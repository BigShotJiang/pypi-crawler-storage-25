from typing import Annotated, Any, Literal, overload

from nexo.types.dict import StrToAnyDict
from nexo.types.misc import IntOrStr, StrOrStrEnum
from nexo.types.string import OptListOfDoubleStrs, OptStr
from pydantic import BaseModel, Field

from .data import CheckData, CountData, DataPair, HealthData, PingData
from .error.descriptor import (
    BadGatewayErrorDescriptor,
    BadRequestErrorDescriptor,
    ConflictErrorDescriptor,
    ErrorDescriptor,
    ForbiddenErrorDescriptor,
    InternalServerErrorDescriptor,
    MethodNotAllowedErrorDescriptor,
    NotFoundErrorDescriptor,
    NotImplementedErrorDescriptor,
    ServiceUnavailableErrorDescriptor,
    TooManyRequestsErrorDescriptor,
    UnauthorizedErrorDescriptor,
    UnprocessableEntityErrorDescriptor,
)
from .error.enums import ErrorCode
from .mixins.general import Descriptor, Success
from .pagination import AnyPagination, OptAnyPagination
from .payload import (
    MultipleDataPairPayload,
    MultipleDataPayload,
    NoDataPayload,
    Payload,
    SingleDataPairPayload,
    SingleDataPayload,
)
from .success.descriptor import (
    AnyDataSuccessDescriptor,
    MultipleDataPairSuccessDescriptor,
    MultipleDataSuccessDescriptor,
    NoDataSuccessDescriptor,
    SingleDataPairSuccessDescriptor,
    SingleDataSuccessDescriptor,
    SuccessDescriptor,
)
from .success.enums import SuccessCode


class ResponseContext(BaseModel):
    status_code: Annotated[int, Field(..., description="Status code")]
    media_type: Annotated[OptStr, Field(None, description="Media type (Optional)")] = (
        None
    )
    headers: Annotated[
        OptListOfDoubleStrs, Field(None, description="Response's headers")
    ] = None


OptResponseContext = ResponseContext | None


class ResponseContextMixin[T: OptResponseContext](BaseModel):
    response_context: Annotated[T, Field(..., description="Response's context")]


class Response[
    S: bool,
    C: StrOrStrEnum,
    D: Any,
    P: OptAnyPagination,
    M: BaseModel | None,
](
    Payload[D, P, M],
    Descriptor[C],
    Success[S],
    BaseModel,
):
    pass


OptResponse = Response | None


# Error Response
class ErrorResponse(
    NoDataPayload[None],
    ErrorDescriptor,
    Response[Literal[False], ErrorCode, None, None, None],
):
    success: Literal[False] = False
    data: None = None
    pagination: None = None
    metadata: None = None
    other: Any = "Please try again later or contact administrator"


OptErrorResponse = ErrorResponse | None


class BadRequestResponse(
    BadRequestErrorDescriptor,
    ErrorResponse,
):
    pass


OptBadRequestResponse = BadRequestResponse | None


class UnauthorizedResponse(
    UnauthorizedErrorDescriptor,
    ErrorResponse,
):
    pass


OptUnauthorizedResponse = UnauthorizedResponse | None


class ForbiddenResponse(
    ForbiddenErrorDescriptor,
    ErrorResponse,
):
    pass


OptForbiddenResponse = ForbiddenResponse | None


class NotFoundResponse(
    NotFoundErrorDescriptor,
    ErrorResponse,
):
    pass


OptNotFoundResponse = NotFoundResponse | None


class MethodNotAllowedResponse(
    MethodNotAllowedErrorDescriptor,
    ErrorResponse,
):
    pass


OptMethodNotAllowedResponse = MethodNotAllowedResponse | None


class ConflictResponse(
    ConflictErrorDescriptor,
    ErrorResponse,
):
    pass


OptConflictResponse = ConflictResponse | None


class UnprocessableEntityResponse(
    UnprocessableEntityErrorDescriptor,
    ErrorResponse,
):
    pass


OptUnprocessableEntityResponse = UnprocessableEntityResponse | None


class TooManyRequestsResponse(
    TooManyRequestsErrorDescriptor,
    ErrorResponse,
):
    pass


OptTooManyRequestsResponse = TooManyRequestsResponse | None


class InternalServerErrorResponse(
    InternalServerErrorDescriptor,
    ErrorResponse,
):
    pass


OptInternalServerErrorResponse = InternalServerErrorResponse | None


class NotImplementedResponse(
    NotImplementedErrorDescriptor,
    ErrorResponse,
):
    pass


OptNotImplementedResponse = NotImplementedResponse | None


class BadGatewayResponse(
    BadGatewayErrorDescriptor,
    ErrorResponse,
):
    pass


OptBadGatewayResponse = BadGatewayResponse | None


class ServiceUnavailableResponse(
    ServiceUnavailableErrorDescriptor,
    ErrorResponse,
):
    pass


OptServiceUnavailableResponse = ServiceUnavailableResponse | None


AnyErrorResponseType = (
    type[BadRequestResponse]
    | type[UnauthorizedResponse]
    | type[ForbiddenResponse]
    | type[NotFoundResponse]
    | type[MethodNotAllowedResponse]
    | type[ConflictResponse]
    | type[UnprocessableEntityResponse]
    | type[TooManyRequestsResponse]
    | type[InternalServerErrorResponse]
    | type[NotImplementedResponse]
    | type[BadGatewayResponse]
    | type[ServiceUnavailableResponse]
)
AnyErrorResponse = (
    BadRequestResponse
    | UnauthorizedResponse
    | ForbiddenResponse
    | NotFoundResponse
    | MethodNotAllowedResponse
    | ConflictResponse
    | UnprocessableEntityResponse
    | TooManyRequestsResponse
    | InternalServerErrorResponse
    | NotImplementedResponse
    | BadGatewayResponse
    | ServiceUnavailableResponse
)
OptAnyErrorResponse = AnyErrorResponse | None


class ErrorResponseFactory:
    @overload
    @staticmethod
    def cls_from_code(
        code: Literal[ErrorCode.BAD_REQUEST, 400],
        /,
    ) -> type[BadRequestResponse]: ...
    @overload
    @staticmethod
    def cls_from_code(
        code: Literal[ErrorCode.UNAUTHORIZED, 401],
        /,
    ) -> type[UnauthorizedResponse]: ...
    @overload
    @staticmethod
    def cls_from_code(
        code: Literal[ErrorCode.FORBIDDEN, 403],
        /,
    ) -> type[ForbiddenResponse]: ...
    @overload
    @staticmethod
    def cls_from_code(
        code: Literal[ErrorCode.NOT_FOUND, 404],
        /,
    ) -> type[NotFoundResponse]: ...
    @overload
    @staticmethod
    def cls_from_code(
        code: Literal[ErrorCode.METHOD_NOT_ALLOWED, 405],
        /,
    ) -> type[MethodNotAllowedResponse]: ...
    @overload
    @staticmethod
    def cls_from_code(
        code: Literal[ErrorCode.CONFLICT, 409],
        /,
    ) -> type[ConflictResponse]: ...
    @overload
    @staticmethod
    def cls_from_code(
        code: Literal[ErrorCode.UNPROCESSABLE_ENTITY, 422],
        /,
    ) -> type[UnprocessableEntityResponse]: ...
    @overload
    @staticmethod
    def cls_from_code(
        code: Literal[ErrorCode.TOO_MANY_REQUESTS, 429],
        /,
    ) -> type[TooManyRequestsResponse]: ...
    @overload
    @staticmethod
    def cls_from_code(
        code: Literal[ErrorCode.INTERNAL_SERVER_ERROR, 500],
        /,
    ) -> type[InternalServerErrorResponse]: ...
    @overload
    @staticmethod
    def cls_from_code(
        code: Literal[ErrorCode.NOT_IMPLEMENTED, 501],
        /,
    ) -> type[NotImplementedResponse]: ...
    @overload
    @staticmethod
    def cls_from_code(
        code: Literal[ErrorCode.BAD_GATEWAY, 502],
        /,
    ) -> type[BadGatewayResponse]: ...
    @overload
    @staticmethod
    def cls_from_code(
        code: Literal[ErrorCode.SERVICE_UNAVAILABLE, 503],
        /,
    ) -> type[ServiceUnavailableResponse]: ...
    @overload
    @staticmethod
    def cls_from_code(
        code: ErrorCode | int,
        /,
    ) -> AnyErrorResponseType: ...
    @staticmethod
    def cls_from_code(
        code: ErrorCode | int,
        /,
    ) -> AnyErrorResponseType:
        if code is ErrorCode.BAD_REQUEST or code == 400:
            return BadRequestResponse
        elif code is ErrorCode.UNAUTHORIZED or code == 401:
            return UnauthorizedResponse
        elif code is ErrorCode.FORBIDDEN or code == 403:
            return ForbiddenResponse
        elif code is ErrorCode.NOT_FOUND or code == 404:
            return NotFoundResponse
        elif code is ErrorCode.METHOD_NOT_ALLOWED or code == 405:
            return MethodNotAllowedResponse
        elif code is ErrorCode.CONFLICT or code == 409:
            return ConflictResponse
        elif code is ErrorCode.UNPROCESSABLE_ENTITY or code == 422:
            return UnprocessableEntityResponse
        elif code is ErrorCode.TOO_MANY_REQUESTS or code == 429:
            return TooManyRequestsResponse
        elif code is ErrorCode.INTERNAL_SERVER_ERROR or code == 500:
            return InternalServerErrorResponse
        elif code is ErrorCode.NOT_IMPLEMENTED or code == 501:
            return NotImplementedResponse
        elif code is ErrorCode.BAD_GATEWAY or code == 502:
            return BadGatewayResponse
        elif code is ErrorCode.SERVICE_UNAVAILABLE or code == 503:
            return ServiceUnavailableResponse
        raise ValueError(f"Unable to determine error response class for code: {code}")

    @overload
    @staticmethod
    def from_code(
        code: Literal[ErrorCode.BAD_REQUEST, 400],
        *,
        message: OptStr = None,
        description: OptStr = None,
        other: Any = None,
    ) -> BadRequestResponse: ...
    @overload
    @staticmethod
    def from_code(
        code: Literal[ErrorCode.UNAUTHORIZED, 401],
        *,
        message: OptStr = None,
        description: OptStr = None,
        other: Any = None,
    ) -> UnauthorizedResponse: ...
    @overload
    @staticmethod
    def from_code(
        code: Literal[ErrorCode.FORBIDDEN, 403],
        *,
        message: OptStr = None,
        description: OptStr = None,
        other: Any = None,
    ) -> ForbiddenResponse: ...
    @overload
    @staticmethod
    def from_code(
        code: Literal[ErrorCode.NOT_FOUND, 404],
        *,
        message: OptStr = None,
        description: OptStr = None,
        other: Any = None,
    ) -> NotFoundResponse: ...
    @overload
    @staticmethod
    def from_code(
        code: Literal[ErrorCode.METHOD_NOT_ALLOWED, 405],
        *,
        message: OptStr = None,
        description: OptStr = None,
        other: Any = None,
    ) -> MethodNotAllowedResponse: ...
    @overload
    @staticmethod
    def from_code(
        code: Literal[ErrorCode.CONFLICT, 409],
        *,
        message: OptStr = None,
        description: OptStr = None,
        other: Any = None,
    ) -> ConflictResponse: ...
    @overload
    @staticmethod
    def from_code(
        code: Literal[ErrorCode.UNPROCESSABLE_ENTITY, 422],
        *,
        message: OptStr = None,
        description: OptStr = None,
        other: Any = None,
    ) -> UnprocessableEntityResponse: ...
    @overload
    @staticmethod
    def from_code(
        code: Literal[ErrorCode.TOO_MANY_REQUESTS, 429],
        *,
        message: OptStr = None,
        description: OptStr = None,
        other: Any = None,
    ) -> TooManyRequestsResponse: ...
    @overload
    @staticmethod
    def from_code(
        code: Literal[ErrorCode.INTERNAL_SERVER_ERROR, 500],
        *,
        message: OptStr = None,
        description: OptStr = None,
        other: Any = None,
    ) -> InternalServerErrorResponse: ...
    @overload
    @staticmethod
    def from_code(
        code: Literal[ErrorCode.NOT_IMPLEMENTED, 501],
        *,
        message: OptStr = None,
        description: OptStr = None,
        other: Any = None,
    ) -> NotImplementedResponse: ...
    @overload
    @staticmethod
    def from_code(
        code: Literal[ErrorCode.BAD_GATEWAY, 502],
        *,
        message: OptStr = None,
        description: OptStr = None,
        other: Any = None,
    ) -> BadGatewayResponse: ...
    @overload
    @staticmethod
    def from_code(
        code: Literal[ErrorCode.SERVICE_UNAVAILABLE, 503],
        *,
        message: OptStr = None,
        description: OptStr = None,
        other: Any = None,
    ) -> ServiceUnavailableResponse: ...
    @overload
    @staticmethod
    def from_code(
        code: ErrorCode | int,
        *,
        message: OptStr = None,
        description: OptStr = None,
        other: Any = None,
    ) -> AnyErrorResponse: ...
    @staticmethod
    def from_code(
        code: ErrorCode | int,
        *,
        message: OptStr = None,
        description: OptStr = None,
        other: Any = None,
    ) -> AnyErrorResponse:
        obj = {}
        if message is not None:
            obj["message"] = message
        if description is not None:
            obj["description"] = description
        if other is not None:
            obj["other"] = other
        return ErrorResponseFactory.cls_from_code(code).model_validate(obj)


OTHER_RESPONSES: dict[
    IntOrStr,
    StrToAnyDict,
] = {
    400: {
        "description": "Bad Request Response",
        "model": BadRequestResponse,
    },
    401: {
        "description": "Unauthorized Response",
        "model": UnauthorizedResponse,
    },
    403: {
        "description": "Forbidden Response",
        "model": ForbiddenResponse,
    },
    404: {
        "description": "Not Found Response",
        "model": NotFoundResponse,
    },
    405: {
        "description": "Method Not Allowed Response",
        "model": MethodNotAllowedResponse,
    },
    409: {
        "description": "Conflict Response",
        "model": ConflictResponse,
    },
    422: {
        "description": "Unprocessable Entity Response",
        "model": UnprocessableEntityResponse,
    },
    429: {
        "description": "Too Many Requests Response",
        "model": TooManyRequestsResponse,
    },
    500: {
        "description": "Internal Server Error Response",
        "model": InternalServerErrorResponse,
    },
    501: {
        "description": "Not Implemented Response",
        "model": NotImplementedResponse,
    },
    502: {
        "description": "Bad Gateway Response",
        "model": BadGatewayResponse,
    },
    503: {
        "description": "Service Unavailable Response",
        "model": ServiceUnavailableResponse,
    },
}


class SuccessResponse[D: Any, P: OptAnyPagination, M: BaseModel | None](
    SuccessDescriptor,
    Response[Literal[True], SuccessCode, D, P, M],
):
    success: Literal[True] = True


class AnyDataResponse[D: Any, P: OptAnyPagination, M: BaseModel | None](
    AnyDataSuccessDescriptor,
    SuccessResponse[D, P, M],
):
    pass


class NoDataResponse[M: BaseModel | None](
    NoDataPayload[M],
    NoDataSuccessDescriptor,
    SuccessResponse[None, None, M],
):
    data: None = None
    pagination: None = None

    @classmethod
    def new(
        cls,
        *,
        message: OptStr = None,
        description: OptStr = None,
        metadata: M = None,
        other: Any = None,
    ) -> "NoDataResponse[M]":
        descriptor = NoDataSuccessDescriptor()
        return cls(
            message=message if message is not None else descriptor.message,
            description=(
                description if description is not None else descriptor.description
            ),
            metadata=metadata,
            other=other,
        )


class SingleDataResponse[D: Any, M: BaseModel | None](
    SingleDataPayload[D, M],
    SingleDataSuccessDescriptor,
    SuccessResponse[D, None, M],
):
    pagination: None = None

    @classmethod
    def new(
        cls,
        *,
        message: OptStr = None,
        description: OptStr = None,
        data: D,
        metadata: M = None,
        other: Any = None,
    ) -> "SingleDataResponse[D, M]":
        descriptor = SingleDataSuccessDescriptor()
        return cls(
            message=message if message is not None else descriptor.message,
            description=(
                description if description is not None else descriptor.description
            ),
            data=data,
            metadata=metadata,
            other=other,
        )


class HealthResponse(SingleDataResponse[HealthData, None]):
    data: Annotated[
        HealthData, Field(HealthData(), description="Health response's data")
    ] = HealthData()
    metadata: Annotated[None, Field(None, description="Health response's metadata")] = (
        None
    )


class PingResponse(SingleDataResponse[PingData, None]):
    data: Annotated[PingData, Field(PingData(), description="Ping response's data")] = (
        PingData()
    )
    metadata: Annotated[None, Field(None, description="Ping response's metadata")] = (
        None
    )


class CheckDataResponse[M: BaseModel | None](SingleDataResponse[CheckData, M]):
    pass


class CountDataResponse[M: BaseModel | None](SingleDataResponse[CountData, M]):
    pass


class SingleDataPairResponse[D: Any, M: BaseModel | None](
    SingleDataPairPayload[D, M],
    SingleDataPairSuccessDescriptor,
    SuccessResponse[DataPair[D, D], None, M],
):
    pagination: None = None

    @classmethod
    def new(
        cls,
        *,
        message: OptStr = None,
        description: OptStr = None,
        old_data: D,
        new_data: D,
        metadata: M = None,
        other: Any = None,
    ) -> "SingleDataPairResponse[D, M]":
        descriptor = SingleDataPairSuccessDescriptor()
        return cls(
            message=message if message is not None else descriptor.message,
            description=(
                description if description is not None else descriptor.description
            ),
            data=DataPair[D, D](
                old=old_data,
                new=new_data,
            ),
            metadata=metadata,
            other=other,
        )


class MultipleDataResponse[D: Any, P: AnyPagination, M: BaseModel | None](
    MultipleDataPayload[D, P, M],
    MultipleDataSuccessDescriptor,
    SuccessResponse[list[D], P, M],
):
    @classmethod
    def new(
        cls,
        *,
        message: OptStr = None,
        description: OptStr = None,
        data: list[D],
        pagination: P,
        metadata: M = None,
        other: Any = None,
    ) -> "MultipleDataResponse[D, P, M]":
        descriptor = MultipleDataSuccessDescriptor()
        return cls(
            message=message if message is not None else descriptor.message,
            description=(
                description if description is not None else descriptor.description
            ),
            data=data,
            pagination=pagination,
            metadata=metadata,
            other=other,
        )


class MultipleDataPairResponse[D: Any, P: AnyPagination, M: BaseModel | None](
    MultipleDataPairPayload[D, P, M],
    MultipleDataPairSuccessDescriptor,
    SuccessResponse[DataPair[list[D], list[D]], P, M],
):
    @classmethod
    def new(
        cls,
        *,
        message: OptStr = None,
        description: OptStr = None,
        old_data: list[D],
        new_data: list[D],
        pagination: P,
        metadata: M = None,
        other: Any = None,
    ) -> "MultipleDataPairResponse[D, P, M]":
        descriptor = MultipleDataPairSuccessDescriptor()
        return cls(
            message=message if message is not None else descriptor.message,
            description=(
                description if description is not None else descriptor.description
            ),
            data=DataPair[list[D], list[D]](
                old=old_data,
                new=new_data,
            ),
            pagination=pagination,
            metadata=metadata,
            other=other,
        )


AnySuccessResponse = (
    AnyDataResponse
    | NoDataResponse
    | SingleDataResponse
    | SingleDataPairResponse
    | MultipleDataResponse
    | MultipleDataPairResponse
)
OptAnySuccessResponse = AnySuccessResponse | None


AnyResponse = AnyErrorResponse | AnySuccessResponse
OptAnyResponse = AnyResponse | None


class ResponseMixin[T: OptAnyResponse](BaseModel):
    response: Annotated[T, Field(..., description="Response")]
