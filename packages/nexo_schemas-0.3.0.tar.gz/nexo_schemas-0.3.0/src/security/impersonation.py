from collections.abc import Callable
from enum import StrEnum
from typing import Annotated, Literal, overload
from uuid import UUID

from fastapi import Header, Query
from fastapi.requests import HTTPConnection, Request
from fastapi.websockets import WebSocket
from nexo.enums.connection import Header as HeaderEnum
from nexo.enums.connection import OptProtocol, Protocol
from nexo.types.string import ListOfStrs
from nexo.types.uuid import OptUUID
from pydantic import BaseModel, Field

from ..mixins.identity import UUIDPrincipalId


class Source(StrEnum):
    HEADER = "header"
    STATE = "state"

    @classmethod
    def choices(cls) -> ListOfStrs:
        return [e.value for e in cls]


class Impersonation(UUIDPrincipalId[UUID]):
    @classmethod
    def from_header(cls, conn: HTTPConnection) -> "Impersonation | None":
        principal_id = conn.headers.get(HeaderEnum.X_PRINCIPAL_ID, None)
        if principal_id is not None:
            principal_id = UUID(principal_id)
            return cls(principal_id=principal_id)

        return None

    @classmethod
    def from_query(cls, conn: HTTPConnection) -> "Impersonation | None":
        principal_id = conn.query_params.get(HeaderEnum.X_PRINCIPAL_ID.value, None)
        if principal_id is not None:
            principal_id = UUID(principal_id)
            return cls(principal_id=principal_id)

        return None

    @classmethod
    def extract(cls, conn: HTTPConnection) -> "Impersonation | None":
        impersonation = getattr(conn.state, "impersonation", None)
        if isinstance(impersonation, Impersonation):
            return impersonation

        impersonation = cls.from_header(conn)
        if impersonation is not None:
            return impersonation

        impersonation = cls.from_query(conn)
        if impersonation is not None:
            return impersonation

        return None

    @overload
    @classmethod
    def as_dependency(
        cls,
        protocol: None = None,
        /,
    ) -> Callable[[HTTPConnection, OptUUID], "Impersonation | None"]: ...
    @overload
    @classmethod
    def as_dependency(
        cls,
        protocol: Literal[Protocol.HTTP],
        /,
    ) -> Callable[[Request, OptUUID], "Impersonation | None"]: ...
    @overload
    @classmethod
    def as_dependency(
        cls,
        protocol: Literal[Protocol.WEBSOCKET],
        /,
    ) -> Callable[[WebSocket, OptUUID], "Impersonation | None"]: ...
    @classmethod
    def as_dependency(
        cls,
        protocol: OptProtocol = None,
        /,
    ) -> (
        Callable[[HTTPConnection, OptUUID], "Impersonation | None"]
        | Callable[[Request, OptUUID], "Impersonation | None"]
        | Callable[[WebSocket, OptUUID], "Impersonation | None"]
    ):
        def _dependency(
            conn: HTTPConnection,
            # These are for documentation purpose only
            _principal_id: OptUUID = Header(
                None,
                alias=HeaderEnum.X_PRINCIPAL_ID.value,
                description="Principal's ID",
            ),
        ) -> "Impersonation | None":
            return cls.extract(conn)

        def _request_dependency(
            request: Request,
            # These are for documentation purpose only
            _principal_id: OptUUID = Header(
                None,
                alias=HeaderEnum.X_PRINCIPAL_ID.value,
                description="Principal's ID",
            ),
        ) -> "Impersonation | None":
            return cls.extract(request)

        def _websocket_dependency(
            websocket: WebSocket,
            # These are for documentation purpose only
            _principal_id: OptUUID = Query(
                None,
                alias=HeaderEnum.X_PRINCIPAL_ID.value,
                description="Principal's ID",
            ),
        ) -> "Impersonation | None":
            return cls.extract(websocket)

        if protocol is None:
            return _dependency
        elif protocol is Protocol.HTTP:
            return _request_dependency
        elif protocol is Protocol.WEBSOCKET:
            return _websocket_dependency


OptImpersonation = Impersonation | None


class ImpersonationMixin[T: OptImpersonation](BaseModel):
    impersonation: Annotated[T, Field(..., description="Impersonation")]
