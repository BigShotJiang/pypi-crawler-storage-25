from collections.abc import Sequence
from enum import StrEnum
from typing import Annotated

from nexo.types.string import ListOfStrs
from pydantic import BaseModel, Field


class Domain(StrEnum):
    PERSONAL = "personal"
    SYSTEM = "system"
    TENANT = "tenant"

    @classmethod
    def choices(cls) -> ListOfStrs:
        return [e.value for e in cls]


OptDomain = Domain | None


class DomainMixin[T: OptDomain](BaseModel):
    domain: Annotated[T, Field(..., description="Domain")]


ListOfDomains = list[Domain]
OptListOfDomains = ListOfDomains | None
SeqOfDomains = Sequence[Domain]
OptSeqOfDomains = SeqOfDomains | None


class DomainsMixin[T: OptSeqOfDomains](BaseModel):
    domains: Annotated[T, Field(..., description="Domains")]


class RolePrefix(StrEnum):
    MEDICAL = "medical"
    SYSTEM = "system"
    TENANT = "tenant"

    @classmethod
    def choices(cls) -> ListOfStrs:
        return [e.value for e in cls]
