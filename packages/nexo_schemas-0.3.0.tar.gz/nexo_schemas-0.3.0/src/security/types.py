from nexo.enums.organization import ListOfOrganizationRoles, SeqOfOrganizationRoles
from nexo.enums.system import ListOfSystemRoles, SeqOfSystemRoles

ListOfDomainRoles = ListOfOrganizationRoles | ListOfSystemRoles
OptListOfDomainRoles = ListOfDomainRoles | None
SeqOfDomainRoles = SeqOfOrganizationRoles | SeqOfSystemRoles
OptSeqOfDomainRoles = SeqOfDomainRoles | None
