from typing import Annotated

import pika
import pika.adapters.blocking_connection
from google.cloud.pubsub_v1 import PublisherClient
from nexo.types.dict import OptStrToAnyDict
from pydantic import BaseModel, ConfigDict, Field, computed_field


class PubSubPublisher(BaseModel):
    model_config = ConfigDict(arbitrary_types_allowed=True)

    client: Annotated[PublisherClient, Field(..., description="Publisher client")]
    project_id: Annotated[str, Field(..., description="Project ID")]
    topic_id: Annotated[str, Field(..., description="Topic ID")]

    @computed_field
    @property
    def topic_path(self) -> str:
        return self.client.topic_path(self.project_id, self.topic_id)


OptPubSubPublisher = PubSubPublisher | None


class RabbitMQPublisher(BaseModel):
    """
    Lightweight, self-contained publisher handle.
    Meant to be passed into low-level models like Operation.
    Both sync and async channels are always available;
    Manager is responsible for instantiating both.
    """

    model_config = ConfigDict(arbitrary_types_allowed=True)

    channel: Annotated[
        pika.adapters.blocking_connection.BlockingChannel,
        Field(..., description="Sync pika channel"),
    ]
    exchange_name: Annotated[
        str, Field(default="", description="Exchange name, empty = default exchange")
    ]
    routing_key: Annotated[str, Field(..., description="Routing key / queue name")]

    def publish(
        self,
        data: bytes,
        *,
        headers: OptStrToAnyDict = None,
        content_type: str = "application/json",
    ) -> None:
        """
        Sync publish via pika. Fast by default (fire-and-forget).
        Set confirm_delivery=True to wait for broker ack (~1-5ms extra).
        """

        properties = pika.BasicProperties(
            content_type=content_type,
            headers=headers or {},
            delivery_mode=pika.DeliveryMode.Persistent,
        )

        self.channel.basic_publish(
            exchange=self.exchange_name,
            routing_key=self.routing_key,
            body=data,
            properties=properties,
        )


OptRabbitMQPublisher = RabbitMQPublisher | None


AnyPublisher = PubSubPublisher | RabbitMQPublisher
OptAnyPublisher = AnyPublisher | None


ListOfAnyPublishers = list[AnyPublisher]
OptListOfAnyPublishers = ListOfAnyPublishers | None
