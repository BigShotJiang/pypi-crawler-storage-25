"""End-to-end tests for raindrop-bedrock.

These tests make REAL API calls to AWS Bedrock and verify that events
land in the Raindrop dashboard via the TRPC API.  They are skipped
automatically when the required environment variables are not set.

Required environment variables:
  AWS_ACCESS_KEY_ID            — AWS credentials
  AWS_SECRET_ACCESS_KEY        — AWS credentials
  RAINDROP_WRITE_KEY           — (or RAINDROP_API_KEY) Raindrop write key
  RAINDROP_DASHBOARD_TOKEN     — Bearer token for backend.raindrop.ai TRPC API

Run locally:
  cd packages/bedrock-python
  source .venv/bin/activate
  export AWS_ACCESS_KEY_ID=... AWS_SECRET_ACCESS_KEY=... AWS_DEFAULT_REGION=us-east-1
  export RAINDROP_WRITE_KEY=your-write-key
  export RAINDROP_DASHBOARD_TOKEN=eyJ...
  python -m pytest tests/test_e2e.py -v -s
"""

from __future__ import annotations

import json
import os
import time
import urllib.parse
import uuid

import pytest
import requests

# ---------------------------------------------------------------------------
# Environment / skip gate
# ---------------------------------------------------------------------------

WRITE_KEY = os.getenv("RAINDROP_WRITE_KEY") or os.getenv("RAINDROP_API_KEY")
AWS_ACCESS_KEY_ID = os.getenv("AWS_ACCESS_KEY_ID")
AWS_SECRET_ACCESS_KEY = os.getenv("AWS_SECRET_ACCESS_KEY")
AWS_DEFAULT_REGION = os.getenv("AWS_DEFAULT_REGION", "us-east-1")
DASHBOARD_TOKEN = os.getenv("RAINDROP_DASHBOARD_TOKEN")
BACKEND_URL = os.getenv("RAINDROP_BACKEND_URL", "https://backend.raindrop.ai")

skip_unless_e2e = pytest.mark.skipif(
    not all([AWS_ACCESS_KEY_ID, AWS_SECRET_ACCESS_KEY, WRITE_KEY, DASHBOARD_TOKEN]),
    reason="AWS credentials, RAINDROP_WRITE_KEY, and RAINDROP_DASHBOARD_TOKEN required",
)

RUN_ID = uuid.uuid4().hex[:10]
CONVERSE_MODEL = os.getenv("BEDROCK_CONVERSE_MODEL", "amazon.nova-lite-v1:0")
INVOKE_MODEL_ID = os.getenv("BEDROCK_INVOKE_MODEL", "amazon.nova-lite-v1:0")

# ---------------------------------------------------------------------------
# Dashboard TRPC query helpers
# ---------------------------------------------------------------------------


def _query_dashboard(limit: int = 50) -> list[dict]:
    """Fetch recent events from the dashboard TRPC API."""
    input_obj = {"json": {"limit": limit, "orderBy": {"field": "timestamp", "direction": "desc"}}}
    encoded = urllib.parse.quote(json.dumps(input_obj))
    resp = requests.get(
        f"{BACKEND_URL}/api/trpc/events.list?input={encoded}",
        headers={"Authorization": f"Bearer {DASHBOARD_TOKEN}"},
        timeout=20,
    )
    resp.raise_for_status()
    return resp.json().get("result", {}).get("data", [])


def poll_events(
    user_id: str,
    min_count: int = 1,
    timeout: int = 60,
    interval: int = 4,
) -> list[dict]:
    """Poll until *min_count* events for *user_id* appear, or raise."""
    deadline = time.time() + timeout
    matched: list[dict] = []
    while time.time() < deadline:
        all_events = _query_dashboard()
        matched = [e for e in all_events if e.get("userId") == user_id]
        if len(matched) >= min_count:
            return matched
        time.sleep(interval)
    raise TimeoutError(
        f"Expected >= {min_count} events for userId={user_id}, "
        f"got {len(matched)} after {timeout}s"
    )


def _user(suffix: str) -> str:
    return f"e2e_bedrock_{RUN_ID}_{suffix}"


def _convo(suffix: str) -> str:
    return f"e2e_convo_{RUN_ID}_{suffix}"


# ---------------------------------------------------------------------------
# Sync converse tests
# ---------------------------------------------------------------------------


@skip_unless_e2e
class TestConverseE2E:
    """converse() end-to-end: full event shape verification."""

    def test_converse_event_shape(self):
        """Verify userId, aiData nesting, model, input/output, tokens, finish_reason."""
        import boto3
        from raindrop_bedrock import RaindropBedrock

        user_id = _user("conv_shape")
        convo_id = _convo("conv_shape")

        rb = RaindropBedrock(api_key=WRITE_KEY, user_id=user_id, convo_id=convo_id)
        client = boto3.client("bedrock-runtime", region_name=AWS_DEFAULT_REGION)
        rb.wrap(client)

        response = client.converse(
            modelId=CONVERSE_MODEL,
            messages=[{"role": "user", "content": [{"text": "What is the capital of France? Reply in one word."}]}],
        )
        assert "output" in response
        rb.flush()

        rows = poll_events(user_id)
        assert len(rows) >= 1
        ev = rows[0]

        assert ev["userId"] == user_id

        ai = ev.get("aiData") or {}
        assert ai.get("input"), "input should be captured"
        assert "capital" in ai["input"].lower() or "france" in ai["input"].lower()
        assert ai.get("output"), "output should be captured"
        assert ai.get("model") == CONVERSE_MODEL
        assert ai.get("convoId") == convo_id

        props = ev.get("properties") or {}
        prompt_tokens = props.get("ai.usage.prompt_tokens")
        completion_tokens = props.get("ai.usage.completion_tokens")
        assert prompt_tokens is not None and int(prompt_tokens) > 0, (
            f"prompt_tokens should be > 0, got {prompt_tokens}"
        )
        assert completion_tokens is not None and int(completion_tokens) > 0, (
            f"completion_tokens should be > 0, got {completion_tokens}"
        )
        finish = props.get("bedrock.finish_reason")
        assert finish in ("end_turn", "stop", "max_tokens"), (
            f"Expected a valid finish_reason, got {finish!r}"
        )

    def test_converse_multi_turn_captures_last_user_input(self):
        """Multi-turn: the tracked input should be the last user message."""
        import boto3
        from raindrop_bedrock import RaindropBedrock

        user_id = _user("multi_turn")
        rb = RaindropBedrock(api_key=WRITE_KEY, user_id=user_id)
        client = boto3.client("bedrock-runtime", region_name=AWS_DEFAULT_REGION)
        rb.wrap(client)

        client.converse(
            modelId=CONVERSE_MODEL,
            messages=[
                {"role": "user", "content": [{"text": "My name is Alice."}]},
                {"role": "assistant", "content": [{"text": "Hello Alice!"}]},
                {"role": "user", "content": [{"text": "What is 2+2? Reply with just the number."}]},
            ],
        )
        rb.flush()

        rows = poll_events(user_id)
        ai = rows[0].get("aiData") or {}
        assert "2+2" in (ai.get("input") or ""), (
            f"Expected last user message '2+2' in input, got: {ai.get('input')!r}"
        )


# ---------------------------------------------------------------------------
# Sync invoke_model tests
# ---------------------------------------------------------------------------


@skip_unless_e2e
class TestInvokeModelE2E:
    """invoke_model() end-to-end with full property verification."""

    @pytest.mark.skipif(
        not os.getenv("BEDROCK_INVOKE_MODEL"),
        reason="invoke_model event-shape test requires BEDROCK_INVOKE_MODEL set to a Claude model (e.g. anthropic.claude-3-haiku-20240307-v1:0)",
    )
    def test_invoke_model_event_shape(self):
        """Verify model, output, tokens, stop_reason for invoke_model (Claude format).

        Skipped by default because invoke_model response parsing only supports
        Claude/Titan/Llama formats. Set BEDROCK_INVOKE_MODEL to a Claude model
        with 'anthropic_version' in the request body.
        """
        import boto3
        from raindrop_bedrock import RaindropBedrock

        user_id = _user("invoke_shape")
        convo_id = _convo("invoke_shape")

        rb = RaindropBedrock(api_key=WRITE_KEY, user_id=user_id, convo_id=convo_id)
        client = boto3.client("bedrock-runtime", region_name=AWS_DEFAULT_REGION)
        rb.wrap(client)

        response = client.invoke_model(
            modelId=INVOKE_MODEL_ID,
            contentType="application/json",
            body=json.dumps({
                "anthropic_version": "bedrock-2023-05-31",
                "messages": [{"role": "user", "content": "Say hello in one word."}],
                "max_tokens": 64,
            }),
        )

        result = json.loads(response["body"].read())
        assert "content" in result, "invoke_model response should have content"

        rb.flush()

        rows = poll_events(user_id)
        assert len(rows) >= 1
        ev = rows[0]

        assert ev["userId"] == user_id

        ai = ev.get("aiData") or {}
        assert ai.get("output"), "output should be captured"
        assert ai.get("model") == INVOKE_MODEL_ID
        assert ai.get("convoId") == convo_id

        props = ev.get("properties") or {}
        assert int(props.get("ai.usage.prompt_tokens", 0)) > 0
        assert int(props.get("ai.usage.completion_tokens", 0)) > 0

    def test_invoke_model_body_still_readable(self):
        """After wrapper consumes the body stream, caller can still read() it."""
        import boto3
        from raindrop_bedrock import RaindropBedrock

        user_id = _user("body_read")
        rb = RaindropBedrock(api_key=WRITE_KEY, user_id=user_id)
        client = boto3.client("bedrock-runtime", region_name=AWS_DEFAULT_REGION)
        rb.wrap(client)

        response = client.invoke_model(
            modelId=CONVERSE_MODEL,
            contentType="application/json",
            body=json.dumps({
                "messages": [{"role": "user", "content": [{"text": "Say hi."}]}],
            }),
        )

        body_bytes = response["body"].read()
        assert len(body_bytes) > 0, "body should be readable after wrapping"
        parsed = json.loads(body_bytes)
        assert "output" in parsed or "content" in parsed
        rb.shutdown()


# ---------------------------------------------------------------------------
# Error handling
# ---------------------------------------------------------------------------


@skip_unless_e2e
class TestErrorE2E:
    """Error tracking: invalid model produces an error event with exact props."""

    def test_error_event_has_error_properties(self):
        import boto3
        from raindrop_bedrock import RaindropBedrock

        user_id = _user("error")
        convo_id = _convo("error")
        rb = RaindropBedrock(api_key=WRITE_KEY, user_id=user_id, convo_id=convo_id)
        client = boto3.client("bedrock-runtime", region_name=AWS_DEFAULT_REGION)
        rb.wrap(client)

        with pytest.raises(Exception):
            client.converse(
                modelId="invalid.model.does.not.exist",
                messages=[{"role": "user", "content": [{"text": "Hello"}]}],
            )

        rb.flush()

        rows = poll_events(user_id, timeout=30)
        assert len(rows) >= 1, "Error event should still be tracked"
        props = rows[0].get("properties") or {}
        assert props.get("error.type"), f"error.type should be set, got props={props}"
        assert props.get("error.message"), f"error.message should be set, got props={props}"


# ---------------------------------------------------------------------------
# Multiple calls / no leak
# ---------------------------------------------------------------------------


@skip_unless_e2e
class TestMultipleCallsE2E:
    """Multiple converse() calls produce distinct events with different inputs."""

    def test_three_calls_produce_three_events(self):
        import boto3
        from raindrop_bedrock import RaindropBedrock

        user_id = _user("multi")
        rb = RaindropBedrock(api_key=WRITE_KEY, user_id=user_id)
        client = boto3.client("bedrock-runtime", region_name=AWS_DEFAULT_REGION)
        rb.wrap(client)

        prompts = ["Count: zero", "Count: one", "Count: two"]
        for prompt in prompts:
            client.converse(
                modelId=CONVERSE_MODEL,
                messages=[{"role": "user", "content": [{"text": prompt}]}],
            )

        rb.flush()

        rows = poll_events(user_id, min_count=3, timeout=90)
        assert len(rows) >= 3, f"Expected 3 events, got {len(rows)}"

        inputs = {(r.get("aiData") or {}).get("input", "") for r in rows}
        assert len(inputs) >= 2, (
            f"Expected distinct inputs (no cross-contamination), got: {inputs}"
        )


# ---------------------------------------------------------------------------
# Factory function
# ---------------------------------------------------------------------------


@skip_unless_e2e
class TestFactoryE2E:
    """create_raindrop_bedrock() factory produces events with correct defaults."""

    def test_factory_event_with_properties(self):
        import boto3
        from raindrop_bedrock import create_raindrop_bedrock

        user_id = _user("factory")
        convo_id = _convo("factory")
        rd = create_raindrop_bedrock(api_key=WRITE_KEY, user_id=user_id, convo_id=convo_id)

        client = boto3.client("bedrock-runtime", region_name=AWS_DEFAULT_REGION)
        rd.wrap(client)

        client.converse(
            modelId=CONVERSE_MODEL,
            messages=[{"role": "user", "content": [{"text": "Factory test: say OK."}]}],
        )
        rd.flush()

        rows = poll_events(user_id)
        ev = rows[0]
        assert ev["userId"] == user_id
        ai = ev.get("aiData") or {}
        assert ai.get("convoId") == convo_id
        assert ai.get("model") == CONVERSE_MODEL
        assert ai.get("output"), "output should be captured"
        props = ev.get("properties") or {}
        assert int(props.get("ai.usage.prompt_tokens", 0)) > 0


# ---------------------------------------------------------------------------
# Async
# ---------------------------------------------------------------------------


@skip_unless_e2e
class TestAsyncE2E:
    """Async converse() via aioboto3 produces events with full properties."""

    def test_async_converse_event_shape(self):
        import asyncio
        import aioboto3
        from raindrop_bedrock import RaindropBedrock

        user_id = _user("async_conv")
        convo_id = _convo("async_conv")
        rb = RaindropBedrock(api_key=WRITE_KEY, user_id=user_id, convo_id=convo_id)

        async def _run():
            session = aioboto3.Session()
            async with session.client("bedrock-runtime", region_name=AWS_DEFAULT_REGION) as client:
                rb.async_wrap(client)
                return await client.converse(
                    modelId=CONVERSE_MODEL,
                    messages=[{"role": "user", "content": [{"text": "Async: what is 1+1? Reply with the number."}]}],
                )

        response = asyncio.run(_run())
        assert "output" in response
        rb.flush()

        rows = poll_events(user_id)
        ev = rows[0]

        assert ev["userId"] == user_id
        ai = ev.get("aiData") or {}
        assert ai.get("model") == CONVERSE_MODEL
        assert ai.get("convoId") == convo_id
        assert ai.get("input"), "input should be captured"
        assert ai.get("output"), "output should be captured"

        props = ev.get("properties") or {}
        assert int(props.get("ai.usage.prompt_tokens", 0)) > 0
        assert int(props.get("ai.usage.completion_tokens", 0)) > 0

    @pytest.mark.skipif(
        not os.getenv("BEDROCK_INVOKE_MODEL"),
        reason="async invoke_model event test requires BEDROCK_INVOKE_MODEL set to a Claude model",
    )
    def test_async_invoke_model_event_shape(self):
        """Async invoke_model with Claude streaming body produces correct telemetry."""
        import asyncio
        import aioboto3
        from raindrop_bedrock import RaindropBedrock

        user_id = _user("async_invoke")
        rb = RaindropBedrock(api_key=WRITE_KEY, user_id=user_id)

        async def _run():
            session = aioboto3.Session()
            async with session.client("bedrock-runtime", region_name=AWS_DEFAULT_REGION) as client:
                rb.async_wrap(client)
                response = await client.invoke_model(
                    modelId=INVOKE_MODEL_ID,
                    contentType="application/json",
                    body=json.dumps({
                        "anthropic_version": "bedrock-2023-05-31",
                        "messages": [{"role": "user", "content": "Say hi."}],
                        "max_tokens": 32,
                    }),
                )
                body_bytes = await response["body"].read()
                return json.loads(body_bytes)

        result = asyncio.run(_run())
        assert "content" in result
        rb.flush()

        rows = poll_events(user_id)
        ev = rows[0]
        assert ev["userId"] == user_id
        props = ev.get("properties") or {}
        assert int(props.get("ai.usage.prompt_tokens", 0)) > 0
        assert int(props.get("ai.usage.completion_tokens", 0)) > 0


# ---------------------------------------------------------------------------
# ConvoId grouping
# ---------------------------------------------------------------------------


@skip_unless_e2e
class TestConvoIdGroupingE2E:
    """Two calls with same convo_id share it; a third with different convo_id is separate."""

    def test_convo_id_isolation(self):
        import boto3
        from raindrop_bedrock import RaindropBedrock

        user_id = _user("convo_grp")
        shared = _convo("shared")
        other = _convo("other")

        rb1 = RaindropBedrock(api_key=WRITE_KEY, user_id=user_id, convo_id=shared)
        client = boto3.client("bedrock-runtime", region_name=AWS_DEFAULT_REGION)
        rb1.wrap(client)

        client.converse(modelId=CONVERSE_MODEL, messages=[{"role": "user", "content": [{"text": "Event A"}]}])
        client.converse(modelId=CONVERSE_MODEL, messages=[{"role": "user", "content": [{"text": "Event B"}]}])
        rb1.flush()

        rb2 = RaindropBedrock(api_key=WRITE_KEY, user_id=user_id, convo_id=other)
        client2 = boto3.client("bedrock-runtime", region_name=AWS_DEFAULT_REGION)
        rb2.wrap(client2)
        client2.converse(modelId=CONVERSE_MODEL, messages=[{"role": "user", "content": [{"text": "Event C"}]}])
        rb2.flush()

        rows = poll_events(user_id, min_count=3, timeout=90)
        convo_ids = [(r.get("aiData") or {}).get("convoId") for r in rows]
        assert convo_ids.count(shared) >= 2, (
            f"Expected >= 2 events with convoId={shared}, got {convo_ids}"
        )
        assert any(c == other for c in convo_ids), (
            f"Expected at least 1 event with convoId={other}, got {convo_ids}"
        )
