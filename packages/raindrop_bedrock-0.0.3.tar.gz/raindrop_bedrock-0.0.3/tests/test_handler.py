"""Tests for AWS Bedrock Raindrop integration."""
import asyncio
import json
import logging
import warnings
from unittest.mock import MagicMock, patch

import pytest

from raindrop_bedrock import RaindropBedrock, create_raindrop_bedrock
from raindrop_bedrock.wrapper import (
    _build_token_properties,
    _extract_converse_output,
    _extract_parsed_invoke_fields,
    _format_converse_input,
    _parse_invoke_response,
    _wrap_bedrock_client,
)


# ------------------------------------------------------------------
# Helper function tests
# ------------------------------------------------------------------


class TestConverseInputFormatting:
    """Test input extraction from Converse messages."""

    def test_formats_single_message(self):
        messages = [{"role": "user", "content": [{"text": "Hello"}]}]
        result = _format_converse_input(messages)
        assert result == "Hello"

    def test_formats_multi_turn_extracts_last_user_only(self):
        messages = [
            {"role": "user", "content": [{"text": "Hi"}]},
            {"role": "assistant", "content": [{"text": "Hello!"}]},
            {"role": "user", "content": [{"text": "What is 2+2?"}]},
        ]
        result = _format_converse_input(messages)
        assert result == "What is 2+2?"
        assert "Hi" not in result
        assert "Hello!" not in result

    def test_handles_none(self):
        assert _format_converse_input(None) is None

    def test_handles_empty(self):
        assert _format_converse_input([]) is None


class TestConverseOutputExtraction:
    """Test output extraction from Converse response."""

    def test_extracts_text(self):
        response = {
            "output": {"message": {"content": [{"text": "Paris"}]}},
            "usage": {"inputTokens": 10, "outputTokens": 5},
        }
        assert _extract_converse_output(response) == "Paris"

    def test_handles_empty_content(self):
        response = {"output": {"message": {"content": []}}}
        assert _extract_converse_output(response) is None

    def test_handles_missing_output(self):
        assert _extract_converse_output({}) is None


class TestInvokeModelResponseParsing:
    """Test response parsing for different model formats."""

    def test_claude_format(self):
        body = json.dumps({
            "content": [{"type": "text", "text": "Hello from Claude!"}],
            "usage": {"input_tokens": 10, "output_tokens": 5},
        }).encode()
        response = {"body": body}
        output, pt, ct, sr, cached = _parse_invoke_response(response)
        assert output == "Hello from Claude!"
        assert pt == 10
        assert ct == 5
        assert sr is None
        assert cached is None

    def test_claude_format_with_stop_reason(self):
        body = json.dumps({
            "content": [{"type": "text", "text": "Hello!"}],
            "usage": {"input_tokens": 10, "output_tokens": 5},
            "stop_reason": "end_turn",
        }).encode()
        response = {"body": body}
        output, pt, ct, sr, cached = _parse_invoke_response(response)
        assert output == "Hello!"
        assert sr == "end_turn"

    def test_claude_format_with_cached_tokens(self):
        body = json.dumps({
            "content": [{"type": "text", "text": "Hello!"}],
            "usage": {
                "input_tokens": 10,
                "output_tokens": 5,
                "cache_read_input_tokens": 3,
            },
        }).encode()
        response = {"body": body}
        output, pt, ct, sr, cached = _parse_invoke_response(response)
        assert cached == 3

    def test_titan_format(self):
        body = json.dumps({
            "inputTextTokenCount": 8,
            "results": [{"tokenCount": 12, "outputText": "Hello from Titan!"}],
        }).encode()
        response = {"body": body}
        output, pt, ct, sr, cached = _parse_invoke_response(response)
        assert output == "Hello from Titan!"
        assert pt == 8
        assert ct == 12
        assert sr is None
        assert cached is None

    def test_llama_format(self):
        body = json.dumps({
            "generation": "Hello from Llama!",
            "prompt_token_count": 6,
            "generation_token_count": 4,
        }).encode()
        response = {"body": body}
        output, pt, ct, sr, cached = _parse_invoke_response(response)
        assert output == "Hello from Llama!"
        assert pt == 6
        assert ct == 4
        assert sr is None
        assert cached is None

    def test_llama_format_with_stop_reason(self):
        body = json.dumps({
            "generation": "Hello from Llama!",
            "prompt_token_count": 6,
            "generation_token_count": 4,
            "stop_reason": "stop",
        }).encode()
        response = {"body": body}
        output, pt, ct, sr, cached = _parse_invoke_response(response)
        assert sr == "stop"

    def test_handles_empty_body(self):
        output, pt, ct, sr, cached = _parse_invoke_response({})
        assert output is None
        assert pt is None
        assert ct is None
        assert sr is None
        assert cached is None

    def test_handles_invalid_json(self):
        response = {"body": b"not json"}
        output, pt, ct, sr, cached = _parse_invoke_response(response)
        assert output is None

    def test_streaming_body_replaced_with_readable(self):
        """Ensures the caller can still call .read() on the body after we parse it."""
        import io

        body_data = json.dumps({
            "content": [{"type": "text", "text": "Hello!"}],
            "usage": {"input_tokens": 1, "output_tokens": 1},
        }).encode()
        fake_stream = io.BytesIO(body_data)
        response = {"body": fake_stream}
        output, pt, ct, sr, cached = _parse_invoke_response(response)
        assert output == "Hello!"
        assert response["body"].read() == body_data


class TestBuildTokenProperties:
    """Test the _build_token_properties helper."""

    def test_returns_none_when_all_none(self):
        assert _build_token_properties(None, None) is None

    def test_returns_prompt_only(self):
        props = _build_token_properties(10, None)
        assert props == {"ai.usage.prompt_tokens": 10}

    def test_returns_both(self):
        props = _build_token_properties(10, 5)
        assert props == {"ai.usage.prompt_tokens": 10, "ai.usage.completion_tokens": 5}

    def test_includes_stop_reason(self):
        props = _build_token_properties(10, 5, stop_reason="end_turn")
        assert props == {
            "ai.usage.prompt_tokens": 10,
            "ai.usage.completion_tokens": 5,
            "bedrock.finish_reason": "end_turn",
        }

    def test_includes_cached_tokens(self):
        props = _build_token_properties(10, 5, cached_tokens=3)
        assert props["ai.usage.cached_tokens"] == 3

    def test_includes_cache_write_tokens(self):
        props = _build_token_properties(10, 5, cache_write_tokens=7)
        assert props["ai.usage.cache_write_tokens"] == 7

    def test_all_extended_fields(self):
        props = _build_token_properties(
            10, 5,
            stop_reason="max_tokens",
            cached_tokens=3,
            cache_write_tokens=7,
        )
        assert props == {
            "ai.usage.prompt_tokens": 10,
            "ai.usage.completion_tokens": 5,
            "bedrock.finish_reason": "max_tokens",
            "ai.usage.cached_tokens": 3,
            "ai.usage.cache_write_tokens": 7,
        }

    def test_stop_reason_alone_returns_props(self):
        props = _build_token_properties(None, None, stop_reason="end_turn")
        assert props == {"bedrock.finish_reason": "end_turn"}

    def test_cached_tokens_alone_returns_props(self):
        props = _build_token_properties(None, None, cached_tokens=5)
        assert props == {"ai.usage.cached_tokens": 5}


# ------------------------------------------------------------------
# Sync wrap tests
# ------------------------------------------------------------------


class TestWrapBedrockClient:
    """Test the client wrapping functionality."""

    def test_converse_call_tracked(self):
        fake_response = {
            "output": {"message": {"content": [{"text": "Paris"}]}},
            "usage": {"inputTokens": 12, "outputTokens": 8},
        }
        client = MagicMock()
        client.converse = MagicMock(return_value=fake_response)
        client._raindrop_wrapped = False

        with patch("raindrop_bedrock.wrapper.raindrop") as mock_raindrop:
            _wrap_bedrock_client(client, user_id="test-user", convo_id=None)
            result = client.converse(
                modelId="anthropic.claude-3-5-sonnet-20241022-v2:0",
                messages=[{"role": "user", "content": [{"text": "What is the capital of France?"}]}],
            )

            assert result == fake_response
            mock_raindrop.track_ai.assert_called_once()
            kwargs = mock_raindrop.track_ai.call_args.kwargs
            assert kwargs["user_id"] == "test-user"
            assert kwargs["model"] == "anthropic.claude-3-5-sonnet-20241022-v2:0"
            assert "capital of France" in kwargs["input"]
            assert kwargs["output"] == "Paris"
            assert kwargs["properties"]["ai.usage.prompt_tokens"] == 12
            assert kwargs["properties"]["ai.usage.completion_tokens"] == 8

    def test_invoke_model_call_tracked(self):
        response_body = json.dumps({
            "content": [{"type": "text", "text": "Hello!"}],
            "usage": {"input_tokens": 5, "output_tokens": 3},
        }).encode()
        client = MagicMock()
        client.invoke_model = MagicMock(return_value={"body": response_body})
        client._raindrop_wrapped = False

        with patch("raindrop_bedrock.wrapper.raindrop") as mock_raindrop:
            _wrap_bedrock_client(client, user_id="test-user", convo_id=None)
            result = client.invoke_model(
                modelId="anthropic.claude-3-5-sonnet-20241022-v2:0",
                body=json.dumps({"messages": [{"role": "user", "content": "Hi"}]}).encode(),
            )

            assert result["body"] == response_body
            mock_raindrop.track_ai.assert_called_once()
            kwargs = mock_raindrop.track_ai.call_args.kwargs
            assert kwargs["output"] == "Hello!"
            assert kwargs["properties"]["ai.usage.prompt_tokens"] == 5

    def test_converse_error_tracked_with_error_properties(self):
        client = MagicMock()
        client.converse = MagicMock(side_effect=RuntimeError("AccessDenied"))
        client._raindrop_wrapped = False

        with patch("raindrop_bedrock.wrapper.raindrop") as mock_raindrop:
            _wrap_bedrock_client(client, user_id="test-user", convo_id=None)
            with pytest.raises(RuntimeError, match="AccessDenied"):
                client.converse(
                    modelId="test-model",
                    messages=[{"role": "user", "content": [{"text": "Hello"}]}],
                )

            mock_raindrop.track_ai.assert_called_once()
            kwargs = mock_raindrop.track_ai.call_args.kwargs
            assert kwargs["model"] == "test-model"
            assert kwargs["properties"]["error.type"] == "RuntimeError"
            assert kwargs["properties"]["error.message"] == "AccessDenied"

    def test_invoke_model_error_tracked_with_error_properties(self):
        client = MagicMock()
        client.invoke_model = MagicMock(side_effect=RuntimeError("Throttled"))
        client._raindrop_wrapped = False

        with patch("raindrop_bedrock.wrapper.raindrop") as mock_raindrop:
            _wrap_bedrock_client(client, user_id="test-user", convo_id=None)
            with pytest.raises(RuntimeError, match="Throttled"):
                client.invoke_model(modelId="test-model", body=b'{}')

            mock_raindrop.track_ai.assert_called_once()
            kwargs = mock_raindrop.track_ai.call_args.kwargs
            assert kwargs["properties"]["error.type"] == "RuntimeError"
            assert kwargs["properties"]["error.message"] == "Throttled"

    def test_convo_id_forwarded(self):
        client = MagicMock()
        client.converse = MagicMock(return_value={
            "output": {"message": {"content": [{"text": "Ok"}]}},
            "usage": {},
        })
        client._raindrop_wrapped = False

        with patch("raindrop_bedrock.wrapper.raindrop") as mock_raindrop:
            _wrap_bedrock_client(client, user_id="test-user", convo_id="convo-123")
            client.converse(modelId="test-model", messages=[])

            kwargs = mock_raindrop.track_ai.call_args.kwargs
            assert kwargs["convo_id"] == "convo-123"

    def test_non_instrumented_methods_unchanged(self):
        client = MagicMock()
        client.list_foundation_models = MagicMock(return_value={"models": []})
        client._raindrop_wrapped = False

        with patch("raindrop_bedrock.wrapper.raindrop"):
            _wrap_bedrock_client(client, user_id="test-user", convo_id=None)
            result = client.list_foundation_models()
            assert result == {"models": []}


# ------------------------------------------------------------------
# Double-wrap guard tests
# ------------------------------------------------------------------


class TestDoubleWrapGuard:
    """Test that wrapping the same client twice is a no-op."""

    def test_double_wrap_is_noop(self):
        client = MagicMock()
        original_converse = MagicMock(return_value={
            "output": {"message": {"content": [{"text": "Ok"}]}},
            "usage": {},
        })
        client.converse = original_converse
        client._raindrop_wrapped = False

        with patch("raindrop_bedrock.wrapper.raindrop"):
            _wrap_bedrock_client(client, user_id="u1", convo_id=None)
            wrapped_converse = client.converse

            # Second wrap should be a no-op
            _wrap_bedrock_client(client, user_id="u2", convo_id=None)
            assert client.converse is wrapped_converse

    def test_double_wrap_guard_via_class(self):
        client = MagicMock()
        client.converse = MagicMock(return_value={
            "output": {"message": {"content": [{"text": "Ok"}]}},
            "usage": {},
        })
        client._raindrop_wrapped = False

        with patch("raindrop_bedrock.wrapper.raindrop"):
            rb = RaindropBedrock.__new__(RaindropBedrock)
            rb._user_id = "u1"
            rb._convo_id = None
            rb.wrap(client)
            first_converse = client.converse

            rb.wrap(client)
            assert client.converse is first_converse


# ------------------------------------------------------------------
# Class-based API tests
# ------------------------------------------------------------------


class TestRaindropBedrockClass:
    """Test the RaindropBedrock class API."""

    def test_init_calls_raindrop_init_with_tracing_flags(self):
        with patch("raindrop_bedrock.wrapper.raindrop") as mock_raindrop:
            RaindropBedrock(api_key="test-write-key")
            mock_raindrop.init.assert_called_once_with(
                api_key="test-write-key",
                tracing_enabled=True,
                bypass_otel_for_tools=True,
            )

    def test_debug_flag_sets_logger_level(self):
        with patch("raindrop_bedrock.wrapper.raindrop"):
            with patch("raindrop_bedrock.wrapper.logger") as mock_logger:
                RaindropBedrock(api_key="test-write-key", debug=True)
                mock_logger.setLevel.assert_called_once_with(logging.DEBUG)

    def test_debug_false_does_not_set_logger_level(self):
        with patch("raindrop_bedrock.wrapper.raindrop"):
            with patch("raindrop_bedrock.wrapper.logger") as mock_logger:
                RaindropBedrock(api_key="test-write-key", debug=False)
                mock_logger.setLevel.assert_not_called()

    def test_init_warns_on_empty_api_key(self):
        with patch("raindrop_bedrock.wrapper.raindrop"):
            with warnings.catch_warnings(record=True) as w:
                warnings.simplefilter("always")
                RaindropBedrock(api_key="")
                assert len(w) == 1
                assert "api_key not provided" in str(w[0].message)

    def test_init_warns_on_none_api_key(self):
        with patch("raindrop_bedrock.wrapper.raindrop"):
            with warnings.catch_warnings(record=True) as w:
                warnings.simplefilter("always")
                RaindropBedrock(api_key=None)
                assert len(w) == 1
                assert "api_key not provided" in str(w[0].message)

    def test_init_no_warning_when_api_key_provided(self):
        with patch("raindrop_bedrock.wrapper.raindrop"):
            with warnings.catch_warnings(record=True) as w:
                warnings.simplefilter("always")
                RaindropBedrock(api_key="valid-key")
                assert len(w) == 0

    def test_user_id_defaults_to_unknown(self):
        with patch("raindrop_bedrock.wrapper.raindrop"):
            rb = RaindropBedrock(api_key="test-write-key")
            assert rb._user_id == "unknown"

    def test_user_id_set_when_provided(self):
        with patch("raindrop_bedrock.wrapper.raindrop"):
            rb = RaindropBedrock(api_key="test-write-key", user_id="user-1")
            assert rb._user_id == "user-1"

    def test_user_id_none_falls_back_to_unknown(self):
        with patch("raindrop_bedrock.wrapper.raindrop"):
            rb = RaindropBedrock(api_key="test-write-key", user_id=None)
            assert rb._user_id == "unknown"

    def test_flush_calls_raindrop_flush(self):
        with patch("raindrop_bedrock.wrapper.raindrop") as mock_raindrop:
            rb = RaindropBedrock(api_key="test-write-key")
            rb.flush()
            mock_raindrop.flush.assert_called_once()

    def test_shutdown_calls_raindrop_shutdown(self):
        with patch("raindrop_bedrock.wrapper.raindrop") as mock_raindrop:
            rb = RaindropBedrock(api_key="test-write-key")
            rb.shutdown()
            mock_raindrop.shutdown.assert_called_once()

    def test_identify_passes_through(self):
        with patch("raindrop_bedrock.wrapper.raindrop") as mock_raindrop:
            rb = RaindropBedrock(api_key="test-write-key")
            rb.identify(user_id="u1", traits={"name": "Alice"})
            mock_raindrop.identify.assert_called_once_with(
                user_id="u1", traits={"name": "Alice"},
            )

    def test_identify_with_traits_none(self):
        with patch("raindrop_bedrock.wrapper.raindrop") as mock_raindrop:
            rb = RaindropBedrock(api_key="test-write-key")
            rb.identify(user_id="u1")
            mock_raindrop.identify.assert_called_once_with(
                user_id="u1", traits={},
            )

    def test_identify_with_traits_default(self):
        with patch("raindrop_bedrock.wrapper.raindrop") as mock_raindrop:
            rb = RaindropBedrock(api_key="test-write-key")
            rb.identify(user_id="u1", traits=None)
            mock_raindrop.identify.assert_called_once_with(
                user_id="u1", traits={},
            )

    def test_track_signal_passes_through(self):
        with patch("raindrop_bedrock.wrapper.raindrop") as mock_raindrop:
            rb = RaindropBedrock(api_key="test-write-key")
            rb.track_signal(event_id="e1", name="thumbs_up", signal_type="feedback")
            mock_raindrop.track_signal.assert_called_once_with(
                event_id="e1",
                name="thumbs_up",
                signal_type="feedback",
                timestamp=None,
                properties=None,
                attachment_id=None,
                comment=None,
                after=None,
                sentiment=None,
            )

    def test_wrap_instruments_client(self):
        client = MagicMock()
        client.converse = MagicMock(return_value={
            "output": {"message": {"content": [{"text": "Hi"}]}},
            "usage": {"inputTokens": 1, "outputTokens": 1},
        })
        client._raindrop_wrapped = False

        with patch("raindrop_bedrock.wrapper.raindrop") as mock_raindrop:
            rb = RaindropBedrock(api_key="test-write-key", user_id="user-1")
            rb.wrap(client)
            client.converse(modelId="test-model", messages=[])

            mock_raindrop.track_ai.assert_called_once()

    def test_getitem_backward_compat(self):
        with patch("raindrop_bedrock.wrapper.raindrop"):
            rb = RaindropBedrock(api_key="test-write-key")
            with warnings.catch_warnings(record=True) as w:
                warnings.simplefilter("always")
                assert callable(rb["wrap"])
                assert callable(rb["flush"])
                assert callable(rb["shutdown"])
                assert len(w) == 3
                assert all(issubclass(x.category, DeprecationWarning) for x in w)

    def test_getitem_raises_key_error(self):
        with patch("raindrop_bedrock.wrapper.raindrop"):
            rb = RaindropBedrock(api_key="test-write-key")
            with pytest.raises(KeyError):
                rb["nonexistent"]

    def test_init_passes_api_key_or_empty_to_raindrop(self):
        with patch("raindrop_bedrock.wrapper.raindrop") as mock_raindrop:
            RaindropBedrock(api_key=None)
            mock_raindrop.init.assert_called_once_with(
                api_key="",
                tracing_enabled=True,
                bypass_otel_for_tools=True,
            )

    def test_tracing_flags_pass_through(self):
        with patch("raindrop_bedrock.wrapper.raindrop") as mock_raindrop:
            RaindropBedrock(
                api_key="key",
                tracing_enabled=False,
                bypass_otel_for_tools=False,
            )
            mock_raindrop.init.assert_called_once_with(
                api_key="key",
                tracing_enabled=False,
                bypass_otel_for_tools=False,
            )


# ------------------------------------------------------------------
# Factory function tests (backwards compatibility)
# ------------------------------------------------------------------


class TestFactory:
    """Test the create_raindrop_bedrock factory."""

    def test_factory_returns_raindrop_bedrock_instance(self):
        with patch("raindrop_bedrock.wrapper.raindrop") as mock_raindrop:
            result = create_raindrop_bedrock(api_key="test-write-key", user_id="user-1")

            assert isinstance(result, RaindropBedrock)
            # Factory preserves old SDK defaults (tracing_enabled=False)
            mock_raindrop.init.assert_called_once_with(
                api_key="test-write-key",
                tracing_enabled=False,
                bypass_otel_for_tools=False,
            )

    def test_dict_style_access_backward_compat(self):
        """Ensure raindrop['wrap'], raindrop['flush'], raindrop['shutdown'] still work."""
        with patch("raindrop_bedrock.wrapper.raindrop"):
            rd = create_raindrop_bedrock(api_key="test-write-key")
            with warnings.catch_warnings(record=True):
                warnings.simplefilter("always")
                assert callable(rd["wrap"])
                assert callable(rd["flush"])
                assert callable(rd["shutdown"])
            with pytest.raises(KeyError):
                rd["nonexistent"]

    def test_factory_with_tracing_flags(self):
        with patch("raindrop_bedrock.wrapper.raindrop") as mock_raindrop:
            create_raindrop_bedrock(
                api_key="key",
                tracing_enabled=True,
                bypass_otel_for_tools=True,
            )
            mock_raindrop.init.assert_called_once_with(
                api_key="key",
                tracing_enabled=True,
                bypass_otel_for_tools=True,
            )

    def test_factory_wrap_instruments_client(self):
        client = MagicMock()
        client.converse = MagicMock(return_value={
            "output": {"message": {"content": [{"text": "Hi"}]}},
            "usage": {"inputTokens": 1, "outputTokens": 1},
        })
        client._raindrop_wrapped = False

        with patch("raindrop_bedrock.wrapper.raindrop") as mock_raindrop:
            rd = create_raindrop_bedrock(api_key="test-write-key", user_id="user-1")
            rd.wrap(client)
            client.converse(modelId="test-model", messages=[])

            mock_raindrop.track_ai.assert_called_once()

    def test_factory_with_convo_id(self):
        client = MagicMock()
        client.converse = MagicMock(return_value={
            "output": {"message": {"content": [{"text": "Ok"}]}},
            "usage": {},
        })
        client._raindrop_wrapped = False

        with patch("raindrop_bedrock.wrapper.raindrop") as mock_raindrop:
            rd = create_raindrop_bedrock(api_key="test-write-key", user_id="u1", convo_id="c1")
            rd.wrap(client)
            client.converse(modelId="m", messages=[])

            kwargs = mock_raindrop.track_ai.call_args.kwargs
            assert kwargs["convo_id"] == "c1"

    def test_multiple_calls_no_leak(self):
        client = MagicMock()
        client.converse = MagicMock(return_value={
            "output": {"message": {"content": [{"text": "Ok"}]}},
            "usage": {},
        })
        client._raindrop_wrapped = False

        with patch("raindrop_bedrock.wrapper.raindrop") as mock_raindrop:
            rd = create_raindrop_bedrock(api_key="test-write-key", user_id="u1")
            rd.wrap(client)

            for _ in range(10):
                client.converse(modelId="m", messages=[])

            assert mock_raindrop.track_ai.call_count == 10


# ------------------------------------------------------------------
# Async wrap tests
# ------------------------------------------------------------------


class TestAsyncWrap:
    """Test async client wrapping."""

    def test_async_converse_tracked(self):
        fake_response = {
            "output": {"message": {"content": [{"text": "Paris"}]}},
            "usage": {"inputTokens": 12, "outputTokens": 8},
        }

        async def fake_converse(**kwargs):
            return fake_response

        client = MagicMock()
        client.converse = fake_converse
        client.invoke_model = None
        client._raindrop_wrapped = False

        with patch("raindrop_bedrock.wrapper.raindrop") as mock_raindrop:
            rb = RaindropBedrock.__new__(RaindropBedrock)
            rb._user_id = "test-user"
            rb._convo_id = None
            rb.async_wrap(client)

            result = asyncio.run(client.converse(
                modelId="anthropic.claude-3-5-sonnet-20241022-v2:0",
                messages=[{"role": "user", "content": [{"text": "What is the capital of France?"}]}],
            ))

            assert result == fake_response
            mock_raindrop.track_ai.assert_called_once()
            kwargs = mock_raindrop.track_ai.call_args.kwargs
            assert kwargs["user_id"] == "test-user"
            assert kwargs["output"] == "Paris"

    def test_async_invoke_model_tracked(self):
        body_data = json.dumps({
            "content": [{"type": "text", "text": "Hello!"}],
            "usage": {"input_tokens": 5, "output_tokens": 3},
        }).encode()

        class FakeAsyncStreamingBody:
            """Simulates aioboto3 AioStreamingBody with async read()."""

            async def read(self):
                return body_data

        async def fake_invoke_model(**kwargs):
            return {"body": FakeAsyncStreamingBody()}

        client = MagicMock()
        client.converse = None
        client.invoke_model = fake_invoke_model
        client._raindrop_wrapped = False

        with patch("raindrop_bedrock.wrapper.raindrop") as mock_raindrop:
            rb = RaindropBedrock.__new__(RaindropBedrock)
            rb._user_id = "test-user"
            rb._convo_id = None
            rb.async_wrap(client)

            result = asyncio.run(client.invoke_model(
                modelId="test-model",
                body=b'{}',
            ))

            # Body should be replaced with an async-compatible wrapper
            assert asyncio.run(result["body"].read()) == body_data
            mock_raindrop.track_ai.assert_called_once()
            kwargs = mock_raindrop.track_ai.call_args.kwargs
            assert kwargs["output"] == "Hello!"
            assert kwargs["properties"]["ai.usage.prompt_tokens"] == 5
            assert kwargs["properties"]["ai.usage.completion_tokens"] == 3

    def test_async_error_tracked(self):
        async def fake_converse(**kwargs):
            raise RuntimeError("Throttled")

        client = MagicMock()
        client.converse = fake_converse
        client.invoke_model = None
        client._raindrop_wrapped = False

        with patch("raindrop_bedrock.wrapper.raindrop") as mock_raindrop:
            rb = RaindropBedrock.__new__(RaindropBedrock)
            rb._user_id = "test-user"
            rb._convo_id = None
            rb.async_wrap(client)

            with pytest.raises(RuntimeError, match="Throttled"):
                asyncio.run(client.converse(modelId="test-model", messages=[]))

            mock_raindrop.track_ai.assert_called_once()
            kwargs = mock_raindrop.track_ai.call_args.kwargs
            assert kwargs["properties"]["error.type"] == "RuntimeError"
            assert kwargs["properties"]["error.message"] == "Throttled"

    def test_async_double_wrap_is_noop(self):
        async def fake_converse(**kwargs):
            return {"output": {"message": {"content": [{"text": "Ok"}]}}, "usage": {}}

        client = MagicMock()
        client.converse = fake_converse
        client.invoke_model = None
        client._raindrop_wrapped = False

        with patch("raindrop_bedrock.wrapper.raindrop"):
            rb = RaindropBedrock.__new__(RaindropBedrock)
            rb._user_id = "u1"
            rb._convo_id = None
            rb.async_wrap(client)
            first_converse = client.converse

            rb.async_wrap(client)
            assert client.converse is first_converse


# ------------------------------------------------------------------
# Version test
# ------------------------------------------------------------------


class TestVersion:
    """Test that __version__ is exported."""

    def test_version_exported(self):
        from raindrop_bedrock import __version__
        assert isinstance(__version__, str)
        assert __version__ == "0.0.3"


# ------------------------------------------------------------------
# Converse stop_reason and extended tokens tests
# ------------------------------------------------------------------


class TestConverseStopReasonAndExtendedTokens:
    """Test that stop_reason and extended token categories are captured in converse()."""

    def test_converse_captures_stop_reason(self):
        fake_response = {
            "output": {"message": {"content": [{"text": "Paris"}]}},
            "usage": {"inputTokens": 12, "outputTokens": 8},
            "stopReason": "end_turn",
        }
        client = MagicMock()
        client.converse = MagicMock(return_value=fake_response)
        client._raindrop_wrapped = False

        with patch("raindrop_bedrock.wrapper.raindrop") as mock_raindrop:
            _wrap_bedrock_client(client, user_id="test-user", convo_id=None)
            client.converse(
                modelId="anthropic.claude-3-5-sonnet-20241022-v2:0",
                messages=[{"role": "user", "content": [{"text": "What is the capital of France?"}]}],
            )

            kwargs = mock_raindrop.track_ai.call_args.kwargs
            assert kwargs["properties"]["bedrock.finish_reason"] == "end_turn"

    def test_converse_captures_tool_use_stop_reason(self):
        fake_response = {
            "output": {"message": {"content": [{"text": "Calling tool..."}]}},
            "usage": {"inputTokens": 20, "outputTokens": 15},
            "stopReason": "tool_use",
        }
        client = MagicMock()
        client.converse = MagicMock(return_value=fake_response)
        client._raindrop_wrapped = False

        with patch("raindrop_bedrock.wrapper.raindrop") as mock_raindrop:
            _wrap_bedrock_client(client, user_id="test-user", convo_id=None)
            client.converse(modelId="test-model", messages=[])

            kwargs = mock_raindrop.track_ai.call_args.kwargs
            assert kwargs["properties"]["bedrock.finish_reason"] == "tool_use"

    def test_converse_captures_max_tokens_stop_reason(self):
        fake_response = {
            "output": {"message": {"content": [{"text": "Truncated..."}]}},
            "usage": {"inputTokens": 10, "outputTokens": 100},
            "stopReason": "max_tokens",
        }
        client = MagicMock()
        client.converse = MagicMock(return_value=fake_response)
        client._raindrop_wrapped = False

        with patch("raindrop_bedrock.wrapper.raindrop") as mock_raindrop:
            _wrap_bedrock_client(client, user_id="test-user", convo_id=None)
            client.converse(modelId="test-model", messages=[])

            kwargs = mock_raindrop.track_ai.call_args.kwargs
            assert kwargs["properties"]["bedrock.finish_reason"] == "max_tokens"

    def test_converse_captures_cached_tokens(self):
        fake_response = {
            "output": {"message": {"content": [{"text": "Cached response"}]}},
            "usage": {
                "inputTokens": 100,
                "outputTokens": 20,
                "cacheReadInputTokenCount": 80,
            },
            "stopReason": "end_turn",
        }
        client = MagicMock()
        client.converse = MagicMock(return_value=fake_response)
        client._raindrop_wrapped = False

        with patch("raindrop_bedrock.wrapper.raindrop") as mock_raindrop:
            _wrap_bedrock_client(client, user_id="test-user", convo_id=None)
            client.converse(modelId="test-model", messages=[])

            kwargs = mock_raindrop.track_ai.call_args.kwargs
            assert kwargs["properties"]["ai.usage.cached_tokens"] == 80

    def test_converse_captures_cache_write_tokens(self):
        fake_response = {
            "output": {"message": {"content": [{"text": "Response"}]}},
            "usage": {
                "inputTokens": 100,
                "outputTokens": 20,
                "cacheWriteInputTokenCount": 50,
            },
            "stopReason": "end_turn",
        }
        client = MagicMock()
        client.converse = MagicMock(return_value=fake_response)
        client._raindrop_wrapped = False

        with patch("raindrop_bedrock.wrapper.raindrop") as mock_raindrop:
            _wrap_bedrock_client(client, user_id="test-user", convo_id=None)
            client.converse(modelId="test-model", messages=[])

            kwargs = mock_raindrop.track_ai.call_args.kwargs
            assert kwargs["properties"]["ai.usage.cache_write_tokens"] == 50

    def test_converse_all_extended_fields(self):
        fake_response = {
            "output": {"message": {"content": [{"text": "Full response"}]}},
            "usage": {
                "inputTokens": 100,
                "outputTokens": 20,
                "cacheReadInputTokenCount": 80,
                "cacheWriteInputTokenCount": 15,
            },
            "stopReason": "end_turn",
        }
        client = MagicMock()
        client.converse = MagicMock(return_value=fake_response)
        client._raindrop_wrapped = False

        with patch("raindrop_bedrock.wrapper.raindrop") as mock_raindrop:
            _wrap_bedrock_client(client, user_id="test-user", convo_id=None)
            client.converse(modelId="test-model", messages=[])

            props = mock_raindrop.track_ai.call_args.kwargs["properties"]
            assert props["ai.usage.prompt_tokens"] == 100
            assert props["ai.usage.completion_tokens"] == 20
            assert props["bedrock.finish_reason"] == "end_turn"
            assert props["ai.usage.cached_tokens"] == 80
            assert props["ai.usage.cache_write_tokens"] == 15

    def test_converse_no_stop_reason_omitted(self):
        """When stopReason is absent, bedrock.finish_reason should not be in properties."""
        fake_response = {
            "output": {"message": {"content": [{"text": "Ok"}]}},
            "usage": {"inputTokens": 5, "outputTokens": 3},
        }
        client = MagicMock()
        client.converse = MagicMock(return_value=fake_response)
        client._raindrop_wrapped = False

        with patch("raindrop_bedrock.wrapper.raindrop") as mock_raindrop:
            _wrap_bedrock_client(client, user_id="test-user", convo_id=None)
            client.converse(modelId="test-model", messages=[])

            props = mock_raindrop.track_ai.call_args.kwargs["properties"]
            assert "bedrock.finish_reason" not in props
            assert "ai.usage.cached_tokens" not in props
            assert "ai.usage.cache_write_tokens" not in props


# ------------------------------------------------------------------
# InvokeModel stop_reason and cached tokens tests
# ------------------------------------------------------------------


class TestInvokeModelStopReasonAndCachedTokens:
    """Test that stop_reason and cached tokens are captured in invoke_model()."""

    def test_invoke_model_claude_stop_reason(self):
        response_body = json.dumps({
            "content": [{"type": "text", "text": "Hello!"}],
            "usage": {"input_tokens": 5, "output_tokens": 3},
            "stop_reason": "end_turn",
        }).encode()
        client = MagicMock()
        client.invoke_model = MagicMock(return_value={"body": response_body})
        client._raindrop_wrapped = False

        with patch("raindrop_bedrock.wrapper.raindrop") as mock_raindrop:
            _wrap_bedrock_client(client, user_id="test-user", convo_id=None)
            client.invoke_model(modelId="anthropic.claude-3-5-sonnet-20241022-v2:0", body=b'{}')

            props = mock_raindrop.track_ai.call_args.kwargs["properties"]
            assert props["bedrock.finish_reason"] == "end_turn"

    def test_invoke_model_claude_cached_tokens(self):
        response_body = json.dumps({
            "content": [{"type": "text", "text": "Hello!"}],
            "usage": {
                "input_tokens": 10,
                "output_tokens": 5,
                "cache_read_input_tokens": 7,
            },
            "stop_reason": "end_turn",
        }).encode()
        client = MagicMock()
        client.invoke_model = MagicMock(return_value={"body": response_body})
        client._raindrop_wrapped = False

        with patch("raindrop_bedrock.wrapper.raindrop") as mock_raindrop:
            _wrap_bedrock_client(client, user_id="test-user", convo_id=None)
            client.invoke_model(modelId="anthropic.claude-3-5-sonnet-20241022-v2:0", body=b'{}')

            props = mock_raindrop.track_ai.call_args.kwargs["properties"]
            assert props["ai.usage.cached_tokens"] == 7

    def test_invoke_model_llama_stop_reason(self):
        response_body = json.dumps({
            "generation": "Hello from Llama!",
            "prompt_token_count": 6,
            "generation_token_count": 4,
            "stop_reason": "stop",
        }).encode()
        client = MagicMock()
        client.invoke_model = MagicMock(return_value={"body": response_body})
        client._raindrop_wrapped = False

        with patch("raindrop_bedrock.wrapper.raindrop") as mock_raindrop:
            _wrap_bedrock_client(client, user_id="test-user", convo_id=None)
            client.invoke_model(modelId="meta.llama3-8b-instruct-v1:0", body=b'{}')

            props = mock_raindrop.track_ai.call_args.kwargs["properties"]
            assert props["bedrock.finish_reason"] == "stop"

    def test_invoke_model_titan_no_stop_reason(self):
        """Titan format doesn't include stop_reason."""
        response_body = json.dumps({
            "inputTextTokenCount": 8,
            "results": [{"tokenCount": 12, "outputText": "Hello from Titan!"}],
        }).encode()
        client = MagicMock()
        client.invoke_model = MagicMock(return_value={"body": response_body})
        client._raindrop_wrapped = False

        with patch("raindrop_bedrock.wrapper.raindrop") as mock_raindrop:
            _wrap_bedrock_client(client, user_id="test-user", convo_id=None)
            client.invoke_model(modelId="amazon.titan-text-lite-v1", body=b'{}')

            props = mock_raindrop.track_ai.call_args.kwargs["properties"]
            assert "bedrock.finish_reason" not in props


# ------------------------------------------------------------------
# _extract_parsed_invoke_fields direct tests
# ------------------------------------------------------------------


class TestExtractParsedInvokeFields:
    """Test _extract_parsed_invoke_fields for all model formats."""

    def test_claude_full(self):
        parsed = {
            "content": [{"type": "text", "text": "Hi"}],
            "usage": {
                "input_tokens": 10,
                "output_tokens": 5,
                "cache_read_input_tokens": 3,
            },
            "stop_reason": "end_turn",
        }
        output, pt, ct, sr, cached = _extract_parsed_invoke_fields(parsed)
        assert output == "Hi"
        assert pt == 10
        assert ct == 5
        assert sr == "end_turn"
        assert cached == 3

    def test_claude_no_cache(self):
        parsed = {
            "content": [{"type": "text", "text": "Hi"}],
            "usage": {"input_tokens": 10, "output_tokens": 5},
        }
        output, pt, ct, sr, cached = _extract_parsed_invoke_fields(parsed)
        assert cached is None
        assert sr is None

    def test_titan(self):
        parsed = {
            "inputTextTokenCount": 8,
            "results": [{"tokenCount": 12, "outputText": "Titan response"}],
        }
        output, pt, ct, sr, cached = _extract_parsed_invoke_fields(parsed)
        assert output == "Titan response"
        assert sr is None
        assert cached is None

    def test_llama_with_stop(self):
        parsed = {
            "generation": "Llama says hi",
            "prompt_token_count": 6,
            "generation_token_count": 4,
            "stop_reason": "length",
        }
        output, pt, ct, sr, cached = _extract_parsed_invoke_fields(parsed)
        assert output == "Llama says hi"
        assert sr == "length"
        assert cached is None

    def test_fallback(self):
        parsed = {"completion": "Some completion"}
        output, pt, ct, sr, cached = _extract_parsed_invoke_fields(parsed)
        assert output == "Some completion"
        assert pt is None
        assert ct is None
        assert sr is None
        assert cached is None


# ------------------------------------------------------------------
# Async converse extended fields tests
# ------------------------------------------------------------------


class TestAsyncConverseExtendedFields:
    """Test that async converse captures stop_reason and cache tokens."""

    def test_async_converse_captures_stop_reason_and_cache(self):
        fake_response = {
            "output": {"message": {"content": [{"text": "Paris"}]}},
            "usage": {
                "inputTokens": 12,
                "outputTokens": 8,
                "cacheReadInputTokenCount": 5,
                "cacheWriteInputTokenCount": 2,
            },
            "stopReason": "end_turn",
        }

        async def fake_converse(**kwargs):
            return fake_response

        client = MagicMock()
        client.converse = fake_converse
        client.invoke_model = None
        client._raindrop_wrapped = False

        with patch("raindrop_bedrock.wrapper.raindrop") as mock_raindrop:
            rb = RaindropBedrock.__new__(RaindropBedrock)
            rb._user_id = "test-user"
            rb._convo_id = None
            rb.async_wrap(client)

            asyncio.run(client.converse(
                modelId="test-model",
                messages=[{"role": "user", "content": [{"text": "Question"}]}],
            ))

            props = mock_raindrop.track_ai.call_args.kwargs["properties"]
            assert props["bedrock.finish_reason"] == "end_turn"
            assert props["ai.usage.cached_tokens"] == 5
            assert props["ai.usage.cache_write_tokens"] == 2


# ------------------------------------------------------------------
# Async invoke_model extended fields tests
# ------------------------------------------------------------------


class TestAsyncInvokeModelExtendedFields:
    """Test that async invoke_model captures stop_reason and cached tokens."""

    def test_async_invoke_model_captures_stop_reason_and_cache(self):
        body_data = json.dumps({
            "content": [{"type": "text", "text": "Hello!"}],
            "usage": {
                "input_tokens": 5,
                "output_tokens": 3,
                "cache_read_input_tokens": 2,
            },
            "stop_reason": "end_turn",
        }).encode()

        class FakeAsyncStreamingBody:
            async def read(self):
                return body_data

        async def fake_invoke_model(**kwargs):
            return {"body": FakeAsyncStreamingBody()}

        client = MagicMock()
        client.converse = None
        client.invoke_model = fake_invoke_model
        client._raindrop_wrapped = False

        with patch("raindrop_bedrock.wrapper.raindrop") as mock_raindrop:
            rb = RaindropBedrock.__new__(RaindropBedrock)
            rb._user_id = "test-user"
            rb._convo_id = None
            rb.async_wrap(client)

            asyncio.run(client.invoke_model(modelId="test-model", body=b'{}'))

            props = mock_raindrop.track_ai.call_args.kwargs["properties"]
            assert props["bedrock.finish_reason"] == "end_turn"
            assert props["ai.usage.cached_tokens"] == 2


# ------------------------------------------------------------------
# Edge case tests
# ------------------------------------------------------------------


class TestEdgeCases:
    """Test edge cases and boundary conditions."""

    def test_converse_empty_usage_dict(self):
        """Empty usage dict should produce None properties (no token fields)."""
        fake_response = {
            "output": {"message": {"content": [{"text": "Ok"}]}},
            "usage": {},
        }
        client = MagicMock()
        client.converse = MagicMock(return_value=fake_response)
        client._raindrop_wrapped = False

        with patch("raindrop_bedrock.wrapper.raindrop") as mock_raindrop:
            _wrap_bedrock_client(client, user_id="test-user", convo_id=None)
            client.converse(modelId="test-model", messages=[])

            kwargs = mock_raindrop.track_ai.call_args.kwargs
            assert kwargs["properties"] is None

    def test_converse_missing_usage(self):
        """Missing usage entirely should still track the event."""
        fake_response = {
            "output": {"message": {"content": [{"text": "Ok"}]}},
        }
        client = MagicMock()
        client.converse = MagicMock(return_value=fake_response)
        client._raindrop_wrapped = False

        with patch("raindrop_bedrock.wrapper.raindrop") as mock_raindrop:
            _wrap_bedrock_client(client, user_id="test-user", convo_id=None)
            client.converse(modelId="test-model", messages=[])

            mock_raindrop.track_ai.assert_called_once()

    def test_invoke_model_fallback_format_no_extended_fields(self):
        """Fallback format should return None for stop_reason and cached_tokens."""
        body = json.dumps({"output": "Some output"}).encode()
        response = {"body": body}
        output, pt, ct, sr, cached = _parse_invoke_response(response)
        assert output == "Some output"
        assert sr is None
        assert cached is None

    def test_converse_zero_cached_tokens(self):
        """Zero cached tokens should still be included in properties."""
        fake_response = {
            "output": {"message": {"content": [{"text": "Ok"}]}},
            "usage": {
                "inputTokens": 10,
                "outputTokens": 5,
                "cacheReadInputTokenCount": 0,
            },
        }
        client = MagicMock()
        client.converse = MagicMock(return_value=fake_response)
        client._raindrop_wrapped = False

        with patch("raindrop_bedrock.wrapper.raindrop") as mock_raindrop:
            _wrap_bedrock_client(client, user_id="test-user", convo_id=None)
            client.converse(modelId="test-model", messages=[])

            props = mock_raindrop.track_ai.call_args.kwargs["properties"]
            assert props["ai.usage.cached_tokens"] == 0
