"""
AWS Bedrock client wrapper for Raindrop observability.

Wraps a boto3 bedrock-runtime client to automatically capture
converse() and invoke_model() calls and ship them to Raindrop.

Usage:
    from raindrop_bedrock import RaindropBedrock

    rb = RaindropBedrock(api_key="your-write-key")
    bedrock = boto3.client("bedrock-runtime", region_name="us-east-1")
    rb.wrap(bedrock)

    response = bedrock.converse(modelId="anthropic.claude-3-5-sonnet-20241022-v2:0", ...)
    rb.flush()
"""

from __future__ import annotations

import inspect
import io
import json
import logging
import uuid
import warnings
from typing import TYPE_CHECKING, Any, Dict, Literal, Optional, Union

import raindrop.analytics as raindrop

if TYPE_CHECKING:
    from mypy_boto3_bedrock_runtime import BedrockRuntimeClient

logger = logging.getLogger(__name__)


class RaindropBedrock:
    """Raindrop instrumentation wrapper for AWS Bedrock clients.

    Provides methods to wrap boto3 bedrock-runtime clients, forwarding
    telemetry (inputs, outputs, token usage, errors) to Raindrop.

    Args:
        api_key: Raindrop API key. When empty or ``None``, a warning is
            emitted and telemetry shipping is disabled.
        user_id: Default user ID for all tracked events. Falls back to
            ``"unknown"`` when not provided.
        convo_id: Optional conversation ID to group related events.
        tracing_enabled: Pass ``True`` (default) to enable Raindrop tracing.
        bypass_otel_for_tools: Pass ``True`` (default) to bypass OpenTelemetry
            for tool-level instrumentation.
        debug: When ``True``, sets the module logger to ``DEBUG`` level for
            verbose diagnostic output.
    """

    def __init__(
        self,
        api_key: Optional[str] = None,
        user_id: Optional[str] = None,
        convo_id: Optional[str] = None,
        tracing_enabled: bool = True,
        bypass_otel_for_tools: bool = True,
        debug: bool = False,
    ) -> None:
        if not api_key:
            warnings.warn(
                "[raindrop-bedrock] api_key not provided; telemetry shipping is disabled",
                stacklevel=2,
            )
        if debug:
            logger.setLevel(logging.DEBUG)
        raindrop.init(
            api_key=api_key or "",
            tracing_enabled=tracing_enabled,
            bypass_otel_for_tools=bypass_otel_for_tools,
        )
        self._user_id = user_id or "unknown"
        self._convo_id = convo_id

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def wrap(self, client: "BedrockRuntimeClient") -> "BedrockRuntimeClient":
        """Instrument a boto3 bedrock-runtime client (sync).

        Monkey-patches ``converse`` and ``invoke_model`` to capture
        telemetry. Returns the same client instance for convenience.

        A ``_raindrop_wrapped`` attribute is set on the client to prevent
        double instrumentation.
        """
        try:
            return _wrap_bedrock_client(
                client,
                user_id=self._user_id,
                convo_id=self._convo_id,
            )
        except Exception:
            logger.debug("Failed to wrap bedrock client", exc_info=True)
            return client

    def async_wrap(self, client: Any) -> Any:
        """Instrument an aioboto3 bedrock-runtime async client.

        Monkey-patches the async ``converse`` and ``invoke_model`` methods.
        Requires the ``async`` extra (``pip install raindrop-bedrock[async]``).

        A ``_raindrop_wrapped`` attribute is set on the client to prevent
        double instrumentation.
        """
        try:
            return _wrap_async_bedrock_client(
                client,
                user_id=self._user_id,
                convo_id=self._convo_id,
            )
        except Exception:
            logger.debug("Failed to wrap async bedrock client", exc_info=True)
            return client

    def identify(
        self,
        user_id: str,
        traits: Optional[Dict[str, Union[str, int, bool, float]]] = None,
    ) -> None:
        """Identify a user with optional traits.

        Args:
            user_id: The user identifier.
            traits: Optional dictionary of user traits.
        """
        try:
            raindrop.identify(user_id=user_id, traits=traits or {})
        except Exception:
            logger.debug("Failed to identify user", exc_info=True)

    def track_signal(
        self,
        event_id: str,
        name: str,
        signal_type: Literal["default", "feedback", "edit"] = "default",
        *,
        timestamp: Optional[str] = None,
        properties: Optional[Dict[str, object]] = None,
        attachment_id: Optional[str] = None,
        comment: Optional[str] = None,
        after: Optional[str] = None,
        sentiment: Optional[Literal["POSITIVE", "NEGATIVE"]] = None,
    ) -> None:
        """Track a signal event.

        Args:
            event_id: The event ID to associate the signal with.
            name: Signal name.
            signal_type: One of "default", "feedback", or "edit".
            timestamp: Optional ISO-8601 timestamp string.
            properties: Optional extra properties dict.
            attachment_id: Optional attachment identifier.
            comment: Optional comment text.
            after: Optional "after" value for edit signals.
            sentiment: Optional sentiment ("POSITIVE" or "NEGATIVE").
        """
        try:
            raindrop.track_signal(
                event_id=event_id,
                name=name,
                signal_type=signal_type,
                timestamp=timestamp,
                properties=properties,
                attachment_id=attachment_id,
                comment=comment,
                after=after,
                sentiment=sentiment,
            )
        except Exception:
            logger.debug("Failed to track signal", exc_info=True)

    def flush(self) -> None:
        """Flush any pending telemetry events."""
        try:
            raindrop.flush()
        except Exception:
            logger.debug("Failed to flush events", exc_info=True)

    def shutdown(self) -> None:
        """Flush pending events and release resources."""
        try:
            raindrop.shutdown()
        except Exception:
            logger.debug("Failed to shutdown", exc_info=True)

    # ------------------------------------------------------------------
    # Backward-compatible dict-style access
    # ------------------------------------------------------------------

    def __getitem__(self, key: str) -> Any:
        """Support dict-style access for backwards compatibility.

        .. deprecated::
            Use attribute access instead.
        """
        _COMPAT_MAP = {"wrap": "wrap", "flush": "flush", "shutdown": "shutdown"}
        if key in _COMPAT_MAP:
            warnings.warn(
                f'raindrop["{key}"] is deprecated — use raindrop.{key} instead',
                DeprecationWarning,
                stacklevel=2,
            )
            return getattr(self, key)
        raise KeyError(key)


def create_raindrop_bedrock(
    api_key: Optional[str] = None,
    user_id: Optional[str] = None,
    convo_id: Optional[str] = None,
    tracing_enabled: bool = False,
    bypass_otel_for_tools: bool = False,
) -> RaindropBedrock:
    """Factory that returns a :class:`RaindropBedrock` instance.

    Kept for backwards compatibility. Prefer instantiating
    :class:`RaindropBedrock` directly.

    Note: The factory preserves the old SDK defaults where
    ``tracing_enabled`` and ``bypass_otel_for_tools`` default to
    ``False`` (the class defaults to ``True``).

    Args:
        api_key: Raindrop API key.
        user_id: Associate all events with this user.
        convo_id: Conversation ID to group related events.
        tracing_enabled: Enable Raindrop tracing (default ``False``).
        bypass_otel_for_tools: Bypass OpenTelemetry for tools (default ``False``).

    Returns:
        A :class:`RaindropBedrock` instance.

    Usage::

        raindrop = create_raindrop_bedrock(api_key="your-write-key")
        bedrock = boto3.client("bedrock-runtime", region_name="us-east-1")
        raindrop.wrap(bedrock)
        response = bedrock.converse(modelId="...", messages=[...])
        raindrop.flush()
    """
    return RaindropBedrock(
        api_key=api_key,
        user_id=user_id,
        convo_id=convo_id,
        tracing_enabled=tracing_enabled,
        bypass_otel_for_tools=bypass_otel_for_tools,
    )


# ------------------------------------------------------------------
# Sync wrapping
# ------------------------------------------------------------------


def _wrap_bedrock_client(
    client: "BedrockRuntimeClient",
    user_id: str,
    convo_id: Optional[str],
) -> "BedrockRuntimeClient":
    """Monkey-patch sync ``converse`` and ``invoke_model`` on *client*.

    Sets ``_raindrop_wrapped`` to guard against double-wrapping.
    """
    if getattr(client, "_raindrop_wrapped", False):
        return client

    original_converse = getattr(client, "converse", None)
    original_invoke_model = getattr(client, "invoke_model", None)

    if original_converse is not None:

        def wrapped_converse(**kwargs: Any) -> Any:
            return _instrument_converse(original_converse, kwargs, user_id, convo_id)

        client.converse = wrapped_converse  # type: ignore[attr-defined]

    if original_invoke_model is not None:

        def wrapped_invoke_model(**kwargs: Any) -> Any:
            return _instrument_invoke_model(original_invoke_model, kwargs, user_id, convo_id)

        client.invoke_model = wrapped_invoke_model  # type: ignore[attr-defined]

    client._raindrop_wrapped = True  # type: ignore[attr-defined]
    return client


# ------------------------------------------------------------------
# Async wrapping
# ------------------------------------------------------------------


def _wrap_async_bedrock_client(
    client: Any,
    user_id: str,
    convo_id: Optional[str],
) -> Any:
    """Monkey-patch async ``converse`` and ``invoke_model`` on an aioboto3 client.

    Sets ``_raindrop_wrapped`` to guard against double-wrapping.
    """
    if getattr(client, "_raindrop_wrapped", False):
        return client

    original_converse = getattr(client, "converse", None)
    original_invoke_model = getattr(client, "invoke_model", None)

    if original_converse is not None:

        async def wrapped_async_converse(**kwargs: Any) -> Any:
            return await _async_instrument_converse(original_converse, kwargs, user_id, convo_id)

        client.converse = wrapped_async_converse  # type: ignore[attr-defined]

    if original_invoke_model is not None:

        async def wrapped_async_invoke_model(**kwargs: Any) -> Any:
            return await _async_instrument_invoke_model(original_invoke_model, kwargs, user_id, convo_id)

        client.invoke_model = wrapped_async_invoke_model  # type: ignore[attr-defined]

    client._raindrop_wrapped = True  # type: ignore[attr-defined]
    return client


# ------------------------------------------------------------------
# Sync instrumentation
# ------------------------------------------------------------------


def _instrument_converse(
    original_fn: Any,
    kwargs: Dict[str, Any],
    user_id: str,
    convo_id: Optional[str],
) -> Any:
    """Call *original_fn* and track the converse interaction in Raindrop."""
    try:
        model_id = kwargs.get("modelId")
        input_text = _format_converse_input(kwargs.get("messages"))
        event_id = str(uuid.uuid4())
    except Exception:
        logger.debug("Failed to prepare converse telemetry", exc_info=True)
        return original_fn(**kwargs)

    try:
        response = original_fn(**kwargs)
    except Exception as exc:
        _track_error(event_id, input_text, model_id, user_id, convo_id, exc)
        raise

    try:
        output_text = _extract_converse_output(response)
        usage = response.get("usage", {})
        prompt_tokens: Optional[int] = usage.get("inputTokens")
        completion_tokens: Optional[int] = usage.get("outputTokens")
        stop_reason: Optional[str] = response.get("stopReason")
        cached_tokens: Optional[int] = usage.get("cacheReadInputTokenCount")
        cache_write_tokens: Optional[int] = usage.get("cacheWriteInputTokenCount")

        properties = _build_token_properties(
            prompt_tokens,
            completion_tokens,
            stop_reason=stop_reason,
            cached_tokens=cached_tokens,
            cache_write_tokens=cache_write_tokens,
        )

        raindrop.track_ai(
            user_id=user_id,
            event="ai_generation",
            event_id=event_id,
            input=input_text,
            output=output_text,
            model=model_id,
            properties=properties,
            convo_id=convo_id,
        )
    except Exception:
        logger.debug("Failed to track converse response", exc_info=True)

    return response


def _instrument_invoke_model(
    original_fn: Any,
    kwargs: Dict[str, Any],
    user_id: str,
    convo_id: Optional[str],
) -> Any:
    """Call *original_fn* and track the invoke_model interaction in Raindrop."""
    try:
        model_id = kwargs.get("modelId")
        input_text = _parse_body(kwargs.get("body"))
        event_id = str(uuid.uuid4())
    except Exception:
        logger.debug("Failed to prepare invoke_model telemetry", exc_info=True)
        return original_fn(**kwargs)

    try:
        response = original_fn(**kwargs)
    except Exception as exc:
        _track_error(event_id, input_text, model_id, user_id, convo_id, exc)
        raise

    try:
        output_text, prompt_tokens, completion_tokens, stop_reason, cached_tokens = (
            _parse_invoke_response(response)
        )

        properties = _build_token_properties(
            prompt_tokens,
            completion_tokens,
            stop_reason=stop_reason,
            cached_tokens=cached_tokens,
        )

        raindrop.track_ai(
            user_id=user_id,
            event="ai_generation",
            event_id=event_id,
            input=input_text,
            output=output_text,
            model=model_id,
            properties=properties,
            convo_id=convo_id,
        )
    except Exception:
        logger.debug("Failed to track invoke_model response", exc_info=True)

    return response


# ------------------------------------------------------------------
# Async instrumentation
# ------------------------------------------------------------------


async def _async_instrument_converse(
    original_fn: Any,
    kwargs: Dict[str, Any],
    user_id: str,
    convo_id: Optional[str],
) -> Any:
    """Await *original_fn* and track the converse interaction in Raindrop."""
    try:
        model_id = kwargs.get("modelId")
        input_text = _format_converse_input(kwargs.get("messages"))
        event_id = str(uuid.uuid4())
    except Exception:
        logger.debug("Failed to prepare async converse telemetry", exc_info=True)
        return await original_fn(**kwargs)

    try:
        response = await original_fn(**kwargs)
    except Exception as exc:
        _track_error(event_id, input_text, model_id, user_id, convo_id, exc)
        raise

    try:
        output_text = _extract_converse_output(response)
        usage = response.get("usage", {})
        prompt_tokens: Optional[int] = usage.get("inputTokens")
        completion_tokens: Optional[int] = usage.get("outputTokens")
        stop_reason: Optional[str] = response.get("stopReason")
        cached_tokens: Optional[int] = usage.get("cacheReadInputTokenCount")
        cache_write_tokens: Optional[int] = usage.get("cacheWriteInputTokenCount")

        properties = _build_token_properties(
            prompt_tokens,
            completion_tokens,
            stop_reason=stop_reason,
            cached_tokens=cached_tokens,
            cache_write_tokens=cache_write_tokens,
        )

        raindrop.track_ai(
            user_id=user_id,
            event="ai_generation",
            event_id=event_id,
            input=input_text,
            output=output_text,
            model=model_id,
            properties=properties,
            convo_id=convo_id,
        )
    except Exception:
        logger.debug("Failed to track async converse response", exc_info=True)

    return response


async def _async_instrument_invoke_model(
    original_fn: Any,
    kwargs: Dict[str, Any],
    user_id: str,
    convo_id: Optional[str],
) -> Any:
    """Await *original_fn* and track the invoke_model interaction in Raindrop."""
    try:
        model_id = kwargs.get("modelId")
        input_text = _parse_body(kwargs.get("body"))
        event_id = str(uuid.uuid4())
    except Exception:
        logger.debug("Failed to prepare async invoke_model telemetry", exc_info=True)
        return await original_fn(**kwargs)

    try:
        response = await original_fn(**kwargs)
    except Exception as exc:
        _track_error(event_id, input_text, model_id, user_id, convo_id, exc)
        raise

    try:
        output_text, prompt_tokens, completion_tokens, stop_reason, cached_tokens = (
            await _async_parse_invoke_response(response)
        )

        properties = _build_token_properties(
            prompt_tokens,
            completion_tokens,
            stop_reason=stop_reason,
            cached_tokens=cached_tokens,
        )

        raindrop.track_ai(
            user_id=user_id,
            event="ai_generation",
            event_id=event_id,
            input=input_text,
            output=output_text,
            model=model_id,
            properties=properties,
            convo_id=convo_id,
        )
    except Exception:
        logger.debug("Failed to track async invoke_model response", exc_info=True)

    return response


# ------------------------------------------------------------------
# Error tracking helper
# ------------------------------------------------------------------


def _track_error(
    event_id: str,
    input_text: Optional[str],
    model_id: Optional[str],
    user_id: str,
    convo_id: Optional[str],
    exc: BaseException,
) -> None:
    """Track a failed LLM call, capturing error type and message."""
    try:
        error_properties: Dict[str, Any] = {
            "error.type": type(exc).__name__,
            "error.message": str(exc),
        }
        raindrop.track_ai(
            user_id=user_id,
            event="ai_generation",
            event_id=event_id,
            input=input_text,
            model=model_id,
            properties=error_properties,
            convo_id=convo_id,
        )
    except Exception:
        logger.debug("Failed to track error telemetry", exc_info=True)


# ------------------------------------------------------------------
# Converse helpers
# ------------------------------------------------------------------


def _format_converse_input(messages: Any) -> Optional[str]:
    """Extract the last user message text from a Converse ``messages`` list."""
    if not messages:
        return None
    user_msgs = [m for m in messages if isinstance(m, dict) and m.get("role") == "user"]
    last_msg = user_msgs[-1] if user_msgs else (messages[-1] if messages else None)
    if not last_msg or not isinstance(last_msg, dict):
        return None
    content = last_msg.get("content", [])
    text_parts: list[str] = []
    for block in (content if isinstance(content, list) else []):
        if isinstance(block, dict) and block.get("text"):
            text_parts.append(block["text"])
    return " ".join(text_parts) if text_parts else None


def _extract_converse_output(response: Dict[str, Any]) -> Optional[str]:
    """Extract assistant text from a Converse API response."""
    output = response.get("output", {})
    message = output.get("message", {}) if isinstance(output, dict) else {}
    content = message.get("content", []) if isinstance(message, dict) else []
    texts: list[str] = []
    for block in (content if isinstance(content, list) else []):
        if isinstance(block, dict) and "text" in block:
            texts.append(block["text"])
    return "\n".join(texts) if texts else None


# ------------------------------------------------------------------
# invoke_model helpers
# ------------------------------------------------------------------


def _parse_body(body: Any) -> Optional[str]:
    """Decode the request body of an ``invoke_model`` call to a string."""
    if body is None:
        return None
    try:
        if isinstance(body, (bytes, bytearray)):
            return body.decode("utf-8")
        if isinstance(body, str):
            return body
        if hasattr(body, "read"):
            data = body.read()
            if hasattr(body, "seek"):
                body.seek(0)
            return data.decode("utf-8") if isinstance(data, bytes) else str(data)
        return str(body)
    except Exception:
        logger.debug("Failed to parse invoke_model request body", exc_info=True)
        return None


def _parse_invoke_response(
    response: Dict[str, Any],
) -> tuple[Optional[str], Optional[int], Optional[int], Optional[str], Optional[int]]:
    """Parse an ``invoke_model`` response body.

    Returns ``(output_text, prompt_tokens, completion_tokens, stop_reason, cached_tokens)``.

    If the body is a streaming object (like ``botocore.response.StreamingBody``),
    it is read and replaced with a ``BytesIO`` so the caller can still call
    ``.read()``.
    """
    body = response.get("body")
    if not body:
        return None, None, None, None, None

    try:
        if hasattr(body, "read"):
            raw = body.read()
            response["body"] = io.BytesIO(raw)
        elif isinstance(body, (bytes, bytearray)):
            raw = body
        else:
            raw = str(body).encode("utf-8")

        parsed = json.loads(raw)
        return _extract_parsed_invoke_fields(parsed)

    except Exception:
        logger.debug("Failed to parse invoke_model response body", exc_info=True)
        return None, None, None, None, None


def _extract_parsed_invoke_fields(
    parsed: Dict[str, Any],
) -> tuple[Optional[str], Optional[int], Optional[int], Optional[str], Optional[int]]:
    """Extract output text, prompt tokens, completion tokens, stop reason, and cached tokens.

    Returns ``(output_text, prompt_tokens, completion_tokens, stop_reason, cached_tokens)``.

    Supports Anthropic Claude, Amazon Titan, and Meta Llama response formats.
    """
    # Anthropic Claude format
    content = parsed.get("content")
    if isinstance(content, list):
        output = (
            "\n".join(
                c.get("text", "")
                for c in content
                if isinstance(c, dict) and c.get("type") == "text"
            )
            or None
        )
        usage = parsed.get("usage", {})
        stop_reason = parsed.get("stop_reason")
        cached_tokens = usage.get("cache_read_input_tokens")
        return (
            output,
            usage.get("input_tokens"),
            usage.get("output_tokens"),
            stop_reason,
            cached_tokens,
        )

    # Amazon Titan format
    results = parsed.get("results")
    if isinstance(results, list) and results:
        output = (
            "\n".join(r.get("outputText", "") for r in results if isinstance(r, dict))
            or None
        )
        ct = results[0].get("tokenCount") if isinstance(results[0], dict) else None
        return output, parsed.get("inputTextTokenCount"), ct, None, None

    # Llama format
    generation = parsed.get("generation")
    if generation:
        stop_reason = parsed.get("stop_reason")
        return (
            generation,
            parsed.get("prompt_token_count"),
            parsed.get("generation_token_count"),
            stop_reason,
            None,
        )

    # Fallback
    output = parsed.get("output") or parsed.get("completion") or parsed.get("generated_text")
    return output, None, None, None, None


async def _async_parse_invoke_response(
    response: Dict[str, Any],
) -> tuple[Optional[str], Optional[int], Optional[int], Optional[str], Optional[int]]:
    """Async version of :func:`_parse_invoke_response`.

    Handles aioboto3 ``AioStreamingBody`` whose ``.read()`` is a coroutine.
    Falls back to sync read for plain bytes / ``BytesIO`` bodies.

    Returns ``(output_text, prompt_tokens, completion_tokens, stop_reason, cached_tokens)``.
    """
    body = response.get("body")
    if not body:
        return None, None, None, None, None

    try:
        if isinstance(body, (bytes, bytearray)):
            raw = body
        elif hasattr(body, "read"):
            read_result = body.read()
            # aioboto3 AioStreamingBody.read() returns a coroutine
            if inspect.isawaitable(read_result):
                raw = await read_result
            else:
                raw = read_result
            response["body"] = _AsyncBytesIO(raw)
        else:
            raw = str(body).encode("utf-8")

        parsed = json.loads(raw)
        return _extract_parsed_invoke_fields(parsed)

    except Exception:
        logger.debug("Failed to parse async invoke_model response body", exc_info=True)
        return None, None, None, None, None


class _AsyncBytesIO:
    """A thin async-compatible wrapper around ``io.BytesIO``.

    After consuming the original ``AioStreamingBody``, we replace the response
    body with this wrapper so that callers using ``await response["body"].read()``
    continue to work.  A plain ``io.BytesIO`` would break because its ``read()``
    returns ``bytes`` directly, and ``await bytes_obj`` raises ``TypeError``.
    """

    def __init__(self, data: bytes) -> None:
        self._buf = io.BytesIO(data)

    async def read(self, amt: int = -1) -> bytes:
        """Return the buffered bytes (async-compatible)."""
        return self._buf.read(amt)

    def __repr__(self) -> str:
        return f"_AsyncBytesIO(len={self._buf.getbuffer().nbytes})"


# ------------------------------------------------------------------
# Shared helpers
# ------------------------------------------------------------------


def _build_token_properties(
    prompt_tokens: Optional[int],
    completion_tokens: Optional[int],
    *,
    stop_reason: Optional[str] = None,
    cached_tokens: Optional[int] = None,
    cache_write_tokens: Optional[int] = None,
) -> Optional[Dict[str, Any]]:
    """Build a properties dict with token usage and stop reason fields.

    Returns ``None`` when every input is ``None``.
    """
    props: Dict[str, Any] = {}
    if prompt_tokens is not None:
        props["ai.usage.prompt_tokens"] = prompt_tokens
    if completion_tokens is not None:
        props["ai.usage.completion_tokens"] = completion_tokens
    if stop_reason is not None:
        props["bedrock.finish_reason"] = stop_reason
    if cached_tokens is not None:
        props["ai.usage.cached_tokens"] = cached_tokens
    if cache_write_tokens is not None:
        props["ai.usage.cache_write_tokens"] = cache_write_tokens
    return props if props else None
