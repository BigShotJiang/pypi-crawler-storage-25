"""
pytmrobot._ft_base — Compliance / TouchStop / Force 共用基底

三個控制器共享相同的「宣告 → 設定 → Start() → ListenSend」模式，
以及 Listen Node session 變數宣告追蹤邏輯，在此統一實作。
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from .types import Pose6

if TYPE_CHECKING:
    from ._client import TMClientWrapper
    from .tag_manager import TagManager


class _FTBase:
    """Compliance / TouchStop / Force 共用基底類別。

    子類別需定義：
    - ``_OBJ_NAME``:   TMScript 物件變數名稱，如 ``"_ts"``
    - ``_RESULT_VAR``: TMScript 整數結果變數名稱，如 ``"_ts_r"``

    **Start() 傳回碼（int）：**

    +------+----------------------------------+
    |  0   | Not Working                      |
    |  1   | Working（Start() 仍在執行中）     |
    |  2   | Timeout                          |
    |  3   | Distance reached（正常完成）      |
    |  4   | IO triggered                     |
    |  5   | Resisted（偵測到外部阻力）        |
    |  6   | Error                            |
    |  7   | Over Speed                       |
    |  8   | Digital IO triggered             |
    |  9   | Analog IO triggered              |
    | 10   | Variable                         |
    | 11   | Force is Satisfied               |
    | 12   | Allowable Position Tolerances    |
    | 13   | Motion Finish（軌跡結束正常完成） |
    +------+----------------------------------+
    """

    _OBJ_NAME:   str = ""
    _RESULT_VAR: str = ""

    def __init__(self, client: TMClientWrapper, tags: TagManager) -> None:
        self._client   = client
        self._tags     = tags
        self._declared: dict[str, bool] = {}

    def _reset_session(self) -> None:
        """重設所有 TMScript 變數宣告狀態（重新連線時呼叫）。"""
        self._declared.clear()

    # ── 內部工具 ──────────────────────────────────────────────────────────────

    def _is_declared(self, var: str) -> bool:
        return self._declared.get(var, False)

    def _mark(self, var: str) -> None:
        self._declared[var] = True

    def _assign(self, tmtype: str, var: str, expr: str) -> str:
        """依宣告狀態回傳 'TYPE var = expr' 或 'var = expr'。"""
        if not self._is_declared(var):
            self._mark(var)
            return f"{tmtype} {var} = {expr}"
        return f"{var} = {expr}"

    def _sid(self, suffix: str = "") -> str:
        """生成腳本 ID（使用物件名去掉底線為前綴）。"""
        tag = self._tags.next()
        prefix = self._OBJ_NAME.lstrip("_")
        return f"{prefix}{suffix}{tag}"

    # ── 核心執行 ──────────────────────────────────────────────────────────────

    def _run(
        self,
        setup_lines: list[str],
        start_expr:  str,
        timeout_ms:  int,
    ) -> int:
        """發送設定 + Start() 腳本，以 ListenSend SubCmd 90 接收結果碼。

        Args:
            setup_lines: 物件宣告/設定行（Reset, Frame, Single, Timeout…）
            start_expr:  Start() 呼叫字串，如 ``"_ts.Start()"``
            timeout_ms:  TMScript 逾時設定，用於計算 Python 端等待上限
        """
        result_line = self._assign("int", self._RESULT_VAR, start_expr)
        lines = setup_lines + [result_line,
                               f"ListenSend(90, GetString({self._RESULT_VAR}))"]
        py_timeout = (timeout_ms / 1000.0 + 5.0) if timeout_ms > 0 else 3600.0
        csv = self._client.send_and_recv_subcmd(self._sid(), lines, timeout=py_timeout)
        return int(csv.strip())

    def _stop(self) -> int:
        """發送 Stop() 腳本並以 ListenSend 接收結果碼。"""
        result_line = self._assign("int", self._RESULT_VAR,
                                   f"{self._OBJ_NAME}.Stop()")
        lines = [result_line, f"ListenSend(90, GetString({self._RESULT_VAR}))"]
        csv = self._client.send_and_recv_subcmd(self._sid("stop"), lines)
        return int(csv.strip())

    def _read_pos(self, method_call: str, var_name: str) -> Pose6:
        """發送 GetXxxPos(type) → ListenSend，解析 float[] 座標為 Pose6。"""
        assign = self._assign("float[]", var_name, method_call)
        lines  = [assign, f"ListenSend(90, GetString({var_name}))"]
        csv    = self._client.send_and_recv_subcmd(self._sid("pos"), lines)
        parts  = [v.strip() for v in csv.strip().strip("{}").split(",") if v.strip()]
        return tuple(float(p) for p in parts)  # type: ignore[return-value]
