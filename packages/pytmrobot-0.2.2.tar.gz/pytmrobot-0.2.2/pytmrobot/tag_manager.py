"""
pytmrobot.tag_manager — QueueTag 循環計數器。

TMScript QueueTag 合法值為 1-15，機器人端保留最後四筆狀態。
同步 API 每次等待完成後才發下一個指令，因此循環 1-15 不會衝突。
"""


class TagManager:
    """QueueTag 循環計數器（1–15）。

    Examples::

        tm = TagManager()
        t1 = tm.next()   # → 1
        t2 = tm.next()   # → 2
        ...
        t15 = tm.next()  # → 15
        t16 = tm.next()  # → 1  (循環)
    """

    _MIN = 1
    _MAX = 15

    def __init__(self) -> None:
        self._counter: int = 0

    def next(self) -> int:
        """取下一個可用 tag id（1-15 循環）。"""
        self._counter = (self._counter % self._MAX) + self._MIN
        return self._counter

    @property
    def current(self) -> int:
        """當前 tag id（最後一次 next() 回傳的值）。"""
        return self._counter

    def reset(self) -> None:
        """重設計數器至初始狀態（下次 next() 回傳 1）。"""
        self._counter = 0
