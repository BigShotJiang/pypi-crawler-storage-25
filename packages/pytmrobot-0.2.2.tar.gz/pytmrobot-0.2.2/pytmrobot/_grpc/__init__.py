# gRPC generated stubs — EIH Camera API
