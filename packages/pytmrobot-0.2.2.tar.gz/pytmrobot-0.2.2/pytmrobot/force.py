"""
pytmrobot.force — ForceController

透過 robot.force 存取。使用 TM Robot 的 Force 控制功能，
透過外接力矩感測器（FTSensor）進行力控制運動。

TMScript 對應：Chapter 22 Force / FTSensor

使用流程：
  1. robot.force.open_sensor("ATI")  — 連接力矩感測器
  2. robot.force.run([("Fz", True, 5.0, 2)], ...)  — 執行力控運動
  3. robot.force.close_sensor()  — 關閉連線（可選）
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from . import script_builder as sb
from ._ft_base import _FTBase

if TYPE_CHECKING:
    pass

# FTSensor 變數名稱（Listen Node session 全域固定）
_FTS_VAR = "_fts"


class ForceController(_FTBase):
    """Force 力控制器。透過 ``robot.force`` 存取。

    典型流程::

        robot.force.open_sensor("ATI")

        # Z 軸力控：目標 5N，允許移動 20mm，逾時 5 秒
        result = robot.force.run(
            axes=[("Fz", True, 5.0, 2)],
            distance_mm=20.0,
            timeout_ms=5000,
        )
        if result == 11:   # Force is Satisfied
            print("力量達到目標")

        robot.force.close_sensor()

    **axes 格式**：``(axis, enabled, value, pid)``

    - axis:    ``"Fx"``/``"Fy"``/``"Fz"``/``"Mx"``/``"My"``/``"Mz"``
    - enabled: 是否對此軸啟用力控
    - value:   目標力/力矩值（N 或 N·m）
    - pid:     PID 增益組索引

    Start() 結果碼（result 值）請參考 _FTBase docstring。
    """

    _OBJ_NAME   = "_fc"
    _RESULT_VAR = "_fc_r"

    def open_sensor(self, model: str) -> None:
        """連接 FTSensor 力矩感測器。

        Args:
            model: 感測器型號字串（如 ``"ATI"``）

        Note:
            同一 Listen Node session 內只需宣告一次；
            斷線重連後需重新呼叫。

        Examples::

            robot.force.open_sensor("ATI")
        """
        fts_declared = self._is_declared(_FTS_VAR)
        lines = sb.build_ftsensor_open(model, fts_declared=fts_declared)
        if lines:
            tag = self._tags.next()
            self._client.send_script_checked(f"ftso{tag}", lines)
            self._mark(_FTS_VAR)

    def close_sensor(self) -> None:
        """關閉 FTSensor 連線（不銷毀物件，可再次 open_sensor）。

        Examples::

            robot.force.close_sensor()
        """
        tag = self._tags.next()
        self._client.send_script_checked(
            f"ftsc{tag}", [f'ftsensor_close("{_FTS_VAR}")']
        )

    def run(
        self,
        axes:       list[tuple[str, bool, float, int]],
        *,
        frame:                int   = 1,
        distance_mm:          float = -1.0,
        timeout_ms:           int   = -1,
        zero_ft:              bool  = True,
        gravity_compensation: bool  = False,
    ) -> int:
        """執行 Force 力控運動。

        Args:
            axes:                 軸設定列表，每項為 ``(axis, enabled, value, pid)``
            frame:                座標系（1=機器人基座, 2=工具, 3=使用者）
            distance_mm:          最大移動距離（mm，-1=不限）
            timeout_ms:           逾時毫秒（-1=不逾時）
            zero_ft:              開始前清零力矩感測器
            gravity_compensation: 啟用重力補償

        Returns:
            Start() 結果碼（見 _FTBase docstring）

        Examples::

            # Z 軸壓力 5N，最多移動 20mm
            result = robot.force.run(
                axes=[("Fz", True, 5.0, 2)],
                distance_mm=20.0,
            )

            # 多軸力控
            result = robot.force.run(
                axes=[
                    ("Fz", True, 5.0, 2),
                    ("Mx", True, 0.5, 2),
                ],
                timeout_ms=8000,
                gravity_compensation=True,
            )
        """
        obj_declared = self._is_declared(self._OBJ_NAME)
        setup = sb.build_force_setup(
            axes,
            frame=frame, timeout_ms=timeout_ms, distance_mm=distance_mm,
            obj_declared=obj_declared,
        )
        self._mark(self._OBJ_NAME)
        zero_str  = "true" if zero_ft else "false"
        gcomp_str = "true" if gravity_compensation else "false"
        return self._run(setup, f"_fc.Start({zero_str}, {gcomp_str})", timeout_ms)

    def stop(self) -> int:
        """中止 Force 力控運動。

        Returns:
            Stop() 結果碼
        """
        return self._stop()
