"""
pytmrobot.motion — MotionController

提供 robot.move.xxx() 系列運動指令。
所有方法預設 wait=True（同步等待運動完成）。
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Union

from . import script_builder as sb
from .exceptions import TMValueError
from .types import BlendUnit, CartPoint, JointPoint, SpeedUnit

if TYPE_CHECKING:
    from ._client import TMClientWrapper
    from .tag_manager import TagManager


class MotionController:
    """機器人運動控制器。透過 ``robot.move`` 存取。

    Examples::

        with TMRobot("192.168.1.101") as robot:
            robot.move.ptp(CartPoint(400, -100, 350, 180, 0, 90), speed=30)
            robot.move.line(CartPoint(450, -100, 350, 180, 0, 90), speed=150)
    """

    def __init__(self, client: TMClientWrapper, tags: TagManager) -> None:
        self._client = client
        self._tags   = tags
        self._last_tag: int = 0   # 最後一次 wait=False 的 tag，供 wait_motion() 使用

    def _send_motion(self, prefix: str, tag: int, lines: list[str], *, wait: bool) -> None:
        """發送運動 script，並在 wait=False 時記錄 tag 供 wait_motion() 使用。"""
        self._client.send_script_checked(f"{prefix}{tag}", lines)
        if not wait:
            self._last_tag = tag

    # ── PTP ──────────────────────────────────────────────────────────────────

    def ptp(
        self,
        target: Union[CartPoint, JointPoint],
        speed:    int  = 10,
        accel_ms: int  = 200,
        blend:    int  = 0,
        *,
        wait: bool = True,
    ) -> None:
        """點對點（PTP）運動。

        Args:
            target:   目標點，CartPoint（笛卡爾）或 JointPoint（關節角度）
            speed:    速度百分比（1-100）
            accel_ms: 加速時間，ms
            blend:    軌跡混合百分比（0=精準到位，>0=過渡）
            wait:     True=等待到位後才返回；False=發送後立即返回

        Raises:
            TMValueError: 參數超出範圍
            TMScriptError: 機器人回傳 ERROR

        Examples::

            robot.move.ptp(CartPoint(400, -100, 350, 180, 0, 90), speed=30)
            robot.move.ptp(JointPoint(0, -6.5, 96.1, 0.4, 90, 0), speed=20)
        """
        self._validate_speed_pct(speed)
        self._validate_blend_pct(blend)
        tag = self._tags.next()
        self._send_motion("ptp", tag, sb.build_ptp(target, speed, accel_ms, blend, tag, wait=wait), wait=wait)

    # ── Line ─────────────────────────────────────────────────────────────────

    def line(
        self,
        target:     CartPoint,
        speed:      int = 100,
        speed_unit: SpeedUnit = SpeedUnit.ABS_LOCK,
        accel_ms:   int = 200,
        blend:      int = 0,
        blend_unit: BlendUnit = BlendUnit.PERCENT,
        *,
        wait: bool = True,
    ) -> None:
        """直線（Line）運動。

        Args:
            target:     目標點（CartPoint）
            speed:      速度值（百分比或 mm/s，取決於 speed_unit）
            speed_unit: SpeedUnit.PERCENT / ABS_SYNC / ABS_LOCK（預設）
            accel_ms:   加速時間，ms
            blend:      混合值（百分比或半徑 mm，取決於 blend_unit）
            blend_unit: BlendUnit.PERCENT（預設）/ RADIUS
            wait:       True=等待到位

        Examples::

            robot.move.line(CartPoint(450, -100, 350, 180, 0, 90), speed=150)
            robot.move.line(CartPoint(500, -100, 350, 180, 0, 90),
                            speed=50, speed_unit=SpeedUnit.PERCENT)
        """
        tag = self._tags.next()
        self._send_motion("line", tag,
                          sb.build_line(target, speed_unit, blend_unit, speed, accel_ms, blend, tag, wait=wait),
                          wait=wait)

    # ── Circle ───────────────────────────────────────────────────────────────

    def circle(
        self,
        via:        CartPoint,
        end:        CartPoint,
        speed:      int = 100,
        speed_unit: SpeedUnit = SpeedUnit.ABS_LOCK,
        accel_ms:   int = 200,
        blend:      int = 0,
        angle:      int = 0,
        *,
        wait: bool = True,
    ) -> None:
        """圓弧（Circle）運動。

        Args:
            via:   圓弧上任意中間點（非起點非終點）
            end:   圓弧終點
            angle: 0=運動至 end；非0=依指定角度（°）運動並保持起始姿態

        Examples::

            robot.move.circle(
                via=CartPoint(420, -50, 350, 180, 0, 90),
                end=CartPoint(400, 0,  350, 180, 0, 90),
            )
        """
        tag = self._tags.next()
        self._send_motion("circ", tag,
                          sb.build_circle(via, end, speed_unit, speed, accel_ms, blend, angle, tag, wait=wait),
                          wait=wait)

    # ── 相對運動 ──────────────────────────────────────────────────────────────

    def ptp_relative(
        self,
        delta:    Union[CartPoint, JointPoint],
        speed:    int  = 10,
        accel_ms: int  = 200,
        blend:    int  = 0,
        *,
        wait: bool = True,
    ) -> None:
        """相對 PTP 運動（Move_PTP）：基於當前位置的偏移量移動。

        Args:
            delta: 偏移量（CartPoint=座標偏移，JointPoint=關節偏移）

        Examples::

            # 在 Z 軸往上移 50 mm
            robot.move.ptp_relative(CartPoint(0, 0, 50, 0, 0, 0), speed=20)
        """
        self._validate_speed_pct(speed)
        tag = self._tags.next()
        self._send_motion("mptp", tag,
                          sb.build_move_ptp(delta, speed, accel_ms, blend, tag, wait=wait),
                          wait=wait)

    def line_relative(
        self,
        delta:      CartPoint,
        speed:      int = 100,
        speed_unit: SpeedUnit = SpeedUnit.ABS_LOCK,
        accel_ms:   int = 200,
        blend:      int = 0,
        blend_unit: BlendUnit = BlendUnit.PERCENT,
        *,
        wait: bool = True,
    ) -> None:
        """相對直線運動（Move_Line）：基於當前位置的偏移量直線移動。

        Examples::

            # 沿 X 軸直線移動 30 mm
            robot.move.line_relative(CartPoint(30, 0, 0, 0, 0, 0), speed=50)
        """
        tag = self._tags.next()
        self._send_motion("mline", tag,
                          sb.build_move_line(delta, speed_unit, blend_unit, speed, accel_ms, blend, tag, wait=wait),
                          wait=wait)

    # ── PVT 軌跡（Ch13）──────────────────────────────────────────────────────

    def pvt_enter(self, mode: str = "cart") -> None:
        """進入 PVT（Position-Velocity-Time）軌跡模式。

        Args:
            mode: ``"cart"``=笛卡爾（預設），``"joint"``=關節

        Note:
            進入後以 :meth:`pvt_point` 累積軌跡點，最後呼叫 :meth:`pvt_exit` 執行。

        Examples::

            robot.move.pvt_enter("cart")
            robot.move.pvt_point(p1, v1, 1000)
            robot.move.pvt_point(p2, v2, 2000)
            robot.move.pvt_exit()
        """
        if mode not in ("cart", "joint"):
            raise TMValueError(f"mode 必須是 'cart' 或 'joint'，得到 {mode!r}")
        mode_int = 1 if mode == "cart" else 2
        tag = self._tags.next()
        self._client.send_script_checked(f"pvte{tag}", [sb.build_pvt_enter(mode_int)])

    def pvt_point(
        self,
        target:   Union[CartPoint, JointPoint],
        velocity: Union[CartPoint, JointPoint],
        time_ms:  int,
    ) -> None:
        """新增 PVT 軌跡點（放入機器人端緩衝，不等待執行）。

        Args:
            target:   目標點位置
            velocity: 到達目標點時的速度向量（與 target 同型別，單位 mm/s 或 °/s）
            time_ms:  從上一點到此點的執行時間，ms

        Raises:
            TypeError: target 與 velocity 型別不一致

        Examples::

            robot.move.pvt_point(
                CartPoint(400, -100, 350, 180, 0, 90),
                CartPoint(10, 0, 0, 0, 0, 0),    # 10 mm/s 沿 X 軸
                1000,
            )
        """
        if isinstance(target, CartPoint) and isinstance(velocity, CartPoint):
            mtype = "CPP"
        elif isinstance(target, JointPoint) and isinstance(velocity, JointPoint):
            mtype = "JPP"
        else:
            raise TypeError(
                "target 與 velocity 必須是相同型別（CartPoint 或 JointPoint）"
            )
        line = sb.build_pvt_point(mtype, target.as_pose6(), velocity.as_pose6(), time_ms)
        tag = self._tags.next()
        self._client.send_script_checked(f"pvtp{tag}", [line])

    def pvt_pause(self) -> None:
        """暫停 PVT 軌跡執行。"""
        tag = self._tags.next()
        self._client.send_script_checked(f"pvtps{tag}", [sb.build_pvt_pause()])

    def pvt_resume(self) -> None:
        """繼續暫停中的 PVT 軌跡執行。"""
        tag = self._tags.next()
        self._client.send_script_checked(f"pvtrs{tag}", [sb.build_pvt_resume()])

    def pvt_exit(self, *, wait: bool = True) -> None:
        """結束 PVT 模式並執行緩衝中所有軌跡點。

        Args:
            wait: True=等待全部軌跡執行完畢後才返回
        """
        tag = self._tags.next()
        self._send_motion("pvtx", tag, sb.build_pvt_exit(tag, wait), wait=wait)

    # ── 等待 ─────────────────────────────────────────────────────────────────

    def wait_motion(self) -> None:
        """等待最近一次 ``wait=False`` 的運動指令完成。

        Examples::

            robot.move.ptp(p1, wait=False)
            # ... 做其他事 ...
            robot.move.wait_motion()   # 確認已到位
        """
        if self._last_tag:
            self._client.wait_queue_tag(self._last_tag)

    # ── 內部驗證 ──────────────────────────────────────────────────────────────

    @staticmethod
    def _validate_speed_pct(speed: int) -> None:
        if not (1 <= speed <= 100):
            raise TMValueError(f"speed 必須在 1-100 之間，得到 {speed}")

    @staticmethod
    def _validate_blend_pct(blend: int) -> None:
        if not (0 <= blend <= 100):
            raise TMValueError(f"blend 必須在 0-100 之間，得到 {blend}")
