"""
pytmrobot.types — 所有公開資料型別定義。

CartPoint / JointPoint 是使用者最常接觸的型別。
Pose6 為 6 元素 float tuple，代表 (X,Y,Z,Rx,Ry,Rz) 或 (J1..J6)。
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum

# ── 基礎別名 ────────────────────────────────────────────────────────────────
Pose6 = tuple[float, float, float, float, float, float]
"""(X, Y, Z, Rx, Ry, Rz) mm/° 或 (J1, J2, J3, J4, J5, J6) °"""


# ── 點位型別 ────────────────────────────────────────────────────────────────

@dataclass
class CartPoint:
    """笛卡爾座標目標點，單位 mm / degree。

    Examples::

        p = CartPoint(400, -100, 350, 180, 0, 90)
        robot.move.ptp(p, speed=30)
    """
    x:  float
    y:  float
    z:  float
    rx: float
    ry: float
    rz: float

    def as_pose6(self) -> Pose6:
        return (self.x, self.y, self.z, self.rx, self.ry, self.rz)

    def __repr__(self) -> str:
        return (f"CartPoint(x={self.x}, y={self.y}, z={self.z}, "
                f"rx={self.rx}, ry={self.ry}, rz={self.rz})")


@dataclass
class JointPoint:
    """關節角度目標點，單位 degree。

    Examples::

        p = JointPoint(0, -6.5, 96.1, 0.4, 90, 0)
        robot.move.ptp(p, speed=20)
    """
    j1: float
    j2: float
    j3: float
    j4: float
    j5: float
    j6: float

    def as_pose6(self) -> Pose6:
        return (self.j1, self.j2, self.j3, self.j4, self.j5, self.j6)

    def __repr__(self) -> str:
        return (f"JointPoint(j1={self.j1}, j2={self.j2}, j3={self.j3}, "
                f"j4={self.j4}, j5={self.j5}, j6={self.j6})")


# ── 速度 / 混合單位列舉 ──────────────────────────────────────────────────────

class SpeedUnit(Enum):
    """直線/圓弧運動的速度單位。

    - ``PERCENT``  : 佔專案最大速度的百分比（0-100 %）
    - ``ABS_SYNC`` : 絕對速度 mm/s，與 TMflow 專案速度連動
    - ``ABS_LOCK`` : 絕對速度 mm/s，不受專案速度影響（預設推薦）
    """
    PERCENT  = "P"   # %，第二字母
    ABS_SYNC = "A"   # mm/s，連動
    ABS_LOCK = "D"   # mm/s，不連動


class BlendUnit(Enum):
    """軌跡混合的計量單位。

    - ``PERCENT`` : 混合百分比（0-100 %）
    - ``RADIUS``  : 混合半徑 mm
    """
    PERCENT = "P"
    RADIUS  = "R"


# ── 狀態容器 ────────────────────────────────────────────────────────────────

@dataclass
class RobotState:
    """``robot.state.snapshot()`` 的批次回傳值。"""
    tcp_position: Pose6
    """TCP 位置 (X,Y,Z,Rx,Ry,Rz)，相對 RobotBase，mm / °"""
    joint_angles: Pose6
    """各關節角度 (J1..J6)，°"""
    tcp_force_3d: float
    """TCP 合力，N"""
    tcp_speed_3d: float
    """TCP 合速度，mm/s"""
    base_name: str
    """當前座標系名稱"""
    tcp_name: str
    """當前工具名稱"""
    payload_kg: float
    """補償附載重量，kg"""


@dataclass
class IOState:
    """``robot.io.get_all_io()`` 的批次回傳值。"""
    di: list[int]   = field(default_factory=list)
    """數位輸入狀態（0=Low, 1=High）"""
    do: list[int]   = field(default_factory=list)
    """數位輸出狀態（0=Low, 1=High）"""
    ai: list[float] = field(default_factory=list)
    """類比輸入電壓，V"""
    ao: list[float] = field(default_factory=list)
    """類比輸出電壓，V"""
