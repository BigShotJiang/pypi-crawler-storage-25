"""
pytmrobot.touchstop — TouchStopController

透過 robot.touchstop 存取。使用 TM Robot 的 TouchStop 功能，
讓機器人在偵測到接觸力達到閾值時自動停止，並可讀取停止位置。

TMScript 對應：Chapter 21 TouchStop
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from . import script_builder as sb
from ._ft_base import _FTBase
from .types import Pose6

if TYPE_CHECKING:
    pass


class TouchStopController(_FTBase):
    """TouchStop 控制器。透過 ``robot.touchstop`` 存取。

    典型流程::

        # 在 Z- 方向最多移動 50mm，當接觸力 ≥ 5N 時停止，速度 10%
        result = robot.touchstop.run(
            direction=32,    # 32 = Z-（見 TMScript ch21）
            distance=50.0,
            force=5.0,
            speed=10,
        )
        if result == 5:   # Resisted
            pos = robot.touchstop.get_stopped_pos()
            print(f"接觸停止位置: {pos}")

    Start() 結果碼（result 值）請參考 _FTBase docstring。
    """

    _OBJ_NAME   = "_ts"
    _RESULT_VAR = "_ts_r"

    def run(
        self,
        direction:  int,
        distance:   float,
        force:      float,
        speed:      int,
        *,
        mode:       str = "Compliance",
        frame:      int = 1,
        timeout_ms: int = -1,
    ) -> int:
        """執行 TouchStop 運動。

        Args:
            direction:  偵測軸方向代碼（TMScript ch21 Single() 參數，
                        如 1=X+, 2=X-, 4=Y+, 8=Y-, 16=Z+, 32=Z-）
            distance:   最大偵測距離（mm）
            force:      觸發力閾值（N）
            speed:      運動速度（%）
            mode:       觸停模式字串（預設 ``"Compliance"``）
            frame:      座標系（1=機器人基座, 2=工具, 3=使用者）
            timeout_ms: 逾時毫秒（-1=不逾時）

        Returns:
            Start() 結果碼（見 _FTBase docstring）

        Examples::

            result = robot.touchstop.run(32, 50.0, 5.0, 10)
            if result == 5:
                stopped = robot.touchstop.get_stopped_pos()
        """
        obj_declared = self._is_declared(self._OBJ_NAME)
        setup = sb.build_touchstop_setup(
            direction, distance, force, speed,
            mode=mode, frame=frame, timeout_ms=timeout_ms,
            obj_declared=obj_declared,
        )
        self._mark(self._OBJ_NAME)
        return self._run(setup, f"{self._OBJ_NAME}.Start()", timeout_ms)

    def stop(self) -> int:
        """中止 TouchStop 運動。

        Returns:
            Stop() 結果碼
        """
        return self._stop()

    def get_stopped_pos(self, coord_type: int = 2) -> Pose6:
        """讀取觸停時的位置。

        Args:
            coord_type: 座標系類型（1=關節角度, 2=笛卡爾機器人基座,
                        3=工具座標, 4=使用者座標）

        Returns:
            Pose6 六軸位置/角度元組

        Examples::

            pos = robot.touchstop.get_stopped_pos()  # 預設笛卡爾
            jnt = robot.touchstop.get_stopped_pos(1) # 關節角度
        """
        return self._read_pos(f"_ts.GetStoppedPos({coord_type})", "_ts_sp")

    def get_triggered_pos(self, coord_type: int = 2) -> Pose6:
        """讀取觸發訊號時的位置（與停止位置不同，因減速距離）。

        Args:
            coord_type: 同 get_stopped_pos()

        Returns:
            Pose6 六軸位置/角度元組
        """
        return self._read_pos(f"_ts.GetTriggeredPos({coord_type})", "_ts_tp")
