"""
pytmrobot.decision — DecisionController

提供 robot.decision.xxx() 系列人機互動指令。
透過 TMScript MDecision 物件在機器人 HMI 顯示對話框，
以 ListenSend 將操作員的選擇回傳給 Python。
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from . import script_builder as sb
from .exceptions import TMValueError

if TYPE_CHECKING:
    from ._client import TMClientWrapper
    from .tag_manager import TagManager


class DecisionController:
    """人機互動控制器。透過 ``robot.decision`` 存取。

    Examples::

        # 詢問操作員
        r = robot.decision.ask("確認繼續？", "工件已放置完畢，繼續執行？", ["繼續", "停止"])
        if r == 1:   # 停止
            robot.stop()

        # 純提示，等待操作員確認
        robot.decision.popup("警告", "請確認安全門已關閉再繼續")
        robot.move.ptp(next_point)
    """

    def __init__(self, client: TMClientWrapper, tags: TagManager) -> None:
        self._client = client
        self._tags   = tags
        self._declared = False  # _md 與 _r 是否已在 Listen Node session 中宣告

    def _reset_session(self) -> None:
        """重設 session 狀態（重新連線時呼叫）。"""
        self._declared = False

    # ── 詢問對話框 ────────────────────────────────────────────────────────────

    def ask(
        self,
        title:      str,
        message:    str,
        choices:    list[str],
        timeout_ms: int = -1,
    ) -> int:
        """在機器人 HMI 顯示多選項對話框，等待操作員選擇。

        Args:
            title:      對話框標題
            message:    說明文字
            choices:    按鈕文字列表（1-3 個）
            timeout_ms: 自動逾時毫秒，-1=無限等待；逾時時回傳最後一個索引

        Returns:
            選擇的按鈕索引（0=第一個, 1=第二個...）；逾時回傳 ``len(choices)-1``

        Raises:
            TMValueError:   choices 為空或超過 3 個
            TMScriptError:  機器人回傳 ERROR
            TMTimeoutError: Python 端等待超過 ``timeout_ms + 5`` 秒

        Examples::

            r = robot.decision.ask(
                "下一步",
                "請選擇要執行的動作",
                ["取料", "放料", "中止"],
            )
            if r == 2:
                raise RuntimeError("操作員中止")
        """
        if not choices:
            raise TMValueError("choices 不可為空")
        if len(choices) > 3:
            raise TMValueError(f"最多支援 3 個選項，得到 {len(choices)} 個")

        tag = self._tags.next()
        lines = sb.build_decision_ask(
            title, message, choices, timeout_ms,
            declared=self._declared,
        )
        # Python 端等待逾時 = TMScript 逾時 + 5 秒緩衝；-1 時用 1 小時
        py_timeout = (timeout_ms / 1000.0 + 5.0) if timeout_ms > 0 else 3600.0
        csv = self._client.send_and_recv_subcmd(f"dec{tag}", lines, timeout=py_timeout)
        self._declared = True
        return int(csv.strip())

    # ── 提示對話框 ────────────────────────────────────────────────────────────

    def popup(
        self,
        title:      str,
        message:    str,
        timeout_ms: int = -1,
    ) -> None:
        """在機器人 HMI 顯示 OK 提示對話框，等待操作員確認後繼續。

        Args:
            title:      對話框標題
            message:    說明文字
            timeout_ms: 自動關閉毫秒，-1=等待操作員點擊 OK

        Note:
            等待時間受 ``TMRobot(timeout=...)`` 設定上限。
            若 popup 可能超過 60 秒（預設值），建立 TMRobot 時請加大 timeout。

        Examples::

            robot.decision.popup("請確認", "夾爪已就位，按確認繼續")
            robot.move.ptp(next_point)
        """
        tag = self._tags.next()
        lines = sb.build_popup(title, message, timeout_ms, tag)
        self._client.send_script_checked(f"pop{tag}", lines)
