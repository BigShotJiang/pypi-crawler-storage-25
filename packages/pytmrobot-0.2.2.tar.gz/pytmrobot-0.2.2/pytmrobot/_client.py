"""
pytmrobot._client — TMClientWrapper

薄包裝現有 TMClient，新增 send_and_recv_subcmd() 實現狀態讀取。
不修改 tm_listen_client.py 任何一行。
"""

from __future__ import annotations

import time

from ._protocol import TMClient, build_packet
from .exceptions import TMConnectionError, TMScriptError, TMTimeoutError


class TMClientWrapper:
    """包裝 TMClient，對外提供更高階的收發介面。

    主要新增 :meth:`send_and_recv_subcmd`，用於實作 ListenSend 狀態讀取。
    其餘方法直接委派給底層 TMClient。
    """

    def __init__(self, ip: str, port: int = 5890, timeout: float = 60.0) -> None:
        self._client = TMClient(ip=ip, port=port)
        self._timeout = timeout

    # ── 連線管理（委派） ──────────────────────────────────────────────────────

    def connect(self) -> None:
        """建立 TCP 連線並等待機器人進入 Listen Node。"""
        try:
            self._client.connect()
            self._client.wait_for_listen_node()
        except OSError as e:
            raise TMConnectionError(str(e)) from e

    def disconnect(self) -> None:
        """關閉 TCP 連線。"""
        self._client.disconnect()

    # ── 一般 script 發送（委派） ──────────────────────────────────────────────

    def send_script(self, script_id: str, lines: list[str]) -> bool:
        """發送 TMSCT，等待 OK/ERROR 回應（委派 TMClient.send_script）。

        Returns:
            True=OK, False=ERROR 或無回應
        """
        return self._client.send_script(script_id, lines)

    def send_script_checked(self, script_id: str, lines: list[str]) -> None:
        """發送 TMSCT，失敗時拋出 TMScriptError。"""
        ok = self.send_script(script_id, lines)
        if not ok:
            raise TMScriptError(f"指令執行失敗：{lines}", script_id=script_id)

    def wait_queue_tag(self, tag_id: int, poll_interval: float = 0.2) -> None:
        """等待 QueueTag 完成（委派 TMClient.wait_queue_tag）。"""
        self._client.wait_queue_tag(tag_id, poll_interval)

    def exit_listen(self, pass_exit: bool = True) -> None:
        """退出 Listen Node（委派 TMClient.exit_listen）。"""
        self._client.exit_listen(pass_exit)

    # ── 狀態讀取（ListenSend 往返） ───────────────────────────────────────────

    def send_and_recv_subcmd(
        self,
        script_id: str,
        lines: list[str],
        expected_subcmd: int = 90,
        timeout: float = 5.0,
    ) -> str:
        """發送含 ListenSend 的 script，等待 TMSCT OK 與 TMSTA SubCmd 回傳。

        使用狀態機接收迴圈，不假設封包到達順序：
        - TMSCT OK  → ok_received = True
        - TMSCT ERROR / CPERR → 拋出 TMScriptError
        - TMSTA subcmd == expected_subcmd → data_received = csv_string
        - TMSTA 其他 → 忽略（殘留 QueueTag 通知等）
        - ok_received AND data_received → 回傳 csv_string
        - 逾時 → 拋出 TMTimeoutError

        Args:
            script_id:       TMSCT 的 Script ID
            lines:           TMScript 行列表（最後一行應含 ListenSend）
            expected_subcmd: 期望的 TMSTA SubCmd（90-99）
            timeout:         等待逾時秒數

        Returns:
            TMSTA 回傳的資料字串（SubCmd 之後的部分）
        """
        # 發送封包
        pkt = build_packet("TMSCT", f"{script_id}," + "\r\n".join(lines))
        self._client.send_raw(pkt)

        ok_received   = False
        data_received: str | None = None
        deadline      = time.monotonic() + timeout
        orig_timeout  = self._client.sock.gettimeout() if self._client.sock else timeout

        while time.monotonic() < deadline:
            # 設短的 socket timeout 避免長時間阻塞
            if self._client.sock:
                self._client.sock.settimeout(min(0.5, deadline - time.monotonic()))

            try:
                pkt_dict = self._client.recv_packet()
            except TimeoutError:
                continue
            except Exception as e:
                raise TMConnectionError(str(e)) from e
            finally:
                if self._client.sock:
                    try:
                        self._client.sock.settimeout(orig_timeout)
                    except Exception:
                        pass

            if pkt_dict is None:
                continue

            hdr  = pkt_dict["header"]
            data = pkt_dict["data"]

            if hdr == "TMSCT":
                parts  = data.split(",", 1)
                status = parts[1] if len(parts) > 1 else ""
                if status.startswith("OK"):
                    ok_received = True
                else:
                    raise TMScriptError(status, script_id=script_id)

            elif hdr == "TMSTA":
                parts = data.split(",", 1)
                subcmd_str = parts[0].strip()
                try:
                    subcmd = int(subcmd_str)
                except ValueError:
                    continue
                if subcmd == expected_subcmd:
                    # data 欄位: "<subcmd>,<payload>"
                    data_received = parts[1] if len(parts) > 1 else ""

            elif hdr == "CPERR":
                raise TMScriptError(f"CPERR: {data}", script_id=script_id)

            if ok_received and data_received is not None:
                return data_received

        raise TMTimeoutError(
            f"等待 TMSTA SubCmd {expected_subcmd} 逾時（{timeout}s），"
            f"ok={ok_received}, data={data_received!r}"
        )

    # ── 底層存取 ──────────────────────────────────────────────────────────────

    @property
    def raw_client(self) -> TMClient:
        """取得底層 TMClient 實例（進階使用）。"""
        return self._client
