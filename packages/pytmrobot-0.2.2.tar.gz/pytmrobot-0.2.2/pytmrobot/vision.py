"""
pytmrobot.vision — VisionController

透過 robot.vision 存取。封裝 TM Robot 的視覺任務觸發與結果讀取功能。

TMScript 對應：Chapter 14 Vision
  - Vision_DoJob("JobName")                           → 觸發視覺任務並等待完成
  - Vision_IsJobAvailable("JobName")                  → 查詢任務是否有可用結果
  - GetOutputArrayValue("JobName", "VarName")         → 讀取輸出變數（字串）

使用流程：
  1. robot.vision.do_job("Job1")            — 觸發任務，等待偵測完成
  2. robot.vision.get_output("Job1", "Detect_Model_0")  — 讀取結果
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from . import script_builder as sb
from .types import Pose6

if TYPE_CHECKING:
    from ._client import TMClientWrapper
    from .tag_manager import TagManager


class VisionController:
    """視覺控制器。透過 ``robot.vision`` 存取。

    典型流程::

        # 觸發視覺任務並讀取辨識到的物件位姿
        if robot.vision.do_job("DetectPart"):
            pose = robot.vision.get_output_pose("DetectPart", "Detect_Model_0")
            robot.move.ptp(CartPoint(*pose), speed=20)
        else:
            print("未偵測到物件")

    多次呼叫時，同一 Listen Node session 內的 TMScript 變數（_vj、_va、_vo）
    僅在首次呼叫時宣告，後續呼叫改為賦值，避免 session 重複宣告錯誤。
    """

    def __init__(self, client: TMClientWrapper, tags: TagManager) -> None:
        self._client = client
        self._tags   = tags
        # 追蹤各 TMScript 變數的宣告狀態
        self._declared: dict[str, bool] = {}

    def _reset_session(self) -> None:
        """重設 session 狀態（重新連線時呼叫）。"""
        self._declared.clear()

    # ── 視覺任務 ──────────────────────────────────────────────────────────────

    def do_job(self, job_name: str) -> bool:
        """觸發視覺任務並等待執行完成。

        Args:
            job_name: TMflow 中的視覺任務名稱

        Returns:
            True=偵測成功（找到至少一個物件）；False=失敗（未找到或任務錯誤）

        Examples::

            if robot.vision.do_job("DetectScrew"):
                pose = robot.vision.get_output_pose("DetectScrew", "Detect_Model_0")
        """
        declared = self._declared.get("_vj", False)
        lines    = sb.build_vision_do_job(job_name, var_declared=declared)
        tag      = self._tags.next()
        csv      = self._client.send_and_recv_subcmd(f"vdo{tag}", lines)
        self._declared["_vj"] = True
        return csv.strip() in ("1", "true")

    def is_available(self, job_name: str) -> bool:
        """查詢視覺任務是否有可用的辨識結果（不觸發新任務）。

        Args:
            job_name: 視覺任務名稱

        Returns:
            True=有可用結果；False=無結果或結果已失效

        Examples::

            if robot.vision.is_available("DetectPart"):
                pose = robot.vision.get_output_pose("DetectPart", "Detect_Model_0")
        """
        declared = self._declared.get("_va", False)
        lines    = sb.build_vision_is_available(job_name, var_declared=declared)
        tag      = self._tags.next()
        csv      = self._client.send_and_recv_subcmd(f"vav{tag}", lines)
        self._declared["_va"] = True
        return csv.strip() in ("1", "true")

    def get_output(self, job_name: str, var_name: str) -> str:
        """讀取視覺任務的輸出變數值（原始字串）。

        Args:
            job_name: 視覺任務名稱
            var_name: 輸出變數名稱（如 ``"Detect_Model_0"``、``"ArmPose_0"``）

        Returns:
            原始字串值（格式依輸出型別而定，座標為逗號分隔數值）

        Examples::

            raw = robot.vision.get_output("Job1", "Detect_Model_0")
            # raw = "400.12,-100.5,280.0,180.0,0.0,90.0"
        """
        declared = self._declared.get("_vo", False)
        lines    = sb.build_vision_get_output(job_name, var_name, var_declared=declared)
        tag      = self._tags.next()
        result   = self._client.send_and_recv_subcmd(f"vgo{tag}", lines)
        self._declared["_vo"] = True
        return result.strip()

    def get_output_pose(self, job_name: str, var_name: str) -> Pose6:
        """讀取視覺任務輸出的 6D 位姿（X,Y,Z,Rx,Ry,Rz）。

        Args:
            job_name: 視覺任務名稱
            var_name: 輸出座標變數名稱

        Returns:
            Pose6 = (X, Y, Z, Rx, Ry, Rz)，單位 mm / °

        Raises:
            ValueError: 回傳字串無法解析為 6 個浮點數

        Examples::

            pose = robot.vision.get_output_pose("DetectPart", "ArmPose_0")
            robot.move.ptp(CartPoint(*pose), speed=20)
        """
        raw   = self.get_output(job_name, var_name)
        parts = [v.strip() for v in raw.split(",") if v.strip()]
        if len(parts) != 6:
            raise ValueError(
                f"get_output_pose 期望 6 個數值，但得到 {len(parts)} 個：{raw!r}"
            )
        return tuple(float(p) for p in parts)  # type: ignore[return-value]
