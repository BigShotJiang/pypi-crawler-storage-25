"""
pytmrobot.script_builder — TMScript 字串生成純函式模組。

本模組不依賴任何連線狀態，所有函式接受 Python 型別，
輸出合法的 TMScript 字串（或字串列表），可完整單元測試。

TMScript 命名規則（motion type string）：
  Line / Circle:
    第1字 C = 座標
    第2字 P=% / A=絕對連動 / D=絕對不連動
    第3字 P=% / R=半徑(mm)
  有效組合: CPP CPR CAP CAR CDP CDR (Line)
           CPP CAP CDP (Circle)
  PTP:
    CPP = 座標+%速度+%混合
    JPP = 關節+%速度+%混合
  Move_PTP / Move_Line 類似，加上 T(工具) 前綴。
"""

from __future__ import annotations

from collections.abc import Sequence
from typing import TYPE_CHECKING, Union

if TYPE_CHECKING:
    from .types import BlendUnit, CartPoint, JointPoint, SpeedUnit

# ── 內部工具 ──────────────────────────────────────────────────────────────────

def fmt_array(values: Sequence[float]) -> str:
    """將浮點數序列格式化為 TMScript 花括號陣列字面值。

    Examples::

        fmt_array([400.0, -100.0, 350.0, 180.0, 0.0, 90.0])
        # → '{400.0,-100.0,350.0,180.0,0.0,90.0}'
    """
    inner = ",".join(_fmt_float(v) for v in values)
    return "{" + inner + "}"


def _fmt_float(v: float) -> str:
    """格式化單一浮點數，移除不必要的尾數零但保留至少一位小數。"""
    s = f"{v:.6f}".rstrip("0")
    if s.endswith("."):
        s += "0"
    return s


def _motion_type_line(speed_unit: SpeedUnit, blend_unit: BlendUnit) -> str:
    """組合 Line/Circle 的 motion type 字串。"""
    return f"C{speed_unit.value}{blend_unit.value}"


def _build_queue_tag(tag_id: int, wait: bool) -> str:
    """生成 QueueTag TMScript 行。wait=True 時附帶等待旗標（第二參數 1）。"""
    return f"QueueTag({tag_id},1)" if wait else f"QueueTag({tag_id})"


def _build_robot_elems(prop: str, count: int) -> str:
    """生成 Robot[0].{prop}[0..count-1] 的 GetString 串接字串。

    Examples::

        _build_robot_elems("CoordRobot", 6)
        # → 'GetString(Robot[0].CoordRobot[0])+","+...+GetString(Robot[0].CoordRobot[5])'
    """
    return '+","+'.join(f"GetString(Robot[0].{prop}[{i}])" for i in range(count))


# ── PTP 運動 ──────────────────────────────────────────────────────────────────

def build_ptp(
    target: Union[CartPoint, JointPoint],
    speed: int,
    accel_ms: int,
    blend: int,
    tag_id: int,
    wait: bool = True,
) -> list[str]:
    """建立 PTP 運動的 TMScript 行列表。

    Returns:
        ['PTP("CPP",{...},speed,accel,blend,false)', 'QueueTag(n,1)']

    Examples::

        build_ptp(CartPoint(400,-100,350,180,0,90), 10, 200, 0, 1)
        # → ['PTP("CPP",{400.0,-100.0,350.0,180.0,0.0,90.0},10,200,0,false)',
        #    'QueueTag(1,1)']
    """
    from .types import CartPoint, JointPoint
    if isinstance(target, CartPoint):
        mtype = "CPP"
        arr = fmt_array(target.as_pose6())
    elif isinstance(target, JointPoint):
        mtype = "JPP"
        arr = fmt_array(target.as_pose6())
    else:
        raise TypeError(f"target 必須是 CartPoint 或 JointPoint，得到 {type(target)}")

    ptp_line = f'PTP("{mtype}",{arr},{speed},{accel_ms},{blend},false)'
    return [ptp_line, _build_queue_tag(tag_id, wait)]


# ── Line 直線運動 ─────────────────────────────────────────────────────────────

def build_line(
    target: CartPoint,
    speed_unit: SpeedUnit,
    blend_unit: BlendUnit,
    speed: int,
    accel_ms: int,
    blend: int,
    tag_id: int,
    wait: bool = True,
) -> list[str]:
    """建立 Line 直線運動的 TMScript 行列表。

    Examples::

        from pytmrobot.types import SpeedUnit, BlendUnit
        build_line(CartPoint(450,-100,350,180,0,90),
                   SpeedUnit.ABS_LOCK, BlendUnit.PERCENT,
                   150, 200, 0, 2)
        # → ['Line("CDP",{450.0,-100.0,350.0,180.0,0.0,90.0},150,200,0,false)',
        #    'QueueTag(2,1)']
    """
    mtype = _motion_type_line(speed_unit, blend_unit)
    arr   = fmt_array(target.as_pose6())
    line  = f'Line("{mtype}",{arr},{speed},{accel_ms},{blend},false)'
    return [line, _build_queue_tag(tag_id, wait)]


# ── Circle 圓弧運動 ───────────────────────────────────────────────────────────

def build_circle(
    via: CartPoint,
    end: CartPoint,
    speed_unit: SpeedUnit,
    speed: int,
    accel_ms: int,
    blend: int,
    angle: int,
    tag_id: int,
    wait: bool = True,
) -> list[str]:
    """建立 Circle 圓弧運動的 TMScript 行列表。

    Circle motion type 僅支援 PERCENT blend（第3字固定 P）。

    Args:
        via:   圓弧上任意一點（非起點非終點）
        end:   圓弧終點
        angle: 0=運動至 end，非0=依指定角度（°）運動
    """
    mtype    = f"C{speed_unit.value}P"
    via_arr  = fmt_array(via.as_pose6())
    end_arr  = fmt_array(end.as_pose6())
    line     = f'Circle("{mtype}",{via_arr},{end_arr},{speed},{accel_ms},{blend},{angle},false)'
    return [line, _build_queue_tag(tag_id, wait)]


# ── 相對運動 ──────────────────────────────────────────────────────────────────

def build_move_ptp(
    delta: Union[CartPoint, JointPoint],
    speed: int,
    accel_ms: int,
    blend: int,
    tag_id: int,
    wait: bool = True,
) -> list[str]:
    """建立 Move_PTP 相對 PTP 運動的 TMScript 行列表。

    CartPoint delta → Move_PTP("CPP", ...)
    JointPoint delta → Move_PTP("JPP", ...)
    """
    from .types import CartPoint, JointPoint
    if isinstance(delta, CartPoint):
        mtype = "CPP"
    elif isinstance(delta, JointPoint):
        mtype = "JPP"
    else:
        raise TypeError("delta 必須是 CartPoint 或 JointPoint")

    arr  = fmt_array(delta.as_pose6())
    line = f'Move_PTP("{mtype}",{arr},{speed},{accel_ms},{blend},false)'
    return [line, _build_queue_tag(tag_id, wait)]


def build_move_line(
    delta: CartPoint,
    speed_unit: SpeedUnit,
    blend_unit: BlendUnit,
    speed: int,
    accel_ms: int,
    blend: int,
    tag_id: int,
    wait: bool = True,
) -> list[str]:
    """建立 Move_Line 相對直線運動的 TMScript 行列表。"""
    mtype = _motion_type_line(speed_unit, blend_unit)
    arr   = fmt_array(delta.as_pose6())
    line  = f'Move_Line("{mtype}",{arr},{speed},{accel_ms},{blend},false)'
    return [line, _build_queue_tag(tag_id, wait)]


# ── IO 控制 ───────────────────────────────────────────────────────────────────

def build_set_do(pin: int, value: bool, module: str, instant: bool) -> str:
    """建立數位輸出賦值的 TMScript 行。

    Examples::

        build_set_do(2, True, "ControlBox", False)
        # → 'IO["ControlBox"].DO[2] = 1'

        build_set_do(0, False, "ControlBox", True)
        # → 'IO["ControlBox"].InstantDO[0] = 0'
    """
    prop = "InstantDO" if instant else "DO"
    val  = 1 if value else 0
    return f'IO["{module}"].{prop}[{pin}] = {val}'


def build_set_ao(pin: int, voltage: float, module: str, instant: bool) -> str:
    """建立類比輸出賦值的 TMScript 行。

    Examples::

        build_set_ao(0, 3.3, "ControlBox", False)
        # → 'IO["ControlBox"].AO[0] = 3.3'
    """
    prop = "InstantAO" if instant else "AO"
    v    = _fmt_float(voltage)
    return f'IO["{module}"].{prop}[{pin}] = {v}'


# ── 狀態讀取（ListenSend） ────────────────────────────────────────────────────

def build_read_tcp_position() -> list[str]:
    """建立讀取 TCP 位置並透過 TMSTA SubCmd 90 回傳的 TMScript 行列表。

    回傳格式：CSV 字串 "x,y,z,rx,ry,rz"

    實作注意：直接存取 Robot[0].CoordRobot[i] 元素（不使用中間變數），
    可避免 Listen Node session 變數重複宣告問題。
    """
    return [f'ListenSend(90, {_build_robot_elems("CoordRobot", 6)})']


def build_read_joint_angles() -> list[str]:
    """建立讀取關節角度並透過 TMSTA SubCmd 90 回傳的 TMScript 行列表。

    回傳格式：CSV 字串 "j1,j2,j3,j4,j5,j6"
    """
    return [f'ListenSend(90, {_build_robot_elems("Joint", 6)})']


def build_read_di(pin: int, module: str) -> list[str]:
    """建立讀取單一 DI 並透過 TMSTA SubCmd 90 回傳的 TMScript 行列表。

    回傳格式："0" 或 "1"
    """
    return [f'ListenSend(90, GetString(IO["{module}"].DI[{pin}]))']


def build_read_do(pin: int, module: str) -> list[str]:
    """建立讀取單一 DO 並透過 TMSTA SubCmd 90 回傳的 TMScript 行列表。"""
    return [f'ListenSend(90, GetString(IO["{module}"].DO[{pin}]))']


def build_read_ai(pin: int, module: str) -> list[str]:
    """建立讀取單一 AI 並透過 TMSTA SubCmd 90 回傳的 TMScript 行列表。"""
    return [f'ListenSend(90, GetString(IO["{module}"].AI[{pin}]))']


def build_read_tcp_force() -> list[str]:
    """建立讀取 TCP 合力並透過 TMSTA SubCmd 90 回傳的 TMScript 行列表。"""
    return ['ListenSend(90, GetString(Robot[0].TCPForce3D))']


def build_read_tcp_speed() -> list[str]:
    """建立讀取 TCP 合速度並透過 TMSTA SubCmd 90 回傳的 TMScript 行列表。"""
    return ['ListenSend(90, GetString(Robot[0].TCPSpeed3D))']


def build_read_all_io(module: str, vars_declared: bool = False) -> list[str]:
    """建立批次讀取全部 DI/DO/AI/AO 並透過 TMSTA SubCmd 90 回傳的 TMScript 行列表。

    回傳格式（以 | 分隔各組，各組以 GetString(array) 回傳 {v0,v1,...} 格式）：
    "DI:{d0,d1,...}|DO:{d0,...}|AI:{a0,...}|AO:{a0,...}"

    使用陣列層級 GetString 保持腳本長度在機器人限制內（約 300 bytes），
    比逐元素展開的 ~1400 bytes 短得多。

    Args:
        module:        模組名稱（"ControlBox" / "EndModule" 等）
        vars_declared: True 表示 Listen Node session 內變數已宣告（用賦值取代宣告）。
                       IOController 在首次呼叫後自動設為 True。
    """
    if vars_declared:
        # 變數已存在，改用賦值（不加型別），避免 session 內重複宣告錯誤
        return [
            f'_io_di = IO["{module}"].DI',
            f'_io_do = IO["{module}"].DO',
            f'_io_ai = IO["{module}"].AI',
            f'_io_ao = IO["{module}"].AO',
            'ListenSend(90, "DI:"+GetString(_io_di)'
            '+"|DO:"+GetString(_io_do)'
            '+"|AI:"+GetString(_io_ai)'
            '+"|AO:"+GetString(_io_ao))',
        ]
    else:
        # 首次呼叫：宣告新變數
        return [
            f'byte[]  _io_di = IO["{module}"].DI',
            f'byte[]  _io_do = IO["{module}"].DO',
            f'float[] _io_ai = IO["{module}"].AI',
            f'float[] _io_ao = IO["{module}"].AO',
            'ListenSend(90, "DI:"+GetString(_io_di)'
            '+"|DO:"+GetString(_io_do)'
            '+"|AI:"+GetString(_io_ai)'
            '+"|AO:"+GetString(_io_ao))',
        ]


def build_batch_snapshot() -> list[str]:
    """建立一次讀取所有重要狀態並透過 TMSTA SubCmd 90 回傳的 TMScript 行列表。

    回傳格式（CSV，固定欄位順序）：
    "px,py,pz,prx,pry,prz,j1,j2,j3,j4,j5,j6,force3d,speed3d,base,tcp,payload"

    實作注意：對 Robot[0].CoordRobot 和 Robot[0].Joint 使用逐元素直接存取，
    不宣告 float[] 陣列變數（這些變數在此韌體版本無法從 Robot[0].CoordRobot 賦值）。
    """
    tcp_elems   = _build_robot_elems("CoordRobot", 6)
    joint_elems = _build_robot_elems("Joint", 6)
    concat = (
        f'{tcp_elems}'
        f'+","+{joint_elems}'
        '+","+GetString(Robot[0].TCPForce3D)'
        '+","+GetString(Robot[0].TCPSpeed3D)'
        '+","+Robot[0].BaseName'
        '+","+Robot[0].TCPName'
        '+","+GetString(Robot[0].Payload)'
    )
    return [f'ListenSend(90, {concat})']


# ── 基礎控制 ──────────────────────────────────────────────────────────────────

def build_sleep(ms: int) -> str:
    """Sleep(ms) — 在機器人端等待。"""
    return f"Sleep({ms})"


def build_stop(mode: int) -> str:
    """StopAndClearBuffer(mode)。

    mode: 0=清除運動緩衝, 1=清除全部, 2=清除運動+條件等待
    """
    return f"StopAndClearBuffer({mode})"


def build_change_base(name: str) -> str:
    return f'ChangeBase("{name}")'


def build_change_tcp(name: str) -> str:
    return f'ChangeTCP("{name}")'


def build_change_load(kg: float) -> str:
    return f"ChangeLoad({_fmt_float(kg)})"


def build_script_exit(success: bool) -> str:
    return f"ScriptExit({1 if success else 0})"


def build_wait_for(condition_expr: str, timeout_ms: int = -1) -> str:
    """WaitFor(condition, timeout_ms)。timeout_ms=-1 表示無限等待。"""
    return f"WaitFor({condition_expr},{timeout_ms})"


# ── MDecision（Ch10）──────────────────────────────────────────────────────────

def build_decision_ask(
    title:      str,
    message:    str,
    choices:    list[str],
    timeout_ms: int,
    *,
    declared: bool,
) -> list[str]:
    """建立 MDecision 詢問對話框的 TMScript 行列表。

    Args:
        title:      對話框標題
        message:    說明文字
        choices:    按鈕文字列表（1-3 個）
        timeout_ms: 逾時毫秒（-1=無限等待）；逾時時回傳最後一個索引
        declared:   True 表示 _md / _r 已在 Listen Node session 中宣告
                    （用 Reset()+賦值 取代重新宣告，避免 ERROR;1）

    Returns:
        以 ListenSend(90, GetString(_r)) 結尾；需用 send_and_recv_subcmd 接收結果。

    Examples::

        build_decision_ask("繼續？", "確認後繼續", ["確認", "取消"], -1, declared=False)
        # → ['MDecision _md = "繼續？", "確認後繼續"',
        #    '_md.Case(0, "確認")',
        #    '_md.Case(1, "取消")',
        #    'int _r = _md.Show()',
        #    'ListenSend(90, GetString(_r))']
    """
    lines: list[str] = []
    if not declared:
        lines.append(f'MDecision _md = "{title}", "{message}"')
    else:
        lines += [
            '_md.Reset()',
            f'_md.Title("{title}")',
            f'_md.Description("{message}")',
        ]

    for i, ch in enumerate(choices):
        lines.append(f'_md.Case({i}, "{ch}")')

    if timeout_ms > 0:
        # 逾時預設回傳最後一個索引
        lines.append(f'_md.Timeout({timeout_ms}, {len(choices) - 1})')

    lines.append('int _r = _md.Show()' if not declared else '_r = _md.Show()')
    lines.append('ListenSend(90, GetString(_r))')
    return lines


def build_popup(title: str, message: str, timeout_ms: int, tag_id: int) -> list[str]:
    """建立 Popup 提示對話框（OK 按鈕，無回傳值）的 TMScript 行列表。

    Args:
        tag_id: QueueTag ID，用於等待操作員確認後的 TMSCT OK 回應

    Examples::

        build_popup("提示", "請放置工件", -1, 1)
        # → ['Popup("提示", "請放置工件", -1)', 'QueueTag(1,1)']
    """
    tm = timeout_ms if timeout_ms > 0 else -1
    return [f'Popup("{title}", "{message}", {tm})', _build_queue_tag(tag_id, True)]


# ── PVT 軌跡（Ch13）───────────────────────────────────────────────────────────

def build_pvt_enter(mode_int: int) -> str:
    """PVTEnter(mode)。1=笛卡爾, 2=關節。"""
    return f"PVTEnter({mode_int})"


def build_pvt_point(
    mtype:    str,
    target:   Sequence[float],
    velocity: Sequence[float],
    time_ms:  int,
) -> str:
    """PVTPoint("{mtype}", {pos}, {vel}, time_ms)。

    Args:
        mtype:    "CPP"（笛卡爾）或 "JPP"（關節）
        target:   目標位置 6 元素序列
        velocity: 到達目標時的速度向量 6 元素序列
        time_ms:  從上一點到此點的執行時間，ms

    Examples::

        build_pvt_point("CPP", [400,0,350,180,0,90], [10,0,0,0,0,0], 1000)
        # → 'PVTPoint("CPP",{400.0,...},{10.0,...},1000)'
    """
    return f'PVTPoint("{mtype}",{fmt_array(target)},{fmt_array(velocity)},{time_ms})'


def build_pvt_pause() -> str:
    """PVTPause() — 暫停 PVT 軌跡執行。"""
    return "PVTPause()"


def build_pvt_resume() -> str:
    """PVTResume() — 繼續 PVT 軌跡執行。"""
    return "PVTResume()"


def build_pvt_exit(tag_id: int, wait: bool = True) -> list[str]:
    """PVTExit() + QueueTag(n,1)。

    Returns:
        ['PVTExit()', 'QueueTag(n,1)']  或 ['PVTExit()', 'QueueTag(n)']
    """
    return ["PVTExit()", _build_queue_tag(tag_id, wait)]


# ── Modbus（Ch16）──────────────────────────────────────────────────────────────

# ── Vision（Ch14）──────────────────────────────────────────────────────────────

def build_vision_do_job(job_name: str, *, var_declared: bool) -> list[str]:
    """建立 Vision_DoJob 並透過 ListenSend 回傳執行結果（bool）的 TMScript 行列表。

    Args:
        job_name:     TMflow 中的視覺任務名稱
        var_declared: _vj 是否已在 session 中宣告

    Returns:
        以 ListenSend(90, GetString(_vj)) 結尾；"1"=偵測成功，"0"=失敗

    Examples::

        build_vision_do_job("Job1", var_declared=False)
        # → ['bool _vj = Vision_DoJob("Job1")',
        #    'ListenSend(90, GetString(_vj))']
    """
    expr = f'Vision_DoJob("{job_name}")'
    if not var_declared:
        return [f'bool _vj = {expr}', 'ListenSend(90, GetString(_vj))']
    return [f'_vj = {expr}', 'ListenSend(90, GetString(_vj))']


def build_vision_is_available(job_name: str, *, var_declared: bool) -> list[str]:
    """建立 Vision_IsJobAvailable 查詢行列表。

    Examples::

        build_vision_is_available("Job1", var_declared=False)
        # → ['bool _va = Vision_IsJobAvailable("Job1")',
        #    'ListenSend(90, GetString(_va))']
    """
    expr = f'Vision_IsJobAvailable("{job_name}")'
    if not var_declared:
        return [f'bool _va = {expr}', 'ListenSend(90, GetString(_va))']
    return [f'_va = {expr}', 'ListenSend(90, GetString(_va))']


def build_vision_get_output(
    job_name: str,
    var_name: str,
    *,
    var_declared: bool,
) -> list[str]:
    """建立 GetOutputArrayValue 讀取視覺輸出變數的 TMScript 行列表。

    Args:
        job_name:     TMflow 視覺任務名稱
        var_name:     輸出變數名稱（如 ``"Detect_Model_0"``）
        var_declared: _vo 是否已在 session 中宣告

    Returns:
        以 ListenSend(90, _vo) 結尾；回傳原始字串（逗號分隔座標或標籤值）

    Examples::

        build_vision_get_output("Job1", "Detect_Model_0", var_declared=False)
        # → ['string _vo = GetOutputArrayValue("Job1", "Detect_Model_0")',
        #    'ListenSend(90, _vo)']
    """
    expr = f'GetOutputArrayValue("{job_name}", "{var_name}")'
    if not var_declared:
        return [f'string _vo = {expr}', 'ListenSend(90, _vo)']
    return [f'_vo = {expr}', 'ListenSend(90, _vo)']


def build_modbus_connect(ip: str, port: int, *, mbus_declared: bool) -> list[str]:
    """建立 ModbusTCP 裝置物件並開啟連線的 TMScript 行列表。

    裝置固定命名為 ``_mbus``（Listen Node session 全域）。

    Args:
        mbus_declared: True 表示 _mbus 已在 session 中宣告，只需重新開啟連線。

    Examples::

        build_modbus_connect("192.168.1.10", 502, mbus_declared=False)
        # → ['ModbusTCP _mbus = "192.168.1.10", 502', 'modbus_open("_mbus")']

        build_modbus_connect("192.168.1.10", 502, mbus_declared=True)
        # → ['modbus_open("_mbus")']
    """
    if not mbus_declared:
        return [f'ModbusTCP _mbus = "{ip}", {port}', 'modbus_open("_mbus")']
    return ['modbus_open("_mbus")']


def build_modbus_disconnect() -> list[str]:
    """關閉 Modbus 連線的 TMScript 行列表。

    Examples::

        build_modbus_disconnect()
        # → ['modbus_close("_mbus")']
    """
    return ['modbus_close("_mbus")']


# ── TouchStop（Ch21）──────────────────────────────────────────────────────────

def build_touchstop_setup(
    direction:  int,
    distance:   float,
    force:      float,
    speed:      int,
    *,
    mode:         str  = "Compliance",
    frame:        int  = 1,
    timeout_ms:   int  = -1,
    obj_declared: bool = False,
) -> list[str]:
    """建立 TouchStop 設定行列表（不含 Start()）。

    Args:
        direction:    偵測軸方向代碼（見 TMScript ch21 Touch.Single()）
        distance:     最大偵測距離（mm）
        force:        觸發力閾值（N）
        speed:        運動速度（%）
        mode:         觸停模式字串（預設 "Compliance"）
        frame:        座標系（1=機器人基座, 2=工具, 3=使用者）
        timeout_ms:   逾時毫秒（-1=不設定）
        obj_declared: _ts 是否已在 session 中宣告

    Examples::

        build_touchstop_setup(16, 50.0, 5.0, 10, obj_declared=False)
        # → ['TouchStop _ts = "Compliance"', '_ts.Frame(1)',
        #    '_ts.Single(16, 50.0, 5.0, 10)']
    """
    lines: list[str] = []
    if not obj_declared:
        lines.append(f'TouchStop _ts = "{mode}"')
    else:
        lines.append("_ts.Reset()")
    lines.append(f"_ts.Frame({frame})")
    lines.append(f"_ts.Single({direction}, {_fmt_float(distance)}, {_fmt_float(force)}, {speed})")
    if timeout_ms > 0:
        lines.append(f"_ts.Timeout({timeout_ms})")
    return lines


# ── Compliance（Ch20）──────────────────────────────────────────────────────────

def build_compliance_setup(
    direction:  int,
    distance:   float,
    force:      float,
    speed:      int,
    *,
    frame:           int  = 1,
    timeout_ms:      int  = -1,
    high_resistance: bool = False,
    obj_declared:    bool = False,
) -> list[str]:
    """建立 Compliance 設定行列表（不含 Start()）。

    Args:
        direction:       偵測軸方向代碼（見 TMScript ch20 Compliance.Single()）
        distance:        最大順從移動距離（mm）
        force:           目標/閾值力（N）
        speed:           運動速度（%）
        frame:           座標系（1=機器人基座, 2=工具, 3=使用者）
        timeout_ms:      逾時毫秒（-1=不設定）
        high_resistance: 啟用高阻力偵測
        obj_declared:    _cp 是否已在 session 中宣告

    Examples::

        build_compliance_setup(16, 30.0, 3.0, 5, obj_declared=False)
        # → ['Compliance _cp', '_cp.Frame(1)', '_cp.Single(16, 30.0, 3.0, 5)']
    """
    lines: list[str] = []
    if not obj_declared:
        lines.append("Compliance _cp")
    else:
        lines.append("_cp.Reset()")
    lines.append(f"_cp.Frame({frame})")
    lines.append(f"_cp.Single({direction}, {_fmt_float(distance)}, {_fmt_float(force)}, {speed})")
    if timeout_ms > 0:
        lines.append(f"_cp.Timeout({timeout_ms})")
    if high_resistance:
        lines.append("_cp.HighResistance(true)")
    return lines


# ── Force（Ch22）──────────────────────────────────────────────────────────────

def build_ftsensor_open(model: str, *, fts_declared: bool) -> list[str]:
    """建立 FTSensor 宣告行（僅首次呼叫需要宣告）。

    Args:
        model:        感測器型號字串（如 "ATI"）
        fts_declared: _fts 是否已在 session 中宣告

    Returns:
        首次宣告：['FTSensor _fts = "model"']；已宣告：[]

    Examples::

        build_ftsensor_open("ATI", fts_declared=False)
        # → ['FTSensor _fts = "ATI"']

        build_ftsensor_open("ATI", fts_declared=True)
        # → []
    """
    if not fts_declared:
        return [f'FTSensor _fts = "{model}"']
    return []


def build_force_setup(
    axis_settings: list[tuple[str, bool, float, int]],
    *,
    frame:        int   = 1,
    timeout_ms:   int   = -1,
    distance_mm:  float = -1.0,
    obj_declared: bool  = False,
) -> list[str]:
    """建立 Force 控制設定行列表（不含 Start()）。

    Args:
        axis_settings: 軸設定列表，每項為 (axis, enabled, value, pid)。
                       axis: "Fx"/"Fy"/"Fz"/"Mx"/"My"/"Mz"
                       enabled: 是否啟用此軸
                       value:   目標力/力矩值
                       pid:     PID 增益組索引
        frame:         座標系（1=機器人基座, 2=工具, 3=使用者）
        timeout_ms:    逾時毫秒（-1=不設定）
        distance_mm:   最大移動距離（mm，-1=不限）
        obj_declared:  _fc 是否已在 session 中宣告

    Examples::

        build_force_setup([("Fz", True, 5.0, 2)], obj_declared=False)
        # → ['Force _fc = "_fts"', '_fc.Frame(1)', '_fc.FTSet("Fz", true, 5.0, 2)']
    """
    lines: list[str] = []
    if not obj_declared:
        lines.append('Force _fc = "_fts"')
    else:
        lines.append("_fc.Reset()")
    lines.append(f"_fc.Frame({frame})")
    for axis, enabled, value, pid in axis_settings:
        en = "true" if enabled else "false"
        lines.append(f'_fc.FTSet("{axis}", {en}, {_fmt_float(value)}, {pid})')
    if distance_mm > 0:
        lines.append(f"_fc.Distance({_fmt_float(distance_mm)})")
    if timeout_ms > 0:
        lines.append(f"_fc.Timeout({timeout_ms})")
    return lines


# ── SerialPort（Ch08）────────────────────────────────────────────────────────

def _bytes_to_tm(data: bytes) -> str:
    """將 Python bytes 轉換為 TMScript byte[] 字面值。

    Examples::

        _bytes_to_tm(b"\\x01\\x03\\x00\\x00")
        # → '{1,3,0,0}'
    """
    return "{" + ",".join(str(b) for b in data) + "}"


def build_serial_open(
    port:       str,
    baudrate:   int,
    parity:     str = "none",
    data_bits:  int = 8,
    stop_bits:  int = 1,
    timeout_ms: int = -1,
    *,
    sp_declared: bool,
) -> list[str]:
    """建立 SerialPort 宣告（首次）並開啟埠口的 TMScript 行列表。

    TMScript 變數 ``_sp`` 在 Listen Node session 中只能宣告一次；
    ``sp_declared=True`` 時跳過宣告，直接呼叫 ``com_open``。

    Examples::

        build_serial_open("COM3", 9600, sp_declared=False)
        # → ['SerialPort _sp = "COM3", 9600, "none", 8, 1', 'com_open("_sp")']

        build_serial_open("COM3", 115200, sp_declared=True)
        # → ['com_open("_sp")']
    """
    lines: list[str] = []
    if not sp_declared:
        params = f'"{port}", {baudrate}, "{parity}", {data_bits}, {stop_bits}'
        if timeout_ms > 0:
            params += f", {timeout_ms}"
        lines.append(f"SerialPort _sp = {params}")
    lines.append('com_open("_sp")')
    return lines


def build_serial_close() -> list[str]:
    """關閉串列埠的 TMScript 行列表。

    Examples::

        build_serial_close()
        # → ['com_close("_sp")']
    """
    return ['com_close("_sp")']


def build_serial_write_bytes(data: bytes) -> list[str]:
    """以 byte[] 寫入串列埠的 TMScript 行列表。

    Examples::

        build_serial_write_bytes(b"\\x01\\x03")
        # → ['com_write("_sp", {1,3})']
    """
    return [f'com_write("_sp", {_bytes_to_tm(data)})']


def build_serial_write_string(text: str) -> list[str]:
    """以字串寫入串列埠（不加換行）的 TMScript 行列表。

    Examples::

        build_serial_write_string("AT+VER")
        # → ['com_write("_sp", "AT+VER")']
    """
    return [f'com_write("_sp", "{text}")']


def build_serial_writeline(text: str) -> list[str]:
    """以字串寫入串列埠並附加 \\r\\n 的 TMScript 行列表。

    Examples::

        build_serial_writeline("AT+VER")
        # → ['com_writeline("_sp", "AT+VER")']
    """
    return [f'com_writeline("_sp", "{text}")']


def build_serial_read_bytes(
    count:      int,
    timeout_ms: int,
    *,
    rx_declared: bool,
) -> list[str]:
    """讀取指定數量 bytes 並透過 TMSTA SubCmd 90 回傳的 TMScript 行列表。

    回傳格式：``{b0,b1,...}``（GetString(byte[]) 輸出）

    Args:
        count:       要讀取的位元組數
        timeout_ms:  讀取逾時毫秒
        rx_declared: True 表示 ``_sp_rx`` 已在 session 中宣告

    Examples::

        build_serial_read_bytes(8, 200, rx_declared=False)
        # → ['byte[] _sp_rx = com_read("_sp", 8, 200)',
        #    'ListenSend(90, GetString(_sp_rx))']
    """
    read_expr = f'com_read("_sp", {count}, {timeout_ms})'
    if not rx_declared:
        return [f"byte[] _sp_rx = {read_expr}", "ListenSend(90, GetString(_sp_rx))"]
    return [f"_sp_rx = {read_expr}", "ListenSend(90, GetString(_sp_rx))"]


def build_serial_read_string(
    count:      int,
    timeout_ms: int,
    *,
    rs_declared: bool,
) -> list[str]:
    """讀取指定數量字元（字串）並透過 TMSTA SubCmd 90 回傳的 TMScript 行列表。

    Args:
        count:       要讀取的字元數
        timeout_ms:  讀取逾時毫秒
        rs_declared: True 表示 ``_sp_rs`` 已在 session 中宣告

    Examples::

        build_serial_read_string(16, 500, rs_declared=False)
        # → ['string _sp_rs = com_read_string("_sp", 16, 500)',
        #    'ListenSend(90, _sp_rs)']
    """
    read_expr = f'com_read_string("_sp", {count}, {timeout_ms})'
    if not rs_declared:
        return [f"string _sp_rs = {read_expr}", "ListenSend(90, _sp_rs)"]
    return [f"_sp_rs = {read_expr}", "ListenSend(90, _sp_rs)"]


def build_modbus_preset(
    name:      str,
    slave_id:  int,
    reg_type:  str,
    addr:      int,
    dtype:     str,
    extra:     int,
    *,
    var_declared: bool,
) -> list[str]:
    """建立 Modbus Preset 設置的 TMScript 行列表，以 ListenSend 回傳設置結果。

    Args:
        name:         預設名稱（英數字組合）
        slave_id:     Slave ID（0=廣播）
        reg_type:     暫存器類型 "DO"/"DI"/"RO"/"RI"
        addr:         起始位址
        dtype:        資料型別 "bool"/"byte"/"int16"/"int32"/"float"/"double"/"string"
        extra:        附加參數：int32/float/double → 0=LE, 1=BE；string → 個數
        var_declared: _mb_pr 是否已宣告

    Examples::

        build_modbus_preset("light", 1, "DO", 7206, "bool", 1, var_declared=False)
        # → ['bool _mb_pr = _mbus.Preset("light", 1, "DO", 7206, "bool", 1)',
        #    'ListenSend(90, GetString(_mb_pr))']
    """
    expr = f'_mbus.Preset("{name}", {slave_id}, "{reg_type}", {addr}, "{dtype}", {extra})'
    if not var_declared:
        return [f'bool _mb_pr = {expr}', 'ListenSend(90, GetString(_mb_pr))']
    return [f'_mb_pr = {expr}', 'ListenSend(90, GetString(_mb_pr))']
