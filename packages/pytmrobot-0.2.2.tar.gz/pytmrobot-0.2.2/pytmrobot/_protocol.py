"""
pytmrobot._protocol — TM Robot Listen Node 底層通訊協定。

包含封包編解碼與 TMClient 類別。
原始碼源自 tm_listen_client.py（同 repo），
抽出為獨立私有模組以支援 PyPI 打包安裝。
"""

from __future__ import annotations

import re
import socket
import time

# ── 封包工具 ─────────────────────────────────────────────────────────────────


def calc_checksum(raw: str) -> str:
    """計算封包 checksum：對 $ 與 * 之間的所有位元組做 XOR。

    raw 為完整字串，含頭尾的 $ 與 *，但不含 \\r\\n。
    例如 raw = "$TMSCT,5,10,OK,*"

    使用 rindex 找最後一個 *（checksum 分隔符），
    避免 TMScript 腳本內容含乘法符號 * 時計算出錯（CPERR 02）。
    """
    inner = raw[1 : raw.rindex("*")]
    cs = 0
    for ch in inner.encode("utf-8"):
        cs ^= ch
    return format(cs, "02X")


def build_packet(header: str, data: str) -> bytes:
    """建立封包並計算 checksum。

    Args:
        header: ``'TMSCT'`` | ``'TMSTA'``
        data:   資料欄位字串（不含 checksum）
    """
    length = len(data.encode("utf-8"))
    raw = f"${header},{length},{data},*"
    cs = calc_checksum(raw)
    packet = f"{raw}{cs}\r\n"
    return packet.encode("utf-8")


def parse_packet(line: str) -> dict | None:
    """解析一行機器人回覆，回傳 dict 或 None（格式錯誤時）。"""
    line = line.strip()
    if not line.startswith("$"):
        return None
    m = re.match(r"^\$([^,]+),(\d+),(.+),\*([0-9A-Fa-f]{2})$", line)
    if not m:
        return None
    header, length, data, cs = m.groups()
    return {"header": header, "length": int(length), "data": data, "cs": cs}


# ── TMClient ─────────────────────────────────────────────────────────────────

_DEFAULT_TIMEOUT = 60.0


class TMClient:
    """TM Robot Listen Node TCP 客戶端。

    提供底層 send/recv 與常用操作（等待 Listen Node、送指令、等 QueueTag）。
    """

    def __init__(self, ip: str, port: int = 5890, timeout: float = _DEFAULT_TIMEOUT):
        self.ip = ip
        self.port = port
        self.sock: socket.socket | None = None
        self._buf = ""

    # ── 連線 / 斷線 ──────────────────────────────────────────────────────────

    def connect(self) -> None:
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.sock.settimeout(_DEFAULT_TIMEOUT)
        self.sock.connect((self.ip, self.port))

    def disconnect(self) -> None:
        if self.sock:
            self.sock.close()
            self.sock = None

    # ── 底層收發 ─────────────────────────────────────────────────────────────

    def _recv_line(self) -> str:
        """從緩衝區讀取一行（以 \\r\\n 結尾）。"""
        assert self.sock is not None
        while "\r\n" not in self._buf:
            chunk = self.sock.recv(4096).decode("utf-8", errors="replace")
            if not chunk:
                raise ConnectionError("連線中斷")
            self._buf += chunk
        line, self._buf = self._buf.split("\r\n", 1)
        return line

    def recv_packet(self) -> dict | None:
        """接收並解析一個封包。"""
        line = self._recv_line()
        return parse_packet(line)

    def send_raw(self, packet: bytes) -> None:
        assert self.sock is not None
        self.sock.sendall(packet)

    # ── 等待 Listen Node ─────────────────────────────────────────────────────

    def wait_for_listen_node(self) -> None:
        """確保機器人已進入 Listen Node。"""
        if self.query_listen_mode():
            return
        while True:
            pkt = self.recv_packet()
            if pkt and pkt["header"] == "TMSCT":
                return

    def query_listen_mode(self) -> bool:
        """SubCmd 00：查詢是否已進入外部 Script 控制模式。"""
        pkt = build_packet("TMSTA", "00")
        self.send_raw(pkt)
        resp = self.recv_packet()
        if resp and resp["header"] == "TMSTA":
            return resp["data"].split(",")[1].lower() == "true"
        return False

    # ── 發送 TMScript 指令 ────────────────────────────────────────────────────

    def send_script(self, script_id: str, script_lines: list[str]) -> bool:
        """發送一或多行 TMScript，等待 OK/ERROR 回應。"""
        data = f"{script_id}," + "\r\n".join(script_lines)
        pkt = build_packet("TMSCT", data)
        self.send_raw(pkt)

        while True:
            resp = self.recv_packet()
            if not resp:
                return False
            if resp["header"] == "TMSTA":
                continue
            if resp["header"] == "TMSCT":
                parts = resp["data"].split(",", 1)
                status = parts[1] if len(parts) > 1 else ""
                return status.startswith("OK")
            if resp["header"] == "CPERR":
                return False

    # ── 等待 QueueTag ─────────────────────────────────────────────────────────

    def wait_queue_tag(self, tag_id: int, poll_interval: float = 0.2) -> None:
        """等待機器人完成指定的 QueueTag（輪詢）。"""
        while True:
            pkt = build_packet("TMSTA", f"01,{tag_id}")
            self.send_raw(pkt)
            resp = self.recv_packet()
            if resp and resp["header"] == "TMSTA":
                parts = resp["data"].split(",")
                if len(parts) >= 3 and parts[2].lower() == "true":
                    return
            time.sleep(poll_interval)

    # ── 退出 Listen Node ──────────────────────────────────────────────────────

    def exit_listen(self, pass_exit: bool = True) -> None:
        """發送 ScriptExit() 退出 Listen Node。"""
        cmd = "ScriptExit(1)" if pass_exit else "ScriptExit(0)"
        self.send_script("exit", [cmd])
