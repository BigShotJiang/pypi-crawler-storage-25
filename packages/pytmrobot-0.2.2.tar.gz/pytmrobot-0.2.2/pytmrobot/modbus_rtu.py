"""
pytmrobot.modbus_rtu — ModbusRTU

透過機器人控制箱串列埠（RS485）收發 Modbus RTU 協定訊框。
底層使用 ``SerialPortController`` 進行位元組收發。

支援功能碼：
  FC01  讀取線圈（Read Coils）
  FC02  讀取離散輸入（Read Discrete Inputs）
  FC03  讀取保持暫存器（Read Holding Registers）
  FC04  讀取輸入暫存器（Read Input Registers）
  FC05  寫入單一線圈（Write Single Coil）
  FC06  寫入單一暫存器（Write Single Register）
  FC16  寫入多個暫存器（Write Multiple Registers）

典型用途：
  - Modbus RTU 夾爪（如 Robotiq 2F-85、DH-Robotics AGC-95）
  - Modbus RTU 感測器（重量、距離、溫度）
  - 其他 RS485 周邊裝置
"""

from __future__ import annotations

from .serial_port import SerialPortController


class ModbusRTU:
    """Modbus RTU 協定收發器。

    透過 ``SerialPortController``（``robot.serial``）收發 Modbus RTU 訊框。
    呼叫任何方法前，請先透過 ``robot.serial.open()`` 開啟串列埠。

    Examples::

        with TMRobot("192.168.1.101") as robot:
            # 開啟 COM3，9600 bps，N-8-1
            robot.serial.open("COM3", 9600)

            rtu = robot.modbus_rtu   # 取得 ModbusRTU 控制器
            # 讀取 Slave 1 從位址 0 起的 10 個保持暫存器
            regs = rtu.read_holding_registers(1, 0, 10)
            print(regs)

            robot.serial.close()
    """

    def __init__(self, serial: SerialPortController) -> None:
        self._serial = serial

    # ── CRC16 Modbus ──────────────────────────────────────────────────────────

    @staticmethod
    def _crc16(data: bytes) -> int:
        """計算 Modbus CRC16（多項式 0xA001）。"""
        crc = 0xFFFF
        for byte in data:
            crc ^= byte
            for _ in range(8):
                if crc & 0x0001:
                    crc = (crc >> 1) ^ 0xA001
                else:
                    crc >>= 1
        return crc

    @classmethod
    def _add_crc(cls, data: bytes) -> bytes:
        """在訊框尾部加入 CRC16（低位元組在前）。"""
        crc = cls._crc16(data)
        return data + bytes([crc & 0xFF, (crc >> 8) & 0xFF])

    def _validate(self, resp: bytes, slave_id: int, fc: int) -> None:
        """驗證回應訊框的 Slave ID、功能碼與 CRC。

        Raises:
            RuntimeError: 任何驗證失敗
        """
        if len(resp) < 4:
            raise RuntimeError(f"Modbus RTU 回應過短：{len(resp)} bytes，期望至少 4 bytes")
        if resp[0] != slave_id:
            raise RuntimeError(f"Slave ID 不符：期望 {slave_id}，收到 {resp[0]}")
        if resp[1] == (fc | 0x80):
            exc = resp[2] if len(resp) > 2 else -1
            raise RuntimeError(f"Modbus 例外回應，功能碼 0x{fc:02X}，例外代碼 {exc}")
        if resp[1] != fc:
            raise RuntimeError(f"功能碼不符：期望 0x{fc:02X}，收到 0x{resp[1]:02X}")
        crc_calc = self._crc16(resp[:-2])
        crc_recv = resp[-2] | (resp[-1] << 8)
        if crc_calc != crc_recv:
            raise RuntimeError(
                f"CRC 錯誤：計算 0x{crc_calc:04X}，收到 0x{crc_recv:04X}"
            )

    # ── 讀取功能碼 ────────────────────────────────────────────────────────────

    def read_coils(self, slave_id: int, addr: int, count: int,
                   timeout_ms: int = 200) -> list[bool]:
        """FC01 讀取線圈狀態。

        Args:
            slave_id:   Slave 裝置 ID（1-247）
            addr:       起始線圈位址（0-based）
            count:      要讀取的線圈數量
            timeout_ms: 等待回應的逾時毫秒

        Returns:
            ``count`` 個布林值列表，True=ON，False=OFF

        Examples::

            coils = rtu.read_coils(1, 0, 8)
            print(coils[0])   # True/False
        """
        req  = self._add_crc(bytes([
            slave_id, 0x01,
            addr >> 8, addr & 0xFF,
            count >> 8, count & 0xFF,
        ]))
        self._serial.write_bytes(req)
        n_bytes = (count + 7) // 8
        resp = self._serial.read_bytes(5 + n_bytes, timeout_ms)
        self._validate(resp, slave_id, 0x01)
        result = []
        for i in range(count):
            byte_idx = 3 + i // 8
            result.append(bool(resp[byte_idx] & (1 << (i % 8))))
        return result

    def read_discrete_inputs(self, slave_id: int, addr: int, count: int,
                              timeout_ms: int = 200) -> list[bool]:
        """FC02 讀取離散輸入狀態。

        Args:
            slave_id:   Slave 裝置 ID
            addr:       起始位址（0-based）
            count:      要讀取的數量
            timeout_ms: 等待回應的逾時毫秒

        Returns:
            ``count`` 個布林值列表
        """
        req  = self._add_crc(bytes([
            slave_id, 0x02,
            addr >> 8, addr & 0xFF,
            count >> 8, count & 0xFF,
        ]))
        self._serial.write_bytes(req)
        n_bytes = (count + 7) // 8
        resp = self._serial.read_bytes(5 + n_bytes, timeout_ms)
        self._validate(resp, slave_id, 0x02)
        result = []
        for i in range(count):
            byte_idx = 3 + i // 8
            result.append(bool(resp[byte_idx] & (1 << (i % 8))))
        return result

    def read_holding_registers(self, slave_id: int, addr: int, count: int,
                                timeout_ms: int = 200) -> list[int]:
        """FC03 讀取保持暫存器（Holding Registers）。

        Args:
            slave_id:   Slave 裝置 ID
            addr:       起始位址（0-based）
            count:      要讀取的暫存器數量
            timeout_ms: 等待回應的逾時毫秒

        Returns:
            ``count`` 個 uint16 整數列表（big-endian 解碼）

        Examples::

            regs = rtu.read_holding_registers(1, 0, 4)
            print(regs)   # [100, 200, 0, 512]
        """
        req  = self._add_crc(bytes([
            slave_id, 0x03,
            addr >> 8, addr & 0xFF,
            count >> 8, count & 0xFF,
        ]))
        self._serial.write_bytes(req)
        resp = self._serial.read_bytes(5 + count * 2, timeout_ms)
        self._validate(resp, slave_id, 0x03)
        return [
            int.from_bytes(resp[3 + i * 2 : 5 + i * 2], "big")
            for i in range(count)
        ]

    def read_input_registers(self, slave_id: int, addr: int, count: int,
                              timeout_ms: int = 200) -> list[int]:
        """FC04 讀取輸入暫存器（Input Registers）。

        Args:
            slave_id:   Slave 裝置 ID
            addr:       起始位址（0-based）
            count:      要讀取的暫存器數量
            timeout_ms: 等待回應的逾時毫秒

        Returns:
            ``count`` 個 uint16 整數列表（big-endian 解碼）
        """
        req  = self._add_crc(bytes([
            slave_id, 0x04,
            addr >> 8, addr & 0xFF,
            count >> 8, count & 0xFF,
        ]))
        self._serial.write_bytes(req)
        resp = self._serial.read_bytes(5 + count * 2, timeout_ms)
        self._validate(resp, slave_id, 0x04)
        return [
            int.from_bytes(resp[3 + i * 2 : 5 + i * 2], "big")
            for i in range(count)
        ]

    # ── 寫入功能碼 ────────────────────────────────────────────────────────────

    def write_coil(self, slave_id: int, addr: int, value: bool,
                   timeout_ms: int = 200) -> None:
        """FC05 寫入單一線圈。

        Args:
            slave_id:   Slave 裝置 ID
            addr:       線圈位址（0-based）
            value:      True=ON（0xFF00），False=OFF（0x0000）
            timeout_ms: 等待回應的逾時毫秒

        Examples::

            rtu.write_coil(1, 0, True)    # 開啟線圈 0
        """
        val = 0xFF00 if value else 0x0000
        req = self._add_crc(bytes([
            slave_id, 0x05,
            addr >> 8, addr & 0xFF,
            val >> 8, val & 0xFF,
        ]))
        self._serial.write_bytes(req)
        resp = self._serial.read_bytes(8, timeout_ms)
        self._validate(resp, slave_id, 0x05)

    def write_register(self, slave_id: int, addr: int, value: int,
                        timeout_ms: int = 200) -> None:
        """FC06 寫入單一保持暫存器。

        Args:
            slave_id:   Slave 裝置 ID
            addr:       暫存器位址（0-based）
            value:      寫入值（0-65535）
            timeout_ms: 等待回應的逾時毫秒

        Examples::

            rtu.write_register(1, 0x0100, 500)   # 設定目標位置
        """
        if not 0 <= value <= 0xFFFF:
            raise ValueError(f"value 必須在 0~65535，得到 {value}")
        req = self._add_crc(bytes([
            slave_id, 0x06,
            addr >> 8, addr & 0xFF,
            value >> 8, value & 0xFF,
        ]))
        self._serial.write_bytes(req)
        resp = self._serial.read_bytes(8, timeout_ms)
        self._validate(resp, slave_id, 0x06)

    def write_registers(self, slave_id: int, addr: int, values: list[int],
                         timeout_ms: int = 200) -> None:
        """FC16 寫入多個保持暫存器。

        Args:
            slave_id:   Slave 裝置 ID
            addr:       起始暫存器位址（0-based）
            values:     要寫入的 uint16 整數列表
            timeout_ms: 等待回應的逾時毫秒

        Examples::

            rtu.write_registers(1, 0x0100, [500, 0, 1])
        """
        count = len(values)
        if count == 0:
            return
        for v in values:
            if not 0 <= v <= 0xFFFF:
                raise ValueError(f"values 中的值必須在 0~65535，得到 {v}")
        data = bytearray([
            slave_id, 0x10,
            addr >> 8, addr & 0xFF,
            count >> 8, count & 0xFF,
            count * 2,
        ])
        for v in values:
            data += bytes([v >> 8, v & 0xFF])
        req = self._add_crc(bytes(data))
        self._serial.write_bytes(req)
        resp = self._serial.read_bytes(8, timeout_ms)
        self._validate(resp, slave_id, 0x10)
