"""
pytmrobot.compliance — ComplianceController

透過 robot.compliance 存取。使用 TM Robot 的 Compliance 功能，
讓機器人以順從控制方式沿指定軸移動，遇到阻力時停止。

TMScript 對應：Chapter 20 Compliance
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from . import script_builder as sb
from ._ft_base import _FTBase

if TYPE_CHECKING:
    pass


class ComplianceController(_FTBase):
    """Compliance 順從控制器。透過 ``robot.compliance`` 存取。

    典型流程::

        # 在 Z- 方向最多移動 30mm，目標力 3N，速度 5%
        result = robot.compliance.run(
            direction=32,    # 32 = Z-
            distance=30.0,
            force=3.0,
            speed=5,
        )
        if result == 5:   # Resisted（偵測到外部阻力）
            print("已接觸工件")
        elif result == 3: # Distance reached
            print("移動完成但未偵測到阻力")

    Start() 結果碼（result 值）請參考 _FTBase docstring。
    """

    _OBJ_NAME   = "_cp"
    _RESULT_VAR = "_cp_r"

    def run(
        self,
        direction:  int,
        distance:   float,
        force:      float,
        speed:      int,
        *,
        frame:           int  = 1,
        timeout_ms:      int  = -1,
        high_resistance: bool = False,
    ) -> int:
        """執行 Compliance 順從控制運動。

        Args:
            direction:       偵測軸方向代碼（TMScript ch20 Single() 參數，
                             如 1=X+, 2=X-, 4=Y+, 8=Y-, 16=Z+, 32=Z-）
            distance:        最大順從移動距離（mm）
            force:           目標/阻力閾值（N）
            speed:           運動速度（%）
            frame:           座標系（1=機器人基座, 2=工具, 3=使用者）
            timeout_ms:      逾時毫秒（-1=不逾時）
            high_resistance: True=啟用高阻力偵測模式

        Returns:
            Start() 結果碼（見 _FTBase docstring）

        Examples::

            result = robot.compliance.run(32, 30.0, 3.0, 5)
            if result in (3, 5):
                print("Compliance 完成")
        """
        obj_declared = self._is_declared(self._OBJ_NAME)
        setup = sb.build_compliance_setup(
            direction, distance, force, speed,
            frame=frame, timeout_ms=timeout_ms,
            high_resistance=high_resistance,
            obj_declared=obj_declared,
        )
        self._mark(self._OBJ_NAME)
        return self._run(setup, f"{self._OBJ_NAME}.Start()", timeout_ms)

    def stop(self) -> int:
        """中止 Compliance 運動。

        Returns:
            Stop() 結果碼
        """
        return self._stop()
