"""
pytmrobot.state — StateReader

提供 robot.state.xxx 系列機器人狀態讀取。
每次 property 存取都向機器人發送 ListenSend script 並等待回傳。
snapshot() 一次批次讀取所有重要狀態，效率最高。
"""

from __future__ import annotations

from collections.abc import Callable
from typing import TYPE_CHECKING, TypeVar

from . import script_builder as sb
from .types import Pose6, RobotState

if TYPE_CHECKING:
    from ._client import TMClientWrapper
    from .tag_manager import TagManager

_T = TypeVar("_T")


class StateReader:
    """機器人狀態讀取器。透過 ``robot.state`` 存取。

    每個 property 都會觸發一次 TCP 往返（TMSCT + TMSTA SubCmd 90）。
    若需要同時讀取多個狀態，建議使用 ``snapshot()`` 批次讀取。

    Examples::

        pos  = robot.state.tcp_position   # (X, Y, Z, Rx, Ry, Rz)
        jnts = robot.state.joint_angles   # (J1, J2, J3, J4, J5, J6)
        all_ = robot.state.snapshot()     # 一次讀取全部
    """

    def __init__(self, client: TMClientWrapper, tags: TagManager) -> None:
        self._client = client
        self._tags   = tags

    def _read(self, prefix: str, lines: list[str], parse_fn: Callable[[str], _T]) -> _T:
        """發送 ListenSend script，等待 SubCmd 90 回傳後以 parse_fn 解析結果。"""
        tag = self._tags.next()
        csv = self._client.send_and_recv_subcmd(f"{prefix}{tag}", lines)
        return parse_fn(csv)

    # ── TCP 位置 ──────────────────────────────────────────────────────────────

    @property
    def tcp_position(self) -> Pose6:
        """當前 TCP 位置（相對 RobotBase），(X, Y, Z, Rx, Ry, Rz)，mm / °。"""
        return self._read("rtcp", sb.build_read_tcp_position(), _parse_pose6)

    # ── 關節角度 ──────────────────────────────────────────────────────────────

    @property
    def joint_angles(self) -> Pose6:
        """當前各關節角度，(J1, J2, J3, J4, J5, J6)，°。"""
        return self._read("rjnt", sb.build_read_joint_angles(), _parse_pose6)

    # ── 力 / 速度 ─────────────────────────────────────────────────────────────

    @property
    def tcp_force(self) -> float:
        """TCP 合力，N。"""
        return self._read("rfc", sb.build_read_tcp_force(), lambda csv: float(csv.strip()))

    @property
    def tcp_speed(self) -> float:
        """TCP 合速度，mm/s。"""
        return self._read("rspd", sb.build_read_tcp_speed(), lambda csv: float(csv.strip()))

    # ── 批次快照 ──────────────────────────────────────────────────────────────

    def snapshot(self) -> RobotState:
        """一次批次讀取所有重要狀態（單次 TCP 往返）。

        效率遠高於逐一讀取各 property，適合需要瞬間一致狀態的場景。

        Returns:
            RobotState 實例

        Examples::

            s = robot.state.snapshot()
            print(f"位置: {s.tcp_position}")
            print(f"合力: {s.tcp_force_3d} N")
        """
        return self._read("snap", sb.build_batch_snapshot(), _parse_snapshot)


# ── 解析工具 ──────────────────────────────────────────────────────────────────

def _parse_pose6(csv: str) -> Pose6:
    """解析 'x,y,z,rx,ry,rz' CSV 為 Pose6 tuple。"""
    parts = [v.strip() for v in csv.strip().split(",")]
    if len(parts) != 6:
        raise ValueError(f"預期 6 個值，得到 {len(parts)}: {csv!r}")
    return tuple(float(p) for p in parts)  # type: ignore[return-value]


def _parse_snapshot(csv: str) -> RobotState:
    """解析 build_batch_snapshot() 產生的固定格式 CSV。

    欄位順序：px,py,pz,prx,pry,prz, j1..j6, force3d, speed3d, base, tcp, payload
    """
    parts = [v.strip() for v in csv.strip().split(",")]
    # 至少需要 12+1+1+1+1+1 = 17 欄
    if len(parts) < 17:
        raise ValueError(f"snapshot CSV 欄位不足（{len(parts)}），內容: {csv!r}")
    tcp_position = tuple(float(p) for p in parts[0:6])   # type: ignore[assignment]
    joint_angles = tuple(float(p) for p in parts[6:12])  # type: ignore[assignment]
    tcp_force_3d = float(parts[12])
    tcp_speed_3d = float(parts[13])
    base_name    = parts[14]
    tcp_name     = parts[15]
    payload_kg   = float(parts[16])
    return RobotState(
        tcp_position=tcp_position,
        joint_angles=joint_angles,
        tcp_force_3d=tcp_force_3d,
        tcp_speed_3d=tcp_speed_3d,
        base_name=base_name,
        tcp_name=tcp_name,
        payload_kg=payload_kg,
    )
