"""
pytmrobot.exceptions — 自訂例外類別。

所有 pytmrobot 丟出的例外都繼承自 TMError，方便使用者統一捕捉。
"""


class TMError(Exception):
    """所有 pytmrobot 例外的基礎類別。"""


class TMConnectionError(TMError):
    """TCP 連線失敗，或連線中斷。"""


class TMScriptError(TMError):
    """機器人回傳 TMSCT ERROR 或 CPERR 封包。

    Attributes:
        script_id: 造成錯誤的 script ID（若可取得）
        detail:    機器人回傳的錯誤細節字串
    """
    def __init__(self, detail: str, script_id: str = ""):
        self.script_id = script_id
        self.detail = detail
        msg = f"Script error (id={script_id!r}): {detail}" if script_id else f"Script error: {detail}"
        super().__init__(msg)


class TMTimeoutError(TMError):
    """等待機器人回應逾時（TMSCT OK 或 TMSTA SubCmd 回傳）。"""


class TMValueError(TMError, ValueError):
    """傳入參數超出合法範圍（如速度 > 100%）。"""
