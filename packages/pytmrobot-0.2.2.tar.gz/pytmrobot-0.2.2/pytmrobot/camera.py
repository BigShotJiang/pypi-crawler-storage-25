"""
pytmrobot.camera — EIH (Eye-In-Hand) 相機控制器

透過 gRPC（Port 15567）與 TM Robot 內嵌相機通訊。
獨立於 Listen Node，不需要先建立 TMRobot 連線。

使用範例::

    from pytmrobot.camera import EIHCamera

    with EIHCamera("192.168.1.101") as cam:
        ok, msg = cam.is_connected()
        print(msg)

        img_bytes = cam.get_image()          # PNG bytes
        intrinsics = cam.get_intrinsics()    # list[CameraIntrinsics]
        hand_eye  = cam.get_hand_eye()       # (x, y, z, rx, ry, rz)

        cam.set_image_size("5M")
        cam.set_focus(500)
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    pass

# ── gRPC 延遲匯入（使用者若不使用 camera 功能，不強制安裝 grpcio） ─────────
def _get_grpc():
    try:
        import grpc
        return grpc
    except ImportError as e:
        raise ImportError(
            "使用 EIHCamera 需要安裝 grpcio：pip install pytmrobot[camera]"
        ) from e


def _get_stubs():
    try:
        from google.protobuf import empty_pb2

        from pytmrobot._grpc import EIHCameraAPI_pb2, EIHCameraAPI_pb2_grpc
        return EIHCameraAPI_pb2, EIHCameraAPI_pb2_grpc, empty_pb2
    except ImportError as e:
        raise ImportError(
            "使用 EIHCamera 需要安裝 grpcio：pip install pytmrobot[camera]"
        ) from e


# ── 資料型別 ─────────────────────────────────────────────────────────────────

@dataclass
class CaptureRange:
    """某個拍攝參數的目前值與有效範圍。"""
    current: int
    min_val: int
    max_val: int

    def __repr__(self) -> str:
        return f"CaptureRange(current={self.current}, min={self.min_val}, max={self.max_val})"


@dataclass
class WhiteBalance:
    """白平衡 RGB 比率（各含 CaptureRange）。"""
    red:   CaptureRange
    green: CaptureRange
    blue:  CaptureRange


@dataclass
class CameraMatrix:
    """相機投影矩陣（3×3）。"""
    m00: float
    m01: float
    m02: float
    m10: float
    m11: float
    m12: float
    m20: float
    m21: float
    m22: float

    def as_list(self) -> list[list[float]]:
        return [
            [self.m00, self.m01, self.m02],
            [self.m10, self.m11, self.m12],
            [self.m20, self.m21, self.m22],
        ]


@dataclass
class DistortionCoefficients:
    """鏡頭失真係數（5×1）。"""
    k1: float
    k2: float
    k3: float
    k4: float
    k5: float

    def as_list(self) -> list[float]:
        return [self.k1, self.k2, self.k3, self.k4, self.k5]


@dataclass
class CameraIntrinsics:
    """相機內部參數（一個焦距對應一組）。"""
    focus_value:  float
    image_width:  int
    image_height: int
    camera_matrix:           CameraMatrix
    distortion_coefficients: DistortionCoefficients


@dataclass
class CapturingSettings:
    """完整拍攝設定快照。"""
    shutter_time:  CaptureRange
    gain:          CaptureRange
    white_balance: WhiteBalance
    focus:         CaptureRange
    image_size:    str           # "1M:1280*960" 或 "5M:2592*1944"


@dataclass
class ImageConfig:
    """影像配置資訊。"""
    image_type:   str   # "png"
    image_size:   str   # "1M:1280*960" 或 "5M:2592*1944"
    image_width:  int
    image_height: int
    pixel_format: str   # "MONO" 或 "RGB"


# ── 內部轉換函式 ──────────────────────────────────────────────────────────────

def _to_capture_range(pb) -> CaptureRange:
    return CaptureRange(current=pb.CurrentValue, min_val=pb.MinValue, max_val=pb.MaxValue)


def _to_white_balance(pb) -> WhiteBalance:
    return WhiteBalance(
        red=_to_capture_range(pb.red_ratio),
        green=_to_capture_range(pb.green_ratio),
        blue=_to_capture_range(pb.blue_ratio),
    )


def _to_camera_matrix(pb) -> CameraMatrix:
    return CameraMatrix(
        m00=pb.matrix_00, m01=pb.matrix_01, m02=pb.matrix_02,
        m10=pb.matrix_10, m11=pb.matrix_11, m12=pb.matrix_12,
        m20=pb.matrix_20, m21=pb.matrix_21, m22=pb.matrix_22,
    )


def _to_distortion(pb) -> DistortionCoefficients:
    return DistortionCoefficients(
        k1=pb.coefficient_00, k2=pb.coefficient_10, k3=pb.coefficient_20,
        k4=pb.coefficient_30, k5=pb.coefficient_40,
    )


def _to_intrinsics(pb) -> CameraIntrinsics:
    return CameraIntrinsics(
        focus_value=pb.FocusValue,
        image_width=pb.ImageWidth,
        image_height=pb.ImageHeight,
        camera_matrix=_to_camera_matrix(pb.CameraMatrix),
        distortion_coefficients=_to_distortion(pb.DistortionCoefficients),
    )


def _to_capturing_settings(pb) -> CapturingSettings:
    return CapturingSettings(
        shutter_time=_to_capture_range(pb.ShutterTime),
        gain=_to_capture_range(pb.Gain),
        white_balance=_to_white_balance(pb.WhiteBalance),
        focus=_to_capture_range(pb.Focus),
        image_size=pb.ImageSize,
    )


def _to_image_config(pb) -> ImageConfig:
    return ImageConfig(
        image_type=pb.ImageType,
        image_size=pb.ImageSize,
        image_width=pb.ImageWidth,
        image_height=pb.ImageHeight,
        pixel_format=pb.PixelFormat,
    )


# ── EIHCamera 主類別 ──────────────────────────────────────────────────────────

class EIHCamera:
    """TM Robot EIH（Eye-In-Hand）相機 gRPC 客戶端。

    獨立物件，不依賴 TMRobot / Listen Node，直接以 gRPC 連線至相機伺服器。

    Args:
        host:    機器人 IP
        port:    EIH Camera API gRPC 埠號（預設 15567）
        timeout: gRPC 呼叫逾時秒數（預設 5.0）

    Examples::

        # context manager（自動連線/斷線）
        with EIHCamera("192.168.1.101") as cam:
            img = cam.get_image()

        # 手動管理
        cam = EIHCamera("192.168.1.101")
        cam.connect()
        img = cam.get_image()
        cam.disconnect()
    """

    DEFAULT_PORT = 15567

    def __init__(self, host: str, port: int = DEFAULT_PORT, timeout: float = 5.0) -> None:
        self._host    = host
        self._port    = port
        self._timeout = timeout
        self._channel = None
        self._stub    = None

    # ── 連線管理 ──────────────────────────────────────────────────────────────

    def connect(self) -> None:
        """建立 gRPC channel 並初始化 stub。"""
        grpc = _get_grpc()
        _, EIHCameraAPI_pb2_grpc, _ = _get_stubs()
        self._channel = grpc.insecure_channel(f"{self._host}:{self._port}")
        self._stub = EIHCameraAPI_pb2_grpc.EIHCameraApiStub(self._channel)

    def disconnect(self) -> None:
        """關閉 gRPC channel。"""
        if self._channel is not None:
            self._channel.close()
            self._channel = None
            self._stub = None

    def __enter__(self) -> EIHCamera:
        self.connect()
        return self

    def __exit__(self, *_) -> None:
        self.disconnect()

    # ── 內部輔助 ──────────────────────────────────────────────────────────────

    def _stub_call(self, method_name: str, request=None):
        """呼叫 stub 方法，統一處理逾時與連線檢查。"""
        if self._stub is None:
            raise RuntimeError("尚未連線，請先呼叫 connect() 或使用 with 語句")
        grpc = _get_grpc()
        _, _, empty_pb2 = _get_stubs()
        req = request if request is not None else empty_pb2.Empty()
        try:
            return getattr(self._stub, method_name)(req, timeout=self._timeout)
        except grpc.RpcError as e:
            raise RuntimeError(
                f"gRPC 呼叫 {method_name} 失敗：{e.code()} — {e.details()}"
            ) from e

    # ── 連線狀態 ──────────────────────────────────────────────────────────────

    def is_connected(self) -> tuple[bool, str]:
        """檢查相機是否連線。

        Returns:
            (is_connected, message)
        """
        resp = self._stub_call("isCameraConnected")
        return resp.isCameraConnected, resp.connection_message

    # ── 相機資訊 ──────────────────────────────────────────────────────────────

    def get_intrinsics(self) -> list[CameraIntrinsics]:
        """取得相機內部參數（通常約 13 筆，各焦距對應一組）。"""
        resp = self._stub_call("getIntrinsics")
        return [_to_intrinsics(i) for i in resp.cam_intrinsics]

    def get_hand_eye(self) -> tuple[float, float, float, float, float, float]:
        """取得手眼標定參數。

        Returns:
            (x, y, z, rx, ry, rz) — 單位 mm / °
        """
        resp = self._stub_call("getHandEyeParameters")
        ha = resp.HandEyeArray
        return (ha.handeye_x, ha.handeye_y, ha.handeye_z,
                ha.handeye_rx, ha.handeye_ry, ha.handeye_rz)

    # ── 影像擷取 ──────────────────────────────────────────────────────────────

    def get_image(self) -> bytes:
        """擷取一張影像，回傳 PNG bytes。

        Examples::

            img_bytes = cam.get_image()
            with open("capture.png", "wb") as f:
                f.write(img_bytes)

            # 搭配 OpenCV
            import cv2, numpy as np
            arr = np.frombuffer(img_bytes, dtype=np.uint8)
            img = cv2.imdecode(arr, cv2.IMREAD_COLOR)
        """
        resp = self._stub_call("getImageData")
        return bytes(resp.EncodeString)

    def get_image_config(self) -> ImageConfig:
        """取得影像配置（格式、大小、像素格式）。"""
        resp = self._stub_call("getImageConfiguration")
        return _to_image_config(resp)

    # ── 拍攝設定（批次）─────────────────────────────────────────────────────

    def get_capturing_settings(self) -> CapturingSettings:
        """取得完整拍攝設定快照。"""
        resp = self._stub_call("getCapturingSettings")
        return _to_capturing_settings(resp)

    def set_capturing_settings(
        self,
        shutter_time: int,
        gain: int,
        wb_red: int,
        wb_green: int,
        wb_blue: int,
        focus: int,
        image_size: str,
    ) -> None:
        """一次設定所有拍攝參數。

        Args:
            shutter_time: 快門時間（μs）
            gain:         增益（dB）
            wb_red:       白平衡紅色比率
            wb_green:     白平衡綠色比率
            wb_blue:      白平衡藍色比率
            focus:        焦距值
            image_size:   ``"1M"``（1280×960）或 ``"5M"``（2592×1944）
        """
        EIHCameraAPI_pb2, _, _ = _get_stubs()
        req = EIHCameraAPI_pb2.setCapturingSettingsRequest(
            ShutterTime=shutter_time,
            Gain=gain,
            wb_redratio=wb_red,
            wb_greenratio=wb_green,
            wb_blueratio=wb_blue,
            Focus=focus,
            ImageSize=image_size,
        )
        self._stub_call("setCapturingSettings", req)

    # ── 快門時間 ──────────────────────────────────────────────────────────────

    def get_shutter_time(self) -> CaptureRange:
        """取得快門時間設定（目前值及上下限，μs）。"""
        resp = self._stub_call("getShutterTime")
        return _to_capture_range(resp.shuttertime)

    def set_shutter_time(self, value: int) -> None:
        """設定快門時間（μs）。"""
        EIHCameraAPI_pb2, _, _ = _get_stubs()
        self._stub_call("setShutterTime",
                        EIHCameraAPI_pb2.setShutterTimeRequest(shuttertime=value))

    # ── 增益 ──────────────────────────────────────────────────────────────────

    def get_gain(self) -> CaptureRange:
        """取得增益設定（目前值及上下限，dB）。"""
        resp = self._stub_call("getGain")
        return _to_capture_range(resp.gain)

    def set_gain(self, value: int) -> None:
        """設定增益（dB）。"""
        EIHCameraAPI_pb2, _, _ = _get_stubs()
        self._stub_call("setGain",
                        EIHCameraAPI_pb2.setGainRequest(gain=value))

    # ── 白平衡 ────────────────────────────────────────────────────────────────

    def get_white_balance(self) -> WhiteBalance:
        """取得白平衡設定（RGB 三通道各含目前值及上下限）。"""
        resp = self._stub_call("getWhiteBalance")
        return _to_white_balance(resp.whitebalance)

    def set_white_balance(self, red: int, green: int, blue: int) -> None:
        """設定白平衡 RGB 比率。"""
        EIHCameraAPI_pb2, _, _ = _get_stubs()
        self._stub_call("setWhiteBalance",
                        EIHCameraAPI_pb2.setWhiteBalanceRequest(
                            wb_redratio=red, wb_greenratio=green, wb_blueratio=blue))

    # ── 焦距 ──────────────────────────────────────────────────────────────────

    def get_focus(self) -> CaptureRange:
        """取得焦距設定（目前值及上下限）。"""
        resp = self._stub_call("getFocus")
        return _to_capture_range(resp.focus)

    def set_focus(self, value: int) -> None:
        """設定焦距值。"""
        EIHCameraAPI_pb2, _, _ = _get_stubs()
        self._stub_call("setFocus",
                        EIHCameraAPI_pb2.setFocusRequest(focus=value))

    # ── 影像大小 ──────────────────────────────────────────────────────────────

    def get_image_size(self) -> str:
        """取得目前影像大小設定。

        Returns:
            ``"1M:1280_960"`` 或 ``"5M:2592_1944"``
        """
        resp = self._stub_call("getImageSize")
        return resp.imagesize

    def set_image_size(self, size: str) -> None:
        """設定影像大小。

        Args:
            size: ``"1M"``（1280×960）或 ``"5M"``（2592×1944）
        """
        if size not in ("1M", "5M"):
            raise ValueError(f"影像大小必須為 '1M' 或 '5M'，收到：{size!r}")
        EIHCameraAPI_pb2, _, _ = _get_stubs()
        self._stub_call("setImageSize",
                        EIHCameraAPI_pb2.setImageSizeRequest(imagesize=size))

    # ── 連線管理（進階）──────────────────────────────────────────────────────

    def terminate_connection(self) -> None:
        """將 EIH 相機與機器人斷線（進階功能，一般不建議使用）。"""
        self._stub_call("terminateCameraConnection")

    def resume_connection(self) -> None:
        """恢復 EIH 相機與機器人之間連線。"""
        self._stub_call("resumeCameraConnection")

    # ── repr ──────────────────────────────────────────────────────────────────

    def __repr__(self) -> str:
        status = "connected" if self._stub is not None else "disconnected"
        return f"EIHCamera(host={self._host!r}, port={self._port}, status={status})"
