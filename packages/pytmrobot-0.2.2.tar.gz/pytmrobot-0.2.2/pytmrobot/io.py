"""
pytmrobot.io — IOController

提供 robot.io.xxx() 系列 IO 讀寫指令。
寫入操作直接發送 TMScript 賦值；讀取操作透過 ListenSend 往返取值。
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from . import script_builder as sb
from .types import IOState

if TYPE_CHECKING:
    from ._client import TMClientWrapper
    from .tag_manager import TagManager


class IOController:
    """IO 控制器。透過 ``robot.io`` 存取。

    Examples::

        robot.io.set_do(2, True)          # DO2 = High
        robot.io.set_ao(0, 3.3)           # AO0 = 3.3V
        state = robot.io.get_di(0)        # DI0 狀態（bool）
        voltage = robot.io.get_ai(1)      # AI1 電壓（float）
    """

    def __init__(self, client: TMClientWrapper, tags: TagManager) -> None:
        self._client = client
        self._tags   = tags
        self._io_vars_declared = False  # 追蹤 get_all_io 變數是否已在 session 中宣告

    def _reset_session(self) -> None:
        """重設 session 狀態（重新連線時呼叫）。"""
        self._io_vars_declared = False

    def _read_pin(self, prefix: str, lines: list[str], parse_fn) -> object:
        """發送單腳位讀取 script，等待 SubCmd 90 後以 parse_fn 解析。"""
        tag = self._tags.next()
        csv = self._client.send_and_recv_subcmd(f"{prefix}{tag}", lines)
        return parse_fn(csv)

    # ── 數位輸出 ──────────────────────────────────────────────────────────────

    def set_do(
        self,
        pin:     int,
        value:   bool,
        module:  str  = "ControlBox",
        *,
        instant: bool = False,
    ) -> None:
        """設定數位輸出。

        Args:
            pin:     DO 腳位編號（0 起始）
            value:   True=High, False=Low
            module:  模組名稱（"ControlBox" / "EndModule" / "ExtModuleN"）
            instant: True=立即更新（InstantDO），不等待周期同步

        Examples::

            robot.io.set_do(2, True)            # DO2 = High
            robot.io.set_do(0, False, instant=True)
        """
        tag  = self._tags.next()
        line = sb.build_set_do(pin, value, module, instant)
        self._client.send_script_checked(f"do{tag}", [line])

    def set_ao(
        self,
        pin:     int,
        voltage: float,
        module:  str  = "ControlBox",
        *,
        instant: bool = False,
    ) -> None:
        """設定類比輸出電壓。

        Args:
            pin:     AO 腳位編號
            voltage: 電壓值 V（通常 -10.0 ~ +10.0）
            module:  模組名稱
            instant: True=立即更新

        Examples::

            robot.io.set_ao(0, 5.0)    # AO0 = 5.0V
        """
        tag  = self._tags.next()
        line = sb.build_set_ao(pin, voltage, module, instant)
        self._client.send_script_checked(f"ao{tag}", [line])

    # ── 數位輸入讀取（ListenSend 往返） ──────────────────────────────────────

    def get_di(self, pin: int, module: str = "ControlBox") -> bool:
        """讀取數位輸入狀態。

        Args:
            pin:    DI 腳位編號
            module: 模組名稱

        Returns:
            True=High, False=Low

        Examples::

            if robot.io.get_di(0):
                robot.io.set_do(2, True)
        """
        return bool(self._read_pin("rdi", sb.build_read_di(pin, module),
                                   lambda csv: int(csv.strip())))

    def get_do(self, pin: int, module: str = "ControlBox") -> bool:
        """讀取當前數位輸出狀態。

        Returns:
            True=High, False=Low
        """
        return bool(self._read_pin("rdo", sb.build_read_do(pin, module),
                                   lambda csv: int(csv.strip())))

    def get_ai(self, pin: int, module: str = "ControlBox") -> float:
        """讀取類比輸入電壓。

        Returns:
            電壓值 V
        """
        return float(self._read_pin("rai", sb.build_read_ai(pin, module),  # type: ignore[arg-type]
                                    lambda csv: float(csv.strip())))

    def get_all_io(self, module: str = "ControlBox") -> IOState:
        """批次讀取全部 DI/DO/AI/AO 狀態。

        Returns:
            IOState（di/do/ai/ao 各為 list）

        Examples::

            io = robot.io.get_all_io()
            print(io.di)   # [0, 1, 0, ...]
            print(io.ai)   # [3.3, 0.0, ...]
        """
        tag   = self._tags.next()
        lines = sb.build_read_all_io(module, vars_declared=self._io_vars_declared)
        csv   = self._client.send_and_recv_subcmd(f"allIO{tag}", lines)
        self._io_vars_declared = True  # 首次成功後，後續改用賦值避免重複宣告
        return _parse_all_io(csv)


# ── 解析 get_all_io 回傳的 CSV ────────────────────────────────────────────────

def _parse_all_io(csv: str) -> IOState:
    """解析 IO 狀態回傳字串。

    支援兩種格式：
    - 緊湊格式（GetString(array) 回傳）：'DI:{0,0,...}|DO:{0,...}|AI:{a,...}|AO:{a,...}'
    - 展開格式（逐元素回傳）：'DI:0,0,...|DO:0,...|AI:a,...|AO:a,...'
    """
    state = IOState()
    for segment in csv.strip().split("|"):
        if ":" not in segment:
            continue
        label, _, values_str = segment.partition(":")
        label = label.strip().upper()
        values_str = values_str.strip().strip("{}")  # 去除 GetString(array) 回傳的 {}
        if not values_str:
            continue
        if label == "DI":
            state.di = [int(v) for v in values_str.split(",") if v.strip()]
        elif label == "DO":
            state.do = [int(v) for v in values_str.split(",") if v.strip()]
        elif label == "AI":
            state.ai = [float(v) for v in values_str.split(",") if v.strip()]
        elif label == "AO":
            state.ao = [float(v) for v in values_str.split(",") if v.strip()]
    return state
