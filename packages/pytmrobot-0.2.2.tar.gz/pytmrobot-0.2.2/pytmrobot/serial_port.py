"""
pytmrobot.serial_port — SerialPortController

透過機器人控制箱的 RS232/RS485 串列埠收發資料。
底層使用 TMScript SerialPort 物件（ch08），由 Listen Node 執行。

典型用途：
  - 驅動 RS485 從站裝置（夾爪、感測器、馬達驅動器等）
  - 透過 ``ModbusRTU`` 收發 Modbus RTU 協定訊框
"""

from __future__ import annotations

from . import script_builder as sb
from ._client import TMClientWrapper
from .tag_manager import TagManager

# 有效的串列埠奇偶校驗字串（TMScript 文件規定）
_VALID_PARITY = {"none", "odd", "even", "mark", "space"}


class SerialPortController:
    """控制機器人控制箱 RS232/RS485 串列埠。

    需先呼叫 ``open()`` 開啟埠口，結束後呼叫 ``close()``。

    Examples::

        with TMRobot("192.168.1.101") as robot:
            robot.serial.open("COM3", 9600)          # 開啟串列埠
            robot.serial.write_bytes(b"\\x01\\x03\\x00\\x00\\x00\\x01\\x84\\x0A")
            data = robot.serial.read_bytes(7, timeout_ms=200)
            robot.serial.close()

    Notes:
        - 控制箱通常提供 ``COM3`` / ``COM4`` 兩個 RS232 埠，RS485 則掛載在相同 COM 號碼。
        - ``_sp``（SerialPort 物件）在 Listen Node session 中只能宣告一次；
          重新連線後會自動重設宣告狀態。
    """

    def __init__(self, wrapper: TMClientWrapper, tags: TagManager) -> None:
        self._wrapper = wrapper
        self._tags    = tags
        # session 變數宣告追蹤
        self._sp_declared: bool = False
        self._rx_declared: bool = False
        self._rs_declared: bool = False

    def _reset_session(self) -> None:
        """重連後重設所有 session 變數宣告狀態。由 TMRobot.connect() 呼叫。"""
        self._sp_declared = False
        self._rx_declared = False
        self._rs_declared = False

    # ── 埠口管理 ──────────────────────────────────────────────────────────────

    def open(
        self,
        port:       str,
        baudrate:   int = 9600,
        parity:     str = "none",
        data_bits:  int = 8,
        stop_bits:  int = 1,
        timeout_ms: int = -1,
    ) -> None:
        """開啟串列埠。

        Args:
            port:       埠口名稱（如 ``"COM3"``）
            baudrate:   鮑率（bps），常用值 9600 / 19200 / 115200
            parity:     奇偶校驗：``"none"`` / ``"odd"`` / ``"even"``
            data_bits:  資料位元數（通常為 8）
            stop_bits:  停止位元數（1 或 2）
            timeout_ms: 預設讀取逾時（毫秒）；-1 表示不設定（等待資料到來）

        Raises:
            ValueError: parity 不在允許值範圍
        """
        if parity not in _VALID_PARITY:
            raise ValueError(f"parity 必須是 {sorted(_VALID_PARITY)} 之一，得到 {parity!r}")
        tag   = self._tags.next()
        lines = sb.build_serial_open(
            port, baudrate, parity, data_bits, stop_bits, timeout_ms,
            sp_declared=self._sp_declared,
        )
        self._wrapper.send_script_checked(f"sport{tag}", lines)
        self._sp_declared = True

    def close(self) -> None:
        """關閉串列埠。"""
        tag = self._tags.next()
        self._wrapper.send_script_checked(f"spclose{tag}", sb.build_serial_close())

    # ── 寫入 ──────────────────────────────────────────────────────────────────

    def write_bytes(self, data: bytes) -> None:
        """以原始位元組序列寫入串列埠。

        Args:
            data: 要傳送的位元組序列（如 Modbus RTU 訊框）

        Examples::

            robot.serial.write_bytes(b"\\x01\\x03\\x00\\x00\\x00\\x01\\x84\\x0A")
        """
        tag = self._tags.next()
        self._wrapper.send_script_checked(f"spwb{tag}", sb.build_serial_write_bytes(data))

    def write_string(self, text: str) -> None:
        """以字串寫入串列埠（不加換行符號）。

        Args:
            text: 要傳送的字串
        """
        tag = self._tags.next()
        self._wrapper.send_script_checked(f"spws{tag}", sb.build_serial_write_string(text))

    def writeline(self, text: str) -> None:
        """以字串寫入串列埠並自動附加 ``\\r\\n``。

        Args:
            text: 要傳送的字串（不含換行）
        """
        tag = self._tags.next()
        self._wrapper.send_script_checked(f"spwl{tag}", sb.build_serial_writeline(text))

    # ── 讀取 ──────────────────────────────────────────────────────────────────

    def read_bytes(self, count: int, timeout_ms: int = 200) -> bytes:
        """從串列埠讀取指定數量的位元組。

        機器人端執行 ``com_read()`` 讀取後透過 TMSTA SubCmd 90 回傳，
        回傳格式為 ``{b0,b1,...}``，Python 端解析成 ``bytes``。

        Args:
            count:      要讀取的位元組數
            timeout_ms: 等待資料的逾時毫秒

        Returns:
            讀取到的位元組序列

        Raises:
            RuntimeError: 讀取失敗或回傳格式異常
        """
        tag   = self._tags.next()
        lines = sb.build_serial_read_bytes(count, timeout_ms, rx_declared=self._rx_declared)
        raw   = self._wrapper.send_and_recv_subcmd(f"sprb{tag}", lines)
        self._rx_declared = True
        return _parse_bytes_str(raw)

    def read_string(self, count: int, timeout_ms: int = 200) -> str:
        """從串列埠讀取指定數量的位元組並以字串回傳。

        Args:
            count:      要讀取的字元數
            timeout_ms: 等待資料的逾時毫秒

        Returns:
            讀取到的字串
        """
        tag   = self._tags.next()
        lines = sb.build_serial_read_string(count, timeout_ms, rs_declared=self._rs_declared)
        result = self._wrapper.send_and_recv_subcmd(f"sprs{tag}", lines)
        self._rs_declared = True
        return result


# ── 解析工具 ──────────────────────────────────────────────────────────────────

def _parse_bytes_str(raw: str) -> bytes:
    """解析 TMScript GetString(byte[]) 回傳的 ``{b0,b1,...}`` 格式為 bytes。

    Examples::

        _parse_bytes_str("{1,3,0,1,132,10}")  # → b'\\x01\\x03\\x00\\x01\\x84\\x0A'
    """
    cleaned = raw.strip().strip("{}")
    if not cleaned:
        return b""
    return bytes(int(x) for x in cleaned.split(",") if x.strip())
