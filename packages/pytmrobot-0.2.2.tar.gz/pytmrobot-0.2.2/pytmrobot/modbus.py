"""
pytmrobot.modbus — ModbusManager

提供 robot.modbus.xxx() 系列 Modbus TCP 讀寫指令。

使用流程：
  1. connect(ip) — 建立 ModbusTCP 裝置並開啟連線
  2. preset(name, ...) — 設定命名暫存器（Preset）
  3. read_*(name) / write(name, value) — 依名稱讀寫
  4. disconnect() — 關閉連線

TMScript 物件 ``_mbus`` 在 Listen Node session 中宣告一次並持續存在，
後續的 connect() 只重新呼叫 modbus_open()。
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Union

from . import script_builder as sb

if TYPE_CHECKING:
    from ._client import TMClientWrapper
    from .tag_manager import TagManager


class ModbusManager:
    """Modbus TCP 管理器。透過 ``robot.modbus`` 存取。

    Examples::

        robot.modbus.connect("192.168.1.10")
        robot.modbus.preset("light",   1, "DO", 7206, "bool")
        robot.modbus.preset("counter", 1, "RO", 9000, "int16")

        robot.modbus.write("light", True)
        count = robot.modbus.read_int("counter")
        is_on = robot.modbus.read_bool("light")

        robot.modbus.disconnect()
    """

    def __init__(self, client: TMClientWrapper, tags: TagManager) -> None:
        self._client       = client
        self._tags         = tags
        self._mbus_declared = False  # ModbusTCP _mbus 是否已在 session 中宣告
        # 逐型別追蹤讀取結果變數的宣告狀態（避免 Listen Node session 重複宣告）
        # key = TMScript 變數名稱，value = 是否已宣告
        self._var_decl: dict[str, bool] = {}

    def _reset_session(self) -> None:
        """重設 session 狀態（重新連線時呼叫）。"""
        self._mbus_declared = False
        self._var_decl.clear()

    # ── 連線管理 ──────────────────────────────────────────────────────────────

    def connect(self, ip: str, port: int = 502) -> None:
        """建立 ModbusTCP 裝置並開啟連線。

        Args:
            ip:   Modbus 裝置 IP 位址
            port: TCP 埠（預設 502）

        Note:
            同一 Listen Node session 內可多次呼叫以重新連線，
            不會重複宣告 TMScript 物件。

        Examples::

            robot.modbus.connect("192.168.1.10")
            robot.modbus.connect("192.168.1.10", port=502)
        """
        tag   = self._tags.next()
        lines = sb.build_modbus_connect(ip, port, mbus_declared=self._mbus_declared)
        self._client.send_script_checked(f"mbcon{tag}", lines)
        self._mbus_declared = True

    def disconnect(self) -> None:
        """關閉 Modbus 連線（不銷毀裝置物件，可再次 connect）。"""
        tag = self._tags.next()
        self._client.send_script_checked(f"mbdis{tag}", sb.build_modbus_disconnect())

    # ── Preset 設定 ───────────────────────────────────────────────────────────

    def preset(
        self,
        name:     str,
        slave_id: int,
        reg_type: str,
        addr:     int,
        dtype:    str,
        extra:    int = 1,
    ) -> bool:
        """設定命名暫存器（Preset），供後續讀寫呼叫使用。

        Args:
            name:     預設名稱（英數字+底線，如 ``"light"``）
            slave_id: Slave ID（0=廣播）
            reg_type: ``"DO"`` / ``"DI"`` / ``"RO"`` / ``"RI"``
            addr:     起始暫存器位址
            dtype:    ``"bool"`` / ``"byte"`` / ``"int16"`` / ``"int32"`` /
                      ``"float"`` / ``"double"`` / ``"string"``
            extra:    int32/float/double 的位元組序（0=Little, 1=Big 預設）；
                      string 型別為讀取位址個數

        Returns:
            True=設定成功

        Examples::

            robot.modbus.preset("light",   1, "DO", 7206, "bool")
            robot.modbus.preset("counter", 1, "RO", 9000, "int16")
            robot.modbus.preset("temp",    1, "RI", 7001, "float")
        """
        tag   = self._tags.next()
        lines = sb.build_modbus_preset(
            name, slave_id, reg_type, addr, dtype, extra,
            var_declared=self._var_decl.get("_mb_pr", False),
        )
        csv = self._client.send_and_recv_subcmd(f"mbpr{tag}", lines)
        self._var_decl["_mb_pr"] = True
        return _parse_bool(csv)

    # ── 讀取（Preset 命名） ───────────────────────────────────────────────────

    def read_bool(self, preset_name: str) -> bool:
        """依 Preset 名稱讀取布林值（DO / DI）。

        Examples::

            is_on = robot.modbus.read_bool("light")
        """
        return _parse_bool(self._read_preset(preset_name, "bool", "_mb_b"))

    def read_int(self, preset_name: str) -> int:
        """依 Preset 名稱讀取整數（int16 / int32）。

        Examples::

            count = robot.modbus.read_int("counter")
        """
        return int(self._read_preset(preset_name, "int", "_mb_i").strip())

    def read_float(self, preset_name: str) -> float:
        """依 Preset 名稱讀取浮點數（float / double）。

        Examples::

            temperature = robot.modbus.read_float("temp")
        """
        return float(self._read_preset(preset_name, "float", "_mb_f").strip())

    def read_string(self, preset_name: str) -> str:
        """依 Preset 名稱讀取字串。

        Examples::

            label = robot.modbus.read_string("product_id")
        """
        return self._read_preset(preset_name, "string", "_mb_s").strip()

    # ── 讀取（原始暫存器，不需 Preset） ──────────────────────────────────────

    def read_int16_array(
        self,
        slave_id: int,
        reg_type: str,
        addr:     int,
        count:    int,
        endian:   int = 1,
    ) -> list[int]:
        """直接讀取多個 int16 暫存器（不需 Preset）。

        Args:
            slave_id: Slave ID
            reg_type: ``"DO"`` / ``"DI"`` / ``"RO"`` / ``"RI"``
            addr:     起始位址
            count:    個數
            endian:   0=LE, 1=BE（預設）

        Examples::

            regs = robot.modbus.read_int16_array(1, "RO", 9000, 4)
        """
        expr = f'modbus_read_int16("_mbus", {slave_id}, "{reg_type}", {addr}, {count}, {endian})'
        return [int(v) for v in _parse_array(self._read_array("int[]", "_mb_ia", expr))]

    def read_float_array(
        self,
        slave_id: int,
        reg_type: str,
        addr:     int,
        count:    int,
        endian:   int = 1,
    ) -> list[float]:
        """直接讀取多個 float 暫存器（不需 Preset）。

        Examples::

            temps = robot.modbus.read_float_array(1, "RI", 7001, 3)
        """
        expr = f'modbus_read_float("_mbus", {slave_id}, "{reg_type}", {addr}, {count}, {endian})'
        return [float(v) for v in _parse_array(self._read_array("float[]", "_mb_fa", expr))]

    # ── 寫入 ─────────────────────────────────────────────────────────────────

    def write(
        self,
        preset_name: str,
        value:       Union[bool, int, float, str],
    ) -> None:
        """依 Preset 名稱寫入數值。

        Args:
            preset_name: 已設定的 Preset 名稱
            value:       寫入值（型別需與 Preset 宣告一致）

        Examples::

            robot.modbus.write("light", True)
            robot.modbus.write("counter", 42)
            robot.modbus.write("temp_setpoint", 25.0)
        """
        # 布林值需轉為 TMScript 關鍵字（true/false）
        if isinstance(value, bool):
            val_str = "true" if value else "false"
        elif isinstance(value, str):
            val_str = f'"{value}"'
        else:
            val_str = str(value)
        tag = self._tags.next()
        line = f'modbus_write("_mbus", "{preset_name}", {val_str})'
        self._client.send_script_checked(f"mbw{tag}", [line])

    # ── 內部工具 ──────────────────────────────────────────────────────────────

    def _read_preset(self, preset_name: str, tmtype: str, var_name: str) -> str:
        """發送 modbus_read("_mbus", preset_name) 並透過 ListenSend 接收結果。"""
        declared = self._var_decl.get(var_name, False)
        expr     = f'modbus_read("_mbus", "{preset_name}")'
        if not declared:
            assign = f'{tmtype} {var_name} = {expr}'
            self._var_decl[var_name] = True
        else:
            assign = f'{var_name} = {expr}'
        tag   = self._tags.next()
        lines = [assign, f'ListenSend(90, GetString({var_name}))']
        return self._client.send_and_recv_subcmd(f"mbr{tag}", lines)

    def _read_array(self, tmtype: str, var_name: str, read_expr: str) -> str:
        """發送陣列型態讀取 script 並透過 ListenSend 接收 {v0,v1,...} 格式字串。"""
        declared = self._var_decl.get(var_name, False)
        if not declared:
            assign = f'{tmtype} {var_name} = {read_expr}'
            self._var_decl[var_name] = True
        else:
            assign = f'{var_name} = {read_expr}'
        tag   = self._tags.next()
        lines = [assign, f'ListenSend(90, GetString({var_name}))']
        return self._client.send_and_recv_subcmd(f"mbar{tag}", lines)


# ── 解析工具 ──────────────────────────────────────────────────────────────────

def _parse_bool(csv: str) -> bool:
    """解析 TMScript 布林回傳值（"0"/"1" 或 "true"/"false"）。"""
    s = csv.strip().lower()
    return s in ("1", "true")


def _parse_array(csv: str) -> list[str]:
    """解析 GetString(array) 回傳的 '{v0,v1,...}' 格式。"""
    return [v.strip() for v in csv.strip().strip("{}").split(",") if v.strip()]
