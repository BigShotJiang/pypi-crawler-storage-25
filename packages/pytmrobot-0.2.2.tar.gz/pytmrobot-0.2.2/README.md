# pytmrobot

**Python API for Techman (TM) Robots** — control your TM robot without writing TMScript.

[![Python](https://img.shields.io/badge/python-3.10%2B-blue)](https://www.python.org/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](LICENSE)

[繁體中文說明文件](https://github.com/harry123180/TMDemo/blob/master/docs/wiki.md) | [Changelog](https://github.com/harry123180/TMDemo/blob/master/CHANGELOG.md)

---

## Features

| Category | Capabilities |
|---|---|
| **Motion** | PTP, Line, Circle, relative moves, PVT trajectories |
| **I/O** | Digital / analog output & input, batch read |
| **State** | TCP position, joint angles, force, speed, snapshot |
| **Force sensing** | TouchStop, Compliance, Force control (FTSensor) |
| **Communication** | Modbus TCP read/write with named Presets |
| **Vision** | Trigger vision jobs, read output poses |
| **HMI** | Operator dialogs (choice + popup) |
| **Multi-robot** | Each `TMRobot` instance is fully independent — run 12+ in parallel |

---

## Requirements

- Python **3.10+**
- TM Robot running **TMflow 1.80+** with a **Listen Node** in the flow
- Network access to port **5890** on the robot controller

No external dependencies — only the Python standard library.

---

## Installation

```bash
pip install pytmrobot
```

Or install from source:

```bash
git clone https://github.com/harry-techman/pytmrobot.git
cd pytmrobot
pip install -e .
```

---

## Quick Start

```python
from pytmrobot import TMRobot, CartPoint

with TMRobot("192.168.1.101") as robot:

    home = CartPoint(400, -100, 500, 180, 0, 90)   # X, Y, Z, Rx, Ry, Rz
    pick = CartPoint(400, -100, 280, 180, 0, 90)

    robot.move.ptp(home, speed=30)       # point-to-point move, 30 %
    robot.move.ptp(pick, speed=10)       # slow approach

    robot.io.set_do(2, True)             # close gripper (DO[2] = 1)
    robot.sleep(500)                     # wait 500 ms on robot side

    robot.move.ptp(home, speed=30)
    robot.io.set_do(2, False)            # open gripper

    pos = robot.state.tcp_position       # read current TCP pose
    print(f"Done — X={pos[0]:.1f}  Y={pos[1]:.1f}  Z={pos[2]:.1f} mm")
```

---

## Sub-controllers

| Property | Description |
|---|---|
| `robot.move` | PTP / Line / Circle / relative / PVT |
| `robot.io` | DO, AO, DI, AI, batch read |
| `robot.state` | TCP position, joints, force, speed, snapshot |
| `robot.decision` | `ask()` choice dialog, `popup()` confirmation |
| `robot.modbus` | Modbus TCP connect / preset / read / write |
| `robot.touchstop` | TouchStop — detect contact and stop |
| `robot.compliance` | Compliance — compliant motion until resistance |
| `robot.force` | Force control with external FTSensor |
| `robot.vision` | Trigger vision jobs, get output pose |

---

## More Examples

### Read robot state

```python
s = robot.state.snapshot()
print(s.tcp_position)   # (X, Y, Z, Rx, Ry, Rz)
print(s.joint_angles)   # (J1 … J6)
print(s.tcp_force_3d)   # resultant force N
```

### TouchStop — find workpiece surface

```python
result = robot.touchstop.run(
    direction=32,    # Z−  (1=X+, 2=X−, 4=Y+, 8=Y−, 16=Z+, 32=Z−)
    distance=50.0,   # max travel mm
    force=5.0,       # contact threshold N
    speed=10,
)
if result == 5:      # Resisted
    z = robot.touchstop.get_stopped_pos()[2]
    print(f"Surface at Z = {z:.2f} mm")
```

### Multi-robot (12 concurrent)

```python
from concurrent.futures import ThreadPoolExecutor

robots = [TMRobot(f"192.168.1.{100+i}") for i in range(12)]
for r in robots:
    r.connect()

with ThreadPoolExecutor(max_workers=12) as pool:
    futures = [pool.submit(run_task, r) for r in robots]
    for f in futures:
        f.result()

for r in robots:
    r.disconnect()
```

### Modbus TCP

```python
robot.modbus.connect("192.168.1.10")
robot.modbus.preset("light", 1, "DO", 7206, "bool")
robot.modbus.write("light", True)
print(robot.modbus.read_bool("light"))
robot.modbus.disconnect()
```

### Vision-guided pick

```python
if robot.vision.do_job("DetectPart"):
    pose = robot.vision.get_output_pose("DetectPart", "ArmPose_0")
    robot.move.ptp(CartPoint(*pose), speed=20)
```

---

## Running Tests

```bash
pip install -e ".[dev]"
python -m pytest tests/ -v
```

All 259 tests run without a physical robot (mock-based unit tests).

---

## Documentation

Full API reference and tutorials (繁體中文): [`docs/wiki.md`](https://github.com/harry123180/TMDemo/blob/master/docs/wiki.md)

---

## License

MIT — see [LICENSE](LICENSE).
