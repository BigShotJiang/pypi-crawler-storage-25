"""
tests/test_serial_port.py — SerialPortController 單元測試

所有測試使用 MagicMock 取代 TMClientWrapper，不需要真實機器人連線。
驗證：
  - script_builder serial 函式輸出格式正確
  - SerialPortController open/close/write_bytes/write_string/writeline/read_bytes/read_string
  - session 變數宣告追蹤（sp_declared / rx_declared / rs_declared）
  - _parse_bytes_str 解析 GetString(byte[]) 回傳格式
  - parity 參數驗證
"""

from __future__ import annotations

from unittest.mock import MagicMock

import pytest

from pytmrobot import script_builder as sb
from pytmrobot.serial_port import SerialPortController, _parse_bytes_str
from pytmrobot.tag_manager import TagManager


# ── fixtures ──────────────────────────────────────────────────────────────────

@pytest.fixture
def ctrl():
    wrapper = MagicMock()
    tags    = TagManager()
    return SerialPortController(wrapper, tags), wrapper


# ── script_builder: build_serial_open ─────────────────────────────────────────

class TestBuildSerialOpen:
    def test_first_open_includes_declaration(self):
        lines = sb.build_serial_open("COM3", 9600, sp_declared=False)
        assert lines[0] == 'SerialPort _sp = "COM3", 9600, "none", 8, 1'
        assert lines[1] == 'com_open("_sp")'

    def test_subsequent_open_skips_declaration(self):
        lines = sb.build_serial_open("COM3", 115200, sp_declared=True)
        assert lines == ['com_open("_sp")']

    def test_with_timeout(self):
        lines = sb.build_serial_open("COM4", 9600, timeout_ms=5000, sp_declared=False)
        assert "5000" in lines[0]

    def test_custom_parity(self):
        lines = sb.build_serial_open("COM3", 9600, parity="odd", sp_declared=False)
        assert '"odd"' in lines[0]


# ── script_builder: write / read ──────────────────────────────────────────────

class TestBuildSerialWrite:
    def test_write_bytes(self):
        lines = sb.build_serial_write_bytes(b"\x01\x03\x00\x00")
        assert lines == ['com_write("_sp", {1,3,0,0})']

    def test_write_string(self):
        lines = sb.build_serial_write_string("AT+VER")
        assert lines == ['com_write("_sp", "AT+VER")']

    def test_writeline(self):
        lines = sb.build_serial_writeline("HELLO")
        assert lines == ['com_writeline("_sp", "HELLO")']

    def test_close(self):
        assert sb.build_serial_close() == ['com_close("_sp")']


class TestBuildSerialRead:
    def test_read_bytes_first_call(self):
        lines = sb.build_serial_read_bytes(8, 200, rx_declared=False)
        assert lines[0] == "byte[] _sp_rx = com_read(\"_sp\", 8, 200)"
        assert lines[1] == "ListenSend(90, GetString(_sp_rx))"

    def test_read_bytes_subsequent_call(self):
        lines = sb.build_serial_read_bytes(8, 200, rx_declared=True)
        assert lines[0] == '_sp_rx = com_read("_sp", 8, 200)'
        assert "byte[]" not in lines[0]

    def test_read_string_first_call(self):
        lines = sb.build_serial_read_string(16, 500, rs_declared=False)
        assert lines[0] == 'string _sp_rs = com_read_string("_sp", 16, 500)'
        assert lines[1] == "ListenSend(90, _sp_rs)"

    def test_read_string_subsequent_call(self):
        lines = sb.build_serial_read_string(16, 500, rs_declared=True)
        # 不應再有型別宣告 "string _sp_rs = ..."，只有賦值
        assert not lines[0].startswith("string ")


# ── _parse_bytes_str ──────────────────────────────────────────────────────────

class TestParseBytesStr:
    def test_normal(self):
        result = _parse_bytes_str("{1,3,0,0,0,1,132,10}")
        assert result == bytes([1, 3, 0, 0, 0, 1, 132, 10])

    def test_single_byte(self):
        assert _parse_bytes_str("{255}") == bytes([255])

    def test_empty(self):
        assert _parse_bytes_str("{}") == b""
        assert _parse_bytes_str("") == b""

    def test_without_braces(self):
        # 防禦性：若回傳不含 {}
        result = _parse_bytes_str("1,2,3")
        assert result == bytes([1, 2, 3])


# ── SerialPortController.open ─────────────────────────────────────────────────

class TestSerialOpen:
    def test_first_open_sets_declared(self, ctrl):
        c, wrapper = ctrl
        assert not c._sp_declared
        c.open("COM3", 9600)
        wrapper.send_script_checked.assert_called_once()
        assert c._sp_declared

    def test_second_open_uses_assignment(self, ctrl):
        c, wrapper = ctrl
        c.open("COM3", 9600)
        c.open("COM3", 9600)
        calls = wrapper.send_script_checked.call_args_list
        # 第一次呼叫包含宣告
        first_lines = calls[0][0][1]
        assert any("SerialPort" in ln for ln in first_lines)
        # 第二次不含宣告
        second_lines = calls[1][0][1]
        assert all("SerialPort" not in ln for ln in second_lines)

    def test_invalid_parity_raises(self, ctrl):
        c, _ = ctrl
        with pytest.raises(ValueError, match="parity"):
            c.open("COM3", 9600, parity="xyz")

    def test_reset_session_clears_declared(self, ctrl):
        c, _ = ctrl
        c._sp_declared = True
        c._rx_declared = True
        c._rs_declared = True
        c._reset_session()
        assert not c._sp_declared
        assert not c._rx_declared
        assert not c._rs_declared


# ── SerialPortController write / close ────────────────────────────────────────

class TestSerialWrite:
    def test_write_bytes_calls_checked(self, ctrl):
        c, wrapper = ctrl
        c.write_bytes(b"\x01\x03")
        wrapper.send_script_checked.assert_called_once()
        lines = wrapper.send_script_checked.call_args[0][1]
        assert 'com_write("_sp", {1,3})' in lines

    def test_write_string(self, ctrl):
        c, wrapper = ctrl
        c.write_string("HELLO")
        lines = wrapper.send_script_checked.call_args[0][1]
        assert 'com_write("_sp", "HELLO")' in lines

    def test_writeline(self, ctrl):
        c, wrapper = ctrl
        c.writeline("CMD")
        lines = wrapper.send_script_checked.call_args[0][1]
        assert 'com_writeline("_sp", "CMD")' in lines

    def test_close(self, ctrl):
        c, wrapper = ctrl
        c.close()
        lines = wrapper.send_script_checked.call_args[0][1]
        assert 'com_close("_sp")' in lines


# ── SerialPortController read_bytes ───────────────────────────────────────────

class TestSerialReadBytes:
    def test_read_bytes_returns_parsed(self, ctrl):
        c, wrapper = ctrl
        wrapper.send_and_recv_subcmd.return_value = "{1,2,3}"
        result = c.read_bytes(3)
        assert result == bytes([1, 2, 3])

    def test_read_bytes_sets_rx_declared(self, ctrl):
        c, wrapper = ctrl
        wrapper.send_and_recv_subcmd.return_value = "{0}"
        assert not c._rx_declared
        c.read_bytes(1)
        assert c._rx_declared

    def test_read_string_sets_rs_declared(self, ctrl):
        c, wrapper = ctrl
        wrapper.send_and_recv_subcmd.return_value = "OK"
        assert not c._rs_declared
        c.read_string(2)
        assert c._rs_declared

    def test_read_bytes_second_call_no_redeclare(self, ctrl):
        c, wrapper = ctrl
        wrapper.send_and_recv_subcmd.return_value = "{0}"
        c.read_bytes(1)
        c.read_bytes(1)
        second_call_lines = wrapper.send_and_recv_subcmd.call_args_list[1][0][1]
        assert all("byte[]" not in ln for ln in second_call_lines)
