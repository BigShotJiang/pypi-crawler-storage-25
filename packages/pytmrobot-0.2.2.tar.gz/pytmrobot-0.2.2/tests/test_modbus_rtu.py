"""
tests/test_modbus_rtu.py — ModbusRTU 單元測試

所有測試使用 MagicMock 取代 SerialPortController，不需要真實裝置連線。
驗證：
  - CRC16 Modbus 計算（使用已知標準訊框驗證）
  - _add_crc 尾部附加低位元組在前的 CRC
  - _validate 驗證 Slave ID、功能碼、CRC 各種失敗情境
  - FC01 read_coils：請求訊框、回傳解析
  - FC02 read_discrete_inputs
  - FC03 read_holding_registers：請求訊框、暫存器 big-endian 解碼
  - FC04 read_input_registers
  - FC05 write_coil：ON=0xFF00、OFF=0x0000
  - FC06 write_register：範圍驗證
  - FC16 write_registers：多暫存器寫入訊框
"""

from __future__ import annotations

from unittest.mock import MagicMock

import pytest

from pytmrobot.modbus_rtu import ModbusRTU
from pytmrobot.serial_port import SerialPortController


# ── fixtures ──────────────────────────────────────────────────────────────────

@pytest.fixture
def rtu():
    serial = MagicMock(spec=SerialPortController)
    return ModbusRTU(serial), serial


# ── CRC16 ─────────────────────────────────────────────────────────────────────

class TestCRC16:
    def test_known_frame(self):
        # FC03 read 1 register from addr 0, slave 1
        # 完整訊框：01 03 00 00 00 01 84 0A
        # CRC 整數值 = 0x0A84；低位元組 0x84 先傳，高位元組 0x0A 後傳
        data = bytes([0x01, 0x03, 0x00, 0x00, 0x00, 0x01])
        crc  = ModbusRTU._crc16(data)
        assert crc & 0xFF == 0x84         # 低位元組（先傳）
        assert (crc >> 8) & 0xFF == 0x0A  # 高位元組（後傳）

    def test_add_crc_appends_lo_hi(self):
        data  = bytes([0x01, 0x03, 0x00, 0x00, 0x00, 0x01])
        frame = ModbusRTU._add_crc(data)
        assert frame[-2] == 0x84  # CRC 低位元組先
        assert frame[-1] == 0x0A  # CRC 高位元組後
        assert len(frame) == len(data) + 2

    def test_crc_empty(self):
        # 空資料不應崩潰
        crc = ModbusRTU._crc16(b"")
        assert crc == 0xFFFF


# ── _validate ─────────────────────────────────────────────────────────────────

class TestValidate:
    def _make_valid(self, slave_id, fc, payload=b""):
        """建立有效的 Modbus RTU 回應訊框（加 CRC）。"""
        body = bytes([slave_id, fc]) + payload
        return ModbusRTU._add_crc(body)

    def test_valid_passes(self, rtu):
        m, _ = rtu
        resp = self._make_valid(1, 0x03, b"\x02\x00\x0A")  # 1 register = 10
        m._validate(resp, 1, 0x03)   # 不應拋出例外

    def test_too_short_raises(self, rtu):
        m, _ = rtu
        with pytest.raises(RuntimeError, match="過短"):
            m._validate(b"\x01", 1, 0x03)

    def test_wrong_slave_raises(self, rtu):
        m, _ = rtu
        resp = self._make_valid(2, 0x03, b"\x02\x00\x0A")
        with pytest.raises(RuntimeError, match="Slave ID"):
            m._validate(resp, 1, 0x03)

    def test_exception_response_raises(self, rtu):
        m, _ = rtu
        resp = self._make_valid(1, 0x83, b"\x02")  # FC03 例外 = 0x83
        with pytest.raises(RuntimeError, match="例外"):
            m._validate(resp, 1, 0x03)

    def test_wrong_fc_raises(self, rtu):
        m, _ = rtu
        resp = self._make_valid(1, 0x01, b"\x01\xFF")
        with pytest.raises(RuntimeError, match="功能碼"):
            m._validate(resp, 1, 0x03)

    def test_bad_crc_raises(self, rtu):
        m, _ = rtu
        resp = self._make_valid(1, 0x03, b"\x02\x00\x0A")
        corrupted = bytearray(resp)
        corrupted[-1] ^= 0xFF  # 破壞 CRC
        with pytest.raises(RuntimeError, match="CRC"):
            m._validate(bytes(corrupted), 1, 0x03)


# ── read_coils ────────────────────────────────────────────────────────────────

class TestReadCoils:
    def _coil_resp(self, slave_id, bits: list[bool]) -> bytes:
        """建立 FC01 回應訊框。"""
        n_bytes = (len(bits) + 7) // 8
        payload = bytearray(n_bytes)
        for i, b in enumerate(bits):
            if b:
                payload[i // 8] |= (1 << (i % 8))
        body = bytes([slave_id, 0x01, n_bytes]) + bytes(payload)
        return ModbusRTU._add_crc(body)

    def test_request_frame(self, rtu):
        m, serial = rtu
        serial.read_bytes.return_value = self._coil_resp(1, [True, False, True])
        m.read_coils(1, 0, 3)
        written = serial.write_bytes.call_args[0][0]
        assert written[0] == 1     # slave
        assert written[1] == 0x01  # FC
        assert written[2] == 0x00 and written[3] == 0x00   # addr
        assert written[4] == 0x00 and written[5] == 0x03   # count

    def test_result_parsed(self, rtu):
        m, serial = rtu
        serial.read_bytes.return_value = self._coil_resp(1, [True, False, True, False, False, True, False, False])
        result = m.read_coils(1, 0, 8)
        assert result == [True, False, True, False, False, True, False, False]


# ── read_holding_registers ────────────────────────────────────────────────────

class TestReadHoldingRegisters:
    def _reg_resp(self, slave_id, fc, values: list[int]) -> bytes:
        """建立 FC03/FC04 回應訊框。"""
        payload = bytearray()
        for v in values:
            payload += bytes([v >> 8, v & 0xFF])
        body = bytes([slave_id, fc, len(payload)]) + bytes(payload)
        return ModbusRTU._add_crc(body)

    def test_request_frame_fc03(self, rtu):
        m, serial = rtu
        serial.read_bytes.return_value = self._reg_resp(1, 0x03, [100])
        m.read_holding_registers(1, 0x0100, 1)
        written = serial.write_bytes.call_args[0][0]
        assert written[1] == 0x03  # FC
        assert written[2] == 0x01 and written[3] == 0x00  # addr = 0x0100
        assert written[4] == 0x00 and written[5] == 0x01  # count = 1

    def test_values_decoded_big_endian(self, rtu):
        m, serial = rtu
        serial.read_bytes.return_value = self._reg_resp(1, 0x03, [100, 200, 512])
        result = m.read_holding_registers(1, 0, 3)
        assert result == [100, 200, 512]

    def test_fc04_input_registers(self, rtu):
        m, serial = rtu
        serial.read_bytes.return_value = self._reg_resp(1, 0x04, [42, 0])
        result = m.read_input_registers(1, 0, 2)
        assert result[0] == 42

    def test_read_bytes_count(self, rtu):
        m, serial = rtu
        serial.read_bytes.return_value = self._reg_resp(1, 0x03, [1, 2, 3])
        m.read_holding_registers(1, 0, 3)
        count_arg = serial.read_bytes.call_args[0][0]
        assert count_arg == 5 + 3 * 2  # header(5) + 3 registers * 2 bytes


# ── write_coil ────────────────────────────────────────────────────────────────

class TestWriteCoil:
    def _echo_resp(self, slave_id, fc, addr, val_hi, val_lo) -> bytes:
        body = bytes([slave_id, fc, addr >> 8, addr & 0xFF, val_hi, val_lo])
        return ModbusRTU._add_crc(body)

    def test_write_coil_on(self, rtu):
        m, serial = rtu
        serial.read_bytes.return_value = self._echo_resp(1, 0x05, 0, 0xFF, 0x00)
        m.write_coil(1, 0, True)
        written = serial.write_bytes.call_args[0][0]
        assert written[4] == 0xFF and written[5] == 0x00

    def test_write_coil_off(self, rtu):
        m, serial = rtu
        serial.read_bytes.return_value = self._echo_resp(1, 0x05, 0, 0x00, 0x00)
        m.write_coil(1, 0, False)
        written = serial.write_bytes.call_args[0][0]
        assert written[4] == 0x00 and written[5] == 0x00


# ── write_register ────────────────────────────────────────────────────────────

class TestWriteRegister:
    def _echo_resp(self, slave_id, fc, addr, value) -> bytes:
        body = bytes([slave_id, fc, addr >> 8, addr & 0xFF, value >> 8, value & 0xFF])
        return ModbusRTU._add_crc(body)

    def test_write_register(self, rtu):
        m, serial = rtu
        serial.read_bytes.return_value = self._echo_resp(1, 0x06, 0x0100, 500)
        m.write_register(1, 0x0100, 500)
        written = serial.write_bytes.call_args[0][0]
        assert written[1] == 0x06
        assert written[2] == 0x01 and written[3] == 0x00
        assert written[4] == 0x01 and written[5] == 0xF4  # 500 = 0x01F4

    def test_value_out_of_range_raises(self, rtu):
        m, _ = rtu
        with pytest.raises(ValueError):
            m.write_register(1, 0, 70000)

    def test_negative_value_raises(self, rtu):
        m, _ = rtu
        with pytest.raises(ValueError):
            m.write_register(1, 0, -1)


# ── write_registers ───────────────────────────────────────────────────────────

class TestWriteRegisters:
    def _echo_resp(self, slave_id, addr, count) -> bytes:
        body = bytes([slave_id, 0x10, addr >> 8, addr & 0xFF, count >> 8, count & 0xFF])
        return ModbusRTU._add_crc(body)

    def test_request_frame_structure(self, rtu):
        m, serial = rtu
        serial.read_bytes.return_value = self._echo_resp(1, 0, 3)
        m.write_registers(1, 0, [100, 200, 300])
        written = serial.write_bytes.call_args[0][0]
        assert written[1] == 0x10                          # FC16
        assert written[6] == 6                             # byte count = 3*2
        assert written[7] == 0 and written[8] == 100       # reg0 = 100
        assert written[9] == 0 and written[10] == 200      # reg1 = 200
        assert written[11] == 1 and written[12] == 44      # reg2 = 300 = 0x012C

    def test_empty_list_no_call(self, rtu):
        m, serial = rtu
        m.write_registers(1, 0, [])
        serial.write_bytes.assert_not_called()

    def test_invalid_value_raises(self, rtu):
        m, _ = rtu
        with pytest.raises(ValueError):
            m.write_registers(1, 0, [100, -1, 200])
