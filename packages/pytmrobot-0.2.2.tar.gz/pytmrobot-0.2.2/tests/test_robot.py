"""
tests/test_robot.py — TMRobot 主類別單元測試

驗證：
  - 所有子控制器 property 回傳正確型別
  - connect() 呼叫所有控制器的 _reset_session()
  - context manager __enter__/__exit__ 正確連線/斷線
  - stop / sleep / change_base / change_tcp / change_load 送出正確 TMScript
  - run_script 轉交 wrapper
  - 多實例相互獨立（多機器人場景）
"""

from unittest.mock import MagicMock, patch

from pytmrobot.compliance import ComplianceController
from pytmrobot.decision import DecisionController
from pytmrobot.force import ForceController
from pytmrobot.io import IOController
from pytmrobot.modbus import ModbusManager
from pytmrobot.motion import MotionController
from pytmrobot.robot import TMRobot
from pytmrobot.state import StateReader
from pytmrobot.touchstop import TouchStopController
from pytmrobot.vision import VisionController


def make_robot() -> tuple[TMRobot, MagicMock]:
    """建立 TMRobot 並替換內部 wrapper 為 mock。"""
    robot = TMRobot.__new__(TMRobot)
    # 重新執行 __init__ 但先替換 TMClientWrapper
    with patch("pytmrobot.robot.TMClientWrapper") as MockWrapper:
        mock_wrapper = MagicMock()
        MockWrapper.return_value = mock_wrapper
        robot.__init__("192.168.1.101")
    return robot, mock_wrapper


# ── 子控制器型別 ──────────────────────────────────────────────────────────────

class TestProperties:
    def test_move_type(self):
        r, _ = make_robot()
        assert isinstance(r.move, MotionController)

    def test_io_type(self):
        r, _ = make_robot()
        assert isinstance(r.io, IOController)

    def test_state_type(self):
        r, _ = make_robot()
        assert isinstance(r.state, StateReader)

    def test_decision_type(self):
        r, _ = make_robot()
        assert isinstance(r.decision, DecisionController)

    def test_modbus_type(self):
        r, _ = make_robot()
        assert isinstance(r.modbus, ModbusManager)

    def test_touchstop_type(self):
        r, _ = make_robot()
        assert isinstance(r.touchstop, TouchStopController)

    def test_compliance_type(self):
        r, _ = make_robot()
        assert isinstance(r.compliance, ComplianceController)

    def test_force_type(self):
        r, _ = make_robot()
        assert isinstance(r.force, ForceController)

    def test_vision_type(self):
        r, _ = make_robot()
        assert isinstance(r.vision, VisionController)


# ── 連線管理 ──────────────────────────────────────────────────────────────────

class TestConnect:
    def test_connect_calls_wrapper_connect(self):
        r, wrapper = make_robot()
        r.connect()
        wrapper.connect.assert_called_once()

    def test_connect_sets_connected_flag(self):
        r, _ = make_robot()
        assert not r.is_connected
        r.connect()
        assert r.is_connected

    def test_connect_resets_all_sessions(self):
        r, _ = make_robot()
        # 給各 controller 設一些「已宣告」狀態
        r._io._io_vars_declared = True
        r._decision._declared = {"_md": True}
        r._modbus._mbus_declared = True
        r._touchstop._declared = {"_ts": True}
        r._compliance._declared = {"_cp": True}
        r._force._declared = {"_fc": True}
        r._vision._declared = {"_vj": True}

        r.connect()

        assert not r._io._io_vars_declared
        assert not r._decision._declared
        assert not r._modbus._mbus_declared
        assert not r._touchstop._declared
        assert not r._compliance._declared
        assert not r._force._declared
        assert not r._vision._declared

    def test_disconnect_clears_connected_flag(self):
        r, _ = make_robot()
        r.connect()
        r.disconnect()
        assert not r.is_connected

    def test_disconnect_only_when_connected(self):
        r, wrapper = make_robot()
        r.disconnect()   # 尚未連線，不應報錯
        wrapper.disconnect.assert_not_called()


# ── Context Manager ───────────────────────────────────────────────────────────

class TestContextManager:
    def test_enter_returns_robot(self):
        r, _ = make_robot()
        result = r.__enter__()
        assert result is r

    def test_exit_disconnects(self):
        r, wrapper = make_robot()
        r.connect()
        r.__exit__(None, None, None)
        wrapper.disconnect.assert_called()

    def test_exit_does_not_suppress_exception(self):
        r, _ = make_robot()
        r.connect()
        result = r.__exit__(ValueError, ValueError("test"), None)
        assert result is False


# ── 直接動作 ──────────────────────────────────────────────────────────────────

class TestDirectActions:
    def test_stop_mode_0(self):
        r, wrapper = make_robot()
        r.stop()
        lines = wrapper.send_script_checked.call_args[0][1]
        assert lines[0] == "StopAndClearBuffer(0)"

    def test_stop_mode_1(self):
        r, wrapper = make_robot()
        r.stop(mode=1)
        lines = wrapper.send_script_checked.call_args[0][1]
        assert lines[0] == "StopAndClearBuffer(1)"

    def test_sleep(self):
        r, wrapper = make_robot()
        r.sleep(500)
        lines = wrapper.send_script_checked.call_args[0][1]
        assert lines[0] == "Sleep(500)"

    def test_change_base(self):
        r, wrapper = make_robot()
        r.change_base("WorkFrame1")
        lines = wrapper.send_script_checked.call_args[0][1]
        assert lines[0] == 'ChangeBase("WorkFrame1")'

    def test_change_base_empty(self):
        r, wrapper = make_robot()
        r.change_base("")
        lines = wrapper.send_script_checked.call_args[0][1]
        assert lines[0] == 'ChangeBase("")'

    def test_change_tcp(self):
        r, wrapper = make_robot()
        r.change_tcp("Gripper")
        lines = wrapper.send_script_checked.call_args[0][1]
        assert lines[0] == 'ChangeTCP("Gripper")'

    def test_change_load(self):
        r, wrapper = make_robot()
        r.change_load(2.5)
        lines = wrapper.send_script_checked.call_args[0][1]
        assert lines[0] == "ChangeLoad(2.5)"

    def test_run_script(self):
        r, wrapper = make_robot()
        wrapper.send_script.return_value = True
        ok = r.run_script(["Sleep(100)"])
        assert ok is True
        wrapper.send_script.assert_called_once()


# ── repr ─────────────────────────────────────────────────────────────────────

class TestRepr:
    def test_repr_disconnected(self):
        r, _ = make_robot()
        s = repr(r)
        assert "disconnected" in s
        assert "192.168.1.101" in s

    def test_repr_connected(self):
        r, _ = make_robot()
        r.connect()
        s = repr(r)
        assert "connected" in s


# ── 多實例獨立性（多機器人場景）────────────────────────────────────────────────

class TestMultiRobot:
    def test_two_robots_independent_tags(self):
        r1, _ = make_robot()
        r2, _ = make_robot()
        # 各自的 TagManager 獨立計數
        t1 = r1._tags.next()
        t2 = r2._tags.next()
        # 兩個都從 1 開始，但互不影響
        assert t1 == 1
        assert t2 == 1

    def test_two_robots_independent_session_state(self):
        r1, _ = make_robot()
        r2, _ = make_robot()
        r1._io._io_vars_declared = True
        assert not r2._io._io_vars_declared   # r2 不受 r1 影響

    def test_twelve_robots_create_successfully(self):
        robots = [make_robot()[0] for _ in range(12)]
        assert len(robots) == 12
        # 每個都有獨立子控制器
        ids = {id(r._tags) for r in robots}
        assert len(ids) == 12   # 12 個不同的 TagManager 實例
