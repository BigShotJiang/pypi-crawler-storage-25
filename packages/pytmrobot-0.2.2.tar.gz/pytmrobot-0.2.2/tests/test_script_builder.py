"""
tests/test_script_builder.py — TMScript 字串生成純函式測試

不需要機器人或任何網路連線，直接驗證輸出字串的格式。
執行：
    python -m pytest tests/test_script_builder.py -v
"""

import os
import sys

# 確保可以 import pytmrobot
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import pytest

from pytmrobot import script_builder as sb
from pytmrobot.types import BlendUnit, CartPoint, JointPoint, SpeedUnit

# ── fmt_array ────────────────────────────────────────────────────────────────

class TestFmtArray:
    def test_basic(self):
        result = sb.fmt_array([400.0, -100.0, 350.0, 180.0, 0.0, 90.0])
        assert result == "{400.0,-100.0,350.0,180.0,0.0,90.0}"

    def test_integer_like_float(self):
        result = sb.fmt_array([0.0, 0.0, 0.0, 0.0, 0.0, 0.0])
        assert result == "{0.0,0.0,0.0,0.0,0.0,0.0}"

    def test_negative(self):
        result = sb.fmt_array([-122.2])
        assert result == "{-122.2}"

    def test_trailing_zeros_stripped(self):
        # 400.000000 → "400.0"
        r = sb.fmt_array([400.000000])
        assert r == "{400.0}"


# ── build_ptp ────────────────────────────────────────────────────────────────

class TestBuildPtp:
    def test_cart_point(self):
        lines = sb.build_ptp(
            CartPoint(400, -100, 350, 180, 0, 90),
            speed=10, accel_ms=200, blend=0, tag_id=1, wait=True,
        )
        assert len(lines) == 2
        assert lines[0] == 'PTP("CPP",{400.0,-100.0,350.0,180.0,0.0,90.0},10,200,0,false)'
        assert lines[1] == "QueueTag(1,1)"

    def test_joint_point(self):
        lines = sb.build_ptp(
            JointPoint(0, -6.5, 96.1, 0.4, 90, 0),
            speed=20, accel_ms=300, blend=5, tag_id=3, wait=True,
        )
        assert lines[0].startswith('PTP("JPP",')
        assert "QueueTag(3,1)" in lines[1]

    def test_no_wait(self):
        lines = sb.build_ptp(
            CartPoint(400, -100, 350, 180, 0, 90),
            speed=10, accel_ms=200, blend=0, tag_id=5, wait=False,
        )
        # wait=False → QueueTag(n) 沒有 ,1
        assert lines[1] == "QueueTag(5)"

    def test_wrong_type_raises(self):
        with pytest.raises(TypeError):
            sb.build_ptp((400, -100, 350), speed=10, accel_ms=200, blend=0, tag_id=1)  # type: ignore


# ── build_line ───────────────────────────────────────────────────────────────

class TestBuildLine:
    def test_cdp_default(self):
        lines = sb.build_line(
            CartPoint(450, -100, 350, 180, 0, 90),
            SpeedUnit.ABS_LOCK, BlendUnit.PERCENT,
            speed=150, accel_ms=200, blend=0, tag_id=2, wait=True,
        )
        assert lines[0] == 'Line("CDP",{450.0,-100.0,350.0,180.0,0.0,90.0},150,200,0,false)'
        assert lines[1] == "QueueTag(2,1)"

    def test_cap_mode(self):
        lines = sb.build_line(
            CartPoint(450, -100, 350, 180, 0, 90),
            SpeedUnit.ABS_SYNC, BlendUnit.PERCENT,
            speed=100, accel_ms=200, blend=0, tag_id=3, wait=True,
        )
        assert '"CAP"' in lines[0]

    def test_cpp_percent(self):
        lines = sb.build_line(
            CartPoint(450, -100, 350, 180, 0, 90),
            SpeedUnit.PERCENT, BlendUnit.PERCENT,
            speed=50, accel_ms=200, blend=0, tag_id=4, wait=True,
        )
        assert '"CPP"' in lines[0]

    def test_cdr_radius(self):
        lines = sb.build_line(
            CartPoint(450, -100, 350, 180, 0, 90),
            SpeedUnit.ABS_LOCK, BlendUnit.RADIUS,
            speed=100, accel_ms=200, blend=5, tag_id=5, wait=True,
        )
        assert '"CDR"' in lines[0]


# ── build_circle ─────────────────────────────────────────────────────────────

class TestBuildCircle:
    def test_basic(self):
        via = CartPoint(420, -50, 350, 180, 0, 90)
        end = CartPoint(400, 0,  350, 180, 0, 90)
        lines = sb.build_circle(
            via, end, SpeedUnit.ABS_LOCK,
            speed=100, accel_ms=200, blend=0, angle=0, tag_id=6,
        )
        assert len(lines) == 2
        assert lines[0].startswith('Circle("CDP",')
        assert "QueueTag(6,1)" in lines[1]

    def test_abs_sync(self):
        via = CartPoint(420, -50, 350, 180, 0, 90)
        end = CartPoint(400, 0,  350, 180, 0, 90)
        lines = sb.build_circle(
            via, end, SpeedUnit.ABS_SYNC,
            speed=80, accel_ms=200, blend=0, angle=0, tag_id=7,
        )
        assert '"CAP"' in lines[0]


# ── build_set_do ─────────────────────────────────────────────────────────────

class TestBuildSetDo:
    def test_high(self):
        assert sb.build_set_do(2, True, "ControlBox", False) == 'IO["ControlBox"].DO[2] = 1'

    def test_low(self):
        assert sb.build_set_do(0, False, "ControlBox", False) == 'IO["ControlBox"].DO[0] = 0'

    def test_instant(self):
        result = sb.build_set_do(3, True, "ControlBox", True)
        assert "InstantDO" in result
        assert result == 'IO["ControlBox"].InstantDO[3] = 1'

    def test_end_module(self):
        result = sb.build_set_do(0, True, "EndModule", False)
        assert '"EndModule"' in result


# ── build_set_ao ─────────────────────────────────────────────────────────────

class TestBuildSetAo:
    def test_basic(self):
        result = sb.build_set_ao(0, 3.3, "ControlBox", False)
        assert result == 'IO["ControlBox"].AO[0] = 3.3'

    def test_zero(self):
        result = sb.build_set_ao(1, 0.0, "ControlBox", False)
        assert result == 'IO["ControlBox"].AO[1] = 0.0'

    def test_instant(self):
        result = sb.build_set_ao(0, 5.0, "ControlBox", True)
        assert "InstantAO" in result


# ── build_read_tcp_position ───────────────────────────────────────────────────

class TestBuildReadTcpPosition:
    def test_returns_one_line(self):
        lines = sb.build_read_tcp_position()
        assert len(lines) == 1

    def test_listen_send_and_coords(self):
        line = sb.build_read_tcp_position()[0]
        assert line.startswith("ListenSend(90,")
        assert "Robot[0].CoordRobot" in line
        for i in range(6):
            assert f"CoordRobot[{i}]" in line

    def test_uses_get_string(self):
        line = sb.build_read_tcp_position()[0]
        assert "GetString(" in line


# ── build_read_joint_angles ──────────────────────────────────────────────────

class TestBuildReadJointAngles:
    def test_returns_one_line(self):
        lines = sb.build_read_joint_angles()
        assert len(lines) == 1

    def test_listen_send_and_joints(self):
        line = sb.build_read_joint_angles()[0]
        assert line.startswith("ListenSend(90,")
        assert "Robot[0].Joint" in line
        for i in range(6):
            assert f"Joint[{i}]" in line


# ── build_read_di / build_read_ai ────────────────────────────────────────────

class TestBuildReadIO:
    def test_di_pin(self):
        line = sb.build_read_di(3, "ControlBox")[0]
        assert 'IO["ControlBox"].DI[3]' in line
        assert "GetString(" in line

    def test_ai_pin(self):
        line = sb.build_read_ai(1, "ControlBox")[0]
        assert 'IO["ControlBox"].AI[1]' in line


# ── build_read_all_io ────────────────────────────────────────────────────────

class TestBuildReadAllIO:
    def test_first_call_uses_declarations(self):
        lines = sb.build_read_all_io("ControlBox", vars_declared=False)
        assert any("byte[]  _io_di" in ln for ln in lines)
        assert any("float[] _io_ai" in ln for ln in lines)
        listen = lines[-1]
        assert listen.startswith("ListenSend(90,")
        assert '"DI:"' in listen and '"|DO:"' in listen

    def test_subsequent_call_uses_assignment(self):
        lines = sb.build_read_all_io("ControlBox", vars_declared=True)
        assert all("byte[]" not in ln and "float[]" not in ln for ln in lines[:-1])
        assert lines[0].startswith("_io_di = ")

    def test_listen_send_uses_get_string_arrays(self):
        lines = sb.build_read_all_io("ControlBox")
        listen = lines[-1]
        assert "GetString(_io_di)" in listen
        assert "GetString(_io_ai)" in listen


# ── build_batch_snapshot ──────────────────────────────────────────────────────

class TestBuildBatchSnapshot:
    def test_returns_one_line(self):
        lines = sb.build_batch_snapshot()
        assert len(lines) == 1

    def test_contains_all_state(self):
        line = sb.build_batch_snapshot()[0]
        assert "CoordRobot" in line
        assert "Joint" in line
        assert "TCPForce3D" in line
        assert "TCPSpeed3D" in line
        assert "BaseName" in line
        assert "TCPName" in line
        assert "Payload" in line


# ── build_sleep / build_stop ──────────────────────────────────────────────────

class TestBuildUtils:
    def test_sleep(self):
        assert sb.build_sleep(1000) == "Sleep(1000)"
        assert sb.build_sleep(0) == "Sleep(0)"

    def test_stop(self):
        assert sb.build_stop(0) == "StopAndClearBuffer(0)"
        assert sb.build_stop(1) == "StopAndClearBuffer(1)"

    def test_change_base(self):
        assert sb.build_change_base("RobotBase") == 'ChangeBase("RobotBase")'

    def test_change_tcp(self):
        assert sb.build_change_tcp("Gripper") == 'ChangeTCP("Gripper")'

    def test_change_load(self):
        assert sb.build_change_load(2.5) == "ChangeLoad(2.5)"

    def test_script_exit(self):
        assert sb.build_script_exit(True)  == "ScriptExit(1)"
        assert sb.build_script_exit(False) == "ScriptExit(0)"


# ── build_decision_ask ────────────────────────────────────────────────────────

class TestBuildDecisionAsk:
    def test_first_call_declares_object(self):
        lines = sb.build_decision_ask("T", "M", ["Yes", "No"], -1, declared=False)
        assert lines[0] == 'MDecision _md = "T", "M"'
        assert 'int _r = _md.Show()' in lines
        assert 'ListenSend(90, GetString(_r))' in lines

    def test_subsequent_call_uses_reset(self):
        lines = sb.build_decision_ask("T2", "M2", ["OK"], -1, declared=True)
        assert lines[0] == '_md.Reset()'
        assert '_md.Title("T2")' in lines
        assert '_md.Description("M2")' in lines
        assert '_r = _md.Show()' in lines           # 賦值，不宣告
        assert 'int _r' not in " ".join(lines)

    def test_cases_appended(self):
        lines = sb.build_decision_ask("T", "M", ["A", "B", "C"], -1, declared=False)
        assert '_md.Case(0, "A")' in lines
        assert '_md.Case(1, "B")' in lines
        assert '_md.Case(2, "C")' in lines

    def test_timeout_included_when_positive(self):
        lines = sb.build_decision_ask("T", "M", ["A", "B"], 5000, declared=False)
        assert any("_md.Timeout(5000," in ln for ln in lines)

    def test_no_timeout_when_minus_one(self):
        lines = sb.build_decision_ask("T", "M", ["A"], -1, declared=False)
        assert not any("Timeout" in ln for ln in lines)


# ── build_popup ───────────────────────────────────────────────────────────────

class TestBuildPopup:
    def test_basic(self):
        lines = sb.build_popup("Title", "Msg", -1, 1)
        assert lines[0] == 'Popup("Title", "Msg", -1)'
        assert lines[1] == "QueueTag(1,1)"

    def test_positive_timeout(self):
        lines = sb.build_popup("T", "M", 3000, 2)
        assert lines[0] == 'Popup("T", "M", 3000)'

    def test_queue_tag_no_wait(self):
        lines = sb.build_popup("T", "M", -1, 5)
        # build_popup 固定 wait=True（等操作員確認）
        assert lines[1] == "QueueTag(5,1)"


# ── build_pvt_* ───────────────────────────────────────────────────────────────

class TestBuildPvt:
    def test_pvt_enter_cart(self):
        assert sb.build_pvt_enter(1) == "PVTEnter(1)"

    def test_pvt_enter_joint(self):
        assert sb.build_pvt_enter(2) == "PVTEnter(2)"

    def test_pvt_point_cpp(self):
        result = sb.build_pvt_point(
            "CPP",
            [400.0, -100.0, 350.0, 180.0, 0.0, 90.0],
            [10.0, 0.0, 0.0, 0.0, 0.0, 0.0],
            1000,
        )
        assert result.startswith('PVTPoint("CPP",')
        assert result.endswith(",1000)")
        assert "{400.0,-100.0,350.0,180.0,0.0,90.0}" in result
        assert "{10.0,0.0,0.0,0.0,0.0,0.0}" in result

    def test_pvt_pause(self):
        assert sb.build_pvt_pause() == "PVTPause()"

    def test_pvt_resume(self):
        assert sb.build_pvt_resume() == "PVTResume()"

    def test_pvt_exit_wait(self):
        lines = sb.build_pvt_exit(3, wait=True)
        assert lines[0] == "PVTExit()"
        assert lines[1] == "QueueTag(3,1)"

    def test_pvt_exit_no_wait(self):
        lines = sb.build_pvt_exit(4, wait=False)
        assert lines[0] == "PVTExit()"
        assert lines[1] == "QueueTag(4)"


# ── build_modbus_* ────────────────────────────────────────────────────────────

class TestBuildModbus:
    def test_connect_first_call(self):
        lines = sb.build_modbus_connect("192.168.1.10", 502, mbus_declared=False)
        assert lines[0] == 'ModbusTCP _mbus = "192.168.1.10", 502'
        assert lines[1] == 'modbus_open("_mbus")'

    def test_connect_subsequent_call(self):
        lines = sb.build_modbus_connect("192.168.1.10", 502, mbus_declared=True)
        assert lines == ['modbus_open("_mbus")']

    def test_disconnect(self):
        assert sb.build_modbus_disconnect() == ['modbus_close("_mbus")']

    def test_preset_first_call(self):
        lines = sb.build_modbus_preset("light", 1, "DO", 7206, "bool", 1, var_declared=False)
        assert lines[0] == 'bool _mb_pr = _mbus.Preset("light", 1, "DO", 7206, "bool", 1)'
        assert lines[1] == 'ListenSend(90, GetString(_mb_pr))'

    def test_preset_subsequent_call(self):
        lines = sb.build_modbus_preset("light", 1, "DO", 7206, "bool", 1, var_declared=True)
        assert lines[0] == '_mb_pr = _mbus.Preset("light", 1, "DO", 7206, "bool", 1)'
        assert not lines[0].startswith('bool ')   # 行首沒有型別宣告

    def test_preset_int32_extra(self):
        lines = sb.build_modbus_preset("cnt", 1, "RO", 100, "int32", 0, var_declared=False)
        assert '"int32", 0' in lines[0]


# ── build_touchstop_setup ─────────────────────────────────────────────────────

class TestBuildTouchstopSetup:
    def test_first_call(self):
        lines = sb.build_touchstop_setup(32, 50.0, 5.0, 10, obj_declared=False)
        assert lines[0] == 'TouchStop _ts = "Compliance"'
        assert lines[1] == "_ts.Frame(1)"
        assert lines[2] == "_ts.Single(32, 50.0, 5.0, 10)"

    def test_subsequent_call_uses_reset(self):
        lines = sb.build_touchstop_setup(16, 30.0, 3.0, 5, obj_declared=True)
        assert lines[0] == "_ts.Reset()"
        assert lines[1] == "_ts.Frame(1)"

    def test_timeout_included(self):
        lines = sb.build_touchstop_setup(32, 50.0, 5.0, 10, timeout_ms=3000, obj_declared=False)
        assert "_ts.Timeout(3000)" in lines

    def test_no_timeout_when_minus_one(self):
        lines = sb.build_touchstop_setup(32, 50.0, 5.0, 10, timeout_ms=-1, obj_declared=False)
        assert not any("Timeout" in ln for ln in lines)

    def test_custom_frame(self):
        lines = sb.build_touchstop_setup(16, 20.0, 2.0, 5, frame=2, obj_declared=False)
        assert "_ts.Frame(2)" in lines

    def test_custom_mode(self):
        lines = sb.build_touchstop_setup(32, 50.0, 5.0, 10, mode="Joint", obj_declared=False)
        assert lines[0] == 'TouchStop _ts = "Joint"'


# ── build_compliance_setup ────────────────────────────────────────────────────

class TestBuildComplianceSetup:
    def test_first_call(self):
        lines = sb.build_compliance_setup(32, 30.0, 3.0, 5, obj_declared=False)
        assert lines[0] == "Compliance _cp"
        assert lines[1] == "_cp.Frame(1)"
        assert lines[2] == "_cp.Single(32, 30.0, 3.0, 5)"

    def test_subsequent_call_uses_reset(self):
        lines = sb.build_compliance_setup(16, 20.0, 2.0, 3, obj_declared=True)
        assert lines[0] == "_cp.Reset()"

    def test_high_resistance_included(self):
        lines = sb.build_compliance_setup(32, 30.0, 3.0, 5, high_resistance=True, obj_declared=False)
        assert "_cp.HighResistance(true)" in lines

    def test_no_high_resistance_by_default(self):
        lines = sb.build_compliance_setup(32, 30.0, 3.0, 5, obj_declared=False)
        assert not any("HighResistance" in ln for ln in lines)

    def test_timeout_included(self):
        lines = sb.build_compliance_setup(32, 30.0, 3.0, 5, timeout_ms=4000, obj_declared=False)
        assert "_cp.Timeout(4000)" in lines


# ── build_ftsensor_open / build_force_setup ───────────────────────────────────

class TestBuildForce:
    def test_ftsensor_first_call(self):
        lines = sb.build_ftsensor_open("ATI", fts_declared=False)
        assert lines == ['FTSensor _fts = "ATI"']

    def test_ftsensor_subsequent_call(self):
        lines = sb.build_ftsensor_open("ATI", fts_declared=True)
        assert lines == []

    def test_force_setup_first_call(self):
        lines = sb.build_force_setup([("Fz", True, 5.0, 2)], obj_declared=False)
        assert lines[0] == 'Force _fc = "_fts"'
        assert lines[1] == "_fc.Frame(1)"
        assert lines[2] == '_fc.FTSet("Fz", true, 5.0, 2)'

    def test_force_setup_subsequent_call(self):
        lines = sb.build_force_setup([("Fz", True, 5.0, 2)], obj_declared=True)
        assert lines[0] == "_fc.Reset()"

    def test_force_setup_multiple_axes(self):
        lines = sb.build_force_setup(
            [("Fz", True, 5.0, 2), ("Mx", True, 0.5, 2)],
            obj_declared=False,
        )
        assert '_fc.FTSet("Fz", true, 5.0, 2)' in lines
        assert '_fc.FTSet("Mx", true, 0.5, 2)' in lines

    def test_force_setup_disabled_axis(self):
        lines = sb.build_force_setup([("Fy", False, 0.0, 1)], obj_declared=False)
        assert '_fc.FTSet("Fy", false, 0.0, 1)' in lines

    def test_force_setup_distance(self):
        lines = sb.build_force_setup([("Fz", True, 5.0, 2)], distance_mm=20.0, obj_declared=False)
        assert "_fc.Distance(20.0)" in lines

    def test_force_setup_no_distance_when_negative(self):
        lines = sb.build_force_setup([("Fz", True, 5.0, 2)], distance_mm=-1.0, obj_declared=False)
        assert not any("Distance" in ln for ln in lines)

    def test_force_setup_timeout(self):
        lines = sb.build_force_setup([("Fz", True, 5.0, 2)], timeout_ms=5000, obj_declared=False)
        assert "_fc.Timeout(5000)" in lines


# ── build_vision_* ────────────────────────────────────────────────────────────

class TestBuildVision:
    def test_do_job_first_call(self):
        lines = sb.build_vision_do_job("Job1", var_declared=False)
        assert lines[0] == 'bool _vj = Vision_DoJob("Job1")'
        assert lines[1] == "ListenSend(90, GetString(_vj))"

    def test_do_job_subsequent_call(self):
        lines = sb.build_vision_do_job("Job1", var_declared=True)
        assert lines[0] == '_vj = Vision_DoJob("Job1")'
        assert not lines[0].startswith("bool ")

    def test_is_available_first_call(self):
        lines = sb.build_vision_is_available("Job2", var_declared=False)
        assert lines[0] == 'bool _va = Vision_IsJobAvailable("Job2")'
        assert lines[1] == "ListenSend(90, GetString(_va))"

    def test_is_available_subsequent_call(self):
        lines = sb.build_vision_is_available("Job2", var_declared=True)
        assert lines[0] == '_va = Vision_IsJobAvailable("Job2")'

    def test_get_output_first_call(self):
        lines = sb.build_vision_get_output("Job1", "Detect_Model_0", var_declared=False)
        assert lines[0] == 'string _vo = GetOutputArrayValue("Job1", "Detect_Model_0")'
        assert lines[1] == "ListenSend(90, _vo)"

    def test_get_output_subsequent_call(self):
        lines = sb.build_vision_get_output("Job1", "ArmPose_0", var_declared=True)
        assert lines[0] == '_vo = GetOutputArrayValue("Job1", "ArmPose_0")'
        assert not lines[0].startswith("string ")
