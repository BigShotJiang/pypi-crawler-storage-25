"""
tests/test_state.py — StateReader 單元測試

驗證：
  - tcp_position / joint_angles 正確解析 CSV → Pose6
  - tcp_force / tcp_speed 解析單一浮點數
  - snapshot() 解析全部 17 欄位為 RobotState
"""

from unittest.mock import MagicMock

from pytmrobot.state import StateReader
from pytmrobot.tag_manager import TagManager
from pytmrobot.types import RobotState


def make_state(recv: str) -> tuple[StateReader, MagicMock]:
    client = MagicMock()
    client.send_and_recv_subcmd.return_value = recv
    return StateReader(client, TagManager()), client


# ── tcp_position ──────────────────────────────────────────────────────────────

class TestTcpPosition:
    def test_parses_pose6(self):
        ctrl, _ = make_state("400.0,-100.0,350.0,180.0,0.0,90.0")
        pos = ctrl.tcp_position
        assert len(pos) == 6
        assert abs(pos[0] - 400.0) < 1e-6
        assert abs(pos[1] - (-100.0)) < 1e-6
        assert abs(pos[5] - 90.0) < 1e-6

    def test_sends_listen_send(self):
        ctrl, client = make_state("0.0,0.0,0.0,0.0,0.0,0.0")
        _ = ctrl.tcp_position
        lines = client.send_and_recv_subcmd.call_args[0][1]
        assert any("ListenSend" in ln for ln in lines)
        assert any("CoordRobot" in ln for ln in lines)

    def test_returns_float_tuple(self):
        ctrl, _ = make_state("1.5,2.5,3.5,4.5,5.5,6.5")
        pos = ctrl.tcp_position
        assert all(isinstance(v, float) for v in pos)


# ── joint_angles ──────────────────────────────────────────────────────────────

class TestJointAngles:
    def test_parses_six_joints(self):
        ctrl, _ = make_state("0.0,-6.5,96.1,0.4,90.0,0.0")
        j = ctrl.joint_angles
        assert abs(j[1] - (-6.5)) < 1e-6
        assert abs(j[4] - 90.0)   < 1e-6

    def test_script_contains_joint(self):
        ctrl, client = make_state("0.0,0.0,0.0,0.0,0.0,0.0")
        _ = ctrl.joint_angles
        lines = client.send_and_recv_subcmd.call_args[0][1]
        assert any("Joint" in ln for ln in lines)


# ── tcp_force / tcp_speed ─────────────────────────────────────────────────────

class TestTcpForcSpeed:
    def test_force_float(self):
        ctrl, _ = make_state("3.14")
        assert abs(ctrl.tcp_force - 3.14) < 1e-6

    def test_speed_float(self):
        ctrl, _ = make_state("250.5")
        assert abs(ctrl.tcp_speed - 250.5) < 1e-6


# ── snapshot ──────────────────────────────────────────────────────────────────

class TestSnapshot:
    _CSV = (
        "400.0,-100.0,350.0,180.0,0.0,90.0,"   # tcp_position (6)
        "0.0,-6.5,96.1,0.4,90.0,0.0,"          # joint_angles (6)
        "2.5,"                                   # tcp_force_3d
        "150.0,"                                 # tcp_speed_3d
        "RobotBase,"                             # base_name
        "Gripper,"                               # tcp_name
        "1.5"                                    # payload_kg
    )

    def test_returns_robot_state(self):
        ctrl, _ = make_state(self._CSV)
        s = ctrl.snapshot()
        assert isinstance(s, RobotState)

    def test_tcp_position_correct(self):
        ctrl, _ = make_state(self._CSV)
        s = ctrl.snapshot()
        assert abs(s.tcp_position[0] - 400.0)  < 1e-6
        assert abs(s.tcp_position[5] - 90.0)   < 1e-6

    def test_joint_angles_correct(self):
        ctrl, _ = make_state(self._CSV)
        s = ctrl.snapshot()
        assert abs(s.joint_angles[1] - (-6.5)) < 1e-6
        assert abs(s.joint_angles[4] - 90.0)   < 1e-6

    def test_scalar_fields(self):
        ctrl, _ = make_state(self._CSV)
        s = ctrl.snapshot()
        assert abs(s.tcp_force_3d - 2.5)  < 1e-6
        assert abs(s.tcp_speed_3d - 150.0) < 1e-6
        assert abs(s.payload_kg - 1.5)    < 1e-6

    def test_string_fields(self):
        ctrl, _ = make_state(self._CSV)
        s = ctrl.snapshot()
        assert s.base_name == "RobotBase"
        assert s.tcp_name  == "Gripper"
