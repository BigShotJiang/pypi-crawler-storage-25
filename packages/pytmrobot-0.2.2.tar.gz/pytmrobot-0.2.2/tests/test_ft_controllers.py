"""
tests/test_ft_controllers.py — TouchStop / Compliance / Force 單元測試

驗證：
  - 首次呼叫宣告 TMScript 物件，後續呼叫使用 Reset()
  - _reset_session() 清除所有宣告狀態
  - _run() 組裝 setup + Start() + ListenSend 並回傳整數結果碼
  - ForceController.open_sensor() 首次宣告 FTSensor，後續不重複
  - stop() 呼叫正確
  - get_stopped_pos / get_triggered_pos 解析 float[] → Pose6
"""

from unittest.mock import MagicMock

# ════════════════════════════════════════════════════════
#  共用工具
# ════════════════════════════════════════════════════════

def _first_send_lines(client: MagicMock) -> list[str]:
    """取得第一次 send_and_recv_subcmd 呼叫的 lines 參數。"""
    return client.send_and_recv_subcmd.call_args[0][1]


def _first_checked_lines(client: MagicMock) -> list[str]:
    """取得第一次 send_script_checked 呼叫的 lines 參數。"""
    return client.send_script_checked.call_args[0][1]


# ════════════════════════════════════════════════════════
#  _FTBase（透過 TouchStopController 間接測試）
# ════════════════════════════════════════════════════════

class TestFTBaseAssign:
    """驗證 _assign() 的型別宣告 vs 賦值邏輯。"""

    def test_first_assign_includes_type(self, touchstop_ctrl):
        ctrl, client = touchstop_ctrl
        client.send_and_recv_subcmd.return_value = "5"
        ctrl.run(32, 50.0, 5.0, 10)
        lines = _first_send_lines(client)
        # 結果變數 _ts_r 應以 'int _ts_r = ...' 宣告
        assert any(ln.startswith("int _ts_r") for ln in lines)

    def test_subsequent_assign_no_type(self, touchstop_ctrl):
        ctrl, client = touchstop_ctrl
        client.send_and_recv_subcmd.return_value = "5"
        ctrl.run(32, 50.0, 5.0, 10)
        ctrl.run(32, 50.0, 5.0, 10)
        lines = _first_send_lines(client)
        # 第二次不應出現 'int _ts_r'
        assert not any(ln.startswith("int _ts_r") for ln in lines)
        # 但仍有 '_ts_r = ...'
        assert any("_ts_r" in ln and "=" in ln for ln in lines)

    def test_reset_session_forces_redeclare(self, touchstop_ctrl):
        ctrl, client = touchstop_ctrl
        client.send_and_recv_subcmd.return_value = "5"
        ctrl.run(32, 50.0, 5.0, 10)
        ctrl._reset_session()
        ctrl.run(32, 50.0, 5.0, 10)
        lines = _first_send_lines(client)
        # 重設後再次宣告
        assert any(ln.startswith("int _ts_r") for ln in lines)


# ════════════════════════════════════════════════════════
#  TouchStopController
# ════════════════════════════════════════════════════════

class TestTouchStop:
    def test_first_run_declares_ts(self, touchstop_ctrl):
        ctrl, client = touchstop_ctrl
        client.send_and_recv_subcmd.return_value = "5"
        ctrl.run(32, 50.0, 5.0, 10)
        lines = _first_send_lines(client)
        assert any('TouchStop _ts' in ln for ln in lines)

    def test_subsequent_run_uses_reset(self, touchstop_ctrl):
        ctrl, client = touchstop_ctrl
        client.send_and_recv_subcmd.return_value = "5"
        ctrl.run(32, 50.0, 5.0, 10)
        ctrl.run(16, 30.0, 3.0, 5)
        lines = _first_send_lines(client)
        assert lines[0] == "_ts.Reset()"
        assert not any("TouchStop _ts" in ln for ln in lines)

    def test_returns_result_code(self, touchstop_ctrl):
        ctrl, client = touchstop_ctrl
        client.send_and_recv_subcmd.return_value = "5"
        assert ctrl.run(32, 50.0, 5.0, 10) == 5

    def test_run_ends_with_listen_send(self, touchstop_ctrl):
        ctrl, client = touchstop_ctrl
        client.send_and_recv_subcmd.return_value = "3"
        ctrl.run(32, 50.0, 5.0, 10)
        lines = _first_send_lines(client)
        assert any("ListenSend(90" in ln for ln in lines)

    def test_run_contains_start(self, touchstop_ctrl):
        ctrl, client = touchstop_ctrl
        client.send_and_recv_subcmd.return_value = "3"
        ctrl.run(32, 50.0, 5.0, 10)
        lines = _first_send_lines(client)
        assert any("_ts.Start()" in ln for ln in lines)

    def test_frame_passed(self, touchstop_ctrl):
        ctrl, client = touchstop_ctrl
        client.send_and_recv_subcmd.return_value = "3"
        ctrl.run(32, 50.0, 5.0, 10, frame=2)
        lines = _first_send_lines(client)
        assert any("_ts.Frame(2)" in ln for ln in lines)

    def test_timeout_line_present(self, touchstop_ctrl):
        ctrl, client = touchstop_ctrl
        client.send_and_recv_subcmd.return_value = "2"
        ctrl.run(32, 50.0, 5.0, 10, timeout_ms=3000)
        lines = _first_send_lines(client)
        assert any("_ts.Timeout(3000)" in ln for ln in lines)

    def test_stop_sends_stop_call(self, touchstop_ctrl):
        ctrl, client = touchstop_ctrl
        client.send_and_recv_subcmd.return_value = "0"
        ctrl.stop()
        lines = _first_send_lines(client)
        assert any("_ts.Stop()" in ln for ln in lines)

    def test_get_stopped_pos_parses_pose6(self, touchstop_ctrl):
        ctrl, client = touchstop_ctrl
        client.send_and_recv_subcmd.return_value = "{400.0,-100.0,350.0,180.0,0.0,90.0}"
        pos = ctrl.get_stopped_pos()
        assert len(pos) == 6
        assert abs(pos[0] - 400.0) < 1e-6

    def test_get_triggered_pos(self, touchstop_ctrl):
        ctrl, client = touchstop_ctrl
        client.send_and_recv_subcmd.return_value = "{1.0,2.0,3.0,4.0,5.0,6.0}"
        pos = ctrl.get_triggered_pos()
        assert abs(pos[5] - 6.0) < 1e-6

    def test_get_stopped_pos_script_contains_get_stopped(self, touchstop_ctrl):
        ctrl, client = touchstop_ctrl
        client.send_and_recv_subcmd.return_value = "{0.0,0.0,0.0,0.0,0.0,0.0}"
        ctrl.get_stopped_pos(coord_type=2)
        lines = _first_send_lines(client)
        assert any("GetStoppedPos(2)" in ln for ln in lines)

    def test_reset_session(self, touchstop_ctrl):
        ctrl, client = touchstop_ctrl
        client.send_and_recv_subcmd.return_value = "3"
        ctrl.run(32, 50.0, 5.0, 10)
        assert ctrl._declared
        ctrl._reset_session()
        assert not ctrl._declared


# ════════════════════════════════════════════════════════
#  ComplianceController
# ════════════════════════════════════════════════════════

class TestCompliance:
    def test_first_run_declares_cp(self, compliance_ctrl):
        ctrl, client = compliance_ctrl
        client.send_and_recv_subcmd.return_value = "3"
        ctrl.run(32, 30.0, 3.0, 5)
        lines = _first_send_lines(client)
        assert any("Compliance _cp" in ln for ln in lines)

    def test_subsequent_run_uses_reset(self, compliance_ctrl):
        ctrl, client = compliance_ctrl
        client.send_and_recv_subcmd.return_value = "3"
        ctrl.run(32, 30.0, 3.0, 5)
        ctrl.run(16, 20.0, 2.0, 3)
        lines = _first_send_lines(client)
        assert lines[0] == "_cp.Reset()"

    def test_returns_result_code(self, compliance_ctrl):
        ctrl, client = compliance_ctrl
        client.send_and_recv_subcmd.return_value = "5"
        assert ctrl.run(32, 30.0, 3.0, 5) == 5

    def test_high_resistance_line(self, compliance_ctrl):
        ctrl, client = compliance_ctrl
        client.send_and_recv_subcmd.return_value = "3"
        ctrl.run(32, 30.0, 3.0, 5, high_resistance=True)
        lines = _first_send_lines(client)
        assert any("HighResistance(true)" in ln for ln in lines)

    def test_no_high_resistance_by_default(self, compliance_ctrl):
        ctrl, client = compliance_ctrl
        client.send_and_recv_subcmd.return_value = "3"
        ctrl.run(32, 30.0, 3.0, 5)
        lines = _first_send_lines(client)
        assert not any("HighResistance" in ln for ln in lines)

    def test_contains_cp_start(self, compliance_ctrl):
        ctrl, client = compliance_ctrl
        client.send_and_recv_subcmd.return_value = "3"
        ctrl.run(32, 30.0, 3.0, 5)
        lines = _first_send_lines(client)
        assert any("_cp.Start()" in ln for ln in lines)

    def test_stop(self, compliance_ctrl):
        ctrl, client = compliance_ctrl
        client.send_and_recv_subcmd.return_value = "0"
        ctrl.stop()
        lines = _first_send_lines(client)
        assert any("_cp.Stop()" in ln for ln in lines)


# ════════════════════════════════════════════════════════
#  ForceController
# ════════════════════════════════════════════════════════

class TestForce:
    def test_open_sensor_first_call_declares(self, force_ctrl):
        ctrl, client = force_ctrl
        ctrl.open_sensor("ATI")
        lines = _first_checked_lines(client)
        assert lines[0] == 'FTSensor _fts = "ATI"'
        assert ctrl._declared.get("_fts")

    def test_open_sensor_subsequent_no_redeclare(self, force_ctrl):
        ctrl, client = force_ctrl
        ctrl.open_sensor("ATI")
        ctrl.open_sensor("ATI")
        # 第二次不應呼叫 send_script_checked（lines 為空，不發送）
        assert client.send_script_checked.call_count == 1

    def test_close_sensor_sends_close(self, force_ctrl):
        ctrl, client = force_ctrl
        ctrl.close_sensor()
        lines = _first_checked_lines(client)
        assert 'ftsensor_close("_fts")' in lines[0]

    def test_first_run_declares_fc(self, force_ctrl):
        ctrl, client = force_ctrl
        client.send_and_recv_subcmd.return_value = "11"
        ctrl.run([("Fz", True, 5.0, 2)])
        lines = _first_send_lines(client)
        assert any('Force _fc = "_fts"' in ln for ln in lines)

    def test_subsequent_run_uses_reset(self, force_ctrl):
        ctrl, client = force_ctrl
        client.send_and_recv_subcmd.return_value = "11"
        ctrl.run([("Fz", True, 5.0, 2)])
        ctrl.run([("Fz", True, 3.0, 2)])
        lines = _first_send_lines(client)
        assert lines[0] == "_fc.Reset()"

    def test_returns_result_code(self, force_ctrl):
        ctrl, client = force_ctrl
        client.send_and_recv_subcmd.return_value = "11"
        assert ctrl.run([("Fz", True, 5.0, 2)]) == 11

    def test_fset_line_in_script(self, force_ctrl):
        ctrl, client = force_ctrl
        client.send_and_recv_subcmd.return_value = "11"
        ctrl.run([("Fz", True, 5.0, 2)])
        lines = _first_send_lines(client)
        assert any('_fc.FTSet("Fz", true, 5.0, 2)' in ln for ln in lines)

    def test_multiple_axes(self, force_ctrl):
        ctrl, client = force_ctrl
        client.send_and_recv_subcmd.return_value = "11"
        ctrl.run([("Fz", True, 5.0, 2), ("Mx", True, 0.5, 2)])
        lines = _first_send_lines(client)
        assert any('"Fz"' in ln for ln in lines)
        assert any('"Mx"' in ln for ln in lines)

    def test_start_with_zero_ft(self, force_ctrl):
        ctrl, client = force_ctrl
        client.send_and_recv_subcmd.return_value = "11"
        ctrl.run([("Fz", True, 5.0, 2)], zero_ft=True)
        lines = _first_send_lines(client)
        assert any("_fc.Start(true," in ln for ln in lines)

    def test_start_with_gravity_comp(self, force_ctrl):
        ctrl, client = force_ctrl
        client.send_and_recv_subcmd.return_value = "11"
        ctrl.run([("Fz", True, 5.0, 2)], gravity_compensation=True)
        lines = _first_send_lines(client)
        assert any("_fc.Start(true, true)" in ln for ln in lines)

    def test_reset_session_clears_fts_and_fc(self, force_ctrl):
        ctrl, client = force_ctrl
        ctrl.open_sensor("ATI")
        client.send_and_recv_subcmd.return_value = "11"
        ctrl.run([("Fz", True, 5.0, 2)])
        assert ctrl._declared.get("_fts")
        assert ctrl._declared.get("_fc")
        ctrl._reset_session()
        assert not ctrl._declared
