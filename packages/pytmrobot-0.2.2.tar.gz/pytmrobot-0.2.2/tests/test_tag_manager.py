"""
tests/test_tag_manager.py — TagManager 循環邏輯驗證
"""

import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from pytmrobot.tag_manager import TagManager


class TestTagManager:
    def test_first_call_returns_one(self):
        tm = TagManager()
        assert tm.next() == 1

    def test_sequential(self):
        tm = TagManager()
        results = [tm.next() for _ in range(5)]
        assert results == [1, 2, 3, 4, 5]

    def test_wraps_at_15(self):
        tm = TagManager()
        for _ in range(15):
            tm.next()
        assert tm.current == 15
        assert tm.next() == 1  # 循環回 1

    def test_full_cycle(self):
        tm = TagManager()
        values = [tm.next() for _ in range(30)]
        # 前 15 個是 1-15，後 15 個也是 1-15
        assert values[:15] == list(range(1, 16))
        assert values[15:] == list(range(1, 16))

    def test_current_before_first_call(self):
        tm = TagManager()
        assert tm.current == 0

    def test_reset(self):
        tm = TagManager()
        tm.next()
        tm.next()
        tm.reset()
        assert tm.current == 0
        assert tm.next() == 1

    def test_all_values_in_range(self):
        tm = TagManager()
        for _ in range(100):
            val = tm.next()
            assert 1 <= val <= 15
