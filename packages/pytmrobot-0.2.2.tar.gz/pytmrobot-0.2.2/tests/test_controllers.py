"""
tests/test_controllers.py — DecisionController / ModbusManager / VisionController 單元測試

驗證：
  - session 變數宣告追蹤（首次宣告 vs 後續賦值）
  - _reset_session() 清除狀態
  - 結果解析正確性
  - 邊界條件（choice 數量、逾時值）
"""


import pytest

# ════════════════════════════════════════════════════════
#  DecisionController
# ════════════════════════════════════════════════════════

class TestDecisionAsk:
    def test_first_call_declares_md(self, decision_ctrl):
        ctrl, client = decision_ctrl
        client.send_and_recv_subcmd.return_value = "0"
        ctrl.ask("T", "M", ["A", "B"])
        lines = client.send_and_recv_subcmd.call_args[0][1]
        assert any(ln.startswith('MDecision _md') for ln in lines)

    def test_subsequent_call_uses_reset(self, decision_ctrl):
        ctrl, client = decision_ctrl
        client.send_and_recv_subcmd.return_value = "0"
        ctrl.ask("T", "M", ["A"])
        ctrl.ask("T2", "M2", ["B"])
        lines = client.send_and_recv_subcmd.call_args[0][1]
        assert lines[0] == "_md.Reset()"
        assert not any(ln.startswith("MDecision") for ln in lines)

    def test_returns_int_index(self, decision_ctrl):
        ctrl, client = decision_ctrl
        client.send_and_recv_subcmd.return_value = "1"
        result = ctrl.ask("T", "M", ["A", "B", "C"])
        assert result == 1

    def test_invalid_choices_count_raises(self, decision_ctrl):
        ctrl, _ = decision_ctrl
        from pytmrobot.exceptions import TMValueError
        with pytest.raises(TMValueError):
            ctrl.ask("T", "M", [])        # 0 個
        with pytest.raises(TMValueError):
            ctrl.ask("T", "M", ["A","B","C","D"])  # 4 個

    def test_three_choices_ok(self, decision_ctrl):
        ctrl, client = decision_ctrl
        client.send_and_recv_subcmd.return_value = "2"
        result = ctrl.ask("T", "M", ["A", "B", "C"])
        assert result == 2

    def test_reset_session_clears_declared(self, decision_ctrl):
        ctrl, client = decision_ctrl
        client.send_and_recv_subcmd.return_value = "0"
        ctrl.ask("T", "M", ["A"])
        assert ctrl._declared
        ctrl._reset_session()
        assert not ctrl._declared

    def test_timeout_line_included(self, decision_ctrl):
        ctrl, client = decision_ctrl
        client.send_and_recv_subcmd.return_value = "0"
        ctrl.ask("T", "M", ["A", "B"], timeout_ms=5000)
        lines = client.send_and_recv_subcmd.call_args[0][1]
        assert any("Timeout" in ln for ln in lines)

    def test_no_timeout_line_when_minus_one(self, decision_ctrl):
        ctrl, client = decision_ctrl
        client.send_and_recv_subcmd.return_value = "0"
        ctrl.ask("T", "M", ["A"], timeout_ms=-1)
        lines = client.send_and_recv_subcmd.call_args[0][1]
        assert not any("Timeout" in ln for ln in lines)


class TestDecisionPopup:
    def test_sends_popup_script(self, decision_ctrl):
        ctrl, client = decision_ctrl
        ctrl.popup("Title", "Msg")
        lines = client.send_script_checked.call_args[0][1]
        assert any("Popup" in ln for ln in lines)

    def test_popup_contains_queue_tag(self, decision_ctrl):
        ctrl, client = decision_ctrl
        ctrl.popup("Title", "Msg")
        lines = client.send_script_checked.call_args[0][1]
        assert any("QueueTag" in ln for ln in lines)


# ════════════════════════════════════════════════════════
#  ModbusManager
# ════════════════════════════════════════════════════════

class TestModbusConnect:
    def test_first_connect_declares_mbus(self, modbus_ctrl):
        ctrl, client = modbus_ctrl
        ctrl.connect("192.168.1.10")
        lines = client.send_script_checked.call_args[0][1]
        assert any("ModbusTCP _mbus" in ln for ln in lines)
        assert ctrl._mbus_declared

    def test_subsequent_connect_no_redeclare(self, modbus_ctrl):
        ctrl, client = modbus_ctrl
        ctrl.connect("192.168.1.10")
        ctrl.connect("192.168.1.10")
        lines = client.send_script_checked.call_args[0][1]
        assert not any("ModbusTCP" in ln for ln in lines)
        assert lines[0] == 'modbus_open("_mbus")'

    def test_disconnect_sends_close(self, modbus_ctrl):
        ctrl, client = modbus_ctrl
        ctrl.disconnect()
        lines = client.send_script_checked.call_args[0][1]
        assert lines[0] == 'modbus_close("_mbus")'

    def test_reset_session_clears_state(self, modbus_ctrl):
        ctrl, client = modbus_ctrl
        ctrl.connect("192.168.1.10")
        assert ctrl._mbus_declared
        ctrl._reset_session()
        assert not ctrl._mbus_declared
        assert not ctrl._var_decl


class TestModbusPreset:
    def test_preset_returns_bool(self, modbus_ctrl):
        ctrl, client = modbus_ctrl
        client.send_and_recv_subcmd.return_value = "1"
        result = ctrl.preset("light", 1, "DO", 7206, "bool")
        assert result is True

    def test_preset_false_on_zero(self, modbus_ctrl):
        ctrl, client = modbus_ctrl
        client.send_and_recv_subcmd.return_value = "0"
        result = ctrl.preset("light", 1, "DO", 7206, "bool")
        assert result is False

    def test_preset_tracks_var_declared(self, modbus_ctrl):
        ctrl, client = modbus_ctrl
        client.send_and_recv_subcmd.return_value = "1"
        assert not ctrl._var_decl.get("_mb_pr", False)
        ctrl.preset("light", 1, "DO", 7206, "bool")
        assert ctrl._var_decl.get("_mb_pr", False)


class TestModbusRead:
    def test_read_bool_true(self, modbus_ctrl):
        ctrl, client = modbus_ctrl
        client.send_and_recv_subcmd.return_value = "1"
        assert ctrl.read_bool("light") is True

    def test_read_bool_false(self, modbus_ctrl):
        ctrl, client = modbus_ctrl
        client.send_and_recv_subcmd.return_value = "0"
        assert ctrl.read_bool("light") is False

    def test_read_int(self, modbus_ctrl):
        ctrl, client = modbus_ctrl
        client.send_and_recv_subcmd.return_value = "42"
        assert ctrl.read_int("counter") == 42

    def test_read_float(self, modbus_ctrl):
        ctrl, client = modbus_ctrl
        client.send_and_recv_subcmd.return_value = "3.14"
        assert abs(ctrl.read_float("temp") - 3.14) < 1e-5

    def test_read_string(self, modbus_ctrl):
        ctrl, client = modbus_ctrl
        client.send_and_recv_subcmd.return_value = "ABC123"
        assert ctrl.read_string("label") == "ABC123"


class TestModbusWrite:
    def test_write_bool_true(self, modbus_ctrl):
        ctrl, client = modbus_ctrl
        ctrl.write("light", True)
        lines = client.send_script_checked.call_args[0][1]
        assert "true" in lines[0]

    def test_write_bool_false(self, modbus_ctrl):
        ctrl, client = modbus_ctrl
        ctrl.write("light", False)
        lines = client.send_script_checked.call_args[0][1]
        assert "false" in lines[0]

    def test_write_int(self, modbus_ctrl):
        ctrl, client = modbus_ctrl
        ctrl.write("counter", 99)
        lines = client.send_script_checked.call_args[0][1]
        assert "99" in lines[0]

    def test_write_string_quoted(self, modbus_ctrl):
        ctrl, client = modbus_ctrl
        ctrl.write("label", "hello")
        lines = client.send_script_checked.call_args[0][1]
        assert '"hello"' in lines[0]


# ════════════════════════════════════════════════════════
#  VisionController
# ════════════════════════════════════════════════════════

class TestVisionDoJob:
    def test_success_returns_true(self, vision_ctrl):
        ctrl, client = vision_ctrl
        client.send_and_recv_subcmd.return_value = "1"
        assert ctrl.do_job("Job1") is True

    def test_failure_returns_false(self, vision_ctrl):
        ctrl, client = vision_ctrl
        client.send_and_recv_subcmd.return_value = "0"
        assert ctrl.do_job("Job1") is False

    def test_first_call_declares_vj(self, vision_ctrl):
        ctrl, client = vision_ctrl
        client.send_and_recv_subcmd.return_value = "1"
        ctrl.do_job("Job1")
        lines = client.send_and_recv_subcmd.call_args[0][1]
        assert lines[0].startswith("bool _vj")
        assert ctrl._declared.get("_vj")

    def test_subsequent_call_no_type(self, vision_ctrl):
        ctrl, client = vision_ctrl
        client.send_and_recv_subcmd.return_value = "1"
        ctrl.do_job("Job1")
        ctrl.do_job("Job1")
        lines = client.send_and_recv_subcmd.call_args[0][1]
        assert not lines[0].startswith("bool ")

    def test_reset_session_clears(self, vision_ctrl):
        ctrl, client = vision_ctrl
        client.send_and_recv_subcmd.return_value = "1"
        ctrl.do_job("Job1")
        ctrl._reset_session()
        assert not ctrl._declared


class TestVisionIsAvailable:
    def test_true_on_one(self, vision_ctrl):
        ctrl, client = vision_ctrl
        client.send_and_recv_subcmd.return_value = "1"
        assert ctrl.is_available("Job1") is True

    def test_false_on_zero(self, vision_ctrl):
        ctrl, client = vision_ctrl
        client.send_and_recv_subcmd.return_value = "0"
        assert ctrl.is_available("Job1") is False

    def test_subsequent_no_type(self, vision_ctrl):
        ctrl, client = vision_ctrl
        client.send_and_recv_subcmd.return_value = "1"
        ctrl.is_available("Job1")
        ctrl.is_available("Job1")
        lines = client.send_and_recv_subcmd.call_args[0][1]
        assert not lines[0].startswith("bool ")


class TestVisionGetOutput:
    def test_get_output_raw_string(self, vision_ctrl):
        ctrl, client = vision_ctrl
        client.send_and_recv_subcmd.return_value = "400.0,-100.0,350.0,180.0,0.0,90.0"
        raw = ctrl.get_output("Job1", "ArmPose_0")
        assert raw == "400.0,-100.0,350.0,180.0,0.0,90.0"

    def test_get_output_pose_parses_six(self, vision_ctrl):
        ctrl, client = vision_ctrl
        client.send_and_recv_subcmd.return_value = "400.0,-100.0,350.0,180.0,0.0,90.0"
        pose = ctrl.get_output_pose("Job1", "ArmPose_0")
        assert len(pose) == 6
        assert abs(pose[0] - 400.0) < 1e-6
        assert abs(pose[5] - 90.0)  < 1e-6

    def test_get_output_pose_wrong_count_raises(self, vision_ctrl):
        ctrl, client = vision_ctrl
        client.send_and_recv_subcmd.return_value = "1.0,2.0,3.0"  # 只有 3 個
        with pytest.raises(ValueError, match="6"):
            ctrl.get_output_pose("Job1", "ArmPose_0")

    def test_subsequent_get_output_no_type(self, vision_ctrl):
        ctrl, client = vision_ctrl
        client.send_and_recv_subcmd.return_value = "test"
        ctrl.get_output("Job1", "Var1")
        ctrl.get_output("Job1", "Var2")
        lines = client.send_and_recv_subcmd.call_args[0][1]
        assert not lines[0].startswith("string ")
