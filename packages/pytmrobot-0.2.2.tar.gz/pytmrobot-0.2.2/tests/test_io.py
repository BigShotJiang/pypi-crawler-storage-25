"""
tests/test_io.py — IOController 單元測試

驗證：
  - set_do/ao 送出正確的 TMScript 行
  - get_di/do/ai 呼叫 send_and_recv_subcmd 並解析結果
  - get_all_io 解析多區段 CSV
  - _reset_session 清除宣告狀態
  - instant / module 參數正確傳遞
"""

from unittest.mock import MagicMock

from pytmrobot.io import IOController
from pytmrobot.types import IOState

# ── set_do ────────────────────────────────────────────────────────────────────

class TestSetDo:
    def test_set_high(self, io_ctrl):
        ctrl, client = io_ctrl
        ctrl.set_do(2, True)
        line = client.send_script_checked.call_args[0][1][0]
        assert line == 'IO["ControlBox"].DO[2] = 1'

    def test_set_low(self, io_ctrl):
        ctrl, client = io_ctrl
        ctrl.set_do(3, False)
        line = client.send_script_checked.call_args[0][1][0]
        assert line == 'IO["ControlBox"].DO[3] = 0'

    def test_instant(self, io_ctrl):
        ctrl, client = io_ctrl
        ctrl.set_do(0, True, instant=True)
        line = client.send_script_checked.call_args[0][1][0]
        assert "InstantDO" in line

    def test_end_module(self, io_ctrl):
        ctrl, client = io_ctrl
        ctrl.set_do(1, True, module="EndModule")
        line = client.send_script_checked.call_args[0][1][0]
        assert '"EndModule"' in line


# ── set_ao ────────────────────────────────────────────────────────────────────

class TestSetAo:
    def test_basic(self, io_ctrl):
        ctrl, client = io_ctrl
        ctrl.set_ao(0, 5.0)
        line = client.send_script_checked.call_args[0][1][0]
        assert line == 'IO["ControlBox"].AO[0] = 5.0'

    def test_instant(self, io_ctrl):
        ctrl, client = io_ctrl
        ctrl.set_ao(0, 3.3, instant=True)
        line = client.send_script_checked.call_args[0][1][0]
        assert "InstantAO" in line


# ── get_di ────────────────────────────────────────────────────────────────────

class TestGetDi:
    def test_returns_true_when_one(self, tags):
        client = MagicMock()
        client.send_and_recv_subcmd.return_value = "1"
        ctrl = IOController(client, tags)
        assert ctrl.get_di(2) is True

    def test_returns_false_when_zero(self, tags):
        client = MagicMock()
        client.send_and_recv_subcmd.return_value = "0"
        ctrl = IOController(client, tags)
        assert ctrl.get_di(2) is False

    def test_correct_script_line(self, tags):
        client = MagicMock()
        client.send_and_recv_subcmd.return_value = "0"
        ctrl = IOController(client, tags)
        ctrl.get_di(5)
        lines = client.send_and_recv_subcmd.call_args[0][1]
        assert 'IO["ControlBox"].DI[5]' in lines[0]

    def test_end_module(self, tags):
        client = MagicMock()
        client.send_and_recv_subcmd.return_value = "1"
        ctrl = IOController(client, tags)
        ctrl.get_di(0, module="EndModule")
        lines = client.send_and_recv_subcmd.call_args[0][1]
        assert '"EndModule"' in lines[0]


# ── get_do ────────────────────────────────────────────────────────────────────

class TestGetDo:
    def test_returns_bool(self, tags):
        client = MagicMock()
        client.send_and_recv_subcmd.return_value = "1"
        ctrl = IOController(client, tags)
        assert ctrl.get_do(3) is True

    def test_script_uses_do(self, tags):
        client = MagicMock()
        client.send_and_recv_subcmd.return_value = "0"
        ctrl = IOController(client, tags)
        ctrl.get_do(3)
        lines = client.send_and_recv_subcmd.call_args[0][1]
        assert ".DO[3]" in lines[0]


# ── get_ai ────────────────────────────────────────────────────────────────────

class TestGetAi:
    def test_returns_float(self, tags):
        client = MagicMock()
        client.send_and_recv_subcmd.return_value = "2.45"
        ctrl = IOController(client, tags)
        result = ctrl.get_ai(0)
        assert isinstance(result, float)
        assert abs(result - 2.45) < 1e-6

    def test_script_uses_ai(self, tags):
        client = MagicMock()
        client.send_and_recv_subcmd.return_value = "0.0"
        ctrl = IOController(client, tags)
        ctrl.get_ai(1)
        lines = client.send_and_recv_subcmd.call_args[0][1]
        assert ".AI[1]" in lines[0]


# ── get_all_io ────────────────────────────────────────────────────────────────

class TestGetAllIo:
    def _make_csv(self):
        # 格式：DI:{0,1,0,...}|DO:{1,0,...}|AI:{2.0,0.0,...}|AO:{5.0,0.0,...}
        return "DI:{0,1,0,0}|DO:{1,0,1,0}|AI:{2.45,0.0}|AO:{5.0,0.0}"

    def test_parses_all_sections(self, tags):
        client = MagicMock()
        client.send_and_recv_subcmd.return_value = self._make_csv()
        ctrl = IOController(client, tags)
        state = ctrl.get_all_io()
        assert isinstance(state, IOState)
        assert state.di == [0, 1, 0, 0]
        assert state.do == [1, 0, 1, 0]
        assert abs(state.ai[0] - 2.45) < 1e-6
        assert abs(state.ao[0] - 5.0)  < 1e-6

    def test_first_call_declares_vars(self, tags):
        client = MagicMock()
        client.send_and_recv_subcmd.return_value = self._make_csv()
        ctrl = IOController(client, tags)
        assert not ctrl._io_vars_declared
        ctrl.get_all_io()
        assert ctrl._io_vars_declared

    def test_subsequent_call_uses_assignment(self, tags):
        client = MagicMock()
        client.send_and_recv_subcmd.return_value = self._make_csv()
        ctrl = IOController(client, tags)
        ctrl.get_all_io()   # 首次 → 宣告
        ctrl.get_all_io()   # 第二次 → 賦值
        # 第二次呼叫的 script lines 不應有型別宣告
        lines = client.send_and_recv_subcmd.call_args[0][1]
        assert not any(line.startswith("byte[]") or line.startswith("float[]")
                       for line in lines)


# ── _reset_session ────────────────────────────────────────────────────────────

class TestResetSession:
    def test_clears_declared_state(self, tags):
        client = MagicMock()
        client.send_and_recv_subcmd.return_value = (
            "DI:{0}|DO:{0}|AI:{0.0}|AO:{0.0}"
        )
        ctrl = IOController(client, tags)
        ctrl.get_all_io()
        assert ctrl._io_vars_declared
        ctrl._reset_session()
        assert not ctrl._io_vars_declared
