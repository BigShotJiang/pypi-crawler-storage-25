"""
tests/test_types.py — 型別定義驗證測試
"""

import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from pytmrobot.types import BlendUnit, CartPoint, IOState, JointPoint, SpeedUnit


class TestCartPoint:
    def test_creation(self):
        p = CartPoint(400, -100, 350, 180, 0, 90)
        assert p.x == 400
        assert p.rz == 90

    def test_as_pose6(self):
        p = CartPoint(1, 2, 3, 4, 5, 6)
        assert p.as_pose6() == (1, 2, 3, 4, 5, 6)

    def test_repr(self):
        p = CartPoint(400, -100, 350, 180, 0, 90)
        assert "CartPoint" in repr(p)


class TestJointPoint:
    def test_creation(self):
        p = JointPoint(0, -6.5, 96.1, 0.4, 90, 0)
        assert p.j2 == -6.5

    def test_as_pose6(self):
        p = JointPoint(1, 2, 3, 4, 5, 6)
        assert p.as_pose6() == (1, 2, 3, 4, 5, 6)


class TestSpeedUnit:
    def test_values(self):
        assert SpeedUnit.PERCENT.value  == "P"
        assert SpeedUnit.ABS_SYNC.value == "A"
        assert SpeedUnit.ABS_LOCK.value == "D"


class TestBlendUnit:
    def test_values(self):
        assert BlendUnit.PERCENT.value == "P"
        assert BlendUnit.RADIUS.value  == "R"


class TestIOState:
    def test_defaults(self):
        s = IOState()
        assert s.di == []
        assert s.ao == []

    def test_with_values(self):
        s = IOState(di=[1, 0, 1], do=[0, 0], ai=[3.3, 5.0], ao=[0.0])
        assert s.di[0] == 1
        assert s.ai[1] == 5.0
