"""
tests/test_camera.py — EIHCamera 單元測試

所有測試使用 MagicMock 取代 gRPC stub，不需要真實相機連線。
驗證：
  - 資料型別轉換正確性
  - 各 API 方法呼叫正確的 stub 方法
  - 參數驗證（set_image_size 合法值）
  - connect / disconnect / context manager
  - 未連線時呼叫拋出 RuntimeError
  - gRPC 錯誤轉換為 RuntimeError
"""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest

from pytmrobot.camera import (
    CameraIntrinsics,
    CaptureRange,
    CapturingSettings,
    EIHCamera,
    ImageConfig,
    WhiteBalance,
)

# ── fixtures ──────────────────────────────────────────────────────────────────

def _make_capture_range_pb(current=100, min_val=0, max_val=1000):
    pb = MagicMock()
    pb.CurrentValue = current
    pb.MinValue = min_val
    pb.MaxValue = max_val
    return pb


def _make_white_balance_pb(r=512, g=512, b=512):
    pb = MagicMock()
    pb.red_ratio   = _make_capture_range_pb(r)
    pb.green_ratio = _make_capture_range_pb(g)
    pb.blue_ratio  = _make_capture_range_pb(b)
    return pb


def _make_camera_matrix_pb():
    pb = MagicMock()
    for attr in ("matrix_00","matrix_01","matrix_02",
                 "matrix_10","matrix_11","matrix_12",
                 "matrix_20","matrix_21","matrix_22"):
        setattr(pb, attr, 1.0)
    return pb


def _make_distortion_pb():
    pb = MagicMock()
    for attr in ("coefficient_00","coefficient_10","coefficient_20",
                 "coefficient_30","coefficient_40"):
        setattr(pb, attr, 0.1)
    return pb


def _make_intrinsics_pb():
    pb = MagicMock()
    pb.FocusValue   = 500.0
    pb.ImageWidth   = 1280
    pb.ImageHeight  = 960
    pb.CameraMatrix = _make_camera_matrix_pb()
    pb.DistortionCoefficients = _make_distortion_pb()
    return pb


@pytest.fixture
def cam_and_stub():
    """建立 EIHCamera 並注入 mock stub。"""
    cam = EIHCamera("192.168.1.101")
    cam._channel = MagicMock()
    stub = MagicMock()
    cam._stub = stub
    return cam, stub


# ── 連線管理 ──────────────────────────────────────────────────────────────────

class TestConnection:
    def test_connect_creates_stub(self):
        cam = EIHCamera("192.168.1.101")
        with patch("pytmrobot.camera._get_grpc") as mock_grpc, \
             patch("pytmrobot.camera._get_stubs") as mock_stubs:
            mock_channel = MagicMock()
            mock_grpc.return_value.insecure_channel.return_value = mock_channel
            mock_stub_cls = MagicMock()
            mock_stubs.return_value = (MagicMock(), mock_stub_cls, MagicMock())
            cam.connect()
        assert cam._stub is not None
        assert cam._channel is not None

    def test_disconnect_clears_stub(self, cam_and_stub):
        cam, _ = cam_and_stub
        cam.disconnect()
        assert cam._stub is None
        assert cam._channel is None

    def test_context_manager(self):
        cam = EIHCamera("192.168.1.101")
        with patch.object(cam, "connect") as mock_connect, \
             patch.object(cam, "disconnect") as mock_disconnect:
            with cam:
                mock_connect.assert_called_once()
            mock_disconnect.assert_called_once()

    def test_not_connected_raises(self):
        cam = EIHCamera("192.168.1.101")
        with pytest.raises(RuntimeError, match="尚未連線"):
            cam.get_image()

    def test_repr_disconnected(self):
        cam = EIHCamera("192.168.1.101")
        assert "disconnected" in repr(cam)

    def test_repr_connected(self, cam_and_stub):
        cam, _ = cam_and_stub
        assert "connected" in repr(cam)


# ── is_connected ──────────────────────────────────────────────────────────────

class TestIsConnected:
    def test_returns_true_and_message(self, cam_and_stub):
        cam, stub = cam_and_stub
        resp = MagicMock()
        resp.isCameraConnected = True
        resp.connection_message = "Camera connected successfully."
        stub.isCameraConnected.return_value = resp
        with patch("pytmrobot.camera._get_stubs") as ms:
            ms.return_value = (MagicMock(), MagicMock(), MagicMock())
            ok, msg = cam.is_connected()
        assert ok is True
        assert "successfully" in msg

    def test_returns_false_on_disconnect(self, cam_and_stub):
        cam, stub = cam_and_stub
        resp = MagicMock()
        resp.isCameraConnected = False
        resp.connection_message = "TM_EIH_Camera is not connected."
        stub.isCameraConnected.return_value = resp
        with patch("pytmrobot.camera._get_stubs") as ms:
            ms.return_value = (MagicMock(), MagicMock(), MagicMock())
            ok, _ = cam.is_connected()
        assert ok is False


# ── 影像擷取 ──────────────────────────────────────────────────────────────────

class TestImageCapture:
    def test_get_image_returns_bytes(self, cam_and_stub):
        cam, stub = cam_and_stub
        fake_png = b"\x89PNG\r\n\x1a\n"
        resp = MagicMock()
        resp.EncodeString = fake_png
        stub.getImageData.return_value = resp
        with patch("pytmrobot.camera._get_stubs") as ms:
            ms.return_value = (MagicMock(), MagicMock(), MagicMock())
            result = cam.get_image()
        assert isinstance(result, bytes)
        assert result == fake_png

    def test_get_image_config(self, cam_and_stub):
        cam, stub = cam_and_stub
        resp = MagicMock()
        resp.ImageType   = "png"
        resp.ImageSize   = "1M:1280*960"
        resp.ImageWidth  = 1280
        resp.ImageHeight = 960
        resp.PixelFormat = "RGB"
        stub.getImageConfiguration.return_value = resp
        with patch("pytmrobot.camera._get_stubs") as ms:
            ms.return_value = (MagicMock(), MagicMock(), MagicMock())
            cfg = cam.get_image_config()
        assert isinstance(cfg, ImageConfig)
        assert cfg.pixel_format == "RGB"
        assert cfg.image_width == 1280


# ── 相機資訊 ──────────────────────────────────────────────────────────────────

class TestCameraInfo:
    def test_get_intrinsics_list(self, cam_and_stub):
        cam, stub = cam_and_stub
        resp = MagicMock()
        resp.cam_intrinsics = [_make_intrinsics_pb(), _make_intrinsics_pb()]
        stub.getIntrinsics.return_value = resp
        with patch("pytmrobot.camera._get_stubs") as ms:
            ms.return_value = (MagicMock(), MagicMock(), MagicMock())
            result = cam.get_intrinsics()
        assert len(result) == 2
        assert isinstance(result[0], CameraIntrinsics)
        assert result[0].focus_value == 500.0
        assert result[0].image_width == 1280

    def test_get_hand_eye_tuple(self, cam_and_stub):
        cam, stub = cam_and_stub
        ha = MagicMock()
        ha.handeye_x = 10.0
        ha.handeye_y = 20.0
        ha.handeye_z = 30.0
        ha.handeye_rx = 0.0
        ha.handeye_ry = 0.0
        ha.handeye_rz = 90.0
        resp = MagicMock()
        resp.HandEyeArray = ha
        stub.getHandEyeParameters.return_value = resp
        with patch("pytmrobot.camera._get_stubs") as ms:
            ms.return_value = (MagicMock(), MagicMock(), MagicMock())
            result = cam.get_hand_eye()
        assert len(result) == 6
        assert result[0] == 10.0
        assert result[5] == 90.0


# ── 拍攝設定 ──────────────────────────────────────────────────────────────────

class TestCapturingSettings:
    def test_get_capturing_settings(self, cam_and_stub):
        cam, stub = cam_and_stub
        resp = MagicMock()
        resp.ShutterTime  = _make_capture_range_pb(5000, 100, 100000)
        resp.Gain         = _make_capture_range_pb(100, 0, 480)
        resp.WhiteBalance = _make_white_balance_pb()
        resp.Focus        = _make_capture_range_pb(500, 0, 1023)
        resp.ImageSize    = "1M:1280*960"
        stub.getCapturingSettings.return_value = resp
        with patch("pytmrobot.camera._get_stubs") as ms:
            ms.return_value = (MagicMock(), MagicMock(), MagicMock())
            settings = cam.get_capturing_settings()
        assert isinstance(settings, CapturingSettings)
        assert settings.shutter_time.current == 5000
        assert settings.image_size == "1M:1280*960"

    def test_get_shutter_time(self, cam_and_stub):
        cam, stub = cam_and_stub
        resp = MagicMock()
        resp.shuttertime = _make_capture_range_pb(5000, 100, 100000)
        stub.getShutterTime.return_value = resp
        with patch("pytmrobot.camera._get_stubs") as ms:
            ms.return_value = (MagicMock(), MagicMock(), MagicMock())
            cr = cam.get_shutter_time()
        assert isinstance(cr, CaptureRange)
        assert cr.current == 5000
        assert cr.max_val == 100000

    def test_get_white_balance(self, cam_and_stub):
        cam, stub = cam_and_stub
        resp = MagicMock()
        resp.whitebalance = _make_white_balance_pb(r=600, g=512, b=450)
        stub.getWhiteBalance.return_value = resp
        with patch("pytmrobot.camera._get_stubs") as ms:
            ms.return_value = (MagicMock(), MagicMock(), MagicMock())
            wb = cam.get_white_balance()
        assert isinstance(wb, WhiteBalance)
        assert wb.red.current == 600

    def test_set_image_size_valid(self, cam_and_stub):
        cam, stub = cam_and_stub
        stub.setImageSize.return_value = MagicMock()
        with patch("pytmrobot.camera._get_stubs") as ms:
            mock_pb2 = MagicMock()
            ms.return_value = (mock_pb2, MagicMock(), MagicMock())
            cam.set_image_size("1M")
        stub.setImageSize.assert_called_once()

    def test_set_image_size_invalid_raises(self, cam_and_stub):
        cam, _ = cam_and_stub
        with pytest.raises(ValueError, match="'1M' 或 '5M'"):
            cam.set_image_size("2M")

    def test_set_focus_calls_stub(self, cam_and_stub):
        cam, stub = cam_and_stub
        stub.setFocus.return_value = MagicMock()
        with patch("pytmrobot.camera._get_stubs") as ms:
            mock_pb2 = MagicMock()
            ms.return_value = (mock_pb2, MagicMock(), MagicMock())
            cam.set_focus(800)
        stub.setFocus.assert_called_once()


# ── gRPC 錯誤處理 ─────────────────────────────────────────────────────────────

class TestGrpcError:
    def test_grpc_error_raises_runtime_error(self, cam_and_stub):
        cam, stub = cam_and_stub
        import grpc
        err = grpc.RpcError()
        err.code    = lambda: grpc.StatusCode.UNAVAILABLE
        err.details = lambda: "connection refused"
        stub.isCameraConnected.side_effect = err
        with patch("pytmrobot.camera._get_stubs") as ms:
            ms.return_value = (MagicMock(), MagicMock(), MagicMock())
            with patch("pytmrobot.camera._get_grpc") as mg:
                mg.return_value = grpc
                with pytest.raises(RuntimeError, match="gRPC"):
                    cam.is_connected()
