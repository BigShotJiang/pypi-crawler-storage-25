"""
tests/test_motion.py — MotionController 單元測試

驗證：
  - 各運動方法組裝出正確的 TMScript 行並送出
  - wait=False 時記錄 last_tag，wait_motion() 呼叫 wait_queue_tag
  - 參數驗證（speed/blend 超出範圍）
  - PVT 流程方法順序正確
"""


import pytest

from pytmrobot.exceptions import TMValueError
from pytmrobot.types import BlendUnit, CartPoint, JointPoint, SpeedUnit

# ── PTP ───────────────────────────────────────────────────────────────────────

class TestPtp:
    def test_cart_sends_cpp(self, motion_ctrl):
        ctrl, client = motion_ctrl
        ctrl.ptp(CartPoint(400, -100, 350, 180, 0, 90), speed=30)
        lines = client.send_script_checked.call_args[0][1]
        assert lines[0].startswith('PTP("CPP",')
        assert "{400.0,-100.0,350.0,180.0,0.0,90.0}" in lines[0]
        assert ",30," in lines[0]
        assert lines[1] == "QueueTag(1,1)"

    def test_joint_sends_jpp(self, motion_ctrl):
        ctrl, client = motion_ctrl
        ctrl.ptp(JointPoint(0, -6.5, 96.1, 0.4, 90, 0), speed=20)
        lines = client.send_script_checked.call_args[0][1]
        assert 'PTP("JPP",' in lines[0]

    def test_speed_out_of_range_raises(self, motion_ctrl):
        ctrl, _ = motion_ctrl
        with pytest.raises(TMValueError):
            ctrl.ptp(CartPoint(0, 0, 0, 0, 0, 0), speed=0)
        with pytest.raises(TMValueError):
            ctrl.ptp(CartPoint(0, 0, 0, 0, 0, 0), speed=101)

    def test_blend_out_of_range_raises(self, motion_ctrl):
        ctrl, _ = motion_ctrl
        with pytest.raises(TMValueError):
            ctrl.ptp(CartPoint(0, 0, 0, 0, 0, 0), speed=10, blend=-1)
        with pytest.raises(TMValueError):
            ctrl.ptp(CartPoint(0, 0, 0, 0, 0, 0), speed=10, blend=101)

    def test_wait_false_no_queue_wait(self, motion_ctrl):
        ctrl, client = motion_ctrl
        ctrl.ptp(CartPoint(400, 0, 350, 180, 0, 90), speed=10, wait=False)
        lines = client.send_script_checked.call_args[0][1]
        # wait=False → QueueTag 無第二參數
        assert lines[1] == "QueueTag(1)"

    def test_wait_false_records_last_tag(self, motion_ctrl):
        ctrl, client = motion_ctrl
        assert ctrl._last_tag == 0
        ctrl.ptp(CartPoint(0, 0, 0, 0, 0, 0), speed=10, wait=False)
        assert ctrl._last_tag == 1

    def test_wait_motion_calls_wait_queue_tag(self, motion_ctrl):
        ctrl, client = motion_ctrl
        ctrl.ptp(CartPoint(0, 0, 0, 0, 0, 0), speed=10, wait=False)
        ctrl.wait_motion()
        client.wait_queue_tag.assert_called_once_with(1)

    def test_wait_motion_no_op_when_no_last_tag(self, motion_ctrl):
        ctrl, client = motion_ctrl
        ctrl.wait_motion()   # _last_tag == 0 → 不呼叫
        client.wait_queue_tag.assert_not_called()

    def test_script_id_increments(self, motion_ctrl):
        ctrl, client = motion_ctrl
        ctrl.ptp(CartPoint(0, 0, 0, 0, 0, 0), speed=10)
        ctrl.ptp(CartPoint(0, 0, 0, 0, 0, 0), speed=10)
        ids = [c[0][0] for c in client.send_script_checked.call_args_list]
        assert ids[0] != ids[1]   # 每次 tag 不同


# ── Line ──────────────────────────────────────────────────────────────────────

class TestLine:
    def test_default_cdp(self, motion_ctrl):
        ctrl, client = motion_ctrl
        ctrl.line(CartPoint(450, -100, 350, 180, 0, 90), speed=100)
        lines = client.send_script_checked.call_args[0][1]
        assert 'Line("CDP",' in lines[0]
        assert "{450.0,-100.0,350.0,180.0,0.0,90.0}" in lines[0]

    def test_percent_speed_unit(self, motion_ctrl):
        ctrl, client = motion_ctrl
        ctrl.line(CartPoint(450, 0, 350, 180, 0, 90),
                  speed=50, speed_unit=SpeedUnit.PERCENT)
        lines = client.send_script_checked.call_args[0][1]
        assert 'Line("CPP",' in lines[0]

    def test_radius_blend_unit(self, motion_ctrl):
        ctrl, client = motion_ctrl
        ctrl.line(CartPoint(450, 0, 350, 180, 0, 90),
                  speed=100, blend_unit=BlendUnit.RADIUS)
        lines = client.send_script_checked.call_args[0][1]
        assert 'Line("CDR",' in lines[0]

    def test_queue_tag_wait(self, motion_ctrl):
        ctrl, client = motion_ctrl
        ctrl.line(CartPoint(450, 0, 350, 180, 0, 90), speed=100, wait=True)
        lines = client.send_script_checked.call_args[0][1]
        assert lines[-1].startswith("QueueTag(") and lines[-1].endswith(",1)")


# ── Circle ────────────────────────────────────────────────────────────────────

class TestCircle:
    def test_basic(self, motion_ctrl):
        ctrl, client = motion_ctrl
        ctrl.circle(
            via=CartPoint(420, -50, 350, 180, 0, 90),
            end=CartPoint(400,   0, 350, 180, 0, 90),
        )
        lines = client.send_script_checked.call_args[0][1]
        assert lines[0].startswith('Circle("CDP"')
        assert "{420.0,-50.0,350.0,180.0,0.0,90.0}" in lines[0]
        assert "{400.0,0.0,350.0,180.0,0.0,90.0}" in lines[0]

    def test_angle_param(self, motion_ctrl):
        ctrl, client = motion_ctrl
        ctrl.circle(
            via=CartPoint(420, -50, 350, 180, 0, 90),
            end=CartPoint(400,   0, 350, 180, 0, 90),
            angle=270,
        )
        lines = client.send_script_checked.call_args[0][1]
        assert ",270," in lines[0]


# ── 相對運動 ──────────────────────────────────────────────────────────────────

class TestRelativeMotion:
    def test_ptp_relative_cart(self, motion_ctrl):
        ctrl, client = motion_ctrl
        ctrl.ptp_relative(CartPoint(0, 0, 50, 0, 0, 0), speed=20)
        lines = client.send_script_checked.call_args[0][1]
        assert 'Move_PTP("CPP",' in lines[0]
        assert "{0.0,0.0,50.0,0.0,0.0,0.0}" in lines[0]

    def test_ptp_relative_joint(self, motion_ctrl):
        ctrl, client = motion_ctrl
        ctrl.ptp_relative(JointPoint(0, 0, 0, 0, 0, 45), speed=10)
        lines = client.send_script_checked.call_args[0][1]
        assert 'Move_PTP("JPP",' in lines[0]

    def test_line_relative(self, motion_ctrl):
        ctrl, client = motion_ctrl
        ctrl.line_relative(CartPoint(30, 0, 0, 0, 0, 0), speed=50)
        lines = client.send_script_checked.call_args[0][1]
        assert 'Move_Line("CDP",' in lines[0]


# ── PVT ───────────────────────────────────────────────────────────────────────

class TestPvt:
    def test_enter_cart(self, motion_ctrl):
        ctrl, client = motion_ctrl
        ctrl.pvt_enter("cart")
        line = client.send_script_checked.call_args[0][1][0]
        assert line == "PVTEnter(1)"

    def test_enter_joint(self, motion_ctrl):
        ctrl, client = motion_ctrl
        ctrl.pvt_enter("joint")
        line = client.send_script_checked.call_args[0][1][0]
        assert line == "PVTEnter(2)"

    def test_enter_invalid_raises(self, motion_ctrl):
        ctrl, _ = motion_ctrl
        with pytest.raises(TMValueError):
            ctrl.pvt_enter("invalid")

    def test_pvt_point_cpp(self, motion_ctrl):
        ctrl, client = motion_ctrl
        ctrl.pvt_point(
            CartPoint(400, 0, 350, 180, 0, 90),
            CartPoint(10, 0, 0, 0, 0, 0),
            1000,
        )
        line = client.send_script_checked.call_args[0][1][0]
        assert line.startswith('PVTPoint("CPP",')
        assert line.endswith(",1000)")

    def test_pvt_point_jpp(self, motion_ctrl):
        ctrl, client = motion_ctrl
        ctrl.pvt_point(
            JointPoint(0, 0, 0, 0, 0, 0),
            JointPoint(1, 0, 0, 0, 0, 0),
            500,
        )
        line = client.send_script_checked.call_args[0][1][0]
        assert 'PVTPoint("JPP",' in line

    def test_pvt_point_type_mismatch_raises(self, motion_ctrl):
        ctrl, _ = motion_ctrl
        with pytest.raises(TypeError):
            ctrl.pvt_point(
                CartPoint(0, 0, 0, 0, 0, 0),
                JointPoint(0, 0, 0, 0, 0, 0),
                1000,
            )

    def test_pvt_exit_wait(self, motion_ctrl):
        ctrl, client = motion_ctrl
        ctrl.pvt_enter("cart")
        ctrl.pvt_exit(wait=True)
        lines = client.send_script_checked.call_args[0][1]
        assert lines[0] == "PVTExit()"
        assert lines[1].endswith(",1)")

    def test_pvt_pause_resume(self, motion_ctrl):
        ctrl, client = motion_ctrl
        ctrl.pvt_pause()
        assert client.send_script_checked.call_args[0][1][0] == "PVTPause()"
        ctrl.pvt_resume()
        assert client.send_script_checked.call_args[0][1][0] == "PVTResume()"
