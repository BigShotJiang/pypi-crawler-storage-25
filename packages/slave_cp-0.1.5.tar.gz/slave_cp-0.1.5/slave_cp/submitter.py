import time
from pathlib import Path
from curl_cffi import requests as cf_requests
from bs4 import BeautifulSoup
from rich.console import Console
from slave_cp import config

console = Console()

# ─── CODEFORCES LANGUAGE MAP ─────────────────────────────────────────────────

CF_LANG_MAP = {
    ".cpp":   "54",
    ".c":     "43",
    ".py":    "70",
    ".java":  "60",
    ".kt":    "88",
    ".go":    "32",
    ".rs":    "75",
    ".cs":    "65",
    ".rb":    "67",
    ".js":    "55",
    ".hs":    "12",
    ".scala": "20",
    ".d":     "28",
    ".pas":   "4",
    ".pl":    "13",
    ".php":   "6",
    ".swift": "83",
    ".lua":   "19",
    ".r":     "99",
    ".dart":  "91",
    ".fs":    "100",
    ".ts":    "55",
}


# ─── MAIN ENTRY POINT ────────────────────────────────────────────────────────

def submit(problem: str, contest_id: str, platform: str, workspace: Path):
    if platform == "codeforces":
        submit_codeforces(problem, contest_id, workspace)
    else:
        console.print("[red]Only Codeforces submission is supported.[/]")


# ─── HELPERS ─────────────────────────────────────────────────────────────────

def _js_set(driver, element_id: str, value: str):
    """Set an input value via JS native setter — bypasses React/CF input listeners."""
    driver.execute_script("""
        var el = document.getElementById(arguments[0]);
        var setter = Object.getOwnPropertyDescriptor(
            window.HTMLInputElement.prototype, 'value'
        ).set;
        setter.call(el, arguments[1]);
        el.dispatchEvent(new Event('input',  {bubbles: true}));
        el.dispatchEvent(new Event('change', {bubbles: true}));
    """, element_id, value)


# ─── CODEFORCES ──────────────────────────────────────────────────────────────

def submit_codeforces(problem: str, contest_id: str, workspace: Path):
    creds    = config.get_credentials("codeforces")
    handle   = creds.get("handle")
    password = creds.get("password")

    if not handle or not password:
        console.print("[bold red]✘ Codeforces credentials not set.[/]")
        console.print("[dim]Run 'slave-cp init' to set your credentials.[/]")
        return

    numeric_id     = contest_id.upper().replace("CF", "").strip()
    contest_folder = workspace / contest_id.upper()

    solution_file, ext = find_solution_file(contest_folder, problem)
    if solution_file is None:
        console.print(f"[bold red]✘ No solution file found for problem {problem.upper()}[/]")
        return

    lang_id = CF_LANG_MAP.get(ext)
    if not lang_id:
        console.print(f"[bold red]✘ Language '{ext}' not supported for Codeforces submission.[/]")
        return

    source_code = solution_file.read_text(encoding="utf-8")

    try:
        import undetected_chromedriver as uc
        from selenium.webdriver.common.by import By
        from selenium.webdriver.support.ui import WebDriverWait, Select
        from selenium.webdriver.support import expected_conditions as EC
    except ImportError:
        console.print("[bold red]✘ Run: pip install undetected-chromedriver selenium[/]")
        return

    options = uc.ChromeOptions()
    options.add_argument("--no-sandbox")
    options.add_argument("--disable-dev-shm-usage")
    # No --headless: Cloudflare blocks headless

    console.print("[dim]Launching browser...[/]")
    driver = uc.Chrome(options=options)
    wait   = WebDriverWait(driver, 40)

    try:
        # ── Step 1: Login ──────────────────────────────────────────────────
        console.print("[dim]Opening Codeforces login...[/]")
        driver.get("https://codeforces.com/enter")

        wait.until(EC.presence_of_element_located((By.ID, "handleOrEmail")))
        time.sleep(1.5)

        _js_set(driver, "handleOrEmail", handle)
        time.sleep(0.3)
        _js_set(driver, "password", password)
        time.sleep(0.3)

        remember = driver.find_element(By.ID, "remember")
        if not remember.is_selected():
            remember.click()

        time.sleep(0.5)
        driver.find_element(By.ID, "enterForm").submit()
        wait.until(lambda d: "/enter" not in d.current_url)

        if "Invalid" in driver.page_source or "/enter" in driver.current_url:
            console.print("[bold red]✘ Login failed — check your credentials.[/]")
            return

        console.print("[bold green]✔ Logged in.[/]")

        # ── Step 2: Open submit page ───────────────────────────────────────
        submit_url = f"https://codeforces.com/contest/{numeric_id}/submit"
        driver.get(submit_url)

        wait.until(EC.presence_of_element_located(
            (By.CSS_SELECTOR, "select[name='submittedProblemIndex']")
        ))
        time.sleep(1)

        # Select problem
        problem_select = Select(driver.find_element(
            By.CSS_SELECTOR, "select[name='submittedProblemIndex']"
        ))
        problem_select.select_by_value(problem.upper())
        time.sleep(1.5)

        # Select language
        time.sleep(1.0)
        lang_select = Select(driver.find_element(
            By.CSS_SELECTOR, "select[name='programTypeId']"
        ))
        lang_select.select_by_value(lang_id)
        time.sleep(1.0)

        # Switch off CodeMirror — gives a plain textarea instead
        try:
            switch_off = driver.find_element(
                By.XPATH,
                "//input[@type='checkbox' and following-sibling::label[contains(text(),'Switch off editor')]]"
            )
        except Exception:
            switch_off = driver.find_element(
                By.XPATH,
                "//label[contains(text(),'Switch off editor')]/preceding-sibling::input[@type='checkbox']"
            )

        if not switch_off.is_selected():
            switch_off.click()
        time.sleep(0.8)

        # Paste into plain textarea
        textarea = wait.until(EC.presence_of_element_located(
            (By.CSS_SELECTOR, "textarea[name='source']")
        ))
        driver.execute_script("arguments[0].value = arguments[1];", textarea, source_code)
        driver.execute_script(
            "arguments[0].dispatchEvent(new Event('input', {bubbles:true}));", textarea
        )
        time.sleep(0.5)

        # Verify paste worked
        pasted = driver.execute_script("return arguments[0].value;", textarea)
        if not pasted.strip():
            console.print("[bold red]✘ Code paste failed.[/]")
            return

        console.print(f"[dim]Submitting {problem.upper()} ({ext})...[/]")

        # ── Step 3: Submit ─────────────────────────────────────────────────
        driver.find_element(
            By.CSS_SELECTOR, ".submit-form input[type='submit']"
        ).click()

        wait.until(lambda d: "/submit" not in d.current_url)

        console.print("[bold green]✔ Submitted![/]")
        console.print(f"[dim]https://codeforces.com/contest/{numeric_id}/my[/]")

        # ── Step 4: Poll verdict ───────────────────────────────────────────
        poll_codeforces_verdict(numeric_id, problem, handle)

    finally:
        driver.quit()


# ─── VERDICT POLLING ─────────────────────────────────────────────────────────

def poll_codeforces_verdict(contest_id: str, problem: str, handle: str):
    console.print("\n[dim]Waiting for verdict...[/dim]")

    api_url  = f"https://codeforces.com/api/user.status?handle={handle}&count=5"
    deadline = time.time() + 120

    while time.time() < deadline:
        time.sleep(3)
        print(".", end="", flush=True)

        try:
            resp = cf_requests.get(api_url, timeout=10, impersonate="chrome110")
            data = resp.json()
        except Exception:
            continue

        if data.get("status") != "OK":
            continue

        for sub in data["result"]:
            if str(sub.get("contestId")) != str(contest_id):
                continue
            if sub.get("problem", {}).get("index", "").upper() != problem.upper():
                continue
            verdict = sub.get("verdict", "")
            if not verdict or verdict == "TESTING":
                break
            print()
            _print_verdict(verdict)
            return

    print()
    console.print("[yellow]⚠ Timed out waiting for verdict.[/]")
    console.print(f"[dim]https://codeforces.com/contest/{contest_id}/my[/]")


def _print_verdict(verdict: str):
    v = verdict.upper()
    if v == "OK":
        console.print("\n  [bold green]✔ ACCEPTED 🎉[/bold green]\n")
    elif "WRONG" in v:
        console.print("\n  [bold red]✘ WRONG ANSWER[/bold red]\n")
    elif "TIME" in v:
        console.print("\n  [bold yellow]⏱ TIME LIMIT EXCEEDED[/bold yellow]\n")
    elif "MEMORY" in v:
        console.print("\n  [bold yellow]📦 MEMORY LIMIT EXCEEDED[/bold yellow]\n")
    elif "COMPILATION" in v:
        console.print("\n  [bold red]🔨 COMPILATION ERROR[/bold red]\n")
    elif "RUNTIME" in v or "CRASHED" in v:
        console.print("\n  [bold red]💥 RUNTIME ERROR[/bold red]\n")
    else:
        console.print(f"\n  [bold yellow]{verdict}[/bold yellow]\n")


# ─── HELPERS ─────────────────────────────────────────────────────────────────

def extract_csrf(html: str) -> str | None:
    soup = BeautifulSoup(html, "html.parser")
    meta = soup.find("meta", {"name": "X-Csrf-Token"})
    if meta:
        return meta.get("content")
    inp = soup.find("input", {"name": "csrf_token"})
    if inp:
        return inp.get("value")
    return None


def find_solution_file(contest_folder: Path, problem: str):
    from slave_cp.runner import LANGUAGES

    found = []
    for ext in LANGUAGES:
        candidate = contest_folder / f"{problem.upper()}{ext}"
        if candidate.exists():
            found.append((candidate, ext))

    if not found:
        return None, None
    if len(found) == 1:
        return found[0]

    console.print(f"\n[bold yellow]Multiple solution files found:[/]")
    for i, (f, e) in enumerate(found):
        console.print(f"  [{i + 1}] {f.name}")

    while True:
        choice = input("\nWhich file to submit? (enter number): ").strip()
        if choice.isdigit() and 1 <= int(choice) <= len(found):
            return found[int(choice) - 1]
        console.print("[red]Invalid choice. Try again.[/]")