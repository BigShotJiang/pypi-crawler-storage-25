Changelog
=========

0.3.3 (2026-05-17)
------------------
- Added support for GraalPy 3.12
- Added support for Python 3.15
- Dropped support for Python 3.10 (due to compatibility issues).
- Fix for nox 'lint' session.
- Setup update and improvement.

0.2.0 (2026-01-25)
------------------
- First (preliminary) release.

0.0.0 (2025-11-10)
------------------
- Initial commit.
