"""_____________________________________________________________________

:PROJECT: LARAsuite

*lara_django_processes high_level_interface *

:details: lara_django_processes high_level_interface.
         - generated with 'lara-django-dev generate_high_level_interface lara_django_processes
:authors: mark doerr <mark.doerr@uni-greifswald.de>

.. note:: -
.. todo:: -
________________________________________________________________________
"""

import json
import asyncio
import logging
import grpc
from typing import Union

from google.protobuf.struct_pb2 import Struct
from google.protobuf.json_format import MessageToDict

import lara_django_base_grpc.v1.lara_django_base_pb2 as lara_django_base_pb2
import lara_django_base_grpc.v1.lara_django_base_pb2_grpc as lara_django_base_pb2_grpc

import lara_django_processes_grpc.v1.lara_django_processes_pb2 as lara_django_processes_pb2
import lara_django_processes_grpc.v1.lara_django_processes_pb2_grpc as lara_django_processes_pb2_grpc

import  lara_django_base_grpc.lara_django_base_data_model as base_dm
import  lara_django_base_grpc.lara_django_base_interface as base_if
from  lara_django_base_grpc.abstract_interface import LARAInterface, GRPCChannelSingleton, import_model_instance_from_file, export_model_instance_to_file, upload_file, download_file, update_file, upload_image, update_image, download_image, id_cache

import  lara_django_processes_grpc.lara_django_processes_data_model as processes_dm

logger = logging.getLogger(__name__)



#_________________  ExtraData  ______________________


class ExtraDataInterface:
    def __init__(self, channel: grpc.Channel = None, 
                       default_namespace_uri : str = None,
                       default_namespace_id : str = None,
                       namespace_if = None ) -> None:
        self._default_namespace_uri = default_namespace_uri
        self._default_namespace_id = default_namespace_id

        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.namespace_if = namespace_if if namespace_if is not None else base_if.NamespaceInterface(channel)

        # self.extradata_class_client = (
        #     lara_django_processes_pb2_grpc.ExtraDataclassByIRIControllerStub(channel)
        # )

        self.extradata_client = lara_django_processes_pb2_grpc.ExtraDataControllerStub(channel)
        
        self.item_id = None
        self.update_item_id = "extradata_id"
        self.stub = self.extradata_client

        self.file_download_info = lara_django_processes_pb2.FileDownloadInfo
        self.file_upload_chunk = lara_django_processes_pb2.FileUploadChunk

        self.image_upload_chunk = lara_django_processes_pb2.ImageUploadChunk


        # self.extradata_full_client = lara_django_processes_pb2_grpc.ExtraDataFullControllerStub(
        #     channel
        # )

    @property
    def default_namespace_uri(self):
        return self._default_namespace_uri

    @property
    def default_namespace_id(self):
        return self._default_namespace_id

    @classmethod
    async def build_if(cls, channel: grpc.Channel = None, default_namespace_uri: str = None):
    
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel
    
        namespace_if = base_if.NamespaceInterface(channel)
        try:
            default_namespace_id = await namespace_if.retrieve_id(namespace_uri=default_namespace_uri)
        except Exception as e:
            logger.error(f"Error retrieving namespace_id: {e}")
        
        return cls(channel=channel, default_namespace_uri=default_namespace_uri,  
                   default_namespace_id=default_namespace_id, namespace_if=namespace_if)
    
    async def set_default_namespace_uri(self, namespace_uri: str = None):
        if namespace_uri is not None:
            self._default_namespace_uri = namespace_uri.strip()
        try:
            self._default_namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logger.error(f"Error retrieving namespace_id: {e}")
    
    @import_model_instance_from_file()
    @upload_file  # needed for file upload
    @upload_image  # needed for image upload
    async def create(self,  extradata:  list[processes_dm.ExtraData] = None,  
                            ids_only: bool = False,
                            namespace_uri: str = None) -> Union[list[str], list[processes_dm.ExtraData]]:
        """ create a list of extradata instances,
               returns a list of extradata data model objects or ids_only

        :param extradata: list of extradata data model objects
        :param ids_only: return only the ids of the created instances
        :return: list of extradata data model objects or ids_only
        """
        extradataclass_id = None

        namespace_id = None
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
            namespace_id = self._default_namespace_id
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        if namespace_id is None:
            try:
                namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
            except Exception as e:
                logger.error(f"Error retrieving namespace_id: {e}")

        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if extradata_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.extradata_class_client.Retrieve(
        #         lara_django_processes_pb2.ExtraDataclassRetrieveRequest(iri=extradata_class_iri)
        #     )
        #     extradataclass_id = res.extradataclass_id
        # except Exception as e:
        #     logger.error(f"Error retrieving extradataclass_id: {e}")
        for extradatum in extradata:
            if extradatum.namespace == "" or extradatum.namespace == "default":
                    extradatum.namespace = namespace_id
            # extradata.extradata_class = extradataclass_id # uncomment if a model class is used
            if extradatum.data_json is not None:
                try:
                    data_struct = Struct()
                    data_json = extradatum.data_json
                    data_struct.update(data_json)
                    extradatum.data_json = data_struct
                except Exception as e:
                    logging.error(f"Error(DataInterface) - converting data_json to Struct: {e}")

        try:
            create_coroutines = ( self.extradata_client.Create(lara_django_processes_pb2.ExtraDataRequest(**extradatum.model_dump())) for extradatum in extradata )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [ MessageToDict(item, preserving_proto_field_name=True).get("extradata_id") for item in res ]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating extradata: {e}")
        
    @export_model_instance_to_file
    async def retrieve(
        self,
        namespace_uri: str = None,
        extradata_id: str = None,
        name: str = None,
        # name_display: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[processes_dm.ExtraData]:
        """ retrieve a list of extradata instances by extradata_id, name or filter_dict,
               returns a list of extradata data model objects,
               if raw is True, the raw protobuf objects are returned.
               If namespace_uri is "default", the default namespace_uri is used.
        """
        if namespace_uri == "default":
            if self._default_namespace_uri is not None:
                namespace_uri = self._default_namespace_uri
            else:
                raise ValueError("No default namespace URI is given.")
        
        results_list = []
        if  extradata_id is not None:
            try:
                res =  await self.extradata_client.Retrieve(
                    lara_django_processes_pb2.ExtraDataRetrieveRequest(extradata_id=extradata_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( processes_dm.ExtraData(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving extradata_id: {e}")

        if filter_dict is None:
            filter_dict = {}

        if name is not None:
            filter_dict["name"] = name
        if namespace_uri is not None:
            filter_dict["namespace__uri"] = namespace_uri
        # if name_display is not None:
        #    filter_dict["name_display"] = name_display

        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.extradata_client.List(
                    lara_django_processes_pb2.ExtraDataListRequest(), metadata=metadata
                    )
            if raw:
                    results_list += res.results
            else:
                # :TODO: a queue could be used here to speed up the retrieval
                results = res.results
                results_list += [ processes_dm.ExtraData(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
        except Exception as e:
            logger.error(f"Error retrieving extradata name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          name: str = None,
                          # name_display: str = None,
                          namespace_uri : str = None,
                          filter_dict : dict = None,
                          iri: str = None,) -> str:
        """ retrieve the extradata_id for a given name,
               name_display or iri
        """

        results_list = await self.retrieve(name=name, 
                        namespace_uri=namespace_uri, filter_dict=filter_dict, raw=True)

        if len(results_list) == 1 :
            return results_list[0].extradata_id
        else:
            raise ValueError(f"Error retrieving extradata_id - no or too many results found.")
    
    @download_file  # needed for file download
    @download_image  # needed for image download
    async def get_by_id(self, extradata_id: str = None, id_only: bool = False) -> processes_dm.ExtraData:
        """ retrieve a extradata data model by extradata_id """
        try:
            res = await self.extradata_client.Retrieve(
                lara_django_processes_pb2.ExtraDataRetrieveRequest(extradata_id=extradata_id)
            )
            item = processes_dm.ExtraData(**MessageToDict(res, preserving_proto_field_name=True))
            self.item_id = item.extradata_id
            return item
        except Exception as e:
            logger.error(f"Error retrieving extradata_id: {e}")
    
    @download_file  # needed for file download
    @download_image  # needed for image download
    async def get_by_name(self, name: str = None,
                                namespace_uri : str = None,
                                id_only: bool = False) -> processes_dm.ExtraData | str:
        """ retrieve a extradata data model by name """
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            res = await self.extradata_client.RetrieveByNameNamespace(
                lara_django_processes_pb2.ExtraDataRetrieveByNameNSRequest(name=name, namespace_uri=namespace_uri)
            )
            item = MessageToDict(res, preserving_proto_field_name=True)
            self.item_id = item["extradata_id"]
            if id_only:
                return self.item_id
            else:
                return processes_dm.ExtraData(**item)
        except Exception as e:
            logger.error(f"Error retrieving extradata name: {e}")
   
    
    @download_file  # needed for file download
    async def get_file(self, extradata_id : str = None, id_only : bool = True ) -> bytes | None:
        """ retrieve a file by data_id """
        self.item_id = extradata_id
        
    
    async def get_file_by_name(self, name: str = None,
                                namespace_uri : str = None,
                                filename_target : str = None,
                                as_byte_str : bool = None ) -> bytes | None:
        """ retrieve a file by name """
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
            # logger.warning(f"no namespace_uri provided, using default namespace: {namespace_uri}")
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            extradata_id = await self.get_by_name(name=name, namespace_uri=namespace_uri, id_only=True)
            return await self.get_file(extradata_id=extradata_id, filename_target=filename_target, as_byte_str=as_byte_str, get_file=True)
        except Exception as e:
            logger.error(f"Error retrieving extradata name: {e}")
        
    
    @download_image  # needed for image download
    async def get_image(self, extradata_id : str = None, id_only : bool = True) -> bytes | None:
        """ retrieve an image by data_id """
        self.item_id = extradata_id
        
    
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all extradatas """
        if filter_dict is None:
            res = await self.extradata_client.List(lara_django_processes_pb2.ExtraDataListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.extradata_client.List(
                lara_django_processes_pb2.ExtraDataListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.extradata_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all extradatas """
        if self.extradata_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.extradata_full_client.List(
                lara_django_processes_pb2.ExtraDataFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.extradata_full_client.List(
                lara_django_processes_pb2.ExtraDataFullListRequest(), metadata=metadata
            )
    
    @import_model_instance_from_file()
    @update_file  # needed for file update
    @update_image  # needed for image update
    async def update(self, extradata : processes_dm.ExtraData = None) -> None:
        """ update a extradata model instance """
        try:
            res = await self.extradata_client.Update(
                lara_django_processes_pb2.ExtraDataRequest(**extradata.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating extradata_id: {e}")
        else:
            return res
    
    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a extradata by extradata_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.extradata_client.Destroy(lara_django_processes_pb2.ExtraDataDestroyRequest(extradata_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting extradata_id: {e}")

#_________________  MethodClass  ______________________


class MethodClassInterface:
    def __init__(self, channel: grpc.Channel = None) -> None:
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.methodclass_client = lara_django_processes_pb2_grpc.MethodClassControllerStub(channel)
        
    
    @import_model_instance_from_file()
    async def create(self,  methodclasses:  list[processes_dm.MethodClass] = None,  ids_only: bool = False) -> Union[list[str], list[processes_dm.MethodClass]]:
        try:
            create_coroutines = ( self.methodclass_client.Create(lara_django_processes_pb2.MethodClassRequest(**methodclass.model_dump())) for methodclass in methodclasses )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.methodclass_id for item in res]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating methodclass: {e}")
        
    @export_model_instance_to_file
    async def retrieve(
        self,
        methodclass_id: str = None,
        name: str = None,
        # name_display: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[processes_dm.MethodClass]:
        """ retrieve a list of methodclass instances by methodclass_id, name or filter_dict,
               returns a list of methodclass data model objects,
               if raw is True, the raw protobuf objects are returned
        """
        results_list = []
        if  methodclass_id is not None:
            try:
                res =  await self.methodclass_client.Retrieve(
                    lara_django_processes_pb2.MethodClassRetrieveRequest(methodclass_id=methodclass_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( processes_dm.MethodClass(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving methodclass_id: {e}")

        if filter_dict is None:
            filter_dict = {}

        if name is not None:
            filter_dict["name"] = name
        # if name_display is not None:
        #    filter_dict["name_display"] = name_display

        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.methodclass_client.List(
                    lara_django_processes_pb2.MethodClassListRequest(), metadata=metadata
                    )
            if raw:
                    results_list += res.results
            else:
                # a queue could be used here to speed up the retrieval
                results = res.results
                results_list += [ processes_dm.MethodClass(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
        except Exception as e:
            logger.error(f"Error retrieving methodclass name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          name: str = None,
                          # name_display: str = None,
                          filter_dict : dict = None,
                          iri: str = None,) -> str:
        """ retrieve the methodclass_id for a given name,
               (name_display) or iri
        """
        
        results_list = await self.retrieve(name=name, filter_dict=filter_dict, raw=True)
        if len(results_list) == 1 :
            return results_list[0].methodclass_id
        else:
            raise ValueError(f"Error retrieving methodclass_id - no or too many results found.")
    
    async def get_by_id(self, methodclass_id: str = None) -> processes_dm.MethodClass:
        """ retrieve a methodclass data model by methodclass_id """
        try:
            res = await self.methodclass_client.Retrieve(
                lara_django_processes_pb2.MethodClassRetrieveRequest(methodclass_id=methodclass_id)
            )
            return processes_dm.MethodClass(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving methodclass_id: {e}")
    
    async def get_by_name(self, name: str = None, id_only: bool = False) -> processes_dm.MethodClass | str:
        """ retrieve a methodclass data model by name """
        try:
            res = await self.methodclass_client.RetrieveByNameNamespace(
                lara_django_processes_pb2.MethodClassRetrieveByNameNSRequest(name=name, namespace_uri="")
            )
            if id_only:
                return MessageToDict(res, preserving_proto_field_name=True)["methodclass_id"]
            else:
                return processes_dm.MethodClass(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving methodclass name: {e}")
    
    
    
    
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all methodclasss """
        if filter_dict is None:
            res = await self.methodclass_client.List(lara_django_processes_pb2.MethodClassListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.methodclass_client.List(
                lara_django_processes_pb2.MethodClassListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.methodclass_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all methodclasss """
        if self.methodclass_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.methodclass_full_client.List(
                lara_django_processes_pb2.MethodClassFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.methodclass_full_client.List(
                lara_django_processes_pb2.MethodClassFullListRequest(), metadata=metadata
            )
    
    @import_model_instance_from_file()
    async def update(self, methodclass : processes_dm.MethodClass = None) -> None:
        """ update a methodclass model instance """
        try:
            res = await self.methodclass_client.Update(
                lara_django_processes_pb2.MethodClassRequest(**methodclass.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating methodclass_id: {e}")
        else:
            return res
    
    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a methodclass by methodclass_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.methodclass_client.Destroy(lara_django_processes_pb2.MethodClassDestroyRequest(methodclass_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting methodclass_id: {e}")

#_________________  Method  ______________________


class MethodInterface:
    def __init__(self, channel: grpc.Channel = None, 
                       default_namespace_uri : str = None,
                       default_namespace_id : str = None,
                       namespace_if = None ) -> None:
        self._default_namespace_uri = default_namespace_uri
        self._default_namespace_id = default_namespace_id

        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.namespace_if = namespace_if if namespace_if is not None else base_if.NamespaceInterface(channel)

        # self.method_class_client = (
        #     lara_django_processes_pb2_grpc.MethodclassByIRIControllerStub(channel)
        # )

        self.method_client = lara_django_processes_pb2_grpc.MethodControllerStub(channel)
        

        # self.method_full_client = lara_django_processes_pb2_grpc.MethodFullControllerStub(
        #     channel
        # )

    @property
    def default_namespace_uri(self):
        return self._default_namespace_uri

    @property
    def default_namespace_id(self):
        return self._default_namespace_id

    @classmethod
    async def build_if(cls, channel: grpc.Channel = None, default_namespace_uri: str = None):
    
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel
    
        namespace_if = base_if.NamespaceInterface(channel)
        try:
            default_namespace_id = await namespace_if.retrieve_id(namespace_uri=default_namespace_uri)
        except Exception as e:
            logger.error(f"Error retrieving namespace_id: {e}")
        
        return cls(channel=channel, default_namespace_uri=default_namespace_uri,  
                   default_namespace_id=default_namespace_id, namespace_if=namespace_if)
    
    async def set_default_namespace_uri(self, namespace_uri: str = None):
        if namespace_uri is not None:
            self._default_namespace_uri = namespace_uri.strip()
        try:
            self._default_namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logger.error(f"Error retrieving namespace_id: {e}")
    
    @import_model_instance_from_file()
    async def create(self,  methods:  list[processes_dm.Method] = None,  
                            ids_only: bool = False,
                            namespace_uri: str = None) -> Union[list[str], list[processes_dm.Method]]:
        """ create a list of method instances,
               returns a list of method data model objects or ids_only

        :param methods: list of method data model objects
        :param ids_only: return only the ids of the created instances
        :return: list of method data model objects or ids_only
        """
        methodclass_id = None

        namespace_id = None
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
            namespace_id = self._default_namespace_id
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        if namespace_id is None:
            try:
                namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
            except Exception as e:
                logger.error(f"Error retrieving namespace_id: {e}")

        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if method_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.method_class_client.Retrieve(
        #         lara_django_processes_pb2.MethodclassRetrieveRequest(iri=method_class_iri)
        #     )
        #     methodclass_id = res.methodclass_id
        # except Exception as e:
        #     logger.error(f"Error retrieving methodclass_id: {e}")
        for method in methods:
            if method.namespace == "" or method.namespace == "default":
                    method.namespace = namespace_id
            # method.method_class = methodclass_id # uncomment if a model class is used
            if method.method_json is not None:
                try:
                    data_struct = Struct()
                    data_json = method.method_json
                    data_struct.update(data_json)
                    method.method_json = data_struct
                except Exception as e:
                    logging.error(f"Error(DataInterface) - converting method_json to Struct: {e}")

        try:
            create_coroutines = ( self.method_client.Create(lara_django_processes_pb2.MethodRequest(**method.model_dump())) for method in methods )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [ MessageToDict(item, preserving_proto_field_name=True).get("method_id") for item in res ]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating method: {e}")
        
    @export_model_instance_to_file
    async def retrieve(
        self,
        namespace_uri: str = None,
        method_id: str = None,
        name: str = None,
        # name_display: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[processes_dm.Method]:
        """ retrieve a list of method instances by method_id, name or filter_dict,
               returns a list of method data model objects,
               if raw is True, the raw protobuf objects are returned.
               If namespace_uri is "default", the default namespace_uri is used.
        """
        if namespace_uri == "default":
            if self._default_namespace_uri is not None:
                namespace_uri = self._default_namespace_uri
            else:
                raise ValueError("No default namespace URI is given.")
        
        results_list = []
        if  method_id is not None:
            try:
                res =  await self.method_client.Retrieve(
                    lara_django_processes_pb2.MethodRetrieveRequest(method_id=method_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( processes_dm.Method(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving method_id: {e}")

        if filter_dict is None:
            filter_dict = {}

        if name is not None:
            filter_dict["name"] = name
        if namespace_uri is not None:
            filter_dict["namespace__uri"] = namespace_uri
        # if name_display is not None:
        #    filter_dict["name_display"] = name_display

        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.method_client.List(
                    lara_django_processes_pb2.MethodListRequest(), metadata=metadata
                    )
            if raw:
                    results_list += res.results
            else:
                # :TODO: a queue could be used here to speed up the retrieval
                results = res.results
                results_list += [ processes_dm.Method(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
        except Exception as e:
            logger.error(f"Error retrieving method name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          name: str = None,
                          # name_display: str = None,
                          namespace_uri : str = None,
                          filter_dict : dict = None,
                          iri: str = None,) -> str:
        """ retrieve the method_id for a given name,
               name_display or iri
        """

        results_list = await self.retrieve(name=name, 
                        namespace_uri=namespace_uri, filter_dict=filter_dict, raw=True)

        if len(results_list) == 1 :
            return results_list[0].method_id
        else:
            raise ValueError(f"Error retrieving method_id - no or too many results found.")
    
    async def get_by_id(self, method_id: str = None, id_only: bool = False) -> processes_dm.Method:
        """ retrieve a method data model by method_id """
        try:
            res = await self.method_client.Retrieve(
                lara_django_processes_pb2.MethodRetrieveRequest(method_id=method_id)
            )
            item = processes_dm.Method(**MessageToDict(res, preserving_proto_field_name=True))
            self.item_id = item.method_id
            return item
        except Exception as e:
            logger.error(f"Error retrieving method_id: {e}")
    
    async def get_by_name(self, name: str = None,
                                namespace_uri : str = None,
                                id_only: bool = False) -> processes_dm.Method | str:
        """ retrieve a method data model by name """
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            res = await self.method_client.RetrieveByNameNamespace(
                lara_django_processes_pb2.MethodRetrieveByNameNSRequest(name=name, namespace_uri=namespace_uri)
            )
            item = MessageToDict(res, preserving_proto_field_name=True)
            self.item_id = item["method_id"]
            if id_only:
                return self.item_id
            else:
                return processes_dm.Method(**item)
        except Exception as e:
            logger.error(f"Error retrieving method name: {e}")
   
    
    
    
    
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all methods """
        if filter_dict is None:
            res = await self.method_client.List(lara_django_processes_pb2.MethodListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.method_client.List(
                lara_django_processes_pb2.MethodListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.method_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all methods """
        if self.method_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.method_full_client.List(
                lara_django_processes_pb2.MethodFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.method_full_client.List(
                lara_django_processes_pb2.MethodFullListRequest(), metadata=metadata
            )
    
    @import_model_instance_from_file()
    async def update(self, method : processes_dm.Method = None) -> None:
        """ update a method model instance """
        try:
            res = await self.method_client.Update(
                lara_django_processes_pb2.MethodRequest(**method.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating method_id: {e}")
        else:
            return res
    
    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a method by method_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.method_client.Destroy(lara_django_processes_pb2.MethodDestroyRequest(method_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting method_id: {e}")

#_________________  MethodsSubset  ______________________


class MethodsSubsetInterface:
    def __init__(self, channel: grpc.Channel = None, 
                       default_namespace_uri : str = None,
                       default_namespace_id : str = None,
                       namespace_if = None ) -> None:
        self._default_namespace_uri = default_namespace_uri
        self._default_namespace_id = default_namespace_id

        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.namespace_if = namespace_if if namespace_if is not None else base_if.NamespaceInterface(channel)

        # self.methodssubset_class_client = (
        #     lara_django_processes_pb2_grpc.MethodsSubsetclassByIRIControllerStub(channel)
        # )

        self.methodssubset_client = lara_django_processes_pb2_grpc.MethodsSubsetControllerStub(channel)
        

        # self.methodssubset_full_client = lara_django_processes_pb2_grpc.MethodsSubsetFullControllerStub(
        #     channel
        # )

    @property
    def default_namespace_uri(self):
        return self._default_namespace_uri

    @property
    def default_namespace_id(self):
        return self._default_namespace_id

    @classmethod
    async def build_if(cls, channel: grpc.Channel = None, default_namespace_uri: str = None):
    
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel
    
        namespace_if = base_if.NamespaceInterface(channel)
        try:
            default_namespace_id = await namespace_if.retrieve_id(namespace_uri=default_namespace_uri)
        except Exception as e:
            logger.error(f"Error retrieving namespace_id: {e}")
        
        return cls(channel=channel, default_namespace_uri=default_namespace_uri,  
                   default_namespace_id=default_namespace_id, namespace_if=namespace_if)
    
    async def set_default_namespace_uri(self, namespace_uri: str = None):
        if namespace_uri is not None:
            self._default_namespace_uri = namespace_uri.strip()
        try:
            self._default_namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logger.error(f"Error retrieving namespace_id: {e}")
    
    @import_model_instance_from_file()
    async def create(self,  methodssubsets:  list[processes_dm.MethodsSubset] = None,  
                            ids_only: bool = False,
                            namespace_uri: str = None) -> Union[list[str], list[processes_dm.MethodsSubset]]:
        """ create a list of methodssubset instances,
               returns a list of methodssubset data model objects or ids_only

        :param methodssubsets: list of methodssubset data model objects
        :param ids_only: return only the ids of the created instances
        :return: list of methodssubset data model objects or ids_only
        """
        methodssubsetclass_id = None

        namespace_id = None
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
            namespace_id = self._default_namespace_id
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        if namespace_id is None:
            try:
                namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
            except Exception as e:
                logger.error(f"Error retrieving namespace_id: {e}")

        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if methodssubset_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.methodssubset_class_client.Retrieve(
        #         lara_django_processes_pb2.MethodsSubsetclassRetrieveRequest(iri=methodssubset_class_iri)
        #     )
        #     methodssubsetclass_id = res.methodssubsetclass_id
        # except Exception as e:
        #     logger.error(f"Error retrieving methodssubsetclass_id: {e}")
        for methodssubset in methodssubsets:
            if methodssubset.namespace == "" or methodssubset.namespace == "default":
                    methodssubset.namespace = namespace_id
            # methodssubset.methodssubset_class = methodssubsetclass_id # uncomment if a model class is used

        try:
            create_coroutines = ( self.methodssubset_client.Create(lara_django_processes_pb2.MethodsSubsetRequest(**methodssubset.model_dump())) for methodssubset in methodssubsets )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [ MessageToDict(item, preserving_proto_field_name=True).get("methodssubset_id") for item in res ]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating methodssubset: {e}")
        
    @export_model_instance_to_file
    async def retrieve(
        self,
        namespace_uri: str = None,
        methodssubset_id: str = None,
        name: str = None,
        # name_display: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[processes_dm.MethodsSubset]:
        """ retrieve a list of methodssubset instances by methodssubset_id, name or filter_dict,
               returns a list of methodssubset data model objects,
               if raw is True, the raw protobuf objects are returned.
               If namespace_uri is "default", the default namespace_uri is used.
        """
        if namespace_uri == "default":
            if self._default_namespace_uri is not None:
                namespace_uri = self._default_namespace_uri
            else:
                raise ValueError("No default namespace URI is given.")
        
        results_list = []
        if  methodssubset_id is not None:
            try:
                res =  await self.methodssubset_client.Retrieve(
                    lara_django_processes_pb2.MethodsSubsetRetrieveRequest(methodssubset_id=methodssubset_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( processes_dm.MethodsSubset(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving methodssubset_id: {e}")

        if filter_dict is None:
            filter_dict = {}

        if name is not None:
            filter_dict["name"] = name
        if namespace_uri is not None:
            filter_dict["namespace__uri"] = namespace_uri
        # if name_display is not None:
        #    filter_dict["name_display"] = name_display

        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.methodssubset_client.List(
                    lara_django_processes_pb2.MethodsSubsetListRequest(), metadata=metadata
                    )
            if raw:
                    results_list += res.results
            else:
                # :TODO: a queue could be used here to speed up the retrieval
                results = res.results
                results_list += [ processes_dm.MethodsSubset(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
        except Exception as e:
            logger.error(f"Error retrieving methodssubset name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          name: str = None,
                          # name_display: str = None,
                          namespace_uri : str = None,
                          filter_dict : dict = None,
                          iri: str = None,) -> str:
        """ retrieve the methodssubset_id for a given name,
               name_display or iri
        """

        results_list = await self.retrieve(name=name, 
                        namespace_uri=namespace_uri, filter_dict=filter_dict, raw=True)

        if len(results_list) == 1 :
            return results_list[0].methodssubset_id
        else:
            raise ValueError(f"Error retrieving methodssubset_id - no or too many results found.")
    
    async def get_by_id(self, methodssubset_id: str = None, id_only: bool = False) -> processes_dm.MethodsSubset:
        """ retrieve a methodssubset data model by methodssubset_id """
        try:
            res = await self.methodssubset_client.Retrieve(
                lara_django_processes_pb2.MethodsSubsetRetrieveRequest(methodssubset_id=methodssubset_id)
            )
            item = processes_dm.MethodsSubset(**MessageToDict(res, preserving_proto_field_name=True))
            self.item_id = item.methodssubset_id
            return item
        except Exception as e:
            logger.error(f"Error retrieving methodssubset_id: {e}")
    
    async def get_by_name(self, name: str = None,
                                namespace_uri : str = None,
                                id_only: bool = False) -> processes_dm.MethodsSubset | str:
        """ retrieve a methodssubset data model by name """
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            res = await self.methodssubset_client.RetrieveByNameNamespace(
                lara_django_processes_pb2.MethodsSubsetRetrieveByNameNSRequest(name=name, namespace_uri=namespace_uri)
            )
            item = MessageToDict(res, preserving_proto_field_name=True)
            self.item_id = item["methodssubset_id"]
            if id_only:
                return self.item_id
            else:
                return processes_dm.MethodsSubset(**item)
        except Exception as e:
            logger.error(f"Error retrieving methodssubset name: {e}")
   
    
    
    
    
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all methodssubsets """
        if filter_dict is None:
            res = await self.methodssubset_client.List(lara_django_processes_pb2.MethodsSubsetListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.methodssubset_client.List(
                lara_django_processes_pb2.MethodsSubsetListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.methodssubset_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all methodssubsets """
        if self.methodssubset_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.methodssubset_full_client.List(
                lara_django_processes_pb2.MethodsSubsetFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.methodssubset_full_client.List(
                lara_django_processes_pb2.MethodsSubsetFullListRequest(), metadata=metadata
            )
    
    @import_model_instance_from_file()
    async def update(self, methodssubset : processes_dm.MethodsSubset = None) -> None:
        """ update a methodssubset model instance """
        try:
            res = await self.methodssubset_client.Update(
                lara_django_processes_pb2.MethodsSubsetRequest(**methodssubset.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating methodssubset_id: {e}")
        else:
            return res
    
    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a methodssubset by methodssubset_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.methodssubset_client.Destroy(lara_django_processes_pb2.MethodsSubsetDestroyRequest(methodssubset_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting methodssubset_id: {e}")

#_________________  OrderedMethodsSubset  ______________________


class OrderedMethodsSubsetInterface:
    def __init__(self, channel: grpc.Channel = None) -> None:
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.orderedmethodssubset_client = lara_django_processes_pb2_grpc.OrderedMethodsSubsetControllerStub(channel)
        
    
    @import_model_instance_from_file()
    async def create(self,  orderedmethodssubsets:  list[processes_dm.OrderedMethodsSubset] = None,  ids_only: bool = False) -> Union[list[str], list[processes_dm.OrderedMethodsSubset]]:
        try:
            create_coroutines = ( self.orderedmethodssubset_client.Create(lara_django_processes_pb2.OrderedMethodsSubsetRequest(**orderedmethodssubset.model_dump())) for orderedmethodssubset in orderedmethodssubsets )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.orderedmethodssubset_id for item in res]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating orderedmethodssubset: {e}")
        
    @export_model_instance_to_file
    async def retrieve(
        self,
        orderedmethodssubset_id: str = None,
        name: str = None,
        # name_display: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[processes_dm.OrderedMethodsSubset]:
        """ retrieve a list of orderedmethodssubset instances by orderedmethodssubset_id, name or filter_dict,
               returns a list of orderedmethodssubset data model objects,
               if raw is True, the raw protobuf objects are returned
        """
        results_list = []
        if  orderedmethodssubset_id is not None:
            try:
                res =  await self.orderedmethodssubset_client.Retrieve(
                    lara_django_processes_pb2.OrderedMethodsSubsetRetrieveRequest(orderedmethodssubset_id=orderedmethodssubset_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( processes_dm.OrderedMethodsSubset(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving orderedmethodssubset_id: {e}")

        if filter_dict is None:
            filter_dict = {}

        if name is not None:
            filter_dict["name"] = name
        # if name_display is not None:
        #    filter_dict["name_display"] = name_display

        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.orderedmethodssubset_client.List(
                    lara_django_processes_pb2.OrderedMethodsSubsetListRequest(), metadata=metadata
                    )
            if raw:
                    results_list += res.results
            else:
                # a queue could be used here to speed up the retrieval
                results = res.results
                results_list += [ processes_dm.OrderedMethodsSubset(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
        except Exception as e:
            logger.error(f"Error retrieving orderedmethodssubset name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          name: str = None,
                          # name_display: str = None,
                          filter_dict : dict = None,
                          iri: str = None,) -> str:
        """ retrieve the orderedmethodssubset_id for a given name,
               (name_display) or iri
        """
        
        results_list = await self.retrieve(name=name, filter_dict=filter_dict, raw=True)
        if len(results_list) == 1 :
            return results_list[0].orderedmethodssubset_id
        else:
            raise ValueError(f"Error retrieving orderedmethodssubset_id - no or too many results found.")
    
    async def get_by_id(self, orderedmethodssubset_id: str = None) -> processes_dm.OrderedMethodsSubset:
        """ retrieve a orderedmethodssubset data model by orderedmethodssubset_id """
        try:
            res = await self.orderedmethodssubset_client.Retrieve(
                lara_django_processes_pb2.OrderedMethodsSubsetRetrieveRequest(orderedmethodssubset_id=orderedmethodssubset_id)
            )
            return processes_dm.OrderedMethodsSubset(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving orderedmethodssubset_id: {e}")
    
    async def get_by_name(self, name: str = None, id_only: bool = False) -> processes_dm.OrderedMethodsSubset | str:
        """ retrieve a orderedmethodssubset data model by name """
        try:
            res = await self.orderedmethodssubset_client.RetrieveByNameNamespace(
                lara_django_processes_pb2.OrderedMethodsSubsetRetrieveByNameNSRequest(name=name, namespace_uri="")
            )
            if id_only:
                return MessageToDict(res, preserving_proto_field_name=True)["orderedmethodssubset_id"]
            else:
                return processes_dm.OrderedMethodsSubset(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving orderedmethodssubset name: {e}")
    
    
    
    
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all orderedmethodssubsets """
        if filter_dict is None:
            res = await self.orderedmethodssubset_client.List(lara_django_processes_pb2.OrderedMethodsSubsetListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.orderedmethodssubset_client.List(
                lara_django_processes_pb2.OrderedMethodsSubsetListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.orderedmethodssubset_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all orderedmethodssubsets """
        if self.orderedmethodssubset_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.orderedmethodssubset_full_client.List(
                lara_django_processes_pb2.OrderedMethodsSubsetFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.orderedmethodssubset_full_client.List(
                lara_django_processes_pb2.OrderedMethodsSubsetFullListRequest(), metadata=metadata
            )
    
    @import_model_instance_from_file()
    async def update(self, orderedmethodssubset : processes_dm.OrderedMethodsSubset = None) -> None:
        """ update a orderedmethodssubset model instance """
        try:
            res = await self.orderedmethodssubset_client.Update(
                lara_django_processes_pb2.OrderedMethodsSubsetRequest(**orderedmethodssubset.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating orderedmethodssubset_id: {e}")
        else:
            return res
    
    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a orderedmethodssubset by orderedmethodssubset_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.orderedmethodssubset_client.Destroy(lara_django_processes_pb2.OrderedMethodsSubsetDestroyRequest(orderedmethodssubset_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting orderedmethodssubset_id: {e}")

#_________________  Procedure  ______________________


class ProcedureInterface:
    def __init__(self, channel: grpc.Channel = None, 
                       default_namespace_uri : str = None,
                       default_namespace_id : str = None,
                       namespace_if = None ) -> None:
        self._default_namespace_uri = default_namespace_uri
        self._default_namespace_id = default_namespace_id

        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.namespace_if = namespace_if if namespace_if is not None else base_if.NamespaceInterface(channel)

        # self.procedure_class_client = (
        #     lara_django_processes_pb2_grpc.ProcedureclassByIRIControllerStub(channel)
        # )

        self.procedure_client = lara_django_processes_pb2_grpc.ProcedureControllerStub(channel)
        
        self.item_id = None
        self.update_item_id = "procedure_id"
        self.stub = self.procedure_client

        self.file_download_info = lara_django_processes_pb2.FileDownloadInfo
        self.file_upload_chunk = lara_django_processes_pb2.FileUploadChunk


        # self.procedure_full_client = lara_django_processes_pb2_grpc.ProcedureFullControllerStub(
        #     channel
        # )

    @property
    def default_namespace_uri(self):
        return self._default_namespace_uri

    @property
    def default_namespace_id(self):
        return self._default_namespace_id

    @classmethod
    async def build_if(cls, channel: grpc.Channel = None, default_namespace_uri: str = None):
    
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel
    
        namespace_if = base_if.NamespaceInterface(channel)
        try:
            default_namespace_id = await namespace_if.retrieve_id(namespace_uri=default_namespace_uri)
        except Exception as e:
            logger.error(f"Error retrieving namespace_id: {e}")
        
        return cls(channel=channel, default_namespace_uri=default_namespace_uri,  
                   default_namespace_id=default_namespace_id, namespace_if=namespace_if)
    
    async def set_default_namespace_uri(self, namespace_uri: str = None):
        if namespace_uri is not None:
            self._default_namespace_uri = namespace_uri.strip()
        try:
            self._default_namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logger.error(f"Error retrieving namespace_id: {e}")
    
    @import_model_instance_from_file()
    @upload_file  # needed for file upload
    async def create(self,  procedures:  list[processes_dm.Procedure] = None,  
                            ids_only: bool = False,
                            namespace_uri: str = None) -> Union[list[str], list[processes_dm.Procedure]]:
        """ create a list of procedure instances,
               returns a list of procedure data model objects or ids_only

        :param procedures: list of procedure data model objects
        :param ids_only: return only the ids of the created instances
        :return: list of procedure data model objects or ids_only
        """
        procedureclass_id = None

        namespace_id = None
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
            namespace_id = self._default_namespace_id
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        if namespace_id is None:
            try:
                namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
            except Exception as e:
                logger.error(f"Error retrieving namespace_id: {e}")

        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if procedure_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.procedure_class_client.Retrieve(
        #         lara_django_processes_pb2.ProcedureclassRetrieveRequest(iri=procedure_class_iri)
        #     )
        #     procedureclass_id = res.procedureclass_id
        # except Exception as e:
        #     logger.error(f"Error retrieving procedureclass_id: {e}")
        for procedure in procedures:
            if procedure.namespace == "" or procedure.namespace == "default":
                    procedure.namespace = namespace_id
            # procedure.procedure_class = procedureclass_id # uncomment if a model class is used
            if procedure.procedure_json is not None:
                try:
                    procedure_struct = Struct()
                    procedure_json = procedure.procedure_json
                    procedure_struct.update(procedure_json)
                    procedure.procedure_json = procedure_struct
                except Exception as e:
                    logging.error(f"Error(DataInterface) - converting data_json to Struct: {e}")
        try:
            create_coroutines = ( self.procedure_client.Create(lara_django_processes_pb2.ProcedureRequest(**procedure.model_dump())) for procedure in procedures )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [ MessageToDict(item, preserving_proto_field_name=True).get("procedure_id") for item in res ]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating procedure: {e}")
        
    @export_model_instance_to_file
    async def retrieve(
        self,
        namespace_uri: str = None,
        procedure_id: str = None,
        name: str = None,
        # name_display: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[processes_dm.Procedure]:
        """ retrieve a list of procedure instances by procedure_id, name or filter_dict,
               returns a list of procedure data model objects,
               if raw is True, the raw protobuf objects are returned.
               If namespace_uri is "default", the default namespace_uri is used.
        """
        if namespace_uri == "default":
            if self._default_namespace_uri is not None:
                namespace_uri = self._default_namespace_uri
            else:
                raise ValueError("No default namespace URI is given.")
        
        results_list = []
        if  procedure_id is not None:
            try:
                res =  await self.procedure_client.Retrieve(
                    lara_django_processes_pb2.ProcedureRetrieveRequest(procedure_id=procedure_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( processes_dm.Procedure(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving procedure_id: {e}")

        if filter_dict is None:
            filter_dict = {}

        if name is not None:
            filter_dict["name"] = name
        if namespace_uri is not None:
            filter_dict["namespace__uri"] = namespace_uri
        # if name_display is not None:
        #    filter_dict["name_display"] = name_display

        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.procedure_client.List(
                    lara_django_processes_pb2.ProcedureListRequest(), metadata=metadata
                    )
            if raw:
                    results_list += res.results
            else:
                # :TODO: a queue could be used here to speed up the retrieval
                results = res.results
                results_list += [ processes_dm.Procedure(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
        except Exception as e:
            logger.error(f"Error retrieving procedure name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          name: str = None,
                          # name_display: str = None,
                          namespace_uri : str = None,
                          filter_dict : dict = None,
                          iri: str = None,) -> str:
        """ retrieve the procedure_id for a given name,
               name_display or iri
        """

        results_list = await self.retrieve(name=name, 
                        namespace_uri=namespace_uri, filter_dict=filter_dict, raw=True)

        if len(results_list) == 1 :
            return results_list[0].procedure_id
        else:
            raise ValueError(f"Error retrieving procedure_id - no or too many results found.")
    
    @download_file  # needed for file download
    async def get_by_id(self, procedure_id: str = None, id_only: bool = False) -> processes_dm.Procedure:
        """ retrieve a procedure data model by procedure_id """
        try:
            res = await self.procedure_client.Retrieve(
                lara_django_processes_pb2.ProcedureRetrieveRequest(procedure_id=procedure_id)
            )
            item = processes_dm.Procedure(**MessageToDict(res, preserving_proto_field_name=True))
            self.item_id = item.procedure_id
            return item
        except Exception as e:
            logger.error(f"Error retrieving procedure_id: {e}")
    
    @download_file  # needed for file download
    async def get_by_name(self, name: str = None,
                                namespace_uri : str = None,
                                id_only: bool = False) -> processes_dm.Procedure | str:
        """ retrieve a procedure data model by name """
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            res = await self.procedure_client.RetrieveByNameNamespace(
                lara_django_processes_pb2.ProcedureRetrieveByNameNSRequest(name=name, namespace_uri=namespace_uri)
            )
            item = MessageToDict(res, preserving_proto_field_name=True)
            self.item_id = item["procedure_id"]
            if id_only:
                return self.item_id
            else:
                return processes_dm.Procedure(**item)
        except Exception as e:
            logger.error(f"Error retrieving procedure name: {e}")
   
    
    @download_file  # needed for file download
    async def get_file(self, procedure_id : str = None, id_only : bool = True ) -> bytes | None:
        """ retrieve a file by data_id """
        self.item_id = procedure_id
        
    
    async def get_file_by_name(self, name: str = None,
                                namespace_uri : str = None,
                                filename_target : str = None,
                                as_byte_str : bool = None ) -> bytes | None:
        """ retrieve a file by name """
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
            # logger.warning(f"no namespace_uri provided, using default namespace: {namespace_uri}")
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            procedure_id = await self.get_by_name(name=name, namespace_uri=namespace_uri, id_only=True)
            return await self.get_file(procedure_id=procedure_id, filename_target=filename_target, as_byte_str=as_byte_str, get_file=True)
        except Exception as e:
            logger.error(f"Error retrieving procedure name: {e}")
        
    
    
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all procedures """
        if filter_dict is None:
            res = await self.procedure_client.List(lara_django_processes_pb2.ProcedureListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.procedure_client.List(
                lara_django_processes_pb2.ProcedureListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.procedure_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all procedures """
        if self.procedure_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.procedure_full_client.List(
                lara_django_processes_pb2.ProcedureFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.procedure_full_client.List(
                lara_django_processes_pb2.ProcedureFullListRequest(), metadata=metadata
            )
    
    @import_model_instance_from_file()
    @update_file  # needed for file update
    async def update(self, procedure : processes_dm.Procedure = None) -> None:
        """ update a procedure model instance """
        try:
            res = await self.procedure_client.Update(
                lara_django_processes_pb2.ProcedureRequest(**procedure.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating procedure_id: {e}")
        else:
            return res
    
    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a procedure by procedure_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.procedure_client.Destroy(lara_django_processes_pb2.ProcedureDestroyRequest(procedure_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting procedure_id: {e}")

#_________________  ProceduresSubset  ______________________


class ProceduresSubsetInterface:
    def __init__(self, channel: grpc.Channel = None, 
                       default_namespace_uri : str = None,
                       default_namespace_id : str = None,
                       namespace_if = None ) -> None:
        self._default_namespace_uri = default_namespace_uri
        self._default_namespace_id = default_namespace_id

        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.namespace_if = namespace_if if namespace_if is not None else base_if.NamespaceInterface(channel)

        # self.proceduressubset_class_client = (
        #     lara_django_processes_pb2_grpc.ProceduresSubsetclassByIRIControllerStub(channel)
        # )

        self.proceduressubset_client = lara_django_processes_pb2_grpc.ProceduresSubsetControllerStub(channel)
        

        # self.proceduressubset_full_client = lara_django_processes_pb2_grpc.ProceduresSubsetFullControllerStub(
        #     channel
        # )

    @property
    def default_namespace_uri(self):
        return self._default_namespace_uri

    @property
    def default_namespace_id(self):
        return self._default_namespace_id

    @classmethod
    async def build_if(cls, channel: grpc.Channel = None, default_namespace_uri: str = None):
    
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel
    
        namespace_if = base_if.NamespaceInterface(channel)
        try:
            default_namespace_id = await namespace_if.retrieve_id(namespace_uri=default_namespace_uri)
        except Exception as e:
            logger.error(f"Error retrieving namespace_id: {e}")
        
        return cls(channel=channel, default_namespace_uri=default_namespace_uri,  
                   default_namespace_id=default_namespace_id, namespace_if=namespace_if)
    
    async def set_default_namespace_uri(self, namespace_uri: str = None):
        if namespace_uri is not None:
            self._default_namespace_uri = namespace_uri.strip()
        try:
            self._default_namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logger.error(f"Error retrieving namespace_id: {e}")
    
    @import_model_instance_from_file()
    async def create(self,  proceduressubsets:  list[processes_dm.ProceduresSubset] = None,  
                            ids_only: bool = False,
                            namespace_uri: str = None) -> Union[list[str], list[processes_dm.ProceduresSubset]]:
        """ create a list of proceduressubset instances,
               returns a list of proceduressubset data model objects or ids_only

        :param proceduressubsets: list of proceduressubset data model objects
        :param ids_only: return only the ids of the created instances
        :return: list of proceduressubset data model objects or ids_only
        """
        proceduressubsetclass_id = None

        namespace_id = None
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
            namespace_id = self._default_namespace_id
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        if namespace_id is None:
            try:
                namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
            except Exception as e:
                logger.error(f"Error retrieving namespace_id: {e}")

        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if proceduressubset_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.proceduressubset_class_client.Retrieve(
        #         lara_django_processes_pb2.ProceduresSubsetclassRetrieveRequest(iri=proceduressubset_class_iri)
        #     )
        #     proceduressubsetclass_id = res.proceduressubsetclass_id
        # except Exception as e:
        #     logger.error(f"Error retrieving proceduressubsetclass_id: {e}")
        for proceduressubset in proceduressubsets:
            if proceduressubset.namespace == "" or proceduressubset.namespace == "default":
                    proceduressubset.namespace = namespace_id
            # proceduressubset.proceduressubset_class = proceduressubsetclass_id # uncomment if a model class is used

        try:
            create_coroutines = ( self.proceduressubset_client.Create(lara_django_processes_pb2.ProceduresSubsetRequest(**proceduressubset.model_dump())) for proceduressubset in proceduressubsets )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [ MessageToDict(item, preserving_proto_field_name=True).get("proceduressubset_id") for item in res ]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating proceduressubset: {e}")
        
    @export_model_instance_to_file
    async def retrieve(
        self,
        namespace_uri: str = None,
        proceduressubset_id: str = None,
        name: str = None,
        # name_display: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[processes_dm.ProceduresSubset]:
        """ retrieve a list of proceduressubset instances by proceduressubset_id, name or filter_dict,
               returns a list of proceduressubset data model objects,
               if raw is True, the raw protobuf objects are returned.
               If namespace_uri is "default", the default namespace_uri is used.
        """
        if namespace_uri == "default":
            if self._default_namespace_uri is not None:
                namespace_uri = self._default_namespace_uri
            else:
                raise ValueError("No default namespace URI is given.")
        
        results_list = []
        if  proceduressubset_id is not None:
            try:
                res =  await self.proceduressubset_client.Retrieve(
                    lara_django_processes_pb2.ProceduresSubsetRetrieveRequest(proceduressubset_id=proceduressubset_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( processes_dm.ProceduresSubset(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving proceduressubset_id: {e}")

        if filter_dict is None:
            filter_dict = {}

        if name is not None:
            filter_dict["name"] = name
        if namespace_uri is not None:
            filter_dict["namespace__uri"] = namespace_uri
        # if name_display is not None:
        #    filter_dict["name_display"] = name_display

        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.proceduressubset_client.List(
                    lara_django_processes_pb2.ProceduresSubsetListRequest(), metadata=metadata
                    )
            if raw:
                    results_list += res.results
            else:
                # :TODO: a queue could be used here to speed up the retrieval
                results = res.results
                results_list += [ processes_dm.ProceduresSubset(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
        except Exception as e:
            logger.error(f"Error retrieving proceduressubset name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          name: str = None,
                          # name_display: str = None,
                          namespace_uri : str = None,
                          filter_dict : dict = None,
                          iri: str = None,) -> str:
        """ retrieve the proceduressubset_id for a given name,
               name_display or iri
        """

        results_list = await self.retrieve(name=name, 
                        namespace_uri=namespace_uri, filter_dict=filter_dict, raw=True)

        if len(results_list) == 1 :
            return results_list[0].proceduressubset_id
        else:
            raise ValueError(f"Error retrieving proceduressubset_id - no or too many results found.")
    
    async def get_by_id(self, proceduressubset_id: str = None, id_only: bool = False) -> processes_dm.ProceduresSubset:
        """ retrieve a proceduressubset data model by proceduressubset_id """
        try:
            res = await self.proceduressubset_client.Retrieve(
                lara_django_processes_pb2.ProceduresSubsetRetrieveRequest(proceduressubset_id=proceduressubset_id)
            )
            item = processes_dm.ProceduresSubset(**MessageToDict(res, preserving_proto_field_name=True))
            self.item_id = item.proceduressubset_id
            return item
        except Exception as e:
            logger.error(f"Error retrieving proceduressubset_id: {e}")
    
    async def get_by_name(self, name: str = None,
                                namespace_uri : str = None,
                                id_only: bool = False) -> processes_dm.ProceduresSubset | str:
        """ retrieve a proceduressubset data model by name """
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            res = await self.proceduressubset_client.RetrieveByNameNamespace(
                lara_django_processes_pb2.ProceduresSubsetRetrieveByNameNSRequest(name=name, namespace_uri=namespace_uri)
            )
            item = MessageToDict(res, preserving_proto_field_name=True)
            self.item_id = item["proceduressubset_id"]
            if id_only:
                return self.item_id
            else:
                return processes_dm.ProceduresSubset(**item)
        except Exception as e:
            logger.error(f"Error retrieving proceduressubset name: {e}")
   
    
    
    
    
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all proceduressubsets """
        if filter_dict is None:
            res = await self.proceduressubset_client.List(lara_django_processes_pb2.ProceduresSubsetListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.proceduressubset_client.List(
                lara_django_processes_pb2.ProceduresSubsetListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.proceduressubset_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all proceduressubsets """
        if self.proceduressubset_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.proceduressubset_full_client.List(
                lara_django_processes_pb2.ProceduresSubsetFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.proceduressubset_full_client.List(
                lara_django_processes_pb2.ProceduresSubsetFullListRequest(), metadata=metadata
            )
    
    @import_model_instance_from_file()
    async def update(self, proceduressubset : processes_dm.ProceduresSubset = None) -> None:
        """ update a proceduressubset model instance """
        try:
            res = await self.proceduressubset_client.Update(
                lara_django_processes_pb2.ProceduresSubsetRequest(**proceduressubset.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating proceduressubset_id: {e}")
        else:
            return res
    
    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a proceduressubset by proceduressubset_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.proceduressubset_client.Destroy(lara_django_processes_pb2.ProceduresSubsetDestroyRequest(proceduressubset_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting proceduressubset_id: {e}")

#_________________  OrderedProceduresSubset  ______________________


class OrderedProceduresSubsetInterface:
    def __init__(self, channel: grpc.Channel = None) -> None:
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.orderedproceduressubset_client = lara_django_processes_pb2_grpc.OrderedProceduresSubsetControllerStub(channel)
        
    
    @import_model_instance_from_file()
    async def create(self,  orderedproceduressubsets:  list[processes_dm.OrderedProceduresSubset] = None,  ids_only: bool = False) -> Union[list[str], list[processes_dm.OrderedProceduresSubset]]:
        try:
            create_coroutines = ( self.orderedproceduressubset_client.Create(lara_django_processes_pb2.OrderedProceduresSubsetRequest(**orderedproceduressubset.model_dump())) for orderedproceduressubset in orderedproceduressubsets )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.orderedproceduressubset_id for item in res]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating orderedproceduressubset: {e}")
        
    @export_model_instance_to_file
    async def retrieve(
        self,
        orderedproceduressubset_id: str = None,
        name: str = None,
        # name_display: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[processes_dm.OrderedProceduresSubset]:
        """ retrieve a list of orderedproceduressubset instances by orderedproceduressubset_id, name or filter_dict,
               returns a list of orderedproceduressubset data model objects,
               if raw is True, the raw protobuf objects are returned
        """
        results_list = []
        if  orderedproceduressubset_id is not None:
            try:
                res =  await self.orderedproceduressubset_client.Retrieve(
                    lara_django_processes_pb2.OrderedProceduresSubsetRetrieveRequest(orderedproceduressubset_id=orderedproceduressubset_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( processes_dm.OrderedProceduresSubset(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving orderedproceduressubset_id: {e}")

        if filter_dict is None:
            filter_dict = {}

        if name is not None:
            filter_dict["name"] = name
        # if name_display is not None:
        #    filter_dict["name_display"] = name_display

        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.orderedproceduressubset_client.List(
                    lara_django_processes_pb2.OrderedProceduresSubsetListRequest(), metadata=metadata
                    )
            if raw:
                    results_list += res.results
            else:
                # a queue could be used here to speed up the retrieval
                results = res.results
                results_list += [ processes_dm.OrderedProceduresSubset(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
        except Exception as e:
            logger.error(f"Error retrieving orderedproceduressubset name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          name: str = None,
                          # name_display: str = None,
                          filter_dict : dict = None,
                          iri: str = None,) -> str:
        """ retrieve the orderedproceduressubset_id for a given name,
               (name_display) or iri
        """
        
        results_list = await self.retrieve(name=name, filter_dict=filter_dict, raw=True)
        if len(results_list) == 1 :
            return results_list[0].orderedproceduressubset_id
        else:
            raise ValueError(f"Error retrieving orderedproceduressubset_id - no or too many results found.")
    
    async def get_by_id(self, orderedproceduressubset_id: str = None) -> processes_dm.OrderedProceduresSubset:
        """ retrieve a orderedproceduressubset data model by orderedproceduressubset_id """
        try:
            res = await self.orderedproceduressubset_client.Retrieve(
                lara_django_processes_pb2.OrderedProceduresSubsetRetrieveRequest(orderedproceduressubset_id=orderedproceduressubset_id)
            )
            return processes_dm.OrderedProceduresSubset(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving orderedproceduressubset_id: {e}")
    
    async def get_by_name(self, name: str = None, id_only: bool = False) -> processes_dm.OrderedProceduresSubset | str:
        """ retrieve a orderedproceduressubset data model by name """
        try:
            res = await self.orderedproceduressubset_client.RetrieveByNameNamespace(
                lara_django_processes_pb2.OrderedProceduresSubsetRetrieveByNameNSRequest(name=name, namespace_uri="")
            )
            if id_only:
                return MessageToDict(res, preserving_proto_field_name=True)["orderedproceduressubset_id"]
            else:
                return processes_dm.OrderedProceduresSubset(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving orderedproceduressubset name: {e}")
    
    
    
    
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all orderedproceduressubsets """
        if filter_dict is None:
            res = await self.orderedproceduressubset_client.List(lara_django_processes_pb2.OrderedProceduresSubsetListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.orderedproceduressubset_client.List(
                lara_django_processes_pb2.OrderedProceduresSubsetListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.orderedproceduressubset_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all orderedproceduressubsets """
        if self.orderedproceduressubset_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.orderedproceduressubset_full_client.List(
                lara_django_processes_pb2.OrderedProceduresSubsetFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.orderedproceduressubset_full_client.List(
                lara_django_processes_pb2.OrderedProceduresSubsetFullListRequest(), metadata=metadata
            )
    
    @import_model_instance_from_file()
    async def update(self, orderedproceduressubset : processes_dm.OrderedProceduresSubset = None) -> None:
        """ update a orderedproceduressubset model instance """
        try:
            res = await self.orderedproceduressubset_client.Update(
                lara_django_processes_pb2.OrderedProceduresSubsetRequest(**orderedproceduressubset.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating orderedproceduressubset_id: {e}")
        else:
            return res
    
    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a orderedproceduressubset by orderedproceduressubset_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.orderedproceduressubset_client.Destroy(lara_django_processes_pb2.OrderedProceduresSubsetDestroyRequest(orderedproceduressubset_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting orderedproceduressubset_id: {e}")

#_________________  Process  ______________________


class ProcessInterface:
    def __init__(self, channel: grpc.Channel = None, 
                       default_namespace_uri : str = None,
                       default_namespace_id : str = None,
                       namespace_if = None ) -> None:
        self._default_namespace_uri = default_namespace_uri
        self._default_namespace_id = default_namespace_id

        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.namespace_if = namespace_if if namespace_if is not None else base_if.NamespaceInterface(channel)

        # self.process_class_client = (
        #     lara_django_processes_pb2_grpc.ProcessclassByIRIControllerStub(channel)
        # )

        self.process_client = lara_django_processes_pb2_grpc.ProcessControllerStub(channel)
        
        self.item_id = None
        self.update_item_id = "process_id"
        self.stub = self.process_client

        self.file_download_info = lara_django_processes_pb2.FileDownloadInfo
        self.file_upload_chunk = lara_django_processes_pb2.FileUploadChunk


        # self.process_full_client = lara_django_processes_pb2_grpc.ProcessFullControllerStub(
        #     channel
        # )

    @property
    def default_namespace_uri(self):
        return self._default_namespace_uri

    @property
    def default_namespace_id(self):
        return self._default_namespace_id

    @classmethod
    async def build_if(cls, channel: grpc.Channel = None, default_namespace_uri: str = None):
    
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel
    
        namespace_if = base_if.NamespaceInterface(channel)
        try:
            default_namespace_id = await namespace_if.retrieve_id(namespace_uri=default_namespace_uri)
        except Exception as e:
            logger.error(f"Error retrieving namespace_id: {e}")
        
        return cls(channel=channel, default_namespace_uri=default_namespace_uri,  
                   default_namespace_id=default_namespace_id, namespace_if=namespace_if)
    
    async def set_default_namespace_uri(self, namespace_uri: str = None):
        if namespace_uri is not None:
            self._default_namespace_uri = namespace_uri.strip()
        try:
            self._default_namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logger.error(f"Error retrieving namespace_id: {e}")
    
    @import_model_instance_from_file()
    @upload_file  # needed for file upload
    async def create(self,  processes:  list[processes_dm.Process] = None,  
                            ids_only: bool = False,
                            namespace_uri: str = None) -> Union[list[str], list[processes_dm.Process]]:
        """ create a list of process instances,
               returns a list of process data model objects or ids_only

        :param processes: list of process data model objects
        :param ids_only: return only the ids of the created instances
        :return: list of process data model objects or ids_only
        """
        processclass_id = None

        namespace_id = None
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
            namespace_id = self._default_namespace_id
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        if namespace_id is None:
            try:
                namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
            except Exception as e:
                logger.error(f"Error retrieving namespace_id: {e}")

        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if process_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.process_class_client.Retrieve(
        #         lara_django_processes_pb2.ProcessclassRetrieveRequest(iri=process_class_iri)
        #     )
        #     processclass_id = res.processclass_id
        # except Exception as e:
        #     logger.error(f"Error retrieving processclass_id: {e}")
        for process in processes:
            if process.namespace == "" or process.namespace == "default":
                    process.namespace = namespace_id
            # process.process_class = processclass_id # uncomment if a model class is used
            if process.process_json is not None:
                    try:
                        process_struct = Struct()
                        process_json = process.process_json
                        process_struct.update(process_json)
                        process.process_json = process_struct
                    except Exception as e:
                        logging.error(f"Error(DataInterface) - converting data_json to Struct: {e}")

        try:
            create_coroutines = ( self.process_client.Create(lara_django_processes_pb2.ProcessRequest(**process.model_dump())) for process in processes )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [ MessageToDict(item, preserving_proto_field_name=True).get("process_id") for item in res ]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating process: {e}")
        
    @export_model_instance_to_file
    async def retrieve(
        self,
        namespace_uri: str = None,
        process_id: str = None,
        name: str = None,
        # name_display: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[processes_dm.Process]:
        """ retrieve a list of process instances by process_id, name or filter_dict,
               returns a list of process data model objects,
               if raw is True, the raw protobuf objects are returned.
               If namespace_uri is "default", the default namespace_uri is used.
        """
        if namespace_uri == "default":
            if self._default_namespace_uri is not None:
                namespace_uri = self._default_namespace_uri
            else:
                raise ValueError("No default namespace URI is given.")
        
        results_list = []
        if  process_id is not None:
            try:
                res =  await self.process_client.Retrieve(
                    lara_django_processes_pb2.ProcessRetrieveRequest(process_id=process_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( processes_dm.Process(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving process_id: {e}")

        if filter_dict is None:
            filter_dict = {}

        if name is not None:
            filter_dict["name"] = name
        if namespace_uri is not None:
            filter_dict["namespace__uri"] = namespace_uri
        # if name_display is not None:
        #    filter_dict["name_display"] = name_display

        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.process_client.List(
                    lara_django_processes_pb2.ProcessListRequest(), metadata=metadata
                    )
            if raw:
                    results_list += res.results
            else:
                # :TODO: a queue could be used here to speed up the retrieval
                results = res.results
                results_list += [ processes_dm.Process(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
        except Exception as e:
            logger.error(f"Error retrieving process name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          name: str = None,
                          # name_display: str = None,
                          namespace_uri : str = None,
                          filter_dict : dict = None,
                          iri: str = None,) -> str:
        """ retrieve the process_id for a given name,
               name_display or iri
        """

        results_list = await self.retrieve(name=name, 
                        namespace_uri=namespace_uri, filter_dict=filter_dict, raw=True)

        if len(results_list) == 1 :
            return results_list[0].process_id
        else:
            raise ValueError(f"Error retrieving process_id - no or too many results found.")
    
    @download_file  # needed for file download
    async def get_by_id(self, process_id: str = None, id_only: bool = False) -> processes_dm.Process:
        """ retrieve a process data model by process_id """
        try:
            res = await self.process_client.Retrieve(
                lara_django_processes_pb2.ProcessRetrieveRequest(process_id=process_id)
            )
            item = processes_dm.Process(**MessageToDict(res, preserving_proto_field_name=True))
            self.item_id = item.process_id
            return item
        except Exception as e:
            logger.error(f"Error retrieving process_id: {e}")
    
    @download_file  # needed for file download
    async def get_by_name(self, name: str = None,
                                namespace_uri : str = None,
                                id_only: bool = False) -> processes_dm.Process | str:
        """ retrieve a process data model by name """
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            res = await self.process_client.RetrieveByNameNamespace(
                lara_django_processes_pb2.ProcessRetrieveByNameNSRequest(name=name, namespace_uri=namespace_uri)
            )
            item = MessageToDict(res, preserving_proto_field_name=True)
            self.item_id = item["process_id"]
            if id_only:
                return self.item_id
            else:
                return processes_dm.Process(**item)
        except Exception as e:
            logger.error(f"Error retrieving process name: {e}")
   
    
    @download_file  # needed for file download
    async def get_file(self, process_id : str = None, id_only : bool = True ) -> bytes | None:
        """ retrieve a file by data_id """
        self.item_id = process_id
        
    
    async def get_file_by_name(self, name: str = None,
                                namespace_uri : str = None,
                                filename_target : str = None,
                                as_byte_str : bool = None ) -> bytes | None:
        """ retrieve a file by name """
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
            # logger.warning(f"no namespace_uri provided, using default namespace: {namespace_uri}")
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            process_id = await self.get_by_name(name=name, namespace_uri=namespace_uri, id_only=True)
            return await self.get_file(process_id=process_id, filename_target=filename_target, as_byte_str=as_byte_str, get_file=True)
        except Exception as e:
            logger.error(f"Error retrieving process name: {e}")
        
    
    
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all processs """
        if filter_dict is None:
            res = await self.process_client.List(lara_django_processes_pb2.ProcessListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.process_client.List(
                lara_django_processes_pb2.ProcessListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.process_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all processs """
        if self.process_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.process_full_client.List(
                lara_django_processes_pb2.ProcessFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.process_full_client.List(
                lara_django_processes_pb2.ProcessFullListRequest(), metadata=metadata
            )
    
    @import_model_instance_from_file()
    @update_file  # needed for file update
    async def update(self, process : processes_dm.Process = None) -> None:
        """ update a process model instance """
        try:
            res = await self.process_client.Update(
                lara_django_processes_pb2.ProcessRequest(**process.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating process_id: {e}")
        else:
            return res
    
    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a process by process_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.process_client.Destroy(lara_django_processes_pb2.ProcessDestroyRequest(process_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting process_id: {e}")

#_________________  OrderedProcedures  ______________________


class OrderedProceduresInterface:
    def __init__(self, channel: grpc.Channel = None) -> None:
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.orderedprocedures_client = lara_django_processes_pb2_grpc.OrderedProceduresControllerStub(channel)
        
    
    @import_model_instance_from_file()
    async def create(self,  orderedproceduress:  list[processes_dm.OrderedProcedures] = None,  ids_only: bool = False) -> Union[list[str], list[processes_dm.OrderedProcedures]]:
        try:
            create_coroutines = ( self.orderedprocedures_client.Create(lara_django_processes_pb2.OrderedProceduresRequest(**orderedprocedures.model_dump())) for orderedprocedures in orderedproceduress )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.orderedprocedures_id for item in res]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating orderedprocedures: {e}")
        
    @export_model_instance_to_file
    async def retrieve(
        self,
        orderedprocedures_id: str = None,
        name: str = None,
        # name_display: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[processes_dm.OrderedProcedures]:
        """ retrieve a list of orderedprocedures instances by orderedprocedures_id, name or filter_dict,
               returns a list of orderedprocedures data model objects,
               if raw is True, the raw protobuf objects are returned
        """
        results_list = []
        if  orderedprocedures_id is not None:
            try:
                res =  await self.orderedprocedures_client.Retrieve(
                    lara_django_processes_pb2.OrderedProceduresRetrieveRequest(orderedprocedures_id=orderedprocedures_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( processes_dm.OrderedProcedures(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving orderedprocedures_id: {e}")

        if filter_dict is None:
            filter_dict = {}

        if name is not None:
            filter_dict["name"] = name
        # if name_display is not None:
        #    filter_dict["name_display"] = name_display

        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.orderedprocedures_client.List(
                    lara_django_processes_pb2.OrderedProceduresListRequest(), metadata=metadata
                    )
            if raw:
                    results_list += res.results
            else:
                # a queue could be used here to speed up the retrieval
                results = res.results
                results_list += [ processes_dm.OrderedProcedures(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
        except Exception as e:
            logger.error(f"Error retrieving orderedprocedures name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          name: str = None,
                          # name_display: str = None,
                          filter_dict : dict = None,
                          iri: str = None,) -> str:
        """ retrieve the orderedprocedures_id for a given name,
               (name_display) or iri
        """
        
        results_list = await self.retrieve(name=name, filter_dict=filter_dict, raw=True)
        if len(results_list) == 1 :
            return results_list[0].orderedprocedures_id
        else:
            raise ValueError(f"Error retrieving orderedprocedures_id - no or too many results found.")
    
    async def get_by_id(self, orderedprocedures_id: str = None) -> processes_dm.OrderedProcedures:
        """ retrieve a orderedprocedures data model by orderedprocedures_id """
        try:
            res = await self.orderedprocedures_client.Retrieve(
                lara_django_processes_pb2.OrderedProceduresRetrieveRequest(orderedprocedures_id=orderedprocedures_id)
            )
            return processes_dm.OrderedProcedures(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving orderedprocedures_id: {e}")
    
    async def get_by_name(self, name: str = None, id_only: bool = False) -> processes_dm.OrderedProcedures | str:
        """ retrieve a orderedprocedures data model by name """
        try:
            res = await self.orderedprocedures_client.RetrieveByNameNamespace(
                lara_django_processes_pb2.OrderedProceduresRetrieveByNameNSRequest(name=name, namespace_uri="")
            )
            if id_only:
                return MessageToDict(res, preserving_proto_field_name=True)["orderedprocedures_id"]
            else:
                return processes_dm.OrderedProcedures(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving orderedprocedures name: {e}")
    
    
    
    
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all orderedproceduress """
        if filter_dict is None:
            res = await self.orderedprocedures_client.List(lara_django_processes_pb2.OrderedProceduresListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.orderedprocedures_client.List(
                lara_django_processes_pb2.OrderedProceduresListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.orderedprocedures_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all orderedproceduress """
        if self.orderedprocedures_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.orderedprocedures_full_client.List(
                lara_django_processes_pb2.OrderedProceduresFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.orderedprocedures_full_client.List(
                lara_django_processes_pb2.OrderedProceduresFullListRequest(), metadata=metadata
            )
    
    @import_model_instance_from_file()
    async def update(self, orderedprocedures : processes_dm.OrderedProcedures = None) -> None:
        """ update a orderedprocedures model instance """
        try:
            res = await self.orderedprocedures_client.Update(
                lara_django_processes_pb2.OrderedProceduresRequest(**orderedprocedures.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating orderedprocedures_id: {e}")
        else:
            return res
    
    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a orderedprocedures by orderedprocedures_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.orderedprocedures_client.Destroy(lara_django_processes_pb2.OrderedProceduresDestroyRequest(orderedprocedures_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting orderedprocedures_id: {e}")

#_________________  ProcessesSubset  ______________________


class ProcessesSubsetInterface:
    def __init__(self, channel: grpc.Channel = None, 
                       default_namespace_uri : str = None,
                       default_namespace_id : str = None,
                       namespace_if = None ) -> None:
        self._default_namespace_uri = default_namespace_uri
        self._default_namespace_id = default_namespace_id

        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.namespace_if = namespace_if if namespace_if is not None else base_if.NamespaceInterface(channel)

        # self.processessubset_class_client = (
        #     lara_django_processes_pb2_grpc.ProcessesSubsetclassByIRIControllerStub(channel)
        # )

        self.processessubset_client = lara_django_processes_pb2_grpc.ProcessesSubsetControllerStub(channel)
        

        # self.processessubset_full_client = lara_django_processes_pb2_grpc.ProcessesSubsetFullControllerStub(
        #     channel
        # )

    @property
    def default_namespace_uri(self):
        return self._default_namespace_uri

    @property
    def default_namespace_id(self):
        return self._default_namespace_id

    @classmethod
    async def build_if(cls, channel: grpc.Channel = None, default_namespace_uri: str = None):
    
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel
    
        namespace_if = base_if.NamespaceInterface(channel)
        try:
            default_namespace_id = await namespace_if.retrieve_id(namespace_uri=default_namespace_uri)
        except Exception as e:
            logger.error(f"Error retrieving namespace_id: {e}")
        
        return cls(channel=channel, default_namespace_uri=default_namespace_uri,  
                   default_namespace_id=default_namespace_id, namespace_if=namespace_if)
    
    async def set_default_namespace_uri(self, namespace_uri: str = None):
        if namespace_uri is not None:
            self._default_namespace_uri = namespace_uri.strip()
        try:
            self._default_namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logger.error(f"Error retrieving namespace_id: {e}")
    
    @import_model_instance_from_file()
    async def create(self,  processessubsets:  list[processes_dm.ProcessesSubset] = None,  
                            ids_only: bool = False,
                            namespace_uri: str = None) -> Union[list[str], list[processes_dm.ProcessesSubset]]:
        """ create a list of processessubset instances,
               returns a list of processessubset data model objects or ids_only

        :param processessubsets: list of processessubset data model objects
        :param ids_only: return only the ids of the created instances
        :return: list of processessubset data model objects or ids_only
        """
        processessubsetclass_id = None

        namespace_id = None
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
            namespace_id = self._default_namespace_id
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        if namespace_id is None:
            try:
                namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
            except Exception as e:
                logger.error(f"Error retrieving namespace_id: {e}")

        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if processessubset_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.processessubset_class_client.Retrieve(
        #         lara_django_processes_pb2.ProcessesSubsetclassRetrieveRequest(iri=processessubset_class_iri)
        #     )
        #     processessubsetclass_id = res.processessubsetclass_id
        # except Exception as e:
        #     logger.error(f"Error retrieving processessubsetclass_id: {e}")
        for processessubset in processessubsets:
            if processessubset.namespace == "" or processessubset.namespace == "default":
                    processessubset.namespace = namespace_id
            # processessubset.processessubset_class = processessubsetclass_id # uncomment if a model class is used

        try:
            create_coroutines = ( self.processessubset_client.Create(lara_django_processes_pb2.ProcessesSubsetRequest(**processessubset.model_dump())) for processessubset in processessubsets )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [ MessageToDict(item, preserving_proto_field_name=True).get("processessubset_id") for item in res ]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating processessubset: {e}")
        
    @export_model_instance_to_file
    async def retrieve(
        self,
        namespace_uri: str = None,
        processessubset_id: str = None,
        name: str = None,
        # name_display: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[processes_dm.ProcessesSubset]:
        """ retrieve a list of processessubset instances by processessubset_id, name or filter_dict,
               returns a list of processessubset data model objects,
               if raw is True, the raw protobuf objects are returned.
               If namespace_uri is "default", the default namespace_uri is used.
        """
        if namespace_uri == "default":
            if self._default_namespace_uri is not None:
                namespace_uri = self._default_namespace_uri
            else:
                raise ValueError("No default namespace URI is given.")
        
        results_list = []
        if  processessubset_id is not None:
            try:
                res =  await self.processessubset_client.Retrieve(
                    lara_django_processes_pb2.ProcessesSubsetRetrieveRequest(processessubset_id=processessubset_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( processes_dm.ProcessesSubset(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving processessubset_id: {e}")

        if filter_dict is None:
            filter_dict = {}

        if name is not None:
            filter_dict["name"] = name
        if namespace_uri is not None:
            filter_dict["namespace__uri"] = namespace_uri
        # if name_display is not None:
        #    filter_dict["name_display"] = name_display

        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.processessubset_client.List(
                    lara_django_processes_pb2.ProcessesSubsetListRequest(), metadata=metadata
                    )
            if raw:
                    results_list += res.results
            else:
                # :TODO: a queue could be used here to speed up the retrieval
                results = res.results
                results_list += [ processes_dm.ProcessesSubset(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
        except Exception as e:
            logger.error(f"Error retrieving processessubset name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          name: str = None,
                          # name_display: str = None,
                          namespace_uri : str = None,
                          filter_dict : dict = None,
                          iri: str = None,) -> str:
        """ retrieve the processessubset_id for a given name,
               name_display or iri
        """

        results_list = await self.retrieve(name=name, 
                        namespace_uri=namespace_uri, filter_dict=filter_dict, raw=True)

        if len(results_list) == 1 :
            return results_list[0].processessubset_id
        else:
            raise ValueError(f"Error retrieving processessubset_id - no or too many results found.")
    
    async def get_by_id(self, processessubset_id: str = None, id_only: bool = False) -> processes_dm.ProcessesSubset:
        """ retrieve a processessubset data model by processessubset_id """
        try:
            res = await self.processessubset_client.Retrieve(
                lara_django_processes_pb2.ProcessesSubsetRetrieveRequest(processessubset_id=processessubset_id)
            )
            item = processes_dm.ProcessesSubset(**MessageToDict(res, preserving_proto_field_name=True))
            self.item_id = item.processessubset_id
            return item
        except Exception as e:
            logger.error(f"Error retrieving processessubset_id: {e}")
    
    async def get_by_name(self, name: str = None,
                                namespace_uri : str = None,
                                id_only: bool = False) -> processes_dm.ProcessesSubset | str:
        """ retrieve a processessubset data model by name """
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            res = await self.processessubset_client.RetrieveByNameNamespace(
                lara_django_processes_pb2.ProcessesSubsetRetrieveByNameNSRequest(name=name, namespace_uri=namespace_uri)
            )
            item = MessageToDict(res, preserving_proto_field_name=True)
            self.item_id = item["processessubset_id"]
            if id_only:
                return self.item_id
            else:
                return processes_dm.ProcessesSubset(**item)
        except Exception as e:
            logger.error(f"Error retrieving processessubset name: {e}")
   
    
    
    
    
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all processessubsets """
        if filter_dict is None:
            res = await self.processessubset_client.List(lara_django_processes_pb2.ProcessesSubsetListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.processessubset_client.List(
                lara_django_processes_pb2.ProcessesSubsetListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.processessubset_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all processessubsets """
        if self.processessubset_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.processessubset_full_client.List(
                lara_django_processes_pb2.ProcessesSubsetFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.processessubset_full_client.List(
                lara_django_processes_pb2.ProcessesSubsetFullListRequest(), metadata=metadata
            )
    
    @import_model_instance_from_file()
    async def update(self, processessubset : processes_dm.ProcessesSubset = None) -> None:
        """ update a processessubset model instance """
        try:
            res = await self.processessubset_client.Update(
                lara_django_processes_pb2.ProcessesSubsetRequest(**processessubset.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating processessubset_id: {e}")
        else:
            return res
    
    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a processessubset by processessubset_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.processessubset_client.Destroy(lara_django_processes_pb2.ProcessesSubsetDestroyRequest(processessubset_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting processessubset_id: {e}")

#_________________  OrderedProcessesSubset  ______________________


class OrderedProcessesSubsetInterface:
    def __init__(self, channel: grpc.Channel = None) -> None:
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.orderedprocessessubset_client = lara_django_processes_pb2_grpc.OrderedProcessesSubsetControllerStub(channel)
        
    
    @import_model_instance_from_file()
    async def create(self,  orderedprocessessubsets:  list[processes_dm.OrderedProcessesSubset] = None,  ids_only: bool = False) -> Union[list[str], list[processes_dm.OrderedProcessesSubset]]:
        try:
            create_coroutines = ( self.orderedprocessessubset_client.Create(lara_django_processes_pb2.OrderedProcessesSubsetRequest(**orderedprocessessubset.model_dump())) for orderedprocessessubset in orderedprocessessubsets )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.orderedprocessessubset_id for item in res]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating orderedprocessessubset: {e}")
        
    @export_model_instance_to_file
    async def retrieve(
        self,
        orderedprocessessubset_id: str = None,
        name: str = None,
        # name_display: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[processes_dm.OrderedProcessesSubset]:
        """ retrieve a list of orderedprocessessubset instances by orderedprocessessubset_id, name or filter_dict,
               returns a list of orderedprocessessubset data model objects,
               if raw is True, the raw protobuf objects are returned
        """
        results_list = []
        if  orderedprocessessubset_id is not None:
            try:
                res =  await self.orderedprocessessubset_client.Retrieve(
                    lara_django_processes_pb2.OrderedProcessesSubsetRetrieveRequest(orderedprocessessubset_id=orderedprocessessubset_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( processes_dm.OrderedProcessesSubset(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving orderedprocessessubset_id: {e}")

        if filter_dict is None:
            filter_dict = {}

        if name is not None:
            filter_dict["name"] = name
        # if name_display is not None:
        #    filter_dict["name_display"] = name_display

        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.orderedprocessessubset_client.List(
                    lara_django_processes_pb2.OrderedProcessesSubsetListRequest(), metadata=metadata
                    )
            if raw:
                    results_list += res.results
            else:
                # a queue could be used here to speed up the retrieval
                results = res.results
                results_list += [ processes_dm.OrderedProcessesSubset(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
        except Exception as e:
            logger.error(f"Error retrieving orderedprocessessubset name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          name: str = None,
                          # name_display: str = None,
                          filter_dict : dict = None,
                          iri: str = None,) -> str:
        """ retrieve the orderedprocessessubset_id for a given name,
               (name_display) or iri
        """
        
        results_list = await self.retrieve(name=name, filter_dict=filter_dict, raw=True)
        if len(results_list) == 1 :
            return results_list[0].orderedprocessessubset_id
        else:
            raise ValueError(f"Error retrieving orderedprocessessubset_id - no or too many results found.")
    
    async def get_by_id(self, orderedprocessessubset_id: str = None) -> processes_dm.OrderedProcessesSubset:
        """ retrieve a orderedprocessessubset data model by orderedprocessessubset_id """
        try:
            res = await self.orderedprocessessubset_client.Retrieve(
                lara_django_processes_pb2.OrderedProcessesSubsetRetrieveRequest(orderedprocessessubset_id=orderedprocessessubset_id)
            )
            return processes_dm.OrderedProcessesSubset(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving orderedprocessessubset_id: {e}")
    
    async def get_by_name(self, name: str = None, id_only: bool = False) -> processes_dm.OrderedProcessesSubset | str:
        """ retrieve a orderedprocessessubset data model by name """
        try:
            res = await self.orderedprocessessubset_client.RetrieveByNameNamespace(
                lara_django_processes_pb2.OrderedProcessesSubsetRetrieveByNameNSRequest(name=name, namespace_uri="")
            )
            if id_only:
                return MessageToDict(res, preserving_proto_field_name=True)["orderedprocessessubset_id"]
            else:
                return processes_dm.OrderedProcessesSubset(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving orderedprocessessubset name: {e}")
    
    
    
    
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all orderedprocessessubsets """
        if filter_dict is None:
            res = await self.orderedprocessessubset_client.List(lara_django_processes_pb2.OrderedProcessesSubsetListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.orderedprocessessubset_client.List(
                lara_django_processes_pb2.OrderedProcessesSubsetListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.orderedprocessessubset_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all orderedprocessessubsets """
        if self.orderedprocessessubset_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.orderedprocessessubset_full_client.List(
                lara_django_processes_pb2.OrderedProcessesSubsetFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.orderedprocessessubset_full_client.List(
                lara_django_processes_pb2.OrderedProcessesSubsetFullListRequest(), metadata=metadata
            )
    
    @import_model_instance_from_file()
    async def update(self, orderedprocessessubset : processes_dm.OrderedProcessesSubset = None) -> None:
        """ update a orderedprocessessubset model instance """
        try:
            res = await self.orderedprocessessubset_client.Update(
                lara_django_processes_pb2.OrderedProcessesSubsetRequest(**orderedprocessessubset.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating orderedprocessessubset_id: {e}")
        else:
            return res
    
    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a orderedprocessessubset by orderedprocessessubset_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.orderedprocessessubset_client.Destroy(lara_django_processes_pb2.OrderedProcessesSubsetDestroyRequest(orderedprocessessubset_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting orderedprocessessubset_id: {e}")

#_________________  MethodInstance  ______________________


class MethodInstanceInterface:
    def __init__(self, channel: grpc.Channel = None, 
                       default_namespace_uri : str = None,
                       default_namespace_id : str = None,
                       namespace_if = None ) -> None:
        self._default_namespace_uri = default_namespace_uri
        self._default_namespace_id = default_namespace_id

        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.namespace_if = namespace_if if namespace_if is not None else base_if.NamespaceInterface(channel)

        # self.methodinstance_class_client = (
        #     lara_django_processes_pb2_grpc.MethodInstanceclassByIRIControllerStub(channel)
        # )

        self.methodinstance_client = lara_django_processes_pb2_grpc.MethodInstanceControllerStub(channel)
        

        # self.methodinstance_full_client = lara_django_processes_pb2_grpc.MethodInstanceFullControllerStub(
        #     channel
        # )

    @property
    def default_namespace_uri(self):
        return self._default_namespace_uri

    @property
    def default_namespace_id(self):
        return self._default_namespace_id

    @classmethod
    async def build_if(cls, channel: grpc.Channel = None, default_namespace_uri: str = None):
    
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel
    
        namespace_if = base_if.NamespaceInterface(channel)
        try:
            default_namespace_id = await namespace_if.retrieve_id(namespace_uri=default_namespace_uri)
        except Exception as e:
            logger.error(f"Error retrieving namespace_id: {e}")
        
        return cls(channel=channel, default_namespace_uri=default_namespace_uri,  
                   default_namespace_id=default_namespace_id, namespace_if=namespace_if)
    
    async def set_default_namespace_uri(self, namespace_uri: str = None):
        if namespace_uri is not None:
            self._default_namespace_uri = namespace_uri.strip()
        try:
            self._default_namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logger.error(f"Error retrieving namespace_id: {e}")
    
    @import_model_instance_from_file()
    async def create(self,  methodinstances:  list[processes_dm.MethodInstance] = None,  
                            ids_only: bool = False,
                            namespace_uri: str = None) -> Union[list[str], list[processes_dm.MethodInstance]]:
        """ create a list of methodinstance instances,
               returns a list of methodinstance data model objects or ids_only

        :param methodinstances: list of methodinstance data model objects
        :param ids_only: return only the ids of the created instances
        :return: list of methodinstance data model objects or ids_only
        """
        methodinstanceclass_id = None

        namespace_id = None
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
            namespace_id = self._default_namespace_id
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        if namespace_id is None:
            try:
                namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
            except Exception as e:
                logger.error(f"Error retrieving namespace_id: {e}")

        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if methodinstance_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.methodinstance_class_client.Retrieve(
        #         lara_django_processes_pb2.MethodInstanceclassRetrieveRequest(iri=methodinstance_class_iri)
        #     )
        #     methodinstanceclass_id = res.methodinstanceclass_id
        # except Exception as e:
        #     logger.error(f"Error retrieving methodinstanceclass_id: {e}")
        for methodinstance in methodinstances:
            if methodinstance.namespace == "" or methodinstance.namespace == "default":
                    methodinstance.namespace = namespace_id
            # methodinstance.methodinstance_class = methodinstanceclass_id # uncomment if a model class is used

            if methodinstance.method_json is not None:
                try:
                    methodinstance_struct = Struct()
                    method_json = methodinstance.method_json
                    methodinstance_struct.update(method_json)
                    methodinstance.method_json = methodinstance_struct
                except Exception as e:
                    logging.error(f"Error(DataInterface) - converting data_json to Struct: {e}")
        try:
            create_coroutines = ( self.methodinstance_client.Create(lara_django_processes_pb2.MethodInstanceRequest(**methodinstance.model_dump())) for methodinstance in methodinstances )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [ MessageToDict(item, preserving_proto_field_name=True).get("methodinstance_id") for item in res ]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating methodinstance: {e}")
        
    @export_model_instance_to_file
    async def retrieve(
        self,
        namespace_uri: str = None,
        methodinstance_id: str = None,
        name: str = None,
        # name_display: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[processes_dm.MethodInstance]:
        """ retrieve a list of methodinstance instances by methodinstance_id, name or filter_dict,
               returns a list of methodinstance data model objects,
               if raw is True, the raw protobuf objects are returned.
               If namespace_uri is "default", the default namespace_uri is used.
        """
        if namespace_uri == "default":
            if self._default_namespace_uri is not None:
                namespace_uri = self._default_namespace_uri
            else:
                raise ValueError("No default namespace URI is given.")
        
        results_list = []
        if  methodinstance_id is not None:
            try:
                res =  await self.methodinstance_client.Retrieve(
                    lara_django_processes_pb2.MethodInstanceRetrieveRequest(methodinstance_id=methodinstance_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( processes_dm.MethodInstance(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving methodinstance_id: {e}")

        if filter_dict is None:
            filter_dict = {}

        if name is not None:
            filter_dict["name"] = name
        if namespace_uri is not None:
            filter_dict["namespace__uri"] = namespace_uri
        # if name_display is not None:
        #    filter_dict["name_display"] = name_display

        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.methodinstance_client.List(
                    lara_django_processes_pb2.MethodInstanceListRequest(), metadata=metadata
                    )
            if raw:
                    results_list += res.results
            else:
                # :TODO: a queue could be used here to speed up the retrieval
                results = res.results
                results_list += [ processes_dm.MethodInstance(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
        except Exception as e:
            logger.error(f"Error retrieving methodinstance name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          name: str = None,
                          # name_display: str = None,
                          namespace_uri : str = None,
                          filter_dict : dict = None,
                          iri: str = None,) -> str:
        """ retrieve the methodinstance_id for a given name,
               name_display or iri
        """

        results_list = await self.retrieve(name=name, 
                        namespace_uri=namespace_uri, filter_dict=filter_dict, raw=True)

        if len(results_list) == 1 :
            return results_list[0].methodinstance_id
        else:
            raise ValueError(f"Error retrieving methodinstance_id - no or too many results found.")
    
    async def get_by_id(self, methodinstance_id: str = None, id_only: bool = False) -> processes_dm.MethodInstance:
        """ retrieve a methodinstance data model by methodinstance_id """
        try:
            res = await self.methodinstance_client.Retrieve(
                lara_django_processes_pb2.MethodInstanceRetrieveRequest(methodinstance_id=methodinstance_id)
            )
            item = processes_dm.MethodInstance(**MessageToDict(res, preserving_proto_field_name=True))
            self.item_id = item.methodinstance_id
            return item
        except Exception as e:
            logger.error(f"Error retrieving methodinstance_id: {e}")
    
    async def get_by_name(self, name: str = None,
                                namespace_uri : str = None,
                                id_only: bool = False) -> processes_dm.MethodInstance | str:
        """ retrieve a methodinstance data model by name """
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            res = await self.methodinstance_client.RetrieveByNameNamespace(
                lara_django_processes_pb2.MethodInstanceRetrieveByNameNSRequest(name=name, namespace_uri=namespace_uri)
            )
            item = MessageToDict(res, preserving_proto_field_name=True)
            self.item_id = item["methodinstance_id"]
            if id_only:
                return self.item_id
            else:
                return processes_dm.MethodInstance(**item)
        except Exception as e:
            logger.error(f"Error retrieving methodinstance name: {e}")
   
    
    
    
    
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all methodinstances """
        if filter_dict is None:
            res = await self.methodinstance_client.List(lara_django_processes_pb2.MethodInstanceListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.methodinstance_client.List(
                lara_django_processes_pb2.MethodInstanceListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.methodinstance_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all methodinstances """
        if self.methodinstance_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.methodinstance_full_client.List(
                lara_django_processes_pb2.MethodInstanceFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.methodinstance_full_client.List(
                lara_django_processes_pb2.MethodInstanceFullListRequest(), metadata=metadata
            )
    
    @import_model_instance_from_file()
    async def update(self, methodinstance : processes_dm.MethodInstance = None) -> None:
        """ update a methodinstance model instance """
        try:
            res = await self.methodinstance_client.Update(
                lara_django_processes_pb2.MethodInstanceRequest(**methodinstance.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating methodinstance_id: {e}")
        else:
            return res
    
    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a methodinstance by methodinstance_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.methodinstance_client.Destroy(lara_django_processes_pb2.MethodInstanceDestroyRequest(methodinstance_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting methodinstance_id: {e}")

#_________________  MethodInstancesSubset  ______________________


class MethodInstancesSubsetInterface:
    def __init__(self, channel: grpc.Channel = None, 
                       default_namespace_uri : str = None,
                       default_namespace_id : str = None,
                       namespace_if = None ) -> None:
        self._default_namespace_uri = default_namespace_uri
        self._default_namespace_id = default_namespace_id

        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.namespace_if = namespace_if if namespace_if is not None else base_if.NamespaceInterface(channel)

        # self.methodinstancessubset_class_client = (
        #     lara_django_processes_pb2_grpc.MethodInstancesSubsetclassByIRIControllerStub(channel)
        # )

        self.methodinstancessubset_client = lara_django_processes_pb2_grpc.MethodInstancesSubsetControllerStub(channel)
        

        # self.methodinstancessubset_full_client = lara_django_processes_pb2_grpc.MethodInstancesSubsetFullControllerStub(
        #     channel
        # )

    @property
    def default_namespace_uri(self):
        return self._default_namespace_uri

    @property
    def default_namespace_id(self):
        return self._default_namespace_id

    @classmethod
    async def build_if(cls, channel: grpc.Channel = None, default_namespace_uri: str = None):
    
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel
    
        namespace_if = base_if.NamespaceInterface(channel)
        try:
            default_namespace_id = await namespace_if.retrieve_id(namespace_uri=default_namespace_uri)
        except Exception as e:
            logger.error(f"Error retrieving namespace_id: {e}")
        
        return cls(channel=channel, default_namespace_uri=default_namespace_uri,  
                   default_namespace_id=default_namespace_id, namespace_if=namespace_if)
    
    async def set_default_namespace_uri(self, namespace_uri: str = None):
        if namespace_uri is not None:
            self._default_namespace_uri = namespace_uri.strip()
        try:
            self._default_namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logger.error(f"Error retrieving namespace_id: {e}")
    
    @import_model_instance_from_file()
    async def create(self,  methodinstancessubsets:  list[processes_dm.MethodInstancesSubset] = None,  
                            ids_only: bool = False,
                            namespace_uri: str = None) -> Union[list[str], list[processes_dm.MethodInstancesSubset]]:
        """ create a list of methodinstancessubset instances,
               returns a list of methodinstancessubset data model objects or ids_only

        :param methodinstancessubsets: list of methodinstancessubset data model objects
        :param ids_only: return only the ids of the created instances
        :return: list of methodinstancessubset data model objects or ids_only
        """
        methodinstancessubsetclass_id = None

        namespace_id = None
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
            namespace_id = self._default_namespace_id
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        if namespace_id is None:
            try:
                namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
            except Exception as e:
                logger.error(f"Error retrieving namespace_id: {e}")

        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if methodinstancessubset_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.methodinstancessubset_class_client.Retrieve(
        #         lara_django_processes_pb2.MethodInstancesSubsetclassRetrieveRequest(iri=methodinstancessubset_class_iri)
        #     )
        #     methodinstancessubsetclass_id = res.methodinstancessubsetclass_id
        # except Exception as e:
        #     logger.error(f"Error retrieving methodinstancessubsetclass_id: {e}")
        for methodinstancessubset in methodinstancessubsets:
            if methodinstancessubset.namespace == "" or methodinstancessubset.namespace == "default":
                    methodinstancessubset.namespace = namespace_id
            # methodinstancessubset.methodinstancessubset_class = methodinstancessubsetclass_id # uncomment if a model class is used

        try:
            create_coroutines = ( self.methodinstancessubset_client.Create(lara_django_processes_pb2.MethodInstancesSubsetRequest(**methodinstancessubset.model_dump())) for methodinstancessubset in methodinstancessubsets )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [ MessageToDict(item, preserving_proto_field_name=True).get("methodinstancessubset_id") for item in res ]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating methodinstancessubset: {e}")
        
    @export_model_instance_to_file
    async def retrieve(
        self,
        namespace_uri: str = None,
        methodinstancessubset_id: str = None,
        name: str = None,
        # name_display: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[processes_dm.MethodInstancesSubset]:
        """ retrieve a list of methodinstancessubset instances by methodinstancessubset_id, name or filter_dict,
               returns a list of methodinstancessubset data model objects,
               if raw is True, the raw protobuf objects are returned.
               If namespace_uri is "default", the default namespace_uri is used.
        """
        if namespace_uri == "default":
            if self._default_namespace_uri is not None:
                namespace_uri = self._default_namespace_uri
            else:
                raise ValueError("No default namespace URI is given.")
        
        results_list = []
        if  methodinstancessubset_id is not None:
            try:
                res =  await self.methodinstancessubset_client.Retrieve(
                    lara_django_processes_pb2.MethodInstancesSubsetRetrieveRequest(methodinstancessubset_id=methodinstancessubset_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( processes_dm.MethodInstancesSubset(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving methodinstancessubset_id: {e}")

        if filter_dict is None:
            filter_dict = {}

        if name is not None:
            filter_dict["name"] = name
        if namespace_uri is not None:
            filter_dict["namespace__uri"] = namespace_uri
        # if name_display is not None:
        #    filter_dict["name_display"] = name_display

        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.methodinstancessubset_client.List(
                    lara_django_processes_pb2.MethodInstancesSubsetListRequest(), metadata=metadata
                    )
            if raw:
                    results_list += res.results
            else:
                # :TODO: a queue could be used here to speed up the retrieval
                results = res.results
                results_list += [ processes_dm.MethodInstancesSubset(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
        except Exception as e:
            logger.error(f"Error retrieving methodinstancessubset name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          name: str = None,
                          # name_display: str = None,
                          namespace_uri : str = None,
                          filter_dict : dict = None,
                          iri: str = None,) -> str:
        """ retrieve the methodinstancessubset_id for a given name,
               name_display or iri
        """

        results_list = await self.retrieve(name=name, 
                        namespace_uri=namespace_uri, filter_dict=filter_dict, raw=True)

        if len(results_list) == 1 :
            return results_list[0].methodinstancessubset_id
        else:
            raise ValueError(f"Error retrieving methodinstancessubset_id - no or too many results found.")
    
    async def get_by_id(self, methodinstancessubset_id: str = None, id_only: bool = False) -> processes_dm.MethodInstancesSubset:
        """ retrieve a methodinstancessubset data model by methodinstancessubset_id """
        try:
            res = await self.methodinstancessubset_client.Retrieve(
                lara_django_processes_pb2.MethodInstancesSubsetRetrieveRequest(methodinstancessubset_id=methodinstancessubset_id)
            )
            item = processes_dm.MethodInstancesSubset(**MessageToDict(res, preserving_proto_field_name=True))
            self.item_id = item.methodinstancessubset_id
            return item
        except Exception as e:
            logger.error(f"Error retrieving methodinstancessubset_id: {e}")
    
    async def get_by_name(self, name: str = None,
                                namespace_uri : str = None,
                                id_only: bool = False) -> processes_dm.MethodInstancesSubset | str:
        """ retrieve a methodinstancessubset data model by name """
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            res = await self.methodinstancessubset_client.RetrieveByNameNamespace(
                lara_django_processes_pb2.MethodInstancesSubsetRetrieveByNameNSRequest(name=name, namespace_uri=namespace_uri)
            )
            item = MessageToDict(res, preserving_proto_field_name=True)
            self.item_id = item["methodinstancessubset_id"]
            if id_only:
                return self.item_id
            else:
                return processes_dm.MethodInstancesSubset(**item)
        except Exception as e:
            logger.error(f"Error retrieving methodinstancessubset name: {e}")
   
    
    
    
    
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all methodinstancessubsets """
        if filter_dict is None:
            res = await self.methodinstancessubset_client.List(lara_django_processes_pb2.MethodInstancesSubsetListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.methodinstancessubset_client.List(
                lara_django_processes_pb2.MethodInstancesSubsetListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.methodinstancessubset_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all methodinstancessubsets """
        if self.methodinstancessubset_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.methodinstancessubset_full_client.List(
                lara_django_processes_pb2.MethodInstancesSubsetFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.methodinstancessubset_full_client.List(
                lara_django_processes_pb2.MethodInstancesSubsetFullListRequest(), metadata=metadata
            )
    
    @import_model_instance_from_file()
    async def update(self, methodinstancessubset : processes_dm.MethodInstancesSubset = None) -> None:
        """ update a methodinstancessubset model instance """
        try:
            res = await self.methodinstancessubset_client.Update(
                lara_django_processes_pb2.MethodInstancesSubsetRequest(**methodinstancessubset.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating methodinstancessubset_id: {e}")
        else:
            return res
    
    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a methodinstancessubset by methodinstancessubset_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.methodinstancessubset_client.Destroy(lara_django_processes_pb2.MethodInstancesSubsetDestroyRequest(methodinstancessubset_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting methodinstancessubset_id: {e}")

#_________________  OrderedMethodInstancesSubset  ______________________


class OrderedMethodInstancesSubsetInterface:
    def __init__(self, channel: grpc.Channel = None) -> None:
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.orderedmethodinstancessubset_client = lara_django_processes_pb2_grpc.OrderedMethodInstancesSubsetControllerStub(channel)
        
    
    @import_model_instance_from_file()
    async def create(self,  orderedmethodinstancessubsets:  list[processes_dm.OrderedMethodInstancesSubset] = None,  ids_only: bool = False) -> Union[list[str], list[processes_dm.OrderedMethodInstancesSubset]]:
        try:
            create_coroutines = ( self.orderedmethodinstancessubset_client.Create(lara_django_processes_pb2.OrderedMethodInstancesSubsetRequest(**orderedmethodinstancessubset.model_dump())) for orderedmethodinstancessubset in orderedmethodinstancessubsets )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.orderedmethodinstancessubset_id for item in res]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating orderedmethodinstancessubset: {e}")
        
    @export_model_instance_to_file
    async def retrieve(
        self,
        orderedmethodinstancessubset_id: str = None,
        name: str = None,
        # name_display: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[processes_dm.OrderedMethodInstancesSubset]:
        """ retrieve a list of orderedmethodinstancessubset instances by orderedmethodinstancessubset_id, name or filter_dict,
               returns a list of orderedmethodinstancessubset data model objects,
               if raw is True, the raw protobuf objects are returned
        """
        results_list = []
        if  orderedmethodinstancessubset_id is not None:
            try:
                res =  await self.orderedmethodinstancessubset_client.Retrieve(
                    lara_django_processes_pb2.OrderedMethodInstancesSubsetRetrieveRequest(orderedmethodinstancessubset_id=orderedmethodinstancessubset_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( processes_dm.OrderedMethodInstancesSubset(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving orderedmethodinstancessubset_id: {e}")

        if filter_dict is None:
            filter_dict = {}

        if name is not None:
            filter_dict["name"] = name
        # if name_display is not None:
        #    filter_dict["name_display"] = name_display

        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.orderedmethodinstancessubset_client.List(
                    lara_django_processes_pb2.OrderedMethodInstancesSubsetListRequest(), metadata=metadata
                    )
            if raw:
                    results_list += res.results
            else:
                # a queue could be used here to speed up the retrieval
                results = res.results
                results_list += [ processes_dm.OrderedMethodInstancesSubset(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
        except Exception as e:
            logger.error(f"Error retrieving orderedmethodinstancessubset name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          name: str = None,
                          # name_display: str = None,
                          filter_dict : dict = None,
                          iri: str = None,) -> str:
        """ retrieve the orderedmethodinstancessubset_id for a given name,
               (name_display) or iri
        """
        
        results_list = await self.retrieve(name=name, filter_dict=filter_dict, raw=True)
        if len(results_list) == 1 :
            return results_list[0].orderedmethodinstancessubset_id
        else:
            raise ValueError(f"Error retrieving orderedmethodinstancessubset_id - no or too many results found.")
    
    async def get_by_id(self, orderedmethodinstancessubset_id: str = None) -> processes_dm.OrderedMethodInstancesSubset:
        """ retrieve a orderedmethodinstancessubset data model by orderedmethodinstancessubset_id """
        try:
            res = await self.orderedmethodinstancessubset_client.Retrieve(
                lara_django_processes_pb2.OrderedMethodInstancesSubsetRetrieveRequest(orderedmethodinstancessubset_id=orderedmethodinstancessubset_id)
            )
            return processes_dm.OrderedMethodInstancesSubset(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving orderedmethodinstancessubset_id: {e}")
    
    async def get_by_name(self, name: str = None, id_only: bool = False) -> processes_dm.OrderedMethodInstancesSubset | str:
        """ retrieve a orderedmethodinstancessubset data model by name """
        try:
            res = await self.orderedmethodinstancessubset_client.RetrieveByNameNamespace(
                lara_django_processes_pb2.OrderedMethodInstancesSubsetRetrieveByNameNSRequest(name=name, namespace_uri="")
            )
            if id_only:
                return MessageToDict(res, preserving_proto_field_name=True)["orderedmethodinstancessubset_id"]
            else:
                return processes_dm.OrderedMethodInstancesSubset(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving orderedmethodinstancessubset name: {e}")
    
    
    
    
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all orderedmethodinstancessubsets """
        if filter_dict is None:
            res = await self.orderedmethodinstancessubset_client.List(lara_django_processes_pb2.OrderedMethodInstancesSubsetListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.orderedmethodinstancessubset_client.List(
                lara_django_processes_pb2.OrderedMethodInstancesSubsetListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.orderedmethodinstancessubset_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all orderedmethodinstancessubsets """
        if self.orderedmethodinstancessubset_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.orderedmethodinstancessubset_full_client.List(
                lara_django_processes_pb2.OrderedMethodInstancesSubsetFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.orderedmethodinstancessubset_full_client.List(
                lara_django_processes_pb2.OrderedMethodInstancesSubsetFullListRequest(), metadata=metadata
            )
    
    @import_model_instance_from_file()
    async def update(self, orderedmethodinstancessubset : processes_dm.OrderedMethodInstancesSubset = None) -> None:
        """ update a orderedmethodinstancessubset model instance """
        try:
            res = await self.orderedmethodinstancessubset_client.Update(
                lara_django_processes_pb2.OrderedMethodInstancesSubsetRequest(**orderedmethodinstancessubset.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating orderedmethodinstancessubset_id: {e}")
        else:
            return res
    
    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a orderedmethodinstancessubset by orderedmethodinstancessubset_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.orderedmethodinstancessubset_client.Destroy(lara_django_processes_pb2.OrderedMethodInstancesSubsetDestroyRequest(orderedmethodinstancessubset_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting orderedmethodinstancessubset_id: {e}")

#_________________  ProcedureInstance  ______________________


class ProcedureInstanceInterface:
    def __init__(self, channel: grpc.Channel = None, 
                       default_namespace_uri : str = None,
                       default_namespace_id : str = None,
                       namespace_if = None ) -> None:
        self._default_namespace_uri = default_namespace_uri
        self._default_namespace_id = default_namespace_id

        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.namespace_if = namespace_if if namespace_if is not None else base_if.NamespaceInterface(channel)

        # self.procedureinstance_class_client = (
        #     lara_django_processes_pb2_grpc.ProcedureInstanceclassByIRIControllerStub(channel)
        # )

        self.procedureinstance_client = lara_django_processes_pb2_grpc.ProcedureInstanceControllerStub(channel)
        
        self.item_id = None
        self.update_item_id = "procedureinstance_id"
        self.stub = self.procedureinstance_client

        self.file_download_info = lara_django_processes_pb2.FileDownloadInfo
        self.file_upload_chunk = lara_django_processes_pb2.FileUploadChunk


        # self.procedureinstance_full_client = lara_django_processes_pb2_grpc.ProcedureInstanceFullControllerStub(
        #     channel
        # )

    @property
    def default_namespace_uri(self):
        return self._default_namespace_uri

    @property
    def default_namespace_id(self):
        return self._default_namespace_id

    @classmethod
    async def build_if(cls, channel: grpc.Channel = None, default_namespace_uri: str = None):
    
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel
    
        namespace_if = base_if.NamespaceInterface(channel)
        try:
            default_namespace_id = await namespace_if.retrieve_id(namespace_uri=default_namespace_uri)
        except Exception as e:
            logger.error(f"Error retrieving namespace_id: {e}")
        
        return cls(channel=channel, default_namespace_uri=default_namespace_uri,  
                   default_namespace_id=default_namespace_id, namespace_if=namespace_if)
    
    async def set_default_namespace_uri(self, namespace_uri: str = None):
        if namespace_uri is not None:
            self._default_namespace_uri = namespace_uri.strip()
        try:
            self._default_namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logger.error(f"Error retrieving namespace_id: {e}")
    
    @import_model_instance_from_file()
    @upload_file  # needed for file upload
    async def create(self,  procedureinstances:  list[processes_dm.ProcedureInstance] = None,  
                            ids_only: bool = False,
                            namespace_uri: str = None) -> Union[list[str], list[processes_dm.ProcedureInstance]]:
        """ create a list of procedureinstance instances,
               returns a list of procedureinstance data model objects or ids_only

        :param procedureinstances: list of procedureinstance data model objects
        :param ids_only: return only the ids of the created instances
        :return: list of procedureinstance data model objects or ids_only
        """
        procedureinstanceclass_id = None

        namespace_id = None
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
            namespace_id = self._default_namespace_id
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        if namespace_id is None:
            try:
                namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
            except Exception as e:
                logger.error(f"Error retrieving namespace_id: {e}")

        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if procedureinstance_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.procedureinstance_class_client.Retrieve(
        #         lara_django_processes_pb2.ProcedureInstanceclassRetrieveRequest(iri=procedureinstance_class_iri)
        #     )
        #     procedureinstanceclass_id = res.procedureinstanceclass_id
        # except Exception as e:
        #     logger.error(f"Error retrieving procedureinstanceclass_id: {e}")
        for procedureinstance in procedureinstances:
            if procedureinstance.namespace == "" or procedureinstance.namespace == "default":
                    procedureinstance.namespace = namespace_id
            # procedureinstance.procedureinstance_class = procedureinstanceclass_id # uncomment if a model class is used
            if procedureinstance.procedure_json is not None:
                try:
                    procedureinstance_struct = Struct()
                    procedureinstance_json = procedureinstance.procedure_json
                    procedureinstance_struct.update(procedureinstance_json)
                    procedureinstance.procedure_json = procedureinstance_struct
                except Exception as e:
                    logger.error(f"Error updating procedure_json with struct: {e}")

        try:
            create_coroutines = ( self.procedureinstance_client.Create(lara_django_processes_pb2.ProcedureInstanceRequest(**procedureinstance.model_dump())) for procedureinstance in procedureinstances )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [ MessageToDict(item, preserving_proto_field_name=True).get("procedureinstance_id") for item in res ]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating procedureinstance: {e}")
        
    @export_model_instance_to_file
    async def retrieve(
        self,
        namespace_uri: str = None,
        procedureinstance_id: str = None,
        name: str = None,
        # name_display: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[processes_dm.ProcedureInstance]:
        """ retrieve a list of procedureinstance instances by procedureinstance_id, name or filter_dict,
               returns a list of procedureinstance data model objects,
               if raw is True, the raw protobuf objects are returned.
               If namespace_uri is "default", the default namespace_uri is used.
        """
        if namespace_uri == "default":
            if self._default_namespace_uri is not None:
                namespace_uri = self._default_namespace_uri
            else:
                raise ValueError("No default namespace URI is given.")
        
        results_list = []
        if  procedureinstance_id is not None:
            try:
                res =  await self.procedureinstance_client.Retrieve(
                    lara_django_processes_pb2.ProcedureInstanceRetrieveRequest(procedureinstance_id=procedureinstance_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( processes_dm.ProcedureInstance(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving procedureinstance_id: {e}")

        if filter_dict is None:
            filter_dict = {}

        if name is not None:
            filter_dict["name"] = name
        if namespace_uri is not None:
            filter_dict["namespace__uri"] = namespace_uri
        # if name_display is not None:
        #    filter_dict["name_display"] = name_display

        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.procedureinstance_client.List(
                    lara_django_processes_pb2.ProcedureInstanceListRequest(), metadata=metadata
                    )
            if raw:
                    results_list += res.results
            else:
                # :TODO: a queue could be used here to speed up the retrieval
                results = res.results
                results_list += [ processes_dm.ProcedureInstance(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
        except Exception as e:
            logger.error(f"Error retrieving procedureinstance name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          name: str = None,
                          # name_display: str = None,
                          namespace_uri : str = None,
                          filter_dict : dict = None,
                          iri: str = None,) -> str:
        """ retrieve the procedureinstance_id for a given name,
               name_display or iri
        """

        results_list = await self.retrieve(name=name, 
                        namespace_uri=namespace_uri, filter_dict=filter_dict, raw=True)

        if len(results_list) == 1 :
            return results_list[0].procedureinstance_id
        else:
            raise ValueError(f"Error retrieving procedureinstance_id - no or too many results found.")
    
    @download_file  # needed for file download
    async def get_by_id(self, procedureinstance_id: str = None, id_only: bool = False) -> processes_dm.ProcedureInstance:
        """ retrieve a procedureinstance data model by procedureinstance_id """
        try:
            res = await self.procedureinstance_client.Retrieve(
                lara_django_processes_pb2.ProcedureInstanceRetrieveRequest(procedureinstance_id=procedureinstance_id)
            )
            item = processes_dm.ProcedureInstance(**MessageToDict(res, preserving_proto_field_name=True))
            self.item_id = item.procedureinstance_id
            return item
        except Exception as e:
            logger.error(f"Error retrieving procedureinstance_id: {e}")
    
    @download_file  # needed for file download
    async def get_by_name(self, name: str = None,
                                namespace_uri : str = None,
                                id_only: bool = False) -> processes_dm.ProcedureInstance | str:
        """ retrieve a procedureinstance data model by name """
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            res = await self.procedureinstance_client.RetrieveByNameNamespace(
                lara_django_processes_pb2.ProcedureInstanceRetrieveByNameNSRequest(name=name, namespace_uri=namespace_uri)
            )
            item = MessageToDict(res, preserving_proto_field_name=True)
            self.item_id = item["procedureinstance_id"]
            if id_only:
                return self.item_id
            else:
                return processes_dm.ProcedureInstance(**item)
        except Exception as e:
            logger.error(f"Error retrieving procedureinstance name: {e}")
   
    
    @download_file  # needed for file download
    async def get_file(self, procedureinstance_id : str = None, id_only : bool = True ) -> bytes | None:
        """ retrieve a file by data_id """
        self.item_id = procedureinstance_id
        
    
    async def get_file_by_name(self, name: str = None,
                                namespace_uri : str = None,
                                filename_target : str = None,
                                as_byte_str : bool = None ) -> bytes | None:
        """ retrieve a file by name """
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
            # logger.warning(f"no namespace_uri provided, using default namespace: {namespace_uri}")
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            procedureinstance_id = await self.get_by_name(name=name, namespace_uri=namespace_uri, id_only=True)
            return await self.get_file(procedureinstance_id=procedureinstance_id, filename_target=filename_target, as_byte_str=as_byte_str, get_file=True)
        except Exception as e:
            logger.error(f"Error retrieving procedureinstance name: {e}")
        
    
    
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all procedureinstances """
        if filter_dict is None:
            res = await self.procedureinstance_client.List(lara_django_processes_pb2.ProcedureInstanceListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.procedureinstance_client.List(
                lara_django_processes_pb2.ProcedureInstanceListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.procedureinstance_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all procedureinstances """
        if self.procedureinstance_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.procedureinstance_full_client.List(
                lara_django_processes_pb2.ProcedureInstanceFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.procedureinstance_full_client.List(
                lara_django_processes_pb2.ProcedureInstanceFullListRequest(), metadata=metadata
            )
    
    @import_model_instance_from_file()
    @update_file  # needed for file update
    async def update(self, procedureinstance : processes_dm.ProcedureInstance = None) -> None:
        """ update a procedureinstance model instance """
        try:
            res = await self.procedureinstance_client.Update(
                lara_django_processes_pb2.ProcedureInstanceRequest(**procedureinstance.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating procedureinstance_id: {e}")
        else:
            return res
    
    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a procedureinstance by procedureinstance_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.procedureinstance_client.Destroy(lara_django_processes_pb2.ProcedureInstanceDestroyRequest(procedureinstance_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting procedureinstance_id: {e}")

#_________________  ProcedureInstancesSubset  ______________________


class ProcedureInstancesSubsetInterface:
    def __init__(self, channel: grpc.Channel = None, 
                       default_namespace_uri : str = None,
                       default_namespace_id : str = None,
                       namespace_if = None ) -> None:
        self._default_namespace_uri = default_namespace_uri
        self._default_namespace_id = default_namespace_id

        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.namespace_if = namespace_if if namespace_if is not None else base_if.NamespaceInterface(channel)

        # self.procedureinstancessubset_class_client = (
        #     lara_django_processes_pb2_grpc.ProcedureInstancesSubsetclassByIRIControllerStub(channel)
        # )

        self.procedureinstancessubset_client = lara_django_processes_pb2_grpc.ProcedureInstancesSubsetControllerStub(channel)
        

        # self.procedureinstancessubset_full_client = lara_django_processes_pb2_grpc.ProcedureInstancesSubsetFullControllerStub(
        #     channel
        # )

    @property
    def default_namespace_uri(self):
        return self._default_namespace_uri

    @property
    def default_namespace_id(self):
        return self._default_namespace_id

    @classmethod
    async def build_if(cls, channel: grpc.Channel = None, default_namespace_uri: str = None):
    
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel
    
        namespace_if = base_if.NamespaceInterface(channel)
        try:
            default_namespace_id = await namespace_if.retrieve_id(namespace_uri=default_namespace_uri)
        except Exception as e:
            logger.error(f"Error retrieving namespace_id: {e}")
        
        return cls(channel=channel, default_namespace_uri=default_namespace_uri,  
                   default_namespace_id=default_namespace_id, namespace_if=namespace_if)
    
    async def set_default_namespace_uri(self, namespace_uri: str = None):
        if namespace_uri is not None:
            self._default_namespace_uri = namespace_uri.strip()
        try:
            self._default_namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logger.error(f"Error retrieving namespace_id: {e}")
    
    @import_model_instance_from_file()
    async def create(self,  procedureinstancessubsets:  list[processes_dm.ProcedureInstancesSubset] = None,  
                            ids_only: bool = False,
                            namespace_uri: str = None) -> Union[list[str], list[processes_dm.ProcedureInstancesSubset]]:
        """ create a list of procedureinstancessubset instances,
               returns a list of procedureinstancessubset data model objects or ids_only

        :param procedureinstancessubsets: list of procedureinstancessubset data model objects
        :param ids_only: return only the ids of the created instances
        :return: list of procedureinstancessubset data model objects or ids_only
        """
        procedureinstancessubsetclass_id = None

        namespace_id = None
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
            namespace_id = self._default_namespace_id
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        if namespace_id is None:
            try:
                namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
            except Exception as e:
                logger.error(f"Error retrieving namespace_id: {e}")

        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if procedureinstancessubset_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.procedureinstancessubset_class_client.Retrieve(
        #         lara_django_processes_pb2.ProcedureInstancesSubsetclassRetrieveRequest(iri=procedureinstancessubset_class_iri)
        #     )
        #     procedureinstancessubsetclass_id = res.procedureinstancessubsetclass_id
        # except Exception as e:
        #     logger.error(f"Error retrieving procedureinstancessubsetclass_id: {e}")
        for procedureinstancessubset in procedureinstancessubsets:
            if procedureinstancessubset.namespace == "" or procedureinstancessubset.namespace == "default":
                    procedureinstancessubset.namespace = namespace_id
            # procedureinstancessubset.procedureinstancessubset_class = procedureinstancessubsetclass_id # uncomment if a model class is used

        try:
            create_coroutines = ( self.procedureinstancessubset_client.Create(lara_django_processes_pb2.ProcedureInstancesSubsetRequest(**procedureinstancessubset.model_dump())) for procedureinstancessubset in procedureinstancessubsets )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [ MessageToDict(item, preserving_proto_field_name=True).get("procedureinstancessubset_id") for item in res ]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating procedureinstancessubset: {e}")
        
    @export_model_instance_to_file
    async def retrieve(
        self,
        namespace_uri: str = None,
        procedureinstancessubset_id: str = None,
        name: str = None,
        # name_display: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[processes_dm.ProcedureInstancesSubset]:
        """ retrieve a list of procedureinstancessubset instances by procedureinstancessubset_id, name or filter_dict,
               returns a list of procedureinstancessubset data model objects,
               if raw is True, the raw protobuf objects are returned.
               If namespace_uri is "default", the default namespace_uri is used.
        """
        if namespace_uri == "default":
            if self._default_namespace_uri is not None:
                namespace_uri = self._default_namespace_uri
            else:
                raise ValueError("No default namespace URI is given.")
        
        results_list = []
        if  procedureinstancessubset_id is not None:
            try:
                res =  await self.procedureinstancessubset_client.Retrieve(
                    lara_django_processes_pb2.ProcedureInstancesSubsetRetrieveRequest(procedureinstancessubset_id=procedureinstancessubset_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( processes_dm.ProcedureInstancesSubset(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving procedureinstancessubset_id: {e}")

        if filter_dict is None:
            filter_dict = {}

        if name is not None:
            filter_dict["name"] = name
        if namespace_uri is not None:
            filter_dict["namespace__uri"] = namespace_uri
        # if name_display is not None:
        #    filter_dict["name_display"] = name_display

        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.procedureinstancessubset_client.List(
                    lara_django_processes_pb2.ProcedureInstancesSubsetListRequest(), metadata=metadata
                    )
            if raw:
                    results_list += res.results
            else:
                # :TODO: a queue could be used here to speed up the retrieval
                results = res.results
                results_list += [ processes_dm.ProcedureInstancesSubset(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
        except Exception as e:
            logger.error(f"Error retrieving procedureinstancessubset name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          name: str = None,
                          # name_display: str = None,
                          namespace_uri : str = None,
                          filter_dict : dict = None,
                          iri: str = None,) -> str:
        """ retrieve the procedureinstancessubset_id for a given name,
               name_display or iri
        """

        results_list = await self.retrieve(name=name, 
                        namespace_uri=namespace_uri, filter_dict=filter_dict, raw=True)

        if len(results_list) == 1 :
            return results_list[0].procedureinstancessubset_id
        else:
            raise ValueError(f"Error retrieving procedureinstancessubset_id - no or too many results found.")
    
    async def get_by_id(self, procedureinstancessubset_id: str = None, id_only: bool = False) -> processes_dm.ProcedureInstancesSubset:
        """ retrieve a procedureinstancessubset data model by procedureinstancessubset_id """
        try:
            res = await self.procedureinstancessubset_client.Retrieve(
                lara_django_processes_pb2.ProcedureInstancesSubsetRetrieveRequest(procedureinstancessubset_id=procedureinstancessubset_id)
            )
            item = processes_dm.ProcedureInstancesSubset(**MessageToDict(res, preserving_proto_field_name=True))
            self.item_id = item.procedureinstancessubset_id
            return item
        except Exception as e:
            logger.error(f"Error retrieving procedureinstancessubset_id: {e}")
    
    async def get_by_name(self, name: str = None,
                                namespace_uri : str = None,
                                id_only: bool = False) -> processes_dm.ProcedureInstancesSubset | str:
        """ retrieve a procedureinstancessubset data model by name """
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            res = await self.procedureinstancessubset_client.RetrieveByNameNamespace(
                lara_django_processes_pb2.ProcedureInstancesSubsetRetrieveByNameNSRequest(name=name, namespace_uri=namespace_uri)
            )
            item = MessageToDict(res, preserving_proto_field_name=True)
            self.item_id = item["procedureinstancessubset_id"]
            if id_only:
                return self.item_id
            else:
                return processes_dm.ProcedureInstancesSubset(**item)
        except Exception as e:
            logger.error(f"Error retrieving procedureinstancessubset name: {e}")
   
    
    
    
    
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all procedureinstancessubsets """
        if filter_dict is None:
            res = await self.procedureinstancessubset_client.List(lara_django_processes_pb2.ProcedureInstancesSubsetListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.procedureinstancessubset_client.List(
                lara_django_processes_pb2.ProcedureInstancesSubsetListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.procedureinstancessubset_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all procedureinstancessubsets """
        if self.procedureinstancessubset_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.procedureinstancessubset_full_client.List(
                lara_django_processes_pb2.ProcedureInstancesSubsetFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.procedureinstancessubset_full_client.List(
                lara_django_processes_pb2.ProcedureInstancesSubsetFullListRequest(), metadata=metadata
            )
    
    @import_model_instance_from_file()
    async def update(self, procedureinstancessubset : processes_dm.ProcedureInstancesSubset = None) -> None:
        """ update a procedureinstancessubset model instance """
        try:
            res = await self.procedureinstancessubset_client.Update(
                lara_django_processes_pb2.ProcedureInstancesSubsetRequest(**procedureinstancessubset.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating procedureinstancessubset_id: {e}")
        else:
            return res
    
    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a procedureinstancessubset by procedureinstancessubset_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.procedureinstancessubset_client.Destroy(lara_django_processes_pb2.ProcedureInstancesSubsetDestroyRequest(procedureinstancessubset_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting procedureinstancessubset_id: {e}")

#_________________  OrderedProcedureInstancesSubset  ______________________


class OrderedProcedureInstancesSubsetInterface:
    def __init__(self, channel: grpc.Channel = None) -> None:
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.orderedprocedureinstancessubset_client = lara_django_processes_pb2_grpc.OrderedProcedureInstancesSubsetControllerStub(channel)
        
    
    @import_model_instance_from_file()
    async def create(self,  orderedprocedureinstancessubsets:  list[processes_dm.OrderedProcedureInstancesSubset] = None,  ids_only: bool = False) -> Union[list[str], list[processes_dm.OrderedProcedureInstancesSubset]]:
        try:
            create_coroutines = ( self.orderedprocedureinstancessubset_client.Create(lara_django_processes_pb2.OrderedProcedureInstancesSubsetRequest(**orderedprocedureinstancessubset.model_dump())) for orderedprocedureinstancessubset in orderedprocedureinstancessubsets )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.orderedprocedureinstancessubset_id for item in res]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating orderedprocedureinstancessubset: {e}")
        
    @export_model_instance_to_file
    async def retrieve(
        self,
        orderedprocedureinstancessubset_id: str = None,
        name: str = None,
        # name_display: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[processes_dm.OrderedProcedureInstancesSubset]:
        """ retrieve a list of orderedprocedureinstancessubset instances by orderedprocedureinstancessubset_id, name or filter_dict,
               returns a list of orderedprocedureinstancessubset data model objects,
               if raw is True, the raw protobuf objects are returned
        """
        results_list = []
        if  orderedprocedureinstancessubset_id is not None:
            try:
                res =  await self.orderedprocedureinstancessubset_client.Retrieve(
                    lara_django_processes_pb2.OrderedProcedureInstancesSubsetRetrieveRequest(orderedprocedureinstancessubset_id=orderedprocedureinstancessubset_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( processes_dm.OrderedProcedureInstancesSubset(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving orderedprocedureinstancessubset_id: {e}")

        if filter_dict is None:
            filter_dict = {}

        if name is not None:
            filter_dict["name"] = name
        # if name_display is not None:
        #    filter_dict["name_display"] = name_display

        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.orderedprocedureinstancessubset_client.List(
                    lara_django_processes_pb2.OrderedProcedureInstancesSubsetListRequest(), metadata=metadata
                    )
            if raw:
                    results_list += res.results
            else:
                # a queue could be used here to speed up the retrieval
                results = res.results
                results_list += [ processes_dm.OrderedProcedureInstancesSubset(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
        except Exception as e:
            logger.error(f"Error retrieving orderedprocedureinstancessubset name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          name: str = None,
                          # name_display: str = None,
                          filter_dict : dict = None,
                          iri: str = None,) -> str:
        """ retrieve the orderedprocedureinstancessubset_id for a given name,
               (name_display) or iri
        """
        
        results_list = await self.retrieve(name=name, filter_dict=filter_dict, raw=True)
        if len(results_list) == 1 :
            return results_list[0].orderedprocedureinstancessubset_id
        else:
            raise ValueError(f"Error retrieving orderedprocedureinstancessubset_id - no or too many results found.")
    
    async def get_by_id(self, orderedprocedureinstancessubset_id: str = None) -> processes_dm.OrderedProcedureInstancesSubset:
        """ retrieve a orderedprocedureinstancessubset data model by orderedprocedureinstancessubset_id """
        try:
            res = await self.orderedprocedureinstancessubset_client.Retrieve(
                lara_django_processes_pb2.OrderedProcedureInstancesSubsetRetrieveRequest(orderedprocedureinstancessubset_id=orderedprocedureinstancessubset_id)
            )
            return processes_dm.OrderedProcedureInstancesSubset(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving orderedprocedureinstancessubset_id: {e}")
    
    async def get_by_name(self, name: str = None, id_only: bool = False) -> processes_dm.OrderedProcedureInstancesSubset | str:
        """ retrieve a orderedprocedureinstancessubset data model by name """
        try:
            res = await self.orderedprocedureinstancessubset_client.RetrieveByNameNamespace(
                lara_django_processes_pb2.OrderedProcedureInstancesSubsetRetrieveByNameNSRequest(name=name, namespace_uri="")
            )
            if id_only:
                return MessageToDict(res, preserving_proto_field_name=True)["orderedprocedureinstancessubset_id"]
            else:
                return processes_dm.OrderedProcedureInstancesSubset(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving orderedprocedureinstancessubset name: {e}")
    
    
    
    
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all orderedprocedureinstancessubsets """
        if filter_dict is None:
            res = await self.orderedprocedureinstancessubset_client.List(lara_django_processes_pb2.OrderedProcedureInstancesSubsetListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.orderedprocedureinstancessubset_client.List(
                lara_django_processes_pb2.OrderedProcedureInstancesSubsetListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.orderedprocedureinstancessubset_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all orderedprocedureinstancessubsets """
        if self.orderedprocedureinstancessubset_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.orderedprocedureinstancessubset_full_client.List(
                lara_django_processes_pb2.OrderedProcedureInstancesSubsetFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.orderedprocedureinstancessubset_full_client.List(
                lara_django_processes_pb2.OrderedProcedureInstancesSubsetFullListRequest(), metadata=metadata
            )
    
    @import_model_instance_from_file()
    async def update(self, orderedprocedureinstancessubset : processes_dm.OrderedProcedureInstancesSubset = None) -> None:
        """ update a orderedprocedureinstancessubset model instance """
        try:
            res = await self.orderedprocedureinstancessubset_client.Update(
                lara_django_processes_pb2.OrderedProcedureInstancesSubsetRequest(**orderedprocedureinstancessubset.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating orderedprocedureinstancessubset_id: {e}")
        else:
            return res
    
    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a orderedprocedureinstancessubset by orderedprocedureinstancessubset_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.orderedprocedureinstancessubset_client.Destroy(lara_django_processes_pb2.OrderedProcedureInstancesSubsetDestroyRequest(orderedprocedureinstancessubset_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting orderedprocedureinstancessubset_id: {e}")

#_________________  ProcedureInstanceStepClass  ______________________


class ProcedureInstanceStepClassInterface:
    def __init__(self, channel: grpc.Channel = None) -> None:
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.procedureinstancestepclass_client = lara_django_processes_pb2_grpc.ProcedureInstanceStepClassControllerStub(channel)
        
    
    @import_model_instance_from_file()
    async def create(self,  procedureinstancestepclasses:  list[processes_dm.ProcedureInstanceStepClass] = None,  ids_only: bool = False) -> Union[list[str], list[processes_dm.ProcedureInstanceStepClass]]:
        try:
            create_coroutines = ( self.procedureinstancestepclass_client.Create(lara_django_processes_pb2.ProcedureInstanceStepClassRequest(**procedureinstancestepclass.model_dump())) for procedureinstancestepclass in procedureinstancestepclasses )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.procedureinstancestepclass_id for item in res]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating procedureinstancestepclass: {e}")
        
    @export_model_instance_to_file
    async def retrieve(
        self,
        procedureinstancestepclass_id: str = None,
        name: str = None,
        # name_display: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[processes_dm.ProcedureInstanceStepClass]:
        """ retrieve a list of procedureinstancestepclass instances by procedureinstancestepclass_id, name or filter_dict,
               returns a list of procedureinstancestepclass data model objects,
               if raw is True, the raw protobuf objects are returned
        """
        results_list = []
        if  procedureinstancestepclass_id is not None:
            try:
                res =  await self.procedureinstancestepclass_client.Retrieve(
                    lara_django_processes_pb2.ProcedureInstanceStepClassRetrieveRequest(procedureinstancestepclass_id=procedureinstancestepclass_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( processes_dm.ProcedureInstanceStepClass(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving procedureinstancestepclass_id: {e}")

        if filter_dict is None:
            filter_dict = {}

        if name is not None:
            filter_dict["name"] = name
        # if name_display is not None:
        #    filter_dict["name_display"] = name_display

        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.procedureinstancestepclass_client.List(
                    lara_django_processes_pb2.ProcedureInstanceStepClassListRequest(), metadata=metadata
                    )
            if raw:
                    results_list += res.results
            else:
                # a queue could be used here to speed up the retrieval
                results = res.results
                results_list += [ processes_dm.ProcedureInstanceStepClass(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
        except Exception as e:
            logger.error(f"Error retrieving procedureinstancestepclass name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          name: str = None,
                          # name_display: str = None,
                          filter_dict : dict = None,
                          iri: str = None,) -> str:
        """ retrieve the procedureinstancestepclass_id for a given name,
               (name_display) or iri
        """
        
        results_list = await self.retrieve(name=name, filter_dict=filter_dict, raw=True)
        if len(results_list) == 1 :
            return results_list[0].procedureinstancestepclass_id
        else:
            raise ValueError(f"Error retrieving procedureinstancestepclass_id - no or too many results found.")
    
    async def get_by_id(self, procedureinstancestepclass_id: str = None) -> processes_dm.ProcedureInstanceStepClass:
        """ retrieve a procedureinstancestepclass data model by procedureinstancestepclass_id """
        try:
            res = await self.procedureinstancestepclass_client.Retrieve(
                lara_django_processes_pb2.ProcedureInstanceStepClassRetrieveRequest(procedureinstancestepclass_id=procedureinstancestepclass_id)
            )
            return processes_dm.ProcedureInstanceStepClass(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving procedureinstancestepclass_id: {e}")
    
    async def get_by_name(self, name: str = None, id_only: bool = False) -> processes_dm.ProcedureInstanceStepClass | str:
        """ retrieve a procedureinstancestepclass data model by name """
        try:
            res = await self.procedureinstancestepclass_client.RetrieveByNameNamespace(
                lara_django_processes_pb2.ProcedureInstanceStepClassRetrieveByNameNSRequest(name=name, namespace_uri="")
            )
            if id_only:
                return MessageToDict(res, preserving_proto_field_name=True)["procedureinstancestepclass_id"]
            else:
                return processes_dm.ProcedureInstanceStepClass(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving procedureinstancestepclass name: {e}")
    
    
    
    
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all procedureinstancestepclasss """
        if filter_dict is None:
            res = await self.procedureinstancestepclass_client.List(lara_django_processes_pb2.ProcedureInstanceStepClassListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.procedureinstancestepclass_client.List(
                lara_django_processes_pb2.ProcedureInstanceStepClassListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.procedureinstancestepclass_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all procedureinstancestepclasss """
        if self.procedureinstancestepclass_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.procedureinstancestepclass_full_client.List(
                lara_django_processes_pb2.ProcedureInstanceStepClassFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.procedureinstancestepclass_full_client.List(
                lara_django_processes_pb2.ProcedureInstanceStepClassFullListRequest(), metadata=metadata
            )
    
    @import_model_instance_from_file()
    async def update(self, procedureinstancestepclass : processes_dm.ProcedureInstanceStepClass = None) -> None:
        """ update a procedureinstancestepclass model instance """
        try:
            res = await self.procedureinstancestepclass_client.Update(
                lara_django_processes_pb2.ProcedureInstanceStepClassRequest(**procedureinstancestepclass.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating procedureinstancestepclass_id: {e}")
        else:
            return res
    
    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a procedureinstancestepclass by procedureinstancestepclass_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.procedureinstancestepclass_client.Destroy(lara_django_processes_pb2.ProcedureInstanceStepClassDestroyRequest(procedureinstancestepclass_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting procedureinstancestepclass_id: {e}")

#_________________  ProcedureInstanceStep  ______________________


class ProcedureInstanceStepInterface:
    def __init__(self, channel: grpc.Channel = None) -> None:
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.procedureinstancestep_client = lara_django_processes_pb2_grpc.ProcedureInstanceStepControllerStub(channel)
        
    
    @import_model_instance_from_file()
    async def create(self,  procedureinstancesteps:  list[processes_dm.ProcedureInstanceStep] = None,  ids_only: bool = False) -> Union[list[str], list[processes_dm.ProcedureInstanceStep]]:
        try:
            create_coroutines = ( self.procedureinstancestep_client.Create(lara_django_processes_pb2.ProcedureInstanceStepRequest(**procedureinstancestep.model_dump())) for procedureinstancestep in procedureinstancesteps )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.procedureinstancestep_id for item in res]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating procedureinstancestep: {e}")
        
    @export_model_instance_to_file
    async def retrieve(
        self,
        procedureinstancestep_id: str = None,
        name: str = None,
        # name_display: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[processes_dm.ProcedureInstanceStep]:
        """ retrieve a list of procedureinstancestep instances by procedureinstancestep_id, name or filter_dict,
               returns a list of procedureinstancestep data model objects,
               if raw is True, the raw protobuf objects are returned
        """
        results_list = []
        if  procedureinstancestep_id is not None:
            try:
                res =  await self.procedureinstancestep_client.Retrieve(
                    lara_django_processes_pb2.ProcedureInstanceStepRetrieveRequest(procedureinstancestep_id=procedureinstancestep_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( processes_dm.ProcedureInstanceStep(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving procedureinstancestep_id: {e}")

        if filter_dict is None:
            filter_dict = {}

        if name is not None:
            filter_dict["name"] = name
        # if name_display is not None:
        #    filter_dict["name_display"] = name_display

        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.procedureinstancestep_client.List(
                    lara_django_processes_pb2.ProcedureInstanceStepListRequest(), metadata=metadata
                    )
            if raw:
                    results_list += res.results
            else:
                # a queue could be used here to speed up the retrieval
                results = res.results
                results_list += [ processes_dm.ProcedureInstanceStep(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
        except Exception as e:
            logger.error(f"Error retrieving procedureinstancestep name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          name: str = None,
                          # name_display: str = None,
                          filter_dict : dict = None,
                          iri: str = None,) -> str:
        """ retrieve the procedureinstancestep_id for a given name,
               (name_display) or iri
        """
        
        results_list = await self.retrieve(name=name, filter_dict=filter_dict, raw=True)
        if len(results_list) == 1 :
            return results_list[0].procedureinstancestep_id
        else:
            raise ValueError(f"Error retrieving procedureinstancestep_id - no or too many results found.")
    
    async def get_by_id(self, procedureinstancestep_id: str = None) -> processes_dm.ProcedureInstanceStep:
        """ retrieve a procedureinstancestep data model by procedureinstancestep_id """
        try:
            res = await self.procedureinstancestep_client.Retrieve(
                lara_django_processes_pb2.ProcedureInstanceStepRetrieveRequest(procedureinstancestep_id=procedureinstancestep_id)
            )
            return processes_dm.ProcedureInstanceStep(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving procedureinstancestep_id: {e}")
    
    async def get_by_name(self, name: str = None, id_only: bool = False) -> processes_dm.ProcedureInstanceStep | str:
        """ retrieve a procedureinstancestep data model by name """
        try:
            res = await self.procedureinstancestep_client.RetrieveByNameNamespace(
                lara_django_processes_pb2.ProcedureInstanceStepRetrieveByNameNSRequest(name=name, namespace_uri="")
            )
            if id_only:
                return MessageToDict(res, preserving_proto_field_name=True)["procedureinstancestep_id"]
            else:
                return processes_dm.ProcedureInstanceStep(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving procedureinstancestep name: {e}")
    
    
    
    
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all procedureinstancesteps """
        if filter_dict is None:
            res = await self.procedureinstancestep_client.List(lara_django_processes_pb2.ProcedureInstanceStepListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.procedureinstancestep_client.List(
                lara_django_processes_pb2.ProcedureInstanceStepListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.procedureinstancestep_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all procedureinstancesteps """
        if self.procedureinstancestep_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.procedureinstancestep_full_client.List(
                lara_django_processes_pb2.ProcedureInstanceStepFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.procedureinstancestep_full_client.List(
                lara_django_processes_pb2.ProcedureInstanceStepFullListRequest(), metadata=metadata
            )
    
    @import_model_instance_from_file()
    async def update(self, procedureinstancestep : processes_dm.ProcedureInstanceStep = None) -> None:
        """ update a procedureinstancestep model instance """
        try:
            res = await self.procedureinstancestep_client.Update(
                lara_django_processes_pb2.ProcedureInstanceStepRequest(**procedureinstancestep.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating procedureinstancestep_id: {e}")
        else:
            return res
    
    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a procedureinstancestep by procedureinstancestep_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.procedureinstancestep_client.Destroy(lara_django_processes_pb2.ProcedureInstanceStepDestroyRequest(procedureinstancestep_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting procedureinstancestep_id: {e}")

#_________________  ProcedureInstanceMoveStep  ______________________


class ProcedureInstanceMoveStepInterface:
    def __init__(self, channel: grpc.Channel = None) -> None:
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.procedureinstancemovestep_client = lara_django_processes_pb2_grpc.ProcedureInstanceMoveStepControllerStub(channel)
        
    
    @import_model_instance_from_file()
    async def create(self,  procedureinstancemovesteps:  list[processes_dm.ProcedureInstanceMoveStep] = None,  ids_only: bool = False) -> Union[list[str], list[processes_dm.ProcedureInstanceMoveStep]]:
        try:
            create_coroutines = ( self.procedureinstancemovestep_client.Create(lara_django_processes_pb2.ProcedureInstanceMoveStepRequest(**procedureinstancemovestep.model_dump())) for procedureinstancemovestep in procedureinstancemovesteps )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.procedureinstancemovestep_id for item in res]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating procedureinstancemovestep: {e}")
        
    @export_model_instance_to_file
    async def retrieve(
        self,
        procedureinstancemovestep_id: str = None,
        name: str = None,
        # name_display: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[processes_dm.ProcedureInstanceMoveStep]:
        """ retrieve a list of procedureinstancemovestep instances by procedureinstancemovestep_id, name or filter_dict,
               returns a list of procedureinstancemovestep data model objects,
               if raw is True, the raw protobuf objects are returned
        """
        results_list = []
        if  procedureinstancemovestep_id is not None:
            try:
                res =  await self.procedureinstancemovestep_client.Retrieve(
                    lara_django_processes_pb2.ProcedureInstanceMoveStepRetrieveRequest(procedureinstancemovestep_id=procedureinstancemovestep_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( processes_dm.ProcedureInstanceMoveStep(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving procedureinstancemovestep_id: {e}")

        if filter_dict is None:
            filter_dict = {}

        if name is not None:
            filter_dict["name"] = name
        # if name_display is not None:
        #    filter_dict["name_display"] = name_display

        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.procedureinstancemovestep_client.List(
                    lara_django_processes_pb2.ProcedureInstanceMoveStepListRequest(), metadata=metadata
                    )
            if raw:
                    results_list += res.results
            else:
                # a queue could be used here to speed up the retrieval
                results = res.results
                results_list += [ processes_dm.ProcedureInstanceMoveStep(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
        except Exception as e:
            logger.error(f"Error retrieving procedureinstancemovestep name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          name: str = None,
                          # name_display: str = None,
                          filter_dict : dict = None,
                          iri: str = None,) -> str:
        """ retrieve the procedureinstancemovestep_id for a given name,
               (name_display) or iri
        """
        
        results_list = await self.retrieve(name=name, filter_dict=filter_dict, raw=True)
        if len(results_list) == 1 :
            return results_list[0].procedureinstancemovestep_id
        else:
            raise ValueError(f"Error retrieving procedureinstancemovestep_id - no or too many results found.")
    
    async def get_by_id(self, procedureinstancemovestep_id: str = None) -> processes_dm.ProcedureInstanceMoveStep:
        """ retrieve a procedureinstancemovestep data model by procedureinstancemovestep_id """
        try:
            res = await self.procedureinstancemovestep_client.Retrieve(
                lara_django_processes_pb2.ProcedureInstanceMoveStepRetrieveRequest(procedureinstancemovestep_id=procedureinstancemovestep_id)
            )
            return processes_dm.ProcedureInstanceMoveStep(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving procedureinstancemovestep_id: {e}")
    
    async def get_by_name(self, name: str = None, id_only: bool = False) -> processes_dm.ProcedureInstanceMoveStep | str:
        """ retrieve a procedureinstancemovestep data model by name """
        try:
            res = await self.procedureinstancemovestep_client.RetrieveByNameNamespace(
                lara_django_processes_pb2.ProcedureInstanceMoveStepRetrieveByNameNSRequest(name=name, namespace_uri="")
            )
            if id_only:
                return MessageToDict(res, preserving_proto_field_name=True)["procedureinstancemovestep_id"]
            else:
                return processes_dm.ProcedureInstanceMoveStep(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving procedureinstancemovestep name: {e}")
    
    
    
    
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all procedureinstancemovesteps """
        if filter_dict is None:
            res = await self.procedureinstancemovestep_client.List(lara_django_processes_pb2.ProcedureInstanceMoveStepListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.procedureinstancemovestep_client.List(
                lara_django_processes_pb2.ProcedureInstanceMoveStepListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.procedureinstancemovestep_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all procedureinstancemovesteps """
        if self.procedureinstancemovestep_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.procedureinstancemovestep_full_client.List(
                lara_django_processes_pb2.ProcedureInstanceMoveStepFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.procedureinstancemovestep_full_client.List(
                lara_django_processes_pb2.ProcedureInstanceMoveStepFullListRequest(), metadata=metadata
            )
    
    @import_model_instance_from_file()
    async def update(self, procedureinstancemovestep : processes_dm.ProcedureInstanceMoveStep = None) -> None:
        """ update a procedureinstancemovestep model instance """
        try:
            res = await self.procedureinstancemovestep_client.Update(
                lara_django_processes_pb2.ProcedureInstanceMoveStepRequest(**procedureinstancemovestep.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating procedureinstancemovestep_id: {e}")
        else:
            return res
    
    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a procedureinstancemovestep by procedureinstancemovestep_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.procedureinstancemovestep_client.Destroy(lara_django_processes_pb2.ProcedureInstanceMoveStepDestroyRequest(procedureinstancemovestep_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting procedureinstancemovestep_id: {e}")

#_________________  ProcessInstance  ______________________


class ProcessInstanceInterface:
    def __init__(self, channel: grpc.Channel = None, 
                       default_namespace_uri : str = None,
                       default_namespace_id : str = None,
                       namespace_if = None ) -> None:
        self._default_namespace_uri = default_namespace_uri
        self._default_namespace_id = default_namespace_id

        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.namespace_if = namespace_if if namespace_if is not None else base_if.NamespaceInterface(channel)

        # self.processinstance_class_client = (
        #     lara_django_processes_pb2_grpc.ProcessInstanceclassByIRIControllerStub(channel)
        # )

        self.processinstance_client = lara_django_processes_pb2_grpc.ProcessInstanceControllerStub(channel)
        
        self.item_id = None
        self.update_item_id = "processinstance_id"
        self.stub = self.processinstance_client

        self.file_download_info = lara_django_processes_pb2.FileDownloadInfo
        self.file_upload_chunk = lara_django_processes_pb2.FileUploadChunk


        # self.processinstance_full_client = lara_django_processes_pb2_grpc.ProcessInstanceFullControllerStub(
        #     channel
        # )

    @property
    def default_namespace_uri(self):
        return self._default_namespace_uri

    @property
    def default_namespace_id(self):
        return self._default_namespace_id

    @classmethod
    async def build_if(cls, channel: grpc.Channel = None, default_namespace_uri: str = None):
    
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel
    
        namespace_if = base_if.NamespaceInterface(channel)
        try:
            default_namespace_id = await namespace_if.retrieve_id(namespace_uri=default_namespace_uri)
        except Exception as e:
            logger.error(f"Error retrieving namespace_id: {e}")
        
        return cls(channel=channel, default_namespace_uri=default_namespace_uri,  
                   default_namespace_id=default_namespace_id, namespace_if=namespace_if)
    
    async def set_default_namespace_uri(self, namespace_uri: str = None):
        if namespace_uri is not None:
            self._default_namespace_uri = namespace_uri.strip()
        try:
            self._default_namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logger.error(f"Error retrieving namespace_id: {e}")
    
    @import_model_instance_from_file()
    @upload_file  # needed for file upload
    async def create(self,  processinstances:  list[processes_dm.ProcessInstance] = None,  
                            ids_only: bool = False,
                            namespace_uri: str = None) -> Union[list[str], list[processes_dm.ProcessInstance]]:
        """ create a list of processinstance instances,
               returns a list of processinstance data model objects or ids_only

        :param processinstances: list of processinstance data model objects
        :param ids_only: return only the ids of the created instances
        :return: list of processinstance data model objects or ids_only
        """
        processinstanceclass_id = None

        namespace_id = None
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
            namespace_id = self._default_namespace_id
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        if namespace_id is None:
            try:
                namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
            except Exception as e:
                logger.error(f"Error retrieving namespace_id: {e}")

        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if processinstance_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.processinstance_class_client.Retrieve(
        #         lara_django_processes_pb2.ProcessInstanceclassRetrieveRequest(iri=processinstance_class_iri)
        #     )
        #     processinstanceclass_id = res.processinstanceclass_id
        # except Exception as e:
        #     logger.error(f"Error retrieving processinstanceclass_id: {e}")
        for processinstance in processinstances:
            if processinstance.namespace == "" or processinstance.namespace == "default":
                    processinstance.namespace = namespace_id
            # processinstance.processinstance_class = processinstanceclass_id # uncomment if a model class is used
            if processinstance.process_json is not None:
                try:
                    processinstance_struct = Struct()
                    processinstance_json = processinstance.process_json
                    processinstance_struct.update(processinstance_json)
                    processinstance.process_json = processinstance_struct
                except Exception as e:
                    logger.error(f"Error updating process_json: {e}")

        try:
            create_coroutines = ( self.processinstance_client.Create(lara_django_processes_pb2.ProcessInstanceRequest(**processinstance.model_dump())) for processinstance in processinstances )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [ MessageToDict(item, preserving_proto_field_name=True).get("processinstance_id") for item in res ]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating processinstance: {e}")
        
    @export_model_instance_to_file
    async def retrieve(
        self,
        namespace_uri: str = None,
        processinstance_id: str = None,
        name: str = None,
        # name_display: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[processes_dm.ProcessInstance]:
        """ retrieve a list of processinstance instances by processinstance_id, name or filter_dict,
               returns a list of processinstance data model objects,
               if raw is True, the raw protobuf objects are returned.
               If namespace_uri is "default", the default namespace_uri is used.
        """
        if namespace_uri == "default":
            if self._default_namespace_uri is not None:
                namespace_uri = self._default_namespace_uri
            else:
                raise ValueError("No default namespace URI is given.")
        
        results_list = []
        if  processinstance_id is not None:
            try:
                res =  await self.processinstance_client.Retrieve(
                    lara_django_processes_pb2.ProcessInstanceRetrieveRequest(processinstance_id=processinstance_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( processes_dm.ProcessInstance(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving processinstance_id: {e}")

        if filter_dict is None:
            filter_dict = {}

        if name is not None:
            filter_dict["name"] = name
        if namespace_uri is not None:
            filter_dict["namespace__uri"] = namespace_uri
        # if name_display is not None:
        #    filter_dict["name_display"] = name_display

        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.processinstance_client.List(
                    lara_django_processes_pb2.ProcessInstanceListRequest(), metadata=metadata
                    )
            if raw:
                    results_list += res.results
            else:
                # :TODO: a queue could be used here to speed up the retrieval
                results = res.results
                results_list += [ processes_dm.ProcessInstance(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
        except Exception as e:
            logger.error(f"Error retrieving processinstance name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          name: str = None,
                          # name_display: str = None,
                          namespace_uri : str = None,
                          filter_dict : dict = None,
                          iri: str = None,) -> str:
        """ retrieve the processinstance_id for a given name,
               name_display or iri
        """

        results_list = await self.retrieve(name=name, 
                        namespace_uri=namespace_uri, filter_dict=filter_dict, raw=True)

        if len(results_list) == 1 :
            return results_list[0].processinstance_id
        else:
            raise ValueError(f"Error retrieving processinstance_id - no or too many results found.")
    
    @download_file  # needed for file download
    async def get_by_id(self, processinstance_id: str = None, id_only: bool = False) -> processes_dm.ProcessInstance:
        """ retrieve a processinstance data model by processinstance_id """
        try:
            res = await self.processinstance_client.Retrieve(
                lara_django_processes_pb2.ProcessInstanceRetrieveRequest(processinstance_id=processinstance_id)
            )
            item = processes_dm.ProcessInstance(**MessageToDict(res, preserving_proto_field_name=True))
            self.item_id = item.processinstance_id
            return item
        except Exception as e:
            logger.error(f"Error retrieving processinstance_id: {e}")
    
    @download_file  # needed for file download
    async def get_by_name(self, name: str = None,
                                namespace_uri : str = None,
                                id_only: bool = False) -> processes_dm.ProcessInstance | str:
        """ retrieve a processinstance data model by name """
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            res = await self.processinstance_client.RetrieveByNameNamespace(
                lara_django_processes_pb2.ProcessInstanceRetrieveByNameNSRequest(name=name, namespace_uri=namespace_uri)
            )
            item = MessageToDict(res, preserving_proto_field_name=True)
            self.item_id = item["processinstance_id"]
            if id_only:
                return self.item_id
            else:
                return processes_dm.ProcessInstance(**item)
        except Exception as e:
            logger.error(f"Error retrieving processinstance name: {e}")
   
    
    @download_file  # needed for file download
    async def get_file(self, processinstance_id : str = None, id_only : bool = True ) -> bytes | None:
        """ retrieve a file by data_id """
        self.item_id = processinstance_id
        
    
    async def get_file_by_name(self, name: str = None,
                                namespace_uri : str = None,
                                filename_target : str = None,
                                as_byte_str : bool = None ) -> bytes | None:
        """ retrieve a file by name """
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
            # logger.warning(f"no namespace_uri provided, using default namespace: {namespace_uri}")
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            processinstance_id = await self.get_by_name(name=name, namespace_uri=namespace_uri, id_only=True)
            return await self.get_file(processinstance_id=processinstance_id, filename_target=filename_target, as_byte_str=as_byte_str, get_file=True)
        except Exception as e:
            logger.error(f"Error retrieving processinstance name: {e}")
        
    
    
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all processinstances """
        if filter_dict is None:
            res = await self.processinstance_client.List(lara_django_processes_pb2.ProcessInstanceListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.processinstance_client.List(
                lara_django_processes_pb2.ProcessInstanceListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.processinstance_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all processinstances """
        if self.processinstance_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.processinstance_full_client.List(
                lara_django_processes_pb2.ProcessInstanceFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.processinstance_full_client.List(
                lara_django_processes_pb2.ProcessInstanceFullListRequest(), metadata=metadata
            )
    
    @import_model_instance_from_file()
    @update_file  # needed for file update
    async def update(self, processinstance : processes_dm.ProcessInstance = None) -> None:
        """ update a processinstance model instance """
        try:
            res = await self.processinstance_client.Update(
                lara_django_processes_pb2.ProcessInstanceRequest(**processinstance.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating processinstance_id: {e}")
        else:
            return res
    
    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a processinstance by processinstance_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.processinstance_client.Destroy(lara_django_processes_pb2.ProcessInstanceDestroyRequest(processinstance_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting processinstance_id: {e}")

#_________________  OrderedProcedureInstances  ______________________


class OrderedProcedureInstancesInterface:
    def __init__(self, channel: grpc.Channel = None) -> None:
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.orderedprocedureinstances_client = lara_django_processes_pb2_grpc.OrderedProcedureInstancesControllerStub(channel)
        
    
    @import_model_instance_from_file()
    async def create(self,  orderedprocedureinstancess:  list[processes_dm.OrderedProcedureInstances] = None,  ids_only: bool = False) -> Union[list[str], list[processes_dm.OrderedProcedureInstances]]:
        try:
            create_coroutines = ( self.orderedprocedureinstances_client.Create(lara_django_processes_pb2.OrderedProcedureInstancesRequest(**orderedprocedureinstances.model_dump())) for orderedprocedureinstances in orderedprocedureinstancess )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.orderedprocedureinstances_id for item in res]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating orderedprocedureinstances: {e}")
        
    @export_model_instance_to_file
    async def retrieve(
        self,
        orderedprocedureinstances_id: str = None,
        name: str = None,
        # name_display: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[processes_dm.OrderedProcedureInstances]:
        """ retrieve a list of orderedprocedureinstances instances by orderedprocedureinstances_id, name or filter_dict,
               returns a list of orderedprocedureinstances data model objects,
               if raw is True, the raw protobuf objects are returned
        """
        results_list = []
        if  orderedprocedureinstances_id is not None:
            try:
                res =  await self.orderedprocedureinstances_client.Retrieve(
                    lara_django_processes_pb2.OrderedProcedureInstancesRetrieveRequest(orderedprocedureinstances_id=orderedprocedureinstances_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( processes_dm.OrderedProcedureInstances(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving orderedprocedureinstances_id: {e}")

        if filter_dict is None:
            filter_dict = {}

        if name is not None:
            filter_dict["name"] = name
        # if name_display is not None:
        #    filter_dict["name_display"] = name_display

        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.orderedprocedureinstances_client.List(
                    lara_django_processes_pb2.OrderedProcedureInstancesListRequest(), metadata=metadata
                    )
            if raw:
                    results_list += res.results
            else:
                # a queue could be used here to speed up the retrieval
                results = res.results
                results_list += [ processes_dm.OrderedProcedureInstances(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
        except Exception as e:
            logger.error(f"Error retrieving orderedprocedureinstances name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          name: str = None,
                          # name_display: str = None,
                          filter_dict : dict = None,
                          iri: str = None,) -> str:
        """ retrieve the orderedprocedureinstances_id for a given name,
               (name_display) or iri
        """
        
        results_list = await self.retrieve(name=name, filter_dict=filter_dict, raw=True)
        if len(results_list) == 1 :
            return results_list[0].orderedprocedureinstances_id
        else:
            raise ValueError(f"Error retrieving orderedprocedureinstances_id - no or too many results found.")
    
    async def get_by_id(self, orderedprocedureinstances_id: str = None) -> processes_dm.OrderedProcedureInstances:
        """ retrieve a orderedprocedureinstances data model by orderedprocedureinstances_id """
        try:
            res = await self.orderedprocedureinstances_client.Retrieve(
                lara_django_processes_pb2.OrderedProcedureInstancesRetrieveRequest(orderedprocedureinstances_id=orderedprocedureinstances_id)
            )
            return processes_dm.OrderedProcedureInstances(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving orderedprocedureinstances_id: {e}")
    
    async def get_by_name(self, name: str = None, id_only: bool = False) -> processes_dm.OrderedProcedureInstances | str:
        """ retrieve a orderedprocedureinstances data model by name """
        try:
            res = await self.orderedprocedureinstances_client.RetrieveByNameNamespace(
                lara_django_processes_pb2.OrderedProcedureInstancesRetrieveByNameNSRequest(name=name, namespace_uri="")
            )
            if id_only:
                return MessageToDict(res, preserving_proto_field_name=True)["orderedprocedureinstances_id"]
            else:
                return processes_dm.OrderedProcedureInstances(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving orderedprocedureinstances name: {e}")
    
    
    
    
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all orderedprocedureinstancess """
        if filter_dict is None:
            res = await self.orderedprocedureinstances_client.List(lara_django_processes_pb2.OrderedProcedureInstancesListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.orderedprocedureinstances_client.List(
                lara_django_processes_pb2.OrderedProcedureInstancesListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.orderedprocedureinstances_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all orderedprocedureinstancess """
        if self.orderedprocedureinstances_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.orderedprocedureinstances_full_client.List(
                lara_django_processes_pb2.OrderedProcedureInstancesFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.orderedprocedureinstances_full_client.List(
                lara_django_processes_pb2.OrderedProcedureInstancesFullListRequest(), metadata=metadata
            )
    
    @import_model_instance_from_file()
    async def update(self, orderedprocedureinstances : processes_dm.OrderedProcedureInstances = None) -> None:
        """ update a orderedprocedureinstances model instance """
        try:
            res = await self.orderedprocedureinstances_client.Update(
                lara_django_processes_pb2.OrderedProcedureInstancesRequest(**orderedprocedureinstances.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating orderedprocedureinstances_id: {e}")
        else:
            return res
    
    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a orderedprocedureinstances by orderedprocedureinstances_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.orderedprocedureinstances_client.Destroy(lara_django_processes_pb2.OrderedProcedureInstancesDestroyRequest(orderedprocedureinstances_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting orderedprocedureinstances_id: {e}")

#_________________  ProcessInstancesSubset  ______________________


class ProcessInstancesSubsetInterface:
    def __init__(self, channel: grpc.Channel = None, 
                       default_namespace_uri : str = None,
                       default_namespace_id : str = None,
                       namespace_if = None ) -> None:
        self._default_namespace_uri = default_namespace_uri
        self._default_namespace_id = default_namespace_id

        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.namespace_if = namespace_if if namespace_if is not None else base_if.NamespaceInterface(channel)

        # self.processinstancessubset_class_client = (
        #     lara_django_processes_pb2_grpc.ProcessInstancesSubsetclassByIRIControllerStub(channel)
        # )

        self.processinstancessubset_client = lara_django_processes_pb2_grpc.ProcessInstancesSubsetControllerStub(channel)
        

        # self.processinstancessubset_full_client = lara_django_processes_pb2_grpc.ProcessInstancesSubsetFullControllerStub(
        #     channel
        # )

    @property
    def default_namespace_uri(self):
        return self._default_namespace_uri

    @property
    def default_namespace_id(self):
        return self._default_namespace_id

    @classmethod
    async def build_if(cls, channel: grpc.Channel = None, default_namespace_uri: str = None):
    
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel
    
        namespace_if = base_if.NamespaceInterface(channel)
        try:
            default_namespace_id = await namespace_if.retrieve_id(namespace_uri=default_namespace_uri)
        except Exception as e:
            logger.error(f"Error retrieving namespace_id: {e}")
        
        return cls(channel=channel, default_namespace_uri=default_namespace_uri,  
                   default_namespace_id=default_namespace_id, namespace_if=namespace_if)
    
    async def set_default_namespace_uri(self, namespace_uri: str = None):
        if namespace_uri is not None:
            self._default_namespace_uri = namespace_uri.strip()
        try:
            self._default_namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logger.error(f"Error retrieving namespace_id: {e}")
    
    @import_model_instance_from_file()
    async def create(self,  processinstancessubsets:  list[processes_dm.ProcessInstancesSubset] = None,  
                            ids_only: bool = False,
                            namespace_uri: str = None) -> Union[list[str], list[processes_dm.ProcessInstancesSubset]]:
        """ create a list of processinstancessubset instances,
               returns a list of processinstancessubset data model objects or ids_only

        :param processinstancessubsets: list of processinstancessubset data model objects
        :param ids_only: return only the ids of the created instances
        :return: list of processinstancessubset data model objects or ids_only
        """
        processinstancessubsetclass_id = None

        namespace_id = None
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
            namespace_id = self._default_namespace_id
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        if namespace_id is None:
            try:
                namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
            except Exception as e:
                logger.error(f"Error retrieving namespace_id: {e}")

        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if processinstancessubset_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.processinstancessubset_class_client.Retrieve(
        #         lara_django_processes_pb2.ProcessInstancesSubsetclassRetrieveRequest(iri=processinstancessubset_class_iri)
        #     )
        #     processinstancessubsetclass_id = res.processinstancessubsetclass_id
        # except Exception as e:
        #     logger.error(f"Error retrieving processinstancessubsetclass_id: {e}")
        for processinstancessubset in processinstancessubsets:
            if processinstancessubset.namespace == "" or processinstancessubset.namespace == "default":
                    processinstancessubset.namespace = namespace_id
            # processinstancessubset.processinstancessubset_class = processinstancessubsetclass_id # uncomment if a model class is used

        try:
            create_coroutines = ( self.processinstancessubset_client.Create(lara_django_processes_pb2.ProcessInstancesSubsetRequest(**processinstancessubset.model_dump())) for processinstancessubset in processinstancessubsets )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [ MessageToDict(item, preserving_proto_field_name=True).get("processinstancessubset_id") for item in res ]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating processinstancessubset: {e}")
        
    @export_model_instance_to_file
    async def retrieve(
        self,
        namespace_uri: str = None,
        processinstancessubset_id: str = None,
        name: str = None,
        # name_display: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[processes_dm.ProcessInstancesSubset]:
        """ retrieve a list of processinstancessubset instances by processinstancessubset_id, name or filter_dict,
               returns a list of processinstancessubset data model objects,
               if raw is True, the raw protobuf objects are returned.
               If namespace_uri is "default", the default namespace_uri is used.
        """
        if namespace_uri == "default":
            if self._default_namespace_uri is not None:
                namespace_uri = self._default_namespace_uri
            else:
                raise ValueError("No default namespace URI is given.")
        
        results_list = []
        if  processinstancessubset_id is not None:
            try:
                res =  await self.processinstancessubset_client.Retrieve(
                    lara_django_processes_pb2.ProcessInstancesSubsetRetrieveRequest(processinstancessubset_id=processinstancessubset_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( processes_dm.ProcessInstancesSubset(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving processinstancessubset_id: {e}")

        if filter_dict is None:
            filter_dict = {}

        if name is not None:
            filter_dict["name"] = name
        if namespace_uri is not None:
            filter_dict["namespace__uri"] = namespace_uri
        # if name_display is not None:
        #    filter_dict["name_display"] = name_display

        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.processinstancessubset_client.List(
                    lara_django_processes_pb2.ProcessInstancesSubsetListRequest(), metadata=metadata
                    )
            if raw:
                    results_list += res.results
            else:
                # :TODO: a queue could be used here to speed up the retrieval
                results = res.results
                results_list += [ processes_dm.ProcessInstancesSubset(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
        except Exception as e:
            logger.error(f"Error retrieving processinstancessubset name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          name: str = None,
                          # name_display: str = None,
                          namespace_uri : str = None,
                          filter_dict : dict = None,
                          iri: str = None,) -> str:
        """ retrieve the processinstancessubset_id for a given name,
               name_display or iri
        """

        results_list = await self.retrieve(name=name, 
                        namespace_uri=namespace_uri, filter_dict=filter_dict, raw=True)

        if len(results_list) == 1 :
            return results_list[0].processinstancessubset_id
        else:
            raise ValueError(f"Error retrieving processinstancessubset_id - no or too many results found.")
    
    async def get_by_id(self, processinstancessubset_id: str = None, id_only: bool = False) -> processes_dm.ProcessInstancesSubset:
        """ retrieve a processinstancessubset data model by processinstancessubset_id """
        try:
            res = await self.processinstancessubset_client.Retrieve(
                lara_django_processes_pb2.ProcessInstancesSubsetRetrieveRequest(processinstancessubset_id=processinstancessubset_id)
            )
            item = processes_dm.ProcessInstancesSubset(**MessageToDict(res, preserving_proto_field_name=True))
            self.item_id = item.processinstancessubset_id
            return item
        except Exception as e:
            logger.error(f"Error retrieving processinstancessubset_id: {e}")
    
    async def get_by_name(self, name: str = None,
                                namespace_uri : str = None,
                                id_only: bool = False) -> processes_dm.ProcessInstancesSubset | str:
        """ retrieve a processinstancessubset data model by name """
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            res = await self.processinstancessubset_client.RetrieveByNameNamespace(
                lara_django_processes_pb2.ProcessInstancesSubsetRetrieveByNameNSRequest(name=name, namespace_uri=namespace_uri)
            )
            item = MessageToDict(res, preserving_proto_field_name=True)
            self.item_id = item["processinstancessubset_id"]
            if id_only:
                return self.item_id
            else:
                return processes_dm.ProcessInstancesSubset(**item)
        except Exception as e:
            logger.error(f"Error retrieving processinstancessubset name: {e}")
   
    
    
    
    
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all processinstancessubsets """
        if filter_dict is None:
            res = await self.processinstancessubset_client.List(lara_django_processes_pb2.ProcessInstancesSubsetListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.processinstancessubset_client.List(
                lara_django_processes_pb2.ProcessInstancesSubsetListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.processinstancessubset_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all processinstancessubsets """
        if self.processinstancessubset_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.processinstancessubset_full_client.List(
                lara_django_processes_pb2.ProcessInstancesSubsetFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.processinstancessubset_full_client.List(
                lara_django_processes_pb2.ProcessInstancesSubsetFullListRequest(), metadata=metadata
            )
    
    @import_model_instance_from_file()
    async def update(self, processinstancessubset : processes_dm.ProcessInstancesSubset = None) -> None:
        """ update a processinstancessubset model instance """
        try:
            res = await self.processinstancessubset_client.Update(
                lara_django_processes_pb2.ProcessInstancesSubsetRequest(**processinstancessubset.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating processinstancessubset_id: {e}")
        else:
            return res
    
    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a processinstancessubset by processinstancessubset_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.processinstancessubset_client.Destroy(lara_django_processes_pb2.ProcessInstancesSubsetDestroyRequest(processinstancessubset_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting processinstancessubset_id: {e}")

#_________________  OrderedProcessInstancesSubset  ______________________


class OrderedProcessInstancesSubsetInterface:
    def __init__(self, channel: grpc.Channel = None) -> None:
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.orderedprocessinstancessubset_client = lara_django_processes_pb2_grpc.OrderedProcessInstancesSubsetControllerStub(channel)
        
    
    @import_model_instance_from_file()
    async def create(self,  orderedprocessinstancessubsets:  list[processes_dm.OrderedProcessInstancesSubset] = None,  ids_only: bool = False) -> Union[list[str], list[processes_dm.OrderedProcessInstancesSubset]]:
        try:
            create_coroutines = ( self.orderedprocessinstancessubset_client.Create(lara_django_processes_pb2.OrderedProcessInstancesSubsetRequest(**orderedprocessinstancessubset.model_dump())) for orderedprocessinstancessubset in orderedprocessinstancessubsets )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.orderedprocessinstancessubset_id for item in res]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating orderedprocessinstancessubset: {e}")
        
    @export_model_instance_to_file
    async def retrieve(
        self,
        orderedprocessinstancessubset_id: str = None,
        name: str = None,
        # name_display: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[processes_dm.OrderedProcessInstancesSubset]:
        """ retrieve a list of orderedprocessinstancessubset instances by orderedprocessinstancessubset_id, name or filter_dict,
               returns a list of orderedprocessinstancessubset data model objects,
               if raw is True, the raw protobuf objects are returned
        """
        results_list = []
        if  orderedprocessinstancessubset_id is not None:
            try:
                res =  await self.orderedprocessinstancessubset_client.Retrieve(
                    lara_django_processes_pb2.OrderedProcessInstancesSubsetRetrieveRequest(orderedprocessinstancessubset_id=orderedprocessinstancessubset_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( processes_dm.OrderedProcessInstancesSubset(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving orderedprocessinstancessubset_id: {e}")

        if filter_dict is None:
            filter_dict = {}

        if name is not None:
            filter_dict["name"] = name
        # if name_display is not None:
        #    filter_dict["name_display"] = name_display

        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.orderedprocessinstancessubset_client.List(
                    lara_django_processes_pb2.OrderedProcessInstancesSubsetListRequest(), metadata=metadata
                    )
            if raw:
                    results_list += res.results
            else:
                # a queue could be used here to speed up the retrieval
                results = res.results
                results_list += [ processes_dm.OrderedProcessInstancesSubset(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
        except Exception as e:
            logger.error(f"Error retrieving orderedprocessinstancessubset name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          name: str = None,
                          # name_display: str = None,
                          filter_dict : dict = None,
                          iri: str = None,) -> str:
        """ retrieve the orderedprocessinstancessubset_id for a given name,
               (name_display) or iri
        """
        
        results_list = await self.retrieve(name=name, filter_dict=filter_dict, raw=True)
        if len(results_list) == 1 :
            return results_list[0].orderedprocessinstancessubset_id
        else:
            raise ValueError(f"Error retrieving orderedprocessinstancessubset_id - no or too many results found.")
    
    async def get_by_id(self, orderedprocessinstancessubset_id: str = None) -> processes_dm.OrderedProcessInstancesSubset:
        """ retrieve a orderedprocessinstancessubset data model by orderedprocessinstancessubset_id """
        try:
            res = await self.orderedprocessinstancessubset_client.Retrieve(
                lara_django_processes_pb2.OrderedProcessInstancesSubsetRetrieveRequest(orderedprocessinstancessubset_id=orderedprocessinstancessubset_id)
            )
            return processes_dm.OrderedProcessInstancesSubset(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving orderedprocessinstancessubset_id: {e}")
    
    async def get_by_name(self, name: str = None, id_only: bool = False) -> processes_dm.OrderedProcessInstancesSubset | str:
        """ retrieve a orderedprocessinstancessubset data model by name """
        try:
            res = await self.orderedprocessinstancessubset_client.RetrieveByNameNamespace(
                lara_django_processes_pb2.OrderedProcessInstancesSubsetRetrieveByNameNSRequest(name=name, namespace_uri="")
            )
            if id_only:
                return MessageToDict(res, preserving_proto_field_name=True)["orderedprocessinstancessubset_id"]
            else:
                return processes_dm.OrderedProcessInstancesSubset(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving orderedprocessinstancessubset name: {e}")
    
    
    
    
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all orderedprocessinstancessubsets """
        if filter_dict is None:
            res = await self.orderedprocessinstancessubset_client.List(lara_django_processes_pb2.OrderedProcessInstancesSubsetListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.orderedprocessinstancessubset_client.List(
                lara_django_processes_pb2.OrderedProcessInstancesSubsetListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.orderedprocessinstancessubset_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all orderedprocessinstancessubsets """
        if self.orderedprocessinstancessubset_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.orderedprocessinstancessubset_full_client.List(
                lara_django_processes_pb2.OrderedProcessInstancesSubsetFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.orderedprocessinstancessubset_full_client.List(
                lara_django_processes_pb2.OrderedProcessInstancesSubsetFullListRequest(), metadata=metadata
            )
    
    @import_model_instance_from_file()
    async def update(self, orderedprocessinstancessubset : processes_dm.OrderedProcessInstancesSubset = None) -> None:
        """ update a orderedprocessinstancessubset model instance """
        try:
            res = await self.orderedprocessinstancessubset_client.Update(
                lara_django_processes_pb2.OrderedProcessInstancesSubsetRequest(**orderedprocessinstancessubset.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating orderedprocessinstancessubset_id: {e}")
        else:
            return res
    
    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a orderedprocessinstancessubset by orderedprocessinstancessubset_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.orderedprocessinstancessubset_client.Destroy(lara_django_processes_pb2.OrderedProcessInstancesSubsetDestroyRequest(orderedprocessinstancessubset_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting orderedprocessinstancessubset_id: {e}")

