from google.protobuf import empty_pb2 as _empty_pb2
from google.protobuf import struct_pb2 as _struct_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class ExtraDataDestroyRequest(_message.Message):
    __slots__ = ("extradata_id",)
    EXTRADATA_ID_FIELD_NUMBER: _ClassVar[int]
    extradata_id: str
    def __init__(self, extradata_id: _Optional[str] = ...) -> None: ...

class ExtraDataListRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class ExtraDataListResponse(_message.Message):
    __slots__ = ("results",)
    RESULTS_FIELD_NUMBER: _ClassVar[int]
    results: _containers.RepeatedCompositeFieldContainer[ExtraDataResponse]
    def __init__(self, results: _Optional[_Iterable[_Union[ExtraDataResponse, _Mapping]]] = ...) -> None: ...

class ExtraDataPartialUpdateRequest(_message.Message):
    __slots__ = ("extradata_id", "data_type", "namespace", "media_type", "_partial_update_fields", "name_display", "name", "name_full", "version", "hash_sha256", "data_json", "iri", "url", "datetime_created", "datetime_last_modified", "description", "search_vector", "image", "file")
    EXTRADATA_ID_FIELD_NUMBER: _ClassVar[int]
    DATA_TYPE_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    MEDIA_TYPE_FIELD_NUMBER: _ClassVar[int]
    _PARTIAL_UPDATE_FIELDS_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    NAME_FULL_FIELD_NUMBER: _ClassVar[int]
    VERSION_FIELD_NUMBER: _ClassVar[int]
    HASH_SHA256_FIELD_NUMBER: _ClassVar[int]
    DATA_JSON_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    URL_FIELD_NUMBER: _ClassVar[int]
    DATETIME_CREATED_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    IMAGE_FIELD_NUMBER: _ClassVar[int]
    FILE_FIELD_NUMBER: _ClassVar[int]
    extradata_id: str
    data_type: str
    namespace: str
    media_type: str
    _partial_update_fields: _containers.RepeatedScalarFieldContainer[str]
    name_display: str
    name: str
    name_full: str
    version: str
    hash_sha256: str
    data_json: _struct_pb2.Struct
    iri: str
    url: str
    datetime_created: str
    datetime_last_modified: str
    description: str
    search_vector: str
    image: str
    file: str
    def __init__(self, extradata_id: _Optional[str] = ..., data_type: _Optional[str] = ..., namespace: _Optional[str] = ..., media_type: _Optional[str] = ..., _partial_update_fields: _Optional[_Iterable[str]] = ..., name_display: _Optional[str] = ..., name: _Optional[str] = ..., name_full: _Optional[str] = ..., version: _Optional[str] = ..., hash_sha256: _Optional[str] = ..., data_json: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., iri: _Optional[str] = ..., url: _Optional[str] = ..., datetime_created: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., description: _Optional[str] = ..., search_vector: _Optional[str] = ..., image: _Optional[str] = ..., file: _Optional[str] = ...) -> None: ...

class ExtraDataRequest(_message.Message):
    __slots__ = ("extradata_id", "data_type", "namespace", "media_type", "name_display", "name", "name_full", "version", "hash_sha256", "data_json", "iri", "url", "datetime_created", "datetime_last_modified", "description", "search_vector", "image", "file")
    EXTRADATA_ID_FIELD_NUMBER: _ClassVar[int]
    DATA_TYPE_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    MEDIA_TYPE_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    NAME_FULL_FIELD_NUMBER: _ClassVar[int]
    VERSION_FIELD_NUMBER: _ClassVar[int]
    HASH_SHA256_FIELD_NUMBER: _ClassVar[int]
    DATA_JSON_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    URL_FIELD_NUMBER: _ClassVar[int]
    DATETIME_CREATED_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    IMAGE_FIELD_NUMBER: _ClassVar[int]
    FILE_FIELD_NUMBER: _ClassVar[int]
    extradata_id: str
    data_type: str
    namespace: str
    media_type: str
    name_display: str
    name: str
    name_full: str
    version: str
    hash_sha256: str
    data_json: _struct_pb2.Struct
    iri: str
    url: str
    datetime_created: str
    datetime_last_modified: str
    description: str
    search_vector: str
    image: str
    file: str
    def __init__(self, extradata_id: _Optional[str] = ..., data_type: _Optional[str] = ..., namespace: _Optional[str] = ..., media_type: _Optional[str] = ..., name_display: _Optional[str] = ..., name: _Optional[str] = ..., name_full: _Optional[str] = ..., version: _Optional[str] = ..., hash_sha256: _Optional[str] = ..., data_json: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., iri: _Optional[str] = ..., url: _Optional[str] = ..., datetime_created: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., description: _Optional[str] = ..., search_vector: _Optional[str] = ..., image: _Optional[str] = ..., file: _Optional[str] = ...) -> None: ...

class ExtraDataResponse(_message.Message):
    __slots__ = ("extradata_id", "data_type", "namespace", "media_type", "name_display", "name", "name_full", "version", "hash_sha256", "data_json", "iri", "url", "datetime_created", "datetime_last_modified", "description", "search_vector", "image", "file")
    EXTRADATA_ID_FIELD_NUMBER: _ClassVar[int]
    DATA_TYPE_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    MEDIA_TYPE_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    NAME_FULL_FIELD_NUMBER: _ClassVar[int]
    VERSION_FIELD_NUMBER: _ClassVar[int]
    HASH_SHA256_FIELD_NUMBER: _ClassVar[int]
    DATA_JSON_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    URL_FIELD_NUMBER: _ClassVar[int]
    DATETIME_CREATED_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    IMAGE_FIELD_NUMBER: _ClassVar[int]
    FILE_FIELD_NUMBER: _ClassVar[int]
    extradata_id: str
    data_type: str
    namespace: str
    media_type: str
    name_display: str
    name: str
    name_full: str
    version: str
    hash_sha256: str
    data_json: _struct_pb2.Struct
    iri: str
    url: str
    datetime_created: str
    datetime_last_modified: str
    description: str
    search_vector: str
    image: str
    file: str
    def __init__(self, extradata_id: _Optional[str] = ..., data_type: _Optional[str] = ..., namespace: _Optional[str] = ..., media_type: _Optional[str] = ..., name_display: _Optional[str] = ..., name: _Optional[str] = ..., name_full: _Optional[str] = ..., version: _Optional[str] = ..., hash_sha256: _Optional[str] = ..., data_json: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., iri: _Optional[str] = ..., url: _Optional[str] = ..., datetime_created: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., description: _Optional[str] = ..., search_vector: _Optional[str] = ..., image: _Optional[str] = ..., file: _Optional[str] = ...) -> None: ...

class ExtraDataRetrieveByNameNSRequest(_message.Message):
    __slots__ = ("name", "namespace_uri")
    NAME_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_URI_FIELD_NUMBER: _ClassVar[int]
    name: str
    namespace_uri: str
    def __init__(self, name: _Optional[str] = ..., namespace_uri: _Optional[str] = ...) -> None: ...

class ExtraDataRetrieveRequest(_message.Message):
    __slots__ = ("extradata_id",)
    EXTRADATA_ID_FIELD_NUMBER: _ClassVar[int]
    extradata_id: str
    def __init__(self, extradata_id: _Optional[str] = ...) -> None: ...

class ExtraDataStreamRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class FileDownloadChunk(_message.Message):
    __slots__ = ("filename", "data", "success")
    FILENAME_FIELD_NUMBER: _ClassVar[int]
    DATA_FIELD_NUMBER: _ClassVar[int]
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    filename: str
    data: bytes
    success: bool
    def __init__(self, filename: _Optional[str] = ..., data: _Optional[bytes] = ..., success: bool = ...) -> None: ...

class FileDownloadInfo(_message.Message):
    __slots__ = ("item_id", "chunk_size")
    ITEM_ID_FIELD_NUMBER: _ClassVar[int]
    CHUNK_SIZE_FIELD_NUMBER: _ClassVar[int]
    item_id: str
    chunk_size: int
    def __init__(self, item_id: _Optional[str] = ..., chunk_size: _Optional[int] = ...) -> None: ...

class FileUploadChunk(_message.Message):
    __slots__ = ("filename", "update_item_id", "data")
    FILENAME_FIELD_NUMBER: _ClassVar[int]
    UPDATE_ITEM_ID_FIELD_NUMBER: _ClassVar[int]
    DATA_FIELD_NUMBER: _ClassVar[int]
    filename: str
    update_item_id: str
    data: bytes
    def __init__(self, filename: _Optional[str] = ..., update_item_id: _Optional[str] = ..., data: _Optional[bytes] = ...) -> None: ...

class FileUploadInfo(_message.Message):
    __slots__ = ("success",)
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    success: bool
    def __init__(self, success: bool = ...) -> None: ...

class ImageDownloadChunk(_message.Message):
    __slots__ = ("filename_image", "data", "success")
    FILENAME_IMAGE_FIELD_NUMBER: _ClassVar[int]
    DATA_FIELD_NUMBER: _ClassVar[int]
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    filename_image: str
    data: bytes
    success: bool
    def __init__(self, filename_image: _Optional[str] = ..., data: _Optional[bytes] = ..., success: bool = ...) -> None: ...

class ImageDownloadInfo(_message.Message):
    __slots__ = ("item_id", "chunk_size")
    ITEM_ID_FIELD_NUMBER: _ClassVar[int]
    CHUNK_SIZE_FIELD_NUMBER: _ClassVar[int]
    item_id: str
    chunk_size: int
    def __init__(self, item_id: _Optional[str] = ..., chunk_size: _Optional[int] = ...) -> None: ...

class ImageUploadChunk(_message.Message):
    __slots__ = ("filename", "update_item_id", "data")
    FILENAME_FIELD_NUMBER: _ClassVar[int]
    UPDATE_ITEM_ID_FIELD_NUMBER: _ClassVar[int]
    DATA_FIELD_NUMBER: _ClassVar[int]
    filename: str
    update_item_id: str
    data: bytes
    def __init__(self, filename: _Optional[str] = ..., update_item_id: _Optional[str] = ..., data: _Optional[bytes] = ...) -> None: ...

class ImageUploadInfo(_message.Message):
    __slots__ = ("success",)
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    success: bool
    def __init__(self, success: bool = ...) -> None: ...

class MethodClassDestroyRequest(_message.Message):
    __slots__ = ("procmethodclass_id",)
    PROCMETHODCLASS_ID_FIELD_NUMBER: _ClassVar[int]
    procmethodclass_id: str
    def __init__(self, procmethodclass_id: _Optional[str] = ...) -> None: ...

class MethodClassListRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class MethodClassListResponse(_message.Message):
    __slots__ = ("results",)
    RESULTS_FIELD_NUMBER: _ClassVar[int]
    results: _containers.RepeatedCompositeFieldContainer[MethodClassResponse]
    def __init__(self, results: _Optional[_Iterable[_Union[MethodClassResponse, _Mapping]]] = ...) -> None: ...

class MethodClassPartialUpdateRequest(_message.Message):
    __slots__ = ("procmethodclass_id", "_partial_update_fields", "name", "iri", "proc_method_schema", "description", "tags")
    PROCMETHODCLASS_ID_FIELD_NUMBER: _ClassVar[int]
    _PARTIAL_UPDATE_FIELDS_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    PROC_METHOD_SCHEMA_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    procmethodclass_id: str
    _partial_update_fields: _containers.RepeatedScalarFieldContainer[str]
    name: str
    iri: str
    proc_method_schema: _struct_pb2.Struct
    description: str
    tags: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, procmethodclass_id: _Optional[str] = ..., _partial_update_fields: _Optional[_Iterable[str]] = ..., name: _Optional[str] = ..., iri: _Optional[str] = ..., proc_method_schema: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., description: _Optional[str] = ..., tags: _Optional[_Iterable[str]] = ...) -> None: ...

class MethodClassRequest(_message.Message):
    __slots__ = ("procmethodclass_id", "name", "iri", "proc_method_schema", "description", "tags")
    PROCMETHODCLASS_ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    PROC_METHOD_SCHEMA_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    procmethodclass_id: str
    name: str
    iri: str
    proc_method_schema: _struct_pb2.Struct
    description: str
    tags: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, procmethodclass_id: _Optional[str] = ..., name: _Optional[str] = ..., iri: _Optional[str] = ..., proc_method_schema: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., description: _Optional[str] = ..., tags: _Optional[_Iterable[str]] = ...) -> None: ...

class MethodClassResponse(_message.Message):
    __slots__ = ("procmethodclass_id", "name", "iri", "proc_method_schema", "description", "tags")
    PROCMETHODCLASS_ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    PROC_METHOD_SCHEMA_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    procmethodclass_id: str
    name: str
    iri: str
    proc_method_schema: _struct_pb2.Struct
    description: str
    tags: _containers.RepeatedScalarFieldContainer[str]
    def __init__(self, procmethodclass_id: _Optional[str] = ..., name: _Optional[str] = ..., iri: _Optional[str] = ..., proc_method_schema: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., description: _Optional[str] = ..., tags: _Optional[_Iterable[str]] = ...) -> None: ...

class MethodClassRetrieveRequest(_message.Message):
    __slots__ = ("procmethodclass_id",)
    PROCMETHODCLASS_ID_FIELD_NUMBER: _ClassVar[int]
    procmethodclass_id: str
    def __init__(self, procmethodclass_id: _Optional[str] = ...) -> None: ...

class MethodClassStreamRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class MethodDestroyRequest(_message.Message):
    __slots__ = ("method_id",)
    METHOD_ID_FIELD_NUMBER: _ClassVar[int]
    method_id: str
    def __init__(self, method_id: _Optional[str] = ...) -> None: ...

class MethodInstanceDestroyRequest(_message.Message):
    __slots__ = ("methodinstance_id",)
    METHODINSTANCE_ID_FIELD_NUMBER: _ClassVar[int]
    methodinstance_id: str
    def __init__(self, methodinstance_id: _Optional[str] = ...) -> None: ...

class MethodInstanceListRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class MethodInstanceListResponse(_message.Message):
    __slots__ = ("results",)
    RESULTS_FIELD_NUMBER: _ClassVar[int]
    results: _containers.RepeatedCompositeFieldContainer[MethodInstanceResponse]
    def __init__(self, results: _Optional[_Iterable[_Union[MethodInstanceResponse, _Mapping]]] = ...) -> None: ...

class MethodInstancePartialUpdateRequest(_message.Message):
    __slots__ = ("methodinstance_id", "namespace", "method_base", "status", "media_type", "substance_instances", "polymer_instances", "mixture_instances", "part_instances", "device_instances", "device_setup_instances", "labware_instances", "organism_instances", "samples", "sample_sets", "creators", "resources_external", "data_extra", "tags", "_partial_update_fields", "name_display", "name", "uri", "datetime_start", "datetime_end", "datetime_last_modified", "parameters", "version", "icon", "description", "remarks", "iri", "pid", "search_vector", "method_json")
    METHODINSTANCE_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    METHOD_BASE_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    MEDIA_TYPE_FIELD_NUMBER: _ClassVar[int]
    SUBSTANCE_INSTANCES_FIELD_NUMBER: _ClassVar[int]
    POLYMER_INSTANCES_FIELD_NUMBER: _ClassVar[int]
    MIXTURE_INSTANCES_FIELD_NUMBER: _ClassVar[int]
    PART_INSTANCES_FIELD_NUMBER: _ClassVar[int]
    DEVICE_INSTANCES_FIELD_NUMBER: _ClassVar[int]
    DEVICE_SETUP_INSTANCES_FIELD_NUMBER: _ClassVar[int]
    LABWARE_INSTANCES_FIELD_NUMBER: _ClassVar[int]
    ORGANISM_INSTANCES_FIELD_NUMBER: _ClassVar[int]
    SAMPLES_FIELD_NUMBER: _ClassVar[int]
    SAMPLE_SETS_FIELD_NUMBER: _ClassVar[int]
    CREATORS_FIELD_NUMBER: _ClassVar[int]
    RESOURCES_EXTERNAL_FIELD_NUMBER: _ClassVar[int]
    DATA_EXTRA_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    _PARTIAL_UPDATE_FIELDS_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    URI_FIELD_NUMBER: _ClassVar[int]
    DATETIME_START_FIELD_NUMBER: _ClassVar[int]
    DATETIME_END_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    PARAMETERS_FIELD_NUMBER: _ClassVar[int]
    VERSION_FIELD_NUMBER: _ClassVar[int]
    ICON_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    REMARKS_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    PID_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    METHOD_JSON_FIELD_NUMBER: _ClassVar[int]
    methodinstance_id: str
    namespace: str
    method_base: str
    status: str
    media_type: str
    substance_instances: _containers.RepeatedScalarFieldContainer[str]
    polymer_instances: _containers.RepeatedScalarFieldContainer[str]
    mixture_instances: _containers.RepeatedScalarFieldContainer[str]
    part_instances: _containers.RepeatedScalarFieldContainer[str]
    device_instances: _containers.RepeatedScalarFieldContainer[str]
    device_setup_instances: _containers.RepeatedScalarFieldContainer[str]
    labware_instances: _containers.RepeatedScalarFieldContainer[str]
    organism_instances: _containers.RepeatedScalarFieldContainer[str]
    samples: _containers.RepeatedScalarFieldContainer[str]
    sample_sets: _containers.RepeatedScalarFieldContainer[str]
    creators: _containers.RepeatedScalarFieldContainer[str]
    resources_external: _containers.RepeatedScalarFieldContainer[str]
    data_extra: _containers.RepeatedScalarFieldContainer[str]
    tags: _containers.RepeatedScalarFieldContainer[str]
    _partial_update_fields: _containers.RepeatedScalarFieldContainer[str]
    name_display: str
    name: str
    uri: str
    datetime_start: str
    datetime_end: str
    datetime_last_modified: str
    parameters: _struct_pb2.Struct
    version: str
    icon: str
    description: str
    remarks: str
    iri: str
    pid: str
    search_vector: str
    method_json: _struct_pb2.Struct
    def __init__(self, methodinstance_id: _Optional[str] = ..., namespace: _Optional[str] = ..., method_base: _Optional[str] = ..., status: _Optional[str] = ..., media_type: _Optional[str] = ..., substance_instances: _Optional[_Iterable[str]] = ..., polymer_instances: _Optional[_Iterable[str]] = ..., mixture_instances: _Optional[_Iterable[str]] = ..., part_instances: _Optional[_Iterable[str]] = ..., device_instances: _Optional[_Iterable[str]] = ..., device_setup_instances: _Optional[_Iterable[str]] = ..., labware_instances: _Optional[_Iterable[str]] = ..., organism_instances: _Optional[_Iterable[str]] = ..., samples: _Optional[_Iterable[str]] = ..., sample_sets: _Optional[_Iterable[str]] = ..., creators: _Optional[_Iterable[str]] = ..., resources_external: _Optional[_Iterable[str]] = ..., data_extra: _Optional[_Iterable[str]] = ..., tags: _Optional[_Iterable[str]] = ..., _partial_update_fields: _Optional[_Iterable[str]] = ..., name_display: _Optional[str] = ..., name: _Optional[str] = ..., uri: _Optional[str] = ..., datetime_start: _Optional[str] = ..., datetime_end: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., parameters: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., version: _Optional[str] = ..., icon: _Optional[str] = ..., description: _Optional[str] = ..., remarks: _Optional[str] = ..., iri: _Optional[str] = ..., pid: _Optional[str] = ..., search_vector: _Optional[str] = ..., method_json: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ...) -> None: ...

class MethodInstanceRequest(_message.Message):
    __slots__ = ("methodinstance_id", "namespace", "method_base", "status", "media_type", "substance_instances", "polymer_instances", "mixture_instances", "part_instances", "device_instances", "device_setup_instances", "labware_instances", "organism_instances", "samples", "sample_sets", "creators", "resources_external", "data_extra", "tags", "name_display", "name", "uri", "datetime_start", "datetime_end", "datetime_last_modified", "parameters", "version", "icon", "description", "remarks", "iri", "pid", "search_vector", "method_json")
    METHODINSTANCE_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    METHOD_BASE_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    MEDIA_TYPE_FIELD_NUMBER: _ClassVar[int]
    SUBSTANCE_INSTANCES_FIELD_NUMBER: _ClassVar[int]
    POLYMER_INSTANCES_FIELD_NUMBER: _ClassVar[int]
    MIXTURE_INSTANCES_FIELD_NUMBER: _ClassVar[int]
    PART_INSTANCES_FIELD_NUMBER: _ClassVar[int]
    DEVICE_INSTANCES_FIELD_NUMBER: _ClassVar[int]
    DEVICE_SETUP_INSTANCES_FIELD_NUMBER: _ClassVar[int]
    LABWARE_INSTANCES_FIELD_NUMBER: _ClassVar[int]
    ORGANISM_INSTANCES_FIELD_NUMBER: _ClassVar[int]
    SAMPLES_FIELD_NUMBER: _ClassVar[int]
    SAMPLE_SETS_FIELD_NUMBER: _ClassVar[int]
    CREATORS_FIELD_NUMBER: _ClassVar[int]
    RESOURCES_EXTERNAL_FIELD_NUMBER: _ClassVar[int]
    DATA_EXTRA_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    URI_FIELD_NUMBER: _ClassVar[int]
    DATETIME_START_FIELD_NUMBER: _ClassVar[int]
    DATETIME_END_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    PARAMETERS_FIELD_NUMBER: _ClassVar[int]
    VERSION_FIELD_NUMBER: _ClassVar[int]
    ICON_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    REMARKS_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    PID_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    METHOD_JSON_FIELD_NUMBER: _ClassVar[int]
    methodinstance_id: str
    namespace: str
    method_base: str
    status: str
    media_type: str
    substance_instances: _containers.RepeatedScalarFieldContainer[str]
    polymer_instances: _containers.RepeatedScalarFieldContainer[str]
    mixture_instances: _containers.RepeatedScalarFieldContainer[str]
    part_instances: _containers.RepeatedScalarFieldContainer[str]
    device_instances: _containers.RepeatedScalarFieldContainer[str]
    device_setup_instances: _containers.RepeatedScalarFieldContainer[str]
    labware_instances: _containers.RepeatedScalarFieldContainer[str]
    organism_instances: _containers.RepeatedScalarFieldContainer[str]
    samples: _containers.RepeatedScalarFieldContainer[str]
    sample_sets: _containers.RepeatedScalarFieldContainer[str]
    creators: _containers.RepeatedScalarFieldContainer[str]
    resources_external: _containers.RepeatedScalarFieldContainer[str]
    data_extra: _containers.RepeatedScalarFieldContainer[str]
    tags: _containers.RepeatedScalarFieldContainer[str]
    name_display: str
    name: str
    uri: str
    datetime_start: str
    datetime_end: str
    datetime_last_modified: str
    parameters: _struct_pb2.Struct
    version: str
    icon: str
    description: str
    remarks: str
    iri: str
    pid: str
    search_vector: str
    method_json: _struct_pb2.Struct
    def __init__(self, methodinstance_id: _Optional[str] = ..., namespace: _Optional[str] = ..., method_base: _Optional[str] = ..., status: _Optional[str] = ..., media_type: _Optional[str] = ..., substance_instances: _Optional[_Iterable[str]] = ..., polymer_instances: _Optional[_Iterable[str]] = ..., mixture_instances: _Optional[_Iterable[str]] = ..., part_instances: _Optional[_Iterable[str]] = ..., device_instances: _Optional[_Iterable[str]] = ..., device_setup_instances: _Optional[_Iterable[str]] = ..., labware_instances: _Optional[_Iterable[str]] = ..., organism_instances: _Optional[_Iterable[str]] = ..., samples: _Optional[_Iterable[str]] = ..., sample_sets: _Optional[_Iterable[str]] = ..., creators: _Optional[_Iterable[str]] = ..., resources_external: _Optional[_Iterable[str]] = ..., data_extra: _Optional[_Iterable[str]] = ..., tags: _Optional[_Iterable[str]] = ..., name_display: _Optional[str] = ..., name: _Optional[str] = ..., uri: _Optional[str] = ..., datetime_start: _Optional[str] = ..., datetime_end: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., parameters: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., version: _Optional[str] = ..., icon: _Optional[str] = ..., description: _Optional[str] = ..., remarks: _Optional[str] = ..., iri: _Optional[str] = ..., pid: _Optional[str] = ..., search_vector: _Optional[str] = ..., method_json: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ...) -> None: ...

class MethodInstanceResponse(_message.Message):
    __slots__ = ("methodinstance_id", "namespace", "method_base", "status", "media_type", "substance_instances", "polymer_instances", "mixture_instances", "part_instances", "device_instances", "device_setup_instances", "labware_instances", "organism_instances", "samples", "sample_sets", "creators", "resources_external", "data_extra", "tags", "name_display", "name", "uri", "datetime_start", "datetime_end", "datetime_last_modified", "parameters", "version", "icon", "description", "remarks", "iri", "pid", "search_vector", "method_json")
    METHODINSTANCE_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    METHOD_BASE_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    MEDIA_TYPE_FIELD_NUMBER: _ClassVar[int]
    SUBSTANCE_INSTANCES_FIELD_NUMBER: _ClassVar[int]
    POLYMER_INSTANCES_FIELD_NUMBER: _ClassVar[int]
    MIXTURE_INSTANCES_FIELD_NUMBER: _ClassVar[int]
    PART_INSTANCES_FIELD_NUMBER: _ClassVar[int]
    DEVICE_INSTANCES_FIELD_NUMBER: _ClassVar[int]
    DEVICE_SETUP_INSTANCES_FIELD_NUMBER: _ClassVar[int]
    LABWARE_INSTANCES_FIELD_NUMBER: _ClassVar[int]
    ORGANISM_INSTANCES_FIELD_NUMBER: _ClassVar[int]
    SAMPLES_FIELD_NUMBER: _ClassVar[int]
    SAMPLE_SETS_FIELD_NUMBER: _ClassVar[int]
    CREATORS_FIELD_NUMBER: _ClassVar[int]
    RESOURCES_EXTERNAL_FIELD_NUMBER: _ClassVar[int]
    DATA_EXTRA_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    URI_FIELD_NUMBER: _ClassVar[int]
    DATETIME_START_FIELD_NUMBER: _ClassVar[int]
    DATETIME_END_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    PARAMETERS_FIELD_NUMBER: _ClassVar[int]
    VERSION_FIELD_NUMBER: _ClassVar[int]
    ICON_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    REMARKS_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    PID_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    METHOD_JSON_FIELD_NUMBER: _ClassVar[int]
    methodinstance_id: str
    namespace: str
    method_base: str
    status: str
    media_type: str
    substance_instances: _containers.RepeatedScalarFieldContainer[str]
    polymer_instances: _containers.RepeatedScalarFieldContainer[str]
    mixture_instances: _containers.RepeatedScalarFieldContainer[str]
    part_instances: _containers.RepeatedScalarFieldContainer[str]
    device_instances: _containers.RepeatedScalarFieldContainer[str]
    device_setup_instances: _containers.RepeatedScalarFieldContainer[str]
    labware_instances: _containers.RepeatedScalarFieldContainer[str]
    organism_instances: _containers.RepeatedScalarFieldContainer[str]
    samples: _containers.RepeatedScalarFieldContainer[str]
    sample_sets: _containers.RepeatedScalarFieldContainer[str]
    creators: _containers.RepeatedScalarFieldContainer[str]
    resources_external: _containers.RepeatedScalarFieldContainer[str]
    data_extra: _containers.RepeatedScalarFieldContainer[str]
    tags: _containers.RepeatedScalarFieldContainer[str]
    name_display: str
    name: str
    uri: str
    datetime_start: str
    datetime_end: str
    datetime_last_modified: str
    parameters: _struct_pb2.Struct
    version: str
    icon: str
    description: str
    remarks: str
    iri: str
    pid: str
    search_vector: str
    method_json: _struct_pb2.Struct
    def __init__(self, methodinstance_id: _Optional[str] = ..., namespace: _Optional[str] = ..., method_base: _Optional[str] = ..., status: _Optional[str] = ..., media_type: _Optional[str] = ..., substance_instances: _Optional[_Iterable[str]] = ..., polymer_instances: _Optional[_Iterable[str]] = ..., mixture_instances: _Optional[_Iterable[str]] = ..., part_instances: _Optional[_Iterable[str]] = ..., device_instances: _Optional[_Iterable[str]] = ..., device_setup_instances: _Optional[_Iterable[str]] = ..., labware_instances: _Optional[_Iterable[str]] = ..., organism_instances: _Optional[_Iterable[str]] = ..., samples: _Optional[_Iterable[str]] = ..., sample_sets: _Optional[_Iterable[str]] = ..., creators: _Optional[_Iterable[str]] = ..., resources_external: _Optional[_Iterable[str]] = ..., data_extra: _Optional[_Iterable[str]] = ..., tags: _Optional[_Iterable[str]] = ..., name_display: _Optional[str] = ..., name: _Optional[str] = ..., uri: _Optional[str] = ..., datetime_start: _Optional[str] = ..., datetime_end: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., parameters: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., version: _Optional[str] = ..., icon: _Optional[str] = ..., description: _Optional[str] = ..., remarks: _Optional[str] = ..., iri: _Optional[str] = ..., pid: _Optional[str] = ..., search_vector: _Optional[str] = ..., method_json: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ...) -> None: ...

class MethodInstanceRetrieveByNameNSRequest(_message.Message):
    __slots__ = ("name", "namespace_uri")
    NAME_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_URI_FIELD_NUMBER: _ClassVar[int]
    name: str
    namespace_uri: str
    def __init__(self, name: _Optional[str] = ..., namespace_uri: _Optional[str] = ...) -> None: ...

class MethodInstanceRetrieveRequest(_message.Message):
    __slots__ = ("methodinstance_id",)
    METHODINSTANCE_ID_FIELD_NUMBER: _ClassVar[int]
    methodinstance_id: str
    def __init__(self, methodinstance_id: _Optional[str] = ...) -> None: ...

class MethodInstanceStreamRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class MethodListRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class MethodListResponse(_message.Message):
    __slots__ = ("results",)
    RESULTS_FIELD_NUMBER: _ClassVar[int]
    results: _containers.RepeatedCompositeFieldContainer[MethodResponse]
    def __init__(self, results: _Optional[_Iterable[_Union[MethodResponse, _Mapping]]] = ...) -> None: ...

class MethodPartialUpdateRequest(_message.Message):
    __slots__ = ("method_id", "namespace", "substances", "polymers", "mixtures", "parts", "devices", "device_setups", "labware", "organisms", "samples", "sample_sets", "creators", "resources_external", "data_extra", "tags", "method_class", "_partial_update_fields", "name_display", "name", "uri", "iri", "pid", "pac_id", "version", "datetime_last_modified", "parameters", "parameters_schema", "icon", "description", "remarks", "search_vector", "method_json", "media_type")
    METHOD_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    SUBSTANCES_FIELD_NUMBER: _ClassVar[int]
    POLYMERS_FIELD_NUMBER: _ClassVar[int]
    MIXTURES_FIELD_NUMBER: _ClassVar[int]
    PARTS_FIELD_NUMBER: _ClassVar[int]
    DEVICES_FIELD_NUMBER: _ClassVar[int]
    DEVICE_SETUPS_FIELD_NUMBER: _ClassVar[int]
    LABWARE_FIELD_NUMBER: _ClassVar[int]
    ORGANISMS_FIELD_NUMBER: _ClassVar[int]
    SAMPLES_FIELD_NUMBER: _ClassVar[int]
    SAMPLE_SETS_FIELD_NUMBER: _ClassVar[int]
    CREATORS_FIELD_NUMBER: _ClassVar[int]
    RESOURCES_EXTERNAL_FIELD_NUMBER: _ClassVar[int]
    DATA_EXTRA_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    METHOD_CLASS_FIELD_NUMBER: _ClassVar[int]
    _PARTIAL_UPDATE_FIELDS_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    URI_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    PID_FIELD_NUMBER: _ClassVar[int]
    PAC_ID_FIELD_NUMBER: _ClassVar[int]
    VERSION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    PARAMETERS_FIELD_NUMBER: _ClassVar[int]
    PARAMETERS_SCHEMA_FIELD_NUMBER: _ClassVar[int]
    ICON_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    REMARKS_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    METHOD_JSON_FIELD_NUMBER: _ClassVar[int]
    MEDIA_TYPE_FIELD_NUMBER: _ClassVar[int]
    method_id: str
    namespace: str
    substances: _containers.RepeatedScalarFieldContainer[str]
    polymers: _containers.RepeatedScalarFieldContainer[str]
    mixtures: _containers.RepeatedScalarFieldContainer[str]
    parts: _containers.RepeatedScalarFieldContainer[str]
    devices: _containers.RepeatedScalarFieldContainer[str]
    device_setups: _containers.RepeatedScalarFieldContainer[str]
    labware: _containers.RepeatedScalarFieldContainer[str]
    organisms: _containers.RepeatedScalarFieldContainer[str]
    samples: _containers.RepeatedScalarFieldContainer[str]
    sample_sets: _containers.RepeatedScalarFieldContainer[str]
    creators: _containers.RepeatedScalarFieldContainer[str]
    resources_external: _containers.RepeatedScalarFieldContainer[str]
    data_extra: _containers.RepeatedScalarFieldContainer[str]
    tags: _containers.RepeatedScalarFieldContainer[str]
    method_class: str
    _partial_update_fields: _containers.RepeatedScalarFieldContainer[str]
    name_display: str
    name: str
    uri: str
    iri: str
    pid: str
    pac_id: str
    version: str
    datetime_last_modified: str
    parameters: _struct_pb2.Struct
    parameters_schema: _struct_pb2.Struct
    icon: str
    description: str
    remarks: str
    search_vector: str
    method_json: _struct_pb2.Struct
    media_type: str
    def __init__(self, method_id: _Optional[str] = ..., namespace: _Optional[str] = ..., substances: _Optional[_Iterable[str]] = ..., polymers: _Optional[_Iterable[str]] = ..., mixtures: _Optional[_Iterable[str]] = ..., parts: _Optional[_Iterable[str]] = ..., devices: _Optional[_Iterable[str]] = ..., device_setups: _Optional[_Iterable[str]] = ..., labware: _Optional[_Iterable[str]] = ..., organisms: _Optional[_Iterable[str]] = ..., samples: _Optional[_Iterable[str]] = ..., sample_sets: _Optional[_Iterable[str]] = ..., creators: _Optional[_Iterable[str]] = ..., resources_external: _Optional[_Iterable[str]] = ..., data_extra: _Optional[_Iterable[str]] = ..., tags: _Optional[_Iterable[str]] = ..., method_class: _Optional[str] = ..., _partial_update_fields: _Optional[_Iterable[str]] = ..., name_display: _Optional[str] = ..., name: _Optional[str] = ..., uri: _Optional[str] = ..., iri: _Optional[str] = ..., pid: _Optional[str] = ..., pac_id: _Optional[str] = ..., version: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., parameters: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., parameters_schema: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., icon: _Optional[str] = ..., description: _Optional[str] = ..., remarks: _Optional[str] = ..., search_vector: _Optional[str] = ..., method_json: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., media_type: _Optional[str] = ...) -> None: ...

class MethodRequest(_message.Message):
    __slots__ = ("method_id", "namespace", "substances", "polymers", "mixtures", "parts", "devices", "device_setups", "labware", "organisms", "samples", "sample_sets", "creators", "resources_external", "data_extra", "tags", "method_class", "name_display", "name", "uri", "iri", "pid", "pac_id", "version", "datetime_last_modified", "parameters", "parameters_schema", "icon", "description", "remarks", "search_vector", "method_json", "media_type")
    METHOD_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    SUBSTANCES_FIELD_NUMBER: _ClassVar[int]
    POLYMERS_FIELD_NUMBER: _ClassVar[int]
    MIXTURES_FIELD_NUMBER: _ClassVar[int]
    PARTS_FIELD_NUMBER: _ClassVar[int]
    DEVICES_FIELD_NUMBER: _ClassVar[int]
    DEVICE_SETUPS_FIELD_NUMBER: _ClassVar[int]
    LABWARE_FIELD_NUMBER: _ClassVar[int]
    ORGANISMS_FIELD_NUMBER: _ClassVar[int]
    SAMPLES_FIELD_NUMBER: _ClassVar[int]
    SAMPLE_SETS_FIELD_NUMBER: _ClassVar[int]
    CREATORS_FIELD_NUMBER: _ClassVar[int]
    RESOURCES_EXTERNAL_FIELD_NUMBER: _ClassVar[int]
    DATA_EXTRA_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    METHOD_CLASS_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    URI_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    PID_FIELD_NUMBER: _ClassVar[int]
    PAC_ID_FIELD_NUMBER: _ClassVar[int]
    VERSION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    PARAMETERS_FIELD_NUMBER: _ClassVar[int]
    PARAMETERS_SCHEMA_FIELD_NUMBER: _ClassVar[int]
    ICON_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    REMARKS_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    METHOD_JSON_FIELD_NUMBER: _ClassVar[int]
    MEDIA_TYPE_FIELD_NUMBER: _ClassVar[int]
    method_id: str
    namespace: str
    substances: _containers.RepeatedScalarFieldContainer[str]
    polymers: _containers.RepeatedScalarFieldContainer[str]
    mixtures: _containers.RepeatedScalarFieldContainer[str]
    parts: _containers.RepeatedScalarFieldContainer[str]
    devices: _containers.RepeatedScalarFieldContainer[str]
    device_setups: _containers.RepeatedScalarFieldContainer[str]
    labware: _containers.RepeatedScalarFieldContainer[str]
    organisms: _containers.RepeatedScalarFieldContainer[str]
    samples: _containers.RepeatedScalarFieldContainer[str]
    sample_sets: _containers.RepeatedScalarFieldContainer[str]
    creators: _containers.RepeatedScalarFieldContainer[str]
    resources_external: _containers.RepeatedScalarFieldContainer[str]
    data_extra: _containers.RepeatedScalarFieldContainer[str]
    tags: _containers.RepeatedScalarFieldContainer[str]
    method_class: str
    name_display: str
    name: str
    uri: str
    iri: str
    pid: str
    pac_id: str
    version: str
    datetime_last_modified: str
    parameters: _struct_pb2.Struct
    parameters_schema: _struct_pb2.Struct
    icon: str
    description: str
    remarks: str
    search_vector: str
    method_json: _struct_pb2.Struct
    media_type: str
    def __init__(self, method_id: _Optional[str] = ..., namespace: _Optional[str] = ..., substances: _Optional[_Iterable[str]] = ..., polymers: _Optional[_Iterable[str]] = ..., mixtures: _Optional[_Iterable[str]] = ..., parts: _Optional[_Iterable[str]] = ..., devices: _Optional[_Iterable[str]] = ..., device_setups: _Optional[_Iterable[str]] = ..., labware: _Optional[_Iterable[str]] = ..., organisms: _Optional[_Iterable[str]] = ..., samples: _Optional[_Iterable[str]] = ..., sample_sets: _Optional[_Iterable[str]] = ..., creators: _Optional[_Iterable[str]] = ..., resources_external: _Optional[_Iterable[str]] = ..., data_extra: _Optional[_Iterable[str]] = ..., tags: _Optional[_Iterable[str]] = ..., method_class: _Optional[str] = ..., name_display: _Optional[str] = ..., name: _Optional[str] = ..., uri: _Optional[str] = ..., iri: _Optional[str] = ..., pid: _Optional[str] = ..., pac_id: _Optional[str] = ..., version: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., parameters: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., parameters_schema: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., icon: _Optional[str] = ..., description: _Optional[str] = ..., remarks: _Optional[str] = ..., search_vector: _Optional[str] = ..., method_json: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., media_type: _Optional[str] = ...) -> None: ...

class MethodResponse(_message.Message):
    __slots__ = ("method_id", "namespace", "substances", "polymers", "mixtures", "parts", "devices", "device_setups", "labware", "organisms", "samples", "sample_sets", "creators", "resources_external", "data_extra", "tags", "method_class", "name_display", "name", "uri", "iri", "pid", "pac_id", "version", "datetime_last_modified", "parameters", "parameters_schema", "icon", "description", "remarks", "search_vector", "method_json", "media_type")
    METHOD_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    SUBSTANCES_FIELD_NUMBER: _ClassVar[int]
    POLYMERS_FIELD_NUMBER: _ClassVar[int]
    MIXTURES_FIELD_NUMBER: _ClassVar[int]
    PARTS_FIELD_NUMBER: _ClassVar[int]
    DEVICES_FIELD_NUMBER: _ClassVar[int]
    DEVICE_SETUPS_FIELD_NUMBER: _ClassVar[int]
    LABWARE_FIELD_NUMBER: _ClassVar[int]
    ORGANISMS_FIELD_NUMBER: _ClassVar[int]
    SAMPLES_FIELD_NUMBER: _ClassVar[int]
    SAMPLE_SETS_FIELD_NUMBER: _ClassVar[int]
    CREATORS_FIELD_NUMBER: _ClassVar[int]
    RESOURCES_EXTERNAL_FIELD_NUMBER: _ClassVar[int]
    DATA_EXTRA_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    METHOD_CLASS_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    URI_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    PID_FIELD_NUMBER: _ClassVar[int]
    PAC_ID_FIELD_NUMBER: _ClassVar[int]
    VERSION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    PARAMETERS_FIELD_NUMBER: _ClassVar[int]
    PARAMETERS_SCHEMA_FIELD_NUMBER: _ClassVar[int]
    ICON_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    REMARKS_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    METHOD_JSON_FIELD_NUMBER: _ClassVar[int]
    MEDIA_TYPE_FIELD_NUMBER: _ClassVar[int]
    method_id: str
    namespace: str
    substances: _containers.RepeatedScalarFieldContainer[str]
    polymers: _containers.RepeatedScalarFieldContainer[str]
    mixtures: _containers.RepeatedScalarFieldContainer[str]
    parts: _containers.RepeatedScalarFieldContainer[str]
    devices: _containers.RepeatedScalarFieldContainer[str]
    device_setups: _containers.RepeatedScalarFieldContainer[str]
    labware: _containers.RepeatedScalarFieldContainer[str]
    organisms: _containers.RepeatedScalarFieldContainer[str]
    samples: _containers.RepeatedScalarFieldContainer[str]
    sample_sets: _containers.RepeatedScalarFieldContainer[str]
    creators: _containers.RepeatedScalarFieldContainer[str]
    resources_external: _containers.RepeatedScalarFieldContainer[str]
    data_extra: _containers.RepeatedScalarFieldContainer[str]
    tags: _containers.RepeatedScalarFieldContainer[str]
    method_class: str
    name_display: str
    name: str
    uri: str
    iri: str
    pid: str
    pac_id: str
    version: str
    datetime_last_modified: str
    parameters: _struct_pb2.Struct
    parameters_schema: _struct_pb2.Struct
    icon: str
    description: str
    remarks: str
    search_vector: str
    method_json: _struct_pb2.Struct
    media_type: str
    def __init__(self, method_id: _Optional[str] = ..., namespace: _Optional[str] = ..., substances: _Optional[_Iterable[str]] = ..., polymers: _Optional[_Iterable[str]] = ..., mixtures: _Optional[_Iterable[str]] = ..., parts: _Optional[_Iterable[str]] = ..., devices: _Optional[_Iterable[str]] = ..., device_setups: _Optional[_Iterable[str]] = ..., labware: _Optional[_Iterable[str]] = ..., organisms: _Optional[_Iterable[str]] = ..., samples: _Optional[_Iterable[str]] = ..., sample_sets: _Optional[_Iterable[str]] = ..., creators: _Optional[_Iterable[str]] = ..., resources_external: _Optional[_Iterable[str]] = ..., data_extra: _Optional[_Iterable[str]] = ..., tags: _Optional[_Iterable[str]] = ..., method_class: _Optional[str] = ..., name_display: _Optional[str] = ..., name: _Optional[str] = ..., uri: _Optional[str] = ..., iri: _Optional[str] = ..., pid: _Optional[str] = ..., pac_id: _Optional[str] = ..., version: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., parameters: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., parameters_schema: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., icon: _Optional[str] = ..., description: _Optional[str] = ..., remarks: _Optional[str] = ..., search_vector: _Optional[str] = ..., method_json: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., media_type: _Optional[str] = ...) -> None: ...

class MethodRetrieveByNameNSRequest(_message.Message):
    __slots__ = ("name", "namespace_uri")
    NAME_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_URI_FIELD_NUMBER: _ClassVar[int]
    name: str
    namespace_uri: str
    def __init__(self, name: _Optional[str] = ..., namespace_uri: _Optional[str] = ...) -> None: ...

class MethodRetrieveRequest(_message.Message):
    __slots__ = ("method_id",)
    METHOD_ID_FIELD_NUMBER: _ClassVar[int]
    method_id: str
    def __init__(self, method_id: _Optional[str] = ...) -> None: ...

class ProcedureDestroyRequest(_message.Message):
    __slots__ = ("procedure_id",)
    PROCEDURE_ID_FIELD_NUMBER: _ClassVar[int]
    procedure_id: str
    def __init__(self, procedure_id: _Optional[str] = ...) -> None: ...

class ProcedureInstanceDestroyRequest(_message.Message):
    __slots__ = ("procedureinstance_id",)
    PROCEDUREINSTANCE_ID_FIELD_NUMBER: _ClassVar[int]
    procedureinstance_id: str
    def __init__(self, procedureinstance_id: _Optional[str] = ...) -> None: ...

class ProcedureInstanceListRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class ProcedureInstanceListResponse(_message.Message):
    __slots__ = ("results",)
    RESULTS_FIELD_NUMBER: _ClassVar[int]
    results: _containers.RepeatedCompositeFieldContainer[ProcedureInstanceResponse]
    def __init__(self, results: _Optional[_Iterable[_Union[ProcedureInstanceResponse, _Mapping]]] = ...) -> None: ...

class ProcedureInstancePartialUpdateRequest(_message.Message):
    __slots__ = ("procedureinstance_id", "namespace", "procedure_base", "status", "media_type", "substance_instances", "polymer_instances", "mixture_instances", "part_instances", "device_instances", "device_setup_instances", "labware_instances", "organism_instances", "samples", "sample_sets", "creators", "resources_external", "data_extra", "tags", "_partial_update_fields", "name_display", "name", "uri", "datetime_start", "datetime_end", "datetime_last_modified", "parameters", "version", "icon", "description", "remarks", "iri", "pid", "search_vector", "procedure_json", "procedure_file")
    PROCEDUREINSTANCE_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    PROCEDURE_BASE_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    MEDIA_TYPE_FIELD_NUMBER: _ClassVar[int]
    SUBSTANCE_INSTANCES_FIELD_NUMBER: _ClassVar[int]
    POLYMER_INSTANCES_FIELD_NUMBER: _ClassVar[int]
    MIXTURE_INSTANCES_FIELD_NUMBER: _ClassVar[int]
    PART_INSTANCES_FIELD_NUMBER: _ClassVar[int]
    DEVICE_INSTANCES_FIELD_NUMBER: _ClassVar[int]
    DEVICE_SETUP_INSTANCES_FIELD_NUMBER: _ClassVar[int]
    LABWARE_INSTANCES_FIELD_NUMBER: _ClassVar[int]
    ORGANISM_INSTANCES_FIELD_NUMBER: _ClassVar[int]
    SAMPLES_FIELD_NUMBER: _ClassVar[int]
    SAMPLE_SETS_FIELD_NUMBER: _ClassVar[int]
    CREATORS_FIELD_NUMBER: _ClassVar[int]
    RESOURCES_EXTERNAL_FIELD_NUMBER: _ClassVar[int]
    DATA_EXTRA_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    _PARTIAL_UPDATE_FIELDS_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    URI_FIELD_NUMBER: _ClassVar[int]
    DATETIME_START_FIELD_NUMBER: _ClassVar[int]
    DATETIME_END_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    PARAMETERS_FIELD_NUMBER: _ClassVar[int]
    VERSION_FIELD_NUMBER: _ClassVar[int]
    ICON_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    REMARKS_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    PID_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    PROCEDURE_JSON_FIELD_NUMBER: _ClassVar[int]
    PROCEDURE_FILE_FIELD_NUMBER: _ClassVar[int]
    procedureinstance_id: str
    namespace: str
    procedure_base: str
    status: str
    media_type: str
    substance_instances: _containers.RepeatedScalarFieldContainer[str]
    polymer_instances: _containers.RepeatedScalarFieldContainer[str]
    mixture_instances: _containers.RepeatedScalarFieldContainer[str]
    part_instances: _containers.RepeatedScalarFieldContainer[str]
    device_instances: _containers.RepeatedScalarFieldContainer[str]
    device_setup_instances: _containers.RepeatedScalarFieldContainer[str]
    labware_instances: _containers.RepeatedScalarFieldContainer[str]
    organism_instances: _containers.RepeatedScalarFieldContainer[str]
    samples: _containers.RepeatedScalarFieldContainer[str]
    sample_sets: _containers.RepeatedScalarFieldContainer[str]
    creators: _containers.RepeatedScalarFieldContainer[str]
    resources_external: _containers.RepeatedScalarFieldContainer[str]
    data_extra: _containers.RepeatedScalarFieldContainer[str]
    tags: _containers.RepeatedScalarFieldContainer[str]
    _partial_update_fields: _containers.RepeatedScalarFieldContainer[str]
    name_display: str
    name: str
    uri: str
    datetime_start: str
    datetime_end: str
    datetime_last_modified: str
    parameters: _struct_pb2.Struct
    version: str
    icon: str
    description: str
    remarks: str
    iri: str
    pid: str
    search_vector: str
    procedure_json: _struct_pb2.Struct
    procedure_file: str
    def __init__(self, procedureinstance_id: _Optional[str] = ..., namespace: _Optional[str] = ..., procedure_base: _Optional[str] = ..., status: _Optional[str] = ..., media_type: _Optional[str] = ..., substance_instances: _Optional[_Iterable[str]] = ..., polymer_instances: _Optional[_Iterable[str]] = ..., mixture_instances: _Optional[_Iterable[str]] = ..., part_instances: _Optional[_Iterable[str]] = ..., device_instances: _Optional[_Iterable[str]] = ..., device_setup_instances: _Optional[_Iterable[str]] = ..., labware_instances: _Optional[_Iterable[str]] = ..., organism_instances: _Optional[_Iterable[str]] = ..., samples: _Optional[_Iterable[str]] = ..., sample_sets: _Optional[_Iterable[str]] = ..., creators: _Optional[_Iterable[str]] = ..., resources_external: _Optional[_Iterable[str]] = ..., data_extra: _Optional[_Iterable[str]] = ..., tags: _Optional[_Iterable[str]] = ..., _partial_update_fields: _Optional[_Iterable[str]] = ..., name_display: _Optional[str] = ..., name: _Optional[str] = ..., uri: _Optional[str] = ..., datetime_start: _Optional[str] = ..., datetime_end: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., parameters: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., version: _Optional[str] = ..., icon: _Optional[str] = ..., description: _Optional[str] = ..., remarks: _Optional[str] = ..., iri: _Optional[str] = ..., pid: _Optional[str] = ..., search_vector: _Optional[str] = ..., procedure_json: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., procedure_file: _Optional[str] = ...) -> None: ...

class ProcedureInstanceRequest(_message.Message):
    __slots__ = ("procedureinstance_id", "namespace", "procedure_base", "status", "media_type", "substance_instances", "polymer_instances", "mixture_instances", "part_instances", "device_instances", "device_setup_instances", "labware_instances", "organism_instances", "samples", "sample_sets", "creators", "resources_external", "data_extra", "tags", "name_display", "name", "uri", "datetime_start", "datetime_end", "datetime_last_modified", "parameters", "version", "icon", "description", "remarks", "iri", "pid", "search_vector", "procedure_json", "procedure_file")
    PROCEDUREINSTANCE_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    PROCEDURE_BASE_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    MEDIA_TYPE_FIELD_NUMBER: _ClassVar[int]
    SUBSTANCE_INSTANCES_FIELD_NUMBER: _ClassVar[int]
    POLYMER_INSTANCES_FIELD_NUMBER: _ClassVar[int]
    MIXTURE_INSTANCES_FIELD_NUMBER: _ClassVar[int]
    PART_INSTANCES_FIELD_NUMBER: _ClassVar[int]
    DEVICE_INSTANCES_FIELD_NUMBER: _ClassVar[int]
    DEVICE_SETUP_INSTANCES_FIELD_NUMBER: _ClassVar[int]
    LABWARE_INSTANCES_FIELD_NUMBER: _ClassVar[int]
    ORGANISM_INSTANCES_FIELD_NUMBER: _ClassVar[int]
    SAMPLES_FIELD_NUMBER: _ClassVar[int]
    SAMPLE_SETS_FIELD_NUMBER: _ClassVar[int]
    CREATORS_FIELD_NUMBER: _ClassVar[int]
    RESOURCES_EXTERNAL_FIELD_NUMBER: _ClassVar[int]
    DATA_EXTRA_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    URI_FIELD_NUMBER: _ClassVar[int]
    DATETIME_START_FIELD_NUMBER: _ClassVar[int]
    DATETIME_END_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    PARAMETERS_FIELD_NUMBER: _ClassVar[int]
    VERSION_FIELD_NUMBER: _ClassVar[int]
    ICON_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    REMARKS_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    PID_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    PROCEDURE_JSON_FIELD_NUMBER: _ClassVar[int]
    PROCEDURE_FILE_FIELD_NUMBER: _ClassVar[int]
    procedureinstance_id: str
    namespace: str
    procedure_base: str
    status: str
    media_type: str
    substance_instances: _containers.RepeatedScalarFieldContainer[str]
    polymer_instances: _containers.RepeatedScalarFieldContainer[str]
    mixture_instances: _containers.RepeatedScalarFieldContainer[str]
    part_instances: _containers.RepeatedScalarFieldContainer[str]
    device_instances: _containers.RepeatedScalarFieldContainer[str]
    device_setup_instances: _containers.RepeatedScalarFieldContainer[str]
    labware_instances: _containers.RepeatedScalarFieldContainer[str]
    organism_instances: _containers.RepeatedScalarFieldContainer[str]
    samples: _containers.RepeatedScalarFieldContainer[str]
    sample_sets: _containers.RepeatedScalarFieldContainer[str]
    creators: _containers.RepeatedScalarFieldContainer[str]
    resources_external: _containers.RepeatedScalarFieldContainer[str]
    data_extra: _containers.RepeatedScalarFieldContainer[str]
    tags: _containers.RepeatedScalarFieldContainer[str]
    name_display: str
    name: str
    uri: str
    datetime_start: str
    datetime_end: str
    datetime_last_modified: str
    parameters: _struct_pb2.Struct
    version: str
    icon: str
    description: str
    remarks: str
    iri: str
    pid: str
    search_vector: str
    procedure_json: _struct_pb2.Struct
    procedure_file: str
    def __init__(self, procedureinstance_id: _Optional[str] = ..., namespace: _Optional[str] = ..., procedure_base: _Optional[str] = ..., status: _Optional[str] = ..., media_type: _Optional[str] = ..., substance_instances: _Optional[_Iterable[str]] = ..., polymer_instances: _Optional[_Iterable[str]] = ..., mixture_instances: _Optional[_Iterable[str]] = ..., part_instances: _Optional[_Iterable[str]] = ..., device_instances: _Optional[_Iterable[str]] = ..., device_setup_instances: _Optional[_Iterable[str]] = ..., labware_instances: _Optional[_Iterable[str]] = ..., organism_instances: _Optional[_Iterable[str]] = ..., samples: _Optional[_Iterable[str]] = ..., sample_sets: _Optional[_Iterable[str]] = ..., creators: _Optional[_Iterable[str]] = ..., resources_external: _Optional[_Iterable[str]] = ..., data_extra: _Optional[_Iterable[str]] = ..., tags: _Optional[_Iterable[str]] = ..., name_display: _Optional[str] = ..., name: _Optional[str] = ..., uri: _Optional[str] = ..., datetime_start: _Optional[str] = ..., datetime_end: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., parameters: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., version: _Optional[str] = ..., icon: _Optional[str] = ..., description: _Optional[str] = ..., remarks: _Optional[str] = ..., iri: _Optional[str] = ..., pid: _Optional[str] = ..., search_vector: _Optional[str] = ..., procedure_json: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., procedure_file: _Optional[str] = ...) -> None: ...

class ProcedureInstanceResponse(_message.Message):
    __slots__ = ("procedureinstance_id", "namespace", "procedure_base", "status", "media_type", "substance_instances", "polymer_instances", "mixture_instances", "part_instances", "device_instances", "device_setup_instances", "labware_instances", "organism_instances", "samples", "sample_sets", "creators", "resources_external", "data_extra", "tags", "name_display", "name", "uri", "datetime_start", "datetime_end", "datetime_last_modified", "parameters", "version", "icon", "description", "remarks", "iri", "pid", "search_vector", "procedure_json", "procedure_file")
    PROCEDUREINSTANCE_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    PROCEDURE_BASE_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    MEDIA_TYPE_FIELD_NUMBER: _ClassVar[int]
    SUBSTANCE_INSTANCES_FIELD_NUMBER: _ClassVar[int]
    POLYMER_INSTANCES_FIELD_NUMBER: _ClassVar[int]
    MIXTURE_INSTANCES_FIELD_NUMBER: _ClassVar[int]
    PART_INSTANCES_FIELD_NUMBER: _ClassVar[int]
    DEVICE_INSTANCES_FIELD_NUMBER: _ClassVar[int]
    DEVICE_SETUP_INSTANCES_FIELD_NUMBER: _ClassVar[int]
    LABWARE_INSTANCES_FIELD_NUMBER: _ClassVar[int]
    ORGANISM_INSTANCES_FIELD_NUMBER: _ClassVar[int]
    SAMPLES_FIELD_NUMBER: _ClassVar[int]
    SAMPLE_SETS_FIELD_NUMBER: _ClassVar[int]
    CREATORS_FIELD_NUMBER: _ClassVar[int]
    RESOURCES_EXTERNAL_FIELD_NUMBER: _ClassVar[int]
    DATA_EXTRA_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    URI_FIELD_NUMBER: _ClassVar[int]
    DATETIME_START_FIELD_NUMBER: _ClassVar[int]
    DATETIME_END_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    PARAMETERS_FIELD_NUMBER: _ClassVar[int]
    VERSION_FIELD_NUMBER: _ClassVar[int]
    ICON_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    REMARKS_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    PID_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    PROCEDURE_JSON_FIELD_NUMBER: _ClassVar[int]
    PROCEDURE_FILE_FIELD_NUMBER: _ClassVar[int]
    procedureinstance_id: str
    namespace: str
    procedure_base: str
    status: str
    media_type: str
    substance_instances: _containers.RepeatedScalarFieldContainer[str]
    polymer_instances: _containers.RepeatedScalarFieldContainer[str]
    mixture_instances: _containers.RepeatedScalarFieldContainer[str]
    part_instances: _containers.RepeatedScalarFieldContainer[str]
    device_instances: _containers.RepeatedScalarFieldContainer[str]
    device_setup_instances: _containers.RepeatedScalarFieldContainer[str]
    labware_instances: _containers.RepeatedScalarFieldContainer[str]
    organism_instances: _containers.RepeatedScalarFieldContainer[str]
    samples: _containers.RepeatedScalarFieldContainer[str]
    sample_sets: _containers.RepeatedScalarFieldContainer[str]
    creators: _containers.RepeatedScalarFieldContainer[str]
    resources_external: _containers.RepeatedScalarFieldContainer[str]
    data_extra: _containers.RepeatedScalarFieldContainer[str]
    tags: _containers.RepeatedScalarFieldContainer[str]
    name_display: str
    name: str
    uri: str
    datetime_start: str
    datetime_end: str
    datetime_last_modified: str
    parameters: _struct_pb2.Struct
    version: str
    icon: str
    description: str
    remarks: str
    iri: str
    pid: str
    search_vector: str
    procedure_json: _struct_pb2.Struct
    procedure_file: str
    def __init__(self, procedureinstance_id: _Optional[str] = ..., namespace: _Optional[str] = ..., procedure_base: _Optional[str] = ..., status: _Optional[str] = ..., media_type: _Optional[str] = ..., substance_instances: _Optional[_Iterable[str]] = ..., polymer_instances: _Optional[_Iterable[str]] = ..., mixture_instances: _Optional[_Iterable[str]] = ..., part_instances: _Optional[_Iterable[str]] = ..., device_instances: _Optional[_Iterable[str]] = ..., device_setup_instances: _Optional[_Iterable[str]] = ..., labware_instances: _Optional[_Iterable[str]] = ..., organism_instances: _Optional[_Iterable[str]] = ..., samples: _Optional[_Iterable[str]] = ..., sample_sets: _Optional[_Iterable[str]] = ..., creators: _Optional[_Iterable[str]] = ..., resources_external: _Optional[_Iterable[str]] = ..., data_extra: _Optional[_Iterable[str]] = ..., tags: _Optional[_Iterable[str]] = ..., name_display: _Optional[str] = ..., name: _Optional[str] = ..., uri: _Optional[str] = ..., datetime_start: _Optional[str] = ..., datetime_end: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., parameters: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., version: _Optional[str] = ..., icon: _Optional[str] = ..., description: _Optional[str] = ..., remarks: _Optional[str] = ..., iri: _Optional[str] = ..., pid: _Optional[str] = ..., search_vector: _Optional[str] = ..., procedure_json: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., procedure_file: _Optional[str] = ...) -> None: ...

class ProcedureInstanceRetrieveByNameNSRequest(_message.Message):
    __slots__ = ("name", "namespace_uri")
    NAME_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_URI_FIELD_NUMBER: _ClassVar[int]
    name: str
    namespace_uri: str
    def __init__(self, name: _Optional[str] = ..., namespace_uri: _Optional[str] = ...) -> None: ...

class ProcedureInstanceRetrieveRequest(_message.Message):
    __slots__ = ("procedureinstance_id",)
    PROCEDUREINSTANCE_ID_FIELD_NUMBER: _ClassVar[int]
    procedureinstance_id: str
    def __init__(self, procedureinstance_id: _Optional[str] = ...) -> None: ...

class ProcedureInstanceStreamRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class ProcedureListRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class ProcedureListResponse(_message.Message):
    __slots__ = ("results",)
    RESULTS_FIELD_NUMBER: _ClassVar[int]
    results: _containers.RepeatedCompositeFieldContainer[ProcedureResponse]
    def __init__(self, results: _Optional[_Iterable[_Union[ProcedureResponse, _Mapping]]] = ...) -> None: ...

class ProcedurePartialUpdateRequest(_message.Message):
    __slots__ = ("procedure_id", "namespace", "substances", "polymers", "mixtures", "parts", "devices", "device_setups", "labware", "organisms", "samples", "sample_sets", "creators", "resources_external", "data_extra", "tags", "media_type", "procedure_class", "_partial_update_fields", "name_display", "name", "uri", "iri", "pid", "pac_id", "version", "datetime_last_modified", "parameters", "parameters_schema", "icon", "description", "remarks", "search_vector", "procedure_txt", "procedure_json", "procedure_file", "method")
    PROCEDURE_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    SUBSTANCES_FIELD_NUMBER: _ClassVar[int]
    POLYMERS_FIELD_NUMBER: _ClassVar[int]
    MIXTURES_FIELD_NUMBER: _ClassVar[int]
    PARTS_FIELD_NUMBER: _ClassVar[int]
    DEVICES_FIELD_NUMBER: _ClassVar[int]
    DEVICE_SETUPS_FIELD_NUMBER: _ClassVar[int]
    LABWARE_FIELD_NUMBER: _ClassVar[int]
    ORGANISMS_FIELD_NUMBER: _ClassVar[int]
    SAMPLES_FIELD_NUMBER: _ClassVar[int]
    SAMPLE_SETS_FIELD_NUMBER: _ClassVar[int]
    CREATORS_FIELD_NUMBER: _ClassVar[int]
    RESOURCES_EXTERNAL_FIELD_NUMBER: _ClassVar[int]
    DATA_EXTRA_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    MEDIA_TYPE_FIELD_NUMBER: _ClassVar[int]
    PROCEDURE_CLASS_FIELD_NUMBER: _ClassVar[int]
    _PARTIAL_UPDATE_FIELDS_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    URI_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    PID_FIELD_NUMBER: _ClassVar[int]
    PAC_ID_FIELD_NUMBER: _ClassVar[int]
    VERSION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    PARAMETERS_FIELD_NUMBER: _ClassVar[int]
    PARAMETERS_SCHEMA_FIELD_NUMBER: _ClassVar[int]
    ICON_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    REMARKS_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    PROCEDURE_TXT_FIELD_NUMBER: _ClassVar[int]
    PROCEDURE_JSON_FIELD_NUMBER: _ClassVar[int]
    PROCEDURE_FILE_FIELD_NUMBER: _ClassVar[int]
    METHOD_FIELD_NUMBER: _ClassVar[int]
    procedure_id: str
    namespace: str
    substances: _containers.RepeatedScalarFieldContainer[str]
    polymers: _containers.RepeatedScalarFieldContainer[str]
    mixtures: _containers.RepeatedScalarFieldContainer[str]
    parts: _containers.RepeatedScalarFieldContainer[str]
    devices: _containers.RepeatedScalarFieldContainer[str]
    device_setups: _containers.RepeatedScalarFieldContainer[str]
    labware: _containers.RepeatedScalarFieldContainer[str]
    organisms: _containers.RepeatedScalarFieldContainer[str]
    samples: _containers.RepeatedScalarFieldContainer[str]
    sample_sets: _containers.RepeatedScalarFieldContainer[str]
    creators: _containers.RepeatedScalarFieldContainer[str]
    resources_external: _containers.RepeatedScalarFieldContainer[str]
    data_extra: _containers.RepeatedScalarFieldContainer[str]
    tags: _containers.RepeatedScalarFieldContainer[str]
    media_type: str
    procedure_class: str
    _partial_update_fields: _containers.RepeatedScalarFieldContainer[str]
    name_display: str
    name: str
    uri: str
    iri: str
    pid: str
    pac_id: str
    version: str
    datetime_last_modified: str
    parameters: _struct_pb2.Struct
    parameters_schema: _struct_pb2.Struct
    icon: str
    description: str
    remarks: str
    search_vector: str
    procedure_txt: str
    procedure_json: _struct_pb2.Struct
    procedure_file: str
    method: str
    def __init__(self, procedure_id: _Optional[str] = ..., namespace: _Optional[str] = ..., substances: _Optional[_Iterable[str]] = ..., polymers: _Optional[_Iterable[str]] = ..., mixtures: _Optional[_Iterable[str]] = ..., parts: _Optional[_Iterable[str]] = ..., devices: _Optional[_Iterable[str]] = ..., device_setups: _Optional[_Iterable[str]] = ..., labware: _Optional[_Iterable[str]] = ..., organisms: _Optional[_Iterable[str]] = ..., samples: _Optional[_Iterable[str]] = ..., sample_sets: _Optional[_Iterable[str]] = ..., creators: _Optional[_Iterable[str]] = ..., resources_external: _Optional[_Iterable[str]] = ..., data_extra: _Optional[_Iterable[str]] = ..., tags: _Optional[_Iterable[str]] = ..., media_type: _Optional[str] = ..., procedure_class: _Optional[str] = ..., _partial_update_fields: _Optional[_Iterable[str]] = ..., name_display: _Optional[str] = ..., name: _Optional[str] = ..., uri: _Optional[str] = ..., iri: _Optional[str] = ..., pid: _Optional[str] = ..., pac_id: _Optional[str] = ..., version: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., parameters: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., parameters_schema: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., icon: _Optional[str] = ..., description: _Optional[str] = ..., remarks: _Optional[str] = ..., search_vector: _Optional[str] = ..., procedure_txt: _Optional[str] = ..., procedure_json: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., procedure_file: _Optional[str] = ..., method: _Optional[str] = ...) -> None: ...

class ProcedureRequest(_message.Message):
    __slots__ = ("procedure_id", "namespace", "substances", "polymers", "mixtures", "parts", "devices", "device_setups", "labware", "organisms", "samples", "sample_sets", "creators", "resources_external", "data_extra", "tags", "media_type", "procedure_class", "name_display", "name", "uri", "iri", "pid", "pac_id", "version", "datetime_last_modified", "parameters", "parameters_schema", "icon", "description", "remarks", "search_vector", "procedure_txt", "procedure_json", "procedure_file", "method")
    PROCEDURE_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    SUBSTANCES_FIELD_NUMBER: _ClassVar[int]
    POLYMERS_FIELD_NUMBER: _ClassVar[int]
    MIXTURES_FIELD_NUMBER: _ClassVar[int]
    PARTS_FIELD_NUMBER: _ClassVar[int]
    DEVICES_FIELD_NUMBER: _ClassVar[int]
    DEVICE_SETUPS_FIELD_NUMBER: _ClassVar[int]
    LABWARE_FIELD_NUMBER: _ClassVar[int]
    ORGANISMS_FIELD_NUMBER: _ClassVar[int]
    SAMPLES_FIELD_NUMBER: _ClassVar[int]
    SAMPLE_SETS_FIELD_NUMBER: _ClassVar[int]
    CREATORS_FIELD_NUMBER: _ClassVar[int]
    RESOURCES_EXTERNAL_FIELD_NUMBER: _ClassVar[int]
    DATA_EXTRA_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    MEDIA_TYPE_FIELD_NUMBER: _ClassVar[int]
    PROCEDURE_CLASS_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    URI_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    PID_FIELD_NUMBER: _ClassVar[int]
    PAC_ID_FIELD_NUMBER: _ClassVar[int]
    VERSION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    PARAMETERS_FIELD_NUMBER: _ClassVar[int]
    PARAMETERS_SCHEMA_FIELD_NUMBER: _ClassVar[int]
    ICON_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    REMARKS_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    PROCEDURE_TXT_FIELD_NUMBER: _ClassVar[int]
    PROCEDURE_JSON_FIELD_NUMBER: _ClassVar[int]
    PROCEDURE_FILE_FIELD_NUMBER: _ClassVar[int]
    METHOD_FIELD_NUMBER: _ClassVar[int]
    procedure_id: str
    namespace: str
    substances: _containers.RepeatedScalarFieldContainer[str]
    polymers: _containers.RepeatedScalarFieldContainer[str]
    mixtures: _containers.RepeatedScalarFieldContainer[str]
    parts: _containers.RepeatedScalarFieldContainer[str]
    devices: _containers.RepeatedScalarFieldContainer[str]
    device_setups: _containers.RepeatedScalarFieldContainer[str]
    labware: _containers.RepeatedScalarFieldContainer[str]
    organisms: _containers.RepeatedScalarFieldContainer[str]
    samples: _containers.RepeatedScalarFieldContainer[str]
    sample_sets: _containers.RepeatedScalarFieldContainer[str]
    creators: _containers.RepeatedScalarFieldContainer[str]
    resources_external: _containers.RepeatedScalarFieldContainer[str]
    data_extra: _containers.RepeatedScalarFieldContainer[str]
    tags: _containers.RepeatedScalarFieldContainer[str]
    media_type: str
    procedure_class: str
    name_display: str
    name: str
    uri: str
    iri: str
    pid: str
    pac_id: str
    version: str
    datetime_last_modified: str
    parameters: _struct_pb2.Struct
    parameters_schema: _struct_pb2.Struct
    icon: str
    description: str
    remarks: str
    search_vector: str
    procedure_txt: str
    procedure_json: _struct_pb2.Struct
    procedure_file: str
    method: str
    def __init__(self, procedure_id: _Optional[str] = ..., namespace: _Optional[str] = ..., substances: _Optional[_Iterable[str]] = ..., polymers: _Optional[_Iterable[str]] = ..., mixtures: _Optional[_Iterable[str]] = ..., parts: _Optional[_Iterable[str]] = ..., devices: _Optional[_Iterable[str]] = ..., device_setups: _Optional[_Iterable[str]] = ..., labware: _Optional[_Iterable[str]] = ..., organisms: _Optional[_Iterable[str]] = ..., samples: _Optional[_Iterable[str]] = ..., sample_sets: _Optional[_Iterable[str]] = ..., creators: _Optional[_Iterable[str]] = ..., resources_external: _Optional[_Iterable[str]] = ..., data_extra: _Optional[_Iterable[str]] = ..., tags: _Optional[_Iterable[str]] = ..., media_type: _Optional[str] = ..., procedure_class: _Optional[str] = ..., name_display: _Optional[str] = ..., name: _Optional[str] = ..., uri: _Optional[str] = ..., iri: _Optional[str] = ..., pid: _Optional[str] = ..., pac_id: _Optional[str] = ..., version: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., parameters: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., parameters_schema: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., icon: _Optional[str] = ..., description: _Optional[str] = ..., remarks: _Optional[str] = ..., search_vector: _Optional[str] = ..., procedure_txt: _Optional[str] = ..., procedure_json: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., procedure_file: _Optional[str] = ..., method: _Optional[str] = ...) -> None: ...

class ProcedureResponse(_message.Message):
    __slots__ = ("procedure_id", "namespace", "substances", "polymers", "mixtures", "parts", "devices", "device_setups", "labware", "organisms", "samples", "sample_sets", "creators", "resources_external", "data_extra", "tags", "media_type", "procedure_class", "name_display", "name", "uri", "iri", "pid", "pac_id", "version", "datetime_last_modified", "parameters", "parameters_schema", "icon", "description", "remarks", "search_vector", "procedure_txt", "procedure_json", "procedure_file", "method")
    PROCEDURE_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    SUBSTANCES_FIELD_NUMBER: _ClassVar[int]
    POLYMERS_FIELD_NUMBER: _ClassVar[int]
    MIXTURES_FIELD_NUMBER: _ClassVar[int]
    PARTS_FIELD_NUMBER: _ClassVar[int]
    DEVICES_FIELD_NUMBER: _ClassVar[int]
    DEVICE_SETUPS_FIELD_NUMBER: _ClassVar[int]
    LABWARE_FIELD_NUMBER: _ClassVar[int]
    ORGANISMS_FIELD_NUMBER: _ClassVar[int]
    SAMPLES_FIELD_NUMBER: _ClassVar[int]
    SAMPLE_SETS_FIELD_NUMBER: _ClassVar[int]
    CREATORS_FIELD_NUMBER: _ClassVar[int]
    RESOURCES_EXTERNAL_FIELD_NUMBER: _ClassVar[int]
    DATA_EXTRA_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    MEDIA_TYPE_FIELD_NUMBER: _ClassVar[int]
    PROCEDURE_CLASS_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    URI_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    PID_FIELD_NUMBER: _ClassVar[int]
    PAC_ID_FIELD_NUMBER: _ClassVar[int]
    VERSION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    PARAMETERS_FIELD_NUMBER: _ClassVar[int]
    PARAMETERS_SCHEMA_FIELD_NUMBER: _ClassVar[int]
    ICON_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    REMARKS_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    PROCEDURE_TXT_FIELD_NUMBER: _ClassVar[int]
    PROCEDURE_JSON_FIELD_NUMBER: _ClassVar[int]
    PROCEDURE_FILE_FIELD_NUMBER: _ClassVar[int]
    METHOD_FIELD_NUMBER: _ClassVar[int]
    procedure_id: str
    namespace: str
    substances: _containers.RepeatedScalarFieldContainer[str]
    polymers: _containers.RepeatedScalarFieldContainer[str]
    mixtures: _containers.RepeatedScalarFieldContainer[str]
    parts: _containers.RepeatedScalarFieldContainer[str]
    devices: _containers.RepeatedScalarFieldContainer[str]
    device_setups: _containers.RepeatedScalarFieldContainer[str]
    labware: _containers.RepeatedScalarFieldContainer[str]
    organisms: _containers.RepeatedScalarFieldContainer[str]
    samples: _containers.RepeatedScalarFieldContainer[str]
    sample_sets: _containers.RepeatedScalarFieldContainer[str]
    creators: _containers.RepeatedScalarFieldContainer[str]
    resources_external: _containers.RepeatedScalarFieldContainer[str]
    data_extra: _containers.RepeatedScalarFieldContainer[str]
    tags: _containers.RepeatedScalarFieldContainer[str]
    media_type: str
    procedure_class: str
    name_display: str
    name: str
    uri: str
    iri: str
    pid: str
    pac_id: str
    version: str
    datetime_last_modified: str
    parameters: _struct_pb2.Struct
    parameters_schema: _struct_pb2.Struct
    icon: str
    description: str
    remarks: str
    search_vector: str
    procedure_txt: str
    procedure_json: _struct_pb2.Struct
    procedure_file: str
    method: str
    def __init__(self, procedure_id: _Optional[str] = ..., namespace: _Optional[str] = ..., substances: _Optional[_Iterable[str]] = ..., polymers: _Optional[_Iterable[str]] = ..., mixtures: _Optional[_Iterable[str]] = ..., parts: _Optional[_Iterable[str]] = ..., devices: _Optional[_Iterable[str]] = ..., device_setups: _Optional[_Iterable[str]] = ..., labware: _Optional[_Iterable[str]] = ..., organisms: _Optional[_Iterable[str]] = ..., samples: _Optional[_Iterable[str]] = ..., sample_sets: _Optional[_Iterable[str]] = ..., creators: _Optional[_Iterable[str]] = ..., resources_external: _Optional[_Iterable[str]] = ..., data_extra: _Optional[_Iterable[str]] = ..., tags: _Optional[_Iterable[str]] = ..., media_type: _Optional[str] = ..., procedure_class: _Optional[str] = ..., name_display: _Optional[str] = ..., name: _Optional[str] = ..., uri: _Optional[str] = ..., iri: _Optional[str] = ..., pid: _Optional[str] = ..., pac_id: _Optional[str] = ..., version: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., parameters: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., parameters_schema: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., icon: _Optional[str] = ..., description: _Optional[str] = ..., remarks: _Optional[str] = ..., search_vector: _Optional[str] = ..., procedure_txt: _Optional[str] = ..., procedure_json: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., procedure_file: _Optional[str] = ..., method: _Optional[str] = ...) -> None: ...

class ProcedureRetrieveByNameNSRequest(_message.Message):
    __slots__ = ("name", "namespace_uri")
    NAME_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_URI_FIELD_NUMBER: _ClassVar[int]
    name: str
    namespace_uri: str
    def __init__(self, name: _Optional[str] = ..., namespace_uri: _Optional[str] = ...) -> None: ...

class ProcedureRetrieveRequest(_message.Message):
    __slots__ = ("procedure_id",)
    PROCEDURE_ID_FIELD_NUMBER: _ClassVar[int]
    procedure_id: str
    def __init__(self, procedure_id: _Optional[str] = ...) -> None: ...

class ProcedureStreamRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class ProcessDestroyRequest(_message.Message):
    __slots__ = ("process_id",)
    PROCESS_ID_FIELD_NUMBER: _ClassVar[int]
    process_id: str
    def __init__(self, process_id: _Optional[str] = ...) -> None: ...

class ProcessInstanceDestroyRequest(_message.Message):
    __slots__ = ("processinstance_id",)
    PROCESSINSTANCE_ID_FIELD_NUMBER: _ClassVar[int]
    processinstance_id: str
    def __init__(self, processinstance_id: _Optional[str] = ...) -> None: ...

class ProcessInstanceListRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class ProcessInstanceListResponse(_message.Message):
    __slots__ = ("results",)
    RESULTS_FIELD_NUMBER: _ClassVar[int]
    results: _containers.RepeatedCompositeFieldContainer[ProcessInstanceResponse]
    def __init__(self, results: _Optional[_Iterable[_Union[ProcessInstanceResponse, _Mapping]]] = ...) -> None: ...

class ProcessInstancePartialUpdateRequest(_message.Message):
    __slots__ = ("processinstance_id", "namespace", "process_base", "status", "media_type", "substance_instances", "polymer_instances", "mixture_instances", "part_instances", "device_instances", "device_setup_instances", "labware_instances", "organism_instances", "samples", "sample_sets", "creators", "resources_external", "data_extra", "tags", "procedure_instances", "_partial_update_fields", "name_display", "name", "uri", "datetime_start", "datetime_end", "datetime_last_modified", "parameters", "version", "icon", "description", "remarks", "iri", "pid", "search_vector", "process_json", "process_file")
    PROCESSINSTANCE_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    PROCESS_BASE_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    MEDIA_TYPE_FIELD_NUMBER: _ClassVar[int]
    SUBSTANCE_INSTANCES_FIELD_NUMBER: _ClassVar[int]
    POLYMER_INSTANCES_FIELD_NUMBER: _ClassVar[int]
    MIXTURE_INSTANCES_FIELD_NUMBER: _ClassVar[int]
    PART_INSTANCES_FIELD_NUMBER: _ClassVar[int]
    DEVICE_INSTANCES_FIELD_NUMBER: _ClassVar[int]
    DEVICE_SETUP_INSTANCES_FIELD_NUMBER: _ClassVar[int]
    LABWARE_INSTANCES_FIELD_NUMBER: _ClassVar[int]
    ORGANISM_INSTANCES_FIELD_NUMBER: _ClassVar[int]
    SAMPLES_FIELD_NUMBER: _ClassVar[int]
    SAMPLE_SETS_FIELD_NUMBER: _ClassVar[int]
    CREATORS_FIELD_NUMBER: _ClassVar[int]
    RESOURCES_EXTERNAL_FIELD_NUMBER: _ClassVar[int]
    DATA_EXTRA_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    PROCEDURE_INSTANCES_FIELD_NUMBER: _ClassVar[int]
    _PARTIAL_UPDATE_FIELDS_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    URI_FIELD_NUMBER: _ClassVar[int]
    DATETIME_START_FIELD_NUMBER: _ClassVar[int]
    DATETIME_END_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    PARAMETERS_FIELD_NUMBER: _ClassVar[int]
    VERSION_FIELD_NUMBER: _ClassVar[int]
    ICON_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    REMARKS_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    PID_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    PROCESS_JSON_FIELD_NUMBER: _ClassVar[int]
    PROCESS_FILE_FIELD_NUMBER: _ClassVar[int]
    processinstance_id: str
    namespace: str
    process_base: str
    status: str
    media_type: str
    substance_instances: _containers.RepeatedScalarFieldContainer[str]
    polymer_instances: _containers.RepeatedScalarFieldContainer[str]
    mixture_instances: _containers.RepeatedScalarFieldContainer[str]
    part_instances: _containers.RepeatedScalarFieldContainer[str]
    device_instances: _containers.RepeatedScalarFieldContainer[str]
    device_setup_instances: _containers.RepeatedScalarFieldContainer[str]
    labware_instances: _containers.RepeatedScalarFieldContainer[str]
    organism_instances: _containers.RepeatedScalarFieldContainer[str]
    samples: _containers.RepeatedScalarFieldContainer[str]
    sample_sets: _containers.RepeatedScalarFieldContainer[str]
    creators: _containers.RepeatedScalarFieldContainer[str]
    resources_external: _containers.RepeatedScalarFieldContainer[str]
    data_extra: _containers.RepeatedScalarFieldContainer[str]
    tags: _containers.RepeatedScalarFieldContainer[str]
    procedure_instances: _containers.RepeatedScalarFieldContainer[str]
    _partial_update_fields: _containers.RepeatedScalarFieldContainer[str]
    name_display: str
    name: str
    uri: str
    datetime_start: str
    datetime_end: str
    datetime_last_modified: str
    parameters: _struct_pb2.Struct
    version: str
    icon: str
    description: str
    remarks: str
    iri: str
    pid: str
    search_vector: str
    process_json: _struct_pb2.Struct
    process_file: str
    def __init__(self, processinstance_id: _Optional[str] = ..., namespace: _Optional[str] = ..., process_base: _Optional[str] = ..., status: _Optional[str] = ..., media_type: _Optional[str] = ..., substance_instances: _Optional[_Iterable[str]] = ..., polymer_instances: _Optional[_Iterable[str]] = ..., mixture_instances: _Optional[_Iterable[str]] = ..., part_instances: _Optional[_Iterable[str]] = ..., device_instances: _Optional[_Iterable[str]] = ..., device_setup_instances: _Optional[_Iterable[str]] = ..., labware_instances: _Optional[_Iterable[str]] = ..., organism_instances: _Optional[_Iterable[str]] = ..., samples: _Optional[_Iterable[str]] = ..., sample_sets: _Optional[_Iterable[str]] = ..., creators: _Optional[_Iterable[str]] = ..., resources_external: _Optional[_Iterable[str]] = ..., data_extra: _Optional[_Iterable[str]] = ..., tags: _Optional[_Iterable[str]] = ..., procedure_instances: _Optional[_Iterable[str]] = ..., _partial_update_fields: _Optional[_Iterable[str]] = ..., name_display: _Optional[str] = ..., name: _Optional[str] = ..., uri: _Optional[str] = ..., datetime_start: _Optional[str] = ..., datetime_end: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., parameters: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., version: _Optional[str] = ..., icon: _Optional[str] = ..., description: _Optional[str] = ..., remarks: _Optional[str] = ..., iri: _Optional[str] = ..., pid: _Optional[str] = ..., search_vector: _Optional[str] = ..., process_json: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., process_file: _Optional[str] = ...) -> None: ...

class ProcessInstanceRequest(_message.Message):
    __slots__ = ("processinstance_id", "namespace", "process_base", "status", "media_type", "substance_instances", "polymer_instances", "mixture_instances", "part_instances", "device_instances", "device_setup_instances", "labware_instances", "organism_instances", "samples", "sample_sets", "creators", "resources_external", "data_extra", "tags", "procedure_instances", "name_display", "name", "uri", "datetime_start", "datetime_end", "datetime_last_modified", "parameters", "version", "icon", "description", "remarks", "iri", "pid", "search_vector", "process_json", "process_file")
    PROCESSINSTANCE_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    PROCESS_BASE_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    MEDIA_TYPE_FIELD_NUMBER: _ClassVar[int]
    SUBSTANCE_INSTANCES_FIELD_NUMBER: _ClassVar[int]
    POLYMER_INSTANCES_FIELD_NUMBER: _ClassVar[int]
    MIXTURE_INSTANCES_FIELD_NUMBER: _ClassVar[int]
    PART_INSTANCES_FIELD_NUMBER: _ClassVar[int]
    DEVICE_INSTANCES_FIELD_NUMBER: _ClassVar[int]
    DEVICE_SETUP_INSTANCES_FIELD_NUMBER: _ClassVar[int]
    LABWARE_INSTANCES_FIELD_NUMBER: _ClassVar[int]
    ORGANISM_INSTANCES_FIELD_NUMBER: _ClassVar[int]
    SAMPLES_FIELD_NUMBER: _ClassVar[int]
    SAMPLE_SETS_FIELD_NUMBER: _ClassVar[int]
    CREATORS_FIELD_NUMBER: _ClassVar[int]
    RESOURCES_EXTERNAL_FIELD_NUMBER: _ClassVar[int]
    DATA_EXTRA_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    PROCEDURE_INSTANCES_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    URI_FIELD_NUMBER: _ClassVar[int]
    DATETIME_START_FIELD_NUMBER: _ClassVar[int]
    DATETIME_END_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    PARAMETERS_FIELD_NUMBER: _ClassVar[int]
    VERSION_FIELD_NUMBER: _ClassVar[int]
    ICON_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    REMARKS_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    PID_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    PROCESS_JSON_FIELD_NUMBER: _ClassVar[int]
    PROCESS_FILE_FIELD_NUMBER: _ClassVar[int]
    processinstance_id: str
    namespace: str
    process_base: str
    status: str
    media_type: str
    substance_instances: _containers.RepeatedScalarFieldContainer[str]
    polymer_instances: _containers.RepeatedScalarFieldContainer[str]
    mixture_instances: _containers.RepeatedScalarFieldContainer[str]
    part_instances: _containers.RepeatedScalarFieldContainer[str]
    device_instances: _containers.RepeatedScalarFieldContainer[str]
    device_setup_instances: _containers.RepeatedScalarFieldContainer[str]
    labware_instances: _containers.RepeatedScalarFieldContainer[str]
    organism_instances: _containers.RepeatedScalarFieldContainer[str]
    samples: _containers.RepeatedScalarFieldContainer[str]
    sample_sets: _containers.RepeatedScalarFieldContainer[str]
    creators: _containers.RepeatedScalarFieldContainer[str]
    resources_external: _containers.RepeatedScalarFieldContainer[str]
    data_extra: _containers.RepeatedScalarFieldContainer[str]
    tags: _containers.RepeatedScalarFieldContainer[str]
    procedure_instances: _containers.RepeatedScalarFieldContainer[str]
    name_display: str
    name: str
    uri: str
    datetime_start: str
    datetime_end: str
    datetime_last_modified: str
    parameters: _struct_pb2.Struct
    version: str
    icon: str
    description: str
    remarks: str
    iri: str
    pid: str
    search_vector: str
    process_json: _struct_pb2.Struct
    process_file: str
    def __init__(self, processinstance_id: _Optional[str] = ..., namespace: _Optional[str] = ..., process_base: _Optional[str] = ..., status: _Optional[str] = ..., media_type: _Optional[str] = ..., substance_instances: _Optional[_Iterable[str]] = ..., polymer_instances: _Optional[_Iterable[str]] = ..., mixture_instances: _Optional[_Iterable[str]] = ..., part_instances: _Optional[_Iterable[str]] = ..., device_instances: _Optional[_Iterable[str]] = ..., device_setup_instances: _Optional[_Iterable[str]] = ..., labware_instances: _Optional[_Iterable[str]] = ..., organism_instances: _Optional[_Iterable[str]] = ..., samples: _Optional[_Iterable[str]] = ..., sample_sets: _Optional[_Iterable[str]] = ..., creators: _Optional[_Iterable[str]] = ..., resources_external: _Optional[_Iterable[str]] = ..., data_extra: _Optional[_Iterable[str]] = ..., tags: _Optional[_Iterable[str]] = ..., procedure_instances: _Optional[_Iterable[str]] = ..., name_display: _Optional[str] = ..., name: _Optional[str] = ..., uri: _Optional[str] = ..., datetime_start: _Optional[str] = ..., datetime_end: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., parameters: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., version: _Optional[str] = ..., icon: _Optional[str] = ..., description: _Optional[str] = ..., remarks: _Optional[str] = ..., iri: _Optional[str] = ..., pid: _Optional[str] = ..., search_vector: _Optional[str] = ..., process_json: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., process_file: _Optional[str] = ...) -> None: ...

class ProcessInstanceResponse(_message.Message):
    __slots__ = ("processinstance_id", "namespace", "process_base", "status", "media_type", "substance_instances", "polymer_instances", "mixture_instances", "part_instances", "device_instances", "device_setup_instances", "labware_instances", "organism_instances", "samples", "sample_sets", "creators", "resources_external", "data_extra", "tags", "procedure_instances", "name_display", "name", "uri", "datetime_start", "datetime_end", "datetime_last_modified", "parameters", "version", "icon", "description", "remarks", "iri", "pid", "search_vector", "process_json", "process_file")
    PROCESSINSTANCE_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    PROCESS_BASE_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    MEDIA_TYPE_FIELD_NUMBER: _ClassVar[int]
    SUBSTANCE_INSTANCES_FIELD_NUMBER: _ClassVar[int]
    POLYMER_INSTANCES_FIELD_NUMBER: _ClassVar[int]
    MIXTURE_INSTANCES_FIELD_NUMBER: _ClassVar[int]
    PART_INSTANCES_FIELD_NUMBER: _ClassVar[int]
    DEVICE_INSTANCES_FIELD_NUMBER: _ClassVar[int]
    DEVICE_SETUP_INSTANCES_FIELD_NUMBER: _ClassVar[int]
    LABWARE_INSTANCES_FIELD_NUMBER: _ClassVar[int]
    ORGANISM_INSTANCES_FIELD_NUMBER: _ClassVar[int]
    SAMPLES_FIELD_NUMBER: _ClassVar[int]
    SAMPLE_SETS_FIELD_NUMBER: _ClassVar[int]
    CREATORS_FIELD_NUMBER: _ClassVar[int]
    RESOURCES_EXTERNAL_FIELD_NUMBER: _ClassVar[int]
    DATA_EXTRA_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    PROCEDURE_INSTANCES_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    URI_FIELD_NUMBER: _ClassVar[int]
    DATETIME_START_FIELD_NUMBER: _ClassVar[int]
    DATETIME_END_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    PARAMETERS_FIELD_NUMBER: _ClassVar[int]
    VERSION_FIELD_NUMBER: _ClassVar[int]
    ICON_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    REMARKS_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    PID_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    PROCESS_JSON_FIELD_NUMBER: _ClassVar[int]
    PROCESS_FILE_FIELD_NUMBER: _ClassVar[int]
    processinstance_id: str
    namespace: str
    process_base: str
    status: str
    media_type: str
    substance_instances: _containers.RepeatedScalarFieldContainer[str]
    polymer_instances: _containers.RepeatedScalarFieldContainer[str]
    mixture_instances: _containers.RepeatedScalarFieldContainer[str]
    part_instances: _containers.RepeatedScalarFieldContainer[str]
    device_instances: _containers.RepeatedScalarFieldContainer[str]
    device_setup_instances: _containers.RepeatedScalarFieldContainer[str]
    labware_instances: _containers.RepeatedScalarFieldContainer[str]
    organism_instances: _containers.RepeatedScalarFieldContainer[str]
    samples: _containers.RepeatedScalarFieldContainer[str]
    sample_sets: _containers.RepeatedScalarFieldContainer[str]
    creators: _containers.RepeatedScalarFieldContainer[str]
    resources_external: _containers.RepeatedScalarFieldContainer[str]
    data_extra: _containers.RepeatedScalarFieldContainer[str]
    tags: _containers.RepeatedScalarFieldContainer[str]
    procedure_instances: _containers.RepeatedScalarFieldContainer[str]
    name_display: str
    name: str
    uri: str
    datetime_start: str
    datetime_end: str
    datetime_last_modified: str
    parameters: _struct_pb2.Struct
    version: str
    icon: str
    description: str
    remarks: str
    iri: str
    pid: str
    search_vector: str
    process_json: _struct_pb2.Struct
    process_file: str
    def __init__(self, processinstance_id: _Optional[str] = ..., namespace: _Optional[str] = ..., process_base: _Optional[str] = ..., status: _Optional[str] = ..., media_type: _Optional[str] = ..., substance_instances: _Optional[_Iterable[str]] = ..., polymer_instances: _Optional[_Iterable[str]] = ..., mixture_instances: _Optional[_Iterable[str]] = ..., part_instances: _Optional[_Iterable[str]] = ..., device_instances: _Optional[_Iterable[str]] = ..., device_setup_instances: _Optional[_Iterable[str]] = ..., labware_instances: _Optional[_Iterable[str]] = ..., organism_instances: _Optional[_Iterable[str]] = ..., samples: _Optional[_Iterable[str]] = ..., sample_sets: _Optional[_Iterable[str]] = ..., creators: _Optional[_Iterable[str]] = ..., resources_external: _Optional[_Iterable[str]] = ..., data_extra: _Optional[_Iterable[str]] = ..., tags: _Optional[_Iterable[str]] = ..., procedure_instances: _Optional[_Iterable[str]] = ..., name_display: _Optional[str] = ..., name: _Optional[str] = ..., uri: _Optional[str] = ..., datetime_start: _Optional[str] = ..., datetime_end: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., parameters: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., version: _Optional[str] = ..., icon: _Optional[str] = ..., description: _Optional[str] = ..., remarks: _Optional[str] = ..., iri: _Optional[str] = ..., pid: _Optional[str] = ..., search_vector: _Optional[str] = ..., process_json: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., process_file: _Optional[str] = ...) -> None: ...

class ProcessInstanceRetrieveByNameNSRequest(_message.Message):
    __slots__ = ("name", "namespace_uri")
    NAME_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_URI_FIELD_NUMBER: _ClassVar[int]
    name: str
    namespace_uri: str
    def __init__(self, name: _Optional[str] = ..., namespace_uri: _Optional[str] = ...) -> None: ...

class ProcessInstanceRetrieveRequest(_message.Message):
    __slots__ = ("processinstance_id",)
    PROCESSINSTANCE_ID_FIELD_NUMBER: _ClassVar[int]
    processinstance_id: str
    def __init__(self, processinstance_id: _Optional[str] = ...) -> None: ...

class ProcessInstanceStreamRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class ProcessListRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class ProcessListResponse(_message.Message):
    __slots__ = ("results",)
    RESULTS_FIELD_NUMBER: _ClassVar[int]
    results: _containers.RepeatedCompositeFieldContainer[ProcessResponse]
    def __init__(self, results: _Optional[_Iterable[_Union[ProcessResponse, _Mapping]]] = ...) -> None: ...

class ProcessPartialUpdateRequest(_message.Message):
    __slots__ = ("process_id", "namespace", "substances", "polymers", "mixtures", "parts", "devices", "device_setups", "labware", "organisms", "samples", "sample_sets", "creators", "resources_external", "data_extra", "tags", "process_class", "procedures", "_partial_update_fields", "name_display", "name", "uri", "iri", "pid", "pac_id", "version", "datetime_last_modified", "parameters", "parameters_schema", "icon", "description", "remarks", "search_vector", "process_json", "process_file", "graph_representation", "media_type")
    PROCESS_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    SUBSTANCES_FIELD_NUMBER: _ClassVar[int]
    POLYMERS_FIELD_NUMBER: _ClassVar[int]
    MIXTURES_FIELD_NUMBER: _ClassVar[int]
    PARTS_FIELD_NUMBER: _ClassVar[int]
    DEVICES_FIELD_NUMBER: _ClassVar[int]
    DEVICE_SETUPS_FIELD_NUMBER: _ClassVar[int]
    LABWARE_FIELD_NUMBER: _ClassVar[int]
    ORGANISMS_FIELD_NUMBER: _ClassVar[int]
    SAMPLES_FIELD_NUMBER: _ClassVar[int]
    SAMPLE_SETS_FIELD_NUMBER: _ClassVar[int]
    CREATORS_FIELD_NUMBER: _ClassVar[int]
    RESOURCES_EXTERNAL_FIELD_NUMBER: _ClassVar[int]
    DATA_EXTRA_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    PROCESS_CLASS_FIELD_NUMBER: _ClassVar[int]
    PROCEDURES_FIELD_NUMBER: _ClassVar[int]
    _PARTIAL_UPDATE_FIELDS_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    URI_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    PID_FIELD_NUMBER: _ClassVar[int]
    PAC_ID_FIELD_NUMBER: _ClassVar[int]
    VERSION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    PARAMETERS_FIELD_NUMBER: _ClassVar[int]
    PARAMETERS_SCHEMA_FIELD_NUMBER: _ClassVar[int]
    ICON_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    REMARKS_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    PROCESS_JSON_FIELD_NUMBER: _ClassVar[int]
    PROCESS_FILE_FIELD_NUMBER: _ClassVar[int]
    GRAPH_REPRESENTATION_FIELD_NUMBER: _ClassVar[int]
    MEDIA_TYPE_FIELD_NUMBER: _ClassVar[int]
    process_id: str
    namespace: str
    substances: _containers.RepeatedScalarFieldContainer[str]
    polymers: _containers.RepeatedScalarFieldContainer[str]
    mixtures: _containers.RepeatedScalarFieldContainer[str]
    parts: _containers.RepeatedScalarFieldContainer[str]
    devices: _containers.RepeatedScalarFieldContainer[str]
    device_setups: _containers.RepeatedScalarFieldContainer[str]
    labware: _containers.RepeatedScalarFieldContainer[str]
    organisms: _containers.RepeatedScalarFieldContainer[str]
    samples: _containers.RepeatedScalarFieldContainer[str]
    sample_sets: _containers.RepeatedScalarFieldContainer[str]
    creators: _containers.RepeatedScalarFieldContainer[str]
    resources_external: _containers.RepeatedScalarFieldContainer[str]
    data_extra: _containers.RepeatedScalarFieldContainer[str]
    tags: _containers.RepeatedScalarFieldContainer[str]
    process_class: str
    procedures: _containers.RepeatedScalarFieldContainer[str]
    _partial_update_fields: _containers.RepeatedScalarFieldContainer[str]
    name_display: str
    name: str
    uri: str
    iri: str
    pid: str
    pac_id: str
    version: str
    datetime_last_modified: str
    parameters: _struct_pb2.Struct
    parameters_schema: _struct_pb2.Struct
    icon: str
    description: str
    remarks: str
    search_vector: str
    process_json: _struct_pb2.Struct
    process_file: str
    graph_representation: _struct_pb2.Struct
    media_type: str
    def __init__(self, process_id: _Optional[str] = ..., namespace: _Optional[str] = ..., substances: _Optional[_Iterable[str]] = ..., polymers: _Optional[_Iterable[str]] = ..., mixtures: _Optional[_Iterable[str]] = ..., parts: _Optional[_Iterable[str]] = ..., devices: _Optional[_Iterable[str]] = ..., device_setups: _Optional[_Iterable[str]] = ..., labware: _Optional[_Iterable[str]] = ..., organisms: _Optional[_Iterable[str]] = ..., samples: _Optional[_Iterable[str]] = ..., sample_sets: _Optional[_Iterable[str]] = ..., creators: _Optional[_Iterable[str]] = ..., resources_external: _Optional[_Iterable[str]] = ..., data_extra: _Optional[_Iterable[str]] = ..., tags: _Optional[_Iterable[str]] = ..., process_class: _Optional[str] = ..., procedures: _Optional[_Iterable[str]] = ..., _partial_update_fields: _Optional[_Iterable[str]] = ..., name_display: _Optional[str] = ..., name: _Optional[str] = ..., uri: _Optional[str] = ..., iri: _Optional[str] = ..., pid: _Optional[str] = ..., pac_id: _Optional[str] = ..., version: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., parameters: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., parameters_schema: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., icon: _Optional[str] = ..., description: _Optional[str] = ..., remarks: _Optional[str] = ..., search_vector: _Optional[str] = ..., process_json: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., process_file: _Optional[str] = ..., graph_representation: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., media_type: _Optional[str] = ...) -> None: ...

class ProcessRequest(_message.Message):
    __slots__ = ("process_id", "namespace", "substances", "polymers", "mixtures", "parts", "devices", "device_setups", "labware", "organisms", "samples", "sample_sets", "creators", "resources_external", "data_extra", "tags", "process_class", "procedures", "name_display", "name", "uri", "iri", "pid", "pac_id", "version", "datetime_last_modified", "parameters", "parameters_schema", "icon", "description", "remarks", "search_vector", "process_json", "process_file", "graph_representation", "media_type")
    PROCESS_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    SUBSTANCES_FIELD_NUMBER: _ClassVar[int]
    POLYMERS_FIELD_NUMBER: _ClassVar[int]
    MIXTURES_FIELD_NUMBER: _ClassVar[int]
    PARTS_FIELD_NUMBER: _ClassVar[int]
    DEVICES_FIELD_NUMBER: _ClassVar[int]
    DEVICE_SETUPS_FIELD_NUMBER: _ClassVar[int]
    LABWARE_FIELD_NUMBER: _ClassVar[int]
    ORGANISMS_FIELD_NUMBER: _ClassVar[int]
    SAMPLES_FIELD_NUMBER: _ClassVar[int]
    SAMPLE_SETS_FIELD_NUMBER: _ClassVar[int]
    CREATORS_FIELD_NUMBER: _ClassVar[int]
    RESOURCES_EXTERNAL_FIELD_NUMBER: _ClassVar[int]
    DATA_EXTRA_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    PROCESS_CLASS_FIELD_NUMBER: _ClassVar[int]
    PROCEDURES_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    URI_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    PID_FIELD_NUMBER: _ClassVar[int]
    PAC_ID_FIELD_NUMBER: _ClassVar[int]
    VERSION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    PARAMETERS_FIELD_NUMBER: _ClassVar[int]
    PARAMETERS_SCHEMA_FIELD_NUMBER: _ClassVar[int]
    ICON_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    REMARKS_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    PROCESS_JSON_FIELD_NUMBER: _ClassVar[int]
    PROCESS_FILE_FIELD_NUMBER: _ClassVar[int]
    GRAPH_REPRESENTATION_FIELD_NUMBER: _ClassVar[int]
    MEDIA_TYPE_FIELD_NUMBER: _ClassVar[int]
    process_id: str
    namespace: str
    substances: _containers.RepeatedScalarFieldContainer[str]
    polymers: _containers.RepeatedScalarFieldContainer[str]
    mixtures: _containers.RepeatedScalarFieldContainer[str]
    parts: _containers.RepeatedScalarFieldContainer[str]
    devices: _containers.RepeatedScalarFieldContainer[str]
    device_setups: _containers.RepeatedScalarFieldContainer[str]
    labware: _containers.RepeatedScalarFieldContainer[str]
    organisms: _containers.RepeatedScalarFieldContainer[str]
    samples: _containers.RepeatedScalarFieldContainer[str]
    sample_sets: _containers.RepeatedScalarFieldContainer[str]
    creators: _containers.RepeatedScalarFieldContainer[str]
    resources_external: _containers.RepeatedScalarFieldContainer[str]
    data_extra: _containers.RepeatedScalarFieldContainer[str]
    tags: _containers.RepeatedScalarFieldContainer[str]
    process_class: str
    procedures: _containers.RepeatedScalarFieldContainer[str]
    name_display: str
    name: str
    uri: str
    iri: str
    pid: str
    pac_id: str
    version: str
    datetime_last_modified: str
    parameters: _struct_pb2.Struct
    parameters_schema: _struct_pb2.Struct
    icon: str
    description: str
    remarks: str
    search_vector: str
    process_json: _struct_pb2.Struct
    process_file: str
    graph_representation: _struct_pb2.Struct
    media_type: str
    def __init__(self, process_id: _Optional[str] = ..., namespace: _Optional[str] = ..., substances: _Optional[_Iterable[str]] = ..., polymers: _Optional[_Iterable[str]] = ..., mixtures: _Optional[_Iterable[str]] = ..., parts: _Optional[_Iterable[str]] = ..., devices: _Optional[_Iterable[str]] = ..., device_setups: _Optional[_Iterable[str]] = ..., labware: _Optional[_Iterable[str]] = ..., organisms: _Optional[_Iterable[str]] = ..., samples: _Optional[_Iterable[str]] = ..., sample_sets: _Optional[_Iterable[str]] = ..., creators: _Optional[_Iterable[str]] = ..., resources_external: _Optional[_Iterable[str]] = ..., data_extra: _Optional[_Iterable[str]] = ..., tags: _Optional[_Iterable[str]] = ..., process_class: _Optional[str] = ..., procedures: _Optional[_Iterable[str]] = ..., name_display: _Optional[str] = ..., name: _Optional[str] = ..., uri: _Optional[str] = ..., iri: _Optional[str] = ..., pid: _Optional[str] = ..., pac_id: _Optional[str] = ..., version: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., parameters: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., parameters_schema: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., icon: _Optional[str] = ..., description: _Optional[str] = ..., remarks: _Optional[str] = ..., search_vector: _Optional[str] = ..., process_json: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., process_file: _Optional[str] = ..., graph_representation: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., media_type: _Optional[str] = ...) -> None: ...

class ProcessResponse(_message.Message):
    __slots__ = ("process_id", "namespace", "substances", "polymers", "mixtures", "parts", "devices", "device_setups", "labware", "organisms", "samples", "sample_sets", "creators", "resources_external", "data_extra", "tags", "process_class", "procedures", "name_display", "name", "uri", "iri", "pid", "pac_id", "version", "datetime_last_modified", "parameters", "parameters_schema", "icon", "description", "remarks", "search_vector", "process_json", "process_file", "graph_representation", "media_type")
    PROCESS_ID_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_FIELD_NUMBER: _ClassVar[int]
    SUBSTANCES_FIELD_NUMBER: _ClassVar[int]
    POLYMERS_FIELD_NUMBER: _ClassVar[int]
    MIXTURES_FIELD_NUMBER: _ClassVar[int]
    PARTS_FIELD_NUMBER: _ClassVar[int]
    DEVICES_FIELD_NUMBER: _ClassVar[int]
    DEVICE_SETUPS_FIELD_NUMBER: _ClassVar[int]
    LABWARE_FIELD_NUMBER: _ClassVar[int]
    ORGANISMS_FIELD_NUMBER: _ClassVar[int]
    SAMPLES_FIELD_NUMBER: _ClassVar[int]
    SAMPLE_SETS_FIELD_NUMBER: _ClassVar[int]
    CREATORS_FIELD_NUMBER: _ClassVar[int]
    RESOURCES_EXTERNAL_FIELD_NUMBER: _ClassVar[int]
    DATA_EXTRA_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    PROCESS_CLASS_FIELD_NUMBER: _ClassVar[int]
    PROCEDURES_FIELD_NUMBER: _ClassVar[int]
    NAME_DISPLAY_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    URI_FIELD_NUMBER: _ClassVar[int]
    IRI_FIELD_NUMBER: _ClassVar[int]
    PID_FIELD_NUMBER: _ClassVar[int]
    PAC_ID_FIELD_NUMBER: _ClassVar[int]
    VERSION_FIELD_NUMBER: _ClassVar[int]
    DATETIME_LAST_MODIFIED_FIELD_NUMBER: _ClassVar[int]
    PARAMETERS_FIELD_NUMBER: _ClassVar[int]
    PARAMETERS_SCHEMA_FIELD_NUMBER: _ClassVar[int]
    ICON_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    REMARKS_FIELD_NUMBER: _ClassVar[int]
    SEARCH_VECTOR_FIELD_NUMBER: _ClassVar[int]
    PROCESS_JSON_FIELD_NUMBER: _ClassVar[int]
    PROCESS_FILE_FIELD_NUMBER: _ClassVar[int]
    GRAPH_REPRESENTATION_FIELD_NUMBER: _ClassVar[int]
    MEDIA_TYPE_FIELD_NUMBER: _ClassVar[int]
    process_id: str
    namespace: str
    substances: _containers.RepeatedScalarFieldContainer[str]
    polymers: _containers.RepeatedScalarFieldContainer[str]
    mixtures: _containers.RepeatedScalarFieldContainer[str]
    parts: _containers.RepeatedScalarFieldContainer[str]
    devices: _containers.RepeatedScalarFieldContainer[str]
    device_setups: _containers.RepeatedScalarFieldContainer[str]
    labware: _containers.RepeatedScalarFieldContainer[str]
    organisms: _containers.RepeatedScalarFieldContainer[str]
    samples: _containers.RepeatedScalarFieldContainer[str]
    sample_sets: _containers.RepeatedScalarFieldContainer[str]
    creators: _containers.RepeatedScalarFieldContainer[str]
    resources_external: _containers.RepeatedScalarFieldContainer[str]
    data_extra: _containers.RepeatedScalarFieldContainer[str]
    tags: _containers.RepeatedScalarFieldContainer[str]
    process_class: str
    procedures: _containers.RepeatedScalarFieldContainer[str]
    name_display: str
    name: str
    uri: str
    iri: str
    pid: str
    pac_id: str
    version: str
    datetime_last_modified: str
    parameters: _struct_pb2.Struct
    parameters_schema: _struct_pb2.Struct
    icon: str
    description: str
    remarks: str
    search_vector: str
    process_json: _struct_pb2.Struct
    process_file: str
    graph_representation: _struct_pb2.Struct
    media_type: str
    def __init__(self, process_id: _Optional[str] = ..., namespace: _Optional[str] = ..., substances: _Optional[_Iterable[str]] = ..., polymers: _Optional[_Iterable[str]] = ..., mixtures: _Optional[_Iterable[str]] = ..., parts: _Optional[_Iterable[str]] = ..., devices: _Optional[_Iterable[str]] = ..., device_setups: _Optional[_Iterable[str]] = ..., labware: _Optional[_Iterable[str]] = ..., organisms: _Optional[_Iterable[str]] = ..., samples: _Optional[_Iterable[str]] = ..., sample_sets: _Optional[_Iterable[str]] = ..., creators: _Optional[_Iterable[str]] = ..., resources_external: _Optional[_Iterable[str]] = ..., data_extra: _Optional[_Iterable[str]] = ..., tags: _Optional[_Iterable[str]] = ..., process_class: _Optional[str] = ..., procedures: _Optional[_Iterable[str]] = ..., name_display: _Optional[str] = ..., name: _Optional[str] = ..., uri: _Optional[str] = ..., iri: _Optional[str] = ..., pid: _Optional[str] = ..., pac_id: _Optional[str] = ..., version: _Optional[str] = ..., datetime_last_modified: _Optional[str] = ..., parameters: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., parameters_schema: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., icon: _Optional[str] = ..., description: _Optional[str] = ..., remarks: _Optional[str] = ..., search_vector: _Optional[str] = ..., process_json: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., process_file: _Optional[str] = ..., graph_representation: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., media_type: _Optional[str] = ...) -> None: ...

class ProcessRetrieveByNameNSRequest(_message.Message):
    __slots__ = ("name", "namespace_uri")
    NAME_FIELD_NUMBER: _ClassVar[int]
    NAMESPACE_URI_FIELD_NUMBER: _ClassVar[int]
    name: str
    namespace_uri: str
    def __init__(self, name: _Optional[str] = ..., namespace_uri: _Optional[str] = ...) -> None: ...

class ProcessRetrieveRequest(_message.Message):
    __slots__ = ("process_id",)
    PROCESS_ID_FIELD_NUMBER: _ClassVar[int]
    process_id: str
    def __init__(self, process_id: _Optional[str] = ...) -> None: ...

class ProcessStreamRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class SubscriptionRequest(_message.Message):
    __slots__ = ("signal",)
    SIGNAL_FIELD_NUMBER: _ClassVar[int]
    signal: str
    def __init__(self, signal: _Optional[str] = ...) -> None: ...
