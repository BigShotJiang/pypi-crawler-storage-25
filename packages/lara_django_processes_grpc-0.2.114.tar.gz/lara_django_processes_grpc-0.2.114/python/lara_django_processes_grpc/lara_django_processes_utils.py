"""_____________________________________________________________________

:PROJECT: LARAsuite

*lara_django_processes process utilities *

:details: lara_django_processe process utilities.
            - serialing a process file

:authors: mark doerr <mark.doerr@uni-greifswald.de>

.. note:: -
.. todo:: -
________________________________________________________________________
"""

import json


def serialize_process_file(process_file_path, language = "python"):
    """
    serialize the process files to JSON, use "src" as key and the content of the file as value
    opens process files and read the content
    create a dictionary with the key "src" and the content of the file as value
    serialize the dictionary to JSON
    """
    with open(process_file_path, "r") as file:
        process_content = file.read()
        process_dict = { language:  {"src": process_content}}
        process_json = json.dumps(process_dict)
    return json.loads(process_json)
