<img src="https://raw.githubusercontent.com/iammcoding/lac-cli/main/lacicon.png" width="120" />

# lac-cli

lac-cli is a terminal toolkit built by [lacai.io](https://lacai.io) that brings AI directly into your command line. It includes an AI-powered shell, a coding assistant with project memory, a multi-model debate engine, and an API documentation generator.

**New in v0.2.1:** LacAgent - AI coding assistant with filesystem access, command execution, undo/redo, and API testing capabilities.

## Install

```bash
# Fast install (core + agent + gendoc)
pip install lac-cli

# Or install everything (includes shell server and mind)
pip install lac-cli[all]
```

**Optional components:**
```bash
pip install lac-cli[agent]  # Just the coding assistant
pip install lac-cli[shell]  # Shell with autocomplete server
pip install lac-cli[mind]   # Multi-model debate engine
pip install lac-cli[all]    # Everything
```

## Getting Started

Run `lac` to see the menu of available tools:

```bash
lac
```

You'll see:
```
lac-cli v0.2.1

Available Tools:

  1. Shell    - AI-powered terminal with autocomplete
  2. Mind     - Multi-model debate engine
  3. GenDoc   - API documentation generator
  4. Agent    - AI coding assistant with project memory
  5. Settings - Configure AI provider and model

Select a tool [1-5] or press Enter for Shell:
```

Or use direct commands:

```bash
lac shell          # Launch AI terminal shell
lac mind           # Launch multi-model debate
lac gendoc <path>  # Generate API docs
lac agent          # Launch AI coding assistant
```

### LacAgent AI Coding Assistant

Launch the AI coding assistant with project memory:

```bash
lac agent
```

LacAgent is a powerful AI coding assistant that can:
- Read, write, and edit files in your project
- Execute shell commands (with safety checks)
- Test API endpoints with HTTP requests
- Watch files for changes
- Generate API documentation
- Remember project context across sessions
- Undo/redo file changes with diff preview

**Slash Commands:**
```bash
/undo              # Revert last file edit with diff preview
/redo              # Reapply undone edit
/history           # Show all file edits this session
/diff <file>       # Inspect file contents with line numbers
/gendoc [path]     # Generate API documentation
```

**Example Usage:**
```
[You] create a FastAPI app with user authentication
[Agent] → Creates files, installs dependencies, sets up routes

[You] run the server
[Agent] → Starts uvicorn in background, provides log file location

[You] test the /users endpoint
[Agent] → Makes HTTP request, shows response

[You] /undo
[Agent] → Reverts last file change with diff preview
```

### Terminal Shell

Launch the AI-powered shell:

```bash
lac shell
```

The first time you run it, a setup wizard will walk you through picking your AI provider and entering your API key.

To redo the setup:

```bash
lac shell --setup
```

To run without an internet connection:

```bash
lac shell --offline
```

To adjust autocomplete speed (default 150ms):

```bash
lac shell --debounce 50   # faster
lac shell --debounce 300  # slower
```

### LacMind Multi-Model Debate

Launch the web-based debate interface for complex queries:

```bash
lac mind
```

LacMind runs multiple AI models in a debate format where they challenge and refine each other's ideas, then vote on the best response. Perfect for research, code generation, and complex problem-solving.

### GenDoc API Documentation

Generate beautiful API documentation from your codebase:

```bash
lac gendoc /path/to/project
```

GenDoc scans your project, detects the framework, and uses AI to analyze your routes and controllers to generate comprehensive API documentation. Supports Laravel, Django, FastAPI, Flask, Express, and Rails.

Optional flags:

```bash
lac gendoc /path/to/project --prompt "Focus on authentication endpoints"
lac gendoc /path/to/project --integrate  # Add /docs route to your framework
lac gendoc /path/to/project --output custom.html
```

## How It Works

### Main Menu

When you run `lac` without arguments, you get an interactive menu to choose between:
- **Shell** - AI-powered terminal with real-time autocomplete
- **Mind** - Multi-model debate for complex queries
- **GenDoc** - API documentation generator
- **Agent** - AI coding assistant with project memory
- **Settings** - Configure AI provider and model

You can also use direct commands like `lac shell`, `lac mind`, `lac gendoc <path>`, or `lac agent`.

### LacAgent Coding Assistant

LacAgent is an AI coding assistant that runs in your project directory with full filesystem and command execution access:

**Core Capabilities:**
- **File Operations** - Read, write, and patch files with exact string matching
- **Command Execution** - Run shell commands with automatic background process detection
- **API Testing** - Make HTTP requests to test your endpoints
- **File Watching** - Monitor files for changes and get diff reports
- **Documentation** - Generate API docs using GenDoc integration
- **Project Memory** - Remembers project context, stack, decisions across sessions
- **Undo/Redo** - Full file edit history with diff preview and restoration

**Smart Features:**
- Automatically runs long-running commands (flutter run, npm start, etc.) in background with logging
- Logs saved to `~/.lac/logs/` for later inspection
- Multi-line paste support with visual indicator
- Slash command autocomplete (type `/` to see options)
- Security validation prevents dangerous commands and path escaping

**File Editing Workflow:**
1. Agent reads file first to get exact content
2. Uses patch_file to make surgical edits (not full rewrites)
3. Automatically snapshots before every edit
4. You can /undo anytime to revert with diff preview

### Terminal Shell

When you launch `lac`, it automatically starts a local server in the background that handles communication with your AI model. You do not need to start anything manually.

As you type, the shell sends your input to the AI and shows a suggested completion as ghost text. Press Tab to accept it. If you type something in plain English like "show all files bigger than 100mb", the shell converts it to the right command and asks you to confirm before running it.

The shell now tracks your session history (commands + outputs) and passes it to the AI for smarter context-aware suggestions.

### LacMind Debate Engine

LacMind orchestrates multiple AI models in a structured debate:

1. **Debate Rounds** - Models discuss and challenge each other's ideas sequentially
2. **Voting Phase** - Models vote on who provided the best reasoning
3. **Consensus Summary** - The winning model delivers the final response

Models are labeled anonymously (Model A, B, C) during debate to prevent bias. You can configure debate duration and select which models participate.

### GenDoc Documentation Generator

GenDoc uses AI to automatically generate API documentation:

1. **Project Scanning** - Detects framework and finds route/controller files
2. **AI Analysis** - Sends files to lacai.io backend for intelligent analysis
3. **HTML Generation** - Creates beautiful, interactive documentation
4. **Framework Integration** - Optionally adds `/docs` route to your app

The first time you run `lac gendoc`, you'll be prompted for an API key from [lacai.io/dashboard/keys](https://lacai.io/dashboard/keys). Documentation includes endpoint details, parameters, request/response examples, and export to Swagger/Postman formats.

## Supported Providers

| Provider | Notes |
|----------|-------|
| `claude` | Anthropic API |
| `openai` | OpenAI API |
| `ollama` | Local models, no API key needed |
| `custom` | Any OpenAI compatible endpoint |

## Commands

### Main Menu

| Command | What it does |
|---------|--------------|
| `lac` | Show interactive menu |
| `lac shell` | Launch AI terminal shell |
| `lac mind` | Launch LacMind debate UI |
| `lac gendoc <path>` | Generate API documentation |
| `lac agent` | Launch AI coding assistant |

### LacAgent

| Command | What it does |
|---------|--------------|
| `lac agent` | Launch AI coding assistant |
| `/undo` | Revert last file edit with diff |
| `/redo` | Reapply undone edit |
| `/history` | Show all file edits this session |
| `/diff <file>` | Inspect file with line numbers |
| `/gendoc [path]` | Generate API documentation |
| `exit` | Quit the agent |

### Terminal Shell

| Command | What it does |
|---------|--------------|
| `lac shell` | Launch the AI shell |
| `lac shell --setup` | Re-run setup wizard |
| `lac shell --offline` | Run without server |
| `lac shell --debounce MS` | Set autocomplete delay |
| `exit` | Quit the shell |
| `logout` | Delete your config and start fresh |
| `clear` | Clear the screen and session history |
| `cd <path>` | Change directory |

### LacMind

| Command | What it does |
|---------|--------------|
| `lac mind` | Launch LacMind web interface |
| Settings page | Add/edit/delete AI models |
| Duration selector | Set debate time (30s - 5min) |
| Stop button | End debate early |
| Export | Save conversations to PDF |

### GenDoc

| Command | What it does |
|---------|--------------|
| `lac gendoc <path>` | Generate API docs from project |
| `--prompt "text"` | Custom instructions for AI analysis |
| `--integrate` | Add /docs route to framework |
| `--output file.html` | Custom output filename |
| Export buttons | Download as Swagger or Postman |

## Config

Your config is saved at `~/.lac/config.json` after setup. You can edit it directly if needed.

```json
{
  "provider": "claude",
  "api_key": "sk-...",
  "model": "claude-haiku-4-5-20251001",
  "base_url": "https://api.anthropic.com",
  "server": "ws://localhost:8765"
}
```

## Features

### LacAgent Coding Assistant

- **File Operations** - Read, write, patch files with exact string matching
- **Command Execution** - Run shell commands with safety validation
- **Background Processes** - Auto-detects long-running commands (flutter run, npm start, etc.) and runs them in background with logging
- **API Testing** - Make HTTP requests (GET, POST, PUT, DELETE, etc.) to test endpoints
- **File Watching** - Monitor files for changes and get diff reports
- **Documentation Generation** - Integrated GenDoc for API docs
- **Project Memory** - Persistent memory stores project context, stack, decisions, todos
- **Undo/Redo System** - Full file edit history with diff preview and restoration
- **Multi-line Paste** - Paste code freely with visual indicator `[Pasted · N lines · M chars]`
- **Slash Commands** - Autocomplete for /undo, /redo, /history, /diff, /gendoc
- **Security** - Path validation, dangerous command blocking, confirmation prompts
- **Native Tool Calling** - Uses Anthropic/OpenAI function calling for reliable tool execution
- **Session Logs** - All background process logs saved to `~/.lac/logs/`

### Terminal Shell

- Ghost text autocomplete as you type, powered by your AI model
- Plain English to shell command conversion with confirmation before running
- Session history tracking - AI sees your recent commands and outputs for better context
- Configurable autocomplete debounce delay (--debounce flag)
- Works with any major AI provider or local models via Ollama
- Offline mode falls back to history and static completions
- Local server starts automatically in the background, no manual setup needed
- Logout clears your credentials and resets the config

### LacMind

- Multi-model debate engine with sequential discussion rounds
- Anonymous voting system to select best reasoning
- Real-time streaming of debate progress
- Conversation history with chat persistence
- Model management (add/edit/delete models)
- Configurable debate duration
- Stop debate early if consensus is reached
- Export conversations to PDF
- Clean, minimal dark theme UI

### GenDoc

- Automatic framework detection (Laravel, Django, FastAPI, Flask, Express, Rails)
- AI-powered endpoint analysis and documentation generation
- Interactive HTML documentation with search and navigation
- Resizable sidebar with endpoint filtering
- Try It feature to test endpoints directly from docs
- Export to Swagger (OpenAPI 3.0) and Postman Collection formats
- Optional framework integration to serve docs at `/docs` route
- Custom prompts to guide AI analysis
- Separate API key system from lac shell (stored in `~/.lac/gendoc.json`)
- Credit-based usage with backend session management

## About

lac-cli is part of [lacai.io](https://lacai.io). Built for developers who live in the terminal.

## License

MIT
