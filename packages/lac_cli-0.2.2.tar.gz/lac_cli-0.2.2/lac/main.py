"""
lac/main.py
───────────
Entry point for the `lac` CLI command.

Flow:
  1. First run → launch setup wizard
  2. Auto-start lac-server in background if not already running
  3. Connect to lac-server via WebSocket
  4. Launch the interactive shell
"""

import asyncio
import subprocess
import sys
import time
import argparse
from rich.console import Console
from rich import print as rprint

from lac import config, wizard
from lac.ws_client import LacClient
from lac.shell import run_shell

console = Console()

_server_process = None


def _port_open(host: str, port: int) -> bool:
    import socket
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.settimeout(0.5)
        return s.connect_ex((host, port)) == 0


def _ensure_server():
    """Start lac-server in background if not already running.
    Returns: 'already_running' | 'started' | 'failed'
    """
    global _server_process
    host, port = "127.0.0.1", 8765

    if _port_open(host, port):
        return "already_running"

    try:
        _server_process = subprocess.Popen(
            [sys.executable, "-m", "uvicorn", "server.main:app",
             "--host", "0.0.0.0", "--port", str(port), "--log-level", "error"],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
    except Exception:
        return "failed"

    # wait up to 5s for the port to open
    for _ in range(10):
        time.sleep(0.5)
        if _server_process.poll() is not None:
            return "failed"  # process exited early
        if _port_open(host, port):
            return "started"

    # timed out — kill it and fall back to offline
    _server_process.terminate()
    return "failed"


def _stop_server():
    if _server_process and _server_process.poll() is None:
        _server_process.terminate()


async def _start(offline: bool = False, debounce: int = 150):
    """Main async entry — connect to server then run shell."""

    client = None

    if not offline:
        status = _ensure_server()
        if status == "started":
            console.print("[dim]started lac-server in background[/dim]")
        elif status == "failed":
            console.print("[yellow]⚠ could not start lac-server — running in offline mode[/yellow]")

        if status != "failed":
            server_url = config.get("server", "ws://localhost:8765")
            console.print(f"[dim]connecting to {server_url}...[/dim]", end="\r")
            client = LacClient()
            try:
                await client.connect()
                console.print("[green]✓ connected to lac-server[/green]          ")
            except ConnectionError as e:
                console.print(
                    f"[yellow]⚠ could not connect to server — running in offline mode[/yellow]\n"
                    f"[dim]  {e}[/dim]\n"
                )
                client = None

    try:
        await run_shell(client, debounce_ms=debounce)
    finally:
        if client:
            await client.disconnect()
        _stop_server()


def main():
    """
    CLI entry point registered in pyproject.toml as `lac`.
    """
    parser = argparse.ArgumentParser(
        prog="lac",
        description="lac-cli — AI-powered terminal shell with multiple tools",
    )
    parser.add_argument(
        "--version",
        action="version",
        version="lac-cli 0.2.1",
    )
    subparsers = parser.add_subparsers(dest="command")
    
    # Shell subcommand
    shell_parser = subparsers.add_parser("shell", help="launch AI-powered terminal shell")
    shell_parser.add_argument("--setup", action="store_true", help="re-run the setup wizard")
    shell_parser.add_argument("--offline", action="store_true", help="run without connecting to lac-server")
    shell_parser.add_argument("--debounce", type=int, default=150, metavar="MS", help="autocomplete debounce delay in milliseconds (default: 150)")
    
    # Mind subcommand
    subparsers.add_parser("mind", help="launch LacMind multi-model debate UI")
    
    # Agent subcommand
    subparsers.add_parser("agent", help="launch AI coding assistant with project memory")
    
    # GenDoc subcommand
    gendoc_parser = subparsers.add_parser("gendoc", help="generate API documentation from codebase")
    gendoc_parser.add_argument("path", type=str, help="Path to your project directory")
    gendoc_parser.add_argument("--prompt", type=str, help="Custom instructions for documentation generation")
    gendoc_parser.add_argument("--integrate", action="store_true", help="Add documentation route to your MVC framework")
    gendoc_parser.add_argument("--output", type=str, default="api-docs.html", help="Output file path (default: api-docs.html)")
    
    args = parser.parse_args()

    # If no command specified, show menu
    if not args.command:
        show_menu()
        return

    # ── Shell ─────────────────────────────────────────────────────────────────
    if args.command == "shell":
        # First run or forced setup
        if args.setup or not config.config_exists():
            wizard.run()
        
        # Launch shell
        try:
            asyncio.run(_start(offline=args.offline, debounce=args.debounce))
        except KeyboardInterrupt:
            console.print("\n[bold cyan]bye 👋[/bold cyan]")
            sys.exit(0)
        return

    # ── LacMind ───────────────────────────────────────────────────────────────
    if args.command == "mind":
        try:
            from lac.mind.main import launch
            launch()
        except ImportError:
            console.print("[red]✗ LacMind dependencies not installed[/red]")
            console.print("[dim]Install with:[/dim] pip install lac-cli[mind]\n")
            sys.exit(1)
        return
    
    # ── LacAgent ──────────────────────────────────────────────────────────────
    if args.command == "agent":
        try:
            from lac.agent.main import launch
            launch()
        except ImportError:
            console.print("[red]✗ LacAgent dependencies not installed[/red]")
            console.print("[dim]Install with:[/dim] pip install lac-cli[agent]\n")
            sys.exit(1)
        return
    
    # ── lac gendoc ────────────────────────────────────────────────────────────
    if args.command == "gendoc":
        from lac.gendoc.main import launch
        launch(args)
        return


def show_menu():
    """Display interactive menu for tool selection."""
    console.print("\n[bold cyan]  ██╗      █████╗  ██████╗[/bold cyan]")
    console.print("[bold cyan]  ██║     ██╔══██╗██╔════╝[/bold cyan]")
    console.print("[bold cyan]  ██║     ███████║██║[/bold cyan]")
    console.print("[bold cyan]  ██║     ██╔══██║██║[/bold cyan]")
    console.print("[bold cyan]  ███████╗██║  ██║╚██████╗[/bold cyan]")
    console.print("[bold cyan]  ╚══════╝╚═╝  ╚═╝ ╚═════╝[/bold cyan]  [white]CLI[/white] [dim]v0.2.1[/dim]\n")
    
    console.print("[bold]Available Tools:[/bold]\n")
    console.print("  [cyan]1.[/cyan] [bold]Shell[/bold]    - AI-powered terminal with autocomplete")
    console.print("  [cyan]2.[/cyan] [bold]Mind[/bold]     - Multi-model debate engine")
    console.print("  [cyan]3.[/cyan] [bold]GenDoc[/bold]   - API documentation generator")
    console.print("  [cyan]4.[/cyan] [bold]Agent[/bold]    - AI coding assistant with project memory")
    console.print("  [cyan]5.[/cyan] [bold]Settings[/bold] - Configure AI provider and model\n")
    
    try:
        choice = input("Select a tool [1-5] or press Enter for Shell: ").strip()
    except (KeyboardInterrupt, EOFError):
        console.print("\n[bold cyan]bye 👋[/bold cyan]")
        sys.exit(0)
    
    # Handle exit command
    if choice.lower() in ["exit", "quit", "bye"]:
        console.print("\n[bold cyan]bye 👋[/bold cyan]")
        sys.exit(0)
    
    if choice == "2":
        try:
            from lac.mind.main import launch
            launch()
        except ImportError:
            console.print("\n[red]✗ LacMind dependencies not installed[/red]")
            console.print("[dim]Install with:[/dim] pip install lac-cli[mind]\n")
            return
    elif choice == "3":
        console.print()
        try:
            path = input("Enter project path: ").strip()
        except (KeyboardInterrupt, EOFError):
            console.print("\n[bold cyan]bye 👋[/bold cyan]")
            sys.exit(0)
        
        if not path:
            console.print("[red]Error: Path is required[/red]")
            console.print("[dim]Usage:[/dim] lac gendoc <path>\n")
            return
        
        # Create args object for gendoc
        class Args:
            def __init__(self, path):
                self.path = path
                self.prompt = None
                self.integrate = False
                self.output = "api-docs.html"
        
        from lac.gendoc.main import launch
        launch(Args(path))
    elif choice == "4":
        try:
            from lac.agent.main import launch
            launch()
        except ImportError:
            console.print("\n[red]✗ LacAgent dependencies not installed[/red]")
            console.print("[dim]Install with:[/dim] pip install lac-cli[agent]\n")
            return
    elif choice == "5":
        # Settings - re-run wizard
        wizard.run()
        console.print("\n[green]✓ Settings updated[/green]")
        console.print("[dim]Returning to menu...[/dim]\n")
        import time
        time.sleep(1)
        show_menu()  # Return to menu
    else:
        # Default to shell (choice == "1" or Enter)
        if not config.config_exists():
            wizard.run()
        try:
            asyncio.run(_start(offline=False, debounce=150))
        except KeyboardInterrupt:
            console.print("\n[bold cyan]bye 👋[/bold cyan]")
            sys.exit(0)


if __name__ == "__main__":
    main()
