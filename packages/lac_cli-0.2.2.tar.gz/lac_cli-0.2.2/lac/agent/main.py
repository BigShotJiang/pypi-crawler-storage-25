"""
lac/agent/main.py
Entry point for LacAgent
"""

import os
from rich.console import Console
from lac.agent.agent import Agent

console = Console()


def launch():
    """Launch LacAgent"""
    try:
        cwd = os.getcwd()
        agent = Agent(cwd)
        agent.run()
    except RuntimeError as e:
        console.print(f"\n[red]Error: {e}[/red]\n")
    except KeyboardInterrupt:
        console.print("\n[bold cyan]bye 👋[/bold cyan]\n")
    except Exception as e:
        console.print(f"\n[red]Unexpected error: {e}[/red]\n")
