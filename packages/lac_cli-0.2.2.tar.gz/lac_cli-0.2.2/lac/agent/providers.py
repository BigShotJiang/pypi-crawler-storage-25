"""
lac/agent/providers.py
Multi-provider support with fallback
"""

import httpx
import json
from typing import AsyncIterator, Optional
from lac import config


class Provider:
    def __init__(self, provider: str, api_key: str, model: str, base_url: str):
        self.provider = provider
        self.api_key = api_key
        self.model = model
        self.base_url = base_url
    
    async def send_message(self, messages: list[dict], stream: bool = True) -> AsyncIterator[str]:
        """Send message to provider and stream response"""
        if self.provider == "claude":
            async for chunk in self._claude_stream(messages):
                yield chunk
        elif self.provider in ["openai", "custom"]:
            async for chunk in self._openai_stream(messages):
                yield chunk
        elif self.provider == "ollama":
            async for chunk in self._ollama_stream(messages):
                yield chunk
    
    async def _claude_stream(self, messages: list[dict]) -> AsyncIterator[str]:
        headers = {
            "x-api-key": self.api_key,
            "anthropic-version": "2023-06-01",
            "content-type": "application/json",
        }
        
        # Extract system message if present
        system = ""
        user_messages = []
        for msg in messages:
            if msg["role"] == "system":
                system = msg["content"]
            else:
                user_messages.append(msg)
        
        body = {
            "model": self.model,
            "max_tokens": 4096,
            "stream": True,
            "messages": user_messages,
        }
        if system:
            body["system"] = system
        
        async with httpx.AsyncClient(timeout=60.0) as client:
            async with client.stream(
                "POST",
                f"{self.base_url}/v1/messages",
                headers=headers,
                json=body,
            ) as resp:
                resp.raise_for_status()
                async for line in resp.aiter_lines():
                    if not line.startswith("data:"):
                        continue
                    data_str = line[5:].strip()
                    if data_str == "[DONE]":
                        break
                    try:
                        data = json.loads(data_str)
                        if data.get("type") == "content_block_delta":
                            token = data["delta"].get("text", "")
                            if token:
                                yield token
                    except json.JSONDecodeError:
                        continue
    
    async def _openai_stream(self, messages: list[dict]) -> AsyncIterator[str]:
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
        }
        body = {
            "model": self.model,
            "max_tokens": 4096,
            "stream": True,
            "messages": messages,
        }
        
        async with httpx.AsyncClient(timeout=60.0) as client:
            async with client.stream(
                "POST",
                f"{self.base_url}/chat/completions",
                headers=headers,
                json=body,
            ) as resp:
                resp.raise_for_status()
                async for line in resp.aiter_lines():
                    if not line.startswith("data:"):
                        continue
                    data_str = line[5:].strip()
                    if data_str == "[DONE]":
                        break
                    try:
                        data = json.loads(data_str)
                        token = (
                            data.get("choices", [{}])[0]
                            .get("delta", {})
                            .get("content", "")
                        )
                        if token:
                            yield token
                    except json.JSONDecodeError:
                        continue
    
    async def _ollama_stream(self, messages: list[dict]) -> AsyncIterator[str]:
        body = {
            "model": self.model,
            "stream": True,
            "messages": messages,
        }
        
        async with httpx.AsyncClient(timeout=90.0) as client:
            async with client.stream(
                "POST",
                f"{self.base_url}/api/chat",
                json=body,
            ) as resp:
                resp.raise_for_status()
                async for line in resp.aiter_lines():
                    if not line:
                        continue
                    try:
                        data = json.loads(line)
                        token = data.get("message", {}).get("content", "")
                        if token:
                            yield token
                        if data.get("done"):
                            break
                    except json.JSONDecodeError:
                        continue


def get_provider() -> Optional[Provider]:
    """Get active provider from config"""
    cfg = config.load_config()
    if not cfg:
        return None
    
    api_key = cfg.get("api_key", "")
    provider_name = cfg.get("provider", "claude")
    
    # Validate API key for non-ollama providers
    if provider_name != "ollama" and not api_key:
        raise RuntimeError(f"No API key found for {provider_name}. Run 'lac shell --setup' to configure.")
    
    return Provider(
        provider=provider_name,
        api_key=api_key,
        model=cfg.get("model", "claude-haiku-4-5-20251001"),
        base_url=cfg.get("base_url", "https://api.anthropic.com"),
    )


def get_fallback_providers() -> list[Provider]:
    """Get list of all configured providers for fallback"""
    providers = []
    cfg = config.load_config()
    
    # Add primary provider first
    primary = get_provider()
    if primary:
        providers.append(primary)
    
    # Add other providers from config if available
    # For now, just return primary
    return providers
