"""
lac/agent/tools.py
Agent tools for file operations, command execution, and memory
"""

import difflib
import httpx
import os
import subprocess
import time
from datetime import datetime
from pathlib import Path
from typing import Any


class UndoStack:
    """Snapshots file state before every write/patch. Pop to undo."""

    def __init__(self):
        self._stack = []   # list of {"path", "before", "after", "op", "ts"}
        self._redo = []

    def snapshot(self, path: str, before: str | None, after: str, op: str):
        self._stack.append({
            "path": path,
            "before": before,   # None = file didn't exist (write_file created it)
            "after": after,
            "op": op,
            "ts": datetime.now().strftime("%H:%M:%S"),
        })
        self._redo.clear()     # new edit wipes redo history

    def undo(self) -> dict | None:
        if not self._stack:
            return None
        entry = self._stack.pop()
        self._redo.append(entry)
        return entry

    def redo(self) -> dict | None:
        if not self._redo:
            return None
        entry = self._redo.pop()
        self._stack.append(entry)
        return entry

    def list(self) -> list:
        return list(reversed(self._stack))   # most recent first

    def diff(self, entry: dict) -> str:
        before = (entry["before"] or "").splitlines(keepends=True)
        after  = entry["after"].splitlines(keepends=True)
        return "".join(difflib.unified_diff(
            after, before,
            fromfile=f"{entry['path']} (current)",
            tofile=f"{entry['path']} (restored)",
            lineterm="",
        ))


class Tools:
    def __init__(self, memory, cwd: str = "."):
        self.memory = memory
        self.cwd = Path(cwd)
        self.undo_stack = UndoStack()
    
    def read_file(self, path: str) -> str:
        """Read file contents"""
        try:
            file_path = self.cwd / path
            with open(file_path, "r") as f:
                return f.read()
        except Exception as e:
            return f"Error reading file: {e}"
    
    def write_file(self, path: str, content: str) -> str:
        """Write content to file"""
        try:
            file_path = self.cwd / path
            file_path.parent.mkdir(parents=True, exist_ok=True)
            before = file_path.read_text() if file_path.exists() else None
            file_path.write_text(content)
            self.undo_stack.snapshot(path, before, content, "write_file")
            return f"Successfully wrote to {path}"
        except Exception as e:
            return f"Error writing file: {e}"
    
    def patch_file(self, path: str, old_str: str, new_str: str, replace_all: bool = False) -> str:
        """Edit a file by replacing exact string match"""
        try:
            file_path = self.cwd / path
            before = file_path.read_text()
            
            if old_str not in before:
                # Return file contents so AI can self-correct
                preview = before[:2000] + ("\n... (truncated)" if len(before) > 2000 else "")
                return f"""Error: old_str not found in {path}.

Current file contents:
{preview}

You must read_file first and copy old_str exactly from the output, character-for-character including all whitespace."""
            
            count = before.count(old_str)
            if count > 1 and not replace_all:
                return f"Error: old_str appears {count} times in {path}. Add more context to make it unique, or set replace_all=true."
            
            after = before.replace(old_str, new_str) if replace_all else before.replace(old_str, new_str, 1)
            file_path.write_text(after)
            self.undo_stack.snapshot(path, before, after, "patch_file")
            replaced = count if replace_all else 1
            return f"Successfully patched {path} ({replaced} occurrence{'s' if replaced > 1 else ''} replaced)"
        except FileNotFoundError:
            return f"Error: File {path} not found. Use write_file to create new files."
        except Exception as e:
            return f"Error patching file: {e}"
    
    def run_command(self, command: str) -> str:
        """Execute shell command with safety checks"""
        import re
        
        # Tier 2: BLOCKED - Never run these
        blocked_patterns = [
            r':\(\)\{.*:\|:&\};:',  # fork bomb
            r'curl.*\|.*bash',  # curl | bash
            r'wget.*\|.*bash',  # wget | bash
            r'nc.*-e',  # netcat reverse shell
            r'rm\s+-rf\s+/',  # rm -rf / (root)
        ]
        
        for pattern in blocked_patterns:
            if re.search(pattern, command, re.IGNORECASE):
                return f"BLOCKED: Command '{command}' is not allowed for security reasons."
        
        # Tier 1: CONFIRM - Ask user first
        dangerous_patterns = [
            r'rm\s+-r',  # rm -r
            r'sudo\s+rm',  # sudo rm
            r'chmod\s+-R.*7',  # chmod -R *7
            r'shutdown',
            r'reboot',
            r'mkfs',
            r'dd\s+if=',
            r'/etc/',  # writing to /etc/
        ]
        
        is_dangerous = any(re.search(p, command, re.IGNORECASE) for p in dangerous_patterns)
        
        if is_dangerous:
            print(f"\n[WARNING] Potentially dangerous command detected:")
            print(f"  {command}")
            try:
                confirm = input("\nRun this command? [y/N]: ").strip().lower()
                if confirm != 'y':
                    return "Command aborted by user."
            except (KeyboardInterrupt, EOFError):
                return "Command aborted by user."
        
        # Detect long-running commands that should run in background
        long_running_patterns = [
            r'flutter\s+run',
            r'npm\s+(run\s+)?dev',
            r'npm\s+start',
            r'yarn\s+(run\s+)?dev',
            r'yarn\s+start',
            r'python.*manage\.py\s+runserver',
            r'rails\s+server',
            r'rails\s+s\b',
            r'php\s+artisan\s+serve',
            r'uvicorn',
            r'gunicorn',
            r'nodemon',
            r'ng\s+serve',
            r'vite',
            r'webpack.*serve',
            r'next\s+dev',
        ]
        
        is_long_running = any(re.search(p, command, re.IGNORECASE) for p in long_running_patterns)
        
        if is_long_running:
            # Run in background with logging
            from datetime import datetime
            timestamp = datetime.now().strftime("%Y%m%d-%H%M%S")
            log_dir = Path.home() / ".lac" / "logs"
            log_dir.mkdir(parents=True, exist_ok=True)
            
            # Extract a simple name for the log file
            cmd_name = command.split()[0].replace('/', '-')
            log_file = log_dir / f"{cmd_name}-{timestamp}.log"
            
            # Run command in background, redirect output to log file
            bg_command = f"({command}) > {log_file} 2>&1 &"
            
            try:
                result = subprocess.run(
                    bg_command,
                    shell=True,
                    cwd=self.cwd,
                    capture_output=True,
                    text=True,
                )
                
                # Get the PID of the background process (approximate)
                pid_result = subprocess.run(
                    f"pgrep -f '{command.split()[0]}'" if ' ' in command else f"pgrep {command}",
                    shell=True,
                    capture_output=True,
                    text=True,
                )
                pid = pid_result.stdout.strip().split('\n')[-1] if pid_result.stdout else "unknown"
                
                return f"""Started '{command}' in background (PID: {pid})
Logs: {log_file}

The process is now running. To check logs, use read_file with the log path above.
To stop it, use run_command with 'kill {pid}' or 'pkill -f \"{command.split()[0]}\"'"""
                
            except Exception as e:
                return f"Error starting background process: {e}"
        
        # Execute normal command (blocking)
        try:
            result = subprocess.run(
                command,
                shell=True,
                cwd=self.cwd,
                capture_output=True,
                text=True,
                timeout=30,
            )
            output = result.stdout + result.stderr
            return output if output else "Command executed successfully"
        except subprocess.TimeoutExpired:
            return "Command timed out after 30 seconds"
        except Exception as e:
            return f"Error running command: {e}"
    
    def list_files(self, path: str = ".") -> str:
        """List files in directory"""
        try:
            dir_path = self.cwd / path
            files = []
            for item in dir_path.iterdir():
                if item.name.startswith("."):
                    continue
                prefix = "[DIR]" if item.is_dir() else "[FILE]"
                files.append(f"{prefix} {item.name}")
            return "\n".join(files) if files else "Directory is empty"
        except Exception as e:
            return f"Error listing files: {e}"
    
    def search_code(self, pattern: str, path: str = ".") -> str:
        """Search for pattern in code files"""
        try:
            # First try grep
            result = subprocess.run(
                ["grep", "-r", "-n", "--include=*.py", "--include=*.js", "--include=*.ts", 
                 "--include=*.java", "--include=*.go", "--include=*.html", "--include=*.css", 
                 pattern, path],
                cwd=self.cwd,
                capture_output=True,
                text=True,
                timeout=10,
            )
            if result.stdout:
                return result.stdout
            
            # If no results, try case-insensitive
            result = subprocess.run(
                ["grep", "-r", "-n", "-i", "--include=*.py", "--include=*.js", "--include=*.ts", 
                 "--include=*.java", "--include=*.go", "--include=*.html", "--include=*.css",
                 pattern, path],
                cwd=self.cwd,
                capture_output=True,
                text=True,
                timeout=10,
            )
            return result.stdout if result.stdout else "No matches found"
        except Exception as e:
            return f"Error searching code: {e}"
    
    def generate_docs(self, path: str = ".", prompt: str = "") -> str:
        """Generate API documentation using GenDoc"""
        try:
            from lac.gendoc.scanner import get_file_list
            from lac.gendoc.client import GendocClient, GendocAPIError
            from lac.gendoc.templates import build_html
            from lac.gendoc.gendoc_config import get_api_key, config_exists
            from lac.gendoc.setup import run_setup
            
            project_path = self.cwd / path
            
            if not project_path.exists() or not project_path.is_dir():
                return f"Error: {path} is not a valid directory"
            
            # Get API key
            if not config_exists():
                return "Error: GenDoc not configured. Run 'lac gendoc --setup' first or provide API key at https://lacai.io/dashboard/keys"
            
            api_key = get_api_key()
            if not api_key:
                return "Error: No GenDoc API key found. Run 'lac gendoc --setup' first"
            
            # Scan project
            scan_result = get_file_list(project_path)
            framework = scan_result['framework']
            files = scan_result['files']
            
            if len(files) == 0:
                return f"No route/controller files found in {path}"
            
            # Start session
            client = GendocClient(api_key)
            start_resp = client.start_session(files, framework, prompt)
            
            if start_resp.get('status') != 'started':
                return f"Error starting GenDoc session: {start_resp}"
            
            # Iterative analysis
            files_sent = 0
            requested_file = start_resp.get('requested_file')
            doc_data = None
            
            while requested_file and files_sent < 50:  # safety limit
                files_sent += 1
                file_path = project_path / requested_file
                
                if not file_path.exists():
                    break
                
                try:
                    file_content = file_path.read_text(encoding='utf-8')
                except Exception:
                    break
                
                resp = client.continue_session(requested_file, file_content)
                status = resp.get('status')
                
                if status == 'need_file':
                    requested_file = resp.get('requested_file')
                elif status in ('complete', 'limit_reached'):
                    doc_data = resp.get('documentation')
                    break
                else:
                    return f"Error: Unexpected status {status}"
            
            if not doc_data:
                return "Error: No documentation generated"
            
            # Generate HTML
            html = build_html(doc_data)
            output_path = project_path / "api-docs.html"
            output_path.write_text(html, encoding='utf-8')
            
            return f"Successfully generated API documentation at {output_path.relative_to(self.cwd)}\nAnalyzed {files_sent} files. Framework: {framework or 'unknown'}\nOpen the file in a browser to view."
            
        except GendocAPIError as e:
            return f"GenDoc API Error: {e}"
        except Exception as e:
            return f"Error generating docs: {e}"
    
    def http_request(self, method: str, url: str, headers: dict = None, body: dict = None) -> str:
        """Make HTTP request to test API endpoints"""
        try:
            method = method.upper()
            if method not in ["GET", "POST", "PUT", "DELETE", "PATCH", "HEAD", "OPTIONS"]:
                return f"Error: Invalid HTTP method '{method}'"
            
            # Make request with timeout
            with httpx.Client(timeout=30.0) as client:
                if method == "GET":
                    response = client.get(url, headers=headers)
                elif method == "POST":
                    response = client.post(url, headers=headers, json=body)
                elif method == "PUT":
                    response = client.put(url, headers=headers, json=body)
                elif method == "DELETE":
                    response = client.delete(url, headers=headers)
                elif method == "PATCH":
                    response = client.patch(url, headers=headers, json=body)
                elif method == "HEAD":
                    response = client.head(url, headers=headers)
                elif method == "OPTIONS":
                    response = client.options(url, headers=headers)
            
            # Format response
            result = f"HTTP {method} {url}\n"
            result += f"Status: {response.status_code} {response.reason_phrase}\n"
            result += f"\nResponse Headers:\n"
            for key, value in response.headers.items():
                result += f"  {key}: {value}\n"
            
            # Get response body (cap at 5000 chars)
            try:
                body_text = response.text
                if len(body_text) > 5000:
                    result += f"\nResponse Body (truncated to 5000 chars):\n{body_text[:5000]}...\n"
                else:
                    result += f"\nResponse Body:\n{body_text}\n"
            except Exception:
                result += f"\nResponse Body: (binary or unreadable)\n"
            
            return result
            
        except httpx.TimeoutException:
            return f"Error: Request to {url} timed out after 30 seconds"
        except httpx.ConnectError:
            return f"Error: Could not connect to {url}"
        except Exception as e:
            return f"Error making HTTP request: {e}"
    
    def watch_file(self, path: str, seconds: int = 30) -> str:
        """Monitor a file for changes and report back"""
        try:
            file_path = self.cwd / path
            
            if not file_path.exists():
                return f"Error: File {path} does not exist"
            
            # Read initial content and mtime
            initial_content = file_path.read_text()
            initial_mtime = os.stat(file_path).st_mtime
            
            # Poll for changes
            elapsed = 0
            while elapsed < seconds:
                time.sleep(1)
                elapsed += 1
                
                current_mtime = os.stat(file_path).st_mtime
                if current_mtime != initial_mtime:
                    # File changed!
                    new_content = file_path.read_text()
                    
                    # Generate diff
                    diff = list(difflib.unified_diff(
                        initial_content.splitlines(keepends=True),
                        new_content.splitlines(keepends=True),
                        fromfile=f"{path} (before)",
                        tofile=f"{path} (after)",
                        lineterm=""
                    ))
                    
                    if diff:
                        diff_text = "".join(diff)
                        return f"File {path} changed after {elapsed} seconds:\n\n{diff_text}"
                    else:
                        return f"File {path} was modified after {elapsed} seconds but content appears unchanged"
            
            return f"File {path} did not change during {seconds} second watch period"
            
        except Exception as e:
            return f"Error watching file: {e}"
    
    def remember(self, key: str, value: Any) -> str:
        """Store value in project memory"""
        self.memory.remember(key, value)
        return f"Remembered {key}: {value}"
    
    def recall(self, key: str) -> str:
        """Retrieve value from project memory"""
        value = self.memory.recall(key)
        return str(value) if value else f"No memory for key: {key}"
    
    def execute(self, tool_name: str, **kwargs) -> str:
        """Execute a tool by name"""
        if tool_name == "read_file":
            return self.read_file(kwargs.get("path", ""))
        elif tool_name == "write_file":
            return self.write_file(kwargs.get("path", ""), kwargs.get("content", ""))
        elif tool_name == "patch_file":
            return self.patch_file(
                kwargs.get("path", ""),
                kwargs.get("old_str", ""),
                kwargs.get("new_str", ""),
                kwargs.get("replace_all", False)
            )
        elif tool_name == "run_command":
            return self.run_command(kwargs.get("command", ""))
        elif tool_name == "list_files":
            return self.list_files(kwargs.get("path", "."))
        elif tool_name == "search_code":
            return self.search_code(kwargs.get("pattern", ""), kwargs.get("path", "."))
        elif tool_name == "generate_docs":
            return self.generate_docs(kwargs.get("path", "."), kwargs.get("prompt", ""))
        elif tool_name == "http_request":
            return self.http_request(
                kwargs.get("method", "GET"),
                kwargs.get("url", ""),
                kwargs.get("headers"),
                kwargs.get("body")
            )
        elif tool_name == "watch_file":
            return self.watch_file(kwargs.get("path", ""), kwargs.get("seconds", 30))
        elif tool_name == "remember":
            return self.remember(kwargs.get("key", ""), kwargs.get("value", ""))
        elif tool_name == "recall":
            return self.recall(kwargs.get("key", ""))
        else:
            return f"Unknown tool: {tool_name}"


TOOLS_DESCRIPTION = """
Available tools:
- read_file(path): Read file contents
- write_file(path, content): Write content to file
- run_command(command): Execute shell command
- list_files(path="."): List files in directory
- search_code(pattern, path="."): Search for pattern in code
- remember(key, value): Store in project memory
- recall(key): Retrieve from project memory

To use a tool, respond with:
TOOL: tool_name
ARGS: {"arg1": "value1", "arg2": "value2"}
"""
