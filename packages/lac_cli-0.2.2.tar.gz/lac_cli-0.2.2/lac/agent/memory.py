"""
lac/agent/memory.py
Persistent project memory stored in .lac-memory.json
"""

import json
import os
from pathlib import Path
from typing import Any, Optional


class Memory:
    def __init__(self, cwd: str = "."):
        self.cwd = Path(cwd)
        self.memory_file = self.cwd / ".lac-memory.json"
        self.data = self._load()
    
    def _load(self) -> dict:
        """Load memory from .lac-memory.json or create default"""
        if self.memory_file.exists():
            with open(self.memory_file, "r") as f:
                return json.load(f)
        return {
            "project": "",
            "stack": [],
            "decisions": [],
            "todos": [],
            "last_session": ""
        }
    
    def save(self):
        """Persist memory to disk"""
        with open(self.memory_file, "w") as f:
            json.dump(self.data, f, indent=2)
    
    def remember(self, key: str, value: Any):
        """Store a value in memory"""
        if key in ["stack", "decisions", "todos"]:
            if not isinstance(self.data[key], list):
                self.data[key] = []
            if value not in self.data[key]:
                self.data[key].append(value)
        else:
            self.data[key] = value
        self.save()
    
    def recall(self, key: str) -> Any:
        """Retrieve a value from memory"""
        return self.data.get(key)
    
    def get_context(self) -> str:
        """Build context string from memory for agent"""
        lines = []
        if self.data.get("project"):
            lines.append(f"Project: {self.data['project']}")
        if self.data.get("stack"):
            lines.append(f"Stack: {', '.join(self.data['stack'])}")
        if self.data.get("decisions"):
            lines.append("Key Decisions:")
            for d in self.data["decisions"][-5:]:
                lines.append(f"  - {d}")
        if self.data.get("todos"):
            lines.append("TODOs:")
            for t in self.data["todos"][-5:]:
                lines.append(f"  - {t}")
        if self.data.get("last_session"):
            lines.append(f"Last Session: {self.data['last_session']}")
        return "\n".join(lines) if lines else "No project memory yet."
    
    def update_session(self, summary: str):
        """Update last session summary"""
        self.data["last_session"] = summary
        self.save()
