"""
Framework integrator - adds /docs route to serve generated documentation
"""

from pathlib import Path
from typing import Optional

def integrate_laravel(project_path: Path, docs_file: str) -> bool:
    """Add route to Laravel routes/web.php"""
    routes_file = project_path / "routes" / "web.php"
    if not routes_file.exists():
        return False
    
    route_code = f"""
Route::get('/docs', function () {{
    return response()->file(base_path('{docs_file}'));
}});
"""
    
    content = routes_file.read_text()
    if '/docs' in content:
        return False  # Already exists
    
    routes_file.write_text(content.rstrip() + "\n" + route_code)
    return True

def integrate_django(project_path: Path, docs_file: str) -> bool:
    """Add route to Django urls.py"""
    # Find main urls.py
    urls_files = list(project_path.glob("**/urls.py"))
    if not urls_files:
        return False
    
    urls_file = urls_files[0]  # Use first found
    
    route_code = f"""
from django.http import FileResponse
from django.urls import path
import os

def serve_docs(request):
    return FileResponse(open(os.path.join(os.path.dirname(__file__), '..', '{docs_file}'), 'rb'))

urlpatterns += [path('docs/', serve_docs)]
"""
    
    content = urls_file.read_text()
    if 'docs/' in content:
        return False
    
    urls_file.write_text(content.rstrip() + "\n" + route_code)
    return True

def integrate_fastapi(project_path: Path, docs_file: str) -> bool:
    """Add route to FastAPI main.py or app.py"""
    main_file = project_path / "main.py"
    if not main_file.exists():
        main_file = project_path / "app.py"
    if not main_file.exists():
        return False
    
    route_code = f"""
from fastapi.responses import FileResponse

@app.get("/docs")
async def serve_docs():
    return FileResponse("{docs_file}")
"""
    
    content = main_file.read_text()
    if '"/docs"' in content:
        return False
    
    main_file.write_text(content.rstrip() + "\n" + route_code)
    return True

def integrate_flask(project_path: Path, docs_file: str) -> bool:
    """Add route to Flask app.py"""
    app_file = project_path / "app.py"
    if not app_file.exists():
        return False
    
    route_code = f"""
@app.route('/docs')
def serve_docs():
    return send_file('{docs_file}')
"""
    
    content = app_file.read_text()
    if '/docs' in content:
        return False
    
    # Add import if needed
    if 'send_file' not in content:
        content = content.replace('from flask import', 'from flask import send_file,', 1)
    
    app_file.write_text(content.rstrip() + "\n" + route_code)
    return True

def integrate_express(project_path: Path, docs_file: str) -> bool:
    """Add route to Express app.js"""
    app_file = project_path / "app.js"
    if not app_file.exists():
        return False
    
    route_code = f"""
app.get('/docs', (req, res) => {{
    res.sendFile('{docs_file}', {{ root: __dirname }});
}});
"""
    
    content = app_file.read_text()
    if '/docs' in content:
        return False
    
    app_file.write_text(content.rstrip() + "\n" + route_code)
    return True

INTEGRATORS = {
    'laravel': integrate_laravel,
    'django': integrate_django,
    'fastapi': integrate_fastapi,
    'flask': integrate_flask,
    'express': integrate_express
}

def integrate_docs_route(project_path: Path, framework: Optional[str], docs_file: str) -> bool:
    """Add /docs route to framework"""
    if not framework or framework not in INTEGRATORS:
        return False
    
    return INTEGRATORS[framework](project_path, docs_file)
