"""
Gendoc setup wizard - prompts for API key on first run
"""

from rich.console import Console
from rich.prompt import Prompt
from lac.gendoc.gendoc_config import save_api_key
from lac.gendoc.client import GendocClient, GendocAPIError

console = Console()

def run_setup() -> str:
    """Prompt user for API key and verify it"""
    console.print("\n[bold cyan]Welcome to lac gendoc![/bold cyan]\n")
    console.print("To generate API documentation, you need an API key from:")
    console.print("[link]https://lacai.io/dashboard/keys[/link]\n")
    
    try:
        while True:
            api_key = Prompt.ask("[cyan]Enter your API key[/cyan]", password=True)
            
            if not api_key or not api_key.strip():
                console.print("[red]✗ API key cannot be empty[/red]\n")
                continue
            
            api_key = api_key.strip()
            
            # Verify the key
            console.print("\n[dim]Verifying API key...[/dim]")
            try:
                client = GendocClient(api_key)
                auth_info = client.verify_key()
                
                plan = auth_info.get('plan', 'free')
                credits = auth_info.get('credits_remaining', 'unknown')
                
                console.print(f"[green]✓ API key verified![/green]")
                console.print(f"[dim]Plan: {plan} | Credits: {credits}[/dim]\n")
                
                save_api_key(api_key)
                console.print("[green]✓ Configuration saved[/green]\n")
                
                return api_key
                
            except GendocAPIError as e:
                console.print(f"[red]✗ Invalid API key: {e}[/red]\n")
                retry = Prompt.ask("Try again?", choices=["y", "n"], default="y")
                if retry == "n":
                    return None
            except Exception as e:
                console.print(f"[red]✗ Connection error: {e}[/red]\n")
                console.print("[yellow]⚠ Cannot reach backend server. Please check your internet connection.[/yellow]\n")
                retry = Prompt.ask("Try again?", choices=["y", "n"], default="y")
                if retry == "n":
                    return None
    except KeyboardInterrupt:
        console.print("\n[yellow]⚠ Setup cancelled[/yellow]")
        return None
