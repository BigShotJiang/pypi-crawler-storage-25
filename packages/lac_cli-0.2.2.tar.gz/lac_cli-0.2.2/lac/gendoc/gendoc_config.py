"""
Gendoc config management - separate from lac shell config
"""

import json
from pathlib import Path

CONFIG_DIR = Path.home() / ".lac"
GENDOC_CONFIG_FILE = CONFIG_DIR / "gendoc.json"

def config_exists() -> bool:
    """Check if gendoc config exists"""
    return GENDOC_CONFIG_FILE.exists()

def get_api_key() -> str:
    """Get stored API key"""
    if not config_exists():
        return None
    
    try:
        with open(GENDOC_CONFIG_FILE, "r") as f:
            data = json.load(f)
            return data.get("api_key")
    except:
        return None

def save_api_key(api_key: str):
    """Save API key to config"""
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    
    data = {"api_key": api_key}
    with open(GENDOC_CONFIG_FILE, "w") as f:
        json.dump(data, f, indent=2)

def clear_config():
    """Delete config file"""
    if GENDOC_CONFIG_FILE.exists():
        GENDOC_CONFIG_FILE.unlink()
