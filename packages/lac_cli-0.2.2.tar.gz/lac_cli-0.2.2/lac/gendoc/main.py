"""
lac/gendoc/main.py
Entry point for `lac gendoc <path>`.
"""

import sys
from pathlib import Path
from rich.console import Console
from rich.progress import Progress, SpinnerColumn, TextColumn

from lac.gendoc.scanner import get_file_list
from lac.gendoc.client import GendocClient, GendocAPIError
from lac.gendoc.templates import build_html
from lac.gendoc.integrator import integrate_docs_route
from lac.gendoc.gendoc_config import get_api_key, config_exists
from lac.gendoc.setup import run_setup

console = Console()

def launch(args):
    """Entry point for lac gendoc command"""
    project_path = Path(args.path).resolve()
    
    if not project_path.exists():
        console.print(f"[red]✗ Path does not exist: {project_path}[/red]")
        sys.exit(1)
    
    if not project_path.is_dir():
        console.print(f"[red]✗ Path is not a directory: {project_path}[/red]")
        sys.exit(1)
    
    # Get or setup API key
    if not config_exists():
        api_key = run_setup()
        if not api_key:
            console.print("[red]✗ Setup cancelled[/red]")
            sys.exit(1)
    else:
        api_key = get_api_key()
        if not api_key:
            console.print("[red]✗ No API key found. Please run setup again[/red]")
            api_key = run_setup()
            if not api_key:
                sys.exit(1)
    
    try:
        # Step 1: Scan project
        console.print(f"\n[cyan]Scanning project:[/cyan] {project_path}")
        scan_result = get_file_list(project_path)
        framework = scan_result['framework']
        files = scan_result['files']
        
        if framework:
            console.print(f"[green]✓ Detected framework:[/green] {framework}")
        console.print(f"[green]✓ Found {len(files)} route/controller files[/green]")
        
        if len(files) == 0:
            console.print("[yellow]⚠ No route files found. Exiting.[/yellow]")
            sys.exit(0)
        
        # Step 2: Verify API key
        console.print("\n[cyan]Verifying API key...[/cyan]")
        client = GendocClient(api_key)
        auth_info = client.verify_key()
        console.print(f"[green]✓ Authenticated[/green] ({auth_info.get('plan', 'free')} plan)")
        console.print(f"[dim]Credits remaining: {auth_info.get('credits_remaining', 'unknown')}[/dim]")
        
        # Step 3: Start agent session
        console.print("\n[cyan]Starting AI analysis...[/cyan]")
        start_resp = client.start_session(files, framework, args.prompt)
        
        if start_resp.get('status') != 'started':
            console.print(f"[red]✗ Unexpected response: {start_resp}[/red]")
            sys.exit(1)
        
        # Step 4: Iterative file analysis
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            console=console
        ) as progress:
            task = progress.add_task("Analyzing files...", total=None)
            
            files_sent = 0
            requested_file = start_resp.get('requested_file')
            doc_data = None
            
            while requested_file:
                files_sent += 1
                progress.update(task, description=f"Analyzing {requested_file} ({files_sent}/{len(files)})")
                
                file_path = project_path / requested_file
                if not file_path.exists():
                    console.print(f"[yellow]⚠ File not found: {requested_file}[/yellow]")
                    break
                
                try:
                    file_content = file_path.read_text(encoding='utf-8')
                except Exception as e:
                    console.print(f"[yellow]⚠ Could not read {requested_file}: {e}[/yellow]")
                    break
                
                resp = client.continue_session(requested_file, file_content)
                status = resp.get('status')
                
                if status == 'need_file':
                    requested_file = resp.get('requested_file')
                elif status == 'complete':
                    progress.update(task, description="Analysis complete")
                    doc_data = resp.get('documentation')
                    break
                elif status == 'limit_reached':
                    progress.update(task, description="Credit limit reached")
                    console.print("\n[yellow]⚠ Credit limit reached. Generating partial documentation...[/yellow]")
                    doc_data = resp.get('documentation')
                    break
                else:
                    console.print(f"[red]✗ Unexpected status: {status}[/red]")
                    sys.exit(1)
        
        if not doc_data:
            console.print("[red]✗ No documentation generated[/red]")
            sys.exit(1)
        
        # Step 5: Generate HTML
        console.print("\n[cyan]Generating HTML documentation...[/cyan]")
        html = build_html(doc_data)
        
        output_path = project_path / args.output
        output_path.write_text(html, encoding='utf-8')
        console.print(f"[green]✓ Documentation saved:[/green] {output_path}")
        
        # Step 6: Integrate (optional)
        if args.integrate:
            console.print("\n[cyan]Integrating with framework...[/cyan]")
            if integrate_docs_route(project_path, framework, args.output):
                console.print(f"[green]✓ Added /docs route to {framework}[/green]")
            else:
                console.print(f"[yellow]⚠ Could not integrate with {framework or 'unknown framework'}[/yellow]")
        
        console.print("\n[bold green]✓ Done![/bold green]")
        
    except GendocAPIError as e:
        console.print(f"[red]✗ API Error: {e}[/red]")
        sys.exit(1)
    except KeyboardInterrupt:
        console.print("\n[yellow]⚠ Cancelled by user[/yellow]")
        if 'client' in locals():
            client.cancel_session()
        sys.exit(0)
    except Exception as e:
        console.print(f"[red]✗ Error: {e}[/red]")
        sys.exit(1)
