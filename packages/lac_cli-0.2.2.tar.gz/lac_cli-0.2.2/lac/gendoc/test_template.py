#!/usr/bin/env python3
"""Test the template builder with sample data"""

import json
from lac.gendoc.templates import build_html

# Sample data matching backend JSON schema
sample_data = {
    "title": "My API",
    "version": "v1.0",
    "baseUrl": "https://api.example.com/v1",
    "sections": [
        {
            "id": "users",
            "title": "Users",
            "icon": "ph:users-three",
            "description": "Manage user accounts in your organization",
            "endpoints": [
                {
                    "method": "GET",
                    "path": "/users",
                    "description": "List all users",
                    "parameters": [
                        {
                            "name": "limit",
                            "in": "query",
                            "type": "integer",
                            "required": False,
                            "description": "Number of results to return",
                            "default": "20"
                        },
                        {
                            "name": "offset",
                            "in": "query",
                            "type": "integer",
                            "required": False,
                            "description": "Number of results to skip",
                            "default": "0"
                        }
                    ],
                    "responses": [
                        {
                            "status": "200",
                            "body": {
                                "data": [
                                    {
                                        "id": "usr_123",
                                        "name": "John Doe",
                                        "email": "john@example.com"
                                    }
                                ],
                                "total": 42,
                                "limit": 20,
                                "offset": 0
                            }
                        },
                        {
                            "status": "401",
                            "body": {
                                "error": {
                                    "code": "unauthorized",
                                    "message": "Invalid API key"
                                }
                            }
                        }
                    ]
                },
                {
                    "method": "POST",
                    "path": "/users",
                    "description": "Create a new user",
                    "requestBody": {
                        "properties": [
                            {
                                "name": "name",
                                "type": "string",
                                "required": True,
                                "description": "Full name of the user"
                            },
                            {
                                "name": "email",
                                "type": "string",
                                "required": True,
                                "description": "Email address"
                            }
                        ],
                        "example": {
                            "name": "Jane Smith",
                            "email": "jane@example.com"
                        }
                    },
                    "responses": [
                        {
                            "status": "201",
                            "body": {
                                "id": "usr_456",
                                "name": "Jane Smith",
                                "email": "jane@example.com",
                                "created_at": "2024-01-15T10:30:00Z"
                            }
                        }
                    ]
                },
                {
                    "method": "GET",
                    "path": "/users/{id}",
                    "description": "Get a specific user",
                    "parameters": [
                        {
                            "name": "id",
                            "in": "path",
                            "type": "string",
                            "required": True,
                            "description": "User ID",
                            "example": "usr_123"
                        }
                    ],
                    "responses": [
                        {
                            "status": "200",
                            "body": {
                                "id": "usr_123",
                                "name": "John Doe",
                                "email": "john@example.com",
                                "created_at": "2024-01-10T08:00:00Z"
                            }
                        }
                    ]
                }
            ]
        },
        {
            "id": "projects",
            "title": "Projects",
            "icon": "ph:folder-notch",
            "description": "Manage projects and workspaces",
            "endpoints": [
                {
                    "method": "GET",
                    "path": "/projects",
                    "description": "List all projects",
                    "parameters": [],
                    "responses": [
                        {
                            "status": "200",
                            "body": {
                                "data": [
                                    {
                                        "id": "prj_789",
                                        "name": "My Project",
                                        "created_at": "2024-01-01T00:00:00Z"
                                    }
                                ]
                            }
                        }
                    ]
                }
            ]
        }
    ]
}

if __name__ == "__main__":
    print("Generating HTML from sample data...")
    html = build_html(sample_data)
    
    # Write to file
    output_path = "test-output.html"
    with open(output_path, "w") as f:
        f.write(html)
    
    print(f"✓ Generated {len(html)} characters")
    print(f"✓ Saved to {output_path}")
    print(f"✓ Open in browser to test")
