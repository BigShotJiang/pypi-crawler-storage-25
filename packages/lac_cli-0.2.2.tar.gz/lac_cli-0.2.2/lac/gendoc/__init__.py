"""
lac gendoc - AI-powered API documentation generator
"""

__version__ = "0.1.0"
