"""
Scanner module - detects framework and finds route/controller files
"""

from pathlib import Path
from typing import List, Dict, Optional

EXCLUDE_DIRS = {
    'node_modules', 'vendor', '.git', 'dist', 'build', 
    '__pycache__', '.venv', 'venv', 'env'
}

FRAMEWORK_SIGNATURES = {
    'laravel': ['artisan', 'composer.json'],
    'django': ['manage.py'],
    'fastapi': ['main.py', 'app.py'],
    'flask': ['app.py', 'wsgi.py'],
    'express': ['package.json'],
    'rails': ['Gemfile', 'config.ru']
}

ROUTE_PATTERNS = {
    'laravel': ['routes/*.php', 'app/Http/Controllers/*.php'],
    'django': ['**/urls.py', '**/views.py'],
    'fastapi': ['**/*main.py', '**/*app.py', '**/routers/*.py'],
    'flask': ['**/*app.py', '**/routes/*.py', '**/views/*.py'],
    'express': ['**/routes/*.js', '**/controllers/*.js', '**/app.js'],
    'rails': ['config/routes.rb', 'app/controllers/*.rb']
}

def detect_framework(project_path: Path) -> Optional[str]:
    """Detect framework by checking for signature files"""
    for framework, signatures in FRAMEWORK_SIGNATURES.items():
        if all((project_path / sig).exists() for sig in signatures):
            return framework
    return None

def find_route_files(project_path: Path, framework: Optional[str]) -> List[Path]:
    """Find all route and controller files"""
    files = []
    
    if framework and framework in ROUTE_PATTERNS:
        patterns = ROUTE_PATTERNS[framework]
        for pattern in patterns:
            files.extend(project_path.glob(pattern))
    else:
        # Generic fallback - find common route file patterns
        for ext in ['*.py', '*.php', '*.js', '*.rb']:
            for file in project_path.rglob(ext):
                if any(excluded in file.parts for excluded in EXCLUDE_DIRS):
                    continue
                if any(keyword in file.name.lower() for keyword in ['route', 'controller', 'api', 'endpoint']):
                    files.append(file)
    
    # Remove duplicates and excluded dirs
    unique_files = []
    seen = set()
    for f in files:
        if any(excluded in f.parts for excluded in EXCLUDE_DIRS):
            continue
        if f.resolve() not in seen:
            seen.add(f.resolve())
            unique_files.append(f)
    
    return unique_files

def get_file_list(project_path: Path) -> Dict:
    """Get framework info and file list"""
    framework = detect_framework(project_path)
    files = find_route_files(project_path, framework)
    
    return {
        'framework': framework,
        'project_path': str(project_path),
        'files': [str(f.relative_to(project_path)) for f in files]
    }
