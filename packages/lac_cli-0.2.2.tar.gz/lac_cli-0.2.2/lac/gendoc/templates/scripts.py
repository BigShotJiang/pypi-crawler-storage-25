def get_scripts():
    return """<script>
function toggleEndpoint(header) {
  const ep = header.closest('.endpoint');
  ep.classList.toggle('open');
}

function switchRes(btn, panelId) {
  const wrap = btn.closest('.endpoint-body') || btn.closest('.panel-body');
  wrap.querySelectorAll('.res-tab').forEach(t => t.classList.remove('active'));
  btn.classList.add('active');
  const tabsParent = btn.parentElement;
  const body = tabsParent.parentElement;
  body.querySelectorAll('.res-panel').forEach(p => p.classList.remove('active'));
  const target = document.getElementById(panelId);
  if (target) target.classList.add('active');
}

function copyCode(id) {
  const pre = document.getElementById(id);
  if (!pre) return;
  const text = pre.innerText || pre.textContent;
  navigator.clipboard.writeText(text).then(() => showToast());
}

function showToast() {
  const t = document.getElementById('toast');
  t.classList.add('show');
  setTimeout(() => t.classList.remove('show'), 2000);
}

let panelState = {};

function openPanel(e, method, path, pathParams, body) {
  e.stopPropagation();
  panelState = { method, path, pathParams, body };

  document.getElementById('panelMethod').textContent = method;
  document.getElementById('panelMethod').className = `method-pill method-${method}`;
  document.getElementById('panelPath').textContent = path;

  const qFields = document.getElementById('panelQueryFields');
  const bFields = document.getElementById('panelBodyFields');
  qFields.innerHTML = '';
  bFields.innerHTML = '';

  if (pathParams && pathParams.length > 0) {
    qFields.innerHTML = `<div class="panel-label">Path Parameters</div>`;
    pathParams.forEach(p => {
      qFields.innerHTML += `
        <div class="panel-field">
          <div class="panel-label" style="text-transform:none; font-size:12px; color:var(--text)">${p.name} <span style="color:var(--text3); font-size:11px; font-family:var(--mono)">string</span></div>
          <input class="panel-input" type="text" placeholder="${p.placeholder || p.name}" id="param_${p.name}">
        </div>`;
    });
  }

  if (body !== null) {
    bFields.innerHTML = `<div class="panel-label">Request Body</div>
      <div class="panel-field">
        <textarea class="panel-textarea" id="panelBodyText" spellcheck="false">${JSON.stringify(body, null, 2)}</textarea>
      </div>`;
  }

  document.getElementById('responseSection').style.display = 'none';
  document.getElementById('tryPanel').classList.add('open');
  document.getElementById('mainContent').classList.add('panel-open');
}

function closePanel() {
  document.getElementById('tryPanel').classList.remove('open');
  document.getElementById('mainContent').classList.remove('panel-open');
}

function sendRequest() {
  const btn = document.getElementById('sendBtn');
  const resSection = document.getElementById('responseSection');
  const output = document.getElementById('responseOutput');
  const pill = document.getElementById('resStatusPill');
  const time = document.getElementById('resTime');

  btn.disabled = true;
  btn.innerHTML = `<span class="spin"></span> Sending...`;
  resSection.style.display = 'none';

  const start = Date.now();
  const baseUrl = document.getElementById('panelBaseUrl').value.trim();
  let path = panelState.path;

  if (panelState.pathParams) {
    panelState.pathParams.forEach(p => {
      const val = document.getElementById(`param_${p.name}`)?.value.trim();
      if (val) path = path.replace(`{${p.name}}`, val);
    });
  }

  const fullUrl = baseUrl + path;
  const auth = document.getElementById('panelAuth').value.trim();
  const headers = { 'Content-Type': 'application/json' };
  if (auth) headers['Authorization'] = auth;

  let opts = { method: panelState.method, headers };
  if (panelState.body !== null) {
    try {
      const bodyText = document.getElementById('panelBodyText')?.value;
      if (bodyText) opts.body = bodyText;
    } catch(e) {}
  }

  fetch(fullUrl, opts)
    .then(res => {
      const elapsed = Date.now() - start;
      time.textContent = `${elapsed}ms`;
      const statusColor = res.status < 300 ? '#18794e' : res.status < 500 ? '#ad5700' : '#cd2b31';
      const statusBg = res.status < 300 ? '#effaf4' : res.status < 500 ? '#fff1e0' : '#fdecea';
      pill.textContent = `${res.status} ${res.statusText}`;
      pill.style.cssText = `background:${statusBg}; color:${statusColor}; font-family:var(--mono); font-size:11px; font-weight:500; padding:3px 8px; border-radius:4px;`;
      return res.text();
    })
    .then(text => {
      try { output.textContent = JSON.stringify(JSON.parse(text), null, 2); }
      catch { output.textContent = text; }
      resSection.style.display = 'block';
    })
    .catch(err => {
      const elapsed = Date.now() - start;
      time.textContent = `${elapsed}ms`;
      pill.textContent = 'Network Error';
      pill.style.cssText = `background:#fdecea; color:#cd2b31; font-family:var(--mono); font-size:11px; font-weight:500; padding:3px 8px; border-radius:4px;`;
      output.textContent = `Could not reach ${fullUrl}\\n\\nMake sure the API is running and accessible.`;
      resSection.style.display = 'block';
    })
    .finally(() => {
      btn.disabled = false;
      btn.innerHTML = `<span class="iconify" data-icon="ph:paper-plane-tilt"></span> Send Request`;
    });
}

function setActive(el, e) {
  if (e) e.preventDefault();
  document.querySelectorAll('.sidebar-item').forEach(i => i.classList.remove('active'));
  el.classList.add('active');
  const target = document.querySelector(el.getAttribute('href'));
  if (target) {
    target.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }
}

function filterSidebar(val) {
  const q = val.toLowerCase();
  document.querySelectorAll('.sidebar-item').forEach(item => {
    const text = item.textContent.toLowerCase();
    item.style.display = text.includes(q) ? '' : 'none';
  });
  document.querySelectorAll('.sidebar-group').forEach(group => {
    const items = group.querySelectorAll('.sidebar-item');
    const anyVisible = [...items].some(i => i.style.display !== 'none');
    group.style.display = anyVisible ? '' : 'none';
  });
}

document.addEventListener('scroll', () => {
  const sections = document.querySelectorAll('.section');
  sections.forEach(sec => {
    const rect = sec.getBoundingClientRect();
    if (rect.top <= 80 && rect.bottom >= 80) {
      const id = sec.getAttribute('id');
      document.querySelectorAll('.sidebar-item').forEach(item => {
        item.classList.toggle('active', item.getAttribute('href') === `#${id}`);
      });
    }
  });
}, { passive: true });

function exportSwagger() {
  const docData = JSON.parse(document.getElementById('doc-data').textContent);
  const spec = {
    openapi: '3.0.0',
    info: {
      title: docData.title || 'API Documentation',
      version: docData.version || '1.0.0'
    },
    servers: [{ url: docData.baseUrl }],
    paths: {}
  };
  
  docData.sections.forEach(section => {
    section.endpoints.forEach(endpoint => {
      if (!spec.paths[endpoint.path]) spec.paths[endpoint.path] = {};
      
      const operation = {
        summary: endpoint.description,
        tags: [section.title],
        parameters: [],
        responses: {}
      };
      
      if (endpoint.parameters) {
        endpoint.parameters.forEach(param => {
          operation.parameters.push({
            name: param.name,
            in: param.in || 'query',
            required: param.required || false,
            schema: { type: param.type || 'string' },
            description: param.description
          });
        });
      }
      
      if (endpoint.requestBody) {
        operation.requestBody = {
          content: {
            'application/json': {
              schema: { type: 'object' }
            }
          }
        };
      }
      
      if (endpoint.responses) {
        endpoint.responses.forEach(res => {
          operation.responses[res.status] = {
            description: res.description || 'Response',
            content: {
              'application/json': {
                example: res.example
              }
            }
          };
        });
      }
      
      spec.paths[endpoint.path][endpoint.method.toLowerCase()] = operation;
    });
  });
  
  const blob = new Blob([JSON.stringify(spec, null, 2)], { type: 'application/json' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = 'openapi.json';
  a.click();
  showToast();
}

function exportPostman() {
  const docData = JSON.parse(document.getElementById('doc-data').textContent);
  const collection = {
    info: {
      name: docData.title || 'API Documentation',
      schema: 'https://schema.getpostman.com/json/collection/v2.1.0/collection.json'
    },
    item: []
  };
  
  docData.sections.forEach(section => {
    const folder = {
      name: section.title,
      item: []
    };
    
    section.endpoints.forEach(endpoint => {
      const url = new URL(endpoint.path, docData.baseUrl);
      
      const request = {
        name: endpoint.description,
        request: {
          method: endpoint.method,
          header: [{ key: 'Content-Type', value: 'application/json' }],
          url: {
            raw: url.href,
            protocol: url.protocol.replace(':', ''),
            host: url.hostname.split('.'),
            path: url.pathname.split('/').filter(p => p)
          }
        }
      };
      
      if (endpoint.requestBody && endpoint.requestBody.example) {
        request.request.body = {
          mode: 'raw',
          raw: JSON.stringify(endpoint.requestBody.example, null, 2)
        };
      }
      
      folder.item.push(request);
    });
    
    collection.item.push(folder);
  });
  
  const blob = new Blob([JSON.stringify(collection, null, 2)], { type: 'application/json' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = 'postman_collection.json';
  a.click();
  showToast();
}

const resizeObserver = new ResizeObserver(entries => {
  for (let entry of entries) {
    const main = document.getElementById('mainContent');
    if (main) {
      main.style.marginLeft = entry.target.offsetWidth + 'px';
    }
  }
});
const sidebar = document.getElementById('sidebar');
if (sidebar) resizeObserver.observe(sidebar);

const resizeHandle = document.getElementById('resizeHandle');
if (resizeHandle) {
  let isResizing = false;
  let startX = 0;
  let startWidth = 0;
  
  resizeHandle.addEventListener('mousedown', (e) => {
    isResizing = true;
    startX = e.clientX;
    startWidth = sidebar.offsetWidth;
    document.body.style.cursor = 'ew-resize';
    document.body.style.userSelect = 'none';
    e.preventDefault();
  });
  
  document.addEventListener('mousemove', (e) => {
    if (!isResizing) return;
    const delta = e.clientX - startX;
    const newWidth = Math.max(180, Math.min(400, startWidth + delta));
    sidebar.style.width = newWidth + 'px';
  });
  
  document.addEventListener('mouseup', () => {
    if (isResizing) {
      isResizing = false;
      document.body.style.cursor = '';
      document.body.style.userSelect = '';
    }
  });
}
</script>"""
