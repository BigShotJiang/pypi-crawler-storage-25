def get_base_html(title, version, base_url, sections_html):
    return f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>{title}</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=IBM+Plex+Sans:wght@400;500&family=IBM+Plex+Mono:wght@400;500&display=swap" rel="stylesheet">
<script src="https://code.iconify.design/3/3.1.0/iconify.min.js"></script>
{get_styles()}
</head>
<body>
{get_toast()}
{get_header(title, version)}
{get_sidebar(sections_html)}
{get_try_panel(base_url)}
<main id="mainContent">
<div class="content">
{sections_html}
</div>
</main>
{get_scripts()}
</body>
</html>"""
