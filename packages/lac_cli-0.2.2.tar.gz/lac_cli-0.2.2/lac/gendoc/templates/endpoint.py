import json

def format_json(data):
    """Format JSON with syntax highlighting"""
    if isinstance(data, str):
        try:
            data = json.loads(data)
        except:
            return data
    
    json_str = json.dumps(data, indent=2)
    
    # Simple syntax highlighting
    json_str = json_str.replace('"', '<span class="t-key">"', 1)
    json_str = json_str.replace('": ', '"</span>: ')
    json_str = json_str.replace(': "', ': <span class="t-str">"')
    json_str = json_str.replace('",', '"</span>,')
    json_str = json_str.replace('"\\n', '"</span>\\n')
    json_str = json_str.replace(': true', ': <span class="t-bool">true</span>')
    json_str = json_str.replace(': false', ': <span class="t-bool">false</span>')
    json_str = json_str.replace(': null', ': <span class="t-bool">null</span>')
    
    # Highlight numbers
    import re
    json_str = re.sub(r': (\d+)', r': <span class="t-num">\1</span>', json_str)
    
    return json_str

def get_params_table(params, param_type="query"):
    """Generate parameter table HTML"""
    if not params:
        return ""
    
    rows = ""
    for param in params:
        name = param.get('name', '')
        type_val = param.get('type', 'string')
        required = param.get('required', False)
        description = param.get('description', '')
        default = param.get('default', '')
        
        required_badge = '<span class="required-badge">required</span>' if required else ''
        default_text = f" Default: <code>{default}</code>" if default else ""
        
        rows += f"""          <tr>
            <td><code>{name}</code>{required_badge}</td>
            <td><span class="type-badge">{type_val}</span></td>
            <td class="param-desc">{description}{default_text}</td>
          </tr>
"""
    
    label = "Query Parameters" if param_type == "query" else "Path Parameters" if param_type == "path" else "Body Parameters"
    
    return f"""        <div class="param-label">{label}</div>
        <table class="params-table">
{rows}        </table>
"""

def get_response_html(responses):
    """Generate response tabs and panels"""
    if not responses:
        return ""
    
    tabs = ""
    panels = ""
    
    for idx, response in enumerate(responses):
        status = response.get('status', '200')
        body = response.get('body', {})
        active = "active" if idx == 0 else ""
        
        tabs += f'          <button class="res-tab {active}" onclick="switchRes(this, \'res-{status}\')">{status}</button>\n'
        
        formatted_json = format_json(body)
        
        panels += f"""        <div class="res-panel {active}" id="res-{status}">
          <div class="code-wrap">
            <div class="code-header">
              <div></div>
              <button class="copy-btn" onclick="copyCode('res-{status}-code')">
                <span class="iconify" data-icon="ph:copy"></span>copy
              </button>
            </div>
            <pre id="res-{status}-code"><code>{formatted_json}</code></pre>
          </div>
        </div>
"""
    
    return f"""        <div class="param-label">Response</div>
        <div class="res-tabs">
{tabs}        </div>
{panels}"""

def get_endpoint_card(endpoint, section_id):
    """Generate a single endpoint card"""
    method = endpoint.get('method', 'GET').upper()
    path = endpoint.get('path', '/')
    description = endpoint.get('description', '')
    parameters = endpoint.get('parameters', [])
    request_body = endpoint.get('requestBody', None)
    responses = endpoint.get('responses', [])
    
    # Separate path and query params
    path_params = [p for p in parameters if p.get('in') == 'path']
    query_params = [p for p in parameters if p.get('in') == 'query']
    body_params = []
    
    if request_body:
        body_params = request_body.get('properties', [])
    
    # Generate params tables
    path_table = get_params_table(path_params, "path") if path_params else ""
    query_table = get_params_table(query_params, "query") if query_params else ""
    body_table = get_params_table(body_params, "body") if body_params else ""
    
    # Generate response HTML
    response_html = get_response_html(responses)
    
    # Prepare try-it button data
    path_params_json = json.dumps([{"name": p['name'], "placeholder": p.get('example', p['name'])} for p in path_params])
    body_json = json.dumps(request_body.get('example', {})) if request_body else "null"
    
    endpoint_id = f"{section_id}-{method.lower()}-{path.replace('/', '-').replace('{', '').replace('}', '')}"
    
    return f"""    <div class="endpoint" id="{endpoint_id}">
      <div class="endpoint-header" onclick="toggleEndpoint(this)">
        <div class="endpoint-header-left">
          <span class="method-pill method-{method}">{method}</span>
          <span class="endpoint-path">{path}</span>
          <span class="endpoint-summary" style="margin-left: 8px;">{description}</span>
        </div>
        <div class="endpoint-header-right">
          <button class="try-btn" onclick="openPanel(event, '{method}', '{path}', {path_params_json}, {body_json})">
            <span class="iconify" data-icon="ph:play"></span>
            Try it
          </button>
          <span class="iconify chevron" data-icon="ph:caret-down"></span>
        </div>
      </div>
      <div class="endpoint-body">
{path_table}{query_table}{body_table}{response_html}
      </div>
    </div>
"""
