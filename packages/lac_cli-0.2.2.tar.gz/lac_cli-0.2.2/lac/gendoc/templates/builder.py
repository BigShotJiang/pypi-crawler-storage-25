from lac.gendoc.templates.styles import get_styles
from lac.gendoc.templates.header import get_header, get_toast
from lac.gendoc.templates.sidebar import get_sidebar
from lac.gendoc.templates.panel import get_try_panel
from lac.gendoc.templates.section import get_section
from lac.gendoc.templates.scripts import get_scripts

def build_html(data):
    """
    Build complete HTML from backend JSON data
    
    Expected data structure:
    {
        "title": "API Reference",
        "version": "v1",
        "baseUrl": "https://api.example.com",
        "sections": [
            {
                "id": "users",
                "title": "Users",
                "icon": "ph:users-three",
                "description": "Manage user accounts",
                "endpoints": [
                    {
                        "method": "GET",
                        "path": "/users",
                        "description": "List all users",
                        "parameters": [...],
                        "responses": [...]
                    }
                ]
            }
        ]
    }
    """
    title = data.get('title', 'API Reference')
    version = data.get('version', 'v1')
    base_url = data.get('baseUrl', 'https://api.example.com')
    sections = data.get('sections', [])
    
    # Build sections HTML
    sections_html = ""
    for section in sections:
        sections_html += get_section(section)
    
    # Embed documentation data for exports
    import json
    doc_data_json = json.dumps(data).replace('<', '\\u003c').replace('>', '\\u003e')
    
    # Build complete HTML
    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>{title}</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=IBM+Plex+Sans:wght@400;500&family=IBM+Plex+Mono:wght@400;500&display=swap" rel="stylesheet">
<script src="https://code.iconify.design/3/3.1.0/iconify.min.js"></script>
<script id="doc-data" type="application/json">{doc_data_json}</script>
{get_styles()}
</head>
<body>
{get_toast()}
{get_header(title, version)}
{get_sidebar(sections)}
{get_try_panel(base_url)}
<main id="mainContent">
<div class="content">
{sections_html}
</div>
</main>
{get_scripts()}
</body>
</html>"""
    
    return html
