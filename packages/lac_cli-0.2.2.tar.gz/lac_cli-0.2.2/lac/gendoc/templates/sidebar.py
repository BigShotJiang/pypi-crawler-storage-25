def get_sidebar(sections_data):
    """Generate sidebar navigation from sections data"""
    items_html = ""
    
    for section in sections_data:
        icon = section.get('icon', 'ph:folder-notch')
        section_id = section.get('id', '')
        title = section.get('title', '')
        
        items_html += f"""    <a class="sidebar-item" href="#{section_id}" onclick="setActive(this, event); return false;" title="{title}">
      <span class="iconify" data-icon="{icon}"></span>
      <span>{title}</span>
    </a>
"""
    
    return f"""<aside id="sidebar">
  <div class="sidebar-resize-handle" id="resizeHandle"></div>
  <div class="sidebar-nav">
    <div class="sidebar-search">
      <div class="sidebar-search-wrap">
        <span class="iconify search-icon" data-icon="ph:magnifying-glass"></span>
        <input type="text" placeholder="Search endpoints..." oninput="filterSidebar(this.value)" id="sidebarSearch">
      </div>
    </div>
    <div class="sidebar-group">
      <div class="sidebar-label">Endpoints</div>
{items_html}    </div>
  </div>
</aside>"""
