def get_header(title, version):
    return f"""<header>
  <div class="header-left">
    <div class="logo-mark">
      <span class="iconify" data-icon="ph:brackets-curly-bold"></span>
    </div>
    <span class="logo-text">{title}</span>
    <span class="logo-badge">{version}</span>
  </div>
  <div class="header-right">
    <button class="header-btn" onclick="exportSwagger()">
      <span class="iconify" data-icon="ph:file-code"></span>
      Swagger
    </button>
    <button class="header-btn" onclick="exportPostman()">
      <span class="iconify" data-icon="ph:export"></span>
      Postman
    </button>
  </div>
</header>"""

def get_toast():
    return """<div class="toast" id="toast">
  <span class="iconify" data-icon="ph:check-circle-fill"></span>
  Copied to clipboard
</div>"""
