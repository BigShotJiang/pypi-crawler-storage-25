def get_try_panel(base_url):
    return f"""<div class="try-panel" id="tryPanel">
  <div class="panel-header">
    <div class="panel-title">
      <span class="method-pill" id="panelMethod">GET</span>
      <span style="font-family: var(--mono); font-size: 12px; color: var(--text2);" id="panelPath">/</span>
    </div>
    <div class="panel-close" onclick="closePanel()">
      <span class="iconify" data-icon="ph:x"></span>
    </div>
  </div>
  <div class="panel-body">
    <div class="panel-field">
      <div class="panel-label">Base URL</div>
      <input class="panel-input" type="text" value="{base_url}" id="panelBaseUrl">
    </div>
    <div class="panel-field">
      <div class="panel-label">Authorization</div>
      <input class="panel-input" type="text" placeholder="Bearer your-api-key" id="panelAuth">
    </div>
    <div id="panelQueryFields"></div>
    <div id="panelBodyFields"></div>
  </div>
  <div class="panel-footer">
    <button class="send-btn" id="sendBtn" onclick="sendRequest()">
      <span class="iconify" data-icon="ph:paper-plane-tilt"></span>
      Send Request
    </button>
    <div class="response-section" id="responseSection" style="display:none">
      <div class="res-header-bar">
        <div>
          <span class="res-status-pill" id="resStatusPill"></span>
        </div>
        <span class="res-time" id="resTime"></span>
      </div>
      <div class="response-output" id="responseOutput"></div>
    </div>
  </div>
</div>"""
