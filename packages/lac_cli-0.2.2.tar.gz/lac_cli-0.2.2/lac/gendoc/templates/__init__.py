from lac.gendoc.templates.builder import build_html

__all__ = ['build_html']
