def get_styles():
    return """<style>
*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

:root {
  --bg: #ffffff;
  --bg2: #f9f9f8;
  --bg3: #f4f4f3;
  --sidebar-bg: #111110;
  --sidebar-text: #878680;
  --sidebar-active: #ffffff;
  --sidebar-hover: #1c1c1a;
  --border: #e8e7e4;
  --border2: #d4d3cf;
  --text: #1c1c1a;
  --text2: #6f6e6b;
  --text3: #a3a29f;
  --accent: #18794e;
  --accent-bg: #effaf4;
  --accent-border: #b4e8c9;
  --code-bg: #f4f4f3;
  --get: #18794e;
  --get-bg: #effaf4;
  --post: #0066cc;
  --post-bg: #e8f1fd;
  --delete: #cd2b31;
  --delete-bg: #fdecea;
  --patch: #9d5bd2;
  --patch-bg: #f5eefe;
  --put: #ad5700;
  --put-bg: #fff1e0;
  --font: 'IBM Plex Sans', system-ui, sans-serif;
  --mono: 'IBM Plex Mono', 'Courier New', monospace;
  --radius: 6px;
}

html { font-size: 14px; }
body { font-family: var(--font); background: var(--bg); color: var(--text); line-height: 1.6; }

::-webkit-scrollbar { width: 5px; height: 5px; }
::-webkit-scrollbar-track { background: transparent; }
::-webkit-scrollbar-thumb { background: var(--border2); border-radius: 10px; }

header {
  position: fixed; top: 0; left: 0; right: 0; height: 52px;
  background: var(--sidebar-bg); display: flex; align-items: center;
  justify-content: space-between; padding: 0 20px; z-index: 100;
  border-bottom: 1px solid #222220;
}
.header-left {
  display: flex; align-items: center; gap: 8px;
}
.logo-mark {
  width: 26px; height: 26px; background: var(--accent);
  border-radius: 5px; display: flex; align-items: center; justify-content: center;
  flex-shrink: 0;
}
.logo-mark .iconify { color: white; font-size: 14px; }
.logo-text { color: #fff; font-size: 13px; font-weight: 500; letter-spacing: -0.01em; }
.logo-badge {
  font-size: 10px; font-family: var(--mono); color: var(--sidebar-text);
  background: #1c1c1a; border: 1px solid #2e2e2c; border-radius: 3px;
  padding: 1px 5px; margin-left: 4px;
}
.header-right { display: flex; align-items: center; gap: 6px; margin-left: auto; }
.header-btn {
  display: flex; align-items: center; gap: 6px; padding: 5px 10px;
  background: transparent; border: 1px solid #2e2e2c; border-radius: var(--radius);
  color: #a3a29f; font-size: 12px; font-family: var(--font); cursor: pointer;
  transition: all .15s; white-space: nowrap;
}
.header-btn:hover { background: #1c1c1a; color: #d4d3cf; border-color: #3e3e3c; }
.header-btn .iconify { font-size: 13px; }

aside {
  position: fixed; left: 0; top: 52px; bottom: 0; width: 240px;
  background: var(--sidebar-bg); z-index: 90;
  border-right: 1px solid #1e1e1c; display: flex; flex-direction: column;
  min-width: 180px; max-width: 400px;
}
.sidebar-resize-handle {
  position: absolute; right: 0; top: 0; bottom: 0; width: 4px;
  cursor: ew-resize; z-index: 10; background: transparent;
  transition: background .15s;
}
.sidebar-resize-handle:hover { background: var(--accent); }
.sidebar-nav {
  flex: 1; overflow-y: auto; overflow-x: hidden; padding-bottom: 40px;
}
.sidebar-search {
  padding: 12px 12px 8px; background: var(--sidebar-bg);
  border-bottom: 1px solid #1e1e1c; flex-shrink: 0;
}
.sidebar-search input {
  width: 100%; background: #1a1a18; border: 1px solid #2e2e2c;
  border-radius: var(--radius); padding: 7px 10px 7px 30px;
  color: #d4d3cf; font-size: 12px; font-family: var(--font); outline: none;
}
.sidebar-search input::placeholder { color: #4a4a48; }
.sidebar-search input:focus { border-color: #3e3e3c; }
.search-icon {
  position: absolute; left: 22px; top: 50%; transform: translateY(-50%);
  color: #4a4a48; font-size: 13px; pointer-events: none;
}
.sidebar-search-wrap { position: relative; }
.sidebar-group { padding: 16px 0 4px; }
.sidebar-label {
  font-size: 10px; font-weight: 500; letter-spacing: 0.08em;
  text-transform: uppercase; color: #3e3e3c; padding: 0 12px 6px;
}
.sidebar-item {
  display: flex; align-items: center; gap: 8px; padding: 6px 12px;
  color: var(--sidebar-text); font-size: 12.5px; text-decoration: none;
  cursor: pointer; transition: all .12s; border-radius: 0;
  border-left: 2px solid transparent; user-select: none;
  overflow: hidden; text-overflow: ellipsis; white-space: nowrap;
}
.sidebar-item span:not(.iconify):not(.sidebar-item-badge) {
  overflow: hidden; text-overflow: ellipsis; white-space: nowrap;
}
.sidebar-item:hover { background: var(--sidebar-hover); color: #c4c3bf; }
.sidebar-item.active { background: var(--sidebar-hover); color: var(--sidebar-active); border-left-color: var(--accent); }
.sidebar-item .iconify { font-size: 14px; flex-shrink: 0; opacity: .7; }
.sidebar-item.active .iconify { opacity: 1; }
.sidebar-item-badge {
  margin-left: auto; font-size: 9px; font-family: var(--mono);
  padding: 1px 5px; border-radius: 3px; font-weight: 500; letter-spacing: .02em;
}
.sidebar-divider { height: 1px; background: #1e1e1c; margin: 8px 12px; }

main {
  margin-left: 240px; padding: 0; min-height: 100vh; padding-top: 52px;
  transition: margin-left .15s, margin-right .3s;
}
main.panel-open { margin-right: 420px; }
.content { max-width: 780px; padding: 44px 48px 80px; }

.section { margin-bottom: 64px; }
.section-title {
  font-size: 22px; font-weight: 500; letter-spacing: -0.02em;
  color: var(--text); margin-bottom: 8px; padding-bottom: 16px;
  border-bottom: 1px solid var(--border);
}
.section-desc { font-size: 14px; color: var(--text2); margin-bottom: 24px; line-height: 1.7; }

.endpoint {
  border: 1px solid var(--border); border-radius: 8px; margin-bottom: 16px;
  overflow: hidden; transition: border-color .15s;
}
.endpoint:hover { border-color: var(--border2); }
.endpoint-header {
  display: flex; align-items: center; justify-content: space-between;
  padding: 14px 18px; cursor: pointer; user-select: none;
  background: var(--bg); transition: background .12s;
}
.endpoint-header:hover { background: var(--bg2); }
.endpoint-header-left { display: flex; align-items: center; gap: 12px; }
.method-pill {
  font-family: var(--mono); font-size: 11px; font-weight: 500;
  padding: 3px 8px; border-radius: 4px; letter-spacing: .04em;
}
.method-GET { background: var(--get-bg); color: var(--get); }
.method-POST { background: var(--post-bg); color: var(--post); }
.method-DELETE { background: var(--delete-bg); color: var(--delete); }
.method-PATCH { background: var(--patch-bg); color: var(--patch); }
.method-PUT { background: var(--put-bg); color: var(--put); }
.endpoint-path { font-family: var(--mono); font-size: 13px; color: var(--text); }
.endpoint-summary { font-size: 12.5px; color: var(--text2); }
.endpoint-header-right { display: flex; align-items: center; gap: 8px; }
.try-btn {
  display: flex; align-items: center; gap: 5px; font-size: 12px;
  color: var(--text2); background: var(--bg3); border: 1px solid var(--border);
  border-radius: var(--radius); padding: 5px 10px; cursor: pointer;
  font-family: var(--font); transition: all .15s; white-space: nowrap;
}
.try-btn:hover { background: var(--accent); color: white; border-color: var(--accent); }
.try-btn .iconify { font-size: 13px; }
.chevron { font-size: 14px; color: var(--text3); transition: transform .2s; }
.endpoint.open .chevron { transform: rotate(180deg); }
.endpoint-body { padding: 0 18px 18px; border-top: 1px solid var(--border); display: none; }
.endpoint.open .endpoint-body { display: block; }

.param-label { font-size: 11px; font-weight: 500; letter-spacing: .06em; text-transform: uppercase; color: var(--text3); margin: 18px 0 8px; }
.params-table { width: 100%; border-collapse: collapse; font-size: 13px; }
.params-table tr { border-bottom: 1px solid var(--border); }
.params-table tr:last-child { border-bottom: none; }
.params-table td { padding: 9px 8px; vertical-align: top; }
.params-table td:first-child { font-family: var(--mono); font-size: 12px; color: var(--text); width: 130px; }
.type-badge {
  display: inline-block; font-family: var(--mono); font-size: 10px;
  color: var(--text3); background: var(--bg3); padding: 1px 5px;
  border-radius: 3px; border: 1px solid var(--border);
}
.required-badge {
  display: inline-block; font-size: 10px; color: #cd2b31;
  background: #fdecea; padding: 1px 5px; border-radius: 3px;
  margin-left: 4px;
}
.params-table .param-desc { color: var(--text2); font-size: 12.5px; }

.code-wrap { position: relative; margin: 12px 0; }
.code-header {
  display: flex; align-items: center; justify-content: space-between;
  background: #1a1a18; border: 1px solid #2e2e2c; border-bottom: none;
  border-radius: var(--radius) var(--radius) 0 0; padding: 8px 14px;
}
.copy-btn {
  display: flex; align-items: center; gap: 5px; font-family: var(--mono);
  font-size: 11px; color: #4a4a48; background: transparent; border: none;
  cursor: pointer; padding: 3px 6px; border-radius: 4px; transition: all .12s;
}
.copy-btn:hover { color: #878680; background: #2a2a28; }
.copy-btn .iconify { font-size: 13px; }
pre {
  background: #1a1a18; border: 1px solid #2e2e2c; border-top: none;
  border-radius: 0 0 var(--radius) var(--radius);
  padding: 16px; overflow-x: auto; font-family: var(--mono);
  font-size: 12.5px; line-height: 1.65; color: #c4c3bf;
}
pre code { background: none; border: none; padding: 0; color: inherit; }
.t-key { color: #6aa6f0; }
.t-str { color: #87c98e; }
.t-num { color: #e8be6a; }
.t-bool { color: #cf9eff; }
.t-comment { color: #4a4a48; }

.try-panel {
  position: fixed; top: 52px; right: 0; bottom: 0; width: 420px;
  background: var(--bg); border-left: 1px solid var(--border);
  z-index: 80; display: flex; flex-direction: column; transform: translateX(100%);
  transition: transform .3s cubic-bezier(.4,0,.2,1);
}
.try-panel.open { transform: translateX(0); }
.panel-header {
  padding: 16px 18px; border-bottom: 1px solid var(--border);
  display: flex; align-items: center; justify-content: space-between; flex-shrink: 0;
}
.panel-title { font-size: 13px; font-weight: 500; display: flex; align-items: center; gap: 8px; }
.panel-close {
  display: flex; align-items: center; justify-content: center; width: 28px; height: 28px;
  background: var(--bg3); border: 1px solid var(--border); border-radius: 5px;
  cursor: pointer; color: var(--text2); transition: all .12s;
}
.panel-close:hover { background: var(--border); color: var(--text); }
.panel-close .iconify { font-size: 15px; }
.panel-body { flex: 1; overflow-y: auto; padding: 16px 18px; }
.panel-field { margin-bottom: 14px; }
.panel-label { font-size: 11px; font-weight: 500; color: var(--text2); letter-spacing: .04em; text-transform: uppercase; margin-bottom: 5px; }
.panel-input, .panel-textarea {
  width: 100%; background: var(--bg2); border: 1px solid var(--border);
  border-radius: var(--radius); padding: 8px 10px; font-size: 12.5px;
  font-family: var(--mono); color: var(--text); outline: none; transition: border .12s;
}
.panel-input:focus, .panel-textarea:focus { border-color: var(--accent); }
.panel-textarea { resize: vertical; min-height: 100px; line-height: 1.5; }
.panel-footer {
  padding: 14px 18px; border-top: 1px solid var(--border); flex-shrink: 0;
}
.send-btn {
  width: 100%; padding: 10px; background: var(--accent); border: none;
  border-radius: var(--radius); color: white; font-size: 13px; font-weight: 500;
  font-family: var(--font); cursor: pointer; display: flex; align-items: center;
  justify-content: center; gap: 8px; transition: background .15s;
}
.send-btn:hover { background: #146040; }
.send-btn:disabled { background: var(--bg3); color: var(--text3); cursor: not-allowed; }
.send-btn .iconify { font-size: 15px; }
.response-section { margin-top: 16px; }
.res-header-bar {
  display: flex; align-items: center; justify-content: space-between;
  margin-bottom: 8px;
}
.res-status-pill {
  font-family: var(--mono); font-size: 11px; font-weight: 500;
  padding: 3px 8px; border-radius: 4px;
}
.res-time { font-family: var(--mono); font-size: 11px; color: var(--text3); }
.response-output {
  background: #1a1a18; border: 1px solid #2e2e2c; border-radius: var(--radius);
  padding: 14px; font-family: var(--mono); font-size: 12px; color: #c4c3bf;
  overflow-x: auto; line-height: 1.6; white-space: pre-wrap; min-height: 60px;
}
.spin {
  display: inline-block; width: 14px; height: 14px; border: 2px solid transparent;
  border-top-color: white; border-radius: 50%; animation: spin .7s linear infinite;
}
@keyframes spin { to { transform: rotate(360deg); } }

code {
  font-family: var(--mono); font-size: 12px; background: var(--bg3);
  padding: 1px 5px; border-radius: 3px; color: var(--text);
}
a { color: var(--accent); text-decoration: none; }
a:hover { text-decoration: underline; }

.toast {
  position: fixed; bottom: 24px; left: 50%; transform: translateX(-50%) translateY(80px);
  background: var(--text); color: var(--bg); font-size: 12px; font-family: var(--font);
  padding: 8px 16px; border-radius: 20px; z-index: 200; transition: transform .25s;
  display: flex; align-items: center; gap: 6px;
}
.toast.show { transform: translateX(-50%) translateY(0); }
.toast .iconify { font-size: 14px; color: #52d68a; }
</style>"""
