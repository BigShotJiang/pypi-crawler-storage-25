from lac.gendoc.templates.endpoint import get_endpoint_card

def get_section(section):
    """Generate a complete section with all its endpoints"""
    section_id = section.get('id', '')
    title = section.get('title', '')
    description = section.get('description', '')
    endpoints = section.get('endpoints', [])
    
    endpoints_html = ""
    for endpoint in endpoints:
        endpoints_html += get_endpoint_card(endpoint, section_id)
    
    return f"""  <section class="section" id="{section_id}">
    <h2 class="section-title">{title}</h2>
    <p class="section-desc">{description}</p>

{endpoints_html}
  </section>
"""
