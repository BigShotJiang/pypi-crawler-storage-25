"""
API client for gendoc backend
"""

import requests
from typing import Dict, Optional

BACKEND_URL = "https://lacai.io/api"  # Backend API base URL

class GendocAPIError(Exception):
    pass

class GendocClient:
    def __init__(self, api_key: str):
        self.api_key = api_key
        self.session_id = None
        self.headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json"
        }
    
    def verify_key(self) -> Dict:
        """Verify API key and get credit info"""
        resp = requests.post(
            f"{BACKEND_URL}/auth/verify",
            json={"api_key": self.api_key},
            timeout=10
        )
        data = resp.json()
        if not data.get('valid'):
            raise GendocAPIError(f"Invalid API key: {data.get('error', 'Unknown error')}")
        return data
    
    def start_session(self, file_list: list, framework: Optional[str], custom_prompt: Optional[str]) -> Dict:
        """Start agentic documentation session"""
        payload = {
            "project_files": file_list,
            "framework": framework,
            "language": self._detect_language(framework),
            "custom_prompt": custom_prompt
        }
        resp = requests.post(
            f"{BACKEND_URL}/gendoc/agent/start",
            headers=self.headers,
            json=payload,
            timeout=30
        )
        data = resp.json()
        if not data.get('success'):
            raise GendocAPIError(f"Failed to start session: {data.get('error', 'Unknown error')}")
        
        self.session_id = data.get("session_id")
        return data
    
    def continue_session(self, file_path: str, file_content: str) -> Dict:
        """Send file content and get next request or final result"""
        if not self.session_id:
            raise GendocAPIError("No active session")
        
        payload = {
            "session_id": self.session_id,
            "file_path": file_path,
            "file_content": file_content
        }
        resp = requests.post(
            f"{BACKEND_URL}/gendoc/agent/continue",
            headers=self.headers,
            json=payload,
            timeout=60
        )
        data = resp.json()
        if not data.get('success'):
            raise GendocAPIError(f"Session continue failed: {data.get('error', 'Unknown error')}")
        
        return data
    
    def cancel_session(self):
        """Cancel active session"""
        if not self.session_id:
            return
        
        try:
            requests.post(
                f"{BACKEND_URL}/gendoc/agent/cancel",
                headers=self.headers,
                json={"session_id": self.session_id},
                timeout=10
            )
        except:
            pass
    
    def _detect_language(self, framework: Optional[str]) -> str:
        """Detect language from framework"""
        lang_map = {
            'laravel': 'php',
            'django': 'python',
            'fastapi': 'python',
            'flask': 'python',
            'express': 'javascript',
            'rails': 'ruby'
        }
        return lang_map.get(framework, 'unknown')
