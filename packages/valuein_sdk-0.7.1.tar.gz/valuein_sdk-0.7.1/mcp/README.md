# Valuein MCP Server — SEC EDGAR Financial Data

**`@valuein/mcp-sec-edgar`** — Institutional-grade US financial data from SEC EDGAR, accessible to any AI agent via the Model Context Protocol.

Connect Claude, Cursor, or any MCP-compatible agent to 105M+ financial facts covering 10,000+ companies from 1993 to present.

## Quickstart

### Claude Desktop / Cursor

Add to your MCP client configuration:

```json
{
  "mcpServers": {
    "valuein-sec-edgar": {
      "type": "http",
      "url": "https://mcp.valuein.com/mcp",
      "headers": {
        "Authorization": "Bearer tok_your_token_here"
      }
    }
  }
}
```

Get a token at [billing.valuein.com/checkout](https://billing.valuein.com/checkout). A free tier is available with no credit card required.

---

## Tools

| Tool | Description | Tier |
|---|---|---|
| `search_companies` | Find companies by name, ticker, CIK, or SIC code | Free |
| `get_sec_filing_links` | Direct links to 10-K/10-Q filings on SEC EDGAR | Free |
| `get_company_fundamentals` | Revenue, net income, EPS, assets, cash flow | Free (annual) / Pro (quarterly) |
| `get_financial_ratios` | Margins, ROE, ROA, debt-to-equity, FCF | Pro |
| `get_dcf_inputs` | Pre-computed two-stage DCF inputs (WACC, FCF, growth rates) | Enterprise |

---

## What makes this different

**Point-in-Time (PIT)**: Every fact has a `knowledge_at` timestamp. History is never rewritten. Eliminates look-ahead bias in backtests.

**Survivorship-bias free**: Includes delisted, acquired, and bankrupt companies back to 1993.

**Standardised concepts**: 10,000+ raw XBRL tags normalised to canonical `standard_concept` values — no custom mapping required.

**Cloud-native**: Data lives in Cloudflare R2. Zero download required. The Worker queries it at the edge in <50 ms.

---

## Tiers

| Tier | Price | Rate limit | Data depth |
|---|---|---|---|
| Free | $0 | 100 req/day | 3 years |
| Pro | $49/mo | 10,000 req/day | 10 years |
| Enterprise | $299/mo | Unlimited | Full history (1993+) |

All tiers include: search, filing links, and annual fundamentals.

---

## Architecture

```
AI Agent
  │  Authorization: Bearer <token>
  ▼
valuein-mcp-server  (Cloudflare Worker, this repo)
  │  Auth: Service Binding → valuein-auth-private (closed source)
  │  Data: R2 Bucket → pre-processed JSON slices
  ▼
Tools return structured JSON + plain-text content
```

- **Transport**: Streamable HTTP (MCP spec 2025-11-25) on `POST /mcp`
- **Legacy SSE**: `GET /sse` redirects to `/mcp` with 308
- **Per-request server instances**: MCP SDK 1.26+ security requirement

---

## Development

```bash
git clone https://github.com/valuein/quants.git
cd quants/mcp
npm install
npm run typecheck
npm run test
```

### Running locally

You need a `wrangler.toml` with Service Binding stubs. For local dev without the real auth worker, use a stub that accepts any token:

```bash
npm run dev
```

Then test with MCP Inspector:

```bash
npx @modelcontextprotocol/inspector http://localhost:8787/mcp
```

### Deploy

```bash
npm run deploy           # production
npm run deploy:staging   # staging environment
```

---

## API Discovery

- **MCP endpoint**: `https://mcp.valuein.com/mcp`
- **Well-known**: `https://valuein.com/.well-known/mcp.json`
- **LLM discovery**: `https://valuein.com/llms.txt`
- **Docs**: `https://docs.valuein.com/mcp`
- **Health**: `https://mcp.valuein.com/health`

---

## License

MIT — see [LICENSE](../LICENSE)

Data sourced from SEC EDGAR public bulk data. Usage subject to [SEC terms](https://www.sec.gov/oit/announcement/edgarfull-index-feeds.html).
