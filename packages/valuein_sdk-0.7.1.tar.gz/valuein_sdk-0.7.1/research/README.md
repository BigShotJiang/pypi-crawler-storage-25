# Research — Institutional-Grade Data, Proven

These scripts prove what the Valuein dataset can do. Each module validates a specific claim, demonstrates a real investment workflow, or audits data quality.

> "Don't trust — verify." Every claim in our marketing is backed by runnable code in this directory.

## Prerequisites

```bash
pip install valuein-sdk
export VALUEIN_API_KEY=your_key_here
```

## Structure

### `fundamental/` — Financial Statement Analysis
Build real investment models from income statements, balance sheets, and cash flows.

| File | What It Does | Key Metric |
|---|---|---|
| [`income_statement_analysis.py`](fundamental/income_statement_analysis.py) | Revenue growth, margins, TTM rolling, R&D intensity | YoY revenue growth, gross/operating/net margin |
| [`balance_sheet_analysis.py`](fundamental/balance_sheet_analysis.py) | Liquidity, solvency, leverage, income volatility | Current ratio, D/E ratio, interest coverage |
| [`cash_flow_analysis.py`](fundamental/cash_flow_analysis.py) | FCF, CapEx intensity, cash conversion cycle | Free cash flow, CapEx/revenue, CCC days |
| [`dupont_decomposition.py`](fundamental/dupont_decomposition.py) | ROE broken into profit margin × asset turnover × leverage | DuPont ROE, Piotroski F-Score, Sloan accruals |
| [`altman_z_score.py`](fundamental/altman_z_score.py) | Bankruptcy prediction across a portfolio | Z-Score zones: Distress / Grey / Safe |

### `quantitative/` — Factor Models & Strategy Research
Production-grade quant workflows with PIT-correct data.

| File | What It Proves | Key Signal |
|---|---|---|
| [`pit_correctness_proof.py`](quantitative/pit_correctness_proof.py) | knowledge_at prevents look-ahead bias | Restatement delta, PIT snapshot accuracy |
| [`survivorship_bias_proof.py`](quantitative/survivorship_bias_proof.py) | Dead companies are preserved, not deleted | % of universe that is inactive/delisted |
| [`restatement_tracker.py`](quantitative/restatement_tracker.py) | Downward restatements as a short signal | Negative revision magnitude, 8-K item 1.03 |
| [`sector_rotation.py`](quantitative/sector_rotation.py) | Cross-sectional sector fundamentals for macro timing | Sector-relative ROE, SIC ranking, geographic concentration |

### `data_engineering/` — XBRL Normalization & Data Pipeline
For engineers and quants who need to understand the data pipeline.

| File | What It Shows | Key Output |
|---|---|---|
| [`concept_mapping_explorer.py`](data_engineering/concept_mapping_explorer.py) | XBRL → `standard_concept` normalization | Tag lineage audit, top concept coverage |
| [`taxonomy_coverage.py`](data_engineering/taxonomy_coverage.py) | Which concepts have data, which are sparse | Coverage %, high-confidence fact count |
| [`filing_timeline.py`](data_engineering/filing_timeline.py) | Filing cadence: 10-K, 10-Q, 8-K distribution | Monthly volume, seasonal patterns |
| [`data_freshness_check.py`](data_engineering/data_freshness_check.py) | How current is the data? | Days since last filing by sector |

### `quality_proof/` — Automated Data Quality Checks
Evidence package for institutional data due-diligence.

| File | What It Validates | Pass Criterion |
|---|---|---|
| [`pit_validation.py`](quality_proof/pit_validation.py) | No fact has `knowledge_at` before `filing.accepted_at` | Zero violations |
| [`balance_sheet_check.py`](quality_proof/balance_sheet_check.py) | Assets = Liabilities + Equity, within 1% tolerance | > 95% pass rate |
| [`coverage_report.py`](quality_proof/coverage_report.py) | Entity, filing, and fact counts by year and sector | Completeness metrics |
| [`cross_reference_sec.py`](quality_proof/cross_reference_sec.py) | Spot-check 5 tickers against SEC EDGAR directly | Revenue within 2% of EDGAR |

---

> **For Compliance Teams:** Start with [`quality_proof/`](quality_proof/) — these are automated checks you can run to validate data integrity.

> **For Portfolio Managers:** Start with [`fundamental/`](fundamental/) — these are ready-to-use analysis templates.

> **New to the SDK?** Start with [`examples/`](../examples/) first.
