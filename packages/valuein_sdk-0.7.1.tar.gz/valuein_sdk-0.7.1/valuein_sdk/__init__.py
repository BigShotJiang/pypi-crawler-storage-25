from importlib.metadata import PackageNotFoundError, version

from .alpha import AlphaEngine, AlphaFactor, AlphaResult
from .alpha.factors import (
    ASSET_TURNOVER,
    BUILTIN_FACTORS,
    DEBT_TO_EQUITY,
    FCF_TO_ASSETS,
    GROSS_MARGIN,
    OPERATING_MARGIN,
    REVENUE_GROWTH_YOY,
    ROE,
)
from .client import ValueinClient, ValueinConfig
from .exceptions import (
    ValueinAPIError,
    ValueinAuthError,
    ValueinConfigError,
    ValueinConnectionError,
    ValueinDataError,
    ValueinError,
    ValueinNotFoundError,
    ValueinPlanError,
    ValueinRateLimitError,
)

try:
    __version__ = version("valuein-sdk")
except PackageNotFoundError:
    __version__ = "0.0.0-dev"

__all__ = [
    # Client
    "ValueinClient",
    "ValueinConfig",
    "__version__",
    # Alpha framework
    "AlphaEngine",
    "AlphaResult",
    "AlphaFactor",
    "ROE",
    "GROSS_MARGIN",
    "OPERATING_MARGIN",
    "REVENUE_GROWTH_YOY",
    "FCF_TO_ASSETS",
    "DEBT_TO_EQUITY",
    "ASSET_TURNOVER",
    "BUILTIN_FACTORS",
    # Exceptions
    "ValueinError",
    "ValueinAuthError",
    "ValueinPlanError",
    "ValueinNotFoundError",
    "ValueinRateLimitError",
    "ValueinAPIError",
    "ValueinConfigError",
    "ValueinConnectionError",
    "ValueinDataError",
]
