"""AlphaEngine and AlphaResult — cross-sectional fundamental factor framework.

Typical workflow::

    from valuein_sdk.alpha import AlphaEngine
    from valuein_sdk.alpha.factors import ROE, GROSS_MARGIN, DEBT_TO_EQUITY

    engine = (
        AlphaEngine(client)
        .add_factor(ROE)
        .add_factor(GROSS_MARGIN)
        .add_factor(DEBT_TO_EQUITY)
    )

    result = engine.compute(as_of="2024-01-01")   # PIT: only data known by this date
    scores  = result.rank().combine()             # composite alpha, best stocks first
"""

from __future__ import annotations

import logging
import re
from typing import TYPE_CHECKING

import pandas as pd

from ..exceptions import ValueinDataError

if TYPE_CHECKING:
    import polars as pl
    import pyarrow as pa

    from ..client import ValueinClient
    from .factors import AlphaFactor

_logger = logging.getLogger("valuein_sdk.alpha")

_DATE_RE = re.compile(r"^\d{4}-\d{2}-\d{2}$")


# ---------------------------------------------------------------------------
# AlphaResult
# ---------------------------------------------------------------------------


class AlphaResult:
    """Factor scores for a cross-section of companies.

    Rows are companies (identified by ``cik``, ``symbol``, ``name``).
    Each factor occupies one numeric column.

    Typical usage::

        result  = engine.compute()
        ranked  = result.rank()       # percentile rank per factor
        score   = ranked.combine()    # composite pd.Series (symbol → score)
    """

    def __init__(self, df: pd.DataFrame, factors: list[AlphaFactor]) -> None:
        self.df: pd.DataFrame = df.copy()
        self.factors: list[AlphaFactor] = list(factors)

    # ── Properties ────────────────────────────────────────────────────────

    @property
    def factor_names(self) -> list[str]:
        """Factor column names present in the DataFrame."""
        return [f.name for f in self.factors if f.name in self.df.columns]

    # ── Transformations ───────────────────────────────────────────────────

    def rank(self, pct: bool = True) -> AlphaResult:
        """Cross-sectional percentile rank (0.0 – 1.0) per factor.

        Directionality is respected: factors with ``higher_is_better=False``
        are ranked so that *low* values receive a *high* percentile score.
        After calling ``rank()``, a score of 1.0 always means "best in universe".

        Args:
            pct: If ``True`` (default) return percentile rank.
                 If ``False`` return ordinal rank.

        Returns:
            New ``AlphaResult`` with ranked factor columns.
        """
        ranked = self.df.copy()
        for factor in self.factors:
            if factor.name not in ranked.columns:
                continue
            # ascending=True  → highest value gets pct=1.0 (best for higher_is_better)
            # ascending=False → lowest  value gets pct=1.0 (best for lower_is_better)
            ranked[factor.name] = ranked[factor.name].rank(
                ascending=factor.higher_is_better,
                pct=pct,
                na_option="keep",
            )
        return AlphaResult(df=ranked, factors=self.factors)

    def zscore(self) -> AlphaResult:
        """Z-score standardize each factor column (mean 0, std 1).

        Missing values are preserved as ``NaN``.

        Returns:
            New ``AlphaResult`` with z-scored factor columns.
        """
        result = self.df.copy()
        for name in self.factor_names:
            col = result[name].dropna()
            if col.empty or col.std() == 0:
                result[name] = 0.0
            else:
                result[name] = (result[name] - col.mean()) / col.std()
        return AlphaResult(df=result, factors=self.factors)

    def combine(self, weights: dict[str, float] | None = None) -> pd.Series:
        """Weighted composite score, sorted descending (best stock first).

        Call ``rank()`` or ``zscore()`` before ``combine()`` to put all
        factors on a comparable scale.  Missing factor values are treated
        as 0.0 when combining.

        Args:
            weights: ``{factor_name: weight}`` mapping.
                     Weights need not sum to 1.
                     Defaults to equal weights across all available factors.

        Returns:
            ``pd.Series`` indexed by ``symbol``, named ``composite_score``,
            sorted descending.

        Raises:
            ValueError: If no factor columns are available.
        """
        cols = self.factor_names
        if not cols:
            raise ValueError("No factor columns available in this AlphaResult.")
        if weights is None:
            weights = {c: 1.0 / len(cols) for c in cols}

        score = pd.Series(0.0, index=self.df.index, dtype="float64")
        for col, w in weights.items():
            if col in self.df.columns:
                score += self.df[col].fillna(0.0) * w

        score.index = self.df["symbol"].values
        score.name = "composite_score"
        return score.sort_values(ascending=False)

    # ── Export ────────────────────────────────────────────────────────────

    def to_arrow(self) -> pa.Table:
        """Return the result DataFrame as a PyArrow Table (zero-copy compatible).

        PyArrow is a core dependency of the SDK — no additional install required.
        """
        import pyarrow as pa

        return pa.Table.from_pandas(self.df, preserve_index=False)

    def to_polars(self) -> pl.DataFrame:
        """Return the result DataFrame as a Polars DataFrame.

        Requires: ``pip install polars``
        """
        try:
            import polars as pol
        except ImportError:
            raise ImportError("polars is not installed. Run: pip install polars") from None
        return pol.from_pandas(self.df)

    # ── Dunder ────────────────────────────────────────────────────────────

    def __len__(self) -> int:
        return len(self.df)

    def __repr__(self) -> str:
        return f"AlphaResult(entities={len(self.df)}, factors={self.factor_names})"


# ---------------------------------------------------------------------------
# AlphaEngine
# ---------------------------------------------------------------------------


class AlphaEngine:
    """Compute fundamental alpha factors across a company universe.

    The engine executes each registered ``AlphaFactor`` SQL against the
    client's DuckDB instance, merges the results by ``cik``, and returns
    an ``AlphaResult``.

    Args:
        client: An authenticated ``ValueinClient`` instance.

    Example::

        from valuein_sdk.alpha import AlphaEngine
        from valuein_sdk.alpha.factors import BUILTIN_FACTORS

        engine = AlphaEngine(client).add_factors(*BUILTIN_FACTORS)
        result = engine.compute(as_of="2024-01-01")
        scores = result.rank().combine()
        print(scores.head(10))
    """

    def __init__(self, client: ValueinClient) -> None:
        self._client = client
        self._factors: list[AlphaFactor] = []

    # ── Builder ───────────────────────────────────────────────────────────

    def add_factor(self, factor: AlphaFactor) -> AlphaEngine:
        """Register one factor. Returns ``self`` for method chaining."""
        self._factors.append(factor)
        return self

    def add_factors(self, *factors: AlphaFactor) -> AlphaEngine:
        """Register multiple factors at once. Returns ``self`` for chaining."""
        for f in factors:
            self._factors.append(f)
        return self

    # ── Compute ───────────────────────────────────────────────────────────

    def compute(
        self,
        universe: list[str] | None = None,
        as_of: str | None = None,
        sp500_only: bool | None = None,
        min_factors: int = 1,
    ) -> AlphaResult:
        """Compute all registered factors and return an ``AlphaResult``.

        Args:
            universe: Explicit list of ticker symbols to include.
                      ``None`` → use plan-default universe.
            as_of: ISO date (``YYYY-MM-DD``) for point-in-time filtering.
                   Only data with ``filing_date <= as_of`` is used.
                   Pass this when backtesting to avoid look-ahead bias.
            sp500_only: When ``universe`` is ``None``, restrict to S&P 500
                        members.  Defaults to ``True`` for ``sp500`` plan
                        clients and ``False`` for ``full`` plan clients.
            min_factors: Minimum non-null factor values required to include
                         a company in the result.  Set higher to discard
                         companies with sparse data.

        Returns:
            ``AlphaResult`` with one row per company.

        Raises:
            ValueError: No factors registered, or invalid ``as_of`` date.
            ValueinDataError: All registered factors failed to compute.
        """
        if not self._factors:
            raise ValueError("No factors registered. Call add_factor() first.")

        if as_of is not None and not _DATE_RE.match(as_of):
            raise ValueError(f"Invalid as_of date: {as_of!r}. Expected YYYY-MM-DD format.")

        # Resolve universe filter
        if sp500_only is None:
            sp500_only = self._client._plan != "full"

        as_of_filter = f"AND filing_date <= '{as_of}'" if as_of else ""

        if universe:
            quoted = ", ".join("'" + t.replace("'", "''") + "'" for t in universe)
            universe_filter = f"AND r.symbol IN ({quoted})"
        elif sp500_only:
            universe_filter = "AND r.is_sp500 = TRUE"
        else:
            universe_filter = ""

        # Execute each factor SQL
        computed: list[tuple[AlphaFactor, pd.DataFrame]] = []

        for factor in self._factors:
            try:
                sql = factor.sql.format(
                    as_of_filter=as_of_filter,
                    universe_filter=universe_filter,
                )
                df = self._client.query(sql)
                if df.empty:
                    _logger.warning("Factor '%s' returned no rows — skipping.", factor.name)
                    continue
                if factor.name not in df.columns:
                    _logger.warning(
                        "Factor '%s' result missing column '%s' — skipping.",
                        factor.name,
                        factor.name,
                    )
                    continue
                computed.append((factor, df[["cik", "symbol", "name", factor.name]].copy()))
            except Exception as exc:
                _logger.warning("Factor '%s' failed to compute: %s", factor.name, exc)

        if not computed:
            raise ValueinDataError(
                "All registered factors failed to compute. "
                "Check that the 'references', 'filing', and 'fact' tables are loaded."
            )

        # Build base universe — union of all factor result sets
        base = (
            pd.concat([df[["cik", "symbol", "name"]] for _, df in computed])
            .drop_duplicates("cik")
            .reset_index(drop=True)
        )

        # Left-join each factor result onto the base
        for factor, df in computed:
            base = base.merge(df[["cik", factor.name]], on="cik", how="left")

        # Filter to rows meeting the min_factors threshold
        factor_cols = [f.name for f, _ in computed]
        mask = base[factor_cols].notna().sum(axis=1) >= min_factors
        result_df = base[mask].reset_index(drop=True)

        factors_list = [f for f, _ in computed]
        _logger.info(
            "AlphaEngine.compute: %d companies × %d factors",
            len(result_df),
            len(factors_list),
        )
        return AlphaResult(df=result_df, factors=factors_list)
