"""Built-in fundamental alpha factors for the Valuein SDK.

Each ``AlphaFactor`` wraps a SQL template that returns exactly four columns::

    cik, symbol, name, <factor_name>

Two placeholders are required in every SQL template:

* ``{as_of_filter}``    — injected by ``AlphaEngine`` as
                          ``AND filing_date <= 'YYYY-MM-DD'`` or ``""``
* ``{universe_filter}`` — injected as ``AND r.symbol IN (...)`` or
                          ``AND r.is_sp500 = TRUE`` or ``""``

These are filled by ``AlphaEngine.compute()`` and must **not** be hard-coded
in factor SQL.  SQL injection is prevented by the engine: ``as_of`` is
validated against a strict date regex; tickers are single-quote escaped.
"""

from __future__ import annotations

from dataclasses import dataclass, field

# ---------------------------------------------------------------------------
# AlphaFactor
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class AlphaFactor:
    """A named fundamental signal computed from financial data.

    Attributes:
        name:              Column name in the ``AlphaResult`` DataFrame.
        sql:               SQL template (Python ``str.format`` placeholders).
        higher_is_better:  ``True`` → rank ascending (high rank = high value).
                           ``False`` → rank descending (low value = high rank).
        description:       Human-readable description of the signal.
    """

    name: str
    sql: str
    higher_is_better: bool = True
    description: str = field(default="", compare=False)

    def __str__(self) -> str:
        direction = "↑ higher better" if self.higher_is_better else "↓ lower better"
        return f"AlphaFactor({self.name!r}, {direction})"


# ---------------------------------------------------------------------------
# Built-in factors
# ---------------------------------------------------------------------------

ROE = AlphaFactor(
    name="roe",
    higher_is_better=True,
    description="Return on equity: NetIncome / StockholdersEquity (latest 10-K).",
    sql="""
SELECT r.cik, r.symbol, r.name,
    MAX(CASE WHEN f.standard_concept = 'NetIncome'
             THEN f.numeric_value END) /
    NULLIF(MAX(CASE WHEN f.standard_concept = 'StockholdersEquity'
                    THEN f.numeric_value END), 0) AS roe
FROM "references" r
JOIN LATERAL (
    SELECT accession_id FROM filing
    WHERE entity_id = r.cik AND form_type = '10-K'
    {as_of_filter}
    ORDER BY filing_date DESC LIMIT 1
) lf ON TRUE
JOIN fact f ON f.accession_id = lf.accession_id
    AND f.standard_concept IN ('NetIncome', 'StockholdersEquity')
WHERE r.is_active = TRUE {universe_filter}
GROUP BY r.cik, r.symbol, r.name
HAVING roe IS NOT NULL
""",
)

GROSS_MARGIN = AlphaFactor(
    name="gross_margin",
    higher_is_better=True,
    description="Gross profit margin: GrossProfit / TotalRevenue (latest 10-K).",
    sql="""
SELECT r.cik, r.symbol, r.name,
    MAX(CASE WHEN f.standard_concept = 'GrossProfit'
             THEN f.numeric_value END) /
    NULLIF(MAX(CASE WHEN f.standard_concept = 'TotalRevenue'
                    THEN f.numeric_value END), 0) AS gross_margin
FROM "references" r
JOIN LATERAL (
    SELECT accession_id FROM filing
    WHERE entity_id = r.cik AND form_type = '10-K'
    {as_of_filter}
    ORDER BY filing_date DESC LIMIT 1
) lf ON TRUE
JOIN fact f ON f.accession_id = lf.accession_id
    AND f.standard_concept IN ('GrossProfit', 'TotalRevenue')
WHERE r.is_active = TRUE {universe_filter}
GROUP BY r.cik, r.symbol, r.name
HAVING gross_margin IS NOT NULL
""",
)

OPERATING_MARGIN = AlphaFactor(
    name="operating_margin",
    higher_is_better=True,
    description="Operating margin: OperatingIncome / TotalRevenue (latest 10-K).",
    sql="""
SELECT r.cik, r.symbol, r.name,
    MAX(CASE WHEN f.standard_concept = 'OperatingIncome'
             THEN f.numeric_value END) /
    NULLIF(MAX(CASE WHEN f.standard_concept = 'TotalRevenue'
                    THEN f.numeric_value END), 0) AS operating_margin
FROM "references" r
JOIN LATERAL (
    SELECT accession_id FROM filing
    WHERE entity_id = r.cik AND form_type = '10-K'
    {as_of_filter}
    ORDER BY filing_date DESC LIMIT 1
) lf ON TRUE
JOIN fact f ON f.accession_id = lf.accession_id
    AND f.standard_concept IN ('OperatingIncome', 'TotalRevenue')
WHERE r.is_active = TRUE {universe_filter}
GROUP BY r.cik, r.symbol, r.name
HAVING operating_margin IS NOT NULL
""",
)

REVENUE_GROWTH_YOY = AlphaFactor(
    name="revenue_growth_yoy",
    higher_is_better=True,
    description=(
        "Year-over-year revenue growth rate: (latest - prior) / prior (two most recent 10-Ks)."
    ),
    sql="""
WITH ranked_revenue AS (
    SELECT r.cik, r.symbol, r.name,
        f.numeric_value AS revenue,
        ROW_NUMBER() OVER (
            PARTITION BY r.cik ORDER BY lf.filing_date DESC
        ) AS rn
    FROM "references" r
    JOIN LATERAL (
        SELECT accession_id, filing_date FROM filing
        WHERE entity_id = r.cik AND form_type = '10-K'
        {as_of_filter}
        ORDER BY filing_date DESC LIMIT 2
    ) lf ON TRUE
    JOIN fact f ON f.accession_id = lf.accession_id
        AND f.standard_concept = 'TotalRevenue'
    WHERE r.is_active = TRUE {universe_filter}
)
SELECT cik, symbol, name,
    (MAX(CASE WHEN rn = 1 THEN revenue END) -
     MAX(CASE WHEN rn = 2 THEN revenue END)) /
    NULLIF(MAX(CASE WHEN rn = 2 THEN revenue END), 0) AS revenue_growth_yoy
FROM ranked_revenue
WHERE rn <= 2
GROUP BY cik, symbol, name
HAVING MAX(CASE WHEN rn = 1 THEN revenue END) IS NOT NULL
   AND MAX(CASE WHEN rn = 2 THEN revenue END) IS NOT NULL
""",
)

FCF_TO_ASSETS = AlphaFactor(
    name="fcf_to_assets",
    higher_is_better=True,
    description=(
        "Free cash flow yield on assets: (OperatingCashFlow − |CAPEX|) / TotalAssets (latest 10-K)."
    ),
    sql="""
SELECT r.cik, r.symbol, r.name,
    (COALESCE(MAX(CASE WHEN f.standard_concept = 'OperatingCashFlow'
                       THEN COALESCE(f.derived_quarterly_value, f.numeric_value)
                  END), 0) -
     ABS(COALESCE(MAX(CASE WHEN f.standard_concept = 'CAPEX'
                           THEN f.numeric_value END), 0))) /
    NULLIF(MAX(CASE WHEN f.standard_concept = 'TotalAssets'
                    THEN f.numeric_value END), 0) AS fcf_to_assets
FROM "references" r
JOIN LATERAL (
    SELECT accession_id FROM filing
    WHERE entity_id = r.cik AND form_type = '10-K'
    {as_of_filter}
    ORDER BY filing_date DESC LIMIT 1
) lf ON TRUE
JOIN fact f ON f.accession_id = lf.accession_id
    AND f.standard_concept IN ('OperatingCashFlow', 'CAPEX', 'TotalAssets')
WHERE r.is_active = TRUE {universe_filter}
GROUP BY r.cik, r.symbol, r.name
HAVING fcf_to_assets IS NOT NULL
""",
)

DEBT_TO_EQUITY = AlphaFactor(
    name="debt_to_equity",
    higher_is_better=False,
    description="Leverage ratio: TotalLiabilities / StockholdersEquity (latest 10-K). Lower is better.",
    sql="""
SELECT r.cik, r.symbol, r.name,
    MAX(CASE WHEN f.standard_concept = 'TotalLiabilities'
             THEN f.numeric_value END) /
    NULLIF(MAX(CASE WHEN f.standard_concept = 'StockholdersEquity'
                    THEN f.numeric_value END), 0) AS debt_to_equity
FROM "references" r
JOIN LATERAL (
    SELECT accession_id FROM filing
    WHERE entity_id = r.cik AND form_type = '10-K'
    {as_of_filter}
    ORDER BY filing_date DESC LIMIT 1
) lf ON TRUE
JOIN fact f ON f.accession_id = lf.accession_id
    AND f.standard_concept IN ('TotalLiabilities', 'StockholdersEquity')
WHERE r.is_active = TRUE {universe_filter}
GROUP BY r.cik, r.symbol, r.name
HAVING debt_to_equity IS NOT NULL
""",
)

ASSET_TURNOVER = AlphaFactor(
    name="asset_turnover",
    higher_is_better=True,
    description="Asset efficiency: TotalRevenue / TotalAssets (latest 10-K).",
    sql="""
SELECT r.cik, r.symbol, r.name,
    MAX(CASE WHEN f.standard_concept = 'TotalRevenue'
             THEN f.numeric_value END) /
    NULLIF(MAX(CASE WHEN f.standard_concept = 'TotalAssets'
                    THEN f.numeric_value END), 0) AS asset_turnover
FROM "references" r
JOIN LATERAL (
    SELECT accession_id FROM filing
    WHERE entity_id = r.cik AND form_type = '10-K'
    {as_of_filter}
    ORDER BY filing_date DESC LIMIT 1
) lf ON TRUE
JOIN fact f ON f.accession_id = lf.accession_id
    AND f.standard_concept IN ('TotalRevenue', 'TotalAssets')
WHERE r.is_active = TRUE {universe_filter}
GROUP BY r.cik, r.symbol, r.name
HAVING asset_turnover IS NOT NULL
""",
)

# Convenience collection — all built-in factors in signal-strength order.
BUILTIN_FACTORS: list[AlphaFactor] = [
    ROE,
    GROSS_MARGIN,
    OPERATING_MARGIN,
    REVENUE_GROWTH_YOY,
    FCF_TO_ASSETS,
    DEBT_TO_EQUITY,
    ASSET_TURNOVER,
]
