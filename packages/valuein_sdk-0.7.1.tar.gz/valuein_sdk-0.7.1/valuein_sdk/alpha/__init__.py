"""Alpha factor framework for fundamental signal generation.

Quick start::

    from valuein_sdk.alpha import AlphaEngine, AlphaResult, AlphaFactor
    from valuein_sdk.alpha.factors import ROE, GROSS_MARGIN, DEBT_TO_EQUITY, BUILTIN_FACTORS

    engine = (
        AlphaEngine(client)
        .add_factor(ROE)
        .add_factor(GROSS_MARGIN)
        .add_factor(DEBT_TO_EQUITY)
    )

    result = engine.compute(as_of="2024-01-01")   # PIT-safe
    scores  = result.rank().combine()             # composite alpha, best first
"""

from .engine import AlphaEngine, AlphaResult
from .factors import (
    ASSET_TURNOVER,
    BUILTIN_FACTORS,
    DEBT_TO_EQUITY,
    FCF_TO_ASSETS,
    GROSS_MARGIN,
    OPERATING_MARGIN,
    REVENUE_GROWTH_YOY,
    ROE,
    AlphaFactor,
)

__all__ = [
    "AlphaEngine",
    "AlphaResult",
    "AlphaFactor",
    # Built-in factors
    "ROE",
    "GROSS_MARGIN",
    "OPERATING_MARGIN",
    "REVENUE_GROWTH_YOY",
    "FCF_TO_ASSETS",
    "DEBT_TO_EQUITY",
    "ASSET_TURNOVER",
    "BUILTIN_FACTORS",
]
