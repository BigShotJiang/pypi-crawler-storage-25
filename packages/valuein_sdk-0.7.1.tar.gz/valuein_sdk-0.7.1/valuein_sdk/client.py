# Copyright 2026 Valuein LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Valuein SDK — Python client for US Core Fundamentals data.

The client authenticates against the Valuein edge gateway, discovers the
user's plan and current data snapshot, then downloads Parquet tables into
an in-process DuckDB instance for zero-latency SQL analytics.

Users never interact with storage directly.  The gateway resolves the
correct bucket, snapshot folder, and Parquet path from the token alone.
"""

from __future__ import annotations

import importlib.resources as pkg_resources
import io
import json
import logging
import os
import pathlib
import tempfile
import time
import warnings
from collections.abc import Iterator
from dataclasses import dataclass
from typing import Any

import duckdb
import pandas as pd
import pyarrow.parquet as pq
from dotenv import load_dotenv

from .exceptions import (
    ValueinAuthError,
    ValueinConfigError,
    ValueinConnectionError,
    ValueinDataError,
    ValueinError,
    ValueinPlanError,
)
from .transport import Transport

_logger = logging.getLogger("valuein_sdk")

_DEFAULT_GATEWAY = "https://data.valuein.biz"

# Manifest data is small and changes only when the pipeline publishes a new snapshot.
# Cache it for 5 minutes to avoid a network round-trip on every manifest() call.
_MANIFEST_CACHE_TTL_S = 300.0
ALLOWED_FORM_TYPES = {"10-K", "10-K/A", "10-Q", "10-Q/A", "20-F", "20-F/A", "8-K", "8-K/A"}

# Tables too large to download at init — served via presigned R2 URL + httpfs.
# DuckDB fetches only the Parquet footer then the specific row groups it needs,
# so a filtered query reads a tiny fraction of the file even without downloading.
# Small tables (entity, security, taxonomy_guide, etc.) continue to be downloaded
# for fast repeated local access without expiry concerns.
_REMOTE_TABLES = frozenset({"fact", "filing"})
_PRESIGN_TTL_S = 3_600  # 1-hour URL for remote table views
_PRESIGN_REFRESH_BUFFER_S = 120  # refresh when < 2 minutes remain

_SAMPLE_NOTICE = """\
Defaulting to SAMPLE dataset (S&P500, last 5 years).

Upgrade access:
  Register (free)  → Full S&P500 history
  Add API token    → Full US equities universe + complete history

Get your token: https://valuein.biz\
"""

# The 8 tables the edge-gateway exposes.  Used as fallback only when
# the manifest does not include a "tables" key.
# `references` is the denormalized flat join of entity + security + index_membership
# (one row per security) and is the recommended starting point for cross-company queries.
_KNOWN_TABLES = frozenset(
    [
        "references",
        "entity",
        "security",
        "valuation",
        "filing",
        "fact",
        "taxonomy_guide",
        "index_membership",
    ]
)


@dataclass
class ValueinConfig:
    """Hardware and resource constraints for the Valuein SDK."""

    # RAM limit (e.g., '2GB', '512MB').
    # DuckDB will spill to disk once this is hit.
    memory_limit: str = "4GB"

    # Where to store temporary spill files.
    # Defaults to a secure OS-provided temp directory.
    temp_directory: str | None = None

    # Hard cap on disk usage to prevent filling up the host SSD.
    max_temp_directory_size: str = "20GB"

    # Number of CPU threads DuckDB is allowed to use.
    threads: int = 4

    def __post_init__(self) -> None:
        """Sanitize inputs to prevent DuckDB parser crashes."""
        self.memory_limit = self.memory_limit.strip().upper()
        self.max_temp_directory_size = self.max_temp_directory_size.strip().upper()

        # Ensure standard formatting (e.g., replacing 'G' with 'GB')
        if self.memory_limit.endswith("G"):
            self.memory_limit += "B"
        if self.max_temp_directory_size.endswith("G"):
            self.max_temp_directory_size += "B"

        # Guard against zero/negative thread counts that would crash DuckDB.
        self.threads = max(1, int(self.threads))


class ValueinClient:
    """Client for the Valuein Financial Data API.

    Connects to the Valuein edge gateway, authenticates with a Bearer
    token, and loads Parquet tables into DuckDB for SQL querying.

    Args:
        api_key: Valuein API token. Falls back to ``VALUEIN_API_KEY`` env var.
        gateway_url: Override the gateway URL (development only).
        tables: Restrict which tables are loaded at init.
        config: Hardware constraints (RAM/Disk/Threads) for the local engine.
    """

    def __init__(
        self,
        api_key: str | None = None,
        gateway_url: str | None = None,
        tables: list[str] | None = None,
        config: ValueinConfig | None = None,
    ) -> None:
        load_dotenv()

        raw_key = api_key or os.getenv("VALUEIN_API_KEY", "")
        self.api_key = raw_key  # may be empty string — sample mode

        self.gateway_url: str = (
            gateway_url or os.getenv("VALUEIN_GATEWAY_URL") or _DEFAULT_GATEWAY
        ).rstrip("/")

        self._transport = Transport(
            api_key=self.api_key,
            gateway_url=self.gateway_url,
        )

        # ── Discover plan & snapshot ──────────────────────────────────────
        if not raw_key:
            # No token — run in sample mode with public data, no network auth needed.
            warnings.warn(_SAMPLE_NOTICE, UserWarning, stacklevel=2)
            self._plan = "sample"
            self._me_data: dict[str, Any] = {
                "plan": "sample",
                "status": "unauthenticated",
                "email": None,
                "message": "No API key provided. Register for free at https://valuein.biz",
            }
            # Fetch last_updated from the sample bucket manifest (auth-disabled endpoint).
            last_updated: str | None = None
            try:
                raw = self._transport.get("/v1/sample/_manifest.json").json()
                last_updated = raw.get("last_updated") or raw.get("created_at")
            except Exception:
                pass  # Non-fatal — last_updated stays None if the fetch fails.
            self._manifest_data: dict[str, Any] = {
                "plan": "sample",
                "path": "/v1/sample",
                "last_updated": last_updated,
                "message": "Sample mode — add an API key for full S&P500 or full-universe access",
            }
            self._manifest_fetched_at: float = time.monotonic()
        else:
            try:
                self._me_data = self._fetch_me()
                self._plan = self._me_data.get("plan", "sp500")
                self._manifest_data = self._fetch_manifest()
                self._manifest_fetched_at = time.monotonic()
            except ValueinError:
                # Auth/plan/rate-limit errors must propagate with their original type
                raise
            except Exception as e:
                # Wrap unexpected boot errors (DNS, SSL, etc.) in a ConnectionError
                raise ValueinConnectionError(f"Failed to initialize session: {e}") from e

        # ── Resolve table list ────────────────────────────────────────────
        manifest_tables = list(self._manifest_data.get("tables", []))
        available = manifest_tables if manifest_tables else sorted(_KNOWN_TABLES)

        if tables is not None:
            unknown = set(tables) - set(available)
            if unknown:
                raise ValueinConfigError(f"Unknown table(s): {', '.join(sorted(unknown))}")
            self._tables: list[str] = list(tables)
        else:
            self._tables = available

        # ── Resource Management ───────────────────────────────────────────
        self.config = config or ValueinConfig()
        self._managed_temp: tempfile.TemporaryDirectory | None = None
        # Tracks expiry (monotonic seconds) for remote httpfs views.
        # Populated by _load_tables when large tables are mounted via presigned URLs.
        self._remote_view_expiry: dict[str, float] = {}

        if self.config.temp_directory:
            # User provided a custom directory; we will NOT clean this up
            self._temp_dir_path = self.config.temp_directory
            os.makedirs(self._temp_dir_path, exist_ok=True)
        else:
            # SDK creates a temp directory; we MUST clean this up
            self._managed_temp = tempfile.TemporaryDirectory()
            self._temp_dir_path = self._managed_temp.name

        # ── Initialization ────────────────────────────────────────────────
        self._setup_duckdb()
        self.query_cache: dict[str, str] = {}

        if self._tables:
            self._load_tables()

        self._build_query_map()
        self._init_jinja()

    def _setup_duckdb(self) -> None:
        self.con: duckdb.DuckDBPyConnection = duckdb.connect()
        self.con.execute("SET preserve_insertion_order = false")
        self.con.execute(f"SET memory_limit = '{self.config.memory_limit}'")
        self.con.execute(f"SET temp_directory = '{self._temp_dir_path}'")
        self.con.execute(f"SET max_temp_directory_size = '{self.config.max_temp_directory_size}'")
        self.con.execute(f"SET threads = {self.config.threads}")

        # Load httpfs to enable direct remote Parquet queries via presigned URLs.
        # Non-fatal: if the extension is unavailable (air-gapped environments,
        # restricted DuckDB builds), get_presigned_url still works but the caller
        # must pass the URL to read_parquet() themselves.
        self._httpfs_available = False
        try:
            self.con.execute("INSTALL httpfs; LOAD httpfs;")
            self.con.execute("SET enable_http_metadata_cache = true;")
            self.con.execute("SET enable_object_cache = true;")
            self._httpfs_available = True
        except Exception:
            _logger.debug("httpfs extension unavailable — presigned URL direct queries disabled")

    def _fetch_me(self) -> dict[str, Any]:
        return self._transport.get("/v1/me").json()

    def _fetch_manifest(self) -> dict[str, Any]:
        return self._transport.get("/v1/manifest").json()

    def _table_endpoint(self, table: str) -> str:
        if self._plan == "full":
            prefix = "full"
        elif self._plan == "sample":
            prefix = "sample"
        else:
            prefix = "sp500"
        return f"/v1/{prefix}/{table}"

    def _load_tables(self) -> None:
        """Register tables as DuckDB views.

        Large tables (``fact``, ``filing``) are mounted via a presigned R2 URL
        when httpfs is available — no download, zero bytes transferred until a
        query actually runs.  All other tables are downloaded to the local temp
        directory for fast repeated access.
        """
        loaded: list[str] = []
        t0 = time.monotonic()

        for table in self._tables:
            # ── Remote path (large tables, httpfs available, authenticated) ─
            if self._httpfs_available and table in _REMOTE_TABLES and self._plan != "sample":
                try:
                    url = self._get_presigned_url(table, expires_in=_PRESIGN_TTL_S)
                    self.con.execute(
                        f"CREATE OR REPLACE VIEW \"{table}\" AS SELECT * FROM read_parquet('{url}')"
                    )
                    self._remote_view_expiry[table] = time.monotonic() + _PRESIGN_TTL_S
                    loaded.append(table)
                    _logger.debug(
                        "Mounted '%s' as remote httpfs view (presigned URL, %ds TTL)",
                        table,
                        _PRESIGN_TTL_S,
                    )
                    continue
                except Exception as exc:
                    _logger.warning(
                        "Presign failed for '%s' — falling back to local download: %s", table, exc
                    )

            # ── Local path (small tables, or remote path fallback) ────────
            endpoint = self._table_endpoint(table)
            pq_path = pathlib.Path(self._temp_dir_path) / f"{table}.parquet"

            try:
                with open(pq_path, "wb") as f:
                    self._transport.download_to_file(endpoint, f)

                self.con.execute(
                    f"CREATE OR REPLACE VIEW \"{table}\" AS SELECT * FROM read_parquet('{pq_path}')"
                )
                loaded.append(table)
            except ValueinAuthError:
                if self._plan == "sample":
                    _logger.warning(
                        "Table '%s' is not accessible without an API key. "
                        "Register for free at https://valuein.biz",
                        table,
                    )
                else:
                    raise
            except ValueinPlanError:
                _logger.warning("Table '%s' requires a higher plan — skipping.", table)
            except Exception as exc:
                _logger.error("Failed to load table '%s': %s", table, exc)

        if not loaded and self._tables:
            if self._plan == "sample":
                warnings.warn(
                    "No tables could be loaded in sample mode. "
                    "The sample endpoint may require an API key — register for free at https://valuein.biz",
                    UserWarning,
                    stacklevel=3,
                )
            else:
                raise ValueinDataError("Valuein engine failed to load any requested tables.")

        self._tables = loaded
        _logger.info("Engine ready. %d tables loaded in %.2fs", len(loaded), time.monotonic() - t0)

    def _build_query_map(self) -> None:
        self.query_cache = {}
        try:
            queries_root = str(pkg_resources.files("valuein_sdk").joinpath("queries"))
            for dirpath, _, filenames in os.walk(queries_root):
                for fname in filenames:
                    if fname.endswith(".sql"):
                        key = fname.removesuffix(".sql")
                        self.query_cache[key] = os.path.join(dirpath, fname)
        except Exception as exc:
            warnings.warn(f"Could not index SQL templates: {exc}", stacklevel=2)

    def _init_jinja(self) -> None:
        """Initialize the Jinja2 environment and persistent template cache.

        Called once in ``__init__``. The ``lru_cache`` on ``_load_jinja_template``
        must live at instance scope — defining it inside ``run_template`` creates a
        new cache object on every call, so nothing is ever reused.
        """
        from functools import lru_cache

        from jinja2 import Environment, StrictUndefined

        def _quote_sql_string(v: object) -> str:
            return "'" + str(v).replace("'", "''") + "'"

        def sql_list(value: object) -> str:
            if value is None:
                raise ValueError("List parameter cannot be None")
            if not isinstance(value, (list, tuple)):
                raise TypeError(f"Expected list/tuple, got {type(value)}")
            if not value:
                raise ValueError("List parameter cannot be empty")
            return ", ".join(_quote_sql_string(v) for v in value)

        def sql_identifier(value: object) -> str:
            if not isinstance(value, str) or not value:
                raise ValueError("Invalid SQL identifier")
            if not value.replace("_", "").isalnum():
                raise ValueError(f"Unsafe SQL identifier: {value}")
            return value

        def sql_quote(value: object) -> str:
            """Single scalar SQL string literal — safe for WHERE ``= {{ val | sql_quote }}``."""
            return _quote_sql_string(value)

        env = Environment(
            undefined=StrictUndefined,
            autoescape=False,
            trim_blocks=True,
            lstrip_blocks=True,
        )
        env.filters["sql_list"] = sql_list
        env.filters["sql_identifier"] = sql_identifier
        env.filters["sql_quote"] = sql_quote

        self._jinja_env = env

        # Defined here once — the cache persists for the client's lifetime.
        # Each unique path touches the filesystem only on the first call.
        @lru_cache(maxsize=128)
        def _load_jinja_template(path: str) -> Any:  # jinja2.Template
            with open(path) as fh:
                return env.from_string(fh.read())

        self._load_jinja_template = _load_jinja_template

    def me(self) -> dict[str, Any]:
        return dict(self._me_data)

    def manifest(self) -> dict[str, Any]:
        """Return current snapshot metadata, refreshing from the gateway at most every 5 minutes.

        In sample mode (no API key) the stub is returned directly — no network call is made.
        """
        if self._plan == "sample":
            return dict(self._manifest_data)
        now = time.monotonic()
        if now - self._manifest_fetched_at >= _MANIFEST_CACHE_TTL_S:
            self._manifest_data = self._fetch_manifest()
            self._manifest_fetched_at = now
        return dict(self._manifest_data)

    def health(self) -> dict[str, Any]:
        """Return gateway health status.

        In sample mode (no API key) a static response is returned so that callers
        can always depend on this method without triggering a 401 from the gateway.
        """
        if self._plan == "sample":
            return {
                "status": "ok",
                "mode": "sample",
                "authenticated": False,
                "message": "Running in unauthenticated sample mode. Add an API key for full access.",
            }
        return self._transport.get("/health").json()

    def get(self, table: str) -> pd.DataFrame:
        all_known = sorted(set(list(self._manifest_data.get("tables", []))) | _KNOWN_TABLES)
        if table not in all_known:
            raise ValueError(f"Unknown table '{table}'. Available: {', '.join(all_known)}")

        endpoint = self._table_endpoint(table)
        try:
            response = self._transport.get(endpoint)
        except (ValueinAuthError, ValueinPlanError):
            raise
        except Exception as exc:
            raise ConnectionError(f"Failed to download '{table}': {exc}") from exc

        return pq.read_table(io.BytesIO(response.content)).to_pandas()

    def _bundled_schema(self) -> dict[str, Any]:
        """Load and return the bundled schema.json shipped with the package."""
        schema_file = pkg_resources.files("valuein_sdk").joinpath("schema.json")
        with schema_file.open("r", encoding="utf-8") as fh:
            data = json.load(fh)
        return data.get("tables", {})

    def get_schema(self, table: str) -> dict[str, str]:
        """Return column names and their types for a table.

        When the table is loaded in DuckDB the types come from DuckDB's own
        ``DESCRIBE`` (authoritative, reflects the actual Parquet file).  When
        the table is not loaded — including in sample mode before any data has
        been downloaded — the schema is served from the bundled ``schema.json``
        shipped with the package.

        Args:
            table: Any known table name (loaded or not).

        Returns:
            Dict mapping column name → type string,
            e.g. ``{"cik": "VARCHAR", "name": "VARCHAR", "is_sp500": "BOOLEAN"}``.

        Raises:
            ValueError: If ``table`` is not loaded and not found in the bundled schema.
            ValueinDataError: If DuckDB cannot describe a loaded table.
        """
        if table in self._tables:
            try:
                rows = self.con.execute(f"DESCRIBE {table}").fetchall()
                return {row[0]: row[1] for row in rows}
            except Exception as e:
                raise ValueinDataError(f"Failed to describe table '{table}': {e}") from e

        # Fall back to bundled schema for unloaded tables (includes sample mode).
        bundled = self._bundled_schema()
        if table in bundled:
            return {
                col: meta.get("type", "UNKNOWN") for col, meta in bundled[table]["columns"].items()
            }

        all_known = sorted(bundled.keys() | set(self._tables))
        raise ValueError(f"Unknown table '{table}'. Known tables: {', '.join(all_known)}")

    def query(self, sql_query: str) -> pd.DataFrame:
        """Execute a raw SQL query against the loaded tables."""
        if self._remote_view_expiry:
            self._maybe_refresh_remote_views()
        try:
            return self.con.execute(sql_query).df()
        except Exception as e:
            raise ValueinDataError(f"SQL execution failed: {e}") from e

    def to_arrow(self, sql_query: str) -> pq.Table:
        """Execute SQL and return the result as a PyArrow Table.

        Uses DuckDB's native Arrow export path — zero Python-object overhead.
        Suitable for passing directly to Spark, Polars, or any Arrow-compatible
        engine without a pandas round-trip.

        Args:
            sql_query: DuckDB SQL query string.

        Returns:
            ``pyarrow.Table`` with the full result set.

        Raises:
            ValueinDataError: If DuckDB raises during execution.

        Example::

            table = client.to_arrow("SELECT * FROM references WHERE is_sp500 = TRUE")
            # Pass to Spark:
            spark_df = spark.createDataFrame(table.to_pandas())
        """
        if self._remote_view_expiry:
            self._maybe_refresh_remote_views()
        try:
            return self.con.execute(sql_query).fetch_arrow_table()
        except Exception as e:
            raise ValueinDataError(f"Arrow export failed: {e}") from e

    def to_polars(self, sql_query: str) -> Any:
        """Execute SQL and return the result as a Polars DataFrame.

        Chains through the Arrow path for zero-copy conversion.

        Args:
            sql_query: DuckDB SQL query string.

        Returns:
            ``polars.DataFrame`` with the full result set.

        Raises:
            ImportError: If polars is not installed.
            ValueinDataError: If DuckDB raises during execution.

        Example::

            df = client.to_polars("SELECT symbol, sector FROM references LIMIT 100")
        """
        try:
            import polars as pl
        except ImportError:
            raise ImportError("polars is not installed. Run: pip install polars") from None
        return pl.from_arrow(self.to_arrow(sql_query))

    def stream(self, sql: str, batch_size: int = 10_000) -> Iterator[pd.DataFrame]:
        """Execute SQL and yield results in batches to avoid materialising a huge DataFrame.

        Useful when querying large tables such as ``fact`` where the full result set
        may not fit comfortably in RAM.

        Args:
            sql: DuckDB SQL query string.
            batch_size: Maximum number of rows per yielded DataFrame (default 10 000).

        Yields:
            Consecutive DataFrames of up to ``batch_size`` rows each.

        Raises:
            ValueinDataError: If DuckDB raises an error while preparing or streaming.

        Example::

            for chunk in client.stream("SELECT * FROM fact WHERE fiscal_year = 2023"):
                process(chunk)
        """
        if self._remote_view_expiry:
            self._maybe_refresh_remote_views()
        try:
            cursor = self.con.cursor()
            cursor.execute(sql)
        except Exception as e:
            raise ValueinDataError(f"SQL stream failed: {e}") from e

        # fetch_df_chunk uses DuckDB's Arrow path: zero-copy, no Python-list
        # intermediate. vectors_per_chunk maps batch_size → DuckDB vector units
        # (each vector ≈ 2048 rows by default).
        vectors_per_chunk = max(1, batch_size // 2048)
        while True:
            try:
                chunk = cursor.fetch_df_chunk(vectors_per_chunk)
            except Exception as e:
                raise ValueinDataError(f"SQL stream read failed: {e}") from e
            if chunk.shape[0] == 0:
                break
            yield chunk

    def run_template(self, name: str, **kwargs: object) -> pd.DataFrame:
        """Execute a named SQL template from the ``queries/`` directory.

        Templates use Python ``str.format()`` placeholders (e.g. ``{ticker}``,
        ``{form_types}``).  List/tuple values are automatically expanded to
        SQL-safe quoted, comma-joined strings for use in ``IN (...)`` clauses.

        A Jinja2 environment with ``sql_list``, ``sql_identifier``, and
        ``sql_quote`` filters is also available for new Jinja2-syntax templates
        via ``self._load_jinja_template(path).render(**kwargs)``.

        Args:
            name:   Template key (filename without ``.sql``).
            **kwargs: Template variables forwarded to ``str.format()``.
                      ``form_types`` and ``metrics`` are validated before render.

        Returns:
            Query result as a pandas DataFrame.

        Raises:
            FileNotFoundError: If ``name`` is not in the template index.
            TypeError / ValueError: On invalid ``form_types`` or ``metrics``.
            ValueinDataError: If DuckDB raises during execution.
        """
        # ── Template lookup ───────────────────────────────────────────────
        path = self.query_cache.get(name)
        if not path:
            available = sorted(self.query_cache) or ["(none)"]
            raise FileNotFoundError(
                f"Template '{name}' not found. Available: {', '.join(available)}"
            )

        # ── Validation ────────────────────────────────────────────────────
        if "form_types" in kwargs:
            values = kwargs["form_types"]
            if not isinstance(values, (list, tuple)):
                raise TypeError("form_types must be a list/tuple")
            invalid = set(values) - ALLOWED_FORM_TYPES  # type: ignore[arg-type]
            if invalid:
                raise ValueError(f"Invalid form_types: {sorted(invalid)}")

        if "metrics" in kwargs:
            values = kwargs["metrics"]
            if not isinstance(values, (list, tuple)):
                raise TypeError("metrics must be a list/tuple")
            if not values:
                raise ValueError("metrics cannot be empty")
            if not all(isinstance(v, str) for v in values):  # type: ignore[union-attr]
                raise TypeError("metrics must be strings")

        # ── Load & render (Python str.format) ─────────────────────────────
        # All bundled templates use single-brace {var} placeholders.
        # List/tuple values are expanded to SQL-safe, single-quote-escaped strings.
        with open(path) as fh:
            sql = fh.read()

        fmt: dict[str, object] = {}
        for key, val in kwargs.items():
            if isinstance(val, (list, tuple)):
                fmt[key] = ", ".join("'" + str(v).replace("'", "''") + "'" for v in val)
            else:
                fmt[key] = val

        try:
            rendered_sql = sql.format(**fmt)
        except Exception as e:
            raise ValueError(f"Template '{name}' render failed: {e}") from e

        # ── Execute ───────────────────────────────────────────────────────
        try:
            return self.con.execute(rendered_sql).df()
        except Exception as e:
            raise ValueinDataError(f"Template '{name}' execution failed: {e}") from e

    def _get_presigned_url(self, table: str, expires_in: int = _PRESIGN_TTL_S) -> str:
        """Fetch a short-lived presigned R2 URL from the gateway (internal only).

        Called by ``_load_tables`` and ``_maybe_refresh_remote_views`` to mount
        large tables as remote httpfs views.  Not part of the public API.
        """
        if self._plan == "sample":
            raise ValueError("Presigned URLs require an API key.")
        response = self._transport.get(f"/v1/presign/{table}?expires_in={expires_in}")
        return response.json()["url"]

    def _maybe_refresh_remote_views(self) -> None:
        """Silently refresh any presigned-URL views that are close to expiry.

        Called at the start of every ``query()`` and ``stream()`` invocation.
        Views with more than ``_PRESIGN_REFRESH_BUFFER_S`` seconds remaining are
        left untouched.  On refresh failure the old view is preserved and a
        warning is emitted — the next query will retry automatically.
        """
        now = time.monotonic()
        for table, expiry in list(self._remote_view_expiry.items()):
            if expiry - now <= _PRESIGN_REFRESH_BUFFER_S:
                try:
                    url = self._get_presigned_url(table, expires_in=_PRESIGN_TTL_S)
                    self.con.execute(
                        f"CREATE OR REPLACE VIEW \"{table}\" AS SELECT * FROM read_parquet('{url}')"
                    )
                    self._remote_view_expiry[table] = now + _PRESIGN_TTL_S
                    _logger.debug("Refreshed remote view for '%s'", table)
                except Exception as exc:
                    _logger.warning("Failed to refresh remote view for '%s': %s", table, exc)

    def tables(self) -> list[str]:
        return sorted(self._tables)

    def __repr__(self) -> str:
        return (
            f"ValueinClient(plan={self._plan!r}, "
            f"snapshot={self._manifest_data.get('snapshot', 'unknown')!r}, "
            f"tables={len(self._tables)})"
        )

    def close(self) -> None:
        """Explicitly close database connections and clean up managed temp files."""
        if hasattr(self, "con"):
            try:
                self.con.close()
            except Exception as exc:
                _logger.debug("DuckDB close error (suppressed): %s", exc)

        if hasattr(self, "_transport"):
            try:
                self._transport.close()
            except Exception as exc:
                _logger.debug("Transport close error (suppressed): %s", exc)

        if hasattr(self, "_managed_temp") and self._managed_temp is not None:
            try:
                self._managed_temp.cleanup()
                self._managed_temp = None
            except Exception as exc:
                _logger.debug("Temp directory cleanup error (suppressed): %s", exc)

    def __enter__(self) -> ValueinClient:
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        self.close()

    def __del__(self) -> None:
        self.close()
