-- Counts the frequency of 8-K filings to measure corporate volatility.

SELECT
    DATE_TRUNC('month', f.filing_date) AS event_month,
    COUNT(f.accession_id) AS material_events_count
FROM filing f
JOIN "references" r ON f.entity_id = r.cik
WHERE r.symbol = '{ticker}'
  AND r.is_active = TRUE
  AND f.form_type = '8-K'
  AND f.filing_date BETWEEN '{start_date}' AND '{end_date}'
GROUP BY event_month
ORDER BY event_month DESC;
