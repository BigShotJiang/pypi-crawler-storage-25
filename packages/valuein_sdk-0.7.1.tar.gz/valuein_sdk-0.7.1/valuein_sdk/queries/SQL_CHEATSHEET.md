# Valuein SEC SQL Cheat Sheet

Common patterns for querying the Valuein data lake. The SDK executes these against Parquet files on Cloudflare R2 via DuckDB — no database setup required.

---

## 🗂️ Available Tables

| Table | Rows | What it is |
|---|---|---|
| `references` | ~7K | **Start here.** Flat join of entity + security + index_membership. One row per security. Boolean flags (`is_sp500`) replace three joins. |
| `fact` | 108M+ | Financial statement data points |
| `filing` | 12M+ | SEC filing metadata |
| `entity` | 19K+ | Company master (use for fields not in `references`) |
| `security` | 7K+ | Ticker history — SCD Type 2 with date ranges |
| `index_membership` | 8K+ | Historical index membership with start/end dates |
| `taxonomy_guide` | 11,966 | Human-readable concept definitions |
| `valuation` | 19K+ | Pre-computed DCF + DDM intrinsic values |

---

## Pattern 1 — `references` as Entry Point (replaces 3 joins)

**Goal:** Filter by index, sector, or ticker without joining entity + security + index_membership every time.

```sql
-- All current S&P 500 technology companies
SELECT symbol, name, sector
FROM   references
WHERE  is_sp500 = TRUE
  AND  sector ILIKE '%technology%'
  AND  is_active = TRUE;
```

`references` eliminates the entity → security → index_membership join chain on every query.
Use `entity` or `security` directly only when you need fields not in `references`
(e.g., full SCD2 history, `ein`, `state_of_incorporation`, index membership date ranges).

---

## Pattern 2 — LATERAL Join for Latest Filing

**Goal:** One row per company using the most recent filing, without a correlated subquery.

```sql
-- Latest annual revenue for every S&P 500 company
SELECT
  r.symbol,
  r.name,
  r.sector,
  f.filing_date,
  fa.numeric_value / 1e9 AS revenue_billions
FROM references r
JOIN LATERAL (
  SELECT accession_id, filing_date
  FROM   filing
  WHERE  entity_id = r.cik AND form_type = '10-K'
  ORDER  BY filing_date DESC
  LIMIT  1
) f ON true
JOIN fact fa ON fa.accession_id = f.accession_id
           AND fa.standard_concept = 'TotalRevenue'
WHERE r.is_sp500 = TRUE
ORDER BY revenue_billions DESC;
```

`LATERAL` runs once per company and pins exactly one `accession_id` — the subsequent `fact`
join is a lookup, not a full scan.

---

## Pattern 3 — Pivot Multiple Concepts in One Scan

**Goal:** Compute a ratio or multi-metric screen without joining `fact` to itself twice.

```sql
-- Debt-to-equity for S&P 500 tech — latest annual filing, one fact scan
SELECT
  r.symbol,
  r.name,
  r.sector,
  f.filing_date                                                          AS annual_filing_date,
  MAX(CASE WHEN fa.standard_concept = 'LongTermDebt'       THEN fa.numeric_value END) / 1e9 AS debt_billions,
  MAX(CASE WHEN fa.standard_concept = 'StockholdersEquity' THEN fa.numeric_value END) / 1e9 AS equity_billions,
  MAX(CASE WHEN fa.standard_concept = 'LongTermDebt'       THEN fa.numeric_value END)
  / NULLIF(
    MAX(CASE WHEN fa.standard_concept = 'StockholdersEquity' THEN fa.numeric_value END), 0
  )                                                                      AS debt_to_equity
FROM references r
JOIN LATERAL (
  SELECT accession_id, filing_date
  FROM   filing
  WHERE  entity_id = r.cik AND form_type = '10-K'
  ORDER  BY filing_date DESC
  LIMIT  1
) f ON true
JOIN fact fa ON fa.accession_id = f.accession_id
           AND fa.standard_concept IN ('LongTermDebt', 'StockholdersEquity')
WHERE r.is_sp500 = TRUE
  AND r.sector ILIKE '%technology%'
GROUP BY r.symbol, r.name, r.sector, f.filing_date
ORDER BY debt_to_equity DESC NULLS LAST;
```

One `fact` scan, two metrics. Add more concepts to the `IN` list and `CASE WHEN` blocks to extend.

---

## Pattern 4 — QUALIFY for Latest Record (DuckDB-native)

**Goal:** Filter to the most recent row within a group without a subquery or CTE.

```sql
-- Most recent active ticker per entity
SELECT cik, name, sector, symbol, exchange
FROM   references
WHERE  is_active = TRUE
QUALIFY ROW_NUMBER() OVER (PARTITION BY cik ORDER BY valid_from DESC) = 1;
```

```sql
-- Latest 10-Q per company — one row each
SELECT entity_id, accession_id, filing_date
FROM   filing
WHERE  form_type = '10-Q'
QUALIFY ROW_NUMBER() OVER (PARTITION BY entity_id ORDER BY filing_date DESC) = 1;
```

`QUALIFY` is DuckDB-native. Use it instead of wrapping in a subquery or CTE when you
only need to filter by window rank.

---

## Pattern 5 — FCF Across S&P 500 (Latest Quarter)

**Goal:** Free Cash Flow = Operating Cash Flow − CapEx, isolated to a single quarter.

```sql
WITH latest_10q AS (
  SELECT entity_id, accession_id, filing_date
  FROM   filing
  WHERE  form_type = '10-Q'
  QUALIFY ROW_NUMBER() OVER (PARTITION BY entity_id ORDER BY filing_date DESC) = 1
),
fcf AS (
  SELECT
    fa.accession_id,
    -- derived_quarterly_value isolates one quarter from YTD cumulative filings (Q2, Q3)
    MAX(CASE WHEN fa.standard_concept = 'OperatingCashFlow'
        THEN COALESCE(fa.derived_quarterly_value, fa.numeric_value) END) AS ocf,
    MAX(CASE WHEN fa.standard_concept = 'CAPEX'
        THEN COALESCE(fa.derived_quarterly_value, fa.numeric_value) END) AS capex
  FROM fact fa
  WHERE fa.standard_concept IN ('OperatingCashFlow', 'CAPEX')
  GROUP BY fa.accession_id
)
SELECT
  r.symbol,
  r.name,
  r.sector,
  q.filing_date,
  fcf.ocf / 1e6                           AS ocf_millions,
  ABS(fcf.capex) / 1e6                    AS capex_millions,
  (fcf.ocf - ABS(fcf.capex)) / 1e6       AS fcf_millions
FROM references r
JOIN latest_10q q  ON q.entity_id = r.cik
JOIN fcf           ON fcf.accession_id = q.accession_id
WHERE r.is_sp500 = TRUE
ORDER BY fcf_millions DESC NULLS LAST
LIMIT 20;
```

`derived_quarterly_value` is pre-computed by the pipeline — Q2/Q3 10-Qs report YTD cash
flow; this column gives the isolated quarter. `ABS(capex)` handles filers that report CapEx
as negative vs positive.

---

## Pattern 6 — Point-in-Time Backtest Filter

**Goal:** Reconstruct the information set known on a specific trade date — zero look-ahead bias.

```sql
-- What was known about AAPL revenue on 2024-01-15?
SELECT
  fa.period_end,
  fa.fiscal_period,
  fa.numeric_value / 1e9 AS revenue_billions,
  fa.knowledge_at        -- when the market learned this
FROM references r
JOIN fact fa ON fa.entity_id = r.cik
           AND fa.standard_concept = 'TotalRevenue'
WHERE r.symbol = 'AAPL'
  AND fa.knowledge_at <= '2024-01-15'    -- ← PIT filter: only what was filed by this date
  AND fa.filing_date  <= '2024-01-15'    -- ← belt-and-suspenders: filing received by SEC
ORDER BY fa.period_end DESC
LIMIT 10;
```

Always filter by `filing_date <= trade_date` (or `knowledge_at`), never `report_date`.
`report_date` is fiscal period end — using it introduces look-ahead bias.

---

## Pattern 7 — Amendment & Restatement Audit

**Goal:** Track how a financial value changed between original filing and amendments.

```sql
SELECT
  f.filing_date,
  f.is_amendment,
  f.amendment_no,
  fa.standard_concept,
  fa.numeric_value / 1e9 AS value_billions
FROM filing f
JOIN fact fa ON fa.accession_id = f.accession_id
           AND fa.standard_concept = 'NetIncome'
WHERE f.entity_id = '0001067983'     -- Berkshire Hathaway CIK
  AND f.form_type = '10-K'
ORDER BY f.filing_date DESC, f.amendment_no ASC;
```

---

## Pattern 8 — Human-Readable Concept Labels

**Goal:** Map `standard_concept` codes to definitions and unit types.

```sql
SELECT
  fa.standard_concept,
  tg.human_name,
  tg.definition,
  tg.unit_type,
  fa.numeric_value
FROM fact fa
JOIN taxonomy_guide tg ON tg.standard_concept = fa.standard_concept
WHERE fa.accession_id = '0001047469-24-000012';
```

---

## Key Rules

| Rule | Detail |
|---|---|
| **`references` first** | Start every cross-company query with `references`, not `entity + security + index_membership` |
| **`LATERAL` for latest** | Use `LATERAL (... ORDER BY filing_date DESC LIMIT 1)` — cleaner than correlated subqueries |
| **Pivot, don't self-join** | Use `MAX(CASE WHEN standard_concept = '...' THEN ...)` to pull multiple concepts in one `fact` scan |
| **`QUALIFY` not subqueries** | DuckDB-native `QUALIFY ROW_NUMBER() OVER (...) = 1` replaces `DISTINCT ON` wrappers |
| **`derived_quarterly_value`** | Use `COALESCE(derived_quarterly_value, numeric_value)` for quarterly cash flow — Q2/Q3 10-Qs are YTD |
| **`ABS(capex)`** | CapEx sign varies by filer — always wrap in `ABS()` |
| **PIT filter** | `filing_date <= trade_date` not `report_date <= trade_date` |
| **`NULLIF` for ratios** | Protect every division: `/ NULLIF(denominator, 0)` |
| **`standard_concept` not `concept`** | Use the normalized label (`'TotalRevenue'`), not the raw XBRL tag (`'us-gaap:Revenues'`) |
