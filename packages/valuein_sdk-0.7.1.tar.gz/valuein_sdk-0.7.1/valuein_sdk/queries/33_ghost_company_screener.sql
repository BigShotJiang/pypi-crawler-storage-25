-- Identifies companies whose last_seen_at date is unusually old, indicating a halt in SEC reporting or a potential de-listing event.

SELECT
    cik,
    name,
    industry,
    last_seen_at,
    DATEDIFF('day', last_seen_at, CURRENT_DATE) AS days_since_last_filing
FROM entity
WHERE status = 'ACTIVE'
  AND DATEDIFF('day', last_seen_at, CURRENT_DATE) > 180
ORDER BY days_since_last_filing DESC;
