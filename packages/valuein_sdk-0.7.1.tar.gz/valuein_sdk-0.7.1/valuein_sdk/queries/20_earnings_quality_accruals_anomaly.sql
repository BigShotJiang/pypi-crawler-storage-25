-- Calculates the Sloan Accruals Anomaly (Net Income minus Operating Cash Flow, scaled by Assets).
-- High accruals predict future stock underperformance.

WITH financials AS (
    SELECT
        entity_id,
        standard_concept,
        numeric_value
    FROM fact
    WHERE frame = '{frame}'
      AND standard_concept IN ('NetIncomeLoss', 'NetCashProvidedByUsedInOperatingActivities', 'Assets')
)
SELECT
    entity_id,
    SUM(CASE WHEN standard_concept = 'NetIncomeLoss' THEN numeric_value ELSE 0 END) -
    SUM(CASE WHEN standard_concept = 'NetCashProvidedByUsedInOperatingActivities' THEN numeric_value ELSE 0 END) AS total_accruals
FROM financials
GROUP BY entity_id;
