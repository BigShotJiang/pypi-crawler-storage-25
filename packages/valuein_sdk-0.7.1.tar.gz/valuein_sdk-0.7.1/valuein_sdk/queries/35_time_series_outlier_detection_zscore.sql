-- Finds anomalous spikes in expenses or revenues using rolling averages and standard deviations.

WITH rolling_stats AS (
    SELECT
        entity_id,
        period_end,
        numeric_value,
        AVG(numeric_value) OVER (PARTITION BY entity_id ORDER BY period_end ROWS BETWEEN 8 PRECEDING AND 1 PRECEDING) as rolling_avg,
        STDDEV(numeric_value) OVER (PARTITION BY entity_id ORDER BY period_end ROWS BETWEEN 8 PRECEDING AND 1 PRECEDING) as rolling_stddev
    FROM fact
    WHERE standard_concept = '{metric}'
)
SELECT
    entity_id,
    period_end,
    numeric_value,
    (numeric_value - rolling_avg) / NULLIF(rolling_stddev, 0) AS z_score
FROM rolling_stats
WHERE ABS((numeric_value - rolling_avg) / NULLIF(rolling_stddev, 0)) > 3.0;
