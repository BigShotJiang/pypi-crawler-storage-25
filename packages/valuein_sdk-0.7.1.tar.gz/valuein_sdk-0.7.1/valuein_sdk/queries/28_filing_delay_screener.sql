-- Screens for companies delaying their reports (a strong short signal).

SELECT
    r.symbol AS ticker,
    f.form_type,
    f.report_date,
    f.filing_date,
    date_diff('day', f.report_date, f.filing_date) AS reporting_delay_days
FROM filing f
JOIN "references" r ON f.entity_id = r.cik
WHERE r.is_active = TRUE
  AND f.form_type IN ('10-K', '10-Q')
  AND f.filing_date BETWEEN '{start_date}' AND '{end_date}'
ORDER BY reporting_delay_days DESC
LIMIT 50;
