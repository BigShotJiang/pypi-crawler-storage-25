-- Isolates is_amendment = TRUE filings to track companies that retroactively revised their
-- historical earnings downward (Quality of Earnings red flag).

SELECT
    filing.entity_id,
    filing.filing_date,
    filing.amendment_no,
    f.standard_concept,
    f.numeric_value
FROM filing
JOIN fact f ON filing.accession_id = f.accession_id
WHERE filing.is_amendment = TRUE
  AND f.standard_concept = 'NetIncomeLoss'
  AND filing.filing_date BETWEEN '{start_date}' AND '{end_date}'
ORDER BY filing.filing_date DESC;
