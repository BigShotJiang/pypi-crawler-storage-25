-- Reconstructs total revenue or earnings across the S&P 500 for macro analysis.
-- Uses references.is_sp500 for a clean single-join universe.
-- For other indices (e.g. RUSSELL2000), join index_membership directly instead.

SELECT
    f.period_end,
    SUM(f.numeric_value) AS total_sp500_revenue
FROM "references" r
JOIN fact f ON r.cik = f.entity_id
WHERE r.is_sp500 = TRUE
  AND r.is_active = TRUE
  AND f.standard_concept = 'Revenues'
  AND f.frame = '{frame}'
GROUP BY f.period_end
ORDER BY f.period_end DESC;
