-- Filters entities based on the Market Identification Code (MIC) to isolate domestic vs. foreign-listed ADRs.

SELECT
    r.symbol,
    r.exchange,
    r.mic,
    f.numeric_value,
    f.unit
FROM "references" r
JOIN fact f ON r.cik = f.entity_id
WHERE r.mic = '{mic_code}' -- e.g., 'XNYS' for NYSE
  AND r.is_active = TRUE
  AND f.standard_concept = 'NetIncomeLoss'
  AND f.frame = '{frame}' -- e.g., 'CY2023Q4'
ORDER BY f.numeric_value DESC;
