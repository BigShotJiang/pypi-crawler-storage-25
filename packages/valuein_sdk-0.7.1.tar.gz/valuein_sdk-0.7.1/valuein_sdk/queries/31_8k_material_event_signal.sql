-- Scans the items array in 8-K filings to find distressed companies (e.g., Item 1.03 Bankruptcy)
-- or executive departures (Item 5.02).

SELECT
    r.cik,
    r.symbol,
    filing.filing_date,
    filing.items
FROM filing
JOIN "references" r ON filing.entity_id = r.cik
WHERE filing.form_type = '8-K'
  AND '{target_item_code}' = ANY(filing.items) -- e.g., '1.03'
  AND filing.filing_date BETWEEN '{start_date}' AND '{end_date}'
  AND r.is_active = TRUE;
