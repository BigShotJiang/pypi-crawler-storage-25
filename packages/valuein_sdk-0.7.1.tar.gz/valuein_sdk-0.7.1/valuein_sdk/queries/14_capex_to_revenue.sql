-- Extracts Revenues and Capital Expenditures to calculate the CapEx-to-Revenue ratio.

WITH target_filings AS (
    SELECT
        f.accession_id,
        f.report_date
    FROM filing f
    JOIN "references" r ON f.entity_id = r.cik
    WHERE r.symbol = '{ticker}'
      AND r.is_active = TRUE
      AND f.form_type IN ({form_types})
      AND f.filing_date BETWEEN '{start_date}' AND '{end_date}'
)
SELECT
    tf.report_date,
    fa.standard_concept,
    fa.numeric_value
FROM target_filings tf
JOIN fact fa
  ON tf.accession_id = fa.accession_id
WHERE fa.standard_concept IN ('Revenues', 'PaymentsToAcquirePropertyPlantAndEquipment')
ORDER BY tf.report_date DESC;
