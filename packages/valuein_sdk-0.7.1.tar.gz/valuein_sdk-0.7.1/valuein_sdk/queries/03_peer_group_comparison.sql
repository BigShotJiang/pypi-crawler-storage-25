-- Compares specified metrics across an array of competitor tickers.

WITH target_filings AS (
    SELECT
        f.accession_id,
        r.symbol,
        f.report_date
    FROM filing f
    JOIN "references" r ON f.entity_id = r.cik
    WHERE r.symbol IN ({tickers})
      AND r.is_active = TRUE
      AND f.form_type IN ({form_types})
      AND f.filing_date BETWEEN '{start_date}' AND '{end_date}'
)
SELECT
    tf.symbol,
    tf.report_date,
    fa.standard_concept,
    fa.numeric_value,
    fa.unit
FROM target_filings tf
JOIN fact fa
  ON tf.accession_id = fa.accession_id
WHERE fa.standard_concept IN ({metrics})
ORDER BY tf.report_date DESC, tf.symbol;
