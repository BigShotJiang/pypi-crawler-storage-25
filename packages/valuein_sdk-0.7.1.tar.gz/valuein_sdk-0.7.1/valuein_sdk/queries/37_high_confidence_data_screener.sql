-- Filters out messy data by enforcing high confidence_score and isolating only is_audited = TRUE annual facts.

SELECT
    entity_id,
    standard_concept,
    numeric_value,
    confidence_score
FROM fact
WHERE is_audited = TRUE
  AND is_estimated = FALSE
  AND confidence_score >= 0.95
  AND frame = '{frame}'
ORDER BY confidence_score ASC;
