-- Aggregates total capex or revenue by entity.location to map out regional economic hotspots or tax-haven dependencies.

SELECT
    e.state_of_incorporation,
    COUNT(DISTINCT e.cik) as entity_count,
    SUM(f.numeric_value) as total_regional_metric
FROM entity e
JOIN fact f ON e.cik = f.entity_id
WHERE f.standard_concept = '{metric}'
  AND f.frame = '{frame}'
GROUP BY e.state_of_incorporation
ORDER BY total_regional_metric DESC;
