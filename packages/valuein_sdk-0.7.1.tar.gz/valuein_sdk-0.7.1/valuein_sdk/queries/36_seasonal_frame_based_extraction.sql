-- Aligns Q1 data perfectly across companies, regardless of their weird fiscal_year_end calendars,
-- by relying on your standardized frame logic.

SELECT
    e.name,
    f.fiscal_year,
    f.fiscal_period,
    f.numeric_value
FROM fact f
JOIN entity e ON f.entity_id = e.cik
WHERE f.standard_concept = 'Revenues'
  AND f.fiscal_period = 'Q1'
  AND f.fiscal_year >= 2020
ORDER BY e.name, f.fiscal_year;
