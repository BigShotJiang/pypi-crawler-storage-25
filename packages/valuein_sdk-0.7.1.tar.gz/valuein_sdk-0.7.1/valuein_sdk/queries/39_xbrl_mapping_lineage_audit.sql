-- Shows exactly which raw xbrl_tag was parsed to create the standard_concept. Vital for resolving data disputes.

SELECT
    f.accession_id,
    f.standard_concept,
    c.xbrl_tag,
    c.priority,
    f.numeric_value
FROM fact f
JOIN concept_mapping c ON f.standard_concept = c.standard_concept
WHERE f.entity_id = '{cik}'
  AND f.frame = '{frame}';
