-- A classic short-selling signal. Calculates the delay between the end of the quarter and the actual filing date.

SELECT
    r.cik,
    r.symbol,
    filing.form_type,
    filing.report_date,
    filing.filing_date,
    (filing.filing_date - filing.report_date) AS reporting_delay_days
FROM filing
JOIN "references" r ON filing.entity_id = r.cik
WHERE filing.form_type IN ('10-K', '10-Q')
  AND filing.filing_date BETWEEN '{start_date}' AND '{end_date}'
  AND r.is_active = TRUE
ORDER BY reporting_delay_days DESC
LIMIT 100;
