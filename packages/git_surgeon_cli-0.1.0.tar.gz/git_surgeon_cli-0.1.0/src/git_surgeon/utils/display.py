"""Rich-powered display helpers for git-surgeon CLI output."""

from __future__ import annotations

from rich.console import Console
from rich.panel import Panel
from rich.prompt import Confirm
from rich.syntax import Syntax
from rich.table import Table
from rich.text import Text

console = Console()
error_console = Console(stderr=True)


def print_banner() -> None:
    """Print the git-surgeon banner."""
    banner = Text("🔪 git-surgeon", style="bold cyan")
    banner.append(" — surgical git history rewriting", style="dim")
    console.print(banner)
    console.print()


def print_preview(preview: dict) -> None:
    """Print a formatted preview of the planned rewrite."""
    commit_count = preview.get("commit_count", 0)
    operations = preview.get("operations", [])
    callback = preview.get("callback", "(none)")
    replace_text = preview.get("replace_text", [])
    warnings = preview.get("warnings", [])

    # Warnings
    if warnings:
        for w in warnings:
            console.print(f"  [yellow]⚠ {w}[/yellow]")
        console.print()

    # Summary table
    table = Table(title="Rewrite Preview", title_style="bold magenta")
    table.add_column("Property", style="cyan")
    table.add_column("Value", style="white")
    table.add_row("Commits in repo", str(commit_count))
    table.add_row("Operations", str(len(operations)))
    table.add_row(
        "Has callback", "Yes" if callback != "(none — no callback operations)" else "No"
    )
    table.add_row("Replace-text rules", str(len(replace_text)))
    console.print(table)
    console.print()

    # Operation details
    if operations:
        console.print("[bold]Operations:[/bold]")
        for desc in operations:
            for line in desc.split("\n"):
                console.print(f"  {line}")
        console.print()

    # Author impact report (shown during preview / dry-run)
    author_impact = preview.get("author_impact")
    if author_impact:
        self_email = preview.get("self_email", "")
        has_non_analyzable = preview.get("has_non_analyzable_author_rules", False)
        print_author_impact_report(author_impact, self_email, has_non_analyzable)

    # Callback code
    if callback and callback != "(none — no callback operations)":
        console.print(
            Panel(
                Syntax(callback, "python", theme="monokai", line_numbers=True),
                title="Generated Callback",
                border_style="green",
            )
        )
        console.print()

    # Replace-text entries
    if replace_text:
        console.print("[bold]Replace-text patterns:[/bold]")
        for entry in replace_text:
            console.print(f"  [dim]{entry}[/dim]")
        console.print()


def print_author_impact_report(
    impact: list[dict],
    self_email: str,
    has_non_analyzable: bool,
) -> None:
    """Print a table of authors affected by AuthorRewrite rules (preview/dry-run only)."""
    affected = [a for a in impact if a.get("will_change")]
    if not affected and not has_non_analyzable:
        return

    table = Table(title="Author Impact Report", title_style="bold yellow")
    table.add_column("Original Name", style="white")
    table.add_column("Original Email", style="dim")
    table.add_column("→ New Name", style="green")
    table.add_column("→ New Email", style="dim green")
    table.add_column("Commits", style="cyan", justify="right")
    table.add_column("Owner", justify="center")

    for a in affected:
        owner = (
            "[bold green]you[/bold green]"
            if a["is_self"]
            else "[bold red]other[/bold red]"
        )
        table.add_row(
            a["original_name"],
            a["original_email"],
            a.get("new_name") or "?",
            a.get("new_email") or "?",
            str(a["commit_count"]),
            owner,
        )

    console.print(table)

    if has_non_analyzable:
        console.print(
            "  [yellow]⚠ Some rules match on commit message/subject — additional"
            " authors may be affected (cannot be determined statically).[/yellow]"
        )
    if not self_email:
        console.print(
            "  [yellow]⚠ git config user.email not set — cannot identify which"
            " commits belong to you.[/yellow]"
        )
    console.print()


def print_success(message: str) -> None:
    console.print(f"[bold green]✓[/bold green] {message}")


def print_error(message: str) -> None:
    error_console.print(f"[bold red]✗[/bold red] {message}")


def print_warning(message: str) -> None:
    console.print(f"[yellow]⚠[/yellow] {message}")


def print_info(message: str) -> None:
    console.print(f"[cyan]ℹ[/cyan] {message}")


def print_validation_errors(errors: dict[str, list[str]]) -> None:
    """Print validation errors grouped by operation."""
    console.print("[bold red]Validation errors:[/bold red]")
    for name, errs in errors.items():
        console.print(f"  [bold]{name}:[/bold]")
        for e in errs:
            console.print(f"    [red]• {e}[/red]")


def confirm_action(message: str, default: bool = False) -> bool:
    """Ask the user for confirmation."""
    return Confirm.ask(message, default=default)
