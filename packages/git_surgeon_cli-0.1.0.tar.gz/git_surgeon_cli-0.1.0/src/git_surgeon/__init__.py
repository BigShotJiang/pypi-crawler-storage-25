"""git-surgeon: A modular toolkit for rewriting git history."""
