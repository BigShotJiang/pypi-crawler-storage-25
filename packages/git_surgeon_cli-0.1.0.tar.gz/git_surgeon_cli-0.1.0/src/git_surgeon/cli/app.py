"""Main Typer application — entry point for git-surgeon CLI."""

from __future__ import annotations

from pathlib import Path
from typing import Annotated, Optional

import typer

from git_surgeon.cli.commands import (
    flatten,
    init,
    preview,
    rewrite_authors,
    run,
    scrub,
    undo,
    filter_commits,
)

app = typer.Typer(
    name="git-surgeon",
    help="🔪 Surgical git history rewriting — author rewrite, message scrub, blob scrub, and more.",
    invoke_without_command=True,
    no_args_is_help=False,
    rich_markup_mode="rich",
)

# Register subcommands
app.command(name="init")(init.init_cmd)
app.command(name="run")(run.run_cmd)
app.command(name="preview")(preview.preview_cmd)
app.command(name="rewrite-authors")(rewrite_authors.rewrite_authors_cmd)
app.command(name="scrub")(scrub.scrub_cmd)
app.command(name="flatten")(flatten.flatten_cmd)
app.command(name="filter")(filter_commits.filter_cmd)
app.command(name="undo")(undo.undo_cmd)


@app.callback()
def main(
    ctx: typer.Context,
    repo: Annotated[
        Optional[Path],
        typer.Option("--repo", "-r", help="Path to the target git repository."),
    ] = None,
    dry_run: Annotated[
        bool,
        typer.Option(
            "--dry-run", "-n", help="Preview changes without modifying the repo."
        ),
    ] = False,
    force: Annotated[
        bool,
        typer.Option("--force", "-f", help="Skip confirmation prompts."),
    ] = False,
    verbose: Annotated[
        bool,
        typer.Option("--verbose", "-v", help="Enable verbose output."),
    ] = False,
) -> None:
    """git-surgeon — surgical git history rewriting.

    Run without a subcommand to launch the interactive wizard.
    """
    # Store globals in context for subcommands
    ctx.ensure_object(dict)
    ctx.obj["repo"] = repo
    ctx.obj["dry_run"] = dry_run
    ctx.obj["force"] = force
    ctx.obj["verbose"] = verbose

    if ctx.invoked_subcommand is None:
        # No subcommand → launch interactive wizard
        from git_surgeon.cli.wizard import run_wizard

        run_wizard(repo=repo, dry_run=dry_run, force=force)
