"""Interactive wizard — launched when git-surgeon is run with no subcommand."""

from __future__ import annotations

from pathlib import Path

from rich.prompt import Confirm, Prompt

from git_surgeon.core.config import Config
from git_surgeon.core.engine import Engine, EngineError
from git_surgeon.core.repo import (
    RepoError,
    ensure_gitignore,
    find_repo_root,
    get_commit_count,
)
from git_surgeon.operations.author_rewrite import AuthorRewrite, AuthorRule
from git_surgeon.operations.blob_scrub import BlobScrub
from git_surgeon.operations.commit_filter import CommitFilter, FilterRule
from git_surgeon.operations.merge_flatten import MergeFlatten
from git_surgeon.operations.message_scrub import MessageScrub
from git_surgeon.utils.display import (
    confirm_action,
    print_banner,
    print_error,
    print_info,
    print_preview,
    print_success,
    print_validation_errors,
    print_warning,
    console,
)


def run_wizard(
    repo: Path | None = None,
    dry_run: bool = False,
    force: bool = False,
) -> None:
    """Interactive wizard for configuring and running git-surgeon."""
    print_banner()

    # Step 1: Find repo
    try:
        repo_root = find_repo_root(repo)
    except RepoError as exc:
        print_error(str(exc))
        return

    commit_count = get_commit_count(repo_root)
    print_info(f"Repository: {repo_root}")
    print_info(f"Commits: {commit_count}")
    console.print()

    # Step 2: Select operations
    console.print("[bold]Select operations to perform:[/bold]")
    console.print("  1. Rewrite authors")
    console.print("  2. Scrub commit messages")
    console.print("  3. Scrub file contents (blobs)")
    console.print("  4. Flatten merge commits")
    console.print("  5. Filter commits")
    console.print()

    selection = Prompt.ask(
        "Enter operation numbers (comma-separated)",
        default="1,2,3,4",
    )
    selected = {s.strip() for s in selection.split(",")}

    operations = []

    # Step 3: Configure each selected operation
    if "1" in selected:
        console.print("\n[bold cyan]── Author Rewrite ──[/bold cyan]")
        op = _configure_author_rewrite()
        if op:
            operations.append(op)

    if "2" in selected:
        console.print("\n[bold cyan]── Message Scrub ──[/bold cyan]")
        op = _configure_message_scrub()
        if op:
            operations.append(op)

    if "3" in selected:
        console.print("\n[bold cyan]── Blob Scrub ──[/bold cyan]")
        op = _configure_blob_scrub()
        if op:
            operations.append(op)

    if "4" in selected:
        console.print("\n[bold cyan]── Merge Flatten ──[/bold cyan]")
        operations.append(MergeFlatten(enabled=True))
        print_success("Merge flattening enabled.")

    if "5" in selected:
        console.print("\n[bold cyan]── Commit Filter ──[/bold cyan]")
        op = _configure_commit_filter()
        if op:
            operations.append(op)

    if not operations:
        print_warning("No operations configured. Exiting.")
        return

    # Step 4: Preview
    console.print()
    engine = Engine(
        repo_path=repo_root,
        operations=operations,
        dry_run=True,
        force=force,
    )

    errors = engine.validate()
    if errors:
        print_validation_errors(errors)
        return

    preview_data = engine.preview()
    print_preview(preview_data)

    # Step 5: Save config
    if Confirm.ask("Save configuration to .git-surgeon/config.toml?", default=True):
        config = Config(operations=operations)
        config.save(repo_root)
        ensure_gitignore(repo_root)
        print_success("Configuration saved. Added .git-surgeon/ to .gitignore.")

    # Step 6: Execute
    if dry_run:
        print_info("Dry run mode — no changes made.")
        return

    if force or confirm_action(
        f"Execute rewrite on {commit_count} commit(s)?",
        default=False,
    ):
        engine.dry_run = False
        engine.force = force
        try:
            print_info("Creating backup bundle...")
            engine.run()
            print_success("History rewritten successfully!")
            print_info(
                "Backup saved to .git-surgeon/backup.bundle. "
                "Run 'git-surgeon undo' to restore."
            )
        except EngineError as exc:
            print_error(str(exc))
    else:
        print_info("Aborted. Config saved — run 'git-surgeon run' to execute later.")


def _configure_author_rewrite() -> AuthorRewrite | None:
    """Interactive author rewrite configuration."""
    rules: list[AuthorRule] = []

    while True:
        is_default = Confirm.ask(
            "Add a default (catch-all) author?", default=len(rules) == 0
        )

        new_name = Prompt.ask("Author name")
        new_email = Prompt.ask("Author email")

        if is_default:
            rules.append(
                AuthorRule(
                    is_default=True,
                    new_name=new_name,
                    new_email=new_email,
                )
            )
        else:
            match_field = Prompt.ask(
                "Match field",
                choices=["subject", "author_name", "author_email", "message", "all"],
                default="subject",
            )
            match_pattern = Prompt.ask("Match pattern (text to match)")
            is_regex = Confirm.ask("Is regex?", default=False)

            rules.append(
                AuthorRule(
                    match_field=match_field,
                    match_pattern=match_pattern,
                    new_name=new_name,
                    new_email=new_email,
                    is_regex=is_regex,
                )
            )

        if not Confirm.ask("Add another author rule?", default=False):
            break

    return AuthorRewrite(rules=rules) if rules else None


def _configure_message_scrub() -> MessageScrub | None:
    """Interactive message scrub configuration."""
    scrub = MessageScrub()

    while True:
        find = Prompt.ask("Find text in commit messages")
        replace = Prompt.ask("Replace with", default="***REMOVED***")
        is_regex = Confirm.ask("Is regex?", default=False)
        scrub.add_replacement(find, replace, is_regex=is_regex)

        if not Confirm.ask("Add another message replacement?", default=False):
            break

    return scrub if scrub.replacements else None


def _configure_blob_scrub() -> BlobScrub | None:
    """Interactive blob scrub configuration."""
    scrub = BlobScrub()

    while True:
        find = Prompt.ask("Find text in file contents")
        replace = Prompt.ask("Replace with", default="***REMOVED***")
        is_regex = Confirm.ask("Is regex?", default=False)
        scrub.add_replacement(find, replace, is_regex=is_regex)

        if not Confirm.ask("Add another blob replacement?", default=False):
            break

    return scrub if scrub.replacements else None


def _configure_commit_filter() -> CommitFilter | None:
    """Interactive commit filter configuration."""
    rules: list[FilterRule] = []

    while True:
        field = Prompt.ask(
            "Match field",
            choices=["author_name", "author_email", "subject", "message", "date"],
            default="author_name",
        )
        pattern = Prompt.ask("Pattern to match")
        action = Prompt.ask("Action", choices=["remove", "keep"], default="remove")
        is_regex = Confirm.ask("Is regex?", default=False)

        rules.append(
            FilterRule(
                field=field,
                pattern=pattern,
                action=action,
                is_regex=is_regex,
            )
        )

        if not Confirm.ask("Add another filter rule?", default=False):
            break

    return CommitFilter(rules=rules) if rules else None
