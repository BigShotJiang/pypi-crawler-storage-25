"""git-surgeon undo — restore from backup bundle."""

from __future__ import annotations

from pathlib import Path
from typing import Annotated, Optional

import typer

from git_surgeon.core.repo import RepoError, find_repo_root
from git_surgeon.core.safety import (
    BackupError,
    get_backup_info,
    has_backup,
    restore_backup,
)
from git_surgeon.utils.display import (
    confirm_action,
    print_error,
    print_info,
    print_success,
)


def undo_cmd(
    ctx: typer.Context,
    repo: Annotated[
        Optional[Path],
        typer.Option("--repo", "-r", help="Path to the target git repository."),
    ] = None,
    force: Annotated[
        Optional[bool],
        typer.Option("--force", "-f", help="Skip confirmation prompt."),
    ] = None,
) -> None:
    """Undo the last rewrite by restoring from the backup bundle."""
    obj = ctx.obj or {}
    repo_path_opt = repo or obj.get("repo")
    is_force = force if force is not None else obj.get("force", False)

    try:
        repo_root = find_repo_root(repo_path_opt)
    except RepoError as exc:
        print_error(str(exc))
        raise typer.Exit(1) from exc

    if not has_backup(repo_root):
        print_error(
            "No backup found. Cannot undo — no previous 'git-surgeon run' "
            "created a backup bundle."
        )
        raise typer.Exit(1)

    info = get_backup_info(repo_root)
    print_info(f"Backup bundle: {info.get('bundle_path', 'unknown')}")
    print_info(f"Bundle size: {info.get('bundle_size', 'unknown')}")
    if "original_head" in info:
        print_info(f"Original HEAD: {info['original_head']}")

    if not is_force:
        if not confirm_action(
            "This will restore the repository to its pre-rewrite state. Continue?",
            default=False,
        ):
            print_info("Aborted.")
            raise typer.Exit(0)

    try:
        restore_backup(repo_root)
        print_success("Repository restored to pre-rewrite state!")
    except BackupError as exc:
        print_error(str(exc))
        raise typer.Exit(1) from exc
