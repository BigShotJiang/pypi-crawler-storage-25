"""git-surgeon run — execute all configured operations."""

from __future__ import annotations

from pathlib import Path
from typing import Annotated, Optional

import typer

from git_surgeon.core.config import Config
from git_surgeon.core.engine import Engine, EngineError
from git_surgeon.core.repo import RepoError, find_repo_root, get_commit_count
from git_surgeon.utils.display import (
    confirm_action,
    print_error,
    print_info,
    print_preview,
    print_success,
    print_validation_errors,
    print_warning,
)


def run_cmd(
    ctx: typer.Context,
    repo: Annotated[
        Optional[Path],
        typer.Option("--repo", "-r", help="Path to the target git repository."),
    ] = None,
    dry_run: Annotated[
        Optional[bool],
        typer.Option("--dry-run", "-n", help="Preview changes without executing."),
    ] = None,
    force: Annotated[
        Optional[bool],
        typer.Option("--force", "-f", help="Skip confirmation prompt."),
    ] = None,
    skip_backup: Annotated[
        bool,
        typer.Option("--skip-backup", help="Skip creating a backup bundle."),
    ] = False,
    protect_others: Annotated[
        bool,
        typer.Option(
            "--protect-others",
            help="Only allow rewriting commits authored by you (git config user.email)."
            " Commits from other authors are left untouched by author-rewrite rules.",
        ),
    ] = False,
    auto_stash: Annotated[
        bool,
        typer.Option(
            "--auto-stash",
            help="Automatically stash uncommitted changes before rewriting and"
            " restore them afterwards.",
        ),
    ] = False,
) -> None:
    """Run all operations from .git-surgeon/config.toml."""
    obj = ctx.obj or {}
    repo_path = repo or obj.get("repo")
    is_dry_run = dry_run if dry_run is not None else obj.get("dry_run", False)
    is_force = force if force is not None else obj.get("force", False)

    try:
        repo_root = find_repo_root(repo_path)
    except RepoError as exc:
        print_error(str(exc))
        raise typer.Exit(1) from exc

    # Load config
    config = Config.load(repo_root)
    if not config.operations:
        print_error(
            "No operations configured. Run 'git-surgeon init' or use subcommands "
            "to add operations."
        )
        raise typer.Exit(1)

    # Create engine
    engine = Engine.from_config(
        config,
        repo_root,
        dry_run=is_dry_run,
        force=is_force,
        skip_backup=skip_backup,
        protect_others=protect_others,
        auto_stash=auto_stash,
    )

    # Validate
    errors = engine.validate()
    if errors:
        print_validation_errors(errors)
        raise typer.Exit(1)

    # Preview
    preview_data = engine.preview()
    print_preview(preview_data)

    if is_dry_run:
        print_info("Dry run — no changes made.")
        return

    # Confirm
    commit_count = get_commit_count(repo_root)
    if not is_force:
        if not confirm_action(
            f"This will rewrite {commit_count} commit(s). Continue?",
            default=False,
        ):
            print_info("Aborted.")
            raise typer.Exit(0)

    # Execute
    try:
        if auto_stash:
            print_info("Auto-stashing uncommitted changes...")
        if not skip_backup:
            print_info("Creating backup bundle...")
        engine.run()
        print_success("History rewritten successfully!")
        if auto_stash:
            print_info("Auto-stash restored.")
        if not skip_backup:
            print_info(
                "Backup saved to .git-surgeon/backup.bundle. "
                "Use 'git-surgeon undo' to restore."
            )
    except EngineError as exc:
        print_error(str(exc))
        raise typer.Exit(1) from exc
