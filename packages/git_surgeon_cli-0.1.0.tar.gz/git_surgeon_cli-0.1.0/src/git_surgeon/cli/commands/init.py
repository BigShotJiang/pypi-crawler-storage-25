"""git-surgeon init — initialize .git-surgeon/ config directory."""

from __future__ import annotations

from pathlib import Path
from typing import Annotated, Optional

import typer

from git_surgeon.core.config import Config
from git_surgeon.core.repo import RepoError, ensure_gitignore, find_repo_root
from git_surgeon.utils.display import print_error, print_info, print_success


def init_cmd(
    ctx: typer.Context,
    repo: Annotated[
        Optional[Path],
        typer.Option("--repo", "-r", help="Path to the target git repository."),
    ] = None,
    template: Annotated[
        bool,
        typer.Option("--template", "-t", help="Generate a commented template config."),
    ] = True,
) -> None:
    """Initialize .git-surgeon/ directory with a config template."""
    repo_path = repo or (ctx.obj or {}).get("repo")
    try:
        repo_root = find_repo_root(repo_path)
    except RepoError as exc:
        print_error(str(exc))
        raise typer.Exit(1) from exc

    config_dir = Config.config_dir(repo_root)

    if config_dir.exists():
        print_info(f".git-surgeon/ already exists at {config_dir}")
    else:
        config_dir.mkdir(parents=True)
        print_success(f"Created {config_dir}")

    config_file = Config.config_file(repo_root)
    if not config_file.exists():
        if template:
            config_file.write_text(Config.generate_template(), encoding="utf-8")
            print_success(f"Created template config at {config_file}")
        else:
            config = Config()
            config.save(repo_root)
            print_success(f"Created empty config at {config_file}")
    else:
        print_info(f"Config already exists at {config_file}")

    if ensure_gitignore(repo_root):
        print_success("Added .git-surgeon/ to .gitignore")
    else:
        print_info(".git-surgeon/ already in .gitignore")
