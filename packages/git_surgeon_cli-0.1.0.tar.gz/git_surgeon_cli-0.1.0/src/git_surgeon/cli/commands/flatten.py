"""git-surgeon flatten — linearize merge history."""

from __future__ import annotations

from pathlib import Path
from typing import Annotated, Optional

import typer

from git_surgeon.core.config import Config
from git_surgeon.core.engine import Engine, EngineError
from git_surgeon.core.repo import RepoError, find_repo_root, get_commit_count
from git_surgeon.operations.merge_flatten import MergeFlatten
from git_surgeon.utils.display import (
    confirm_action,
    print_error,
    print_info,
    print_preview,
    print_success,
)


def flatten_cmd(
    ctx: typer.Context,
    repo: Annotated[
        Optional[Path],
        typer.Option("--repo", "-r", help="Path to the target git repository."),
    ] = None,
    save: Annotated[
        bool,
        typer.Option("--save/--no-save", help="Save to config."),
    ] = True,
    execute: Annotated[
        bool,
        typer.Option("--execute", "-x", help="Execute immediately."),
    ] = False,
    dry_run: Annotated[
        Optional[bool],
        typer.Option("--dry-run", "-n", help="Preview only."),
    ] = None,
    force: Annotated[
        Optional[bool],
        typer.Option("--force", "-f", help="Skip confirmation."),
    ] = None,
    auto_stash: Annotated[
        bool,
        typer.Option(
            "--auto-stash",
            help="Stash uncommitted changes before rewriting and restore afterwards.",
        ),
    ] = False,
) -> None:
    """Flatten merge commits by keeping only the first parent (linearize history)."""
    obj = ctx.obj or {}
    repo_path_opt = repo or obj.get("repo")
    is_dry_run = dry_run if dry_run is not None else obj.get("dry_run", False)
    is_force = force if force is not None else obj.get("force", False)

    try:
        repo_root = find_repo_root(repo_path_opt)
    except RepoError as exc:
        print_error(str(exc))
        raise typer.Exit(1) from exc

    flatten_op = MergeFlatten(enabled=True)
    config = Config.load(repo_root)
    config.add_operation(flatten_op)

    if save:
        config.save(repo_root)
        print_success("Saved merge flatten config.")

    if execute or is_dry_run:
        engine = Engine(
            repo_path=repo_root,
            operations=[flatten_op],
            dry_run=is_dry_run,
            force=is_force,
            auto_stash=auto_stash,
        )
        if is_dry_run:
            print_preview(engine.preview())
            print_info("Dry run — no changes made.")
        else:
            commit_count = get_commit_count(repo_root)
            if is_force or confirm_action(
                f"Flatten merges across {commit_count} commit(s)?"
            ):
                try:
                    engine.run()
                    print_success("History linearized!")
                except EngineError as exc:
                    print_error(str(exc))
                    raise typer.Exit(1) from exc
