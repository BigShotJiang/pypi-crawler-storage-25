"""git-surgeon rewrite-authors — add/configure author rewriting rules."""

from __future__ import annotations

from pathlib import Path
from typing import Annotated, Optional

import typer

from git_surgeon.core.config import Config
from git_surgeon.core.engine import Engine, EngineError
from git_surgeon.core.repo import RepoError, find_repo_root, get_commit_count
from git_surgeon.operations.author_rewrite import AuthorRewrite, AuthorRule
from git_surgeon.utils.display import (
    confirm_action,
    print_error,
    print_info,
    print_preview,
    print_success,
    print_warning,
)


def rewrite_authors_cmd(
    ctx: typer.Context,
    repo: Annotated[
        Optional[Path],
        typer.Option("--repo", "-r", help="Path to the target git repository."),
    ] = None,
    match_field: Annotated[
        str,
        typer.Option(
            "--match-field",
            "-m",
            help="Field to match: subject, author_name, author_email, message, all.",
        ),
    ] = "subject",
    match_pattern: Annotated[
        Optional[str],
        typer.Option("--match-pattern", "-p", help="Pattern to match commits against."),
    ] = None,
    new_name: Annotated[
        Optional[str],
        typer.Option("--name", help="New author/committer name."),
    ] = None,
    new_email: Annotated[
        Optional[str],
        typer.Option("--email", help="New author/committer email."),
    ] = None,
    is_default: Annotated[
        bool,
        typer.Option(
            "--default", help="Make this a catch-all rule for unmatched commits."
        ),
    ] = False,
    is_regex: Annotated[
        bool,
        typer.Option("--regex", help="Treat match-pattern as a regex."),
    ] = False,
    save: Annotated[
        bool,
        typer.Option("--save/--no-save", help="Save rule to config (default: save)."),
    ] = True,
    execute: Annotated[
        bool,
        typer.Option(
            "--execute", "-x", help="Execute immediately after adding the rule."
        ),
    ] = False,
    interactive: Annotated[
        bool,
        typer.Option(
            "--interactive", "-i", help="Interactive mode — prompts for inputs."
        ),
    ] = False,
    dry_run: Annotated[
        Optional[bool],
        typer.Option("--dry-run", "-n", help="Preview changes without executing."),
    ] = None,
    force: Annotated[
        Optional[bool],
        typer.Option("--force", "-f", help="Skip confirmation prompt."),
    ] = None,
    protect_others: Annotated[
        bool,
        typer.Option(
            "--protect-others",
            help="Only rewrite commits authored by you (git config user.email)."
            " All other authors are left untouched.",
        ),
    ] = False,
    preserve_attribution: Annotated[
        bool,
        typer.Option(
            "--preserve-attribution/--no-preserve-attribution",
            help="(default: on) Append Co-authored-by: trailer when an author identity"
            " changes, so original contribution is credited in the commit message.",
        ),
    ] = True,
    auto_stash: Annotated[
        bool,
        typer.Option(
            "--auto-stash",
            help="Stash uncommitted changes before rewriting and restore afterwards.",
        ),
    ] = False,
) -> None:
    """Add or execute author rewriting rules."""
    obj = ctx.obj or {}
    repo_path_opt = repo or obj.get("repo")
    is_dry_run = dry_run if dry_run is not None else obj.get("dry_run", False)
    is_force = force if force is not None else obj.get("force", False)

    try:
        repo_root = find_repo_root(repo_path_opt)
    except RepoError as exc:
        print_error(str(exc))
        raise typer.Exit(1) from exc

    if interactive:
        _interactive_rewrite_authors(
            repo_root,
            is_dry_run,
            is_force,
            save,
            protect_others=protect_others,
            preserve_attribution=preserve_attribution,
        )
        return

    # CLI mode — validate required args
    if not new_name or not new_email:
        print_error(
            "--name and --email are required. Use --interactive for guided setup."
        )
        raise typer.Exit(1)

    if not is_default and not match_pattern:
        print_error(
            "--match-pattern is required for non-default rules. Use --default for a catch-all."
        )
        raise typer.Exit(1)

    rule = AuthorRule(
        match_field=match_field,
        match_pattern=match_pattern or "",
        new_name=new_name,
        new_email=new_email,
        is_regex=is_regex,
        is_default=is_default,
    )

    # Load existing config and add rule
    config = Config.load(repo_root)
    existing = config.get_operations_by_type(AuthorRewrite)
    if existing:
        author_op = existing[0]
        assert isinstance(author_op, AuthorRewrite)
        author_op.add_rule(rule)
        author_op.preserve_attribution = preserve_attribution
    else:
        author_op = AuthorRewrite(
            rules=[rule], preserve_attribution=preserve_attribution
        )
        config.add_operation(author_op)

    if save:
        config.save(repo_root)
        print_success(f"Saved author rule to config.")

    if execute or is_dry_run:
        engine = Engine(
            repo_path=repo_root,
            operations=[author_op],
            dry_run=is_dry_run,
            force=is_force,
            protect_others=protect_others,
            auto_stash=auto_stash,
        )
        if is_dry_run:
            print_preview(engine.preview())
            print_info("Dry run — no changes made.")
        else:
            commit_count = get_commit_count(repo_root)
            if is_force or confirm_action(f"Rewrite {commit_count} commit(s)?"):
                try:
                    engine.run()
                    print_success("Authors rewritten successfully!")
                except EngineError as exc:
                    print_error(str(exc))
                    raise typer.Exit(1) from exc


def _interactive_rewrite_authors(
    repo_root: Path,
    dry_run: bool,
    force: bool,
    save: bool,
    protect_others: bool = False,
    preserve_attribution: bool = True,
) -> None:
    """Interactive mode for author rewriting."""
    from rich.prompt import Prompt, Confirm

    print_info("Interactive author rewrite setup")
    rules: list[AuthorRule] = []

    while True:
        is_default = Confirm.ask("Is this a default (catch-all) rule?", default=False)
        new_name = Prompt.ask("New author name")
        new_email = Prompt.ask("New author email")

        match_pattern = ""
        match_field = "subject"
        is_regex = False

        if not is_default:
            match_field = Prompt.ask(
                "Match field",
                choices=["subject", "author_name", "author_email", "message", "all"],
                default="subject",
            )
            match_pattern = Prompt.ask("Match pattern")
            is_regex = Confirm.ask("Is pattern a regex?", default=False)

        rules.append(
            AuthorRule(
                match_field=match_field,
                match_pattern=match_pattern,
                new_name=new_name,
                new_email=new_email,
                is_regex=is_regex,
                is_default=is_default,
            )
        )

        if not Confirm.ask("Add another rule?", default=False):
            break

    author_op = AuthorRewrite(rules=rules, preserve_attribution=preserve_attribution)
    errors = author_op.validate()
    if errors:
        for e in errors:
            print_error(e)
        raise typer.Exit(1)

    config = Config.load(repo_root)
    config.add_operation(author_op)

    if save:
        config.save(repo_root)
        print_success("Saved author rewrite config.")

    if dry_run:
        engine = Engine(
            repo_path=repo_root,
            operations=[author_op],
            dry_run=True,
            protect_others=protect_others,
        )
        print_preview(engine.preview())
