"""git-surgeon scrub — scrub messages and/or blob content."""

from __future__ import annotations

from pathlib import Path
from typing import Annotated, Optional

import typer

from git_surgeon.core.config import Config
from git_surgeon.core.engine import Engine, EngineError
from git_surgeon.core.repo import RepoError, find_repo_root, get_commit_count
from git_surgeon.operations.blob_scrub import BlobScrub
from git_surgeon.operations.message_scrub import MessageScrub
from git_surgeon.utils.display import (
    confirm_action,
    print_error,
    print_info,
    print_preview,
    print_success,
)


def scrub_cmd(
    ctx: typer.Context,
    repo: Annotated[
        Optional[Path],
        typer.Option("--repo", "-r", help="Path to the target git repository."),
    ] = None,
    find: Annotated[
        Optional[str],
        typer.Option("--find", help="Pattern to find."),
    ] = None,
    replace: Annotated[
        str,
        typer.Option("--replace", help="Replacement text."),
    ] = "***REMOVED***",
    messages: Annotated[
        bool,
        typer.Option("--messages", help="Scrub commit messages."),
    ] = False,
    blobs: Annotated[
        bool,
        typer.Option("--blobs", help="Scrub file contents (blobs)."),
    ] = False,
    is_regex: Annotated[
        bool,
        typer.Option("--regex", help="Treat find pattern as regex."),
    ] = False,
    save: Annotated[
        bool,
        typer.Option("--save/--no-save", help="Save to config."),
    ] = True,
    execute: Annotated[
        bool,
        typer.Option("--execute", "-x", help="Execute immediately."),
    ] = False,
    interactive: Annotated[
        bool,
        typer.Option("--interactive", "-i", help="Interactive mode."),
    ] = False,
    dry_run: Annotated[
        Optional[bool],
        typer.Option("--dry-run", "-n", help="Preview only."),
    ] = None,
    force: Annotated[
        Optional[bool],
        typer.Option("--force", "-f", help="Skip confirmation."),
    ] = None,
    auto_stash: Annotated[
        bool,
        typer.Option(
            "--auto-stash",
            help="Stash uncommitted changes before rewriting and restore afterwards.",
        ),
    ] = False,
) -> None:
    """Scrub sensitive data from commit messages and/or file contents."""
    obj = ctx.obj or {}
    repo_path_opt = repo or obj.get("repo")
    is_dry_run = dry_run if dry_run is not None else obj.get("dry_run", False)
    is_force = force if force is not None else obj.get("force", False)

    try:
        repo_root = find_repo_root(repo_path_opt)
    except RepoError as exc:
        print_error(str(exc))
        raise typer.Exit(1) from exc

    if interactive:
        _interactive_scrub(repo_root, is_dry_run, is_force, save)
        return

    if not find:
        print_error("--find is required. Use --interactive for guided setup.")
        raise typer.Exit(1)

    if not messages and not blobs:
        # Default to both
        messages = True
        blobs = True

    config = Config.load(repo_root)
    operations: list = []

    if messages:
        msg_scrub = MessageScrub()
        msg_scrub.add_replacement(find, replace, is_regex=is_regex)
        config.add_operation(msg_scrub)
        operations.append(msg_scrub)

    if blobs:
        blob_scrub = BlobScrub()
        blob_scrub.add_replacement(find, replace, is_regex=is_regex)
        config.add_operation(blob_scrub)
        operations.append(blob_scrub)

    if save:
        config.save(repo_root)
        print_success("Saved scrub config.")

    if execute or is_dry_run:
        engine = Engine(
            repo_path=repo_root,
            operations=operations,
            dry_run=is_dry_run,
            force=is_force,
            auto_stash=auto_stash,
        )
        if is_dry_run:
            print_preview(engine.preview())
            print_info("Dry run — no changes made.")
        else:
            commit_count = get_commit_count(repo_root)
            if is_force or confirm_action(f"Rewrite {commit_count} commit(s)?"):
                try:
                    engine.run()
                    print_success("Scrubbing complete!")
                except EngineError as exc:
                    print_error(str(exc))
                    raise typer.Exit(1) from exc


def _interactive_scrub(
    repo_root: Path,
    dry_run: bool,
    force: bool,
    save: bool,
) -> None:
    """Interactive scrub setup."""
    from rich.prompt import Prompt, Confirm

    print_info("Interactive scrub setup")
    operations: list = []

    while True:
        target = Prompt.ask(
            "What to scrub?",
            choices=["messages", "blobs", "both"],
            default="both",
        )
        find = Prompt.ask("Find pattern")
        replace = Prompt.ask("Replace with", default="***REMOVED***")
        is_regex = Confirm.ask("Is pattern a regex?", default=False)

        if target in ("messages", "both"):
            msg_scrub = MessageScrub()
            msg_scrub.add_replacement(find, replace, is_regex=is_regex)
            operations.append(msg_scrub)

        if target in ("blobs", "both"):
            blob_scrub = BlobScrub()
            blob_scrub.add_replacement(find, replace, is_regex=is_regex)
            operations.append(blob_scrub)

        if not Confirm.ask("Add another scrub rule?", default=False):
            break

    config = Config.load(repo_root)
    for op in operations:
        config.add_operation(op)

    if save:
        config.save(repo_root)
        print_success("Saved scrub config.")

    if dry_run:
        engine = Engine(repo_path=repo_root, operations=operations, dry_run=True)
        print_preview(engine.preview())
