"""git-surgeon filter — remove or keep commits matching criteria."""

from __future__ import annotations

from pathlib import Path
from typing import Annotated, Optional

import typer

from git_surgeon.core.config import Config
from git_surgeon.core.engine import Engine, EngineError
from git_surgeon.core.repo import RepoError, find_repo_root, get_commit_count
from git_surgeon.operations.commit_filter import CommitFilter, FilterRule
from git_surgeon.utils.display import (
    confirm_action,
    print_error,
    print_info,
    print_preview,
    print_success,
)


def filter_cmd(
    ctx: typer.Context,
    repo: Annotated[
        Optional[Path],
        typer.Option("--repo", "-r", help="Path to the target git repository."),
    ] = None,
    field: Annotated[
        str,
        typer.Option(
            "--field",
            help="Commit field to match: author_name, author_email, subject, message, date.",
        ),
    ] = "author_name",
    pattern: Annotated[
        Optional[str],
        typer.Option("--pattern", "-p", help="Pattern to match."),
    ] = None,
    action: Annotated[
        str,
        typer.Option("--action", "-a", help="Action: remove or keep."),
    ] = "remove",
    is_regex: Annotated[
        bool,
        typer.Option("--regex", help="Treat pattern as regex."),
    ] = False,
    save: Annotated[
        bool,
        typer.Option("--save/--no-save", help="Save to config."),
    ] = True,
    execute: Annotated[
        bool,
        typer.Option("--execute", "-x", help="Execute immediately."),
    ] = False,
    interactive: Annotated[
        bool,
        typer.Option("--interactive", "-i", help="Interactive mode."),
    ] = False,
    dry_run: Annotated[
        Optional[bool],
        typer.Option("--dry-run", "-n", help="Preview only."),
    ] = None,
    force: Annotated[
        Optional[bool],
        typer.Option("--force", "-f", help="Skip confirmation."),
    ] = None,
    auto_stash: Annotated[
        bool,
        typer.Option(
            "--auto-stash",
            help="Stash uncommitted changes before rewriting and restore afterwards.",
        ),
    ] = False,
) -> None:
    """Filter (remove/keep) commits matching criteria."""
    obj = ctx.obj or {}
    repo_path_opt = repo or obj.get("repo")
    is_dry_run = dry_run if dry_run is not None else obj.get("dry_run", False)
    is_force = force if force is not None else obj.get("force", False)

    try:
        repo_root = find_repo_root(repo_path_opt)
    except RepoError as exc:
        print_error(str(exc))
        raise typer.Exit(1) from exc

    if interactive:
        _interactive_filter(repo_root, is_dry_run, is_force, save)
        return

    if not pattern:
        print_error("--pattern is required. Use --interactive for guided setup.")
        raise typer.Exit(1)

    rule = FilterRule(field=field, pattern=pattern, action=action, is_regex=is_regex)
    filter_op = CommitFilter(rules=[rule])

    config = Config.load(repo_root)
    config.add_operation(filter_op)

    if save:
        config.save(repo_root)
        print_success("Saved filter config.")

    if execute or is_dry_run:
        engine = Engine(
            repo_path=repo_root,
            operations=[filter_op],
            dry_run=is_dry_run,
            force=is_force,
            auto_stash=auto_stash,
        )
        if is_dry_run:
            print_preview(engine.preview())
            print_info("Dry run — no changes made.")
        else:
            commit_count = get_commit_count(repo_root)
            if is_force or confirm_action(f"Filter {commit_count} commit(s)?"):
                try:
                    engine.run()
                    print_success("Commit filtering complete!")
                except EngineError as exc:
                    print_error(str(exc))
                    raise typer.Exit(1) from exc


def _interactive_filter(
    repo_root: Path,
    dry_run: bool,
    force: bool,
    save: bool,
) -> None:
    """Interactive filter setup."""
    from rich.prompt import Prompt, Confirm

    print_info("Interactive commit filter setup")
    rules: list[FilterRule] = []

    while True:
        field = Prompt.ask(
            "Match field",
            choices=["author_name", "author_email", "subject", "message", "date"],
            default="author_name",
        )
        pattern = Prompt.ask("Pattern to match")
        action = Prompt.ask("Action", choices=["remove", "keep"], default="remove")
        is_regex = Confirm.ask("Is pattern a regex?", default=False)

        rules.append(
            FilterRule(field=field, pattern=pattern, action=action, is_regex=is_regex)
        )

        if not Confirm.ask("Add another filter rule?", default=False):
            break

    filter_op = CommitFilter(rules=rules)

    config = Config.load(repo_root)
    config.add_operation(filter_op)

    if save:
        config.save(repo_root)
        print_success("Saved filter config.")

    if dry_run:
        engine = Engine(repo_path=repo_root, operations=[filter_op], dry_run=True)
        print_preview(engine.preview())
