"""git-surgeon preview — show what would happen without executing."""

from __future__ import annotations

from pathlib import Path
from typing import Annotated, Optional

import typer

from git_surgeon.core.config import Config
from git_surgeon.core.engine import Engine
from git_surgeon.core.repo import RepoError, find_repo_root
from git_surgeon.utils.display import (
    print_error,
    print_info,
    print_preview,
    print_validation_errors,
)


def preview_cmd(
    ctx: typer.Context,
    repo: Annotated[
        Optional[Path],
        typer.Option("--repo", "-r", help="Path to the target git repository."),
    ] = None,
) -> None:
    """Preview all configured operations without executing them."""
    obj = ctx.obj or {}
    repo_path = repo or obj.get("repo")

    try:
        repo_root = find_repo_root(repo_path)
    except RepoError as exc:
        print_error(str(exc))
        raise typer.Exit(1) from exc

    config = Config.load(repo_root)
    if not config.operations:
        print_error("No operations configured. Run 'git-surgeon init' to get started.")
        raise typer.Exit(1)

    engine = Engine.from_config(config, repo_root, dry_run=True)

    errors = engine.validate()
    if errors:
        print_validation_errors(errors)

    preview_data = engine.preview()
    print_preview(preview_data)
    print_info("This is a preview — no changes were made.")
