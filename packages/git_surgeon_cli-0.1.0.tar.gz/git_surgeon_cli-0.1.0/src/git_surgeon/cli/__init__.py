"""CLI interface for git-surgeon."""
