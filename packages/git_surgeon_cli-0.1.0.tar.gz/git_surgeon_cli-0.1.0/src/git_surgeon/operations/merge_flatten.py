"""Merge flattening — linearize history by dropping extra parents."""

from __future__ import annotations

from typing import Any

from git_surgeon.operations.base import Operation


class MergeFlatten(Operation):
    """Flatten merge commits by keeping only the first parent.

    This effectively linearizes the git history, converting merge commits
    into regular single-parent commits.
    """

    def __init__(self, enabled: bool = True) -> None:
        self.enabled = enabled

    @property
    def name(self) -> str:
        return "Merge Flatten"

    @property
    def priority(self) -> int:
        return 10  # Structural changes first

    def validate(self) -> list[str]:
        return []  # No validation needed — it's a boolean toggle

    def describe(self) -> str:
        if self.enabled:
            return "Merge Flatten: linearize history (keep first parent of merges)"
        return "Merge Flatten: disabled"

    def generate_callback_code(self) -> str | None:
        if not self.enabled:
            return None

        return (
            "# --- Merge Flatten ---\n"
            "if len(commit.parents) > 1:\n"
            "    commit.parents = [commit.parents[0]]"
        )

    def to_config(self) -> dict[str, Any]:
        return {
            "type": "merge_flatten",
            "enabled": self.enabled,
        }

    @classmethod
    def from_config(cls, data: dict[str, Any]) -> "MergeFlatten":
        return cls(enabled=data.get("enabled", True))
