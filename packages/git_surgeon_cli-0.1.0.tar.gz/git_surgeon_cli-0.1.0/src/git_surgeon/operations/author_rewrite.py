"""Author rewriting operation — reattribute commits based on matching rules."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from git_surgeon.operations.base import Operation


@dataclass
class AuthorRule:
    """A single rule for matching commits and assigning a new author.

    Attributes:
        match_field: Which commit field to match against.
            One of: "subject", "author_name", "author_email", "body", "message", "all".
        match_pattern: Text to match (exact substring match by default).
        new_name: New author/committer name to set.
        new_email: New author/committer email to set.
        is_regex: If True, treat match_pattern as a regex.
        is_default: If True, this rule matches all unmatched commits (catch-all).
    """

    match_field: str = "subject"
    match_pattern: str = ""
    new_name: str = ""
    new_email: str = ""
    is_regex: bool = False
    is_default: bool = False

    def to_dict(self) -> dict[str, Any]:
        d: dict[str, Any] = {
            "new_name": self.new_name,
            "new_email": self.new_email,
        }
        if self.is_default:
            d["is_default"] = True
        else:
            d["match_field"] = self.match_field
            d["match_pattern"] = self.match_pattern
            if self.is_regex:
                d["is_regex"] = True
        return d

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "AuthorRule":
        return cls(
            match_field=data.get("match_field", "subject"),
            match_pattern=data.get("match_pattern", ""),
            new_name=data["new_name"],
            new_email=data["new_email"],
            is_regex=data.get("is_regex", False),
            is_default=data.get("is_default", False),
        )


class AuthorRewrite(Operation):
    """Reattribute commits by matching against subject/author/etc."""

    def __init__(
        self,
        rules: list[AuthorRule] | None = None,
        preserve_attribution: bool = True,
        protect_others_email: str | None = None,
    ) -> None:
        self.rules: list[AuthorRule] = rules or []
        self.preserve_attribution = preserve_attribution
        # When set, only rewrites commits authored by this email; others are untouched.
        self.protect_others_email = protect_others_email

    @property
    def name(self) -> str:
        return "Author Rewrite"

    @property
    def priority(self) -> int:
        return 30

    def add_rule(self, rule: AuthorRule) -> None:
        self.rules.append(rule)

    def validate(self) -> list[str]:
        errors: list[str] = []
        if not self.rules:
            errors.append("AuthorRewrite: at least one rule is required.")
        defaults = [r for r in self.rules if r.is_default]
        if len(defaults) > 1:
            errors.append(
                "AuthorRewrite: at most one default (catch-all) rule allowed."
            )
        for i, rule in enumerate(self.rules):
            if not rule.new_name:
                errors.append(f"AuthorRewrite rule #{i + 1}: new_name is required.")
            if not rule.new_email:
                errors.append(f"AuthorRewrite rule #{i + 1}: new_email is required.")
            if not rule.is_default and not rule.match_pattern:
                errors.append(
                    f"AuthorRewrite rule #{i + 1}: match_pattern required for non-default rules."
                )
            if rule.match_field not in (
                "subject",
                "author_name",
                "author_email",
                "body",
                "message",
                "all",
            ):
                errors.append(
                    f"AuthorRewrite rule #{i + 1}: invalid match_field '{rule.match_field}'."
                )
        return errors

    def describe(self) -> str:
        lines = [f"Author Rewrite ({len(self.rules)} rule(s)):"]
        for rule in self.rules:
            if rule.is_default:
                lines.append(f"  [default] → {rule.new_name} <{rule.new_email}>")
            else:
                mode = "regex" if rule.is_regex else "exact"
                lines.append(
                    f"  {rule.match_field} {mode}({rule.match_pattern!r}) "
                    f"→ {rule.new_name} <{rule.new_email}>"
                )
        if self.preserve_attribution:
            lines.append(
                "  [attribution: Co-authored-by trailer added when identity changes]"
            )
        else:
            lines.append(
                "  [attribution: disabled — original authorship not preserved]"
            )
        if self.protect_others_email:
            lines.append(
                f"  [protect-others: only rewrites commits by <{self.protect_others_email}>]"
            )
        return "\n".join(lines)

    def generate_callback_code(self) -> str | None:
        if not self.rules:
            return None

        outer: list[str] = ["# --- Author Rewrite ---"]
        outer.append("_orig_author_name = commit.author_name")
        outer.append("_orig_author_email = commit.author_email")

        # Build inner rule logic (may be wrapped in a protect-others guard)
        inner: list[str] = []

        match_rules = [r for r in self.rules if not r.is_default]
        default_rules = [r for r in self.rules if r.is_default]

        subject_exact_rules: dict[str, list[AuthorRule]] = {}
        other_rules: list[AuthorRule] = []

        for rule in match_rules:
            if rule.match_field == "subject" and not rule.is_regex:
                key = f"{rule.new_name}|{rule.new_email}"
                subject_exact_rules.setdefault(key, []).append(rule)
            else:
                other_rules.append(rule)

        if subject_exact_rules:
            inner.append('_subject = commit.message.split(b"\\n")[0].strip()')
            inner.append("")

        inner.append("_author_matched = False")

        set_idx = 0
        for key, rules in subject_exact_rules.items():
            set_name = f"_author_set_{set_idx}"
            set_idx += 1
            sorted_patterns = sorted(r.match_pattern for r in rules)
            patterns_repr = ", ".join(f"b{p!r}" for p in sorted_patterns)
            inner.append(f"{set_name} = {{{patterns_repr}}}")
            r0 = rules[0]
            inner.append(f"if _subject in {set_name}:")
            inner.append(f"    commit.author_name = b{r0.new_name!r}")
            inner.append(f"    commit.author_email = b{r0.new_email!r}")
            inner.append(f"    commit.committer_name = b{r0.new_name!r}")
            inner.append(f"    commit.committer_email = b{r0.new_email!r}")
            inner.append("    _author_matched = True")

        if other_rules:
            inner.append("import re as _re")
        for rule in other_rules:
            field_expr = _field_expression(rule.match_field)
            if rule.is_regex:
                cond = f"_re.search(b{rule.match_pattern!r}, {field_expr})"
            else:
                cond = f"b{rule.match_pattern!r} in {field_expr}"
            inner.append(f"if not _author_matched and {cond}:")
            inner.append(f"    commit.author_name = b{rule.new_name!r}")
            inner.append(f"    commit.author_email = b{rule.new_email!r}")
            inner.append(f"    commit.committer_name = b{rule.new_name!r}")
            inner.append(f"    commit.committer_email = b{rule.new_email!r}")
            inner.append("    _author_matched = True")

        if default_rules:
            d = default_rules[0]
            inner.append("if not _author_matched:")
            inner.append(f"    commit.author_name = b{d.new_name!r}")
            inner.append(f"    commit.author_email = b{d.new_email!r}")
            inner.append(f"    commit.committer_name = b{d.new_name!r}")
            inner.append(f"    commit.committer_email = b{d.new_email!r}")

        # Optionally wrap all rules in a protect-others guard
        if self.protect_others_email:
            outer.append(f"if commit.author_email == b{self.protect_others_email!r}:")
            outer.extend(("    " + line) if line else "" for line in inner)
        else:
            outer.extend(inner)

        # Attribution preservation: add Co-authored-by when the identity actually changed
        if self.preserve_attribution:
            outer.append(
                "if _orig_author_name != commit.author_name "
                "or _orig_author_email != commit.author_email:"
            )
            outer.append(
                "    _coauthor_line = ("
                "b'Co-authored-by: ' + _orig_author_name"
                " + b' <' + _orig_author_email + b'>')"
            )
            outer.append("    if _coauthor_line not in commit.message:")
            outer.append(
                "        commit.message = ("
                "commit.message.rstrip(b'\\n') + b'\\n\\n'"
                " + _coauthor_line + b'\\n')"
            )

        return "\n".join(outer)

    def to_config(self) -> dict[str, Any]:
        d: dict[str, Any] = {
            "type": "author_rewrite",
            "rules": [r.to_dict() for r in self.rules],
        }
        if not self.preserve_attribution:
            d["preserve_attribution"] = False
        return d

    @classmethod
    def from_config(cls, data: dict[str, Any]) -> "AuthorRewrite":
        rules = [AuthorRule.from_dict(r) for r in data.get("rules", [])]
        return cls(
            rules=rules,
            preserve_attribution=data.get("preserve_attribution", True),
        )


def _field_expression(match_field: str) -> str:
    """Return the Python expression to access a commit field in callback context."""
    mapping = {
        "subject": 'commit.message.split(b"\\n")[0].strip()',
        "author_name": "commit.author_name",
        "author_email": "commit.author_email",
        "body": 'b"\\n".join(commit.message.split(b"\\n")[1:])',
        "message": "commit.message",
        "all": 'commit.message + b" " + commit.author_name + b" " + commit.author_email',
    }
    return mapping.get(match_field, "commit.message")
