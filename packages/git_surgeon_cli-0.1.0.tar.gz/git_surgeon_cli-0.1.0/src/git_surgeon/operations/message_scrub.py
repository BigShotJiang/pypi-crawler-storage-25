"""Commit message scrubbing — find-and-replace text in commit messages."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from git_surgeon.operations.base import Operation


@dataclass
class MessageReplacement:
    """A single find→replace rule for commit messages.

    Attributes:
        find: The pattern to search for.
        replace: The replacement string.
        is_regex: If True, treat *find* as a regex pattern.
    """

    find: str
    replace: str
    is_regex: bool = False

    def to_dict(self) -> dict[str, Any]:
        d: dict[str, Any] = {"find": self.find, "replace": self.replace}
        if self.is_regex:
            d["is_regex"] = True
        return d

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "MessageReplacement":
        return cls(
            find=data["find"],
            replace=data["replace"],
            is_regex=data.get("is_regex", False),
        )


class MessageScrub(Operation):
    """Replace patterns in commit messages."""

    def __init__(self, replacements: list[MessageReplacement] | None = None) -> None:
        self.replacements: list[MessageReplacement] = replacements or []

    @property
    def name(self) -> str:
        return "Message Scrub"

    @property
    def priority(self) -> int:
        return 20  # Runs before author matching so subjects are already cleaned

    def add_replacement(
        self, find: str, replace: str, *, is_regex: bool = False
    ) -> None:
        self.replacements.append(
            MessageReplacement(find=find, replace=replace, is_regex=is_regex)
        )

    def validate(self) -> list[str]:
        errors: list[str] = []
        if not self.replacements:
            errors.append("MessageScrub: at least one replacement rule is required.")
        for i, r in enumerate(self.replacements):
            if not r.find:
                errors.append(
                    f"MessageScrub rule #{i + 1}: 'find' pattern cannot be empty."
                )
        return errors

    def describe(self) -> str:
        lines = [f"Message Scrub ({len(self.replacements)} rule(s)):"]
        for r in self.replacements:
            mode = "regex" if r.is_regex else "literal"
            display_replace = r.replace if r.replace else "(empty)"
            lines.append(f"  [{mode}] {r.find!r} → {display_replace!r}")
        return "\n".join(lines)

    def generate_callback_code(self) -> str | None:
        if not self.replacements:
            return None

        lines: list[str] = ["# --- Message Scrub ---", "msg = commit.message"]

        uses_regex = any(r.is_regex for r in self.replacements)
        if uses_regex:
            lines.insert(1, "import re as _re")

        for r in self.replacements:
            if r.is_regex:
                lines.append(f"msg = _re.sub(b{r.find!r}, b{r.replace!r}, msg)")
            else:
                lines.append(f"msg = msg.replace(b{r.find!r}, b{r.replace!r})")

        lines.append("commit.message = msg")
        return "\n".join(lines)

    def generate_replace_text_entries(self) -> list[str]:
        # Message scrub works via callback, not --replace-text
        return []

    def to_config(self) -> dict[str, Any]:
        return {
            "type": "message_scrub",
            "replacements": [r.to_dict() for r in self.replacements],
        }

    @classmethod
    def from_config(cls, data: dict[str, Any]) -> "MessageScrub":
        replacements = [
            MessageReplacement.from_dict(r) for r in data.get("replacements", [])
        ]
        return cls(replacements=replacements)
