"""Commit filtering — remove or keep commits matching criteria."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from git_surgeon.operations.base import Operation


@dataclass
class FilterRule:
    """A single rule for filtering commits.

    Attributes:
        field: The commit field to match on.
            One of: "author_name", "author_email", "subject", "message", "date".
        pattern: The text or regex pattern to match.
        action: What to do with matching commits: "remove" or "keep".
        is_regex: If True, treat pattern as a regex.
    """

    field: str
    pattern: str
    action: str = "remove"  # "remove" or "keep"
    is_regex: bool = False

    def to_dict(self) -> dict[str, Any]:
        d: dict[str, Any] = {
            "field": self.field,
            "pattern": self.pattern,
            "action": self.action,
        }
        if self.is_regex:
            d["is_regex"] = True
        return d

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "FilterRule":
        return cls(
            field=data["field"],
            pattern=data["pattern"],
            action=data.get("action", "remove"),
            is_regex=data.get("is_regex", False),
        )


class CommitFilter(Operation):
    """Filter (remove/keep) commits matching criteria.

    Uses git-filter-repo's commit callback to skip commits by reassigning
    their parents, effectively removing them from history.
    """

    def __init__(self, rules: list[FilterRule] | None = None) -> None:
        self.rules: list[FilterRule] = rules or []

    @property
    def name(self) -> str:
        return "Commit Filter"

    @property
    def priority(self) -> int:
        return 40  # After rewrites, before blob scrub

    def add_rule(self, rule: FilterRule) -> None:
        self.rules.append(rule)

    def validate(self) -> list[str]:
        errors: list[str] = []
        if not self.rules:
            errors.append("CommitFilter: at least one filter rule is required.")
        for i, rule in enumerate(self.rules):
            if not rule.pattern:
                errors.append(f"CommitFilter rule #{i + 1}: 'pattern' cannot be empty.")
            if rule.action not in ("remove", "keep"):
                errors.append(
                    f"CommitFilter rule #{i + 1}: action must be 'remove' or 'keep', "
                    f"got '{rule.action}'."
                )
            if rule.field not in (
                "author_name",
                "author_email",
                "subject",
                "message",
                "date",
            ):
                errors.append(
                    f"CommitFilter rule #{i + 1}: invalid field '{rule.field}'."
                )
        return errors

    def describe(self) -> str:
        lines = [f"Commit Filter ({len(self.rules)} rule(s)):"]
        for rule in self.rules:
            mode = "regex" if rule.is_regex else "exact"
            lines.append(f"  [{rule.action}] {rule.field} {mode}({rule.pattern!r})")
        return "\n".join(lines)

    def generate_callback_code(self) -> str | None:
        if not self.rules:
            return None

        lines: list[str] = ["# --- Commit Filter ---"]

        uses_regex = any(r.is_regex for r in self.rules)
        if uses_regex:
            lines.append("import re as _re")

        for rule in self.rules:
            field_expr = _filter_field_expression(rule.field)
            if rule.is_regex:
                cond = f"_re.search(b{rule.pattern!r}, {field_expr})"
            else:
                cond = f"b{rule.pattern!r} in {field_expr}"

            if rule.action == "remove":
                # Skip the commit by splicing it out of the parent chain
                lines.append(f"if {cond}:")
                lines.append("    commit.skip()")
            else:
                # "keep" — skip everything that does NOT match
                lines.append(f"if not ({cond}):")
                lines.append("    commit.skip()")

        return "\n".join(lines)

    def to_config(self) -> dict[str, Any]:
        return {
            "type": "commit_filter",
            "rules": [r.to_dict() for r in self.rules],
        }

    @classmethod
    def from_config(cls, data: dict[str, Any]) -> "CommitFilter":
        rules = [FilterRule.from_dict(r) for r in data.get("rules", [])]
        return cls(rules=rules)


def _filter_field_expression(field: str) -> str:
    """Return the Python expression to access a commit field in callback context."""
    mapping = {
        "subject": 'commit.message.split(b"\\n")[0].strip()',
        "author_name": "commit.author_name",
        "author_email": "commit.author_email",
        "message": "commit.message",
        "date": "commit.author_date",
    }
    return mapping.get(field, "commit.message")
