"""Pluggable operations for git history rewriting."""

from git_surgeon.operations.base import Operation
from git_surgeon.operations.author_rewrite import AuthorRewrite
from git_surgeon.operations.message_scrub import MessageScrub
from git_surgeon.operations.blob_scrub import BlobScrub
from git_surgeon.operations.merge_flatten import MergeFlatten
from git_surgeon.operations.commit_filter import CommitFilter

__all__ = [
    "Operation",
    "AuthorRewrite",
    "MessageScrub",
    "BlobScrub",
    "MergeFlatten",
    "CommitFilter",
]
