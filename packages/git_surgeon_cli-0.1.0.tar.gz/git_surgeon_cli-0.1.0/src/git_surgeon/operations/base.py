"""Abstract base class for all git-surgeon operations."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any


class Operation(ABC):
    """Base class for a composable git history rewriting operation.

    Each operation can contribute:
    - Python callback code executed per-commit by git-filter-repo (--commit-callback)
    - Text replacement entries for blob content scrubbing (--replace-text)

    Operations are composable: the Engine collects all operations, merges their
    callback snippets, and invokes git-filter-repo in a single pass.
    """

    @property
    @abstractmethod
    def name(self) -> str:
        """Human-readable operation name."""

    @abstractmethod
    def validate(self) -> list[str]:
        """Return a list of validation error messages (empty if valid)."""

    @abstractmethod
    def describe(self) -> str:
        """Return a human-readable summary for dry-run / preview output."""

    @abstractmethod
    def generate_callback_code(self) -> str | None:
        """Return Python code for git-filter-repo's --commit-callback.

        The code runs inside git-filter-repo's callback context where a
        ``commit`` object is available with attributes like:
        - commit.message (bytes)
        - commit.author_name (bytes)
        - commit.author_email (bytes)
        - commit.committer_name (bytes)
        - commit.committer_email (bytes)
        - commit.parents (list)

        Return None if this operation doesn't need commit callback code
        (e.g. blob-only scrubbing via --replace-text).
        """

    def generate_replace_text_entries(self) -> list[str]:
        """Return git-filter-repo --replace-text pattern lines.

        Each line uses the format: ``literal_or_regex==>replacement``
        Default: no entries.
        """
        return []

    @abstractmethod
    def to_config(self) -> dict[str, Any]:
        """Serialize this operation to a dict suitable for TOML config."""

    @classmethod
    @abstractmethod
    def from_config(cls, data: dict[str, Any]) -> "Operation":
        """Deserialize an operation from a TOML config dict."""

    @property
    def priority(self) -> int:
        """Execution priority (lower = runs first in the callback).

        Default ordering:
          10 - MergeFlatten  (structural changes first)
          20 - MessageScrub  (clean messages before matching)
          30 - AuthorRewrite (match on cleaned messages)
          40 - CommitFilter  (filter after all transformations)
          50 - BlobScrub     (handled separately via --replace-text)
        """
        return 50
