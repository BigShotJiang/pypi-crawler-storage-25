"""Blob content scrubbing — replace sensitive patterns in file contents."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from git_surgeon.operations.base import Operation


@dataclass
class BlobReplacement:
    """A single find→replace rule for blob (file) content.

    Uses git-filter-repo's ``--replace-text`` mechanism.

    Attributes:
        find: The pattern to search for in file contents.
        replace: The replacement text.
        is_regex: If True, prefix the line with ``regex:`` for git-filter-repo.
    """

    find: str
    replace: str = "***REMOVED***"
    is_regex: bool = False

    def to_dict(self) -> dict[str, Any]:
        d: dict[str, Any] = {"find": self.find, "replace": self.replace}
        if self.is_regex:
            d["is_regex"] = True
        return d

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "BlobReplacement":
        return cls(
            find=data["find"],
            replace=data.get("replace", "***REMOVED***"),
            is_regex=data.get("is_regex", False),
        )


class BlobScrub(Operation):
    """Replace sensitive patterns in blob (file) contents across history."""

    def __init__(self, replacements: list[BlobReplacement] | None = None) -> None:
        self.replacements: list[BlobReplacement] = replacements or []

    @property
    def name(self) -> str:
        return "Blob Scrub"

    @property
    def priority(self) -> int:
        return 50  # Handled via --replace-text, not callback ordering

    def add_replacement(
        self,
        find: str,
        replace: str = "***REMOVED***",
        *,
        is_regex: bool = False,
    ) -> None:
        self.replacements.append(
            BlobReplacement(find=find, replace=replace, is_regex=is_regex)
        )

    def validate(self) -> list[str]:
        errors: list[str] = []
        if not self.replacements:
            errors.append("BlobScrub: at least one replacement rule is required.")
        for i, r in enumerate(self.replacements):
            if not r.find:
                errors.append(
                    f"BlobScrub rule #{i + 1}: 'find' pattern cannot be empty."
                )
        return errors

    def describe(self) -> str:
        lines = [f"Blob Scrub ({len(self.replacements)} rule(s)):"]
        for r in self.replacements:
            mode = "regex" if r.is_regex else "literal"
            lines.append(f"  [{mode}] {r.find!r} → {r.replace!r}")
        return "\n".join(lines)

    def generate_callback_code(self) -> str | None:
        # Blob scrubbing is done via --replace-text, not commit callback
        return None

    def generate_replace_text_entries(self) -> list[str]:
        """Generate git-filter-repo --replace-text format lines.

        Format:
          literal_text==>replacement
          regex:pattern==>replacement
        """
        entries: list[str] = []
        for r in self.replacements:
            prefix = "regex:" if r.is_regex else ""
            entries.append(f"{prefix}{r.find}==>{r.replace}")
        return entries

    def to_config(self) -> dict[str, Any]:
        return {
            "type": "blob_scrub",
            "replacements": [r.to_dict() for r in self.replacements],
        }

    @classmethod
    def from_config(cls, data: dict[str, Any]) -> "BlobScrub":
        replacements = [
            BlobReplacement.from_dict(r) for r in data.get("replacements", [])
        ]
        return cls(replacements=replacements)
