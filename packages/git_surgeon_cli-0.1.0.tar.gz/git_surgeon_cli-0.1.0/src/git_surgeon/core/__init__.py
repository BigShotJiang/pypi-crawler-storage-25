"""Core engine, config, and safety modules."""
