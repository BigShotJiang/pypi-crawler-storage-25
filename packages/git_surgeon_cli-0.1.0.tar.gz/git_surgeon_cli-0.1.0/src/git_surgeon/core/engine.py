"""Engine — orchestrates operations and invokes git-filter-repo."""

from __future__ import annotations

import subprocess
import sys
import tempfile
from pathlib import Path

from git_surgeon.core.callback_builder import CallbackBuilder
from git_surgeon.core.config import CALLBACK_DEBUG_NAME, CONFIG_DIR_NAME, Config
from git_surgeon.core.repo import get_commit_count, validate_repo
from git_surgeon.core.safety import (
    StashError,
    create_backup,
    pop_stash,
    stash_changes,
)
from git_surgeon.operations.base import Operation


class EngineError(Exception):
    """Raised when the rewrite engine encounters an error."""


class Engine:
    """Orchestrates git history rewriting from a set of operations.

    The engine:
    1. Validates all operations
    2. Composes callback code via CallbackBuilder
    3. Collects --replace-text entries
    4. Optionally creates a backup bundle
    5. Invokes git-filter-repo in a single pass
    """

    def __init__(
        self,
        repo_path: Path,
        operations: list[Operation] | None = None,
        dry_run: bool = False,
        force: bool = False,
        skip_backup: bool = False,
        protect_others: bool = False,
        auto_stash: bool = False,
    ) -> None:
        self.repo_path = repo_path
        self.operations: list[Operation] = operations or []
        self.dry_run = dry_run
        self.force = force
        self.skip_backup = skip_backup
        self.protect_others = protect_others
        self.auto_stash = auto_stash

    @classmethod
    def from_config(
        cls,
        config: Config,
        repo_path: Path,
        *,
        dry_run: bool = False,
        force: bool = False,
        skip_backup: bool = False,
        protect_others: bool = False,
        auto_stash: bool = False,
    ) -> "Engine":
        """Create an Engine from a loaded Config."""
        return cls(
            repo_path=repo_path,
            operations=config.operations,
            dry_run=dry_run,
            force=force,
            skip_backup=skip_backup,
            protect_others=protect_others,
            auto_stash=auto_stash,
        )

    def add_operation(self, operation: Operation) -> None:
        self.operations.append(operation)

    def validate(self) -> dict[str, list[str]]:
        """Validate all operations. Returns {name: [errors]}."""
        all_errors: dict[str, list[str]] = {}
        for op in self.operations:
            errors = op.validate()
            if errors:
                all_errors[op.name] = errors
        return all_errors

    def preview(self) -> dict:
        """Generate a preview of what would happen without executing.

        Returns a dict with:
        - "commit_count": number of commits in the repo
        - "operations": list of operation descriptions
        - "callback": the composed callback code (or "(none)")
        - "replace_text": list of replace-text entries
        - "warnings": repo validation warnings
        - "author_impact": affected-author rows (when AuthorRewrite is configured)
        - "self_email": current git user email (for report highlighting)
        - "has_non_analyzable_author_rules": True when subject/message rules can't be
          statically analysed to determine which other authors they'll affect
        """
        builder = CallbackBuilder(self.operations)
        impact, self_email, has_non_analyzable = self._get_author_impact()

        return {
            "commit_count": get_commit_count(self.repo_path),
            "operations": [op.describe() for op in self.operations],
            "callback": builder.build() or "(none — no callback operations)",
            "replace_text": builder.build_replace_text(),
            "warnings": validate_repo(self.repo_path),
            "author_impact": impact,
            "self_email": self_email,
            "has_non_analyzable_author_rules": has_non_analyzable,
        }

    def _get_author_impact(self) -> tuple[list[dict], str, bool]:
        """Statically analyse which repo authors are affected by AuthorRewrite operations.

        Returns (impact_list, self_email, has_non_analyzable_rules).

        impact_list entries:
            original_name, original_email, new_name, new_email,
            commit_count, is_self, will_change

        has_non_analyzable_rules is True when any rule uses subject/message matching
        (those can't be pre-determined without a full commit scan).
        """
        import re as _re

        from git_surgeon.core.repo import get_authors, get_self_identity
        from git_surgeon.operations.author_rewrite import AuthorRewrite as _AR

        author_rewrites: list[_AR] = [
            op for op in self.operations if isinstance(op, _AR)
        ]
        if not author_rewrites:
            return [], "", False

        repo_authors = get_authors(self.repo_path)
        _, self_email = get_self_identity(self.repo_path)

        has_non_analyzable = any(
            rule.match_field not in ("author_email", "author_name")
            for ar in author_rewrites
            for rule in ar.rules
            if not rule.is_default
        )

        impact: list[dict] = []
        for author in repo_authors:
            email: str = author["email"]
            name: str = author["name"]
            commit_count: int = author["commit_count"]
            is_self = bool(self_email and email.lower() == self_email.lower())

            matched_new_name: str | None = None
            matched_new_email: str | None = None

            for ar in author_rewrites:
                match_rules = [r for r in ar.rules if not r.is_default]
                default_rule = next((r for r in ar.rules if r.is_default), None)

                for rule in match_rules:
                    if rule.match_field == "author_email":
                        target = email
                    elif rule.match_field == "author_name":
                        target = name
                    else:
                        continue  # non-analyzable field; skip static check

                    hit = (
                        bool(_re.search(rule.match_pattern, target))
                        if rule.is_regex
                        else (rule.match_pattern in target)
                    )
                    if hit:
                        matched_new_name = rule.new_name
                        matched_new_email = rule.new_email
                        break

                if matched_new_name is None and default_rule:
                    matched_new_name = default_rule.new_name
                    matched_new_email = default_rule.new_email

                if matched_new_name:
                    break

            if matched_new_name is not None:
                will_change = matched_new_name != name or matched_new_email != email
                impact.append(
                    {
                        "original_name": name,
                        "original_email": email,
                        "new_name": matched_new_name,
                        "new_email": matched_new_email,
                        "commit_count": commit_count,
                        "is_self": is_self,
                        "will_change": will_change,
                    }
                )

        return impact, self_email, has_non_analyzable

    def run(self) -> None:
        """Execute the rewrite.

        Raises EngineError on failure.
        """
        if not self.operations:
            raise EngineError("No operations configured. Nothing to do.")

        # Validate
        errors = self.validate()
        if errors:
            msg_parts = ["Validation failed:"]
            for name, errs in errors.items():
                for e in errs:
                    msg_parts.append(f"  [{name}] {e}")
            raise EngineError("\n".join(msg_parts))

        # Author-rewrite safeguards: protect-others guard + per-author confirmation
        from git_surgeon.core.repo import get_self_identity
        from git_surgeon.operations.author_rewrite import AuthorRewrite as _AR

        _author_ops: list[_AR] = [op for op in self.operations if isinstance(op, _AR)]

        if _author_ops and not self.dry_run:
            _, _self_email = get_self_identity(self.repo_path)

            # Apply protect-others guard to callback generation
            if self.protect_others and _self_email:
                for _ar in _author_ops:
                    _ar.protect_others_email = _self_email

            # Per-author confirmation for non-self authors (skipped with --force)
            if not self.force:
                _impact, _, _has_non_analyzable = self._get_author_impact()
                _other_changed = [
                    a for a in _impact if not a["is_self"] and a["will_change"]
                ]

                if _other_changed or _has_non_analyzable:
                    from git_surgeon.utils.display import (
                        confirm_action,
                        print_author_impact_report,
                    )

                    print_author_impact_report(
                        _impact, _self_email, _has_non_analyzable
                    )

                    for _a in _other_changed:
                        _ok = confirm_action(
                            f"Rewrite {_a['commit_count']} commit(s) from "
                            f"'{_a['original_name']} <{_a['original_email']}>'"
                            f" \u2192 '{_a['new_name']} <{_a['new_email']}>'?",
                            default=False,
                        )
                        if not _ok:
                            raise EngineError(
                                f"Cancelled: rewrite of '{_a['original_name']}'"
                                f" <{_a['original_email']}> was declined.\n"
                                "Adjust your rules, or use --protect-others to skip"
                                " all commits that aren't yours."
                            )

                    if _has_non_analyzable and not _other_changed:
                        _ok = confirm_action(
                            "Some rules match on commit messages/subjects — other"
                            " authors' commits may be affected. Proceed?",
                            default=False,
                        )
                        if not _ok:
                            raise EngineError(
                                "Rewrite cancelled. Use author_email/author_name"
                                " match fields for precise, auditable attribution."
                            )

        # Build callback & replace-text
        builder = CallbackBuilder(self.operations)
        callback = builder.build()
        replace_entries = builder.build_replace_text()

        # Save debug callback
        config_dir = self.repo_path / CONFIG_DIR_NAME
        config_dir.mkdir(parents=True, exist_ok=True)
        debug_file = config_dir / CALLBACK_DEBUG_NAME
        if callback:
            debug_file.write_text(callback, encoding="utf-8")

        if self.dry_run:
            return  # Preview only — do not modify the repo

        # Auto-stash uncommitted changes so git-filter-repo starts from a clean worktree
        _stashed = False
        if self.auto_stash:
            try:
                _stashed = stash_changes(self.repo_path)
            except StashError as exc:
                raise EngineError(f"Auto-stash failed: {exc}") from exc

        # Create backup unless skipped
        if not self.skip_backup:
            create_backup(self.repo_path)

        # Build git-filter-repo command
        cmd: list[str] = [
            sys.executable,
            "-m",
            "git_filter_repo",
            "--force",
        ]

        if callback:
            cmd.extend(["--commit-callback", callback])

        # Write replace-text to a temp file if needed
        replace_text_file = None
        if replace_entries:
            replace_text_file = tempfile.NamedTemporaryFile(
                mode="w",
                suffix=".txt",
                prefix="git-surgeon-replace-",
                delete=False,
                encoding="utf-8",
            )
            replace_text_file.write("\n".join(replace_entries) + "\n")
            replace_text_file.close()
            cmd.extend(["--replace-text", replace_text_file.name])

        # Execute
        try:
            result = subprocess.run(
                cmd,
                cwd=str(self.repo_path),
                capture_output=True,
                text=True,
            )
            if result.returncode != 0:
                raise EngineError(
                    f"git-filter-repo exited with code {result.returncode}.\n"
                    f"stderr: {result.stderr}\n"
                    f"stdout: {result.stdout}"
                )
        except FileNotFoundError as exc:
            raise EngineError(
                "git-filter-repo not found. Install it with: pip install git-filter-repo"
            ) from exc
        finally:
            # Clean up temp file
            if replace_text_file:
                Path(replace_text_file.name).unlink(missing_ok=True)

        # Pop the auto-stash now that the rewrite succeeded.
        # If this is reached, the rewrite did not raise; the stash is safe to restore.
        if _stashed:
            try:
                pop_stash(self.repo_path)
            except StashError as exc:
                raise EngineError(str(exc)) from exc
