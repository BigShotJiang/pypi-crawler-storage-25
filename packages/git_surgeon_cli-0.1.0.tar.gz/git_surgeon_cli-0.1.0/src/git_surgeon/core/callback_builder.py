"""Composes multiple operations' callback snippets into a single callback."""

from __future__ import annotations

from git_surgeon.operations.base import Operation


class CallbackBuilder:
    """Combine callback code from multiple operations into one coherent script.

    git-filter-repo executes the ``--commit-callback`` string once per commit
    with a ``commit`` object in scope. This builder merges all operations'
    callback snippets in priority order into a single cohesive script.
    """

    def __init__(self, operations: list[Operation]) -> None:
        self.operations = sorted(operations, key=lambda op: op.priority)

    def build(self) -> str | None:
        """Return the merged callback string, or None if no operations need callbacks."""
        snippets: list[str] = []

        for op in self.operations:
            code = op.generate_callback_code()
            if code:
                snippets.append(code)

        if not snippets:
            return None

        return "\n\n".join(snippets) + "\n"

    def build_replace_text(self) -> list[str]:
        """Collect all --replace-text entries from all operations."""
        entries: list[str] = []
        for op in self.operations:
            entries.extend(op.generate_replace_text_entries())
        return entries
