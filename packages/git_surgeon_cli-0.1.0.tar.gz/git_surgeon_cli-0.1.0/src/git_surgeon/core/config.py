"""Configuration management — load/save operations to .git-surgeon/config.toml."""

from __future__ import annotations

from pathlib import Path
from typing import Any

import tomli_w
import tomllib

from git_surgeon.operations.author_rewrite import AuthorRewrite
from git_surgeon.operations.base import Operation
from git_surgeon.operations.blob_scrub import BlobScrub
from git_surgeon.operations.commit_filter import CommitFilter
from git_surgeon.operations.merge_flatten import MergeFlatten
from git_surgeon.operations.message_scrub import MessageScrub

# Registry mapping type strings to operation classes
_OPERATION_REGISTRY: dict[str, type[Operation]] = {
    "author_rewrite": AuthorRewrite,
    "message_scrub": MessageScrub,
    "blob_scrub": BlobScrub,
    "merge_flatten": MergeFlatten,
    "commit_filter": CommitFilter,
}

CONFIG_DIR_NAME = ".git-surgeon"
CONFIG_FILE_NAME = "config.toml"
CALLBACK_DEBUG_NAME = "last-callback.py"
BACKUP_BUNDLE_NAME = "backup.bundle"
PRE_REWRITE_HEAD_NAME = "pre-rewrite-head"


class Config:
    """Manages git-surgeon configuration stored in .git-surgeon/config.toml."""

    def __init__(
        self,
        operations: list[Operation] | None = None,
        general: dict[str, Any] | None = None,
    ) -> None:
        self.operations: list[Operation] = operations or []
        self.general: dict[str, Any] = general or {}

    @classmethod
    def config_dir(cls, repo_path: Path) -> Path:
        """Return the .git-surgeon/ directory for a given repo."""
        return repo_path / CONFIG_DIR_NAME

    @classmethod
    def config_file(cls, repo_path: Path) -> Path:
        """Return the config.toml path for a given repo."""
        return cls.config_dir(repo_path) / CONFIG_FILE_NAME

    @classmethod
    def load(cls, repo_path: Path) -> "Config":
        """Load configuration from .git-surgeon/config.toml."""
        config_file = cls.config_file(repo_path)
        if not config_file.exists():
            return cls()

        with open(config_file, "rb") as f:
            data = tomllib.load(f)

        general = data.get("general", {})
        operations: list[Operation] = []

        for op_data in data.get("operations", []):
            op_type = op_data.get("type")
            op_class = _OPERATION_REGISTRY.get(op_type)  # type: ignore[arg-type]
            if op_class:
                operations.append(op_class.from_config(op_data))

        return cls(operations=operations, general=general)

    def save(self, repo_path: Path) -> Path:
        """Save configuration to .git-surgeon/config.toml.

        Creates the .git-surgeon/ directory if it doesn't exist.
        Returns the path to the written config file.
        """
        config_dir = self.config_dir(repo_path)
        config_dir.mkdir(parents=True, exist_ok=True)

        config_file = config_dir / CONFIG_FILE_NAME
        data: dict[str, Any] = {}

        if self.general:
            data["general"] = self.general

        data["operations"] = [op.to_config() for op in self.operations]

        with open(config_file, "wb") as f:
            tomli_w.dump(data, f)

        return config_file

    def add_operation(self, operation: Operation) -> None:
        """Add an operation to the configuration."""
        self.operations.append(operation)

    def get_operations_by_type(self, op_type: type[Operation]) -> list[Operation]:
        """Return all operations of a given type."""
        return [op for op in self.operations if isinstance(op, op_type)]

    def validate_all(self) -> dict[str, list[str]]:
        """Validate all operations. Returns {operation_name: [errors]}."""
        results: dict[str, list[str]] = {}
        for op in self.operations:
            errors = op.validate()
            if errors:
                results[op.name] = errors
        return results

    @staticmethod
    def generate_template() -> str:
        """Generate a commented template config.toml for new users."""
        return """
# git-surgeon configuration
# This file is auto-generated. Edit to customize operations.
# It is stored in .git-surgeon/ which is gitignored.

[general]
# target_repo = "."  # Optional: path to target repo (default: current directory)

# --- Operations ---
# Each [[operations]] block defines one rewriting operation.
# Available types: author_rewrite, message_scrub, blob_scrub, merge_flatten, commit_filter

# Example: Flatten merge commits
# [[operations]]
# type = "merge_flatten"
# enabled = true

# Example: Scrub commit messages
# [[operations]]
# type = "message_scrub"
# [[operations.replacements]]
# find = "old-org-name"
# replace = "new-org-name"

# Example: Rewrite authors
# [[operations]]
# type = "author_rewrite"
# [[operations.rules]]
# match_field = "subject"
# match_pattern = "feat: some feature"
# new_name = "Jane Doe"
# new_email = "jane@example.com"
# [[operations.rules]]
# is_default = true
# new_name = "John Doe"
# new_email = "john@example.com"

# Example: Scrub sensitive data from files
# [[operations]]
# type = "blob_scrub"
# [[operations.replacements]]
# find = "secret-api-key"
# replace = "***REMOVED***"

# Example: Filter commits
# [[operations]]
# type = "commit_filter"
# [[operations.rules]]
# field = "author_name"
# pattern = "dependabot"
# action = "remove"
"""
