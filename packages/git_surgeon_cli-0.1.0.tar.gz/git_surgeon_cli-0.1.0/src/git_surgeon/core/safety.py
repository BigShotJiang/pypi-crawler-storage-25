"""Safety module — backup, confirmation, and undo via git bundles."""

from __future__ import annotations

import subprocess
from pathlib import Path

from git_surgeon.core.config import (
    BACKUP_BUNDLE_NAME,
    CONFIG_DIR_NAME,
    PRE_REWRITE_HEAD_NAME,
)
from git_surgeon.core.repo import get_current_head


class BackupError(Exception):
    """Raised when backup or restore operations fail."""


def create_backup(repo_path: Path) -> Path:
    """Create a lightweight git bundle backup before rewriting.

    Stores the bundle in .git-surgeon/backup.bundle and records the
    current HEAD SHA in .git-surgeon/pre-rewrite-head.

    Returns the path to the bundle file.
    """
    config_dir = repo_path / CONFIG_DIR_NAME
    config_dir.mkdir(parents=True, exist_ok=True)

    bundle_path = config_dir / BACKUP_BUNDLE_NAME
    head_path = config_dir / PRE_REWRITE_HEAD_NAME

    # Record current HEAD
    head_sha = get_current_head(repo_path)
    if head_sha:
        head_path.write_text(head_sha + "\n", encoding="utf-8")

    # Create bundle containing all refs
    try:
        subprocess.run(
            ["git", "bundle", "create", str(bundle_path), "--all"],
            cwd=str(repo_path),
            capture_output=True,
            text=True,
            check=True,
        )
    except subprocess.CalledProcessError as exc:
        raise BackupError(f"Failed to create backup bundle: {exc.stderr}") from exc

    return bundle_path


def restore_backup(repo_path: Path) -> None:
    """Restore the repository from a previously created bundle backup.

    This fetches all refs from the bundle and resets HEAD to the
    pre-rewrite state.
    """
    config_dir = repo_path / CONFIG_DIR_NAME
    bundle_path = config_dir / BACKUP_BUNDLE_NAME
    head_path = config_dir / PRE_REWRITE_HEAD_NAME

    if not bundle_path.exists():
        raise BackupError(
            f"No backup bundle found at {bundle_path}. "
            "Cannot undo — no previous backup was created."
        )

    # Fetch all refs from the bundle
    try:
        subprocess.run(
            ["git", "fetch", str(bundle_path), "*:*", "--force"],
            cwd=str(repo_path),
            capture_output=True,
            text=True,
            check=True,
        )
    except subprocess.CalledProcessError as exc:
        raise BackupError(f"Failed to restore from bundle: {exc.stderr}") from exc

    # Reset to pre-rewrite HEAD if available
    if head_path.exists():
        original_head = head_path.read_text(encoding="utf-8").strip()
        if original_head:
            try:
                subprocess.run(
                    ["git", "reset", "--hard", original_head],
                    cwd=str(repo_path),
                    capture_output=True,
                    text=True,
                    check=True,
                )
            except subprocess.CalledProcessError as exc:
                raise BackupError(
                    f"Fetched bundle but failed to reset HEAD: {exc.stderr}"
                ) from exc


def has_backup(repo_path: Path) -> bool:
    """Check if a backup bundle exists."""
    return (repo_path / CONFIG_DIR_NAME / BACKUP_BUNDLE_NAME).exists()


def get_backup_info(repo_path: Path) -> dict[str, str]:
    """Return information about the existing backup."""
    config_dir = repo_path / CONFIG_DIR_NAME
    bundle_path = config_dir / BACKUP_BUNDLE_NAME
    head_path = config_dir / PRE_REWRITE_HEAD_NAME

    info: dict[str, str] = {}

    if bundle_path.exists():
        size_mb = bundle_path.stat().st_size / (1024 * 1024)
        info["bundle_path"] = str(bundle_path)
        info["bundle_size"] = f"{size_mb:.2f} MB"

    if head_path.exists():
        info["original_head"] = head_path.read_text(encoding="utf-8").strip()

    return info


# Auto-stash helpers

_AUTO_STASH_MSG = "git-surgeon: auto-stash pre-rewrite"


class StashError(Exception):
    """Raised when stash push/pop operations fail."""


def has_uncommitted_changes(repo_path: Path) -> bool:
    """Return True if the repo has any staged, unstaged, or untracked changes."""
    try:
        result = subprocess.run(
            ["git", "status", "--porcelain"],
            cwd=str(repo_path),
            capture_output=True,
            text=True,
            check=True,
        )
        return bool(result.stdout.strip())
    except subprocess.CalledProcessError:
        return False


def stash_changes(repo_path: Path) -> bool:
    """Push all changes (tracked + untracked) onto the stash.

    Returns True if a new stash entry was created, False if there was
    nothing to stash (working tree was already clean).

    Raises StashError on failure.
    """
    if not has_uncommitted_changes(repo_path):
        return False

    try:
        subprocess.run(
            ["git", "stash", "push", "-u", "-m", _AUTO_STASH_MSG],
            cwd=str(repo_path),
            capture_output=True,
            text=True,
            check=True,
        )
    except subprocess.CalledProcessError as exc:
        raise StashError(f"Failed to stash changes: {exc.stderr}") from exc

    return True


def pop_stash(repo_path: Path) -> None:
    """Pop the most recent stash entry.

    Raises StashError if the pop fails (e.g. merge conflict).  In that
    case the stash entry is left intact so the user can recover manually
    via ``git stash show`` / ``git stash pop``.
    """
    try:
        subprocess.run(
            ["git", "stash", "pop"],
            cwd=str(repo_path),
            capture_output=True,
            text=True,
            check=True,
        )
    except subprocess.CalledProcessError as exc:
        raise StashError(
            "Auto-stash pop failed — your changes are still saved in the stash.\n"
            "Run 'git stash list' to see them and 'git stash pop' to restore manually.\n"
            f"Details: {exc.stderr}"
        ) from exc
