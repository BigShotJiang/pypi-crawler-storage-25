"""Target repository discovery, validation, and .gitignore management."""

from __future__ import annotations

import subprocess
from pathlib import Path

from git_surgeon.core.config import CONFIG_DIR_NAME


class RepoError(Exception):
    """Raised when the target directory is not a valid git repository."""


def find_repo_root(path: Path | None = None) -> Path:
    """Find the git repository root from the given path (default: cwd).

    Raises RepoError if not inside a git repository.
    """
    start = path or Path.cwd()
    try:
        result = subprocess.run(
            ["git", "rev-parse", "--show-toplevel"],
            cwd=str(start),
            capture_output=True,
            text=True,
            check=True,
        )
        return Path(result.stdout.strip())
    except (subprocess.CalledProcessError, FileNotFoundError) as exc:
        raise RepoError(
            f"'{start}' is not inside a git repository. "
            "Make sure git is installed and you're in a repo directory."
        ) from exc


def validate_repo(repo_path: Path) -> list[str]:
    """Validate that the path is a usable git repository.

    Returns a list of warnings (empty if everything is fine).
    """
    warnings: list[str] = []
    git_dir = repo_path / ".git"
    if not git_dir.exists():
        warnings.append(f"No .git directory found at {repo_path}")
        return warnings

    # Check for uncommitted changes
    try:
        result = subprocess.run(
            ["git", "status", "--porcelain"],
            cwd=str(repo_path),
            capture_output=True,
            text=True,
            check=True,
        )
        if result.stdout.strip():
            warnings.append(
                "Repository has uncommitted changes. "
                "Consider committing or stashing before rewriting history."
            )
    except subprocess.CalledProcessError:
        warnings.append("Could not check repository status.")

    return warnings


def get_commit_count(repo_path: Path) -> int:
    """Return the total number of commits in the repository."""
    try:
        result = subprocess.run(
            ["git", "rev-list", "--count", "--all"],
            cwd=str(repo_path),
            capture_output=True,
            text=True,
            check=True,
        )
        return int(result.stdout.strip())
    except (subprocess.CalledProcessError, ValueError):
        return 0


def get_current_head(repo_path: Path) -> str:
    """Return the current HEAD commit SHA."""
    try:
        result = subprocess.run(
            ["git", "rev-parse", "HEAD"],
            cwd=str(repo_path),
            capture_output=True,
            text=True,
            check=True,
        )
        return result.stdout.strip()
    except subprocess.CalledProcessError:
        return ""


def ensure_gitignore(repo_path: Path) -> bool:
    """Ensure .git-surgeon/ is in .gitignore. Returns True if modified."""
    gitignore = repo_path / ".gitignore"
    entry = CONFIG_DIR_NAME + "/"

    if gitignore.exists():
        content = gitignore.read_text(encoding="utf-8")
        # Check if already ignored
        for line in content.splitlines():
            stripped = line.strip()
            if stripped == entry or stripped == CONFIG_DIR_NAME:
                return False
        # Append
        if not content.endswith("\n"):
            content += "\n"
        content += f"\n# git-surgeon local config (private)\n{entry}\n"
        gitignore.write_text(content, encoding="utf-8")
    else:
        gitignore.write_text(
            f"# git-surgeon local config (private)\n{entry}\n",
            encoding="utf-8",
        )

    return True


def get_authors(repo_path: Path) -> list[dict[str, str | int]]:
    """Return all unique authors in the repo with their commit counts.

    Each entry: {"name": str, "email": str, "commit_count": int}
    Sorted by commit count descending.
    """
    try:
        result = subprocess.run(
            ["git", "log", "--format=%ae|||%an", "--all"],
            cwd=str(repo_path),
            capture_output=True,
            text=True,
            check=True,
        )
    except subprocess.CalledProcessError:
        return []

    counts: dict[tuple[str, str], int] = {}
    for line in result.stdout.splitlines():
        if "|||" not in line:
            continue
        email, name = line.split("|||", 1)
        key = (email.strip(), name.strip())
        counts[key] = counts.get(key, 0) + 1

    return [
        {"email": k[0], "name": k[1], "commit_count": v}
        for k, v in sorted(counts.items(), key=lambda x: -x[1])
    ]


def get_self_identity(repo_path: Path) -> tuple[str, str]:
    """Return the current git user's (name, email) from git config.

    Returns ("", "") if not configured.
    """
    try:
        name = subprocess.run(
            ["git", "config", "user.name"],
            cwd=str(repo_path),
            capture_output=True,
            text=True,
            check=True,
        ).stdout.strip()
        email = subprocess.run(
            ["git", "config", "user.email"],
            cwd=str(repo_path),
            capture_output=True,
            text=True,
            check=True,
        ).stdout.strip()
        return name, email
    except subprocess.CalledProcessError:
        return "", ""
