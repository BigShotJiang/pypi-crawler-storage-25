"""MCP server entry points for git-surgeon."""

from git_surgeon.mcp.server import mcp, run_server

__all__ = ["mcp", "run_server"]
