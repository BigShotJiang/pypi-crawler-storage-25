"""Error handling and response utilities for MCP server."""

from __future__ import annotations

import logging
import sys
from typing import Any

from git_surgeon.mcp.schemas import OperationError

_logger = logging.getLogger("git_surgeon.mcp")
if not _logger.handlers:
    _handler = logging.StreamHandler(sys.stderr)
    _handler.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(message)s"))
    _logger.addHandler(_handler)
_logger.setLevel(logging.INFO)


def error(error_type: str, message: str, details: dict[str, Any] | None = None) -> dict:
    """Log and return a structured error response."""
    _logger.error("%s: %s", error_type, message)
    return OperationError(
        error_type=error_type,
        message=message,
        details=details,
    ).model_dump()


__all__ = ["error", "_logger"]
