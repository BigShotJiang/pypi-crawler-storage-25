"""Pydantic schemas for git-surgeon MCP tools."""

from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field


class AuthorRuleSchema(BaseModel):
    model_config = ConfigDict(extra="forbid")

    match_field: str = Field(default="subject")
    match_pattern: str = Field(default="")
    new_name: str
    new_email: str
    is_regex: bool = False
    is_default: bool = False


class ReplacementSchema(BaseModel):
    model_config = ConfigDict(extra="forbid")

    find: str
    replace: str = ""
    is_regex: bool = False


class FilterRuleSchema(BaseModel):
    model_config = ConfigDict(extra="forbid")

    field: Literal[
        "author_name",
        "author_email",
        "subject",
        "message",
        "date",
    ]
    pattern: str
    action: Literal["remove", "keep"] = "remove"
    is_regex: bool = False


class Author(BaseModel):
    model_config = ConfigDict(extra="forbid")

    name: str
    email: str
    commit_count: int


class AuthorRewriteRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    repo_path: str
    rules: list[AuthorRuleSchema]
    preserve_attribution: bool = True


class MessageScrubRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    repo_path: str
    replacements: list[ReplacementSchema]


class BlobScrubRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    repo_path: str
    patterns: list[str]


class CommitFilterRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    repo_path: str
    rules: list[FilterRuleSchema]


class MergeFlattenRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    repo_path: str


class DescribeResult(BaseModel):
    model_config = ConfigDict(extra="forbid")

    impact_summary: str
    commits_affected: int
    warnings: list[str] = Field(default_factory=list)
    estimated_changes: dict[str, Any] = Field(default_factory=dict)


class ExecutionResult(BaseModel):
    model_config = ConfigDict(extra="forbid")

    success: bool
    backup_path: str | None = None
    commit_count_changed: int = 0
    details: dict[str, Any] = Field(default_factory=dict)


class RepositoryInfo(BaseModel):
    model_config = ConfigDict(extra="forbid")

    repo_path: str
    commit_count: int
    authors_list: list[Author] = Field(default_factory=list)
    has_backup: bool
    config_exists: bool
    warnings: list[str] = Field(default_factory=list)


class OperationError(BaseModel):
    model_config = ConfigDict(extra="forbid")

    error_type: str
    message: str
    details: dict[str, Any] | None = None
