"""Helper utilities for MCP server operations."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from git_surgeon.core.repo import RepoError, find_repo_root
from git_surgeon.mcp.errors import error


def resolve_repo_root(repo_path: str | None) -> Path:
    """Resolve the git repository root from a path."""
    base = Path(repo_path) if repo_path else Path.cwd()
    return find_repo_root(base)


def signature(payload: dict[str, Any]) -> str:
    """Generate a canonical signature for a payload for comparison."""
    return json.dumps(payload, sort_keys=True, default=str)


_DESCRIBE_CACHE: dict[tuple[str, str], str] = {}


def record_describe(
    repo_root: Path, operation_name: str, payload: dict[str, Any]
) -> None:
    """Cache the describe signature for later validation."""
    key = (str(repo_root), operation_name)
    _DESCRIBE_CACHE[key] = signature(payload)


def require_describe(
    repo_root: Path,
    operation_name: str,
    payload: dict[str, Any],
) -> dict | None:
    """Enforce describe-first pattern: validate that describe was called with same args."""
    key = (str(repo_root), operation_name)
    expected = _DESCRIBE_CACHE.get(key)
    if expected is None:
        return error(
            "describe_required",
            f"Call describe_{operation_name} before execute_{operation_name}.",
        )
    if expected != signature(payload):
        return error(
            "describe_mismatch",
            "Describe parameters do not match the execute request. Re-run describe.",
        )
    return None


__all__ = [
    "resolve_repo_root",
    "signature",
    "record_describe",
    "require_describe",
]
