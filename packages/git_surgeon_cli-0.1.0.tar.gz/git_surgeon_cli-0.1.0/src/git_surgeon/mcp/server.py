"""MCP server exposing git-surgeon operations."""

from __future__ import annotations

from pathlib import Path
from typing import Any

from mcp.server.fastmcp import FastMCP
from pydantic import ValidationError

from git_surgeon.core.config import BACKUP_BUNDLE_NAME, CONFIG_DIR_NAME, Config
from git_surgeon.core.engine import Engine, EngineError
from git_surgeon.core.repo import (
    RepoError,
    get_authors,
    get_commit_count,
    validate_repo,
)
from git_surgeon.core.safety import (
    BackupError,
    create_backup,
    has_backup,
    restore_backup,
)
from git_surgeon.operations.author_rewrite import AuthorRewrite, AuthorRule
from git_surgeon.operations.blob_scrub import BlobScrub, BlobReplacement
from git_surgeon.operations.commit_filter import CommitFilter, FilterRule
from git_surgeon.operations.merge_flatten import MergeFlatten
from git_surgeon.operations.message_scrub import MessageScrub, MessageReplacement

from git_surgeon.mcp.errors import error
from git_surgeon.mcp.helpers import (
    record_describe,
    require_describe,
    resolve_repo_root,
)
from git_surgeon.mcp.schemas import (
    Author,
    AuthorRewriteRequest,
    BlobScrubRequest,
    CommitFilterRequest,
    DescribeResult,
    ExecutionResult,
    MergeFlattenRequest,
    MessageScrubRequest,
    RepositoryInfo,
)

mcp = FastMCP("git-surgeon")


def _describe(repo_path: str, operations: list) -> dict:
    try:
        repo_root = resolve_repo_root(repo_path)
    except RepoError as exc:
        return error("repo_error", str(exc))

    engine = Engine(repo_root, operations=operations, dry_run=True, force=True)
    errors_list = engine.validate()
    if errors_list:
        return error("validation_error", "Validation failed", {"errors": errors_list})

    preview = engine.preview()
    impact_summary = (
        "\n".join(preview.get("operations", []))
        if preview.get("operations")
        else "No operations configured."
    )

    callback_value = preview.get("callback", "")
    estimated_changes = {
        "operations": preview.get("operations", []),
        "callback_present": bool(callback_value)
        and not str(callback_value).startswith("(none"),
        "replace_text_count": len(preview.get("replace_text", [])),
        "author_impact": preview.get("author_impact", []),
        "self_email": preview.get("self_email", ""),
        "has_non_analyzable_author_rules": preview.get(
            "has_non_analyzable_author_rules", False
        ),
    }

    return DescribeResult(
        impact_summary=impact_summary,
        commits_affected=preview.get("commit_count", 0),
        warnings=preview.get("warnings", []),
        estimated_changes=estimated_changes,
    ).model_dump()


def _execute(repo_path: str, operations: list, operation_name: str) -> dict:
    try:
        repo_root = resolve_repo_root(repo_path)
    except RepoError as exc:
        return error("repo_error", str(exc))

    engine = Engine(
        repo_root,
        operations=operations,
        dry_run=False,
        force=True,
        skip_backup=True,
    )
    errors_list = engine.validate()
    if errors_list:
        return error("validation_error", "Validation failed", {"errors": errors_list})

    commit_count_before = get_commit_count(repo_root)

    try:
        backup_path = create_backup(repo_root)
    except BackupError as exc:
        return error("backup_error", str(exc))

    try:
        engine.run()
    except EngineError as exc:
        return error("engine_error", str(exc))

    commit_count_after = get_commit_count(repo_root)

    return ExecutionResult(
        success=True,
        backup_path=str(backup_path),
        commit_count_changed=commit_count_after - commit_count_before,
        details={
            "commit_count_before": commit_count_before,
            "commit_count_after": commit_count_after,
            "operation": operation_name,
        },
    ).model_dump()


def _build_author_rewrite(request: AuthorRewriteRequest) -> AuthorRewrite:
    rules = [
        AuthorRule(
            match_field=r.match_field,
            match_pattern=r.match_pattern,
            new_name=r.new_name,
            new_email=r.new_email,
            is_regex=r.is_regex,
            is_default=r.is_default,
        )
        for r in request.rules
    ]
    return AuthorRewrite(rules=rules, preserve_attribution=request.preserve_attribution)


def _build_message_scrub(request: MessageScrubRequest) -> MessageScrub:
    replacements = [
        MessageReplacement(find=r.find, replace=r.replace, is_regex=r.is_regex)
        for r in request.replacements
    ]
    return MessageScrub(replacements=replacements)


def _build_blob_scrub(request: BlobScrubRequest) -> BlobScrub:
    replacements = [BlobReplacement(find=pattern) for pattern in request.patterns]
    return BlobScrub(replacements=replacements)


def _build_commit_filter(request: CommitFilterRequest) -> CommitFilter:
    rules = [
        FilterRule(
            field=r.field,
            pattern=r.pattern,
            action=r.action,
            is_regex=r.is_regex,
        )
        for r in request.rules
    ]
    return CommitFilter(rules=rules)


@mcp.tool()
def describe_author_rewrite(
    repo_path: str,
    rules: list[dict],
    preserve_attribution: bool = True,
) -> dict:
    """SAFE: Preview author rewrite without mutating history."""
    try:
        request = AuthorRewriteRequest(
            repo_path=repo_path,
            rules=rules,
            preserve_attribution=preserve_attribution,
        )
    except ValidationError as exc:
        return error("validation_error", "Invalid request", {"errors": exc.errors()})
    try:
        repo_root = resolve_repo_root(request.repo_path)
    except RepoError as exc:
        return error("repo_error", str(exc))

    payload = request.model_dump()
    payload["repo_path"] = str(repo_root)
    record_describe(repo_root, "author_rewrite", payload)

    return _describe(request.repo_path, [_build_author_rewrite(request)])


@mcp.tool()
def execute_author_rewrite(
    repo_path: str,
    rules: list[dict],
    preserve_attribution: bool = True,
) -> dict:
    """DESTRUCTIVE: Rewrite commit authors. Call describe_author_rewrite first."""
    try:
        request = AuthorRewriteRequest(
            repo_path=repo_path,
            rules=rules,
            preserve_attribution=preserve_attribution,
        )
    except ValidationError as exc:
        return error("validation_error", "Invalid request", {"errors": exc.errors()})
    try:
        repo_root = resolve_repo_root(request.repo_path)
    except RepoError as exc:
        return error("repo_error", str(exc))

    payload = request.model_dump()
    payload["repo_path"] = str(repo_root)
    guard = require_describe(repo_root, "author_rewrite", payload)
    if guard:
        return guard

    return _execute(
        request.repo_path,
        [_build_author_rewrite(request)],
        "author_rewrite",
    )


@mcp.tool()
def describe_message_scrub(repo_path: str, replacements: list[dict]) -> dict:
    """SAFE: Preview message scrubbing without mutating history."""
    try:
        request = MessageScrubRequest(repo_path=repo_path, replacements=replacements)
    except ValidationError as exc:
        return error("validation_error", "Invalid request", {"errors": exc.errors()})
    try:
        repo_root = resolve_repo_root(request.repo_path)
    except RepoError as exc:
        return error("repo_error", str(exc))

    payload = request.model_dump()
    payload["repo_path"] = str(repo_root)
    record_describe(repo_root, "message_scrub", payload)

    return _describe(request.repo_path, [_build_message_scrub(request)])


@mcp.tool()
def execute_message_scrub(repo_path: str, replacements: list[dict]) -> dict:
    """DESTRUCTIVE: Scrub commit messages. Call describe_message_scrub first."""
    try:
        request = MessageScrubRequest(repo_path=repo_path, replacements=replacements)
    except ValidationError as exc:
        return error("validation_error", "Invalid request", {"errors": exc.errors()})
    try:
        repo_root = resolve_repo_root(request.repo_path)
    except RepoError as exc:
        return error("repo_error", str(exc))

    payload = request.model_dump()
    payload["repo_path"] = str(repo_root)
    guard = require_describe(repo_root, "message_scrub", payload)
    if guard:
        return guard

    return _execute(request.repo_path, [_build_message_scrub(request)], "message_scrub")


@mcp.tool()
def describe_blob_scrub(repo_path: str, patterns: list[str]) -> dict:
    """SAFE: Preview blob scrubbing without mutating history."""
    try:
        request = BlobScrubRequest(repo_path=repo_path, patterns=patterns)
    except ValidationError as exc:
        return error("validation_error", "Invalid request", {"errors": exc.errors()})
    try:
        repo_root = resolve_repo_root(request.repo_path)
    except RepoError as exc:
        return error("repo_error", str(exc))

    payload = request.model_dump()
    payload["repo_path"] = str(repo_root)
    record_describe(repo_root, "blob_scrub", payload)

    return _describe(request.repo_path, [_build_blob_scrub(request)])


@mcp.tool()
def execute_blob_scrub(repo_path: str, patterns: list[str]) -> dict:
    """DESTRUCTIVE: Scrub blob content. Call describe_blob_scrub first."""
    try:
        request = BlobScrubRequest(repo_path=repo_path, patterns=patterns)
    except ValidationError as exc:
        return error("validation_error", "Invalid request", {"errors": exc.errors()})
    try:
        repo_root = resolve_repo_root(request.repo_path)
    except RepoError as exc:
        return error("repo_error", str(exc))

    payload = request.model_dump()
    payload["repo_path"] = str(repo_root)
    guard = require_describe(repo_root, "blob_scrub", payload)
    if guard:
        return guard

    return _execute(request.repo_path, [_build_blob_scrub(request)], "blob_scrub")


@mcp.tool()
def describe_commit_filter(repo_path: str, rules: list[dict]) -> dict:
    """SAFE: Preview commit filtering without mutating history."""
    try:
        request = CommitFilterRequest(repo_path=repo_path, rules=rules)
    except ValidationError as exc:
        return error("validation_error", "Invalid request", {"errors": exc.errors()})
    try:
        repo_root = resolve_repo_root(request.repo_path)
    except RepoError as exc:
        return error("repo_error", str(exc))

    payload = request.model_dump()
    payload["repo_path"] = str(repo_root)
    record_describe(repo_root, "commit_filter", payload)

    return _describe(request.repo_path, [_build_commit_filter(request)])


@mcp.tool()
def execute_commit_filter(repo_path: str, rules: list[dict]) -> dict:
    """DESTRUCTIVE: Filter commits. Call describe_commit_filter first."""
    try:
        request = CommitFilterRequest(repo_path=repo_path, rules=rules)
    except ValidationError as exc:
        return error("validation_error", "Invalid request", {"errors": exc.errors()})
    try:
        repo_root = resolve_repo_root(request.repo_path)
    except RepoError as exc:
        return error("repo_error", str(exc))

    payload = request.model_dump()
    payload["repo_path"] = str(repo_root)
    guard = require_describe(repo_root, "commit_filter", payload)
    if guard:
        return guard

    return _execute(request.repo_path, [_build_commit_filter(request)], "commit_filter")


@mcp.tool()
def describe_merge_flatten(repo_path: str) -> dict:
    """SAFE: Preview merge flatten without mutating history."""
    try:
        request = MergeFlattenRequest(repo_path=repo_path)
    except ValidationError as exc:
        return error("validation_error", "Invalid request", {"errors": exc.errors()})
    try:
        repo_root = resolve_repo_root(request.repo_path)
    except RepoError as exc:
        return error("repo_error", str(exc))

    payload = request.model_dump()
    payload["repo_path"] = str(repo_root)
    record_describe(repo_root, "merge_flatten", payload)

    return _describe(request.repo_path, [MergeFlatten(enabled=True)])


@mcp.tool()
def execute_merge_flatten(repo_path: str) -> dict:
    """DESTRUCTIVE: Flatten merge commits. Call describe_merge_flatten first."""
    try:
        request = MergeFlattenRequest(repo_path=repo_path)
    except ValidationError as exc:
        return error("validation_error", "Invalid request", {"errors": exc.errors()})
    try:
        repo_root = resolve_repo_root(request.repo_path)
    except RepoError as exc:
        return error("repo_error", str(exc))

    payload = request.model_dump()
    payload["repo_path"] = str(repo_root)
    guard = require_describe(repo_root, "merge_flatten", payload)
    if guard:
        return guard

    return _execute(request.repo_path, [MergeFlatten(enabled=True)], "merge_flatten")


@mcp.tool()
def validate_repository(repo_path: str) -> dict:
    """Validate the repository and return basic metadata."""
    try:
        repo_root = resolve_repo_root(repo_path)
    except RepoError as exc:
        return error("repo_error", str(exc))

    warnings = validate_repo(repo_root)
    authors = [Author(**a) for a in get_authors(repo_root)]
    info = RepositoryInfo(
        repo_path=str(repo_root),
        commit_count=get_commit_count(repo_root),
        authors_list=authors,
        has_backup=has_backup(repo_root),
        config_exists=Config.config_file(repo_root).exists(),
        warnings=warnings,
    )
    return info.model_dump()


@mcp.tool()
def get_repository_config(repo_path: str) -> dict:
    """Load and return the git-surgeon config for a repository."""
    try:
        repo_root = resolve_repo_root(repo_path)
    except RepoError as exc:
        return error("repo_error", str(exc))

    config_file = Config.config_file(repo_root)
    config = Config.load(repo_root)
    return {
        "config_path": str(config_file),
        "exists": config_file.exists(),
        "general": config.general,
        "operations": [op.to_config() for op in config.operations],
        "operations_description": [op.describe() for op in config.operations],
    }


@mcp.tool()
def undo_last_operation(repo_path: str) -> dict:
    """Restore the repository from the last backup bundle."""
    try:
        repo_root = resolve_repo_root(repo_path)
    except RepoError as exc:
        return error("repo_error", str(exc))

    if not has_backup(repo_root):
        return error(
            "backup_missing",
            "No backup found. Run a destructive operation first.",
        )

    commit_count_before = get_commit_count(repo_root)

    try:
        restore_backup(repo_root)
    except BackupError as exc:
        return error("backup_restore_error", str(exc))

    commit_count_after = get_commit_count(repo_root)
    backup_path = repo_root / CONFIG_DIR_NAME / BACKUP_BUNDLE_NAME

    return ExecutionResult(
        success=True,
        backup_path=str(backup_path),
        commit_count_changed=commit_count_after - commit_count_before,
        details={
            "commit_count_before": commit_count_before,
            "commit_count_after": commit_count_after,
            "operation": "undo_last_operation",
        },
    ).model_dump()


def run_server() -> None:
    """Run the MCP server over stdio transport."""
    mcp.run(transport="stdio")


if __name__ == "__main__":
    run_server()
