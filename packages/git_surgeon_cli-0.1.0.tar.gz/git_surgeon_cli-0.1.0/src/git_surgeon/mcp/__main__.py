"""Module entrypoint for `python -m git_surgeon.mcp`."""

from git_surgeon.mcp.server import run_server


if __name__ == "__main__":
    run_server()
