# Safety & Undo

git-surgeon rewrites git history, which is inherently destructive. This document explains the safety mechanisms in place, how to recover from mistakes, and best practices.

## The Problem

`git-filter-repo` (the underlying engine) is a **destructive** operation:

- It rewrites every commit SHA in the repository
- It runs `git reflog expire --expire=now --all` to clear reflogs
- It runs `git gc --prune=now` to garbage-collect old objects
- After execution, the original commits **no longer exist** in the repository

This means standard git recovery (`git reflog`, `git fsck --lost-found`) **will not work** after a `git-filter-repo` run.

## How git-surgeon Protects You

### 1. Backup Bundle

Before every `git-surgeon run`, the tool automatically creates a backup using `git bundle`:

```
git bundle create .git-surgeon/backup.bundle --all
```

A git bundle is a compressed, portable file containing **every ref and all reachable objects** — essentially the entire repository in a single file. It's typically 30–70% smaller than the `.git` directory.

The bundle is saved at `.git-surgeon/backup.bundle`, and the pre-rewrite HEAD SHA is recorded in `.git-surgeon/pre-rewrite-head`.

### 2. Confirmation Prompt

Before executing, git-surgeon shows:
- A preview of all operations
- The number of commits that will be rewritten
- A confirmation prompt: "This will rewrite N commit(s). Continue? [y/N]"

Skip with `--force` if you're confident.

### 3. Dry Run

Every command supports `--dry-run` (or `-n`), which shows exactly what would happen without modifying anything:

```bash
git-surgeon run --dry-run
```

The dry run shows:
- The composed Python callback code (syntax-highlighted)
- All replace-text patterns
- A summary table
- Validation errors if any

### 4. Auto-gitignore

`.git-surgeon/` is automatically added to `.gitignore`, so:
- The backup bundle (containing original history) never gets pushed
- Sensitive patterns in the config never get committed
- The generated callback (which may embed secrets) stays local

## Restoring from Backup

### Using `git-surgeon undo`

```bash
git-surgeon undo
```

This command:
1. Verifies `.git-surgeon/backup.bundle` exists
2. Shows backup info (file size, original HEAD)
3. Prompts for confirmation
4. Runs `git fetch .git-surgeon/backup.bundle '*:*' --force` to restore all refs
5. Runs `git reset --hard <original-HEAD>` to restore the working tree

After undo, the repository is in the **exact same state** as before the rewrite.

### Manual Restore

If `git-surgeon undo` fails for any reason, you can restore manually:

```bash
# Option A: Fetch refs back from the bundle
git fetch .git-surgeon/backup.bundle '*:*' --force
git reset --hard $(cat .git-surgeon/pre-rewrite-head)

# Option B: Clone from the bundle (fresh copy)
git clone .git-surgeon/backup.bundle restored-repo
```

### What if there's no backup?

If you ran with `--skip-backup` or the bundle was deleted, recovery options are limited:

- **Remote still has original history?** → `git fetch origin` + `git reset --hard origin/main`
- **You cloned before rewriting?** → Copy from the original clone
- **Neither?** → The original history is lost

## Best Practices

### Always work on a clone

The safest approach is to rewrite a **fresh clone**, not your working repo:

```bash
git clone /path/to/original /path/to/rewrite-target
cd /path/to/rewrite-target
git-surgeon init
# ... configure operations ...
git-surgeon run
```

If something goes wrong, delete the clone and start over.

### Preview first

Always run `git-surgeon preview` or `git-surgeon run --dry-run` before executing. Read the generated callback carefully — it shows the exact Python code that will run on every commit.

### Keep bundles until you're sure

Don't delete `.git-surgeon/backup.bundle` until you've verified the rewrite is correct. Check:

```bash
git log --oneline            # verify commit messages
git log --format='%an <%ae>' # verify author attributions
git show HEAD:some/file.py   # verify file contents are scrubbed
```

### Small, iterative rewrites

If you're unsure about the results, use individual subcommands with `--execute` to apply operations one at a time, verifying between each:

```bash
git-surgeon flatten --execute
# check results...
git-surgeon undo              # if wrong, undo and retry

git-surgeon rewrite-authors --name "X" --email "x@y.com" --default --execute
# check results...
```

Note: each `--execute` overwrites the previous backup bundle. If you need to undo through multiple steps, create manual backups between runs:

```bash
cp .git-surgeon/backup.bundle .git-surgeon/backup-step1.bundle
```

## What Gets Modified

| Artifact | Modified by `run`? | Restored by `undo`? |
| --- | --- | --- |
| Commit SHAs | Yes (all rewritten) | Yes |
| Commit messages | Yes (if MessageScrub configured) | Yes |
| Author/committer name & email | Yes (if AuthorRewrite configured) | Yes |
| File contents (blobs) | Yes (if BlobScrub configured) | Yes |
| Merge topology | Yes (if MergeFlatten configured) | Yes |
| Reflogs | Destroyed by git-filter-repo | Partially (bundle doesn't contain reflogs) |
| Tags | Rewritten (new SHAs) | Yes |
| Remote tracking refs | Removed by git-filter-repo | Not restored (re-fetch from remote) |

## Push Implications

After a successful rewrite, you'll need to force-push:

```bash
git push --force --all
git push --force --tags
```

**Warning:** This rewrites history for all collaborators. Coordinate with your team before force-pushing.

## Limitations

- **One backup at a time** — each `run` overwrites `backup.bundle`. For multi-step workflows, manually copy bundles between runs.
- **Reflogs are lost** — git-filter-repo destroys reflogs during its cleanup. The bundle doesn't preserve them.
- **Remote refs are removed** — `git-filter-repo` removes remote tracking branches. After undo, you may need to `git fetch origin` to get them back.
- **Large repos** — bundle creation time and size scales with repo size. For very large repos (>1 GB), backup creation may take significant time and disk space.
