# Operations Guide

git-surgeon ships with five pluggable operations. Each one knows how to generate the code that `git-filter-repo` executes — either as a per-commit Python callback (`--commit-callback`) or as blob replacement patterns (`--replace-text`).

All operations implement the same `Operation` base class, so they share a consistent interface for validation, preview, serialization, and execution.

## Execution Order

Operations are sorted by **priority** before composing the callback. Lower priority numbers run first:

| Priority | Operation | Why this order |
| --- | --- | --- |
| 10 | Merge Flatten | Structural changes before anything else |
| 20 | Message Scrub | Clean messages before matching against them |
| 30 | Author Rewrite | Match on already-cleaned subjects/messages |
| 40 | Commit Filter | Filter after all transformations are applied |
| 50 | Blob Scrub | Handled separately via `--replace-text`, not in callback |

This ordering is automatic — you don't need to worry about it. Configure operations in any order; the engine sorts them.

---

## Author Rewrite

Reattribute commits to different authors based on matching rules.

### How it works

Each rule has:
- **`match_field`** — which part of the commit to match against
- **`match_pattern`** — text or regex to look for
- **`new_name`** / **`new_email`** — the new author identity

When a commit matches a rule, both `author_*` and `committer_*` fields are rewritten.

### Match fields

| Field | What it matches | Example use case |
| --- | --- | --- |
| `subject` | First line of commit message | Match specific features/commits |
| `author_name` | Current author name | Map old names to new |
| `author_email` | Current author email | Map emails after domain change |
| `message` | Entire commit message | Match body text |
| `body` | Everything after the first line | Match PR descriptions |
| `all` | Message + author name + email concatenated | Broadest matching |

### Default (catch-all) rule

A rule with `is_default = true` matches any commit not matched by other rules. You can have at most one default rule. This is useful for setting a fallback author.

### CLI examples

```bash
# Match commits by subject line
git-surgeon rewrite-authors \
  --match-field subject \
  --match-pattern "feat: login page" \
  --name "Alice" --email "alice@example.com" --save

# Match by old author email
git-surgeon rewrite-authors \
  --match-field author_email \
  --match-pattern "old@company.com" \
  --name "Bob" --email "bob@newcompany.com" --save

# Catch-all for everything else
git-surgeon rewrite-authors \
  --name "Default Author" --email "default@example.com" \
  --default --save

# Regex matching
git-surgeon rewrite-authors \
  --match-field subject \
  --match-pattern "^(feat|fix)\(frontend\)" \
  --regex \
  --name "Frontend Dev" --email "frontend@team.com" --save
```

### Config format

```toml
[[operations]]
type = "author_rewrite"

# Specific rule: match commits with this subject
[[operations.rules]]
match_field = "subject"
match_pattern = "feat: login page"
new_name = "Alice"
new_email = "alice@example.com"

# Default: catch-all for unmatched commits
[[operations.rules]]
is_default = true
new_name = "Default Author"
new_email = "default@example.com"
```

### Generated callback (example)

For subject-based exact matching, git-surgeon optimizes by using a Python `set` for O(1) lookups:

```python
# --- Author Rewrite ---
_subject = commit.message.split(b"\n")[0].strip()
_author_matched = False
_author_set_0 = {b'feat: login page', b'feat: signup flow'}
if _subject in _author_set_0:
    commit.author_name = b'Alice'
    commit.author_email = b'alice@example.com'
    commit.committer_name = b'Alice'
    commit.committer_email = b'alice@example.com'
    _author_matched = True
if not _author_matched:
    commit.author_name = b'Default Author'
    commit.author_email = b'default@example.com'
    commit.committer_name = b'Default Author'
    commit.committer_email = b'default@example.com'
```

---

## Message Scrub

Find-and-replace text in commit messages across all history.

### Use cases

- Rename an organization in all commit messages
- Remove internal URLs or email addresses
- Fix typos in historical commit messages
- Strip internal ticket references (e.g., JIRA IDs)

### CLI examples

```bash
# Simple literal replacement
git-surgeon scrub --find "OldCompanyName" --replace "NewCompanyName" --messages --save

# Remove an email from messages
git-surgeon scrub --find "internal@company.com" --replace "***REMOVED***" --messages --save

# Regex replacement
git-surgeon scrub --find "JIRA-\d+" --replace "[REDACTED]" --regex --messages --save
```

### Config format

```toml
[[operations]]
type = "message_scrub"

[[operations.replacements]]
find = "OldCompanyName"
replace = "NewCompanyName"

[[operations.replacements]]
find = "JIRA-\\d+"
replace = "[REDACTED]"
is_regex = true
```

### Generated callback

```python
# --- Message Scrub ---
msg = commit.message
msg = msg.replace(b'OldCompanyName', b'NewCompanyName')
import re as _re
msg = _re.sub(b'JIRA-\\d+', b'[REDACTED]', msg)
commit.message = msg
```

---

## Blob Scrub

Replace sensitive patterns in **file contents** across all history. This uses `git-filter-repo`'s `--replace-text` mechanism, which operates on blob data (not commit metadata).

### Use cases

- Remove API keys, tokens, passwords from source code history
- Replace internal hostnames or URLs
- Scrub email addresses from config files
- Remove license keys

### CLI examples

```bash
# Scrub a secret from file contents
git-surgeon scrub --find "AKIA1234567890ABCDEF" --blobs --save

# Custom replacement text
git-surgeon scrub --find "password=hunter2" --replace "password=***" --blobs --save

# Regex pattern
git-surgeon scrub --find "sk_live_[a-zA-Z0-9]{24}" --replace "sk_live_***REMOVED***" --regex --blobs --save

# Both messages AND blobs (default when neither flag is specified)
git-surgeon scrub --find "secret@email.com"
```

### Config format

```toml
[[operations]]
type = "blob_scrub"

[[operations.replacements]]
find = "AKIA1234567890ABCDEF"
replace = "***REMOVED***"

[[operations.replacements]]
find = "sk_live_[a-zA-Z0-9]{24}"
replace = "sk_live_***REMOVED***"
is_regex = true
```

### How it differs from Message Scrub

| Aspect | Message Scrub | Blob Scrub |
| --- | --- | --- |
| Target | Commit messages | File contents (blobs) |
| Mechanism | `--commit-callback` Python code | `--replace-text` patterns file |
| Format | Python `bytes.replace()` or `re.sub()` | git-filter-repo `==>` syntax |
| When it runs | Callback per commit | Internally by git-filter-repo |

---

## Merge Flatten

Linearize git history by converting merge commits to single-parent commits (keeping only the first parent).

### When to use

- Cleaning up a messy branching history before open-sourcing
- Converting a merge-heavy workflow to a linear history for readability
- Preparing a repo for tools that expect linear history

### CLI

```bash
git-surgeon flatten --save          # save to config
git-surgeon flatten --execute       # save and execute immediately
git-surgeon flatten --dry-run       # preview only
```

### Config format

```toml
[[operations]]
type = "merge_flatten"
enabled = true
```

### Generated callback

```python
# --- Merge Flatten ---
if len(commit.parents) > 1:
    commit.parents = [commit.parents[0]]
```

### Caution

Merge flattening is lossy — it discards the second (and subsequent) parents of merge commits. The code changes from the merged branch are preserved (they're in the tree), but the history topology changes from a DAG to a line. This cannot be undone except by restoring from backup.

---

## Commit Filter

Remove or keep commits matching specific criteria. Matching commits are either skipped (removed from history) or kept (everything else removed).

### Match fields

| Field | What it matches |
| --- | --- |
| `author_name` | Commit author name |
| `author_email` | Commit author email |
| `subject` | First line of commit message |
| `message` | Full commit message |
| `date` | Author date string |

### Actions

- **`remove`** — skip commits that match the pattern (keep everything else)
- **`keep`** — keep only commits that match (skip everything else)

### CLI examples

```bash
# Remove all dependabot commits
git-surgeon filter --field author_name --pattern "dependabot" --action remove --save

# Keep only commits from a specific author
git-surgeon filter --field author_email --pattern "alice@example.com" --action keep --save

# Remove commits with "WIP" in the subject
git-surgeon filter --field subject --pattern "WIP" --action remove --save

# Regex: remove all merge commits by message pattern
git-surgeon filter --field subject --pattern "^Merge (pull request|branch)" \
  --regex --action remove --save
```

### Config format

```toml
[[operations]]
type = "commit_filter"

[[operations.rules]]
field = "author_name"
pattern = "dependabot"
action = "remove"

[[operations.rules]]
field = "subject"
pattern = "^Merge (pull request|branch)"
action = "remove"
is_regex = true
```

### Generated callback

```python
# --- Commit Filter ---
if b'dependabot' in commit.author_name:
    commit.skip()
import re as _re
if _re.search(b'^Merge (pull request|branch)', commit.message.split(b"\n")[0].strip()):
    commit.skip()
```

---

## Combining multiple operations

Operations are designed to be composed. You can configure any combination in a single config file, and they'll all execute in one pass:

```toml
# 1. Flatten merges first (priority 10)
[[operations]]
type = "merge_flatten"
enabled = true

# 2. Clean up messages (priority 20)
[[operations]]
type = "message_scrub"
[[operations.replacements]]
find = "OldOrg"
replace = "NewOrg"

# 3. Reattribute authors (priority 30)
[[operations]]
type = "author_rewrite"
[[operations.rules]]
is_default = true
new_name = "Maintainer"
new_email = "maintainer@neworg.com"

# 4. Remove bot commits (priority 40)
[[operations]]
type = "commit_filter"
[[operations.rules]]
field = "author_name"
pattern = "dependabot"
action = "remove"

# 5. Scrub secrets from files (priority 50, via --replace-text)
[[operations]]
type = "blob_scrub"
[[operations.replacements]]
find = "secret-api-key"
replace = "***REMOVED***"
```

Run `git-surgeon preview` to see the composed callback before executing.
