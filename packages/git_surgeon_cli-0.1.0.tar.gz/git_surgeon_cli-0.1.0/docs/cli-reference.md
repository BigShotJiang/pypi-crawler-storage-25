# CLI Reference

Complete reference for every git-surgeon command, option, and flag.

## Global Options

These options are available on all commands when placed before the subcommand:

```bash
git-surgeon [GLOBAL OPTIONS] COMMAND [COMMAND OPTIONS]
```

| Option | Short | Type | Default | Description |
| --- | --- | --- | --- | --- |
| `--repo` | `-r` | PATH | cwd | Path to the target git repository |
| `--dry-run` | `-n` | flag | off | Preview changes without modifying the repo |
| `--force` | `-f` | flag | off | Skip confirmation prompts |
| `--verbose` | `-v` | flag | off | Enable verbose output |
| `--help` | | flag | | Show help and exit |

## Commands

---

### `git-surgeon` (no subcommand)

Launch the interactive wizard. Guides you through operation selection, configuration, preview, and execution.

```bash
git-surgeon
git-surgeon --dry-run          # wizard in preview-only mode
git-surgeon --repo /path/to/repo
```

---

### `git-surgeon init`

Initialize the `.git-surgeon/` config directory in the target repo.

```bash
git-surgeon init [OPTIONS]
```

| Option | Short | Type | Default | Description |
| --- | --- | --- | --- | --- |
| `--repo` | `-r` | PATH | cwd | Target repository |
| `--template` / `--no-template` | `-t` | flag | template | Generate a commented template config |

**What it does:**
1. Creates `.git-surgeon/` directory
2. Writes `config.toml` (template with commented examples, or empty)
3. Adds `.git-surgeon/` to `.gitignore`

---

### `git-surgeon run`

Execute all operations defined in `.git-surgeon/config.toml`.

```bash
git-surgeon run [OPTIONS]
```

| Option | Short | Type | Default | Description |
| --- | --- | --- | --- | --- |
| `--repo` | `-r` | PATH | cwd | Target repository |
| `--dry-run` | `-n` | flag | off | Preview without executing |
| `--force` | `-f` | flag | off | Skip confirmation prompt |
| `--skip-backup` | | flag | off | Don't create backup bundle |

**What it does:**
1. Loads config and validates all operations
2. Shows a preview (always)
3. Creates a backup bundle (unless `--skip-backup`)
4. Prompts for confirmation (unless `--force`)
5. Invokes `git-filter-repo` with the composed callback and replace-text

---

### `git-surgeon preview`

Show what all configured operations would do, without executing anything.

```bash
git-surgeon preview [OPTIONS]
```

| Option | Short | Type | Default | Description |
| --- | --- | --- | --- | --- |
| `--repo` | `-r` | PATH | cwd | Target repository |

**Output includes:**
- Summary table (commit count, operation count, callback presence)
- Each operation's description
- The full generated Python callback code (syntax-highlighted)
- All replace-text patterns

---

### `git-surgeon rewrite-authors`

Add author rewriting rules to the config, or execute them immediately.

```bash
git-surgeon rewrite-authors [OPTIONS]
```

| Option | Short | Type | Default | Description |
| --- | --- | --- | --- | --- |
| `--repo` | `-r` | PATH | cwd | Target repository |
| `--match-field` | `-m` | TEXT | `subject` | Field to match: `subject`, `author_name`, `author_email`, `message`, `all` |
| `--match-pattern` | `-p` | TEXT | | Pattern to match commits against |
| `--name` | | TEXT | | New author/committer name |
| `--email` | | TEXT | | New author/committer email |
| `--default` | | flag | off | Make this a catch-all rule |
| `--regex` | | flag | off | Treat pattern as regex |
| `--save` / `--no-save` | | flag | save | Save rule to config |
| `--execute` | `-x` | flag | off | Execute immediately |
| `--interactive` | `-i` | flag | off | Interactive mode |
| `--dry-run` | `-n` | flag | off | Preview only |
| `--force` | `-f` | flag | off | Skip confirmation |

**Examples:**

```bash
# CLI: specific rule
git-surgeon rewrite-authors \
  --match-field author_email \
  --match-pattern "old@company.com" \
  --name "Alice" --email "alice@new.com" --save

# CLI: catch-all default
git-surgeon rewrite-authors \
  --name "Default" --email "d@example.com" --default --save

# Interactive mode
git-surgeon rewrite-authors -i
```

---

### `git-surgeon scrub`

Scrub sensitive data from commit messages and/or file contents.

```bash
git-surgeon scrub [OPTIONS]
```

| Option | Short | Type | Default | Description |
| --- | --- | --- | --- | --- |
| `--repo` | `-r` | PATH | cwd | Target repository |
| `--find` | | TEXT | | Pattern to find |
| `--replace` | | TEXT | `***REMOVED***` | Replacement text |
| `--messages` | | flag | off | Scrub commit messages only |
| `--blobs` | | flag | off | Scrub file contents only |
| `--regex` | | flag | off | Treat find as regex |
| `--save` / `--no-save` | | flag | save | Save to config |
| `--execute` | `-x` | flag | off | Execute immediately |
| `--interactive` | `-i` | flag | off | Interactive mode |
| `--dry-run` | `-n` | flag | off | Preview only |
| `--force` | `-f` | flag | off | Skip confirmation |

If neither `--messages` nor `--blobs` is specified, both are scrubbed.

**Examples:**

```bash
# Scrub from both messages and files
git-surgeon scrub --find "secret-api-key" --save

# Scrub files only
git-surgeon scrub --find "password=prod123" --blobs --save

# Regex scrub from messages
git-surgeon scrub --find "JIRA-\d+" --replace "[TICKET]" --regex --messages --save
```

---

### `git-surgeon flatten`

Flatten merge commits (linearize history).

```bash
git-surgeon flatten [OPTIONS]
```

| Option | Short | Type | Default | Description |
| --- | --- | --- | --- | --- |
| `--repo` | `-r` | PATH | cwd | Target repository |
| `--save` / `--no-save` | | flag | save | Save to config |
| `--execute` | `-x` | flag | off | Execute immediately |
| `--dry-run` | `-n` | flag | off | Preview only |
| `--force` | `-f` | flag | off | Skip confirmation |

---

### `git-surgeon filter`

Filter (remove/keep) commits matching criteria.

```bash
git-surgeon filter [OPTIONS]
```

| Option | Short | Type | Default | Description |
| --- | --- | --- | --- | --- |
| `--repo` | `-r` | PATH | cwd | Target repository |
| `--field` | | TEXT | `author_name` | Field to match: `author_name`, `author_email`, `subject`, `message`, `date` |
| `--pattern` | `-p` | TEXT | | Pattern to match |
| `--action` | `-a` | TEXT | `remove` | `remove` or `keep` |
| `--regex` | | flag | off | Treat pattern as regex |
| `--save` / `--no-save` | | flag | save | Save to config |
| `--execute` | `-x` | flag | off | Execute immediately |
| `--interactive` | `-i` | flag | off | Interactive mode |
| `--dry-run` | `-n` | flag | off | Preview only |
| `--force` | `-f` | flag | off | Skip confirmation |

**Examples:**

```bash
# Remove dependabot commits
git-surgeon filter --field author_name --pattern "dependabot" --save

# Keep only one author's commits
git-surgeon filter --field author_email --pattern "alice@co.com" --action keep --save
```

---

### `git-surgeon undo`

Restore the repository from the backup bundle created by the last `run`.

```bash
git-surgeon undo [OPTIONS]
```

| Option | Short | Type | Default | Description |
| --- | --- | --- | --- | --- |
| `--repo` | `-r` | PATH | cwd | Target repository |
| `--force` | `-f` | flag | off | Skip confirmation |

**What it does:**
1. Checks for `.git-surgeon/backup.bundle`
2. Shows backup info (size, original HEAD)
3. Prompts for confirmation
4. Fetches all refs from the bundle
5. Resets HEAD to the pre-rewrite state

---

## Common Patterns

### Save now, execute later

```bash
git-surgeon rewrite-authors --name "X" --email "x@y.com" --default --save
git-surgeon scrub --find "secret" --save
git-surgeon flatten --save
git-surgeon preview    # review everything
git-surgeon run        # execute all at once
```

### One-shot execution

```bash
git-surgeon flatten --execute --force
```

### Dry run everything

```bash
git-surgeon --dry-run run
# or
git-surgeon run --dry-run
```
