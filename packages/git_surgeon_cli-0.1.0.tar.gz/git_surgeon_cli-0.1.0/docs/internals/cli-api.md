# CLI & Utils API

Module-level API reference for `git_surgeon.cli` and `git_surgeon.utils`.

---

## CLI Entry Point

**Module:** `git_surgeon.cli.app`

### `app` — Typer application

```python
app = typer.Typer(
    name="git-surgeon",
    invoke_without_command=True,
    no_args_is_help=False,
    rich_markup_mode="rich",
)
```

Key behaviors:
- `invoke_without_command=True` — the callback fires even when no subcommand is given
- `no_args_is_help=False` — running `git-surgeon` alone launches the wizard (not help)

### `main()` — Global callback

```python
@app.callback()
def main(ctx, repo, dry_run, force, verbose) -> None
```

Stores global options in `ctx.obj` (a `dict`):
```python
ctx.obj = {
    "repo": Path | None,
    "dry_run": bool,
    "force": bool,
    "verbose": bool,
}
```

If `ctx.invoked_subcommand is None` (no subcommand provided), imports and calls `run_wizard()`.

### Registered subcommands

```python
app.command(name="init")(init.init_cmd)
app.command(name="run")(run.run_cmd)
app.command(name="preview")(preview.preview_cmd)
app.command(name="rewrite-authors")(rewrite_authors.rewrite_authors_cmd)
app.command(name="scrub")(scrub.scrub_cmd)
app.command(name="flatten")(flatten.flatten_cmd)
app.command(name="filter")(filter_commits.filter_cmd)
app.command(name="undo")(undo.undo_cmd)
```

---

## Wizard

**Module:** `git_surgeon.cli.wizard`

### `run_wizard(repo, dry_run, force) -> None`

Interactive 6-step flow:

1. **Find repo** — `find_repo_root(repo)`, show commit count
2. **Select operations** — numbered menu (1-5), comma-separated selection
3. **Configure** — calls private `_configure_*()` functions per operation
4. **Preview** — creates `Engine(dry_run=True)`, validates, shows preview
5. **Save** — optionally saves config and updates `.gitignore`
6. **Execute** — if not dry_run, prompts and runs `engine.run()`

### Private configuration functions

| Function | Returns | Prompts for |
| --- | --- | --- |
| `_configure_author_rewrite()` | `AuthorRewrite \| None` | Default?, name, email, match_field, pattern, regex?, add more? |
| `_configure_message_scrub()` | `MessageScrub \| None` | Find, replace, regex?, add more? |
| `_configure_blob_scrub()` | `BlobScrub \| None` | Find, replace, regex?, add more? |
| `_configure_commit_filter()` | `CommitFilter \| None` | Field, pattern, action, regex?, add more? |

Each loops with "Add another?" until the user declines.

---

## Command Modules

**Location:** `git_surgeon.cli.commands.*`

All command functions follow a consistent pattern:

```python
def command_name(
    repo: Path = typer.Option(None, "--repo", "-r"),
    # ... command-specific options ...
    dry_run: bool = typer.Option(False, "--dry-run", "-n"),
    force: bool = typer.Option(False, "--force", "-f"),
) -> None:
    # 1. Resolve repo path
    # 2. Load or create config
    # 3. Create operation from CLI args
    # 4. Validate
    # 5. Preview
    # 6. Optionally save config
    # 7. Optionally execute
```

### `init.init_cmd`

```python
def init_cmd(
    repo: Path | None,
    template: bool = True,   # --template / --no-template
) -> None
```

- Creates `.git-surgeon/` directory
- Writes config.toml (template or empty `[general]\n`)
- Calls `ensure_gitignore()`

### `run.run_cmd`

```python
def run_cmd(
    repo: Path | None,
    dry_run: bool,
    force: bool,
    skip_backup: bool = False,
) -> None
```

- Loads config via `Config.load()`
- Creates `Engine.from_config()`
- Shows preview always
- If not dry_run: confirms (unless force), runs engine

### `preview.preview_cmd`

```python
def preview_cmd(repo: Path | None) -> None
```

- Loads config, creates engine with `dry_run=True`
- Shows preview and exits

### `rewrite_authors.rewrite_authors_cmd`

```python
def rewrite_authors_cmd(
    repo, match_field, match_pattern, name, email,
    default, regex, save, execute, interactive,
    dry_run, force,
) -> None
```

- Interactive mode: delegates to `_configure_author_rewrite()` from wizard
- CLI mode: creates `AuthorRule` from flags, wraps in `AuthorRewrite`
- `--save`: appends to config file (loads existing, adds operation, saves)
- `--execute`: save + run engine immediately

### `scrub.scrub_cmd`

```python
def scrub_cmd(
    repo, find, replace, messages, blobs,
    regex, save, execute, interactive,
    dry_run, force,
) -> None
```

- If neither `--messages` nor `--blobs`: creates both `MessageScrub` and `BlobScrub`
- `--messages` only: creates `MessageScrub`
- `--blobs` only: creates `BlobScrub`

### `flatten.flatten_cmd`

```python
def flatten_cmd(
    repo, save, execute, dry_run, force,
) -> None
```

- Creates `MergeFlatten(enabled=True)`
- No interactive mode (it's a boolean toggle)

### `filter_commits.filter_cmd`

```python
def filter_cmd(
    repo, field, pattern, action,
    regex, save, execute, interactive,
    dry_run, force,
) -> None
```

- Creates `FilterRule` from flags, wraps in `CommitFilter`

### `undo.undo_cmd`

```python
def undo_cmd(repo, force) -> None
```

- Checks `has_backup()`, shows `get_backup_info()`
- Prompts for confirmation (unless force)
- Calls `restore_backup()`

---

## Display Utils

**Module:** `git_surgeon.utils.display`

Rich-powered console output helpers. All functions use shared `Console` instances:

```python
console = Console()                # stdout
error_console = Console(stderr=True)  # stderr
```

### Functions

| Function | Signature | Description |
| --- | --- | --- |
| `print_banner()` | `() -> None` | Prints "🔪 git-surgeon" with styling |
| `print_preview(preview)` | `(dict) -> None` | Full preview output (table + callback + patterns) |
| `print_success(message)` | `(str) -> None` | Green checkmark + message |
| `print_error(message)` | `(str) -> None` | Red X + message (to stderr) |
| `print_warning(message)` | `(str) -> None` | Yellow warning + message |
| `print_info(message)` | `(str) -> None` | Blue info + message |
| `print_validation_errors(errors)` | `(dict[str, list[str]]) -> None` | Grouped error display |
| `confirm_action(message, default)` | `(str, bool) -> bool` | Rich `Confirm.ask()` wrapper |

### `print_preview()` detail

Renders the preview dict from `Engine.preview()`:

1. **Warnings** — yellow `⚠` for each
2. **Summary table** — Rich `Table` with commit count, op count, callback presence, replace-text count
3. **Operations** — each `describe()` output, indented
4. **Callback** — `Rich.Syntax` panel with Python highlighting and line numbers
5. **Replace-text** — dimmed list of patterns

### `confirm_action()` note

Uses `rich.prompt.Confirm.ask()` which renders a `[y/N]` or `[Y/n]` prompt based on the `default` parameter. Returns `bool`.
