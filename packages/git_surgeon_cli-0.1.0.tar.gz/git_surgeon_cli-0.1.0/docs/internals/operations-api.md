# Operations API

Module-level API reference for `git_surgeon.operations`.

## Package: `git_surgeon.operations`

**Location:** `src/git_surgeon/operations/__init__.py`

Re-exports all public classes:

```python
from git_surgeon.operations import (
    Operation,       # ABC
    AuthorRewrite,   # + AuthorRule
    MessageScrub,    # + MessageReplacement
    BlobScrub,       # + BlobReplacement
    MergeFlatten,
    CommitFilter,    # + FilterRule
)
```

---

## `Operation` (Abstract Base Class)

**Module:** `git_surgeon.operations.base`

The contract that every operation must implement. The engine and callback builder interact exclusively through this interface.

### Abstract methods (must implement)

| Method | Signature | Returns | Purpose |
| --- | --- | --- | --- |
| `name` | `@property` | `str` | Human-readable name for display |
| `validate()` | `() -> list[str]` | Error messages | Return empty list if valid |
| `describe()` | `() -> str` | Summary string | Used in preview output |
| `generate_callback_code()` | `() -> str \| None` | Python code or None | Per-commit callback snippet |
| `to_config()` | `() -> dict[str, Any]` | TOML-serializable dict | Must include `"type"` key |
| `from_config()` | `@classmethod (data) -> Operation` | Instance | Deserialize from TOML dict |

### Concrete methods (may override)

| Method | Default | Purpose |
| --- | --- | --- |
| `priority` | `50` | Execution order (lower = first) |
| `generate_replace_text_entries()` | `[]` | Blob replacement patterns |

### Priority convention

```
10 — MergeFlatten   (structural changes first)
20 — MessageScrub   (clean messages before matching)
30 — AuthorRewrite  (match on cleaned messages)
40 — CommitFilter   (filter after all transforms)
50 — BlobScrub      (separate mechanism: --replace-text)
```

### Callback code contract

Code returned by `generate_callback_code()` must:
- Be valid Python 3 code
- Reference `commit` as the variable (provided by git-filter-repo)
- Use `b'...'` for all string comparisons (commit fields are bytes)
- Not import from `git_surgeon` (runs in git-filter-repo's sandbox)
- Be safe to concatenate with other operations' code (no conflicting variable names — use `_` prefixed locals)

---

## `AuthorRewrite`

**Module:** `git_surgeon.operations.author_rewrite`

### `AuthorRule` (dataclass)

```python
@dataclass
class AuthorRule:
    match_field: str = "subject"    # subject|author_name|author_email|body|message|all
    match_pattern: str = ""         # text to match (exact or regex)
    new_name: str = ""              # new author name
    new_email: str = ""             # new author email
    is_regex: bool = False          # treat match_pattern as regex
    is_default: bool = False        # catch-all rule (ignores match_field/pattern)
```

**Methods:**
- `to_dict() -> dict[str, Any]` — serializes to config-ready dict (omits match fields for default rules)
- `from_dict(data) -> AuthorRule` — classmethod, deserializes

### `AuthorRewrite(Operation)`

```python
class AuthorRewrite(Operation):
    def __init__(self, rules: list[AuthorRule] | None = None) -> None
```

| Method | Notes |
| --- | --- |
| `add_rule(rule)` | Appends an `AuthorRule` |
| `validate()` | Checks: ≥1 rule, ≤1 default, required fields present, valid match_field |
| `describe()` | Multi-line summary of all rules |
| `generate_callback_code()` | See optimization notes below |
| `priority` | `30` |

**Callback optimizations:**

1. **Subject-exact set matching** — rules with `match_field="subject"` and `is_regex=False` are grouped by target author. Each group gets a Python `set` for O(1) lookup instead of linear `if/elif` chains.

2. **Variable naming** — uses `_subject`, `_author_matched`, `_author_set_N` to avoid collisions with other operations' code.

3. **Evaluation order** — specific rules checked first, default (catch-all) applied only if `_author_matched` is still `False`.

### Helper: `_field_expression(match_field: str) -> str`

Maps field names to Python expressions accessing the `commit` object:

```python
{
    "subject": 'commit.message.split(b"\\n")[0].strip()',
    "author_name": "commit.author_name",
    "author_email": "commit.author_email",
    "body": 'b"\\n".join(commit.message.split(b"\\n")[1:])',
    "message": "commit.message",
    "all": 'commit.message + b" " + commit.author_name + b" " + commit.author_email',
}
```

---

## `MessageScrub`

**Module:** `git_surgeon.operations.message_scrub`

### `MessageReplacement` (dataclass)

```python
@dataclass
class MessageReplacement:
    find: str           # pattern to find
    replace: str        # replacement text
    is_regex: bool = False
```

**Methods:** `to_dict()`, `from_dict(data)` — standard serialization.

### `MessageScrub(Operation)`

```python
class MessageScrub(Operation):
    def __init__(self, replacements: list[MessageReplacement] | None = None) -> None
```

| Method | Notes |
| --- | --- |
| `add_replacement(find, replace, *, is_regex)` | Convenience builder |
| `validate()` | Checks: ≥1 replacement, non-empty find |
| `generate_callback_code()` | Uses `msg.replace()` for literals, `_re.sub()` for regex |
| `generate_replace_text_entries()` | Returns `[]` (messages use callback, not replace-text) |
| `priority` | `20` |

**Callback structure:**

```python
# --- Message Scrub ---
msg = commit.message
import re as _re         # only if regex rules exist
msg = msg.replace(b'...', b'...')
msg = _re.sub(b'...', b'...', msg)
commit.message = msg
```

---

## `BlobScrub`

**Module:** `git_surgeon.operations.blob_scrub`

### `BlobReplacement` (dataclass)

```python
@dataclass
class BlobReplacement:
    find: str
    replace: str = "***REMOVED***"
    is_regex: bool = False
```

### `BlobScrub(Operation)`

```python
class BlobScrub(Operation):
    def __init__(self, replacements: list[BlobReplacement] | None = None) -> None
```

| Method | Notes |
| --- | --- |
| `add_replacement(find, replace, *, is_regex)` | Convenience builder |
| `generate_callback_code()` | Always returns `None` |
| `generate_replace_text_entries()` | Returns `["literal==>replacement", ...]` lines |
| `priority` | `50` |

**Replace-text format:**

```
find_text==>replace_text           # literal match
regex:pattern==>replace_text       # regex match
```

These lines are written to a temp file and passed to `git-filter-repo --replace-text`.

---

## `MergeFlatten`

**Module:** `git_surgeon.operations.merge_flatten`

```python
class MergeFlatten(Operation):
    def __init__(self, enabled: bool = True) -> None
```

The simplest operation — boolean toggle, no sub-rules.

| Method | Notes |
| --- | --- |
| `validate()` | Always returns `[]` |
| `generate_callback_code()` | Returns `None` if disabled; otherwise the 3-line flatten snippet |
| `priority` | `10` |

---

## `CommitFilter`

**Module:** `git_surgeon.operations.commit_filter`

### `FilterRule` (dataclass)

```python
@dataclass
class FilterRule:
    field: str             # author_name|author_email|subject|message|date
    pattern: str           # text or regex
    action: str = "remove" # "remove"|"keep"
    is_regex: bool = False
```

### `CommitFilter(Operation)`

```python
class CommitFilter(Operation):
    def __init__(self, rules: list[FilterRule] | None = None) -> None
```

| Method | Notes |
| --- | --- |
| `add_rule(rule)` | Appends a `FilterRule` |
| `validate()` | Checks: ≥1 rule, valid field, valid action, non-empty pattern |
| `generate_callback_code()` | Uses `commit.skip()` for removal |
| `priority` | `40` |

**Callback behavior by action:**
- `action="remove"`: `if match: commit.skip()`
- `action="keep"`: `if not match: commit.skip()`

### Helper: `_filter_field_expression(field: str) -> str`

Maps field names to Python expressions (same pattern as author rewrite, but includes `"date"` → `commit.author_date`).
