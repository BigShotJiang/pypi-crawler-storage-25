# Internals

This subfolder contains module-level API documentation for contributors. If you're adding a new operation, fixing a bug, or extending git-surgeon, start here.

## Contents

| Document | Covers |
| --- | --- |
| [operations-api.md](operations-api.md) | `Operation` ABC, all 5 concrete operations, dataclasses, helper functions |
| [core-api.md](core-api.md) | `Engine`, `CallbackBuilder`, `Config`, `Safety`, `Repo` modules |
| [cli-api.md](cli-api.md) | `app.py`, `wizard.py`, all 8 command modules, `display.py` utils |

## Quick Links for Common Tasks

**Adding a new operation:**
1. Read [operations-api.md](operations-api.md) for the `Operation` ABC contract
2. Read [core-api.md](core-api.md) → Config section for the operation registry
3. Read [cli-api.md](cli-api.md) for adding a new subcommand

**Debugging a callback:**
1. Run `git-surgeon preview` — it prints the composed callback
2. Check `.git-surgeon/last-callback.py` after a run
3. Read [core-api.md](core-api.md) → CallbackBuilder for how snippets are merged

**Changing config format:**
1. Read [core-api.md](core-api.md) → Config section
2. Check `to_config()` / `from_config()` on the relevant operation in [operations-api.md](operations-api.md)
