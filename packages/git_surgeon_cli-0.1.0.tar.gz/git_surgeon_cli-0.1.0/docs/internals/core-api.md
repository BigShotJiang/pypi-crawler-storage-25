# Core API

Module-level API reference for `git_surgeon.core`.

---

## `Engine`

**Module:** `git_surgeon.core.engine`

The central orchestrator. Validates operations, composes callbacks, manages backups, and invokes `git-filter-repo`.

### `EngineError(Exception)`

Raised when the engine encounters a fatal error (validation failure, subprocess error, missing git-filter-repo).

### `Engine`

```python
class Engine:
    def __init__(
        self,
        repo_path: Path,
        operations: list[Operation] | None = None,
        dry_run: bool = False,
        force: bool = False,
        skip_backup: bool = False,
    ) -> None
```

#### Factory

```python
@classmethod
def from_config(
    cls,
    config: Config,
    repo_path: Path,
    *,
    dry_run: bool = False,
    force: bool = False,
    skip_backup: bool = False,
) -> Engine
```

Creates an engine from a loaded `Config` instance. The config's operations list is passed directly.

#### Methods

| Method | Signature | Returns | Description |
| --- | --- | --- | --- |
| `add_operation` | `(op: Operation) -> None` | — | Appends an operation |
| `validate` | `() -> dict[str, list[str]]` | `{name: [errors]}` | Calls `.validate()` on each operation |
| `preview` | `() -> dict` | Preview data dict | Non-destructive; builds callback and collects metadata |
| `run` | `() -> None` | — | Full execution (backup + rewrite). Raises `EngineError` on failure |

#### `preview()` return value

```python
{
    "commit_count": int,           # from git rev-list --count --all
    "operations": list[str],       # op.describe() for each
    "callback": str | None,        # merged callback or "(none ...)"
    "replace_text": list[str],     # replace-text entries
    "warnings": list[str],         # repo validation warnings
}
```

#### `run()` execution flow

1. Validates all operations → raises `EngineError` if any fail
2. Builds callback via `CallbackBuilder`
3. Collects replace-text entries
4. Saves callback to `.git-surgeon/last-callback.py` (for debugging)
5. If `dry_run`: returns early
6. Creates backup bundle via `safety.create_backup()` (unless `skip_backup`)
7. Builds subprocess command:
   ```
   python -m git_filter_repo --force [--commit-callback CODE] [--replace-text FILE]
   ```
8. Writes replace-text entries to a temp file if any exist
9. Runs subprocess, captures output
10. Cleans up temp file in `finally` block
11. Raises `EngineError` if exit code ≠ 0 or if `FileNotFoundError` (git-filter-repo missing)

---

## `CallbackBuilder`

**Module:** `git_surgeon.core.callback_builder`

Composes multiple operations' callback code into a single script.

```python
class CallbackBuilder:
    def __init__(self, operations: list[Operation]) -> None
```

The constructor **sorts operations by priority** (ascending). All subsequent calls use this sorted order.

#### Methods

| Method | Returns | Description |
| --- | --- | --- |
| `build()` | `str \| None` | Merged callback string (snippets joined by `\n\n`) or `None` if no operations produce callback code |
| `build_replace_text()` | `list[str]` | Concatenation of all operations' `generate_replace_text_entries()` results |

#### `build()` algorithm

```
1. For each operation (sorted by priority):
     code = op.generate_callback_code()
     if code is not None:
         append to snippets list
2. If no snippets: return None
3. Return "\n\n".join(snippets) + "\n"
```

The trailing `\n` ensures the script ends with a newline.

---

## `Config`

**Module:** `git_surgeon.core.config`

Manages TOML configuration for operations.

### Constants

```python
CONFIG_DIR_NAME = ".git-surgeon"
CONFIG_FILE_NAME = "config.toml"
CALLBACK_DEBUG_NAME = "last-callback.py"
BACKUP_BUNDLE_NAME = "backup.bundle"
PRE_REWRITE_HEAD_NAME = "pre-rewrite-head"
```

These constants are used by `Engine`, `Safety`, and CLI commands. Import them from `git_surgeon.core.config`.

### Operation Registry

```python
_OPERATION_REGISTRY: dict[str, type[Operation]] = {
    "author_rewrite": AuthorRewrite,
    "message_scrub": MessageScrub,
    "blob_scrub": BlobScrub,
    "merge_flatten": MergeFlatten,
    "commit_filter": CommitFilter,
}
```

Maps `type` strings in TOML to operation classes. To add a new operation, register it here.

### `Config`

```python
class Config:
    def __init__(
        self,
        operations: list[Operation] | None = None,
        general: dict[str, Any] | None = None,
    ) -> None
```

#### Classmethods

| Method | Signature | Returns | Description |
| --- | --- | --- | --- |
| `config_dir` | `(repo_path: Path) -> Path` | `.git-surgeon/` path | Convenience accessor |
| `config_file` | `(repo_path: Path) -> Path` | `config.toml` path | Convenience accessor |
| `load` | `(repo_path: Path) -> Config` | Loaded config | Reads TOML, deserializes operations via registry |

#### Instance methods

| Method | Signature | Returns | Description |
| --- | --- | --- | --- |
| `save` | `(repo_path: Path) -> Path` | Config file path | Writes TOML, creates dir if needed |
| `add_operation` | `(op: Operation) -> None` | — | Appends to operations list |
| `get_operations_by_type` | `(op_type: type) -> list[Operation]` | Filtered list | `isinstance` check |
| `validate_all` | `() -> dict[str, list[str]]` | `{name: [errors]}` | Same as Engine.validate |

#### Static methods

| Method | Returns | Description |
| --- | --- | --- |
| `generate_template()` | `str` | Commented TOML template for new users |

#### `load()` deserialization flow

```
1. Read .git-surgeon/config.toml with tomllib.load()
2. Extract data["general"] → self.general
3. For each block in data["operations"]:
     a. Read type = block["type"]
     b. Look up class in _OPERATION_REGISTRY
     c. Call class.from_config(block)
     d. Append to operations list
4. Unknown types are silently skipped
```

#### `save()` serialization flow

```
1. Create .git-surgeon/ directory
2. Build dict:
     {"general": {...}, "operations": [op.to_config() for op]}
3. Write with tomli_w.dump()
```

---

## `Safety`

**Module:** `git_surgeon.core.safety`

Backup and restore functions using git bundles.

### `BackupError(Exception)`

Raised when backup/restore operations fail (subprocess errors).

### Functions

#### `create_backup(repo_path: Path) -> Path`

1. Creates `.git-surgeon/` directory if needed
2. Records current HEAD SHA to `.git-surgeon/pre-rewrite-head`
3. Runs `git bundle create .git-surgeon/backup.bundle --all`
4. Returns bundle path
5. Raises `BackupError` if `git bundle create` fails

#### `restore_backup(repo_path: Path) -> None`

1. Checks bundle exists → `BackupError` if not
2. Runs `git fetch <bundle> '*:*' --force` to restore all refs
3. If `pre-rewrite-head` exists, runs `git reset --hard <SHA>`
4. Raises `BackupError` on subprocess failure

#### `has_backup(repo_path: Path) -> bool`

Returns `True` if `.git-surgeon/backup.bundle` exists.

#### `get_backup_info(repo_path: Path) -> dict[str, str]`

Returns:
```python
{
    "bundle_path": str,       # absolute path
    "bundle_size": str,       # e.g. "12.34 MB"
    "original_head": str,     # SHA from pre-rewrite-head
}
```

Only includes keys for files that exist.

---

## `Repo`

**Module:** `git_surgeon.core.repo`

Repository discovery, validation, and `.gitignore` management.

### `RepoError(Exception)`

Raised when the target path is not inside a git repo.

### Functions

#### `find_repo_root(path: Path | None = None) -> Path`

Runs `git rev-parse --show-toplevel` from the given path (or cwd). Returns the repo root as a `Path`. Raises `RepoError` if not in a git repo.

#### `validate_repo(repo_path: Path) -> list[str]`

Returns warnings (not errors):
- "No .git directory found" if `.git/` doesn't exist
- "Repository has uncommitted changes" if `git status --porcelain` has output
- "Could not check repository status" if subprocess fails

#### `get_commit_count(repo_path: Path) -> int`

Runs `git rev-list --count --all`. Returns `0` on error.

#### `get_current_head(repo_path: Path) -> str`

Runs `git rev-parse HEAD`. Returns empty string on error.

#### `ensure_gitignore(repo_path: Path) -> bool`

Ensures `.git-surgeon/` is listed in `.gitignore`:
1. If `.gitignore` exists: checks all lines for the entry, appends if missing
2. If `.gitignore` doesn't exist: creates it with the entry
3. Returns `True` if the file was modified, `False` if already present
