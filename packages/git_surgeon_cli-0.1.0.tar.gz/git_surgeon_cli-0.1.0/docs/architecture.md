# Architecture

This document explains how git-surgeon is designed, how data flows through the system, and how to extend it with new operations.

## High-Level Design

git-surgeon is a **composition layer** over [git-filter-repo](https://github.com/newren/git-filter-repo). Rather than requiring users to write raw Python callbacks, it provides a modular operation system where each operation generates its fragment of callback code. The engine then merges all fragments into a single coherent script and invokes `git-filter-repo` in one pass.

### Design Principles

1. **Single-pass execution** — no matter how many operations are configured, the repo is traversed only once
2. **Pluggable operations** — each operation is an independent module implementing a common interface
3. **Config-as-code** — operations serialize to/from TOML, so configs are portable and version-controllable (though gitignored by default)
4. **Safety first** — automatic backups, confirmation prompts, dry-run by default in the wizard

## System Architecture

```mermaid
graph TB
    subgraph CLI["CLI Layer (Typer)"]
        APP["app.py — Entry Point"]
        WIZ["wizard.py — Interactive Mode"]
        subgraph Commands
            INIT["init"] ; RUN["run"] ; PREVIEW["preview"]
            RA["rewrite-authors"] ; SCRUB["scrub"]
            FLAT["flatten"] ; FILT["filter"] ; UNDO["undo"]
        end
    end

    subgraph Core
        ENGINE["Engine — Orchestrator"]
        CB["CallbackBuilder — Code Composer"]
        CONFIG["Config — TOML Load/Save"]
        SAFETY["Safety — Backup & Undo"]
        REPO["Repo — Discovery & Validation"]
    end

    subgraph Ops["Operations (Pluggable)"]
        BASE["Operation — Abstract Base"]
        AR["AuthorRewrite"] ; MS["MessageScrub"] ; BS["BlobScrub"]
        MF["MergeFlatten"] ; CF["CommitFilter"]
    end

    subgraph External
        GFR["git-filter-repo"]
        GIT["git"]
        FS[".git-surgeon/"]
    end

    APP --> WIZ & Commands
    Commands & WIZ --> ENGINE & CONFIG
    ENGINE --> CB & SAFETY & REPO & GFR
    CONFIG --> FS
    CB --> Ops
    SAFETY & REPO & GFR --> GIT
    AR & MS & BS & MF & CF --> BASE
```

### Layer Responsibilities

| Layer | Package | Role |
| --- | --- | --- |
| **CLI** | `git_surgeon.cli` | User-facing interface (Typer commands, wizard, Rich output) |
| **Core** | `git_surgeon.core` | Business logic: engine orchestration, config I/O, safety, repo utils |
| **Operations** | `git_surgeon.operations` | Pluggable operation modules, each generates callback/replace-text code |
| **Utils** | `git_surgeon.utils` | Display helpers (Rich console, formatting) |

## Data Flow

```mermaid
sequenceDiagram
    actor User
    participant CLI as CLI / Wizard
    participant Engine
    participant CB as CallbackBuilder
    participant Safety
    participant GFR as git-filter-repo

    User->>CLI: git-surgeon run
    CLI->>CLI: Load config.toml
    CLI->>Engine: Create with operations
    Engine->>Engine: Validate all operations
    Engine->>CB: Compose callbacks
    CB->>CB: Sort by priority
    CB-->>Engine: Merged callback string
    Engine->>Engine: Collect replace-text entries

    alt Dry Run
        Engine-->>CLI: Preview data
        CLI-->>User: Show preview table + callback
    else Execute
        Engine->>Safety: create_backup()
        Safety->>Safety: git bundle create
        Safety-->>Engine: backup.bundle path
        Engine->>GFR: subprocess.run(git-filter-repo)
        GFR->>GFR: Rewrite commits
        GFR-->>Engine: Exit code
        Engine-->>CLI: Success/Error
        CLI-->>User: Result + undo instructions
    end
```

### Step-by-step breakdown

1. **User invokes CLI** — either a subcommand (`run`, `rewrite-authors`, etc.) or the wizard
2. **Config loads** — `Config.load()` reads `.git-surgeon/config.toml`, deserializes each `[[operations]]` block into the corresponding `Operation` subclass via the operation registry
3. **Engine created** — receives the list of `Operation` instances plus flags (dry-run, force, etc.)
4. **Validation** — `engine.validate()` calls `.validate()` on each operation, collecting errors
5. **Callback composition** — `CallbackBuilder` sorts operations by priority, calls `.generate_callback_code()` on each, concatenates the snippets
6. **Replace-text collection** — `CallbackBuilder.build_replace_text()` collects all `.generate_replace_text_entries()` results
7. **Backup** — `safety.create_backup()` runs `git bundle create` to save the entire repo state
8. **Execution** — `subprocess.run()` invokes `python -m git_filter_repo` with `--commit-callback` and `--replace-text`
9. **Result** — success or error reported back to the user

## Module Map

```
src/git_surgeon/
├── __init__.py                     # Package version
├── operations/
│   ├── __init__.py                 # Re-exports all operation classes
│   ├── base.py                     # Operation ABC
│   ├── author_rewrite.py           # AuthorRewrite + AuthorRule
│   ├── message_scrub.py            # MessageScrub + MessageReplacement
│   ├── blob_scrub.py               # BlobScrub + BlobReplacement
│   ├── merge_flatten.py            # MergeFlatten
│   └── commit_filter.py            # CommitFilter + FilterRule
├── core/
│   ├── __init__.py
│   ├── engine.py                   # Engine orchestrator
│   ├── callback_builder.py         # CallbackBuilder
│   ├── config.py                   # Config + TOML I/O + registry
│   ├── safety.py                   # Backup/restore functions
│   └── repo.py                     # Repo discovery, .gitignore mgmt
├── cli/
│   ├── __init__.py
│   ├── app.py                      # Typer app + global callback
│   ├── wizard.py                   # Interactive wizard
│   └── commands/
│       ├── __init__.py
│       ├── init.py                 # git-surgeon init
│       ├── run.py                  # git-surgeon run
│       ├── preview.py              # git-surgeon preview
│       ├── rewrite_authors.py      # git-surgeon rewrite-authors
│       ├── scrub.py                # git-surgeon scrub
│       ├── flatten.py              # git-surgeon flatten
│       ├── filter_commits.py       # git-surgeon filter
│       └── undo.py                 # git-surgeon undo
└── utils/
    ├── __init__.py
    └── display.py                  # Rich console helpers
```

## The Operation Abstraction

The central design pattern is the `Operation` abstract base class. Every operation implements:

```python
class Operation(ABC):
    @property
    def name(self) -> str: ...            # Human-readable name
    @property
    def priority(self) -> int: ...        # Execution order (lower = first)

    def validate(self) -> list[str]: ...  # Return error messages
    def describe(self) -> str: ...        # Human-readable summary

    def generate_callback_code(self) -> str | None: ...      # Per-commit Python code
    def generate_replace_text_entries(self) -> list[str]: ... # Blob replacement patterns

    def to_config(self) -> dict[str, Any]: ...                # Serialize to TOML dict
    @classmethod
    def from_config(cls, data: dict[str, Any]) -> Operation: ... # Deserialize
```

### Two mechanisms

Operations contribute to the `git-filter-repo` invocation through two mechanisms:

1. **Commit callback** (`generate_callback_code`) — Python code that runs per-commit. The code has access to a `commit` object with fields like `commit.message`, `commit.author_name`, `commit.parents`, etc. Used by: MergeFlatten, MessageScrub, AuthorRewrite, CommitFilter.

2. **Replace-text** (`generate_replace_text_entries`) — Pattern lines in `git-filter-repo`'s `literal==>replacement` format. These operate on blob (file) content. Used by: BlobScrub.

### Operation registry

The `Config` module maintains a registry mapping type strings to classes:

```python
_OPERATION_REGISTRY = {
    "author_rewrite": AuthorRewrite,
    "message_scrub": MessageScrub,
    "blob_scrub": BlobScrub,
    "merge_flatten": MergeFlatten,
    "commit_filter": CommitFilter,
}
```

This enables TOML deserialization: when `Config.load()` reads `type = "author_rewrite"` from a config block, it looks up the class and calls `AuthorRewrite.from_config(data)`.

## Callback Composition

`CallbackBuilder` is responsible for merging multiple operations' callback snippets into one script. The algorithm:

1. Sort operations by `.priority`
2. Call `.generate_callback_code()` on each
3. Filter out `None` results (e.g., BlobScrub returns None)
4. Join with double newlines
5. Return the complete script

The result is a single Python string passed to `git-filter-repo --commit-callback`. For example, with MergeFlatten + MessageScrub + AuthorRewrite configured:

```python
# --- Merge Flatten ---
if len(commit.parents) > 1:
    commit.parents = [commit.parents[0]]

# --- Message Scrub ---
msg = commit.message
msg = msg.replace(b'OldOrg', b'NewOrg')
commit.message = msg

# --- Author Rewrite ---
_subject = commit.message.split(b"\n")[0].strip()
_author_matched = False
if not _author_matched:
    commit.author_name = b'Maintainer'
    ...
```

## Extending git-surgeon

### Adding a new operation

1. Create `src/git_surgeon/operations/your_operation.py`
2. Implement the `Operation` ABC (all abstract methods)
3. Register in `core/config.py`'s `_OPERATION_REGISTRY`
4. Optionally add a CLI subcommand in `cli/commands/`
5. Add to the wizard's operation selection in `cli/wizard.py`

Example skeleton:

```python
from git_surgeon.operations.base import Operation

class YourOperation(Operation):
    @property
    def name(self) -> str:
        return "Your Operation"

    @property
    def priority(self) -> int:
        return 25  # choose based on execution order needs

    def validate(self) -> list[str]:
        return []  # return error strings

    def describe(self) -> str:
        return "Description for preview"

    def generate_callback_code(self) -> str | None:
        return "# your python code accessing `commit`"

    def to_config(self) -> dict:
        return {"type": "your_operation", ...}

    @classmethod
    def from_config(cls, data: dict) -> "YourOperation":
        return cls(...)
```

### Key constraints

- Callback code runs inside `git-filter-repo`'s sandbox where only the `commit` object is available (plus Python stdlib)
- No imports from `git_surgeon` in callback code — it's a standalone Python string
- The `commit` object API is defined by `git-filter-repo` (see their docs)
- Operations should be stateless and serializable to TOML
