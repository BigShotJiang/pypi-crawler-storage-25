# MCP setup

Use git-surgeon as an MCP server so agents can safely orchestrate history rewrites.

## What is MCP?

MCP (Model Context Protocol) is a standard way for AI agents to call external tools. With MCP, agents can invoke git-surgeon operations like author rewrite, message scrub, blob scrub, and commit filtering.

## Install

Use the optional MCP extra:

- `uv add git-surgeon-cli[mcp]`
- or run on demand with `uvx git-surgeon-cli[mcp]`

## Client setup

### Claude Desktop

Add a server entry to your Claude Desktop MCP config:

```json
{
  "mcpServers": {
    "git-surgeon": {
      "command": "uvx",
      "args": ["git-surgeon-cli[mcp]", "git-surgeon-mcp"]
    }
  }
}
```

### VS Code Copilot

Add to your MCP servers configuration:

```json
{
  "copilot.extensions.mcp.servers": {
    "git-surgeon": {
      "command": "uvx",
      "args": ["git-surgeon-cli[mcp]", "git-surgeon-mcp"]
    }
  }
}
```

### Cursor or other MCP clients

Use the same pattern as Claude Desktop:

```json
{
  "mcpServers": {
    "git-surgeon": {
      "command": "uvx",
      "args": ["git-surgeon-cli[mcp]", "git-surgeon-mcp"]
    }
  }
}
```

## Example workflow

1. Ask the agent to preview changes using a describe tool.
2. Review the summary and warnings.
3. Ask the agent to execute the operation.

Example prompt:

"Preview and then scrub all .env secrets from this repo history."

## Safety notes

- Each destructive tool has a paired describe tool for preview.
- Backups are created before any destructive run.
- You can restore with `undo_last_operation`.

## Troubleshooting

- If the server fails to start, ensure `uvx` is installed and on your PATH.
- If you see import errors, upgrade to the latest `git-surgeon-cli[mcp]`.
- If you are not in a git repo, use `validate_repository` to confirm the path.
