# git-surgeon Documentation

Welcome to the `git-surgeon` documentation!

| Document | What's inside |
| --- | --- |
| [Getting Started](getting-started.md) | Installation, first run, tutorial walkthrough |
| [Architecture](architecture.md) | System design, data flow, extension guide |
| [Operations Guide](operations.md) | Deep dive into each operation type with examples |
| [Configuration](configuration.md) | Config file format, schema, and examples |
| [CLI Reference](cli-reference.md) | Every command, flag, and option |
| [Safety & Undo](safety-and-undo.md) | Backup mechanism, restore, and risk mitigation |
| [API Internals](internals/README.md) | Module-level API docs for contributors |
