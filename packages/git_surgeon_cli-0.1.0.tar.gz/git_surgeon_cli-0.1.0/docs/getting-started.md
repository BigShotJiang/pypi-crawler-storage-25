# Getting Started

This guide walks you through installing git-surgeon, running your first rewrite, and understanding the basic workflow.

## Prerequisites

- **Python ≥ 3.13** — [download](https://www.python.org/downloads/)
- **git** — must be on your system PATH
- **git-filter-repo** — installed automatically as a dependency

## Installation

### From PyPI (recommended)

```bash
pip install git-surgeon
```

### From source (development)

```bash
git clone https://github.com/Raghav-56/git-surgeon.git
cd git-surgeon
uv sync   # or: pip install -e .
```

Verify the installation:

```bash
git-surgeon --help
```

## Core Concepts

Before diving in, understand these three ideas:

1. **Operations** — modular units of work (rewrite authors, scrub messages, etc.). Each operation knows how to generate the code that `git-filter-repo` will execute.

2. **Config** — operations are saved to `.git-surgeon/config.toml` inside the target repo. This directory is automatically added to `.gitignore` so private data (emails, secrets) never gets committed.

3. **Single-pass execution** — all operations are composed into one `git-filter-repo` invocation. No matter how many operations you configure, history is traversed only once.

## Your First Rewrite

### Step 1 — Initialize

Navigate to the git repo you want to rewrite and initialize git-surgeon:

```bash
cd /path/to/your/repo
git-surgeon init
```

This creates:

```
your-repo/
├── .git-surgeon/
│   └── config.toml    ← operation definitions go here
└── .gitignore          ← .git-surgeon/ added automatically
```

### Step 2 — Add operations

You can add operations via CLI flags or interactively.

**CLI approach:**

```bash
# Set a default author for all commits
git-surgeon rewrite-authors \
  --name "Your Name" \
  --email "you@example.com" \
  --default \
  --save

# Scrub a secret from commit messages AND file contents
git-surgeon scrub \
  --find "old-api-key-abc123" \
  --replace "***REMOVED***" \
  --save
```

**Interactive approach:**

```bash
git-surgeon rewrite-authors --interactive
git-surgeon scrub --interactive
```

Each `--save` flag writes the operation to `.git-surgeon/config.toml`.

### Step 3 — Preview

Always preview before executing:

```bash
git-surgeon preview
```

This shows:
- A summary table (commit count, operations, replace-text rules)
- The exact Python callback code that will run per commit
- All blob replacement patterns

You can also use `--dry-run` on any command:

```bash
git-surgeon run --dry-run
```

### Step 4 — Execute

```bash
git-surgeon run
```

What happens:
1. A backup bundle is created at `.git-surgeon/backup.bundle`
2. You're prompted for confirmation (skip with `--force`)
3. `git-filter-repo` rewrites all commits in a single pass
4. The generated callback is saved to `.git-surgeon/last-callback.py` for inspection

### Step 5 — Undo (if needed)

```bash
git-surgeon undo
```

This restores the entire repository to its pre-rewrite state from the bundle.

## Interactive Wizard

Running `git-surgeon` with no arguments launches the interactive wizard:

```bash
git-surgeon
```

The wizard walks you through:
1. Selecting which operations to perform (checkboxes)
2. Configuring each selected operation with prompts
3. Previewing the composed callback and changes
4. Optionally saving the config for later re-use
5. Executing (with confirmation)

This is the easiest way to get started if you're unsure which CLI flags to use.

## Typical Workflows

### Reattributing commits after a team change

```bash
git-surgeon init
git-surgeon rewrite-authors --name "Alice" --email "alice@newco.com" \
  --match-field author_email --match-pattern "alice@oldco.com" --save
git-surgeon rewrite-authors --name "Bob" --email "bob@newco.com" \
  --match-field author_email --match-pattern "bob@oldco.com" --save
git-surgeon run
```

### Removing secrets that were accidentally committed

```bash
git-surgeon init
git-surgeon scrub --find "AKIA1234567890ABCDEF" --save
git-surgeon scrub --find "password=hunter2" --save
git-surgeon run
```

### Cleaning up a fork before open-sourcing

```bash
git-surgeon init
git-surgeon rewrite-authors --name "Maintainer" --email "oss@company.com" --default --save
git-surgeon scrub --find "internal-jira.company.com" --replace "***REMOVED***" --save
git-surgeon scrub --find "private-slack-webhook-url" --save
git-surgeon flatten --save
git-surgeon filter --field author_name --pattern "dependabot" --action remove --save
git-surgeon preview
git-surgeon run
```

## Next Steps

- [Operations Guide](operations.md) — deep dive into each operation
- [Configuration Reference](configuration.md) — config file format and schema
- [CLI Reference](cli-reference.md) — every command and flag
- [Safety & Undo](safety-and-undo.md) — how backups work
