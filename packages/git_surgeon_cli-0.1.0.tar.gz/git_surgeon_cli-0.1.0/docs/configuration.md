# Configuration Reference

git-surgeon stores its configuration in `.git-surgeon/config.toml` inside the target repository. This directory is automatically added to `.gitignore` to prevent private data from being published.

## Directory Structure

```
your-repo/
├── .git-surgeon/                ← auto-gitignored
│   ├── config.toml              ← operation definitions
│   ├── last-callback.py         ← generated callback (debug, after run)
│   ├── backup.bundle            ← pre-rewrite backup (after run)
│   └── pre-rewrite-head         ← original HEAD SHA (after run)
├── .gitignore                   ← .git-surgeon/ added here
└── ... (your repo files)
```

## File Descriptions

| File | Created By | Purpose |
| --- | --- | --- |
| `config.toml` | `git-surgeon init` or `--save` | Defines all operations to execute |
| `last-callback.py` | `git-surgeon run` | The exact Python callback that was passed to git-filter-repo (for debugging) |
| `backup.bundle` | `git-surgeon run` | Git bundle containing all refs pre-rewrite (for undo) |
| `pre-rewrite-head` | `git-surgeon run` | Text file with the HEAD SHA before rewrite |

## Config File Format

The config uses [TOML](https://toml.io/) format with two sections:

### `[general]` — Global settings

```toml
[general]
# Currently unused, reserved for future options
# target_repo = "."
```

### `[[operations]]` — Operation list

Each `[[operations]]` block defines one operation. The `type` field determines which operation class handles it.

#### Available types

| Type string | Operation class | Description |
| --- | --- | --- |
| `author_rewrite` | `AuthorRewrite` | Reattribute commit authors |
| `message_scrub` | `MessageScrub` | Find-replace in commit messages |
| `blob_scrub` | `BlobScrub` | Find-replace in file contents |
| `merge_flatten` | `MergeFlatten` | Linearize merge history |
| `commit_filter` | `CommitFilter` | Remove/keep commits by criteria |

## Complete Schema

### `merge_flatten`

```toml
[[operations]]
type = "merge_flatten"
enabled = true           # boolean, default: true
```

### `message_scrub`

```toml
[[operations]]
type = "message_scrub"

[[operations.replacements]]
find = "old-text"        # required: pattern to find
replace = "new-text"     # required: replacement text
is_regex = false         # optional, default: false
```

Multiple `[[operations.replacements]]` blocks can be added under one `message_scrub` operation.

### `author_rewrite`

```toml
[[operations]]
type = "author_rewrite"

# Matching rule
[[operations.rules]]
match_field = "subject"      # required: subject|author_name|author_email|message|body|all
match_pattern = "feat: X"    # required for non-default rules
new_name = "Alice"           # required: new author name
new_email = "a@example.com"  # required: new author email
is_regex = false             # optional, default: false

# Default (catch-all) rule
[[operations.rules]]
is_default = true            # marks this as catch-all
new_name = "Default"
new_email = "d@example.com"
```

Rules are evaluated in order. The first match wins. At most one default rule is allowed.

### `blob_scrub`

```toml
[[operations]]
type = "blob_scrub"

[[operations.replacements]]
find = "secret-value"        # required: pattern to find in file contents
replace = "***REMOVED***"    # optional, default: "***REMOVED***"
is_regex = false             # optional, default: false
```

### `commit_filter`

```toml
[[operations]]
type = "commit_filter"

[[operations.rules]]
field = "author_name"        # required: author_name|author_email|subject|message|date
pattern = "bot-name"         # required: text or regex to match
action = "remove"            # required: "remove"|"keep"
is_regex = false             # optional, default: false
```

## Example: Full Config

```toml
[general]

# Linearize history
[[operations]]
type = "merge_flatten"
enabled = true

# Rename organization in commit messages
[[operations]]
type = "message_scrub"
[[operations.replacements]]
find = "AcmeCorp"
replace = "NewCorp"
[[operations.replacements]]
find = "acme-internal.slack.com"
replace = "***REMOVED***"

# Reattribute authors
[[operations]]
type = "author_rewrite"
[[operations.rules]]
match_field = "author_email"
match_pattern = "alice@acme.com"
new_name = "Alice Johnson"
new_email = "alice@newcorp.com"
[[operations.rules]]
is_default = true
new_name = "Team NewCorp"
new_email = "engineering@newcorp.com"

# Remove API keys from source files
[[operations]]
type = "blob_scrub"
[[operations.replacements]]
find = "AKIA[A-Z0-9]{16}"
replace = "***AWS_KEY_REMOVED***"
is_regex = true
[[operations.replacements]]
find = "password=prodpass123"
replace = "password=***REMOVED***"

# Remove dependabot commits
[[operations]]
type = "commit_filter"
[[operations.rules]]
field = "author_name"
pattern = "dependabot"
action = "remove"
```

## Managing Config

### Creating

```bash
git-surgeon init                    # creates template config
git-surgeon init --no-template      # creates empty config
```

### Adding operations via CLI

Every subcommand with `--save` appends to the config:

```bash
git-surgeon scrub --find "secret" --save
git-surgeon rewrite-authors --name "X" --email "x@y.com" --default --save
```

### Manual editing

Edit `.git-surgeon/config.toml` directly in any text editor. Run `git-surgeon preview` to validate.

### Security

The `.git-surgeon/` directory is automatically added to `.gitignore` on `git-surgeon init`. This means:

- Author emails in config never get committed
- Sensitive patterns (find strings) stay local
- Backup bundles (which contain the original history) stay local
- The generated callback (which may embed patterns) stays local

**Always verify** `.git-surgeon/` is in your `.gitignore` before pushing.
