#
# Licensed to the Apache Software Foundation (ASF) under one
# or more contributor license agreements.  See the NOTICE file
# distributed with this work for additional information
# regarding copyright ownership.  The ASF licenses this file
# to you under the Apache License, Version 2.0 (the
# "License"); you may not use this file except in compliance
# with the License.  You may obtain a copy of the License at
#
#   https://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing,
# software distributed under the License is distributed on an
# "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
# KIND, either express or implied.  See the License for the
# specific language governing permissions and limitations
# under the License.
#

"""Veculo Python SDK — managed graph+vector database client."""

from veculo.client import VeculoClient
from veculo.embeddings import (
    EmbeddingProvider,
    OpenAIEmbeddings,
    SentenceTransformerEmbeddings,
    VertexAIEmbeddings,
)
from veculo.errors import AuthenticationError, NotFoundError, ValidationError, VeculoError
from veculo.models import Edge, JobList, JobStatus, QueryResult, VectorResult, Vertex

__version__ = "0.2.11"

__all__ = [
    "VeculoClient",
    "EmbeddingProvider",
    "OpenAIEmbeddings",
    "SentenceTransformerEmbeddings",
    "VertexAIEmbeddings",
    "VeculoError",
    "AuthenticationError",
    "NotFoundError",
    "ValidationError",
    "Vertex",
    "Edge",
    "VectorResult",
    "QueryResult",
    "JobStatus",
    "JobList",
    "__version__",
]
