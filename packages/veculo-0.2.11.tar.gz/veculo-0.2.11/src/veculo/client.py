#
# Licensed to the Apache Software Foundation (ASF) under one
# or more contributor license agreements.  See the NOTICE file
# distributed with this work for additional information
# regarding copyright ownership.  The ASF licenses this file
# to you under the Apache License, Version 2.0 (the
# "License"); you may not use this file except in compliance
# with the License.  You may obtain a copy of the License at
#
#   https://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing,
# software distributed under the License is distributed on an
# "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
# KIND, either express or implied.  See the License for the
# specific language governing permissions and limitations
# under the License.
#

"""Veculo API client."""

from __future__ import annotations

import os
from typing import TYPE_CHECKING, Any, Optional

import httpx

if TYPE_CHECKING:
    from veculo.embeddings import EmbeddingProvider

from veculo.errors import AuthenticationError, NotFoundError, ValidationError, VeculoError

_DEFAULT_ENDPOINT = "https://api.veculo.com"
_DEFAULT_TIMEOUT = 30.0
_API_VERSION = "v1"


class VeculoClient:
    """Client for the Veculo managed graph+vector database API.

    The client reads configuration from explicit arguments, then falls back to
    environment variables:

    * ``VECULO_ENDPOINT``  -- API base URL (default ``https://api.veculo.com``)
    * ``VECULO_API_KEY``   -- API key for authentication
    * ``VECULO_CLUSTER_ID`` -- Target cluster identifier

    Example::

        from veculo import VeculoClient

        client = VeculoClient(api_key="vk-...", cluster_id="cl-a7f3b2")
        client.put_vertex(id="alice", label="person", properties={"name": "Alice"})
        result = client.get_vertex(id="alice")
    """

    def __init__(
        self,
        endpoint: str | None = None,
        api_key: str | None = None,
        cluster_id: str | None = None,
        cluster_name: str | None = None,
        *,
        timeout: float = _DEFAULT_TIMEOUT,
    ) -> None:
        """Initialize the Veculo client.

        Provide either ``cluster_id`` or ``cluster_name``. If
        ``cluster_name`` is given, the client resolves it to an ID via
        the API on first use.

        Args:
            endpoint: API endpoint URL. Defaults to ``VECULO_ENDPOINT`` env var
                or ``https://api.veculo.com``.
            api_key: Veculo API key. Defaults to ``VECULO_API_KEY`` env var.
            cluster_id: Cluster ID (e.g., ``cl-a7f3b2``). Defaults to
                ``VECULO_CLUSTER_ID`` env var.
            cluster_name: Cluster display name (e.g., ``"production"``).
                Defaults to ``VECULO_CLUSTER_NAME`` env var. Resolved to
                cluster_id automatically.
            timeout: HTTP request timeout in seconds.

        Raises:
            VeculoError: If ``api_key`` or cluster cannot be resolved.
        """
        self.endpoint = (
            endpoint or os.environ.get("VECULO_ENDPOINT") or _DEFAULT_ENDPOINT
        ).rstrip("/")
        self.api_key = api_key or os.environ.get("VECULO_API_KEY")
        self._timeout = timeout

        if not self.api_key:
            raise VeculoError(
                "API key is required. Pass api_key= or set VECULO_API_KEY."
            )

        # Resolve cluster: ID takes priority, then name lookup
        self.cluster_id = cluster_id or os.environ.get("VECULO_CLUSTER_ID")
        cluster_name = cluster_name or os.environ.get("VECULO_CLUSTER_NAME")

        # Auto-detect: if cluster_id doesn't look like an ID, treat it as a name
        if self.cluster_id and not self.cluster_id.startswith("cl-"):
            cluster_name = self.cluster_id
            self.cluster_id = None

        if not self.cluster_id and cluster_name:
            self.cluster_id = self._resolve_cluster_name(cluster_name)
        elif not self.cluster_id:
            raise VeculoError(
                "Cluster is required. Pass cluster_id=, cluster_name=, "
                "or set VECULO_CLUSTER_ID / VECULO_CLUSTER_NAME."
            )

        self._embedder: EmbeddingProvider | None = None

        self._client = httpx.Client(
            base_url=f"{self.endpoint}/{_API_VERSION}/{self.cluster_id}",
            headers={
                "Authorization": f"Bearer {self.api_key}",
                "Content-Type": "application/json",
                "User-Agent": "veculo-python/0.1.0",
            },
            timeout=timeout,
        )

    def _resolve_cluster_name(self, name: str) -> str:
        """Look up a cluster ID by display name via the API."""
        response = httpx.get(
            f"{self.endpoint}/tenants",
            headers={"Authorization": f"Bearer {self.api_key}"},
            timeout=self._timeout,
        )
        if not response.is_success:
            raise VeculoError(
                f"Failed to list clusters: HTTP {response.status_code}"
            )
        clusters = response.json()
        for cluster in clusters:
            if cluster.get("name") == name:
                return cluster["tenant_id"]
        raise NotFoundError(f"No cluster found with name '{name}'")

    # ------------------------------------------------------------------
    # Vertex operations
    # ------------------------------------------------------------------

    def put_vertex(
        self,
        id: str,
        label: str = "default",
        properties: dict[str, Any] | None = None,
        embedding: list[float] | None = None,
        visibility: str | None = None,
    ) -> dict:
        """Insert or update a vertex, optionally with a vector embedding.

        Args:
            id: Unique vertex identifier.
            label: Vertex label / type.
            properties: Key-value properties to store.
            embedding: Optional vector embedding for similarity search.
            visibility: Accumulo-style visibility expression.

        Returns:
            API response body as a dictionary.
        """
        body: dict[str, Any] = {"id": id, "label": label}
        if properties is not None:
            body["properties"] = properties
        if visibility is not None:
            body["visibility"] = visibility
        if embedding is not None:
            body["embedding"] = embedding
            return self._request("POST", "/vertices/embedding", json=body)
        return self._request("POST", "/vertices", json=body)

    def put_vertex_with_text(
        self,
        id: str,
        text: str,
        label: str = "default",
        properties: dict[str, Any] | None = None,
        visibility: str | None = None,
        embed_server_side: bool = False,
    ) -> dict:
        """Insert a vertex, generating an embedding from text.

        Args:
            id: Unique vertex identifier.
            text: Text to generate embedding from.
            label: Vertex label.
            properties: Additional properties.
            visibility: Visibility expression.
            embed_server_side: If True, sends text to Veculo API for
                server-side embedding (billed). If False, requires
                an embedding provider to be configured via set_embedder().

        Returns:
            API response.

        Raises:
            VeculoError: If no embedder configured and embed_server_side=False.
        """
        if embed_server_side:
            body: dict[str, Any] = {"id": id, "label": label, "text": text}
            if properties:
                body["properties"] = properties
            if visibility:
                body["visibility"] = visibility
            return self._request("POST", "/vertices/embed", json=body)

        if self._embedder is None:
            raise VeculoError(
                "No embedding provider configured. Call client.set_embedder() "
                "or use embed_server_side=True."
            )
        embedding = self._embedder.embed(text)
        props = dict(properties or {})
        props["_text"] = text
        return self.put_vertex(
            id=id, label=label, properties=props,
            embedding=embedding, visibility=visibility,
        )

    def put_vertex_with_file(
        self,
        id: str,
        file_path: str,
        label: str = "document",
        properties: dict[str, Any] | None = None,
        visibility: str | None = None,
    ) -> dict:
        """Upload a file and create a vertex with automatic knowledge extraction.

        The file is uploaded to GCS. Veculo asynchronously extracts text,
        generates embeddings, discovers entities, and builds relationship
        edges from the file content.

        Supported types: PDF, images (JPEG/PNG/WebP), audio (MP3/WAV),
        video (MP4), code (Python/Java/JavaScript/TypeScript), plain text.

        Veculo automatically:
        - Extracts text (OCR, transcription, or parsing)
        - Generates embeddings
        - Discovers entities and relationships
        - Builds a knowledge subgraph

        Args:
            id: Unique vertex identifier.
            file_path: Path to file on disk.
            label: Vertex label (default "document").
            properties: Additional key-value properties.
            visibility: Accumulo-style visibility expression.

        Returns:
            API response with vertex_id and file_uri.
        """
        import mimetypes
        from pathlib import Path

        path = Path(file_path)
        filename = path.name
        content_type = mimetypes.guess_type(filename)[0] or "application/octet-stream"
        file_bytes = path.read_bytes()

        return self._multipart_request(
            "/vertices/file",
            files={"file": (filename, file_bytes, content_type)},
            data={
                "id": id,
                "label": label,
                **({"properties_json": __import__("json").dumps(properties)} if properties else {}),
                **({"visibility": visibility} if visibility else {}),
            },
        )

    def _multipart_request(
        self,
        path: str,
        files: dict,
        data: dict,
    ) -> dict:
        """Send a multipart/form-data request (for file uploads)."""
        # httpx needs Content-Type unset for multipart boundary auto-detection
        response = self._client.post(path, files=files, data=data)
        if response.is_success:
            return response.json()
        # Same error handling as _request
        try:
            error_body = response.json()
            message = error_body.get("error", {}).get("message", response.text)
        except Exception:
            error_body = None
            message = response.text or f"HTTP {response.status_code}"
        status = response.status_code
        if status in (401, 403):
            raise AuthenticationError(message, status_code=status, body=error_body)
        if status == 404:
            raise NotFoundError(message, status_code=status, body=error_body)
        if status in (400, 422):
            raise ValidationError(message, status_code=status, body=error_body)
        raise VeculoError(message, status_code=status, body=error_body)

    def set_embedder(self, provider: "EmbeddingProvider") -> None:
        """Configure a client-side embedding provider.

        Example::
            from veculo.embeddings import OpenAIEmbeddings
            client.set_embedder(OpenAIEmbeddings(api_key="sk-..."))
        """
        self._embedder = provider

    def get_vertex(
        self,
        id: str,
        authorizations: str | None = None,
    ) -> dict:
        """Retrieve a vertex by ID.

        Args:
            id: Vertex identifier.
            authorizations: Comma-separated visibility authorizations.

        Returns:
            Vertex data as a dictionary.
        """
        params: dict[str, str] | None = None
        if authorizations is not None:
            params = {"authorizations": authorizations}
        return self._request("GET", f"/vertices/{id}", params=params)

    # ------------------------------------------------------------------
    # Edge operations
    # ------------------------------------------------------------------

    def put_edge(
        self,
        source: str,
        target: str,
        edge_type: str,
        properties: dict[str, Any] | None = None,
        visibility: str | None = None,
    ) -> dict:
        """Create or update a directed edge between two vertices.

        Args:
            source: Source vertex ID.
            target: Target vertex ID.
            edge_type: Relationship type (e.g., ``"knows"``).
            properties: Key-value properties to store on the edge.
            visibility: Accumulo-style visibility expression.

        Returns:
            API response body as a dictionary.
        """
        body: dict[str, Any] = {
            "source": source,
            "target": target,
            "edge_type": edge_type,
        }
        if properties is not None:
            body["properties"] = properties
        if visibility is not None:
            body["visibility"] = visibility
        return self._request("POST", "/edges", json=body)

    # ------------------------------------------------------------------
    # Query operations
    # ------------------------------------------------------------------

    def get_neighbors(
        self,
        vertex_id: str,
        edge_type: str,
        depth: int = 1,
        authorizations: str | None = None,
    ) -> dict:
        """Traverse the graph to find neighbors of a vertex.

        Args:
            vertex_id: Starting vertex ID.
            edge_type: Filter traversal to this edge type.
            depth: Maximum traversal depth (default 1).
            authorizations: Comma-separated visibility authorizations.

        Returns:
            Neighboring vertices and edges as a dictionary.
        """
        body: dict[str, Any] = {
            "vertex_id": vertex_id,
            "edge_type": edge_type,
        }
        if authorizations is not None:
            body["authorizations"] = authorizations
        return self._request("POST", "/neighbors", json=body)

    def query(
        self,
        embedding: list[float] | None = None,
        top_k: int = 10,
        edge_type: str | None = None,
        depth: int = 1,
        authorizations: str | None = None,
    ) -> dict:
        """Execute a hybrid vector similarity + graph traversal query.

        Finds the ``top_k`` most similar vertices by embedding, then
        optionally expands the result set via graph traversal.

        Args:
            embedding: Query vector for similarity search.
            top_k: Number of nearest neighbors to return (default 10).
            edge_type: Optional edge type filter for graph expansion.
            depth: Graph traversal depth (default 1).
            authorizations: Comma-separated visibility authorizations.

        Returns:
            Combined vector and graph results as a dictionary.
        """
        body: dict[str, Any] = {"top_k": top_k, "depth": depth}
        if embedding is not None:
            body["query_vector"] = embedding
        if edge_type is not None:
            body["edge_type"] = edge_type
        if authorizations is not None:
            body["authorizations"] = authorizations
        return self._request("POST", "/query/vector", json=body)

    def query_temporal(
        self,
        vertex_id: str,
        start_time: int | None = None,
        end_time: int | None = None,
        edge_type: str | None = None,
        time_field: str = "write_time",
    ) -> dict:
        """Query edges within a time range.

        Args:
            vertex_id: Vertex to query edges for.
            start_time: Start of time range (epoch milliseconds).
            end_time: End of time range (epoch milliseconds).
            edge_type: Optional edge type filter.
            time_field: "write_time" (Accumulo timestamp) or "event_time" (property).

        Returns:
            Dict with 'edges' list and 'count'.
        """
        body: dict[str, Any] = {"vertex_id": vertex_id, "time_field": time_field}
        if start_time is not None:
            body["start_time"] = start_time
        if end_time is not None:
            body["end_time"] = end_time
        if edge_type is not None:
            body["edge_type"] = edge_type
        return self._request("POST", "/query/temporal", json=body)

    def aggregate(
        self,
        aggregation: str,
        vertex_id: str | None = None,
        edge_type: str | None = None,
        time_bucket: str | None = None,
        start_time: int | None = None,
        end_time: int | None = None,
        limit: int = 100,
    ) -> dict:
        """Run a server-side aggregation query.

        Args:
            aggregation: One of COUNT, COUNT_DISTINCT, GROUP_BY_EDGE_TYPE,
                GROUP_BY_TIME, DEGREE, TOP_CONNECTED.
            vertex_id: Scope to a single vertex (optional).
            edge_type: Filter to a specific edge type (optional).
            time_bucket: For GROUP_BY_TIME: HOUR, DAY, WEEK, MONTH.
            start_time: Lower time bound (epoch millis).
            end_time: Upper time bound (epoch millis).
            limit: Maximum results to return.

        Returns:
            Dict with 'aggregation', 'results' list, and 'count'.
        """
        body: dict[str, Any] = {"aggregation": aggregation, "limit": limit}
        if vertex_id is not None:
            body["vertex_id"] = vertex_id
        if edge_type is not None:
            body["edge_type"] = edge_type
        if time_bucket is not None:
            body["time_bucket"] = time_bucket
        if start_time is not None:
            body["start_time"] = start_time
        if end_time is not None:
            body["end_time"] = end_time
        return self._request("POST", "/query/aggregate", json=body)

    def list_jobs(self) -> dict:
        """List file upload jobs and their extraction status.

        Returns:
            Dict with 'jobs' list containing vertex_id, filename, content_type,
            status (processing/complete), and extraction details.
        """
        return self._request("GET", "/jobs")

    def get_metrics(self) -> dict:
        """Retrieve cluster health and performance metrics.

        Returns:
            Cluster metrics as a dictionary.
        """
        return self._request("GET", "/metrics")

    # ------------------------------------------------------------------
    # Hibernate / Resume
    # ------------------------------------------------------------------

    def hibernate(self) -> dict:
        """Hibernate the cluster to save costs.

        Flushes all in-memory data to GCS, snapshots ZooKeeper metadata,
        and tears down all compute resources. Data and tablet metadata
        are fully preserved. Resume later with ``resume()``.

        Returns:
            API response with hibernation status.
        """
        return self._request("POST", "/hibernate")

    def resume(self) -> dict:
        """Resume a hibernated cluster.

        Deploys fresh compute pointing at the existing GCS data and
        restores ZooKeeper metadata. All tables, vertices, edges,
        and embeddings come back intact.

        Returns:
            API response with resume status.
        """
        return self._request("POST", "/resume")

    # ------------------------------------------------------------------
    # Bulk operations
    # ------------------------------------------------------------------

    def put_vertices_bulk(
        self,
        vertices: list[dict[str, Any]],
    ) -> dict:
        """Insert multiple vertices in a single batch.

        Args:
            vertices: List of vertex dicts, each with 'id', 'label',
                and optional 'properties'.

        Returns:
            API response with insert count.
        """
        return self._request("POST", "/vertices/bulk", json={"vertices": vertices})

    def put_edges_bulk(
        self,
        edges: list[dict[str, Any]],
    ) -> dict:
        """Insert multiple edges in a single batch.

        Args:
            edges: List of edge dicts, each with 'source', 'target',
                'edge_type', and optional 'properties'.

        Returns:
            API response with insert count.
        """
        return self._request("POST", "/edges/bulk", json={"edges": edges})

    # ------------------------------------------------------------------
    # AI-native queries
    # ------------------------------------------------------------------

    def nl_query(
        self,
        question: str,
        authorizations: str | None = None,
        schema_hints: dict | None = None,
    ) -> dict:
        """Execute a natural language query against the graph.

        Translates the question into a structured query plan via LLM,
        executes it, and returns results with the generated plan.

        Args:
            question: Natural language question.
            authorizations: Comma-separated visibility authorizations.
            schema_hints: Optional schema metadata for better translation.

        Returns:
            Dict with 'question', 'query_plan', and 'results'.
        """
        body: dict[str, Any] = {"question": question}
        if authorizations is not None:
            body["authorizations"] = authorizations
        if schema_hints is not None:
            body["schema_hints"] = schema_hints
        return self._request("POST", "/query/natural", json=body)

    def rag_query(
        self,
        question: str,
        context_hops: int = 1,
        model: str | None = None,
        authorizations: str | None = None,
        top_k: int = 10,
    ) -> dict:
        """Execute a Graph-Augmented RAG query.

        Performs vector search, expands graph neighborhoods, and
        synthesizes an answer via LLM with source citations.

        Args:
            question: Natural language question.
            context_hops: Graph traversal depth for context (default 1).
            model: LLM model for synthesis.
            authorizations: Visibility authorizations for ABAC.
            top_k: Number of vector search results.

        Returns:
            Dict with 'answer', 'sources', 'context', and 'model'.
        """
        body: dict[str, Any] = {
            "question": question,
            "context_hops": context_hops,
            "top_k": top_k,
        }
        if model is not None:
            body["model"] = model
        if authorizations is not None:
            body["authorizations"] = authorizations
        return self._request("POST", "/rag", json=body)

    # ------------------------------------------------------------------
    # Graph pattern queries
    # ------------------------------------------------------------------

    def query_expand(
        self,
        embedding: list[float],
        top_k: int = 10,
        threshold: float = 0.5,
        alpha: float = 0.7,
        depth: int = 1,
    ) -> dict:
        """Topological vector expansion -- finds similar vertices AND scores their graph neighbors.

        Performs vector search to find seed vertices, then expands to their
        graph neighbors and scores them using a combination of vector similarity
        and connectivity strength.

        Args:
            embedding: Query vector for similarity search.
            top_k: Number of results to return (default 10).
            threshold: Minimum similarity for seed search (default 0.5).
            alpha: Weight between similarity and connectivity.
                0 = pure connectivity, 1 = pure similarity (default 0.7).
            depth: Graph traversal depth for expansion (default 1).

        Returns:
            Dict with 'results' (list of scored vertices) and 'count'.
        """
        body: dict[str, Any] = {
            "query_vector": embedding,
            "top_k": top_k,
            "threshold": threshold,
            "alpha": alpha,
            "depth": depth,
        }
        return self._request("POST", "/query/expand", json=body)

    def reason(
        self,
        query: str | None = None,
        embedding: list[float] | None = None,
        start_vertex: str | None = None,
        max_depth: int = 5,
        alpha: float = 0.8,
        threshold: float = 0.3,
        use_scan_server: bool = True,
    ) -> dict:
        """SSM reasoning: stateful multi-hop graph traversal.

        Each hop updates a hidden state using the current vertex's embedding:
        ``h_t = alpha * h_{t-1} + (1-alpha) * normalize(x_t)``.
        The next hop follows the neighbor most aligned with the accumulated state.

        Provide either ``query`` (text, embedded server-side) or ``embedding``
        (raw vector). Text queries are easier.

        Args:
            query: Natural language query (embedded server-side via Vertex AI).
            embedding: Raw query vector (alternative to query).
            start_vertex: Start vertex ID. If None, finds nearest to query.
            max_depth: Maximum hops (default 5).
            alpha: State momentum (0=reset each hop, 1=ignore new embeddings).
            threshold: Minimum cosine to continue (default 0.3).
            use_scan_server: Route through inference scan servers (default True).

        Returns:
            Dict with 'path', 'hop_count', 'terminated_early',
            'termination_reason', 'final_state'.

        Example::

            # Text query (easiest — server generates embedding)
            result = client.reason(query="how did neural networks evolve into LLMs")

            # With explicit start vertex
            result = client.reason(query="trace the influence chain",
                                   start_vertex="ai-foundations", max_depth=10)

            # Raw embedding
            result = client.reason(embedding=[0.1, 0.2, ...])
        """
        if not query and not embedding:
            raise ValueError("Provide either query (text) or embedding (vector)")
        body: dict[str, Any] = {
            "max_depth": max_depth,
            "alpha": alpha,
            "threshold": threshold,
            "use_scan_server": use_scan_server,
        }
        if query is not None:
            body["query_text"] = query
        if embedding is not None:
            body["query_vector"] = embedding
        if start_vertex is not None:
            body["start_vertex"] = start_vertex
        return self._request("POST", "/query/reason", json=body, timeout=120)

    def find_path(
        self,
        source: str,
        target: str,
        edge_type: str | None = None,
        max_depth: int = 5,
        find_all: bool = False,
        max_paths: int = 10,
    ) -> dict:
        """Find paths between two vertices.

        Args:
            source: Source vertex ID.
            target: Target vertex ID.
            edge_type: Edge type to follow (optional).
            max_depth: Maximum path length (default 5).
            find_all: If True, find all paths (default: shortest only).
            max_paths: Maximum paths to return when find_all=True.

        Returns:
            Dict with 'paths' (list of vertex ID lists) and 'count'.
        """
        body: dict[str, Any] = {
            "source": source, "target": target,
            "max_depth": max_depth, "find_all": find_all, "max_paths": max_paths,
        }
        if edge_type is not None:
            body["edge_type"] = edge_type
        return self._request("POST", "/query/path", json=body)

    def find_intersection(
        self,
        anchor_vertices: list[str],
        edge_types: list[str] | None = None,
        direction: str = "both",
    ) -> dict:
        """Find vertices connected to ALL anchor vertices.

        Args:
            anchor_vertices: List of vertex IDs that results must connect to.
            edge_types: Edge types to follow (optional).
            direction: "outgoing", "incoming", or "both" (default).

        Returns:
            Dict with 'vertices' (list of matching IDs) and 'count'.
        """
        body: dict[str, Any] = {
            "anchor_vertices": anchor_vertices,
            "edge_types": edge_types or [],
            "direction": direction,
        }
        return self._request("POST", "/query/intersection", json=body)

    def find_triangles(
        self,
        vertex_id: str,
        edge_type: str | None = None,
        max_triangles: int = 100,
    ) -> dict:
        """Find triangles involving a vertex.

        Args:
            vertex_id: Center vertex ID.
            edge_type: Edge type filter (optional).
            max_triangles: Maximum triangles to return (default 100).

        Returns:
            Dict with 'triangles' (list of [A,B,C] vertex ID triples) and 'count'.
        """
        body: dict[str, Any] = {"vertex_id": vertex_id, "max_triangles": max_triangles}
        if edge_type is not None:
            body["edge_type"] = edge_type
        return self._request("POST", "/query/triangles", json=body)

    # ------------------------------------------------------------------
    # Configuration
    # ------------------------------------------------------------------

    def configure_auto_embed(
        self,
        model: str = "text-embedding-005",
        provider: str = "vertex-ai",
        text_properties: list[str] | None = None,
        min_text_length: int = 10,
    ) -> dict:
        """Configure automatic embedding generation for text vertices.

        When enabled, new vertices with text properties will automatically
        get embeddings generated during minor compaction.

        Args:
            model: Embedding model name.
            provider: Embedding provider (vertex-ai, openai).
            text_properties: Property names to treat as text sources.
            min_text_length: Minimum text length to trigger embedding.

        Returns:
            API response confirming configuration.
        """
        body: dict[str, Any] = {
            "model": model,
            "provider": provider,
            "text_properties": text_properties or [],
            "min_text_length": min_text_length,
        }
        return self._request("POST", "/configure/auto-embed", json=body)

    def configure_semantic_edges(
        self,
        similarity_threshold: float = 0.85,
        max_edges_per_vertex: int = 10,
    ) -> dict:
        """Configure automatic semantic edge creation.

        During major compaction, vertices with similar embeddings will
        automatically get SIMILAR_TO edges.

        Args:
            similarity_threshold: Minimum cosine similarity (default 0.85).
            max_edges_per_vertex: Maximum edges per vertex (default 10).

        Returns:
            API response confirming configuration.
        """
        return self._request("POST", "/configure/semantic-edges", json={
            "similarity_threshold": similarity_threshold,
            "max_edges_per_vertex": max_edges_per_vertex,
        })

    # ------------------------------------------------------------------
    # Insights
    # ------------------------------------------------------------------

    def get_anomalies(
        self,
        authorizations: str | None = None,
    ) -> dict:
        """Get vertices flagged as anomalous by embedding analysis.

        Returns:
            Dict with 'anomalies' list of flagged vertices and scores.
        """
        params: dict[str, str] | None = None
        if authorizations is not None:
            params = {"authorizations": authorizations}
        return self._request("GET", "/insights/anomalies", params=params)

    def get_top_ranked(
        self,
        authorizations: str | None = None,
    ) -> dict:
        """Get top-ranked vertices by PageRank score.

        Returns:
            Dict with 'ranks' list of vertices and their scores.
        """
        params: dict[str, str] | None = None
        if authorizations is not None:
            params = {"authorizations": authorizations}
        return self._request("GET", "/insights/ranks", params=params)

    def get_processing_status(self) -> dict:
        """Get the status of pending marker processing queue.

        Returns:
            Dict with queue sizes for each marker type.
        """
        return self._request("GET", "/insights/processing-queue")

    # ------------------------------------------------------------------
    # Internals
    # ------------------------------------------------------------------

    def _request(
        self,
        method: str,
        path: str,
        *,
        params: dict[str, str] | None = None,
        json: dict[str, Any] | None = None,
        timeout: float | None = None,
    ) -> dict:
        """Send an HTTP request and return the parsed JSON response.

        Raises:
            AuthenticationError: On 401 or 403 responses.
            NotFoundError: On 404 responses.
            ValidationError: On 400 or 422 responses.
            VeculoError: On any other non-2xx response.
        """
        response = self._client.request(method, path, params=params, json=json,
                                        timeout=timeout)

        if response.is_success:
            if response.status_code == 204:
                return {}
            return response.json()

        # Parse error body
        try:
            error_body = response.json()
            message = error_body.get("error", {}).get("message", response.text)
        except Exception:
            error_body = None
            message = response.text or f"HTTP {response.status_code}"

        status = response.status_code
        if status in (401, 403):
            raise AuthenticationError(message, status_code=status, body=error_body)
        if status == 404:
            raise NotFoundError(message, status_code=status, body=error_body)
        if status in (400, 422):
            raise ValidationError(message, status_code=status, body=error_body)
        raise VeculoError(message, status_code=status, body=error_body)

    def close(self) -> None:
        """Close the underlying HTTP client."""
        self._client.close()

    def __enter__(self) -> "VeculoClient":
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()

    def __repr__(self) -> str:
        return (
            f"VeculoClient(endpoint={self.endpoint!r}, "
            f"cluster_id={self.cluster_id!r})"
        )
