#!/usr/bin/env sh
# Talon installer
# Usage: curl -fsSL https://api.cogmeta.ai/install.sh | sh
#
# Security note: always review scripts before running them.
# The package is served over HTTPS from api.cogmeta.ai.
set -e

TALON_INDEX_URL="https://api.cogmeta.ai/simple/"
TALON_VENV="$HOME/.talon-venv"
UV_INSTALL_URL="https://astral.sh/uv/install.sh"

print_step()  { printf '\n\033[1;36m==> %s\033[0m\n' "$1"; }
print_ok()    { printf '\033[1;32m  ✓ %s\033[0m\n' "$1"; }
print_warn()  { printf '\033[1;33m  ! %s\033[0m\n' "$1"; }
print_error() { printf '\033[1;31m  ✗ %s\033[0m\n' "$1"; }
die()         { print_error "$1"; exit 1; }

# ── OS check ──────────────────────────────────────────────────────────────────

OS="$(uname -s)"
case "$OS" in
  Linux|Darwin) ;;
  *) die "Unsupported OS: $OS. See https://app.cogmeta.ai/quickstart" ;;
esac

# ── Python check ──────────────────────────────────────────────────────────────

print_step "Checking Python"

PYTHON=""
for cmd in python3.13 python3.12 python3 python; do
  if command -v "$cmd" >/dev/null 2>&1; then
    major=$("$cmd" -c "import sys; print(sys.version_info.major)" 2>/dev/null || true)
    minor=$("$cmd" -c "import sys; print(sys.version_info.minor)" 2>/dev/null || true)
    if [ "$major" -ge 3 ] && [ "$minor" -ge 12 ]; then
      PYTHON="$cmd"
      print_ok "Found $cmd ($major.$minor)"
      break
    fi
  fi
done

[ -z "$PYTHON" ] && die "Python 3.12+ is required. Install from https://python.org"

# ── uv check / install ────────────────────────────────────────────────────────

print_step "Checking uv"

if command -v uv >/dev/null 2>&1; then
  print_ok "uv already installed ($(uv --version 2>/dev/null | head -1))"
else
  print_warn "uv not found — installing..."
  if command -v curl >/dev/null 2>&1; then
    curl -LsSf "$UV_INSTALL_URL" | sh
  elif command -v wget >/dev/null 2>&1; then
    wget -qO- "$UV_INSTALL_URL" | sh
  else
    die "curl or wget required to install uv"
  fi
  export PATH="$HOME/.cargo/bin:$HOME/.local/bin:$PATH"
  command -v uv >/dev/null 2>&1 || die "uv install failed — see https://docs.astral.sh/uv/"
  print_ok "uv installed ($(uv --version 2>/dev/null | head -1))"
fi

# ── Install talon ─────────────────────────────────────────────────────────────

print_step "Installing Talon"

if [ ! -d "$TALON_VENV" ]; then
  uv venv "$TALON_VENV" --python "$PYTHON"
  print_ok "Created venv at $TALON_VENV"
else
  print_ok "Using existing venv at $TALON_VENV"
fi

uv pip install cogmeta-talon \
  --extra-index-url "$TALON_INDEX_URL" \
  --python "$TALON_VENV/bin/python" \
  --reinstall

print_ok "cogmeta-talon installed ($("$TALON_VENV/bin/talon" --version 2>/dev/null | head -1 || echo 'ok'))"

# ── Link binaries ─────────────────────────────────────────────────────────────

LOCAL_BIN="$HOME/.local/bin"
mkdir -p "$LOCAL_BIN"
for bin in talon talon-statusline talon-prompt-hook; do
  if [ -x "$TALON_VENV/bin/$bin" ]; then
    ln -sf "$TALON_VENV/bin/$bin" "$LOCAL_BIN/$bin"
  fi
done

if command -v talon >/dev/null 2>&1; then
  print_ok "talon linked to $LOCAL_BIN/talon"
else
  print_warn "talon not on PATH — add to your shell profile:"
  printf '\n  export PATH="%s/bin:$PATH"\n' "$TALON_VENV"
fi

# ── Claude Code permissions ───────────────────────────────────────────────────

print_step "Configuring Claude Code permissions"

"$PYTHON" -c "
import json, os
path = os.path.expanduser('~/.claude/settings.json')
os.makedirs(os.path.dirname(path), exist_ok=True)
try:
    with open(path) as f: settings = json.load(f)
except (json.JSONDecodeError, FileNotFoundError): settings = {}
allow = settings.setdefault('permissions', {}).setdefault('allow', [])
venv = os.path.expanduser('~/.talon-venv/bin')
for rule in ['Bash(talon *)', f'Bash({venv}/talon *)']:
    if rule not in allow: allow.append(rule)
with open(path, 'w') as f: json.dump(settings, f, indent=2); f.write('\n')
" 2>/dev/null && print_ok "Permissions configured" || print_warn "Could not update ~/.claude/settings.json"

# ── Skill installation ────────────────────────────────────────────────────────

print_step "Installing /talon skill"

SKILL_SRC=""
for pyver in python3.13 python3.12 python3; do
  candidate="$TALON_VENV/lib/$pyver/site-packages/talon/skills/SKILL.md"
  if [ -f "$candidate" ]; then SKILL_SRC="$candidate"; break; fi
done

SKILL_DIR="$HOME/.claude/skills/talon"
if [ -f "$SKILL_SRC" ]; then
  mkdir -p "$SKILL_DIR"
  cp "$SKILL_SRC" "$SKILL_DIR/SKILL.md"
  print_ok "Installed /talon skill to $SKILL_DIR/SKILL.md"
else
  print_warn "SKILL.md not found — /talon commands won't be available"
fi

# ── Status line + prompt hook ─────────────────────────────────────────────────

print_step "Configuring status line and hooks"

"$PYTHON" -c "
import json, os
path = os.path.expanduser('~/.claude/settings.json')
try:
    with open(path) as f: settings = json.load(f)
except (json.JSONDecodeError, FileNotFoundError): settings = {}
venv = os.path.expanduser('~/.talon-venv/bin')
settings['statusLine'] = {'type': 'command', 'command': venv + '/talon-statusline'}
hooks = settings.setdefault('hooks', {})
ups = hooks.setdefault('UserPromptSubmit', [])
hook_cmd = venv + '/talon-prompt-hook'
already = any(hook_cmd in h.get('command','') for entry in ups for h in entry.get('hooks',[]))
if not already:
    ups.append({'matcher': '', 'hooks': [{'type': 'command', 'command': hook_cmd, 'timeout': 5}]})
with open(path, 'w') as f: json.dump(settings, f, indent=2); f.write('\n')
" 2>/dev/null && print_ok "Status line and prompt hook configured" || print_warn "Could not configure — run 'talon init' manually"

# ── MCP wiring (if already authed) ───────────────────────────────────────────

"$PYTHON" -c "
import json, os
creds_path = os.path.expanduser('~/.talon/credentials.json')
try:
    with open(creds_path) as f: creds = json.load(f)
    api_key   = creds.get('api_key', '')
    cloud_url = creds.get('cloud_url', 'https://api.cogmeta.ai').rstrip('/')
    if not api_key: raise ValueError('no key')
    claude_json = os.path.expanduser('~/.claude.json')
    try:
        with open(claude_json) as f: cdata = json.load(f)
    except (FileNotFoundError, json.JSONDecodeError): cdata = {}
    cdata.setdefault('mcpServers', {})['talon'] = {
        'type': 'sse',
        'url': cloud_url + '/talon/mcp/sse',
        'headers': {'X-API-Key': api_key},
    }
    with open(claude_json, 'w') as f: json.dump(cdata, f, indent=2); f.write('\n')
except Exception: pass
" 2>/dev/null

# ── Done ──────────────────────────────────────────────────────────────────────

printf '\n\033[1;32m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\033[0m\n'
printf '\033[1;32m  Talon installed into %s\033[0m\n' "$TALON_VENV"
printf '\033[1;32m━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\033[0m\n'

if ! command -v talon >/dev/null 2>&1; then
  printf '\n\033[1;33mAdd talon to your PATH:\033[0m\n'
  printf '\n  echo '\''export PATH="$HOME/.talon-venv/bin:$PATH"'\'' >> ~/.bashrc && source ~/.bashrc\n'
  printf '\n  (macOS: use ~/.zshrc instead of ~/.bashrc)\n'
fi

printf '\nNext steps:\n'
printf '\n  1. \033[1;36mtalon auth\033[0m    Log in or create an account'
printf '\n  2. \033[1;36mtalon init\033[0m    Set up your project'
printf '\n  3. \033[1;36mclaude\033[0m        Start Claude Code — Talon tools are active\n'
printf '\nDocs: https://app.cogmeta.ai/quickstart\n\n'
