# Talon

Context intelligence for Agentic Development — graph-based code context for AI coding agents.

## Supported Languages

| Language   | Extensions                     | Parser Features                                                      |
| ---------- | ------------------------------ | -------------------------------------------------------------------- |
| Python     | `.py`                          | Classes, decorators, raise/except, async                             |
| TypeScript | `.ts`, `.tsx`                  | Classes, interfaces, arrow functions, ES imports                     |
| JavaScript | `.js`, `.jsx`, `.mjs`, `.cjs`  | Arrow functions, ES imports/exports, method chains, error paths      |
| Go         | `.go`                          | Structs, receiver methods, interfaces, panic/recover                 |
| Java       | `.java`                        | Annotations, constructors, throws, inheritance, enums                |
| Rust       | `.rs`                          | Structs, traits, impl blocks, enums, panic!/? error paths            |
| C#         | `.cs`                          | Classes, interfaces, attributes, constructors, throw/catch           |
| Kotlin     | `.kt`, `.kts`                  | Data/sealed classes, companion objects, suspend functions             |
| Ruby       | `.rb`                          | Classes, modules, include/extend, singleton methods, rescue          |
| PHP        | `.php`                         | Classes, interfaces, traits, enums, namespace imports                |

All languages get full-depth parsing: classes/structs, functions/methods, imports, call edges, error flow edges, method chain resolution, and cross-module call edges.

## Install

```bash
pip install talon
```

## Quick start

```bash
# Authenticate with cogmeta.ai (opens browser, no copy/paste)
talon-setup auth login

# Generate .mcp.json for your project
talon-setup init --cloud
```

Then restart Claude Code — Talon is active.
