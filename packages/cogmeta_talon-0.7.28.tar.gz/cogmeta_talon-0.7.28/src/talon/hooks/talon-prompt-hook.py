#!/usr/bin/env python3
"""talon-prompt-hook.py — UserPromptSubmit hook for end-user Talon installs.

Lightweight hook that:
1. Fires prompt telemetry to cloud API (fire-and-forget)
2. Injects a brief reminder to use talon MCP tools on first prompt
"""

import json
import os
import sys
import threading
import time
from pathlib import Path

_TELEMETRY_URL = os.environ.get(
    "TALON_TELEMETRY_URL", "https://api.cogmeta.ai/cloud/v1/talon/telemetry/prompt_event"
)
_SESSION_FILE = Path.home() / ".talon" / "session_state.json"


def _load_api_key() -> tuple[str, str]:
    try:
        creds = json.loads((Path.home() / ".talon" / "credentials.json").read_text())
        return creds.get("api_key", ""), creds.get("cloud_url", "https://api.cogmeta.ai")
    except Exception:
        return "", "https://api.cogmeta.ai"


def _fire_telemetry(prompt_text: str, session_id: str) -> None:
    try:
        import urllib.request
        data = json.dumps({
            "session_id": session_id,
            "prompt_length": len(prompt_text),
            "timestamp": time.time(),
        }).encode()
        req = urllib.request.Request(
            _TELEMETRY_URL,
            data=data,
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        api_key = os.environ.get("TALON_API_KEY", "")
        if api_key:
            req.add_header("Authorization", f"Bearer {api_key}")
        urllib.request.urlopen(req, timeout=2)
    except Exception:
        pass


def _fetch_alltime_score() -> None:
    try:
        import ssl
        import urllib.request
        api_key, cloud_url = _load_api_key()
        if not api_key:
            return
        alltime_path = Path.home() / ".talon" / "score_alltime.json"
        if alltime_path.exists():
            age = time.time() - json.loads(alltime_path.read_text()).get("updated_at", 0)
            if age < 3600:
                return
        url = f"{cloud_url.rstrip('/')}/cloud/v1/talon/telemetry/score/summary"
        ctx = ssl.create_default_context()
        if os.environ.get("TALON_NO_VERIFY", "").lower() in ("1", "true", "yes"):
            ctx.check_hostname = False
            ctx.verify_mode = ssl.CERT_NONE
        req = urllib.request.Request(url, headers={"X-API-Key": api_key})
        resp = urllib.request.urlopen(req, timeout=3, context=ctx)
        data = json.loads(resp.read())
        alltime_path.parent.mkdir(parents=True, exist_ok=True)
        alltime_path.write_text(json.dumps({
            "score": data.get("avg_score", 0.0),
            "sessions": data.get("total_sessions", 0),
            "updated_at": time.time(),
        }))
    except Exception:
        pass


def _is_first_prompt(session_id: str) -> bool:
    try:
        _SESSION_FILE.parent.mkdir(parents=True, exist_ok=True)
        if _SESSION_FILE.exists():
            state = json.loads(_SESSION_FILE.read_text())
            if state.get("session_id") == session_id:
                return False
        _SESSION_FILE.write_text(json.dumps({"session_id": session_id}))
        return True
    except Exception:
        return False


def main() -> None:
    try:
        raw = sys.stdin.read()
        event = json.loads(raw) if raw.strip() else {}
    except Exception:
        event = {}

    session_id = event.get("session_id", "")
    prompt_text = ""
    content = event.get("message", {}).get("content", "")
    if isinstance(content, str):
        prompt_text = content
    elif isinstance(content, list):
        for c in content:
            if isinstance(c, dict) and c.get("text"):
                prompt_text = c["text"]
                break

    t = threading.Thread(target=_fire_telemetry, args=(prompt_text, session_id), daemon=True)
    t.start()
    t2 = threading.Thread(target=_fetch_alltime_score, daemon=True)
    t2.start()

    result = {"allow": True}

    if _is_first_prompt(session_id):
        result["message"] = (
            "[Talon] Use graph_ask_lite first for code context, "
            "then edit_batch for changes. Run /talon score to check session efficiency."
        )

    json.dump(result, sys.stdout)
    t.join(timeout=2)
    t2.join(timeout=2)


if __name__ == "__main__":
    main()
