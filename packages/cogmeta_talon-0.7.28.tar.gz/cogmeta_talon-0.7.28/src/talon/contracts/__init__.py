"""Intent response contracts for talon v5."""
