"""Talon Score — real-time session health metric (0.00–1.00).

Four signals:
  spp  (40%) — Steps per prompt: total_tool_calls / prompts
  go%  (20%) — Graph-only prompt %: prompts with 0 native calls
  cpp  (30%) — Context per prompt: total_tctx / prompts
  s/g  (10%) — SRB-to-GAL ratio

Marathon calibration: r=-0.604, N=123 sessions.
"""

from __future__ import annotations

import json
import time
from dataclasses import asdict, dataclass, field
from pathlib import Path


TALON_TOOLS = frozenset({
    "mcp__talon__graph_ask_lite",
    "mcp__talon__graph_query",
    "mcp__talon__smart_read_batch",
    "mcp__talon__edit_batch",
    "graph_ask_lite",
    "graph_query",
    "smart_read_batch",
    "edit_batch",
})

REPORT_EVERY_N_PROMPTS = 1


@dataclass
class ScoreSnapshot:
    score: float
    band: str
    est_reduction_pct: float
    spp: float
    go_pct: float
    cpp: int
    sg_ratio: float
    prompts: int
    total_steps: int
    total_tctx: int
    timestamp: float = field(default_factory=time.time)


class SessionScorer:
    """Compute talon_score in real time during a session."""

    def __init__(self) -> None:
        self.tool_calls: list[str] = []
        self.prompt_tools: dict[int, list[str]] = {}
        self.total_cc: int = 0
        self.total_cr: int = 0
        self.total_input: int = 0
        self.snapshots: list[ScoreSnapshot] = []
        self._last_report_prompt: int = 0

    def record_call(
        self,
        tool_name: str,
        prompt_idx: int,
        cc: int = 0,
        cr: int = 0,
        inp: int = 0,
    ) -> ScoreSnapshot | None:
        """Record a tool call. Returns a snapshot every REPORT_EVERY_N_PROMPTS prompts."""
        self.tool_calls.append(tool_name)
        self.prompt_tools.setdefault(prompt_idx, []).append(tool_name)
        self.total_cc += cc
        self.total_cr += cr
        self.total_input += inp

        n_prompts = len(self.prompt_tools)
        if n_prompts > 0 and n_prompts >= self._last_report_prompt + REPORT_EVERY_N_PROMPTS:
            self._last_report_prompt = n_prompts
            snap = self._compute()
            self.snapshots.append(snap)
            return snap
        return None

    def score(self) -> ScoreSnapshot:
        return self._compute()

    def _compute(self) -> ScoreSnapshot:
        n_prompts = len(self.prompt_tools)
        if n_prompts == 0:
            return ScoreSnapshot(0.0, "no_data", 0.0, 0.0, 0.0, 0, 0.0, 0, 0, 0)

        total_steps = len(self.tool_calls)
        tctx = self.total_cc + self.total_cr + self.total_input

        spp = total_steps / n_prompts

        graph_only = sum(
            1 for tools in self.prompt_tools.values()
            if all(t in TALON_TOOLS for t in tools)
        )
        go_pct = graph_only / n_prompts * 100

        cpp = tctx / n_prompts

        gal = sum(1 for t in self.tool_calls if t in ("mcp__talon__graph_ask_lite", "graph_ask_lite"))
        srb = sum(1 for t in self.tool_calls if t in ("mcp__talon__smart_read_batch", "smart_read_batch"))
        sg = srb / gal if gal > 0 else (float(srb) if srb > 0 else 0.0)

        spp_s = max(0.0, min(1.0, (12 - spp) / 10))
        go_s = go_pct / 100
        ctx_s = max(0.0, min(1.0, (1_000_000 - cpp) / 600_000))
        sg_s = max(0.0, min(1.0, (5 - sg) / 4.5))

        score = 0.40 * spp_s + 0.20 * go_s + 0.30 * ctx_s + 0.10 * sg_s
        est_reduction = -55.7 + (-28.4 * score)

        band = (
            "excellent" if score >= 0.85 else
            "good" if score >= 0.65 else
            "moderate" if score >= 0.40 else
            "poor" if score >= 0.20 else
            "bad"
        )

        return ScoreSnapshot(
            score=round(score, 3),
            band=band,
            est_reduction_pct=round(est_reduction, 1),
            spp=round(spp, 1),
            go_pct=round(go_pct, 1),
            cpp=round(cpp),
            sg_ratio=round(sg, 2),
            prompts=n_prompts,
            total_steps=total_steps,
            total_tctx=tctx,
        )

    def footer_line(self) -> str:
        """One-line score footer for GAL responses."""
        s = self._compute()
        if s.prompts == 0:
            return ""
        cpp_fmt = f"{s.cpp / 1000:.0f}K" if s.cpp >= 1000 else str(s.cpp)
        return (
            f"─── talon score: {s.score:.2f} ({s.band}) | "
            f"est. {s.est_reduction_pct:.0f}% tctx | "
            f"spp={s.spp} go={s.go_pct:.0f}% cpp={cpp_fmt} ───"
        )

    def persist(self, session_id: str = "") -> None:
        """Write current score to ~/.talon/score.json for status bar consumption."""
        s = self._compute()
        score_path = Path.home() / ".talon" / "score.json"
        try:
            score_path.parent.mkdir(parents=True, exist_ok=True)
            last_prompt_score = s.score
            if self.snapshots:
                last_prompt_score = self.snapshots[-1].score
            data = {
                "last_prompt": round(last_prompt_score, 2),
                "session": round(s.score, 2),
                "band": s.band,
                "prompts": s.prompts,
                "total_steps": s.total_steps,
                "spp": s.spp,
                "go_pct": s.go_pct,
                "cpp": s.cpp,
                "sg_ratio": s.sg_ratio,
                "est_reduction_pct": s.est_reduction_pct,
                "session_id": session_id,
                "updated_at": time.time(),
            }
            score_path.write_text(json.dumps(data))
        except Exception:
            pass
