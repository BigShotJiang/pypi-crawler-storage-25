"""Intent router for talon v5 single-tool architecture.

Routes graph_query intents to handler functions that build plain-text
responses shaped by the depth contract. No JSON blobs to the LLM.

Implements: v5 Phase 1 (toc), Phase 2 (locate), Phase 3 (pre-warming, confidence),
Phase 4 (callers/blast/coverage/flow).
"""

from __future__ import annotations

import json as _json
import logging
import os
import re
import time
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from talon.cache.memory_store import MemoryStore
    from talon.db.arango import TalonGraph

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Not-Found Suggestions
# ---------------------------------------------------------------------------


def _log_not_found(target: str, entity_type: str, intent: str = "") -> None:
    """Append not-found events to the error log (fire-and-forget)."""
    try:
        from pathlib import Path
        import datetime
        log_path = Path(os.environ.get(
            "TALON_ERROR_LOG",
            str(Path.home() / ".talon" / "error.log"),
        ))
        ts = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        entry = f"| {ts} | {intent or entity_type} | `{target}` | {entity_type} not found |\n"
        if not log_path.exists():
            log_path.parent.mkdir(parents=True, exist_ok=True)
            header = "# Talon Error Log\n\n| Timestamp | Intent | Target | Error |\n|-----------|--------|--------|-------|\n"
            log_path.write_text(header + entry)
        else:
            with open(log_path, "a") as f:
                f.write(entry)
    except Exception:
        pass  # fire-and-forget


def _not_found_suggestions(target: str, entity_type: str = "file") -> str:
    """Build an actionable not-found message with suggestions."""
    msg = [f"{entity_type.title()} '{target}' not found."]

    if entity_type == "symbol":
        _log_not_found(target, entity_type, intent="locate")
        # Detect malformed locate patterns and give targeted advice
        has_slash = "/" in target
        has_spaces = " " in target
        has_dot_py = ".py" in target
        looks_like_import = target.startswith("from ") or " import " in target

        if looks_like_import:
            msg.append("locate searches symbol NAMES, not import statements.")
            msg.append("Try: search(intent='search', target='" + target.split()[-1] + "')")
        elif has_slash or has_dot_py:
            # Path-qualified syntax: "symbol file/path.py"
            parts = target.split()
            symbol_guess = parts[0] if parts else target
            msg.append("locate searches symbol NAMES only — don't include file paths.")
            msg.append(f"Try: locate(target='{symbol_guess}') or toc on the file directly.")
        elif has_spaces and "." not in target:
            # Multi-word keyword search: "backends tests sqlite"
            msg.append("locate searches symbol NAMES, not keywords.")
            msg.append(f"Try: search(intent='search', target='{target}') for content/keyword matches.")
        else:
            msg.append("Suggestions:")
            msg.append("  - Try a partial name for fuzzy matching (e.g. prefix)")
            msg.append("  - search(intent='search') for content/keyword matches")
            msg.append("  - toc on the most likely directory to scan symbols")
    else:
        # File/directory not found — redirect to graph navigation, not Glob
        stem = target.rstrip("/").split("/")[-1].replace(".py", "")
        # Guess a likely class name from the filename (e.g. "database" → "DatabaseBackend")
        class_guess = stem.title().replace("_", "") + "Backend" if stem else stem
        msg.append(f"  - The file may not exist or may have moved.")
        msg.append(f"  - Use graph_query(intent='locate', target='{class_guess}') to find by class name")
        msg.append(f"  - Use graph_query(intent='search', target='{stem}') to find by keyword")
        msg.append(f"  - Do NOT use Glob — graph_query(locate/search) is faster and searches the full index")
    return "\n".join(msg)


def _is_directory_target(target: str) -> bool:
    """Check if target looks like a directory path (no file extension)."""
    if "/" not in target:
        return False
    last = target.rstrip("/").rsplit("/", 1)[-1]
    return "." not in last


# ---------------------------------------------------------------------------
# Response Cache (in-memory, keyed by intent:target:depth:project_id)
# ---------------------------------------------------------------------------

_response_cache: dict[str, tuple[str, float]] = {}  # key → (response, timestamp)
_CACHE_TTL_SECONDS = 1800.0  # 30 min session lifetime default


def _cache_key(intent: str, target: str, depth: str, project_id: str, hops: int | None = None) -> str:
    base = f"{intent}:{target}:{depth}:{project_id}"
    return f"{base}:h{hops}" if hops else base


def _cache_get(key: str) -> str | None:
    entry = _response_cache.get(key)
    if entry is None:
        return None
    response, ts = entry
    if time.monotonic() - ts > _CACHE_TTL_SECONDS:
        del _response_cache[key]
        return None
    return response


def _cache_set(key: str, response: str) -> None:
    _response_cache[key] = (response, time.monotonic())


def invalidate_file(file_path: str) -> int:
    """Invalidate all cached responses for a given file. Returns count removed."""
    keys_to_remove = [k for k in _response_cache if f":{file_path}:" in k]
    for k in keys_to_remove:
        del _response_cache[k]
    return len(keys_to_remove)


# ---------------------------------------------------------------------------
# Confidence Scoring (Phase 3)
# ---------------------------------------------------------------------------


def compute_confidence(
    *,
    callers_count: int = 0,
    co_change_correlation: float = 0.0,
    changes_30d: int = 0,
    has_tests: bool = False,
) -> float:
    """Compute composite confidence score for ranking graph results.

    Combines structural importance (callers), co-change correlation,
    churn risk, and test coverage into a 0-1 score.

    Higher = more important / more confident in the data.
    """
    # Structural importance: log-scaled caller count (0-0.4)
    import math
    structural = min(0.4, 0.1 * math.log1p(callers_count))

    # Co-change signal (0-0.3)
    cochange = min(0.3, co_change_correlation * 0.3)

    # Stability penalty: high churn = lower confidence (0-0.15)
    if changes_30d > 15:
        stability = 0.0
    elif changes_30d > 5:
        stability = 0.05
    elif changes_30d > 0:
        stability = 0.10
    else:
        stability = 0.15

    # Test coverage bonus (0-0.15)
    test_bonus = 0.15 if has_tests else 0.0

    return round(structural + cochange + stability + test_bonus, 3)


# ---------------------------------------------------------------------------
# Pre-warmer reference (set by local_server.py after init)
# ---------------------------------------------------------------------------

_pre_warmer: Any = None  # PreWarmer instance, set externally


def set_pre_warmer(warmer: Any) -> None:
    """Set the pre-warmer instance for post-query warming."""
    global _pre_warmer
    _pre_warmer = warmer


# ---------------------------------------------------------------------------
# Concept Graph (CG) integration
# ---------------------------------------------------------------------------

_cg_store: Any = None  # ConceptGraphStore
_cg_query: Any = None  # ConceptGraphQuery


def set_cg_store(store: Any) -> None:
    """Set the CG store for cg/cg_update intents."""
    global _cg_store, _cg_query
    _cg_store = store
    from talon.cg.query import ConceptGraphQuery
    _cg_query = ConceptGraphQuery(store)


# ---------------------------------------------------------------------------
# Intent Dispatch
# ---------------------------------------------------------------------------

SUPPORTED_INTENTS = {"toc", "locate", "callers", "blast", "coverage", "flow", "sync", "scope", "cg", "cg_update", "search", "insert"}

# Feature 4: Depth auto-upgrade — track seen (intent, target) pairs
_auto_depth_seen: set[str] = set()


async def route_intent(
    intent: str,
    target: str,
    depth: str,
    project_id: str,
    graph: TalonGraph,
    memory: MemoryStore,
    hops: int | None = None,
) -> dict[str, Any]:
    """Route an intent to its handler and return structured result.

    Returns dict with:
        response: str — plain text response for the LLM
        tokens_est: int — estimated token count
        cache_hit: bool
        latency_ms: int
        layers_used: list[str]
        warnings_count: int
    """
    start = time.monotonic()

    # Feature 4: Depth auto-upgrade — second request for same target upgrades shallow→standard
    if os.environ.get("TALON_DEPTH_AUTO") == "1" and depth == "shallow":
        cache_key = f"{intent}:{target}"
        if cache_key in _auto_depth_seen:
            depth = "standard"
        _auto_depth_seen.add(cache_key)

    # Check cache
    key = _cache_key(intent, target, depth, project_id, hops)
    cached = _cache_get(key)
    if cached is not None:
        latency = int((time.monotonic() - start) * 1000)
        return {
            "response": cached,
            "tokens_est": len(cached) // 4,
            "cache_hit": True,
            "latency_ms": latency,
            "layers_used": ["cache"],
            "warnings_count": 0,
        }

    # Multi-target toc: "file1\nfile2\nfile3" → batch all in one call
    if intent == "toc":
        targets = [t.strip() for t in target.splitlines() if t.strip()]
        if len(targets) > 1:
            parts = []
            all_layers: list[str] = []
            total_warnings = 0
            for t in targets:
                r, lyr, w = await _build_toc_response(t, depth, project_id, graph, memory, hops=hops)
                parts.append(r)
                all_layers.extend(lyr)
                total_warnings += w
            response = "\n\n".join(parts)
            if intent != "sync":
                _cache_set(key, response)
            if _pre_warmer:
                for t in targets:
                    if "/" in t:
                        _pre_warmer.on_query_fire_and_forget(t)
            latency = int((time.monotonic() - start) * 1000)
            return {
                "response": response,
                "tokens_est": len(response) // 4,
                "cache_hit": False,
                "latency_ms": latency,
                "layers_used": list(dict.fromkeys(all_layers)),
                "warnings_count": total_warnings,
            }

    # Dispatch to handler
    handler = _INTENT_HANDLERS.get(intent)
    if handler is None:
        return {
            "response": f"Unknown intent: {intent}. Supported: {', '.join(sorted(SUPPORTED_INTENTS))}",
            "tokens_est": 10,
            "cache_hit": False,
            "latency_ms": 0,
            "layers_used": [],
            "warnings_count": 0,
        }

    try:
        response, layers, warnings_count = await handler(target, depth, project_id, graph, memory, hops=hops)
    except Exception as e:
        logger.error("Intent %s failed for %s: %s", intent, target, e, exc_info=True)
        response = f"Error processing {intent} for {target}: {e}"
        layers = []
        warnings_count = 0

    # Cache the response (except sync intent)
    if intent != "sync":
        _cache_set(key, response)

    # Fire-and-forget pre-warming for file-targeted intents
    if _pre_warmer and intent in ("toc", "locate") and "/" in target:
        _pre_warmer.on_query_fire_and_forget(target)

    latency = int((time.monotonic() - start) * 1000)
    return {
        "response": response,
        "tokens_est": len(response) // 4,
        "cache_hit": False,
        "latency_ms": latency,
        "layers_used": layers,
        "warnings_count": warnings_count,
    }


# ---------------------------------------------------------------------------
# TOC Intent (Phase 1)
# ---------------------------------------------------------------------------


def _file_path_to_module(file_path: str) -> str:
    """Convert file path to Python module name for AQL queries.

    src/talon/mcp/server.py → src.talon.mcp.server
    """
    name = file_path.replace("/", ".")
    if name.endswith(".py"):
        name = name[:-3]
    if name.endswith(".__init__"):
        name = name[:-9]
    return name


async def _build_toc_response(
    target: str,
    depth: str,
    project_id: str,
    graph: TalonGraph,
    memory: MemoryStore,
    hops: int | None = None,
) -> tuple[str, list[str], int]:
    """Build table-of-contents response for a file.

    Returns: (response_text, layers_used, warnings_count)
    """
    layers_used = []
    warnings_count = 0

    # Directory target: delegate to directory TOC builder
    if _is_directory_target(target):
        return _build_directory_toc(target, depth, memory)

    # Try memory store first for file metadata
    file_loc = memory.get_file_loc(target)
    symbols_from_memory = memory.get_file_symbols(target) if file_loc > 0 else []

    if symbols_from_memory:
        layers_used.append("L1")
        functions = symbols_from_memory
    else:
        # Fall back to graph query
        layers_used.append("graph")
        module_key = _file_path_to_module(target)

        # Query for file node
        file_results = await graph.query(
            "FOR f IN talon_files FILTER f.path == @path AND f.project_id == @pid LIMIT 1 RETURN f",
            {"path": target, "pid": project_id},
        )
        if not file_results:
            # Memory might have the file even if graph doesn't
            if file_loc > 0:
                return _format_toc_shallow(target, file_loc, 0, [], layers_used + ["L1"], 0)
            return (_not_found_suggestions(target, "file"), layers_used, 0)

        file_loc = file_results[0].get("loc", 0)

        # Query for functions
        func_results = await graph.query(
            """FOR f IN talon_functions
               FILTER f.module == @module AND f.project_id == @pid
               SORT f.line_start
               RETURN {
                   name: f.name,
                   class_name: f.class_name,
                   line_start: f.line_start,
                   line_end: f.line_end,
                   type: f.class_name ? "method" : "function",
                   params: f.params,
                   return_type: f.return_type,
                   is_async: f.is_async,
                   decorators: f.decorators
               }""",
            {"module": module_key, "pid": project_id},
        )
        functions = func_results

    # Count functions and classes
    func_count = len(functions)

    # Build response based on depth
    if depth == "shallow":
        return _format_toc_shallow(target, file_loc, func_count, functions, layers_used, warnings_count)
    elif depth == "standard":
        return await _format_toc_standard(
            target, file_loc, func_count, functions, project_id, graph, memory, layers_used
        )
    elif depth == "edit":
        return _format_toc_edit(target, file_loc, func_count, functions, memory, layers_used)
    else:  # full
        return await _format_toc_full(
            target, file_loc, func_count, functions, project_id, graph, memory, layers_used
        )


def _format_toc_shallow(
    target: str,
    file_loc: int,
    func_count: int,
    functions: list[dict],
    layers_used: list[str],
    warnings_count: int,
) -> tuple[str, list[str], int]:
    """Format shallow TOC: names + line ranges only. Target: ~50 tokens."""
    lines = [f"{target} ({file_loc} LOC, {func_count} functions):"]

    for fn in functions:
        name = fn.get("name", "?")
        cls = fn.get("class_name")
        start = fn.get("line_start", 0)
        end = fn.get("line_end", 0)

        if cls:
            lines.append(f"  {cls}.{name} ({start}-{end})")
        else:
            lines.append(f"  {name} ({start}-{end})")

    response = "\n".join(lines)
    return (response, layers_used, warnings_count)


async def _format_toc_standard(
    target: str,
    file_loc: int,
    func_count: int,
    functions: list[dict],
    project_id: str,
    graph: TalonGraph,
    memory: MemoryStore,
    layers_used: list[str],
) -> tuple[str, list[str], int]:
    """Format standard TOC: + params, warnings, related files. Target: ~200 tokens."""
    warnings_count = 0
    lines = [f"{target} ({file_loc} LOC, {func_count} functions):"]

    # Get hotspot data for warnings (if available)
    hotspot_data = {}
    try:
        hotspot_results = await graph.query(
            """FOR h IN talon_hotspots
               FILTER h.project_id == @pid AND h.file_path == @path
               RETURN {function_name: h.function_name, changes_30d: h.changes_30d,
                       last_changed: h.last_changed}""",
            {"pid": project_id, "path": target},
        )
        for h in hotspot_results:
            hotspot_data[h.get("function_name", "")] = h
    except Exception:
        pass  # Hotspot data is optional

    # Compute relative hotspot threshold (p80, minimum 3)
    all_changes = [(h.get("changes_30d") or 0) for h in hotspot_data.values() if (h.get("changes_30d") or 0) > 0]
    if all_changes:
        all_changes_sorted = sorted(all_changes)
        p80_idx = min(int(len(all_changes_sorted) * 0.8), len(all_changes_sorted) - 1)
        hotspot_threshold = max(3, all_changes_sorted[p80_idx])
    else:
        hotspot_threshold = 3

    # Get test coverage data for untested warnings
    tested_functions: set[str] = set()
    has_any_test_data = False
    try:
        module_key = _file_path_to_module(target)
        test_results = await graph.query(
            """FOR f IN talon_functions
               FILTER f.module == @module AND f.project_id == @pid
               FOR t IN 1..1 INBOUND f talon_tests
               RETURN DISTINCT f.name""",
            {"module": module_key, "pid": project_id},
        )
        if test_results:
            has_any_test_data = True
            tested_functions = {n for n in test_results if n}
    except Exception:
        pass

    for fn in functions:
        name = fn.get("name", "?")
        cls = fn.get("class_name")
        start = fn.get("line_start", 0)
        end = fn.get("line_end", 0)
        params = fn.get("params") or []
        return_type = fn.get("return_type")
        is_async = fn.get("is_async", False)

        # Build signature
        prefix = "async " if is_async else ""
        cls_prefix = f"{cls}." if cls else ""
        param_str = ", ".join(params[:4])
        if len(params) > 4:
            param_str += ", ..."
        ret_str = f" -> {return_type}" if return_type else ""
        sig = f"{prefix}{cls_prefix}{name}({param_str}){ret_str}"

        line = f"  {sig} ({start}-{end})"

        # Hotspot warning (relative threshold)
        hotspot = hotspot_data.get(name, {})
        changes = hotspot.get("changes_30d", 0)
        if changes and changes >= hotspot_threshold:
            line += f" !! {changes} changes/30d"
            warnings_count += 1

        # Untested warning (only if some test data exists in graph)
        if has_any_test_data and name not in tested_functions and fn.get("type") != "class":
            line += " !! untested"
            warnings_count += 1

        lines.append(line)

    # Add related files (co-change partners)
    try:
        co_changes = await graph.query(
            """FOR v, e IN 1..1 OUTBOUND
               CONCAT('talon_files/', @file_key) talon_co_changes
               FILTER e.project_id == @pid
               SORT e.correlation DESC
               LIMIT 3
               RETURN {path: v.path, correlation: e.correlation}""",
            {"file_key": f"{project_id}:{target}", "pid": project_id},
        )
        if co_changes:
            related = ", ".join(f"{c['path']}" for c in co_changes)
            lines.append(f"  Related: {related}")
    except Exception:
        pass  # Co-change data is optional

    # Add test file reference
    try:
        test_edges = await graph.query(
            """FOR v, e IN 1..1 OUTBOUND
               CONCAT('talon_files/', @file_key) talon_tests
               FILTER e.project_id == @pid
               LIMIT 1
               RETURN {path: v.path}""",
            {"file_key": f"{project_id}:{target}", "pid": project_id},
        )
        if test_edges:
            lines.append(f"  Tested by: {test_edges[0]['path']}")
    except Exception:
        pass

    response = "\n".join(lines)
    return (response, layers_used, warnings_count)


async def _format_toc_full(
    target: str,
    file_loc: int,
    func_count: int,
    functions: list[dict],
    project_id: str,
    graph: TalonGraph,
    memory: MemoryStore,
    layers_used: list[str],
) -> tuple[str, list[str], int]:
    """Format full TOC: + source snippets, temporal detail. Target: ~800 tokens."""
    # Start with standard content
    response_text, layers, warnings_count = await _format_toc_standard(
        target, file_loc, func_count, functions, project_id, graph, memory, layers_used
    )

    # Add source snippets from memory store if available
    if memory.get_file_loc(target) > 0:
        layers_used.append("L1")
        snippet_lines = [response_text, "", "Source snippets:"]
        for fn in functions[:5]:  # Limit to first 5 functions
            name = fn.get("name", "?")
            start = fn.get("line_start", 0)
            end = fn.get("line_end", 0)
            # Get first 3 lines of function
            src_lines = memory.get_lines(target, start, min(start + 2, end))
            if src_lines:
                snippet_lines.append(f"  {name}:")
                for sl in src_lines:
                    snippet_lines.append(f"    {sl.rstrip()}")

        response_text = "\n".join(snippet_lines)

    return (response_text, layers_used, warnings_count)


# ---------------------------------------------------------------------------
# Edit-Aware TOC (IMP-7)
# ---------------------------------------------------------------------------


def _format_toc_edit(
    target: str,
    file_loc: int,
    func_count: int,
    functions: list[dict],
    memory: MemoryStore,
    layers_used: list[str],
) -> tuple[str, list[str], int]:
    """Format edit TOC: signature + first 2-3 body lines per function.

    Designed for edit tasks — provides enough context to craft an Edit
    old_string match without requiring a full file Read.
    Target: ~600 tokens.
    """
    header = f"{target} ({file_loc} LOC, {func_count} functions):"
    lines = [header]

    has_cache = memory.get_file_loc(target) > 0
    if has_cache:
        layers_used.append("L1")

    current_class = None
    for fn in functions:
        name = fn.get("name", "?")
        start = fn.get("line_start", 0)
        end = fn.get("line_end", 0)
        fn_type = fn.get("type", "function")
        class_name = fn.get("class_name")

        # Show class grouping
        if class_name and class_name != current_class:
            current_class = class_name
            lines.append(f"  class {class_name}:")
        elif not class_name and current_class:
            current_class = None

        indent = "    " if class_name else "  "
        lines.append(f"{indent}{name} ({start}-{end}):")

        # Get the signature line + body lines from cache
        # TALON_EDIT_BODY_LINES env var controls how many body lines (default 3, Path K uses 6)
        body_lines = int(os.environ.get("TALON_EDIT_BODY_LINES", "3"))
        if has_cache:
            preview_end = min(start + body_lines, end)
            src_lines = memory.get_lines(target, start, preview_end)
            if src_lines:
                for sl in src_lines:
                    lines.append(f"{indent}  {sl.rstrip()}")

    return ("\n".join(lines), layers_used, 0)


# ---------------------------------------------------------------------------
# Directory TOC (IMP-2)
# ---------------------------------------------------------------------------


def _build_directory_toc(
    target: str, depth: str, memory: MemoryStore
) -> tuple[str, list[str], int]:
    """Build table-of-contents for a directory listing its files and symbols."""
    files = memory.get_files_by_prefix(target)
    if not files:
        return (_not_found_suggestions(target, "directory"), [], 0)

    total_loc = sum(loc for _, loc, _ in files)
    total_syms = sum(sc for _, _, sc in files)
    lines = [f"{target.rstrip('/')}/ ({len(files)} files, {total_loc} LOC, {total_syms} symbols):"]

    if depth == "shallow":
        for path, loc, sym_count in files:
            lines.append(f"  {path} ({loc} LOC, {sym_count} fns)")
    elif depth == "standard":
        for path, loc, sym_count in files:
            lines.append(f"  {path} ({loc} LOC, {sym_count} fns)")
            syms = memory.get_file_symbols(path)
            if syms:
                names = [s["name"] for s in syms[:5]]
                suffix = ", ..." if len(syms) > 5 else ""
                lines.append(f"    {', '.join(names)}{suffix}")
    else:  # full
        for path, loc, sym_count in files:
            lines.append(f"  {path} ({loc} LOC, {sym_count} fns)")
            syms = memory.get_file_symbols(path)
            for s in syms:
                cls = s.get("class_name")
                name = f"{cls}.{s['name']}" if cls else s["name"]
                lines.append(f"    {name} ({s['line_start']}-{s['line_end']})")

    return ("\n".join(lines), ["L1"], 0)


# ---------------------------------------------------------------------------
# Locate Intent (Phase 2+)
# ---------------------------------------------------------------------------


async def _build_locate_response(
    target: str, depth: str, project_id: str, graph: TalonGraph, memory: MemoryStore, hops: int | None = None,
) -> tuple[str, list[str], int]:
    """Phase 2: Symbol location via inverted index with fuzzy fallback.

    Search strategy: exact → case-insensitive → prefix → substring.
    Depth controls how much detail is returned per hit.

    Supports comma-separated multi-locate: "sym1, sym2, sym3" runs each
    through the full locate pipeline and concatenates results.
    """
    # --- Multi-locate: comma-separated symbols ---
    symbols = [s.strip() for s in target.split(",") if s.strip()]
    if len(symbols) > 1:
        all_lines: list[str] = []
        all_layers: list[str] = []
        total_warnings = 0
        found = 0
        not_found_syms: list[str] = []
        for sym in symbols[:10]:  # cap at 10 symbols per call
            text, layers, warns = await _build_locate_response(
                sym, depth, project_id, graph, memory, hops,
            )
            total_warnings += warns
            for la in layers:
                if la not in all_layers:
                    all_layers.append(la)
            if "not found" in text.lower():
                not_found_syms.append(sym)
            else:
                found += 1
                all_lines.append(text)
        header = f"Multi-locate: {found}/{len(symbols)} symbols resolved"
        if not_found_syms:
            header += f" (not found: {', '.join(not_found_syms)})"
        return (header + "\n\n" + "\n\n".join(all_lines), all_layers, total_warnings)

    layers_used: list[str] = []
    warnings_count = 0

    # --- Dotted target splitting (e.g. "Task.apply" → class_hint="Task", method="apply") ---
    class_hint: str | None = None
    search_name = target
    if "." in target and not target.startswith("."):
        parts = target.rsplit(".", 1)
        if len(parts) == 2 and parts[0].isidentifier() and parts[1].isidentifier():
            class_hint, search_name = parts[0], parts[1]

    # --- Search via fuzzy locate (exact → prefix → substring) ---
    # Widen search for dotted targets — common names like 'get', 'apply' have 50+ hits
    # and the class-specific one may be beyond max_results=15.
    search_limit = 50 if class_hint else 15
    results = memory.locate_symbol_fuzzy(search_name, max_results=search_limit)

    # If dotted target, filter results by class_name from symbol metadata.
    if class_hint and results:
        hint_lower = class_hint.lower()
        filtered = []
        for fp, ln, kind in results:
            # Primary: check class_name in symbol metadata
            sym = memory.get_symbol_at(fp, ln)
            if sym and (sym.get("class_name") or "").lower() == hint_lower:
                filtered.append((fp, ln, kind))
            # Fallback: file path match (module.Class patterns)
            elif hint_lower in fp.lower() or any(
                hint_lower == seg.lower()
                for seg in fp.replace("/", ".").replace("\\", ".").split(".")
            ):
                filtered.append((fp, ln, kind))
        if not filtered:
            # Fall through to graph which can filter by class_name
            results = []
        else:
            results = filtered

    if not results:
        # Try graph as last resort (supports class_name filtering for dotted targets)
        try:
            aql = """FOR f IN talon_functions
                   FILTER LOWER(f.name) == LOWER(@name) AND f.project_id == @pid"""
            bind = {"name": search_name, "pid": project_id}
            if class_hint:
                aql += "\n                   FILTER LOWER(f.class_name) == LOWER(@cls)"
                bind["cls"] = class_hint
            aql += """
                   RETURN {name: f.name, module: f.module, line_start: f.line_start,
                           class_name: f.class_name, params: f.params, return_type: f.return_type}"""
            graph_results = await graph.query(aql, bind)
            if not graph_results and class_hint:
                # Retry without class filter — dotted prefix may be a module, not a class
                graph_results = await graph.query(
                    """FOR f IN talon_functions
                       FILTER LOWER(f.name) == LOWER(@name) AND f.project_id == @pid
                       RETURN {name: f.name, module: f.module, line_start: f.line_start,
                               class_name: f.class_name, params: f.params, return_type: f.return_type}""",
                    {"name": search_name, "pid": project_id},
                )
            if graph_results:
                layers_used.append("graph")
                label = f"'{target}'" if class_hint else f"'{target}'"
                lines = [f"Symbol {label} found in {len(graph_results)} locations (via graph):"]
                for r in graph_results[:10]:
                    mod = r.get("module", "?").replace(".", "/") + ".py"
                    cls = r.get("class_name", "")
                    suffix = f" ({cls})" if cls else ""
                    lines.append(f"  {mod}:{r.get('line_start', '?')}{suffix}")
                return ("\n".join(lines), layers_used, 0)
        except Exception:
            pass
        return (_not_found_suggestions(target, "symbol"), [], 0)

    layers_used.append("L2")

    # --- Count by match kind ---
    exact_count = sum(1 for _, _, k in results if k == "exact")
    match_note = ""
    if exact_count == 0:
        kinds = {k for _, _, k in results}
        if "prefix" in kinds:
            match_note = " (prefix match)"
        elif "substring" in kinds:
            match_note = " (substring match)"

    # --- Shallow: just file:line ---
    if depth == "shallow":
        lines = [f"Symbol '{target}' found in {len(results)} locations{match_note}:"]
        for fp, ln, kind in results:
            suffix = "" if kind == "exact" else f" [{kind}]"
            lines.append(f"  {fp}:{ln}{suffix}")
        return ("\n".join(lines), layers_used, 0)

    # --- Standard: + type, signature, callers count, warnings ---
    if depth == "standard":
        return await _format_locate_standard(
            target, results, match_note, project_id, graph, memory, layers_used
        )

    # --- Full: + source snippets, caller names, temporal ---
    return await _format_locate_full(
        target, results, match_note, project_id, graph, memory, layers_used
    )


async def _format_locate_standard(
    target: str,
    results: list[tuple[str, int, str]],
    match_note: str,
    project_id: str,
    graph: TalonGraph,
    memory: MemoryStore,
    layers_used: list[str],
) -> tuple[str, list[str], int]:
    """Format locate at standard depth: + signature, callers count, warnings."""
    warnings_count = 0
    lines = [f"Symbol '{target}' found in {len(results)} locations{match_note}:"]

    for fp, ln, kind in results:
        # Get symbol metadata from memory
        sym = memory.get_symbol_at(fp, ln)
        suffix = "" if kind == "exact" else f" [{kind}]"

        if sym:
            sym_type = sym.get("type", "?")
            name = sym.get("name", target)
            sig_line = f"  {fp}:{ln} ({sym_type}{suffix})"

            # Try to get signature from file lines
            src_line = memory.get_lines(fp, ln, ln)
            if src_line:
                sig = src_line[0].strip()
                # Truncate long signatures
                if len(sig) > 80:
                    sig = sig[:77] + "..."
                sig_line += f"\n    {sig}"
                layers_used_set = set(layers_used)
                if "L1" not in layers_used_set:
                    layers_used.append("L1")
        else:
            sig_line = f"  {fp}:{ln}{suffix}"

        # Callers: enriched (≤3 results) or count-only (>3 results)
        if len(results) <= 3:
            # Auto-enrich: caller names + function body
            fn_nodes = await _find_function_nodes(
                sym.get("name", target) if sym else target, project_id, graph
            )
            if fn_nodes:
                # Pick the node matching this file path
                fn_key = None
                for fn in fn_nodes:
                    fn_mod = fn.get("module", "")
                    if fp in _module_to_path(fn_mod) or _module_to_path(fn_mod) in fp:
                        fn_key = fn["_key"]
                        break
                if fn_key is None:
                    fn_key = fn_nodes[0]["_key"]
                try:
                    callers = await graph.query(
                        """FOR v IN 1..1 INBOUND
                           CONCAT('talon_functions/', @fkey) talon_calls
                           RETURN {name: v.name, module: v.module,
                                   class_name: v.class_name, line_start: v.line_start}""",
                        {"fkey": fn_key},
                    )
                    if callers:
                        caller_strs = []
                        for c in callers[:5]:
                            cname = f"{c['class_name']}.{c['name']}" if c.get("class_name") else c["name"]
                            cpath = _module_to_path(c.get("module", ""))
                            caller_strs.append(f"{cname} ({cpath}:{c.get('line_start', '?')})")
                        sig_line += f"\n    Callers: {', '.join(caller_strs)}"
                        if "graph" not in layers_used:
                            layers_used.append("graph")
                except Exception:
                    pass

            # Function body via L1 lines (capped at 15 lines)
            if sym:
                body_start = sym.get("line_start", ln)
                body_end = min(sym.get("line_end", body_start + 10), body_start + 14)
                body_lines = memory.get_lines(fp, body_start, body_end)
                if body_lines:
                    sig_line += "\n    Source:"
                    for bl in body_lines:
                        sig_line += f"\n      {bl.rstrip()}"
                    if "L1" not in set(layers_used):
                        layers_used.append("L1")
        else:
            # Count-only for >3 results
            try:
                callers_result = await graph.query(
                    """FOR v IN 1..1 INBOUND
                       CONCAT('talon_functions/', @fkey) talon_calls
                       COLLECT WITH COUNT INTO cnt
                       RETURN cnt""",
                    {"fkey": f"{project_id}:{fp}:{target}"},
                )
                callers_count = callers_result[0] if callers_result else 0
                if callers_count > 0:
                    sig_line += f" ({callers_count} callers)"
                    if "graph" not in layers_used:
                        layers_used.append("graph")
            except Exception:
                pass

        # Hotspot warnings
        try:
            hotspot = await graph.query(
                """FOR h IN talon_hotspots
                   FILTER h.project_id == @pid AND h.file_path == @path
                   AND h.function_name == @fname
                   RETURN {changes_30d: h.changes_30d}""",
                {"pid": project_id, "path": fp, "fname": sym.get("name", target) if sym else target},
            )
            if hotspot and hotspot[0].get("changes_30d", 0) > 10:
                changes = hotspot[0]["changes_30d"]
                sig_line += f" !! {changes} changes/30d"
                warnings_count += 1
        except Exception:
            pass

        lines.append(sig_line)

    # Related files (files containing the same symbol)
    unique_files = list(dict.fromkeys(fp for fp, _, _ in results))
    if len(unique_files) > 1:
        lines.append(f"  Appears in: {', '.join(unique_files)}")

    return ("\n".join(lines), layers_used, warnings_count)


async def _format_locate_full(
    target: str,
    results: list[tuple[str, int, str]],
    match_note: str,
    project_id: str,
    graph: TalonGraph,
    memory: MemoryStore,
    layers_used: list[str],
) -> tuple[str, list[str], int]:
    """Format locate at full depth: + source snippets, caller names."""
    warnings_count = 0
    lines = [f"Symbol '{target}' found in {len(results)} locations{match_note}:"]

    for fp, ln, kind in results[:10]:  # Cap at 10 for full depth
        sym = memory.get_symbol_at(fp, ln)
        suffix = "" if kind == "exact" else f" [{kind}]"

        if sym:
            sym_type = sym.get("type", "?")
            name = sym.get("name", target)
            lines.append(f"  {fp}:{ln} ({sym_type}{suffix})")

            # Full body only when single match — multiple results use 4-line snippet
            start = sym.get("line_start", ln)
            if len(results) == 1:
                end = min(sym.get("line_end", start + 50), start + 50)
            else:
                end = min(start + 3, start + 3)
            src_lines = memory.get_lines(fp, start, end)
            if src_lines:
                for sl in src_lines:
                    lines.append(f"    {sl.rstrip()}")
                if "L1" not in layers_used:
                    layers_used.append("L1")
        else:
            lines.append(f"  {fp}:{ln}{suffix}")
            # Show lines around the hit
            src_lines = memory.get_lines(fp, ln, min(ln + 2, ln + 2))
            if src_lines:
                for sl in src_lines:
                    lines.append(f"    {sl.rstrip()}")
                if "L1" not in layers_used:
                    layers_used.append("L1")

        # Caller names from graph (use _find_function_nodes for correct _key)
        fn_nodes = await _find_function_nodes(
            sym.get("name", target) if sym else target, project_id, graph
        )
        if fn_nodes:
            fn_key = None
            for fn in fn_nodes:
                fn_mod = fn.get("module", "")
                if fp in _module_to_path(fn_mod) or _module_to_path(fn_mod) in fp:
                    fn_key = fn["_key"]
                    break
            if fn_key is None:
                fn_key = fn_nodes[0]["_key"]
            try:
                callers = await graph.query(
                    """FOR v IN 1..1 INBOUND
                       CONCAT('talon_functions/', @fkey) talon_calls
                       RETURN v.name""",
                    {"fkey": fn_key},
                )
                if callers:
                    caller_names = [c for c in callers if c][:5]
                    if caller_names:
                        lines.append(f"    Callers: {', '.join(caller_names)}")
                        if "graph" not in layers_used:
                            layers_used.append("graph")
            except Exception:
                pass

    return ("\n".join(lines), layers_used, warnings_count)


# ---------------------------------------------------------------------------
# Callers Intent (Phase 4)
# ---------------------------------------------------------------------------


async def _find_function_nodes(
    target: str, project_id: str, graph: TalonGraph
) -> list[dict[str, Any]]:
    """Find function nodes by name. Returns list of function docs."""
    try:
        return await graph.query(
            """FOR f IN talon_functions
               FILTER f.name == @name AND f.project_id == @pid
               RETURN {
                   _key: f._key, name: f.name, module: f.module,
                   class_name: f.class_name, line_start: f.line_start,
                   line_end: f.line_end, params: f.params,
                   return_type: f.return_type, is_async: f.is_async
               }""",
            {"name": target, "pid": project_id},
        )
    except Exception:
        return []


def _module_to_path(module: str) -> str:
    """Convert dotted module name to file path.

    src.talon.mcp.server → src/talon/mcp/server.py
    talon.mcp.server     → src/talon/mcp/server.py
    """
    if not module:
        return module
    parts = module.split(".")
    # If the module already starts with 'src', don't add it again
    if parts[0] == "src":
        return "/".join(parts) + ".py"
    return "/".join(["src"] + parts) + ".py"


async def _build_callers_response(
    target: str, depth: str, project_id: str, graph: TalonGraph, memory: MemoryStore, hops: int | None = None,
) -> tuple[str, list[str], int]:
    """Phase 4: Who calls this function — upstream dependency chain.

    Traverses talon_calls edges INBOUND to find all callers.
    """
    layers_used: list[str] = []
    warnings_count = 0

    # Find the target function(s) in the graph
    fn_nodes = await _find_function_nodes(target, project_id, graph)

    if not fn_nodes:
        # Fall back to memory store to confirm the symbol exists
        locations = memory.locate_symbol(target)
        if locations:
            lines = [f"'{target}' found in memory cache but not in graph (re-index needed):"]
            for fp, ln in locations[:5]:
                lines.append(f"  {fp}:{ln}")
            return ("\n".join(lines), ["L2"], 0)
        return (_not_found_suggestions(target, "function"), [], 0)

    layers_used.append("graph")
    all_lines: list[str] = []

    # Multi-hop traversal: single AQL query across N hops
    if hops and hops > 1:
        max_hops = min(hops, 5)
        fn = fn_nodes[0]
        fn_key = fn["_key"]
        fn_class = fn.get("class_name")
        fn_display = f"{fn_class}.{target}" if fn_class else target
        try:
            chain = await graph.query(
                """FOR v, e, p IN 1..@max_hops INBOUND
                   CONCAT('talon_functions/', @fkey) talon_calls
                   LET hop = LENGTH(p.edges)
                   SORT hop ASC, v.module ASC, v.name ASC
                   LIMIT 30
                   RETURN DISTINCT {
                       name: v.name, module: v.module,
                       class_name: v.class_name,
                       line_start: v.line_start,
                       hop: hop
                   }""",
                {"fkey": fn_key, "max_hops": max_hops},
            )
        except Exception:
            chain = []
        # Group by hop level
        by_hop: dict[int, list[dict]] = {}
        for c in chain:
            h = c.get("hop", 1)
            by_hop.setdefault(h, []).append(c)
        direct_count = len(by_hop.get(1, []))
        total_count = len(chain)
        all_lines.append(
            f"Callers of '{fn_display}' ({direct_count} direct, {total_count} total across {max_hops} hops):"
        )
        for h in sorted(by_hop):
            for c in by_hop[h][:10]:
                c_name = c.get("name", "?")
                c_class = c.get("class_name")
                c_display = f"{c_class}.{c_name}" if c_class else c_name
                c_path = _module_to_path(c.get("module", ""))
                c_line = c.get("line_start", "?")
                all_lines.append(f"  [hop {h}] {c_display}  {c_path}:{c_line}")
        return ("\n".join(all_lines) if all_lines else f"No callers found for '{target}'.", layers_used, 0)

    for fn in fn_nodes:
        fn_key = fn["_key"]
        fn_module = fn.get("module", "")
        fn_class = fn.get("class_name")
        fn_display = f"{fn_class}.{target}" if fn_class else target
        fn_path = _module_to_path(fn_module)

        # Query callers
        try:
            callers = await graph.query(
                """FOR caller, edge IN 1..1 INBOUND
                   CONCAT('talon_functions/', @fkey) talon_calls
                   RETURN {
                       name: caller.name, module: caller.module,
                       class_name: caller.class_name,
                       line_start: caller.line_start, line_end: caller.line_end,
                       params: caller.params, is_async: caller.is_async,
                       call_line: edge.line_number,
                       cross_module: edge.cross_module
                   }""",
                {"fkey": fn_key},
            )
        except Exception:
            callers = []

        if depth == "shallow":
            all_lines.append(f"Callers of '{fn_display}' ({len(callers)} callers):")
            for c in callers[:15]:
                c_name = c.get("name", "?")
                c_class = c.get("class_name")
                c_display = f"{c_class}.{c_name}" if c_class else c_name
                c_path = _module_to_path(c.get("module", ""))
                c_line = c.get("line_start", "?")
                all_lines.append(f"  {c_display}  {c_path}:{c_line}")

        elif depth == "standard":
            # Group by module
            modules: dict[str, list[dict]] = {}
            for c in callers:
                mod = c.get("module", "unknown")
                modules.setdefault(mod, []).append(c)

            all_lines.append(
                f"Callers of '{fn_display}' ({len(callers)} callers, {len(modules)} modules):"
            )
            for c in callers[:15]:
                c_name = c.get("name", "?")
                c_class = c.get("class_name")
                c_display = f"{c_class}.{c_name}" if c_class else c_name
                c_path = _module_to_path(c.get("module", ""))
                c_line_start = c.get("line_start", "?")
                cross = "  [cross-module]" if c.get("cross_module") else ""
                all_lines.append(f"  {c_display}  {c_path}:{c_line_start}{cross}")

                # Show call site line
                call_line = c.get("call_line")
                if call_line and memory.get_file_loc(c_path) > 0:
                    src = memory.get_lines(c_path, call_line, call_line)
                    if src:
                        all_lines.append(f"    calls at line {call_line}: {src[0].strip()}")
                        if "L1" not in layers_used:
                            layers_used.append("L1")

            if len(modules) > 1:
                mod_summary = ", ".join(
                    f"{m.split('.')[-1]} ({len(fns)})" for m, fns in modules.items()
                )
                all_lines.append(f"  Modules: {mod_summary}")

        else:  # full
            # Get transitive callers (2 hops)
            try:
                transitive = await graph.query(
                    """FOR caller IN 2..2 INBOUND
                       CONCAT('talon_functions/', @fkey) talon_calls
                       RETURN DISTINCT caller.name""",
                    {"fkey": fn_key},
                )
                transitive_names = [n for n in transitive if n and n not in {c.get("name") for c in callers}]
            except Exception:
                transitive_names = []

            total = len(callers) + len(transitive_names)
            all_lines.append(
                f"Callers of '{fn_display}' ({len(callers)} direct, {total} total):"
            )
            for c in callers[:10]:
                c_name = c.get("name", "?")
                c_class = c.get("class_name")
                c_display = f"{c_class}.{c_name}" if c_class else c_name
                c_path = _module_to_path(c.get("module", ""))
                c_start = c.get("line_start", 0)
                c_end = c.get("line_end", c_start)
                all_lines.append(f"  {c_display}  {c_path}:{c_start}")

                # Source snippet
                if c_start and memory.get_file_loc(c_path) > 0:
                    src = memory.get_lines(c_path, c_start, min(c_start + 2, c_end))
                    if src:
                        for sl in src:
                            all_lines.append(f"    {sl.rstrip()}")
                        if "L1" not in layers_used:
                            layers_used.append("L1")

            if transitive_names:
                all_lines.append(f"  Transitive ({len(transitive_names)}): {', '.join(transitive_names[:10])}")

    if not all_lines:
        return (f"No callers found for '{target}'.", layers_used, 0)

    return ("\n".join(all_lines), layers_used, warnings_count)


# ---------------------------------------------------------------------------
# Blast Radius Intent (Phase 4)
# ---------------------------------------------------------------------------


async def _build_blast_response(
    target: str, depth: str, project_id: str, graph: TalonGraph, memory: MemoryStore, hops: int | None = None,
) -> tuple[str, list[str], int]:
    """Phase 4: Blast radius — what breaks if this function/file changes.

    Traverses talon_calls INBOUND (who calls target) and checks test coverage.
    """
    layers_used: list[str] = []
    warnings_count = 0

    # Determine if target is a file path or function name
    is_file = "/" in target or target.endswith(".py") or target.endswith(".ts")

    if is_file:
        return await _blast_for_file(target, depth, project_id, graph, memory)

    # Function-level blast radius
    fn_nodes = await _find_function_nodes(target, project_id, graph)
    if not fn_nodes:
        locations = memory.locate_symbol(target)
        if locations:
            return (f"'{target}' in cache but not in graph (re-index needed). Found at: {locations[0][0]}:{locations[0][1]}", ["L2"], 0)
        return (_not_found_suggestions(target, "function"), [], 0)

    layers_used.append("graph")
    fn = fn_nodes[0]  # Use first match
    fn_key = fn["_key"]
    fn_class = fn.get("class_name")
    fn_display = f"{fn_class}.{target}" if fn_class else target

    # Direct callers (hop 1)
    try:
        direct = await graph.query(
            """FOR caller, edge IN 1..1 INBOUND
               CONCAT('talon_functions/', @fkey) talon_calls
               RETURN {
                   _key: caller._key, name: caller.name, module: caller.module,
                   class_name: caller.class_name, line_start: caller.line_start
               }""",
            {"fkey": fn_key},
        )
    except Exception:
        direct = []

    # Indirect callers (hop 2)
    try:
        indirect = await graph.query(
            """FOR caller IN 2..2 INBOUND
               CONCAT('talon_functions/', @fkey) talon_calls
               RETURN DISTINCT {
                   name: caller.name, module: caller.module,
                   class_name: caller.class_name, line_start: caller.line_start
               }""",
            {"fkey": fn_key},
        )
        # Deduplicate against direct callers
        direct_names = {d.get("name") for d in direct}
        indirect = [i for i in indirect if i.get("name") not in direct_names]
    except Exception:
        indirect = []

    # Check test coverage for each direct caller
    tested_fns: set[str] = set()
    untested_fns: list[str] = []
    for d in direct:
        d_key = d.get("_key", "")
        try:
            tests = await graph.query(
                """FOR t IN 1..1 INBOUND
                   CONCAT('talon_functions/', @fkey) talon_tests
                   LIMIT 1 RETURN 1""",
                {"fkey": d_key},
            )
            if tests:
                tested_fns.add(d.get("name", ""))
            else:
                untested_fns.append(d.get("name", "?"))
                warnings_count += 1
        except Exception:
            pass

    # Collect affected files
    affected_files: set[str] = set()
    for d in direct + indirect:
        mod = d.get("module", "")
        if mod:
            affected_files.add(_module_to_path(mod))

    # Format response
    total = len(direct) + len(indirect)
    lines: list[str] = []

    if depth == "shallow":
        lines.append(f"Blast radius for '{fn_display}' ({total} affected, {len(affected_files)} files):")
        if direct:
            direct_names_list = [f"{d.get('class_name', '')}.{d['name']}" if d.get('class_name') else d['name'] for d in direct]
            lines.append(f"  Direct ({len(direct)}): {', '.join(direct_names_list[:10])}")
        if indirect:
            indirect_names = [i.get("name", "?") for i in indirect]
            lines.append(f"  Indirect ({len(indirect)}): {', '.join(indirect_names[:10])}")

    elif depth == "standard":
        risk = "HIGH" if len(untested_fns) > 2 else "MEDIUM" if untested_fns else "LOW"
        lines.append(f"Blast radius for '{fn_display}' ({total} affected, {len(affected_files)} files):")
        if direct:
            lines.append(f"  Direct callers ({len(direct)}):")
            for d in direct[:10]:
                d_name = d.get("name", "?")
                d_class = d.get("class_name")
                d_display = f"{d_class}.{d_name}" if d_class else d_name
                d_path = _module_to_path(d.get("module", ""))
                tested = "[tested]" if d_name in tested_fns else "!! UNTESTED"
                lines.append(f"    {d_display}  {d_path}:{d.get('line_start', '?')}  {tested}")
        if indirect:
            indirect_names = [i.get("name", "?") for i in indirect]
            lines.append(f"  Indirect (hop 2, {len(indirect)} functions): {', '.join(indirect_names[:10])}")
        lines.append(f"  Risk: {risk} — {len(untested_fns)} untested direct callers")
        if affected_files:
            lines.append(f"  Files affected: {', '.join(sorted(affected_files)[:8])}")

    else:  # full
        risk = "HIGH" if len(untested_fns) > 2 else "MEDIUM" if untested_fns else "LOW"
        lines.append(f"Blast radius for '{fn_display}' ({total} affected, {len(affected_files)} files):")
        if direct:
            lines.append(f"  Hop 1 — Direct callers ({len(direct)}):")
            for d in direct[:8]:
                d_name = d.get("name", "?")
                d_class = d.get("class_name")
                d_display = f"{d_class}.{d_name}" if d_class else d_name
                d_path = _module_to_path(d.get("module", ""))
                tested_label = "[tested]" if d_name in tested_fns else "!! UNTESTED"
                lines.append(f"    {d_display}  {d_path}:{d.get('line_start', '?')}  {tested_label}")

                # Source snippet
                d_start = d.get("line_start", 0)
                if d_start and memory.get_file_loc(d_path) > 0:
                    src = memory.get_lines(d_path, d_start, min(d_start + 1, d_start + 1))
                    if src:
                        lines.append(f"      {src[0].strip()}")
                        if "L1" not in layers_used:
                            layers_used.append("L1")

        if indirect:
            lines.append(f"  Hop 2 — Transitive ({len(indirect)}):")
            for i in indirect[:8]:
                i_name = i.get("name", "?")
                i_path = _module_to_path(i.get("module", ""))
                lines.append(f"    {i_name}  {i_path}:{i.get('line_start', '?')}")

        lines.append(f"  Risk: {risk}")

    return ("\n".join(lines), layers_used, warnings_count)


async def _blast_for_file(
    target: str, depth: str, project_id: str, graph: TalonGraph, memory: MemoryStore
) -> tuple[str, list[str], int]:
    """Blast radius for a file — which other files depend on it."""
    layers_used: list[str] = ["graph"]

    try:
        # Find files that depend on this file (INBOUND on talon_depends_on)
        dependents = await graph.query(
            """FOR file IN talon_files FILTER file.path == @path AND file.project_id == @pid
               FOR dep_file, edge IN 1..1 INBOUND file talon_depends_on
               RETURN {path: dep_file.path, import_count: edge.import_count}""",
            {"path": target, "pid": project_id},
        )
    except Exception:
        dependents = []

    if not dependents:
        loc = memory.get_file_loc(target)
        if loc > 0:
            return (f"File '{target}' ({loc} LOC) — no dependents found in graph (may need re-index).", ["L2"], 0)
        return (_not_found_suggestions(target, "file"), [], 0)

    lines = [f"Blast radius for '{target}' ({len(dependents)} dependent files):"]
    for d in dependents[:15]:
        path = d.get("path", "?")
        imports = d.get("import_count", 0)
        suffix = f" ({imports} imports)" if imports and depth != "shallow" else ""
        lines.append(f"  {path}{suffix}")

    return ("\n".join(lines), layers_used, 0)


# ---------------------------------------------------------------------------
# Coverage Intent (Phase 4)
# ---------------------------------------------------------------------------


async def _build_coverage_response(
    target: str, depth: str, project_id: str, graph: TalonGraph, memory: MemoryStore, hops: int | None = None,
) -> tuple[str, list[str], int]:
    """Phase 4: Test coverage — which tests cover this function.

    Traverses talon_tests edges INBOUND to find test functions.
    """
    layers_used: list[str] = []
    warnings_count = 0

    fn_nodes = await _find_function_nodes(target, project_id, graph)
    if not fn_nodes:
        locations = memory.locate_symbol(target)
        if locations:
            return (f"'{target}' in cache but not in graph (re-index needed).", ["L2"], 0)
        return (_not_found_suggestions(target, "function"), [], 0)

    layers_used.append("graph")
    fn = fn_nodes[0]
    fn_key = fn["_key"]
    fn_class = fn.get("class_name")
    fn_display = f"{fn_class}.{target}" if fn_class else target

    # Find tests via talon_tests edges
    try:
        tests = await graph.query(
            """FOR test_fn, edge IN 1..1 INBOUND
               CONCAT('talon_functions/', @fkey) talon_tests
               RETURN {
                   name: test_fn.name, module: test_fn.module,
                   class_name: test_fn.class_name,
                   line_start: test_fn.line_start, line_end: test_fn.line_end
               }""",
            {"fkey": fn_key},
        )
    except Exception:
        tests = []

    # Also get callers count for coverage context
    try:
        callers_count_result = await graph.query(
            """FOR c IN 1..1 INBOUND CONCAT('talon_functions/', @fkey) talon_calls
               COLLECT WITH COUNT INTO cnt RETURN cnt""",
            {"fkey": fn_key},
        )
        callers_count = callers_count_result[0] if callers_count_result else 0
    except Exception:
        callers_count = 0

    lines: list[str] = []

    if not tests:
        warnings_count += 1
        lines.append(f"No tests found for '{fn_display}'.")
        if callers_count > 0:
            lines.append(f"  !! No tests found for '{fn_display}' — {callers_count} callers depend on it")
            lines.append(f"  Consider adding tests before modifying this function.")
        else:
            lines.append(f"  !! No tests and no callers — low-risk to modify")
        return ("\n".join(lines), layers_used, warnings_count)

    # Group tests by file
    test_files: dict[str, list[dict]] = {}
    for t in tests:
        t_path = _module_to_path(t.get("module", ""))
        test_files.setdefault(t_path, []).append(t)

    if depth == "shallow":
        lines.append(f"Tests for '{fn_display}' ({len(tests)} tests):")
        for t in tests[:15]:
            t_name = t.get("name", "?")
            t_path = _module_to_path(t.get("module", ""))
            lines.append(f"  {t_name}  {t_path}:{t.get('line_start', '?')}")

    elif depth == "standard":
        lines.append(f"Tests for '{fn_display}' ({len(tests)} tests in {len(test_files)} files):")
        for t in tests[:10]:
            t_name = t.get("name", "?")
            t_path = _module_to_path(t.get("module", ""))
            lines.append(f"  {t_name}  {t_path}:{t.get('line_start', '?')}")

            # Check what else each test covers
            try:
                also_tests = await graph.query(
                    """FOR tested IN 1..1 OUTBOUND
                       CONCAT('talon_functions/', @tkey) talon_tests
                       FILTER tested.name != @target_name
                       LIMIT 3
                       RETURN tested.name""",
                    {"tkey": t.get("_key", ""), "target_name": target},
                )
                if also_tests:
                    also_names = [n for n in also_tests if n]
                    if also_names:
                        lines.append(f"    Also tests: {', '.join(also_names)}")
            except Exception:
                pass

        if callers_count > 0 and len(tests) < callers_count:
            lines.append(f"  !! {callers_count} callers but only {len(tests)} tests")
            warnings_count += 1

    else:  # full
        lines.append(f"Tests for '{fn_display}' ({len(tests)} tests in {len(test_files)} files):")
        for t in tests[:8]:
            t_name = t.get("name", "?")
            t_path = _module_to_path(t.get("module", ""))
            t_start = t.get("line_start", 0)
            t_end = t.get("line_end", t_start)
            lines.append(f"  {t_name}  {t_path}:{t_start}")

            # Source snippet
            if t_start and memory.get_file_loc(t_path) > 0:
                src = memory.get_lines(t_path, t_start, min(t_start + 3, t_end))
                if src:
                    for sl in src:
                        lines.append(f"    {sl.rstrip()}")
                    if "L1" not in layers_used:
                        layers_used.append("L1")

    return ("\n".join(lines), layers_used, warnings_count)


# ---------------------------------------------------------------------------
# Flow Intent (Phase 4)
# ---------------------------------------------------------------------------


async def _build_flow_response(
    target: str, depth: str, project_id: str, graph: TalonGraph, memory: MemoryStore, hops: int | None = None,
) -> tuple[str, list[str], int]:
    """Phase 4: Execution flow — what this function calls, pre-traced paths.

    Traverses talon_calls edges OUTBOUND.
    """
    layers_used: list[str] = []
    warnings_count = 0

    fn_nodes = await _find_function_nodes(target, project_id, graph)
    if not fn_nodes:
        locations = memory.locate_symbol(target)
        if locations:
            return (f"'{target}' in cache but not in graph (re-index needed).", ["L2"], 0)
        return (_not_found_suggestions(target, "function"), [], 0)

    layers_used.append("graph")
    fn = fn_nodes[0]
    fn_key = fn["_key"]
    fn_class = fn.get("class_name")
    fn_display = f"{fn_class}.{target}" if fn_class else target

    # Multi-hop traversal: single AQL query across N hops OUTBOUND
    if hops and hops > 1:
        max_hops = min(hops, 5)
        try:
            chain = await graph.query(
                """FOR v, e, p IN 1..@max_hops OUTBOUND
                   CONCAT('talon_functions/', @fkey) talon_calls
                   LET hop = LENGTH(p.edges)
                   SORT hop ASC, v.module ASC, v.name ASC
                   LIMIT 30
                   RETURN DISTINCT {
                       name: v.name, module: v.module,
                       class_name: v.class_name,
                       line_start: v.line_start,
                       hop: hop
                   }""",
                {"fkey": fn_key, "max_hops": max_hops},
            )
        except Exception:
            chain = []
        by_hop: dict[int, list[dict]] = {}
        for c in chain:
            h = c.get("hop", 1)
            by_hop.setdefault(h, []).append(c)
        direct_count = len(by_hop.get(1, []))
        total_count = len(chain)
        lines = [
            f"Flow from '{fn_display}' ({direct_count} direct, {total_count} total across {max_hops} hops):"
        ]
        for h in sorted(by_hop):
            for c in by_hop[h][:10]:
                c_name = c.get("name", "?")
                c_class = c.get("class_name")
                c_display = f"{c_class}.{c_name}" if c_class else c_name
                c_path = _module_to_path(c.get("module", ""))
                c_line = c.get("line_start", "?")
                lines.append(f"  [hop {h}] {c_display}  {c_path}:{c_line}")
        return ("\n".join(lines) if lines else f"No flow data for '{target}'.", layers_used, 0)

    # Direct callees (hop 1)
    try:
        direct_callees = await graph.query(
            """FOR callee, edge IN 1..1 OUTBOUND
               CONCAT('talon_functions/', @fkey) talon_calls
               RETURN {
                   _key: callee._key, name: callee.name, module: callee.module,
                   class_name: callee.class_name,
                   line_start: callee.line_start, line_end: callee.line_end,
                   call_line: edge.line_number,
                   cross_module: edge.cross_module
               }""",
            {"fkey": fn_key},
        )
    except Exception:
        direct_callees = []

    if depth == "shallow":
        lines = [f"Flow from '{fn_display}' ({len(direct_callees)} calls):"]
        for c in direct_callees[:15]:
            c_name = c.get("name", "?")
            c_class = c.get("class_name")
            c_display = f"{c_class}.{c_name}" if c_class else c_name
            c_path = _module_to_path(c.get("module", ""))
            lines.append(f"  {c_display}  {c_path}:{c.get('line_start', '?')}")
        return ("\n".join(lines), layers_used, 0)

    # For standard/full, also get hop-2 callees
    hop2_total = 0
    hop2_by_parent: dict[str, list[str]] = {}  # parent_name → [callee_names]
    for dc in direct_callees[:10]:
        dc_key = dc.get("_key", "")
        dc_name = dc.get("name", "?")
        try:
            sub_callees = await graph.query(
                """FOR callee IN 1..1 OUTBOUND
                   CONCAT('talon_functions/', @fkey) talon_calls
                   RETURN callee.name""",
                {"fkey": dc_key},
            )
            if sub_callees:
                names = [n for n in sub_callees if n][:5]
                if names:
                    hop2_by_parent[dc_name] = names
                    hop2_total += len(names)
        except Exception:
            pass

    total = len(direct_callees) + hop2_total

    if depth == "standard":
        lines = [f"Flow from '{fn_display}' ({len(direct_callees)} direct, {total} total at depth 2):"]
        for c in direct_callees[:12]:
            c_name = c.get("name", "?")
            c_class = c.get("class_name")
            c_display = f"{c_class}.{c_name}" if c_class else c_name
            c_path = _module_to_path(c.get("module", ""))
            call_line = c.get("call_line")
            cross = "  [cross-module]" if c.get("cross_module") else ""
            call_note = f"  (calls at line {call_line})" if call_line else ""
            lines.append(f"  {c_display}  {c_path}:{c.get('line_start', '?')}{call_note}{cross}")

            # Sub-callees
            if c_name in hop2_by_parent:
                sub_names = hop2_by_parent[c_name]
                for sn in sub_names:
                    lines.append(f"    -> {sn}")

        return ("\n".join(lines), layers_used, 0)

    # Full depth: extend to 3-hop chains (hop-1 direct, hop-2 sub, hop-3 sub-sub)
    hop3_total = 0
    hop3_by_parent: dict[str, list[str]] = {}  # sub-callee name → [sub-sub-callee names]
    for dc in direct_callees[:10]:
        dc_key = dc.get("_key", "")
        dc_name = dc.get("name", "?")
        try:
            sub_callees_full = await graph.query(
                """FOR callee IN 1..2 OUTBOUND
                   CONCAT('talon_functions/', @fkey) talon_calls
                   RETURN DISTINCT callee.name""",
                {"fkey": dc_key},
            )
            if sub_callees_full:
                names = [n for n in sub_callees_full if n][:5]
                if names:
                    hop3_by_parent[dc_name] = names
                    hop3_total += len(names)
        except Exception:
            pass

    total_full = len(direct_callees) + hop3_total
    lines = [f"Flow from '{fn_display}' ({len(direct_callees)} direct, {total_full} total at depth 3):"]
    for c in direct_callees[:10]:
        c_name = c.get("name", "?")
        c_class = c.get("class_name")
        c_display = f"{c_class}.{c_name}" if c_class else c_name
        c_path = _module_to_path(c.get("module", ""))
        call_line = c.get("call_line")
        call_note = f"  (called at line {call_line})" if call_line else ""
        lines.append(f"  {c_display}  {c_path}:{c.get('line_start', '?')}{call_note}")

        # Source snippet
        c_start = c.get("line_start", 0)
        c_end = c.get("line_end", c_start)
        if c_start and memory.get_file_loc(c_path) > 0:
            src = memory.get_lines(c_path, c_start, min(c_start + 2, c_end))
            if src:
                for sl in src:
                    lines.append(f"    {sl.rstrip()}")
                if "L1" not in layers_used:
                    layers_used.append("L1")

        # Sub-callees chain (up to hop 3)
        if c_name in hop3_by_parent:
            chain = " -> ".join(hop3_by_parent[c_name])
            lines.append(f"    -> {chain}")

        # Error flow info
        try:
            error_flows = await graph.query(
                """FOR ef IN talon_error_flows
                   FILTER ef._from == CONCAT('talon_functions/', @fkey)
                   LIMIT 2
                   RETURN {exception_type: ef.exception_type, is_handled: ef.is_handled}""",
                {"fkey": c.get("_key", "")},
            )
            for ef in error_flows:
                exc = ef.get("exception_type", "?")
                handled = "handled" if ef.get("is_handled") else "unhandled"
                lines.append(f"    !! raises {exc} ({handled})")
                warnings_count += 1
        except Exception:
            pass

    return ("\n".join(lines), layers_used, warnings_count)


async def _handle_sync_notification(
    target: str, depth: str, project_id: str, graph: TalonGraph, memory: MemoryStore, hops: int | None = None,
) -> tuple[str, list[str], int]:
    """Phase 6: LLM notifies server of file edit for cache invalidation.

    IMP-8: If the file has >5 callers/dependents, suggest running blast.
    """
    invalidated = invalidate_file(target)
    memory.invalidate(target)

    msg = f"Sync acknowledged: {target} invalidated ({invalidated} cached responses cleared)."

    # IMP-8: Check if this file has significant callers/dependents
    try:
        caller_count = 0
        # Count inbound call edges to functions in this file
        module_key = _file_path_to_module(target)
        callers_result = await graph.query(
            """FOR fn IN talon_functions
               FILTER fn.module == @module AND fn.project_id == @pid
               FOR c IN talon_calls
                   FILTER c._to == fn._id
                   COLLECT WITH COUNT INTO cnt
               RETURN cnt""",
            {"module": module_key, "pid": project_id},
        )
        if callers_result:
            caller_count = callers_result[0] or 0

        if caller_count > 5:
            msg += (
                f"\nTip: This file has {caller_count} inbound call edges. "
                f"Run `graph_query(intent=\"blast\", target=\"{target}\")` to check impact."
            )
    except Exception:
        pass  # Best effort — never block sync

    return (msg, [], 0)


# ---------------------------------------------------------------------------
# Scope Intent — Plan-Based Context Composition
# ---------------------------------------------------------------------------

# Regex patterns for extracting targets from plan text
_SCOPE_FILE_RE = re.compile(r"[\w./\-]+\.(?:py|ts|js|jsx|tsx)")
_SCOPE_CAMEL_RE = re.compile(r"\b[A-Z][a-zA-Z0-9]{2,}\b")
_SCOPE_FUNC_RE = re.compile(r"\b([a-z_][a-z0-9_]{2,})(?=\s*[\(=])")
_SCOPE_SNAKE_RE = re.compile(r"\b([a-z_][a-z0-9_]{2,})\b")

# Priority extraction: backtick-quoted symbols and method() calls
_SCOPE_BACKTICK_RE = re.compile(r"`([a-zA-Z_][a-zA-Z0-9_.]*(?:\(\))?)`")
_SCOPE_METHOD_RE = re.compile(r"\b([a-zA-Z_][a-zA-Z0-9_]*)\(\)")
_SCOPE_CONST_RE = re.compile(r"\b([A-Z][A-Z0-9_]{2,})\b")

# Exception class names — false positive CamelCase matches
_EXCEPTION_NAMES = frozenset({
    "AttributeError", "TypeError", "ValueError", "KeyError", "IndexError",
    "RuntimeError", "ImportError", "FileNotFoundError", "OSError", "IOError",
    "StopIteration", "GeneratorExit", "SystemExit", "KeyboardInterrupt",
    "Exception", "BaseException", "NotImplementedError", "PermissionError",
    "TimeoutError", "ConnectionError", "ModuleNotFoundError", "NameError",
    "ZeroDivisionError", "OverflowError", "UnicodeError", "LookupError",
})

# Common English words to exclude from symbol matching
_SCOPE_STOPWORDS = frozenset({
    "the", "and", "for", "from", "with", "that", "this", "into", "when",
    "add", "use", "run", "get", "set", "new", "all", "not", "but", "has",
    "are", "was", "can", "will", "also", "each", "need", "should", "would",
    "could", "been", "have", "make", "like", "then", "than", "where", "here",
    "file", "files", "function", "class", "method", "module", "test", "tests",
    "modify", "change", "update", "create", "delete", "remove", "move",
    "wire", "connect", "implement", "across", "between", "through",
    "def", "return", "import", "async", "await", "None", "True", "False",
    "self", "cls", "args", "kwargs",
})


def _extract_scope_targets(
    text: str, memory: MemoryStore
) -> dict[str, Any]:
    """Extract file paths and symbol names from plan/task text.

    Uses regex to find likely file paths and symbol names, then validates
    each against the memory store to filter out non-existent targets.

    Returns:
        dict with keys:
            files: list of valid file paths found
            symbols: list of (name, [(file, line), ...]) tuples
            priority_symbols: set of symbol names that were explicitly mentioned
                (backtick-quoted, method() calls) — these get full enrichment
            unresolved_files: list of file paths that didn't resolve
            unresolved_symbols: list of symbol names that didn't resolve
    """
    # 1. Extract file paths (C4: deterministic with partial-match fallback)
    raw_files = _SCOPE_FILE_RE.findall(text)
    valid_files: list[str] = []
    seen_files: set[str] = set()
    known_paths = memory.cached_paths  # All indexed file paths
    for fp in raw_files:
        if fp in seen_files:
            continue
        seen_files.add(fp)
        if memory.get_file_loc(fp) > 0:
            valid_files.append(fp)
        else:
            # Partial-match fallback: "canvas.py" → "celery/canvas.py"
            basename = fp.rsplit("/", 1)[-1] if "/" in fp else fp
            for known in known_paths:
                if known.endswith("/" + basename) or known == basename:
                    if known not in seen_files:
                        valid_files.append(known)
                        seen_files.add(known)
                    break

    # 2a. Extract PRIORITY symbol candidates (explicitly mentioned)
    priority_names: set[str] = set()
    # Backtick-quoted: `validate_token`, `Request`, `shelve.open()`
    for m in _SCOPE_BACKTICK_RE.finditer(text):
        raw = m.group(1).rstrip("()")
        # Handle dotted: `Class.method` → extract both
        if "." in raw:
            parts = raw.split(".")
            priority_names.update(p for p in parts if len(p) > 2)
        else:
            priority_names.add(raw)
    # Bare method calls: validate_token(), Request()
    for m in _SCOPE_METHOD_RE.finditer(text):
        priority_names.add(m.group(1))

    # 2b. Extract general symbol candidates
    candidates: set[str] = set()
    # CamelCase identifiers (class names, etc.)
    candidates.update(_SCOPE_CAMEL_RE.findall(text))
    # Function-call-style identifiers (before parentheses or assignment)
    candidates.update(m.group(1) for m in _SCOPE_FUNC_RE.finditer(text))
    # Snake_case identifiers (only those with underscores to reduce noise)
    for m in _SCOPE_SNAKE_RE.finditer(text):
        name = m.group(1)
        if "_" in name:
            candidates.add(name)
    # ALL_CAPS constants
    candidates.update(_SCOPE_CONST_RE.findall(text))

    # Filter: stopwords, short names, exception class names
    candidates = {
        c for c in candidates
        if c.lower() not in _SCOPE_STOPWORDS and len(c) > 2
        and c not in _EXCEPTION_NAMES
    }
    # Also filter priority names
    priority_names = {
        p for p in priority_names
        if p.lower() not in _SCOPE_STOPWORDS and len(p) > 2
        and p not in _EXCEPTION_NAMES
    }

    # Merge: priority symbols go into candidates too (for locate), deduplicated
    candidates.update(priority_names)

    # 3. Validate against memory store — priority symbols first
    valid_symbols: list[tuple[str, list[tuple[str, int]]]] = []
    unresolved_symbols: list[str] = []
    seen_syms: set[str] = set()
    # Priority symbols first so they appear at front of list
    for name in sorted(priority_names):
        if name in seen_syms:
            continue
        locs = memory.locate_symbol(name)
        if locs:
            seen_syms.add(name)
            valid_symbols.append((name, locs))
        else:
            unresolved_symbols.append(name)
    # Then general candidates
    for name in sorted(candidates - priority_names):
        if name in seen_syms:
            continue
        locs = memory.locate_symbol(name)
        if locs:
            seen_syms.add(name)
            valid_symbols.append((name, locs))
        else:
            unresolved_symbols.append(name)

    # Track unresolved files (raw files that didn't resolve to valid paths)
    unresolved_files: list[str] = [fp for fp in raw_files if fp not in seen_files and fp not in valid_files]

    return {
        "files": valid_files,
        "symbols": valid_symbols,
        "priority_symbols": priority_names,
        "unresolved_files": list(dict.fromkeys(unresolved_files)),
        "unresolved_symbols": unresolved_symbols,
    }


async def _build_scope_response(
    target: str,
    depth: str,
    project_id: str,
    graph: TalonGraph,
    memory: MemoryStore,
    hops: int | None = None,
) -> tuple[str, list[str], int]:
    """Plan-based context composition: parse plan text, compose one response.

    Extracts file paths and symbols from the target text (a plan or task
    description), then composes a single response bundling locate + toc +
    callers + flow + blast information.

    Returns: (response_text, layers_used, warnings_count)
    """
    layers_used: list[str] = []
    warnings_count = 0

    # 1. Parse the plan text for file paths and symbol names
    extracted = _extract_scope_targets(target, memory)
    files: list[str] = extracted["files"]
    symbols: list[tuple[str, list[tuple[str, int]]]] = extracted["symbols"]
    priority_symbols: set[str] = extracted.get("priority_symbols", set())

    # E3: Track raw extraction counts for confidence scoring
    raw_file_re = re.compile(r"[\w./\-]+\.(?:py|ts|js|jsx|tsx)")
    raw_file_count = len(set(raw_file_re.findall(target)))
    raw_symbol_re = re.compile(r"\b[A-Z][a-zA-Z0-9]{2,}\b")
    raw_symbol_count = len(set(raw_symbol_re.findall(target)))

    if not files and not symbols:
        return (
            "SCOPE: No recognizable file paths or symbols found in the provided text.\n"
            "Tip: Include file paths (e.g. src/auth.py) or symbol names "
            "(e.g. validate_token, Request) in your plan description.",
            [],
            0,
        )

    # Collect all unique files from both direct paths and symbol locations
    all_files: dict[str, int] = {}  # path → LOC
    for fp in files:
        loc = memory.get_file_loc(fp)
        if loc > 0:
            all_files[fp] = loc

    # Deduplicate symbol locations to unique (file, symbol, line) triples
    edit_targets: list[dict[str, Any]] = []
    for name, locs in symbols:
        for fp, ln in locs:
            loc = memory.get_file_loc(fp)
            if loc > 0:
                all_files[fp] = loc
            sym_info = memory.get_symbol_at(fp, ln)
            edit_targets.append({
                "name": name,
                "file": fp,
                "line": ln,
                "sym_info": sym_info,
            })

    if not all_files and not edit_targets:
        return (
            "SCOPE: Extracted targets could not be resolved in the memory cache.\n"
            "Tip: Ensure the project is indexed with `talon-index`.",
            [],
            0,
        )

    # Fix 1: Inheritance-edge scope expansion — traverse talon_inherits to find
    # base class files not already in scope (e.g. bootsteps.py for consumer/ files).
    # Only runs when graph is available (graceful degradation if query fails).
    try:
        # Collect all class names defined in files currently in scope
        in_scope_classes: list[str] = []
        for fp in list(all_files.keys()):
            for sym in memory.get_file_symbols(fp):
                if sym.get("type") == "class":
                    in_scope_classes.append(sym["name"])

        if in_scope_classes and graph:
            # Find parent classes (via talon_inherits edges) — returns parent module paths
            parent_mods = await graph.query(
                """FOR cls IN talon_classes
                   FILTER cls.name IN @names AND cls.project_id == @pid
                   FOR parent IN 1..1 OUTBOUND cls talon_inherits
                   RETURN DISTINCT parent.module""",
                {"names": in_scope_classes, "pid": project_id},
            )
            added = False
            for mod in parent_mods:
                if not mod:
                    continue
                fp = _module_to_path(mod)
                if fp and fp not in all_files:
                    loc = memory.get_file_loc(fp)
                    if loc > 0:
                        all_files[fp] = loc
                        added = True
            if added and "graph" not in layers_used:
                layers_used.append("graph")
    except Exception:
        pass  # Graph unavailable — skip inheritance expansion

    # Fix 3: Directory-level scope expansion — when scope files are in a subdirectory,
    # include adjacent parent-directory files (e.g. components.py, heartbeat.py when
    # scoping on worker/consumer/) to surface architectural siblings.
    subdirs_seen: set[str] = set()
    for fp in list(all_files.keys()):
        parts = fp.rsplit("/", 1)
        if len(parts) == 2:
            parent_dir = parts[0].rsplit("/", 1)[0] if "/" in parts[0] else ""
            if parent_dir and parent_dir not in subdirs_seen:
                subdirs_seen.add(parent_dir)
                parent_prefix = parent_dir + "/"
                for known in memory.cached_paths:
                    # Add direct children of parent_dir (not deeper subdirs)
                    if (known.startswith(parent_prefix)
                            and known not in all_files
                            and "/" not in known[len(parent_prefix):]):
                        loc = memory.get_file_loc(known)
                        if loc > 0:
                            all_files[known] = loc

    layers_used.append("L2")

    # E3: Compute confidence score
    resolved_files = len(files)
    resolved_symbols = len(symbols)
    total_raw = max(raw_file_count + raw_symbol_count, 1)
    total_resolved = resolved_files + resolved_symbols
    confidence_pct = min(100, int(100 * total_resolved / total_raw))

    # E2: Detect test files for verification hints
    test_files: list[str] = []
    for fp in all_files:
        basename = fp.rsplit("/", 1)[-1] if "/" in fp else fp
        if basename.startswith("test_") or basename.endswith("_test.py"):
            test_files.append(fp)
    # Also check if any edit target files have corresponding test files
    for fp in list(all_files.keys()):
        basename = fp.rsplit("/", 1)[-1] if "/" in fp else fp
        if not basename.startswith("test_"):
            test_name = "test_" + basename
            found = False
            for known in memory.cached_paths:
                if known.endswith("/" + test_name) or known == test_name:
                    if known not in test_files:
                        test_files.append(known)
                    found = True
                    break
            # #6: Substring match — find test files containing the source basename
            if not found:
                src_stem = basename.rstrip(".py").rstrip(".ts").rstrip(".js")
                if src_stem.endswith(".jsx") or src_stem.endswith(".tsx"):
                    src_stem = src_stem.rsplit(".", 1)[0]
                for known in memory.cached_paths:
                    k_basename = known.rsplit("/", 1)[-1] if "/" in known else known
                    if (k_basename.startswith("test_") and src_stem in k_basename
                            and known not in test_files):
                        test_files.append(known)
                        break

    # 2. Build file summary section
    # Fix 2: Include class-boundary line ranges so agents request the full class
    # extent in sm_batch reads — prevents truncation at class body boundaries
    # (e.g. heartbeat.py Heart:1-78 → agent requests 1-78, not 1-61).
    file_lines: list[str] = []
    for fp in sorted(all_files.keys()):
        loc = all_files[fp]
        syms = memory.get_file_symbols(fp)
        class_syms = [s for s in syms if s.get("type") == "class"]
        if class_syms:
            class_ranges = ", ".join(
                f"{s['name']}:{s.get('line_start', '?')}-{s.get('line_end', '?')}"
                for s in class_syms[:5]
            )
            file_lines.append(f"  {fp} ({loc} LOC, {len(syms)} fns, classes: {class_ranges})")
        else:
            file_lines.append(f"  {fp} ({loc} LOC, {len(syms)} fns)")

    # Build header with confidence score (E3)
    header = f"SCOPE ({len(all_files)} files, {len(edit_targets)} symbols, {confidence_pct}% resolved)"

    # Log thin scope responses (0 symbols = extraction failed)
    if len(edit_targets) == 0:
        _log_not_found(target, "scope", intent="scope")

    # === SHALLOW: file list + symbol locations ===
    if depth == "shallow":
        lines = [f"{header}:", "Files:"]
        lines.extend(file_lines)
        if edit_targets:
            lines.append("Symbols:")
            for et in edit_targets:
                lines.append(f"  {et['name']}  {et['file']}:{et['line']}")
        return ("\n".join(lines), layers_used, 0)

    # === STANDARD / FULL: add callers, callees, signatures, blast ===

    # Check whether inline smart_read bodies are enabled (default: on)
    inline_bodies = os.environ.get("TALON_SCOPE_INLINE_BODIES", "1") == "1"
    bodies_rendered = 0  # X909: track how many bodies were actually inlined

    # X7 Change 6A: Propagation detection — if same symbol appears in 3+ files,
    # use full body (body_cap = 0) since the agent needs complete source for each site.
    symbol_file_counts: dict[str, int] = {}
    for et in edit_targets:
        name = et["name"]
        symbol_file_counts[name] = symbol_file_counts.get(name, 0) + 1
    has_propagation = any(c >= 3 for c in symbol_file_counts.values())

    # Fix 4: Instrumentation task detection — "wrap/hook/lifecycle/instrument"
    # tasks need full method bodies to decide WHERE and HOW to wrap. Force body_cap=0.
    _INSTRUMENTATION_KEYWORDS = frozenset({
        "hook", "hooks", "lifecycle", "wrap", "instrument", "middleware",
        "intercept", "patch", "monkey", "signal", "event", "callback",
    })
    target_words = set(target.lower().split())
    is_instrumentation_task = bool(target_words & _INSTRUMENTATION_KEYWORDS)

    # Standard: adaptive cap based on edit target count; Full: full body (no cap)
    if has_propagation or is_instrumentation_task:
        body_cap = 0  # Full body for propagation and instrumentation tasks
    elif depth == "standard":
        if len(edit_targets) <= 3:
            body_cap = 15
        elif len(edit_targets) <= 6:
            body_cap = 8
        else:
            body_cap = 5
    else:
        body_cap = 0

    # 3. Enrich edit targets with callers + callees (1-hop)
    # Priority symbols get full enrichment; general symbols get signature only
    for et in edit_targets:
        name = et["name"]
        sym_info = et.get("sym_info")
        is_priority = name in priority_symbols

        # Get signature from memory (all symbols get this)
        if sym_info and memory.get_file_loc(et["file"]) > 0:
            sig_lines = memory.get_lines(et["file"], et["line"], et["line"])
            if sig_lines:
                et["signature"] = sig_lines[0].strip()
                if "L1" not in layers_used:
                    layers_used.append("L1")

        # Skip graph enrichment for non-priority symbols
        if not is_priority:
            continue

        # Query callers from graph (priority only)
        fn_nodes = await _find_function_nodes(name, project_id, graph)
        if fn_nodes:
            if "graph" not in layers_used:
                layers_used.append("graph")
            # Pick node matching this file
            fn_key = None
            for fn in fn_nodes:
                fn_mod = fn.get("module", "")
                fn_path = _module_to_path(fn_mod)
                if et["file"] in fn_path or fn_path in et["file"]:
                    fn_key = fn["_key"]
                    break
            if fn_key is None and fn_nodes:
                fn_key = fn_nodes[0]["_key"]

            if fn_key:
                # Callers (inbound)
                try:
                    callers = await graph.query(
                        """FOR v IN 1..1 INBOUND
                           CONCAT('talon_functions/', @fkey) talon_calls
                           RETURN {name: v.name, module: v.module, class_name: v.class_name,
                                   line_start: v.line_start}""",
                        {"fkey": fn_key},
                    )
                    if callers:
                        caller_strs = []
                        for c in callers[:5]:
                            cname = f"{c['class_name']}.{c['name']}" if c.get("class_name") else c["name"]
                            caller_strs.append(cname)
                        et["callers"] = caller_strs
                except Exception:
                    pass

                # Callees (outbound) — for pipeline reconstruction
                try:
                    callees = await graph.query(
                        """FOR v IN 1..1 OUTBOUND
                           CONCAT('talon_functions/', @fkey) talon_calls
                           RETURN {name: v.name, module: v.module, class_name: v.class_name}""",
                        {"fkey": fn_key},
                    )
                    if callees:
                        callee_strs = []
                        for c in callees[:5]:
                            cname = f"{c['class_name']}.{c['name']}" if c.get("class_name") else c["name"]
                            callee_strs.append(cname)
                        et["callees"] = callee_strs
                except Exception:
                    pass

                # Test coverage (full depth only)
                if depth == "full":
                    try:
                        tests = await graph.query(
                            """FOR t IN 1..1 INBOUND
                               CONCAT('talon_functions/', @fkey) talon_tests
                               RETURN t.name""",
                            {"fkey": fn_key},
                        )
                        test_names = [n for n in tests if n]
                        if test_names:
                            et["tests"] = test_names[:3]
                        else:
                            et["untested"] = True
                            warnings_count += 1
                    except Exception:
                        pass

    # 4. Blast radius — for each file, check dependents
    blast_info: dict[str, list[str]] = {}
    for fp in sorted(all_files.keys()):
        try:
            dependents = await graph.query(
                """FOR file IN talon_files FILTER file.path == @path AND file.project_id == @pid
                   FOR dep_file IN 1..1 INBOUND file talon_depends_on
                   RETURN dep_file.path""",
                {"path": fp, "pid": project_id},
            )
            dep_paths = [d for d in dependents if d]
            if dep_paths:
                blast_info[fp] = dep_paths[:5]
                if "graph" not in layers_used:
                    layers_used.append("graph")
        except Exception:
            pass

    # 5. Reconstruct pipeline summary from callees
    pipeline_parts: list[str] = []
    for et in edit_targets:
        if et.get("callees"):
            chain = f"{et['name']}() -> {', '.join(c + '()' for c in et['callees'][:3])}"
            pipeline_parts.append(chain)

    # X7 Change 1: Scope Confidence Signal — warn when <80% targets resolved
    unresolved_files_list: list[str] = extracted.get("unresolved_files", [])
    unresolved_symbols_list: list[str] = extracted.get("unresolved_symbols", [])

    # 6. Compose response
    lines = [f"{header}:", ""]

    if confidence_pct < 80:
        lines.append("!! LOW CONFIDENCE — scope resolved only "
                      f"{confidence_pct}% of targets from your description.")
        if unresolved_symbols_list:
            suggest_syms = unresolved_symbols_list[:5]
            lines.append("  Unresolved symbols — try locate for these:")
            for sym in suggest_syms:
                lines.append(f"    graph_query(intent=\"locate\", target=\"{sym}\")")
        if unresolved_files_list:
            lines.append(f"  Unresolved files: {', '.join(unresolved_files_list[:5])}")
        lines.append("")

    lines.append("Files:")
    lines.extend(file_lines)

    # Edit targets section
    lines.append("")
    lines.append("Edit targets:")
    for et in edit_targets:
        sym_info = et.get("sym_info")
        is_priority = et["name"] in priority_symbols
        line_range = ""
        if sym_info:
            line_range = f" ({sym_info.get('line_start', et['line'])}-{sym_info.get('line_end', '?')})"

        # Fix 3: Use full path so hook can match against task_mentioned paths
        file_display = et["file"]
        cls_prefix = ""
        if sym_info and sym_info.get("class_name"):
            cls_prefix = f"{sym_info['class_name']}."

        # Non-priority symbols: file:line only, no body/callers
        if not is_priority:
            lines.append(f"  {file_display}:{cls_prefix}{et['name']}{line_range}")
            continue

        # V1 def-line verification: check first source line starts with def/class/async def
        v1_tag = ""
        if inline_bodies and sym_info and memory.get_file_loc(et["file"]) > 0:
            body_start = sym_info.get("line_start", et["line"])
            body_end = sym_info.get("line_end", body_start + 15)
            if body_cap > 0:
                body_end = min(body_start + body_cap - 1, body_end)
            body_lines = memory.get_lines(et["file"], body_start, body_end)
            if body_lines:
                first = body_lines[0].lstrip()
                if first.startswith(("def ", "async def ", "class ")):
                    v1_tag = " [VERIFIED]"
                else:
                    v1_tag = " [UNVERIFIED]"
                    warnings_count += 1
        elif sym_info:
            # Bodies disabled but sym_info exists — check def line only
            check_line = memory.get_lines(et["file"], sym_info.get("line_start", et["line"]),
                                          sym_info.get("line_start", et["line"]))
            if check_line:
                first = check_line[0].lstrip()
                if first.startswith(("def ", "async def ", "class ")):
                    v1_tag = " [VERIFIED]"
                else:
                    v1_tag = " [UNVERIFIED]"
                    warnings_count += 1

        lines.append(f"  {file_display}:{cls_prefix}{et['name']}{line_range}{v1_tag}")

        # Inline smart_read body (numbered lines, Edit-ready format)
        if inline_bodies and sym_info and memory.get_file_loc(et["file"]) > 0:
            body_start = sym_info.get("line_start", et["line"])
            body_end = sym_info.get("line_end", body_start + 15)
            if body_cap > 0:
                body_end = min(body_start + body_cap - 1, body_end)
            body_lines = memory.get_lines(et["file"], body_start, body_end)
            if body_lines:
                for i, bl in enumerate(body_lines):
                    lines.append(f"    {body_start + i:4d}  {bl.rstrip()}")
                bodies_rendered += 1
                if "L1" not in layers_used:
                    layers_used.append("L1")
        elif et.get("signature"):
            # Fallback: signature only when inline bodies disabled
            sig = et["signature"]
            if len(sig) > 80:
                sig = sig[:77] + "..."
            lines.append(f"    {sig}")

        # Callers
        if et.get("callers"):
            lines.append(f"    Callers: {', '.join(et['callers'])}")

        # Tests (full only)
        if depth == "full":
            if et.get("tests"):
                lines.append(f"    Tests: {', '.join(et['tests'])}")
            elif et.get("untested"):
                lines.append("    Tests: !! UNTESTED")

    # Pipeline summary
    if pipeline_parts:
        lines.append("")
        for pp in pipeline_parts[:3]:
            lines.append(f"Pipeline: {pp}")

    # Blast radius summary
    if blast_info:
        lines.append("")
        for fp, deps in blast_info.items():
            short_fp = fp.rsplit("/", 1)[-1] if "/" in fp else fp
            dep_names = [d.rsplit("/", 1)[-1] if "/" in d else d for d in deps]
            lines.append(f"Blast: {short_fp} changes -> {', '.join(dep_names)}")

    # Co-change companions — top-3 per target file (v2)
    cochange_info: dict[str, list[str]] = {}  # file → [partner1, partner2, ...]
    for fp in sorted(all_files.keys()):
        file_key = await _find_file_key(fp, project_id, graph)
        if not file_key:
            continue
        try:
            partners = await graph.query(
                """LET fid = CONCAT('talon_files/', @fkey)
                   LET out_edges = (
                       FOR partner, edge IN 1..1 OUTBOUND fid talon_co_changes
                       FILTER edge.co_change_count >= 2
                       RETURN {path: partner.path, corr: edge.correlation, count: edge.co_change_count}
                   )
                   LET in_edges = (
                       FOR partner, edge IN 1..1 INBOUND fid talon_co_changes
                       FILTER edge.co_change_count >= 2
                       RETURN {path: partner.path, corr: edge.correlation, count: edge.co_change_count}
                   )
                   FOR p IN UNION(out_edges, in_edges)
                   FILTER p.path != null
                   COLLECT path = p.path INTO grouped
                   LET best = FIRST(FOR g IN grouped[*].p SORT g.corr DESC RETURN g)
                   SORT best.corr DESC, path ASC
                   LIMIT 3
                   RETURN {path: path, corr: best.corr, count: best.count}""",
                {"fkey": file_key},
            )
            if partners:
                companion_strs = []
                for p in partners:
                    ppath = p.get("path") or "?"
                    # Skip if partner is already in the scope target files
                    if ppath in all_files:
                        continue
                    corr = p.get("corr", 0)
                    companion_strs.append(f"{ppath} (corr={corr:.2f})")
                if companion_strs:
                    cochange_info[fp] = companion_strs
                    if "graph" not in layers_used:
                        layers_used.append("graph")
        except Exception:
            pass

    if cochange_info and os.environ.get("TALON_SCOPE_COCHANGE", "1") != "0":
        lines.append("")
        for fp, companions in cochange_info.items():
            short_fp = fp.rsplit("/", 1)[-1] if "/" in fp else fp
            lines.append(f"Co-change: {short_fp} often changes with: {', '.join(companions)}")

    # E2: Verification hints — suggest pytest command for discovered test files
    if test_files:
        lines.append("")
        if len(test_files) == 1:
            lines.append(f"Verify: pytest {test_files[0]} -v")
        else:
            test_dirs = set()
            for tf in test_files:
                parent = tf.rsplit("/", 1)[0] if "/" in tf else "."
                test_dirs.add(parent)
            if len(test_dirs) == 1:
                lines.append(f"Verify: pytest {next(iter(test_dirs))}/ -v")
            else:
                lines.append(f"Verify: pytest {' '.join(test_files)} -v")

    # X7 Change 4: EDIT PLAN — ordered edit steps derived from scope analysis
    if edit_targets and (depth in ("standard", "full")):
        lines.append("")
        lines.append("EDIT PLAN:")

        # Sort edit targets: base classes first, source before tests, callers-count desc
        def _edit_sort_key(et: dict) -> tuple[int, int, int]:
            fp = et.get("file", "")
            is_test = 1 if ("test_" in fp or "/tests/" in fp) else 0
            # Base classes (classes with subclasses = many callers) go first
            callers_count = len(et.get("callers", []))
            # class_name present = method, no class_name = function/class def
            is_base = 1 if (et.get("sym_info", {}) or {}).get("class_name") else 0
            return (is_test, -is_base, -callers_count)

        sorted_targets = sorted(edit_targets, key=_edit_sort_key)
        for step_num, et in enumerate(sorted_targets, 1):
            sym_info = et.get("sym_info")
            fp = et["file"]
            name = et["name"]
            if sym_info:
                start = sym_info.get("line_start", et["line"])
                end = sym_info.get("line_end", "?")
                # Infer action from context
                action = "modify"
                if et.get("callers"):
                    action = "modify (has callers — check signatures)"
                lines.append(
                    f"  {step_num}. Read {fp}:{start}-{end} → Edit {name} — {action}"
                )
            else:
                lines.append(f"  {step_num}. Read {fp} → Edit {name}")

        # Verification step
        if test_files:
            step_final = len(sorted_targets) + 1
            if len(test_files) == 1:
                lines.append(f"  {step_final}. Verify: pytest {test_files[0]} --tb=no -q")
            else:
                lines.append(f"  {step_final}. Verify: pytest {' '.join(test_files[:3])} --tb=no -q")

    # X7.5 P0: Scope response size guard — truncate enrichment to fit buffer
    # Budget: ~3000 chars. Truncation order: Co-change → Callers → Pipeline → Blast → body lines.
    # EDIT PLAN, TALON_META, Files, header always survive.
    SCOPE_CHAR_BUDGET = 3000
    total_chars = sum(len(ln) + 1 for ln in lines)  # +1 for newline
    if total_chars > SCOPE_CHAR_BUDGET:
        # Phase 0: Remove Co-change lines (lowest priority — nice-to-have signal)
        lines = [ln for ln in lines if not ln.startswith("Co-change:")]
        total_chars = sum(len(ln) + 1 for ln in lines)

    if total_chars > SCOPE_CHAR_BUDGET:
        # Phase 1: Remove Callers lines
        lines = [ln for ln in lines if not ln.strip().startswith("Callers:")]
        total_chars = sum(len(ln) + 1 for ln in lines)

    if total_chars > SCOPE_CHAR_BUDGET:
        # Phase 2: Remove Pipeline lines
        lines = [ln for ln in lines if not ln.startswith("Pipeline:")]
        total_chars = sum(len(ln) + 1 for ln in lines)

    if total_chars > SCOPE_CHAR_BUDGET:
        # Phase 3: Remove Blast lines
        lines = [ln for ln in lines if not ln.startswith("Blast:")]
        total_chars = sum(len(ln) + 1 for ln in lines)

    if total_chars > SCOPE_CHAR_BUDGET:
        # Phase 4: Trim inline body lines (numbered lines like "  1234  def foo()")
        import re as _re
        _body_line_re = _re.compile(r'^\s+\d{3,}\s+')
        lines = [ln for ln in lines if not _body_line_re.match(ln)]

    # X909: Bodies-included footer — tell LLM not to re-read with smart_read
    if bodies_rendered > 0:
        lines.append("")
        lines.append(
            "TALON_META: Bodies included above — do NOT re-read with smart_read. "
            "Edit directly using inline bodies as old_string reference."
        )

    # TALON_META: machine-readable block for hook extraction (X7)
    meta: dict[str, Any] = {
        "served_files": [et["file"] for et in edit_targets],
        "shadow_reads": {},
    }
    for et in edit_targets:
        sym_info = et.get("sym_info")
        if sym_info:
            start = sym_info.get("line_start", et["line"])
            end = sym_info.get("line_end", start + 15)
            meta["shadow_reads"][et["file"]] = {
                "offset": max(1, start - 5),
                "limit": (end - start) + 15,
                "symbol": et["name"],
            }
    lines.append("")
    lines.append(f"<!-- TALON_META:{_json.dumps(meta)} -->")

    return ("\n".join(lines), layers_used, warnings_count)


# ---------------------------------------------------------------------------
# CG Intent Handler (G4)
# ---------------------------------------------------------------------------


async def _build_cg_response(
    target: str,
    depth: str,
    project_id: str,
    graph: TalonGraph,
    memory: MemoryStore,
    hops: int | None = None,
) -> tuple[str, list[str], int]:
    """Handle cg intent — query the concept graph for a topic."""
    if _cg_query is None:
        return ("Concept graph not available. Ensure ArangoDB is running and CG is initialized.", [], 0)

    try:
        result = _cg_query.query(target, depth=depth)
    except Exception as e:
        logger.warning("CG query failed for %s: %s", target, e)
        return (f"CG query error: {e}", [], 0)

    if not result:
        return (f"No concepts found matching '{target}'.", [], 0)

    # Log CG telemetry
    try:
        from talon.cg.telemetry import CGEvent, log_cg_event
        n_concepts = result.count("\n") if result else 0
        log_cg_event(CGEvent(
            event_type="query",
            concepts_matched=n_concepts,
            latency_ms=0,  # filled by route_intent wrapper
            details={"topic": target, "depth": depth},
        ))
    except Exception:
        pass

    return (result, ["CG"], 0)


async def _handle_cg_update(
    target: str,
    depth: str,
    project_id: str,
    graph: TalonGraph,
    memory: MemoryStore,
    hops: int | None = None,
) -> tuple[str, list[str], int]:
    """Handle cg_update intent — modify concept graph entries.

    Target string encoding:
      weight:<concept>=<float>
      suppress:<concept>
      unsuppress:<concept>
      feedback:<type>:<concept>:<text>
      status:<concept>=<STATUS>
    """
    if _cg_store is None:
        return ("Concept graph not available. Ensure ArangoDB is running and CG is initialized.", [], 0)

    from talon.cg.store import CONCEPTS, _make_key

    parts = target.split(":", 1)
    if len(parts) < 2:
        return (
            "Invalid cg_update target. Use: weight:<concept>=<value>, "
            "suppress:<concept>, unsuppress:<concept>, "
            "feedback:<type>:<concept>:<text>, status:<concept>=<STATUS>, "
            "group_create:<name>:<desc>, group_add:<group>:<concepts>, "
            "group_rm:<group>:<concept>, group_delete:<group>",
            [], 0,
        )

    operation = parts[0].strip().lower()
    operand = parts[1].strip()
    col = _cg_store.db.collection(CONCEPTS)

    try:
        if operation == "weight":
            # weight:<concept>=<float>
            if "=" not in operand:
                return ("Format: weight:<concept>=<float>", [], 0)
            concept_name, val_str = operand.rsplit("=", 1)
            key = _make_key(concept_name.strip())
            weight = max(0.0, min(1.0, float(val_str.strip())))
            if not col.has(key):
                return (f"Concept '{concept_name.strip()}' not found.", [], 0)
            col.update({"_key": key, "user_weight": weight})
            msg = f"CG_UPDATE: Set weight for '{concept_name.strip()}' to {weight}"

        elif operation == "suppress":
            key = _make_key(operand)
            if not col.has(key):
                return (f"Concept '{operand}' not found.", [], 0)
            col.update({"_key": key, "suppressed": True})
            msg = f"CG_UPDATE: Suppressed '{operand}'"

        elif operation == "unsuppress":
            key = _make_key(operand)
            if not col.has(key):
                return (f"Concept '{operand}' not found.", [], 0)
            col.update({"_key": key, "suppressed": False})
            msg = f"CG_UPDATE: Unsuppressed '{operand}'"

        elif operation == "feedback":
            # feedback:<type>:<concept>:<text>
            fb_parts = operand.split(":", 2)
            if len(fb_parts) < 3:
                return ("Format: feedback:<type>:<concept>:<text>", [], 0)
            fb_type, fb_concept, fb_text = fb_parts[0].strip(), fb_parts[1].strip(), fb_parts[2].strip()
            key = _make_key(fb_concept)
            concept_key = key if col.has(key) else None
            _cg_store.record_feedback(
                feedback_type=fb_type,
                content=fb_text,
                concept_key=concept_key,
                session_id=f"mcp-{project_id}",
            )
            if concept_key:
                from talon.cg.feedback import apply_feedback
                apply_feedback(concept_key, fb_type, store=_cg_store)
            msg = f"CG_UPDATE: Recorded {fb_type} feedback on '{fb_concept}'"

        elif operation == "status":
            # status:<concept>=<STATUS>
            if "=" not in operand:
                return ("Format: status:<concept>=<STATUS>", [], 0)
            concept_name, new_status = operand.rsplit("=", 1)
            key = _make_key(concept_name.strip())
            new_status = new_status.strip().upper()
            valid_statuses = {"PROPOSED", "DESIGNED", "BUILT", "VALIDATED", "DEAD_END", "ABANDONED"}
            if new_status not in valid_statuses:
                return (f"Invalid status '{new_status}'. Valid: {', '.join(sorted(valid_statuses))}", [], 0)
            if not col.has(key):
                return (f"Concept '{concept_name.strip()}' not found.", [], 0)
            col.update({"_key": key, "status": new_status})
            msg = f"CG_UPDATE: Set status of '{concept_name.strip()}' to {new_status}"

        elif operation == "group_create":
            # group_create:<name>:<description>
            gc_parts = operand.split(":", 1)
            group_name = gc_parts[0].strip()
            group_desc = gc_parts[1].strip() if len(gc_parts) > 1 else ""
            display = group_name.replace("-", " ").title()
            key = _cg_store.create_group(group_name, display, group_desc, session_id=f"mcp-{project_id}")
            msg = f"CG_UPDATE: Created group '{group_name}' (key={key})"

        elif operation == "group_add":
            # group_add:<group>:<concept1>,<concept2>,...
            ga_parts = operand.split(":", 1)
            if len(ga_parts) < 2:
                return ("Format: group_add:<group>:<concept1>,<concept2>,...", [], 0)
            group_name = ga_parts[0].strip()
            concept_names = [c.strip() for c in ga_parts[1].split(",") if c.strip()]
            group_key = _make_key(group_name)
            added = []
            errors = []
            for cn in concept_names:
                ck = _make_key(cn)
                result = _cg_store.add_to_group(group_key, ck, session_id=f"mcp-{project_id}")
                if result:
                    added.append(cn)
                else:
                    errors.append(cn)
            parts_msg = []
            if added:
                parts_msg.append(f"added {', '.join(added)}")
            if errors:
                parts_msg.append(f"failed: {', '.join(errors)}")
            msg = f"CG_UPDATE: group_add '{group_name}': {'; '.join(parts_msg)}"

        elif operation == "group_rm":
            # group_rm:<group>:<concept>
            gr_parts = operand.split(":", 1)
            if len(gr_parts) < 2:
                return ("Format: group_rm:<group>:<concept>", [], 0)
            group_name = gr_parts[0].strip()
            concept_name = gr_parts[1].strip()
            group_key = _make_key(group_name)
            concept_key = _make_key(concept_name)
            removed = _cg_store.remove_from_group(group_key, concept_key)
            msg = f"CG_UPDATE: {'Removed' if removed else 'Not found:'} '{concept_name}' from group '{group_name}'"

        elif operation == "group_delete":
            # group_delete:<group>
            group_name = operand.strip()
            group_key = _make_key(group_name)
            deleted = _cg_store.delete_group(group_key)
            msg = f"CG_UPDATE: {'Deleted' if deleted else 'Not found:'} group '{group_name}'"

        else:
            return (
                f"Unknown operation '{operation}'. Use: weight, suppress, unsuppress, feedback, status, "
                "group_create, group_add, group_rm, group_delete",
                [], 0,
            )

    except Exception as e:
        logger.warning("CG update failed: %s", e)
        return (f"CG update error: {e}", [], 0)

    # Log telemetry
    try:
        from talon.cg.telemetry import CGEvent, log_cg_event
        log_cg_event(CGEvent(
            event_type="update",
            concepts_matched=1,
            details={"operation": operation, "target": operand},
        ))
    except Exception:
        pass

    return (msg, ["CG"], 0)


# ---------------------------------------------------------------------------
# Co-Change Intent (v2 — internal, not exposed in tool schema)
# ---------------------------------------------------------------------------


async def _find_file_key(
    target: str, project_id: str, graph: TalonGraph
) -> str | None:
    """Find a file's _key by path. Returns None if not found."""
    try:
        results = await graph.query(
            """FOR f IN talon_files
               FILTER f.path == @path AND f.project_id == @pid
               LIMIT 1
               RETURN f._key""",
            {"path": target, "pid": project_id},
        )
        return results[0] if results else None
    except Exception:
        return None


async def _build_cochange_response(
    target: str, depth: str, project_id: str, graph: TalonGraph, memory: MemoryStore, hops: int | None = None,
) -> tuple[str, list[str], int]:
    """Co-change intent: what files usually change together.

    Queries talon_co_changes edges for temporal co-change partners
    ranked by correlation strength.
    """
    layers_used: list[str] = []
    warnings_count = 0

    # Resolve target file
    file_key = await _find_file_key(target, project_id, graph)
    if file_key is None:
        # Try partial path match
        try:
            results = await graph.query(
                """FOR f IN talon_files
                   FILTER f.project_id == @pid AND CONTAINS(f.path, @partial)
                   SORT LENGTH(f.path) ASC
                   LIMIT 1
                   RETURN {_key: f._key, path: f.path}""",
                {"pid": project_id, "partial": target},
            )
            if results:
                file_key = results[0]["_key"]
                target = results[0]["path"]
        except Exception:
            pass

    if file_key is None:
        loc = memory.get_file_loc(target)
        if loc > 0:
            return (f"File '{target}' ({loc} LOC) — no co-change data in graph (re-index with git history).", ["L2"], 0)
        return (_not_found_suggestions(target, "file"), [], 0)

    layers_used.append("graph")

    # Query co-change partners (both directions since edges are directional)
    limit = 5 if depth == "shallow" else 10 if depth == "standard" else 15
    try:
        partners = await graph.query(
            """LET fid = CONCAT('talon_files/', @fkey)
               LET out_edges = (
                   FOR partner, edge IN 1..1 OUTBOUND fid talon_co_changes
                   RETURN {
                       path: partner.path, correlation: edge.correlation,
                       co_change_count: edge.co_change_count,
                       total_changes_a: edge.total_changes_a,
                       total_changes_b: edge.total_changes_b,
                       last_co_change: edge.last_co_change
                   }
               )
               LET in_edges = (
                   FOR partner, edge IN 1..1 INBOUND fid talon_co_changes
                   RETURN {
                       path: partner.path, correlation: edge.correlation,
                       co_change_count: edge.co_change_count,
                       total_changes_a: edge.total_changes_b,
                       total_changes_b: edge.total_changes_a,
                       last_co_change: edge.last_co_change
                   }
               )
               FOR p IN UNION(out_edges, in_edges)
               FILTER p.co_change_count >= 2
               COLLECT path = p.path INTO grouped
               LET best = FIRST(FOR g IN grouped[*].p SORT g.correlation DESC RETURN g)
               SORT best.correlation DESC
               LIMIT @limit
               RETURN best""",
            {"fkey": file_key, "limit": limit},
        )
    except Exception as e:
        logger.warning("Co-change query failed: %s", e)
        partners = []

    if not partners:
        return (f"No co-change partners found for '{target}'.", layers_used, 0)

    lines: list[str] = []

    if depth == "shallow":
        lines.append(f"Co-change partners for '{target}' (top {len(partners)}):")
        for p in partners:
            path = p.get("path") or "?"
            corr = p.get("correlation", 0)
            count = p.get("co_change_count", 0)
            lines.append(f"  {path:<45s} corr={corr:.3f}  ({count} co-changes)")

    elif depth == "standard":
        lines.append(f"Co-change partners for '{target}' (top {len(partners)}):")
        high_coupling = 0
        for p in partners:
            path = p.get("path") or "?"
            corr = p.get("correlation", 0)
            count = p.get("co_change_count", 0)
            last = p.get("last_co_change", "")
            if last:
                last = last[:10]  # date portion only
            changes_a = p.get("total_changes_a", 0)
            changes_b = p.get("total_changes_b", 0)
            lines.append(f"  {path:<45s} corr={corr:.3f}  ({count} co-changes, last: {last})")
            lines.append(f"    target: {changes_a} total changes, partner: {changes_b} total changes")
            if corr > 0.5:
                high_coupling += 1
        if high_coupling:
            lines.append(f"  !! High coupling: {high_coupling} files change together >50% of the time")
            warnings_count += high_coupling

    else:  # full
        # Group by coupling strength
        high = [p for p in partners if p.get("correlation", 0) > 0.5]
        moderate = [p for p in partners if 0.2 < p.get("correlation", 0) <= 0.5]
        low = [p for p in partners if p.get("correlation", 0) <= 0.2]

        lines.append(f"Co-change partners for '{target}' ({len(partners)} partners):")

        if high:
            lines.append("  HIGH COUPLING (corr > 0.5):")
            for p in high:
                path = p.get("path") or "?"
                corr = p.get("correlation", 0)
                count = p.get("co_change_count", 0)
                last = (p.get("last_co_change", "") or "")[:10]
                lines.append(f"    {path:<43s} corr={corr:.3f}  ({count} co-changes, last: {last})")
            warnings_count += len(high)

        if moderate:
            lines.append("  MODERATE COUPLING (0.2 < corr <= 0.5):")
            for p in moderate:
                path = p.get("path") or "?"
                corr = p.get("correlation", 0)
                count = p.get("co_change_count", 0)
                last = (p.get("last_co_change", "") or "")[:10]
                lines.append(f"    {path:<43s} corr={corr:.3f}  ({count} co-changes, last: {last})")

        if low:
            lines.append("  LOW COUPLING (corr <= 0.2):")
            for p in low:
                path = p.get("path") or "?"
                corr = p.get("correlation", 0)
                count = p.get("co_change_count", 0)
                lines.append(f"    {path:<43s} corr={corr:.3f}  ({count} co-changes)")

        lines.append(f"  Summary: {len(high)} high, {len(moderate)} moderate, {len(low)} low coupling partners")

    return ("\n".join(lines), layers_used, warnings_count)


# ---------------------------------------------------------------------------
# Hierarchy Intent (v2 — internal, not exposed in tool schema)
# ---------------------------------------------------------------------------


async def _find_class_nodes(
    target: str, project_id: str, graph: TalonGraph
) -> list[dict[str, Any]]:
    """Find class nodes by name. Returns list of class docs."""
    try:
        return await graph.query(
            """FOR c IN talon_classes
               FILTER c.name == @name AND c.project_id == @pid
               RETURN {
                   _key: c._key, name: c.name, module: c.module,
                   bases: c.bases, decorators: c.decorators,
                   docstring: c.docstring,
                   line_start: c.line_start, line_end: c.line_end
               }""",
            {"name": target, "pid": project_id},
        )
    except Exception:
        return []


async def _build_hierarchy_response(
    target: str, depth: str, project_id: str, graph: TalonGraph, memory: MemoryStore, hops: int | None = None,
) -> tuple[str, list[str], int]:
    """Hierarchy intent: class inheritance — bases and subclasses.

    Traverses talon_inherits edges to find parent and child classes.
    """
    layers_used: list[str] = []
    warnings_count = 0

    class_nodes = await _find_class_nodes(target, project_id, graph)
    if not class_nodes:
        return (_not_found_suggestions(target, "class"), [], 0)

    layers_used.append("graph")
    lines: list[str] = []

    for cls in class_nodes[:3]:  # Limit to 3 matches if name collision
        cls_key = cls["_key"]
        cls_name = cls.get("name", target)
        cls_module = cls.get("module", "")
        cls_path = _module_to_path(cls_module)

        # Subclasses: INBOUND on talon_inherits (child _from -> parent _to)
        try:
            subclasses = await graph.query(
                """FOR child, edge IN 1..1 INBOUND
                   CONCAT('talon_classes/', @ckey) talon_inherits
                   RETURN DISTINCT {
                       name: child.name, module: child.module,
                       bases: child.bases, line_start: child.line_start,
                       line_end: child.line_end, docstring: child.docstring
                   }""",
                {"ckey": cls_key},
            )
        except Exception:
            subclasses = []

        # Base classes: OUTBOUND on talon_inherits (child _from -> parent _to)
        try:
            bases = await graph.query(
                """FOR parent, edge IN 1..1 OUTBOUND
                   CONCAT('talon_classes/', @ckey) talon_inherits
                   RETURN {
                       name: parent.name, module: parent.module,
                       line_start: parent.line_start, line_end: parent.line_end
                   }""",
                {"ckey": cls_key},
            )
        except Exception:
            bases = []

        display = f"{cls_name} ({cls_module})" if cls_module else cls_name

        if depth == "shallow":
            lines.append(f"Hierarchy for '{display}':")
            if subclasses:
                lines.append(f"  Subclasses ({len(subclasses)}):")
                for s in subclasses[:10]:
                    s_path = _module_to_path(s.get("module", ""))
                    lines.append(f"    {s['name']:<30s} {s_path}:{s.get('line_start', '?')}")
            else:
                lines.append("  Subclasses: none")
            if bases:
                lines.append(f"  Bases ({len(bases)}):")
                for b in bases[:5]:
                    b_path = _module_to_path(b.get("module", ""))
                    lines.append(f"    {b['name']:<30s} {b_path}:{b.get('line_start', '?')}")
            else:
                # Fall back to parsed bases list from class node
                parsed_bases = cls.get("bases", [])
                if parsed_bases:
                    lines.append(f"  Bases ({len(parsed_bases)}): {', '.join(parsed_bases)}")
                else:
                    lines.append("  Bases: object (builtin)")

        elif depth == "standard":
            lines.append(f"Hierarchy for '{display}':")
            if subclasses:
                lines.append(f"  Subclasses ({len(subclasses)}):")
                for s in subclasses[:10]:
                    s_path = _module_to_path(s.get("module", ""))
                    s_bases = s.get("bases", [])
                    lines.append(f"    {s['name']:<30s} {s_path}:{s.get('line_start', '?')}")
                    if s_bases:
                        lines.append(f"      bases: [{', '.join(s_bases)}]")
            else:
                lines.append("  Subclasses: none")
            if bases:
                lines.append(f"  Bases ({len(bases)}):")
                for b in bases[:5]:
                    b_path = _module_to_path(b.get("module", ""))
                    lines.append(f"    {b['name']:<30s} {b_path}:{b.get('line_start', '?')}")
            else:
                parsed_bases = cls.get("bases", [])
                if parsed_bases:
                    lines.append(f"  Bases ({len(parsed_bases)}): {', '.join(parsed_bases)}")
                else:
                    lines.append("  Bases: object (builtin)")

        else:  # full
            lines.append(f"Hierarchy for '{display}' ({len(subclasses)} subclasses, {len(bases) or len(cls.get('bases', []))} bases):")
            if subclasses:
                lines.append(f"  Subclasses ({len(subclasses)}):")
                for s in subclasses[:10]:
                    s_path = _module_to_path(s.get("module", ""))
                    s_start = s.get("line_start", "?")
                    s_end = s.get("line_end", s_start)
                    s_bases = s.get("bases", [])
                    lines.append(f"    {s['name']:<30s} {s_path}:{s_start}-{s_end}")
                    if s_bases:
                        lines.append(f"      bases: [{', '.join(s_bases)}]")

                    # Get methods of this subclass
                    try:
                        methods = await graph.query(
                            """FOR f IN talon_functions
                               FILTER f.class_name == @cname AND f.module == @mod AND f.project_id == @pid
                               SORT f.line_start ASC
                               RETURN f.name""",
                            {"cname": s["name"], "mod": s.get("module", ""), "pid": project_id},
                        )
                        if methods:
                            lines.append(f"      methods: {', '.join(methods[:8])}")
                    except Exception:
                        pass

            else:
                lines.append("  Subclasses: none")

            if bases:
                lines.append(f"  Bases ({len(bases)}):")
                for b in bases:
                    b_path = _module_to_path(b.get("module", ""))
                    lines.append(f"    {b['name']:<30s} {b_path}:{b.get('line_start', '?')}")
            else:
                parsed_bases = cls.get("bases", [])
                if parsed_bases:
                    lines.append(f"  Bases ({len(parsed_bases)}): {', '.join(parsed_bases)}")
                else:
                    lines.append("  Bases: object (builtin)")

    return ("\n".join(lines), layers_used, warnings_count)


# ---------------------------------------------------------------------------
# Imports Intent (v2 — internal, not exposed in tool schema)
# ---------------------------------------------------------------------------


async def _find_module_key(
    target: str, project_id: str, graph: TalonGraph
) -> tuple[str | None, str | None]:
    """Find a module's _key by file path or module name.

    Returns (module_key, module_name) or (None, None).
    """
    # Try by path first
    try:
        results = await graph.query(
            """FOR m IN talon_modules
               FILTER m.project_id == @pid AND (m.path == @target OR m.name == @target)
               LIMIT 1
               RETURN {_key: m._key, name: m.name, path: m.path}""",
            {"pid": project_id, "target": target},
        )
        if results:
            return results[0]["_key"], results[0]["name"]
    except Exception:
        pass

    # Try partial path match
    try:
        results = await graph.query(
            """FOR m IN talon_modules
               FILTER m.project_id == @pid AND CONTAINS(m.path, @partial)
               SORT LENGTH(m.path) ASC
               LIMIT 1
               RETURN {_key: m._key, name: m.name, path: m.path}""",
            {"pid": project_id, "partial": target},
        )
        if results:
            return results[0]["_key"], results[0]["name"]
    except Exception:
        pass

    # Try converting file path to module name
    mod_name = _file_path_to_module(target)
    try:
        results = await graph.query(
            """FOR m IN talon_modules
               FILTER m.project_id == @pid AND m.name == @name
               LIMIT 1
               RETURN {_key: m._key, name: m.name}""",
            {"pid": project_id, "name": mod_name},
        )
        if results:
            return results[0]["_key"], results[0]["name"]
    except Exception:
        pass

    return None, None


async def _build_imports_response(
    target: str, depth: str, project_id: str, graph: TalonGraph, memory: MemoryStore, hops: int | None = None,
) -> tuple[str, list[str], int]:
    """Imports intent: module dependency graph — what imports/imported-by.

    Queries talon_imports_edge for both directions.
    """
    layers_used: list[str] = []
    warnings_count = 0

    mod_key, mod_name = await _find_module_key(target, project_id, graph)
    if mod_key is None:
        return (_not_found_suggestions(target, "module"), [], 0)

    layers_used.append("graph")
    mod_id = f"talon_modules/{mod_key}"

    # What does this module import? (OUTBOUND — edge-first to handle missing vertices)
    try:
        imports_out = await graph.query(
            """FOR edge IN talon_imports_edge
               FILTER edge._from == @mid
               LET dep = DOCUMENT(edge._to)
               FILTER dep != null
               RETURN {
                   name: dep.name, path: dep.path,
                   imported_names: edge.imported_names,
                   is_relative: edge.is_relative,
                   is_package: dep.is_package
               }""",
            {"mid": mod_id},
        )
    except Exception:
        imports_out = []

    # Count external/stdlib imports (no vertex doc)
    external_count = 0
    try:
        ext = await graph.query(
            """FOR edge IN talon_imports_edge
               FILTER edge._from == @mid
               LET dep = DOCUMENT(edge._to)
               FILTER dep == null
               COLLECT WITH COUNT INTO cnt
               RETURN cnt""",
            {"mid": mod_id},
        )
        external_count = ext[0] if ext else 0
    except Exception:
        pass

    # What imports this module? (INBOUND — edge-first)
    try:
        imports_in = await graph.query(
            """FOR edge IN talon_imports_edge
               FILTER edge._to == @mid
               LET dep = DOCUMENT(edge._from)
               FILTER dep != null
               RETURN {
                   name: dep.name, path: dep.path,
                   imported_names: edge.imported_names,
                   is_relative: edge.is_relative
               }""",
            {"mid": mod_id},
        )
    except Exception:
        imports_in = []

    if not imports_out and not imports_in:
        return (f"No import edges found for module '{mod_name}' (may need re-index).", layers_used, 0)

    lines: list[str] = []

    ext_note = f" + {external_count} external/stdlib" if external_count else ""

    if depth == "shallow":
        lines.append(f"Import graph for '{target}':")
        if imports_out or external_count:
            lines.append(f"  Imports ({len(imports_out)} internal{ext_note}):")
            for imp in imports_out[:10]:
                name = imp.get("name") or "?"
                path = imp.get("path") or ""
                path_display = path if path else "(external)"
                lines.append(f"    {name:<40s} {path_display}")
        if imports_in:
            lines.append(f"  Imported by ({len(imports_in)}):")
            for imp in imports_in[:10]:
                name = imp.get("name") or "?"
                path = imp.get("path") or ""
                path_display = path if path else "(external)"
                lines.append(f"    {name:<40s} {path_display}")

    elif depth == "standard":
        lines.append(f"Import graph for '{target}':")
        if imports_out or external_count:
            lines.append(f"  Imports ({len(imports_out)} internal{ext_note}):")
            for imp in imports_out[:12]:
                name = imp.get("name") or "?"
                path = imp.get("path") or ""
                path_display = path if path else "(external)"
                lines.append(f"    {name:<40s} {path_display}")
                imported_names = imp.get("imported_names", [])
                if imported_names:
                    rel_tag = "  (relative import)" if imp.get("is_relative") else ""
                    lines.append(f"      names: {', '.join(imported_names[:8])}{rel_tag}")
        if imports_in:
            lines.append(f"  Imported by ({len(imports_in)}):")
            for imp in imports_in[:12]:
                name = imp.get("name") or "?"
                path = imp.get("path") or ""
                path_display = path if path else "(external)"
                lines.append(f"    {name:<40s} {path_display}")
                imported_names = imp.get("imported_names", [])
                if imported_names:
                    lines.append(f"      names: {', '.join(imported_names[:8])}")

        # Check for circular imports
        out_names = {imp.get("name") for imp in imports_out}
        in_names = {imp.get("name") for imp in imports_in}
        circular = out_names & in_names
        if circular:
            for c in circular:
                lines.append(f"  !! Circular: {mod_name} <-> {c}")
            warnings_count += len(circular)

    else:  # full
        lines.append(f"Import graph for '{target}' ({len(imports_out)} internal{ext_note}, {len(imports_in)} imported-by):")
        if imports_out:
            lines.append(f"  Imports ({len(imports_out)}):")
            for imp in imports_out[:15]:
                name = imp.get("name") or "?"
                path = imp.get("path") or ""
                path_display = path if path else "(external)"
                lines.append(f"    {name:<40s} {path_display}")
                imported_names = imp.get("imported_names", [])
                if imported_names:
                    lines.append(f"      names: {', '.join(imported_names[:10])}")
                rel = imp.get("is_relative", False)
                pkg = imp.get("is_package", False)
                tags = []
                if rel:
                    tags.append("relative")
                if pkg:
                    tags.append("package")
                if tags:
                    lines.append(f"      flags: {', '.join(tags)}")

        if imports_in:
            lines.append(f"  Imported by ({len(imports_in)}):")
            for imp in imports_in[:15]:
                name = imp.get("name") or "?"
                path = imp.get("path") or ""
                path_display = path if path else "(external)"
                lines.append(f"    {name:<40s} {path_display}")
                imported_names = imp.get("imported_names", [])
                if imported_names:
                    lines.append(f"      names: {', '.join(imported_names[:10])}")

        # Circular detection
        out_names = {imp.get("name") for imp in imports_out}
        in_names = {imp.get("name") for imp in imports_in}
        circular = out_names & in_names
        if circular:
            for c in circular:
                lines.append(f"  !! Circular: {mod_name} <-> {c}")
            warnings_count += len(circular)

    return ("\n".join(lines), layers_used, warnings_count)


# ---------------------------------------------------------------------------
# Hotspots Intent (v2 — internal, not exposed in tool schema)
# ---------------------------------------------------------------------------


async def _build_hotspots_response(
    target: str, depth: str, project_id: str, graph: TalonGraph, memory: MemoryStore, hops: int | None = None,
) -> tuple[str, list[str], int]:
    """Hotspots intent: change frequency — most volatile files.

    Queries talon_hotspots for change counts, sorted by recency-weighted churn.
    Target can be a directory prefix or project-wide.
    """
    layers_used: list[str] = []
    warnings_count = 0

    limit = 5 if depth == "shallow" else 10 if depth == "standard" else 15

    # Build filter: if target looks like a path, filter by prefix
    is_path = "/" in target or target.endswith("/")

    try:
        if is_path:
            hotspots = await graph.query(
                """FOR h IN talon_hotspots
                   FILTER h.project_id == @pid AND STARTS_WITH(h.file_path, @prefix)
                   SORT h.change_count_30d DESC, h.recency_score DESC
                   LIMIT @limit
                   RETURN h""",
                {"pid": project_id, "prefix": target.rstrip("/") + "/", "limit": limit},
            )
            # Also try without trailing slash for exact prefix
            if not hotspots:
                hotspots = await graph.query(
                    """FOR h IN talon_hotspots
                       FILTER h.project_id == @pid AND CONTAINS(h.file_path, @partial)
                       SORT h.change_count_30d DESC, h.recency_score DESC
                       LIMIT @limit
                       RETURN h""",
                    {"pid": project_id, "partial": target.rstrip("/"), "limit": limit},
                )
        else:
            # Project-wide or use target as project_id
            pid = target if not project_id else project_id
            hotspots = await graph.query(
                """FOR h IN talon_hotspots
                   FILTER h.project_id == @pid
                   SORT h.change_count_30d DESC, h.recency_score DESC
                   LIMIT @limit
                   RETURN h""",
                {"pid": pid, "limit": limit},
            )
    except Exception as e:
        logger.warning("Hotspots query failed: %s", e)
        hotspots = []

    if not hotspots:
        return (f"No hotspot data found for '{target}' in project '{project_id}'.", layers_used, 0)

    layers_used.append("graph")
    lines: list[str] = []

    def _churn_label(changes_30d: int) -> str:
        avg_per_week = changes_30d / 4.3
        if avg_per_week > 2:
            return "HIGH"
        elif avg_per_week >= 0.5:
            return "moderate"
        return "stable"

    if depth == "shallow":
        label = target if is_path else project_id
        lines.append(f"Hotspots in '{label}' (top {len(hotspots)}, last 30 days):")
        for h in hotspots:
            path = h.get("file_path", "?")
            c30 = h.get("change_count_30d", 0)
            avg = h.get("avg_changes_per_week", 0)
            churn = _churn_label(c30)
            lines.append(f"  {path:<45s} {c30:>3d} changes   {avg:.1f}/week   {churn}")

    elif depth == "standard":
        label = target if is_path else project_id
        lines.append(f"Hotspots in '{label}' (top {len(hotspots)}, last 90 days):")
        high_count = 0
        for h in hotspots:
            path = h.get("file_path", "?")
            c30 = h.get("change_count_30d", 0)
            c90 = h.get("change_count_90d", 0)
            avg = h.get("avg_changes_per_week", 0)
            recency = h.get("recency_score", 0)
            churn = _churn_label(c30)
            authors = h.get("authors", [])
            lines.append(f"  {path:<45s} 30d={c30:<4d} 90d={c90:<4d} {avg:.1f}/week  recency={recency:.2f}   {churn}")
            if authors:
                lines.append(f"    authors: {len(authors)} contributors")
            if churn == "HIGH":
                high_count += 1
        if high_count:
            lines.append(f"  !! {high_count} files with HIGH churn — consider careful review")
            warnings_count += high_count

    else:  # full
        label = target if is_path else project_id
        lines.append(f"Hotspots in '{label}' ({len(hotspots)} files):")

        # Group by churn level
        high_files = [h for h in hotspots if _churn_label(h.get("change_count_30d", 0)) == "HIGH"]
        mod_files = [h for h in hotspots if _churn_label(h.get("change_count_30d", 0)) == "moderate"]
        stable_files = [h for h in hotspots if _churn_label(h.get("change_count_30d", 0)) == "stable"]

        if high_files:
            lines.append("  HIGH CHURN (>2/week):")
            for h in high_files:
                path = h.get("file_path", "?")
                c30 = h.get("change_count_30d", 0)
                c90 = h.get("change_count_90d", 0)
                avg = h.get("avg_changes_per_week", 0)
                last = (h.get("last_changed", "") or "")[:10]
                lines.append(f"    {path:<43s} 30d={c30}  90d={c90}  {avg:.1f}/week  last: {last}")
                authors = h.get("authors", [])
                if authors:
                    lines.append(f"      authors: {', '.join(authors[:5])}")
            warnings_count += len(high_files)

        if mod_files:
            lines.append("  MODERATE (0.5-2/week):")
            for h in mod_files:
                path = h.get("file_path", "?")
                c30 = h.get("change_count_30d", 0)
                c90 = h.get("change_count_90d", 0)
                avg = h.get("avg_changes_per_week", 0)
                last = (h.get("last_changed", "") or "")[:10]
                lines.append(f"    {path:<43s} 30d={c30}  90d={c90}  {avg:.1f}/week  last: {last}")

        if stable_files:
            lines.append("  STABLE (<0.5/week):")
            for h in stable_files:
                path = h.get("file_path", "?")
                c30 = h.get("change_count_30d", 0)
                c90 = h.get("change_count_90d", 0)
                avg = h.get("avg_changes_per_week", 0)
                lines.append(f"    {path:<43s} 30d={c30}  90d={c90}  {avg:.1f}/week")

        lines.append(f"  Summary: {len(high_files)} high churn, {len(mod_files)} moderate, {len(stable_files)} stable")

    return ("\n".join(lines), layers_used, warnings_count)


# ---------------------------------------------------------------------------
# Dead Code Intent (v2 — internal, not exposed in tool schema)
# ---------------------------------------------------------------------------

# Functions to exclude from dead code analysis (always called implicitly)
_DEAD_CODE_EXCLUDE_NAMES = frozenset({
    "__init__", "__new__", "__del__", "__str__", "__repr__", "__hash__",
    "__eq__", "__ne__", "__lt__", "__le__", "__gt__", "__ge__",
    "__bool__", "__len__", "__iter__", "__next__", "__contains__",
    "__getitem__", "__setitem__", "__delitem__", "__getattr__", "__setattr__",
    "__enter__", "__exit__", "__aenter__", "__aexit__",
    "__call__", "__get__", "__set__", "__delete__",
    "__add__", "__sub__", "__mul__", "__truediv__",
    "main", "setup", "teardown", "setUp", "tearDown",
})

_DEAD_CODE_EXCLUDE_PREFIXES = ("test_", "_test", "conftest")


async def _build_dead_response(
    target: str, depth: str, project_id: str, graph: TalonGraph, memory: MemoryStore, hops: int | None = None,
) -> tuple[str, list[str], int]:
    """Dead code intent: functions with zero callers.

    Finds functions that have no inbound talon_calls edges, excluding
    dunder methods, test functions, and common entrypoints.
    """
    layers_used: list[str] = []
    warnings_count = 0

    limit = 15 if depth == "shallow" else 25 if depth == "standard" else 25

    # Build path filter
    is_path = "/" in target or target.endswith("/")

    try:
        if is_path:
            # Filter by module path prefix
            mod_prefix = _file_path_to_module(target.rstrip("/"))
            dead_fns = await graph.query(
                """FOR f IN talon_functions
                   FILTER f.project_id == @pid
                   FILTER STARTS_WITH(f.module, @prefix)
                   LET caller_count = LENGTH(
                       FOR c IN 1..1 INBOUND CONCAT("talon_functions/", f._key) talon_calls
                       LIMIT 1 RETURN 1
                   )
                   FILTER caller_count == 0
                   SORT f.module ASC, f.line_start ASC
                   LIMIT @limit
                   RETURN {
                       name: f.name, module: f.module, class_name: f.class_name,
                       line_start: f.line_start, line_end: f.line_end,
                       params: f.params, is_async: f.is_async
                   }""",
                {"pid": project_id, "prefix": mod_prefix, "limit": limit * 3},
            )
        else:
            # Use target as project_id or search project-wide
            pid = target if not project_id else project_id
            dead_fns = await graph.query(
                """FOR f IN talon_functions
                   FILTER f.project_id == @pid
                   LET caller_count = LENGTH(
                       FOR c IN 1..1 INBOUND CONCAT("talon_functions/", f._key) talon_calls
                       LIMIT 1 RETURN 1
                   )
                   FILTER caller_count == 0
                   SORT f.module ASC, f.line_start ASC
                   LIMIT @limit
                   RETURN {
                       name: f.name, module: f.module, class_name: f.class_name,
                       line_start: f.line_start, line_end: f.line_end,
                       params: f.params, is_async: f.is_async
                   }""",
                {"pid": pid, "limit": limit * 3},
            )
    except Exception as e:
        logger.warning("Dead code query failed: %s", e)
        dead_fns = []

    # Filter out excluded names client-side (faster than complex AQL)
    filtered = []
    for fn in dead_fns:
        name = fn.get("name", "")
        if name in _DEAD_CODE_EXCLUDE_NAMES:
            continue
        if any(name.startswith(p) for p in _DEAD_CODE_EXCLUDE_PREFIXES):
            continue
        # Skip property-like single-line functions (getters)
        if fn.get("line_end") and fn.get("line_start"):
            if fn["line_end"] - fn["line_start"] <= 1 and name.startswith("_"):
                continue
        filtered.append(fn)

    dead_fns = filtered[:limit]

    if not dead_fns:
        label = target if is_path else project_id
        return (f"No uncalled functions found in '{label}' (after excluding dunders/tests).", layers_used, 0)

    layers_used.append("graph")
    lines: list[str] = []
    label = target if is_path else project_id

    if depth == "shallow":
        lines.append(f"Uncalled functions in '{label}' ({len(dead_fns)} found):")
        for fn in dead_fns:
            name = fn.get("name", "?")
            cls = fn.get("class_name")
            display = f"{cls}.{name}" if cls else name
            path = _module_to_path(fn.get("module", ""))
            lines.append(f"  {display:<35s} {path}:{fn.get('line_start', '?')}")

    else:  # standard
        # Group by module
        modules: dict[str, list[dict]] = {}
        for fn in dead_fns:
            mod = fn.get("module", "unknown")
            modules.setdefault(mod, []).append(fn)

        class_count = len({fn.get("class_name") for fn in dead_fns if fn.get("class_name")})
        lines.append(f"Uncalled functions in '{label}' ({len(dead_fns)} found, {class_count} classes, {len(modules)} modules):")

        for fn in dead_fns:
            name = fn.get("name", "?")
            cls = fn.get("class_name")
            display = f"{cls}.{name}" if cls else name
            path = _module_to_path(fn.get("module", ""))
            async_tag = "  async" if fn.get("is_async") else ""
            lines.append(f"  {display:<35s} {path}:{fn.get('line_start', '?')}")

            params = fn.get("params") or []
            if params:
                param_str = ", ".join(params[:6])
                lines.append(f"    params: ({param_str}){async_tag}")

            # Flag large functions as removal candidates
            start = fn.get("line_start", 0)
            end = fn.get("line_end", 0)
            if start and end and (end - start) > 30:
                lines.append(f"    !! Large function ({end - start} lines) — candidate for removal")
                warnings_count += 1

        lines.append(f"  Excluded: {', '.join(sorted(list(_DEAD_CODE_EXCLUDE_NAMES)[:6]))}..., test_*")

    return ("\n".join(lines), layers_used, warnings_count)


# ---------------------------------------------------------------------------
# Cycles Intent (v2 — internal, not exposed in tool schema)
# ---------------------------------------------------------------------------


async def _build_cycles_response(
    target: str, depth: str, project_id: str, graph: TalonGraph, memory: MemoryStore, hops: int | None = None,
) -> tuple[str, list[str], int]:
    """Cycles intent: circular dependencies in import graph.

    Finds module pairs where A imports B AND B imports A.
    Also detects longer cycles (3-hop) at full depth.
    """
    layers_used: list[str] = []
    warnings_count = 0

    is_path = "/" in target or target.endswith("/")

    # Find 2-node cycles (A <-> B)
    try:
        if is_path:
            mod_prefix = _file_path_to_module(target.rstrip("/"))
            cycles_2 = await graph.query(
                """FOR m IN talon_modules
                   FILTER m.project_id == @pid
                   FILTER STARTS_WITH(m.name, @prefix)
                   FOR dep, e1 IN 1..1 OUTBOUND CONCAT("talon_modules/", m._key) talon_imports_edge
                   FILTER dep != null
                   FOR back, e2 IN 1..1 OUTBOUND CONCAT("talon_modules/", dep._key) talon_imports_edge
                   FILTER back._key == m._key
                   RETURN DISTINCT {
                       a_name: m.name, a_path: m.path,
                       b_name: dep.name, b_path: dep.path,
                       a_imports: e1.imported_names,
                       b_imports: e2.imported_names
                   }""",
                {"pid": project_id, "prefix": mod_prefix},
            )
        else:
            pid = target if not project_id else project_id
            cycles_2 = await graph.query(
                """FOR m IN talon_modules
                   FILTER m.project_id == @pid
                   FOR dep, e1 IN 1..1 OUTBOUND CONCAT("talon_modules/", m._key) talon_imports_edge
                   FILTER dep != null
                   FOR back, e2 IN 1..1 OUTBOUND CONCAT("talon_modules/", dep._key) talon_imports_edge
                   FILTER back._key == m._key
                   RETURN DISTINCT {
                       a_name: m.name, a_path: m.path,
                       b_name: dep.name, b_path: dep.path,
                       a_imports: e1.imported_names,
                       b_imports: e2.imported_names
                   }""",
                {"pid": pid},
            )
    except Exception as e:
        logger.warning("Cycles query failed: %s", e)
        cycles_2 = []

    # Deduplicate: (A,B) and (B,A) are the same cycle
    seen_pairs: set[tuple[str, str]] = set()
    unique_cycles: list[dict] = []
    for c in cycles_2:
        a = c.get("a_name", "")
        b = c.get("b_name", "")
        pair = tuple(sorted([a, b]))
        if pair not in seen_pairs:
            seen_pairs.add(pair)
            unique_cycles.append(c)

    # Find 3-node cycles at full depth
    cycles_3: list[dict] = []
    if depth == "full":
        try:
            if is_path:
                mod_prefix = _file_path_to_module(target.rstrip("/"))
                cycles_3 = await graph.query(
                    """FOR m IN talon_modules
                       FILTER m.project_id == @pid AND STARTS_WITH(m.name, @prefix)
                       FOR b, e1 IN 1..1 OUTBOUND CONCAT("talon_modules/", m._key) talon_imports_edge
                       FILTER b != null
                       FOR c, e2 IN 1..1 OUTBOUND CONCAT("talon_modules/", b._key) talon_imports_edge
                       FILTER c != null AND c._key != m._key
                       FOR back, e3 IN 1..1 OUTBOUND CONCAT("talon_modules/", c._key) talon_imports_edge
                       FILTER back._key == m._key
                       SORT m.name ASC, b.name ASC, c.name ASC
                       LIMIT 10
                       RETURN DISTINCT {
                           a: m.name, b: b.name, c: c.name
                       }""",
                    {"pid": project_id, "prefix": mod_prefix},
                )
            else:
                pid = target if not project_id else project_id
                cycles_3 = await graph.query(
                    """FOR m IN talon_modules
                       FILTER m.project_id == @pid
                       FOR b, e1 IN 1..1 OUTBOUND CONCAT("talon_modules/", m._key) talon_imports_edge
                       FILTER b != null
                       FOR c, e2 IN 1..1 OUTBOUND CONCAT("talon_modules/", b._key) talon_imports_edge
                       FILTER c != null AND c._key != m._key
                       FOR back, e3 IN 1..1 OUTBOUND CONCAT("talon_modules/", c._key) talon_imports_edge
                       FILTER back._key == m._key
                       SORT m.name ASC, b.name ASC, c.name ASC
                       LIMIT 10
                       RETURN DISTINCT {
                           a: m.name, b: b.name, c: c.name
                       }""",
                    {"pid": pid},
                )
        except Exception:
            cycles_3 = []

    label = target if is_path else project_id

    if not unique_cycles and not cycles_3:
        return (f"No circular dependencies found in '{label}'.", layers_used, 0)

    layers_used.append("graph")
    lines: list[str] = []
    total = len(unique_cycles) + len(cycles_3)

    if depth == "shallow":
        lines.append(f"Circular dependencies in '{label}' ({total} cycles):")
        for i, c in enumerate(unique_cycles[:15], 1):
            lines.append(f"  {c.get('a_name', '?')} <-> {c.get('b_name', '?')}")

    elif depth == "standard":
        lines.append(f"Circular dependencies in '{label}' ({total} cycles):")
        for i, c in enumerate(unique_cycles[:10], 1):
            a_name = c.get("a_name", "?")
            b_name = c.get("b_name", "?")
            lines.append(f"  Cycle {i}: {a_name} <-> {b_name}")
            a_imports = c.get("a_imports") or []
            b_imports = c.get("b_imports") or []
            if a_imports:
                lines.append(f"    {a_name.rsplit('.', 1)[-1]} imports: {', '.join(a_imports[:5])}")
            if b_imports:
                lines.append(f"    {b_name.rsplit('.', 1)[-1]} imports: {', '.join(b_imports[:5])}")
            lines.append(f"    !! Tight coupling — consider interface extraction")
            warnings_count += 1

    else:  # full
        lines.append(f"Circular dependencies in '{label}' ({len(unique_cycles)} direct, {len(cycles_3)} triangular):")
        if unique_cycles:
            lines.append("  Direct cycles (A <-> B):")
            for i, c in enumerate(unique_cycles[:10], 1):
                a_name = c.get("a_name", "?")
                b_name = c.get("b_name", "?")
                a_path = c.get("a_path") or ""
                b_path = c.get("b_path") or ""
                lines.append(f"    Cycle {i}: {a_name} <-> {b_name}")
                a_imports = c.get("a_imports") or []
                b_imports = c.get("b_imports") or []
                if a_imports:
                    lines.append(f"      {a_path}: imports {', '.join(a_imports[:5])}")
                if b_imports:
                    lines.append(f"      {b_path}: imports {', '.join(b_imports[:5])}")
                warnings_count += 1
        if cycles_3:
            lines.append("  Triangular cycles (A -> B -> C -> A):")
            for c in cycles_3[:5]:
                lines.append(f"    {c.get('a', '?')} -> {c.get('b', '?')} -> {c.get('c', '?')} -> {c.get('a', '?')}")
                warnings_count += 1

    return ("\n".join(lines), layers_used, warnings_count)


# ---------------------------------------------------------------------------
# Data Flow Intent (v2 — internal, not exposed in tool schema)
# ---------------------------------------------------------------------------


async def _build_dataflow_response(
    target: str, depth: str, project_id: str, graph: TalonGraph, memory: MemoryStore, hops: int | None = None,
) -> tuple[str, list[str], int]:
    """Data flow intent: parameter flow across call chain.

    Queries talon_data_flows edges to trace how a parameter name
    flows from function to function through call chains.
    """
    layers_used: list[str] = []
    warnings_count = 0

    max_hops = min(hops or 1, 5)
    limit = 10 if depth == "shallow" else 20 if depth == "standard" else 30

    # Check if data_flows collection has data
    try:
        count_result = await graph.query("RETURN LENGTH(talon_data_flows)", {})
        total_flows = count_result[0] if count_result else 0
    except Exception:
        total_flows = 0

    if total_flows == 0:
        return (
            "No data flow edges available. Run the data flow indexer first:\n"
            "  python -c \"from talon.indexer.data_flows import compute_and_store; ...\"\n"
            "The indexer analyzes parameter overlap across talon_calls edges.",
            [], 0,
        )

    layers_used.append("graph")

    # Query data flows for the target parameter name
    try:
        flows = await graph.query(
            """FOR e IN talon_data_flows
               FILTER e.variable == @param
               FILTER e.project_id == @pid OR @pid == ""
               LET caller = DOCUMENT(e._from)
               LET callee = DOCUMENT(e._to)
               FILTER caller != null AND callee != null
               LIMIT @limit
               RETURN {
                   caller_name: caller.name, caller_module: caller.module,
                   caller_line: caller.line_start,
                   callee_name: callee.name, callee_module: callee.module,
                   callee_line: callee.line_start,
                   variable: e.variable, through_param: e.through_param,
                   source_type: e.source_type
               }""",
            {"param": target, "pid": project_id, "limit": limit},
        )
    except Exception as e:
        logger.warning("Data flow query failed: %s", e)
        flows = []

    if not flows:
        # Try searching for functions that have this parameter
        try:
            fns_with_param = await graph.query(
                """FOR f IN talon_functions
                   FILTER f.project_id == @pid
                   FILTER @param IN f.params
                   SORT f.module ASC, f.line_start ASC
                   LIMIT 5
                   RETURN {name: f.name, module: f.module, line_start: f.line_start}""",
                {"pid": project_id, "param": target},
            )
        except Exception:
            fns_with_param = []

        if fns_with_param:
            lines = [f"No data flow edges for parameter '{target}', but found in {len(fns_with_param)} functions:"]
            for fn in fns_with_param:
                path = _module_to_path(fn.get("module", ""))
                lines.append(f"  {fn.get('name', '?')}  {path}:{fn.get('line_start', '?')}")
            lines.append("Run the data flow indexer to compute flow edges.")
            return ("\n".join(lines), layers_used, 0)

        return (f"Parameter '{target}' not found in any function signatures.", layers_used, 0)

    lines: list[str] = []
    affected_files: set[str] = set()

    if depth == "shallow":
        lines.append(f"Data flow for parameter '{target}' ({len(flows)} paths):")
        for f in flows:
            caller = f.get("caller_name", "?")
            callee = f.get("callee_name", "?")
            var = f.get("variable", target)
            lines.append(f"  {caller}({var}) -> {callee}({var})")

    elif depth == "standard":
        lines.append(f"Data flow for parameter '{target}' ({len(flows)} paths):")
        for f in flows:
            caller = f.get("caller_name", "?")
            callee = f.get("callee_name", "?")
            var = f.get("variable", target)
            caller_path = _module_to_path(f.get("caller_module", ""))
            callee_path = _module_to_path(f.get("callee_module", ""))
            lines.append(f"  {caller}({var}) -> {callee}({var})")
            lines.append(f"    {caller_path}:{f.get('caller_line', '?')} -> {callee_path}:{f.get('callee_line', '?')}")
            affected_files.add(caller_path)
            affected_files.add(callee_path)

        if len(affected_files) > 1:
            lines.append(f"  !! Parameter '{target}' flows through {len(flows)} functions across {len(affected_files)} files")
            warnings_count += 1

    else:  # full
        lines.append(f"Data flow for parameter '{target}' ({len(flows)} paths):")

        # Group by caller for a tree-like view
        by_caller: dict[str, list[dict]] = {}
        for f in flows:
            caller = f.get("caller_name", "?")
            by_caller.setdefault(caller, []).append(f)

        for caller, callees in by_caller.items():
            first = callees[0]
            caller_path = _module_to_path(first.get("caller_module", ""))
            lines.append(f"  {caller}({target})  {caller_path}:{first.get('caller_line', '?')}")
            affected_files.add(caller_path)
            for c in callees:
                callee = c.get("callee_name", "?")
                callee_path = _module_to_path(c.get("callee_module", ""))
                lines.append(f"    -> {callee}({target})  {callee_path}:{c.get('callee_line', '?')}")
                affected_files.add(callee_path)

        if affected_files:
            lines.append(f"  Affected files: {len(affected_files)} ({', '.join(sorted(affected_files)[:5])})")
        if len(affected_files) > 2:
            lines.append(f"  !! Renaming '{target}' requires changes in {len(flows)} functions across {len(affected_files)} files")
            warnings_count += 1

    return ("\n".join(lines), layers_used, warnings_count)


# ---------------------------------------------------------------------------
# Search (content keyword search via L1 cache)
# ---------------------------------------------------------------------------

async def _build_search_response(
    target: str, depth: str, project_id: str,
    graph: "TalonGraph", memory: "MemoryStore", hops: int | None = None,
) -> tuple[str, list[str], int]:
    """Content search across codebase files via MemoryStore L1.

    Target format: "pattern" or "pattern | file_filter"
    """
    layers_used = ["L1"]
    warnings_count = 0

    parts = target.split("|", 1)
    pattern = parts[0].strip()
    file_filter = parts[1].strip() if len(parts) > 1 else None

    if not pattern:
        return ("search: empty pattern", [], 0)

    # Warn on regex metacharacters that suggest the agent is misusing search.
    # Common mistake: using \| for OR (the | is the file_filter separator).
    regex_meta = {"\\|", ".*", "\\d", "\\w", "\\s", ".+", "[^"}
    if any(m in pattern for m in regex_meta):
        hint = (
            f"Warning: search target '{pattern[:60]}' contains regex metacharacters. "
            "search uses plain keyword matching (case-insensitive). "
            "The `|` character separates pattern from file filter — it is NOT regex OR. "
            "For multiple keywords, make separate search calls.\n\n"
        )
        warnings_count += 1
    else:
        hint = ""

    max_results = {"shallow": 10, "standard": 20, "full": 40}.get(depth, 20)
    results = memory.search_content(pattern, file_filter=file_filter, max_results=max_results)

    if not results:
        _log_not_found(target, "content", "search")
        msg = hint + f"No matches for '{pattern}'"
        if file_filter:
            msg += f" in {file_filter}"
        msg += ". Try: locate (symbol names), toc (file structure), or broaden the filter."
        return (msg, layers_used, 1)

    # Group by file
    from collections import defaultdict
    by_file: dict[str, list[tuple[int, str]]] = defaultdict(list)
    for fpath, line_no, line_text in results:
        by_file[fpath].append((line_no, line_text))

    lines: list[str] = [f"Search '{pattern}': {len(results)} matches in {len(by_file)} files"]
    if file_filter:
        lines.append(f"  (filter: {file_filter})")

    for fpath, matches in by_file.items():
        lines.append(f"\n  {fpath}:")
        for line_no, text in matches:
            if depth == "shallow":
                lines.append(f"    :{line_no}")
            else:
                lines.append(f"    :{line_no}  {text[:120]}")

    response = hint + "\n".join(lines)
    # Cap search response to prevent giant outputs on broad queries
    _search_cap = 6000  # ~1500 tokens
    if len(response) > _search_cap:
        response = response[:_search_cap] + f"\n  ... (truncated — {len(results)} total matches, showing first {_search_cap} chars. Use a more specific pattern or file filter.)"
    return (response, layers_used, warnings_count)


# ---------------------------------------------------------------------------
# Insert Intent — find exact insertion point in a file
# ---------------------------------------------------------------------------

async def _build_insert_response(
    target: str,
    depth: str,
    project_id: str,
    graph: TalonGraph,
    memory: MemoryStore,
    hops: int | None = None,
) -> tuple[str, list[str], int]:
    """Find the insertion point in a file for adding new code.

    Target format: "file.py::ClassName" or "file.py::ClassName::after_method"
    or just "file.py::after_function".

    Returns the exact line number + surrounding context (~5 lines) so the agent
    can use edit_batch without scroll-scanning through the file.

    Returns: (response_text, layers_used, warnings_count)
    """
    layers_used: list[str] = []
    warnings_count = 0

    # Parse target: "file.py::Class::after_method" or "file.py::after_symbol"
    parts = [p.strip() for p in target.split("::")]
    if len(parts) < 2:
        return (
            f"insert requires target format: file.py::ClassName or file.py::ClassName::after_method\n"
            f"Got: {target!r}",
            layers_used, 1,
        )

    file_path = parts[0]
    class_name = parts[1] if len(parts) >= 3 else None
    after_symbol = parts[-1]  # Last part is always the "after" anchor

    # Get symbols from memory (fast path)
    symbols = memory.get_file_symbols(file_path) if memory else []
    if symbols:
        layers_used.append("L1")
    else:
        # Fall back to graph
        layers_used.append("graph")
        module_key = _file_path_to_module(file_path)
        func_results = await graph.query(
            """FOR f IN talon_functions
               FILTER f.module == @module AND f.project_id == @pid
               SORT f.line_start
               RETURN {
                   name: f.name,
                   class_name: f.class_name,
                   line_start: f.line_start,
                   line_end: f.line_end,
                   type: f.class_name ? "method" : "function"
               }""",
            {"module": module_key, "pid": project_id},
        )
        symbols = func_results

    if not symbols:
        return (f"No symbols found in {file_path}", layers_used, 1)

    # Filter to class if specified
    if class_name:
        class_symbols = [s for s in symbols if s.get("class_name") == class_name]
        if not class_symbols:
            # Try case-insensitive
            class_symbols = [s for s in symbols if (s.get("class_name") or "").lower() == class_name.lower()]
        if class_symbols:
            symbols = class_symbols

    # Find the "after" symbol
    after_sym = None
    for s in symbols:
        if s.get("name") == after_symbol or s.get("name", "").lower() == after_symbol.lower():
            after_sym = s
    if after_sym is None:
        # If after_symbol matches the class name, insert after last method in class
        if class_name and after_symbol.lower() == class_name.lower():
            after_sym = symbols[-1]  # Last symbol in class
        else:
            # Try prefix match
            for s in symbols:
                if s.get("name", "").lower().startswith(after_symbol.lower()):
                    after_sym = s
                    break

    if after_sym is None:
        # Default: insert after the last symbol in the file/class
        after_sym = symbols[-1]
        warnings_count += 1

    insert_line = after_sym.get("line_end", 0) + 1

    # Get surrounding context (last 4 lines of after_sym + next 4 lines)
    context_start = max(1, after_sym.get("line_end", 1) - 3)
    context_end = after_sym.get("line_end", 1) + 4

    context_lines: list[str] = []
    if memory:
        src = memory.get_lines(file_path, context_start, context_end)
        if src:
            for i, sl in enumerate(src):
                ln = context_start + i
                marker = "  ← INSERT HERE" if ln == insert_line else ""
                context_lines.append(f"{ln}│{sl.rstrip()}{marker}")

    # Build response
    file_loc = memory.get_file_loc(file_path) if memory else 0
    lines: list[str] = []
    lines.append(f"Insert point: {file_path}:{insert_line}")
    lines.append(f"After: {after_sym.get('name')} (lines {after_sym.get('line_start')}-{after_sym.get('line_end')})")
    if file_loc:
        lines.append(f"File: {file_loc} LOC, {len(symbols)} symbols")

    if context_lines:
        lines.append("")
        lines.append("Context:")
        lines.extend(context_lines)

    # Show nearby symbols for orientation
    lines.append("")
    lines.append("Nearby symbols:")
    after_end = after_sym.get("line_end", 0)
    nearby = [s for s in symbols if abs(s.get("line_start", 0) - after_end) < 50]
    for s in nearby[-5:]:
        marker = " ◀ after this" if s is after_sym else ""
        lines.append(f"  {s.get('name')} ({s.get('line_start')}-{s.get('line_end')}){marker}")

    response = "\n".join(lines)
    return (response, layers_used, warnings_count)


# ---------------------------------------------------------------------------
# Handler Registry
# ---------------------------------------------------------------------------

_INTENT_HANDLERS = {
    "toc": _build_toc_response,
    "locate": _build_locate_response,
    "callers": _build_callers_response,
    "blast": _build_blast_response,
    "coverage": _build_coverage_response,
    "flow": _build_flow_response,
    "sync": _handle_sync_notification,
    "scope": _build_scope_response,
    "cg": _build_cg_response,
    "cg_update": _handle_cg_update,
    "search": _build_search_response,
    "insert": _build_insert_response,
    # v2 intents — internal only (not in ALL_INTENTS / SUPPORTED_INTENTS)
    "cochange": _build_cochange_response,
    "hierarchy": _build_hierarchy_response,
    "imports": _build_imports_response,
    "hotspots": _build_hotspots_response,
    "dead": _build_dead_response,
    "cycles": _build_cycles_response,
    "dataflow": _build_dataflow_response,
}
