"""Talon v5 Local MCP Server (stdio transport).

Single-tool architecture: one graph_query tool with intent routing,
three-layer memory cache, pre-warming, and fire-and-forget telemetry.

Replaces the multi-tool HTTP/SSE server for local Claude Code sessions.

Implements: v5 Phase 0-4
"""

from __future__ import annotations

import argparse
import asyncio
import logging
import os
import re
import subprocess
import sys
import time
from pathlib import Path
from typing import Any

from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import TextContent, Tool

from talon.cache.memory_store import MemoryStore
from talon.cache.pre_warmer import PreWarmer
from talon.mcp.contracts import build_graph_query_tool, load_contracts
from talon.mcp.intent_router import route_intent, set_cg_store, set_pre_warmer
from talon.mcp.telemetry_logger import TelemetryLogger, ToolCallMetric

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Module-level state (initialised in main)
# ---------------------------------------------------------------------------

app = Server("talon-context-v5")

_memory_store: MemoryStore | None = None
_graph_client: Any = None  # TalonGraph instance
_telemetry: TelemetryLogger | None = None
_pre_warmer: PreWarmer | None = None
_health_reporter: Any = None  # HealthReporter instance (set in _initialize)
_project_id: str = ""
_project_path: str = ""
_tool_def: dict[str, Any] = {}

# ── Read-ahead monitor state ─────────────────────────────────────────────
# Tracks predictions from _extract_same_file_callees() across calls.
# When TALON_READAHEAD_MONITOR=1, predictions are logged to autobot DB
# and checked against subsequent smart_read_batch targets for hit/miss.
_ra_monitor_session: str = ""          # session ID for DB grouping
_ra_monitor_call: int = 0             # increments per smart_read_batch call
_ra_pending_predictions: list[dict] = []  # [{symbol, file, source_symbol, source_file, call_number}]
_ra_store: Any = None                 # lazy AutobotStore instance

# ── Precision tracking state (TALON_PRECISION_TRACKING=1) ─────────────────
# Tracks scope→edit overlap: which scope-served files/symbols actually get edited.
_pt_enabled: bool = False
_pt_served_files: set[str] = set()          # files from scope TALON_META
_pt_served_symbols: dict[str, str] = {}     # symbol_name → file_path
_pt_edits_in_scope: int = 0                 # edit_batch files that were in scope
_pt_edits_total: int = 0                    # total edit_batch files
_pt_scope_calls: int = 0                    # how many scope calls

# ── Navigation budget gate (TALON_NAV_BUDGET=N) ────────────────────────────
# Caps consecutive graph_query + smart_read_batch calls to prevent
# exploration spirals.  Resets on any edit_batch or write_batch.
_nav_budget_cap: int = 0                    # 0 = disabled
_nav_consecutive: int = 0                   # current consecutive nav count


# ---------------------------------------------------------------------------
# MCP Tool Registration
# ---------------------------------------------------------------------------


@app.list_tools()
async def list_tools() -> list[Tool]:
    """Return available tools: graph_query always, smart_read when TALON_SMART_READ=1."""
    import os

    tools = [
        Tool(
            name=_tool_def.get("name", "graph_query"),
            description=_tool_def.get("description", "Query the code graph."),
            inputSchema=_tool_def.get("inputSchema", {}),
        )
    ]

    if os.environ.get("TALON_SMART_READ") == "1":
        tools.append(
            Tool(
                name="smart_read",
                description=(
                    "Read a specific function or class body from a source file. "
                    "Returns ONLY the targeted symbol's source (~50-200 tokens) instead of "
                    "the entire file. Use this instead of Read when you know the symbol name."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "file": {
                            "type": "string",
                            "description": "Relative path to the source file (e.g. 'celery/app/base.py')",
                        },
                        "symbol": {
                            "type": "string",
                            "description": "Function or class name to read (e.g. 'handle_request')",
                        },
                        "context": {
                            "type": "integer",
                            "description": "Lines of context before/after the function body (0-20, default 0). Use 3-5 for Edit prep.",
                            "default": 0,
                        },
                    },
                    "required": ["file", "symbol"],
                },
            )
        )

    if os.environ.get("TALON_SMART_EDIT") == "1":
        tools.append(
            Tool(
                name="smart_edit",
                description=(
                    "Get a function body formatted for Edit tool preparation. "
                    "Returns the function source with an Edit hint showing the def line "
                    "as old_string. Use this when you need to modify a specific function."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "file": {
                            "type": "string",
                            "description": "Relative path to the source file (e.g. 'celery/app/base.py')",
                        },
                        "symbol": {
                            "type": "string",
                            "description": "Function or class name to prepare for editing (e.g. 'handle_request')",
                        },
                    },
                    "required": ["file", "symbol"],
                },
            )
        )

    if os.environ.get("TALON_SMART_READ") == "1":
        tools.append(
            Tool(
                name="smart_read_batch",
                description=(
                    "Read multiple function/class bodies or line ranges in a single call (up to 20 targets). "
                    "Returns all requested content concatenated, saving multiple round-trips. "
                    "IMPORTANT: batch ALL symbols you need into ONE call — do not split across multiple calls. "
                    "Three modes: {file, symbol} for symbol lookup, {file, lines: '100-150'} for "
                    "line-range read, {file, symbol, lines: '±10'} for symbol body with padding."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "targets": {
                            "description": "List of targets to read. Each needs 'file' plus 'symbol' and/or 'lines'. Pass as a JSON array.",
                            "items": {
                                "type": "object",
                                "properties": {
                                    "file": {"type": "string", "description": "Relative file path"},
                                    "symbol": {"type": "string", "description": "Function or class name (optional if lines provided)"},
                                    "lines": {"type": "string", "description": "Line range: '100-150' for absolute range, '±10' for padding around symbol"},
                                    "context": {"type": "integer", "description": "Lines before/after symbol body (0-20, default 0)"},
                                },
                                "required": ["file"],
                            },
                        },
                    },
                    "required": ["targets"],
                },
            )
        )

    if os.environ.get("TALON_EDIT_BATCH") == "1":
        tools.append(
            Tool(
                name="edit_batch",
                description=(
                    "Apply multiple file edits in a single call. Each edit replaces "
                    "old_string with new_string in the specified file. old_string must "
                    "be unique in the file. Use this instead of sequential Edit calls "
                    "when you have 2+ edits ready. Saves one API round-trip per edit."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "edits": {
                            "description": "List of edits to apply. Pass as a JSON array.",
                            "items": {
                                "type": "object",
                                "properties": {
                                    "file_path": {
                                        "type": "string",
                                        "description": "File path (absolute or relative to project root)",
                                    },
                                    "old_string": {
                                        "type": "string",
                                        "description": "Exact string to find (must be unique in file)",
                                    },
                                    "new_string": {
                                        "type": "string",
                                        "description": "Replacement string",
                                    },
                                },
                                "required": ["file_path", "old_string", "new_string"],
                            },
                            "maxItems": 20,
                        },
                    },
                    "required": ["edits"],
                },
            )
        )

    if os.environ.get("TALON_EDIT_BATCH") == "1":
        tools.append(
            Tool(
                name="write_batch",
                description=(
                    "Create multiple new files in a single call. Each entry specifies "
                    "a file_path and content. Use this instead of sequential Write calls "
                    "when creating 2+ new files. Saves one API round-trip per file."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "files": {
                            "description": "List of files to create. Pass as a JSON array.",
                            "items": {
                                "type": "object",
                                "properties": {
                                    "file_path": {
                                        "type": "string",
                                        "description": "File path (absolute or relative to project root)",
                                    },
                                    "content": {
                                        "type": "string",
                                        "description": "Full file content to write",
                                    },
                                },
                                "required": ["file_path", "content"],
                            },
                            "maxItems": 10,
                        },
                    },
                    "required": ["files"],
                },
            )
        )

    if os.environ.get("TALON_VERIFY") == "1":
        tools.append(
            Tool(
                name="talon_verify",
                description=(
                    "Run pytest and return structured pass/fail output — saves 1,000–3,000 tokens vs Bash pytest. "
                    "Prefer this over Bash for all test verification. "
                    "target: test file OR directory (e.g. 't/unit/worker/test_consumer.py' or 't/unit/worker/'). "
                    "detail='summary' → ~15 tok (pass/fail counts only). "
                    "detail='failures' → ~500 tok (tracebacks + source context at error lines, so you can fix without re-reading). "
                    "Running a directory covers the full suite for that package."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "target": {
                            "type": "string",
                            "description": "Test file(s) or directory relative to project root. Comma-separated for multiple targets (e.g. 'tests/test_a.py,tests/test_b.py')",
                        },
                        "scope": {
                            "type": "string",
                            "description": "Run scope: 'file' (default) runs the whole file, 'function' uses -k to match a specific test function name in target",
                            "enum": ["file", "function"],
                        },
                        "detail": {
                            "type": "string",
                            "description": "Detail level: 'summary' (~15 tok, pass/fail counts only), 'failures' (default, ~500 tok, tracebacks + source context at error locations). 'full' is alias for 'failures'.",
                            "enum": ["summary", "failures", "full"],
                        },
                    },
                    "required": ["target"],
                },
            )
        )

    if os.environ.get("TALON_PYTEST") == "1":
        tools.append(
            Tool(
                name="talon_pytest",
                description=(
                    "Run pytest on one or more test files and return a structured summary. "
                    "Equivalent to `Bash(pytest ...)` but returns ~50-300 tokens instead of "
                    "raw terminal output — saving the full context overhead of a Bash turn. "
                    "Pass multiple files as a list. Use `args` for pytest flags (-k, -x, --lf, etc.). "
                    "Extra flags from TALON_PYTEST_ARGS env var are always appended."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "files": {
                            "description": (
                                "Test file paths relative to project root, e.g. "
                                "[\"tests/test_auth.py\", \"tests/test_api.py\"]. "
                                "Up to 10 files per call. Pass as a JSON array."
                            ),
                            "items": {"type": "string"},
                            "maxItems": 10,
                        },
                        "args": {
                            "type": "string",
                            "description": (
                                "Optional extra pytest arguments, e.g. \"-k test_login -x --lf\". "
                                "Applied after the file list."
                            ),
                        },
                    },
                    "required": ["files"],
                },
            )
        )

    # X909: talon_test_for bundled with TALON_VERIFY (no separate gate needed)
    if os.environ.get("TALON_VERIFY") == "1":
        schema = EXPERIMENTAL_TOOL_SCHEMAS["talon_test_for"]
        tools.append(Tool(
            name=schema["name"],
            description=schema["description"],
            inputSchema=schema["inputSchema"],
        ))

    # X907c experimental tools — env-gated, available for autoshot/experiments
    # Track already-registered tool names to avoid duplicates
    _registered_names = {t.name for t in tools}
    for tool_key, env_var in [
        ("talon_grep", "TALON_GREP"),
        ("talon_test_for", "TALON_TEST_FOR"),  # fallback if TALON_VERIFY not set
        ("talon_verify_fix", "TALON_VERIFY_FIX"),
        ("talon_check", "TALON_CHECK"),
        ("talon_diff", "TALON_DIFF"),
        ("talon_deps", "TALON_DEPS"),
    ]:
        if os.environ.get(env_var) == "1":
            schema = EXPERIMENTAL_TOOL_SCHEMAS[tool_key]
            if schema["name"] not in _registered_names:
                tools.append(Tool(
                    name=schema["name"],
                    description=schema["description"],
                    inputSchema=schema["inputSchema"],
                ))
                _registered_names.add(schema["name"])

    # graph_ask_lite: lean semantic symbol search (TALON_GRAPH_ASK_LITE=1) — GA24+
    if os.environ.get("TALON_GRAPH_ASK_LITE") == "1":
        tools.append(
            Tool(
                name="graph_ask_lite",
                description=(
                    "Semantic symbol search for any coding task. "
                    "Returns the top relevant symbol bodies (25 lines each) ready for edit_batch old_string. "
                    "Call this FIRST before any navigation — works for both explicit symbol names and "
                    "concept-level descriptions like 'add gzip compression'. "
                    "Returns: symbol names, file paths, line ranges, and body snippets."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "task": {
                            "type": "string",
                            "description": "Full task description — natural language or with symbol names.",
                        },
                    },
                    "required": ["task"],
                },
            )
        )

    # graph_ask: agent-initiated knowledge retrieval (TALON_GRAPH_ASK=1)
    if os.environ.get("TALON_GRAPH_ASK") == "1":
        tools.append(
            Tool(
                name="graph_ask",
                description=(
                    "Ask the code graph for a structured plan before starting any coding task. "
                    "Returns: task analysis, ordered steps with file paths and symbol bodies, "
                    "callers, known pitfalls, test files, and edit preparation hints. "
                    "Call this FIRST before any Read, Grep, or navigation — it provides "
                    "everything you need to start editing immediately."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "task": {
                            "type": "string",
                            "description": "Natural language description of the coding task you need to accomplish.",
                        },
                        "expected_files": {
                            "description": "Optional list of files you expect to modify (improves accuracy). Pass as a JSON array e.g. [\"file.py\"] or omit entirely.",
                        },
                    },
                    "required": ["task"],
                },
            )
        )

    # graph_discovery: always available — returns capabilities list
    tools.append(
        Tool(
            name="graph_discovery",
            description="Returns a list of all graph capabilities and navigation tools available.",
            inputSchema={"type": "object", "properties": {}, "required": []},
        )
    )

    return tools


def _handle_graph_discovery() -> list[TextContent]:
    """Return a capabilities list of all graph tools."""
    text = """\
Graph Capabilities:
  graph_query(intent, target, depth, hops)
    toc      — File/directory table of contents
    locate   — Find symbol by name (fuzzy search)
    callers  — Who calls this function (hops=2-5 for chains)
    flow     — What this function calls (hops=2-5 for pipelines)
    blast    — Blast radius — what breaks if this changes
    coverage — Test coverage for a function
    scope    — Multi-file context from task description
    cg       — Concept graph — problem-space memory
  depth: shallow (~80 tok) | standard (~300 tok) | full (~800 tok) | edit
  hops: 1-5 (callers/flow only)

Tools:
  smart_read(file, symbol)          — read function body (~200 tok)
  smart_read_batch(targets=[...])   — batch reads (up to 20, batch ALL into ONE call)
  smart_edit(file, symbol)          — function body + Edit hint
  edit_batch(edits=[...])           — batch edits (up to 20)
  write_batch(files=[...])          — batch new file creation (up to 10)
  talon_verify(target, detail)       — structured test runner"""
    return [TextContent(type="text", text=text)]




def _expand_callees_into_result(result: Any, project_id: str, graph: Any, memory: Any, max_body: int = 60) -> None:
    """1-hop callee expansion: for each located symbol, add callees from same project.

    Queries talon_calls edges outbound from each symbol's graph key and appends
    any callee not already in result.located. Helps when the task involves a
    dispatcher/event system where both the event definition and the dispatch site
    are needed (e.g. before_cursor_execute event + do_executemany in base.py).
    """
    if not hasattr(graph, "db"):
        return

    try:
        from talon.ab.preinject import LocatedSymbol
    except ImportError:
        return

    seen_positions: set[tuple[str, int]] = {
        (s.file_path, s.line_start) for s in result.located if hasattr(s, "file_path")
    }

    new_syms: list[Any] = []
    for sym in list(result.located):
        if not hasattr(sym, "name") or not sym.name:
            continue
        try:
            # Find callee function nodes reachable via talon_calls from this symbol
            aql = """
            FOR f IN talon_functions
                FILTER CONTAINS(LOWER(f.name), LOWER(@name))
                FILTER f.project_id == @pid OR @pid == "" OR f.project_id == null
                LIMIT 3
                FOR callee, e IN 1..1 OUTBOUND f talon_calls
                    FILTER callee.project_id == @pid OR @pid == "" OR callee.project_id == null
                    LIMIT 5
                    RETURN DISTINCT {name: callee.name, module: callee.module,
                                     line_start: callee.line_start, line_end: callee.line_end,
                                     class_name: callee.class_name}
            """
            rows = list(graph.db.aql.execute(aql, bind_vars={"name": sym.name, "pid": project_id or ""}))
        except Exception:
            continue

        for row in rows:
            fp = row.get("module", "")
            ln = row.get("line_start", 0)
            if not fp or not ln or (fp, ln) in seen_positions:
                continue
            seen_positions.add((fp, ln))

            body_end = row.get("line_end", ln + max_body)
            body_end = min(body_end, ln + max_body - 1)
            body_lines = memory.get_lines(fp, ln, body_end) if hasattr(memory, "get_lines") else []
            body_text = "".join(body_lines) if body_lines else ""

            ls = LocatedSymbol(
                name=row.get("name", ""),
                file_path=fp,
                line_start=ln,
                line_end=row.get("line_end", ln),
                body=body_text,
                confidence=0.5,
                source="callee_expand",
            )
            new_syms.append(ls)

    result.located.extend(new_syms)

async def _handle_graph_ask(arguments: dict[str, Any], start: float) -> list[TextContent]:
    """Handle graph_ask: agent-initiated knowledge retrieval.

    Runs the preinject pipeline (classify → navigate → compose) on demand,
    returning a structured plan the agent can follow immediately.
    """
    task_desc = arguments.get("task", "")
    expected_files = arguments.get("expected_files") or []

    # Coerce expected_files: agent sometimes passes a JSON-encoded string instead of array
    if isinstance(expected_files, str):
        import json as _json
        try:
            expected_files = _json.loads(expected_files)
        except Exception:
            expected_files = [expected_files] if expected_files else []

    if not task_desc:
        return [TextContent(type="text", text="Missing required parameter: task")]

    # Auto-extract file paths from task description if agent didn't provide expected_files
    if not expected_files:
        import re as _re
        # Match any relative path with a file extension (e.g. "celery/app/defaults.py")
        _path_re = _re.findall(r'(?:[\w][\w/.-]+/[\w/.-]+\.(?:py|ts|js|go|rs|java))', task_desc)
        if _path_re:
            expected_files = list(dict.fromkeys(_path_re))  # deduplicate, preserve order

    try:
        from talon.ab.preinject import (
            MemoryStore as PreinjectMemoryStore,
            classify_task,
            compose_output,
            navigate,
            navigate_confidence,
            _connect_graph_or_stub,
        )
        from talon.ab.models import ABTask

        # Build a synthetic ABTask from the agent's question
        synthetic_task = ABTask(
            task_id="graph_ask_live",
            project=_project_id,
            project_path=_project_path,
            description=task_desc,
            expected_files=expected_files,
            task_type="write",
        )

        # Use existing memory store if available, else build fresh
        workspace = Path(_project_path)
        if _memory_store and _memory_store.file_count > 0:
            memory = _memory_store
        else:
            memory = PreinjectMemoryStore()
            memory.build(workspace)

        graph = _connect_graph_or_stub()

        # Phase 1: Classify
        profile = classify_task(synthetic_task)

        # Skip graph_ask for simple tasks — overhead exceeds savings.
        # len <= 1: covers both explicit 1-file AND description-inferred simple (0 files).
        if profile.complexity == "simple" and len(expected_files) <= 1:
            latency_ms = (time.monotonic() - start) * 1000
            short = f"Single-file simple task — use Read directly.\n  file: {expected_files[0] if expected_files else '(unknown)'}"
            if profile.symbols:
                short += f"\n  symbols: {', '.join(profile.symbols[:8])}"
            short += f"\n[graph_ask: skipped (simple single-file), {latency_ms:.0f}ms]"
            return [TextContent(type="text", text=short)]

        # graph_ask gets fuller bodies than preinject — agent needs complete old_string for Edit
        _ga_body = int(os.environ.get("TALON_GA_BODY_PRIMARY", "80"))

        # Phase 2: Navigate (graph_ask gets fuller bodies via max_body).
        # allow_file_discovery=True: enables semantic fallback + outside-file promotion
        # for graph_ask, where agent-provided expected_files may be incomplete.
        result = navigate(profile, synthetic_task, workspace, memory, graph,
                          max_body=_ga_body, allow_file_discovery=True)

        # 1-hop callee expansion: add callees of located symbols (TALON_GA_CALLEE_EXPAND=1)
        if os.environ.get("TALON_GA_CALLEE_EXPAND") == "1":
            _expand_callees_into_result(result, _project_id, graph, memory, max_body=_ga_body)

        # Fix 1: resolve graph paths against workspace filesystem.
        # Graph index may store paths without a leading 'src/' prefix (e.g.
        # 'airflow/models/dagrun.py') while the workspace has
        # 'src/airflow/models/dagrun.py'. Resolve each before scoring so that
        # sm_batch can actually read the files, and boost confidence proportionally.
        _resolved_count = 0
        _resolved_files: list[str] = []
        for _fp in result.target_files:
            _alt = _resolve_path_suffix_match(workspace, _fp)
            if _alt and _alt != _fp:
                _resolved_files.append(_alt)
                _resolved_count += 1
            else:
                _resolved_files.append(_fp)
        if _resolved_count:
            result.target_files = _resolved_files
        # Also resolve paths in located symbols
        for _sym in result.located:
            if hasattr(_sym, "file_path") and _sym.file_path:
                _alt = _resolve_path_suffix_match(workspace, _sym.file_path)
                if _alt and _alt != _sym.file_path:
                    _sym.file_path = _alt

        # Phase 3: Confidence scoring
        confidence = navigate_confidence(profile, result)
        # Boost confidence when paths were resolved — file existence confirmed
        if _resolved_count and result.target_files:
            _boost = min(0.3, 0.1 * _resolved_count)
            confidence = min(1.0, confidence + _boost)

        # Phase 4: Compose (same format as preinject, but enhanced header)
        _ga_stratum = {"body_primary": _ga_body, "body_secondary": max(_ga_body - 10, 12), "max_syms": int(os.environ.get("TALON_GA_MAX_SYMS", "12"))}
        scope_output = compose_output(profile, result, synthetic_task, memory, stratum_config=_ga_stratum)

        # Build enhanced response with graph_ask framing
        lines = []
        lines.append("# Graph-Ask Plan")
        lines.append(f"confidence: {confidence:.2f}")
        lines.append("")

        # Fix: hoist edit_prep + callers/flow_chain to top — agent reads top-down.
        # By the time it reaches these sections at the bottom of scope_output (after
        # 8K+ of symbol bodies), the call chain data has scrolled out of working focus.
        # Moving them here ensures the agent sees navigation hints BEFORE symbol bodies.
        import re as _re
        _hoisted: list[str] = []
        _scope_remainder = scope_output

        # Extract and hoist: config_section first (before symbols), then edit_prep, callers, flow_chain.
        # config_section must come early — 12 symbol bodies at 80 lines each easily push it past
        # the TALON_SCOPE_CAP=8000 cutoff, causing agents to search for config keys with graph_query.
        for _section in ("config_section", "edit_prep", "callers", "flow_chain"):
            _pat = _re.compile(
                rf"^({_section}:.*?)(?=^\w|\Z)", _re.MULTILINE | _re.DOTALL
            )
            _m = _pat.search(_scope_remainder)
            if _m:
                _hoisted.append(_m.group(0).rstrip())
                _scope_remainder = _scope_remainder[: _m.start()] + _scope_remainder[_m.end() :]

        if _hoisted:
            for _h in _hoisted:
                lines.append(_h)
                lines.append("")

        # Add the remaining preinject output (task_analysis, files, symbols, config)
        lines.append(_scope_remainder)

        # Add pitfalls section from graph knowledge
        pitfalls = _extract_pitfalls(result, memory, workspace)
        if pitfalls:
            lines.append("")
            lines.append("pitfalls:")
            for p in pitfalls:
                lines.append(f"  - {p}")

        # Add verification guidance
        if result.test_file:
            lines.append("")
            lines.append(f"verification:")
            lines.append(f"  test_file: {result.test_file}")
            lines.append(f"  command: pytest {result.test_file} -x -q")

        # Confidence-based guidance
        lines.append("")
        if confidence >= 0.7:
            lines.append("guidance: High confidence — follow the plan above. Use the symbol bodies for edit_batch old_string matching. Do NOT re-read files already shown.")
        elif confidence >= 0.4:
            lines.append("guidance: Medium confidence — plan covers most targets. You may need 1-2 additional reads for symbols not found above.")
        else:
            lines.append("guidance: Low confidence — plan is incomplete. Use file paths above as starting points, then use smart_read_batch to explore further.")

        response = "\n".join(lines)

        # Cap response
        scope_cap = int(os.environ.get("TALON_SCOPE_CAP", "8000"))
        if scope_cap and len(response) > scope_cap:
            response = response[:scope_cap] + "\n\n[... truncated to " + str(scope_cap) + " chars]"

        latency_ms = (time.monotonic() - start) * 1000
        response += f"\n[graph_ask: {len(response)} chars, confidence={confidence:.2f}, {latency_ms:.0f}ms]"

        logger.info(
            "graph_ask: %d chars, confidence=%.2f, %d files, %d symbols, %.0fms",
            len(response), confidence, len(result.target_files),
            len(result.located), latency_ms,
        )

        return [TextContent(type="text", text=response)]

    except Exception as exc:
        import traceback
        logger.error("graph_ask failed: %s", exc)
        traceback.print_exc()
        return [TextContent(type="text", text=f"graph_ask error: {exc}. Fall back to manual navigation.")]


async def _handle_graph_ask_lite(arguments: dict[str, Any], start: float) -> list[TextContent]:
    """Handle graph_ask_lite: lean semantic symbol search for GA24+.

    Like graph_ask but:
    - max_body=25 lines (not 80) — enough for old_string, not file-sized
    - Concept-level fallback: _extract_semantic_terms + AQL when classify finds nothing
    - Cap at 3000 chars (not 8000)
    - No pitfalls / edit_prep hoisting / verification sections
    """
    task_desc = arguments.get("task", "")
    if not task_desc:
        return [TextContent(type="text", text="Missing required parameter: task")]

    try:
        from talon.ab.preinject import (
            MemoryStore as PreinjectMemoryStore,
            classify_task,
            compose_output,
            navigate,
            _connect_graph_or_stub,
            _extract_semantic_terms,
            _aql_locate_supplement,
        )
        from talon.ab.models import ABTask

        synthetic_task = ABTask(
            task_id="graph_ask_lite_live",
            project=_project_id,
            project_path=_project_path,
            description=task_desc,
            expected_files=[],
            task_type="write",
        )

        workspace = Path(_project_path)
        if _memory_store and _memory_store.file_count > 0:
            memory = _memory_store
        else:
            memory = PreinjectMemoryStore()
            memory.build(workspace)

        graph = _connect_graph_or_stub()

        # Classify (extracts CamelCase/snake_case symbols)
        profile = classify_task(synthetic_task)

        # Navigate with 60-line bodies; allow_file_discovery promotes outside-file symbols
        result = navigate(profile, synthetic_task, workspace, memory, graph,
                          max_body=60, allow_file_discovery=True)

        # Concept-level fallback: semantic terms + AQL when classify found nothing
        if not result.located and not result.target_files:
            terms = _extract_semantic_terms(task_desc, memory)
            if terms and hasattr(graph, "db"):
                aql_syms = _aql_locate_supplement(
                    terms, [],
                    synthetic_task.project, graph, memory,
                    max_body=60, exclude_positions=set(),
                )
                if aql_syms:
                    result.located.extend(aql_syms)

        if not result.located and not result.target_files:
            latency_ms = (time.monotonic() - start) * 1000
            return [TextContent(type="text", text=(
                f"graph_ask_lite: no symbols found — use graph_query(intent='locate') to search manually.\n"
                f"[graph_ask_lite: 0 chars, {latency_ms:.0f}ms]"
            ))]

        # Path resolution (workspace prefix matching)
        for sym in result.located:
            if hasattr(sym, "file_path") and sym.file_path:
                alt = _resolve_path_suffix_match(workspace, sym.file_path)
                if alt and alt != sym.file_path:
                    sym.file_path = alt

        # Body size: TALON_GA_LITE_BODY controls primary body lines (default 60).
        # Max syms: dynamic by default — scales with file diversity in the result.
        # TALON_GA_LITE_MAX_SYMS overrides the minimum (default 8).
        # Cap scales proportionally: 100 chars/line * body_primary * max_syms.
        _lite_body = int(os.environ.get("TALON_GA_LITE_BODY", "60"))
        _env_max_syms = int(os.environ.get("TALON_GA_LITE_MAX_SYMS", "8"))

        # 1-hop callee expansion: add callees of located symbols (TALON_GA_CALLEE_EXPAND=1)
        if os.environ.get("TALON_GA_CALLEE_EXPAND") == "1":
            _expand_callees_into_result(result, _project_id, graph, memory, max_body=_lite_body)

        # Dynamic max_syms + body size: both scale with file diversity in the result.
        # Cross-cutting tasks span 4+ files → need more symbols AND fuller bodies.
        # Simple tasks (1-3 files) → fewer symbols, shorter bodies → less context inflation.
        _unique_result_files = len({
            getattr(s, "file_path", None) for s in result.located
            if getattr(s, "file_path", None)
        })
        _is_complex = _unique_result_files >= 4
        _lite_max_syms = max(_env_max_syms, 12) if _is_complex else _env_max_syms
        # Render body: complex tasks get full _lite_body lines; simple tasks get 60 lines max.
        # navigate() already fetched up to _lite_body lines — we just render fewer for simple tasks.
        _render_body = _lite_body if _is_complex else min(_lite_body, 60)

        # Compose output — body size and symbol count both scaled by complexity
        _lite_stratum = {"body_primary": _render_body, "body_secondary": max(_render_body // 2, 15), "max_syms": _lite_max_syms}
        scope_output = compose_output(profile, result, synthetic_task, memory, stratum_config=_lite_stratum)

        # Hoist edit_prep + callers/flow_chain to top — agent reads top-down.
        # Without hoisting, callers and edit_prep get buried after 4K+ of symbol bodies,
        # causing agents to Bash-discover test files instead of using pre-computed data.
        import re as _re
        _hoisted_sections: list[str] = []
        _scope_remainder = scope_output
        for _section in ("edit_prep", "callers", "flow_chain"):
            _pat = _re.compile(
                rf"^({_section}:.*?)(?=^\w|\Z)", _re.MULTILINE | _re.DOTALL
            )
            _m = _pat.search(_scope_remainder)
            if _m:
                _hoisted_sections.append(_m.group(0).rstrip())
                _scope_remainder = _scope_remainder[: _m.start()] + _scope_remainder[_m.end() :]
        if _hoisted_sections:
            scope_output = "\n\n".join(_hoisted_sections) + "\n\n" + _scope_remainder

        cap = 100 * _render_body * _lite_max_syms  # ~100 chars/line * body_primary * max_syms
        if len(scope_output) > cap:
            scope_output = scope_output[:cap] + "\n[... truncated]"

        latency_ms = (time.monotonic() - start) * 1000
        scope_output += f"\n[graph_ask_lite: {len(scope_output)} chars, {latency_ms:.0f}ms]"

        logger.info(
            "graph_ask_lite: %d chars, %d symbols, %.0fms",
            len(scope_output), len(result.located), latency_ms,
        )

        return [TextContent(type="text", text=scope_output)]

    except Exception as exc:
        import traceback
        logger.error("graph_ask_lite failed: %s", exc)
        traceback.print_exc()
        return [TextContent(type="text", text=f"graph_ask_lite error: {exc}. Use graph_query(intent='locate') instead.")]


def _extract_pitfalls(result: Any, memory: Any, workspace: Path) -> list[str]:
    """Extract known pitfalls from navigation results and codebase analysis."""
    pitfalls = []

    # Circular import detection: check if target files import each other
    if len(result.target_files) >= 2:
        for i, f1 in enumerate(result.target_files[:4]):
            f1_lines = memory.get_lines(f1, 1, 30)
            if not f1_lines:
                continue
            f1_imports = " ".join(f1_lines).lower()
            for f2 in result.target_files[i + 1:4]:
                # Check if f1 imports from f2's module
                f2_module = Path(f2).stem
                if f2_module in f1_imports and "import" in f1_imports:
                    pitfalls.append(
                        f"Potential circular import: {f1} imports from {f2_module} — "
                        f"avoid adding new top-level imports between these files"
                    )

    # Large file warning
    for fp in result.target_files[:4]:
        loc = memory.get_file_loc(fp)
        if loc and loc > 800:
            pitfalls.append(
                f"{fp} is {loc} LOC — use smart_read_batch with line ranges, "
                f"do not Read the full file"
            )

    # Missing files need creation
    if result.missing_files:
        for mf in result.missing_files:
            pitfalls.append(f"{mf.file_path} does not exist — CREATE NEW FILE")

    # Already-fixed detection
    if result.already_fixed:
        pitfalls.append(
            f"Bug may already be fixed: {result.already_fixed_evidence}. "
            f"Verify before making changes."
        )

    return pitfalls[:5]  # Cap at 5 pitfalls


@app.call_tool()
async def call_tool(name: str, arguments: dict[str, Any]) -> list[TextContent]:
    """Handle graph_query and smart_read tool calls."""
    global _nav_consecutive
    start = time.monotonic()

    if name == "graph_discovery":
        return _handle_graph_discovery()

    if name == "graph_ask_lite":
        return await _handle_graph_ask_lite(arguments, start)

    if name == "graph_ask":
        return await _handle_graph_ask(arguments, start)

    if name == "smart_read":
        return await _handle_smart_read(arguments, start)

    if name == "smart_edit":
        return await _handle_smart_edit(arguments, start)

    if name == "smart_read_batch":
        # Navigation budget gate: check before executing
        if _nav_budget_cap and _nav_consecutive >= _nav_budget_cap:
            return [TextContent(type="text", text=(
                f"[nav-budget] {_nav_consecutive} consecutive navigation calls — "
                f"budget of {_nav_budget_cap} reached.  Start editing now.  "
                "Counter resets after edit_batch or write_batch."
            ))]
        _nav_consecutive += 1
        return await _handle_smart_read_batch(arguments, start)

    if name == "edit_batch":
        _nav_consecutive = 0  # reset nav budget on any edit action
        return await _handle_edit_batch(arguments, start)

    if name == "write_batch":
        _nav_consecutive = 0  # reset nav budget on write action
        return await _handle_write_batch(arguments, start)

    if name == "talon_verify":
        return await _handle_verify(arguments, start)

    if name == "talon_pytest":
        return await _handle_talon_pytest(arguments, start)

    # X907c experimental tools
    _experimental_dispatch = {
        "talon_grep": _handle_talon_grep,
        "talon_test_for": _handle_talon_test_for,
        "talon_verify_fix": _handle_talon_verify_fix,
        "talon_check": _handle_talon_check,
        "talon_diff": _handle_talon_diff,
        "talon_deps": _handle_talon_deps,
    }
    if name in _experimental_dispatch:
        return await _experimental_dispatch[name](arguments, start)

    if name != "graph_query":
        return [TextContent(type="text", text=f"Unknown tool: {name}.")]

    intent = arguments.get("intent", "")
    target = arguments.get("target", "")
    depth = arguments.get("depth", "shallow")
    hops = arguments.get("hops")

    if not intent or not target:
        return [TextContent(type="text", text="Missing required parameters: intent and target.")]

    # Navigation budget gate: count graph_query as navigation
    if _nav_budget_cap and intent not in ("sync", "cg", "cg_update"):
        if _nav_consecutive >= _nav_budget_cap:
            return [TextContent(type="text", text=(
                f"[nav-budget] {_nav_consecutive} consecutive navigation calls — "
                f"budget of {_nav_budget_cap} reached.  Start editing now.  "
                "Counter resets after edit_batch or write_batch."
            ))]
        _nav_consecutive += 1

    # Route to handler
    result = await route_intent(
        intent=intent,
        target=target,
        depth=depth,
        project_id=_project_id,
        graph=_graph_client,
        memory=_memory_store,
        hops=hops,
    )

    response_text = result["response"]

    # Scope cap: truncate scope responses if TALON_SCOPE_CAP is set
    scope_cap = int(os.environ.get("TALON_SCOPE_CAP", 0))
    if scope_cap and intent == "scope" and len(response_text) > scope_cap:
        response_text = response_text[:scope_cap] + "\n\n[... truncated to " + str(scope_cap) + " chars]"

    # Precision tracking: extract served files/symbols from scope TALON_META
    if _pt_enabled and intent == "scope":
        _pt_extract_scope_meta(result["response"])

    # Add token count footer
    tokens_est = result["tokens_est"]
    response_text += f"\n[~{tokens_est} tokens]"

    # Fire-and-forget telemetry
    if _telemetry:
        metric = ToolCallMetric(
            intent=intent,
            target=target,
            depth=depth,
            response_tokens=tokens_est,
            latency_ms=result["latency_ms"],
            cache_hit=result["cache_hit"],
            warnings_count=result["warnings_count"],
            layers_used=result["layers_used"],
        )
        _telemetry.log(metric)

    return [TextContent(type="text", text=response_text)]


# ---------------------------------------------------------------------------
# Precision tracking helpers (TALON_PRECISION_TRACKING=1)
# ---------------------------------------------------------------------------


def _pt_extract_scope_meta(response_text: str) -> None:
    """Extract served files/symbols from TALON_META in a scope response."""
    global _pt_scope_calls
    import json as _json

    m = re.search(r"<!-- TALON_META:(\{.*?\}) -->", response_text)
    if not m:
        return

    try:
        meta = _json.loads(m.group(1))
    except Exception:
        return

    _pt_scope_calls += 1

    for f in meta.get("served_files", []):
        _pt_served_files.add(f)

    for file_path, sr in meta.get("shadow_reads", {}).items():
        sym = sr.get("symbol", "")
        if sym:
            _pt_served_symbols[sym] = file_path


def _pt_on_edit_batch(edited_files: set[str]) -> str | None:
    """Compare edited files against scope-served files. Returns log line or None."""
    global _pt_edits_in_scope, _pt_edits_total

    if not _pt_served_files or not edited_files:
        return None

    _pt_edits_total += len(edited_files)

    # Normalise: compare basenames when full paths differ
    served_basenames = {os.path.basename(f) for f in _pt_served_files}
    in_scope = 0
    for ef in edited_files:
        ef_base = os.path.basename(ef)
        if ef in _pt_served_files or ef_base in served_basenames:
            in_scope += 1

    _pt_edits_in_scope += in_scope

    # File precision: how many scope files were actually edited
    file_precision = in_scope / len(_pt_served_files) if _pt_served_files else 0.0
    # File coverage: how many edited files were in scope
    file_coverage = in_scope / len(edited_files) if edited_files else 0.0

    msg = (
        f"[precision] scope={len(_pt_served_files)} files, "
        f"{len(_pt_served_symbols)} symbols | "
        f"edit hit {in_scope}/{len(edited_files)} in-scope | "
        f"precision={file_precision:.2f} coverage={file_coverage:.2f} | "
        f"session: {_pt_edits_in_scope}/{_pt_edits_total} cumulative"
    )
    logger.info(msg)
    return msg


# ---------------------------------------------------------------------------
# smart_read handler (Path L — targeted function reads)
# ---------------------------------------------------------------------------


async def _handle_smart_read(
    arguments: dict[str, Any], start: float
) -> list[TextContent]:
    """Read a specific function/class body from a source file.

    Uses MemoryStore's locate_symbol + get_lines to return only the targeted
    symbol's source code, avoiding the cost of reading the entire file.
    """
    file_path = arguments.get("file", "")
    symbol = arguments.get("symbol", "")
    context_lines = min(max(int(arguments.get("context", 0)), 0), 20)

    if not file_path or not symbol:
        return [TextContent(type="text", text="Missing required parameters: file and symbol.")]

    if not _memory_store:
        return [TextContent(type="text", text="Memory store not initialized.")]

    # Find the symbol in the file
    locations = _memory_store.locate_symbol(symbol)
    match = None
    for loc_file, loc_line in locations:
        if loc_file == file_path or loc_file.endswith(file_path) or file_path.endswith(loc_file):
            match = (loc_file, loc_line)
            break

    if not match:
        # Try fuzzy match
        fuzzy = _memory_store.locate_symbol_fuzzy(symbol, max_results=5)
        candidates = [
            (f, l) for f, l, _ in fuzzy
            if f == file_path or f.endswith(file_path) or file_path.endswith(f)
        ]
        if candidates:
            match = candidates[0]

    if not match:
        return [TextContent(
            type="text",
            text=f"Symbol '{symbol}' not found in '{file_path}'. "
            f"Use graph_query(intent='locate', target='{symbol}') to find it.",
        )]

    resolved_file, line = match

    # Get the symbol's line range
    sym_info = _memory_store.get_symbol_at(resolved_file, line)
    if not sym_info:
        return [TextContent(
            type="text",
            text=f"Symbol '{symbol}' found at {resolved_file}:{line} but no range info available.",
        )]

    line_start = sym_info.get("line_start", line)
    line_end = sym_info.get("line_end", line + 20)

    # Expand range with context lines if requested
    ctx_tag = ""
    if context_lines > 0:
        line_start = max(1, line_start - context_lines)
        line_end = line_end + context_lines
        ctx_tag = f" [+{context_lines} context]"

    # Fetch the source lines (use disk for context since cache may not have surrounding lines)
    if context_lines > 0:
        project = Path(_project_path) if _project_path else Path.cwd()
        src_lines = _read_file_lines(project, resolved_file, line_start, line_end)
    else:
        src_lines = _memory_store.get_lines(resolved_file, line_start, line_end)
    if not src_lines:
        return [TextContent(
            type="text",
            text=f"Symbol '{symbol}' at {resolved_file}:{line_start}-{line_end} — no cached source.",
        )]

    # Format response
    header = f"{resolved_file}:{line_start}-{line_end} ({sym_info.get('name', symbol)}){ctx_tag}"
    numbered = [f"{line_start + i}│{sl.rstrip()}" for i, sl in enumerate(src_lines)]
    body = "\n".join(numbered)
    tokens_est = len(body) // 4

    latency_ms = (time.monotonic() - start) * 1000

    # Log telemetry
    if _telemetry:
        metric = ToolCallMetric(
            intent="smart_read",
            target=f"{file_path}::{symbol}",
            depth="full",
            response_tokens=tokens_est,
            latency_ms=latency_ms,
            cache_hit=True,
            warnings_count=0,
            layers_used=["L1"],
        )
        _telemetry.log(metric)

    return [TextContent(type="text", text=f"{header}\n{body}\n[~{tokens_est} tokens]")]


# ---------------------------------------------------------------------------
# smart_edit handler (X7 — Edit-prep with hint line)
# ---------------------------------------------------------------------------


async def _handle_smart_edit(
    arguments: dict[str, Any], start: float
) -> list[TextContent]:
    """Return function body + Edit hint for old_string matching.

    Reuses smart_read internals but appends an Edit template hint showing
    the def/class line as old_string for direct Edit tool usage.
    """
    file_path = arguments.get("file", "")
    symbol = arguments.get("symbol", "")

    if not file_path or not symbol:
        return [TextContent(type="text", text="Missing required parameters: file and symbol.")]

    if not _memory_store:
        return [TextContent(type="text", text="Memory store not initialized.")]

    # Find the symbol
    locations = _memory_store.locate_symbol(symbol)
    match = None
    for loc_file, loc_line in locations:
        if loc_file == file_path or loc_file.endswith(file_path) or file_path.endswith(loc_file):
            match = (loc_file, loc_line)
            break

    if not match:
        fuzzy = _memory_store.locate_symbol_fuzzy(symbol, max_results=5)
        candidates = [
            (f, l) for f, l, _ in fuzzy
            if f == file_path or f.endswith(file_path) or file_path.endswith(f)
        ]
        if candidates:
            match = candidates[0]

    if not match:
        return [TextContent(
            type="text",
            text=f"Symbol '{symbol}' not found in '{file_path}'. "
            f"Use graph_query(intent='locate', target='{symbol}') to find it.",
        )]

    resolved_file, line = match
    sym_info = _memory_store.get_symbol_at(resolved_file, line)
    if not sym_info:
        return [TextContent(
            type="text",
            text=f"Symbol '{symbol}' found at {resolved_file}:{line} but no range info available.",
        )]

    line_start = sym_info.get("line_start", line)
    line_end = sym_info.get("line_end", line + 20)

    src_lines = _memory_store.get_lines(resolved_file, line_start, line_end)
    if not src_lines:
        return [TextContent(
            type="text",
            text=f"Symbol '{symbol}' at {resolved_file}:{line_start}-{line_end} — no cached source.",
        )]

    # Format response with numbered lines
    header = f"{resolved_file}:{line_start}-{line_end} ({sym_info.get('name', symbol)})"
    numbered = [f"{line_start + i}│{sl.rstrip()}" for i, sl in enumerate(src_lines)]
    body = "\n".join(numbered)

    # Build Edit hint from the def/class line
    def_line = src_lines[0].rstrip() if src_lines else ""
    hint = f'\nEdit hint → old_string: "{def_line}"'

    tokens_est = len(body) // 4
    latency_ms = (time.monotonic() - start) * 1000

    if _telemetry:
        metric = ToolCallMetric(
            intent="smart_edit",
            target=f"{file_path}::{symbol}",
            depth="full",
            response_tokens=tokens_est,
            latency_ms=latency_ms,
            cache_hit=True,
            warnings_count=0,
            layers_used=["L1"],
        )
        _telemetry.log(metric)

    return [TextContent(type="text", text=f"{header}\n{body}{hint}\n[~{tokens_est} tokens]")]


# ---------------------------------------------------------------------------
# smart_read_batch handler (X7 — multi-symbol read in one call)
# ---------------------------------------------------------------------------

# Fix 10: Track files that have had module context (imports) served this session
_module_context_served: set[str] = set()


def _get_edited_files() -> set[str]:
    """Read edited_files from enforce_state.json (written by talon-enforce hook)."""
    try:
        state_path = Path(_project_path) / ".claude/state/enforce_state.json"
        if state_path.exists():
            state = json.loads(state_path.read_text())
            return set(state.get("edited_files", []))
    except Exception:
        pass
    return set()


def _build_file_toc(project: Path, file_path: str) -> str:
    """Build a compact TOC block for a file edited this session.

    Appended to line-range reads so the agent knows the file's total length
    and symbol structure without additional scroll-scan reads.

    Returns empty string if no useful info can be gathered.
    """
    # Resolve absolute path
    abs_path = project / file_path
    if not abs_path.exists():
        # Try matching by filename anywhere under project
        name = Path(file_path).name
        for candidate in project.rglob(name):
            abs_path = candidate
            break

    total_lines = 0
    if abs_path.exists():
        try:
            with abs_path.open() as f:
                total_lines = sum(1 for _ in f)
        except Exception:
            pass

    sym_lines: list[str] = []
    if _memory_store:
        file_syms = _memory_store.get_file_symbols(file_path)
        if file_syms:
            for s in file_syms[:40]:
                sym_lines.append(f"  {s['name']}  {s['line_start']}-{s['line_end']}")

    if not sym_lines and not total_lines:
        return ""

    header = f"--- {file_path} [file-toc — edited this session"
    if total_lines:
        header += f", {total_lines} lines total]"
    else:
        header += "]"

    parts: list[str] = []
    if total_lines:
        parts.append(f"FILE LENGTH: {total_lines} lines")
    if sym_lines:
        parts.append("\n".join(sym_lines))
    return header + "\n" + "\n".join(parts)


async def _handle_smart_read_batch(
    arguments: dict[str, Any], start: float
) -> list[TextContent]:
    """Read multiple function/class bodies or line ranges in a single call.

    Three modes per target:
    - {file, symbol}: symbol lookup via MemoryStore
    - {file, lines: "100-150"}: line-range read from disk
    - {file, symbol, lines: "±10"}: symbol body with padding
    """
    targets = arguments.get("targets", [])
    if isinstance(targets, str):
        import json as _json
        try: targets = _json.loads(targets)
        except Exception: targets = []
    if not targets:
        return [TextContent(type="text", text="Missing required parameter: targets (list of {file, symbol/lines}).")]

    if not _memory_store:
        return [TextContent(type="text", text="Memory store not initialized.")]

    project = Path(_project_path) if _project_path else Path.cwd()
    results: list[str] = []
    total_tokens = 0
    # Track resolved symbols for read-ahead dedup
    resolved_symbols: set[str] = set()
    # Collect source lines per file for read-ahead extraction
    file_source_lines: dict[str, list[str]] = {}
    # Fix 10: Track which files have had module context served
    module_ctx = os.environ.get("TALON_MODULE_CONTEXT", "0") == "1"
    # Fix 13: Edit-ready output
    edit_ready = os.environ.get("TALON_EDIT_READY", "0") == "1"
    # Fix 14: Edited-file TOC — append symbol list + LOC to line-range reads of edited files
    edited_file_toc = os.environ.get("TALON_EDITED_FILE_TOC", "0") == "1"
    edited_files: set[str] = _get_edited_files() if edited_file_toc else set()
    _toc_injected_files: set[str] = set()  # Per-batch dedup

    # ── Read-ahead monitor: check hits from previous predictions ─────
    monitor_enabled = os.environ.get("TALON_READAHEAD_MONITOR", "0") == "1"
    readahead_on = os.environ.get("TALON_READAHEAD", "0") == "1"
    ra_hits = 0
    global _ra_monitor_call
    if monitor_enabled or readahead_on:
        _ra_monitor_call += 1
    if monitor_enabled:
        _ra_monitor_init()
        # Collect requested symbols from this call
        requested_syms = {t.get("symbol", "") for t in targets if t.get("symbol")}
        ra_hits = _ra_monitor_check_hits(requested_syms)

    for t in targets[:20]:  # Cap at 20 per batch
        file_path = t.get("file", "")
        symbol = t.get("symbol", "")
        lines_spec = t.get("lines", "")

        if not file_path:
            results.append("--- SKIPPED (missing file)")
            continue

        # Fix 10: Module context — prepend imports on first file access
        if module_ctx and file_path not in _module_context_served:
            _module_context_served.add(file_path)
            all_lines = _memory_store.get_lines(file_path, 1, 50) if _memory_store else None
            if all_lines:
                import_end = 0
                in_docstring = False
                for i, ln in enumerate(all_lines):
                    s = ln.strip()
                    if s.startswith(('"""', "'''")):
                        in_docstring = not in_docstring
                        continue
                    if in_docstring or not s or s.startswith("#"):
                        continue
                    if s.startswith(("import ", "from ")):
                        import_end = i + 1
                        continue
                    # First non-import, non-blank, non-comment line
                    if import_end == 0:
                        import_end = i
                    break
                if import_end > 0 and import_end <= 50:  # Sanity cap
                    ctx_header = f"--- {file_path} imports (1-{import_end}) [module-context]"
                    ctx_numbered = [f"{j+1}│{all_lines[j].rstrip()}" for j in range(import_end)]
                    ctx_body = "\n".join(ctx_numbered)
                    total_tokens += len(ctx_body) // 4
                    results.append(f"{ctx_header}\n{ctx_body}")

        # Mode 1: Pure line-range read (no symbol)
        if lines_spec and not symbol:
            lr = _parse_line_range(lines_spec)
            if lr is None:
                results.append(f"--- {file_path} — invalid line range: {lines_spec}")
                continue
            range_start, range_end = lr
            src_lines = _read_file_lines(project, file_path, range_start, range_end)
            if not src_lines:
                # Fix 2: suffix-match fallback — graph paths may omit leading 'src/'
                resolved_fp = _resolve_path_suffix_match(project, file_path)
                if resolved_fp and resolved_fp != file_path:
                    src_lines = _read_file_lines(project, resolved_fp, range_start, range_end)
                    if src_lines:
                        file_path = resolved_fp  # use resolved path for header + TOC check
            if not src_lines:
                results.append(f"--- {file_path}:{range_start}-{range_end} — no source (file not found or empty range)")
                continue
            header = f"--- {file_path}:{range_start}-{range_end}"
            numbered = [f"{range_start + i}│{sl.rstrip()}" for i, sl in enumerate(src_lines)]
            body = "\n".join(numbered)
            total_tokens += len(body) // 4
            results.append(f"{header}\n{body}")
            # Fix 14: Append file TOC on first line-range read of an edited file.
            # Tells the agent the file's total length and symbol structure so it
            # doesn't need further scroll-scan reads to find the insertion point.
            if (edited_file_toc
                    and file_path not in _toc_injected_files
                    and any(
                        file_path == ef or file_path.endswith(ef) or ef.endswith(file_path)
                        for ef in edited_files
                    )):
                toc_block = _build_file_toc(project, file_path)
                if toc_block:
                    total_tokens += len(toc_block) // 4
                    results.append(toc_block)
                _toc_injected_files.add(file_path)
            continue

        # No symbol and no lines — emit symbol index so agent can make targeted follow-up
        if not symbol:
            sym_lines: list[str] = []
            if _memory_store:
                # Collect all symbols defined in this file with their line ranges
                file_syms = _memory_store.get_file_symbols(file_path)
                if file_syms:
                    sym_lines = [f"    {s['name']}({s['line_start']}-{s['line_end']})" for s in file_syms[:20]]
            if sym_lines:
                sym_index = "\n".join(sym_lines)
                results.append(
                    f"--- {file_path} — specify symbol or lines\n{sym_index}"
                )
            else:
                results.append(f"--- {file_path} — SKIPPED (need symbol or lines)")
            continue

        # Find the symbol
        locations = _memory_store.locate_symbol(symbol)
        match = None
        for loc_file, loc_line in locations:
            if loc_file == file_path or loc_file.endswith(file_path) or file_path.endswith(loc_file):
                match = (loc_file, loc_line)
                break

        if not match:
            fuzzy = _memory_store.locate_symbol_fuzzy(symbol, max_results=3)
            candidates = [
                (f, l) for f, l, _ in fuzzy
                if f == file_path or f.endswith(file_path) or file_path.endswith(f)
            ]
            if candidates:
                match = candidates[0]

        if not match:
            results.append(f"--- {file_path}::{symbol} — NOT FOUND")
            continue

        resolved_file, line = match
        sym_info = _memory_store.get_symbol_at(resolved_file, line)
        if not sym_info:
            results.append(f"--- {resolved_file}:{line} ({symbol}) — no range info")
            continue

        line_start = sym_info.get("line_start", line)
        line_end = sym_info.get("line_end", line + 20)

        # Mode 3: Symbol + padding — expand range
        if lines_spec:
            padding = _parse_padding(lines_spec)
            if padding > 0:
                line_start = max(1, line_start - padding)
                line_end = line_end + padding
                # Read from disk (may have been edited since cache)
                src_lines = _read_file_lines(project, resolved_file, line_start, line_end)
            else:
                results.append(f"--- {file_path}::{symbol} — invalid padding: {lines_spec}")
                continue
        else:
            # Mode 2: Symbol only — apply context param if present
            ctx = min(max(int(t.get("context", 0)), 0), 20)
            if ctx > 0:
                line_start = max(1, line_start - ctx)
                line_end = line_end + ctx
                src_lines = _read_file_lines(project, resolved_file, line_start, line_end)
            else:
                src_lines = _memory_store.get_lines(resolved_file, line_start, line_end)

        if not src_lines:
            # Fix 2: suffix-match fallback for symbol mode
            alt_fp = _resolve_path_suffix_match(project, resolved_file)
            if alt_fp and alt_fp != resolved_file:
                src_lines = _read_file_lines(project, alt_fp, line_start, line_end)
                if src_lines:
                    resolved_file = alt_fp
        if not src_lines:
            results.append(f"--- {resolved_file}:{line_start}-{line_end} ({symbol}) — no source")
            continue

        header = f"--- {resolved_file}:{line_start}-{line_end} ({sym_info.get('name', symbol)})"
        numbered = [f"{line_start + i}│{sl.rstrip()}" for i, sl in enumerate(src_lines)]
        body = "\n".join(numbered)
        total_tokens += len(body) // 4
        result_block = f"{header}\n{body}"

        # Fix 13: Edit-ready output — raw old_string block for edit_batch
        if edit_ready and src_lines and len(src_lines) <= 30:
            sym_name = sym_info.get("name", symbol)
            raw_body = "\n".join(sl.rstrip() for sl in src_lines)
            result_block += f"\n```edit-ready:{sym_name}\n{raw_body}\n```"
            total_tokens += len(raw_body) // 4

        results.append(result_block)

        # Track for read-ahead
        resolved_symbols.add(sym_info.get("name", symbol))
        file_source_lines.setdefault(resolved_file, []).extend(src_lines)

    # ── Read-ahead: include same-file callees ───────────────────────────
    # For each file that had symbols resolved, scan the collected source
    # bodies for function calls to other functions in the same file.
    # Only 1 level deep, capped at _READAHEAD_MAX total extras.
    readahead_active = os.environ.get("TALON_READAHEAD", "0") == "1"
    readahead_count = 0
    if _memory_store and (readahead_active or monitor_enabled):
        for ra_file, ra_lines in file_source_lines.items():
            if readahead_count >= _READAHEAD_MAX:
                break
            extras = _extract_same_file_callees(
                ra_lines, ra_file, _memory_store, resolved_symbols,
            )
            # Monitor: record predictions regardless of active mode
            if monitor_enabled:
                file_resolved = {s for s in resolved_symbols if s}
                _ra_monitor_record_predictions(extras, ra_file, file_resolved)

            # Only include in response if read-ahead is active (not monitor-only)
            if readahead_active:
                for _, ls, le, name in extras:
                    if readahead_count >= _READAHEAD_MAX:
                        break
                    ra_src = _memory_store.get_lines(ra_file, ls, le)
                    if not ra_src:
                        continue
                    ra_header = f"--- {ra_file}:{ls}-{le} ({name}) [read-ahead]"
                    ra_numbered = [f"{ls + i}│{sl.rstrip()}" for i, sl in enumerate(ra_src)]
                    ra_body = "\n".join(ra_numbered)
                    total_tokens += len(ra_body) // 4
                    results.append(f"{ra_header}\n{ra_body}")
                    resolved_symbols.add(name)
                    readahead_count += 1

    response = "\n\n".join(results)

    # Fix 12: Token budget cap — truncate oversized responses
    batch_cap = int(os.environ.get("TALON_BATCH_CAP", "0"))
    if batch_cap > 0 and len(response) > batch_cap:
        # Truncate at a target boundary
        truncated = response[:batch_cap]
        last_sep = truncated.rfind("\n\n---")
        if last_sep > batch_cap // 2:
            truncated = truncated[:last_sep]
        served = truncated.count("---")
        omitted = len(results) - served
        response = truncated + f"\n\n[truncated — {omitted} targets omitted, response exceeded {batch_cap // 1000}K char cap. Re-request specific symbols.]"

    tokens_est = len(response) // 4
    latency_ms = (time.monotonic() - start) * 1000

    if _telemetry:
        metric = ToolCallMetric(
            intent="smart_read_batch",
            target=f"{len(targets)} symbols",
            depth="full",
            response_tokens=tokens_est,
            latency_ms=latency_ms,
            cache_hit=True,
            warnings_count=0,
            layers_used=["L1"],
        )
        _telemetry.log(metric)

    ra_suffix = f" +{readahead_count} read-ahead" if readahead_count else ""
    mon_suffix = f" ra-monitor:{ra_hits}hits/{len(_ra_pending_predictions)}pending" if monitor_enabled else ""
    return [TextContent(type="text", text=f"{response}\n[~{tokens_est} tokens, {len(targets)} targets{ra_suffix}{mon_suffix}]")]


# ── Read-ahead: same-file callee inclusion ──────────────────────────────────
# When reading function A, if A calls function B in the same file and B wasn't
# already requested, include B's body automatically. Deterministic: only direct
# callees in the same file, 1 level deep, capped at 5 extras.

_READAHEAD_SKIP = frozenset({
    'if', 'for', 'while', 'with', 'return', 'yield', 'raise', 'assert', 'del',
    'print', 'len', 'range', 'enumerate', 'zip', 'map', 'filter', 'sorted',
    'list', 'dict', 'set', 'tuple', 'str', 'int', 'float', 'bool', 'type',
    'isinstance', 'issubclass', 'hasattr', 'getattr', 'setattr', 'delattr',
    'super', 'property', 'staticmethod', 'classmethod', 'open', 'repr',
    'max', 'min', 'sum', 'abs', 'any', 'all', 'next', 'iter', 'id', 'hash',
    'vars', 'dir', 'callable', 'format', 'input', 'round', 'reversed',
    'not', 'and', 'or', 'in', 'is', 'None', 'True', 'False',
})

_READAHEAD_MAX = 5  # max extra symbols to include per batch call


def _extract_same_file_callees(
    source_lines: list[str],
    file_path: str,
    memory: "MemoryStore",
    already_resolved: set[str],
) -> list[tuple[str, int, int, str]]:
    """Extract same-file function callees from source bodies.

    Returns list of (file, line_start, line_end, name) for callees that are:
    1. Called in the source (name( pattern or self.name( pattern)
    2. Defined in the same file
    3. Not already resolved in this batch
    Capped at _READAHEAD_MAX to prevent response bloat.
    """
    calls: set[str] = set()
    for line in source_lines:
        # function_name( pattern
        for m in re.finditer(r'\b([a-zA-Z_]\w*)\s*\(', line):
            name = m.group(1)
            if name not in _READAHEAD_SKIP and name not in already_resolved:
                calls.add(name)
        # self.method() pattern — extract method name
        for m in re.finditer(r'self\.([a-zA-Z_]\w*)\s*\(', line):
            name = m.group(1)
            if name not in already_resolved:
                calls.add(name)

    if not calls:
        return []

    read_ahead: list[tuple[str, int, int, str]] = []
    for name in sorted(calls):
        if len(read_ahead) >= _READAHEAD_MAX:
            break
        locations = memory.locate_symbol(name)
        for loc_file, loc_line in locations:
            if loc_file == file_path:
                sym_info = memory.get_symbol_at(loc_file, loc_line)
                if sym_info:
                    read_ahead.append((
                        loc_file,
                        sym_info.get("line_start", loc_line),
                        sym_info.get("line_end", loc_line + 20),
                        sym_info.get("name", name),
                    ))
                break
    return read_ahead


# ── Read-ahead monitor ──────────────────────────────────────────────────────
# Shadow mode: compute what read-ahead would include, log predictions to
# autobot DB, check subsequent calls for hits. Enable via TALON_READAHEAD_MONITOR=1.

def _ra_monitor_init() -> None:
    """Lazy-init the monitor session ID and DB store."""
    global _ra_monitor_session, _ra_store
    if _ra_monitor_session:
        return
    _ra_monitor_session = f"ra-{int(time.time())}"
    try:
        from talon.ab.autobot.db import AutobotStore
        _ra_store = AutobotStore()
    except Exception as e:
        logger.warning("Read-ahead monitor: DB init failed: %s", e)
        _ra_store = None


def _ra_monitor_check_hits(requested_symbols: set[str]) -> int:
    """Check pending predictions against current request targets. Returns hit count."""
    global _ra_pending_predictions
    if not _ra_pending_predictions or not requested_symbols:
        return 0

    hits: list[str] = []
    remaining: list[dict] = []
    for p in _ra_pending_predictions:
        if p["symbol"] in requested_symbols:
            hits.append(p["symbol"])
        else:
            remaining.append(p)
    _ra_pending_predictions = remaining

    if hits and _ra_store:
        import threading
        threading.Thread(
            target=_ra_store.update_readahead_hits,
            args=(_ra_monitor_session, _ra_monitor_call, hits),
            daemon=True,
        ).start()

    return len(hits)


def _ra_monitor_record_predictions(
    extras: list[tuple[str, int, int, str]],
    source_file: str,
    source_symbols: set[str],
) -> None:
    """Record new read-ahead predictions to memory + DB."""
    global _ra_pending_predictions
    if not extras:
        return

    new_preds: list[dict] = []
    source_sym = ", ".join(sorted(source_symbols)[:3])  # compact source label
    for _, _, _, name in extras:
        pred = {
            "symbol": name,
            "file": source_file,
            "source_symbol": source_sym,
            "source_file": source_file,
            "call_number": _ra_monitor_call,
        }
        _ra_pending_predictions.append(pred)
        new_preds.append({
            "predicted_symbol": name,
            "predicted_file": source_file,
            "source_symbol": source_sym,
            "source_file": source_file,
        })

    if new_preds and _ra_store:
        import threading
        threading.Thread(
            target=_ra_store.insert_readahead_predictions,
            args=(_ra_monitor_session, _ra_monitor_call, new_preds),
            daemon=True,
        ).start()


def _parse_line_range(spec: str) -> tuple[int, int] | None:
    """Parse '100-150' line range spec. Returns (start, end) or None."""
    if not spec or spec.startswith("±") or spec.startswith("+"):
        return None
    parts = spec.split("-", 1)
    if len(parts) != 2:
        return None
    try:
        start, end = int(parts[0]), int(parts[1])
        if start < 1 or end < start:
            return None
        return (start, end)
    except ValueError:
        return None


def _parse_padding(spec: str) -> int:
    """Parse '±10' or '+10' padding spec. Returns padding int or 0."""
    cleaned = spec.replace("±", "").replace("+", "").replace("-", "").strip()
    try:
        val = int(cleaned)
        return val if val > 0 else 0
    except ValueError:
        return 0


async def _edit_pytest_run(edited_files: list[str], project: Path) -> str:
    """TALON_EDIT_PYTEST: structured pytest run appended to edit_batch response.

    Discovers test files the same way as _auto_verify_edits, then runs
    talon_pytest logic (structured output + TALON_PYTEST_ARGS support).
    Returns a compact result string to append to the edit_batch response.
    """
    import re as _re
    import shlex

    # Discover test files matching edited source files (same as auto-verify)
    test_targets: list[str] = []
    for ef in edited_files:
        base = Path(ef).stem
        if base.startswith("test_"):
            test_targets.append(ef)
            continue
        test_name = f"test_{base}"
        for test_dir in ["tests", "t/unit", "tests/unit", "test"]:
            td = project / test_dir
            if td.exists():
                for match in td.rglob(f"{test_name}.py"):
                    rel = str(match.relative_to(project))
                    if rel not in test_targets:
                        test_targets.append(rel)

    if not test_targets:
        return ""

    # Skip pytest for projects that use a custom test runner (e.g. Django runtests.py).
    # Pytest cannot import Django test suites without special configuration, producing
    # 100% collection errors that waste turns.
    custom_runner_markers = ["runtests.py", "manage.py"]
    for marker in custom_runner_markers:
        if (project / marker).exists():
            return f"--- edit-pytest: SKIP (project uses {marker}, not pytest) ---"

    targets_to_run = test_targets[:5]
    cmd = [sys.executable, "-m", "pytest"] + [str(project / t) for t in targets_to_run] + ["-v", "--tb=short", "-q"]

    # TALON_PYTEST_ARGS — project-level flags (e.g. "-p no:warnings")
    env_args = os.environ.get("TALON_PYTEST_ARGS", "").strip()
    if env_args:
        try:
            cmd += shlex.split(env_args)
        except ValueError:
            cmd += env_args.split()

    run_env = os.environ.copy()
    existing_pp = run_env.get("PYTHONPATH", "")
    project_str = str(project)
    if project_str not in existing_pp.split(os.pathsep):
        run_env["PYTHONPATH"] = (
            f"{project_str}{os.pathsep}{existing_pp}" if existing_pp else project_str
        )

    try:
        result = subprocess.run(
            cmd, cwd=str(project), timeout=60,
            capture_output=True, text=True, env=run_env,
        )
    except subprocess.TimeoutExpired:
        return "--- edit-pytest: TIMEOUT (60s) ---"

    output = result.stdout + result.stderr
    passed = failed = errors = 0
    for m in _re.finditer(r"(\d+) passed", output):
        passed = int(m.group(1))
    for m in _re.finditer(r"(\d+) failed", output):
        failed = int(m.group(1))
    for m in _re.finditer(r"(\d+) error", output):
        errors = int(m.group(1))
    collection_error = (
        passed == 0 and failed == 0 and errors == 0 and result.returncode != 0
    )
    time_match = _re.search(r"in ([\d.]+)s", output)
    elapsed = time_match.group(1) if time_match else "?"
    labels = ", ".join(t.split("/")[-1] for t in targets_to_run)

    if failed == 0 and errors == 0 and not collection_error and passed > 0:
        return f"--- edit-pytest: PASS {passed} passed ({elapsed}s) [{labels}] ---"

    # PASS-only mode: on failure or collection error, return empty string.
    # Rationale: inline FAIL feedback triggers Bash debug spirals (P2 pattern).
    # Silence lets the agent proceed; it can verify manually if needed.
    # The confidence signal (PASS) is what matters — failure is just silence.
    return ""


def _resolve_path_suffix_match(project: Path, file_path: str) -> str | None:
    """Try to resolve a graph path that doesn't exist in the workspace by suffix-matching.

    Graph paths are often indexed without a leading 'src/' prefix (e.g. 'airflow/models/dagrun.py')
    but the workspace copy lives at 'src/airflow/models/dagrun.py'. This function globs the
    project tree for any file whose path ends with `file_path` (or whose suffix matches the
    basename) and returns the workspace-relative path if found.

    Returns the resolved relative path string, or None if no match.
    """
    import fnmatch as _fnmatch

    # Quick check: already exists
    if (project / file_path).exists():
        return file_path

    fp = Path(file_path)
    filename = fp.name

    # Collect candidate files matching the basename
    try:
        candidates = list(project.glob(f"**/{filename}"))
    except Exception:
        return None

    if not candidates:
        return None

    # Prefer the candidate whose relative path ends with file_path
    for c in candidates:
        try:
            rel = c.relative_to(project).as_posix()
        except ValueError:
            continue
        if rel.endswith(file_path) or file_path.endswith(rel):
            return rel

    # Fall back to the shortest path (least deeply nested)
    best = min(candidates, key=lambda c: len(c.parts))
    try:
        return best.relative_to(project).as_posix()
    except ValueError:
        return None


def _read_file_lines(project: Path, file_path: str, start: int, end: int) -> list[str]:
    """Read lines start..end (1-indexed, inclusive) from disk."""
    full_path = project / file_path
    if not full_path.exists():
        return []
    try:
        all_lines = full_path.read_text().splitlines()
    except (OSError, UnicodeDecodeError):
        return []
    return all_lines[max(0, start - 1):end]  # 1-indexed to 0-indexed


# ---------------------------------------------------------------------------
# edit_batch handler (X904e — batch edits to cut round-trips)
# ---------------------------------------------------------------------------


def _auto_verify_edits(edited_files: list[str], project: Path) -> str:
    """Fix 15: Auto-run pytest on test files matching edited source files.

    Returns a compact pass/fail summary or empty string if no tests found.
    """
    import re as _re

    # Resolve test files from edited files
    test_targets: list[str] = []
    for ef in edited_files:
        base = Path(ef).stem
        # Skip test files themselves
        if base.startswith("test_"):
            test_targets.append(ef)
            continue
        # Convention: foo.py → test_foo.py
        test_name = f"test_{base}"
        for test_dir in ["tests", "t/unit", "tests/unit", "test"]:
            td = project / test_dir
            if td.exists():
                for match in td.rglob(f"{test_name}.py"):
                    rel = str(match.relative_to(project))
                    if rel not in test_targets:
                        test_targets.append(rel)

    if not test_targets:
        return ""

    # Build env with project PYTHONPATH
    run_env = os.environ.copy()
    existing_pp = run_env.get("PYTHONPATH", "")
    project_str = str(project)
    if project_str not in existing_pp.split(os.pathsep):
        run_env["PYTHONPATH"] = (
            f"{project_str}{os.pathsep}{existing_pp}" if existing_pp else project_str
        )

    # Run pytest on discovered test files (cap at 3 files, 30s timeout)
    targets_to_run = test_targets[:3]
    cmd = [sys.executable, "-m", "pytest"] + [str(project / t) for t in targets_to_run] + ["-q", "--tb=line", "--no-header"]

    try:
        result = subprocess.run(
            cmd, cwd=str(project), timeout=30,
            capture_output=True, text=True, env=run_env,
        )
    except subprocess.TimeoutExpired:
        return "--- auto-verify: TIMEOUT (30s) ---"

    output = result.stdout + result.stderr

    # Parse pass/fail
    passed = failed = errors = 0
    for m in _re.finditer(r"(\d+) passed", output):
        passed = int(m.group(1))
    for m in _re.finditer(r"(\d+) failed", output):
        failed = int(m.group(1))
    for m in _re.finditer(r"(\d+) error", output):
        errors = int(m.group(1))

    time_match = _re.search(r"in ([\d.]+)s", output)
    elapsed = time_match.group(1) if time_match else "?"

    if failed == 0 and errors == 0 and passed > 0:
        return f"--- auto-verify: PASS ({passed} passed, {elapsed}s) [{', '.join(targets_to_run)}] ---"

    # Include first failure line for context
    summary = f"--- auto-verify: FAIL ({passed} passed, {failed} failed, {errors} errors, {elapsed}s) ---"
    fail_lines = [l for l in output.splitlines() if "FAILED" in l or "ERROR" in l]
    if fail_lines:
        summary += "\n" + "\n".join(fail_lines[:3])
    return summary


async def _handle_edit_batch(
    arguments: dict[str, Any], start: float
) -> list[TextContent]:
    """Apply multiple file edits in a single call.

    Eliminates N-1 Edit round-trips by batching. Each round-trip saved
    avoids resending the full conversation context to the API.
    """
    from talon.proxy.edit_batch import apply_edits

    edits = arguments.get("edits", [])
    if isinstance(edits, str):
        import json as _json
        try: edits = _json.loads(edits)
        except Exception: edits = []
    if not edits:
        return [TextContent(type="text", text="Missing required parameter: edits.")]

    if len(edits) > 20:
        return [TextContent(type="text", text=f"Too many edits ({len(edits)}). Maximum 20 per batch.")]

    results = apply_edits(edits, project_path=_project_path)

    # Refresh MemoryStore + response cache for successfully edited files
    if _memory_store:
        from talon.mcp.intent_router import invalidate_file

        project = Path(_project_path) if _project_path else Path.cwd()
        edited_files: set[str] = set()
        for r in results:
            if r["status"] == "ok":
                edited_files.add(r["file"])
        for fp in edited_files:
            try:
                full_path = Path(fp) if Path(fp).is_absolute() else project / fp
                new_content = full_path.read_text()
                _memory_store.refresh_file(fp, new_content)
            except Exception:
                _memory_store.invalidate(fp)
            invalidate_file(fp)
        if edited_files:
            logger.info("edit_batch: refreshed cache for %d files: %s",
                        len(edited_files), ", ".join(sorted(edited_files)))

    # Precision tracking: compare edited files against scope-served files
    pt_msg: str | None = None
    if _pt_enabled:
        ok_files = {r["file"] for r in results if r["status"] == "ok"}
        if ok_files:
            pt_msg = _pt_on_edit_batch(ok_files)

    # Format response
    ok = sum(1 for r in results if r["status"] == "ok")
    failed = len(results) - ok

    lines = [f"edit_batch: {ok}/{len(results)} applied"]
    for r in results:
        status_icon = "OK" if r["status"] == "ok" else "FAIL"
        lines.append(f"  [{status_icon}] {r['file']} — {r['detail']}")

    if pt_msg:
        lines.append(pt_msg)

    response = "\n".join(lines)

    # Fix 15: Silent auto-verify — run pytest on test files matching edited files
    auto_verify = os.environ.get("TALON_AUTO_VERIFY", "0") == "1"
    if auto_verify and ok > 0:
        project = Path(_project_path) if _project_path else Path.cwd()
        edited_files_list = [r["file"] for r in results if r["status"] == "ok"]
        verify_result = _auto_verify_edits(edited_files_list, project)
        if verify_result:
            response += f"\n\n{verify_result}"

    # TALON_EDIT_PYTEST: structured pytest appended to edit_batch result.
    # Same test-discovery logic as auto-verify but uses talon_pytest output
    # format and honours TALON_PYTEST_ARGS — no extra Bash turn needed.
    edit_pytest = os.environ.get("TALON_EDIT_PYTEST", "0") == "1"
    if edit_pytest and ok > 0:
        project = Path(_project_path) if _project_path else Path.cwd()
        edited_files_list = [r["file"] for r in results if r["status"] == "ok"]
        pytest_result = await _edit_pytest_run(edited_files_list, project)
        if pytest_result:
            response += f"\n\n{pytest_result}"

    tokens_est = len(response) // 4
    latency_ms = (time.monotonic() - start) * 1000

    if _telemetry:
        metric = ToolCallMetric(
            intent="edit_batch",
            target=f"{len(edits)} edits",
            depth="full",
            response_tokens=tokens_est,
            latency_ms=latency_ms,
            cache_hit=False,
            warnings_count=failed,
            layers_used=[],
        )
        _telemetry.log(metric)

    return [TextContent(type="text", text=f"{response}\n[~{tokens_est} tokens]")]


# ---------------------------------------------------------------------------
# write_batch handler — create multiple new files in one call
# ---------------------------------------------------------------------------


async def _handle_write_batch(
    arguments: dict[str, Any], start: float
) -> list[TextContent]:
    """Create multiple new files in a single call.

    Each entry specifies file_path and content. Files are written
    atomically — parent directories are created as needed.
    """
    files = arguments.get("files", [])
    if isinstance(files, str):
        import json as _json
        try: files = _json.loads(files)
        except Exception: files = []
    if not files:
        return [TextContent(type="text", text="Missing required parameter: files.")]

    if len(files) > 10:
        return [TextContent(type="text", text=f"Too many files ({len(files)}). Maximum 10 per batch.")]

    project = Path(_project_path) if _project_path else Path.cwd()
    results_lines: list[str] = []
    ok = 0
    failed = 0

    for entry in files:
        fp = entry.get("file_path", "")
        content = entry.get("content", "")
        if not fp:
            results_lines.append("  [FAIL] (missing file_path)")
            failed += 1
            continue

        target = Path(fp)
        if not target.is_absolute():
            target = project / target

        try:
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_text(content)
            results_lines.append(f"  [OK] {fp} ({len(content)} bytes)")
            ok += 1

            # Refresh MemoryStore for the new file so SKIPPED includes its symbols
            if _memory_store:
                from talon.mcp.intent_router import invalidate_file
                rel = str(target.relative_to(project)) if target.is_relative_to(project) else fp
                _memory_store.refresh_file(rel, content)
                invalidate_file(rel)
        except Exception as exc:
            results_lines.append(f"  [FAIL] {fp} — {exc}")
            failed += 1

    header = f"write_batch: {ok}/{len(files)} created"
    response = header + "\n" + "\n".join(results_lines)
    tokens_est = len(response) // 4
    latency_ms = (time.monotonic() - start) * 1000

    if _telemetry:
        metric = ToolCallMetric(
            intent="write_batch",
            target=f"{len(files)} files",
            depth="full",
            response_tokens=tokens_est,
            latency_ms=latency_ms,
            cache_hit=False,
            warnings_count=failed,
            layers_used=[],
        )
        _telemetry.log(metric)

    return [TextContent(type="text", text=f"{response}\n[~{tokens_est} tokens]")]


# ---------------------------------------------------------------------------
# talon_verify handler (Path U — structured test runner)
# ---------------------------------------------------------------------------


async def _handle_verify(
    arguments: dict[str, Any], start: float
) -> list[TextContent]:
    """Run tests via pytest and return a structured pass/fail summary.

    Replaces Bash-based test verification with a purpose-built tool that
    returns ~50-200 tokens of structured output instead of raw pytest dump.
    """
    import re as _re

    target = arguments.get("target", "").strip()
    scope = arguments.get("scope", "file")
    detail = arguments.get("detail", "failures")  # X7: tiered detail levels

    # Multi-target: split on commas and run each independently
    if "," in target:
        targets = [t.strip() for t in target.split(",") if t.strip()]
        all_results: list[str] = []
        total_passed = 0
        total_failed = 0
        for t in targets:
            sub_args = {**arguments, "target": t}
            sub_result = await _handle_verify(sub_args, time.monotonic())
            text = sub_result[0].text if sub_result else "ERROR"
            # Extract pass/fail from sub-result for combined summary
            import re as _mre
            for m in _mre.finditer(r"(\d+) passed", text):
                total_passed += int(m.group(1))
            for m in _mre.finditer(r"(\d+) failed", text):
                total_failed += int(m.group(1))
            all_results.append(f"[{t.split('/')[-1]}] {text.split(chr(10))[0]}")
        combined = "\n".join(all_results)
        summary_line = f"\nCOMBINED: {total_passed} passed, {total_failed} failed across {len(targets)} targets"
        tokens_est = len(combined) // 4
        return [TextContent(type="text", text=f"{combined}{summary_line}\n[~{tokens_est} tokens]")]

    # Resolve target relative to project path
    project = Path(_project_path) if _project_path else Path.cwd()
    discover_on = os.environ.get("TALON_VERIFY_DISCOVER", "0") == "1"

    # Fix 14: Auto-discover tests from written files when target is empty
    if not target and discover_on:
        session_path = project / ".claude" / "state" / "session.json"
        if session_path.exists():
            try:
                sess = json.loads(session_path.read_text())
                written = sess.get("written_files", [])
                for wf in written:
                    base = Path(wf).stem
                    test_name = f"test_{base}" if not base.startswith("test_") else base
                    for test_dir in ["tests", "t/unit", "tests/unit", "test"]:
                        td = project / test_dir
                        if td.exists():
                            for match in td.rglob(f"{test_name}.py"):
                                target = str(match.relative_to(project))
                                break
                        if target:
                            break
                    if target:
                        break
            except (json.JSONDecodeError, OSError):
                pass

    # Fix 16: Symbol-to-test resolution (e.g. "Consumer" → test_consumer.py)
    if target and "/" not in target and not target.endswith(".py") and "::" not in target and discover_on:
        sym_lower = target.lower()
        test_search = f"test_{sym_lower}"
        for test_dir in ["tests", "t/unit", "tests/unit", "test"]:
            td = project / test_dir
            if td.exists():
                for match in td.rglob("*.py"):
                    if test_search in match.stem.lower():
                        target = str(match.relative_to(project))
                        break
                if target.endswith(".py"):
                    break

    if not target:
        return [TextContent(type="text", text="Missing required parameter: target.")]

    # Build pytest command — handle :: separator for function scope
    if scope == "function" and "::" in target:
        file_part, func_part = target.split("::", 1)
        target_path = project / file_part
        if not target_path.exists():
            return [TextContent(
                type="text",
                text=f"ERROR: Target not found: {file_part}\nResolved to: {target_path}",
            )]
        cmd = [sys.executable, "-m", "pytest", str(target_path), "-k", func_part, "-v", "--tb=short", "-q"]
    else:
        target_path = project / target
        if not target_path.exists():
            return [TextContent(
                type="text",
                text=f"ERROR: Target not found: {target}\nResolved to: {target_path}",
            )]
        cmd = [sys.executable, "-m", "pytest", str(target_path), "-v", "--tb=short", "-q"]

    # Build env with PYTHONPATH including the project root
    # Without this, pytest can't collect tests in projects that need
    # the workspace on sys.path (e.g. celery's t/unit/ tests).
    run_env = os.environ.copy()
    existing_pp = run_env.get("PYTHONPATH", "")
    project_str = str(project)
    if project_str not in existing_pp.split(os.pathsep):
        run_env["PYTHONPATH"] = (
            f"{project_str}{os.pathsep}{existing_pp}" if existing_pp else project_str
        )

    try:
        result = subprocess.run(
            cmd,
            cwd=str(project),
            timeout=60,
            capture_output=True,
            text=True,
            env=run_env,
        )
    except subprocess.TimeoutExpired:
        latency_ms = (time.monotonic() - start) * 1000
        _log_verify_telemetry(target, 0, latency_ms)
        return [TextContent(type="text", text=f"TIMEOUT: Tests exceeded 60s limit on {target}")]

    output = result.stdout + result.stderr
    latency_ms = (time.monotonic() - start) * 1000

    # Parse pass/fail counts from pytest output
    # Patterns: "5 passed", "1 failed", "2 error"
    passed = 0
    failed = 0
    errors = 0

    for m in _re.finditer(r"(\d+) passed", output):
        passed = int(m.group(1))
    for m in _re.finditer(r"(\d+) failed", output):
        failed = int(m.group(1))
    for m in _re.finditer(r"(\d+) error", output):
        errors = int(m.group(1))
    # Collection/import errors (conftest fail, missing module) exit non-zero
    # but don't emit a "N error in Xs" summary line — detect via exit code
    collection_error = (
        passed == 0 and failed == 0 and errors == 0 and result.returncode != 0
    )

    # Extract elapsed time
    time_match = _re.search(r"in ([\d.]+)s", output)
    elapsed = time_match.group(1) if time_match else "?"

    if failed == 0 and errors == 0 and not collection_error and passed > 0:
        summary = f"PASS: {passed} passed, 0 failed ({elapsed}s)"
    else:
        err_label = "collection error" if collection_error else f"{errors} errors"
        summary = f"FAIL: {passed} passed, {failed} failed, {err_label} ({elapsed}s)"

        # X907b: failures and full both produce identical rich output
        if detail != "summary":
            # Extract first failure message
            fail_match = _re.search(
                r"FAILED\s+(\S+)\s*[-—]\s*(.*?)(?:\n|$)", output
            )
            if not fail_match:
                fail_match = _re.search(
                    r"(test_\w+).*?(?:AssertionError|AssertionError|Error|Exception)[:\s]*(.*?)(?:\n|$)",
                    output,
                )
            if fail_match:
                summary += f"\nFirst failure: {fail_match.group(1).strip()}"
                if fail_match.group(2).strip():
                    summary += f" — {fail_match.group(2).strip()[:200]}"

            # FAILURES section (assertion/runtime errors)
            short_tb = _re.search(r"(FAILURES.*?)(?:=+ short test summary|$)", output, _re.DOTALL)
            if short_tb:
                tb_text = short_tb.group(1).strip()
                if len(tb_text) > 1500:
                    tb_text = tb_text[:1500] + "..."
                summary += f"\n\n{tb_text}"

            # ERRORS section (collection/import errors — no FAILURES section exists)
            if not short_tb:
                errors_tb = _re.search(r"(ERRORS.*?)(?:=+ short test summary|$)", output, _re.DOTALL)
                if errors_tb:
                    tb_text = errors_tb.group(1).strip()
                    if len(tb_text) > 1500:
                        tb_text = tb_text[:1500] + "..."
                    summary += f"\n\n{tb_text}"
                elif collection_error:
                    # conftest itself failed to import — dump raw output (capped)
                    raw = output.strip()
                    if len(raw) > 1500:
                        raw = raw[:1500] + "..."
                    summary += f"\n\n{raw}"

            # X907b: source context at failure locations
            summary += _extract_failure_context(output, project)

            # X909: Merge verify_fix — include test source + code under test
            fix_kit = _build_fix_kit(output, project)
            if fix_kit:
                summary += fix_kit

    tokens_est = len(summary) // 4
    _log_verify_telemetry(target, tokens_est, latency_ms)

    return [TextContent(type="text", text=f"{summary}\n[~{tokens_est} tokens]")]


def _extract_failure_context(output: str, project: Path) -> str:
    """Extract source context around failure locations from pytest output.

    Parses file:line from tracebacks and reads ±5 lines from disk.
    Only includes project-local files (not stdlib/venv). Max 3 locations,
    total context capped at 1200 chars.
    """
    import re as _re

    # Find file:line patterns in pytest output
    locs = _re.findall(r"(\S+\.py):(\d+)", output)
    if not locs:
        return ""

    seen: set[str] = set()
    sections: list[str] = []
    project_str = str(project)

    for fpath, lineno_str in locs:
        if len(sections) >= 3:
            break

        # Resolve to absolute path
        abs_path = Path(fpath)
        if not abs_path.is_absolute():
            abs_path = project / fpath

        # Filter: only project-local files
        try:
            abs_resolved = str(abs_path.resolve())
        except (OSError, ValueError):
            continue

        if not abs_resolved.startswith(project_str):
            continue

        # Deduplicate by file:line
        key = f"{abs_resolved}:{lineno_str}"
        if key in seen:
            continue
        seen.add(key)

        if not abs_path.exists():
            continue

        lineno = int(lineno_str)
        try:
            all_lines = abs_path.read_text().splitlines()
        except (OSError, UnicodeDecodeError):
            continue

        start = max(0, lineno - 6)  # ±5 lines (1-indexed → 0-indexed: lineno-1 ±5)
        end = min(len(all_lines), lineno + 5)
        snippet_lines = all_lines[start:end]

        # Format with line numbers
        numbered = [f"{start + i + 1}│{sl.rstrip()}" for i, sl in enumerate(snippet_lines)]
        rel_path = fpath if not Path(fpath).is_absolute() else str(abs_path.relative_to(project))
        sections.append(f"--- {rel_path}:{lineno} context ---\n" + "\n".join(numbered))

    if not sections:
        return ""

    context = "\n\n".join(sections)
    if len(context) > 1200:
        context = context[:1200] + "..."
    return f"\n\n{context}"


def _log_verify_telemetry(target: str, tokens_est: int, latency_ms: float) -> None:
    """Fire-and-forget telemetry for verify calls."""
    if _telemetry:
        metric = ToolCallMetric(
            intent="verify",
            target=target,
            depth="standard",
            response_tokens=tokens_est,
            latency_ms=latency_ms,
            cache_hit=False,
            warnings_count=0,
            layers_used=[],
        )
        _telemetry.log(metric)


# ---------------------------------------------------------------------------
# talon_pytest handler — multi-file pytest, env-var config, token-efficient
# ---------------------------------------------------------------------------


async def _handle_talon_pytest(
    arguments: dict[str, Any], start: float
) -> list[TextContent]:
    """Run pytest on multiple test files; return structured summary.

    Equivalent to Bash(pytest ...) but returns ~50-300 tokens of structured
    output instead of the full terminal dump, saving a full context round-trip.

    Extra args from TALON_PYTEST_ARGS env var are always appended — use this to
    inject project-level config (e.g. '-p no:warnings --tb=short').
    """
    import re as _re
    import shlex

    files = arguments.get("files", [])
    extra_args_str = arguments.get("args", "").strip()

    if not files:
        return [TextContent(type="text", text="Missing required parameter: files (list of test paths).")]

    project = Path(_project_path) if _project_path else Path.cwd()

    # Resolve and validate paths
    resolved: list[str] = []
    missing: list[str] = []
    for f in files[:10]:
        p = project / f
        if p.exists():
            resolved.append(str(p))
        else:
            missing.append(f)

    if missing:
        return [TextContent(type="text", text=f"ERROR: Test file(s) not found: {', '.join(missing)}")]

    # Build command — always use -v --tb=short -q for structured output
    cmd = [sys.executable, "-m", "pytest"] + resolved + ["-v", "--tb=short", "-q"]

    # Per-call args (e.g. "-k test_login -x")
    if extra_args_str:
        try:
            cmd += shlex.split(extra_args_str)
        except ValueError:
            cmd += extra_args_str.split()

    # TALON_PYTEST_ARGS env var — project-level config injected for every call
    env_args = os.environ.get("TALON_PYTEST_ARGS", "").strip()
    if env_args:
        try:
            cmd += shlex.split(env_args)
        except ValueError:
            cmd += env_args.split()

    # PYTHONPATH: ensure project root is on path for test collection
    run_env = os.environ.copy()
    existing_pp = run_env.get("PYTHONPATH", "")
    project_str = str(project)
    if project_str not in existing_pp.split(os.pathsep):
        run_env["PYTHONPATH"] = (
            f"{project_str}{os.pathsep}{existing_pp}" if existing_pp else project_str
        )

    try:
        result = subprocess.run(
            cmd, cwd=str(project), timeout=60,
            capture_output=True, text=True, env=run_env,
        )
    except subprocess.TimeoutExpired:
        return [TextContent(type="text", text=f"TIMEOUT: Tests exceeded 60s on {', '.join(files)}")]

    output = result.stdout + result.stderr
    latency_ms = (time.monotonic() - start) * 1000

    # Parse counts
    passed = failed = errors = 0
    for m in _re.finditer(r"(\d+) passed", output):
        passed = int(m.group(1))
    for m in _re.finditer(r"(\d+) failed", output):
        failed = int(m.group(1))
    for m in _re.finditer(r"(\d+) error", output):
        errors = int(m.group(1))
    time_match = _re.search(r"in ([\d.]+)s", output)
    elapsed = time_match.group(1) if time_match else "?"
    file_labels = ", ".join(f.split("/")[-1] for f in files)

    if failed == 0 and errors == 0 and passed > 0:
        response = f"PASS: {passed} passed, 0 failed ({elapsed}s) [{file_labels}]"
    elif failed == 0 and errors == 0 and passed == 0:
        response = f"NO TESTS: 0 collected ({elapsed}s) [{file_labels}]"
    else:
        response = f"FAIL: {passed} passed, {failed} failed, {errors} errors ({elapsed}s) [{file_labels}]"
        # Include failure section (capped at 2000 chars)
        fail_section = _re.search(r"(FAILURES.*?)(?:=+ short test summary|$)", output, _re.DOTALL)
        if fail_section:
            tb = fail_section.group(1).strip()
            if len(tb) > 2000:
                tb = tb[:2000] + "\n... (truncated)"
            response += f"\n\n{tb}"
        else:
            # Fallback: first FAILED lines
            fail_lines = [l for l in output.splitlines() if "FAILED" in l or "ERROR" in l]
            if fail_lines:
                response += "\n" + "\n".join(fail_lines[:5])

    tokens_est = len(response) // 4

    if _telemetry:
        metric = ToolCallMetric(
            intent="talon_pytest",
            target=file_labels,
            depth="full",
            response_tokens=tokens_est,
            latency_ms=latency_ms,
            cache_hit=False,
            warnings_count=failed + errors,
            layers_used=[],
        )
        _telemetry.log(metric)

    return [TextContent(type="text", text=f"{response}\n[~{tokens_est} tokens]")]


# ---------------------------------------------------------------------------
# X909: Fix Kit Builder (extracted from verify_fix for verify merge)
# ---------------------------------------------------------------------------


def _build_fix_kit(output: str, project: Path) -> str:
    """Build a fix kit from pytest output: test source + code under test.

    Parses failure locations from tracebacks, categorizes as test vs source,
    and returns the relevant function bodies so the LLM can fix without
    additional Read calls.
    """
    import re as _re

    locs = _re.findall(r"(\S+\.py):(\d+)", output)
    if not locs:
        return ""

    test_locs: list[tuple[str, int]] = []
    source_locs: list[tuple[str, int]] = []
    seen: set[str] = set()
    project_str = str(project)

    for fpath, lineno_str in locs:
        abs_path = Path(fpath) if Path(fpath).is_absolute() else project / fpath
        try:
            abs_resolved = str(abs_path.resolve())
        except (OSError, ValueError):
            continue
        if not abs_resolved.startswith(project_str):
            continue

        key = f"{abs_resolved}:{lineno_str}"
        if key in seen:
            continue
        seen.add(key)

        if not abs_path.exists():
            continue

        lineno = int(lineno_str)
        try:
            rel = str(abs_path.relative_to(project))
        except ValueError:
            rel = fpath

        is_test = any(x in rel for x in ["test_", "_test.", "/tests/"])
        if is_test:
            test_locs.append((rel, lineno))
        else:
            source_locs.append((rel, lineno))

    parts: list[str] = []

    # Test source at failure — show the failing test function
    for rel, lineno in test_locs[:2]:
        func_start = lineno
        func_end = lineno + 20
        if _memory_store:
            sym = _memory_store.get_symbol_at(rel, lineno)
            if sym:
                func_start = sym.get("line_start", lineno)
                func_end = sym.get("line_end", lineno + 20)
        src = _read_file_lines(project, rel, func_start, func_end)
        if src:
            numbered = [f"{func_start + i}│{sl.rstrip()}" for i, sl in enumerate(src)]
            parts.append(f"--- TEST: {rel}:{func_start}-{func_end} ---\n" + "\n".join(numbered))

    # Source code under test — show the function being tested
    for rel, lineno in source_locs[:2]:
        func_start = lineno
        func_end = lineno + 20
        if _memory_store:
            sym = _memory_store.get_symbol_at(rel, lineno)
            if sym:
                func_start = sym.get("line_start", lineno)
                func_end = sym.get("line_end", lineno + 30)
        src = _read_file_lines(project, rel, func_start, func_end)
        if src:
            numbered = [f"{func_start + i}│{sl.rstrip()}" for i, sl in enumerate(src)]
            parts.append(f"--- SOURCE: {rel}:{func_start}-{func_end} ---\n" + "\n".join(numbered))

    if not parts:
        return ""

    fix_kit = "\n\n".join(parts)
    # Cap at 2000 chars to stay within token budget
    if len(fix_kit) > 2000:
        fix_kit = fix_kit[:2000] + "\n..."
    return f"\n\n{fix_kit}"


# ---------------------------------------------------------------------------
# X907c Experimental Tools (NOT EXPOSED — dormant handlers for future activation)
# Enable via TALON_GREP=1, TALON_TEST_FOR=1, etc. when ready to test.
# ---------------------------------------------------------------------------


# --- Tool schemas (for future registration in list_tools) ---
EXPERIMENTAL_TOOL_SCHEMAS: dict[str, dict[str, Any]] = {
    "talon_grep": {
        "name": "talon_grep",
        "description": (
            "Search codebase for a pattern and return matches with surrounding context. "
            "Eliminates Grep → Read → Read pattern by returning matches with ±N lines. "
            "Results are structured by file with line numbers, ready for editing."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "pattern": {"type": "string", "description": "Regex pattern to search for"},
                "context": {"type": "integer", "description": "Lines of context around each match (default 3)", "default": 3},
                "glob": {"type": "string", "description": "File glob filter (e.g. '*.py', 'src/**/*.ts')"},
                "max_files": {"type": "integer", "description": "Max files to return (default 5)", "default": 5},
                "max_matches": {"type": "integer", "description": "Max matches per file (default 3)", "default": 3},
            },
            "required": ["pattern"],
        },
    },
    "talon_test_for": {
        "name": "talon_test_for",
        "description": (
            "Find test files and functions that cover a source file or symbol. "
            "Returns test locations with source bodies. Eliminates the Grep('test_X') → "
            "Glob('test_*.py') → Read → Read pattern."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "file": {"type": "string", "description": "Source file to find tests for (e.g. 'src/auth.py')"},
                "symbol": {"type": "string", "description": "Optional: specific function/class name"},
                "include_bodies": {"type": "boolean", "description": "Include test function bodies (default true)", "default": True},
            },
            "required": ["file"],
        },
    },
    "talon_verify_fix": {
        "name": "talon_verify_fix",
        "description": (
            "Run tests and on failure return a complete fix kit: traceback + failing test "
            "source + code under test. Eliminates verify → read test → read source → fix "
            "cycle (6 calls → 1)."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "target": {"type": "string", "description": "Test file or directory relative to project root"},
                "scope": {"type": "string", "enum": ["file", "function"], "description": "Run scope (default 'file')"},
            },
            "required": ["target"],
        },
    },
    "talon_check": {
        "name": "talon_check",
        "description": (
            "Run linting/type checking and return structured errors with source context. "
            "Eliminates Bash(ruff) → parse → Read pattern."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "target": {"type": "string", "description": "File or directory to check (relative to project root)"},
                "tools": {
                    "type": "array",
                    "items": {"type": "string", "enum": ["ruff", "mypy"]},
                    "description": "Which checkers to run (default ['ruff'])",
                },
            },
            "required": ["target"],
        },
    },
    "talon_diff": {
        "name": "talon_diff",
        "description": (
            "Show git diff for a file or the whole project. Returns structured diff output "
            "instead of requiring full file re-read to verify edits."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "file": {"type": "string", "description": "Specific file to diff (optional, default: all changes)"},
                "staged": {"type": "boolean", "description": "Show staged changes only (default false)"},
            },
        },
    },
    "talon_deps": {
        "name": "talon_deps",
        "description": (
            "Find all files that import or depend on a module/file. Eliminates multiple "
            "Grep('from X import') → Grep('import X') calls."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "target": {"type": "string", "description": "Module or file path to find dependents of"},
                "direction": {
                    "type": "string",
                    "enum": ["importers", "imports"],
                    "description": "'importers' = who imports this (default), 'imports' = what this imports",
                },
            },
            "required": ["target"],
        },
    },
}


async def _handle_talon_grep(
    arguments: dict[str, Any], start: float
) -> list[TextContent]:
    """Search codebase with context — replaces Grep → N×Read pattern."""
    import re as _re

    pattern = arguments.get("pattern", "")
    if not pattern:
        return [TextContent(type="text", text="Missing required parameter: pattern.")]

    context_lines = min(arguments.get("context", 3), 10)
    glob_filter = arguments.get("glob", "")
    max_files = min(arguments.get("max_files", 5), 10)
    max_matches_per_file = min(arguments.get("max_matches", 3), 10)

    project = Path(_project_path) if _project_path else Path.cwd()

    # Use ripgrep for speed (fallback to grep)
    cmd = ["rg", "--json", "-n", f"-C{context_lines}", "--max-count", str(max_matches_per_file)]
    if glob_filter:
        cmd += ["--glob", glob_filter]
    cmd += [pattern, str(project)]

    try:
        result = subprocess.run(
            cmd, capture_output=True, text=True, timeout=15,
            cwd=str(project),
        )
    except FileNotFoundError:
        # rg not available, fallback to grep
        cmd = ["grep", "-rn", f"-C{context_lines}", "-m", str(max_matches_per_file)]
        if glob_filter:
            cmd += ["--include", glob_filter]
        cmd += [pattern, str(project)]
        try:
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=15)
        except (FileNotFoundError, subprocess.TimeoutExpired):
            return [TextContent(type="text", text="ERROR: Neither rg nor grep available.")]
    except subprocess.TimeoutExpired:
        return [TextContent(type="text", text=f"TIMEOUT: Search exceeded 15s for pattern: {pattern}")]

    # Parse rg --json output into structured results
    import json

    file_matches: dict[str, list[str]] = {}
    current_file = ""

    if result.stdout.startswith("{"):
        # JSON mode (rg --json)
        for line in result.stdout.splitlines():
            try:
                entry = json.loads(line)
            except json.JSONDecodeError:
                continue
            if entry.get("type") == "match":
                data = entry["data"]
                fpath = data["path"]["text"]
                # Make relative to project
                try:
                    rel = str(Path(fpath).relative_to(project))
                except ValueError:
                    rel = fpath
                lineno = data["line_number"]
                text = data["lines"]["text"].rstrip()
                if rel not in file_matches:
                    file_matches[rel] = []
                file_matches[rel].append(f"{lineno:4d}> {text}")
            elif entry.get("type") == "context":
                data = entry["data"]
                fpath = data["path"]["text"]
                try:
                    rel = str(Path(fpath).relative_to(project))
                except ValueError:
                    rel = fpath
                lineno = data["line_number"]
                text = data["lines"]["text"].rstrip()
                if rel not in file_matches:
                    file_matches[rel] = []
                file_matches[rel].append(f"{lineno}│{text}")
    else:
        # Plain grep output: file:line:content
        for line in result.stdout.splitlines():
            m = _re.match(r"(.+?):(\d+)([:-])(.*)", line)
            if m:
                fpath, lineno_str, sep, text = m.groups()
                try:
                    rel = str(Path(fpath).relative_to(project))
                except ValueError:
                    rel = fpath
                if rel not in file_matches:
                    file_matches[rel] = []
                marker = ">" if sep == ":" else " "
                file_matches[rel].append(f"{int(lineno_str):4d}{marker} {text.rstrip()}")

    if not file_matches:
        return [TextContent(type="text", text=f"No matches for: {pattern}")]

    # Format output, capped at max_files
    sections: list[str] = []
    for fpath in list(file_matches.keys())[:max_files]:
        lines = file_matches[fpath]
        sections.append(f"--- {fpath} ---\n" + "\n".join(lines))

    total_files = len(file_matches)
    shown = min(total_files, max_files)
    response = "\n\n".join(sections)
    tokens_est = len(response) // 4

    extra = f" (+{total_files - shown} more files)" if total_files > shown else ""
    return [TextContent(type="text", text=f"{response}\n\n[{shown} files{extra}, ~{tokens_est} tokens]")]


async def _handle_talon_test_for(
    arguments: dict[str, Any], start: float
) -> list[TextContent]:
    """Find tests covering a source file/function — replaces Grep+Glob+Read pattern."""
    file_path = arguments.get("file", "")
    symbol = arguments.get("symbol", "")
    include_bodies = arguments.get("include_bodies", True)

    if not file_path:
        return [TextContent(type="text", text="Missing required parameter: file.")]

    project = Path(_project_path) if _project_path else Path.cwd()

    # Strategy 1: Convention-based test file discovery
    # src/auth.py → tests/test_auth.py, test_auth.py, tests/unit/test_auth.py
    file_stem = Path(file_path).stem
    file_name = Path(file_path).name

    # Build candidate test file patterns
    candidates = [
        f"**/test_{file_stem}.py",
        f"**/test_{file_stem}s.py",
        f"**/{file_stem}_test.py",
        f"**/tests/test_{file_stem}.py",
        f"**/tests/unit/test_{file_stem}.py",
    ]

    found_files: list[Path] = []
    for pattern in candidates:
        for f in project.glob(pattern):
            if f not in found_files and f.is_file():
                found_files.append(f)

    # Strategy 2: Graph-based coverage lookup (if available)
    graph_tests: list[str] = []
    if _graph_client and symbol:
        try:
            coverage = _graph_client.query(
                "FOR e IN talon_tests "
                "FILTER e._to LIKE @pattern "
                "RETURN e._from",
                bind_vars={"pattern": f"%{symbol}%"},
            )
            graph_tests = [str(r) for r in coverage] if coverage else []
        except Exception:
            pass  # Graph not available, convention-only

    # Strategy 3: Grep for test functions referencing the symbol
    symbol_tests: list[tuple[str, int, str]] = []
    if symbol and _memory_store:
        # Search for test functions that reference this symbol
        for tf in found_files[:5]:
            try:
                rel = str(tf.relative_to(project))
            except ValueError:
                rel = str(tf)
            lines_data = _memory_store.get_file_lines(rel)
            if not lines_data:
                try:
                    lines_data = tf.read_text().splitlines()
                except (OSError, UnicodeDecodeError):
                    continue
            for i, line in enumerate(lines_data, 1):
                if symbol in line and ("def test_" in line or "async def test_" in line):
                    symbol_tests.append((rel, i, line.strip()))

    if not found_files and not graph_tests:
        return [TextContent(type="text", text=f"No tests found for: {file_path}" + (f"::{symbol}" if symbol else ""))]

    # Build response
    sections: list[str] = []

    # Test files found
    for tf in found_files[:5]:
        try:
            rel = str(tf.relative_to(project))
        except ValueError:
            rel = str(tf)

        # Find test function names in the file
        test_funcs: list[tuple[str, int, int]] = []
        if _memory_store:
            syms = _memory_store.get_file_symbols(rel)
            if syms:
                test_funcs = [(s["name"], s["line_start"], s.get("line_end", s["line_start"] + 10))
                              for s in syms if s["name"].startswith("test_")]

        if not test_funcs:
            # Fallback: scan file for def test_ lines
            try:
                file_lines = tf.read_text().splitlines()
                for i, line in enumerate(file_lines, 1):
                    if line.strip().startswith("def test_") or line.strip().startswith("async def test_"):
                        func_name = line.strip().split("(")[0].replace("def ", "").replace("async ", "")
                        test_funcs.append((func_name, i, i + 15))
            except (OSError, UnicodeDecodeError):
                pass

        header = f"--- {rel} ({len(test_funcs)} test functions)"
        func_lines: list[str] = []

        for fname, ls, le in test_funcs[:10]:
            relevance = " *" if symbol and symbol.lower() in fname.lower() else ""
            func_lines.append(f"  {fname} (line {ls}){relevance}")

            # Include body if requested and symbol matches
            if include_bodies and symbol and symbol.lower() in fname.lower():
                if _memory_store:
                    src = _memory_store.get_lines(rel, ls, min(le, ls + 20))
                    if src:
                        numbered = [f"    {ls + j}│{sl.rstrip()}" for j, sl in enumerate(src)]
                        func_lines.append("\n".join(numbered))
                else:
                    body_lines = _read_file_lines(project, rel, ls, min(le, ls + 20))
                    if body_lines:
                        numbered = [f"    {ls + j}│{sl.rstrip()}" for j, sl in enumerate(body_lines)]
                        func_lines.append("\n".join(numbered))

        sections.append(header + "\n" + "\n".join(func_lines))

        # X909: Insert point — find last test function's end line
        if test_funcs:
            last_name, _ls, last_end = test_funcs[-1]
            sections.append(f"Insert new test at line {last_end + 1} (after {last_name})")

    response = "\n\n".join(sections)
    tokens_est = len(response) // 4
    return [TextContent(type="text", text=f"{response}\n\n[~{tokens_est} tokens]")]


async def _handle_talon_verify_fix(
    arguments: dict[str, Any], start: float
) -> list[TextContent]:
    """Verify + return fix kit on failure — replaces verify → read → read → fix cycle."""
    import re as _re

    target = arguments.get("target", "")
    scope = arguments.get("scope", "file")

    if not target:
        return [TextContent(type="text", text="Missing required parameter: target.")]

    project = Path(_project_path) if _project_path else Path.cwd()

    # Build and run pytest (same as _handle_verify)
    if scope == "function" and "::" in target:
        file_part, func_part = target.split("::", 1)
        target_path = project / file_part
        if not target_path.exists():
            return [TextContent(type="text", text=f"ERROR: Target not found: {file_part}")]
        cmd = [sys.executable, "-m", "pytest", str(target_path), "-k", func_part, "-v", "--tb=short", "-q"]
    else:
        target_path = project / target
        if not target_path.exists():
            return [TextContent(type="text", text=f"ERROR: Target not found: {target}")]
        cmd = [sys.executable, "-m", "pytest", str(target_path), "-v", "--tb=short", "-q"]

    try:
        result = subprocess.run(cmd, cwd=str(project), timeout=60, capture_output=True, text=True)
    except subprocess.TimeoutExpired:
        return [TextContent(type="text", text=f"TIMEOUT: Tests exceeded 60s limit on {target}")]

    output = result.stdout + result.stderr

    # Parse counts
    passed = failed = errors = 0
    for m in _re.finditer(r"(\d+) passed", output):
        passed = int(m.group(1))
    for m in _re.finditer(r"(\d+) failed", output):
        failed = int(m.group(1))
    for m in _re.finditer(r"(\d+) error", output):
        errors = int(m.group(1))

    time_match = _re.search(r"in ([\d.]+)s", output)
    elapsed = time_match.group(1) if time_match else "?"

    if failed == 0 and errors == 0 and passed > 0:
        summary = f"PASS: {passed} passed, 0 failed ({elapsed}s)"
        tokens_est = len(summary) // 4
        return [TextContent(type="text", text=f"{summary}\n[~{tokens_est} tokens]")]

    # === FAIL: Build fix kit ===
    parts: list[str] = [f"FAIL: {passed} passed, {failed} failed, {errors} errors ({elapsed}s)"]

    # 1. Traceback section
    short_tb = _re.search(r"(FAILURES.*?)(?:=+ short test summary|$)", output, _re.DOTALL)
    if short_tb:
        tb_text = short_tb.group(1).strip()
        if len(tb_text) > 2000:
            tb_text = tb_text[:2000] + "..."
        parts.append(tb_text)

    # 2. Parse failure locations and categorize as test vs source
    locs = _re.findall(r"(\S+\.py):(\d+)", output)
    test_locs: list[tuple[str, int]] = []
    source_locs: list[tuple[str, int]] = []
    seen: set[str] = set()

    for fpath, lineno_str in locs:
        abs_path = Path(fpath) if Path(fpath).is_absolute() else project / fpath
        try:
            abs_resolved = str(abs_path.resolve())
        except (OSError, ValueError):
            continue
        if not abs_resolved.startswith(str(project)):
            continue

        key = f"{abs_resolved}:{lineno_str}"
        if key in seen:
            continue
        seen.add(key)

        if not abs_path.exists():
            continue

        lineno = int(lineno_str)
        try:
            rel = str(abs_path.relative_to(project))
        except ValueError:
            rel = fpath

        is_test = any(x in rel for x in ["test_", "_test.", "/tests/"])
        if is_test:
            test_locs.append((rel, lineno))
        else:
            source_locs.append((rel, lineno))

    # 3. Test source at failure — show the failing test function
    for rel, lineno in test_locs[:2]:
        full = project / rel
        # Find the enclosing test function
        func_start = lineno
        func_end = lineno + 20
        if _memory_store:
            sym = _memory_store.get_symbol_at(rel, lineno)
            if sym:
                func_start = sym.get("line_start", lineno)
                func_end = sym.get("line_end", lineno + 20)
        src = _read_file_lines(project, rel, func_start, func_end)
        if src:
            numbered = [f"{func_start + i}│{sl.rstrip()}" for i, sl in enumerate(src)]
            parts.append(f"--- TEST: {rel}:{func_start}-{func_end} ---\n" + "\n".join(numbered))

    # 4. Source code under test — show the function being tested
    for rel, lineno in source_locs[:2]:
        func_start = lineno
        func_end = lineno + 20
        if _memory_store:
            sym = _memory_store.get_symbol_at(rel, lineno)
            if sym:
                func_start = sym.get("line_start", lineno)
                func_end = sym.get("line_end", lineno + 30)
        src = _read_file_lines(project, rel, func_start, func_end)
        if src:
            numbered = [f"{func_start + i}│{sl.rstrip()}" for i, sl in enumerate(src)]
            parts.append(f"--- SOURCE: {rel}:{func_start}-{func_end} ---\n" + "\n".join(numbered))

    response = "\n\n".join(parts)
    # Cap total response
    if len(response) > 4000:
        response = response[:4000] + "\n..."
    tokens_est = len(response) // 4
    return [TextContent(type="text", text=f"{response}\n[~{tokens_est} tokens]")]


async def _handle_talon_check(
    arguments: dict[str, Any], start: float
) -> list[TextContent]:
    """Lint/typecheck with structured errors + source context."""
    import re as _re

    target = arguments.get("target", "")
    tools = arguments.get("tools", ["ruff"])

    if not target:
        return [TextContent(type="text", text="Missing required parameter: target.")]

    project = Path(_project_path) if _project_path else Path.cwd()
    target_path = project / target
    if not target_path.exists():
        return [TextContent(type="text", text=f"ERROR: Target not found: {target}")]

    all_issues: list[str] = []

    for tool_name in tools[:2]:  # Max 2 tools
        if tool_name == "ruff":
            cmd = [sys.executable, "-m", "ruff", "check", str(target_path),
                   "--output-format", "text", "--no-fix"]
            try:
                result = subprocess.run(cmd, capture_output=True, text=True, timeout=30, cwd=str(project))
            except (FileNotFoundError, subprocess.TimeoutExpired):
                all_issues.append(f"[ruff] ERROR: ruff not available or timed out")
                continue

            # Parse ruff output: file:line:col: CODE message
            issue_count = 0
            for line in result.stdout.splitlines():
                m = _re.match(r"(.+?):(\d+):(\d+): (\w+) (.+)", line)
                if m and issue_count < 10:
                    fpath, lineno, col, code, msg = m.groups()
                    try:
                        rel = str(Path(fpath).relative_to(project))
                    except ValueError:
                        rel = fpath

                    issue_line = f"  [{code}] {rel}:{lineno}:{col} — {msg}"

                    # Add source context (±1 line)
                    src = _read_file_lines(project, rel, max(1, int(lineno) - 1), int(lineno) + 1)
                    if src:
                        start_ln = max(1, int(lineno) - 1)
                        context = "\n".join(f"    {start_ln + j}│{sl.rstrip()}" for j, sl in enumerate(src))
                        issue_line += f"\n{context}"

                    all_issues.append(issue_line)
                    issue_count += 1

            if issue_count == 0:
                all_issues.append(f"[ruff] CLEAN: no issues in {target}")

        elif tool_name == "mypy":
            cmd = [sys.executable, "-m", "mypy", str(target_path), "--no-color-output",
                   "--no-error-summary", "--show-column-numbers"]
            try:
                result = subprocess.run(cmd, capture_output=True, text=True, timeout=60, cwd=str(project))
            except (FileNotFoundError, subprocess.TimeoutExpired):
                all_issues.append(f"[mypy] ERROR: mypy not available or timed out")
                continue

            issue_count = 0
            for line in result.stdout.splitlines():
                m = _re.match(r"(.+?):(\d+):(\d+): (\w+): (.+)", line)
                if m and issue_count < 10:
                    fpath, lineno, col, severity, msg = m.groups()
                    try:
                        rel = str(Path(fpath).relative_to(project))
                    except ValueError:
                        rel = fpath
                    all_issues.append(f"  [{severity}] {rel}:{lineno}:{col} — {msg}")
                    issue_count += 1

            if issue_count == 0:
                all_issues.append(f"[mypy] CLEAN: no issues in {target}")

    response = "\n".join(all_issues)
    tokens_est = len(response) // 4
    return [TextContent(type="text", text=f"{response}\n[~{tokens_est} tokens]")]


async def _handle_talon_diff(
    arguments: dict[str, Any], start: float
) -> list[TextContent]:
    """Show git diff — replaces re-reading files to verify edits."""
    file_path = arguments.get("file", "")
    staged = arguments.get("staged", False)

    project = Path(_project_path) if _project_path else Path.cwd()

    cmd = ["git", "diff"]
    if staged:
        cmd.append("--staged")
    cmd += ["--stat", "--patch", "--no-color"]
    if file_path:
        cmd += ["--", str(project / file_path)]

    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=15, cwd=str(project))
    except (FileNotFoundError, subprocess.TimeoutExpired):
        return [TextContent(type="text", text="ERROR: git not available or timed out")]

    if not result.stdout.strip():
        label = f" for {file_path}" if file_path else ""
        stage_label = " (staged)" if staged else ""
        return [TextContent(type="text", text=f"No changes{label}{stage_label}.")]

    diff_output = result.stdout
    # Cap output
    if len(diff_output) > 3000:
        diff_output = diff_output[:3000] + "\n... (truncated)"

    tokens_est = len(diff_output) // 4
    return [TextContent(type="text", text=f"{diff_output}\n[~{tokens_est} tokens]")]


async def _handle_talon_deps(
    arguments: dict[str, Any], start: float
) -> list[TextContent]:
    """Find importers/imports of a module — replaces multiple Grep calls."""
    import re as _re

    target = arguments.get("target", "")
    direction = arguments.get("direction", "importers")

    if not target:
        return [TextContent(type="text", text="Missing required parameter: target.")]

    project = Path(_project_path) if _project_path else Path.cwd()

    # Derive module name from file path
    # src/talon/mcp/local_server.py → talon.mcp.local_server
    module_name = target.replace("/", ".").replace("\\", ".")
    if module_name.endswith(".py"):
        module_name = module_name[:-3]
    # Strip common prefixes
    for prefix in ["src.", "backend.src."]:
        if module_name.startswith(prefix):
            module_name = module_name[len(prefix):]

    # Also get the bare file stem for partial matching
    stem = Path(target).stem

    if direction == "importers":
        # Find all files that import this module
        # Patterns: "from X import", "import X", "from X.Y import"
        patterns = [
            f"from\\s+{_re.escape(module_name)}\\s+import",
            f"import\\s+{_re.escape(module_name)}",
            f"from\\s+\\S*{_re.escape(stem)}\\s+import",
        ]
        combined = "|".join(f"({p})" for p in patterns)

        cmd = ["rg", "-l", "--type", "py", combined, str(project)]
        try:
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=15, cwd=str(project))
        except FileNotFoundError:
            cmd = ["grep", "-rl", "--include=*.py", f"import.*{stem}", str(project)]
            try:
                result = subprocess.run(cmd, capture_output=True, text=True, timeout=15)
            except (FileNotFoundError, subprocess.TimeoutExpired):
                return [TextContent(type="text", text="ERROR: Neither rg nor grep available.")]
        except subprocess.TimeoutExpired:
            return [TextContent(type="text", text=f"TIMEOUT: Dependency search exceeded 15s")]

        files = [f.strip() for f in result.stdout.splitlines() if f.strip()]
        if not files:
            return [TextContent(type="text", text=f"No importers found for: {target}")]

        # Format with import lines
        sections: list[str] = []
        for fpath in files[:15]:
            try:
                rel = str(Path(fpath).relative_to(project))
            except ValueError:
                rel = fpath

            # Find the actual import lines
            import_lines: list[str] = []
            try:
                content = Path(fpath).read_text().splitlines()
                for i, line in enumerate(content, 1):
                    if stem in line and ("import" in line):
                        import_lines.append(f"  {i:4d}  {line.strip()}")
            except (OSError, UnicodeDecodeError):
                pass

            if import_lines:
                sections.append(f"{rel}\n" + "\n".join(import_lines[:3]))
            else:
                sections.append(rel)

        response = "\n\n".join(sections)
        tokens_est = len(response) // 4
        return [TextContent(type="text", text=f"Importers of {target} ({len(files)} files):\n\n{response}\n[~{tokens_est} tokens]")]

    else:  # direction == "imports"
        # What does this file import?
        file_full = project / target
        if not file_full.exists():
            return [TextContent(type="text", text=f"ERROR: File not found: {target}")]

        try:
            content = file_full.read_text().splitlines()
        except (OSError, UnicodeDecodeError):
            return [TextContent(type="text", text=f"ERROR: Cannot read: {target}")]

        imports: list[str] = []
        for i, line in enumerate(content, 1):
            stripped = line.strip()
            if stripped.startswith("import ") or stripped.startswith("from "):
                imports.append(f"  {i:4d}  {stripped}")

        if not imports:
            return [TextContent(type="text", text=f"No imports found in: {target}")]

        response = f"Imports in {target} ({len(imports)} statements):\n" + "\n".join(imports)
        tokens_est = len(response) // 4
        return [TextContent(type="text", text=f"{response}\n[~{tokens_est} tokens]")]


# ---------------------------------------------------------------------------
# Server Status (for /talon audit speed)
# ---------------------------------------------------------------------------


def get_status() -> dict[str, Any]:
    """Return server status for audit/debug purposes."""
    status: dict[str, Any] = {
        "version": "v5-phase5",
        "project_id": _project_id,
        "project_path": _project_path,
    }
    if _memory_store:
        status["cache"] = _memory_store.status()
    if _pre_warmer:
        status["pre_warmer"] = _pre_warmer.status()
    if _telemetry:
        status["telemetry"] = {
            "session_id": _telemetry.session_id,
            "failed_count": _telemetry.failed_count,
            "session_mode": _telemetry.session_mode,
            "recent_intents": _telemetry.recent_intents,
        }
    return status


# ---------------------------------------------------------------------------
# Initialization
# ---------------------------------------------------------------------------


async def _initialize(project_path: str, arango_url: str | None = None, project_id_override: str | None = None) -> None:
    """Initialize all components: graph client, memory cache, pre-warmer, contracts."""
    global _memory_store, _graph_client, _telemetry, _pre_warmer
    global _project_id, _project_path, _tool_def, _pt_enabled
    global _nav_budget_cap

    _project_path = project_path
    _project_id = project_id_override if project_id_override else Path(project_path).name

    # Precision tracking (TALON_PRECISION_TRACKING=1)
    _pt_enabled = os.environ.get("TALON_PRECISION_TRACKING", "0") == "1"
    if _pt_enabled:
        logger.info("Precision tracking ENABLED — scope→edit overlap will be logged")

    # Navigation budget gate (TALON_NAV_BUDGET=N, default 0 = disabled)
    _nav_budget_cap = int(os.environ.get("TALON_NAV_BUDGET", "0"))
    if _nav_budget_cap:
        logger.info("Navigation budget gate ENABLED — cap=%d consecutive graph_query+smart_read_batch", _nav_budget_cap)

    logger.info("Initializing talon-local v5 for project: %s", _project_id)

    # 1. Load contracts and build tool definition
    contracts = load_contracts()
    _tool_def = build_graph_query_tool(contracts)
    logger.info("Loaded %d contracts, tool description built", len(contracts))

    # 2. Connect to ArangoDB
    try:
        from talon.db.arango import create_graph

        _graph_client = create_graph()
        _graph_client.connect()
        logger.info("Connected to ArangoDB")
    except Exception as e:
        logger.warning("ArangoDB not available: %s. Running in cache-only mode.", e)
        _graph_client = _FallbackGraph()

    # 3. Build memory cache
    _memory_store = MemoryStore()
    cache_start = time.monotonic()

    # Try seed file first
    seed_path = Path(project_path) / ".talon" / "cache_seed.json"
    if seed_path.exists() and _memory_store.load_from_seed(seed_path):
        logger.info(
            "Cache loaded from seed: %d files, %d symbols in %.1fs",
            _memory_store.file_count,
            _memory_store.symbol_count,
            time.monotonic() - cache_start,
        )
    else:
        # Build from file system
        _memory_store.build(Path(project_path))
        logger.info(
            "Cache built from filesystem: %d files, %d symbols in %.1fs",
            _memory_store.file_count,
            _memory_store.symbol_count,
            time.monotonic() - cache_start,
        )

    # 3b. A3: Graph staleness detection
    _stale_warning: str = ""
    _meta_path = Path(project_path) / ".talon" / "graph_meta.json"
    if _meta_path.exists():
        try:
            import json as _json
            _meta = _json.loads(_meta_path.read_text())
            _current_head = subprocess.check_output(
                ["git", "rev-parse", "HEAD"], cwd=project_path, stderr=subprocess.DEVNULL
            ).decode().strip()
            _indexed_head = _meta.get("git_head", "")
            if _indexed_head and _current_head != _indexed_head:
                _stale_warning = (
                    f"⚠ Graph stale: indexed at {_meta.get('indexed_at', '?')[:10]}"
                    f" (HEAD {_indexed_head[:8]}), current HEAD {_current_head[:8]}."
                    f" Run: talon-index {project_path}"
                )
                logger.warning("Graph stale: %s", _stale_warning)
            else:
                logger.info("Graph fresh: HEAD matches indexed HEAD (%s)", _current_head[:8])
        except Exception:
            pass

    # 4. Initialize pre-warmer and warm hubs
    _pre_warmer = PreWarmer(
        graph=_graph_client,
        memory=_memory_store,
        project_id=_project_id,
    )
    set_pre_warmer(_pre_warmer)
    await _pre_warmer.warm_hubs()
    logger.info("Pre-warmer initialized: %s", _pre_warmer.status())

    # 5. Initialize telemetry (respects TALON_TELEMETRY_ENABLED env var)
    if os.environ.get("TALON_TELEMETRY_ENABLED", "1") != "0":
        _telemetry = TelemetryLogger(
            session_id=f"v5-{_project_id}-{int(time.time())}",
            fallback_path=str(Path.home() / ".talon" / "observations.jsonl"),
        )
        logger.info("Telemetry initialized: session=%s", _telemetry.session_id)
    else:
        logger.info("Telemetry disabled (TALON_TELEMETRY_ENABLED=0)")

    # 5b. B1: Start HealthReporter (fire-and-forget — skipped if no API key)
    global _health_reporter  # noqa: PLW0603
    try:
        from talon.mcp.health_reporter import HealthReporter
        _health_reporter = HealthReporter(
            project_id=_project_id,
            project_path=project_path,
            memory_store=_memory,
            telemetry=_telemetry,
        )
        _health_reporter.start()
    except Exception as _hr_err:
        logger.debug("HealthReporter init error (non-fatal): %s", _hr_err)

    # 6. Initialize concept graph (optional — fail gracefully)
    try:
        from talon.cg.store import ConceptGraphStore
        import yaml as _yaml

        config_path = Path.home() / ".talon" / "config.yaml"
        infra: dict[str, Any] = {}
        if config_path.exists():
            with open(config_path) as _f:
                cfg = _yaml.safe_load(_f) or {}
                infra = cfg.get("infrastructure", {})

        cg_store = ConceptGraphStore(
            db_url=infra.get("arango_url", "http://localhost:8530"),
            db_name=infra.get("arango_database", "talon"),
        )
        set_cg_store(cg_store)
        logger.info("Concept graph initialized")
    except Exception as e:
        logger.info("Concept graph not available: %s (CG intents disabled)", e)


# ---------------------------------------------------------------------------
# Fallback Graph (graceful degradation when ArangoDB unavailable)
# ---------------------------------------------------------------------------


class _FallbackGraph:
    """Minimal graph client that returns empty results.

    Used when ArangoDB is not reachable — allows Layer 1 and Layer 2
    to still serve toc and locate intents.
    """

    async def query(self, aql: str, bind_vars: dict | None = None) -> list[dict]:
        return []

    def connect(self) -> None:
        pass

    def close(self) -> None:
        pass


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------


async def _run_stdio(project_path: str, project_id_override: str | None = None) -> None:
    """Run the MCP server over stdio."""
    await _initialize(project_path, project_id_override=project_id_override)

    logger.info("talon-local v5 ready. Serving graph_query via stdio.")
    async with stdio_server() as (read, write):
        await app.run(read, write, app.create_initialization_options())

    # Cleanup — T0-5: push session trace before closing telemetry
    if _health_reporter is not None:
        try:
            await _health_reporter.push_trace_on_exit()
        except Exception as _trace_err:
            logger.debug("Trace push error (non-fatal): %s", _trace_err)
    if _telemetry:
        await _telemetry.close()
    if _graph_client and hasattr(_graph_client, "close"):
        _graph_client.close()


def _install_skill_once() -> None:
    """Install the /talon SKILL.md to ~/.claude/skills/talon/ if not already present."""
    try:
        import importlib.resources
        skill_dest = Path.home() / ".claude" / "skills" / "talon" / "SKILL.md"
        if skill_dest.exists():
            return
        ref = importlib.resources.files("talon.skills").joinpath("SKILL.md")
        skill_dest.parent.mkdir(parents=True, exist_ok=True)
        skill_dest.write_text(ref.read_text(encoding="utf-8"), encoding="utf-8")
        logger.info("Installed /talon skill → %s", skill_dest)
    except Exception:
        pass  # Non-fatal — server continues without skill


def main() -> None:
    """CLI entry point for talon-local."""
    parser = argparse.ArgumentParser(
        prog="talon-local",
        description="Talon v5 local MCP server (stdio transport)",
    )
    parser.add_argument(
        "--project-path",
        type=str,
        required=True,
        help="Path to the project root",
    )
    parser.add_argument(
        "--project-id",
        type=str,
        default=None,
        help="Override ArangoDB project_id (use when workspace dir name differs from indexed project name)",
    )
    parser.add_argument(
        "--log-level",
        type=str,
        default="WARNING",
        choices=["DEBUG", "INFO", "WARNING", "ERROR"],
        help="Logging level (default: WARNING to keep stdio clean)",
    )

    args = parser.parse_args()

    # Configure logging to stderr (stdio stdout is for MCP protocol)
    logging.basicConfig(
        level=getattr(logging, args.log_level),
        format="%(asctime)s %(name)s %(levelname)s %(message)s",
        stream=sys.stderr,
    )

    _install_skill_once()
    asyncio.run(_run_stdio(args.project_path, project_id_override=args.project_id))


if __name__ == "__main__":
    main()
