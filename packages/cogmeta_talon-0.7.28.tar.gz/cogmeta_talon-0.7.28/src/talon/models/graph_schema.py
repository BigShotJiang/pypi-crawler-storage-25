"""ArangoDB graph schema for Talon structural code graph.

Defines vertex/edge collections, named graph, indexes, and Pydantic models.
Implements: AC-01, AC-02, AC-03 (F01 Graph Indexer)
Implements: S3-1 temporal validity edges (valid_until, last_seen, recency scoring)
"""

from __future__ import annotations

import hashlib
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from typing import Any

from pydantic import BaseModel, Field


# =============================================================================
# Temporal Validity Constants
# =============================================================================

# Default staleness window: edges not re-confirmed within this period are stale
STALENESS_WINDOW_DAYS = 90

# Default validity extension: how far into the future to set valid_until on re-index
VALIDITY_EXTENSION_DAYS = 90


# =============================================================================
# Collection Names
# =============================================================================

# Vertex collections
COLLECTION_FILES = "talon_files"
COLLECTION_MODULES = "talon_modules"
COLLECTION_CLASSES = "talon_classes"
COLLECTION_FUNCTIONS = "talon_functions"
COLLECTION_IMPORTS = "talon_imports"
COLLECTION_PARAMETERS = "talon_parameters"
COLLECTION_HOTSPOTS = "talon_hotspots"
COLLECTION_TEST_RESULTS = "talon_test_results"
COLLECTION_CONTRACTS = "talon_contracts"
COLLECTION_META = "talon_meta"

# Edge collections
EDGE_CONTAINS = "talon_contains"
EDGE_CALLS = "talon_calls"
EDGE_IMPORTS_EDGE = "talon_imports_edge"
EDGE_INHERITS = "talon_inherits"
EDGE_DEPENDS_ON = "talon_depends_on"
EDGE_CO_CHANGES = "talon_co_changes"
EDGE_TESTS = "talon_tests"
EDGE_CONTRACT_APPLIES = "talon_contract_applies"
EDGE_SIMILAR_FILES = "talon_similar_files"
EDGE_ERROR_FLOWS = "talon_error_flows"
EDGE_DATA_FLOWS = "talon_data_flows"

# Named graph
GRAPH_NAME = "talon_code"

VERTEX_COLLECTIONS: list[str] = [
    COLLECTION_FILES,
    COLLECTION_MODULES,
    COLLECTION_CLASSES,
    COLLECTION_FUNCTIONS,
    COLLECTION_IMPORTS,
    COLLECTION_PARAMETERS,
    COLLECTION_HOTSPOTS,
    COLLECTION_TEST_RESULTS,
    COLLECTION_CONTRACTS,
    COLLECTION_META,
]

EDGE_COLLECTIONS: list[str] = [
    EDGE_CONTAINS,
    EDGE_CALLS,
    EDGE_IMPORTS_EDGE,
    EDGE_INHERITS,
    EDGE_DEPENDS_ON,
    EDGE_CO_CHANGES,
    EDGE_TESTS,
    EDGE_CONTRACT_APPLIES,
    EDGE_SIMILAR_FILES,
    EDGE_ERROR_FLOWS,
    EDGE_DATA_FLOWS,
]


# =============================================================================
# Named Graph Edge Definitions
# =============================================================================

@dataclass
class EdgeDefinition:
    collection: str
    from_vertex_collections: list[str]
    to_vertex_collections: list[str]


GRAPH_EDGE_DEFINITIONS: list[EdgeDefinition] = [
    EdgeDefinition(
        collection=EDGE_CONTAINS,
        from_vertex_collections=[COLLECTION_FILES],
        to_vertex_collections=[COLLECTION_MODULES, COLLECTION_CLASSES, COLLECTION_FUNCTIONS],
    ),
    EdgeDefinition(
        collection=EDGE_CALLS,
        from_vertex_collections=[COLLECTION_FUNCTIONS],
        to_vertex_collections=[COLLECTION_FUNCTIONS],
    ),
    EdgeDefinition(
        collection=EDGE_IMPORTS_EDGE,
        from_vertex_collections=[COLLECTION_MODULES],
        to_vertex_collections=[COLLECTION_MODULES],
    ),
    EdgeDefinition(
        collection=EDGE_INHERITS,
        from_vertex_collections=[COLLECTION_CLASSES],
        to_vertex_collections=[COLLECTION_CLASSES],
    ),
    EdgeDefinition(
        collection=EDGE_DEPENDS_ON,
        from_vertex_collections=[COLLECTION_FILES],
        to_vertex_collections=[COLLECTION_FILES],
    ),
    EdgeDefinition(
        collection=EDGE_CO_CHANGES,
        from_vertex_collections=[COLLECTION_FILES],
        to_vertex_collections=[COLLECTION_FILES],
    ),
    EdgeDefinition(
        collection=EDGE_TESTS,
        from_vertex_collections=[COLLECTION_FUNCTIONS],
        to_vertex_collections=[COLLECTION_FUNCTIONS],
    ),
    EdgeDefinition(
        collection=EDGE_CONTRACT_APPLIES,
        from_vertex_collections=[COLLECTION_CONTRACTS],
        to_vertex_collections=[COLLECTION_FILES],
    ),
    EdgeDefinition(
        collection=EDGE_SIMILAR_FILES,
        from_vertex_collections=[COLLECTION_FILES],
        to_vertex_collections=[COLLECTION_FILES],
    ),
    EdgeDefinition(
        collection=EDGE_ERROR_FLOWS,
        from_vertex_collections=[COLLECTION_FUNCTIONS],
        to_vertex_collections=[COLLECTION_FUNCTIONS],
    ),
    EdgeDefinition(
        collection=EDGE_DATA_FLOWS,
        from_vertex_collections=[COLLECTION_FUNCTIONS],
        to_vertex_collections=[COLLECTION_FUNCTIONS],
    ),
]


# =============================================================================
# Index Specifications
# =============================================================================

@dataclass
class IndexSpec:
    collection: str
    fields: list[str]
    unique: bool = False
    sparse: bool = False
    name: str = ""


INDEXES: list[IndexSpec] = [
    # Files
    IndexSpec(COLLECTION_FILES, ["project_id"], name="idx_files_project"),
    IndexSpec(COLLECTION_FILES, ["project_id", "path"], unique=True, name="idx_files_project_path"),
    IndexSpec(COLLECTION_FILES, ["language"], name="idx_files_language"),
    # Modules
    IndexSpec(COLLECTION_MODULES, ["project_id"], name="idx_modules_project"),
    IndexSpec(COLLECTION_MODULES, ["name"], name="idx_modules_name"),
    # Classes
    IndexSpec(COLLECTION_CLASSES, ["name"], name="idx_classes_name"),
    IndexSpec(COLLECTION_CLASSES, ["module"], name="idx_classes_module"),
    # Functions
    IndexSpec(COLLECTION_FUNCTIONS, ["project_id"], name="idx_functions_project"),
    IndexSpec(COLLECTION_FUNCTIONS, ["name"], name="idx_functions_name"),
    IndexSpec(COLLECTION_FUNCTIONS, ["module"], name="idx_functions_module"),
    IndexSpec(COLLECTION_FUNCTIONS, ["class_name"], sparse=True, name="idx_functions_class"),
    # Hotspots
    IndexSpec(COLLECTION_HOTSPOTS, ["project_id"], name="idx_hotspots_project"),
    IndexSpec(COLLECTION_HOTSPOTS, ["project_id", "file_path"], unique=True, name="idx_hotspots_project_file"),
    # Contracts
    IndexSpec(COLLECTION_CONTRACTS, ["project_id"], name="idx_contracts_project"),
    IndexSpec(COLLECTION_CONTRACTS, ["pattern_type"], name="idx_contracts_pattern_type"),
    IndexSpec(COLLECTION_CONTRACTS, ["confidence"], name="idx_contracts_confidence"),
    # Meta
    IndexSpec(COLLECTION_META, ["project_id"], unique=True, name="idx_meta_project"),
    # Similar files
    IndexSpec(EDGE_SIMILAR_FILES, ["project_id"], name="idx_similar_files_project"),
    IndexSpec(EDGE_SIMILAR_FILES, ["jaccard_score"], name="idx_similar_files_jaccard"),
    # Error flows
    IndexSpec(EDGE_ERROR_FLOWS, ["project_id"], name="idx_error_flows_project"),
    IndexSpec(EDGE_ERROR_FLOWS, ["exception_type"], name="idx_error_flows_exception"),
    # Data flows
    IndexSpec(EDGE_DATA_FLOWS, ["project_id"], name="idx_data_flows_project"),
]


# =============================================================================
# Key Generation
# =============================================================================

def make_key(*parts: str) -> str:
    """Generate a deterministic document key from parts.

    Uses SHA-256 truncated to 32 hex chars for uniqueness.
    """
    raw = ":".join(parts)
    return hashlib.sha256(raw.encode()).hexdigest()[:32]


# =============================================================================
# Pydantic Models — Vertices
# =============================================================================

class BaseNode(BaseModel):
    """Base for all graph vertex documents."""

    key: str = Field(default="", alias="_key")
    project_id: str = ""
    created_at: str = ""
    updated_at: str = ""

    def to_db_dict(self) -> dict[str, Any]:
        data = self.model_dump(by_alias=True, exclude_none=True)
        if not data.get("created_at"):
            data["created_at"] = datetime.utcnow().isoformat()
        if not data.get("updated_at"):
            data["updated_at"] = datetime.utcnow().isoformat()
        return data


class FileNode(BaseNode):
    """Source file vertex."""

    path: str = ""
    language: str = ""
    loc: int = 0
    hash: str = ""
    last_indexed: str = ""
    last_modified: str = ""


class ModuleNode(BaseNode):
    """Python/TypeScript module vertex."""

    name: str = ""
    path: str = ""
    language: str = ""
    is_package: bool = False


class ClassNode(BaseNode):
    """Class definition vertex."""

    name: str = ""
    module: str = ""
    bases: list[str] = Field(default_factory=list)
    decorators: list[str] = Field(default_factory=list)
    docstring: str = ""
    line_start: int = 0
    line_end: int = 0


class FunctionNode(BaseNode):
    """Function/method definition vertex."""

    name: str = ""
    module: str = ""
    class_name: str | None = None
    params: list[str] = Field(default_factory=list)
    return_type: str | None = None
    is_async: bool = False
    is_method: bool = False
    is_static: bool = False
    is_classmethod: bool = False
    is_assignment: bool = False
    decorators: list[str] = Field(default_factory=list)
    docstring: str = ""
    line_start: int = 0
    line_end: int = 0
    complexity: int | None = None
    raises: list[str] = Field(default_factory=list)
    catches: list[str] = Field(default_factory=list)


class ImportNode(BaseNode):
    """Import statement vertex."""

    source_module: str = ""
    target_module: str = ""
    imported_names: list[str] = Field(default_factory=list)
    is_relative: bool = False
    line_number: int = 0


# =============================================================================
# Pydantic Models — Edges
# =============================================================================

class BaseEdge(BaseModel):
    """Base for all graph edge documents.

    Temporal validity fields (S3-1):
    - last_seen: ISO timestamp of when this edge was last confirmed by an index run.
    - valid_until: ISO timestamp after which this edge is considered stale.
      None means the edge never expires (legacy behavior).
    """

    from_id: str = Field(default="", alias="_from")
    to_id: str = Field(default="", alias="_to")
    project_id: str = ""
    created_at: str = ""
    last_seen: str = ""
    valid_until: str | None = None

    def to_db_dict(self) -> dict[str, Any]:
        data = self.model_dump(by_alias=True, exclude_none=True)
        now = datetime.now(timezone.utc)
        if not data.get("created_at"):
            data["created_at"] = now.isoformat()
        if not data.get("last_seen"):
            data["last_seen"] = now.isoformat()
        if "valid_until" not in data or data.get("valid_until") is None:
            data["valid_until"] = (now + timedelta(days=VALIDITY_EXTENSION_DAYS)).isoformat()
        return data


class ContainsEdge(BaseEdge):
    """File → Module/Class/Function containment."""

    entity_type: str = ""


class CallsEdge(BaseEdge):
    """Function → Function call edge."""

    call_count: int = 1
    line_number: int | None = None


class ImportsEdge(BaseEdge):
    """Module → Module import dependency edge."""

    imported_names: list[str] = Field(default_factory=list)
    is_relative: bool = False


class InheritsEdge(BaseEdge):
    """Class → Class inheritance edge."""

    order: int = 0


class DependsOnEdge(BaseEdge):
    """File → File dependency edge."""

    import_count: int = 0
    call_count: int = 0


class CoChangeEdge(BaseEdge):
    """File → File co-change edge with temporal data."""

    co_change_count: int = 0
    total_changes_a: int = 0
    total_changes_b: int = 0
    correlation: float = 0.0
    last_co_change: str = ""


class TestEdge(BaseEdge):
    """Test result → Function coverage edge."""

    pass


class ContractNode(BaseNode):
    """Mined fix-commit contract rule vertex.

    Implements: S4-1 — each contract is a "problem → solution" pattern
    extracted from git fix-commit history.
    """

    pattern_type: str = ""
    category: str = ""
    description: str = ""
    problem_code: str = ""
    solution_code: str = ""
    explanation: str = ""
    commit_hashes: list[str] = Field(default_factory=list)
    file_paths: list[str] = Field(default_factory=list)
    occurrences: int = 1
    confidence: float = 0.0
    first_seen: str = ""
    last_seen: str = ""


class ContractAppliesEdge(BaseEdge):
    """Contract → File edge indicating which files a rule applies to.

    Implements: S4-1 — links mined contract rules to the files where the
    pattern was observed, enabling contract retrieval during context delivery.
    """

    relevance: float = 1.0


class SimilarFilesEdge(BaseEdge):
    """File -> File similarity edge (E9a).

    Jaccard overlap on shared talon_depends_on targets. Stored persistently
    during indexing. Only edges with jaccard >= 0.3 and shared_imports >= 2.
    """

    jaccard_score: float = 0.0
    shared_imports: int = 0
    total_imports_a: int = 0
    total_imports_b: int = 0


class ErrorFlowEdge(BaseEdge):
    """Function -> Function error propagation edge (E9b).

    Tracks raise/catch chains across call boundaries.
    """

    exception_type: str = ""
    is_handled: bool = False
    propagation_depth: int = 1
    raise_line: int = 0
    catch_line: int = 0


class DataFlowEdge(BaseEdge):
    """Function -> Function data flow edge (E9c).

    Tracks parameter passing across call boundaries (one hop only).
    """

    variable: str = ""
    source_type: str = ""  # "parameter", "return", "attribute"
    direction: str = "forward"  # "forward" = caller passes to callee
    through_param: str = ""


# =============================================================================
# Temporal Validity Utilities
# =============================================================================


def compute_recency_score(last_changed: str | None, now: datetime | None = None) -> float:
    """Compute recency score from a last-changed timestamp.

    Formula: 1.0 / (1 + days_since_last_change)
    - Changed today: ~1.0
    - Changed 1 day ago: 0.5
    - Changed 7 days ago: ~0.125
    - Changed 30 days ago: ~0.032
    - Changed 90 days ago: ~0.011
    - Never changed / no data: 0.0

    Args:
        last_changed: ISO timestamp string of last change.
        now: Reference datetime (defaults to UTC now).

    Returns:
        Recency score between 0.0 and 1.0.
    """
    if not last_changed:
        return 0.0

    if now is None:
        now = datetime.now(timezone.utc)

    try:
        # Parse ISO date, strip timezone if present for compat
        dt_str = last_changed.strip()
        if "T" in dt_str:
            # ISO format
            parts = dt_str.replace("+00:00", "").replace("Z", "")
            dt = datetime.fromisoformat(parts).replace(tzinfo=timezone.utc)
        else:
            # Git date format: "2024-01-15 10:30:00 +0000"
            date_part = dt_str.rsplit(" ", 1)[0]
            dt = datetime.strptime(date_part, "%Y-%m-%d %H:%M:%S").replace(tzinfo=timezone.utc)

        days_since = max(0, (now - dt).total_seconds() / 86400)
        return round(1.0 / (1.0 + days_since), 4)
    except (ValueError, TypeError):
        return 0.0


def is_edge_valid(valid_until: str | None, now: datetime | None = None) -> bool:
    """Check if an edge is still valid (not stale).

    Args:
        valid_until: ISO timestamp string, or None (never expires).
        now: Reference datetime (defaults to UTC now).

    Returns:
        True if the edge is still valid.
    """
    if valid_until is None or valid_until == "":
        return True  # No expiry set — always valid (legacy edges)

    if now is None:
        now = datetime.now(timezone.utc)

    try:
        dt_str = valid_until.strip().replace("+00:00", "").replace("Z", "")
        dt = datetime.fromisoformat(dt_str).replace(tzinfo=timezone.utc)
        return now <= dt
    except (ValueError, TypeError):
        return True  # Can't parse — assume valid
