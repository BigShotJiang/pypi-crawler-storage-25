"""Pre-warmer for the talon v5 response cache.

Uses dependency graph (talon_depends_on) and co-change data (talon_co_changes)
to proactively warm the response cache with TOC data for files the LLM is
likely to query next.

Three warming strategies:
1. Hub warming — on startup, pre-warm TOC for top-N dependency hubs (PageRank proxy)
2. Co-change warming — after a query, pre-warm co-change partners
3. Neighbor warming — after a toc query, pre-warm direct dependency neighbors

Implements: v5 Phase 3 — §6.5 Graph-Guided Pre-Warming
"""

from __future__ import annotations

import asyncio
import logging
import time
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from talon.cache.memory_store import MemoryStore
    from talon.db.arango import TalonGraph

logger = logging.getLogger(__name__)


class PreWarmer:
    """Manages background cache warming using graph structure."""

    def __init__(
        self,
        graph: Any,
        memory: MemoryStore,
        project_id: str,
        *,
        hub_count: int = 20,
        cochange_count: int = 5,
        neighbor_count: int = 3,
    ) -> None:
        self._graph = graph
        self._memory = memory
        self._project_id = project_id
        self._hub_count = hub_count
        self._cochange_count = cochange_count
        self._neighbor_count = neighbor_count
        self._warmed_files: set[str] = set()
        self._hub_files: list[dict[str, Any]] = []
        self._warming_task: asyncio.Task | None = None
        self._stats = PreWarmerStats()

    # ------------------------------------------------------------------
    # Hub warming (startup)
    # ------------------------------------------------------------------

    async def warm_hubs(self) -> None:
        """Identify and pre-warm hub files (most depended-on).

        Uses inbound degree on talon_depends_on as a PageRank proxy.
        Hub files are the structural backbone — the LLM almost always
        reads them during any task.
        """
        t0 = time.monotonic()

        try:
            self._hub_files = await self._graph.query(
                """FOR f IN talon_files
                   FILTER f.project_id == @pid
                   LET deps_in = LENGTH(
                       FOR d IN 1..1 INBOUND f talon_depends_on RETURN 1
                   )
                   FILTER deps_in > 0
                   SORT deps_in DESC
                   LIMIT @limit
                   RETURN {path: f.path, dependents: deps_in, loc: f.loc}""",
                {"pid": self._project_id, "limit": self._hub_count},
            )
        except Exception as e:
            logger.warning("Hub query failed: %s", e)
            self._hub_files = []
            return

        if not self._hub_files:
            logger.info("No dependency hubs found for project %s", self._project_id)
            return

        # Ensure hub files are in the memory cache (they should be already
        # from build(), but this confirms Layer 1 is ready)
        warmed = 0
        for hub in self._hub_files:
            path = hub.get("path", "")
            if path and self._memory.get_file_loc(path) > 0:
                self._warmed_files.add(path)
                warmed += 1

        elapsed = (time.monotonic() - t0) * 1000
        self._stats.hub_files_identified = len(self._hub_files)
        self._stats.hub_warm_ms = elapsed

        logger.info(
            "Pre-warmer: %d hub files identified, %d in cache (%.1fms). Top: %s",
            len(self._hub_files),
            warmed,
            elapsed,
            ", ".join(h["path"].split("/")[-1] for h in self._hub_files[:5]),
        )

    # ------------------------------------------------------------------
    # Co-change warming (after query)
    # ------------------------------------------------------------------

    async def warm_cochange_partners(self, file_path: str) -> list[str]:
        """Pre-warm files that frequently co-change with the queried file.

        Called after a toc or locate query to anticipate the next query.
        Returns list of warmed partner paths.
        """
        if file_path in self._warmed_files:
            return []

        self._warmed_files.add(file_path)

        try:
            partners = await self._graph.query(
                """FOR f IN talon_files
                   FILTER f.path == @path AND f.project_id == @pid
                   FOR partner, edge IN 1..1 ANY f talon_co_changes
                   FILTER edge.project_id == @pid
                   SORT edge.correlation DESC
                   LIMIT @limit
                   RETURN {path: partner.path, correlation: edge.correlation}""",
                {
                    "path": file_path,
                    "pid": self._project_id,
                    "limit": self._cochange_count,
                },
            )
        except Exception:
            return []

        warmed: list[str] = []
        for p in partners:
            partner_path = p.get("path", "")
            if partner_path and partner_path not in self._warmed_files:
                if self._memory.get_file_loc(partner_path) > 0:
                    self._warmed_files.add(partner_path)
                    warmed.append(partner_path)
                    self._stats.cochange_warms += 1

        if warmed:
            logger.debug(
                "Pre-warmed %d co-change partners for %s: %s",
                len(warmed),
                file_path,
                ", ".join(warmed),
            )

        return warmed

    # ------------------------------------------------------------------
    # Neighbor warming (after toc query)
    # ------------------------------------------------------------------

    async def warm_neighbors(self, file_path: str) -> list[str]:
        """Pre-warm direct dependency neighbors of a file.

        Both files this file imports from and files that import this file.
        """
        try:
            neighbors = await self._graph.query(
                """FOR f IN talon_files
                   FILTER f.path == @path AND f.project_id == @pid
                   FOR neighbor IN 1..1 ANY f talon_depends_on
                   LIMIT @limit
                   RETURN DISTINCT neighbor.path""",
                {
                    "path": file_path,
                    "pid": self._project_id,
                    "limit": self._neighbor_count,
                },
            )
        except Exception:
            return []

        warmed: list[str] = []
        for path in neighbors:
            if path and path not in self._warmed_files:
                if self._memory.get_file_loc(path) > 0:
                    self._warmed_files.add(path)
                    warmed.append(path)
                    self._stats.neighbor_warms += 1

        return warmed

    # ------------------------------------------------------------------
    # Combined post-query warming
    # ------------------------------------------------------------------

    async def on_query(self, file_path: str) -> None:
        """Fire-and-forget warming after a query. Non-blocking."""
        try:
            await asyncio.gather(
                self.warm_cochange_partners(file_path),
                self.warm_neighbors(file_path),
            )
        except Exception as e:
            logger.debug("Post-query warming error: %s", e)

    def on_query_fire_and_forget(self, file_path: str) -> None:
        """Schedule post-query warming as a background task."""
        try:
            loop = asyncio.get_running_loop()
            self._warming_task = loop.create_task(self.on_query(file_path))
        except RuntimeError:
            pass  # No event loop — skip warming

    # ------------------------------------------------------------------
    # Hub ranking for file ordering
    # ------------------------------------------------------------------

    def get_hub_ranking(self) -> list[dict[str, Any]]:
        """Return hub files sorted by dependent count.

        Used by toc intent when target is a directory — serves
        a ranked file list so the LLM knows where to start.
        """
        return list(self._hub_files)

    def is_hub(self, file_path: str) -> bool:
        """Check if a file is a dependency hub."""
        return any(h.get("path") == file_path for h in self._hub_files)

    # ------------------------------------------------------------------
    # Status
    # ------------------------------------------------------------------

    def status(self) -> dict[str, Any]:
        """Return pre-warmer status for audit/debug."""
        return {
            "hub_files": len(self._hub_files),
            "warmed_files": len(self._warmed_files),
            "stats": {
                "hub_files_identified": self._stats.hub_files_identified,
                "hub_warm_ms": round(self._stats.hub_warm_ms, 1),
                "cochange_warms": self._stats.cochange_warms,
                "neighbor_warms": self._stats.neighbor_warms,
            },
        }


class PreWarmerStats:
    """Counters for pre-warming activity."""

    def __init__(self) -> None:
        self.hub_files_identified: int = 0
        self.hub_warm_ms: float = 0
        self.cochange_warms: int = 0
        self.neighbor_warms: int = 0
