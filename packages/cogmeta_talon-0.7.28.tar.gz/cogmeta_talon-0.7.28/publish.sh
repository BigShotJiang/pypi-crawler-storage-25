#!/usr/bin/env bash
# Publish a talon client wheel to the private PEP 503 index on api.cogmeta.ai
#
# Usage: ./publish.sh           (builds + publishes current version)
#        ./publish.sh 0.6.0     (set version, build, publish)
set -e

cd "$(dirname "$0")"

VERSION="${1:-$(python3 -c 'from src.talon import __version__; print(__version__)')}"
WHL="talon-${VERSION}-py3-none-any.whl"

# ── Set version if specified ──────────────────────────────────────────────────
if [ -n "$1" ]; then
  sed -i "s/^version = .*/version = \"$VERSION\"/" pyproject.toml
  sed -i "s/^__version__ = .*/__version__ = \"$VERSION\"/" src/talon/__init__.py
  echo "Version set to $VERSION"
fi

# ── Build ─────────────────────────────────────────────────────────────────────
python3 -m build -w
echo "Built dist/$WHL"

# ── Deploy to nginx ───────────────────────────────────────────────────────────
WEB_POD=$(kubectl get pod -n talon -l app=talon-cloud-web -o jsonpath='{.items[0].metadata.name}')

# Upload wheel to PEP 503 index
kubectl cp "dist/$WHL" "talon/$WEB_POD:/usr/share/nginx/html/simple/talon/$WHL"

# Also keep a copy at downloads/talon-latest.whl for legacy install scripts
kubectl cp "dist/$WHL" "talon/$WEB_POD:/usr/share/nginx/html/downloads/talon-latest.whl"

# Update LATEST version file
echo -n "$VERSION" | kubectl exec -n talon "$WEB_POD" -i -- tee /usr/share/nginx/html/downloads/LATEST > /dev/null

# Update PEP 503 index page
kubectl exec -n talon "$WEB_POD" -- sh -c "cat > /usr/share/nginx/html/simple/talon/index.html << EOF
<!DOCTYPE html>
<html><body>
<a href=\"$WHL\">$WHL</a>
</body></html>
EOF"

# Update K8s configmap + restart cloud API so it picks up the new env
kubectl patch configmap talon-cloud-config -n talon --type merge -p "{\"data\":{\"TALON_LATEST_VERSION\":\"$VERSION\"}}"
kubectl rollout restart deployment talon-cloud-api -n talon
kubectl rollout status deployment talon-cloud-api -n talon --timeout=60s

echo ""
echo "Published talon $VERSION"
echo "  Index:  https://api.cogmeta.ai/simple/talon/"
echo "  Install: pip install talon --index-url https://api.cogmeta.ai/simple/"
echo "  Upgrade: talon upgrade"
