"""Core integration-test utilities for validating aggregation results.

Usage
-----
The :class:`AggregationTestHarness` is the main entry point.  Domain-specific
test modules (``tests/domains/test_lc.py``, etc.) instantiate it and call
:meth:`~AggregationTestHarness.run_domain` to get a :class:`ComparisonReport`.

How comparisons work
--------------------
1. **Load** the full domain CSV (source rows + existing aggregate rows).
2. **Identify** "expected aggregates" = rows whose area code belongs to a
   known group (area >= 5000, or the China-351 group code).
3. **Run** the engine on the full dataset.  The engine internally deletes
   existing aggregate rows and recomputes them from the source data.
4. **Extract** actual aggregates from the engine output using the same
   aggregate-code filter.
5. **Compare** expected vs. actual:
   - *Coverage*: which expected rows appear in the actual output?
   - *Precision*: are :attr:`Value` numbers within tolerance?
   - *Flag accuracy*: do :attr:`Flag` strings match?
   - *Extra rows*: does the engine produce rows not present in expected?

Columns intentionally *not* compared
--------------------------------------
- ``LoadDate`` - the engine always writes the current timestamp.
- ``Note`` - set to NULL by the aggregator.
- ``DissFlagInt`` / ``DissFlagExt`` - set to NULL by the aggregator.
"""

from __future__ import annotations

import csv
import json
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Dict, List, Optional, Set

from pyspark.sql import DataFrame, SparkSession
from pyspark.sql import functions as F

from fao_agg.core.engine import AggregationEngine
from fao_calc.core.engine import CalculationEngine


# ---------------------------------------------------------------------------
# Result data structure
# ---------------------------------------------------------------------------


@dataclass
class ComparisonReport:
    """Aggregation comparison metrics for one domain run."""

    domain_code: str

    # Row counts
    total_expected: int = 0  # aggregate rows in original data
    total_actual: int = 0    # aggregate rows produced by engine
    matched_rows: int = 0    # key present in both expected and actual
    missing_rows: int = 0    # in expected but absent from actual
    extra_rows: int = 0      # in actual but absent from expected

    # Value comparison (among matched rows)
    value_matched: int = 0
    value_mismatched: int = 0

    # Flag comparison (among matched rows)
    flag_matched: int = 0
    flag_mismatched: int = 0

    # Collected mismatch sample (up to N rows each)
    missing_sample: List[dict] = field(default_factory=list)
    extra_sample: List[dict] = field(default_factory=list)
    value_mismatch_sample: List[dict] = field(default_factory=list)
    flag_mismatch_sample: List[dict] = field(default_factory=list)

    # ---------------------------------------------------------------------------
    # Derived metrics
    # ---------------------------------------------------------------------------

    @property
    def coverage_pct(self) -> float:
        """Fraction of expected rows found in actual output (0-100)."""
        return 100.0 * self.matched_rows / max(1, self.total_expected)

    @property
    def value_precision_pct(self) -> float:
        """Fraction of matched rows where Value is within tolerance (0-100)."""
        return 100.0 * self.value_matched / max(1, self.matched_rows)

    @property
    def flag_accuracy_pct(self) -> float:
        """Fraction of matched rows where Flag is identical (0-100)."""
        return 100.0 * self.flag_matched / max(1, self.matched_rows)

    def passed(
        self,
        min_coverage: float = 99.0,
        min_precision: float = 99.0,
        min_flag_accuracy: float = 99.0,
        max_extra: int = 0,
    ) -> bool:
        return (
            self.coverage_pct >= min_coverage
            and self.value_precision_pct >= min_precision
            and self.flag_accuracy_pct >= min_flag_accuracy
            and self.extra_rows <= max_extra
        )

    def summary(self) -> str:
        lines = [
            f"=== {self.domain_code} Aggregation Test Report ===",
            f"  Expected aggregates  : {self.total_expected:,}",
            f"  Actual aggregates    : {self.total_actual:,}",
            f"  Matched rows         : {self.matched_rows:,}",
            f"  Missing rows         : {self.missing_rows:,}",
            f"  Extra rows           : {self.extra_rows:,}",
            f"  Coverage             : {self.coverage_pct:.2f}%",
            f"  Value mismatches     : {self.value_mismatched:,}  "
            f"({self.value_precision_pct:.2f}% precise)",
            f"  Flag mismatches      : {self.flag_mismatched:,}  "
            f"({self.flag_accuracy_pct:.2f}% accurate)",
        ]
        return "\n".join(lines)


# ---------------------------------------------------------------------------
# Test harness
# ---------------------------------------------------------------------------


class AggregationTestHarness:
    """Run the full aggregation pipeline for a domain and compare output.

    Parameters
    ----------
    spark:
        Active SparkSession.
    repo_root:
        Path to the repository root (contains ``data/`` and ``configs/``).
    value_rtol:
        Relative tolerance for Value comparison (default 0.1%).
    value_atol:
        Absolute tolerance for Value comparison (for near-zero values).
    sample_size:
        Max number of mismatch rows to collect for inspection.
    """

    def __init__(
        self,
        spark: SparkSession,
        repo_root: Path,
        value_rtol: float = 1e-3,
        value_atol: float = 1e-4,
        sample_size: int = 20,
    ) -> None:
        self.spark = spark
        self.repo_root = Path(repo_root)
        self.value_rtol = value_rtol
        self.value_atol = value_atol
        self.sample_size = sample_size

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def run_domain(
        self,
        domain_code: str,
        additional_datasets: Optional[Dict[str, str]] = None,
        export_dir: Optional[Path] = None,
        restrict_expected_to: Optional[Dict[str, List[str]]] = None,
        calculations_config: Optional[str] = None,
        calc_additional_datasets: Optional[Dict[str, str]] = None,
    ) -> ComparisonReport:
        """Run the engine for *domain_code* and return a :class:`ComparisonReport`.

        Parameters
        ----------
        domain_code:
            FAO domain code (e.g. ``"LC"``, ``"FDI"``).  Must correspond to:
            - ``data/domains/{domain_code}/Data{domain_code}.csv``
            - ``configs/domains/{domain_code}/data_mapping_*.json``
            - ``configs/domains/{domain_code}/aggregation.json``
        additional_datasets:
            Optional mapping of ``{domain_code: path}`` for cross-domain
            AggJoin denominators (e.g. ``{"MK": "data/domains/MK/DataMK.csv"}``).
        export_dir:
            If given, write mismatch CSVs to this directory.
        calculations_config:
            Optional path to a calculations JSON file.  When provided, the
            :class:`CalculationEngine` is run on the aggregation output and
            its results are merged back before the comparison step.
        calc_additional_datasets:
            Optional mapping of ``{domain_code: path}`` for cross-domain
            calculation denominators.  Loaded into the CalculationEngine only.
        """
        config_dir = self.repo_root / "configs" / "domains" / domain_code

        # Resolve data_mapping (find the first json matching data_mapping_*.json)
        dm_candidates = list(config_dir.glob("data_mapping_*.json"))
        if not dm_candidates:
            raise FileNotFoundError(
                f"No data_mapping_*.json found in {config_dir}"
            )
        data_mapping_path = dm_candidates[0]
        aggregation_path = config_dir / "aggregation.json"

        # Initialise engine
        engine = AggregationEngine(
            data_mapping=str(data_mapping_path),
            aggregation_config=str(aggregation_path),
            spark=self.spark,
            config_base_dir=config_dir,
        )

        # Load original data
        data_path = (
            self.repo_root / "data" / "domains" / domain_code
            / f"Data{domain_code}.csv"
        )
        original_df = engine._adapter.load(data_path, self.spark, engine.data_mapping)
        original_df = engine._normalize_schema(original_df)

        # Build filter condition that identifies aggregate rows (works for all domains:
        # standard area aggregation, non-area dims like recipientarea/purpose, China 351)
        agg_filter = self._build_agg_filter(engine)

        # Separate expected aggregates from the original data.
        # This is the *reference set*: rows that the SQL procedure produced.
        expected_df = (
            original_df.filter(agg_filter)
            if agg_filter is not None
            else original_df.filter(F.lit(False))
        )

        # Optionally restrict the expected set to a subset of dimension values.
        # Use this for domains where the reference data includes rows produced by
        # procedures not implemented here (e.g. usp_VarCalc ratio indicators in OEA).
        if restrict_expected_to:
            for dim_name, codes in restrict_expected_to.items():
                dim = engine.data_mapping.get_dimension(dim_name)
                if dim:
                    expected_df = expected_df.filter(F.col(dim.column).isin(codes))

        expected_df.cache()

        # Load additional datasets into the engine (for cross-domain AggJoin)
        if additional_datasets:
            for ds_code, ds_path in additional_datasets.items():
                engine.load_additional_dataset(ds_code, path=ds_path)

        # Run the pipeline on the FULL original data
        engine.load_data(dataframe=original_df).aggregate()
        result_df = engine.get_results()

        # Optionally run calculations on the aggregated output
        if calculations_config is not None:
            calc_engine = CalculationEngine(
                data_mapping=str(data_mapping_path),
                calculations=calculations_config,
                spark=self.spark,
                groups_config=engine.groups_config,
            )
            # Select only columns the calculator produces (dims + value +
            # flag + note + load_date) to avoid schema mismatch during the
            # internal union inside calculate().
            cols = engine.data_mapping.columns
            calc_cols = [d.column for d in engine.data_mapping.dimensions]
            calc_cols += [cols.value, cols.flag]
            for opt in (cols.note, cols.load_date):
                if opt and opt in result_df.columns:
                    calc_cols.append(opt)
            calc_engine.load_data(dataframe=result_df.select(*calc_cols))
            # Load additional datasets for calculations
            if calc_additional_datasets:
                for ds_code, ds_path in calc_additional_datasets.items():
                    ds_df = self.spark.read.csv(ds_path, header=True, inferSchema=True)
                    calc_engine.additional_datasets[ds_code] = ds_df
            calc_engine.calculate()
            calc_new = calc_engine.get_new_calculations()
            if calc_new is not None and calc_new.count() > 0:
                # Align schemas: add missing columns from result_df to calc output
                for col_name in result_df.columns:
                    if col_name not in calc_new.columns:
                        calc_new = calc_new.withColumn(col_name, F.lit(None))
                # Select in same column order and union
                calc_new = calc_new.select(*result_df.columns)
                result_df = result_df.union(calc_new)

        # Extract actual aggregates using a *reference-driven* filter:
        # Only consider engine output for group codes that actually appear in the
        # reference data.  This prevents base_groups codes not used by this domain's
        # SQL procedure from inflating "extra rows".
        actual_filter = self._build_actual_filter_from_expected(engine, expected_df)
        actual_df = (
            result_df.filter(actual_filter)
            if actual_filter is not None
            else result_df.filter(F.lit(False))
        )

        expected_df.unpersist()

        # Build and return comparison report
        dim_cols = [d.column for d in engine.data_mapping.dimensions]
        val_col = engine.data_mapping.columns.value
        flag_col = engine.data_mapping.columns.flag

        report = self._compare(
            domain_code=domain_code,
            expected=expected_df,
            actual=actual_df,
            key_cols=dim_cols,
            val_col=val_col,
            flag_col=flag_col,
        )

        if export_dir:
            self._export_mismatches(report, Path(export_dir), domain_code)

        return report

    # ------------------------------------------------------------------
    # Helpers - engine configuration
    # ------------------------------------------------------------------

    def _build_agg_filter(self, engine: AggregationEngine):
        """Build a Spark column condition that selects aggregate rows.

        Covers all domain types:
        - Standard aggregation: rows whose aggregated-dimension value matches
          a known group code (e.g. area groups for ``agg_dimensions=["area"]``).
        - Multi-dimension domains (EA): recipientarea OR purpose aggregate codes.
        - China-351-only domains (BE, OER): area code == "351".

        Returns ``None`` when no aggregate filter can be built (empty domain).
        """
        conditions = []

        # Collect agg_dimensions that are actually run (from iterations)
        agg_dim_types: Set[str] = set()
        for it in engine.aggregation_cfg.iterations:
            for dim_type in it.agg_dimensions:
                agg_dim_types.add(dim_type)

        for dim_type in agg_dim_types:
            codes = {
                str(g.code)
                for g in engine.groups_config.groups.get(dim_type, [])
            }
            if codes:
                dim = engine.data_mapping.get_dimension(dim_type)
                if dim:
                    conditions.append(
                        F.col(dim.column).cast("string").isin(list(codes))
                    )

        # China 351 is always an area-dimension aggregate
        if engine._china351_processor is not None:
            china_code = str(engine._china351_processor.config.group_code)
            area_dim = engine.data_mapping.get_dimension("area")
            if area_dim:
                conditions.append(
                    F.col(area_dim.column).cast("string") == china_code
                )

        if not conditions:
            return None

        combined = conditions[0]
        for c in conditions[1:]:
            combined = combined | c
        return combined

    def _build_actual_filter_from_expected(
        self, engine: AggregationEngine, expected_df: DataFrame
    ):
        """Build a filter that restricts actual output to codes present in *expected_df*.

        ``base_groups.json`` is a global groups file that contains aggregate codes
        from **all** FAO domains.  Each domain's SQL procedure only computed a
        subset of those groups (its ``vDomainVarGroupVar`` rows).  Filtering the
        engine's actual output by ``base_groups`` would count rows for non-domain
        groups as false "extra" rows.

        This helper collects the unique aggregate-dimension values that actually
        appear in the reference data and limits the ``actual`` side of the
        comparison to those codes.  Rows produced by the engine for groups not
        in the reference are silently ignored (not counted as extra or missing).
        """
        conditions = []

        agg_dim_types: Set[str] = set()
        for it in engine.aggregation_cfg.iterations:
            for dim_type in it.agg_dimensions:
                agg_dim_types.add(dim_type)

        for dim_type in agg_dim_types:
            dim = engine.data_mapping.get_dimension(dim_type)
            if not dim:
                continue
            config_codes = {
                str(g.code)
                for g in engine.groups_config.groups.get(dim_type, [])
            }
            # Only include codes that exist in the reference data AND in the config
            ref_codes = {
                row[dim.column]
                for row in expected_df.select(dim.column).distinct().collect()
                if row[dim.column] is not None
            }
            relevant = ref_codes & config_codes
            if relevant:
                conditions.append(
                    F.col(dim.column).isin(list(relevant))
                )

        # China 351: include unconditionally when configured (always in reference)
        if engine._china351_processor is not None:
            china_code = str(engine._china351_processor.config.group_code)
            area_dim = engine.data_mapping.get_dimension("area")
            if area_dim:
                conditions.append(
                    F.col(area_dim.column) == china_code
                )

        if not conditions:
            return None

        combined = conditions[0]
        for c in conditions[1:]:
            combined = combined | c
        return combined

    # ------------------------------------------------------------------
    # Helpers - comparison
    # ------------------------------------------------------------------

    def _compare(
        self,
        domain_code: str,
        expected: DataFrame,
        actual: DataFrame,
        key_cols: List[str],
        val_col: str,
        flag_col: str,
    ) -> ComparisonReport:
        """Join expected vs actual and produce a :class:`ComparisonReport`."""
        report = ComparisonReport(domain_code=domain_code)

        # Normalise key columns: cast to string, coalesce NULL → ""
        exp = self._normalise_keys(
            expected.select(*key_cols, val_col, flag_col), key_cols
        ).withColumnRenamed(val_col, "_exp_val").withColumnRenamed(flag_col, "_exp_flag")

        act = self._normalise_keys(
            actual.select(*key_cols, val_col, flag_col), key_cols
        ).withColumnRenamed(val_col, "_act_val").withColumnRenamed(flag_col, "_act_flag")

        # Full outer join on all dimension columns
        joined = exp.join(act, on=key_cols, how="full")
        joined.cache()

        report.total_expected = expected.count()
        report.total_actual = actual.count()

        # Classify rows.
        # "matched" includes both the normal case (both values non-null) and the
        # both-null case where the engine correctly produced NULL for a NULL reference
        # row (e.g. China 351 sum of all-NULL members).
        matched = joined.filter(
            (F.col("_exp_val").isNotNull() & F.col("_act_val").isNotNull())
            | (F.col("_exp_val").isNull() & F.col("_act_val").isNull())
        )
        missing = joined.filter(F.col("_act_val").isNull() & F.col("_exp_val").isNotNull())
        extra   = joined.filter(F.col("_exp_val").isNull() & F.col("_act_val").isNotNull())

        report.matched_rows = matched.count()
        report.missing_rows = missing.count()
        report.extra_rows   = extra.count()

        # Value precision: |actual - expected| <= atol + rtol * |expected|
        # Both-null rows are counted as "value ok" (no value to compare).
        rtol = self.value_rtol
        atol = self.value_atol
        value_ok_expr = (
            (F.col("_exp_val").isNull() & F.col("_act_val").isNull())
            | (
                F.col("_exp_val").isNotNull()
                & F.col("_act_val").isNotNull()
                & (
                    F.abs(F.col("_act_val") - F.col("_exp_val"))
                    <= atol + rtol * F.abs(F.col("_exp_val"))
                )
            )
        )
        value_counts = (
            matched
            .withColumn("_value_ok", value_ok_expr)
            .groupBy("_value_ok")
            .count()
            .collect()
        )
        for row in value_counts:
            if row["_value_ok"]:
                report.value_matched = row["count"]
            else:
                report.value_mismatched = row["count"]

        # Flag accuracy: exact match
        flag_counts = (
            matched
            .withColumn("_flag_ok", F.col("_exp_flag") == F.col("_act_flag"))
            .groupBy("_flag_ok")
            .count()
            .collect()
        )
        for row in flag_counts:
            if row["_flag_ok"]:
                report.flag_matched = row["count"]
            else:
                report.flag_mismatched = row["count"]

        # Collect samples for inspection
        if report.missing_rows > 0:
            report.missing_sample = [
                r.asDict() for r in missing.limit(self.sample_size).collect()
            ]
        if report.extra_rows > 0:
            report.extra_sample = [
                r.asDict() for r in extra.limit(self.sample_size).collect()
            ]
        if report.value_mismatched > 0:
            report.value_mismatch_sample = [
                r.asDict()
                for r in matched.filter(~value_ok_expr).limit(self.sample_size).collect()
            ]
        if report.flag_mismatched > 0:
            report.flag_mismatch_sample = [
                r.asDict()
                for r in matched.filter(
                    F.col("_exp_flag") != F.col("_act_flag")
                ).limit(self.sample_size).collect()
            ]

        joined.unpersist()
        return report

    @staticmethod
    def _normalise_keys(df: DataFrame, key_cols: List[str]) -> DataFrame:
        """Cast key columns to string and replace NULL with '' for join safety."""
        for c in key_cols:
            df = df.withColumn(c, F.coalesce(F.col(c).cast("string"), F.lit("")))
        return df

    # ------------------------------------------------------------------
    # Helpers - export
    # ------------------------------------------------------------------

    def _export_mismatches(
        self, report: ComparisonReport, export_dir: Path, domain_code: str
    ) -> None:
        """Write mismatch samples to CSV files and a metrics JSON under *export_dir*."""
        export_dir.mkdir(parents=True, exist_ok=True)

        # Mismatch CSVs
        datasets = {
            "missing": report.missing_sample,
            "extra": report.extra_sample,
            "value_mismatch": report.value_mismatch_sample,
            "flag_mismatch": report.flag_mismatch_sample,
        }
        for name, rows in datasets.items():
            if not rows:
                continue
            out_path = export_dir / f"{domain_code}_{name}.csv"
            with open(out_path, "w", newline="") as fh:
                writer = csv.DictWriter(fh, fieldnames=list(rows[0].keys()))
                writer.writeheader()
                writer.writerows(rows)

        # Scalar metrics JSON (used by the runner script for report generation)
        metrics = {
            k: v
            for k, v in asdict(report).items()
            if not k.endswith("_sample")
        }
        metrics["coverage_pct"] = report.coverage_pct
        metrics["value_precision_pct"] = report.value_precision_pct
        metrics["flag_accuracy_pct"] = report.flag_accuracy_pct
        metrics_path = export_dir / f"{domain_code}_metrics.json"
        with open(metrics_path, "w") as fh:
            json.dump(metrics, fh, indent=2)


# ---------------------------------------------------------------------------
# Convenience assertion helpers (used directly by test functions)
# ---------------------------------------------------------------------------


def assert_coverage(report: ComparisonReport, min_pct: float = 99.0) -> None:
    """Assert that coverage meets the minimum threshold."""
    assert report.coverage_pct >= min_pct, (
        f"[{report.domain_code}] Coverage {report.coverage_pct:.2f}% < {min_pct}%.\n"
        f"Missing rows ({report.missing_rows}): "
        + (str(report.missing_sample[:3]) if report.missing_sample else "none")
    )


def assert_precision(report: ComparisonReport, min_pct: float = 99.0) -> None:
    """Assert that value precision meets the minimum threshold."""
    assert report.value_precision_pct >= min_pct, (
        f"[{report.domain_code}] Value precision {report.value_precision_pct:.2f}% < {min_pct}%.\n"
        f"Value mismatches ({report.value_mismatched}): "
        + (str(report.value_mismatch_sample[:3]) if report.value_mismatch_sample else "none")
    )


def assert_flag_accuracy(report: ComparisonReport, min_pct: float = 99.0) -> None:
    """Assert that flag accuracy meets the minimum threshold."""
    assert report.flag_accuracy_pct >= min_pct, (
        f"[{report.domain_code}] Flag accuracy {report.flag_accuracy_pct:.2f}% < {min_pct}%.\n"
        f"Flag mismatches ({report.flag_mismatched}): "
        + (str(report.flag_mismatch_sample[:3]) if report.flag_mismatch_sample else "none")
    )


def assert_no_extra_rows(report: ComparisonReport) -> None:
    """Assert that the engine produces no unexpected aggregate rows."""
    assert report.extra_rows == 0, (
        f"[{report.domain_code}] Engine produced {report.extra_rows} unexpected aggregate rows.\n"
        f"Extra rows sample: "
        + (str(report.extra_sample[:3]) if report.extra_sample else "none")
    )
