"""Command-line interface for the FAO indicator calculation engine.

Usage
-----
    fao-calc --data-mapping configs/data_mapping.json \\
             --calculations configs/domains/CS/calculations.json \\
             --data         data/DataCS.csv \\
             --output       output/DataCS_calculated.csv

Exit codes
----------
0 — success
1 — configuration or I/O error
2 — calculation error
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="fao-calc",
        description="Configuration-driven indicator calculations for FAO data.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )

    p.add_argument(
        "--data-mapping", "-m",
        required=True,
        metavar="PATH",
        help="Path to the data mapping JSON (dimensions, column names).",
    )
    p.add_argument(
        "--calculations", "-c",
        required=True,
        metavar="PATH",
        help="Path to the calculations config JSON.",
    )
    p.add_argument(
        "--flag-config",
        required=False,
        metavar="PATH",
        default=None,
        help="Path to an optional flag config JSON.",
    )
    p.add_argument(
        "--data", "-d",
        required=False,
        metavar="PATH",
        help="Path to the input data file. Overrides the path in the data mapping config.",
    )
    p.add_argument(
        "--output", "-o",
        required=True,
        metavar="PATH",
        help="Output path for the calculated data.",
    )
    p.add_argument(
        "--output-format", "-f",
        choices=["csv", "parquet", "delta"],
        default="csv",
        help="Output file format (default: csv).",
    )
    p.add_argument(
        "--output-mode",
        choices=["overwrite", "append", "error", "ignore"],
        default="overwrite",
        help="Spark write mode (default: overwrite).",
    )
    p.add_argument(
        "--additional-data",
        metavar="DATASET_ID=MAPPING_PATH:DATA_PATH",
        action="append",
        default=[],
        help=(
            "Additional dataset for cross-domain calculations. "
            "Format: DATASET_ID=mapping.json:data.csv. May be repeated."
        ),
    )
    p.add_argument(
        "--iterations",
        metavar="N",
        type=int,
        nargs="+",
        default=None,
        help="Run only specific iteration numbers (space-separated). Default: all.",
    )
    p.add_argument(
        "--aggregates-only",
        action="store_true",
        default=False,
        help="Calculate only for aggregate rows.",
    )
    return p


def parse_additional_data(specs: list[str]) -> list[tuple[str, str, str]]:
    """Parse ``DATASET_ID=mapping:data`` strings."""
    result = []
    for spec in specs:
        if "=" not in spec:
            raise argparse.ArgumentTypeError(
                f"Invalid --additional-data value '{spec}'. "
                "Expected format: DATASET_ID=mapping.json:data.csv"
            )
        dataset_id, rest = spec.split("=", 1)
        if ":" not in rest:
            raise argparse.ArgumentTypeError(
                f"Invalid --additional-data value '{spec}'. "
                "Expected format: DATASET_ID=mapping.json:data.csv"
            )
        mapping_path, data_path = rest.split(":", 1)
        result.append((dataset_id.strip(), mapping_path.strip(), data_path.strip()))
    return result


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)

    try:
        from fao_calc.core.engine import CalculationEngine
    except ImportError as exc:
        print(f"ERROR: Could not import fao_calc — {exc}", file=sys.stderr)
        return 1

    try:
        engine = CalculationEngine(
            data_mapping=args.data_mapping,
            calculations=args.calculations,
            flag_config=args.flag_config,
        )
    except Exception as exc:
        print(f"ERROR: Failed to load configuration — {exc}", file=sys.stderr)
        return 1

    try:
        load_kwargs: dict = {}
        if args.data:
            load_kwargs["path"] = args.data
        engine.load_data(**load_kwargs)
    except Exception as exc:
        print(f"ERROR: Failed to load data — {exc}", file=sys.stderr)
        return 1

    try:
        for dataset_id, mapping_path, data_path in parse_additional_data(args.additional_data):
            engine.load_additional_dataset(dataset_id, data_mapping=mapping_path, path=data_path)
    except Exception as exc:
        print(f"ERROR: Failed to load additional dataset — {exc}", file=sys.stderr)
        return 1

    try:
        engine.calculate(
            iterations=args.iterations,
            aggregates_only=args.aggregates_only if args.aggregates_only else None,
        )
    except Exception as exc:
        print(f"ERROR: Calculation failed — {exc}", file=sys.stderr)
        return 2

    try:
        results = engine.get_results()
        if results is None:
            print("ERROR: No results produced.", file=sys.stderr)
            return 2

        fmt = args.output_format
        output_path = args.output
        mode = args.output_mode

        if fmt == "csv":
            engine.write_csv(output_path, mode=mode)
        elif fmt == "parquet":
            engine.write_parquet(output_path, mode=mode)
        elif fmt == "delta":
            engine.write_delta(output_path, mode=mode)

        print(f"Calculation complete. Output written to: {output_path}")
    except Exception as exc:
        print(f"ERROR: Failed to write output — {exc}", file=sys.stderr)
        return 2

    return 0


if __name__ == "__main__":
    sys.exit(main())
