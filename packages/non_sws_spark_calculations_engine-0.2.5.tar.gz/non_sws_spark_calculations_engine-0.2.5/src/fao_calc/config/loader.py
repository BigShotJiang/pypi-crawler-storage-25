"""Configuration file loading and validation for fao_calc."""

from pathlib import Path
from typing import Union

from pydantic import ValidationError

# Re-use shared utilities from fao_common; also re-export them so existing
# callers of fao_calc.config.loader continue to work without changes.
from fao_common.config.loader import (  # noqa: F401
    ConfigurationError,
    load_data_mapping,
    load_json_config,
    resolve_config_dict as _resolve_config_dict,
)
from fao_common.config.schema import DataMappingConfig  # noqa: F401

from .schema import CalculationConfig, FlagConfig, MultiDatasetConfig


def load_calculations(config: Union[str, Path, dict]) -> CalculationConfig:
    """Load and validate a CalculationConfig.

    Args:
        config: File path, JSON string, or dict with calculation config.

    Returns:
        Validated CalculationConfig.

    Raises:
        ConfigurationError: If the configuration is invalid.
    """
    config_dict = _resolve_config_dict(config)
    try:
        return CalculationConfig(**config_dict)
    except ValidationError as e:
        raise ConfigurationError(f"Invalid calculation configuration: {e}") from e


def load_flag_config(config: Union[str, Path, dict]) -> FlagConfig:
    """Load and validate a FlagConfig.

    Args:
        config: File path, JSON string, or dict with flag config.

    Returns:
        Validated FlagConfig.

    Raises:
        ConfigurationError: If the configuration is invalid.
    """
    config_dict = _resolve_config_dict(config)
    try:
        return FlagConfig(**config_dict)
    except ValidationError as e:
        raise ConfigurationError(f"Invalid flag configuration: {e}") from e


def load_multi_dataset_config(config: Union[str, Path, dict]) -> MultiDatasetConfig:
    """Load and validate a MultiDatasetConfig.

    Args:
        config: File path, JSON string, or dict with multi-dataset config.

    Returns:
        Validated MultiDatasetConfig.

    Raises:
        ConfigurationError: If the configuration is invalid.
    """
    config_dict = _resolve_config_dict(config)
    try:
        return MultiDatasetConfig(**config_dict)
    except ValidationError as e:
        raise ConfigurationError(f"Invalid multi-dataset configuration: {e}") from e


def validate_config_compatibility(
    data_mapping: DataMappingConfig, calculations: CalculationConfig
) -> None:
    """Validate that a CalculationConfig is compatible with the DataMappingConfig.

    Args:
        data_mapping: Data mapping configuration.
        calculations: Calculation configuration.

    Raises:
        ConfigurationError: If the configurations are incompatible.
    """
    dimension_names = {dim.name for dim in data_mapping.dimensions}
    dimension_columns = {dim.column for dim in data_mapping.dimensions}

    for calc in calculations.calculations:
        for dim_name in calc.result.keys():
            if dim_name not in dimension_names:
                raise ConfigurationError(
                    f"Calculation '{calc.id}': result dimension "
                    f"'{dim_name}' not found in data mapping"
                )

        for num in calc.get_numerator_filters():
            if num.dimension not in dimension_names:
                raise ConfigurationError(
                    f"Calculation '{calc.id}': numerator dimension "
                    f"'{num.dimension}' not found in data mapping"
                )

        den_filters = calc.get_denominator_filters()
        if den_filters:
            for var_ref in den_filters:
                if var_ref.dimension not in dimension_names:
                    raise ConfigurationError(
                        f"Calculation '{calc.id}': denominator dimension "
                        f"'{var_ref.dimension}' not found in data mapping"
                    )

        if calc.filters:
            for filter_dim in calc.filters.keys():
                if filter_dim not in dimension_names and filter_dim not in dimension_columns:
                    raise ConfigurationError(
                        f"Calculation '{calc.id}': filter dimension "
                        f"'{filter_dim}' not found in data mapping"
                    )
