"""Configuration module for FAO Indicator Calculator."""

from .loader import (
    ConfigurationError,
    load_calculations,
    load_data_mapping,
    load_flag_config,
    load_json_config,
    load_multi_dataset_config,
    validate_config_compatibility,
)
from .schema import (
    CalculationConfig,
    CalculationDefinition,
    CalculationType,
    ColumnMapping,
    DataMappingConfig,
    DatasetDefinition,
    DataSourceConfig,
    DenominatorConfig,
    DimensionDefinition,
    FlagConfig,
    FlagPropagationCondition,
    FlagPropagationResult,
    FlagPropagationRule,
    MultiDatasetConfig,
    NumeratorConfig,
    VariableReference,
)

__all__ = [
    # Loader functions
    "load_json_config",
    "load_data_mapping",
    "load_calculations",
    "load_flag_config",
    "load_multi_dataset_config",
    "validate_config_compatibility",
    "ConfigurationError",
    # Schema classes
    "DataSourceConfig",
    "DimensionDefinition",
    "ColumnMapping",
    "DataMappingConfig",
    "VariableReference",
    "NumeratorConfig",
    "DenominatorConfig",
    "CalculationDefinition",
    "CalculationConfig",
    "FlagPropagationRule",
    "FlagConfig",
    "DatasetDefinition",
    "MultiDatasetConfig",
    # Enums
    "CalculationType",
    "FlagPropagationCondition",
    "FlagPropagationResult",
]
