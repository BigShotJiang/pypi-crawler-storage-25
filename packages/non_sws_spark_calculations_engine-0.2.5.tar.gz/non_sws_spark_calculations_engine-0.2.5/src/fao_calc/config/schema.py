"""Configuration schema definitions using Pydantic for validation."""

from enum import Enum
from typing import Any, Dict, List, Optional, Union  # noqa: F401

from pydantic import BaseModel, Field, field_validator, model_validator

# Re-export shared models from fao_common so existing code using
# fao_calc.config.schema continues to work without changes.
from fao_common.config.schema import (  # noqa: F401
    ColumnMapping,
    DataMappingConfig,
    DataSourceConfig,
    DimensionDefinition,
)


class CalculationType(str, Enum):
    """Supported calculation types."""

    RATIO = "ratio"
    GROWTH_RATE = "growth_rate"
    TRANSFORMATION = "transformation"
    CUSTOM = "custom"


class FlagPropagationCondition(str, Enum):
    """Flag propagation conditions."""

    BOTH_SAME = "both_same"
    BOTH_DIFFERENT = "both_different"
    ANY = "any"


class FlagPropagationResult(str, Enum):
    """Flag propagation results."""

    PRESERVE = "preserve"
    SET_FLAG = "set_flag"


class VariableReference(BaseModel):
    """Reference to a variable/indicator in a specific dimension."""

    dimension: str = Field(description="Dimension name (must match dimension definition)")
    value: Union[str, List[str]] = Field(
        description="Value(s) to match in the dimension column"
    )
    dataset: Optional[str] = Field(
        None,
        description="Dataset identifier if from different dataset (enables cross-dataset joins)",
    )


class NumeratorConfig(BaseModel):
    """Numerator configuration for calculations."""

    filters: List[VariableReference] = Field(
        description="Filters to select numerator data", min_length=1
    )
    multiplier: float = Field(
        default=1.0, description="Multiplier to apply to numerator values"
    )


class DenominatorConfig(BaseModel):
    """Denominator configuration for calculations."""

    filters: List[VariableReference] = Field(
        description="Filters to select denominator data", min_length=1
    )
    dataset: Optional[str] = Field(
        None, description="Dataset identifier if denominator comes from different dataset"
    )


class CalculationDefinition(BaseModel):
    """Definition of a single calculation."""

    id: str = Field(description="Unique calculation identifier")
    name: str = Field(description="Human-readable calculation name")
    type: CalculationType = Field(description="Type of calculation")
    numerator: Union[NumeratorConfig, List[VariableReference]] = Field(
        description="Numerator configuration or variable references (for backward compatibility)"
    )
    denominator: Optional[Union[DenominatorConfig, List[VariableReference]]] = Field(
        None, description="Denominator configuration or variable references (for backward compatibility)"
    )
    result: Dict[str, Union[str, int]] = Field(
        description="Result dimension values (e.g., {'element': '6161', 'item': '22030'})"
    )
    time_offset: Optional[int] = Field(
        None,
        description="Time period offset for growth rate calculations (e.g., -1 for previous year)",
    )
    filters: Optional[Dict[str, List[str]]] = Field(
        None, description="Additional filters to apply (dimension -> list of values)"
    )
    iteration: int = Field(default=1, description="Calculation iteration order", ge=1)
    include_note: bool = Field(
        default=False, description="Whether to copy note from numerator to result"
    )
    custom_formula: Optional[str] = Field(
        None, description="Custom Spark SQL expression (for custom type)"
    )

    # Backward compatibility fields (deprecated)
    result_variable: Optional[VariableReference] = Field(
        None, description="DEPRECATED: Use 'result' instead"
    )
    additional_variables: Optional[List[Dict[str, Union[str, int]]]] = Field(
        None, description="DEPRECATED: Use 'result' instead"
    )
    multiplier: Optional[float] = Field(
        None, description="DEPRECATED: Use 'numerator.multiplier' instead"
    )
    denominator_dataset: Optional[str] = Field(
        None, description="DEPRECATED: Use 'denominator.dataset' instead"
    )

    @model_validator(mode="before")
    @classmethod
    def handle_backward_compatibility(cls, data: Dict[str, Any]) -> Dict[str, Any]:
        """Handle backward compatibility with old configuration format."""
        # If using old format, convert to new format
        if "result_variable" in data and "result" not in data:
            result = {}

            # Add result_variable to result
            result_var = data["result_variable"]
            if isinstance(result_var, dict):
                result[result_var["dimension"]] = result_var["value"]

            # Add additional_variables to result
            if "additional_variables" in data:
                for add_var in data["additional_variables"]:
                    if isinstance(add_var, dict):
                        result[add_var["dimension"]] = add_var["value"]

            data["result"] = result

        # Convert old numerator format to new
        if "numerator" in data and isinstance(data["numerator"], list):
            # Check if it's already in new format (has "filters" key)
            if not (len(data["numerator"]) > 0 and isinstance(data["numerator"][0], dict) and "filters" in data["numerator"][0]):
                # Old format: list of VariableReference dicts
                multiplier = data.pop("multiplier", 1.0)
                data["numerator"] = {
                    "filters": data["numerator"],
                    "multiplier": multiplier
                }

        # Convert old denominator format to new
        if "denominator" in data and isinstance(data["denominator"], list):
            # Check if it's already in new format
            if not (len(data["denominator"]) > 0 and isinstance(data["denominator"][0], dict) and "filters" in data["denominator"][0]):
                # Old format: list of VariableReference dicts
                dataset = data.pop("denominator_dataset", None)
                data["denominator"] = {
                    "filters": data["denominator"],
                    "dataset": dataset
                }

        return data

    @model_validator(mode="after")
    def validate_calculation_type(self) -> "CalculationDefinition":
        """Validate calculation type requirements."""
        if self.type == CalculationType.RATIO:
            if not self.denominator:
                raise ValueError("Ratio calculations require denominator")
        elif self.type == CalculationType.GROWTH_RATE:
            if self.time_offset is None:
                raise ValueError("Growth rate calculations require time_offset")
        elif self.type == CalculationType.CUSTOM:
            if not self.custom_formula:
                raise ValueError("Custom calculations require custom_formula")
        return self

    def get_numerator_filters(self) -> List[VariableReference]:
        """Get numerator filters in consistent format."""
        if isinstance(self.numerator, NumeratorConfig):
            return self.numerator.filters
        return self.numerator

    def get_numerator_multiplier(self) -> float:
        """Get numerator multiplier."""
        if isinstance(self.numerator, NumeratorConfig):
            return self.numerator.multiplier
        return self.multiplier or 1.0

    def get_denominator_filters(self) -> Optional[List[VariableReference]]:
        """Get denominator filters in consistent format."""
        if self.denominator is None:
            return None
        if isinstance(self.denominator, DenominatorConfig):
            return self.denominator.filters
        return self.denominator

    def get_denominator_dataset(self) -> Optional[str]:
        """Get denominator dataset."""
        if isinstance(self.denominator, DenominatorConfig):
            return self.denominator.dataset
        return self.denominator_dataset


class FlagPropagationRule(BaseModel):
    """Rule for flag propagation."""

    condition: FlagPropagationCondition = Field(description="When this rule applies")
    valid_flags: Optional[List[str]] = Field(
        None, description="Flags this rule applies to (None = all)"
    )
    result: Union[FlagPropagationResult, str] = Field(
        description="Result flag (preserve or specific flag)"
    )


class FlagConfig(BaseModel):
    """Flag handling configuration."""

    default_calculated_flag: str = Field(
        default="E", description="Default flag for calculated values"
    )
    propagation_rules: List[FlagPropagationRule] = Field(
        default_factory=list, description="Flag propagation rules (applied in order)"
    )
    dissemination_enabled: bool = Field(
        default=False, description="Whether to handle dissemination flags"
    )
    aggregate_enabled: bool = Field(default=False, description="Whether to handle aggregate flags")


class CalculationConfig(BaseModel):
    """Complete calculation configuration."""

    calculations: List[CalculationDefinition] = Field(
        description="List of calculations to perform", min_length=1
    )
    flag_config: Optional[FlagConfig] = Field(
        None,
        description=(
            "Inline flag configuration.  When provided, this takes precedence "
            "over a separate flag_config parameter passed to the engine."
        ),
    )
    aggregates_only: bool = Field(
        default=False, description="Only calculate for aggregate dimensions"
    )
    aggregate_dimension: Optional[str] = Field(
        None,
        description=(
            "Dimension name whose aggregate group codes identify aggregate rows "
            "(e.g. 'area').  Required when aggregates_only is True."
        ),
    )
    aggregate_codes: Optional[List[str]] = Field(
        None,
        description=(
            "Explicit list of aggregate group codes for the aggregate_dimension "
            "(e.g. ['5100', '5300', '351', ...]).  Required when aggregates_only is True."
        ),
    )

    @field_validator("calculations")
    @classmethod
    def validate_unique_ids(cls, v: List[CalculationDefinition]) -> List[CalculationDefinition]:
        """Validate that calculation IDs are unique."""
        ids = [calc.id for calc in v]
        if len(ids) != len(set(ids)):
            raise ValueError("Calculation IDs must be unique")
        return v


class DatasetDefinition(BaseModel):
    """Definition of a dataset for multi-dataset calculations."""

    id: str = Field(description="Unique dataset identifier")
    name: str = Field(description="Human-readable dataset name")
    mapping: DataMappingConfig = Field(description="Data mapping configuration for this dataset")


class MultiDatasetConfig(BaseModel):
    """Configuration for calculations involving multiple datasets."""

    datasets: List[DatasetDefinition] = Field(description="Dataset definitions", min_length=1)
    primary_dataset: str = Field(
        description="ID of the primary dataset where results will be stored"
    )

    @field_validator("datasets")
    @classmethod
    def validate_unique_dataset_ids(
        cls, v: List[DatasetDefinition]
    ) -> List[DatasetDefinition]:
        """Validate that dataset IDs are unique."""
        ids = [ds.id for ds in v]
        if len(ids) != len(set(ids)):
            raise ValueError("Dataset IDs must be unique")
        return v

    @model_validator(mode="after")
    def validate_primary_dataset_exists(self) -> "MultiDatasetConfig":
        """Validate that primary_dataset ID exists."""
        dataset_ids = {ds.id for ds in self.datasets}
        if self.primary_dataset not in dataset_ids:
            raise ValueError(f"primary_dataset '{self.primary_dataset}' not found in datasets")
        return self
