"""Main calculation engine."""

from pathlib import Path
from typing import Dict, List, Optional, Union

import logging

from pyspark.sql import DataFrame, SparkSession
from pyspark.sql import functions as F

from fao_common.adapters import load_additional_dataset as _load_additional_dataset
from fao_common.config.schema import SdmxDataSource

logger = logging.getLogger(__name__)

from ..config import (
    CalculationConfig,
    DataMappingConfig,
    FlagConfig,
    load_calculations,
    load_data_mapping,
    load_flag_config,
    validate_config_compatibility,
)
from .calculator import Calculator
from .flag_handler import FlagHandler


class CalculationEngine:
    """Main engine for running statistical calculations."""

    def __init__(
        self,
        data_mapping: Union[str, Path, dict, DataMappingConfig],
        calculations: Union[str, Path, dict, CalculationConfig],
        flag_config: Optional[Union[str, Path, dict, FlagConfig]] = None,
        spark: Optional[SparkSession] = None,
        groups_config=None,
    ):
        """Initialize calculation engine.

        Args:
            data_mapping: DataMappingConfig, dict, file path, or JSON string
            calculations: CalculationConfig, dict, file path, or JSON string
            flag_config: Optional FlagConfig, dict, file path, or JSON string
            spark: Optional SparkSession (will create one if not provided)
        """
        # Load configurations
        if isinstance(data_mapping, DataMappingConfig):
            self.data_mapping = data_mapping
        else:
            self.data_mapping = load_data_mapping(data_mapping)

        if isinstance(calculations, CalculationConfig):
            self.calculations = calculations
        else:
            self.calculations = load_calculations(calculations)

        # Flag config: inline (from calculations JSON) > explicit parameter > default
        if self.calculations.flag_config is not None:
            self.flag_config = self.calculations.flag_config
        elif flag_config is None:
            self.flag_config = FlagConfig()
        elif isinstance(flag_config, FlagConfig):
            self.flag_config = flag_config
        else:
            self.flag_config = load_flag_config(flag_config)

        # Validate configuration compatibility
        validate_config_compatibility(self.data_mapping, self.calculations)

        # Initialize Spark
        self.spark = spark or self._create_spark_session()

        # Initialize components
        self.flag_handler = FlagHandler(self.flag_config)
        self.calculator = Calculator(
            self.data_mapping.dimensions, self.data_mapping.columns, self.flag_handler
        )

        # Groups config — used to derive aggregate codes when aggregates_only=True
        self.groups_config = groups_config

        # Data storage
        self.data: Optional[DataFrame] = None
        self.results: Optional[DataFrame] = None
        self.additional_datasets: Dict[str, DataFrame] = {}

    def _create_spark_session(self) -> SparkSession:
        """Create default Spark session.

        Returns:
            SparkSession
        """
        return (
            SparkSession.builder.appName("FAO Indicator Calculator")
            .config("spark.sql.adaptive.enabled", "true")
            .config("spark.sql.adaptive.coalescePartitions.enabled", "true")
            .getOrCreate()
        )

    def load_data(
        self, path: Optional[Union[str, Path]] = None, dataframe: Optional[DataFrame] = None
    ) -> "CalculationEngine":
        """Load input data.

        Args:
            path: Path to data file (overrides config)
            dataframe: Pre-loaded DataFrame (alternative to path)

        Returns:
            Self for chaining
        """
        if dataframe is not None:
            self.data = dataframe
        elif path is not None:
            self.data = self._load_from_path(Path(path))
        else:
            # Load from config
            self.data = self._load_from_config()

        return self

    def _load_from_path(self, path: Path) -> DataFrame:
        """Load data from path.

        Args:
            path: Path to data file

        Returns:
            Loaded DataFrame
        """
        source_type = self.data_mapping.data_source.type
        options = self.data_mapping.data_source.options or {}

        if source_type == "csv":
            # Set defaults only if not in config (config takes precedence)
            csv_options = options.copy()
            if "header" not in csv_options:
                csv_options["header"] = "true"
            if "inferSchema" not in csv_options:
                csv_options["inferSchema"] = "true"
            return self.spark.read.csv(str(path), **csv_options)
        elif source_type == "parquet":
            return self.spark.read.parquet(str(path), **options)
        elif source_type == "delta":
            return self.spark.read.format("delta").load(str(path), **options)
        else:
            raise ValueError(f"Unsupported data source type: {source_type}")

    def _load_from_config(self) -> DataFrame:
        """Load data from configuration.

        Returns:
            Loaded DataFrame
        """
        if not self.data_mapping.data_source.path:
            raise ValueError("No data path provided in config or load_data()")

        return self._load_from_path(Path(self.data_mapping.data_source.path))

    def load_additional_dataset(
        self,
        dataset_id: str,
        path: Optional[Union[str, Path]] = None,
        dataframe: Optional[DataFrame] = None,
        data_mapping: Optional[Union[str, Path, dict, DataMappingConfig]] = None,
        sdmx_source: Optional[Union[dict, SdmxDataSource]] = None,
    ) -> "CalculationEngine":
        """Load additional dataset for cross-dataset calculations.

        Delegates to :func:`fao_common.adapters.load_additional_dataset` and
        stores the result in :attr:`additional_datasets`.

        Returns:
            Self for chaining.
        """
        self.additional_datasets[dataset_id] = _load_additional_dataset(
            dataset_id=dataset_id,
            spark=self.spark,
            primary_data_mapping=self.data_mapping,
            path=path,
            dataframe=dataframe,
            data_mapping=data_mapping,
            sdmx_source=sdmx_source,
        )
        return self

    # ------------------------------------------------------------------
    # Additional-dataset optimisation (pre-filter + cache)
    # ------------------------------------------------------------------

    def _prepare_additional_datasets(self) -> Dict[str, DataFrame]:
        """Pre-filter and cache additional datasets before the calculation loop.

        Scans every calculation that references an additional dataset and
        collects the union of all dimension filter values it will ever need.
        Each additional dataset is then:

        1. Filtered to only the rows that *any* calculation will actually use.
        2. Cached so Spark doesn't re-read / re-evaluate for each calculation.

        Returns a dict of ``dataset_id -> cached DataFrame`` that should
        replace ``self.additional_datasets`` for the duration of the run.
        The originals are **not** mutated.
        """
        if not self.additional_datasets:
            return {}

        # Collect required filter values per dataset: {dataset_id: {dim_name: {values}}}
        needed: Dict[str, Dict[str, set]] = {}

        for calc in self.calculations.calculations:
            ds_id = calc.get_denominator_dataset()
            if not ds_id or ds_id not in self.additional_datasets:
                continue

            ds_needed = needed.setdefault(ds_id, {})
            for var_ref in (calc.get_denominator_filters() or []):
                vals = ds_needed.setdefault(var_ref.dimension, set())
                if isinstance(var_ref.value, list):
                    vals.update(var_ref.value)
                else:
                    vals.add(var_ref.value)

        # Pre-filter + cache each referenced dataset
        prepared: Dict[str, DataFrame] = {}
        dim_map = {d.name: d for d in self.data_mapping.dimensions}

        for ds_id, df in self.additional_datasets.items():
            filters = needed.get(ds_id)
            if not filters:
                # Dataset loaded but not referenced by any calculation — skip caching
                prepared[ds_id] = df
                continue

            filtered = df
            for dim_name, values in filters.items():
                dim = dim_map.get(dim_name)
                if dim is None:
                    continue
                if len(values) == 1:
                    filtered = filtered.filter(F.col(dim.column) == next(iter(values)))
                else:
                    filtered = filtered.filter(F.col(dim.column).isin(list(values)))

            prepared[ds_id] = filtered.cache()
            logger.info(
                "Additional dataset '%s': pre-filtered to %d dimension filter(s) and cached.",
                ds_id,
                len(filters),
            )

        return prepared

    @staticmethod
    def _unpersist_additional_datasets(prepared: Dict[str, DataFrame]) -> None:
        """Unpersist any cached additional datasets."""
        for df in prepared.values():
            if df.is_cached:
                df.unpersist()

    def calculate(
        self, iterations: Optional[List[int]] = None, aggregates_only: Optional[bool] = None
    ) -> "CalculationEngine":
        """Run calculations.

        Args:
            iterations: Specific iterations to run (defaults to all)
            aggregates_only: Only calculate for aggregates (overrides config)

        Returns:
            Self for chaining
        """
        if self.data is None:
            raise ValueError("No data loaded. Call load_data() first.")

        # Determine which iterations to run
        if iterations is None:
            # Get all unique iterations from calculations
            iterations = sorted(set(calc.iteration for calc in self.calculations.calculations))

        # Determine aggregates_only setting
        agg_only = (
            aggregates_only
            if aggregates_only is not None
            else self.calculations.aggregates_only
        )

        # Normalize data to only include mapped columns
        working_data = self._normalize_data_schema(self.data)

        # Filter data for aggregates if needed
        if agg_only:
            working_data = self._filter_aggregates(working_data)

        # Pre-filter and cache additional datasets
        prepared = self._prepare_additional_datasets()

        try:
            # Process calculations by iteration
            all_results = []
            for iteration in iterations:
                # Get calculations for this iteration
                iter_calcs = [
                    calc for calc in self.calculations.calculations if calc.iteration == iteration
                ]

                # Run each calculation
                for calc in iter_calcs:
                    # Delete existing calculated values
                    working_data = self._delete_calculated_values(working_data, calc)

                    # Run calculation (pass pre-filtered additional datasets)
                    calc_result = self.calculator.calculate(
                        calc, working_data, prepared or self.additional_datasets
                    )

                    # Store result
                    all_results.append(calc_result)

                    # Add result back to working data for next iterations
                    working_data = working_data.union(calc_result)

            # Union all results
            if all_results:
                self.results = all_results[0]
                for result in all_results[1:]:
                    self.results = self.results.union(result)
        finally:
            self._unpersist_additional_datasets(prepared)

        return self

    def _normalize_data_schema(self, data: DataFrame) -> DataFrame:
        """Normalize data to only include mapped columns.

        This ensures calculation results can be unioned with input data.
        If the DataFrame has SDMX column names (AREA, OBS_VALUE, …) instead
        of internal names (Var1Code, Value, …), they are renamed automatically.

        Args:
            data: Input DataFrame

        Returns:
            DataFrame with only mapped columns
        """
        from pyspark.sql.functions import col

        available = set(data.columns)

        # Well-known SDMX aliases for the time dimension
        _TIME_ALIASES = {"TIME_PERIOD", "YEAR"}

        # Build a rename map: SDMX column name → internal column name
        # This handles DataFrames that still have SDMX column names.
        rename_map: Dict[str, str] = {}

        for dim in self.data_mapping.dimensions:
            if dim.column not in available:
                # Try SDMX name variants: explicit sdmx_id, uppercase name, aliases
                candidates = []
                if hasattr(dim, "sdmx_id") and dim.sdmx_id:
                    candidates.append(dim.sdmx_id)
                candidates.append(dim.name.upper())
                if dim.name.lower() == "year":
                    candidates.extend(_TIME_ALIASES)
                for candidate in candidates:
                    if candidate in available:
                        rename_map[candidate] = dim.column
                        break

        # Value column
        value_col = self.data_mapping.columns.value
        if value_col not in available:
            for candidate in ["OBS_VALUE", "UNROUNDED_VALUE"]:
                if candidate in available:
                    rename_map[candidate] = value_col
                    break

        # Flag column
        flag_col = self.data_mapping.columns.flag
        if flag_col and flag_col not in available:
            if "FLAG" in available:
                rename_map["FLAG"] = flag_col

        # Apply renames
        if rename_map:
            for sdmx_name, internal_name in rename_map.items():
                data = data.withColumnRenamed(sdmx_name, internal_name)
            available = set(data.columns)

        # Build list of columns to select
        select_cols = []

        # Add all dimension columns
        for dim in self.data_mapping.dimensions:
            select_cols.append(col(dim.column))

        # Add value, flag, note columns
        select_cols.append(col(self.data_mapping.columns.value))
        if self.data_mapping.columns.flag:
            select_cols.append(col(self.data_mapping.columns.flag))
        if self.data_mapping.columns.note and self.data_mapping.columns.note in available:
            select_cols.append(col(self.data_mapping.columns.note))

        # Add optional columns if they exist in the schema
        if self.data_mapping.columns.load_date and self.data_mapping.columns.load_date in available:
            select_cols.append(col(self.data_mapping.columns.load_date))
        if self.data_mapping.columns.diss_flag_int and self.data_mapping.columns.diss_flag_int in available:
            select_cols.append(col(self.data_mapping.columns.diss_flag_int))
        if self.data_mapping.columns.diss_flag_ext and self.data_mapping.columns.diss_flag_ext in available:
            select_cols.append(col(self.data_mapping.columns.diss_flag_ext))
        if self.data_mapping.columns.agg_flag_int and self.data_mapping.columns.agg_flag_int in available:
            select_cols.append(col(self.data_mapping.columns.agg_flag_int))
        if self.data_mapping.columns.agg_flag_ext and self.data_mapping.columns.agg_flag_ext in available:
            select_cols.append(col(self.data_mapping.columns.agg_flag_ext))

        return data.select(*select_cols)

    def _filter_aggregates(self, data: DataFrame) -> DataFrame:
        """Filter data to only include aggregate rows.

        Aggregate codes are resolved in order of priority:
        1. Explicit ``aggregate_codes`` in the calculation config.
        2. Derived from ``groups_config`` (passed to the engine constructor)
           using the ``aggregate_dimension`` name.

        Args:
            data: Input DataFrame

        Returns:
            Filtered DataFrame
        """
        from pyspark.sql.functions import col

        dim_name = self.calculations.aggregate_dimension
        if not dim_name:
            raise ValueError(
                "aggregates_only=True requires 'aggregate_dimension' in the "
                "calculation config."
            )

        # Resolve aggregate codes
        codes = self.calculations.aggregate_codes
        if not codes and self.groups_config is not None:
            groups = self.groups_config.groups.get(dim_name, [])
            codes = [g.code for g in groups]

        if not codes:
            raise ValueError(
                f"aggregates_only=True but no aggregate codes found for "
                f"dimension '{dim_name}'. Either set 'aggregate_codes' in "
                f"the calculation config or pass groups_config to the engine."
            )

        # Find the column name for the aggregate dimension
        agg_dim = None
        for dim in self.data_mapping.dimensions:
            if dim.name == dim_name:
                agg_dim = dim
                break
        if agg_dim is None:
            raise ValueError(
                f"aggregate_dimension '{dim_name}' not found in data_mapping dimensions."
            )

        return data.filter(col(agg_dim.column).isin(codes))

    def _delete_calculated_values(
        self, data: DataFrame, calculation
    ) -> DataFrame:
        """Delete existing calculated values.

        Implements SQL lines 287-328.

        Args:
            data: Current DataFrame
            calculation: Calculation definition

        Returns:
            DataFrame with calculated values removed
        """
        # Get result assignments
        result_assignments = calculation.result

        # Build filter condition to remove existing calculated values
        # We need to remove rows where ALL result dimensions match (AND condition)
        from pyspark.sql.functions import col, lit
        from pyspark.sql.types import IntegerType, LongType

        # Build a list of conditions - we want to keep rows where ANY dimension doesn't match
        keep_conditions = []

        for dim_name, dim_value in result_assignments.items():
            # Find the dimension definition
            result_dim = None
            for dim in self.data_mapping.dimensions:
                if dim.name == dim_name:
                    result_dim = dim
                    break

            if not result_dim:
                continue

            # Get the column data type
            column_dtype = None
            for field in data.schema.fields:
                if field.name == result_dim.column:
                    column_dtype = field.dataType
                    break

            # Convert value to list if needed
            values = dim_value if isinstance(dim_value, list) else [dim_value]

            # Add condition to keep rows where this dimension doesn't match
            for value in values:
                try:
                    if isinstance(column_dtype, (IntegerType, LongType)):
                        try:
                            int_value = int(value)
                            keep_conditions.append(col(result_dim.column) != lit(int_value))
                        except (ValueError, TypeError):
                            pass
                    else:
                        keep_conditions.append(col(result_dim.column) != lit(value))
                except Exception:
                    pass

        # Apply filter: keep rows where ANY dimension doesn't match
        # (This is equivalent to: delete rows where ALL dimensions match)
        if keep_conditions:
            combined_condition = keep_conditions[0]
            for cond in keep_conditions[1:]:
                combined_condition = combined_condition | cond
            data = data.filter(combined_condition)

        return data

    def get_results(self) -> Optional[DataFrame]:
        """Get calculation results.

        Returns:
            Results DataFrame or None if not calculated yet
        """
        return self.results

    def get_new_calculations(self) -> Optional[DataFrame]:
        """Return only the rows produced by calculations.

        Filters to rows whose dimension values match any calculation's
        ``result`` assignments.

        Returns:
            DataFrame of new calculated rows, or None if not calculated yet.
        """
        if self.results is None:
            return None

        from pyspark.sql import functions as F

        dim_lookup = {d.name: d.column for d in self.data_mapping.dimensions}
        row_conditions = []
        for calc in self.calculations.calculations:
            col_conditions = []
            for dim_name, value in calc.result.items():
                col_name = dim_lookup.get(dim_name)
                if col_name:
                    col_conditions.append(F.col(col_name) == str(value))
            if col_conditions:
                combined = col_conditions[0]
                for c in col_conditions[1:]:
                    combined = combined & c
                row_conditions.append(combined)

        if not row_conditions:
            return self.results.limit(0)

        final = row_conditions[0]
        for r in row_conditions[1:]:
            final = final | r

        return self.results.filter(final)

    def write_csv(
        self, path: Union[str, Path], mode: str = "overwrite", **options
    ) -> "CalculationEngine":
        """Write results to CSV.

        Args:
            path: Output path
            mode: Write mode (overwrite, append, etc.)
            **options: Additional write options

        Returns:
            Self for chaining
        """
        if self.results is None:
            raise ValueError("No results to write. Call calculate() first.")

        self.results.write.csv(str(path), header=True, mode=mode, **options)
        return self

    def write_parquet(
        self, path: Union[str, Path], mode: str = "overwrite", **options
    ) -> "CalculationEngine":
        """Write results to Parquet.

        Args:
            path: Output path
            mode: Write mode (overwrite, append, etc.)
            **options: Additional write options

        Returns:
            Self for chaining
        """
        if self.results is None:
            raise ValueError("No results to write. Call calculate() first.")

        self.results.write.parquet(str(path), mode=mode, **options)
        return self

    def write_delta(
        self, path: Union[str, Path], mode: str = "overwrite", **options
    ) -> "CalculationEngine":
        """Write results to Delta Lake.

        Args:
            path: Output path
            mode: Write mode (overwrite, append, etc.)
            **options: Additional write options

        Returns:
            Self for chaining
        """
        if self.results is None:
            raise ValueError("No results to write. Call calculate() first.")

        self.results.write.format("delta").mode(mode).save(str(path), **options)
        return self

    def show_results(self, n: int = 20, truncate: bool = True) -> "CalculationEngine":
        """Show results in console.

        Args:
            n: Number of rows to show
            truncate: Whether to truncate long values

        Returns:
            Self for chaining
        """
        if self.results is None:
            raise ValueError("No results to show. Call calculate() first.")

        self.results.show(n, truncate)
        return self
