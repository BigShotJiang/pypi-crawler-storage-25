"""Flag propagation and handling logic."""

from typing import List, Optional

from pyspark.sql import Column
from pyspark.sql import functions as F

from ..config.schema import FlagConfig, FlagPropagationCondition, FlagPropagationResult


class FlagHandler:
    """Handles flag propagation logic for calculated values."""

    def __init__(self, config: FlagConfig):
        """Initialize flag handler.

        Args:
            config: Flag configuration
        """
        self.config = config

    def create_flag_expression(
        self, numerator_flag_col: str, denominator_flag_cols: Optional[List[str]] = None
    ) -> Column:
        """Create Spark SQL expression for flag propagation.

        Implements the logic from SQL:
        CASE WHEN d.Flag = d1.Flag
             THEN CASE WHEN d.Flag NOT IN ('A','X') THEN 'E' ELSE d.Flag END
             ELSE 'E' END

        Args:
            numerator_flag_col: Column name for numerator flag
            denominator_flag_cols: Column names for denominator flags (if any)

        Returns:
            Spark Column expression for the result flag
        """
        if not denominator_flag_cols:
            # No denominator - simple transformation always gets default flag
            return F.lit(self.config.default_calculated_flag)

        # For single denominator
        if len(denominator_flag_cols) == 1:
            return self._create_single_denominator_flag(numerator_flag_col, denominator_flag_cols[0])

        # For multiple denominators, check if all flags are the same
        return self._create_multi_denominator_flag(numerator_flag_col, denominator_flag_cols)

    def _create_single_denominator_flag(
        self, numerator_flag: str, denominator_flag: str
    ) -> Column:
        """Create flag expression for single denominator case.

        Args:
            numerator_flag: Numerator flag column name
            denominator_flag: Denominator flag column name

        Returns:
            Flag expression
        """
        num_col = F.col(numerator_flag)
        den_col = F.col(denominator_flag)

        # Apply custom rules first
        result = None
        for rule in self.config.propagation_rules:
            if rule.condition == FlagPropagationCondition.BOTH_SAME:
                # When both flags are the same
                condition = num_col == den_col

                if rule.valid_flags:
                    # Only for specific flags
                    condition = condition & num_col.isin(rule.valid_flags)

                if rule.result == FlagPropagationResult.PRESERVE:
                    # Preserve the flag
                    rule_result = num_col
                else:
                    # Set specific flag
                    rule_result = F.lit(str(rule.result))

                if result is None:
                    result = F.when(condition, rule_result)
                else:
                    result = result.when(condition, rule_result)

            elif rule.condition == FlagPropagationCondition.BOTH_DIFFERENT:
                # When flags are different
                condition = num_col != den_col

                rule_result = F.lit(str(rule.result))

                if result is None:
                    result = F.when(condition, rule_result)
                else:
                    result = result.when(condition, rule_result)

        # Default fallback
        if result is None:
            result = F.lit(self.config.default_calculated_flag)
        else:
            result = result.otherwise(F.lit(self.config.default_calculated_flag))

        return result

    def _create_multi_denominator_flag(
        self, numerator_flag: str, denominator_flags: List[str]
    ) -> Column:
        """Create flag expression for multiple denominators.

        For multiple denominators, we check if all flags match.
        If all match and are in valid_flags, preserve; otherwise use default.

        Args:
            numerator_flag: Numerator flag column name
            denominator_flags: List of denominator flag column names

        Returns:
            Flag expression
        """
        num_col = F.col(numerator_flag)
        den_cols = [F.col(df) for df in denominator_flags]

        # Check if all flags are the same
        all_same = num_col == den_cols[0]
        for den_col in den_cols[1:]:
            all_same = all_same & (num_col == den_col)

        # Apply rules
        result = None
        for rule in self.config.propagation_rules:
            if rule.condition == FlagPropagationCondition.BOTH_SAME:
                condition = all_same

                if rule.valid_flags:
                    condition = condition & num_col.isin(rule.valid_flags)

                if rule.result == FlagPropagationResult.PRESERVE:
                    rule_result = num_col
                else:
                    rule_result = F.lit(str(rule.result))

                if result is None:
                    result = F.when(condition, rule_result)
                else:
                    result = result.when(condition, rule_result)

        # Default fallback
        if result is None:
            result = F.lit(self.config.default_calculated_flag)
        else:
            result = result.otherwise(F.lit(self.config.default_calculated_flag))

        return result

    def create_dissemination_flag_expression(
        self,
        flag_type: str,
        numerator_flag_col: str,
        denominator_flag_cols: Optional[List[str]] = None,
    ) -> Column:
        """Create dissemination flag expression.

        Implements logic from SQL lines 392-393, 488-489:
        CASE WHEN CAST(d.DissFlagInt AS INT) = 0 THEN 0
             ELSE CASE WHEN c.DomainVar_LevelInt = 0 THEN 0
                  ELSE CASE WHEN CAST(d.DissFlagInt AS INT) + CAST(d1.DissFlagInt AS INT) >= 1
                       THEN 1 ELSE 0 END END END

        Args:
            flag_type: 'int' or 'ext'
            numerator_flag_col: Numerator dissemination flag column
            denominator_flag_cols: Denominator dissemination flag columns

        Returns:
            Dissemination flag expression
        """
        if not self.config.dissemination_enabled:
            return F.lit(None)

        num_flag = F.col(numerator_flag_col).cast("int")

        if not denominator_flag_cols:
            return num_flag

        # If any flag is set, result is set
        den_flags = [F.col(df).cast("int") for df in denominator_flag_cols]
        all_flags = [num_flag] + den_flags

        # Sum all flags and check if >= 1
        flag_sum = all_flags[0]
        for flag in all_flags[1:]:
            flag_sum = flag_sum + flag

        return F.when(num_flag == 0, F.lit(0)).otherwise(
            F.when(flag_sum >= 1, F.lit(1)).otherwise(F.lit(0))
        )

    def create_aggregate_flag_expression(
        self,
        flag_type: str,
        numerator_flag_col: str,
        denominator_flag_cols: Optional[List[str]] = None,
    ) -> Column:
        """Create aggregate flag expression.

        Implements logic from SQL lines 394-395, 490-491:
        CASE WHEN CAST(d.AggFlagInt AS INT) <> CAST(d1.AggFlagInt AS INT)
             AND (SELECT MIN(AggFlagInt) FROM (VALUES (d.AggFlagInt),(d1.AggFlagInt))
                  AS AggFlags(AggFlagInt)) = 0
             THEN (SELECT MAX(AggFlagInt) FROM (VALUES (d.AggFlagInt),(d1.AggFlagInt))
                   AS AggFlags(AggFlagInt))
             ELSE 0 END

        Args:
            flag_type: 'int' or 'ext'
            numerator_flag_col: Numerator aggregate flag column
            denominator_flag_cols: Denominator aggregate flag columns

        Returns:
            Aggregate flag expression
        """
        if not self.config.aggregate_enabled:
            return F.lit(None)

        num_flag = F.col(numerator_flag_col).cast("int")

        if not denominator_flag_cols:
            return num_flag

        # For each denominator, check if flags differ and one is 0
        # If so, take the non-zero value; otherwise 0
        result = num_flag
        for den_flag_col in denominator_flag_cols:
            den_flag = F.col(den_flag_col).cast("int")

            # When flags differ and min is 0, take max; otherwise 0
            result = F.when(
                (result != den_flag) & (F.least(result, den_flag) == 0),
                F.greatest(result, den_flag),
            ).otherwise(F.lit(0))

        return result
