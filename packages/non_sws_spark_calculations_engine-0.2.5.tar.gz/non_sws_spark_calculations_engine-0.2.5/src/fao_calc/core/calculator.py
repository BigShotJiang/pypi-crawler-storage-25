"""Core calculation implementations."""

from datetime import datetime
from typing import Any, Dict, List, Optional

from pyspark.sql import Column, DataFrame
from pyspark.sql import functions as F

from ..config.schema import (
    CalculationDefinition,
    CalculationType,
    ColumnMapping,
    DimensionDefinition,
)
from .flag_handler import FlagHandler


class Calculator:
    """Implements statistical calculations on Spark DataFrames."""

    def __init__(
        self,
        dimensions: List[DimensionDefinition],
        columns: ColumnMapping,
        flag_handler: FlagHandler,
    ):
        """Initialize calculator.

        Args:
            dimensions: Dimension definitions
            columns: Column mappings
            flag_handler: Flag handler instance
        """
        self.dimensions = dimensions
        self.columns = columns
        self.flag_handler = flag_handler

        # Create dimension lookup
        self.dimension_map = {dim.name: dim for dim in dimensions}

    @staticmethod
    def _resolve_denominator(
        den_dataset: Optional[str],
        denominator_data: Optional[Dict[str, DataFrame]],
        primary_data: DataFrame,
    ) -> DataFrame:
        """Return the denominator DataFrame, broadcast-hinting cross-dataset sources.

        Additional datasets are typically much smaller than the primary
        working data (e.g. a single-domain lookup used as denominator).
        Wrapping them in ``F.broadcast()`` lets Spark avoid an expensive
        shuffle-join and use a broadcast-hash-join instead.
        """
        if den_dataset and denominator_data:
            den_df = denominator_data.get(den_dataset)
            if den_df is None:
                raise ValueError(f"Denominator dataset '{den_dataset}' not found")
            return F.broadcast(den_df)
        return primary_data

    def calculate(
        self,
        calculation: CalculationDefinition,
        data: DataFrame,
        denominator_data: Optional[Dict[str, DataFrame]] = None,
    ) -> DataFrame:
        """Execute a calculation.

        Args:
            calculation: Calculation definition
            data: Input DataFrame
            denominator_data: Optional dict of dataset_id -> DataFrame for cross-dataset joins

        Returns:
            DataFrame with calculated results
        """
        if calculation.type == CalculationType.RATIO:
            return self._calculate_ratio(calculation, data, denominator_data)
        elif calculation.type == CalculationType.GROWTH_RATE:
            return self._calculate_growth_rate(calculation, data)
        elif calculation.type == CalculationType.TRANSFORMATION:
            return self._calculate_transformation(calculation, data)
        elif calculation.type == CalculationType.CUSTOM:
            return self._calculate_custom(calculation, data, denominator_data)
        else:
            raise ValueError(f"Unsupported calculation type: {calculation.type}")

    def _calculate_ratio(
        self,
        calculation: CalculationDefinition,
        data: DataFrame,
        denominator_data: Optional[Dict[str, DataFrame]] = None,
    ) -> DataFrame:
        """Calculate ratio: (numerator * multiplier) / denominator.

        Implements SQL lines 365-430.

        Args:
            calculation: Calculation definition
            data: Numerator data
            denominator_data: Optional denominator datasets

        Returns:
            Calculated results
        """
        # Get numerator filters and multiplier
        num_filters = calculation.get_numerator_filters()
        multiplier = calculation.get_numerator_multiplier()

        # Filter numerator data
        numerator_df = self._filter_data(data, num_filters, calculation.filters)

        # Get denominator dataset and filters
        den_dataset = calculation.get_denominator_dataset()
        den_filters = calculation.get_denominator_filters()

        # Get denominator data (broadcast-hinted when cross-dataset)
        den_df = self._resolve_denominator(den_dataset, denominator_data, data)

        # Filter denominator data
        den_df = self._filter_data(den_df, den_filters, calculation.filters)

        # Build join condition
        join_condition = self._build_join_condition(num_filters, den_filters, calculation.result)

        # Join numerator and denominator
        joined = numerator_df.alias("num").join(den_df.alias("den"), join_condition, "inner")

        # Calculate ratio
        ratio_value = (F.col(f"num.{self.columns.value}") * F.lit(multiplier)) / F.col(
            f"den.{self.columns.value}"
        )

        # Filter out division by zero
        joined = joined.filter(F.col(f"den.{self.columns.value}") != 0)
        joined = joined.filter(F.col(f"num.{self.columns.value}").isNotNull())

        # Build result columns
        result_cols = self._build_result_columns(calculation, ratio_value, "num", ["den"])

        return joined.select(*result_cols)

    def _calculate_growth_rate(
        self, calculation: CalculationDefinition, data: DataFrame
    ) -> DataFrame:
        """Calculate growth rate: ((current / previous) - 1) * multiplier.

        Implements SQL lines 458-527.

        Args:
            calculation: Calculation definition
            data: Input data

        Returns:
            Calculated results
        """
        # Filter data
        filtered_df = self._filter_data(data, calculation.get_numerator_filters(), calculation.filters)

        # Find time dimension
        time_dim = None
        for dim in self.dimensions:
            if any("time" in dim.name.lower() or "year" in dim.name.lower() for _ in [1]):
                time_dim = dim
                break

        if not time_dim:
            raise ValueError("No time dimension found for growth rate calculation")

        # Alias current and previous
        current_df = filtered_df.alias("current")
        previous_df = filtered_df.alias("previous")

        # Build join condition with time offset
        join_conditions = []
        for dim in self.dimensions:
            if dim.name == time_dim.name:
                # Time dimension with offset
                join_conditions.append(
                    F.col(f"current.{dim.column}")
                    == F.col(f"previous.{dim.column}") + calculation.time_offset
                )
            else:
                # Other dimensions match exactly
                join_conditions.append(
                    F.col(f"current.{dim.column}") == F.col(f"previous.{dim.column}")
                )

        join_condition = join_conditions[0]
        for cond in join_conditions[1:]:
            join_condition = join_condition & cond

        # Join current with previous
        joined = current_df.join(previous_df, join_condition, "inner")

        # Calculate growth rate
        growth_rate_value = (
            (F.col(f"current.{self.columns.value}") / F.col(f"previous.{self.columns.value}"))
            - 1
        ) * F.lit(calculation.multiplier)

        # Filter out division by zero and nulls
        joined = joined.filter(F.col(f"previous.{self.columns.value}") != 0)
        joined = joined.filter(F.col(f"current.{self.columns.value}").isNotNull())

        # Build result columns
        result_cols = self._build_result_columns(
            calculation, growth_rate_value, "current", ["previous"]
        )

        return joined.select(*result_cols)

    def _calculate_transformation(
        self, calculation: CalculationDefinition, data: DataFrame
    ) -> DataFrame:
        """Calculate simple transformation: value * multiplier.

        Implements SQL lines 543-589.

        Args:
            calculation: Calculation definition
            data: Input data

        Returns:
            Calculated results
        """
        # Filter data
        filtered_df = self._filter_data(data, calculation.get_numerator_filters(), calculation.filters)

        # Calculate transformed value
        transformed_value = F.col(self.columns.value) * F.lit(calculation.multiplier)

        # Filter out nulls
        filtered_df = filtered_df.filter(F.col(self.columns.value).isNotNull())

        # Build result columns
        result_cols = self._build_result_columns(calculation, transformed_value, None, None)

        return filtered_df.select(*result_cols)

    def _calculate_custom(
        self,
        calculation: CalculationDefinition,
        data: DataFrame,
        denominator_data: Optional[Dict[str, DataFrame]] = None,
    ) -> DataFrame:
        """Calculate using custom Spark SQL formula.

        When a ``denominator`` is configured, the numerator and denominator
        datasets are joined (like a ratio) and the formula can reference
        ``num.Value`` and ``den.Value``.  Without a denominator the formula
        operates on the filtered numerator rows directly.

        Args:
            calculation: Calculation definition
            data: Input data
            denominator_data: Optional additional datasets

        Returns:
            Calculated results
        """
        num_filters = calculation.get_numerator_filters()
        numerator_df = self._filter_data(data, num_filters, calculation.filters)

        den_filters = calculation.get_denominator_filters()
        if den_filters:
            # Join-based custom: mirrors the ratio join logic
            den_dataset = calculation.get_denominator_dataset()
            den_df = self._resolve_denominator(den_dataset, denominator_data, data)
            den_df = self._filter_data(den_df, den_filters, calculation.filters)

            join_condition = self._build_join_condition(
                num_filters, den_filters, calculation.result
            )
            joined = numerator_df.alias("num").join(
                den_df.alias("den"), join_condition, "inner"
            )
            custom_value = F.expr(calculation.custom_formula)
            result_cols = self._build_result_columns(
                calculation, custom_value, "num", ["den"]
            )
            return joined.select(*result_cols)

        # Simple custom: no join, formula operates on filtered rows
        custom_value = F.expr(calculation.custom_formula)
        result_cols = self._build_result_columns(
            calculation, custom_value, None, None
        )
        return numerator_df.select(*result_cols)

    def _filter_data(
        self,
        data: DataFrame,
        variable_refs: List,
        additional_filters: Optional[Dict[str, List[str]]] = None,
    ) -> DataFrame:
        """Filter data based on variable references and additional filters.

        Args:
            data: Input DataFrame
            variable_refs: Variable references to filter
            additional_filters: Additional filters to apply

        Returns:
            Filtered DataFrame
        """
        filtered = data

        # Apply variable reference filters
        for var_ref in variable_refs:
            dim = self.dimension_map[var_ref.dimension]
            if isinstance(var_ref.value, list):
                filtered = filtered.filter(F.col(dim.column).isin(var_ref.value))
            else:
                filtered = filtered.filter(F.col(dim.column) == var_ref.value)

        # Apply additional filters
        if additional_filters:
            for filter_key, filter_values in additional_filters.items():
                # Check if filter_key is a dimension name or column name
                column_name = filter_key
                for dim in self.dimensions:
                    if dim.name == filter_key:
                        column_name = dim.column
                        break

                filtered = filtered.filter(F.col(column_name).isin(filter_values))

        return filtered

    def _build_join_condition(
        self, numerator_vars: List, denominator_vars: List, result: Dict[str, any]
    ) -> Column:
        """Build join condition between numerator and denominator.

        Joins on all dimensions except those being filtered or assigned.

        Args:
            numerator_vars: Numerator variable references
            denominator_vars: Denominator variable references
            result: Result dimension assignments

        Returns:
            Join condition
        """
        # Get dimensions that are filtered in numerator/denominator or assigned in result
        num_dims = {var.dimension for var in numerator_vars}
        den_dims = {var.dimension for var in denominator_vars}
        result_dims = set(result.keys())

        # Join on dimensions that are NOT being filtered or assigned
        join_conditions = []
        for dim in self.dimensions:
            if (
                dim.name not in num_dims
                and dim.name not in den_dims
                and dim.name not in result_dims
            ):
                join_conditions.append(F.col(f"num.{dim.column}") == F.col(f"den.{dim.column}"))

        if not join_conditions:
            # If all dimensions are filtered/assigned, join on all except result
            for dim in self.dimensions:
                if dim.name not in result_dims:
                    join_conditions.append(
                        F.col(f"num.{dim.column}") == F.col(f"den.{dim.column}")
                    )

        # Combine all conditions
        join_condition = join_conditions[0]
        for cond in join_conditions[1:]:
            join_condition = join_condition & cond

        return join_condition

    def _build_result_columns(
        self,
        calculation: CalculationDefinition,
        value_expr: Column,
        numerator_alias: Optional[str],
        denominator_aliases: Optional[List[str]],
    ) -> List[Column]:
        """Build list of result columns.

        Args:
            calculation: Calculation definition
            value_expr: Expression for calculated value
            numerator_alias: Alias for numerator table (if joined)
            denominator_aliases: Aliases for denominator tables (if joined)

        Returns:
            List of column expressions
        """
        result_cols = []

        # Get result assignments
        result_assignments = calculation.result

        # Add dimension columns
        for dim in self.dimensions:
            if dim.name in result_assignments:
                # This dimension is assigned in result
                result_cols.append(F.lit(result_assignments[dim.name]).alias(dim.column))
            else:
                # Copy from numerator
                if numerator_alias:
                    result_cols.append(F.col(f"{numerator_alias}.{dim.column}").alias(dim.column))
                else:
                    result_cols.append(F.col(dim.column))

        # Add calculated value
        result_cols.append(value_expr.alias(self.columns.value))

        # Add flag
        if numerator_alias and denominator_aliases:
            # Build flag column names
            num_flag = f"{numerator_alias}.{self.columns.flag}"
            den_flags = [f"{alias}.{self.columns.flag}" for alias in denominator_aliases]
            flag_expr = self.flag_handler.create_flag_expression(num_flag, den_flags)
        elif numerator_alias:
            num_flag = f"{numerator_alias}.{self.columns.flag}"
            flag_expr = self.flag_handler.create_flag_expression(num_flag)
        else:
            flag_expr = self.flag_handler.create_flag_expression(self.columns.flag)

        result_cols.append(flag_expr.alias(self.columns.flag))

        # Add note
        if calculation.include_note:
            if numerator_alias:
                result_cols.append(F.col(f"{numerator_alias}.{self.columns.note}").alias(self.columns.note))
            else:
                result_cols.append(F.col(self.columns.note))
        else:
            # Use F.lit(None).cast("string") to avoid VOID type
            if self.columns.note:
                result_cols.append(F.lit(None).cast("string").alias(self.columns.note))

        # Add load date
        if self.columns.load_date:
            result_cols.append(F.lit(datetime.now()).alias(self.columns.load_date))

        # Add dissemination flags if configured
        if self.flag_handler.config.dissemination_enabled:
            if self.columns.diss_flag_int:
                if numerator_alias and denominator_aliases:
                    num_diss = f"{numerator_alias}.{self.columns.diss_flag_int}"
                    den_diss = [f"{alias}.{self.columns.diss_flag_int}" for alias in denominator_aliases]
                    diss_expr = self.flag_handler.create_dissemination_flag_expression(
                        "int", num_diss, den_diss
                    )
                else:
                    diss_expr = F.col(self.columns.diss_flag_int)
                result_cols.append(diss_expr.alias(self.columns.diss_flag_int))

            if self.columns.diss_flag_ext:
                if numerator_alias and denominator_aliases:
                    num_diss = f"{numerator_alias}.{self.columns.diss_flag_ext}"
                    den_diss = [f"{alias}.{self.columns.diss_flag_ext}" for alias in denominator_aliases]
                    diss_expr = self.flag_handler.create_dissemination_flag_expression(
                        "ext", num_diss, den_diss
                    )
                else:
                    diss_expr = F.col(self.columns.diss_flag_ext)
                result_cols.append(diss_expr.alias(self.columns.diss_flag_ext))

        # Add aggregate flags if configured
        if self.flag_handler.config.aggregate_enabled:
            if self.columns.agg_flag_int:
                if numerator_alias and denominator_aliases:
                    num_agg = f"{numerator_alias}.{self.columns.agg_flag_int}"
                    den_agg = [f"{alias}.{self.columns.agg_flag_int}" for alias in denominator_aliases]
                    agg_expr = self.flag_handler.create_aggregate_flag_expression(
                        "int", num_agg, den_agg
                    )
                else:
                    agg_expr = F.col(self.columns.agg_flag_int)
                result_cols.append(agg_expr.alias(self.columns.agg_flag_int))

            if self.columns.agg_flag_ext:
                if numerator_alias and denominator_aliases:
                    num_agg = f"{numerator_alias}.{self.columns.agg_flag_ext}"
                    den_agg = [f"{alias}.{self.columns.agg_flag_ext}" for alias in denominator_aliases]
                    agg_expr = self.flag_handler.create_aggregate_flag_expression(
                        "ext", num_agg, den_agg
                    )
                else:
                    agg_expr = F.col(self.columns.agg_flag_ext)
                result_cols.append(agg_expr.alias(self.columns.agg_flag_ext))

        # Filter out None values
        result_cols = [col for col in result_cols if col is not None]

        return result_cols
