"""FAO Indicator Calculator - Configurable statistical indicator calculation engine."""

__version__ = "0.1.0"

from .config import (
    CalculationConfig,
    CalculationDefinition,
    CalculationType,
    DataMappingConfig,
    FlagConfig,
    load_calculations,
    load_data_mapping,
    load_flag_config,
)
from .core import CalculationEngine, Calculator, FlagHandler

__all__ = [
    # Main engine
    "CalculationEngine",
    # Core components
    "Calculator",
    "FlagHandler",
    # Configuration
    "DataMappingConfig",
    "CalculationConfig",
    "CalculationDefinition",
    "FlagConfig",
    "CalculationType",
    # Loaders
    "load_data_mapping",
    "load_calculations",
    "load_flag_config",
    # Version
    "__version__",
]
