"""FAO Aggregation Engine - configuration-driven statistical aggregation."""

from .core.engine import AggregationEngine

__all__ = ["AggregationEngine"]
