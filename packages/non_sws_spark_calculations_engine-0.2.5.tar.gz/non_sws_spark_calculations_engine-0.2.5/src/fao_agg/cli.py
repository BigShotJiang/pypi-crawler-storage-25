"""Command-line interface for the FAO aggregation engine.

Usage
-----
    fao-agg --data-mapping configs/data_mapping.json \\
            --agg-config   configs/domains/CS/aggregation.json \\
            --data         data/DataCS.csv \\
            --output       output/DataCS_aggregated.csv \\
            --output-format csv

All paths are resolved relative to the current working directory.
Additional datasets for cross-domain AggJoin rules can be supplied with
``--additional-data DOMAIN_CODE=path/to/file.csv``.

Exit codes
----------
0 — success
1 — configuration or I/O error
2 — aggregation error
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="fao-agg",
        description="Configuration-driven geographic/dimensional aggregation for FAO data.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )

    p.add_argument(
        "--data-mapping", "-m",
        required=True,
        metavar="PATH",
        help="Path to the data mapping JSON (dimensions, column names).",
    )
    p.add_argument(
        "--agg-config", "-c",
        required=True,
        metavar="PATH",
        help="Path to the aggregation config JSON (groups, iterations, etc.).",
    )
    p.add_argument(
        "--data", "-d",
        required=False,
        metavar="PATH",
        help=(
            "Path to the input data file. Overrides the path in the data mapping config. "
            "Supported formats: CSV, Parquet, Delta."
        ),
    )
    p.add_argument(
        "--output", "-o",
        required=True,
        metavar="PATH",
        help="Output path for the aggregated data.",
    )
    p.add_argument(
        "--output-format", "-f",
        choices=["csv", "parquet", "delta"],
        default="csv",
        help="Output file format (default: csv).",
    )
    p.add_argument(
        "--output-mode",
        choices=["overwrite", "append", "error", "ignore"],
        default="overwrite",
        help="Spark write mode (default: overwrite).",
    )
    p.add_argument(
        "--additional-data",
        metavar="DOMAIN=PATH",
        action="append",
        default=[],
        help=(
            "Additional dataset for cross-domain AggJoin denominators. "
            "Format: DOMAIN_CODE=path/to/file. "
            "May be repeated for multiple extra datasets."
        ),
    )
    p.add_argument(
        "--iterations",
        metavar="N",
        type=int,
        nargs="+",
        default=None,
        help="Run only specific iteration numbers (space-separated). Default: all.",
    )
    p.add_argument(
        "--no-china351",
        action="store_true",
        default=False,
        help="Skip the China 351 special aggregate step even if configured.",
    )
    p.add_argument(
        "--new-aggregates-only",
        action="store_true",
        default=False,
        help="Write only newly computed aggregate rows, not the full output.",
    )
    p.add_argument(
        "--config-base-dir",
        metavar="PATH",
        default=None,
        help=(
            "Base directory for resolving relative paths inside the aggregation config. "
            "Defaults to the directory containing --agg-config."
        ),
    )
    return p


def parse_additional_data(specs: list[str]) -> dict[str, str]:
    """Parse ``DOMAIN=path`` strings into a dict."""
    result: dict[str, str] = {}
    for spec in specs:
        if "=" not in spec:
            raise argparse.ArgumentTypeError(
                f"Invalid --additional-data value '{spec}'. "
                "Expected format: DOMAIN_CODE=path/to/file"
            )
        domain, path = spec.split("=", 1)
        result[domain.strip()] = path.strip()
    return result


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)

    # Import here so startup is fast when run with --help
    try:
        from fao_agg.core.engine import AggregationEngine
    except ImportError as exc:
        print(f"ERROR: Could not import fao_agg — {exc}", file=sys.stderr)
        return 1

    # Resolve config base dir
    agg_config_path = Path(args.agg_config)
    config_base_dir = (
        Path(args.config_base_dir)
        if args.config_base_dir
        else agg_config_path.parent
    )

    try:
        engine = AggregationEngine(
            data_mapping=args.data_mapping,
            aggregation_config=args.agg_config,
            config_base_dir=config_base_dir,
        )
    except Exception as exc:
        print(f"ERROR: Failed to load configuration — {exc}", file=sys.stderr)
        return 1

    # Load primary data
    try:
        load_kwargs: dict = {}
        if args.data:
            load_kwargs["path"] = args.data
        engine.load_data(**load_kwargs)
    except Exception as exc:
        print(f"ERROR: Failed to load data — {exc}", file=sys.stderr)
        return 1

    # Load additional datasets
    try:
        additional = parse_additional_data(args.additional_data)
        for domain_code, file_path in additional.items():
            engine.load_additional_dataset(domain_code, path=file_path)
    except Exception as exc:
        print(f"ERROR: Failed to load additional dataset — {exc}", file=sys.stderr)
        return 1

    # Run aggregation
    try:
        engine.aggregate(
            iterations=args.iterations,
            run_china351=not args.no_china351,
        )
    except Exception as exc:
        print(f"ERROR: Aggregation failed — {exc}", file=sys.stderr)
        return 2

    # Write output
    try:
        results = (
            engine.get_new_aggregates() if args.new_aggregates_only
            else engine.get_results()
        )
        if results is None:
            print("ERROR: No results produced.", file=sys.stderr)
            return 2

        fmt = args.output_format
        output_path = args.output
        mode = args.output_mode

        if fmt == "csv":
            engine.write_csv(output_path, mode=mode)
        elif fmt == "parquet":
            engine.write_parquet(output_path, mode=mode)
        elif fmt == "delta":
            engine.write_delta(output_path, mode=mode)

        print(f"Aggregation complete. Output written to: {output_path}")
    except Exception as exc:
        print(f"ERROR: Failed to write output — {exc}", file=sys.stderr)
        return 2

    return 0


if __name__ == "__main__":
    sys.exit(main())
