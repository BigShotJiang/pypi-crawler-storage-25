"""Configuration loaders for fao_agg."""

from pathlib import Path
from typing import Union

from pydantic import ValidationError

from fao_common.config.loader import (
    ConfigurationError,
    load_json_config,
    resolve_config_dict,
)

from .schema import AggJoinConfig, AggregationConfig, China351Config, GroupsConfig


def _merge_raw_group_dicts(base: dict, overlay: dict) -> dict:
    """Merge two raw groups-override dicts at the dict level.

    Used to implement the ``extends`` inheritance mechanism.  Both inputs are
    raw JSON dicts in the groups-override format
    ``{dim_type: [{code, name, members/excluded_members/additional_members}, ...]}``,
    optionally with top-level ``dim_type_aliases`` and ``extends`` keys.

    Rules:
    - ``dim_type_aliases``: overlay values take precedence; base values are
      kept for keys absent from overlay.
    - Per group: groups are indexed by ``code``; overlay group wins on conflict,
      with member-list keys unioned by member ``code`` (overlay member wins).
    - New groups or dim_types in either dict are carried through as-is.
    - The ``extends`` key is **not** propagated to the result (it has already
      been consumed by the caller).
    """
    _SPECIAL = {"extends", "dim_type_aliases"}

    result: dict = {}

    # Merge dim_type_aliases (overlay takes precedence)
    merged_aliases = {**base.get("dim_type_aliases", {}), **overlay.get("dim_type_aliases", {})}
    if merged_aliases:
        result["dim_type_aliases"] = merged_aliases

    # Collect all non-special dim_type keys
    dim_types = (set(base) | set(overlay)) - _SPECIAL

    for dim_type in dim_types:
        base_dim: list = base.get(dim_type, [])
        overlay_dim: list = overlay.get(dim_type, [])

        # Index base groups by code
        merged_by_code: dict = {g["code"]: g for g in base_dim}

        for group_data in overlay_dim:
            group_code = group_data["code"]
            if group_code not in merged_by_code:
                merged_by_code[group_code] = group_data
            else:
                merged_group = {**merged_by_code[group_code]}
                if "name" in group_data:
                    merged_group["name"] = group_data["name"]
                # Union each member-list key by member code; overlay wins on conflicts
                for key in ("members", "excluded_members", "additional_members"):
                    base_list = merged_by_code[group_code].get(key, [])
                    overlay_list = group_data.get(key, [])
                    if base_list or overlay_list:
                        member_map = {m["code"]: m for m in base_list}
                        for m in overlay_list:
                            member_map[m["code"]] = m
                        merged_group[key] = list(member_map.values())
                merged_by_code[group_code] = merged_group

        result[dim_type] = list(merged_by_code.values())

    return result


def load_groups_config(config: Union[str, Path, dict]) -> GroupsConfig:
    """Load and validate a GroupsConfig.

    The JSON structure is ``{dim_type: {group_code: {name, members, ...}}}``.

    Supports two optional top-level keys in addition to dimension types:

    ``dim_type_aliases`` (dict)
        Maps domain-specific dimension names to the base dimension type whose
        groups they inherit from (e.g. ``{"donor": "area"}``).

    ``extends`` (str)
        Path to another groups-override file to inherit from.  The extended
        file is loaded first; the current file's entries are then merged on
        top using a union of member entries keyed by code (overlay wins on
        conflicts).  Paths are resolved relative to the current file when the
        input is a file path.  Chained ``extends`` (A extends B extends C)
        are supported via recursion.

    Args:
        config: Path to JSON file, a JSON string, or a dict.

    Returns:
        Validated GroupsConfig.

    Raises:
        ConfigurationError: If the configuration is invalid.
    """
    # Retain file location for resolving relative 'extends' paths
    base_dir: Union[Path, None] = None
    if isinstance(config, Path):
        base_dir = config.parent.resolve()
    elif isinstance(config, str) and not config.strip().startswith("{"):
        p = Path(config)
        if p.exists():
            base_dir = p.parent.resolve()

    raw = resolve_config_dict(config)

    # Handle 'extends': load the referenced file and union its entries with ours
    extends_path = raw.pop("extends", None)
    if extends_path is not None:
        if base_dir is not None:
            extends_resolved: Union[str, Path] = (base_dir / extends_path).resolve()
        else:
            extends_resolved = extends_path
        extends_raw = resolve_config_dict(extends_resolved)
        # Merge: extends file is the base, current raw is the overlay
        raw = _merge_raw_group_dicts(extends_raw, raw)

    # The raw dict is {dim_type: [group_dict, ...]} plus an optional
    # top-level "dim_type_aliases" key.  Extract aliases before wrapping the
    # remainder in {"groups": ...} for the model.
    aliases = raw.pop("dim_type_aliases", {})
    if "groups" not in raw:
        raw = {"groups": raw}
    raw["dim_type_aliases"] = aliases
    try:
        return GroupsConfig(**raw)
    except ValidationError as e:
        raise ConfigurationError(f"Invalid groups configuration: {e}") from e


def load_aggregation_config(config: Union[str, Path, dict]) -> AggregationConfig:
    """Load and validate an AggregationConfig.

    Args:
        config: Path to JSON file, a JSON string, or a dict.

    Returns:
        Validated AggregationConfig.

    Raises:
        ConfigurationError: If the configuration is invalid.
    """
    config_dict = resolve_config_dict(config)
    try:
        return AggregationConfig(**config_dict)
    except ValidationError as e:
        raise ConfigurationError(f"Invalid aggregation configuration: {e}") from e


def load_agg_join_config(config: Union[str, Path, dict]) -> AggJoinConfig:
    """Load and validate an AggJoinConfig.

    Args:
        config: Path to JSON file, a JSON string, or a dict.

    Returns:
        Validated AggJoinConfig.

    Raises:
        ConfigurationError: If the configuration is invalid.
    """
    config_dict = resolve_config_dict(config)
    try:
        return AggJoinConfig(**config_dict)
    except ValidationError as e:
        raise ConfigurationError(f"Invalid AggJoin configuration: {e}") from e


def load_china351_config(config: Union[str, Path, dict]) -> China351Config:
    """Load and validate a China351Config.

    Args:
        config: Path to JSON file, a JSON string, or a dict.

    Returns:
        Validated China351Config.

    Raises:
        ConfigurationError: If the configuration is invalid.
    """
    config_dict = resolve_config_dict(config)
    try:
        return China351Config(**config_dict)
    except ValidationError as e:
        raise ConfigurationError(f"Invalid China351 configuration: {e}") from e


def load_merged_groups(
    aggregation_cfg: AggregationConfig,
    base_dir: Union[str, Path, None] = None,
) -> GroupsConfig:
    """Load and merge base + domain-specific groups configs.

    Paths in ``aggregation_cfg`` are resolved relative to ``base_dir``
    when they are not absolute.

    Args:
        aggregation_cfg: Aggregation configuration with path references.
        base_dir: Directory used to resolve relative paths.  Defaults to
            the current working directory.

    Returns:
        Merged GroupsConfig (base overridden by domain groups).

    Raises:
        ConfigurationError: If any referenced file is missing or invalid.
    """
    base_dir = Path(base_dir) if base_dir else Path.cwd()

    def _resolve(path_str: str) -> Path:
        p = Path(path_str)
        return p if p.is_absolute() else base_dir / p

    def _load_groups(val) -> GroupsConfig:
        if isinstance(val, dict):
            return load_groups_config(val)
        return load_groups_config(_resolve(val))

    # China-351-only domains have no standard iterations and omit base_groups.
    if not aggregation_cfg.base_groups:
        return GroupsConfig(groups={})

    base_groups = _load_groups(aggregation_cfg.base_groups)

    if aggregation_cfg.domain_groups:
        domain_groups = _load_groups(aggregation_cfg.domain_groups)
        return base_groups.merge(domain_groups)

    return base_groups
