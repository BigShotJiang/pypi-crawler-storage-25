"""fao_agg configuration models and loaders."""

from .loader import load_aggregation_config, load_agg_join_config, load_groups_config
from .schema import (
    AggJoinComponent,
    AggJoinConfig,
    AggJoinRule,
    AggJoinSubRatio,
    AggregateGroup,
    AggregationConfig,
    AggregationIteration,
    China351Config,
    GroupMember,
    GroupsConfig,
)

__all__ = [
    # Schema
    "GroupMember",
    "AggregateGroup",
    "GroupsConfig",
    "AggregationIteration",
    "AggregationConfig",
    "AggJoinComponent",
    "AggJoinSubRatio",
    "AggJoinRule",
    "AggJoinConfig",
    "China351Config",
    # Loaders
    "load_groups_config",
    "load_aggregation_config",
    "load_agg_join_config",
]
