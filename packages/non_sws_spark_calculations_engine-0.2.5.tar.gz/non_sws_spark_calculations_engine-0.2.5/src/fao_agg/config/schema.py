"""Configuration schema for the FAO aggregation engine.

The aggregation system reads two categories of JSON configuration files:

Groups configuration (shareable across domains)
------------------------------------------------
Defines aggregate group membership and weights for each dimension type.
The base file covers standard UN geographic and commodity groupings;
domain-specific files can extend or override individual groups.

``factor`` defaults to ``1.0`` and is omitted from JSON when equal to the
default.  ``exclude`` defaults to ``false`` and is omitted when not set.

Example ``base_groups.json`` (from tbl_VarGroupVar):

.. code-block:: json

    {
      "area": {
        "5100": {
          "name": "Africa",
          "members": [{"code": "107"}, {"code": "114"}]
        }
      },
      "item": {
        "2805": {
          "name": "Vegetables + (Total)",
          "members": [{"code": "388"}]
        }
      }
    }

Example ``groups_override.json`` (domain-specific diff, from vDomainVarGroupVar):
Only the *changes* relative to the base are stored.

- ``{"code": "351", "exclude": true}`` — remove member 351 from this group.
- ``{"code": "999"}`` — add member 999 to this group.
- A group code absent from the base must include a full ``members`` list.

.. code-block:: json

    {
      "area": {
        "5100": {
          "members": [{"code": "351", "exclude": true}]
        },
        "9901": {
          "name": "Custom World",
          "members": [{"code": "5100"}, {"code": "5200"}]
        }
      }
    }

Aggregation configuration (per domain)
---------------------------------------
Specifies which iterations to run, which dimensions to aggregate in each
iteration, optional filters, valid-combination constraints, and whether
AggJoin pre-processing is required.

Example ``aggregation.json``:

.. code-block:: json

    {
      "base_groups": "configs/groups/base_groups.json",
      "domain_groups": "configs/domains/CS/groups_override.json",
      "iterations": [
        {
          "iteration": 1,
          "agg_dimensions": ["area"]
        }
      ],
      "agg_join": "configs/domains/CS/agg_join.json",
      "valid_combinations": [
        {"item": "22030", "element": "6110"}
      ]
    }
"""

from __future__ import annotations

from typing import Dict, List, Optional, Union

from pydantic import BaseModel, Field, model_serializer, model_validator


# ---------------------------------------------------------------------------
# Groups configuration
# ---------------------------------------------------------------------------


class GroupMember(BaseModel):
    """A single member of an aggregate group with its weighting factor.

    JSON serialization is compact: ``factor`` is omitted when 1.0,
    ``exclude`` is omitted when False, and ``name`` is omitted when None.
    """

    code: str = Field(description="Member code (e.g. country or item code)")
    name: Optional[str] = Field(
        default=None,
        description="Human-readable name for this member (e.g. country name)",
    )
    factor: float = Field(
        default=1.0,
        description="Weighting factor applied to this member's value before summing",
    )
    exclude: bool = Field(
        default=False,
        description=(
            "When True in a domain override ``members`` list, this member is removed "
            "from the merged group.  Not used in ``excluded_members`` lists."
        ),
    )

    @model_serializer
    def _serialize(self) -> dict:
        d: dict = {"code": self.code}
        if self.name is not None:
            d["name"] = self.name
        if self.factor != 1.0:
            d["factor"] = self.factor
        if self.exclude:
            d["exclude"] = True
        return d


class AggregateGroup(BaseModel):
    """Definition of one aggregate group (e.g. 'Africa', region 5100).

    **Base group files** use ``members`` for a full member list.

    **Domain override files** use the cleaner split format:

    - ``excluded_members``: members to *remove* from the base group.
    - ``additional_members``: members to *add* (or update factor of) in the base group.

    Either or both may be omitted; omitting both means a name-only update.
    The legacy ``members`` format (with ``exclude=True`` entries) is still
    accepted for backward compatibility.
    """

    code: str = Field(description="Group code (e.g. '5100' for Africa)")
    name: Optional[str] = Field(None, description="Human-readable group name")
    members: Optional[List[GroupMember]] = Field(
        None,
        description=(
            "Full member list (base files) or legacy diff format (override files). "
            "Prefer ``excluded_members`` / ``additional_members`` in new override files."
        ),
    )
    excluded_members: Optional[List[GroupMember]] = Field(
        None,
        description=(
            "Override files only: members to remove from the base group. "
            "Each entry needs only ``code`` (and optional ``name``)."
        ),
    )
    additional_members: Optional[List[GroupMember]] = Field(
        None,
        description=(
            "Override files only: members to add or update in the base group. "
            "Supports optional ``name`` and ``factor``."
        ),
    )


class GroupsConfig(BaseModel):
    """Complete groups configuration as arrays per dimension type.

    Example structure::

        {
            "area": [AggregateGroup(code="5100", name="Africa", ...), ...],
            "item": [AggregateGroup(code="2805", ...), ...],
        }

    ``dim_type_aliases`` maps a domain-specific dimension name to the base
    dimension type whose groups it inherits from.  For example::

        {"donor": "area", "recipientarea": "area"}

    means that when merging, the "donor" and "recipientarea" overrides are
    diffed against the "area" base groups, and the merged result is stored
    under "donor" / "recipientarea" so the engine can look them up by their
    actual column names.
    """

    groups: Dict[str, List[AggregateGroup]] = Field(
        description=(
            "Outer key: dimension type (e.g. 'area', 'item'). "
            "Value: list of group definitions, each carrying its own ``code``."
        )
    )
    dim_type_aliases: Dict[str, str] = Field(
        default_factory=dict,
        description=(
            "Maps a domain dimension name to the base dimension type it inherits "
            "groups from.  E.g. {'donor': 'area', 'recipientarea': 'area'}.  "
            "Only meaningful in domain override files; ignored in base files."
        ),
    )

    def get_groups_for_dimension(
        self, dim_type: str
    ) -> Dict[str, AggregateGroup]:
        """Return all groups for a given dimension type, indexed by group code."""
        return {g.code: g for g in self.groups.get(dim_type, [])}

    def merge(self, override: "GroupsConfig") -> "GroupsConfig":
        """Return a new GroupsConfig with ``override`` applied as a diff.

        For each (dim_type, group) pair in ``override``:

        - **Aliased dim_type** (via ``override.dim_type_aliases``): the
          merged groups for this dim_type are initialised from a copy of the
          base groups for the aliased type, then the override diffs are
          applied on top.  This lets domain-specific dimension names (e.g.
          "donor", "recipientarea") reuse and refine existing base area groups
          without duplicating them.
        - **Group already in base**: ``members`` is interpreted as a diff.
          Members with ``exclude=True`` are removed; all others are added or
          have their factor updated.  ``members=None`` leaves membership
          unchanged (name-only update).
        - **Group not in base**: treated as a new group.  ``members`` is
          required and used as-is (any ``exclude=True`` entries are stripped
          since there is nothing to exclude from).
        """
        import copy

        # Build dict index from base lists for efficient lookup during merge
        merged: Dict[str, Dict[str, AggregateGroup]] = {
            dim_type: {g.code: g for g in groups}
            for dim_type, groups in self.groups.items()
        }

        # Seed every aliased dim_type from its base type upfront.  This ensures
        # that a dim_type listed only in dim_type_aliases (with no override group
        # entries at all) still receives the full set of base groups.
        for dim_type, base_type in override.dim_type_aliases.items():
            if dim_type not in merged:
                merged[dim_type] = copy.deepcopy(merged.get(base_type, {}))

        for dim_type, override_groups in override.groups.items():
            # Resolve alias: which base dim_type to inherit groups from
            base_type = override.dim_type_aliases.get(dim_type, dim_type)

            if dim_type not in merged:
                # Initialise from the aliased base type (full copy) so that
                # all base groups are available for the aliased dimension.
                merged[dim_type] = copy.deepcopy(merged.get(base_type, {}))

            for override_group in override_groups:
                group_code = override_group.code
                if group_code in merged[dim_type]:
                    base_group = merged[dim_type][group_code]
                    new_name = override_group.name or base_group.name
                    uses_new_format = (
                        override_group.excluded_members is not None
                        or override_group.additional_members is not None
                    )
                    if override_group.members is None and not uses_new_format:
                        # No membership change — update name only
                        merged[dim_type][group_code] = AggregateGroup(
                            code=group_code,
                            name=new_name,
                            members=base_group.members,
                        )
                    else:
                        # Apply diff: build ordered map from base, then apply changes
                        member_map: Dict[str, GroupMember] = {
                            m.code: m for m in (base_group.members or [])
                        }
                        if uses_new_format:
                            for m in (override_group.excluded_members or []):
                                member_map.pop(m.code, None)
                            for m in (override_group.additional_members or []):
                                member_map[m.code] = m
                        else:
                            for m in (override_group.members or []):
                                if m.exclude:
                                    member_map.pop(m.code, None)
                                else:
                                    member_map[m.code] = m
                        merged[dim_type][group_code] = AggregateGroup(
                            code=group_code,
                            name=new_name,
                            members=list(member_map.values()),
                        )
                else:
                    # New group — members are required
                    if override_group.members is None and override_group.additional_members is None:
                        raise ValueError(
                            f"Group '{group_code}' in dimension '{dim_type}' "
                            "does not exist in base config and no members were provided "
                            "in the domain override."
                        )
                    # New format: use additional_members directly; strip excluded (nothing to remove)
                    members_src = (
                        override_group.additional_members
                        if override_group.additional_members is not None
                        else [m for m in (override_group.members or []) if not m.exclude]
                    )
                    merged[dim_type][group_code] = AggregateGroup(
                        code=group_code,
                        name=override_group.name,
                        members=members_src,
                    )

        # Convert dict index back to lists for the result
        return GroupsConfig(
            groups={dt: list(dg.values()) for dt, dg in merged.items()},
        )


# ---------------------------------------------------------------------------
# Aggregation iteration configuration
# ---------------------------------------------------------------------------


class AggregationIteration(BaseModel):
    """Configuration for one aggregation pass.

    Each iteration specifies which dimension(s) to aggregate and how.
    When multiple dimensions are listed they are processed in order
    (cascading): the output of each dimension's aggregation is added to
    the working dataset before the next dimension is processed.
    """

    iteration: int = Field(
        description="Iteration number (1-based, processed in ascending order)", ge=1
    )
    agg_dimensions: List[str] = Field(
        description=(
            "Ordered list of dimension names to aggregate. "
            "E.g. ['area'] or ['area', 'item'] (area first, then item)."
        ),
        min_length=1,
    )
    group_filter: Optional[List[str]] = Field(
        None,
        description=(
            "Restrict aggregation to specific group codes. "
            "``null`` (default) means all groups for the dimension."
        ),
    )
    var_filters: Optional[Dict[str, List[str]]] = Field(
        None,
        description=(
            "Inclusion row-level filters keyed by dimension name. "
            "Only rows whose dimension value is in the list are processed. "
            "E.g. {'element': ['6110', '6120']} restricts to those elements."
        ),
    )
    var_exclude_filters: Optional[Dict[str, List[str]]] = Field(
        None,
        description=(
            "Exclusion row-level filters keyed by dimension name. "
            "Rows whose dimension value is in the list are excluded. "
            "E.g. {'element': ['6139', '6159']} skips those elements."
        ),
    )


class AggregationConfig(BaseModel):
    """Top-level aggregation configuration for a domain.

    Combines groups (base + optional domain override) with iteration
    specifications and optional AggJoin pre-processing.
    """

    base_groups: Optional[Union[str, Dict]] = Field(
        None,
        description=(
            "Base GroupsConfig.  Accepts a file path (string) or an inline dict.  "
            "Required when ``iterations`` is non-empty; omit for China-351-only domains."
        ),
    )
    domain_groups: Optional[Union[str, Dict]] = Field(
        None,
        description=(
            "Domain-specific GroupsConfig.  Accepts a file path (string) or an inline dict.  "
            "Its entries are merged on top of base_groups."
        ),
    )
    iterations: List[AggregationIteration] = Field(
        default_factory=list,
        description=(
            "Aggregation iterations in execution order. "
            "May be empty for domains that only run China 351 (no standard aggregation)."
        ),
    )
    agg_join: Optional[Union[str, Dict]] = Field(
        None,
        description=(
            "AggJoin configuration.  Accepts a file path (string) or an inline dict."
        ),
    )
    china_351: Optional[Union[str, Dict]] = Field(
        None,
        description=(
            "China 351 configuration.  Accepts a file path (string) or an inline dict."
        ),
    )
    valid_combinations: Optional[List[Dict[str, str]]] = Field(
        None,
        description=(
            "List of valid dimension-pair combinations that a row must satisfy to be "
            "eligible for aggregation.  Each entry is a dict keyed by dimension name, "
            "e.g. [{\"item\": \"22073\", \"element\": \"6110\"}, ...].  "
            "Mirrors the SQL tbl_VarLink INNER JOIN filter.  "
            "When null, no combination filtering is applied."
        ),
    )

    @model_validator(mode="after")
    def validate_config(self) -> "AggregationConfig":
        """Validate iteration uniqueness and required field combinations."""
        nums = [it.iteration for it in self.iterations]
        if len(nums) != len(set(nums)):
            raise ValueError("Iteration numbers must be unique")
        if not self.iterations and not self.china_351:
            raise ValueError(
                "At least one of 'iterations' or 'china_351' must be configured."
            )
        if self.iterations and not self.base_groups:
            raise ValueError(
                "'base_groups' is required when 'iterations' is non-empty."
            )
        return self


# ---------------------------------------------------------------------------
# AggJoin configuration (pre-aggregation join for ratio indicators)
# ---------------------------------------------------------------------------


class AggJoinComponent(BaseModel):
    """Identifies the row(s) used as a numerator or denominator in an AggJoin rule.

    Dimension codes are stored as plain ``Dict[str, str]`` alongside optional
    human-readable ``*_name`` annotations.  For example::

        {"element": "6110", "element_name": "Value US$",
         "item": "22030",   "item_name": "Gross Fixed Capital Formation (Agriculture, Forestry and Fishing)"}

    The ``dataset`` field names an external domain whose data is used instead
    of the primary domain table (e.g. ``"MK"`` for Macro-economic data).

    Keys ending in ``_name`` are purely documentary and are ignored by the
    processor; only the bare dimension keys are used to filter rows.
    """

    model_config = {"extra": "allow"}

    dataset: Optional[str] = Field(
        None,
        description="External domain code when the rows come from a different dataset (e.g. 'MK').",
    )

    def dimension_codes(self) -> Dict[str, str]:
        """Return only the dimension-code entries (excluding ``dataset`` and ``*_name`` keys)."""
        return {
            k: v
            for k, v in self.model_dump(exclude={"dataset"}).items()
            if not k.endswith("_name") and v is not None
        }


class AggJoinSubRatio(BaseModel):
    """One sub-ratio inside a ratio-of-ratios rule.

    Computes ``numerator / denominator`` and tags the pre-aggregation rows
    with a unique intermediate code derived from ``result_code``.
    """

    result_code: str = Field(
        description="Intermediate element code produced by this sub-ratio (e.g. '6161')."
    )
    result_name: Optional[str] = Field(
        None,
        description="Human-readable name for the intermediate result (optional, documentation only).",
    )
    numerator: AggJoinComponent = Field(
        description="Row filter for the numerator of this sub-ratio."
    )
    denominator: AggJoinComponent = Field(
        description="Row filter for the denominator of this sub-ratio."
    )


class AggJoinRule(BaseModel):
    """One pre-aggregation join rule.

    Simple ratio (default)
    ----------------------
    Provide ``numerator`` and ``denominator``.  The processor pairs matching
    rows, tags both with ``AggFlagInt = 100``, and inserts them into the
    working dataset for the main aggregator to sum.

    Ratio of ratios
    ---------------
    Provide ``numerator_ratio`` and ``denominator_ratio`` instead.  Each
    sub-ratio is first processed as a simple ratio (phase 1), producing
    intermediate pre-agg rows.  Those rows are then combined in a second
    pass (phase 2) to produce the final pre-agg rows for ``result_code``.
    """

    result_code: str = Field(
        description="Final element code of the ratio result (e.g. '6161' or '6159')."
    )
    result_name: Optional[str] = Field(
        None,
        description="Human-readable name for the result element (optional, documentation only).",
    )

    # --- Simple ratio fields ------------------------------------------------
    numerator: Optional[AggJoinComponent] = Field(
        None,
        description="Numerator row filter.  Required for simple-ratio rules.",
    )
    denominator: Optional[AggJoinComponent] = Field(
        None,
        description="Denominator row filter.  Required for simple-ratio rules.",
    )

    # --- Ratio-of-ratios fields ---------------------------------------------
    numerator_ratio: Optional[AggJoinSubRatio] = Field(
        None,
        description="Numerator sub-ratio.  Required for ratio-of-ratios rules.",
    )
    denominator_ratio: Optional[AggJoinSubRatio] = Field(
        None,
        description="Denominator sub-ratio.  Required for ratio-of-ratios rules.",
    )

    @model_validator(mode="after")
    def validate_rule_type(self) -> "AggJoinRule":
        """Ensure exactly one of (numerator/denominator) or (numerator_ratio/denominator_ratio) is set."""
        has_simple = self.numerator is not None or self.denominator is not None
        has_ror = self.numerator_ratio is not None or self.denominator_ratio is not None
        if has_simple and has_ror:
            raise ValueError(
                f"Rule '{self.result_code}': cannot mix simple-ratio and ratio-of-ratios fields."
            )
        if has_simple and not (self.numerator is not None and self.denominator is not None):
            raise ValueError(
                f"Rule '{self.result_code}': simple-ratio rules require both 'numerator' and 'denominator'."
            )
        if has_ror and not (self.numerator_ratio is not None and self.denominator_ratio is not None):
            raise ValueError(
                f"Rule '{self.result_code}': ratio-of-ratios rules require both "
                "'numerator_ratio' and 'denominator_ratio'."
            )
        if not has_simple and not has_ror:
            raise ValueError(
                f"Rule '{self.result_code}': must provide either numerator/denominator "
                "or numerator_ratio/denominator_ratio."
            )
        return self

    @property
    def is_ratio_of_ratios(self) -> bool:
        return self.numerator_ratio is not None


class AggJoinConfig(BaseModel):
    """Complete AggJoin configuration for a domain.

    ``result_dimension`` is the dimension whose code is replaced by the
    pre-aggregation code (typically ``'element'`` or ``'indicator'``).
    ``secondary_dimension`` is the dimension used to distinguish numerator
    from denominator rows (typically ``'item'`` or ``'element'``).
    """

    result_dimension: str = Field(
        default="element",
        description="Dimension type whose code becomes the pre-aggregation code (default 'element').",
    )
    secondary_dimension: str = Field(
        default="item",
        description="Dimension type that identifies the numerator/denominator row (default 'item').",
    )
    rules: List[AggJoinRule] = Field(
        description="Pre-aggregation join rules.", min_length=1
    )


# ---------------------------------------------------------------------------
# China 351 configuration
# ---------------------------------------------------------------------------


class China351Config(BaseModel):
    """Configuration for the China 351 special aggregate.

    Code 351 represents mainland China.  It is computed by aggregating over
    the members specified here, independently of the main aggregation run.
    This mirrors the logic in ``usp_China351.sql``.
    """

    group_code: str = Field(
        default="351",
        description="The area code assigned to the China aggregate (default '351')",
    )
    members: List[GroupMember] = Field(
        description="Member country codes that compose the China 351 aggregate"
    )
    diss_flag_int: int = Field(default=1)
    diss_flag_ext: int = Field(default=1)
    delete_existing: bool = Field(
        default=True,
        description="Delete existing rows with group_code before inserting new aggregates",
    )
    var_filters: Optional[Dict[str, List[str]]] = Field(
        None,
        description="Optional dimension filters (e.g. restrict to specific items)",
    )
