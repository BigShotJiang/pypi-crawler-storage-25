"""Flag aggregation logic implementing the FAO 2/3 majority rule.

SQL equivalents
---------------
Mirrors the two-pass flag UPDATE in ``usp_Aggregates.sql``.

For non-zero aggregate totals (value-weighted proportions):
  A_value / total >= 2/3  → 'A'
  F_value / total == 1    → 'F'
  any B member            → 'B'
  X_value / total == 1    → 'X'
  else                    → 'E'

For zero aggregate totals (count-based proportions):
  A_count / total >= 2/3  → 'A'
  F_count / total == 1    → 'F'
  any B member            → 'B'
  X_count / total == 1    → 'X'
  else                    → 'E'

Special case for zero totals: if the member with the minimum flag weight
is a "missing data" flag (MissingFlag = 1 in tbl_Flag), the aggregate
gets that flag directly instead of going through the count-based rule.

Additionally, when any member has a factor != 1.0 the aggregate is
immediately flagged 'E' (estimated due to non-unit weighting), regardless
of the member flags.

All of the above is computed in a single GROUP BY pass by injecting
aggregation expressions that are then consumed by ``apply_flag_rules``.
"""

from __future__ import annotations

from typing import Dict, List, Optional, Tuple

from pyspark.sql import Column, DataFrame
from pyspark.sql import functions as F


# Standard FAO flag hierarchy: flag → (weight, is_missing_data_flag).
# Lower weight = higher quality.  Missing-data flags are propagated
# directly for zero-value aggregates.
DEFAULT_FLAG_WEIGHTS: Dict[str, Tuple[float, bool]] = {
    "A": (1.00, False),   # Official figure
    "B": (0.01, False),   # Time-series break
    "E": (0.75, False),   # Estimated
    "F": (0.60, False),   # Forecast
    "I": (0.90, False),   # Imputed
    "M": (0.99, True),    # Missing value
    "N": (0.95, False),   # Not available
    "O": (1.00, True),    # Official figure, no numerical value (missing)
    "P": (0.70, False),   # Provisional
    "S": (0.80, False),   # Unofficial
    "T": (0.85, False),   # International estimate
    "W": (0.50, False),   # Unofficial figure
    "X": (0.05, False),   # Figure from international organisations
    "Z": (0.02, True),    # Official data reported on UNdata
}


class FlagAggregator:
    """Computes aggregate-level quality flags from member-level flags.

    Usage::

        agg_exprs = flag_agg.agg_expressions("Flag", "Value", "_factor")
        grouped = joined_df.groupBy(*group_cols).agg(
            F.sum(F.col("Value") * F.col("_factor")).alias("_total"),
            *agg_exprs,
            ...
        )
        grouped = flag_agg.apply_flag_rules(grouped, "_total", "Flag")
        grouped = grouped.drop(*flag_agg.intermediate_columns)
    """

    # Intermediate column name prefix — never clash with domain data columns
    _PREFIX = "_fa_"

    _COL_VAL_A = "_fa_val_A"
    _COL_VAL_F = "_fa_val_F"
    _COL_VAL_X = "_fa_val_X"
    _COL_CNT_B = "_fa_cnt_B"
    _COL_CNT_TOTAL = "_fa_cnt_total"
    _COL_CNT_A = "_fa_cnt_A"
    _COL_CNT_F = "_fa_cnt_F"
    _COL_CNT_X = "_fa_cnt_X"
    _COL_HAS_E_FACTOR = "_fa_has_e_factor"
    # Struct(weight DOUBLE, is_missing INT) for the member with minimum weight
    _COL_MIN_STRUCT = "_fa_min_struct"

    def __init__(
        self,
        flag_weights: Optional[Dict[str, Tuple[float, bool]]] = None,
    ) -> None:
        self._weights = flag_weights or DEFAULT_FLAG_WEIGHTS
        self._missing_flags: List[Tuple[str, float]] = sorted(
            [(f, w) for f, (w, m) in self._weights.items() if m],
            key=lambda x: x[1],
        )

    @property
    def intermediate_columns(self) -> List[str]:
        """All intermediate column names added by this class."""
        return [
            self._COL_VAL_A, self._COL_VAL_F, self._COL_VAL_X,
            self._COL_CNT_B, self._COL_CNT_TOTAL,
            self._COL_CNT_A, self._COL_CNT_F, self._COL_CNT_X,
            self._COL_HAS_E_FACTOR, self._COL_MIN_STRUCT,
        ]

    # ------------------------------------------------------------------
    # Aggregation expressions (injected into groupBy.agg())
    # ------------------------------------------------------------------

    def agg_expressions(
        self, flag_col: str, value_col: str, factor_col: str
    ) -> List[Column]:
        """Return Spark aggregation Column expressions for the GROUP BY.

        These must be included alongside the value SUM in the ``agg()`` call.
        They produce the intermediate columns consumed by ``apply_flag_rules``.

        Args:
            flag_col: Name of the quality flag column.
            value_col: Name of the numeric value column.
            factor_col: Name of the factor column from the membership DataFrame.

        Returns:
            List of aliased Spark Column expressions.
        """
        wv = F.col(value_col) * F.col(factor_col)   # weighted value
        f  = F.col(flag_col)
        fac = F.col(factor_col)
        fac_nz = fac != 0  # member participates (factor not zero)

        return [
            # --- Value-weighted stats (for non-zero totals) ---
            F.sum(F.when(f == "A", wv).otherwise(F.lit(0.0))).alias(self._COL_VAL_A),
            F.sum(F.when(f == "F", wv).otherwise(F.lit(0.0))).alias(self._COL_VAL_F),
            F.sum(F.when(f == "X", wv).otherwise(F.lit(0.0))).alias(self._COL_VAL_X),

            # --- Count-based stats (for zero totals) ---
            F.count(F.when(f == "B", F.lit(1))).alias(self._COL_CNT_B),
            F.count(F.when(fac_nz, F.lit(1))).alias(self._COL_CNT_TOTAL),
            F.count(F.when(fac_nz & (f == "A"), F.lit(1))).alias(self._COL_CNT_A),
            F.count(F.when(fac_nz & (f == "F"), F.lit(1))).alias(self._COL_CNT_F),
            F.count(F.when(fac_nz & (f == "X"), F.lit(1))).alias(self._COL_CNT_X),

            # --- E-factor: any member with factor != 1.0? ---
            F.max(F.when(fac != F.lit(1.0), F.lit(1)).otherwise(F.lit(0))).alias(
                self._COL_HAS_E_FACTOR
            ),

            # --- Min-weight struct: (weight, is_missing_int) of lowest-weight member ---
            # F.min on a struct uses lexicographic ordering, so the struct with
            # the smallest weight field is selected.
            F.min(
                F.struct(
                    self._weight_expr(flag_col).alias("w"),
                    self._is_missing_expr(flag_col).alias("m"),
                )
            ).alias(self._COL_MIN_STRUCT),
        ]

    # ------------------------------------------------------------------
    # Apply flag rules (called after groupBy.agg())
    # ------------------------------------------------------------------

    def apply_flag_rules(
        self,
        df: DataFrame,
        total_value_col: str,
        flag_col: str,
        force_count_based: bool = False,
    ) -> DataFrame:
        """Compute the aggregate flag and add it as ``flag_col``.

        Must be called on a DataFrame that was produced by a ``groupBy.agg()``
        call that included the expressions from ``agg_expressions()``.

        Args:
            df: Post-aggregation DataFrame.
            total_value_col: Column holding ``SUM(value * factor)``.
            flag_col: Output column name for the computed flag.
            force_count_based: If True, always use the count-based 2/3 rule
                (with missing-flag propagation) instead of value-weighted
                fractions.  Set to True for China 351, which mirrors the
                SQL's second flag UPDATE that applies count-based logic to
                all rows.

        Returns:
            DataFrame with ``flag_col`` added.
        """
        total = F.col(total_value_col)
        cnt_total = F.col(self._COL_CNT_TOTAL)

        # Guard against division by zero in proportions
        safe_total = F.when(total == 0, F.lit(None)).otherwise(total)
        safe_cnt   = F.when(cnt_total == 0, F.lit(None)).otherwise(cnt_total.cast("double"))

        zero_flag = self._zero_flag_expr(safe_cnt)

        if force_count_based:
            flag_expr = zero_flag
        else:
            nonzero_flag = self._nonzero_flag_expr(safe_total)
            flag_expr = F.when(
                total.isNotNull() & (total != 0),
                nonzero_flag,
            ).otherwise(zero_flag)

        return df.withColumn(flag_col, flag_expr)

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    def _weight_expr(self, flag_col: str) -> Column:
        """Row-level expression: weight of the current row's flag."""
        expr = F.lit(1.0)  # default weight if flag not in table
        for flag, (weight, _) in self._weights.items():
            expr = F.when(F.col(flag_col) == flag, F.lit(weight)).otherwise(expr)
        return expr

    def _is_missing_expr(self, flag_col: str) -> Column:
        """Row-level expression: 1 if the current row's flag is a missing-data flag."""
        if not self._missing_flags:
            return F.lit(0)
        missing_flag_codes = [f for f, _ in self._missing_flags]
        return F.when(F.col(flag_col).isin(missing_flag_codes), F.lit(1)).otherwise(F.lit(0))

    def _nonzero_flag_expr(self, safe_total: Column) -> Column:
        """Flag rule for aggregates with non-zero total value."""
        return (
            F.when(
                F.col(self._COL_HAS_E_FACTOR) == 1,
                F.lit("E"),
            )
            .when(
                F.col(self._COL_VAL_A) / safe_total >= F.lit(2.0 / 3.0),
                F.lit("A"),
            )
            .when(
                F.col(self._COL_VAL_F) / safe_total == F.lit(1.0),
                F.lit("F"),
            )
            .when(F.col(self._COL_CNT_B) > 0, F.lit("B"))
            .when(
                F.col(self._COL_VAL_X) / safe_total == F.lit(1.0),
                F.lit("X"),
            )
            .otherwise(F.lit("E"))
        )

    def _zero_flag_expr(self, safe_cnt: Column) -> Column:
        """Flag rule for aggregates with zero total value.

        First checks whether the minimum-weight member flag is a missing-data
        flag (SQL: MissingFlag = 1).  If so, that flag is used directly.
        Otherwise applies the count-based 2/3 majority rule.
        """
        min_is_missing = F.col(f"{self._COL_MIN_STRUCT}.m") == 1

        # Determine which missing flag to use (the one with minimum weight)
        missing_flag_value: Column = F.lit("M")  # fallback
        for flag, weight in self._missing_flags:
            missing_flag_value = F.when(
                F.col(f"{self._COL_MIN_STRUCT}.w") == F.lit(weight),
                F.lit(flag),
            ).otherwise(missing_flag_value)

        count_based = (
            F.when(
                F.col(self._COL_CNT_A) * 100.0 / safe_cnt >= F.lit(200.0 / 3.0),
                F.lit("A"),
            )
            .when(
                F.col(self._COL_CNT_F) * 100.0 / safe_cnt == F.lit(100.0),
                F.lit("F"),
            )
            .when(F.col(self._COL_CNT_B) >= 1, F.lit("B"))
            .when(
                F.col(self._COL_CNT_X) * 100.0 / safe_cnt == F.lit(100.0),
                F.lit("X"),
            )
            .otherwise(F.lit("E"))
        )

        return F.when(min_is_missing, missing_flag_value).otherwise(count_based)
