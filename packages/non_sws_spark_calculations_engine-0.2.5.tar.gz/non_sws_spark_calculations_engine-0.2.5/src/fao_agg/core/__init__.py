"""Core aggregation engine components."""
