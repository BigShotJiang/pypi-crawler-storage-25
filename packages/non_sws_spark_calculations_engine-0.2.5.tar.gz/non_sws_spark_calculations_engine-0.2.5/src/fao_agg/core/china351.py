"""China 351 special aggregate processor.

SQL equivalent: ``usp_China351.sql``.

The China 351 aggregate represents mainland China (code '351') and is
computed separately from the main geographic aggregation because:

- Some domains only need the China aggregate, others only the standard
  geographic aggregates, and some need both.
- The members of code '351' are configured per domain (they may differ
  from the standard area groups used in the main aggregation).
- It uses the same item-element VarLink constraint as the main procedure
  (borrowed from the VarCalc procedure for the domain).

This class is called from ``AggregationEngine`` only when a
``china_351`` config path is present in the ``AggregationConfig``.
"""

from __future__ import annotations

from datetime import datetime
from typing import Dict, List, Optional

from pyspark.sql import DataFrame, SparkSession
from pyspark.sql import functions as F
from pyspark.sql.types import IntegerType, StringType, TimestampType

from fao_common.config.schema import ColumnMapping, DataMappingConfig, DimensionDefinition

from ..config.schema import China351Config, GroupMember
from .flag_aggregator import FlagAggregator


class China351Processor:
    """Computes the China 351 special aggregate.

    The implementation mirrors the cursor loop in ``usp_China351.sql``:

    1. Optionally delete existing rows with area code = 351.
    2. Join eligible data rows with the member list.
    3. Group by all dimensions except area, replacing area with '351'.
    4. Compute ``SUM(value * factor)`` and determine the aggregate flag.
    5. Attach dissemination flags.
    """

    def __init__(
        self,
        data_mapping: DataMappingConfig,
        china351_config: China351Config,
        flag_aggregator: FlagAggregator,
        spark: SparkSession,
    ) -> None:
        self.data_mapping = data_mapping
        self.config = china351_config
        self.flag_agg = flag_aggregator
        self.spark = spark
        self._dim_by_name: Dict[str, DimensionDefinition] = {
            d.name: d for d in data_mapping.dimensions
        }

    def process(
        self,
        working_data: DataFrame,
        area_dim_name: str = "area",
        additional_datasets: Optional[Dict[str, DataFrame]] = None,
        valid_combinations: Optional[List[Dict[str, str]]] = None,
    ) -> DataFrame:
        """Compute and inject the China 351 aggregate.

        Args:
            working_data: Current working DataFrame.
            area_dim_name: Semantic name of the area dimension.
            additional_datasets: Extra datasets (unused currently, reserved
                for future cross-domain extensions).
            valid_combinations: Optional list of dimension-value dicts that
                the aggregate output must match.  Mirrors the tbl_VarLink
                DELETE step in usp_China351.sql (removes rows whose dimension
                combination is not in the allowed set).  When ``None``, no
                combination filtering is applied.

        Returns:
            Working DataFrame with China 351 aggregate rows added.
        """
        area_dim = self._dim_by_name.get(area_dim_name)
        if area_dim is None:
            raise ValueError(
                f"Area dimension '{area_dim_name}' not found in data mapping"
            )

        # Step 1: delete existing rows with the 351 group code
        if self.config.delete_existing:
            working_data = working_data.filter(
                F.col(area_dim.column) != self.config.group_code
            )

        # Step 2: build member DataFrame
        member_codes = [m.code for m in self.config.members]
        factors = {m.code: m.factor for m in self.config.members}

        member_rows = [(m.code, m.factor) for m in self.config.members]
        member_df = self.spark.createDataFrame(
            member_rows, schema=["_china_member_code", "_china_factor"]
        )

        # Step 3: filter eligible rows (same eligibility rules as main aggregation)
        cols = self.data_mapping.columns
        eligible = working_data.filter(F.col(area_dim.column).isin(member_codes))

        if self.config.var_filters:
            for dim_name, allowed_codes in self.config.var_filters.items():
                dim = self._dim_by_name.get(dim_name)
                if dim:
                    eligible = eligible.filter(F.col(dim.column).isin(allowed_codes))

        # Step 4: join with member factors
        joined = eligible.join(
            member_df,
            eligible[area_dim.column] == member_df["_china_member_code"],
            "inner",
        )

        # Step 5: group by all dimensions except area
        other_dims = [d for d in self.data_mapping.dimensions if d.name != area_dim_name]

        flag_agg_exprs = self.flag_agg.agg_expressions(cols.flag, cols.value, "_china_factor")

        opt_flag_agg = []
        if cols.agg_flag_int:
            opt_flag_agg.append(F.min(F.col(cols.agg_flag_int)).alias(cols.agg_flag_int))
        if cols.agg_flag_ext:
            opt_flag_agg.append(F.min(F.col(cols.agg_flag_ext)).alias(cols.agg_flag_ext))

        aggregated = (
            joined
            .groupBy(*[F.col(d.column) for d in other_dims])
            .agg(
                F.sum(F.col(cols.value) * F.col("_china_factor")).alias("_total_value"),
                *flag_agg_exprs,
                *opt_flag_agg,
            )
        )

        # Step 6: apply flag rules and rename value column.
        # China 351 uses count-based flag logic (mirrors the SQL's second flag
        # UPDATE, which applies count-based 2/3 majority to all rows regardless
        # of whether the aggregate total is zero or non-zero).
        aggregated = self.flag_agg.apply_flag_rules(
            aggregated, "_total_value", cols.flag, force_count_based=True
        )
        aggregated = aggregated.withColumnRenamed("_total_value", cols.value)
        aggregated = aggregated.drop(*self.flag_agg.intermediate_columns)

        # Step 7: add fixed columns
        aggregated = aggregated.withColumn(
            area_dim.column, F.lit(self.config.group_code).cast(StringType())
        )

        if cols.load_date:
            aggregated = aggregated.withColumn(
                cols.load_date, F.lit(datetime.now()).cast(TimestampType())
            )
        if cols.note:
            aggregated = aggregated.withColumn(cols.note, F.lit(None).cast(StringType()))
        if cols.diss_flag_int:
            aggregated = aggregated.withColumn(
                cols.diss_flag_int, F.lit(self.config.diss_flag_int).cast(IntegerType())
            )
        if cols.diss_flag_ext:
            aggregated = aggregated.withColumn(
                cols.diss_flag_ext, F.lit(self.config.diss_flag_ext).cast(IntegerType())
            )

        # Step 8: select output columns in canonical order
        output_cols = (
            [d.column for d in sorted(self.data_mapping.dimensions, key=lambda d: d.var_position)]
            + [cols.value, cols.flag]
        )
        for c in [cols.note, cols.load_date, cols.diss_flag_int,
                  cols.diss_flag_ext, cols.agg_flag_int, cols.agg_flag_ext]:
            if c:
                output_cols.append(c)

        existing = set(aggregated.columns)
        aggregated = aggregated.select(*[c for c in output_cols if c in existing])

        # Step 9: apply valid_combinations filter (mirrors the tbl_VarLink DELETE
        # step in usp_China351.sql that removes rows whose dimension-pair combination
        # is not approved for aggregation).
        if valid_combinations:
            aggregated = self._apply_valid_combinations(aggregated, valid_combinations)

        return working_data.union(aggregated)

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _apply_valid_combinations(
        self, df: DataFrame, valid_combinations: List[Dict[str, str]]
    ) -> DataFrame:
        """Filter aggregate output to only rows matching valid_combinations.

        Mirrors the tbl_VarLink DELETE step in usp_China351.sql: removes
        aggregate rows whose dimension values are not in the allowed set.
        """
        if not valid_combinations:
            return df

        dim_names = list(valid_combinations[0].keys())
        dims = [self._dim_by_name.get(n) for n in dim_names]
        if any(d is None for d in dims):
            return df

        col_aliases = [f"_vc351_{n}" for n in dim_names]
        rows = [tuple(combo[n] for n in dim_names) for combo in valid_combinations]
        vc_df = F.broadcast(self.spark.createDataFrame(rows, schema=col_aliases))

        join_cond = None
        for dim, alias in zip(dims, col_aliases):
            cond = df[dim.column] == F.col(alias)
            join_cond = cond if join_cond is None else join_cond & cond

        return df.join(vc_df, join_cond, "inner").drop(*col_aliases)
