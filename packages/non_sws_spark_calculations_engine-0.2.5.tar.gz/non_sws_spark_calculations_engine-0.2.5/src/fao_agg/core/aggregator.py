"""Core aggregation logic: DELETE existing → INSERT new aggregates.

SQL equivalent: the main DELETE + INSERT + flag UPDATE block inside the
cursor loop of ``usp_Aggregates.sql`` (lines 183-619).

Pipeline per dimension
----------------------
1. Build a group membership DataFrame from the GroupsConfig.
2. Filter the working dataset to rows eligible for aggregation
   (AggFlagExt IN (99, col_pos) OR AggFlagInt IN (100, 99, col_pos)).
3. Optionally apply valid_combinations filter.
4. Remove existing aggregate rows from the working dataset (DELETE).
5. Join eligible rows with group membership on member code.
6. GROUP BY (all other dimensions + group_code): compute SUM(value * factor)
   and all flag statistics in one pass.
7. Apply flag rules to determine the aggregate flag.
8. Return new aggregate rows for UNION with the working dataset.
"""

from __future__ import annotations

from datetime import datetime
from typing import Dict, List, Optional

from pyspark.sql import DataFrame, SparkSession
from pyspark.sql import functions as F
from pyspark.sql.types import IntegerType, StringType, TimestampType

from fao_common.config.schema import DataMappingConfig, DimensionDefinition

from ..config.schema import AggregateGroup, AggregationIteration, GroupsConfig
from .flag_aggregator import FlagAggregator

# Sentinel value used by AggJoin to tag pre-aggregation rows.
AGG_FLAG_INT_JOIN = 100


class Aggregator:
    """Executes one aggregation dimension pass on a working DataFrame.

    Parameters
    ----------
    data_mapping:
        Full data mapping for the domain (dimensions, columns).
    groups_config:
        Merged groups configuration (base + domain override).
    flag_aggregator:
        Flag aggregation logic instance.
    spark:
        Active SparkSession.
    """

    def __init__(
        self,
        data_mapping: DataMappingConfig,
        groups_config: GroupsConfig,
        flag_aggregator: FlagAggregator,
        spark: SparkSession,
        valid_combinations: Optional[List[Dict[str, str]]] = None,
    ) -> None:
        self.data_mapping = data_mapping
        self.groups_config = groups_config
        self.flag_agg = flag_aggregator
        self.spark = spark
        self._valid_combinations: List[Dict[str, str]] = valid_combinations or []
        self._dim_by_name: Dict[str, DimensionDefinition] = {
            d.name: d for d in data_mapping.dimensions
        }

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def run_iteration(
        self,
        working_data: DataFrame,
        iteration_cfg: AggregationIteration,
    ) -> DataFrame:
        """Run one full aggregation iteration (potentially multiple dimensions).

        Dimensions are processed in the order listed in ``iteration_cfg.agg_dimensions``
        (cascading: each dimension's output is folded into the working data
        before the next dimension runs).

        Args:
            working_data: Current working DataFrame (original + previously computed aggregates).
            iteration_cfg: Configuration for this iteration.

        Returns:
            Updated working DataFrame including new aggregate rows.
        """
        for dim_name in iteration_cfg.agg_dimensions:
            working_data = self._aggregate_dimension(
                working_data, dim_name, iteration_cfg
            )
        return working_data

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _aggregate_dimension(
        self,
        working_data: DataFrame,
        dim_name: str,
        iteration_cfg: AggregationIteration,
    ) -> DataFrame:
        """Aggregate one dimension: delete existing → insert new aggregates.

        Args:
            working_data: Current working DataFrame.
            dim_name: Semantic name of the dimension being aggregated (e.g. 'area').
            iteration_cfg: Iteration configuration.

        Returns:
            Working DataFrame with new aggregates added.
        """
        agg_dim = self._dim_by_name.get(dim_name)
        if agg_dim is None:
            raise ValueError(
                f"Dimension '{dim_name}' not found in data mapping.  "
                f"Available: {list(self._dim_by_name)}"
            )

        groups = self.groups_config.get_groups_for_dimension(dim_name)
        if not groups:
            return working_data  # nothing to do

        # Optional: restrict to specific group codes
        if iteration_cfg.group_filter:
            groups = {k: v for k, v in groups.items() if k in iteration_cfg.group_filter}

        # Step 1: build membership DataFrame
        membership_df = self._build_membership_df(groups, dim_name)
        if membership_df is None:
            return working_data

        # Step 2: delete existing aggregates for these group codes
        group_codes = list(groups.keys())
        working_data = self._delete_existing_aggregates(working_data, agg_dim, group_codes)

        # Step 3: filter eligible rows
        eligible = self._filter_eligible(working_data, agg_dim)

        # Step 4: apply per-dimension var_filters
        if iteration_cfg.var_filters:
            for filter_dim_name, allowed_codes in iteration_cfg.var_filters.items():
                filter_dim = self._dim_by_name.get(filter_dim_name)
                if filter_dim:
                    eligible = eligible.filter(F.col(filter_dim.column).isin(allowed_codes))

        # Step 5: apply valid_combinations filter (restrict to known dim-pair rows)
        # Exempt AggFlagInt=100 (AggJoin pre-aggregation rows) — their composite
        # dimension codes are not in valid_combinations by design.
        if self._valid_combinations:
            cols = self.data_mapping.columns
            if cols.agg_flag_int:
                pre_agg = eligible.filter(F.col(cols.agg_flag_int) == AGG_FLAG_INT_JOIN)
                regular = eligible.filter(F.col(cols.agg_flag_int) != AGG_FLAG_INT_JOIN)
                regular = self._apply_valid_combinations(regular)
                eligible = regular.union(pre_agg)
            else:
                eligible = self._apply_valid_combinations(eligible)

        # Step 6: join eligible rows with group membership
        joined = eligible.join(
            membership_df,
            eligible[agg_dim.column] == membership_df["_member_code"],
            "inner",
        )

        # Step 7: aggregate
        new_aggregates = self._compute_aggregates(joined, agg_dim)

        # Step 8: union new aggregates into working data
        return working_data.union(new_aggregates)

    def _build_membership_df(
        self, groups: Dict[str, AggregateGroup], dim_name: str
    ) -> Optional[DataFrame]:
        """Build a Spark DataFrame of (group_code, member_code, factor).

        Only groups that have members defined are included.
        """
        rows = []
        for group_code, group in groups.items():
            if not group.members:
                continue
            for member in group.members:
                rows.append((group_code, member.code, float(member.factor)))

        if not rows:
            return None

        return self.spark.createDataFrame(
            rows, schema=["_group_code", "_member_code", "_factor"]
        )

    def _delete_existing_aggregates(
        self,
        working_data: DataFrame,
        agg_dim: DimensionDefinition,
        group_codes: List[str],
    ) -> DataFrame:
        """Remove rows where the aggregating dimension matches any group code.

        Mirrors ``DELETE FROM d ... WHERE vgv.VarGroupCode = d.VarXCode``.
        """
        return working_data.filter(
            ~F.col(agg_dim.column).isin(group_codes)
        )

    def _filter_eligible(
        self, data: DataFrame, agg_dim: DimensionDefinition
    ) -> DataFrame:
        """Keep only rows eligible for aggregation based on AggFlag values.

        SQL equivalent::

            AggFlagExt IN (99, col_pos)
            OR AggFlagInt IN (100, 99, col_pos)

        ``col_pos`` is the var_position of the aggregating dimension (1-7).
        AggFlagInt=100 marks pre-aggregation rows from AggJoin.
        """
        cols = self.data_mapping.columns
        col_pos = agg_dim.var_position

        conditions = []

        if cols.agg_flag_ext:
            conditions.append(
                F.col(cols.agg_flag_ext).isin(99, col_pos)
            )
        if cols.agg_flag_int:
            conditions.append(
                F.col(cols.agg_flag_int).isin(AGG_FLAG_INT_JOIN, 99, col_pos)
            )

        if not conditions:
            return data  # no agg flags configured — include all rows

        combined = conditions[0]
        for c in conditions[1:]:
            combined = combined | c

        return data.filter(combined)

    def _apply_valid_combinations(self, data: DataFrame) -> DataFrame:
        """Filter rows to only include known dimension-pair combinations.

        Reads from ``self._valid_combinations``, a list of dicts keyed by
        dimension name, e.g. ``[{"item": "22073", "element": "6110"}, ...]``.
        Dimension names are resolved to physical columns via ``self._dim_by_name``.

        Mirrors the ``INNER JOIN tbl_VarLink`` in the SQL.
        """
        combos = self._valid_combinations
        if not combos:
            return data

        dim_names = list(combos[0].keys())
        dims = [self._dim_by_name.get(n) for n in dim_names]
        if any(d is None for d in dims):
            return data

        col_aliases = [f"_vc_{n}" for n in dim_names]
        rows = [tuple(combo[n] for n in dim_names) for combo in combos]
        vc_df = F.broadcast(self.spark.createDataFrame(rows, schema=col_aliases))

        join_cond = None
        for dim, alias in zip(dims, col_aliases):
            cond = data[dim.column] == F.col(alias)
            join_cond = cond if join_cond is None else join_cond & cond

        return data.join(vc_df, join_cond, "inner").drop(*col_aliases)

    def _compute_aggregates(
        self,
        joined: DataFrame,
        agg_dim: DimensionDefinition,
    ) -> DataFrame:
        """Perform the GROUP BY aggregation and assemble the result DataFrame.

        Returns a DataFrame with the same schema as the input data, ready
        to be unioned into the working dataset.
        """
        cols = self.data_mapping.columns

        # Dimensions that keep their original value (all except the agg dim)
        other_dims = [d for d in self.data_mapping.dimensions if d.name != agg_dim.name]

        flag_agg_exprs = self.flag_agg.agg_expressions(cols.flag, cols.value, "_factor")

        aggregated = (
            joined
            .groupBy(F.col("_group_code").alias(agg_dim.column), *[F.col(d.column) for d in other_dims])
            .agg(*flag_agg_exprs,
                 F.sum(F.col(cols.value) * F.col("_factor")).alias("_total_value"),
                 *(F.min(F.col(cols.agg_flag_int)).alias(cols.agg_flag_int),) if cols.agg_flag_int else (),
                 *(F.min(F.col(cols.agg_flag_ext)).alias(cols.agg_flag_ext),) if cols.agg_flag_ext else (),
                 )
        )

        # Apply flag rules
        aggregated = self.flag_agg.apply_flag_rules(aggregated, "_total_value", cols.flag)

        # Rename _total_value → value column
        aggregated = aggregated.withColumnRenamed("_total_value", cols.value)

        # Drop intermediate flag statistics columns
        aggregated = aggregated.drop(*self.flag_agg.intermediate_columns)

        # Add optional columns not produced by aggregation so that the schema
        # stays consistent with the working dataset for union compatibility.
        if cols.load_date:
            aggregated = aggregated.withColumn(
                cols.load_date, F.lit(datetime.now()).cast(TimestampType())
            )
        if cols.note:
            aggregated = aggregated.withColumn(
                cols.note, F.lit(None).cast(StringType())
            )
        if cols.diss_flag_int:
            aggregated = aggregated.withColumn(
                cols.diss_flag_int, F.lit(None).cast(IntegerType())
            )
        if cols.diss_flag_ext:
            aggregated = aggregated.withColumn(
                cols.diss_flag_ext, F.lit(None).cast(IntegerType())
            )

        # Select final columns in canonical order (matching input schema)
        return self._select_output_columns(aggregated)

    def _select_output_columns(self, df: DataFrame) -> DataFrame:
        """Select and order output columns to match the canonical data schema."""
        cols = self.data_mapping.columns
        output_cols = (
            [d.column for d in sorted(self.data_mapping.dimensions, key=lambda d: d.var_position)]
            + [cols.value, cols.flag]
        )
        if cols.note:
            output_cols.append(cols.note)
        if cols.load_date:
            output_cols.append(cols.load_date)
        if cols.diss_flag_int:
            output_cols.append(cols.diss_flag_int)
        if cols.diss_flag_ext:
            output_cols.append(cols.diss_flag_ext)
        if cols.agg_flag_int:
            output_cols.append(cols.agg_flag_int)
        if cols.agg_flag_ext:
            output_cols.append(cols.agg_flag_ext)

        # Only select columns that actually exist in the DataFrame
        existing = set(df.columns)
        return df.select(*[c for c in output_cols if c in existing])
