"""Main aggregation engine orchestrating the full pipeline.

Usage example::

    from fao_agg import AggregationEngine

    engine = AggregationEngine(
        data_mapping="configs/data_mapping.json",
        aggregation_config="configs/domains/CS/aggregation.json",
    )
    result = (
        engine
        .load_data("data/DataCS.csv")
        .aggregate()
        .get_results()
    )

Pipeline
--------
For each iteration (in ascending order):

1. Run ``AggJoinProcessor`` (if ``agg_join`` is configured) to insert
   pre-aggregation rows (``AggFlagInt = 100``).
2. Run ``Aggregator.run_iteration()`` for each aggregation dimension
   (cascading: each dimension's output feeds the next).
3. Remove ``AggFlagInt = 100`` rows from the working dataset.

After all iterations:

4. Optionally run ``China351Processor`` (if ``china_351`` is configured).
5. Return the final DataFrame (original data + all new aggregates).
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Dict, List, Optional, Union

logger = logging.getLogger(__name__)

from pyspark.sql import DataFrame, SparkSession
from pyspark.sql import functions as F
from pyspark.sql.types import IntegerType

from fao_common.adapters import DataAdapter, create_adapter
from fao_common.adapters import load_additional_dataset as _load_additional_dataset
from fao_common.adapters.sdmx import SdmxDataAdapter
from fao_common.config.loader import load_data_mapping
from fao_common.config.schema import DataMappingConfig, SdmxDataSource
from fao_common.spark.session import create_spark_session

from ..config.loader import (
    load_aggregation_config,
    load_agg_join_config,
    load_china351_config,
    load_merged_groups,
)
from ..config.schema import AggregationConfig, China351Config
from .agg_join import AggJoinProcessor, _AGG_FLAG_INT_JOIN
from .aggregator import Aggregator
from .china351 import China351Processor
from .flag_aggregator import DEFAULT_FLAG_WEIGHTS, FlagAggregator


class AggregationEngine:
    """Configuration-driven aggregation engine for FAO statistical data.

    Parameters
    ----------
    data_mapping:
        ``DataMappingConfig``, file path, JSON string, or dict describing
        the domain's dimensions and column names.
    aggregation_config:
        ``AggregationConfig``, file path, JSON string, or dict describing
        iterations, groups, and optional AggJoin / China 351 steps.
    spark:
        Optional existing ``SparkSession``.  A local session is created
        automatically when not provided (suitable for testing).
    config_base_dir:
        Base directory used to resolve relative paths inside
        ``aggregation_config`` (e.g. ``base_groups``, ``agg_join``).
        Defaults to the current working directory.
    flag_weights:
        Optional custom flag weight table (``{flag: (weight, is_missing)}``).
        Defaults to the standard FAO flag hierarchy.
    """

    def __init__(
        self,
        data_mapping: Union[str, Path, dict, DataMappingConfig],
        aggregation_config: Union[str, Path, dict, AggregationConfig],
        spark: Optional[SparkSession] = None,
        config_base_dir: Optional[Union[str, Path]] = None,
        flag_weights: Optional[Dict[str, tuple[float, bool]]] = None,
    ) -> None:
        # Load configurations
        self.data_mapping = (
            data_mapping
            if isinstance(data_mapping, DataMappingConfig)
            else load_data_mapping(data_mapping)
        )
        self.aggregation_cfg = (
            aggregation_config
            if isinstance(aggregation_config, AggregationConfig)
            else load_aggregation_config(aggregation_config)
        )

        self._base_dir = Path(config_base_dir) if config_base_dir else Path.cwd()

        # Spark session
        self.spark = spark or create_spark_session(local=True)

        # Flag weights
        self.flag_aggregator = FlagAggregator(flag_weights or DEFAULT_FLAG_WEIGHTS)

        # Resolve and merge groups
        self.groups_config = load_merged_groups(self.aggregation_cfg, self._base_dir)

        # Build core components
        self.aggregator = Aggregator(
            self.data_mapping, self.groups_config, self.flag_aggregator, self.spark,
            valid_combinations=self.aggregation_cfg.valid_combinations,
        )

        # Optional AggJoin processor
        self._agg_join_processor: Optional[AggJoinProcessor] = None
        if self.aggregation_cfg.agg_join:
            agg_join_val = self.aggregation_cfg.agg_join
            if isinstance(agg_join_val, dict):
                agg_join_cfg = load_agg_join_config(agg_join_val)
            else:
                agg_join_cfg = load_agg_join_config(self._resolve(agg_join_val))
            self._agg_join_processor = AggJoinProcessor(
                self.data_mapping, agg_join_cfg, self.spark
            )

        # Optional China 351 processor
        self._china351_processor: Optional[China351Processor] = None
        if self.aggregation_cfg.china_351:
            china_351_val = self.aggregation_cfg.china_351
            if isinstance(china_351_val, dict):
                # Inline dict — validate directly as China351Config
                china_cfg = China351Config.model_validate(china_351_val)
            else:
                # File path — resolve and load from disk
                china_cfg = load_china351_config(self._resolve(china_351_val))
            self._china351_processor = China351Processor(
                self.data_mapping, china_cfg, self.flag_aggregator, self.spark
            )

        # Data adapter — chosen once based on data_source type
        self._adapter: DataAdapter = create_adapter(self.data_mapping.data_source)

        # Runtime state
        self._data: Optional[DataFrame] = None
        self._results: Optional[DataFrame] = None
        self.additional_datasets: Dict[str, DataFrame] = {}

    # ------------------------------------------------------------------
    # Data loading
    # ------------------------------------------------------------------

    def load_data(
        self,
        path: Optional[Union[str, Path]] = None,
        dataframe: Optional[DataFrame] = None,
    ) -> "AggregationEngine":
        """Load the primary input dataset.

        Args:
            path: Path to a data file (overrides the path in data_mapping config).
            dataframe: Pre-loaded Spark DataFrame (alternative to a file path).

        Returns:
            Self for method chaining.
        """
        if dataframe is not None:
            # If the adapter is SDMX and the DataFrame still has SDMX columns,
            # transform it to internal column names automatically.
            if isinstance(self._adapter, SdmxDataAdapter):
                dim_cols = {d.column for d in self.data_mapping.dimensions}
                if not dim_cols.issubset(set(dataframe.columns)):
                    dataframe = self._adapter.transform_dataframe(
                        dataframe, self.data_mapping
                    )
            self._data = dataframe
        else:
            resolved = Path(path) if path is not None else None
            self._data = self._adapter.load(resolved, self.spark, self.data_mapping)
        return self

    def load_additional_dataset(
        self,
        dataset_id: str,
        path: Optional[Union[str, Path]] = None,
        dataframe: Optional[DataFrame] = None,
        data_mapping: Optional[Union[str, Path, dict, DataMappingConfig]] = None,
        sdmx_source: Optional[Union[dict, SdmxDataSource]] = None,
    ) -> "AggregationEngine":
        """Load an additional dataset (e.g. for cross-domain AggJoin denominators).

        Delegates to :func:`fao_common.adapters.load_additional_dataset` and
        stores the result in :attr:`additional_datasets`.

        Returns:
            Self for method chaining.
        """
        self.additional_datasets[dataset_id] = _load_additional_dataset(
            dataset_id=dataset_id,
            spark=self.spark,
            primary_data_mapping=self.data_mapping,
            path=path,
            dataframe=dataframe,
            data_mapping=data_mapping,
            sdmx_source=sdmx_source,
        )
        return self

    # ------------------------------------------------------------------
    # Additional-dataset optimisation (pre-filter + cache)
    # ------------------------------------------------------------------

    def _prepare_additional_datasets(self) -> Dict[str, DataFrame]:
        """Pre-filter and cache additional datasets before aggregation.

        Scans every AggJoin rule (simple and ratio-of-ratios) to collect
        the union of all dimension-code values each additional dataset will
        ever be filtered to.  Each dataset is then:

        1. Filtered to only the rows that *any* rule will actually use.
        2. Cached so Spark doesn't re-evaluate for each rule.

        Returns a dict of ``dataset_id -> cached DataFrame``.  The
        originals in :attr:`additional_datasets` are **not** mutated.
        """
        if not self.additional_datasets or self._agg_join_processor is None:
            return {}

        # Collect required filter values: {dataset_id: {dim_name: {values}}}
        needed: Dict[str, Dict[str, set]] = {}

        def _collect_component(comp) -> None:
            if not comp.dataset or comp.dataset not in self.additional_datasets:
                return
            ds_needed = needed.setdefault(comp.dataset, {})
            for dim_name, code in comp.dimension_codes().items():
                ds_needed.setdefault(dim_name, set()).add(code)

        for rule in self._agg_join_processor.config.rules:
            if rule.is_ratio_of_ratios:
                _collect_component(rule.numerator_ratio.numerator)
                _collect_component(rule.numerator_ratio.denominator)
                _collect_component(rule.denominator_ratio.numerator)
                _collect_component(rule.denominator_ratio.denominator)
            else:
                _collect_component(rule.numerator)
                _collect_component(rule.denominator)

        # Pre-filter + cache each referenced dataset
        prepared: Dict[str, DataFrame] = {}
        dim_map = {d.name: d for d in self.data_mapping.dimensions}

        for ds_id, df in self.additional_datasets.items():
            filters = needed.get(ds_id)
            if not filters:
                prepared[ds_id] = df
                continue

            filtered = df
            for dim_name, values in filters.items():
                dim = dim_map.get(dim_name)
                if dim is None:
                    continue
                if len(values) == 1:
                    filtered = filtered.filter(F.col(dim.column) == next(iter(values)))
                else:
                    filtered = filtered.filter(F.col(dim.column).isin(list(values)))

            prepared[ds_id] = filtered.cache()
            logger.info(
                "Additional dataset '%s': pre-filtered to %d dimension filter(s) and cached.",
                ds_id,
                len(filters),
            )

        return prepared

    @staticmethod
    def _unpersist_additional_datasets(prepared: Dict[str, DataFrame]) -> None:
        """Unpersist any cached additional datasets."""
        for df in prepared.values():
            if df.is_cached:
                df.unpersist()

    # ------------------------------------------------------------------
    # Aggregation
    # ------------------------------------------------------------------

    def aggregate(
        self,
        iterations: Optional[List[int]] = None,
        run_china351: bool = True,
    ) -> "AggregationEngine":
        """Run the full aggregation pipeline.

        Args:
            iterations: Specific iteration numbers to run.  Defaults to all
                iterations defined in the configuration, in ascending order.
            run_china351: Whether to run the China 351 step (if configured).
                Set to ``False`` to skip it.

        Returns:
            Self for method chaining.

        Raises:
            ValueError: If ``load_data()`` has not been called yet.
        """
        if self._data is None:
            raise ValueError("No data loaded. Call load_data() before aggregate().")

        working = self._normalize_schema(self._data)

        # Pre-filter and cache additional datasets
        prepared = self._prepare_additional_datasets()
        active_additional = prepared or self.additional_datasets

        # Determine which iterations to run
        all_iterations = sorted(
            {it.iteration for it in self.aggregation_cfg.iterations}
        )
        iterations_to_run = (
            [i for i in all_iterations if i in iterations]
            if iterations is not None
            else all_iterations
        )

        try:
            for iter_num in iterations_to_run:
                iter_cfg = next(
                    (it for it in self.aggregation_cfg.iterations if it.iteration == iter_num),
                    None,
                )
                if iter_cfg is None:
                    continue

                # AggJoin pre-processing (runs once per iteration)
                if self._agg_join_processor is not None:
                    working = self._agg_join_processor.process(working, active_additional)

                # Main aggregation (cascading across dimensions)
                working = self.aggregator.run_iteration(working, iter_cfg)

                # Compute ratio indicators from aggregated pre-agg rows
                # (must happen BEFORE the AggFlagInt=100 cleanup)
                if self._agg_join_processor is not None:
                    ratio_rows = self._agg_join_processor.compute_ratios(working)
                    if ratio_rows is not None:
                        working = working.union(ratio_rows)

                # Remove AggJoin intermediate rows after aggregation
                cols = self.data_mapping.columns
                if cols.agg_flag_int:
                    working = working.filter(
                        F.col(cols.agg_flag_int) != _AGG_FLAG_INT_JOIN
                    )

            # China 351 special aggregate (independent of main iterations)
            if run_china351 and self._china351_processor is not None:
                working = self._china351_processor.process(
                    working,
                    additional_datasets=active_additional,
                    valid_combinations=self.aggregation_cfg.valid_combinations,
                )
        finally:
            self._unpersist_additional_datasets(prepared)

        self._results = working
        return self

    # ------------------------------------------------------------------
    # Results access
    # ------------------------------------------------------------------

    def get_results(self) -> Optional[DataFrame]:
        """Return the aggregated DataFrame, or ``None`` if not yet computed."""
        return self._results

    def get_new_aggregates(self) -> Optional[DataFrame]:
        """Return only the rows that are new aggregate groups.

        Filters to rows whose dimension values match known group codes
        from standard aggregation groups and/or the China 351 group code.
        """
        if self._results is None:
            return None

        all_group_codes: Dict[str, set] = {}
        for dim_type, groups in self.groups_config.groups.items():
            all_group_codes[dim_type] = {g.code for g in groups}

        conditions = []
        for dim_type, codes in all_group_codes.items():
            dim = self.data_mapping.get_dimension(dim_type)
            if dim and codes:
                conditions.append(F.col(dim.column).isin(list(codes)))

        # Include China 351 group code (mapped to the area dimension)
        if self._china351_processor is not None:
            area_dim = self.data_mapping.get_dimension("area")
            if area_dim:
                china_code = self._china351_processor.config.group_code
                conditions.append(F.col(area_dim.column) == china_code)

        if not conditions:
            return self._results

        combined = conditions[0]
        for c in conditions[1:]:
            combined = combined | c

        return self._results.filter(combined)

    # ------------------------------------------------------------------
    # Output
    # ------------------------------------------------------------------

    def write_csv(
        self, path: Union[str, Path], mode: str = "overwrite", **options
    ) -> "AggregationEngine":
        """Write results to CSV.

        Args:
            path: Output path.
            mode: Spark write mode (``"overwrite"``, ``"append"``, etc.).

        Returns:
            Self for method chaining.
        """
        self._require_results()
        self._results.write.csv(str(path), header=True, mode=mode, **options)
        return self

    def write_parquet(
        self, path: Union[str, Path], mode: str = "overwrite", **options
    ) -> "AggregationEngine":
        """Write results to Parquet."""
        self._require_results()
        self._results.write.parquet(str(path), mode=mode, **options)
        return self

    def write_delta(
        self, path: Union[str, Path], mode: str = "overwrite", **options
    ) -> "AggregationEngine":
        """Write results to Delta Lake."""
        self._require_results()
        self._results.write.format("delta").mode(mode).save(str(path), **options)
        return self

    def show(self, n: int = 20, truncate: bool = True) -> "AggregationEngine":
        """Display results in the console."""
        self._require_results()
        self._results.show(n, truncate)
        return self

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    def _resolve(self, path_str: str) -> Path:
        """Resolve a path relative to config_base_dir."""
        p = Path(path_str)
        return p if p.is_absolute() else self._base_dir / p

    def _normalize_schema(self, data: DataFrame) -> DataFrame:
        """Select only the mapped columns and enforce correct types.

        - Dimension columns are trimmed and cast to STRING so that
          space-padded CSV values (e.g. ' 1006') do not cause BIGINT cast
          failures when joining with the config-derived membership DataFrame.
        - Integer flag columns are trimmed and cast to IntegerType for safe
          numeric comparisons in the eligibility filter.
        """
        cols = self.data_mapping.columns
        int_flag_cols = {
            c for c in (
                cols.agg_flag_int, cols.agg_flag_ext,
                cols.diss_flag_int, cols.diss_flag_ext,
            )
            if c
        }

        # Dimension columns: trim whitespace + cast to STRING
        select_exprs = [
            F.trim(F.col(d.column)).cast("string").alias(d.column)
            for d in self.data_mapping.dimensions
        ]
        select_exprs += [F.col(cols.value), F.col(cols.flag)]

        for optional in [
            cols.note, cols.load_date,
            cols.diss_flag_int, cols.diss_flag_ext,
            cols.agg_flag_int, cols.agg_flag_ext,
        ]:
            if not optional:
                continue
            if optional not in data.columns:
                # Column configured but absent (e.g. SDMX sources don't carry
                # Note/LoadDate/DissFlag/AggFlag).  Add a typed NULL so
                # downstream union() calls always see a consistent schema.
                if optional in int_flag_cols:
                    select_exprs.append(
                        F.lit(None).cast(IntegerType()).alias(optional)
                    )
                else:
                    select_exprs.append(
                        F.lit(None).cast("string").alias(optional)
                    )
            elif optional in int_flag_cols:
                # Trim + cast to INT; handles space-padded CSV values
                select_exprs.append(
                    F.trim(F.col(optional)).cast(IntegerType()).alias(optional)
                )
            else:
                select_exprs.append(F.col(optional))

        return data.select(*select_exprs)

    def _require_results(self) -> None:
        if self._results is None:
            raise ValueError("No results yet. Call aggregate() first.")
