"""Pre-aggregation join processor for ratio-type indicators.

SQL equivalent: ``usp_Aggregates_Join.sql``.

Purpose
-------
Some indicators are ratios (e.g. "Share of Value Added").  You cannot
aggregate a ratio directly; instead you must aggregate the numerator and
denominator separately and then recalculate.  This processor inserts
intermediate rows tagged with ``AggFlagInt = 100`` that pair up the
numerator and denominator components under new "pre-aggregation" codes
(e.g. "6110-6161-22030").  The main aggregator then sums these paired
rows.  After aggregation the pre-aggregation rows are removed from the
final output.

Simple ratio
    One numerator row + one denominator row from the same (or a different)
    domain.  Both are re-inserted under pre-aggregation codes derived as
    ``"{result_dim_code}-{result_code}-{secondary_dim_code}"``.

Ratio of ratios
    The ratio result is itself the ratio of two sub-ratios (N/D).  Phase 1
    computes pre-agg rows for each sub-ratio independently.  Phase 2 then
    joins those pre-agg rows to produce the final pre-agg rows for the
    top-level result code.

Pre-aggregation code formula
    Simple:         ``"{num_result_dim}-{result_code}-{num_secondary_dim}"``
    Sub-ratio (N):  ``"{num_result_dim_n}-{sub_result_n}-{result_code}-{num_secondary_dim_n}"``
    Sub-ratio (D):  ``"{num_result_dim_d}-{sub_result_d}-{result_code}-{num_secondary_dim_d}"``
    Final (ror):    ``"{sub_result_n}-{result_code}-{num_secondary_dim_n}"`` (num)
                    ``"{sub_result_d}-{result_code}-{num_secondary_dim_d}"`` (den)
"""

from __future__ import annotations

from datetime import datetime
from typing import Dict, List, Optional

from pyspark.sql import DataFrame, SparkSession
from pyspark.sql import functions as F
from pyspark.sql.types import IntegerType, StringType, TimestampType

from fao_common.config.schema import DataMappingConfig, DimensionDefinition

from ..config.schema import AggJoinComponent, AggJoinConfig, AggJoinRule, AggJoinSubRatio

# Sentinel AggFlagInt value for pre-aggregation rows
_AGG_FLAG_INT_JOIN = 100


class AggJoinProcessor:
    """Inserts pre-aggregation rows needed for ratio indicators.

    After calling :meth:`process`, the returned DataFrame has new rows
    with ``AggFlagInt = 100``.  These must be removed from the final output
    after aggregation is complete (handled by ``AggregationEngine``).
    """

    def __init__(
        self,
        data_mapping: DataMappingConfig,
        agg_join_config: AggJoinConfig,
        spark: SparkSession,
    ) -> None:
        self.data_mapping = data_mapping
        self.config = agg_join_config
        self.spark = spark
        self._dim_by_name: Dict[str, DimensionDefinition] = {
            d.name: d for d in data_mapping.dimensions
        }

    def process(
        self,
        working_data: DataFrame,
        additional_datasets: Optional[Dict[str, DataFrame]] = None,
    ) -> DataFrame:
        """Run AggJoin pre-processing and return the augmented working dataset.

        Existing rows with ``AggFlagInt = 100`` are deleted first (mimicking
        the initial DELETE in the SQL procedure), then new pre-aggregation
        rows are inserted for each rule.

        Args:
            working_data: Current working DataFrame.
            additional_datasets: DataFrames from other domains, keyed by
                domain code (e.g. ``{"MK": mk_df}``).

        Returns:
            DataFrame with AggFlagInt=100 rows added.
        """
        cols = self.data_mapping.columns

        # Delete any existing AggFlagInt=100 rows
        if cols.agg_flag_int:
            working_data = working_data.filter(
                F.col(cols.agg_flag_int) != _AGG_FLAG_INT_JOIN
            )

        simple_rules = [r for r in self.config.rules if not r.is_ratio_of_ratios]
        ror_rules = [r for r in self.config.rules if r.is_ratio_of_ratios]

        # Phase 1: simple ratios.
        # Checkpoint after every rule to break Spark's logical-plan lineage.
        # Without per-rule checkpointing, each union re-appends the entire
        # prior plan as a child, causing exponential plan growth → OOM on
        # TreeNode analysis (Java heap / BitSet) for IC (15 rules) and FDI
        # (8 rules).
        for rule in simple_rules:
            new_rows = self._process_simple_rule(rule, working_data, additional_datasets)
            if new_rows is not None:
                working_data = working_data.union(new_rows).localCheckpoint(eager=True)

        # Phase 1: sub-ratios for ratio-of-ratios rules
        for rule in ror_rules:
            for sub_ratio in (rule.numerator_ratio, rule.denominator_ratio):
                new_rows = self._process_sub_ratio(
                    sub_ratio, rule.result_code, working_data, additional_datasets
                )
                if new_rows is not None:
                    working_data = working_data.union(new_rows).localCheckpoint(eager=True)

        # Phase 2: combine sub-ratio pre-agg rows into final pre-agg rows
        for rule in ror_rules:
            new_rows = self._process_ror_phase2(rule, working_data)
            if new_rows is not None:
                working_data = working_data.union(new_rows).localCheckpoint(eager=True)

        return working_data

    # ------------------------------------------------------------------
    # Simple ratio
    # ------------------------------------------------------------------

    def _process_simple_rule(
        self,
        rule: AggJoinRule,
        data: DataFrame,
        additional_datasets: Optional[Dict[str, DataFrame]],
    ) -> Optional[DataFrame]:
        """Insert paired num + den rows for a simple ratio.

        Both rows get ``AggFlagInt = 100`` and have their result-dimension
        code replaced with the pre-aggregation code.
        """
        result_dim = self._dim_by_name.get(self.config.result_dimension)
        secondary_dim = self._dim_by_name.get(self.config.secondary_dimension)
        if result_dim is None or secondary_dim is None:
            return None

        num_comp = rule.numerator
        den_comp = rule.denominator
        num_codes = num_comp.dimension_codes()
        den_codes = den_comp.dimension_codes()

        den_src = (
            additional_datasets.get(den_comp.dataset)
            if den_comp.dataset and additional_datasets
            else None
        )
        if den_comp.dataset and additional_datasets and den_src is None:
            return None

        # Broadcast-hint cross-dataset denominators (typically smaller)
        den_base = F.broadcast(den_src) if den_src is not None else data

        # Derive pre-aggregation codes
        num_result_code = num_codes.get(self.config.result_dimension, "")
        num_secondary_code = num_codes.get(self.config.secondary_dimension, "")
        num_agg_code = f"{num_result_code}-{rule.result_code}-{num_secondary_code}"

        den_result_code = den_codes.get(self.config.result_dimension, "")
        den_secondary_code = den_codes.get(self.config.secondary_dimension, num_secondary_code)
        den_agg_code = f"{den_result_code}-{rule.result_code}-{den_secondary_code}"

        num_df, den_df = self._filter_component(data, num_comp, result_dim, secondary_dim), \
                         self._filter_component(den_base, den_comp, result_dim, secondary_dim)
        num_df = num_df.alias("dn")
        den_df = den_df.alias("dd")

        paired = self._join_on_other_dims(num_df, den_df, result_dim, secondary_dim)

        cols = self.data_mapping.columns
        if cols.agg_flag_int:
            paired = paired.filter(
                (F.col(f"dn.{cols.agg_flag_int}") != 0) &
                (F.col(f"dd.{cols.agg_flag_int}") != 0)
            )

        if paired is None:
            return None

        num_rows = self._build_pre_agg_row(paired, "dn", result_dim, secondary_dim, num_agg_code)
        den_rows = self._build_pre_agg_row(paired, "dd", result_dim, secondary_dim, den_agg_code)

        if num_rows is None or den_rows is None:
            return None
        return num_rows.union(den_rows)

    # ------------------------------------------------------------------
    # Ratio of ratios — phase 1 (sub-ratios)
    # ------------------------------------------------------------------

    def _process_sub_ratio(
        self,
        sub: AggJoinSubRatio,
        parent_result_code: str,
        data: DataFrame,
        additional_datasets: Optional[Dict[str, DataFrame]],
    ) -> Optional[DataFrame]:
        """Insert pre-agg rows for one sub-ratio of a ratio-of-ratios rule.

        Pre-agg code formula:
            ``"{num_result_dim}-{sub.result_code}-{parent_result_code}-{num_secondary_dim}"``
        """
        result_dim = self._dim_by_name.get(self.config.result_dimension)
        secondary_dim = self._dim_by_name.get(self.config.secondary_dimension)
        if result_dim is None or secondary_dim is None:
            return None

        num_comp = sub.numerator
        den_comp = sub.denominator
        num_codes = num_comp.dimension_codes()
        den_codes = den_comp.dimension_codes()

        den_src = (
            additional_datasets.get(den_comp.dataset)
            if den_comp.dataset and additional_datasets
            else None
        )
        if den_comp.dataset and additional_datasets and den_src is None:
            return None

        # Broadcast-hint cross-dataset denominators (typically smaller)
        den_base = F.broadcast(den_src) if den_src is not None else data

        # Pre-agg codes for the sub-ratio include both sub.result_code and parent_result_code
        num_result_code = num_codes.get(self.config.result_dimension, "")
        num_secondary_code = num_codes.get(self.config.secondary_dimension, "")
        sub_agg_code = f"{num_result_code}-{sub.result_code}-{parent_result_code}-{num_secondary_code}"

        num_df = self._filter_component(data, num_comp, result_dim, secondary_dim).alias("dnn")
        den_df = self._filter_component(den_base, den_comp, result_dim, secondary_dim).alias("dnd")

        paired = self._join_on_other_dims(num_df, den_df, result_dim, secondary_dim,
                                          left_alias="dnn", right_alias="dnd")

        cols = self.data_mapping.columns
        if cols.agg_flag_int:
            paired = paired.filter(
                (F.col(f"dnn.{cols.agg_flag_int}") != 0) &
                (F.col(f"dnd.{cols.agg_flag_int}") != 0)
            )

        num_rows = self._build_pre_agg_row(paired, "dnn", result_dim, secondary_dim, sub_agg_code)
        den_rows = self._build_pre_agg_row(paired, "dnd", result_dim, secondary_dim, sub_agg_code)

        if num_rows is None or den_rows is None:
            return None
        return num_rows.union(den_rows)

    # ------------------------------------------------------------------
    # Ratio of ratios — phase 2 (combine)
    # ------------------------------------------------------------------

    def _process_ror_phase2(
        self,
        rule: AggJoinRule,
        data: DataFrame,
    ) -> Optional[DataFrame]:
        """Combine sub-ratio pre-agg rows into final pre-agg rows.

        Joins rows tagged with the N sub-ratio pre-agg code and D sub-ratio
        pre-agg code to produce final pre-agg rows tagged with the top-level
        NumAggJoinVarCode and DenAggJoinVarCode.
        """
        result_dim = self._dim_by_name.get(self.config.result_dimension)
        secondary_dim = self._dim_by_name.get(self.config.secondary_dimension)
        if result_dim is None or secondary_dim is None:
            return None

        sub_n = rule.numerator_ratio
        sub_d = rule.denominator_ratio

        num_n_codes = sub_n.numerator.dimension_codes()
        den_n_codes = sub_n.denominator.dimension_codes()
        num_d_codes = sub_d.numerator.dimension_codes()
        den_d_codes = sub_d.denominator.dimension_codes()

        # Sub-ratio pre-agg codes (must match what _process_sub_ratio produced)
        num_n_result = num_n_codes.get(self.config.result_dimension, "")
        num_n_secondary = num_n_codes.get(self.config.secondary_dimension, "")
        sub_n_agg_code = f"{num_n_result}-{sub_n.result_code}-{rule.result_code}-{num_n_secondary}"

        num_d_result = num_d_codes.get(self.config.result_dimension, "")
        num_d_secondary = num_d_codes.get(self.config.secondary_dimension, "")
        sub_d_agg_code = f"{num_d_result}-{sub_d.result_code}-{rule.result_code}-{num_d_secondary}"

        # Secondary-dim codes used to retrieve each of the four sub-ratio rows
        den_n_secondary = den_n_codes.get(self.config.secondary_dimension, "")
        den_d_secondary = den_d_codes.get(self.config.secondary_dimension, "")

        # Final pre-agg codes
        final_num_agg_code = f"{sub_n.result_code}-{rule.result_code}-{num_n_secondary}"
        final_den_agg_code = f"{sub_d.result_code}-{rule.result_code}-{den_d_secondary}"

        # Skip if already inserted
        existing = set(
            row[0] for row in
            data.filter(F.col(result_dim.column).isin(final_num_agg_code, final_den_agg_code))
            .select(result_dim.column).distinct().collect()
        )
        if final_num_agg_code in existing and final_den_agg_code in existing:
            return None

        rc = result_dim.column
        sc = secondary_dim.column

        dnn = data.filter(
            (F.col(rc) == sub_n_agg_code) & (F.col(sc) == num_n_secondary)
        ).alias("dnn")
        dnd = data.filter(
            (F.col(rc) == sub_n_agg_code) & (F.col(sc) == den_n_secondary)
        ).alias("dnd")
        ddn = data.filter(
            (F.col(rc) == sub_d_agg_code) & (F.col(sc) == num_d_secondary)
        ).alias("ddn")
        ddd = data.filter(
            (F.col(rc) == sub_d_agg_code) & (F.col(sc) == den_d_secondary)
        ).alias("ddd")

        join_dims = self._other_dims(result_dim, secondary_dim)
        if not join_dims:
            return None

        def _cond(left: str, right: str):
            c = F.col(f"{left}.{join_dims[0].column}") == F.col(f"{right}.{join_dims[0].column}")
            for d in join_dims[1:]:
                c = c & (F.col(f"{left}.{d.column}") == F.col(f"{right}.{d.column}"))
            return c

        paired = (
            dnn
            .join(dnd, _cond("dnn", "dnd"), "inner")
            .join(ddn, _cond("dnn", "ddn"), "inner")
            .join(ddd, _cond("dnn", "ddd"), "inner")
        )

        cols = self.data_mapping.columns
        if cols.agg_flag_int:
            paired = paired.filter(
                (F.col(f"dnn.{cols.agg_flag_int}") != 0) &
                (F.col(f"dnd.{cols.agg_flag_int}") != 0) &
                (F.col(f"ddn.{cols.agg_flag_int}") != 0) &
                (F.col(f"ddd.{cols.agg_flag_int}") != 0)
            )

        all_rows = []
        if final_num_agg_code not in existing:
            r = self._build_pre_agg_row(paired, "dnn", result_dim, secondary_dim, final_num_agg_code)
            if r is not None:
                all_rows.append(r)
        if final_den_agg_code not in existing:
            r = self._build_pre_agg_row(paired, "dnd", result_dim, secondary_dim, final_den_agg_code)
            if r is not None:
                all_rows.append(r)

        if not all_rows:
            return None
        result = all_rows[0]
        for df in all_rows[1:]:
            result = result.union(df)
        return result

    # ------------------------------------------------------------------
    # Post-aggregation ratio computation
    # ------------------------------------------------------------------

    def compute_ratios(
        self,
        working_data: DataFrame,
        multiplier: float = 100.0,
    ) -> Optional[DataFrame]:
        """Compute ratio indicators from aggregated pre-agg rows.

        After the main aggregation sums the paired pre-agg rows, this method
        joins the aggregated numerator and denominator composite codes and
        divides them to produce the final ratio result rows.

        Must be called BEFORE the ``AggFlagInt = 100`` cleanup.

        Args:
            working_data: Working DataFrame containing aggregated pre-agg rows.
            multiplier: Multiplier for the ratio (default 100.0 for percentages).

        Returns:
            DataFrame of new ratio rows (without ``AggFlagInt = 100``),
            or ``None`` if no ratios could be computed.
        """
        result_dim = self._dim_by_name.get(self.config.result_dimension)
        secondary_dim = self._dim_by_name.get(self.config.secondary_dimension)
        if result_dim is None or secondary_dim is None:
            return None

        cols = self.data_mapping.columns
        rc = result_dim.column
        sc = secondary_dim.column

        if not cols.agg_flag_int:
            return None
        pre_agg = working_data.filter(F.col(cols.agg_flag_int) == _AGG_FLAG_INT_JOIN)

        all_ratios = []
        simple_rules = [r for r in self.config.rules if not r.is_ratio_of_ratios]

        for rule in simple_rules:
            num_comp = rule.numerator
            den_comp = rule.denominator
            num_codes = num_comp.dimension_codes()
            den_codes = den_comp.dimension_codes()

            num_result_code = num_codes.get(self.config.result_dimension, "")
            num_secondary_code = num_codes.get(self.config.secondary_dimension, "")
            num_agg_code = f"{num_result_code}-{rule.result_code}-{num_secondary_code}"

            den_result_code = den_codes.get(self.config.result_dimension, "")
            den_secondary_code = den_codes.get(
                self.config.secondary_dimension, num_secondary_code
            )
            den_agg_code = f"{den_result_code}-{rule.result_code}-{den_secondary_code}"

            num_df = pre_agg.filter(
                (F.col(rc) == num_agg_code) & (F.col(sc) == num_secondary_code)
            ).alias("rn")
            den_df = pre_agg.filter(
                (F.col(rc) == den_agg_code) & (F.col(sc) == den_secondary_code)
            ).alias("rd")

            join_dims = self._other_dims(result_dim, secondary_dim)
            if not join_dims:
                continue
            cond = F.col(f"rn.{join_dims[0].column}") == F.col(
                f"rd.{join_dims[0].column}"
            )
            for d in join_dims[1:]:
                cond = cond & (
                    F.col(f"rn.{d.column}") == F.col(f"rd.{d.column}")
                )

            joined = num_df.join(den_df, cond, "inner")
            joined = joined.filter(F.col(f"rd.{cols.value}") != 0)

            ratio_val = (
                F.col(f"rn.{cols.value}") * F.lit(multiplier)
            ) / F.col(f"rd.{cols.value}")

            select_exprs = []
            for dim in self.data_mapping.dimensions:
                if dim.name == self.config.result_dimension:
                    select_exprs.append(
                        F.lit(rule.result_code).cast(StringType()).alias(dim.column)
                    )
                else:
                    select_exprs.append(
                        F.col(f"rn.{dim.column}").alias(dim.column)
                    )

            select_exprs.append(ratio_val.alias(cols.value))
            select_exprs.append(F.col(f"rn.{cols.flag}").alias(cols.flag))

            if cols.note:
                select_exprs.append(F.lit(None).cast(StringType()).alias(cols.note))
            if cols.load_date:
                select_exprs.append(
                    F.lit(datetime.now()).cast(TimestampType()).alias(cols.load_date)
                )
            if cols.diss_flag_int:
                select_exprs.append(
                    F.lit(None).cast(IntegerType()).alias(cols.diss_flag_int)
                )
            if cols.diss_flag_ext:
                select_exprs.append(
                    F.lit(None).cast(IntegerType()).alias(cols.diss_flag_ext)
                )
            if cols.agg_flag_int:
                select_exprs.append(
                    F.lit(0).cast(IntegerType()).alias(cols.agg_flag_int)
                )
            if cols.agg_flag_ext:
                select_exprs.append(
                    F.lit(0).cast(IntegerType()).alias(cols.agg_flag_ext)
                )

            ratio_df = joined.select(*[e for e in select_exprs if e is not None])
            all_ratios.append(ratio_df)

        if not all_ratios:
            return None
        result = all_ratios[0]
        for df in all_ratios[1:]:
            result = result.union(df)
        return result

    # ------------------------------------------------------------------
    # Shared helpers
    # ------------------------------------------------------------------

    def _filter_component(
        self,
        df: DataFrame,
        component: AggJoinComponent,
        result_dim: DimensionDefinition,
        secondary_dim: DimensionDefinition,
    ) -> DataFrame:
        """Filter a DataFrame to the rows matching a component's dimension codes."""
        for dim_name, code in component.dimension_codes().items():
            dim = self._dim_by_name.get(dim_name)
            if dim is not None:
                df = df.filter(F.col(dim.column) == code)
        return df

    def _join_on_other_dims(
        self,
        left: DataFrame,
        right: DataFrame,
        result_dim: DimensionDefinition,
        secondary_dim: DimensionDefinition,
        left_alias: str = "dn",
        right_alias: str = "dd",
    ) -> DataFrame:
        """Join two DataFrames on all dimensions except result_dim and secondary_dim."""
        join_dims = self._other_dims(result_dim, secondary_dim)
        if not join_dims:
            return left.crossJoin(right)

        cond = F.col(f"{left_alias}.{join_dims[0].column}") == F.col(f"{right_alias}.{join_dims[0].column}")
        for d in join_dims[1:]:
            cond = cond & (F.col(f"{left_alias}.{d.column}") == F.col(f"{right_alias}.{d.column}"))
        return left.join(right, cond, "inner")

    def _other_dims(
        self,
        result_dim: DimensionDefinition,
        secondary_dim: DimensionDefinition,
    ) -> List[DimensionDefinition]:
        """All dimensions excluding result_dim and secondary_dim."""
        excluded = {result_dim.name, secondary_dim.name}
        return [d for d in self.data_mapping.dimensions if d.name not in excluded]

    def _build_pre_agg_row(
        self,
        paired: DataFrame,
        source_alias: str,
        result_dim: DimensionDefinition,
        secondary_dim: DimensionDefinition,
        new_result_code: str,
    ) -> Optional[DataFrame]:
        """Build pre-aggregation rows from a joined DataFrame.

        Selects the source alias's columns, replaces the result-dimension
        code with ``new_result_code``, and tags the row with ``AggFlagInt = 100``.
        """
        cols = self.data_mapping.columns
        select_exprs = []

        for dim in self.data_mapping.dimensions:
            if dim.name == self.config.result_dimension:
                select_exprs.append(F.lit(new_result_code).cast(StringType()).alias(dim.column))
            else:
                select_exprs.append(F.col(f"{source_alias}.{dim.column}").alias(dim.column))

        select_exprs.append(F.col(f"{source_alias}.{cols.value}").alias(cols.value))
        select_exprs.append(F.col(f"{source_alias}.{cols.flag}").alias(cols.flag))

        if cols.note:
            select_exprs.append(F.col(f"{source_alias}.{cols.note}").alias(cols.note))
        if cols.load_date:
            select_exprs.append(F.lit(datetime.now()).cast(TimestampType()).alias(cols.load_date))
        if cols.diss_flag_int:
            select_exprs.append(
                F.col(f"{source_alias}.{cols.diss_flag_int}").alias(cols.diss_flag_int)
            )
        if cols.diss_flag_ext:
            select_exprs.append(
                F.col(f"{source_alias}.{cols.diss_flag_ext}").alias(cols.diss_flag_ext)
            )
        if cols.agg_flag_int:
            select_exprs.append(F.lit(_AGG_FLAG_INT_JOIN).cast(IntegerType()).alias(cols.agg_flag_int))
        if cols.agg_flag_ext:
            select_exprs.append(
                F.col(f"{source_alias}.{cols.agg_flag_ext}").alias(cols.agg_flag_ext)
            )

        return paired.select(*[e for e in select_exprs if e is not None])
