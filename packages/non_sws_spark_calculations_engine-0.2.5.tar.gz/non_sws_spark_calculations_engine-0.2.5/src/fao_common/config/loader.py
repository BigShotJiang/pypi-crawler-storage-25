"""Shared configuration file loading utilities."""

import json
from pathlib import Path
from typing import Union

from pydantic import ValidationError

from .schema import DataMappingConfig


class ConfigurationError(Exception):
    """Raised when a configuration file is missing, malformed, or invalid."""

    pass


def load_json_config(path: Union[str, Path]) -> dict:
    """Load a JSON configuration file and return it as a dict.

    Args:
        path: Path to the JSON file.

    Returns:
        Parsed JSON as a dictionary.

    Raises:
        ConfigurationError: If the file cannot be read or parsed.
    """
    path = Path(path)
    if not path.exists():
        raise ConfigurationError(f"Configuration file not found: {path}")

    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except json.JSONDecodeError as e:
        raise ConfigurationError(f"Invalid JSON in {path}: {e}") from e
    except Exception as e:
        raise ConfigurationError(f"Error reading {path}: {e}") from e


def resolve_config_dict(config: Union[str, Path, dict]) -> dict:
    """Resolve a config input (path, JSON string, or dict) to a dictionary.

    Args:
        config: File path, JSON string, or dict.

    Returns:
        Configuration as a dictionary.

    Raises:
        ConfigurationError: If the input cannot be resolved.
    """
    if isinstance(config, dict):
        return config

    if isinstance(config, Path):
        return load_json_config(config)

    if isinstance(config, str):
        stripped = config.strip()
        if stripped.startswith("{") or stripped.startswith("["):
            try:
                return json.loads(config)
            except json.JSONDecodeError as e:
                raise ConfigurationError(f"Invalid JSON string: {e}") from e
        return load_json_config(config)

    raise ConfigurationError(
        f"Config must be a file path (str/Path), a JSON string, or a dict. "
        f"Got {type(config).__name__}"
    )


def load_data_mapping(config: Union[str, Path, dict]) -> DataMappingConfig:
    """Load and validate a DataMappingConfig.

    Args:
        config: File path, JSON string, or dict with data mapping config.

    Returns:
        Validated DataMappingConfig.

    Raises:
        ConfigurationError: If the configuration is invalid.
    """
    config_dict = resolve_config_dict(config)
    try:
        return DataMappingConfig(**config_dict)
    except ValidationError as e:
        raise ConfigurationError(f"Invalid data mapping configuration: {e}") from e
