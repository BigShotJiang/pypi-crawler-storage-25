"""Shared configuration schema definitions used by fao_calc and fao_agg."""

from typing import Annotated, Any, Dict, List, Literal, Optional, Union

from pydantic import BaseModel, Field, field_validator, model_validator


# ---------------------------------------------------------------------------
# Data source configs — discriminated union on "type"
# ---------------------------------------------------------------------------

class FileDataSource(BaseModel):
    """Configuration for a file-based data source (CSV, Parquet, Delta, JDBC)."""

    type: Literal["csv", "parquet", "delta", "jdbc"]
    path: Optional[str] = Field(None, description="Path to data file or directory")
    options: Dict[str, Any] = Field(
        default_factory=dict, description="Additional options for reading data"
    )


class SdmxDataSource(BaseModel):
    """Configuration for an SDMX API-based data source.

    The data file is an SDMX-formatted CSV (columns declared by the registry).
    The schema (dimension order and IDs) is fetched from a pysdmx
    ``RegistryClient`` so that domain-specific ITEM/ELEMENT orderings are
    handled automatically.

    Minimal required fields::

        {
            "type": "sdmx",
            "path": "data/domains/FDI/DataFDI_SDMX.csv",
            "endpoint": "https://private-fmr.aws.fao.org/sdmx/v2/",
            "domain_code": "FDI"
        }

    ``agency`` defaults to ``"FAO.FAOSTAT.<domain_code>"``.
    ``dataflow_id`` defaults to ``"OFFICIAL"``.
    ``dataflow_version`` defaults to ``"+"``.
    """

    type: Literal["sdmx"] = "sdmx"
    path: Optional[str] = Field(None, description="Path to the SDMX CSV file on disk")
    endpoint: str = Field(description="SDMX registry base URL, e.g. https://host/sdmx/v2/")
    domain_code: str = Field(description="Domain code, e.g. 'FDI'; used to build default agency")
    agency: Optional[str] = Field(
        None,
        description="SDMX agency ID. Defaults to 'FAO.FAOSTAT.<domain_code>' if not set.",
    )
    dataflow_id: str = Field(default="OFFICIAL", description="SDMX dataflow ID")
    dataflow_version: str = Field(default="+", description="SDMX dataflow version")
    cache_dir: Optional[str] = Field(
        None,
        description="Directory for caching API schema responses (pickle). None = no cache.",
    )
    cache_ttl_seconds: int = Field(
        default=3600,
        description="Cache time-to-live in seconds. Schema is re-fetched after expiry.",
    )
    timeout_seconds: int = Field(
        default=30,
        description="HTTP timeout in seconds for API calls.",
    )
    value_sdmx_column: Optional[str] = Field(
        None,
        description=(
            "SDMX column to use as the observation value. "
            "Defaults to the first declared measure (OBS_VALUE). "
            "Override to 'UNROUNDED_VALUE' to use the full-precision attribute "
            "when the dataflow carries it alongside the rounded OBS_VALUE."
        ),
    )

    @model_validator(mode="after")
    def _set_default_agency(self) -> "SdmxDataSource":
        if self.agency is None:
            self.agency = f"FAO.FAOSTAT.{self.domain_code}"
        return self


# Discriminated union — Pydantic picks the right model based on "type".
# Existing JSON configs using "csv"/"parquet"/"delta"/"jdbc" deserialise to
# FileDataSource unchanged; new "sdmx" configs deserialise to SdmxDataSource.
DataSourceConfig = Annotated[
    Union[FileDataSource, SdmxDataSource],
    Field(discriminator="type"),
]


# ---------------------------------------------------------------------------
# Dimension and column definitions
# ---------------------------------------------------------------------------

class DimensionDefinition(BaseModel):
    """Definition of a dimension in the data (e.g. area, item, element, year)."""

    name: str = Field(description="Semantic name of the dimension")
    column: str = Field(description="Column name in the data (e.g. 'Var1Code')")
    var_position: int = Field(
        description="Position in Var1-Var7 structure (1-7)", ge=1, le=7
    )
    aggregates_enabled: bool = Field(
        default=False, description="Whether this dimension has aggregate groups"
    )
    sdmx_id: Optional[str] = Field(
        None,
        description=(
            "SDMX dimension ID used when source type is 'sdmx'. "
            "If omitted, auto-detected by lowercasing the SDMX ID and matching against name. "
            "Set explicitly when the SDMX ID differs from the semantic name, e.g. 'GEO' for 'area'."
        ),
    )


class ColumnMapping(BaseModel):
    """Mapping between physical data columns and the calculation engine."""

    value: str = Field(description="Column containing the numeric value")
    flag: str = Field(description="Column containing the data quality flag")
    note: Optional[str] = Field(None, description="Column containing notes")
    load_date: Optional[str] = Field(None, description="Column containing load date")
    diss_flag_int: Optional[str] = Field(
        None, description="Internal dissemination flag column"
    )
    diss_flag_ext: Optional[str] = Field(
        None, description="External dissemination flag column"
    )
    agg_flag_int: Optional[str] = Field(
        None, description="Internal aggregate flag column"
    )
    agg_flag_ext: Optional[str] = Field(
        None, description="External aggregate flag column"
    )


class DataMappingConfig(BaseModel):
    """Complete data mapping configuration shared across engines."""

    data_source: DataSourceConfig
    dimensions: List[DimensionDefinition] = Field(
        description="Dimension definitions ordered by var_position", min_length=1
    )
    columns: ColumnMapping = Field(description="Column mappings for value/flag/etc.")

    @field_validator("dimensions")
    @classmethod
    def validate_unique_positions(
        cls, v: List[DimensionDefinition]
    ) -> List[DimensionDefinition]:
        """Validate that var_positions are unique."""
        positions = [dim.var_position for dim in v]
        if len(positions) != len(set(positions)):
            raise ValueError("Dimension var_positions must be unique")
        return v

    def get_dimension(self, name: str) -> Optional[DimensionDefinition]:
        """Look up a dimension by semantic name."""
        for dim in self.dimensions:
            if dim.name == name:
                return dim
        return None

    def dimension_by_column(self, column: str) -> Optional[DimensionDefinition]:
        """Look up a dimension by its physical column name."""
        for dim in self.dimensions:
            if dim.column == column:
                return dim
        return None

    @property
    def dimension_names(self) -> List[str]:
        """Return all dimension names in var_position order."""
        return [dim.name for dim in sorted(self.dimensions, key=lambda d: d.var_position)]
