"""FAO Common - Shared utilities for fao_calc and fao_agg."""
