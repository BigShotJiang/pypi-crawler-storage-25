"""Spark session utilities."""

from .session import create_spark_session

__all__ = ["create_spark_session"]
