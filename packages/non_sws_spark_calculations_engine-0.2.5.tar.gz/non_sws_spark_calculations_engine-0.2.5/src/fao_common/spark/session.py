"""Spark session factory with sensible defaults for local testing and EMR."""

from __future__ import annotations

from pyspark.sql import SparkSession


def create_spark_session(
    app_name: str = "FAO Analytics",
    local: bool = False,
    extra_config: dict | None = None,
) -> SparkSession:
    """Create or retrieve a SparkSession.

    When ``local=True`` the session runs in local mode, suitable for unit
    tests.  In EMR the session is created by the cluster, so this function
    simply retrieves the existing one (``local=False``).

    Args:
        app_name: Application name shown in the Spark UI.
        local: If True, force local[*] mode (for testing).
        extra_config: Additional Spark config key-value pairs.

    Returns:
        SparkSession instance.
    """
    builder = SparkSession.builder.appName(app_name)

    if local:
        builder = builder.master("local[*]")

    builder = (
        builder.config("spark.sql.adaptive.enabled", "true")
        .config("spark.sql.adaptive.coalescePartitions.enabled", "true")
    )

    if extra_config:
        for key, value in extra_config.items():
            builder = builder.config(key, value)

    return builder.getOrCreate()
