"""Factory for creating DataAdapter instances from a DataSourceConfig."""

from __future__ import annotations

from fao_common.config.schema import DataSourceConfig, FileDataSource, SdmxDataSource

from .base import DataAdapter
from .file import FileDataAdapter
from .sdmx import SdmxDataAdapter


def create_adapter(source: DataSourceConfig) -> DataAdapter:
    """Return the appropriate ``DataAdapter`` for the given source config.

    Args:
        source: A validated ``FileDataSource`` or ``SdmxDataSource`` instance
            (the discriminated union is already resolved by Pydantic).

    Returns:
        A concrete ``DataAdapter`` ready to call ``.load()``.

    Raises:
        TypeError: If the source type is unrecognised (should not happen with
            a validated ``DataSourceConfig``).
    """
    if isinstance(source, FileDataSource):
        return FileDataAdapter(source)
    if isinstance(source, SdmxDataSource):
        return SdmxDataAdapter(source)
    raise TypeError(f"No adapter available for data source type: {type(source).__name__!r}")
