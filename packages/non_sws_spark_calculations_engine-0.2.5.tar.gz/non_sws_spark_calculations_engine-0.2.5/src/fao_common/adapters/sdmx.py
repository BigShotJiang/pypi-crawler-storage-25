"""SDMX API-based data adapter.

Loads data from an SDMX-formatted CSV file, using a ``pysdmx``
``RegistryClient`` to determine the authoritative dimension order and
attribute list for the dataflow.

Column-mapping strategy
-----------------------
The SDMX registry is the single source of truth for column semantics:

1. ``RegistryClient.get_dataflow_details()`` returns the list of dimensions
   (in schema order), the measure, and the attributes.
2. Each SDMX dimension ID is matched against the engine's
   ``DimensionDefinition`` entries (three-level fallback):
   a. If ``sdmx_id`` is set on the definition, that value is used for matching.
   b. Otherwise, the SDMX ID is lower-cased and compared to ``name``
      (e.g. SDMX ``"AREA"`` → engine name ``"area"``).
   c. Built-in aliases for standard SDMX names (``TIME_PERIOD`` → ``"year"``).
3. The matched definition supplies the internal column name (e.g. ``"Var1Code"``).
4. The first measure (typically ``OBS_VALUE``) is renamed to the engine's
   ``value`` column.
5. The SDMX attribute whose ID matches ``"FLAG"`` (case-insensitive) is
   renamed to the engine's ``flag`` column.
6. All other SDMX columns (``STRUCTURE``, ``STRUCTURE_ID``, ``ACTION``,
   remaining attributes) are dropped.

ITEM / ELEMENT ordering
-----------------------
Some domains declare ITEM before ELEMENT in their SDMX schema; others do the
reverse.  Because this adapter maps by *name* (not position), the correct
internal column is always selected regardless of the order in the CSV.

Flag eligibility
----------------
SDMX data does not carry ``AggFlagInt`` / ``AggFlagExt`` columns.  When those
columns are absent from the engine's ``ColumnMapping``, the aggregator treats
all rows as eligible (see ``Aggregator._filter_eligible``).  Do *not* configure
``agg_flag_int`` / ``agg_flag_ext`` in the SDMX ``data_mapping`` — the engine
handles the "always eligible" case automatically.

Schema caching
--------------
If ``cache_dir`` is set, the ``DataflowInfo`` object is serialised with
``pickle`` after the first successful fetch.  Subsequent calls use the cached
copy until the file is older than ``cache_ttl_seconds``.
"""

from __future__ import annotations

import logging
import pickle
import time
from pathlib import Path
from typing import Dict, List, Optional

from pyspark.sql import DataFrame, SparkSession
from pyspark.sql import functions as F
from pyspark.sql.types import IntegerType

from fao_common.config.schema import (
    ColumnMapping,
    DataMappingConfig,
    DimensionDefinition,
    SdmxDataSource,
)

from .base import DataAdapter

logger = logging.getLogger(__name__)

# Standard SDMX metadata columns that are always dropped from the data.
_SDMX_META_COLUMNS = {"STRUCTURE", "STRUCTURE_ID", "ACTION"}

# Well-known SDMX dimension aliases.  When a schema dimension ID doesn't match
# any DimensionDefinition by sdmx_id or lowercase name, this map is consulted.
# Key = SDMX dimension ID (upper-case), Value = engine dimension name.
# This avoids the need for explicit sdmx_id overrides for standard SDMX names.
_SDMX_DIMENSION_ALIASES: Dict[str, str] = {
    "TIME_PERIOD": "year",
    "YEAR": "year",
}


class SdmxDataAdapter(DataAdapter):
    """Loads SDMX-formatted CSV data, mapping columns via the SDMX registry.

    Parameters
    ----------
    source:
        Validated ``SdmxDataSource`` configuration.
    """

    def __init__(self, source: SdmxDataSource) -> None:
        self._source = source
        self._cached_schema = None  # in-memory cache (cleared on TTL expiry)

    # ------------------------------------------------------------------
    # Public interface
    # ------------------------------------------------------------------

    def build_data_mapping(self) -> DataMappingConfig:
        """Derive a complete DataMappingConfig from the SDMX registry schema.

        Fetches (or retrieves from cache) the dataflow schema and builds the
        mapping automatically:

        - Each SDMX dimension becomes a ``DimensionDefinition`` with
          ``name`` = lowercased ID (or built-in alias, e.g. TIME_PERIOD → year),
          ``column`` = ``Var{position}Code``, ``var_position`` = 1-based
          schema order.
        - ``columns.value`` = ``"Value"``, ``columns.flag`` = ``"Flag"``.
        - No optional columns (note, load_date, diss/agg flags) are configured.

        Returns:
            A fully populated ``DataMappingConfig`` backed by this adapter's
            ``SdmxDataSource``.
        """
        schema_info = self._get_schema()
        sdmx_dim_ids = [d.id for d in schema_info.components.dimensions]

        dimensions = []
        for pos, sdmx_id in enumerate(sdmx_dim_ids, start=1):
            name = _SDMX_DIMENSION_ALIASES.get(sdmx_id, sdmx_id.lower())
            dimensions.append(
                DimensionDefinition(
                    name=name,
                    column=f"Var{pos}Code",
                    var_position=pos,
                )
            )

        return DataMappingConfig(
            data_source=self._source,
            dimensions=dimensions,
            columns=ColumnMapping(value="Value", flag="Flag"),
        )

    def load(
        self,
        path: Optional[Path],
        spark: SparkSession,
        data_mapping: DataMappingConfig,
    ) -> DataFrame:
        """Fetch schema, load SDMX CSV, and return a normalised DataFrame.

        Args:
            path: Path to the SDMX CSV file.  Falls back to
                ``source.path`` when ``None``.
            spark: Active SparkSession.
            data_mapping: Dimension and column definitions for the domain.

        Returns:
            DataFrame with internal column names (``Var1Code``, …, ``Value``,
            ``Flag``).  All SDMX metadata / extra attribute columns are
            dropped.

        Raises:
            ValueError: If no path is available or a required dimension ID
                cannot be matched.
            RuntimeError: If the SDMX registry call fails.
        """
        resolved = path or (Path(self._source.path) if self._source.path else None)
        if resolved is None:
            raise ValueError(
                "No data path provided: set 'path' in load() or 'data_source.path' in config."
            )

        schema_info = self._get_schema()
        rename_map, flag_sdmx_id = self._build_column_mapping(schema_info, data_mapping)

        # Read raw CSV — all columns as strings to avoid schema-inference issues
        raw_df = spark.read.csv(str(resolved), header=True, inferSchema=False)

        return self._transform(raw_df, rename_map, flag_sdmx_id, data_mapping)

    def transform_dataframe(
        self,
        dataframe: DataFrame,
        data_mapping: DataMappingConfig,
    ) -> DataFrame:
        """Transform a raw SDMX DataFrame to internal column names.

        Use this when you already have the data as a Spark DataFrame
        (e.g. from a Glue catalog table) and need to rename SDMX columns
        (AREA, TIME_PERIOD, OBS_VALUE, …) to internal names (Var1Code, …,
        Value, Flag).

        Args:
            dataframe: DataFrame with SDMX column names.
            data_mapping: Dimension and column definitions for the domain.

        Returns:
            DataFrame with internal column names.
        """
        schema_info = self._get_schema()
        rename_map, flag_sdmx_id = self._build_column_mapping(schema_info, data_mapping)
        return self._transform(dataframe, rename_map, flag_sdmx_id, data_mapping)

    def to_sdmx(
        self,
        dataframe: DataFrame,
        data_mapping: DataMappingConfig,
        reference: Optional[DataFrame] = None,
    ) -> DataFrame:
        """Convert an internal-format DataFrame back to the SDMX schema.

        Produces a DataFrame whose columns match the original SDMX CSV:
        STRUCTURE, STRUCTURE_ID, ACTION, <dimensions>, <measure>,
        <attributes> — with all columns present.

        Dimension, value, and flag columns are reverse-mapped from internal
        names.  SDMX metadata columns (STRUCTURE, STRUCTURE_ID, ACTION) are
        populated with fixed values derived from the adapter's config.
        All remaining attribute columns (e.g. AREA_M49, DECIMALS, NOTE, UNIT)
        are added as NULL strings so the schema matches the input file.

        Args:
            dataframe: DataFrame with internal column names (Var1Code, …,
                Value, Flag).
            data_mapping: The same mapping used during ``load`` /
                ``transform_dataframe``.
            reference: Optional reference DataFrame (e.g. the original input)
                whose column order will be used.  When ``None``, columns
                follow the registry schema order.

        Returns:
            DataFrame with the full SDMX column schema.
        """
        schema_info = self._get_schema()
        rename_map, flag_sdmx_id = self._build_column_mapping(schema_info, data_mapping)

        # Build the STRUCTURE_ID value from the adapter config
        agency = self._source.agency
        dataflow_id = self._source.dataflow_id
        version = self._source.dataflow_version
        # Resolve "+" to the version from the schema if available
        resolved_version = getattr(schema_info, "version", version) or version
        structure_id = f"{agency}:{dataflow_id}({resolved_version})"

        # Collect all known SDMX column names
        all_sdmx_cols: List[str] = (
            list(_SDMX_META_COLUMNS)  # STRUCTURE, STRUCTURE_ID, ACTION
            + [d.id for d in schema_info.components.dimensions]
            + [m.id for m in schema_info.components.measures]
            + [a.id for a in schema_info.components.attributes]
        )

        # Determine output column order
        if reference is not None:
            ordered_cols = reference.columns
        else:
            ordered_cols = all_sdmx_cols

        # Build expression for each column
        col_exprs: Dict[str, "Column"] = {}

        # Metadata
        col_exprs["STRUCTURE"] = F.lit("dataflow")
        col_exprs["STRUCTURE_ID"] = F.lit(structure_id)
        col_exprs["ACTION"] = F.lit("I")

        # Dimensions + measure — reverse-mapped from internal columns
        for sdmx_col, internal_col in rename_map.items():
            if internal_col in dataframe.columns:
                col_exprs[sdmx_col] = F.col(internal_col).cast("string")
            else:
                col_exprs[sdmx_col] = F.lit(None).cast("string")

        # Flag attribute
        if flag_sdmx_id:
            flag_col = data_mapping.columns.flag
            if flag_col in dataframe.columns:
                col_exprs[flag_sdmx_id] = F.col(flag_col)
            else:
                col_exprs[flag_sdmx_id] = F.lit(None).cast("string")

        # Build select in the target order; anything unmapped becomes NULL
        select_exprs = []
        for col_name in ordered_cols:
            if col_name in col_exprs:
                select_exprs.append(col_exprs[col_name].alias(col_name))
            else:
                select_exprs.append(F.lit(None).cast("string").alias(col_name))

        return dataframe.select(*select_exprs)

    # ------------------------------------------------------------------
    # Schema retrieval with caching
    # ------------------------------------------------------------------

    def _get_schema(self):
        """Return cached or freshly-fetched ``DataflowInfo``."""
        # 1. In-memory hit
        if self._cached_schema is not None:
            return self._cached_schema

        # 2. On-disk cache hit
        cache_path = self._cache_path()
        if cache_path is not None and cache_path.exists():
            age = time.time() - cache_path.stat().st_mtime
            if age < self._source.cache_ttl_seconds:
                logger.debug("Loading SDMX schema from cache: %s", cache_path)
                with open(cache_path, "rb") as fh:
                    self._cached_schema = pickle.load(fh)
                return self._cached_schema

        # 3. Live API call
        schema_info = self._fetch_from_api()

        # Persist to disk
        if cache_path is not None:
            cache_path.parent.mkdir(parents=True, exist_ok=True)
            with open(cache_path, "wb") as fh:
                pickle.dump(schema_info, fh)
            logger.debug("SDMX schema cached to: %s", cache_path)

        self._cached_schema = schema_info
        return schema_info

    def _fetch_from_api(self):
        """Call the pysdmx registry and return a ``DataflowInfo`` object."""
        try:
            from pysdmx.api.fmr import RegistryClient
        except ImportError as exc:
            raise RuntimeError(
                "pysdmx is required for SDMX data sources. "
                "Install it with: pip install pysdmx"
            ) from exc

        logger.info(
            "Fetching SDMX schema: agency=%s, id=%s, version=%s",
            self._source.agency,
            self._source.dataflow_id,
            self._source.dataflow_version,
        )
        try:
            client = RegistryClient(self._source.endpoint)
            return client.get_dataflow_details(
                agency=self._source.agency,
                id=self._source.dataflow_id,
                version=self._source.dataflow_version,
            )
        except Exception as exc:
            raise RuntimeError(
                f"Failed to fetch SDMX schema from {self._source.endpoint!r} "
                f"(agency={self._source.agency!r}, dataflow={self._source.dataflow_id!r}): {exc}"
            ) from exc

    def _cache_path(self) -> Optional[Path]:
        if not self._source.cache_dir:
            return None
        safe_name = f"{self._source.agency}_{self._source.dataflow_id}.pkl".replace(
            "/", "_"
        )
        return Path(self._source.cache_dir) / safe_name

    # ------------------------------------------------------------------
    # Column mapping
    # ------------------------------------------------------------------

    def _build_column_mapping(
        self, schema_info, data_mapping: DataMappingConfig
    ) -> tuple[Dict[str, str], Optional[str]]:
        """Build the SDMX-column → internal-column rename map.

        Returns:
            (rename_map, flag_sdmx_id) where ``rename_map`` maps each SDMX
            column name to the engine's internal column name, and
            ``flag_sdmx_id`` is the SDMX attribute column name for the flag
            (``None`` if not found in the schema — column presence in the CSV
            is checked separately).
        """
        # Build lookups from the data_mapping
        by_sdmx_id: Dict[str, str] = {
            d.sdmx_id: d.column
            for d in data_mapping.dimensions
            if d.sdmx_id
        }
        by_name: Dict[str, str] = {d.name: d.column for d in data_mapping.dimensions}

        rename_map: Dict[str, str] = {}

        # --- Dimensions (order from API = authoritative) ---
        sdmx_dim_ids = [d.id for d in schema_info.components.dimensions]
        for sdmx_id in sdmx_dim_ids:
            # 1. Explicit sdmx_id override  2. Lowercase name  3. Built-in alias
            internal_col = (
                by_sdmx_id.get(sdmx_id)
                or by_name.get(sdmx_id.lower())
                or by_name.get(_SDMX_DIMENSION_ALIASES.get(sdmx_id, ""))
            )
            if internal_col is None:
                raise ValueError(
                    f"SDMX dimension '{sdmx_id}' has no matching DimensionDefinition "
                    f"in data_mapping (tried sdmx_id='{sdmx_id}', name='{sdmx_id.lower()}', "
                    f"and alias='{_SDMX_DIMENSION_ALIASES.get(sdmx_id, '')}'). "
                    f"Add an explicit sdmx_id to the relevant DimensionDefinition."
                )
            rename_map[sdmx_id] = internal_col
            logger.debug("Dimension mapping: %s → %s", sdmx_id, internal_col)

        # --- Value column (explicit override or first declared measure) ---
        # source.value_sdmx_column lets callers use a high-precision attribute
        # (e.g. "UNROUNDED_VALUE") instead of the rounded OBS_VALUE measure.
        value_sdmx_col: Optional[str] = self._source.value_sdmx_column
        if not value_sdmx_col:
            sdmx_measures = [m.id for m in schema_info.components.measures]
            if sdmx_measures:
                value_sdmx_col = sdmx_measures[0]
        if value_sdmx_col:
            rename_map[value_sdmx_col] = data_mapping.columns.value
            logger.debug("Value mapping: %s → %s", value_sdmx_col, data_mapping.columns.value)

        # --- Flag attribute ---
        flag_sdmx_id: Optional[str] = None
        sdmx_attr_ids = [a.id for a in schema_info.components.attributes]
        for attr_id in sdmx_attr_ids:
            if attr_id.upper() == "FLAG":
                flag_sdmx_id = attr_id
                break
        if flag_sdmx_id:
            logger.debug(
                "Flag attribute mapping: %s → %s", flag_sdmx_id, data_mapping.columns.flag
            )

        return rename_map, flag_sdmx_id

    # ------------------------------------------------------------------
    # DataFrame transformation
    # ------------------------------------------------------------------

    def _transform(
        self,
        raw_df: DataFrame,
        rename_map: Dict[str, str],
        flag_sdmx_id: Optional[str],
        data_mapping: DataMappingConfig,
    ) -> DataFrame:
        """Select, rename, and return only the columns the engine needs.

        Steps:
        1. Rename dimension and measure columns via ``rename_map``.
        2. Add the flag column (renamed from SDMX attribute).
        3. Synthesize ``AggFlagInt`` / ``AggFlagExt`` as ``99`` when those
           column names are configured in ``data_mapping.columns``.  This
           ensures the output schema is compatible with AggJoin rows (which
           carry real ``AggFlagInt`` / ``AggFlagExt`` values) and makes all
           source observations eligible for aggregation.
        4. Drop all SDMX metadata and unrequired attribute columns.
        """
        available = set(raw_df.columns)
        select_exprs = []

        # Build alias alternatives: for each SDMX ID, find other IDs that map
        # to the same engine dimension (e.g. TIME_PERIOD ↔ YEAR both map to "year")
        _alias_alternatives: Dict[str, List[str]] = {}
        for sdmx_id, engine_name in _SDMX_DIMENSION_ALIASES.items():
            siblings = [
                k for k, v in _SDMX_DIMENSION_ALIASES.items()
                if v == engine_name and k != sdmx_id
            ]
            if siblings:
                _alias_alternatives[sdmx_id] = siblings

        # Renamed dimension + measure columns
        for sdmx_col, internal_col in rename_map.items():
            if sdmx_col in available:
                select_exprs.append(F.col(sdmx_col).alias(internal_col))
            else:
                # Check alias alternatives (e.g. TIME_PERIOD ↔ YEAR)
                resolved = None
                for alt in _alias_alternatives.get(sdmx_col, []):
                    if alt in available:
                        resolved = alt
                        break
                if resolved:
                    logger.info(
                        "SDMX column '%s' not found; using alias '%s' for '%s'.",
                        sdmx_col, resolved, internal_col,
                    )
                    select_exprs.append(F.col(resolved).alias(internal_col))
                else:
                    logger.warning(
                        "Expected SDMX column '%s' not found in CSV (mapped to '%s'). "
                        "The data may not match the declared schema.",
                        sdmx_col,
                        internal_col,
                    )

        # Flag column — from SDMX attribute or direct "FLAG" column name fallback
        flag_source = flag_sdmx_id or "FLAG"
        flag_target = data_mapping.columns.flag
        if flag_source in available:
            select_exprs.append(F.col(flag_source).alias(flag_target))
        else:
            logger.warning(
                "Flag column '%s' not found in SDMX CSV. "
                "Rows will have null flags.",
                flag_source,
            )
            select_exprs.append(F.lit(None).cast("string").alias(flag_target))

        # Synthesize AggFlagInt=99 / AggFlagExt=99 when the column names are
        # configured.  Value 99 = "always eligible" in the aggregation engine.
        cols = data_mapping.columns
        if cols.agg_flag_int:
            select_exprs.append(
                F.lit(99).cast(IntegerType()).alias(cols.agg_flag_int)
            )
            logger.debug("Synthesized %s=99 for all SDMX rows", cols.agg_flag_int)
        if cols.agg_flag_ext:
            select_exprs.append(
                F.lit(99).cast(IntegerType()).alias(cols.agg_flag_ext)
            )
            logger.debug("Synthesized %s=99 for all SDMX rows", cols.agg_flag_ext)

        return raw_df.select(*select_exprs)

    # ------------------------------------------------------------------
    # SDMX export
    # ------------------------------------------------------------------

    def export_sdmx(
        self,
        df: DataFrame,
        data_mapping: DataMappingConfig,
        output_path: Optional[str] = None,
    ) -> DataFrame:
        """Convert engine-format DataFrame back to SDMX CSV format.

        Reverses the column mapping: internal names (``Var1Code``, …,
        ``Value``, ``Flag``) become SDMX names (``AREA``, …,
        ``OBS_VALUE``, ``FLAG``).  Adds SDMX metadata columns
        (``STRUCTURE``, ``STRUCTURE_ID``, ``ACTION``) and drops everything
        else (Note, LoadDate, DissFlag, AggFlag columns).

        Args:
            df: Engine result DataFrame (internal column names).
            data_mapping: The same DataMappingConfig used during loading.
            output_path: If provided, write a single-partition CSV here.

        Returns:
            DataFrame in SDMX column format (dimensions + measure + FLAG
            + SDMX metadata).
        """
        schema_info = self._get_schema()
        rename_map, _ = self._build_column_mapping(schema_info, data_mapping)

        # Invert: internal_col → sdmx_col
        reverse_map: Dict[str, str] = {v: k for k, v in rename_map.items()}

        select_exprs = [
            F.lit("dataflow").alias("STRUCTURE"),
            F.lit(
                f"{self._source.agency}:{self._source.dataflow_id}"
                f"({self._source.dataflow_version.replace('+', '+')})"
            ).alias("STRUCTURE_ID"),
            F.lit("I").alias("ACTION"),
        ]

        # Dimensions in schema order
        for dim_info in schema_info.components.dimensions:
            sdmx_id = dim_info.id
            internal_col = rename_map.get(sdmx_id)
            if internal_col and internal_col in df.columns:
                select_exprs.append(F.col(internal_col).alias(sdmx_id))

        # Measure
        value_col = data_mapping.columns.value
        value_sdmx = reverse_map.get(value_col, "OBS_VALUE")
        if value_col in df.columns:
            select_exprs.append(F.col(value_col).alias(value_sdmx))

        # Flag attribute
        flag_col = data_mapping.columns.flag
        if flag_col in df.columns:
            select_exprs.append(F.col(flag_col).alias("FLAG"))

        result = df.select(*select_exprs)

        if output_path:
            result.coalesce(1).write.csv(
                output_path, header=True, mode="overwrite"
            )
            logger.info("SDMX CSV written to: %s", output_path)

        return result
