"""Abstract base class for data-source adapters."""

from __future__ import annotations

from abc import ABC, abstractmethod
from pathlib import Path
from typing import Optional

from pyspark.sql import DataFrame, SparkSession

from fao_common.config.schema import DataMappingConfig


class DataAdapter(ABC):
    """Common interface for loading domain data into a Spark DataFrame.

    Each concrete adapter handles one source type (file, SDMX …) and is
    responsible for reading data, normalising column names to the engine's
    internal schema, and adding any synthetic columns required by the engine.
    """

    @abstractmethod
    def load(
        self,
        path: Optional[Path],
        spark: SparkSession,
        data_mapping: DataMappingConfig,
    ) -> DataFrame:
        """Load data and return a DataFrame with internal column names.

        Args:
            path: Path override (may be ``None`` when ``data_source.path``
                is used instead).
            spark: Active SparkSession.
            data_mapping: Full data mapping config describing dimensions and
                column names used by the aggregation engine.

        Returns:
            Spark DataFrame with columns matching ``data_mapping`` conventions.
        """
