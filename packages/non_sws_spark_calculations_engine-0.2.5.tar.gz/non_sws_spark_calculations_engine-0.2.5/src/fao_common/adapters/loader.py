"""Shared helper for loading additional datasets.

Both ``AggregationEngine`` and ``CalculationEngine`` need to load cross-domain
datasets (e.g. MK for CS domain ratios).  This module provides a single
implementation that handles all three loading modes:

1. Pre-loaded Spark DataFrame.
2. File path loaded via the adapter resolved from a ``DataMappingConfig``.
3. SDMX registry: build a ``DataMappingConfig`` from the SDMX schema, then
   load the data file through the resulting ``SdmxDataAdapter``.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Optional, Union

from pyspark.sql import DataFrame, SparkSession

from fao_common.config.loader import load_data_mapping
from fao_common.config.schema import DataMappingConfig, SdmxDataSource

from .factory import create_adapter

logger = logging.getLogger(__name__)


def load_additional_dataset(
    dataset_id: str,
    spark: SparkSession,
    primary_data_mapping: DataMappingConfig,
    path: Optional[Union[str, Path]] = None,
    dataframe: Optional[DataFrame] = None,
    data_mapping: Optional[Union[str, Path, dict, DataMappingConfig]] = None,
    sdmx_source: Optional[Union[dict, SdmxDataSource]] = None,
) -> DataFrame:
    """Load an additional dataset for cross-domain operations.

    Resolution order:

    1. ``dataframe`` + ``sdmx_source`` — transform the DataFrame's SDMX
       column names (``AREA``, ``TIME_PERIOD``, …) to internal names
       (``Var1Code``, …) using the SDMX registry schema.
    2. ``dataframe`` alone — use as-is (assumes internal column names).
    3. ``sdmx_source`` (+ optional ``path``) — build a ``DataMappingConfig``
       from the SDMX registry, then load the file through the
       ``SdmxDataAdapter``.
    4. ``data_mapping`` + ``path`` — load via the adapter for that mapping.
    5. ``path`` only — load via the primary domain's adapter.

    Args:
        dataset_id: Identifier for this dataset (e.g. ``"MK"``).
        spark: Active SparkSession.
        primary_data_mapping: The calling engine's own ``DataMappingConfig``,
            used as fallback adapter when no separate mapping is provided.
        path: Path to a data file.
        dataframe: Pre-loaded Spark DataFrame.
        data_mapping: Separate ``DataMappingConfig`` (or path/dict/JSON string
            that resolves to one) for this dataset.  Required when the
            additional dataset has a different column layout than the primary.
        sdmx_source: ``SdmxDataSource`` config (or dict) describing the SDMX
            registry endpoint for this dataset.  When provided, the adapter
            builds the data mapping from the registry automatically.

    Returns:
        Loaded Spark DataFrame with internal column names.

    Raises:
        ValueError: If no usable combination of arguments is provided.
    """
    # 1. Pre-loaded DataFrame + SDMX source — transform SDMX columns
    if dataframe is not None and sdmx_source is not None:
        if isinstance(sdmx_source, dict):
            sdmx_source = SdmxDataSource(**sdmx_source)
        from .sdmx import SdmxDataAdapter

        adapter = SdmxDataAdapter(sdmx_source)
        mapping = adapter.build_data_mapping()
        logger.info(
            "Additional dataset '%s': transforming pre-loaded DataFrame via SDMX adapter (endpoint=%s).",
            dataset_id,
            sdmx_source.endpoint,
        )
        return adapter.transform_dataframe(dataframe, mapping)

    # 2. Pre-loaded DataFrame (already has internal column names)
    if dataframe is not None:
        logger.info("Additional dataset '%s': using pre-loaded DataFrame.", dataset_id)
        return dataframe

    # 3. SDMX source — derive mapping from registry, then load
    if sdmx_source is not None:
        if isinstance(sdmx_source, dict):
            sdmx_source = SdmxDataSource(**sdmx_source)
        from .sdmx import SdmxDataAdapter

        adapter = SdmxDataAdapter(sdmx_source)
        mapping = adapter.build_data_mapping()
        resolved_path = Path(path) if path else None
        logger.info(
            "Additional dataset '%s': loading via SDMX adapter (endpoint=%s).",
            dataset_id,
            sdmx_source.endpoint,
        )
        return adapter.load(resolved_path, spark, mapping)

    # 3. Explicit data_mapping (+ path)
    if data_mapping is not None:
        if not isinstance(data_mapping, DataMappingConfig):
            data_mapping = load_data_mapping(data_mapping)
        adapter = create_adapter(data_mapping.data_source)
        resolved_path = Path(path) if path else None
        logger.info(
            "Additional dataset '%s': loading via explicit data_mapping.", dataset_id
        )
        return adapter.load(resolved_path, spark, data_mapping)

    # 4. Path only — use the primary domain's adapter
    if path is not None:
        adapter = create_adapter(primary_data_mapping.data_source)
        logger.info(
            "Additional dataset '%s': loading via primary adapter from '%s'.",
            dataset_id,
            path,
        )
        return adapter.load(Path(path), spark, primary_data_mapping)

    raise ValueError(
        f"Cannot load additional dataset '{dataset_id}': provide at least one of "
        f"'dataframe', 'sdmx_source', 'data_mapping', or 'path'."
    )
