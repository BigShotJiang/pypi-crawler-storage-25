"""Pluggable data-source adapters for fao_common.

Usage::

    from fao_common.adapters import create_adapter

    adapter = create_adapter(data_mapping.data_source)
    df = adapter.load(path=Path("data/DataFDI.csv"), spark=spark, data_mapping=dm)
"""

from .base import DataAdapter
from .factory import create_adapter
from .loader import load_additional_dataset

__all__ = ["DataAdapter", "create_adapter", "load_additional_dataset"]
