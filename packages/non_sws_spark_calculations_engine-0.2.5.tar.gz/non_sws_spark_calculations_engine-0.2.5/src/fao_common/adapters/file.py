"""File-based data adapter (CSV, Parquet, Delta, JDBC)."""

from __future__ import annotations

from pathlib import Path
from typing import Optional

from pyspark.sql import DataFrame, SparkSession

from fao_common.config.schema import DataMappingConfig, FileDataSource

from .base import DataAdapter


class FileDataAdapter(DataAdapter):
    """Loads data from a local or remote file (CSV, Parquet, Delta, JDBC).

    This adapter wraps the original ``_read_file()`` logic that was previously
    embedded in ``AggregationEngine``.
    """

    def __init__(self, source: FileDataSource) -> None:
        self._source = source

    def load(
        self,
        path: Optional[Path],
        spark: SparkSession,
        data_mapping: DataMappingConfig,
    ) -> DataFrame:
        """Read the file at *path* (or ``source.path``) and return a DataFrame.

        Args:
            path: Explicit path override.  Falls back to ``source.path`` when
                ``None``.
            spark: Active SparkSession.
            data_mapping: Unused by this adapter (file data is already in the
                engine's internal column format).

        Returns:
            Raw Spark DataFrame as read from disk.

        Raises:
            ValueError: If no path is available.
        """
        resolved = path or (Path(self._source.path) if self._source.path else None)
        if resolved is None:
            raise ValueError(
                "No data path provided: set 'path' in load() or 'data_source.path' in config."
            )

        options = self._source.options or {}
        src_type = self._source.type

        if src_type == "csv":
            opts = options.copy()
            opts.setdefault("header", "true")
            opts.setdefault("inferSchema", "true")
            return spark.read.csv(str(resolved), **opts)
        elif src_type == "parquet":
            return spark.read.parquet(str(resolved), **options)
        elif src_type == "delta":
            return spark.read.format("delta").load(str(resolved), **options)
        else:
            raise ValueError(f"Unsupported file data source type: {src_type!r}")
