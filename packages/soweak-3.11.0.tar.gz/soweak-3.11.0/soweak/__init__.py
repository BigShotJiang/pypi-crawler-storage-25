"""soweak — OWASP LLM Top 10 security middleware framework.

A library logger named ``"soweak"`` is created at import time and given a
:class:`~logging.NullHandler`. Configure it like any other Python logger to
collect framework-level diagnostics (pattern compilation, store fallbacks,
adapter import failures); silence with ``logging.getLogger("soweak").setLevel(logging.CRITICAL)``.

See :doc:`ROADMAP <ROADMAP>` for the full architectural model and which
OWASP categories each release covers.

Quick start::

    from soweak import (
        Pipeline,
        PolicyBuilder,
        BlockEnforcer,
        RedactEnforcer,
        Severity,
    )
    from soweak.detectors import (
        prompt_injection_detector,
        input_dlp_detector,
    )

    policy = (
        PolicyBuilder()
        .on_input("user-prompt")
            .detect(prompt_injection_detector())
            .enforce(BlockEnforcer(min_severity=Severity.HIGH))
        .on_input("dlp")
            .detect(input_dlp_detector())
            .enforce(RedactEnforcer())
        .build()
    )

    pipeline = Pipeline(policy)
    decision = pipeline.check_input(user_text)
    if decision.blocked:
        raise SecurityError(decision.reason)
"""

import logging as _logging

# Library logger: callers configure handlers as they see fit. Default
# is silent (NullHandler) per library best practice.
_logging.getLogger(__name__).addHandler(_logging.NullHandler())

from soweak.core import (
    Action,
    AuditEvent,
    AuditLog,
    Boundary,
    Context,
    Decision,
    Detector,
    Enforcer,
    InMemoryAuditLog,
    JsonLinesAuditLog,
    OwaspCategory,
    Payload,
    Pipeline,
    Policy,
    PolicyBuilder,
    Rule,
    Severity,
    Signal,
    StreamingPipeline,
)
from soweak.enforcers import (
    BlockEnforcer,
    LogOnlyEnforcer,
    RedactEnforcer,
    ThresholdEnforcer,
    TransformEnforcer,
)
from soweak.output import (
    URLAllowlist,
    html_sanitizer_enforcer,
    is_safe_sql,
    sanitize_html,
)
from soweak.agent import (
    ApprovalRequired,
    ToolCall,
    ToolCallEvent,
    authorize,
    current_context,
    guarded_tool,
)
from soweak.budget import (
    Budget,
    BudgetEnforcer,
    BudgetExceededError,
    CostBudget,
    ModelPricing,
    RateLimitEnforcer,
    RateLimiter,
    TokenBudget,
)
from soweak.storage import (
    CounterStore,
    InMemoryCounterStore,
    InMemoryWindowStore,
    SqliteCounterStore,
    SqliteWindowStore,
    WindowStore,
)
from soweak.streaming import RepetitionDetector
from soweak.ml import MLClassifierDetector
from soweak.embeddings import (
    EmbeddingGroundingDetector,
    cosine_similarity,
)
from soweak.config import build_policy, load_policy
from soweak.rag import (
    IndirectInjectionDetector,
    ProvenanceDetector,
    RetrievalAnomalyDetector,
    TenantIsolationDetector,
)
from soweak.grounding import (
    CitationRequiredDetector,
    GroundingDetector,
)

__version__ = "3.11.0"

__all__ = [
    # version
    "__version__",
    # core types
    "Action",
    "AuditEvent",
    "AuditLog",
    "Boundary",
    "Context",
    "Decision",
    "Detector",
    "Enforcer",
    "InMemoryAuditLog",
    "JsonLinesAuditLog",
    "OwaspCategory",
    "Payload",
    "Pipeline",
    "Policy",
    "PolicyBuilder",
    "Rule",
    "Severity",
    "Signal",
    "StreamingPipeline",
    # built-in enforcers
    "BlockEnforcer",
    "LogOnlyEnforcer",
    "RedactEnforcer",
    "ThresholdEnforcer",
    "TransformEnforcer",
    # output sanitisation (LLM05)
    "URLAllowlist",
    "html_sanitizer_enforcer",
    "is_safe_sql",
    "sanitize_html",
    # tool authorization (LLM06)
    "ApprovalRequired",
    "ToolCall",
    "ToolCallEvent",
    "authorize",
    "current_context",
    "guarded_tool",
    # budgets & rate limits (LLM10)
    "Budget",
    "BudgetEnforcer",
    "BudgetExceededError",
    "CostBudget",
    "ModelPricing",
    "RateLimitEnforcer",
    "RateLimiter",
    "TokenBudget",
    # storage backends
    "CounterStore",
    "InMemoryCounterStore",
    "InMemoryWindowStore",
    "SqliteCounterStore",
    "SqliteWindowStore",
    "WindowStore",
    # streaming (LLM10)
    "RepetitionDetector",
    # ML classifier (LLM01 ML augmentation, LLM05 toxicity, LLM-as-judge)
    "MLClassifierDetector",
    # embedding-based grounding (LLM09 semantic)
    "EmbeddingGroundingDetector",
    "cosine_similarity",
    # declarative policy loader
    "build_policy",
    "load_policy",
    # RAG (LLM08)
    "IndirectInjectionDetector",
    "ProvenanceDetector",
    "RetrievalAnomalyDetector",
    "TenantIsolationDetector",
    # grounding (LLM09)
    "CitationRequiredDetector",
    "GroundingDetector",
]
