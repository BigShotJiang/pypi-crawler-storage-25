

## \<a name="chinese"\>\</a\>🇨🇳 中文说明

### 关于项目

你好！我是 **Eric Go**，一名专注于少儿编程教育的老师。

在我的教学实践中，我发现由于种种环境限制，很多学生无法直接使用正式版的 Minecraft 进行复杂的 API 编程。为了让我的编程课堂更加有趣且高效，我基于 **`mcpi`** 和 **`minecraftstuff`** 这两个优秀的库，开发并封装了 **`mcri`**。

`mcri` 旨在降低 Minecraft Python 编程的门槛。它修复了原版库中的一些小 Bug，补全了常用的 3D 绘图方法，并提供了一套详尽的中英文对照 ID 常量表，非常适合作为编程启蒙的教学工具。

### 核心功能

  * **基础交互**：快速获取位置、放置方块，支持中英文常量名（如 `mcri.金块`）。
  * **高级绘图**：内置 `setLine`, `setCircle`, `setSphere`, `setFace` 等方法，轻松实现 3D 建模。
  * **3D 海龟艺术**：全功能的 `Turtle` 类，支持在 3D 空间中进行艺术创作。
  * **物体动画**：通过 `Shape` 类实现物体的整体移动与平滑动画。
  * **编码优化**：针对 Windows 环境下的中文乱码问题进行了优化处理。

### 安装方法

```bash
pip install mcri
```

### 联系我

  * **作者**: Eric Go
  * **邮箱**: funkyeric.gou@gmail.com

-----

## \<a name="english"\>\</a\>🇺🇸 English Description

### About This Project

Hi there\! I am **Eric Go**, a programming teacher dedicated to K-12 education.

In my classroom, I encountered challenges where students couldn't easily access the full potential of official Minecraft APIs due to technical constraints. To bridge this gap and make Python learning more engaging, I created **`mcri`**, a wrapper library built upon the foundations of **`mcpi`** and **`minecraftstuff`**.

`mcri` is designed to simplify Minecraft Python programming. It fixes common bugs, adds essential 3D drawing methods, and provides a comprehensive bilingual (English & Chinese) constant library, making it the perfect tool for educators and young learners.

### Key Features

  * **Base Interaction**: Fast teleportation and block placement with bilingual constants (e.g., `mcri.GOLD_BLOCK`).
  * **Advanced Drawing**: Built-in methods for `setLine`, `setCircle`, `setSphere`, and `setFace` for easy 3D modeling.
  * **3D Turtle Art**: A fully functional `Turtle` class for creating 3D artistic structures.
  * **Object Animation**: Smoothly move complex shapes across the world using the `Shape` class.
  * **Encoding Optimized**: Specifically optimized to handle Chinese character display issues in Windows environments.

### Installation

```bash
pip install mcri
```

### Contact Me

  * **Author**: Eric Go
  * **Email**: funkyeric.gou@gmail.com

-----
