# mcri.py - 100天计划专用·完全体
# -*- coding: utf-8 -*-

ADDRESS = 'localhost'

# 全局变量延迟初始化
bukkit = None
pen = None
minecraft = None
entity = None
block = None
event = None
minecraftstuff = None


def init(address=ADDRESS):
    global bukkit, pen, minecraft, entity, block, event, minecraftstuff
    from mcpi import minecraft
    from mcpi import entity
    from mcpi import block
    from mcpi import event
    from mcpi.vec3 import Vec3
    import minecraftstuff

    bukkit = minecraft.Minecraft.create(address)
    pen = minecraftstuff.MinecraftDrawing(bukkit)
    return minecraft, entity, block, event, minecraftstuff


def ensure_initialized():
    global bukkit, pen
    if bukkit is None or pen is None:
        init()


# ==========================================
# 1. 基础世界交互 (Base World API)
# ==========================================

def getPlayer(name):
    ensure_initialized()
    return bukkit.getPlayerEntityId(name)


def getPos(player_id):
    ensure_initialized()
    return bukkit.entity.getTilePos(player_id)


def setPos(player_id, x, y, z):
    ensure_initialized()
    bukkit.entity.setTilePos(player_id, x, y, z)


def getBlock(x, y, z):
    ensure_initialized()
    return bukkit.getBlock(x, y, z)


def setBlock(x, y, z, block_id, color=None):
    ensure_initialized()
    if color is not None:
        bukkit.setBlock(x, y, z, block_id, color)
    else:
        bukkit.setBlock(x, y, z, block_id)


def getHeight(x, z):
    ensure_initialized()
    return bukkit.getHeight(x, z)


def setWorldImmutable(state=True):
    ensure_initialized()
    bukkit.setting("world_immutable", state)


def spawn(x, y, z, entity_id):
    ensure_initialized()
    return bukkit.spawnEntity(x, y, z, entity_id)


# ==========================================
# 2. 高级绘图功能 (Drawing API)
# ==========================================

def setLine(x1, y1, z1, x2, y2, z2, block_id, block_data=0):
    ensure_initialized()
    pen.drawLine(x1, y1, z1, x2, y2, z2, block_id, block_data)


def setFace(points, block_id, block_data=0):
    ensure_initialized()
    from mcpi.vec3 import Vec3
    vec_points = [Vec3(p[0], p[1], p[2]) for p in points]
    pen.drawFace(vec_points, True, block_id, block_data)


def setCircle(x, y, z, radius, block_id, block_data=0):
    ensure_initialized()
    pen.drawCircle(x, y, z, radius, block_id, block_data)


def setSphere(x, y, z, radius, block_id, block_data=0):
    ensure_initialized()
    pen.drawSphere(x, y, z, radius, block_id, block_data)


def setEllipse(x, y, z, radiusX, radiusZ, block_id, block_data=0):
    ensure_initialized()
    pen.drawEllipse(x, y, z, radiusX, radiusZ, block_id, block_data)


# ==========================================
# 3. 玩家感知与事件 (Event & Interaction)
# ==========================================


def send_chat(message):
    """
    发送聊天信息。针对中文乱码问题进行了兼容性处理。
    """
    ensure_initialized()
    try:
        # 方案 A: 尝试直接发送（原逻辑）
        bukkit.postToChat(message)
    except:
        # 方案 B: 如果 A 失败，尝试手动处理（应对某些旧版插件）
        # 强制将 unicode 转为 utf-8 字节，再模拟 latin-1 传出
        safe_message = message.encode('utf-8').decode('latin-1')
        bukkit.postToChat(safe_message)


def get_chats():
    ensure_initialized()
    return bukkit.events.pollChatPosts()


def get_shots():
    ensure_initialized()
    return bukkit.events.pollProjectileHits()


def get_hits():
    ensure_initialized()
    return bukkit.events.pollBlockHits()


def clearEvents():
    ensure_initialized()
    bukkit.events.clearAll()


def getDirection(player_id=None):
    ensure_initialized()
    if player_id is None:
        return bukkit.player.getDirection()
    return bukkit.entity.getDirection(player_id)


def setCamera(mode, player_id=None):
    ensure_initialized()
    if mode == "fixed":
        bukkit.camera.setFixed()
    elif mode == "follow" and player_id:
        bukkit.camera.setFollow(player_id)
    else:
        bukkit.camera.setNormal()


# ==========================================
# 4. 类定义 (Turtle & Shape)
# ==========================================

class Turtle:
    def __init__(self, x, y, z):
        ensure_initialized()
        from mcpi.vec3 import Vec3
        import minecraftstuff
        self.entity = minecraftstuff.MinecraftTurtle(bukkit, Vec3(x, y, z))
        self.entity.showturtle = False

    def forward(self, dist): self.entity.forward(dist)

    def backward(self, dist): self.entity.backward(dist)

    def left(self, angle): self.entity.left(angle)

    def right(self, angle): self.entity.right(angle)

    def up(self, angle): self.entity.up(angle)

    def down(self, angle): self.entity.down(angle)

    def rollLeft(self, angle): self.entity.rollleft(angle)

    def rollRight(self, angle): self.entity.rollright(angle)

    def penUp(self): self.entity.penup()

    def penDown(self): self.entity.pendown()

    def penBlock(self, b_id, b_data=0): self.entity.penblock(b_id, b_data)

    def speed(self, n): self.entity.speed(n)

    def show(self): self.entity.showturtle = True

    def hide(self): self.entity.showturtle = False


class Shape:
    def __init__(self, block_list):
        ensure_initialized()
        from mcpi.vec3 import Vec3
        import minecraftstuff

        shape_blocks = []
        for b in block_list:
            bx, by, bz, bid = b[0], b[1], b[2], b[3]
            bdata = b[4] if len(b) > 4 else 0
            shape_blocks.append(minecraftstuff.ShapeBlock(bx, by, bz, bid, bdata))

        self.entity = minecraftstuff.MinecraftShape(bukkit, Vec3(0, 0, 0), shape_blocks)

    def draw(self, x, y, z):
        self.entity.draw(x, y, z)

    # --- 修复核心：在这里处理 delay，不传给底层 ---
    def move(self, x, y, z, delay=0):
        self.entity.move(x, y, z)
        if delay > 0:
            import time
            time.sleep(delay)

    def clear(self):
        self.entity.clear()


# ==========================================
# 5. 常量定义 (Constants - ID 库)
# ==========================================

# --- 常用方块 ---
AIR = 0;
空气 = 0
STONE = 1;
石头 = 1
GRASS = 2;
草方块 = 2
DIRT = 3;
泥土 = 3
COBBLESTONE = 4;
圆石 = 4
WOOD_PLANKS = 5;
木板 = 5
SAPLING = 6;
树苗 = 6
BEDROCK = 7;
基岩 = 7
WATER = 9;
水 = 9
LAVA = 11;
岩浆 = 11
SAND = 12;
沙子 = 12
GRAVEL = 13;
沙砾 = 13
GOLD_ORE = 14;
金矿石 = 14
IRON_ORE = 15;
铁矿石 = 15
COAL_ORE = 16;
煤矿石 = 16
WOOD = 17;
原木 = 17
LEAVES = 18;
叶子 = 18
GLASS = 20;
玻璃 = 20
LAPIS_LAZULI_BLOCK = 22;
青金石块 = 22
SANDSTONE = 24;
沙岩 = 24
BED = 26;
床 = 26
WOOL = 35;
羊毛 = 35
GOLD_BLOCK = 41;
金块 = 41
IRON_BLOCK = 42;
铁块 = 42
BRICK_BLOCK = 45;
砖块 = 45
TNT = 46;
TNT = 46
BOOKSHELF = 47;
书架 = 47
MOSS_STONE = 48;
苔石 = 48
OBSIDIAN = 49;
黑曜石 = 49
TORCH = 50;
火把 = 50
FIRE = 51;
火 = 51
CHEST = 54;
箱子 = 54
DIAMOND_ORE = 56;
钻石矿石 = 56
DIAMOND_BLOCK = 57;
钻石块 = 57
CRAFTING_TABLE = 58;
工作台 = 58
FURNACE = 61;
熔炉 = 61
SNOW = 78;
雪 = 78
ICE = 79;
冰 = 79
CACTUS = 81;
仙人掌 = 81
CLAY = 82;
粘土 = 82
SUGAR_CANE = 83;
甘蔗 = 83
GLOWSTONE_BLOCK = 89;
萤石 = 89
REDSTONE_BLOCK = 152;
红石块 = 152
SEA_LANTERN = 169;
海晶灯 = 169

# --- 常用颜色 (数据值) ---
白色 = 0;
橙色 = 1;
品红色 = 2;
淡蓝色 = 3
黄色 = 4;
黄绿色 = 5;
粉红色 = 6;
灰色 = 7
淡灰色 = 8;
青色 = 9;
紫色 = 10;
蓝色 = 11
棕色 = 12;
绿色 = 13;
红色 = 14;
黑色 = 15

# --- 常用实体 ---
CHICKEN = 10;
鸡 = 10
COW = 11;
牛 = 11
PIG = 12;
猪 = 12
SHEEP = 13;
羊 = 13
WOLF = 14;
狼 = 14
VILLAGER = 120;
村民 = 120
HORSE = 100;
马 = 100
ZOMBIE = 32;
僵尸 = 32
SKELETON = 34;
骷髅 = 34
SPIDER = 35;
蜘蛛 = 35
CREEPER = 50;
苦力怕 = 50
ENDERMAN = 43;
末影人 = 43
ENDER_DRAGON = 63;
末影龙 = 63