import json

import pytest

from bddrest import Given, Append, Remove, when, response, status


def wsgi_application(environ, start_response):
    result = {}
    start_response('200 OK', [
        ('Content-Type', 'application/json;charset=utf-8'),
    ])

    for key in [h for h in environ if h.startswith('HTTP')]:
        result[key[5:].lower()] = environ[key]

    yield json.dumps(result).encode()


def test_append_headers_field():
    with Given(
        wsgi_application,
        title='test add header field',
        headers={'header1': '1'}
    ):
        assert status == '200 OK'
        assert response.json['header1'] == '1'

        # Using dictionary to manipulate lists.
        when(title='Appending another header', headers=Append(header2='2'))
        assert status == '200 OK'
        assert response.json['header1'] == '1'
        assert response.json['header2'] == '2'

        when(
            title='Adding new header: 2-tuple',
            headers=Append(('header2', '2'))
        )
        assert response.json['header1'] == '1'
        assert response.json['header2'] == '2'

        when(
            title='Adding new header: single string',
            headers=Append('header3: 3')
        )
        assert response.json['header1'] == '1'
        assert response.json['header3'] == '3'
        assert 'header2' not in response.json


def test_remove_headers_field():
    with Given(
        wsgi_application,
        title='test remove header field',
        headers={'header1': '1'}
    ):
        assert status == '200 OK'
        assert response.json['header1'] == '1'

        when(title='Remove header by key', headers=Remove('header1'))

        # Remove an invalid header(Not exists)
        with pytest.raises(ValueError):
            when(title='Invalid  key', headers=Remove('invalid header'))
