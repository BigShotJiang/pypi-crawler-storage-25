""" memorph """


def main() -> None:
    print("  memorph  ")
