from ..types import Secret
from .decorator import teams_type

teams_type(
    "secret",
    title="Secret",
    description="Select an existing secret",
    exclude={"id", "name", "broker_id", "_field_name"},
)(Secret)


__all__ = ["Secret"]
