import os
from dataclasses import dataclass, field
from typing import Any, ClassVar, Dict, Generic, Type, TypeVar
from uuid import UUID

from cloudpathlib import AnyPath
from typing_extensions import Self

from ellf_pam_sdk import models as pam_models
from ellf_pam_sdk import recipe_client
from ellf_pam_sdk.client.full_client import Client

_KindT = TypeVar("_KindT", bound=str)


@dataclass
class Asset(Generic[_KindT]):
    """Custom type for an asset uploaded to the cluster."""

    id: UUID
    broker_id: UUID
    name: str
    version: str
    kind: ClassVar[str] = ""
    path: str
    meta: Dict[str, Any]

    def load(self, *args: Any, **kwargs: Any) -> AnyPath:
        raise NotImplementedError  # shouldn't happen

    @classmethod
    def create(cls: Type[Self], name: str, path: str, version: str, meta: dict) -> Self:
        cfg = recipe_client.Settings()
        if not cfg.pam_host or not cfg.job_token:
            raise ValueError(
                "Cannot create asset: ELLF_PAM_HOST and "
                "ELLF_PAM_BOOTSTRAP_TOKEN must be set"
            )
        if cfg.broker_id is None:
            raise ValueError("Cannot create asset: ELLF_BROKER_ID must be set")
        client = Client.from_job_token_sync(cfg.pam_host, cfg.job_token)
        broker_id = cfg.broker_id
        return cls.create_with_client(
            client, broker_id, name=name, path=path, version=version, meta=meta
        )

    @classmethod
    def create_with_client(
        cls: Type[Self],
        client: recipe_client.Client,
        broker_id: UUID,
        name: str,
        path: str,
        version: str,
        meta: dict,
    ) -> Self:
        response = client.asset.create(
            pam_models.AssetCreating(
                broker_id=broker_id,
                name=name,
                version=version,
                path=path,
                kind=cls.kind,
                meta=meta,
            )
        )
        return cls(
            id=response.id,
            broker_id=response.broker_id,
            name=response.name,
            path=response.path,
            version=response.version,
            meta=response.meta,
        )

    def update(self) -> None:
        cfg = recipe_client.Settings()
        if not cfg.is_valid():
            raise ValueError("Invalid settings")
        pam_client = Client.from_job_token_sync(cfg.pam_host, cfg.job_token)
        return self.update_with_client(pam_client)

    def update_with_client(self, client: recipe_client.Client) -> None:
        _ = client.asset.update(
            pam_models.AssetUpdating(
                id=self.id,
                name=self.name,
                version=self.version,
                path=self.path,
                kind=self.kind,
                meta=self.meta,
            )
        )


@dataclass
class Dataset(Generic[_KindT]):
    """Custom type for a Prodigy dataset on the cluster."""

    id: UUID
    name: str
    broker_id: UUID
    kind: ClassVar[str] = ""

    def load(self, *args: Any, **kwargs: Any) -> AnyPath:
        raise NotImplementedError  # shouldn't happen


@dataclass
class Secret:
    """Custom type for a secret on the cluster.

    The secret value is injected into the pod as an environment variable
    named ``PRODIGY_SECRET_<FIELD_NAME>`` where *field_name* is the recipe
    parameter that this secret was bound to.  Call :meth:`value` to retrieve
    the plain-text value.
    """

    id: UUID
    name: str
    broker_id: UUID
    _field_name: str = field(default="", repr=False)

    def value(self) -> str:
        """Return the secret's plain-text value."""
        env_var = f"PRODIGY_SECRET_{self._field_name.upper()}"
        value = os.getenv(env_var)
        if value is None:
            raise KeyError(f"No secret value found (expected env var {env_var})")
        return value
