"""
Utility functions and models for the tvkit API.

This package provides essential utilities for TradingView API interactions,
including timestamp conversion, symbol validation, and indicator management.

The package is organized into focused modules:
- models: Pydantic data models for TradingView structures
- retry: Exponential backoff delay calculation
- timestamp: Timestamp conversion utilities
- symbol_validator: Symbol validation service
- indicator_service: TradingView indicator management

All functions and models are re-exported at package level for backward compatibility.
"""

# Re-export all functions and models for backward compatibility
from .indicator_service import (
    display_and_select_indicator,
    fetch_indicator_metadata,
    fetch_tradingview_indicators,
    prepare_indicator_metadata,
)
from .models import (
    IndicatorData,
    InputValue,
    PineFeatures,
    ProfileConfig,
    StudyPayload,
    SymbolConversionResult,
)
from .retry import calculate_backoff_delay
from .symbol_validator import (
    SymbolValidationOutcome,
    convert_symbol_format,
    validate_symbol_detailed,
    validate_symbols,
)
from .timestamp import convert_timestamp_to_iso

__all__ = [
    # Functions
    "calculate_backoff_delay",
    "convert_timestamp_to_iso",
    "validate_symbols",
    "validate_symbol_detailed",
    "convert_symbol_format",
    "SymbolValidationOutcome",
    "fetch_tradingview_indicators",
    "display_and_select_indicator",
    "fetch_indicator_metadata",
    "prepare_indicator_metadata",
    # Models
    "IndicatorData",
    "PineFeatures",
    "ProfileConfig",
    "InputValue",
    "StudyPayload",
    "SymbolConversionResult",
]
