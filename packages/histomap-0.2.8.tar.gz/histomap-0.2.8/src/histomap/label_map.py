"""
Utilities for mapping categorical labels from one column into another.

The mapper is defined as:
    {target_label: [source_value_1, source_value_2, ...], ...}

This module supports direct pandas DataFrame use and efficient SpatialData table-only
read/write when given a SpatialData Zarr path plus table name.
"""
from __future__ import annotations

from pathlib import Path
from typing import Mapping, Optional

import pandas as pd


def _invert_mapper(mapper: Mapping) -> dict[str, object]:
    inverse: dict[str, object] = {}
    duplicates: dict[str, list[object]] = {}
    for target, sources in mapper.items():
        if sources is None:
            continue
        for src in sources:
            key = str(src)
            if key in inverse and inverse[key] != target:
                duplicates.setdefault(key, [inverse[key]]).append(target)
            else:
                inverse[key] = target
    if duplicates:
        dup_text = ", ".join(f"{src}: {targets}" for src, targets in duplicates.items())
        raise ValueError(f"Mapper contains duplicate source labels mapped to multiple targets: {dup_text}")
    return inverse


def map_column_labels_df(
    df: pd.DataFrame,
    mapper: Mapping,
    input_col: str,
    output_col: str,
    *,
    unmapped_value=None,
    keep_original_for_unmapped: bool = True,
) -> pd.DataFrame:
    """
    Map values from `input_col` into `output_col` using a dict-of-lists mapper.

    Parameters
    ----------
    df:
        Input dataframe.
    mapper:
        Dict where keys are output labels and values are lists of input labels that
        should map to that key.
    input_col:
        Source column to map from.
    output_col:
        Destination column to write.
    unmapped_value:
        Optional value to assign when an input label is not found in the mapper and
        `keep_original_for_unmapped=False`.
    keep_original_for_unmapped:
        If True, values not found in the mapper are copied through from `input_col`.

    Returns
    -------
    A copy of the dataframe with `output_col` added/updated.
    """
    if input_col not in df.columns:
        raise KeyError(f"Column '{input_col}' not found.")

    inverse = _invert_mapper(mapper)
    out = df.copy()
    source = out[input_col].astype("object")
    mapped = source.astype(str).map(inverse)

    if keep_original_for_unmapped:
        output = mapped.where(mapped.notna(), source)
    else:
        output = mapped.where(mapped.notna(), unmapped_value)

    if pd.api.types.is_categorical_dtype(source):
        out[output_col] = pd.Categorical(output.astype("object"))
    else:
        out[output_col] = output.astype("object")
    return out


def map_column_labels(
    sda,
    table: Optional[str],
    mapper: Mapping,
    input_col: str,
    output_col: str,
    *,
    unmapped_value=None,
    keep_original_for_unmapped: bool = True,
    write_back: Optional[bool] = None,
):
    """
    Map labels for a dataframe, AnnData object, SpatialData-like object, or SpatialData Zarr path.

    When `sda` is a path to a SpatialData Zarr, only `tables/<table>` is read and written.
    """
    table_store = None
    adata = None

    if isinstance(sda, pd.DataFrame):
        obs = sda
        if write_back is None:
            write_back = False
    else:
        if table is None:
            raise ValueError("table is required when sda is not a pandas DataFrame.")
        if hasattr(sda, "obs") and not hasattr(sda, "tables"):
            adata = sda
            obs = adata.obs
            if write_back is None:
                write_back = False
        else:
            from .umap import _load_adata, _write_adata_table_store

            adata, table_store = _load_adata(sda, table)
            obs = adata.obs
            if write_back is None:
                write_back = isinstance(sda, (str, Path))

    out_obs = map_column_labels_df(
        obs,
        mapper=mapper,
        input_col=input_col,
        output_col=output_col,
        unmapped_value=unmapped_value,
        keep_original_for_unmapped=keep_original_for_unmapped,
    )

    if adata is not None:
        adata.obs[output_col] = out_obs[output_col].copy()
        if write_back:
            if table_store is None:
                raise ValueError("write_back=True requires a SpatialData Zarr path input.")
            from .umap import _write_adata_table_store

            _write_adata_table_store(adata, table_store)
        return adata.obs

    return out_obs


def main():
    import argparse
    import json

    parser = argparse.ArgumentParser(description="Map categorical labels from one obs column to another")
    parser.add_argument("input", help="Path to SpatialData .zarr directory")
    parser.add_argument("--table", required=True, help="Table name in sda.tables")
    parser.add_argument("--input-col", required=True, help="Source obs column")
    parser.add_argument("--output-col", required=True, help="Destination obs column")
    parser.add_argument(
        "--mapper-json",
        required=True,
        help="JSON string or path to a JSON file containing a dict-of-lists label mapper",
    )
    parser.add_argument("--unmapped-value", default=None, help="Value to assign to unmapped labels when not keeping originals")
    parser.add_argument("--no-keep-original-for-unmapped", dest="keep_original_for_unmapped", action="store_false")
    parser.add_argument("--no-write-back", dest="write_back", action="store_false")
    parser.set_defaults(write_back=True, keep_original_for_unmapped=True)
    args = parser.parse_args()

    mapper_arg = args.mapper_json
    mapper_path = Path(mapper_arg)
    if mapper_path.exists():
        mapper = json.loads(mapper_path.read_text())
    else:
        mapper = json.loads(mapper_arg)

    map_column_labels(
        args.input,
        table=args.table,
        mapper=mapper,
        input_col=args.input_col,
        output_col=args.output_col,
        unmapped_value=args.unmapped_value,
        keep_original_for_unmapped=args.keep_original_for_unmapped,
        write_back=args.write_back,
    )
    print(f"[histomap.map_column_labels] Wrote obs['{args.output_col}'] for table '{args.table}'.")


if __name__ == "__main__":
    main()
