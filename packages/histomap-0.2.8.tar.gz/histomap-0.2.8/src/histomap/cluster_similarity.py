"""
Headless cluster-similarity plots and meta-cluster summaries.
"""
from __future__ import annotations

from pathlib import Path
from typing import Optional
import re

import matplotlib
import numpy as np
import pandas as pd
from tqdm import tqdm

matplotlib.use("Agg")

from matplotlib import pyplot as plt
from matplotlib import gridspec

try:
    import scipy.sparse as sp
except Exception:
    sp = None  # type: ignore

try:
    from scipy.cluster.hierarchy import dendrogram, fcluster, leaves_list, linkage
    from scipy.spatial.distance import pdist, squareform
except Exception:
    dendrogram = None  # type: ignore
    fcluster = None  # type: ignore
    leaves_list = None  # type: ignore
    linkage = None  # type: ignore
    pdist = None  # type: ignore
    squareform = None  # type: ignore

from .umap import _load_adata


def _sanitize_filename(value: str) -> str:
    value = re.sub(r"[^\w.\-]+", "_", str(value)).strip("_")
    return value or "plot"


def _choose_matrix(adata, *, layer: Optional[str] = None, obsm_key: Optional[str] = None):
    if layer is not None and obsm_key is not None:
        raise ValueError("Pass only one of 'layer' or 'obsm_key'.")
    if obsm_key is not None:
        if obsm_key not in adata.obsm:
            raise KeyError(f"obsm['{obsm_key}'] not found in selected table.")
        return adata.obsm[obsm_key], f"obsm['{obsm_key}']"
    if layer is not None:
        if layer not in adata.layers:
            raise KeyError(f"Layer '{layer}' not found in adata.layers.")
        return adata.layers[layer], f"layer='{layer}'"
    return adata.X, "X"


def _default_output_base(source, table: str, cluster_col: str, output_path: Optional[str | Path]) -> Path:
    if output_path is not None:
        return Path(output_path)
    if isinstance(source, (str, Path)):
        src = Path(source).expanduser().resolve()
        return src.parent / f"{src.stem}_{table}_{cluster_col}_cluster_similarity"
    return Path.cwd() / f"histomap_{table}_{cluster_col}_cluster_similarity"


def _to_float_array(X):
    if sp is not None and sp.issparse(X):
        return X.astype(np.float32)
    return np.asarray(X, dtype=np.float32)


def _cluster_centroids(X, labels: pd.Series, *, progress=None) -> tuple[np.ndarray, pd.Index, pd.Series]:
    cluster_names = pd.Index(pd.unique(labels.astype(str)))
    counts = labels.astype(str).value_counts().reindex(cluster_names)
    centroids = []
    label_arr = labels.astype(str).to_numpy()
    for cluster_name in cluster_names:
        mask = label_arr == str(cluster_name)
        X_grp = X[mask]
        if sp is not None and sp.issparse(X_grp):
            centroid = np.asarray(X_grp.mean(axis=0)).ravel().astype(np.float32, copy=False)
        else:
            centroid = np.asarray(X_grp, dtype=np.float32).mean(axis=0).astype(np.float32, copy=False)
        centroids.append(centroid)
        if progress is not None:
            progress.update(1)
            progress.set_postfix_str(f"centroid={cluster_name}")
    centroid_matrix = np.vstack(centroids).astype(np.float32, copy=False)
    return centroid_matrix, cluster_names, counts


def _similarity_matrix(centroids: np.ndarray, metric: str) -> tuple[np.ndarray, np.ndarray]:
    if pdist is None or squareform is None:
        raise ImportError("scipy is required for cluster similarity and hierarchical clustering.")
    metric = metric.lower()
    if metric not in {"cosine", "correlation", "euclidean"}:
        raise ValueError("metric must be one of: cosine, correlation, euclidean")
    distances = pdist(centroids, metric=metric)
    if metric in {"cosine", "correlation"}:
        similarity = 1.0 - squareform(distances)
        np.fill_diagonal(similarity, 1.0)
    else:
        dist_square = squareform(distances)
        scale = float(dist_square.max()) if dist_square.size else 1.0
        scale = scale if scale > 0 else 1.0
        similarity = 1.0 - (dist_square / scale)
        np.fill_diagonal(similarity, 1.0)
    return similarity, distances


def _meta_cluster_assignments(Z, *, n_meta_clusters: Optional[int], cut_fraction: float) -> np.ndarray:
    if fcluster is None:
        raise ImportError("scipy is required for hierarchical cluster cutting.")
    if n_meta_clusters is not None:
        if n_meta_clusters < 1:
            raise ValueError("n_meta_clusters must be >= 1.")
        return fcluster(Z, t=int(n_meta_clusters), criterion="maxclust").astype(int)
    max_height = float(np.max(Z[:, 2])) if Z.size else 0.0
    if max_height <= 0:
        return np.ones(Z.shape[0] + 1, dtype=int)
    cut_height = max_height * float(cut_fraction)
    return fcluster(Z, t=cut_height, criterion="distance").astype(int)


def _plot_similarity_heatmap(
    *,
    similarity: np.ndarray,
    Z,
    cluster_names: pd.Index,
    counts: pd.Series,
    meta_labels: np.ndarray,
    output_file: Path,
    metric: str,
    source_label: str,
    table: str,
    cluster_col: str,
):
    if dendrogram is None or leaves_list is None:
        raise ImportError("scipy is required for dendrogram plotting.")
    leaf_order = leaves_list(Z) if len(cluster_names) > 1 else np.array([0], dtype=int)
    sim_ord = similarity[np.ix_(leaf_order, leaf_order)]
    names_ord = cluster_names[leaf_order]
    counts_ord = counts.reindex(names_ord)
    meta_ord = meta_labels[leaf_order]

    fig = plt.figure(figsize=(10.5, 9.5), dpi=180)
    gs = gridspec.GridSpec(
        2,
        3,
        width_ratios=[1.4, 6.0, 0.28],
        height_ratios=[1.3, 6.0],
        wspace=0.06,
        hspace=0.03,
    )

    ax_dend_col = fig.add_subplot(gs[0, 1])
    if len(cluster_names) > 1:
        dendrogram(Z, labels=cluster_names.astype(str).tolist(), ax=ax_dend_col, no_labels=True, color_threshold=None)
    ax_dend_col.set_xticks([])
    ax_dend_col.set_yticks([])
    for spine in ax_dend_col.spines.values():
        spine.set_visible(False)

    ax_dend_row = fig.add_subplot(gs[1, 0])
    if len(cluster_names) > 1:
        dendrogram(Z, labels=cluster_names.astype(str).tolist(), ax=ax_dend_row, orientation="left", no_labels=True, color_threshold=None)
    ax_dend_row.set_xticks([])
    ax_dend_row.set_yticks([])
    for spine in ax_dend_row.spines.values():
        spine.set_visible(False)

    ax_heat = fig.add_subplot(gs[1, 1])
    im = ax_heat.imshow(sim_ord, cmap="viridis", vmin=0.0, vmax=1.0, interpolation="nearest", aspect="auto")
    ax_heat.set_xticks(np.arange(len(names_ord)))
    ax_heat.set_yticks(np.arange(len(names_ord)))
    ax_heat.set_xticklabels([str(x) for x in names_ord], rotation=90, fontsize=6)
    ax_heat.set_yticklabels([str(x) for x in names_ord], fontsize=6)
    ax_heat.set_xlabel(cluster_col)
    ax_heat.set_ylabel(cluster_col)

    title = (
        f"Cluster similarity for {table}\n"
        f"source={source_label} metric={metric} "
        f"meta_clusters={len(pd.unique(meta_labels))}"
    )
    ax_dend_col.set_title(title, fontsize=11)

    ax_cbar = fig.add_subplot(gs[1, 2])
    cbar = fig.colorbar(im, cax=ax_cbar)
    cbar.set_label("Similarity")
    fig.subplots_adjust(left=0.08, right=0.96, top=0.93, bottom=0.08)
    fig.savefig(output_file, bbox_inches="tight")
    plt.close(fig)

    return leaf_order


def cluster_similarity(
    sda,
    table: str,
    cluster_col: str,
    *,
    layer: Optional[str] = None,
    obsm_key: Optional[str] = None,
    metric: str = "cosine",
    linkage_method: str = "average",
    n_meta_clusters: Optional[int] = None,
    meta_cut_fraction: float = 0.7,
    output_path: Optional[str | Path] = None,
    show_progress: bool = True,
):
    """
    Compute cluster-level similarity, hierarchical clustering, and meta-cluster assignments.

    Saves:
    - a heatmap PDF with dendrograms
    - a summary CSV mapping cluster -> meta cluster
    """
    adata, _ = _load_adata(sda, table)
    if cluster_col not in adata.obs:
        raise KeyError(f"obs['{cluster_col}'] not found in table '{table}'.")

    labels = adata.obs[cluster_col]
    labels = labels[~pd.isna(labels)]
    if labels.empty:
        raise ValueError(f"obs['{cluster_col}'] has no non-null values.")
    valid_idx = labels.index

    X, source_label = _choose_matrix(adata, layer=layer, obsm_key=obsm_key)
    X = X[adata.obs_names.get_indexer(valid_idx)]
    X = _to_float_array(X)

    if linkage_method == "ward" and metric != "euclidean":
        raise ValueError("linkage_method='ward' requires metric='euclidean'.")

    cluster_names = pd.Index(pd.unique(labels.astype(str)))
    progress = tqdm(
        total=len(cluster_names) + 3,
        desc=f"ClusterSim:{table}",
        disable=not show_progress,
        unit="step",
        dynamic_ncols=True,
        leave=False,
    )
    progress.set_postfix_str(f"source={source_label}")
    progress.update(1)

    centroid_matrix, cluster_names, counts = _cluster_centroids(X, labels, progress=progress)
    similarity, condensed_dist = _similarity_matrix(centroid_matrix, metric)
    progress.set_postfix_str("similarity matrix")
    progress.update(1)

    if linkage is None:
        raise ImportError("scipy is required for hierarchical clustering.")
    Z = linkage(condensed_dist, method=linkage_method) if len(cluster_names) > 1 else np.empty((0, 4), dtype=float)
    meta_labels = (
        _meta_cluster_assignments(Z, n_meta_clusters=n_meta_clusters, cut_fraction=meta_cut_fraction)
        if len(cluster_names) > 1
        else np.array([1], dtype=int)
    )
    progress.set_postfix_str("hierarchical clustering")
    progress.update(1)

    out_base = _default_output_base(sda, table, cluster_col, output_path)
    out_base.parent.mkdir(parents=True, exist_ok=True)
    heatmap_path = out_base.with_suffix(".pdf")
    summary_path = out_base.with_name(f"{out_base.name}_summary.csv")

    leaf_order = _plot_similarity_heatmap(
        similarity=similarity,
        Z=Z,
        cluster_names=cluster_names,
        counts=counts,
        meta_labels=meta_labels,
        output_file=heatmap_path,
        metric=metric,
        source_label=source_label,
        table=table,
        cluster_col=cluster_col,
    )
    cluster_to_meta = pd.DataFrame(
        {
            "cluster": cluster_names.astype(str),
            "n_obs": counts.reindex(cluster_names).astype(int).values,
            "meta_cluster": meta_labels.astype(int),
        }
    )
    order_map = {cluster_names[i]: int(pos) for pos, i in enumerate(leaf_order)}
    cluster_to_meta["leaf_order"] = cluster_to_meta["cluster"].map(order_map).astype(int)
    cluster_to_meta["source"] = source_label
    cluster_to_meta["metric"] = metric
    cluster_to_meta["linkage_method"] = linkage_method
    cluster_to_meta.to_csv(summary_path, index=False)

    progress.set_postfix_str(f"saved={heatmap_path.name}")
    progress.update(1)
    progress.close()
    if show_progress:
        print(
            f"[histomap.cluster_similarity] Done table='{table}' cluster_col='{cluster_col}' "
            f"clusters={len(cluster_names)} meta_clusters={cluster_to_meta['meta_cluster'].nunique()} "
            f"heatmap='{heatmap_path}' summary='{summary_path}'"
        )
    return {"heatmap_pdf": heatmap_path, "summary_csv": summary_path}


def main():
    import argparse

    parser = argparse.ArgumentParser(description="Plot cluster similarity heatmap with dendrogram and save meta-cluster summary CSV")
    parser.add_argument("input", help="Path to SpatialData .zarr directory")
    parser.add_argument("--table", required=True, help="Table name in sda.tables to use")
    parser.add_argument("--cluster-col", required=True, help="obs column containing cluster labels")
    parser.add_argument("--layer", default=None, help="Optional layer to compute cluster centroids from")
    parser.add_argument("--obsm-key", default=None, help="Optional obsm key to compute cluster centroids from")
    parser.add_argument("--metric", choices=["cosine", "correlation", "euclidean"], default="cosine")
    parser.add_argument("--linkage-method", choices=["average", "complete", "single", "ward"], default="average")
    parser.add_argument("--n-meta-clusters", type=int, default=None, help="Optional fixed number of meta-clusters")
    parser.add_argument("--meta-cut-fraction", type=float, default=0.7, help="Tree-height fraction used to infer meta-clusters when n-meta-clusters is not set")
    parser.add_argument("--output-path", default=None, help="Optional output base path without extension")
    parser.add_argument("--quiet", action="store_true", help="Disable progress output")
    args = parser.parse_args()

    cluster_similarity(
        args.input,
        table=args.table,
        cluster_col=args.cluster_col,
        layer=args.layer,
        obsm_key=args.obsm_key,
        metric=args.metric,
        linkage_method=args.linkage_method,
        n_meta_clusters=args.n_meta_clusters,
        meta_cut_fraction=args.meta_cut_fraction,
        output_path=args.output_path,
        show_progress=not args.quiet,
    )


if __name__ == "__main__":
    main()
