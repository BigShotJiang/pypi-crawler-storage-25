"""
Utilities for merging two categorical annotation columns into a consensus label.

The core implementation operates on a pandas DataFrame. A thin AnnData/SpatialData
wrapper reads and writes only the requested table when a SpatialData Zarr path is used.
"""
from __future__ import annotations

from pathlib import Path
from typing import Iterable, Optional

import numpy as np
import pandas as pd


MISSING_TOKEN = "__missing__"


def _as_set(values: Optional[Iterable]) -> set[str]:
    if values is None:
        return set()
    return {str(v) for v in values}


def _normalize_labels(series: pd.Series, *, missing_labels: set[str]) -> pd.Series:
    """Normalize arbitrary categorical labels to object strings plus a missing sentinel."""
    out = series.astype("object").copy()
    missing = pd.isna(out) | out.astype(str).isin(missing_labels)
    out = out.astype(str)
    out[missing] = MISSING_TOKEN
    return out


def _label_membership(series: pd.Series, labels: set[str]) -> pd.Series:
    """Robust label matching across categorical/int/string dtypes."""
    if not labels:
        return pd.Series(False, index=series.index)
    return series.astype("object").astype(str).isin(labels)


def _display_label(value: object, *, missing_display: str = "-1"):
    if value == MISSING_TOKEN:
        return missing_display
    return value


def _preferred_missing_display(*label_groups) -> str:
    candidates: list[str] = []
    for group in label_groups:
        if group is None:
            continue
        for value in group:
            text = str(value)
            if text == MISSING_TOKEN:
                continue
            candidates.append(text)
    if not candidates:
        return "-1"
    if "-1" in candidates:
        return "-1"
    generic = {"", "nan", "NaN", "None", "NA"}
    specific = [c for c in candidates if c not in generic]
    if specific:
        return sorted(pd.unique(specific).tolist())[0]
    return sorted(pd.unique(candidates).tolist())[0]


def _build_overlap_tables(
    primary: pd.Series,
    secondary: pd.Series,
    *,
    primary_col: str,
    secondary_col: str,
    missing_display: str,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    counts = pd.crosstab(
        secondary.rename(secondary_col),
        primary.rename(primary_col),
        dropna=False,
    )
    fractions = counts.div(counts.sum(axis=1).replace(0, np.nan), axis=0).fillna(0.0)
    counts.index = [_display_label(v, missing_display=missing_display) for v in counts.index]
    counts.columns = [_display_label(v, missing_display=missing_display) for v in counts.columns]
    fractions.index = counts.index
    fractions.columns = counts.columns
    return counts, fractions


def _summarize_secondary_groups(
    primary: pd.Series,
    secondary: pd.Series,
    *,
    primary_col: str,
    secondary_col: str,
    missing_display: str,
) -> pd.DataFrame:
    rows = []
    grouped = pd.DataFrame({"primary": primary, "secondary": secondary}).groupby("secondary", dropna=False)
    for secondary_label, group in grouped:
        counts = group["primary"].value_counts(dropna=False)
        total = int(counts.sum())
        dominant = counts.index[0] if total else MISSING_TOKEN
        purity = float(counts.iloc[0] / total) if total else np.nan
        rows.append(
            {
                secondary_col: _display_label(secondary_label, missing_display=missing_display),
                "_secondary_key": secondary_label,
                "dominant_primary": _display_label(dominant, missing_display=missing_display),
                "_dominant_key": dominant,
                "purity": purity,
                "n": total,
                "n_primary_labels": int(counts.shape[0]),
            }
        )
    return pd.DataFrame(rows).sort_values(["purity", "n"], ascending=[False, False]).reset_index(drop=True)


def _summarize_primary_groups(
    primary: pd.Series,
    secondary: pd.Series,
    *,
    primary_col: str,
    secondary_col: str,
    missing_display: str,
) -> pd.DataFrame:
    rows = []
    grouped = pd.DataFrame({"primary": primary, "secondary": secondary}).groupby("primary", dropna=False)
    for primary_label, group in grouped:
        counts = group["secondary"].value_counts(dropna=False)
        total = int(counts.sum())
        dominant = counts.index[0] if total else MISSING_TOKEN
        purity = float(counts.iloc[0] / total) if total else np.nan
        rows.append(
            {
                primary_col: _display_label(primary_label, missing_display=missing_display),
                "_primary_key": primary_label,
                "dominant_secondary": _display_label(dominant, missing_display=missing_display),
                "_dominant_secondary_key": dominant,
                "secondary_purity": purity,
                "n": total,
                "n_secondary_labels": int(counts.shape[0]),
            }
        )
    return pd.DataFrame(rows).sort_values(["secondary_purity", "n"], ascending=[False, False]).reset_index(drop=True)


def _consensus_one(
    *,
    primary_key: str,
    secondary_key: str,
    dominant_key: str,
    purity: float,
    primary_dominant_secondary_key: str,
    primary_secondary_purity: float,
    primary_n: int,
    protected_primary_labels: set[str],
    broad_primary_labels: set[str],
    purity_threshold: float,
    primary_minority_purity_threshold: float,
    primary_minority_min_n: int,
    ambiguous_label: str,
    use_ambiguous_when_discordant: bool,
    preserve_specific_primary: bool,
    preserve_coherent_primary_minority: bool,
) -> tuple[str, str, str]:
    primary_missing = primary_key == MISSING_TOKEN
    dominant_missing = dominant_key == MISSING_TOKEN or pd.isna(dominant_key)
    protected = primary_key in protected_primary_labels and not primary_missing
    broad_or_weak_primary = primary_missing or primary_key in broad_primary_labels
    high_purity = bool(pd.notna(purity) and purity >= purity_threshold)
    concordant = (not primary_missing) and (not dominant_missing) and primary_key == dominant_key
    discordant = (not primary_missing) and (not dominant_missing) and primary_key != dominant_key

    if protected:
        return primary_key, "primary_protected", "high"
    if concordant:
        return primary_key, "concordant", "high" if high_purity else "medium"
    if high_purity and broad_or_weak_primary and not dominant_missing:
        return dominant_key, "secondary_refined", "high"
    coherent_primary_minority = (
        preserve_coherent_primary_minority
        and discordant
        and not broad_or_weak_primary
        and primary_dominant_secondary_key == secondary_key
        and pd.notna(primary_secondary_purity)
        and primary_secondary_purity >= primary_minority_purity_threshold
        and int(primary_n) >= primary_minority_min_n
    )
    if coherent_primary_minority:
        confidence = "high" if primary_secondary_purity >= purity_threshold else "medium"
        return primary_key, "primary_minority", confidence
    if preserve_specific_primary and discordant and not broad_or_weak_primary:
        return primary_key, "primary_default", "medium"
    if use_ambiguous_when_discordant and discordant:
        return ambiguous_label, "ambiguous", "low"
    if use_ambiguous_when_discordant and primary_missing and not high_purity:
        return ambiguous_label, "ambiguous", "low"
    if primary_missing:
        return ambiguous_label, "ambiguous", "low"
    return primary_key, "primary_default", "medium" if not discordant else "low"


def merge_categorical_annotations_df(
    df: pd.DataFrame,
    primary_col: str,
    secondary_col: str,
    *,
    protected_primary_labels: Optional[Iterable] = None,
    broad_primary_labels: Optional[Iterable] = None,
    missing_labels: Optional[Iterable] = None,
    purity_threshold: float = 0.8,
    ambiguous_label: str = "0",
    use_ambiguous_when_discordant: bool = False,
    preserve_specific_primary: bool = False,
    preserve_coherent_primary_minority: bool = True,
    primary_minority_purity_threshold: float = 0.6,
    primary_minority_min_n: int = 5,
    force_ambiguous_col: Optional[str] = None,
    force_ambiguous_labels: Optional[Iterable] = None,
    output_prefix: str = "consensus",
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """
    Merge two categorical annotation columns into a row-level consensus label.

    Parameters
    ----------
    df:
        Input dataframe, typically `adata.obs`.
    primary_col:
        Column containing the primary annotation system.
    secondary_col:
        Column containing the secondary annotation system whose groups are summarized
        against `primary_col`.
    protected_primary_labels:
        Primary labels that should always be retained when present.
    broad_primary_labels:
        Primary labels considered broad/uncertain and eligible for secondary-driven
        refinement when secondary purity is high.
    missing_labels:
        Extra values to treat as missing, for example ["", "Unknown", "NA"].
    purity_threshold:
        Minimum secondary-group purity needed for secondary-driven refinement.
    ambiguous_label:
        Label assigned when ambiguity should be preserved.
    force_ambiguous_col:
        Optional dataframe column. Rows with values in `force_ambiguous_labels` are
        forced to `ambiguous_label`.
    force_ambiguous_labels:
        Labels in `force_ambiguous_col` that should force ambiguity. Defaults to ["-1"].
    use_ambiguous_when_discordant:
        If True, weak discordant evidence becomes `ambiguous_label` rather than
        retaining the primary label.
    preserve_specific_primary:
        If True, any non-missing primary labels that are not in `broad_primary_labels`
        are retained even when discordant. This is disabled by default because it is
        intentionally broad.
    preserve_coherent_primary_minority:
        If True, retain a minority primary label when that primary label is mostly
        concentrated in the same secondary group. This protects rare coherent groups
        such as a Treg-like primary label embedded in a broader T-cell Leiden cluster
        without hardcoding biological labels.
    primary_minority_purity_threshold:
        Minimum fraction of a primary label that must fall in its dominant secondary
        group before it is treated as a coherent minority.
    primary_minority_min_n:
        Minimum size of a primary label before coherent-minority preservation applies.
    output_prefix:
        Prefix for added columns.

    Returns
    -------
    modified_df, summary, counts, fractions, label_frequency, source_frequency
    """
    if primary_col not in df.columns:
        raise KeyError(f"Column '{primary_col}' not found.")
    if secondary_col not in df.columns:
        raise KeyError(f"Column '{secondary_col}' not found.")
    if force_ambiguous_col is not None and force_ambiguous_col not in df.columns:
        raise KeyError(f"Column '{force_ambiguous_col}' not found.")
    if not (0 <= purity_threshold <= 1):
        raise ValueError("purity_threshold must be between 0 and 1.")
    if not (0 <= primary_minority_purity_threshold <= 1):
        raise ValueError("primary_minority_purity_threshold must be between 0 and 1.")

    missing_set = _as_set(missing_labels) | {"", "nan", "None", "NA", "NaN"}
    missing_display = _preferred_missing_display(missing_set)
    protected_set = _as_set(protected_primary_labels)
    broad_set = _as_set(broad_primary_labels) | missing_set
    force_ambiguous_set = _as_set(force_ambiguous_labels if force_ambiguous_labels is not None else ["-1"])

    out = df.copy()
    primary = _normalize_labels(out[primary_col], missing_labels=missing_set)
    secondary = _normalize_labels(out[secondary_col], missing_labels=missing_set)

    counts, fractions = _build_overlap_tables(
        primary,
        secondary,
        primary_col=primary_col,
        secondary_col=secondary_col,
        missing_display=missing_display,
    )
    summary = _summarize_secondary_groups(
        primary,
        secondary,
        primary_col=primary_col,
        secondary_col=secondary_col,
        missing_display=missing_display,
    )
    primary_summary = _summarize_primary_groups(
        primary,
        secondary,
        primary_col=primary_col,
        secondary_col=secondary_col,
        missing_display=missing_display,
    )

    summary_by_key = summary.set_index("_secondary_key")
    mapped = summary_by_key.reindex(secondary)
    primary_summary_by_key = primary_summary.set_index("_primary_key")
    primary_mapped = primary_summary_by_key.reindex(primary)
    out[f"{output_prefix}_secondary_dominant"] = mapped["_dominant_key"].map(
        lambda x: _display_label(x, missing_display=missing_display)
    ).to_numpy()
    out[f"{output_prefix}_secondary_purity"] = mapped["purity"].astype(float).to_numpy()
    out[f"{output_prefix}_secondary_n"] = mapped["n"].astype("Int64").to_numpy()
    out[f"{output_prefix}_secondary_n_primary_labels"] = mapped["n_primary_labels"].astype("Int64").to_numpy()
    out[f"{output_prefix}_primary_dominant_secondary"] = primary_mapped["_dominant_secondary_key"].map(
        lambda x: _display_label(x, missing_display=missing_display)
    ).to_numpy()
    out[f"{output_prefix}_primary_secondary_purity"] = primary_mapped["secondary_purity"].astype(float).to_numpy()
    out[f"{output_prefix}_primary_n"] = primary_mapped["n"].astype("Int64").to_numpy()

    labels = []
    sources = []
    confidence = []
    for pk, sk, dk, purity, psk, psp, pn in zip(
        primary,
        secondary,
        mapped["_dominant_key"],
        mapped["purity"],
        primary_mapped["_dominant_secondary_key"],
        primary_mapped["secondary_purity"],
        primary_mapped["n"],
    ):
        label, source, conf = _consensus_one(
            primary_key=pk,
            secondary_key=sk,
            dominant_key=dk,
            purity=float(purity) if pd.notna(purity) else np.nan,
            primary_dominant_secondary_key=psk,
            primary_secondary_purity=float(psp) if pd.notna(psp) else np.nan,
            primary_n=int(pn) if pd.notna(pn) else 0,
            protected_primary_labels=protected_set,
            broad_primary_labels=broad_set,
            purity_threshold=purity_threshold,
            primary_minority_purity_threshold=primary_minority_purity_threshold,
            primary_minority_min_n=primary_minority_min_n,
            ambiguous_label=ambiguous_label,
            use_ambiguous_when_discordant=use_ambiguous_when_discordant,
            preserve_specific_primary=preserve_specific_primary,
            preserve_coherent_primary_minority=preserve_coherent_primary_minority,
        )
        labels.append(_display_label(label, missing_display=missing_display))
        sources.append(source)
        confidence.append(conf)

    out[f"{output_prefix}_label"] = pd.Categorical(labels)
    out[f"{output_prefix}_source"] = pd.Categorical(
        sources,
        categories=["primary_protected", "concordant", "secondary_refined", "primary_minority", "primary_default", "ambiguous"],
    )
    out[f"{output_prefix}_confidence"] = pd.Categorical(confidence, categories=["high", "medium", "low"])
    if force_ambiguous_col is not None:
        force_mask = _label_membership(out[force_ambiguous_col], force_ambiguous_set)
        if force_mask.any():
            label_series = out[f"{output_prefix}_label"].astype(object)
            source_series = out[f"{output_prefix}_source"].astype(object)
            confidence_series = out[f"{output_prefix}_confidence"].astype(object)
            label_series.loc[force_mask] = ambiguous_label
            source_series.loc[force_mask] = "ambiguous"
            confidence_series.loc[force_mask] = "low"
            out[f"{output_prefix}_label"] = pd.Categorical(label_series)
            out[f"{output_prefix}_source"] = pd.Categorical(
                source_series,
                categories=["primary_protected", "concordant", "secondary_refined", "primary_minority", "primary_default", "ambiguous"],
            )
            out[f"{output_prefix}_confidence"] = pd.Categorical(confidence_series, categories=["high", "medium", "low"])

    public_summary = summary.drop(columns=["_secondary_key", "_dominant_key"])
    out.attrs[f"{output_prefix}_primary_summary"] = primary_summary.drop(columns=["_primary_key", "_dominant_secondary_key"])
    label_freq = out[f"{output_prefix}_label"].value_counts(dropna=False).rename_axis(f"{output_prefix}_label").reset_index(name="n")
    source_freq = out[f"{output_prefix}_source"].value_counts(dropna=False).rename_axis(f"{output_prefix}_source").reset_index(name="n")
    return out, public_summary, counts, fractions, label_freq, source_freq


def _consensus_uns_payload(
    out_obs: pd.DataFrame,
    summary: pd.DataFrame,
    counts: pd.DataFrame,
    fractions: pd.DataFrame,
    label_freq: pd.DataFrame,
    source_freq: pd.DataFrame,
    *,
    output_prefix: str,
    output_col: str,
    primary_col: str,
    secondary_col: str,
    purity_threshold: float,
    primary_minority_purity_threshold: float,
    primary_minority_min_n: int,
    ambiguous_label: str,
    use_ambiguous_when_discordant: bool,
    preserve_specific_primary: bool,
    preserve_coherent_primary_minority: bool,
    force_ambiguous_col: Optional[str],
    force_ambiguous_labels: Optional[Iterable],
    protected_primary_labels: Optional[Iterable],
    broad_primary_labels: Optional[Iterable],
    missing_labels: Optional[Iterable],
) -> dict:
    detail_cols = [
        f"{output_prefix}_secondary_dominant",
        f"{output_prefix}_secondary_purity",
        f"{output_prefix}_secondary_n",
        f"{output_prefix}_secondary_n_primary_labels",
        f"{output_prefix}_primary_dominant_secondary",
        f"{output_prefix}_primary_secondary_purity",
        f"{output_prefix}_primary_n",
        f"{output_prefix}_source",
        f"{output_prefix}_confidence",
    ]
    row_details = out_obs[[c for c in detail_cols if c in out_obs.columns]].copy()
    primary_summary = out_obs.attrs.get(f"{output_prefix}_primary_summary")
    return {
        "params": {
            "output_col": output_col,
            "primary_col": primary_col,
            "secondary_col": secondary_col,
            "purity_threshold": purity_threshold,
            "primary_minority_purity_threshold": primary_minority_purity_threshold,
            "primary_minority_min_n": primary_minority_min_n,
            "ambiguous_label": ambiguous_label,
            "force_ambiguous_col": force_ambiguous_col,
            "force_ambiguous_labels": list(force_ambiguous_labels or ["-1"]),
            "use_ambiguous_when_discordant": use_ambiguous_when_discordant,
            "preserve_specific_primary": preserve_specific_primary,
            "preserve_coherent_primary_minority": preserve_coherent_primary_minority,
            "protected_primary_labels": list(protected_primary_labels or []),
            "broad_primary_labels": list(broad_primary_labels or []),
            "missing_labels": list(missing_labels or []),
        },
        "row_details": row_details,
        "secondary_summary": summary,
        "primary_summary": primary_summary,
        "overlap_counts": counts,
        "overlap_fractions": fractions,
        "label_frequency": label_freq,
        "source_frequency": source_freq,
    }


def find_mixed_secondary_groups(summary: pd.DataFrame, *, purity_threshold: float = 0.8, min_n: int = 1) -> pd.DataFrame:
    """Return secondary groups with mixed primary-label composition."""
    return summary[(summary["purity"] < purity_threshold) & (summary["n"] >= min_n)].sort_values(["purity", "n"])


def most_discordant_combinations(counts: pd.DataFrame, *, top_n: int = 20) -> pd.DataFrame:
    """Return high-count off-diagonal combinations from a contingency table."""
    records = []
    for secondary_label in counts.index:
        dominant_primary = counts.loc[secondary_label].idxmax()
        for primary_label, n in counts.loc[secondary_label].items():
            if primary_label != dominant_primary and int(n) > 0:
                records.append(
                    {
                        "secondary_label": secondary_label,
                        "primary_label": primary_label,
                        "dominant_primary_for_secondary": dominant_primary,
                        "n": int(n),
                    }
                )
    return pd.DataFrame(records).sort_values("n", ascending=False).head(top_n).reset_index(drop=True)


def plot_overlap_heatmap(fractions: pd.DataFrame, *, figsize=(8, 6), cmap: str = "viridis"):
    """Optional matplotlib heatmap for a row-normalized overlap fraction table."""
    import matplotlib.pyplot as plt

    fig, ax = plt.subplots(figsize=figsize)
    im = ax.imshow(fractions.to_numpy(dtype=float), aspect="auto", cmap=cmap, vmin=0, vmax=1)
    ax.set_xticks(np.arange(fractions.shape[1]))
    ax.set_yticks(np.arange(fractions.shape[0]))
    ax.set_xticklabels(fractions.columns, rotation=90)
    ax.set_yticklabels(fractions.index)
    ax.set_xlabel("Primary label")
    ax.set_ylabel("Secondary label")
    fig.colorbar(im, ax=ax, label="Fraction within secondary label")
    fig.tight_layout()
    return fig, ax


def _resolved_label_metadata(label_metadata: dict, col_a: str, col_b: str) -> dict:
    """
    Expand semantic metadata aliases onto the actual column names used in this run.

    This lets callers provide either:
    - label_metadata keyed by the real column names, or
    - label_metadata keyed by the semantic roles "he_annotation" / "if_annotation"

    without the downstream logic depending on hardcoded role keys.
    """
    resolved = dict(label_metadata)
    alias_map = {
        "he_annotation": col_a,
        "if_annotation": col_b,
    }
    for alias, actual_col in alias_map.items():
        if actual_col not in resolved and alias in resolved:
            resolved[actual_col] = resolved[alias]
    return resolved


def _normalize_label_metadata(label_metadata: dict, col_a: str, col_b: str) -> dict[str, dict[str, set[str]]]:
    resolved = _resolved_label_metadata(label_metadata, col_a, col_b)
    normalized: dict[str, dict[str, set[str]]] = {}
    for col in [col_a, col_b]:
        meta = resolved.get(col, {})
        normalized[col] = {
            "missing": _as_set(meta.get("missing")),
            "ambiguous": _as_set(meta.get("ambiguous")),
            "broad": _as_set(meta.get("broad")),
            "specific": _as_set(meta.get("specific")),
        }
    return normalized


def _sanitize_uns_payload(value):
    """
    Convert Python container types that Zarr/AnnData cannot write directly
    (especially sets) into serialization-safe equivalents while preserving
    DataFrames/Series used for diagnostics.
    """
    if isinstance(value, dict):
        return {str(k): _sanitize_uns_payload(v) for k, v in value.items()}
    if isinstance(value, set):
        return sorted(_sanitize_uns_payload(v) for v in value)
    if isinstance(value, tuple):
        return [_sanitize_uns_payload(v) for v in value]
    if isinstance(value, list):
        return [_sanitize_uns_payload(v) for v in value]
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, (pd.Index, pd.CategoricalIndex)):
        return [_sanitize_uns_payload(v) for v in value.tolist()]
    if isinstance(value, np.generic):
        return value.item()
    return value


def _label_kind(label: str, meta: dict[str, set[str]]) -> str:
    if label == MISSING_TOKEN or label in meta["missing"]:
        return "missing"
    if label in meta["ambiguous"]:
        return "ambiguous"
    if label in meta["broad"]:
        return "broad"
    if label in meta["specific"]:
        return "specific"
    return "untyped"


def _conditional_fraction(ct: pd.DataFrame, row_label: str, col_label: str) -> float:
    try:
        row = ct.loc[row_label]
        total = float(row.sum())
        if total <= 0:
            return 0.0
        return float(row.get(col_label, 0) / total)
    except Exception:
        return 0.0


def _summarize_label_to_other(
    source: pd.Series,
    other: pd.Series,
    *,
    source_col: str,
    other_col: str,
    missing_display: str,
) -> pd.DataFrame:
    rows = []
    grouped = pd.DataFrame({"source": source, "other": other}).groupby("source", dropna=False)
    for source_label, group in grouped:
        counts = group["other"].value_counts(dropna=False)
        total = int(counts.sum())
        dominant = counts.index[0] if total else MISSING_TOKEN
        purity = float(counts.iloc[0] / total) if total else np.nan
        rows.append(
            {
                source_col: _display_label(source_label, missing_display=missing_display),
                "_source_key": source_label,
                f"dominant_{other_col}": _display_label(dominant, missing_display=missing_display),
                f"_dominant_{other_col}_key": dominant,
                f"{other_col}_purity": purity,
                "n": total,
                f"n_{other_col}_labels": int(counts.shape[0]),
            }
        )
    return pd.DataFrame(rows).sort_values([f"{other_col}_purity", "n"], ascending=[False, False]).reset_index(drop=True)


def _resolve_dual_annotation(
    *,
    label_a: str,
    label_b: str,
    kind_a: str,
    kind_b: str,
    frac_b_given_a: float,
    frac_a_given_b: float,
    ambiguous_label: str,
    broad_specific_support_threshold: float,
    untyped_specific_support_threshold: float,
) -> tuple[str, str, str]:
    # Exact agreement is the strongest signal regardless of label kind.
    if label_a == label_b:
        confidence = "high" if kind_a == kind_b == "specific" else "medium"
        return label_a, "concordant", confidence

    noninformative = {"missing", "ambiguous"}
    informative_a = kind_a not in noninformative
    informative_b = kind_b not in noninformative

    if not informative_a and not informative_b:
        return ambiguous_label, "both_noninformative", "low"
    if not informative_a and informative_b:
        confidence = "high" if kind_b == "specific" else "medium"
        return label_b, "source_b_informative", confidence
    if informative_a and not informative_b:
        confidence = "high" if kind_a == "specific" else "medium"
        return label_a, "source_a_informative", confidence

    # broad vs specific: keep the specific label if it is well-contained inside the broad label
    if kind_a == "broad" and kind_b == "specific":
        if frac_a_given_b >= broad_specific_support_threshold:
            return label_b, "source_b_refined", "high"
        return ambiguous_label, "broad_specific_conflict", "low"
    if kind_a == "specific" and kind_b == "broad":
        if frac_b_given_a >= broad_specific_support_threshold:
            return label_a, "source_a_refined", "high"
        return ambiguous_label, "broad_specific_conflict", "low"

    # specific vs specific with disagreement is ambiguous unless one is strongly nested in the other source label.
    if kind_a == kind_b == "specific":
        return ambiguous_label, "specific_conflict", "low"

    # untyped can win over broad only with strong support; otherwise be conservative.
    if kind_a == "untyped" and kind_b == "specific":
        if frac_a_given_b >= untyped_specific_support_threshold:
            return label_b, "source_b_supported", "medium"
        return ambiguous_label, "untyped_specific_conflict", "low"
    if kind_a == "specific" and kind_b == "untyped":
        if frac_b_given_a >= untyped_specific_support_threshold:
            return label_a, "source_a_supported", "medium"
        return ambiguous_label, "untyped_specific_conflict", "low"

    if kind_a == "untyped" and kind_b == "broad":
        if frac_a_given_b >= broad_specific_support_threshold and frac_b_given_a >= 0.2:
            return label_b, "source_b_supported", "medium"
        return ambiguous_label, "untyped_broad_conflict", "low"
    if kind_a == "broad" and kind_b == "untyped":
        if frac_b_given_a >= broad_specific_support_threshold and frac_a_given_b >= 0.2:
            return label_a, "source_a_supported", "medium"
        return ambiguous_label, "untyped_broad_conflict", "low"

    if kind_a == kind_b == "broad":
        return ambiguous_label, "broad_conflict", "low"
    if kind_a == kind_b == "untyped":
        return ambiguous_label, "untyped_conflict", "low"

    # Fallback for mixed residual cases.
    return ambiguous_label, "discordant", "low"


def reconcile_annotation_sources_df(
    df: pd.DataFrame,
    he_annotation: Optional[str] = None,
    if_annotation: Optional[str] = None,
    *,
    col_a: Optional[str] = None,
    col_b: Optional[str] = None,
    label_metadata: dict,
    ambiguous_label: str = "0",
    broad_specific_support_threshold: float = 0.6,
    untyped_specific_support_threshold: float = 0.75,
    output_prefix: str = "reconcile",
) -> tuple[pd.DataFrame, dict]:
    """
    Reconcile two annotation columns using metadata-defined label kinds and overlap support.

    Parameters
    ----------
    df:
        Input dataframe, usually `adata.obs`.
    he_annotation, if_annotation:
        The two annotation columns to reconcile, typically H&E and IF labels.
    col_a, col_b:
        Deprecated aliases for `he_annotation` and `if_annotation`.
    label_metadata:
        Dict keyed by column name. Each entry may contain sets/lists for:
        `missing`, `ambiguous`, `broad`, `specific`.
    ambiguous_label:
        Output label used when the two sources cannot be reconciled confidently.
    broad_specific_support_threshold:
        Minimum conditional support required to let a specific label refine a broad one.
    untyped_specific_support_threshold:
        Higher support threshold used when an untyped label conflicts with a specific label.
    output_prefix:
        Prefix used only for diagnostics returned in the payload.

    Returns
    -------
    modified_df, diagnostics_dict
    """
    he_annotation = he_annotation or col_a
    if_annotation = if_annotation or col_b
    if he_annotation is None or if_annotation is None:
        raise ValueError("Both 'he_annotation' and 'if_annotation' are required.")
    col_a = he_annotation
    col_b = if_annotation
    if col_a not in df.columns:
        raise KeyError(f"Column '{col_a}' not found.")
    if col_b not in df.columns:
        raise KeyError(f"Column '{col_b}' not found.")

    meta = _normalize_label_metadata(label_metadata, col_a, col_b)
    missing_display = _preferred_missing_display(meta[col_a]["missing"], meta[col_b]["missing"])
    out = df.copy()
    a = _normalize_labels(out[col_a], missing_labels=meta[col_a]["missing"])
    b = _normalize_labels(out[col_b], missing_labels=meta[col_b]["missing"])

    ct_a_to_b = pd.crosstab(a, b, dropna=False)
    ct_b_to_a = pd.crosstab(b, a, dropna=False)
    frac_a_to_b = ct_a_to_b.div(ct_a_to_b.sum(axis=1).replace(0, np.nan), axis=0).fillna(0.0)
    frac_b_to_a = ct_b_to_a.div(ct_b_to_a.sum(axis=1).replace(0, np.nan), axis=0).fillna(0.0)

    summary_a = _summarize_label_to_other(a, b, source_col=col_a, other_col=col_b, missing_display=missing_display)
    summary_b = _summarize_label_to_other(b, a, source_col=col_b, other_col=col_a, missing_display=missing_display)

    row_kind_a = a.map(lambda x: _label_kind(x, meta[col_a]))
    row_kind_b = b.map(lambda x: _label_kind(x, meta[col_b]))

    labels = []
    sources = []
    confidence = []
    frac_b_given_a_vals = []
    frac_a_given_b_vals = []
    for la, lb, ka, kb in zip(a, b, row_kind_a, row_kind_b):
        fbg = _conditional_fraction(ct_a_to_b, la, lb)
        fag = _conditional_fraction(ct_b_to_a, lb, la)
        label, source, conf = _resolve_dual_annotation(
            label_a=la,
            label_b=lb,
            kind_a=ka,
            kind_b=kb,
            frac_b_given_a=fbg,
            frac_a_given_b=fag,
            ambiguous_label=ambiguous_label,
            broad_specific_support_threshold=broad_specific_support_threshold,
            untyped_specific_support_threshold=untyped_specific_support_threshold,
        )
        labels.append(_display_label(label, missing_display=missing_display))
        sources.append(source)
        confidence.append(conf)
        frac_b_given_a_vals.append(fbg)
        frac_a_given_b_vals.append(fag)

    out[f"{output_prefix}_label"] = pd.Categorical(labels)
    out[f"{output_prefix}_source"] = pd.Categorical(sources)
    out[f"{output_prefix}_confidence"] = pd.Categorical(confidence, categories=["high", "medium", "low"])
    out[f"{output_prefix}_{col_a}_kind"] = pd.Categorical(row_kind_a)
    out[f"{output_prefix}_{col_b}_kind"] = pd.Categorical(row_kind_b)
    out[f"{output_prefix}_{col_b}_given_{col_a}"] = np.asarray(frac_b_given_a_vals, dtype=float)
    out[f"{output_prefix}_{col_a}_given_{col_b}"] = np.asarray(frac_a_given_b_vals, dtype=float)

    diagnostics = {
        "params": {
            "he_annotation": col_a,
            "if_annotation": col_b,
            "ambiguous_label": ambiguous_label,
            "broad_specific_support_threshold": broad_specific_support_threshold,
            "untyped_specific_support_threshold": untyped_specific_support_threshold,
            "label_metadata": label_metadata,
        },
        "unknown_labels": {
            col_a: sorted(pd.Index(a[row_kind_a.eq("untyped")]).unique().tolist()),
            col_b: sorted(pd.Index(b[row_kind_b.eq("untyped")]).unique().tolist()),
        },
        "summary_a_to_b": summary_a,
        "summary_b_to_a": summary_b,
        "counts_a_to_b": ct_a_to_b.rename(
            index=lambda x: _display_label(x, missing_display=missing_display),
            columns=lambda x: _display_label(x, missing_display=missing_display),
        ),
        "counts_b_to_a": ct_b_to_a.rename(
            index=lambda x: _display_label(x, missing_display=missing_display),
            columns=lambda x: _display_label(x, missing_display=missing_display),
        ),
        "fractions_a_to_b": frac_a_to_b.rename(
            index=lambda x: _display_label(x, missing_display=missing_display),
            columns=lambda x: _display_label(x, missing_display=missing_display),
        ),
        "fractions_b_to_a": frac_b_to_a.rename(
            index=lambda x: _display_label(x, missing_display=missing_display),
            columns=lambda x: _display_label(x, missing_display=missing_display),
        ),
        "label_frequency": out[f"{output_prefix}_label"].value_counts(dropna=False).rename_axis("label").reset_index(name="n"),
        "source_frequency": out[f"{output_prefix}_source"].value_counts(dropna=False).rename_axis("source").reset_index(name="n"),
        "row_details": out[
            [
                f"{output_prefix}_label",
                f"{output_prefix}_source",
                f"{output_prefix}_confidence",
                f"{output_prefix}_{col_a}_kind",
                f"{output_prefix}_{col_b}_kind",
                f"{output_prefix}_{col_b}_given_{col_a}",
                f"{output_prefix}_{col_a}_given_{col_b}",
            ]
        ].copy(),
    }
    return out, diagnostics


def reconcile_annotation_sources(
    sda,
    table: Optional[str],
    he_annotation: Optional[str] = None,
    if_annotation: Optional[str] = None,
    *,
    col_a: Optional[str] = None,
    col_b: Optional[str] = None,
    label_metadata: dict,
    ambiguous_label: str = "0",
    broad_specific_support_threshold: float = 0.6,
    untyped_specific_support_threshold: float = 0.75,
    output_prefix: str = "reconcile",
    output_col: str = "label",
    write_back: Optional[bool] = None,
):
    """
    Reconcile two annotation columns on a DataFrame, AnnData object, SpatialData-like object, or SpatialData Zarr path.

    Similar I/O behavior to `merge_categorical_annotations`: when `sda` is a path, only
    `tables/<table>` is read and written.
    """
    he_annotation = he_annotation or col_a
    if_annotation = if_annotation or col_b
    if he_annotation is None or if_annotation is None:
        raise ValueError("Both 'he_annotation' and 'if_annotation' are required.")
    col_a = he_annotation
    col_b = if_annotation
    table_store = None
    adata = None
    if isinstance(sda, pd.DataFrame):
        obs = sda
        if write_back is None:
            write_back = False
    else:
        if table is None:
            raise ValueError("table is required when sda is not a pandas DataFrame.")
        if hasattr(sda, "obs") and not hasattr(sda, "tables"):
            adata = sda
            obs = adata.obs
            if write_back is None:
                write_back = False
        else:
            from .umap import _load_adata, _write_adata_table_store

            adata, table_store = _load_adata(sda, table)
            obs = adata.obs
            if write_back is None:
                write_back = isinstance(sda, (str, Path))

    out_obs, diagnostics = reconcile_annotation_sources_df(
        obs,
        he_annotation=col_a,
        if_annotation=col_b,
        label_metadata=label_metadata,
        ambiguous_label=ambiguous_label,
        broad_specific_support_threshold=broad_specific_support_threshold,
        untyped_specific_support_threshold=untyped_specific_support_threshold,
        output_prefix=output_prefix,
    )

    if adata is not None:
        adata.obs[output_col] = out_obs[f"{output_prefix}_label"].copy()
        adata.uns[f"{output_prefix}_annotation_reconcile"] = _sanitize_uns_payload(diagnostics)
        if write_back:
            if table_store is None:
                raise ValueError("write_back=True requires a SpatialData Zarr path input.")
            from .umap import _write_adata_table_store

            _write_adata_table_store(adata, table_store)
        return adata.obs, diagnostics

    return out_obs, diagnostics


def merge_categorical_annotations(
    sda,
    table: Optional[str],
    primary_col: str,
    secondary_col: str,
    *,
    protected_primary_labels: Optional[Iterable] = None,
    broad_primary_labels: Optional[Iterable] = None,
    missing_labels: Optional[Iterable] = None,
    purity_threshold: float = 0.8,
    ambiguous_label: str = "0",
    use_ambiguous_when_discordant: bool = False,
    preserve_specific_primary: bool = False,
    preserve_coherent_primary_minority: bool = True,
    primary_minority_purity_threshold: float = 0.6,
    primary_minority_min_n: int = 5,
    force_ambiguous_col: Optional[str] = None,
    force_ambiguous_labels: Optional[Iterable] = None,
    output_prefix: str = "consensus",
    output_col: str = "label",
    write_back: Optional[bool] = None,
):
    """
    Merge annotations on a dataframe, AnnData object, SpatialData-like object, or SpatialData Zarr path.

    When `sda` is a path to a SpatialData Zarr, only `tables/<table>` is read and written.
    """
    table_store = None
    adata = None
    if isinstance(sda, pd.DataFrame):
        obs = sda
        if write_back is None:
            write_back = False
    else:
        if table is None:
            raise ValueError("table is required when sda is not a pandas DataFrame.")
        if hasattr(sda, "obs") and not hasattr(sda, "tables"):
            adata = sda
            obs = adata.obs
            if write_back is None:
                write_back = False
        else:
            from .umap import _load_adata, _write_adata_table_store

            adata, table_store = _load_adata(sda, table)
            obs = adata.obs
            if write_back is None:
                write_back = isinstance(sda, (str, Path))

    result = merge_categorical_annotations_df(
        obs,
        primary_col=primary_col,
        secondary_col=secondary_col,
        protected_primary_labels=protected_primary_labels,
        broad_primary_labels=broad_primary_labels,
        missing_labels=missing_labels,
        purity_threshold=purity_threshold,
        ambiguous_label=ambiguous_label,
        use_ambiguous_when_discordant=use_ambiguous_when_discordant,
        preserve_specific_primary=preserve_specific_primary,
        preserve_coherent_primary_minority=preserve_coherent_primary_minority,
        primary_minority_purity_threshold=primary_minority_purity_threshold,
        primary_minority_min_n=primary_minority_min_n,
        force_ambiguous_col=force_ambiguous_col,
        force_ambiguous_labels=force_ambiguous_labels,
        output_prefix=output_prefix,
    )
    out_obs, summary, counts, fractions, label_freq, source_freq = result

    if adata is not None:
        adata.obs[output_col] = out_obs[f"{output_prefix}_label"].copy()
        adata.uns[f"{output_prefix}_annotation_merge"] = _sanitize_uns_payload(
            _consensus_uns_payload(
                out_obs,
                summary,
                counts,
                fractions,
                label_freq,
                source_freq,
                output_prefix=output_prefix,
                output_col=output_col,
                primary_col=primary_col,
                secondary_col=secondary_col,
                purity_threshold=purity_threshold,
                primary_minority_purity_threshold=primary_minority_purity_threshold,
                primary_minority_min_n=primary_minority_min_n,
                ambiguous_label=ambiguous_label,
                use_ambiguous_when_discordant=use_ambiguous_when_discordant,
                preserve_specific_primary=preserve_specific_primary,
                preserve_coherent_primary_minority=preserve_coherent_primary_minority,
                force_ambiguous_col=force_ambiguous_col,
                force_ambiguous_labels=force_ambiguous_labels,
                protected_primary_labels=protected_primary_labels,
                broad_primary_labels=broad_primary_labels,
                missing_labels=missing_labels,
            )
        )
        if write_back:
            if table_store is None:
                raise ValueError("write_back=True requires a SpatialData Zarr path input.")
            if "_write_adata_table_store" not in locals():
                from .umap import _write_adata_table_store
            _write_adata_table_store(adata, table_store)
        return adata.obs, summary, counts, fractions, label_freq, source_freq

    return out_obs, summary, counts, fractions, label_freq, source_freq


def main():
    import argparse

    parser = argparse.ArgumentParser(description="Merge two categorical obs annotations into a consensus label")
    parser.add_argument("input", help="Path to SpatialData .zarr directory")
    parser.add_argument("--table", required=True, help="Table name in sda.tables")
    parser.add_argument("--primary-col", required=True, help="Primary obs annotation column")
    parser.add_argument("--secondary-col", required=True, help="Secondary obs annotation column")
    parser.add_argument("--protected-primary-labels", nargs="*", default=None)
    parser.add_argument("--broad-primary-labels", nargs="*", default=None)
    parser.add_argument("--missing-labels", nargs="*", default=None)
    parser.add_argument("--purity-threshold", type=float, default=0.8)
    parser.add_argument(
        "--primary-minority-purity-threshold",
        type=float,
        default=0.6,
        help="Minimum primary->secondary concentration needed to preserve coherent rare primary labels",
    )
    parser.add_argument(
        "--primary-minority-min-n",
        type=int,
        default=5,
        help="Minimum primary-label size needed for coherent-minority preservation",
    )
    parser.add_argument("--ambiguous-label", default="0")
    parser.add_argument("--force-ambiguous-col", default=None, help="Optional obs column whose selected labels force ambiguity")
    parser.add_argument("--force-ambiguous-labels", nargs="*", default=None, help="Values in --force-ambiguous-col that force ambiguity; default: -1")
    parser.add_argument("--use-ambiguous-when-discordant", action="store_true")
    parser.add_argument(
        "--disable-coherent-primary-minority",
        dest="preserve_coherent_primary_minority",
        action="store_false",
        help="Disable overlap-based preservation of coherent minority primary labels",
    )
    parser.add_argument(
        "--allow-ambiguous-specific-primary",
        dest="preserve_specific_primary",
        action="store_false",
        help="Deprecated broad behavior toggle; specific labels are not protected by default unless coherent-minority evidence supports them",
    )
    parser.add_argument("--output-prefix", default="consensus")
    parser.add_argument("--output-col", default="label", help="obs column name for the final consensus label")
    parser.add_argument("--no-write-back", dest="write_back", action="store_false")
    parser.set_defaults(write_back=True, preserve_specific_primary=False, preserve_coherent_primary_minority=True)
    args = parser.parse_args()

    _, summary, counts, fractions, label_freq, source_freq = merge_categorical_annotations(
        args.input,
        table=args.table,
        primary_col=args.primary_col,
        secondary_col=args.secondary_col,
        protected_primary_labels=args.protected_primary_labels,
        broad_primary_labels=args.broad_primary_labels,
        missing_labels=args.missing_labels,
        purity_threshold=args.purity_threshold,
        primary_minority_purity_threshold=args.primary_minority_purity_threshold,
        primary_minority_min_n=args.primary_minority_min_n,
        ambiguous_label=args.ambiguous_label,
        force_ambiguous_col=args.force_ambiguous_col,
        force_ambiguous_labels=args.force_ambiguous_labels,
        use_ambiguous_when_discordant=args.use_ambiguous_when_discordant,
        preserve_specific_primary=args.preserve_specific_primary,
        preserve_coherent_primary_minority=args.preserve_coherent_primary_minority,
        output_prefix=args.output_prefix,
        output_col=args.output_col,
        write_back=args.write_back,
    )
    out_dir = Path(args.input).expanduser().resolve().parent / "annotation_consensus" / args.table
    out_dir.mkdir(parents=True, exist_ok=True)
    summary.to_csv(out_dir / f"{args.output_prefix}_secondary_summary.csv", index=False)
    counts.to_csv(out_dir / f"{args.output_prefix}_overlap_counts.csv")
    fractions.to_csv(out_dir / f"{args.output_prefix}_overlap_fractions.csv")
    label_freq.to_csv(out_dir / f"{args.output_prefix}_label_frequency.csv", index=False)
    source_freq.to_csv(out_dir / f"{args.output_prefix}_source_frequency.csv", index=False)
    print(
        f"[histomap.merge_categorical_annotations] Wrote obs['{args.output_col}'], "
        f"uns['{args.output_prefix}_annotation_merge'], and summary CSVs to {out_dir}"
    )


if __name__ == "__main__":
    main()
