"""
PCA embedding utility for SpatialData/WSIData tables, with optional GPU acceleration.

Writes a reduced representation to `adata.obsm[target_key]`, intended for downstream
clustering on large tables where raw-feature GPU graph construction is too expensive.
"""
from __future__ import annotations

from pathlib import Path
from typing import Optional
import inspect

import numpy as np
from tqdm import tqdm

try:
    import scipy.sparse as sp
except Exception:
    sp = None  # type: ignore

try:
    from sklearn.decomposition import IncrementalPCA
except Exception:
    IncrementalPCA = None  # type: ignore

try:
    import cupy as _cp
except Exception:
    _cp = None  # type: ignore

try:
    from cuml.decomposition import PCA as CuMLPCA
except Exception:
    CuMLPCA = None  # type: ignore

from .umap import _gpu_available, _load_adata, _write_adata_table_store


def _to_float32_dense_rows(X, rows=None):
    X_sel = X if rows is None else X[rows]
    if sp is not None and sp.issparse(X_sel):
        return X_sel.toarray().astype(np.float32, copy=False)
    return np.asarray(X_sel, dtype=np.float32)


def _iter_row_slices(n_rows: int, batch_size: int):
    for start in range(0, n_rows, batch_size):
        stop = min(n_rows, start + batch_size)
        yield slice(start, stop)


def _fit_sample_indices(n: int, sample_n: Optional[int], *, random_state: int):
    if sample_n is None or int(sample_n) >= n:
        return None
    k = max(2, min(int(sample_n), n))
    rng = np.random.default_rng(random_state)
    return np.sort(rng.choice(n, size=k, replace=False))


def _cuml_pca_kwargs(*, n_components: int, random_state: int):
    kwargs = {"n_components": n_components}
    try:
        sig = inspect.signature(CuMLPCA)
    except Exception:
        sig = None
    if sig is not None:
        if "random_state" in sig.parameters:
            kwargs["random_state"] = random_state
        if "output_type" in sig.parameters:
            kwargs["output_type"] = "numpy"
    return kwargs


def pca(
    sda,
    table: str,
    *,
    layer: Optional[str] = None,
    n_components: int = 50,
    sample_n: Optional[int] = 100_000,
    random_state: int = 0,
    target_key: str = "X_pca",
    prefer_gpu: str = "auto",
    batch_size: int = 4096,
    show_progress: bool = True,
    write_back: Optional[bool] = None,
    log: bool = False,
):
    """
    Compute a PCA embedding for the selected table and save it to `adata.obsm[target_key]`.

    By default, PCA is fit on up to `sample_n` rows for large tables, then the full table is
    transformed in batches. This keeps memory use predictable for very large datasets.
    """
    source = sda
    if write_back is None:
        write_back = isinstance(source, (str, Path))

    progress = tqdm(
        total=6 if write_back else 5,
        desc=f"PCA:{table}",
        disable=not show_progress,
        unit="step",
        dynamic_ncols=True,
        leave=False,
    )

    def advance(message: str) -> None:
        if show_progress:
            progress.set_postfix_str(message)
        progress.update(1)

    try:
        adata, table_store = _load_adata(source, table)
    except Exception:
        progress.close()
        raise

    if n_components <= 0:
        progress.close()
        raise ValueError("n_components must be >= 1")
    if batch_size <= 0:
        progress.close()
        raise ValueError("batch_size must be >= 1")

    if layer is None:
        X = adata.X
    else:
        if layer not in adata.layers:
            progress.close()
            raise KeyError(f"Layer '{layer}' not found in adata.layers.")
        X = adata.layers[layer]
    advance("loaded matrix")

    if log:
        if sp is not None and sp.issparse(X):
            X = X.copy()
            X.data = np.log1p(X.data)
        else:
            X = np.log1p(np.asarray(X))
        advance("applied log1p")

    n = X.shape[0]
    sample_inds = _fit_sample_indices(n, sample_n, random_state=random_state)
    fit_n = n if sample_inds is None else len(sample_inds)
    advance(f"prepared fit sample n={fit_n}")

    use_gpu = prefer_gpu == "gpu" or (prefer_gpu == "auto" and _gpu_available() and CuMLPCA is not None and _cp is not None)
    if prefer_gpu == "gpu" and not (CuMLPCA is not None and _cp is not None and _gpu_available()):
        progress.close()
        raise RuntimeError("GPU PCA requested, but cuML/CuPy are not available.")
    backend_name = "gpu" if use_gpu else "cpu"
    advance(f"backend={backend_name}")

    if use_gpu:
        X_fit = _to_float32_dense_rows(X, sample_inds)
        X_fit_gpu = _cp.asarray(X_fit)
        model = CuMLPCA(**_cuml_pca_kwargs(n_components=n_components, random_state=random_state))
        model.fit(X_fit_gpu)
        del X_fit_gpu
        try:
            _cp.get_default_memory_pool().free_all_blocks()
        except Exception:
            pass
        emb = np.empty((n, n_components), dtype=np.float32)
        for row_slice in _iter_row_slices(n, min(int(batch_size), n)):
            X_batch = _to_float32_dense_rows(X, row_slice)
            X_batch_gpu = _cp.asarray(X_batch)
            emb[row_slice] = np.asarray(model.transform(X_batch_gpu), dtype=np.float32)
            del X_batch_gpu
            try:
                _cp.get_default_memory_pool().free_all_blocks()
            except Exception:
                pass
    else:
        if IncrementalPCA is None:
            progress.close()
            raise ImportError("scikit-learn is required for CPU PCA.")
        model = IncrementalPCA(n_components=n_components, batch_size=min(int(batch_size), fit_n))
        if sample_inds is None:
            for row_slice in _iter_row_slices(n, min(int(batch_size), n)):
                model.partial_fit(_to_float32_dense_rows(X, row_slice))
        else:
            X_fit = _to_float32_dense_rows(X, sample_inds)
            for row_slice in _iter_row_slices(X_fit.shape[0], min(int(batch_size), X_fit.shape[0])):
                model.partial_fit(X_fit[row_slice])
        emb = np.empty((n, n_components), dtype=np.float32)
        for row_slice in _iter_row_slices(n, min(int(batch_size), n)):
            emb[row_slice] = model.transform(_to_float32_dense_rows(X, row_slice)).astype(np.float32, copy=False)
    advance("embedding computed")

    adata.obsm[target_key] = emb
    advance(f"saved obsm['{target_key}']")

    if write_back:
        if table_store is None:
            progress.close()
            raise ValueError("write_back=True requires a SpatialData path input.")
        _write_adata_table_store(adata, table_store)
        advance(f"wrote {table_store.as_posix()}")
    progress.close()

    if show_progress:
        print(
            f"[histomap.pca] Done table='{table}' backend={backend_name} "
            f"target_key='{target_key}' shape={adata.obsm[target_key].shape}"
        )
    return source


def main():
    import argparse

    parser = argparse.ArgumentParser(
        description="Compute PCA for a SpatialData table and write the reduced representation to obsm"
    )
    parser.add_argument("input", help="Path to SpatialData .zarr directory")
    parser.add_argument("--table", required=True, help="Table name in sda.tables to use")
    parser.add_argument("--layer", default=None, help="AnnData layer name to use (default: X)")
    parser.add_argument("--n-components", type=int, default=50, help="Number of PCA components to compute")
    parser.add_argument("--sample-n", type=int, default=100000, help="Rows to use for PCA fitting on large tables")
    parser.add_argument("--target-key", default="X_pca", help="obsm key to store the PCA embedding")
    parser.add_argument("--prefer-gpu", choices=["auto", "cpu", "gpu"], default="auto")
    parser.add_argument("--batch-size", type=int, default=4096, help="Row batch size for fitting/transform")
    parser.add_argument("--random-state", type=int, default=0)
    parser.add_argument("--quiet", action="store_true", help="Disable progress output")
    parser.add_argument("--log", action="store_true", help="Apply log1p to the selected matrix before PCA")
    parser.add_argument("--no-write-back", dest="write_back", action="store_false", help="Compute PCA without writing back")
    parser.set_defaults(write_back=True)

    args = parser.parse_args()

    result = pca(
        args.input,
        table=args.table,
        layer=args.layer,
        n_components=args.n_components,
        sample_n=args.sample_n,
        random_state=args.random_state,
        target_key=args.target_key,
        prefer_gpu=args.prefer_gpu,
        batch_size=args.batch_size,
        show_progress=not args.quiet,
        write_back=args.write_back,
        log=args.log,
    )
    print(result)


if __name__ == "__main__":
    main()
