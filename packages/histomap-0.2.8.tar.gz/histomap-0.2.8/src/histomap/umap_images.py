"""
Headless UMAP image export utilities.
"""
from __future__ import annotations

from pathlib import Path
from typing import Iterable, Optional, Sequence
import colorsys
import re

import matplotlib
import numpy as np
import pandas as pd
from tqdm import tqdm

matplotlib.use("Agg")

from matplotlib import pyplot as plt
from matplotlib.lines import Line2D

try:
    import scipy.sparse as sp
except Exception:
    sp = None  # type: ignore

from .umap import _load_adata


def _sanitize_filename(value: str) -> str:
    value = re.sub(r"[^\w.\-]+", "_", str(value)).strip("_")
    return value or "plot"


def _default_output_dir(source, table: str, output_path: Optional[str | Path]) -> Path:
    if output_path is not None:
        return Path(output_path)
    if isinstance(source, (str, Path)):
        return Path(source).expanduser().resolve().parent / "umap" / table
    return Path.cwd() / "umap" / table


def _sample_indices(n: int, sample_n: Optional[int], sample_frac: Optional[float], random_state: int):
    if sample_n is None and sample_frac is None:
        return np.arange(n)
    if sample_n is not None:
        k = max(1, min(int(sample_n), n))
    else:
        frac = float(sample_frac)
        if not (0 < frac <= 1):
            raise ValueError("sample_frac must be in (0, 1].")
        k = max(1, min(n, int(round(n * frac))))
    rng = np.random.default_rng(random_state)
    return np.sort(rng.choice(n, size=k, replace=False))


def _is_categorical(series: pd.Series) -> bool:
    if pd.api.types.is_categorical_dtype(series) or series.dtype == object:
        return True
    if pd.api.types.is_bool_dtype(series):
        return True
    return series.nunique(dropna=True) <= max(32, int(len(series) * 0.02))


def _hex_to_rgb01(hex_str: str):
    hex_str = hex_str.lstrip("#")
    return tuple(int(hex_str[i:i + 2], 16) / 255.0 for i in (0, 2, 4))


def _palette(n: int):
    if n <= 8:
        hexes = ["#E69F00", "#56B4E9", "#009E73", "#D6C83A", "#0072B2", "#D55E00", "#CC79A7", "#999999"]
        return [_hex_to_rgb01(hx) for hx in hexes[:n]]
    if n <= 20:
        cmap = matplotlib.colormaps.get("tab20")
        order = list(range(0, 20, 2)) + list(range(1, 20, 2))
        return [tuple(cmap(i)[:3]) for i in order[:n]]
    hs = np.linspace(0.0, 1.0, n, endpoint=False)
    return [colorsys.hsv_to_rgb(float(h), 0.88, 0.88) for h in hs]


def _plot_numeric(emb, values, *, title: str, output_file: Path, point_size: float, alpha: float, cmap_name: str):
    vals = pd.to_numeric(pd.Series(values), errors="coerce").to_numpy(dtype=float)
    valid = np.isfinite(vals)
    fig, ax = plt.subplots(figsize=(7.5, 6), dpi=180)
    if (~valid).any():
        ax.scatter(emb[~valid, 0], emb[~valid, 1], s=point_size, c="#D0D0D0", alpha=0.25, linewidths=0)
    if valid.any():
        vmin = np.nanpercentile(vals[valid], 2)
        vmax = np.nanpercentile(vals[valid], 98)
        if not np.isfinite(vmin) or not np.isfinite(vmax) or vmin == vmax:
            vmin, vmax = np.nanmin(vals[valid]), np.nanmax(vals[valid])
        sc = ax.scatter(
            emb[valid, 0],
            emb[valid, 1],
            s=point_size,
            c=vals[valid],
            cmap=cmap_name,
            vmin=vmin,
            vmax=vmax,
            alpha=alpha,
            linewidths=0,
        )
        cbar = fig.colorbar(sc, ax=ax, fraction=0.046, pad=0.04)
        cbar.set_label(title)
    ax.set_title(title)
    ax.set_xlabel("UMAP1")
    ax.set_ylabel("UMAP2")
    ax.set_xticks([])
    ax.set_yticks([])
    fig.tight_layout()
    fig.savefig(output_file, bbox_inches="tight")
    plt.close(fig)


def _plot_categorical(
    emb,
    values,
    *,
    title: str,
    output_file: Path,
    legend_file: Path,
    point_size: float,
    alpha: float,
    max_legend_entries: int,
):
    series = pd.Series(values).astype("object").where(~pd.isna(values), "__missing__")
    cat = pd.Categorical(series)
    categories = list(cat.categories)
    colors = _palette(len(categories))
    counts = pd.Series(cat).value_counts(dropna=False)
    color_map = {cat_name: colors[i] for i, cat_name in enumerate(categories)}

    legend_df = pd.DataFrame(
        {
            "category": ["NA" if c == "__missing__" else str(c) for c in categories],
            "count": [int(counts.get(c, 0)) for c in categories],
            "color_hex": [
                "#{:02X}{:02X}{:02X}".format(*(int(round(ch * 255)) for ch in color_map[c]))
                for c in categories
            ],
        }
    )
    legend_df.to_csv(legend_file, index=False)

    fig, ax = plt.subplots(figsize=(8.5, 6), dpi=180)
    for i, category in enumerate(categories):
        mask = cat.codes == i
        ax.scatter(
            emb[mask, 0],
            emb[mask, 1],
            s=point_size,
            c=[colors[i]],
            alpha=0.35 if category == "__missing__" else alpha,
            linewidths=0,
        )

    handles = []
    for i, category in enumerate(categories[:max_legend_entries]):
        label = "NA" if category == "__missing__" else str(category)
        handles.append(
            Line2D(
                [0],
                [0],
                marker="o",
                color="none",
                markerfacecolor=colors[i],
                markersize=5,
                label=f"{label} ({int(counts.get(category, 0))})",
            )
        )
    if len(categories) > max_legend_entries:
        handles.append(Line2D([0], [0], marker="", color="none", label=f"... {len(categories) - max_legend_entries} more"))
    if handles:
        ax.legend(
            handles=handles,
            title=f"{title}\nfull key: {legend_file.name}",
            loc="center left",
            bbox_to_anchor=(1.02, 0.5),
            fontsize=7,
            title_fontsize=8,
            frameon=True,
        )
    ax.set_title(title)
    ax.set_xlabel("UMAP1")
    ax.set_ylabel("UMAP2")
    ax.set_xticks([])
    ax.set_yticks([])
    fig.tight_layout()
    fig.savefig(output_file, bbox_inches="tight")
    plt.close(fig)


def _matrix_column(X, col_idx: int):
    col = X[:, col_idx]
    if sp is not None and sp.issparse(col):
        return np.asarray(col.toarray()).ravel()
    return np.asarray(col).ravel()


def save_umap_images(
    sda,
    table: str,
    obs_columns: Optional[Sequence[str]] = None,
    *,
    obsm_key: str = "X_umap",
    layer: Optional[str] = None,
    output_path: Optional[str | Path] = None,
    sample_n: Optional[int] = 200_000,
    sample_frac: Optional[float] = None,
    random_state: int = 0,
    point_size: float = 2.0,
    alpha: float = 0.75,
    cmap: str = "viridis",
    max_legend_entries: int = 24,
    show_progress: bool = True,
) -> list[Path]:
    """
    Save static UMAP images colored by obs columns and optionally layer expression.

    If `layer` is provided, one expression-colored UMAP is generated per `adata.var_names`
    from `adata.layers[layer]` and saved under `expression_<layer>/`.
    """
    adata, _ = _load_adata(sda, table)
    if obsm_key not in adata.obsm:
        raise KeyError(f"obsm['{obsm_key}'] not found in table '{table}'.")
    emb = np.asarray(adata.obsm[obsm_key])
    if emb.ndim != 2 or emb.shape[1] < 2:
        raise ValueError(f"obsm['{obsm_key}'] must be a 2D array with at least 2 columns.")

    sample_idx = _sample_indices(emb.shape[0], sample_n, sample_frac, random_state)
    emb2 = emb[sample_idx, :2]

    out_dir = _default_output_dir(sda, table, output_path)
    out_dir.mkdir(parents=True, exist_ok=True)
    saved: list[Path] = []

    obs_columns = list(obs_columns or [])
    missing_cols = [c for c in obs_columns if c not in adata.obs.columns]
    if missing_cols:
        raise KeyError(f"Missing obs columns in table '{table}': {missing_cols}")

    total = len(obs_columns)
    if layer is not None:
        if layer not in adata.layers:
            raise KeyError(f"Layer '{layer}' not found in table '{table}'.")
        total += adata.n_vars
    progress = tqdm(total=total, desc=f"UMAP images:{table}", disable=not show_progress, unit="plot", dynamic_ncols=True, leave=False)

    for col in obs_columns:
        values = adata.obs[col].iloc[sample_idx]
        output_file = out_dir / f"{_sanitize_filename(col)}.png"
        if _is_categorical(values):
            legend_file = out_dir / f"{_sanitize_filename(col)}_legend.csv"
            _plot_categorical(
                emb2,
                values,
                title=col,
                output_file=output_file,
                legend_file=legend_file,
                point_size=point_size,
                alpha=alpha,
                max_legend_entries=max_legend_entries,
            )
        else:
            _plot_numeric(
                emb2,
                values,
                title=col,
                output_file=output_file,
                point_size=point_size,
                alpha=alpha,
                cmap_name=cmap,
            )
        saved.append(output_file)
        progress.update(1)

    if layer is not None:
        expr_dir = out_dir / f"expression_{_sanitize_filename(layer)}"
        expr_dir.mkdir(parents=True, exist_ok=True)
        X = adata.layers[layer]
        for i, marker in enumerate(adata.var_names):
            values = _matrix_column(X[sample_idx, :], i)
            output_file = expr_dir / f"{_sanitize_filename(marker)}.png"
            _plot_numeric(
                emb2,
                values,
                title=str(marker),
                output_file=output_file,
                point_size=point_size,
                alpha=alpha,
                cmap_name=cmap,
            )
            saved.append(output_file)
            progress.update(1)

    progress.close()
    if show_progress:
        print(f"[histomap.save_umap_images] Done table='{table}' saved={len(saved)} output='{out_dir}'")
    return saved


def main():
    import argparse

    parser = argparse.ArgumentParser(description="Save static UMAP images colored by obs columns and/or layer expression")
    parser.add_argument("input", help="Path to SpatialData .zarr directory")
    parser.add_argument("--table", required=True, help="Table name in sda.tables to use")
    parser.add_argument("--obs-columns", nargs="*", default=[], help="obs columns to color by")
    parser.add_argument("--obsm-key", default="X_umap", help="obsm key containing the UMAP embedding")
    parser.add_argument("--layer", default=None, help="Optional layer to plot expression for every marker")
    parser.add_argument("--output-path", default=None, help="Optional output directory")
    parser.add_argument("--sample-n", type=int, default=200000, help="Number of points to sample for plotting")
    parser.add_argument("--sample-frac", type=float, default=None, help="Fraction of points to sample for plotting")
    parser.add_argument("--random-state", type=int, default=0)
    parser.add_argument("--point-size", type=float, default=2.0)
    parser.add_argument("--alpha", type=float, default=0.75)
    parser.add_argument("--cmap", default="viridis")
    parser.add_argument("--max-legend-entries", type=int, default=24)
    parser.add_argument("--quiet", action="store_true", help="Disable progress output")
    args = parser.parse_args()

    save_umap_images(
        args.input,
        table=args.table,
        obs_columns=args.obs_columns,
        obsm_key=args.obsm_key,
        layer=args.layer,
        output_path=args.output_path,
        sample_n=args.sample_n,
        sample_frac=args.sample_frac,
        random_state=args.random_state,
        point_size=args.point_size,
        alpha=args.alpha,
        cmap=args.cmap,
        max_legend_entries=args.max_legend_entries,
        show_progress=not args.quiet,
    )


if __name__ == "__main__":
    main()
