"""
UMAP embedding utility for SpatialData/WSIData tables, with optional GPU acceleration via RAPIDS cuML.

Usage:
    from histomap.umap import umap
    sda = umap(sda_or_wsi, table="my_table", layer=None, sample_n=5000, sample_frac=None)

This will compute a 2D UMAP embedding of the selected table's data (from AnnData.X or a named layer)
and save it into adata.obsm['X_umap'].

If GPU is available and RAPIDS (cuml + cupy) is installed, the function will use the GPU automatically.
Otherwise, it falls back to `umap-learn` on CPU.
"""
from __future__ import annotations

from pathlib import Path
from typing import Optional
import inspect
import shutil
import uuid

import numpy as np
import pandas as pd
from tqdm import tqdm

try:
    import zarr
except Exception:
    zarr = None  # type: ignore

try:
    # CPU backend
    import umap as umap_learn
except Exception as _e_umap:
    umap_learn = None  # type: ignore

try:
    import anndata as ad
except Exception:
    ad = None  # type: ignore

# Optional GPU backend
_cuml = None
_cupy = None
try:
    import cupy as _cp
    _cupy = _cp
    import cuml
    _cuml = cuml
except Exception:
    pass


def _gpu_available() -> bool:
    """Detect if GPU is available and RAPIDS (cuml + cupy) can be used."""
    try:
        if _cupy is None or _cuml is None:
            return False
        # Check device count via CUDA runtime
        try:
            return _cupy.cuda.runtime.getDeviceCount() > 0
        except Exception:
            return False
    except Exception:
        return False


def _umap_kwargs_with_optional_verbose(umap_cls, *, verbose: bool, **kwargs):
    """Pass `verbose` only when the backend constructor supports it."""
    try:
        sig = inspect.signature(umap_cls)
    except Exception:
        sig = None
    # Keep backend-specific verbose logs disabled so we only show the
    # outer histomap progress bar rather than interleaved nested output.
    if sig is not None and "verbose" in sig.parameters:
        kwargs["verbose"] = False
    return kwargs


def _resolve_sdata_table_store(source, table: str) -> Path:
    root = Path(source).expanduser().resolve()
    table_store = root / "tables" / table
    if not table_store.exists():
        raise FileNotFoundError(
            f"Table store not found at '{table_store}'. Expected a SpatialData Zarr with tables/{table}."
        )
    return table_store


def _load_adata(source, table: str):
    if isinstance(source, (str, Path)):
        if ad is None:
            raise ImportError("anndata is required to read a table directly from a SpatialData path.")
        table_store = _resolve_sdata_table_store(source, table)
        return ad.read_zarr(str(table_store)), table_store

    if not hasattr(source, "tables"):
        raise TypeError("Expected a SpatialData/WSIData-like object or a path to a SpatialData Zarr.")
    if table not in getattr(source, "tables"):
        raise KeyError(f"Table '{table}' not found in provided object.")
    return source.tables[table], None


def _write_adata_table_store(adata, table_store: Path) -> None:
    def _first_present(columns, candidates):
        for col in candidates:
            if col in columns:
                return col
        return None

    def _infer_table_attrs(adata_obj, store_path: Path):
        obs_cols = set(getattr(adata_obj, "obs", pd.DataFrame()).columns)
        table_name = store_path.name
        if "global_token_id" in obs_cols:
            return {"region": "tokens", "region_key": None, "instance_key": "global_token_id"}
        if "global_patch_id" in obs_cols:
            return {"region": "tiles", "region_key": None, "instance_key": "global_patch_id"}
        cell_key = _first_present(obs_cols, ["global_cell_id", "cell_id", "CellId", "instance_id"])
        if cell_key is not None:
            region = "segmentation_mask"
            if "_mIF_cells" in table_name:
                region = "segmentation_mask"
            return {"region": region, "region_key": None, "instance_key": cell_key}
        if "global_tissue_id" in obs_cols:
            return {"region": "tissue", "region_key": None, "instance_key": "global_tissue_id"}
        return {"region": None, "region_key": None, "instance_key": None}

    attrs = {}
    if zarr is not None and table_store.exists():
        try:
            attrs = dict(zarr.open_group(str(table_store), mode="r").attrs)
        except Exception:
            attrs = {}
    sd_attrs = adata.uns.get("spatialdata_attrs", {}) if hasattr(adata, "uns") else {}
    inferred = _infer_table_attrs(adata, table_store)
    attrs = {
        **attrs,
        "spatialdata-encoding-type": attrs.get("spatialdata-encoding-type", "ngff:regions_table"),
        "region": attrs.get("region") or sd_attrs.get("region") or inferred["region"],
        "region_key": attrs.get("region_key") or sd_attrs.get("region_key") or inferred["region_key"],
        "instance_key": attrs.get("instance_key") or sd_attrs.get("instance_key") or inferred["instance_key"],
        "version": attrs.get("version", "0.2"),
    }

    table_store = table_store.resolve()
    tmp_store = table_store.parent / f"{table_store.name}.histomap-tmp-{uuid.uuid4().hex}"
    if tmp_store.exists():
        shutil.rmtree(tmp_store)
    adata.write_zarr(str(tmp_store))
    if zarr is not None and attrs:
        tmp_group = zarr.open_group(str(tmp_store), mode="a")
        for key, value in attrs.items():
            tmp_group.attrs[key] = value
    if table_store.exists():
        shutil.rmtree(table_store)
    shutil.move(str(tmp_store), str(table_store))


def _to_float32_dense_rows(X, rows=None):
    try:
        import scipy.sparse as sp
    except Exception:
        sp = None  # type: ignore

    X_sel = X if rows is None else X[rows]
    if sp is not None and sp.issparse(X_sel):
        return X_sel.toarray().astype(np.float32, copy=False)
    return np.asarray(X_sel, dtype=np.float32)


def _iter_row_slices(n_rows: int, batch_size: int):
    for start in range(0, n_rows, batch_size):
        stop = min(n_rows, start + batch_size)
        yield slice(start, stop)


def _gpu_transform_batched(model, X, *, n_rows: int, n_components: int, batch_size: int):
    emb = np.empty((n_rows, n_components), dtype=np.float32)
    for row_slice in _iter_row_slices(n_rows, batch_size):
        X_batch = _to_float32_dense_rows(X, row_slice)
        X_batch_gpu = _cupy.asarray(X_batch)
        emb_batch = model.transform(X_batch_gpu)
        emb[row_slice] = _cupy.asnumpy(emb_batch)
        del X_batch_gpu, emb_batch
        try:
            _cupy.get_default_memory_pool().free_all_blocks()
        except Exception:
            pass
    return emb


def umap(
    sda,
    table: str,
    *,
    layer: Optional[str] = None,
    sample_n: Optional[int] = None,
    sample_frac: Optional[float] = None,
    embed_full: bool = True,
    n_neighbors: int = 15,
    min_dist: float = 0.1,
    n_components: int = 2,
    random_state: int = 0,
    target_key: str = "X_umap",
    prefer_gpu: str = "auto",  # "auto" | "cpu" | "gpu"
    show_progress: bool = True,
    write_back: Optional[bool] = None,
    log: bool = False,
    gpu_batch_size: int = 4096,
):
    """
    Compute a UMAP embedding for the selected table inside a SpatialData/WSIData-like object and
    save the result to `adata.obsm[target_key]`.

    Parameters
    - sda_or_wsi: An object with a `tables` dict mapping table names to AnnData.
    - table: Name of the table to use.
    - layer: AnnData layer name to use. If None, use `adata.X`.
    - sample_n: Optional number of rows to sample when fitting the UMAP model.
    - sample_frac: Optional fraction (0-1] of rows to sample when fitting the model.
    - n_neighbors, min_dist, n_components: UMAP hyperparameters.
    - random_state: RNG seed for reproducibility (sampling and UMAP init).
    - target_key: Key to write embedding into `adata.obsm[target_key]`.
    - prefer_gpu: "auto" (default) will use GPU if available; "gpu" forces GPU (errors if unavailable);
                  "cpu" forces CPU path.
    - show_progress: If True, print backend selection and show a coarse progress bar for the major stages.
    - write_back: When True, persist the updated table to disk. Defaults to True for path inputs and
      False for in-memory objects.
    - log: If True, apply log1p to the selected matrix before fitting/transforming UMAP.
    - gpu_batch_size: Row batch size used for GPU transform when fitting on a sample and embedding the
      full table. Smaller values reduce peak GPU memory usage.

    Returns
    - The updated SpatialData/WSIData-like object, or the input path if a path was provided.
    """
    source = sda

    if write_back is None:
        write_back = isinstance(source, (str, Path))

    progress = tqdm(
        total=6 if write_back else 5,
        desc=f"UMAP:{table}",
        disable=not show_progress,
        unit="step",
        dynamic_ncols=True,
        leave=False,
    )

    def advance(message: str) -> None:
        if show_progress:
            progress.set_postfix_str(message)
        progress.update(1)

    # Resolve AnnData from provided object
    try:
        adata, table_store = _load_adata(source, table)
    except Exception:
        progress.close()
        raise

    # Choose matrix source
    if layer is None:
        X = adata.X
    else:
        if not hasattr(adata, "layers") or layer not in adata.layers:
            progress.close()
            raise KeyError(f"Layer '{layer}' not found in adata.layers.")
        X = adata.layers[layer]
    advance("loaded matrix")

    if log:
        try:
            import scipy.sparse as sp
        except Exception:
            sp = None  # type: ignore
        if sp is not None and sp.issparse(X):
            X = X.copy()
            X.data = np.log1p(X.data)
        else:
            X = np.log1p(np.asarray(X))
        advance("applied log1p")

    n = X.shape[0]
    if n_components <= 0:
        progress.close()
        raise ValueError("n_components must be >= 1")
    if gpu_batch_size <= 0:
        progress.close()
        raise ValueError("gpu_batch_size must be >= 1")

    # Create sample indices if requested
    rng = np.random.default_rng(random_state)
    sample_inds = None
    if sample_n is not None or sample_frac is not None:
        if sample_n is not None:
            k = int(sample_n)
            k = max(2, min(k, n))
        else:
            frac = float(sample_frac)
            if not (0 < frac <= 1):
                progress.close()
                raise ValueError("sample_frac must be in (0, 1]")
            k = max(2, min(n, int(np.round(n * frac))))
        sample_inds = np.sort(rng.choice(n, size=k, replace=False))
    advance(f"prepared sample n={len(sample_inds) if sample_inds is not None else n}")

    # Select backend
    use_gpu = False
    if prefer_gpu == "gpu":
        use_gpu = True
    elif prefer_gpu == "cpu":
        use_gpu = False
    else:  # auto
        use_gpu = _gpu_available()
    backend_name = "gpu" if use_gpu else "cpu"
    advance(f"backend={backend_name}")

    # Build model & fit
    if use_gpu:
        if _cuml is None or _cupy is None:
            progress.close()
            raise RuntimeError("GPU backend requested, but RAPIDS (cuml + cupy) is not available.")
        model = _cuml.UMAP(
            **_umap_kwargs_with_optional_verbose(
                _cuml.UMAP,
                verbose=show_progress,
                n_neighbors=n_neighbors,
                min_dist=min_dist,
                n_components=n_components,
                random_state=random_state,
            )
        )
        if sample_inds is not None:
            Xs_gpu = _cupy.asarray(_to_float32_dense_rows(X, sample_inds))
            advance("copied sample to gpu")
            model.fit(Xs_gpu)
            if embed_full:
                try:
                    emb = _gpu_transform_batched(
                        model,
                        X,
                        n_rows=n,
                        n_components=n_components,
                        batch_size=min(int(gpu_batch_size), n),
                    )
                except Exception:
                    # Fallback: fit on full data if transform fails
                    X_gpu = _cupy.asarray(_to_float32_dense_rows(X))
                    advance("copied full data to gpu")
                    emb_gpu = model.fit_transform(X_gpu)
                    emb = _cupy.asnumpy(emb_gpu)
            else:
                try:
                    emb_s_gpu = model.transform(Xs_gpu)
                except Exception:
                    emb_s_gpu = model.fit_transform(Xs_gpu)
                emb = np.full((n, n_components), np.nan, dtype=np.float32)
                emb[sample_inds] = _cupy.asnumpy(emb_s_gpu)
        else:
            X_gpu = _cupy.asarray(_to_float32_dense_rows(X))
            advance("copied full data to gpu")
            emb_gpu = model.fit_transform(X_gpu)
            emb = _cupy.asnumpy(emb_gpu)

    else:
        if umap_learn is None:
            progress.close()
            raise ImportError(
                "umap-learn is required for CPU UMAP. Please install it, e.g., 'pip install umap-learn'."
            )
        model = umap_learn.UMAP(
            **_umap_kwargs_with_optional_verbose(
                umap_learn.UMAP,
                verbose=show_progress,
                n_neighbors=n_neighbors,
                min_dist=min_dist,
                n_components=n_components,
                random_state=random_state,
                metric="euclidean",
            )
        )
        advance("prepared cpu model")
        if sample_inds is not None:
            # Fit on sample, then transform full or embed only sample
            Xs = X[sample_inds]
            model.fit(Xs)
            if embed_full:
                try:
                    emb = model.transform(X)
                except Exception:
                    # Fallback: fit on full data if transform is not available
                    emb = model.fit_transform(X)
            else:
                try:
                    emb_sample = model.transform(Xs)
                except Exception:
                    emb_sample = model.fit_transform(Xs)
                emb = np.full((n, n_components), np.nan, dtype=np.float32)
                emb[sample_inds] = np.asarray(emb_sample, dtype=np.float32)
        else:
            emb = model.fit_transform(X)
    advance("embedding computed")

    # Save into obsm
    adata.obsm[target_key] = np.asarray(emb)
    advance(f"saved obsm['{target_key}']")
    if write_back:
        if table_store is None:
            progress.close()
            raise ValueError(
                "write_back=True requires a SpatialData path input so histomap can update tables/<table> on disk."
            )
        _write_adata_table_store(adata, table_store)
        advance(f"wrote {table_store.as_posix()}")
    progress.close()
    if show_progress:
        print(
            f"[histomap.umap] Done table='{table}' backend={backend_name} target_key='{target_key}' "
            f"shape={adata.obsm[target_key].shape}"
        )

    return source


def main():
    import argparse
    import spatialdata as sd

    parser = argparse.ArgumentParser(
        description="Compute UMAP embedding for a SpatialData table and write back to the dataset"
    )
    parser.add_argument("input", help="Path to SpatialData .zarr directory")
    parser.add_argument("--table", required=True, help="Table name in sda.tables to use")
    parser.add_argument("--layer", default=None, help="AnnData layer name to use (default: X)")
    parser.add_argument("--sample-n", type=int, default=None, help="Number of rows to sample for fitting")
    parser.add_argument("--sample-frac", type=float, default=None, help="Fraction of rows to sample for fitting (0-1]")
    parser.add_argument("--embed-full", action="store_true", help="Transform all rows after fitting on sample (default)")
    parser.add_argument("--no-embed-full", dest="embed_full", action="store_false", help="Only embed sampled rows and fill others with NaN")
    parser.set_defaults(embed_full=True)
    parser.add_argument("--n-neighbors", type=int, default=15)
    parser.add_argument("--min-dist", type=float, default=0.1)
    parser.add_argument("--n-components", type=int, default=2)
    parser.add_argument("--random-state", type=int, default=0)
    parser.add_argument("--target-key", default="X_umap")
    parser.add_argument("--prefer-gpu", choices=["auto", "cpu", "gpu"], default="auto")
    parser.add_argument("--gpu-batch-size", type=int, default=4096, help="Row batch size for GPU transform after sample fitting")
    parser.add_argument("--quiet", action="store_true", help="Disable progress output")
    parser.add_argument("--log", action="store_true", help="Apply log1p to the selected matrix before UMAP")
    parser.add_argument(
        "--no-write-back",
        dest="write_back",
        action="store_false",
        help="Compute the embedding without writing the updated table back to disk",
    )
    parser.set_defaults(write_back=True)

    args = parser.parse_args()

    result = umap(
        args.input,
        table=args.table,
        layer=args.layer,
        sample_n=args.sample_n,
        sample_frac=args.sample_frac,
        embed_full=args.embed_full,
        n_neighbors=args.n_neighbors,
        min_dist=args.min_dist,
        n_components=args.n_components,
        random_state=args.random_state,
        target_key=args.target_key,
        prefer_gpu=args.prefer_gpu,
        gpu_batch_size=args.gpu_batch_size,
        show_progress=not args.quiet,
        write_back=args.write_back,
        log=args.log,
    )

    # Determine backend used for message
    if args.prefer_gpu == "gpu":
        backend = "gpu"
    elif args.prefer_gpu == "cpu":
        backend = "cpu"
    else:
        backend = "gpu" if _gpu_available() else "cpu"

    if isinstance(result, (str, Path)):
        if ad is None:
            raise ImportError("anndata is required to read the written table back for reporting.")
        adata = ad.read_zarr(str(_resolve_sdata_table_store(result, args.table)))
    else:
        adata = result.tables[args.table]
    E = adata.obsm[args.target_key]
    print(
        f"{'Wrote' if args.write_back else 'Computed'} embedding for {args.input} in table '{args.table}' obsm['{args.target_key}'] "
        f"using backend={backend}. Shape={E.shape}"
    )


if __name__ == "__main__":
    main()
