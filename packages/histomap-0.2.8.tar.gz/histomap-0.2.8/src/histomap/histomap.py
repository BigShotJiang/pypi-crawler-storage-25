"""
Napari dock widget for overlaying SpatialData tile polygons on H&E and for UMAP‑lasso selection.

Requirements (install as needed):
    pip install napari PyQt5 magicgui geopandas shapely anndata matplotlib spatialdata
Optional (for robust SVS loading):
    pip install openslide-python napari-openslide

Usage:
    from napari_spatialdata_overlay import histomap
    viewer = histomap(
        spatialdata_obj,
        # If shapes are in microns but image is in pixels, scale by 1/MPP
        # (Do NOT pass this if your tiles are already in base pixels.)
        # global_to_pixel_scale=(1/0.263049, 1/0.263049),
        # global_to_pixel_translate=(0.0, 0.0),
        # UI theme is fixed to 'dark'; canvas background is forced to white.
    )

Notes:
        spatialdata_obj,
        # If shapes are in microns but image is in pixels, scale by 1/MPP
        # (Do NOT pass this if your tiles are already in base pixels.)
        # global_to_pixel_scale=(1/0.263049, 1/0.263049),
        # global_to_pixel_translate=(0.0, 0.0),
    )

Notes:
- Assumes `AnnData.obs_names` correspond to the index of `sda.shapes['tiles']` (no column join).
- Robust ID matching: we coerce both sides (obs_names and tiles.index) to strings before intersecting.
- Full-resolution WSI is opened via napari’s reader stack (e.g., napari-openslide).
- Overlays are pyramid-aware by copying the image layer's affine transform.
"""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Optional, List, Dict, Tuple, Union

import numpy as np
import pandas as pd
from qtpy import QtWidgets
from qtpy.QtCore import Qt

# Matplotlib embedded in Qt
import matplotlib
matplotlib.use("QtAgg")  # use the generic Qt backend so PyQt6/PySide are supported
from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure
from matplotlib.lines import Line2D
from matplotlib.widgets import LassoSelector
from matplotlib.path import Path as MplPath
import colorsys

import napari
from napari.layers import Image as NapariImage

from .linkage import (
    ENTITY_ID_COLUMNS,
    IDENTITY_COLUMN_TO_ENTITY,
    TOKEN_CELL_ID_COLUMNS,
    _normalize_id_series,
    get_wsi_path,
)

try:
    import geopandas as gpd
except Exception:
    gpd = None

try:
    from spatialdata import SpatialData
    import spatialdata as sd
    from spatialdata.models import get_table_keys
except Exception:
    SpatialData = object  # type: ignore
    sd = None  # type: ignore
    get_table_keys = None  # type: ignore

try:
    import anndata as ad
except Exception:
    ad = None  # type: ignore

try:
    import tifffile
except Exception:
    tifffile = None  # type: ignore


def parse_mpp_from_str(obj) -> Optional[float]:
    """Try to extract MPP using a simple regex-like parse; returns None if absent."""
    s = str(obj)
    for line in s.splitlines():
        line = line.strip()
        if line.startswith("Pixel physical size:"):
            rest = line.split("Pixel physical size:", 1)[1].strip()
            token = rest.split()[0] if rest else None
            try:
                return float(token)
            except Exception:
                return None
    return None


def is_categorical(series: pd.Series) -> bool:
    if pd.api.types.is_categorical_dtype(series) or series.dtype == object:
        # treat low-cardinality object as categorical
        return series.nunique(dropna=True) <= max(32, int(len(series) * 0.05))
    if pd.api.types.is_integer_dtype(series) or pd.api.types.is_string_dtype(series):
        # Cluster labels such as leiden/dbscan may round-trip as integer/string dtype
        # instead of pandas Categorical after reload. Render low-cardinality cases as
        # classes rather than continuous numeric values.
        return series.nunique(dropna=True) <= max(64, int(len(series) * 0.01))
    return pd.api.types.is_bool_dtype(series)


def _open_image_as_rgb(viewer: napari.Viewer, image_path: str):
    """
    Open TIFF-like RGB images explicitly as Napari RGB layers.
    Falls back to `viewer.open()` for formats we don't recognize here.
    """
    path = Path(image_path)
    suffixes = [s.lower() for s in path.suffixes]
    is_tiff = any(s in {".tif", ".tiff"} for s in suffixes)
    if tifffile is None or not is_tiff:
        viewer.open(str(path))
        return

    with tifffile.TiffFile(str(path)) as tf:
        series = tf.series[0]
        axes = getattr(series, "axes", "")
        levels = list(getattr(series, "levels", [])) or [series]

        def _to_rgb(arr: np.ndarray, axes_name: str) -> np.ndarray:
            if axes_name in {"YXC", "YXS"}:
                return arr
            if axes_name in {"CYX", "SYX"} and arr.ndim == 3 and arr.shape[0] == 3:
                return np.moveaxis(arr, 0, -1)
            raise ValueError(f"Unsupported RGB TIFF layout axes={axes_name!r}, shape={arr.shape!r}")

        # Explicit RGB handling for common TIFF layouts like CYX / YXC / YXS.
        if axes in {"YXC", "YXS", "CYX", "SYX"}:
            data = [_to_rgb(lvl.asarray(out="memmap"), axes) for lvl in levels]
            viewer.add_image(
                data if len(data) > 1 else data[0],
                rgb=True,
                multiscale=len(data) > 1,
                name=path.name,
            )
            return

    viewer.open(str(path))


# ---------- color helpers ---------- #

def _relative_luminance(rgb):
    r, g, b = rgb
    return 0.2126 * r + 0.7152 * g + 0.0722 * b


def _ensure_contrast_on_white(rgb):
    # If too light on white, darken slightly
    try:
        r, g, b = rgb
    except Exception:
        r, g, b, *_ = rgb
    if _relative_luminance((r, g, b)) > 0.82:
        factor = 0.85
        return (r * factor, g * factor, b * factor)
    return (r, g, b)


def _hex_to_rgb01(hex_str: str):
    hex_str = hex_str.lstrip('#')
    return tuple(int(hex_str[i:i+2], 16) / 255.0 for i in (0, 2, 4))


def _okabe_ito_no_black_no_white():
    # Okabe–Ito palette (colorblind-friendly) minus black/white
    hexes = [
        "#E69F00",  # orange
        "#56B4E9",  # sky blue
        "#009E73",  # bluish green
        "#F0E442",  # yellow (will be slightly darkened)
        "#0072B2",  # blue
        "#D55E00",  # vermillion
        "#CC79A7",  # reddish purple
    ]
    cols = [_hex_to_rgb01(hx) for hx in hexes]
    cols = [_ensure_contrast_on_white(c) for c in cols]
    return cols

@dataclass
class SelectionState:
    points: Optional[np.ndarray] = None  # (n_sel,) indices in table order
    name: str = ""
    obs_column: str = ""


# -------------------------- UMAP Lasso Dock -------------------------- #
class UmapLassoDock(QtWidgets.QWidget):
    """A Qt dock embedding a matplotlib scatter with a lasso selector."""

    def __init__(self, embedding: np.ndarray, index: pd.Index, obs: pd.DataFrame, on_selection):
        super().__init__()
        self.embedding = embedding
        self.index = index
        self.obs = obs
        self.on_selection = on_selection
        self._base_colors: Optional[np.ndarray] = None
        self._selected_inds: List[int] = []
        self._colorbar = None
        self._legend = None
        self._init_ui()

    def _init_ui(self):
        layout = QtWidgets.QVBoxLayout(self)
        controls = QtWidgets.QHBoxLayout()
        self.color_combo = QtWidgets.QComboBox()
        self.color_combo.addItem("(none)")
        self.color_combo.addItems(list(self.obs.columns))
        self.color_combo.currentTextChanged.connect(self._on_color_changed)
        controls.addWidget(QtWidgets.QLabel("Color by obs:"))
        controls.addWidget(self.color_combo)
        layout.addLayout(controls)

        self.fig = Figure(figsize=(5, 4), tight_layout=True)
        self.canvas = FigureCanvas(self.fig)
        layout.addWidget(self.canvas)

        ax = self.fig.add_subplot(111)
        self.ax = ax
        self.scatter = ax.scatter(self.embedding[:, 0], self.embedding[:, 1], s=6, linewidths=0)
        ax.set_xlabel("UMAP1")
        ax.set_ylabel("UMAP2")
        ax.set_title("Lasso to select; click outside to clear")
        self._set_default_colors()

        self.lasso = LassoSelector(self.ax, onselect=self._on_lasso)
        self.canvas.mpl_connect("button_press_event", self._on_click)

    def _palette(self, n: int):
        if n <= 8:
            base = _okabe_ito_no_black_no_white()
            return base[:n]
        if n <= 20:
            cmap = matplotlib.colormaps.get("tab20")
            order = list(range(0, 20, 2)) + list(range(1, 20, 2))
            return [tuple(cmap(i)[:3]) for i in order[:n]]
        hs = np.linspace(0.0, 1.0, n, endpoint=False)
        return [colorsys.hsv_to_rgb(float(h), 0.88, 0.88) for h in hs]

    def _clear_legend_artists(self):
        if self._colorbar is not None:
            try:
                self._colorbar.remove()
            except Exception:
                pass
            self._colorbar = None
        if self._legend is not None:
            try:
                self._legend.remove()
            except Exception:
                pass
            self._legend = None

    def _set_default_colors(self):
        self._clear_legend_artists()
        self._base_colors = np.tile(np.array([[0.35, 0.35, 0.35, 0.9]], dtype=float), (len(self.embedding), 1))
        self.scatter.set_array(None)
        self.scatter.set_facecolors(self._base_colors)
        self.scatter.set_edgecolors("none")
        self._apply_selection_alpha()
        self.canvas.draw_idle()

    def _on_color_changed(self, column: str):
        if column == "(none)" or column not in self.obs.columns:
            self._set_default_colors()
            return
        series = self.obs[column]
        if is_categorical(series):
            self._color_categorical(column, series)
        else:
            numeric = pd.to_numeric(series, errors="coerce")
            if numeric.notna().any():
                self._color_numeric(column, numeric)
            else:
                self._color_categorical(column, series.astype(str))
        self._apply_selection_alpha()
        self.canvas.draw_idle()

    def _color_categorical(self, column: str, series: pd.Series):
        self._clear_legend_artists()
        cat = pd.Categorical(series.astype("object").where(~pd.isna(series), "__missing__"))
        categories = list(cat.categories)
        codes = cat.codes
        palette = self._palette(len(categories))
        colors = np.zeros((len(series), 4), dtype=float)
        for i, rgb in enumerate(palette):
            colors[codes == i, :3] = rgb
            colors[codes == i, 3] = 0.9
        missing_idx = categories.index("__missing__") if "__missing__" in categories else None
        if missing_idx is not None:
            colors[codes == missing_idx, :] = (0.75, 0.75, 0.75, 0.45)
        self._base_colors = colors
        self.scatter.set_array(None)
        self.scatter.set_facecolors(colors)
        self.scatter.set_edgecolors("none")

        max_legend = 24
        handles = []
        display_categories = categories[:max_legend]
        counts = pd.Series(cat).value_counts(dropna=False)
        for i, category in enumerate(display_categories):
            label = "NA" if category == "__missing__" else str(category)
            count = int(counts.get(category, 0))
            handles.append(
                Line2D(
                    [0],
                    [0],
                    marker="o",
                    color="none",
                    markerfacecolor=palette[i],
                    markersize=5,
                    label=f"{label} ({count})",
                )
            )
        if len(categories) > max_legend:
            handles.append(
                Line2D(
                    [0],
                    [0],
                    marker="",
                    color="none",
                    label=f"... {len(categories) - max_legend} more",
                )
            )
        self._legend = self.ax.legend(
            handles=handles,
            title=column,
            loc="center left",
            bbox_to_anchor=(1.02, 0.5),
            fontsize=7,
            title_fontsize=8,
            frameon=True,
            borderaxespad=0.0,
        )

    def _color_numeric(self, column: str, numeric: pd.Series):
        self._clear_legend_artists()
        vals = numeric.to_numpy(dtype=float)
        colors = np.zeros((len(vals), 4), dtype=float)
        valid = np.isfinite(vals)
        if not valid.any():
            self._set_default_colors()
            return
        vmin = np.nanpercentile(vals[valid], 2)
        vmax = np.nanpercentile(vals[valid], 98)
        if not np.isfinite(vmin) or not np.isfinite(vmax) or vmin == vmax:
            vmin, vmax = np.nanmin(vals[valid]), np.nanmax(vals[valid])
        norm = matplotlib.colors.Normalize(vmin=vmin, vmax=vmax)
        cmap = matplotlib.colormaps.get("viridis")
        colors[valid] = cmap(norm(vals[valid]))
        colors[~valid] = (0.75, 0.75, 0.75, 0.35)
        self._base_colors = colors
        self.scatter.set_array(None)
        self.scatter.set_facecolors(colors)
        self.scatter.set_edgecolors("none")
        sm = matplotlib.cm.ScalarMappable(norm=norm, cmap=cmap)
        sm.set_array([])
        self._colorbar = self.fig.colorbar(sm, ax=self.ax, fraction=0.046, pad=0.04)
        self._colorbar.set_label(column)

    def _apply_selection_alpha(self):
        if self._base_colors is None:
            return
        colors = self._base_colors.copy()
        if self._selected_inds:
            colors[:, 3] = np.minimum(colors[:, 3], 0.16)
            inds = np.asarray(self._selected_inds, dtype=int)
            colors[inds, 3] = 1.0
            self.scatter.set_sizes(np.full(len(self.embedding), 5.0))
            sizes = self.scatter.get_sizes()
            sizes[inds] = 14.0
            self.scatter.set_sizes(sizes)
            self.scatter.set_edgecolors(np.tile(np.array([[0.0, 0.0, 0.0, 0.0]]), (len(self.embedding), 1)))
        else:
            self.scatter.set_sizes(np.full(len(self.embedding), 6.0))
            self.scatter.set_edgecolors("none")
        self.scatter.set_facecolors(colors)

    def _on_click(self, event):
        # Clicking outside axes clears selection
        if event.inaxes != self.ax:
            self._highlight([])
            self.on_selection([])

    def _on_lasso(self, verts: List[Tuple[float, float]]):
        path = MplPath(verts)
        inds = np.nonzero(path.contains_points(self.embedding))[0]
        self._highlight(inds)
        self.on_selection(list(inds))

    def _highlight(self, inds: List[int]):
        self._selected_inds = list(inds)
        self._apply_selection_alpha()
        self.canvas.draw_idle()


# -------------------------- Main Dock -------------------------- #
class SpatialOverlayDock(QtWidgets.QWidget):
    """Dock widget controlling overlays from SpatialData on a WSI in napari."""

    def __init__(self, viewer: napari.Viewer, sda: SpatialData,
                 global_to_pixel_scale: Tuple[float, float] | None = None,
                 global_to_pixel_translate: Tuple[float, float] | None = None):
        super().__init__()
        if gpd is None:
            raise ImportError("geopandas is required for polygon overlays. pip install geopandas")
        self.viewer = viewer
        self.sda = sda
        self.global_to_pixel_scale = global_to_pixel_scale
        self.global_to_pixel_translate = global_to_pixel_translate

        # State
        self.current_table_key: Optional[str] = None
        self.current_table: Optional[ad.AnnData] = None
        # Choose entity kind from all available shape collections
        available_entities = list(self.sda.shapes.keys())
        if not available_entities:
            raise ValueError("No shapes found in SpatialData.sda.shapes")
        self.entity_kind: str = available_entities[0]
        self.shapes_df: gpd.GeoDataFrame = self.sda.shapes[self.entity_kind]
        self.selection_state = SelectionState()

        # Parse MPP from SpatialData string for optional auto-scaling
        self._mpp = parse_mpp_from_str(self.sda)

        # Build UI
        self._build_ui()

    # ---------------- UI ---------------- #
    def _build_ui(self):
        layout = QtWidgets.QVBoxLayout(self)

        # Header: WSI path and Open button
        wsi_path = get_wsi_path(self.sda)
        header = QtWidgets.QHBoxLayout()
        self.wsi_label = QtWidgets.QLabel(f"WSI: {wsi_path if wsi_path else 'N/A'}")
        self.wsi_label.setTextInteractionFlags(Qt.TextSelectableByMouse)
        self.open_btn = QtWidgets.QPushButton("Open WSI in Viewer")
        self.open_btn.clicked.connect(lambda: self._open_wsi(wsi_path))
        header.addWidget(self.wsi_label)
        header.addStretch(1)
        header.addWidget(self.open_btn)
        layout.addLayout(header)

        # Alignment helpers
        align_row = QtWidgets.QHBoxLayout()
        self.auto_align_btn = QtWidgets.QPushButton("Auto-align (use MPP)")
        self.auto_align_btn.setToolTip("If MPP is missing, you'll be prompted.")
        self.auto_align_btn.clicked.connect(self._auto_align_from_mpp)
        self.calibrate_btn = QtWidgets.QPushButton("Calibrate (fit tiles)")
        self.calibrate_btn.setToolTip("Estimate scale/translation from image & tile bounds")
        self.calibrate_btn.clicked.connect(self._calibrate_fit_to_image)
        self.clear_align_btn = QtWidgets.QPushButton("Clear align")
        self.clear_align_btn.clicked.connect(self._clear_alignment)
        align_row.addWidget(self.auto_align_btn)
        align_row.addWidget(self.calibrate_btn)
        align_row.addWidget(self.clear_align_btn)
        layout.addLayout(align_row)

        layout.addSpacing(6)

        # Entity chooser (Tiles/Tokens)
        entity_row = QtWidgets.QHBoxLayout()
        self.entity_combo = QtWidgets.QComboBox()
        entity_keys = list(self.sda.shapes.keys())
        self.entity_combo.addItems(entity_keys)
        self.entity_combo.setCurrentText(self.entity_kind)
        self.entity_combo.currentTextChanged.connect(self._on_entity_changed)
        entity_row.addWidget(QtWidgets.QLabel("Entity:"))
        entity_row.addWidget(self.entity_combo)
        layout.addLayout(entity_row)

        # Table chooser
        self.table_combo = QtWidgets.QComboBox()
        table_keys = list(self.sda.tables.keys())
        self.table_combo.addItems(table_keys)
        self.table_combo.currentTextChanged.connect(self._on_table_changed)
        layout.addWidget(QtWidgets.QLabel("Table:"))
        layout.addWidget(self.table_combo)

        # obs/obsm chooser
        self.axis_combo = QtWidgets.QComboBox()
        self.axis_combo.addItems(["obs", "obsm"]) 
        self.axis_combo.currentTextChanged.connect(self._on_axis_changed)
        layout.addWidget(QtWidgets.QLabel("Data axis:"))
        layout.addWidget(self.axis_combo)

        # Column / key chooser (populated dynamically)
        self.column_combo = QtWidgets.QComboBox()
        self.column_combo.currentTextChanged.connect(self._populate_value_choices)
        layout.addWidget(QtWidgets.QLabel("Column / embedding key:"))
        layout.addWidget(self.column_combo)

        # Category/value chooser for categorical obs overlays
        self.value_combo = QtWidgets.QComboBox()
        layout.addWidget(QtWidgets.QLabel("Category / value filter:"))
        layout.addWidget(self.value_combo)

        # Buttons for rendering / lasso
        btn_row = QtWidgets.QHBoxLayout()
        self.render_btn = QtWidgets.QPushButton("Render Overlay")
        self.render_btn.clicked.connect(self._on_render)
        self.lasso_btn = QtWidgets.QPushButton("Open UMAP + Lasso")
        self.lasso_btn.clicked.connect(self._on_open_lasso)
        btn_row.addWidget(self.render_btn)
        btn_row.addWidget(self.lasso_btn)
        layout.addLayout(btn_row)

        # Shapes overlay controls
        shapes_group = QtWidgets.QGroupBox("Shapes")
        shapes_layout = QtWidgets.QFormLayout()
        self.shape_layer_combo = QtWidgets.QComboBox()
        self.shape_layer_combo.addItems(list(self.sda.shapes.keys()))
        self.shape_layer_combo.setCurrentText(self.entity_kind)
        self.shape_edge_color_combo = QtWidgets.QComboBox()
        self.shape_edge_color_combo.addItems(
            ["yellow", "cyan", "magenta", "lime", "red", "blue", "white", "black"]
        )
        self.shape_face_color_combo = QtWidgets.QComboBox()
        self.shape_face_color_combo.addItems(
            ["transparent", "yellow", "cyan", "magenta", "lime", "red", "blue", "white"]
        )
        self.shape_face_color_combo.setCurrentText("transparent")
        self.shape_edge_width_spin = QtWidgets.QDoubleSpinBox()
        self.shape_edge_width_spin.setRange(0.1, 20.0)
        self.shape_edge_width_spin.setDecimals(1)
        self.shape_edge_width_spin.setSingleStep(0.1)
        self.shape_edge_width_spin.setValue(0.4)
        self.shape_opacity_spin = QtWidgets.QDoubleSpinBox()
        self.shape_opacity_spin.setRange(0.0, 1.0)
        self.shape_opacity_spin.setDecimals(2)
        self.shape_opacity_spin.setSingleStep(0.05)
        self.shape_opacity_spin.setValue(0.8)
        self.shape_render_btn = QtWidgets.QPushButton("Render Shape Layer")
        self.shape_render_btn.clicked.connect(self._on_render_shape_layer)
        shapes_layout.addRow("Shape layer:", self.shape_layer_combo)
        shapes_layout.addRow("Edge color:", self.shape_edge_color_combo)
        shapes_layout.addRow("Fill color:", self.shape_face_color_combo)
        shapes_layout.addRow("Edge width:", self.shape_edge_width_spin)
        shapes_layout.addRow("Opacity:", self.shape_opacity_spin)
        shapes_layout.addRow(self.shape_render_btn)
        shapes_group.setLayout(shapes_layout)
        layout.addWidget(shapes_group)

        # Save selection controls
        save_group = QtWidgets.QGroupBox("Save current lasso selection to obs")
        save_layout = QtWidgets.QFormLayout()
        self.sel_name_edit = QtWidgets.QLineEdit()
        self.obs_col_edit = QtWidgets.QLineEdit()
        self.save_btn = QtWidgets.QPushButton("Save selection")
        self.save_btn.clicked.connect(self._on_save_selection)
        save_layout.addRow("Layer name:", self.sel_name_edit)
        save_layout.addRow("obs column:", self.obs_col_edit)
        save_layout.addRow(self.save_btn)
        save_group.setLayout(save_layout)
        layout.addWidget(save_group)

        layout.addStretch(1)

        # Initialize: trigger entity logic to auto-select a matching table when possible
        self._on_entity_changed(self.entity_kind)

    # ---------------- Actions ---------------- #
    def _open_wsi(self, wsi_path: Optional[str]):
        import os
        if not wsi_path:
            QtWidgets.QMessageBox.warning(self, "No Path", "WSI path not found in SpatialData text.")
            return
        if not os.path.exists(wsi_path):
            QtWidgets.QMessageBox.critical(self, "Path missing", f"WSI not found:{wsi_path}")
            return
        try:
            _open_image_as_rgb(self.viewer, wsi_path)
        except Exception as e:
            QtWidgets.QMessageBox.critical(self, "Open failed", f"Could not open WSI:{e}")

    def _on_table_changed(self, key: str):
        self.current_table_key = key
        self.current_table = self.sda.tables[key]
        inferred_entity = self._infer_entity_for_table(self.current_table)
        if inferred_entity is not None and inferred_entity in self.sda.shapes and inferred_entity != self.entity_kind:
            self.entity_combo.blockSignals(True)
            self.entity_combo.setCurrentText(inferred_entity)
            self.entity_combo.blockSignals(False)
            self.entity_kind = inferred_entity
            self.shapes_df = self.sda.shapes[inferred_entity]
        self._populate_columns()

    def _on_entity_changed(self, kind: str):
        # Update selected entity and shapes dataframe
        if kind not in self.sda.shapes:
            QtWidgets.QMessageBox.warning(self, "Unknown entity", f"Shapes['{kind}'] not found.")
            return
        self.entity_kind = kind
        self.shapes_df = self.sda.shapes[kind]
        if self.table_combo.currentText():
            self._on_table_changed(self.table_combo.currentText())

    def _on_axis_changed(self, axis: str):
        self._populate_columns()

    def _on_theme_changed(self, theme_name: str):
        """Switch napari UI theme (light=white background, dark=black)."""
        try:
            self.viewer.theme = theme_name
        except Exception:
            # older napari versions may not support theme assignment; ignore
            pass

    def _on_bg_changed(self, color_name: str):
        """Set only the canvas/view area background, not the whole UI."""
        self._set_canvas_background(color_name)

    def _set_canvas_background(self, color: str):
        # Try multiple access paths for robustness across napari versions
        try:
            qtv = getattr(self.viewer.window, 'qt_viewer', None) or getattr(self.viewer.window, '_qt_viewer', None)
            if qtv is not None and hasattr(qtv, 'canvas') and qtv.canvas is not None:
                try:
                    qtv.canvas.bgcolor = color
                    return
                except Exception:
                    try:
                        qtv.canvas.set_background_color(color)
                        return
                    except Exception:
                        pass
        except Exception:
            pass

    def _populate_columns(self):
        self.column_combo.clear()
        self.value_combo.clear()
        if self.current_table is None:
            return
        axis = self.axis_combo.currentText()
        if axis == "obs":
            cols = list(self.current_table.obs.columns)
        else:
            cols = list(self.current_table.obsm.keys())
        self.column_combo.addItems(cols)
        self._populate_value_choices()

    def _populate_value_choices(self):
        self.value_combo.clear()
        self.value_combo.addItem("All categories")
        if self.current_table is None:
            return
        if self.axis_combo.currentText() != "obs":
            return
        col = (self.column_combo.currentText() or "").strip()
        if not col or col not in self.current_table.obs:
            return
        series = self.current_table.obs[col]
        if not is_categorical(series):
            return
        values = pd.Series(series).dropna()
        if values.empty:
            return
        unique_vals = pd.Index(pd.unique(values.astype(object)))
        for val in unique_vals:
            self.value_combo.addItem(str(val))

    def _overlay_transform_kwargs(self) -> Dict:
        """Mirror the current image transform onto shape overlays when possible."""
        img_layer = self._get_image_layer()
        if img_layer is None:
            return {}
        affine = getattr(img_layer, "affine", None)
        return {"affine": affine} if affine is not None else {}

    def _infer_entity_for_table(self, tbl) -> Optional[str]:
        if tbl is None:
            return None
        if self.current_table_key and "_mIF_cells" in self.current_table_key and "tokens" in self.sda.shapes:
            return "tokens"
        if get_table_keys is not None:
            try:
                region, _, _ = get_table_keys(tbl)
            except Exception:
                region = None
            else:
                if isinstance(region, str) and region in self.sda.shapes:
                    return region
                if isinstance(region, (list, tuple)) and len(region) == 1 and region[0] in self.sda.shapes:
                    return region[0]
        for col in tbl.obs.columns:
            if col in IDENTITY_COLUMN_TO_ENTITY and IDENTITY_COLUMN_TO_ENTITY[col] in self.sda.shapes:
                return IDENTITY_COLUMN_TO_ENTITY[col]
        return None

    def _shape_value_map_for_current_table(self, col: str) -> pd.Series:
        """
        Return a Series indexed by shape row labels containing the value to render for the current table/entity.
        Supports direct table->shape identity matching and special cell->token projection for *_mIF_cells tables.
        """
        tbl = self.current_table
        if tbl is None:
            return pd.Series(dtype=object)

        # Special case: project cell-level mIF annotations onto token shapes.
        if (
            self.current_table_key
            and "_mIF_cells" in self.current_table_key
            and self.entity_kind == "tokens"
        ):
            cell_id_col = next((c for c in ["global_cell_id", "cell_id", "CellId", "instance_id"] if c in tbl.obs.columns), None)
            token_cell_col = next((c for c in TOKEN_CELL_ID_COLUMNS if c in self.shapes_df.columns), None)
            if cell_id_col is not None and token_cell_col is not None:
                cell_values = pd.DataFrame(
                    {
                        "cell_id": _normalize_id_series(tbl.obs[cell_id_col].values).values,
                        "value": tbl.obs[col].values,
                    }
                )
                cell_values = cell_values.drop_duplicates(subset="cell_id", keep="last").set_index("cell_id")["value"]
                token_cell_ids = _normalize_id_series(self.shapes_df[token_cell_col].values, index=self.shapes_df.index)
                vals = cell_values.reindex(token_cell_ids)
                vals.index = self.shapes_df.index
                return vals

        # Default direct mapping: table identity column -> current shape identity column.
        shape_identity = self._shape_identity_series().astype(str)
        shape_ids = self._table_shape_ids(tbl)
        if shape_ids.empty:
            return pd.Series(dtype=object)
        value_map = pd.DataFrame(
            {
                "shape_id": shape_ids.astype(str).values,
                "value": tbl.obs.loc[shape_ids.index, col].values,
            }
        )
        value_map = value_map.drop_duplicates(subset="shape_id", keep="last").set_index("shape_id")["value"]
        vals = value_map.reindex(shape_identity)
        vals.index = self.shapes_df.index
        return vals

    def _on_render(self):
        if self.current_table is None:
            QtWidgets.QMessageBox.warning(self, "No table", "Select a table first.")
            return
        axis = self.axis_combo.currentText()
        key = (self.column_combo.currentText() or "").strip()
        if not key:
            QtWidgets.QMessageBox.warning(self, "No column/key", f"Select a column in {axis}.")
            return
        if axis == "obs":
            if key not in self.current_table.obs:
                QtWidgets.QMessageBox.warning(self, "Missing column", f"obs['{key}'] not found in the selected table.")
                return
            self._render_obs_column(key)
        else:
            QtWidgets.QMessageBox.information(
                self, "Embedding", "Rendering from obsm is handled via the UMAP + Lasso panel."
            )

    def _on_render_shape_layer(self):
        shape_key = (self.shape_layer_combo.currentText() or "").strip()
        if not shape_key:
            QtWidgets.QMessageBox.warning(self, "No shape layer", "Choose a shape layer first.")
            return
        if shape_key not in self.sda.shapes:
            QtWidgets.QMessageBox.warning(self, "Missing", f"shapes['{shape_key}'] not found.")
            return
        self._render_shape_layer(shape_key)

    def _on_open_lasso(self):
        if self.current_table is None:
            return
        if self.axis_combo.currentText() != "obsm":
            QtWidgets.QMessageBox.information(self, "Select obsm", "Switch Data axis to 'obsm' and choose an embedding key (e.g., X_umap).")
            return
        key = self.column_combo.currentText()
        if key == "":
            QtWidgets.QMessageBox.warning(self, "No key", "Choose an obsm key (e.g., X_umap) first.")
            return
        if key not in self.current_table.obsm:
            QtWidgets.QMessageBox.warning(self, "Missing", f"obsm['{key}'] not found.")
            return
        emb = np.asarray(self.current_table.obsm[key])
        if emb.ndim != 2 or emb.shape[1] < 2:
            QtWidgets.QMessageBox.warning(self, "Invalid", f"obsm['{key}'] must be (n,2+) for lasso.")
            return
        emb2 = emb[:, :2]

        # Create/raise a docked window with the lasso scatter
        self._lasso_dialog = QtWidgets.QDialog(self)
        self._lasso_dialog.setWindowTitle(f"Lasso selection: {self.current_table_key}:{key}")
        layout = QtWidgets.QVBoxLayout(self._lasso_dialog)
        dock = UmapLassoDock(emb2, self.current_table.obs_names, self.current_table.obs, self._apply_lasso_selection)
        layout.addWidget(dock)
        note = QtWidgets.QLabel("After lasso, a green 'Lasso preview' overlay should appear on the WSI. If you don't see it, try 'Auto-align (use MPP)' or 'Calibrate (fit tiles)'.")
        note.setWordWrap(True)
        layout.addWidget(note)
        self._lasso_dialog.resize(680, 560)
        self._lasso_dialog.show()

    def _apply_lasso_selection(self, sel_inds: List[int]):
        # Record selection in state and immediately overlay as a layer
        if self.current_table is None:
            return
        self.selection_state.points = np.asarray(sel_inds, dtype=int) if len(sel_inds) else None
        self._overlay_selection_preview()

    # ---------------- Matching & overlay logic ---------------- #
    def _candidate_id_columns(self, entity_kind: Optional[str] = None) -> List[str]:
        entity_kind = self.entity_kind if entity_kind is None else entity_kind
        return ENTITY_ID_COLUMNS.get(entity_kind, []) + ["instance_id"]

    def _shape_identity_series(self) -> pd.Series:
        """
        Return a Series indexed by shape row labels whose values are the identity column
        used to match table rows to shapes for the current entity.
        """
        shp_idx = pd.Index(self.shapes_df.index)
        for col in self._candidate_id_columns():
            if col in self.shapes_df.columns:
                return _normalize_id_series(self.shapes_df[col].values, index=shp_idx)
        return _normalize_id_series(shp_idx.values, index=shp_idx)

    def _match_shape_ids_to_rows(self, shape_ids: pd.Index) -> pd.Index:
        """Return shape row labels matching the provided identity values."""
        shape_identity = self._shape_identity_series()
        ids_str = pd.Index(shape_ids).astype(str)
        mask = shape_identity.astype(str).isin(ids_str)
        return pd.Index(shape_identity.index[mask])

    def _table_shape_ids(self, tbl=None) -> pd.Series:
        """
        Return a row-aligned Series mapping table rows to shape IDs for the current entity.
        Prefer SpatialData's declared instance_key/region_key linkage; fall back to obs_names.
        """
        tbl = self.current_table if tbl is None else tbl
        if tbl is None:
            return pd.Series(dtype=object)

        row_names = pd.Index(tbl.obs_names)

        # Special case: project cell-level mIF rows onto token shapes.
        if (
            tbl is self.current_table
            and self.current_table_key
            and "_mIF_cells" in self.current_table_key
            and self.entity_kind == "tokens"
        ):
            cell_id_col = next((c for c in ["global_cell_id", "cell_id", "CellId", "instance_id"] if c in tbl.obs.columns), None)
            token_cell_col = next((c for c in TOKEN_CELL_ID_COLUMNS if c in self.shapes_df.columns), None)
            token_id_col = next((c for c in ENTITY_ID_COLUMNS.get("tokens", []) if c in self.shapes_df.columns), None)
            if cell_id_col is not None and token_cell_col is not None:
                token_shape_ids = self._shape_identity_series()
                token_cell_ids = _normalize_id_series(self.shapes_df[token_cell_col].values, index=self.shapes_df.index)
                token_lookup = pd.DataFrame(
                    {
                        "cell_id": token_cell_ids.values,
                        "token_shape_id": token_shape_ids.loc[token_cell_ids.index].astype(str).values,
                    }
                )
                token_lookup = token_lookup.drop_duplicates(subset="cell_id", keep="first").set_index("cell_id")["token_shape_id"]
                cell_ids = _normalize_id_series(tbl.obs[cell_id_col].values, index=row_names)
                mapped = token_lookup.reindex(cell_ids)
                mapped.index = row_names
                return mapped.dropna()

        shape_ids = None
        if get_table_keys is not None:
            try:
                _, region_key, instance_key = get_table_keys(tbl)
            except Exception:
                region_key, instance_key = None, None
            else:
                if instance_key and instance_key in tbl.obs:
                    shape_ids = _normalize_id_series(tbl.obs[instance_key].values, index=row_names)
                if region_key and region_key in tbl.obs:
                    region_vals = tbl.obs[region_key].astype(str)
                    shape_ids = shape_ids[region_vals == str(self.entity_kind)]
        if shape_ids is None:
            for col in self._candidate_id_columns():
                if col in tbl.obs:
                    shape_ids = _normalize_id_series(tbl.obs[col].values, index=row_names)
                    break
        if shape_ids is None:
            shape_ids = _normalize_id_series(row_names.values, index=row_names)
        return shape_ids.dropna()

    def _shape_ids_from_rows(self, row_names: pd.Index, tbl=None) -> pd.Index:
        tbl = self.current_table if tbl is None else tbl
        if tbl is None:
            return pd.Index([], dtype=object)
        shape_ids = self._table_shape_ids(tbl)
        selected_rows = pd.Index(row_names).intersection(shape_ids.index)
        if len(selected_rows) == 0:
            return pd.Index([], dtype=object)
        return pd.Index(shape_ids.loc[selected_rows].astype(str))

    def _tiles_to_napari(self, idx_like: pd.Index) -> Tuple[List[np.ndarray], Dict]:
        """Convert selected polygons to napari Shapes data after safe matching for current entity."""
        avail = self._match_shape_ids_to_rows(pd.Index(idx_like))
        if len(avail) == 0:
            return [], {}
        sub = self.shapes_df.loc[avail]
        polys: List[np.ndarray] = []
        for geom in sub.geometry:
            if geom is None or geom.is_empty:
                continue
            geoms = [geom] if geom.geom_type == "Polygon" else list(geom.geoms)
            for g in geoms:
                coords = np.asarray(g.exterior.coords, float)  # (x, y)
                # Optional global->pixel transform
                if self.global_to_pixel_scale is not None:
                    sx, sy = self.global_to_pixel_scale
                    coords = coords * np.array([sx, sy], float)
                if self.global_to_pixel_translate is not None:
                    tx, ty = self.global_to_pixel_translate
                    coords = coords + np.array([tx, ty], float)
                polys.append(coords[:, [1, 0]])  # (row, col)
        return polys, {}

    def _shape_frame_to_napari(self, shape_df) -> List[np.ndarray]:
        polys: List[np.ndarray] = []
        for geom in shape_df.geometry:
            if geom is None or geom.is_empty:
                continue
            geoms = [geom] if geom.geom_type == "Polygon" else list(geom.geoms)
            for g in geoms:
                coords = np.asarray(g.exterior.coords, float)
                if self.global_to_pixel_scale is not None:
                    sx, sy = self.global_to_pixel_scale
                    coords = coords * np.array([sx, sy], float)
                if self.global_to_pixel_translate is not None:
                    tx, ty = self.global_to_pixel_translate
                    coords = coords + np.array([tx, ty], float)
                polys.append(coords[:, [1, 0]])
        return polys

    def _render_shape_layer(self, shape_key: str):
        shape_df = self.sda.shapes[shape_key]
        polys = self._shape_frame_to_napari(shape_df)
        if not polys:
            QtWidgets.QMessageBox.warning(self, "No polygons", f"No polygons found in shapes['{shape_key}'].")
            return
        edge_color = self.shape_edge_color_combo.currentText() or "yellow"
        face_color = self.shape_face_color_combo.currentText() or "transparent"
        edge_width = float(self.shape_edge_width_spin.value())
        opacity = float(self.shape_opacity_spin.value())
        layer = self.viewer.add_shapes(
            polys,
            shape_type="polygon",
            edge_width=edge_width,
            edge_color=edge_color,
            face_color=face_color,
            name=self._unique_layer_name(shape_key),
            blending="translucent",
            opacity=opacity,
            **self._overlay_transform_kwargs(),
        )
        self.viewer.layers.selection.active = layer

    def _get_categorical_palette(self, n: int):
        """Return n high-contrast colors suitable for a white canvas.
        Strategy:
          - n <= 8: Okabe–Ito (colorblind-friendly) minus black; yellow darkened
          - 9 <= n <= 12: matplotlib 'tab10' then a few from 'Dark2'
          - 13 <= n <= 20: 'tab20' with even-then-odd index ordering for separation
          - n > 20: evenly spaced HSV around the color wheel, tuned for white background
        """
        out = []
        if n <= 8:
            base = _okabe_ito_no_black_no_white()
            out = base[:n]
        elif n <= 12:
            tab10 = matplotlib.colormaps.get("tab10")
            out = [tuple(tab10(i)[:3]) for i in range(min(10, n))]
            if n > 10:
                dark2 = matplotlib.colormaps.get("Dark2")
                out += [tuple(dark2(i)[:3]) for i in range(n - 10)]
        elif n <= 20:
            tab20 = matplotlib.colormaps.get("tab20")
            order = list(range(0, 20, 2)) + list(range(1, 20, 2))
            out = [tuple(tab20(i)[:3]) for i in order[:n]]
        else:
            hs = np.linspace(0.0, 1.0, n, endpoint=False)
            for k, h in enumerate(hs):
                s = 0.85 if (k % 2 == 0) else 0.95
                v = 0.90
                r, g, b = colorsys.hsv_to_rgb(h, s, v)
                out.append((r, g, b))
        # improve contrast on white
        out = [_ensure_contrast_on_white(c) for c in out]
        return out

    def _overlay_selection_preview(self):
        # Remove previous preview layer if any
        for lyr in [lyr for lyr in self.viewer.layers if lyr.name == "Lasso preview"]:
            self.viewer.layers.remove(lyr)
        if self.selection_state.points is None or self.current_table is None:
            return
        selected_rows = self.current_table.obs_names[self.selection_state.points]
        selected_shape_ids = self._shape_ids_from_rows(selected_rows)
        polys, _ = self._tiles_to_napari(selected_shape_ids)
        if not polys:
            tiles_idx = self.shapes_df.index
            msg = (
                "No polygons for current selection."
                f"Examples:first selected rows → {list(map(str, selected_rows[:5]))}"
                f" selected shape ids → {list(map(str, selected_shape_ids[:5]))}"
                f"first {self.entity_kind}.index → {list(map(str, tiles_idx[:5]))}"
                f"Tips:• Ensure the table's instance_key maps to {self.entity_kind}.index."
                f" • If coordinates look off, try Auto-align (use MPP) or Calibrate (fit {self.entity_kind})."
            )
            QtWidgets.QMessageBox.warning(self, "No overlay", msg)
            return
        layer = self.viewer.add_shapes(
            polys,
            shape_type="polygon",
            edge_width=0.6,
            edge_color="black",
            face_color="green",
            name="Lasso preview",
            blending="translucent",
            opacity=0.4,
            **self._overlay_transform_kwargs(),
        )
        self.viewer.layers.selection.active = layer

    def _render_obs_column(self, col: str):
        tbl = self.current_table
        if tbl is None:
            return
        selected_value = (self.value_combo.currentText() or "").strip()
        vals = self._shape_value_map_for_current_table(col)
        if vals.empty:
            QtWidgets.QMessageBox.information(
                self,
                "No overlap",
                f"No rows in the selected table map to the '{self.entity_kind}' shapes.",
            )
            return
        vals = vals.reindex(self.shapes_df.index)
        matched_mask = ~pd.isna(vals)
        if not matched_mask.any():
            QtWidgets.QMessageBox.information(
                self,
                "No overlap",
                f"No non-null values from the selected table mapped to the current {self.entity_kind} shapes.",
            )
            return
        vals = vals[matched_mask]

        # If everything is NA after matching, nothing to draw
        if vals.dropna().empty:
            QtWidgets.QMessageBox.information(
                self,
                "No data",
                f"obs['{col}'] has no non-null values on matched tiles.",
            )
            return

        # ---- Categorical (strings/low-cardinality) ----
        if is_categorical(vals):
            cats = pd.Categorical(vals.astype("category")).categories
            if len(cats) == 0:
                QtWidgets.QMessageBox.information(self, "No classes", f"No non-null classes in obs['{col}'].")
                return
            if selected_value and selected_value != "All categories":
                vals = vals[vals.astype(str) == selected_value]
                if vals.empty:
                    QtWidgets.QMessageBox.information(
                        self,
                        "No overlap",
                        f"No matched {self.entity_kind} shapes for obs['{col}'] == '{selected_value}'.",
                    )
                    return
                cats = pd.Categorical(vals.astype("category")).categories
            palette = self._get_categorical_palette(len(cats))
            any_drawn = False
            for i, cat in enumerate(cats):
                idx = vals.index[(vals == cat).fillna(False)]
                if len(idx) == 0:
                    continue
                polys, _ = self._tiles_to_napari(idx)
                if not polys:
                    continue
                color = np.array(palette[i % len(palette)])
                face_color = np.tile(color, (len(polys), 1))
                layer = self.viewer.add_shapes(
                    polys,
                    shape_type="polygon",
                    edge_width=0.5,
                    edge_color="white",
                    face_color=face_color,
                    name=self._unique_layer_name(str(cat)),
                    blending="translucent",
                    opacity=0.4,
                    **self._overlay_transform_kwargs(),
                )
                self.viewer.layers.selection.active = layer
                any_drawn = True
            if not any_drawn:
                QtWidgets.QMessageBox.information(self, "Nothing to draw", "No matching polygons for the chosen column.")
            return

        # ---- Numeric ----
        numeric_vals = pd.to_numeric(vals, errors="coerce")
        if numeric_vals.dropna().empty:
            QtWidgets.QMessageBox.warning(self, "No data", f"All values in obs['{col}'] are NaN after matching.")
            return
        vmin = np.nanpercentile(numeric_vals, 2)
        vmax = np.nanpercentile(numeric_vals, 98)
        if not np.isfinite(vmin) or not np.isfinite(vmax) or vmin == vmax:
            vmin, vmax = np.nanmin(numeric_vals.values), np.nanmax(numeric_vals.values)
        norm = matplotlib.colors.Normalize(vmin=vmin, vmax=vmax)
        cmap = matplotlib.colormaps.get("viridis")

        idx_all = numeric_vals.index
        poly_data, _ = self._tiles_to_napari(idx_all)
        if not poly_data:
            QtWidgets.QMessageBox.warning(self, "No polygons", "Tiles not found or alignment issue.")
            return
        colors = []
        for v in numeric_vals.reindex(idx_all).values:
            if np.isnan(v):
                colors.append((0, 0, 0, 0))
            else:
                colors.append(cmap(norm(v)))
        colors = np.array(colors)
        if len(colors) != len(poly_data):
            colors = np.tile(np.array(cmap(0.5))[:3], (len(poly_data), 1))
        layer = self.viewer.add_shapes(
            poly_data,
            shape_type="polygon",
            edge_width=0.2,
            edge_color="white",
            face_color=colors,
            name=self._unique_layer_name(str(col)),
            blending="translucent",
            opacity=0.4,
            **self._overlay_transform_kwargs(),
        )
        self.viewer.layers.selection.active = layer
    
    def _on_save_selection(self):
        """Save current lasso as STRING labels in an obs column."""
        if self.selection_state.points is None or self.current_table is None:
            QtWidgets.QMessageBox.information(self, "Nothing to save", "No active lasso selection.")
            return
    
        name = self.sel_name_edit.text().strip() or "selection"
        obs_col = self.obs_col_edit.text().strip() or name
        adata = self.current_table
    
        # Ensure target column exists as PLAIN-STRING (object) dtype, with no NA
        if obs_col not in adata.obs:
            adata.obs[obs_col] = pd.Series("", index=adata.obs_names, dtype=object)
        else:
            s = adata.obs[obs_col]
            # nullable string or categorical → object; other non-object → object
            if pd.api.types.is_categorical_dtype(s) or getattr(s.dtype, "name", "") == "string" or s.dtype != object:
                s = s.astype(object)
            # replace missing with empty string
            s = s.where(~pd.isna(s), "")
            adata.obs[obs_col] = s
    
        # Indices to update (selected tiles)
        sel_names = adata.obs_names[self.selection_state.points]
        # Write the provided name to selected rows only
        adata.obs.loc[sel_names, obs_col] = str(name)
    
        # Add a permanent layer with this selection and clear preview
        sel_shape_ids = self._shape_ids_from_rows(sel_names, adata)
        polys, _ = self._tiles_to_napari(sel_shape_ids)
        if polys:
            layer = self.viewer.add_shapes(
                polys,
                shape_type="polygon",
                edge_width=0.6,
                edge_color="black",
                face_color="orange",
                name=name,
                blending="translucent",
                opacity=0.4,
                **self._overlay_transform_kwargs(),
            )
            self.viewer.layers.selection.active = layer
    
        # Clear preview layer
        for lyr in [lyr for lyr in self.viewer.layers if lyr.name == "Lasso preview"]:
            self.viewer.layers.remove(lyr)
    
        # Refresh UI to include/select the saved column
        self.axis_combo.setCurrentText("obs")
        self._populate_columns()
        i = self.column_combo.findText(obs_col)
        if i >= 0:
            self.column_combo.setCurrentIndex(i)
    
        QtWidgets.QMessageBox.information(
            self,
            "Saved",
            f"Saved {len(sel_names)} {self.entity_kind} to obs['{obs_col}'] as '{name}'. Existing values outside the selection were left unchanged.",
        )


    # ---- alignment helpers ----
    def _get_image_layer(self) -> Optional[NapariImage]:
        # Return the first Image layer (assumed to be the WSI)
        for lyr in self.viewer.layers:
            if isinstance(lyr, NapariImage):
                return lyr
        return None

    def _unique_layer_name(self, base: str) -> str:
        """Return a name not already used in the viewer by appending (2), (3), ..."""
        existing = {lyr.name for lyr in self.viewer.layers}
        if base not in existing:
            return base
        k = 2
        while f"{base} ({k})" in existing:
            k += 1
        return f"{base} ({k})"

    def _calibrate_fit_to_image(self):
        """Estimate scale and translation so tile bounds fit the current image layer."""
        img = self._get_image_layer()
        if img is None:
            QtWidgets.QMessageBox.warning(self, "No image", "Open a WSI image layer first.")
            return
        # image base dimensions (pixels)
        if isinstance(img.data, list):
            H, W = img.data[0].shape[-2:]
        else:
            H, W = img.data.shape[-2:]
        minx, miny, maxx, maxy = self.shapes_df.geometry.total_bounds
        span_x = maxx - minx
        span_y = maxy - miny
        if span_x <= 0 or span_y <= 0:
            QtWidgets.QMessageBox.warning(self, "Invalid shapes", f"{self.entity_kind.capitalize()} bounds are degenerate.")
            return
        sx = W / span_x
        sy = H / span_y
        if abs(sx - sy) / max(sx, sy) < 0.05:
            s = (sx + sy) / 2.0
            self.global_to_pixel_scale = (s, s)
        else:
            self.global_to_pixel_scale = (sx, sy)
        tx = -minx * self.global_to_pixel_scale[0]
        ty = -miny * self.global_to_pixel_scale[1]
        self.global_to_pixel_translate = (tx, ty)
        QtWidgets.QMessageBox.information(self, "Calibrated", f"Scale≈({self.global_to_pixel_scale[0]:.3f}, {self.global_to_pixel_scale[1]:.3f}),Translate≈({tx:.1f}, {ty:.1f})")
        self._overlay_selection_preview()

    def _auto_align_from_mpp(self):
        """If shapes are in microns and image is in pixels, scale by 1/MPP. If MPP missing, prompt."""
        img = self._get_image_layer()
        if img is None:
            QtWidgets.QMessageBox.warning(self, "No image", "Open a WSI image layer first.")
            return
        # derive image size
        if isinstance(img.data, list):
            H, W = img.data[0].shape[-2:]
        else:
            H, W = img.data.shape[-2:]
        minx, miny, maxx, maxy = self.shapes_df.geometry.total_bounds
        span_x, span_y = maxx - minx, maxy - miny

        mpp = self._mpp
        if mpp is None:
            val, ok = QtWidgets.QInputDialog.getDouble(self, "Set MPP", "Enter pixel size (µm/px):", 0.5, 0.01, 10.0, 6)
            if not ok:
                return
            mpp = float(val)
            self._mpp = mpp

        # Heuristic: if shapes already span the image roughly, they're likely in pixels already
        already_pixels = (0.5 <= span_x / W <= 2.0) and (0.5 <= span_y / H <= 2.0)
        if already_pixels:
            QtWidgets.QMessageBox.information(self, "No scaling applied", f"{self.entity_kind.capitalize()} appear to be in pixel units already; skipping 1/MPP scaling.")
            self.global_to_pixel_scale = None
            self.global_to_pixel_translate = None
            self._overlay_selection_preview()
            return

        s = 1.0 / float(mpp)
        self.global_to_pixel_scale = (s, s)
        self.global_to_pixel_translate = None
        QtWidgets.QMessageBox.information(self, "Alignment applied", f"Scaled tiles by 1/MPP = {s:.3f}.")
        self._overlay_selection_preview()

    def _clear_alignment(self):
        self.global_to_pixel_scale = None
        self.global_to_pixel_translate = None
        QtWidgets.QMessageBox.information(self, "Alignment cleared", "Scale/translate reset.")
        self._overlay_selection_preview()


# -------------------------- Public API -------------------------- #

def histomap(sda: Union[SpatialData, str, Path],
                   *,
                   global_to_pixel_scale: Tuple[float, float] | None = None,
                   global_to_pixel_translate: Tuple[float, float] | None = None,
                  theme: str = "dark",
                  canvas_bg: str = "white",
                   imagePath: Optional[str] = None,   # NEW: custom H&E path
                   mpp: Optional[float] = None,      # NEW: µm/px (used only if scale not provided)
                   ) -> napari.Viewer:
    """Launch napari with a dock for SpatialData overlays."""
    if isinstance(sda, (str, Path)):
        if sd is None:
            raise ImportError("spatialdata is required to load a SpatialData object from a path.")
        sda = sd.read_zarr(str(Path(sda)))

    viewer = napari.Viewer()
    # hardcode UI theme to dark
    try:
        viewer.theme = "dark"
    except Exception:
        pass

    # If caller provided MPP and no explicit scale, compute scale = 1/MPP (tiles in microns → pixels)
    if global_to_pixel_scale is None and mpp is not None:
        try:
            s = 1.0 / float(mpp)
            global_to_pixel_scale = (s, s)
        except Exception:
            pass  # ignore bad mpp, fall back to None    
    
    # Create dock 
    dock = SpatialOverlayDock(viewer, sda,
                              global_to_pixel_scale=global_to_pixel_scale,
                              global_to_pixel_translate=global_to_pixel_translate)
    
    # If you keep _mpp on the dock, set it for later 'Auto-align (use MPP)' use
    try:
        dock._mpp = float(mpp) if mpp is not None else dock._mpp
    except Exception:
        pass
    
    viewer.window.add_dock_widget(dock, name="Spatial overlays", area="right")

    # hardcode canvas (view area) background to white
    try:
        dock._set_canvas_background("white")
    except Exception:
        pass

    # Resolve image path: prefer user-provided > parsed
    import os
    path = imagePath or get_wsi_path(sda)

    if path and os.path.exists(path):
        try:
            _open_image_as_rgb(viewer, path)
        except Exception as e:
            QtWidgets.QMessageBox.critical(
                None,
                "Failed to open H&E image",
                f"Could not open image at '{path}': {e}"
            )
    else:
        QtWidgets.QMessageBox.warning(
            None,
            "H&E Image Missing",
            "No H&E image path found. Please pass it explicitly via:\n"
            "  histomap(sda, imagePath='/path/to/image.svs')"
        )

    return viewer

if __name__ == "__main__":
    print("This module provides histomap(sda). Import and call from your analysis script.")
