"""
Clustering utilities for SpatialData/WSIData tables with path-based writeback.

Exposes:
- leiden(...): write cluster labels to adata.obs[target_col]
- dbscan(...): write DBSCAN labels to adata.obs[target_col]
"""
from __future__ import annotations

from pathlib import Path
from typing import Optional
import inspect

import numpy as np
import pandas as pd
from tqdm import tqdm

try:
    import scipy.sparse as sp
except Exception:
    sp = None  # type: ignore

try:
    from sklearn.cluster import DBSCAN as SklearnDBSCAN
    from sklearn.decomposition import IncrementalPCA
    from sklearn.neighbors import NearestNeighbors
except Exception:
    SklearnDBSCAN = None  # type: ignore
    IncrementalPCA = None  # type: ignore
    NearestNeighbors = None  # type: ignore

try:
    import anndata as ad
except Exception:
    ad = None  # type: ignore

try:
    import igraph as ig
except Exception:
    ig = None  # type: ignore

try:
    import leidenalg
except Exception:
    leidenalg = None  # type: ignore

try:
    import cupy as _cp
except Exception:
    _cp = None  # type: ignore

try:
    from cuml.cluster import DBSCAN as CuMLDBSCAN
    from cuml.decomposition import PCA as CuMLPCA
except Exception:
    CuMLDBSCAN = None  # type: ignore
    CuMLPCA = None  # type: ignore

try:
    import cudf
    import cugraph
    from cuml.neighbors import NearestNeighbors as CuMLNearestNeighbors
except Exception:
    cudf = None  # type: ignore
    cugraph = None  # type: ignore
    CuMLNearestNeighbors = None  # type: ignore

from .umap import _gpu_available, _load_adata, _resolve_sdata_table_store, _write_adata_table_store


def _choose_matrix(adata, *, layer: Optional[str] = None, obsm_key: Optional[str] = None):
    if layer is not None and obsm_key is not None:
        raise ValueError("Pass only one of 'layer' or 'obsm_key'.")
    if obsm_key is not None:
        if obsm_key not in adata.obsm:
            raise KeyError(f"obsm['{obsm_key}'] not found in selected table.")
        return adata.obsm[obsm_key], f"obsm['{obsm_key}']"
    if layer is not None:
        if layer not in adata.layers:
            raise KeyError(f"Layer '{layer}' not found in adata.layers.")
        return adata.layers[layer], f"layer='{layer}'"
    return adata.X, "X"


def _apply_log1p(X):
    if sp is not None and sp.issparse(X):
        X = X.copy()
        X.data = np.log1p(X.data)
        return X
    return np.log1p(np.asarray(X))


def _to_float32_dense(X):
    if sp is not None and sp.issparse(X):
        return X.toarray().astype(np.float32, copy=False)
    return np.asarray(X, dtype=np.float32)


def _to_float32_dense_rows(X, rows=None):
    X_sel = X if rows is None else X[rows]
    if sp is not None and sp.issparse(X_sel):
        return X_sel.toarray().astype(np.float32, copy=False)
    return np.asarray(X_sel, dtype=np.float32)


def _iter_row_slices(n_rows: int, batch_size: int):
    for start in range(0, n_rows, batch_size):
        stop = min(n_rows, start + batch_size)
        yield slice(start, stop)


def _fit_sample_indices(n: int, sample_n: Optional[int], *, random_state: int):
    if sample_n is None or int(sample_n) >= n:
        return None
    k = max(2, min(int(sample_n), n))
    rng = np.random.default_rng(random_state)
    return np.sort(rng.choice(n, size=k, replace=False))


def _write_obs_labels(adata, target_col: str, labels) -> None:
    labels = np.asarray(labels)
    if labels.ndim != 1 or labels.shape[0] != adata.n_obs:
        raise ValueError("Cluster labels must be a 1D array with length equal to adata.n_obs.")
    labels_int = labels.astype(int)
    labels_str = labels_int.astype(str)
    categories = [str(v) for v in sorted(pd.unique(labels_int))]
    adata.obs[target_col] = pd.Categorical(labels_str, categories=categories)


def _estimate_dbscan_eps(
    X,
    *,
    min_samples: int,
    estimate_sample_n: int,
    quantile: float,
    random_state: int,
) -> float:
    if NearestNeighbors is None:
        raise ImportError("scikit-learn is required to estimate DBSCAN eps on CPU.")
    n = X.shape[0]
    rng = np.random.default_rng(random_state)
    if n > estimate_sample_n:
        sample_idx = np.sort(rng.choice(n, size=estimate_sample_n, replace=False))
        X_est = X[sample_idx]
    else:
        X_est = X
    if sp is not None and sp.issparse(X_est):
        X_est = X_est.tocsr()
    nn = NearestNeighbors(n_neighbors=min_samples, algorithm="auto", n_jobs=-1)
    nn.fit(X_est)
    distances, _ = nn.kneighbors(X_est)
    kth = distances[:, -1]
    eps = float(np.quantile(kth, quantile))
    if not np.isfinite(eps) or eps <= 0:
        raise ValueError("Failed to estimate a positive DBSCAN eps.")
    return eps


def _cugraph_leiden_available() -> bool:
    return bool(_gpu_available() and cudf is not None and cugraph is not None and CuMLNearestNeighbors is not None and _cp is not None)


def _cuml_pca_kwargs(*, n_components: int, random_state: int):
    kwargs = {"n_components": n_components}
    try:
        sig = inspect.signature(CuMLPCA)
    except Exception:
        sig = None
    if sig is not None:
        if "random_state" in sig.parameters:
            kwargs["random_state"] = random_state
        if "output_type" in sig.parameters:
            kwargs["output_type"] = "numpy"
    return kwargs


def _is_gpu_oom(exc: Exception) -> bool:
    text = str(exc).lower()
    return any(
        token in text
        for token in (
            "out of memory",
            "cudaerrormemoryallocation",
            "std::bad_alloc",
            "memoryerror",
        )
    )


def _compute_pca_embedding(
    X,
    *,
    n_components: int,
    sample_n: Optional[int],
    batch_size: int,
    random_state: int,
    use_gpu: bool,
    allow_gpu_fallback: bool,
):
    if n_components <= 0:
        raise ValueError("pca_n_components must be >= 1")
    if batch_size <= 0:
        raise ValueError("pca_batch_size must be >= 1")

    n = X.shape[0]
    sample_inds = _fit_sample_indices(n, sample_n, random_state=random_state)
    n_fit_rows = n if sample_inds is None else len(sample_inds)
    n_features = int(X.shape[1])
    effective_components = min(int(n_components), n_features, n_fit_rows)
    if effective_components <= 0:
        raise ValueError("PCA requires at least one feature and one fitted row.")

    if use_gpu:
        if CuMLPCA is None or _cp is None or not _gpu_available():
            if not allow_gpu_fallback:
                raise RuntimeError("GPU PCA requested, but cuML/CuPy are not available.")
            use_gpu = False
        else:
            try:
                X_fit = _to_float32_dense_rows(X, sample_inds)
                X_fit_gpu = _cp.asarray(X_fit)
                model = CuMLPCA(**_cuml_pca_kwargs(n_components=effective_components, random_state=random_state))
                model.fit(X_fit_gpu)
                del X_fit_gpu
                try:
                    _cp.get_default_memory_pool().free_all_blocks()
                except Exception:
                    pass
                emb = np.empty((n, effective_components), dtype=np.float32)
                for row_slice in _iter_row_slices(n, min(int(batch_size), n)):
                    X_batch = _to_float32_dense_rows(X, row_slice)
                    X_batch_gpu = _cp.asarray(X_batch)
                    emb[row_slice] = np.asarray(model.transform(X_batch_gpu), dtype=np.float32)
                    del X_batch_gpu
                    try:
                        _cp.get_default_memory_pool().free_all_blocks()
                    except Exception:
                        pass
                return emb, "gpu"
            except Exception as exc:
                if not allow_gpu_fallback:
                    raise
                use_gpu = False

    if IncrementalPCA is None:
        raise ImportError("scikit-learn is required for CPU PCA.")
    fit_n = n_fit_rows
    model = IncrementalPCA(n_components=effective_components, batch_size=min(int(batch_size), fit_n))
    if sample_inds is None:
        for row_slice in _iter_row_slices(n, min(int(batch_size), n)):
            model.partial_fit(_to_float32_dense_rows(X, row_slice))
    else:
        X_fit = _to_float32_dense_rows(X, sample_inds)
        for row_slice in _iter_row_slices(X_fit.shape[0], min(int(batch_size), X_fit.shape[0])):
            model.partial_fit(X_fit[row_slice])
    emb = np.empty((n, effective_components), dtype=np.float32)
    for row_slice in _iter_row_slices(n, min(int(batch_size), n)):
        emb[row_slice] = model.transform(_to_float32_dense_rows(X, row_slice)).astype(np.float32, copy=False)
    return emb, "cpu"


def _prepare_cluster_matrix(
    adata,
    *,
    layer: Optional[str],
    obsm_key: Optional[str],
    log: bool,
    force_raw: bool,
    pca_n_components: int,
    pca_sample_n: Optional[int],
    pca_batch_size: int,
    random_state: int,
    prefer_gpu: str,
):
    X, source_label = _choose_matrix(adata, layer=layer, obsm_key=obsm_key)
    if log:
        X = _apply_log1p(X)
        source_label = f"log1p({source_label})"
    if obsm_key is not None or force_raw:
        return X, source_label

    use_gpu_pca = prefer_gpu in {"auto", "gpu"}
    emb, pca_backend = _compute_pca_embedding(
        X,
        n_components=pca_n_components,
        sample_n=pca_sample_n,
        batch_size=pca_batch_size,
        random_state=random_state,
        use_gpu=use_gpu_pca,
        allow_gpu_fallback=(prefer_gpu == "auto"),
    )
    return emb, f"PCA[{pca_backend}]({source_label})"


def _build_leiden_graph_gpu(X, *, n_neighbors: int):
    X_dense = _to_float32_dense(X)
    X_gpu = _cp.asarray(X_dense)
    nn = CuMLNearestNeighbors(n_neighbors=n_neighbors + 1)
    nn.fit(X_gpu)
    distances, indices = nn.kneighbors(X_gpu)
    src = _cp.repeat(_cp.arange(X_gpu.shape[0], dtype=_cp.int32), n_neighbors)
    dst = indices[:, 1:].reshape(-1).astype(_cp.int32)
    weights = (1.0 / (1.0 + distances[:, 1:].reshape(-1))).astype(_cp.float32)
    edge_df = cudf.DataFrame(
        {
            "src": src.get(),
            "dst": dst.get(),
            "weight": weights.get(),
        }
    )
    graph = cugraph.Graph(directed=False)
    graph.from_cudf_edgelist(edge_df, source="src", destination="dst", edge_attr="weight", renumber=False)
    return graph, X_gpu.shape[0]


def _run_leiden_gpu_from_graph(graph, *, n_obs: int, resolution: float, random_state: int):
    parts, _ = cugraph.leiden(graph, resolution=resolution, random_state=random_state)
    labels = np.full(n_obs, -1, dtype=np.int32)
    labels[parts["vertex"].to_numpy()] = parts["partition"].to_numpy().astype(np.int32)
    return labels


def _leidenalg_find_partition_kwargs(*, graph, weights, resolution: float, random_state: int):
    kwargs = {
        "graph": graph,
        "partition_type": leidenalg.RBConfigurationVertexPartition,
        "weights": weights,
        "resolution_parameter": resolution,
    }
    try:
        sig = inspect.signature(leidenalg.find_partition)
    except Exception:
        sig = None
    if sig is not None and "seed" in sig.parameters:
        kwargs["seed"] = random_state
    return kwargs


def _build_leiden_graph_cpu(X, *, n_neighbors: int):
    if NearestNeighbors is None or ig is None:
        raise ImportError("CPU Leiden requires scikit-learn and python-igraph.")
    X_input = X.tocsr() if sp is not None and sp.issparse(X) else np.asarray(X, dtype=np.float32)
    nn = NearestNeighbors(n_neighbors=n_neighbors + 1, algorithm="auto", n_jobs=-1)
    nn.fit(X_input)
    distances, indices = nn.kneighbors(X_input)
    src = np.repeat(np.arange(X_input.shape[0], dtype=np.int32), n_neighbors)
    dst = indices[:, 1:].reshape(-1).astype(np.int32, copy=False)
    weights = (1.0 / (1.0 + distances[:, 1:].reshape(-1))).astype(np.float32, copy=False)

    edge_frame = pd.DataFrame({"src": src, "dst": dst, "weight": weights})
    edge_frame["a"] = np.minimum(edge_frame["src"], edge_frame["dst"])
    edge_frame["b"] = np.maximum(edge_frame["src"], edge_frame["dst"])
    edge_frame = edge_frame[edge_frame["a"] != edge_frame["b"]]
    edge_frame = edge_frame.groupby(["a", "b"], as_index=False)["weight"].max()

    graph = ig.Graph(n=int(X_input.shape[0]), edges=edge_frame[["a", "b"]].itertuples(index=False, name=None), directed=False)
    graph.es["weight"] = edge_frame["weight"].astype(float).tolist()
    return graph


def _run_leiden_cpu_from_graph(graph, *, resolution: float, random_state: int):
    if leidenalg is None:
        raise ImportError("CPU Leiden requires the leidenalg package.")
    partition = leidenalg.find_partition(
        **_leidenalg_find_partition_kwargs(
            graph=graph,
            weights=graph.es["weight"] if "weight" in graph.es.attributes() else None,
            resolution=resolution,
            random_state=random_state,
        )
    )
    return np.asarray(partition.membership, dtype=np.int32)


def leiden(
    sda,
    table: str,
    *,
    layer: Optional[str] = None,
    obsm_key: Optional[str] = None,
    n_neighbors: int = 15,
    resolution: float = 1.0,
    random_state: int = 0,
    target_col: str = "leiden",
    prefer_gpu: str = "auto",
    force_raw: bool = False,
    pca_n_components: int = 50,
    pca_sample_n: Optional[int] = 100_000,
    pca_batch_size: int = 4096,
    show_progress: bool = True,
    write_back: Optional[bool] = None,
    log: bool = False,
):
    source = sda
    if write_back is None:
        write_back = isinstance(source, (str, Path))

    progress = tqdm(
        total=10 if write_back else 9,
        desc=f"Leiden:{table}",
        disable=not show_progress,
        unit="step",
        dynamic_ncols=True,
        leave=False,
    )

    def advance(message: str) -> None:
        if show_progress:
            progress.set_postfix_str(message)
        progress.update(1)

    def phase(message: str) -> None:
        if show_progress:
            progress.set_postfix_str(message)

    try:
        use_gpu = prefer_gpu == "gpu" or (prefer_gpu == "auto" and _cugraph_leiden_available())
        backend_name = "gpu" if use_gpu else "cpu"
        if prefer_gpu == "gpu" and not _cugraph_leiden_available():
            raise RuntimeError("GPU Leiden requested, but cugraph/cudf/cuml neighbors are not available.")
        phase("loading table")
        adata, table_store = _load_adata(source, table)
        advance("table loaded")
        phase("preparing clustering matrix")
        X, source_label = _prepare_cluster_matrix(
            adata,
            layer=layer,
            obsm_key=obsm_key,
            log=log,
            force_raw=force_raw,
            pca_n_components=pca_n_components,
            pca_sample_n=pca_sample_n,
            pca_batch_size=pca_batch_size,
            random_state=random_state,
            prefer_gpu=prefer_gpu,
        )
        advance(f"prepared {source_label}")
        advance(f"backend={backend_name}")
        if use_gpu:
            try:
                phase("building gpu knn graph")
                graph, n_obs = _build_leiden_graph_gpu(X, n_neighbors=n_neighbors)
                advance("gpu graph built")
                phase("running leiden on gpu graph")
                labels = _run_leiden_gpu_from_graph(graph, n_obs=n_obs, resolution=resolution, random_state=random_state)
            except Exception as exc:
                if prefer_gpu == "auto" and _is_gpu_oom(exc):
                    backend_name = "cpu"
                    phase("gpu oom -> cpu fallback")
                    phase("building cpu neighbors graph")
                    graph = _build_leiden_graph_cpu(X, n_neighbors=n_neighbors)
                    advance("cpu graph built")
                    phase("running leiden on cpu graph")
                    labels = _run_leiden_cpu_from_graph(graph, resolution=resolution, random_state=random_state)
                else:
                    raise
        else:
            phase("building cpu neighbors graph")
            graph = _build_leiden_graph_cpu(X, n_neighbors=n_neighbors)
            advance("cpu graph built")
            phase("running leiden on cpu graph")
            labels = _run_leiden_cpu_from_graph(graph, resolution=resolution, random_state=random_state)
        advance("clustered")
        phase("writing labels")
        _write_obs_labels(adata, target_col, labels)
        advance(f"saved obs['{target_col}']")
        if write_back:
            if table_store is None:
                raise ValueError("write_back=True requires a SpatialData path input.")
            phase("writing table store")
            _write_adata_table_store(adata, table_store)
            advance(f"wrote {table_store.as_posix()}")
    except Exception:
        progress.close()
        raise
    progress.close()
    if show_progress:
        print(
            f"[histomap.leiden] Done table='{table}' backend={backend_name} "
            f"source={source_label!r} target_col='{target_col}' n_clusters={np.unique(labels).size}"
        )
    return source


def dbscan(
    sda,
    table: str,
    *,
    layer: Optional[str] = None,
    obsm_key: Optional[str] = None,
    eps: Optional[float] = None,
    min_samples: int = 10,
    estimate_eps_quantile: float = 0.99,
    estimate_sample_n: int = 100_000,
    random_state: int = 0,
    target_col: str = "dbscan",
    prefer_gpu: str = "auto",
    force_raw: bool = False,
    pca_n_components: int = 50,
    pca_sample_n: Optional[int] = 100_000,
    pca_batch_size: int = 4096,
    show_progress: bool = True,
    write_back: Optional[bool] = None,
    log: bool = False,
):
    source = sda
    if write_back is None:
        write_back = isinstance(source, (str, Path))

    progress = tqdm(total=8 if write_back else 7, desc=f"DBSCAN:{table}", disable=not show_progress, unit="step", dynamic_ncols=True, leave=False)

    def advance(message: str) -> None:
        if show_progress:
            progress.set_postfix_str(message)
        progress.update(1)

    try:
        adata, table_store = _load_adata(source, table)
        X, source_label = _prepare_cluster_matrix(
            adata,
            layer=layer,
            obsm_key=obsm_key,
            log=log,
            force_raw=force_raw,
            pca_n_components=pca_n_components,
            pca_sample_n=pca_sample_n,
            pca_batch_size=pca_batch_size,
            random_state=random_state,
            prefer_gpu=prefer_gpu,
        )
        advance(f"loaded {source_label}")
        use_gpu = prefer_gpu == "gpu" or (prefer_gpu == "auto" and _gpu_available() and CuMLDBSCAN is not None and _cp is not None)
        backend_name = "gpu" if use_gpu else "cpu"
        if prefer_gpu == "gpu" and not (CuMLDBSCAN is not None and _cp is not None and _gpu_available()):
            raise RuntimeError("GPU DBSCAN requested, but cuML/CuPy are not available.")
        advance(f"backend={backend_name}")
        if eps is None:
            eps = _estimate_dbscan_eps(
                X,
                min_samples=min_samples,
                estimate_sample_n=estimate_sample_n,
                quantile=estimate_eps_quantile,
                random_state=random_state,
            )
        advance(f"eps={eps:.4g}")
        if use_gpu:
            X_fit = _cp.asarray(_to_float32_dense(X))
            model = CuMLDBSCAN(eps=eps, min_samples=min_samples)
            labels = _cp.asnumpy(model.fit_predict(X_fit)).astype(np.int32)
        else:
            if SklearnDBSCAN is None:
                raise ImportError("scikit-learn is required for CPU DBSCAN.")
            X_fit = X.tocsr() if sp is not None and sp.issparse(X) else np.asarray(X, dtype=np.float32)
            model = SklearnDBSCAN(eps=eps, min_samples=min_samples, metric="euclidean", n_jobs=-1)
            labels = model.fit_predict(X_fit).astype(np.int32)
        advance("clustered")
        _write_obs_labels(adata, target_col, labels)
        advance(f"saved obs['{target_col}']")
        if write_back:
            if table_store is None:
                raise ValueError("write_back=True requires a SpatialData path input.")
            _write_adata_table_store(adata, table_store)
            advance(f"wrote {table_store.as_posix()}")
    except Exception:
        progress.close()
        raise
    progress.close()
    if show_progress:
        n_outliers = int(np.sum(labels == -1))
        print(
            f"[histomap.dbscan] Done table='{table}' backend={backend_name} "
            f"target_col='{target_col}' eps={eps:.4g} outliers={n_outliers}"
        )
    return source


def _build_parser(kind: str):
    import argparse

    parser = argparse.ArgumentParser(description=f"Run {kind} clustering for a SpatialData table and write back labels")
    parser.add_argument("input", help="Path to SpatialData .zarr directory")
    parser.add_argument("--table", required=True, help="Table name in sda.tables to use")
    parser.add_argument("--layer", default=None, help="AnnData layer name to use (default: X)")
    parser.add_argument("--obsm-key", default=None, help="AnnData obsm key to cluster instead of X/layer")
    parser.add_argument("--quiet", action="store_true", help="Disable progress output")
    parser.add_argument("--log", action="store_true", help="Apply log1p to the selected matrix before clustering")
    parser.add_argument("--target-col", default=kind, help=f"obs column to write {kind} labels into")
    parser.add_argument("--prefer-gpu", choices=["auto", "cpu", "gpu"], default="auto")
    parser.add_argument("--force-raw", action="store_true", help="Cluster directly on the selected X/layer instead of the default PCA-reduced representation")
    parser.add_argument("--pca-n-components", type=int, default=50, help="PCA components used by default before clustering when obsm-key is not provided")
    parser.add_argument("--pca-sample-n", type=int, default=100000, help="Rows to use for PCA fitting on large tables")
    parser.add_argument("--pca-batch-size", type=int, default=4096, help="Row batch size for internal PCA reduction")
    parser.add_argument("--random-state", type=int, default=0)
    parser.add_argument("--no-write-back", dest="write_back", action="store_false", help="Compute labels without writing back")
    parser.set_defaults(write_back=True)
    return parser


def main_leiden():
    parser = _build_parser("leiden")
    parser.add_argument("--n-neighbors", type=int, default=15)
    parser.add_argument("--resolution", type=float, default=1.0)
    args = parser.parse_args()
    leiden(
        args.input,
        table=args.table,
        layer=args.layer,
        obsm_key=args.obsm_key,
        n_neighbors=args.n_neighbors,
        resolution=args.resolution,
        random_state=args.random_state,
        target_col=args.target_col,
        prefer_gpu=args.prefer_gpu,
        force_raw=args.force_raw,
        pca_n_components=args.pca_n_components,
        pca_sample_n=args.pca_sample_n,
        pca_batch_size=args.pca_batch_size,
        show_progress=not args.quiet,
        write_back=args.write_back,
        log=args.log,
    )


def main_dbscan():
    parser = _build_parser("dbscan")
    parser.add_argument("--eps", type=float, default=None)
    parser.add_argument("--min-samples", type=int, default=10)
    parser.add_argument("--estimate-eps-quantile", type=float, default=0.99)
    parser.add_argument("--estimate-sample-n", type=int, default=100000)
    args = parser.parse_args()
    dbscan(
        args.input,
        table=args.table,
        layer=args.layer,
        obsm_key=args.obsm_key,
        eps=args.eps,
        min_samples=args.min_samples,
        estimate_eps_quantile=args.estimate_eps_quantile,
        estimate_sample_n=args.estimate_sample_n,
        random_state=args.random_state,
        target_col=args.target_col,
        prefer_gpu=args.prefer_gpu,
        force_raw=args.force_raw,
        pca_n_components=args.pca_n_components,
        pca_sample_n=args.pca_sample_n,
        pca_batch_size=args.pca_batch_size,
        show_progress=not args.quiet,
        write_back=args.write_back,
        log=args.log,
    )
