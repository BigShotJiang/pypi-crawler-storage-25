from __future__ import annotations

__all__ = [
    "histomap",
    "umap",
    "pca",
    "leiden",
    "dbscan",
    "save_umap_images",
    "cluster_similarity",
    "merge_categorical_annotations",
    "merge_categorical_annotations_df",
    "reconcile_annotation_sources",
    "reconcile_annotation_sources_df",
    "map_column_labels",
    "map_column_labels_df",
    "find_mixed_secondary_groups",
    "most_discordant_combinations",
    "plot_overlap_heatmap",
    "thumbnail_pdf",
    "mergeChannelsRGB",
    "__version__",
]


try:
    from importlib.metadata import PackageNotFoundError, version as _get_version
except Exception:
    _get_version = None

    class PackageNotFoundError(Exception):
        pass


__version__ = "unknown"
if _get_version is not None:
    try:
        __version__ = _get_version("histomap")
    except PackageNotFoundError:
        pass
    except Exception:
        pass
def _histomap_wrapper(*args, **kwargs):
    from .histomap import histomap as _histomap

    globals()["histomap"] = _histomap_wrapper
    return _histomap(*args, **kwargs)


def _umap_wrapper(*args, **kwargs):
    from importlib import import_module

    _umap = import_module(".umap", __name__).umap

    globals()["umap"] = _umap_wrapper
    return _umap(*args, **kwargs)


def _leiden_wrapper(*args, **kwargs):
    from importlib import import_module

    _leiden = import_module(".cluster", __name__).leiden

    globals()["leiden"] = _leiden_wrapper
    return _leiden(*args, **kwargs)


def _pca_wrapper(*args, **kwargs):
    from importlib import import_module

    _pca = import_module(".pca", __name__).pca

    globals()["pca"] = _pca_wrapper
    return _pca(*args, **kwargs)


def _dbscan_wrapper(*args, **kwargs):
    from importlib import import_module

    _dbscan = import_module(".cluster", __name__).dbscan

    globals()["dbscan"] = _dbscan_wrapper
    return _dbscan(*args, **kwargs)


def _thumbnail_pdf_wrapper(*args, **kwargs):
    from importlib import import_module

    _thumbnail_pdf = import_module(".thumbnails", __name__).thumbnail_pdf

    globals()["thumbnail_pdf"] = _thumbnail_pdf_wrapper
    return _thumbnail_pdf(*args, **kwargs)


def _save_umap_images_wrapper(*args, **kwargs):
    from importlib import import_module

    _save_umap_images = import_module(".umap_images", __name__).save_umap_images

    globals()["save_umap_images"] = _save_umap_images_wrapper
    return _save_umap_images(*args, **kwargs)


def _cluster_similarity_wrapper(*args, **kwargs):
    from importlib import import_module

    _cluster_similarity = import_module(".cluster_similarity", __name__).cluster_similarity

    globals()["cluster_similarity"] = _cluster_similarity_wrapper
    return _cluster_similarity(*args, **kwargs)


def _merge_categorical_annotations_wrapper(*args, **kwargs):
    from importlib import import_module

    _merge_categorical_annotations = import_module(".annotations", __name__).merge_categorical_annotations

    globals()["merge_categorical_annotations"] = _merge_categorical_annotations_wrapper
    return _merge_categorical_annotations(*args, **kwargs)


def _merge_categorical_annotations_df_wrapper(*args, **kwargs):
    from importlib import import_module

    _merge_categorical_annotations_df = import_module(".annotations", __name__).merge_categorical_annotations_df

    globals()["merge_categorical_annotations_df"] = _merge_categorical_annotations_df_wrapper
    return _merge_categorical_annotations_df(*args, **kwargs)


def _reconcile_annotation_sources_wrapper(*args, **kwargs):
    from importlib import import_module

    _reconcile_annotation_sources = import_module(".annotations", __name__).reconcile_annotation_sources

    globals()["reconcile_annotation_sources"] = _reconcile_annotation_sources_wrapper
    return _reconcile_annotation_sources(*args, **kwargs)


def _reconcile_annotation_sources_df_wrapper(*args, **kwargs):
    from importlib import import_module

    _reconcile_annotation_sources_df = import_module(".annotations", __name__).reconcile_annotation_sources_df

    globals()["reconcile_annotation_sources_df"] = _reconcile_annotation_sources_df_wrapper
    return _reconcile_annotation_sources_df(*args, **kwargs)


def _map_column_labels_wrapper(*args, **kwargs):
    from importlib import import_module

    _map_column_labels = import_module(".label_map", __name__).map_column_labels

    globals()["map_column_labels"] = _map_column_labels_wrapper
    return _map_column_labels(*args, **kwargs)


def _map_column_labels_df_wrapper(*args, **kwargs):
    from importlib import import_module

    _map_column_labels_df = import_module(".label_map", __name__).map_column_labels_df

    globals()["map_column_labels_df"] = _map_column_labels_df_wrapper
    return _map_column_labels_df(*args, **kwargs)


def _find_mixed_secondary_groups_wrapper(*args, **kwargs):
    from importlib import import_module

    _find_mixed_secondary_groups = import_module(".annotations", __name__).find_mixed_secondary_groups

    globals()["find_mixed_secondary_groups"] = _find_mixed_secondary_groups_wrapper
    return _find_mixed_secondary_groups(*args, **kwargs)


def _most_discordant_combinations_wrapper(*args, **kwargs):
    from importlib import import_module

    _most_discordant_combinations = import_module(".annotations", __name__).most_discordant_combinations

    globals()["most_discordant_combinations"] = _most_discordant_combinations_wrapper
    return _most_discordant_combinations(*args, **kwargs)


def _plot_overlap_heatmap_wrapper(*args, **kwargs):
    from importlib import import_module

    _plot_overlap_heatmap = import_module(".annotations", __name__).plot_overlap_heatmap

    globals()["plot_overlap_heatmap"] = _plot_overlap_heatmap_wrapper
    return _plot_overlap_heatmap(*args, **kwargs)


def _merge_channels_rgb_wrapper(*args, **kwargs):
    from .mergeChannelsRGB import mergeChannelsRGB as _merge_channels_rgb

    globals()["mergeChannelsRGB"] = _merge_channels_rgb_wrapper
    return _merge_channels_rgb(*args, **kwargs)


histomap = _histomap_wrapper
umap = _umap_wrapper
pca = _pca_wrapper
leiden = _leiden_wrapper
dbscan = _dbscan_wrapper
save_umap_images = _save_umap_images_wrapper
cluster_similarity = _cluster_similarity_wrapper
merge_categorical_annotations = _merge_categorical_annotations_wrapper
merge_categorical_annotations_df = _merge_categorical_annotations_df_wrapper
reconcile_annotation_sources = _reconcile_annotation_sources_wrapper
reconcile_annotation_sources_df = _reconcile_annotation_sources_df_wrapper
map_column_labels = _map_column_labels_wrapper
map_column_labels_df = _map_column_labels_df_wrapper
find_mixed_secondary_groups = _find_mixed_secondary_groups_wrapper
most_discordant_combinations = _most_discordant_combinations_wrapper
plot_overlap_heatmap = _plot_overlap_heatmap_wrapper
thumbnail_pdf = _thumbnail_pdf_wrapper
mergeChannelsRGB = _merge_channels_rgb_wrapper
