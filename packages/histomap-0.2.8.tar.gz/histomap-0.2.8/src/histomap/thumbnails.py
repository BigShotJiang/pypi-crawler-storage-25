"""
Thumbnail PDF generation for categorical table annotations.
"""
from __future__ import annotations

from pathlib import Path
from typing import Optional
import math

import matplotlib
import numpy as np
import pandas as pd
from tqdm import tqdm

matplotlib.use("Agg")

from matplotlib.colors import to_rgb
from matplotlib import pyplot as plt
from matplotlib.backends.backend_pdf import PdfPages
from matplotlib.path import Path as MplPath
from shapely.geometry import box
from shapely.ops import unary_union

try:
    import spatialdata as sd
    from spatialdata.models import get_table_keys
except Exception:
    sd = None  # type: ignore
    get_table_keys = None  # type: ignore

try:
    import tifffile
except Exception:
    tifffile = None  # type: ignore

from .linkage import (
    ENTITY_ID_COLUMNS,
    IDENTITY_COLUMN_TO_ENTITY,
    TOKEN_CELL_ID_COLUMNS,
    _normalize_id_series,
    get_wsi_path,
)
from .umap import _load_adata


ISO_PAPER_SIZES_MM = {
    "A10": (26, 37),
    "A9": (37, 52),
    "A8": (52, 74),
    "A7": (74, 105),
    "A6": (105, 148),
    "A5": (148, 210),
    "A4": (210, 297),
}


def _candidate_id_columns(entity_kind: str):
    return ENTITY_ID_COLUMNS.get(entity_kind, []) + ["instance_id"]


def _resolve_output_path(source, table: str, column: str, output_path: Optional[str | Path]) -> Path:
    if output_path is not None:
        return Path(output_path)
    if isinstance(source, (str, Path)):
        src = Path(source)
        return src.parent / f"{src.stem}_{table}_{column}.pdf"
    return Path.cwd() / f"histomap_{table}_{column}.pdf"


def _resolve_spatial_output_path(main_output_path: Path) -> Path:
    return main_output_path.with_name(f"{main_output_path.stem}_spatial{main_output_path.suffix}")


def _infer_entity_for_table(table_name: str, adata) -> str:
    if get_table_keys is not None:
        try:
            region, _, _ = get_table_keys(adata)
        except Exception:
            region = None
        else:
            if isinstance(region, str):
                return region
            if isinstance(region, (list, tuple)) and len(region) == 1:
                return str(region[0])
    for col in adata.obs.columns:
        if col in IDENTITY_COLUMN_TO_ENTITY:
            return IDENTITY_COLUMN_TO_ENTITY[col]
    if "_tokens" in table_name:
        return "tokens"
    if "_tiles" in table_name:
        return "tiles"
    if "_mIF_cells" in table_name:
        return "segmentation_mask"
    raise ValueError(f"Could not infer shape layer for table '{table_name}'.")


def _shape_identity_series(shape_df, entity_kind: str) -> pd.Series:
    shp_idx = pd.Index(shape_df.index)
    for col in _candidate_id_columns(entity_kind):
        if col in shape_df.columns:
            return _normalize_id_series(shape_df[col].values, index=shp_idx)
    return _normalize_id_series(shp_idx.values, index=shp_idx)


def _table_shape_ids(adata, entity_kind: str) -> pd.Series:
    row_names = pd.Index(adata.obs_names)
    shape_ids = None
    if get_table_keys is not None:
        try:
            _, region_key, instance_key = get_table_keys(adata)
        except Exception:
            region_key, instance_key = None, None
        else:
            if instance_key and instance_key in adata.obs:
                shape_ids = _normalize_id_series(adata.obs[instance_key].values, index=row_names)
            if region_key and region_key in adata.obs and shape_ids is not None:
                region_vals = adata.obs[region_key].astype(str)
                shape_ids = shape_ids[region_vals == str(entity_kind)]
    if shape_ids is None:
        for col in _candidate_id_columns(entity_kind):
            if col in adata.obs:
                shape_ids = _normalize_id_series(adata.obs[col].values, index=row_names)
                break
    if shape_ids is None:
        shape_ids = _normalize_id_series(row_names.values, index=row_names)
    return shape_ids.dropna()


def _linked_rows_and_shapes(adata, shape_df, *, table_name: str, entity_kind: str):
    row_to_shape_ids = _table_shape_ids(adata, entity_kind)
    shape_identity = _shape_identity_series(shape_df, entity_kind)
    identity_to_shape_row = pd.Series(shape_identity.index, index=shape_identity.values)
    mapped_shape_rows = identity_to_shape_row.reindex(row_to_shape_ids.astype(str))
    linked = pd.DataFrame(
        {
            "row_name": row_to_shape_ids.index.astype(str),
            "shape_id": row_to_shape_ids.astype(str).values,
            "shape_row": mapped_shape_rows.values,
        },
        index=row_to_shape_ids.index,
    )
    linked = linked.dropna(subset=["shape_row"])
    return linked


def _load_image_rgb(image_path: str | Path):
    path = Path(image_path)
    if tifffile is None:
        raise ImportError("tifffile is required to read image crops.")
    with tifffile.TiffFile(str(path)) as tf:
        series = tf.series[0]
        arr = series.asarray(out="memmap")
        axes = getattr(series, "axes", "")
    if axes in {"YXC", "YXS"}:
        return arr
    if axes in {"CYX", "SYX"} and arr.ndim == 3 and arr.shape[0] == 3:
        return np.moveaxis(arr, 0, -1)
    if arr.ndim == 2:
        return np.stack([arr, arr, arr], axis=-1)
    raise ValueError(f"Unsupported image layout for thumbnail cropping: axes={axes!r}, shape={arr.shape!r}")


def _crop_rgb(image, *, center_x: float, center_y: float, crop_size: int):
    h, w = image.shape[:2]
    half = crop_size // 2
    cx = int(round(center_x))
    cy = int(round(center_y))
    x0, x1 = cx - half, cx - half + crop_size
    y0, y1 = cy - half, cy - half + crop_size
    src_x0, src_x1 = max(0, x0), min(w, x1)
    src_y0, src_y1 = max(0, y0), min(h, y1)
    out = np.zeros((crop_size, crop_size, 3), dtype=image.dtype)
    dst_x0 = src_x0 - x0
    dst_y0 = src_y0 - y0
    dst_x1 = dst_x0 + (src_x1 - src_x0)
    dst_y1 = dst_y0 + (src_y1 - src_y0)
    out[dst_y0:dst_y1, dst_x0:dst_x1] = image[src_y0:src_y1, src_x0:src_x1]
    return out, x0, y0


def _prepare_reference_image(image, *, max_dim: int = 2000):
    h, w = image.shape[:2]
    step = max(1, int(math.ceil(max(h, w) / max_dim)))
    if step == 1:
        return np.asarray(image)
    return np.asarray(image[::step, ::step])


def _page_layout(crop_size: int, paper_size: str, dpi: int):
    if paper_size not in ISO_PAPER_SIZES_MM:
        raise ValueError(f"Unsupported paper_size={paper_size!r}. Supported: {sorted(ISO_PAPER_SIZES_MM)}")
    width_mm, height_mm = ISO_PAPER_SIZES_MM[paper_size]
    width_in = width_mm / 25.4
    height_in = height_mm / 25.4
    page_w_px = int(width_in * dpi)
    page_h_px = int(height_in * dpi)
    margin_px = max(8, int(0.05 * min(page_w_px, page_h_px)))
    title_px = max(20, int(0.10 * page_h_px))
    usable_w_px = max(page_w_px - 2 * margin_px, crop_size)
    usable_h_px = max(page_h_px - 2 * margin_px - title_px, crop_size)
    cols = max(1, usable_w_px // crop_size)
    rows = max(1, usable_h_px // crop_size)
    return width_in, height_in, rows, cols, rows * cols, usable_w_px, usable_h_px


def _layout_for_count(n_items: int, paper_size: str, dpi: int):
    width_in, height_in, _, _, _, usable_w_px, usable_h_px = _page_layout(1, paper_size, dpi)
    if n_items <= 0:
        return width_in, height_in, 1, 1
    page_aspect = usable_w_px / usable_h_px
    best = None
    for cols in range(1, n_items + 1):
        rows = math.ceil(n_items / cols)
        cell_w = usable_w_px / cols
        cell_h = usable_h_px / rows
        cell_size = min(cell_w, cell_h)
        grid_aspect_penalty = abs((cols / rows) - page_aspect)
        score = (cell_size, -grid_aspect_penalty)
        if best is None or score > best[0]:
            best = (score, rows, cols)
    assert best is not None
    _, rows, cols = best
    return width_in, height_in, rows, cols


def _draw_context_overlays(
    ax,
    *,
    crop_x0: int,
    crop_y0: int,
    crop_size: int,
    center_shape_row,
    category: str,
    shape_df,
    linked,
    spatial_index,
    merge_connected_context: bool,
    max_context_shapes: int,
    overlay_color,
):
    crop_geom = box(crop_x0, crop_y0, crop_x0 + crop_size, crop_y0 + crop_size)
    candidate_idx = list(spatial_index.intersection(crop_geom.bounds))
    if not candidate_idx:
        return

    candidate_rows = shape_df.index.take(candidate_idx)
    candidate_df = shape_df.loc[candidate_rows]
    candidate_df = candidate_df[candidate_df.geometry.intersects(crop_geom)]
    if candidate_df.empty:
        return

    same_category_rows = pd.Index(linked.index[linked["category"] == category])
    same_category_shape_rows = pd.Index(linked.loc[same_category_rows, "shape_row"])
    context_df = candidate_df.loc[candidate_df.index.intersection(same_category_shape_rows)]
    if context_df.empty:
        return

    # Keep the center outline distinct; draw context separately.
    context_df = context_df.loc[context_df.index != center_shape_row]
    if context_df.empty:
        return
    if len(context_df) > max_context_shapes:
        context_df = context_df.iloc[:max_context_shapes]

    geoms = list(context_df.geometry.values)
    if merge_connected_context:
        merged = unary_union(geoms)
        geoms = [merged] if merged.geom_type == "Polygon" else list(getattr(merged, "geoms", [merged]))

    for geom in geoms:
        if geom is None or geom.is_empty:
            continue
        polys = [geom] if geom.geom_type == "Polygon" else list(getattr(geom, "geoms", []))
        for poly in polys:
            if poly.is_empty:
                continue
            coords = np.asarray(poly.exterior.coords, float)
            clipped = poly.intersection(crop_geom)
            if clipped.is_empty:
                continue
            clipped_polys = [clipped] if clipped.geom_type == "Polygon" else list(getattr(clipped, "geoms", []))
            for clipped_poly in clipped_polys:
                if clipped_poly.is_empty:
                    continue
                clipped_coords = np.asarray(clipped_poly.exterior.coords, float)
                xs = clipped_coords[:, 0] - crop_x0
                ys = clipped_coords[:, 1] - crop_y0
                ax.plot(xs, ys, color=overlay_color, linewidth=0.8, alpha=0.85)


def _highlight_context_region(
    ax,
    *,
    crop_x0: int,
    crop_y0: int,
    crop_size: int,
    center_shape_row,
    category: str,
    shape_df,
    linked,
    spatial_index,
    merge_connected_context: bool,
    max_context_shapes: int,
    focus_mask_opacity: float,
    overlay_rgb,
):
    crop_geom = box(crop_x0, crop_y0, crop_x0 + crop_size, crop_y0 + crop_size)
    candidate_idx = list(spatial_index.intersection(crop_geom.bounds))
    if not candidate_idx:
        return
    candidate_rows = shape_df.index.take(candidate_idx)
    candidate_df = shape_df.loc[candidate_rows]
    candidate_df = candidate_df[candidate_df.geometry.intersects(crop_geom)]
    if candidate_df.empty:
        return

    same_category_rows = pd.Index(linked.index[linked["category"] == category])
    same_category_shape_rows = pd.Index(linked.loc[same_category_rows, "shape_row"])
    focus_df = candidate_df.loc[candidate_df.index.intersection(same_category_shape_rows)]
    if focus_df.empty:
        return

    if len(focus_df) > max_context_shapes:
        focus_df = focus_df.iloc[:max_context_shapes]

    geoms = list(focus_df.geometry.values)
    if merge_connected_context:
        merged = unary_union(geoms)
        geoms = [merged] if merged.geom_type == "Polygon" else list(getattr(merged, "geoms", [merged]))

    yy, xx = np.mgrid[0:crop_size, 0:crop_size]
    pixel_points = np.column_stack((xx.ravel(), yy.ravel()))
    inside = np.zeros(pixel_points.shape[0], dtype=bool)

    for geom in geoms:
        if geom is None or geom.is_empty:
            continue
        clipped = geom.intersection(crop_geom)
        if clipped.is_empty:
            continue
        polys = [clipped] if clipped.geom_type == "Polygon" else list(getattr(clipped, "geoms", []))
        for poly in polys:
            if poly.is_empty:
                continue
            ext = np.asarray(poly.exterior.coords, float)
            ext[:, 0] -= crop_x0
            ext[:, 1] -= crop_y0
            inside |= MplPath(ext).contains_points(pixel_points)

    alpha = np.zeros((crop_size, crop_size), dtype=float)
    alpha.reshape(-1)[inside] = float(focus_mask_opacity)
    highlight = np.empty((crop_size, crop_size, 3), dtype=float)
    highlight[..., 0] = overlay_rgb[0]
    highlight[..., 1] = overlay_rgb[1]
    highlight[..., 2] = overlay_rgb[2]
    ax.imshow(highlight, alpha=alpha)


def _save_spatial_distribution_pdf(
    *,
    image,
    linked: pd.DataFrame,
    categories: list[str],
    out_path: Path,
    paper_size: str,
    dpi: int,
):
    width_mm, height_mm = ISO_PAPER_SIZES_MM[paper_size]
    width_in = width_mm / 25.4
    height_in = height_mm / 25.4

    all_x = linked["cx"].to_numpy(dtype=float)
    all_y = linked["cy"].to_numpy(dtype=float)
    x_min, x_max = float(np.nanmin(all_x)), float(np.nanmax(all_x))
    y_min, y_max = float(np.nanmin(all_y)), float(np.nanmax(all_y))
    pad_x = max((x_max - x_min) * 0.02, 1.0)
    pad_y = max((y_max - y_min) * 0.02, 1.0)

    n_total = len(linked)

    def _auto_point_size(total_n: int) -> float:
        # Use one shared point size for both background and foreground and let
        # layering/color do the emphasis. Size is still adapted to total slide
        # density so very large datasets do not overfill the page.
        if total_n > 5_000_000:
            return 0.03
        elif total_n > 2_000_000:
            return 0.05
        elif total_n > 1_000_000:
            return 0.08
        elif total_n > 500_000:
            return 0.12
        elif total_n > 100_000:
            return 0.22
        return 0.4

    with PdfPages(out_path) as pdf:
        ref_fig, ref_ax = plt.subplots(figsize=(width_in, height_in), dpi=dpi)
        ref_img = _prepare_reference_image(image)
        ref_ax.imshow(ref_img)
        ref_ax.set_title("Reference image", fontsize=10)
        ref_ax.set_xticks([])
        ref_ax.set_yticks([])
        for spine in ref_ax.spines.values():
            spine.set_visible(False)
        ref_fig.tight_layout(pad=0.4)
        pdf.savefig(ref_fig)
        plt.close(ref_fig)

        for category in categories:
            fig, ax = plt.subplots(figsize=(width_in, height_in), dpi=dpi)
            cat_df = linked[linked["category"] == category]
            point_size = _auto_point_size(n_total)
            ax.scatter(
                all_x,
                all_y,
                s=point_size,
                c="#D3D3D3",
                alpha=0.18,
                linewidths=0,
                rasterized=True,
                zorder=1,
            )
            ax.scatter(
                cat_df["cx"].to_numpy(dtype=float),
                cat_df["cy"].to_numpy(dtype=float),
                s=point_size,
                c="#000000",
                alpha=0.9,
                linewidths=0,
                rasterized=True,
                zorder=2,
            )
            ax.set_title(f"Spatial distribution: {category}", fontsize=10)
            ax.set_xlim(x_min - pad_x, x_max + pad_x)
            ax.set_ylim(y_min - pad_y, y_max + pad_y)
            ax.set_aspect("equal", adjustable="box")
            ax.invert_yaxis()
            ax.set_xticks([])
            ax.set_yticks([])
            for spine in ax.spines.values():
                spine.set_visible(False)
            ax.text(
                0.01,
                0.01,
                f"n={len(cat_df):,}",
                transform=ax.transAxes,
                ha="left",
                va="bottom",
                fontsize=8,
                color="#444444",
            )
            fig.tight_layout(pad=0.4)
            pdf.savefig(fig)
            plt.close(fig)


def thumbnail_pdf(
    sda,
    table: str,
    column: str,
    *,
    imagePath: Optional[str] = None,
    crop_size: int = 64,
    paper_size: str = "A4",
    dpi: int = 150,
    max_thumbnails: Optional[int] = None,
    context_same_category: bool = True,
    merge_connected_context: bool = True,
    max_context_shapes: int = 200,
    context_mode: str = "boxes",
    focus_mask_opacity: float = 0.28,
    overlay_color: str = "#FCE83A",
    save_spatial_pdf: bool = True,
    random_state: int = 0,
    output_path: Optional[str | Path] = None,
    show_progress: bool = True,
):
    """
    Generate one PDF page per category in `adata.obs[column]`, filled with image thumbnails.
    """
    if sd is None:
        raise ImportError("spatialdata is required for thumbnail generation.")
    if crop_size <= 0:
        raise ValueError("crop_size must be > 0")
    if context_mode not in {"boxes", "mask"}:
        raise ValueError("context_mode must be either 'boxes' or 'mask'.")
    if not (0.0 <= focus_mask_opacity <= 1.0):
        raise ValueError("focus_mask_opacity must be between 0 and 1.")
    try:
        overlay_rgb = to_rgb(overlay_color)
    except ValueError as exc:
        raise ValueError("overlay_color must be a valid Matplotlib color or hex code, e.g. '#FCE83A'.") from exc

    source = sda
    if isinstance(source, (str, Path)):
        adata, _ = _load_adata(source, table)
        entity_kind = _infer_entity_for_table(table, adata)
        sdata = sd.read_zarr(str(Path(source)))
        shape_df = sdata.shapes[entity_kind]
        image_path = imagePath or get_wsi_path(sdata)
    else:
        if table not in source.tables:
            raise KeyError(f"Table '{table}' not found in provided object.")
        adata = source.tables[table]
        entity_kind = _infer_entity_for_table(table, adata)
        if entity_kind not in source.shapes:
            raise KeyError(f"Shape layer '{entity_kind}' not found for table '{table}'.")
        shape_df = source.shapes[entity_kind]
        image_path = imagePath or get_wsi_path(source)

    if column not in adata.obs:
        raise KeyError(f"obs['{column}'] not found in table '{table}'.")
    if not image_path:
        raise ValueError("Could not determine image path. Please pass imagePath explicitly.")

    image = _load_image_rgb(image_path)
    linked = _linked_rows_and_shapes(adata, shape_df, table_name=table, entity_kind=entity_kind)
    if linked.empty:
        raise ValueError(f"No table rows in '{table}' could be linked to shape layer '{entity_kind}'.")

    values = adata.obs[column].loc[linked.index]
    values = values[~pd.isna(values)]
    if values.empty:
        raise ValueError(f"obs['{column}'] in table '{table}' has no non-null values linked to '{entity_kind}'.")

    linked = linked.loc[values.index].copy()
    linked["category"] = values.astype(str).values
    centroids = shape_df.loc[linked["shape_row"], "geometry"].centroid
    linked["cx"] = centroids.x.to_numpy()
    linked["cy"] = centroids.y.to_numpy()
    spatial_index = shape_df.sindex

    width_in, height_in, rows, cols, per_page, _, _ = _page_layout(crop_size, paper_size, dpi)
    if max_thumbnails is not None:
        if max_thumbnails <= 0:
            raise ValueError("max_thumbnails must be > 0 when provided.")
        per_page = min(per_page, int(max_thumbnails))
    categories = list(pd.Index(linked["category"]).drop_duplicates())
    out_path = _resolve_output_path(source, table, column, output_path)
    spatial_out_path = _resolve_spatial_output_path(out_path)
    out_path.parent.mkdir(parents=True, exist_ok=True)

    rng = np.random.default_rng(random_state)
    progress = tqdm(
        total=len(categories) + 2 + (1 if save_spatial_pdf else 0),
        desc=f"Thumbs:{table}",
        disable=not show_progress,
        unit="step",
        dynamic_ncols=True,
        leave=False,
    )
    progress.set_postfix_str(f"entity={entity_kind}")
    progress.update(1)

    with PdfPages(out_path) as pdf:
        for category in categories:
            cat_df = linked[linked["category"] == category]
            if len(cat_df) > per_page:
                pick = np.sort(rng.choice(len(cat_df), size=per_page, replace=False))
                cat_df = cat_df.iloc[pick]

            page_rows = rows
            page_cols = cols
            if max_thumbnails is not None:
                width_in, height_in, page_rows, page_cols = _layout_for_count(len(cat_df), paper_size, dpi)

            fig, axes = plt.subplots(page_rows, page_cols, figsize=(width_in, height_in), dpi=dpi)
            axes = np.atleast_1d(axes).ravel()
            fig.suptitle(f"Cluster: {category}", fontsize=8)
            for ax, (_, row) in zip(axes, cat_df.iterrows()):
                crop, crop_x0, crop_y0 = _crop_rgb(image, center_x=row["cx"], center_y=row["cy"], crop_size=crop_size)
                ax.imshow(crop)
                if context_same_category:
                    if context_mode == "mask":
                        _highlight_context_region(
                            ax,
                            crop_x0=crop_x0,
                            crop_y0=crop_y0,
                            crop_size=crop_size,
                            center_shape_row=row["shape_row"],
                            category=category,
                            shape_df=shape_df,
                            linked=linked,
                            spatial_index=spatial_index,
                            merge_connected_context=merge_connected_context,
                            max_context_shapes=max_context_shapes,
                            focus_mask_opacity=focus_mask_opacity,
                            overlay_rgb=overlay_rgb,
                        )
                    else:
                        _draw_context_overlays(
                            ax,
                            crop_x0=crop_x0,
                            crop_y0=crop_y0,
                            crop_size=crop_size,
                            center_shape_row=row["shape_row"],
                            category=category,
                            shape_df=shape_df,
                            linked=linked,
                            spatial_index=spatial_index,
                            merge_connected_context=merge_connected_context,
                            max_context_shapes=max_context_shapes,
                            overlay_color=overlay_color,
                        )
                ax.set_axis_off()
            for ax in axes[len(cat_df):]:
                ax.set_axis_off()
            fig.tight_layout(rect=(0, 0, 1, 0.94), pad=0.1)
            pdf.savefig(fig)
            plt.close(fig)
            progress.set_postfix_str(f"category={category}")
            progress.update(1)

    if save_spatial_pdf:
        progress.set_postfix_str("saving spatial pdf")
        _save_spatial_distribution_pdf(
            image=image,
            linked=linked,
            categories=categories,
            out_path=spatial_out_path,
            paper_size=paper_size,
            dpi=dpi,
        )
        progress.update(1)

    progress.set_postfix_str(f"saved={out_path.name}")
    progress.update(1)
    progress.close()
    if show_progress:
        extra = f" spatial_output='{spatial_out_path}'" if save_spatial_pdf else ""
        print(
            f"[histomap.thumbnail_pdf] Done table='{table}' column='{column}' "
            f"pages={len(categories)} output='{out_path}'{extra}"
        )
    return out_path


def main_thumbnail_pdf():
    import argparse

    parser = argparse.ArgumentParser(description="Generate a categorical thumbnail PDF for a SpatialData table column")
    parser.add_argument("input", help="Path to SpatialData .zarr directory")
    parser.add_argument("--table", required=True, help="Table name in sdata.tables to use")
    parser.add_argument("--column", required=True, help="obs column containing the categories to visualize")
    parser.add_argument("--image-path", dest="image_path", default=None, help="Path to the source RGB image")
    parser.add_argument("--crop-size", type=int, default=64, help="Square crop size in pixels")
    parser.add_argument("--paper-size", default="A4", help="ISO paper size, e.g. A4 or A10")
    parser.add_argument("--dpi", type=int, default=150, help="PDF render DPI")
    parser.add_argument("--max-thumbnails", type=int, default=None, help="Maximum thumbnails per category page")
    parser.add_argument("--context-mode", choices=["boxes", "mask"], default="boxes", help="How to emphasize same-category context")
    parser.add_argument("--focus-mask-opacity", type=float, default=0.28, help="In-region highlight opacity when context-mode=mask")
    parser.add_argument("--overlay-color", default="#FCE83A", help="Overlay color as a hex code or Matplotlib color name")
    parser.add_argument("--no-spatial-pdf", dest="save_spatial_pdf", action="store_false", help="Do not generate the companion spatial distribution PDF")
    parser.add_argument("--no-context-same-category", dest="context_same_category", action="store_false", help="Disable same-category context overlay")
    parser.add_argument("--no-merge-connected-context", dest="merge_connected_context", action="store_false", help="Do not merge touching nearby same-category shapes")
    parser.add_argument("--max-context-shapes", type=int, default=200, help="Maximum nearby same-category shapes to consider per thumbnail")
    parser.add_argument("--random-state", type=int, default=0, help="Random seed for thumbnail sampling")
    parser.add_argument("--output-path", default=None, help="Optional PDF output path")
    parser.add_argument("--quiet", action="store_true", help="Disable progress output")
    parser.set_defaults(context_same_category=True, merge_connected_context=True)

    args = parser.parse_args()

    out = thumbnail_pdf(
        sda=args.input,
        table=args.table,
        column=args.column,
        imagePath=args.image_path,
        crop_size=args.crop_size,
        paper_size=args.paper_size,
        dpi=args.dpi,
        max_thumbnails=args.max_thumbnails,
        context_same_category=args.context_same_category,
        merge_connected_context=args.merge_connected_context,
        max_context_shapes=args.max_context_shapes,
        context_mode=args.context_mode,
        focus_mask_opacity=args.focus_mask_opacity,
        overlay_color=args.overlay_color,
        save_spatial_pdf=args.save_spatial_pdf,
        random_state=args.random_state,
        output_path=args.output_path,
        show_progress=not args.quiet,
    )
    print(out)
