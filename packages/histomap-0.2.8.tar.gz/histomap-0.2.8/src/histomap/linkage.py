from __future__ import annotations

from typing import Optional

import numpy as np
import pandas as pd


ENTITY_ID_COLUMNS = {
    "tokens": ["global_token_id", "token_id", "instance_id"],
    "tiles": ["global_patch_id", "patch_id", "instance_id"],
    "segmentation_mask": ["global_cell_id", "cell_id", "CellId", "instance_id"],
    "tissue": ["global_tissue_id", "tissue_id", "instance_id"],
}

IDENTITY_COLUMN_TO_ENTITY = {
    "global_token_id": "tokens",
    "global_patch_id": "tiles",
    "global_cell_id": "segmentation_mask",
    "global_tissue_id": "tissue",
}

TOKEN_CELL_ID_COLUMNS = ["global_cell_id", "cell_index", "cell_id", "CellId", "instance_id"]


def get_wsi_path(obj) -> Optional[str]:
    """Parse the WSI path from SpatialData.__str__ without regex (robust to escaping)."""
    s = str(obj)
    for line in s.splitlines():
        line = line.strip()
        if line.startswith("WSI:"):
            return line.split("WSI:", 1)[1].strip()
    return None


def _normalize_id_series(values, index=None) -> pd.Series:
    """
    Normalize identifier values so int-like floats and ints compare consistently.
    Examples: 3, 3.0, "3", "3.0" -> "3"
    """
    s = pd.Series(values, index=index, dtype=object)
    s = s.where(~pd.isna(s), None)
    numeric = pd.to_numeric(s, errors="coerce")
    out = pd.Series(index=s.index, dtype=object)
    numeric_mask = ~numeric.isna()
    if numeric_mask.any():
        out.loc[numeric_mask] = numeric.loc[numeric_mask].astype(np.int64).astype(str)
    if (~numeric_mask).any():
        out.loc[~numeric_mask] = s.loc[~numeric_mask].astype(str)
    return out.dropna()
