from __future__ import annotations

from pathlib import Path
from typing import ClassVar, List, Literal

from fireredasr2.asr import FireRedAsr2, FireRedAsr2Config
import librosa
import numpy as np
from pydantic import ConfigDict, Field
import torch
from typing_extensions import Self

from fasr.config import Config, registry
from fasr.data import AudioSpan, AudioToken, AudioTokenList
from fasr.model import ASRModel


def _any_tensor_to_numpy(x: np.ndarray | torch.Tensor) -> np.ndarray:
    if isinstance(x, torch.Tensor):
        return x.detach().cpu().float().numpy()
    return np.asarray(x)


def _prepare_firered_wav(
    data: np.ndarray | torch.Tensor, sample_rate: int, target_sr: int = 16000
) -> tuple[int, np.ndarray]:
    x = _any_tensor_to_numpy(data)
    if x.ndim > 1:
        x = np.mean(x, axis=0)
    x = x.flatten()
    if np.issubdtype(x.dtype, np.floating):
        xf = x.astype(np.float32)
    else:
        xf = x.astype(np.float32) / 32768.0
    if sample_rate != target_sr:
        xf = librosa.resample(xf, orig_sr=sample_rate, target_sr=target_sr)
        sample_rate = target_sr
    pcm = (np.clip(xf, -1.0, 1.0) * 32767.0).astype(np.int16)
    return sample_rate, pcm


def _apply_aed_result(span: AudioSpan, row: dict, return_timestamp: bool) -> None:
    """Write FireRed-AED result onto ``span``.

    Populates ``span.raw_text`` with the full decoded string; when the backend
    was asked for token timestamps, also populates ``span.tokens`` with
    per-token :class:`AudioToken` objects whose times are shifted from the
    span-local reference into the enclosing channel's absolute timeline.
    """
    span.raw_text = row.get("text") or ""
    if not return_timestamp or not row.get("timestamp"):
        span.tokens = None
        return
    offset_ms = int(span.start_ms or 0)
    tokens = AudioTokenList()
    for item in row["timestamp"]:
        if len(item) < 3:
            continue
        tok, start_s, end_s = item[0], item[1], item[2]
        tokens.append(
            AudioToken(
                text=str(tok),
                start_ms=int(round(float(start_s) * 1000)) + offset_ms,
                end_ms=int(round(float(end_s) * 1000)) + offset_ms,
            )
        )
    span.tokens = tokens if len(tokens) > 0 else None


def _apply_llm_result(span: AudioSpan, row: dict) -> None:
    span.raw_text = row.get("text") or ""
    span.tokens = None


def _resolve_use_gpu(device: str | None) -> bool:
    if device is not None:
        return device != "cpu"
    return torch.cuda.is_available()


class _FireRedASRBase(ASRModel):
    """Shared FireRedAsr2 batch inference and result assembly."""

    registry_name: ClassVar[str] = ""
    kind: ClassVar[Literal["aed", "llm"]]

    firered: FireRedAsr2 | None = Field(
        default=None,
        exclude=True,
        description="Underlying FireRedAsr2 handle populated by `load_checkpoint`.",
    )
    firered_config: FireRedAsr2Config | None = Field(
        default=None,
        exclude=True,
        description="Decoding configuration handed to FireRedAsr2; excluded from serialization.",
    )

    device: str | None = Field(
        default=None,
        description="Execution device (`'cpu'`, `'cuda'`, or explicit device string). `None` auto-detects via `torch.cuda.is_available()`.",
    )
    beam_size: int = Field(default=3, ge=1, description="Beam search width.")
    decode_max_len: int = Field(
        default=0,
        ge=0,
        description="Maximum decoded length; ``0`` lets the backend pick the default.",
    )

    model_config = ConfigDict(arbitrary_types_allowed=True, validate_assignment=True)

    def transcribe(
        self,
        batch: List[AudioSpan],
        **kwargs,
    ) -> List[AudioSpan]:
        if self.firered is None:
            raise RuntimeError(
                "Model is not initialized, call load_checkpoint() first."
            )
        if not batch:
            return batch
        uttids = [f"utt-{i}" for i in range(len(batch))]
        wav_inputs: list[tuple[int, np.ndarray]] = []
        for span in batch:
            wf = span.waveform
            sr, pcm = _prepare_firered_wav(wf.data, int(wf.sample_rate))
            wav_inputs.append((sr, pcm))
        rows = self.firered.transcribe(uttids, wav_inputs)
        by_utt = {r["uttid"]: r for r in rows}
        assert self.firered_config is not None
        for span, uttid in zip(batch, uttids):
            row = by_utt.get(uttid, {"text": "", "uttid": uttid})
            if self.kind == "aed":
                _apply_aed_result(span, row, self.firered_config.return_timestamp)
            else:
                _apply_llm_result(span, row)
        return batch

    def _resolve_checkpoint(self, checkpoint_dir: str | Path | None) -> Path:
        if checkpoint_dir is None:
            if self.checkpoint is None:
                raise ValueError(
                    "Either `checkpoint_dir` or `self.checkpoint` must be set."
                )
            self.download_checkpoint()
            checkpoint_dir = self.checkpoint_dir
        path = Path(checkpoint_dir)
        if not path.exists():
            raise FileNotFoundError(f"Checkpoint not found: {path}")
        return path

    def get_config(self) -> Config:
        return Config(
            data={
                "asr_model": {
                    "@asr_models": self.registry_name,
                    "checkpoint": self.checkpoint,
                    "endpoint": self.endpoint,
                    "device": self.device,
                    "beam_size": self.beam_size,
                    "decode_max_len": self.decode_max_len,
                }
            }
        )


@registry.asr_models.register("firered")
@registry.asr_models.register("firered_aed")
class FireRedAEDForASR(_FireRedASRBase):
    """FireRed ASR-AED (CTC + Transformer decoding)."""

    registry_name: ClassVar[str] = "firered_aed"
    kind: ClassVar[Literal["aed", "llm"]] = "aed"

    checkpoint: str = "FireRedTeam/FireRedASR2-AED"
    endpoint: str = "modelscope"

    use_half: bool = Field(
        default=True,
        description="Run the AED model in FP16 to save VRAM; disable when numerical stability matters more than throughput.",
    )
    nbest: int = Field(
        default=1, ge=1, description="Number of best hypotheses returned per utterance."
    )
    softmax_smoothing: float = Field(
        default=1.25,
        description="Temperature applied to the softmax output during beam search.",
    )
    aed_length_penalty: float = Field(
        default=0.6, description="Length penalty applied to the AED beam search."
    )
    eos_penalty: float = Field(
        default=1.0, description="End-of-sentence token penalty."
    )
    return_timestamp: bool = Field(
        default=True, description="Whether to request token-level timestamps."
    )
    elm_dir: str = Field(
        default="",
        description="Optional external LM checkpoint directory; empty disables LM fusion.",
    )
    elm_weight: float = Field(
        default=0.0,
        description="Fusion weight for the external LM; ``0.0`` disables it.",
    )

    def load_checkpoint(self, checkpoint_dir: str | Path | None = None) -> Self:
        """Load the FireRed AED checkpoint; falls back to ``self.checkpoint``."""
        path = self._resolve_checkpoint(checkpoint_dir)
        cfg = FireRedAsr2Config(
            use_gpu=_resolve_use_gpu(self.device),
            use_half=self.use_half,
            beam_size=self.beam_size,
            nbest=self.nbest,
            decode_max_len=self.decode_max_len,
            softmax_smoothing=self.softmax_smoothing,
            aed_length_penalty=self.aed_length_penalty,
            eos_penalty=self.eos_penalty,
            return_timestamp=self.return_timestamp,
            decode_min_len=0,
            repetition_penalty=1.0,
            llm_length_penalty=0.0,
            temperature=1.0,
            elm_dir=self.elm_dir,
            elm_weight=self.elm_weight,
        )
        self.firered = FireRedAsr2.from_pretrained("aed", str(path), cfg)
        self.firered_config = cfg
        return self


@registry.asr_models.register("firered_llm")
class FireRedLLMForASR(_FireRedASRBase):
    """FireRed ASR-LLM (speech encoder + LLM decoding)."""

    registry_name: ClassVar[str] = "firered_llm"
    kind: ClassVar[Literal["aed", "llm"]] = "llm"

    checkpoint: str = "FireRedTeam/FireRedASR2-LLM"
    endpoint: str = "modelscope"

    decode_min_len: int = Field(
        default=0, ge=0, description="Minimum decoded length; ``0`` disables the bound."
    )
    repetition_penalty: float = Field(
        default=1.2,
        description="Repetition penalty applied by the LLM; ``>1`` discourages repetition.",
    )
    llm_length_penalty: float = Field(
        default=0.0, description="Length penalty applied to the LLM beam search."
    )
    temperature: float = Field(
        default=1.0, ge=0.0, description="Sampling temperature used during decoding."
    )

    def load_checkpoint(self, checkpoint_dir: str | Path | None = None) -> Self:
        """Load the FireRed LLM checkpoint; falls back to ``self.checkpoint``."""
        path = self._resolve_checkpoint(checkpoint_dir)
        cfg = FireRedAsr2Config(
            use_gpu=_resolve_use_gpu(self.device),
            use_bfloat16=True,
            beam_size=self.beam_size,
            nbest=1,
            decode_max_len=self.decode_max_len,
            softmax_smoothing=1.25,
            aed_length_penalty=0.6,
            eos_penalty=1.0,
            return_timestamp=False,
            decode_min_len=self.decode_min_len,
            repetition_penalty=self.repetition_penalty,
            llm_length_penalty=self.llm_length_penalty,
            temperature=self.temperature,
            elm_dir="",
            elm_weight=0.0,
        )
        self.firered = FireRedAsr2.from_pretrained("llm", str(path), cfg)
        self.firered_config = cfg
        return self
