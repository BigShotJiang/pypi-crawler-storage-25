# -*- coding: utf-8 -*-
"""
@Author: HuangJianYi
@Date: 2021-10-22 13:32:07
@LastEditTime: 2026-04-02 11:14:17
@LastEditors: HuangJianYi
@Description: 
"""
from seven_framework import *
from seven_cloudapp_frame.models.seven_model import InvokeResultData  # ✅ 在文件顶部导入

class ActionHelper:
    """
    :description:执行帮助类 例子：执行多个方法run_func_while([lambda: act_info_model.add_entity(act_info),lambda: act_info_model.get_dict("id>0"),lambda: act_info_model.get_list("id>0")]) 或执行单个方法run_func_while(lambda: act_info_model.add_entity(act_info))
    """
    logger_error = Logger.get_logger_by_name("log_error")

    @classmethod
    def run_action_while(self, action, sleep_time=0.5, is_log=False, error_count_log=100, title=""):
        """
        :description: 无限循环执行动作
        :param action:方法
        :param sleep_time:异常停留时间，单位秒
        :param is_log:是否记录日志
        :param error_count_log:出错多少次记一次日志
        :param title:异常标题
        :return:无返回
        :last_editors: HuangJianYi
        """
        if not action:
            raise ValueError("参数action不能为空")
        if not sleep_time:
            raise ValueError("参数sleep_time不能为空")
        run_count = 0
        while True:
            try:
                if isinstance(action,list):
                    for item in action:
                        item()
                else:
                    action()
                break
            except Exception:
                if is_log == True and (run_count % error_count_log == 0):
                    self.logger_error.error(f"title:{title},ex:{traceback.format_exc()}")
                print(title+":"+traceback.format_exc())
            run_count+=1
            time.sleep(sleep_time)
        return None

    @classmethod
    def run_func_while(self, func, sleep_time=0.5, is_log=False, error_count_log=100, title=""):
        """
        :description: 无限循环执行动作
        :param func:方法
        :param func:异常标题
        :param sleep_time:异常停留时间，单位秒
        :param is_log:是否记录日志
        :param error_count_log:出错多少次记一次日志
        :return:结果数据
        :last_editors: HuangJianYi
        """
        if not func:
            raise ValueError("参数func不能为空")
        if not sleep_time:
            raise ValueError("参数sleep_time不能为空")
        
        func_result = None
        run_count = 0
        while True:
            try:
                if isinstance(func,list):
                    func_result = []
                    for item in func:
                        func_result.append(item())
                    return func_result
                else:
                    func_result = func()
                    return func_result
            except Exception:
                if is_log == True and (run_count % error_count_log == 0):
                    self.logger_error.error(f"title:{title},ex:{traceback.format_exc()}")
                print(title+":"+traceback.format_exc())
            run_count+=1
            time.sleep(sleep_time)

    @classmethod
    def run_action(self, action, sleep_time=0.5, retry_run_count=10, is_log=False, error_count_log=10, title=""):
        """
        :description: 限制次数执行动作
        :param action:方法
        :param sleep_time:异常停留时间，单位秒
        :param retry_run_count:尝试次数
        :param is_log:是否记录日志
        :param error_count_log:出错多少次记一次日志
        :param title:异常标题
        :return:bool
        :last_editors: HuangJianYi
        """
        if not action:
            raise ValueError("参数action不能为空")
        if not sleep_time:
            raise ValueError("参数sleep_time不能为空")
        run_count = 0
        while run_count < retry_run_count:
            try:
                if isinstance(action,list):
                    for item in action:
                        item()
                else:
                    action()
                break
            except Exception:
                if is_log == True and (run_count % error_count_log == 0):
                    self.logger_error.error(f"title:{title},ex:{traceback.format_exc()}")
                print(title+":"+traceback.format_exc())
            run_count+=1
            time.sleep(sleep_time)

    @classmethod
    def run_func(self, func, sleep_time=0.5, retry_run_count=10, is_log=False, error_count_log=10, title=""):
        """
        :description: 限制次数执行动作
        :param action:方法
        :param sleep_time:异常停留时间，单位秒
        :param retry_run_count:尝试次数
        :param is_log:是否记录日志
        :param error_count_log:出错多少次记一次日志
        :param title:异常标题
        :return:结果数据
        :last_editors: HuangJianYi
        """
        if not func:
            raise ValueError("参数func不能为空")
        if not sleep_time:
            raise ValueError("参数sleep_time不能为空")
        
        func_result = None
        run_count = 0
        while run_count < retry_run_count:
            try:
                if isinstance(func,list):
                    func_result = []
                    for item in func:
                        func_result.append(item())
                    return func_result
                else:
                    func_result = func()
                    return func_result
            except Exception:
                if is_log == True and (run_count % error_count_log == 0):
                    self.logger_error.error(f"title:{title},ex:{traceback.format_exc()}")
                print(title+":"+traceback.format_exc())
            run_count += 1
            time.sleep(sleep_time)
        return func_result
    
    @classmethod
    def api_func(self, func, sleep_time=0.5, retry_run_count=10, is_log=False, error_count_log=10, title="", retry_messages=None):
        """
        :description: 请求外部接口，限制次数执行动作
        :param func: 方法
        :param sleep_time: 异常停留时间，单位秒
        :param retry_run_count: 尝试次数
        :param is_log: 是否记录日志
        :param error_count_log: 出错多少次记一次日志
        :param title: 异常标题
        :param retry_messages: 可重试的错误信息列表（None 表示所有错误都可重试）
        :return: 结果数据
        :last_editors: HuangJianYi
        """
        if not func:
            raise ValueError("参数 func 不能为空")
        if not sleep_time:
            raise ValueError("参数 sleep_time 不能为空")
        
        if retry_messages is None:
            retry_messages = []

        func_result = None
        run_count = 0
        error_message = ''
        while run_count < retry_run_count:
            try:
                func_result = func()
                # 处理 InvokeResultData 类型
                if isinstance(func_result, InvokeResultData):
                    if func_result.success:
                        return func_result
                    error_message = func_result.error_code
                # 处理 bool 类型
                elif isinstance(func_result, bool):
                    if func_result:
                        return func_result
                # 其他类型默认返回结果
                else:
                    return func_result
                # 检查是否为不可重试的错误
                if retry_messages and error_message not in retry_messages:
                    return func_result
            except Exception as e:
                error_message = str(e)
                if is_log and (run_count % error_count_log == 0):
                    self.logger_error.error(f"title:{title}, error:{traceback.format_exc()}")
                else:
                    print(f"{title}:{traceback.format_exc()}")
            run_count += 1
            time.sleep(sleep_time)
        return func_result
            