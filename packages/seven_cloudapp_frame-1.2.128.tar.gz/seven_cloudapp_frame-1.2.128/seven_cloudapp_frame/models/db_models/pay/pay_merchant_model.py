# -*- coding: utf-8 -*-
"""
@Author: HuangJianYi
@Date: 2026-02-28 00:00:00
@LastEditTime: 2026-03-10
@LastEditors: HuangJianYi
@Description: 支付商户模型
"""
from seven_framework.mysql import MySQLHelper
from seven_framework.base_model import *
from seven_cloudapp_frame.models.cache_model import *


class PayMerchantModel(CacheModel):
    def __init__(self, db_connect_key='db_cloudapp', sub_table=None, db_transaction=None, context=None, is_auto=False):
        super(PayMerchantModel, self).__init__(PayMerchant, sub_table)
        self.db = MySQLHelper(self.convert_db_config(db_connect_key, is_auto))
        self.db_connect_key = db_connect_key
        self.db_transaction = db_transaction
        self.db.context = context

    #方法扩展请继承此类

class PayMerchant:

    def __init__(self):
        super(PayMerchant, self).__init__()
        self.id = 0  # id
        self.app_id = ""  # 应用标识
        self.app_secret = ""  # 应用秘钥
        self.mch_id = ""  # 商户号
        self.api_key = ""  # API密钥
        self.serial_no = ""  # 证书序号
        self.public_key_id = ""  # 公钥ID
        self.pay_notify_url = ""  # 支付回调地址
        self.refund_notify_url = ""  # 退款回调地址
        self.certificate_url = ""  # 证书地址
        self.private_key_url = ""  # 私钥秘钥地址或秘钥
        self.public_key_url = ""  # 公钥秘钥地址或秘钥
        self.encrypt_type = 0  # 加密方式(0-未知 1-不加密 2-aes )
        self.create_date = "1900-01-01 00:00:00"  # 创建时间
        self.modify_date = "1900-01-01 00:00:00"  # 修改时间

    @classmethod
    def get_field_list(self):
        return ['id', 'app_id', 'app_secret', 'mch_id', 'api_key', 'serial_no', 'public_key_id', 'pay_notify_url', 'refund_notify_url', 'certificate_url', 'private_key_url', 'public_key_url', 'encrypt_type', 'create_date', 'modify_date']

    @classmethod
    def get_primary_key(self):
        return "id"

    def __str__(self):
        return "pay_merchant_tb"
