import unittest
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from trademux.metatrader_client import MTClient


class StubMTClient(MTClient):
    def __init__(self, payload):
        self.payload = payload

    def _make_request(self, method, endpoint, data=None, timeout=None):
        return self.payload


class MTHistoryTests(unittest.TestCase):
    def test_mt4_history_dataframe_preserves_sl_tp_columns(self):
        client = StubMTClient(
            {
                "deals": [
                    {
                        "ticket": 123456789,
                        "symbol": "EURUSD",
                        "type": "BUY",
                        "volume": 0.01,
                        "open_price": 1.10500,
                        "close_price": 1.10750,
                        "sl": 1.10000,
                        "tp": 1.11000,
                        "profit": 25.0,
                        "commission": -0.7,
                        "swap": -0.12,
                        "magic": 0,
                        "comment": "tmx",
                        "open_time": 1705744800,
                        "close_time": 1705831200,
                    }
                ]
            }
        )

        df = client.get_history(as_df=True)

        self.assertIn("sl", df.columns)
        self.assertIn("tp", df.columns)
        self.assertAlmostEqual(float(df.iloc[0]["sl"]), 1.1)
        self.assertAlmostEqual(float(df.iloc[0]["tp"]), 1.11)
        self.assertEqual(df.iloc[0]["status"], "closed")

    def test_mt5_history_dataframe_returns_normalized_trade_rows_with_sl_tp(self):
        client = StubMTClient(
            {
                "deals": [
                    {
                        "ticket": 1001,
                        "position_id": 5001,
                        "order_id": 7001,
                        "symbol": "EURUSD",
                        "type": "BUY",
                        "entry": "ENTRY",
                        "volume": 0.01,
                        "price": 1.10500,
                        "sl": 1.10000,
                        "tp": 1.11000,
                        "profit": 0.0,
                        "commission": -0.35,
                        "swap": 0.0,
                        "comment": "tmx",
                        "magic": 0,
                        "time": 1705744800,
                    },
                    {
                        "ticket": 1002,
                        "position_id": 5001,
                        "order_id": 7002,
                        "symbol": "EURUSD",
                        "type": "BUY",
                        "entry": "EXIT",
                        "volume": 0.01,
                        "price": 1.10750,
                        "sl": 1.10100,
                        "tp": 1.11200,
                        "profit": 25.0,
                        "commission": -0.35,
                        "swap": -0.12,
                        "comment": "tmx",
                        "magic": 0,
                        "time": 1705831200,
                    },
                ]
            }
        )

        df = client.get_history(as_df=True)

        self.assertEqual(len(df), 1)
        self.assertIn("open_ticket", df.columns)
        self.assertIn("close_ticket", df.columns)
        self.assertIn("sl", df.columns)
        self.assertIn("tp", df.columns)
        self.assertEqual(int(df.iloc[0]["open_ticket"]), 1001)
        self.assertEqual(int(df.iloc[0]["close_ticket"]), 1002)
        self.assertAlmostEqual(float(df.iloc[0]["sl"]), 1.101)
        self.assertAlmostEqual(float(df.iloc[0]["tp"]), 1.112)
        self.assertEqual(df.iloc[0]["status"], "closed")

    def test_mt5_history_defaults_sl_tp_to_zero_when_unset(self):
        client = StubMTClient(
            {
                "deals": [
                    {
                        "ticket": 2001,
                        "position_id": 9001,
                        "order_id": 8001,
                        "symbol": "GBPUSD",
                        "type": "SELL",
                        "entry": "ENTRY",
                        "volume": 0.02,
                        "price": 1.25000,
                        "sl": 0.0,
                        "tp": 0.0,
                        "profit": 0.0,
                        "commission": -0.5,
                        "swap": 0.0,
                        "comment": "tmx",
                        "magic": 0,
                        "time": 1705744800,
                    }
                ]
            }
        )

        df = client.get_history(as_df=True)

        self.assertEqual(float(df.iloc[0]["sl"]), 0.0)
        self.assertEqual(float(df.iloc[0]["tp"]), 0.0)
        self.assertEqual(df.iloc[0]["status"], "open")


if __name__ == "__main__":
    unittest.main()
