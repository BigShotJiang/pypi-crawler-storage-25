from __future__ import annotations

import uuid
from datetime import datetime
from typing import Any, Dict, List, Optional, Union

import requests
import pandas as pd


class MTClient:
    """Python client for the TradeMux MT4/5 mux service."""

    def __init__(
        self,
        api_key: str,
        server_url: str = "https://mux.skybluefin.tech",
        timeout: int = 10,
    ) -> None:
        self.server_url = server_url.rstrip("/")
        self.headers = {"Content-Type": "application/json", "X-API-Key": api_key}
        self.timeout = timeout
        self.account_no: Optional[str] = None
        self.platform: Optional[str] = None

        # Use session for connection pooling (reuses TCP connections)
        self.session = requests.Session()
        self.session.headers.update(self.headers)

        # Fetch key info and validate connection
        self._init_connection()

    def _make_request(
        self,
        method: str,
        endpoint: str,
        data: Optional[Dict[str, Any]] = None,
        timeout: Optional[int] = None,
    ) -> Dict[str, Any]:
        url = f"{self.server_url}{endpoint}"
        effective_timeout = timeout if timeout is not None else self.timeout

        try:
            if method.upper() == "GET":
                response = self.session.get(url, timeout=effective_timeout)
            elif method.upper() == "POST":
                response = self.session.post(url, json=data, timeout=effective_timeout)
            else:
                raise ValueError(f"Unsupported HTTP method: {method}")

            response.raise_for_status()
            return response.json()
        except requests.exceptions.Timeout as exc:
            raise RuntimeError(
                f"Request timeout after {effective_timeout} seconds"
            ) from exc
        except requests.exceptions.ConnectionError as exc:
            raise RuntimeError(
                f"Failed to connect to server at {self.server_url}"
            ) from exc
        except requests.exceptions.HTTPError as exc:
            raise RuntimeError(
                f"HTTP error {response.status_code}: {response.text}"
            ) from exc
        except Exception as exc:  # pragma: no cover - fallthrough
            raise RuntimeError(f"Request failed: {exc}") from exc

    def _init_connection(self) -> None:
        """Fetch key info from server and validate connection."""
        try:
            info = self._make_request("GET", "/v1/key-info")
            self.account_no = info.get("account_no")
            self.platform = info.get("platform").upper()
            print(
                f"MTClient to {self.platform} account no. {self.account_no} established"
            )
        except Exception as e:
            raise RuntimeError(f"Failed to initialize MTClient: {e}") from e

    # ==================== SERVER STATUS ====================

    def get_server_status(self) -> Dict[str, Any]:
        return self._make_request("GET", "/")

    def is_connected(self) -> bool:
        try:
            self.get_server_status()
            return True
        except Exception:
            return False

    def get_account_info(self) -> Dict[str, Any]:
        return self._make_request("GET", "/v1/account")

    # ==================== TRADING ORDERS ====================

    def _send_order(
        self,
        symbol: str,
        side: str,
        lots: float,
        order_type: str = "MARKET",
        price: Optional[float] = None,
        sl: Optional[float] = None,
        tp: Optional[float] = None,
        comment: Optional[str] = None,
        expiration: Optional[Union[int, datetime]] = None,
    ) -> Dict[str, Any]:
        order_id = f"{side.lower()}_{datetime.now().strftime('%Y%m%d_%H%M%S')}_{uuid.uuid4().hex[:6]}"

        data: Dict[str, Any] = {
            "id": order_id,
            "symbol": symbol,
            "side": side.upper(),
            "type": order_type.upper(),
            "lots": lots,
        }

        if sl is not None:
            data["sl"] = sl
        if tp is not None:
            data["tp"] = tp
        if order_type.upper() in {"LIMIT", "STOP"} and price is not None:
            data["price"] = price
        if comment is not None:
            data["comment"] = comment
        if expiration is not None:
            if isinstance(expiration, datetime):
                data["expiration"] = int(expiration.timestamp())
            else:
                data["expiration"] = int(expiration)

        return self._make_request("POST", "/v1/order", data)

    def buy_market(
        self,
        symbol: str,
        lots: float,
        sl: Optional[float] = None,
        tp: Optional[float] = None,
        comment: Optional[str] = None,
    ) -> Dict[str, Any]:
        return self._send_order(
            symbol, "BUY", lots, "MARKET", sl=sl, tp=tp, comment=comment
        )

    def sell_market(
        self,
        symbol: str,
        lots: float,
        sl: Optional[float] = None,
        tp: Optional[float] = None,
        comment: Optional[str] = None,
    ) -> Dict[str, Any]:
        return self._send_order(
            symbol, "SELL", lots, "MARKET", sl=sl, tp=tp, comment=comment
        )

    def buy_limit(
        self,
        symbol: str,
        lots: float,
        price: float,
        sl: Optional[float] = None,
        tp: Optional[float] = None,
        comment: Optional[str] = None,
        expiration: Optional[Union[int, datetime]] = None,
    ) -> Dict[str, Any]:
        return self._send_order(
            symbol,
            "BUY",
            lots,
            "LIMIT",
            price,
            sl,
            tp,
            comment=comment,
            expiration=expiration,
        )

    def sell_limit(
        self,
        symbol: str,
        lots: float,
        price: float,
        sl: Optional[float] = None,
        tp: Optional[float] = None,
        comment: Optional[str] = None,
        expiration: Optional[Union[int, datetime]] = None,
    ) -> Dict[str, Any]:
        return self._send_order(
            symbol,
            "SELL",
            lots,
            "LIMIT",
            price,
            sl,
            tp,
            comment=comment,
            expiration=expiration,
        )

    def buy_stop(
        self,
        symbol: str,
        lots: float,
        price: float,
        sl: Optional[float] = None,
        tp: Optional[float] = None,
        comment: Optional[str] = None,
        expiration: Optional[Union[int, datetime]] = None,
    ) -> Dict[str, Any]:
        return self._send_order(
            symbol,
            "BUY",
            lots,
            "STOP",
            price,
            sl,
            tp,
            comment=comment,
            expiration=expiration,
        )

    def sell_stop(
        self,
        symbol: str,
        lots: float,
        price: float,
        sl: Optional[float] = None,
        tp: Optional[float] = None,
        comment: Optional[str] = None,
        expiration: Optional[Union[int, datetime]] = None,
    ) -> Dict[str, Any]:
        return self._send_order(
            symbol,
            "SELL",
            lots,
            "STOP",
            price,
            sl,
            tp,
            comment=comment,
            expiration=expiration,
        )

    def buy_conditional_entry(
        self,
        symbol: str,
        lots: float,
        price: float,
        sl: Optional[float] = None,
        tp: Optional[float] = None,
        comment: Optional[str] = None,
        expiration: Optional[Union[int, datetime]] = None,
    ) -> Dict[str, Any]:
        """Buy if touched order"""
        current_price = self.get_mid(symbol)
        if price is not None and price < current_price:
            return self.buy_limit(
                symbol,
                lots,
                price,
                sl=sl,
                tp=tp,
                comment=comment,
                expiration=expiration,
            )
        if price is not None and price > current_price:
            return self.buy_stop(
                symbol,
                lots,
                price,
                sl=sl,
                tp=tp,
                comment=comment,
                expiration=expiration,
            )
        return self.buy_market(symbol, lots, sl, tp, comment=comment)

    def sell_conditional_entry(
        self,
        symbol: str,
        lots: float,
        price: float | None,
        sl: Optional[float] = None,
        tp: Optional[float] = None,
        comment: Optional[str] = None,
        expiration: Optional[Union[int, datetime]] = None,
    ) -> Dict[str, Any]:
        """Sell if touched order"""
        current_price = self.get_mid(symbol)
        if price is not None and price > current_price:
            return self.sell_limit(
                symbol,
                lots,
                price,
                sl=sl,
                tp=tp,
                comment=comment,
                expiration=expiration,
            )
        if price is not None and price < current_price:
            return self.sell_stop(
                symbol,
                lots,
                price,
                sl=sl,
                tp=tp,
                comment=comment,
                expiration=expiration,
            )
        return self.sell_market(symbol, lots, sl, tp, comment=comment)

    # ==================== MARKET DATA ====================

    def get_price(self, symbol: str) -> Dict[str, Any]:
        data = {"symbol": symbol, "type": "MID"}
        return self._make_request("POST", "/v1/data", data)

    def get_bid(self, symbol: str) -> float:
        return float(self.get_price(symbol)["bid"])

    def get_ask(self, symbol: str) -> float:
        return float(self.get_price(symbol)["ask"])

    def get_mid(self, symbol: str) -> float:
        return float(self.get_price(symbol)["mid"])

    def get_spread(self, symbol: str) -> float:
        prices = self.get_price(symbol)
        return float(prices["ask"] - prices["bid"])

    def get_symbol_specs(self, symbol: str) -> Dict[str, Any]:
        """Get symbol specifications including contract size, digits, spreads, etc."""
        data = {"symbol": symbol}
        specs = self._make_request("POST", "/v1/symbol_specs", data)
        if "contract_size" not in specs and "contractSize" in specs:
            specs["contract_size"] = specs["contractSize"]
        return specs

    def list_tradeable_instruments(self) -> List[Dict[str, Any]]:
        """
        List all tradeable instruments/symbols available in the MT terminal.

        Returns a list of symbols that can be traded on the connected
        MetaTrader terminal.

        Returns:
            List of instrument dictionaries containing symbol name, description,
            contract_size, digits, and other specifications.
        """
        response = self._make_request("GET", "/v1/instruments")
        return response.get("instruments", [])

    def _get_contract_size(self, symbol: str) -> float:
        specs = self.get_symbol_specs(symbol)
        return float(specs.get("contract_size", 1.0))

    def get_ohlc(
        self,
        symbol: str,
        timeframe: str = "1h",
        count: Optional[int] = None,
        start_date: Optional[Union[str, datetime, int]] = None,
        end_date: Optional[Union[str, datetime, int]] = None,
        as_df: bool = False,
    ) -> Union[Dict[str, Any], "pd.DataFrame"]:
        """Fetch OHLC data.

        Modes:
          - count only: latest N bars (max 5000)
          - start_date + end_date: bounded historical window (first MAX_BARS from start_date)
          - start_date only: legacy — first MAX_BARS from start_date toward now; truncated=True if more exist
        """
        def _has_date(value: Optional[Union[str, datetime, int]]) -> bool:
            return value is not None and not (
                isinstance(value, str) and not value.strip()
            )

        def _validate_date_arg(
            name: str, value: Optional[Union[str, datetime, int]]
        ) -> bool:
            if not _has_date(value):
                return False
            if isinstance(value, int) and value <= 0:
                raise ValueError(
                    f"{name} must be a positive unix timestamp when provided as an int"
                )
            if isinstance(value, str) and value.strip().isdigit() and int(value.strip()) <= 0:
                raise ValueError(
                    f"{name} must be a positive unix timestamp when provided as unix seconds"
                )
            return True

        has_count = count is not None
        has_start = _validate_date_arg("start_date", start_date)
        has_end = _validate_date_arg("end_date", end_date)

        if not has_count and not has_start:
            raise ValueError("Provide either 'count' or 'start_date' (with optional 'end_date')")
        if has_count and has_start:
            raise ValueError("Cannot combine 'count' with 'start_date'")
        if has_count and has_end:
            raise ValueError("Cannot combine 'count' with 'end_date'")
        if has_end and not has_start:
            raise ValueError("'end_date' requires 'start_date'")

        data: Dict[str, Any] = {
            "symbol": symbol,
            "timeframe": timeframe,
        }

        if count is not None:
            if count <= 0:
                raise ValueError("count must be positive")
            if count > 5000:
                raise ValueError("count cannot exceed 5000")
            data["count"] = count

        if has_start:
            if isinstance(start_date, datetime):
                data["start_date"] = start_date.isoformat()
            else:
                data["start_date"] = str(start_date)

        if has_end:
            if isinstance(end_date, datetime):
                data["end_date"] = end_date.isoformat()
            else:
                data["end_date"] = str(end_date)

        response = self._make_request("POST", "/v1/ohlc", data)

        if as_df:
            if pd is None:
                raise ImportError(
                    "pandas is required for as_df=True (pip install trademux[pandas])"
                )
            frame = pd.DataFrame(response.get("data", []))
            if not frame.empty:
                frame["time"] = pd.to_datetime(frame["time"], unit="s")
                frame.set_index("time", inplace=True)
                frame.sort_index(ascending=True, inplace=True)
            return frame

        return response

    # ==================== ACCOUNT INFO ====================

    def _get_account(self) -> Dict[str, Any]:
        return self.get_account_info()

    def get_balance(self) -> float:
        return float(self._get_account().get("balance", 0.0))

    def get_equity(self) -> float:
        return float(self._get_account().get("equity", 0.0))

    def get_floating_pnl(self) -> float:
        account = self._get_account()
        return float(account.get("equity", 0.0) - account.get("balance", 0.0))

    # ==================== RISK MANAGEMENT ====================

    def kill_switch(self, timeout: int = 30) -> Dict[str, Any]:
        return self._make_request("POST", "/v1/kill_switch", {}, timeout=timeout)

    def close_symbol(self, symbol: str) -> Dict[str, Any]:
        return self._make_request("POST", "/v1/close_symbol", {"symbol": symbol})

    def list_positions(self) -> Dict[str, Any]:
        return self._make_request("GET", "/v1/positions")

    def close_ticket(self, ticket: int) -> Dict[str, Any]:
        return self._make_request("POST", "/v1/close_ticket", {"ticket": int(ticket)})

    def close_order(self, ticket: int) -> Dict[str, Any]:
        return self.close_ticket(ticket)

    def close_trade(self, ticket: int) -> Dict[str, Any]:
        return self.close_ticket(ticket)

    def close_magic(self, magic: int) -> Dict[str, Any]:
        return self._make_request("POST", "/v1/close_magic", {"magic": int(magic)})

    def close_same_comment(self, comment: str) -> Dict[str, Any]:
        positions = self.list_positions().get("positions", [])
        closed = []
        skipped = []
        for position in positions:
            pos_comment = position.get("comment")
            ticket = position.get("ticket")
            if pos_comment is None or ticket is None:
                skipped.append(position)
                continue
            if pos_comment == comment:
                closed.append(self.close_ticket(int(ticket)))
        return {"closed": closed, "skipped": skipped}

    def get_order_details(self, ticket: int) -> Dict[str, Any]:
        return self._make_request("POST", "/v1/order_details", {"ticket": int(ticket)})

    def get_trade_details(self, ticket: int) -> Dict[str, Any]:
        return self.get_order_details(ticket)

    def modify_order(
        self,
        ticket: int,
        *,
        price: Optional[float] = None,
        sl: Optional[float] = None,
        tp: Optional[float] = None,
        expiration: Optional[Union[int, datetime]] = None,
    ) -> Dict[str, Any]:
        if price is None and sl is None and tp is None and expiration is None:
            raise ValueError("Provide at least one of price, sl, tp, or expiration")

        data: Dict[str, Any] = {"ticket": int(ticket)}

        if price is not None:
            if price <= 0:
                raise ValueError("price must be positive")
            data["price"] = float(price)
        if sl is not None:
            data["sl"] = float(sl)
        if tp is not None:
            data["tp"] = float(tp)
        if expiration is not None:
            if isinstance(expiration, datetime):
                data["expiration"] = int(expiration.timestamp())
            else:
                data["expiration"] = int(expiration)

        return self._make_request("POST", "/v1/modify_order", data)

    def modify_trade(
        self,
        ticket: int,
        *,
        price: Optional[float] = None,
        sl: Optional[float] = None,
        tp: Optional[float] = None,
        expiration: Optional[Union[int, datetime]] = None,
    ) -> Dict[str, Any]:
        return self.modify_order(
            ticket, price=price, sl=sl, tp=tp, expiration=expiration
        )

    def get_history(
        self,
        start_date: Optional[Union[datetime, str, int]] = None,
        as_df: bool = False,
    ) -> Union[Dict[str, Any], "pd.DataFrame"]:
        data: Dict[str, Any] = {}
        if start_date is not None:
            if isinstance(start_date, datetime):
                data["start_date"] = start_date.isoformat()
            else:
                data["start_date"] = str(start_date)

        response = self._make_request("POST", "/v1/history", data or {})
        if not as_df:
            return response

        def _to_utc_timestamp(value: Any) -> "pd.Timestamp":
            if value in (None, ""):
                return pd.NaT
            if isinstance(value, (int, float)) and not isinstance(value, bool):
                return pd.to_datetime(value, unit="s", utc=True, errors="coerce")
            return pd.to_datetime(value, utc=True, errors="coerce")

        def _series_or_default(
            frame: "pd.DataFrame", column: str, default: float = 0.0
        ) -> "pd.Series":
            if column in frame.columns:
                return pd.to_numeric(frame[column], errors="coerce").fillna(default)
            return pd.Series(default, index=frame.index, dtype=float)

        def _first_valid(frame: "pd.DataFrame", column: str) -> Any:
            if column not in frame.columns:
                return None
            valid = frame[column].dropna()
            return valid.iloc[0] if not valid.empty else None

        def _coalesce(*values: Any) -> Any:
            for value in values:
                if value is None:
                    continue
                if isinstance(value, float) and pd.isna(value):
                    continue
                return value
            return None

        def _weighted_avg(
            frame: "pd.DataFrame", price_col: str, volume_col: str
        ) -> Optional[float]:
            if frame.empty or price_col not in frame.columns:
                return None
            prices = pd.to_numeric(frame[price_col], errors="coerce")
            if volume_col in frame.columns:
                volumes = pd.to_numeric(frame[volume_col], errors="coerce")
            else:
                volumes = pd.Series(1.0, index=frame.index, dtype=float)
            valid = prices.notna() & volumes.notna()
            if not valid.any():
                return None
            prices = prices[valid]
            volumes = volumes[valid]
            volume_sum = float(volumes.sum())
            if volume_sum <= 0:
                return float(prices.iloc[-1])
            return float((prices * volumes).sum() / volume_sum)

        def _latest_non_zero(frame: "pd.DataFrame", column: str) -> float:
            if frame.empty or column not in frame.columns:
                return 0.0
            series = pd.to_numeric(frame[column], errors="coerce")
            valid = series[(series.notna()) & (series != 0)]
            if valid.empty:
                return 0.0
            return float(valid.iloc[-1])

        history_rows = response.get("deals") or response.get("history") or []
        deals = response.get("deals") or []
        if not history_rows and not deals:
            return pd.DataFrame()

        deals_df = pd.DataFrame(history_rows or deals)
        if deals_df.empty:
            return deals_df

        is_mt5_history = all(
            column in deals_df.columns for column in ("entry", "position_id", "time")
        )

        if not is_mt5_history:
            if "lots" in deals_df.columns and "volume" not in deals_df.columns:
                deals_df["volume"] = pd.to_numeric(deals_df["lots"], errors="coerce")

            for col in ("open_time", "close_time", "time"):
                if col in deals_df.columns:
                    deals_df[col] = deals_df[col].map(_to_utc_timestamp)

            for col in (
                "open_price",
                "close_price",
                "volume",
                "lots",
                "profit",
                "commission",
                "swap",
                "sl",
                "tp",
            ):
                if col in deals_df.columns:
                    deals_df[col] = pd.to_numeric(deals_df[col], errors="coerce")

            for col in ("ticket", "position_id", "order_id", "magic"):
                if col in deals_df.columns:
                    deals_df[col] = pd.to_numeric(deals_df[col], errors="coerce").astype(
                        "Int64"
                    )

            deals_df["gross_profit"] = _series_or_default(deals_df, "profit")
            deals_df["net_pnl"] = (
                deals_df["gross_profit"]
                + _series_or_default(deals_df, "commission")
                + _series_or_default(deals_df, "swap")
            )

            if "status" not in deals_df.columns:
                if "close_time" in deals_df.columns:
                    deals_df["status"] = (
                        deals_df["close_time"]
                        .notna()
                        .map(lambda closed: "closed" if closed else "open")
                    )
                else:
                    deals_df["status"] = "closed"

            if "position_id" not in deals_df.columns and "ticket" in deals_df.columns:
                deals_df["position_id"] = deals_df["ticket"]

            sort_col = None
            if "open_time" in deals_df.columns:
                sort_col = "open_time"
            elif "time" in deals_df.columns:
                sort_col = "time"
            if sort_col:
                deals_df.sort_values(sort_col, inplace=True)

            return deals_df

        for col in ("volume", "price", "profit", "commission", "swap", "sl", "tp"):
            if col in deals_df.columns:
                deals_df[col] = pd.to_numeric(deals_df[col], errors="coerce")

        for col in ("ticket", "position_id", "order_id", "magic"):
            if col in deals_df.columns:
                deals_df[col] = pd.to_numeric(deals_df[col], errors="coerce").astype(
                    "Int64"
                )

        if "time" in deals_df.columns:
            deals_df["time"] = deals_df["time"].map(_to_utc_timestamp)

        if "type" in deals_df.columns:
            deals_df["type"] = deals_df["type"].astype(str).str.upper()
            deals_df = deals_df[deals_df["type"].isin({"BUY", "SELL"})].copy()

        if "symbol" in deals_df.columns:
            deals_df = deals_df[
                deals_df["symbol"].fillna("").astype(str).str.strip() != ""
            ].copy()

        if "position_id" in deals_df.columns:
            deals_df = deals_df[
                deals_df["position_id"].notna() & (deals_df["position_id"] != 0)
            ].copy()

        if deals_df.empty:
            return deals_df

        if "entry" in deals_df.columns:
            deals_df["entry"] = deals_df["entry"].astype(str).str.upper()
        else:
            deals_df["entry"] = ""

        if "position_id" not in deals_df.columns:
            if "ticket" in deals_df.columns:
                deals_df["position_id"] = deals_df["ticket"]
            else:
                deals_df["position_id"] = deals_df.index.astype(str)

        rows: List[Dict[str, Any]] = []
        grouped = deals_df.groupby("position_id", dropna=False, sort=False)
        for position_id, group in grouped:
            if "time" in group.columns:
                group = group.sort_values("time")

            entries = group[group["entry"] == "ENTRY"]
            exits = group[group["entry"] == "EXIT"]

            entry_volume = float(_series_or_default(entries, "volume").sum())
            exit_volume = float(_series_or_default(exits, "volume").sum())
            remaining_volume = max(entry_volume - exit_volume, 0.0)

            is_closed = entry_volume > 0 and exit_volume >= (entry_volume - 1e-9)
            if entry_volume == 0 and not exits.empty:
                is_closed = True

            exits_desc = exits
            if not exits.empty and "time" in exits.columns:
                exits_desc = exits.sort_values("time", ascending=False)

            row: Dict[str, Any] = {
                "position_id": position_id,
                "symbol": _coalesce(
                    _first_valid(entries, "symbol"), _first_valid(group, "symbol")
                ),
                "side": _coalesce(
                    _first_valid(entries, "type"), _first_valid(group, "type")
                ),
                "status": "closed" if is_closed else "open",
                "open_ticket": _coalesce(
                    _first_valid(entries, "ticket"), _first_valid(group, "ticket")
                ),
                "close_ticket": _first_valid(exits_desc, "ticket"),
                "open_order_id": _first_valid(entries, "order_id"),
                "close_order_id": _first_valid(exits_desc, "order_id"),
                "open_time": (
                    entries["time"].min()
                    if ("time" in entries.columns and not entries.empty)
                    else (group["time"].min() if "time" in group.columns else pd.NaT)
                ),
                "close_time": (
                    exits["time"].max()
                    if ("time" in exits.columns and not exits.empty)
                    else pd.NaT
                ),
                "open_price": _weighted_avg(entries, "price", "volume"),
                "close_price": _weighted_avg(exits, "price", "volume"),
                "entry_volume": entry_volume,
                "exit_volume": exit_volume,
                "remaining_volume": remaining_volume,
                "gross_profit": float(_series_or_default(group, "profit").sum()),
                "commission": float(_series_or_default(group, "commission").sum()),
                "swap": float(_series_or_default(group, "swap").sum()),
                "sl": _coalesce(
                    _latest_non_zero(exits_desc, "sl"),
                    _latest_non_zero(group, "sl"),
                    0.0,
                ),
                "tp": _coalesce(
                    _latest_non_zero(exits_desc, "tp"),
                    _latest_non_zero(group, "tp"),
                    0.0,
                ),
                "comment": _coalesce(
                    _first_valid(entries, "comment"), _first_valid(group, "comment")
                ),
                "magic": _coalesce(
                    _first_valid(entries, "magic"), _first_valid(group, "magic")
                ),
                "entry_deals": int(len(entries)),
                "exit_deals": int(len(exits)),
                "deal_count": int(len(group)),
            }
            row["net_pnl"] = row["gross_profit"] + row["commission"] + row["swap"]
            rows.append(row)

        trades_df = pd.DataFrame(rows)
        for col in (
            "position_id",
            "open_ticket",
            "close_ticket",
            "open_order_id",
            "close_order_id",
            "magic",
            "entry_deals",
            "exit_deals",
            "deal_count",
        ):
            if col in trades_df.columns:
                trades_df[col] = pd.to_numeric(trades_df[col], errors="coerce").astype(
                    "Int64"
                )
        if not trades_df.empty and "open_time" in trades_df.columns:
            trades_df.sort_values("open_time", inplace=True)
        return trades_df

    # ==================== UTILITY METHODS ====================

    def get_conversion_rate(
        self, counter_currency: str, accnt_currency: str = "USD"
    ) -> float:
        """Get conversion rate between two currencies."""
        resp = self.session.get(
            f"https://api.frankfurter.dev/v1/latest?base={counter_currency}&symbols={accnt_currency}",
            timeout=self.timeout,
        ).json()
        rates = resp.get("rates", {})
        if accnt_currency in rates:
            return float(rates[accnt_currency])
        raise RuntimeError(f"Rate not found for {counter_currency} to {accnt_currency}")

    def close(self) -> None:
        """Close the HTTP session and release connections."""
        self.session.close()

    def __enter__(self):
        """Context manager support."""
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager cleanup."""
        self.close()
