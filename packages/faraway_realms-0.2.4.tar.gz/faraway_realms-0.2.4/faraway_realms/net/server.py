"""Asyncio game server: tick loop and per-client reader/writer coroutines."""

from __future__ import annotations

import asyncio
import logging
import statistics
import time
from collections import deque
from typing import TYPE_CHECKING, Any

import numpy as np

from faraway_realms import fov as _fov
from faraway_realms.commands import CommandParser
from faraway_realms.net.protocol import recv_message, send_message
from faraway_realms.net.serialization import (
    collect_entities,
    serialize_per_client,
    serialize_shared,
    serialize_tile_sparse,
)

if TYPE_CHECKING:
    from faraway_realms.game import Game
    from faraway_realms.map import Map
    from faraway_realms.net.serialization import EntitySnapshot

_PLAYER_SIGHT_RANGE: int = 12

_log = logging.getLogger(__name__)
_RECONNECT_GRACE_S: float = 30.0

# Thresholds for immediate warnings.
_WARN_TICK_MS: float = 50.0  # half the 10 Hz budget
_WARN_QUEUE: int = 20  # commands backed up across one inter-tick window


class _ServerMetrics:
    """Rolling tick-time and queue-depth statistics; logs every 10 seconds."""

    _LOG_INTERVAL: float = 10.0
    _WINDOW: int = 100  # ticks kept for rolling stats (~10 s at 10 Hz)

    _WARMUP_S: float = 2.0  # suppress warnings during startup (JIT + coverage overhead)

    def __init__(self) -> None:
        self._times: deque[float] = deque(maxlen=self._WINDOW)
        self._queue_hwm: int = 0
        self._bytes: deque[int] = deque(maxlen=self._WINDOW)
        self._ser_times: deque[float] = deque(maxlen=self._WINDOW)
        self._game_tick_ms: deque[float] = deque(maxlen=self._WINDOW)
        self._fov_ms: deque[float] = deque(maxlen=self._WINDOW)
        self._ser_pc_ms: deque[float] = deque(maxlen=self._WINDOW)
        self._send_ms: deque[float] = deque(maxlen=self._WINDOW)
        self._last_log: float = 0.0
        self._start: float = time.monotonic()

    def record(self, duration: float, queue_size: int, n_clients: int) -> None:
        """Record one tick's timing and queue depth."""
        self._times.append(duration)
        self._queue_hwm = max(self._queue_hwm, queue_size)
        if time.monotonic() - self._start >= self._WARMUP_S:
            self._warn_if_notable(duration, queue_size)
        self._maybe_log(n_clients)

    def record_broadcast(self, total_bytes: int, ser_ms: float) -> None:
        """Record one broadcast's outbound bytes and serialization time."""
        self._bytes.append(total_bytes)
        self._ser_times.append(ser_ms)

    def record_phases(
        self, game_tick_ms: float, fov_ms: float, ser_pc_ms: float, send_ms: float
    ) -> None:
        """Record per-phase timings for the current tick."""
        self._game_tick_ms.append(game_tick_ms)
        self._fov_ms.append(fov_ms)
        self._ser_pc_ms.append(ser_pc_ms)
        self._send_ms.append(send_ms)

    def _warn_if_notable(self, duration: float, queue_size: int) -> None:
        if duration * 1000 >= _WARN_TICK_MS:
            _log.warning(
                "slow tick %.1f ms (queue depth %d)", duration * 1000, queue_size
            )
        elif queue_size >= _WARN_QUEUE:
            _log.warning("command queue depth %d", queue_size)

    def _maybe_log(self, n_clients: int) -> None:
        now = time.monotonic()
        if now - self._last_log < self._LOG_INTERVAL or not self._times:
            return
        self._emit_log(n_clients)
        self._queue_hwm = 0
        self._last_log = now

    def _emit_log(self, n_clients: int) -> None:
        avg_ms = statistics.mean(self._times) * 1000
        max_ms = max(self._times) * 1000
        _log.info(
            "server tick avg=%.1f ms  max=%.1f ms  queue_hwm=%d  clients=%d",
            avg_ms,
            max_ms,
            self._queue_hwm,
            n_clients,
        )
        if self._bytes:
            _log.info(
                "broadcast avg=%.1f KB/tick  ser_shared avg=%.2f ms  max=%.2f ms",
                statistics.mean(self._bytes) / 1024,
                statistics.mean(self._ser_times),
                max(self._ser_times),
            )
        if self._game_tick_ms:
            _log.info(
                "phases avg ms: game_tick=%.2f  fov=%.2f  ser_pc=%.2f  send=%.2f",
                statistics.mean(self._game_tick_ms),
                statistics.mean(self._fov_ms),
                statistics.mean(self._ser_pc_ms),
                statistics.mean(self._send_ms),
            )


class _ClientSession:
    def __init__(self, uuid: str, entity_id: int) -> None:
        self.uuid = uuid
        self.entity_id = entity_id
        self.writer: asyncio.StreamWriter | None = None
        self._disconnected_at: float | None = None
        # Visibility culling state — persists across reconnects
        self.visible_entity_ids: frozenset[int] = frozenset()
        self.explored_tiles: set[tuple[int, int]] = set()

    def attach(self, writer: asyncio.StreamWriter) -> None:
        """Attach a writer and clear the disconnection timestamp."""
        self.writer = writer
        self._disconnected_at = None

    def detach(self) -> None:
        """Mark this session as disconnected."""
        self.writer = None
        self._disconnected_at = asyncio.get_event_loop().time()

    def grace_expired(self, now: float) -> bool:
        """Return True when the reconnection grace period has elapsed."""
        if self._disconnected_at is None:
            return False
        return now - self._disconnected_at > _RECONNECT_GRACE_S


def _fov_visible_tiles(game_map: Map, px: int, py: int) -> frozenset[tuple[int, int]]:
    """Return (x, y) tiles visible from (px, py) within the player sight range."""
    fov = _fov.compute_fov(game_map, px, py, _PLAYER_SIGHT_RANGE)
    ys, xs = np.where(fov)
    return frozenset(zip(xs.tolist(), ys.tolist(), strict=True))


def _update_session_entities(
    session: _ClientSession,
    all_snaps: list[EntitySnapshot],
    visible: frozenset[tuple[int, int]],
) -> frozenset[int]:
    """Update session visibility; return IDs that left FOV since last tick."""
    now_visible = frozenset(
        s.entity_id
        for s in all_snaps
        if (s.x, s.y) in visible or s.entity_id == session.entity_id
    )
    removed = session.visible_entity_ids - now_visible
    session.visible_entity_ids = now_visible
    return removed


class GameServer:
    """Asyncio server that owns the authoritative game tick loop.

    Parameters
    ----------
    game : Game
        The authoritative game state.
    host : str
        Bind address.
    port : int
        Bind port; use ``0`` to let the OS assign a free port.
    max_clients : int
        Maximum simultaneous connected clients.
    """

    def __init__(self, game: Game, host: str, port: int, max_clients: int = 8) -> None:
        self._game = game
        self._host = host
        self._port = port
        self._max_clients = max_clients
        self._sessions: dict[str, _ClientSession] = {}
        self._server: asyncio.Server | None = None

    @property
    def bound_port(self) -> int:
        """Resolved port after binding (useful when ``port=0``)."""
        if self._server is None:
            raise RuntimeError("Server not yet started")
        sock = self._server.sockets[0]
        return int(sock.getsockname()[1])

    async def run(self) -> None:
        """Start the tick loop and serve clients forever."""
        self._server = await asyncio.start_server(
            self._handle_client, self._host, self._port
        )
        asyncio.create_task(self._tick_loop())  # noqa: RUF006
        async with self._server:
            await self._server.serve_forever()

    async def _tick_loop(self) -> None:
        interval = 1.0 / self._game.tick_rate
        metrics = _ServerMetrics()
        next_tick = time.monotonic()
        while True:
            t0 = time.monotonic()
            q = self._game.command_queue_size
            t_game = time.monotonic()
            self._game.tick()
            game_tick_ms = (time.monotonic() - t_game) * 1000
            await self._broadcast_tick(metrics, game_tick_ms)
            self._reap_expired_sessions()
            metrics.record(time.monotonic() - t0, q, self._connected_count())
            next_tick += interval
            delay = next_tick - time.monotonic()
            if delay > 0:
                loop = asyncio.get_event_loop()
                await loop.run_in_executor(None, time.sleep, delay)
            else:
                next_tick = time.monotonic()  # too far behind; resync

    def _connected_count(self) -> int:
        return sum(1 for s in self._sessions.values() if s.writer is not None)

    def _session_visibility(
        self,
        session: _ClientSession,
        all_snaps: list[EntitySnapshot],
    ) -> tuple[frozenset[tuple[int, int]], frozenset[int], frozenset[tuple[int, int]]]:
        """Compute FOV; update session state; return (visible, removed, new_tiles)."""
        try:
            px, py = self._game.game_map.get_entity_position(session.entity_id)
        except KeyError:
            removed = frozenset(session.visible_entity_ids)
            session.visible_entity_ids = frozenset()
            return frozenset(), removed, frozenset()
        visible = _fov_visible_tiles(self._game.game_map, px, py)
        removed = _update_session_entities(session, all_snaps, visible)
        new_tiles = visible - session.explored_tiles
        session.explored_tiles |= visible
        return visible, removed, new_tiles

    async def _broadcast_tick(
        self, metrics: _ServerMetrics, game_tick_ms: float
    ) -> None:
        t0 = time.monotonic()
        shared = serialize_shared(self._game)
        all_snaps = collect_entities(self._game)
        ser_ms = (time.monotonic() - t0) * 1000
        total_bytes = 0
        fov_ms = ser_pc_ms = send_ms = 0.0
        for session in list(self._sessions.values()):
            if session.writer is None:
                continue
            try:
                t = time.monotonic()
                visible, removed, new_tiles = self._session_visibility(
                    session, all_snaps
                )
                fov_ms += (time.monotonic() - t) * 1000
                t = time.monotonic()
                per_client = serialize_per_client(
                    self._game,
                    session.entity_id,
                    all_snaps,
                    visible,
                    removed,
                    new_tiles,
                )
                ser_pc_ms += (time.monotonic() - t) * 1000
                t = time.monotonic()
                total_bytes += await send_message(session.writer, shared | per_client)
                send_ms += (time.monotonic() - t) * 1000
            except OSError, ConnectionResetError:
                session.detach()
        metrics.record_broadcast(total_bytes, ser_ms)
        metrics.record_phases(game_tick_ms, fov_ms, ser_pc_ms, send_ms)

    def _reap_expired_sessions(self) -> None:
        now = asyncio.get_event_loop().time()
        expired = [uuid for uuid, s in self._sessions.items() if s.grace_expired(now)]
        for uuid in expired:
            del self._sessions[uuid]

    async def _handle_client(
        self, reader: asyncio.StreamReader, writer: asyncio.StreamWriter
    ) -> None:
        try:
            await self._run_client(reader, writer)
        except OSError, asyncio.IncompleteReadError, KeyError:
            pass
        finally:
            writer.close()

    def _initial_explored_tiles(self, session: _ClientSession) -> set[tuple[int, int]]:
        """Add the starting FOV to session.explored_tiles; return all explored tiles."""
        try:
            px, py = self._game.game_map.get_entity_position(session.entity_id)
            visible = _fov_visible_tiles(self._game.game_map, px, py)
        except KeyError:
            visible = frozenset()
        session.explored_tiles |= visible
        return session.explored_tiles

    def _build_welcome(
        self, session: _ClientSession, explored: set[tuple[int, int]]
    ) -> dict[str, Any]:
        """Build the welcome message, culling to the client's explored tiles."""
        blood_tiles = {
            f"{x},{y}": {"color": list(t.color), "alpha": t.alpha}
            for (x, y), t in self._game.blood_map.tiles.items()
            if (x, y) in explored
        }
        static_objects = [
            {"x": o.x, "y": o.y, "char": o.char, "fg_color": list(o.fg_color)}
            for o in self._game.static_objects
            if (o.x, o.y) in explored
        ]
        return {
            "type": "welcome",
            "entity_id": session.entity_id,
            "map_width": self._game.game_map.width,
            "map_height": self._game.game_map.height,
            "map_tiles": serialize_tile_sparse(self._game.game_map, explored),
            "blood_tiles": blood_tiles,
            "static_objects": static_objects,
        }

    async def _run_client(
        self, reader: asyncio.StreamReader, writer: asyncio.StreamWriter
    ) -> None:
        auth = await recv_message(reader)
        if auth.get("type") != "auth":
            await send_message(writer, {"type": "error", "message": "expected auth"})
            return
        session = self._auth_session(auth, writer)
        if session is None:
            await send_message(writer, {"type": "error", "message": "server full"})
            return
        explored = self._initial_explored_tiles(session)
        await send_message(writer, self._build_welcome(session, explored))
        await self._recv_loop(reader, session)

    def _auth_session(
        self, auth: dict[str, Any], writer: asyncio.StreamWriter
    ) -> _ClientSession | None:
        uuid = str(auth.get("uuid", ""))
        username = str(auth.get("username", "player"))
        if uuid in self._sessions:
            session = self._sessions[uuid]
            session.attach(writer)
            return session
        return self._create_session(uuid, username, writer)

    def _create_session(
        self, uuid: str, username: str, writer: asyncio.StreamWriter
    ) -> _ClientSession | None:
        entity_id = self._game.player_entity_id(username)
        if entity_id is None:
            return None
        if len(self._sessions) >= self._max_clients:
            return None
        session = _ClientSession(uuid=uuid, entity_id=entity_id)
        session.attach(writer)
        self._sessions[uuid] = session
        return session

    def _handle_command_msg(self, msg: dict[str, Any], parser: Any) -> None:
        raw = str(msg.get("raw", ""))
        if raw:
            self._game.enqueue_command(parser.parse(raw))

    async def _recv_loop(
        self, reader: asyncio.StreamReader, session: _ClientSession
    ) -> None:
        parser = CommandParser()
        try:
            while True:
                msg = await recv_message(reader)
                await self._dispatch_client_msg(msg, parser, session)
        except OSError, asyncio.IncompleteReadError:
            session.detach()

    async def _dispatch_client_msg(
        self,
        msg: dict[str, Any],
        parser: CommandParser,
        session: _ClientSession,
    ) -> None:
        if msg.get("type") == "command":
            self._handle_command_msg(msg, parser)
        elif msg.get("type") == "ping":
            await self._handle_ping(msg, session)

    async def _handle_ping(self, msg: dict[str, Any], session: _ClientSession) -> None:
        if session.writer is not None:
            await send_message(session.writer, {"type": "pong", "t": msg.get("t", 0.0)})
