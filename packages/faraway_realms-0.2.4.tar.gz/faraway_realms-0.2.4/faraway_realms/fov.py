"""Field-of-view helpers — shared between behaviour and targeting systems."""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np
import tcod.map

if TYPE_CHECKING:
    from faraway_realms.entity import GameEntity
    from faraway_realms.map import Map

DEFAULT_SIGHT_RANGE: int = 15


def entity_sight(entity: GameEntity) -> int:
    """Return the effective sight range for *entity*.

    Parameters
    ----------
    entity : GameEntity
        The entity whose ``"sight"`` stat is read.

    Returns
    -------
    int
        ``entity.stats["sight"].value`` if present, else
        :data:`DEFAULT_SIGHT_RANGE`.
    """
    stat = entity.stats.get("sight")
    return stat.value if stat is not None else DEFAULT_SIGHT_RANGE


def build_transparency(game_map: Map) -> np.ndarray:
    """Return a ``(height, width)`` bool array; ``True`` = transparent tile.

    Parameters
    ----------
    game_map : Map
        The map to build the array from.

    Returns
    -------
    np.ndarray
        Boolean array where walkable tiles are ``True``.
    """
    return game_map.transparency_array


def compute_fov(
    game_map: Map,
    origin_x: int,
    origin_y: int,
    radius: int,
) -> np.ndarray:
    """Return a ``(height, width)`` bool array; ``True`` = visible from origin.

    Parameters
    ----------
    game_map : Map
        The map to compute FOV on.
    origin_x : int
        Column of the observer.
    origin_y : int
        Row of the observer.
    radius : int
        Maximum sight radius in tiles.

    Returns
    -------
    np.ndarray
        Boolean array where visible tiles are ``True``.
    """
    transparency = build_transparency(game_map)
    visible = tcod.map.compute_fov(transparency, (origin_y, origin_x), radius=radius)
    ys, xs = np.mgrid[0 : game_map.height, 0 : game_map.width]
    visible &= (xs - origin_x) ** 2 + (ys - origin_y) ** 2 <= radius**2
    return visible
