import asyncio

async def post_process(json):
    pass