import httpx
import asyncio

async def get_process(url, timeout, headers, follow_redirects, retry, retries, session=None):
    url = [url] if isinstance(url, str) else url

    num = 0

    while True:
        try:
            if session is None:
                async with httpx.AsyncClient(timeout=timeout, headers=headers, follow_redirects=follow_redirects) as client:
                    responses = await asyncio.gather(
                        *[client.get(urlu) for urlu in url]
                    )
            
            else:
                responses = await asyncio.gather(
                    *[session.get(urlu) for urlu in url]
                )

            return responses
        except Exception as exc:
            if retry is True:
                if retries == num:
                    raise Exception(f'The connection was attempted {num} times, but there was no response.') from exc

                num += 1
                continue

            raise
