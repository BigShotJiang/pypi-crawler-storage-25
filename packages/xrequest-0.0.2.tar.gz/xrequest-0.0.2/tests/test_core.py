import xrequest
import asyncio
from xrequest.utils import show
from xrequest.utils.base_headers import HEADERS 


async def test():
    '''
    test = await xrequest.get("https://google.com", session=True)
    '''
    l = await xrequest.get(url='https://httpstat.us?utm_source=chatgpt.com', headers=HEADERS['human'], retry=True, retries=20)
    f = l.text

    print(f"{f}")

   
asyncio.run(test())