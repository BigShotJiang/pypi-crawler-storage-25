---
name: "stock-data"
description: "A-share stock market data management and backtesting. Supports data query/update, factor analysis, and multi-engine strategy backtesting."
---

# 股票数据管理与回测 Skill

## 用法

```
python -m claw_quant.cli <command> [options]
```

## 快速开始

```bash
# 启动数据库服务（必须先启动）
python -m claw_quant.cli db start

# 检查系统环境
python -m claw_quant.cli doctor

# 更新股票数据
python -m claw_quant.cli update --codes 000001.SZ --date 2024-06-01

# 查询数据
python -m claw_quant.cli query --code 000001.SZ --start 2024-06-01 --end 2024-06-01
```

## 基础命令

| 命令 | 功能 | 说明 |
|------|------|------|
| `db start` | 启动数据库服务 | 必须先启动，同步等待启动完成 |
| `db stop` | 停止数据库服务 | 优雅停止或强制终止 |
| `db status` | 查看数据库状态 | 检查运行状态和路径信息 |
| `doctor` | 环境诊断 | 检查版本、数据库、QMT、引擎状态 |
| `selftest` | 自动化测试 | 运行完整测试流程 |
| `version` | 查看版本 | 显示当前安装版本 |

## 数据管理

```bash
# 更新数据（从QMT获取）
python -m claw_quant.cli update --codes 000001.SZ --date 2024-06-01

# 批量更新多只股票
python -m claw_quant.cli update --codes 000001.SZ,000002.SZ,000333.SZ

# 查询数据
python -m claw_quant.cli query --code 000001.SZ --start 2024-01-01 --end 2024-06-01

# 批量查询
python -m claw_quant.cli query --codes 000001.SZ,000002.SZ --start 2024-01-01 --end 2024-06-01
```

## 因子管理

```bash
# 列出所有因子
python -m claw_quant.cli factor list

# 查看因子详情（参数、示例）
python -m claw_quant.cli factor info MACD

# 计算因子值
python -m claw_quant.cli factor calc MACD --date 2024-06-01 --codes 000001.SZ

# 计算因子（带参数）
python -m claw_quant.cli factor calc MA_CROSS --date 2024-06-01 --codes 000001.SZ --params "{short_window:10,long_window:30}"

# 因子回测（IC测试）
python -m claw_quant.cli factor backtest MOM_20D --codes 000001.SZ --start 2024-01-01 --end 2024-06-01

# 因子回测（分层收益）
python -m claw_quant.cli factor backtest MOM_20D --codes 000001.SZ --start 2024-01-01 --end 2024-06-01 --method layer
```

**因子分类**（44个因子）：
- **估值类**: PE_TTM, PB, PS, PCF, 股息率, EP, BP, SP
- **质量类**: ROE, ROA, 毛利率, 净利率, 资产负债率, 流动比率
- **成长类**: 营收增长率, 净利润增长率, ROE增长率, 总资产增长率
- **动量类**: MOM_20D/60D/120D, 波动率, Beta, 最大回撤
- **情绪类**: 换手率, PSY心理线, VR成交量比率, OBV能量潮
- **技术类**: MA_CROSS, MACD, RSI, KDJ, 布林带, CCI

## 策略管理

```bash
# 列出所有策略
python -m claw_quant.cli strategy list

# 查看策略详情
python -m claw_quant.cli strategy info CROSS_STRATEGY

# 策略回测（单只股票）
python -m claw_quant.cli strategy backtest CROSS_STRATEGY --codes 000001.SZ --start 2024-01-01 --end 2024-06-01

# 策略回测（多只股票）
python -m claw_quant.cli strategy backtest CROSS_STRATEGY --codes 000001.SZ,000002.SZ,000333.SZ --start 2024-01-01 --end 2024-06-01

# 查看可用回测引擎
python -m claw_quant.cli engines
```

## 动态因子/策略

支持将代码存储在数据库中，运行时动态编译执行。

```bash
# 动态因子管理
python -m claw_quant.cli dynamic-factor list          # 列出所有动态因子
python -m claw_quant.cli dynamic-factor get --code MY_FACTOR    # 查看详情
python -m claw_quant.cli dynamic-factor save --code MY_FACTOR --name "我的因子" --file my_factor.py
python -m claw_quant.cli dynamic-factor delete --code MY_FACTOR

# 动态策略管理
python -m claw_quant.cli dynamic-strategy list        # 列出所有动态策略
python -m claw_quant.cli dynamic-strategy get --code MY_STRATEGY
python -m claw_quant.cli dynamic-strategy save --code MY_STRATEGY --name "我的策略" --file my_strategy.py
python -m claw_quant.cli dynamic-strategy delete --code MY_STRATEGY
```

## 典型工作流程

### 1. 首次使用
```bash
python -m claw_quant.cli db start      # 启动数据库
python -m claw_quant.cli doctor        # 检查环境
python -m claw_quant.cli update --codes 000001.SZ --date 2024-06-01  # 更新数据
```

### 2. 数据查询
```bash
python -m claw_quant.cli query --code 000001.SZ --start 2024-01-01 --end 2024-06-01
```

### 3. 因子研发
```bash
# 查看因子列表和详情
python -m claw_quant.cli factor list
python -m claw_quant.cli factor info MACD

# 计算和回测
python -m claw_quant.cli factor calc MACD --date 2024-06-01 --codes 000001.SZ
python -m claw_quant.cli factor backtest MACD --codes 000001.SZ --start 2024-01-01 --end 2024-06-01
```

### 4. 策略回测
```bash
python -m claw_quant.cli strategy list
python -m claw_quant.cli strategy info CROSS_STRATEGY
python -m claw_quant.cli strategy backtest CROSS_STRATEGY --codes 000001.SZ --start 2024-01-01 --end 2024-06-01
```

## 故障排查

| 问题 | 解决方法 |
|------|----------|
| 查询返回空数据 | 先运行 `update` 更新数据 |
| 更新失败 | 确认QMT已登录且数据已下载 |
| 回测失败 | 确认数据已更新，使用 `--help` 检查参数 |
| 数据库连接失败 | 运行 `db start` 启动服务 |
| 系统环境问题 | 运行 `doctor` 命令诊断 |

## 详细帮助

所有命令都支持 `--help` 查看详细参数：

```bash
python -m claw_quant.cli --help
python -m claw_quant.cli update --help
python -m claw_quant.cli query --help
python -m claw_quant.cli factor --help
python -m claw_quant.cli factor calc --help
python -m claw_quant.cli factor backtest --help
python -m claw_quant.cli strategy --help
python -m claw_quant.cli strategy backtest --help
```
