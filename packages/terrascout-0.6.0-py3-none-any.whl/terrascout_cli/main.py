"""Terrascout CLI — geospatial data scoping from the terminal.

Usage:
    terrascout scope new "Monitor vegetation on a 500ha mine site near Emerald QLD"
    terrascout scope view <scope_id>
    terrascout search providers --resolution 10
    terrascout auth login
"""

from typing import Optional

import typer

from terrascout_cli import __version__
from terrascout_cli.commands import agents, auth, catalog, config, copilot, eodag_cmd, project, scope, search, skills, teams, tools


def _version_callback(value: bool) -> None:
    if value:
        typer.echo(f"terrascout {__version__}")
        raise typer.Exit()


app = typer.Typer(
    name="terrascout",
    help="Terrascout — geospatial data scoping from the terminal.",
    no_args_is_help=True,
    rich_markup_mode="rich",
)


@app.callback()
def main(
    version: Optional[bool] = typer.Option(  # noqa: ARG001
        None, "--version", "-V", callback=_version_callback, is_eager=True,
        help="Show version and exit.",
    ),
) -> None:
    """Terrascout — geospatial data scoping from the terminal."""

app.add_typer(copilot.app, name="copilot", help="GIS Copilot — spatial intelligence chat (ask/chat).")
app.add_typer(scope.app, name="scope", help="Create and view scopes.")
app.add_typer(search.app, name="search", help="Search STAC catalogs and providers.")
app.add_typer(auth.app, name="auth", help="Authentication (login/logout/status).")
app.add_typer(config.app, name="config", help="Configuration management.")
app.add_typer(project.app, name="project", help="Project workspace management.")
app.add_typer(agents.app, name="agents", help="AI agent listing and execution.")
app.add_typer(skills.app, name="skills", help="Skills engine (list/run).")
app.add_typer(catalog.app, name="catalog", help="Data Catalog (list/query/discover).")
app.add_typer(teams.app, name="teams", help="Team management (list/create/invite).")
app.add_typer(tools.app, name="tools", help="MCP tools (list/connect/add/remove).")
app.add_typer(eodag_cmd.app, name="eodag", help="EODAG satellite data search/download (optional).")


@app.command()
def version() -> None:
    """Show CLI version."""
    typer.echo(f"terrascout {__version__}")


@app.command()
def health() -> None:
    """Check API connectivity."""
    from terrascout_cli.client import health as api_health
    from terrascout_cli.output import error, success

    try:
        data = api_health()
        success(f"API healthy — v{data.get('version', '?')} ({data.get('environment', '?')})")
    except Exception as exc:
        error(f"Cannot reach API: {exc}")
        raise typer.Exit(1)


if __name__ == "__main__":
    app()
