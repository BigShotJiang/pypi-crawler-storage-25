"""Rich output helpers — tables, panels, spinners, error display."""

import sys
from typing import Any

from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.text import Text

console = Console()
err_console = Console(stderr=True)


def _check_mark() -> str:
    """Return ✓ if console supports it, otherwise [OK]."""
    try:
        "\u2713".encode(sys.stdout.encoding or "utf-8")
        return "\u2713"
    except (UnicodeEncodeError, LookupError):
        return "[OK]"


def error(msg: str) -> None:
    err_console.print(f"[bold red]Error:[/] {msg}")


def success(msg: str) -> None:
    console.print(f"[bold green]{_check_mark()}[/] {msg}")


def warning(msg: str) -> None:
    console.print(f"[bold yellow]![/] {msg}")


def info(msg: str) -> None:
    console.print(f"[dim]{msg}[/]")


def print_json_panel(data: dict[str, Any], title: str = "") -> None:
    """Print a dict as a formatted panel."""
    import json

    console.print(Panel(json.dumps(data, indent=2, default=str), title=title, border_style="cyan"))


def recommendations_table(recs: list[dict[str, Any]]) -> Table:
    """Build a Rich table for scope recommendations."""
    table = Table(title="Recommendations", border_style="cyan", show_lines=True)
    table.add_column("#", style="dim", width=3)
    table.add_column("Sensor", style="bold white")
    table.add_column("Provider", style="cyan")
    table.add_column("Type", style="dim")
    table.add_column("Resolution", justify="right")
    table.add_column("Fit Score", justify="right")
    table.add_column("Feasibility", justify="center")

    for rec in recs:
        score = rec.get("fit_score", 0)
        score_color = "green" if score >= 0.7 else "yellow" if score >= 0.4 else "red"
        feasibility = rec.get("feasibility_status", "unknown")
        feas_color = "green" if feasibility == "feasible" else "yellow" if feasibility == "conditional" else "red"

        table.add_row(
            str(rec.get("rank", "")),
            rec.get("sensor_name", ""),
            rec.get("provider_name", ""),
            rec.get("sensor_type", ""),
            f"{rec.get('spatial_resolution_m', '?')}m",
            Text(f"{score:.0%}", style=score_color),
            Text(feasibility, style=feas_color),
        )
    return table


def providers_table(providers: list[dict[str, Any]]) -> Table:
    """Build a Rich table for provider listing."""
    table = Table(title="Providers", border_style="cyan", show_lines=True)
    table.add_column("Name", style="bold white")
    table.add_column("Short", style="cyan")
    table.add_column("Type", style="dim")
    table.add_column("Sensors", justify="right")
    table.add_column("Free", justify="center")

    for p in providers:
        sensors = p.get("sensors", [])
        is_free = all(s.get("is_free", True) for s in sensors) if sensors else True
        table.add_row(
            p.get("name", ""),
            p.get("short_name", ""),
            p.get("provider_type", ""),
            str(len(sensors)),
            "[green]Yes[/]" if is_free else "[yellow]Paid[/]",
        )
    return table


def parsed_brief_panel(parsed: dict[str, Any]) -> Panel:
    """Format a parsed brief as a Rich panel."""
    lines = []
    if parsed.get("objective"):
        lines.append(f"[bold]Objective:[/] {parsed['objective']}")
    if parsed.get("aoi_description"):
        lines.append(f"[bold]AOI:[/] {parsed['aoi_description']}")
    if parsed.get("min_resolution_m"):
        lines.append(f"[bold]Resolution:[/] {parsed['min_resolution_m']}m")
    if parsed.get("temporal_frequency"):
        lines.append(f"[bold]Frequency:[/] {parsed['temporal_frequency']}")
    if parsed.get("budget_aud"):
        lines.append(f"[bold]Budget:[/] ${parsed['budget_aud']:,.0f} AUD")
    if parsed.get("timeframe_months"):
        lines.append(f"[bold]Timeframe:[/] {parsed['timeframe_months']} months")

    method = parsed.get("parse_method", "unknown")
    conf = parsed.get("overall_confidence", 0)
    conf_color = "green" if conf >= 0.7 else "yellow" if conf >= 0.4 else "red"
    lines.append(f"[dim]Parse method:[/] {method} | [dim]Confidence:[/] [{conf_color}]{conf:.0%}[/]")

    return Panel("\n".join(lines) or "[dim]No details parsed[/]", title="Parsed Brief", border_style="blue")


def agents_table(agents: list[dict[str, Any]]) -> Table:
    """Build a Rich table for agent listing."""
    table = Table(title="AI Agents", border_style="cyan", show_lines=True)
    table.add_column("Slug", style="bold white")
    table.add_column("Name", style="cyan")
    table.add_column("Description")
    table.add_column("Tier", justify="center")

    for a in agents:
        tier = a.get("min_tier", "free")
        tier_color = "green" if tier == "free" else "yellow" if tier == "pro" else "red"
        table.add_row(
            a.get("slug", ""),
            a.get("name", ""),
            a.get("description", "")[:60],
            Text(tier, style=tier_color),
        )
    return table


def stac_results_table(scenes: list[dict[str, Any]]) -> Table:
    """Build a Rich table for STAC search results."""
    table = Table(title="STAC Scenes", border_style="cyan", show_lines=True)
    table.add_column("ID", style="bold white", max_width=40)
    table.add_column("Date", style="cyan")
    table.add_column("Cloud %", justify="right")
    table.add_column("Thumbnail", style="dim", max_width=50)

    for s in scenes:
        cloud = s.get("cloud_cover_pct")
        cloud_str = f"{cloud:.0f}%" if cloud is not None else "—"
        table.add_row(
            s.get("scene_id", "")[:40],
            s.get("acquisition_date", ""),
            cloud_str,
            (s.get("thumbnail_url") or "—")[:50],
        )
    return table
