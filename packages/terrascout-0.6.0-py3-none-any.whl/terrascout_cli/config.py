"""Configuration management — reads/writes ~/.terrascout/config.yaml."""

from pathlib import Path
from typing import Any

import yaml

CONFIG_DIR = Path.home() / ".terrascout"
CONFIG_FILE = CONFIG_DIR / "config.yaml"

DEFAULT_CONFIG = {
    "api_url": "https://terrascout.app",
    "token": None,
}


def _ensure_dir() -> None:
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)


def load_config() -> dict[str, Any]:
    """Load config from disk, returning defaults if file missing."""
    if not CONFIG_FILE.exists():
        return dict(DEFAULT_CONFIG)
    with open(CONFIG_FILE, encoding="utf-8") as f:
        data = yaml.safe_load(f) or {}
    merged = dict(DEFAULT_CONFIG)
    merged.update(data)
    return merged


def save_config(cfg: dict[str, Any]) -> None:
    """Persist config to disk."""
    _ensure_dir()
    with open(CONFIG_FILE, "w", encoding="utf-8") as f:
        yaml.dump(cfg, f, default_flow_style=False, sort_keys=False)


def get_api_url() -> str:
    return load_config()["api_url"]


def get_token() -> str | None:
    return load_config().get("token")


def set_token(token: str | None) -> None:
    cfg = load_config()
    cfg["token"] = token
    save_config(cfg)
