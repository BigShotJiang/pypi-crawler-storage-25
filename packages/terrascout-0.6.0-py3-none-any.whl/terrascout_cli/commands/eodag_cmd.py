"""EODAG commands — unified satellite data search and download via EODAG.

EODAG (Earth Observation Data Access Gateway) provides access to 50+ satellite
data providers through a single API. It is an optional dependency — install
with: pip install eodag
"""

from typing import Optional

import typer
from rich.panel import Panel
from rich.table import Table

from terrascout_cli import output

app = typer.Typer(no_args_is_help=True)

_INSTALL_HINT = (
    "EODAG is not installed. Install it with:\n\n"
    "  pip install eodag\n\n"
    "EODAG provides unified access to 50+ satellite data providers."
)


def _require_eodag():
    """Import and return EODataAccessGateway, or exit with a helpful message."""
    try:
        from eodag import EODataAccessGateway  # type: ignore[import-untyped]
        return EODataAccessGateway
    except ImportError:
        output.error(_INSTALL_HINT)
        raise typer.Exit(1)


def _parse_bbox(raw: str) -> list[float]:
    """Parse a comma-separated bbox string into [west, south, east, north]."""
    parts = raw.split(",")
    if len(parts) != 4:
        raise typer.BadParameter(f"bbox must have 4 values (w,s,e,n), got {len(parts)}")
    try:
        return [float(p.strip()) for p in parts]
    except ValueError as exc:
        raise typer.BadParameter(f"bbox values must be numeric: {exc}") from exc


@app.command("search")
def eodag_search(
    product: str = typer.Option(
        "S2_MSI_L2A",
        "--product", "-p",
        help="EODAG product type (e.g. S2_MSI_L2A, S1_SAR_GRD, L8_OLI_TIRS_C2L2).",
    ),
    bbox: str = typer.Option(
        ...,
        "--bbox", "-b",
        help="Bounding box as west,south,east,north (decimal degrees).",
    ),
    start: str = typer.Option(
        ...,
        "--start", "-s",
        help="Start date (YYYY-MM-DD).",
    ),
    end: str = typer.Option(
        ...,
        "--end", "-e",
        help="End date (YYYY-MM-DD).",
    ),
    cloud_cover: int = typer.Option(
        30,
        "--cloud-cover", "-c",
        help="Maximum cloud cover percentage (0-100).",
    ),
    provider: Optional[str] = typer.Option(
        None,
        "--provider",
        help="Preferred EODAG provider (e.g. cop_dataspace, usgs, aws_eos).",
    ),
    limit: int = typer.Option(
        10,
        "--limit", "-l",
        help="Maximum number of results to return.",
    ),
) -> None:
    """Search satellite imagery via EODAG (50+ providers)."""
    EODataAccessGateway = _require_eodag()

    try:
        bbox_list = _parse_bbox(bbox)
    except typer.BadParameter as exc:
        output.error(str(exc))
        raise typer.Exit(1) from exc

    dag = EODataAccessGateway()

    if provider:
        dag.set_preferred_provider(provider)

    output.info(f"Searching {product} in [{bbox}] from {start} to {end} (max cloud {cloud_cover}%)...")

    try:
        results = dag.search(
            productType=product,
            geom={"lonmin": bbox_list[0], "latmin": bbox_list[1], "lonmax": bbox_list[2], "latmax": bbox_list[3]},
            start=start,
            end=end,
            cloudCover=cloud_cover,
            items_per_page=limit,
        )
    except Exception as exc:
        output.error(f"EODAG search failed: {exc}")
        raise typer.Exit(1) from exc

    if not results:
        output.warning("No products found matching the search criteria.")
        return

    table = Table(title=f"EODAG Results: {product}", border_style="cyan", show_lines=True)
    table.add_column("ID", style="bold white", max_width=50)
    table.add_column("Date", style="cyan")
    table.add_column("Provider", style="dim")
    table.add_column("Cloud %", justify="right")
    table.add_column("Size", justify="right")

    for item in results:
        props = item.properties
        item_id = str(getattr(item, "id", ""))[:50]
        acq_date = str(props.get("startTimeFromAscendingNode", props.get("datetime", "")))[:10]
        prov = str(props.get("provider", getattr(item, "provider", "")))
        cloud = props.get("cloudCover", None)
        cloud_str = f"{cloud:.0f}%" if cloud is not None else "-"
        size_mb = props.get("downloadSize", None)
        size_str = f"{size_mb:.0f} MB" if size_mb is not None else "-"

        table.add_row(item_id, acq_date, prov, cloud_str, size_str)

    output.console.print(table)
    output.success(f"Found {len(results)} product(s)")


@app.command("providers")
def eodag_providers(
    product: Optional[str] = typer.Option(
        None,
        "--product", "-p",
        help="Filter providers by product type support.",
    ),
) -> None:
    """List available EODAG providers."""
    EODataAccessGateway = _require_eodag()
    dag = EODataAccessGateway()

    try:
        if product:
            providers = dag.available_providers(product)
        else:
            providers = dag.available_providers()
    except Exception as exc:
        output.error(f"Failed to list providers: {exc}")
        raise typer.Exit(1) from exc

    if not providers:
        output.warning("No providers found.")
        return

    table = Table(title="EODAG Providers", border_style="cyan", show_lines=True)
    table.add_column("#", style="dim", width=4)
    table.add_column("Provider", style="bold white")

    for i, prov in enumerate(sorted(providers), 1):
        table.add_row(str(i), str(prov))

    output.console.print(table)
    output.success(f"{len(providers)} provider(s) available")


@app.command("products")
def eodag_products(
    provider: Optional[str] = typer.Option(
        None,
        "--provider", "-p",
        help="Filter by provider name.",
    ),
) -> None:
    """List available EODAG product types."""
    EODataAccessGateway = _require_eodag()
    dag = EODataAccessGateway()

    try:
        product_types = dag.list_product_types(provider=provider)
    except Exception as exc:
        output.error(f"Failed to list products: {exc}")
        raise typer.Exit(1) from exc

    if not product_types:
        output.warning("No product types found.")
        return

    table = Table(title="EODAG Product Types", border_style="cyan", show_lines=True)
    table.add_column("ID", style="bold white", max_width=30)
    table.add_column("Title", max_width=50)
    table.add_column("Abstract", style="dim", max_width=60)

    for pt in product_types:
        pt_id = pt.get("ID", "")
        title = pt.get("title", "")[:50]
        abstract = pt.get("abstract", "")[:60]
        table.add_row(pt_id, title, abstract)

    output.console.print(table)
    output.success(f"{len(product_types)} product type(s) available")


@app.command("download")
def eodag_download(
    product_type: str = typer.Option(
        ...,
        "--product", "-p",
        help="EODAG product type (e.g. S2_MSI_L2A).",
    ),
    product_id: str = typer.Argument(help="Product ID to download (from search results)."),
    output_dir: str = typer.Option(
        ".",
        "--output", "-o",
        help="Output directory for downloaded files.",
    ),
    provider: Optional[str] = typer.Option(
        None,
        "--provider",
        help="Preferred provider for download.",
    ),
) -> None:
    """Download a satellite product by ID via EODAG."""
    EODataAccessGateway = _require_eodag()
    dag = EODataAccessGateway()

    if provider:
        dag.set_preferred_provider(provider)

    output.info(f"Searching for product '{product_id}'...")

    try:
        results = dag.search(
            productType=product_type,
            id=product_id,
        )
    except Exception as exc:
        output.error(f"EODAG search failed: {exc}")
        raise typer.Exit(1) from exc

    if not results:
        output.error(f"Product '{product_id}' not found.")
        raise typer.Exit(1)

    product = results[0]
    output.info(f"Downloading {product.properties.get('title', product_id)} to {output_dir}...")

    try:
        path = dag.download(product, outputs_prefix=output_dir)
        output.success(f"Downloaded to: {path}")
    except Exception as exc:
        output.error(f"Download failed: {exc}")
        raise typer.Exit(1) from exc
