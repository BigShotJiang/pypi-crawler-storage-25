"""Catalog commands — list, query, and discover data sources via the Terrascout API."""

import json

import typer
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn
from rich.table import Table

from terrascout_cli import client, output

app = typer.Typer(no_args_is_help=True)


def _parse_bbox(raw: str) -> list[float]:
    """Parse a comma-separated bbox string into [west, south, east, north]."""
    parts = raw.split(",")
    if len(parts) != 4:
        raise typer.BadParameter(f"bbox must have 4 values (w,s,e,n), got {len(parts)}")
    try:
        return [float(p.strip()) for p in parts]
    except ValueError as exc:
        raise typer.BadParameter(f"bbox values must be numeric: {exc}") from exc


@app.command("list")
def catalog_list(
    category: str = typer.Option(None, "--category", "-c", help="Filter by category"),
    tier: str = typer.Option(None, "--tier", "-t", help="Filter by tier"),
) -> None:
    """List available data catalog sources."""
    params = {}
    if category:
        params["category"] = category
    if tier:
        params["tier"] = tier

    with Progress(
        SpinnerColumn(),
        TextColumn("[bold cyan]Loading catalog sources..."),
        transient=True,
        console=output.console,
    ):
        resp = client.get("/catalog", params=params)

    if resp.status_code == 404:
        output.warning("Catalog not yet deployed.")
        return
    if resp.status_code != 200:
        output.error(f"API error {resp.status_code}: {resp.text[:200]}")
        raise typer.Exit(1)

    sources = resp.json()
    if not isinstance(sources, list):
        sources = sources.get("sources", [])

    if not sources:
        output.warning("No sources match the given filters.")
        return

    table = Table(title="Data Catalog", border_style="cyan", show_lines=True)
    table.add_column("Name", style="bold white")
    table.add_column("Category", style="cyan")
    table.add_column("Fetch Mode", style="dim")
    table.add_column("Description")
    table.add_column("Tier", justify="center")

    for s in sources:
        table.add_row(
            s.get("name", ""),
            s.get("category", ""),
            s.get("fetch_mode", ""),
            s.get("description", "")[:50],
            s.get("tier", "free"),
        )

    output.console.print(table)


@app.command("query")
def catalog_query(
    source_id: str = typer.Argument(help="Data source ID (e.g. usgs-earthquakes)"),
    bbox: str = typer.Option(..., "--bbox", "-b", help="Bounding box as w,s,e,n"),
    time_start: str = typer.Option(None, "--time-start", help="Start time (ISO 8601)"),
    time_end: str = typer.Option(None, "--time-end", help="End time (ISO 8601)"),
) -> None:
    """Query a single catalog source by bounding box."""
    try:
        bbox_list = _parse_bbox(bbox)
    except typer.BadParameter as exc:
        output.error(str(exc))
        raise typer.Exit(1) from exc

    body: dict = {"bbox": bbox_list}
    if time_start:
        body["time_start"] = time_start
    if time_end:
        body["time_end"] = time_end

    with Progress(
        SpinnerColumn(),
        TextColumn(f"[bold cyan]Querying '{source_id}'..."),
        transient=True,
        console=output.console,
    ):
        resp = client.post(f"/catalog/{source_id}/query", json=body)

    if resp.status_code == 404:
        output.error(f"Source '{source_id}' not found.")
        raise typer.Exit(1)
    if resp.status_code != 200:
        output.error(f"API error {resp.status_code}: {resp.text[:200]}")
        raise typer.Exit(1)

    data = resp.json()
    status = data.get("status", "ok")
    status_display = "[green]ok[/green]" if status == "ok" else "[red]error[/red]"
    count = data.get("count", 0)
    fetched_at = data.get("fetched_at", "")

    content = (
        f"[bold]Source:[/bold] {data.get('source_id', source_id)}\n"
        f"[bold]Status:[/bold] {status_display}\n"
        f"[bold]Count:[/bold] {count}\n"
        f"[bold]Fetched:[/bold] {fetched_at}"
    )

    # Show first feature's property keys if features exist
    geojson = data.get("geojson")
    if geojson and isinstance(geojson, dict):
        features = geojson.get("features", [])
        if features:
            content += f"\n\n[dim]{len(features)} features returned[/dim]"
            first_props = features[0].get("properties", {})
            if first_props:
                keys = ", ".join(sorted(first_props.keys())[:10])
                content += f"\n[dim]Property keys: {keys}[/dim]"

    border = "green" if status == "ok" else "red"
    output.console.print(Panel(content, title=f"Query: {source_id}", border_style=border))


@app.command("discover")
def catalog_discover(
    bbox: str = typer.Option(..., "--bbox", "-b", help="Bounding box as w,s,e,n"),
    categories: str = typer.Option(None, "--categories", "-c", help="Comma-separated categories"),
    time_start: str = typer.Option(None, "--time-start", help="Start time (ISO 8601)"),
    time_end: str = typer.Option(None, "--time-end", help="End time (ISO 8601)"),
) -> None:
    """Discover data from multiple sources for an area of interest."""
    try:
        bbox_list = _parse_bbox(bbox)
    except typer.BadParameter as exc:
        output.error(str(exc))
        raise typer.Exit(1) from exc

    body: dict = {"bbox": bbox_list}
    if categories:
        body["categories"] = [c.strip() for c in categories.split(",")]
    if time_start:
        body["time_start"] = time_start
    if time_end:
        body["time_end"] = time_end

    with Progress(
        SpinnerColumn(),
        TextColumn("[bold cyan]Discovering data sources..."),
        transient=True,
        console=output.console,
    ):
        resp = client.post("/catalog/discover", json=body)

    if resp.status_code != 200:
        output.error(f"API error {resp.status_code}: {resp.text[:200]}")
        raise typer.Exit(1)

    data = resp.json()
    total = data.get("total_features", 0)
    elapsed = data.get("elapsed_ms", 0)

    output.console.print(Panel(
        f"[bold]Total features:[/bold] {total}\n"
        f"[bold]Elapsed:[/bold] {elapsed}ms",
        title="Discovery Summary",
        border_style="cyan",
    ))

    results = data.get("results", {})
    if results:
        table = Table(title="Sources", border_style="cyan", show_lines=True)
        table.add_column("Name", style="bold white")
        table.add_column("Status", justify="center")
        table.add_column("Count", justify="right")
        table.add_column("Error", style="dim")

        for name, result in results.items():
            status = result.get("status", "ok")
            status_display = "[green]ok[/green]" if status == "ok" else "[red]error[/red]"
            err = result.get("error") or ""
            table.add_row(
                name,
                status_display,
                str(result.get("count", 0)),
                err[:40],
            )

        output.console.print(table)
