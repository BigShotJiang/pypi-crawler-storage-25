"""Config commands — show, set."""

import typer
from rich.table import Table

from terrascout_cli import output
from terrascout_cli.config import CONFIG_FILE, load_config, save_config

app = typer.Typer(no_args_is_help=True)


@app.command("show")
def config_show() -> None:
    """Display current configuration."""
    cfg = load_config()

    table = Table(title=f"Config ({CONFIG_FILE})", border_style="cyan")
    table.add_column("Key", style="bold white")
    table.add_column("Value", style="cyan")

    for key, value in cfg.items():
        display = str(value) if value is not None else "[dim]not set[/]"
        if key == "token" and value:
            display = f"{value[:20]}..." if len(value) > 20 else value
        table.add_row(key, display)

    output.console.print(table)


@app.command("set")
def config_set(
    key: str = typer.Argument(help="Config key (e.g. api_url)"),
    value: str = typer.Argument(help="New value"),
) -> None:
    """Set a configuration value."""
    cfg = load_config()

    valid_keys = {"api_url", "token"}
    if key not in valid_keys:
        output.error(f"Unknown key '{key}'. Valid keys: {', '.join(sorted(valid_keys))}")
        raise typer.Exit(1)

    cfg[key] = value
    save_config(cfg)
    output.success(f"Set [bold]{key}[/] = {value}")
