"""MCP tools commands — list, add, remove, test external MCP servers."""

from typing import Optional

import typer
from rich.progress import Progress, SpinnerColumn, TextColumn
from rich.table import Table

from terrascout_cli import client, output

app = typer.Typer(no_args_is_help=True)


def _check_error(resp):
    if resp.status_code == 401:
        output.error("Authentication required. Run [bold]terrascout auth login[/].")
        raise typer.Exit(1)
    if resp.status_code not in (200, 201):
        output.error(f"API error {resp.status_code}: {resp.text[:200]}")
        raise typer.Exit(1)


@app.command("list")
def tools_list() -> None:
    """List all available MCP tools from connected servers."""
    with Progress(
        SpinnerColumn(),
        TextColumn("[bold cyan]Loading tools..."),
        transient=True,
        console=output.console,
    ):
        resp = client.get("/mcp-servers/tools")

    _check_error(resp)
    data = resp.json()
    tools = data.get("tools", [])

    if not tools:
        output.warning("No MCP tools available. Connect a server first with [bold]terrascout tools connect[/].")
        return

    table = Table(title=f"MCP Tools ({len(tools)})", border_style="cyan", show_lines=True)
    table.add_column("Tool", style="bold white")
    table.add_column("Server", style="cyan")
    table.add_column("Description", style="dim", max_width=50)

    for t in tools:
        table.add_row(t.get("name", ""), t.get("server", ""), t.get("description", "")[:50])

    output.console.print(table)


@app.command("status")
def tools_status() -> None:
    """Show connection status of all MCP servers."""
    with Progress(
        SpinnerColumn(),
        TextColumn("[bold cyan]Checking status..."),
        transient=True,
        console=output.console,
    ):
        resp = client.get("/mcp-servers/status")

    _check_error(resp)
    connections = resp.json().get("connections", [])

    if not connections:
        output.warning("No MCP server connections configured.")
        return

    table = Table(title="MCP Server Status", border_style="cyan")
    table.add_column("Server", style="bold white")
    table.add_column("Type", style="dim")
    table.add_column("Status")
    table.add_column("Tools", justify="right")
    table.add_column("Error", style="dim", max_width=40)

    for c in connections:
        status = "[green]Healthy[/]" if c.get("is_healthy") else "[red]Unhealthy[/]"
        table.add_row(
            c.get("name", ""),
            c.get("type", ""),
            status,
            str(c.get("tool_count", 0)),
            (c.get("error") or "")[:40],
        )

    output.console.print(table)


@app.command("connect")
def tools_connect(
    server_name: str = typer.Argument(help="Built-in server name (e.g., stac-mcp, gis-mcp)"),
) -> None:
    """Connect to a built-in MCP server."""
    with Progress(
        SpinnerColumn(),
        TextColumn(f"[bold cyan]Connecting to {server_name}..."),
        transient=True,
        console=output.console,
    ):
        resp = client.post(f"/mcp-servers/connect/{server_name}")

    _check_error(resp)
    data = resp.json()

    if data.get("status") == "connected":
        output.success(f"Connected to [bold]{server_name}[/] — {data.get('tool_count', 0)} tools discovered")
    else:
        output.error(f"Connection failed: {data.get('error', 'unknown error')}")


@app.command("disconnect")
def tools_disconnect(
    server_name: str = typer.Argument(help="Server name to disconnect"),
) -> None:
    """Disconnect from an MCP server."""
    with Progress(
        SpinnerColumn(),
        TextColumn(f"[bold cyan]Disconnecting {server_name}..."),
        transient=True,
        console=output.console,
    ):
        resp = client.post(f"/mcp-servers/disconnect/{server_name}")

    _check_error(resp)
    output.success(f"Disconnected from [bold]{server_name}[/]")


@app.command("add")
def tools_add(
    name: str = typer.Argument(help="Server name"),
    server_type: str = typer.Option("http", "--type", "-t", help="Transport: http or stdio"),
    url: Optional[str] = typer.Option(None, "--url", "-u", help="HTTP URL"),
    command: Optional[str] = typer.Option(None, "--cmd", "-c", help="Stdio command"),
    description: Optional[str] = typer.Option(None, "--desc", "-d", help="Description"),
) -> None:
    """Add a custom MCP server."""
    body: dict = {
        "name": name,
        "server_type": server_type,
    }
    if url:
        body["url"] = url
    if command:
        body["command"] = command
    if description:
        body["description"] = description

    with Progress(
        SpinnerColumn(),
        TextColumn("[bold cyan]Adding server..."),
        transient=True,
        console=output.console,
    ):
        resp = client.post("/mcp-servers", json=body)

    _check_error(resp)
    output.success(f"Server [bold]{name}[/] added. Test with: [bold]terrascout tools test {name}[/]")


@app.command("remove")
def tools_remove(
    server_id: str = typer.Argument(help="Server UUID to remove"),
) -> None:
    """Remove a custom MCP server."""
    confirm = typer.confirm("Remove this MCP server?")
    if not confirm:
        raise typer.Abort()

    with Progress(
        SpinnerColumn(),
        TextColumn("[bold cyan]Removing server..."),
        transient=True,
        console=output.console,
    ):
        resp = client.delete(f"/mcp-servers/{server_id}")

    _check_error(resp)
    output.success("Server removed.")
