"""Copilot commands — interactive spatial intelligence chat."""

from typing import Optional

import typer
from rich.console import Console
from rich.markdown import Markdown
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn

from terrascout_cli import client, output

app = typer.Typer(no_args_is_help=True)
console = Console()


def _check_error(resp):
    if resp.status_code == 401:
        output.error("Authentication required. Run [bold]terrascout auth login[/].")
        raise typer.Exit(1)
    if resp.status_code not in (200, 201):
        output.error(f"API error {resp.status_code}: {resp.text[:200]}")
        raise typer.Exit(1)


@app.command("ask")
def copilot_ask(
    question: str = typer.Argument(help="Spatial question to ask"),
) -> None:
    """Ask the GIS Copilot a one-shot spatial question."""
    # Create session
    with Progress(SpinnerColumn(), TextColumn("[bold cyan]Creating session..."), transient=True, console=output.console):
        resp = client.post("/copilot/session", json={})
    _check_error(resp)
    session_id = resp.json().get("session_id")

    # Send message
    with Progress(SpinnerColumn(), TextColumn("[bold cyan]Analyzing..."), transient=True, console=output.console):
        resp = client.post(f"/copilot/{session_id}/message", json={"message": question})
    _check_error(resp)

    data = resp.json()
    route = data.get("route", "general")
    response_text = data.get("response", "No response.")

    # Display route badge
    console.print(f"\n[dim]Route: [cyan]{route}[/cyan][/dim]")

    # Display SQL if present
    if data.get("data", {}).get("sql"):
        console.print(Panel(data["data"]["sql"], title="[dim]Generated SQL[/dim]", border_style="cyan"))

    # Display response as markdown
    console.print(Markdown(response_text))

    # Display data summary
    if data.get("data", {}).get("row_count"):
        console.print(f"\n[dim]{data['data']['row_count']} rows returned in {data['data'].get('duration_ms', '?')}ms[/dim]")


@app.command("chat")
def copilot_chat() -> None:
    """Start an interactive copilot chat session (REPL)."""
    console.print(Panel.fit(
        "[bold white]Terrascout GIS Copilot[/]\n"
        "[dim]Type spatial questions, or /help for commands.[/]\n"
        "[dim]Type /quit to exit.[/]",
        border_style="teal",
    ))

    # Create session
    with Progress(SpinnerColumn(), TextColumn("[bold cyan]Starting session..."), transient=True, console=output.console):
        resp = client.post("/copilot/session", json={})
    _check_error(resp)
    session_id = resp.json().get("session_id")
    console.print(f"[dim]Session: {session_id}[/dim]\n")

    while True:
        try:
            question = console.input("[bold teal]> [/]")
        except (EOFError, KeyboardInterrupt):
            console.print("\n[dim]Session ended.[/dim]")
            break

        question = question.strip()
        if not question:
            continue
        if question.lower() in ("/quit", "/exit", "/q"):
            console.print("[dim]Session ended.[/dim]")
            break
        if question.lower() == "/help":
            console.print("[bold]Commands:[/]")
            console.print("  /quit    — End session")
            console.print("  /history — Show conversation history")
            console.print("  /clear   — Start new session")
            continue
        if question.lower() == "/history":
            resp = client.get(f"/copilot/{session_id}/history")
            if resp.status_code == 200:
                for m in resp.json().get("messages", []):
                    role = "[teal]You[/]" if m["role"] == "user" else "[cyan]Copilot[/]"
                    console.print(f"{role}: {m['content'][:200]}")
            continue
        if question.lower() == "/clear":
            resp = client.post("/copilot/session", json={})
            _check_error(resp)
            session_id = resp.json().get("session_id")
            console.print(f"[dim]New session: {session_id}[/dim]\n")
            continue

        # Send message
        with Progress(SpinnerColumn(), TextColumn("[bold cyan]Thinking..."), transient=True, console=output.console):
            resp = client.post(f"/copilot/{session_id}/message", json={"message": question})

        if resp.status_code != 200:
            output.error(f"Error: {resp.text[:200]}")
            continue

        data = resp.json()
        route = data.get("route", "")
        if route:
            console.print(f"[dim]({route})[/dim]")

        console.print(Markdown(data.get("response", "")))
        console.print()
