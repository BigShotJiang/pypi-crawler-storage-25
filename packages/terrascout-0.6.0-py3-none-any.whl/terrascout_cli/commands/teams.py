"""Team commands — list, create, info, invite, members, leave."""

from typing import Optional

import typer
from rich.progress import Progress, SpinnerColumn, TextColumn
from rich.table import Table

from terrascout_cli import client, output

app = typer.Typer(no_args_is_help=True)


def _check_auth(resp):
    if resp.status_code == 401:
        output.error("Authentication required. Run [bold]terrascout auth login[/].")
        raise typer.Exit(1)


def _check_error(resp):
    _check_auth(resp)
    if resp.status_code not in (200, 201):
        output.error(f"API error {resp.status_code}: {resp.text[:200]}")
        raise typer.Exit(1)


@app.command("list")
def teams_list() -> None:
    """List your teams."""
    with Progress(
        SpinnerColumn(),
        TextColumn("[bold cyan]Loading teams..."),
        transient=True,
        console=output.console,
    ):
        resp = client.get("/teams")

    _check_error(resp)
    teams = resp.json()

    if not teams:
        output.warning("No teams yet. Use [bold]terrascout teams create[/] to start one.")
        return

    table = Table(title="My Teams", border_style="cyan", show_lines=True)
    table.add_column("ID", style="dim", max_width=36)
    table.add_column("Name", style="bold white")
    table.add_column("Slug", style="dim")
    table.add_column("Members", justify="right")
    table.add_column("My Role", style="cyan")
    table.add_column("Created", style="dim")

    for t in teams:
        table.add_row(
            str(t.get("id", ""))[:36],
            t.get("name", ""),
            t.get("slug", ""),
            str(t.get("member_count", 0)),
            t.get("my_role", ""),
            str(t.get("created_at", ""))[:10],
        )

    output.console.print(table)


@app.command("create")
def teams_create(
    name: str = typer.Argument(help="Team name"),
    description: Optional[str] = typer.Option(None, "--desc", "-d", help="Team description"),
) -> None:
    """Create a new team (you become the owner)."""
    body: dict = {"name": name}
    if description:
        body["description"] = description

    with Progress(
        SpinnerColumn(),
        TextColumn("[bold cyan]Creating team..."),
        transient=True,
        console=output.console,
    ):
        resp = client.post("/teams", json=body)

    _check_error(resp)
    data = resp.json()
    output.success(f"Team created: [bold]{data.get('name', name)}[/] (slug: {data.get('slug', '?')})")


@app.command("info")
def teams_info(
    team_id: str = typer.Argument(help="Team UUID"),
) -> None:
    """Show team details and members."""
    with Progress(
        SpinnerColumn(),
        TextColumn("[bold cyan]Loading team..."),
        transient=True,
        console=output.console,
    ):
        resp = client.get(f"/teams/{team_id}")

    _check_error(resp)
    data = resp.json()

    output.console.print(f"\n[bold white]{data.get('name', '')}[/]")
    if data.get("description"):
        output.console.print(f"[dim]{data['description']}[/]")
    output.console.print(f"Slug: [cyan]{data.get('slug', '')}[/]  |  Your role: [bold]{data.get('my_role', 'N/A')}[/]")
    output.console.print()

    members = data.get("members", [])
    if members:
        table = Table(title="Members", border_style="cyan")
        table.add_column("Name", style="white")
        table.add_column("Role", style="cyan")
        table.add_column("Joined", style="dim")

        for m in members:
            table.add_row(
                m.get("display_name") or f"User {m.get('user_id', '')[:8]}",
                m.get("role", ""),
                str(m.get("joined_at", ""))[:10],
            )
        output.console.print(table)

    pending = data.get("pending_invitations", [])
    if pending:
        output.console.print(f"\n[amber]Pending invitations: {len(pending)}[/]")
        for inv in pending:
            output.console.print(f"  - {inv.get('email', '')} ({inv.get('role', '')})")


@app.command("invite")
def teams_invite(
    team_id: str = typer.Argument(help="Team UUID"),
    email: str = typer.Argument(help="Email to invite"),
    role: str = typer.Option("member", "--role", "-r", help="Role: admin, member, viewer"),
) -> None:
    """Invite a user to join a team."""
    with Progress(
        SpinnerColumn(),
        TextColumn(f"[bold cyan]Inviting {email}..."),
        transient=True,
        console=output.console,
    ):
        resp = client.post(f"/teams/{team_id}/invite", json={"email": email, "role": role})

    _check_error(resp)
    output.success(f"Invitation sent to [bold]{email}[/] as [bold]{role}[/]")


@app.command("members")
def teams_members(
    team_id: str = typer.Argument(help="Team UUID"),
) -> None:
    """List team members."""
    with Progress(
        SpinnerColumn(),
        TextColumn("[bold cyan]Loading members..."),
        transient=True,
        console=output.console,
    ):
        resp = client.get(f"/teams/{team_id}/members")

    _check_error(resp)
    members = resp.json()

    table = Table(title="Team Members", border_style="cyan", show_lines=True)
    table.add_column("User ID", style="dim", max_width=36)
    table.add_column("Name", style="bold white")
    table.add_column("Role", style="cyan")
    table.add_column("Joined", style="dim")

    for m in members:
        table.add_row(
            str(m.get("user_id", ""))[:36],
            m.get("display_name") or "—",
            m.get("role", ""),
            str(m.get("joined_at", ""))[:10],
        )

    output.console.print(table)


@app.command("leave")
def teams_leave(
    team_id: str = typer.Argument(help="Team UUID"),
) -> None:
    """Leave a team."""
    confirm = typer.confirm("Are you sure you want to leave this team?")
    if not confirm:
        raise typer.Abort()

    with Progress(
        SpinnerColumn(),
        TextColumn("[bold cyan]Leaving team..."),
        transient=True,
        console=output.console,
    ):
        # We need the current user's ID — use the profile endpoint
        profile_resp = client.get("/profile")
        _check_error(profile_resp)
        user_id = profile_resp.json().get("user_id", "")
        resp = client.delete(f"/teams/{team_id}/members/{user_id}")

    _check_error(resp)
    output.success("You have left the team.")


@app.command("projects")
def teams_projects(
    team_id: str = typer.Argument(help="Team UUID"),
) -> None:
    """List projects belonging to a team."""
    with Progress(
        SpinnerColumn(),
        TextColumn("[bold cyan]Loading team projects..."),
        transient=True,
        console=output.console,
    ):
        resp = client.get(f"/teams/{team_id}/projects")

    _check_error(resp)
    projects = resp.json()

    if not projects:
        output.warning("No team projects yet.")
        return

    table = Table(title="Team Projects", border_style="cyan", show_lines=True)
    table.add_column("ID", style="dim", max_width=36)
    table.add_column("Name", style="bold white")
    table.add_column("Status", style="cyan")
    table.add_column("Created", style="dim")

    for p in projects:
        table.add_row(
            str(p.get("id", ""))[:36],
            p.get("name", ""),
            p.get("status", "active"),
            str(p.get("created_at", ""))[:10],
        )

    output.console.print(table)
