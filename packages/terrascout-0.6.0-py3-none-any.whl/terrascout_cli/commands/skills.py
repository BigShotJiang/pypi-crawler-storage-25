"""Skills commands — list, info, run against the Terrascout Skills Engine API."""

import json

import typer
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn
from rich.table import Table

from terrascout_cli import client, output

app = typer.Typer(no_args_is_help=True)


@app.command("list")
def skills_list(
    category: str = typer.Option(None, "--category", "-c", help="Filter by category"),
    tier: str = typer.Option(None, "--tier", "-t", help="Filter by tier"),
    tag: str = typer.Option(None, "--tag", help="Filter by tag"),
) -> None:
    """List available skills."""
    params = {}
    if category:
        params["category"] = category
    if tier:
        params["tier"] = tier
    if tag:
        params["tag"] = tag

    with Progress(
        SpinnerColumn(),
        TextColumn("[bold cyan]Loading skills..."),
        transient=True,
        console=output.console,
    ):
        resp = client.get("/skills", params=params)

    if resp.status_code == 404:
        output.warning("Skills engine not yet deployed. Coming in a future release.")
        return
    if resp.status_code != 200:
        output.error(f"API error {resp.status_code}: {resp.text[:200]}")
        raise typer.Exit(1)

    skills = resp.json()
    if not isinstance(skills, list):
        skills = skills.get("skills", [])

    if not skills:
        output.warning("No skills match the given filters.")
        return

    table = Table(title="Skills", border_style="cyan", show_lines=True)
    table.add_column("Name", style="bold white")
    table.add_column("Version", style="dim")
    table.add_column("Category", style="cyan")
    table.add_column("Description")
    table.add_column("Tier", justify="center")

    for s in skills:
        table.add_row(
            s.get("name", ""),
            s.get("version", ""),
            s.get("category", ""),
            s.get("description", "")[:60],
            s.get("tier", "free"),
        )

    output.console.print(table)


@app.command("info")
def skills_info(
    name: str = typer.Argument(help="Skill name (e.g. search-sentinel)"),
) -> None:
    """Show detailed info and parameter schema for a skill."""
    with Progress(
        SpinnerColumn(),
        TextColumn(f"[bold cyan]Loading skill '{name}'..."),
        transient=True,
        console=output.console,
    ):
        resp = client.get(f"/skills/{name}")

    if resp.status_code == 404:
        output.error(f"Skill '{name}' not found.")
        raise typer.Exit(1)
    if resp.status_code != 200:
        output.error(f"API error {resp.status_code}: {resp.text[:200]}")
        raise typer.Exit(1)

    skill = resp.json()

    # Header
    output.console.print(Panel(
        f"[bold]{skill['name']}[/bold] v{skill['version']}  [{skill['tier']}]\n\n"
        f"{skill['description']}\n\n"
        f"Category: {skill['category']}\n"
        f"Tags: {', '.join(skill.get('tags', []))}",
        title="Skill Info",
        border_style="cyan",
    ))

    # Parameter table
    params = skill.get("params", {})
    if params:
        table = Table(title="Parameters", border_style="dim", show_lines=True)
        table.add_column("Name", style="bold white")
        table.add_column("Type", style="cyan")
        table.add_column("Required", justify="center")
        table.add_column("Default", style="dim")
        table.add_column("Description")

        for pname, pschema in params.items():
            table.add_row(
                pname,
                pschema.get("type", ""),
                "[green]yes[/green]" if pschema.get("required") else "no",
                str(pschema.get("default", "")),
                pschema.get("description", "")[:50],
            )

        output.console.print(table)


@app.command("run")
def skills_run(
    name: str = typer.Argument(help="Skill name"),
    params: list[str] = typer.Option(
        [], "--param", "-p",
        help="Parameters as key=value (use JSON for arrays: bbox='[144.9,-37.9,145.0,-37.8]')",
    ),
) -> None:
    """Run a skill with parameters."""
    param_dict: dict = {}
    for p in params:
        if "=" not in p:
            output.error(f"Invalid param format: '{p}'. Use key=value.")
            raise typer.Exit(1)
        k, v = p.split("=", 1)
        # Try to parse as JSON (for arrays, numbers, booleans)
        try:
            param_dict[k] = json.loads(v)
        except (json.JSONDecodeError, ValueError):
            param_dict[k] = v

    with Progress(
        SpinnerColumn(),
        TextColumn(f"[bold cyan]Running skill '{name}'..."),
        transient=True,
        console=output.console,
    ):
        resp = client.post(f"/skills/{name}/run", json={"params": param_dict})

    if resp.status_code == 404:
        output.error(f"Skill '{name}' not found.")
        raise typer.Exit(1)
    if resp.status_code == 403:
        output.error(f"Access denied — skill '{name}' requires a higher tier.")
        raise typer.Exit(1)
    if resp.status_code != 200:
        output.error(f"API error {resp.status_code}: {resp.text[:200]}")
        raise typer.Exit(1)

    data = resp.json()
    success = data.get("success", False)
    border = "green" if success else "red"
    status = "[green]SUCCESS[/green]" if success else "[red]FAILED[/red]"

    content = f"{status}\n\n{data.get('message', '')}"
    if data.get("processing_time_seconds"):
        content += f"\n\nTime: {data['processing_time_seconds']:.2f}s"

    output.console.print(Panel(content, title=f"Skill: {name}", border_style=border))

    # Print data if present
    result_data = data.get("data")
    if result_data:
        output.console.print_json(json.dumps(result_data, indent=2, default=str))
