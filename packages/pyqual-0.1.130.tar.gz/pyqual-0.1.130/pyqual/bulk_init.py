"""Bulk project initialization with LLM-based project type detection.

Scans subdirectories of a given folder, collects a fingerprint of each project,
sends it to an LLM with a JSON schema, and generates tailored pyqual.yaml configs.

Usage (CLI):
    pyqual bulk-init /path/to/workspace
    pyqual bulk-init /path/to/workspace --dry-run
    pyqual bulk-init /path/to/workspace --no-llm   # heuristic-only fallback
"""

from __future__ import annotations

import json
import logging
import re
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any

from pyqual.bulk_init_classify import ProjectConfig, check_skip_conditions
from pyqual.bulk_init_fingerprint import (
    ProjectFingerprint,
    collect_fingerprint,
)
from pyqual.constants import (
    DEFAULT_CC_MAX,
    README_EXCERPT_MAX_CHARS,
    TOP_LEVEL_FILES_MAX,
)

import yaml

logger = logging.getLogger("pyqual.bulk_init")

# ---------------------------------------------------------------------------
# JSON Schema for LLM response
# ---------------------------------------------------------------------------

PROJECT_CONFIG_SCHEMA: dict[str, Any] = {
    "$schema": "https://json-schema.org/draft/2020-12/schema",
    "title": "PyqualProjectConfig",
    "description": "LLM-generated pyqual configuration decisions for a single project.",
    "type": "object",
    "required": ["project_type", "has_tests", "skip"],
    "properties": {
        "project_type": {
            "type": "string",
            "enum": [
                "python",
                "node",
                "typescript",
                "php",
                "rust",
                "go",
                "shell",
                "mixed",
                "docs",
                "unknown",
            ],
            "description": "Primary language / ecosystem of the project.",
        },
        "skip": {
            "type": "boolean",
            "description": "True if this directory is not a real project (artifacts, data, venv, etc.).",
        },
        "skip_reason": {
            "type": ["string", "null"],
            "description": "If skip=true, short reason why.",
        },
        "has_tests": {
            "type": "boolean",
            "description": "Whether the project has an existing test suite.",
        },
        "test_command": {
            "type": ["string", "null"],
            "description": "Command to run tests, e.g. 'python3 -m pytest -q', 'npm test', 'make test'.",
        },
        "lint_command": {
            "type": ["string", "null"],
            "description": "Lint command, e.g. 'ruff check .', 'npm run lint'. null = use tool preset.",
        },
        "lint_tool_preset": {
            "type": ["string", "null"],
            "description": "Built-in pyqual tool preset for linting: 'ruff', 'pylint', 'flake8', or null.",
        },
        "build_command": {
            "type": ["string", "null"],
            "description": "Build command if applicable, e.g. 'npm run build'.",
        },
        "extra_excludes": {
            "type": "array",
            "items": {"type": "string"},
            "description": "Additional directories to exclude from code2llm/vallm analysis.",
        },
        "cc_max": {
            "type": "integer",
            "default": DEFAULT_CC_MAX,
            "description": "Max cyclomatic complexity threshold.",
        },
        "extra_stages": {
            "type": "array",
            "items": {
                "type": "object",
                "required": ["name", "run"],
                "properties": {
                    "name": {"type": "string"},
                    "run": {"type": "string"},
                    "when": {
                        "type": "string",
                        "enum": ["always", "metrics_fail", "metrics_pass"],
                        "default": "always",
                    },
                    "optional": {"type": "boolean", "default": False},
                },
            },
            "description": "Additional custom stages beyond the standard analyze/validate/fix/test pipeline.",
        },
    },
    "additionalProperties": False,
}

# ---------------------------------------------------------------------------
# Default exclude lists
# ---------------------------------------------------------------------------

BASE_EXCLUDES_SPACE = (
    ".git .venv .venv_test build dist __pycache__ .pytest_cache "
    ".code2llm_cache .benchmarks .mypy_cache .ruff_cache node_modules"
)
BASE_EXCLUDES_COMMA = BASE_EXCLUDES_SPACE.replace(" ", ",")


# ---------------------------------------------------------------------------
# LLM classification
# ---------------------------------------------------------------------------

LLM_SYSTEM_PROMPT = """\
You are a project classifier for pyqual, a declarative quality gate pipeline tool.
Given a project fingerprint (directory structure, manifests, scripts), determine
the best pyqual configuration for that project.

Respond ONLY with valid JSON matching the provided schema. No markdown, no explanation.
"""


def _build_llm_prompt(fp: ProjectFingerprint) -> str:
    """Build the user prompt for LLM classification."""
    fp_dict = asdict(fp)
    # Trim large fields
    if len(fp_dict.get("readme_excerpt", "")) > README_EXCERPT_MAX_CHARS:
        fp_dict["readme_excerpt"] = f"{fp_dict['readme_excerpt'][:README_EXCERPT_MAX_CHARS]}..."
    if len(fp_dict.get("top_level_files", [])) > TOP_LEVEL_FILES_MAX:
        fp_dict["top_level_files"] = [*fp_dict["top_level_files"][:TOP_LEVEL_FILES_MAX], "..."]

    return (
        f"## Project fingerprint\n\n"
        f"```json\n{json.dumps(fp_dict, indent=2, ensure_ascii=False)}\n```\n\n"
        f"## Output JSON schema\n\n"
        f"```json\n{json.dumps(PROJECT_CONFIG_SCHEMA, indent=2)}\n```\n\n"
        f"Return a single JSON object matching the schema above. "
        f"Decide the best test/lint/build commands based on the project's manifests and scripts."
    )


def classify_with_llm(fp: ProjectFingerprint, model: str | None = None) -> ProjectConfig:
    """Send fingerprint to LLM, parse structured response."""
    from pyqual.llm import LLM

    llm = LLM(model=model)
    prompt = _build_llm_prompt(fp)

    response = llm.complete(
        prompt=prompt,
        system=LLM_SYSTEM_PROMPT,
        temperature=0.1,
        max_tokens=1000,
    )

    # Extract JSON from response (handle markdown fences)
    text = response.content.strip()
    if text.startswith("```"):
        lines = text.splitlines()
        # Remove first and last fence lines
        json_lines = []
        in_fence = False
        for line in lines:
            if line.startswith("```") and not in_fence:
                in_fence = True
                continue
            if line.startswith("```") and in_fence:
                break
            if in_fence:
                json_lines.append(line)
        text = "\n".join(json_lines)

    try:
        data = json.loads(text)
    except json.JSONDecodeError as exc:
        logger.warning("LLM returned invalid JSON for %s: %s", fp.name, exc)
        logger.debug("Raw LLM response: %s", response.content)
        return _classify_heuristic(fp)

    return ProjectConfig(
        project_type=data.get("project_type", "unknown"),
        skip=data.get("skip", False),
        skip_reason=data.get("skip_reason"),
        has_tests=data.get("has_tests", False),
        test_command=data.get("test_command"),
        lint_command=data.get("lint_command"),
        lint_tool_preset=data.get("lint_tool_preset"),
        build_command=data.get("build_command"),
        extra_excludes=data.get("extra_excludes", []),
        cc_max=data.get("cc_max", DEFAULT_CC_MAX),
        extra_stages=data.get("extra_stages", []),
    )


# ---------------------------------------------------------------------------
# Heuristic fallback (no LLM)
# ---------------------------------------------------------------------------


def _classify_heuristic(fp: ProjectFingerprint) -> ProjectConfig:
    """Rule-based classification when LLM is unavailable."""
    # Use shared skip conditions checker
    skip_result = check_skip_conditions(fp)
    if skip_result:
        return skip_result

    has_python = "pyproject.toml" in fp.manifests or "setup.py" in fp.manifests
    has_node = "package.json" in fp.manifests
    has_composer = "composer.json" in fp.manifests
    has_makefile = "Makefile" in fp.manifests
    has_cargo = "Cargo.toml" in fp.manifests
    has_go = "go.mod" in fp.manifests

    # Python
    if has_python:
        test_cmd = "python3 -m pytest -q" if fp.has_tests_dir else "python3 -m pytest -q --co 2>/dev/null || true"
        return ProjectConfig(
            project_type="python",
            has_tests=fp.has_tests_dir,
            test_command=test_cmd,
            lint_tool_preset="ruff",
        )

    # Node.js / TypeScript
    if has_node:
        ptype = "typescript" if ".ts" in fp.file_extensions or ".tsx" in fp.file_extensions else "node"
        test_cmd = None
        lint_cmd = None
        build_cmd = None
        if "test" in fp.node_scripts:
            test_cmd = "npm test"
        if "lint" in fp.node_scripts:
            lint_cmd = "npm run lint"
        if "build" in fp.node_scripts:
            build_cmd = "npm run build"
        return ProjectConfig(
            project_type=ptype,
            has_tests="test" in fp.node_scripts,
            test_command=test_cmd,
            lint_command=lint_cmd,
            build_command=build_cmd,
        )

    # PHP
    if has_composer:
        test_cmd = "composer test" if "test" in fp.composer_scripts else None
        return ProjectConfig(
            project_type="php",
            has_tests="test" in fp.composer_scripts,
            test_command=test_cmd,
            lint_command="find . -name '*.php' -exec php -l {} \\;",
        )

    # Rust
    if has_cargo:
        return ProjectConfig(
            project_type="rust",
            has_tests=True,
            test_command="cargo test",
            lint_command="cargo clippy",
            build_command="cargo build",
        )

    # Go
    if has_go:
        return ProjectConfig(
            project_type="go",
            has_tests=True,
            test_command="go test ./...",
            lint_command="golangci-lint run",
        )

    # Makefile-only
    if has_makefile:
        test_cmd = "make test" if "test" in fp.makefile_targets else None
        lint_cmd = "make lint" if "lint" in fp.makefile_targets else None
        return ProjectConfig(
            project_type="mixed",
            has_tests="test" in fp.makefile_targets,
            test_command=test_cmd,
            lint_command=lint_cmd,
        )

    # Check for loose Python files
    py_exts = {".py"}
    if py_exts & set(fp.file_extensions):
        return ProjectConfig(
            project_type="python",
            has_tests=fp.has_tests_dir,
            test_command="python3 -m pytest -q --co 2>/dev/null || true",
        )

    # Docs-only
    md_exts = {".md", ".rst", ".txt"}
    if set(fp.file_extensions) <= md_exts | {""}:
        return ProjectConfig(skip=True, skip_reason="documentation-only directory")

    return ProjectConfig(project_type="unknown", skip=False)


# ---------------------------------------------------------------------------
# YAML generation
# ---------------------------------------------------------------------------

def _safe_name(name: str) -> str:
    """Convert project name to a safe identifier for tool names."""
    return re.sub(r"[^a-z0-9]", "_", name.lower()).strip("_")


def generate_pyqual_yaml(project_name: str, cfg: ProjectConfig) -> str:
    """Generate pyqual.yaml content from a ProjectConfig."""
    sn = _safe_name(project_name)

    excludes_list = BASE_EXCLUDES_SPACE.split()
    excludes_list.extend(cfg.extra_excludes)
    excludes_space = " ".join(excludes_list)
    excludes_comma = ",".join(excludes_list)

    lines: list[str] = []
    lines.append("pipeline:")
    lines.append(f"  name: {project_name}-quality")
    lines.append("")
    lines.append("  metrics:")
    lines.append(f"    cc_max: {cfg.cc_max}")
    lines.append("    critical_max: 0")
    lines.append("")

    # Custom tools
    lines.append("  custom_tools:")
    lines.append(f"    - name: code2llm_{sn}")
    lines.append("      binary: code2llm")
    lines.append("      command: >-")
    lines.append("        code2llm {workdir} -f toon -o ./project --no-chunk")
    lines.append(f"        --exclude {excludes_space}")
    lines.append('      output: ""')
    lines.append("      allow_failure: false")
    lines.append("")
    lines.append(f"    - name: vallm_{sn}")
    lines.append("      binary: vallm")
    lines.append("      command: >-")
    lines.append("        vallm batch {workdir} --recursive --format toon --output ./project")
    lines.append(f"        --exclude {excludes_comma}")
    lines.append('      output: ""')
    lines.append("      allow_failure: false")
    lines.append("")

    # Stages
    lines.append("  stages:")
    lines.append("    - name: analyze")
    lines.append(f"      tool: code2llm_{sn}")
    lines.append("      optional: true")
    lines.append("      timeout: 0")
    lines.append("")
    lines.append("    - name: validate")
    lines.append(f"      tool: vallm_{sn}")
    lines.append("      optional: true")
    lines.append("      timeout: 0")

    # Lint stage
    if cfg.lint_tool_preset:
        lines.append("")
        lines.append("    - name: lint")
        lines.append(f"      tool: {cfg.lint_tool_preset}")
        lines.append("      optional: true")
    elif cfg.lint_command:
        lines.append("")
        lines.append("    - name: lint")
        lines.append(f"      run: {cfg.lint_command}")
        lines.append("      when: always")

    # Build stage
    if cfg.build_command:
        lines.append("")
        lines.append("    - name: build")
        lines.append(f"      run: {cfg.build_command}")
        lines.append("      when: always")

    # Fix stage
    lines.append("")
    lines.append("    - name: fix")
    lines.append("      tool: prefact")
    lines.append("      optional: true")
    lines.append("      when: metrics_fail")
    lines.append("      timeout: 900")

    # Test stage
    if cfg.test_command:
        lines.append("")
        lines.append("    - name: test")
        lines.append(f"      run: {cfg.test_command}")
        lines.append("      when: always")

    # Extra stages from LLM
    for stage in cfg.extra_stages:
        lines.append("")
        lines.append(f"    - name: {stage['name']}")
        lines.append(f"      run: {stage['run']}")
        when = stage.get("when", "always")
        lines.append(f"      when: {when}")
        if stage.get("optional"):
            lines.append("      optional: true")

    # Loop + env
    lines.append("")
    lines.append("  loop:")
    lines.append("    max_iterations: 3")
    lines.append("    on_fail: report")
    lines.append("")
    lines.append("  env:")
    lines.append("    LLM_MODEL: openrouter/qwen/qwen3-coder-next")
    lines.append("")

    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Bulk init orchestrator
# ---------------------------------------------------------------------------

@dataclass
class BulkInitResult:
    """Summary of a bulk-init run."""

    created: list[str] = field(default_factory=list)
    skipped_existing: list[str] = field(default_factory=list)
    skipped_nonproject: list[tuple[str, str]] = field(default_factory=list)
    errors: list[tuple[str, str]] = field(default_factory=list)

    @property
    def total(self) -> int:
        return len(self.created) + len(self.skipped_existing) + len(self.skipped_nonproject) + len(self.errors)


def _validate_yaml_content(yaml_content: str, project_name: str) -> None:
    """Validate that YAML content is parseable and has required structure."""
    try:
        parsed = yaml.safe_load(yaml_content)
        if not parsed or "pipeline" not in parsed:
            raise ValueError("missing 'pipeline' key")
    except Exception as exc:
        raise ValueError(f"YAML validation error: {exc}") from exc


def _write_pyqual_yaml(project_dir: Path, yaml_content: str) -> None:
    """Write pyqual.yaml to project directory and ensure .pyqual exists."""
    target = project_dir / "pyqual.yaml"
    target.write_text(yaml_content)
    (project_dir / ".pyqual").mkdir(exist_ok=True)


def _classify_project(fp: ProjectFingerprint, use_llm: bool, model: str | None, project_name: str) -> ProjectConfig:
    """Classify project using LLM or heuristic fallback."""
    if not use_llm:
        return _classify_heuristic(fp)
    
    try:
        return classify_with_llm(fp, model=model)
    except Exception as exc:
        logger.warning("LLM classification failed for %s, using heuristic: %s", project_name, exc)
        return _classify_heuristic(fp)


def bulk_init(
    root: Path,
    *,
    use_llm: bool = True,
    model: str | None = None,
    dry_run: bool = False,
    overwrite: bool = False,
) -> BulkInitResult:
    """Scan subdirectories of *root* and generate pyqual.yaml for each project.

    Parameters
    ----------
    root:
        Parent directory whose immediate children are projects.
    use_llm:
        If True, classify projects via LLM.  Falls back to heuristics on failure.
    model:
        Override LLM model name.
    dry_run:
        If True, do not write files — only return what would be generated.
    overwrite:
        If True, regenerate pyqual.yaml even when one already exists.
    """
    result = BulkInitResult()

    subdirs = sorted(
        d for d in root.iterdir()
        if d.is_dir() and not d.name.startswith(".")
    )

    for project_dir in subdirs:
        name = project_dir.name

        # Collect fingerprint
        try:
            fp = collect_fingerprint(project_dir)
        except Exception as exc:
            result.errors.append((name, f"fingerprint error: {exc}"))
            continue

        # Skip existing
        if fp.has_pyqual_yaml and not overwrite:
            result.skipped_existing.append(name)
            continue

        # Classify with LLM or heuristic
        try:
            cfg = _classify_project(fp, use_llm, model, name)
        except Exception as exc:
            result.errors.append((name, f"classification error: {exc}"))
            continue

        # Handle skip
        if cfg.skip:
            result.skipped_nonproject.append((name, cfg.skip_reason or ""))
            continue

        # Generate YAML
        try:
            yaml_content = generate_pyqual_yaml(name, cfg)
        except Exception as exc:
            result.errors.append((name, f"generation error: {exc}"))
            continue

        # Validate generated YAML
        try:
            _validate_yaml_content(yaml_content, name)
        except Exception as exc:
            result.errors.append((name, str(exc)))
            continue

        # Write
        if not dry_run:
            _write_pyqual_yaml(project_dir, yaml_content)

        result.created.append(name)

    return result
