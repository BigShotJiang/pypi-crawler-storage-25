from __future__ import annotations

from pathlib import Path

from m2_sdk.catalog import CatalogChanges, apply_changes, diff_catalog, load_catalog, save_catalog


class ResourceEndpoint:
    def __init__(
        self, key: str | None = None, failures: set[tuple[str, str]] | None = None
    ) -> None:
        self.key = key
        self.failures = failures or set()
        self.created: list[dict[str, object]] = []
        self.updated: list[tuple[str, dict[str, object]]] = []
        self.deleted: list[str] = []

    def __call__(self, **kwargs: str) -> ResourceEndpoint:
        return ResourceEndpoint(kwargs.get("sku"), self.failures)

    def post(self, record: dict[str, object]) -> None:
        if ("post", str(record.get("sku"))) in self.failures:
            raise RuntimeError("post failed")
        self.created.append(record)

    def put(self, record: dict[str, object]) -> None:
        if ("put", self.key or "") in self.failures:
            raise RuntimeError("put failed")
        self.updated.append((self.key or "", record))

    def delete(self) -> None:
        if ("delete", self.key or "") in self.failures:
            raise RuntimeError("delete failed")
        self.deleted.append(self.key or "")


class EndpointFactory:
    def __init__(self, failures: set[tuple[str, str]] | None = None) -> None:
        self.failures = failures or set()
        self.created: list[dict[str, object]] = []
        self.updated: list[tuple[str, dict[str, object]]] = []
        self.deleted: list[str] = []

    def __call__(self, **kwargs: str) -> EndpointFactoryBound:
        return EndpointFactoryBound(self, kwargs.get("sku"))

    def post(self, record: dict[str, object]) -> None:
        if ("post", str(record.get("sku"))) in self.failures:
            raise RuntimeError("post failed")
        self.created.append(record)


class EndpointFactoryBound:
    def __init__(self, parent: EndpointFactory, key: str | None) -> None:
        self.parent = parent
        self.key = key or ""

    def put(self, record: dict[str, object]) -> None:
        if ("put", self.key) in self.parent.failures:
            raise RuntimeError("put failed")
        self.parent.updated.append((self.key, record))

    def delete(self) -> None:
        if ("delete", self.key) in self.parent.failures:
            raise RuntimeError("delete failed")
        self.parent.deleted.append(self.key)


def test_save_and_load_catalog_round_trip(tmp_path: Path) -> None:
    path = tmp_path / "nested" / "products.json"
    catalog = {"SKU-1": {"sku": "SKU-1", "name": "Alpha"}}

    saved = save_catalog(catalog, path)
    loaded = load_catalog(path)

    assert saved == 1
    assert loaded == catalog


def test_load_catalog_non_dict_raises_value_error(tmp_path: Path) -> None:
    path = tmp_path / "list.json"
    path.write_text("[]")

    try:
        load_catalog(path)
    except ValueError as exc:
        assert "Expected dict" in str(exc)
    else:
        raise AssertionError("Expected ValueError")


def test_diff_catalog_detects_created_updated_and_deleted() -> None:
    original = {
        "SKU-1": {"sku": "SKU-1", "name": "Old", "price": 10},
        "SKU-2": {"sku": "SKU-2", "name": "Gone"},
    }
    modified = {
        "SKU-1": {"sku": "SKU-1", "name": "New", "price": 10, "stock": 5},
        "SKU-3": {"sku": "SKU-3", "name": "Fresh"},
    }

    changes = diff_catalog(original, modified)

    assert changes.created == {"SKU-3": {"sku": "SKU-3", "name": "Fresh"}}
    assert changes.deleted == ["SKU-2"]
    assert changes.updated == {"SKU-1": {"name": "New", "stock": 5}}
    assert changes.total == 3
    assert repr(changes) == "CatalogChanges(created=1, updated=1, deleted=1)"


def test_apply_changes_returns_successful_keys_only() -> None:
    endpoint = EndpointFactory(failures={("post", "SKU-2"), ("put", "SKU-3"), ("delete", "SKU-4")})
    client = type("Client", (), {"products": endpoint})()
    changes = CatalogChanges()
    changes.created = {
        "SKU-1": {"sku": "SKU-1"},
        "SKU-2": {"sku": "SKU-2"},
    }
    changes.updated = {
        "SKU-3": {"name": "Updated"},
        "SKU-5": {"price": 99},
    }
    changes.deleted = ["SKU-4", "SKU-6"]

    result = apply_changes(client, changes)

    assert result == {"created": ["SKU-1"], "updated": ["SKU-5"], "deleted": ["SKU-6"]}
    assert endpoint.created == [{"sku": "SKU-1"}]
    assert endpoint.updated == [("SKU-5", {"price": 99})]
    assert endpoint.deleted == ["SKU-6"]
