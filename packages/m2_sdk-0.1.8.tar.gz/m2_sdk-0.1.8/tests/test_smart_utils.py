from __future__ import annotations

import json
from pathlib import Path

import pytest
import typer

import m2_sdk.smart_utils as smart_utils


class DummyConsole:
    def __init__(self) -> None:
        self.messages: list[str] = []

    def print(self, message: str) -> None:
        self.messages.append(message)


def test_build_smart_search_criteria_and_request_body(tmp_path: Path) -> None:
    params = smart_utils.build_smart_search_criteria(
        name_like="Laptop%",
        sku_like="SKU%",
        price_from=10,
        price_to=20,
        status="1",
        type="simple",
        email_like="%@example.com",
        limit=50,
        page=3,
        sort_by="price",
        sort_order="desc",
        color_like="red%",
        _internal="skip",
    )

    assert params["searchCriteria[pageSize]"] == 50
    assert params["searchCriteria[currentPage]"] == 3
    assert params["searchCriteria[sortOrders][0][field]"] == "price"
    assert params["searchCriteria[filterGroups][0][filters][0][field]"] == "name"
    assert params["searchCriteria[filterGroups][0][filters][0][conditionType]"] == "like"
    assert params["searchCriteria[filterGroups][0][filters][7][field]"] == "color"
    assert "_internal" not in json.dumps(params)

    inline = smart_utils.build_request_body(data='{"sku": "A", "price": 9.5}')
    simple = smart_utils.build_request_body(sku="B", price=2)
    path = tmp_path / "product.json"
    path.write_text('{"sku": "C"}')
    from_file = smart_utils.parse_json_data(f"@{path}")

    assert inline == {"sku": "A", "price": 9.5}
    assert simple == {"sku": "B", "price": 2}
    assert from_file == {"sku": "C"}


def test_parse_json_data_errors(tmp_path: Path) -> None:
    path = tmp_path / "bad.json"
    path.write_text("[]")

    with pytest.raises(typer.BadParameter, match="Invalid JSON"):
        smart_utils.parse_json_data("{bad")

    with pytest.raises(typer.BadParameter, match="File not found"):
        smart_utils.parse_json_data("@missing.json")

    assert smart_utils.parse_json_data("") is None
    assert smart_utils.parse_json_data("[]") is None
    assert smart_utils.parse_json_data(f"@{path}") is None


def test_format_and_print_and_error_handling(monkeypatch: pytest.MonkeyPatch) -> None:
    captured: list[object] = []
    monkeypatch.setattr(smart_utils, "rprint", captured.append)
    monkeypatch.setattr(smart_utils, "format_output", lambda *args, **kwargs: {"ok": True})

    smart_utils.format_and_print({"sku": "A"})
    assert captured == [{"ok": True}]

    console = DummyConsole()
    monkeypatch.setattr(smart_utils, "Console", lambda: console)

    with pytest.raises(typer.Exit):
        smart_utils.handle_api_error(Exception("Connection refused"), "product", "SKU-1")
    assert any("Could not connect" in msg for msg in console.messages)

    console.messages.clear()
    with pytest.raises(typer.Exit):
        smart_utils.handle_api_error(Exception("Timeout"), "product", "SKU-1")
    assert any("Request timed out" in msg for msg in console.messages)

    console.messages.clear()
    with pytest.raises(typer.Exit):
        smart_utils.handle_api_error(Exception("boom"), "product", "SKU-1")
    assert console.messages[0].startswith("[red bold]Error:")

    console.messages.clear()
    with pytest.raises(typer.Exit):
        smart_utils.handle_magento_error(Exception("boom"), "product", "SKU-1")
    assert console.messages[0].startswith("[red bold]Error:")


def test_handle_api_error_status_branches(monkeypatch: pytest.MonkeyPatch) -> None:
    console = DummyConsole()
    monkeypatch.setattr(smart_utils, "Console", lambda: console)

    class StatusError(Exception):
        def __init__(self, message: str, status_code: int) -> None:
            super().__init__(message)
            self.status_code = status_code

    branches = [
        (401, "Authentication Failed"),
        (400, "Validation Error:"),
        (403, "Permission Denied"),
        (404, "Product Not Found"),
        (409, "Conflict"),
        (429, "Rate Limited"),
        (500, "Server Error (500)"),
    ]

    for status_code, expected in branches:
        console.messages.clear()
        with pytest.raises(typer.Exit):
            smart_utils.handle_api_error(StatusError("boom", status_code), "product", "SKU-1")
        assert any(expected in message for message in console.messages)
