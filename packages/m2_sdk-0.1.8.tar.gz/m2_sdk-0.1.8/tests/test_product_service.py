from __future__ import annotations

import pytest

from m2_sdk.exceptions import ConflictError, NotFoundError, ValidationError
from m2_sdk.models import StockItem
from m2_sdk.services.product_service import ProductService

from .service_fakes import FakeBuilder, FakeClient


def test_product_service_getters_update_and_delete_paths() -> None:
    state = {
        "by_sku": {"sku": "SKU-1", "name": "Alpha", "category_links": [{"category_id": 7}]},
        "by_id": {"items": [{"id": 42, "sku": "SKU-42"}]},
    }

    def resolver(builder: FakeBuilder, operation: str, data):
        if (
            operation == "get"
            and builder.path == "products"
            and builder.kwargs.get("sku") == "SKU-1"
        ):
            return state["by_sku"]
        if (
            operation == "get"
            and builder.path == "products"
            and builder.kwargs.get("entity_id") == "42"
        ):
            return state["by_id"]
        if operation == "put" and builder.kwargs.get("sku") == "SKU-1":
            assert data == {"product": {"price": 12.5}}
            return {"ok": True, **data["product"]}
        if operation == "delete" and builder.kwargs.get("sku") == "SKU-1":
            return {"ok": True}
        raise AssertionError(f"Unexpected call: {builder.path} {operation} {builder.kwargs}")

    service = ProductService(FakeClient(resolver))

    assert service.get_by_sku("SKU-1") == state["by_sku"]
    assert service.get_by_id(42) == state["by_id"]["items"][0]
    assert service.update_price("SKU-1", 12.5) == {"ok": True, "price": 12.5}
    assert service.delete_by_sku("SKU-1") is True


def test_product_service_create_update_upsert_and_remove_category() -> None:
    calls: list[tuple[str, str, dict[str, object] | None]] = []

    def resolver(builder: FakeBuilder, operation: str, data):
        calls.append((builder.path, operation, data))
        if operation == "post":
            if builder.kwargs.get("store_id") == 2 or data:
                assert data is not None
                product = data["product"]
                return {"sku": product["sku"], **product}
            raise ConflictError("duplicate")
        if operation == "put":
            assert data is not None
            product = data["product"]
            if builder.kwargs.get("sku") == "EXISTING":
                return {"sku": "EXISTING", **product}
            if builder.kwargs.get("sku") == "MISSING":
                raise NotFoundError("missing")
            if builder.kwargs.get("sku") == "NO-UPD":
                raise NotFoundError("missing")
            return {"sku": builder.kwargs.get("sku"), **product}
        if operation == "get" and builder.kwargs.get("sku") == "SKU-1":
            return {"sku": "SKU-1", "category_links": [{"category_id": 1}, {"category_id": 2}]}
        if operation == "get" and builder.kwargs.get("sku") == "MISSING":
            raise NotFoundError("missing")
        if operation == "get" and str(builder.kwargs.get("entity_id")) == "1":
            return {"items": [{"name": "No SKU"}]}
        if operation == "get" and str(builder.kwargs.get("entity_id")) == "2":
            return {"items": []}
        if operation == "delete":
            raise NotFoundError("missing")
        return {"ok": True}

    client = FakeClient(resolver)
    service = ProductService(client)

    assert service.create({"sku": "NEW", "name": "Created"})["sku"] == "NEW"
    assert service.create({"sku": "STORE", "name": "Store"}, store_id=2)["sku"] == "STORE"
    assert (
        service.update("EXISTING", {"name": "Updated"}, create_if_missing=False)["sku"]
        == "EXISTING"
    )
    assert (
        service.update("MISSING", {"name": "Fallback"}, create_if_missing=True)["sku"] == "MISSING"
    )
    assert service.upsert({"sku": "EXISTING", "name": "Upserted"})["sku"] == "EXISTING"
    assert service.upsert({"sku": "NO-UPD", "name": "Upserted"})["sku"] == "NO-UPD"
    assert service.remove_category("SKU-1", 2)["category_links"] == [{"category_id": 1}]
    assert service.remove_category("SKU-1", 999)["category_links"] == [
        {"category_id": 1},
        {"category_id": 2},
    ]

    assert any(call[1] == "post" for call in calls)


def test_product_service_update_stock_uses_inventory_endpoint() -> None:
    state = StockItem.model_validate(
        {"sku": "SKU-1", "qty": 5, "is_in_stock": True, "manage_stock": True}
    )

    def resolver(builder: FakeBuilder, operation: str, data):
        nonlocal state
        sku = builder.kwargs.get("sku") or (builder.kwargs.get("_args") or [None])[0]
        if builder.path == "stock_items" and operation == "get" and sku == "SKU-1":
            return state
        if builder.path == "stock_items" and operation == "put" and sku == "SKU-1":
            assert data == {
                "stockItem": {
                    "sku": "SKU-1",
                    "qty": 9,
                    "is_in_stock": False,
                    "manage_stock": True,
                }
            }
            payload = data["stockItem"]
            assert isinstance(payload, dict)
            state = StockItem.model_validate(payload)
            return {"ok": True}
        raise AssertionError(f"Unexpected call: {builder.path} {operation} {builder.kwargs}")

    service = ProductService(FakeClient(resolver))

    updated = service.update_stock("SKU-1", qty=9, is_in_stock=False)

    assert updated["qty"] == 9
    assert updated["sku"] == "SKU-1"


def test_product_service_validation_and_missing_paths() -> None:
    def resolver(builder: FakeBuilder, operation: str, data):
        if operation == "post":
            raise ValidationError("bad payload")
        if operation == "put":
            raise ValidationError("bad update")
        if operation == "get" and builder.kwargs.get("sku") == "NO-SKU":
            return {"name": "broken"}
        if operation == "get" and builder.kwargs.get("sku") == "ABSENT":
            raise NotFoundError("missing")
        return {"sku": builder.kwargs.get("sku")}

    service = ProductService(FakeClient(resolver))

    with pytest.raises(ValidationError, match="sku"):
        service.create({"name": "Missing sku"})

    with pytest.raises(ValidationError, match="Invalid product data"):
        service.create({"sku": "SKU-1"})

    with pytest.raises(ValidationError, match="Invalid product data"):
        service.update("SKU-1", {"name": "bad"})

    with pytest.raises(ValidationError, match="sku"):
        service.upsert({"name": "Missing sku"})

    service.get_by_id = lambda product_id: {"name": "No SKU"}  # type: ignore[method-assign]
    with pytest.raises(NotFoundError, match="Product ID 1 has no SKU"):
        service.delete_by_id(1)

    with pytest.raises(NotFoundError, match="Product ID 2 has no SKU"):
        service.delete_by_id(2)
