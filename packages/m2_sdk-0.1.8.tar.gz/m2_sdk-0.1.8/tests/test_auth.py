from __future__ import annotations

import httpx
import pytest

from m2_sdk.auth import AuthManager
from m2_sdk.exceptions import AuthError


class DummyClient:
    def __init__(self, response: object) -> None:
        self.response = response
        self.calls: list[tuple[str, dict[str, str]]] = []

    def __enter__(self) -> DummyClient:
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        return None

    def post(self, url: str, json: dict[str, str]) -> object:
        self.calls.append((url, json))
        if isinstance(self.response, Exception):
            raise self.response
        return self.response


class DummyAsyncClient:
    def __init__(self, response: object) -> None:
        self.response = response
        self.calls: list[tuple[str, dict[str, str]]] = []

    async def __aenter__(self) -> DummyAsyncClient:
        return self

    async def __aexit__(self, exc_type, exc, tb) -> None:
        return None

    async def post(self, url: str, json: dict[str, str]) -> object:
        self.calls.append((url, json))
        if isinstance(self.response, Exception):
            raise self.response
        return self.response


class TokenResponse:
    def __init__(self, token: object, status_code: int = 200, text: str = "") -> None:
        self._token = token
        self.status_code = status_code
        self.text = text

    def raise_for_status(self) -> None:
        if self.status_code >= 400:
            request = httpx.Request("POST", "https://example.test/V1/integration/admin/token")
            response = httpx.Response(self.status_code, text=self.text, request=request)
            raise httpx.HTTPStatusError("boom", request=request, response=response)

    def json(self) -> object:
        return self._token


def test_get_admin_token_uses_config_credentials(
    monkeypatch: pytest.MonkeyPatch, config_factory
) -> None:
    config = config_factory()
    dummy = DummyClient(TokenResponse("token-123"))
    monkeypatch.setattr("m2_sdk.auth.httpx.Client", lambda timeout: dummy)

    token = AuthManager(config).get_admin_token()

    assert token == "token-123"
    assert dummy.calls == [
        (
            "https://example.test/V1/integration/admin/token",
            {"username": "admin", "password": "secret"},
        )
    ]


def test_get_admin_token_explicit_credentials_override_config(
    monkeypatch: pytest.MonkeyPatch, config_factory
) -> None:
    dummy = DummyClient(TokenResponse("token-override"))
    monkeypatch.setattr("m2_sdk.auth.httpx.Client", lambda timeout: dummy)

    token = AuthManager(config_factory()).get_admin_token("other", "pw")

    assert token == "token-override"
    assert dummy.calls[0][1] == {"username": "other", "password": "pw"}


def test_get_admin_token_missing_credentials_raises(config_factory) -> None:
    config = config_factory(username=None, password=None)

    with pytest.raises(AuthError, match="Username and password required"):
        AuthManager(config).get_admin_token()


def test_get_admin_token_non_string_token_raises(
    monkeypatch: pytest.MonkeyPatch, config_factory
) -> None:
    monkeypatch.setattr(
        "m2_sdk.auth.httpx.Client", lambda timeout: DummyClient(TokenResponse({"x": 1}))
    )

    with pytest.raises(AuthError, match="Unexpected token format"):
        AuthManager(config_factory()).get_admin_token()


def test_get_admin_token_401_maps_to_invalid_credentials(
    monkeypatch: pytest.MonkeyPatch, config_factory
) -> None:
    monkeypatch.setattr(
        "m2_sdk.auth.httpx.Client",
        lambda timeout: DummyClient(TokenResponse(None, status_code=401)),
    )

    with pytest.raises(AuthError, match="Invalid username or password"):
        AuthManager(config_factory()).get_admin_token()


def test_get_admin_token_http_error_includes_response_text(
    monkeypatch: pytest.MonkeyPatch, config_factory
) -> None:
    monkeypatch.setattr(
        "m2_sdk.auth.httpx.Client",
        lambda timeout: DummyClient(TokenResponse(None, status_code=500, text="server sad")),
    )

    with pytest.raises(AuthError, match="Authentication failed: server sad"):
        AuthManager(config_factory()).get_admin_token()


def test_get_admin_token_request_error_maps_to_auth_error(
    monkeypatch: pytest.MonkeyPatch, config_factory
) -> None:
    request = httpx.Request("POST", "https://example.test/V1/integration/admin/token")
    error = httpx.RequestError("offline", request=request)
    monkeypatch.setattr("m2_sdk.auth.httpx.Client", lambda timeout: DummyClient(error))

    with pytest.raises(AuthError, match="Connection error: offline"):
        AuthManager(config_factory()).get_admin_token()


@pytest.mark.asyncio
async def test_async_get_admin_token_success(
    monkeypatch: pytest.MonkeyPatch, config_factory
) -> None:
    dummy = DummyAsyncClient(TokenResponse("async-token"))
    monkeypatch.setattr("m2_sdk.auth.httpx.AsyncClient", lambda timeout: dummy)

    token = await AuthManager(config_factory()).async_get_admin_token()

    assert token == "async-token"
    assert dummy.calls[0][1] == {"username": "admin", "password": "secret"}


@pytest.mark.asyncio
async def test_async_get_admin_token_request_error(
    monkeypatch: pytest.MonkeyPatch, config_factory
) -> None:
    request = httpx.Request("POST", "https://example.test/V1/integration/admin/token")
    error = httpx.RequestError("network down", request=request)
    monkeypatch.setattr("m2_sdk.auth.httpx.AsyncClient", lambda timeout: DummyAsyncClient(error))

    with pytest.raises(AuthError, match="Connection error: network down"):
        await AuthManager(config_factory()).async_get_admin_token()


def test_login_masks_token_in_output(monkeypatch: pytest.MonkeyPatch, config_factory) -> None:
    printed: list[str] = []
    manager = AuthManager(config_factory())
    monkeypatch.setattr(manager, "get_admin_token", lambda username=None, password=None: "x" * 24)
    monkeypatch.setattr("m2_sdk.auth.rprint", printed.append)

    token = manager.login()

    assert token == "x" * 24
    assert any("Authenticated successfully" in line for line in printed)
    assert any("xxxxxxxxxx...xxxxxxxxxx" in line for line in printed)


def test_ensure_token_returns_token(config_factory) -> None:
    manager = AuthManager(config_factory(api_key="present-token"))
    assert manager.ensure_token() == "present-token"


def test_ensure_token_raises_when_missing(config_factory) -> None:
    manager = AuthManager(config_factory(api_key=None, get_token=lambda: None))

    with pytest.raises(AuthError, match="No authentication token found"):
        manager.ensure_token()
