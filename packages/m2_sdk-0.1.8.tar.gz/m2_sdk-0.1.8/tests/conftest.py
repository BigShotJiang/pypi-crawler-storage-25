from __future__ import annotations

from types import SimpleNamespace

import httpx
import pytest

from m2_sdk.client import M2Client


def make_config(**overrides: object) -> SimpleNamespace:
    data: dict[str, object] = {
        "verbose": False,
        "json_output": False,
        "max_retries": 0,
        "retry_delay": 0,
        "api_url": "https://example.test/V1",
        "timeout": 5,
        "username": "admin",
        "password": "secret",
        "api_key": "env-token",
    }
    data.update(overrides)
    data.setdefault("get_token", lambda: data.get("api_key"))
    return SimpleNamespace(**data)


def make_client(**config_overrides: object) -> M2Client:
    config = make_config(**config_overrides)
    auth_manager = SimpleNamespace(get_admin_token=lambda: "token")
    return M2Client(config=config, auth_manager=auth_manager)


def make_response(
    status_code: int = 200,
    *,
    json_data: object | None = None,
    text: str = "",
    headers: dict[str, str] | None = None,
    method: str = "GET",
    url: str = "https://example.test/V1/products",
) -> httpx.Response:
    request = httpx.Request(method, url)
    if json_data is not None:
        return httpx.Response(status_code, json=json_data, headers=headers, request=request)
    return httpx.Response(status_code, text=text, headers=headers, request=request)


@pytest.fixture
def config_factory():
    return make_config


@pytest.fixture
def client_factory():
    return make_client


@pytest.fixture
def response_factory():
    return make_response
