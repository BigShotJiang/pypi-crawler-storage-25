from __future__ import annotations

import pytest

from m2_sdk.middleware.auth import AuthMiddleware


def test_auth_middleware_injects_headers_and_reuses_cached_token(response_factory) -> None:
    refreshes = 0
    seen_headers: list[dict[str, str]] = []

    def refresh_token() -> str:
        nonlocal refreshes
        refreshes += 1
        return "fresh-token"

    middleware = AuthMiddleware(lambda: None, refresh_token)

    def handler(method: str, url: str, **kwargs):
        seen_headers.append(dict(kwargs["headers"]))
        return response_factory(200)

    middleware(handler, "GET", "https://example.test", headers={"X-Test": "1"})
    middleware(handler, "GET", "https://example.test")

    assert refreshes == 1
    assert seen_headers[0]["Authorization"] == "Bearer fresh-token"
    assert seen_headers[0]["Content-Type"] == "application/json"
    assert seen_headers[0]["Accept"] == "application/json"
    assert seen_headers[0]["X-Test"] == "1"
    assert seen_headers[1]["Authorization"] == "Bearer fresh-token"


def test_auth_middleware_retries_once_on_401(response_factory) -> None:
    refreshes = 0
    seen_headers: list[str] = []

    def refresh_token() -> str:
        nonlocal refreshes
        refreshes += 1
        return f"fresh-{refreshes}"

    middleware = AuthMiddleware(lambda: None, refresh_token)
    responses = [response_factory(401), response_factory(200)]

    def handler(method: str, url: str, **kwargs):
        seen_headers.append(kwargs["headers"]["Authorization"])
        return responses.pop(0)

    response = middleware(handler, "GET", "https://example.test")

    assert response.status_code == 200
    assert seen_headers == ["Bearer fresh-1", "Bearer fresh-2"]


@pytest.mark.asyncio
async def test_auth_middleware_async_retries_once_on_401(response_factory) -> None:
    refreshes = 0

    def refresh_token() -> str:
        nonlocal refreshes
        refreshes += 1
        return f"token-{refreshes}"

    middleware = AuthMiddleware(lambda: None, refresh_token)
    responses = [response_factory(401), response_factory(200)]
    headers_seen: list[str] = []

    async def handler(method: str, url: str, **kwargs):
        headers_seen.append(kwargs["headers"]["Authorization"])
        return responses.pop(0)

    response = await middleware.async_call(handler, "GET", "https://example.test")

    assert response.status_code == 200
    assert headers_seen == ["Bearer token-1", "Bearer token-2"]
