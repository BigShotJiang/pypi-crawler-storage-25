from __future__ import annotations

import pytest

from m2_sdk.exceptions import APIError, NotFoundError, ValidationError
from m2_sdk.models import StockItem
from m2_sdk.services.inventory_service import InventoryService

from .service_fakes import FakeBuilder, FakeClient


def test_inventory_service_stock_item_and_update_paths() -> None:
    state = {
        "SKU-1": StockItem.model_validate(
            {"sku": "SKU-1", "qty": 5, "is_in_stock": True, "manage_stock": True}
        )
    }

    def resolver(builder: FakeBuilder, operation: str, data):
        sku = builder.kwargs.get("sku") or (builder.kwargs.get("_args") or [None])[0]
        if builder.path.startswith("stock_items") and operation == "get" and sku == "SKU-1":
            return state["SKU-1"]
        if builder.path.startswith("stock_items") and operation == "get" and sku == "MISSING":
            raise ValidationError("missing")
        if builder.path == "stock_items" and operation == "put" and sku == "SKU-1":
            assert data == {
                "stockItem": {
                    "sku": "SKU-1",
                    "qty": 8,
                    "is_in_stock": True,
                    "manage_stock": True,
                }
            }
            state["SKU-1"] = StockItem.model_validate(
                {"sku": "SKU-1", "qty": 8, "is_in_stock": True, "manage_stock": True}
            )
            return {"ok": True}
        raise AssertionError(f"Unexpected: {builder.path} {operation} {builder.kwargs}")

    service = InventoryService(FakeClient(resolver))

    stock_item = service.get_stock_item("SKU-1")
    stock_items = service.get_stock_items(["SKU-1", "MISSING"])
    updated = service.update_stock_item("SKU-1", qty=8)

    assert stock_item and stock_item.qty == 5
    assert list(stock_items) == ["SKU-1"]
    assert updated.qty == 8


def test_inventory_service_stock_item_update_400_becomes_validation_error() -> None:
    def resolver(builder: FakeBuilder, operation: str, data):
        sku = builder.kwargs.get("sku") or (builder.kwargs.get("_args") or [None])[0]
        if builder.path.startswith("stock_items") and operation == "get" and sku == "SKU-1":
            return StockItem.model_validate(
                {"sku": "SKU-1", "qty": 5, "is_in_stock": True, "manage_stock": True}
            )
        if builder.path == "stock_items" and operation == "put" and sku == "SKU-1":
            raise APIError("Missing required field in request", status_code=400)
        raise AssertionError(f"Unexpected: {builder.path} {operation} {builder.kwargs}")

    service = InventoryService(FakeClient(resolver))

    with pytest.raises(
        ValidationError, match="Invalid stock data: Missing required field in request"
    ):
        service.update_stock_item("SKU-1", qty=8)


def test_inventory_service_update_stock_uses_stock_item_endpoint() -> None:
    state = {
        "SKU-1": StockItem.model_validate(
            {"sku": "SKU-1", "qty": 5, "is_in_stock": True, "manage_stock": True}
        )
    }

    def resolver(builder: FakeBuilder, operation: str, data):
        sku = builder.kwargs.get("sku") or (builder.kwargs.get("_args") or [None])[0]
        if builder.path.startswith("stock_items") and operation == "get" and sku == "SKU-1":
            return state["SKU-1"]
        if builder.path == "stock_items" and operation == "put" and sku == "SKU-1":
            assert data == {
                "stockItem": {
                    "sku": "SKU-1",
                    "qty": 12,
                    "is_in_stock": False,
                    "manage_stock": True,
                }
            }
            state["SKU-1"] = StockItem.model_validate(data["stockItem"])
            return {"ok": True}
        raise AssertionError(f"Unexpected: {builder.path} {operation} {builder.kwargs}")

    service = InventoryService(FakeClient(resolver))

    updated = service.update_stock("SKU-1", qty=12, is_in_stock=False, manage_stock=True)

    assert updated.qty == 12
    assert updated.is_in_stock is False


def test_inventory_service_update_stock_item_falls_back_to_product_stock_item_route() -> None:
    state = {
        "SKU-1": StockItem.model_validate(
            {
                "sku": "SKU-1",
                "item_id": 7,
                "qty": 5,
                "is_in_stock": True,
                "manage_stock": True,
            }
        )
    }

    def resolver(builder: FakeBuilder, operation: str, data):
        sku = builder.kwargs.get("sku") or (builder.kwargs.get("_args") or [None])[0]
        item_id = builder.kwargs.get("item_id") or (builder.kwargs.get("_args") or [None, None])[-1]
        if builder.path.startswith("stock_items") and operation == "get" and sku == "SKU-1":
            return state["SKU-1"]
        if builder.path == "stock_items" and operation == "put" and sku == "SKU-1":
            raise APIError("API endpoint not found", status_code=404)
        if builder.path == "products.stock_items" and operation == "put" and sku == "SKU-1":
            assert item_id == 7
            assert data == {
                "stockItem": {
                    "sku": "SKU-1",
                    "item_id": 7,
                    "qty": 8,
                    "is_in_stock": True,
                    "manage_stock": True,
                }
            }
            state["SKU-1"] = StockItem.model_validate(data["stockItem"])
            return {"ok": True}
        raise AssertionError(f"Unexpected: {builder.path} {operation} {builder.kwargs}")

    service = InventoryService(FakeClient(resolver))

    updated = service.update_stock_item("SKU-1", qty=8)

    assert updated.qty == 8


def test_inventory_service_update_stock_item_raises_when_both_routes_fail() -> None:
    def resolver(builder: FakeBuilder, operation: str, data):
        sku = builder.kwargs.get("sku") or (builder.kwargs.get("_args") or [None])[0]
        if builder.path.startswith("stock_items") and operation == "get" and sku == "SKU-1":
            return StockItem.model_validate(
                {
                    "sku": "SKU-1",
                    "item_id": 7,
                    "qty": 5,
                    "is_in_stock": True,
                    "manage_stock": True,
                }
            )
        if builder.path == "stock_items" and operation == "put" and sku == "SKU-1":
            raise APIError("API endpoint not found", status_code=404)
        if builder.path == "products.stock_items" and operation == "put" and sku == "SKU-1":
            raise APIError("Fallback endpoint failed", status_code=404)
        raise AssertionError(f"Unexpected: {builder.path} {operation} {builder.kwargs}")

    service = InventoryService(FakeClient(resolver))

    with pytest.raises(APIError, match="Fallback endpoint failed"):
        service.update_stock_item("SKU-1", qty=8)


def test_inventory_service_msi_and_fallbacks(monkeypatch: pytest.MonkeyPatch) -> None:
    msi_checks = 0

    def resolver(builder: FakeBuilder, operation: str, data):
        nonlocal msi_checks
        if builder.path.startswith("inventory.sources") and operation == "get":
            msi_checks += 1
            return {"items": [{"code": "default"}]}

        if builder.path.startswith("inventory.source_items") and operation == "post":
            return {"items": data["sourceItems"]}

        if builder.path.startswith("inventory.source_items") and operation == "get":
            return {"items": [{"sku": "SKU-1", "source_code": "default"}]}

        if (
            builder.path.startswith("inventory.salable")
            and "are_product_salable" not in builder.path
            and operation == "get"
        ):
            return {"salable_qty": 3}

        if builder.path.endswith("are_product_salable") and operation == "get":
            return {"items": [{"is_salable": True}]}

        if builder.path.startswith("inventory.stocks") and operation == "get":
            return {"items": [{"stock_id": 1}]}

        if builder.path.startswith("inventory.stock_source_links") and operation == "post":
            return {"ok": True}

        if builder.path.startswith("inventory.low_stock") and operation == "get":
            return {"items": [{"sku": "SKU-LOW", "qty": 2}]}

        if (
            builder.path == "products"
            and operation == "get"
            and builder.kwargs.get("sku") == "SKU-LOW"
        ):
            return {"sku": "SKU-LOW", "name": "Low", "stock_item": {"qty": 2, "is_in_stock": True}}

        if (
            builder.path == "products"
            and operation == "get"
            and builder.kwargs.get("sku") == "SKU-1"
        ):
            return {"sku": "SKU-1", "stock_item": {"qty": 10, "is_in_stock": True}}

        if (
            builder.path == "products"
            and operation == "get"
            and builder.kwargs.get("sku") == "SKU-2"
        ):
            return {"items": [{"sku": "SKU-2"}]}

        return {"items": []} if operation == "get" else {"ok": True}

    service = InventoryService(FakeClient(resolver))

    assert service._check_msi() is True
    assert service.get_source_items("SKU-1") == [{"sku": "SKU-1", "source_code": "default"}]
    assert service.update_source_item("SKU-1", "default", 2)["items"][0]["sku"] == "SKU-1"
    assert service.get_salable_qty("SKU-1") == 3.0
    assert service.check_is_salable("SKU-1", qty=2) is True
    assert service.get_sources() == [{"code": "default"}]
    assert service.get_stocks() == [{"stock_id": 1}]
    assert service.assign_source_to_stock("default", 1) == {"ok": True}
    assert service.low_stock_report(5.0) == [{"sku": "SKU-LOW", "qty": 2}]
    assert msi_checks == 2


def test_inventory_service_bulk_and_not_found_paths() -> None:
    def resolver(builder: FakeBuilder, operation: str, data):
        if builder.path.startswith("inventory.sources") and operation == "get":
            return {"items": [{"code": "default"}]}
        if builder.path == "products" and operation == "get" and builder.kwargs.get("sku") == "A":
            return {"sku": "A", "stock_item": {"qty": 1, "is_in_stock": True, "manage_stock": True}}
        if builder.path == "products" and operation == "put" and builder.kwargs.get("sku") == "A":
            return {"ok": True}
        if (
            builder.path == "products"
            and operation == "put"
            and builder.kwargs.get("sku") == "MISSING"
        ):
            raise ValidationError("bad")
        if builder.path.endswith("are_product_salable") and operation == "get":
            raise ValidationError("oops")
        if builder.path == "products" and operation == "get" and builder.kwargs.get("sku") == "B":
            return {"sku": "B", "stock_item": {"qty": 0, "is_in_stock": False}}
        if builder.path == "products" and operation == "get" and builder.kwargs.get("sku") == "LOW":
            return {"sku": "LOW", "stock_item": {"qty": 0, "is_in_stock": False}}
        if builder.path == "products" and operation == "get" and builder.kwargs.get("page") == 1:
            return {"items": [{"sku": "LOW"}], "total_count": 1}
        if builder.path.startswith("inventory.source_items") and operation == "post":
            return {"ok": True}
        raise NotFoundError("missing")

    service = InventoryService(FakeClient(resolver))

    assert service.bulk_update_source_items(
        [{"sku": "A", "source_code": "default", "quantity": 2}]
    ) == [{"ok": True}]
    assert service.bulk_update_source_items(
        [
            {"sku": "A", "source_code": "default", "quantity": 2},
            {"sku": "MISSING", "source_code": "default", "quantity": 2},
        ],
        stop_on_error=True,
    )[0] == {"ok": True}

    def no_msi_resolver(builder: FakeBuilder, operation: str, data):
        if builder.path.startswith("inventory.sources") and operation == "get":
            raise ValidationError("no msi")
        return {"ok": True}

    with pytest.raises(NotFoundError, match="MSI not available"):
        InventoryService(FakeClient(no_msi_resolver)).assign_source_to_stock("default", 1)

    with pytest.raises(ValidationError, match="No stock item fields provided"):
        service.update_stock_item("A")

    assert service.get_source_items() == []
    assert service.get_salable_qty("B") == 0.0
    assert service.check_is_salable("B") is False
