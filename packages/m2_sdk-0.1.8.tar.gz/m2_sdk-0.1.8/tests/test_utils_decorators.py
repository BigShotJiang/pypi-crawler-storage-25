from __future__ import annotations

import sys
from types import ModuleType

import pytest

from m2_sdk import utils


class DummyClient:
    def __init__(self, config, auth_manager) -> None:
        self.config = config
        self.auth_manager = auth_manager

    def __enter__(self) -> DummyClient:
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        return None


def test_with_m2_client_injects_client_and_preserves_metadata(
    monkeypatch: pytest.MonkeyPatch, config_factory
) -> None:
    seen: dict[str, object] = {}
    config = config_factory()
    monkeypatch.setattr("m2_sdk.utils.get_config", lambda: config)
    monkeypatch.setattr("m2_sdk.utils.M2Client", DummyClient)

    class DummyAuthManager:
        def __init__(self, incoming_config) -> None:
            seen["auth_config"] = incoming_config

    auth_module = ModuleType("m2_sdk.auth")
    auth_module.AuthManager = DummyAuthManager
    monkeypatch.setitem(sys.modules, "m2_sdk.auth", auth_module)

    @utils.with_m2_client
    def command(client: DummyClient, value: str) -> str:
        seen["client"] = client
        return value.upper()

    result = command("hello")

    assert result == "HELLO"
    assert command.__name__ == "command"
    assert command.__inject_m2_client__ is True
    assert isinstance(seen["client"], DummyClient)
    assert seen["auth_config"] is config


def test_with_error_handling_delegates_and_extracts_resource_id(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    captured: dict[str, object] = {}

    def handle_api_error(
        error: Exception, resource_type: str, resource_id: str | None = None
    ) -> None:
        captured["error"] = error
        captured["resource_type"] = resource_type
        captured["resource_id"] = resource_id

    smart_utils = ModuleType("m2_sdk.smart_utils")
    smart_utils.handle_api_error = handle_api_error
    monkeypatch.setitem(sys.modules, "m2_sdk.smart_utils", smart_utils)

    @utils.with_error_handling("product")
    def command(sku: str) -> None:
        raise RuntimeError("broken")

    command("SKU-1")

    assert str(captured["error"]) == "broken"
    assert captured["resource_type"] == "product"
    assert captured["resource_id"] == "SKU-1"


def test_with_error_handling_uses_kwarg_resource_id(monkeypatch: pytest.MonkeyPatch) -> None:
    captured: dict[str, object] = {}

    def handle_api_error(
        error: Exception, resource_type: str, resource_id: str | None = None
    ) -> None:
        captured["resource_id"] = resource_id

    smart_utils = ModuleType("m2_sdk.smart_utils")
    smart_utils.handle_api_error = handle_api_error
    monkeypatch.setitem(sys.modules, "m2_sdk.smart_utils", smart_utils)

    @utils.with_error_handling("order")
    def command(*, id: int) -> None:
        raise RuntimeError("boom")

    command(id=42)

    assert captured["resource_id"] == "42"
