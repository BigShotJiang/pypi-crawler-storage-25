from __future__ import annotations

import base64
import sys
import types
from pathlib import Path

import pytest

from m2_sdk.exceptions import NotFoundError, ValidationError
from m2_sdk.services.media_service import MediaService

from .service_fakes import FakeBuilder, FakeClient


def test_media_service_get_image_data_from_bytes_file_and_url(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    file_path = tmp_path / "image.jpg"
    file_path.write_bytes(b"file-bytes")

    class DummyResponse:
        content = b"url-bytes"

        def raise_for_status(self) -> None:
            return None

    monkeypatch.setitem(
        sys.modules,
        "httpx",
        types.SimpleNamespace(get=lambda url, timeout: DummyResponse()),
    )

    service = MediaService(FakeClient(lambda b, o, d: {"ok": True}))

    assert service._get_image_data(b"raw") == b"raw"
    assert service._get_image_data(file_path) == b"file-bytes"
    assert service._get_image_data("https://example.test/image.jpg") == b"url-bytes"

    with pytest.raises(ValidationError, match="Invalid image source type"):
        service._get_image_data(123)  # type: ignore[arg-type]


def test_media_service_upload_update_delete_and_roles(tmp_path: Path) -> None:
    media_state = {
        "SKU-1": [
            {"id": 1, "file": "/i/a.jpg", "types": ["image"], "position": 1, "disabled": False},
            {"id": 2, "file": "/i/b.jpg", "types": ["thumbnail"], "position": 2, "disabled": False},
        ]
    }
    updated: list[tuple[str, str, object]] = []

    def resolver(builder: FakeBuilder, operation: str, data):
        sku = builder.kwargs.get("sku")
        media_id = builder.kwargs.get("id")
        if (
            operation == "get"
            and builder.path == "products.media"
            and sku == "SKU-1"
            and media_id is None
        ):
            return media_state["SKU-1"]
        if (
            operation == "get"
            and builder.path == "products.media"
            and sku == "SKU-1"
            and media_id in {1, 2}
        ):
            return media_state["SKU-1"][0 if media_id == 1 else 1]
        if operation == "post" and builder.path == "products.media" and sku == "SKU-1":
            updated.append(("post", sku, data))
            return {"id": 3, **data["entry"]}
        if (
            operation == "put"
            and builder.path == "products.media"
            and sku == "SKU-1"
            and media_id in {1, 2}
        ):
            updated.append(("put", sku, data))
            return {"id": media_id, **data["entry"]}
        if (
            operation == "delete"
            and builder.path == "products.media"
            and sku == "SKU-1"
            and media_id in {1, 2}
        ):
            updated.append(("delete", sku, data))
            return {"ok": True}
        raise AssertionError(f"Unexpected: {builder.path} {operation} {builder.kwargs}")

    service = MediaService(FakeClient(resolver))

    image_path = tmp_path / "a.jpg"
    image_path.write_bytes(b"hello")

    uploaded = service.upload_image(
        "SKU-1", image_path, label="Label", types=["image"], replace_existing=True
    )
    updated_meta = service.update_image("SKU-1", 1, label="New")
    roles = service.set_image_roles("SKU-1", 1, ["image", "thumbnail"])
    deleted = service.delete_image("SKU-1", 2)
    main_image = service.get_main_image("SKU-1")
    reordered = service.reorder_images("SKU-1", [1, 2])
    main_set = service.set_main_image("SKU-1", 1)

    assert uploaded["label"] == "Label"
    assert updated_meta["label"] == "New"
    assert roles["types"] == ["image", "thumbnail"]
    assert deleted is True
    assert main_image["id"] == 1
    assert [item["id"] for item in reordered] == [1, 2]
    assert main_set["types"] == ["image", "small_image", "thumbnail"]
    assert any(call[0] == "post" for call in updated)
    upload_call = next(call for call in updated if call[0] == "post")
    upload_data = upload_call[2]
    assert isinstance(upload_data, dict)
    assert upload_data["entry"]["content"]["base64_encoded_data"] == base64.b64encode(
        b"hello"
    ).decode("ascii")


def test_media_service_bulk_and_not_found_behaviour(monkeypatch: pytest.MonkeyPatch) -> None:
    def resolver(builder: FakeBuilder, operation: str, data):
        sku = builder.kwargs.get("sku")
        media_id = builder.kwargs.get("id")
        if operation == "get" and builder.path == "products.media" and sku == "SKU-1":
            return []
        if operation == "get" and builder.path == "products.media" and sku == "SKU-2":
            return {"id": 9, "types": ["image"], "position": 1, "disabled": False}
        if (
            operation == "delete"
            and builder.path == "products.media"
            and sku == "SKU-2"
            and media_id == 9
        ):
            raise NotFoundError("missing")
        if operation == "post" and builder.path == "products.media" and sku == "SKU-2":
            raise ValidationError("bad image")
        return {"id": media_id or 0, "types": ["image"], "disabled": False}

    service = MediaService(FakeClient(resolver))

    assert service.delete_all_images("SKU-1") == 0
    assert service.delete_image("SKU-2", 9, ignore_missing=True) is False

    results = service.upload_multiple(
        "SKU-2",
        [{"path": b"1"}, {"path": b"2"}],
        stop_on_error=True,
    )

    assert len(results) == 1
    assert isinstance(results[0], ValidationError)
