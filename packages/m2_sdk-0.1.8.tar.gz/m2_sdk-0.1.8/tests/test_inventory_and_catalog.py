import asyncio
from types import SimpleNamespace
from typing import Any

import pytest

from m2_sdk.client import M2Client
from m2_sdk.exceptions import APIError, ValidationError
from m2_sdk.services.inventory_service import InventoryService


def make_client() -> M2Client:
    config = SimpleNamespace(
        verbose=False,
        max_retries=0,
        retry_delay=0,
        api_url="https://example.test/V1",
        timeout=5,
        get_token=lambda: "token",
    )
    auth_manager = SimpleNamespace(get_admin_token=lambda: "token")
    return M2Client(config=config, auth_manager=auth_manager)


def test_inventory_service_returns_typed_stock_items(monkeypatch: pytest.MonkeyPatch) -> None:
    client = make_client()
    requests: list[tuple[str, str]] = []

    def request(method: str, path: str, params=None, json_data=None):
        requests.append((method, path))
        if path == "/stockItems/SKU-1":
            return {"sku": "SKU-1", "qty": 5, "is_in_stock": True, "manage_stock": True}
        if path == "/stockItems/SKU-2":
            return {"sku": "SKU-2", "qty": 0, "is_in_stock": False, "manage_stock": True}
        raise AssertionError(f"Unexpected request: {method} {path}")

    monkeypatch.setattr(client, "request", request)

    service = InventoryService(client)
    stock_item = service.get_stock_item("SKU-1")
    stock_items = service.get_stock_items(["SKU-1", "SKU-2"])

    assert stock_item is not None
    assert stock_item.qty == 5
    assert stock_item.is_in_stock is True
    assert stock_items["SKU-2"].is_in_stock is False
    assert requests[0] == ("GET", "/stockItems/SKU-1")


def test_update_stock_item_fetches_updated_typed_state(monkeypatch: pytest.MonkeyPatch) -> None:
    client = make_client()
    state = {
        "sku": "SKU-1",
        "item_id": 7,
        "product_id": 11,
        "stock_id": 1,
        "qty": 5,
        "is_in_stock": True,
        "manage_stock": True,
    }
    updates: list[dict[str, Any]] = []

    def request(method: str, path: str, params=None, json_data=None):
        if method == "GET" and path == "/stockItems/SKU-1":
            return dict(state)
        if method == "PUT" and path == "/stockItems/SKU-1":
            assert isinstance(json_data, dict)
            updates.append(json_data)
            state.update(json_data["stockItem"])
            return {"ok": True}
        raise AssertionError(f"Unexpected request: {method} {path}")

    monkeypatch.setattr(client, "request", request)

    service = InventoryService(client)
    updated = service.update_stock_item("SKU-1", qty=8)

    assert updates == [
        {
            "stockItem": {
                "sku": "SKU-1",
                "item_id": 7,
                "product_id": 11,
                "stock_id": 1,
                "qty": 8,
                "is_in_stock": True,
                "manage_stock": True,
            }
        }
    ]
    assert updated.qty == 8
    assert updated.manage_stock is True


def test_update_stock_item_falls_back_after_primary_404(monkeypatch: pytest.MonkeyPatch) -> None:
    client = make_client()
    state = {
        "sku": "SKU-1",
        "item_id": 7,
        "product_id": 11,
        "stock_id": 1,
        "qty": 5,
        "is_in_stock": True,
        "manage_stock": True,
    }
    updates: list[tuple[str, dict[str, Any]]] = []

    def request(method: str, path: str, params=None, json_data=None):
        if method == "GET" and path == "/stockItems/SKU-1":
            return dict(state)
        if method == "PUT" and path == "/stockItems/SKU-1":
            raise APIError("API endpoint not found", status_code=404)
        if method == "PUT" and path == "/products/SKU-1/stockItems/7":
            assert isinstance(json_data, dict)
            updates.append((path, json_data))
            state.update(json_data["stockItem"])
            return {"ok": True}
        raise AssertionError(f"Unexpected request: {method} {path}")

    monkeypatch.setattr(client, "request", request)

    service = InventoryService(client)
    updated = service.update_stock_item("SKU-1", qty=8)

    assert updates == [
        (
            "/products/SKU-1/stockItems/7",
            {
                "stockItem": {
                    "sku": "SKU-1",
                    "item_id": 7,
                    "product_id": 11,
                    "stock_id": 1,
                    "qty": 8,
                    "is_in_stock": True,
                    "manage_stock": True,
                }
            },
        )
    ]
    assert updated.qty == 8


def test_update_stock_item_both_paths_failing_raises_original_error(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    client = make_client()

    def request(method: str, path: str, params=None, json_data=None):
        if method == "GET" and path == "/stockItems/SKU-1":
            return {
                "sku": "SKU-1",
                "item_id": 7,
                "qty": 5,
                "is_in_stock": True,
                "manage_stock": True,
            }
        if method == "PUT" and path == "/stockItems/SKU-1":
            raise APIError("API endpoint not found", status_code=404)
        if method == "PUT" and path == "/products/SKU-1/stockItems/7":
            assert isinstance(json_data, dict)
            raise APIError("Fallback endpoint failed", status_code=404)
        raise AssertionError(f"Unexpected request: {method} {path}")

    monkeypatch.setattr(client, "request", request)

    service = InventoryService(client)

    with pytest.raises(APIError, match="Fallback endpoint failed"):
        service.update_stock_item("SKU-1", qty=8)


def test_update_stock_item_400_maps_to_validation_error(monkeypatch: pytest.MonkeyPatch) -> None:
    client = make_client()

    def request(method: str, path: str, params=None, json_data=None):
        if method == "GET" and path == "/stockItems/SKU-1":
            return {"sku": "SKU-1", "qty": 5, "is_in_stock": True, "manage_stock": True}
        if method == "PUT" and path == "/stockItems/SKU-1":
            assert isinstance(json_data, dict)
            raise APIError("Missing required field in request", status_code=400)
        raise AssertionError(f"Unexpected request: {method} {path}")

    monkeypatch.setattr(client, "request", request)

    service = InventoryService(client)

    with pytest.raises(
        ValidationError, match="Invalid stock data: Missing required field in request"
    ):
        service.update_stock_item("SKU-1", qty=8)


def test_iter_pages_preserves_filters_and_resource_aliases(monkeypatch: pytest.MonkeyPatch) -> None:
    client = make_client()
    calls: list[tuple[str, dict[str, object] | None]] = []

    def request(method: str, path: str, params=None, json_data=None):
        calls.append((path, params))

        if path == "/inventory/source-items":
            return {"items": [{"sku": "SKU-1"}], "total_count": 1}

        page = int(params["searchCriteria[currentPage]"])
        if page == 1:
            return {"items": [{"sku": "SKU-1"}, {"sku": "SKU-2"}], "total_count": 3}
        if page == 2:
            return {"items": [{"sku": "SKU-3"}], "total_count": 3}
        return {"items": [], "total_count": 3}

    monkeypatch.setattr(client, "request", request)

    source_items = client.inventory.source_items().get()
    pages = list(client.products.filter(status="1").iter_pages(page_size=2))

    assert source_items["items"][0]["sku"] == "SKU-1"
    assert [len(page["items"]) for page in pages] == [2, 1]
    assert calls[1][0] == "/products"
    assert calls[1][1]["searchCriteria[filterGroups][0][filters][0][field]"] == "status"
    assert calls[1][1]["searchCriteria[currentPage]"] == "1"
    assert calls[2][1]["searchCriteria[currentPage]"] == "2"


def test_catalog_enrichment_uses_alias_paths(monkeypatch: pytest.MonkeyPatch) -> None:
    client = make_client()
    seen_paths: list[str] = []

    def request(method: str, path: str, params=None, json_data=None):
        seen_paths.append(path)
        if path == "/products":
            return {
                "items": [
                    {"sku": "SKU-1", "name": "Alpha"},
                    {"sku": "SKU-2", "name": "Beta"},
                ],
                "total_count": 2,
            }
        if path == "/stockItems/SKU-1":
            return {"sku": "SKU-1", "qty": 5, "is_in_stock": True}
        if path == "/stockItems/SKU-2":
            return {"sku": "SKU-2", "qty": 0, "is_in_stock": False}
        raise AssertionError(f"Unexpected request: {method} {path}")

    monkeypatch.setattr(client, "request", request)

    catalog = client.catalog("products", enrich={"stock": "stock_items/{sku}"}, page_size=2)

    assert catalog["SKU-1"]["stock"]["qty"] == 5
    assert catalog["SKU-2"]["stock"]["is_in_stock"] is False
    assert "/stockItems/SKU-1" in seen_paths


@pytest.mark.asyncio
async def test_acatalog_and_aiter_pages(monkeypatch: pytest.MonkeyPatch) -> None:
    client = make_client()

    async def async_request(method: str, path: str, params=None, json_data=None):
        if path == "/products":
            page = int(params["searchCriteria[currentPage]"])
            if page == 1:
                return {"items": [{"sku": "SKU-1"}], "total_count": 2}
            if page == 2:
                return {"items": [{"sku": "SKU-2"}], "total_count": 2}
            return {"items": [], "total_count": 2}
        if path == "/stockItems/SKU-1":
            return {"sku": "SKU-1", "qty": 3, "is_in_stock": True}
        if path == "/stockItems/SKU-2":
            return {"sku": "SKU-2", "qty": 1, "is_in_stock": True}
        raise AssertionError(f"Unexpected request: {method} {path}")

    monkeypatch.setattr(client, "async_request", async_request)

    pages = []
    async for page in client.products.aiter_pages(page_size=1):
        pages.append(page)

    catalog = await client.acatalog("products", enrich={"stock": "stock_items/{sku}"}, page_size=1)

    assert [page["items"][0]["sku"] for page in pages] == ["SKU-1", "SKU-2"]
    assert catalog["SKU-1"]["stock"]["qty"] == 3
    assert catalog["SKU-2"]["stock"]["qty"] == 1


@pytest.mark.asyncio
async def test_acatalog_can_use_concurrent_pagination(monkeypatch: pytest.MonkeyPatch) -> None:
    client = make_client()

    async def async_request(method: str, path: str, params=None, json_data=None):
        assert method == "GET"

        if path == "/products":
            page = int(params["searchCriteria[currentPage]"])
            if page == 1:
                await asyncio.sleep(0)
                return {"items": [{"sku": "SKU-1", "name": "Alpha"}], "total_count": 3}
            if page == 2:
                await asyncio.sleep(0.05)
                return {"items": [{"sku": "SKU-2", "name": "Beta"}], "total_count": 3}
            if page == 3:
                await asyncio.sleep(0.01)
                return {"items": [{"sku": "SKU-3", "name": "Gamma"}], "total_count": 3}
            return {"items": [], "total_count": 3}

        raise AssertionError(f"Unexpected request: {method} {path}")

    monkeypatch.setattr(client, "async_request", async_request)

    catalog = await client.acatalog(
        "products",
        page_size=1,
        concurrency=2,
        yield_order="completion",
    )

    assert list(catalog) == ["SKU-1", "SKU-3", "SKU-2"]
    assert catalog["SKU-2"]["name"] == "Beta"


@pytest.mark.asyncio
async def test_aiter_pages_concurrent_preserves_page_order(monkeypatch: pytest.MonkeyPatch) -> None:
    client = make_client()
    active_requests = 0
    max_active_requests = 0
    call_order: list[int] = []

    async def async_request(method: str, path: str, params=None, json_data=None):
        nonlocal active_requests, max_active_requests

        assert method == "GET"
        assert path == "/products"

        page = int(params["searchCriteria[currentPage]"])
        call_order.append(page)
        active_requests += 1
        max_active_requests = max(max_active_requests, active_requests)

        try:
            if page == 1:
                await asyncio.sleep(0)
                return {"items": [{"sku": "SKU-1"}], "total_count": 4}
            if page == 2:
                await asyncio.sleep(0.05)
                return {"items": [{"sku": "SKU-2"}], "total_count": 4}
            if page == 3:
                await asyncio.sleep(0.01)
                return {"items": [{"sku": "SKU-3"}], "total_count": 4}
            if page == 4:
                await asyncio.sleep(0.01)
                return {"items": [{"sku": "SKU-4"}], "total_count": 4}
            return {"items": [], "total_count": 4}
        finally:
            active_requests -= 1

    monkeypatch.setattr(client, "async_request", async_request)

    pages = []
    async for page in client.products.aiter_pages_concurrent(page_size=1, concurrency=2):
        pages.append(page)

    assert [page["items"][0]["sku"] for page in pages] == ["SKU-1", "SKU-2", "SKU-3", "SKU-4"]
    assert call_order[0] == 1
    assert sorted(call_order) == [1, 2, 3, 4]
    assert max_active_requests <= 2


@pytest.mark.asyncio
async def test_aiter_pages_concurrent_can_yield_in_completion_order(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    client = make_client()
    active_requests = 0
    max_active_requests = 0

    async def async_request(method: str, path: str, params=None, json_data=None):
        nonlocal active_requests, max_active_requests

        assert method == "GET"
        assert path == "/products"

        page = int(params["searchCriteria[currentPage]"])
        active_requests += 1
        max_active_requests = max(max_active_requests, active_requests)

        try:
            if page == 1:
                await asyncio.sleep(0)
                return {"items": [{"sku": "SKU-1"}], "total_count": 4}
            if page == 2:
                await asyncio.sleep(0.05)
                return {"items": [{"sku": "SKU-2"}], "total_count": 4}
            if page == 3:
                await asyncio.sleep(0.01)
                return {"items": [{"sku": "SKU-3"}], "total_count": 4}
            if page == 4:
                await asyncio.sleep(0.01)
                return {"items": [{"sku": "SKU-4"}], "total_count": 4}
            return {"items": [], "total_count": 4}
        finally:
            active_requests -= 1

    monkeypatch.setattr(client, "async_request", async_request)

    pages = []
    async for page in client.products.aiter_pages_concurrent(
        page_size=1,
        concurrency=2,
        yield_order="completion",
    ):
        pages.append(page)

    assert [page["items"][0]["sku"] for page in pages] == ["SKU-1", "SKU-3", "SKU-4", "SKU-2"]
    assert max_active_requests <= 2


@pytest.mark.asyncio
async def test_aiter_pages_concurrent_falls_back_without_total_count(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    client = make_client()
    seen_pages: list[int] = []

    async def async_request(method: str, path: str, params=None, json_data=None):
        assert method == "GET"
        assert path == "/products"

        page = int(params["searchCriteria[currentPage]"])
        seen_pages.append(page)

        if page == 1:
            return {"items": [{"sku": "SKU-1"}]}
        if page == 2:
            return {"items": [{"sku": "SKU-2"}]}
        return {"items": []}

    monkeypatch.setattr(client, "async_request", async_request)

    pages = []
    async for page in client.products.aiter_pages_concurrent(page_size=1, concurrency=3):
        pages.append(page)

    assert [page.get("items", []) for page in pages] == [
        [{"sku": "SKU-1"}],
        [{"sku": "SKU-2"}],
        [],
    ]
    assert seen_pages == [1, 2, 3]


@pytest.mark.asyncio
async def test_aiter_pages_concurrent_rejects_invalid_options() -> None:
    client = make_client()

    with pytest.raises(ValueError, match="concurrency"):
        await anext(client.products.aiter_pages_concurrent(concurrency=0))

    with pytest.raises(ValueError, match="yield_order"):
        await anext(client.products.aiter_pages_concurrent(yield_order="invalid"))
