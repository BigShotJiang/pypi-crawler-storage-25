from __future__ import annotations

import json

import pytest

from m2_sdk.middleware.logging import LoggingMiddleware, StructuredLogEntry


def test_structured_log_entry_to_dict_and_rich_string(monkeypatch: pytest.MonkeyPatch) -> None:
    entry = StructuredLogEntry("abcd1234", "GET", "https://example.test", 10.0)
    entry.end_time = 10.25
    entry.status_code = 200

    assert entry.to_dict()["duration_ms"] == 250.0
    assert entry.to_rich_string() == "[abcd1234] GET 200 (250.0ms)"


def test_logging_middleware_logs_json_request_and_response(
    monkeypatch: pytest.MonkeyPatch, response_factory
) -> None:
    printed: list[str] = []
    uuids = iter(["abcd1234-uuid"])
    times = iter([1.0, 1.5, 1.5])
    middleware = LoggingMiddleware(verbose=True, json_output=True)
    monkeypatch.setattr("builtins.print", printed.append)
    monkeypatch.setattr("m2_sdk.middleware.logging.uuid.uuid4", lambda: next(uuids))
    monkeypatch.setattr("m2_sdk.middleware.logging.time.time", lambda: next(times))

    response = middleware(
        lambda method, url, **kwargs: response_factory(201),
        "POST",
        "https://example.test",
        params={"page": 1},
        json={"sku": "SKU-1"},
    )

    assert response.status_code == 201
    request_log = json.loads(printed[0])
    response_log = json.loads(printed[1])
    assert request_log["event"] == "request"
    assert request_log["params"] == {"page": 1}
    assert request_log["body_preview"] == '{"sku": "SKU-1"}'
    assert response_log["event"] == "response"
    assert response_log["status_code"] == 201
    assert response_log["duration_ms"] == 500.0


def test_logging_middleware_truncates_body_preview() -> None:
    middleware = LoggingMiddleware(verbose=True, max_body_preview=5)
    assert middleware._truncate_preview("abcdefgh") == "abcde..."


@pytest.mark.asyncio
async def test_logging_middleware_async_logs_error(monkeypatch: pytest.MonkeyPatch) -> None:
    printed: list[str] = []
    times = iter([2.0, 2.2])
    middleware = LoggingMiddleware(verbose=True, json_output=False)
    monkeypatch.setattr("m2_sdk.middleware.logging.rprint", printed.append)
    monkeypatch.setattr("m2_sdk.middleware.logging.time.time", lambda: next(times))

    async def handler(method: str, url: str, **kwargs):
        raise RuntimeError("boom")

    with pytest.raises(RuntimeError, match="boom"):
        await middleware.async_call(handler, "GET", "https://example.test")

    assert any("→ GET https://example.test" in line for line in printed)
    assert any("ERROR: boom" in line for line in printed)
