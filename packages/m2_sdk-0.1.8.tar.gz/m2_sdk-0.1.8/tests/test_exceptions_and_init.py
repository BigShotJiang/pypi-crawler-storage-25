from __future__ import annotations

from importlib import reload
from importlib.metadata import PackageNotFoundError

import pytest

import m2_sdk
from m2_sdk.exceptions import (
    APIError,
    ConflictError,
    NotFoundError,
    RateLimitError,
    ServerError,
    ValidationError,
)


def test_exception_fields() -> None:
    api = APIError("boom", status_code=500, response_body="x", request_info={"m": 1})
    nf = NotFoundError("missing", resource_type="product", resource_id="SKU-1")
    cf = ConflictError("dup", resource_type="product", resource_id="SKU-1")
    ve = ValidationError("bad", field_errors={"sku": "required"})
    rl = RateLimitError("slow", retry_after=3)
    se = ServerError("oops", status_code=502)

    assert api.status_code == 500 and api.response_body == "x"
    assert nf.status_code == 404 and nf.resource_id == "SKU-1"
    assert cf.status_code == 409 and cf.resource_type == "product"
    assert ve.status_code == 400 and ve.field_errors == {"sku": "required"}
    assert rl.status_code == 429 and rl.retry_after == 3
    assert se.status_code == 502


def test_init_version_fallback(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(
        "importlib.metadata.version", lambda name: (_ for _ in ()).throw(PackageNotFoundError())
    )
    reloaded = reload(m2_sdk)
    assert reloaded.__version__ == "0.0.0"
