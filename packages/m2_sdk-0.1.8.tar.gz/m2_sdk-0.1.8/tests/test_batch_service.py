from __future__ import annotations

from pathlib import Path

from m2_sdk.catalog import CatalogStore
from m2_sdk.exceptions import APIError
from m2_sdk.services.batch_service import BatchService

from .service_fakes import FakeBuilder, FakeClient


def test_batch_service_iter_products_iter_catalog_and_sync(tmp_path: Path) -> None:
    def resolver(builder: FakeBuilder, operation: str, data):
        page = builder.kwargs.get("page")
        if builder.path == "products" and operation == "get" and page == 1:
            return {
                "items": [
                    {"sku": "SKU-1", "id": 1, "name": "Alpha"},
                    {"sku": "SKU-2", "id": 2, "name": "Beta"},
                ],
                "total_count": 3,
            }
        if builder.path == "products" and operation == "get" and page == 2:
            return {"items": [{"sku": "SKU-3", "id": 3, "name": "Gamma"}], "total_count": 3}
        raise AssertionError(f"Unexpected: {builder.path} {operation} {builder.kwargs}")

    service = BatchService(FakeClient(resolver))

    products = list(service.iter_products(batch_size=2))
    catalog = list(service.iter_catalog(batch_size=2))
    store = CatalogStore(tmp_path / "catalog.db")

    try:
        synced = service.sync_to_store(store, batch_size=2)

        assert [item["sku"] for item in products] == ["SKU-1", "SKU-2", "SKU-3"]
        assert catalog[0] == ("SKU-1", {"sku": "SKU-1", "id": 1, "name": "Alpha"})
        assert synced == 3
        assert store.count() == 3
    finally:
        store.close()


def test_batch_service_batch_fetches_fall_back_to_individuals() -> None:
    def resolver(builder: FakeBuilder, operation: str, data):
        if builder.path == "products" and operation == "get" and builder.kwargs.get("entity_id"):
            raise APIError("batch failed", status_code=500)
        if (
            builder.path == "products"
            and operation == "get"
            and builder.kwargs.get("sku") == "SKU-1,SKU-2"
            and builder.kwargs.get("condition") == "finset"
        ):
            return {"items": [{"id": 1, "sku": "SKU-1"}, {"id": 2, "sku": "SKU-2"}]}
        if builder.path == "products" and operation == "get" and builder.kwargs.get("id") == 1:
            return {"id": 1, "sku": "SKU-1"}
        if builder.path == "products" and operation == "get" and builder.kwargs.get("id") == 2:
            return {"id": 2, "sku": "SKU-2"}
        if (
            builder.path == "products"
            and operation == "get"
            and builder.kwargs.get("sku") == "SKU-1"
        ):
            return {"id": 1, "sku": "SKU-1"}
        if (
            builder.path == "products"
            and operation == "get"
            and builder.kwargs.get("sku") == "SKU-2"
        ):
            return {"id": 2, "sku": "SKU-2"}
        return {"items": []}

    service = BatchService(FakeClient(resolver))

    by_ids = service.get_products_by_ids([1, 2])
    by_skus = service.get_products_by_skus(["SKU-1", "SKU-2"])

    assert by_ids[1]["sku"] == "SKU-1"
    assert by_ids[2]["sku"] == "SKU-2"
    assert by_skus["SKU-1"]["id"] == 1
    assert by_skus["SKU-2"]["id"] == 2


def test_batch_service_empty_inputs_return_empty_collections() -> None:
    service = BatchService(FakeClient(lambda builder, operation, data: {"items": []}))

    assert service.get_products_by_ids([]) == {}
    assert service.get_products_by_skus([]) == {}
