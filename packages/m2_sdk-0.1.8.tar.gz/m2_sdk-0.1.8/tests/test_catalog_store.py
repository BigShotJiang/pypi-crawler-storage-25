from __future__ import annotations

from pathlib import Path

from m2_sdk.catalog import CatalogStore


def test_catalog_store_save_get_count_keys_and_to_dict(tmp_path: Path) -> None:
    store = CatalogStore(tmp_path / "catalog.db")
    try:
        saved = store.save(
            {
                "SKU-2": {"sku": "SKU-2", "price": 20},
                "SKU-1": {"sku": "SKU-1", "price": 10},
            }
        )

        assert saved == 2
        assert store.get("SKU-1") == {"sku": "SKU-1", "price": 10}
        assert store.get("missing") is None
        assert store.count() == 2
        assert store.keys() == ["SKU-1", "SKU-2"]
        assert store.to_dict()["SKU-2"]["price"] == 20
    finally:
        store.close()


def test_catalog_store_delete_keys_and_query(tmp_path: Path) -> None:
    store = CatalogStore(tmp_path / "catalog.db")
    try:
        store.save(
            {
                "SKU-1": {"sku": "SKU-1", "price": 10},
                "SKU-2": {"sku": "SKU-2", "price": 25},
            }
        )

        rows = store.query(
            "SELECT key FROM data WHERE json_extract(json, '$.price') >= ? ORDER BY key", (20,)
        )
        deleted = store.delete_keys(["SKU-2"])

        assert rows == [{"key": "SKU-2"}]
        assert deleted == 1
        assert store.delete_keys([]) == 0
        assert store.count() == 1
    finally:
        store.close()


def test_catalog_store_diff_and_context_manager_close(tmp_path: Path) -> None:
    path = tmp_path / "catalog.db"
    with CatalogStore(path) as store:
        store.save({"SKU-1": {"sku": "SKU-1", "name": "Alpha"}})
        changes = store.diff(
            {
                "SKU-1": {"sku": "SKU-1", "name": "Beta"},
                "SKU-2": {"sku": "SKU-2", "name": "Gamma"},
            }
        )
        assert changes.created == {"SKU-2": {"sku": "SKU-2", "name": "Gamma"}}
        assert changes.updated == {"SKU-1": {"name": "Beta"}}
        assert changes.deleted == []

    assert store._conn is None
