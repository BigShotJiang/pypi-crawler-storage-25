from __future__ import annotations

import httpx
import pytest

from m2_sdk.exceptions import APIError, AuthError
from m2_sdk.middleware.error import ErrorMiddleware


def test_error_middleware_passes_through_success(response_factory) -> None:
    middleware = ErrorMiddleware()
    response = middleware(
        lambda method, url, **kwargs: response_factory(200, json_data={"ok": True}),
        "GET",
        "https://example.test",
    )
    assert response.status_code == 200


def test_error_middleware_maps_permission_401_to_auth_error(response_factory) -> None:
    middleware = ErrorMiddleware()
    response = response_factory(
        401, json_data={"parameters": {"resources": "Magento_Catalog::products"}}
    )

    with pytest.raises(AuthError, match="Permission denied"):
        middleware(lambda method, url, **kwargs: response, "GET", "https://example.test")


def test_error_middleware_maps_route_404_to_helpful_api_error(response_factory) -> None:
    middleware = ErrorMiddleware()
    response = response_factory(404, json_data={"message": "Request does not match any route."})

    with pytest.raises(APIError, match="API endpoint not found"):
        middleware(lambda method, url, **kwargs: response, "GET", "https://example.test")


def test_error_middleware_maps_httpx_request_error_to_api_error() -> None:
    middleware = ErrorMiddleware()
    request = httpx.Request("GET", "https://example.test")

    def handler(method: str, url: str, **kwargs):
        raise httpx.RequestError("socket down", request=request)

    with pytest.raises(APIError, match="Request failed: socket down"):
        middleware(handler, "GET", "https://example.test")


@pytest.mark.asyncio
async def test_error_middleware_async_maps_5xx_api_error(response_factory) -> None:
    middleware = ErrorMiddleware()
    response = response_factory(500, text="oops")

    async def handler(method: str, url: str, **kwargs):
        return response

    with pytest.raises(APIError) as exc_info:
        await middleware.async_call(handler, "GET", "https://example.test")

    assert exc_info.value.status_code == 500
    assert exc_info.value.response_body == "oops"
