from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass, field
from typing import Any


@dataclass
class FakeBuilder:
    resolver: Callable[[FakeBuilder, str, Any | None], Any]
    path: str
    kwargs: dict[str, Any] = field(default_factory=dict)
    history: list[tuple[str, Any]] = field(default_factory=list)
    model: Any | None = None

    def _clone(
        self, *, path: str | None = None, kwargs: dict[str, Any] | None = None
    ) -> FakeBuilder:
        return FakeBuilder(
            resolver=self.resolver,
            path=self.path if path is None else path,
            kwargs=dict(self.kwargs if kwargs is None else kwargs),
            history=list(self.history),
            model=self.model,
        )

    def __call__(self, *path_args: Any, **path_kwargs: Any) -> FakeBuilder:
        builder = self._clone()
        builder.history.append(("call", {"args": path_args, "kwargs": path_kwargs}))
        builder.kwargs.update(path_kwargs)
        if path_args:
            builder.kwargs["_args"] = path_args
        return builder

    def __getattr__(self, name: str) -> FakeBuilder:
        if name.startswith("_"):
            raise AttributeError(name)
        return self._clone(path=f"{self.path}.{name}")

    def filter(self, **kwargs: Any) -> FakeBuilder:
        builder = self._clone()
        builder.history.append(("filter", kwargs))
        builder.kwargs.update(kwargs)
        return builder

    def limit(self, count: int) -> FakeBuilder:
        builder = self._clone()
        builder.history.append(("limit", count))
        builder.kwargs["limit"] = count
        return builder

    def page(self, num: int) -> FakeBuilder:
        builder = self._clone()
        builder.history.append(("page", num))
        builder.kwargs["page"] = num
        return builder

    def sort_by(self, field: str, direction: str = "asc") -> FakeBuilder:
        builder = self._clone()
        builder.history.append(("sort_by", (field, direction)))
        builder.kwargs["sort"] = (field, direction)
        return builder

    def store(self, store_id: int) -> FakeBuilder:
        builder = self._clone()
        builder.history.append(("store", store_id))
        builder.kwargs["store_id"] = store_id
        return builder

    def typed(self, model: Any) -> FakeBuilder:
        builder = self._clone()
        builder.history.append(("typed", model))
        builder.model = model
        return builder

    def get(self) -> Any:
        return self.resolver(self, "get", None)

    def post(self, data: dict[str, Any]) -> Any:
        return self.resolver(self, "post", data)

    def put(self, data: dict[str, Any]) -> Any:
        return self.resolver(self, "put", data)

    def delete(self) -> Any:
        return self.resolver(self, "delete", None)


class FakeClient:
    def __init__(self, resolver: Callable[[FakeBuilder, str, Any | None], Any]) -> None:
        self._resolver = resolver
        self.products = FakeBuilder(resolver, "products")
        self.stock_items = FakeBuilder(resolver, "stock_items")
        self.inventory = FakeBuilder(resolver, "inventory")
