from __future__ import annotations

from m2_sdk.formatters import format_output


def test_format_output_modes() -> None:
    assert format_output({"x": 1}, raw_output=True) == {"x": 1}
    assert format_output({"x": 1}, json_output=True).startswith("{\n")
    assert format_output({"x": 1}) == {"x": 1}
    assert format_output({"x": 1}, format_type="text") == str({"x": 1})
