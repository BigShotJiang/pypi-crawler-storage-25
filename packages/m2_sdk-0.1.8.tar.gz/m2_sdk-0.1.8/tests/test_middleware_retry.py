from __future__ import annotations

import pytest

from m2_sdk.middleware.retry import RetryMiddleware


def test_retry_middleware_retries_then_succeeds(
    monkeypatch: pytest.MonkeyPatch, response_factory
) -> None:
    delays: list[float] = []
    responses = [response_factory(429, headers={"Retry-After": "0.25"}), response_factory(200)]
    middleware = RetryMiddleware(max_retries=2, base_delay=1.0)
    monkeypatch.setattr("m2_sdk.middleware.retry.time.sleep", delays.append)

    response = middleware(
        lambda method, url, **kwargs: responses.pop(0), "GET", "https://example.test"
    )

    assert response.status_code == 200
    assert delays == [0.25]


def test_retry_middleware_stops_at_max_retries(
    monkeypatch: pytest.MonkeyPatch, response_factory
) -> None:
    delays: list[float] = []
    middleware = RetryMiddleware(max_retries=1, base_delay=0.5)
    monkeypatch.setattr("m2_sdk.middleware.retry.time.sleep", delays.append)

    response = middleware(
        lambda method, url, **kwargs: response_factory(503), "GET", "https://example.test"
    )

    assert response.status_code == 503
    assert delays == [0.5]


@pytest.mark.asyncio
async def test_retry_middleware_async_uses_exponential_backoff(
    monkeypatch: pytest.MonkeyPatch, response_factory
) -> None:
    delays: list[float] = []
    responses = [response_factory(500), response_factory(500), response_factory(200)]
    middleware = RetryMiddleware(max_retries=3, base_delay=0.25)

    async def fake_sleep(delay: float) -> None:
        delays.append(delay)

    monkeypatch.setattr("m2_sdk.middleware.retry.asyncio.sleep", fake_sleep)

    async def handler(method: str, url: str, **kwargs):
        return responses.pop(0)

    response = await middleware.async_call(handler, "GET", "https://example.test")

    assert response.status_code == 200
    assert delays == [0.25, 0.5]
