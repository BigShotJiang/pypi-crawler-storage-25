from __future__ import annotations

import pytest

from m2_sdk.config import M2Config, get_config


def test_config_validation_and_aliases(monkeypatch: pytest.MonkeyPatch) -> None:
    config = M2Config(api_url="https://example.test/rest")
    assert config.api_url.endswith("/V1")
    assert config.base_url == config.api_url
    assert config.get_token() is None

    config = M2Config(default_format="RAW")
    assert config.default_format == "raw"

    with pytest.raises(ValueError, match="API URL must start"):
        M2Config(api_url="example.test")

    with pytest.raises(ValueError, match="Format must be one of"):
        M2Config(default_format="bad")


def test_get_config_returns_fresh_instance() -> None:
    assert isinstance(get_config(), M2Config)
