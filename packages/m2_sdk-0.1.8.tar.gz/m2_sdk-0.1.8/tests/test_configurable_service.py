from __future__ import annotations

import pytest

from m2_sdk.exceptions import NotFoundError, ValidationError
from m2_sdk.services.configurable_service import ConfigurableProductService

from .service_fakes import FakeBuilder, FakeClient


def test_configurable_parent_attach_detach_children_and_options() -> None:
    calls: list[tuple[str, str, object]] = []

    def resolver(builder: FakeBuilder, operation: str, data):
        calls.append((builder.path, operation, data or builder.kwargs))
        sku = builder.kwargs.get("sku")
        if operation == "post" and builder.path == "products":
            assert data == {
                "product": {
                    "sku": "PARENT",
                    "name": "Parent",
                    "price": 99.0,
                    "type_id": "configurable",
                    "attribute_set_id": 4,
                    "status": 1,
                    "visibility": 4,
                    "extension_attributes": {
                        "configurable_product_options": [
                            {"attribute_id": "color", "label": "Color"},
                            {"attribute_id": "size", "label": "Size"},
                        ]
                    },
                }
            }
            return {"sku": data["product"]["sku"], "type_id": data["product"]["type_id"]}
        if operation == "get" and sku == "PARENT":
            return {
                "sku": "PARENT",
                "type_id": "configurable",
                "extension_attributes": {
                    "configurable_product_links": [
                        {"sku": "CHILD-1"},
                        {"sku": "CHILD-2"},
                    ],
                    "configurable_product_options": [{"attribute_id": "color"}],
                },
            }
        if operation == "get" and sku in {"CHILD-1", "CHILD-2"}:
            return {"sku": sku, "type_id": "simple"}
        if operation == "get" and sku == "MISSING":
            raise NotFoundError("missing")
        if operation == "put" and sku == "PARENT":
            return {"sku": "PARENT", **data["product"]}
        if operation == "put" and sku == "CHILD-1":
            return {"sku": "CHILD-1", **data["product"]}
        if operation == "delete" and sku in {"PARENT", "CHILD-1", "CHILD-2"}:
            return {"ok": True}
        return {"sku": sku}

    service = ConfigurableProductService(FakeClient(resolver))

    parent = service.create_parent("PARENT", "Parent", 99.0, ["color", "size"])
    attached = service.attach_children("PARENT", ["CHILD-1", "CHILD-2"])
    detached = service.detach_children("PARENT", ["CHILD-2"])
    children = service.get_children("PARENT")
    options = service.get_configurable_options("PARENT")
    updated = service.update_super_attributes(
        "PARENT", [{"attribute_id": "size", "values": [1, 2]}]
    )
    prices = service.set_child_prices("PARENT", {"CHILD-1": 12.5})
    is_conf = service.is_configurable("PARENT")
    deleted = service.delete_parent("PARENT", delete_children=True)

    assert parent["type_id"] == "configurable"
    assert attached["extension_attributes"]["configurable_product_links"]
    assert detached["extension_attributes"]["configurable_product_links"] == [{"sku": "CHILD-1"}]
    assert [child["sku"] for child in children] == ["CHILD-1", "CHILD-2"]
    assert options == [{"attribute_id": "color"}]
    assert updated["extension_attributes"]["configurable_product_options"][0]["label"] == ""
    assert prices["sku"] == "PARENT"
    assert is_conf is True
    assert deleted is True
    assert any(call[1] == "post" for call in calls)
    assert any(
        call[1] == "put"
        and call[0] == "products"
        and call[2]
        == {
            "product": {
                "extension_attributes": {
                    "configurable_product_links": [
                        {"sku": "CHILD-1", "qty": 1},
                        {"sku": "CHILD-2", "qty": 1},
                    ]
                }
            }
        }
        for call in calls
    )


def test_configurable_service_validation_and_not_found_paths() -> None:
    def resolver(builder: FakeBuilder, operation: str, data):
        if builder.kwargs.get("sku") == "MISSING":
            raise NotFoundError("missing")
        if operation == "post":
            raise ValidationError("bad parent")
        if operation == "get" and builder.kwargs.get("sku") == "INVALID":
            raise NotFoundError("missing")
        return {"sku": builder.kwargs.get("sku")}

    service = ConfigurableProductService(FakeClient(resolver))

    with pytest.raises(ValidationError, match="Invalid product data"):
        service.create_parent("PARENT", "Parent", 10.0, ["color"])

    with pytest.raises(NotFoundError, match="Configurable parent MISSING not found"):
        service.attach_children("MISSING", ["CHILD-1"])

    with pytest.raises(NotFoundError, match="Configurable parent MISSING not found"):
        service.detach_children("MISSING", ["CHILD-1"])

    with pytest.raises(NotFoundError, match="Configurable parent MISSING not found"):
        service.get_children("MISSING")

    with pytest.raises(NotFoundError, match="Configurable MISSING not found"):
        service.get_configurable_options("MISSING")
