from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import httpx
import pytest
from pydantic import BaseModel

from m2_sdk.cascade import ResourceBuilder
from m2_sdk.client import M2Client


class ItemModel(BaseModel):
    sku: str


@dataclass
class DummyResponse:
    payload: Any = None
    status_code: int = 200
    text: str = ""

    def json(self) -> Any:
        if isinstance(self.payload, Exception):
            raise self.payload
        return self.payload


class CascadeClientStub:
    def __init__(self) -> None:
        self.calls: list[tuple[str, str, dict[str, Any]]] = []

    def _normalize_resource_segment(self, segment: str) -> str:
        return {"stock_items": "stockItems"}.get(segment, segment)

    def _normalize_path(self, path: str) -> str:
        return path if path.startswith("/") else f"/{path}"

    def _build_url_with_params(self, path: str, params: dict[str, Any] | None) -> str:
        if not params:
            return path
        query = "&".join(f"{k}={v}" for k, v in params.items())
        return f"{path}?{query}"

    def request(self, method: str, path: str, **kwargs: Any) -> dict[str, Any]:
        self.calls.append((method, path, kwargs))
        if path == "/typed":
            return {"sku": "A"}
        return {"method": method, "path": path, "kwargs": kwargs}

    async def async_request(self, method: str, path: str, **kwargs: Any) -> dict[str, Any]:
        self.calls.append((method, path, kwargs))
        return {"method": method, "path": path, "kwargs": kwargs}


def test_client_resource_alias_and_url_helpers(config_factory) -> None:
    client = M2Client(
        config_factory(), auth_manager=type("A", (), {"get_admin_token": lambda self: "x"})()
    )

    assert client._normalize_resource_name("stock_items/source_items") == "stockItems/source-items"
    assert client._normalize_path("V1/products") == "/products"
    assert (
        client._build_url_with_params("/products", {"searchCriteria[pageSize]": 2})
        == "/products?searchCriteria[pageSize]=2"
    )
    assert client.stock_items._path == "/stockItems"
    assert client.resource("stock_items")._path == "/stockItems"
    assert client._normalize_resource_segment("") == ""
    assert client._normalize_resource_segment("{sku}") == "{sku}"


def test_client_request_pipeline_and_client_lifecycle(
    monkeypatch: pytest.MonkeyPatch, config_factory
) -> None:
    sync_calls: list[tuple[str, str, dict[str, Any]]] = []
    async_calls: list[tuple[str, str, dict[str, Any]]] = []
    build_calls: list[str] = []

    class DummySyncClient:
        def request(self, method: str, url: str, **kwargs: Any) -> httpx.Response:
            sync_calls.append((method, url, kwargs))
            return httpx.Response(200, json={"ok": True}, request=httpx.Request(method, url))

        def close(self) -> None:
            sync_calls.append(("close", "", {}))

    class DummyAsyncClient:
        async def request(self, method: str, url: str, **kwargs: Any) -> httpx.Response:
            async_calls.append((method, url, kwargs))
            return httpx.Response(200, json={"ok": True}, request=httpx.Request(method, url))

        async def aclose(self) -> None:
            async_calls.append(("aclose", "", {}))

    monkeypatch.setattr("m2_sdk.client.httpx.Client", lambda **kwargs: DummySyncClient())
    monkeypatch.setattr("m2_sdk.client.httpx.AsyncClient", lambda **kwargs: DummyAsyncClient())
    monkeypatch.setattr(
        "m2_sdk.client.build_pipeline",
        lambda middlewares, final_handler: (
            lambda method, url, **kwargs: (
                build_calls.append("sync") or final_handler(method, url, **kwargs)
            )
        ),
    )
    monkeypatch.setattr(
        "m2_sdk.client.build_async_pipeline",
        lambda middlewares, final_handler: (
            lambda method, url, **kwargs: (
                build_calls.append("async") or final_handler(method, url, **kwargs)
            )
        ),
    )

    client = M2Client(
        config_factory(), auth_manager=type("A", (), {"get_admin_token": lambda self: "x"})()
    )

    assert client.request("GET", "/products", params={"a": 1}).status_code == 200

    async def run() -> None:
        async with client:
            response = await client.async_request("POST", "/products", json_data={"sku": "x"})
            assert response.status_code == 200

    import asyncio

    asyncio.run(run())

    client.close()
    assert any(call[0] == "close" for call in sync_calls)
    assert any(call[0] == "aclose" for call in async_calls)
    assert build_calls == ["sync", "async"]


def test_client_parsing_and_catalog_helpers(config_factory) -> None:
    client = M2Client(
        config_factory(), auth_manager=type("A", (), {"get_admin_token": lambda self: "x"})()
    )

    assert client._parse_json(httpx.Response(204, request=httpx.Request("GET", "https://x"))) == {}
    assert client._parse_json(
        httpx.Response(200, text="not json", request=httpx.Request("GET", "https://x"))
    ) == {"raw_response": "not json"}
    assert client._extract_catalog_items({"items": [{"sku": "A"}, 1]}) == [{"sku": "A"}]
    assert client._extract_catalog_items(
        type("P", (), {"items": [type("I", (), {"model_dump": lambda self: {"sku": "B"}})()]})()
    ) == [{"sku": "B"}]
    assert client._catalog_key({"sku": "A"}, "sku") == "A"
    assert client._catalog_key({"id": 7}, "sku") == "7"
    assert client._format_enrichment_path("stockItems/{sku}", {"sku": "A"}) == "stockItems/A"
    assert client._enrich_item({"sku": "A"}, None) == {"sku": "A"}


def test_client_context_managers(monkeypatch: pytest.MonkeyPatch, config_factory) -> None:
    sync_closed = False
    async_closed = False

    class DummySyncClient:
        def request(self, method: str, url: str, **kwargs: Any) -> httpx.Response:
            return httpx.Response(200, json={"ok": True}, request=httpx.Request(method, url))

        def close(self) -> None:
            nonlocal sync_closed
            sync_closed = True

    class DummyAsyncClient:
        async def request(self, method: str, url: str, **kwargs: Any) -> httpx.Response:
            return httpx.Response(200, json={"ok": True}, request=httpx.Request(method, url))

        async def aclose(self) -> None:
            nonlocal async_closed
            async_closed = True

    monkeypatch.setattr("m2_sdk.client.httpx.Client", lambda **kwargs: DummySyncClient())
    monkeypatch.setattr("m2_sdk.client.httpx.AsyncClient", lambda **kwargs: DummyAsyncClient())

    client = M2Client(
        config_factory(), auth_manager=type("A", (), {"get_admin_token": lambda self: "x"})()
    )

    with client as entered:
        assert entered is client
        client.request("GET", "/products")
    assert sync_closed is True

    import asyncio

    async def run() -> bool:
        async with client as entered_async:
            assert entered_async is client
            await client.async_request("GET", "/products")
        return async_closed

    assert asyncio.run(run()) is True


def test_cascade_builder_navigation_filters_and_terminal_calls() -> None:
    client = CascadeClientStub()
    builder = ResourceBuilder(client, "/products")

    assert repr(builder) == "ResourceBuilder('/products')"
    with pytest.raises(AttributeError):
        _ = builder._private

    next_builder = builder.media(id=2)
    assert next_builder._path == "/products/media/2"
    assert builder.filter(status="1") is builder
    assert builder.where("price", ">=", "10") is builder
    assert builder.where("status", "1") is builder
    assert (
        builder.sort_by("price", "desc")._params["searchCriteria[sortOrders][0][direction]"]
        == "DESC"
    )
    assert builder.limit(25)._params["searchCriteria[pageSize]"] == "25"
    assert builder.page(2)._params["searchCriteria[currentPage]"] == "2"
    assert builder.body({"sku": "X"})._body == {"sku": "X"}
    assert builder.typed(ItemModel)._response_model is ItemModel
    assert builder.params(extra="1")._params["extra"] == "1"
    assert ResourceBuilder(client, "/products/{sku}")(sku="SKU/1")._path == "/products/SKU%2F1"

    assert builder._clone(path="/typed").typed(ItemModel).get().sku == "A"
    assert ResourceBuilder(client, "/products").post({"sku": "X"})["method"] == "POST"
    assert ResourceBuilder(client, "/products").put({"sku": "X"})["method"] == "PUT"
    assert ResourceBuilder(client, "/products").patch({"sku": "X"})["method"] == "PATCH"
    assert ResourceBuilder(client, "/products").delete()["method"] == "DELETE"


@pytest.mark.asyncio
async def test_cascade_async_terminal_and_pagination_paths() -> None:
    class PagingClient:
        def __init__(self) -> None:
            self.calls: list[tuple[str, str, dict[str, Any]]] = []

        def _normalize_resource_segment(self, segment: str) -> str:
            return segment

        def request(self, method: str, path: str, **kwargs: Any) -> dict[str, Any]:
            self.calls.append((method, path, kwargs))
            return {"items": [], "total_count": 0}

        async def async_request(self, method: str, path: str, **kwargs: Any) -> dict[str, Any]:
            self.calls.append((method, path, kwargs))
            params = kwargs.get("params", {})
            page = params.get("searchCriteria[currentPage]")
            if page is None:
                return {"items": [], "total_count": 0}
            if str(page) == "1":
                return {"items": [{"sku": "A"}], "total_count": 2}
            if str(page) == "2":
                return {"items": [{"sku": "B"}], "total_count": 2}
            return {"items": []}

        def _normalize_path(self, path: str) -> str:
            return path

        def _build_url_with_params(self, path: str, params: dict[str, Any] | None) -> str:
            return path

    builder = ResourceBuilder(PagingClient(), "/products")
    assert await builder.aget() == {"items": [], "total_count": 0}
    pages = []
    async for page in builder.aiter_pages(page_size=1):
        pages.append(page)
    assert [page["items"][0]["sku"] for page in pages] == ["A", "B"]
