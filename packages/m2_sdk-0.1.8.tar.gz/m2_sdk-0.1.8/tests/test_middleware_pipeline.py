from __future__ import annotations

import httpx
import pytest

from m2_sdk.middleware import build_async_pipeline, build_pipeline


class RecorderMiddleware:
    def __init__(self, name: str, events: list[str]) -> None:
        self.name = name
        self.events = events

    def __call__(self, handler, method: str, url: str, **kwargs):
        self.events.append(f"before:{self.name}")
        response = handler(method, url, **kwargs)
        self.events.append(f"after:{self.name}")
        return response

    async def async_call(self, handler, method: str, url: str, **kwargs):
        self.events.append(f"before:{self.name}")
        response = await handler(method, url, **kwargs)
        self.events.append(f"after:{self.name}")
        return response


def test_build_pipeline_applies_middlewares_in_order(response_factory) -> None:
    events: list[str] = []
    pipeline = build_pipeline(
        [RecorderMiddleware("outer", events), RecorderMiddleware("inner", events)],
        lambda method, url, **kwargs: response_factory(200, text="ok"),
    )

    response = pipeline("GET", "https://example.test")

    assert response.status_code == 200
    assert events == ["before:outer", "before:inner", "after:inner", "after:outer"]


@pytest.mark.asyncio
async def test_build_async_pipeline_applies_middlewares_in_order(response_factory) -> None:
    events: list[str] = []

    async def final_handler(method: str, url: str, **kwargs) -> httpx.Response:
        return response_factory(204)

    pipeline = build_async_pipeline(
        [RecorderMiddleware("outer", events), RecorderMiddleware("inner", events)],
        final_handler,
    )

    response = await pipeline("GET", "https://example.test")

    assert response.status_code == 204
    assert events == ["before:outer", "before:inner", "after:inner", "after:outer"]
