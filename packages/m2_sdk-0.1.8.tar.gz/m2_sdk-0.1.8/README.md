# m2-sdk

Magento 2 REST API SDK

## Installation

```bash
pip install m2-sdk
```

## Usage

```python
from m2_sdk import M2Client, get_config
from m2_sdk.auth import AuthManager

config = get_config()
auth = AuthManager(config)
client = M2Client(config, auth)

# List products
products = client.products().limit(10).get()

# Stream pages concurrently after page 1 reveals total_count
async for page in client.products().aiter_pages_concurrent(page_size=100, concurrency=4):
    for item in page["items"]:
        print(item["sku"])

# Build an async catalog with concurrent pagination
catalog = await client.acatalog("products", page_size=100, concurrency=4)
```
