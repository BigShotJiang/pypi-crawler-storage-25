"""Formatting helpers for CLI output."""

from __future__ import annotations

import json
from typing import Any


def format_output(
    response: Any,
    format_type: str = "rich",
    json_output: bool = False,
    raw_output: bool = False,
) -> Any:
    """Format API output for CLI display."""
    if raw_output:
        return response
    if json_output:
        return json.dumps(response, default=str, indent=2)
    return response if format_type == "rich" else str(response)
