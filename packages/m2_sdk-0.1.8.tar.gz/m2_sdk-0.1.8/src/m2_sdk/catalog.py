"""Catalog sync helpers for downloading, saving, diffing, and uploading changes.

Supports two backends:

**JSON** (simple, human-readable, diffable)::

    from m2_sdk.catalog import save_catalog, load_catalog, diff_catalog, apply_changes

    catalog = client.catalog("products")
    save_catalog(catalog, "products.json")
    original = load_catalog("products.json")

**SQLite** (queryable, handles large catalogs, no memory pressure)::

    from m2_sdk.catalog import CatalogStore

    store = CatalogStore("products.db")
    store.save(client.catalog("products"))

    # Query
    cheap = store.query("SELECT sku, name, price FROM data WHERE price < 50")
    count = store.count()

    # Diff against a new download
    changes = store.diff(client.catalog("products"))
    print(changes)  # CatalogChanges(created=12, updated=47, deleted=3)

    # Apply and snapshot
    apply_changes(client, changes)
    store.save(client.catalog("products"))  # update snapshot
"""

from __future__ import annotations

import json
import sqlite3
from pathlib import Path
from typing import Any

# ---------------------------------------------------------------------------
# JSON backend (simple)
# ---------------------------------------------------------------------------


def save_catalog(
    catalog: dict[str, dict[str, Any]],
    path: str | Path,
) -> int:
    """Save catalog snapshot to JSON file.

    Args:
        catalog: Keyed dict {sku: product_dict, ...}.
        path: File path to write.

    Returns:
        Number of records saved.
    """
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w") as f:
        json.dump(catalog, f, indent=2, default=str)
    return len(catalog)


def load_catalog(path: str | Path) -> dict[str, dict[str, Any]]:
    """Load catalog snapshot from JSON file.

    Args:
        path: File path to read.

    Returns:
        Keyed dict {sku: product_dict, ...}.
    """
    with open(path) as f:
        data = json.load(f)
    if not isinstance(data, dict):
        raise ValueError(f"Expected dict, got {type(data).__name__}")
    return data


# ---------------------------------------------------------------------------
# CatalogChanges (diff result)
# ---------------------------------------------------------------------------


class CatalogChanges:
    """Diff result between two catalog snapshots."""

    def __init__(self) -> None:
        self.created: dict[str, dict[str, Any]] = {}  # key -> full record
        self.updated: dict[str, dict[str, Any]] = {}  # key -> changed fields only
        self.deleted: list[str] = []  # keys to delete

    @property
    def total(self) -> int:
        return len(self.created) + len(self.updated) + len(self.deleted)

    def __repr__(self) -> str:
        return (
            f"CatalogChanges(created={len(self.created)}, "
            f"updated={len(self.updated)}, deleted={len(self.deleted)})"
        )


def diff_catalog(
    original: dict[str, dict[str, Any]],
    modified: dict[str, dict[str, Any]],
) -> CatalogChanges:
    """Compute field-level changes between two catalog snapshots.

    Args:
        original: Previous catalog state.
        modified: New catalog state.

    Returns:
        CatalogChanges with created, updated, and deleted records.
    """
    changes = CatalogChanges()

    original_keys = set(original.keys())
    modified_keys = set(modified.keys())

    for key in modified_keys - original_keys:
        changes.created[key] = modified[key]

    changes.deleted = list(original_keys - modified_keys)

    for key in original_keys & modified_keys:
        old = original[key]
        new = modified[key]
        diff = {}
        all_keys = set(old.keys()) | set(new.keys())
        for field in all_keys:
            old_val = old.get(field)
            new_val = new.get(field)
            if old_val != new_val:
                diff[field] = new_val
        if diff:
            changes.updated[key] = diff

    return changes


# ---------------------------------------------------------------------------
# Apply changes
# ---------------------------------------------------------------------------


def apply_changes(
    client: Any,
    changes: CatalogChanges,
    resource: str = "products",
    key_field: str = "sku",
) -> dict[str, list[str]]:
    """Apply catalog changes to Magento via the SDK.

    Args:
        client: M2Client instance.
        changes: CatalogChanges from diff_catalog().
        resource: Resource name ("products", "orders", etc.).
        key_field: Field used as the key ("sku" for products).

    Returns:
        Dict with "created", "updated", "deleted" lists of keys that succeeded.
    """
    results: dict[str, list[str]] = {"created": [], "updated": [], "deleted": []}
    builder = getattr(client, resource)

    for key, record in changes.created.items():
        try:
            builder.post(record)
            results["created"].append(key)
        except Exception:
            continue

    for key, diff in changes.updated.items():
        try:
            builder(**{key_field: key}).put(diff)
            results["updated"].append(key)
        except Exception:
            continue

    for key in changes.deleted:
        try:
            builder(**{key_field: key}).delete()
            results["deleted"].append(key)
        except Exception:
            continue

    return results


# ---------------------------------------------------------------------------
# SQLite backend (queryable, handles large catalogs)
# ---------------------------------------------------------------------------


class CatalogStore:
    """SQLite-backed catalog store.

    Stores catalog snapshots in a local SQLite database.
    Supports querying, diffing, and snapshotting without loading
    everything into memory.

    Usage::

        store = CatalogStore("products.db", key_field="sku")

        # Save a catalog download
        store.save(client.catalog("products"))

        # Query
        for row in store.query("SELECT sku, price FROM data WHERE price < 50"):
            print(row)

        # Count
        print(store.count())  # 4523

        # Get single record
        product = store.get("SKU-001")

        # Diff against new download
        changes = store.diff(client.catalog("products"))
        print(changes)  # CatalogChanges(created=12, updated=47, deleted=3)

        # Export to dict (for JSON serialization)
        catalog = store.to_dict()

        # List all keys
        skus = store.keys()
    """

    def __init__(self, path: str | Path, key_field: str = "sku") -> None:
        """Initialize store.

        Args:
            path: SQLite database file path.
            key_field: Field used as the primary key.
        """
        self.path = Path(path)
        self.key_field = key_field
        self._conn: sqlite3.Connection | None = None

    @property
    def conn(self) -> sqlite3.Connection:
        """Lazy connection to SQLite."""
        if self._conn is None:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            self._conn = sqlite3.connect(str(self.path))
            self._conn.row_factory = sqlite3.Row
            self._ensure_schema()
        return self._conn

    def _ensure_schema(self) -> None:
        """Create tables if they don't exist."""
        self.conn.execute(
            """
            CREATE TABLE IF NOT EXISTS data (
                key TEXT PRIMARY KEY,
                json TEXT NOT NULL,
                updated_at REAL DEFAULT (unixepoch())
            )
            """
        )
        self.conn.commit()

    def close(self) -> None:
        """Close the database connection."""
        if self._conn:
            self._conn.close()
            self._conn = None

    def __enter__(self) -> CatalogStore:
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()

    # --- Write ---

    def save(self, catalog: dict[str, dict[str, Any]]) -> int:
        """Save/upsert a catalog into the store.

        Args:
            catalog: Keyed dict {key: record_dict, ...}.

        Returns:
            Number of records saved.
        """
        rows = [(key, json.dumps(record, default=str)) for key, record in catalog.items()]
        self.conn.executemany(
            "INSERT INTO data (key, json, updated_at) VALUES (?, ?, unixepoch()) "
            "ON CONFLICT(key) DO UPDATE SET json = excluded.json, updated_at = excluded.updated_at",
            rows,
        )
        self.conn.commit()
        return len(rows)

    def set(self, key: str, record: dict[str, Any]) -> None:
        """Upsert a single record by key."""
        self.conn.execute(
            "INSERT INTO data (key, json, updated_at) VALUES (?, ?, unixepoch()) "
            "ON CONFLICT(key) DO UPDATE SET json = excluded.json, updated_at = excluded.updated_at",
            (key, json.dumps(record, default=str)),
        )
        self.conn.commit()

    def delete_keys(self, keys: list[str]) -> int:
        """Delete records by key.

        Args:
            keys: List of keys to delete.

        Returns:
            Number of records deleted.
        """
        if not keys:
            return 0
        placeholders = ",".join("?" * len(keys))
        cursor = self.conn.execute(f"DELETE FROM data WHERE key IN ({placeholders})", keys)
        self.conn.commit()
        return cursor.rowcount

    # --- Read ---

    def get(self, key: str) -> dict[str, Any] | None:
        """Get a single record by key.

        Args:
            key: Record key (e.g., SKU).

        Returns:
            Record dict or None if not found.
        """
        row = self.conn.execute("SELECT json FROM data WHERE key = ?", (key,)).fetchone()
        return json.loads(row["json"]) if row else None

    def keys(self) -> list[str]:
        """Get all keys in the store."""
        rows = self.conn.execute("SELECT key FROM data ORDER BY key").fetchall()
        return [row["key"] for row in rows]

    def count(self) -> int:
        """Get total number of records."""
        row = self.conn.execute("SELECT COUNT(*) as cnt FROM data").fetchone()
        return row["cnt"] if row else 0

    def to_dict(self) -> dict[str, dict[str, Any]]:
        """Load entire store into a dict.

        Warning: loads all records into memory. Use query() for large stores.
        """
        rows = self.conn.execute("SELECT key, json FROM data ORDER BY key").fetchall()
        return {row["key"]: json.loads(row["json"]) for row in rows}

    def query(self, sql: str, params: tuple[Any, ...] = ()) -> list[dict[str, Any]]:
        """Run a SQL query against the data table.

        The table is called ``data`` with columns: ``key``, ``json``, ``updated_at``.

        Args:
            sql: SQL query. Use ``data`` as the table name.
            params: Query parameters.

        Returns:
            List of row dicts.

        Example::

            # Find cheap products
            rows = store.query("SELECT key, json FROM data WHERE json_extract(json, '$.price') < 50")

            # Get recently updated
            rows = store.query("SELECT key FROM data WHERE updated_at > ?", (yesterday,))
        """
        cursor = self.conn.execute(sql, params)
        return [dict(row) for row in cursor.fetchall()]

    # --- Diff ---

    def diff(self, new_catalog: dict[str, dict[str, Any]]) -> CatalogChanges:
        """Diff the store against a new catalog download.

        Args:
            new_catalog: Fresh catalog dict {key: record_dict, ...}.

        Returns:
            CatalogChanges with created, updated, deleted records.
        """
        old = self.to_dict()
        return diff_catalog(old, new_catalog)
