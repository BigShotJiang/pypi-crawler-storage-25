"""HTTP client for Magento 2 REST API.

Dual sync/async client using httpx with middleware pipeline support.
"""

import json
from typing import Any, Literal, cast
from urllib.parse import urlencode

import httpx

from m2_sdk.auth import AuthManager
from m2_sdk.config import M2Config
from m2_sdk.middleware import build_async_pipeline, build_pipeline
from m2_sdk.middleware.auth import AuthMiddleware
from m2_sdk.middleware.error import ErrorMiddleware
from m2_sdk.middleware.logging import LoggingMiddleware
from m2_sdk.middleware.retry import RetryMiddleware


class M2Client:
    """Dual sync/async HTTP client for Magento 2 REST API.

    Supports cascade API via attribute access:
        client.products().filter(status="1").limit(10).get()
        await client.products().filter(status="1").aget()

    Also supports direct request methods:
        client.get("/products")
        await client.async_get("/products")
    """

    def __init__(
        self,
        config: M2Config,
        auth_manager: AuthManager,
        middlewares: list[Any] | None = None,
    ) -> None:
        """Initialize client.

        Args:
            config: Configuration instance.
            auth_manager: Auth manager instance.
            middlewares: Custom middleware list. If None, uses defaults.
        """
        self.config = config
        self.auth = auth_manager
        self._middlewares = middlewares if middlewares is not None else self._default_middlewares()

        self._sync_client: httpx.Client | None = None
        self._async_client: httpx.AsyncClient | None = None

        # Built pipelines (lazily constructed)
        self._sync_pipeline: Any = None
        self._async_pipeline: Any = None

    def _default_middlewares(self) -> list[Any]:
        """Create default middleware stack."""
        return [
            LoggingMiddleware(verbose=self.config.verbose),
            AuthMiddleware(
                get_token=lambda: self.config.get_token(),
                refresh_token=lambda: self.auth.get_admin_token(),
            ),
            RetryMiddleware(
                max_retries=self.config.max_retries,
                base_delay=self.config.retry_delay,
            ),
            ErrorMiddleware(),
        ]

    # --- HTTP client lifecycle ---

    def _get_sync_client(self) -> httpx.Client:
        """Get or create sync HTTP client."""
        if self._sync_client is None:
            self._sync_client = httpx.Client(
                base_url=self.config.api_url,
                timeout=self.config.timeout,
                follow_redirects=True,
            )
        return self._sync_client

    def _get_async_client(self) -> httpx.AsyncClient:
        """Get or create async HTTP client."""
        if self._async_client is None:
            self._async_client = httpx.AsyncClient(
                base_url=self.config.api_url,
                timeout=self.config.timeout,
                follow_redirects=True,
            )
        return self._async_client

    def close(self) -> None:
        """Close sync HTTP client."""
        if self._sync_client:
            self._sync_client.close()
            self._sync_client = None

    async def aclose(self) -> None:
        """Close async HTTP client."""
        if self._async_client:
            await self._async_client.aclose()
            self._async_client = None

    def __enter__(self) -> "M2Client":
        """Sync context manager entry."""
        return self

    def __exit__(self, *args: Any) -> None:
        """Sync context manager exit."""
        self.close()

    async def __aenter__(self) -> "M2Client":
        """Async context manager entry."""
        return self

    async def __aexit__(self, *args: Any) -> None:
        """Async context manager exit."""
        await self.aclose()

    # --- Cascade entry points ---

    _RESOURCE_ALIASES: dict[str, str] = {
        "stock_items": "stockItems",
        "source_items": "source-items",
        "stock_source_links": "stock-source-links",
    }

    def _normalize_resource_segment(self, segment: str) -> str:
        """Normalize ergonomic snake_case aliases to Magento resource segments."""
        if not segment or segment.startswith("{"):
            return segment
        return self._RESOURCE_ALIASES.get(segment, segment)

    def _normalize_resource_name(self, name: str) -> str:
        """Normalize every segment in a resource path."""
        return "/".join(self._normalize_resource_segment(segment) for segment in name.split("/"))

    def resource(self, name: str) -> Any:
        """Start cascade builder for a resource.

        Args:
            name: Resource name (e.g., "products", "orders").

        Returns:
            ResourceBuilder for fluent chaining.

        Example:
            client.resource("products").filter(status="1").get()
            # Same as: client.products().filter(status="1").get()
        """
        from m2_sdk.cascade import ResourceBuilder

        return ResourceBuilder(self, f"/{self._normalize_resource_name(name)}")

    def __getattr__(self, name: str) -> Any:
        """Attribute access for cascade: client.products → ResourceBuilder.

        Avoids triggering for internal attributes during initialization.
        """
        if name.startswith("_"):
            raise AttributeError(name)
        return self.resource(name)

    # --- Path normalization ---

    def _normalize_path(self, path: str) -> str:
        """Normalize API path (strip /V1 prefix if base_url already includes it)."""
        if not path.startswith("/"):
            path = f"/{path}"
        if path.startswith("/V1/") and self.config.api_url.endswith("/V1"):
            path = path[3:]
        return path

    # --- Query string building ---

    def _build_url_with_params(self, path: str, params: dict[str, Any] | None) -> str:
        """Build URL with query parameters, preserving Magento bracket notation.

        httpx interprets square brackets as nested dict keys, which breaks
        Magento's searchCriteria[pageSize]=5 format. We build the query string
        manually to preserve literal brackets.
        """
        if not params:
            return path
        query_parts = []
        for key, value in params.items():
            encoded_value = urlencode({"": str(value)})[1:]
            query_parts.append(f"{key}={encoded_value}")
        return f"{path}?{'&'.join(query_parts)}"

    # --- Core request methods ---

    def _raw_sync_request(
        self,
        method: str,
        url: str,
        **kwargs: Any,
    ) -> httpx.Response:
        """Raw sync request — used as the pipeline's final handler."""
        return self._get_sync_client().request(method=method, url=url, **kwargs)

    async def _raw_async_request(
        self,
        method: str,
        url: str,
        **kwargs: Any,
    ) -> httpx.Response:
        """Raw async request — used as the pipeline's final handler."""
        return await self._get_async_client().request(method=method, url=url, **kwargs)

    def _get_sync_pipeline(self) -> Any:
        """Build and cache sync middleware pipeline."""
        if self._sync_pipeline is None:
            self._sync_pipeline = build_pipeline(self._middlewares, self._raw_sync_request)
        return self._sync_pipeline

    def _get_async_pipeline(self) -> Any:
        """Build and cache async middleware pipeline."""
        if self._async_pipeline is None:
            self._async_pipeline = build_async_pipeline(self._middlewares, self._raw_async_request)
        return self._async_pipeline

    def request(
        self,
        method: str,
        path: str,
        params: dict[str, Any] | None = None,
        json_data: dict[str, Any] | None = None,
    ) -> httpx.Response:
        """Make sync API request through middleware pipeline.

        Args:
            method: HTTP method.
            path: API path (without base URL).
            params: Query parameters.
            json_data: JSON request body.

        Returns:
            httpx.Response object.

        Raises:
            APIError: If request fails.
            AuthError: If authentication fails.
        """
        path = self._normalize_path(path)
        url = self._build_url_with_params(path, params)
        pipeline = self._get_sync_pipeline()
        return cast(httpx.Response, pipeline(method, url, json=json_data))

    async def async_request(
        self,
        method: str,
        path: str,
        params: dict[str, Any] | None = None,
        json_data: dict[str, Any] | None = None,
    ) -> httpx.Response:
        """Make async API request through middleware pipeline.

        Args:
            method: HTTP method.
            path: API path (without base URL).
            params: Query parameters.
            json_data: JSON request body.

        Returns:
            httpx.Response object.

        Raises:
            APIError: If request fails.
            AuthError: If authentication fails.
        """
        path = self._normalize_path(path)
        url = self._build_url_with_params(path, params)
        pipeline = self._get_async_pipeline()
        return cast(httpx.Response, await pipeline(method, url, json=json_data))

    # --- Response parsing ---

    @staticmethod
    def _parse_json(response: httpx.Response) -> dict[str, Any]:
        """Parse response as JSON, return empty dict for 204."""
        if response.status_code == 204:
            return {}
        try:
            return cast(dict[str, Any], response.json())
        except (json.JSONDecodeError, ValueError):
            return {"raw_response": response.text}

    @staticmethod
    def _extract_catalog_items(page: Any) -> list[dict[str, Any]]:
        """Extract item records from a page response."""
        if isinstance(page, dict):
            items = page.get("items", [])
            return [item for item in items if isinstance(item, dict)]

        items = getattr(page, "items", [])
        return [item.model_dump() if hasattr(item, "model_dump") else item for item in items]

    @staticmethod
    def _catalog_key(item: dict[str, Any], key_field: str) -> str:
        """Resolve the catalog key for an item."""
        return str(item.get(key_field, item.get("id", "")))

    @staticmethod
    def _format_enrichment_path(template: str, item: dict[str, Any]) -> str:
        """Render a resource template like ``stockItems/{sku}`` from an item."""
        return template.format(**item)

    def _enrich_item(
        self,
        item: dict[str, Any],
        enrich: dict[str, str] | None,
    ) -> dict[str, Any]:
        """Attach related resource payloads to an item."""
        if not enrich:
            return item

        enriched = dict(item)
        for field, resource_template in enrich.items():
            enriched[field] = self.resource(
                self._format_enrichment_path(resource_template, item)
            ).get()
        return enriched

    async def _aenrich_item(
        self,
        item: dict[str, Any],
        enrich: dict[str, str] | None,
    ) -> dict[str, Any]:
        """Async variant of item enrichment."""
        if not enrich:
            return item

        enriched = dict(item)
        for field, resource_template in enrich.items():
            path = self._format_enrichment_path(resource_template, item)
            enriched[field] = await self.resource(path).aget()
        return enriched

    # --- Catalog sync helpers ---

    def catalog(
        self,
        resource: str = "products",
        key_field: str = "sku",
        enrich: dict[str, str] | None = None,
        page_size: int = 100,
        **filters: Any,
    ) -> dict[str, dict[str, Any]]:
        """Download full catalog (paginated) into a keyed dict.

        Returns {sku: product_dict, ...} for the entire resource.
        Handles pagination automatically.

        Usage::

            # All products keyed by SKU
            catalog = client.catalog()

            # All orders keyed by increment_id
            orders = client.catalog("orders", key_field="increment_id")

            # Filtered subset
            active = client.catalog(products, status="1")
        """
        result: dict[str, dict[str, Any]] = {}
        builder = self.resource(resource)
        if filters:
            builder = builder.filter(**filters)

        for page in builder.iter_pages(page_size=page_size):
            items = self._extract_catalog_items(page)
            if not items:
                break

            for item in items:
                enriched = self._enrich_item(item, enrich)
                key = self._catalog_key(enriched, key_field)
                if key:
                    result[key] = enriched

        return result

    async def acatalog(
        self,
        resource: str = "products",
        key_field: str = "sku",
        enrich: dict[str, str] | None = None,
        page_size: int = 100,
        concurrency: int | None = None,
        yield_order: Literal["page", "completion"] = "page",
        **filters: Any,
    ) -> dict[str, dict[str, Any]]:
        """Async catalog download helper with optional enrichment.

        Set ``concurrency`` greater than 1 to fetch catalog pages in parallel
        after the first page establishes ``total_count``.
        """
        result: dict[str, dict[str, Any]] = {}
        builder = self.resource(resource)
        if filters:
            builder = builder.filter(**filters)

        page_iterator = (
            builder.aiter_pages(page_size=page_size)
            if concurrency is None or concurrency <= 1
            else builder.aiter_pages_concurrent(
                page_size=page_size,
                concurrency=concurrency,
                yield_order=yield_order,
            )
        )

        async for page in page_iterator:
            items = self._extract_catalog_items(page)
            if not items:
                break

            for item in items:
                enriched = await self._aenrich_item(item, enrich)
                key = self._catalog_key(enriched, key_field)
                if key:
                    result[key] = enriched

        return result
