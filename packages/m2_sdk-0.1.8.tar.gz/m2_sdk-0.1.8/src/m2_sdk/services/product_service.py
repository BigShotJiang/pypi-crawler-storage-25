"""Product service with high-level CRUD operations.

Provides easy-to-use methods for product operations with automatic
conflict handling, validation, and retry support.
"""

from typing import Any

from m2_sdk.client import M2Client
from m2_sdk.exceptions import APIError, ConflictError, NotFoundError, ValidationError
from m2_sdk.services.inventory_service import InventoryService


class ProductService:
    """High-level service for product operations.

    Provides simple CRUD operations with automatic handling of:
    - SKU encoding (URL-safe)
    - Conflict detection (409 handling)
    - Not found handling (404)
    - Validation errors (400)
    - Retry logic for transient failures

    Example:
        >>> service = ProductService(client)
        >>>
        >>> # Get by SKU
        >>> product = service.get_by_sku("ABC-123")
        >>>
        >>> # Upsert (create or update)
        >>> result = service.upsert({
        ...     "sku": "ABC-123",
        ...     "name": "Product Name",
        ...     "price": 99.99
        ... })
        >>>
        >>> # Delete with safe handling
        >>> service.delete_by_sku("ABC-123", ignore_missing=True)
    """

    def __init__(self, client: M2Client) -> None:
        """Initialize product service.

        Args:
            client: M2Client instance.
        """
        self.client = client

    @staticmethod
    def _product_payload(data: dict[str, Any]) -> dict[str, Any]:
        """Wrap product writes in Magento's expected payload shape."""
        return {"product": data}

    def get_by_sku(self, sku: str) -> dict[str, Any] | None:
        """Get product by SKU."""
        try:
            return self.client.products(sku=sku).get()
        except NotFoundError:
            return None
        except APIError as e:
            if e.status_code == 404:
                return None
            raise

    def get_by_id(self, product_id: int) -> dict[str, Any] | None:
        """Get product by ID."""
        try:
            response = (
                self.client.products.filter(entity_id=str(product_id), condition="eq")
                .limit(1)
                .get()
            )
            items = response.get("items", [])
            return items[0] if items else None
        except NotFoundError:
            return None
        except APIError as e:
            if e.status_code == 404:
                return None
            raise

    def create(
        self,
        data: dict[str, Any],
        store_id: int | None = None,
    ) -> dict[str, Any]:
        """Create a new product."""
        if "sku" not in data:
            raise ValidationError("Product data must include 'sku'")

        builder = self.client.products
        if store_id:
            builder = builder.store(store_id)

        try:
            return builder.post(self._product_payload(data))
        except APIError as e:
            if e.status_code == 400:
                raise ValidationError(f"Invalid product data: {e}") from e
            elif e.status_code == 409:
                raise ConflictError(f"Product with SKU {data['sku']} already exists") from e
            raise

    def update(
        self,
        sku: str,
        data: dict[str, Any],
        store_id: int | None = None,
        create_if_missing: bool = False,
    ) -> dict[str, Any]:
        """Update an existing product."""
        builder = self.client.products(sku=sku)
        if store_id:
            builder = builder.store(store_id)

        try:
            return builder.put(self._product_payload(data))
        except NotFoundError:
            if create_if_missing:
                full_data = {**data, "sku": sku}
                return self.create(full_data, store_id)
            raise
        except APIError as e:
            if e.status_code == 400:
                raise ValidationError(f"Invalid product data: {e}") from e
            raise

    def upsert(
        self,
        data: dict[str, Any],
        store_id: int | None = None,
    ) -> dict[str, Any]:
        """Create or update a product."""
        sku = data.get("sku")
        if not sku:
            raise ValidationError("Product data must include 'sku'")

        try:
            return self.update(sku, data, store_id, create_if_missing=False)
        except NotFoundError:
            return self.create(data, store_id)

    def delete_by_sku(
        self,
        sku: str,
        ignore_missing: bool = False,
    ) -> bool:
        """Delete product by SKU."""
        try:
            self.client.products(sku=sku).delete()
            return True
        except NotFoundError:
            if ignore_missing:
                return False
            raise

    def delete_by_id(
        self,
        product_id: int,
        ignore_missing: bool = False,
    ) -> bool:
        """Delete product by ID."""
        product = self.get_by_id(product_id)
        if not product:
            if ignore_missing:
                return False
            raise NotFoundError(f"Product ID {product_id} not found")

        sku = product.get("sku")
        if not sku:
            raise NotFoundError(f"Product ID {product_id} has no SKU")

        return self.delete_by_sku(sku, ignore_missing)

    def update_status(
        self,
        sku: str,
        status: int,
        store_id: int | None = None,
    ) -> dict[str, Any]:
        """Update product status."""
        return self.update(sku, {"status": status}, store_id)

    def update_price(
        self,
        sku: str,
        price: float,
        store_id: int | None = None,
    ) -> dict[str, Any]:
        """Update product price."""
        return self.update(sku, {"price": price}, store_id)

    def update_stock(
        self,
        sku: str,
        qty: float,
        is_in_stock: bool = True,
        store_id: int | None = None,
    ) -> dict[str, Any]:
        """Update product stock."""
        updated = InventoryService(self.client).update_stock_item(
            sku=sku,
            qty=qty,
            is_in_stock=is_in_stock,
        )
        return updated.model_dump(exclude_none=True)

    def assign_category(
        self,
        sku: str,
        category_id: int,
        position: int = 0,
    ) -> dict[str, Any]:
        """Assign product to category."""
        category_link = {
            "category_links": [
                {
                    "category_id": category_id,
                    "position": position,
                }
            ]
        }
        return self.update(sku, category_link)

    def remove_category(
        self,
        sku: str,
        category_id: int,
    ) -> dict[str, Any]:
        """Remove product from category."""
        product = self.get_by_sku(sku)
        if not product:
            raise NotFoundError(f"Product {sku} not found")

        current_links = product.get("category_links", [])
        new_links = [link for link in current_links if link.get("category_id") != category_id]

        if len(new_links) == len(current_links):
            return product

        return self.update(sku, {"category_links": new_links})
