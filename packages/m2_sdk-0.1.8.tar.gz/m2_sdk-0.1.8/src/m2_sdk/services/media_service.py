"""Media management service for product images.

Provides high-level operations for uploading, updating, and managing
product media with automatic retry, deduplication, and role management.
"""

import base64
import hashlib
from pathlib import Path
from typing import Any

from m2_sdk.client import M2Client
from m2_sdk.exceptions import APIError, NotFoundError, ValidationError


class MediaService:
    """Service for product media operations.

    Handles image uploads with:
    - Automatic retry on failure
    - Deduplication by filename/hash
    - Image role management (base, small, thumbnail)
    - Bulk operations
    - URL/path/bytes support

    Example:
        >>> service = MediaService(client)
        >>>
        >>> # Upload from file path
        >>> media = service.upload_image(
        ...     sku="ABC-123",
        ...     image_path="/path/to/image.jpg",
        ...     label="Product Image",
        ...     types=["image", "small_image", "thumbnail"]
        ... )
        >>>
        >>> # Upload from URL
        >>> media = service.upload_from_url(
        ...     sku="ABC-123",
        ...     url="https://example.com/image.jpg"
        ... )
        >>>
        >>> # Set image roles
        >>> service.set_image_roles(sku="ABC-123", media_id=42, types=["image"])
    """

    def __init__(self, client: M2Client) -> None:
        """Initialize media service.

        Args:
            client: M2Client instance.
        """
        self.client = client

    def _calculate_hash(self, data: bytes) -> str:
        """Calculate MD5 hash of image data for deduplication."""
        return hashlib.md5(data).hexdigest()

    def _get_image_data(self, source: str | bytes | Path) -> bytes:
        """Get image data from various sources.

        Args:
            source: File path, URL, or bytes.

        Returns:
            Raw image bytes.

        Raises:
            ValidationError: If source is invalid or cannot be read.
        """
        if isinstance(source, bytes):
            return source

        if isinstance(source, Path):
            source = str(source)

        if isinstance(source, str):
            # Check if it's a URL
            if source.startswith(("http://", "https://")):
                try:
                    import httpx

                    response = httpx.get(source, timeout=30)
                    response.raise_for_status()
                    return response.content
                except Exception as e:
                    raise ValidationError(f"Failed to download image: {e}") from e
            else:
                # Treat as file path
                try:
                    return Path(source).read_bytes()
                except Exception as e:
                    raise ValidationError(f"Failed to read image file: {e}") from e

        raise ValidationError(f"Invalid image source type: {type(source)}")

    def get_media(
        self,
        sku: str,
        media_id: int | None = None,
    ) -> dict[str, Any] | list[dict[str, Any]]:
        """Get product media.

        Args:
            sku: Product SKU.
            media_id: Specific media ID, or None for all media.

        Returns:
            Media entry or list of all media.
        """
        builder = self.client.products(sku=sku).media

        if media_id:
            return builder(id=media_id).get()

        return builder.get()

    def upload_image(
        self,
        sku: str,
        image_path: str | Path | bytes,
        label: str = "",
        position: int = 0,
        types: list[str] | None = None,
        disabled: bool = False,
        replace_existing: bool = True,
    ) -> dict[str, Any]:
        """Upload product image.

        Args:
            sku: Product SKU.
            image_path: Path to image file, URL, or bytes.
            label: Image label/caption.
            position: Sort position.
            types: Image roles (image, small_image, thumbnail).
            disabled: Whether image is disabled.
            replace_existing: If True, replace existing image with same filename.

        Returns:
            Uploaded media data.

        Raises:
            ValidationError: If image cannot be processed.
            NotFoundError: If product doesn't exist.
        """
        # Get image data
        image_data = self._get_image_data(image_path)

        # Determine filename
        if isinstance(image_path, (str, Path)):
            filename = Path(image_path).name
        else:
            filename = f"image_{self._calculate_hash(image_data)[:8]}.jpg"

        # Check for existing media if replacing
        if replace_existing:
            try:
                existing = self.get_media(sku)
                if isinstance(existing, list):
                    for media in existing:
                        if media.get("file", "").endswith(filename):
                            # Delete existing
                            self.delete_image(sku, media["id"])
            except NotFoundError:
                pass

        # Build media data
        media_data: dict[str, Any] = {
            "entry": {
                "media_type": "image",
                "label": label or filename,
                "position": position,
                "disabled": disabled,
                "types": types or ["image"],
                "file": filename,
                "content": {
                    "base64_encoded_data": base64.b64encode(image_data).decode("ascii"),
                    "type": "image/jpeg",
                    "name": filename,
                },
            }
        }

        # Upload
        try:
            return self.client.products(sku=sku).media.post(media_data)
        except APIError as e:
            if e.status_code == 400:
                raise ValidationError(f"Invalid image data: {e}") from e
            raise

    def upload_from_url(
        self,
        sku: str,
        url: str,
        label: str = "",
        types: list[str] | None = None,
    ) -> dict[str, Any]:
        """Upload image from URL.

        Args:
            sku: Product SKU.
            url: Image URL.
            label: Image label.
            types: Image roles.

        Returns:
            Uploaded media data.
        """
        return self.upload_image(
            sku=sku,
            image_path=url,
            label=label,
            types=types,
        )

    def update_image(
        self,
        sku: str,
        media_id: int,
        label: str | None = None,
        position: int | None = None,
        types: list[str] | None = None,
        disabled: bool | None = None,
    ) -> dict[str, Any]:
        """Update existing media metadata.

        Args:
            sku: Product SKU.
            media_id: Media entry ID.
            label: New label (optional).
            position: New position (optional).
            types: New image roles (optional).
            disabled: New disabled state (optional).

        Returns:
            Updated media data.
        """
        # Get current data
        current = self.get_media(sku, media_id)
        if isinstance(current, list):
            current = current[0] if current else {}

        # Build update data
        update_data: dict[str, Any] = {"entry": {}}

        if label is not None:
            update_data["entry"]["label"] = label
        if position is not None:
            update_data["entry"]["position"] = position
        if types is not None:
            update_data["entry"]["types"] = types
        if disabled is not None:
            update_data["entry"]["disabled"] = disabled

        # Update
        return self.client.products(sku=sku).media(id=media_id).put(update_data)

    def set_image_roles(
        self,
        sku: str,
        media_id: int,
        types: list[str],
    ) -> dict[str, Any]:
        """Set image roles (base, small, thumbnail).

        Args:
            sku: Product SKU.
            media_id: Media entry ID.
            types: List of roles (image, small_image, thumbnail).

        Returns:
            Updated media data.
        """
        return self.update_image(sku, media_id, types=types)

    def delete_image(
        self,
        sku: str,
        media_id: int,
        ignore_missing: bool = False,
    ) -> bool:
        """Delete product image.

        Args:
            sku: Product SKU.
            media_id: Media entry ID.
            ignore_missing: If True, don't raise error if not found.

        Returns:
            True if deleted, False if not found (and ignore_missing=True).
        """
        try:
            self.client.products(sku=sku).media(id=media_id).delete()
            return True
        except NotFoundError:
            if ignore_missing:
                return False
            raise

    def delete_all_images(
        self,
        sku: str,
        keep_roles: list[str] | None = None,
    ) -> int:
        """Delete all product images.

        Args:
            sku: Product SKU.
            keep_roles: Optional list of image roles to preserve.

        Returns:
            Number of images deleted.
        """
        keep_roles = keep_roles or []
        media_list = self.get_media(sku)

        if isinstance(media_list, dict):
            media_list = [media_list]

        deleted = 0
        for media in media_list:
            media_id = media.get("id")
            media_types = media.get("types", [])

            # Skip if has protected role
            if any(role in keep_roles for role in media_types):
                continue

            if media_id:
                self.delete_image(sku, media_id, ignore_missing=True)
                deleted += 1

        return deleted

    def reorder_images(
        self,
        sku: str,
        media_ids: list[int],
    ) -> list[dict[str, Any]]:
        """Reorder product images by setting positions.

        Args:
            sku: Product SKU.
            media_ids: List of media IDs in desired order.

        Returns:
            Updated media list.
        """
        updated = []
        for position, media_id in enumerate(media_ids):
            result = self.update_image(sku, media_id, position=position)
            updated.append(result)
        return updated

    def upload_multiple(
        self,
        sku: str,
        images: list[dict[str, Any]],
        stop_on_error: bool = False,
    ) -> list[dict[str, Any] | Exception]:
        """Upload multiple images.

        Args:
            sku: Product SKU.
            images: List of image data dicts with keys:
                - path: Image path/URL/bytes
                - label: Optional label
                - types: Optional roles
                - position: Optional position
            stop_on_error: If True, stop on first error.

        Returns:
            List of results (media data or Exception).
        """
        results = []

        for idx, image_data in enumerate(images):
            try:
                result = self.upload_image(
                    sku=sku,
                    image_path=image_data["path"],
                    label=image_data.get("label", ""),
                    position=image_data.get("position", idx),
                    types=image_data.get("types"),
                )
                results.append(result)
            except Exception as e:
                results.append(e)
                if stop_on_error:
                    break

        return results

    def get_main_image(
        self,
        sku: str,
    ) -> dict[str, Any] | None:
        """Get the main/base image for a product.

        Args:
            sku: Product SKU.

        Returns:
            Main image media data or None.
        """
        media_list = self.get_media(sku)

        if isinstance(media_list, dict):
            media_list = [media_list]

        # Find image with 'image' type and lowest position
        main_images = [
            m for m in media_list if "image" in m.get("types", []) and not m.get("disabled")
        ]

        if main_images:
            return min(main_images, key=lambda x: x.get("position", 0))

        # Fallback to first non-disabled image
        for media in media_list:
            if not media.get("disabled"):
                return media

        return None

    def set_main_image(
        self,
        sku: str,
        media_id: int,
    ) -> dict[str, Any]:
        """Set image as main/base image.

        Args:
            sku: Product SKU.
            media_id: Media entry ID.

        Returns:
            Updated media data.
        """
        return self.set_image_roles(
            sku,
            media_id,
            types=["image", "small_image", "thumbnail"],
        )
