"""Batch operations service for bulk API operations.

Provides high-level batch operations with automatic pagination,
rate limiting, and retry handling.
"""

from collections.abc import Iterator
from typing import Any, TypeVar

from m2_sdk.catalog import CatalogStore
from m2_sdk.client import M2Client
from m2_sdk.exceptions import APIError

T = TypeVar("T")


class BatchService:
    """Service for batch operations with automatic pagination.

    Handles large dataset operations efficiently with:
    - Automatic pagination (cursor-based and offset-based)
    - Batch fetching with configurable sizes
    - Rate limiting and retry handling
    - Progress tracking and structured logging

    Example:
        >>> service = BatchService(client)
        >>>
        >>> # Iterate all products with automatic pagination
        >>> for product in service.iter_products(batch_size=100):
        ...     process(product)
        >>>
        >>> # Batch fetch specific IDs
        >>> products = service.get_products_by_ids([1, 2, 3, 4, 5])
        >>>
        >>> # Fetch by SKUs with automatic batching
        >>> products = service.get_products_by_skus(["SKU-001", "SKU-002"])
    """

    def __init__(self, client: M2Client) -> None:
        """Initialize batch service.

        Args:
            client: M2Client instance.
        """
        self.client = client

    def iter_products(
        self,
        batch_size: int = 100,
        filters: dict[str, Any] | None = None,
        sort_by: str = "entity_id",
        sort_order: str = "asc",
    ) -> Iterator[dict[str, Any]]:
        """Iterate all products with automatic pagination.

        Args:
            batch_size: Number of products per page.
            filters: Optional filter criteria.
            sort_by: Field to sort by.
            sort_order: Sort direction (asc/desc).

        Yields:
            Product dictionaries.

        Example:
            >>> for product in service.iter_products(batch_size=50):
            ...     print(f"{product['sku']}: {product['name']}")
        """
        page = 1
        total_fetched = 0

        while True:
            try:
                builder = (
                    self.client.products.limit(batch_size).page(page).sort_by(sort_by, sort_order)
                )

                if filters:
                    builder = builder.filter(**filters)

                response = builder.get()
                items = response.get("items", [])

                if not items:
                    break

                for item in items:
                    yield item
                    total_fetched += 1

                # Check if we've fetched everything
                total_count = response.get("total_count", 0)
                if total_fetched >= total_count:
                    break

                page += 1

            except APIError as e:
                if e.status_code == 429:
                    # Rate limited - retry delay handled by middleware
                    continue
                raise

    def iter_catalog(
        self,
        resource: str = "products",
        batch_size: int = 100,
        filters: dict[str, Any] | None = None,
    ) -> Iterator[tuple[str, dict[str, Any]]]:
        """Iterate catalog with key-value pairs.

        Similar to iter_products but returns (key, item) tuples
        suitable for building a CatalogStore.

        Args:
            resource: Resource type (products, orders, etc.).
            batch_size: Items per page.
            filters: Optional filter criteria.

        Yields:
            Tuples of (key, item) where key is the item identifier.
        """
        key_field = "sku" if resource == "products" else "id"

        for item in self.iter_products(batch_size=batch_size, filters=filters):
            key = str(item.get(key_field, item.get("id", "")))
            if key:
                yield (key, item)

    def get_products_by_ids(
        self,
        ids: list[int],
        batch_size: int = 100,
    ) -> dict[int, dict[str, Any]]:
        """Fetch products by IDs with automatic batching.

        Uses finset condition for efficient bulk lookup.

        Args:
            ids: List of product IDs to fetch.
            batch_size: Maximum IDs per request.

        Returns:
            Dictionary mapping ID to product data.

        Example:
            >>> products = service.get_products_by_ids([1, 2, 3, 4, 5])
            >>> print(products[1]["sku"])
        """
        if not ids:
            return {}

        result: dict[int, dict[str, Any]] = {}

        # Process in batches
        for i in range(0, len(ids), batch_size):
            batch = ids[i : i + batch_size]

            try:
                # Use finset condition for bulk lookup
                response = (
                    self.client.products.filter(
                        entity_id=",".join(map(str, batch)), condition="finset"
                    )
                    .limit(len(batch))
                    .get()
                )

                for item in response.get("items", []):
                    product_id = item.get("id")
                    if product_id:
                        result[product_id] = item

            except APIError:
                # Fall back to individual fetches on error
                for pid in batch:
                    try:
                        item = self.client.products(id=pid).get()
                        if item:
                            result[pid] = item
                    except APIError:
                        pass

        return result

    def get_products_by_skus(
        self,
        skus: list[str],
        batch_size: int = 100,
    ) -> dict[str, dict[str, Any]]:
        """Fetch products by SKUs with automatic batching.

        Args:
            skus: List of SKUs to fetch.
            batch_size: Maximum SKUs per request.

        Returns:
            Dictionary mapping SKU to product data.

        Example:
            >>> products = service.get_products_by_skus(["SKU-001", "SKU-002"])
            >>> print(products["SKU-001"]["name"])
        """
        if not skus:
            return {}

        result: dict[str, dict[str, Any]] = {}

        # Process in batches using finset
        for i in range(0, len(skus), batch_size):
            batch = skus[i : i + batch_size]

            try:
                response = (
                    self.client.products.filter(sku=",".join(batch), condition="finset")
                    .limit(len(batch))
                    .get()
                )

                for item in response.get("items", []):
                    sku = item.get("sku")
                    if sku:
                        result[sku] = item

            except APIError:
                # Fall back to individual fetches
                for sku in batch:
                    try:
                        item = self.client.products(sku=sku).get()
                        if item:
                            result[sku] = item
                    except APIError:
                        pass

        return result

    def sync_to_store(
        self,
        store: CatalogStore,
        resource: str = "products",
        filters: dict[str, Any] | None = None,
        batch_size: int = 100,
    ) -> int:
        """Sync catalog to a local store.

        Downloads entire catalog (or filtered subset) into a
        CatalogStore for offline operations.

        Args:
            store: CatalogStore to populate.
            resource: Resource type to sync.
            filters: Optional filter criteria.
            batch_size: Items per page.

        Returns:
            Number of items synced.

        Example:
            >>> store = CatalogStore("products.db")
            >>> count = service.sync_to_store(store, filters={"status": "1"})
            >>> print(f"Synced {count} active products")
        """
        count = 0

        for key, item in self.iter_catalog(resource, batch_size, filters):
            store.set(key, item)
            count += 1

        return count
