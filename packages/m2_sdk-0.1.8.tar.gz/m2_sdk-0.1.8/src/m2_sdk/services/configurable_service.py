"""Configurable product service for parent/child relationships.

Provides high-level operations for managing configurable products
with automatic attribute handling and child product linking.
"""

from contextlib import suppress
from typing import Any

from m2_sdk.client import M2Client
from m2_sdk.exceptions import APIError, NotFoundError, ValidationError


class ConfigurableProductService:
    """Service for configurable product operations.

    Simplifies working with configurable products by handling:
    - Parent product creation
    - Child product attachment
    - Super attribute management
    - Option value handling
    - Price/tier price management

    Example:
        >>> service = ConfigurableProductService(client)
        >>>
        >>> # Create configurable parent
        >>> parent = service.create_parent(
        ...     sku="CONFIG-001",
        ...     name="Configurable Product",
        ...     price=99.99,
        ...     super_attributes=["color", "size"]
        ... )
        >>>
        >>> # Attach children
        >>> service.attach_children(
        ...     parent_sku="CONFIG-001",
        ...     child_skus=["CHILD-RED-S", "CHILD-BLUE-M"]
        ... )
    """

    def __init__(self, client: M2Client) -> None:
        """Initialize configurable product service.

        Args:
            client: M2Client instance.
        """
        self.client = client

    @staticmethod
    def _product_payload(data: dict[str, Any]) -> dict[str, Any]:
        """Wrap configurable product writes in Magento's expected payload shape."""
        return {"product": data}

    def create_parent(
        self,
        sku: str,
        name: str,
        price: float,
        super_attributes: list[str],
        attribute_set_id: int = 4,
        visibility: int = 4,
        status: int = 1,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Create a configurable parent product.

        Args:
            sku: Parent SKU.
            name: Product name.
            price: Base price.
            super_attributes: Attribute codes used for configuration.
            attribute_set_id: Attribute set ID.
            visibility: Visibility (4 = catalog/search).
            status: Status (1 = enabled).
            **kwargs: Additional product data.

        Returns:
            Created product data.
        """
        product_data = {
            "sku": sku,
            "name": name,
            "price": price,
            "type_id": "configurable",
            "attribute_set_id": attribute_set_id,
            "status": status,
            "visibility": visibility,
            "extension_attributes": {
                "configurable_product_options": [
                    {
                        "attribute_id": attr,
                        "label": attr.replace("_", " ").title(),
                    }
                    for attr in super_attributes
                ]
            },
            **kwargs,
        }

        try:
            return self.client.products.post(self._product_payload(product_data))
        except APIError as e:
            if e.status_code == 400:
                raise ValidationError(f"Invalid product data: {e}") from e
            raise

    def attach_children(
        self,
        parent_sku: str,
        child_skus: list[str],
        validate: bool = True,
    ) -> dict[str, Any]:
        """Attach child products to configurable parent.

        Args:
            parent_sku: Parent configurable SKU.
            child_skus: List of child SKUs to attach.
            validate: If True, validate children exist first.

        Returns:
            Updated parent product data.

        Raises:
            NotFoundError: If parent or any child not found.
            ValidationError: If child products are invalid.
        """
        if validate:
            # Verify parent exists
            try:
                self.client.products(sku=parent_sku).get()
            except APIError as err:
                raise NotFoundError(f"Configurable parent {parent_sku} not found") from err

            # Verify all children exist
            for child_sku in child_skus:
                try:
                    self.client.products(sku=child_sku).get()
                except APIError as err:
                    raise NotFoundError(f"Child product {child_sku} not found") from err

        # Build child links
        child_links = [{"sku": child_sku, "qty": 1} for child_sku in child_skus]

        update_data = {"extension_attributes": {"configurable_product_links": child_links}}

        return self.client.products(sku=parent_sku).put(self._product_payload(update_data))

    def detach_children(
        self,
        parent_sku: str,
        child_skus: list[str],
    ) -> dict[str, Any]:
        """Detach child products from configurable parent.

        Args:
            parent_sku: Parent configurable SKU.
            child_skus: List of child SKUs to detach.

        Returns:
            Updated parent product data.
        """
        # Get current parent
        try:
            parent = self.client.products(sku=parent_sku).get()
        except APIError as err:
            raise NotFoundError(f"Configurable parent {parent_sku} not found") from err

        # Get current links
        ext_attrs = parent.get("extension_attributes", {})
        current_links = ext_attrs.get("configurable_product_links", [])

        # Filter out detached children
        new_links = [link for link in current_links if link.get("sku") not in child_skus]

        update_data = {"extension_attributes": {"configurable_product_links": new_links}}

        return self.client.products(sku=parent_sku).put(self._product_payload(update_data))

    def get_children(
        self,
        parent_sku: str,
    ) -> list[dict[str, Any]]:
        """Get all child products of a configurable.

        Args:
            parent_sku: Parent configurable SKU.

        Returns:
            List of child product data.
        """
        try:
            parent = self.client.products(sku=parent_sku).get()
        except APIError as err:
            raise NotFoundError(f"Configurable parent {parent_sku} not found") from err

        ext_attrs = parent.get("extension_attributes", {})
        child_links = ext_attrs.get("configurable_product_links", [])

        children = []
        for link in child_links:
            child_sku = link.get("sku")
            if child_sku:
                try:
                    child = self.client.products(sku=child_sku).get()
                    children.append(child)
                except APIError:
                    pass  # Skip if child not found

        return children

    def update_super_attributes(
        self,
        parent_sku: str,
        super_attributes: list[dict[str, Any]],
    ) -> dict[str, Any]:
        """Update super attributes for configurable.

        Args:
            parent_sku: Parent configurable SKU.
            super_attributes: List of attribute configs with keys:
                - attribute_id: Attribute ID or code
                - label: Display label
                - values: List of option values

        Returns:
            Updated product data.
        """
        options = [
            {
                "attribute_id": attr.get("attribute_id"),
                "label": attr.get("label", ""),
                "values": attr.get("values", []),
            }
            for attr in super_attributes
        ]

        update_data = {"extension_attributes": {"configurable_product_options": options}}

        return self.client.products(sku=parent_sku).put(self._product_payload(update_data))

    def set_child_prices(
        self,
        parent_sku: str,
        price_overrides: dict[str, float],
    ) -> dict[str, Any]:
        """Set custom prices for specific children.

        Args:
            parent_sku: Parent configurable SKU.
            price_overrides: Dict mapping child SKU to custom price.

        Returns:
            Updated parent product data.
        """
        # Get current children
        children = self.get_children(parent_sku)

        # Update each child with custom price
        for child in children:
            child_sku = child.get("sku")
            if child_sku in price_overrides:
                new_price = price_overrides[child_sku]
                self.client.products(sku=child_sku).put(self._product_payload({"price": new_price}))

        # Return updated parent
        return self.client.products(sku=parent_sku).get()

    def is_configurable(
        self,
        sku: str,
    ) -> bool:
        """Check if product is configurable.

        Args:
            sku: Product SKU.

        Returns:
            True if configurable, False otherwise.
        """
        try:
            product = self.client.products(sku=sku).get()
            return product.get("type_id") == "configurable"
        except APIError:
            return False

    def get_configurable_options(
        self,
        parent_sku: str,
    ) -> list[dict[str, Any]]:
        """Get configurable attribute options.

        Args:
            parent_sku: Parent configurable SKU.

        Returns:
            List of configurable option data.
        """
        try:
            product = self.client.products(sku=parent_sku).get()
        except APIError as err:
            raise NotFoundError(f"Configurable {parent_sku} not found") from err

        ext_attrs = product.get("extension_attributes", {})
        return ext_attrs.get("configurable_product_options", [])

    def delete_parent(
        self,
        parent_sku: str,
        delete_children: bool = False,
    ) -> bool:
        """Delete configurable parent.

        Args:
            parent_sku: Parent configurable SKU.
            delete_children: If True, also delete all children.

        Returns:
            True if deleted.
        """
        if delete_children:
            children = self.get_children(parent_sku)
            for child in children:
                child_sku = child.get("sku")
                if child_sku:
                    with suppress(APIError):
                        self.client.products(sku=child_sku).delete()

        self.client.products(sku=parent_sku).delete()
        return True
