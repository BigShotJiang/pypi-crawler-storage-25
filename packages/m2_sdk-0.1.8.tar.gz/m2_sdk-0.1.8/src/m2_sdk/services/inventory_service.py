"""Inventory management service for stock operations.

Provides high-level operations for managing product inventory
with support for both simple stock and MSI (Multi-Source Inventory).
"""

from typing import Any

from m2_sdk.client import M2Client
from m2_sdk.exceptions import APIError, NotFoundError, ValidationError
from m2_sdk.models import StockItem


class InventoryService:
    """Service for inventory operations.

    Handles stock operations with:
    - Simple stock updates (legacy)
    - MSI multi-source support
    - Bulk operations
    - Stock status management
    - Reservation/salable qty checks

    Example:
        >>> service = InventoryService(client)
        >>>
        >>> # Update simple stock
        >>> service.update_stock("ABC-123", qty=100, is_in_stock=True)
        >>>
        >>> # Update MSI source
        >>> service.update_source_item(
        ...     sku="ABC-123",
        ...     source_code="default",
        ...     qty=100
        ... )
        >>>
        >>> # Check salable quantity
        >>> salable = service.get_salable_qty("ABC-123")
    """

    def __init__(self, client: M2Client) -> None:
        """Initialize inventory service.

        Args:
            client: M2Client instance.
        """
        self.client = client
        self._msi_available: bool | None = None

    def _check_msi(self) -> bool:
        """Check if MSI is available.

        Returns:
            True if MSI endpoints are available.
        """
        if self._msi_available is not None:
            return self._msi_available

        try:
            # Try to access MSI endpoint
            self.client.inventory.sources().limit(1).get()
            self._msi_available = True
        except APIError:
            self._msi_available = False

        return self._msi_available

    def get_stock_item(
        self,
        sku: str,
    ) -> StockItem | None:
        """Get stock item for product.

        Args:
            sku: Product SKU.

        Returns:
            Typed stock item or None.
        """
        try:
            return self.client.stock_items(sku).typed(StockItem).get()
        except APIError:
            return None

    def get_stock_items(self, skus: list[str]) -> dict[str, StockItem]:
        """Get stock items for multiple SKUs."""
        items: dict[str, StockItem] = {}

        for sku in skus:
            stock_item = self.get_stock_item(sku)
            if stock_item is not None:
                items[sku] = stock_item

        return items

    def _build_stock_item_payload(
        self,
        current: StockItem | None,
        qty: float | None,
        is_in_stock: bool | None,
        manage_stock: bool | None,
        extra: dict[str, Any],
    ) -> dict[str, Any]:
        """Build a fuller stock item payload for Magento stock updates."""
        stock_item: dict[str, Any] = (
            current.model_dump(exclude_none=True) if current is not None else {}
        )
        stock_item.update(extra)

        if qty is not None:
            stock_item["qty"] = qty
        elif current is not None and current.qty is not None:
            stock_item["qty"] = current.qty

        if is_in_stock is not None:
            stock_item["is_in_stock"] = is_in_stock
        elif current is not None and current.is_in_stock is not None:
            stock_item["is_in_stock"] = current.is_in_stock

        if manage_stock is not None:
            stock_item["manage_stock"] = manage_stock
        elif current is not None and current.manage_stock is not None:
            stock_item["manage_stock"] = current.manage_stock

        return stock_item

    def update_stock_item(
        self,
        sku: str,
        qty: float | None = None,
        is_in_stock: bool | None = None,
        manage_stock: bool | None = None,
        **extra: Any,
    ) -> StockItem:
        """Update a stock item and return the typed fresh state."""
        current = self.get_stock_item(sku)
        stock_item = self._build_stock_item_payload(
            current,
            qty=qty,
            is_in_stock=is_in_stock,
            manage_stock=manage_stock,
            extra=dict(extra),
        )

        if not stock_item:
            raise ValidationError("No stock item fields provided for update")

        payload = {"stockItem": stock_item}

        try:
            self.client.stock_items(sku=sku).put(payload)
        except APIError as e:
            if e.status_code == 400:
                raise ValidationError(f"Invalid stock data: {e}") from e
            if e.status_code == 404 and current is not None and current.item_id is not None:
                try:
                    self.client.products(sku=sku).stock_items(current.item_id).put(payload)
                except APIError as fallback_error:
                    if fallback_error.status_code == 400:
                        raise ValidationError(
                            f"Invalid stock data: {fallback_error}"
                        ) from fallback_error
                    raise
            else:
                raise

        updated = self.get_stock_item(sku)
        if updated is None:
            raise NotFoundError(f"Stock item for SKU {sku} not found after update")
        return updated

    def update_stock(
        self,
        sku: str,
        qty: float,
        is_in_stock: bool = True,
        manage_stock: bool = True,
    ) -> StockItem:
        """Update product stock (legacy simple stock).

        Args:
            sku: Product SKU.
            qty: Quantity.
            is_in_stock: Stock status.
            manage_stock: Whether stock is managed.

        Returns:
            Updated stock item.
        """
        return self.update_stock_item(
            sku,
            qty=qty,
            is_in_stock=is_in_stock,
            manage_stock=manage_stock,
        )

    def update_source_item(
        self,
        sku: str,
        source_code: str,
        qty: float,
        status: int = 1,
    ) -> dict[str, Any]:
        """Update MSI source item quantity.

        Args:
            sku: Product SKU.
            source_code: Source code (e.g., "default", "warehouse_1").
            qty: Quantity.
            status: Source item status.

        Returns:
            Updated source item data.

        Raises:
            NotFoundError: If MSI not available or item not found.
        """
        if not self._check_msi():
            raise NotFoundError("MSI not available, use update_stock() instead")

        source_item = {
            "sourceItems": [
                {
                    "sku": sku,
                    "source_code": source_code,
                    "quantity": qty,
                    "status": status,
                }
            ]
        }

        try:
            return self.client.inventory.source_items().post(source_item)
        except APIError as e:
            if e.status_code == 400:
                raise ValidationError(f"Invalid source item data: {e}") from e
            raise

    def get_source_items(
        self,
        sku: str | None = None,
        source_code: str | None = None,
    ) -> list[dict[str, Any]]:
        """Get source items (MSI).

        Args:
            sku: Filter by SKU (optional).
            source_code: Filter by source code (optional).

        Returns:
            List of source item data.
        """
        if not self._check_msi():
            return []

        builder = self.client.inventory.source_items()

        if sku:
            builder = builder.sku(sku)
        if source_code:
            builder = builder.source_code(source_code)

        try:
            response = builder.get()
            return response.get("items", [])
        except APIError:
            return []

    def get_salable_qty(
        self,
        sku: str,
        stock_id: int = 1,
    ) -> float:
        """Get salable quantity for product.

        Args:
            sku: Product SKU.
            stock_id: Stock ID.

        Returns:
            Salable quantity (available for sale).
        """
        try:
            response = self.client.inventory.salable(sku=sku, stockId=stock_id).get()
            return float(response.get("salable_qty", 0))
        except APIError:
            # Fall back to simple stock qty
            stock = self.get_stock_item(sku)
            if stock:
                return float(stock.qty or 0)
            return 0.0

    def check_is_salable(
        self,
        sku: str,
        qty: float = 1,
        stock_id: int = 1,
    ) -> bool:
        """Check if quantity is salable.

        Args:
            sku: Product SKU.
            qty: Quantity to check.
            stock_id: Stock ID.

        Returns:
            True if quantity is available for sale.
        """
        try:
            response = (
                self.client.inventory.salable(
                    sku=sku,
                    stockId=stock_id,
                )
                .are_product_salable(
                    skuRequests=[{"sku": sku, "qty": qty}],
                    stockId=stock_id,
                )
                .get()
            )

            results = response.get("items", [])
            return all(r.get("is_salable", False) for r in results)
        except APIError:
            # Fall back to simple check
            stock = self.get_stock_item(sku)
            if stock:
                return bool(stock.is_in_stock) and float(stock.qty or 0) >= qty
            return False

    def bulk_update_source_items(
        self,
        items: list[dict[str, Any]],
        stop_on_error: bool = False,
    ) -> list[dict[str, Any] | Exception]:
        """Update multiple source items.

        Args:
            items: List of source item data with keys:
                - sku: Product SKU
                - source_code: Source code
                - quantity: Quantity
                - status: Status (optional)
            stop_on_error: If True, stop on first error.

        Returns:
            List of results (data or Exception).
        """
        if not self._check_msi():
            raise NotFoundError("MSI not available")

        results = []

        for item in items:
            try:
                result = self.update_source_item(
                    sku=item["sku"],
                    source_code=item["source_code"],
                    qty=item["quantity"],
                    status=item.get("status", 1),
                )
                results.append(result)
            except Exception as e:
                results.append(e)
                if stop_on_error:
                    break

        return results

    def get_sources(
        self,
    ) -> list[dict[str, Any]]:
        """Get all MSI sources.

        Returns:
            List of source data.
        """
        if not self._check_msi():
            return []

        try:
            response = self.client.inventory.sources().get()
            return response.get("items", [])
        except APIError:
            return []

    def get_stocks(
        self,
    ) -> list[dict[str, Any]]:
        """Get all MSI stocks.

        Returns:
            List of stock data.
        """
        if not self._check_msi():
            return []

        try:
            response = self.client.inventory.stocks().get()
            return response.get("items", [])
        except APIError:
            return []

    def assign_source_to_stock(
        self,
        source_code: str,
        stock_id: int,
    ) -> dict[str, Any]:
        """Assign source to stock.

        Args:
            source_code: Source code.
            stock_id: Stock ID.

        Returns:
            Assignment data.
        """
        if not self._check_msi():
            raise NotFoundError("MSI not available")

        assignment = {
            "stockSourceLink": {
                "stock_id": stock_id,
                "source_code": source_code,
            }
        }

        return self.client.inventory.stock_source_links().post(assignment)

    def low_stock_report(
        self,
        threshold: float = 10.0,
    ) -> list[dict[str, Any]]:
        """Get products with low stock.

        Args:
            threshold: Quantity threshold.

        Returns:
            List of low stock items.
        """
        if self._check_msi():
            # Use MSI low stock endpoint
            try:
                response = self.client.inventory.low_stock().qty(threshold).get()
                return response.get("items", [])
            except APIError:
                pass

        # Fallback: iterate products
        low_stock = []
        page = 1

        while True:
            try:
                response = self.client.products.limit(100).page(page).get()

                items = response.get("items", [])
                if not items:
                    break

                for product in items:
                    sku = product.get("sku")
                    if sku:
                        stock = self.get_stock_item(sku)
                        if stock:
                            qty = float(stock.qty or 0)
                            if qty < threshold:
                                low_stock.append(
                                    {
                                        "sku": sku,
                                        "name": product.get("name"),
                                        "qty": qty,
                                        "threshold": threshold,
                                    }
                                )

                page += 1

            except APIError:
                break

        return low_stock
