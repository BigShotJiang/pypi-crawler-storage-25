from __future__ import annotations

from turbo_agent_runtime.utils.message_converter import _content_to_openai_content


def test_content_to_openai_content_preserves_openai_parts():
    content = [
        {"type": "text", "text": "hello"},
        {"type": "image_url", "image_url": {"url": "data:image/png;base64,abc"}},
    ]

    result = _content_to_openai_content(content)

    assert result == content