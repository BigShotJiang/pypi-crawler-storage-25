"""
django_flosse
~~~~~~~~~~

Dead-simple Server-Sent Events for Django.

Quick start::

    from django_flosse import sse_stream, SSEEvent
    from django_flosse.permissions import IsAuthenticated

    @sse_stream(heartbeat_interval=10, permission_classes=[IsAuthenticated])
    def live_updates(request):
        yield "connected"                              # plain string
        yield ("update", {"count": 1})                # (event, data) tuple
        yield {"data": "done", "event": "finish"}     # dict
        yield SSEEvent(data="bye", event="close")     # SSEEvent object
"""

from .decorators import sse_stream
from .events import SSEEvent
from .exceptions import SSEClientDisconnected, SSEPermissionDenied, SSEYieldError
from .formatters import to_sse


__all__ = [
    "sse_stream",
    "SSEEvent",
    "to_sse",
    "SSEClientDisconnected",
    "SSEPermissionDenied",
    "SSEYieldError",
]

__version__ = "0.1.0"
