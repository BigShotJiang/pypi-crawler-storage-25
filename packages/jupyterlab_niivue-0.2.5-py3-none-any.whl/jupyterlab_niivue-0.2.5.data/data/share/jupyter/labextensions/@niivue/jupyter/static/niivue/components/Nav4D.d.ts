import { Signal } from '@preact/signals';
import { ExtendedNiivue } from '../events';
interface Nav4DProps {
    nv: ExtendedNiivue;
    nvArray: Signal<ExtendedNiivue[]>;
    volumeIndex: number;
    vol4D: Signal<number>;
    isPlaying: Signal<boolean>;
    isEditingVol4D: Signal<boolean>;
    syncedIndices: Signal<Set<number>>;
}
export declare const Nav4D: ({ nv, nvArray, volumeIndex, vol4D, isPlaying, isEditingVol4D, syncedIndices }: Nav4DProps) => import("preact").JSX.Element;
export {};
