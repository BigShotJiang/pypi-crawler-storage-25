"use strict";
(self["webpackChunk_niivue_jupyter"] = self["webpackChunk_niivue_jupyter"] || []).push([["lib_index_js"],{

/***/ "./lib/index.js":
/*!**********************!*\
  !*** ./lib/index.js ***!
  \**********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _jupyterlab_docmanager__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/docmanager */ "webpack/sharing/consume/default/@jupyterlab/docmanager");
/* harmony import */ var _jupyterlab_docmanager__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_docmanager__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_filebrowser__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/filebrowser */ "webpack/sharing/consume/default/@jupyterlab/filebrowser");
/* harmony import */ var _jupyterlab_filebrowser__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_filebrowser__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _jupyterlab_translation__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @jupyterlab/translation */ "webpack/sharing/consume/default/@jupyterlab/translation");
/* harmony import */ var _jupyterlab_translation__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_translation__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _viewer__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./viewer */ "./lib/viewer.js");




const FACTORY_NAME = 'Niivue Viewer';
const COMPARE_COMMAND_ID = 'jupyterlab-niivue:compare';
const plugin = {
    id: 'jupyterlab-niivue:plugin',
    description: 'A JupyterLab extension for viewing NIfTI files with Niivue',
    autoStart: true,
    requires: [_jupyterlab_docmanager__WEBPACK_IMPORTED_MODULE_0__.IDocumentManager, _jupyterlab_filebrowser__WEBPACK_IMPORTED_MODULE_1__.IFileBrowserFactory],
    optional: [_jupyterlab_translation__WEBPACK_IMPORTED_MODULE_2__.ITranslator],
    activate: (app, docManager, browserFactory, translator) => {
        console.log('JupyterLab extension jupyterlab-niivue is activated!');
        const trans = (translator !== null && translator !== void 0 ? translator : _jupyterlab_translation__WEBPACK_IMPORTED_MODULE_2__.nullTranslator).load('jupyterlab');
        // All supported file types
        const fileTypes = [
            'nii',
            'nii.gz',
            'dcm',
            'mih',
            'mif',
            'mif.gz',
            'nhdr',
            'nrrd',
            'mhd',
            'mha',
            'mgh',
            'mgz',
            'v',
            'v16',
            'vmr',
            'mz3',
            'gii',
            'mnc',
            'npy',
            'npz',
        ];
        const widgetFactory = new _viewer__WEBPACK_IMPORTED_MODULE_3__.NiivueViewer.Factory({
            name: FACTORY_NAME,
            fileTypes: fileTypes,
            defaultFor: fileTypes,
            modelName: 'base64',
        }, docManager, app.serviceManager.serverSettings);
        widgetFactory.widgetCreated.connect((_sender, widget) => {
            console.log('Niivue widget created:', widget);
            // widget.title.icon = 'jp-MaterialIcon jp-ImageIcon';
            widget.context.pathChanged.connect(() => {
                widget.title.label = widget.context.localPath.split('/').pop() || '';
            });
        });
        app.docRegistry.addWidgetFactory(widgetFactory);
        // Add compare command
        app.commands.addCommand(COMPARE_COMMAND_ID, {
            label: trans.__('Compare in NiiVue'),
            caption: trans.__('Open selected images in NiiVue compare view'),
            execute: () => {
                const { tracker } = browserFactory;
                const widget = tracker.currentWidget;
                if (!widget) {
                    return;
                }
                const selectedItems = Array.from(widget.selectedItems());
                if (selectedItems.length < 2) {
                    console.warn('Please select at least 2 files to compare');
                    return;
                }
                // Create a compare view widget
                _viewer__WEBPACK_IMPORTED_MODULE_3__.NiivueViewer.createCompareView(app, docManager, selectedItems);
            },
            isVisible: () => {
                const { tracker } = browserFactory;
                const widget = tracker.currentWidget;
                if (!widget) {
                    return false;
                }
                const selectedItems = Array.from(widget.selectedItems());
                // Only show if multiple files are selected and they are all supported types
                return (selectedItems.length >= 2 &&
                    selectedItems.every((item) => {
                        const ext = item.name.toLowerCase();
                        return fileTypes.some((type) => ext.endsWith(`.${type}`));
                    }));
            },
        });
        // Add context menu item
        app.contextMenu.addItem({
            command: COMPARE_COMMAND_ID,
            selector: '.jp-DirListing-item[data-isdir="false"]',
            rank: 3,
        });
        // Register all file types
        const fileTypeConfigs = [
            {
                name: 'nii',
                displayName: 'NIfTI File',
                extensions: ['.nii'],
                mimeTypes: ['application/x-nifti'],
            },
            {
                name: 'nii.gz',
                displayName: 'Compressed NIfTI File',
                extensions: ['.nii.gz'],
                mimeTypes: ['application/x-nifti-gz'],
            },
            {
                name: 'dcm',
                displayName: 'DICOM File',
                extensions: ['.dcm'],
                mimeTypes: ['application/dicom'],
            },
            {
                name: 'mih',
                displayName: 'MIH File',
                extensions: ['.mih'],
                mimeTypes: ['application/octet-stream'],
            },
            {
                name: 'mif',
                displayName: 'MIF File',
                extensions: ['.mif'],
                mimeTypes: ['application/octet-stream'],
            },
            {
                name: 'mif.gz',
                displayName: 'Compressed MIF File',
                extensions: ['.mif.gz'],
                mimeTypes: ['application/octet-stream'],
            },
            {
                name: 'nhdr',
                displayName: 'NRRD Header File',
                extensions: ['.nhdr'],
                mimeTypes: ['application/octet-stream'],
            },
            {
                name: 'nrrd',
                displayName: 'NRRD File',
                extensions: ['.nrrd'],
                mimeTypes: ['application/octet-stream'],
            },
            {
                name: 'mhd',
                displayName: 'MetaImage Header File',
                extensions: ['.mhd'],
                mimeTypes: ['application/octet-stream'],
            },
            {
                name: 'mha',
                displayName: 'MetaImage File',
                extensions: ['.mha'],
                mimeTypes: ['application/octet-stream'],
            },
            {
                name: 'mgh',
                displayName: 'MGH File',
                extensions: ['.mgh'],
                mimeTypes: ['application/octet-stream'],
            },
            {
                name: 'mgz',
                displayName: 'Compressed MGH File',
                extensions: ['.mgz'],
                mimeTypes: ['application/octet-stream'],
            },
            {
                name: 'v',
                displayName: 'BrainVoyager V File',
                extensions: ['.v'],
                mimeTypes: ['application/octet-stream'],
            },
            {
                name: 'v16',
                displayName: 'BrainVoyager V16 File',
                extensions: ['.v16'],
                mimeTypes: ['application/octet-stream'],
            },
            {
                name: 'vmr',
                displayName: 'BrainVoyager VMR File',
                extensions: ['.vmr'],
                mimeTypes: ['application/octet-stream'],
            },
            {
                name: 'mz3',
                displayName: 'MZ3 Mesh File',
                extensions: ['.mz3'],
                mimeTypes: ['application/octet-stream'],
            },
            {
                name: 'gii',
                displayName: 'GIFTI File',
                extensions: ['.gii'],
                mimeTypes: ['application/octet-stream'],
            },
            {
                name: 'mnc',
                displayName: 'MINC File',
                extensions: ['.mnc'],
                mimeTypes: ['application/octet-stream'],
            },
            {
                name: 'npy',
                displayName: 'NumPy Array File',
                extensions: ['.npy'],
                mimeTypes: ['application/octet-stream'],
            },
            {
                name: 'npz',
                displayName: 'NumPy Compressed Archive',
                extensions: ['.npz'],
                mimeTypes: ['application/octet-stream'],
            },
        ];
        fileTypeConfigs.forEach((config) => {
            app.docRegistry.addFileType({
                name: config.name,
                displayName: config.displayName,
                extensions: config.extensions,
                mimeTypes: config.mimeTypes,
                iconClass: 'jp-Icon jp-NiivueFileIcon',
            });
        });
    },
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (plugin);


/***/ }),

/***/ "./lib/url-utils.js":
/*!**************************!*\
  !*** ./lib/url-utils.js ***!
  \**************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   fetchArrayBuffer: () => (/* binding */ fetchArrayBuffer),
/* harmony export */   fetchJson: () => (/* binding */ fetchJson),
/* harmony export */   getContentsUrl: () => (/* binding */ getContentsUrl),
/* harmony export */   getFileUrl: () => (/* binding */ getFileUrl),
/* harmony export */   getJupyterUrl: () => (/* binding */ getJupyterUrl)
/* harmony export */ });
/* harmony import */ var _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/coreutils */ "webpack/sharing/consume/default/@jupyterlab/coreutils");
/* harmony import */ var _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/services */ "webpack/sharing/consume/default/@jupyterlab/services");
/* harmony import */ var _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__);


/**
 * Constructs a URL using the JupyterLab base URL.
 * Uses URLExt.join for proper path joining with JupyterHub prefixes.
 */
function getJupyterUrl(path) {
    return _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0__.URLExt.join(_jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0__.PageConfig.getBaseUrl(), path);
}
/**
 * Constructs a file URL using server settings base URL.
 * This respects JupyterHub prefixes like /user/<name>/.
 */
function getFileUrl(baseUrl, filePath) {
    return _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0__.URLExt.join(baseUrl, 'files', _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0__.URLExt.encodeParts(filePath));
}
/**
 * Constructs a contents API URL using server settings base URL.
 * This respects JupyterHub prefixes like /user/<name>/.
 */
function getContentsUrl(baseUrl, path) {
    return _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0__.URLExt.join(baseUrl, 'api/contents', _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0__.URLExt.encodeParts(path));
}
/**
 * Fetches an ArrayBuffer from the given URL using ServerConnection.
 * Handles authentication and provides detailed error messages.
 */
async function fetchArrayBuffer(url, serverSettings) {
    var _a;
    let response;
    try {
        response = await _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__.ServerConnection.makeRequest(url, { method: 'GET' }, serverSettings);
    }
    catch (error) {
        throw new Error(`Request failed (${url}): ${error instanceof Error ? error.message : String(error)}`);
    }
    if (!response.ok) {
        let detail = '';
        try {
            const text = await response.text();
            if (text) {
                detail = `; ${text.slice(0, 300)}`;
            }
        }
        catch (_b) {
            // ignore
        }
        throw new Error(`HTTP ${response.status} ${response.statusText}${detail}`);
    }
    const contentType = (_a = response.headers.get('content-type')) !== null && _a !== void 0 ? _a : '';
    if (contentType.includes('text/html')) {
        throw new Error(`Unexpected HTML response (likely auth redirect). Final URL: ${response.url || url}`);
    }
    return response.arrayBuffer();
}
/**
 * Fetches JSON from the given URL using ServerConnection.
 * Handles authentication and provides detailed error messages.
 */
async function fetchJson(url, serverSettings) {
    const response = await _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__.ServerConnection.makeRequest(url, { method: 'GET' }, serverSettings);
    if (!response.ok) {
        throw new Error(`HTTP ${response.status} ${response.statusText}`);
    }
    return (await response.json());
}


/***/ }),

/***/ "./lib/viewer.js":
/*!***********************!*\
  !*** ./lib/viewer.js ***!
  \***********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   NiivueViewer: () => (/* binding */ NiivueViewer),
/* harmony export */   NiivueWidget: () => (/* binding */ NiivueWidget)
/* harmony export */ });
/* harmony import */ var _jupyterlab_docregistry__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/docregistry */ "webpack/sharing/consume/default/@jupyterlab/docregistry");
/* harmony import */ var _jupyterlab_docregistry__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_docregistry__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_filebrowser__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/filebrowser */ "webpack/sharing/consume/default/@jupyterlab/filebrowser");
/* harmony import */ var _jupyterlab_filebrowser__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_filebrowser__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _lumino_widgets__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @lumino/widgets */ "webpack/sharing/consume/default/@lumino/widgets");
/* harmony import */ var _lumino_widgets__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_lumino_widgets__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _url_utils__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./url-utils */ "./lib/url-utils.js");




class NiivueWidget extends _lumino_widgets__WEBPACK_IMPORTED_MODULE_2__.Widget {
    constructor(context, docManager, serverSettings) {
        super();
        this._context = context;
        this._docManager = docManager;
        this._serverSettings = serverSettings;
        this.addClass('jp-NiivueWidget');
        this._iframe = document.createElement('iframe');
        this._iframe.style.width = '100%';
        this._iframe.style.height = '100%';
        this._iframe.style.border = 'none';
        this.node.appendChild(this._iframe);
        this._onMessage = this._handleIframeMessage.bind(this);
        this._initializeViewer();
    }
    _initializeViewer() {
        try {
            const filePath = this._context.path;
            console.log('Initializing this.onResize Niivue viewer for file:', filePath);
            const html = this._getHtmlForViewer();
            // Write HTML to iframe
            this._iframe.srcdoc = html;
            // Set up message passing from iframe
            window.addEventListener('message', this._onMessage);
            // Set up message passing
            this._iframe.onload = () => {
                console.log('Iframe loaded, initializing viewer');
                // Send initial settings to initialize the app
                setTimeout(() => {
                    this._sendInitSettings();
                    // Then send the image
                    setTimeout(() => {
                        console.log('Sending message with image: ', filePath);
                        this._sendAddImageMessage(filePath);
                    }, 500);
                }, 100);
            };
            console.log('Niivue viewer initialized successfully');
        }
        catch (error) {
            console.error('Failed to initialize Niivue viewer:', error);
            this._showError(`Failed to initialize viewer: ${error instanceof Error ? error.message : 'Unknown error'}`);
        }
    }
    _getHtmlForViewer() {
        // Use the static file handler we set up in handlers.py
        const scriptPath = (0,_url_utils__WEBPACK_IMPORTED_MODULE_3__.getJupyterUrl)('lab/extensions/@niivue/jupyter/static/niivue/index.js');
        const cssPath = (0,_url_utils__WEBPACK_IMPORTED_MODULE_3__.getJupyterUrl)('lab/extensions/@niivue/jupyter/static/niivue/index.css');
        return `<!doctype html>
          <html lang="en">
            <head>
              <meta charset="utf-8" />
              <style>
                /* Embed critical CSS to avoid loading issues */
                body { margin: 0; padding: 0; background: #1a1a1a; color: white; font-family: system-ui, sans-serif; }
                #app { width: 100vw; height: 100vh; }
                .loading { display: flex; justify-content: center; align-items: center; height: 100vh; }
                .error { display: flex; flex-direction: column; justify-content: center; align-items: center; height: 100vh; color: #ff6b6b; }
              </style>
              <link rel="stylesheet" crossorigin href="${cssPath}">
            </head>
            <body class="text-white p-0">
              <div id="app" class="w-screen h-screen">
                <div class="loading">Loading NIfTI viewer...</div>
              </div>
              <script>
                // Mock vscode API for Jupyter environment
                window.vscode = {
                  postMessage: function(message) {
                    window.parent.postMessage(message, '*');
                  }
                };
              </script>
              <script type="module" crossorigin src="${scriptPath}"
                      onerror="document.getElementById('app').innerHTML = '<div class=\\"error\\"><h3>Failed to load NIfTI viewer</h3><p>Could not load the required JavaScript files</p></div>';">
              </script>
            </body>
          </html>`;
    }
    _sendInitSettings() {
        if (this._iframe.contentWindow) {
            const defaultSettings = {
                showCrosshairs: true,
                interpolation: true,
                colorbar: false,
                radiologicalConvention: false,
                zoomDragMode: false,
                defaultVolumeColormap: 'gray',
                defaultOverlayColormap: 'redyell',
            };
            console.log('Sending init settings:', defaultSettings);
            this._iframe.contentWindow.postMessage({
                type: 'initSettings',
                body: defaultSettings,
            }, '*');
        }
    }
    async _sendAddImageMessage(filePath) {
        if (this._iframe.contentWindow) {
            try {
                console.log('Reading file data for:', filePath);
                const fileUrl = (0,_url_utils__WEBPACK_IMPORTED_MODULE_3__.getFileUrl)(this._serverSettings.baseUrl, filePath);
                console.log('Fetching file from URL:', fileUrl);
                const buffer = await (0,_url_utils__WEBPACK_IMPORTED_MODULE_3__.fetchArrayBuffer)(fileUrl, this._serverSettings);
                console.log('Sending file data to iframe, size:', buffer.byteLength);
                // Send the file data directly to the iframe
                this._iframe.contentWindow.postMessage({
                    type: 'addImage',
                    body: {
                        data: buffer,
                        uri: filePath,
                    },
                }, '*');
            }
            catch (error) {
                console.error('Error reading file:', error);
                this._showError(`Could not load file: ${filePath}\n${error instanceof Error ? error.message : String(error)}`);
            }
        }
    }
    _showError(message) {
        const errorDiv = document.createElement('div');
        errorDiv.className = 'jp-NiivueWidget-error';
        errorDiv.innerHTML = `
      <div style="padding: 20px; text-align: center; color: #d32f2f;">
        <h3>Error Loading NIfTI File</h3>
        <p>${message}</p>
      </div>
    `;
        this.node.innerHTML = '';
        this.node.appendChild(errorDiv);
    }
    async _handleIframeMessage(event) {
        // Only handle messages from our iframe
        if (event.source !== this._iframe.contentWindow) {
            return;
        }
        const message = event.data;
        switch (message.type) {
            case 'addImages':
                await this._handleAddImages();
                break;
            case 'addOverlay':
                await this._handleAddOverlay(message.body);
                break;
            case 'addDcmFolder':
                await this._handleAddDcmFolder();
                break;
        }
    }
    async _handleAddImages() {
        // Use JupyterLab's FileDialog to select files from workspace
        try {
            const result = await _jupyterlab_filebrowser__WEBPACK_IMPORTED_MODULE_1__.FileDialog.getOpenFiles({
                manager: this._docManager,
                filter: (model) => {
                    // Allow directories for navigation
                    if (model.type === 'directory') {
                        return { score: 1 };
                    }
                    // Allow all files - NiiVue will handle unsupported formats gracefully
                    if (model.type === 'file') {
                        return { score: 1 };
                    }
                    return null;
                },
            });
            if (result.button.accept &&
                result.value &&
                result.value.length > 0 &&
                this._iframe.contentWindow) {
                // Send initCanvas message first
                this._iframe.contentWindow.postMessage({
                    type: 'initCanvas',
                    body: { n: result.value.length },
                }, '*');
                // Then send each file
                for (const item of result.value) {
                    const filePath = item.path;
                    await this._loadFileAndSend(filePath, 'addImage', undefined);
                }
            }
        }
        catch (error) {
            console.error('Error opening file dialog:', error);
        }
    }
    async _loadFileAndSend(filePath, messageType, body) {
        if (this._iframe.contentWindow) {
            try {
                const fileUrl = (0,_url_utils__WEBPACK_IMPORTED_MODULE_3__.getFileUrl)(this._serverSettings.baseUrl, filePath);
                const buffer = await (0,_url_utils__WEBPACK_IMPORTED_MODULE_3__.fetchArrayBuffer)(fileUrl, this._serverSettings);
                this._iframe.contentWindow.postMessage({
                    type: messageType,
                    body: {
                        data: buffer,
                        uri: filePath,
                        ...body,
                    },
                }, '*');
            }
            catch (error) {
                console.error('Error reading file:', error);
                this._showError(`Could not load file: ${filePath}\n${error instanceof Error ? error.message : String(error)}`);
            }
        }
    }
    async _handleAddOverlay(body) {
        // Use JupyterLab's FileDialog to select a file from workspace
        try {
            const result = await _jupyterlab_filebrowser__WEBPACK_IMPORTED_MODULE_1__.FileDialog.getOpenFiles({
                manager: this._docManager,
                filter: (model) => {
                    // Allow directories for navigation
                    if (model.type === 'directory') {
                        return { score: 1 };
                    }
                    // Allow all files - NiiVue will handle unsupported formats gracefully
                    if (model.type === 'file') {
                        return { score: 1 };
                    }
                    return null;
                },
            });
            if (result.button.accept && result.value && result.value.length > 0) {
                const filePath = result.value[0].path;
                await this._loadFileAndSend(filePath, body.type, { index: body.index });
            }
        }
        catch (error) {
            console.error('Error opening file dialog:', error);
        }
    }
    async _handleAddDcmFolder() {
        // Use JupyterLab's FileDialog to select a directory
        const result = await _jupyterlab_filebrowser__WEBPACK_IMPORTED_MODULE_1__.FileDialog.getExistingDirectory({
            manager: this._docManager,
        });
        if (result.button.accept &&
            result.value &&
            result.value.length > 0 &&
            this._iframe.contentWindow) {
            const dirPath = result.value[0].path;
            try {
                // List all files in the directory
                const dirData = await (0,_url_utils__WEBPACK_IMPORTED_MODULE_3__.fetchJson)((0,_url_utils__WEBPACK_IMPORTED_MODULE_3__.getContentsUrl)(this._serverSettings.baseUrl, dirPath), this._serverSettings);
                const files = dirData.content.filter((item) => item.type === 'file');
                if (files.length > 0) {
                    // Load all files
                    const fileBuffers = await Promise.all(files.map(async (file) => {
                        const fileUrl = (0,_url_utils__WEBPACK_IMPORTED_MODULE_3__.getFileUrl)(this._serverSettings.baseUrl, file.path);
                        return (0,_url_utils__WEBPACK_IMPORTED_MODULE_3__.fetchArrayBuffer)(fileUrl, this._serverSettings);
                    }));
                    this._iframe.contentWindow.postMessage({
                        type: 'addImage',
                        body: {
                            data: fileBuffers,
                            uri: files.map((f) => f.name),
                        },
                    }, '*');
                }
            }
            catch (error) {
                console.error('Error reading DICOM folder:', error);
                this._showError(`Could not load DICOM folder: ${dirPath}\n${error instanceof Error ? error.message : String(error)}`);
            }
        }
    }
    onResize() {
        // Resize is handled by the iframe content
        console.log('Widget resized');
    }
    dispose() {
        // Remove message listener
        window.removeEventListener('message', this._onMessage);
        // Cleanup iframe
        if (this._iframe) {
            this._iframe.remove();
        }
        super.dispose();
    }
}
var NiivueViewer;
(function (NiivueViewer) {
    class Factory extends _jupyterlab_docregistry__WEBPACK_IMPORTED_MODULE_0__.ABCWidgetFactory {
        constructor(options, docManager, serverSettings) {
            super(options);
            this._docManager = docManager;
            this._serverSettings = serverSettings;
        }
        createNewWidget(context) {
            console.log('Creating new Niivue widget for context:', context);
            const content = new NiivueWidget(context, this._docManager, this._serverSettings);
            const widget = new _jupyterlab_docregistry__WEBPACK_IMPORTED_MODULE_0__.DocumentWidget({ content, context });
            return widget;
        }
    }
    NiivueViewer.Factory = Factory;
    /**
     * Create a compare view widget for multiple images
     */
    function createCompareView(app, docManager, selectedItems) {
        const widget = new CompareWidget(selectedItems, docManager, app.serviceManager.serverSettings);
        widget.title.label = `Compare (${selectedItems.length} images)`;
        widget.title.closable = true;
        app.shell.add(widget, 'main');
        app.shell.activateById(widget.id);
    }
    NiivueViewer.createCompareView = createCompareView;
})(NiivueViewer || (NiivueViewer = {}));
/**
 * Widget for comparing multiple NIfTI images
 * Shares core functionality with NiivueWidget but initializes with multiple panels
 */
class CompareWidget extends NiivueWidget {
    constructor(selectedItems, docManager, serverSettings) {
        // Create a dummy context - we won't use it for compare view
        const dummyContext = {
            path: '',
            localPath: '',
            pathChanged: { connect: () => { } },
        };
        super(dummyContext, docManager, serverSettings);
        this._selectedItems = selectedItems;
        this.removeClass('jp-NiivueWidget');
        this.addClass('jp-NiivueCompareWidget');
        this.id = `niivue-compare-${Date.now()}`;
        // Re-initialize for compare mode
        this._initializeCompareView();
    }
    _initializeCompareView() {
        this._iframe.onload = () => {
            console.log('Compare view iframe loaded');
            setTimeout(() => {
                this._sendInitSettings();
                // Initialize with multiple panels
                if (this._iframe.contentWindow) {
                    this._iframe.contentWindow.postMessage({
                        type: 'initCanvas',
                        body: { n: this._selectedItems.length },
                    }, '*');
                }
                setTimeout(() => {
                    this._loadAllImages();
                }, 500);
            }, 100);
        };
        // Trigger onload
        if (this._iframe.contentWindow) {
            this._iframe.onload(new Event('load'));
        }
    }
    async _loadAllImages() {
        for (const item of this._selectedItems) {
            await this._loadFileAndSend(item.path, 'addImage');
        }
    }
}


/***/ })

}]);
//# sourceMappingURL=lib_index_js.2b8baa95e106381e9490.js.map