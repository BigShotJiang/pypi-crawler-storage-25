from __future__ import annotations

from dataclasses import dataclass
from typing import List, Optional
from urllib.parse import urlencode, urljoin

import httpx

from .models import ErrorResponse, HealthCheck, Session


class OIDCProxyError(Exception):
    """Represents an error response from OIDC-proxy."""

    def __init__(self, error: ErrorResponse) -> None:
        self.error = error
        super().__init__(f"{error.status} {error.message} ({error.path})")


@dataclass
class AuthorizeInput:
    redirect_uri: str


@dataclass
class AuthorizeCallbackInput:
    code: Optional[str] = None
    state: Optional[str] = None
    error: Optional[str] = None
    error_description: Optional[str] = None


class OIDCProxyClient:
    """Synchronous HTTP client for kafka-admin-agent OIDC-proxy.

    Интерфейс повторяет Go-интерфейс `OIDCProxyClient`:
    - Healthy / Ready
    - Authorize / AuthorizeCallback
    - FindSession / DeleteSession
    """

    def __init__(
        self,
        base_url: str,
        timeout: float = 30.0,
        client: Optional[httpx.Client] = None,
    ) -> None:
        self._base_url = base_url.rstrip("/")
        self._client = client or httpx.Client(timeout=timeout)

    def close(self) -> None:
        self._client.close()

    # Health API

    def healthy(self) -> bool:
        """Check liveness endpoint `/api/v1/health/liveness`."""
        url = urljoin(self._base_url + "/", "api/v1/health/liveness")
        resp = self._client.get(url)
        if resp.status_code != 200:
            self._raise_for_error(resp)
        return True

    def ready(self) -> bool:
        """Check readiness endpoint `/api/v1/health/readiness`."""
        url = urljoin(self._base_url + "/", "api/v1/health/readiness")
        resp = self._client.get(url)
        if resp.status_code not in (200, 503):
            self._raise_for_error(resp)

        # Ответ — список HealthCheck, но Go-клиент возвращает только bool.
        # Для совместимости возвращаем True при 200, False при 503.
        return resp.status_code == 200

    # OIDC API

    def authorize(self, input: AuthorizeInput) -> str:
        """Call `/api/v1/oidc/authorize` and return redirect location."""
        query = urlencode({"redirect_uri": input.redirect_uri})
        url = urljoin(self._base_url + "/", f"api/v1/oidc/authorize?{query}")
        resp = self._client.get(url, follow_redirects=False)

        if resp.status_code != 302:
            self._raise_for_error(resp)

        location = resp.headers.get("Location")
        if not location:
            raise RuntimeError("Missing Location header in authorize response")
        return location

    def authorize_callback(self, input: AuthorizeCallbackInput) -> Session:
        """Call `/api/v1/oidc/authorize/callback` and return session data."""
        query_params = {
            "code": input.code,
            "state": input.state,
            "error": input.error,
            "error_description": input.error_description,
        }
        filtered = {k: v for k, v in query_params.items() if v is not None}
        query = urlencode(filtered)
        url = urljoin(self._base_url + "/", f"api/v1/oidc/authorize/callback?{query}")

        resp = self._client.get(url)
        if resp.status_code != 200:
            self._raise_for_error(resp)

        return Session.model_validate(resp.json())

    # Session API

    def find_session(self, user_id: str) -> Optional[Session]:
        """Get session by user id from `/api/v1/sessions/{userID}`.

        Возвращает:
        - Session при 200
        - None при 404
        - бросает OIDCProxyError для остальных кодов
        """
        url = urljoin(self._base_url + "/", f"api/v1/sessions/{user_id}")
        resp = self._client.get(url)

        if resp.status_code == 404:
            return None
        if resp.status_code != 200:
            self._raise_for_error(resp)

        return Session.model_validate(resp.json())

    def delete_session(self, user_id: str) -> None:
        """Delete session by user id via `DELETE /api/v1/sessions/{userID}`."""
        url = urljoin(self._base_url + "/", f"api/v1/sessions/{user_id}")
        resp = self._client.delete(url)

        if resp.status_code == 204:
            return
        self._raise_for_error(resp)

    # Helpers

    def _raise_for_error(self, resp: httpx.Response) -> None:
        try:
            payload = resp.json()
        except Exception:
            resp.raise_for_status()
            return

        try:
            error = ErrorResponse.model_validate(payload)
        except Exception:
            resp.raise_for_status()
            return

        raise OIDCProxyError(error)
