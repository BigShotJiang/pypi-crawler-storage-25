from __future__ import annotations

from datetime import datetime
from typing import List, Optional

from pydantic import BaseModel, ConfigDict


class Locale(BaseModel):
    """Loosely-typed locale information.

    The Go implementation uses `oidc.Locale` which can contain provider-specific
    fields, so we allow extra keys here.
    """

    model_config = ConfigDict(extra="allow")


class UserInfo(BaseModel):
    birthdate: Optional[str] = None
    email: Optional[str] = None
    email_verified: Optional[bool] = None
    family_name: Optional[str] = None
    gender: Optional[str] = None
    given_name: Optional[str] = None
    locale: Optional[Locale] = None
    middle_name: Optional[str] = None
    name: Optional[str] = None
    nickname: Optional[str] = None
    permissions: Optional[List[str]] = None
    phone_number: Optional[str] = None
    phone_number_verified: Optional[bool] = None
    picture: Optional[str] = None
    preferred_username: Optional[str] = None
    profile: Optional[str] = None
    roles: Optional[List[str]] = None
    updated_at: Optional[str] = None
    website: Optional[str] = None
    zoneinfo: Optional[str] = None


class Session(BaseModel):
    user_id: str
    user_info: UserInfo
    expiry_time: datetime


class HealthCheck(BaseModel):
    type: str
    check: bool


class ErrorResponse(BaseModel):
    timestamp: datetime
    message: str
    status: int
    path: str

