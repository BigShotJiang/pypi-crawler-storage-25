# oidc-proxy-python-sdk

Python SDK для сервиса `oidc-proxy`.

SDK реализует модели API и клиент, повторяющий интерфейс Go-клиента:

- `Healthy` / `Ready`
- `Authorize` / `AuthorizeCallback`
- `FindSession` / `DeleteSession`

## Установка

Из корня репозитория:

```bash
cd oidc-proxy/oidc-proxy-python-sdk
poetry install
```

## Использование

```python
from oidc_proxy_sdk import (
    OIDCProxyClient,
    AuthorizeInput,
    AuthorizeCallbackInput,
    OIDCProxyError,
)

client = OIDCProxyClient(base_url="http://localhost:8080")

# Health
client.healthy()  # -> True или OIDCProxyError
client.ready()    # -> True (200) или False (503)

# Авторизация
location = client.authorize(AuthorizeInput(redirect_uri="https://example.com/callback"))
print("Redirect user to:", location)

# Callback
session = client.authorize_callback(
    AuthorizeCallbackInput(
        code="code-from-provider",
        state="state-from-cookie",
    )
)
print(session.user_id, session.user_info.email)

# Сессии
session = client.find_session("user-id-123")
if session:
    print("Session expiry:", session.expiry_time)

client.delete_session("user-id-123")
```

## Модели

Модели соответствуют OpenAPI-схеме `oidc-proxy`:

- `Session` — структура ответа `/api/v1/sessions/{userID}` и `/api/v1/oidc/authorize/callback`
- `UserInfo` — данные пользователя (включая `roles` и `permissions`)
- `HealthCheck` — элемент ответа `/api/v1/health/readiness`
- `ErrorResponse` — тело ошибки, возвращаемое API

