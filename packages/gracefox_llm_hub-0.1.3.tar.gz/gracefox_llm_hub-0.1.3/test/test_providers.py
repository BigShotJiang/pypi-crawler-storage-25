"""测试提供商"""

import unittest
from unittest.mock import Mock, patch
from llm_hub.providers.openai_compatible import OpenAICompatibleProvider
from llm_hub.providers.ollama import OllamaProvider
from llm_hub.models.message import Conversation


class TestOpenAICompatibleProvider(unittest.TestCase):
    """测试OpenAI兼容提供商"""
    
    def setUp(self):
        self.config = {
            "api_url": "https://api.openai.com/v1",
            "api_key": "test-key",
            "model": "gpt-3.5-turbo",
            "debug": True
        }
        self.provider = OpenAICompatibleProvider(self.config)
    
    @patch('requests.post')
    def test_chat(self, mock_post):
        """测试对话"""
        mock_response = Mock()
        mock_response.json.return_value = {
            "choices": [{"message": {"content": "Hello!"}}],
            "model": "gpt-3.5-turbo"
        }
        mock_post.return_value = mock_response
        
        conv = Conversation()
        conv.add_user("Hi")
        
        response = self.provider.chat(conv)
        self.assertEqual(response.content, "Hello!")
    
    @patch('requests.post')
    def test_complete(self, mock_post):
        """测试补全"""
        mock_response = Mock()
        mock_response.json.return_value = {
            "choices": [{"text": "Completion text"}],
            "model": "gpt-3.5-turbo"
        }
        mock_post.return_value = mock_response
        
        response = self.provider.complete("Complete this")
        self.assertEqual(response.content, "Completion text")
    
    @patch('requests.get')
    def test_health_check(self, mock_get):
        """测试健康检查"""
        mock_response = Mock()
        mock_response.status_code = 200
        mock_get.return_value = mock_response
        
        self.assertTrue(self.provider.health_check())


class TestOllamaProvider(unittest.TestCase):
    """测试Ollama提供商"""
    
    def setUp(self):
        self.config = {
            "ollama_url": "http://localhost:11434",
            "model": "llama2",
            "debug": True
        }
        self.provider = OllamaProvider(self.config)
    
    @patch('requests.post')
    def test_chat(self, mock_post):
        """测试对话"""
        mock_response = Mock()
        mock_response.json.return_value = {
            "message": {"content": "Hello from Ollama!"}
        }
        mock_post.return_value = mock_response
        
        conv = Conversation()
        conv.add_user("Hi")
        
        response = self.provider.chat(conv)
        self.assertEqual(response.content, "Hello from Ollama!")
    
    @patch('requests.get')
    def test_list_models(self, mock_get):
        """测试列出模型"""
        mock_response = Mock()
        mock_response.json.return_value = {
            "models": [{"name": "llama2"}, {"name": "mistral"}]
        }
        mock_response.status_code = 200
        mock_get.return_value = mock_response
        
        models = self.provider.list_models()
        self.assertEqual(len(models), 2)
        self.assertIn("llama2", models)


if __name__ == "__main__":
    unittest.main()