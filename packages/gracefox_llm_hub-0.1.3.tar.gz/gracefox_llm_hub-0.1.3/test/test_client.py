"""测试客户端"""

import unittest
from unittest.mock import Mock, patch
from llm_hub import LLMClient, LLMConfig, Provider
from llm_hub.models.message import Conversation, Message


class TestLLMClient(unittest.TestCase):
    """测试LLMClient"""
    
    def setUp(self):
        """设置测试环境"""
        self.config = LLMConfig(
            provider=Provider.OPENAI,
            model="gpt-3.5-turbo",
            api_key="test-key",
            debug=True
        )
        self.client = LLMClient(self.config)
    
    def test_config_loading(self):
        """测试配置加载"""
        self.assertEqual(self.client.config.provider, Provider.OPENAI)
        self.assertEqual(self.client.config.model, "gpt-3.5-turbo")
    
    def test_update_config(self):
        """测试更新配置"""
        self.client.update_config(temperature=0.5, max_tokens=1000)
        self.assertEqual(self.client.config.temperature, 0.5)
        self.assertEqual(self.client.config.max_tokens, 1000)
    
    def test_chat_with_string(self):
        """测试字符串对话"""
        with patch.object(self.client._provider, 'chat') as mock_chat:
            mock_chat.return_value.content = "Hello!"
            response = self.client.chat("Hi")
            self.assertEqual(response.content, "Hello!")
    
    def test_chat_with_messages(self):
        """测试消息列表对话"""
        messages = [
            {"role": "user", "content": "Hello"},
            {"role": "assistant", "content": "Hi"}
        ]
        with patch.object(self.client._provider, 'chat') as mock_chat:
            mock_chat.return_value.content = "How are you?"
            response = self.client.chat(messages)
            self.assertEqual(response.content, "How are you?")
    
    def test_chat_with_conversation(self):
        """测试对话对象"""
        conv = Conversation()
        conv.add_user("Hello")
        with patch.object(self.client._provider, 'chat') as mock_chat:
            mock_chat.return_value.content = "Hi there!"
            response = self.client.chat(conv)
            self.assertEqual(response.content, "Hi there!")
    
    def test_complete(self):
        """测试补全"""
        with patch.object(self.client._provider, 'complete') as mock_complete:
            mock_complete.return_value.content = "This is a completion"
            response = self.client.complete("Complete this")
            self.assertEqual(response.content, "This is a completion")
    
    def test_health_check(self):
        """测试健康检查"""
        with patch.object(self.client._provider, 'health_check') as mock_health:
            mock_health.return_value = True
            self.assertTrue(self.client.health_check())
    
    def test_save_load_config(self):
        """测试保存加载配置"""
        import tempfile
        import os
        
        with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
            self.client.save_config(f.name)
            f.close()
            
            new_client = LLMClient.from_config_file(f.name)
            self.assertEqual(new_client.config.model, self.client.config.model)
            
            os.unlink(f.name)


if __name__ == "__main__":
    unittest.main()