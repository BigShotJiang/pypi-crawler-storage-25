"""流式输出示例"""

from llm_hub import LLMClient, LLMConfig, Provider


def streaming_chat():
    """流式对话示例"""
    config = LLMConfig(
        provider=Provider.DEEPSEEK,
        model="deepseek-chat",
        api_key="your-api-key",
        stream=True
    )
    
    client = LLMClient(config)
    
    print("助手: ", end="", flush=True)
    for chunk in client.stream_chat("讲一个关于机器学习的短故事"):
        print(chunk, end="", flush=True)
    print()


def streaming_with_callback():
    """带回调的流式输出"""
    config = LLMConfig(
        provider=Provider.OLLAMA,
        model="llama2",
        stream=True
    )
    
    client = LLMClient(config)
    
    def on_chunk(chunk):
        print(f"收到块: {chunk[:50]}...")
    
    print("开始流式输出...")
    for chunk in client.stream_chat("介绍一下Python"):
        on_chunk(chunk)


if __name__ == "__main__":
    streaming_chat()