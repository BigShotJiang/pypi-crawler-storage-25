"""基本使用示例"""

from llm_hub import LLMClient, LLMConfig, Provider


def basic_chat():
    """基本对话示例"""
    # 使用DeepSeek
    config = LLMConfig(
        provider=Provider.DEEPSEEK,
        model="deepseek-chat",
        api_key="your-api-key"
    )
    
    client = LLMClient(config)
    
    # 单轮对话
    response = client.chat("什么是人工智能？")
    print(response.content)


def multi_turn_chat():
    """多轮对话示例"""
    from llm_hub.models.message import Conversation
    
    client = LLMClient.from_config_file("config.json")
    conv = Conversation()
    
    conv.add_user("你好，我叫小明")
    response = client.chat(conv)
    print(f"助手: {response.content}")
    conv.add_assistant(response.content)
    
    conv.add_user("你还记得我叫什么吗？")
    response = client.chat(conv)
    print(f"助手: {response.content}")


def streaming():
    """流式输出示例"""
    client = LLMClient(LLMConfig(
        provider=Provider.OPENAI,
        model="gpt-3.5-turbo",
        api_key="your-api-key",
        stream=True
    ))
    
    print("助手: ", end="")
    for chunk in client.stream_chat("讲一个短故事"):
        print(chunk, end="", flush=True)
    print()


if __name__ == "__main__":
    basic_chat()