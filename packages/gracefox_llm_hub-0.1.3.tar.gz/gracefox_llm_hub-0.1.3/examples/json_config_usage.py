"""JSON配置使用示例"""

import json
from llm_hub import LLMClient, LLMConfig, merge_configs, get_config_manager


def example_1_from_json_string():
    """示例1: 从JSON字符串创建配置"""
    json_str = '''
    {
        "provider": "deepseek",
        "model": "deepseek-chat",
        "api_key": "your-api-key",
        "temperature": 0.8,
        "max_tokens": 1500
    }
    '''
    
    config = LLMConfig.from_json(json_str)
    client = LLMClient(config)
    
    response = client.chat("你好，请介绍一下自己")
    print(f"JSON字符串配置结果: {response.content[:100]}...")
    print()


def example_2_from_json_file():
    """示例2: 从JSON文件创建配置"""
    # 假设有 config.json 文件
    try:
        config = LLMConfig.from_file("config.json")
        client = LLMClient(config)
        response = client.chat("你好")
        print(f"文件配置结果: {response.content[:100]}...")
    except FileNotFoundError:
        print("config.json 文件不存在，跳过示例2")
    print()


def example_3_merge_configs():
    """示例3: 合并多个配置"""
    # 基础配置
    base_config = LLMConfig(
        provider="openai",
        model="gpt-3.5-turbo",
        temperature=0.7,
        max_tokens=1000
    )
    
    # 覆盖配置（字典）
    override_dict = {
        "provider": "deepseek",
        "model": "deepseek-chat",
        "temperature": 0.9
    }
    
    # 合并
    merged_config = merge_configs(base_config, override_dict)
    
    print("基础配置:", base_config.provider, base_config.model)
    print("覆盖配置:", override_dict)
    print("合并结果:", merged_config.provider, merged_config.model, f"温度={merged_config.temperature}")
    print()


def example_4_multi_source():
    """示例4: 多源配置（档案 + 文件 + 覆盖）"""
    manager = get_config_manager()
    
    # 保存一个配置档案
    manager.add_profile(
        "my-deepseek",
        {
            "provider": "deepseek",
            "model": "deepseek-chat",
            "api_key": "sk-xxx",
            "temperature": 0.7
        },
        "我的DeepSeek配置"
    )
    
    # 构建配置（档案 + 覆盖）
    config = manager.build_config(
        profile="my-deepseek",
        max_tokens=3000,
        stream=True
    )
    
    print(f"多源配置结果: provider={config.provider}, model={config.model}, "
          f"max_tokens={config.max_tokens}, stream={config.stream}")
    
    # 列出所有档案
    profiles = manager.list_profiles()
    print(f"已保存的档案: {profiles}")
    print()


def example_5_from_environment():
    """示例5: 从环境变量创建配置"""
    import os
    
    # 设置环境变量（示例）
    os.environ["LLM_PROVIDER"] = "deepseek"
    os.environ["LLM_MODEL"] = "deepseek-chat"
    os.environ["LLM_TEMPERATURE"] = "0.5"
    
    manager = get_config_manager()
    config = manager.create_from_env()
    
    print(f"环境变量配置: provider={config.provider}, model={config.model}, "
          f"temperature={config.temperature}")
    print()


def example_6_dynamic_config():
    """示例6: 运行时动态修改配置"""
    config = LLMConfig(
        provider="deepseek",
        model="deepseek-chat",
        api_key="your-key",
        temperature=0.7
    )
    
    client = LLMClient(config)
    print(f"初始温度: {client.config.temperature}")
    
    # 运行时修改配置
    client.update_config(temperature=1.2, max_tokens=3000)
    print(f"修改后温度: {client.config.temperature}")
    print(f"修改后max_tokens: {client.config.max_tokens}")
    print()


def example_7_export_config():
    """示例7: 导出配置为JSON"""
    config = LLMConfig(
        provider="deepseek",
        model="deepseek-chat",
        api_key="sk-test",
        temperature=0.8
    )
    
    # 导出为JSON字符串
    json_str = config.to_json(indent=2)
    print("导出为JSON:")
    print(json_str)
    
    # 保存到文件
    config.save("exported_config.json")
    print("配置已保存到 exported_config.json")
    print()


def example_8_validate_config():
    """示例8: 配置验证（使用JSON Schema）"""
    manager = get_config_manager()
    schema = manager.to_json_schema()
    
    print("配置JSON Schema:")
    print(json.dumps(schema, indent=2, ensure_ascii=False)[:500] + "...")
    print()


if __name__ == "__main__":
    print("=" * 50)
    print("JSON配置使用示例")
    print("=" * 50)
    print()
    
    example_1_from_json_string()
    example_3_merge_configs()
    example_4_multi_source()
    example_5_from_environment()
    example_6_dynamic_config()
    example_7_export_config()
    example_8_validate_config()