"""环境感知示例"""

import psutil
import platform
from llm_hub import LLMClient, LLMConfig, Provider


def get_system_info() -> str:
    """获取系统信息"""
    info = f"""
系统: {platform.system()} {platform.release()}
CPU使用率: {psutil.cpu_percent()}%
内存使用率: {psutil.virtual_memory().percent}%
运行进程数: {len(psutil.pids())}
    """
    return info.strip()


def environment_aware_chat():
    """环境感知对话"""
    config = LLMConfig(
        provider=Provider.DEEPSEEK,
        model="deepseek-chat",
        api_key="your-api-key"
    )
    
    client = LLMClient(config)
    
    # 获取环境信息
    system_info = get_system_info()
    
    # 构建提示
    prompt = f"""你是一个智能助手，了解用户的系统环境。

当前系统信息：
{system_info}

用户问：我的系统资源使用情况如何？有什么优化建议吗？

请基于系统信息给出回答。"""
    
    response = client.complete(prompt)
    print(response.content)


if __name__ == "__main__":
    environment_aware_chat()