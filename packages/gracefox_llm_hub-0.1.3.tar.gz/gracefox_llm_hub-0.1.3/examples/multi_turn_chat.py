"""多轮对话示例"""

from llm_hub import LLMClient, LLMConfig, Provider
from llm_hub.models.message import Conversation


def multi_turn_with_history():
    """带历史记录的多轮对话"""
    config = LLMConfig(
        provider=Provider.OPENAI,
        model="gpt-3.5-turbo",
        api_key="your-api-key"
    )
    
    client = LLMClient(config)
    conv = Conversation()
    
    # 第一轮
    conv.add_user("我叫小明，我喜欢编程")
    response = client.chat(conv)
    print(f"助手: {response.content}")
    conv.add_assistant(response.content)
    
    # 第二轮
    conv.add_user("你还记得我叫什么吗？")
    response = client.chat(conv)
    print(f"助手: {response.content}")
    conv.add_assistant(response.content)
    
    # 第三轮
    conv.add_user("我喜欢什么？")
    response = client.chat(conv)
    print(f"助手: {response.content}")


def chat_with_system_prompt():
    """带系统提示的对话"""
    config = LLMConfig(
        provider=Provider.DEEPSEEK,
        model="deepseek-chat",
        api_key="your-api-key"
    )
    
    client = LLMClient(config)
    conv = Conversation(system_prompt="你是一个专业的Python编程助手")
    
    conv.add_user("如何读取文件？")
    response = client.chat(conv)
    print(f"助手: {response.content}")


if __name__ == "__main__":
    multi_turn_with_history()