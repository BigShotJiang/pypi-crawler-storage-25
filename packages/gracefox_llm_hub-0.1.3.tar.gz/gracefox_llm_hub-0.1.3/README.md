# LLM Hub - Unified LLM Calling Library

[![中文](https://img.shields.io/badge/跳转中文-README-blue.svg)](README_zh.md)

A unified calling library supporting multiple LLM providers, providing consistent API interfaces, command-line tools, and graphical interface.

## Project Structure

```
llm-hub/
│
├── 📄 Root configuration files
│   ├── LICENSE                          # GPL-3.0 license file
│   ├── requirements.txt                 # Python dependencies list
│   ├── setup.py                         # Project installation script
│   ├── pyproject.toml                   # Project configuration
│   ├── MANIFEST.in                      # Packaging manifest
│   ├── config.json                      # Default configuration example
│   ├── pytest.ini                       # pytest configuration
│   ├── Makefile                         # Build automation script
│   ├── Dockerfile                       # Docker containerization config
│   ├── .gitignore                       # Git ignore file
│   ├── run_ui.py                        # UI launcher script
│   └── README.md                        # Project documentation
│
├── 📁 llm_hub/                          # Core code directory
│   ├── __init__.py                      # Module initialization
│   ├── py.typed                         # Type marking file
│   │
│   ├── 📁 cli/                          # CLI module
│   │   ├── __init__.py
│   │   └── main.py                      # CLI main program
│   │
│   ├── 📁 core/                         # Core functionality
│   │   ├── __init__.py
│   │   ├── client.py                    # LLMClient main class
│   │   ├── config.py                    # Configuration management
│   │   ├── config_manager.py            # Config manager with profiles
│   │   └── enums.py                     # Enum definitions
│   │
│   ├── 📁 models/                       # Data models
│   │   ├── __init__.py
│   │   ├── message.py                   # Message and Conversation models
│   │   └── response.py                  # Response models
│   │
│   ├── 📁 providers/                    # LLM provider implementations
│   │   ├── __init__.py
│   │   ├── base.py                      # Base provider class
│   │   ├── openai_compatible.py         # OpenAI-compatible providers
│   │   ├── ollama.py                    # Ollama local provider
│   │   ├── llama_cpp.py                 # llama.cpp local provider
│   │   ├── deepseek.py                  # DeepSeek API provider
│   │   ├── kimi.py                      # Kimi API provider
│   │   ├── gemini.py                    # Google Gemini API provider
│   │   ├── anthropic.py                 # Anthropic Claude API provider
│   │   └── custom.py                    # Custom API provider
│   │
│   └── 📁 utils/                        # Utility functions
│       ├── __init__.py
│       ├── logger.py                    # Logging system
│       ├── token_counter.py             # Token counter
│       └── helpers.py                   # Helper functions
│
├── 📁 ui/                               # GUI module
│   ├── __init__.py
│   └── app.py                           # Main UI application
│
├── 📁 tests/                            # Test module
│   ├── __init__.py
│   ├── test_client.py
│   └── test_providers.py
│
└── 📁 examples/                         # Example code
    ├── basic_usage.py
    ├── streaming.py
    ├── multi_turn_chat.py
    ├── environment_aware.py
    └── json_config_usage.py
```

## Quick Start

### Installation

```bash
# Basic installation
pip install gracefox-llm-hub

# Install all dependencies (including UI)
pip install gracefox-llm-hub[all]

# Install UI only
pip install gracefox-llm-hub[ui]
```

### Use as Library

```python
from llm_hub import LLMClient, LLMConfig, Provider

# Create client
client = LLMClient(LLMConfig(
    provider=Provider.DEEPSEEK,
    model="deepseek-chat",
    api_key="your-api-key"
))

# Chat
response = client.chat("Hello")
print(response.content)

# Streaming output
for chunk in client.stream_chat("Tell a story"):
    print(chunk, end="")
```

### Command Line Usage

```bash
# Basic usage
llm-hub --provider deepseek --api-key YOUR_KEY "Hello"

# Use JSON config string
llm-hub --json '{"provider": "deepseek", "model": "deepseek-chat", "api_key": "xxx"}' "Hello"

# Use config file
llm-hub --config-file config.json "Hello"

# Use config profile
llm-hub --profile my-deepseek "Hello"

# Interactive mode
llm-hub --provider ollama --interactive

# Streaming output
llm-hub --provider openai --stream "Tell a story"
```

### Configuration File Formats

Support multiple configuration formats:

**Flat format:**
```json
{
    "provider": "deepseek",
    "model": "deepseek-chat",
    "api_key": "your-api-key",
    "temperature": 0.7,
    "max_tokens": 2000
}
```

**Nested format:**
```json
{
    "deepseek_config": {
        "provider": "deepseek",
        "model": "deepseek-chat",
        "api_key": "your-api-key"
    }
}
```

**Multi-profile format:**
```json
{
    "current": "deepseek",
    "profiles": {
        "deepseek": {
            "provider": "deepseek",
            "model": "deepseek-chat",
            "api_key": "sk-ds"
        },
        "openai": {
            "provider": "openai",
            "model": "gpt-4",
            "api_key": "sk-oa"
        }
    }
}
```

### GUI

```bash
# Launch UI
llm-hub-ui
# or
python run_ui.py
```

## Supported Providers

| Provider | Type | API Key Required | Config Parameters |
|----------|------|------------------|-------------------|
| OpenAI | Cloud | ✓ | `api_key` |
| DeepSeek | Cloud | ✓ | `api_key` |
| Kimi | Cloud | ✓ | `api_key` |
| Google Gemini | Cloud | ✓ | `api_key` |
| Anthropic Claude | Cloud | ✓ | `api_key` |
| Ollama | Local | ✗ | `ollama_url` |
| llama.cpp | Local | ✗ | `model_path` |
| Custom | Optional | Optional | `api_url` |

## Configuration Management

### Config Profiles

```bash
# Save config profile
llm-hub --provider deepseek --api-key xxx --save-profile my-ds

# List all profiles
llm-hub --list-profiles

# Use profile
llm-hub --profile my-ds "Hello"

# Delete profile
llm-hub --delete-profile my-ds
```

### Environment Variables

```bash
export LLM_PROVIDER=deepseek
export LLM_MODEL=deepseek-chat
export LLM_API_KEY=your-key
export LLM_TEMPERATURE=0.7

llm-hub "Hello"
```

### Configuration Priority

From low to high:
1. Default configuration
2. Environment variables
3. Config profile
4. Config file
5. JSON string
6. Command line arguments

## Development Commands

```bash
# Install development dependencies
make install-dev

# Run tests
make test

# Format code
make format

# Lint code
make lint

# Clean temporary files
make clean

# Build distribution package
make build

# Run CLI
make run-cli

# Run UI
make run-ui
```

## Extending Development

### Adding a New Provider

1. Add enum in `core/enums.py`:
```python
class Provider(Enum):
    NEW_PROVIDER = "new_provider"
```

2. Create `providers/new_provider.py`:
```python
from llm_hub.providers.base import BaseProvider

class NewProvider(BaseProvider):
    def chat(self, conversation, **kwargs):
        # Implement chat logic
        pass
```

3. Register in `providers/__init__.py`:
```python
from llm_hub.providers.new_provider import NewProvider

providers = {
    Provider.NEW_PROVIDER: NewProvider,
}
```

## License

GNU General Public License v3.0 - See [LICENSE](LICENSE) file for details

### GPL-3.0 Core Requirements

- **Freedom to Use**: Anyone can freely use this software
- **Source Code Availability**: Source code must be provided when distributing
- **Same License**: Modified versions must be released under the same GPL-3.0 license
- **Copyright Notice**: Original copyright and license notices must be retained

## Links

- Homepage: https://gitee.com/SteHub/llm-hub
- Issues: https://gitee.com/SteHub/llm-hub/issues
- Author Email: 948743980@qq.com
