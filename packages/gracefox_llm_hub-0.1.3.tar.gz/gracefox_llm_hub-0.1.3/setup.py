"""安装脚本"""

from setuptools import setup, find_packages
import os
import re

# 读取版本号（从 llm_hub/__init__.py）
def get_version():
    init_file = os.path.join(os.path.dirname(__file__), "llm_hub", "__init__.py")
    with open(init_file, "r", encoding="utf-8") as f:
        content = f.read()
        version_match = re.search(r"__version__\s*=\s*['\"]([^'\"]+)['\"]", content)
        if version_match:
            return version_match.group(1)
    return "0.1.2"

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="llm-hub",
    version=get_version(),
    author="LLM Hub Team",
    author_email="team@llm-hub.com",
    description="统一的LLM调用库，支持多种LLM提供商",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://gitee.com/SteHub/llm-hub",
    packages=find_packages(exclude=["tests", "tests.*", "examples", "examples.*"]),
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "License :: OSI Approved :: GNU General Public License v3 (GPLv3)",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.8",
    install_requires=[
        "requests>=2.31.0",
    ],
    extras_require={
        "ui": [
            "psutil>=5.9.0",
            "pygetwindow>=0.0.9",
        ],
        "config": [
            "pyyaml>=6.0",
        ],
        "windows": ["pywin32>=306"],
        "linux": ["python-xlib>=0.33"],
        "macos": ["pyobjc>=9.0"],
        "dev": [
            "pytest>=7.0.0",
            "pytest-cov>=4.0.0",
            "black>=23.0.0",
            "flake8>=6.0.0",
            "mypy>=1.0.0",
            "build>=0.10.0",
            "twine>=4.0.0",
        ],
        "all": [
            "psutil>=5.9.0",
            "pygetwindow>=0.0.9",
            "pyyaml>=6.0",
            "pytest>=7.0.0",
            "black>=23.0.0",
        ]
    },
    entry_points={
        "console_scripts": [
            "llm-hub=llm_hub.cli.main:main",
            "llm-hub-ui=llm_hub.ui.app:main",
        ],
    },
    package_data={
        "llm_hub": ["py.typed"],
    },
    include_package_data=True,
    zip_safe=False,
)