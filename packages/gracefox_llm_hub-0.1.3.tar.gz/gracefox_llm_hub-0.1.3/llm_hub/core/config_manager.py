"""配置管理器 - 多档案、优先级、环境变量"""

import json
import os
from pathlib import Path
from typing import Dict, Any, Optional, Union, List
from dataclasses import dataclass

from llm_hub.core.config import LLMConfig
from llm_hub.core.enums import Provider


@dataclass
class ConfigProfile:
    """配置档案"""
    name: str
    config: LLMConfig
    description: str = ""


class ConfigManager:
    """配置管理器"""
    
    def __init__(self, config_dir: Optional[str] = None):
        self.config_dir = Path(config_dir) if config_dir else Path.home() / ".llm-hub"
        self.config_dir.mkdir(parents=True, exist_ok=True)
        self.profiles: Dict[str, ConfigProfile] = {}
        self._load_profiles()
    
    def _get_profiles_file(self) -> Path:
        return self.config_dir / "profiles.json"
    
    def _load_profiles(self):
        """加载配置档案"""
        profiles_file = self._get_profiles_file()
        if profiles_file.exists():
            try:
                with open(profiles_file, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    for name, profile_data in data.items():
                        config = LLMConfig.from_dict(profile_data.get("config", {}))
                        self.profiles[name] = ConfigProfile(
                            name=name,
                            config=config,
                            description=profile_data.get("description", "")
                        )
            except Exception as e:
                print(f"Warning: Failed to load profiles: {e}")
    
    def _save_profiles(self):
        """保存配置档案（格式化输出）"""
        profiles_file = self._get_profiles_file()
        data = {}
        for name, profile in self.profiles.items():
            data[name] = {
                "config": profile.config.to_dict(),
                "description": profile.description
            }
        with open(profiles_file, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
    
    def add_profile(self, name: str, config: Union[LLMConfig, Dict, str], description: str = ""):
        """添加配置档案"""
        if isinstance(config, str):
            if os.path.exists(config):
                config = LLMConfig.from_file(config)
            else:
                config = LLMConfig.from_json(config)
        elif isinstance(config, dict):
            config = LLMConfig.from_dict(config)
        elif not isinstance(config, LLMConfig):
            raise TypeError(f"Unsupported config type: {type(config)}")
        
        self.profiles[name] = ConfigProfile(name=name, config=config, description=description)
        self._save_profiles()
    
    def get_profile(self, name: str) -> Optional[LLMConfig]:
        """获取配置档案"""
        profile = self.profiles.get(name)
        return profile.config if profile else None
    
    def list_profiles(self) -> List[Dict[str, str]]:
        """列出所有配置档案"""
        return [{"name": name, "description": p.description} for name, p in self.profiles.items()]
    
    def remove_profile(self, name: str) -> bool:
        """删除配置档案"""
        if name in self.profiles:
            del self.profiles[name]
            self._save_profiles()
            return True
        return False
    
    def export_profile(self, name: str, path: str, format: str = "json"):
        """导出配置档案"""
        profile = self.profiles.get(name)
        if not profile:
            raise ValueError(f"Profile not found: {name}")
        profile.config.save(path, format)
    
    def build_config(
        self,
        profile: Optional[str] = None,
        file_path: Optional[str] = None,
        json_str: Optional[str] = None,
        env: bool = True,
        **overrides
    ) -> LLMConfig:
        """构建配置（支持多级覆盖）
        
        优先级（从低到高）：
        1. 默认配置
        2. 环境变量（可选）
        3. 配置档案
        4. 配置文件
        5. JSON字符串
        6. 直接参数覆盖
        
        支持的配置格式：
        - 扁平格式: {"provider": "deepseek", "model": "..."}
        - 嵌套格式: {"deepseek_config": {"provider": "deepseek", ...}}
        - 多配置格式: {"current": "deepseek", "profiles": {...}}
        """
        # 默认配置
        config = LLMConfig()
        
        # 环境变量
        if env:
            env_config = self._config_from_env()
            config = self._merge_configs(config, env_config)
        
        # 配置档案
        if profile:
            profile_config = self.get_profile(profile)
            if not profile_config:
                raise ValueError(f"Profile not found: {profile}")
            config = self._merge_configs(config, profile_config)
        
        # 配置文件（支持嵌套和多配置）
        if file_path:
            file_config = LLMConfig.from_file(file_path)
            config = self._merge_configs(config, file_config)
        
        # JSON字符串（支持嵌套和多配置）
        if json_str:
            json_config = LLMConfig.from_json(json_str)
            config = self._merge_configs(config, json_config)
        
        # 直接覆盖（支持嵌套）
        if overrides:
            # 处理嵌套配置：如果只有一个顶层键且值为字典
            if len(overrides) == 1:
                key, value = next(iter(overrides.items()))
                if isinstance(value, dict) and ('config' in key.lower() or key.endswith('_config')):
                    overrides = value
            
            if "provider" in overrides and isinstance(overrides["provider"], str):
                overrides["provider"] = Provider.from_string(overrides["provider"])
            
            # 过滤有效参数
            valid_params = [
                "provider", "model", "api_key", "api_base",
                "temperature", "max_tokens", "top_p",
                "frequency_penalty", "presence_penalty",
                "timeout", "max_retries", "model_path",
                "ollama_url", "debug", "stream"
            ]
            filtered_overrides = {k: v for k, v in overrides.items() if k in valid_params}
            
            if filtered_overrides:
                override_config = LLMConfig(**filtered_overrides)
                config = self._merge_configs(config, override_config)
        
        return config
    
    def _merge_configs(self, base: LLMConfig, override: LLMConfig) -> LLMConfig:
        """合并两个配置"""
        merged_dict = base.to_dict()
        for key, value in override.to_dict().items():
            if value is not None and value != "":
                merged_dict[key] = value
        return LLMConfig.from_dict(merged_dict)
    
    def _config_from_env(self) -> LLMConfig:
        """从环境变量创建配置"""
        config_dict = {}
        
        env_mappings = {
            "LLM_PROVIDER": "provider",
            "LLM_MODEL": "model",
            "LLM_API_KEY": "api_key",
            "LLM_API_BASE": "api_base",
            "LLM_TEMPERATURE": "temperature",
            "LLM_MAX_TOKENS": "max_tokens",
            "LLM_TIMEOUT": "timeout",
            "LLM_OLLAMA_URL": "ollama_url",
        }
        
        for env_var, config_key in env_mappings.items():
            value = os.environ.get(env_var)
            if value is not None:
                if config_key == "temperature":
                    try:
                        value = float(value)
                    except ValueError:
                        pass
                elif config_key in ["max_tokens", "timeout"]:
                    try:
                        value = int(value)
                    except ValueError:
                        pass
                config_dict[config_key] = value
        
        return LLMConfig.from_dict(config_dict) if config_dict else LLMConfig()
    
    def to_json_schema(self) -> Dict:
        """生成配置的JSON Schema"""
        return {
            "$schema": "http://json-schema.org/draft-07/schema#",
            "type": "object",
            "properties": {
                "provider": {"type": "string", "enum": [p.value for p in Provider]},
                "model": {"type": "string"},
                "api_key": {"type": "string"},
                "api_base": {"type": "string"},
                "temperature": {"type": "number", "minimum": 0, "maximum": 2, "default": 0.7},
                "max_tokens": {"type": "integer", "minimum": 1, "maximum": 32000, "default": 2000},
                "top_p": {"type": "number", "minimum": 0, "maximum": 1, "default": 0.95},
                "timeout": {"type": "integer", "minimum": 1, "default": 60},
                "max_retries": {"type": "integer", "minimum": 0, "default": 3},
                "model_path": {"type": "string"},
                "ollama_url": {"type": "string", "format": "uri", "default": "http://localhost:11434"},
                "debug": {"type": "boolean", "default": False},
                "stream": {"type": "boolean", "default": False}
            }
        }


# 全局实例
_default_manager: Optional[ConfigManager] = None


def get_config_manager(config_dir: Optional[str] = None) -> ConfigManager:
    """获取全局配置管理器"""
    global _default_manager
    if _default_manager is None:
        _default_manager = ConfigManager(config_dir)
    return _default_manager


# ========== 便捷函数 ==========

def merge_configs(base: LLMConfig, override: Union[Dict, str, LLMConfig]) -> LLMConfig:
    """合并配置"""
    if isinstance(override, str):
        try:
            override_dict = json.loads(override)
            override_config = LLMConfig.from_dict(override_dict)
        except json.JSONDecodeError:
            if os.path.exists(override):
                override_config = LLMConfig.from_file(override)
            else:
                raise ValueError(f"Invalid JSON string or file path: {override}")
    elif isinstance(override, dict):
        override_config = LLMConfig.from_dict(override)
    elif isinstance(override, LLMConfig):
        override_config = override
    else:
        raise TypeError(f"Unsupported override type: {type(override)}")
    
    merged_dict = base.to_dict()
    for key, value in override_config.to_dict().items():
        if value is not None and value != "":
            merged_dict[key] = value
    
    return LLMConfig.from_dict(merged_dict)