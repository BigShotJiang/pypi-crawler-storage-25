"""配置管理 - 基础配置类"""

from dataclasses import dataclass
from typing import Optional, Dict, Any, Union
import json
import os
from pathlib import Path

from llm_hub.core.enums import Provider


@dataclass
class LLMConfig:
    """LLM配置 - 核心数据结构"""
    # 基本配置
    provider: Provider = Provider.OPENAI
    model: str = "gpt-3.5-turbo"
    api_key: Optional[str] = None
    api_base: Optional[str] = None
    
    # 生成参数
    temperature: float = 0.7
    max_tokens: int = 2000
    top_p: float = 0.95
    frequency_penalty: float = 0.0
    presence_penalty: float = 0.0
    
    # 超时和重试
    timeout: int = 60
    max_retries: int = 3
    
    # 本地模型配置
    model_path: Optional[str] = None
    ollama_url: str = "http://localhost:11434"
    
    # 其他
    debug: bool = False
    stream: bool = False
    
    def get_api_url(self) -> str:
        """获取API URL"""
        if self.api_base:
            return self.api_base
        
        urls = {
            Provider.OPENAI: "https://api.openai.com/v1",
            Provider.DEEPSEEK: "https://api.deepseek.com/v1",
            Provider.KIMI: "https://api.moonshot.cn/v1",
            Provider.KIMI_INTL: "https://api.moonshot.cc/v1",
            Provider.ALIYUN_BAILIAN: "https://dashscope.aliyuncs.com/compatible-mode/v1",
            Provider.OPENROUTER: "https://openrouter.ai/api/v1",
            Provider.GOOGLE_GEMINI: "https://generativelanguage.googleapis.com/v1",
            Provider.ANTHROPIC: "https://api.anthropic.com/v1",
        }
        return urls.get(self.provider, "")
    
    def to_dict(self) -> Dict:
        """转换为字典"""
        return {
            "provider": self.provider.value,
            "model": self.model,
            "api_key": self.api_key,
            "api_base": self.api_base,
            "temperature": self.temperature,
            "max_tokens": self.max_tokens,
            "top_p": self.top_p,
            "frequency_penalty": self.frequency_penalty,
            "presence_penalty": self.presence_penalty,
            "timeout": self.timeout,
            "max_retries": self.max_retries,
            "model_path": self.model_path,
            "ollama_url": self.ollama_url,
            "debug": self.debug,
            "stream": self.stream
        }
    
    def to_json(self, indent: int = 2) -> str:
        """转换为JSON字符串"""
        return json.dumps(self.to_dict(), ensure_ascii=False, indent=indent)
    
    @classmethod
    def from_dict(cls, data: Dict, strict: bool = False) -> "LLMConfig":
        """从字典创建配置（支持嵌套结构）
        
        Args:
            data: 配置字典，支持以下格式：
                1. 扁平格式: {"provider": "deepseek", "model": "..."}
                2. 嵌套格式: {"deepseek_config": {"provider": "deepseek", ...}}
                3. 多配置格式: {"current": "deepseek", "profiles": {...}}
            strict: 是否严格模式（遇到未知字段是否报错）
        
        Returns:
            LLMConfig实例
        """
        data = data.copy()
        
        # 处理嵌套配置
        data = cls._unwrap_nested_config(data)
        
        # 处理多配置格式
        if "current" in data and "profiles" in data:
            current = data.get("current")
            profiles = data.get("profiles", {})
            if current in profiles:
                data = profiles[current]
            else:
                # 如果找不到当前配置，尝试使用第一个
                first_key = next(iter(profiles.keys())) if profiles else None
                if first_key:
                    data = profiles[first_key]
        
        # 处理 provider 字符串转换
        if "provider" in data and isinstance(data["provider"], str):
            data["provider"] = Provider.from_string(data["provider"])
        
        # 过滤有效参数
        if not strict:
            import inspect
            valid_params = inspect.signature(cls).parameters.keys()
            data = {k: v for k, v in data.items() if k in valid_params}
        
        return cls(**data)
    
    @classmethod
    def _unwrap_nested_config(cls, data: Dict) -> Dict:
        """展开嵌套配置
        
        支持格式：
        - {"deepseek_config": {...}} -> {...}
        - {"config": {...}} -> {...}
        - {"llm_config": {...}} -> {...}
        """
        # 如果只有一个顶层键，且值为字典，且键名包含 'config'
        if len(data) == 1:
            key, value = next(iter(data.items()))
            if isinstance(value, dict) and ('config' in key.lower() or key.endswith('_config')):
                return value
        return data
    
    @classmethod
    def from_json(cls, json_str: str, strict: bool = False) -> "LLMConfig":
        """从JSON字符串创建配置
        
        Args:
            json_str: JSON格式的配置字符串
            strict: 是否严格模式
        
        Returns:
            LLMConfig实例
        """
        try:
            data = json.loads(json_str)
            return cls.from_dict(data, strict=strict)
        except json.JSONDecodeError as e:
            raise ValueError(f"Invalid JSON string: {e}")
    
    @classmethod
    def from_file(cls, path: str, strict: bool = False) -> "LLMConfig":
        """从文件加载配置（支持JSON和YAML，支持嵌套结构）
        
        Args:
            path: 配置文件路径
            strict: 是否严格模式
        
        Returns:
            LLMConfig实例
        """
        path = Path(path)
        
        if not path.exists():
            raise FileNotFoundError(f"Config file not found: {path}")
        
        with open(path, 'r', encoding='utf-8') as f:
            if path.suffix.lower() in ['.yaml', '.yml']:
                try:
                    import yaml
                    data = yaml.safe_load(f)
                except ImportError:
                    raise ImportError("PyYAML required for YAML support")
            else:
                data = json.load(f)
        
        return cls.from_dict(data, strict=strict)
    
    def save(self, path: str, format: str = "json"):
        """保存配置到文件"""
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        
        if format == "yaml" or path.suffix.lower() in ['.yaml', '.yml']:
            try:
                import yaml
                with open(path, 'w', encoding='utf-8') as f:
                    yaml.dump(self.to_dict(), f, allow_unicode=True, indent=2)
            except ImportError:
                raise ImportError("PyYAML required for YAML support")
        else:
            with open(path, 'w', encoding='utf-8') as f:
                json.dump(self.to_dict(), f, ensure_ascii=False, indent=2)
    
    @classmethod
    def load(cls, path: str) -> "LLMConfig":
        """从文件加载配置（兼容旧接口）"""
        return cls.from_file(path)
    
    def update(self, **kwargs):
        """更新配置"""
        for key, value in kwargs.items():
            if hasattr(self, key):
                if key == "provider" and isinstance(value, str):
                    value = Provider.from_string(value)
                setattr(self, key, value)
    
    def validate(self) -> tuple[bool, Optional[str]]:
        """验证配置"""
        if not self.provider:
            return False, "provider is required"
        if not self.model:
            return False, "model is required"
        if self.provider.is_cloud() and not self.api_key:
            return False, f"api_key required for {self.provider.value}"
        if self.provider == Provider.LLAMA_CPP and not self.model_path:
            return False, "model_path required for llama.cpp"
        if not 0 <= self.temperature <= 2:
            return False, f"temperature must be 0-2"
        if self.max_tokens < 1:
            return False, f"max_tokens must be >= 1"
        return True, None
    
    def __repr__(self) -> str:
        dict_repr = self.to_dict()
        if dict_repr.get("api_key"):
            dict_repr["api_key"] = "***HIDDEN***"
        return f"LLMConfig({dict_repr})"


def merge_configs(base: LLMConfig, override: Union[Dict, str, LLMConfig]) -> LLMConfig:
    """合并配置（便捷函数）"""
    from llm_hub.core.config_manager import ConfigManager
    manager = ConfigManager()
    return manager.build_config(**{
        "profile": None,
        "file_path": None,
        "json_str": override if isinstance(override, str) else None,
        "env": False,
        **({"json_str": override} if isinstance(override, str) else {}),
        **({"file_path": override} if isinstance(override, str) and override.endswith(('.json', '.yaml', '.yml')) else {}),
        **({"profile": override} if isinstance(override, str) and not override.endswith(('.json', '.yaml', '.yml')) else {})
    })