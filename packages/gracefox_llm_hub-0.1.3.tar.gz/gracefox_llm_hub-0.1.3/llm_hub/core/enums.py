"""枚举定义"""

from enum import Enum


class Provider(Enum):
    """LLM提供商"""
    # 云端API
    DEEPSEEK = "deepseek"
    OPENAI = "openai"
    KIMI = "kimi"
    KIMI_INTL = "kimi_intl"
    ALIYUN_BAILIAN = "aliyun_bailian"
    GOOGLE_GEMINI = "gemini"
    OPENROUTER = "openrouter"
    ANTHROPIC = "anthropic"
    
    # 本地部署
    OLLAMA = "ollama"
    LLAMA_CPP = "llama_cpp"
    LOCAL = "local"
    
    # 自定义
    CUSTOM = "custom"
    
    @classmethod
    def from_string(cls, value: str):
        for member in cls:
            if member.value == value:
                return member
        return cls.CUSTOM
    
    def is_local(self) -> bool:
        """是否为本地部署"""
        return self in [self.OLLAMA, self.LLAMA_CPP, self.LOCAL]
    
    def is_cloud(self) -> bool:
        """是否为云端API"""
        return not self.is_local() and self != self.CUSTOM


class ModelType(Enum):
    """模型类型"""
    CHAT = "chat"           # 对话模型
    COMPLETION = "completion"  # 补全模型
    EMBEDDING = "embedding"    # 嵌入模型
    VISION = "vision"          # 视觉模型


class ResponseFormat(Enum):
    """响应格式"""
    TEXT = "text"
    JSON = "json"
    STREAM = "stream"