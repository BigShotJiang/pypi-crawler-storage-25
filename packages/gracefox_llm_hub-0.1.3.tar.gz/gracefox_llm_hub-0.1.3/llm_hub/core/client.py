"""LLM客户端"""

from typing import Optional, Dict, Any, Union, List
import os
from typing import Optional, Dict, Any, Union, List, Generator
from llm_hub.core.config import LLMConfig
from llm_hub.core.enums import Provider
from llm_hub.providers import create_provider
from llm_hub.models.message import Conversation, Message
from llm_hub.models.response import Response, StreamResponse


class LLMClient:
    """统一的LLM客户端"""
    
    def __init__(self, config: Optional[LLMConfig] = None):
        self.config = config or LLMConfig()
        self._provider = None
        self._init_provider()
    
    def _init_provider(self):
        """初始化提供商"""
        self._provider = create_provider(
            self.config.provider,
            self.config.to_dict()
        )
    
    def update_config(self, **kwargs):
        """更新配置"""
        for key, value in kwargs.items():
            if hasattr(self.config, key):
                setattr(self.config, key, value)
        self._init_provider()
    
    def chat(
        self,
        messages: Union[List[Dict], Conversation, str],
        **kwargs
    ) -> Union[Response, StreamResponse]:
        """
        对话接口
        
        Args:
            messages: 消息列表、对话对象或字符串
            **kwargs: 覆盖配置的参数
        
        Returns:
            Response 或 StreamResponse
        """
        # 处理不同类型的输入
        if isinstance(messages, str):
            conv = Conversation()
            conv.add_user(messages)
        elif isinstance(messages, list):
            conv = Conversation()
            for msg in messages:
                if isinstance(msg, dict):
                    conv.add(Message(**msg))
                elif isinstance(msg, Message):
                    conv.add(msg)
        elif isinstance(messages, Conversation):
            conv = messages
        else:
            raise ValueError(f"Unsupported messages type: {type(messages)}")
        
        # 合并参数
        params = {
            "temperature": self.config.temperature,
            "max_tokens": self.config.max_tokens,
            "top_p": self.config.top_p,
            "frequency_penalty": self.config.frequency_penalty,
            "presence_penalty": self.config.presence_penalty,
            "stream": self.config.stream,
            **kwargs
        }
        
        return self._provider.chat(conv, **params)
    
    def complete(self, prompt: str, **kwargs) -> Union[Response, StreamResponse]:
        """
        文本补全接口
        
        Args:
            prompt: 提示词
            **kwargs: 覆盖配置的参数
        
        Returns:
            Response 或 StreamResponse
        """
        params = {
            "temperature": self.config.temperature,
            "max_tokens": self.config.max_tokens,
            "top_p": self.config.top_p,
            "stream": self.config.stream,
            **kwargs
        }
        return self._provider.complete(prompt, **params)
    
    def stream_chat(self, messages: Union[List[Dict], Conversation, str], **kwargs) -> Generator:
        """流式对话"""
        kwargs["stream"] = True
        response = self.chat(messages, **kwargs)
        if isinstance(response, StreamResponse):
            yield from response
        else:
            yield response.content
    
    def health_check(self) -> bool:
        """健康检查"""
        return self._provider.health_check()
    
    @classmethod
    def from_config_file(cls, path: str) -> "LLMClient":
        """从配置文件创建客户端"""
        config = LLMConfig.load(path)
        return cls(config)
    
    def save_config(self, path: str):
        """保存配置"""
        self.config.save(path)