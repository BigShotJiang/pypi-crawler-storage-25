"""UI应用 - 可选的可视化界面"""

import sys
import os

# 添加项目根目录到路径
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import tkinter as tk
from tkinter import ttk, scrolledtext, messagebox
import threading
from datetime import datetime

from llm_hub import LLMClient, LLMConfig, Provider
from llm_hub.models.message import Conversation


class LLMHubUI:
    """LLM Hub 图形界面"""
    
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("LLM Hub - 统一LLM调用工具")
        self.root.geometry("1000x700")
        
        self.client = None
        self.conversation = Conversation()
        
        self._create_menu()
        self._create_ui()
        self._load_default_config()
    
    def _create_menu(self):
        """创建菜单"""
        menubar = tk.Menu(self.root)
        
        # 文件菜单
        file_menu = tk.Menu(menubar, tearoff=0)
        file_menu.add_command(label="加载配置", command=self.load_config)
        file_menu.add_command(label="保存配置", command=self.save_config)
        file_menu.add_separator()
        file_menu.add_command(label="退出", command=self.root.quit)
        menubar.add_cascade(label="文件", menu=file_menu)
        
        # 模型菜单
        model_menu = tk.Menu(menubar, tearoff=0)
        model_menu.add_command(label="OpenAI", command=lambda: self.switch_provider(Provider.OPENAI))
        model_menu.add_command(label="DeepSeek", command=lambda: self.switch_provider(Provider.DEEPSEEK))
        model_menu.add_command(label="Kimi", command=lambda: self.switch_provider(Provider.KIMI))
        model_menu.add_command(label="Ollama", command=lambda: self.switch_provider(Provider.OLLAMA))
        model_menu.add_command(label="llama.cpp", command=lambda: self.switch_provider(Provider.LLAMA_CPP))
        model_menu.add_separator()
        model_menu.add_command(label="设置", command=self.open_settings)
        menubar.add_cascade(label="模型", menu=model_menu)
        
        # 帮助菜单
        help_menu = tk.Menu(menubar, tearoff=0)
        help_menu.add_command(label="使用说明", command=self.show_help)
        help_menu.add_command(label="关于", command=self.show_about)
        menubar.add_cascade(label="帮助", menu=help_menu)
        
        self.root.config(menu=menubar)
    
    def _create_ui(self):
        """创建UI"""
        # 主框架
        main_frame = ttk.Frame(self.root)
        main_frame.pack(fill='both', expand=True, padx=10, pady=10)
        
        # 状态栏
        self.status_bar = ttk.Label(self.root, text="就绪", relief=tk.SUNKEN)
        self.status_bar.pack(side=tk.BOTTOM, fill=tk.X)
        
        # 左侧控制面板
        left_frame = ttk.Frame(main_frame, width=250)
        left_frame.pack(side=tk.LEFT, fill=tk.Y, padx=(0, 10))
        left_frame.pack_propagate(False)
        
        # 右侧对话区域
        right_frame = ttk.Frame(main_frame)
        right_frame.pack(side=tk.RIGHT, fill='both', expand=True)
        
        self._create_control_panel(left_frame)
        self._create_chat_area(right_frame)
    
    def _create_control_panel(self, parent):
        """创建控制面板"""
        # 提供商选择
        provider_frame = ttk.LabelFrame(parent, text="提供商", padding=10)
        provider_frame.pack(fill='x', pady=(0, 10))
        
        self.provider_var = tk.StringVar()
        providers = [p.value for p in Provider]
        provider_combo = ttk.Combobox(provider_frame, textvariable=self.provider_var, values=providers)
        provider_combo.pack(fill='x')
        provider_combo.bind('<<ComboboxSelected>>', self.on_provider_change)
        
        # 模型设置
        model_frame = ttk.LabelFrame(parent, text="模型设置", padding=10)
        model_frame.pack(fill='x', pady=(0, 10))
        
        ttk.Label(model_frame, text="模型名称:").pack(anchor='w')
        self.model_entry = ttk.Entry(model_frame)
        self.model_entry.pack(fill='x', pady=(0, 10))
        
        ttk.Label(model_frame, text="API地址:").pack(anchor='w')
        self.api_url_entry = ttk.Entry(model_frame)
        self.api_url_entry.pack(fill='x', pady=(0, 10))
        
        ttk.Label(model_frame, text="API密钥:").pack(anchor='w')
        self.api_key_entry = ttk.Entry(model_frame, show="*")
        self.api_key_entry.pack(fill='x')
        
        # 本地模型路径
        ttk.Label(model_frame, text="模型路径(本地):").pack(anchor='w')
        self.model_path_entry = ttk.Entry(model_frame)
        self.model_path_entry.pack(fill='x')
        
        # 生成参数
        params_frame = ttk.LabelFrame(parent, text="生成参数", padding=10)
        params_frame.pack(fill='x', pady=(0, 10))
        
        ttk.Label(params_frame, text="温度:").pack(anchor='w')
        self.temperature_var = tk.DoubleVar(value=0.7)
        ttk.Scale(params_frame, from_=0.0, to=2.0, variable=self.temperature_var, orient='horizontal').pack(fill='x')
        self.temperature_label = ttk.Label(params_frame, text="0.7")
        self.temperature_label.pack(anchor='w')
        
        ttk.Label(params_frame, text="最大Token:").pack(anchor='w')
        self.max_tokens_var = tk.IntVar(value=2000)
        ttk.Spinbox(params_frame, from_=100, to=32000, textvariable=self.max_tokens_var).pack(fill='x')
        
        # 按钮
        ttk.Button(parent, text="连接", command=self.connect).pack(fill='x', pady=5)
        ttk.Button(parent, text="清空对话", command=self.clear_chat).pack(fill='x', pady=5)
        
        # 跟踪变量变化
        self.temperature_var.trace('w', self.update_temperature_label)
    
    def _create_chat_area(self, parent):
        """创建对话区域"""
        # 对话显示
        self.chat_display = scrolledtext.ScrolledText(parent, wrap=tk.WORD, font=("微软雅黑", 10))
        self.chat_display.pack(fill='both', expand=True)
        
        # 配置标签样式
        self.chat_display.tag_config("user", foreground="blue", font=("微软雅黑", 10, "bold"))
        self.chat_display.tag_config("assistant", foreground="green", font=("微软雅黑", 10, "bold"))
        self.chat_display.tag_config("system", foreground="gray", font=("微软雅黑", 9, "italic"))
        
        # 输入区域
        input_frame = ttk.Frame(parent)
        input_frame.pack(fill='x', pady=(10, 0))
        
        self.input_entry = ttk.Entry(input_frame)
        self.input_entry.pack(side='left', fill='x', expand=True, padx=(0, 5))
        self.input_entry.bind('<Return>', self.send_message)
        
        self.send_button = ttk.Button(input_frame, text="发送", command=self.send_message)
        self.send_button.pack(side='right')
    
    def _load_default_config(self):
        """加载默认配置"""
        config_path = "config.json"
        if os.path.exists(config_path):
            import json
            with open(config_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
                self.provider_var.set(data.get("provider", "openai"))
                self.model_entry.insert(0, data.get("model", "gpt-3.5-turbo"))
                self.api_url_entry.insert(0, data.get("api_base", ""))
                self.api_key_entry.insert(0, data.get("api_key", ""))
                self.temperature_var.set(data.get("temperature", 0.7))
                self.max_tokens_var.set(data.get("max_tokens", 2000))
    
    def update_temperature_label(self, *args):
        """更新温度标签"""
        self.temperature_label.config(text=f"{self.temperature_var.get():.2f}")
    
    def on_provider_change(self, event):
        """提供商改变时的处理"""
        provider = self.provider_var.get()
        defaults = {
            "openai": "https://api.openai.com/v1",
            "deepseek": "https://api.deepseek.com/v1",
            "kimi": "https://api.moonshot.cn/v1",
        }
        if provider in defaults:
            self.api_url_entry.delete(0, tk.END)
            self.api_url_entry.insert(0, defaults[provider])
    
    def connect(self):
        """连接LLM服务"""
        try:
            config = LLMConfig(
                provider=Provider.from_string(self.provider_var.get()),
                model=self.model_entry.get(),
                api_base=self.api_url_entry.get() or None,
                api_key=self.api_key_entry.get() or None,
                model_path=self.model_path_entry.get() or None,
                temperature=self.temperature_var.get(),
                max_tokens=self.max_tokens_var.get()
            )
            self.client = LLMClient(config)
            self.status_bar.config(text=f"已连接: {config.provider.value}/{config.model}")
            self._add_message("system", f"已连接到 {config.provider.value}/{config.model}")
        except Exception as e:
            messagebox.showerror("错误", f"连接失败: {e}")
            self.status_bar.config(text="连接失败")
    
    def send_message(self, event=None):
        """发送消息"""
        if not self.client:
            messagebox.showwarning("警告", "请先连接LLM服务")
            return
        
        message = self.input_entry.get().strip()
        if not message:
            return
        
        self._add_message("user", message)
        self.input_entry.delete(0, tk.END)
        
        self.send_button.config(state='disabled')
        
        def do_request():
            try:
                self.conversation.add_user(message)
                response = self.client.chat(self.conversation)
                self._add_message("assistant", response.content)
                self.conversation.add_assistant(response.content)
            except Exception as e:
                self._add_message("system", f"错误: {e}")
            finally:
                self.send_button.config(state='normal')
        
        threading.Thread(target=do_request, daemon=True).start()
    
    def _add_message(self, role: str, content: str):
        """添加消息"""
        self.chat_display.insert(tk.END, f"\n{role}: ", role)
        self.chat_display.insert(tk.END, f"{content}\n")
        self.chat_display.see(tk.END)
    
    def clear_chat(self):
        """清空对话"""
        self.conversation.clear()
        self.chat_display.delete(1.0, tk.END)
        self._add_message("system", "对话已清空")
    
    def load_config(self):
        """加载配置"""
        from tkinter import filedialog
        filename = filedialog.askopenfilename(filetypes=[("JSON files", "*.json")])
        if filename:
            config = LLMConfig.load(filename)
            self.provider_var.set(config.provider.value)
            self.model_entry.delete(0, tk.END)
            self.model_entry.insert(0, config.model)
            self.api_url_entry.delete(0, tk.END)
            if config.api_base:
                self.api_url_entry.insert(0, config.api_base)
            self.api_key_entry.delete(0, tk.END)
            if config.api_key:
                self.api_key_entry.insert(0, config.api_key)
            self.temperature_var.set(config.temperature)
            self.max_tokens_var.set(config.max_tokens)
            self.connect()
    
    def save_config(self):
        """保存配置"""
        from tkinter import filedialog
        filename = filedialog.asksaveasfilename(defaultextension=".json", filetypes=[("JSON files", "*.json")])
        if filename and self.client:
            self.client.save_config(filename)
            messagebox.showinfo("成功", f"配置已保存到 {filename}")
    
    def switch_provider(self, provider: Provider):
        """切换提供商"""
        self.provider_var.set(provider.value)
        self.on_provider_change(None)
        self.connect()
    
    def open_settings(self):
        """打开设置窗口"""
        messagebox.showinfo("设置", "高级设置功能开发中...")
    
    def show_help(self):
        """显示帮助"""
        help_text = """LLM Hub 使用说明

1. 选择提供商（OpenAI、DeepSeek、Kimi、Ollama等）
2. 输入模型名称和API密钥
3. 点击"连接"按钮
4. 在下方输入框输入消息开始对话

支持流式输出和对话历史管理

快捷键:
- Enter: 发送消息"""
        
        messagebox.showinfo("使用说明", help_text)
    
    def show_about(self):
        """显示关于"""
        from llm_hub import __version__
        about_text = f"""LLM Hub v{__version__}

统一的LLM调用工具
支持多种LLM提供商

许可证: GPL-3.0"""
        
        messagebox.showinfo("关于", about_text)
    
    def run(self):
        """运行UI"""
        self.root.mainloop()


def main():
    """启动UI"""
    app = LLMHubUI()
    app.run()


if __name__ == "__main__":
    main()