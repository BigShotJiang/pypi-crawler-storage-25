"""命令行接口模块"""

from llm_hub.cli.main import main

__all__ = ["main"]