"""命令行接口 - 支持JSON配置"""

import argparse
import sys
import json
from llm_hub import __version__
from llm_hub import LLMClient, LLMConfig, Provider, merge_configs, get_config_manager
from llm_hub.models.message import Conversation


def interactive_mode(client: LLMClient):
    """交互模式"""
    print("LLM Hub 交互模式 (输入 'exit' 或 'quit' 退出, 'clear' 清空对话)")
    print("-" * 50)
    
    conversation = Conversation()
    
    while True:
        try:
            user_input = input("\n你: ").strip()
            
            if user_input.lower() in ['exit', 'quit']:
                print("再见！")
                break
            elif user_input.lower() == 'clear':
                conversation.clear()
                print("对话已清空")
                continue
            elif user_input.lower().startswith('config '):
                # 动态修改配置
                _, json_part = user_input.split(' ', 1)
                try:
                    new_config_dict = json.loads(json_part)
                    client.update_config(**new_config_dict)
                    print(f"配置已更新: {new_config_dict}")
                except json.JSONDecodeError:
                    print("无效的JSON格式")
                continue
            elif not user_input:
                continue
            
            print("助手: ", end="", flush=True)
            
            conversation.add_user(user_input)
            
            if client.config.stream:
                full_response = ""
                for chunk in client.stream_chat(conversation):
                    print(chunk, end="", flush=True)
                    full_response += chunk
                print()
                conversation.add_assistant(full_response)
            else:
                response = client.chat(conversation)
                print(response.content)
                conversation.add_assistant(response.content)
                
        except KeyboardInterrupt:
            print("\n\n再见！")
            break
        except Exception as e:
            print(f"\n错误: {e}")


def main():
    parser = argparse.ArgumentParser(
        description="LLM Hub - 统一的LLM命令行工具",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例:
  # 基本使用
  llm-hub --provider deepseek --api-key YOUR_KEY "你好"
  
  # 使用JSON配置字符串
  llm-hub --json '{"provider": "deepseek", "model": "deepseek-chat", "api_key": "xxx"}' "你好"
  
  # 使用JSON配置文件
  llm-hub --config-file config.json "你好"
  
  # 使用配置档案
  llm-hub --profile my-deepseek "你好"
  
  # 列出所有配置档案
  llm-hub --list-profiles
  
  # 保存当前配置为档案
  llm-hub --provider deepseek --api-key xxx --save-profile my-profile
  
  # 交互模式
  llm-hub --interactive
"""
    )
    
    # 版本参数
    parser.add_argument("--version", "-V", action="store_true", help="显示版本信息")
    
    # 配置源（优先级：JSON字符串 > 配置文件 > 配置档案 > 环境变量 > 命令行参数）
    parser.add_argument("--json", "-j", type=str, metavar="JSON_STR",
                        help="JSON配置字符串 (最高优先级)")
    parser.add_argument("--config-file", "-c", type=str, metavar="FILE",
                        help="JSON配置文件路径")
    parser.add_argument("--profile", "-P", type=str, metavar="NAME",
                        help="使用已保存的配置档案")
    parser.add_argument("--no-env", action="store_true",
                        help="忽略环境变量")
    
    # 配置档案管理
    parser.add_argument("--list-profiles", action="store_true",
                        help="列出所有配置档案")
    parser.add_argument("--save-profile", type=str, metavar="NAME",
                        help="将当前配置保存为档案")
    parser.add_argument("--delete-profile", type=str, metavar="NAME",
                        help="删除配置档案")
    parser.add_argument("--profile-desc", type=str, default="",
                        help="配置档案描述")
    
    # 基本参数（可被JSON覆盖）
    parser.add_argument("--provider", "-p", type=str,
                        help="LLM提供商 (openai, deepseek, kimi, ollama, etc.)")
    parser.add_argument("--model", "-m", type=str, help="模型名称")
    parser.add_argument("--api-key", "-k", type=str, help="API密钥")
    parser.add_argument("--api-base", type=str, help="API基础URL")
    
    # 生成参数
    parser.add_argument("--temperature", "-t", type=float, help="温度参数")
    parser.add_argument("--max-tokens", "-n", type=int, help="最大token数")
    parser.add_argument("--stream", "-s", action="store_true", help="流式输出")
    
    # 模式
    parser.add_argument("--chat", action="store_true", help="对话模式")
    parser.add_argument("--complete", action="store_true", help="补全模式")
    parser.add_argument("--interactive", "-i", action="store_true", help="交互模式")
    
    # 其他
    parser.add_argument("--list-models", action="store_true", help="列出可用模型")
    parser.add_argument("--health", action="store_true", help="健康检查")
    parser.add_argument("--show-config", action="store_true", help="显示当前配置")
    parser.add_argument("prompt", nargs="?", help="提示词或初始消息")
    
    args = parser.parse_args()
    
    # 显示版本
    if args.version:
        print(f"LLM Hub version {__version__}")
        return
    
    # 配置管理器
    manager = get_config_manager()
    
    # 列出配置档案
    if args.list_profiles:
        profiles = manager.list_profiles()
        if profiles:
            print("已保存的配置档案:")
            for p in profiles:
                print(f"  {p['name']}: {p['description']}")
        else:
            print("暂无配置档案")
        return
    
    # 删除配置档案
    if args.delete_profile:
        if manager.remove_profile(args.delete_profile):
            print(f"已删除配置档案: {args.delete_profile}")
        else:
            print(f"配置档案不存在: {args.delete_profile}")
        return
    
    # 构建配置（从各种源）
    try:
        # 收集命令行覆盖参数
        overrides = {}
        if args.provider:
            overrides["provider"] = args.provider
        if args.model:
            overrides["model"] = args.model
        if args.api_key:
            overrides["api_key"] = args.api_key
        if args.api_base:
            overrides["api_base"] = args.api_base
        if args.temperature is not None:
            overrides["temperature"] = args.temperature
        if args.max_tokens is not None:
            overrides["max_tokens"] = args.max_tokens
        if args.stream:
            overrides["stream"] = args.stream
        
        # 使用配置管理器构建配置
        config = manager.build_config(
            profile=args.profile,
            file_path=args.config_file,
            json_str=args.json,
            env=not args.no_env,
            **overrides
        )
        
    except Exception as e:
        print(f"配置错误: {e}", file=sys.stderr)
        sys.exit(1)
    
    # 保存配置档案
    if args.save_profile:
        manager.add_profile(args.save_profile, config, args.profile_desc)
        print(f"已保存配置档案: {args.save_profile}")
        if not args.interactive and not args.prompt:
            return
    
    # 显示配置
    if args.show_config:
        print("当前配置:")
        print(config.to_json())
        if not args.interactive and not args.prompt:
            return
    
    # 创建客户端
    try:
        client = LLMClient(config)
    except Exception as e:
        print(f"创建客户端失败: {e}", file=sys.stderr)
        sys.exit(1)
    
    # 健康检查
    if args.health:
        if client.health_check():
            print("服务正常")
        else:
            print("服务异常", file=sys.stderr)
            sys.exit(1)
        return
    
    # 列出模型
    if args.list_models:
        if hasattr(client._provider, 'list_models'):
            models = client._provider.list_models()
            for model in models:
                print(model)
        else:
            print("当前提供商不支持列出模型")
        return
    
    # 交互模式
    if args.interactive:
        interactive_mode(client)
        return
    
    # 单次请求
    prompt = args.prompt
    if not prompt:
        print("请提供提示词或使用 --interactive 进入交互模式", file=sys.stderr)
        print("使用 --help 查看帮助", file=sys.stderr)
        sys.exit(1)
    
    try:
        if args.complete:
            response = client.complete(prompt)
            print(response.content)
        else:
            if config.stream:
                print("助手: ", end="", flush=True)
                for chunk in client.stream_chat(prompt):
                    print(chunk, end="", flush=True)
                print()
            else:
                response = client.chat(prompt)
                print(response.content)
    except Exception as e:
        print(f"请求失败: {e}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()