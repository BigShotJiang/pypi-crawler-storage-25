"""Token计数器"""

from typing import List, Dict, Any


class TokenCounter:
    """简单的Token计数器"""
    
    def __init__(self):
        # 中文字符和英文字符的近似比例
        self.chinese_token_ratio = 1.0  # 一个中文约等于1个token
        self.english_token_ratio = 0.75  # 一个英文单词约0.75个token
    
    def count_text(self, text: str) -> int:
        """计算文本的token数"""
        if not text:
            return 0
        
        # 统计中文字符
        chinese_chars = sum(1 for c in text if '\u4e00' <= c <= '\u9fff')
        
        # 统计英文单词
        english_words = len([w for w in text.split() if any(c.isalpha() for c in w)])
        
        # 统计其他字符（标点、数字等）
        other_chars = len(text) - chinese_chars - sum(len(w) for w in text.split())
        
        tokens = int(
            chinese_chars * self.chinese_token_ratio +
            english_words * self.english_token_ratio +
            other_chars * 0.5
        )
        
        return max(1, tokens)
    
    def count_messages(self, messages: List[Dict[str, str]]) -> int:
        """计算消息列表的token数"""
        total = 0
        for msg in messages:
            total += self.count_text(msg.get("content", ""))
            total += 4  # 每条消息的格式开销
        return total
    
    def count_conversation(self, conversation: List[Dict[str, str]]) -> int:
        """计算对话的token数"""
        return self.count_messages(conversation)