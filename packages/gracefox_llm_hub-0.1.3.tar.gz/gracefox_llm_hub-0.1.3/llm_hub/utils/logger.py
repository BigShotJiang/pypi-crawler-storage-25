"""日志模块"""

import logging
import sys
import os
from datetime import datetime
from typing import Optional
from pathlib import Path


# 全局日志器实例
_loggers = {}
_default_level = logging.INFO
_log_dir = "logs"


def setup_logger(
    name: str = "llm_hub",
    level: int = logging.INFO,
    log_file: Optional[str] = None,
    console: bool = True,
    file_size_limit: int = 10 * 1024 * 1024,  # 10MB
    backup_count: int = 5
) -> logging.Logger:
    """
    设置日志器
    
    Args:
        name: 日志器名称
        level: 日志级别
        log_file: 日志文件路径，None则不输出到文件
        console: 是否输出到控制台
        file_size_limit: 日志文件大小限制（字节）
        backup_count: 备份文件数量
    
    Returns:
        配置好的日志器
    """
    logger = logging.getLogger(name)
    logger.setLevel(level)
    
    # 清除已有的处理器
    logger.handlers.clear()
    
    # 设置格式
    formatter = logging.Formatter(
        '%(asctime)s - %(name)s - %(levelname)s - %(filename)s:%(lineno)d - %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S'
    )
    
    # 控制台处理器
    if console:
        console_handler = logging.StreamHandler(sys.stdout)
        console_handler.setLevel(level)
        console_handler.setFormatter(formatter)
        logger.addHandler(console_handler)
    
    # 文件处理器
    if log_file:
        # 确保日志目录存在
        log_path = Path(log_file)
        log_path.parent.mkdir(parents=True, exist_ok=True)
        
        # 使用RotatingFileHandler
        try:
            from logging.handlers import RotatingFileHandler
            file_handler = RotatingFileHandler(
                log_file,
                maxBytes=file_size_limit,
                backupCount=backup_count,
                encoding='utf-8'
            )
        except ImportError:
            # 回退到普通FileHandler
            file_handler = logging.FileHandler(log_file, encoding='utf-8')
        
        file_handler.setLevel(level)
        file_handler.setFormatter(formatter)
        logger.addHandler(file_handler)
    
    # 存储全局配置
    global _default_level
    _default_level = level
    
    _loggers[name] = logger
    return logger


def get_logger(name: str = None) -> logging.Logger:
    """
    获取日志器实例
    
    Args:
        name: 日志器名称，None则返回根日志器
    
    Returns:
        日志器实例
    """
    if name is None:
        name = "llm_hub"
    
    if name not in _loggers:
        # 创建默认日志器
        log_file = os.path.join(_log_dir, f"{name}_{datetime.now().strftime('%Y%m%d')}.log")
        setup_logger(name, _default_level, log_file)
    
    return _loggers[name]


def set_log_level(level: int):
    """
    设置全局日志级别
    
    Args:
        level: 日志级别 (logging.DEBUG, INFO, WARNING, ERROR, CRITICAL)
    """
    global _default_level
    _default_level = level
    
    for logger in _loggers.values():
        logger.setLevel(level)
        for handler in logger.handlers:
            handler.setLevel(level)


def get_log_level() -> int:
    """获取当前日志级别"""
    return _default_level


class LoggerMixin:
    """日志混入类，为类提供日志功能"""
    
    @property
    def logger(self) -> logging.Logger:
        """获取类实例的日志器"""
        if not hasattr(self, '_logger'):
            self._logger = get_logger(self.__class__.__name__)
        return self._logger


class ContextLogger:
    """带上下文的日志器"""
    
    def __init__(self, name: str, context: dict = None):
        self.logger = get_logger(name)
        self.context = context or {}
    
    def _format_message(self, message: str) -> str:
        """格式化消息，添加上下文"""
        if self.context:
            context_str = " ".join([f"[{k}={v}]" for k, v in self.context.items()])
            return f"{context_str} {message}"
        return message
    
    def debug(self, message: str, *args, **kwargs):
        self.logger.debug(self._format_message(message), *args, **kwargs)
    
    def info(self, message: str, *args, **kwargs):
        self.logger.info(self._format_message(message), *args, **kwargs)
    
    def warning(self, message: str, *args, **kwargs):
        self.logger.warning(self._format_message(message), *args, **kwargs)
    
    def error(self, message: str, *args, **kwargs):
        self.logger.error(self._format_message(message), *args, **kwargs)
    
    def critical(self, message: str, *args, **kwargs):
        self.logger.critical(self._format_message(message), *args, **kwargs)
    
    def exception(self, message: str, *args, **kwargs):
        self.logger.exception(self._format_message(message), *args, **kwargs)


# 便捷函数
def debug(msg: str, *args, **kwargs):
    """调试日志"""
    get_logger().debug(msg, *args, **kwargs)


def info(msg: str, *args, **kwargs):
    """信息日志"""
    get_logger().info(msg, *args, **kwargs)


def warning(msg: str, *args, **kwargs):
    """警告日志"""
    get_logger().warning(msg, *args, **kwargs)


def error(msg: str, *args, **kwargs):
    """错误日志"""
    get_logger().error(msg, *args, **kwargs)


def critical(msg: str, *args, **kwargs):
    """严重错误日志"""
    get_logger().critical(msg, *args, **kwargs)


# 日志级别常量
DEBUG = logging.DEBUG
INFO = logging.INFO
WARNING = logging.WARNING
ERROR = logging.ERROR
CRITICAL = logging.CRITICAL


# 初始化默认日志器
def init_default_logger(log_dir: str = "logs", level: int = logging.INFO):
    """初始化默认日志器"""
    global _log_dir, _default_level
    _log_dir = log_dir
    _default_level = level
    
    log_file = os.path.join(log_dir, f"llm_hub_{datetime.now().strftime('%Y%m%d')}.log")
    setup_logger("llm_hub", level, log_file)
    setup_logger("ui", level, os.path.join(log_dir, f"ui_{datetime.now().strftime('%Y%m%d')}.log"))
    setup_logger("provider", level, os.path.join(log_dir, f"provider_{datetime.now().strftime('%Y%m%d')}.log"))


# 自动初始化（但不覆盖已存在的日志器）
if "llm_hub" not in _loggers:
    init_default_logger()