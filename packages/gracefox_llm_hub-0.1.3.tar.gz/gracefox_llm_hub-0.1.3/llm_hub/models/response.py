"""响应模型"""

from dataclasses import dataclass, field
from typing import Optional, Dict, Any, Generator


@dataclass
class Response:
    """响应"""
    content: str
    model: str
    usage: Optional[Dict[str, int]] = None
    finish_reason: Optional[str] = None
    raw: Optional[Dict] = None
    
    def __str__(self):
        return self.content


class StreamResponse:
    """流式响应"""
    
    def __init__(self, generator: Generator):
        self.generator = generator
    
    def __iter__(self):
        return self.generator
    
    def collect(self) -> str:
        """收集所有流式响应"""
        return "".join(self.generator)