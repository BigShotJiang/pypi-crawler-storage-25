"""消息模型"""

from dataclasses import dataclass, field
from typing import List, Optional, Dict, Any
from enum import Enum


class Role(Enum):
    """消息角色"""
    SYSTEM = "system"
    USER = "user"
    ASSISTANT = "assistant"
    FUNCTION = "function"


@dataclass
class Message:
    """消息"""
    role: str
    content: str
    name: Optional[str] = None
    function_call: Optional[Dict] = None
    
    @classmethod
    def system(cls, content: str) -> "Message":
        return cls(role="system", content=content)
    
    @classmethod
    def user(cls, content: str) -> "Message":
        return cls(role="user", content=content)
    
    @classmethod
    def assistant(cls, content: str) -> "Message":
        return cls(role="assistant", content=content)
    
    def to_dict(self) -> Dict:
        result = {"role": self.role, "content": self.content}
        if self.name:
            result["name"] = self.name
        if self.function_call:
            result["function_call"] = self.function_call
        return result


@dataclass
class Conversation:
    """对话"""
    messages: List[Message] = field(default_factory=list)
    system_prompt: Optional[str] = None
    
    def add(self, message: Message):
        """添加消息"""
        self.messages.append(message)
    
    def add_user(self, content: str):
        """添加用户消息"""
        self.add(Message.user(content))
    
    def add_assistant(self, content: str):
        """添加助手消息"""
        self.add(Message.assistant(content))
    
    def get_messages(self) -> List[Dict]:
        """获取消息列表（用于API调用）"""
        messages = []
        if self.system_prompt:
            messages.append({"role": "system", "content": self.system_prompt})
        messages.extend([m.to_dict() for m in self.messages])
        return messages
    
    def clear(self):
        """清空对话"""
        self.messages.clear()
    
    def last(self) -> Optional[Message]:
        """获取最后一条消息"""
        return self.messages[-1] if self.messages else None
    
    def __len__(self):
        return len(self.messages)