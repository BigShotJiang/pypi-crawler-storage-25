"""OpenAI兼容提供商"""

import json
import requests
from typing import Dict, Any, List, Generator, Union

from llm_hub.providers.base import BaseProvider
from llm_hub.models.message import Conversation
from llm_hub.models.response import Response, StreamResponse


class OpenAICompatibleProvider(BaseProvider):
    """OpenAI兼容提供商"""
    
    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        self.api_url = config.get("api_url", "https://api.openai.com/v1")
        self.api_key = config.get("api_key")
        self.model = config.get("model", "gpt-3.5-turbo")
        
    def _get_headers(self) -> Dict:
        """获取请求头"""
        return {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {self.api_key}"
        }
    
    def _build_payload(self, messages: List[Dict], **kwargs) -> Dict:
        """构建请求负载"""
        return {
            "model": kwargs.get("model", self.model),
            "messages": messages,
            "temperature": kwargs.get("temperature", self.config.get("temperature", 0.7)),
            "max_tokens": kwargs.get("max_tokens", self.config.get("max_tokens", 2000)),
            "top_p": kwargs.get("top_p", self.config.get("top_p", 0.95)),
            "frequency_penalty": kwargs.get("frequency_penalty", self.config.get("frequency_penalty", 0)),
            "presence_penalty": kwargs.get("presence_penalty", self.config.get("presence_penalty", 0)),
            "stream": kwargs.get("stream", self.config.get("stream", False))
        }
    
    def _parse_response(self, data: Dict) -> Response:
        """解析响应"""
        choice = data.get("choices", [{}])[0]
        return Response(
            content=choice.get("message", {}).get("content", ""),
            model=data.get("model", self.model),
            usage=data.get("usage"),
            finish_reason=choice.get("finish_reason"),
            raw=data
        )
    
    def chat(self, conversation: Conversation, **kwargs) -> Union[Response, StreamResponse]:
        """对话"""
        messages = conversation.get_messages()
        payload = self._build_payload(messages, **kwargs)
        stream = payload["stream"]
        
        self._log(f"Request: {payload}")
        
        response = requests.post(
            f"{self.api_url}/chat/completions",
            json=payload,
            headers=self._get_headers(),
            stream=stream,
            timeout=self.config.get("timeout", 60)
        )
        response.raise_for_status()
        
        if stream:
            def generate():
                for line in response.iter_lines():
                    if line:
                        line = line.decode('utf-8')
                        if line.startswith("data: "):
                            line = line[6:]
                        if line != "[DONE]":
                            try:
                                data = json.loads(line)
                                content = data.get("choices", [{}])[0].get("delta", {}).get("content", "")
                                if content:
                                    yield content
                            except:
                                pass
            return StreamResponse(generate())
        else:
            return self._parse_response(response.json())
    
    def complete(self, prompt: str, **kwargs) -> Union[Response, StreamResponse]:
        """文本补全"""
        payload = {
            "model": kwargs.get("model", self.model),
            "prompt": prompt,
            "temperature": kwargs.get("temperature", self.config.get("temperature", 0.7)),
            "max_tokens": kwargs.get("max_tokens", self.config.get("max_tokens", 2000)),
            "stream": kwargs.get("stream", self.config.get("stream", False))
        }
        
        response = requests.post(
            f"{self.api_url}/completions",
            json=payload,
            headers=self._get_headers(),
            timeout=self.config.get("timeout", 60)
        )
        response.raise_for_status()
        data = response.json()
        choice = data.get("choices", [{}])[0]
        
        return Response(
            content=choice.get("text", ""),
            model=data.get("model", self.model),
            usage=data.get("usage"),
            finish_reason=choice.get("finish_reason"),
            raw=data
        )
    
    def health_check(self) -> bool:
        """健康检查"""
        try:
            response = requests.get(
                f"{self.api_url}/models",
                headers=self._get_headers(),
                timeout=10
            )
            return response.status_code == 200
        except:
            return False