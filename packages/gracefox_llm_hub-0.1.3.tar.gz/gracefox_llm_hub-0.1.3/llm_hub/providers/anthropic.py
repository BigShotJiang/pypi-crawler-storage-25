"""Anthropic Claude 提供商"""

import json
import requests
from typing import Dict, Any, List, Union

from llm_hub.providers.base import BaseProvider
from llm_hub.models.message import Conversation
from llm_hub.models.response import Response


class AnthropicProvider(BaseProvider):
    """Anthropic Claude 提供商"""
    
    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        self.api_key = config.get("api_key")
        self.model = config.get("model", "claude-3-sonnet-20240229")
        self.api_url = config.get("api_url", "https://api.anthropic.com/v1")
    
    def _get_headers(self) -> Dict:
        """获取请求头"""
        return {
            "Content-Type": "application/json",
            "x-api-key": self.api_key,
            "anthropic-version": "2023-06-01"
        }
    
    def _convert_messages(self, messages: List[Dict]) -> tuple:
        """转换消息格式，提取系统提示"""
        system_prompt = None
        converted = []
        
        for msg in messages:
            if msg["role"] == "system":
                system_prompt = msg["content"]
            else:
                converted.append({
                    "role": msg["role"],
                    "content": msg["content"]
                })
        
        return system_prompt, converted
    
    def chat(self, conversation: Conversation, **kwargs) -> Union[Response, Response]:
        """对话"""
        messages = conversation.get_messages()
        system_prompt, converted_messages = self._convert_messages(messages)
        
        payload = {
            "model": kwargs.get("model", self.model),
            "messages": converted_messages,
            "max_tokens": kwargs.get("max_tokens", self.config.get("max_tokens", 2000)),
            "temperature": kwargs.get("temperature", self.config.get("temperature", 0.7)),
            "top_p": kwargs.get("top_p", self.config.get("top_p", 0.95))
        }
        
        if system_prompt:
            payload["system"] = system_prompt
        
        response = requests.post(
            f"{self.api_url}/messages",
            json=payload,
            headers=self._get_headers(),
            timeout=self.config.get("timeout", 60)
        )
        response.raise_for_status()
        data = response.json()
        
        content = data.get("content", [{}])[0].get("text", "")
        return Response(content=content, model=self.model, usage=data.get("usage"), raw=data)
    
    def complete(self, prompt: str, **kwargs) -> Union[Response, Response]:
        """文本补全"""
        conv = Conversation()
        conv.add_user(prompt)
        return self.chat(conv, **kwargs)
    
    def health_check(self) -> bool:
        """健康检查"""
        try:
            response = requests.get(
                f"{self.api_url}/models",
                headers=self._get_headers(),
                timeout=10
            )
            return response.status_code == 200
        except:
            return False