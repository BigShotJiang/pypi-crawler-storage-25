"""自定义提供商"""

import requests
from typing import Dict, Any, List, Union

from llm_hub.providers.base import BaseProvider
from llm_hub.models.message import Conversation
from llm_hub.models.response import Response


class CustomProvider(BaseProvider):
    """自定义API提供商"""
    
    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        self.api_url = config.get("api_url")
        self.api_key = config.get("api_key")
        self.model = config.get("model", "custom")
        self.request_template = config.get("request_template", {})
        self.response_path = config.get("response_path", "content")
    
    def _build_request(self, prompt: str, **kwargs) -> Dict:
        """构建请求（可被子类覆盖）"""
        template = self.request_template.copy()
        template.update({
            "prompt": prompt,
            "temperature": kwargs.get("temperature", self.config.get("temperature", 0.7)),
            "max_tokens": kwargs.get("max_tokens", self.config.get("max_tokens", 2000))
        })
        return template
    
    def _parse_response(self, data: Dict) -> str:
        """解析响应（可被子类覆盖）"""
        parts = self.response_path.split('.')
        result = data
        for part in parts:
            if isinstance(result, dict):
                result = result.get(part)
            elif isinstance(result, list):
                try:
                    idx = int(part)
                    result = result[idx]
                except:
                    break
            else:
                break
        return str(result) if result else ""
    
    def chat(self, conversation: Conversation, **kwargs) -> Response:
        """对话"""
        messages = conversation.get_messages()
        # 简化处理，将对话转换为prompt
        prompt = "\n".join([f"{m['role']}: {m['content']}" for m in messages])
        return self.complete(prompt, **kwargs)
    
    def complete(self, prompt: str, **kwargs) -> Response:
        """文本补全"""
        if not self.api_url:
            raise RuntimeError("Custom provider requires api_url")
        
        payload = self._build_request(prompt, **kwargs)
        headers = {"Content-Type": "application/json"}
        
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"
        
        response = requests.post(
            self.api_url,
            json=payload,
            headers=headers,
            timeout=self.config.get("timeout", 60)
        )
        response.raise_for_status()
        data = response.json()
        
        content = self._parse_response(data)
        return Response(content=content, model=self.model, raw=data)
    
    def health_check(self) -> bool:
        """健康检查"""
        try:
            response = requests.head(self.api_url, timeout=10)
            return response.status_code < 500
        except:
            return False