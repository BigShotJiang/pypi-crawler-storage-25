"""DeepSeek 提供商"""

from llm_hub.providers.openai_compatible import OpenAICompatibleProvider


class DeepSeekProvider(OpenAICompatibleProvider):
    """DeepSeek 提供商"""
    
    def __init__(self, config: dict):
        super().__init__(config)
        # DeepSeek 默认配置
        self.api_url = config.get("api_url", "https://api.deepseek.com/v1")
        self.model = config.get("model", "deepseek-chat")