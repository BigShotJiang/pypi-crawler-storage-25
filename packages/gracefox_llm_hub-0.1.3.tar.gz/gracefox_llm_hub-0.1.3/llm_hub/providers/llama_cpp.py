"""llama.cpp提供商"""

import subprocess
import os
from typing import Dict, Any, List, Generator, Union

from llm_hub.providers.base import BaseProvider
from llm_hub.models.message import Conversation
from llm_hub.models.response import Response, StreamResponse


class LlamaCppProvider(BaseProvider):
    """llama.cpp提供商"""
    
    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        self.executable = config.get("executable", "./llama.exe")
        self.model_path = config.get("model_path", "")
        
    def is_available(self) -> bool:
        """检查是否可用"""
        return os.path.exists(self.executable) and os.path.exists(self.model_path)
    
    def _build_command(self, prompt: str, **kwargs) -> List[str]:
        """构建命令"""
        return [
            self.executable,
            "-m", self.model_path,
            "-p", prompt,
            "-n", str(kwargs.get("max_tokens", 512)),
            "--temp", str(kwargs.get("temperature", 0.7)),
            "--top-k", str(kwargs.get("top_k", 40)),
            "--top-p", str(kwargs.get("top_p", 0.95)),
            "--repeat_penalty", str(kwargs.get("repeat_penalty", 1.1))
        ]
    
    def chat(self, conversation: Conversation, **kwargs) -> Union[Response, StreamResponse]:
        """对话"""
        if not self.is_available():
            raise RuntimeError("llama.cpp not available")
        
        # 将对话转换为prompt
        messages = conversation.get_messages()
        prompt = "\n".join([f"{m['role']}: {m['content']}" for m in messages])
        prompt += "\nassistant: "
        
        return self.complete(prompt, **kwargs)
    
    def complete(self, prompt: str, **kwargs) -> Union[Response, StreamResponse]:
        """文本补全"""
        if not self.is_available():
            raise RuntimeError("llama.cpp not available")
        
        cmd = self._build_command(prompt, **kwargs)
        stream = kwargs.get("stream", False)
        
        try:
            process = subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                bufsize=1
            )
            
            if stream:
                def generate():
                    for line in process.stdout:
                        if line.strip():
                            yield line.strip()
                    process.wait()
                return StreamResponse(generate())
            else:
                output, error = process.communicate(timeout=kwargs.get("timeout", 60))
                if error:
                    raise RuntimeError(f"llama.cpp error: {error}")
                return Response(content=output.strip(), model=self.model_path)
                
        except Exception as e:
            raise RuntimeError(f"llama.cpp error: {e}")
    
    def health_check(self) -> bool:
        """健康检查"""
        return self.is_available()