"""LLM提供商模块"""

from llm_hub.providers.base import BaseProvider
from llm_hub.providers.openai_compatible import OpenAICompatibleProvider
from llm_hub.providers.ollama import OllamaProvider
from llm_hub.providers.llama_cpp import LlamaCppProvider
from llm_hub.providers.deepseek import DeepSeekProvider
from llm_hub.providers.kimi import KimiProvider
from llm_hub.providers.gemini import GeminiProvider
from llm_hub.providers.anthropic import AnthropicProvider
from llm_hub.providers.custom import CustomProvider
from llm_hub.core.enums import Provider


def _get_default_url(provider: Provider) -> str:
    """获取默认API URL"""
    urls = {
        Provider.OPENAI: "https://api.openai.com/v1",
        Provider.DEEPSEEK: "https://api.deepseek.com/v1",
        Provider.KIMI: "https://api.moonshot.cn/v1",
        Provider.KIMI_INTL: "https://api.moonshot.cc/v1",
        Provider.ALIYUN_BAILIAN: "https://dashscope.aliyuncs.com/compatible-mode/v1",
        Provider.OPENROUTER: "https://openrouter.ai/api/v1",
        Provider.ANTHROPIC: "https://api.anthropic.com/v1",
        Provider.GOOGLE_GEMINI: "https://generativelanguage.googleapis.com/v1",
    }
    return urls.get(provider, "")


def create_provider(provider: Provider, config: dict) -> BaseProvider:
    """创建提供商实例"""
    providers = {
        Provider.OPENAI: OpenAICompatibleProvider,
        Provider.DEEPSEEK: DeepSeekProvider,
        Provider.KIMI: KimiProvider,
        Provider.KIMI_INTL: KimiProvider,
        Provider.ALIYUN_BAILIAN: OpenAICompatibleProvider,
        Provider.OPENROUTER: OpenAICompatibleProvider,
        Provider.GOOGLE_GEMINI: GeminiProvider,
        Provider.ANTHROPIC: AnthropicProvider,
        Provider.OLLAMA: OllamaProvider,
        Provider.LLAMA_CPP: LlamaCppProvider,
        Provider.LOCAL: LlamaCppProvider,
        Provider.CUSTOM: CustomProvider,
    }
    
    provider_class = providers.get(provider, OpenAICompatibleProvider)
    
    # 设置API URL（如果未提供）
    if provider not in [Provider.OLLAMA, Provider.LLAMA_CPP, Provider.LOCAL]:
        if not config.get("api_url"):
            config["api_url"] = _get_default_url(provider)
    
    return provider_class(config)


__all__ = [
    "BaseProvider",
    "OpenAICompatibleProvider",
    "OllamaProvider",
    "LlamaCppProvider",
    "DeepSeekProvider",
    "KimiProvider",
    "GeminiProvider",
    "AnthropicProvider",
    "CustomProvider",
    "create_provider"
]