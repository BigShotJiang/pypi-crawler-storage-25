"""Kimi 提供商"""

from llm_hub.providers.openai_compatible import OpenAICompatibleProvider


class KimiProvider(OpenAICompatibleProvider):
    """Kimi 提供商"""
    
    def __init__(self, config: dict):
        super().__init__(config)
        # Kimi 默认配置
        if "kimi_intl" in config.get("provider", ""):
            self.api_url = config.get("api_url", "https://api.moonshot.cc/v1")
        else:
            self.api_url = config.get("api_url", "https://api.moonshot.cn/v1")
        self.model = config.get("model", "moonshot-v1-8k")