"""Google Gemini 提供商"""

import json
import requests
from typing import Dict, Any, List, Union, Generator

from llm_hub.providers.base import BaseProvider
from llm_hub.models.message import Conversation
from llm_hub.models.response import Response, StreamResponse


class GeminiProvider(BaseProvider):
    """Google Gemini 提供商"""
    
    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        self.api_key = config.get("api_key")
        self.model = config.get("model", "gemini-pro")
        self.api_url = "https://generativelanguage.googleapis.com/v1"
    
    def _get_url(self) -> str:
        """获取API URL"""
        return f"{self.api_url}/models/{self.model}:generateContent?key={self.api_key}"
    
    def _convert_messages(self, messages: List[Dict]) -> List[Dict]:
        """转换消息格式"""
        contents = []
        for msg in messages:
            role = "user" if msg["role"] == "user" else "model"
            contents.append({
                "role": role,
                "parts": [{"text": msg["content"]}]
            })
        return contents
    
    def chat(self, conversation: Conversation, **kwargs) -> Union[Response, StreamResponse]:
        """对话"""
        messages = conversation.get_messages()
        contents = self._convert_messages(messages)
        
        payload = {
            "contents": contents,
            "generationConfig": {
                "temperature": kwargs.get("temperature", self.config.get("temperature", 0.7)),
                "maxOutputTokens": kwargs.get("max_tokens", self.config.get("max_tokens", 2000)),
                "topP": kwargs.get("top_p", self.config.get("top_p", 0.95)),
                "topK": kwargs.get("top_k", 40)
            }
        }
        
        response = requests.post(
            self._get_url(),
            json=payload,
            headers={"Content-Type": "application/json"},
            timeout=self.config.get("timeout", 60)
        )
        response.raise_for_status()
        data = response.json()
        
        try:
            content = data["candidates"][0]["content"]["parts"][0]["text"]
            return Response(content=content, model=self.model, raw=data)
        except (KeyError, IndexError):
            raise RuntimeError(f"Failed to parse response: {data}")
    
    def complete(self, prompt: str, **kwargs) -> Union[Response, StreamResponse]:
        """文本补全（Gemini使用相同的chat接口）"""
        conv = Conversation()
        conv.add_user(prompt)
        return self.chat(conv, **kwargs)
    
    def health_check(self) -> bool:
        """健康检查"""
        try:
            response = requests.get(
                f"{self.api_url}/models",
                params={"key": self.api_key},
                timeout=10
            )
            return response.status_code == 200
        except:
            return False