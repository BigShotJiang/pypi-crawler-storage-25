"""Ollama提供商"""

import json
import requests
from typing import Dict, Any, List, Generator, Union

from llm_hub.providers.base import BaseProvider
from llm_hub.models.message import Conversation
from llm_hub.models.response import Response, StreamResponse


class OllamaProvider(BaseProvider):
    """Ollama提供商"""
    
    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        self.base_url = config.get("ollama_url", "http://localhost:11434")
        self.api_url = f"{self.base_url}/api"
        self.model = config.get("model", "llama2")
    
    def _get_headers(self) -> Dict:
        return {"Content-Type": "application/json"}
    
    def chat(self, conversation: Conversation, **kwargs) -> Union[Response, StreamResponse]:
        """对话"""
        messages = conversation.get_messages()
        stream = kwargs.get("stream", self.config.get("stream", False))
        
        payload = {
            "model": kwargs.get("model", self.model),
            "messages": messages,
            "stream": stream,
            "options": {
                "temperature": kwargs.get("temperature", self.config.get("temperature", 0.7)),
                "num_predict": kwargs.get("max_tokens", self.config.get("max_tokens", 2000)),
                "top_p": kwargs.get("top_p", self.config.get("top_p", 0.95))
            }
        }
        
        response = requests.post(
            f"{self.api_url}/chat",
            json=payload,
            headers=self._get_headers(),
            stream=stream,
            timeout=self.config.get("timeout", 60)
        )
        response.raise_for_status()
        
        if stream:
            def generate():
                for line in response.iter_lines():
                    if line:
                        data = json.loads(line)
                        if "message" in data and "content" in data["message"]:
                            yield data["message"]["content"]
            return StreamResponse(generate())
        else:
            data = response.json()
            return Response(
                content=data.get("message", {}).get("content", ""),
                model=self.model,
                raw=data
            )
    
    def complete(self, prompt: str, **kwargs) -> Union[Response, StreamResponse]:
        """文本补全"""
        stream = kwargs.get("stream", self.config.get("stream", False))
        
        payload = {
            "model": kwargs.get("model", self.model),
            "prompt": prompt,
            "stream": stream,
            "options": {
                "temperature": kwargs.get("temperature", self.config.get("temperature", 0.7)),
                "num_predict": kwargs.get("max_tokens", self.config.get("max_tokens", 2000))
            }
        }
        
        response = requests.post(
            f"{self.api_url}/generate",
            json=payload,
            headers=self._get_headers(),
            stream=stream,
            timeout=self.config.get("timeout", 60)
        )
        response.raise_for_status()
        
        if stream:
            def generate():
                for line in response.iter_lines():
                    if line:
                        data = json.loads(line)
                        if "response" in data:
                            yield data["response"]
            return StreamResponse(generate())
        else:
            data = response.json()
            return Response(
                content=data.get("response", ""),
                model=self.model,
                raw=data
            )
    
    def list_models(self) -> List[str]:
        """列出可用模型"""
        try:
            response = requests.get(f"{self.api_url}/tags", timeout=10)
            if response.status_code == 200:
                models = response.json().get("models", [])
                return [m["name"] for m in models]
        except:
            pass
        return []
    
    def health_check(self) -> bool:
        """健康检查"""
        try:
            response = requests.get(f"{self.base_url}", timeout=5)
            return response.status_code == 200
        except:
            return False