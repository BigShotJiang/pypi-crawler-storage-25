"""LLM提供商基类"""

from abc import ABC, abstractmethod
from typing import Dict, Any, List, Generator, Union, Optional

from llm_hub.models.message import Conversation
from llm_hub.models.response import Response, StreamResponse


class BaseProvider(ABC):
    """LLM提供商基类"""
    
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.debug = config.get("debug", False)
    
    @abstractmethod
    def chat(self, conversation: Conversation, **kwargs) -> Union[Response, StreamResponse]:
        """对话"""
        pass
    
    @abstractmethod
    def complete(self, prompt: str, **kwargs) -> Union[Response, StreamResponse]:
        """文本补全"""
        pass
    
    @abstractmethod
    def health_check(self) -> bool:
        """健康检查"""
        pass
    
    def _log(self, message: str):
        """调试日志"""
        if self.debug:
            print(f"[{self.__class__.__name__}] {message}")