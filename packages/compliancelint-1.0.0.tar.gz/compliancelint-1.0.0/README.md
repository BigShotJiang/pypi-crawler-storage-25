# ComplianceLint

[![License](https://img.shields.io/badge/License-Apache_2.0-blue.svg)](https://opensource.org/licenses/Apache-2.0)
[![Python](https://img.shields.io/badge/Python-3.10+-green.svg)](https://www.python.org/)
[![MCP](https://img.shields.io/badge/MCP-Compatible-purple.svg)](https://modelcontextprotocol.io/)
[![EU AI Act](https://img.shields.io/badge/EU_AI_Act-94_obligations-emerald.svg)](https://compliancelint.dev)

**ESLint checks your JavaScript. ComplianceLint checks your legal compliance.**

Scan your codebase against 94 legal obligations from the EU AI Act. Get findings with exact legal citations. Your code never leaves your machine.

> **2026-08-02** — EU AI Act high-risk requirements become enforceable. ComplianceLint helps you prepare now.

---

## Who Needs This

- **AI product teams** — building chatbots, recommendation engines, content generation, or any AI-powered feature
- **Solo developers & founders** — shipping AI products and need to know if they comply before enforcement begins
- **CTOs & engineering leads** — need compliance visibility without hiring a legal team
- **Compliance officers** — want code-level evidence, not just checkbox questionnaires

If your software uses AI and you serve EU customers, the EU AI Act applies to you.

---

## Quick Start

### Option A: One command (recommended)

```bash
npx compliancelint init
```

This adds ComplianceLint to your project's MCP config. Works with Claude Code, Cursor, Windsurf, and any MCP-compatible IDE.

### Option B: Manual setup

Add to your `.mcp.json`:

```json
{
  "mcpServers": {
    "compliancelint": {
      "type": "stdio",
      "command": "python",
      "args": ["/path/to/scanner/server.py"],
      "env": { "PYTHONUNBUFFERED": "1" }
    }
  }
}
```

| IDE | Config location |
|-----|----------------|
| Claude Code | `.mcp.json` in project root |
| Cursor | Settings → MCP → Add Server |
| Windsurf | `.mcp.json` in project root |
| Codex | MCP settings |
| Zed | MCP settings |

### Then ask your AI

> "Scan my project for EU AI Act compliance."

That's it. No extra API key needed — uses your existing AI subscription.

### Track over time (optional)

> "Connect to ComplianceLint dashboard."

Opens browser, links your dashboard at [compliancelint.dev](https://compliancelint.dev). Code never leaves your machine — only compliance findings are synced.

---

## What You Get

```
Art. 12 — Record-keeping                            NON-COMPLIANT

┌──────────────┬────────────┬──────────────────────────────────────────┐
│ Obligation   │ Status     │ Description                              │
├──────────────┼────────────┼──────────────────────────────────────────┤
│ ART12-OBL-1  │ COMPLIANT      │ Logging detected (structlog)         │
│ ART12-OBL-2a │ NON_COMPLIANT  │ Risk event logging not found         │
│ ART12-OBL-4  │ NON_COMPLIANT  │ No retention policy documented       │
│ ART12-OBL-3a │ NOT_APPLICABLE │ Not a biometric system               │
└──────────────┴────────────┴──────────────────────────────────────────┘

Legal citation: Art. 12(1): "High-risk AI systems shall technically allow
for the automatic recording of events (logs)..."
```

Every finding includes:
- **Exact legal citation** — verbatim from EUR-Lex
- **Obligation ID** — traceable to our structured obligation database
- **AI evidence** — what the AI found (or didn't find) in your code
- **Remediation steps** — how to fix it

---

## Dashboard

Track compliance over time at **[compliancelint.dev](https://compliancelint.dev)**:

- Compliance Journey — visualize progress from non-compliant to compliant
- Findings by article — bar chart of issues per EU AI Act article
- PDF reports — export audit-ready reports with legal citations
- Attestation — record human review decisions (cl_update_finding)

```
"Connect to ComplianceLint dashboard and sync my scan results."
```

---

## Why ComplianceLint

| | Other tools | ComplianceLint |
|-|------------|----------------|
| **Method** | Check if `RISK_MANAGEMENT.md` exists | AI reads entire codebase, checks against 94 decomposed legal obligations |
| **Citations** | "You need logging" | `Art. 12(1): "High-risk AI systems shall technically allow for the automatic recording of events..."` |
| **False positives** | Keyword matching → many | AI understands context → near zero |
| **Privacy** | Cloud upload | **100% local** — code never leaves your machine |
| **Cost** | Separate subscription | **Free + open source** — uses your existing AI IDE |

---

## How It Works

```
Your Code → AI reads every file → Obligation Engine → Compliance Report
```

1. **Deontic Decomposition** — Legal text → structured obligation atoms (SHALL / SHALL NOT / MAY)
2. **AI-Powered Scan** — Your AI reads the codebase, fills compliance answers
3. **Obligation Engine** — Maps answers to legal obligations (0 tokens, <100ms)
4. **Legal Citations** — Every finding traces to exact article, paragraph, and verbatim quote

---

## Coverage

**EU AI Act** (Regulation (EU) 2024/1689) — 10 articles, 94 obligations:

| Article | Topic | Obligations |
|---------|-------|:-----------:|
| Art. 5 | Prohibited AI practices | 8 |
| Art. 6 | Risk classification | 8 |
| Art. 9 | Risk management system | 19 |
| Art. 10 | Data governance | 11 |
| Art. 11 | Technical documentation | 9 |
| Art. 12 | Record-keeping (logging) | 11 |
| Art. 13 | Transparency | 4 |
| Art. 14 | Human oversight | 6 |
| Art. 15 | Accuracy & robustness | 8 |
| Art. 50 | Transparency obligations | 10 |

All obligations verified against EUR-Lex source text via Three Locks methodology.

---

## MCP Tools

| Tool | Purpose |
|------|---------|
| `cl_scan` | Scan any article(s) — e.g. `cl_scan(article=12)` or `cl_scan(article="all")` |
| `cl_analyze_project` | Understand project structure before scanning |
| `cl_explain_article` | Plain-language explanation of any article |
| `cl_action_plan` | Prioritized remediation plan with effort estimates |
| `cl_update_finding` | Submit evidence, rebuttals, acknowledgements |
| `cl_verify_evidence` | Verify submitted evidence |
| `cl_export_report` | Export Markdown or JSON compliance report |
| `cl_connect` | Link to dashboard (browser OAuth) |
| `cl_sync` | Upload scan results to dashboard |
| `cl_check_updates` | Enforcement deadlines and regulation status |
| `cl_version` | Show ComplianceLint version |

Plus per-article shortcuts (`cl_scan_article_5`, `cl_scan_article_6`, etc.) for convenience.

---

## Compliance Badge

Add a real-time compliance badge to your README:

```markdown
![EU AI Act](https://compliancelint.dev/api/v1/badge/YOUR_REPO_ID)
```

---

## Project Structure

```
scanner/
├── server.py                 MCP Server entry point
├── core/
│   ├── obligation_engine.py  Obligation-driven analysis
│   ├── context.py            AI-to-scanner bridge
│   ├── config.py             Project configuration
│   └── state.py              Scan persistence + project identity
├── modules/                  Per-article scanning modules
├── obligations/              Obligation JSONs (from deontic decomposition)
└── tests/                    Unit + integration tests
```

---

## Pricing

The scanner is **free and open source** (Apache 2.0). The dashboard is freemium:

| | Free | Solo (€19/mo) | Pro (€49/mo) | Team (€149/mo) | Enterprise |
|-|------|---------------|--------------|----------------|------------|
| Developers | 1 | 1 | 5 | 25 | Unlimited |
| Projects | 1 | Unlimited | Unlimited | Unlimited | Unlimited |
| Scan history | 7 days | Unlimited | Unlimited | Unlimited | Unlimited |
| PDF reports | Watermarked | Full | Full | Full | Custom |
| Invite others | — | ✓ | ✓ | ✓ | ✓ |

---

## Roadmap

- [x] MCP Server
- [x] 10 EU AI Act articles, 94 obligations
- [x] SaaS Dashboard with Compliance Journey tracking
- [x] PDF exports (Scan Report, Journey, Declaration, Tasks)
- [x] Attestation system (evidence, rebuttals, acknowledgements)
- [x] Compliance Badge for README
- [x] Zero-friction project identity (git fingerprint)
- [x] `npx compliancelint init` — one-line setup
- [ ] Art. 4 AI Literacy (in force since Feb 2025)
- [ ] Art. 51-56 GPAI model obligations (in force since Aug 2025)
- [ ] Art. 26 Deployer obligations (enforceable Aug 2026)
- [ ] Art. 17 Quality Management System (enforceable Aug 2026)
- [ ] Additional regulations (GDPR, NIS2, DORA)
- [ ] PR Comment Bot (Codecov-style)
- [ ] GitHub Marketplace App

---

## Accuracy & Testing

| Metric | Value |
|--------|-------|
| Legal obligations covered | 94 (from 10 EU AI Act articles) |
| Unit tests | 800+ (scanner + dashboard) |
| Archetype test fixtures | Biometric systems to CRUD apps |
| Test pass rate | 100% |
| Obligation engine | Deterministic, <100ms, zero tokens |
| Source quote verification | Three Locks methodology (EUR-Lex verbatim) |

All obligation logic is tested against 12 project archetypes covering the full spectrum from "fully compliant" to "all null answers". Mutation testing verifies that test assertions are meaningful.

---

## Limitations

- **Not a legal opinion.** ComplianceLint provides AI-assisted compliance assessments, not legal advice. All findings require review by qualified legal counsel.
- **AI-dependent scanning.** Scan quality depends on the AI model used (Claude, GPT, etc.). The scanner's obligation engine is deterministic, but the AI's code understanding may vary.
- **EU AI Act only (currently).** GDPR and other regulations are planned but not yet available.
- **High-risk focus.** Articles 9–15 apply primarily to high-risk AI systems. Non-high-risk systems may show NOT_APPLICABLE for many obligations.
- **No runtime monitoring.** ComplianceLint scans source code statically. It does not monitor running AI systems.
- **English only.** Legal citations and findings are in English. The EU AI Act source text is from the official English EUR-Lex publication.

---

## Human Oversight Design

ComplianceLint is designed with human oversight at every stage:

1. **Human initiates scans** — the AI never scans autonomously; the user explicitly requests each scan
2. **Human reviews findings** — all findings are presented for human judgment before any action
3. **Human submits evidence** — `cl_update_finding` allows users to acknowledge, rebut, defer, or provide evidence for any finding
4. **Human controls sync** — scan results are only uploaded to the dashboard when the user explicitly runs `cl_sync`
5. **No autonomous decisions** — ComplianceLint never makes compliance determinations without human review

The user can stop any MCP tool call at any time by pressing Stop in their IDE.

---

## License

Apache License 2.0 — see [LICENSE](LICENSE)

---

## Contributing

Issues and PRs welcome. Each article module follows the same pattern:

1. **Obligation JSON** (`scanner/obligations/`) — deontic decomposition of legal text
2. **Module** (`scanner/modules/`) — maps AI answers to obligation findings
3. **Tests** (`scanner/tests/`) — verify obligation logic

See [CLAUDE.md](CLAUDE.md) for development conventions.
