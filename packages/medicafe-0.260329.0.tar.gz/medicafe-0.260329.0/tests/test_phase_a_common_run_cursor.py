# -*- coding: utf-8 -*-
from __future__ import print_function

import os
import sys
import unittest

REPO = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
UM = os.path.join(REPO, 'scripts', 'unified_model')
if UM not in sys.path:
    sys.path.insert(0, UM)

from phase_a_common import refresh_run_cursor_updated_at


class TestRefreshRunCursorUpdatedAt(unittest.TestCase):
    def test_updated_at_follows_latest_phase_timestamp(self):
        cursor = {
            'updated_at_utc': '2026-01-01T00:00:00Z',
            'last_phase_c_at_utc': '2026-02-15T12:00:00Z',
        }
        refresh_run_cursor_updated_at(cursor)
        self.assertEqual(cursor['updated_at_utc'], '2026-02-15T12:00:00Z')


if __name__ == '__main__':
    unittest.main()
