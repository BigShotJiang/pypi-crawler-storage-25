#!/usr/bin/env python
from __future__ import print_function

import unittest

from MediCafe import launcher_next_step_assistant as assistant


class LauncherNextStepAssistantTests(unittest.TestCase):

    def test_recommend_download_success_defaults_to_medibot(self):
        outcome = assistant.build_action_outcome(
            action_key='download_emails',
            status='ok',
            severity='info',
            signals={'intake_artifacts_new_count': 1},
        )
        recs = assistant.recommend_next_steps(outcome)
        self.assertGreaterEqual(len(recs), 1)
        self.assertEqual(recs[0].get('action_id'), 'medibot')

    def test_retry_pending_prioritized(self):
        outcome = assistant.build_action_outcome(
            action_key='claims_status',
            status='ok',
            severity='info',
            signals={'retry_queue_pending_count': 3},
        )
        recs = assistant.recommend_next_steps(outcome)
        self.assertEqual(recs[0].get('action_id'), 'medilink')
        self.assertIn('Retry Queue', recs[0].get('label'))

    def test_prompt_enter_chooses_recommended(self):
        recs = [
            {'action_id': 'medibot', 'label': 'Run MediBot extraction', 'reason': 'x'},
            {'action_id': 'main_menu', 'label': 'Return to main menu', 'reason': 'x'},
        ]

        calls = []

        def _prompt(_msg):
            calls.append(_msg)
            return ''

        selected = assistant.prompt_for_recommendation(recs, _prompt, print_fn=lambda *_: None)
        self.assertEqual(selected.get('action_id'), 'medibot')
        self.assertEqual(len(calls), 1)

    def test_collect_startup_signals_uses_providers(self):
        def provider():
            return {
                'zdat_pending': True,
                'retry_queue_pending_count': 2,
                'intake_artifacts_new_count': 4,
            }

        signals = assistant.collect_startup_signals(startup_notices=[], signal_providers=[provider])
        self.assertTrue(signals.get('zdat_pending'))
        self.assertEqual(signals.get('retry_queue_pending_count'), 2)
        self.assertEqual(signals.get('intake_artifacts_new_count'), 4)

    def test_collect_startup_signals_uses_new_provider_keys(self):
        def provider():
            return {
                'queued_error_reports_pending_count': 2,
                'docx_index_attention_needed': True,
                'monthly_humana_aetna_export_due': True,
            }

        signals = assistant.collect_startup_signals(startup_notices=[], signal_providers=[provider])
        self.assertEqual(signals.get('queued_error_reports_pending_count'), 2)
        self.assertTrue(signals.get('docx_index_attention_needed'))
        self.assertTrue(signals.get('monthly_humana_aetna_export_due'))

    def test_recommendations_include_reason_metadata(self):
        outcome = assistant.build_action_outcome(
            action_key='download_emails',
            status='ok',
            severity='info',
            signals={'intake_artifacts_new_count': 1},
        )
        recs = assistant.recommend_next_steps(outcome)
        self.assertTrue(recs)
        self.assertTrue(recs[0].get('reason_code'))
        self.assertTrue(recs[0].get('signal_source'))

    def test_queued_error_reports_recommend_troubleshooting(self):
        outcome = assistant.build_action_outcome(
            action_key='startup',
            status='ok',
            severity='info',
            signals={'queued_error_reports_pending_count': 1},
        )
        recs = assistant.recommend_next_steps(outcome)
        self.assertEqual(recs[0].get('action_id'), 'troubleshooting')
        self.assertEqual(recs[0].get('reason_code'), 'queued_error_reports')

    def test_docx_attention_recommends_troubleshooting(self):
        outcome = assistant.build_action_outcome(
            action_key='startup',
            status='ok',
            severity='info',
            signals={'docx_index_attention_needed': True},
        )
        recs = assistant.recommend_next_steps(outcome)
        self.assertEqual(recs[0].get('action_id'), 'troubleshooting')
        self.assertEqual(recs[0].get('reason_code'), 'docx_index_attention')

    def test_monthly_export_due_recommends_medilink(self):
        outcome = assistant.build_action_outcome(
            action_key='startup',
            status='ok',
            severity='info',
            signals={'monthly_humana_aetna_export_due': True},
        )
        recs = assistant.recommend_next_steps(outcome)
        self.assertEqual(recs[0].get('action_id'), 'medilink')
        self.assertEqual(recs[0].get('reason_code'), 'monthly_humana_aetna_export_due')

    def test_has_actionable_signals(self):
        self.assertFalse(assistant.has_actionable_signals({}))
        self.assertTrue(assistant.has_actionable_signals({'zdat_pending': True}))
        self.assertTrue(assistant.has_actionable_signals({'retry_queue_pending_count': 1}))
        self.assertTrue(assistant.has_actionable_signals({'intake_artifacts_new_count': 2}))
        self.assertTrue(assistant.has_actionable_signals({'queued_error_reports_pending_count': 1}))
        self.assertTrue(assistant.has_actionable_signals({'docx_index_attention_needed': True}))
        self.assertTrue(assistant.has_actionable_signals({'monthly_humana_aetna_export_due': True}))


if __name__ == '__main__':
    unittest.main()