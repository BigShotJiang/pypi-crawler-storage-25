import io
import os
import tempfile
import time
import unittest
from unittest.mock import patch

from MediLink import insurance_type_cache


class TestInsuranceTypeCacheSave(unittest.TestCase):
    def test_save_cache_uses_os_replace_when_available(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            with patch('MediLink.insurance_type_cache.os.replace') as mock_replace:
                insurance_type_cache.save_cache(tmpdir, {'version': 2, 'by_patient_id': {}})
                self.assertTrue(mock_replace.called)

    def test_save_cache_falls_back_without_replace(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            target = insurance_type_cache.get_cache_path(tmpdir)
            with open(target, 'w') as f:
                f.write('{}')

            real_remove = os.remove
            real_rename = os.rename

            with patch('MediLink.insurance_type_cache.os.replace', None), \
                 patch('MediLink.insurance_type_cache.os.remove') as mock_remove, \
                 patch('MediLink.insurance_type_cache.os.rename') as mock_rename:
                def _rename(src, dst):
                    real_rename(src, dst)

                def _remove(path):
                    real_remove(path)

                mock_rename.side_effect = _rename
                mock_remove.side_effect = _remove

                insurance_type_cache.save_cache(tmpdir, {'version': 2, 'by_patient_id': {}})

                self.assertTrue(mock_remove.called)
                self.assertTrue(mock_rename.called)

    def test_promote_retries_on_contention_errno(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            target = insurance_type_cache.get_cache_path(tmpdir)
            with open(target, 'w') as f:
                f.write('{}')
            calls = {'n': 0}
            real_replace = os.replace

            def flaky_replace(src, dst):
                calls['n'] += 1
                if calls['n'] < 3:
                    raise OSError(183, 'exists')
                return real_replace(src, dst)

            with patch('MediLink.insurance_type_cache.os.replace', flaky_replace):
                with patch('MediLink.insurance_type_cache.time.sleep'):
                    insurance_type_cache.save_cache(tmpdir, {'version': 2, 'by_patient_id': {}})
            self.assertGreaterEqual(calls['n'], 3)
            with open(target, 'r') as f:
                self.assertIn('"version"', f.read())

    def test_tmp_path_uses_pid_timestamp_suffix(self):
        seen = []
        real_open = io.open

        def wrapping_open(path, mode='r', encoding=None, **kwargs):
            p = path if isinstance(path, str) else str(path)
            if 'insurance_type_cache.json.tmp.' in p:
                seen.append(p)
            return real_open(path, mode, encoding=encoding, **kwargs)

        with tempfile.TemporaryDirectory() as tmpdir:
            with patch('MediLink.insurance_type_cache.io.open', side_effect=wrapping_open):
                insurance_type_cache.save_cache(tmpdir, {'version': 2, 'by_patient_id': {}})
        self.assertEqual(len(seen), 1)
        self.assertIn('.tmp.', seen[0])

    def test_cleanup_removes_stale_tmp_artifacts(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            stale = os.path.join(tmpdir, 'insurance_type_cache.json.tmp.99999.111')
            with open(stale, 'w') as f:
                f.write('x')
            old_ts = time.time() - 90000
            os.utime(stale, (old_ts, old_ts))
            insurance_type_cache.save_cache(tmpdir, {'version': 2, 'by_patient_id': {}})
            self.assertFalse(os.path.exists(stale))


if __name__ == '__main__':
    unittest.main()
