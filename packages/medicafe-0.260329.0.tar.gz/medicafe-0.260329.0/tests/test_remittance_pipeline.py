# tests/test_remittance_pipeline.py
"""Remittance merge/resolution helpers (Python 3.4+)."""
import os
import sys
import unittest

current_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(current_dir)
medilink_dir = os.path.join(parent_dir, 'MediLink')
if medilink_dir not in sys.path:
    sys.path.insert(0, medilink_dir)

from MediLink_Parser import parse_era_content  # noqa: E402
from MediLink_RemittancePipeline import (  # noqa: E402
    merge_remittance_group,
    group_records_for_merge,
    canonical_to_posting_row,
    resolve_remittance_dict,
    build_crosswalk_lookups,
    normalize_unified_record,
    build_source_meta,
)


class TestMergeRemittanceGroup(unittest.TestCase):
    def test_single_row_has_merge_count(self):
        r = {'claim_number': '1', 'dos': '20250101', 'paid': '10', 'data_source': 'claims_inquiry'}
        m = merge_remittance_group([r])
        self.assertEqual(m.get('merge_source_count'), 1)
        self.assertTrue(m.get('merge_consistent'))

    def test_money_conflict_flag(self):
        rows = [
            {'paid': '10', 'allowed': '0', 'patient_resp': '0', 'status': 'A', 'data_source': 'parsed_file'},
            {'paid': '20', 'allowed': '0', 'patient_resp': '0', 'status': 'A', 'data_source': 'claims_inquiry'},
        ]
        m = merge_remittance_group(rows)
        self.assertTrue(m.get('money_conflict'))
        self.assertFalse(m.get('merge_consistent'))
        self.assertEqual(m.get('merge_source_count'), 2)

    def test_group_records_for_merge(self):
        recs = [
            {'internal_claim_key': 'k1', 'dos': '20250101', 'claim_number': 'x'},
            {'internal_claim_key': 'k1', 'dos': '20250101', 'claim_number': 'y'},
        ]
        g = group_records_for_merge(recs)
        self.assertEqual(len(g), 1)

    def test_merge_file_plus_api_preserves_api_breadcrumbs(self):
        file_row = {
            'claim_number': 'C1',
            'dos': '20250101',
            'paid': '100',
            'data_source': 'parsed_file',
            'processed_date': '',
            'claim_xwalk_data': None,
            'lookup_mode': '',
            'document_refs': None,
        }
        api_row = {
            'claim_number': 'C1',
            'dos': '20250101',
            'paid': '100',
            'data_source': 'claims_inquiry',
            'processed_date': '2025-01-10',
            'claim_xwalk_data': [{'stage': 'x'}],
            'lookup_mode': 'member',
            'document_refs': [{'id': 'd1'}],
        }
        m = merge_remittance_group([file_row, api_row])
        self.assertEqual(m.get('claim_xwalk_data'), [{'stage': 'x'}])
        self.assertEqual(m.get('lookup_mode'), 'member')
        self.assertEqual(m.get('processed_date'), '2025-01-10')
        self.assertEqual(m.get('document_refs'), [{'id': 'd1'}])

    def test_merge_inquiry_processed_date_when_file_has_different_date(self):
        file_row = {
            'claim_number': 'C1',
            'dos': '20250101',
            'paid': '1',
            'data_source': 'parsed_file',
            'processed_date': '20250101',
        }
        api_row = {
            'claim_number': 'C1',
            'dos': '20250101',
            'paid': '1',
            'data_source': 'claims_inquiry',
            'processed_date': '20250115',
        }
        m = merge_remittance_group([file_row, api_row])
        self.assertEqual(m.get('processed_date'), '20250101')
        self.assertEqual(m.get('inquiry_processed_date'), '20250115')
        self.assertTrue(m.get('source_conflict'))

    def test_merge_fills_blank_patient_name_from_api_row(self):
        file_row = {
            'claim_number': 'C1',
            'dos': '20250101',
            'paid': '100',
            'patient_name': '',
            'data_source': 'parsed_file',
        }
        api_row = {
            'claim_number': 'C1',
            'dos': '20250101',
            'paid': '100',
            'patient_name': 'Jane Q. Public',
            'data_source': 'claims_inquiry',
        }
        m = merge_remittance_group([file_row, api_row])
        self.assertEqual(m.get('patient_name'), 'Jane Q. Public')


class TestCanonicalToPostingRow(unittest.TestCase):
    def test_patid_from_internal(self):
        row = {
            'merge_source_count': 1,
            'merge_consistent': True,
            'internal_patid': '12345',
            'dos': '20250101',
            'payer_id': 'p',
            'paid': '1',
            'allowed': '2',
            'patient_resp': '3',
            'status': 'ok',
            'claim_number': 'CN',
        }
        out = canonical_to_posting_row(row)
        self.assertEqual(out['patid'], '12345')
        self.assertEqual(out['source_claim_number'], 'CN')

    def test_posting_row_ignores_legacy_patid_without_internal(self):
        row = {
            'merge_source_count': 1,
            'merge_consistent': True,
            'patid': 'LEGACY999',
            'internal_patid': '',
            'dos': '20250101',
            'payer_id': 'p',
            'paid': '0',
            'allowed': '0',
            'patient_resp': '0',
            'status': 'x',
            'claim_number': 'CN',
        }
        out = canonical_to_posting_row(row)
        self.assertEqual(out['patid'], '')


class TestResolveRemittanceDict(unittest.TestCase):
    def test_non_dict_unchanged(self):
        self.assertEqual(resolve_remittance_dict([], {}), [])

    def test_resolve_via_submitted_claim_number(self):
        lookups = {
            'by_submitted_claim_number': {
                'CLM01': {
                    'internal_patid': '99',
                    'internal_chart': 'C',
                    'claim_key': 'k',
                }
            },
            'by_claim_key': {},
        }
        rec = {'claim_number': 'CLM01', 'dos': '20250101'}
        resolve_remittance_dict(rec, lookups)
        self.assertEqual(rec.get('internal_patid'), '99')
        self.assertEqual(rec.get('match_status'), 'matched_exact')

    def test_resolve_backfills_patient_name_from_crosswalk(self):
        lookups = {
            'by_submitted_claim_number': {
                'CLM01': {
                    'internal_patid': '99',
                    'internal_chart': 'C',
                    'claim_key': 'k',
                    'member_id': 'MID1',
                    'member_first_name': 'Jane',
                    'member_last_name': 'Doe',
                }
            },
            'by_claim_key': {},
        }
        rec = {'claim_number': 'CLM01', 'dos': '20250101', 'patient_name': ''}
        resolve_remittance_dict(rec, lookups)
        self.assertEqual(rec.get('patient_name'), 'Jane Doe')
        self.assertEqual(rec.get('member_id'), 'MID1')

    def test_resolve_preserves_existing_patient_name(self):
        lookups = {
            'by_submitted_claim_number': {
                'CLM01': {
                    'internal_patid': '99',
                    'internal_chart': 'C',
                    'claim_key': 'k',
                    'member_first_name': 'Jane',
                    'member_last_name': 'Doe',
                }
            },
            'by_claim_key': {},
        }
        rec = {'claim_number': 'CLM01', 'dos': '20250101', 'patient_name': 'Source Name'}
        resolve_remittance_dict(rec, lookups)
        self.assertEqual(rec.get('patient_name'), 'Source Name')


class TestEraPatientNameParsing(unittest.TestCase):
    def test_parse_era_patient_name_from_nm1_qc(self):
        content = (
            'TRN*1*12345~'
            'N1*PR*PAYER~'
            'CLP*CLM123*1*100*80*20*12*PATID*PAYERCLM~'
            'NM1*QC*1*DOE*JANE~'
            'AMT*B6*85~'
            'CAS*PR*1*15~'
            'DTM*472*20210102~'
            'SE*8*0001~'
        )
        rows = parse_era_content(content)
        self.assertEqual(rows[0].get('Patient'), 'DOE JANE')


class TestNormalizeUnifiedRecord(unittest.TestCase):
    def test_source_checksum_from_meta(self):
        raw = {
            'Claim #': 'C1',
            'Chart': '',
            'Serv.': '20250101',
            'Payer ID': '',
            'Payer': '',
            'Patient': 'Ann Other',
            'Status': '',
            'Charged': '',
            'Allowed': '',
            'Paid': '',
            'Pt Resp': '',
        }
        meta = build_source_meta(source_checksum='sha1:abc', source_file='f.era')
        row = normalize_unified_record(raw, meta)
        self.assertEqual(row.get('source_checksum'), 'sha1:abc')


class TestBuildCrosswalkLookups(unittest.TestCase):
    def test_empty_root(self):
        m = build_crosswalk_lookups('')
        self.assertIn('by_claim_key', m)
        self.assertIn('by_submitted_claim_number', m)


if __name__ == '__main__':
    unittest.main()
