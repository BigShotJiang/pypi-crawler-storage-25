# -*- coding: utf-8 -*-
"""Tests for per-channel report dedup reservation (MediCafe.error_reporter)."""
from __future__ import print_function

import json
import os
import shutil
import sys
import tempfile
import time
import unittest

REPO_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
if REPO_ROOT not in sys.path:
    sys.path.insert(0, REPO_ROOT)

from MediCafe import error_reporter as er


class TestReportDedupReserve(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.mkdtemp()
        self.state_path = os.path.join(self.tmp, 'diagnostics_state.json')

    def tearDown(self):
        shutil.rmtree(self.tmp, ignore_errors=True)

    def test_per_channel_independent(self):
        a1, _ = er.report_dedup_try_reserve(self.state_path, 'phase_b_pipeline_report', 'keyb', 3600)
        self.assertTrue(a1)
        a2, _ = er.report_dedup_try_reserve(self.state_path, 'phase_f_evidence', 'keyf', 3600)
        self.assertTrue(a2)
        with open(self.state_path, 'r', encoding='utf-8') as f:
            data = json.load(f)
        self.assertEqual(data['report_dedup']['phase_b_pipeline_report']['key'], 'keyb')
        self.assertEqual(data['report_dedup']['phase_f_evidence']['key'], 'keyf')

    def test_same_channel_same_key_suppressed(self):
        er.report_dedup_try_reserve(self.state_path, 'phase_e_pipeline_report', 'same', 3600)
        second, _ = er.report_dedup_try_reserve(self.state_path, 'phase_e_pipeline_report', 'same', 3600)
        self.assertFalse(second)

    def test_release_after_failed_allows_retry(self):
        er.report_dedup_try_reserve(self.state_path, 'phase_f_evidence', 'kf', 3600)
        er.report_dedup_release_if_failed(self.state_path, 'phase_f_evidence', 'kf')
        again, _ = er.report_dedup_try_reserve(self.state_path, 'phase_f_evidence', 'kf', 3600)
        self.assertTrue(again)

    def test_check_report_dedup_channel_aware(self):
        er.report_dedup_try_reserve(self.state_path, 'phase_c_pipeline_report', 'kc', 3600)
        ok_b, _ = er.check_report_dedup(self.state_path, 'kb', 3600, channel='phase_b_pipeline_report')
        self.assertTrue(ok_b)
        ok_c, _ = er.check_report_dedup(self.state_path, 'kc', 3600, channel='phase_c_pipeline_report')
        self.assertFalse(ok_c)

    def test_legacy_global_when_no_report_dedup(self):
        with open(self.state_path, 'w', encoding='utf-8') as f:
            json.dump({
                'last_report_dedup_key': 'legacy',
                'last_report_sent_at_utc': time.strftime(
                    '%Y-%m-%dT%H:%M:%SZ', time.gmtime()
                ),
            }, f)
        dup, _ = er.check_report_dedup(self.state_path, 'legacy', 3600, channel=None)
        self.assertFalse(dup)

    def test_stale_dedup_lock_dead_pid_allows_reserve(self):
        lock_path = self.state_path + '.dedup.lock'
        with open(lock_path, 'w', encoding='utf-8') as f:
            f.write('999999888')
        try:
            os.kill(999999888, 0)
        except OSError:
            pass
        else:
            self.skipTest('pid 999999888 unexpectedly exists')
        allowed, _ = er.report_dedup_try_reserve(
            self.state_path, 'phase_b_pipeline_report', 'after-stale', 3600)
        self.assertTrue(allowed)
        self.assertFalse(os.path.isfile(lock_path))

    def test_stale_dedup_lock_corrupt_old_mtime_allows_reserve(self):
        lock_path = self.state_path + '.dedup.lock'
        with open(lock_path, 'w', encoding='utf-8') as f:
            f.write('not_a_pid')
        old = time.time() - 700
        os.utime(lock_path, (old, old))
        allowed, _ = er.report_dedup_try_reserve(
            self.state_path, 'phase_c_pipeline_report', 'after-corrupt', 3600)
        self.assertTrue(allowed)

    def test_stale_dedup_lock_old_mtime_steals_despite_live_pid(self):
        """Ancient lock + PID still alive (e.g. OS reused pid): must not block forever."""
        lock_path = self.state_path + '.dedup.lock'
        with open(lock_path, 'w', encoding='utf-8') as f:
            f.write(str(os.getpid()))
        old = time.time() - 700
        os.utime(lock_path, (old, old))
        allowed, _ = er.report_dedup_try_reserve(
            self.state_path, 'phase_d_pipeline_report', 'after-pid-reuse', 3600)
        self.assertTrue(allowed)
        self.assertFalse(os.path.isfile(lock_path))


if __name__ == '__main__':
    unittest.main()
