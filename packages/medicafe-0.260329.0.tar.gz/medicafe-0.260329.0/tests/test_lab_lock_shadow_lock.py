# -*- coding: utf-8 -*-
"""Tests for lab shadow.lock acquisition (orphan/corrupt recovery)."""
from __future__ import print_function

import os
import shutil
import sys
import tempfile
import unittest

REPO_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
UM = os.path.join(REPO_ROOT, 'scripts', 'unified_model')
if UM not in sys.path:
    sys.path.insert(0, UM)

import lab_lock


class TestShadowLockRecoverCorrupt(unittest.TestCase):
    def setUp(self):
        self.lab = tempfile.mkdtemp()

    def tearDown(self):
        shutil.rmtree(self.lab, ignore_errors=True)

    def test_acquire_after_empty_lock_file(self):
        lock_p = os.path.join(self.lab, 'shadow.lock')
        with open(lock_p, 'w') as f:
            f.write('')
        self.assertTrue(lab_lock.acquire_lock(self.lab))
        try:
            self.assertTrue(os.path.exists(lock_p))
        finally:
            lab_lock.release_lock(self.lab)

    def test_acquire_after_lock_missing_pid_line(self):
        lock_p = os.path.join(self.lab, 'shadow.lock')
        with open(lock_p, 'w') as f:
            f.write('heartbeat_at_utc=2020-01-01T00:00:00Z\n')
        self.assertTrue(lab_lock.acquire_lock(self.lab))
        try:
            self.assertTrue(os.path.exists(lock_p))
        finally:
            lab_lock.release_lock(self.lab)


if __name__ == '__main__':
    unittest.main()
