# tests/test_remittance_backfill.py
"""
Unit tests for MediCafe.remittance_backfill.
Python 3.4.4 compatible.
"""
from contextlib import redirect_stdout
from io import StringIO
import hashlib
import json
import os
import sys
import tempfile
import unittest

current_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(current_dir)
medilink_dir = os.path.join(parent_dir, 'MediLink')
if parent_dir not in sys.path:
    sys.path.insert(0, parent_dir)
if medilink_dir not in sys.path:
    sys.path.insert(0, medilink_dir)

from MediCafe.remittance_backfill import (
    _backfill_source_facts,
    _ledger_unique_entries,
    run_backfill,
)


class TestBackfillSourceFacts(unittest.TestCase):
    def test_claims_inquiry_row_normalizes_dos_and_sets_sparse_keys(self):
        rec = {
            'data_source': 'claims_inquiry',
            'dos': '2025-01-01',
            'processed_date': None,
        }
        _backfill_source_facts(rec)
        self.assertEqual(rec.get('dos'), '20250101')
        self.assertEqual(rec.get('processed_date'), '')
        self.assertEqual(rec.get('lookup_mode'), '')
        self.assertIsNone(rec.get('claim_xwalk_data'))
        self.assertIsNone(rec.get('document_refs'))


class TestRunBackfill(unittest.TestCase):
    def test_emit_fn_collects_output_without_redirecting_process_streams(self):
        with tempfile.TemporaryDirectory() as storage:
            parsed_path = os.path.join(storage, 'remittance_parsed.jsonl')
            with open(parsed_path, 'w') as f:
                f.write(json.dumps({
                    'claim_number': 'CLM01',
                    'data_source': 'claims_inquiry',
                    'dos': '2025-01-01',
                    'processed_date': None,
                }) + '\n')

            lines = []

            def capture(message, level='INFO'):
                lines.append((level, message))

            rc = run_backfill(storage, None, dry_run=True, log_fn=capture)

            self.assertEqual(rc, 0)
            self.assertTrue(lines)
            rendered = "\n".join(msg for _level, msg in lines)
            self.assertIn('No remittance_file_ledger.jsonl (or empty); row-only crosswalk backfill.', rendered)
            self.assertIn('Dry-run: would rewrite 1 line(s)', rendered)

    def test_dry_run_leaves_jsonl_unchanged(self):
        with tempfile.TemporaryDirectory() as storage:
            parsed_path = os.path.join(storage, 'remittance_parsed.jsonl')
            original_line = json.dumps({
                'claim_number': 'CLM01',
                'data_source': 'claims_inquiry',
                'dos': '2025-01-01',
                'processed_date': None,
            })
            with open(parsed_path, 'w') as f:
                f.write(original_line + '\n')

            with redirect_stdout(StringIO()):
                rc = run_backfill(storage, None, dry_run=True)

            self.assertEqual(rc, 0)
            with open(parsed_path, 'r') as f:
                self.assertEqual(f.read(), original_line + '\n')
            backups = [n for n in os.listdir(storage) if '.bak.' in n]
            self.assertEqual(backups, [])

    def test_rewrite_creates_backup_and_resolves_against_crosswalk(self):
        with tempfile.TemporaryDirectory() as tmp:
            storage = os.path.join(tmp, 'storage')
            receipts = os.path.join(tmp, 'receipts')
            os.makedirs(storage)
            os.makedirs(receipts)

            parsed_path = os.path.join(storage, 'remittance_parsed.jsonl')
            with open(parsed_path, 'w') as f:
                f.write(json.dumps({
                    'claim_number': 'CLM01',
                    'payer_id': '62308',
                    'data_source': 'claims_inquiry',
                    'dos': '2025-01-01',
                    'processed_date': None,
                    'patient_name': '',
                }) + '\n')

            index_path = os.path.join(receipts, 'submission_index.jsonl')
            with open(index_path, 'w') as f:
                f.write(json.dumps({
                    'record_type': 'submission',
                    'submitted_claim_number': 'CLM01',
                    'claim_key': 'ck1',
                    'internal_patid': '12345',
                    'internal_chart': 'CHART1',
                    'patient_id': 'CHART1',
                    'payer_id': '62308',
                    'dos': '20250101',
                    'status': 'success',
                    'member_first_name': 'Jane',
                    'member_last_name': 'Doe',
                }) + '\n')

            with redirect_stdout(StringIO()):
                rc = run_backfill(storage, receipts, dry_run=False)

            self.assertEqual(rc, 0)
            with open(parsed_path, 'r') as f:
                rows = [json.loads(line) for line in f if line.strip()]
            self.assertEqual(len(rows), 1)
            row = rows[0]
            self.assertEqual(row.get('schema_version'), 1)
            self.assertEqual(row.get('dos'), '20250101')
            self.assertEqual(row.get('processed_date'), '')
            self.assertEqual(row.get('patient_name'), 'Jane Doe')
            self.assertEqual(row.get('internal_patid'), '12345')
            self.assertEqual(row.get('internal_chart'), 'CHART1')
            self.assertEqual(row.get('internal_claim_key'), 'ck1')
            self.assertEqual(row.get('match_status'), 'matched_exact')
            self.assertEqual(row.get('match_basis'), 'submitted_claim_number')
            self.assertIsNone(row.get('claim_xwalk_data'))
            self.assertIsNone(row.get('document_refs'))
            self.assertEqual(row.get('lookup_mode'), '')

            backup_names = [n for n in os.listdir(storage) if n.startswith('remittance_parsed.jsonl.bak.')]
            self.assertEqual(len(backup_names), 1)
            self.assertFalse(os.path.exists(parsed_path + '.new'))

    def test_ledger_replay_restores_patient_name_from_era(self):
        era_body = (
            'TRN*1*12345~'
            'N1*PR*PAYER~'
            'CLP*CLM123*1*100*80*20*12*PATID*PAYERCLM~'
            'NM1*QC*1*DOE*JANE~'
            'AMT*B6*85~'
            'CAS*PR*1*15~'
            'DTM*472*20210102~'
            'SE*8*0001~'
        )
        with tempfile.TemporaryDirectory() as tmp:
            storage = os.path.join(tmp, 'storage')
            os.makedirs(storage)
            era_path = os.path.join(storage, 'sample.era')
            with open(era_path, 'w') as ef:
                ef.write(era_body)

            ledger_path = os.path.join(storage, 'remittance_file_ledger.jsonl')
            with open(ledger_path, 'w') as lf:
                lf.write(json.dumps({
                    'filename': 'sample.era',
                    'path': era_path,
                    'endpoint': 'ep1',
                    'file_type': 'ERA',
                    'mtime': 1700000000,
                    'checksum': '',
                    'records_count': 1,
                }) + '\n')

            parsed_path = os.path.join(storage, 'remittance_parsed.jsonl')
            with open(parsed_path, 'w') as pf:
                pf.write(json.dumps({
                    'claim_number': 'CI1',
                    'data_source': 'claims_inquiry',
                    'dos': '2025-01-01',
                    'patient_name': '',
                    'processed_date': None,
                }) + '\n')

            with redirect_stdout(StringIO()):
                rc = run_backfill(storage, None, dry_run=False)

            self.assertEqual(rc, 0)
            with open(parsed_path, 'r') as f:
                rows = [json.loads(line) for line in f if line.strip()]
            self.assertEqual(len(rows), 2)
            era_rows = [r for r in rows if r.get('claim_number') == 'CLM123']
            self.assertEqual(len(era_rows), 1)
            self.assertIn('DOE', era_rows[0].get('patient_name', ''))
            self.assertIn('JANE', era_rows[0].get('patient_name', ''))

    def test_missing_ledger_path_keeps_claims_inquiry_and_reports_missing(self):
        with tempfile.TemporaryDirectory() as tmp:
            storage = os.path.join(tmp, 'storage')
            os.makedirs(storage)
            bad_path = os.path.join(storage, 'nope.era')
            ledger_path = os.path.join(storage, 'remittance_file_ledger.jsonl')
            with open(ledger_path, 'w') as lf:
                lf.write(json.dumps({
                    'filename': 'nope.era',
                    'path': bad_path,
                    'endpoint': '',
                    'file_type': 'ERA',
                    'mtime': 1,
                    'checksum': '',
                    'records_count': 0,
                }) + '\n')

            parsed_path = os.path.join(storage, 'remittance_parsed.jsonl')
            with open(parsed_path, 'w') as pf:
                pf.write(json.dumps({
                    'claim_number': 'KEEP',
                    'data_source': 'claims_inquiry',
                    'dos': '2025-01-01',
                    'processed_date': None,
                }) + '\n')
                pf.write(json.dumps({
                    'claim_number': 'PF1',
                    'data_source': 'parsed_file',
                    'dos': '20250101',
                    'source_file': 'nope.era',
                    'source_checksum': '',
                }) + '\n')

            buf = StringIO()
            with redirect_stdout(buf):
                rc = run_backfill(storage, None, dry_run=False)
            self.assertEqual(rc, 0)
            out = buf.getvalue()
            self.assertIn('ledger_entries_missing_on_disk=1', out)
            self.assertIn('parsed_file_rows_preserved_unreplayed=1', out)
            with open(parsed_path, 'r') as f:
                rows = [json.loads(line) for line in f if line.strip()]
            self.assertEqual(len(rows), 2)
            claims = [r for r in rows if r.get('claim_number') == 'KEEP']
            self.assertEqual(len(claims), 1)
            preserved = [r for r in rows if r.get('claim_number') == 'PF1']
            self.assertEqual(len(preserved), 1)
            self.assertTrue(preserved[0].get('replay_preserved_unreplayed'))

    def test_ledger_duplicate_basename_two_paths_both_replayed(self):
        era_body = (
            'TRN*1*1~N1*PR*P~CLP*A*1*1*1*1*1*1*1~NM1*QC*1*AA*BB~AMT*B6*1~SE*1*1~'
        )
        era_body_b = (
            'TRN*1*2~N1*PR*P~CLP*B*1*1*1*1*1*1*1~NM1*QC*1*CC*DD~AMT*B6*1~SE*1*1~'
        )
        with tempfile.TemporaryDirectory() as tmp:
            storage = os.path.join(tmp, 'storage')
            d1 = os.path.join(storage, 'd1')
            d2 = os.path.join(storage, 'd2')
            os.makedirs(d1)
            os.makedirs(d2)
            p1 = os.path.join(d1, 'same.era')
            p2 = os.path.join(d2, 'same.era')
            with open(p1, 'w') as f:
                f.write(era_body)
            with open(p2, 'w') as f:
                f.write(era_body_b)

            ledger_path = os.path.join(storage, 'remittance_file_ledger.jsonl')
            with open(ledger_path, 'w') as lf:
                lf.write(json.dumps({
                    'filename': 'same.era', 'path': p1, 'endpoint': '', 'file_type': 'ERA',
                    'mtime': 1, 'checksum': '', 'records_count': 1,
                }) + '\n')
                lf.write(json.dumps({
                    'filename': 'same.era', 'path': p2, 'endpoint': '', 'file_type': 'ERA',
                    'mtime': 2, 'checksum': '', 'records_count': 1,
                }) + '\n')

            parsed_path = os.path.join(storage, 'remittance_parsed.jsonl')
            with open(parsed_path, 'w') as pf:
                pf.write(json.dumps({'claim_number': 'X', 'data_source': 'claims_inquiry', 'dos': '2025-01-01', 'processed_date': None}) + '\n')

            with redirect_stdout(StringIO()):
                rc = run_backfill(storage, None, dry_run=False)
            self.assertEqual(rc, 0)
            with open(parsed_path, 'r') as f:
                rows = [json.loads(line) for line in f if line.strip()]
            claims = [r.get('claim_number') for r in rows]
            self.assertIn('A', claims)
            self.assertIn('B', claims)

    def test_ledger_unique_entries_dedupes_identical_path_checksum_mtime(self):
        p = '/tmp/foo.era'
        ents = [
            {'path': p, 'mtime': 1, 'checksum': 'sha1:abc'},
            {'path': p, 'mtime': 1, 'checksum': 'sha1:abc'},
        ]
        u = _ledger_unique_entries(ents)
        self.assertEqual(len(u), 1)

    def test_ledger_unique_entries_keeps_same_path_different_mtime(self):
        p = '/tmp/foo.era'
        ents = [
            {'path': p, 'mtime': 1, 'checksum': ''},
            {'path': p, 'mtime': 99, 'checksum': ''},
        ]
        u = _ledger_unique_entries(ents)
        self.assertEqual(len(u), 2)

    def test_ledger_unique_entries_keeps_same_path_different_checksum(self):
        p = '/tmp/foo.era'
        ents = [
            {'path': p, 'mtime': 1, 'checksum': 'sha1:aaa'},
            {'path': p, 'mtime': 1, 'checksum': 'sha1:bbb'},
        ]
        u = _ledger_unique_entries(ents)
        self.assertEqual(len(u), 2)

    def test_ledger_rebuild_without_parsed_jsonl_creates_file(self):
        era_body = (
            'TRN*1*1~N1*PR*P~CLP*Z9*1*1*1*1*1*1*1~NM1*QC*1*XX*YY~AMT*B6*1~SE*1*1~'
        )
        with tempfile.TemporaryDirectory() as tmp:
            storage = os.path.join(tmp, 'storage')
            os.makedirs(storage)
            era_path = os.path.join(storage, 'solo.era')
            with open(era_path, 'w') as f:
                f.write(era_body)
            ledger_path = os.path.join(storage, 'remittance_file_ledger.jsonl')
            with open(ledger_path, 'w') as lf:
                lf.write(json.dumps({
                    'filename': 'solo.era',
                    'path': era_path,
                    'endpoint': '',
                    'file_type': 'ERA',
                    'mtime': 1,
                    'checksum': '',
                    'records_count': 1,
                }) + '\n')
            parsed_path = os.path.join(storage, 'remittance_parsed.jsonl')
            self.assertFalse(os.path.isfile(parsed_path))
            buf = StringIO()
            with redirect_stdout(buf):
                rc = run_backfill(storage, None, dry_run=False)
            self.assertEqual(rc, 0)
            self.assertTrue(os.path.isfile(parsed_path))
            out = buf.getvalue()
            self.assertIn('files_replayed=1', out)
            self.assertIn('rows_regenerated=1', out)
            self.assertIn('no prior remittance_parsed.jsonl to backup', out)

    def test_ledger_rebuild_with_empty_parsed_file(self):
        era_body = (
            'TRN*1*1~N1*PR*P~CLP*Z8*1*1*1*1*1*1*1~NM1*QC*1*AA*BB~AMT*B6*1~SE*1*1~'
        )
        with tempfile.TemporaryDirectory() as tmp:
            storage = os.path.join(tmp, 'storage')
            os.makedirs(storage)
            era_path = os.path.join(storage, 'emptyp.era')
            with open(era_path, 'w') as f:
                f.write(era_body)
            ledger_path = os.path.join(storage, 'remittance_file_ledger.jsonl')
            with open(ledger_path, 'w') as lf:
                lf.write(json.dumps({
                    'filename': 'emptyp.era',
                    'path': era_path,
                    'endpoint': '',
                    'file_type': 'ERA',
                    'mtime': 1,
                    'checksum': '',
                    'records_count': 1,
                }) + '\n')
            parsed_path = os.path.join(storage, 'remittance_parsed.jsonl')
            with open(parsed_path, 'w') as pf:
                pass
            with redirect_stdout(StringIO()):
                rc = run_backfill(storage, None, dry_run=False)
            self.assertEqual(rc, 0)
            with open(parsed_path, 'r') as f:
                rows = [json.loads(line) for line in f if line.strip()]
            self.assertEqual(len(rows), 1)
            self.assertEqual(rows[0].get('claim_number'), 'Z8')

    def test_preserved_parsed_file_when_other_file_replayed(self):
        era_body = (
            'TRN*1*1~N1*PR*P~CLP*RA*1*1*1*1*1*1*1~NM1*QC*1*AA*BB~AMT*B6*1~SE*1*1~'
        )
        with tempfile.TemporaryDirectory() as tmp:
            storage = os.path.join(tmp, 'storage')
            os.makedirs(storage)
            era_path = os.path.join(storage, 'a.era')
            with open(era_path, 'w') as f:
                f.write(era_body)
            ledger_path = os.path.join(storage, 'remittance_file_ledger.jsonl')
            with open(ledger_path, 'w') as lf:
                lf.write(json.dumps({
                    'filename': 'a.era',
                    'path': era_path,
                    'endpoint': '',
                    'file_type': 'ERA',
                    'mtime': 1,
                    'checksum': '',
                    'records_count': 1,
                }) + '\n')
            parsed_path = os.path.join(storage, 'remittance_parsed.jsonl')
            with open(parsed_path, 'w') as pf:
                pf.write(json.dumps({
                    'claim_number': 'RB',
                    'data_source': 'parsed_file',
                    'dos': '20250101',
                    'source_file': 'b.era',
                    'source_checksum': '',
                }) + '\n')
            buf = StringIO()
            with redirect_stdout(buf):
                rc = run_backfill(storage, None, dry_run=False)
            self.assertEqual(rc, 0)
            self.assertIn('parsed_file_rows_preserved_unreplayed=1', buf.getvalue())
            with open(parsed_path, 'r') as f:
                rows = [json.loads(line) for line in f if line.strip()]
            rbs = [r for r in rows if r.get('claim_number') == 'RB']
            self.assertEqual(len(rbs), 1)
            self.assertTrue(rbs[0].get('replay_preserved_unreplayed'))
            self.assertTrue(any(r.get('claim_number') == 'RA' for r in rows))

    def test_legacy_row_without_checksum_superseded_when_fingerprint_matches_replay(self):
        era_body = (
            'TRN*1*12345~'
            'N1*PR*PAYER~'
            'CLP*SUPLEG01*1*100*80*20*12*PATID*PAYERCLM~'
            'NM1*QC*1*DOE*JANE~'
            'AMT*B6*85~'
            'CAS*PR*1*15~'
            'DTM*472*20210102~'
            'SE*8*0001~'
        )
        ts = 1700000000
        with tempfile.TemporaryDirectory() as tmp:
            storage = os.path.join(tmp, 'storage')
            os.makedirs(storage)
            era_path = os.path.join(storage, 'sample.era')
            with open(era_path, 'w') as ef:
                ef.write(era_body)
            ledger_path = os.path.join(storage, 'remittance_file_ledger.jsonl')
            with open(ledger_path, 'w') as lf:
                lf.write(json.dumps({
                    'filename': 'sample.era',
                    'path': era_path,
                    'endpoint': 'ep1',
                    'file_type': 'ERA',
                    'mtime': ts,
                    'checksum': '',
                    'records_count': 1,
                }) + '\n')
            parsed_path = os.path.join(storage, 'remittance_parsed.jsonl')
            with open(parsed_path, 'w') as pf:
                pf.write(json.dumps({
                    'claim_number': 'SUPLEG01',
                    'data_source': 'parsed_file',
                    'dos': '20210102',
                    'source_file': 'sample.era',
                    'source_endpoint': 'ep1',
                    'source_checksum': '',
                    'source_timestamp': ts,
                    'patient_name': 'Unknown',
                }) + '\n')
            buf = StringIO()
            with redirect_stdout(buf):
                rc = run_backfill(storage, None, dry_run=False)
            self.assertEqual(rc, 0)
            self.assertIn('parsed_file_rows_superseded_by_replay=1', buf.getvalue())
            with open(parsed_path, 'r') as f:
                rows = [json.loads(line) for line in f if line.strip()]
            self.assertEqual(len(rows), 1)
            self.assertEqual(rows[0].get('claim_number'), 'SUPLEG01')
            self.assertNotEqual(rows[0].get('patient_name'), 'Unknown')

    def test_legacy_row_without_checksum_preserved_when_claim_differs(self):
        era_body = (
            'TRN*1*12345~'
            'N1*PR*PAYER~'
            'CLP*DIFFLEG01*1*100*80*20*12*PATID*PAYERCLM~'
            'NM1*QC*1*DOE*JANE~'
            'AMT*B6*85~'
            'CAS*PR*1*15~'
            'DTM*472*20210102~'
            'SE*8*0001~'
        )
        ts = 1700000000
        with tempfile.TemporaryDirectory() as tmp:
            storage = os.path.join(tmp, 'storage')
            os.makedirs(storage)
            era_path = os.path.join(storage, 'sample.era')
            with open(era_path, 'w') as ef:
                ef.write(era_body)
            ledger_path = os.path.join(storage, 'remittance_file_ledger.jsonl')
            with open(ledger_path, 'w') as lf:
                lf.write(json.dumps({
                    'filename': 'sample.era',
                    'path': era_path,
                    'endpoint': 'ep1',
                    'file_type': 'ERA',
                    'mtime': ts,
                    'checksum': '',
                    'records_count': 1,
                }) + '\n')
            parsed_path = os.path.join(storage, 'remittance_parsed.jsonl')
            with open(parsed_path, 'w') as pf:
                pf.write(json.dumps({
                    'claim_number': 'OTHER999',
                    'data_source': 'parsed_file',
                    'dos': '20210102',
                    'source_file': 'sample.era',
                    'source_endpoint': 'ep1',
                    'source_checksum': '',
                    'source_timestamp': ts,
                }) + '\n')
            buf = StringIO()
            with redirect_stdout(buf):
                rc = run_backfill(storage, None, dry_run=False)
            self.assertEqual(rc, 0)
            self.assertIn('parsed_file_rows_preserved_unreplayed=1', buf.getvalue())
            with open(parsed_path, 'r') as f:
                rows = [json.loads(line) for line in f if line.strip()]
            self.assertEqual(len(rows), 2)
            preserved = [r for r in rows if r.get('claim_number') == 'OTHER999']
            self.assertEqual(len(preserved), 1)
            self.assertTrue(preserved[0].get('replay_preserved_unreplayed'))

    def test_supersession_scoped_by_endpoint(self):
        era_body = (
            'TRN*1*12345~'
            'N1*PR*PAYER~'
            'CLP*SCOPED01*1*100*80*20*12*PATID*PAYERCLM~'
            'NM1*QC*1*DOE*JANE~'
            'AMT*B6*85~'
            'CAS*PR*1*15~'
            'DTM*472*20210102~'
            'SE*8*0001~'
        )
        ts = 1700000000
        with tempfile.TemporaryDirectory() as tmp:
            storage = os.path.join(tmp, 'storage')
            os.makedirs(storage)
            era_path = os.path.join(storage, 'scoped.era')
            with open(era_path, 'w') as ef:
                ef.write(era_body)
            with open(era_path, 'rb') as bf:
                h = hashlib.sha1()
                h.update(bf.read())
                disk_ck = 'sha1:' + h.hexdigest()
            ledger_path = os.path.join(storage, 'remittance_file_ledger.jsonl')
            with open(ledger_path, 'w') as lf:
                lf.write(json.dumps({
                    'filename': 'scoped.era',
                    'path': era_path,
                    'endpoint': 'epA',
                    'file_type': 'ERA',
                    'mtime': ts,
                    'checksum': disk_ck,
                    'records_count': 1,
                }) + '\n')
            parsed_path = os.path.join(storage, 'remittance_parsed.jsonl')
            with open(parsed_path, 'w') as pf:
                pf.write(json.dumps({
                    'claim_number': 'SCOPED01',
                    'data_source': 'parsed_file',
                    'dos': '20210102',
                    'source_file': 'scoped.era',
                    'source_endpoint': 'epB',
                    'source_checksum': disk_ck,
                    'source_timestamp': ts,
                }) + '\n')
            buf = StringIO()
            with redirect_stdout(buf):
                rc = run_backfill(storage, None, dry_run=False)
            self.assertEqual(rc, 0)
            self.assertIn('parsed_file_rows_preserved_unreplayed=1', buf.getvalue())
            with open(parsed_path, 'r') as f:
                rows = [json.loads(line) for line in f if line.strip()]
            epb = [r for r in rows if r.get('source_endpoint') == 'epB']
            self.assertEqual(len(epb), 1)
            self.assertTrue(epb[0].get('replay_preserved_unreplayed'))

    def test_legacy_superseded_via_payer_claim_only(self):
        # 277: Claim # from TRN*2; payer_claim_number from REF*1K*
        r277 = (
            'TRN*2*SUBINT01~'
            'REF*1K*PAYONLY88~'
            'DTP*472*D8*20210102~'
            'STC*A1~'
            'NM1*QC*1*DOE*JANE~'
        )
        ts = 1700000001
        with tempfile.TemporaryDirectory() as tmp:
            storage = os.path.join(tmp, 'storage')
            os.makedirs(storage)
            path_277 = os.path.join(storage, 'payer.277')
            with open(path_277, 'w') as wf:
                wf.write(r277)
            ledger_path = os.path.join(storage, 'remittance_file_ledger.jsonl')
            with open(ledger_path, 'w') as lf:
                lf.write(json.dumps({
                    'filename': 'payer.277',
                    'path': path_277,
                    'endpoint': 'ep1',
                    'file_type': '277',
                    'mtime': ts,
                    'checksum': '',
                    'records_count': 1,
                }) + '\n')
            parsed_path = os.path.join(storage, 'remittance_parsed.jsonl')
            with open(parsed_path, 'w') as pf:
                pf.write(json.dumps({
                    'claim_number': '',
                    'payer_claim_number': 'PAYONLY88',
                    'data_source': 'parsed_file',
                    'dos': '20210102',
                    'source_file': 'payer.277',
                    'source_endpoint': 'ep1',
                    'source_checksum': '',
                    'source_timestamp': ts,
                }) + '\n')
            buf = StringIO()
            with redirect_stdout(buf):
                rc = run_backfill(storage, None, dry_run=False)
            self.assertEqual(rc, 0)
            self.assertIn('parsed_file_rows_superseded_by_replay=1', buf.getvalue())
            with open(parsed_path, 'r') as f:
                rows = [json.loads(line) for line in f if line.strip()]
            self.assertEqual(len(rows), 1)
            self.assertEqual(rows[0].get('payer_claim_number'), 'PAYONLY88')
            self.assertEqual(rows[0].get('claim_number'), 'SUBINT01')

    def test_legacy_fingerprint_preserved_when_timestamps_both_set_and_differ(self):
        era_body = (
            'TRN*1*12345~'
            'N1*PR*PAYER~'
            'CLP*TSLEG01*1*100*80*20*12*PATID*PAYERCLM~'
            'NM1*QC*1*DOE*JANE~'
            'AMT*B6*85~'
            'CAS*PR*1*15~'
            'DTM*472*20210102~'
            'SE*8*0001~'
        )
        replay_ts = 1700000000
        legacy_ts = 1600000000
        with tempfile.TemporaryDirectory() as tmp:
            storage = os.path.join(tmp, 'storage')
            os.makedirs(storage)
            era_path = os.path.join(storage, 'ts.era')
            with open(era_path, 'w') as ef:
                ef.write(era_body)
            ledger_path = os.path.join(storage, 'remittance_file_ledger.jsonl')
            with open(ledger_path, 'w') as lf:
                lf.write(json.dumps({
                    'filename': 'ts.era',
                    'path': era_path,
                    'endpoint': 'ep1',
                    'file_type': 'ERA',
                    'mtime': replay_ts,
                    'checksum': '',
                    'records_count': 1,
                }) + '\n')
            parsed_path = os.path.join(storage, 'remittance_parsed.jsonl')
            with open(parsed_path, 'w') as pf:
                pf.write(json.dumps({
                    'claim_number': 'TSLEG01',
                    'data_source': 'parsed_file',
                    'dos': '20210102',
                    'source_file': 'ts.era',
                    'source_endpoint': 'ep1',
                    'source_checksum': '',
                    'source_timestamp': legacy_ts,
                    'patient_name': 'Stale',
                }) + '\n')
            buf = StringIO()
            with redirect_stdout(buf):
                rc = run_backfill(storage, None, dry_run=False)
            self.assertEqual(rc, 0)
            self.assertIn('parsed_file_rows_preserved_unreplayed=1', buf.getvalue())
            with open(parsed_path, 'r') as f:
                rows = [json.loads(line) for line in f if line.strip()]
            self.assertEqual(len(rows), 2)
            stale = [r for r in rows if r.get('patient_name') == 'Stale']
            self.assertEqual(len(stale), 1)
            self.assertTrue(stale[0].get('replay_preserved_unreplayed'))

    def test_ledger_checksum_mismatch_skips_replay(self):
        era_body = (
            'TRN*1*1~N1*PR*P~CLP*MC*1*1*1*1*1*1*1~NM1*QC*1*AA*BB~AMT*B6*1~SE*1*1~'
        )
        with tempfile.TemporaryDirectory() as tmp:
            storage = os.path.join(tmp, 'storage')
            os.makedirs(storage)
            era_path = os.path.join(storage, 'chk.era')
            with open(era_path, 'w') as f:
                f.write(era_body)
            ledger_path = os.path.join(storage, 'remittance_file_ledger.jsonl')
            with open(ledger_path, 'w') as lf:
                lf.write(json.dumps({
                    'filename': 'chk.era',
                    'path': era_path,
                    'endpoint': '',
                    'file_type': 'ERA',
                    'mtime': 1,
                    'checksum': 'sha1:0000000000000000000000000000000000000000',
                    'records_count': 1,
                }) + '\n')
            parsed_path = os.path.join(storage, 'remittance_parsed.jsonl')
            with open(parsed_path, 'w') as pf:
                pf.write(json.dumps({
                    'claim_number': 'OLD',
                    'data_source': 'parsed_file',
                    'dos': '20250101',
                    'source_file': 'chk.era',
                    'source_checksum': 'sha1:0000000000000000000000000000000000000000',
                }) + '\n')
            buf = StringIO()
            with redirect_stdout(buf):
                rc = run_backfill(storage, None, dry_run=False)
            self.assertEqual(rc, 0)
            self.assertIn('ledger_file_checksum_mismatch=1', buf.getvalue())
            self.assertIn('files_replayed=0', buf.getvalue())
            with open(parsed_path, 'r') as f:
                rows = [json.loads(line) for line in f if line.strip()]
            self.assertEqual(len(rows), 1)
            self.assertEqual(rows[0].get('claim_number'), 'OLD')
            self.assertTrue(rows[0].get('replay_preserved_unreplayed'))


if __name__ == '__main__':
    unittest.main()
