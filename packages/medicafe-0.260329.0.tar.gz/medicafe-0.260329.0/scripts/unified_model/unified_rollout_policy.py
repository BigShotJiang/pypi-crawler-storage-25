#!/usr/bin/env python
"""
Unified relational model rollout policy (Theme 5).

Single source of truth for:
- Phase D invalid external patient ID ratio thresholds (used by migration audit).
- Automated Phase D entity scope: v1 (patient-only) vs v2 (multi-entity upserts).

XP-compatible: Python 3.4.4, stdlib only.
"""
from __future__ import print_function

import json
import os

# --- D-032: audit metric thresholds (mirrored into audit_migration_health.THRESHOLD_PROFILES) ---
PHASE_D_INVALID_EXTERNAL_ID_SKIP_RATIO_PASS_MAX = 0.02
PHASE_D_INVALID_EXTERNAL_ID_SKIP_RATIO_WARN_MAX = 0.05

# --- Gates for selecting v2 entity upserts (stricter than default audit pass in places) ---
# TODO(theme5): After real-lab feedback, revisit V2_GATE_* and projection coverage floor inside
# resolve_phase_d_entity_scope. Keep audit_migration_health.THRESHOLD_PROFILES in sync with
# PHASE_D_INVALID_EXTERNAL_ID_SKIP_RATIO_* above (decision D-032).
V2_ENTITY_UPSERTS_ENABLED = True
V2_GATE_MAX_REJECT_RATIO = 0.10
V2_GATE_MAX_INVALID_EXTERNAL_ID_SKIP_RATIO = 0.02
V2_REQUIRES_CONTRACT_PARITY_PASS = True
V2_REQUIRES_PIPELINE_OK = True

INTERNAL_PHASE_D_ENTITY_SCOPE_ENV = "MEDICAFE_INTERNAL_PHASE_D_ENTITY_SCOPE"
BREAK_GLASS_FORCE_V1_ENV = "MEDICAFE_ROLLOUT_FORCE_V1"


def _truthy_env(name):
    v = str(os.environ.get(name, "") or "").strip().lower()
    return v in ("1", "true", "yes", "on")


def load_json(path):
    if not path or not os.path.exists(path):
        return {}
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except (ValueError, IOError, OSError, TypeError):
        return {}


def latest_report_path(reports_dir, prefix, suffixes=(".json",)):
    """Return (path, run_id) for newest matching report, or ("", "")."""
    if not reports_dir or not os.path.isdir(reports_dir):
        return "", ""
    best = None
    best_mtime = None
    best_rid = ""
    try:
        names = os.listdir(reports_dir)
    except (OSError, IOError):
        return "", ""
    for name in names:
        if not name.startswith(prefix):
            continue
        ok = False
        for suf in suffixes:
            if name.endswith(suf):
                ok = True
                break
        if not ok:
            continue
        full = os.path.join(reports_dir, name)
        try:
            st = os.stat(full)
            mt = st.st_mtime
        except (OSError, IOError):
            continue
        if best_mtime is None or mt >= best_mtime:
            best_mtime = mt
            best = full
            base = name[len(prefix) :]
            for suf in suffixes:
                if base.endswith(suf):
                    base = base[: -len(suf)]
                    break
            best_rid = base
    return (best or "", best_rid or "")


def compute_phase_d_invalid_external_id_skip_ratio(qa_summary):
    """
    D-032: patient_invalid_external_id / max(rows_selected, 1).
    qa_summary is dict from qa_canonical_summary_*.json.
    """
    if not isinstance(qa_summary, dict):
        return None
    rows = qa_summary.get("rows_selected")
    skips = (qa_summary.get("constraint_skip_counts") or {}).get("patient_invalid_external_id")
    if not isinstance(rows, int) or rows < 0:
        return None
    if skips is None:
        skips = 0
    if not isinstance(skips, int) or skips < 0:
        return None
    return float(skips) / float(max(rows, 1))


def compute_phase_d_reject_ratio(qa_summary):
    if not isinstance(qa_summary, dict):
        return None
    rows = qa_summary.get("rows_selected")
    rej = qa_summary.get("qa_reject_count")
    if not isinstance(rows, int) or rows < 0:
        return None
    if not isinstance(rej, int) or rej < 0:
        return None
    return float(rej) / float(max(rows, 1))


def resolve_phase_d_entity_scope(lab_dir):
    """
    Return (scope, reasons) where scope is 'v1' or 'v2'.
    Reads lab/reports and diagnostics_state.json only (no network).
    """
    reasons = []
    if _truthy_env(BREAK_GLASS_FORCE_V1_ENV):
        return ("v1", ["break_glass_force_v1_env"])

    if not V2_ENTITY_UPSERTS_ENABLED:
        return ("v1", ["v2_entity_upserts_disabled_in_policy"])

    state_path = os.path.join(lab_dir, "diagnostics_state.json")
    state = load_json(state_path)

    if V2_REQUIRES_PIPELINE_OK:
        pok = state.get("last_shadow_pipeline_ok")
        if pok is not True:
            return ("v1", ["last_shadow_pipeline_ok_not_true"])

    if V2_REQUIRES_CONTRACT_PARITY_PASS:
        parity = str(state.get("last_contract_parity_status", "") or "").strip().lower()
        if parity != "pass":
            return ("v1", ["contract_parity_not_pass:{0}".format(parity or "missing")])

    reports_dir = os.path.join(lab_dir, "reports")
    qa_path, _qa_rid = latest_report_path(reports_dir, "qa_canonical_summary_", (".json",))
    qa = load_json(qa_path) if qa_path else {}

    rej_ratio = compute_phase_d_reject_ratio(qa)
    if rej_ratio is None:
        return ("v1", ["missing_qa_summary_for_v2_gate"])

    if rej_ratio > V2_GATE_MAX_REJECT_RATIO:
        return ("v1", ["reject_ratio_exceeds_v2_gate:{0:.6f}".format(rej_ratio)])

    bad_ratio = compute_phase_d_invalid_external_id_skip_ratio(qa)
    if bad_ratio is None:
        return ("v1", ["missing_invalid_id_counters_for_v2_gate"])

    if bad_ratio > V2_GATE_MAX_INVALID_EXTERNAL_ID_SKIP_RATIO:
        return ("v1", ["invalid_external_id_ratio_exceeds_v2_gate:{0:.6f}".format(bad_ratio)])

    proj_path, _pr = latest_report_path(reports_dir, "projection_parity_summary_", (".json",))
    proj = load_json(proj_path) if proj_path else {}
    elig = proj.get("eligible_count")
    succ = proj.get("projected_success_this_run")
    rj = proj.get("projected_reject_this_run")
    if isinstance(elig, int) and elig == 0:
        reasons.append("projection_eligible_zero_skip_coverage_gate")
    elif isinstance(elig, int) and elig >= 0 and isinstance(succ, int) and isinstance(rj, int):
        cov = float(succ + rj) / float(max(elig, 1))
        if cov < 0.98:
            return ("v1", ["projection_coverage_below_v2_gate:{0:.6f}".format(cov)])
    else:
        return ("v1", ["missing_projection_summary_for_v2_gate"])

    reasons.append("all_v2_gates_passed")
    return ("v2", reasons)


def resolve_phase_d_entity_scope_for_pipeline(lab_dir):
    """
    Same as resolve_phase_d_entity_scope but tolerates missing prior QA when lab is fresh:
    if no qa summary exists yet, v1 (first-ever D run in a new lab).
    """
    reports_dir = os.path.join(lab_dir, "reports")
    qa_path, _ = latest_report_path(reports_dir, "qa_canonical_summary_", (".json",))
    if not qa_path:
        return ("v1", ["no_prior_qa_summary_default_v1"])
    return resolve_phase_d_entity_scope(lab_dir)
