#!/usr/bin/env python
"""
Shared constants and helpers for Phase A bootstrap, diagnostics, and reporting.
XP-compatible: Python 3.4.4, stdlib only.
"""
from __future__ import print_function

import hashlib
import time
import uuid

BOOTSTRAP_VERSION = "1.0"


def iso_utc_now():
    """ISO 8601 UTC timestamp."""
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


def run_id():
    """Format: YYYYMMDD-HHMMSS-<first8hex>."""
    ts = time.strftime("%Y%m%d-%H%M%S", time.gmtime())
    try:
        hex_part = uuid.uuid4().hex[:8]
    except Exception:
        hex_part = hashlib.sha256(str(time.time()).encode()).hexdigest()[:8]
    return "{0}-{1}".format(ts, hex_part)


# Timestamps written to run_cursor for phase activity (ISO Zulu; lexicographic max == latest).
_RUN_CURSOR_ACTIVITY_TS_KEYS = (
    'updated_at_utc',
    'last_discovery_at_utc',
    'last_phase_c_at_utc',
    'last_phase_d_at_utc',
    'last_phase_e_at_utc',
)


def refresh_run_cursor_updated_at(cursor):
    """
    Set updated_at_utc to the maximum of all known phase activity timestamps in the cursor.
    Prevents updated_at_utc lagging behind last_phase_*_at_utc after partial writes.
    """
    if not isinstance(cursor, dict):
        return
    candidates = []
    for key in _RUN_CURSOR_ACTIVITY_TS_KEYS:
        val = cursor.get(key)
        if isinstance(val, str) and val.strip():
            candidates.append(val.strip())
    if not candidates:
        cursor['updated_at_utc'] = iso_utc_now()
        return
    cursor['updated_at_utc'] = max(candidates)
