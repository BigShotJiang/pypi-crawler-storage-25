#!/usr/bin/env python
"""
Phase D QA Rule layer: deterministic checks over normalized envelope.
No parser-specific business logic in orchestrator. XP-compatible: Python 3.4.4, stdlib only.
"""
from __future__ import print_function

import os
import sys

_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
if _SCRIPT_DIR not in sys.path:
    sys.path.insert(0, _SCRIPT_DIR)

from phase_d_common import (
    QA_ARTIFACT_CLASS_REQUIRED_FIELDS,
    QA_CANONICALIZATION_PRECONDITION,
    QA_DAT_DATE_OF_SERVICE_MISSING,
    QA_DAT_PATIENT_ANCHOR_MISSING,
    QA_DAT_PAYER_ANCHOR_MISSING,
    QA_IDENTITY_INCOMPLETE,
    QA_REQUIRED_DATE_INVALID,
    QA_UNKNOWN_ARTIFACT_CLASS,
)
from dat_contract import resolve_dat_fields


def _check_csv(envelope):
    """QA checks for CSV envelope. Returns (pass, reject_code, reject_reason)."""
    if envelope is None:
        return (False, QA_ARTIFACT_CLASS_REQUIRED_FIELDS, "Envelope missing")
    if not isinstance(envelope, dict):
        return (False, QA_ARTIFACT_CLASS_REQUIRED_FIELDS, "Invalid envelope type")
    rows = envelope.get("rows")
    if not isinstance(rows, list):
        return (False, QA_ARTIFACT_CLASS_REQUIRED_FIELDS, "No rows")
    if len(rows) == 0:
        return (False, QA_ARTIFACT_CLASS_REQUIRED_FIELDS, "Empty CSV")
    if not envelope.get("has_patient_id"):
        return (False, QA_IDENTITY_INCOMPLETE, "Patient ID missing in all rows")
    return (True, None, None)


def _check_jsonl(envelope):
    """QA checks for JSONL envelope. Returns (pass, reject_code, reject_reason)."""
    if envelope is None:
        return (False, QA_ARTIFACT_CLASS_REQUIRED_FIELDS, "Envelope missing")
    if not isinstance(envelope, dict):
        return (False, QA_ARTIFACT_CLASS_REQUIRED_FIELDS, "Invalid envelope type")
    rows = envelope.get("rows")
    if not isinstance(rows, list):
        return (False, QA_ARTIFACT_CLASS_REQUIRED_FIELDS, "No rows")
    if len(rows) == 0:
        return (False, QA_ARTIFACT_CLASS_REQUIRED_FIELDS, "Empty JSONL")
    return (True, None, None)


def _check_x12(envelope):
    """QA checks for 837 X12 envelope (min anchors). Returns (pass, reject_code, reject_reason)."""
    if envelope is None:
        return (False, QA_ARTIFACT_CLASS_REQUIRED_FIELDS, "Envelope missing")
    if not isinstance(envelope, dict):
        return (False, QA_ARTIFACT_CLASS_REQUIRED_FIELDS, "Invalid envelope type")
    member_id = envelope.get("member_id") or ""
    member_dob = envelope.get("member_dob") or ""
    payer_id = envelope.get("payer_id") or ""
    if not str(member_id).strip():
        return (False, QA_IDENTITY_INCOMPLETE, "Member ID missing")
    if not str(member_dob).strip():
        return (False, QA_REQUIRED_DATE_INVALID, "Member DOB missing")
    if not str(payer_id).strip():
        return (False, QA_IDENTITY_INCOMPLETE, "Payer ID missing")
    return (True, None, None)


def _check_dat(envelope):
    """QA checks for DAT envelope. Returns (pass, reject_code, reject_reason)."""
    if envelope is None:
        return (False, QA_ARTIFACT_CLASS_REQUIRED_FIELDS, "Envelope missing")
    if not isinstance(envelope, dict):
        return (False, QA_ARTIFACT_CLASS_REQUIRED_FIELDS, "Invalid envelope type")
    records = envelope.get("records")
    if not isinstance(records, list):
        return (False, QA_ARTIFACT_CLASS_REQUIRED_FIELDS, "No records")
    if len(records) == 0:
        return (False, QA_ARTIFACT_CLASS_REQUIRED_FIELDS, "Empty DAT records")
    saw_anchor_like_record = False
    saw_missing_patient_anchor = False
    saw_missing_date_of_service = False
    saw_missing_payer_anchor = False
    for rec in records:
        if isinstance(rec, dict):
            resolved = resolve_dat_fields(rec)
            pat_id = resolved.get("patient_id") or ""
            chart = resolved.get("chart_number") or ""
            last_name = resolved.get("last_name") or ""
            first_name = resolved.get("first_name") or ""
            if pat_id or chart or last_name or first_name:
                saw_anchor_like_record = True
                date_of_service = resolved.get("date_of_service") or ""
                payer_id = resolved.get("payer_id") or ""
                if not str(pat_id).strip():
                    saw_missing_patient_anchor = True
                    continue
                if not str(date_of_service).strip():
                    saw_missing_date_of_service = True
                    continue
                if not str(payer_id).strip():
                    saw_missing_payer_anchor = True
                    continue
                return (True, None, None)
    if not saw_anchor_like_record:
        return (False, QA_ARTIFACT_CLASS_REQUIRED_FIELDS, "No valid dict records with PATID/CHART/LAST/FIRST")
    if saw_missing_patient_anchor:
        return (False, QA_DAT_PATIENT_ANCHOR_MISSING, "DAT patient anchor missing (PATID required; CHART is supplemental)")
    if saw_missing_date_of_service:
        return (False, QA_DAT_DATE_OF_SERVICE_MISSING, "DAT service date missing (DOS/DATE1)")
    if saw_missing_payer_anchor:
        return (False, QA_DAT_PAYER_ANCHOR_MISSING, "DAT payer anchor missing (PAYERID/INSID)")
    return (False, QA_ARTIFACT_CLASS_REQUIRED_FIELDS, "No DAT records satisfied minimum contract")


def _check_docx(envelope):
    """QA checks for DOCX envelope. Returns (pass, reject_code, reject_reason)."""
    if envelope is None:
        return (False, QA_ARTIFACT_CLASS_REQUIRED_FIELDS, "Envelope missing")
    if not isinstance(envelope, dict):
        return (False, QA_ARTIFACT_CLASS_REQUIRED_FIELDS, "Invalid envelope type")
    schedules = envelope.get("schedules")
    patient_data = envelope.get("patient_data")
    if schedules and isinstance(schedules, dict) and len(schedules) > 0:
        return (True, None, None)
    if patient_data and isinstance(patient_data, dict) and len(patient_data) > 0:
        return (True, None, None)
    return (False, QA_ARTIFACT_CLASS_REQUIRED_FIELDS, "No schedule or patient data")


def evaluate_qa(artifact_class, envelope):
    """
    Run deterministic QA checks over normalized envelope.
    Returns (pass, reject_code, reject_reason).
    pass=True means QA passed; pass=False means reject with given code/reason.
    """
    handlers = {
        "csv": _check_csv,
        "jsonl": _check_jsonl,
        "837": _check_x12,
        "dat": _check_dat,
        "docx": _check_docx,
    }
    handler = handlers.get(artifact_class)
    if handler is None:
        return (False, QA_UNKNOWN_ARTIFACT_CLASS, "No QA handler for artifact_class={0}".format(artifact_class))
    return handler(envelope)
