#!/usr/bin/env python
"""
Shared DAT field/provenance resolution used by parse, QA, join alignment,
canonical extraction, and Phase D decision logging.
XP-compatible: Python 3.4.4, stdlib only.
"""
from __future__ import print_function


_NORMALIZED_FIELD_KEYS = (
    "chart_number",
    "patient_id",
    "first_name",
    "last_name",
    "patient_name",
    "date_of_service",
    "payer_id",
    "insurance_name",
    "member_id",
)


def _to_text(value):
    if value is None:
        return ""
    return str(value).strip()


def _first_text(mapping, keys):
    if not isinstance(mapping, dict):
        return ""
    for key in keys:
        value = _to_text(mapping.get(key))
        if value:
            return value
    return ""


def _to_int_or_none(value):
    if value is None:
        return None
    text = _to_text(value)
    if not text:
        return None
    try:
        return int(text)
    except (TypeError, ValueError):
        return None


def resolve_dat_fields(record, provenance=None):
    """
    Resolve DAT join/contract fields plus row provenance from mixed legacy aliases.
    Returns a dict with normalized field names and available provenance keys.
    """
    record = record if isinstance(record, dict) else {}
    provenance = provenance if isinstance(provenance, dict) else {}

    chart_number = _first_text(record, ("chart_number", "CHART", "patient_chart"))
    patient_id = _first_text(record, ("patient_id", "PATID", "patid"))
    first_name = _first_text(record, ("first_name", "FIRST", "FIRSTNAME"))
    last_name = _first_text(record, ("last_name", "LAST", "LASTNAME"))
    patient_name = _first_text(record, ("patient_name", "PATNAME"))
    if not patient_name:
        patient_name = _to_text((first_name + " " + last_name).strip())
    date_of_service = _first_text(record, ("date_of_service", "DOS", "DATE1", "service_date"))
    payer_id = _first_text(record, ("payer_id", "PAYERID", "INSID", "insurance_id"))
    insurance_name = _first_text(record, ("insurance_name", "INAME"))
    member_id = _first_text(record, ("member_id", "MEMID"))
    if not member_id:
        member_id = patient_id

    return {
        "chart_number": chart_number,
        "patient_id": patient_id,
        "first_name": first_name,
        "last_name": last_name,
        "patient_name": patient_name,
        "date_of_service": date_of_service,
        "payer_id": payer_id,
        "insurance_name": insurance_name,
        "member_id": member_id,
        "source_ref": _first_text(provenance, ("source_ref",)) or _first_text(record, ("source_ref",)),
        "record_index": _to_int_or_none(
            provenance.get("record_index") if provenance.get("record_index") is not None else record.get("record_index")
        ),
        "attachment_sha256": (
            _first_text(provenance, ("attachment_sha256", "sha256"))
            or _first_text(record, ("attachment_sha256", "sha256"))
        ),
    }


def normalize_dat_record(record, provenance=None):
    """
    Copy record and inject normalized DAT aliases.
    Provenance is accepted for interface symmetry but not written back into the row.
    """
    if not isinstance(record, dict):
        return {}
    normalized = dict(record)
    resolved = resolve_dat_fields(record, provenance=provenance)
    for key in _NORMALIZED_FIELD_KEYS:
        normalized[key] = resolved.get(key) or ""
    return normalized


def build_dat_decision_context(record, provenance=None):
    """Context bundle shared by extractor_skip and constraint_fail DAT evidence."""
    resolved = resolve_dat_fields(record, provenance=provenance)
    context = {
        "source_ref": resolved.get("source_ref") or "",
        "record_index": resolved.get("record_index"),
        "attachment_sha256": resolved.get("attachment_sha256") or "",
        "resolved_patient_id": resolved.get("patient_id") or "",
        "resolved_date_of_service": resolved.get("date_of_service") or "",
        "resolved_payer_id": resolved.get("payer_id") or "",
        "resolved_chart_number": resolved.get("chart_number") or "",
        "resolved_insurance_name": resolved.get("insurance_name") or "",
        "resolved_member_id": resolved.get("member_id") or "",
        "resolved_patient_name": resolved.get("patient_name") or "",
    }
    if context["record_index"] is None:
        context.pop("record_index")
    return context
