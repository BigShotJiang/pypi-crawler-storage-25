#!/usr/bin/env python
"""
Phase B autonomous failure report: builds bundle and submits via MediCafe error reporter.
Uses skip_interactive_reauth=True for unattended operation.
XP-compatible: Python 3.4.4, stdlib only.
"""
from __future__ import print_function

import hashlib
import json
import os
import sys

_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
_WORKSPACE_ROOT = os.path.abspath(os.path.join(_SCRIPT_DIR, "..", ".."))
if _WORKSPACE_ROOT not in sys.path:
    sys.path.insert(0, _WORKSPACE_ROOT)
if _SCRIPT_DIR not in sys.path:
    sys.path.insert(0, _SCRIPT_DIR)

DEDUP_WINDOW_SEC = 4 * 3600  # 4 hours
DEDUP_CHANNEL = "phase_b_pipeline_report"


def submit_phase_b_failure_report(lab_root, failure_context):
    """
    Build Phase B failure bundle and submit via error reporter.
    Uses skip_interactive_reauth=True; no token => leave in queue.

    failure_context: dict with error_code, run_id, first_failed, lab_root,
                     report_json_path, report_txt_path (optional),
                     summary (optional dict for extra_files).

    Returns True if report sent, False if queued or failed.
    """
    try:
        from MediCafe.error_reporter import (
            collect_support_bundle,
            report_dedup_release_if_failed,
            report_dedup_try_reserve,
            submit_support_bundle_email,
        )
    except ImportError as e:
        try:
            import logging
            logging.getLogger(__name__).warning(
                "Phase B report: error_reporter unavailable: {0}".format(e)
            )
        except Exception:
            pass
        return False

    error_code = failure_context.get("error_code", "PHASE_B_ROOT_RESOLUTION_FAIL")
    first_failed = failure_context.get("first_failed", "unknown")
    run_id_val = failure_context.get("run_id", "")
    lab_root_val = failure_context.get("lab_root", lab_root)

    dedup_key = hashlib.sha256(
        ("phase_b" + error_code + first_failed + lab_root_val).encode("utf-8")
    ).hexdigest()

    state_path = os.path.join(lab_root, "diagnostics_state.json")
    state_dir = os.path.dirname(state_path)
    if state_dir and not os.path.exists(state_dir):
        try:
            os.makedirs(state_dir, exist_ok=True)
        except (IOError, OSError):
            pass

    allowed, _ = report_dedup_try_reserve(state_path, DEDUP_CHANNEL, dedup_key, DEDUP_WINDOW_SEC)
    if not allowed:
        return False

    extra_meta = {
        "phase_b_failure": True,
        "error_code": error_code,
        "run_id": run_id_val,
        "first_failed": first_failed,
        "lab_root": lab_root_val,
        "error_summary": "Phase B discovery failed: {0} ({1})".format(
            error_code, first_failed
        ),
    }

    extra_files = []
    report_json = failure_context.get("report_json_path")
    report_txt = failure_context.get("report_txt_path")
    if report_json and os.path.exists(report_json):
        extra_files.append(("artifact_discovery_summary.json", report_json))
    if report_txt and os.path.exists(report_txt):
        extra_files.append(("artifact_discovery_summary.txt", report_txt))
    summary = failure_context.get("summary")
    if isinstance(summary, dict):
        extra_files.append(("artifact_discovery_summary.json", summary))

    zip_path = collect_support_bundle(
        include_traceback=False,
        extra_meta=extra_meta,
        extra_files=extra_files if extra_files else None,
    )
    if not zip_path:
        report_dedup_release_if_failed(state_path, DEDUP_CHANNEL, dedup_key)
        return False

    success = submit_support_bundle_email(
        zip_path,
        skip_interactive_reauth=True,
        extra_meta=extra_meta,
        extra_files=extra_files if extra_files else None,
    )
    if not success:
        report_dedup_release_if_failed(state_path, DEDUP_CHANNEL, dedup_key)
    return success
