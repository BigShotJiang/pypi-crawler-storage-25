#!/usr/bin/env python
"""
Phase D v2 domain metrics: source lanes (dat_record, remittance_row), reconcilable counters,
compact DAT-lane slice for telemetry and Phase F. XP-compatible: Python 3.4.4, stdlib only.
"""
from __future__ import print_function

# Canonical types that participate in v2 domain lane metrics (not patient_csv_row / x12_member).
V2_SOURCE_LANE_DAT = "dat_record"
V2_SOURCE_LANE_REMIT = "remittance_row"
V2_SOURCE_LANES = (V2_SOURCE_LANE_DAT, V2_SOURCE_LANE_REMIT)
V2_ENTITY_NAMES = (
    "patient",
    "payer",
    "insurance_plan",
    "coverage",
    "encounter",
    "claim",
    "claim_line",
)

# Extractor skip reasons (dat_record lane); mutually exclusive with constraint_fail per spec.
DAT_V2_SKIP_INVALID_PATIENT_ID = "DAT_V2_SKIP_INVALID_PATIENT_ID"
DAT_V2_SKIP_MISSING_PAYER_ANCHOR = "DAT_V2_SKIP_MISSING_PAYER_ANCHOR"
DAT_V2_SKIP_MISSING_DOS_CLAIM_CHAIN = "DAT_V2_SKIP_MISSING_DOS_CLAIM_CHAIN"

# Constraint / rule_decision_log reason_code values (must match run_qa_canonical log context).
CONSTRAINT_PATIENT_EXTERNAL_ID_INVALID = "PATIENT_EXTERNAL_ID_INVALID_FORMAT"
CONSTRAINT_PLAN_PAYER_UNRESOLVED = "PLAN_PAYER_UNRESOLVED"
CONSTRAINT_COVERAGE_PARENT_UNRESOLVED = "COVERAGE_PARENT_UNRESOLVED"
CONSTRAINT_ENCOUNTER_PATIENT_UNRESOLVED = "ENCOUNTER_PATIENT_UNRESOLVED"
CONSTRAINT_CLAIM_PARENT_UNRESOLVED = "CLAIM_PARENT_UNRESOLVED"
CONSTRAINT_CLAIM_LINE_PARENT_UNRESOLVED = "CLAIM_LINE_PARENT_UNRESOLVED"

# Phase F flatten keys (DAT lane compact totals) — prefix matches shadow_run_report contract.
PHASE_F_DAT_V2_FLAT_KEYS = (
    "phase_d_dat_v2_payload_attempted_total",
    "phase_d_dat_v2_dedup_attempted_total",
    "phase_d_dat_v2_inserted_total",
    "phase_d_dat_v2_ignored_duplicate_total",
    "phase_d_dat_v2_skipped_total",
    "phase_d_dat_v2_constraint_failed_total",
    "phase_d_dat_v2_inserted_patient",
    "phase_d_dat_v2_inserted_payer",
    "phase_d_dat_v2_inserted_insurance_plan",
    "phase_d_dat_v2_inserted_coverage",
    "phase_d_dat_v2_inserted_encounter",
    "phase_d_dat_v2_inserted_claim",
    "phase_d_dat_v2_inserted_claim_line",
)


def v2_lane_from_row(row):
    """Return dat_record or remittance_row if row is a v2 lane payload; else None."""
    if not isinstance(row, dict):
        return None
    ct = str(row.get("canonical_type") or "").strip()
    if ct == V2_SOURCE_LANE_DAT or ct == V2_SOURCE_LANE_REMIT:
        return ct
    return None


def empty_extractor_v2_stats():
    """Stats accumulated from build_domain_upserts (per artifact); merged at run level."""
    return {
        "payload_attempted": _empty_lane_entity_ints(),
        "skipped_by_reason": {V2_SOURCE_LANE_DAT: {}, V2_SOURCE_LANE_REMIT: {}},
        "skip_events": [],
    }


def empty_executor_v2_stats():
    """Mutable stats during _execute_domain_upserts."""
    return {
        "dedup_attempted": _empty_lane_entity_ints(),
        "inserted": _empty_lane_entity_ints(),
        "ignored_duplicate": _empty_lane_entity_ints(),
        "constraint_failed_by_reason": {V2_SOURCE_LANE_DAT: {}, V2_SOURCE_LANE_REMIT: {}},
    }


def _empty_lane_entity_ints():
    out = {}
    for lane in V2_SOURCE_LANES:
        out[lane] = {}
        for ent in V2_ENTITY_NAMES:
            out[lane][ent] = 0
    return out


def v2_inc_payload(stats, lane, entity, n=1):
    if stats is None or not lane or lane not in V2_SOURCE_LANES:
        return
    if entity not in V2_ENTITY_NAMES:
        return
    m = stats.setdefault("payload_attempted", _empty_lane_entity_ints())
    lane_m = m.setdefault(lane, {})
    lane_m[entity] = int(lane_m.get(entity, 0) or 0) + int(n)


def v2_inc_skip(stats, lane, reason, n=1):
    if stats is None or not reason:
        return
    if lane not in V2_SOURCE_LANES:
        return
    sk = stats.setdefault("skipped_by_reason", {V2_SOURCE_LANE_DAT: {}, V2_SOURCE_LANE_REMIT: {}})
    lane_sk = sk.setdefault(lane, {})
    lane_sk[reason] = int(lane_sk.get(reason, 0) or 0) + int(n)


def merge_extractor_v2_stats(accum, partial):
    """Merge partial extractor stats into accum (mutates accum). Returns accum."""
    accum = accum or empty_extractor_v2_stats()
    if not partial:
        return accum
    pay = partial.get("payload_attempted") or {}
    for lane in V2_SOURCE_LANES:
        ent_map = pay.get(lane) or {}
        for ent in V2_ENTITY_NAMES:
            n = int(ent_map.get(ent, 0) or 0)
            if n:
                v2_inc_payload(accum, lane, ent, n)
    psk = partial.get("skipped_by_reason") or {}
    for lane in V2_SOURCE_LANES:
        reasons = psk.get(lane) or {}
        if not isinstance(reasons, dict):
            continue
        for reason, c in reasons.items():
            v2_inc_skip(accum, lane, reason, int(c or 0))
    events = accum.setdefault("skip_events", [])
    for item in partial.get("skip_events") or []:
        if isinstance(item, dict):
            events.append(dict(item))
    return accum


def v2_inc_exec(stats, lane, entity, field, n=1):
    if not stats or not lane or lane not in V2_SOURCE_LANES:
        return
    if entity not in V2_ENTITY_NAMES:
        return
    bucket = stats.setdefault(field, _empty_lane_entity_ints())
    lane_m = bucket.setdefault(lane, {})
    lane_m[entity] = int(lane_m.get(entity, 0) or 0) + int(n)


def v2_inc_constraint(stats, lane, reason, n=1):
    if not stats or not reason:
        return
    if lane not in V2_SOURCE_LANES:
        return
    cf = stats.setdefault(
        "constraint_failed_by_reason", {V2_SOURCE_LANE_DAT: {}, V2_SOURCE_LANE_REMIT: {}}
    )
    lane_cf = cf.setdefault(lane, {})
    lane_cf[reason] = int(lane_cf.get(reason, 0) or 0) + int(n)


def _sum_reason_map(a, b):
    out = dict(a) if isinstance(a, dict) else {}
    if not isinstance(b, dict):
        return out
    for k, v in b.items():
        out[k] = int(out.get(k, 0) or 0) + int(v or 0)
    return out


def _sum_entity_maps(a, b):
    out = {}
    for ent in V2_ENTITY_NAMES:
        out[ent] = int((a or {}).get(ent, 0) or 0) + int((b or {}).get(ent, 0) or 0)
    return out


def build_phase_d_v2_domain_metrics(extractor_stats, executor_stats):
    """
    Full tree for qa_canonical_summary: lanes dat_record, remittance_row, all (sum of those two only).
    """
    ext = extractor_stats or empty_extractor_v2_stats()
    exe = executor_stats or empty_executor_v2_stats()
    pay_d = (ext.get("payload_attempted") or {}).get(V2_SOURCE_LANE_DAT) or {}
    pay_r = (ext.get("payload_attempted") or {}).get(V2_SOURCE_LANE_REMIT) or {}
    ded_d = (exe.get("dedup_attempted") or {}).get(V2_SOURCE_LANE_DAT) or {}
    ded_r = (exe.get("dedup_attempted") or {}).get(V2_SOURCE_LANE_REMIT) or {}
    ins_d = (exe.get("inserted") or {}).get(V2_SOURCE_LANE_DAT) or {}
    ins_r = (exe.get("inserted") or {}).get(V2_SOURCE_LANE_REMIT) or {}
    ign_d = (exe.get("ignored_duplicate") or {}).get(V2_SOURCE_LANE_DAT) or {}
    ign_r = (exe.get("ignored_duplicate") or {}).get(V2_SOURCE_LANE_REMIT) or {}

    skip_d = (ext.get("skipped_by_reason") or {}).get(V2_SOURCE_LANE_DAT) or {}
    skip_r = (ext.get("skipped_by_reason") or {}).get(V2_SOURCE_LANE_REMIT) or {}
    cf_d = (exe.get("constraint_failed_by_reason") or {}).get(V2_SOURCE_LANE_DAT) or {}
    cf_r = (exe.get("constraint_failed_by_reason") or {}).get(V2_SOURCE_LANE_REMIT) or {}

    def _lane_block(pay, ded, ins, ign):
        by_entity = {}
        for ent in V2_ENTITY_NAMES:
            by_entity[ent] = {
                "payload_attempted": int(pay.get(ent, 0) or 0),
                "dedup_attempted": int(ded.get(ent, 0) or 0),
                "inserted": int(ins.get(ent, 0) or 0),
                "ignored_duplicate": int(ign.get(ent, 0) or 0),
            }
        return {"by_entity": by_entity}

    all_pay = _sum_entity_maps(pay_d, pay_r)
    all_ded = _sum_entity_maps(ded_d, ded_r)
    all_ins = _sum_entity_maps(ins_d, ins_r)
    all_ign = _sum_entity_maps(ign_d, ign_r)

    return {
        "schema_version": "phase_d_v2_domain_metrics_v1",
        "source_lane_all_note": "all = dat_record + remittance_row only; not comparable to entity_upsert_counts",
        "dat_record": _lane_block(pay_d, ded_d, ins_d, ign_d),
        "remittance_row": _lane_block(pay_r, ded_r, ins_r, ign_r),
        "all": _lane_block(all_pay, all_ded, all_ins, all_ign),
        "skipped_by_reason": {
            V2_SOURCE_LANE_DAT: dict(skip_d) if isinstance(skip_d, dict) else {},
            V2_SOURCE_LANE_REMIT: dict(skip_r) if isinstance(skip_r, dict) else {},
            "all": _sum_reason_map(
                skip_d if isinstance(skip_d, dict) else {},
                skip_r if isinstance(skip_r, dict) else {},
            ),
        },
        "constraint_failed_by_reason": {
            V2_SOURCE_LANE_DAT: dict(cf_d) if isinstance(cf_d, dict) else {},
            V2_SOURCE_LANE_REMIT: dict(cf_r) if isinstance(cf_r, dict) else {},
            "all": _sum_reason_map(
                cf_d if isinstance(cf_d, dict) else {},
                cf_r if isinstance(cf_r, dict) else {},
            ),
        },
    }


def _entity_total(metrics, lane_key, field):
    block = (metrics.get(lane_key) or {}).get("by_entity") or {}
    total = 0
    for ent in V2_ENTITY_NAMES:
        total += int((block.get(ent) or {}).get(field, 0) or 0)
    return total


def _sum_skips(metrics, lane_key):
    reasons = (metrics.get("skipped_by_reason") or {}).get(lane_key) or {}
    if not isinstance(reasons, dict):
        return 0
    s = 0
    for _k, v in reasons.items():
        s += int(v or 0)
    return s


def _sum_constraints(metrics, lane_key):
    reasons = (metrics.get("constraint_failed_by_reason") or {}).get(lane_key) or {}
    if not isinstance(reasons, dict):
        return 0
    s = 0
    for _k, v in reasons.items():
        s += int(v or 0)
    return s


def build_phase_d_dat_v2_compact_flat(metrics):
    """
    Flat dict for dat_telemetry and Phase F (DAT lane only). Keys match PHASE_F_DAT_V2_FLAT_KEYS.
    """
    if not isinstance(metrics, dict):
        metrics = {}
    lk = V2_SOURCE_LANE_DAT
    out = {
        "phase_d_dat_v2_payload_attempted_total": _entity_total(metrics, lk, "payload_attempted"),
        "phase_d_dat_v2_dedup_attempted_total": _entity_total(metrics, lk, "dedup_attempted"),
        "phase_d_dat_v2_inserted_total": _entity_total(metrics, lk, "inserted"),
        "phase_d_dat_v2_ignored_duplicate_total": _entity_total(metrics, lk, "ignored_duplicate"),
        "phase_d_dat_v2_skipped_total": _sum_skips(metrics, lk),
        "phase_d_dat_v2_constraint_failed_total": _sum_constraints(metrics, lk),
    }
    block = (metrics.get(lk) or {}).get("by_entity") or {}
    for ent in V2_ENTITY_NAMES:
        key = "phase_d_dat_v2_inserted_{0}".format(ent)
        out[key] = int((block.get(ent) or {}).get("inserted", 0) or 0)
    return out
