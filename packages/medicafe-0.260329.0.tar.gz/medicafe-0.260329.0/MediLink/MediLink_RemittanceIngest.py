# MediLink_RemittanceIngest.py
"""
Shared remittance ingest path: decode -> normalize -> resolve (single code path for
live download and ledger replay). Lives outside MediLink_RemittancePipeline to avoid
circular imports with MediLink_Decoder.
"""
from __future__ import print_function

import os

from MediLink_RemittancePipeline import (
    build_source_meta,
    normalize_unified_record,
    resolve_remittance_dict,
)


def _blank_name_count(rows):
    n = 0
    for nd in rows:
        if not str(nd.get('patient_name', '') or '').strip():
            n += 1
    return n


def ingest_decoded_records_to_canonical(records, source_meta, lookups, log_fn=None, log_basename=''):
    """
    Normalize decoded UnifiedRecords and apply crosswalk resolution.

    Args:
        records: list from process_decoded_file(..., return_records=True)
        source_meta: dict passed to normalize_unified_record (e.g. from build_source_meta)
        lookups: dict from build_crosswalk_lookups
        log_fn: optional callable(message, level='INFO')
        log_basename: filename for log lines

    Returns:
        (normalized_records, stats_dict)
    """
    normalized_records = []
    for rec in records:
        normalized_records.append(normalize_unified_record(rec, source_meta))

    blank_name_before = _blank_name_count(normalized_records)

    if lookups is not None:
        for nd in normalized_records:
            resolve_remittance_dict(nd, lookups)

    matched_rows = 0
    blank_name_after = 0
    blank_name_samples = []
    for nd in normalized_records:
        if str(nd.get('match_status', '')).startswith('matched'):
            matched_rows += 1
        if not str(nd.get('patient_name', '') or '').strip():
            blank_name_after += 1
            if len(blank_name_samples) < 5:
                blank_name_samples.append(nd.get('claim_number') or nd.get('payer_claim_number') or '')

    patient_names_backfilled = max(0, blank_name_before - blank_name_after)
    named_after_normalize = len(normalized_records) - blank_name_before

    stats = {
        'records': len(normalized_records),
        'matched_rows': matched_rows,
        'unmatched_rows': len(normalized_records) - matched_rows,
        'sourceBlankPatientNames': blank_name_before,
        'patientNamesBackfilled': patient_names_backfilled,
        'patientNamesStillBlank': blank_name_after,
        'blank_name_samples': blank_name_samples,
        'parser_named_rows': named_after_normalize,
    }

    if log_fn and log_basename:
        log_fn(
            "Remittance ingest identity stats for {}: records={}, matched={}, unmatched={}, sourceBlankPatientNames={}, patientNamesBackfilled={}, patientNamesStillBlank={}".format(
                log_basename,
                len(normalized_records),
                matched_rows,
                len(normalized_records) - matched_rows,
                blank_name_before,
                patient_names_backfilled,
                blank_name_after,
            ),
            level="INFO",
        )
        if blank_name_after:
            log_fn(
                "Remittance rows still missing patient_name for {} sample_claims={}".format(
                    log_basename, blank_name_samples
                ),
                level="DEBUG",
            )

    return normalized_records, stats


def replay_remittance_source_file(
    src_path,
    output_directory,
    endpoint_key,
    lookups,
    file_type_label=None,
    mtime=None,
    source_checksum=None,
    process_decoded_file_fn=None,
    determine_file_type_fn=None,
    log_fn=None,
):
    """
    Decode a single remittance file and run the same normalize/resolve path as live ingest.

    Returns:
        (normalized_rows, stats_dict) or raises from decoder.
    """
    if process_decoded_file_fn is None:
        from MediLink_Decoder import process_decoded_file as process_decoded_file_fn

    if determine_file_type_fn is None:
        from MediLink_Decoder import determine_file_type as determine_file_type_fn

    if mtime is None:
        try:
            mtime = os.path.getmtime(src_path)
        except Exception:
            mtime = None

    records = process_decoded_file_fn(src_path, output_directory, return_records=True)
    for r in records:
        try:
            setattr(r, 'source_file', src_path)
            setattr(r, 'source_mtime', mtime)
        except Exception:
            pass

    ext = os.path.splitext(src_path)[1].strip('.').upper()
    if not file_type_label:
        file_type_label = determine_file_type_fn(src_path) if determine_file_type_fn else ext
    if not file_type_label:
        file_type_label = ext or 'UNKNOWN'

    if source_checksum is None:
        source_checksum = ''

    source_meta = build_source_meta(
        source_file=os.path.basename(src_path),
        source_type=file_type_label,
        source_endpoint=endpoint_key or '',
        source_timestamp=int(mtime) if isinstance(mtime, (int, float)) else None,
        data_source='parsed_file',
        source_checksum=source_checksum,
    )

    return ingest_decoded_records_to_canonical(
        records,
        source_meta,
        lookups,
        log_fn=log_fn,
        log_basename=os.path.basename(src_path),
    )
