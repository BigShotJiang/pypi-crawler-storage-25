# MediBot_Crosswalk_Library.py
"""
Core crosswalk library for MediBot
Handles crosswalk operations and API interactions.
"""

import sys

# Use core utilities for standardized imports
from MediCafe.core_utils import (
    import_medibot_module,
    get_config_loader_with_fallback,
    smart_import
)

# Initialize configuration loader with fallback
MediLink_ConfigLoader = get_config_loader_with_fallback()

# Import MediBot modules using centralized import functions
MediBot_Preprocessor_lib = import_medibot_module('MediBot_Preprocessor_lib')

# Import utility functions from MediBot_Crosswalk_Utils.py using centralized import
MediBot_Crosswalk_Utils = import_medibot_module('MediBot_Crosswalk_Utils')
if MediBot_Crosswalk_Utils:
    check_crosswalk_health = getattr(MediBot_Crosswalk_Utils, 'check_crosswalk_health', None)
    prompt_user_for_api_calls = getattr(MediBot_Crosswalk_Utils, 'prompt_user_for_api_calls', None)
    select_endpoint = getattr(MediBot_Crosswalk_Utils, 'select_endpoint', None)
    ensure_full_config_loaded = getattr(MediBot_Crosswalk_Utils, 'ensure_full_config_loaded', None)
    save_crosswalk = getattr(MediBot_Crosswalk_Utils, 'save_crosswalk', None)
    update_crosswalk_with_corrected_payer_id = getattr(MediBot_Crosswalk_Utils, 'update_crosswalk_with_corrected_payer_id', None)
    update_crosswalk_with_new_payer_id = getattr(MediBot_Crosswalk_Utils, 'update_crosswalk_with_new_payer_id', None)
    load_and_parse_z_data = getattr(MediBot_Crosswalk_Utils, 'load_and_parse_z_data', None)
else:
    # Set all functions to None if import fails completely
    check_crosswalk_health = None
    prompt_user_for_api_calls = None
    select_endpoint = None
    ensure_full_config_loaded = None
    save_crosswalk = None
    update_crosswalk_with_corrected_payer_id = None
    update_crosswalk_with_new_payer_id = None
    load_and_parse_z_data = None

# Import API functions using centralized import pattern
MediLink_API_v3 = smart_import(['MediCafe.api_core'])
fetch_payer_name_from_api = getattr(MediLink_API_v3, 'fetch_payer_name_from_api', None) if MediLink_API_v3 else None

# Module-level cache to prevent redundant API calls
_api_cache = {}

# Module-level set to track payers attempted in this session (prevents retry of "Unknown" in same session)
_session_attempted_payers = set()

# Module-level variable to store the last API error message (prevents duplicate API calls for error checking)
_last_api_error = None

# Module-level flags for non-normal startup conditions
_api_unavailability_detected = set()  # Endpoint-specific tracking (e.g., {'AVAILITY', 'UHCAPI'})
_mains_data_load_failed = False

"""
# RESOLVED: Redundant API calls have been eliminated through module-level caching.
# The _api_cache prevents duplicate API calls for the same payer_id within a session.
# Additionally, _session_attempted_payers prevents retrying "Unknown" payers within the same session,
# since the API won't become available mid-session.
"""

def is_api_unavailable(endpoint_name='AVAILITY'):
    """Check if a specific endpoint is unavailable this session."""
    global _api_unavailability_detected
    return endpoint_name in _api_unavailability_detected

def payer_name_needs_resolution(crosswalk, payer_id):
    """
    Return True when a payer entry still needs API name resolution.
    """
    details = crosswalk.get('payer_id', {}).get(payer_id, {})
    name = details.get('name', '')
    return (not name) or (name == "Unknown")

def ensure_payer_entry(crosswalk, payer_id):
    """
    Ensure crosswalk['payer_id'][payer_id] exists and return the entry.
    """
    if 'payer_id' not in crosswalk:
        crosswalk['payer_id'] = {}
    if payer_id not in crosswalk['payer_id']:
        crosswalk['payer_id'][payer_id] = {}
    return crosswalk['payer_id'][payer_id]

def store_payer_name(crosswalk, payer_id, payer_name):
    """
    Persist a payer name onto the crosswalk entry.
    """
    payer_entry = ensure_payer_entry(crosswalk, payer_id)
    payer_entry['name'] = payer_name
    return payer_entry

def normalize_api_validation_prompt_result(prompt_result, crosswalk):
    """
    Backward-compatible normalizer for prompt_user_for_api_calls return shape.
    Supports:
      - bool (legacy): proceed_api_validation
      - (bool, crosswalk): proceed_api_validation + potentially updated crosswalk
    """
    if isinstance(prompt_result, tuple):
        proceed = bool(prompt_result[0]) if len(prompt_result) > 0 else False
        updated_crosswalk = prompt_result[1] if len(prompt_result) > 1 and prompt_result[1] is not None else crosswalk
        return proceed, updated_crosswalk
    return bool(prompt_result), crosswalk

# =============================================================================
# CORE CROSSWALK OPERATIONS - Main Library Functions
# =============================================================================
# These functions handle the primary crosswalk operations and are kept in the main
# library because they are frequently called and contain the core business logic.
# Utility functions have been moved to MediBot_Crosswalk_Utils.py to reduce
# the main library size and improve maintainability.

def fetch_and_store_payer_name(client, payer_id, crosswalk, config, api_cache=None):
    """
    Fetches the payer name for a given payer ID and stores it in the crosswalk.
    Now with optional API cache to prevent redundant calls and session-level attempt tracking.
    
    Args:
        payer_id (str): The ID of the payer to fetch.
        crosswalk (dict): The crosswalk dictionary to store the payer name.
        config (dict): Configuration settings for logging.
        api_cache (dict, optional): Cache to prevent redundant API calls. Uses module-level cache if None.

    Returns:
        bool: True if the payer name was fetched and stored successfully, False otherwise.
    """
    global _api_cache, _session_attempted_payers, _last_api_error
    
    # Check if AVAILITY (payer-list endpoint) is known to be unavailable
    if is_api_unavailable('AVAILITY'):
        MediLink_ConfigLoader.log(
            "Skipping API call for Payer ID {} - AVAILITY unavailable this session. Marking as 'Unknown'.".format(payer_id),
            config,
            level="DEBUG"
        )
        # Mark as Unknown without attempting API call
        store_payer_name(crosswalk, payer_id, "Unknown")
        return False
    
    # Use provided cache or module-level cache
    if api_cache is None:
        api_cache = _api_cache
    
    # Check if we already have this payer_id in cache
    if payer_id in api_cache:
        payer_name = api_cache[payer_id]
        # If cached value is "Unknown" and we've already attempted it this session, don't retry
        if payer_name == "Unknown" and payer_id in _session_attempted_payers:
            store_payer_name(crosswalk, payer_id, "Unknown")
            MediLink_ConfigLoader.log(
                "Skipping retry for Payer ID {} - already attempted and failed in this session. Will retry next session.".format(payer_id),
                config,
                level="INFO"
            )
            return False
        if payer_name == "Unknown":
            store_payer_name(crosswalk, payer_id, "Unknown")
            MediLink_ConfigLoader.log(
                "Cached unresolved payer name for Payer ID {}. Leaving as 'Unknown'.".format(payer_id),
                config,
                level="DEBUG"
            )
            return False
        store_payer_name(crosswalk, payer_id, payer_name)
        MediLink_ConfigLoader.log("Using cached payer name for Payer ID: {}".format(payer_id), config, level="DEBUG")
        return True
    else:
        MediLink_ConfigLoader.log("Attempting to fetch payer name for Payer ID: {}".format(payer_id), config, level="DEBUG")
        try:
            # Fetch the payer name from the API (pass quiet_mode if AVAILITY is known to be unavailable)
            payer_name = fetch_payer_name_from_api(client, payer_id, config, primary_endpoint=None, quiet_mode=is_api_unavailable('AVAILITY'))
            # Cache the result
            api_cache[payer_id] = payer_name
            _session_attempted_payers.add(payer_id)  # Track that we attempted this payer
            _last_api_error = None  # Clear error on successful fetch
            MediLink_ConfigLoader.log("Fetched and cached payer name: {} for Payer ID: {}".format(payer_name, payer_id), config, level="DEBUG")
        except Exception as e:
            # Store the error message for API unavailability detection (prevents duplicate API calls)
            _last_api_error = str(e)
            # Log any errors encountered during the fetching process
            MediLink_ConfigLoader.log(
                "Failed to fetch name for Payer ID {}: {}. Marking as 'Unknown' for next session retry.".format(payer_id, e),
                config,
                level="WARNING"
            )
            payer_name = "Unknown"
            api_cache[payer_id] = payer_name
            _session_attempted_payers.add(payer_id)  # Track that we attempted and failed
            store_payer_name(crosswalk, payer_id, payer_name)
            return False

        # Store the fetched payer name in the crosswalk
        store_payer_name(crosswalk, payer_id, payer_name)
        message = "Payer ID {} ({}) fetched and stored successfully.".format(payer_id, payer_name)
        MediLink_ConfigLoader.log(message, config, level="INFO")
        print(message)
        return True

def validate_and_correct_payer_ids(client, crosswalk, config, auto_correct=False, api_cache=None):
    """
    Validates and corrects payer IDs in the crosswalk. If a payer ID is invalid, it prompts the user for correction.
    Automatically detects API unavailability and switches to auto-correct mode after consecutive API failures.
    
    Args:
        crosswalk (dict): The crosswalk dictionary containing payer IDs.
        config (dict): Configuration settings for logging.
        auto_correct (bool): If True, automatically corrects invalid payer IDs to 'Unknown'.
        api_cache (dict, optional): Cache to prevent redundant API calls.
    """
    global _last_api_error, _api_unavailability_detected
    
    processed_payer_ids = set()  # Track processed payer IDs
    payer_ids = list(crosswalk.get('payer_id', {}).keys())  # Static list to prevent modification issues
    api_unavailability_count = 0  # Track consecutive API unavailability failures
    api_unavailability_detected = False  # Flag to track if API unavailability was detected
    
    # Check if AVAILITY was already detected as unavailable in a previous call this session
    if is_api_unavailable('AVAILITY'):
        api_unavailability_detected = True
        auto_correct = True
        MediLink_ConfigLoader.log(
            "AVAILITY already marked unavailable from previous call. Enabling auto-correct mode.",
            config,
            level="INFO"
        )
    
    # Patterns that indicate API unavailability (not just a single payer failure)
    api_unavailability_patterns = [
        "No access token available",
        "unauthorized_client",
        "Invalid client ID or secret",
        "All endpoints exhausted"
    ]
    
    for payer_id in payer_ids:
        if payer_id in processed_payer_ids:
            continue  # Skip already processed payer IDs

        # Skip entries that already have a resolved name.
        if not payer_name_needs_resolution(crosswalk, payer_id):
            processed_payer_ids.add(payer_id)
            continue
        
        # If API unavailability already detected, skip API calls entirely for remaining payers
        if api_unavailability_detected:
            # Automatically mark as Unknown without making API call
            crosswalk['payer_id'][payer_id]['name'] = "Unknown"
            MediLink_ConfigLoader.log(
                "Skipping API call for Payer ID {} - API unavailability already detected. Marking as 'Unknown'.".format(payer_id),
                config,
                level="DEBUG"  # Reduced to DEBUG since this is expected behavior after unavailability detection
            )
            print("Auto-corrected Payer ID '{}' to 'Unknown'.".format(payer_id))
            processed_payer_ids.add(payer_id)
            continue
        
        # Validate the payer ID by fetching its name
        is_valid = fetch_and_store_payer_name(client, payer_id, crosswalk, config, api_cache)
        
        if not is_valid:
            # Check if this failure is due to API unavailability using stored error from first call
            # (no need to make duplicate API call - use _last_api_error)
            api_error_detected = False
            if not auto_correct:  # Only check if we're not already in auto-correct mode
                # Use the stored error from the first API call instead of making a duplicate call
                if _last_api_error:
                    error_str = _last_api_error
                    for pattern in api_unavailability_patterns:
                        if pattern in error_str:
                            api_error_detected = True
                            api_unavailability_count += 1
                            break
                
                # If we've detected 2+ consecutive API unavailability failures, switch to auto-correct mode
                if api_error_detected and api_unavailability_count >= 2 and not api_unavailability_detected:
                    api_unavailability_detected = True
                    _api_unavailability_detected.add('AVAILITY')  # Set module-level flag for startup pause (endpoint-specific)
                    auto_correct = True
                    
                    # Count remaining payers for consolidated summary message
                    current_index = payer_ids.index(payer_id) if payer_id in payer_ids else 0
                    remaining_payers = payer_ids[current_index:]
                    remaining_count = len([p for p in remaining_payers if p not in processed_payer_ids])
                    
                    print("\n" + "="*70)
                    print("API SERVICE UNAVAILABLE DETECTED")
                    print("="*70)
                    print("The API service is currently unavailable (authentication or connectivity issues).")
                    print("All remaining payer IDs ({} payers) will be automatically marked as 'Unknown'.".format(remaining_count))
                    print("The system will attempt to resolve these names in the next session when the API is available.")
                    print("="*70 + "\n")
                    MediLink_ConfigLoader.log(
                        "API unavailability detected after {} consecutive failures. Switching to auto-correct mode for {} remaining payers.".format(api_unavailability_count, remaining_count),
                        config,
                        level="WARNING"
                    )
                elif not api_error_detected:
                    # Reset API unavailability count if this failure is not due to API unavailability
                    api_unavailability_count = 0
                    _last_api_error = None  # Clear error since it's not API unavailability
            
            if auto_correct:
                # Automatically correct invalid payer IDs to 'Unknown'
                crosswalk['payer_id'][payer_id]['name'] = "Unknown"
                MediLink_ConfigLoader.log(
                    "Auto-corrected Payer ID {} to 'Unknown'.".format(payer_id),
                    config,
                    level="WARNING"
                )
                print("Auto-corrected Payer ID '{}' to 'Unknown'.".format(payer_id))
                processed_payer_ids.add(payer_id)
                continue
            
            # Prompt the user for a corrected payer ID
            current_name = crosswalk['payer_id'].get(payer_id, {}).get('name', 'Unknown')
            corrected_payer_id = input(
                "WARNING: Invalid Payer ID {} ({}).\n"
                "Enter the correct Payer ID for replacement or type 'FORCE' to continue with the unresolved Payer ID: ".format(
                    payer_id, current_name)
            ).strip()
            
            if corrected_payer_id.lower() == 'force':
                # Assign "Unknown" and log the action
                crosswalk['payer_id'][payer_id]['name'] = "Unknown"
                MediLink_ConfigLoader.log(
                    "User forced unresolved Payer ID {} to remain as 'Unknown'.".format(payer_id),
                    config,
                    level="WARNING"
                )
                print("Payer ID '{}' has been marked as 'Unknown'.".format(payer_id))
                processed_payer_ids.add(payer_id)
                continue
            
            if corrected_payer_id:
                # Validate format and warn if invalid, but allow user to proceed
                try:
                    from MediLink.MediLink_837p_utilities import is_valid_payer_id_format
                    if not is_valid_payer_id_format(corrected_payer_id):
                        print("WARNING: The entered payer ID '{}' does not match the expected format (should be 3-10 alphanumeric characters).".format(corrected_payer_id))
                        confirm = input("Do you want to proceed with this payer ID anyway? (yes/no): ").strip().lower()
                        if confirm not in ('yes', 'y'):
                            MediLink_ConfigLoader.log(
                                "User cancelled entry of invalid payer ID format: {}".format(corrected_payer_id),
                                config,
                                level="INFO"
                            )
                            print("Please try again with a corrected payer ID.")
                            continue
                except ImportError:
                    # If import fails, skip format validation but log for awareness
                    MediLink_ConfigLoader.log(
                        "Could not import is_valid_payer_id_format - skipping format validation for corrected payer ID",
                        config,
                        level="DEBUG"
                    )
                # Validate the corrected payer ID
                if fetch_and_store_payer_name(client, corrected_payer_id, crosswalk, config, api_cache):
                    # Replace the old payer ID with the corrected one in the crosswalk
                    success = update_crosswalk_with_corrected_payer_id(client, payer_id, corrected_payer_id, config, crosswalk, api_cache)
                    if success:
                        print("Payer ID '{}' has been successfully replaced with '{}'.".format(
                            payer_id, corrected_payer_id))
                        processed_payer_ids.add(corrected_payer_id)
                else:
                    # Only set to "Unknown" if the corrected payer ID is not valid
                    crosswalk['payer_id'][corrected_payer_id] = {'name': "Unknown"}
                    MediLink_ConfigLoader.log(
                        "Failed to validate corrected Payer ID {}. Set to 'Unknown'.".format(corrected_payer_id),
                        config,
                        level="ERROR"
                    )
                    print("Payer ID '{}' has been added with name 'Unknown'.".format(corrected_payer_id))
                    processed_payer_ids.add(corrected_payer_id)
            else:
                MediLink_ConfigLoader.log(
                    "No correction provided for Payer ID {}. Skipping.".format(payer_id),
                    config,
                    level="WARNING"
                )
                print("No correction provided for Payer ID '{}'. Skipping.".format(payer_id))

def initialize_crosswalk_from_mapat(client, config, crosswalk):
    """
    Initializes the crosswalk from the MAPAT data source. Loads configuration and data sources, 
    validates payer IDs, and saves the crosswalk.
    
    Returns:
        dict: The payer ID mappings from the initialized crosswalk.
    """
    # Ensure full configuration and crosswalk are loaded
    config, crosswalk = ensure_full_config_loaded(config, crosswalk)
    
    try:
        # Load data sources for patient and payer IDs
        patient_id_to_insurance_id, payer_id_to_patient_ids = MediBot_Preprocessor_lib.load_data_sources(config, crosswalk)
    except ValueError as e:
        print(e)
        sys.exit(1)
    
    # Map payer IDs to insurance IDs
    payer_id_to_details = MediBot_Preprocessor_lib.map_payer_ids_to_insurance_ids(patient_id_to_insurance_id, payer_id_to_patient_ids)
    crosswalk['payer_id'] = payer_id_to_details
    
    # Validate and correct payer IDs in the crosswalk
    validate_and_correct_payer_ids(client, crosswalk, config)
    
    # Save the crosswalk and log the result
    if save_crosswalk(client, config, crosswalk):
        message = "Crosswalk initialized with mappings for {} payers.".format(len(crosswalk.get('payer_id', {})))
        print(message)
        MediLink_ConfigLoader.log(message, config, level="INFO")
    else:
        print("Failed to save the crosswalk.")
        sys.exit(1)
    
    return crosswalk['payer_id']


# =============================================================================
# MAIN CROSSWALK UPDATE FUNCTION
# =============================================================================

def crosswalk_update(client, config, crosswalk): # Upstream of this is only MediBot_Preprocessor.py and MediBot.py
    """
    Updates the crosswalk with insurance data and historical mappings. 
    It loads insurance data, historical payer mappings, and updates the crosswalk accordingly.
    
    Args:
        config (dict): Configuration settings for logging.
        crosswalk (dict): The crosswalk dictionary to update.
    
    Returns:
        bool: True if the crosswalk was updated successfully, False otherwise.
    """
    global _mains_data_load_failed
    MediLink_ConfigLoader.log("Starting crosswalk update process...", config, level="INFO")

    # Initialize API cache for this session to prevent redundant calls
    api_cache = {}

    # Load insurance data from MAINS (optional - continue if not available)
    # XP/Python34 Compatibility: Enhanced error handling with verbose output
    insurance_name_to_id = {}
    try:
        MediLink_ConfigLoader.log("Attempting to load insurance data from MAINS...", config, level="DEBUG")
        
        if MediBot_Preprocessor_lib and hasattr(MediBot_Preprocessor_lib, 'load_insurance_data_from_mains'):
            insurance_name_to_id = MediBot_Preprocessor_lib.load_insurance_data_from_mains(config)
            if insurance_name_to_id:
                MediLink_ConfigLoader.log("Loaded insurance data from MAINS with {} entries.".format(len(insurance_name_to_id)), config, level="INFO")
            else:
                MediLink_ConfigLoader.log("load_insurance_data_from_mains returned empty data", config, level="WARNING")
                _mains_data_load_failed = True  # Set flag for startup pause
        else:
            error_msg = "MediBot_Preprocessor_lib or load_insurance_data_from_mains not available"
            MediLink_ConfigLoader.log(error_msg, config, level="WARNING")
            print("Warning: {}".format(error_msg))
            
    except AttributeError as e:
        error_msg = "AttributeError accessing load_insurance_data_from_mains: {}".format(str(e))
        MediLink_ConfigLoader.log(error_msg, config, level="WARNING")
        print("Warning: {}. Some crosswalk features may be limited.".format(error_msg))
    except ImportError as e:
        error_msg = "ImportError with MediBot_Preprocessor_lib: {}".format(str(e))
        MediLink_ConfigLoader.log(error_msg, config, level="WARNING")
        print("Warning: {}. Some crosswalk features may be limited.".format(error_msg))
    except Exception as e:
        MediLink_ConfigLoader.log("Error loading insurance data from MAINS: {}. Continuing without MAINS data.".format(e), config, level="WARNING")
        print("Warning: MAINS data not available ({}). Some crosswalk features may be limited.".format(str(e)))
        _mains_data_load_failed = True  # Set flag for startup pause
        # Continue without MAINS data - don't return False

    # Load historical payer to patient mappings (optional - continue if not available)
    patient_id_to_payer_id = {}
    try:
        MediLink_ConfigLoader.log("Attempting to load historical payer to patient mappings...", config, level="DEBUG")
        patient_id_to_payer_id = MediBot_Preprocessor_lib.load_historical_payer_to_patient_mappings(config)
        MediLink_ConfigLoader.log("Loaded historical mappings with {} entries.".format(len(patient_id_to_payer_id)), config, level="INFO")
    except Exception as e:
        MediLink_ConfigLoader.log("Error loading historical mappings: {}. Continuing without historical data.".format(e), config, level="WARNING")
        print("Warning: Historical mappings not available. Some crosswalk features may be limited.")
        # Continue without historical data - don't return False

    # Parse Z data for patient to insurance name mappings
    try:
        patient_id_to_insurance_name, z_data_status = load_and_parse_z_data(config)
        mapping_count = len(patient_id_to_insurance_name) if patient_id_to_insurance_name is not None else 0
        MediLink_ConfigLoader.log("Parsed Z data with {} mappings found. Status: {}".format(mapping_count, z_data_status), config, level="INFO")
        
        # Handle different Z data statuses
        if z_data_status == "error":
            MediLink_ConfigLoader.log("Error occurred during Z data parsing.", config, level="ERROR")
            return False
        elif z_data_status == "success_no_new_files":
            MediLink_ConfigLoader.log("No new Z data files to process - this is normal if all files have been processed.", config, level="INFO")
            # Continue with crosswalk update even if no new Z data
        elif z_data_status == "success_empty_files":
            MediLink_ConfigLoader.log("Z data files were processed but contained no valid mappings - this may indicate empty or malformed files.", config, level="WARNING")
            # Continue with crosswalk update even if Z data is empty
        elif z_data_status == "success_with_data":
            MediLink_ConfigLoader.log("Successfully processed Z data with new mappings.", config, level="INFO")
            # Normal case - continue with crosswalk update
    except Exception as e:
        MediLink_ConfigLoader.log("Error parsing Z data in crosswalk update: {}".format(e), config, level="ERROR")
        return False

    # Check if 'payer_id' key exists and is not empty
    MediLink_ConfigLoader.log("Checking for 'payer_id' key in crosswalk...", config, level="DEBUG")
    if 'payer_id' not in crosswalk or not crosswalk['payer_id']:
        MediLink_ConfigLoader.log("The 'payer_id' list is empty or missing.", config, level="WARNING")
        user_input = input(
            "The 'payer_id' list is empty or missing. Would you like to initialize the crosswalk? (yes/no): "
        ).strip().lower()
        if user_input in ['yes', 'y']:
            MediLink_ConfigLoader.log("User chose to initialize the crosswalk.", config, level="INFO")
            initialize_crosswalk_from_mapat(client, config, crosswalk)
            return True  # Indicate that the crosswalk was initialized
        else:
            MediLink_ConfigLoader.log("User opted not to initialize the crosswalk.", config, level="WARNING")
            return False  # Indicate that the update was not completed

    # Determine whether payer-name API validation should run.
    # Core crosswalk synchronization still runs even when API validation is skipped.
    run_api_validation = True
    if prompt_user_for_api_calls is not None:
        prompt_result = prompt_user_for_api_calls(crosswalk, config)
        run_api_validation, crosswalk = normalize_api_validation_prompt_result(prompt_result, crosswalk)
    if not run_api_validation:
        print("Skipping crosswalk API validation - continuing with crosswalk data sync")
        MediLink_ConfigLoader.log("Skipped crosswalk API validation per user choice", config, level="INFO")

    # Continue with existing crosswalk update logic...
    # Update the crosswalk with new payer IDs and insurance IDs
    selected_endpoint_for_new_payers = None
    for patient_id, payer_id in patient_id_to_payer_id.items():
        insurance_name = patient_id_to_insurance_name.get(patient_id)
        if insurance_name and insurance_name in insurance_name_to_id:
            insurance_id = insurance_name_to_id[insurance_name]
           
            # Log the assembly of data
            MediLink_ConfigLoader.log("Assembling data for patient_id '{}': payer_id '{}', insurance_name '{}', insurance_id '{}'.".format(
                patient_id, payer_id, insurance_name, insurance_id), config, level="INFO")
            # Ensure the 'payer_id' key exists in the crosswalk
            if 'payer_id' not in crosswalk:
                crosswalk['payer_id'] = {}
                MediLink_ConfigLoader.log("Initialized 'payer_id' in crosswalk.", config, level="DEBUG")

            # Initialize the payer ID entry if it doesn't exist
            if payer_id not in crosswalk['payer_id']:
                if selected_endpoint_for_new_payers is None:
                    try:
                        if select_endpoint is not None:
                            selected_endpoint_for_new_payers = select_endpoint(config)
                        else:
                            endpoint_keys = list(config.get('MediLink_Config', {}).get('endpoints', {}).keys())
                            selected_endpoint_for_new_payers = endpoint_keys[0] if endpoint_keys else 'AVAILITY'
                            MediLink_ConfigLoader.log(
                                "select_endpoint helper unavailable; defaulting new payer endpoints to '{}'.".format(selected_endpoint_for_new_payers),
                                config,
                                level="WARNING"
                            )
                    except Exception as e:
                        endpoint_keys = list(config.get('MediLink_Config', {}).get('endpoints', {}).keys())
                        selected_endpoint_for_new_payers = endpoint_keys[0] if endpoint_keys else 'AVAILITY'
                        MediLink_ConfigLoader.log(
                            "Endpoint selection failed ({}). Defaulting new payer endpoints to '{}'.".format(e, selected_endpoint_for_new_payers),
                            config,
                            level="WARNING"
                        )

                crosswalk['payer_id'][payer_id] = {
                    'endpoint': selected_endpoint_for_new_payers,
                    'medisoft_id': [],  # PERFORMANCE FIX: Use list instead of set to avoid conversions
                    'medisoft_medicare_id': []  # PERFORMANCE FIX: Use list instead of set to avoid conversions
                }
                MediLink_ConfigLoader.log("Initialized payer ID {} in crosswalk with endpoint '{}'.".format(payer_id, selected_endpoint_for_new_payers), config, level="DEBUG")
                # STRATEGIC NOTE (Medicare Endpoint Routing): Medicare detection logic exists
                # To activate Medicare-specific routing, implement:
                # try:
                #     medicare_payer_ids = config.get('MediLink_Config', {}).get('cob_settings', {}).get('medicare_payer_ids', ['00850'])
                #     if payer_id in medicare_payer_ids or 'MEDICARE' in payer_id.upper():
                #         selected_endpoint = 'MEDICARE_PRIMARY'
                #         crosswalk['payer_id'][payer_id]['crossover_endpoint'] = 'MEDICARE_CROSSOVER'
                # except Exception as e:
                #     MediLink_ConfigLoader.log("Medicare endpoint routing error: {}".format(str(e)), level="WARNING")
                #
                # IMPLEMENTATION QUESTIONS:
                # 1. Should Medicare routing be automatic or require manual confirmation?
                # 2. How should Medicare Advantage plans be routed differently from traditional Medicare?
                # 3. Should crossover endpoints be configured per payer or globally?
                # 4. What fallback behavior when Medicare-specific endpoints are unavailable?

            # Add the insurance ID to the payer ID entry (PERFORMANCE FIX: Use list operations)
            insurance_id_str = str(insurance_id)  # Ensure ID is string
            if insurance_id_str not in crosswalk['payer_id'][payer_id]['medisoft_id']:
                crosswalk['payer_id'][payer_id]['medisoft_id'].append(insurance_id_str)  # Avoid duplicates
            MediLink_ConfigLoader.log(
                "Added new insurance ID {} to payer ID {}.".format(insurance_id, payer_id),
                config,
                level="INFO"
            )

            # Log the update of the crosswalk
            MediLink_ConfigLoader.log("Updated crosswalk for payer_id '{}': added insurance_id '{}'.".format(payer_id, insurance_id), config, level="DEBUG")

            # Fetch payer names only for unresolved entries.
            if run_api_validation and payer_name_needs_resolution(crosswalk, payer_id):
                MediLink_ConfigLoader.log("Fetching and storing payer name for payer_id: {}".format(payer_id), config, level="DEBUG")
                fetch_and_store_payer_name(client, payer_id, crosswalk, config, api_cache)
                MediLink_ConfigLoader.log("Successfully fetched and stored payer name for payer_id: {}".format(payer_id), config, level="INFO")

    # Validate and correct payer IDs in the crosswalk (single authoritative name-resolution pass).
    if run_api_validation:
        MediLink_ConfigLoader.log("Validating and correcting payer IDs in the crosswalk.", config, level="DEBUG")
        validate_and_correct_payer_ids(client, crosswalk, config, api_cache=api_cache)
    else:
        MediLink_ConfigLoader.log("Skipping payer-name validation pass because API validation is disabled this run.", config, level="INFO")

    unresolved_payers = [
        payer_id for payer_id in crosswalk.get('payer_id', {})
        if payer_name_needs_resolution(crosswalk, payer_id)
    ]
    if unresolved_payers:
        MediLink_ConfigLoader.log(
            "Crosswalk update completed with {} unresolved payer name(s).".format(len(unresolved_payers)),
            config,
            level="INFO"
        )

    # PERFORMANCE FIX: Optimized list management - avoid redundant set/list conversions
    # Ensure multiple medisoft_id values are preserved and deduplicated efficiently
    for payer_id, details in crosswalk.get('payer_id', {}).items():
        # Handle medisoft_id - convert sets to lists or deduplicate existing lists
        medisoft_id = details.get('medisoft_id', [])
        if isinstance(medisoft_id, set):
            crosswalk['payer_id'][payer_id]['medisoft_id'] = sorted(list(medisoft_id))
            MediLink_ConfigLoader.log("Converted medisoft_id set to sorted list for payer ID {}.".format(payer_id), config, level="DEBUG")
        elif isinstance(medisoft_id, list) and medisoft_id:
            # Remove duplicates using dict.fromkeys() - preserves order, O(n) performance
            crosswalk['payer_id'][payer_id]['medisoft_id'] = list(dict.fromkeys(medisoft_id))
        
        # Handle medisoft_medicare_id - convert sets to lists or deduplicate existing lists  
        medicare_id = details.get('medisoft_medicare_id', [])
        if isinstance(medicare_id, set):
            crosswalk['payer_id'][payer_id]['medisoft_medicare_id'] = sorted(list(medicare_id))
            MediLink_ConfigLoader.log("Converted medisoft_medicare_id set to sorted list for payer ID {}.".format(payer_id), config, level="DEBUG")
        elif isinstance(medicare_id, list) and medicare_id:
            # Remove duplicates using dict.fromkeys() - preserves order, O(n) performance
            crosswalk['payer_id'][payer_id]['medisoft_medicare_id'] = list(dict.fromkeys(medicare_id))

    MediLink_ConfigLoader.log("Crosswalk update process completed. Processed {} payer IDs.".format(len(patient_id_to_payer_id)), config, level="INFO")
    return save_crosswalk(client, config, crosswalk, api_cache=api_cache)





