@echo off
setlocal enabledelayedexpansion

:: Client Secret Update Launcher
:: Called from MediCafe launcher Troubleshooting menu

:: Get script directory and set paths
set "script_dir=%~dp0"
set "workspace_root=%script_dir%.."
set "python_script=%script_dir%client_secret_update.py"

:: Prefer MEDICAFE_PYTHON if provided by launcher
if defined MEDICAFE_PYTHON (
    set "PYTHON_EXE=%MEDICAFE_PYTHON%"
) else (
    set "PYTHON_EXE=python"
)

:: Use the same path resolution logic as MediLink_ConfigLoader
:: Try default path first (relative to MediCafe module)
set "config_path=%workspace_root%\json\config.json"

:: If default path doesn't exist, try platform-specific fallbacks
if not exist "%config_path%" (
    :: Check for Windows XP (F: drive)
    if exist "F:\" (
        set "config_path=F:\Medibot\json\config.json"
    ) else (
        :: Use current working directory for other Windows versions
        set "config_path=%CD%\json\config.json"
    )
)

:: Display header
cls
echo ========================================
echo    MediCafe Client Secret Updater
echo ========================================
echo.

:: Check if Python is available
"%PYTHON_EXE%" --version >nul 2>&1
if errorlevel 1 (
    echo ERROR: Python is not available or not in PATH
    echo.
    echo Please ensure Python 3.4.4 or later is installed and accessible.
    echo.
    pause
    exit /b 1
)

:: Check if config file exists
if not exist "%config_path%" (
    echo ERROR: Config file not found at:
    echo %config_path%
    echo.
    echo Please ensure the configuration file exists before updating client secrets.
    echo.
    pause
    exit /b 1
)

:: Check if updater script exists
if not exist "%python_script%" (
    echo ERROR: Client secret updater script not found at:
    echo %python_script%
    echo.
    echo Please ensure client_secret_update.py is in the MediBot directory.
    echo.
    pause
    exit /b 1
)

:: Run the client secret updater
echo Starting client secret updater...
echo.
"%PYTHON_EXE%" "%python_script%" "%config_path%"

:: Check exit code
if errorlevel 1 (
    echo.
    echo ERROR: Client secret updater encountered an error.
    echo.
) else (
    echo.
    echo Client secret updater completed successfully.
    echo.
)

:: Return to caller
pause
exit /b %errorlevel%
