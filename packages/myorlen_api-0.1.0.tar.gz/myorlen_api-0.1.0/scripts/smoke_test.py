#!/usr/bin/env python3
"""Quick smoke test for the myorlen library."""
import asyncio
import os
import pathlib
import sys

_orlenid_user  = os.environ.get("ORLENID_USERNAME", "")
_orlenid_pass  = os.environ.get("ORLENID_PASSWORD", "")
_myorlen_user  = os.environ.get("MYORLEN_USERNAME", "")
_myorlen_pass  = os.environ.get("MYORLEN_PASSWORD", "")

if _orlenid_user and _orlenid_pass:
    USERNAME, PASSWORD, USE_ORLENID = _orlenid_user, _orlenid_pass, True
elif _myorlen_user and _myorlen_pass:
    USERNAME, PASSWORD, USE_ORLENID = _myorlen_user, _myorlen_pass, False
else:
    print("ERROR: set ORLENID_USERNAME/ORLENID_PASSWORD or MYORLEN_USERNAME/MYORLEN_PASSWORD", file=sys.stderr)
    sys.exit(1)


async def test_async():
    from myorlen import MyOrlenClient, MyOrlenForbiddenError

    print("=== Async client ===")
    print(f"Login via: {'OrlenID' if USE_ORLENID else 'native myORLEN'}")
    async with MyOrlenClient(USERNAME, PASSWORD, use_orlenid=USE_ORLENID) as client:
        u = client.user_info
        print(f"User: {u.first_name} {u.last_name} <{u.email}>")
        print(f"Agreements: {len(client.agreements)}")
        for ag in client.agreements:
            status = "active" if ag.active else "inactive"
            print(f"  {ag.agreement_number} ({ag.client_number}) — {status}")

        print(f"Metering points: {len(client.metering_points)}")
        for mp in client.metering_points:
            print(f"  {mp.ppg_id}  meter={mp.meter_number}  tariff={mp.tariff}  addr={mp.address}")

        balance = await client.get_balance()
        print(f"\nBalance: {balance.value} PLN  amount_to_pay={balance.amount_to_pay} PLN")

        invoices = await client.get_invoices()
        print(f"Invoices (page 1): {len(invoices)}")
        for inv in invoices[:3]:
            paid = "paid" if inv.is_paid else f"due {inv.payment_deadline}"
            print(f"  {inv.invoice_number}  {inv.issue_date}  {inv.amount} PLN  {paid}  downloadable={inv.downloadable}")

        first_dl = next((i for i in invoices if i.downloadable), None)
        if first_dl:
            try:
                pdf = await client.get_invoice_pdf(first_dl.invoice_number)
                fname = f"{first_dl.invoice_number.replace('/', '_')}.pdf"
                pathlib.Path(fname).write_bytes(pdf)
                print(f"Saved {fname} ({len(pdf):,} bytes)")
            except MyOrlenForbiddenError:
                print("Invoice download not permitted by server")


def test_sync():
    from myorlen import MyOrlenClientSync

    print("\n=== Sync client ===")
    with MyOrlenClientSync(USERNAME, PASSWORD, use_orlenid=USE_ORLENID) as client:
        u = client.user_info
        print(f"User: {u.first_name} {u.last_name}")
        balance = client.get_balance()
        print(f"Balance: {balance.value} PLN")


if __name__ == "__main__":
    asyncio.run(test_async())
    test_sync()
