# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [0.1.0] - 2026-03-29

### Added
- Async client (`MyOrlenClient`) with direct myORLEN eBOK login (`/auth/login`)
- OrlenID federated login (`use_orlenid=True`) — headless Keycloak form submission via `oid-ws.orlen.pl`
- Sync wrapper (`MyOrlenClientSync`) with a dedicated event loop for use in non-async contexts
- Transparent re-login on token expiry (tokens last ~1 hour; up to 2 silent re-login attempts)
- `get_balance()` — current balance and amount to pay
- `get_invoices(page, page_size)` — paginated invoice list with gas consumption data (`WearM3`, `WearKWH`)
- `get_invoice_pdf(invoice_number)` — download invoice PDF as raw bytes
- Cached account data at login: `user_info`, `agreements`, `metering_points`
- Typed models: `Address`, `MeteringPoint`, `Agreement`, `UserInfo`, `Balance`, `Invoice`
- Exception hierarchy: `MyOrlenError`, `MyOrlenAuthError`, `MyOrlenForbiddenError`, `MyOrlenNotFoundError`, `MyOrlenAPIError`
- MCP server (`myorlen.mcp_server`) exposing four tools: `get_account_info`, `get_balance`, `get_invoices`, `download_invoice`
- `mcp` optional dependency group: `pip install myorlen-api[mcp]`
- `myorlen-mcp` script entry point
- Credential auto-detection: `ORLENID_USERNAME`/`ORLENID_PASSWORD` (OrlenID, preferred) or `MYORLEN_USERNAME`/`MYORLEN_PASSWORD` (native)
- PEP 561 `py.typed` marker
