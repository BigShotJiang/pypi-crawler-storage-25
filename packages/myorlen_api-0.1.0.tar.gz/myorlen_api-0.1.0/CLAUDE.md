# myorlen-api

Python client for the myORLEN eBOK self-care portal at `https://ebok.myorlen.pl` (gas accounts, formerly PGNiG).

## Project structure

```
myorlen/
├── client.py       # Async MyOrlenClient
├── sync.py         # MyOrlenClientSync (blocking wrapper)
├── models.py       # Dataclasses: Address, MeteringPoint, Agreement, UserInfo, Balance, Invoice
├── exceptions.py   # MyOrlenError hierarchy
├── _helpers.py     # Response parsers, generate_device_id, token_expires_at
├── mcp_server.py   # MCP server (requires myorlen-api[mcp])
└── __init__.py     # Public exports
scripts/
└── smoke_test.py   # End-to-end test, reads env vars
```

## Running

```bash
uv sync
MYORLEN_USERNAME=... MYORLEN_PASSWORD=... uv run python scripts/smoke_test.py
ORLENID_USERNAME=... ORLENID_PASSWORD=... uv run python scripts/smoke_test.py
```

## Authentication

### Direct login (MYORLEN_USERNAME / MYORLEN_PASSWORD)
- `POST /auth/login?api-version=3.0` with JSON body containing `identificator`, `accessPin`, `DeviceId`
- Returns `Token` + `DateExpirationUtc` directly in response body
- All subsequent requests use `AuthToken: {token}` header (not `Authorization: Bearer`)
- All requests include `?api-version=3.0`
- Server returns HTTP 401 + `Code: 1025 "Soft blocked."` for bad credentials

### OrlenID login (ORLENID_USERNAME / ORLENID_PASSWORD)
Headless OIDC flow — no browser required:
1. `POST /auth/oid/init-login` → server generates PKCE server-side, returns `RedirectUrl` to Keycloak
2. `GET RedirectUrl` (oid-ws.orlen.pl) → Keycloak login form; accumulates session cookies
3. `POST` credentials to form action with `Content-Type: application/x-www-form-urlencoded` → 302 to callback
4. `GET /auth/oid/after-login-callback?code=...` → server exchanges code, stores token for DeviceId
5. `GET /auth/get-auth-token?deviceId=...` → returns the token

## Known gotchas

### aiohttp session-level Content-Type override
The session is created with default `Content-Type: application/json`. For the Keycloak form POST,
this must be explicitly overridden per-request:
```python
session.post(form_action, data={...}, headers={"Content-Type": "application/x-www-form-urlencoded"})
```
Without this, aiohttp sends the wrong content type, Keycloak silently re-renders the form (HTTP 200)
instead of redirecting, and login fails with no obvious error.

### OIDC callback URL contains IdP domain in query parameter
The successful redirect from Keycloak looks like:
```
https://ebok.myorlen.pl/auth/oid/after-login-callback?state=...&iss=https%3A%2F%2Foid-ws.orlen.pl%2F...&code=...
```
Checking `"oid-ws.orlen.pl" in location` is a false positive. Use `location.startswith(_BASE_URL)` instead.

### Token expiry
Tokens expire after ~1 hour (`DateExpirationUtc`). No refresh endpoint exists — re-login on expiry.
Up to `_MAX_RELOGIN_ATTEMPTS = 2` transparent re-logins before raising `MyOrlenAuthError`.

### MCP server credentials
Credential env vars (`ORLENID_USERNAME`/`ORLENID_PASSWORD` or `MYORLEN_USERNAME`/`MYORLEN_PASSWORD`)
are not listed in `.mcp.json` — the subprocess inherits them from the shell environment. This avoids
Claude Code's "missing environment variables" diagnostic, which fires for any `${VAR}` reference
whose var is unset. Export the pair you need in `~/.bashrc` / `~/.zshrc` before starting Claude Code.

## Response format
All API responses wrap data in:
```json
{"Code": 0, "Message": null, "TokenExpireDate": "...", ...data fields...}
```
`Code != 0` means an error. The `check_response_code()` helper raises `MyOrlenAPIError` for these.
