"""Async myORLEN eBOK API client."""
from __future__ import annotations

import re
from datetime import datetime, timedelta, timezone
from typing import Any

import aiohttp

from .exceptions import (
    MyOrlenAPIError,
    MyOrlenAuthError,
    MyOrlenForbiddenError,
    MyOrlenNotFoundError,
)
from ._helpers import (
    check_response_code,
    generate_device_id,
    parse_agreements,
    parse_balance,
    parse_invoice_list,
    parse_metering_points,
    token_expires_at,
    _parse_user_info,
)
from .models import Agreement, Balance, Invoice, MeteringPoint, UserInfo


_BASE_URL = "https://ebok.myorlen.pl"
_API_VERSION = "3.0"


class MyOrlenClient:
    """Async client for the myORLEN eBOK self-care portal API.

    Usage::

        async with MyOrlenClient("user@example.com", "password") as client:
            balance = await client.get_balance()
            invoices = await client.get_invoices()

    For OrlenID federated login::

        async with MyOrlenClient("user@example.com", "password", use_orlenid=True) as client:
            ...
    """

    _MAX_RELOGIN_ATTEMPTS = 2

    def __init__(self, username: str, password: str, *, use_orlenid: bool = False) -> None:
        self._username = username
        self._password = password
        self._use_orlenid = use_orlenid
        self._device_id = generate_device_id()
        self._session: aiohttp.ClientSession | None = None
        self._token: str | None = None
        self._token_expires_at: datetime = datetime.min.replace(tzinfo=timezone.utc)
        self._user_info: UserInfo | None = None
        self._agreements: list[Agreement] = []
        self._metering_points: list[MeteringPoint] = []
        self._relogin_attempts: int = 0

    # ── context manager ───────────────────────────────────────────────────────

    async def __aenter__(self) -> "MyOrlenClient":
        await self.login()
        return self

    async def __aexit__(self, *_: Any) -> None:
        await self.close()

    # ── public properties ─────────────────────────────────────────────────────

    @property
    def user_info(self) -> UserInfo:
        """User profile populated after login()."""
        if self._user_info is None:
            raise MyOrlenAuthError("Not logged in — call login() first.")
        return self._user_info

    @property
    def agreements(self) -> list[Agreement]:
        """Gas supply agreements populated after login()."""
        if not self._agreements and self._user_info is None:
            raise MyOrlenAuthError("Not logged in — call login() first.")
        return self._agreements

    @property
    def metering_points(self) -> list[MeteringPoint]:
        """Gas metering points populated after login()."""
        if not self._metering_points and self._user_info is None:
            raise MyOrlenAuthError("Not logged in — call login() first.")
        return self._metering_points

    # ── auth ──────────────────────────────────────────────────────────────────

    async def login(self) -> None:
        """Authenticate and cache account data. Safe to call multiple times."""
        if self._use_orlenid:
            await self._login_orlenid()
        else:
            await self._login_direct()
        await self._fetch_account_data()

    async def _login_direct(self) -> None:
        """Authenticate via direct username/password POST."""
        session = self._get_session()
        async with session.post(
            f"{_BASE_URL}/auth/login",
            params={"api-version": _API_VERSION},
            json={
                "identificator": self._username,
                "accessPin": self._password,
                "rememberLogin": False,
                "DeviceId": self._device_id,
                "DeviceName": "Python myorlen-api",
                "DeviceType": "Web",
            },
        ) as resp:
            if resp.status != 200:
                body = await resp.text()
                raise MyOrlenAuthError(
                    f"Login request failed ({resp.status}): {body[:300]}"
                )
            data = await resp.json(content_type=None)

        if data.get("Code", -1) != 0:
            msg = data.get("Message") or data.get("EndUserMessage") or "Login failed."
            raise MyOrlenAuthError(msg)

        self._token = data["Token"]
        self._token_expires_at = token_expires_at(data["DateExpirationUtc"])

    async def _login_orlenid(self) -> None:
        """Authenticate via OrlenID OIDC flow (headless form submission)."""
        session = self._get_session()

        # Step 1: init-login — ebok.myorlen.pl generates server-side PKCE,
        # returns a Keycloak authorization URL
        async with session.post(
            f"{_BASE_URL}/auth/oid/init-login",
            params={"api-version": _API_VERSION},
            json={
                "DeviceId": self._device_id,
                "DeviceType": "Web",
                "DeviceName": "Python myorlen-api",
                "LightweightRedirectUrl": f"{_BASE_URL}/?show=modal",
                "FinalizeRegistrationRedirectUrl": f"{_BASE_URL}/aktywuj-oid/",
            },
            headers={"AuthToken": "0"},
        ) as resp:
            if resp.status != 200:
                body = await resp.text()
                raise MyOrlenAuthError(f"OIDC init-login failed ({resp.status}): {body[:200]}")
            data = await resp.json(content_type=None)

        check_response_code(data, "/auth/oid/init-login")
        redirect_url = data.get("RedirectUrl")
        if not redirect_url:
            raise MyOrlenAuthError(
                "Could not find RedirectUrl in init-login response — site may have changed."
            )

        # Step 2: GET the Keycloak authorization URL — follows redirects to the
        # login-actions/authenticate page, accumulating oid-ws.orlen.pl session cookies
        async with session.get(redirect_url, allow_redirects=True) as resp:
            html = await resp.text()

        match = re.search(r'action="([^"]+)"', html)
        if not match:
            raise MyOrlenAuthError(
                "Could not find login form on OrlenID page — site may have changed."
            )
        form_action = match.group(1).replace("&amp;", "&")

        # Step 3: POST credentials to Keycloak form (no auto-redirects — we
        # need to inspect the Location to detect wrong credentials)
        async with session.post(
            form_action,
            data={
                "username": self._username,
                "password": self._password,
                "credentialId": "",
            },
            # Override the session-default application/json so Keycloak
            # receives a proper form-encoded body
            headers={"Content-Type": "application/x-www-form-urlencoded"},
            allow_redirects=False,
        ) as resp:
            location = resp.headers.get("Location", "")
        # Keycloak returns 302 → callback on success, 200 (re-renders form) on failure.
        # Check the host only — the callback URL legitimately contains
        # oid-ws.orlen.pl in its `iss` query parameter.
        if not location or not location.startswith(_BASE_URL):
            raise MyOrlenAuthError(
                "OrlenID login failed — check ORLENID_USERNAME/ORLENID_PASSWORD credentials."
            )

        # Step 4: GET the after-login-callback URL — ebok.myorlen.pl exchanges
        # the authorization code for a token and stores it against our DeviceId.
        async with session.get(location, allow_redirects=False) as resp:
            await resp.release()

        # Step 5: retrieve the token the server stored during callback processing
        async with session.get(
            f"{_BASE_URL}/auth/get-auth-token",
            params={"deviceId": self._device_id, "api-version": _API_VERSION},
        ) as resp:
            if resp.status != 200:
                body = await resp.text()
                raise MyOrlenAuthError(
                    f"get-auth-token failed after OrlenID callback ({resp.status}): {body[:200]}"
                )
            token_data = await resp.json(content_type=None)

        if token_data.get("Code", -1) != 0 or not token_data.get("Token"):
            raise MyOrlenAuthError(
                "OrlenID login did not yield a valid token — "
                f"Code={token_data.get('Code')}, Message={token_data.get('Message')}"
            )

        self._token = token_data["Token"]
        self._token_expires_at = token_expires_at(token_data["DateExpirationUtc"])

    async def close(self) -> None:
        """Close the underlying HTTP session."""
        if self._session and not self._session.closed:
            await self._session.close()

    # ── API methods ───────────────────────────────────────────────────────────

    async def get_balance(self) -> Balance:
        """Fetch the current account balance."""
        data = await self._get_json("/crm/get-balance")
        check_response_code(data, "/crm/get-balance")
        return parse_balance(data)

    async def get_invoices(self, *, page: int = 1, page_size: int = 12) -> list[Invoice]:
        """Fetch invoices (paginated)."""
        data = await self._get_json(
            "/crm/get-invoices-v2",
            params={"pageNumber": page, "pageSize": page_size},
        )
        check_response_code(data, "/crm/get-invoices-v2")
        return parse_invoice_list(data)

    async def get_invoice_pdf(self, invoice_number: str) -> bytes:
        """Download an invoice PDF. Returns raw bytes."""
        await self._ensure_fresh_token()
        async with self._get_session().get(
            f"{_BASE_URL}/crm/get-invoice-pdf",
            params={"invoiceNumber": invoice_number, "api-version": _API_VERSION},
            headers=self._auth_headers(),
        ) as resp:
            self._check_status(resp, "/crm/get-invoice-pdf")
            return await resp.read()

    # ── internals ─────────────────────────────────────────────────────────────

    def _get_session(self) -> aiohttp.ClientSession:
        if self._session is None or self._session.closed:
            self._session = aiohttp.ClientSession(
                # unsafe=True required: oid-ws.orlen.pl sets cookies that aiohttp
                # considers unsafe (non-standard domain in OIDC flow)
                cookie_jar=aiohttp.CookieJar(unsafe=True),
                timeout=aiohttp.ClientTimeout(total=30, connect=10),
                headers={
                    "User-Agent": "Mozilla/5.0",
                    "Accept": "application/json",
                    "Content-Type": "application/json",
                    "Origin": _BASE_URL,
                },
            )
        return self._session

    def _auth_headers(self) -> dict[str, str]:
        return {"AuthToken": self._token or "0"}

    async def _ensure_fresh_token(self) -> None:
        if self._token is None:
            raise MyOrlenAuthError("Not logged in — call login() first.")
        now = datetime.now(tz=timezone.utc)
        # Re-login if token expires within 60 seconds
        if now >= self._token_expires_at - timedelta(seconds=60):
            await self._do_relogin()

    async def _do_relogin(self) -> None:
        if self._relogin_attempts >= self._MAX_RELOGIN_ATTEMPTS:
            raise MyOrlenAuthError(
                f"Token expired and re-login failed after "
                f"{self._MAX_RELOGIN_ATTEMPTS} attempt(s) — restart the client."
            )
        self._relogin_attempts += 1
        await self.login()
        self._relogin_attempts = 0

    def _check_status(self, resp: aiohttp.ClientResponse, path: str) -> None:
        if resp.status == 401:
            raise MyOrlenAuthError(f"Unauthorized: {path}")
        if resp.status == 403:
            raise MyOrlenForbiddenError(f"Access denied: {path}")
        if resp.status == 404:
            raise MyOrlenNotFoundError(f"Not found: {path}")
        if not resp.ok:
            raise MyOrlenAPIError(f"API error {resp.status}: {path}", resp.status)

    async def _get_json(self, path: str, **kwargs: Any) -> Any:
        await self._ensure_fresh_token()
        params = dict(kwargs.pop("params", {}))
        params["api-version"] = _API_VERSION
        async with self._get_session().get(
            f"{_BASE_URL}{path}",
            params=params,
            headers=self._auth_headers(),
            **kwargs,
        ) as resp:
            self._check_status(resp, path)
            return await resp.json(content_type=None)

    async def _post_json(self, path: str, body: Any, **kwargs: Any) -> Any:
        await self._ensure_fresh_token()
        params = dict(kwargs.pop("params", {}))
        params["api-version"] = _API_VERSION
        async with self._get_session().post(
            f"{_BASE_URL}{path}",
            params=params,
            json=body,
            headers=self._auth_headers(),
            **kwargs,
        ) as resp:
            self._check_status(resp, path)
            return await resp.json(content_type=None)

    async def _fetch_account_data(self) -> None:
        """Populate user info, agreements, and metering points after login."""
        user_data = await self._get_json("/crm/get-user-data")
        check_response_code(user_data, "/crm/get-user-data")
        self._user_info = _parse_user_info(user_data)

        ppg_data = await self._get_json("/crm/get-ppg-list")
        check_response_code(ppg_data, "/crm/get-ppg-list")
        self._metering_points = parse_metering_points(ppg_data)

        agreements_data = await self._get_json("/crm/get-agreements")
        check_response_code(agreements_data, "/crm/get-agreements")
        raw = agreements_data.get("Agreements") or agreements_data.get("AgreementList") or []
        self._agreements = parse_agreements(raw)
