"""Synchronous wrapper around MyOrlenClient."""
from __future__ import annotations

import asyncio
import threading
from typing import Any

from .client import MyOrlenClient
from .models import Agreement, Balance, Invoice, MeteringPoint, UserInfo


class MyOrlenClientSync:
    """Blocking wrapper around :class:`MyOrlenClient`.

    Runs a dedicated event loop so it works in any synchronous context
    (scripts, Django views, Home Assistant integrations, etc.).

    Usage::

        with MyOrlenClientSync("user@example.com", "password") as client:
            balance = client.get_balance()
            invoices = client.get_invoices()
    """

    def __init__(self, username: str, password: str, *, use_orlenid: bool = False) -> None:
        self._loop = asyncio.new_event_loop()
        self._lock = threading.Lock()
        self._async = MyOrlenClient(username, password, use_orlenid=use_orlenid)
        try:
            self._run(self._async.login())
        except Exception:
            self._loop.close()
            raise

    # ── context manager ───────────────────────────────────────────────────────

    def __enter__(self) -> "MyOrlenClientSync":
        return self

    def __exit__(self, *_: Any) -> None:
        self.close()

    # ── properties (no I/O — safe to expose directly) ─────────────────────────

    @property
    def user_info(self) -> UserInfo:
        return self._async.user_info

    @property
    def agreements(self) -> list[Agreement]:
        return self._async.agreements

    @property
    def metering_points(self) -> list[MeteringPoint]:
        return self._async.metering_points

    # ── API methods ───────────────────────────────────────────────────────────

    def get_balance(self) -> Balance:
        return self._run(self._async.get_balance())

    def get_invoices(self, *, page: int = 1, page_size: int = 12) -> list[Invoice]:
        return self._run(self._async.get_invoices(page=page, page_size=page_size))

    def get_invoice_pdf(self, invoice_number: str) -> bytes:
        return self._run(self._async.get_invoice_pdf(invoice_number))

    def close(self) -> None:
        """Close the HTTP session and shut down the event loop."""
        self._run(self._async.close())
        self._loop.close()

    # ── internal ──────────────────────────────────────────────────────────────

    def _run(self, coro: Any) -> Any:
        with self._lock:
            return self._loop.run_until_complete(coro)
