"""Internal helpers: device ID generation and response parsing."""
from __future__ import annotations

import uuid
from datetime import date, datetime, timezone

from .exceptions import MyOrlenAPIError
from .models import Address, Agreement, Balance, Invoice, MeteringPoint, UserInfo


def generate_device_id() -> str:
    """Return a random 32-char hex device ID."""
    return uuid.uuid4().hex


def _parse_date(value: str | None) -> date | None:
    if not value:
        return None
    # Handles ISO date "2025-01-01" and ISO datetime "2025-01-01T00:00:00"
    try:
        return date.fromisoformat(value[:10])
    except ValueError:
        return None


def _parse_address(data: dict) -> Address:
    street_type = data.get("UlicaTyp", "")
    street_name = data.get("Ulica", "")
    street = f"{street_type} {street_name}".strip() if street_type else street_name
    return Address(
        street=street,
        house_number=data.get("NrBudynku", ""),
        zip_code=data.get("KodPocztowy", ""),
        city=data.get("Miejscowosc", ""),
        apartment_number=data.get("NrLokalu") or None,
    )


def _parse_metering_point(data: dict) -> MeteringPoint:
    addr_data = data.get("Address")
    return MeteringPoint(
        ppg_id=str(data.get("IdPPG", "")),
        meter_number=data.get("MeterNumber", ""),
        tariff=data.get("Tariff", ""),
        address=_parse_address(addr_data) if addr_data else None,
        contract_number=data.get("ContractNumber"),
        last_reading_date=_parse_date(data.get("ReadingDateUtc")),
        last_reading_value=data.get("ReadingValue"),
    )


def _parse_agreement(data: dict) -> Agreement:
    addr_data = data.get("Address")
    return Agreement(
        agreement_number=data.get("AgreementNumber", ""),
        client_number=data.get("ClientNumber", ""),
        active=bool(data.get("Active", False)),
        start_date=_parse_date(data.get("StartDate")),
        end_date=_parse_date(data.get("EndDate")),
        address=_parse_address(addr_data) if addr_data else None,
    )


def _parse_user_info(data: dict) -> UserInfo:
    return UserInfo(
        email=data.get("Email", ""),
        first_name=data.get("FirstName", ""),
        last_name=data.get("LastName", ""),
        client_number=data.get("ClientNumber"),
    )


def parse_balance(data: dict) -> Balance:
    return Balance(
        value=data.get("Value", 0.0),
        amount_to_pay=data.get("AmountToPay", 0.0),
    )


def parse_invoice(data: dict) -> Invoice:
    return Invoice(
        invoice_number=data.get("Number", ""),
        issue_date=_parse_date(data.get("Date")),
        amount=float(data.get("GrossAmount", 0.0)),
        downloadable=bool(data.get("PDFPrintAllowed", False)),
        is_paid=bool(data.get("IsPaid", False)),
        payment_deadline=_parse_date(data.get("PayingDeadlineDate")),
        sell_date=_parse_date(data.get("SellDate")),
        period_start=_parse_date(data.get("StartDate")),
        period_end=_parse_date(data.get("EndDate")),
        wear_m3=data.get("WearM3"),
        wear_kwh=data.get("WearKWH"),
        agreement_number=data.get("AgreementNumber"),
    )


def parse_invoice_list(data: dict | list) -> list[Invoice]:
    if isinstance(data, list):
        items = data
    else:
        items = data.get("InvoicesList") or data.get("InvoiceList") or data.get("Invoices") or []
    return [parse_invoice(i) for i in items]


def parse_metering_points(data: dict) -> list[MeteringPoint]:
    return [_parse_metering_point(p) for p in data.get("PpgList", [])]


def parse_agreements(data: dict | list) -> list[Agreement]:
    if isinstance(data, list):
        items = data
    else:
        items = data.get("Agreements") or data.get("AgreementList") or []
    return [_parse_agreement(a) for a in items]


def check_response_code(data: dict, path: str) -> None:
    """Raise MyOrlenAPIError if the response Code field indicates failure."""
    code = data.get("Code", 0)
    if code != 0:
        msg = data.get("Message") or data.get("EndUserMessage") or f"API error code {code}"
        raise MyOrlenAPIError(f"{msg} [{path}]", code)


def token_expires_at(date_expiration_utc: str) -> datetime:
    """Parse DateExpirationUtc into an aware datetime."""
    dt = datetime.fromisoformat(date_expiration_utc.replace("Z", "+00:00"))
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt
