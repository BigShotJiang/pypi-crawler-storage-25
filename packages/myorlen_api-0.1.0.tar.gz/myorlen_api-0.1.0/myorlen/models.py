from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date


@dataclass
class Address:
    street: str
    house_number: str
    zip_code: str
    city: str
    apartment_number: str | None = None

    def __str__(self) -> str:
        apt = f"/{self.apartment_number}" if self.apartment_number else ""
        return f"{self.street} {self.house_number}{apt}, {self.zip_code} {self.city}"


@dataclass
class MeteringPoint:
    """Gas metering point (Punkt Poboru Gazu)."""
    ppg_id: str
    meter_number: str
    tariff: str
    address: Address | None = None
    contract_number: str | None = None
    last_reading_date: date | None = None
    last_reading_value: float | None = None


@dataclass
class Agreement:
    """Gas supply agreement."""
    agreement_number: str
    client_number: str
    active: bool
    start_date: date | None = None
    end_date: date | None = None
    address: Address | None = None


@dataclass
class UserInfo:
    email: str
    first_name: str
    last_name: str
    client_number: str | None = None


@dataclass
class Balance:
    value: float
    amount_to_pay: float


@dataclass
class Invoice:
    invoice_number: str
    issue_date: date | None
    amount: float
    downloadable: bool
    is_paid: bool = False
    payment_deadline: date | None = None
    sell_date: date | None = None
    period_start: date | None = None
    period_end: date | None = None
    wear_m3: float | None = None
    wear_kwh: float | None = None
    agreement_number: str | None = None
