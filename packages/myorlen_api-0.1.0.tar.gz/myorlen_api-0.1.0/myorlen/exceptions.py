class MyOrlenError(Exception):
    """Base exception for all myORLEN errors."""


class MyOrlenAuthError(MyOrlenError):
    """Authentication failed or session expired."""


class MyOrlenNotFoundError(MyOrlenError):
    """Requested resource does not exist."""


class MyOrlenForbiddenError(MyOrlenError):
    """Access to the resource is denied."""


class MyOrlenAPIError(MyOrlenError):
    """Unexpected API error."""

    def __init__(self, message: str, status_code: int) -> None:
        super().__init__(message)
        self.status_code = status_code
