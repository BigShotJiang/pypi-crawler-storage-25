"""MCP server exposing myORLEN eBOK self-care portal as tools.

Run with:
    uv run python -m myorlen.mcp_server
    myorlen-mcp                            # after pip install myorlen-api[mcp]

Credentials — set one of the following pairs:
    ORLENID_USERNAME / ORLENID_PASSWORD   — OrlenID (oid-ws.orlen.pl) credentials
                                            Takes priority if both pairs are set.
    MYORLEN_USERNAME / MYORLEN_PASSWORD   — native myORLEN eBOK credentials
"""
from __future__ import annotations

import json
import os
import sys
import tempfile
from contextlib import asynccontextmanager
from typing import Any, AsyncIterator

try:
    from mcp.server.fastmcp import FastMCP
except ImportError:
    sys.exit(
        "The 'mcp' package is required to run the MCP server.\n"
        "Install it with:  pip install myorlen-api[mcp]"
    )

from .client import MyOrlenClient
from .exceptions import (
    MyOrlenAPIError,
    MyOrlenAuthError,
    MyOrlenForbiddenError,
    MyOrlenNotFoundError,
)
from .models import Agreement, Balance, Invoice, MeteringPoint, UserInfo


# ── serialisation helpers ─────────────────────────────────────────────────────

def _user_info_to_dict(u: UserInfo) -> dict[str, Any]:
    return {
        "email": u.email,
        "first_name": u.first_name,
        "last_name": u.last_name,
        "client_number": u.client_number,
    }


def _agreement_to_dict(a: Agreement) -> dict[str, Any]:
    d: dict[str, Any] = {
        "agreement_number": a.agreement_number,
        "client_number": a.client_number,
        "active": a.active,
        "start_date": a.start_date.isoformat() if a.start_date else None,
        "end_date": a.end_date.isoformat() if a.end_date else None,
    }
    if a.address:
        d["address"] = {
            "street": a.address.street,
            "house_number": a.address.house_number,
            "apartment_number": a.address.apartment_number,
            "zip_code": a.address.zip_code,
            "city": a.address.city,
        }
    return d


def _metering_point_to_dict(mp: MeteringPoint) -> dict[str, Any]:
    d: dict[str, Any] = {
        "ppg_id": mp.ppg_id,
        "meter_number": mp.meter_number,
        "tariff": mp.tariff,
        "contract_number": mp.contract_number,
        "last_reading_date": mp.last_reading_date.isoformat() if mp.last_reading_date else None,
        "last_reading_value": mp.last_reading_value,
    }
    if mp.address:
        d["address"] = {
            "street": mp.address.street,
            "house_number": mp.address.house_number,
            "apartment_number": mp.address.apartment_number,
            "zip_code": mp.address.zip_code,
            "city": mp.address.city,
        }
    return d


def _balance_to_dict(b: Balance) -> dict[str, Any]:
    return {
        "value": b.value,
        "amount_to_pay": b.amount_to_pay,
    }


def _invoice_to_dict(inv: Invoice) -> dict[str, Any]:
    return {
        "invoice_number": inv.invoice_number,
        "issue_date": inv.issue_date.isoformat() if inv.issue_date else None,
        "amount": inv.amount,
        "is_paid": inv.is_paid,
        "payment_deadline": inv.payment_deadline.isoformat() if inv.payment_deadline else None,
        "sell_date": inv.sell_date.isoformat() if inv.sell_date else None,
        "period_start": inv.period_start.isoformat() if inv.period_start else None,
        "period_end": inv.period_end.isoformat() if inv.period_end else None,
        "wear_m3": inv.wear_m3,
        "wear_kwh": inv.wear_kwh,
        "agreement_number": inv.agreement_number,
        "downloadable": inv.downloadable,
    }


# ── lifespan: single shared client ───────────────────────────────────────────

_client: MyOrlenClient | None = None


def _env(key: str) -> str:
    """Return env var value, treating unexpanded ${...} placeholders as empty."""
    val = os.environ.get(key, "")
    return "" if val.startswith("${") else val


@asynccontextmanager
async def lifespan(_app: Any) -> AsyncIterator[None]:
    global _client
    orlenid_user  = _env("ORLENID_USERNAME")
    orlenid_pass  = _env("ORLENID_PASSWORD")
    myorlen_user  = _env("MYORLEN_USERNAME")
    myorlen_pass  = _env("MYORLEN_PASSWORD")

    if orlenid_user and orlenid_pass:
        username, password, use_orlenid = orlenid_user, orlenid_pass, True
    elif myorlen_user and myorlen_pass:
        username, password, use_orlenid = myorlen_user, myorlen_pass, False
    else:
        sys.exit(
            "Set ORLENID_USERNAME/ORLENID_PASSWORD (OrlenID) "
            "or MYORLEN_USERNAME/MYORLEN_PASSWORD (native) environment variables."
        )
    _client = MyOrlenClient(username, password, use_orlenid=use_orlenid)
    await _client.login()
    try:
        yield
    finally:
        await _client.close()
        _client = None


mcp = FastMCP("myORLEN", lifespan=lifespan)


def _get_client() -> MyOrlenClient:
    if _client is None:
        raise RuntimeError("Client not initialised.")
    return _client


# ── tools ─────────────────────────────────────────────────────────────────────

@mcp.tool()
def get_account_info() -> str:
    """Get user profile, gas supply agreements and metering points.

    Returns JSON with:
    - user: name, email, client number
    - agreements: list of gas supply agreements (number, status, dates)
    - metering_points: list of PPG meters (ID, meter number, tariff, address)

    No network request is made — data is cached at login.
    """
    try:
        client = _get_client()
        return json.dumps(
            {
                "user": _user_info_to_dict(client.user_info),
                "agreements": [_agreement_to_dict(a) for a in client.agreements],
                "metering_points": [_metering_point_to_dict(mp) for mp in client.metering_points],
            },
            ensure_ascii=False,
        )
    except MyOrlenAuthError as e:
        raise ValueError(f"Authentication error: {e}. Restart the MCP server.") from e


@mcp.tool()
async def get_balance() -> str:
    """Get the current gas account balance.

    Returns JSON with:
    - value: current balance in PLN (negative = credit/overpayment)
    - amount_to_pay: outstanding amount to pay in PLN
    """
    client = _get_client()
    try:
        balance = await client.get_balance()
        return json.dumps(_balance_to_dict(balance))
    except MyOrlenAuthError as e:
        raise ValueError(f"Authentication error: {e}. Restart the MCP server.") from e
    except MyOrlenAPIError as e:
        raise ValueError(f"myORLEN API error (code {e.status_code}): {e}") from e


@mcp.tool()
async def get_invoices(page: int = 1, page_size: int = 12) -> str:
    """List gas invoices.

    Args:
        page:       Page number, 1-based (default 1).
        page_size:  Number of invoices per page (default 12).

    Returns a JSON array of invoice objects. Each invoice includes:
    invoice_number, issue_date, amount (PLN), is_paid, payment_deadline,
    gas consumption (wear_m3, wear_kwh), billing period, agreement_number,
    and a 'downloadable' flag indicating whether download_invoice can be called.
    """
    client = _get_client()
    try:
        invoices = await client.get_invoices(page=page, page_size=page_size)
        return json.dumps([_invoice_to_dict(i) for i in invoices], ensure_ascii=False)
    except MyOrlenAuthError as e:
        raise ValueError(f"Authentication error: {e}. Restart the MCP server.") from e
    except MyOrlenAPIError as e:
        raise ValueError(f"myORLEN API error (code {e.status_code}): {e}") from e


@mcp.tool()
async def download_invoice(invoice_number: str) -> str:
    """Download an invoice PDF and save it to a temporary file.

    Only call this for invoices where downloadable=true (from get_invoices).

    Args:
        invoice_number: The invoice_number field from get_invoices (e.g. "P/100200/0001/25/5").

    Returns JSON with the absolute file path and file size in bytes.
    The file is saved to the system temp directory.
    """
    client = _get_client()
    try:
        pdf_bytes = await client.get_invoice_pdf(invoice_number)
    except MyOrlenForbiddenError as e:
        raise ValueError(
            f"The server denied access to invoice {invoice_number}. "
            "This restriction also applies in the browser and cannot be bypassed."
        ) from e
    except MyOrlenNotFoundError as e:
        raise ValueError(f"Invoice {invoice_number} not found.") from e
    except MyOrlenAuthError as e:
        raise ValueError(f"Authentication error: {e}. Restart the MCP server.") from e
    except MyOrlenAPIError as e:
        raise ValueError(f"myORLEN API error (code {e.status_code}): {e}") from e

    safe_name = invoice_number.replace("/", "_")
    fd, path = tempfile.mkstemp(suffix=".pdf", prefix=f"myorlen_{safe_name}_")
    try:
        os.write(fd, pdf_bytes)
    finally:
        os.close(fd)

    return json.dumps({"path": path, "size_bytes": len(pdf_bytes), "invoice_number": invoice_number})


# ── entry point ───────────────────────────────────────────────────────────────

def main() -> None:
    mcp.run()


if __name__ == "__main__":
    main()
