"""Tests for myorlen.mcp_server — serialisation helpers and tool handlers."""
from __future__ import annotations

import json
import os
from datetime import date
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from myorlen.exceptions import (
    MyOrlenAPIError,
    MyOrlenAuthError,
    MyOrlenForbiddenError,
    MyOrlenNotFoundError,
)
from myorlen.models import Address, Agreement, Balance, Invoice, MeteringPoint, UserInfo
from myorlen.mcp_server import (
    _agreement_to_dict,
    _balance_to_dict,
    _invoice_to_dict,
    _metering_point_to_dict,
    _user_info_to_dict,
    download_invoice,
    get_account_info,
    get_balance,
    get_invoices,
)


# ── fixtures ──────────────────────────────────────────────────────────────────

@pytest.fixture
def sample_address():
    return Address("ul. Lipowa", "12", "80-001", "Gdańsk", apartment_number="3")


@pytest.fixture
def sample_metering_point(sample_address):
    return MeteringPoint(
        ppg_id="PPG-001",
        meter_number="M001",
        tariff="W-2.1",
        address=sample_address,
        contract_number="UMOWA-001",
        last_reading_date=date(2025, 3, 31),
        last_reading_value=1234.5,
    )


@pytest.fixture
def sample_agreement(sample_address):
    return Agreement(
        agreement_number="11141UN00000000001",
        client_number="C001",
        active=True,
        start_date=date(2020, 1, 1),
        end_date=None,
        address=sample_address,
    )


@pytest.fixture
def sample_user():
    return UserInfo(
        email="jan@example.com",
        first_name="JAN",
        last_name="KOWALSKI",
        client_number="100200",
    )


@pytest.fixture
def sample_balance():
    return Balance(value=0.0, amount_to_pay=120.50)


@pytest.fixture
def sample_invoice():
    return Invoice(
        invoice_number="P/100200/0001/25/5",
        issue_date=date(2025, 4, 23),
        amount=644.83,
        downloadable=True,
        is_paid=True,
        payment_deadline=date(2025, 5, 7),
        sell_date=date(2025, 3, 31),
        period_start=date(2025, 1, 1),
        period_end=date(2025, 3, 31),
        wear_m3=312.5,
        wear_kwh=3280.0,
        agreement_number="11141UN00000000001",
    )


@pytest.fixture
def mock_client(sample_user, sample_agreement, sample_metering_point, sample_balance, sample_invoice):
    client = MagicMock()
    client.user_info = sample_user
    client.agreements = [sample_agreement]
    client.metering_points = [sample_metering_point]
    client.get_balance = AsyncMock(return_value=sample_balance)
    client.get_invoices = AsyncMock(return_value=[sample_invoice])
    client.get_invoice_pdf = AsyncMock(return_value=b"%PDF-1.4 fake content")
    return client


# ── serialisation helpers ─────────────────────────────────────────────────────

class TestUserInfoToDict:
    def test_fields(self, sample_user):
        d = _user_info_to_dict(sample_user)
        assert d["email"] == "jan@example.com"
        assert d["first_name"] == "JAN"
        assert d["last_name"] == "KOWALSKI"
        assert d["client_number"] == "100200"


class TestAgreementToDict:
    def test_fields(self, sample_agreement):
        d = _agreement_to_dict(sample_agreement)
        assert d["agreement_number"] == "11141UN00000000001"
        assert d["client_number"] == "C001"
        assert d["active"] is True
        assert d["start_date"] == "2020-01-01"
        assert d["end_date"] is None

    def test_address_included(self, sample_agreement):
        addr = _agreement_to_dict(sample_agreement)["address"]
        assert addr["street"] == "ul. Lipowa"
        assert addr["city"] == "Gdańsk"
        assert addr["apartment_number"] == "3"

    def test_no_address(self):
        ag = Agreement("AGR-X", "C-X", active=False)
        d = _agreement_to_dict(ag)
        assert "address" not in d


class TestMeteringPointToDict:
    def test_fields(self, sample_metering_point):
        d = _metering_point_to_dict(sample_metering_point)
        assert d["ppg_id"] == "PPG-001"
        assert d["meter_number"] == "M001"
        assert d["tariff"] == "W-2.1"
        assert d["contract_number"] == "UMOWA-001"
        assert d["last_reading_date"] == "2025-03-31"
        assert d["last_reading_value"] == 1234.5

    def test_address_included(self, sample_metering_point):
        addr = _metering_point_to_dict(sample_metering_point)["address"]
        assert addr["city"] == "Gdańsk"

    def test_no_address(self):
        mp = MeteringPoint(ppg_id="X", meter_number="M", tariff="W-1")
        d = _metering_point_to_dict(mp)
        assert "address" not in d


class TestBalanceToDict:
    def test_fields(self, sample_balance):
        d = _balance_to_dict(sample_balance)
        assert d["value"] == 0.0
        assert d["amount_to_pay"] == 120.50


class TestInvoiceToDict:
    def test_fields(self, sample_invoice):
        d = _invoice_to_dict(sample_invoice)
        assert d["invoice_number"] == "P/100200/0001/25/5"
        assert d["amount"] == 644.83
        assert d["is_paid"] is True
        assert d["downloadable"] is True
        assert d["wear_m3"] == 312.5
        assert d["wear_kwh"] == 3280.0
        assert d["agreement_number"] == "11141UN00000000001"

    def test_dates_as_iso(self, sample_invoice):
        d = _invoice_to_dict(sample_invoice)
        assert d["issue_date"] == "2025-04-23"
        assert d["payment_deadline"] == "2025-05-07"
        assert d["sell_date"] == "2025-03-31"
        assert d["period_start"] == "2025-01-01"
        assert d["period_end"] == "2025-03-31"

    def test_null_dates(self, sample_invoice):
        sample_invoice.payment_deadline = None
        sample_invoice.sell_date = None
        d = _invoice_to_dict(sample_invoice)
        assert d["payment_deadline"] is None
        assert d["sell_date"] is None

    def test_not_downloadable(self, sample_invoice):
        sample_invoice.downloadable = False
        assert _invoice_to_dict(sample_invoice)["downloadable"] is False


# ── tool: get_account_info ────────────────────────────────────────────────────

class TestGetAccountInfo:
    def test_returns_json_with_all_sections(self, mock_client):
        with patch("myorlen.mcp_server._client", mock_client):
            result = get_account_info()
        data = json.loads(result)
        assert "user" in data
        assert "agreements" in data
        assert "metering_points" in data

    def test_user_fields(self, mock_client):
        with patch("myorlen.mcp_server._client", mock_client):
            result = get_account_info()
        user = json.loads(result)["user"]
        assert user["email"] == "jan@example.com"
        assert user["first_name"] == "JAN"

    def test_one_agreement(self, mock_client):
        with patch("myorlen.mcp_server._client", mock_client):
            result = get_account_info()
        assert len(json.loads(result)["agreements"]) == 1

    def test_one_metering_point(self, mock_client):
        with patch("myorlen.mcp_server._client", mock_client):
            result = get_account_info()
        assert len(json.loads(result)["metering_points"]) == 1


# ── tool: get_balance ─────────────────────────────────────────────────────────

class TestGetBalance:
    async def test_returns_json(self, mock_client):
        with patch("myorlen.mcp_server._client", mock_client):
            result = await get_balance()
        data = json.loads(result)
        assert data["value"] == 0.0
        assert data["amount_to_pay"] == 120.50

    async def test_auth_error_raises_value_error(self, mock_client):
        mock_client.get_balance = AsyncMock(side_effect=MyOrlenAuthError("expired"))
        with patch("myorlen.mcp_server._client", mock_client):
            with pytest.raises(ValueError, match="Authentication error"):
                await get_balance()

    async def test_api_error_raises_value_error(self, mock_client):
        mock_client.get_balance = AsyncMock(side_effect=MyOrlenAPIError("server error", 500))
        with patch("myorlen.mcp_server._client", mock_client):
            with pytest.raises(ValueError, match="500"):
                await get_balance()


# ── tool: get_invoices ────────────────────────────────────────────────────────

class TestGetInvoices:
    async def test_returns_json_array(self, mock_client):
        with patch("myorlen.mcp_server._client", mock_client):
            result = await get_invoices()
        data = json.loads(result)
        assert len(data) == 1
        assert data[0]["invoice_number"] == "P/100200/0001/25/5"

    async def test_passes_pagination_to_client(self, mock_client):
        with patch("myorlen.mcp_server._client", mock_client):
            await get_invoices(page=2, page_size=24)
        mock_client.get_invoices.assert_awaited_once_with(page=2, page_size=24)

    async def test_downloadable_flag_preserved(self, mock_client):
        with patch("myorlen.mcp_server._client", mock_client):
            result = await get_invoices()
        assert json.loads(result)[0]["downloadable"] is True

    async def test_auth_error_raises(self, mock_client):
        mock_client.get_invoices = AsyncMock(side_effect=MyOrlenAuthError("expired"))
        with patch("myorlen.mcp_server._client", mock_client):
            with pytest.raises(ValueError, match="Authentication error"):
                await get_invoices()


# ── tool: download_invoice ────────────────────────────────────────────────────

class TestDownloadInvoice:
    async def test_saves_file_and_returns_path(self, mock_client):
        with patch("myorlen.mcp_server._client", mock_client):
            result = await download_invoice("P/100200/0001/25/5")
        data = json.loads(result)
        assert os.path.exists(data["path"])
        assert data["size_bytes"] == len(b"%PDF-1.4 fake content")
        assert data["invoice_number"] == "P/100200/0001/25/5"
        os.unlink(data["path"])

    async def test_file_contains_pdf_bytes(self, mock_client):
        with patch("myorlen.mcp_server._client", mock_client):
            result = await download_invoice("P/100200/0001/25/5")
        path = json.loads(result)["path"]
        assert open(path, "rb").read() == b"%PDF-1.4 fake content"
        os.unlink(path)

    async def test_slashes_replaced_in_filename(self, mock_client):
        with patch("myorlen.mcp_server._client", mock_client):
            result = await download_invoice("P/100200/0001/25/5")
        path = json.loads(result)["path"]
        assert "/" not in os.path.basename(path)
        os.unlink(path)

    async def test_forbidden_raises_value_error(self, mock_client):
        mock_client.get_invoice_pdf = AsyncMock(side_effect=MyOrlenForbiddenError("denied"))
        with patch("myorlen.mcp_server._client", mock_client):
            with pytest.raises(ValueError, match="denied access"):
                await download_invoice("P/100200/0001/25/5")

    async def test_not_found_raises_value_error(self, mock_client):
        mock_client.get_invoice_pdf = AsyncMock(side_effect=MyOrlenNotFoundError("not found"))
        with patch("myorlen.mcp_server._client", mock_client):
            with pytest.raises(ValueError, match="not found"):
                await download_invoice("P/100200/0001/25/5")

    async def test_auth_error_raises(self, mock_client):
        mock_client.get_invoice_pdf = AsyncMock(side_effect=MyOrlenAuthError("expired"))
        with patch("myorlen.mcp_server._client", mock_client):
            with pytest.raises(ValueError, match="Authentication error"):
                await download_invoice("P/100200/0001/25/5")
