"""Unit tests for myorlen.exceptions hierarchy."""
from __future__ import annotations

import pytest

from myorlen.exceptions import (
    MyOrlenAPIError,
    MyOrlenAuthError,
    MyOrlenError,
    MyOrlenForbiddenError,
    MyOrlenNotFoundError,
)


def test_hierarchy():
    assert issubclass(MyOrlenAuthError, MyOrlenError)
    assert issubclass(MyOrlenForbiddenError, MyOrlenError)
    assert issubclass(MyOrlenNotFoundError, MyOrlenError)
    assert issubclass(MyOrlenAPIError, MyOrlenError)


def test_api_error_stores_status_code():
    err = MyOrlenAPIError("server error", 500)
    assert err.status_code == 500
    assert "server error" in str(err)


def test_all_catchable_as_base():
    for cls in (MyOrlenAuthError, MyOrlenForbiddenError, MyOrlenNotFoundError):
        with pytest.raises(MyOrlenError):
            raise cls("test")
