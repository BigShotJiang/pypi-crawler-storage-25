"""Unit tests for myorlen._helpers — all pure functions, no I/O."""
from __future__ import annotations

from datetime import date, datetime, timezone

import pytest

from myorlen._helpers import (
    _parse_user_info,
    check_response_code,
    generate_device_id,
    parse_agreements,
    parse_balance,
    parse_invoice,
    parse_invoice_list,
    parse_metering_points,
    token_expires_at,
)
from myorlen.exceptions import MyOrlenAPIError


# ── generate_device_id ────────────────────────────────────────────────────────

class TestGenerateDeviceId:
    def test_returns_32_chars(self):
        assert len(generate_device_id()) == 32

    def test_hex_only(self):
        did = generate_device_id()
        assert all(c in "0123456789abcdef" for c in did)

    def test_unique_each_call(self):
        assert generate_device_id() != generate_device_id()


# ── token_expires_at ──────────────────────────────────────────────────────────

class TestTokenExpiresAt:
    def test_parses_z_suffix(self):
        dt = token_expires_at("2026-03-27T14:00:00Z")
        assert dt == datetime(2026, 3, 27, 14, 0, 0, tzinfo=timezone.utc)

    def test_parses_offset(self):
        dt = token_expires_at("2026-03-27T14:00:00+00:00")
        assert dt.tzinfo is not None

    def test_naive_gets_utc(self):
        dt = token_expires_at("2026-03-27T14:00:00")
        assert dt.tzinfo == timezone.utc


# ── check_response_code ───────────────────────────────────────────────────────

class TestCheckResponseCode:
    def test_zero_is_ok(self):
        check_response_code({"Code": 0}, "/test")  # no exception

    def test_nonzero_raises(self):
        with pytest.raises(MyOrlenAPIError):
            check_response_code({"Code": 1025, "Message": "Soft blocked."}, "/auth/login")

    def test_error_message_included(self):
        with pytest.raises(MyOrlenAPIError, match="Soft blocked"):
            check_response_code({"Code": 1025, "Message": "Soft blocked."}, "/auth/login")

    def test_missing_code_defaults_to_ok(self):
        check_response_code({}, "/test")  # Code defaults to 0


# ── parse_balance ─────────────────────────────────────────────────────────────

class TestParseBalance:
    def test_fields(self, balance_data):
        b = parse_balance(balance_data)
        assert b.value == 0.0
        assert b.amount_to_pay == 120.50

    def test_missing_fields_default_to_zero(self):
        b = parse_balance({"Code": 0})
        assert b.value == 0.0
        assert b.amount_to_pay == 0.0


# ── parse_invoice / parse_invoice_list ───────────────────────────────────────

class TestParseInvoice:
    def _raw(self):
        return {
            "Number": "P/100200/0001/25/5",
            "Date": "2025-04-23",
            "SellDate": "2025-03-31",
            "GrossAmount": 644.83,
            "IsPaid": True,
            "PayingDeadlineDate": "2025-05-07",
            "StartDate": "2025-01-01",
            "EndDate": "2025-03-31",
            "PDFPrintAllowed": True,
            "AgreementNumber": "11141UN00000000001",
            "WearM3": 312.5,
            "WearKWH": 3280.0,
        }

    def test_basic_fields(self):
        inv = parse_invoice(self._raw())
        assert inv.invoice_number == "P/100200/0001/25/5"
        assert inv.amount == 644.83
        assert inv.is_paid is True
        assert inv.agreement_number == "11141UN00000000001"

    def test_dates(self):
        inv = parse_invoice(self._raw())
        assert inv.issue_date == date(2025, 4, 23)
        assert inv.sell_date == date(2025, 3, 31)
        assert inv.payment_deadline == date(2025, 5, 7)
        assert inv.period_start == date(2025, 1, 1)
        assert inv.period_end == date(2025, 3, 31)

    def test_downloadable_true(self):
        assert parse_invoice(self._raw()).downloadable is True

    def test_downloadable_false(self):
        raw = self._raw()
        raw["PDFPrintAllowed"] = False
        assert parse_invoice(raw).downloadable is False

    def test_wear_fields(self):
        inv = parse_invoice(self._raw())
        assert inv.wear_m3 == 312.5
        assert inv.wear_kwh == 3280.0

    def test_null_wear_fields(self):
        raw = self._raw()
        raw["WearM3"] = None
        raw["WearKWH"] = None
        inv = parse_invoice(raw)
        assert inv.wear_m3 is None
        assert inv.wear_kwh is None

    def test_unpaid(self):
        raw = self._raw()
        raw["IsPaid"] = False
        assert parse_invoice(raw).is_paid is False


class TestParseInvoiceList:
    def test_from_dict_invoices_list_key(self, invoices_data):
        items = parse_invoice_list(invoices_data)
        assert len(items) == 2

    def test_from_list(self, invoices_data):
        items = parse_invoice_list(invoices_data["InvoicesList"])
        assert len(items) == 2

    def test_first_downloadable_second_not(self, invoices_data):
        items = parse_invoice_list(invoices_data)
        assert items[0].downloadable is True
        assert items[1].downloadable is False

    def test_first_paid_second_unpaid(self, invoices_data):
        items = parse_invoice_list(invoices_data)
        assert items[0].is_paid is True
        assert items[1].is_paid is False

    def test_empty_list(self):
        assert parse_invoice_list([]) == []

    def test_empty_dict(self):
        assert parse_invoice_list({}) == []


# ── parse_metering_points ─────────────────────────────────────────────────────

class TestParseMeteringPoints:
    def test_count(self, ppg_list_data):
        pts = parse_metering_points(ppg_list_data)
        assert len(pts) == 1

    def test_fields(self, ppg_list_data):
        mp = parse_metering_points(ppg_list_data)[0]
        assert mp.ppg_id == "0000000000000000000001"
        assert mp.meter_number == "0000000000000000000001"
        assert mp.tariff == "W-2.1"
        assert mp.contract_number == "UMOWA-001"
        assert mp.last_reading_value == 1234.5
        assert mp.last_reading_date == date(2025, 3, 31)

    def test_address(self, ppg_list_data):
        addr = parse_metering_points(ppg_list_data)[0].address
        assert addr is not None
        assert addr.street == "ul. Przykładowa"
        assert addr.house_number == "1"
        assert addr.apartment_number == "2"
        assert addr.zip_code == "00-001"
        assert addr.city == "Warszawa"

    def test_empty_ppg_list(self):
        assert parse_metering_points({"PpgList": []}) == []


# ── parse_agreements ──────────────────────────────────────────────────────────

class TestParseAgreements:
    def test_count(self, agreements_data):
        ags = parse_agreements(agreements_data.get("Agreements", []))
        assert len(ags) == 1

    def test_fields(self, agreements_data):
        ag = parse_agreements(agreements_data.get("Agreements", []))[0]
        assert ag.agreement_number == "11141UN00000000001"
        assert ag.client_number == "100200"
        assert ag.active is True
        assert ag.start_date == date(2020, 1, 1)
        assert ag.end_date is None

    def test_address(self, agreements_data):
        ag = parse_agreements(agreements_data.get("Agreements", []))[0]
        assert ag.address is not None
        assert ag.address.city == "Warszawa"

    def test_empty_list(self):
        assert parse_agreements([]) == []


# ── _parse_user_info ──────────────────────────────────────────────────────────

class TestParseUserInfo:
    def test_fields(self, user_data):
        u = _parse_user_info(user_data)
        assert u.email == "jan.kowalski@example.com"
        assert u.first_name == "JAN"
        assert u.last_name == "KOWALSKI"
        assert u.client_number == "100200"

    def test_missing_client_number(self):
        u = _parse_user_info({"Email": "a@b.com", "FirstName": "A", "LastName": "B"})
        assert u.client_number is None
