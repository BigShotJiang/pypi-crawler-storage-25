"""Unit tests for myorlen.models dataclasses."""
from __future__ import annotations

from datetime import date

from myorlen.models import Address, Agreement, Balance, Invoice, MeteringPoint, UserInfo


class TestAddress:
    def test_str_with_apartment(self):
        addr = Address("ul. Lipowa", "12", "80-001", "Gdańsk", apartment_number="3")
        assert str(addr) == "ul. Lipowa 12/3, 80-001 Gdańsk"

    def test_str_without_apartment(self):
        addr = Address("ul. Lipowa", "12", "80-001", "Gdańsk")
        assert str(addr) == "ul. Lipowa 12, 80-001 Gdańsk"

    def test_str_no_apartment_none(self):
        addr = Address("ul. Lipowa", "12", "80-001", "Gdańsk", apartment_number=None)
        assert "/" not in str(addr)


class TestMeteringPoint:
    def test_defaults(self):
        mp = MeteringPoint(ppg_id="123", meter_number="M001", tariff="W-2.1")
        assert mp.address is None
        assert mp.contract_number is None
        assert mp.last_reading_date is None
        assert mp.last_reading_value is None


class TestAgreement:
    def test_defaults(self):
        ag = Agreement(agreement_number="AGR-001", client_number="C001", active=True)
        assert ag.start_date is None
        assert ag.end_date is None
        assert ag.address is None


class TestUserInfo:
    def test_defaults(self):
        u = UserInfo(email="a@b.com", first_name="Jan", last_name="Kowalski")
        assert u.client_number is None


class TestBalance:
    def test_fields(self):
        b = Balance(value=-10.5, amount_to_pay=120.0)
        assert b.value == -10.5
        assert b.amount_to_pay == 120.0


class TestInvoice:
    def test_defaults(self):
        inv = Invoice(
            invoice_number="P/001",
            issue_date=date(2025, 1, 1),
            amount=100.0,
            downloadable=True,
        )
        assert inv.is_paid is False
        assert inv.payment_deadline is None
        assert inv.sell_date is None
        assert inv.period_start is None
        assert inv.period_end is None
        assert inv.wear_m3 is None
        assert inv.wear_kwh is None
        assert inv.agreement_number is None
