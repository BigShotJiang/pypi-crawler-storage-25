"""Tests for MyOrlenClient token expiry and re-login behaviour."""
from __future__ import annotations

from datetime import datetime, timedelta, timezone
from unittest.mock import AsyncMock, patch

import pytest

from myorlen.client import MyOrlenClient
from myorlen.exceptions import MyOrlenAuthError


def _make_client() -> MyOrlenClient:
    client = MyOrlenClient("user@example.com", "password")
    client._token = "old.jwt.token"
    client._token_expires_at = datetime(2000, 1, 1, tzinfo=timezone.utc)  # already expired
    return client


class TestEnsureFreshToken:
    async def test_raises_if_no_token(self):
        client = MyOrlenClient("user@example.com", "password")
        with pytest.raises(MyOrlenAuthError, match="Not logged in"):
            await client._ensure_fresh_token()

    async def test_no_relogin_if_token_valid(self):
        client = _make_client()
        client._token_expires_at = datetime.now(tz=timezone.utc) + timedelta(hours=1)
        relogin_mock = AsyncMock()
        with patch.object(client, "_do_relogin", relogin_mock):
            await client._ensure_fresh_token()
        relogin_mock.assert_not_awaited()

    async def test_relogin_if_token_expired(self):
        client = _make_client()
        relogin_mock = AsyncMock()
        with patch.object(client, "_do_relogin", relogin_mock):
            await client._ensure_fresh_token()
        relogin_mock.assert_awaited_once()

    async def test_relogin_if_token_expires_within_60s(self):
        client = _make_client()
        client._token_expires_at = datetime.now(tz=timezone.utc) + timedelta(seconds=30)
        relogin_mock = AsyncMock()
        with patch.object(client, "_do_relogin", relogin_mock):
            await client._ensure_fresh_token()
        relogin_mock.assert_awaited_once()


class TestDoRelogin:
    async def test_calls_login(self):
        client = _make_client()
        login_mock = AsyncMock()
        with patch.object(client, "login", login_mock):
            await client._do_relogin()
        login_mock.assert_awaited_once()

    async def test_counter_resets_to_zero_on_success(self):
        client = _make_client()
        client._relogin_attempts = 0
        with patch.object(client, "login", AsyncMock()):
            await client._do_relogin()
        assert client._relogin_attempts == 0

    async def test_resets_counter_after_login(self):
        client = _make_client()
        client._relogin_attempts = 1
        with patch.object(client, "login", AsyncMock()):
            await client._do_relogin()
        assert client._relogin_attempts == 0

    async def test_raises_after_max_attempts(self):
        client = _make_client()
        client._relogin_attempts = client._MAX_RELOGIN_ATTEMPTS
        with pytest.raises(MyOrlenAuthError, match="re-login"):
            await client._do_relogin()

    async def test_error_message_includes_attempt_count(self):
        client = _make_client()
        client._relogin_attempts = client._MAX_RELOGIN_ATTEMPTS
        with pytest.raises(MyOrlenAuthError) as exc_info:
            await client._do_relogin()
        assert str(client._MAX_RELOGIN_ATTEMPTS) in str(exc_info.value)


class TestCheckStatus:
    def test_401_raises_auth_error(self):
        from unittest.mock import MagicMock
        client = _make_client()
        resp = MagicMock()
        resp.status = 401
        resp.ok = False
        with pytest.raises(MyOrlenAuthError):
            client._check_status(resp, "/test")

    def test_403_raises_forbidden(self):
        from unittest.mock import MagicMock
        from myorlen.exceptions import MyOrlenForbiddenError
        client = _make_client()
        resp = MagicMock()
        resp.status = 403
        resp.ok = False
        with pytest.raises(MyOrlenForbiddenError):
            client._check_status(resp, "/test")

    def test_404_raises_not_found(self):
        from unittest.mock import MagicMock
        from myorlen.exceptions import MyOrlenNotFoundError
        client = _make_client()
        resp = MagicMock()
        resp.status = 404
        resp.ok = False
        with pytest.raises(MyOrlenNotFoundError):
            client._check_status(resp, "/test")

    def test_500_raises_api_error(self):
        from unittest.mock import MagicMock
        from myorlen.exceptions import MyOrlenAPIError
        client = _make_client()
        resp = MagicMock()
        resp.status = 500
        resp.ok = False
        with pytest.raises(MyOrlenAPIError):
            client._check_status(resp, "/test")

    def test_200_ok_no_exception(self):
        from unittest.mock import MagicMock
        client = _make_client()
        resp = MagicMock()
        resp.status = 200
        resp.ok = True
        client._check_status(resp, "/test")  # no exception
