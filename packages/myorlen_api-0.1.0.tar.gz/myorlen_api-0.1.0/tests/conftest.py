"""Shared pytest fixtures."""
from __future__ import annotations

import json
import pathlib

import pytest

FIXTURES = pathlib.Path(__file__).parent / "fixtures"


def load(name: str) -> dict | list:
    return json.loads((FIXTURES / name).read_text())


@pytest.fixture
def login_data() -> dict:
    return load("login_response.json")


@pytest.fixture
def user_data() -> dict:
    return load("user_data.json")


@pytest.fixture
def balance_data() -> dict:
    return load("balance.json")


@pytest.fixture
def invoices_data() -> dict:
    return load("invoices.json")


@pytest.fixture
def ppg_list_data() -> dict:
    return load("ppg_list.json")


@pytest.fixture
def agreements_data() -> dict:
    return load("agreements.json")
