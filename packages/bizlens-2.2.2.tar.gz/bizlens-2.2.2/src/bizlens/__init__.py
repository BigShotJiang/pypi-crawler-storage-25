"""
BizLens v2.2.1 — Integrated Analytics Platform
Descriptive · Diagnostic · Predictive · Forecasting · Optimization · Quality · Project · Text

Features:
- Descriptive Analytics: describe(), compare_sample_population(), BizDesc
- Diagnostic Analytics:
    diagnostic.ttest()             — Independent samples t-test (Student's)
    diagnostic.welch_ttest()       — Welch's t-test (unequal variances)
    diagnostic.paired_ttest()      — Paired / dependent samples t-test
    diagnostic.ztest()             — One-sample and two-sample z-test
    diagnostic.anova()             — One-way ANOVA
    diagnostic.two_way_anova()     — Two-way ANOVA with interaction
    diagnostic.chi_square()        — Chi-square test of independence
    diagnostic.correlation()       — Pearson / Spearman / Kendall correlation
    diagnostic.mann_whitney()      — Non-parametric independent t-test alternative
    diagnostic.kruskal_wallis()    — Non-parametric ANOVA alternative
    diagnostic.normality_test()    — Shapiro-Wilk normality test
- Predictive Analytics:
    predict.linear_regression()    — Simple regression with 95% CI
    predict.multiple_regression()  — Multiple regression with cross-validation
    predict.logistic_regression()  — Binary classification with AUC-ROC
    predict.decision_tree()        — Decision tree classifier / regressor
    predict.confusion_matrix_plot()— Confusion matrix visualisation
- Forecasting:
    forecast.moving_average()      — Simple & weighted moving average
    forecast.exponential_smoothing()— SES / Holt's / Holt-Winters
    forecast.decompose()           — Classical time-series decomposition
    forecast.arima()               — ARIMA / SARIMA forecasting
    forecast.accuracy()            — MAE, RMSE, MAPE, SMAPE, MASE, R²
    forecast.compare()             — Side-by-side method comparison
- Optimization: optimize.linear_program() via PuLP
- Statistical Tables:
    tables.frequency()             — Frequency distribution table
    tables.descriptive_comparison()— Side-by-side stats for multiple columns
    tables.crosstab()              — Cross-tabulation with chi-square test
    tables.correlation_matrix()    — Correlation matrix with significance stars
    tables.group_comparison()      — Descriptive stats by group + ANOVA
    tables.percentile_table()      — Percentile / quantile table with z-scores
    tables.distribution_fit()      — Fit & compare statistical distributions
- Quality / Six Sigma:
    quality.process_capability()   — Cp, Cpk, Pp, Ppk, sigma level, DPMO
    quality.control_chart()        — X-bar, R, IMR, P control charts
    quality.pareto()               — Pareto 80/20 analysis
    quality.fishbone()             — Cause-and-effect (Ishikawa) diagram
- Project Management:
    project.gantt()                — Gantt chart (dates or day numbers)
    project.network()              — CPM network with critical path
    project.pert()                 — PERT analysis with uncertainty
- Text Analytics:
    text.wordcloud()               — Word cloud visualisation
    text.frequency()               — Word / n-gram frequency analysis
    text.sentiment()               — Sentiment analysis (VADER / TextBlob)
    text.tfidf()                   — TF-IDF keyword extraction
- Monte Carlo Simulation:
    simulate.run()                 — Generic Monte Carlo engine
    simulate.npv()                 — NPV under uncertainty
    simulate.bootstrap()           — Bootstrap confidence intervals
    simulate.risk_matrix()         — Risk register simulation
- Prescriptive Analytics:
    prescriptive.lp()              — Linear programming
    prescriptive.integer_lp()      — MILP / Binary IP
    prescriptive.transportation()  — Transportation optimisation
    prescriptive.assignment()      — Assignment (Hungarian method)
    prescriptive.sensitivity()     — Sensitivity analysis
- Deployment:
    deploy.streamlit_app()         — Generate Streamlit dashboard
    deploy.gradio_app()            — Generate Gradio demo
    deploy.show_options()          — All deployment platforms
- Package Discovery:
    packages.ecosystem()           — Full curated analytics ecosystem
    packages.search()              — Search by keyword
    packages.search_pypi()         — Live PyPI lookup
    packages.check_installed()     — Audit installed packages
- Datasets:
    load_dataset()                 — Built-in datasets with citations
    load_from_kaggle()             — Download from Kaggle
    load_from_openml()             — Load from OpenML (free)
    load_from_world_bank()         — Live World Bank data

Version: 2.2.2
Author: Sudhanshu Singh
License: MIT
GitHub: https://github.com/solutiongate-learn/bizlens
"""

from .core import (
    describe,
    compare_sample_population,
    BizDesc,
    diagnostic,
    predict,
    forecast,
    optimize,
    tables,
    quality,
    project,
    text,
    simulate,
    prescriptive,
)

from .datasets import (
    load_dataset,
    list_datasets,
    dataset_info,
    load_from_kaggle,
    load_from_openml,
    load_from_world_bank,
)

from .deploy import deploy, packages

__version__ = "2.2.2"
__author__ = "Sudhanshu Singh"
__email__ = "cc9n8y8tqc@privaterelay.appleid.com"
__license__ = "MIT"
__url__ = "https://github.com/solutiongate-learn/bizlens"

__all__ = [
    # Descriptive
    "describe",
    "compare_sample_population",
    "BizDesc",
    # Diagnostic
    "diagnostic",
    # Predictive
    "predict",
    # Optimization
    "optimize",
    # Statistical Tables
    "tables",
    # Quality / Six Sigma
    "quality",
    # Project Management
    "project",
    # Text Analytics
    "text",
    # Forecasting
    "forecast",
    # Monte Carlo Simulation
    "simulate",
    # Prescriptive Analytics / Operations Research
    "prescriptive",
    # Deployment
    "deploy",
    # Package ecosystem
    "packages",
    # Datasets
    "load_dataset",
    "list_datasets",
    "dataset_info",
    "load_from_kaggle",
    "load_from_openml",
    "load_from_world_bank",
]
