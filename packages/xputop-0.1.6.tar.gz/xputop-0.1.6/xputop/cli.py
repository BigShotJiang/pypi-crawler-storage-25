"""
Command-line interface for xputop.

Subcommands:

    xputop              Launch the interactive TUI dashboard
    xputop config       Show / generate configuration file
    xputop once         Print a single snapshot and exit (scriptable)
    xputop alert-test   Send a test alert email
"""

from __future__ import annotations

import argparse
import json
import os
import sys
import time

from xputop import __version__


# ---------------------------------------------------------------------------
# Chinese help text
# ---------------------------------------------------------------------------

_CHINESE_HELP = """\
xputop v{version} — 通用加速卡（NPU/GPU 等）实时监控工具

用法:
  xputop [选项]                   启动交互式 TUI 仪表盘
  xputop once [--json] [--demo]   打印一次快照后退出
  xputop view <file>              可视化离线日志 (JSONL/CSV)
  xputop config [--generate]      管理配置及后端

【核心控制】:
  -i, --interval SECONDS   刷新间隔（秒），默认 2.0
  -b, --backend NAME       强制指定后端 (auto, npu, nvidia, amd, intel等)
  -n, --procs N            每张卡显示 N 个进程行（默认 3）。0=隐藏，-1=全显

【图表视图】:
  -P, --plot               开启 2D 矩阵历史折线图 ( nvtop 风格 )
  -M, --merge-plot         将所有设备的折线图融合到同一个坐标系叠加显示
  -C, --spark              开启单行迷你曲线视图（sparkline）
  -l, --chart-length N     2D图表与迷你曲线保留的采样点数 (视窗宽度)，默认 120

【系统探针】:
  -c, --cpu                显示 CPU 各核心占用率面板
  -m, --mem                显示系统内存（RAM/Swap）面板
  -D, --disk [PATH]        显示磁盘占用面板，默认监控 / (可接多个挂载点如 /data)

【预设模式】:
  -d, --detail             详情模式模式组合 = --spark -c -m -D
  -a, --detail-all         全面详情模式组合 = -d + 进程树 + 网络 IO 监控

【后台日志采集输出】（支持 SQLite 纯原生录入与 泛用级 SQLAlchemy）:
  -o, --output [PATH]      将采集链路输出到离线文件 (csv/jsonl/sqlite) 或数据库 URI
                           * 若纯打 -o 无参数: 将在当前目录落盘按时间戳格式化成的 csv
                           * 例如 -o xputop_log.sqlite 则原生创建并使用 SQLite
                           * 例如 -o mysql://user:pass@host/db 则以 SQLAlchemy 录入表
  --format TYPE            强制指定日志保存格式 (可选: csv/jsonl/sqlite/md/mysql等)
                           * 默认会根据 -o 提供的后缀名自动推断出正确的文件处理链

【其他管理】:
  --demo                   演示模式（无需真实硬件，显示伪造心跳波形）
  --list-backends          列出所有可用后端及状态
  --reset-backend          清除由于 --backend 后保留的驱动测探缓存
  --zh, --chinese          显示此中文帮助文档
"""


# ---------------------------------------------------------------------------
# Argument parser
# ---------------------------------------------------------------------------

def _build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="xputop",
        description="Interactive Universal Accelerator (NPU/GPU) process viewer and monitor.",
        formatter_class=argparse.RawTextHelpFormatter,
    )
    
    # ---- General System ----
    g_core = p.add_argument_group("Core Settings")
    g_core.add_argument("-V", "--version", action="version", version=f"xputop {__version__}")
    g_core.add_argument("-i", "--interval", type=float, default=None, help="Refresh interval (default: 2.0s)")
    g_core.add_argument("-b", "--backend", type=str, default=None, help="Force specific backend (npu, nvidia, amd, etc.)")
    g_core.add_argument("-n", "--procs", type=int, default=None, help="Process rows per device (0=hide, -1=all, default: 3)")
    g_core.add_argument("--config", type=str, default=None, help="Explicit config toml path")
    
    g_vis = p.add_argument_group("Visuals & Charts")
    g_vis.add_argument("-P", "--plot", type=str, nargs="?", const="gpu,mem", default=None, help="Enable 2D multi-line matrix plots. Options: cpu, gpu, mem (e.g. -P cpu,gpu)")
    g_vis.add_argument("-M", "--merge-plot", action="store_true", help="Merge all 2D plots onto a single coordinate axis overlay")
    g_vis.add_argument("-C", "--spark", type=str, nargs="?", const="gpu,mem", default=None, help="Enable 1-line inline sparklines history curves. Options: cpu, gpu, mem")
    g_vis.add_argument("-l", "--chart-length", type=int, default=None, help="Retained history sampling points length")
    g_vis.add_argument("--theme", type=str, choices=["color", "grayscale", "dark", "light"], default=None, help="Color theme for plots (color, grayscale, dark, light)")
    
    # ---- System Sensors ----
    g_sys = p.add_argument_group("System Sensors")
    g_sys.add_argument("-c", "--cpu", action="store_true", help="Show system per-core utilization CPU panel")
    g_sys.add_argument("-m", "--mem", action="store_true", help="Show system memory (RAM/SWAP) panel")
    g_sys.add_argument("-D", "--disk", nargs="*", default=None, help="Show disk utilization. Pass explicit mount paths separated by space")

    # ---- Macro Combinations ----
    g_macro = p.add_argument_group("Macro Configurations")
    g_macro.add_argument("-d", "--detail", action="store_true", help="Alias for: --spark -c -m -D")
    g_macro.add_argument("-a", "--detail-all", action="store_true", help="Alias for: -d + Network IO + Sys process tree")

    # ---- Logging Data Pipelines ----
    g_log = p.add_argument_group("Data Pipelines")
    g_log.add_argument(
        "-o", "--output",
        nargs="?",
        const="",
        default=None,
        help="Target logging path (csv/jsonl/sqlite) or sql engine URI.\nIf provided with no args, defaults to timestamped csv trace in CWD."
    )
    g_log.add_argument(
        "--format",
        type=str,
        default=None,
        help="Format protocol (csv, jsonl, sqlite, md, mysql). Inferred from -o suffix natively.",
    )
    
    # ---- Admin Options ----
    g_admin = p.add_argument_group("Administration Targets")
    g_admin.add_argument("--kill", type=float, default=0.0, help="Autokill top memory tasks on alert thresholds.")
    g_admin.add_argument("--alert", type=str, default=None, help="Temporary threshold config (e.g., mem_usage_percent=95.0)")
    g_admin.add_argument("--list-backends", action="store_true", help="List probed hardware backend capabilities.")
    g_admin.add_argument("--reset-backend", action="store_true", help="Clear probe overrides from config cache.")
    g_admin.add_argument("--demo", action="store_true", help="Enable Demo pseudo-backend generator without accelerator.")
    g_admin.add_argument("--demo-devices", type=int, default=None, help=argparse.SUPPRESS)
    g_admin.add_argument("--zh", "--chinese", action="store_true", dest="chinese", help="Show simplified Chinese documentation menu.")


    # ---- Subcommands -------------------------------------------------------
    sub = p.add_subparsers(dest="command")

    # config
    cfg_parser = sub.add_parser("config", help="Manage xputop configuration")
    cfg_group = cfg_parser.add_mutually_exclusive_group()
    cfg_group.add_argument("--show", action="store_true", help="Print current config")
    cfg_group.add_argument("--generate", action="store_true", help="Generate default config")
    cfg_group.add_argument("--path", action="store_true", help="Print config directory path")

    # once
    once_parser = sub.add_parser("once", help="Print a single snapshot and exit")
    once_parser.add_argument("--json", action="store_true", dest="as_json")
    once_parser.add_argument("-b", "--backend", type=str, default=None)
    once_parser.add_argument("--demo", action="store_true", default=False)
    once_parser.add_argument("--demo-devices", type=int, default=None)
    once_parser.add_argument("-n", "--procs", type=int, default=None)
    once_parser.add_argument("-c", "--cpu", action="store_true", default=False)
    once_parser.add_argument("-m", "--mem", action="store_true", default=False)
    once_parser.add_argument("-D", "--disk", nargs="*", default=None)
    once_parser.add_argument("-d", "--detail", action="store_true", default=False)
    once_parser.add_argument("-a", "--detail-all", action="store_true", default=False)

    once_parser.add_argument("-o", "--output", nargs="?", const="", default=None)
    once_parser.add_argument("--format", type=str, default=None)

    # view
    view_parser = sub.add_parser("view", help="View offline visualization from a JSONL/CSV log")
    view_parser.add_argument("file", type=str, help="Path to JSONL/CSV file")

    # alert-test
    sub.add_parser("alert-test", help="Send a test alert email")

    return p


# ---------------------------------------------------------------------------
# Resolve composite flags
# ---------------------------------------------------------------------------

def _resolve_display_flags(args: argparse.Namespace) -> None:
    if getattr(args, "detail_all", False):
        args.detail = True
    if getattr(args, "detail", False):
        if getattr(args, "spark", None) is None:
            args.spark = "gpu,mem"
        args.cpu = True
        args.mem = True
        if getattr(args, "disk", None) is None:
            args.disk = []


def _resolve_output_args(args: argparse.Namespace) -> tuple[str | None, str]:
    if getattr(args, "output", None) is None:
        return None, ""
        
    out = args.output
    fmt = getattr(args, "format", None)
    
    if out == "":
        fmt = fmt or "csv"
        out = f"xputop_log_{int(time.time())}.{fmt}"
        return out, fmt
        
    from pathlib import Path
    p = Path(out)
    if p.is_dir():
        fmt = fmt or "csv"
        fmt_ext = "db" if fmt == "sqlite" else ("md" if fmt == "markdown" else fmt)
        out = str(p / f"xputop_log_{int(time.time())}.{fmt_ext}")
        return out, fmt
        
    suffix = p.suffix.lower()
    inferred = None
    if suffix == ".csv": inferred = "csv"
    elif suffix == ".jsonl": inferred = "jsonl"
    elif suffix in (".db", ".sqlite"): inferred = "sqlite"
    elif suffix in (".md", ".txt"): inferred = "markdown"

    if fmt is None:
        if inferred:
            fmt = inferred
        elif "://" in out:
            fmt = out.split("://")[0]
        else:
            print(f"Error: Unable to infer format from '{out}'. Please specify --format")
            sys.exit(1)
    else:
        if not suffix and "://" not in out:
            fmt_ext = "db" if fmt == "sqlite" else ("md" if fmt == "markdown" else fmt)
            out += f".{fmt_ext}"
            
    return out, fmt


# ---------------------------------------------------------------------------
# Subcommand handlers
# ---------------------------------------------------------------------------

def _cmd_config(args: argparse.Namespace) -> None:
    from pathlib import Path
    from xputop.alert.config import get_config_dir, get_config_path, generate_default_config

    if args.path:
        print(get_config_dir())
        return

    cfg_path = Path(args.config) if args.config else get_config_path()

    if args.generate:
        p = generate_default_config(cfg_path)
        print(f"Default configuration written to: {p}")
        return

    if cfg_path.exists():
        print(f"Config file: {cfg_path}\n")
        print(cfg_path.read_text(encoding="utf-8"))
    else:
        print(f"No config file found at: {cfg_path}")
        print("Run `xputop config --generate` to create one.")


def _cmd_once(args: argparse.Namespace) -> None:
    from pathlib import Path
    from xputop.alert.config import load_config
    from xputop.core.sysinfo import collect_system_snapshot
    from xputop.core.backends import get_backend
    from xputop.core.backends.demo import DemoBackend

    _resolve_display_flags(args)

    cfg_path = Path(args.config) if args.config else None
    cfg = load_config(cfg_path)

    demo = args.demo or cfg.demo
    backend_name = args.backend or cfg.backend

    if demo:
        backend = DemoBackend(num_devices=args.demo_devices or cfg.demo_devices)
    else:
        # Pass a dict representation if config doesn't have a dict interface directly here
        from dataclasses import asdict
        config_dict = asdict(cfg) if hasattr(cfg, '__dataclass_fields__') else getattr(cfg, '__dict__', {})
        backend = get_backend(config_dict, backend_name)

    snap = backend.collect()

    process_rows = args.procs if args.procs is not None else cfg.process_rows
    sys_snap = None
    show_cpu = getattr(args, "cpu", False)
    show_mem = getattr(args, "mem", False)
    disk_arg = getattr(args, "disk", None)
    show_disk = disk_arg is not None
    show_detail_all = getattr(args, "detail_all", False)

    if show_cpu or show_mem or show_disk or show_detail_all:
        disk_paths = disk_arg if disk_arg else ["/"]
        sys_snap = collect_system_snapshot(
            disk_paths=disk_paths,
            cpu_interval=0.3, # Brief block to get real CPU % for single runs
            collect_net=show_detail_all,
            collect_procs=show_detail_all,
        )

    out_path, out_fmt = _resolve_output_args(args)
    if out_path:
        from xputop.core.recorder import AsyncRecorder
        recorder = AsyncRecorder(out_path, out_fmt)
        recorder.start()
        recorder.record(snap, sys_snap)
        recorder.stop()

    if args.as_json:
        from dataclasses import asdict
        data = asdict(snap)
        if sys_snap:
            data["system"] = asdict(sys_snap)
        print(json.dumps(data, indent=2, default=str))
    else:
        _print_snapshot_table(
            snap, sys_snap, show_cpu, show_mem, show_disk,
            process_rows=process_rows, show_detail_all=show_detail_all,
        )


def _print_snapshot_table(
    snap, sys_snap=None, show_cpu=False, show_mem=False, show_disk=False,
    process_rows=3, show_detail_all=False,
) -> None:
    from rich.console import Console
    from rich.table import Table

    console = Console()

    if snap.error:
        console.print(f"[bold red]Error:[/] {snap.error}")
        return

    console.print(f"[bold cyan]xputop[/] — Driver: {snap.driver_version or 'N/A'}")
    console.print(f"Timestamp: {time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(snap.timestamp))}")
    console.print()

    t = Table(header_style="bold cyan")
    t.add_column("Device", justify="center")
    t.add_column("Name")
    t.add_column("Temp(°C)", justify="right")
    t.add_column("Power(W)", justify="right")
    t.add_column("Util(%)", justify="right")
    t.add_column("Mem Used(MiB)", justify="right")
    t.add_column("Mem Total(MiB)", justify="right")
    t.add_column("Mem(%)", justify="right")
    t.add_column("Health", justify="center")
    t.add_column("#Proc", justify="center")

    for d in snap.devices:
        t.add_row(
            str(d.device_id),
            d.name,
            f"{d.temperature:.0f}",
            f"{d.power:.1f}",
            f"{d.utilization_rate:.1f}",
            f"{d.mem_used:.0f}",
            f"{d.mem_total:.0f}",
            f"{d.mem_usage_percent:.1f}",
            d.health,
            str(len(d.processes)),
        )
    console.print(t)

    # Processes
    if process_rows != 0:
        all_procs = [(d.device_id, p) for d in snap.devices for p in d.processes]
        if process_rows > 0:
            all_procs = all_procs[:process_rows]

        if all_procs:
            console.print()
            pt = Table(title="Processes", header_style="bold")
            pt.add_column("Device", justify="center")
            pt.add_column("PID", justify="right")
            pt.add_column("Process")
            pt.add_column("Mem(MiB)", justify="right")
            for dev_id, p in all_procs:
                pt.add_row(str(dev_id), str(p.pid), p.process_name,
                            f"{p.mem_usage:.0f}" if p.mem_usage > 0 else "-")
            console.print(pt)

    # System info
    if sys_snap and show_cpu:
        console.print()
        console.print(f"[bold blue]CPU[/] — {sys_snap.cpu.core_count} cores  "
                       f"Total: {sys_snap.cpu.total_percent:.1f}%  "
                       f"Load: {sys_snap.cpu.load_avg[0]:.2f} {sys_snap.cpu.load_avg[1]:.2f} {sys_snap.cpu.load_avg[2]:.2f}")
        ct = Table(header_style="bold", show_lines=False)
        ct.add_column("Core", justify="center", width=6)
        ct.add_column("Usage%", justify="right", width=8)
        for i, pct in enumerate(sys_snap.cpu.per_core):
            ct.add_row(str(i), f"{pct:.1f}")
        console.print(ct)

    if sys_snap and show_mem:
        mem = sys_snap.memory
        console.print()
        console.print(f"[bold magenta]Memory[/] — "
                       f"Used: {mem.used_mb:.0f}/{mem.total_mb:.0f} MiB ({mem.percent:.1f}%)  "
                       f"Available: {mem.available_mb:.0f} MiB")
        if mem.swap_total_mb > 0:
            console.print(f"  Swap: {mem.swap_used_mb:.0f}/{mem.swap_total_mb:.0f} MiB ({mem.swap_percent:.1f}%)")

    if sys_snap and show_disk:
        console.print()
        for disk in sys_snap.disks:
            if disk.percent < 0:
                console.print(f"[bold yellow]Disk[/] {disk.mount_point}: N/A")
            else:
                console.print(f"[bold yellow]Disk[/] {disk.mount_point}: "
                               f"{disk.used_gb:.1f}/{disk.total_gb:.1f} GiB ({disk.percent:.1f}%)  "
                               f"free {disk.free_gb:.1f} GiB")

    # Network
    if sys_snap and show_detail_all and sys_snap.network:
        net = sys_snap.network
        console.print()
        if net.error:
            console.print(f"[bold green]Network[/] — {net.error}")
        else:
            console.print(f"[bold green]Network[/] — "
                           f"↑ {net.send_rate}  ↓ {net.recv_rate}  "
                           f"Total sent: {net.total_sent_gb:.2f} GiB  "
                           f"Total recv: {net.total_recv_gb:.2f} GiB")

    # Process tree
    if sys_snap and show_detail_all and sys_snap.top_processes:
        console.print()
        pt2 = Table(title="Top System Processes", header_style="bold")
        pt2.add_column("PID", justify="right", width=8)
        pt2.add_column("User", width=10)
        pt2.add_column("CPU%", justify="right", width=7)
        pt2.add_column("MEM%", justify="right", width=7)
        pt2.add_column("MEM(MiB)", justify="right", width=10)
        pt2.add_column("Status", width=8)
        pt2.add_column("Command", min_width=30)
        for proc in sys_snap.top_processes[:15]:
            pt2.add_row(
                str(proc.pid), proc.username,
                f"{proc.cpu_percent:.1f}", f"{proc.memory_percent:.1f}",
                f"{proc.memory_mb:.0f}", proc.status, proc.cmdline,
            )
        console.print(pt2)


def _cmd_alert_test(args: argparse.Namespace) -> None:
    from pathlib import Path
    from xputop.alert.config import load_config
    from xputop.alert.email_alert import EmailAlertSender

    cfg_path = Path(args.config) if args.config else None
    cfg = load_config(cfg_path)

    if not cfg.email.is_valid():
        print("Email is not configured or not enabled.")
        sys.exit(1)

    sender = EmailAlertSender(cfg.email)
    sender.start()
    sender.send_alert("[TEST] This is a test alert from xputop.")
    time.sleep(5)
    sender.stop()
    print("Test alert sent.")


def _cmd_view(args: argparse.Namespace) -> None:
    from pathlib import Path
    import sys
    
    if not Path(args.file).exists():
        print(f"File not found: {args.file}")
        sys.exit(1)
        
    from xputop.ui.viewer import create_viewer_html
    
    out_path = Path(args.file).with_suffix(".html")
    print(f"Parsing log {args.file} and generating viewer at {out_path}...")
    create_viewer_html(args.file, str(out_path))
    print(f"Viewer created at {out_path}. Please open it in a web browser.")


# ---------------------------------------------------------------------------
# Main TUI
# ---------------------------------------------------------------------------

def _cmd_tui(args: argparse.Namespace) -> None:
    from pathlib import Path
    from xputop.alert.config import load_config
    from xputop.alert.email_alert import EmailAlertSender
    from xputop.core.monitor import Monitor
    from xputop.ui.tui import run_tui

    _resolve_display_flags(args)

    cfg_path = Path(args.config) if args.config else None
    cfg = load_config(cfg_path)

    interval = args.interval if args.interval is not None else cfg.interval
    demo = args.demo or cfg.demo
    demo_devices = args.demo_devices if args.demo_devices is not None else cfg.demo_devices

    show_spark = getattr(args, "spark", None) is not None or cfg.show_chart
    spark_targets = []
    if getattr(args, "spark", None):
        spark_targets = args.spark.split(",")
    elif cfg.show_chart:
        spark_targets = ["gpu", "mem"]

    show_plot = getattr(args, "plot", None) is not None
    plot_targets = args.plot.split(",") if getattr(args, "plot", None) else ["gpu", "mem"]

    merge_plot = args.merge_plot
    chart_length = args.chart_length if args.chart_length is not None else cfg.chart_length
    
    show_cpu = args.cpu or cfg.show_cpu or ("cpu" in spark_targets) or ("cpu" in plot_targets)
    show_mem = args.mem or cfg.show_mem
    show_detail_all = getattr(args, "detail_all", False)
    backend_name = args.backend or cfg.backend
    theme = getattr(args, "theme", None) or cfg.theme

    process_rows = args.procs if args.procs is not None else cfg.process_rows

    disk_arg = args.disk
    if disk_arg is not None:
        show_disk = True
        disk_paths = disk_arg if disk_arg else (cfg.disk_paths or ["/"])
    elif cfg.show_disk:
        show_disk = True
        disk_paths = cfg.disk_paths or ["/"]
    else:
        show_disk = False
        disk_paths = ["/"]
        
    # Convert config object to dict for the backend resolver
    from dataclasses import asdict
    config_dict = asdict(cfg) if hasattr(cfg, '__dataclass_fields__') else getattr(cfg, '__dict__', {})

    out_path, out_fmt = _resolve_output_args(args)

    monitor = Monitor(
        interval=interval,
        demo=demo,
        demo_devices=demo_devices,
        show_cpu=show_cpu,
        show_mem=show_mem,
        show_disk=show_disk,
        disk_paths=disk_paths,
        show_chart=show_spark,
        chart_targets=spark_targets,
        show_plot=show_plot,
        plot_targets=plot_targets,
        merge_plot=merge_plot,
        chart_length=chart_length,
        process_rows=process_rows,
        show_detail_all=show_detail_all,
        config=config_dict,
        force_backend=backend_name,
        output_path=out_path,
        output_format=out_fmt,
        theme=theme,
    )

    for rule in cfg.rules:
        monitor.add_rule(rule)

    if getattr(args, "alert", None):
        from xputop.core.monitor import ThresholdRule
        for part in args.alert.split(","):
            if "=" in part:
                k, v = part.split("=", 1)
                monitor.add_rule(ThresholdRule(metric=k.strip(), limit=float(v.strip())))

    monitor.kill_value = getattr(args, "kill", 0.0)

    email_sender = None
    if cfg.email.is_valid():
        email_sender = EmailAlertSender(cfg.email)
        email_sender.start()
        monitor.on_alert(email_sender.send_alert)

    try:
        run_tui(monitor)
    finally:
        if email_sender:
            email_sender.stop()


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def main() -> None:
    parser = _build_parser()
    args = parser.parse_args()

    if getattr(args, "reset_backend", False):
        import os
        cache_f = os.path.expanduser("~/.cache/xputop/backend.json")
        if os.path.exists(cache_f):
            os.remove(cache_f)
            print(f"Removed cache at {cache_f}")
        else:
            print("No backend cache to reset.")
        sys.exit(0)

    if getattr(args, "list_backends", False):
        from pathlib import Path
        from xputop.alert.config import load_config
        from xputop.core.backends import get_available_backends
        
        cfg_path = Path(args.config) if getattr(args, "config", None) else None
        cfg = load_config(cfg_path)
        from dataclasses import asdict
        config_dict = asdict(cfg) if hasattr(cfg, '__dataclass_fields__') else getattr(cfg, '__dict__', {})
        
        backends = get_available_backends(config_dict)
        print(f"{'Backend Name':<20} {'Priority':<10} {'Available':<10}")
        print("-" * 45)
        for b in backends:
            v_str = "Yes" if b.probe() else "No"
            print(f"{b.name:<20} {getattr(b, 'priority', 100):<10} {v_str:<10}")
        sys.exit(0)

    if args.chinese:
        print(_CHINESE_HELP.format(version=__version__))
        sys.exit(0)

    if args.command == "config":
        _cmd_config(args)
    elif args.command == "once":
        _cmd_once(args)
    elif args.command == "alert-test":
        _cmd_alert_test(args)
    elif args.command == "view":
        _cmd_view(args)
    else:
        _cmd_tui(args)


if __name__ == "__main__":
    main()
