"""
Configuration management for xputop.

Configuration is stored as a TOML-like INI file at one of these locations
(checked in order):

1. Path specified via ``XPUTOP_CONFIG_DIR`` environment variable
2. ``$XDG_CONFIG_HOME/xputop/config.toml``  (Linux standard)
3. ``~/.config/xputop/config.toml``          (fallback)

The configuration file controls email alerting, threshold rules, display
preferences, and system monitoring options.
"""

from __future__ import annotations

import configparser
import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional

from xputop.core.monitor import ThresholdRule


# ---------------------------------------------------------------------------
# Path resolution
# ---------------------------------------------------------------------------

_APP_NAME = "xputop"


def get_config_dir() -> Path:
    """Return the configuration directory, creating it if necessary."""
    env = os.environ.get("XPUTOP_CONFIG_DIR")
    if env:
        p = Path(env)
    else:
        xdg = os.environ.get("XDG_CONFIG_HOME")
        if xdg:
            p = Path(xdg) / _APP_NAME
        else:
            p = Path.home() / ".config" / _APP_NAME
    p.mkdir(parents=True, exist_ok=True)
    return p


def get_config_path() -> Path:
    return get_config_dir() / "config.toml"


def get_log_dir() -> Path:
    """Return the log / cache directory."""
    cache = os.environ.get("XDG_CACHE_HOME")
    if cache:
        p = Path(cache) / _APP_NAME
    else:
        p = Path.home() / ".cache" / _APP_NAME
    p.mkdir(parents=True, exist_ok=True)
    return p


# ---------------------------------------------------------------------------
# Data classes
# ---------------------------------------------------------------------------

@dataclass
class EmailConfig:
    """SMTP email configuration."""

    enabled: bool = False
    smtp_host: str = "smtp.gmail.com"
    smtp_port: int = 587
    use_tls: bool = True
    username: str = ""
    password: str = ""
    sender: str = ""
    recipients: List[str] = field(default_factory=list)
    subject_prefix: str = "[xputop]"

    def is_valid(self) -> bool:
        return bool(self.enabled and self.smtp_host and self.sender and self.recipients)


@dataclass
class NputopConfig:
    """Top-level configuration."""

    # General
    interval: float = 2.0
    demo: bool = False
    demo_devices: int = 4
    backend: str = "auto"

    # Custom backends dict (name -> {key: value})
    backend_custom: Dict[str, Dict[str, str]] = field(default_factory=dict)

    # New display flags (persisted in config)
    show_chart: bool = False
    chart_length: int = 120
    show_cpu: bool = False
    show_mem: bool = False
    show_disk: bool = False
    disk_paths: List[str] = field(default_factory=lambda: ["/"])
    # Process display rows per NPU card: >0 = fixed rows, 0 = hide, -1 = all
    process_rows: int = 3
    theme: str = "color"  # color, grayscale, dark, light

    # Email
    email: EmailConfig = field(default_factory=EmailConfig)

    # Threshold rules
    rules: List[ThresholdRule] = field(default_factory=list)


# ---------------------------------------------------------------------------
# Load / save
# ---------------------------------------------------------------------------

def _bool(val: str) -> bool:
    return val.strip().lower() in ("true", "1", "yes", "on")


def load_config(path: Optional[Path] = None) -> NputopConfig:
    """Load configuration from disk.  Returns defaults if file is missing."""
    if path is None:
        path = get_config_path()

    cfg = NputopConfig()
    if not path.exists():
        return cfg

    cp = configparser.ConfigParser(interpolation=None)
    cp.read(str(path), encoding="utf-8")

    # [general]
    if cp.has_section("general"):
        g = cp["general"]
        cfg.interval = float(g.get("interval", str(cfg.interval)))
        cfg.demo = _bool(g.get("demo", "false"))
        cfg.demo_devices = int(g.get("demo_devices", str(cfg.demo_devices)))
        cfg.backend = g.get("backend", str(cfg.backend))

    # [display]
    if cp.has_section("display"):
        d = cp["display"]
        cfg.show_chart = _bool(d.get("chart", "false"))
        cfg.chart_length = int(d.get("chart_length", str(cfg.chart_length)))
        cfg.show_cpu = _bool(d.get("cpu", "false"))
        cfg.show_mem = _bool(d.get("mem", "false"))
        cfg.show_disk = _bool(d.get("disk", "false"))
        raw_paths = d.get("disk_paths", "/")
        cfg.disk_paths = [p.strip() for p in raw_paths.split(",") if p.strip()]
        cfg.process_rows = int(d.get("process_rows", str(cfg.process_rows)))
        cfg.theme = d.get("theme", str(cfg.theme))

    # [email]
    if cp.has_section("email"):
        e = cp["email"]
        cfg.email.enabled = _bool(e.get("enabled", "false"))
        cfg.email.smtp_host = e.get("smtp_host", cfg.email.smtp_host)
        cfg.email.smtp_port = int(e.get("smtp_port", str(cfg.email.smtp_port)))
        cfg.email.use_tls = _bool(e.get("use_tls", "true"))
        cfg.email.username = e.get("username", "")
        cfg.email.password = e.get("password", "")
        cfg.email.sender = e.get("sender", "")
        cfg.email.subject_prefix = e.get("subject_prefix", cfg.email.subject_prefix)
        raw_recip = e.get("recipients", "")
        cfg.email.recipients = [r.strip() for r in raw_recip.split(",") if r.strip()]

    # [rule:*] and [backend.custom.*]
    for section in cp.sections():
        if section.startswith("rule:"):
            r = cp[section]
            rule = ThresholdRule(
                metric=r.get("metric", "temperature"),
                limit=float(r.get("limit", "80")),
                device_id=int(r["device_id"]) if "device_id" in r else None,
                cooldown=float(r.get("cooldown", "300")),
            )
            cfg.rules.append(rule)
        elif section.startswith("backend.custom."):
            name = section.split(".", 2)[2]
            cfg.backend_custom[name] = dict(cp[section])

    return cfg


def save_config(cfg: NputopConfig, path: Optional[Path] = None) -> Path:
    """Persist configuration to disk."""
    if path is None:
        path = get_config_path()

    cp = configparser.ConfigParser(interpolation=None)

    cp["general"] = {
        "interval": str(cfg.interval),
        "demo": str(cfg.demo).lower(),
        "demo_devices": str(cfg.demo_devices),
        "backend": cfg.backend,
    }

    cp["display"] = {
        "chart": str(cfg.show_chart).lower(),
        "chart_length": str(cfg.chart_length),
        "cpu": str(cfg.show_cpu).lower(),
        "mem": str(cfg.show_mem).lower(),
        "disk": str(cfg.show_disk).lower(),
        "disk_paths": ", ".join(cfg.disk_paths),
        "process_rows": str(cfg.process_rows),
        "theme": cfg.theme,
    }

    cp["email"] = {
        "enabled": str(cfg.email.enabled).lower(),
        "smtp_host": cfg.email.smtp_host,
        "smtp_port": str(cfg.email.smtp_port),
        "use_tls": str(cfg.email.use_tls).lower(),
        "username": cfg.email.username,
        "password": cfg.email.password,
        "sender": cfg.email.sender,
        "recipients": ", ".join(cfg.email.recipients),
        "subject_prefix": cfg.email.subject_prefix,
    }

    for i, rule in enumerate(cfg.rules):
        sec = f"rule:{i}"
        d: Dict[str, str] = {
            "metric": rule.metric,
            "limit": str(rule.limit),
            "cooldown": str(rule.cooldown),
        }
        if rule.device_id is not None:
            d["device_id"] = str(rule.device_id)
        cp[sec] = d

    for name, c_dict in cfg.backend_custom.items():
        sec = f"backend.custom.{name}"
        cp[sec] = c_dict

    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        f.write("# xputop configuration\n")
        f.write(f"# Location: {path}\n")
        f.write("# Edit this file or use `xputop config`.\n\n")
        cp.write(f)

    return path


def generate_default_config(path: Optional[Path] = None) -> Path:
    """Write a default configuration file with example values."""
    cfg = NputopConfig()
    cfg.email = EmailConfig(
        enabled=False,
        smtp_host="smtp.example.com",
        smtp_port=587,
        use_tls=True,
        username="user@example.com",
        password="your_app_password",
        sender="xputop@example.com",
        recipients=["admin@example.com"],
        subject_prefix="[xputop]",
    )
    
    cfg.backend_custom = {
        "example-accel": {
            "probe_command": "example-smi --version",
            "info_command": "example-smi config",
            "device_pattern": r"Device (?P<id>\d+) \| (?P<name>\S+) \| Temp=(?P<temp>\d+) \| Power=(?P<power>[\d.]+) \| Util=(?P<util>\d+)% \| Mem=(?P<mem_used>\d+)/(?P<mem_total>\d+)",
        }
    }
    cfg.rules = [
        ThresholdRule(metric="temperature", limit=80.0, cooldown=300),
        ThresholdRule(metric="hbm_usage_percent", limit=95.0, cooldown=300),
        ThresholdRule(metric="aicore_rate", limit=99.0, cooldown=600),
        ThresholdRule(metric="cpu_percent", limit=95.0, cooldown=120),
        ThresholdRule(metric="mem_percent", limit=90.0, cooldown=300),
        ThresholdRule(metric="disk_percent", limit=95.0, cooldown=600),
    ]
    return save_config(cfg, path)
