"""
Email alerting module.

Sends SMTP email notifications when threshold rules are triggered.
Supports TLS, configurable sender/recipients, and a simple send queue
so alert emails don't block the monitoring loop.
"""

from __future__ import annotations

import logging
import queue
import smtplib
import socket
import threading
import time
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from typing import Optional

from xputop.alert.config import EmailConfig, get_log_dir

logger = logging.getLogger("xputop.alert")


class EmailAlertSender:
    """
    Asynchronous email sender with a background worker thread.

    Usage::

        sender = EmailAlertSender(email_config)
        sender.start()
        sender.send_alert("Temperature too high on NPU 0!")
        ...
        sender.stop()
    """

    def __init__(self, config: EmailConfig, max_queue: int = 100):
        self.config = config
        self._queue: queue.Queue[Optional[str]] = queue.Queue(maxsize=max_queue)
        self._thread: Optional[threading.Thread] = None
        self._setup_logging()

    def _setup_logging(self) -> None:
        log_dir = get_log_dir()
        handler = logging.FileHandler(log_dir / "email_alert.log", encoding="utf-8")
        handler.setFormatter(logging.Formatter(
            "%(asctime)s [%(levelname)s] %(message)s",
        ))
        logger.addHandler(handler)
        logger.setLevel(logging.INFO)

    # -- Lifecycle -----------------------------------------------------------

    def start(self) -> None:
        if self._thread and self._thread.is_alive():
            return
        self._thread = threading.Thread(target=self._worker, daemon=True)
        self._thread.start()
        logger.info("Email alert sender started.")

    def stop(self) -> None:
        self._queue.put(None)  # sentinel
        if self._thread:
            self._thread.join(timeout=10)
        logger.info("Email alert sender stopped.")

    # -- Public API ----------------------------------------------------------

    def send_alert(self, message: str) -> None:
        """Enqueue an alert message for delivery."""
        if not self.config.is_valid():
            logger.warning("Email config invalid; skipping alert: %s", message)
            return
        try:
            self._queue.put_nowait(message)
        except queue.Full:
            logger.warning("Alert queue full; dropping: %s", message)

    # -- Worker --------------------------------------------------------------

    def _worker(self) -> None:
        while True:
            msg = self._queue.get()
            if msg is None:
                break
            self._do_send(msg)

    def _do_send(self, alert_body: str) -> None:
        cfg = self.config
        hostname = socket.gethostname()
        subject = f"{cfg.subject_prefix} Alert from {hostname}"

        html_body = _build_html(alert_body, hostname)

        mime = MIMEMultipart("alternative")
        mime["From"] = cfg.sender
        mime["To"] = ", ".join(cfg.recipients)
        mime["Subject"] = subject
        mime.attach(MIMEText(alert_body, "plain", "utf-8"))
        mime.attach(MIMEText(html_body, "html", "utf-8"))

        try:
            if cfg.use_tls:
                server = smtplib.SMTP(cfg.smtp_host, cfg.smtp_port, timeout=30)
                server.ehlo()
                server.starttls()
                server.ehlo()
            else:
                server = smtplib.SMTP(cfg.smtp_host, cfg.smtp_port, timeout=30)

            if cfg.username and cfg.password:
                server.login(cfg.username, cfg.password)

            server.sendmail(cfg.sender, cfg.recipients, mime.as_string())
            server.quit()
            logger.info("Alert email sent: %s", alert_body[:80])
        except Exception as exc:
            logger.error("Failed to send alert email: %s — %s", exc, alert_body[:80])


def _build_html(alert_body: str, hostname: str) -> str:
    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    return f"""\
<html>
<body style="font-family: monospace; background: #1e1e2e; color: #cdd6f4; padding: 20px;">
  <h2 style="color: #f38ba8;">xputop Alert</h2>
  <p><strong>Host:</strong> {hostname}</p>
  <p><strong>Time:</strong> {ts}</p>
  <hr style="border-color: #45475a;">
  <pre style="background: #313244; padding: 16px; border-radius: 8px; color: #f38ba8;">
{alert_body}
  </pre>
  <hr style="border-color: #45475a;">
  <p style="color: #6c7086; font-size: 12px;">
    Sent by <strong>xputop</strong> — Huawei Ascend NPU Monitor
  </p>
</body>
</html>
"""
