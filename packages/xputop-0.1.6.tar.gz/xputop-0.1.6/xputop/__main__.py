"""Allow running xputop as `python -m xputop`."""

from xputop.cli import main

if __name__ == "__main__":
    main()
