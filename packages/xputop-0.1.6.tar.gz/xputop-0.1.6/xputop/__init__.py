"""xputop - An interactive Huawei Ascend NPU process viewer and monitor."""

__version__ = "0.1.0"
__author__ = "xputop contributors"
