"""
Lightweight system metrics collector: CPU, memory, disk, network, processes.

Design goals:
  - Minimal overhead — uses psutil one-shot calls, no busy loops
  - Single-call snapshot — all metrics in one dataclass
  - Safe on headless / container environments
  - Network metrics: auto-detect root permission, skip if unavailable
"""

from __future__ import annotations

import os
import time
from collections import deque
from dataclasses import dataclass, field
from typing import Deque, Dict, List, Optional, Tuple

try:
    import psutil
    _PSUTIL_AVAILABLE = True
except ImportError:
    _PSUTIL_AVAILABLE = False


# ---------------------------------------------------------------------------
# Data classes
# ---------------------------------------------------------------------------

@dataclass
class CPUInfo:
    """Per-core and aggregate CPU utilization."""

    # Overall CPU usage %
    total_percent: float = 0.0
    # Per-core usage % (index = core id)
    per_core: List[float] = field(default_factory=list)
    # Number of logical cores
    core_count: int = 0
    # Load average (1, 5, 15 min) — Linux only
    load_avg: Tuple[float, float, float] = (0.0, 0.0, 0.0)


@dataclass
class MemoryInfo:
    """System RAM usage."""

    total_mb: float = 0.0
    used_mb: float = 0.0
    available_mb: float = 0.0
    percent: float = 0.0
    # Swap
    swap_total_mb: float = 0.0
    swap_used_mb: float = 0.0
    swap_percent: float = 0.0


@dataclass
class DiskInfo:
    """Usage for a single mount point."""

    mount_point: str = "/"
    device: str = ""
    total_gb: float = 0.0
    used_gb: float = 0.0
    free_gb: float = 0.0
    percent: float = 0.0


@dataclass
class NetworkInfo:
    """Network I/O counters (delta-based)."""

    # Interface name ("total" for aggregate)
    interface: str = "total"
    # Bytes sent/recv since last sample (delta)
    bytes_sent_per_sec: float = 0.0
    bytes_recv_per_sec: float = 0.0
    # Human-readable rates
    send_rate: str = "0 B/s"
    recv_rate: str = "0 B/s"
    # Cumulative totals
    total_sent_gb: float = 0.0
    total_recv_gb: float = 0.0
    # Error flag
    error: Optional[str] = None


@dataclass
class ProcessInfo:
    """A single process entry for the process tree."""

    pid: int = 0
    name: str = ""
    username: str = ""
    cpu_percent: float = 0.0
    memory_percent: float = 0.0
    memory_mb: float = 0.0
    status: str = ""
    cmdline: str = ""


@dataclass
class SystemSnapshot:
    """A single point-in-time reading of CPU + memory + disk + network + process tree."""

    timestamp: float = 0.0
    cpu: CPUInfo = field(default_factory=CPUInfo)
    memory: MemoryInfo = field(default_factory=MemoryInfo)
    disks: List[DiskInfo] = field(default_factory=list)
    network: Optional[NetworkInfo] = None
    top_processes: List[ProcessInfo] = field(default_factory=list)


# ---------------------------------------------------------------------------
# Network I/O helpers — auto-detect permission, skip on failure
# ---------------------------------------------------------------------------

# Module-level state: once we fail to read network counters, don't retry
_net_disabled: bool = False
_prev_net_counters: Optional[Dict[str, int]] = None
_prev_net_time: float = 0.0


def _format_rate(bytes_per_sec: float) -> str:
    """Format bytes/sec into a human-readable rate string."""
    if bytes_per_sec < 1024:
        return f"{bytes_per_sec:.0f} B/s"
    elif bytes_per_sec < 1024 ** 2:
        return f"{bytes_per_sec / 1024:.1f} KB/s"
    elif bytes_per_sec < 1024 ** 3:
        return f"{bytes_per_sec / (1024 ** 2):.1f} MB/s"
    else:
        return f"{bytes_per_sec / (1024 ** 3):.2f} GB/s"


def collect_network_info() -> Optional[NetworkInfo]:
    """Collect network I/O counters.  Returns None if unavailable."""
    global _net_disabled, _prev_net_counters, _prev_net_time

    if _net_disabled or not _PSUTIL_AVAILABLE:
        return None

    try:
        counters = psutil.net_io_counters()
        if counters is None:
            _net_disabled = True
            return None

        now = time.time()
        cur = {
            "bytes_sent": counters.bytes_sent,
            "bytes_recv": counters.bytes_recv,
        }

        if _prev_net_counters is None or _prev_net_time <= 0:
            # First sample — store baseline, return zeros
            _prev_net_counters = cur
            _prev_net_time = now
            return NetworkInfo(
                total_sent_gb=round(counters.bytes_sent / (1024 ** 3), 2),
                total_recv_gb=round(counters.bytes_recv / (1024 ** 3), 2),
            )

        dt = now - _prev_net_time
        if dt <= 0:
            dt = 1.0

        sent_ps = (cur["bytes_sent"] - _prev_net_counters["bytes_sent"]) / dt
        recv_ps = (cur["bytes_recv"] - _prev_net_counters["bytes_recv"]) / dt

        _prev_net_counters = cur
        _prev_net_time = now

        return NetworkInfo(
            bytes_sent_per_sec=max(0.0, sent_ps),
            bytes_recv_per_sec=max(0.0, recv_ps),
            send_rate=_format_rate(max(0.0, sent_ps)),
            recv_rate=_format_rate(max(0.0, recv_ps)),
            total_sent_gb=round(counters.bytes_sent / (1024 ** 3), 2),
            total_recv_gb=round(counters.bytes_recv / (1024 ** 3), 2),
        )

    except (psutil.AccessDenied, PermissionError):
        _net_disabled = True
        return NetworkInfo(error="Permission denied (requires root)")
    except Exception:  # noqa: BLE001
        _net_disabled = True
        return None


# ---------------------------------------------------------------------------
# Process tree collection
# ---------------------------------------------------------------------------

def collect_top_processes(max_procs: int = 20) -> List[ProcessInfo]:
    """Collect top processes sorted by CPU + memory usage."""
    procs: List[ProcessInfo] = []
    if not _PSUTIL_AVAILABLE:
        return procs
        
    try:
        for proc in psutil.process_iter(
            ["pid", "name", "username", "cpu_percent", "memory_percent",
             "memory_info", "status", "cmdline"],
        ):
            try:
                info = proc.info
                mem_info = info.get("memory_info")
                mem_mb = round(mem_info.rss / 1048576, 1) if mem_info else 0.0
                cmdline_parts = info.get("cmdline") or []
                cmdline_str = " ".join(cmdline_parts)[:120] if cmdline_parts else info.get("name", "")

                procs.append(ProcessInfo(
                    pid=info["pid"],
                    name=info.get("name", "") or "",
                    username=info.get("username", "") or "",
                    cpu_percent=info.get("cpu_percent", 0.0) or 0.0,
                    memory_percent=info.get("memory_percent", 0.0) or 0.0,
                    memory_mb=mem_mb,
                    status=info.get("status", "") or "",
                    cmdline=cmdline_str,
                ))
            except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
                continue
    except Exception:  # noqa: BLE001
        pass

    # Sort by CPU% + Memory% descending, take top N
    procs.sort(key=lambda p: p.cpu_percent + p.memory_percent, reverse=True)
    return procs[:max_procs]


# ---------------------------------------------------------------------------
# Collection — designed to be lightweight
# ---------------------------------------------------------------------------

# Keep a cached interval handle so percpu_percent doesn't block the first time.
_PREV_CPU_TIMES = None


def collect_system_snapshot(
    disk_paths: Optional[List[str]] = None,
    cpu_interval: Optional[float] = None,
    collect_net: bool = False,
    collect_procs: bool = False,
) -> SystemSnapshot:
    """
    Collect system metrics in one shot.

    Args:
        disk_paths:    Mount points to monitor. Default ``["/"]``.
        cpu_interval:  If not None, psutil will block for this many seconds
                       to measure CPU.  Use ``None`` for non-blocking (uses
                       delta from the previous call — ideal in a loop).
        collect_net:   If True, also collect network I/O counters.
        collect_procs: If True, also collect top processes by usage.

    The non-blocking mode (cpu_interval=None) is strongly recommended for
    monitoring loops because it adds **zero** extra latency.  The very first
    call may return 0 % if there is no prior sample.
    """
    global _PREV_CPU_TIMES

    ts = time.time()
    
    if not _PSUTIL_AVAILABLE:
        return SystemSnapshot(timestamp=ts)

    # ---- CPU (non-blocking by default) -----------------------------------
    per_core = psutil.cpu_percent(interval=cpu_interval, percpu=True)
    total_pct = sum(per_core) / len(per_core) if per_core else 0.0

    try:
        load_avg = os.getloadavg()
    except (OSError, AttributeError):
        load_avg = (0.0, 0.0, 0.0)

    cpu = CPUInfo(
        total_percent=round(total_pct, 1),
        per_core=[round(c, 1) for c in per_core],
        core_count=len(per_core),
        load_avg=load_avg,
    )

    # ---- Memory ----------------------------------------------------------
    vm = psutil.virtual_memory()
    sw = psutil.swap_memory()
    memory = MemoryInfo(
        total_mb=round(vm.total / 1048576, 1),
        used_mb=round(vm.used / 1048576, 1),
        available_mb=round(vm.available / 1048576, 1),
        percent=vm.percent,
        swap_total_mb=round(sw.total / 1048576, 1),
        swap_used_mb=round(sw.used / 1048576, 1),
        swap_percent=sw.percent,
    )

    # ---- Disk ------------------------------------------------------------
    if disk_paths is None:
        disk_paths = ["/"]

    disks: List[DiskInfo] = []
    for mp in disk_paths:
        try:
            usage = psutil.disk_usage(mp)
            disks.append(DiskInfo(
                mount_point=mp,
                device="",
                total_gb=round(usage.total / (1024 ** 3), 2),
                used_gb=round(usage.used / (1024 ** 3), 2),
                free_gb=round(usage.free / (1024 ** 3), 2),
                percent=usage.percent,
            ))
        except (OSError, PermissionError):
            disks.append(DiskInfo(mount_point=mp, percent=-1))

    # ---- Network ---------------------------------------------------------
    network = collect_network_info() if collect_net else None

    # ---- Top processes ---------------------------------------------------
    top_procs = collect_top_processes() if collect_procs else []

    return SystemSnapshot(
        timestamp=ts, cpu=cpu, memory=memory, disks=disks,
        network=network, top_processes=top_procs,
    )


# ---------------------------------------------------------------------------
# History ring buffer — stores last N samples for sparkline/curves
# ---------------------------------------------------------------------------

class MetricHistory:
    """
    Fixed-size ring buffer that stores the last ``max_points`` values for a
    named metric.  Used by the TUI to render sparkline curves.
    """

    def __init__(self, max_points: int = 120):
        self.max_points = max_points
        self._data: Dict[str, Deque[float]] = {}

    def push(self, name: str, value: float) -> None:
        if name not in self._data:
            self._data[name] = deque(maxlen=self.max_points)
        self._data[name].append(value)

    def get(self, name: str) -> List[float]:
        if name in self._data:
            return list(self._data[name])
        return []

    def keys(self) -> List[str]:
        return list(self._data.keys())
