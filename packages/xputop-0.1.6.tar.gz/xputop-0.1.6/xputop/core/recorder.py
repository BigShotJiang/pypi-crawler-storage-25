"""
Background recorder for long-term monitoring logs.

Supports asynchronous buffering and writing of snapshot data to JSONL or CSV formats,
ensuring zero blocking for the main monitoring loop or training processes.
"""

from __future__ import annotations

import csv
import json
import logging
import queue
import threading
from dataclasses import asdict
from pathlib import Path
from typing import Any, Dict, Optional

from xputop.core.backend import AccelSnapshot
from xputop.core.sysinfo import SystemSnapshot


logger = logging.getLogger(__name__)


class AsyncRecorder:
    """Asynchronously writes metrics to a file (JSONL or CSV)."""

    def __init__(self, filepath: str, format_type: str = "jsonl"):
        self.raw_filepath = filepath
        self.format_type = format_type.lower()
        if "://" in filepath:
            self.filepath = filepath # DB URI string
        else:
            self.filepath = Path(filepath)
            self.filepath.parent.mkdir(parents=True, exist_ok=True)
        
        self.queue: queue.Queue = queue.Queue(maxsize=1000)
        self._stop_event = threading.Event()
        self._thread: Optional[threading.Thread] = None


        
        # Prepare CSV headers if needed
        self._csv_writer = None
        self._csv_file = None
        self._csv_headers_written = False

    def start(self) -> None:
        if self._thread and self._thread.is_alive():
            return
        self._stop_event.clear()
        self._thread = threading.Thread(target=self._worker, daemon=True)
        self._thread.start()

    def stop(self) -> None:
        self._stop_event.set()
        if self._thread:
            self._thread.join(timeout=2.0)
            
        # Flush remaining
        self._flush_queue()
        
        if self._csv_file:
            self._csv_file.close()
            
        if hasattr(self, "_sqlite_conn"):
            self._sqlite_conn.close()

    def record(self, snap: AccelSnapshot, sys_snap: Optional[SystemSnapshot] = None) -> None:
        """Enqueue data for writing. Non-blocking."""
        if not self._thread or not self._thread.is_alive():
            return
        
        # We don't want to block the main thread. If queue is full, drop.
        try:
            self.queue.put_nowait((snap, sys_snap))
        except queue.Full:
            logger.warning("Recorder queue full, dropping snapshot.")

    def _worker(self) -> None:
        while not self._stop_event.is_set():
            try:
                # Wait for item with timeout to check stop_event frequently
                snap, sys_snap = self.queue.get(timeout=0.5)
                self._write_item(snap, sys_snap)
                self.queue.task_done()
            except queue.Empty:
                continue
            except Exception as e:
                logger.error(f"Error writing record: {e}")

    def _flush_queue(self) -> None:
        """Write all remaining items in the queue."""
        while not self.queue.empty():
            try:
                snap, sys_snap = self.queue.get_nowait()
                self._write_item(snap, sys_snap)
            except queue.Empty:
                break
            except Exception as e:
                logger.error(f"Error flushing record: {e}")

    def _write_item(self, snap: AccelSnapshot, sys_snap: Optional[SystemSnapshot]) -> None:
        if self.format_type == "jsonl":
            self._write_jsonl(snap, sys_snap)
        elif self.format_type == "csv":
            self._write_csv(snap, sys_snap)
        elif self.format_type == "sqlite":
            self._write_sqlite(snap, sys_snap)
        elif self.format_type == "markdown":
            self._write_markdown(snap, sys_snap)
        else:
            self._write_sqlalchemy(snap, sys_snap)

    def _build_flat_row(self, snap: AccelSnapshot, sys_snap: Optional[SystemSnapshot]) -> Dict[str, Any]:
        row: Dict[str, Any] = {
            "timestamp": snap.timestamp,
            "driver_version": snap.driver_version or "",
            "error": snap.error or "",
        }
        for dev in snap.devices:
            prefix = f"dev_{dev.device_id}_"
            row[prefix + "name"] = dev.name or ""
            row[prefix + "temp"] = float(dev.temperature)
            row[prefix + "power"] = float(dev.power)
            row[prefix + "util_percent"] = float(dev.utilization_rate)
            row[prefix + "mem_used_mb"] = float(dev.mem_used)
            row[prefix + "mem_total_mb"] = float(dev.mem_total)
            row[prefix + "mem_percent"] = float(dev.mem_usage_percent)
            
        if sys_snap:
            row["sys_cpu_percent"] = float(sys_snap.cpu.total_percent)
            row["sys_mem_percent"] = float(sys_snap.memory.percent)
            row["sys_mem_used_mb"] = float(sys_snap.memory.used_mb)
        return row

    def _write_jsonl(self, snap: AccelSnapshot, sys_snap: Optional[SystemSnapshot]) -> None:
        data = asdict(snap)
        if sys_snap:
            data["system"] = asdict(sys_snap)
        
        with open(self.filepath, "a", encoding="utf-8") as f:
            f.write(json.dumps(data) + "\n")

    def _write_csv(self, snap: AccelSnapshot, sys_snap: Optional[SystemSnapshot]) -> None:
        row = self._build_flat_row(snap, sys_snap)

        if not self._csv_file:
            write_header = not self.filepath.exists() or self.filepath.stat().st_size == 0
            self._csv_file = open(self.filepath, "a", encoding="utf-8", newline="")
            self._csv_writer = csv.DictWriter(self._csv_file, fieldnames=list(row.keys()))
            if write_header:
                self._csv_writer.writeheader()
                self._csv_headers_written = True
            else:
                self._csv_headers_written = True
                
        try:
            filtered_row = {k: v for k, v in row.items() if k in self._csv_writer.fieldnames}
            self._csv_writer.writerow(filtered_row)
            self._csv_file.flush()
        except Exception as e:
            logger.error(f"Failed to write CSV row: {e}")

    def _write_sqlite(self, snap: AccelSnapshot, sys_snap: Optional[SystemSnapshot]) -> None:
        import sqlite3
        row = self._build_flat_row(snap, sys_snap)
        if not hasattr(self, "_sqlite_conn"):
            self._sqlite_conn = sqlite3.connect(self.filepath, check_same_thread=False)
            cols = []
            for k, v in row.items():
                ctype = "REAL" if isinstance(v, float) else "INTEGER" if isinstance(v, int) else "TEXT"
                cols.append(f"{k} {ctype}")
            create_stmt = f"CREATE TABLE IF NOT EXISTS metrics ({', '.join(cols)})"
            self._sqlite_conn.execute(create_stmt)
            self._sqlite_conn.commit()

        placeholders = ", ".join(["?"] * len(row))
        keys = list(row.keys())
        values = [row[k] for k in keys]
        insert_stmt = f"INSERT INTO metrics ({', '.join(keys)}) VALUES ({placeholders})"
        try:
            self._sqlite_conn.execute(insert_stmt, values)
            self._sqlite_conn.commit()
        except sqlite3.OperationalError:
            pass

    def _write_markdown(self, snap: AccelSnapshot, sys_snap: Optional[SystemSnapshot]) -> None:
        row = self._build_flat_row(snap, sys_snap)
        write_header = not self.filepath.exists() or self.filepath.stat().st_size == 0
        with open(self.filepath, "a", encoding="utf-8") as f:
            if write_header:
                headers = list(row.keys())
                f.write("| " + " | ".join(headers) + " |\n")
                f.write("|" + "|".join(["---"] * len(headers)) + "|\n")
            values = [str(v) for v in row.values()]
            f.write("| " + " | ".join(values) + " |\n")

    def _write_sqlalchemy(self, snap: AccelSnapshot, sys_snap: Optional[SystemSnapshot]) -> None:
        row = self._build_flat_row(snap, sys_snap)
        if not hasattr(self, "_sqla_engine"):
            try:
                import sqlalchemy
                from sqlalchemy import create_engine, MetaData, Table, Column, Float, Integer, String
                self._sqla_engine = create_engine(self.raw_filepath)
                metadata = MetaData()
                cols = []
                for k, v in row.items():
                    ctype = Float if isinstance(v, float) else Integer if isinstance(v, int) else String(255)
                    cols.append(Column(k, ctype))
                self._sqla_table = Table("metrics", metadata, *cols)
                metadata.create_all(self._sqla_engine)
            except ImportError:
                logger.error("SQLAlchemy required. Provide via pip install sqlalchemy, or use sqlite format")
                return
            except Exception as e:
                logger.error(f"Failed to init DB engine: {e}")
                return
                
        try:
            with self._sqla_engine.begin() as conn:
                conn.execute(self._sqla_table.insert().values(row))
        except Exception as e:
            logger.error(f"Failed to write to DB: {e}")
