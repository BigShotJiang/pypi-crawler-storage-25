import abc
from dataclasses import dataclass, field
from typing import List, Optional


@dataclass
class AccelProcess:
    """Represents a process running on an accelerator."""
    pid: int
    device_id: int
    process_name: str
    username: str = ""
    # Used memory mapped to this process on the accelerator (in MiB)
    mem_usage: float = 0.0


@dataclass
class AccelDevice:
    """Represents an accelerator device (NPU, GPU, etc.)."""
    device_id: int
    name: str
    temperature: float
    power: float
    utilization_rate: float
    mem_used: float  # MiB
    mem_total: float # MiB
    health: str
    
    # PCI bus id or equivalent
    bus_id: str = ""
    
    # List of processes running on this device
    processes: List[AccelProcess] = field(default_factory=list)

    @property
    def mem_usage_percent(self) -> float:
        """Returns the memory usage as a percentage (0.0 to 100.0)."""
        if self.mem_total <= 0:
            return 0.0
        return min((self.mem_used / self.mem_total) * 100.0, 100.0)

    @property
    def mem_free(self) -> float:
        """Returns the free memory in MiB."""
        return max(self.mem_total - self.mem_used, 0.0)


@dataclass
class AccelSnapshot:
    """A snapshot of all accelerator devices at a specific time."""
    timestamp: float
    devices: List[AccelDevice] = field(default_factory=list)
    driver_version: str = ""
    error: Optional[str] = None


class Backend(abc.ABC):
    """Abstract base class for all accelerator backends."""
    
    name: str = "unknown"
    priority: int = 100

    @abc.abstractmethod
    def probe(self) -> bool:
        """
        Quickly check if this backend is available and working.
        Should return True if available, False otherwise.
        This must be lightweight (< 100ms).
        """
        pass

    @abc.abstractmethod
    def collect(self) -> AccelSnapshot:
        """
        Collect and return a full snapshot of the accelerator state.
        """
        pass
