"""
Backend implementation for AMD GPUs covering `amd-smi` and older `rocm-smi`.
"""

import csv
import logging
import re
import subprocess
import time
from typing import Dict, List, Tuple

from xputop.core.backend import AccelDevice, AccelProcess, AccelSnapshot, Backend

logger = logging.getLogger(__name__)


def safe_float(s: str, default: float = 0.0) -> float:
    try:
        return float(re.sub(r"[^\d.]+", "", s))
    except Exception:
        return default


class AmdBackend(Backend):
    """
    Rocm / AMD backend.
    Checks `amd-smi` first, falls back to `rocm-smi`.
    """
    name = "AMD GPU"
    priority = 25

    def __init__(self):
        self._cmd = ""
        self._is_amd_smi = False

    def probe(self) -> bool:
        """Check if amd-smi or rocm-smi exists."""
        try:
            subprocess.run(["amd-smi", "version"], stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=3)
            self._cmd = "amd-smi"
            self._is_amd_smi = True
            return True
        except (FileNotFoundError, subprocess.TimeoutExpired):
            pass

        try:
            subprocess.run(["rocm-smi", "--version"], stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=3)
            self._cmd = "rocm-smi"
            self._is_amd_smi = False
            return True
        except (FileNotFoundError, subprocess.TimeoutExpired):
            return False

    def collect(self) -> AccelSnapshot:
        if not self._cmd:
            return AccelSnapshot(time.time(), [], "N/A", "AMD tools not found.")

        devices: List[AccelDevice] = []
        driver = "Unknown"
        error = None

        if self._is_amd_smi:
            devices, driver, error_msg = self._collect_amd_smi()
            if error_msg:
                error = error_msg
        else:
            devices, driver, error_msg = self._collect_rocm_smi()
            if error_msg:
                error = error_msg

        return AccelSnapshot(
            timestamp=time.time(),
            devices=devices,
            driver_version=driver,
            error=error,
        )

    def _collect_rocm_smi(self) -> Tuple[List[AccelDevice], str, str]:
        """
        Fallback parser for older rocm-smi using plain raw text output.
        `rocm-smi -a` dumps all metrics line by line per GPU.
        """
        try:
            res = subprocess.run(
                [self._cmd, "-a"],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                timeout=5
            )
            if res.returncode != 0:
                return [], "N/A", f"rocm-smi failed: {res.stderr.strip()}"
            
            output = res.stdout
        except Exception as e:
            return [], "N/A", f"rocm-smi exec error: {e}"

        driver_ver = "ROCm"
        # Try to extract rocm-smi version if possible from a separate call 
        # but for performance let's just stick to "ROCm".

        # Group lines by GPU[id]
        # Example lines:
        # GPU[0]: Temperature (Sensor edge) (C): 45
        # GPU[0]: GPU use (%): 100
        # GPU[0]: VRAM Total Memory (B): 17163091968
        gpu_data: Dict[int, Dict[str, str]] = {}
        
        for line in output.splitlines():
            m = re.match(r"^GPU\[(\d+)\]:\s*(.*?):\s*(.*)", line.strip())
            if m:
                gid = int(m.group(1))
                key = m.group(2).strip().lower()
                val = m.group(3).strip()
                if gid not in gpu_data:
                    gpu_data[gid] = {}
                gpu_data[gid][key] = val

        devices = []
        for gid, data in sorted(gpu_data.items()):
            # Parse memory
            # Often displayed in bytes
            vram_total_b = 0.0
            vram_used_b = 0.0
            
            for k, v in data.items():
                if "vram total memory" in k and "(b)" in k:
                    vram_total_b = safe_float(v)
                elif "vram total used memory" in k and "(b)" in k:
                    vram_used_b = safe_float(v)
            
            mem_total = vram_total_b / (1024**2)
            mem_used = vram_used_b / (1024**2)
            
            # Temps (take max if multiple or default to edge)
            temp = 0.0
            for k, v in data.items():
                if "temperature" in k and "(c)" in k:
                    t_val = safe_float(v)
                    temp = max(temp, t_val)

            # Util
            util = 0.0
            for k, v in data.items():
                if "gpu use (%)" in k:
                    util = safe_float(v)
            
            # Power
            power = 0.0
            for k, v in data.items():
                if "average graphics package power" in k and "(w)" in k:
                    power = safe_float(v)

            dev = AccelDevice(
                device_id=gid,
                name="AMD GPU",
                temperature=temp,
                power=power,
                utilization_rate=util,
                mem_used=mem_used,
                mem_total=mem_total,
                health="OK",
            )
            devices.append(dev)

        return devices, driver_ver, ""

    def _collect_amd_smi(self) -> Tuple[List[AccelDevice], str, str]:
        """
        Parser for the newer amd-smi tool using CSV dump format.
        """
        try:
            res = subprocess.run(
                [self._cmd, "metric", "--csv"],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                timeout=5
            )
            if res.returncode != 0:
                return [], "N/A", f"amd-smi failed: {res.stderr.strip()}"
            output = res.stdout
        except Exception as e:
            return [], "N/A", f"amd-smi error: {e}"

        driver_ver = "AMD-SMI"
        devices = []
        
        # `amd-smi metric --csv` emits headers then rows.
        lines = output.strip().splitlines()
        if not lines:
            return [], driver_ver, "amd-smi yielded empty output"

        reader = csv.DictReader(lines)
        for row in reader:
            # We don't perfectly know all column headers beforehand, they dynamically adjust.
            # We'll normalize case and search for substrings
            # typical headers: GPU, Power (W), Temperature (C), VRAM Total (MB), VRAM Used (MB), Usage (%)
            row_lower = {k.strip().lower(): v for k, v in row.items()}
            
            gid = 0
            temp = 0.0
            power = 0.0
            util = 0.0
            mem_total = 0.0
            mem_used = 0.0
            
            for k, v in row_lower.items():
                if "gpu" == k:
                    gid = int(safe_float(v))
                elif "temp" in k:
                    temp = max(temp, safe_float(v))
                elif "power" in k:
                    power = max(power, safe_float(v))
                elif "usage" in k or "util" in k:
                    util = max(util, safe_float(v))
                elif "vram total" in k:
                    # Sometimes MB, sometimes B
                    val = safe_float(v)
                    if val > 1_000_000: # highly likely Bytes
                        val = val / (1024**2)
                    mem_total = max(mem_total, val)
                elif "vram used" in k:
                    val = safe_float(v)
                    if val > 1_000_000:
                        val = val / (1024**2)
                    mem_used = max(mem_used, val)

            dev = AccelDevice(
                device_id=gid,
                name="AMD GPU",
                temperature=temp,
                power=power,
                utilization_rate=util,
                mem_used=mem_used,
                mem_total=mem_total,
                health="OK"
            )
            devices.append(dev)

        return devices, driver_ver, ""
