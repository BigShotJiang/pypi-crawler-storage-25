import json
import os
from typing import Dict, List, Optional

from xputop.core.backend import Backend
from xputop.core.backends.custom import CustomBackend
from xputop.core.backends.npu import NpuBackend
from xputop.core.backends.nvidia import NvidiaBackend
from xputop.core.backends.amd import AmdBackend
from xputop.core.backends.intel import IntelBackend
from xputop.core.backends.tpu import TpuBackend


class FallbackBackend(Backend):
    """Used when no accelerator can be found."""
    name = "None"
    priority = 999

    def probe(self) -> bool:
        return True

    def collect(self):
        from xputop.core.backend import AccelSnapshot
        import time
        return AccelSnapshot(
            timestamp=time.time(),
            error="No supported accelerator detected. Are drivers installed?"
        )


_CACHE_FILE = os.path.expanduser("~/.cache/xputop/backend.json")


def _load_cache() -> Optional[Dict]:
    if os.path.exists(_CACHE_FILE):
        try:
            with open(_CACHE_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            pass
    return None


def _save_cache(backend_info: Dict) -> None:
    cache_dir = os.path.dirname(_CACHE_FILE)
    if not os.path.exists(cache_dir):
        try:
            os.makedirs(cache_dir, exist_ok=True)
        except OSError:
            return  # Fail silently if cannot write cache
    try:
        with open(_CACHE_FILE, "w", encoding="utf-8") as f:
            json.dump(backend_info, f)
    except Exception:
        pass


def get_available_backends(config: Optional[Dict] = None) -> List[Backend]:
    """Returns a list of all recognized backends, sorted by priority."""
    backends: List[Backend] = []
    
    cfg = config or {}
    custom_dict = cfg.get("backend_custom", {})
    if not custom_dict:
        # Fallback for nested formats
        b_dict = cfg.get("backend", {})
        if isinstance(b_dict, dict):
            custom_dict = b_dict.get("custom", {})

    if isinstance(custom_dict, dict):
        for k, v in custom_dict.items():
            if isinstance(v, dict):
                backends.append(CustomBackend(k, v))
            
    backends.extend([
        NpuBackend(),
        NvidiaBackend(),
        AmdBackend(),
        IntelBackend(),
        TpuBackend()
    ])
    backends.sort(key=lambda b: getattr(b, "priority", 100))
    return backends


def get_backend(config: Optional[Dict] = None, force_backend: Optional[str] = None) -> Backend:
    """
    Decides which backend to use.
    """
    backends = get_available_backends(config)
    
    # 1. Force backend
    if force_backend and force_backend.lower() != "auto":
        fb = force_backend.lower()
        selected = None
        if fb == "npu":
            selected = NpuBackend()
        elif fb == "nvidia":
            selected = NvidiaBackend()
        elif fb == "amd":
            selected = AmdBackend()
        elif fb == "intel":
            selected = IntelBackend()
        elif fb == "tpu":
            selected = TpuBackend()
        elif fb.startswith("custom:"):
            name = fb.split(":", 1)[1]
            for b in backends:
                if getattr(b, "key_name", None) == name:
                    selected = b
                    break
        if not selected:
            for b in backends:
                if b.name.lower() == fb:
                    selected = b
                    break
        
        if selected:
            _save_cache({"name": selected.name})
            return selected

    # 2. Check cache
    cache = _load_cache()
    if cache and "name" in cache:
        cached_name = cache["name"]
        for b in backends:
            if b.name == cached_name:
                if b.probe():
                    return b

    # 3. Probe iteratively
    for b in backends:
        if b.probe():
            _save_cache({"name": b.name})
            return b

    # 4. Fallback (Fail)
    return FallbackBackend()
