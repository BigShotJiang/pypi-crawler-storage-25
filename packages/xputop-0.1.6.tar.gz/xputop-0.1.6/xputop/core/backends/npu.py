import re
import subprocess
import time
from typing import Dict, List, Tuple

from xputop.core.backend import AccelDevice, AccelProcess, AccelSnapshot, Backend


def _run_npu_smi(*args: str, timeout: int = 5) -> Tuple[int, str]:
    """Run npu-smi with given arguments and return (returncode, stdout)."""
    cmd = ["npu-smi"] + list(args)
    try:
        proc = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=timeout,
        )
        return proc.returncode, proc.stdout
    except FileNotFoundError:
        return -1, ""
    except subprocess.TimeoutExpired:
        return -2, ""
    except Exception as exc:  # noqa: BLE001
        return -3, str(exc)


def _parse_float(text: str, default: float = 0.0) -> float:
    try:
        return float(text.strip())
    except (ValueError, AttributeError):
        return default


def _safe_int(text: str, default: int = 0) -> int:
    try:
        return int(text.strip())
    except (ValueError, AttributeError):
        return default


def parse_npu_smi_info(output: str) -> Tuple[str, List[AccelDevice], Dict]:
    driver_version = ""
    npu_power_cache: Dict[int, float] = {}
    dv_match = re.search(r"Version\s*[:=]\s*([\d.]+)", output, re.IGNORECASE)
    if dv_match:
        driver_version = dv_match.group(1)

    devices: List[AccelDevice] = []
    npu_chip_map: Dict[Tuple[int, int], int] = {}

    row_pattern = re.compile(
        r"^\s*(\d+)\s+(\d+)\s+(\S+)\s+(OK|WARNING|ALARM|ERROR)\s+"
        r"([\d.]+)\s+([\d.]+)\s+.*?(\d+)\s*/\s*(\d+)",
        re.MULTILINE | re.IGNORECASE,
    )

    for m in row_pattern.finditer(output):
        npu_id = _safe_int(m.group(1))
        chip_name = m.group(3)
        health = m.group(4)
        col5 = _parse_float(m.group(5))
        col6 = _parse_float(m.group(6))
        hbm_used = _parse_float(m.group(7))
        hbm_total = _parse_float(m.group(8))

        if col5 > 200:
            power, temperature = col5, col6
            aicore_rate = 0.0
        elif col6 > 150:
            aicore_rate, power = col5, col6
            temperature = 0.0
        else:
            power = col5
            temperature = col6
            aicore_rate = 0.0

        dev = AccelDevice(
            device_id=npu_id,
            name=chip_name,
            temperature=temperature,
            power=power,
            utilization_rate=aicore_rate,
            mem_used=hbm_used,
            mem_total=hbm_total,
            health=health,
        )
        devices.append(dev)

    if not devices:
        r1_re = re.compile(
            r"\|\s*(\d+)\s+(\S+)\s*\|\s*(OK|WARNING|ALARM|ERROR)\s*\|"
            r"\s*([\d.]+|-)\s+(\d+)\s+(\d+)\s*/\s*(\d+)\s*\|",
            re.IGNORECASE,
        )
        r2_re = re.compile(
            r"\|\s*(\d+)\s+(\d+)\s*\|\s*(\S+)\s*\|"
            r"\s*(\d+)\s+(\d+)\s*/\s*(\d+)\s+(\d+)\s*/\s*(\d+)\s*\|",
            re.IGNORECASE,
        )

        r1_list = list(r1_re.finditer(output))
        r2_list = list(r2_re.finditer(output))

        for r1, r2 in zip(r1_list, r2_list):
            npu_id = _safe_int(r1.group(1))
            chip_name = r1.group(2)
            health = r1.group(3)
            power_s = r1.group(4)
            power = 0.0 if power_s == "-" else _parse_float(power_s)
            temperature = _parse_float(r1.group(5))

            chip_id = _safe_int(r2.group(1))
            phy_id = _safe_int(r2.group(2))
            bus_id = r2.group(3)
            aicore_rate = _parse_float(r2.group(4))
            hbm_used = _parse_float(r2.group(7))
            hbm_total = _parse_float(r2.group(8))

            # Distribute power from primary chip to secondary if represented as "-"
            if npu_id not in npu_power_cache and power > 0:
                npu_power_cache[npu_id] = power
            elif power <= 0 and npu_id in npu_power_cache:
                power = npu_power_cache[npu_id]

            dev = AccelDevice(
                device_id=phy_id,
                name=chip_name,
                temperature=temperature,
                power=power,
                utilization_rate=aicore_rate,
                mem_used=hbm_used,
                mem_total=hbm_total,
                health=health,
                bus_id=bus_id,
            )
            devices.append(dev)
            npu_chip_map[(npu_id, chip_id)] = phy_id

    if not devices:
        kv_blocks = re.split(r"-{20,}", output)
        for block in kv_blocks:
            npu_match = re.search(r"NPU\s*ID\s*[:=]\s*(\d+)", block, re.IGNORECASE)
            if not npu_match:
                continue
            npu_id = _safe_int(npu_match.group(1))

            chip_match = re.search(r"Chip\s*Name\s*[:=]\s*(\S+)", block, re.IGNORECASE)
            chip_name = chip_match.group(1) if chip_match else "Ascend"

            temp_match = re.search(r"Temp.*?[:=]\s*([\d.]+)", block, re.IGNORECASE)
            power_match = re.search(r"Power.*?[:=]\s*([\d.]+)", block, re.IGNORECASE)
            aicore_match = re.search(r"AI\s*Core.*?[:=]\s*([\d.]+)", block, re.IGNORECASE)
            hbm_match = re.search(r"HBM.*?[:=]\s*([\d.]+)\s*/\s*([\d.]+)", block, re.IGNORECASE)
            health_match = re.search(r"Health\s*[:=]\s*(\w+)", block, re.IGNORECASE)

            dev = AccelDevice(
                device_id=npu_id,
                name=chip_name,
                temperature=_parse_float(temp_match.group(1)) if temp_match else 0.0,
                power=_parse_float(power_match.group(1)) if power_match else 0.0,
                utilization_rate=_parse_float(aicore_match.group(1)) if aicore_match else 0.0,
                mem_used=_parse_float(hbm_match.group(1)) if hbm_match else 0.0,
                mem_total=_parse_float(hbm_match.group(2)) if hbm_match else 0.0,
                health=health_match.group(1) if health_match else "OK",
            )
            devices.append(dev)

    return driver_version, devices, npu_chip_map


def _parse_pipe_processes(output: str) -> List[Tuple[int, int, AccelProcess]]:
    results: List[Tuple[int, int, AccelProcess]] = []
    proc_re = re.compile(
        r"\|\s*(\d+)\s+(\d+)\s*\|\s*(\d+)\s*\|\s*(\S+)\s*\|\s*(\d+)\s*\|",
    )

    in_proc = False
    for line in output.splitlines():
        lower = line.lower()
        if "process id" in lower or "process name" in lower:
            in_proc = True
            continue
        if not in_proc:
            continue
        m = proc_re.search(line)
        if m:
            npu_id = _safe_int(m.group(1))
            chip_id = _safe_int(m.group(2))
            pid = _safe_int(m.group(3))
            name = m.group(4)
            mem = _parse_float(m.group(5))
            if pid > 0:
                results.append((npu_id, chip_id, AccelProcess(
                    pid=pid,
                    device_id=0,
                    process_name=name,
                    mem_usage=mem,
                )))
    return results


def parse_npu_smi_processes(output: str) -> List[AccelProcess]:
    processes: List[AccelProcess] = []
    proc_re = re.compile(r"^\s*(\d+)\s+(\d+)\s+(\S+)", re.MULTILINE)

    in_process_section = False
    for line in output.splitlines():
        lower = line.lower()
        if "process" in lower and ("pid" in lower or "name" in lower):
            in_process_section = True
            continue
        if not in_process_section:
            if re.match(r"^\s*=", line) or re.match(r"^\s*-", line):
                continue
        if in_process_section:
            m = proc_re.match(line)
            if m:
                dev_id = _safe_int(m.group(1))
                pid = _safe_int(m.group(2))
                pname = m.group(3)
                if pid > 0:
                    processes.append(AccelProcess(
                        pid=pid,
                        device_id=dev_id,
                        process_name=pname,
                    ))

    if not processes:
        for m in proc_re.finditer(output):
            dev_id = _safe_int(m.group(1))
            pid = _safe_int(m.group(2))
            pname = m.group(3)
            if pid > 100 and not pname.startswith("-") and not pname.startswith("="):
                processes.append(AccelProcess(
                    pid=pid,
                    device_id=dev_id,
                    process_name=pname,
                ))

    return processes


class NpuBackend(Backend):
    name = "Huawei NPU"
    priority = 10

    def probe(self) -> bool:
        try:
            rc, _ = _run_npu_smi("info", timeout=3)
            return rc == 0
        except Exception:
            return False

    def collect(self) -> AccelSnapshot:
        ts = time.time()
        rc, info_output = _run_npu_smi("info")
        if rc != 0:
            return AccelSnapshot(
                timestamp=ts,
                error=f"npu-smi info failed (rc={rc}). Is the Ascend driver installed?",
            )

        driver_version, devices, npu_chip_map = parse_npu_smi_info(info_output)

        if not devices:
            preview = info_output[:500].strip()
            return AccelSnapshot(
                timestamp=ts,
                driver_version=driver_version,
                error=(
                    "npu-smi info returned OK but no devices were detected. "
                    "The output format may not match the parser. "
                    f"Raw output preview:\n{preview}"
                ),
            )

        rc2, proc_output = _run_npu_smi("info", "-t", "proc-info")
        dev_map: Dict[int, AccelDevice] = {d.device_id: d for d in devices}

        attached = False
        if npu_chip_map:
            for source in ([proc_output] if rc2 == 0 else []) + [info_output]:
                pipe_procs = _parse_pipe_processes(source)
                if pipe_procs:
                    for npu_id, chip_id, proc in pipe_procs:
                        dev_id = npu_chip_map.get((npu_id, chip_id))
                        if dev_id is not None and dev_id in dev_map:
                            proc.device_id = dev_id
                            dev_map[dev_id].processes.append(proc)
                    attached = True
                    break

        if not attached:
            proc_text = proc_output if rc2 == 0 else info_output
            all_procs = parse_npu_smi_processes(proc_text)
            for proc in all_procs:
                if proc.device_id in dev_map:
                    dev_map[proc.device_id].processes.append(proc)

        return AccelSnapshot(
            timestamp=ts,
            devices=devices,
            driver_version=driver_version,
        )
