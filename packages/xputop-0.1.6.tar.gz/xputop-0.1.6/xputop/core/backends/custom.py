import re
import subprocess
import time
from typing import Dict, List

from xputop.core.backend import AccelDevice, AccelProcess, AccelSnapshot, Backend


def _parse_float(text: str, default: float = 0.0) -> float:
    if not text:
        return default
    try:
        return float(text.strip())
    except (ValueError, AttributeError):
        return default


def _safe_int(text: str, default: int = 0) -> int:
    if not text:
        return default
    try:
        return int(text.strip())
    except (ValueError, AttributeError):
        return default


class CustomBackend(Backend):
    """
    A customizable backend driven by shell commands and regex patterns
    defined in the user's config file.
    """

    def __init__(self, key_name: str, config: Dict):
        self.key_name = key_name
        self.name = f"Custom ({key_name})"
        # Custom backends take precedence if they pass the probe
        self.priority = 5

        self.probe_command = config.get("probe_command", "")
        self.info_command = config.get("info_command", "")
        self.device_pattern = config.get("device_pattern", "")
        self.process_command = config.get("process_command", "")
        self.process_pattern = config.get("process_pattern", "")

        self._info_re = None
        self._proc_re = None

        if self.device_pattern:
            self._info_re = re.compile(self.device_pattern, re.MULTILINE | re.IGNORECASE)
        if self.process_pattern:
            self._proc_re = re.compile(self.process_pattern, re.MULTILINE | re.IGNORECASE)

    def probe(self) -> bool:
        """Check if this custom backend's CLI tool is available."""
        if not self.probe_command or not self._info_re:
            return False
            
        try:
            # We use shell=True because users might define chained commands
            rc = subprocess.run(
                self.probe_command,
                shell=True,
                capture_output=True,
                timeout=2,
            ).returncode
            return rc == 0
        except Exception:
            return False

    def collect(self) -> AccelSnapshot:
        ts = time.time()
        
        if not self.info_command or not self._info_re:
            return AccelSnapshot(timestamp=ts, error="Custom backend missing info_command or device_pattern.")

        # 1. Collect Device Info
        try:
            info_proc = subprocess.run(
                self.info_command,
                shell=True,
                capture_output=True,
                text=True,
                timeout=5,
            )
            if info_proc.returncode != 0:
                return AccelSnapshot(
                    timestamp=ts, 
                    error=f"Custom backend info command failed: {info_proc.stderr.strip()}"
                )
        except Exception as e:
            return AccelSnapshot(timestamp=ts, error=str(e))

        devices: List[AccelDevice] = []
        dev_map: Dict[int, AccelDevice] = {}

        for m in self._info_re.finditer(info_proc.stdout):
            groups = m.groupdict()
            dev_id = _safe_int(groups.get("id"), len(devices))
            
            dev = AccelDevice(
                device_id=dev_id,
                name=groups.get("name", "CustomAccelerator"),
                temperature=_parse_float(groups.get("temp")),
                power=_parse_float(groups.get("power")),
                utilization_rate=_parse_float(groups.get("util")),
                mem_used=_parse_float(groups.get("mem_used")),
                mem_total=_parse_float(groups.get("mem_total")),
                health=groups.get("health", "OK"),
                bus_id=groups.get("bus_id", ""),
            )
            devices.append(dev)
            dev_map[dev_id] = dev

        # 2. Collect Process Info (Optional)
        if self.process_command and self._proc_re and devices:
            try:
                proc_proc = subprocess.run(
                    self.process_command,
                    shell=True,
                    capture_output=True,
                    text=True,
                    timeout=5,
                )
                if proc_proc.returncode == 0:
                    for m in self._proc_re.finditer(proc_proc.stdout):
                        groups = m.groupdict()
                        pid = _safe_int(groups.get("pid"))
                        if pid <= 0:
                            continue
                            
                        # Try to map by dev_id, fallback to bus_id if regex captures it
                        target_dev = None
                        if "dev_id" in groups:
                            target_dev = dev_map.get(_safe_int(groups["dev_id"]))
                        elif "bus_id" in groups:
                            b_id = groups["bus_id"].lower()
                            for d in devices:
                                if d.bus_id.lower() == b_id:
                                    target_dev = d
                                    break
                                    
                        if target_dev:
                            target_dev.processes.append(AccelProcess(
                                pid=pid,
                                device_id=target_dev.device_id,
                                process_name=groups.get("name", "unknown"),
                                username=groups.get("user", ""),
                                mem_usage=_parse_float(groups.get("mem_used")),
                            ))
            except Exception:
                pass  # Ignore process collection failures

        return AccelSnapshot(
            timestamp=ts,
            devices=devices,
            driver_version=self.name,
        )
