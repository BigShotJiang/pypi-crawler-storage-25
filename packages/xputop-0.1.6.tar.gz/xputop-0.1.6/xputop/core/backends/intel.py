"""
Backend implementation for Intel Data Center and Flex Series GPUs via `xpu-smi`.
"""

import csv
import logging
import re
import subprocess
import time
from typing import Dict, List, Tuple

from xputop.core.backend import AccelDevice, AccelProcess, AccelSnapshot, Backend

logger = logging.getLogger(__name__)


def safe_float(s: str, default: float = 0.0) -> float:
    try:
        return float(re.sub(r"[^\d.]+", "", s))
    except Exception:
        return default


class IntelBackend(Backend):
    """
    Intel XPU backend using `xpu-smi`.
    """
    name = "Intel GPU"
    priority = 25

    def probe(self) -> bool:
        """Check if xpu-smi exists."""
        try:
            subprocess.run(["xpu-smi", "version"], stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=3)
            return True
        except (FileNotFoundError, subprocess.TimeoutExpired):
            return False

    def collect(self) -> AccelSnapshot:
        try:
            # -m 18 covers memory, power, utilization, temp
            # -n 1 requests exactly 1 sample iteration
            res = subprocess.run(
                ["xpu-smi", "dump", "-m", "18", "-n", "1"],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                timeout=5
            )
            if res.returncode != 0:
                return AccelSnapshot(
                    time.time(), [], "xpu-smi", f"xpu-smi failed: {res.stderr.strip()}"
                )
            
            output = res.stdout
        except Exception as e:
            return AccelSnapshot(
                time.time(), [], "xpu-smi", f"xpu-smi exec error: {e}"
            )

        driver_ver = "xpu-smi"
        devices = []
        
        lines = output.strip().splitlines()
        if not lines:
            return AccelSnapshot(time.time(), [], driver_ver, "xpu-smi yielded empty output")

        reader = csv.DictReader(lines)
        for row in reader:
            row_lower = {k.strip().lower(): v for k, v in row.items()}
            
            gid = 0
            temp = 0.0
            power = 0.0
            util = 0.0
            mem_total = 0.0
            mem_used = 0.0
            
            for k, val in row_lower.items():
                if "device id" in k:
                    gid = int(safe_float(val))
                elif "temperature" in k and "(c)" in k:
                    temp = max(temp, safe_float(val))
                elif "power" in k and "(w)" in k:
                    power = max(power, safe_float(val))
                elif "utilization" in k and "(%)" in k:
                    util = max(util, safe_float(val))
                elif "memory capacity" in k and "(mb)" in k:
                    mem_total = max(mem_total, safe_float(val))
                elif "memory used" in k and "(mb)" in k:
                    mem_used = max(mem_used, safe_float(val))

            dev = AccelDevice(
                device_id=gid,
                name="Intel XPU",
                temperature=temp,
                power=power,
                utilization_rate=util,
                mem_used=mem_used,
                mem_total=mem_total,
                health="OK"
            )
            devices.append(dev)

        return AccelSnapshot(
            timestamp=time.time(),
            devices=devices,
            driver_version=driver_ver,
            error=None
        )
