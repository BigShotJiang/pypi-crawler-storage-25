"""
Backend implementation for Google Cloud TPU via `tpu-info`.
"""

import logging
import re
import subprocess
import time
from typing import Dict, List, Tuple

from xputop.core.backend import AccelDevice, AccelProcess, AccelSnapshot, Backend

logger = logging.getLogger(__name__)


def safe_float(s: str, default: float = 0.0) -> float:
    try:
        return float(re.sub(r"[^\d.]+", "", s))
    except Exception:
        return default


class TpuBackend(Backend):
    """
    Google Cloud TPU backend via `tpu-info`.
    """
    name = "Google TPU"
    priority = 25

    def probe(self) -> bool:
        """Check if tpu-info exists."""
        try:
            # tpu-info usually runs fast and dumps current state if run without arguments
            subprocess.run(["tpu-info"], stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=2)
            return True
        except FileNotFoundError:
            return False

    def collect(self) -> AccelSnapshot:
        try:
            res = subprocess.run(
                ["tpu-info"],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                timeout=5
            )
            if res.returncode != 0:
                return AccelSnapshot(
                    time.time(), [], "tpu-info", f"tpu-info failed: {res.stderr.strip()}"
                )
            
            output = res.stdout
        except Exception as e:
            return AccelSnapshot(
                time.time(), [], "tpu-info", f"tpu-info exec error: {e}"
            )

        driver_ver = "tpu-info"
        devices: List[AccelDevice] = []
        
        # Heuristic parser for tpu-info
        # TPU blocks usually start with something like "TPU 0:" or "Device 0"
        # Since formats change, we'll try to find any numbers associated with Duty Cycle, Memory, and Temperature.
        # Fallback to single TPU representation if multiple cannot be reliably parsed.
        
        current_id = 0
        current_util = []
        current_mem_total = 16384.0 # 16GB default
        current_mem_used = 0.0
        current_temp = []
        current_power = 0.0
        
        for line in output.splitlines():
            line = line.strip().lower()
            if not line:
                continue
                
            # If line specifies a device or TPU id
            if "tpu" in line and ":" in line:
                m = re.search(r"tpu\s*(\d+)", line)
                if m:
                    current_id = int(m.group(1))
            
            # Util - Google TPU uses "duty cycle" or "tensorcore"
            if "duty cycle" in line or "utilization" in line or "tensorcore" in line:
                m = re.search(r"(\d+(?:\.\d+)?)\s*%", line)
                if m:
                    current_util.append(float(m.group(1)))
            
            # Memory
            if "memory" in line or "hbm" in line:
                # e.g., "Memory Usage: 4000 / 16384 MB"
                mm = re.search(r"(\d+(?:\.\d+)?)\s*/\s*(\d+(?:\.\d+)?)\s*(mb|gb)", line)
                if mm:
                    used = float(mm.group(1))
                    tot = float(mm.group(2))
                    unit = mm.group(3)
                    if unit == "gb":
                        used *= 1024
                        tot *= 1024
                    current_mem_used = used
                    current_mem_total = tot
                else:
                    # just try to catch "%"
                    sm = re.search(r"(\d+(?:\.\d+)?)\s*%", line)
                    if sm:
                        # Only assume utilization percent
                        pass
            
            # Temperature
            if "temp" in line or "temperature" in line:
                tm = re.search(r"(\d+(?:\.\d+)?)\s*(?:c|°c)", line)
                if tm:
                    current_temp.append(float(tm.group(1)))

        # Just emit one summary device if structure was mostly flat,
        # or properly append if multiple TPUs were seen.
        
        avg_util = sum(current_util) / len(current_util) if current_util else 0.0
        max_temp = max(current_temp) if current_temp else 0.0
        
        dev = AccelDevice(
            device_id=current_id,
            name="Google TPU",
            temperature=max_temp,
            power=current_power,
            utilization_rate=avg_util,
            mem_used=current_mem_used,
            mem_total=current_mem_total,
            health="OK",
        )
        devices.append(dev)

        return AccelSnapshot(
            timestamp=time.time(),
            devices=devices,
            driver_version=driver_ver,
            error=None
        )
