import random
import time
from typing import List

from xputop.core.backend import AccelDevice, AccelProcess, AccelSnapshot, Backend
import math


class DemoBackend(Backend):
    name = "Demo Backend"
    priority = 1

    def __init__(self, num_devices: int = 4):
        self.num_devices = num_devices

    def probe(self) -> bool:
        return True

    def collect(self) -> AccelSnapshot:
        devices: List[AccelDevice] = []
        t = time.time()
        for i in range(self.num_devices):
            hbm_total = 65536.0  # 64 GB HBM
            
            # Smooth sine variations for demonstration of moving charts
            offset1 = i * 2.5
            offset2 = i * 4.1
            smooth_util = (math.sin(t / 3.0 + offset1) * 40) + 50 + random.uniform(-5, 5)
            smooth_mem_pct = (math.sin(t / 5.0 + offset2) * 30) + 40 + random.uniform(-2, 2)
            
            smooth_util = max(0.0, min(100.0, smooth_util))
            smooth_mem_pct = max(0.0, min(100.0, smooth_mem_pct))
            
            hbm_used = (smooth_mem_pct / 100.0) * hbm_total
            
            dev = AccelDevice(
                device_id=i,
                name="DemoAccelerator",
                temperature=40 + (smooth_util * 0.4) + random.uniform(-1, 1),
                power=50 + (smooth_util * 2.5) + random.uniform(-5, 5),
                utilization_rate=smooth_util,
                mem_used=round(hbm_used, 1),
                mem_total=hbm_total,
                health=random.choice(["OK", "OK", "OK", "WARNING"]),
            )
            # Fake processes
            n_procs = random.randint(0, 4)
            for _ in range(n_procs):
                dev.processes.append(AccelProcess(
                    pid=random.randint(1000, 99999),
                    device_id=i,
                    process_name=random.choice([
                        "python3", "mindspore", "torch_npu", "hccl_worker",
                        "aicpu_daemon", "training.py", "inference_server",
                    ]),
                    mem_usage=random.uniform(100, 8000),
                ))
            devices.append(dev)

        return AccelSnapshot(
            timestamp=time.time(),
            devices=devices,
            driver_version="1.0.0 (demo)",
        )
