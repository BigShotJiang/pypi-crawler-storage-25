import subprocess
import time
from typing import Dict, List

from xputop.core.backend import AccelDevice, AccelProcess, AccelSnapshot, Backend


def _parse_float(text: str, default: float = 0.0) -> float:
    try:
        # Some fields might be [Not Supported]
        return float(text.strip())
    except (ValueError, AttributeError):
        return default


def _safe_int(text: str, default: int = 0) -> int:
    try:
        return int(text.strip())
    except (ValueError, AttributeError):
        return default


class NvidiaBackend(Backend):
    name = "NVIDIA GPU"
    priority = 20

    def probe(self) -> bool:
        """Check if nvidia-smi is available."""
        try:
            rc = subprocess.run(
                ["nvidia-smi", "--version"],
                capture_output=True,
                timeout=3,
            ).returncode
            return rc == 0
        except (FileNotFoundError, subprocess.TimeoutExpired):
            return False

    def collect(self) -> AccelSnapshot:
        ts = time.time()
        
        # 1. Get Driver Version
        try:
            drv_proc = subprocess.run(
                ["nvidia-smi", "--query-gpu=driver_version", "--format=csv,noheader"],
                capture_output=True,
                text=True,
                timeout=5,
            )
            if drv_proc.returncode != 0:
                return AccelSnapshot(
                    timestamp=ts, 
                    error=f"nvidia-smi failed: {drv_proc.stderr.strip()}"
                )
            lines = drv_proc.stdout.strip().split("\n")
            driver_version = lines[0].strip() if lines else "Unknown"
        except Exception as e:
            return AccelSnapshot(timestamp=ts, error=str(e))

        # 2. Get GPUs
        # Querying specific columns without units makes parsing trivial.
        query_fields = (
            "index,name,temperature.gpu,power.draw,utilization.gpu,"
            "memory.used,memory.total,pci.bus_id"
        )
        try:
            gpu_proc = subprocess.run(
                [
                    "nvidia-smi", 
                    f"--query-gpu={query_fields}", 
                    "--format=csv,noheader,nounits"
                ],
                capture_output=True,
                text=True,
                timeout=5,
            )
            if gpu_proc.returncode != 0:
                return AccelSnapshot(
                    timestamp=ts, 
                    error=f"nvidia-smi query-gpu failed: {gpu_proc.stderr.strip()}"
                )
        except Exception as e:
            return AccelSnapshot(timestamp=ts, error=str(e))

        devices: List[AccelDevice] = []
        bus_id_map: Dict[str, AccelDevice] = {}

        for line in gpu_proc.stdout.strip().split("\n"):
            if not line:
                continue
            parts = [p.strip() for p in line.split(",")]
            if len(parts) >= 8:
                dev_id = _safe_int(parts[0])
                name = parts[1]
                temp = _parse_float(parts[2])
                power = _parse_float(parts[3])
                util = _parse_float(parts[4])
                mem_used = _parse_float(parts[5])
                mem_total = _parse_float(parts[6])
                bus_id = parts[7]
                
                dev = AccelDevice(
                    device_id=dev_id,
                    name=name,
                    temperature=temp,
                    power=power,
                    utilization_rate=util,
                    mem_used=mem_used,
                    mem_total=mem_total,
                    health="OK",  # NVIDIA SMI doesn't easily expose simple OK/WARNING string here
                    bus_id=bus_id,
                )
                devices.append(dev)
                # Keep bus_id strictly uppercase for matching just in case
                bus_id_map[bus_id.upper()] = dev

        # 3. Get Processes
        try:
            proc_proc = subprocess.run(
                [
                    "nvidia-smi", 
                    "--query-compute-apps=gpu_bus_id,pid,process_name,used_memory", 
                    "--format=csv,noheader,nounits"
                ],
                capture_output=True,
                text=True,
                timeout=5,
            )
            if proc_proc.returncode == 0:
                for line in proc_proc.stdout.strip().split("\n"):
                    if not line:
                        continue
                    parts = [p.strip() for p in line.split(",")]
                    if len(parts) >= 4:
                        bus_id = parts[0].upper()
                        pid = _safe_int(parts[1])
                        pname = parts[2]
                        mem = _parse_float(parts[3])
                        
                        dev = bus_id_map.get(bus_id)
                        if dev and pid > 0:
                            dev.processes.append(AccelProcess(
                                pid=pid,
                                device_id=dev.device_id,
                                process_name=pname,
                                mem_usage=mem,
                            ))
        except Exception:
            # Process queries failing should not fail the entire snapshot
            pass

        return AccelSnapshot(
            timestamp=ts,
            devices=devices,
            driver_version=driver_version,
        )
