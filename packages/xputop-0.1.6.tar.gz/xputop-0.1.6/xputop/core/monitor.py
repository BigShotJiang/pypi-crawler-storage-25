"""
Monitoring loop with resource-threshold alerting.

Runs the data collection at a configurable heartbeat interval, checks
thresholds, and triggers email alerts when limits are exceeded.

Supports both Accelerator metrics and system-level metrics (CPU, memory, disk).
"""

from __future__ import annotations

import threading
import time
from dataclasses import dataclass, field
from typing import Callable, Dict, List, Optional
import os

from xputop.core.backend import AccelDevice, AccelSnapshot, Backend
from xputop.core.backends import get_backend
from xputop.core.backends.demo import DemoBackend
from xputop.core.sysinfo import (
    MetricHistory,
    NetworkInfo,
    SystemSnapshot,
    collect_system_snapshot,
)


# ---------------------------------------------------------------------------
# Threshold rules
# ---------------------------------------------------------------------------

@dataclass
class ThresholdRule:
    """A single threshold rule for alerting.

    Supports both Accel metrics (temperature, power, utilization_rate,
    mem_usage_percent, …) and system metrics (cpu_percent, mem_percent,
    disk_percent, swap_percent).
    """

    metric: str
    limit: float
    device_id: Optional[int] = None  # None = all devices
    cooldown: float = 300.0
    _last_triggered: float = 0.0

    def check(self, device: AccelDevice, now: float) -> Optional[str]:
        """Return an alert message if an Accel threshold is exceeded."""
        if self.device_id is not None and device.device_id != self.device_id:
            return None

        value_map = {
            "temperature": device.temperature,
            "power": device.power,
            "utilization_rate": device.utilization_rate,
            "mem_usage_percent": device.mem_usage_percent,
            "mem_used": device.mem_used,
        }
        current = value_map.get(self.metric)
        if current is None:
            return None  # not an Accel metric

        if current >= self.limit:
            if now - self._last_triggered >= self.cooldown:
                self._last_triggered = now
                return (
                    f"[ALERT] Device {device.device_id} ({device.name}): "
                    f"{self.metric} = {current:.1f} >= {self.limit:.1f}"
                )
        return None

    def check_system(self, sys_snap: SystemSnapshot, now: float) -> Optional[str]:
        """Return an alert message if a system threshold is exceeded."""
        value_map: Dict[str, float] = {
            "cpu_percent": sys_snap.cpu.total_percent,
            "mem_percent": sys_snap.memory.percent,
            "swap_percent": sys_snap.memory.swap_percent,
        }
        # disk_percent uses first disk by default
        if sys_snap.disks:
            value_map["disk_percent"] = sys_snap.disks[0].percent

        current = value_map.get(self.metric)
        if current is None:
            return None  # not a system metric

        if current >= self.limit:
            if now - self._last_triggered >= self.cooldown:
                self._last_triggered = now
                return (
                    f"[ALERT] System: {self.metric} = {current:.1f}% "
                    f">= {self.limit:.1f}%"
                )
        return None


AlertCallback = Callable[[str], None]


# ---------------------------------------------------------------------------
# Monitor
# ---------------------------------------------------------------------------

class Monitor:
    """
    Background monitor that periodically collects Accel + system snapshots
    and evaluates threshold rules.
    """

    def __init__(
        self,
        interval: float = 2.0,
        demo: bool = False,
        demo_devices: int = 4,
        show_cpu: bool = False,
        show_mem: bool = False,
        show_disk: bool = False,
        disk_paths: Optional[List[str]] = None,
        show_chart: bool = False,
        chart_targets: Optional[List[str]] = None,
        show_plot: bool = False,
        plot_targets: Optional[List[str]] = None,
        merge_plot: bool = False,
        chart_length: int = 120,
        process_rows: int = 3,
        show_detail_all: bool = False,
        config: Optional[Dict] = None,
        force_backend: Optional[str] = None,
        output_path: Optional[str] = None,
        output_format: str = "jsonl",
        theme: str = "color",
    ):
        self.interval = interval
        self.demo = demo
        self.demo_devices = demo_devices
        self.theme = theme

        # Feature flags
        self.show_cpu = show_cpu
        self.show_mem = show_mem
        self.show_disk = show_disk
        self.disk_paths = disk_paths or ["/"]
        self.show_chart = show_chart
        self.chart_targets = chart_targets or ["gpu", "mem"]
        self.show_plot = show_plot
        self.plot_targets = plot_targets or ["gpu", "mem"]
        self.merge_plot = merge_plot
        self.process_rows = process_rows  # >0=fixed, 0=hide, -1=all
        self.show_detail_all = show_detail_all  # network + process tree
        self.kill_value = 0.0
        
        # Initialize Backend
        if self.demo:
            self.backend = DemoBackend(num_devices=self.demo_devices)
        else:
            self.backend = get_backend(config, force_backend)

        # Initialize Recorder
        if output_path:
            from xputop.core.recorder import AsyncRecorder
            self.recorder = AsyncRecorder(output_path, output_format)
            self.recorder.start()
        else:
            self.recorder = None

        self._rules: List[ThresholdRule] = []
        self._callbacks: List[AlertCallback] = []
        self._lock = threading.Lock()
        self._stop_event = threading.Event()
        self._thread: Optional[threading.Thread] = None

        self.latest_snapshot: Optional[AccelSnapshot] = None
        self.latest_sys: Optional[SystemSnapshot] = None
        self.alert_history: List[str] = []

        # History ring buffers for charts
        self.history = MetricHistory(max_points=chart_length)

    # -- Configuration -------------------------------------------------------

    def add_rule(self, rule: ThresholdRule) -> None:
        with self._lock:
            self._rules.append(rule)

    def clear_rules(self) -> None:
        with self._lock:
            self._rules.clear()

    def on_alert(self, callback: AlertCallback) -> None:
        self._callbacks.append(callback)

    # -- Lifecycle -----------------------------------------------------------

    def start(self) -> None:
        if self._thread and self._thread.is_alive():
            return
        self._stop_event.clear()
        self._thread = threading.Thread(target=self._loop, daemon=True)
        self._thread.start()

    def stop(self) -> None:
        self._stop_event.set()
        if self._thread:
            self._thread.join(timeout=self.interval * 2)
        if self.recorder:
            self.recorder.stop()

    def collect_once(self) -> AccelSnapshot:
        """Collect a single snapshot (blocking)."""
        snap = self.backend.collect()
        self.latest_snapshot = snap

        # System metrics (lightweight: cpu_interval=None → non-blocking)
        need_sys = (self.show_cpu or self.show_mem or self.show_disk
                    or self.show_chart or self.show_plot or self.show_detail_all)
        if need_sys:
            self.latest_sys = collect_system_snapshot(
                disk_paths=self.disk_paths,
                cpu_interval=None,
                collect_net=self.show_detail_all,
                collect_procs=self.show_detail_all,
            )

        # Record history for charts and plots
        if self.show_chart or self.show_plot:
            self._record_history(snap)

        if self.recorder:
            self.recorder.record(snap, self.latest_sys)

        self._evaluate(snap)
        return snap

    # -- Internal ------------------------------------------------------------

    def _loop(self) -> None:
        while not self._stop_event.is_set():
            self.collect_once()
            self._stop_event.wait(self.interval)

    def _record_history(self, snap: AccelSnapshot) -> None:
        """Push latest metrics into history ring buffers."""
        if snap.devices:
            for dev in snap.devices:
                self.history.push(f"dev{dev.device_id}_util", dev.utilization_rate)
                self.history.push(f"dev{dev.device_id}_mem", dev.mem_usage_percent)
                self.history.push(f"dev{dev.device_id}_temp", dev.temperature)
                self.history.push(f"dev{dev.device_id}_power", dev.power)

        sys_snap = self.latest_sys
        if sys_snap:
            self.history.push("cpu_total", sys_snap.cpu.total_percent)
            self.history.push("mem_percent", sys_snap.memory.percent)
            if sys_snap.disks:
                self.history.push("disk_percent", sys_snap.disks[0].percent)
            if sys_snap.network and sys_snap.network.error is None:
                # Store rate in MB/s for sparkline
                self.history.push(
                    "net_send", sys_snap.network.bytes_sent_per_sec / (1024 ** 2),
                )
                self.history.push(
                    "net_recv", sys_snap.network.bytes_recv_per_sec / (1024 ** 2),
                )

    def _evaluate(self, snap: AccelSnapshot) -> None:
        now = time.time()
        with self._lock:
            rules = list(self._rules)

        # Check Accel rules
        if snap and not snap.error and snap.devices:
            for dev in snap.devices:
                for rule in rules:
                    msg = rule.check(dev, now)
                    if msg:
                        self._fire_alert(msg)
                        if self.kill_value != 0 and rule.metric in ("mem_usage_percent", "mem_used"):
                            self._execute_auto_kill(dev)

        # Check system rules
        sys_snap = self.latest_sys
        if sys_snap:
            for rule in rules:
                msg = rule.check_system(sys_snap, now)
                if msg:
                    self._fire_alert(msg)
                    if self.kill_value != 0 and rule.metric in ("mem_percent", "swap_percent"):
                        self._execute_system_auto_kill(sys_snap)

    def _fire_alert(self, msg: str) -> None:
        self.alert_history.append(msg)
        for cb in self._callbacks:
            try:
                cb(msg)
            except Exception:
                pass

    def _execute_auto_kill(self, device: AccelDevice) -> None:
        """Execute SIGKILL on top memory consuming accelerator processes."""
        if not device.processes:
            return
            
        procs = sorted(device.processes, key=lambda p: p.mem_used, reverse=True)
        killed_count = 0
        
        if self.kill_value < 0:
            target_n = int(abs(self.kill_value))
            for p in procs:
                if killed_count >= target_n:
                    break
                try:
                    os.kill(p.pid, 9)
                    killed_count += 1
                except Exception:
                    pass
        elif 0 < self.kill_value < 1:
            target_mem = device.mem_total * self.kill_value
            current_mem = device.mem_used
            for p in procs:
                if current_mem <= target_mem:
                    break
                try:
                    os.kill(p.pid, 9)
                    current_mem -= p.mem_used
                except Exception:
                    pass
        else:
            target_pid = int(self.kill_value)
            for p in procs:
                if p.pid == target_pid:
                    try:
                        os.kill(p.pid, 9)
                    except Exception:
                        pass

    def _execute_system_auto_kill(self, sys_snap: SystemSnapshot) -> None:
        """Execute SIGKILL on top memory consuming system processes."""
        if not sys_snap.top_processes:
            return
            
        # Top processes are already sorted by CPU+MEM, but let's re-sort purely by MEM
        procs = sorted(sys_snap.top_processes, key=lambda p: p.memory_mb, reverse=True)
        killed_count = 0
        
        if self.kill_value < 0:
            target_n = int(abs(self.kill_value))
            for p in procs:
                if killed_count >= target_n:
                    break
                try:
                    os.kill(p.pid, 9)
                    killed_count += 1
                except Exception:
                    pass
        elif 0 < self.kill_value < 1:
            target_mem = sys_snap.memory.total_mb * self.kill_value
            current_mem = sys_snap.memory.used_mb
            for p in procs:
                if current_mem <= target_mem:
                    break
                try:
                    os.kill(p.pid, 9)
                    current_mem -= p.memory_mb
                except Exception:
                    pass
        else:
            target_pid = int(self.kill_value)
            for p in procs:
                if p.pid == target_pid:
                    try:
                        os.kill(p.pid, 9)
                    except Exception:
                        pass
