"""
Rich-based Terminal User Interface for xputop.

Renders a live-updating dashboard showing:
  - Per-Device cards with Memory / Utilization bars
  - Optional sparkline history curves (like nvtop)
  - Fixed process row count per card to prevent jitter
  - Optional CPU core utilization panel
  - Optional system memory panel
  - Optional disk usage panel
  - Optional network I/O panel (detail-all)
  - Optional system process tree (detail-all)
  - Alert history
"""

from __future__ import annotations

import os
import time
from typing import List, Optional

from rich.console import Console, Group
from rich.panel import Panel
from rich.live import Live
from rich.table import Table
from rich.text import Text

from xputop import __version__
from xputop.core.monitor import Monitor
from xputop.core.backend import AccelDevice, AccelSnapshot
from xputop.core.sysinfo import SystemSnapshot


# ---------------------------------------------------------------------------
# Theme Palettes
# ---------------------------------------------------------------------------

class ThemePalette:
    def __init__(self, theme: str):
        self.theme = theme
        if theme == "grayscale":
            self.bar_low = "white"
            self.bar_mid = "gray"
            self.bar_high = "bright_black"
            self.border_ok = "white"
            self.border_warn = "gray"
            self.border_err = "bright_black"
            self.header = "bold white"
            self.border_sys = "white"
            self.bg_header = "on black"
            self.text_dim = "bright_black"
        elif theme == "dark":
            self.bar_low = "white"
            self.bar_mid = "bold white"
            self.bar_high = "bright_white"
            self.border_ok = "white"
            self.border_warn = "bold white"
            self.border_err = "bright_white"
            self.header = "bold white"
            self.border_sys = "white"
            self.bg_header = "black"
            self.text_dim = "bright_black"
        elif theme == "light":
            self.bar_low = "black"
            self.bar_mid = "bold black"
            self.bar_high = "bright_black"
            self.border_ok = "black"
            self.border_warn = "bold black"
            self.border_err = "bright_black"
            self.header = "bold black"
            self.border_sys = "black"
            self.bg_header = "white"
            self.text_dim = "black"
        else:
            # Color
            self.bar_low = "green"
            self.bar_mid = "yellow"
            self.bar_high = "red"
            self.border_ok = "green"
            self.border_warn = "yellow"
            self.border_err = "red"
            self.header = "bold cyan"
            self.border_sys = "blue"
            self.bg_header = "on grey11"
            self.text_dim = "dim"


# ---------------------------------------------------------------------------
# Unicode sparkline characters (8 levels)
# ---------------------------------------------------------------------------

_SPARK_CHARS = " ▁▂▃▄▅▆▇█"


def _sparkline(values: List[float], width: int = 50, vmin: float = 0.0,
               vmax: float = 100.0, label: str = "", theme: str = "color") -> Text:
    """Render a sparkline string from a list of values, with optional trailing label."""
    if not values:
        return Text("─" * width, style="dim")

    # Take the last `width` points
    data = values[-width:]
    span = vmax - vmin if vmax > vmin else 1.0
    n = len(_SPARK_CHARS) - 1
    chars: List[str] = []
    colors: List[str] = []
    for v in data:
        idx = int(max(0, min(n, (v - vmin) / span * n)))
        chars.append(_SPARK_CHARS[idx])
        colors.append(_usage_color(v, theme))

    # Pad left if shorter than width
    pad = width - len(chars)
    txt = Text("─" * pad, style="dim")
    for ch, col in zip(chars, colors):
        txt.append(ch, style=col)

    # Append current value label
    if label:
        txt.append(f" {label}", style="bold")
    elif data:
        txt.append(f" {data[-1]:.1f}", style="bold")

    return txt


# ---------------------------------------------------------------------------
# Colour helpers
# ---------------------------------------------------------------------------

def _usage_color(pct: float, theme: str) -> str:
    pal = ThemePalette(theme)
    if pct < 30:
        return pal.bar_low
    if pct < 70:
        return pal.bar_mid
    return pal.bar_high


def _health_color(health: str, theme: str) -> str:
    pal = ThemePalette(theme)
    h = health.upper()
    if h == "OK":
        return pal.border_ok
    if h == "WARNING":
        return pal.border_warn
    return pal.border_err


def _temp_color(temp: float, theme: str) -> str:
    pal = ThemePalette(theme)
    if temp < 50:
        return pal.bar_low
    if temp < 75:
        return pal.bar_mid
    return pal.bar_high


# ---------------------------------------------------------------------------
# Bar rendering
# ---------------------------------------------------------------------------

def _bar_text(used: float, total: float, theme: str, width: int = 30) -> Text:
    """Render a text-based usage bar like [████████░░░░░░░ 45%]."""
    pal = ThemePalette(theme)
    if total <= 0:
        pct = 0.0
    else:
        pct = min(used / total * 100, 100.0)

    filled = int(pct / 100 * width)
    empty = width - filled
    color = _usage_color(pct, theme)

    bar = Text("[")
    bar.append("█" * filled, style=color)
    bar.append("░" * empty, style=pal.text_dim)
    bar.append(f"] {pct:5.1f}%")
    return bar


# ---------------------------------------------------------------------------
# Device card
# ---------------------------------------------------------------------------

def _render_device(dev: AccelDevice, monitor: Monitor) -> Panel:
    """Render a single accelerator device card."""
    theme = monitor.theme
    pal = ThemePalette(theme)

    t = Table.grid(padding=(0, 2))
    t.add_column(justify="right", style=pal.header, min_width=14)
    t.add_column(min_width=40)

    health_style = _health_color(dev.health, theme)
    t.add_row(
        "Name",
        Text.assemble(
            (dev.name, pal.header.replace("bold ", "")),
            "  Health: ",
            (dev.health, health_style),
        ),
    )

    t.add_row(
        "Temp / Power",
        Text.assemble(
            (f"{dev.temperature:.0f}°C", _temp_color(dev.temperature, theme)),
            "  /  ",
            f"{dev.power:.1f} W",
        ),
    )

    # Utilization bar
    util_bar = _bar_text(dev.utilization_rate, 100.0, theme)
    t.add_row("Utilization", util_bar)

    # Sparkline for Util if chart mode is on
    if monitor.show_chart and ("gpu" in monitor.chart_targets):
        data = monitor.history.get(f"dev{dev.device_id}_util")
        t.add_row("", _sparkline(data, width=50, label=f"{dev.utilization_rate:.1f}%", theme=theme))

    # Memory usage bar
    mem_bar = _bar_text(dev.mem_used, dev.mem_total, theme)
    mem_detail = Text(f"  {dev.mem_used:.0f} / {dev.mem_total:.0f} MiB")
    mem_line = Text.assemble(mem_bar, mem_detail)
    t.add_row("Memory", mem_line)

    if monitor.show_chart and ("mem" in monitor.chart_targets):
        data = monitor.history.get(f"dev{dev.device_id}_mem")
        t.add_row("", _sparkline(data, width=50, label=f"{dev.mem_usage_percent:.1f}%", theme=theme))

    # Processes — fixed row count to prevent jitter
    process_rows = monitor.process_rows

    if process_rows == 0:
        # Don't show processes at all
        pass
    else:
        pt = Table(box=None, padding=(0, 1), show_header=True, header_style=f"bold {pal.text_dim}")
        pt.add_column("PID", justify="right", width=8)
        pt.add_column("Process", min_width=18)
        pt.add_column("Mem(MiB)", justify="right", width=10)

        procs = dev.processes

        if process_rows == -1:
            # Show all processes (variable height)
            display_procs = procs
            total_rows = len(procs) if procs else 1
        else:
            # Fixed N rows; truncate or pad
            display_procs = procs[:process_rows]
            total_rows = process_rows

        for p in display_procs:
            pt.add_row(
                str(p.pid),
                p.process_name,
                f"{p.mem_usage:.0f}" if p.mem_usage > 0 else "-",
            )

        # Pad with empty rows to maintain fixed height
        if process_rows > 0:
            for _ in range(process_rows - len(display_procs)):
                pt.add_row("", "", "")

        if len(display_procs) == 0 and process_rows == -1:
            t.add_row("Processes", Text("No running processes", style=pal.text_dim))
        else:
            t.add_row("Processes", pt)

    border_color = pal.border_ok if dev.health.upper() == "OK" else pal.border_err
    return Panel(
        t,
        title=f"[{pal.header}]Device {dev.device_id}[/]",
        border_style=border_color,
        padding=(0, 1),
    )


# ---------------------------------------------------------------------------
# CPU panel
# ---------------------------------------------------------------------------

def _render_cpu(monitor: Monitor) -> Panel:
    theme = monitor.theme
    pal = ThemePalette(theme)
    
    sys_snap = monitor.latest_sys
    if not sys_snap:
        return Panel(Text("Waiting…", style=pal.text_dim), title=f"[{pal.header}]CPU[/]")

    cpu = sys_snap.cpu
    t = Table.grid(padding=(0, 2))
    t.add_column(justify="right", style=pal.header, min_width=12)
    t.add_column(min_width=55)

    t.add_row(
        "Total",
        Text.assemble(
            _bar_text(cpu.total_percent, 100.0, theme),
            f"  ({cpu.core_count} cores)",
        ),
    )

    if monitor.show_chart and ("cpu" in monitor.chart_targets):
        data = monitor.history.get("cpu_total")
        t.add_row("", _sparkline(data, width=50, label=f"{cpu.total_percent:.1f}%", theme=theme))

    t.add_row(
        "Load Avg",
        Text(f"{cpu.load_avg[0]:.2f}  {cpu.load_avg[1]:.2f}  {cpu.load_avg[2]:.2f}"),
    )

    # Per-core mini bars (compact: 4 per row)
    cores = cpu.per_core
    if cores:
        row_parts: List[Text] = []
        for i, pct in enumerate(cores):
            color = _usage_color(pct, theme)
            bar_w = 10
            filled = int(pct / 100 * bar_w)
            empty = bar_w - filled
            part = Text(f"C{i:<2d}[")
            part.append("█" * filled, style=color)
            part.append("░" * empty, style=pal.text_dim)
            part.append(f"]{pct:5.1f}% ")
            row_parts.append(part)

            if len(row_parts) == 4 or i == len(cores) - 1:
                combined = Text()
                for rp in row_parts:
                    combined.append_text(rp)
                t.add_row("" if i >= 4 else "Per Core", combined)
                row_parts = []

    return Panel(t, title=f"[{pal.header}]CPU[/]", border_style=pal.border_sys)


# ---------------------------------------------------------------------------
# Memory panel
# ---------------------------------------------------------------------------

def _render_memory(monitor: Monitor) -> Panel:
    theme = monitor.theme
    pal = ThemePalette(theme)

    sys_snap = monitor.latest_sys
    if not sys_snap:
        return Panel(Text("Waiting…", style=pal.text_dim), title=f"[{pal.header}]Memory[/]")

    mem = sys_snap.memory
    t = Table.grid(padding=(0, 2))
    t.add_column(justify="right", style=pal.header, min_width=12)
    t.add_column(min_width=55)

    ram_bar = _bar_text(mem.used_mb, mem.total_mb, theme)
    ram_detail = Text(f"  {mem.used_mb:.0f} / {mem.total_mb:.0f} MiB")
    t.add_row("RAM", Text.assemble(ram_bar, ram_detail))

    if monitor.show_chart:
        data = monitor.history.get("mem_percent")
        t.add_row("", _sparkline(data, width=50, label=f"{mem.percent:.1f}%", theme=theme))

    if mem.swap_total_mb > 0:
        swap_bar = _bar_text(mem.swap_used_mb, mem.swap_total_mb, theme)
        swap_detail = Text(f"  {mem.swap_used_mb:.0f} / {mem.swap_total_mb:.0f} MiB")
        t.add_row("Swap", Text.assemble(swap_bar, swap_detail))

    t.add_row("Available", Text(f"{mem.available_mb:.0f} MiB"))

    return Panel(t, title=f"[{pal.header}]Memory[/]", border_style=pal.border_sys)


# ---------------------------------------------------------------------------
# Disk panel
# ---------------------------------------------------------------------------

def _render_disk(monitor: Monitor) -> Panel:
    theme = monitor.theme
    pal = ThemePalette(theme)

    sys_snap = monitor.latest_sys
    if not sys_snap or not sys_snap.disks:
        return Panel(Text("Waiting…", style=pal.text_dim), title=f"[{pal.header}]Disk[/]")

    t = Table.grid(padding=(0, 2))
    t.add_column(justify="right", style=pal.header, min_width=12)
    t.add_column(min_width=55)

    for disk in sys_snap.disks:
        if disk.percent < 0:
            t.add_row(disk.mount_point, Text("N/A", style=pal.text_dim))
            continue
        bar = _bar_text(disk.used_gb, disk.total_gb, theme)
        detail = Text(f"  {disk.used_gb:.1f} / {disk.total_gb:.1f} GiB  free {disk.free_gb:.1f} GiB")
        t.add_row(disk.mount_point, Text.assemble(bar, detail))

    if monitor.show_chart:
        data = monitor.history.get("disk_percent")
        if data:
            t.add_row("", _sparkline(data, width=50, theme=theme))

    return Panel(t, title=f"[{pal.header}]Disk[/]", border_style=pal.border_sys)


# ---------------------------------------------------------------------------
# Network panel (detail-all)
# ---------------------------------------------------------------------------

def _render_network(monitor: Monitor) -> Panel:
    theme = monitor.theme
    pal = ThemePalette(theme)

    sys_snap = monitor.latest_sys
    if not sys_snap or not sys_snap.network:
        return Panel(Text("Waiting…", style=pal.text_dim), title=f"[{pal.header}]Network[/]")

    net = sys_snap.network
    t = Table.grid(padding=(0, 2))
    t.add_column(justify="right", style=pal.header, min_width=12)
    t.add_column(min_width=55)

    if net.error:
        t.add_row("Status", Text(net.error, style=pal.border_err))
    else:
        # Upload / Download rates
        t.add_row(
            "↑ Send",
            Text.assemble(
                (net.send_rate, pal.border_ok),
                f"  (Total: {net.total_sent_gb:.2f} GiB)",
            ),
        )
        t.add_row(
            "↓ Recv",
            Text.assemble(
                (net.recv_rate, pal.header.replace("bold ", "")),
                f"  (Total: {net.total_recv_gb:.2f} GiB)",
            ),
        )

        # Sparkline for network rates
        if monitor.show_chart:
            send_data = monitor.history.get("net_send")
            recv_data = monitor.history.get("net_recv")
            if send_data:
                # Auto-scale: vmax = max of historical data or 10 MB/s minimum
                vmax_s = max(max(send_data) * 1.2, 10.0)
                t.add_row("↑ History",
                          _sparkline(send_data, width=50, vmin=0, vmax=vmax_s,
                                     label=net.send_rate, theme=theme))
            if recv_data:
                vmax_r = max(max(recv_data) * 1.2, 10.0)
                t.add_row("↓ History",
                          _sparkline(recv_data, width=50, vmin=0, vmax=vmax_r,
                                     label=net.recv_rate, theme=theme))

    return Panel(t, title=f"[{pal.header}]Network[/]", border_style=pal.border_sys)


# ---------------------------------------------------------------------------
# Process tree panel (detail-all)
# ---------------------------------------------------------------------------

def _render_process_tree(monitor: Monitor) -> Panel:
    theme = monitor.theme
    pal = ThemePalette(theme)
    
    sys_snap = monitor.latest_sys
    if not sys_snap or not sys_snap.top_processes:
        return Panel(Text("Waiting…", style=pal.text_dim),
                     title=f"[{pal.header}]Top System Processes[/]")

    pt = Table(
        show_lines=False,
        padding=(0, 1),
        header_style=f"bold {pal.text_dim}",
        box=None,
    )
    pt.add_column("PID", justify="right", width=8)
    pt.add_column("User", width=10)
    pt.add_column("CPU%", justify="right", width=7)
    pt.add_column("MEM%", justify="right", width=7)
    pt.add_column("MEM(MiB)", justify="right", width=10)
    pt.add_column("Status", width=10)
    pt.add_column("Command", no_wrap=True)

    for proc in sys_snap.top_processes[:15]:
        cpu_color = _usage_color(proc.cpu_percent, theme)
        mem_color = _usage_color(proc.memory_percent * 10, theme)  # scale for color
        pt.add_row(
            str(proc.pid),
            proc.username,
            Text(f"{proc.cpu_percent:.1f}", style=cpu_color),
            Text(f"{proc.memory_percent:.1f}", style=mem_color),
            f"{proc.memory_mb:.0f}",
            proc.status,
            proc.cmdline[:60] if proc.cmdline else proc.name,
        )

    return Panel(pt, title=f"[{pal.header}]Top System Processes[/]", border_style=pal.border_sys)


# ---------------------------------------------------------------------------
# Header
# ---------------------------------------------------------------------------

def _render_header(snap: Optional[AccelSnapshot], monitor: Monitor) -> Panel:
    theme = monitor.theme
    pal = ThemePalette(theme)

    ts = time.strftime("%Y-%m-%d %H:%M:%S")
    driver = snap.driver_version if snap and snap.driver_version else "N/A"
    n_devs = len(snap.devices) if snap and snap.devices else 0
    backend_name = monitor.backend.name if hasattr(monitor, "backend") and monitor.backend else "Unknown"

    title = Text.assemble(
        ("  xputop ", pal.header),
        (f"v{__version__}", pal.text_dim),
        "  |  ",
        (f"Backend: {backend_name}", ""),
        "  |  ",
        (f"Driver/Ver: {driver}", ""),
        "  |  ",
        (f"Devices: {n_devs}", pal.header.replace("bold ", "")),
        "  |  ",
        (ts, pal.text_dim),
        "  ",
    )
    
    if not pal.bg_header:
        # e.g., dark/light where we're ok with default text colors
        panel_style = "none"
    else:
        panel_style = pal.bg_header

    return Panel(title, style=panel_style, border_style=pal.header.replace("bold ", ""), height=3)


# ---------------------------------------------------------------------------
# Alerts
# ---------------------------------------------------------------------------

def _render_alerts(monitor: Monitor, max_lines: int = 5) -> Panel:
    pal = ThemePalette(monitor.theme)
    recent = monitor.alert_history[-max_lines:]
    if not recent:
        body = Text("No alerts", style=pal.text_dim)
    else:
        lines = []
        for a in reversed(recent):
            lines.append(Text(a, style=pal.border_err))
        body = Group(*lines)
    return Panel(body, title=f"[{pal.border_warn}]Alerts[/]", height=max_lines + 2, border_style=pal.border_warn)


# ---------------------------------------------------------------------------
# 2D Plot
# ---------------------------------------------------------------------------

def _calc_cols(num_items: int, term_width: int, min_width: int) -> int:
    max_cols = max(1, term_width // min_width)
    cols = min(num_items, max_cols)
    if num_items == 4 and cols == 3:
        cols = 2
    return cols

def _render_2d_plots(monitor: Monitor) -> RenderableType:
    snap = monitor.latest_snapshot
    if not snap or not snap.devices:
        return Text("")
        
    from rich.console import Console
    cons = Console()
    term_width = cons.size.width
    term_height = cons.size.height

    from xputop.ui.plot import render_2d_plot
    colors = ["cyan", "magenta", "yellow", "green", "blue", "red"]
    
    targets = monitor.plot_targets
    show_gpu = "gpu" in targets
    show_mem = "mem" in targets
    show_cpu = "cpu" in targets

    if monitor.merge_plot:
        all_series = []
        c = []
        l = []
        m = []
        
        # Merge plot uses unique color per device, unique marker per metric type
        device_colors = ["cyan", "magenta", "green", "blue", "red", "white"]
        
        if show_cpu:
            all_series.append(monitor.history.get("cpu_total"))
            c.append("yellow")
            l.append("CPU%")
            m.append("braille")
            
        for i, d in enumerate(snap.devices):
            d_color = device_colors[i % len(device_colors)]
            
            if show_gpu:
                all_series.append(monitor.history.get(f"dev{d.device_id}_util"))
                c.append(d_color)
                l.append(f"GPU{d.device_id}%")
                m.append("braille")
            if show_mem:
                all_series.append(monitor.history.get(f"dev{d.device_id}_mem"))
                c.append(d_color)
                l.append(f"MEM{d.device_id}%")
                m.append("hd")
            
        # Estimate safe plot height to avoid truncation
        plot_h = max(7, min(14, term_height // 3))
        
        # Limit labels logic loosely
        p_table = render_2d_plot(
            all_series, 
            c, l[:12], 
            markers=m,
            width_chars=max(50, term_width - 2), 
            height_chars=plot_h, 
            interval=monitor.interval,
            chart_length=monitor.history.max_points,
            theme=monitor.theme
        )
        return p_table
    else:
        num_devs = len(snap.devices)
        cols = _calc_cols(num_devs, term_width, min_width=55)
        
        # padding 3 between cols -> (cols - 1) * 3 spaces
        plot_w = max(40, (term_width - ((cols - 1) * 3) - 2) // cols)
        
        # Estimate height based on rows
        rows = num_devs // cols + (1 if num_devs % cols else 0)
        # term_height - (device_rows * 10) - (summary 10)
        avail_h = term_height - (rows * 11) - 12
        plot_h = max(7, min(14, avail_h))

        if show_cpu and not show_gpu and not show_mem:
            # ONLY cpu is asked
            s_cpu = monitor.history.get("cpu_total")
            p_table = render_2d_plot(
                [s_cpu], ["yellow"], ["CPU%"], ["braille"], 
                width_chars=max(40, term_width - 4), 
                height_chars=max(7, min(14, term_height // 3)), 
                interval=monitor.interval,
                chart_length=monitor.history.max_points,
                theme=monitor.theme
            )
            return p_table

        plots = []
        for d in snap.devices:
            s_list = []
            c_list = []
            l_list = []
            m_list = []
            if show_cpu:
                s_list.append(monitor.history.get("cpu_total"))
                c_list.append("yellow")
                l_list.append("CPU%")
                m_list.append("braille")
            if show_gpu:
                s_list.append(monitor.history.get(f"dev{d.device_id}_util"))
                c_list.append("cyan")
                l_list.append(f"GPU{d.device_id}%")
                m_list.append("braille")
            if show_mem:
                s_list.append(monitor.history.get(f"dev{d.device_id}_mem"))
                c_list.append("magenta")
                l_list.append(f"MEM{d.device_id}%")
                m_list.append("hd")
                
            p_table = render_2d_plot(
                s_list, 
                c_list, 
                l_list, 
                markers=m_list,
                width_chars=plot_w, 
                height_chars=plot_h, 
                interval=monitor.interval,
                chart_length=monitor.history.max_points,
                theme=monitor.theme
            )
            plots.append(p_table)
            
        grid = Table.grid(padding=(1, 3))
        for _ in range(cols):
            grid.add_column()
            
        for i in range(0, len(plots), cols):
            row = plots[i:i+cols]
            while len(row) < cols:
                row.append("")
            grid.add_row(*row)
            
        return grid


# ---------------------------------------------------------------------------
# Summary table
# ---------------------------------------------------------------------------

def _render_summary(monitor: Monitor, devices: List[AccelDevice]) -> Table:
    pal = ThemePalette(monitor.theme)
    summary = Table(
        title=f"[{pal.header}]Summary[/]",
        show_lines=False,
        padding=(0, 1),
        header_style=pal.header,
    )
    summary.add_column("Dev", justify="center", width=5)
    summary.add_column("Name", min_width=14)
    summary.add_column("Temp(°C)", justify="right", width=9)
    summary.add_column("Power(W)", justify="right", width=9)
    summary.add_column("Util%", justify="right", width=8)
    summary.add_column("Mem Used", justify="right", width=12)
    summary.add_column("Mem Total", justify="right", width=12)
    summary.add_column("Mem%", justify="right", width=8)
    summary.add_column("Health", justify="center", width=8)
    summary.add_column("#Proc", justify="center", width=6)

    for d in devices:
        summary.add_row(
            str(d.device_id),
            d.name,
            f"{d.temperature:.0f}",
            f"{d.power:.1f}",
            f"{d.utilization_rate:.1f}",
            f"{d.mem_used:.0f}",
            f"{d.mem_total:.0f}",
            f"[{_usage_color(d.mem_usage_percent, monitor.theme)}]{d.mem_usage_percent:.1f}[/]",
            f"[{_health_color(d.health, monitor.theme)}]{d.health}[/]",
            str(len(d.processes)),
        )
    return summary


# ---------------------------------------------------------------------------
# Main dashboard builder
# ---------------------------------------------------------------------------

def _build_dashboard(monitor: Monitor) -> Group:
    """Build the full dashboard renderable."""
    pal = ThemePalette(monitor.theme)
    snap = monitor.latest_snapshot
    parts: list = [_render_header(snap, monitor)]
    
    if monitor.show_plot and snap and snap.devices:
        parts.append(_render_2d_plots(monitor))

    if snap and snap.error:
        parts.append(Panel(
            Text(snap.error, style=pal.border_err),
            title=f"[{pal.border_err}]Error[/]",
            border_style=pal.border_err,
        ))
    elif snap and snap.devices:
        devices = snap.devices
        from rich.console import Console
        term_width = Console().size.width
        
        cols = _calc_cols(len(devices), term_width, min_width=60)
        
        # Determine layout
        grid = Table.grid(padding=(0, 1))
        for _ in range(cols):
            grid.add_column(ratio=1)
        
        for i in range(0, len(devices), cols):
            row = []
            for j in range(cols):
                if i + j < len(devices):
                    row.append(_render_device(devices[i + j], monitor))
                else:
                    row.append("")
            grid.add_row(*row)
        
        parts.append(grid)
        parts.append(_render_summary(monitor, devices))
        
    elif snap is not None:
        # snap exists but no devices and no error
        parts.append(Panel(
            Text.assemble(
                ("No accelerator devices detected.\n", pal.border_warn),
                ("The backend returned data but parsing yielded 0 devices.\n", ""),
                ("Check the underlying tool (e.g., npu-smi, nvidia-smi) manually.\n", pal.text_dim),
                ("Use  ", pal.text_dim),
                ("--demo", "bold"),
                ("  to test without hardware.", pal.text_dim),
            ),
            title=f"[{pal.border_warn}]No Devices[/]",
            border_style=pal.border_warn,
        ))
    else:
        parts.append(Panel(Text("Waiting for data…", style=pal.text_dim), title=f"[{pal.header}]Status[/]", border_style=pal.text_dim))

    # System panels — arranged in a 2-column grid when multiple are on
    sys_panels: list = []
    if monitor.show_cpu:
        sys_panels.append(_render_cpu(monitor))
    if monitor.show_mem:
        sys_panels.append(_render_memory(monitor))
    if monitor.show_disk:
        sys_panels.append(_render_disk(monitor))

    # detail-all panels
    if monitor.show_detail_all:
        sys_panels.append(_render_network(monitor))
        sys_panels.append(_render_process_tree(monitor))

    if sys_panels:
        if len(sys_panels) == 1:
            parts.append(sys_panels[0])
        else:
            grid = Table.grid(padding=(0, 1))
            grid.add_column(ratio=1)
            grid.add_column(ratio=1)
            for i in range(0, len(sys_panels), 2):
                left = sys_panels[i]
                right = sys_panels[i + 1] if i + 1 < len(sys_panels) else ""
                grid.add_row(left, right)
            parts.append(grid)

    # Alerts
    if monitor.alert_history:
        parts.append(_render_alerts(monitor))

    # Footer
    parts.append(Text(
        "  Ctrl+C quit  |  -d detail  -a detail-all  -C chart  -p N processes  |  xputop",
        style=pal.text_dim,
    ))

    return Group(*parts)


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def run_tui(monitor: Monitor, refresh_rate: Optional[float] = None) -> None:
    """
    Run the live TUI dashboard.

    Args:
        monitor: A ``Monitor`` instance (already started or will be started).
        refresh_rate: Override display refresh in Hz.
    """
    console = Console()

    if refresh_rate is None:
        refresh_rate = max(1.0, 1.0 / monitor.interval) if monitor.interval > 0 else 2.0

    monitor.start()

    # Wait for first snapshot
    for _ in range(20):
        if monitor.latest_snapshot is not None:
            break
        time.sleep(0.1)

    try:
        with Live(
            _build_dashboard(monitor),
            console=console,
            refresh_per_second=refresh_rate,
            screen=True,
        ) as live:
            while True:
                live.update(_build_dashboard(monitor))
                time.sleep(monitor.interval)
    except KeyboardInterrupt:
        pass
    finally:
        monitor.stop()
        console.print("\n[bold cyan]xputop[/bold cyan] stopped.")
