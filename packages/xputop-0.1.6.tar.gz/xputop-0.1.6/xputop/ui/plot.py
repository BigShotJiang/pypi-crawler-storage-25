from __future__ import annotations

import math
import traceback
from typing import List, Optional

from rich.text import Text
from rich.panel import Panel
from rich.console import RenderableType

def render_2d_plot(
    series: List[List[float]], 
    colors: List[str], 
    labels: List[str], 
    markers: Optional[List[str]] = None,
    width_chars: int = 100, 
    height_chars: int = 10,
    interval: float = 2.0,
    chart_length: int = 120,
    theme: str = "color"
) -> RenderableType:
    """
    Render a 2D line graph with axes.
    Uses plotext for beautiful dynamic scaling ANSI traces.
    """
    try:
        import plotext as plt
    except ImportError:
        return Panel(
            Text.assemble(
                ("Missing required package for 2D plots!\n\n", "bold red"),
                ("Please run:\n", "white"),
                ("pip install 'xputop[plot]'\n", "bold cyan"),
                ("or\n", "white"),
                ("pip install plotext>=5.0.0", "bold cyan")
            ),
            title="[yellow]Dependency Missing[/yellow]",
        )

    try:
        plt.clf()
        plt.plotsize(width_chars, height_chars)
        
        if theme == "dark":
            plt.theme("dark")
        elif theme == "light":
            plt.theme("light")
        else:
            plt.theme("clear")
            
        plt.xlim(-chart_length * interval, 0)
        
        max_len = max((len(s) for s in series if s), default=0)
        
        if max_len == 0:
            plt.plot([0], [0], color="black")
        else:
            for idx, s in enumerate(series):
                if not s:
                    continue
                
                # We interpret history: 0 is the oldest (far left), max_len is newest (far right)
                # s contains up to `chart_length` items (e.g. 120).
                # Rightmost is current time 0s. 
                # Thus old points are -N seconds.
                
                # To graph it smoothly, time goes from - (len-1)*interval to 0.
                x = [ -(len(s) - 1 - i) * interval for i in range(len(s)) ]
                y = s
                
                c = colors[idx] if idx < len(colors) else 'white'
                m = markers[idx] if markers and idx < len(markers) else 'braille'
                
                if theme == "grayscale":
                    c = ["white", "gray", "iron", "cloud"][idx % 4]
                elif theme in ("dark", "light"):
                    # Let plotext automatically handle coloring in monochrome modes
                    c = None
                    
                plt.plot(x, y, color=c, marker=m, label=labels[idx])
                
        plt.ylim(0, 100)
        
        ans = plt.build()
        return Text.from_ansi(ans)
    except Exception:
        return Panel(f"Plot Error:\n{traceback.format_exc()}", border_style="red")
