"""
Offline visualization generator for xputop logs.

Reads a JSONL or CSV log file and generates a standalone, interactive HTML 
dashboard using Chart.js to visualize historical metrics.
"""

import csv
import json
from pathlib import Path
from typing import Any, Dict, List


def _is_jsonl(filepath: Path) -> bool:
    if filepath.suffix == ".jsonl":
        return True
    try:
        with open(filepath, "r", encoding="utf-8") as f:
            first_line = f.readline().strip()
            if first_line.startswith("{") and first_line.endswith("}"):
                return True
    except Exception:
        pass
    return False


def _read_jsonl(filepath: Path) -> List[Dict[str, Any]]:
    records = []
    with open(filepath, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            records.append(json.loads(line))
    return records


def _read_csv(filepath: Path) -> List[Dict[str, Any]]:
    records = []
    with open(filepath, "r", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            # We must reconstruct a snapshot dict format from flat CSV.
            # But the HTML generator only needs flattened time-series arrays anyway.
            # Wait, the generator expects structured dict if it's JSONL.
            # Let's map CSV rows to a dummy JSONL structure.
            rec: Dict[str, Any] = {
                "timestamp": float(row.get("timestamp", 0.0)),
                "devices": []
            }
            
            # Find distinct device IDs
            dev_ids = set()
            for k in row.keys():
                if k.startswith("dev_"):
                    parts = k.split("_", 2)
                    if len(parts) >= 2 and parts[1].isdigit():
                        dev_ids.add(int(parts[1]))
            
            for dev_id in sorted(list(dev_ids)):
                prefix = f"dev_{dev_id}_"
                dev = {
                    "device_id": dev_id,
                    "name": row.get(prefix + "name", ""),
                    "temperature": float(row.get(prefix + "temp", 0)),
                    "power": float(row.get(prefix + "power", 0)),
                    "utilization_rate": float(row.get(prefix + "util_percent", 0)),
                    "mem_used": float(row.get(prefix + "mem_used_mb", 0)),
                    "mem_total": float(row.get(prefix + "mem_total_mb", 0)),
                    "mem_usage_percent": float(row.get(prefix + "mem_percent", 0)),
                }
                rec["devices"].append(dev)
                
            records.append(rec)
    return records


def create_viewer_html(log_path: str, out_path: str) -> None:
    path = Path(log_path)
    if _is_jsonl(path):
        data = _read_jsonl(path)
    else:
        data = _read_csv(path)
        
    if not data:
        print("Log file is empty or invalid.")
        return

    # Extract time series
    labels = []
    datasets_util = {}
    datasets_mem = {}
    datasets_temp = {}
    
    for r in data:
        labels.append(r["timestamp"])
        for dev in r.get("devices", []):
            did = dev["device_id"]
            if did not in datasets_util:
                datasets_util[did] = []
                datasets_mem[did] = []
                datasets_temp[did] = []
            
            datasets_util[did].append(dev.get("utilization_rate", 0))
            datasets_mem[did].append(dev.get("mem_usage_percent", 0))
            datasets_temp[did].append(dev.get("temperature", 0))

    # Format for Chart.js
    def make_datasets(datadict, label_suffix, border_dash=None):
        colors = [
            "rgba(75, 192, 192, 1)",
            "rgba(255, 99, 132, 1)",
            "rgba(255, 206, 86, 1)",
            "rgba(54, 162, 235, 1)",
            "rgba(153, 102, 255, 1)",
            "rgba(255, 159, 64, 1)"
        ]
        out = []
        for i, (did, vals) in enumerate(sorted(datadict.items())):
            ds = {
                "label": f"Device {did} {label_suffix}",
                "data": vals,
                "borderColor": colors[i % len(colors)],
                "backgroundColor": "transparent",
                "pointRadius": 0,
                "borderWidth": 2,
                "tension": 0.1
            }
            if border_dash:
                ds["borderDash"] = border_dash
            out.append(ds)
        return out

    chart_data = {
        "labels": labels, # JS needs real dates, we'll map them in HTML
        "datasets": (
            make_datasets(datasets_util, "Util %") +
            make_datasets(datasets_mem, "Mem %", border_dash=[5, 5]) +
            make_datasets(datasets_temp, "Temp °C", border_dash=[2, 2])
        )
    }

    html = f"""<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>xputop Offline Viewer</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        body {{ font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Arial, sans-serif; margin: 2rem; background: #f8f9fa; }}
        h1 {{ color: #333; }}
        .chart-container {{ position: relative; height: 60vh; width: 100%; max-width: 1200px; margin: 0 auto; background: white; padding: 1rem; border-radius: 8px; box-shadow: 0 4px 6px rgba(0,0,0,0.1); }}
    </style>
</head>
<body>
    <h1>xputop - Historical Metrics</h1>
    <p>File loaded: <code>{path.name}</code> ({len(data)} records)</p>
    
    <div class="chart-container">
        <canvas id="metricsChart"></canvas>
    </div>

    <script>
        const rawData = {json.dumps(chart_data)};
        
        // Convert unix timestamps to JS Date strings
        rawData.labels = rawData.labels.map(ts => {{
            const d = new Date(ts * 1000);
            return d.toLocaleTimeString([], {{hour12: false}});
        }});

        const ctx = document.getElementById('metricsChart').getContext('2d');
        new Chart(ctx, {{
            type: 'line',
            data: rawData,
            options: {{
                responsive: true,
                maintainAspectRatio: false,
                interaction: {{
                    mode: 'index',
                    intersect: false,
                }},
                plugins: {{
                    tooltip: {{
                        callbacks: {{
                            label: function(context) {{
                                return context.dataset.label + ': ' + context.parsed.y;
                            }}
                        }}
                    }}
                }},
                scales: {{
                    y: {{
                        beginAtZero: true,
                        max: 100,
                        title: {{ display: true, text: 'Percentage / Temperature' }}
                    }},
                    x: {{
                        title: {{ display: true, text: 'Time' }}
                    }}
                }}
            }}
        }});
    </script>
</body>
</html>
"""

    with open(out_path, "w", encoding="utf-8") as f:
        f.write(html)
