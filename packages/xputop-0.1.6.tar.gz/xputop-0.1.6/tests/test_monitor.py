"""Tests for the Monitor and ThresholdRule classes."""

import time
from xputop.core.monitor import Monitor, ThresholdRule
from xputop.core.backend import AccelDevice


class TestThresholdRule:
    def test_trigger_when_exceeded(self):
        rule = ThresholdRule(metric="temperature", limit=80.0, cooldown=0)
        dev = AccelDevice(device_id=0, name="sim", temperature=85.0, power=0, utilization_rate=0, mem_used=0, mem_total=0, health="OK")
        msg = rule.check(dev, time.time())
        assert msg is not None
        assert "temperature" in msg

    def test_no_trigger_below_limit(self):
        rule = ThresholdRule(metric="temperature", limit=80.0, cooldown=0)
        dev = AccelDevice(device_id=0, name="sim", temperature=60.0, power=0, utilization_rate=0, mem_used=0, mem_total=0, health="OK")
        msg = rule.check(dev, time.time())
        assert msg is None

    def test_device_filter(self):
        rule = ThresholdRule(metric="temperature", limit=80.0, device_id=1, cooldown=0)
        dev0 = AccelDevice(device_id=0, name="sim", temperature=90.0, power=0, utilization_rate=0, mem_used=0, mem_total=0, health="OK")
        dev1 = AccelDevice(device_id=1, name="sim", temperature=90.0, power=0, utilization_rate=0, mem_used=0, mem_total=0, health="OK")
        assert rule.check(dev0, time.time()) is None
        assert rule.check(dev1, time.time()) is not None

    def test_cooldown(self):
        rule = ThresholdRule(metric="temperature", limit=80.0, cooldown=60)
        dev = AccelDevice(device_id=0, name="sim", temperature=90.0, power=0, utilization_rate=0, mem_used=0, mem_total=0, health="OK")
        now = time.time()
        msg1 = rule.check(dev, now)
        assert msg1 is not None
        msg2 = rule.check(dev, now + 10)  # within cooldown
        assert msg2 is None
        msg3 = rule.check(dev, now + 61)  # past cooldown
        assert msg3 is not None


class TestMonitor:
    def test_demo_collect_once(self):
        mon = Monitor(interval=1, demo=True, demo_devices=2)
        snap = mon.collect_once()
        assert snap is not None
        assert len(snap.devices) == 2

    def test_alert_callback(self):
        alerts = []
        mon = Monitor(interval=1, demo=True, demo_devices=1)
        mon.add_rule(ThresholdRule(metric="mem_usage_percent", limit=0.0, cooldown=0))
        mon.on_alert(lambda msg: alerts.append(msg))
        mon.collect_once()
        # Since demo always produces some HBM usage > 0%, alert should fire
        assert len(alerts) >= 1
