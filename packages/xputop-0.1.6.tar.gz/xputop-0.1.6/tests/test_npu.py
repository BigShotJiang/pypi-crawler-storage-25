"""Tests for NPU data collection and parsing."""

import pytest
from xputop.core.backend import (
    AccelDevice,
    AccelProcess,
    AccelSnapshot,
)
from xputop.core.backends.npu import (
    parse_npu_smi_info,
    parse_npu_smi_processes,
)
from xputop.core.backends.demo import DemoBackend


# ---------------------------------------------------------------------------
# Sample npu-smi outputs for testing
# ---------------------------------------------------------------------------

SAMPLE_NPU_SMI_INFO = """\
+------------------------------------------------------------------------------------------------+
| npu-smi 25.0.RC1                  Version: 25.0.RC1                                           |
+---------------------------+---------------+----------------------------------------------------+
| NPU   Name                | Health        | Power(W)    Temp(C)           Hugepages-Usage(page)|
| Chip                      | Bus-Id        | AICore(%)   Memory-Usage(MB)  HBM-Usage(MB)        |
+===========================+===============+====================================================+
| 0     910B3               | OK            | 72.5        45                0    / 0              |
| 0                         | 0000:C1:00.0  | 0           0    / 0         1234 / 65536           |
+===========================+===============+====================================================+
| 1     910B3               | OK            | 68.2        42                0    / 0              |
| 0                         | 0000:C2:00.0  | 25          0    / 0         8192 / 65536           |
+===========================+===============+====================================================+
"""

SAMPLE_NPU_SMI_SIMPLE = """\
+---------------------------+---------------+----------------------------------------------------+
| NPU   Chip   Name  Health | Power  Temp  | Hugepages  Chip   HBM-Usage(MB)                    |
+===========================+===============+====================================================+
  0       0    910B3   OK      75      46       0          0    1024  / 65536
  1       0    910B3   OK      68      42       0          0    8192  / 65536
  2       0    910B3   WARNING 120     78       0          0    60000 / 65536
"""


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

class TestParseNpuSmiInfo:
    def test_parse_simple_rows(self):
        driver, devices, _ = parse_npu_smi_info(SAMPLE_NPU_SMI_SIMPLE)
        assert len(devices) >= 2

        d0 = devices[0]
        assert d0.device_id == 0
        assert d0.name == "910B3"
        assert d0.health == "OK"
        assert d0.mem_used == 1024.0
        assert d0.mem_total == 65536.0

    def test_parse_version(self):
        driver, _, _ = parse_npu_smi_info(SAMPLE_NPU_SMI_INFO)
        assert "25.0" in driver

    def test_empty_output(self):
        driver, devices, _ = parse_npu_smi_info("")
        assert devices == []
        assert driver == ""


class TestDemoSnapshot:
    def test_demo_returns_devices(self):
        backend = DemoBackend(num_devices=8)
        snap = backend.collect()
        assert len(snap.devices) == 8
        assert snap.error is None
        assert "1.0" in snap.driver_version

    def test_demo_device_fields(self):
        backend = DemoBackend(num_devices=1)
        snap = backend.collect()
        dev = snap.devices[0]
        assert dev.device_id == 0
        assert dev.mem_total == 65536.0
        assert 0 <= dev.temperature <= 100
        assert 0 <= dev.utilization_rate <= 100

    def test_hbm_usage_percent(self):
        dev = AccelDevice(device_id=0, name="t", temperature=0, power=0, 
                          utilization_rate=0, mem_used=32768, mem_total=65536, health="OK")
        assert abs(dev.mem_usage_percent - 50.0) < 0.01

    def test_hbm_free(self):
        dev = AccelDevice(device_id=0, name="t", temperature=0, power=0, 
                          utilization_rate=0, mem_used=10000, mem_total=65536, health="OK")
        assert abs(dev.mem_free - 55536.0) < 0.01


class TestParseProcesses:
    def test_parse_process_section(self):
        output = """\
+---------------------------+------+
| NPU    PID     Process Name      |
+===========================+======+
  0      12345   python3
  0      12346   mindspore
  1      22222   torch_npu
"""
        procs = parse_npu_smi_processes(output)
        assert len(procs) >= 2
        pids = {p.pid for p in procs}
        assert 12345 in pids
        assert 22222 in pids
