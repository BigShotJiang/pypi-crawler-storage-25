"""Tests for the Intel xpu-smi backend."""

from xputop.core.backends.intel import IntelBackend


def test_intel_csv(monkeypatch):
    backend = IntelBackend()

    fake_output = """Device ID,GPU Utilization (%),Power (W),GPU Temperature (C),Memory Capacity (MB),Memory Used (MB)
0,98.5,120.0,60,32768,4096
1,0,30.0,40,32768,0
"""

    def mock_run(*args, **kwargs):
        class Res:
            returncode = 0
            stdout = fake_output
        return Res()

    monkeypatch.setattr("subprocess.run", mock_run)

    snap = backend.collect()
    assert snap.error is None
    assert len(snap.devices) == 2

    d0 = snap.devices[0]
    assert d0.device_id == 0
    assert d0.utilization_rate == 98.5
    assert d0.power == 120.0
    assert d0.temperature == 60.0
    assert d0.mem_total == 32768.0
    assert d0.mem_used == 4096.0
