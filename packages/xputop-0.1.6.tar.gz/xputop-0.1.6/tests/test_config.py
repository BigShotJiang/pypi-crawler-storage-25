"""Tests for configuration loading and saving."""

import tempfile
from pathlib import Path

from xputop.alert.config import (
    EmailConfig,
    NputopConfig,
    load_config,
    save_config,
    generate_default_config,
)
from xputop.core.monitor import ThresholdRule


class TestConfig:
    def test_load_missing_file_returns_defaults(self, tmp_path):
        cfg = load_config(tmp_path / "nonexistent.toml")
        assert cfg.interval == 2.0
        assert cfg.demo is False
        assert cfg.email.enabled is False
        assert cfg.rules == []

    def test_save_and_load_roundtrip(self, tmp_path):
        path = tmp_path / "config.toml"
        original = NputopConfig(
            interval=5.0,
            demo=True,
            demo_devices=8,
            email=EmailConfig(
                enabled=True,
                smtp_host="smtp.test.com",
                smtp_port=465,
                use_tls=True,
                username="user",
                password="pass",
                sender="me@test.com",
                recipients=["a@test.com", "b@test.com"],
            ),
            rules=[
                ThresholdRule(metric="temperature", limit=75, cooldown=120),
                ThresholdRule(metric="hbm_usage_percent", limit=90, device_id=2),
            ],
        )
        save_config(original, path)

        loaded = load_config(path)
        assert loaded.interval == 5.0
        assert loaded.demo is True
        assert loaded.demo_devices == 8
        assert loaded.email.enabled is True
        assert loaded.email.smtp_host == "smtp.test.com"
        assert len(loaded.email.recipients) == 2
        assert len(loaded.rules) == 2
        assert loaded.rules[0].metric == "temperature"
        assert loaded.rules[1].device_id == 2

    def test_generate_default_config(self, tmp_path):
        path = tmp_path / "default.toml"
        result = generate_default_config(path)
        assert result.exists()
        content = result.read_text()
        assert "[general]" in content
        assert "[email]" in content
        assert "temperature" in content


class TestEmailConfig:
    def test_is_valid(self):
        ec = EmailConfig(
            enabled=True,
            smtp_host="smtp.test.com",
            sender="a@b.com",
            recipients=["c@d.com"],
        )
        assert ec.is_valid() is True

    def test_not_valid_when_disabled(self):
        ec = EmailConfig(
            enabled=False,
            smtp_host="smtp.test.com",
            sender="a@b.com",
            recipients=["c@d.com"],
        )
        assert ec.is_valid() is False

    def test_not_valid_without_recipients(self):
        ec = EmailConfig(enabled=True, smtp_host="x", sender="a@b.com")
        assert ec.is_valid() is False
