"""Tests for the AMD rocm-smi / amd-smi backend parsing."""

from xputop.core.backends.amd import AmdBackend


def test_rocm_smi_regex(monkeypatch):
    backend = AmdBackend()
    backend._cmd = "rocm-smi"
    backend._is_amd_smi = False

    fake_output = """
============================ ROCm System Management Interface ============================
====================================== System Info =======================================
GPU[0]: Temperature (Sensor edge) (C): 65.0
GPU[0]: GPU use (%): 99
GPU[0]: Average Graphics Package Power (W): 300.5
GPU[0]: VRAM Total Memory (B): 17163091968
GPU[0]: VRAM Total Used Memory (B): 8581545984
GPU[1]: Temperature (Sensor edge) (C): 62.0
GPU[1]: GPU use (%): 45
GPU[1]: Average Graphics Package Power (W): 150.2
GPU[1]: VRAM Total Memory (B): 17163091968
GPU[1]: VRAM Total Used Memory (B): 2000000000
=========================================================================================
"""

    def mock_run(*args, **kwargs):
        class Res:
            returncode = 0
            stdout = fake_output
        return Res()

    monkeypatch.setattr("subprocess.run", mock_run)

    devices, driver, err = backend._collect_rocm_smi()
    assert err == ""
    assert len(devices) == 2

    d0 = devices[0]
    assert d0.device_id == 0
    assert d0.temperature == 65.0
    assert d0.power == 300.5
    assert d0.utilization_rate == 99.0
    assert abs(d0.mem_total - 16368.0) < 1.0  # 17163091968 B ~ 16368 MB
    assert abs(d0.mem_used - 8184.0) < 1.0


def test_amd_smi_csv(monkeypatch):
    backend = AmdBackend()
    backend._cmd = "amd-smi"
    backend._is_amd_smi = True

    fake_output = """gpu,temperature (c),power (w),usage (%),vram total (mb),vram used (mb)
0,75.0,250.0,100,16384,16384
1,45.0,80.0,0,16384,1024
"""

    def mock_run(*args, **kwargs):
        class Res:
            returncode = 0
            stdout = fake_output
        return Res()

    monkeypatch.setattr("subprocess.run", mock_run)

    devices, driver, err = backend._collect_amd_smi()
    assert err == ""
    assert len(devices) == 2

    d1 = devices[1]
    assert d1.device_id == 1
    assert d1.temperature == 45.0
    assert d1.power == 80.0
    assert d1.utilization_rate == 0.0
    assert d1.mem_total == 16384.0
    assert d1.mem_used == 1024.0
