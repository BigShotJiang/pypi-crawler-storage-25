"""
消息构建器
负责根据不同提供商的要求构建消息格式
"""

from typing import List, Optional, Dict, Any, Tuple
from urllib.parse import urlparse
from filekits.base_io import download_encode_base64
from .validator import validate_base64_content, detect_base64_image_mime_type
from ..utils.normalize_error import ResponseError


def prepare_messages(
        provider_name: str,
        system_prompt: str,
        user_text: str,
        include_img: bool = False,
        img_list: Optional[ List[ str ] ] = None,
) -> List[ Dict[ str, Any ] ] :
    """
    根据提供商名称准备消息格式

    Args:
        provider_name: 提供商名称 ('dashscope', 'zhipu', 'openai', 'modelscope')
        system_prompt: 系统提示词
        user_text: 用户文本
        include_img: 是否包含图片
        img_list: 图片URL列表

    Returns:
        格式化后的消息列表
    """
    if img_list is None :
        if include_img :
            error_tag = "缺少图片"
            response_error = ResponseError( "", "",
                                            exception = ValueError( "包含图片的消息，图片 img_list 不能为空。" ),
                                            error_tag = error_tag )
            response_error.skip_report = True
            raise response_error

        img_list = [ ]

    if include_img and len( img_list ) < 1 :
        error_tag = "缺少图片"
        response_error = ResponseError( "", "",
                                        exception = ValueError( "包含图片的消息，图片 img_list 不能为空。" ),
                                        error_tag = error_tag )
        response_error.skip_report = True
        raise response_error

    # 根据提供商构建不同格式的消息
    system_content, user_content = _build_content_by_provider(
        provider_name, system_prompt, user_text, include_img, img_list
    )

    # 构建消息结构
    user_message = { "role" : "user", "content" : user_content }

    if system_content :
        system_message = { "role" : "system", "content" : system_content }
        return [ system_message, user_message ]
    else :
        return [ user_message ]


def rebuild_messages_single_image(
        provider_name: str,
        system_prompt: str,
        user_text: str,
        reject_single_image: bool,
        img_list: list,
) -> List[ Dict[ str, Any ] ] :
    """
    重新构造messages，只使用一张图片。

    Args:
        provider_name: 提供商名称
        system_prompt: 系统提示词
        user_text: 用户文本
        reject_single_image: 是否禁止单张图片（为True时若图片数量为1则抛异常）
        img_list: 图片URL或base64列表

    Returns:
        格式化后的消息列表（仅保留一张图片）

    Notes:
        优先选择已转换成功的base64图片；如果没有，则回退到第一张图片。
        这样在重试阶段可以尽量保留已经成功转换的图片，而不是再次发送原始URL。
    """
    if not img_list :
        error_tag = "缺少图片"
        response_error = ResponseError( "", "",
                                        exception = ValueError( "包含图片的消息，图片 img_list 不能为空。" ),
                                        error_tag = error_tag )
        response_error.skip_report = True
        raise response_error

    img_num = len( img_list )

    if reject_single_image :
        if img_num == 1 :
            error_tag = "图片数量 == 1，无法缩减"
            response_error = ResponseError( "", "",
                                            exception = ValueError( "异常：图片数量 == 1，无法缩减" ),
                                            error_tag = error_tag )
            response_error.skip_report = True
            raise response_error

    selected_img = next(
        (img for img in img_list if isinstance( img, str ) and img.startswith( 'data:image/' ) and ';base64,' in img),
        img_list[ 0 ],
    )

    return prepare_messages( provider_name, system_prompt, user_text, True, [ selected_img ] )


def _build_content_by_provider(
        provider_name: str,
        system_prompt: str,
        user_text: str,
        include_img: bool,
        img_list: List[ str ],
        image_cache = None,  # 图片缓存参数
) -> tuple :
    """根据提供商构建内容格式"""

    if not include_img :
        return system_prompt, user_text

    if provider_name == "dashscope" :
        user_content = [ { "image" : img } for img in img_list ]
        user_content.append( { "text" : user_text } )
        if system_prompt :
            system_content = [ { "text" : system_prompt } ]
        else :
            system_content = [ ]

    # 兼容通用的 "openai", "modelscope", "openrouter" 格式 , 不支持 zhipu ( 可切换为 zhipu_openai 进行兼容 )
    else :
        if provider_name in [ "openrouter", "gemini", "vercel", "github" ] :
            # openrouter 需要base64格式的图片
            img_list = convert_images_to_base64( img_list, image_cache )  # 传递缓存

        user_content = [ { "type" : "image_url", "image_url" : { "url" : img } } for img in img_list ]
        if provider_name in [ "gitcode" ] :
            if system_prompt :
                system_prompt_user = f"# 任务角色与设定 \n{system_prompt}\n"
            else :
                system_prompt_user = ""
            user_prompt = f"# 任务相关信息 \n{user_text}\n"
            user_content.append( { "type" : "text", "text" : system_prompt_user + user_prompt } )
            system_content = [ ]
        else :
            user_content.append( { "type" : "text", "text" : user_text } )
            if system_prompt :
                system_content = [ { "type" : "text", "text" : system_prompt } ]
            else :
                system_content = [ ]

    return system_content, user_content


def _infer_mime_type_from_url( img_url: str ) -> str :
    """根据URL路径后缀推断图片MIME类型。"""
    ext_to_mime = {
        ".jpg"  : "image/jpeg",
        ".jpeg" : "image/jpeg",
        ".png"  : "image/png",
        ".gif"  : "image/gif",
        ".webp" : "image/webp",
        ".bmp"  : "image/bmp",
        ".svg"  : "image/svg+xml",
        ".avif" : "image/avif",
        ".heic" : "image/heic",
        ".heif" : "image/heic",
    }
    img_path = urlparse( img_url ).path.lower()
    for ext, mime_type in ext_to_mime.items() :
        if img_path.endswith( ext ) :
            return mime_type
    return ""


def _build_base64_image_url( base64_str: str, img_url: str = "" ) -> str :
    """根据base64内容或URL推断MIME类型并构造data URL。"""
    mime_type = detect_base64_image_mime_type( base64_str ) or _infer_mime_type_from_url( img_url ) or "image/jpeg"
    return f"data:{mime_type};base64,{base64_str}"


def _mark_image_conversion_failed( image_cache, img_url: str, reason: str ) -> None :
    """记录图片转换失败，兼容没有失败缓存能力的缓存对象。"""
    if image_cache is not None and hasattr( image_cache, "mark_failed" ) :
        image_cache.mark_failed( img_url, reason )


def _get_image_cache( image_cache = None ) :
    """获取图片缓存对象。"""
    if image_cache is not None :
        return image_cache

    try :
        from ..dispatcher import ModelDispatcher

        return ModelDispatcher.get_image_cache()
    except ImportError :
        return None


def _is_base64_image_url( img_url: str ) -> bool :
    return isinstance( img_url, str ) and img_url.startswith( 'data:image/' ) and ';base64,' in img_url


def _raise_all_images_failed( img_list: List[ str ], failure_errors: List[ str ] ) -> None :
    error_tag = "图片下载转base64失败"
    error_message = f"所有图片 下载/转换base64 均失败，url：{img_list}"
    if failure_errors :
        error_message = f"{error_message}\n" + "\n".join( failure_errors )
    exception = Exception( error_message )
    response_error = ResponseError( "", "",
                                    exception = exception,
                                    error_tag = error_tag )
    response_error.skip_report = True
    raise response_error


def resolve_images_with_cache(
        img_list: List[ str ],
        image_cache = None,
        convert_uncached: bool = False,
) -> List[ str ] :
    """
    使用单图/图片组缓存解析图片列表。

    convert_uncached=False 时只应用已知缓存结果，不主动下载未知URL；
    convert_uncached=True 时会对未知URL执行下载转base64，并写入单图和图片组缓存。
    """
    if not img_list :
        raise ValueError( "图片 img_list 不能为空!" )

    image_cache = _get_image_cache( image_cache )

    if image_cache is not None and hasattr( image_cache, "get_group_result" ) :
        group_result = image_cache.get_group_result( img_list )
        if group_result :
            successful_images = group_result.get( "successful_images", [ ] )
            failed_urls = group_result.get( "failed_urls", [ ] )
            all_failed = group_result.get( "all_failed", False )

            if successful_images :
                if failed_urls :
                    print( f"已从图片组缓存获取可用图片，跳过失败图片 {len(failed_urls)} 张" )
                else :
                    print( "已从图片组缓存获取可用图片" )
                return list( successful_images )

            if all_failed :
                failure_errors = [ f"已命中图片组失败缓存: {img_url}" for img_url in img_list ]
                _raise_all_images_failed( img_list, failure_errors )

    if convert_uncached :
        return convert_images_to_base64( img_list, image_cache )

    resolved_img_list = [ ]
    failed_urls = [ ]
    failure_errors = [ ]

    for img_url in img_list :
        if not isinstance( img_url, str ) :
            resolved_img_list.append( img_url )
            continue

        normalized_img_url = img_url.strip()
        if not normalized_img_url :
            continue

        if _is_base64_image_url( normalized_img_url ) :
            resolved_img_list.append( normalized_img_url )
            continue

        if image_cache is None :
            resolved_img_list.append( normalized_img_url )
            continue

        if hasattr( image_cache, "is_failed" ) and image_cache.is_failed( normalized_img_url ) :
            reason = ""
            if hasattr( image_cache, "get_failed_reason" ) :
                reason = image_cache.get_failed_reason( normalized_img_url )
            message = f"已跳过失败缓存图片: {normalized_img_url}"
            if reason :
                message = f"{message}, 原因: {reason}"
            print( message )
            failed_urls.append( normalized_img_url )
            failure_errors.append( message )
            continue

        cached_base64 = image_cache.get( normalized_img_url )
        if cached_base64 :
            is_valid, error_msg = validate_base64_content( cached_base64, expected_type = "image" )
            if is_valid :
                print( f"已从缓存中获取图片base64: {normalized_img_url}" )
                resolved_img_list.append( _build_base64_image_url( cached_base64, normalized_img_url ) )
                continue

            message = f"缓存中的base64内容无效，已跳过: {normalized_img_url}, 原因: {error_msg}"
            print( message )
            failed_urls.append( normalized_img_url )
            failure_errors.append( message )
            _mark_image_conversion_failed( image_cache, normalized_img_url, error_msg )
            continue

        resolved_img_list.append( normalized_img_url )

    if not resolved_img_list :
        if image_cache is not None and hasattr( image_cache, "put_group_result" ) :
            image_cache.put_group_result( img_list, [ ], failed_urls, True )
        _raise_all_images_failed( img_list, failure_errors )

    return resolved_img_list


def convert_images_to_base64( img_list: List[ str ], image_cache = None ) -> List[ str ] :
    """
    将图片列表转换为base64格式（仅返回转换成功的图片项）。

    Args:
        img_list: 图片URL或base64列表
        image_cache: 可选的图片base64缓存对象

    Returns:
        仅包含转换成功项的图片列表。
        - 转换成功的项会变成 `data:image/...;base64,...`
        - 转换失败的项会被跳过

    Notes:
        1. 不再仅依赖 `.jpg/.jpeg/.png` 后缀判断是否可转换；
        2. 转换后的图片列表，不支持 sdk/platform/provider = zhipu ，
           如需使用，请使用名称 zhipu_openai 兼容 openai 的格式。
    """
    if not img_list :
        raise ValueError( "图片 img_list 不能为空!" )

    image_cache = _get_image_cache( image_cache )

    if image_cache is not None and hasattr( image_cache, "get_group_result" ) :
        group_result = image_cache.get_group_result( img_list )
        if group_result :
            successful_images = group_result.get( "successful_images", [ ] )
            failed_urls = group_result.get( "failed_urls", [ ] )
            all_failed = group_result.get( "all_failed", False )

            if successful_images :
                if failed_urls :
                    print( f"已从图片组缓存获取可用图片，跳过失败图片 {len(failed_urls)} 张" )
                else :
                    print( "已从图片组缓存获取可用图片" )
                return list( successful_images )

            if all_failed :
                failure_errors = [ f"已命中图片组失败缓存: {img_url}" for img_url in img_list ]
                _raise_all_images_failed( img_list, failure_errors )

    processed_img_list = [ ]
    successful_conversions = 0
    success_logs = [ ]
    failure_errors = [ ]
    failed_urls = [ ]

    for img_url in img_list :
        # 仅保留转换成功的图片；失败项直接跳过。
        if not isinstance( img_url, str ) :
            # processed_img_list.append(img_url)
            failure_errors.append( f"{img_url}: 图片地址不是字符串" )
            continue
        # 如果已经是 通过 _build_base64_image_url 构建好的 base64 格式 ，就直接添加
        if _is_base64_image_url( img_url ) :
            processed_img_list.append( img_url )
            successful_conversions += 1
            continue

        normalized_img_url = img_url.strip()
        if not normalized_img_url :
            # processed_img_list.append(img_url)
            failure_errors.append( f"{img_url}: 图片地址为空" )
            continue

        if image_cache is not None :
            if hasattr( image_cache, "is_failed" ) and image_cache.is_failed( normalized_img_url ) :
                reason = ""
                if hasattr( image_cache, "get_failed_reason" ) :
                    reason = image_cache.get_failed_reason( normalized_img_url )
                message = f"已跳过失败缓存图片: {normalized_img_url}"
                if reason :
                    message = f"{message}, 原因: {reason}"
                print( message )
                failure_errors.append( message )
                failed_urls.append( normalized_img_url )
                continue

            # 先查缓存，减少重复下载。
            cached_base64 = image_cache.get( normalized_img_url )
            if cached_base64 :
                is_valid, error_msg = validate_base64_content( cached_base64, expected_type = "image" )
                if is_valid :
                    success_logs.append( f"已从缓存中获取图片base64: {normalized_img_url}" )
                    processed_img_list.append( _build_base64_image_url( cached_base64, normalized_img_url ) )
                    successful_conversions += 1
                    continue
                message = f"缓存中的base64内容无效，已跳过: {normalized_img_url}, 原因: {error_msg}"
                print( message )
                failure_errors.append( message )
                failed_urls.append( normalized_img_url )
                _mark_image_conversion_failed( image_cache, normalized_img_url, error_msg )
                continue

        try :
            # 不依赖URL后缀，直接按URL下载并探测真实内容类型。
            base64_str = download_encode_base64( normalized_img_url )
            if not base64_str :
                message = f"转换后, base64_str 为空，: {normalized_img_url}"
                print( message )
                failure_errors.append( message )
                failed_urls.append( normalized_img_url )
                _mark_image_conversion_failed( image_cache, normalized_img_url, "base64_str 为空" )
                # processed_img_list.append(img_url)
                continue

            is_valid, error_msg = validate_base64_content( base64_str, expected_type = "image" )
            if not is_valid :
                message = f"转换后，base64 验证失败，已跳过: {normalized_img_url}, 原因: {error_msg}"
                print( message )
                failure_errors.append( message )
                failed_urls.append( normalized_img_url )
                _mark_image_conversion_failed( image_cache, normalized_img_url, error_msg )
                # processed_img_list.append(img_url)
                continue

            if image_cache is not None :
                image_cache.put( normalized_img_url, base64_str )

            processed_img_list.append( _build_base64_image_url( base64_str, normalized_img_url ) )

            successful_conversions += 1
            success_logs.append( f"已将图片转换为base64格式: {normalized_img_url}" )

        except Exception as e :
            message = f"图片下载转base64失败: {normalized_img_url}\n{e}"
            print( message )
            failure_errors.append( message )
            failed_urls.append( normalized_img_url )
            _mark_image_conversion_failed( image_cache, normalized_img_url, str( e ) )
            # processed_img_list.append(img_url)

    if successful_conversions == 0 :
        if image_cache is not None and hasattr( image_cache, "put_group_result" ) :
            image_cache.put_group_result( img_list, [ ], failed_urls, True )
        _raise_all_images_failed( img_list, failure_errors )

    for success_log in success_logs :
        print( success_log )
    if failure_errors :
        print( f"图片组base64转换部分成功：成功 {successful_conversions} 张，失败 {len(failure_errors)} 张" )

    if image_cache is not None and hasattr( image_cache, "put_group_result" ) :
        image_cache.put_group_result( img_list, processed_img_list, failed_urls, False )

    return processed_img_list


def prepare_request_data( platform: str, messages: Any, message_info: Optional[ Dict ] ) -> Tuple[ Any, Dict ] :
    """准备请求数据

    Args:
        platform: 平台名称
        messages: 请求消息对象
        message_info: 消息信息字典，包含系统提示词、用户文本、是否包含图片和图片列表等

    Returns:
        Tuple[Any, Dict]: (更新后的消息对象, 消息配置字典)
    """
    message_config = { "user_text" : "", "include_img" : False, "img_list" : [ ] }

    if message_info is not None :
        message_config.update(
            {
                "user_text"   : message_info[ "user_text" ],
                "include_img" : message_info.get( "include_img", False ),
                "img_list"    : message_info.get( "img_list", [ ] ),
            }
        )

        system_prompt = message_info[ "system_prompt" ]
        if system_prompt :
            message_config[ "system_prompt" ] = system_prompt

        messages = prepare_messages(
            platform,
            message_config.get( "system_prompt", "" ),
            message_config[ "user_text" ],
            message_config[ "include_img" ],
            message_config[ "img_list" ],
        )
    return messages, message_config
