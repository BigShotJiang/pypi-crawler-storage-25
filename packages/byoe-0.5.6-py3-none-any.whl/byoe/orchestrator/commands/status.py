"""byoe status 命令 — 查看所有活跃变更状态"""
from __future__ import annotations

import re
from pathlib import Path
from byoe.orchestrator.utils import green, yellow, cyan, bold, red


def status_command() -> None:
    cwd = Path.cwd()
    crew_dir = cwd / "crew"

    if not crew_dir.exists():
        print(yellow("⚠️  未找到 crew/ 目录，请先运行 byoe init"))
        return

    changes_dir = crew_dir / "changes"
    archive_dir = crew_dir / "archive"

    active_changes = []
    if changes_dir.exists():
        for change_dir in sorted(changes_dir.iterdir()):
            if change_dir.is_dir():
                info = _read_change_info(change_dir)
                active_changes.append(info)

    archived_count = (
        len([x for x in archive_dir.iterdir() if x.is_dir()])
        if archive_dir.exists() else 0
    )

    print(f"\n{bold('📊 BYOE 工作区状态')}\n")

    blockers = _read_blockers(crew_dir)
    open_blockers = [b for b in blockers if b["status"] == "OPEN"]

    if open_blockers:
        print(f"{red('🚨 待解决问题 (%d):' % len(open_blockers))}")
        for b in open_blockers:
            print(f"   [{b['id']}] {b['title']}")
            if b.get("related"):
                print(f"        关联: {b['related']}")
        print()

    if not active_changes:
        print(yellow("   暂无活跃变更"))
        print(f"\n   运行 {bold('byoe plan <变更名称>')} 创建新变更\n")
    else:
        print(f"活跃变更（{len(active_changes)} 个）:\n")
        for c in active_changes:
            _print_change_status(c)

    if archived_count:
        print(f"已归档: {archived_count} 个变更  （运行 {bold('byoe release')} 归档已完成变更）\n")

    resume_path = crew_dir / "resume.md"
    if resume_path.exists():
        next_steps = _extract_next_steps(resume_path)
        if next_steps:
            print(f"{cyan('📌 下一步:')}")
            for step in next_steps:
                print(f"   {step}")
            print()


def _read_change_info(change_dir: Path) -> dict:
    info: dict = {
        "name": change_dir.name,
        "mode": "standard",
        "phase": "plan",
        "has_proposal": False,
        "has_design": False,
        "plan_confirmed": False,
        "verify_confirmed": False,
        "tasks_total": 0,
        "tasks_done": 0,
    }

    proposal_path = change_dir / "proposal.md"
    if proposal_path.exists():
        info["has_proposal"] = True
        content = proposal_path.read_text(encoding="utf-8")
        fm = _parse_frontmatter(content)
        info["mode"] = fm.get("mode", "standard")
        info["plan_confirmed"] = fm.get("plan_confirmed", "false").lower() == "true"
        done = len(re.findall(r"- \[x\]", content, re.IGNORECASE))
        total = len(re.findall(r"- \[[ x]\]", content, re.IGNORECASE))
        info["tasks_total"] = total
        info["tasks_done"] = done

    design_path = change_dir / "design.md"
    if design_path.exists():
        info["has_design"] = True
        info["phase"] = "execute" if info["plan_confirmed"] else "design"
    elif info["plan_confirmed"]:
        info["phase"] = "execute" if info["mode"] == "express" else "design"

    return info


def _print_change_status(c: dict) -> None:
    phase_emoji = {
        "plan": "📝", "design": "🏗️", "execute": "⚡",
        "verify": "🔍", "iterate": "🔄", "done": "✅",
    }
    phase_label = {
        "plan": "Plan", "design": "Design", "execute": "Execute",
        "verify": "Verify", "iterate": "Iterate", "done": "完成",
    }

    emoji = phase_emoji.get(c["phase"], "•")
    phase = phase_label.get(c["phase"], c["phase"])
    mode_tag = f"[{c['mode']}]" if c["mode"] != "standard" else ""
    progress = f" {c['tasks_done']}/{c['tasks_total']}" if c["tasks_total"] > 0 else ""

    print(f"  {emoji} {bold(c['name'])} {yellow(mode_tag)}")
    print(f"     阶段: {cyan(phase)}{progress}")
    print(f"     文件: crew/changes/{c['name']}/")
    if not c["plan_confirmed"]:
        print(f"     {yellow('⏳ 等待确认 proposal.md')}")
    print()


def _parse_frontmatter(content: str) -> dict:
    m = re.match(r"^---\s*\n(.*?)\n---", content, re.DOTALL)
    if not m:
        return {}
    result: dict = {}
    for line in m.group(1).splitlines():
        kv = line.split(":", 1)
        if len(kv) == 2:
            k, v = kv[0].strip(), kv[1].strip().strip("'\"")
            result[k] = v
    return result


def _read_blockers(crew_dir: Path) -> list[dict]:
    blockers_path = crew_dir / "blockers.md"
    if not blockers_path.exists():
        return []
    content = blockers_path.read_text(encoding="utf-8")
    blockers = []
    for m in re.finditer(r"## \[(\w+)\] #(\d+) (.+)", content):
        status, num, title = m.group(1), m.group(2), m.group(3)
        related_m = re.search(r"#\s*\*\*关联\*\*:\s*(.+)", content[m.end():m.end() + 200])
        blockers.append({
            "status": status,
            "id": f"#{num}",
            "title": title.strip(),
            "related": related_m.group(1).strip() if related_m else "",
        })
    return blockers


def _extract_next_steps(resume_path: Path) -> list[str]:
    try:
        content = resume_path.read_text(encoding="utf-8")
        m = re.search(r"## 下一步\n(.*?)(?:\n## |\Z)", content, re.DOTALL)
        if m:
            lines = [l.strip() for l in m.group(1).strip().splitlines() if l.strip()]
            return lines[:3]
    except Exception:
        pass
    return []
