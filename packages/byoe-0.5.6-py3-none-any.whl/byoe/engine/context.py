"""Multi-layer context compression.

Three compression layers triggered by context window usage:
  Layer 1 (50%)  - snip verbose tool outputs
  Layer 2 (70%)  - LLM-powered summary of old turns (runs in background thread)
  Layer 3 (90%)  - hard collapse: drop everything except summary + recent
"""

from __future__ import annotations
import threading
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .llm import LLM

# ---------------------------------------------------------------------------
# Token estimation
# ---------------------------------------------------------------------------

def _make_encoder():
    """Try to import tiktoken for accurate token counting.

    Falls back gracefully if tiktoken is not installed — the heuristic below
    is used instead.  We cache the encoder in a module-level variable so we
    only pay the import cost once.
    """
    try:
        import tiktoken
        # cl100k_base is used by GPT-4/3.5, DeepSeek, Qwen, and most
        # OpenAI-compatible models.  It's a safe approximation for others.
        return tiktoken.get_encoding("cl100k_base")
    except Exception:
        return None

_encoder = _make_encoder()


def _approx_tokens(text: str) -> int:
    """Accurate token count when tiktoken is available; heuristic fallback.

    Heuristic improvements over the old version:
    - CJK characters: ~1 token each (BPE encodes them individually)
    - ASCII / Latin text: ~3.5 chars/token (code is denser than prose)
    - Adds 4 tokens per message overhead (system role overhead)
    """
    if _encoder is not None:
        try:
            return len(_encoder.encode(text, disallowed_special=()))
        except Exception:
            pass  # fallback to heuristic on any encode error

    cjk = sum(1 for ch in text if '\u4e00' <= ch <= '\u9fff'
              or '\u3040' <= ch <= '\u30ff'
              or '\uac00' <= ch <= '\ud7af')
    other = len(text) - cjk
    # 3.5 chars/token is more accurate than 4 for code-heavy content
    return cjk + int(other / 3.5)


def estimate_tokens(messages: list[dict]) -> int:
    total = 0
    for m in messages:
        if m.get("content"):
            total += _approx_tokens(m["content"])
        if m.get("tool_calls"):
            total += _approx_tokens(str(m["tool_calls"]))
    return total


class ContextManager:
    def __init__(self, max_tokens: int = 128_000):
        self.max_tokens = max_tokens
        self._snip_at      = int(max_tokens * 0.50)
        self._summarize_at = int(max_tokens * 0.70)
        self._collapse_at  = int(max_tokens * 0.90)

    def maybe_compress(
        self,
        messages: list[dict],
        llm: LLM | None = None,
        on_compress=None,
    ) -> bool:
        """Compress messages if context window usage exceeds thresholds.

        Args:
            messages:    The live message list (mutated in place).
            llm:         Optional LLM used for summarisation.
            on_compress: Optional callable(layer: str, before: int, after: int)
                         called whenever compression occurs — use this to surface
                         a UI notice like "⚡ context compressed".
        """
        current = estimate_tokens(messages)
        compressed = False

        if current > self._snip_at:
            if self._snip_tool_outputs(messages):
                compressed = True
                after = estimate_tokens(messages)
                if on_compress:
                    on_compress("snip", current, after)
                current = after

        if current > self._summarize_at and len(messages) > 10:
            if self._summarize_old(messages, llm, keep_recent=8):
                compressed = True
                after = estimate_tokens(messages)
                if on_compress:
                    on_compress("summarize", current, after)
                current = after

        if current > self._collapse_at and len(messages) > 4:
            self._hard_collapse(messages, llm)
            compressed = True
            after = estimate_tokens(messages)
            if on_compress:
                on_compress("collapse", current, after)

        return compressed

    @staticmethod
    def _snip_tool_outputs(messages: list[dict]) -> bool:
        changed = False
        for m in messages:
            if m.get("role") != "tool":
                continue
            content = m.get("content", "")
            if len(content) <= 1500:
                continue
            lines = content.splitlines()
            if len(lines) <= 6:
                continue
            snipped = (
                "\n".join(lines[:3])
                + f"\n... ({len(lines)} lines, snipped to save context) ...\n"
                + "\n".join(lines[-3:])
            )
            m["content"] = snipped
            changed = True
        return changed

    def _summarize_old(self, messages: list[dict], llm: LLM | None,
                       keep_recent: int = 8) -> bool:
        if len(messages) <= keep_recent:
            return False

        old  = messages[:-keep_recent]
        tail = messages[-keep_recent:]

        # Use heuristic summary immediately so the SSE thread is not blocked.
        # LLM summary (if llm is provided) runs in a background thread and
        # patches the first message in-place once it completes.
        placeholder = self._extract_key_info(old)

        messages.clear()
        summary_msg: dict = {
            "role": "user",
            "content": f"[Context compressed - conversation summary]\n{placeholder}",
        }
        messages.append(summary_msg)
        messages.append({
            "role": "assistant",
            "content": "Got it, I have the context from our earlier conversation.",
        })
        messages.extend(tail)

        if llm:
            flat = self._flatten(old)

            def _bg_summarize():
                try:
                    resp = llm.chat(
                        messages=[
                            {
                                "role": "system",
                                "content": (
                                    "Compress this conversation into a brief summary. "
                                    "Preserve: file paths edited, key decisions made, "
                                    "errors encountered, current task state. "
                                    "Drop: verbose command output, code listings, "
                                    "redundant back-and-forth."
                                ),
                            },
                            {"role": "user", "content": flat[:15000]},
                        ],
                    )
                    if resp.content:
                        summary_msg["content"] = (
                            f"[Context compressed - conversation summary]\n{resp.content}"
                        )
                except Exception:
                    pass  # keep heuristic placeholder on any error

            threading.Thread(target=_bg_summarize, daemon=True).start()

        return True

    def _hard_collapse(self, messages: list[dict], llm: LLM | None):
        tail = messages[-4:] if len(messages) > 4 else messages[-2:]
        old = messages[:-len(tail)]
        placeholder = self._extract_key_info(old)

        messages.clear()
        summary_msg: dict = {
            "role": "user",
            "content": f"[Hard context reset]\n{placeholder}",
        }
        messages.append(summary_msg)
        messages.append({
            "role": "assistant",
            "content": "Context restored. Continuing from where we left off.",
        })
        messages.extend(tail)

        if llm:
            flat = self._flatten(old)

            def _bg_collapse():
                try:
                    resp = llm.chat(
                        messages=[
                            {
                                "role": "system",
                                "content": (
                                    "Compress this conversation into a brief summary. "
                                    "Preserve: file paths edited, key decisions made, "
                                    "errors encountered, current task state."
                                ),
                            },
                            {"role": "user", "content": flat[:15000]},
                        ],
                    )
                    if resp.content:
                        summary_msg["content"] = f"[Hard context reset]\n{resp.content}"
                except Exception:
                    pass

            threading.Thread(target=_bg_collapse, daemon=True).start()

    def _get_summary(self, messages: list[dict], llm: LLM | None) -> str:
        flat = self._flatten(messages)

        if llm:
            try:
                resp = llm.chat(
                    messages=[
                        {
                            "role": "system",
                            "content": (
                                "Compress this conversation into a brief summary. "
                                "Preserve: file paths edited, key decisions made, "
                                "errors encountered, current task state. "
                                "Drop: verbose command output, code listings, "
                                "redundant back-and-forth."
                            ),
                        },
                        {"role": "user", "content": flat[:15000]},
                    ],
                )
                return resp.content
            except Exception:
                pass

        return self._extract_key_info(messages)

    @staticmethod
    def _flatten(messages: list[dict]) -> str:
        parts = []
        for m in messages:
            role = m.get("role", "?")
            text = m.get("content", "") or ""
            if text:
                parts.append(f"[{role}] {text[:400]}")
        return "\n".join(parts)

    @staticmethod
    def _extract_key_info(messages: list[dict]) -> str:
        import re
        files_seen: set[str] = set()
        errors: list[str] = []

        for m in messages:
            text = m.get("content", "") or ""
            for match in re.finditer(r'[\w./\-]+\.\w{1,5}', text):
                files_seen.add(match.group())
            for line in text.splitlines():
                if "error" in line.lower():
                    errors.append(line.strip()[:150])

        parts = []
        if files_seen:
            parts.append(f"Files touched: {', '.join(sorted(files_seen)[:20])}")
        if errors:
            parts.append(f"Errors seen: {'; '.join(errors[:5])}")
        return "\n".join(parts) or "(no extractable context)"
