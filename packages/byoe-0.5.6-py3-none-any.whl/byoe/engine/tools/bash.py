"""Shell command execution with safety checks.

Cross-platform: uses cmd.exe on Windows, /bin/sh on Unix.
Dangerous-command detection covers both platforms.
"""

import os
import re
import subprocess
import sys
from .base import Tool

# ── Unix dangerous patterns ───────────────────────────────────────────────────
_DANGEROUS_PATTERNS_UNIX = [
    (r"\brm\s+(-\w*)?-r\w*\s+(/|~|\$HOME)", "recursive delete on home/root"),
    (r"\brm\s+(-\w*)?-rf\s", "force recursive delete"),
    (r"\bmkfs\b", "format filesystem"),
    (r"\bdd\s+.*of=/dev/", "raw disk write"),
    (r">\s*/dev/sd[a-z]", "overwrite block device"),
    (r"\bchmod\s+(-R\s+)?777\s+/", "chmod 777 on root"),
    (r":\(\)\s*\{.*:\|:.*\}", "fork bomb"),
    (r"\bcurl\b.*\|\s*(sudo\s+)?bash", "pipe curl to bash"),
    (r"\bwget\b.*\|\s*(sudo\s+)?bash", "pipe wget to bash"),
]

# ── Windows dangerous patterns ────────────────────────────────────────────────
_DANGEROUS_PATTERNS_WIN = [
    (r"\brd\s+/s\s+/q\s+[a-zA-Z]:\\\\", "recursive delete of drive root"),
    (r"\brmdir\s+/s\s+/q\s+[a-zA-Z]:\\\\", "recursive delete of drive root"),
    (r"\bformat\s+[a-zA-Z]:", "format drive"),
    (r"\bdiskpart\b", "disk partition tool"),
    (r"\bdel\s+/[fsq]*\s+[a-zA-Z]:\\\\", "bulk delete from drive root"),
    (r"\bpowershell\b.*\|\s*iex\b", "pipe to Invoke-Expression"),
    (r"\bpowershell\b.*\bDownloadString\b.*\|\s*iex\b", "download and execute"),
]

_DANGEROUS_PATTERNS = (
    _DANGEROUS_PATTERNS_WIN if sys.platform == "win32" else _DANGEROUS_PATTERNS_UNIX
)


class BashTool(Tool):
    name = "bash"
    description = (
        "Execute a shell command. Returns stdout, stderr, and exit code. "
        "Use this for running tests, installing packages, git operations, etc."
    )
    parameters = {
        "type": "object",
        "properties": {
            "command": {"type": "string", "description": "The shell command to run"},
            "timeout": {"type": "integer", "description": "Timeout in seconds (default 120)"},
        },
        "required": ["command"],
    }

    def __init__(self):
        # Per-instance working directory — eliminates the global mutable state
        # race condition when multiple tools/agents run concurrently.
        self._cwd: str | None = None
        # Optional sandbox root — if set, commands cannot cd outside this tree
        self._sandbox_root: str | None = None

    def set_sandbox_root(self, path: str) -> None:
        """Restrict all execution to a subtree. Agent.reset should call this."""
        self._sandbox_root = os.path.realpath(path) if path else None

    def reset_cwd(self) -> None:
        """Reset tracked working directory (called by Agent.reset)."""
        self._cwd = None

    def set_cwd(self, path: str) -> None:
        """Explicitly set the working directory (e.g. for multi-tenant use)."""
        self._cwd = path

    def execute(self, command: str, timeout: int = 120) -> str:
        warning = _check_dangerous(command)
        if warning:
            return (
                f"⚠ Blocked: {warning}\nCommand: {command}\n"
                "If intentional, modify the command to be more specific."
            )

        # Cap timeout: max 120s to prevent hanging the server
        timeout = max(1, min(int(timeout), 120))

        cwd = self._cwd or os.getcwd()

        # Enforce sandbox root if set
        if self._sandbox_root:
            real_cwd = os.path.realpath(cwd)
            if not real_cwd.startswith(self._sandbox_root):
                cwd = self._sandbox_root

        try:
            # Append a cwd-sentinel so we can capture the shell's actual cwd
            # after the command runs.  Works for cd, pushd, subshell changes, etc.
            _SENTINEL = "__BYOE_CWD__"
            if sys.platform == "win32":
                # Write to a temp file to avoid injecting sentinel into commands
                # that contain &, |, >, < etc. (special cmd.exe metacharacters).
                # Strategy: run the user command in a sub-shell, then in a
                # separate statement (after &&/unconditional) echo sentinel to a
                # temp file, then read it back.  We use a named temp file instead
                # of inline echo to avoid any metacharacter collision.
                import tempfile
                tmp_sentinel = tempfile.mktemp(suffix=".txt", prefix="byoe_cwd_")
                # Use parentheses to isolate user command; sentinel write is always
                # executed regardless of exit code via a second cmd statement.
                wrapped_cmd = f'({command}) & echo %CD%>{tmp_sentinel}'
                shell_args = ["cmd", "/c", wrapped_cmd]
                use_shell = False
            else:
                wrapped_cmd = f'{command}\necho "{_SENTINEL}:$(pwd)"'
                shell_args = wrapped_cmd
                use_shell = True

            proc = subprocess.run(
                shell_args,
                shell=use_shell,
                capture_output=True,
                text=True,
                timeout=timeout,
                cwd=cwd,
            )

            # Extract cwd from sentinel
            if sys.platform == "win32":
                # Read cwd from temp file written by the sentinel statement
                new_cwd_detected = None
                try:
                    if os.path.isfile(tmp_sentinel):
                        raw_cwd = open(tmp_sentinel, encoding="utf-8", errors="replace").read().strip()
                        if raw_cwd and os.path.isdir(raw_cwd):
                            new_cwd_detected = raw_cwd
                except Exception:
                    pass
                finally:
                    try:
                        os.unlink(tmp_sentinel)
                    except Exception:
                        pass
                out_stdout = proc.stdout
            else:
                # Extract and strip the sentinel line from stdout
                stdout_lines = proc.stdout.splitlines(keepends=True)
                new_cwd_detected = None
                filtered_lines = []
                for line in stdout_lines:
                    stripped = line.rstrip("\r\n")
                    if stripped.startswith(f"{_SENTINEL}:"):
                        new_cwd_detected = stripped[len(_SENTINEL) + 1:].strip()
                    else:
                        filtered_lines.append(line)
                out_stdout = "".join(filtered_lines)

            if proc.returncode == 0 and new_cwd_detected and os.path.isdir(new_cwd_detected):
                # Trust the shell-reported cwd over the regex parser
                new_cwd = new_cwd_detected
            else:
                new_cwd = _resolve_cwd(command, cwd)
            # Never let cwd escape sandbox
            if self._sandbox_root and not os.path.realpath(new_cwd).startswith(self._sandbox_root):
                new_cwd = self._sandbox_root
            self._cwd = new_cwd

            out = out_stdout
            if proc.stderr:
                out += f"\n[stderr]\n{proc.stderr}"
            if proc.returncode != 0:
                out += f"\n[exit code: {proc.returncode}]"
            if len(out) > 15_000:
                out = (
                    out[:6000]
                    + f"\n\n... truncated ({len(out)} chars total) ...\n\n"
                    + out[-3000:]
                )
            return out.strip() or "(no output)"
        except subprocess.TimeoutExpired:
            return f"Error: timed out after {timeout}s"
        except Exception as e:
            return f"Error running command: {e}"


def _check_dangerous(cmd: str) -> str | None:
    for pattern, reason in _DANGEROUS_PATTERNS:
        if re.search(pattern, cmd):
            return reason
    return None


def _resolve_cwd(command: str, current_cwd: str) -> str:
    """Return updated working directory after any cd/Set-Location in command.
    Pure function — no global side effects.
    """
    separators = re.split(r"&&|;", command)
    result = current_cwd
    for part in separators:
        part = part.strip()
        m = re.match(r"(?:cd|Set-Location|sl)\s+(.+)", part, re.IGNORECASE)
        if m:
            target = m.group(1).strip().strip("'\"")
            if target:
                new_dir = os.path.normpath(
                    os.path.join(result, os.path.expanduser(target))
                )
                if os.path.isdir(new_dir):
                    result = new_dir
    return result
