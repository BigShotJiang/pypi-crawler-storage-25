"""Tests for LP and MIP solver wrappers."""

import numpy as np
import pytest

from portfolio_optimizer.lp_solver import check_lp_feasibility, check_mip_feasibility
from portfolio_optimizer.constraints import (
    CardinalityConstraint,
    WeightLimitConstraint,
    BudgetConstraint,
    PositionBoundsConstraint,
    ExclusionConstraint,
)


class TestLPFeasibility:
    """Test continuous LP solver."""

    def test_simple_feasible(self):
        result = check_lp_feasibility(
            n_assets=5,
            weight_limits=[],
            budget=BudgetConstraint(total=1.0),
            position_bounds=PositionBoundsConstraint(min_w=0.0, max_w=1.0),
        )
        assert result["feasible"]
        assert np.isclose(np.sum(result["weights"]), 1.0)

    def test_equal_split(self):
        """5 assets, each exactly 0.20 -> feasible."""
        result = check_lp_feasibility(
            n_assets=5,
            weight_limits=[],
            budget=BudgetConstraint(total=1.0),
            position_bounds=PositionBoundsConstraint(min_w=0.20, max_w=0.20),
        )
        assert result["feasible"]

    def test_impossible_bounds(self):
        """3 assets, max 0.20 each, budget 1.0 -> 3*0.20=0.60 < 1.0."""
        result = check_lp_feasibility(
            n_assets=3,
            weight_limits=[],
            budget=BudgetConstraint(total=1.0),
            position_bounds=PositionBoundsConstraint(min_w=0.0, max_w=0.20),
        )
        assert not result["feasible"]

    def test_sector_limits_feasible(self):
        result = check_lp_feasibility(
            n_assets=6,
            weight_limits=[
                WeightLimitConstraint("tech", [0, 1, 2], max_pct=0.50),
                WeightLimitConstraint("health", [3, 4, 5], max_pct=0.60),
            ],
            budget=BudgetConstraint(total=1.0),
            position_bounds=None,
        )
        assert result["feasible"]
        tech_total = sum(result["weights"][i] for i in [0, 1, 2])
        assert tech_total <= 0.50 + 1e-6

    def test_sector_limits_infeasible(self):
        """Both sectors capped at 0.30 but only 2 sectors -> can't fill 1.0."""
        result = check_lp_feasibility(
            n_assets=6,
            weight_limits=[
                WeightLimitConstraint("tech", [0, 1, 2], max_pct=0.30),
                WeightLimitConstraint("health", [3, 4, 5], max_pct=0.30),
            ],
            budget=BudgetConstraint(total=1.0),
            position_bounds=None,
        )
        assert not result["feasible"]

    def test_no_budget(self):
        """Without budget constraint, just bounds -> always feasible."""
        result = check_lp_feasibility(
            n_assets=3,
            weight_limits=[],
            budget=None,
            position_bounds=PositionBoundsConstraint(min_w=0.0, max_w=0.50),
        )
        assert result["feasible"]

    def test_sector_min_pct(self):
        """Sector minimum: at least 20% in tech."""
        result = check_lp_feasibility(
            n_assets=6,
            weight_limits=[
                WeightLimitConstraint("tech", [0, 1, 2], min_pct=0.20, max_pct=0.60),
            ],
            budget=BudgetConstraint(total=1.0),
            position_bounds=None,
        )
        assert result["feasible"]
        tech_total = sum(result["weights"][i] for i in [0, 1, 2])
        assert tech_total >= 0.20 - 1e-6


class TestMIPFeasibility:
    """Test mixed integer programming solver."""

    def test_simple_mip_feasible(self):
        result = check_mip_feasibility(
            n_assets=10,
            cardinality=CardinalityConstraint(min_assets=3, max_assets=5),
            weight_limits=[],
            budget=BudgetConstraint(total=1.0),
            position_bounds=PositionBoundsConstraint(min_w=0.05, max_w=0.40),
        )
        assert result["feasible"]
        n_selected = np.sum(result["selected"])
        assert 3 <= n_selected <= 5

    def test_mip_exact_5(self):
        """Select exactly 5 out of 10, equal weight."""
        result = check_mip_feasibility(
            n_assets=10,
            cardinality=CardinalityConstraint(min_assets=5, max_assets=5),
            weight_limits=[],
            budget=BudgetConstraint(total=1.0),
            position_bounds=PositionBoundsConstraint(min_w=0.20, max_w=0.20),
        )
        assert result["feasible"]
        assert np.sum(result["selected"]) == 5

    def test_mip_infeasible(self):
        """Select 3-5, max weight 0.10 -> max 0.50 < budget 1.0."""
        result = check_mip_feasibility(
            n_assets=10,
            cardinality=CardinalityConstraint(min_assets=3, max_assets=5),
            weight_limits=[],
            budget=BudgetConstraint(total=1.0),
            position_bounds=PositionBoundsConstraint(min_w=0.01, max_w=0.10),
        )
        assert not result["feasible"]

    def test_mip_with_exclusions(self):
        """Exclusion: assets 0 and 1 can't both be selected."""
        result = check_mip_feasibility(
            n_assets=5,
            cardinality=CardinalityConstraint(min_assets=3, max_assets=3),
            weight_limits=[],
            budget=BudgetConstraint(total=1.0),
            position_bounds=PositionBoundsConstraint(min_w=0.10, max_w=0.50),
            exclusions=[ExclusionConstraint(asset_a=0, asset_b=1)],
        )
        assert result["feasible"]
        # Either 0 or 1 selected, not both
        assert not (result["selected"][0] == 1 and result["selected"][1] == 1)

    def test_mip_with_sector_weight(self):
        """Sector weight limit within MIP."""
        result = check_mip_feasibility(
            n_assets=6,
            cardinality=CardinalityConstraint(min_assets=3, max_assets=4),
            weight_limits=[
                WeightLimitConstraint("tech", [0, 1, 2], max_pct=0.40),
            ],
            budget=BudgetConstraint(total=1.0),
            position_bounds=PositionBoundsConstraint(min_w=0.10, max_w=0.40),
        )
        assert result["feasible"]

    def test_mip_no_cardinality(self):
        """MIP without cardinality (all assets can be selected)."""
        result = check_mip_feasibility(
            n_assets=5,
            cardinality=None,
            weight_limits=[],
            budget=BudgetConstraint(total=1.0),
            position_bounds=PositionBoundsConstraint(min_w=0.0, max_w=0.50),
        )
        assert result["feasible"]


class TestLPWeightValidation:
    """Verify LP solution satisfies all constraints."""

    def test_lp_weights_sum_to_budget(self):
        """Solution weights must sum to budget."""
        result = check_lp_feasibility(
            n_assets=10,
            weight_limits=[
                WeightLimitConstraint("A", [0, 1, 2, 3, 4], max_pct=0.60),
                WeightLimitConstraint("B", [5, 6, 7, 8, 9], max_pct=0.60),
            ],
            budget=BudgetConstraint(total=1.0),
            position_bounds=PositionBoundsConstraint(min_w=0.0, max_w=0.30),
        )
        assert result["feasible"]
        assert np.isclose(np.sum(result["weights"]), 1.0, atol=1e-6)

    def test_lp_weights_within_bounds(self):
        """Each weight must be within [min_w, max_w]."""
        result = check_lp_feasibility(
            n_assets=5,
            weight_limits=[],
            budget=BudgetConstraint(total=1.0),
            position_bounds=PositionBoundsConstraint(min_w=0.05, max_w=0.30),
        )
        assert result["feasible"]
        for w in result["weights"]:
            assert w >= 0.05 - 1e-6
            assert w <= 0.30 + 1e-6

    def test_lp_sector_limit_respected(self):
        """Sector weight must be within limits."""
        result = check_lp_feasibility(
            n_assets=10,
            weight_limits=[
                WeightLimitConstraint("tech", [0, 1, 2], min_pct=0.10, max_pct=0.40),
            ],
            budget=BudgetConstraint(total=1.0),
            position_bounds=None,
        )
        assert result["feasible"]
        tech_weight = sum(result["weights"][i] for i in [0, 1, 2])
        assert tech_weight >= 0.10 - 1e-6
        assert tech_weight <= 0.40 + 1e-6

    def test_lp_many_sectors(self):
        """10 sectors, each 10% max, all cover all assets -> 100% total max."""
        n = 50
        result = check_lp_feasibility(
            n_assets=n,
            weight_limits=[
                WeightLimitConstraint(f"S{i}", list(range(i*5, (i+1)*5)), max_pct=0.10)
                for i in range(10)
            ],
            budget=BudgetConstraint(total=1.0),
            position_bounds=None,
        )
        assert result["feasible"]

    def test_lp_conflicting_sector_min_max(self):
        """Sector A min 60%, Sector B min 60% -> 120% > 100%."""
        result = check_lp_feasibility(
            n_assets=10,
            weight_limits=[
                WeightLimitConstraint("A", [0, 1, 2, 3, 4], min_pct=0.60),
                WeightLimitConstraint("B", [5, 6, 7, 8, 9], min_pct=0.60),
            ],
            budget=BudgetConstraint(total=1.0),
            position_bounds=None,
        )
        assert not result["feasible"]


class TestMIPSolutionValidation:
    """Verify MIP solution satisfies all constraints."""

    def test_mip_selected_count_in_range(self):
        result = check_mip_feasibility(
            n_assets=20,
            cardinality=CardinalityConstraint(min_assets=5, max_assets=8),
            weight_limits=[],
            budget=BudgetConstraint(total=1.0),
            position_bounds=PositionBoundsConstraint(min_w=0.05, max_w=0.30),
        )
        assert result["feasible"]
        n_sel = np.sum(result["selected"])
        assert 5 <= n_sel <= 8

    def test_mip_weights_sum_to_budget(self):
        result = check_mip_feasibility(
            n_assets=10,
            cardinality=CardinalityConstraint(min_assets=4, max_assets=6),
            weight_limits=[],
            budget=BudgetConstraint(total=1.0),
            position_bounds=PositionBoundsConstraint(min_w=0.10, max_w=0.30),
        )
        assert result["feasible"]
        assert np.isclose(np.sum(result["weights"]), 1.0, atol=1e-4)

    def test_mip_unselected_weight_is_zero(self):
        """If z_i=0, then w_i should be 0."""
        result = check_mip_feasibility(
            n_assets=10,
            cardinality=CardinalityConstraint(min_assets=3, max_assets=5),
            weight_limits=[],
            budget=BudgetConstraint(total=1.0),
            position_bounds=PositionBoundsConstraint(min_w=0.10, max_w=0.40),
        )
        assert result["feasible"]
        for i in range(10):
            if result["selected"][i] == 0:
                assert result["weights"][i] < 1e-6, (
                    f"Asset {i} not selected but weight={result['weights'][i]}"
                )

    def test_mip_exclusion_respected(self):
        """Excluded pair should not both be selected."""
        result = check_mip_feasibility(
            n_assets=6,
            cardinality=CardinalityConstraint(min_assets=3, max_assets=4),
            weight_limits=[],
            budget=BudgetConstraint(total=1.0),
            position_bounds=PositionBoundsConstraint(min_w=0.10, max_w=0.50),
            exclusions=[
                ExclusionConstraint(0, 1),
                ExclusionConstraint(2, 3),
            ],
        )
        assert result["feasible"]
        assert not (result["selected"][0] == 1 and result["selected"][1] == 1)
        assert not (result["selected"][2] == 1 and result["selected"][3] == 1)

    def test_mip_sector_weight_respected(self):
        result = check_mip_feasibility(
            n_assets=10,
            cardinality=CardinalityConstraint(min_assets=4, max_assets=6),
            weight_limits=[
                WeightLimitConstraint("tech", [0, 1, 2, 3], max_pct=0.30),
            ],
            budget=BudgetConstraint(total=1.0),
            position_bounds=PositionBoundsConstraint(min_w=0.05, max_w=0.30),
        )
        assert result["feasible"]
        tech_weight = sum(result["weights"][i] for i in [0, 1, 2, 3])
        assert tech_weight <= 0.30 + 1e-4
