"""Robustness tests: numerical precision, large inputs, edge values."""

import numpy as np
import pytest
from portfolio_optimizer import PortfolioChecker
from portfolio_optimizer.lp_solver import check_lp_feasibility, check_mip_feasibility
from portfolio_optimizer.cvar_solver import check_cvar_feasibility
from portfolio_optimizer.constraints import (
    CardinalityConstraint, BudgetConstraint, PositionBoundsConstraint,
    WeightLimitConstraint,
)


class TestNumericalPrecision:
    """Test behavior at numerical boundaries."""

    def test_exact_boundary_lp(self):
        """4 assets * max_w=0.25 = exactly 1.0."""
        result = check_lp_feasibility(
            n_assets=4, weight_limits=[],
            budget=BudgetConstraint(total=1.0),
            position_bounds=PositionBoundsConstraint(min_w=0.25, max_w=0.25),
        )
        assert result["feasible"]

    def test_just_below_boundary_lp(self):
        """4 assets * max_w=0.2499 = 0.9996 < 1.0."""
        result = check_lp_feasibility(
            n_assets=4, weight_limits=[],
            budget=BudgetConstraint(total=1.0),
            position_bounds=PositionBoundsConstraint(min_w=0.2499, max_w=0.2499),
        )
        assert not result["feasible"]

    def test_just_above_boundary_lp(self):
        """4 assets * max_w=0.2501, min_w=0.2501 = 1.0004 > 1.0."""
        result = check_lp_feasibility(
            n_assets=4, weight_limits=[],
            budget=BudgetConstraint(total=1.0),
            position_bounds=PositionBoundsConstraint(min_w=0.2501, max_w=0.2501),
        )
        assert not result["feasible"]

    def test_very_small_weights(self):
        """1000 assets, each max 0.001, budget=1.0 -> exact fit."""
        result = check_lp_feasibility(
            n_assets=1000, weight_limits=[],
            budget=BudgetConstraint(total=1.0),
            position_bounds=PositionBoundsConstraint(min_w=0.001, max_w=0.001),
        )
        assert result["feasible"]

    def test_very_large_budget(self):
        """Budget = 1000.0, many assets."""
        result = check_lp_feasibility(
            n_assets=100, weight_limits=[],
            budget=BudgetConstraint(total=1000.0),
            position_bounds=PositionBoundsConstraint(min_w=0.0, max_w=100.0),
        )
        assert result["feasible"]

    def test_budget_very_close_to_zero(self):
        """Budget = 0.001, tiny weights."""
        result = check_lp_feasibility(
            n_assets=10, weight_limits=[],
            budget=BudgetConstraint(total=0.001),
            position_bounds=PositionBoundsConstraint(min_w=0.0, max_w=0.001),
        )
        assert result["feasible"]


class TestLargeInputs:
    """Test with larger asset universes."""

    def test_200_assets_mip(self):
        """200 assets, select 20, standard bounds."""
        result = check_mip_feasibility(
            n_assets=200,
            cardinality=CardinalityConstraint(min_assets=20, max_assets=20),
            weight_limits=[],
            budget=BudgetConstraint(total=1.0),
            position_bounds=PositionBoundsConstraint(min_w=0.02, max_w=0.08),
        )
        assert result["feasible"]

    def test_500_assets_lp(self):
        """500 assets, budget=1.0, max_w=0.05."""
        result = check_lp_feasibility(
            n_assets=500, weight_limits=[],
            budget=BudgetConstraint(total=1.0),
            position_bounds=PositionBoundsConstraint(min_w=0.0, max_w=0.05),
        )
        assert result["feasible"]

    def test_500_assets_10_sectors(self):
        """500 assets in 10 sectors with limits."""
        wl = [
            WeightLimitConstraint(f"S{i}", list(range(i*50, (i+1)*50)), max_pct=0.20)
            for i in range(10)
        ]
        result = check_lp_feasibility(
            n_assets=500, weight_limits=wl,
            budget=BudgetConstraint(total=1.0),
            position_bounds=PositionBoundsConstraint(min_w=0.0, max_w=0.05),
        )
        assert result["feasible"]

    def test_cvar_300_scenarios(self):
        """CVaR with 300 scenarios, 20 assets."""
        np.random.seed(42)
        returns = np.random.normal(0.02, 0.05, (300, 20))
        result = check_cvar_feasibility(
            n_assets=20, confidence=0.95, max_cvar=0.20, returns=returns,
        )
        assert result["feasible"]


class TestSymmetry:
    """Reordering assets should not change feasibility."""

    def test_lp_permutation_invariant(self):
        """LP result doesn't depend on asset ordering."""
        np.random.seed(42)
        n = 10
        # Original order
        r1 = check_lp_feasibility(
            n_assets=n,
            weight_limits=[WeightLimitConstraint("A", [0, 1, 2], max_pct=0.30)],
            budget=BudgetConstraint(total=1.0),
            position_bounds=PositionBoundsConstraint(min_w=0.0, max_w=0.20),
        )
        # Reversed sector
        r2 = check_lp_feasibility(
            n_assets=n,
            weight_limits=[WeightLimitConstraint("A", [7, 8, 9], max_pct=0.30)],
            budget=BudgetConstraint(total=1.0),
            position_bounds=PositionBoundsConstraint(min_w=0.0, max_w=0.20),
        )
        assert r1["feasible"] == r2["feasible"]

    def test_mip_permutation_invariant(self):
        """MIP with exclusion: swapping asset indices doesn't change result."""
        r1 = check_mip_feasibility(
            n_assets=6,
            cardinality=CardinalityConstraint(min_assets=3, max_assets=3),
            weight_limits=[],
            budget=BudgetConstraint(total=1.0),
            position_bounds=PositionBoundsConstraint(min_w=0.20, max_w=0.40),
            exclusions=[],
        )
        r2 = check_mip_feasibility(
            n_assets=6,
            cardinality=CardinalityConstraint(min_assets=3, max_assets=3),
            weight_limits=[],
            budget=BudgetConstraint(total=1.0),
            position_bounds=PositionBoundsConstraint(min_w=0.20, max_w=0.40),
            exclusions=[],
        )
        assert r1["feasible"] == r2["feasible"]


class TestDegenerateCases:
    """Degenerate and corner cases."""

    def test_zero_budget_zero_bounds(self):
        """Budget=0, bounds=[0,0] -> trivially feasible (all zeros)."""
        result = check_lp_feasibility(
            n_assets=5, weight_limits=[],
            budget=BudgetConstraint(total=0.0),
            position_bounds=PositionBoundsConstraint(min_w=0.0, max_w=0.0),
        )
        assert result["feasible"]

    def test_single_asset_lp(self):
        result = check_lp_feasibility(
            n_assets=1, weight_limits=[],
            budget=BudgetConstraint(total=1.0),
            position_bounds=PositionBoundsConstraint(min_w=1.0, max_w=1.0),
        )
        assert result["feasible"]

    def test_single_asset_mip(self):
        result = check_mip_feasibility(
            n_assets=1,
            cardinality=CardinalityConstraint(min_assets=1, max_assets=1),
            weight_limits=[],
            budget=BudgetConstraint(total=1.0),
            position_bounds=PositionBoundsConstraint(min_w=1.0, max_w=1.0),
        )
        assert result["feasible"]

    def test_all_assets_in_one_sector(self):
        """All assets belong to a single sector."""
        result = check_lp_feasibility(
            n_assets=10,
            weight_limits=[WeightLimitConstraint("all", list(range(10)), max_pct=1.0)],
            budget=BudgetConstraint(total=1.0),
            position_bounds=None,
        )
        assert result["feasible"]

    def test_overlapping_sectors(self):
        """Assets belong to multiple sectors (overlap)."""
        result = check_lp_feasibility(
            n_assets=6,
            weight_limits=[
                WeightLimitConstraint("A", [0, 1, 2, 3], max_pct=0.60),
                WeightLimitConstraint("B", [2, 3, 4, 5], max_pct=0.60),
            ],
            budget=BudgetConstraint(total=1.0),
            position_bounds=None,
        )
        assert result["feasible"]  # Assets 2,3 in both sectors

    def test_min_w_greater_than_max_w(self):
        """min_w > max_w -> infeasible (impossible bounds)."""
        result = check_lp_feasibility(
            n_assets=5, weight_limits=[],
            budget=BudgetConstraint(total=1.0),
            position_bounds=PositionBoundsConstraint(min_w=0.30, max_w=0.10),
        )
        assert not result["feasible"]

    @pytest.mark.parametrize("n", [2, 5, 10, 20, 50])
    def test_equal_weight_always_works(self, n):
        """n assets, each exactly 1/n -> always feasible."""
        w = 1.0 / n
        result = check_lp_feasibility(
            n_assets=n, weight_limits=[],
            budget=BudgetConstraint(total=1.0),
            position_bounds=PositionBoundsConstraint(min_w=w, max_w=w),
        )
        assert result["feasible"]
