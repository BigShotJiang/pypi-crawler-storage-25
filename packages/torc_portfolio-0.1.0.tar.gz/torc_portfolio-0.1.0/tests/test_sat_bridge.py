"""Tests for SAT bridge to torc-sat."""

import pytest

from portfolio_optimizer.sat_bridge import check_sat_feasibility
from portfolio_optimizer.constraints import (
    CardinalityConstraint,
    ExclusionConstraint,
    SectorMinConstraint,
    DiversificationConstraint,
)


class TestSATBridge:
    """Test delegation to torc-sat."""

    def test_no_binary_constraints(self):
        """No binary constraints -> returns None (nothing to check)."""
        result = check_sat_feasibility(
            n_assets=10,
            cardinality=None,
            exclusions=[],
            sector_mins=[],
            diversification=None,
        )
        assert result is None

    def test_cardinality_feasible(self):
        result = check_sat_feasibility(
            n_assets=10,
            cardinality=CardinalityConstraint(min_assets=3, max_assets=7),
            exclusions=[],
            sector_mins=[],
            diversification=None,
        )
        assert result is not None
        assert result.feasible

    def test_cardinality_infeasible(self):
        """min > max -> infeasible (caught by torc-sat)."""
        result = check_sat_feasibility(
            n_assets=10,
            cardinality=CardinalityConstraint(min_assets=8, max_assets=3),
            exclusions=[],
            sector_mins=[],
            diversification=None,
        )
        assert result is not None
        assert not result.feasible

    def test_exclusions_feasible(self):
        result = check_sat_feasibility(
            n_assets=5,
            cardinality=CardinalityConstraint(min_assets=2, max_assets=3),
            exclusions=[ExclusionConstraint(asset_a=0, asset_b=1)],
            sector_mins=[],
            diversification=None,
        )
        assert result is not None
        assert result.feasible

    def test_all_pairs_excluded_infeasible(self):
        """3 assets, all pairs excluded, min 2 -> impossible."""
        result = check_sat_feasibility(
            n_assets=3,
            cardinality=CardinalityConstraint(min_assets=2),
            exclusions=[
                ExclusionConstraint(0, 1),
                ExclusionConstraint(0, 2),
                ExclusionConstraint(1, 2),
            ],
            sector_mins=[],
            diversification=None,
        )
        assert result is not None
        assert not result.feasible

    def test_sector_min_feasible(self):
        result = check_sat_feasibility(
            n_assets=10,
            cardinality=CardinalityConstraint(min_assets=4, max_assets=6),
            exclusions=[],
            sector_mins=[
                SectorMinConstraint("tech", [0, 1, 2, 3], 2),
                SectorMinConstraint("health", [4, 5, 6, 7], 2),
            ],
            diversification=None,
        )
        assert result is not None
        assert result.feasible

    def test_diversification_feasible(self):
        result = check_sat_feasibility(
            n_assets=9,
            cardinality=None,
            exclusions=[],
            sector_mins=[],
            diversification=DiversificationConstraint(sectors={
                "tech": [0, 1, 2],
                "health": [3, 4, 5],
                "energy": [6, 7, 8],
            }),
        )
        assert result is not None
        assert result.feasible

    def test_exclusion_chain_feasible(self):
        """Path exclusions: can pick alternating vertices."""
        result = check_sat_feasibility(
            n_assets=6,
            cardinality=CardinalityConstraint(min_assets=3),
            exclusions=[
                ExclusionConstraint(0, 1),
                ExclusionConstraint(1, 2),
                ExclusionConstraint(2, 3),
                ExclusionConstraint(3, 4),
                ExclusionConstraint(4, 5),
            ],
            sector_mins=[],
            diversification=None,
        )
        assert result is not None
        assert result.feasible  # {0, 2, 4} works

    def test_exclusion_triangle_min2_infeasible(self):
        """Triangle: K3, min 2 -> impossible (can't pick 2 non-adjacent in K3)."""
        result = check_sat_feasibility(
            n_assets=3,
            cardinality=CardinalityConstraint(min_assets=2),
            exclusions=[
                ExclusionConstraint(0, 1),
                ExclusionConstraint(1, 2),
                ExclusionConstraint(0, 2),
            ],
            sector_mins=[],
            diversification=None,
        )
        assert result is not None
        assert not result.feasible

    def test_sector_min_impossible(self):
        """Sector has 2 assets, min 3 -> impossible."""
        result = check_sat_feasibility(
            n_assets=10,
            cardinality=None,
            exclusions=[],
            sector_mins=[SectorMinConstraint("tiny", [0, 1], 3)],
            diversification=None,
        )
        assert result is not None
        assert not result.feasible

    def test_many_sectors_feasible(self):
        """5 sectors, min 1 each, 10 assets -> feasible."""
        result = check_sat_feasibility(
            n_assets=10,
            cardinality=CardinalityConstraint(min_assets=5, max_assets=10),
            exclusions=[],
            sector_mins=[
                SectorMinConstraint(f"S{i}", [i*2, i*2+1], 1) for i in range(5)
            ],
            diversification=None,
        )
        assert result is not None
        assert result.feasible

    def test_infeasible_result_has_suggestion(self):
        """Infeasible result should have non-empty suggestion."""
        result = check_sat_feasibility(
            n_assets=3,
            cardinality=CardinalityConstraint(min_assets=2),
            exclusions=[
                ExclusionConstraint(0, 1),
                ExclusionConstraint(0, 2),
                ExclusionConstraint(1, 2),
            ],
            sector_mins=[],
            diversification=None,
        )
        assert result is not None
        assert not result.feasible
        assert len(result.suggestion) > 0
