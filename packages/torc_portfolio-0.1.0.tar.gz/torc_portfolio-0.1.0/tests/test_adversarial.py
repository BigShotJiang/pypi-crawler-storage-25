"""Adversarial tests: cases specifically designed to trip up LP/MIP solvers.

Targets: numerical instability, degenerate pivots, near-boundary cases,
cycling, and constraint interactions that create hidden infeasibility.
"""

import numpy as np
import pytest
from portfolio_optimizer import PortfolioChecker
from portfolio_optimizer.lp_solver import check_lp_feasibility, check_mip_feasibility
from portfolio_optimizer.cvar_solver import check_cvar_feasibility
from portfolio_optimizer.constraints import (
    CardinalityConstraint, BudgetConstraint, PositionBoundsConstraint,
    WeightLimitConstraint, ExclusionConstraint,
)


class TestNearBoundary:
    """Cases at the exact boundary of feasibility where floating point matters."""

    def test_epsilon_above_critical_max_w(self):
        """max_w = 1/n + epsilon should be feasible."""
        for n in [3, 5, 7, 11, 13, 17, 19, 23]:
            critical = 1.0 / n
            eps = 1e-10
            r = check_lp_feasibility(
                n_assets=n, weight_limits=[],
                budget=BudgetConstraint(total=1.0),
                position_bounds=PositionBoundsConstraint(min_w=0.0, max_w=critical + eps),
            )
            assert r["feasible"], f"n={n}: max_w=1/{n}+1e-10 should be feasible"

    def test_epsilon_below_critical_max_w(self):
        """max_w = 1/n - epsilon should be infeasible (eps > HiGHS tolerance)."""
        for n in [3, 5, 7, 11, 13]:
            critical = 1.0 / n
            eps = 1e-6  # HiGHS tolerance ~1e-7, so 1e-6 is safely above
            r = check_lp_feasibility(
                n_assets=n, weight_limits=[],
                budget=BudgetConstraint(total=1.0),
                position_bounds=PositionBoundsConstraint(min_w=0.0, max_w=critical - eps),
            )
            assert not r["feasible"], f"n={n}: max_w=1/{n}-1e-6 should be infeasible"

    def test_sector_sum_exactly_budget(self):
        """Two sectors sum to exactly 1.0."""
        for pct in [0.50, 0.40, 0.30, 0.25]:
            complement = 1.0 - pct
            r = check_lp_feasibility(
                n_assets=10,
                weight_limits=[
                    WeightLimitConstraint("A", list(range(5)), max_pct=pct),
                    WeightLimitConstraint("B", list(range(5, 10)), max_pct=complement),
                ],
                budget=BudgetConstraint(total=1.0),
                position_bounds=None,
            )
            assert r["feasible"], f"pct={pct}: sectors sum to exactly 1.0"

    def test_sector_sum_epsilon_below(self):
        """Two sectors sum to 1.0 - epsilon. Infeasible if covering."""
        r = check_lp_feasibility(
            n_assets=6,
            weight_limits=[
                WeightLimitConstraint("A", [0, 1, 2], max_pct=0.4999),
                WeightLimitConstraint("B", [3, 4, 5], max_pct=0.5000),
            ],
            budget=BudgetConstraint(total=1.0),
            position_bounds=None,
        )
        assert not r["feasible"]

    def test_min_w_times_n_exactly_budget(self):
        """n * min_w = budget exactly."""
        for n in [2, 3, 4, 5, 7, 10]:
            w = 1.0 / n
            r = check_lp_feasibility(
                n_assets=n, weight_limits=[],
                budget=BudgetConstraint(total=1.0),
                position_bounds=PositionBoundsConstraint(min_w=w, max_w=1.0),
            )
            assert r["feasible"], f"n={n}, min_w=1/{n}: forced equal weights"

    def test_min_w_times_n_epsilon_above(self):
        """n * min_w = budget + epsilon. Infeasible (eps > HiGHS tolerance)."""
        for n in [3, 5, 7, 10]:
            w = 1.0 / n + 1e-6
            r = check_lp_feasibility(
                n_assets=n, weight_limits=[],
                budget=BudgetConstraint(total=1.0),
                position_bounds=PositionBoundsConstraint(min_w=w, max_w=1.0),
            )
            assert not r["feasible"], f"n={n}, min_w=1/{n}+1e-6: forced overweight"


class TestDegeneratePivots:
    """Cases that cause degenerate pivots in simplex method."""

    def test_many_binding_constraints(self):
        """All constraints bind simultaneously -> degenerate vertex."""
        # 4 assets, each exactly 0.25, 1 sector of exactly 0.50
        r = check_lp_feasibility(
            n_assets=4,
            weight_limits=[
                WeightLimitConstraint("A", [0, 1], min_pct=0.50, max_pct=0.50),
                WeightLimitConstraint("B", [2, 3], min_pct=0.50, max_pct=0.50),
            ],
            budget=BudgetConstraint(total=1.0),
            position_bounds=PositionBoundsConstraint(min_w=0.25, max_w=0.25),
        )
        assert r["feasible"]
        if r["feasible"]:
            assert np.allclose(r["weights"], 0.25, atol=1e-6)

    def test_redundant_constraints(self):
        """Many redundant constraints that don't change feasibility."""
        wl = []
        # Add 20 redundant sector constraints that all say "sum <= 1.0"
        for i in range(20):
            assets = list(range(10))
            wl.append(WeightLimitConstraint(f"R{i}", assets, max_pct=1.0))

        r = check_lp_feasibility(
            n_assets=10, weight_limits=wl,
            budget=BudgetConstraint(total=1.0),
            position_bounds=PositionBoundsConstraint(min_w=0.0, max_w=0.20),
        )
        assert r["feasible"]

    def test_conflicting_then_relaxed(self):
        """Sector A min 60% + sector B min 60% -> infeasible.
        But sector A min 50% + B min 50% -> feasible."""
        r_infeasible = check_lp_feasibility(
            n_assets=10,
            weight_limits=[
                WeightLimitConstraint("A", list(range(5)), min_pct=0.60, max_pct=1.0),
                WeightLimitConstraint("B", list(range(5, 10)), min_pct=0.60, max_pct=1.0),
            ],
            budget=BudgetConstraint(total=1.0),
            position_bounds=None,
        )
        assert not r_infeasible["feasible"]

        r_feasible = check_lp_feasibility(
            n_assets=10,
            weight_limits=[
                WeightLimitConstraint("A", list(range(5)), min_pct=0.50, max_pct=1.0),
                WeightLimitConstraint("B", list(range(5, 10)), min_pct=0.50, max_pct=1.0),
            ],
            budget=BudgetConstraint(total=1.0),
            position_bounds=None,
        )
        assert r_feasible["feasible"]


class TestHighDimensional:
    """Large dimensions that test solver scalability."""

    def test_1000_assets_100_sectors(self):
        """1000 assets, 100 sectors of 10 each, max 5% per sector."""
        wl = [
            WeightLimitConstraint(f"S{i}", list(range(i * 10, (i + 1) * 10)), max_pct=0.05)
            for i in range(100)
        ]
        # 100 sectors * 5% = 500%. Budget 100%. Feasible.
        r = check_lp_feasibility(
            n_assets=1000, weight_limits=wl,
            budget=BudgetConstraint(total=1.0),
            position_bounds=PositionBoundsConstraint(min_w=0.0, max_w=0.01),
        )
        assert r["feasible"]

    def test_1000_assets_tight_sectors(self):
        """1000 assets, 100 sectors, tight limits that barely work."""
        wl = [
            WeightLimitConstraint(f"S{i}", list(range(i * 10, (i + 1) * 10)), max_pct=0.011)
            for i in range(100)
        ]
        # 100 * 0.011 = 1.10 >= 1.0. Each asset max 0.005, 1000*0.005=5.0. Feasible.
        r = check_lp_feasibility(
            n_assets=1000, weight_limits=wl,
            budget=BudgetConstraint(total=1.0),
            position_bounds=PositionBoundsConstraint(min_w=0.0, max_w=0.005),
        )
        assert r["feasible"]

    def test_1000_assets_infeasible_sectors(self):
        """1000 assets, 100 sectors max 0.009 each -> 100*0.009=0.9 < 1.0."""
        wl = [
            WeightLimitConstraint(f"S{i}", list(range(i * 10, (i + 1) * 10)), max_pct=0.009)
            for i in range(100)
        ]
        r = check_lp_feasibility(
            n_assets=1000, weight_limits=wl,
            budget=BudgetConstraint(total=1.0),
            position_bounds=None,
        )
        assert not r["feasible"]

    def test_500_assets_mip_loose(self):
        """500 assets, select 20-50, max 10% each."""
        r = check_mip_feasibility(
            n_assets=500,
            cardinality=CardinalityConstraint(min_assets=20, max_assets=50),
            weight_limits=[],
            budget=BudgetConstraint(total=1.0),
            position_bounds=PositionBoundsConstraint(min_w=0.01, max_w=0.10),
        )
        assert r["feasible"]

    def test_cvar_1000_scenarios(self):
        """CVaR with 1000 scenarios, 30 assets."""
        np.random.seed(42)
        returns = np.random.normal(0.01, 0.03, (1000, 30))
        r = check_cvar_feasibility(
            n_assets=30, confidence=0.95, max_cvar=0.10,
            returns=returns, budget_total=1.0, min_w=0.0, max_w=0.10,
        )
        assert r["feasible"]


class TestOverlappingSectors:
    """Sectors with complex overlap patterns."""

    def test_nested_sectors(self):
        """Sector A contains sector B: [0..9] contains [0..4]."""
        r = check_lp_feasibility(
            n_assets=10,
            weight_limits=[
                WeightLimitConstraint("outer", list(range(10)), max_pct=1.0),
                WeightLimitConstraint("inner", list(range(5)), max_pct=0.30),
            ],
            budget=BudgetConstraint(total=1.0),
            position_bounds=None,
        )
        assert r["feasible"]

    def test_nested_sectors_tight(self):
        """Inner must have >= 80%, outer max 70%. Contradiction."""
        r = check_lp_feasibility(
            n_assets=10,
            weight_limits=[
                WeightLimitConstraint("outer", list(range(5)), max_pct=0.70),
                WeightLimitConstraint("inner", list(range(3)), min_pct=0.80, max_pct=1.0),
            ],
            budget=BudgetConstraint(total=1.0),
            position_bounds=None,
        )
        # inner requires >= 80% in [0,1,2], but outer caps [0,1,2,3,4] at 70%.
        # Since [0,1,2] subset of [0,1,2,3,4], this is contradictory.
        assert not r["feasible"]

    def test_chain_of_overlapping_sectors(self):
        """Sectors: [0,1,2], [1,2,3], [2,3,4], [3,4,5] with max 40% each.
        S0 and S3 are disjoint: S0+S3 <= 0.80 < 1.0. Infeasible."""
        wl = [
            WeightLimitConstraint("S0", [0, 1, 2], max_pct=0.40),
            WeightLimitConstraint("S1", [1, 2, 3], max_pct=0.40),
            WeightLimitConstraint("S2", [2, 3, 4], max_pct=0.40),
            WeightLimitConstraint("S3", [3, 4, 5], max_pct=0.40),
        ]
        r = check_lp_feasibility(
            n_assets=6, weight_limits=wl,
            budget=BudgetConstraint(total=1.0),
            position_bounds=None,
        )
        assert not r["feasible"]

    def test_chain_overlapping_feasible(self):
        """Same chain but max 55% each. S0+S3 <= 1.10 >= 1.0. Feasible."""
        wl = [
            WeightLimitConstraint("S0", [0, 1, 2], max_pct=0.55),
            WeightLimitConstraint("S1", [1, 2, 3], max_pct=0.55),
            WeightLimitConstraint("S2", [2, 3, 4], max_pct=0.55),
            WeightLimitConstraint("S3", [3, 4, 5], max_pct=0.55),
        ]
        r = check_lp_feasibility(
            n_assets=6, weight_limits=wl,
            budget=BudgetConstraint(total=1.0),
            position_bounds=None,
        )
        assert r["feasible"]

    def test_all_overlapping(self):
        """Every sector contains all assets -> most restrictive wins."""
        wl = [
            WeightLimitConstraint(f"S{i}", list(range(10)), max_pct=(0.90 + 0.01 * i))
            for i in range(5)
        ]
        # S0 has max_pct=0.90, which is the tightest.
        # But all sectors cover all assets, so it's like max_pct=0.90 for the whole portfolio.
        # Budget=1.0 > 0.90 for a single constraint on all assets => infeasible
        r = check_lp_feasibility(
            n_assets=10, weight_limits=wl,
            budget=BudgetConstraint(total=1.0),
            position_bounds=None,
        )
        assert not r["feasible"]


class TestExtremeCoefficients:
    """Very large or very small numbers that stress numerical precision."""

    def test_very_large_budget(self):
        """Budget = 1e6."""
        r = check_lp_feasibility(
            n_assets=10, weight_limits=[],
            budget=BudgetConstraint(total=1e6),
            position_bounds=PositionBoundsConstraint(min_w=0.0, max_w=1e6),
        )
        assert r["feasible"]

    def test_very_small_budget(self):
        """Budget = 1e-6."""
        r = check_lp_feasibility(
            n_assets=10, weight_limits=[],
            budget=BudgetConstraint(total=1e-6),
            position_bounds=PositionBoundsConstraint(min_w=0.0, max_w=1e-6),
        )
        assert r["feasible"]

    def test_mixed_scale_sectors(self):
        """One sector huge, another micro. Sum = 1.0 exact, feasible."""
        r = check_lp_feasibility(
            n_assets=6,
            weight_limits=[
                WeightLimitConstraint("big", [0, 1, 2], max_pct=0.999999),
                WeightLimitConstraint("small", [3, 4, 5], max_pct=0.000001),
            ],
            budget=BudgetConstraint(total=1.0),
            position_bounds=None,
        )
        assert r["feasible"]  # 0.999999 + 0.000001 = 1.0

    def test_mixed_scale_sectors_infeasible(self):
        """Micro sectors that genuinely can't reach budget."""
        r = check_lp_feasibility(
            n_assets=6,
            weight_limits=[
                WeightLimitConstraint("A", [0, 1, 2], max_pct=0.49),
                WeightLimitConstraint("B", [3, 4, 5], max_pct=0.49),
            ],
            budget=BudgetConstraint(total=1.0),
            position_bounds=None,
        )
        assert not r["feasible"]  # 0.49 + 0.49 = 0.98 < 1.0

    def test_cvar_extreme_returns(self):
        """Returns range from -100% to +1000%."""
        np.random.seed(42)
        n, S = 5, 100
        returns = np.zeros((S, n))
        returns[:90] = np.random.normal(0.10, 0.05, (90, n))  # normal scenarios
        returns[90:] = np.random.uniform(-1.0, 10.0, (10, n))  # extreme scenarios

        r = check_cvar_feasibility(
            n_assets=n, confidence=0.95, max_cvar=2.0,
            returns=returns, budget_total=1.0, min_w=0.0, max_w=1.0,
        )
        assert r["feasible"]


class TestHiddenInfeasibility:
    """Cases where infeasibility is not obvious from any single constraint."""

    def test_three_sector_impossibility(self):
        """3 disjoint sectors each needing >= 35% -> 3*35% = 105% > 100%."""
        r = check_lp_feasibility(
            n_assets=9,
            weight_limits=[
                WeightLimitConstraint("A", [0, 1, 2], min_pct=0.35, max_pct=1.0),
                WeightLimitConstraint("B", [3, 4, 5], min_pct=0.35, max_pct=1.0),
                WeightLimitConstraint("C", [6, 7, 8], min_pct=0.35, max_pct=1.0),
            ],
            budget=BudgetConstraint(total=1.0),
            position_bounds=None,
        )
        assert not r["feasible"]

    def test_four_sector_barely_feasible(self):
        """4 disjoint sectors each needing >= 25% -> 4*25% = 100%. Exact."""
        r = check_lp_feasibility(
            n_assets=12,
            weight_limits=[
                WeightLimitConstraint("A", [0, 1, 2], min_pct=0.25, max_pct=1.0),
                WeightLimitConstraint("B", [3, 4, 5], min_pct=0.25, max_pct=1.0),
                WeightLimitConstraint("C", [6, 7, 8], min_pct=0.25, max_pct=1.0),
                WeightLimitConstraint("D", [9, 10, 11], min_pct=0.25, max_pct=1.0),
            ],
            budget=BudgetConstraint(total=1.0),
            position_bounds=None,
        )
        assert r["feasible"]

    def test_position_bounds_vs_sector_interaction(self):
        """max_w=0.10, 3 assets in sector, sector min 40%.
        3*0.10=0.30 < 0.40 -> infeasible."""
        r = check_lp_feasibility(
            n_assets=10,
            weight_limits=[
                WeightLimitConstraint("tech", [0, 1, 2], min_pct=0.40, max_pct=1.0),
            ],
            budget=BudgetConstraint(total=1.0),
            position_bounds=PositionBoundsConstraint(min_w=0.0, max_w=0.10),
        )
        assert not r["feasible"]

    def test_min_max_squeeze(self):
        """Sector A min 60%, Sector B min 60%. A and B share asset 5.
        Even with overlap, A_only + B_only + shared must sum to 100%."""
        # A = [0..5], B = [5..10]. Shared = {5}.
        # A requires >= 60% in [0..5], B requires >= 60% in [5..10].
        # Assets [0..4] contribute to A only, asset 5 to both, [6..10] to B only.
        # Let x = w(0)+...+w(4), y = w(5), z = w(6)+...+w(9)
        # Budget: x + y + z = 1.0
        # A: x + y >= 0.60
        # B: y + z >= 0.60
        # Sum: x + 2y + z >= 1.20  =>  1.0 + y >= 1.20  =>  y >= 0.20
        # Possible: x=0.40, y=0.20, z=0.40. Check: A=0.60, B=0.60.
        r = check_lp_feasibility(
            n_assets=10,
            weight_limits=[
                WeightLimitConstraint("A", list(range(6)), min_pct=0.60, max_pct=1.0),
                WeightLimitConstraint("B", list(range(5, 10)), min_pct=0.60, max_pct=1.0),
            ],
            budget=BudgetConstraint(total=1.0),
            position_bounds=None,
        )
        assert r["feasible"]

    def test_min_max_squeeze_impossible(self):
        """Same as above but min raised to 55% each for disjoint sectors.
        0.55 + 0.55 = 1.10 > 1.0 -> infeasible."""
        r = check_lp_feasibility(
            n_assets=10,
            weight_limits=[
                WeightLimitConstraint("A", list(range(5)), min_pct=0.55, max_pct=1.0),
                WeightLimitConstraint("B", list(range(5, 10)), min_pct=0.55, max_pct=1.0),
            ],
            budget=BudgetConstraint(total=1.0),
            position_bounds=None,
        )
        assert not r["feasible"]


class TestMIPSpecific:
    """Adversarial MIP-specific tests."""

    def test_exclusion_ring(self):
        """Ring of exclusions: 0-1, 1-2, ..., (n-1)-0.
        With n=5, max independent set = 2. Select 2: feasible."""
        n = 5
        excl = [ExclusionConstraint(i, (i + 1) % n) for i in range(n)]
        r = check_mip_feasibility(
            n_assets=n,
            cardinality=CardinalityConstraint(min_assets=2, max_assets=2),
            weight_limits=[],
            budget=BudgetConstraint(total=1.0),
            position_bounds=PositionBoundsConstraint(min_w=0.30, max_w=0.70),
            exclusions=excl,
        )
        assert r["feasible"]  # e.g., pick {0, 2}

    def test_exclusion_ring_too_many(self):
        """Ring n=5, need 3. Max independent set in C5 = 2. Infeasible."""
        n = 5
        excl = [ExclusionConstraint(i, (i + 1) % n) for i in range(n)]
        r = check_mip_feasibility(
            n_assets=n,
            cardinality=CardinalityConstraint(min_assets=3, max_assets=3),
            weight_limits=[],
            budget=BudgetConstraint(total=1.0),
            position_bounds=PositionBoundsConstraint(min_w=0.20, max_w=0.40),
            exclusions=excl,
        )
        assert not r["feasible"]

    def test_bipartite_exclusion(self):
        """Complete bipartite K_{3,3}: every asset in {0,1,2} excludes every in {3,4,5}.
        Select 3: must pick all from one side."""
        excl = [
            ExclusionConstraint(i, j)
            for i in range(3) for j in range(3, 6)
        ]
        r = check_mip_feasibility(
            n_assets=6,
            cardinality=CardinalityConstraint(min_assets=3, max_assets=3),
            weight_limits=[],
            budget=BudgetConstraint(total=1.0),
            position_bounds=PositionBoundsConstraint(min_w=0.20, max_w=0.40),
            exclusions=excl,
        )
        assert r["feasible"]  # pick {0,1,2} or {3,4,5}

    def test_bipartite_plus_sector_impossible(self):
        """K_{3,3} exclusion + must have >=2 from each side -> impossible."""
        excl = [
            ExclusionConstraint(i, j)
            for i in range(3) for j in range(3, 6)
        ]
        pc = PortfolioChecker(n_assets=6)
        pc.add_cardinality(min_assets=4, max_assets=4)
        for e in excl:
            pc.add_exclusion(e.asset_a, e.asset_b)
        pc.add_sector_min("left", assets=[0, 1, 2], min_count=2)
        pc.add_sector_min("right", assets=[3, 4, 5], min_count=2)
        result = pc.check_feasibility()
        # Need 2 from {0,1,2} and 2 from {3,4,5}, but K_{3,3} says can't mix
        assert not result.feasible

    def test_cardinality_range_sweep(self):
        """For n=10, max_w=0.20: need at least ceil(1/0.20)=5 assets.
        Sweep cardinality from 1 to 10."""
        results = []
        for k in range(1, 11):
            r = check_mip_feasibility(
                n_assets=10,
                cardinality=CardinalityConstraint(min_assets=k, max_assets=k),
                weight_limits=[],
                budget=BudgetConstraint(total=1.0),
                position_bounds=PositionBoundsConstraint(min_w=0.0, max_w=0.20),
            )
            results.append(r["feasible"])

        # k=1..4: infeasible (k*0.20 < 1.0)
        # k=5..10: feasible (k*0.20 >= 1.0)
        assert results == [False, False, False, False, True, True, True, True, True, True]

    def test_min_w_forces_exact_cardinality(self):
        """min_w=0.20, max_w=0.25, budget=1.0.
        k=4: 4*0.25=1.0 and 4*0.20=0.80 -> feasible.
        k=5: 5*0.20=1.0 and 5*0.25=1.25 -> feasible (at min_w=0.20).
        k=6: 6*0.20=1.20 > 1.0 -> infeasible."""
        for k, expected in [(3, False), (4, True), (5, True), (6, False)]:
            r = check_mip_feasibility(
                n_assets=10,
                cardinality=CardinalityConstraint(min_assets=k, max_assets=k),
                weight_limits=[],
                budget=BudgetConstraint(total=1.0),
                position_bounds=PositionBoundsConstraint(min_w=0.20, max_w=0.25),
            )
            assert r["feasible"] == expected, f"k={k}: expected {expected}, got {r['feasible']}"
