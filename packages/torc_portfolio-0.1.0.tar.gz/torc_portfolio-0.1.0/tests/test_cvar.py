"""Tests for CVaR linearization solver."""

import numpy as np
import pytest

from portfolio_optimizer.cvar_solver import check_cvar_feasibility


class TestCVaRFeasibility:
    """Test CVaR constraint checking."""

    def test_positive_returns_feasible(self):
        """All positive returns -> CVaR is negative -> easily feasible."""
        np.random.seed(42)
        n_assets = 5
        S = 30
        returns = np.random.normal(0.10, 0.01, (S, n_assets))

        result = check_cvar_feasibility(
            n_assets=n_assets,
            confidence=0.95,
            max_cvar=0.05,
            returns=returns,
        )
        assert result["feasible"]
        assert result["weights"] is not None
        assert np.isclose(np.sum(result["weights"]), 1.0)

    def test_very_negative_returns_infeasible(self):
        """All very negative returns with tight max_cvar -> infeasible."""
        np.random.seed(42)
        n_assets = 5
        S = 30
        returns = np.random.normal(-1.0, 0.05, (S, n_assets))

        result = check_cvar_feasibility(
            n_assets=n_assets,
            confidence=0.95,
            max_cvar=0.01,
            returns=returns,
        )
        assert not result["feasible"]

    def test_mixed_returns_tight(self):
        """Mixed returns: check that tightening max_cvar makes it infeasible."""
        np.random.seed(99)
        n_assets = 5
        S = 50
        returns = np.random.normal(0.0, 0.20, (S, n_assets))

        # Loose limit: feasible
        result_loose = check_cvar_feasibility(
            n_assets=n_assets,
            confidence=0.95,
            max_cvar=1.0,
            returns=returns,
        )
        assert result_loose["feasible"]

        # Very tight limit: infeasible (can't avoid all risk)
        result_tight = check_cvar_feasibility(
            n_assets=n_assets,
            confidence=0.99,
            max_cvar=0.001,
            returns=returns,
        )
        assert not result_tight["feasible"]

    def test_single_asset(self):
        """Single asset: CVaR is just the expected tail loss."""
        np.random.seed(42)
        S = 100
        returns = np.random.normal(0.05, 0.02, (S, 1))

        result = check_cvar_feasibility(
            n_assets=1,
            confidence=0.95,
            max_cvar=0.10,
            returns=returns,
        )
        assert result["feasible"]
        assert np.isclose(result["weights"][0], 1.0)

    def test_with_position_bounds(self):
        """Position bounds affect CVaR feasibility."""
        np.random.seed(42)
        n_assets = 3
        S = 50
        # Asset 0 is very risky, assets 1-2 are safe
        returns = np.column_stack([
            np.random.normal(-0.50, 0.30, S),  # very risky
            np.random.normal(0.10, 0.01, S),    # safe
            np.random.normal(0.10, 0.01, S),    # safe
        ])

        # With min_w=0.0 (can avoid risky asset): feasible
        result = check_cvar_feasibility(
            n_assets=n_assets,
            confidence=0.95,
            max_cvar=0.05,
            returns=returns,
            min_w=0.0,
            max_w=1.0,
        )
        assert result["feasible"]
        # Should allocate little to asset 0
        assert result["weights"][0] < 0.1

    def test_budget_different_from_one(self):
        """Budget = 0.5 (partial allocation)."""
        np.random.seed(42)
        n_assets = 3
        S = 30
        returns = np.random.normal(0.05, 0.01, (S, n_assets))

        result = check_cvar_feasibility(
            n_assets=n_assets,
            confidence=0.95,
            max_cvar=0.10,
            returns=returns,
            budget_total=0.5,
        )
        assert result["feasible"]
        assert np.isclose(np.sum(result["weights"]), 0.5)

    def test_deterministic_scenarios(self):
        """Known scenarios: 3 assets, 4 scenarios, exact CVaR calculation."""
        returns = np.array([
            [0.10, 0.10, 0.10],   # good
            [0.05, 0.05, 0.05],   # ok
            [-0.10, -0.10, -0.10], # bad
            [-0.20, -0.20, -0.20], # very bad
        ])

        # With max_cvar=0.50, should be feasible (worst case is -0.20)
        result = check_cvar_feasibility(
            n_assets=3,
            confidence=0.50,
            max_cvar=0.50,
            returns=returns,
        )
        assert result["feasible"]


class TestCVaRMathematical:
    """Verify CVaR values against manual calculation."""

    def test_equal_weight_known_cvar(self):
        """Equal weight portfolio with known returns: verify CVaR value.

        4 scenarios, equal weight w=[1/3, 1/3, 1/3]:
        Portfolio returns: [0.10, 0.05, -0.10, -0.20]
        Losses: [-0.10, -0.05, 0.10, 0.20]

        CVaR at 75% = average of worst 25% of losses
        = average of worst 1 scenario = 0.20
        """
        returns = np.array([
            [0.10, 0.10, 0.10],
            [0.05, 0.05, 0.05],
            [-0.10, -0.10, -0.10],
            [-0.20, -0.20, -0.20],
        ])

        # max_cvar=0.20 should be exactly borderline feasible at 75%
        result = check_cvar_feasibility(
            n_assets=3,
            confidence=0.75,
            max_cvar=0.21,  # slightly above the theoretical CVaR
            returns=returns,
        )
        assert result["feasible"]

        # max_cvar=0.15 should be infeasible (all assets have same returns)
        result_tight = check_cvar_feasibility(
            n_assets=3,
            confidence=0.75,
            max_cvar=0.15,
            returns=returns,
        )
        assert not result_tight["feasible"]

    def test_diversification_reduces_cvar(self):
        """Two uncorrelated assets: portfolio CVaR < individual CVaR."""
        np.random.seed(42)
        S = 200
        # Asset 0: positive mean, moderate risk
        # Asset 1: positive mean, moderate risk (independent)
        r0 = np.random.normal(0.02, 0.10, S)
        r1 = np.random.normal(0.02, 0.10, S)
        returns = np.column_stack([r0, r1])

        # Single asset CVaR at 95%: compute manually
        losses_0 = -r0
        sorted_losses = np.sort(losses_0)
        n_tail = max(1, int(np.ceil(S * 0.05)))
        cvar_single = np.mean(sorted_losses[-n_tail:])

        # Portfolio should be feasible at single-asset CVaR (diversification helps)
        result = check_cvar_feasibility(
            n_assets=2,
            confidence=0.95,
            max_cvar=cvar_single,
            returns=returns,
        )
        assert result["feasible"]

    def test_all_identical_assets(self):
        """All assets have identical returns: diversification gives nothing."""
        np.random.seed(42)
        S = 100
        r = np.random.normal(0.01, 0.05, S)
        returns = np.column_stack([r, r, r])  # 3 identical assets

        # CVaR should be the same regardless of allocation
        losses = -r
        sorted_losses = np.sort(losses)
        n_tail = max(1, int(np.ceil(S * 0.05)))
        cvar_true = np.mean(sorted_losses[-n_tail:])

        # Feasible at true CVaR + small margin
        result = check_cvar_feasibility(
            n_assets=3,
            confidence=0.95,
            max_cvar=cvar_true + 0.01,
            returns=returns,
        )
        assert result["feasible"]

        # Infeasible below true CVaR
        result_tight = check_cvar_feasibility(
            n_assets=3,
            confidence=0.95,
            max_cvar=cvar_true - 0.01,
            returns=returns,
        )
        assert not result_tight["feasible"]

    def test_safe_asset_absorbs_risk(self):
        """One risk-free asset (all returns = 0.05): can always achieve low CVaR."""
        np.random.seed(42)
        S = 50
        returns = np.column_stack([
            np.random.normal(-0.50, 0.30, S),  # very risky
            np.full(S, 0.05),                    # risk-free
        ])

        # Allocating 100% to risk-free: CVaR = -0.05 (negative = no risk)
        result = check_cvar_feasibility(
            n_assets=2,
            confidence=0.95,
            max_cvar=0.01,
            returns=returns,
            min_w=0.0,
            max_w=1.0,
        )
        assert result["feasible"]
        # Should put most weight on safe asset
        assert result["weights"][1] > 0.9

    def test_forced_risky_allocation(self):
        """min_w=0.30 forces 30% into risky asset."""
        np.random.seed(42)
        S = 50
        returns = np.column_stack([
            np.random.normal(-0.80, 0.10, S),  # extremely risky
            np.full(S, 0.05),                    # risk-free
        ])

        # With min_w=0.30, must hold 30% of risky asset
        # CVaR should be high -> tight limit infeasible
        result = check_cvar_feasibility(
            n_assets=2,
            confidence=0.95,
            max_cvar=0.01,
            returns=returns,
            min_w=0.30,
            max_w=0.70,
        )
        assert not result["feasible"]


class TestCVaREdgeCases:
    """Edge cases for CVaR solver."""

    def test_two_scenarios(self):
        """Minimum: 2 scenarios."""
        returns = np.array([
            [0.10, 0.10],
            [-0.10, -0.10],
        ])
        result = check_cvar_feasibility(
            n_assets=2, confidence=0.50, max_cvar=0.50, returns=returns,
        )
        assert result["feasible"]

    def test_many_scenarios(self):
        """500 scenarios, 10 assets."""
        np.random.seed(42)
        returns = np.random.normal(0.02, 0.05, (500, 10))
        result = check_cvar_feasibility(
            n_assets=10, confidence=0.95, max_cvar=0.20, returns=returns,
        )
        assert result["feasible"]

    def test_confidence_50(self):
        """Low confidence: CVaR at 50% = median loss."""
        np.random.seed(42)
        returns = np.random.normal(0.0, 0.10, (100, 3))
        result = check_cvar_feasibility(
            n_assets=3, confidence=0.50, max_cvar=0.30, returns=returns,
        )
        assert result["feasible"]

    def test_confidence_99(self):
        """High confidence: CVaR at 99% = avg of worst 1%."""
        np.random.seed(42)
        returns = np.random.normal(0.0, 0.10, (100, 3))
        # Very tight at 99% confidence
        result = check_cvar_feasibility(
            n_assets=3, confidence=0.99, max_cvar=0.50, returns=returns,
        )
        assert result["feasible"]
