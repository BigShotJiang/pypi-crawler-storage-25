"""Formal certification tests: verify mathematical correctness of every result.

For FEASIBLE results: the solution vector must satisfy ALL constraints exactly.
For INFEASIBLE results on small instances: exhaustive search confirms no solution exists.
For CVaR: verify the returned CVaR value matches independent calculation.

These tests serve as formal certificates — each one proves the solver is correct
on that specific instance. Gurobi doesn't do this; it just says feasible/infeasible.
"""

import itertools
import numpy as np
import pytest
from scipy.optimize import linprog

from portfolio_optimizer import PortfolioChecker
from portfolio_optimizer.lp_solver import check_lp_feasibility, check_mip_feasibility
from portfolio_optimizer.cvar_solver import check_cvar_feasibility
from portfolio_optimizer.constraints import (
    CardinalityConstraint, BudgetConstraint, PositionBoundsConstraint,
    WeightLimitConstraint, ExclusionConstraint,
)


class TestFeasibleCertificateMIP:
    """For every feasible MIP result, the solution is a valid CERTIFICATE.
    We verify ALL constraints independently."""

    @pytest.mark.parametrize("seed", range(100))
    def test_mip_certificate(self, seed):
        """Generate random MIP, if feasible verify solution is a valid certificate."""
        rng = np.random.RandomState(seed)
        n = rng.randint(3, 20)
        max_sel = rng.randint(1, n + 1)
        min_sel = rng.randint(1, max_sel + 1)
        min_w = round(rng.uniform(0.0, 0.15), 3)
        max_w = round(rng.uniform(max(min_w + 0.02, 0.10), min(0.80, 1.0)), 3)

        # Random sectors (0-3)
        n_sec = rng.randint(0, 4)
        wl = []
        for s in range(n_sec):
            sec_size = rng.randint(1, min(n, 8))
            assets = sorted(rng.choice(n, size=sec_size, replace=False).tolist())
            mn = round(rng.uniform(0.0, 0.20), 2)
            mx = round(rng.uniform(max(mn, 0.20), 0.80), 2)
            wl.append(WeightLimitConstraint(f"S{s}", assets, min_pct=mn, max_pct=mx))

        # Random exclusions (0-3)
        all_pairs = [(i, j) for i in range(n) for j in range(i + 1, n)]
        n_excl = rng.randint(0, min(4, len(all_pairs) + 1))
        excl_idx = rng.choice(len(all_pairs), size=n_excl, replace=False) if n_excl > 0 else []
        excl = [all_pairs[i] for i in excl_idx]

        r = check_mip_feasibility(
            n_assets=n,
            cardinality=CardinalityConstraint(min_assets=min_sel, max_assets=max_sel),
            weight_limits=wl,
            budget=BudgetConstraint(total=1.0),
            position_bounds=PositionBoundsConstraint(min_w=min_w, max_w=max_w),
            exclusions=[ExclusionConstraint(a, b) for a, b in excl],
        )
        if not r["feasible"]:
            return  # Nothing to certify

        w = r["weights"]
        z = r["selected"]
        TOL = 1e-4

        # 1. Budget
        assert abs(np.sum(w) - 1.0) < TOL, f"[seed={seed}] Budget: sum={np.sum(w)}"

        # 2. Cardinality
        n_sel = int(np.sum(z))
        assert min_sel <= n_sel <= max_sel, (
            f"[seed={seed}] Cardinality: {n_sel} not in [{min_sel},{max_sel}]"
        )

        # 3. Position bounds + linking
        for i in range(n):
            if z[i] == 1:
                assert w[i] >= min_w - TOL, f"[seed={seed}] w[{i}]={w[i]} < min_w={min_w}"
                assert w[i] <= max_w + TOL, f"[seed={seed}] w[{i}]={w[i]} > max_w={max_w}"
            else:
                assert abs(w[i]) < TOL, f"[seed={seed}] w[{i}]={w[i]} but z[{i}]=0"

        # 4. Weight limits (sectors)
        for wlc in wl:
            sector_sum = sum(w[a] for a in wlc.assets if 0 <= a < n)
            assert sector_sum >= wlc.min_pct - TOL, (
                f"[seed={seed}] Sector {wlc.sector}: sum={sector_sum:.6f} < min_pct={wlc.min_pct}"
            )
            assert sector_sum <= wlc.max_pct + TOL, (
                f"[seed={seed}] Sector {wlc.sector}: sum={sector_sum:.6f} > max_pct={wlc.max_pct}"
            )

        # 5. Exclusions
        for a, b in excl:
            assert not (z[a] == 1 and z[b] == 1), (
                f"[seed={seed}] Exclusion ({a},{b}) violated"
            )


class TestFeasibleCertificateLP:
    """For every feasible LP result, verify solution certificate."""

    @pytest.mark.parametrize("seed", range(100))
    def test_lp_certificate(self, seed):
        """Generate random LP, verify solution."""
        rng = np.random.RandomState(2000 + seed)
        n = rng.randint(2, 50)
        min_w = round(rng.uniform(0.0, 0.05), 3)
        max_w = round(rng.uniform(max(min_w + 0.01, 0.05), 1.0), 3)

        n_sec = rng.randint(0, 5)
        wl = []
        for s in range(n_sec):
            sec_size = rng.randint(1, min(n, 15))
            assets = sorted(rng.choice(n, size=sec_size, replace=False).tolist())
            mx = round(rng.uniform(0.10, 0.90), 2)
            wl.append(WeightLimitConstraint(f"S{s}", assets, max_pct=mx))

        r = check_lp_feasibility(
            n_assets=n, weight_limits=wl,
            budget=BudgetConstraint(total=1.0),
            position_bounds=PositionBoundsConstraint(min_w=min_w, max_w=max_w),
        )
        if not r["feasible"]:
            return

        w = r["weights"]
        TOL = 1e-6

        # Budget
        assert abs(np.sum(w) - 1.0) < TOL, f"[seed={seed}] Budget: {np.sum(w)}"

        # Bounds
        for i in range(n):
            assert w[i] >= min_w - TOL, f"[seed={seed}] w[{i}]={w[i]} < {min_w}"
            assert w[i] <= max_w + TOL, f"[seed={seed}] w[{i}]={w[i]} > {max_w}"

        # Sectors
        for wlc in wl:
            s = sum(w[a] for a in wlc.assets if 0 <= a < n)
            assert s <= wlc.max_pct + TOL, (
                f"[seed={seed}] Sector {wlc.sector}: {s:.6f} > {wlc.max_pct}"
            )


class TestInfeasibleCertificateSmall:
    """For INFEASIBLE results on small n, verify by exhaustive enumeration
    that NO solution exists."""

    @pytest.mark.parametrize("seed", range(30))
    def test_infeasible_verified_exhaustive(self, seed):
        """If MIP says infeasible on n<=7, brute force confirms."""
        rng = np.random.RandomState(3000 + seed)
        n = rng.randint(3, 8)
        max_sel = rng.randint(1, n + 1)
        min_sel = rng.randint(1, max_sel + 1)
        min_w = round(rng.uniform(0.05, 0.30), 2)
        max_w = round(rng.uniform(min_w, min(0.60, 1.0)), 2)

        r = check_mip_feasibility(
            n_assets=n,
            cardinality=CardinalityConstraint(min_assets=min_sel, max_assets=max_sel),
            weight_limits=[],
            budget=BudgetConstraint(total=1.0),
            position_bounds=PositionBoundsConstraint(min_w=min_w, max_w=max_w),
        )
        if r["feasible"]:
            return  # Only certify infeasible results here

        # Brute force: try every subset of appropriate size
        for k in range(min_sel, max_sel + 1):
            for subset in itertools.combinations(range(n), k):
                m = len(subset)
                c_obj = np.zeros(m)
                A_eq = [np.ones(m)]
                b_eq = [1.0]
                bounds = [(min_w, max_w)] * m

                result = linprog(
                    c_obj, A_eq=np.array(A_eq), b_eq=np.array(b_eq),
                    bounds=bounds, method="highs",
                )
                assert not result.success, (
                    f"[seed={seed}] MIP says infeasible but brute force found "
                    f"feasible subset {subset} with n={n}, sel=[{min_sel},{max_sel}], "
                    f"w=[{min_w},{max_w}]"
                )


class TestCVaRCertificate:
    """Verify CVaR solutions match independent calculation."""

    @pytest.mark.parametrize("seed", range(30))
    def test_cvar_solution_satisfies_constraint(self, seed):
        """For feasible CVaR, verify the actual CVaR <= max_cvar."""
        rng = np.random.RandomState(4000 + seed)
        n = rng.randint(3, 15)
        S = rng.randint(30, 200)
        returns = rng.normal(0.02, 0.08, (S, n))
        confidence = round(rng.uniform(0.90, 0.99), 2)
        max_cvar = round(rng.uniform(0.05, 0.50), 2)

        r = check_cvar_feasibility(
            n_assets=n, confidence=confidence, max_cvar=max_cvar,
            returns=returns, budget_total=1.0, min_w=0.0, max_w=1.0,
        )
        if not r["feasible"]:
            return

        w = r["weights"]
        TOL = 1e-4

        # Budget
        assert abs(np.sum(w) - 1.0) < TOL

        # Compute empirical CVaR independently
        portfolio_returns = returns @ w
        losses = -portfolio_returns
        var_level = np.quantile(losses, confidence)
        tail = losses[losses >= var_level - TOL]
        if len(tail) > 0:
            cvar_empirical = np.mean(tail)
        else:
            cvar_empirical = var_level

        # The LP CVaR (r["cvar"]) should be <= max_cvar
        assert r["cvar"] <= max_cvar + TOL, (
            f"[seed={seed}] CVaR={r['cvar']:.6f} > max_cvar={max_cvar}"
        )

    @pytest.mark.parametrize("seed", range(20))
    def test_cvar_weights_are_valid(self, seed):
        """CVaR solution weights must satisfy bounds."""
        rng = np.random.RandomState(5000 + seed)
        n = rng.randint(3, 10)
        S = 50
        returns = rng.normal(0.01, 0.05, (S, n))
        min_w = round(rng.uniform(0.0, 0.05), 3)
        max_w = round(rng.uniform(max(min_w + 0.05, 0.10), 1.0), 3)

        r = check_cvar_feasibility(
            n_assets=n, confidence=0.95, max_cvar=0.30,
            returns=returns, budget_total=1.0, min_w=min_w, max_w=max_w,
        )
        if not r["feasible"]:
            return

        w = r["weights"]
        for i in range(n):
            assert w[i] >= min_w - 1e-6, f"[seed={seed}] w[{i}]={w[i]} < min_w={min_w}"
            assert w[i] <= max_w + 1e-6, f"[seed={seed}] w[{i}]={w[i]} > max_w={max_w}"


class TestCheckerEndToEnd:
    """Full pipeline certification: PortfolioChecker end-to-end."""

    @pytest.mark.parametrize("seed", range(50))
    def test_checker_consistent_with_direct_solver(self, seed):
        """PortfolioChecker result must match direct solver call."""
        rng = np.random.RandomState(6000 + seed)
        n = rng.randint(3, 20)

        # Decide constraint type
        has_binary = rng.random() < 0.5
        has_weight = rng.random() < 0.7

        pc = PortfolioChecker(n_assets=n)
        mip_kwargs = {
            "n_assets": n,
            "cardinality": None,
            "weight_limits": [],
            "budget": None,
            "position_bounds": None,
            "exclusions": [],
        }

        if has_binary:
            max_sel = rng.randint(1, n + 1)
            min_sel = rng.randint(1, max_sel + 1)
            pc.add_cardinality(min_assets=min_sel, max_assets=max_sel)
            mip_kwargs["cardinality"] = CardinalityConstraint(min_sel, max_sel)

        if has_weight:
            min_w = round(rng.uniform(0.0, 0.10), 2)
            max_w = round(rng.uniform(max(min_w + 0.05, 0.10), 0.80), 2)
            pc.add_budget(total=1.0)
            pc.add_position_bounds(min_w=min_w, max_w=max_w)
            mip_kwargs["budget"] = BudgetConstraint(total=1.0)
            mip_kwargs["position_bounds"] = PositionBoundsConstraint(min_w, max_w)

        result = pc.check_feasibility()

        # If both binary and weight, compare with direct MIP
        if has_binary and has_weight:
            direct = check_mip_feasibility(**mip_kwargs)
            assert result.feasible == direct["feasible"], (
                f"[seed={seed}] Checker={result.feasible}, Direct MIP={direct['feasible']}"
            )

    @pytest.mark.parametrize("seed", range(30))
    def test_checker_cvar_matches_direct(self, seed):
        """Checker CVaR matches direct cvar_solver."""
        rng = np.random.RandomState(7000 + seed)
        n = rng.randint(3, 10)
        S = rng.randint(20, 80)
        returns = rng.normal(0.01, 0.06, (S, n))
        max_cvar = round(rng.uniform(0.01, 0.30), 2)

        pc = PortfolioChecker(n_assets=n)
        pc.add_budget(total=1.0)
        pc.add_position_bounds(min_w=0.0, max_w=0.50)
        pc.add_cvar_limit(confidence=0.95, max_cvar=max_cvar, returns=returns)
        result = pc.check_feasibility()

        direct = check_cvar_feasibility(
            n_assets=n, confidence=0.95, max_cvar=max_cvar,
            returns=returns, budget_total=1.0, min_w=0.0, max_w=0.50,
        )
        assert result.feasible == direct["feasible"], (
            f"[seed={seed}] Checker={result.feasible}, Direct CVaR={direct['feasible']}"
        )
