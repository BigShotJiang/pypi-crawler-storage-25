"""Tests for IIS extraction and diagnosis."""

import numpy as np
import pytest

from portfolio_optimizer.diagnosis import extract_iis, suggest_fix


class TestIISExtraction:
    """Test deletion-based IIS extraction."""

    def test_simple_infeasible_2_constraints(self):
        """2 contradictory constraints: x >= 1 and x <= 0."""
        n_vars = 1
        c = np.zeros(n_vars)
        # x >= 1 -> -x <= -1
        # x <= 0
        A_ub = np.array([[-1.0], [1.0]])
        b_ub = np.array([-1.0, 0.0])
        bounds = [(None, None)]
        names = ["x >= 1", "x <= 0"]

        result = extract_iis(c, A_ub, b_ub, None, None, bounds, names)
        assert result["n_iis"] == 2
        assert set(result["iis_names"]) == {"x >= 1", "x <= 0"}

    def test_3_constraints_2_form_iis(self):
        """3 constraints, only 2 conflict.

        x >= 3  (essential)
        x <= 1  (essential)
        x >= 0  (redundant — removing it doesn't help)
        """
        n_vars = 1
        c = np.zeros(n_vars)
        A_ub = np.array([[-1.0], [1.0], [-1.0]])
        b_ub = np.array([-3.0, 1.0, 0.0])
        bounds = [(None, None)]
        names = ["x >= 3", "x <= 1", "x >= 0"]

        result = extract_iis(c, A_ub, b_ub, None, None, bounds, names)
        assert result["n_iis"] == 2
        assert "x >= 3" in result["iis_names"]
        assert "x <= 1" in result["iis_names"]
        assert "x >= 0" not in result["iis_names"]

    def test_equality_in_iis(self):
        """Equality constraint conflicts with inequality.

        x = 5  (equality)
        x <= 3 (inequality)
        """
        n_vars = 1
        c = np.zeros(n_vars)
        A_ub = np.array([[1.0]])
        b_ub = np.array([3.0])
        A_eq = np.array([[1.0]])
        b_eq = np.array([5.0])
        bounds = [(None, None)]
        names = ["x <= 3", "x = 5"]

        result = extract_iis(c, A_ub, b_ub, A_eq, b_eq, bounds, names)
        assert result["n_iis"] == 2

    def test_feasible_no_iis(self):
        """Feasible system: no IIS (all redundant)."""
        n_vars = 1
        c = np.zeros(n_vars)
        A_ub = np.array([[-1.0], [1.0]])
        b_ub = np.array([0.0, 10.0])
        bounds = [(None, None)]
        names = ["x >= 0", "x <= 10"]

        result = extract_iis(c, A_ub, b_ub, None, None, bounds, names)
        # For a feasible system, no constraints are essential
        assert result["n_iis"] == 0

    def test_portfolio_like_iis(self):
        """Portfolio: 3 assets, sum=1, each max 0.20 -> infeasible.

        IIS should include budget + at least the 3 upper bounds.
        """
        n_vars = 3
        c = np.zeros(n_vars)
        # x0 <= 0.20, x1 <= 0.20, x2 <= 0.20
        A_ub = np.array([
            [1.0, 0.0, 0.0],
            [0.0, 1.0, 0.0],
            [0.0, 0.0, 1.0],
        ])
        b_ub = np.array([0.20, 0.20, 0.20])
        # sum = 1.0
        A_eq = np.array([[1.0, 1.0, 1.0]])
        b_eq = np.array([1.0])
        bounds = [(0, None), (0, None), (0, None)]
        names = ["x0 <= 0.20", "x1 <= 0.20", "x2 <= 0.20", "sum = 1.0"]

        result = extract_iis(c, A_ub, b_ub, A_eq, b_eq, bounds, names)
        assert result["n_iis"] >= 2  # At least budget + some upper bounds
        assert "sum = 1.0" in result["iis_names"]


class TestIISCorrectness:
    """Verify IIS property: removing ANY single IIS constraint makes it feasible."""

    def test_removing_any_iis_makes_feasible(self):
        """3-asset portfolio IIS: verify removal of each IIS member gives feasibility."""
        from scipy.optimize import linprog

        n_vars = 3
        c = np.zeros(n_vars)
        A_ub = np.array([
            [1.0, 0.0, 0.0],
            [0.0, 1.0, 0.0],
            [0.0, 0.0, 1.0],
        ])
        b_ub = np.array([0.20, 0.20, 0.20])
        A_eq = np.array([[1.0, 1.0, 1.0]])
        b_eq = np.array([1.0])
        bounds = [(0, None), (0, None), (0, None)]
        names = ["x0 <= 0.20", "x1 <= 0.20", "x2 <= 0.20", "sum = 1.0"]

        result = extract_iis(c, A_ub, b_ub, A_eq, b_eq, bounds, names)
        iis_indices = result["iis_indices"]
        assert len(iis_indices) >= 2

        n_ub = len(A_ub)
        # Verify: removing any single IIS member makes it feasible
        for idx in iis_indices:
            remaining_ub = [i for i in range(n_ub) if i != idx and i in iis_indices]
            other_ub = [i for i in range(n_ub) if i not in iis_indices]
            active_ub = remaining_ub + other_ub

            if idx < n_ub:
                # Removing an inequality
                a_ub_f = A_ub[active_ub] if active_ub else None
                b_ub_f = b_ub[active_ub] if active_ub else None
                a_eq_f = A_eq
                b_eq_f = b_eq
            else:
                # Removing the equality
                a_ub_f = A_ub
                b_ub_f = b_ub
                a_eq_f = None
                b_eq_f = None

            res = linprog(c, A_ub=a_ub_f, b_ub=b_ub_f,
                         A_eq=a_eq_f, b_eq=b_eq_f,
                         bounds=bounds, method="highs")
            assert res.success, (
                f"Removing IIS member {idx} ({names[idx]}) should make it feasible, "
                f"but LP still infeasible"
            )

    def test_iis_is_minimal_2vars(self):
        """2 variables, 4 constraints, IIS should be exactly 2.

        x + y >= 3   (essential)
        x <= 1       (essential)
        y <= 1       (essential — needed because x + y <= 2 < 3)
        x >= 0       (redundant)
        """
        n_vars = 2
        c = np.zeros(n_vars)
        A_ub = np.array([
            [-1.0, -1.0],  # x + y >= 3 → -(x+y) <= -3
            [1.0, 0.0],    # x <= 1
            [0.0, 1.0],    # y <= 1
            [-1.0, 0.0],   # x >= 0 → -x <= 0
        ])
        b_ub = np.array([-3.0, 1.0, 1.0, 0.0])
        bounds = [(None, None), (None, None)]
        names = ["x+y >= 3", "x <= 1", "y <= 1", "x >= 0"]

        result = extract_iis(c, A_ub, b_ub, None, None, bounds, names)
        assert "x+y >= 3" in result["iis_names"]
        assert "x <= 1" in result["iis_names"]
        assert "y <= 1" in result["iis_names"]
        assert "x >= 0" not in result["iis_names"]  # redundant
        assert result["n_iis"] == 3

    def test_iis_with_multiple_equalities(self):
        """Two equalities that conflict.

        x = 3
        x = 5
        """
        n_vars = 1
        c = np.zeros(n_vars)
        A_eq = np.array([[1.0], [1.0]])
        b_eq = np.array([3.0, 5.0])
        bounds = [(None, None)]
        names = ["x = 3", "x = 5"]

        result = extract_iis(c, None, None, A_eq, b_eq, bounds, names)
        assert result["n_iis"] == 2
        assert set(result["iis_names"]) == {"x = 3", "x = 5"}

    def test_iis_5_constraints_3_essential(self):
        """5 constraints, 3 form the IIS.

        x + y + z = 1     (essential)
        x >= 0.5           (essential)
        y >= 0.5           (essential)
        z >= 0.5           (redundant — removing doesn't help since x+y already >= 1)
        Actually z >= 0.5 IS essential: x>=0.5, y>=0.5, z>=0.5 → sum>=1.5 but sum=1.
        Wait, 3 of them form the IIS. Let me think again...

        x + y + z = 1 AND x >= 0.5, y >= 0.5 → z <= 0 but z free → feasible at z=0.
        x + y + z = 1 AND x >= 0.5, z >= 0.5 → y <= 0 but y free → feasible at y=0.
        So: all 4 are essential (can't remove any one).
        Let me add a truly redundant one.
        """
        n_vars = 3
        c = np.zeros(n_vars)
        # Constraints: sum=1, x>=0.5, y>=0.5, z>=0.5, x>=0 (redundant)
        A_ub = np.array([
            [-1.0, 0.0, 0.0],  # x >= 0.5 → -x <= -0.5
            [0.0, -1.0, 0.0],  # y >= 0.5 → -y <= -0.5
            [0.0, 0.0, -1.0],  # z >= 0.5 → -z <= -0.5
            [-1.0, 0.0, 0.0],  # x >= 0 → -x <= 0 (redundant)
        ])
        b_ub = np.array([-0.5, -0.5, -0.5, 0.0])
        A_eq = np.array([[1.0, 1.0, 1.0]])
        b_eq = np.array([1.0])
        bounds = [(None, None)] * 3
        names = ["x >= 0.5", "y >= 0.5", "z >= 0.5", "x >= 0", "sum = 1"]

        result = extract_iis(c, A_ub, b_ub, A_eq, b_eq, bounds, names)
        assert "x >= 0" not in result["iis_names"]  # redundant
        assert "sum = 1" in result["iis_names"]
        assert result["n_iis"] >= 3  # At least sum + 2 of the >= 0.5


class TestSuggestFix:
    """Test suggestion generation."""

    def test_non_empty_suggestion(self):
        names = ["weight_limit(tech, max=0.30)", "budget(total=1.0)"]
        text = suggest_fix(names)
        assert len(text) > 0
        assert "conflict" in text.lower() or "irreducible" in text.lower()

    def test_empty_iis(self):
        text = suggest_fix([])
        assert "no infeasible" in text.lower()

    def test_single_constraint(self):
        text = suggest_fix(["x <= 3"])
        assert "1 constraint" in text.lower() or "1" in text

    def test_many_constraints(self):
        names = [f"constraint_{i}" for i in range(10)]
        text = suggest_fix(names)
        assert "10 constraints" in text.lower() or "10" in text
        for name in names:
            assert name in text

    def test_suggestion_mentions_relax(self):
        """Every suggestion should mention relaxing constraints."""
        text = suggest_fix(["a", "b", "c"])
        assert "relax" in text.lower() or "remove" in text.lower()
