"""Cross-validation tests: verify different solvers agree on the same problem."""

import numpy as np
import pytest
from portfolio_optimizer.lp_solver import check_lp_feasibility, check_mip_feasibility
from portfolio_optimizer.constraints import (
    CardinalityConstraint, WeightLimitConstraint,
    BudgetConstraint, PositionBoundsConstraint,
)


class TestLPvsMIP:
    """When there are no binary constraints, LP and MIP should agree."""

    @pytest.mark.parametrize("n_assets,max_w", [
        (3, 0.40), (3, 0.30), (5, 0.25), (5, 0.15),
        (10, 0.12), (10, 0.08), (20, 0.06), (20, 0.04),
    ])
    def test_lp_mip_agree_no_cardinality(self, n_assets, max_w):
        """Without cardinality, LP and MIP should give same feasibility."""
        lp = check_lp_feasibility(
            n_assets=n_assets,
            weight_limits=[],
            budget=BudgetConstraint(total=1.0),
            position_bounds=PositionBoundsConstraint(min_w=0.0, max_w=max_w),
        )
        mip = check_mip_feasibility(
            n_assets=n_assets,
            cardinality=None,
            weight_limits=[],
            budget=BudgetConstraint(total=1.0),
            position_bounds=PositionBoundsConstraint(min_w=0.0, max_w=max_w),
        )
        assert lp["feasible"] == mip["feasible"], (
            f"n={n_assets}, max_w={max_w}: LP={'F' if lp['feasible'] else 'I'}, "
            f"MIP={'F' if mip['feasible'] else 'I'}"
        )

    @pytest.mark.parametrize("sector_a_max,sector_b_max", [
        (0.50, 0.50), (0.60, 0.40), (0.30, 0.30),
        (0.70, 0.30), (0.80, 0.20), (0.40, 0.40),
    ])
    def test_lp_mip_agree_with_sectors(self, sector_a_max, sector_b_max):
        """LP and MIP agree on sector limits (no cardinality)."""
        wl = [
            WeightLimitConstraint("A", [0, 1, 2], max_pct=sector_a_max),
            WeightLimitConstraint("B", [3, 4, 5], max_pct=sector_b_max),
        ]
        lp = check_lp_feasibility(
            n_assets=6, weight_limits=wl,
            budget=BudgetConstraint(total=1.0), position_bounds=None,
        )
        mip = check_mip_feasibility(
            n_assets=6, cardinality=None, weight_limits=wl,
            budget=BudgetConstraint(total=1.0), position_bounds=None,
        )
        assert lp["feasible"] == mip["feasible"]


class TestMIPWithAllSelected:
    """MIP with cardinality = n_assets should match LP (all selected)."""

    @pytest.mark.parametrize("n_assets,max_w", [
        (3, 0.40), (5, 0.25), (10, 0.12),
    ])
    def test_all_selected_matches_lp(self, n_assets, max_w):
        lp = check_lp_feasibility(
            n_assets=n_assets, weight_limits=[],
            budget=BudgetConstraint(total=1.0),
            position_bounds=PositionBoundsConstraint(min_w=0.0, max_w=max_w),
        )
        mip = check_mip_feasibility(
            n_assets=n_assets,
            cardinality=CardinalityConstraint(min_assets=n_assets, max_assets=n_assets),
            weight_limits=[],
            budget=BudgetConstraint(total=1.0),
            position_bounds=PositionBoundsConstraint(min_w=0.0, max_w=max_w),
        )
        assert lp["feasible"] == mip["feasible"]


class TestSolutionConsistency:
    """Verify that feasible solutions satisfy all stated constraints."""

    @pytest.mark.parametrize("n,select,min_w,max_w", [
        (5, 3, 0.10, 0.40),
        (10, 5, 0.10, 0.30),
        (20, 10, 0.05, 0.15),
        (10, 4, 0.15, 0.35),
        (6, 3, 0.20, 0.40),
    ])
    def test_mip_solution_satisfies_all(self, n, select, min_w, max_w):
        """Every returned MIP solution must satisfy all constraints."""
        result = check_mip_feasibility(
            n_assets=n,
            cardinality=CardinalityConstraint(min_assets=select, max_assets=select),
            weight_limits=[],
            budget=BudgetConstraint(total=1.0),
            position_bounds=PositionBoundsConstraint(min_w=min_w, max_w=max_w),
        )
        if not result["feasible"]:
            return  # Nothing to verify

        w = result["weights"]
        z = result["selected"]

        # Budget
        assert np.isclose(np.sum(w), 1.0, atol=1e-4), f"sum(w)={np.sum(w)}"

        # Cardinality
        n_sel = int(np.sum(z))
        assert n_sel == select, f"selected={n_sel}, expected={select}"

        # Bounds
        for i in range(n):
            if z[i] == 1:
                assert w[i] >= min_w - 1e-6, f"w[{i}]={w[i]} < min_w={min_w}"
                assert w[i] <= max_w + 1e-6, f"w[{i}]={w[i]} > max_w={max_w}"
            else:
                assert w[i] < 1e-6, f"w[{i}]={w[i]} but z[{i}]=0"

    @pytest.mark.parametrize("n,min_w,max_w", [
        (3, 0.10, 0.50),
        (5, 0.05, 0.30),
        (10, 0.0, 0.20),
        (20, 0.01, 0.10),
    ])
    def test_lp_solution_satisfies_all(self, n, min_w, max_w):
        """Every returned LP solution must satisfy all constraints."""
        result = check_lp_feasibility(
            n_assets=n, weight_limits=[],
            budget=BudgetConstraint(total=1.0),
            position_bounds=PositionBoundsConstraint(min_w=min_w, max_w=max_w),
        )
        if not result["feasible"]:
            return

        w = result["weights"]
        assert np.isclose(np.sum(w), 1.0, atol=1e-6)
        for i in range(n):
            assert w[i] >= min_w - 1e-6
            assert w[i] <= max_w + 1e-6
