"""Integration tests for PortfolioChecker."""

import numpy as np
import pytest
from portfolio_optimizer import PortfolioChecker


class TestQuickChecks:
    """Test that quick arithmetic catches obvious infeasibilities."""

    def test_sector_mins_exceed_max(self):
        pc = PortfolioChecker(n_assets=20)
        pc.add_cardinality(max_assets=5)
        pc.add_sector_min("tech", assets=list(range(0, 7)), min_count=3)
        pc.add_sector_min("health", assets=list(range(7, 14)), min_count=3)
        result = pc.check_feasibility()
        assert not result.feasible
        assert result.method == "quick_check"

    def test_min_greater_than_n_assets(self):
        pc = PortfolioChecker(n_assets=5)
        pc.add_cardinality(min_assets=10)
        result = pc.check_feasibility()
        assert not result.feasible
        assert result.method == "quick_check"

    def test_max_less_than_min(self):
        pc = PortfolioChecker(n_assets=10)
        pc.add_cardinality(min_assets=8, max_assets=3)
        result = pc.check_feasibility()
        assert not result.feasible
        assert result.method == "quick_check"

    def test_min_w_times_min_assets_exceeds_budget(self):
        pc = PortfolioChecker(n_assets=20)
        pc.add_cardinality(min_assets=15)
        pc.add_position_bounds(min_w=0.10, max_w=0.50)
        pc.add_budget(total=1.0)
        result = pc.check_feasibility()
        assert not result.feasible
        assert result.method == "quick_check"
        assert "min_w" in result.suggestion or "position_bounds" in str(result.infeasible_constraints)

    def test_max_w_times_max_assets_below_budget(self):
        pc = PortfolioChecker(n_assets=10)
        pc.add_cardinality(min_assets=2, max_assets=3)
        pc.add_position_bounds(min_w=0.01, max_w=0.10)
        pc.add_budget(total=1.0)
        result = pc.check_feasibility()
        assert not result.feasible
        assert result.method == "quick_check"

    def test_sector_min_pcts_exceed_100(self):
        pc = PortfolioChecker(n_assets=20)
        pc.add_weight_limit("tech", assets=list(range(0, 7)), min_pct=0.40)
        pc.add_weight_limit("health", assets=list(range(7, 14)), min_pct=0.40)
        pc.add_weight_limit("energy", assets=list(range(14, 20)), min_pct=0.30)
        result = pc.check_feasibility()
        assert not result.feasible
        assert result.method == "quick_check"


class TestSATPath:
    """Test binary constraints via torc-sat bridge."""

    def test_pure_binary_feasible(self):
        pc = PortfolioChecker(n_assets=10)
        pc.add_cardinality(min_assets=3, max_assets=5)
        result = pc.check_feasibility()
        assert result.feasible
        assert result.method == "sat"

    def test_pure_binary_infeasible(self):
        """3 assets, all pairs excluded, min 2 -> impossible."""
        pc = PortfolioChecker(n_assets=3)
        pc.add_cardinality(min_assets=2)
        pc.add_exclusion(0, 1)
        pc.add_exclusion(0, 2)
        pc.add_exclusion(1, 2)
        result = pc.check_feasibility()
        assert not result.feasible
        assert result.method == "sat"

    def test_sector_min_feasible(self):
        pc = PortfolioChecker(n_assets=10)
        pc.add_cardinality(min_assets=4, max_assets=6)
        pc.add_sector_min("tech", assets=[0, 1, 2, 3], min_count=2)
        pc.add_sector_min("health", assets=[4, 5, 6, 7], min_count=2)
        result = pc.check_feasibility()
        assert result.feasible

    def test_diversification_feasible(self):
        pc = PortfolioChecker(n_assets=9)
        pc.add_diversification({
            "tech": [0, 1, 2],
            "health": [3, 4, 5],
            "energy": [6, 7, 8],
        })
        result = pc.check_feasibility()
        assert result.feasible


class TestLPPath:
    """Test weight-only constraints via LP."""

    def test_lp_feasible(self):
        pc = PortfolioChecker(n_assets=5)
        pc.add_budget(total=1.0)
        pc.add_position_bounds(min_w=0.0, max_w=0.50)
        result = pc.check_feasibility()
        assert result.feasible
        assert result.method == "lp"
        assert "weights" in result.details

    def test_lp_infeasible_tight_bounds(self):
        """5 assets, max_w=0.10, budget=1.0 -> impossible (5*0.10=0.50 < 1.0)."""
        pc = PortfolioChecker(n_assets=5)
        pc.add_budget(total=1.0)
        pc.add_position_bounds(min_w=0.0, max_w=0.10)
        result = pc.check_feasibility()
        assert not result.feasible
        assert result.method == "lp"

    def test_lp_sector_limits_feasible(self):
        pc = PortfolioChecker(n_assets=6)
        pc.add_budget(total=1.0)
        pc.add_weight_limit("tech", assets=[0, 1, 2], max_pct=0.50)
        pc.add_weight_limit("health", assets=[3, 4, 5], max_pct=0.60)
        result = pc.check_feasibility()
        assert result.feasible
        assert result.method == "lp"

    def test_lp_sector_limits_infeasible(self):
        """Two sectors each max 30%, but budget=1.0 and only these 2 sectors."""
        pc = PortfolioChecker(n_assets=6)
        pc.add_budget(total=1.0)
        pc.add_weight_limit("tech", assets=[0, 1, 2], max_pct=0.30)
        pc.add_weight_limit("health", assets=[3, 4, 5], max_pct=0.30)
        result = pc.check_feasibility()
        assert not result.feasible


class TestMIPPath:
    """Test mixed binary + weight constraints via MIP."""

    def test_mip_feasible(self):
        pc = PortfolioChecker(n_assets=10)
        pc.add_cardinality(min_assets=3, max_assets=5)
        pc.add_budget(total=1.0)
        pc.add_position_bounds(min_w=0.05, max_w=0.40)
        result = pc.check_feasibility()
        assert result.feasible
        assert result.method == "mip"

    def test_mip_infeasible_tight(self):
        """Select 3-5 assets, each max 0.10 -> max total 0.50 < budget 1.0."""
        pc = PortfolioChecker(n_assets=10)
        pc.add_cardinality(min_assets=3, max_assets=5)
        pc.add_budget(total=1.0)
        pc.add_position_bounds(min_w=0.01, max_w=0.10)
        result = pc.check_feasibility()
        assert not result.feasible

    def test_mip_with_exclusions(self):
        pc = PortfolioChecker(n_assets=6)
        pc.add_cardinality(min_assets=2, max_assets=4)
        pc.add_exclusion(0, 1)
        pc.add_budget(total=1.0)
        pc.add_position_bounds(min_w=0.10, max_w=0.60)
        result = pc.check_feasibility()
        assert result.feasible
        assert result.method == "mip"

    def test_mip_with_sector_weight(self):
        pc = PortfolioChecker(n_assets=10)
        pc.add_cardinality(min_assets=4, max_assets=6)
        pc.add_budget(total=1.0)
        pc.add_position_bounds(min_w=0.05, max_w=0.30)
        pc.add_weight_limit("tech", assets=[0, 1, 2, 3], max_pct=0.40)
        result = pc.check_feasibility()
        assert result.feasible


class TestCVaRPath:
    """Test CVaR risk constraint."""

    def test_cvar_feasible_low_risk(self):
        """Positive returns -> CVaR is negative -> easily under any positive max."""
        np.random.seed(42)
        n_assets = 5
        S = 50
        # Returns with positive mean (low risk)
        returns = np.random.normal(0.05, 0.01, (S, n_assets))

        pc = PortfolioChecker(n_assets=n_assets)
        pc.add_budget(total=1.0)
        pc.add_position_bounds(min_w=0.0, max_w=0.50)
        pc.add_cvar_limit(confidence=0.95, max_cvar=0.10, returns=returns)
        result = pc.check_feasibility()
        assert result.feasible
        assert result.method == "cvar"

    def test_cvar_infeasible_tight(self):
        """Very negative returns with tight CVaR limit -> infeasible."""
        np.random.seed(42)
        n_assets = 5
        S = 50
        # Very negative returns (high risk)
        returns = np.random.normal(-0.50, 0.10, (S, n_assets))

        pc = PortfolioChecker(n_assets=n_assets)
        pc.add_budget(total=1.0)
        pc.add_position_bounds(min_w=0.0, max_w=0.50)
        pc.add_cvar_limit(confidence=0.95, max_cvar=0.01, returns=returns)
        result = pc.check_feasibility()
        assert not result.feasible
        assert result.method == "cvar"

    def test_cvar_moderate(self):
        """Mixed returns with reasonable CVaR limit."""
        np.random.seed(123)
        n_assets = 10
        S = 100
        returns = np.random.normal(0.02, 0.05, (S, n_assets))

        pc = PortfolioChecker(n_assets=n_assets)
        pc.add_budget(total=1.0)
        pc.add_position_bounds(min_w=0.0, max_w=0.30)
        pc.add_cvar_limit(confidence=0.95, max_cvar=0.20, returns=returns)
        result = pc.check_feasibility()
        assert result.feasible


class TestNoConstraints:
    """Edge case: no constraints."""

    def test_empty(self):
        pc = PortfolioChecker(n_assets=10)
        result = pc.check_feasibility()
        assert result.feasible
        assert result.method == "trivial"


class TestSoundness:
    """Soundness: never report INFEASIBLE for a feasible problem."""

    def test_known_feasible_mip(self):
        """10 assets, select 5, equal weight 0.20, budget=1.0."""
        pc = PortfolioChecker(n_assets=10)
        pc.add_cardinality(min_assets=5, max_assets=5)
        pc.add_budget(total=1.0)
        pc.add_position_bounds(min_w=0.20, max_w=0.20)
        result = pc.check_feasibility()
        assert result.feasible

    def test_known_feasible_with_sector(self):
        """6 assets in 2 sectors, select 4, sector min 2 each."""
        pc = PortfolioChecker(n_assets=6)
        pc.add_cardinality(min_assets=4, max_assets=4)
        pc.add_sector_min("A", assets=[0, 1, 2], min_count=2)
        pc.add_sector_min("B", assets=[3, 4, 5], min_count=2)
        pc.add_budget(total=1.0)
        pc.add_position_bounds(min_w=0.10, max_w=0.40)
        result = pc.check_feasibility()
        assert result.feasible

    def test_known_feasible_single_asset(self):
        """1 asset, weight=1.0, select 1."""
        pc = PortfolioChecker(n_assets=1)
        pc.add_cardinality(min_assets=1, max_assets=1)
        pc.add_budget(total=1.0)
        pc.add_position_bounds(min_w=1.0, max_w=1.0)
        result = pc.check_feasibility()
        assert result.feasible

    def test_known_feasible_many_exclusions(self):
        """10 assets, 5 exclusion pairs, select 3 -> feasible if exclusions are sparse."""
        pc = PortfolioChecker(n_assets=10)
        pc.add_cardinality(min_assets=3, max_assets=5)
        # Path exclusions: 0-1, 2-3, 4-5, 6-7, 8-9
        for i in range(0, 10, 2):
            pc.add_exclusion(i, i + 1)
        result = pc.check_feasibility()
        assert result.feasible  # Can pick {0, 2, 4, 6, 8}

    def test_known_feasible_lp_tight_but_ok(self):
        """4 assets, budget=1.0, max_w=0.25 -> exactly fits."""
        pc = PortfolioChecker(n_assets=4)
        pc.add_budget(total=1.0)
        pc.add_position_bounds(min_w=0.25, max_w=0.25)
        result = pc.check_feasibility()
        assert result.feasible

    def test_known_feasible_diversification_plus_weights(self):
        """3 sectors, diversification + budget -> feasible via MIP."""
        pc = PortfolioChecker(n_assets=9)
        pc.add_diversification({
            "tech": [0, 1, 2],
            "health": [3, 4, 5],
            "energy": [6, 7, 8],
        })
        pc.add_budget(total=1.0)
        pc.add_position_bounds(min_w=0.0, max_w=0.50)
        result = pc.check_feasibility()
        assert result.feasible


class TestEdgeCases:
    """Edge cases and boundary conditions."""

    def test_zero_assets(self):
        """0 assets: trivially feasible (nothing to do)."""
        pc = PortfolioChecker(n_assets=0)
        result = pc.check_feasibility()
        assert result.feasible

    def test_single_asset_no_constraints(self):
        pc = PortfolioChecker(n_assets=1)
        result = pc.check_feasibility()
        assert result.feasible

    def test_single_asset_with_budget(self):
        pc = PortfolioChecker(n_assets=1)
        pc.add_budget(total=1.0)
        result = pc.check_feasibility()
        assert result.feasible

    def test_cardinality_only_max(self):
        pc = PortfolioChecker(n_assets=10)
        pc.add_cardinality(max_assets=5)
        result = pc.check_feasibility()
        assert result.feasible

    def test_cardinality_only_min(self):
        pc = PortfolioChecker(n_assets=10)
        pc.add_cardinality(min_assets=3)
        result = pc.check_feasibility()
        assert result.feasible

    def test_exclusion_same_pair_twice(self):
        """Adding same exclusion twice shouldn't break anything."""
        pc = PortfolioChecker(n_assets=5)
        pc.add_cardinality(min_assets=2, max_assets=3)
        pc.add_exclusion(0, 1)
        pc.add_exclusion(0, 1)  # duplicate
        result = pc.check_feasibility()
        assert result.feasible  # Can still pick {0, 2} or {1, 2}

    def test_many_weight_limits_feasible(self):
        """5 sectors, each 20% max, budget 1.0 -> feasible (5*20%=100%)."""
        pc = PortfolioChecker(n_assets=25)
        pc.add_budget(total=1.0)
        for i, sector in enumerate(["A", "B", "C", "D", "E"]):
            pc.add_weight_limit(sector, assets=list(range(i*5, (i+1)*5)), max_pct=0.20)
        result = pc.check_feasibility()
        assert result.feasible

    def test_budget_zero(self):
        """Budget=0, all weights must be 0."""
        pc = PortfolioChecker(n_assets=5)
        pc.add_budget(total=0.0)
        result = pc.check_feasibility()
        assert result.feasible


class TestRealisticScenarios:
    """Realistic financial scenarios with multiple constraint types."""

    def test_sp500_like_portfolio(self):
        """500 assets, 10 sectors, cardinality 20-30, sector limits, budget."""
        n = 500
        pc = PortfolioChecker(n_assets=n)
        pc.add_cardinality(min_assets=20, max_assets=30)
        pc.add_budget(total=1.0)
        pc.add_position_bounds(min_w=0.01, max_w=0.10)

        sectors = {}
        sector_size = 50
        for i, name in enumerate(["tech", "health", "finance", "energy",
                                    "consumer", "industrial", "materials",
                                    "utilities", "realestate", "comms"]):
            assets = list(range(i * sector_size, (i + 1) * sector_size))
            sectors[name] = assets
            pc.add_weight_limit(name, assets=assets, max_pct=0.25)

        result = pc.check_feasibility()
        assert result.feasible

    def test_esg_constrained_portfolio(self):
        """Portfolio with ESG exclusions making it tight."""
        pc = PortfolioChecker(n_assets=20)
        pc.add_cardinality(min_assets=5, max_assets=10)
        pc.add_budget(total=1.0)
        pc.add_position_bounds(min_w=0.05, max_w=0.30)

        # Exclude 3 pairs (ESG conflicts)
        pc.add_exclusion(0, 5)   # arms vs ESG fund
        pc.add_exclusion(1, 10)  # tobacco vs health
        pc.add_exclusion(2, 15)  # coal vs green

        # Sector minimums
        pc.add_sector_min("tech", assets=list(range(0, 7)), min_count=2)
        pc.add_sector_min("health", assets=list(range(7, 14)), min_count=2)

        result = pc.check_feasibility()
        assert result.feasible

    def test_over_constrained_portfolio(self):
        """Too many constraints -> infeasible.

        5 assets, select 3, but ALL pairs excluded -> at most 1 can be selected.
        """
        pc = PortfolioChecker(n_assets=5)
        pc.add_cardinality(min_assets=3, max_assets=5)
        pc.add_budget(total=1.0)
        pc.add_position_bounds(min_w=0.15, max_w=0.40)

        # All 10 pairs excluded -> at most 1 from {0..4}
        for i in range(5):
            for j in range(i + 1, 5):
                pc.add_exclusion(i, j)

        result = pc.check_feasibility()
        assert not result.feasible

    def test_regulatory_minimum_sectors(self):
        """Must have min 3 from each of 4 sectors, max 15 total."""
        pc = PortfolioChecker(n_assets=40)
        pc.add_cardinality(min_assets=12, max_assets=15)
        for i, name in enumerate(["A", "B", "C", "D"]):
            assets = list(range(i * 10, (i + 1) * 10))
            pc.add_sector_min(name, assets=assets, min_count=3)
        result = pc.check_feasibility()
        assert result.feasible  # 4*3=12 <= 15

    def test_regulatory_minimum_sectors_tight(self):
        """Must have min 4 from each of 4 sectors, max 15 total -> 16 > 15."""
        pc = PortfolioChecker(n_assets=40)
        pc.add_cardinality(min_assets=12, max_assets=15)
        for i, name in enumerate(["A", "B", "C", "D"]):
            assets = list(range(i * 10, (i + 1) * 10))
            pc.add_sector_min(name, assets=assets, min_count=4)
        result = pc.check_feasibility()
        assert not result.feasible  # 4*4=16 > 15

    def test_result_has_suggestion_when_infeasible(self):
        """Every infeasible result should have a non-empty suggestion."""
        pc = PortfolioChecker(n_assets=5)
        pc.add_cardinality(min_assets=10)
        result = pc.check_feasibility()
        assert not result.feasible
        assert len(result.suggestion) > 0

    def test_result_has_method(self):
        """Every result should identify which method was used."""
        pc = PortfolioChecker(n_assets=10)
        pc.add_cardinality(min_assets=3, max_assets=5)
        result = pc.check_feasibility()
        assert result.method in ("quick_check", "sat", "lp", "mip", "cvar", "trivial")
