"""Property-based fuzzing: generate random constraints and verify
mathematical invariants that MUST hold regardless of the specific problem.

These tests go beyond Gurobi validation because they test PROPERTIES,
not just individual instances. A property violation proves a solver bug.
"""

import numpy as np
import pytest
from portfolio_optimizer import PortfolioChecker
from portfolio_optimizer.lp_solver import check_lp_feasibility, check_mip_feasibility
from portfolio_optimizer.cvar_solver import check_cvar_feasibility
from portfolio_optimizer.constraints import (
    CardinalityConstraint, BudgetConstraint, PositionBoundsConstraint,
    WeightLimitConstraint, ExclusionConstraint,
)


class TestLPRelaxation:
    """LP relaxation (ignoring binary constraints) is ALWAYS at least as
    feasible as MIP. If MIP is feasible, LP MUST be feasible."""

    @pytest.mark.parametrize("seed", range(50))
    def test_mip_feasible_implies_lp_feasible(self, seed):
        """If MIP says feasible, LP (without cardinality) must agree."""
        rng = np.random.RandomState(seed)
        n = rng.randint(3, 15)
        max_sel = rng.randint(1, n + 1)
        min_sel = rng.randint(1, max_sel + 1)
        min_w = round(rng.uniform(0.0, 0.20), 2)
        max_w = round(rng.uniform(max(min_w + 0.01, 0.10), 1.0), 2)

        mip = check_mip_feasibility(
            n_assets=n,
            cardinality=CardinalityConstraint(min_assets=min_sel, max_assets=max_sel),
            weight_limits=[],
            budget=BudgetConstraint(total=1.0),
            position_bounds=PositionBoundsConstraint(min_w=min_w, max_w=max_w),
        )
        lp = check_lp_feasibility(
            n_assets=n,
            weight_limits=[],
            budget=BudgetConstraint(total=1.0),
            position_bounds=PositionBoundsConstraint(min_w=0.0, max_w=max_w),
        )
        if mip["feasible"]:
            assert lp["feasible"], (
                f"seed={seed}: MIP feasible but LP infeasible! "
                f"n={n}, sel=[{min_sel},{max_sel}], w=[{min_w},{max_w}]"
            )


class TestMonotonicityFuzzing:
    """Random tightening must preserve infeasibility.
    Random relaxation must preserve feasibility."""

    @pytest.mark.parametrize("seed", range(30))
    def test_tightening_max_w(self, seed):
        """If infeasible at max_w, infeasible at max_w - delta."""
        rng = np.random.RandomState(200 + seed)
        n = rng.randint(3, 20)
        max_w = round(rng.uniform(0.05, 0.50), 3)

        r1 = check_lp_feasibility(
            n_assets=n, weight_limits=[],
            budget=BudgetConstraint(total=1.0),
            position_bounds=PositionBoundsConstraint(min_w=0.0, max_w=max_w),
        )
        if not r1["feasible"]:
            tighter = round(max_w * rng.uniform(0.3, 0.9), 3)
            r2 = check_lp_feasibility(
                n_assets=n, weight_limits=[],
                budget=BudgetConstraint(total=1.0),
                position_bounds=PositionBoundsConstraint(min_w=0.0, max_w=tighter),
            )
            assert not r2["feasible"], (
                f"seed={seed}: Infeasible at max_w={max_w} but feasible at max_w={tighter}!"
            )

    @pytest.mark.parametrize("seed", range(30))
    def test_relaxing_max_w(self, seed):
        """If feasible at max_w, feasible at max_w + delta."""
        rng = np.random.RandomState(300 + seed)
        n = rng.randint(3, 20)
        max_w = round(rng.uniform(0.10, 0.80), 3)

        r1 = check_lp_feasibility(
            n_assets=n, weight_limits=[],
            budget=BudgetConstraint(total=1.0),
            position_bounds=PositionBoundsConstraint(min_w=0.0, max_w=max_w),
        )
        if r1["feasible"]:
            looser = round(min(max_w + rng.uniform(0.01, 0.30), 1.0), 3)
            r2 = check_lp_feasibility(
                n_assets=n, weight_limits=[],
                budget=BudgetConstraint(total=1.0),
                position_bounds=PositionBoundsConstraint(min_w=0.0, max_w=looser),
            )
            assert r2["feasible"], (
                f"seed={seed}: Feasible at max_w={max_w} but infeasible at max_w={looser}!"
            )

    @pytest.mark.parametrize("seed", range(30))
    def test_relaxing_cardinality(self, seed):
        """If feasible with max_assets=K, feasible with max_assets=K+1."""
        rng = np.random.RandomState(400 + seed)
        n = rng.randint(3, 15)
        max_sel = rng.randint(1, n)
        min_w = round(rng.uniform(0.0, 0.15), 2)
        max_w = round(rng.uniform(max(min_w + 0.05, 0.15), 0.80), 2)

        r1 = check_mip_feasibility(
            n_assets=n,
            cardinality=CardinalityConstraint(min_assets=1, max_assets=max_sel),
            weight_limits=[],
            budget=BudgetConstraint(total=1.0),
            position_bounds=PositionBoundsConstraint(min_w=min_w, max_w=max_w),
        )
        if r1["feasible"]:
            r2 = check_mip_feasibility(
                n_assets=n,
                cardinality=CardinalityConstraint(min_assets=1, max_assets=min(max_sel + 1, n)),
                weight_limits=[],
                budget=BudgetConstraint(total=1.0),
                position_bounds=PositionBoundsConstraint(min_w=min_w, max_w=max_w),
            )
            assert r2["feasible"], (
                f"seed={seed}: Feasible at max_sel={max_sel} but infeasible at max_sel={max_sel+1}!"
            )

    @pytest.mark.parametrize("seed", range(20))
    def test_adding_exclusion_never_helps(self, seed):
        """If infeasible, adding one more exclusion stays infeasible."""
        rng = np.random.RandomState(500 + seed)
        n = rng.randint(4, 10)
        min_sel = rng.randint(2, n)
        max_sel = rng.randint(min_sel, n + 1)
        min_w = round(rng.uniform(0.05, 0.25), 2)
        max_w = round(rng.uniform(max(min_w, 0.15), 0.60), 2)

        # Start with some exclusions
        all_pairs = [(i, j) for i in range(n) for j in range(i + 1, n)]
        n_excl = rng.randint(0, min(5, len(all_pairs)))
        excl_idx = rng.choice(len(all_pairs), size=n_excl, replace=False) if n_excl > 0 else []
        excl = [all_pairs[i] for i in excl_idx]

        r1 = check_mip_feasibility(
            n_assets=n,
            cardinality=CardinalityConstraint(min_assets=min_sel, max_assets=max_sel),
            weight_limits=[],
            budget=BudgetConstraint(total=1.0),
            position_bounds=PositionBoundsConstraint(min_w=min_w, max_w=max_w),
            exclusions=[ExclusionConstraint(a, b) for a, b in excl],
        )
        if not r1["feasible"]:
            # Add one more exclusion
            remaining = [p for p in all_pairs if p not in excl]
            if remaining:
                extra = remaining[rng.randint(0, len(remaining))]
                excl2 = excl + [extra]
                r2 = check_mip_feasibility(
                    n_assets=n,
                    cardinality=CardinalityConstraint(min_assets=min_sel, max_assets=max_sel),
                    weight_limits=[],
                    budget=BudgetConstraint(total=1.0),
                    position_bounds=PositionBoundsConstraint(min_w=min_w, max_w=max_w),
                    exclusions=[ExclusionConstraint(a, b) for a, b in excl2],
                )
                assert not r2["feasible"], (
                    f"seed={seed}: Infeasible with {len(excl)} excl but feasible with {len(excl2)}!"
                )


class TestSectorSumProperty:
    """If all sectors are disjoint and cover all assets,
    then sum(sector_max_pct) must be >= budget for feasibility."""

    @pytest.mark.parametrize("seed", range(30))
    def test_disjoint_sectors_sum(self, seed):
        """For disjoint covering sectors: sum(max_pct) < budget => infeasible."""
        rng = np.random.RandomState(600 + seed)
        n = rng.randint(6, 30)
        n_sectors = rng.randint(2, min(6, n))
        # Split assets into disjoint sectors
        splits = sorted(rng.choice(range(1, n), size=n_sectors - 1, replace=False))
        splits = [0] + list(splits) + [n]
        sectors = [list(range(splits[i], splits[i + 1])) for i in range(n_sectors)]

        max_pcts = [round(rng.uniform(0.10, 0.60), 2) for _ in range(n_sectors)]
        total_pct = sum(max_pcts)

        wl = [
            WeightLimitConstraint(f"S{i}", sectors[i], min_pct=0.0, max_pct=max_pcts[i])
            for i in range(n_sectors)
        ]
        r = check_lp_feasibility(
            n_assets=n, weight_limits=wl,
            budget=BudgetConstraint(total=1.0),
            position_bounds=None,
        )
        if total_pct < 1.0 - 1e-9:
            assert not r["feasible"], (
                f"seed={seed}: sum(max_pct)={total_pct:.3f} < 1.0 but LP says feasible!"
            )


class TestSolutionCertification:
    """For every FEASIBLE result, verify the solution satisfies ALL constraints
    with strict numerical tolerances."""

    @pytest.mark.parametrize("seed", range(50))
    def test_lp_solution_certified(self, seed):
        """Every LP solution must satisfy all constraints."""
        rng = np.random.RandomState(700 + seed)
        n = rng.randint(3, 30)
        min_w = round(rng.uniform(0.0, 0.10), 3)
        max_w = round(rng.uniform(max(min_w + 0.01, 0.05), 1.0), 3)

        # Random sectors
        n_sec = rng.randint(0, 4)
        wl = []
        for _ in range(n_sec):
            sec_size = rng.randint(1, n)
            assets = sorted(rng.choice(n, size=sec_size, replace=False).tolist())
            mp = round(rng.uniform(0.20, 0.80), 2)
            wl.append(WeightLimitConstraint(f"S{_}", assets, max_pct=mp))

        r = check_lp_feasibility(
            n_assets=n, weight_limits=wl,
            budget=BudgetConstraint(total=1.0),
            position_bounds=PositionBoundsConstraint(min_w=min_w, max_w=max_w),
        )
        if r["feasible"]:
            w = r["weights"]
            # Budget
            assert abs(np.sum(w) - 1.0) < 1e-6, f"Budget violated: sum={np.sum(w)}"
            # Bounds
            for i in range(n):
                assert w[i] >= min_w - 1e-6, f"w[{i}]={w[i]} < min_w={min_w}"
                assert w[i] <= max_w + 1e-6, f"w[{i}]={w[i]} > max_w={max_w}"
            # Sectors
            for wlc in wl:
                s = sum(w[a] for a in wlc.assets if a < n)
                assert s <= wlc.max_pct + 1e-6, (
                    f"Sector {wlc.sector}: sum={s:.6f} > max_pct={wlc.max_pct}"
                )

    @pytest.mark.parametrize("seed", range(50))
    def test_mip_solution_certified(self, seed):
        """Every MIP solution must satisfy all constraints."""
        rng = np.random.RandomState(800 + seed)
        n = rng.randint(3, 15)
        max_sel = rng.randint(1, n + 1)
        min_sel = rng.randint(1, max_sel + 1)
        min_w = round(rng.uniform(0.0, 0.15), 2)
        max_w = round(rng.uniform(max(min_w + 0.05, 0.10), 0.80), 2)

        # Random exclusions
        all_pairs = [(i, j) for i in range(n) for j in range(i + 1, n)]
        n_excl = rng.randint(0, min(4, len(all_pairs) + 1))
        excl_idx = rng.choice(len(all_pairs), size=n_excl, replace=False) if n_excl > 0 else []
        excl = [all_pairs[i] for i in excl_idx]

        r = check_mip_feasibility(
            n_assets=n,
            cardinality=CardinalityConstraint(min_assets=min_sel, max_assets=max_sel),
            weight_limits=[],
            budget=BudgetConstraint(total=1.0),
            position_bounds=PositionBoundsConstraint(min_w=min_w, max_w=max_w),
            exclusions=[ExclusionConstraint(a, b) for a, b in excl],
        )
        if r["feasible"]:
            w = r["weights"]
            z = r["selected"]

            # Budget
            assert abs(np.sum(w) - 1.0) < 1e-4, f"Budget: sum={np.sum(w)}"

            # Cardinality
            n_sel = int(np.sum(z))
            assert min_sel <= n_sel <= max_sel, f"Cardinality: {n_sel} not in [{min_sel},{max_sel}]"

            # Bounds + linking
            for i in range(n):
                if z[i] == 1:
                    assert w[i] >= min_w - 1e-6, f"w[{i}]={w[i]} < min_w"
                    assert w[i] <= max_w + 1e-6, f"w[{i}]={w[i]} > max_w"
                else:
                    assert w[i] < 1e-4, f"w[{i}]={w[i]} but not selected"

            # Exclusions
            for a, b in excl:
                assert not (z[a] == 1 and z[b] == 1), f"Exclusion ({a},{b}) violated"


class TestCVaRProperties:
    """CVaR mathematical properties that must always hold."""

    @pytest.mark.parametrize("seed", range(20))
    def test_cvar_geq_var(self, seed):
        """CVaR must always be >= VaR (by definition)."""
        rng = np.random.RandomState(900 + seed)
        n = rng.randint(3, 15)
        S = rng.randint(20, 100)
        returns = rng.normal(0.01, 0.05, (S, n))
        confidence = round(rng.uniform(0.90, 0.99), 2)

        r = check_cvar_feasibility(
            n_assets=n, confidence=confidence, max_cvar=1.0,
            returns=returns, budget_total=1.0, min_w=0.0, max_w=1.0,
        )
        if r["feasible"] and r["var"] is not None and r["cvar"] is not None:
            assert r["cvar"] >= r["var"] - 1e-6, (
                f"CVaR={r['cvar']:.6f} < VaR={r['var']:.6f}"
            )

    @pytest.mark.parametrize("seed", range(20))
    def test_cvar_solution_matches_definition(self, seed):
        """Verify CVaR from solution matches Rockafellar-Uryasev definition."""
        rng = np.random.RandomState(1000 + seed)
        n = rng.randint(3, 10)
        S = rng.randint(30, 80)
        returns = rng.normal(0.02, 0.08, (S, n))
        confidence = 0.95

        r = check_cvar_feasibility(
            n_assets=n, confidence=confidence, max_cvar=0.50,
            returns=returns, budget_total=1.0, min_w=0.0, max_w=1.0,
        )
        if r["feasible"]:
            w = r["weights"]
            # Compute portfolio losses
            portfolio_returns = returns @ w
            losses = -portfolio_returns
            # VaR at confidence level
            var_empirical = np.quantile(losses, confidence)
            # CVaR = mean of losses > VaR
            tail_losses = losses[losses >= var_empirical]
            if len(tail_losses) > 0:
                cvar_empirical = np.mean(tail_losses)
                # The LP CVaR should be <= max_cvar (which is 0.50 here)
                # Empirical CVaR can differ slightly due to quantile discretization
                assert r["cvar"] <= 0.50 + 1e-4, (
                    f"LP CVaR={r['cvar']:.6f} > max_cvar=0.50"
                )

    @pytest.mark.parametrize("seed", range(15))
    def test_zero_vol_always_feasible(self, seed):
        """If all returns are identical (zero vol), CVaR is deterministic."""
        rng = np.random.RandomState(1100 + seed)
        n = rng.randint(2, 10)
        S = 50
        # All scenarios identical -> zero volatility
        base_return = rng.uniform(-0.05, 0.05, n)
        returns = np.tile(base_return, (S, 1))

        r = check_cvar_feasibility(
            n_assets=n, confidence=0.95, max_cvar=0.50,
            returns=returns, budget_total=1.0, min_w=0.0, max_w=1.0,
        )
        # Zero vol -> CVaR = loss of any scenario. If mean return > -0.50, feasible.
        expected_loss = -np.mean(base_return)  # equal weight
        # Should be feasible if we can find any w with loss <= 0.50
        if expected_loss <= 0.50:
            assert r["feasible"], (
                f"Zero-vol with expected_loss={expected_loss:.4f} should be feasible"
            )


class TestDualityGap:
    """If we solve both the primal and a tightened/relaxed version,
    the feasibility frontier must be consistent."""

    @pytest.mark.parametrize("n", [3, 5, 8, 10, 15, 20])
    def test_critical_max_w_is_1_over_n(self, n):
        """For n assets, budget=1.0, min_w=0: critical max_w is 1/n.
        Below 1/n: infeasible. At 1/n: feasible. Above 1/n: feasible."""
        critical = 1.0 / n

        # Just below
        below = check_lp_feasibility(
            n_assets=n, weight_limits=[],
            budget=BudgetConstraint(total=1.0),
            position_bounds=PositionBoundsConstraint(min_w=0.0, max_w=critical - 0.001),
        )
        assert not below["feasible"], f"n={n}: max_w={critical - 0.001} should be infeasible"

        # Exactly at
        exact = check_lp_feasibility(
            n_assets=n, weight_limits=[],
            budget=BudgetConstraint(total=1.0),
            position_bounds=PositionBoundsConstraint(min_w=0.0, max_w=critical),
        )
        assert exact["feasible"], f"n={n}: max_w={critical} should be feasible"

        # Just above
        above = check_lp_feasibility(
            n_assets=n, weight_limits=[],
            budget=BudgetConstraint(total=1.0),
            position_bounds=PositionBoundsConstraint(min_w=0.0, max_w=critical + 0.001),
        )
        assert above["feasible"], f"n={n}: max_w={critical + 0.001} should be feasible"

    @pytest.mark.parametrize("n,k", [
        (4, 2), (5, 2), (5, 3), (6, 2), (6, 3), (8, 3), (8, 4), (10, 5),
    ])
    def test_critical_max_w_for_cardinality(self, n, k):
        """With cardinality=k, critical max_w = 1/k."""
        critical = 1.0 / k

        below = check_mip_feasibility(
            n_assets=n,
            cardinality=CardinalityConstraint(min_assets=k, max_assets=k),
            weight_limits=[],
            budget=BudgetConstraint(total=1.0),
            position_bounds=PositionBoundsConstraint(min_w=0.0, max_w=critical - 0.001),
        )
        assert not below["feasible"]

        exact = check_mip_feasibility(
            n_assets=n,
            cardinality=CardinalityConstraint(min_assets=k, max_assets=k),
            weight_limits=[],
            budget=BudgetConstraint(total=1.0),
            position_bounds=PositionBoundsConstraint(min_w=0.0, max_w=critical),
        )
        assert exact["feasible"]
