"""Monotonicity tests: tightening constraints should never make infeasible->feasible."""

import numpy as np
import pytest
from portfolio_optimizer import PortfolioChecker


class TestMonotonicity:
    """If a problem is infeasible, making it tighter should stay infeasible."""

    def test_reducing_max_assets_preserves_infeasibility(self):
        """If infeasible at max=K, still infeasible at max=K-1."""
        for max_val in [5, 4, 3, 2, 1]:
            pc = PortfolioChecker(n_assets=10)
            pc.add_cardinality(min_assets=6, max_assets=max_val)
            result = pc.check_feasibility()
            assert not result.feasible, f"max={max_val} should be infeasible (min=6)"

    def test_increasing_min_assets_preserves_infeasibility(self):
        """If infeasible at min=M, still infeasible at min=M+1."""
        for min_val in [6, 7, 8, 9, 10, 11]:
            pc = PortfolioChecker(n_assets=10)
            pc.add_cardinality(min_assets=min_val, max_assets=5)
            result = pc.check_feasibility()
            assert not result.feasible, f"min={min_val} should be infeasible (max=5)"

    def test_reducing_max_w_preserves_infeasibility(self):
        """If max_w too small, reducing it further stays infeasible."""
        for max_w in [0.10, 0.08, 0.05, 0.01]:
            pc = PortfolioChecker(n_assets=5)
            pc.add_budget(total=1.0)
            pc.add_position_bounds(min_w=0.0, max_w=max_w)
            result = pc.check_feasibility()
            assert not result.feasible, f"max_w={max_w} should be infeasible (5 assets)"

    def test_increasing_min_w_preserves_infeasibility(self):
        """If min_w too large, increasing it stays infeasible."""
        for min_w in [0.30, 0.40, 0.50, 0.80]:
            pc = PortfolioChecker(n_assets=5)
            pc.add_budget(total=1.0)
            pc.add_position_bounds(min_w=min_w, max_w=1.0)
            result = pc.check_feasibility()
            assert not result.feasible, f"min_w={min_w} should be infeasible (5*min > 1.0)"

    def test_adding_exclusions_preserves_infeasibility(self):
        """If infeasible with some exclusions, adding more stays infeasible."""
        # Base case: 3 assets, all pairs excluded, min 2
        base_excl = [(0, 1), (0, 2), (1, 2)]
        for n_extra in range(4):
            pc = PortfolioChecker(n_assets=3 + n_extra)
            pc.add_cardinality(min_assets=2)
            for a, b in base_excl:
                pc.add_exclusion(a, b)
            # Add extra exclusions for new assets
            for i in range(3, 3 + n_extra):
                for j in range(i):
                    pc.add_exclusion(j, i)
            result = pc.check_feasibility()
            assert not result.feasible

    def test_tightening_cvar_preserves_infeasibility(self):
        """If infeasible at max_cvar=X, still infeasible at max_cvar < X."""
        np.random.seed(42)
        returns = np.random.normal(-0.50, 0.10, (50, 5))
        for max_cvar in [0.05, 0.03, 0.01, 0.001]:
            result_tight = PortfolioChecker(n_assets=5)
            result_tight.add_budget(total=1.0)
            result_tight.add_cvar_limit(confidence=0.95, max_cvar=max_cvar, returns=returns)
            r = result_tight.check_feasibility()
            assert not r.feasible, f"max_cvar={max_cvar} should be infeasible"

    def test_reducing_sector_max_pct_preserves_infeasibility(self):
        """If sector limits too tight, reducing further stays infeasible."""
        for max_pct in [0.30, 0.25, 0.20, 0.10]:
            pc = PortfolioChecker(n_assets=6)
            pc.add_budget(total=1.0)
            pc.add_weight_limit("A", [0, 1, 2], max_pct=max_pct)
            pc.add_weight_limit("B", [3, 4, 5], max_pct=max_pct)
            result = pc.check_feasibility()
            if 2 * max_pct < 1.0:
                assert not result.feasible, f"2*{max_pct}={2*max_pct} < 1.0, infeasible"


class TestRelaxation:
    """Relaxing constraints should never make feasible->infeasible."""

    def test_increasing_max_assets(self):
        """Increasing max_assets should preserve feasibility."""
        prev_feasible = False
        for max_val in range(1, 11):
            pc = PortfolioChecker(n_assets=10)
            pc.add_cardinality(min_assets=3, max_assets=max_val)
            result = pc.check_feasibility()
            if prev_feasible:
                assert result.feasible, f"Was feasible at max={max_val-1}, should stay at max={max_val}"
            prev_feasible = result.feasible

    def test_increasing_max_w(self):
        """Increasing max_w should preserve LP feasibility."""
        prev_feasible = False
        for max_w_int in range(5, 105, 5):  # 0.05 to 1.00
            max_w = max_w_int / 100.0
            pc = PortfolioChecker(n_assets=5)
            pc.add_budget(total=1.0)
            pc.add_position_bounds(min_w=0.0, max_w=max_w)
            result = pc.check_feasibility()
            if prev_feasible:
                assert result.feasible, f"Was feasible at max_w={max_w-0.05}, should stay at max_w={max_w}"
            prev_feasible = result.feasible

    def test_increasing_max_cvar(self):
        """Increasing max_cvar should preserve feasibility."""
        np.random.seed(42)
        returns = np.random.normal(0.0, 0.10, (50, 5))
        prev_feasible = False
        for max_cvar_int in range(1, 51, 2):  # 0.01 to 0.50
            max_cvar = max_cvar_int / 100.0
            pc = PortfolioChecker(n_assets=5)
            pc.add_budget(total=1.0)
            pc.add_cvar_limit(confidence=0.95, max_cvar=max_cvar, returns=returns)
            result = pc.check_feasibility()
            if prev_feasible:
                assert result.feasible, f"Was feasible at max_cvar={max_cvar-0.02}, should stay at {max_cvar}"
            prev_feasible = result.feasible

    def test_increasing_sector_max_pct(self):
        """Increasing sector max_pct should preserve feasibility."""
        prev_feasible = False
        for pct_int in range(10, 55, 5):  # 0.10 to 0.50
            pct = pct_int / 100.0
            pc = PortfolioChecker(n_assets=6)
            pc.add_budget(total=1.0)
            pc.add_weight_limit("A", [0, 1, 2], max_pct=pct)
            pc.add_weight_limit("B", [3, 4, 5], max_pct=pct)
            result = pc.check_feasibility()
            if prev_feasible:
                assert result.feasible, f"Was feasible at pct={pct-0.05}, should stay at {pct}"
            prev_feasible = result.feasible
