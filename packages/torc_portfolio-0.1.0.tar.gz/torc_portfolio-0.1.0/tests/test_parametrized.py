"""Parametrized tests: systematic coverage with many parameter combinations."""

import numpy as np
import pytest
from portfolio_optimizer import PortfolioChecker
from portfolio_optimizer.lp_solver import check_lp_feasibility, check_mip_feasibility
from portfolio_optimizer.cvar_solver import check_cvar_feasibility
from portfolio_optimizer.constraints import (
    CardinalityConstraint, WeightLimitConstraint,
    BudgetConstraint, PositionBoundsConstraint, ExclusionConstraint,
)


# --- LP parametrized ---

class TestLPParametrized:
    """Systematically test LP feasibility across parameter space."""

    @pytest.mark.parametrize("n_assets,max_w,budget,expected", [
        (2, 0.50, 1.0, True),    # 2*0.50=1.0 == budget
        (2, 0.49, 1.0, False),   # 2*0.49=0.98 < 1.0
        (3, 0.34, 1.0, True),    # 3*0.34=1.02 >= 1.0
        (3, 0.33, 1.0, False),   # 3*0.33=0.99 < 1.0
        (4, 0.25, 1.0, True),    # exact fit
        (4, 0.24, 1.0, False),   # 4*0.24=0.96 < 1.0
        (5, 0.20, 1.0, True),    # exact fit
        (5, 0.19, 1.0, False),   # 5*0.19=0.95 < 1.0
        (10, 0.10, 1.0, True),   # exact fit
        (10, 0.09, 1.0, False),  # 10*0.09=0.90 < 1.0
        (20, 0.05, 1.0, True),   # exact fit
        (100, 0.01, 1.0, True),  # exact fit
        (100, 0.009, 1.0, False),# 100*0.009=0.90 < 1.0
        (5, 0.50, 0.5, True),    # budget < 1.0
        (5, 0.50, 2.0, True),    # budget > 1.0, max_w big enough
        (5, 0.30, 2.0, False),   # 5*0.30=1.50 < 2.0
    ])
    def test_max_w_vs_budget(self, n_assets, max_w, budget, expected):
        """Budget / (n_assets * max_w) determines feasibility."""
        result = check_lp_feasibility(
            n_assets=n_assets,
            weight_limits=[],
            budget=BudgetConstraint(total=budget),
            position_bounds=PositionBoundsConstraint(min_w=0.0, max_w=max_w),
        )
        assert result["feasible"] == expected, (
            f"n={n_assets}, max_w={max_w}, budget={budget}: "
            f"expected {'feasible' if expected else 'infeasible'}, "
            f"got {'feasible' if result['feasible'] else 'infeasible'}"
        )

    @pytest.mark.parametrize("n_assets,min_w,budget,expected", [
        (2, 0.50, 1.0, True),    # 2*0.50=1.0 == budget
        (2, 0.51, 1.0, False),   # 2*0.51=1.02 > 1.0
        (3, 0.33, 1.0, True),    # 3*0.33=0.99 <= 1.0
        (3, 0.34, 1.0, False),   # 3*0.34=1.02 > 1.0
        (5, 0.20, 1.0, True),    # exact fit
        (5, 0.21, 1.0, False),   # 5*0.21=1.05 > 1.0
        (10, 0.10, 1.0, True),   # exact fit
        (10, 0.11, 1.0, False),  # 10*0.11=1.10 > 1.0
    ])
    def test_min_w_vs_budget(self, n_assets, min_w, budget, expected):
        """min_w * n_assets vs budget."""
        result = check_lp_feasibility(
            n_assets=n_assets,
            weight_limits=[],
            budget=BudgetConstraint(total=budget),
            position_bounds=PositionBoundsConstraint(min_w=min_w, max_w=1.0),
        )
        assert result["feasible"] == expected

    @pytest.mark.parametrize("sector_a_max,sector_b_max,expected", [
        (0.50, 0.50, True),    # 0.50+0.50=1.00 >= budget
        (0.50, 0.49, False),   # 0.50+0.49=0.99 < budget (only these 2 sectors)
        (0.60, 0.40, True),    # 0.60+0.40=1.00
        (0.60, 0.50, True),    # 0.60+0.50=1.10 > 1.00
        (0.30, 0.30, False),   # 0.30+0.30=0.60 < 1.00
        (0.70, 0.30, True),    # 0.70+0.30=1.00
        (0.70, 0.29, False),   # 0.70+0.29=0.99 < 1.00
        (1.00, 0.00, True),    # all in sector A
        (0.00, 1.00, True),    # all in sector B
    ])
    def test_two_sector_max(self, sector_a_max, sector_b_max, expected):
        """Two disjoint sectors covering all assets."""
        result = check_lp_feasibility(
            n_assets=6,
            weight_limits=[
                WeightLimitConstraint("A", [0, 1, 2], max_pct=sector_a_max),
                WeightLimitConstraint("B", [3, 4, 5], max_pct=sector_b_max),
            ],
            budget=BudgetConstraint(total=1.0),
            position_bounds=None,
        )
        assert result["feasible"] == expected


# --- MIP parametrized ---

class TestMIPParametrized:
    """Systematically test MIP feasibility."""

    @pytest.mark.parametrize("n,min_sel,max_sel,min_w,max_w,expected", [
        (10, 5, 5, 0.20, 0.20, True),   # 5*0.20=1.00 exact
        (10, 5, 5, 0.21, 0.21, False),  # 5*0.21=1.05 > 1.00
        (10, 5, 5, 0.19, 0.19, False),  # 5*0.19=0.95 < 1.00
        (10, 3, 5, 0.10, 0.40, True),   # 3*0.10=0.30, 5*0.40=2.0, budget=1.0 in range
        (10, 3, 5, 0.25, 0.40, True),   # select 3 at ~0.33 each (in [0.25,0.40]), sum=1.0
        (10, 10, 10, 0.10, 0.10, True), # 10*0.10=1.00 exact
        (10, 1, 1, 1.0, 1.0, True),     # 1 asset with weight 1.0
        (10, 1, 10, 0.0, 1.0, True),    # very loose
        (10, 10, 10, 0.11, 0.11, False),# 10*0.11=1.10 > 1.00
    ])
    def test_cardinality_vs_bounds(self, n, min_sel, max_sel, min_w, max_w, expected):
        result = check_mip_feasibility(
            n_assets=n,
            cardinality=CardinalityConstraint(min_assets=min_sel, max_assets=max_sel),
            weight_limits=[],
            budget=BudgetConstraint(total=1.0),
            position_bounds=PositionBoundsConstraint(min_w=min_w, max_w=max_w),
        )
        assert result["feasible"] == expected, (
            f"n={n}, sel=[{min_sel},{max_sel}], w=[{min_w},{max_w}]: "
            f"expected {expected}"
        )

    @pytest.mark.parametrize("n_excl,expected", [
        (0, True),    # no exclusions, select 3 of 6
        (1, True),    # 1 exclusion, still feasible
        (3, True),    # 3 exclusions (matching), still feasible
        (6, True),    # 6 exclusions (path 0-1-2-3-4-5), pick {0,2,4}
    ])
    def test_exclusion_count(self, n_excl, expected):
        """Path exclusions 0-1, 1-2, ..., with cardinality 3 of 6."""
        exclusions = [ExclusionConstraint(i, i+1) for i in range(min(n_excl, 5))]
        result = check_mip_feasibility(
            n_assets=6,
            cardinality=CardinalityConstraint(min_assets=3, max_assets=3),
            weight_limits=[],
            budget=BudgetConstraint(total=1.0),
            position_bounds=PositionBoundsConstraint(min_w=0.10, max_w=0.50),
            exclusions=exclusions,
        )
        assert result["feasible"] == expected


# --- CVaR parametrized ---

class TestCVaRParametrized:
    """Systematically test CVaR across confidence/risk levels."""

    @pytest.mark.parametrize("confidence", [0.50, 0.75, 0.90, 0.95, 0.99])
    def test_positive_returns_always_feasible(self, confidence):
        """All positive returns -> CVaR is negative -> any positive max_cvar works."""
        np.random.seed(42)
        returns = np.random.normal(0.10, 0.01, (50, 5))
        result = check_cvar_feasibility(
            n_assets=5, confidence=confidence, max_cvar=0.10, returns=returns,
        )
        assert result["feasible"]

    @pytest.mark.parametrize("confidence", [0.50, 0.75, 0.90, 0.95, 0.99])
    def test_very_negative_always_infeasible(self, confidence):
        """All very negative returns, tight limit -> infeasible at any confidence."""
        np.random.seed(42)
        returns = np.random.normal(-1.0, 0.01, (50, 5))
        result = check_cvar_feasibility(
            n_assets=5, confidence=confidence, max_cvar=0.001, returns=returns,
        )
        assert not result["feasible"]

    @pytest.mark.parametrize("max_cvar", [0.01, 0.05, 0.10, 0.20, 0.50, 1.0, 5.0])
    def test_increasing_max_cvar(self, max_cvar):
        """Looser CVaR limit should never make feasible->infeasible."""
        np.random.seed(42)
        returns = np.random.normal(0.0, 0.10, (100, 5))
        result = check_cvar_feasibility(
            n_assets=5, confidence=0.95, max_cvar=max_cvar, returns=returns,
        )
        # We can't assert a specific value, but 5.0 should definitely be feasible
        if max_cvar >= 5.0:
            assert result["feasible"]

    @pytest.mark.parametrize("n_assets", [1, 2, 3, 5, 10, 20, 50])
    def test_different_asset_counts(self, n_assets):
        """CVaR solver should handle different asset counts."""
        np.random.seed(42)
        returns = np.random.normal(0.02, 0.05, (50, n_assets))
        result = check_cvar_feasibility(
            n_assets=n_assets, confidence=0.95, max_cvar=0.50, returns=returns,
        )
        assert result["feasible"]

    @pytest.mark.parametrize("n_scenarios", [2, 5, 10, 50, 100, 200])
    def test_different_scenario_counts(self, n_scenarios):
        """CVaR solver should handle different scenario counts."""
        np.random.seed(42)
        returns = np.random.normal(0.02, 0.05, (n_scenarios, 5))
        result = check_cvar_feasibility(
            n_assets=5, confidence=0.95, max_cvar=0.50, returns=returns,
        )
        assert result["feasible"]


# --- Quick checks parametrized ---

class TestQuickChecksParametrized:
    """Parametrized quick check tests."""

    @pytest.mark.parametrize("n,min_a,max_a,expected_issue", [
        (10, 0, 10, False),    # valid range
        (10, 5, 5, False),     # exact
        (10, 0, 0, False),     # select none
        (10, 11, None, True),  # min > n
        (10, 8, 3, True),      # min > max
        (10, 5, 10, False),    # normal
        (1, 1, 1, False),      # single asset
        (1, 2, None, True),    # min > n (single)
    ])
    def test_cardinality_ranges(self, n, min_a, max_a, expected_issue):
        pc = PortfolioChecker(n_assets=n)
        pc.add_cardinality(min_assets=min_a, max_assets=max_a)
        result = pc.check_feasibility()
        if expected_issue:
            assert not result.feasible
        # If no issue expected, just check it doesn't crash
        # (may still be infeasible for other reasons)

    @pytest.mark.parametrize("n_sectors,min_each,max_total,expected_infeasible", [
        (2, 3, 10, False),   # 2*3=6 <= 10
        (2, 3, 5, True),     # 2*3=6 > 5 -> infeasible
        (3, 2, 6, False),    # 3*2=6 == 6
        (3, 2, 5, True),     # 3*2=6 > 5
        (4, 3, 12, False),   # 4*3=12 == 12
        (4, 3, 11, True),    # 4*3=12 > 11
        (5, 1, 5, False),    # 5*1=5 == 5
        (5, 1, 4, True),     # 5*1=5 > 4
        (10, 1, 10, False),  # 10*1=10 == 10
        (10, 1, 9, True),    # 10*1=10 > 9
    ])
    def test_sector_sum_vs_max(self, n_sectors, min_each, max_total, expected_infeasible):
        n_per_sector = 5
        n_assets = n_sectors * n_per_sector
        pc = PortfolioChecker(n_assets=n_assets)
        pc.add_cardinality(max_assets=max_total)
        for i in range(n_sectors):
            assets = list(range(i * n_per_sector, (i + 1) * n_per_sector))
            pc.add_sector_min(f"S{i}", assets=assets, min_count=min_each)
        result = pc.check_feasibility()
        if expected_infeasible:
            assert not result.feasible
        else:
            assert result.feasible


# --- Checker integration parametrized ---

class TestCheckerParametrized:
    """Parametrized integration tests across the full pipeline."""

    @pytest.mark.parametrize("n_assets", [1, 2, 3, 5, 10, 20, 50, 100])
    def test_equal_weight_always_feasible(self, n_assets):
        """n assets, select all, equal weight = 1/n."""
        if n_assets == 0:
            return
        w = 1.0 / n_assets
        pc = PortfolioChecker(n_assets=n_assets)
        pc.add_cardinality(min_assets=n_assets, max_assets=n_assets)
        pc.add_budget(total=1.0)
        pc.add_position_bounds(min_w=w, max_w=w)
        result = pc.check_feasibility()
        assert result.feasible, f"n={n_assets}, w={w}: should be feasible"

    @pytest.mark.parametrize("n_assets,select", [
        (5, 3), (10, 5), (20, 10), (50, 25), (100, 50),
    ])
    def test_select_half_feasible(self, n_assets, select):
        """Select half the assets with reasonable bounds."""
        pc = PortfolioChecker(n_assets=n_assets)
        pc.add_cardinality(min_assets=select, max_assets=select)
        pc.add_budget(total=1.0)
        min_w = 0.5 / select
        max_w = 2.0 / select
        pc.add_position_bounds(min_w=min_w, max_w=max_w)
        result = pc.check_feasibility()
        assert result.feasible

    @pytest.mark.parametrize("n_assets", [3, 5, 10, 20])
    def test_all_pairs_excluded_infeasible(self, n_assets):
        """All pairs excluded + min 2 -> always infeasible."""
        pc = PortfolioChecker(n_assets=n_assets)
        pc.add_cardinality(min_assets=2)
        for i in range(n_assets):
            for j in range(i + 1, n_assets):
                pc.add_exclusion(i, j)
        result = pc.check_feasibility()
        assert not result.feasible
