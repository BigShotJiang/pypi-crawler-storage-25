"""Exhaustive verification: for small instances, enumerate ALL possible
selections and check LP feasibility for each. Compare with MIP result.

This is the ultimate ground truth — brute force.
No solver (Gurobi, CPLEX, scipy) can argue with enumeration.
"""

import itertools
import numpy as np
import pytest
from scipy.optimize import linprog

from portfolio_optimizer.lp_solver import check_lp_feasibility, check_mip_feasibility
from portfolio_optimizer.constraints import (
    CardinalityConstraint, BudgetConstraint, PositionBoundsConstraint,
    WeightLimitConstraint, ExclusionConstraint,
)


def _brute_force_feasible(
    n_assets: int,
    min_sel: int,
    max_sel: int,
    min_w: float,
    max_w: float,
    budget: float,
    weight_limits: list[WeightLimitConstraint] | None = None,
    exclusions: list[tuple[int, int]] | None = None,
) -> tuple[bool, list[int] | None]:
    """Enumerate all subsets of size [min_sel, max_sel] and check LP for each.

    Returns (feasible, witness_subset) where witness is the first feasible subset found.
    """
    weight_limits = weight_limits or []
    exclusions = exclusions or []
    excl_set = set((min(a, b), max(a, b)) for a, b in exclusions)

    for k in range(min_sel, max_sel + 1):
        for subset in itertools.combinations(range(n_assets), k):
            # Check exclusions
            excl_violated = False
            for i in range(len(subset)):
                for j in range(i + 1, len(subset)):
                    pair = (min(subset[i], subset[j]), max(subset[i], subset[j]))
                    if pair in excl_set:
                        excl_violated = True
                        break
                if excl_violated:
                    break
            if excl_violated:
                continue

            # Check LP feasibility for this subset
            m = len(subset)
            c_obj = np.zeros(m)
            A_eq = [np.ones(m)]
            b_eq = [budget]
            A_ub = []
            b_ub = []
            bounds = [(min_w, max_w)] * m

            # Weight limits (sector constraints)
            subset_list = list(subset)
            for wl in weight_limits:
                row = np.zeros(m)
                for idx, asset in enumerate(subset_list):
                    if asset in wl.assets:
                        row[idx] = 1.0
                if wl.max_pct < 1.0:
                    A_ub.append(row.copy())
                    b_ub.append(wl.max_pct)
                if wl.min_pct > 0.0:
                    A_ub.append(-row.copy())
                    b_ub.append(-wl.min_pct)

            A_eq_arr = np.array(A_eq)
            b_eq_arr = np.array(b_eq)
            A_ub_arr = np.array(A_ub) if A_ub else None
            b_ub_arr = np.array(b_ub) if b_ub else None

            result = linprog(
                c_obj, A_ub=A_ub_arr, b_ub=b_ub_arr,
                A_eq=A_eq_arr, b_eq=b_eq_arr, bounds=bounds, method="highs",
            )
            if result.success:
                return True, list(subset)

    return False, None


class TestExhaustiveSmall:
    """Brute force verification for n <= 7."""

    @pytest.mark.parametrize("n,min_sel,max_sel,min_w,max_w", [
        (4, 2, 2, 0.40, 0.60),     # 2*0.40=0.80, 2*0.60=1.20 -> feasible
        (4, 2, 2, 0.60, 0.60),     # 2*0.60=1.20 > 1.0 -> infeasible
        (4, 2, 2, 0.50, 0.50),     # 2*0.50=1.00 exact -> feasible
        (4, 4, 4, 0.25, 0.25),     # 4*0.25=1.00 exact -> feasible
        (4, 4, 4, 0.26, 0.26),     # 4*0.26=1.04 > 1.0 -> infeasible
        (5, 2, 3, 0.30, 0.50),     # feasible
        (5, 3, 3, 0.35, 0.35),     # 3*0.35=1.05 -> infeasible
        (5, 5, 5, 0.20, 0.20),     # 5*0.20=1.00 exact
        (6, 3, 3, 0.25, 0.40),     # feasible
        (6, 2, 4, 0.10, 0.60),     # feasible
        (6, 6, 6, 0.10, 0.20),     # 6*0.10=0.60, 6*0.20=1.20 -> feasible
        (6, 6, 6, 0.20, 0.20),     # 6*0.20=1.20 > 1.0 -> infeasible
        (7, 3, 5, 0.10, 0.40),     # feasible
        (7, 7, 7, 0.15, 0.15),     # 7*0.15=1.05 -> infeasible
        (7, 4, 4, 0.25, 0.25),     # 4*0.25=1.00 exact -> feasible
    ])
    def test_mip_matches_brute_force(self, n, min_sel, max_sel, min_w, max_w):
        """MIP result MUST match brute force enumeration."""
        brute_feasible, _ = _brute_force_feasible(
            n, min_sel, max_sel, min_w, max_w, budget=1.0,
        )
        mip_result = check_mip_feasibility(
            n_assets=n,
            cardinality=CardinalityConstraint(min_assets=min_sel, max_assets=max_sel),
            weight_limits=[],
            budget=BudgetConstraint(total=1.0),
            position_bounds=PositionBoundsConstraint(min_w=min_w, max_w=max_w),
        )
        assert mip_result["feasible"] == brute_feasible, (
            f"n={n}, sel=[{min_sel},{max_sel}], w=[{min_w},{max_w}]: "
            f"MIP={mip_result['feasible']}, brute={brute_feasible}"
        )


class TestExhaustiveWithExclusions:
    """Brute force with exclusion constraints."""

    @pytest.mark.parametrize("n,min_sel,max_sel,excl,expected_feasible", [
        # 4 assets, select 2, exclude (0,1)
        (4, 2, 2, [(0, 1)], True),           # can pick {0,2}, {0,3}, etc
        # 4 assets, select 2, exclude all pairs -> impossible
        (4, 2, 2, [(0, 1), (0, 2), (0, 3), (1, 2), (1, 3), (2, 3)], False),
        # 4 assets, select 3, exclude (0,1) -> {0,2,3} or {1,2,3}
        (4, 3, 3, [(0, 1)], True),
        # 5 assets, select 3, path exclusions
        (5, 3, 3, [(0, 1), (1, 2), (2, 3), (3, 4)], True),  # {0,2,4}
        # 5 assets, select 3, K5 (all pairs) -> impossible
        (5, 3, 3, [(i, j) for i in range(5) for j in range(i + 1, 5)], False),
        # 6 assets, select 3, triangle on {0,1,2}
        (6, 3, 3, [(0, 1), (0, 2), (1, 2)], True),  # pick from {3,4,5}
        # 5 assets, select 2, star from 0
        (5, 2, 2, [(0, 1), (0, 2), (0, 3), (0, 4)], True),  # {1,2}, {1,3}, etc
    ])
    def test_exclusions_brute_force(self, n, min_sel, max_sel, excl, expected_feasible):
        """Verify MIP with exclusions matches brute force."""
        brute_feasible, _ = _brute_force_feasible(
            n, min_sel, max_sel, min_w=0.10, max_w=0.50,
            budget=1.0, exclusions=excl,
        )
        assert brute_feasible == expected_feasible, (
            f"Brute force disagrees with expected: brute={brute_feasible}"
        )

        mip_result = check_mip_feasibility(
            n_assets=n,
            cardinality=CardinalityConstraint(min_assets=min_sel, max_assets=max_sel),
            weight_limits=[],
            budget=BudgetConstraint(total=1.0),
            position_bounds=PositionBoundsConstraint(min_w=0.10, max_w=0.50),
            exclusions=[ExclusionConstraint(a, b) for a, b in excl],
        )
        assert mip_result["feasible"] == brute_feasible, (
            f"MIP disagrees with brute force: MIP={mip_result['feasible']}, brute={brute_feasible}"
        )


class TestExhaustiveWithSectors:
    """Brute force with sector weight limits."""

    @pytest.mark.parametrize("n,min_sel,max_sel,min_w,max_w,sectors,expected", [
        # 6 assets, 2 sectors [0,1,2] and [3,4,5], each max 60%
        (6, 3, 3, 0.20, 0.40, [([0, 1, 2], 0.0, 0.60), ([3, 4, 5], 0.0, 0.60)], True),
        # Same but max 30% per sector -> 2 sectors * 30% = 60% < 100%
        (6, 3, 3, 0.20, 0.40, [([0, 1, 2], 0.0, 0.30), ([3, 4, 5], 0.0, 0.30)], False),
        # 6 assets, 2 sectors, sector A min 40%, sector B min 40%
        (6, 4, 4, 0.10, 0.40, [([0, 1, 2], 0.40, 1.0), ([3, 4, 5], 0.40, 1.0)], True),
        # Sector A requires 80% but only has 3 assets at max 0.30 each = 0.90 >= 0.80
        (6, 6, 6, 0.10, 0.30, [([0, 1, 2], 0.80, 1.0)], False),
        # 8 assets, 2 sectors, balanced
        (8, 4, 4, 0.20, 0.30, [([0, 1, 2, 3], 0.0, 0.60), ([4, 5, 6, 7], 0.0, 0.60)], True),
    ])
    def test_sectors_brute_force(self, n, min_sel, max_sel, min_w, max_w, sectors, expected):
        """Verify MIP with sectors matches brute force."""
        wl = [
            WeightLimitConstraint(f"S{i}", assets, min_pct=mn, max_pct=mx)
            for i, (assets, mn, mx) in enumerate(sectors)
        ]
        brute_feasible, _ = _brute_force_feasible(
            n, min_sel, max_sel, min_w, max_w, budget=1.0, weight_limits=wl,
        )
        assert brute_feasible == expected, (
            f"Brute force disagrees: brute={brute_feasible}, expected={expected}"
        )
        mip_result = check_mip_feasibility(
            n_assets=n,
            cardinality=CardinalityConstraint(min_assets=min_sel, max_assets=max_sel),
            weight_limits=wl,
            budget=BudgetConstraint(total=1.0),
            position_bounds=PositionBoundsConstraint(min_w=min_w, max_w=max_w),
        )
        assert mip_result["feasible"] == brute_feasible, (
            f"MIP disagrees with brute force: MIP={mip_result['feasible']}, brute={brute_feasible}"
        )


class TestExhaustiveCombined:
    """Brute force with exclusions + sectors simultaneously."""

    def test_excl_plus_sectors_n6(self):
        """6 assets, exclusions + sector limits."""
        excl = [(0, 3), (1, 4)]
        wl = [
            WeightLimitConstraint("A", [0, 1, 2], min_pct=0.0, max_pct=0.50),
            WeightLimitConstraint("B", [3, 4, 5], min_pct=0.0, max_pct=0.60),
        ]
        brute, witness = _brute_force_feasible(
            6, 3, 3, 0.20, 0.40, budget=1.0,
            weight_limits=wl, exclusions=excl,
        )
        mip = check_mip_feasibility(
            n_assets=6,
            cardinality=CardinalityConstraint(min_assets=3, max_assets=3),
            weight_limits=wl,
            budget=BudgetConstraint(total=1.0),
            position_bounds=PositionBoundsConstraint(min_w=0.20, max_w=0.40),
            exclusions=[ExclusionConstraint(a, b) for a, b in excl],
        )
        assert mip["feasible"] == brute

    def test_tight_combined_n7(self):
        """7 assets, 3 exclusions, 2 sectors, tight bounds."""
        excl = [(0, 1), (2, 3), (4, 5)]
        wl = [
            WeightLimitConstraint("X", [0, 1, 2, 3], min_pct=0.30, max_pct=0.60),
            WeightLimitConstraint("Y", [3, 4, 5, 6], min_pct=0.30, max_pct=0.60),
        ]
        brute, _ = _brute_force_feasible(
            7, 4, 4, 0.15, 0.35, budget=1.0,
            weight_limits=wl, exclusions=excl,
        )
        mip = check_mip_feasibility(
            n_assets=7,
            cardinality=CardinalityConstraint(min_assets=4, max_assets=4),
            weight_limits=wl,
            budget=BudgetConstraint(total=1.0),
            position_bounds=PositionBoundsConstraint(min_w=0.15, max_w=0.35),
            exclusions=[ExclusionConstraint(a, b) for a, b in excl],
        )
        assert mip["feasible"] == brute

    @pytest.mark.parametrize("seed", range(20))
    def test_random_n6_brute_vs_mip(self, seed):
        """Random problem with n=6, verify MIP matches brute force."""
        rng = np.random.RandomState(seed)
        n = 6
        min_sel = rng.randint(1, n + 1)
        max_sel = rng.randint(min_sel, n + 1)
        min_w = round(rng.uniform(0.05, 0.30), 2)
        max_w = round(rng.uniform(min_w, min(0.80, 1.0)), 2)

        # Random exclusions (0-3 pairs)
        n_excl = rng.randint(0, 4)
        all_pairs = [(i, j) for i in range(n) for j in range(i + 1, n)]
        if n_excl > 0 and len(all_pairs) > 0:
            excl_idx = rng.choice(len(all_pairs), size=min(n_excl, len(all_pairs)), replace=False)
            excl = [all_pairs[i] for i in excl_idx]
        else:
            excl = []

        brute, _ = _brute_force_feasible(
            n, min_sel, max_sel, min_w, max_w, budget=1.0, exclusions=excl,
        )
        mip = check_mip_feasibility(
            n_assets=n,
            cardinality=CardinalityConstraint(min_assets=min_sel, max_assets=max_sel),
            weight_limits=[],
            budget=BudgetConstraint(total=1.0),
            position_bounds=PositionBoundsConstraint(min_w=min_w, max_w=max_w),
            exclusions=[ExclusionConstraint(a, b) for a, b in excl],
        )
        assert mip["feasible"] == brute, (
            f"seed={seed}: n={n}, sel=[{min_sel},{max_sel}], w=[{min_w},{max_w}], "
            f"excl={excl}: MIP={mip['feasible']}, brute={brute}"
        )

    @pytest.mark.parametrize("seed", range(20))
    def test_random_n7_sectors_brute_vs_mip(self, seed):
        """Random problem with n=7, sectors, verify brute force."""
        rng = np.random.RandomState(100 + seed)
        n = 7
        min_sel = rng.randint(2, 5)
        max_sel = rng.randint(min_sel, min(min_sel + 3, n + 1))
        min_w = round(rng.uniform(0.05, 0.25), 2)
        max_w = round(rng.uniform(max(min_w + 0.05, 0.15), 0.60), 2)

        # Random sector split
        split = rng.randint(2, n - 1)
        sec_a_max = round(rng.uniform(0.40, 0.80), 2)
        sec_b_max = round(rng.uniform(0.40, 0.80), 2)
        wl = [
            WeightLimitConstraint("A", list(range(split)), min_pct=0.0, max_pct=sec_a_max),
            WeightLimitConstraint("B", list(range(split, n)), min_pct=0.0, max_pct=sec_b_max),
        ]

        brute, _ = _brute_force_feasible(
            n, min_sel, max_sel, min_w, max_w, budget=1.0, weight_limits=wl,
        )
        mip = check_mip_feasibility(
            n_assets=n,
            cardinality=CardinalityConstraint(min_assets=min_sel, max_assets=max_sel),
            weight_limits=wl,
            budget=BudgetConstraint(total=1.0),
            position_bounds=PositionBoundsConstraint(min_w=min_w, max_w=max_w),
        )
        assert mip["feasible"] == brute, (
            f"seed={seed}: n={n}, sel=[{min_sel},{max_sel}], w=[{min_w},{max_w}], "
            f"sec_split={split}, sec_max=[{sec_a_max},{sec_b_max}]: "
            f"MIP={mip['feasible']}, brute={brute}"
        )
