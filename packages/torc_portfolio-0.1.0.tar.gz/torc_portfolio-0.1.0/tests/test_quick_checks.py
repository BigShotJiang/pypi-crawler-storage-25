"""Tests for quick arithmetic checks."""

import pytest
from portfolio_optimizer.quick_checks import run_quick_checks
from portfolio_optimizer.constraints import (
    CardinalityConstraint,
    SectorMinConstraint,
    WeightLimitConstraint,
    BudgetConstraint,
    PositionBoundsConstraint,
)


class TestSectorMinsVsMax:
    """Sector minimums exceeding cardinality max."""

    def test_two_sectors_exceed(self):
        result = run_quick_checks(
            n_assets=20,
            cardinality=CardinalityConstraint(min_assets=0, max_assets=5),
            sector_mins=[
                SectorMinConstraint("tech", list(range(10)), 3),
                SectorMinConstraint("health", list(range(10, 20)), 3),
            ],
            weight_limits=[], budget=None, position_bounds=None,
        )
        assert result is not None
        assert not result.feasible
        assert "sector_min" in str(result.infeasible_constraints)

    def test_three_sectors_exceed(self):
        result = run_quick_checks(
            n_assets=30,
            cardinality=CardinalityConstraint(min_assets=0, max_assets=6),
            sector_mins=[
                SectorMinConstraint("A", list(range(10)), 3),
                SectorMinConstraint("B", list(range(10, 20)), 3),
                SectorMinConstraint("C", list(range(20, 30)), 3),
            ],
            weight_limits=[], budget=None, position_bounds=None,
        )
        assert result is not None
        assert not result.feasible

    def test_sectors_within_max(self):
        """2+2=4 <= max 5 -> no contradiction."""
        result = run_quick_checks(
            n_assets=20,
            cardinality=CardinalityConstraint(min_assets=0, max_assets=5),
            sector_mins=[
                SectorMinConstraint("tech", list(range(10)), 2),
                SectorMinConstraint("health", list(range(10, 20)), 2),
            ],
            weight_limits=[], budget=None, position_bounds=None,
        )
        assert result is None

    def test_sectors_exactly_at_max(self):
        """3+2=5 == max 5 -> borderline, no contradiction."""
        result = run_quick_checks(
            n_assets=20,
            cardinality=CardinalityConstraint(min_assets=0, max_assets=5),
            sector_mins=[
                SectorMinConstraint("tech", list(range(10)), 3),
                SectorMinConstraint("health", list(range(10, 20)), 2),
            ],
            weight_limits=[], budget=None, position_bounds=None,
        )
        assert result is None

    def test_no_cardinality_no_issue(self):
        """Without cardinality max, sector mins can't conflict with it."""
        result = run_quick_checks(
            n_assets=20,
            cardinality=None,
            sector_mins=[
                SectorMinConstraint("tech", list(range(10)), 8),
                SectorMinConstraint("health", list(range(10, 20)), 8),
            ],
            weight_limits=[], budget=None, position_bounds=None,
        )
        assert result is None


class TestCardinalityBounds:
    """Cardinality min/max contradictions."""

    def test_min_greater_than_n(self):
        result = run_quick_checks(
            n_assets=5,
            cardinality=CardinalityConstraint(min_assets=10, max_assets=None),
            sector_mins=[], weight_limits=[], budget=None, position_bounds=None,
        )
        assert result is not None
        assert not result.feasible

    def test_min_equals_n(self):
        """min_assets == n_assets -> borderline, not a contradiction."""
        result = run_quick_checks(
            n_assets=5,
            cardinality=CardinalityConstraint(min_assets=5, max_assets=None),
            sector_mins=[], weight_limits=[], budget=None, position_bounds=None,
        )
        assert result is None

    def test_max_less_than_min(self):
        result = run_quick_checks(
            n_assets=10,
            cardinality=CardinalityConstraint(min_assets=7, max_assets=3),
            sector_mins=[], weight_limits=[], budget=None, position_bounds=None,
        )
        assert result is not None
        assert not result.feasible

    def test_max_equals_min(self):
        """max == min -> select exactly N, no contradiction."""
        result = run_quick_checks(
            n_assets=10,
            cardinality=CardinalityConstraint(min_assets=5, max_assets=5),
            sector_mins=[], weight_limits=[], budget=None, position_bounds=None,
        )
        assert result is None

    def test_zero_min_zero_max(self):
        result = run_quick_checks(
            n_assets=10,
            cardinality=CardinalityConstraint(min_assets=0, max_assets=0),
            sector_mins=[], weight_limits=[], budget=None, position_bounds=None,
        )
        assert result is None


class TestBudgetVsBounds:
    """Budget vs position bounds contradictions."""

    def test_min_w_times_min_exceeds_budget(self):
        """min_w=0.15 * min_assets=10 = 1.50 > budget=1.0."""
        result = run_quick_checks(
            n_assets=20,
            cardinality=CardinalityConstraint(min_assets=10),
            sector_mins=[], weight_limits=[],
            budget=BudgetConstraint(total=1.0),
            position_bounds=PositionBoundsConstraint(min_w=0.15, max_w=0.50),
        )
        assert result is not None
        assert not result.feasible

    def test_max_w_times_max_below_budget(self):
        """max_w=0.10 * max_assets=5 = 0.50 < budget=1.0."""
        result = run_quick_checks(
            n_assets=20,
            cardinality=CardinalityConstraint(min_assets=3, max_assets=5),
            sector_mins=[], weight_limits=[],
            budget=BudgetConstraint(total=1.0),
            position_bounds=PositionBoundsConstraint(min_w=0.01, max_w=0.10),
        )
        assert result is not None
        assert not result.feasible

    def test_exact_fit(self):
        """min_w=0.20 * min_assets=5 = 1.00 == budget -> no contradiction."""
        result = run_quick_checks(
            n_assets=10,
            cardinality=CardinalityConstraint(min_assets=5, max_assets=5),
            sector_mins=[], weight_limits=[],
            budget=BudgetConstraint(total=1.0),
            position_bounds=PositionBoundsConstraint(min_w=0.20, max_w=0.20),
        )
        assert result is None

    def test_no_budget_no_issue(self):
        """Without budget, bounds can't conflict."""
        result = run_quick_checks(
            n_assets=10,
            cardinality=CardinalityConstraint(min_assets=5),
            sector_mins=[], weight_limits=[],
            budget=None,
            position_bounds=PositionBoundsConstraint(min_w=0.50, max_w=1.0),
        )
        assert result is None


class TestWeightLimits:
    """Sector weight limit contradictions."""

    def test_min_pcts_exceed_100(self):
        """40% + 40% + 30% = 110% > 100%."""
        result = run_quick_checks(
            n_assets=15,
            cardinality=None, sector_mins=[],
            weight_limits=[
                WeightLimitConstraint("A", list(range(5)), min_pct=0.40),
                WeightLimitConstraint("B", list(range(5, 10)), min_pct=0.40),
                WeightLimitConstraint("C", list(range(10, 15)), min_pct=0.30),
            ],
            budget=None, position_bounds=None,
        )
        assert result is not None
        assert not result.feasible

    def test_min_pcts_exactly_100(self):
        """40% + 40% + 20% = 100% -> borderline, no contradiction."""
        result = run_quick_checks(
            n_assets=15,
            cardinality=None, sector_mins=[],
            weight_limits=[
                WeightLimitConstraint("A", list(range(5)), min_pct=0.40),
                WeightLimitConstraint("B", list(range(5, 10)), min_pct=0.40),
                WeightLimitConstraint("C", list(range(10, 15)), min_pct=0.20),
            ],
            budget=None, position_bounds=None,
        )
        assert result is None

    def test_max_pcts_below_budget(self):
        """All sectors max 30%, 3 sectors cover all assets, budget=1.0 -> 0.90 < 1.0."""
        result = run_quick_checks(
            n_assets=9,
            cardinality=None, sector_mins=[],
            weight_limits=[
                WeightLimitConstraint("A", [0, 1, 2], max_pct=0.30),
                WeightLimitConstraint("B", [3, 4, 5], max_pct=0.30),
                WeightLimitConstraint("C", [6, 7, 8], max_pct=0.30),
            ],
            budget=BudgetConstraint(total=1.0),
            position_bounds=None,
        )
        assert result is not None
        assert not result.feasible


class TestNoConstraints:
    """Edge cases with no/minimal constraints."""

    def test_all_none(self):
        result = run_quick_checks(
            n_assets=10,
            cardinality=None, sector_mins=[],
            weight_limits=[], budget=None, position_bounds=None,
        )
        assert result is None

    def test_only_budget(self):
        result = run_quick_checks(
            n_assets=10,
            cardinality=None, sector_mins=[],
            weight_limits=[],
            budget=BudgetConstraint(total=1.0),
            position_bounds=None,
        )
        assert result is None

    def test_single_asset(self):
        result = run_quick_checks(
            n_assets=1,
            cardinality=CardinalityConstraint(min_assets=1, max_assets=1),
            sector_mins=[], weight_limits=[],
            budget=BudgetConstraint(total=1.0),
            position_bounds=PositionBoundsConstraint(min_w=1.0, max_w=1.0),
        )
        assert result is None
