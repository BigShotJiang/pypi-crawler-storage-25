"""Realistic financial scenarios that a portfolio manager would encounter.

These are the tests that should match what Gurobi/CPLEX would produce.
Every scenario has a known correct answer derived from the constraint math.
"""

import numpy as np
import pytest
from portfolio_optimizer import PortfolioChecker


class TestIndexFundConstruction:
    """Index fund: must track an index with limited number of positions."""

    def test_sp500_track_30_positions(self):
        """Select 30 of 500, budget=1.0, each 1-5%, 10 sectors max 25%."""
        pc = PortfolioChecker(n_assets=500)
        pc.add_cardinality(min_assets=30, max_assets=30)
        pc.add_budget(total=1.0)
        pc.add_position_bounds(min_w=0.01, max_w=0.05)
        # 10 sectors, each max 25%
        for i in range(10):
            assets = list(range(i * 50, (i + 1) * 50))
            pc.add_weight_limit(f"sector_{i}", assets=assets, max_pct=0.25)
        result = pc.check_feasibility()
        # 30 * 0.01 = 0.30 <= 1.0, 30 * 0.05 = 1.50 >= 1.0 -> feasible
        assert result.feasible

    def test_sp500_track_10_positions_tight(self):
        """Select 10, min weight 5%, max 15% -> 10*0.05=0.50, 10*0.15=1.50."""
        pc = PortfolioChecker(n_assets=500)
        pc.add_cardinality(min_assets=10, max_assets=10)
        pc.add_budget(total=1.0)
        pc.add_position_bounds(min_w=0.05, max_w=0.15)
        result = pc.check_feasibility()
        assert result.feasible  # 10*0.05=0.50 <= 1.0 <= 10*0.15=1.50

    def test_sp500_track_3_positions_impossible(self):
        """Select 3, max weight 10% -> 3*0.10=0.30 < 1.0."""
        pc = PortfolioChecker(n_assets=500)
        pc.add_cardinality(min_assets=3, max_assets=3)
        pc.add_budget(total=1.0)
        pc.add_position_bounds(min_w=0.01, max_w=0.10)
        result = pc.check_feasibility()
        assert not result.feasible  # can't reach budget with 3 * 0.10 = 0.30


class TestESGPortfolio:
    """ESG-compliant portfolio with exclusions and sector requirements."""

    def test_esg_with_exclusions_feasible(self):
        """20 assets, exclude 3 pairs, require 2 from each of 3 sectors."""
        pc = PortfolioChecker(n_assets=20)
        pc.add_cardinality(min_assets=6, max_assets=10)
        pc.add_exclusion(0, 10)   # arms vs ESG
        pc.add_exclusion(1, 11)   # tobacco vs health
        pc.add_exclusion(2, 12)   # coal vs green
        pc.add_sector_min("tech", assets=list(range(0, 7)), min_count=2)
        pc.add_sector_min("health", assets=list(range(7, 14)), min_count=2)
        pc.add_sector_min("green", assets=list(range(14, 20)), min_count=2)
        result = pc.check_feasibility()
        assert result.feasible

    def test_esg_too_many_exclusions(self):
        """Small universe, many exclusions make sector mins impossible."""
        pc = PortfolioChecker(n_assets=6)
        pc.add_cardinality(min_assets=4)
        # Sector A: [0,1,2], need 2. Sector B: [3,4,5], need 2.
        pc.add_sector_min("A", assets=[0, 1, 2], min_count=2)
        pc.add_sector_min("B", assets=[3, 4, 5], min_count=2)
        # Exclude all cross-sector pairs -> no issue (exclusions are within-sector)
        # Exclude within sector: 0-1 and 3-4
        pc.add_exclusion(0, 1)
        pc.add_exclusion(0, 2)
        pc.add_exclusion(3, 4)
        pc.add_exclusion(3, 5)
        # Sector A: only {1,2} or {0} survives, but need 2 from {0,1,2} with 0-1 and 0-2 excluded
        # -> must pick {1,2}
        # Sector B: only {4,5} or {3} survives, but need 2 from {3,4,5} with 3-4 and 3-5 excluded
        # -> must pick {4,5}
        # Total: {1,2,4,5} = 4 assets, min 4 -> feasible
        result = pc.check_feasibility()
        assert result.feasible

    def test_esg_complete_sector_exclusion(self):
        """All assets in a sector excluded from each other -> can pick at most 1."""
        pc = PortfolioChecker(n_assets=6)
        pc.add_sector_min("A", assets=[0, 1, 2], min_count=2)
        # K3 on sector A -> at most 1
        pc.add_exclusion(0, 1)
        pc.add_exclusion(0, 2)
        pc.add_exclusion(1, 2)
        result = pc.check_feasibility()
        assert not result.feasible


class TestTargetDateFund:
    """Target date fund: specific asset allocation percentages."""

    def test_60_40_split(self):
        """60% equities, 40% bonds."""
        pc = PortfolioChecker(n_assets=100)
        pc.add_budget(total=1.0)
        pc.add_weight_limit("equities", assets=list(range(60)), min_pct=0.55, max_pct=0.65)
        pc.add_weight_limit("bonds", assets=list(range(60, 100)), min_pct=0.35, max_pct=0.45)
        result = pc.check_feasibility()
        assert result.feasible

    def test_80_20_impossible_with_sector_cap(self):
        """80% equities required but equities capped at 50%."""
        pc = PortfolioChecker(n_assets=100)
        pc.add_budget(total=1.0)
        pc.add_weight_limit("equities", assets=list(range(60)), min_pct=0.80, max_pct=1.0)
        pc.add_weight_limit("equities_cap", assets=list(range(60)), max_pct=0.50)
        result = pc.check_feasibility()
        assert not result.feasible

    def test_three_way_split(self):
        """40% equities, 40% bonds, 20% alternatives."""
        pc = PortfolioChecker(n_assets=90)
        pc.add_budget(total=1.0)
        pc.add_weight_limit("equities", assets=list(range(30)), min_pct=0.35, max_pct=0.45)
        pc.add_weight_limit("bonds", assets=list(range(30, 60)), min_pct=0.35, max_pct=0.45)
        pc.add_weight_limit("alts", assets=list(range(60, 90)), min_pct=0.15, max_pct=0.25)
        result = pc.check_feasibility()
        assert result.feasible


class TestRegulatoryConstraints:
    """Regulatory constraints: concentration limits, diversification rules."""

    def test_ucits_5_10_rule(self):
        """UCITS 5/10/40: no position > 10%, positions > 5% sum to < 40%.

        Simplified: max_w = 0.10 is the hard limit.
        With 20 assets, 10% each -> 200% > budget. But select 10 -> 100%.
        """
        pc = PortfolioChecker(n_assets=50)
        pc.add_cardinality(min_assets=10, max_assets=20)
        pc.add_budget(total=1.0)
        pc.add_position_bounds(min_w=0.02, max_w=0.10)
        result = pc.check_feasibility()
        assert result.feasible

    def test_concentration_limit_infeasible(self):
        """3 assets, max 20% each, budget 100% -> 3*20% = 60% < 100%."""
        pc = PortfolioChecker(n_assets=3)
        pc.add_budget(total=1.0)
        pc.add_position_bounds(min_w=0.0, max_w=0.20)
        result = pc.check_feasibility()
        assert not result.feasible

    def test_diversification_with_min_sectors(self):
        """Must have at least 5 sectors represented."""
        pc = PortfolioChecker(n_assets=50)
        pc.add_cardinality(min_assets=10, max_assets=20)
        for i in range(5):
            pc.add_sector_min(f"sector_{i}", assets=list(range(i*10, (i+1)*10)), min_count=1)
        result = pc.check_feasibility()
        assert result.feasible


class TestRiskBudgeting:
    """Risk budget: CVaR constraints with realistic scenarios."""

    def test_low_vol_portfolio_feasible(self):
        """Low volatility assets -> CVaR easily within limits."""
        np.random.seed(42)
        n = 20
        S = 200
        returns = np.random.normal(0.005, 0.01, (S, n))  # low vol
        pc = PortfolioChecker(n_assets=n)
        pc.add_budget(total=1.0)
        pc.add_position_bounds(min_w=0.0, max_w=0.10)
        pc.add_cvar_limit(confidence=0.95, max_cvar=0.05, returns=returns)
        result = pc.check_feasibility()
        assert result.feasible

    def test_high_vol_tight_cvar(self):
        """High vol assets + tight CVaR -> infeasible."""
        np.random.seed(42)
        n = 10
        S = 200
        returns = np.random.normal(-0.02, 0.15, (S, n))  # high vol, slightly negative
        pc = PortfolioChecker(n_assets=n)
        pc.add_budget(total=1.0)
        pc.add_cvar_limit(confidence=0.99, max_cvar=0.01, returns=returns)
        result = pc.check_feasibility()
        assert not result.feasible

    def test_mixed_assets_cvar(self):
        """Mix of safe and risky: feasible if can avoid risky ones."""
        np.random.seed(42)
        n = 10
        S = 100
        safe = np.random.normal(0.03, 0.01, (S, 5))
        risky = np.random.normal(-0.10, 0.30, (S, 5))
        returns = np.column_stack([safe, risky])
        pc = PortfolioChecker(n_assets=n)
        pc.add_budget(total=1.0)
        pc.add_position_bounds(min_w=0.0, max_w=0.30)
        pc.add_cvar_limit(confidence=0.95, max_cvar=0.05, returns=returns)
        result = pc.check_feasibility()
        assert result.feasible  # Put most weight in safe assets


class TestMultiConstraintCombinations:
    """Complex scenarios with multiple constraint types simultaneously."""

    def test_cardinality_plus_weight_plus_sector(self):
        """All three: cardinality, weight limits, sector minimums."""
        pc = PortfolioChecker(n_assets=30)
        pc.add_cardinality(min_assets=10, max_assets=15)
        pc.add_budget(total=1.0)
        pc.add_position_bounds(min_w=0.02, max_w=0.10)
        pc.add_sector_min("tech", assets=list(range(10)), min_count=3)
        pc.add_sector_min("health", assets=list(range(10, 20)), min_count=3)
        pc.add_weight_limit("tech", assets=list(range(10)), max_pct=0.40)
        pc.add_weight_limit("health", assets=list(range(10, 20)), max_pct=0.40)
        result = pc.check_feasibility()
        assert result.feasible

    def test_exclusion_plus_cardinality_plus_weight(self):
        pc = PortfolioChecker(n_assets=10)
        pc.add_cardinality(min_assets=4, max_assets=6)
        pc.add_budget(total=1.0)
        pc.add_position_bounds(min_w=0.05, max_w=0.30)
        pc.add_exclusion(0, 1)
        pc.add_exclusion(2, 3)
        pc.add_exclusion(4, 5)
        result = pc.check_feasibility()
        assert result.feasible  # Can pick {0,2,4,6,7,8}

    def test_everything_together_feasible(self):
        """Cardinality + sectors + weight limits + exclusions + budget."""
        pc = PortfolioChecker(n_assets=20)
        pc.add_cardinality(min_assets=6, max_assets=10)
        pc.add_budget(total=1.0)
        pc.add_position_bounds(min_w=0.05, max_w=0.20)
        pc.add_sector_min("A", assets=list(range(7)), min_count=2)
        pc.add_sector_min("B", assets=list(range(7, 14)), min_count=2)
        pc.add_weight_limit("A", assets=list(range(7)), max_pct=0.50)
        pc.add_weight_limit("B", assets=list(range(7, 14)), max_pct=0.50)
        pc.add_exclusion(0, 1)
        pc.add_exclusion(7, 8)
        result = pc.check_feasibility()
        assert result.feasible

    def test_everything_together_infeasible(self):
        """Same setup but with impossibly tight cardinality."""
        pc = PortfolioChecker(n_assets=20)
        pc.add_cardinality(min_assets=6, max_assets=3)  # min > max
        pc.add_budget(total=1.0)
        pc.add_position_bounds(min_w=0.05, max_w=0.20)
        result = pc.check_feasibility()
        assert not result.feasible


class TestInfeasibilityDiagnosis:
    """Verify that infeasible results provide useful diagnostics."""

    def test_infeasible_has_suggestion(self):
        """Every infeasible result should have a non-empty suggestion."""
        scenarios = [
            # Scenario 1: min > max
            lambda: self._build(min_a=8, max_a=3),
            # Scenario 2: bounds too tight
            lambda: self._build_lp(n=5, max_w=0.10),
            # Scenario 3: sector sums exceed max
            lambda: self._build_sectors(n_sec=3, min_each=4, max_total=10),
        ]
        for i, build in enumerate(scenarios):
            pc = build()
            result = pc.check_feasibility()
            assert not result.feasible, f"Scenario {i+1} should be infeasible"
            assert len(result.suggestion) > 0, f"Scenario {i+1} should have suggestion"

    def _build(self, min_a, max_a):
        pc = PortfolioChecker(n_assets=10)
        pc.add_cardinality(min_assets=min_a, max_assets=max_a)
        return pc

    def _build_lp(self, n, max_w):
        pc = PortfolioChecker(n_assets=n)
        pc.add_budget(total=1.0)
        pc.add_position_bounds(min_w=0.0, max_w=max_w)
        return pc

    def _build_sectors(self, n_sec, min_each, max_total):
        n = n_sec * 10
        pc = PortfolioChecker(n_assets=n)
        pc.add_cardinality(max_assets=max_total)
        for i in range(n_sec):
            pc.add_sector_min(f"S{i}", assets=list(range(i*10, (i+1)*10)), min_count=min_each)
        return pc

    def test_infeasible_method_is_identified(self):
        """Infeasible results should identify which solver detected it."""
        pc = PortfolioChecker(n_assets=5)
        pc.add_budget(total=1.0)
        pc.add_position_bounds(min_w=0.0, max_w=0.10)
        result = pc.check_feasibility()
        assert not result.feasible
        assert result.method in ("quick_check", "sat", "lp", "mip", "cvar")
