"""Dataclasses for all constraint types.

Binary constraints are delegated to torc-sat (SAT).
Weight constraints are handled by LP/MIP (scipy).
Risk constraints use CVaR linearization.
"""

from dataclasses import dataclass, field


# --- Binary constraints (SAT domain) ---

@dataclass
class CardinalityConstraint:
    """At most max_assets and at least min_assets selected."""
    min_assets: int = 0
    max_assets: int | None = None


@dataclass
class ExclusionConstraint:
    """Assets a and b cannot both be selected."""
    asset_a: int
    asset_b: int


@dataclass
class SectorMinConstraint:
    """At least min_count assets from this sector must be selected."""
    sector: str
    assets: list[int]
    min_count: int


@dataclass
class DiversificationConstraint:
    """At least 1 asset from each sector must be selected."""
    sectors: dict[str, list[int]]


# --- Weight constraints (LP/MIP domain) ---

@dataclass
class WeightLimitConstraint:
    """Sector weight limit: sum of weights in sector <= max_pct or >= min_pct."""
    sector: str
    assets: list[int]
    min_pct: float = 0.0
    max_pct: float = 1.0


@dataclass
class BudgetConstraint:
    """Total weight must equal this value (typically 1.0)."""
    total: float = 1.0


@dataclass
class PositionBoundsConstraint:
    """Per-asset weight bounds: min_w <= w_i <= max_w (when asset is selected)."""
    min_w: float = 0.0
    max_w: float = 1.0


# --- Risk constraints (CVaR domain) ---

@dataclass
class CVaRConstraint:
    """CVaR at given confidence must not exceed max_cvar.

    returns: numpy array of shape (n_scenarios, n_assets).
             Each row is one scenario's returns per asset.
    """
    confidence: float
    max_cvar: float
    returns: object = None  # numpy array, typed as object to avoid import


# --- Result ---

@dataclass
class FeasibilityResult:
    """Result of feasibility check."""
    feasible: bool
    method: str = ""
    infeasible_constraints: list[str] = field(default_factory=list)
    suggestion: str = ""
    details: dict = field(default_factory=dict)
