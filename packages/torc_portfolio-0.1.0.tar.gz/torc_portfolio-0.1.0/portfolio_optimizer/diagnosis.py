"""IIS (Irreducible Infeasible Subsystem) extraction for LP/MIP.

Analogous to MUS in SAT: finds the smallest subset of constraints
that is still infeasible. Removing any single constraint makes it feasible.

Uses deletion-based algorithm:
1. Start with all constraints
2. For each constraint i: remove it, solve LP/MIP
3. If feasible without i → i is essential (part of IIS), keep it
4. If infeasible without i → i is redundant, remove permanently
5. Remaining constraints form the IIS
"""

import numpy as np
from scipy.optimize import linprog


def extract_iis(
    c: np.ndarray,
    A_ub: np.ndarray | None,
    b_ub: np.ndarray | None,
    A_eq: np.ndarray | None,
    b_eq: np.ndarray | None,
    bounds: list[tuple],
    constraint_names: list[str] | None = None,
) -> dict:
    """Extract IIS from an infeasible LP.

    Args:
        c: objective (usually zeros for feasibility)
        A_ub, b_ub: inequality constraints
        A_eq, b_eq: equality constraints
        bounds: variable bounds
        constraint_names: human-readable names for each constraint
            Order: inequality rows first, then equality rows

    Returns:
        {
            "iis_indices": list of constraint indices in the IIS,
            "iis_names": list of constraint names in the IIS,
            "n_total": total constraints checked,
            "n_iis": size of IIS,
        }
    """
    n_ub = len(A_ub) if A_ub is not None else 0
    n_eq = len(A_eq) if A_eq is not None else 0
    n_total = n_ub + n_eq

    if constraint_names is None:
        constraint_names = [f"ub_{i}" for i in range(n_ub)] + [f"eq_{i}" for i in range(n_eq)]

    # Track which constraints are still active
    active = list(range(n_total))

    def _solve_without(excluded_indices: set) -> bool:
        """Solve LP excluding certain constraints. Returns True if feasible."""
        active_ub_idx = [i for i in range(n_ub) if i not in excluded_indices]
        active_eq_idx = [i for i in range(n_ub, n_total) if i not in excluded_indices]

        a_ub_filtered = A_ub[active_ub_idx] if active_ub_idx and A_ub is not None else None
        b_ub_filtered = b_ub[active_ub_idx] if active_ub_idx and b_ub is not None else None

        eq_local_idx = [i - n_ub for i in active_eq_idx]
        a_eq_filtered = A_eq[eq_local_idx] if eq_local_idx and A_eq is not None else None
        b_eq_filtered = b_eq[eq_local_idx] if eq_local_idx and b_eq is not None else None

        res = linprog(
            c,
            A_ub=a_ub_filtered,
            b_ub=b_ub_filtered,
            A_eq=a_eq_filtered,
            b_eq=b_eq_filtered,
            bounds=bounds,
            method="highs",
        )
        return res.success

    # First check: is the system actually infeasible?
    if _solve_without(set()):
        # System is feasible — no IIS exists
        return {
            "iis_indices": [],
            "iis_names": [],
            "n_total": n_total,
            "n_iis": 0,
        }

    # Deletion-based IIS extraction
    removed = set()
    iis = []

    for i in list(active):
        # Try removing constraint i
        test_removed = removed | {i}
        if _solve_without(test_removed):
            # Feasible without i → i is essential (part of IIS)
            iis.append(i)
        else:
            # Still infeasible without i → i is redundant
            removed.add(i)

    return {
        "iis_indices": iis,
        "iis_names": [constraint_names[i] for i in iis],
        "n_total": n_total,
        "n_iis": len(iis),
    }


def suggest_fix(iis_names: list[str]) -> str:
    """Generate actionable suggestion from IIS constraint names."""
    if not iis_names:
        return "No infeasible constraints found."

    parts = [f"  - {name}" for name in iis_names]
    header = f"These {len(iis_names)} constraints form an irreducible conflict:"
    detail = "\n".join(parts)
    fix = "Relax or remove at least one of these constraints to make the problem feasible."

    return f"{header}\n{detail}\n{fix}"
