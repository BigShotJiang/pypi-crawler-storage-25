"""CVaR linearization via Rockafellar-Uryasev (2000).

Conditional Value at Risk (CVaR) at confidence level alpha:
  CVaR_alpha(w) = min_{alpha} { alpha + 1/(1-conf) * E[max(-r^T w - alpha, 0)] }

This can be formulated as a linear program by introducing auxiliary
variables u_s >= 0 for each scenario s:

  Constraint: alpha + (1/(1-conf)) * (1/S) * sum(u_s) <= max_cvar
  Subject to: u_s >= -r_s^T w - alpha  for each scenario s
              u_s >= 0

This adds 1 variable (alpha/VaR) + S variables (u_s) to the LP.
"""

import numpy as np
from scipy.optimize import linprog


def check_cvar_feasibility(
    n_assets: int,
    confidence: float,
    max_cvar: float,
    returns: np.ndarray,
    budget_total: float = 1.0,
    min_w: float = 0.0,
    max_w: float = 1.0,
) -> dict:
    """Check if CVaR constraint is feasible with budget and position bounds.

    Variables: [w_0, ..., w_{n-1}, alpha, u_0, ..., u_{S-1}]
    where w = weights, alpha = VaR threshold, u = excess loss per scenario.

    Args:
        n_assets: number of assets
        confidence: CVaR confidence level (e.g. 0.95)
        max_cvar: maximum allowed CVaR
        returns: array of shape (S, n_assets), returns per scenario
        budget_total: sum of weights must equal this
        min_w: minimum weight per asset
        max_w: maximum weight per asset

    Returns:
        {"feasible": bool, "weights": array or None, "var": float or None, "cvar": float or None}
    """
    S, n = returns.shape
    assert n == n_assets, f"returns has {n} columns but n_assets={n_assets}"
    assert 0 < confidence < 1, f"confidence must be in (0, 1), got {confidence}"

    # Total variables: n (weights) + 1 (alpha) + S (u_s)
    n_vars = n + 1 + S

    # Objective: minimize 0 (feasibility check)
    c = np.zeros(n_vars)

    # Index helpers
    idx_w = slice(0, n)
    idx_alpha = n
    idx_u = slice(n + 1, n + 1 + S)

    # --- Bounds ---
    lower = np.full(n_vars, -np.inf)
    upper = np.full(n_vars, np.inf)

    # w_i in [min_w, max_w]
    lower[:n] = min_w
    upper[:n] = max_w

    # alpha unbounded (VaR can be any real number)
    # u_s >= 0
    lower[n + 1:] = 0.0

    bounds = list(zip(lower, upper))

    # --- Equality constraints ---
    # sum(w_i) = budget_total
    A_eq = np.zeros((1, n_vars))
    A_eq[0, :n] = 1.0
    b_eq = np.array([budget_total])

    # --- Inequality constraints (A_ub @ x <= b_ub) ---
    A_ub_rows = []
    b_ub_rows = []

    # CVaR constraint: alpha + (1/(1-conf)) * (1/S) * sum(u_s) <= max_cvar
    cvar_row = np.zeros(n_vars)
    cvar_row[idx_alpha] = 1.0
    cvar_coeff = 1.0 / ((1.0 - confidence) * S)
    cvar_row[n + 1:] = cvar_coeff
    A_ub_rows.append(cvar_row)
    b_ub_rows.append(max_cvar)

    # For each scenario s: u_s >= -r_s^T w - alpha
    # => -r_s^T w - alpha - u_s <= 0
    # => row: -r_s (for w), -1 (for alpha), -1 (for u_s position)
    for s in range(S):
        row = np.zeros(n_vars)
        row[:n] = -returns[s]      # -r_s^T w
        row[idx_alpha] = -1.0       # -alpha
        row[n + 1 + s] = -1.0      # -u_s
        A_ub_rows.append(row)
        b_ub_rows.append(0.0)

    A_ub = np.array(A_ub_rows)
    b_ub = np.array(b_ub_rows)

    result = linprog(
        c,
        A_ub=A_ub,
        b_ub=b_ub,
        A_eq=A_eq,
        b_eq=b_eq,
        bounds=bounds,
        method="highs",
    )

    if result.success:
        weights = result.x[:n]
        var_val = result.x[idx_alpha]
        u_vals = result.x[n + 1:]
        cvar_val = var_val + cvar_coeff * np.sum(u_vals)
        return {
            "feasible": True,
            "weights": weights,
            "var": var_val,
            "cvar": cvar_val,
        }
    else:
        return {"feasible": False, "weights": None, "var": None, "cvar": None}
