"""Portfolio constraint feasibility checker with LP/MIP/CVaR support."""

from portfolio_optimizer.checker import PortfolioChecker

__all__ = ["PortfolioChecker"]
__version__ = "0.1.0"
