"""Bridge to torc-sat for binary (SAT) constraints.

Delegates cardinality, exclusion, sector_min, diversification
constraints to torc-sat's PortfolioConstraints + MiniSat pipeline.
"""

from torc_sat.finance.constraints import PortfolioConstraints as TorcPC

from portfolio_optimizer.constraints import (
    CardinalityConstraint,
    ExclusionConstraint,
    SectorMinConstraint,
    DiversificationConstraint,
    FeasibilityResult,
)


def check_sat_feasibility(
    n_assets: int,
    cardinality: CardinalityConstraint | None,
    exclusions: list[ExclusionConstraint],
    sector_mins: list[SectorMinConstraint],
    diversification: DiversificationConstraint | None,
) -> FeasibilityResult | None:
    """Check binary constraints via torc-sat.

    Returns FeasibilityResult if a definitive answer is found, None if
    there are no binary constraints to check.
    """
    has_binary = (
        cardinality is not None
        or exclusions
        or sector_mins
        or diversification is not None
    )
    if not has_binary:
        return None

    tpc = TorcPC(n_assets=n_assets)

    if cardinality:
        tpc.add_cardinality(
            min_assets=cardinality.min_assets if cardinality.min_assets > 0 else None,
            max_assets=cardinality.max_assets,
        )

    for exc in exclusions:
        tpc.add_mutual_exclusion(exc.asset_a, exc.asset_b)

    for sm in sector_mins:
        tpc.add_sector_min(sm.sector, sm.assets, sm.min_count)

    if diversification:
        tpc.add_diversification(diversification.sectors)

    result = tpc.check_feasibility()

    if not result.feasible:
        return FeasibilityResult(
            feasible=False,
            method="sat",
            infeasible_constraints=[c.description for c in result.conflicting_constraints],
            suggestion=result.suggestion,
        )

    return FeasibilityResult(
        feasible=True,
        method="sat",
    )
