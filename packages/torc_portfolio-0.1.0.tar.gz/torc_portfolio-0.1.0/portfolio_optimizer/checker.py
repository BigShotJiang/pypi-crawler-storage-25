"""PortfolioChecker: main orchestrator for constraint feasibility.

Pipeline (5 steps, each more expensive):
1. Quick arithmetic checks
2. SAT (torc-sat) for binary constraints
3. LP (scipy.linprog) for weight constraints
4. MIP (scipy.milp) for mixed binary + weight constraints
5. CVaR (Rockafellar-Uryasev) for risk constraints
"""

import numpy as np

from portfolio_optimizer.constraints import (
    CardinalityConstraint,
    ExclusionConstraint,
    SectorMinConstraint,
    DiversificationConstraint,
    WeightLimitConstraint,
    BudgetConstraint,
    PositionBoundsConstraint,
    CVaRConstraint,
    FeasibilityResult,
)
from portfolio_optimizer.quick_checks import run_quick_checks
from portfolio_optimizer.sat_bridge import check_sat_feasibility
from portfolio_optimizer.lp_solver import check_lp_feasibility, check_mip_feasibility
from portfolio_optimizer.cvar_solver import check_cvar_feasibility
from portfolio_optimizer.diagnosis import extract_iis, suggest_fix


class PortfolioChecker:
    """Portfolio constraint feasibility checker.

    Usage:
        pc = PortfolioChecker(n_assets=500)
        pc.add_cardinality(min_assets=15, max_assets=20)
        pc.add_weight_limit("tech", assets=[0,1,2], max_pct=0.30)
        pc.add_budget(total=1.0)

        result = pc.check_feasibility()
        print(result.feasible, result.suggestion)
    """

    def __init__(self, n_assets: int):
        self.n_assets = n_assets

        # Binary constraints (SAT domain)
        self._cardinality: CardinalityConstraint | None = None
        self._exclusions: list[ExclusionConstraint] = []
        self._sector_mins: list[SectorMinConstraint] = []
        self._diversification: DiversificationConstraint | None = None

        # Weight constraints (LP domain)
        self._weight_limits: list[WeightLimitConstraint] = []
        self._budget: BudgetConstraint | None = None
        self._position_bounds: PositionBoundsConstraint | None = None

        # Risk constraints (CVaR domain)
        self._cvar: CVaRConstraint | None = None

        # Track all constraints for diagnostics
        self._all_constraints: list[str] = []

    def add_cardinality(self, min_assets: int = 0, max_assets: int | None = None):
        """Set min/max number of assets to select."""
        self._cardinality = CardinalityConstraint(
            min_assets=min_assets,
            max_assets=max_assets,
        )
        desc = f"cardinality(min={min_assets}, max={max_assets})"
        self._all_constraints.append(desc)

    def add_exclusion(self, asset_a: int, asset_b: int):
        """Two assets cannot both be selected."""
        self._exclusions.append(ExclusionConstraint(asset_a=asset_a, asset_b=asset_b))
        self._all_constraints.append(f"exclusion({asset_a}, {asset_b})")

    def add_sector_min(self, sector: str, assets: list[int], min_count: int):
        """At least min_count assets from this sector."""
        self._sector_mins.append(SectorMinConstraint(
            sector=sector, assets=assets, min_count=min_count,
        ))
        self._all_constraints.append(f"sector_min({sector}, min={min_count})")

    def add_diversification(self, sectors: dict[str, list[int]]):
        """At least 1 asset from each sector."""
        self._diversification = DiversificationConstraint(sectors=sectors)
        for name in sectors:
            self._all_constraints.append(f"diversification({name})")

    def add_weight_limit(self, sector: str, assets: list[int],
                         min_pct: float = 0.0, max_pct: float = 1.0):
        """Sector weight constraint."""
        self._weight_limits.append(WeightLimitConstraint(
            sector=sector, assets=assets, min_pct=min_pct, max_pct=max_pct,
        ))
        self._all_constraints.append(
            f"weight_limit({sector}, min_pct={min_pct}, max_pct={max_pct})"
        )

    def add_budget(self, total: float = 1.0):
        """Sum of all weights must equal total."""
        self._budget = BudgetConstraint(total=total)
        self._all_constraints.append(f"budget(total={total})")

    def add_position_bounds(self, min_w: float = 0.0, max_w: float = 1.0):
        """Per-asset weight bounds (when selected)."""
        self._position_bounds = PositionBoundsConstraint(min_w=min_w, max_w=max_w)
        self._all_constraints.append(f"position_bounds(min_w={min_w}, max_w={max_w})")

    def add_cvar_limit(self, confidence: float, max_cvar: float, returns: np.ndarray):
        """CVaR risk constraint."""
        self._cvar = CVaRConstraint(
            confidence=confidence, max_cvar=max_cvar, returns=returns,
        )
        self._all_constraints.append(
            f"cvar(confidence={confidence}, max_cvar={max_cvar})"
        )

    def check_feasibility(self) -> FeasibilityResult:
        """Run the full feasibility pipeline.

        Returns FeasibilityResult with feasible flag, method used,
        conflicting constraints (if infeasible), and suggestion.
        """
        has_binary = (
            self._cardinality is not None
            or self._exclusions
            or self._sector_mins
            or self._diversification is not None
        )
        has_weight = self._weight_limits or self._budget or self._position_bounds
        has_cvar = self._cvar is not None

        # Step 1: Quick arithmetic checks
        quick = run_quick_checks(
            n_assets=self.n_assets,
            cardinality=self._cardinality,
            sector_mins=self._sector_mins,
            weight_limits=self._weight_limits,
            budget=self._budget,
            position_bounds=self._position_bounds,
        )
        if quick is not None:
            return quick

        # Step 2: SAT check for binary constraints only
        if has_binary and not has_weight and not has_cvar:
            sat_result = check_sat_feasibility(
                n_assets=self.n_assets,
                cardinality=self._cardinality,
                exclusions=self._exclusions,
                sector_mins=self._sector_mins,
                diversification=self._diversification,
            )
            if sat_result is not None:
                return sat_result

        # Step 3: LP check for weight constraints only (no binary)
        if has_weight and not has_binary and not has_cvar:
            lp_result = check_lp_feasibility(
                n_assets=self.n_assets,
                weight_limits=self._weight_limits,
                budget=self._budget,
                position_bounds=self._position_bounds,
            )
            if lp_result["feasible"]:
                return FeasibilityResult(
                    feasible=True,
                    method="lp",
                    details={"weights": lp_result["weights"]},
                )
            else:
                iis_result = self._diagnose_lp()
                return FeasibilityResult(
                    feasible=False,
                    method="lp",
                    infeasible_constraints=iis_result["iis_names"],
                    suggestion=suggest_fix(iis_result["iis_names"]),
                )

        # Step 4: MIP for mixed binary + weight (or pure binary with weight)
        if has_binary or has_weight:
            mip_result = check_mip_feasibility(
                n_assets=self.n_assets,
                cardinality=self._cardinality,
                weight_limits=self._weight_limits,
                budget=self._budget,
                position_bounds=self._position_bounds,
                exclusions=self._exclusions,
            )
            if has_cvar and mip_result["feasible"]:
                # Continue to CVaR check
                pass
            elif mip_result["feasible"]:
                return FeasibilityResult(
                    feasible=True,
                    method="mip",
                    details={
                        "weights": mip_result["weights"],
                        "selected": mip_result["selected"],
                    },
                )
            else:
                iis_result = self._diagnose_lp()
                return FeasibilityResult(
                    feasible=False,
                    method="mip",
                    infeasible_constraints=iis_result["iis_names"] or self._all_constraints,
                    suggestion=suggest_fix(iis_result["iis_names"]) if iis_result["iis_names"] else (
                        "Mixed binary + weight constraints are infeasible. "
                        "Relax cardinality, sector limits, or position bounds."
                    ),
                )

        # Step 5: CVaR check
        if has_cvar:
            min_w = self._position_bounds.min_w if self._position_bounds else 0.0
            max_w = self._position_bounds.max_w if self._position_bounds else 1.0
            budget_total = self._budget.total if self._budget else 1.0

            cvar_result = check_cvar_feasibility(
                n_assets=self.n_assets,
                confidence=self._cvar.confidence,
                max_cvar=self._cvar.max_cvar,
                returns=self._cvar.returns,
                budget_total=budget_total,
                min_w=min_w,
                max_w=max_w,
            )
            if cvar_result["feasible"]:
                return FeasibilityResult(
                    feasible=True,
                    method="cvar",
                    details={
                        "weights": cvar_result["weights"],
                        "var": cvar_result["var"],
                        "cvar": cvar_result["cvar"],
                    },
                )
            else:
                return FeasibilityResult(
                    feasible=False,
                    method="cvar",
                    infeasible_constraints=[
                        f"cvar(confidence={self._cvar.confidence}, max_cvar={self._cvar.max_cvar})",
                        *self._weight_constraint_names(),
                    ],
                    suggestion=(
                        f"CVaR constraint (max={self._cvar.max_cvar} at {self._cvar.confidence:.0%} confidence) "
                        f"is too tight. Increase max_cvar or relax position bounds."
                    ),
                )

        # No constraints at all
        return FeasibilityResult(feasible=True, method="trivial")

    def _diagnose_lp(self) -> dict:
        """Build LP matrices with position_bounds as explicit rows for IIS."""
        n = self.n_assets
        c = np.zeros(n)
        bounds = [(0.0, np.inf)] * n  # No hidden bounds — all explicit

        A_ub = []
        b_ub = []
        A_eq = []
        b_eq = []
        ub_names = []
        eq_names = []

        # Position bounds as explicit inequality rows
        if self._position_bounds:
            # sum constraint: each w_i <= max_w  =>  aggregate: sum(w_i) <= n*max_w
            # But IIS needs individual: use a single row for the aggregate bound
            # w_i <= max_w for all i  =>  encode as: I @ w <= max_w * ones
            for i in range(n):
                row = np.zeros(n)
                row[i] = 1.0
                A_ub.append(row)
                b_ub.append(self._position_bounds.max_w)
            ub_names.append(f"position_bounds(max_w={self._position_bounds.max_w})")
            # w_i >= min_w  =>  -w_i <= -min_w
            if self._position_bounds.min_w > 0:
                for i in range(n):
                    row = np.zeros(n)
                    row[i] = -1.0
                    A_ub.append(row)
                    b_ub.append(-self._position_bounds.min_w)
                ub_names.append(f"position_bounds(min_w={self._position_bounds.min_w})")

        # Weight limits
        for wl in self._weight_limits:
            row = np.zeros(n)
            for a in wl.assets:
                if 0 <= a < n:
                    row[a] = 1.0
            if wl.max_pct < 1.0:
                A_ub.append(row.copy())
                b_ub.append(wl.max_pct)
                ub_names.append(f"weight_limit({wl.sector}, max_pct={wl.max_pct})")
            if wl.min_pct > 0.0:
                A_ub.append(-row.copy())
                b_ub.append(-wl.min_pct)
                ub_names.append(f"weight_limit({wl.sector}, min_pct={wl.min_pct})")

        # Budget
        if self._budget:
            A_eq.append(np.ones(n))
            b_eq.append(self._budget.total)
            eq_names.append(f"budget(total={self._budget.total})")

        # IIS expects names ordered: ub rows first, then eq rows.
        # But position_bounds adds n (or 2n) rows mapped to 1 (or 2) names.
        # Use a simplified approach: map each row to a name.
        row_names = []
        idx = 0
        if self._position_bounds:
            for i in range(n):
                row_names.append(f"position_bounds(max_w={self._position_bounds.max_w})")
                idx += 1
            if self._position_bounds.min_w > 0:
                for i in range(n):
                    row_names.append(f"position_bounds(min_w={self._position_bounds.min_w})")
                    idx += 1
        for wl in self._weight_limits:
            if wl.max_pct < 1.0:
                row_names.append(f"weight_limit({wl.sector}, max_pct={wl.max_pct})")
            if wl.min_pct > 0.0:
                row_names.append(f"weight_limit({wl.sector}, min_pct={wl.min_pct})")
        for _ in eq_names:
            row_names.append(_)

        A_ub_arr = np.array(A_ub) if A_ub else None
        b_ub_arr = np.array(b_ub) if b_ub else None
        A_eq_arr = np.array(A_eq) if A_eq else None
        b_eq_arr = np.array(b_eq) if b_eq else None

        result = extract_iis(
            c, A_ub_arr, b_ub_arr, A_eq_arr, b_eq_arr,
            bounds, constraint_names=row_names,
        )
        # Deduplicate IIS names (position_bounds rows map to same name)
        seen = set()
        unique_names = []
        for name in result["iis_names"]:
            if name not in seen:
                seen.add(name)
                unique_names.append(name)
        result["iis_names"] = unique_names
        result["n_iis"] = len(unique_names)
        return result

    def _weight_constraint_names(self) -> list[str]:
        """Collect all weight-related constraint names."""
        names = []
        for wl in self._weight_limits:
            names.append(f"weight_limit({wl.sector}, min_pct={wl.min_pct}, max_pct={wl.max_pct})")
        if self._budget:
            names.append(f"budget(total={self._budget.total})")
        if self._position_bounds:
            names.append(f"position_bounds(min_w={self._position_bounds.min_w}, max_w={self._position_bounds.max_w})")
        return names
