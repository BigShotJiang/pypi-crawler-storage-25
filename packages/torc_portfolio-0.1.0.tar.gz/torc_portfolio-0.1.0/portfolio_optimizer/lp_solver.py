"""LP/MIP solver wrappers using scipy.optimize.

Handles weight-based constraints:
- Sector weight limits (min_pct, max_pct)
- Budget constraint (sum of weights = total)
- Position bounds (min_w <= w_i <= max_w per asset)
- Cardinality via binary variables + linking (MIP)
"""

import numpy as np
from scipy.optimize import linprog, milp, LinearConstraint, Bounds

from portfolio_optimizer.constraints import (
    CardinalityConstraint,
    WeightLimitConstraint,
    BudgetConstraint,
    PositionBoundsConstraint,
    ExclusionConstraint,
)


def check_lp_feasibility(
    n_assets: int,
    weight_limits: list[WeightLimitConstraint],
    budget: BudgetConstraint | None,
    position_bounds: PositionBoundsConstraint | None,
) -> dict:
    """Check feasibility of weight constraints only (continuous LP).

    Variables: w_0, w_1, ..., w_{n-1} (weights per asset).

    Returns: {"feasible": bool, "weights": array or None}
    """
    # Objective: minimize 0 (just feasibility, no optimization)
    c = np.zeros(n_assets)

    # Bounds per variable
    lb = 0.0
    ub = 1.0
    if position_bounds:
        lb = position_bounds.min_w
        ub = position_bounds.max_w

    bounds = [(lb, ub) for _ in range(n_assets)]

    # Equality constraints: A_eq @ w = b_eq
    A_eq = []
    b_eq = []

    if budget:
        # sum(w_i) = budget.total
        A_eq.append(np.ones(n_assets))
        b_eq.append(budget.total)

    # Inequality constraints: A_ub @ w <= b_ub
    A_ub = []
    b_ub = []

    for wl in weight_limits:
        row = np.zeros(n_assets)
        for a in wl.assets:
            if 0 <= a < n_assets:
                row[a] = 1.0

        # sum(w_i for i in sector) <= max_pct
        if wl.max_pct < 1.0:
            A_ub.append(row.copy())
            b_ub.append(wl.max_pct)

        # sum(w_i for i in sector) >= min_pct  =>  -sum <= -min_pct
        if wl.min_pct > 0.0:
            A_ub.append(-row.copy())
            b_ub.append(-wl.min_pct)

    A_eq_arr = np.array(A_eq) if A_eq else None
    b_eq_arr = np.array(b_eq) if b_eq else None
    A_ub_arr = np.array(A_ub) if A_ub else None
    b_ub_arr = np.array(b_ub) if b_ub else None

    result = linprog(
        c,
        A_ub=A_ub_arr,
        b_ub=b_ub_arr,
        A_eq=A_eq_arr,
        b_eq=b_eq_arr,
        bounds=bounds,
        method="highs",
    )

    if result.success:
        return {"feasible": True, "weights": result.x}
    else:
        return {"feasible": False, "weights": None}


def check_mip_feasibility(
    n_assets: int,
    cardinality: CardinalityConstraint | None,
    weight_limits: list[WeightLimitConstraint],
    budget: BudgetConstraint | None,
    position_bounds: PositionBoundsConstraint | None,
    exclusions: list[ExclusionConstraint] | None = None,
) -> dict:
    """Check feasibility with mixed integer programming (binary + continuous).

    Variables layout: [w_0, ..., w_{n-1}, z_0, ..., z_{n-1}]
    where w_i = weight (continuous), z_i = selected (binary).

    Linking: w_i <= z_i * max_w  (weight is 0 if not selected)
             w_i >= z_i * min_w  (if selected, weight >= min_w)

    Returns: {"feasible": bool, "weights": array or None, "selected": array or None}
    """
    n = n_assets
    n_vars = 2 * n  # w_0..w_{n-1}, z_0..z_{n-1}

    # Objective: minimize 0
    c = np.zeros(n_vars)

    # Bounds
    min_w = 0.0
    max_w = 1.0
    if position_bounds:
        min_w = position_bounds.min_w
        max_w = position_bounds.max_w

    # w_i in [0, max_w], z_i in [0, 1] (integrality makes z_i binary)
    lower = np.zeros(n_vars)
    upper = np.ones(n_vars)
    for i in range(n):
        upper[i] = max_w  # w_i upper bound

    # Integrality: 0 = continuous, 1 = integer
    integrality = np.zeros(n_vars, dtype=int)
    for i in range(n, 2 * n):
        integrality[i] = 1  # z_i is binary

    constraints = []

    # Budget: sum(w_i) = total
    if budget:
        A_budget = np.zeros(n_vars)
        A_budget[:n] = 1.0
        constraints.append(LinearConstraint(A_budget, budget.total, budget.total))

    # Linking: w_i <= z_i * max_w  =>  w_i - max_w * z_i <= 0
    A_link_upper = np.zeros((n, n_vars))
    for i in range(n):
        A_link_upper[i, i] = 1.0        # w_i
        A_link_upper[i, n + i] = -max_w  # -max_w * z_i
    constraints.append(LinearConstraint(A_link_upper, -np.inf, 0.0))

    # Linking: w_i >= z_i * min_w  =>  w_i - min_w * z_i >= 0
    if min_w > 0:
        A_link_lower = np.zeros((n, n_vars))
        for i in range(n):
            A_link_lower[i, i] = 1.0        # w_i
            A_link_lower[i, n + i] = -min_w  # -min_w * z_i
        constraints.append(LinearConstraint(A_link_lower, 0.0, np.inf))

    # Cardinality: min_assets <= sum(z_i) <= max_assets
    if cardinality:
        A_card = np.zeros(n_vars)
        A_card[n:] = 1.0
        lb_card = cardinality.min_assets
        ub_card = cardinality.max_assets if cardinality.max_assets is not None else n
        constraints.append(LinearConstraint(A_card, lb_card, ub_card))

    # Weight limits per sector
    for wl in weight_limits:
        A_wl = np.zeros(n_vars)
        for a in wl.assets:
            if 0 <= a < n:
                A_wl[a] = 1.0
        constraints.append(LinearConstraint(A_wl, wl.min_pct, wl.max_pct))

    # Exclusions: z_a + z_b <= 1
    if exclusions:
        for exc in exclusions:
            A_exc = np.zeros(n_vars)
            if 0 <= exc.asset_a < n:
                A_exc[n + exc.asset_a] = 1.0
            if 0 <= exc.asset_b < n:
                A_exc[n + exc.asset_b] = 1.0
            constraints.append(LinearConstraint(A_exc, 0.0, 1.0))

    bounds_obj = Bounds(lower, upper)

    result = milp(
        c,
        constraints=constraints,
        integrality=integrality,
        bounds=bounds_obj,
    )

    if result.success:
        weights = result.x[:n]
        selected = result.x[n:]
        return {
            "feasible": True,
            "weights": weights,
            "selected": np.round(selected).astype(int),
        }
    else:
        return {"feasible": False, "weights": None, "selected": None}
