"""Quick arithmetic checks that catch obvious infeasibilities without solving.

These run in O(n) and catch contradictions like:
- sum of sector minimums > max_assets
- min_w * min_assets > budget
- sector max_pct sums to < 1.0 when budget requires 1.0
"""

from portfolio_optimizer.constraints import (
    CardinalityConstraint,
    SectorMinConstraint,
    WeightLimitConstraint,
    BudgetConstraint,
    PositionBoundsConstraint,
    FeasibilityResult,
)


def run_quick_checks(
    n_assets: int,
    cardinality: CardinalityConstraint | None,
    sector_mins: list[SectorMinConstraint],
    weight_limits: list[WeightLimitConstraint],
    budget: BudgetConstraint | None,
    position_bounds: PositionBoundsConstraint | None,
) -> FeasibilityResult | None:
    """Run quick arithmetic checks. Returns FeasibilityResult if infeasible, None if no issue found."""

    # Check 1: sum of sector minimums > max_assets
    if cardinality and cardinality.max_assets is not None and sector_mins:
        # Count minimum assets needed across disjoint sectors
        total_min = sum(sm.min_count for sm in sector_mins)
        if total_min > cardinality.max_assets:
            sectors_detail = ", ".join(
                f"{sm.sector}(min={sm.min_count})" for sm in sector_mins
            )
            return FeasibilityResult(
                feasible=False,
                method="quick_check",
                infeasible_constraints=[
                    f"cardinality(max={cardinality.max_assets})",
                    *[f"sector_min({sm.sector}, min={sm.min_count})" for sm in sector_mins],
                ],
                suggestion=(
                    f"Sector minimums sum to {total_min} but max_assets={cardinality.max_assets}. "
                    f"Increase max_assets to at least {total_min} or reduce sector minimums."
                ),
            )

    # Check 2: min_assets > n_assets
    if cardinality:
        if cardinality.min_assets > n_assets:
            return FeasibilityResult(
                feasible=False,
                method="quick_check",
                infeasible_constraints=[
                    f"cardinality(min={cardinality.min_assets})",
                    f"universe(n_assets={n_assets})",
                ],
                suggestion=(
                    f"min_assets={cardinality.min_assets} but only {n_assets} assets available."
                ),
            )
        if cardinality.max_assets is not None and cardinality.max_assets < cardinality.min_assets:
            return FeasibilityResult(
                feasible=False,
                method="quick_check",
                infeasible_constraints=[
                    f"cardinality(min={cardinality.min_assets}, max={cardinality.max_assets})",
                ],
                suggestion=(
                    f"max_assets={cardinality.max_assets} < min_assets={cardinality.min_assets}."
                ),
            )

    # Check 3: min_w * min_assets > budget
    if position_bounds and cardinality and budget:
        min_total = position_bounds.min_w * cardinality.min_assets
        if min_total > budget.total + 1e-9:
            return FeasibilityResult(
                feasible=False,
                method="quick_check",
                infeasible_constraints=[
                    f"position_bounds(min_w={position_bounds.min_w})",
                    f"cardinality(min={cardinality.min_assets})",
                    f"budget(total={budget.total})",
                ],
                suggestion=(
                    f"min_w={position_bounds.min_w} x min_assets={cardinality.min_assets} = "
                    f"{min_total:.4f} > budget={budget.total}. "
                    f"Reduce min_w or min_assets."
                ),
            )

    # Check 4: max_w * max_assets < budget (can't fill the budget)
    if position_bounds and cardinality and budget and cardinality.max_assets is not None:
        max_total = position_bounds.max_w * cardinality.max_assets
        if max_total < budget.total - 1e-9:
            return FeasibilityResult(
                feasible=False,
                method="quick_check",
                infeasible_constraints=[
                    f"position_bounds(max_w={position_bounds.max_w})",
                    f"cardinality(max={cardinality.max_assets})",
                    f"budget(total={budget.total})",
                ],
                suggestion=(
                    f"max_w={position_bounds.max_w} x max_assets={cardinality.max_assets} = "
                    f"{max_total:.4f} < budget={budget.total}. "
                    f"Increase max_w or max_assets."
                ),
            )

    # Check 5: sector min_pct sums > 1.0
    if weight_limits:
        total_min_pct = sum(wl.min_pct for wl in weight_limits)
        if total_min_pct > 1.0 + 1e-9:
            return FeasibilityResult(
                feasible=False,
                method="quick_check",
                infeasible_constraints=[
                    f"weight_limit({wl.sector}, min_pct={wl.min_pct})"
                    for wl in weight_limits if wl.min_pct > 0
                ],
                suggestion=(
                    f"Sector min_pct values sum to {total_min_pct:.2%} > 100%. "
                    f"Reduce some sector minimums."
                ),
            )

    # Check 6: sector max_pct sums < 1.0 (can't fill budget)
    if weight_limits and budget:
        total_max_pct = sum(wl.max_pct for wl in weight_limits)
        # Only relevant if ALL assets belong to some sector
        # This is a conservative check — may not apply if assets span multiple sectors
        # We check only if weight_limits cover all assets
        all_sector_assets = set()
        for wl in weight_limits:
            all_sector_assets.update(wl.assets)
        if len(all_sector_assets) >= n_assets and total_max_pct < budget.total - 1e-9:
            return FeasibilityResult(
                feasible=False,
                method="quick_check",
                infeasible_constraints=[
                    f"weight_limit({wl.sector}, max_pct={wl.max_pct})"
                    for wl in weight_limits
                ] + [f"budget(total={budget.total})"],
                suggestion=(
                    f"Sector max_pct values sum to {total_max_pct:.2%} < budget={budget.total}. "
                    f"Increase some sector limits."
                ),
            )

    return None  # No quick contradiction found
