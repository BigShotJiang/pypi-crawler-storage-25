import DashboardGate from "@/components/DashboardGate";

export default function Home() {
  return <DashboardGate />;
}
