"use client";

import dynamic from "next/dynamic";

/**
 * Client-only shell: avoids hydration mismatches when extensions inject
 * attributes (e.g. fdprocessedid) onto form controls before React hydrates.
 */
const Dashboard = dynamic(() => import("@/components/Dashboard"), {
  ssr: false,
  loading: () => (
    <div className="min-h-screen flex flex-col items-center justify-center gap-2 bg-background text-muted text-sm font-mono">
      <span className="text-foreground font-semibold tracking-tight">
        <span className="text-accent">Nabla</span>Quant
      </span>
      <span>Loading dashboard…</span>
    </div>
  ),
});

export default function DashboardGate() {
  return <Dashboard />;
}
