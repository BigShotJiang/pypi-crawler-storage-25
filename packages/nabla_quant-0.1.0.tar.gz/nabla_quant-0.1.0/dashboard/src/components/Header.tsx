"use client";

export default function Header() {
  return (
    <header className="h-12 flex-shrink-0 flex items-center justify-between px-5 border-b border-border bg-surface">
      <div className="flex items-center gap-3">
        <span className="text-lg font-semibold tracking-tight">
          <span className="text-accent">Nabla</span>
          <span className="text-foreground">Quant</span>
        </span>
        <span className="text-xs text-muted font-mono px-2 py-0.5 rounded bg-background border border-border">
          PDE Engine
        </span>
      </div>
      <div className="flex items-center gap-4 text-xs text-muted">
        <span>Crank-Nicolson + AAD</span>
        <span className="h-4 w-px bg-border" />
        <span className="text-foreground/80">JBAC Options Pricing Engine</span>
      </div>
    </header>
  );
}
