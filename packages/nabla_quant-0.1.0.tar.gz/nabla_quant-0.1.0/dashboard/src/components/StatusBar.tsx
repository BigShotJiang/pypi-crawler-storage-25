"use client";

interface Props {
  connected: boolean;
  syncing: boolean;
  lastComputeMs: number | null;
}

export default function StatusBar({ connected, syncing, lastComputeMs }: Props) {
  const statusLabel = !connected ? "OFFLINE" : syncing ? "SYNC" : "LIVE";
  const statusColor = !connected
    ? "text-negative"
    : syncing
      ? "text-warning"
      : "text-positive";

  return (
    <footer className="h-7 flex-shrink-0 flex items-center justify-between px-4 border-t border-border bg-surface text-xs text-muted font-mono">
      <div className="flex items-center gap-4">
        <span className={statusColor}>
          ● {statusLabel}
        </span>
        <span>JBAC Options Pricing Engine</span>
      </div>
      <div className="flex items-center gap-4">
        {lastComputeMs !== null && (
          <span>
            Last round-trip: {lastComputeMs.toFixed(1)}ms
          </span>
        )}
        <span>NablaQuant v0.1.0</span>
      </div>
    </footer>
  );
}
