"use client";

import { useEffect, useState } from "react";
import Plot from "./PlotlyChart";
import { PricingParams, SurfaceData } from "@/lib/types";

/* eslint-disable @typescript-eslint/no-explicit-any */

interface Props {
  params: PricingParams;
  surfaceOverride?: SurfaceData | null;
}

const PLOTLY_LAYOUT: any = {
  autosize: true,
  margin: { l: 0, r: 0, t: 30, b: 0 },
  paper_bgcolor: "rgba(0,0,0,0)",
  plot_bgcolor: "rgba(0,0,0,0)",
  font: { color: "#c5c8d4", family: "var(--font-mono), monospace", size: 10 },
  scene: {
    xaxis: { title: "Spot (S)", gridcolor: "#1e2333", color: "#6b7280", showbackground: false },
    yaxis: { title: "Expiry (T)", gridcolor: "#1e2333", color: "#6b7280", showbackground: false },
    zaxis: { title: "Value (V)", gridcolor: "#1e2333", color: "#6b7280", showbackground: false },
    bgcolor: "rgba(0,0,0,0)",
    camera: { eye: { x: 1.6, y: -1.6, z: 1.0 } },
  },
};

const SPOT_STEPS = 25;
const EXPIRY_STEPS = 15;

export default function SurfacePlot({ params, surfaceOverride }: Props) {
  const [data, setData] = useState<SurfaceData | null>(null);

  useEffect(() => {
    if (surfaceOverride) {
      setData(surfaceOverride);
      return;
    }
    setData(analyticalSurface(params));
  }, [surfaceOverride, params]);

  return (
    <div className="rounded-lg bg-surface border border-border p-4 relative">
      <h3 className="text-sm font-semibold text-muted mb-2">
        Option Value Surface - V(S, T)
      </h3>
      <div className="h-[420px]">
        {data ? (
          <Plot
            data={[
              {
                type: "surface",
                x: data.spots,
                y: data.expiries,
                z: data.values,
                colorscale: [
                  [0, "#1e3a5f"],
                  [0.25, "#2563eb"],
                  [0.5, "#3b82f6"],
                  [0.75, "#60a5fa"],
                  [1, "#93c5fd"],
                ],
                showscale: true,
                colorbar: {
                  len: 0.6,
                  thickness: 12,
                  tickfont: { size: 9, color: "#6b7280" },
                },
                opacity: 0.92,
              } as any,
            ]}
            layout={PLOTLY_LAYOUT}
            config={{ responsive: true, displayModeBar: true } as any}
            useResizeHandler
            style={{ width: "100%", height: "100%" }}
          />
        ) : (
          <div className="h-full flex items-center justify-center text-muted text-sm">
            Computing surface...
          </div>
        )}
      </div>
    </div>
  );
}

function analyticalSurface(params: PricingParams): SurfaceData {
  const { strike: K, rate: r, volatility: sigma, option_type: opt, dividend: q } = params;
  const spotLo = params.spot * 0.5;
  const spotHi = params.spot * 1.5;
  const expLo = 0.05;
  const expHi = Math.max(params.expiry, 0.1);

  const spots = Array.from({ length: SPOT_STEPS }, (_, i) =>
    Math.round((spotLo + (spotHi - spotLo) * (i / (SPOT_STEPS - 1))) * 100) / 100
  );
  const expiries = Array.from({ length: EXPIRY_STEPS }, (_, j) =>
    Math.round((expLo + (expHi - expLo) * (j / (EXPIRY_STEPS - 1))) * 1000) / 1000
  );

  function normCdf(x: number) {
    const a1 = 0.254829592, a2 = -0.284496736, a3 = 1.421413741;
    const a4 = -1.453152027, a5 = 1.061405429, p = 0.3275911;
    const sign = x < 0 ? -1 : 1;
    x = Math.abs(x) / Math.sqrt(2);
    const t = 1.0 / (1.0 + p * x);
    const y = 1.0 - ((((a5 * t + a4) * t + a3) * t + a2) * t + a1) * t * Math.exp(-x * x);
    return 0.5 * (1.0 + sign * y);
  }

  const values = expiries.map((T) =>
    spots.map((S) => {
      if (T < 1e-6) return Math.max(opt === "call" ? S - K : K - S, 0);
      const d1 = (Math.log(S / K) + (r - q + 0.5 * sigma ** 2) * T) / (sigma * Math.sqrt(T));
      const d2 = d1 - sigma * Math.sqrt(T);
      if (opt === "call")
        return S * Math.exp(-q * T) * normCdf(d1) - K * Math.exp(-r * T) * normCdf(d2);
      return K * Math.exp(-r * T) * normCdf(-d2) - S * Math.exp(-q * T) * normCdf(-d1);
    })
  );

  return { spots, expiries, values };
}
