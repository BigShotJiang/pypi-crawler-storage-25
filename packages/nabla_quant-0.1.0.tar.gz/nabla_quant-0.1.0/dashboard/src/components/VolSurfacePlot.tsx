"use client";

import { useEffect, useState, useCallback, useRef } from "react";
import Plot from "./PlotlyChart";
import { PricingParams } from "@/lib/types";

/* eslint-disable @typescript-eslint/no-explicit-any */

const API_BASE = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000";

interface Props {
  params: PricingParams;
  marketSymbol?: string;
}

export default function VolSurfacePlot({ params, marketSymbol }: Props) {
  const [data, setData] = useState<{ spots: number[]; expiries: number[]; vols: number[][] } | null>(null);
  const [source, setSource] = useState<"market" | "parametric">("parametric");
  const [loading, setLoading] = useState(false);
  const abortRef = useRef<AbortController | null>(null);

  const computeVolSurface = useCallback(async () => {
    abortRef.current?.abort();
    const ctrl = new AbortController();
    abortRef.current = ctrl;
    setLoading(true);

    if (marketSymbol) {
      try {
        const resp = await fetch(
          `${API_BASE}/api/v1/market/vol_surface?symbol=${encodeURIComponent(marketSymbol)}&max_expiries=6`,
          { signal: ctrl.signal }
        );
        if (resp.ok) {
          const j = await resp.json();
          if (!ctrl.signal.aborted && j.strikes?.length && j.expiries?.length) {
            setData({ spots: j.strikes, expiries: j.expiries, vols: j.vols });
            setSource("market");
            setLoading(false);
            return;
          }
        }
      } catch {
        // fall through to parametric
      }
    }

    const spotLo = params.spot * 0.5;
    const spotHi = params.spot * 1.5;
    const expLo = 0.05;
    const expHi = Math.max(params.expiry, 0.1);
    const spotSteps = 30;
    const expirySteps = 20;

    const spots = Array.from({ length: spotSteps }, (_, i) =>
      Math.round((spotLo + (spotHi - spotLo) * (i / (spotSteps - 1))) * 100) / 100
    );
    const expiries = Array.from({ length: expirySteps }, (_, j) =>
      Math.round((expLo + (expHi - expLo) * (j / (expirySteps - 1))) * 1000) / 1000
    );

    const baseVol = params.volatility;
    const skewCoeff = -0.15;
    const termSlope = 0.02;

    const vols = expiries.map((T) =>
      spots.map((S) => {
        const moneyness = Math.log(S / params.strike);
        return Math.max(0.01, baseVol + skewCoeff * moneyness + termSlope * Math.sqrt(T));
      })
    );

    if (!ctrl.signal.aborted) {
      setData({ spots, expiries, vols });
      setSource("parametric");
    }
    setLoading(false);
  }, [params, marketSymbol]);

  useEffect(() => {
    computeVolSurface().catch(() => {
      // Silently fall through; parametric fallback is already applied inside computeVolSurface
    });
    return () => abortRef.current?.abort();
  }, [computeVolSurface]);

  const layout: any = {
    autosize: true,
    margin: { l: 0, r: 0, t: 30, b: 0 },
    paper_bgcolor: "rgba(0,0,0,0)",
    plot_bgcolor: "rgba(0,0,0,0)",
    font: { color: "#c5c8d4", family: "var(--font-mono), monospace", size: 10 },
    scene: {
      xaxis: { title: source === "market" ? "Strike (K)" : "Spot (S)", gridcolor: "#1e2333", color: "#6b7280", showbackground: false },
      yaxis: { title: "Expiry (T)", gridcolor: "#1e2333", color: "#6b7280", showbackground: false },
      zaxis: { title: "σ (vol)", gridcolor: "#1e2333", color: "#6b7280", showbackground: false },
      bgcolor: "rgba(0,0,0,0)",
      camera: { eye: { x: 1.5, y: -1.8, z: 0.9 } },
    },
  };

  return (
    <div className="rounded-lg bg-surface border border-border p-4 relative">
      <h3 className="text-sm font-semibold text-muted mb-2">
        Implied Volatility Surface - σ({source === "market" ? "K" : "S"}, T)
        <span className={`ml-2 text-[10px] font-normal ${source === "market" ? "text-positive" : "text-muted/70"}`}>
          {source === "market" ? `LIVE (${marketSymbol})` : "parametric"}
        </span>
        {loading && (
          <span className="ml-2 text-xs text-warning animate-pulse">loading...</span>
        )}
      </h3>
      <div className="h-[420px]">
        {data ? (
          <Plot
            data={[
              {
                type: "surface",
                x: data.spots,
                y: data.expiries,
                z: data.vols,
                colorscale: [
                  [0, "#1e293b"],
                  [0.2, "#7c3aed"],
                  [0.4, "#a855f7"],
                  [0.6, "#c084fc"],
                  [0.8, "#e879f9"],
                  [1, "#f0abfc"],
                ],
                showscale: true,
                colorbar: {
                  len: 0.6,
                  thickness: 12,
                  tickfont: { size: 9, color: "#6b7280" },
                },
                opacity: 0.88,
              } as any,
            ]}
            layout={layout}
            config={{ responsive: true, displayModeBar: true } as any}
            useResizeHandler
            style={{ width: "100%", height: "100%" }}
          />
        ) : (
          <div className="h-full flex items-center justify-center text-muted text-sm">
            Computing volatility surface...
          </div>
        )}
      </div>
    </div>
  );
}
