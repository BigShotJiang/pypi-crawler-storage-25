"use client";

import { useState, useCallback, useEffect, useRef } from "react";
import { PricingParams, GreeksResult, SurfaceData, DEFAULT_PARAMS } from "@/lib/types";
import { useNablaSocket, buildSingleRequest, buildSurfaceRequest } from "@/lib/useNablaSocket";
import Header from "@/components/Header";
import ParameterPanel from "@/components/ParameterPanel";
import PricingCard from "@/components/PricingCard";
import SurfacePlot from "@/components/SurfacePlot";
import VolSurfacePlot from "@/components/VolSurfacePlot";
import GreeksHeatmap from "@/components/GreeksHeatmap";
import StatusBar from "@/components/StatusBar";
import MarketDataPanel from "@/components/MarketDataPanel";

const DEBOUNCE_MS = 250;

export default function Dashboard() {
  const [params, setParams] = useState<PricingParams>(DEFAULT_PARAMS);
  const [greeks, setGreeks] = useState<GreeksResult | null>(null);
  const [surface, setSurface] = useState<SurfaceData | null>(null);
  const [marketSymbol, setMarketSymbol] = useState<string | undefined>(undefined);
  const {
    connected,
    pendingReplies,
    lastComputeMs,
    send,
    onMessage,
    onSocketReady,
  } = useNablaSocket();
  const timerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const paramsRef = useRef(params);
  paramsRef.current = params;
  /** Latest debounced batch id; responses with a lower id are dropped (out-of-order / stale). */
  const latestRequestIdRef = useRef(0);
  const requestSeqRef = useRef(0);

  const doSendBatch = useCallback(
    (p: PricingParams) => {
      const id = ++requestSeqRef.current;
      const okSingle = send({ ...buildSingleRequest(p), request_id: id });
      const okSurface = send({ ...buildSurfaceRequest(p), request_id: id });
      if (okSingle && okSurface) {
        latestRequestIdRef.current = id;
      }
    },
    [send]
  );

  // When sliders move, drop stale server snapshots so PricingCard/SurfacePlot
  // immediately show analytical fallback until the matching PDE response returns.
  useEffect(() => {
    setGreeks(null);
    setSurface(null);
  }, [params]);

  // Handle incoming WebSocket responses
  useEffect(() => {
    onMessage((res) => {
      const rid = res.request_id;
      if (rid !== undefined && rid !== latestRequestIdRef.current) {
        return;
      }
      if (res.type === "single_price") {
        setGreeks(res.data as GreeksResult);
      } else if (res.type === "surface") {
        setSurface(res.data as SurfaceData);
      }
    });
  }, [onMessage]);

  // Debounced refresh: depend on params only - NOT on connection status.
  // (Tying this to status caused LIVE/CALC flicker: each reply flipped status and re-scheduled sends.)
  useEffect(() => {
    if (timerRef.current) clearTimeout(timerRef.current);
    timerRef.current = setTimeout(() => {
      doSendBatch(params);
    }, DEBOUNCE_MS);
    return () => {
      if (timerRef.current) clearTimeout(timerRef.current);
    };
  }, [params, doSendBatch]);

  // When the socket opens (or reconnects), request once with current params.
  useEffect(() => {
    return onSocketReady(() => {
      doSendBatch(paramsRef.current);
    });
  }, [onSocketReady, doSendBatch]);

  const handleParamsChange = useCallback((newParams: PricingParams) => {
    setParams(newParams);
  }, []);

  const applyParamPatch = useCallback((patch: Partial<PricingParams>) => {
    setParams((prev) => {
      const next = { ...prev };
      for (const [k, v] of Object.entries(patch)) {
        if (v !== undefined && v !== null) {
          (next as Record<string, unknown>)[k] = v;
        }
      }
      return next as PricingParams;
    });
  }, []);

  const handleSymbolChange = useCallback((sym: string) => {
    setMarketSymbol(sym);
  }, []);

  return (
    <div className="flex flex-col h-screen overflow-hidden">
      <Header />
      <div className="flex flex-1 overflow-hidden">
        <aside className="w-80 flex-shrink-0 border-r border-border overflow-y-auto bg-surface">
          <ParameterPanel
            params={params}
            onChange={handleParamsChange}
            connected={connected}
            syncing={pendingReplies > 0}
          />
          <MarketDataPanel onApplyParams={applyParamPatch} onSymbolChange={handleSymbolChange} />
        </aside>

        <main className="flex-1 overflow-y-auto p-4 space-y-4">
          <div className="grid grid-cols-1 xl:grid-cols-4 gap-4">
            <PricingCard
              params={params}
              greeksOverride={greeks}
              setWsStatus={() => {}}
              setLastComputeMs={() => {}}
            />
          </div>

          <div className="grid grid-cols-1 xl:grid-cols-2 gap-4">
            <SurfacePlot params={params} surfaceOverride={surface} />
            <VolSurfacePlot params={params} marketSymbol={marketSymbol} />
          </div>

          <GreeksHeatmap params={params} />
        </main>
      </div>
      <StatusBar
        connected={connected}
        syncing={pendingReplies > 0}
        lastComputeMs={lastComputeMs}
      />
    </div>
  );
}
