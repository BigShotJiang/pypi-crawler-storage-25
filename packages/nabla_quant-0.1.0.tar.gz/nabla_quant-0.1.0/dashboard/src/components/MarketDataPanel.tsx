"use client";

import { useState, useCallback } from "react";
import { PricingParams } from "@/lib/types";

const API_BASE = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000";

interface ChainRow {
  strike: number;
  last_price: number | null;
  implied_volatility: number | null;
  bid: number | null;
  ask: number | null;
}

interface ChainPayload {
  symbol: string;
  expiration: string;
  spot: number;
  time_to_expiry_years: number;
  calls: ChainRow[];
  puts: ChainRow[];
  risk_free_rate: number;
  dividend_yield: number;
}

interface Props {
  onApplyParams: (patch: Partial<PricingParams>) => void;
  onSymbolChange?: (symbol: string) => void;
}

export default function MarketDataPanel({ onApplyParams, onSymbolChange }: Props) {
  const [symbol, setSymbol] = useState("SPY");
  const [expiries, setExpiries] = useState<string[]>([]);
  const [expiration, setExpiration] = useState("");
  const [chain, setChain] = useState<ChainPayload | null>(null);
  const [msg, setMsg] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const loadQuoteAndExpiries = useCallback(async () => {
    setBusy(true);
    setMsg(null);
    setChain(null);
    try {
      const q = await fetch(
        `${API_BASE}/api/v1/market/quote?symbol=${encodeURIComponent(symbol.trim())}`
      );
      const jq = await q.json();
      if (!q.ok) throw new Error(typeof jq.detail === "string" ? jq.detail : "Quote failed");
      onApplyParams({
        spot: jq.spot,
        ...(typeof jq.risk_free_rate === "number" ? { rate: jq.risk_free_rate } : {}),
        ...(typeof jq.dividend_yield === "number" ? { dividend: jq.dividend_yield } : {}),
      });
      if (jq.symbol) onSymbolChange?.(jq.symbol);

      const e = await fetch(
        `${API_BASE}/api/v1/market/expiries?symbol=${encodeURIComponent(symbol.trim())}`
      );
      const je = await e.json();
      if (!e.ok) throw new Error(typeof je.detail === "string" ? je.detail : "Expiries failed");
      const ex = je.expirations as string[];
      setExpiries(ex);
      if (ex.length) setExpiration(ex[0]);
      setMsg(`${jq.symbol} S=${jq.spot} | r=${((jq.risk_free_rate ?? 0) * 100).toFixed(2)}% q=${((jq.dividend_yield ?? 0) * 100).toFixed(2)}% - pick expiry`);
    } catch (err: unknown) {
      setMsg(err instanceof Error ? err.message : "Request failed");
    } finally {
      setBusy(false);
    }
  }, [symbol, onApplyParams]);

  const loadChain = useCallback(async () => {
    if (!expiration) {
      setMsg("Select an expiration first (load quote).");
      return;
    }
    setBusy(true);
    setMsg(null);
    try {
      const r = await fetch(
        `${API_BASE}/api/v1/market/chain?symbol=${encodeURIComponent(symbol.trim())}&expiration=${encodeURIComponent(expiration)}`
      );
      const j = await r.json();
      if (!r.ok) throw new Error(typeof j.detail === "string" ? j.detail : "Chain failed");
      const chainData = j as ChainPayload;
      setChain(chainData);
      onApplyParams({
        spot: chainData.spot,
        expiry: chainData.time_to_expiry_years,
        ...(typeof chainData.risk_free_rate === "number" ? { rate: chainData.risk_free_rate } : {}),
        ...(typeof chainData.dividend_yield === "number" ? { dividend: chainData.dividend_yield } : {}),
      });
      setMsg(`Chain ${chainData.symbol} ${chainData.expiration} (${chainData.calls.length} calls near ATM) | r=${((chainData.risk_free_rate ?? 0) * 100).toFixed(2)}% q=${((chainData.dividend_yield ?? 0) * 100).toFixed(2)}%`);
    } catch (err: unknown) {
      setMsg(err instanceof Error ? err.message : "Request failed");
    } finally {
      setBusy(false);
    }
  }, [symbol, expiration, onApplyParams]);

  const applyRow = useCallback(
    (row: ChainRow, side: "call" | "put") => {
      if (!chain) return;
      const vol =
        row.implied_volatility != null && row.implied_volatility > 0
          ? row.implied_volatility
          : 0.25;
      onApplyParams({
        spot: chain.spot,
        strike: row.strike,
        expiry: chain.time_to_expiry_years,
        volatility: vol,
        option_type: side === "call" ? "call" : "put",
      });
      setMsg(`Applied ${side} K=${row.strike} σ=${(vol * 100).toFixed(1)}%`);
    },
    [chain, onApplyParams]
  );

  return (
    <div className="p-4 border-t border-border space-y-3">
      <h2 className="text-sm font-semibold uppercase tracking-wider text-muted">
        Real-World Options (Yahoo)
      </h2>
      <p className="text-[10px] text-muted leading-relaxed">
        <strong>Quote</strong> sets <strong>spot S</strong> (underlying). It does not replace the option{" "}
        <strong>premium V</strong> in the top row - that value is the priced contract for your current K, T, σ, and call/put.
        Use <strong>Load chain</strong> then <strong>use</strong> on a row to align K, T, and implied vol with a listed strike.
      </p>

      <div className="flex gap-2">
        <input
          value={symbol}
          onChange={(e) => setSymbol(e.target.value.toUpperCase())}
          className="flex-1 rounded border border-border bg-background px-2 py-1.5 text-xs font-mono text-foreground"
          placeholder="SPY"
          maxLength={12}
        />
        <button
          type="button"
          disabled={busy}
          onClick={loadQuoteAndExpiries}
          className="rounded bg-accent px-3 py-1.5 text-xs font-semibold text-white disabled:opacity-50"
        >
          Quote
        </button>
      </div>

      {expiries.length > 0 && (
        <div className="space-y-1">
          <label className="text-[10px] text-muted">Expiration</label>
          <select
            value={expiration}
            onChange={(e) => setExpiration(e.target.value)}
            className="w-full rounded border border-border bg-background px-2 py-1.5 text-xs font-mono text-foreground"
          >
            {expiries.slice(0, 24).map((d) => (
              <option key={d} value={d}>
                {d}
              </option>
            ))}
          </select>
          <button
            type="button"
            disabled={busy}
            onClick={loadChain}
            className="w-full rounded border border-border bg-surface-hover py-1.5 text-xs font-medium text-foreground disabled:opacity-50"
          >
            Load chain (near ATM)
          </button>
        </div>
      )}

      {chain && (
        <div className="max-h-48 overflow-y-auto rounded border border-border text-[10px]">
          <table className="w-full border-collapse">
            <thead className="sticky top-0 bg-surface text-muted">
              <tr>
                <th className="p-1 text-left">K</th>
                <th className="p-1">IV</th>
                <th className="p-1">Call</th>
                <th className="p-1">Put</th>
              </tr>
            </thead>
            <tbody>
              {chain.calls.map((c) => {
                const p = chain.puts.find((x) => Math.abs(x.strike - c.strike) < 1e-6);
                return (
                  <tr key={c.strike} className="border-t border-border/60">
                    <td className="p-1 font-mono">{c.strike.toFixed(0)}</td>
                    <td className="p-1 text-center font-mono text-muted">
                      {c.implied_volatility != null
                        ? `${(c.implied_volatility * 100).toFixed(1)}%`
                        : "-"}
                    </td>
                    <td className="p-1 text-center">
                      <button
                        type="button"
                        className="text-accent hover:underline"
                        onClick={() => applyRow(c, "call")}
                      >
                        use
                      </button>
                    </td>
                    <td className="p-1 text-center">
                      {p ? (
                        <button
                          type="button"
                          className="text-accent hover:underline"
                          onClick={() => applyRow(p, "put")}
                        >
                          use
                        </button>
                      ) : (
                        "-"
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}

      {msg && (
        <p className={`text-[10px] ${!msg.toLowerCase().includes("fail") && !msg.toLowerCase().includes("error") ? "text-positive" : "text-warning"}`}>
          {msg}
        </p>
      )}
    </div>
  );
}
