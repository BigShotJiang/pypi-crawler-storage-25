"use client";

import { useEffect, useState, useCallback, useRef } from "react";
import Plot from "./PlotlyChart";
import { PricingParams, GreekName } from "@/lib/types";

/* eslint-disable @typescript-eslint/no-explicit-any */

interface Props {
  params: PricingParams;
}

const GREEK_CONFIG: Record<GreekName, { label: string; colorscale: [number, string][] }> = {
  delta: {
    label: "Delta (Δ)",
    colorscale: [
      [0, "#dc2626"], [0.5, "#1e1e2e"], [1, "#22c55e"],
    ],
  },
  gamma: {
    label: "Gamma (Γ)",
    colorscale: [
      [0, "#0f172a"], [0.5, "#3b82f6"], [1, "#93c5fd"],
    ],
  },
  theta: {
    label: "Theta (Θ)",
    colorscale: [
      [0, "#7f1d1d"], [0.5, "#991b1b"], [1, "#fee2e2"],
    ],
  },
  vega: {
    label: "Vega (ν)",
    colorscale: [
      [0, "#0f172a"], [0.5, "#7c3aed"], [1, "#c4b5fd"],
    ],
  },
  rho: {
    label: "Rho (ρ)",
    colorscale: [
      [0, "#1e3a5f"], [0.5, "#2563eb"], [1, "#bfdbfe"],
    ],
  },
};

export default function GreeksHeatmap({ params }: Props) {
  const [selectedGreek, setSelectedGreek] = useState<GreekName>("delta");
  const [gridData, setGridData] = useState<Record<GreekName, number[][]> | null>(null);
  const [spots, setSpots] = useState<number[]>([]);
  const [expiries, setExpiries] = useState<number[]>([]);
  const [loading, setLoading] = useState(false);
  const computeRef = useRef(0);

  const computeGrid = useCallback(() => {
    const id = ++computeRef.current;
    setLoading(true);

    const spotLo = params.spot * 0.5;
    const spotHi = params.spot * 1.5;
    const expLo = 0.05;
    const expHi = Math.max(params.expiry, 0.1);
    const nS = 20;
    const nT = 12;

    const ss = Array.from({ length: nS }, (_, i) =>
      Math.round((spotLo + (spotHi - spotLo) * (i / (nS - 1))) * 100) / 100
    );
    const tt = Array.from({ length: nT }, (_, j) =>
      Math.round((expLo + (expHi - expLo) * (j / (nT - 1))) * 1000) / 1000
    );

    const { strike: K, rate: r, volatility: sigma, option_type: opt, dividend: q } = params;
    const grids: Record<GreekName, number[][]> = { delta: [], gamma: [], theta: [], vega: [], rho: [] };

    for (const T of tt) {
      const dRow: number[] = [], gRow: number[] = [], tRow: number[] = [], vRow: number[] = [], rRow: number[] = [];
      for (const S of ss) {
        const g = bsGreeks(S, K, T, r, sigma, q, opt);
        dRow.push(g.delta);
        gRow.push(g.gamma);
        tRow.push(g.theta);
        vRow.push(g.vega);
        rRow.push(g.rho);
      }
      grids.delta.push(dRow);
      grids.gamma.push(gRow);
      grids.theta.push(tRow);
      grids.vega.push(vRow);
      grids.rho.push(rRow);
    }

    if (computeRef.current === id) {
      setSpots(ss);
      setExpiries(tt);
      setGridData(grids);
      setLoading(false);
    }
  }, [params]);

  useEffect(() => {
    computeGrid();
  }, [computeGrid]);

  const cfg = GREEK_CONFIG[selectedGreek];
  const z = gridData?.[selectedGreek] ?? [];

  const layout: any = {
    autosize: true,
    margin: { l: 60, r: 20, t: 30, b: 50 },
    paper_bgcolor: "rgba(0,0,0,0)",
    plot_bgcolor: "rgba(0,0,0,0)",
    font: { color: "#c5c8d4", family: "var(--font-mono), monospace", size: 10 },
    xaxis: { title: "Spot (S)", gridcolor: "#1e2333", color: "#6b7280" },
    yaxis: { title: "Expiry (T)", gridcolor: "#1e2333", color: "#6b7280" },
  };

  return (
    <div className="rounded-lg bg-surface border border-border p-4">
      <div className="flex items-center justify-between mb-3">
        <h3 className="text-sm font-semibold text-muted">
          Greeks Heatmap - {cfg.label}
          {loading && (
            <span className="ml-2 text-xs text-warning animate-pulse">computing...</span>
          )}
        </h3>
        <div className="flex gap-1">
          {(Object.keys(GREEK_CONFIG) as GreekName[]).map((g) => (
            <button
              key={g}
              type="button"
              onClick={() => setSelectedGreek(g)}
              className={`px-2.5 py-1 rounded text-xs font-medium transition-colors ${
                selectedGreek === g
                  ? "bg-accent text-white"
                  : "bg-background border border-border text-muted hover:text-foreground"
              }`}
            >
              {GREEK_CONFIG[g].label.split(" ")[0]}
            </button>
          ))}
        </div>
      </div>
      <p className="text-[10px] text-muted mb-2 leading-relaxed">
        Analytical Black–Scholes slice: x-axis is spot S (0.5×-1.5× your current S), y-axis is time T.
        For a <strong>call</strong>, Δ rises from ~0 (OTM, left) toward ~1 (ITM, right) - red → green is expected.
        Uses the same K, r, σ, q as the sliders (browser-side BS, not the C++ grid).
      </p>
      <div className="h-[300px]">
        {gridData ? (
          <Plot
            data={[
              {
                type: "heatmap",
                x: spots,
                y: expiries,
                z: z,
                colorscale: cfg.colorscale,
                showscale: true,
                colorbar: {
                  len: 0.8,
                  thickness: 12,
                  tickfont: { size: 9, color: "#6b7280" },
                },
                hoverongaps: false,
              } as any,
            ]}
            layout={layout}
            config={{ responsive: true, displayModeBar: false } as any}
            useResizeHandler
            style={{ width: "100%", height: "100%" }}
          />
        ) : (
          <div className="h-full flex items-center justify-center text-muted text-sm">
            Computing Greeks grid...
          </div>
        )}
      </div>
    </div>
  );
}

function bsGreeks(S: number, K: number, T: number, r: number, sigma: number, q: number, opt: string) {
  if (T < 1e-6) {
    const intrinsic = opt === "call" ? Math.max(S - K, 0) : Math.max(K - S, 0);
    return { delta: 0, gamma: 0, theta: 0, vega: 0, rho: 0, price: intrinsic };
  }
  function normCdf(x: number) {
    const a1 = 0.254829592, a2 = -0.284496736, a3 = 1.421413741;
    const a4 = -1.453152027, a5 = 1.061405429, pp = 0.3275911;
    const sign = x < 0 ? -1 : 1;
    x = Math.abs(x) / Math.sqrt(2);
    const t = 1 / (1 + pp * x);
    const y = 1 - ((((a5 * t + a4) * t + a3) * t + a2) * t + a1) * t * Math.exp(-x * x);
    return 0.5 * (1 + sign * y);
  }
  function normPdf(x: number) { return Math.exp(-0.5 * x * x) / Math.sqrt(2 * Math.PI); }

  const d1 = (Math.log(S / K) + (r - q + 0.5 * sigma ** 2) * T) / (sigma * Math.sqrt(T));
  const d2 = d1 - sigma * Math.sqrt(T);
  const eqT = Math.exp(-q * T), erT = Math.exp(-r * T);

  const delta = opt === "call" ? eqT * normCdf(d1) : -eqT * normCdf(-d1);
  const gamma = eqT * normPdf(d1) / (S * sigma * Math.sqrt(T));
  const vega = S * eqT * normPdf(d1) * Math.sqrt(T);
  const rho = opt === "call" ? K * T * erT * normCdf(d2) : -K * T * erT * normCdf(-d2);
  const theta = -(S * sigma * eqT * normPdf(d1)) / (2 * Math.sqrt(T))
    + (opt === "call"
      ? q * S * eqT * normCdf(d1) - r * K * erT * normCdf(d2)
      : -q * S * eqT * normCdf(-d1) + r * K * erT * normCdf(-d2));

  return { delta, gamma, theta, vega, rho, price: 0 };
}
