"use client";

import { useEffect, useState } from "react";
import { PricingParams, GreeksResult } from "@/lib/types";

interface Props {
  params: PricingParams;
  greeksOverride?: GreeksResult | null;
  setWsStatus: (s: "connected" | "disconnected" | "computing") => void;
  setLastComputeMs: (ms: number | null) => void;
}

export default function PricingCard({ params, greeksOverride }: Props) {
  const [greeks, setGreeks] = useState<GreeksResult | null>(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (greeksOverride) {
      setGreeks(greeksOverride);
      setLoading(false);
      return;
    }
    // Fallback: analytical BS
    setGreeks(analyticalGreeks(params));
  }, [greeksOverride, params]);

  const metrics: {
    label: string;
    sub?: string;
    value: number | undefined | null;
    fmt: (v: number) => string;
    color: string;
  }[] = [
    {
      label: "Option V",
      sub: "Premium $/share - not spot S",
      value: greeks?.price,
      fmt: (v: number) => v.toFixed(4),
      color: "text-foreground",
    },
    { label: "Delta (Δ)", value: greeks?.delta, fmt: (v: number) => v.toFixed(5), color: greeks && greeks.delta >= 0 ? "text-positive" : "text-negative" },
    { label: "Gamma (Γ)", value: greeks?.gamma, fmt: (v: number) => v.toFixed(6), color: "text-accent" },
    { label: "Theta (Θ)", value: greeks?.theta, fmt: (v: number) => v.toFixed(4), color: greeks && greeks.theta >= 0 ? "text-positive" : "text-negative" },
    { label: "Vega (ν)", value: greeks?.vega, fmt: (v: number) => v.toFixed(4), color: "text-accent" },
    { label: "Rho (ρ)", value: greeks?.rho, fmt: (v: number) => v.toFixed(4), color: greeks && greeks.rho >= 0 ? "text-positive" : "text-negative" },
  ];

  return (
    <div className="col-span-4 grid grid-cols-6 gap-3">
      {metrics.map((m) => (
        <div key={m.label} className="rounded-lg bg-surface border border-border p-3 relative overflow-hidden">
          <div className="text-xs text-muted mb-0.5">{m.label}</div>
          {m.sub && (
            <div className="text-[9px] text-muted/70 leading-tight mb-1">{m.sub}</div>
          )}
          <div className={`text-lg font-mono font-semibold ${m.color} ${loading ? "opacity-50" : ""}`}>
            {m.value !== undefined && m.value !== null ? m.fmt(m.value) : "-"}
          </div>
          {loading && (
            <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-accent/30">
              <div className="h-full bg-accent animate-pulse w-1/2" />
            </div>
          )}
        </div>
      ))}
    </div>
  );
}

function analyticalGreeks(p: PricingParams): GreeksResult {
  const { spot: S, strike: K, expiry: T, rate: r, volatility: sigma, option_type: opt, dividend: q } = p;
  if (T < 1e-6) return { price: Math.max(opt === "call" ? S - K : K - S, 0), delta: 0, gamma: 0, theta: 0, vega: 0, rho: 0 };
  function normCdf(x: number) {
    const a1 = 0.254829592, a2 = -0.284496736, a3 = 1.421413741;
    const a4 = -1.453152027, a5 = 1.061405429, pp = 0.3275911;
    const sign = x < 0 ? -1 : 1;
    x = Math.abs(x) / Math.sqrt(2);
    const t = 1 / (1 + pp * x);
    const y = 1 - ((((a5 * t + a4) * t + a3) * t + a2) * t + a1) * t * Math.exp(-x * x);
    return 0.5 * (1 + sign * y);
  }
  function normPdf(x: number) { return Math.exp(-0.5 * x * x) / Math.sqrt(2 * Math.PI); }
  const d1 = (Math.log(S / K) + (r - q + 0.5 * sigma ** 2) * T) / (sigma * Math.sqrt(T));
  const d2 = d1 - sigma * Math.sqrt(T);
  const eqT = Math.exp(-q * T), erT = Math.exp(-r * T);
  const price = opt === "call"
    ? S * eqT * normCdf(d1) - K * erT * normCdf(d2)
    : K * erT * normCdf(-d2) - S * eqT * normCdf(-d1);
  const delta = opt === "call" ? eqT * normCdf(d1) : -eqT * normCdf(-d1);
  const gamma = eqT * normPdf(d1) / (S * sigma * Math.sqrt(T));
  const vega = S * eqT * normPdf(d1) * Math.sqrt(T);
  const rho = opt === "call" ? K * T * erT * normCdf(d2) : -K * T * erT * normCdf(-d2);
  const theta = -(S * sigma * eqT * normPdf(d1)) / (2 * Math.sqrt(T))
    + (opt === "call"
      ? q * S * eqT * normCdf(d1) - r * K * erT * normCdf(d2)
      : -q * S * eqT * normCdf(-d1) + r * K * erT * normCdf(-d2));
  return { price, delta, gamma, theta, vega, rho };
}
