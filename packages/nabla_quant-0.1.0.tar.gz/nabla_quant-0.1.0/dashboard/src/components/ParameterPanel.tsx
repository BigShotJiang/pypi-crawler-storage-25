"use client";

import { PricingParams } from "@/lib/types";

interface Props {
  params: PricingParams;
  onChange: (p: PricingParams) => void;
  connected: boolean;
  /** True while WS requests are in flight (replies not yet received). */
  syncing: boolean;
}

export default function ParameterPanel({ params, onChange, connected, syncing }: Props) {
  const update = (key: keyof PricingParams, value: number | string) => {
    onChange({ ...params, [key]: value });
  };

  const statusLabel = !connected ? "OFFLINE" : syncing ? "SYNC" : "LIVE";
  const dotClass = !connected
    ? "bg-negative"
    : syncing
      ? "bg-warning animate-pulse"
      : "bg-positive";

  return (
    <div className="p-4 space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-sm font-semibold uppercase tracking-wider text-muted">
          Market Parameters
        </h2>
        <div className="flex items-center gap-1.5" title={connected ? (syncing ? "Engine is updating plots & Greeks" : "Socket connected to API") : "Start API + refresh to connect"}>
          <span className={`w-2 h-2 rounded-full ${dotClass}`} />
          <span className="text-[10px] text-muted">{statusLabel}</span>
        </div>
      </div>

      <div className="rounded-md border border-border bg-background/80 px-3 py-2 text-[11px] text-muted leading-relaxed">
        <div className="font-semibold text-foreground/90 mb-1">Moneyness</div>
        <div className="flex justify-between gap-2 font-mono">
          <span>S / K = {(params.spot / params.strike).toFixed(3)}</span>
          <span>ln(S/K) = {(Math.log(params.spot / params.strike)).toFixed(3)}</span>
        </div>
        <p className="mt-1.5 text-[10px] text-muted/90">
          ATM call delta stays near 0.5 when S ≈ K; move <strong>spot</strong> or <strong>strike</strong> to see
          delta change. Vol and time mostly shift gamma/vega first.
        </p>
      </div>

      <div className="space-y-3">
        <SliderRow label="Spot Price (S)" value={params.spot} min={10} max={500} step={1}
          display={`$${params.spot.toFixed(0)}`} onChange={(v) => update("spot", v)} />
        <SliderRow label="Strike Price (K)" value={params.strike} min={10} max={500} step={1}
          display={`$${params.strike.toFixed(0)}`} onChange={(v) => update("strike", v)} />
        <SliderRow label="Time to Expiry (T)" value={params.expiry} min={0.01} max={5} step={0.01}
          display={`${params.expiry.toFixed(2)}y`} onChange={(v) => update("expiry", v)} />
        <SliderRow label="Risk-Free Rate (r)" value={params.rate} min={-0.05} max={0.20} step={0.005}
          display={`${(params.rate * 100).toFixed(1)}%`} onChange={(v) => update("rate", v)} />
        <SliderRow label="Volatility (σ)" value={params.volatility} min={0.01} max={1.5} step={0.01}
          display={`${(params.volatility * 100).toFixed(0)}%`} onChange={(v) => update("volatility", v)} />
        <SliderRow label="Dividend Yield (q)" value={params.dividend} min={0} max={0.15} step={0.005}
          display={`${(params.dividend * 100).toFixed(1)}%`} onChange={(v) => update("dividend", v)} />
      </div>

      <div className="pt-2 border-t border-border">
        <label className="block text-muted text-xs mb-2">Option Type</label>
        <div className="flex gap-2">
          {(["call", "put"] as const).map((t) => (
            <button
              key={t}
              type="button"
              onClick={() => update("option_type", t)}
              className={`flex-1 py-2 rounded text-xs font-semibold uppercase tracking-wider transition-all ${
                params.option_type === t
                  ? t === "call"
                    ? "bg-positive/20 text-positive border border-positive/30"
                    : "bg-negative/20 text-negative border border-negative/30"
                  : "bg-background border border-border text-muted hover:text-foreground"
              }`}
            >
              {t}
            </button>
          ))}
        </div>
      </div>

      <div className="pt-2 border-t border-border space-y-3">
        <h3 className="text-xs font-semibold uppercase tracking-wider text-muted">
          Grid Resolution
        </h3>
        <SliderRow label="Spatial Nodes" value={params.num_nodes} min={51} max={501} step={50}
          display={String(params.num_nodes)} onChange={(v) => update("num_nodes", v)} />
        <SliderRow label="Time Steps" value={params.num_time_steps} min={100} max={2000} step={100}
          display={String(params.num_time_steps)} onChange={(v) => update("num_time_steps", v)} />
      </div>

      <div className="pt-3 border-t border-border">
        <div className="text-[10px] text-muted space-y-1">
          <div className="flex justify-between">
            <span>Engine</span>
            <span className="text-foreground">C++ PDE (CN + Thomas)</span>
          </div>
          <div className="flex justify-between">
            <span>Greeks</span>
            <span className="text-foreground">AAD + Spatial FD</span>
          </div>
          <div className="flex justify-between">
            <span>Grid</span>
            <span className="text-foreground">{params.num_nodes} × {params.num_time_steps}</span>
          </div>
        </div>
      </div>
    </div>
  );
}

function SliderRow({
  label,
  value,
  min,
  max,
  step,
  display,
  onChange,
}: {
  label: string;
  value: number;
  min: number;
  max: number;
  step: number;
  display?: string;
  onChange: (v: number) => void;
}) {
  return (
    <div>
      <div className="flex items-center justify-between mb-1">
        <span className="text-muted text-xs">{label}</span>
        <span className="font-mono text-xs text-accent font-medium">
          {display ?? value}
        </span>
      </div>
      <input
        type="range"
        min={min}
        max={max}
        step={step}
        value={value}
        onChange={(e) => onChange(parseFloat(e.target.value))}
        className="w-full h-1 rounded-full appearance-none bg-border accent-accent cursor-pointer"
      />
    </div>
  );
}
