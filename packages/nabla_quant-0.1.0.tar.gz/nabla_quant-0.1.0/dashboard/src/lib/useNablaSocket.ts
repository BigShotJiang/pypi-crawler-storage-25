import { useCallback, useEffect, useRef, useState } from "react";
import { PricingParams, WSRequest, WSResponse } from "./types";

const WS_URL = process.env.NEXT_PUBLIC_WS_URL || "ws://localhost:8000/ws/pricing";
const RECONNECT_DELAY = 2000;
const MAX_RECONNECTS = 10;

export interface UseNablaSocket {
  /** WebSocket is OPEN */
  connected: boolean;
  /** In-flight WS replies (each send increments; each message decrements). */
  pendingReplies: number;
  lastComputeMs: number | null;
  /** Returns true if the frame was sent (socket open). */
  send: (req: WSRequest) => boolean;
  onMessage: (handler: (res: WSResponse) => void) => void;
  /** Called each time the socket reaches OPEN (including reconnects). */
  onSocketReady: (cb: () => void) => () => void;
}

export function useNablaSocket(): UseNablaSocket {
  const wsRef = useRef<WebSocket | null>(null);
  const handlerRef = useRef<((res: WSResponse) => void) | null>(null);
  const readyListenersRef = useRef(new Set<() => void>());
  const retriesRef = useRef(0);
  const [connected, setConnected] = useState(false);
  const [pendingReplies, setPendingReplies] = useState(0);
  const [lastComputeMs, setLastComputeMs] = useState<number | null>(null);

  const onSocketReady = useCallback((cb: () => void) => {
    readyListenersRef.current.add(cb);
    return () => {
      readyListenersRef.current.delete(cb);
    };
  }, []);

  const connect = useCallback(() => {
    if (wsRef.current?.readyState === WebSocket.OPEN) return;
    try {
      const ws = new WebSocket(WS_URL);
      ws.onopen = () => {
        setConnected(true);
        retriesRef.current = 0;
        readyListenersRef.current.forEach((fn) => {
          try {
            fn();
          } catch {
            /* ignore listener errors */
          }
        });
      };
      ws.onclose = () => {
        setConnected(false);
        setPendingReplies(0);
        wsRef.current = null;
        if (retriesRef.current < MAX_RECONNECTS) {
          retriesRef.current++;
          setTimeout(connect, RECONNECT_DELAY);
        }
      };
      ws.onerror = () => {
        ws.close();
      };
      ws.onmessage = (ev) => {
        const res: WSResponse = JSON.parse(ev.data);
        setLastComputeMs(res.compute_time_ms);
        setPendingReplies((p) => Math.max(0, p - 1));
        handlerRef.current?.(res);
      };
      wsRef.current = ws;
    } catch {
      setTimeout(connect, RECONNECT_DELAY);
    }
  }, []);

  useEffect(() => {
    connect();
    return () => {
      wsRef.current?.close();
    };
  }, [connect]);

  const send = useCallback((req: WSRequest): boolean => {
    if (wsRef.current?.readyState === WebSocket.OPEN) {
      setPendingReplies((p) => p + 1);
      wsRef.current.send(JSON.stringify(req));
      return true;
    }
    return false;
  }, []);

  const onMessage = useCallback((handler: (res: WSResponse) => void) => {
    handlerRef.current = handler;
  }, []);

  return {
    connected,
    pendingReplies,
    lastComputeMs,
    send,
    onMessage,
    onSocketReady,
  };
}

// Surface sweeps run 30×20 = 600 PDE calls. Cap grid resolution so that
// cranking the single-price slider to 501×2000 doesn't make the surface
// hang for 30+ seconds. Single-price requests still use the full slider value.
const SURFACE_MAX_NODES = 201;
const SURFACE_MAX_STEPS = 500;

function surfaceParams(params: PricingParams): PricingParams {
  return {
    ...params,
    num_nodes: Math.min(params.num_nodes, SURFACE_MAX_NODES),
    num_time_steps: Math.min(params.num_time_steps, SURFACE_MAX_STEPS),
  };
}

export function buildSurfaceRequest(params: PricingParams): WSRequest {
  return {
    type: "surface",
    params: surfaceParams(params),
    spot_range: [params.spot * 0.5, params.spot * 1.5],
    expiry_range: [0.05, Math.max(params.expiry, 0.1)],
    spot_steps: 30,
    expiry_steps: 20,
  };
}

export function buildGreeksSurfaceRequest(params: PricingParams): WSRequest {
  return {
    type: "greeks_surface",
    params: surfaceParams(params),
    spot_range: [params.spot * 0.5, params.spot * 1.5],
    expiry_range: [0.05, Math.max(params.expiry, 0.1)],
    spot_steps: 25,
    expiry_steps: 15,
  };
}

export function buildVolSurfaceRequest(params: PricingParams): WSRequest {
  return {
    type: "vol_surface",
    params: surfaceParams(params),
    spot_range: [params.spot * 0.5, params.spot * 1.5],
    expiry_range: [0.05, Math.max(params.expiry, 0.1)],
    spot_steps: 30,
    expiry_steps: 20,
  };
}

export function buildSingleRequest(params: PricingParams): WSRequest {
  return {
    type: "single_price",
    params,
  };
}
