export interface PricingParams {
  spot: number;
  strike: number;
  expiry: number;
  rate: number;
  volatility: number;
  option_type: "call" | "put";
  dividend: number;
  num_nodes: number;
  num_time_steps: number;
}

export interface GreeksResult {
  price: number;
  delta: number;
  gamma: number;
  theta: number;
  vega: number;
  rho: number;
}

export interface SurfaceData {
  spots: number[];
  expiries: number[];
  values: number[][];
}

export interface VolSurfaceData {
  spots: number[];
  expiries: number[];
  vols: number[][];
}

export interface GreeksSurfaceData {
  spots: number[];
  expiries: number[];
  delta: number[][];
  gamma: number[][];
  theta: number[][];
  vega: number[][];
  rho: number[][];
}

export type GreekName = "delta" | "gamma" | "theta" | "vega" | "rho";

export interface WSRequest {
  type:
    | "surface"
    | "greeks"
    | "vol_surface"
    | "greeks_surface"
    | "single_price";
  params: PricingParams;
  spot_range?: [number, number];
  expiry_range?: [number, number];
  spot_steps?: number;
  expiry_steps?: number;
  /** Client increments per debounced batch; server echoes so stale responses are ignored */
  request_id?: number;
}

export interface WSResponse {
  type: string;
  data: unknown;
  compute_time_ms: number;
  request_id?: number;
}

export const DEFAULT_PARAMS: PricingParams = {
  spot: 100,
  strike: 100,
  expiry: 1.0,
  rate: 0.05,
  volatility: 0.2,
  option_type: "call",
  dividend: 0.0,
  num_nodes: 201,
  num_time_steps: 500,
};
