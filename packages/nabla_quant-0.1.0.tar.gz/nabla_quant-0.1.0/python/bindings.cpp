#include <pybind11/pybind11.h>
#include <pybind11/stl.h>
#include <pybind11/functional.h>
#include <pybind11/numpy.h>

#include <nabla/nabla.hpp>
#include <sstream>
#include <iomanip>

namespace py = pybind11;
using namespace nabla;

static py::array_t<double> vec_to_numpy(const std::vector<double>& v) {
    auto arr = py::array_t<double>(static_cast<py::ssize_t>(v.size()));
    std::memcpy(arr.mutable_data(), v.data(), v.size() * sizeof(double));
    return arr;
}

PYBIND11_MODULE(_nabla_core, m) {
    m.doc() = "NablaQuant: high-performance PDE option pricing engine (C++ core)";

    // ── Enums ───────────────────────────────────────────────────────────

    py::enum_<OptionType>(m, "OptionType")
        .value("Call", OptionType::Call)
        .value("Put",  OptionType::Put);

    py::enum_<ExerciseType>(m, "ExerciseType")
        .value("European", ExerciseType::European)
        .value("American", ExerciseType::American);

    py::enum_<BoundaryType>(m, "BoundaryType")
        .value("Dirichlet", BoundaryType::Dirichlet)
        .value("Neumann",   BoundaryType::Neumann);

    py::enum_<BarrierDirection>(m, "BarrierDirection")
        .value("Up",   BarrierDirection::Up)
        .value("Down", BarrierDirection::Down);

    py::enum_<BarrierKnock>(m, "BarrierKnock")
        .value("Out", BarrierKnock::Out)
        .value("In",  BarrierKnock::In);

    // ── MarketParams ────────────────────────────────────────────────────

    py::class_<MarketParams>(m, "MarketParams")
        .def(py::init([](double spot, double rate, double vol, double div) {
            return MarketParams{spot, rate, vol, div};
        }), py::arg("spot"), py::arg("rate"), py::arg("volatility"),
            py::arg("dividend") = 0.0)
        .def_readwrite("spot",       &MarketParams::spot)
        .def_readwrite("rate",       &MarketParams::rate)
        .def_readwrite("volatility", &MarketParams::volatility)
        .def_readwrite("dividend",   &MarketParams::dividend)
        .def("__repr__", [](const MarketParams& p) {
            std::ostringstream os;
            os << std::fixed << std::setprecision(4)
               << "MarketParams(spot=" << p.spot
               << ", rate=" << p.rate
               << ", vol=" << p.volatility
               << ", div=" << p.dividend << ")";
            return os.str();
        });

    // ── ContractParams ──────────────────────────────────────────────────

    py::class_<ContractParams>(m, "ContractParams")
        .def(py::init([](double strike, double expiry, OptionType type,
                         ExerciseType exercise) {
            return ContractParams{strike, expiry, type, exercise};
        }), py::arg("strike"), py::arg("expiry"), py::arg("type"),
            py::arg("exercise") = ExerciseType::European)
        .def_readwrite("strike",   &ContractParams::strike)
        .def_readwrite("expiry",   &ContractParams::expiry)
        .def_readwrite("type",     &ContractParams::type)
        .def_readwrite("exercise", &ContractParams::exercise)
        .def("__repr__", [](const ContractParams& c) {
            std::ostringstream os;
            os << std::fixed << std::setprecision(4)
               << "ContractParams(K=" << c.strike
               << ", T=" << c.expiry
               << ", " << to_string(c.type)
               << ", " << (c.exercise == ExerciseType::American ? "American" : "European")
               << ")";
            return os.str();
        });

    // ── SinhMesh ────────────────────────────────────────────────────────

    py::class_<SinhMesh>(m, "SinhMesh")
        .def(py::init<double, double, double, std::size_t, double>(),
             py::arg("strike"), py::arg("s_min"), py::arg("s_max"),
             py::arg("num_nodes"), py::arg("concentration"))
        .def_property_readonly("spot_nodes", [](const SinhMesh& m) {
            return vec_to_numpy(m.spot_nodes());
        })
        .def_property_readonly("xi_nodes", [](const SinhMesh& m) {
            return vec_to_numpy(m.xi_nodes());
        })
        .def_property_readonly("spacings", [](const SinhMesh& m) {
            return vec_to_numpy(m.ds());
        })
        .def_property_readonly("size",          &SinhMesh::size)
        .def_property_readonly("strike",        &SinhMesh::strike)
        .def_property_readonly("s_min",         &SinhMesh::s_min)
        .def_property_readonly("s_max",         &SinhMesh::s_max)
        .def_property_readonly("concentration", &SinhMesh::concentration)
        .def_property_readonly("min_spacing",   &SinhMesh::min_spacing)
        .def_property_readonly("max_spacing",   &SinhMesh::max_spacing)
        .def_property_readonly("spacing_ratio", &SinhMesh::spacing_ratio)
        .def_property_readonly("strike_index",  &SinhMesh::strike_index)
        .def("s_from_xi",  &SinhMesh::s_from_xi,  py::arg("xi"))
        .def("xi_from_s",  &SinhMesh::xi_from_s,  py::arg("s"))
        .def("jacobian",   &SinhMesh::jacobian,    py::arg("xi"))
        .def("__len__",    &SinhMesh::size)
        .def("__repr__", [](const SinhMesh& m) {
            std::ostringstream os;
            os << "SinhMesh(N=" << m.size()
               << ", S=[" << m.s_min() << ", " << m.s_max() << "]"
               << ", K=" << m.strike()
               << ", c=" << m.concentration() << ")";
            return os.str();
        });

    // ── BoundaryConditions ──────────────────────────────────────────────

    py::class_<BoundaryConditions>(m, "BoundaryConditions")
        .def(py::init<const ContractParams&, const MarketParams&, const SinhMesh&>(),
             py::arg("contract"), py::arg("market"), py::arg("mesh"),
             py::keep_alive<1, 4>())  // BoundaryConditions → keeps mesh alive
        .def("payoff", &BoundaryConditions::payoff, py::arg("spot"))
        .def("terminal_condition", [](const BoundaryConditions& bc) {
            return vec_to_numpy(bc.terminal_condition());
        })
        .def("lower_boundary", &BoundaryConditions::lower_boundary, py::arg("tau"))
        .def("upper_boundary", &BoundaryConditions::upper_boundary, py::arg("tau"))
        .def_property_readonly("contract", &BoundaryConditions::contract)
        .def_property_readonly("market",   &BoundaryConditions::market);

    // ── LocalVolSurface ─────────────────────────────────────────────────

    py::class_<LocalVolSurface>(m, "LocalVolSurface")
        .def(py::init([](std::function<double(double, double)> func) {
            return LocalVolSurface(std::move(func));
        }), py::arg("func"),
            "Create from an arbitrary Python callable sigma(S, t)")
        .def_static("flat", &LocalVolSurface::flat, py::arg("sigma"))
        .def_static("cev",  &LocalVolSurface::cev,
             py::arg("sigma_ref"), py::arg("s_ref"), py::arg("beta"))
        .def_static("skew", &LocalVolSurface::skew,
             py::arg("sigma_atm"), py::arg("strike"),
             py::arg("skew_coeff"), py::arg("term_slope") = 0.0)
        .def("__call__", &LocalVolSurface::operator(),
             py::arg("S"), py::arg("t"))
        .def_property_readonly("is_constant",  &LocalVolSurface::is_constant)
        .def_property_readonly("constant_vol", &LocalVolSurface::constant_vol)
        .def("__repr__", [](const LocalVolSurface& v) {
            if (v.is_constant()) {
                std::ostringstream os;
                os << "LocalVolSurface(flat, σ=" << v.constant_vol() << ")";
                return os.str();
            }
            return std::string("LocalVolSurface(dynamic)");
        });

    // ── PricingResult ───────────────────────────────────────────────────

    py::class_<PricingResult>(m, "PricingResult")
        .def_readonly("price",         &PricingResult::price)
        .def_property_readonly("grid", [](const PricingResult& r) {
            return vec_to_numpy(r.grid);
        })
        .def_readonly("time_steps",    &PricingResult::time_steps)
        .def_readonly("spatial_nodes", &PricingResult::spatial_nodes)
        .def("__repr__", [](const PricingResult& r) {
            std::ostringstream os;
            os << std::fixed << std::setprecision(6)
               << "PricingResult(price=" << r.price
               << ", nodes=" << r.spatial_nodes
               << ", steps=" << r.time_steps << ")";
            return os.str();
        });

    // ── CrankNicolsonSolver ─────────────────────────────────────────────

    py::class_<CrankNicolsonSolver>(m, "CrankNicolsonSolver")
        .def(py::init<const SinhMesh&, const BoundaryConditions&,
                       std::size_t, double>(),
             py::arg("mesh"), py::arg("bc"),
             py::arg("num_time_steps"), py::arg("theta") = 0.5,
             py::keep_alive<1, 2>(), py::keep_alive<1, 3>())
        .def(py::init<const SinhMesh&, const BoundaryConditions&,
                       std::size_t, const LocalVolSurface&, double>(),
             py::arg("mesh"), py::arg("bc"),
             py::arg("num_time_steps"), py::arg("vol_surface"),
             py::arg("theta") = 0.5,
             py::keep_alive<1, 2>(), py::keep_alive<1, 3>(),
             py::keep_alive<1, 5>())
        .def("solve", &CrankNicolsonSolver::solve)
        .def_static("interpolate", &CrankNicolsonSolver::interpolate,
             py::arg("mesh"), py::arg("grid"), py::arg("spot"))
        .def_property_readonly("arena_capacity",
             &CrankNicolsonSolver::arena_capacity);

    // ── GreeksResult ────────────────────────────────────────────────────

    py::class_<GreeksResult>(m, "GreeksResult")
        .def_readonly("price", &GreeksResult::price)
        .def_readonly("delta", &GreeksResult::delta)
        .def_readonly("gamma", &GreeksResult::gamma)
        .def_readonly("theta", &GreeksResult::theta)
        .def_readonly("vega",  &GreeksResult::vega)
        .def_readonly("rho",   &GreeksResult::rho)
        .def_property_readonly("delta_surface", [](const GreeksResult& g) {
            return vec_to_numpy(g.delta_surface);
        })
        .def_property_readonly("gamma_surface", [](const GreeksResult& g) {
            return vec_to_numpy(g.gamma_surface);
        })
        .def("__repr__", [](const GreeksResult& g) {
            std::ostringstream os;
            os << std::fixed << std::setprecision(6)
               << "GreeksResult(price=" << g.price
               << ", delta=" << g.delta
               << ", gamma=" << g.gamma
               << ", theta=" << g.theta
               << ", vega=" << g.vega
               << ", rho=" << g.rho << ")";
            return os.str();
        });

    // ── BumpGreeks ──────────────────────────────────────────────────────

    py::class_<BumpGreeks>(m, "BumpGreeks")
        .def_readonly("delta", &BumpGreeks::delta)
        .def_readonly("gamma", &BumpGreeks::gamma)
        .def_readonly("vega",  &BumpGreeks::vega)
        .def_readonly("rho",   &BumpGreeks::rho)
        .def_readonly("theta", &BumpGreeks::theta)
        .def("__repr__", [](const BumpGreeks& g) {
            std::ostringstream os;
            os << std::fixed << std::setprecision(6)
               << "BumpGreeks(delta=" << g.delta
               << ", gamma=" << g.gamma
               << ", vega=" << g.vega
               << ", rho=" << g.rho
               << ", theta=" << g.theta << ")";
            return os.str();
        });

    // ── GreeksCalculator ────────────────────────────────────────────────

    py::class_<GreeksCalculator>(m, "GreeksCalculator")
        .def(py::init<const SinhMesh&, const BoundaryConditions&,
                       std::size_t, double>(),
             py::arg("mesh"), py::arg("bc"),
             py::arg("num_time_steps"), py::arg("theta") = 0.5,
             py::keep_alive<1, 2>(), py::keep_alive<1, 3>())
        .def("compute", &GreeksCalculator::compute)
        .def_static("compute_delta_surface", [](const SinhMesh& mesh,
                     py::array_t<double> grid) {
            auto buf = grid.request();
            std::vector<double> g(static_cast<double*>(buf.ptr),
                                  static_cast<double*>(buf.ptr) + buf.size);
            std::vector<double> delta(g.size());
            GreeksCalculator::compute_delta_surface(mesh, g, delta);
            return vec_to_numpy(delta);
        }, py::arg("mesh"), py::arg("grid"))
        .def_static("compute_gamma_surface", [](const SinhMesh& mesh,
                     py::array_t<double> grid) {
            auto buf = grid.request();
            std::vector<double> g(static_cast<double*>(buf.ptr),
                                  static_cast<double*>(buf.ptr) + buf.size);
            std::vector<double> gamma(g.size());
            GreeksCalculator::compute_gamma_surface(mesh, g, gamma);
            return vec_to_numpy(gamma);
        }, py::arg("mesh"), py::arg("grid"))
        .def_static("interpolate_greek", &GreeksCalculator::interpolate_greek,
             py::arg("mesh"), py::arg("surface"), py::arg("spot"))
        .def_static("theta_from_pde", &GreeksCalculator::theta_from_pde,
             py::arg("V"), py::arg("delta"), py::arg("gamma"),
             py::arg("S"), py::arg("sigma"), py::arg("r"), py::arg("q"))
        .def_static("bump_and_revalue", &GreeksCalculator::bump_and_revalue,
             py::arg("mesh"), py::arg("contract"), py::arg("market"),
             py::arg("num_time_steps"), py::arg("theta") = 0.5,
             py::arg("ds_bump") = 0.50, py::arg("dsigma_bump") = 0.001,
             py::arg("dr_bump") = 0.0001,
             py::arg("dt_bump") = 1.0 / 365.0);

    // ── BarrierParams ───────────────────────────────────────────────────

    py::class_<BarrierParams>(m, "BarrierParams")
        .def(py::init([](double level, BarrierDirection dir,
                         BarrierKnock knock, double rebate) {
            return BarrierParams{level, dir, knock, rebate};
        }), py::arg("level"), py::arg("direction"), py::arg("knock"),
            py::arg("rebate") = 0.0)
        .def_readwrite("level",     &BarrierParams::level)
        .def_readwrite("direction", &BarrierParams::direction)
        .def_readwrite("knock",     &BarrierParams::knock)
        .def_readwrite("rebate",    &BarrierParams::rebate)
        .def("__repr__", [](const BarrierParams& b) {
            std::ostringstream os;
            os << "BarrierParams(B=" << b.level
               << ", " << (b.direction == BarrierDirection::Down ? "Down" : "Up")
               << "-" << (b.knock == BarrierKnock::Out ? "Out" : "In")
               << ", rebate=" << b.rebate << ")";
            return os.str();
        });

    // ── BarrierPricingResult ────────────────────────────────────────────

    py::class_<BarrierPricingResult>(m, "BarrierPricingResult")
        .def_readonly("price",         &BarrierPricingResult::price)
        .def_property_readonly("grid", [](const BarrierPricingResult& r) {
            return vec_to_numpy(r.grid);
        })
        .def_readonly("time_steps",    &BarrierPricingResult::time_steps)
        .def_readonly("spatial_nodes", &BarrierPricingResult::spatial_nodes)
        .def("__repr__", [](const BarrierPricingResult& r) {
            std::ostringstream os;
            os << std::fixed << std::setprecision(6)
               << "BarrierPricingResult(price=" << r.price
               << ", nodes=" << r.spatial_nodes
               << ", steps=" << r.time_steps << ")";
            return os.str();
        });

    // ── BarrierPricer ───────────────────────────────────────────────────

    py::class_<BarrierPricer>(m, "BarrierPricer")
        .def(py::init<const SinhMesh&, const BoundaryConditions&,
                       const BarrierParams&, std::size_t, double>(),
             py::arg("mesh"), py::arg("bc"), py::arg("barrier"),
             py::arg("num_time_steps"), py::arg("theta") = 0.5,
             py::keep_alive<1, 2>(), py::keep_alive<1, 3>())
        .def(py::init<const SinhMesh&, const BoundaryConditions&,
                       const BarrierParams&, std::size_t,
                       const LocalVolSurface&, double>(),
             py::arg("mesh"), py::arg("bc"), py::arg("barrier"),
             py::arg("num_time_steps"), py::arg("vol_surface"),
             py::arg("theta") = 0.5,
             py::keep_alive<1, 2>(), py::keep_alive<1, 3>(),
             py::keep_alive<1, 6>())
        .def("solve", &BarrierPricer::solve)
        .def_static("analytical_down_out_call",
             &BarrierPricer::analytical_down_out_call,
             py::arg("S"), py::arg("K"), py::arg("B"), py::arg("T"),
             py::arg("r"), py::arg("sigma"), py::arg("q") = 0.0)
        .def_static("analytical_up_out_call",
             &BarrierPricer::analytical_up_out_call,
             py::arg("S"), py::arg("K"), py::arg("B"), py::arg("T"),
             py::arg("r"), py::arg("sigma"), py::arg("q") = 0.0)
        .def_static("analytical_down_out_put",
             &BarrierPricer::analytical_down_out_put,
             py::arg("S"), py::arg("K"), py::arg("B"), py::arg("T"),
             py::arg("r"), py::arg("sigma"), py::arg("q") = 0.0)
        .def_static("analytical_up_out_put",
             &BarrierPricer::analytical_up_out_put,
             py::arg("S"), py::arg("K"), py::arg("B"), py::arg("T"),
             py::arg("r"), py::arg("sigma"), py::arg("q") = 0.0);

    // ── Version ─────────────────────────────────────────────────────────

    m.attr("__version__") = "0.1.0";
}
