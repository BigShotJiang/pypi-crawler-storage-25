"""
NablaQuant - Full Pipeline Stress Test
=======================================
16 option contracts: standard, high-value, market-calibrated, barrier, and invalid.
Computes PDE price, BS analytical reference, absolute/relative error,
PDE/Market ratio (where live data available), all Greeks, and compute time.

Run from repo root:
    python -m python.tests.stress_pipeline   (or)
    PYTHONPATH=python python python/tests/stress_pipeline.py
"""

from __future__ import annotations

import math
import time
from dataclasses import dataclass
from typing import Optional

import nabla_quant as nq

# ── Black-Scholes reference ──────────────────────────────────────────────────

def _N(x: float) -> float:
    return 0.5 * math.erfc(-x / math.sqrt(2.0))

def _n(x: float) -> float:
    return math.exp(-0.5 * x * x) / math.sqrt(2.0 * math.pi)

def bs_price(S, K, T, r, sigma, q=0.0, opt="call") -> float:
    if T < 1e-9:
        return max((S - K) if opt == "call" else (K - S), 0.0)
    d1 = (math.log(S / K) + (r - q + 0.5 * sigma**2) * T) / (sigma * math.sqrt(T))
    d2 = d1 - sigma * math.sqrt(T)
    if opt == "call":
        return S * math.exp(-q * T) * _N(d1) - K * math.exp(-r * T) * _N(d2)
    return K * math.exp(-r * T) * _N(-d2) - S * math.exp(-q * T) * _N(-d1)

def bs_greeks(S, K, T, r, sigma, q=0.0, opt="call") -> dict:
    if T < 1e-9:
        return {"delta": 0, "gamma": 0, "vega": 0, "rho": 0, "theta": 0}
    d1 = (math.log(S / K) + (r - q + 0.5 * sigma**2) * T) / (sigma * math.sqrt(T))
    d2 = d1 - sigma * math.sqrt(T)
    eqT, erT = math.exp(-q * T), math.exp(-r * T)
    vega = S * eqT * _n(d1) * math.sqrt(T)
    gamma = eqT * _n(d1) / (S * sigma * math.sqrt(T))
    if opt == "call":
        delta = eqT * _N(d1)
        rho = K * T * erT * _N(d2)
        theta = (-(S * sigma * eqT * _n(d1)) / (2 * math.sqrt(T))
                 + q * S * eqT * _N(d1) - r * K * erT * _N(d2))
    else:
        delta = -eqT * _N(-d1)
        rho = -K * T * erT * _N(-d2)
        theta = (-(S * sigma * eqT * _n(d1)) / (2 * math.sqrt(T))
                 - q * S * eqT * _N(-d1) + r * K * erT * _N(-d2))
    return {"delta": delta, "gamma": gamma, "vega": vega, "rho": rho, "theta": theta}

# ── Result dataclass ─────────────────────────────────────────────────────────

@dataclass
class Result:
    id: int
    label: str
    contract: str
    S: float
    K: float
    T: float
    r: float
    sigma: float
    q: float
    pde_price: Optional[float]
    bs_price: Optional[float]
    market_price: Optional[float]
    delta: Optional[float]
    gamma: Optional[float]
    vega: Optional[float]
    rho: Optional[float]
    compute_ms: float
    status: str
    notes: str = ""

results: list[Result] = []

def run(id_, label, contract, S, K, T, r, sigma, q, fn, market_price=None,
        barrier_level=None, barrier_dir=None, barrier_knock=None,
        option_type="call", notes=""):
    bs = None
    try:
        bs = bs_price(S, K, T, r, sigma, q, option_type)
    except Exception:
        pass

    t0 = time.perf_counter()
    try:
        res_g = fn()
        elapsed = (time.perf_counter() - t0) * 1000
        pde = res_g.price if hasattr(res_g, "price") else None
        delta = getattr(res_g, "delta", None)
        gamma = getattr(res_g, "gamma", None)
        vega = getattr(res_g, "vega", None)
        rho = getattr(res_g, "rho", None)
        status = "PASS"
    except Exception as e:
        elapsed = (time.perf_counter() - t0) * 1000
        pde = None
        delta = gamma = vega = rho = None
        notes = str(e)[:60]
        status = "REJECTED"

    results.append(Result(
        id=id_, label=label, contract=contract,
        S=S, K=K, T=T, r=r, sigma=sigma, q=q,
        pde_price=pde, bs_price=bs,
        market_price=market_price,
        delta=delta, gamma=gamma, vega=vega, rho=rho,
        compute_ms=elapsed, status=status, notes=notes,
    ))

# ─────────────────────────────────────────────────────────────────────────────
# LIVE MARKET DATA  (optional - graceful skip if offline)
# ─────────────────────────────────────────────────────────────────────────────

live = {}
try:
    from nabla_quant.api.market_data import (
        fetch_quote_sync, fetch_chain_sync, list_expiries_sync
    )
    print("[market] Fetching live data…", flush=True)
    for sym in ["SPY", "AAPL", "MSFT"]:
        try:
            q_ = fetch_quote_sync(sym)
            exps = list_expiries_sync(sym)
            # Pick the 2nd expiry (gives a few weeks of TTE)
            exp_idx = min(2, len(exps["expirations"]) - 1)
            exp = exps["expirations"][exp_idx]
            chain = fetch_chain_sync(sym, exp)
            atm = min(chain["calls"], key=lambda c: abs(c["strike"] - chain["spot"]))
            live[sym] = {
                "spot": chain["spot"],
                "strike": atm["strike"],
                "tte": chain["time_to_expiry_years"],
                "iv": atm["implied_volatility"] or 0.20,
                "last": atm["last_price"],
                "bid": atm.get("bid"),
                "ask": atm.get("ask"),
                "rate": chain["risk_free_rate"],
                "div": chain["dividend_yield"],
            }
            print(f"  {sym}: S={chain['spot']:.2f}  K={atm['strike']:.0f}  "
                  f"T={chain['time_to_expiry_years']:.4f}y  "
                  f"IV={((atm['implied_volatility'] or 0)*100):.1f}%  "
                  f"r={chain['risk_free_rate']*100:.2f}%  "
                  f"q={chain['dividend_yield']*100:.2f}%")
        except Exception as ex:
            print(f"  {sym}: {ex}")
except Exception as ex:
    print(f"[market] Skipped live data: {ex}")

def mkt_mid(sym):
    d = live.get(sym, {})
    bid, ask, last = d.get("bid"), d.get("ask"), d.get("last")
    if bid and ask and bid > 0 and ask > 0:
        return (bid + ask) / 2
    return last

# ─────────────────────────────────────────────────────────────────────────────
# TEST CASES
# ─────────────────────────────────────────────────────────────────────────────

KW = dict(num_nodes=801, num_time_steps=2000)

print("\n[stress] Running 16 cases…\n")

# ── 1. Standard ATM European call ────────────────────────────────────────────
run(1, "ATM EUR call", "European", 100, 100, 1.0, 0.05, 0.20, 0.0,
    lambda: nq.greeks(spot=100, strike=100, expiry=1.0, rate=0.05, vol=0.20, **KW))

# ── 2. OTM European put ──────────────────────────────────────────────────────
run(2, "OTM EUR put", "European", 100, 110, 0.5, 0.05, 0.20, 0.0,
    lambda: nq.greeks(spot=100, strike=110, expiry=0.5, rate=0.05, vol=0.20,
                      option_type="put", **KW),
    option_type="put")

# ── 3. ITM European call ─────────────────────────────────────────────────────
run(3, "ITM EUR call", "European", 110, 100, 1.0, 0.05, 0.20, 0.0,
    lambda: nq.greeks(spot=110, strike=100, expiry=1.0, rate=0.05, vol=0.20, **KW))

# ── 4. Short-dated ATM call (1-week) ────────────────────────────────────────
run(4, "1-week ATM call", "European", 100, 100, 0.02, 0.05, 0.25, 0.0,
    lambda: nq.greeks(spot=100, strike=100, expiry=0.02, rate=0.05, vol=0.25, **KW))

# ── 5. Long-dated high-div call (2-year, q=4%) ──────────────────────────────
run(5, "2y div call (q=4%)", "European", 100, 100, 2.0, 0.05, 0.20, 0.04,
    lambda: nq.greeks(spot=100, strike=100, expiry=2.0, rate=0.05, vol=0.20,
                      dividend=0.04, **KW))

# ── 6. American put - deep ITM (early exercise) ──────────────────────────────
run(6, "Deep ITM AM put", "American", 80, 100, 1.0, 0.05, 0.25, 0.0,
    lambda: nq.american(spot=80, strike=100, expiry=1.0, rate=0.05, vol=0.25,
                        option_type="put", **KW),
    option_type="put", notes="Am premium ≥ EU")

# ── 7. SPX-scale ATM call (institutional) ───────────────────────────────────
run(7, "SPX-scale ATM call", "European", 5300, 5300, 0.25, 0.045, 0.16, 0.014,
    lambda: nq.greeks(spot=5300, strike=5300, expiry=0.25, rate=0.045, vol=0.16,
                      dividend=0.014, **KW))

# ── 8. Live SPY ATM call ─────────────────────────────────────────────────────
if "SPY" in live:
    d = live["SPY"]
    run(8, "SPY live ATM call", "European (live)",
        d["spot"], d["strike"], d["tte"], d["rate"], d["iv"], d["div"],
        lambda: nq.greeks(spot=d["spot"], strike=d["strike"], expiry=d["tte"],
                          rate=d["rate"], vol=d["iv"], dividend=d["div"], **KW),
        market_price=mkt_mid("SPY"))
else:
    run(8, "SPY live ATM call", "European (live)",
        679, 679, 0.011, 0.036, 0.139, 0.008,
        lambda: nq.greeks(spot=679, strike=679, expiry=0.011,
                          rate=0.036, vol=0.139, dividend=0.008, **KW),
        notes="offline fallback")

# ── 9. Live AAPL ATM call ────────────────────────────────────────────────────
if "AAPL" in live:
    d = live["AAPL"]
    run(9, "AAPL live ATM call", "European (live)",
        d["spot"], d["strike"], d["tte"], d["rate"], d["iv"], d["div"],
        lambda: nq.greeks(spot=d["spot"], strike=d["strike"], expiry=d["tte"],
                          rate=d["rate"], vol=d["iv"], dividend=d["div"], **KW),
        market_price=mkt_mid("AAPL"))
else:
    run(9, "AAPL live ATM call", "European (live)",
        260, 260, 0.011, 0.036, 0.25, 0.004,
        lambda: nq.greeks(spot=260, strike=260, expiry=0.011,
                          rate=0.036, vol=0.25, dividend=0.004, **KW),
        notes="offline fallback")

# ── 10. Live MSFT ATM call ───────────────────────────────────────────────────
if "MSFT" in live:
    d = live["MSFT"]
    run(10, "MSFT live ATM call", "European (live)",
        d["spot"], d["strike"], d["tte"], d["rate"], d["iv"], d["div"],
        lambda: nq.greeks(spot=d["spot"], strike=d["strike"], expiry=d["tte"],
                          rate=d["rate"], vol=d["iv"], dividend=d["div"], **KW),
        market_price=mkt_mid("MSFT"))
else:
    run(10, "MSFT live ATM call", "European (live)",
        371, 371, 0.011, 0.036, 0.20, 0.009,
        lambda: nq.greeks(spot=371, strike=371, expiry=0.011,
                          rate=0.036, vol=0.20, dividend=0.009, **KW),
        notes="offline fallback")

# ── 11. Barrier: Down-and-Out Call ───────────────────────────────────────────
run(11, "DOC barrier call", "Barrier (DOC)", 100, 100, 1.0, 0.05, 0.20, 0.0,
    lambda: nq.barrier(spot=100, strike=100, expiry=1.0, rate=0.05, vol=0.20,
                       level=80, direction="down", knock="out",
                       num_nodes=801, num_time_steps=2000),
    notes="B=80")

# ── 12. Barrier: Up-and-Out Call ─────────────────────────────────────────────
run(12, "UOC barrier call", "Barrier (UOC)", 100, 100, 1.0, 0.05, 0.20, 0.0,
    lambda: nq.barrier(spot=100, strike=100, expiry=1.0, rate=0.05, vol=0.20,
                       level=130, direction="up", knock="out",
                       num_nodes=801, num_time_steps=2000),
    notes="B=130")

# ── 13. Local vol CEV (β=0.5) - leverage effect ──────────────────────────────
run(13, "CEV local vol (β=0.5)", "LV European", 100, 100, 1.0, 0.05, 0.20, 0.0,
    lambda: nq.european(spot=100, strike=100, expiry=1.0, rate=0.05, vol=0.20,
                        vol_model="cev", vol_params={"beta": 0.5},
                        num_nodes=801, num_time_steps=2000))

# ── 14. High-vol crisis scenario (σ = 80%) ────────────────────────────────────
run(14, "Crisis vol (σ=80%)", "European", 100, 100, 0.5, 0.02, 0.80, 0.0,
    lambda: nq.greeks(spot=100, strike=100, expiry=0.5, rate=0.02, vol=0.80, **KW))

# ── 15. Near-zero expiry (3 calendar days) ───────────────────────────────────
run(15, "3-day near-expiry", "European", 100, 101, 3/365, 0.05, 0.20, 0.0,
    lambda: nq.greeks(spot=100, strike=101, expiry=3/365, rate=0.05, vol=0.20,
                      num_nodes=801, num_time_steps=500))

# ── 16. Invalid: negative spot price ─────────────────────────────────────────
run(16, "INVALID: spot=-10", "Invalid", -10, 100, 1.0, 0.05, 0.20, 0.0,
    lambda: nq.european(spot=-10, strike=100, expiry=1.0, rate=0.05, vol=0.20),
    notes="SDK raises: spot must be positive")

# ─────────────────────────────────────────────────────────────────────────────
# PRINT RESULTS
# ─────────────────────────────────────────────────────────────────────────────

def fmt(v, prec=4, fallback="—"):
    if v is None or (isinstance(v, float) and not math.isfinite(v)):
        return fallback
    return f"{v:.{prec}f}"

def pct_err(pde, ref):
    if pde is None or ref is None or ref == 0:
        return None
    return abs(pde - ref) / abs(ref) * 100

def pde_mkt(pde, mkt):
    if pde is None or mkt is None or mkt <= 0:
        return None
    return pde / mkt

# Print summary
print("=" * 140)
print(f"{'#':>2}  {'Label':<24} {'Contract':<18} S        K        T(y)   r%    vol%  q%    "
      f"PDE$      BS$       Err%   Mkt$     P/M    Delta   Gamma   Vega    ms    Status")
print("=" * 140)

for r in results:
    ep = pct_err(r.pde_price, r.bs_price)
    pm = pde_mkt(r.pde_price, r.market_price)
    print(
        f"{r.id:>2}  {r.label:<24} {r.contract:<18} "
        f"{r.S:>7.1f}  {r.K:>7.1f}  {r.T:>6.4f} "
        f"{r.r*100:>5.2f} {r.sigma*100:>5.1f} {r.q*100:>5.2f}  "
        f"{fmt(r.pde_price,4):>9} {fmt(r.bs_price,4):>9} "
        f"{fmt(ep,2,'—'):>6} "
        f"{fmt(r.market_price,3,'—'):>8} "
        f"{fmt(pm,3,'—'):>6}  "
        f"{fmt(r.delta,4,'—'):>7} "
        f"{fmt(r.gamma,5,'—'):>7} "
        f"{fmt(r.vega,3,'—'):>7} "
        f"{r.compute_ms:>6.1f}  "
        f"{r.status}"
    )
    if r.notes:
        print(f"     ↳ {r.notes}")

print("=" * 140)

passes = sum(1 for r in results if r.status == "PASS")
rejects = sum(1 for r in results if r.status == "REJECTED")
total_ms = sum(r.compute_ms for r in results if r.status == "PASS")
avg_err = [pct_err(r.pde_price, r.bs_price) for r in results
           if r.status == "PASS" and r.pde_price and r.bs_price
           and r.contract.startswith("European")]
avg_err_clean = [e for e in avg_err if e is not None]

print(f"\nSummary: {passes}/16 PASSED  |  {rejects}/16 REJECTED (expected)  |"
      f"  Avg BS err: {sum(avg_err_clean)/len(avg_err_clean):.3f}%  |"
      f"  Total compute: {total_ms:.1f}ms")

live_results = [(r.label, r.pde_price, r.market_price, pde_mkt(r.pde_price, r.market_price))
                for r in results if r.market_price and r.status == "PASS"]
if live_results:
    print(f"\nLive PDE/Market ratios:")
    for label, pde, mkt, pm in live_results:
        print(f"  {label:<30}  PDE={pde:.4f}  Mkt≈{mkt:.4f}  ratio={pm:.4f}")

# ─────────────────────────────────────────────────────────────────────────────
# ADDITIONAL METRICS
# ─────────────────────────────────────────────────────────────────────────────

print("\n── In-out parity check (DOC + DIC = vanilla) ──")
try:
    vanilla = nq.european(spot=100, strike=100, expiry=1.0, rate=0.05, vol=0.20,
                          num_nodes=801, num_time_steps=2000)
    doc = nq.barrier(spot=100, strike=100, expiry=1.0, rate=0.05, vol=0.20,
                     level=80, direction="down", knock="out",
                     num_nodes=801, num_time_steps=2000)
    dic = nq.barrier(spot=100, strike=100, expiry=1.0, rate=0.05, vol=0.20,
                     level=80, direction="down", knock="in",
                     num_nodes=801, num_time_steps=2000)
    parity_err = abs(doc.price + dic.price - vanilla.price)
    print(f"  Vanilla={vanilla.price:.6f}  DOC={doc.price:.6f}  DIC={dic.price:.6f}")
    print(f"  DOC+DIC={doc.price+dic.price:.6f}  parity error={parity_err:.2e}  {'PASS' if parity_err < 0.01 else 'FAIL'}")
except Exception as e:
    print(f"  FAIL: {e}")

print("\n── American early-exercise premium ──")
try:
    am = nq.american(spot=80, strike=100, expiry=1.0, rate=0.05, vol=0.25,
                     option_type="put", num_nodes=801, num_time_steps=2000)
    eu = nq.european(spot=80, strike=100, expiry=1.0, rate=0.05, vol=0.25,
                     option_type="put", num_nodes=801, num_time_steps=2000)
    premium = am.price - eu.price
    print(f"  American put={am.price:.4f}  European put={eu.price:.4f}  "
          f"Early-exercise premium={premium:.4f}  "
          f"{'PASS' if premium > 0 and am.price >= 20.0 else 'FAIL'}")
except Exception as e:
    print(f"  FAIL: {e}")

print("\n── Put-call parity (SPX-scale) ──")
try:
    S, K, T, r, vol, q = 5300, 5300, 0.25, 0.045, 0.16, 0.014
    c = nq.european(spot=S, strike=K, expiry=T, rate=r, vol=vol, dividend=q,
                    option_type="call", num_nodes=801, num_time_steps=2000)
    p = nq.european(spot=S, strike=K, expiry=T, rate=r, vol=vol, dividend=q,
                    option_type="put", num_nodes=801, num_time_steps=2000)
    parity_lhs = c.price - p.price
    parity_rhs = S * math.exp(-q * T) - K * math.exp(-r * T)
    err = abs(parity_lhs - parity_rhs)
    print(f"  C={c.price:.4f}  P={p.price:.4f}  C-P={parity_lhs:.4f}  "
          f"Se^(-qT)-Ke^(-rT)={parity_rhs:.4f}  err={err:.4f}  "
          f"{'PASS' if err < 1.0 else 'FAIL'}")
except Exception as e:
    print(f"  FAIL: {e}")

print("\n── API layer input validation (Pydantic) ──")
try:
    import httpx, json as _json
    _base = "http://localhost:8000"
    _cases = [
        ("vol > 500%",   {"spot": 100, "strike": 100, "expiry": 1.0, "rate": 0.05, "volatility": 6.0}),
        ("spot < 0",     {"spot": -10, "strike": 100, "expiry": 1.0, "rate": 0.05, "volatility": 0.20}),
        ("strike = 0",   {"spot": 100, "strike": 0,   "expiry": 1.0, "rate": 0.05, "volatility": 0.20}),
        ("expiry = 0",   {"spot": 100, "strike": 100, "expiry": 0.0, "rate": 0.05, "volatility": 0.20}),
    ]
    for label, body in _cases:
        r = httpx.post(f"{_base}/api/v1/greeks", json=body, timeout=5)
        ok = r.status_code == 422
        print(f"  [{label}]  HTTP {r.status_code}  {'PASS (422 rejected)' if ok else 'FAIL (should be 422)'}")
except Exception as e:
    print(f"  API server not reachable ({type(e).__name__}) - API validation via Pydantic models confirmed in test_api.py")

print("\n── Done ──")
