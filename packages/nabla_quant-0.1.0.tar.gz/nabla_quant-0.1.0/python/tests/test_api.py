"""
Comprehensive test suite for the NablaQuant FastAPI pricing API.

Tests cover:
  - Health endpoint
  - European pricing (ATM, ITM, OTM, puts, put-call parity)
  - American pricing (early exercise premium)
  - Barrier pricing (all types, in-out parity, rebate)
  - Greeks endpoint (all sensitivities, sign conventions)
  - Local volatility pricing (flat, CEV, skew)
  - Batch pricing endpoint
  - Input validation (negative values, out-of-range, missing fields)
  - Stress testing (concurrent requests, extreme parameters)
  - Error handling (400 responses)
"""

import math
import asyncio
import pytest
from httpx import AsyncClient, ASGITransport

from nabla_quant.api.app import create_app

app = create_app()
transport = ASGITransport(app=app)


def _norm_cdf(x):
    return 0.5 * (1.0 + math.erf(x / math.sqrt(2.0)))


def bs_call(S, K, T, r, sigma):
    d1 = (math.log(S / K) + (r + 0.5 * sigma**2) * T) / (sigma * math.sqrt(T))
    d2 = d1 - sigma * math.sqrt(T)
    return S * _norm_cdf(d1) - K * math.exp(-r * T) * _norm_cdf(d2)


def bs_put(S, K, T, r, sigma):
    d1 = (math.log(S / K) + (r + 0.5 * sigma**2) * T) / (sigma * math.sqrt(T))
    d2 = d1 - sigma * math.sqrt(T)
    return K * math.exp(-r * T) * _norm_cdf(-d2) - S * _norm_cdf(-d1)


# ═══════════════════════════════════════════════════════════════════════
# SECTION 1: Health
# ═══════════════════════════════════════════════════════════════════════


@pytest.mark.asyncio
async def test_health():
    async with AsyncClient(transport=transport, base_url="http://test") as c:
        r = await c.get("/api/v1/health")
    assert r.status_code == 200
    data = r.json()
    assert data["status"] == "ok"
    assert "version" in data
    assert "engine" in data


# ═══════════════════════════════════════════════════════════════════════
# SECTION 2: European Pricing
# ═══════════════════════════════════════════════════════════════════════


@pytest.mark.asyncio
async def test_european_atm_call():
    payload = {
        "spot": 100, "strike": 100, "expiry": 1.0,
        "rate": 0.05, "volatility": 0.20, "option_type": "call",
        "num_nodes": 401, "num_time_steps": 400,
    }
    async with AsyncClient(transport=transport, base_url="http://test") as c:
        r = await c.post("/api/v1/price/european", json=payload)
    assert r.status_code == 200
    data = r.json()
    expected = bs_call(100, 100, 1.0, 0.05, 0.20)
    assert abs(data["price"] - expected) < 0.02
    assert data["time_steps"] == 400
    assert data["spatial_nodes"] == 401


@pytest.mark.asyncio
async def test_european_atm_put():
    payload = {
        "spot": 100, "strike": 100, "expiry": 1.0,
        "rate": 0.05, "volatility": 0.20, "option_type": "put",
        "num_nodes": 401, "num_time_steps": 400,
    }
    async with AsyncClient(transport=transport, base_url="http://test") as c:
        r = await c.post("/api/v1/price/european", json=payload)
    assert r.status_code == 200
    expected = bs_put(100, 100, 1.0, 0.05, 0.20)
    assert abs(r.json()["price"] - expected) < 0.02


@pytest.mark.asyncio
async def test_european_itm_call():
    payload = {
        "spot": 120, "strike": 100, "expiry": 1.0,
        "rate": 0.05, "volatility": 0.20, "option_type": "call",
        "num_nodes": 401, "num_time_steps": 400,
    }
    async with AsyncClient(transport=transport, base_url="http://test") as c:
        r = await c.post("/api/v1/price/european", json=payload)
    assert r.status_code == 200
    assert r.json()["price"] > 20.0  # must exceed intrinsic


@pytest.mark.asyncio
async def test_european_put_call_parity():
    S, K, T, r = 100, 100, 1.0, 0.05
    base = {"spot": S, "strike": K, "expiry": T, "rate": r, "volatility": 0.20,
            "num_nodes": 801, "num_time_steps": 800}

    async with AsyncClient(transport=transport, base_url="http://test") as c:
        rc = await c.post("/api/v1/price/european", json={**base, "option_type": "call"})
        rp = await c.post("/api/v1/price/european", json={**base, "option_type": "put"})

    call_price = rc.json()["price"]
    put_price = rp.json()["price"]
    parity_error = abs(call_price - put_price - (S - K * math.exp(-r * T)))
    assert parity_error < 0.01


@pytest.mark.asyncio
async def test_european_with_dividends():
    base = {"spot": 100, "strike": 100, "expiry": 1.0, "rate": 0.05,
            "volatility": 0.20, "option_type": "call",
            "num_nodes": 401, "num_time_steps": 400}

    async with AsyncClient(transport=transport, base_url="http://test") as c:
        r_no_div = await c.post("/api/v1/price/european", json={**base, "dividend": 0.0})
        r_div = await c.post("/api/v1/price/european", json={**base, "dividend": 0.03})

    assert r_div.json()["price"] < r_no_div.json()["price"]


# ═══════════════════════════════════════════════════════════════════════
# SECTION 3: American Pricing
# ═══════════════════════════════════════════════════════════════════════


@pytest.mark.asyncio
async def test_american_put_premium():
    """American put > European put."""
    base = {"spot": 100, "strike": 100, "expiry": 1.0, "rate": 0.05,
            "volatility": 0.20, "num_nodes": 401, "num_time_steps": 400}

    async with AsyncClient(transport=transport, base_url="http://test") as c:
        r_am = await c.post("/api/v1/price/american",
                            json={**base, "option_type": "put"})
        r_eu = await c.post("/api/v1/price/european",
                            json={**base, "option_type": "put"})

    assert r_am.json()["price"] >= r_eu.json()["price"] - 1e-4


@pytest.mark.asyncio
async def test_american_call_no_div_equals_european():
    base = {"spot": 100, "strike": 100, "expiry": 1.0, "rate": 0.05,
            "volatility": 0.20, "option_type": "call",
            "num_nodes": 401, "num_time_steps": 400}

    async with AsyncClient(transport=transport, base_url="http://test") as c:
        r_am = await c.post("/api/v1/price/american", json=base)
        r_eu = await c.post("/api/v1/price/european", json=base)

    assert abs(r_am.json()["price"] - r_eu.json()["price"]) < 0.02


# ═══════════════════════════════════════════════════════════════════════
# SECTION 4: Barrier Pricing
# ═══════════════════════════════════════════════════════════════════════


@pytest.mark.asyncio
async def test_barrier_doc():
    payload = {
        "spot": 100, "strike": 100, "expiry": 1.0,
        "rate": 0.05, "volatility": 0.20, "option_type": "call",
        "barrier_level": 80, "barrier_direction": "down", "barrier_knock": "out",
        "num_nodes": 801, "num_time_steps": 800,
    }
    async with AsyncClient(transport=transport, base_url="http://test") as c:
        r = await c.post("/api/v1/price/barrier", json=payload)
    assert r.status_code == 200
    data = r.json()
    assert data["price"] > 0
    # KO must be less than vanilla
    vanilla = bs_call(100, 100, 1.0, 0.05, 0.20)
    assert data["price"] <= vanilla + 0.01


@pytest.mark.asyncio
async def test_barrier_uoc():
    payload = {
        "spot": 100, "strike": 100, "expiry": 1.0,
        "rate": 0.05, "volatility": 0.20, "option_type": "call",
        "barrier_level": 140, "barrier_direction": "up", "barrier_knock": "out",
        "num_nodes": 801, "num_time_steps": 800,
    }
    async with AsyncClient(transport=transport, base_url="http://test") as c:
        r = await c.post("/api/v1/price/barrier", json=payload)
    assert r.status_code == 200
    assert r.json()["price"] > 0


@pytest.mark.asyncio
async def test_barrier_in_out_parity_api():
    """DOC + DIC = Vanilla via API."""
    base = {"spot": 100, "strike": 100, "expiry": 1.0,
            "rate": 0.05, "volatility": 0.20, "option_type": "call",
            "barrier_level": 80, "barrier_direction": "down",
            "num_nodes": 801, "num_time_steps": 800}

    async with AsyncClient(transport=transport, base_url="http://test") as c:
        r_ko = await c.post("/api/v1/price/barrier",
                            json={**base, "barrier_knock": "out"})
        r_ki = await c.post("/api/v1/price/barrier",
                            json={**base, "barrier_knock": "in"})
        r_van = await c.post("/api/v1/price/european",
                             json={"spot": 100, "strike": 100, "expiry": 1.0,
                                   "rate": 0.05, "volatility": 0.20,
                                   "option_type": "call",
                                   "num_nodes": 801, "num_time_steps": 800})

    ko = r_ko.json()["price"]
    ki = r_ki.json()["price"]
    van = r_van.json()["price"]
    assert abs((ko + ki) - van) < 0.01


@pytest.mark.asyncio
async def test_barrier_with_rebate():
    base = {"spot": 100, "strike": 100, "expiry": 1.0,
            "rate": 0.05, "volatility": 0.20, "option_type": "call",
            "barrier_level": 80, "barrier_direction": "down", "barrier_knock": "out",
            "num_nodes": 401, "num_time_steps": 400}

    async with AsyncClient(transport=transport, base_url="http://test") as c:
        r_no = await c.post("/api/v1/price/barrier", json={**base, "rebate": 0.0})
        r_yes = await c.post("/api/v1/price/barrier", json={**base, "rebate": 5.0})

    assert r_yes.json()["price"] >= r_no.json()["price"]


# ═══════════════════════════════════════════════════════════════════════
# SECTION 5: Greeks
# ═══════════════════════════════════════════════════════════════════════


@pytest.mark.asyncio
async def test_greeks_atm_call():
    payload = {
        "spot": 100, "strike": 100, "expiry": 1.0,
        "rate": 0.05, "volatility": 0.20, "option_type": "call",
        "num_nodes": 801, "num_time_steps": 800,
    }
    async with AsyncClient(transport=transport, base_url="http://test") as c:
        r = await c.post("/api/v1/greeks", json=payload)
    assert r.status_code == 200
    data = r.json()

    assert abs(data["price"] - bs_call(100, 100, 1.0, 0.05, 0.20)) < 0.02
    assert 0.5 < data["delta"] < 0.8
    assert data["gamma"] > 0
    assert data["theta"] < 0
    assert data["vega"] > 0
    assert data["rho"] > 0


@pytest.mark.asyncio
async def test_greeks_put_signs():
    payload = {
        "spot": 100, "strike": 100, "expiry": 1.0,
        "rate": 0.05, "volatility": 0.20, "option_type": "put",
        "num_nodes": 801, "num_time_steps": 800,
    }
    async with AsyncClient(transport=transport, base_url="http://test") as c:
        r = await c.post("/api/v1/greeks", json=payload)
    data = r.json()
    assert data["delta"] < 0
    assert data["gamma"] > 0
    assert data["vega"] > 0
    assert data["rho"] < 0


# ═══════════════════════════════════════════════════════════════════════
# SECTION 6: Local Volatility
# ═══════════════════════════════════════════════════════════════════════


@pytest.mark.asyncio
async def test_local_vol_flat():
    payload = {
        "spot": 100, "strike": 100, "expiry": 1.0,
        "rate": 0.05, "volatility": 0.20, "option_type": "call",
        "num_nodes": 401, "num_time_steps": 400,
        "vol_surface": {"model": "flat"},
    }
    async with AsyncClient(transport=transport, base_url="http://test") as c:
        r = await c.post("/api/v1/price/local_vol", json=payload)
    assert r.status_code == 200
    expected = bs_call(100, 100, 1.0, 0.05, 0.20)
    assert abs(r.json()["price"] - expected) < 0.02


@pytest.mark.asyncio
async def test_local_vol_cev():
    payload = {
        "spot": 100, "strike": 100, "expiry": 1.0,
        "rate": 0.05, "volatility": 0.20, "option_type": "call",
        "num_nodes": 401, "num_time_steps": 400,
        "vol_surface": {"model": "cev", "beta": 0.5},
    }
    async with AsyncClient(transport=transport, base_url="http://test") as c:
        r = await c.post("/api/v1/price/local_vol", json=payload)
    assert r.status_code == 200
    assert r.json()["price"] > 0


@pytest.mark.asyncio
async def test_local_vol_skew():
    payload = {
        "spot": 100, "strike": 100, "expiry": 1.0,
        "rate": 0.05, "volatility": 0.20, "option_type": "call",
        "num_nodes": 401, "num_time_steps": 400,
        "vol_surface": {"model": "skew", "skew_coeff": -0.05, "term_slope": 0.01},
    }
    async with AsyncClient(transport=transport, base_url="http://test") as c:
        r = await c.post("/api/v1/price/local_vol", json=payload)
    assert r.status_code == 200
    assert r.json()["price"] > 0


# ═══════════════════════════════════════════════════════════════════════
# SECTION 7: Batch Pricing
# ═══════════════════════════════════════════════════════════════════════


@pytest.mark.asyncio
async def test_batch_pricing():
    requests = [
        {"spot": 100, "strike": K, "expiry": 1.0, "rate": 0.05,
         "volatility": 0.20, "option_type": "call",
         "num_nodes": 201, "num_time_steps": 200}
        for K in [90, 95, 100, 105, 110]
    ]
    async with AsyncClient(transport=transport, base_url="http://test") as c:
        r = await c.post("/api/v1/price/batch", json={"requests": requests})
    assert r.status_code == 200
    data = r.json()
    assert data["total_count"] == 5
    assert len(data["results"]) == 5

    prices = [res["price"] for res in data["results"]]
    # Call prices should decrease with increasing strike
    for i in range(len(prices) - 1):
        assert prices[i] > prices[i + 1]


# ═══════════════════════════════════════════════════════════════════════
# SECTION 8: Input Validation
# ═══════════════════════════════════════════════════════════════════════


@pytest.mark.asyncio
async def test_validation_negative_spot():
    payload = {"spot": -100, "strike": 100, "expiry": 1.0,
               "rate": 0.05, "volatility": 0.20}
    async with AsyncClient(transport=transport, base_url="http://test") as c:
        r = await c.post("/api/v1/price/european", json=payload)
    assert r.status_code == 422


@pytest.mark.asyncio
async def test_validation_zero_expiry():
    payload = {"spot": 100, "strike": 100, "expiry": 0.0,
               "rate": 0.05, "volatility": 0.20}
    async with AsyncClient(transport=transport, base_url="http://test") as c:
        r = await c.post("/api/v1/price/european", json=payload)
    assert r.status_code == 422


@pytest.mark.asyncio
async def test_validation_negative_volatility():
    payload = {"spot": 100, "strike": 100, "expiry": 1.0,
               "rate": 0.05, "volatility": -0.20}
    async with AsyncClient(transport=transport, base_url="http://test") as c:
        r = await c.post("/api/v1/price/european", json=payload)
    assert r.status_code == 422


@pytest.mark.asyncio
async def test_validation_extreme_rate():
    payload = {"spot": 100, "strike": 100, "expiry": 1.0,
               "rate": 5.0, "volatility": 0.20}
    async with AsyncClient(transport=transport, base_url="http://test") as c:
        r = await c.post("/api/v1/price/european", json=payload)
    assert r.status_code == 422


@pytest.mark.asyncio
async def test_validation_extreme_volatility():
    payload = {"spot": 100, "strike": 100, "expiry": 1.0,
               "rate": 0.05, "volatility": 10.0}
    async with AsyncClient(transport=transport, base_url="http://test") as c:
        r = await c.post("/api/v1/price/european", json=payload)
    assert r.status_code == 422


@pytest.mark.asyncio
async def test_validation_missing_required_field():
    payload = {"spot": 100, "strike": 100, "rate": 0.05, "volatility": 0.20}
    async with AsyncClient(transport=transport, base_url="http://test") as c:
        r = await c.post("/api/v1/price/european", json=payload)
    assert r.status_code == 422


@pytest.mark.asyncio
async def test_validation_negative_barrier():
    payload = {
        "spot": 100, "strike": 100, "expiry": 1.0,
        "rate": 0.05, "volatility": 0.20,
        "barrier_level": -80, "barrier_direction": "down", "barrier_knock": "out",
    }
    async with AsyncClient(transport=transport, base_url="http://test") as c:
        r = await c.post("/api/v1/price/barrier", json=payload)
    assert r.status_code == 422


@pytest.mark.asyncio
async def test_validation_invalid_option_type():
    payload = {"spot": 100, "strike": 100, "expiry": 1.0,
               "rate": 0.05, "volatility": 0.20, "option_type": "straddle"}
    async with AsyncClient(transport=transport, base_url="http://test") as c:
        r = await c.post("/api/v1/price/european", json=payload)
    assert r.status_code == 422


@pytest.mark.asyncio
async def test_validation_num_nodes_too_small():
    payload = {"spot": 100, "strike": 100, "expiry": 1.0,
               "rate": 0.05, "volatility": 0.20, "num_nodes": 10}
    async with AsyncClient(transport=transport, base_url="http://test") as c:
        r = await c.post("/api/v1/price/european", json=payload)
    assert r.status_code == 422


@pytest.mark.asyncio
async def test_validation_num_nodes_too_large():
    payload = {"spot": 100, "strike": 100, "expiry": 1.0,
               "rate": 0.05, "volatility": 0.20, "num_nodes": 100000}
    async with AsyncClient(transport=transport, base_url="http://test") as c:
        r = await c.post("/api/v1/price/european", json=payload)
    assert r.status_code == 422


# ═══════════════════════════════════════════════════════════════════════
# SECTION 9: Concurrency Stress Test
# ═══════════════════════════════════════════════════════════════════════


@pytest.mark.asyncio
async def test_concurrent_requests():
    """Fire 20 concurrent pricing requests - all should succeed."""
    payloads = [
        {"spot": 80 + i * 2, "strike": 100, "expiry": 1.0,
         "rate": 0.05, "volatility": 0.20, "option_type": "call",
         "num_nodes": 201, "num_time_steps": 200}
        for i in range(20)
    ]

    async with AsyncClient(transport=transport, base_url="http://test") as c:
        tasks = [c.post("/api/v1/price/european", json=p) for p in payloads]
        responses = await asyncio.gather(*tasks)

    for r in responses:
        assert r.status_code == 200
        assert r.json()["price"] >= 0


@pytest.mark.asyncio
async def test_concurrent_mixed_endpoints():
    """Mix of European, Barrier, Greeks - all concurrent."""
    async with AsyncClient(transport=transport, base_url="http://test") as c:
        tasks = [
            c.post("/api/v1/price/european",
                   json={"spot": 100, "strike": 100, "expiry": 1.0,
                         "rate": 0.05, "volatility": 0.20,
                         "num_nodes": 201, "num_time_steps": 200}),
            c.post("/api/v1/price/barrier",
                   json={"spot": 100, "strike": 100, "expiry": 1.0,
                         "rate": 0.05, "volatility": 0.20,
                         "barrier_level": 80, "barrier_direction": "down",
                         "barrier_knock": "out",
                         "num_nodes": 201, "num_time_steps": 200}),
            c.post("/api/v1/greeks",
                   json={"spot": 100, "strike": 100, "expiry": 1.0,
                         "rate": 0.05, "volatility": 0.20,
                         "num_nodes": 201, "num_time_steps": 200}),
        ]
        responses = await asyncio.gather(*tasks)

    for r in responses:
        assert r.status_code == 200
