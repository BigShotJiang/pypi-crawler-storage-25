"""
Comprehensive test suite for the NablaQuant Python SDK.

Tests cover:
  - Core type bindings (enums, structs, constructors, repr)
  - SinhMesh properties and transforms
  - European option pricing vs Black-Scholes analytical
  - American option early-exercise premium
  - Greeks (AAD) vs Black-Scholes analytical
  - Bump-and-revalue cross-validation
  - Barrier options vs analytical formulas and in-out parity
  - Local volatility surface integration
  - Edge cases (deep ITM/OTM, short maturity, high vol)
  - Error handling and input validation
  - Numpy array returns (dtype, shape)
"""

import math
import pytest
import numpy as np

import nabla_quant as nq
from nabla_quant import (
    OptionType,
    ExerciseType,
    BarrierDirection,
    BarrierKnock,
    MarketParams,
    ContractParams,
    SinhMesh,
    BoundaryConditions,
    LocalVolSurface,
    CrankNicolsonSolver,
    GreeksCalculator,
    BarrierPricer,
    BarrierParams,
)


# ── Black-Scholes analytical reference ───────────────────────────────────

def _norm_cdf(x):
    return 0.5 * (1.0 + math.erf(x / math.sqrt(2.0)))


def bs_call(S, K, T, r, sigma, q=0.0):
    d1 = (math.log(S / K) + (r - q + 0.5 * sigma**2) * T) / (sigma * math.sqrt(T))
    d2 = d1 - sigma * math.sqrt(T)
    return S * math.exp(-q * T) * _norm_cdf(d1) - K * math.exp(-r * T) * _norm_cdf(d2)


def bs_put(S, K, T, r, sigma, q=0.0):
    d1 = (math.log(S / K) + (r - q + 0.5 * sigma**2) * T) / (sigma * math.sqrt(T))
    d2 = d1 - sigma * math.sqrt(T)
    return K * math.exp(-r * T) * _norm_cdf(-d2) - S * math.exp(-q * T) * _norm_cdf(-d1)


def bs_delta_call(S, K, T, r, sigma, q=0.0):
    d1 = (math.log(S / K) + (r - q + 0.5 * sigma**2) * T) / (sigma * math.sqrt(T))
    return math.exp(-q * T) * _norm_cdf(d1)


def bs_gamma(S, K, T, r, sigma, q=0.0):
    d1 = (math.log(S / K) + (r - q + 0.5 * sigma**2) * T) / (sigma * math.sqrt(T))
    return (math.exp(-q * T) * math.exp(-0.5 * d1**2) /
            (S * sigma * math.sqrt(2 * math.pi * T)))


def bs_vega(S, K, T, r, sigma, q=0.0):
    d1 = (math.log(S / K) + (r - q + 0.5 * sigma**2) * T) / (sigma * math.sqrt(T))
    return S * math.exp(-q * T) * math.sqrt(T) * math.exp(-0.5 * d1**2) / math.sqrt(2 * math.pi)


# ═══════════════════════════════════════════════════════════════════════
# SECTION 1: Core Type Bindings
# ═══════════════════════════════════════════════════════════════════════


class TestEnums:
    def test_option_type_values(self):
        assert OptionType.Call != OptionType.Put

    def test_exercise_type_values(self):
        assert ExerciseType.European != ExerciseType.American

    def test_barrier_direction_values(self):
        assert BarrierDirection.Up != BarrierDirection.Down

    def test_barrier_knock_values(self):
        assert BarrierKnock.Out != BarrierKnock.In


class TestMarketParams:
    def test_constructor_all_args(self):
        m = MarketParams(spot=100, rate=0.05, volatility=0.20, dividend=0.02)
        assert m.spot == 100.0
        assert m.rate == 0.05
        assert m.volatility == 0.20
        assert m.dividend == 0.02

    def test_constructor_default_dividend(self):
        m = MarketParams(spot=100, rate=0.05, volatility=0.20)
        assert m.dividend == 0.0

    def test_readwrite_fields(self):
        m = MarketParams(spot=100, rate=0.05, volatility=0.20)
        m.spot = 110.0
        m.rate = 0.03
        assert m.spot == 110.0
        assert m.rate == 0.03

    def test_repr(self):
        m = MarketParams(spot=100, rate=0.05, volatility=0.20)
        r = repr(m)
        assert "MarketParams" in r
        assert "100" in r


class TestContractParams:
    def test_constructor(self):
        c = ContractParams(strike=100, expiry=1.0, type=OptionType.Call)
        assert c.strike == 100.0
        assert c.expiry == 1.0
        assert c.type == OptionType.Call
        assert c.exercise == ExerciseType.European

    def test_american_exercise(self):
        c = ContractParams(strike=100, expiry=1.0, type=OptionType.Put,
                           exercise=ExerciseType.American)
        assert c.exercise == ExerciseType.American

    def test_repr(self):
        c = ContractParams(strike=100, expiry=1.0, type=OptionType.Call)
        assert "ContractParams" in repr(c)


# ═══════════════════════════════════════════════════════════════════════
# SECTION 2: SinhMesh
# ═══════════════════════════════════════════════════════════════════════


class TestSinhMesh:
    def test_construction(self):
        mesh = SinhMesh(strike=100, s_min=0, s_max=400, num_nodes=201,
                        concentration=12.5)
        assert mesh.size == 201
        assert len(mesh) == 201
        assert mesh.strike == 100.0
        assert mesh.s_min == 0.0
        assert mesh.s_max == 400.0
        assert mesh.concentration == 12.5

    def test_spot_nodes_numpy(self):
        mesh = SinhMesh(strike=100, s_min=0, s_max=400, num_nodes=201,
                        concentration=12.5)
        nodes = mesh.spot_nodes
        assert isinstance(nodes, np.ndarray)
        assert nodes.dtype == np.float64
        assert len(nodes) == 201
        assert nodes[0] >= 0.0
        assert nodes[-1] <= 400.0

    def test_monotonicity(self):
        mesh = SinhMesh(strike=100, s_min=0, s_max=400, num_nodes=201,
                        concentration=12.5)
        nodes = mesh.spot_nodes
        assert np.all(np.diff(nodes) > 0), "Spot nodes must be strictly increasing"

    def test_clustering_near_strike(self):
        mesh = SinhMesh(strike=100, s_min=0, s_max=400, num_nodes=201,
                        concentration=12.5)
        assert mesh.min_spacing < mesh.max_spacing
        assert mesh.spacing_ratio > 1.0

    def test_transform_invertibility(self):
        mesh = SinhMesh(strike=100, s_min=0, s_max=400, num_nodes=201,
                        concentration=12.5)
        s_test = 150.0
        xi = mesh.xi_from_s(s_test)
        s_back = mesh.s_from_xi(xi)
        assert abs(s_back - s_test) < 1e-10

    def test_repr(self):
        mesh = SinhMesh(strike=100, s_min=0, s_max=400, num_nodes=201,
                        concentration=12.5)
        assert "SinhMesh" in repr(mesh)


# ═══════════════════════════════════════════════════════════════════════
# SECTION 3: BoundaryConditions
# ═══════════════════════════════════════════════════════════════════════


class TestBoundaryConditions:
    def test_call_payoff(self):
        mesh = SinhMesh(strike=100, s_min=0, s_max=400, num_nodes=201,
                        concentration=12.5)
        mkt = MarketParams(spot=100, rate=0.05, volatility=0.20)
        con = ContractParams(strike=100, expiry=1.0, type=OptionType.Call)
        bc = BoundaryConditions(con, mkt, mesh)
        assert bc.payoff(120.0) == pytest.approx(20.0)
        assert bc.payoff(80.0) == pytest.approx(0.0)

    def test_put_payoff(self):
        mesh = SinhMesh(strike=100, s_min=0, s_max=400, num_nodes=201,
                        concentration=12.5)
        mkt = MarketParams(spot=100, rate=0.05, volatility=0.20)
        con = ContractParams(strike=100, expiry=1.0, type=OptionType.Put)
        bc = BoundaryConditions(con, mkt, mesh)
        assert bc.payoff(80.0) == pytest.approx(20.0)
        assert bc.payoff(120.0) == pytest.approx(0.0)

    def test_terminal_condition_numpy(self):
        mesh = SinhMesh(strike=100, s_min=0, s_max=400, num_nodes=201,
                        concentration=12.5)
        mkt = MarketParams(spot=100, rate=0.05, volatility=0.20)
        con = ContractParams(strike=100, expiry=1.0, type=OptionType.Call)
        bc = BoundaryConditions(con, mkt, mesh)
        tc = bc.terminal_condition()
        assert isinstance(tc, np.ndarray)
        assert tc.dtype == np.float64
        assert len(tc) == 201


# ═══════════════════════════════════════════════════════════════════════
# SECTION 4: European Option Pricing vs Analytical
# ═══════════════════════════════════════════════════════════════════════


class TestEuropeanPricing:
    def test_atm_call_vs_bs(self):
        result = nq.european(spot=100, strike=100, expiry=1.0, rate=0.05, vol=0.20)
        expected = bs_call(100, 100, 1.0, 0.05, 0.20)
        assert result.price == pytest.approx(expected, abs=0.01)

    def test_atm_put_vs_bs(self):
        result = nq.european(spot=100, strike=100, expiry=1.0, rate=0.05, vol=0.20,
                             option_type="put")
        expected = bs_put(100, 100, 1.0, 0.05, 0.20)
        assert result.price == pytest.approx(expected, abs=0.01)

    def test_itm_call(self):
        result = nq.european(spot=120, strike=100, expiry=1.0, rate=0.05, vol=0.20)
        expected = bs_call(120, 100, 1.0, 0.05, 0.20)
        assert result.price == pytest.approx(expected, abs=0.02)

    def test_otm_call(self):
        result = nq.european(spot=80, strike=100, expiry=1.0, rate=0.05, vol=0.20)
        expected = bs_call(80, 100, 1.0, 0.05, 0.20)
        assert result.price == pytest.approx(expected, abs=0.01)

    def test_put_call_parity(self):
        S, K, T, r, sigma = 100, 100, 1.0, 0.05, 0.20
        call = nq.european(spot=S, strike=K, expiry=T, rate=r, vol=sigma).price
        put = nq.european(spot=S, strike=K, expiry=T, rate=r, vol=sigma,
                          option_type="put").price
        parity = call - put - (S - K * math.exp(-r * T))
        assert abs(parity) < 0.01

    def test_result_has_grid(self):
        result = nq.european(spot=100, strike=100, expiry=1.0, rate=0.05, vol=0.20)
        assert isinstance(result.grid, np.ndarray)
        assert len(result.grid) == result.spatial_nodes
        assert result.time_steps > 0

    def test_high_volatility(self):
        result = nq.european(spot=100, strike=100, expiry=1.0, rate=0.05, vol=0.80)
        expected = bs_call(100, 100, 1.0, 0.05, 0.80)
        assert result.price == pytest.approx(expected, abs=0.05)

    def test_short_maturity(self):
        result = nq.european(spot=100, strike=100, expiry=0.01, rate=0.05, vol=0.20)
        expected = bs_call(100, 100, 0.01, 0.05, 0.20)
        assert result.price == pytest.approx(expected, abs=0.01)

    def test_deep_itm_call_approaches_intrinsic(self):
        S, K, T, r = 200, 100, 0.01, 0.05
        result = nq.european(spot=S, strike=K, expiry=T, rate=r, vol=0.20)
        intrinsic = S - K * math.exp(-r * T)
        assert result.price >= intrinsic - 0.1

    def test_deep_otm_call_near_zero(self):
        result = nq.european(spot=50, strike=100, expiry=0.1, rate=0.05, vol=0.10)
        assert result.price < 0.01

    def test_with_dividends(self):
        result = nq.european(spot=100, strike=100, expiry=1.0, rate=0.05, vol=0.20,
                             dividend=0.03)
        no_div = nq.european(spot=100, strike=100, expiry=1.0, rate=0.05, vol=0.20)
        assert result.price < no_div.price  # dividends reduce call value

    def test_option_type_string_case_insensitive(self):
        r1 = nq.european(spot=100, strike=100, expiry=1.0, rate=0.05, vol=0.20,
                         option_type="Call")
        r2 = nq.european(spot=100, strike=100, expiry=1.0, rate=0.05, vol=0.20,
                         option_type="call")
        assert r1.price == pytest.approx(r2.price, abs=1e-10)

    def test_option_type_enum(self):
        r = nq.european(spot=100, strike=100, expiry=1.0, rate=0.05, vol=0.20,
                        option_type=OptionType.Call)
        expected = bs_call(100, 100, 1.0, 0.05, 0.20)
        assert r.price == pytest.approx(expected, abs=0.01)


class TestEuropeanInputValidation:
    def test_invalid_option_type_string(self):
        with pytest.raises(ValueError, match="call.*put"):
            nq.european(spot=100, strike=100, expiry=1.0, rate=0.05, vol=0.20,
                        option_type="forward")


# ═══════════════════════════════════════════════════════════════════════
# SECTION 5: American Options
# ═══════════════════════════════════════════════════════════════════════


class TestAmericanPricing:
    def test_american_put_premium(self):
        """American put >= European put."""
        am = nq.american(spot=100, strike=100, expiry=1.0, rate=0.05, vol=0.20,
                         option_type="put").price
        eu = nq.european(spot=100, strike=100, expiry=1.0, rate=0.05, vol=0.20,
                         option_type="put").price
        assert am >= eu - 1e-6

    def test_american_put_above_intrinsic(self):
        """American put >= intrinsic value."""
        S, K = 90, 100
        am = nq.american(spot=S, strike=K, expiry=1.0, rate=0.05, vol=0.20,
                         option_type="put").price
        assert am >= K - S - 0.01

    def test_american_call_equals_european_no_dividend(self):
        """Without dividends, American call = European call."""
        am = nq.american(spot=100, strike=100, expiry=1.0, rate=0.05, vol=0.20,
                         option_type="call").price
        eu = nq.european(spot=100, strike=100, expiry=1.0, rate=0.05, vol=0.20).price
        assert am == pytest.approx(eu, abs=0.01)

    def test_deep_itm_american_put(self):
        """Deep ITM American put should be close to intrinsic."""
        S, K = 50, 100
        am = nq.american(spot=S, strike=K, expiry=1.0, rate=0.05, vol=0.20,
                         option_type="put").price
        assert am >= K - S - 0.5


# ═══════════════════════════════════════════════════════════════════════
# SECTION 6: Greeks (AAD + Spatial)
# ═══════════════════════════════════════════════════════════════════════


class TestGreeks:
    def test_atm_call_greeks_vs_bs(self):
        g = nq.greeks(spot=100, strike=100, expiry=1.0, rate=0.05, vol=0.20)
        assert g.price == pytest.approx(bs_call(100, 100, 1.0, 0.05, 0.20), abs=0.01)
        assert g.delta == pytest.approx(bs_delta_call(100, 100, 1.0, 0.05, 0.20), abs=0.002)
        assert g.gamma == pytest.approx(bs_gamma(100, 100, 1.0, 0.05, 0.20), abs=0.0005)
        assert g.vega == pytest.approx(bs_vega(100, 100, 1.0, 0.05, 0.20), abs=0.05)

    def test_delta_range(self):
        """Call delta in [0, 1]."""
        g = nq.greeks(spot=100, strike=100, expiry=1.0, rate=0.05, vol=0.20)
        assert 0.0 < g.delta < 1.0

    def test_gamma_positive(self):
        g = nq.greeks(spot=100, strike=100, expiry=1.0, rate=0.05, vol=0.20)
        assert g.gamma > 0

    def test_theta_negative_for_long_call(self):
        g = nq.greeks(spot=100, strike=100, expiry=1.0, rate=0.05, vol=0.20)
        assert g.theta < 0

    def test_vega_positive(self):
        g = nq.greeks(spot=100, strike=100, expiry=1.0, rate=0.05, vol=0.20)
        assert g.vega > 0

    def test_rho_positive_for_call(self):
        g = nq.greeks(spot=100, strike=100, expiry=1.0, rate=0.05, vol=0.20)
        assert g.rho > 0

    def test_delta_surface_is_numpy(self):
        g = nq.greeks(spot=100, strike=100, expiry=1.0, rate=0.05, vol=0.20)
        assert isinstance(g.delta_surface, np.ndarray)
        assert g.delta_surface.dtype == np.float64

    def test_put_delta_negative(self):
        g = nq.greeks(spot=100, strike=100, expiry=1.0, rate=0.05, vol=0.20,
                      option_type="put")
        assert g.delta < 0

    def test_put_call_delta_relation(self):
        """delta_call - delta_put ~ 1 (no dividends)."""
        gc = nq.greeks(spot=100, strike=100, expiry=1.0, rate=0.05, vol=0.20)
        gp = nq.greeks(spot=100, strike=100, expiry=1.0, rate=0.05, vol=0.20,
                       option_type="put")
        assert gc.delta - gp.delta == pytest.approx(1.0, abs=0.01)


class TestBumpGreeks:
    def test_bump_vs_aad_call(self):
        g = nq.greeks(spot=100, strike=100, expiry=1.0, rate=0.05, vol=0.20)
        bg = nq.bump_greeks(spot=100, strike=100, expiry=1.0, rate=0.05, vol=0.20)
        assert bg.delta == pytest.approx(g.delta, abs=0.01)
        assert bg.gamma == pytest.approx(g.gamma, abs=0.001)
        assert bg.vega == pytest.approx(g.vega, abs=0.1)
        assert bg.rho == pytest.approx(g.rho, abs=0.1)

    def test_bump_vs_aad_put(self):
        g = nq.greeks(spot=100, strike=100, expiry=1.0, rate=0.05, vol=0.20,
                      option_type="put")
        bg = nq.bump_greeks(spot=100, strike=100, expiry=1.0, rate=0.05, vol=0.20,
                            option_type="put")
        assert bg.delta == pytest.approx(g.delta, abs=0.01)
        assert bg.vega == pytest.approx(g.vega, abs=0.1)


# ═══════════════════════════════════════════════════════════════════════
# SECTION 7: Barrier Options
# ═══════════════════════════════════════════════════════════════════════


class TestBarrierOptions:
    def test_doc_vs_analytical(self):
        r = nq.barrier(spot=100, strike=100, expiry=1.0, rate=0.05, vol=0.20,
                       level=80, direction="down", knock="out")
        analytical = BarrierPricer.analytical_down_out_call(100, 100, 80, 1.0, 0.05, 0.20)
        assert r.price == pytest.approx(analytical, abs=0.1)

    def test_uoc_vs_analytical(self):
        r = nq.barrier(spot=100, strike=100, expiry=1.0, rate=0.05, vol=0.20,
                       level=140, direction="up", knock="out")
        analytical = BarrierPricer.analytical_up_out_call(100, 100, 140, 1.0, 0.05, 0.20)
        assert r.price == pytest.approx(analytical, abs=0.2)

    def test_ko_less_than_vanilla(self):
        """Any knock-out price <= vanilla price."""
        vanilla = nq.european(spot=100, strike=100, expiry=1.0, rate=0.05, vol=0.20).price
        ko = nq.barrier(spot=100, strike=100, expiry=1.0, rate=0.05, vol=0.20,
                        level=80, direction="down", knock="out").price
        assert ko <= vanilla + 1e-6

    def test_ki_positive(self):
        r = nq.barrier(spot=100, strike=100, expiry=1.0, rate=0.05, vol=0.20,
                       level=80, direction="down", knock="in")
        assert r.price >= 0

    def test_in_out_parity_doc_dic(self):
        """DOC + DIC = Vanilla Call."""
        vanilla = nq.european(spot=100, strike=100, expiry=1.0, rate=0.05, vol=0.20).price
        doc = nq.barrier(spot=100, strike=100, expiry=1.0, rate=0.05, vol=0.20,
                         level=80, direction="down", knock="out").price
        dic = nq.barrier(spot=100, strike=100, expiry=1.0, rate=0.05, vol=0.20,
                         level=80, direction="down", knock="in").price
        assert doc + dic == pytest.approx(vanilla, abs=0.001)

    def test_in_out_parity_uoc_uic(self):
        """UOC + UIC = Vanilla Call."""
        vanilla = nq.european(spot=100, strike=100, expiry=1.0, rate=0.05, vol=0.20).price
        uoc = nq.barrier(spot=100, strike=100, expiry=1.0, rate=0.05, vol=0.20,
                         level=130, direction="up", knock="out").price
        uic = nq.barrier(spot=100, strike=100, expiry=1.0, rate=0.05, vol=0.20,
                         level=130, direction="up", knock="in").price
        assert uoc + uic == pytest.approx(vanilla, abs=0.001)

    def test_in_out_parity_puts(self):
        """DOP + DIP = Vanilla Put."""
        vanilla = nq.european(spot=100, strike=100, expiry=1.0, rate=0.05, vol=0.20,
                              option_type="put").price
        dop = nq.barrier(spot=100, strike=100, expiry=1.0, rate=0.05, vol=0.20,
                         option_type="put", level=80, direction="down", knock="out").price
        dip = nq.barrier(spot=100, strike=100, expiry=1.0, rate=0.05, vol=0.20,
                         option_type="put", level=80, direction="down", knock="in").price
        assert dop + dip == pytest.approx(vanilla, abs=0.001)

    def test_far_barrier_approaches_vanilla(self):
        """Down barrier very far below spot -> KO price ~ vanilla."""
        vanilla = nq.european(spot=100, strike=100, expiry=1.0, rate=0.05, vol=0.20).price
        ko = nq.barrier(spot=100, strike=100, expiry=1.0, rate=0.05, vol=0.20,
                        level=1.0, direction="down", knock="out").price
        assert ko == pytest.approx(vanilla, abs=0.01)

    def test_barrier_result_has_grid(self):
        r = nq.barrier(spot=100, strike=100, expiry=1.0, rate=0.05, vol=0.20,
                       level=80, direction="down", knock="out")
        assert isinstance(r.grid, np.ndarray)
        assert len(r.grid) == r.spatial_nodes

    def test_barrier_with_rebate(self):
        r_no = nq.barrier(spot=100, strike=100, expiry=1.0, rate=0.05, vol=0.20,
                          level=80, direction="down", knock="out", rebate=0.0).price
        r_yes = nq.barrier(spot=100, strike=100, expiry=1.0, rate=0.05, vol=0.20,
                           level=80, direction="down", knock="out", rebate=5.0).price
        assert r_yes >= r_no  # rebate adds value


# ═══════════════════════════════════════════════════════════════════════
# SECTION 8: Local Volatility
# ═══════════════════════════════════════════════════════════════════════


class TestLocalVolatility:
    def test_flat_vol_matches_constant(self):
        result_flat = nq.european(spot=100, strike=100, expiry=1.0, rate=0.05, vol=0.20,
                                  vol_model="flat")
        result_const = nq.european(spot=100, strike=100, expiry=1.0, rate=0.05, vol=0.20)
        assert result_flat.price == pytest.approx(result_const.price, abs=0.001)

    def test_cev_produces_different_price(self):
        result_flat = nq.european(spot=100, strike=100, expiry=1.0, rate=0.05,
                                  vol=0.20).price
        result_cev = nq.european(spot=100, strike=100, expiry=1.0, rate=0.05, vol=0.20,
                                 vol_model="cev", vol_params={"beta": 0.5}).price
        # CEV with beta != 1 should give a different price
        assert result_cev > 0
        # They might be close but shouldn't be exactly equal
        assert abs(result_flat - result_cev) < 1.0  # both are reasonable

    def test_skew_vol_model(self):
        result = nq.european(spot=100, strike=100, expiry=1.0, rate=0.05, vol=0.20,
                             vol_model="skew", vol_params={"skew_coeff": -0.1})
        assert result.price > 0

    def test_local_vol_surface_callable(self):
        lv = LocalVolSurface(lambda S, t: 0.20)
        assert lv(100.0, 0.5) == pytest.approx(0.20)

    def test_local_vol_surface_flat(self):
        lv = LocalVolSurface.flat(0.25)
        assert lv.is_constant
        assert lv.constant_vol == pytest.approx(0.25)
        assert lv(50.0, 1.0) == pytest.approx(0.25)

    def test_local_vol_surface_cev(self):
        lv = LocalVolSurface.cev(0.20, 100.0, 0.5)
        assert not lv.is_constant
        vol_at_100 = lv(100.0, 0.0)
        assert vol_at_100 == pytest.approx(0.20, abs=0.001)

    def test_invalid_vol_model(self):
        with pytest.raises(ValueError, match="Unknown vol_model"):
            nq.european(spot=100, strike=100, expiry=1.0, rate=0.05, vol=0.20,
                        vol_model="sabr")


# ═══════════════════════════════════════════════════════════════════════
# SECTION 9: Low-Level Bindings (Solver, Calculator)
# ═══════════════════════════════════════════════════════════════════════


class TestLowLevel:
    def test_solver_constant_vol(self):
        mesh = SinhMesh(strike=100, s_min=0, s_max=400, num_nodes=401,
                        concentration=12.5)
        mkt = MarketParams(spot=100, rate=0.05, volatility=0.20)
        con = ContractParams(strike=100, expiry=1.0, type=OptionType.Call)
        bc = BoundaryConditions(con, mkt, mesh)
        solver = CrankNicolsonSolver(mesh, bc, 400)
        result = solver.solve()
        assert result.price == pytest.approx(bs_call(100, 100, 1.0, 0.05, 0.20), abs=0.01)

    def test_solver_with_local_vol(self):
        mesh = SinhMesh(strike=100, s_min=0, s_max=400, num_nodes=401,
                        concentration=12.5)
        mkt = MarketParams(spot=100, rate=0.05, volatility=0.20)
        con = ContractParams(strike=100, expiry=1.0, type=OptionType.Call)
        bc = BoundaryConditions(con, mkt, mesh)
        lv = LocalVolSurface.flat(0.20)
        solver = CrankNicolsonSolver(mesh, bc, 400, lv)
        result = solver.solve()
        expected = bs_call(100, 100, 1.0, 0.05, 0.20)
        assert result.price == pytest.approx(expected, abs=0.01)

    def test_interpolate_static(self):
        mesh = SinhMesh(strike=100, s_min=0, s_max=400, num_nodes=401,
                        concentration=12.5)
        mkt = MarketParams(spot=100, rate=0.05, volatility=0.20)
        con = ContractParams(strike=100, expiry=1.0, type=OptionType.Call)
        bc = BoundaryConditions(con, mkt, mesh)
        solver = CrankNicolsonSolver(mesh, bc, 400)
        result = solver.solve()
        interp = CrankNicolsonSolver.interpolate(mesh, list(result.grid), 100.0)
        assert interp == pytest.approx(result.price, abs=0.001)

    def test_greeks_calculator_low_level(self):
        mesh = SinhMesh(strike=100, s_min=0, s_max=400, num_nodes=801,
                        concentration=12.5)
        mkt = MarketParams(spot=100, rate=0.05, volatility=0.20)
        con = ContractParams(strike=100, expiry=1.0, type=OptionType.Call)
        bc = BoundaryConditions(con, mkt, mesh)
        calc = GreeksCalculator(mesh, bc, 800)
        result = calc.compute()
        assert result.delta == pytest.approx(bs_delta_call(100, 100, 1.0, 0.05, 0.20),
                                              abs=0.002)

    def test_barrier_pricer_low_level(self):
        mesh = SinhMesh(strike=100, s_min=0, s_max=400, num_nodes=801,
                        concentration=12.5)
        mkt = MarketParams(spot=100, rate=0.05, volatility=0.20)
        con = ContractParams(strike=100, expiry=1.0, type=OptionType.Call)
        bc = BoundaryConditions(con, mkt, mesh)
        bp = BarrierParams(level=80, direction=BarrierDirection.Down,
                           knock=BarrierKnock.Out)
        pricer = BarrierPricer(mesh, bc, bp, 800)
        result = pricer.solve()
        assert result.price > 0
        assert result.price < nq.european(spot=100, strike=100, expiry=1.0,
                                           rate=0.05, vol=0.20).price + 0.01

    def test_analytical_statics_accessible(self):
        doc = BarrierPricer.analytical_down_out_call(100, 100, 80, 1.0, 0.05, 0.20)
        uoc = BarrierPricer.analytical_up_out_call(100, 100, 140, 1.0, 0.05, 0.20)
        dop = BarrierPricer.analytical_down_out_put(100, 100, 80, 1.0, 0.05, 0.20)
        uop = BarrierPricer.analytical_up_out_put(100, 100, 130, 1.0, 0.05, 0.20)
        assert doc > 0
        assert uoc > 0
        assert dop > 0
        assert uop > 0


# ═══════════════════════════════════════════════════════════════════════
# SECTION 10: Grid Convergence
# ═══════════════════════════════════════════════════════════════════════


class TestConvergence:
    def test_european_convergence(self):
        """Finer grids should produce more accurate prices overall."""
        expected = bs_call(100, 100, 1.0, 0.05, 0.20)
        errors = []
        for n in [101, 201, 401, 801]:
            r = nq.european(spot=100, strike=100, expiry=1.0, rate=0.05, vol=0.20,
                            num_nodes=n, num_time_steps=n - 1)
            errors.append(abs(r.price - expected))
        # Coarsest grid should be less accurate than finest
        assert errors[-1] < errors[0]
        # All errors should be small on a fine grid
        assert errors[-1] < 0.001


# ═══════════════════════════════════════════════════════════════════════
# SECTION 11: Stress Tests
# ═══════════════════════════════════════════════════════════════════════


class TestStress:
    def test_many_sequential_prices(self):
        """Price 50 options sequentially - no crashes or memory leaks."""
        for i in range(50):
            S = 80 + i
            r = nq.european(spot=S, strike=100, expiry=1.0, rate=0.05, vol=0.20,
                            num_nodes=201, num_time_steps=200)
            assert r.price >= 0

    def test_extreme_parameters(self):
        """Very high/low parameter values should not crash."""
        # High vol
        r = nq.european(spot=100, strike=100, expiry=1.0, rate=0.05, vol=2.0,
                        num_nodes=201, num_time_steps=200)
        assert r.price > 0

        # Near-zero rate
        r = nq.european(spot=100, strike=100, expiry=1.0, rate=0.001, vol=0.20,
                        num_nodes=201, num_time_steps=200)
        assert r.price > 0

        # Very short maturity
        r = nq.european(spot=100, strike=100, expiry=0.001, rate=0.05, vol=0.20,
                        num_nodes=201, num_time_steps=200)
        assert r.price >= 0

    def test_large_grid(self):
        """Large grid should work correctly."""
        r = nq.european(spot=100, strike=100, expiry=1.0, rate=0.05, vol=0.20,
                        num_nodes=2001, num_time_steps=2000)
        expected = bs_call(100, 100, 1.0, 0.05, 0.20)
        assert r.price == pytest.approx(expected, abs=0.001)
