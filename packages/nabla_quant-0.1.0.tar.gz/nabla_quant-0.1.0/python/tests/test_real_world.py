"""
Real-world pricing validation for the NablaQuant Python SDK and FastAPI API.

Validates against:
  - Black-Scholes analytical formulas with market-realistic parameters
  - Put-call parity at institutional scale (SPX-like)
  - Greeks sign/range consistency for real market regimes
  - Barrier in-out parity at scale
  - API endpoints returning consistent results with SDK
  - LIVE market data from Yahoo Finance, properly reflected in pricing
"""

import math
import asyncio
import pytest
import numpy as np

import nabla_quant as nq


# ── Black-Scholes reference ────────────────────────────────────────

def norm_cdf(x):
    return 0.5 * math.erfc(-x / math.sqrt(2.0))


def norm_pdf(x):
    return math.exp(-0.5 * x * x) / math.sqrt(2.0 * 3.14159265358979323846)


def bs_price(S, K, T, r, sigma, q=0.0, opt="call"):
    d1 = (math.log(S / K) + (r - q + 0.5 * sigma**2) * T) / (sigma * math.sqrt(T))
    d2 = d1 - sigma * math.sqrt(T)
    if opt == "call":
        return S * math.exp(-q * T) * norm_cdf(d1) - K * math.exp(-r * T) * norm_cdf(d2)
    return K * math.exp(-r * T) * norm_cdf(-d2) - S * math.exp(-q * T) * norm_cdf(-d1)


def bs_greeks(S, K, T, r, sigma, q=0.0, opt="call"):
    d1 = (math.log(S / K) + (r - q + 0.5 * sigma**2) * T) / (sigma * math.sqrt(T))
    d2 = d1 - sigma * math.sqrt(T)
    eqT = math.exp(-q * T)
    erT = math.exp(-r * T)
    vega = S * eqT * norm_pdf(d1) * math.sqrt(T)
    gamma = eqT * norm_pdf(d1) / (S * sigma * math.sqrt(T))
    if opt == "call":
        delta = eqT * norm_cdf(d1)
        rho = K * T * erT * norm_cdf(d2)
    else:
        delta = -eqT * norm_cdf(-d1)
        rho = -K * T * erT * norm_cdf(-d2)
    return {"delta": delta, "gamma": gamma, "vega": vega, "rho": rho}


def _yf_available():
    try:
        import yfinance  # noqa: F401
        return True
    except ImportError:
        return False


# ══════════════════════════════════════════════════════════════════
# SDK real-world validation (synthetic - always runnable)
# ══════════════════════════════════════════════════════════════════

class TestRealWorldSDK:
    """Market-realistic SDK tests with synthetic parameters."""

    def test_spx_atm_call(self):
        """SPX-like ATM call pricing matches BS."""
        S, K, T, r, vol = 5000, 5000, 0.25, 0.045, 0.16
        res = nq.european(spot=S, strike=K, expiry=T, rate=r, vol=vol,
                          option_type="call", num_nodes=501, num_time_steps=2000)
        expected = bs_price(S, K, T, r, vol)
        assert res.price == pytest.approx(expected, abs=1.0)

    def test_spx_put_call_parity(self):
        """Put-call parity holds for SPX-scale instruments."""
        S, K, T, r, vol = 5000, 5000, 0.25, 0.045, 0.16
        c = nq.european(spot=S, strike=K, expiry=T, rate=r, vol=vol,
                        option_type="call", num_nodes=501, num_time_steps=2000)
        p = nq.european(spot=S, strike=K, expiry=T, rate=r, vol=vol,
                        option_type="put", num_nodes=501, num_time_steps=2000)
        parity = c.price - p.price - (S - K * math.exp(-r * T))
        assert abs(parity) < 1.0, f"Put-call parity violation: {parity:.4f}"

    def test_spx_greeks_atm_call(self):
        """Greeks for SPX-like ATM call are directionally correct."""
        S, K, T, r, vol = 5000, 5000, 0.25, 0.045, 0.16
        g = nq.greeks(spot=S, strike=K, expiry=T, rate=r, vol=vol,
                      option_type="call", num_nodes=501, num_time_steps=2000)
        ref = bs_greeks(S, K, T, r, vol)
        assert 0.4 < g.delta < 0.7, f"ATM call delta={g.delta}"
        assert g.gamma > 0
        assert g.vega > 0
        assert g.rho > 0
        assert g.vega == pytest.approx(ref["vega"], rel=0.05)

    def test_spx_barrier_doc_vs_analytical(self):
        """DOC for SPX-like instrument vs analytical."""
        S, K, T, r, vol, B = 5000, 5000, 0.25, 0.045, 0.16, 4500
        doc = nq.barrier(spot=S, strike=K, expiry=T, rate=r, vol=vol,
                         option_type="call", level=B, direction="down", knock="out",
                         num_nodes=801, num_time_steps=2000)
        vanilla = nq.european(spot=S, strike=K, expiry=T, rate=r, vol=vol,
                              option_type="call", num_nodes=801, num_time_steps=2000)
        assert doc.price > 0
        assert doc.price < vanilla.price

    def test_spx_barrier_inout_parity(self):
        """DOC + DIC = vanilla at institutional scale."""
        S, K, T, r, vol, B = 5000, 5000, 0.25, 0.045, 0.16, 4500
        kw = dict(spot=S, strike=K, expiry=T, rate=r, vol=vol,
                  option_type="call", num_nodes=801, num_time_steps=2000)
        doc = nq.barrier(**kw, level=B, direction="down", knock="out")
        dic = nq.barrier(**kw, level=B, direction="down", knock="in")
        vanilla = nq.european(**kw)
        assert doc.price + dic.price == pytest.approx(vanilla.price, abs=2.0)

    def test_high_yield_equity_call(self):
        """High-dividend stock pricing: call depressed, put elevated."""
        S, K, T, r, vol, q = 100, 100, 1.0, 0.05, 0.25, 0.06
        c = nq.european(spot=S, strike=K, expiry=T, rate=r, vol=vol,
                        option_type="call", dividend=q,
                        num_nodes=501, num_time_steps=2000)
        c_nodiv = nq.european(spot=S, strike=K, expiry=T, rate=r, vol=vol,
                              option_type="call",
                              num_nodes=501, num_time_steps=2000)
        assert c.price < c_nodiv.price, "Dividend reduces call value"
        expected = bs_price(S, K, T, r, vol, q, "call")
        assert c.price == pytest.approx(expected, abs=0.1)

    def test_short_dated_otm_put(self):
        """Short-dated deep OTM put should be very cheap."""
        S, K, T, r, vol = 100, 70, 0.02, 0.05, 0.20
        p = nq.european(spot=S, strike=K, expiry=T, rate=r, vol=vol,
                        option_type="put", num_nodes=501, num_time_steps=500)
        assert p.price < 0.01

    def test_american_put_early_exercise_premium(self):
        """American put > European put for ITM scenario."""
        S, K, T, r, vol = 80, 100, 1.0, 0.05, 0.25
        am = nq.american(spot=S, strike=K, expiry=T, rate=r, vol=vol,
                         option_type="put", num_nodes=501, num_time_steps=2000)
        eu = nq.european(spot=S, strike=K, expiry=T, rate=r, vol=vol,
                         option_type="put", num_nodes=501, num_time_steps=2000)
        assert am.price > eu.price, "American put must have early-exercise premium"
        assert am.price >= (K - S), "American put >= intrinsic value"

    def test_local_vol_cev_vs_flat(self):
        """CEV vol with beta=1 should approximate flat vol."""
        S, K, T, r, vol = 100, 100, 1.0, 0.05, 0.20
        flat = nq.european(spot=S, strike=K, expiry=T, rate=r, vol=vol,
                           option_type="call", num_nodes=501, num_time_steps=1000)
        cev = nq.european(spot=S, strike=K, expiry=T, rate=r, vol=vol,
                          option_type="call", vol_model="cev",
                          vol_params={"beta": 1.0},
                          num_nodes=501, num_time_steps=1000)
        assert cev.price == pytest.approx(flat.price, abs=0.3)


# ══════════════════════════════════════════════════════════════════
# LIVE MARKET DATA validation (requires yfinance + network)
# ══════════════════════════════════════════════════════════════════

@pytest.mark.skipif(not _yf_available(), reason="yfinance not installed")
class TestLiveMarketData:
    """Fetch real market data and validate the pricing engine against it."""

    def _get_market_data(self, symbol="SPY"):
        from nabla_quant.api.market_data import (
            fetch_quote_sync,
            list_expiries_sync,
            fetch_chain_sync,
        )
        quote = fetch_quote_sync(symbol)
        expiries = list_expiries_sync(symbol)
        exp = expiries["expirations"][min(2, len(expiries["expirations"]) - 1)]
        chain = fetch_chain_sync(symbol, exp)
        return quote, chain

    def test_live_quote_has_real_rate_and_dividend(self):
        """Quote endpoint returns real risk-free rate from Treasury and dividend yield."""
        from nabla_quant.api.market_data import fetch_quote_sync
        quote = fetch_quote_sync("SPY")
        assert "risk_free_rate" in quote
        assert "dividend_yield" in quote
        assert 0 < quote["risk_free_rate"] < 0.20, f"Rate {quote['risk_free_rate']} out of sane range"
        assert 0 <= quote["dividend_yield"] < 0.10, f"Div yield {quote['dividend_yield']} out of range"
        assert quote["spot"] > 0

    def test_live_chain_has_real_rate_and_dividend(self):
        """Chain endpoint returns real rate + div."""
        from nabla_quant.api.market_data import fetch_chain_sync, list_expiries_sync
        expiries = list_expiries_sync("SPY")
        exp = expiries["expirations"][0]
        chain = fetch_chain_sync("SPY", exp)
        assert "risk_free_rate" in chain
        assert "dividend_yield" in chain
        assert chain["risk_free_rate"] > 0

    def test_live_risk_free_rate_from_treasury(self):
        """Verify risk-free rate comes from actual Treasury yield data."""
        from nabla_quant.api.market_data import _fetch_risk_free_rate
        rfr = _fetch_risk_free_rate()
        assert 0 < rfr < 0.15, f"Risk-free rate {rfr} doesn't look like a real Treasury yield"

    def test_live_spy_atm_call_with_market_params(self):
        """Price SPY ATM call using real spot, real r, real q, market IV."""
        quote, chain = self._get_market_data("SPY")
        S = chain["spot"]
        r = chain["risk_free_rate"]
        q = chain["dividend_yield"]
        T = chain["time_to_expiry_years"]

        atm_call = min(chain["calls"], key=lambda c: abs(c["strike"] - S))
        K = atm_call["strike"]
        iv = atm_call["implied_volatility"]
        if iv is None or iv <= 0:
            pytest.skip("No valid IV for ATM call")

        market_price = atm_call["last_price"]
        if market_price is None or market_price <= 0:
            bid = atm_call.get("bid") or 0
            ask = atm_call.get("ask") or 0
            if bid > 0 and ask > 0:
                market_price = (bid + ask) / 2
            else:
                pytest.skip("No valid market price for ATM call")

        pde = nq.european(
            spot=S, strike=K, expiry=T, rate=r, vol=iv,
            option_type="call", dividend=q,
            num_nodes=801, num_time_steps=2000,
        )
        bs_ref = bs_price(S, K, T, r, iv, q, "call")

        assert pde.price == pytest.approx(bs_ref, abs=0.5), \
            f"PDE {pde.price:.4f} vs BS {bs_ref:.4f}"

        ratio = pde.price / market_price if market_price > 0.01 else float("inf")
        assert 0.7 < ratio < 1.4, \
            f"PDE/market={ratio:.3f} (PDE={pde.price:.4f}, mkt={market_price:.4f}) - too far"

    def test_live_put_call_parity_with_market_params(self):
        """Put-call parity holds using real market parameters."""
        quote, chain = self._get_market_data("SPY")
        S = chain["spot"]
        r = chain["risk_free_rate"]
        q = chain["dividend_yield"]
        T = chain["time_to_expiry_years"]

        atm_call = min(chain["calls"], key=lambda c: abs(c["strike"] - S))
        K = atm_call["strike"]
        iv = atm_call["implied_volatility"]
        if iv is None or iv <= 0:
            pytest.skip("No valid IV")

        c = nq.european(spot=S, strike=K, expiry=T, rate=r, vol=iv,
                        option_type="call", dividend=q,
                        num_nodes=801, num_time_steps=2000)
        p = nq.european(spot=S, strike=K, expiry=T, rate=r, vol=iv,
                        option_type="put", dividend=q,
                        num_nodes=801, num_time_steps=2000)
        lhs = c.price - p.price
        rhs = S * math.exp(-q * T) - K * math.exp(-r * T)
        assert lhs == pytest.approx(rhs, abs=0.5), \
            f"Put-call parity: C-P={lhs:.4f} vs S*e^(-qT)-K*e^(-rT)={rhs:.4f}"

    def test_live_greeks_signs_with_market_params(self):
        """Greeks directional signs correct using real parameters."""
        quote, chain = self._get_market_data("SPY")
        S = chain["spot"]
        r = chain["risk_free_rate"]
        q = chain["dividend_yield"]
        T = chain["time_to_expiry_years"]

        atm_call = min(chain["calls"], key=lambda c: abs(c["strike"] - S))
        K = atm_call["strike"]
        iv = atm_call["implied_volatility"]
        if iv is None or iv <= 0:
            pytest.skip("No valid IV")

        g = nq.greeks(spot=S, strike=K, expiry=T, rate=r, vol=iv,
                      option_type="call", dividend=q,
                      num_nodes=801, num_time_steps=2000)
        assert 0.3 < g.delta < 0.8, f"ATM call delta={g.delta}"
        assert g.gamma > 0, f"gamma={g.gamma} should be positive"
        assert g.vega > 0, f"vega={g.vega} should be positive"
        assert g.theta < 0, f"theta={g.theta} should be negative for long call"

    def test_live_vol_surface_endpoint(self):
        """Vol surface endpoint returns real IV data across expirations."""
        from nabla_quant.api.market_data import fetch_vol_surface_sync
        surf = fetch_vol_surface_sync("SPY", max_expiries=4)
        assert surf["spot"] > 0
        assert len(surf["expiries"]) >= 2
        assert len(surf["strikes"]) >= 5
        assert len(surf["vols"]) == len(surf["expiries"])
        for row in surf["vols"]:
            valid = [v for v in row if v is not None]
            assert len(valid) > 0, "At least some IVs should be non-null"
            for v in valid:
                assert 0.01 < v < 5.0, f"IV={v} out of range"

    def test_live_multiple_tickers(self):
        """Rate + div fetch works across multiple tickers."""
        from nabla_quant.api.market_data import fetch_quote_sync
        for sym in ["AAPL", "MSFT"]:
            try:
                q = fetch_quote_sync(sym)
                assert q["spot"] > 0
                assert "risk_free_rate" in q
                assert q["risk_free_rate"] > 0
            except Exception:
                pytest.skip(f"Could not fetch {sym}")

    def test_live_dividend_reflected_in_pricing(self):
        """Dividend yield from market data properly depresses call value."""
        from nabla_quant.api.market_data import fetch_quote_sync
        q = fetch_quote_sync("SPY")
        S = q["spot"]
        r = q["risk_free_rate"]
        div = q["dividend_yield"]

        K, T, vol = S, 1.0, 0.18
        c_with_div = nq.european(spot=S, strike=K, expiry=T, rate=r, vol=vol,
                                 option_type="call", dividend=div,
                                 num_nodes=501, num_time_steps=1000)
        c_no_div = nq.european(spot=S, strike=K, expiry=T, rate=r, vol=vol,
                               option_type="call", dividend=0.0,
                               num_nodes=501, num_time_steps=1000)
        if div > 0.001:
            assert c_with_div.price < c_no_div.price, \
                f"Div={div:.4f} should reduce call: with={c_with_div.price:.4f}, without={c_no_div.price:.4f}"

        expected = bs_price(S, K, T, r, vol, div, "call")
        assert c_with_div.price == pytest.approx(expected, abs=0.5)


# ══════════════════════════════════════════════════════════════════
# API real-world validation
# ══════════════════════════════════════════════════════════════════

class TestRealWorldAPI:
    """FastAPI endpoint validation with real C++ engine."""

    @pytest.fixture
    def app(self):
        from nabla_quant.api.app import create_app
        return create_app()

    @pytest.mark.asyncio
    async def test_api_european_matches_sdk(self, app):
        """API European price should match SDK."""
        import httpx
        kw = {"spot": 100, "strike": 100, "expiry": 1.0,
              "rate": 0.05, "volatility": 0.20,
              "num_nodes": 501, "num_time_steps": 1000}
        async with httpx.AsyncClient(
            transport=httpx.ASGITransport(app=app),
            base_url="http://test"
        ) as c:
            resp = await c.post("/api/v1/price/european", json=kw)
        assert resp.status_code == 200
        api_price = resp.json()["price"]
        sdk_price = nq.european(spot=100, strike=100, expiry=1.0, rate=0.05,
                                vol=0.20, option_type="call",
                                num_nodes=501, num_time_steps=1000).price
        assert api_price == pytest.approx(sdk_price, abs=0.01)

    @pytest.mark.asyncio
    async def test_api_greeks_consistency(self, app):
        """API Greeks should match SDK Greeks."""
        import httpx
        kw = {"spot": 100, "strike": 100, "expiry": 1.0,
              "rate": 0.05, "volatility": 0.20,
              "num_nodes": 501, "num_time_steps": 1000}
        async with httpx.AsyncClient(
            transport=httpx.ASGITransport(app=app),
            base_url="http://test"
        ) as c:
            resp = await c.post("/api/v1/greeks", json=kw)
        assert resp.status_code == 200
        data = resp.json()
        sdk = nq.greeks(spot=100, strike=100, expiry=1.0, rate=0.05, vol=0.20,
                        option_type="call", num_nodes=501, num_time_steps=1000)
        assert data["delta"] == pytest.approx(sdk.delta, abs=0.001)
        assert data["vega"] == pytest.approx(sdk.vega, abs=0.1)

    @pytest.mark.asyncio
    async def test_api_barrier_matches_sdk(self, app):
        """API barrier price should match SDK barrier price."""
        import httpx
        kw = {"spot": 100, "strike": 100, "expiry": 1.0,
              "rate": 0.05, "volatility": 0.20,
              "barrier_level": 80, "barrier_direction": "down",
              "barrier_knock": "out",
              "num_nodes": 501, "num_time_steps": 1000}
        async with httpx.AsyncClient(
            transport=httpx.ASGITransport(app=app),
            base_url="http://test"
        ) as c:
            resp = await c.post("/api/v1/price/barrier", json=kw)
        assert resp.status_code == 200
        api_price = resp.json()["price"]
        sdk_price = nq.barrier(spot=100, strike=100, expiry=1.0, rate=0.05,
                               vol=0.20, option_type="call", level=80,
                               direction="down", knock="out",
                               num_nodes=501, num_time_steps=1000).price
        assert api_price == pytest.approx(sdk_price, abs=0.01)

    @pytest.mark.asyncio
    @pytest.mark.skipif(not _yf_available(), reason="yfinance not installed")
    async def test_api_market_quote_returns_rate_and_dividend(self, app):
        """Market quote API endpoint includes real rate + dividend."""
        import httpx
        async with httpx.AsyncClient(
            transport=httpx.ASGITransport(app=app),
            base_url="http://test",
            timeout=30.0,
        ) as c:
            resp = await c.get("/api/v1/market/quote?symbol=SPY")
        assert resp.status_code == 200
        data = resp.json()
        assert data["spot"] > 0
        assert "risk_free_rate" in data
        assert 0 < data["risk_free_rate"] < 0.20
        assert "dividend_yield" in data
        assert data["dividend_yield"] >= 0

    @pytest.mark.asyncio
    @pytest.mark.skipif(not _yf_available(), reason="yfinance not installed")
    async def test_api_vol_surface_returns_live_ivs(self, app):
        """Vol surface API endpoint returns calibrated IVs from market."""
        import httpx
        async with httpx.AsyncClient(
            transport=httpx.ASGITransport(app=app),
            base_url="http://test",
            timeout=60.0,
        ) as c:
            resp = await c.get("/api/v1/market/vol_surface?symbol=SPY&max_expiries=3")
        assert resp.status_code == 200
        data = resp.json()
        assert len(data["strikes"]) >= 5
        assert len(data["expiries"]) >= 2
        assert data["spot"] > 0
        assert data["risk_free_rate"] > 0
