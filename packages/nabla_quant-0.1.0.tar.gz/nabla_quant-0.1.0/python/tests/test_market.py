"""Market data API tests (yfinance optional)."""

from fastapi.testclient import TestClient

from nabla_quant.api.app import create_app


def test_market_routes_return_503_when_yfinance_disabled(monkeypatch):
    from nabla_quant.api import market_data

    monkeypatch.setattr(market_data, "yfinance_available", lambda: False)
    app = create_app()
    with TestClient(app) as client:
        r = client.get("/api/v1/market/quote", params={"symbol": "SPY"})
        assert r.status_code == 503
        assert "yfinance" in r.json()["detail"].lower()

        r2 = client.get("/api/v1/market/expiries", params={"symbol": "SPY"})
        assert r2.status_code == 503

        r3 = client.get(
            "/api/v1/market/chain",
            params={"symbol": "SPY", "expiration": "2030-01-18"},
        )
        assert r3.status_code == 503
