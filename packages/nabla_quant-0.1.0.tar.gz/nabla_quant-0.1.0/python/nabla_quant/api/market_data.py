"""Delayed equity options data via Yahoo Finance (yfinance).

Suitable for research, demos, and dashboard smoke tests - not for production trading.
"""

from __future__ import annotations

import math
from datetime import date, datetime
from typing import Any


def yfinance_available() -> bool:
    try:
        import yfinance  # noqa: F401

        return True
    except ImportError:
        return False


def _require_yf():
    if not yfinance_available():
        raise RuntimeError(
            "Market data requires yfinance. Install with: pip install yfinance"
        )
    import yfinance as yf

    return yf


def _fetch_risk_free_rate() -> float:
    """Fetch the current 13-week T-bill yield (^IRX) as annualized rate.

    Falls back to 10Y Treasury (^TNX), then to a conservative 4.25% default.
    """
    yf = _require_yf()
    for ticker, divisor in [("^IRX", 100.0), ("^TNX", 100.0)]:
        try:
            t = yf.Ticker(ticker)
            hist = t.history(period="5d")
            if hist is not None and not hist.empty:
                val = float(hist["Close"].iloc[-1])
                if 0 < val < 30:
                    return round(val / divisor, 6)
        except Exception:
            continue
    return 0.0425


def _extract_dividend_yield(info: dict[str, Any]) -> float:
    """Extract annualized continuous dividend yield as a decimal from yfinance info.

    yfinance fields are inconsistent across tickers:
      - trailingAnnualDividendYield: decimal (0.0083 = 0.83%) - most reliable
      - yield: decimal for ETFs (0.0114 = 1.14%)
      - dividendYield: percentage as float (1.14 means 1.14%) - needs /100
    """
    for key in ("trailingAnnualDividendYield",):
        val = info.get(key)
        if val is not None:
            try:
                v = float(val)
                if 0 < v < 0.25:
                    return round(v, 6)
            except (TypeError, ValueError):
                pass

    val = info.get("yield")
    if val is not None:
        try:
            v = float(val)
            if 0 < v < 0.25:
                return round(v, 6)
        except (TypeError, ValueError):
            pass

    val = info.get("dividendYield")
    if val is not None:
        try:
            v = float(val)
            if v > 0.25:
                v = v / 100.0
            if 0 < v < 0.25:
                return round(v, 6)
        except (TypeError, ValueError):
            pass

    return 0.0


def fetch_quote_sync(symbol: str) -> dict[str, Any]:
    yf = _require_yf()
    sym = symbol.upper().strip()
    if not sym:
        raise ValueError("empty symbol")
    t = yf.Ticker(sym)
    hist = t.history(period="5d")
    if hist is None or hist.empty:
        raise ValueError(f"No price history for {sym}")
    spot = float(hist["Close"].iloc[-1])
    info = getattr(t, "info", None) or {}

    div_yield = _extract_dividend_yield(info)
    rfr = _fetch_risk_free_rate()

    return {
        "symbol": sym,
        "spot": round(spot, 4),
        "currency": str(info.get("currency", "USD")),
        "name": info.get("shortName") or info.get("longName"),
        "as_of": str(hist.index[-1])[:10],
        "risk_free_rate": rfr,
        "dividend_yield": div_yield,
    }


def list_expiries_sync(symbol: str) -> dict[str, Any]:
    yf = _require_yf()
    sym = symbol.upper().strip()
    t = yf.Ticker(sym)
    opts = getattr(t, "options", None)
    if not opts:
        raise ValueError(f"No option expirations for {sym}")
    return {"symbol": sym, "expirations": list(opts)}


def _years_to_expiry(expiration: str) -> float:
    exp = datetime.strptime(expiration, "%Y-%m-%d").date()
    days = (exp - date.today()).days
    if days < 1:
        days = 1
    return round(days / 365.25, 4)


def _row_from_call_series(row: Any) -> dict[str, Any]:
    def f(x):
        if x is None:
            return None
        try:
            if x != x:  # NaN
                return None
            return float(x)
        except (TypeError, ValueError):
            return None

    def vi(x):
        try:
            if x is None or x != x:
                return None
            return int(float(x))
        except (TypeError, ValueError):
            return None

    return {
        "strike": float(row.get("strike", 0)),
        "last_price": f(row.get("lastPrice")),
        "bid": f(row.get("bid")),
        "ask": f(row.get("ask")),
        "implied_volatility": f(row.get("impliedVolatility")),
        "volume": vi(row.get("volume")),
    }


def fetch_chain_sync(symbol: str, expiration: str) -> dict[str, Any]:
    yf = _require_yf()
    sym = symbol.upper().strip()
    t = yf.Ticker(sym)
    hist = t.history(period="5d")
    if hist is None or hist.empty:
        raise ValueError(f"No spot price for {sym}")
    spot = float(hist["Close"].iloc[-1])
    try:
        oc = t.option_chain(expiration)
    except Exception as e:
        raise ValueError(f"Could not load chain for {sym} {expiration}: {e}") from e

    calls_df = oc.calls
    puts_df = oc.puts
    calls = calls_df.to_dict("records") if calls_df is not None and not calls_df.empty else []
    puts = puts_df.to_dict("records") if puts_df is not None and not puts_df.empty else []

    def near_atm(rows: list[Any], s: float, width: int = 8) -> list[dict[str, Any]]:
        if not rows:
            return []
        mid = min(range(len(rows)), key=lambda i: abs(float(rows[i]["strike"]) - s))
        lo = max(0, mid - width)
        hi = min(len(rows), mid + width + 1)
        return [_row_from_call_series(r) for r in rows[lo:hi]]

    calls_trim = near_atm(calls, spot)
    puts_trim = near_atm(puts, spot)

    info = getattr(t, "info", None) or {}
    div_yield = _extract_dividend_yield(info)
    rfr = _fetch_risk_free_rate()

    return {
        "symbol": sym,
        "expiration": expiration,
        "spot": round(spot, 4),
        "time_to_expiry_years": _years_to_expiry(expiration),
        "calls": calls_trim,
        "puts": puts_trim,
        "risk_free_rate": rfr,
        "dividend_yield": div_yield,
    }


def fetch_vol_surface_sync(symbol: str, max_expiries: int = 6) -> dict[str, Any]:
    """Build a market-calibrated implied vol surface from live option chain data.

    Returns a grid of IVs indexed by (time_to_expiry, strike) using actual
    market-quoted implied volatilities across multiple expirations.
    """
    yf = _require_yf()
    sym = symbol.upper().strip()
    t = yf.Ticker(sym)
    hist = t.history(period="5d")
    if hist is None or hist.empty:
        raise ValueError(f"No spot price for {sym}")
    spot = float(hist["Close"].iloc[-1])

    opts = getattr(t, "options", None)
    if not opts:
        raise ValueError(f"No option expirations for {sym}")

    # Pick a spread of expirations (near-term through longer-dated)
    n = len(opts)
    if n <= max_expiries:
        selected = list(opts)
    else:
        indices = [int(round(i * (n - 1) / (max_expiries - 1))) for i in range(max_expiries)]
        selected = [opts[i] for i in sorted(set(indices))]

    all_strikes: set[float] = set()
    raw_data: list[dict[str, Any]] = []

    for exp in selected:
        tte = _years_to_expiry(exp)
        try:
            oc = t.option_chain(exp)
        except Exception:
            continue
        calls_df = oc.calls
        if calls_df is None or calls_df.empty:
            continue

        # Filter to near-ATM strikes with valid IV
        calls = calls_df.to_dict("records")
        atm_idx = min(range(len(calls)), key=lambda i: abs(float(calls[i]["strike"]) - spot))
        lo = max(0, atm_idx - 12)
        hi = min(len(calls), atm_idx + 13)
        exp_ivs: dict[float, float] = {}
        for row in calls[lo:hi]:
            strike_val = float(row.get("strike", 0))
            iv = row.get("impliedVolatility")
            if iv is None or (iv != iv):  # NaN check
                continue
            iv = float(iv)
            if 0.01 < iv < 5.0:
                exp_ivs[strike_val] = round(iv, 6)
                all_strikes.add(strike_val)
        if exp_ivs:
            raw_data.append({"expiration": exp, "tte": tte, "ivs": exp_ivs})

    if not raw_data:
        raise ValueError(f"No valid IV data found for {sym}")

    # Build uniform strike grid from the union of observed strikes
    sorted_strikes = sorted(all_strikes)

    expiries_out = []
    vols_out: list[list[float | None]] = []
    for entry in raw_data:
        expiries_out.append(entry["tte"])
        row_ivs = entry["ivs"]
        row: list[float | None] = []
        for k in sorted_strikes:
            if k in row_ivs:
                row.append(row_ivs[k])
            else:
                # Linear interpolation from neighboring strikes in this expiry
                below = [(kk, v) for kk, v in row_ivs.items() if kk < k]
                above = [(kk, v) for kk, v in row_ivs.items() if kk > k]
                if below and above:
                    kb, vb = max(below, key=lambda x: x[0])
                    ka, va = min(above, key=lambda x: x[0])
                    frac = (k - kb) / (ka - kb)
                    row.append(round(vb + frac * (va - vb), 6))
                elif below:
                    row.append(max(below, key=lambda x: x[0])[1])
                elif above:
                    row.append(min(above, key=lambda x: x[0])[1])
                else:
                    row.append(None)
        vols_out.append(row)

    return {
        "symbol": sym,
        "spot": round(spot, 4),
        "strikes": sorted_strikes,
        "expiries": expiries_out,
        "expirations": [e["expiration"] for e in raw_data],
        "vols": vols_out,
        "risk_free_rate": _fetch_risk_free_rate(),
    }
