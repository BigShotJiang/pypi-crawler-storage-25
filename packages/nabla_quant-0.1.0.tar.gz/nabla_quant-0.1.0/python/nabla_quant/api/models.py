"""Pydantic models for the NablaQuant pricing API."""

from __future__ import annotations

from enum import Enum
from typing import Optional

from pydantic import BaseModel, Field, field_validator


class OptionTypeEnum(str, Enum):
    call = "call"
    put = "put"


class ExerciseTypeEnum(str, Enum):
    european = "european"
    american = "american"


class BarrierDirectionEnum(str, Enum):
    up = "up"
    down = "down"


class BarrierKnockEnum(str, Enum):
    out = "out"
    knock_in = "in"


class VolModelEnum(str, Enum):
    flat = "flat"
    cev = "cev"
    skew = "skew"


# ── Request Models ───────────────────────────────────────────────────────


class PricingRequest(BaseModel):
    spot: float = Field(..., gt=0, description="Current asset price")
    strike: float = Field(..., gt=0, description="Strike price")
    expiry: float = Field(..., gt=0, description="Time to expiry in years")
    rate: float = Field(..., description="Risk-free rate (annualized)")
    volatility: float = Field(..., gt=0, description="Volatility (annualized)")
    option_type: OptionTypeEnum = OptionTypeEnum.call
    dividend: float = Field(0.0, ge=0, description="Continuous dividend yield")
    num_nodes: int = Field(801, ge=51, le=10001, description="Spatial grid nodes")
    num_time_steps: int = Field(800, ge=50, le=10000, description="Time steps")
    concentration: Optional[float] = Field(
        None, gt=0, description="Mesh concentration (default: strike/8)"
    )

    @field_validator("rate")
    @classmethod
    def rate_reasonable(cls, v):
        if v < -0.5 or v > 2.0:
            raise ValueError("rate must be in [-0.5, 2.0]")
        return v

    @field_validator("volatility")
    @classmethod
    def vol_reasonable(cls, v):
        if v > 5.0:
            raise ValueError("volatility must be <= 5.0 (500%)")
        return v


class AmericanRequest(PricingRequest):
    option_type: OptionTypeEnum = OptionTypeEnum.put


class BarrierRequest(PricingRequest):
    barrier_level: float = Field(..., gt=0, description="Barrier level B")
    barrier_direction: BarrierDirectionEnum = BarrierDirectionEnum.down
    barrier_knock: BarrierKnockEnum = BarrierKnockEnum.out
    rebate: float = Field(0.0, ge=0, description="Rebate paid on knock-out")

    @field_validator("barrier_level")
    @classmethod
    def barrier_positive(cls, v):
        if v <= 0:
            raise ValueError("barrier_level must be positive")
        return v


class GreeksRequest(PricingRequest):
    pass


class VolSurfaceParams(BaseModel):
    model: VolModelEnum = VolModelEnum.flat
    beta: float = Field(0.5, description="CEV beta parameter")
    s_ref: Optional[float] = Field(None, gt=0, description="CEV reference spot")
    skew_coeff: float = Field(-0.1, description="Skew coefficient")
    term_slope: float = Field(0.0, description="Term structure slope")


class LocalVolPricingRequest(PricingRequest):
    vol_surface: VolSurfaceParams = Field(
        default_factory=VolSurfaceParams,
        description="Local volatility surface specification",
    )


# ── Response Models ──────────────────────────────────────────────────────


class PricingResponse(BaseModel):
    price: float
    time_steps: int
    spatial_nodes: int


class GreeksResponse(BaseModel):
    price: float
    delta: float
    gamma: float
    theta: float
    vega: float
    rho: float


class BarrierResponse(BaseModel):
    price: float
    time_steps: int
    spatial_nodes: int


class HealthResponse(BaseModel):
    status: str
    version: str
    engine: str


class BatchPricingRequest(BaseModel):
    requests: list[PricingRequest] = Field(
        ..., min_length=1, max_length=100, description="Batch of pricing requests"
    )


class BatchPricingResponse(BaseModel):
    results: list[PricingResponse]
    total_count: int


# ── Market data (yfinance; delayed quotes) ─────────────────────────────


class MarketQuoteResponse(BaseModel):
    symbol: str
    spot: float
    currency: str = "USD"
    name: Optional[str] = None
    as_of: Optional[str] = None
    risk_free_rate: float = Field(0.0425, description="Annualized risk-free rate from Treasury yields")
    dividend_yield: float = Field(0.0, description="Annualized continuous dividend yield")


class MarketExpiriesResponse(BaseModel):
    symbol: str
    expirations: list[str]


class OptionContractRow(BaseModel):
    strike: float
    last_price: Optional[float] = None
    bid: Optional[float] = None
    ask: Optional[float] = None
    implied_volatility: Optional[float] = None
    volume: Optional[int] = None


class MarketChainResponse(BaseModel):
    symbol: str
    expiration: str
    spot: float
    time_to_expiry_years: float
    calls: list[OptionContractRow]
    puts: list[OptionContractRow]
    risk_free_rate: float = Field(0.0425, description="Annualized risk-free rate from Treasury yields")
    dividend_yield: float = Field(0.0, description="Annualized continuous dividend yield")


class MarketVolSurfaceResponse(BaseModel):
    symbol: str
    spot: float
    strikes: list[float]
    expiries: list[float]
    expirations: list[str]
    vols: list[list[Optional[float]]]
    risk_free_rate: float = Field(0.0425, description="Annualized risk-free rate")
