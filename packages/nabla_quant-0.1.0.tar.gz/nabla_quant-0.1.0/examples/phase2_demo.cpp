#include "nabla/nabla.hpp"
#include <iostream>
#include <iomanip>
#include <chrono>
#include <cmath>
#include <vector>

using namespace nabla;

static double norm_cdf(double x) {
    return 0.5 * std::erfc(-x / std::sqrt(2.0));
}

static double bs_call(double S, double K, double T, double r, double sigma, double q = 0.0) {
    double d1 = (std::log(S / K) + (r - q + 0.5 * sigma * sigma) * T) / (sigma * std::sqrt(T));
    double d2 = d1 - sigma * std::sqrt(T);
    return S * std::exp(-q * T) * norm_cdf(d1) - K * std::exp(-r * T) * norm_cdf(d2);
}

static double bs_put(double S, double K, double T, double r, double sigma, double q = 0.0) {
    double d1 = (std::log(S / K) + (r - q + 0.5 * sigma * sigma) * T) / (sigma * std::sqrt(T));
    double d2 = d1 - sigma * std::sqrt(T);
    return K * std::exp(-r * T) * norm_cdf(-d2) - S * std::exp(-q * T) * norm_cdf(-d1);
}

static void print_separator(const char* title) {
    std::cout << "\n" << std::string(70, '=') << "\n"
              << "  " << title << "\n"
              << std::string(70, '=') << "\n";
}

static void demo_european_vs_analytical() {
    struct TestCase {
        double S, K, T, r, sigma, q;
        OptionType type;
        const char* label;
    };

    TestCase cases[] = {
        {100, 100, 1.0, 0.05, 0.20, 0.00, OptionType::Call, "ATM Call"},
        {120, 100, 1.0, 0.05, 0.20, 0.00, OptionType::Call, "ITM Call (S=120)"},
        { 80, 100, 1.0, 0.05, 0.20, 0.00, OptionType::Call, "OTM Call (S=80)"},
        {100, 100, 1.0, 0.05, 0.20, 0.00, OptionType::Put,  "ATM Put"},
        {100, 100, 0.25,0.05, 0.20, 0.00, OptionType::Call, "Short-dated Call (T=0.25)"},
        {100, 100, 1.0, 0.05, 0.20, 0.02, OptionType::Call, "Call w/ dividend (q=2%)"},
        {100, 100, 1.0, 0.05, 0.40, 0.00, OptionType::Call, "High-vol Call (sigma=40%)"},
    };

    std::cout << std::fixed << std::setprecision(4);
    std::cout << std::setw(28) << "Contract"
              << std::setw(12) << "PDE Price"
              << std::setw(12) << "BS Exact"
              << std::setw(12) << "Error"
              << std::setw(12) << "Time(ms)" << "\n";
    std::cout << std::string(76, '-') << "\n";

    for (auto& tc : cases) {
        double s_max = (tc.sigma > 0.3) ? 6.0 * tc.K : 5.0 * tc.K;
        SinhMesh mesh(tc.K, 0.0, s_max, 801, tc.K / 8.0);
        BoundaryConditions bc({tc.K, tc.T, tc.type}, {tc.S, tc.r, tc.sigma, tc.q}, mesh);

        auto t0 = std::chrono::high_resolution_clock::now();
        CrankNicolsonSolver solver(mesh, bc, 400);
        auto result = solver.solve();
        auto t1 = std::chrono::high_resolution_clock::now();
        double ms = std::chrono::duration<double, std::milli>(t1 - t0).count();

        double analytical = (tc.type == OptionType::Call)
            ? bs_call(tc.S, tc.K, tc.T, tc.r, tc.sigma, tc.q)
            : bs_put(tc.S, tc.K, tc.T, tc.r, tc.sigma, tc.q);
        double error = result.price - analytical;

        std::cout << std::setw(28) << tc.label
                  << std::setw(12) << result.price
                  << std::setw(12) << analytical
                  << std::setw(12) << error
                  << std::setw(12) << ms << "\n";
    }
}

static void demo_american_options() {
    struct TestCase {
        double S, K;
        OptionType type;
        const char* label;
    };

    double T = 1.0, r = 0.05, sigma = 0.2;

    TestCase cases[] = {
        {100, 100, OptionType::Put,  "ATM Put"},
        { 80, 100, OptionType::Put,  "ITM Put (S=80)"},
        {120, 100, OptionType::Put,  "OTM Put (S=120)"},
        {100, 100, OptionType::Call, "ATM Call"},
    };

    std::cout << std::fixed << std::setprecision(4);
    std::cout << std::setw(22) << "Contract"
              << std::setw(14) << "European"
              << std::setw(14) << "American"
              << std::setw(14) << "EE Premium"
              << std::setw(12) << "Time(ms)" << "\n";
    std::cout << std::string(76, '-') << "\n";

    for (auto& tc : cases) {
        SinhMesh mesh(tc.K, 0.0, 5.0 * tc.K, 801, tc.K / 8.0);
        MarketParams mkt{tc.S, r, sigma, 0.0};

        ContractParams eu_contract{tc.K, T, tc.type, ExerciseType::European};
        ContractParams am_contract{tc.K, T, tc.type, ExerciseType::American};

        BoundaryConditions eu_bc(eu_contract, mkt, mesh);
        BoundaryConditions am_bc(am_contract, mkt, mesh);

        auto t0 = std::chrono::high_resolution_clock::now();
        double eu_price = CrankNicolsonSolver(mesh, eu_bc, 400).solve().price;
        double am_price = CrankNicolsonSolver(mesh, am_bc, 400).solve().price;
        auto t1 = std::chrono::high_resolution_clock::now();
        double ms = std::chrono::duration<double, std::milli>(t1 - t0).count();

        std::cout << std::setw(22) << tc.label
                  << std::setw(14) << eu_price
                  << std::setw(14) << am_price
                  << std::setw(14) << (am_price - eu_price)
                  << std::setw(12) << ms << "\n";
    }
}

static void demo_local_vol() {
    double S = 100.0, K = 100.0, T = 1.0, r = 0.05;

    struct VolModel {
        const char* name;
        LocalVolSurface surface;
    };

    std::vector<VolModel> models;
    models.push_back({"Flat (sigma=0.20)", LocalVolSurface::flat(0.2)});
    models.push_back({"CEV (beta=0.5)",    LocalVolSurface::cev(0.2, S, 0.5)});
    models.push_back({"CEV (beta=0.2)",    LocalVolSurface::cev(0.2, S, 0.2)});
    models.push_back({"Skew (-10%/logS)",  LocalVolSurface::skew(0.2, K, -0.1, 0.02)});

    std::cout << std::fixed << std::setprecision(4);
    std::cout << std::setw(24) << "Vol Model"
              << std::setw(14) << "Call Price"
              << std::setw(14) << "Put Price"
              << std::setw(14) << "C-P Parity"
              << std::setw(12) << "Time(ms)" << "\n";
    std::cout << std::string(78, '-') << "\n";

    for (auto& vm : models) {
        SinhMesh mesh(K, 0.0, 5.0 * K, 601, K / 8.0);
        MarketParams mkt{S, r, 0.2, 0.0};

        BoundaryConditions call_bc({K, T, OptionType::Call}, mkt, mesh);
        BoundaryConditions put_bc({K, T, OptionType::Put}, mkt, mesh);

        auto t0 = std::chrono::high_resolution_clock::now();
        double call_p = CrankNicolsonSolver(mesh, call_bc, 300, vm.surface).solve().price;
        double put_p  = CrankNicolsonSolver(mesh, put_bc, 300, vm.surface).solve().price;
        auto t1 = std::chrono::high_resolution_clock::now();
        double ms = std::chrono::duration<double, std::milli>(t1 - t0).count();

        double parity = call_p - put_p - (S - K * std::exp(-r * T));

        std::cout << std::setw(24) << vm.name
                  << std::setw(14) << call_p
                  << std::setw(14) << put_p
                  << std::setw(14) << parity
                  << std::setw(12) << ms << "\n";
    }
}

static void demo_performance_benchmark() {
    double S = 100.0, K = 100.0, T = 1.0, r = 0.05, sigma = 0.2;

    struct Config {
        std::size_t N, M;
        const char* label;
    };

    Config configs[] = {
        {  201,  100, "201 x 100  (coarse)"},
        {  401,  200, "401 x 200  (medium)"},
        {  801,  400, "801 x 400  (fine)"},
        { 1601,  800, "1601 x 800 (dense)"},
        { 3201, 1600, "3201 x 1600 (ultra)"},
    };

    std::cout << std::fixed << std::setprecision(6);
    std::cout << std::setw(26) << "Grid (N x M)"
              << std::setw(14) << "Price"
              << std::setw(14) << "Error"
              << std::setw(12) << "Time(ms)"
              << std::setw(14) << "Arena(KB)" << "\n";
    std::cout << std::string(80, '-') << "\n";

    double analytical = bs_call(S, K, T, r, sigma);

    for (auto& cfg : configs) {
        SinhMesh mesh(K, 0.0, 5.0 * K, cfg.N, K / 8.0);
        BoundaryConditions bc({K, T, OptionType::Call}, {S, r, sigma, 0.0}, mesh);

        auto t0 = std::chrono::high_resolution_clock::now();
        CrankNicolsonSolver solver(mesh, bc, cfg.M);
        auto result = solver.solve();
        auto t1 = std::chrono::high_resolution_clock::now();
        double ms = std::chrono::duration<double, std::milli>(t1 - t0).count();

        double error = result.price - analytical;
        double arena_kb = solver.arena_capacity() / 1024.0;

        std::cout << std::setw(26) << cfg.label
                  << std::setw(14) << result.price
                  << std::setw(14) << error
                  << std::setw(12) << std::setprecision(2) << ms
                  << std::setw(14) << std::setprecision(1) << arena_kb << "\n";
        std::cout << std::setprecision(6);
    }
}

int main() {
    std::cout << "NablaQuant - Phase 2: Core Engine & Bare-Metal Optimization\n";
    std::cout << "Crank-Nicolson PDE Solver | Thomas O(N) | Arena Allocator | AVX2 SIMD\n";

    print_separator("1. European Option Pricing vs Black-Scholes Analytical");
    demo_european_vs_analytical();

    print_separator("2. American Options: Early Exercise Premium");
    demo_american_options();

    print_separator("3. Local Volatility Surface Pricing");
    demo_local_vol();

    print_separator("4. Performance Benchmark: Convergence & Throughput");
    demo_performance_benchmark();

    std::cout << "\n" << std::string(70, '=') << "\n"
              << "  Phase 2 complete. Zero-allocation PDE engine operational.\n"
              << std::string(70, '=') << "\n";

    return 0;
}
