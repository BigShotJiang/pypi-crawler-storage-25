#include "nabla/nabla.hpp"
#include <iostream>
#include <iomanip>
#include <cmath>
#include <chrono>

using namespace nabla;

static const double PI = 3.14159265358979323846;

static double norm_cdf(double x) {
    return 0.5 * std::erfc(-x / std::sqrt(2.0));
}

static double norm_pdf(double x) {
    return std::exp(-0.5 * x * x) / std::sqrt(2.0 * PI);
}

struct BSGreeks {
    double price, delta, gamma, vega, rho, theta;
};

static BSGreeks bs_greeks(double S, double K, double T,
                          double r, double sigma, double q, OptionType type) {
    double d1 = (std::log(S / K) + (r - q + 0.5 * sigma * sigma) * T)
              / (sigma * std::sqrt(T));
    double d2 = d1 - sigma * std::sqrt(T);
    double eqT = std::exp(-q * T);
    double erT = std::exp(-r * T);
    BSGreeks g;
    if (type == OptionType::Call) {
        g.price = S * eqT * norm_cdf(d1) - K * erT * norm_cdf(d2);
        g.delta = eqT * norm_cdf(d1);
        g.rho   = K * T * erT * norm_cdf(d2);
        g.theta = -eqT * S * norm_pdf(d1) * sigma / (2.0 * std::sqrt(T))
                  - r * K * erT * norm_cdf(d2) + q * S * eqT * norm_cdf(d1);
    } else {
        g.price = K * erT * norm_cdf(-d2) - S * eqT * norm_cdf(-d1);
        g.delta = -eqT * norm_cdf(-d1);
        g.rho   = -K * T * erT * norm_cdf(-d2);
        g.theta = -eqT * S * norm_pdf(d1) * sigma / (2.0 * std::sqrt(T))
                  + r * K * erT * norm_cdf(-d2) - q * S * eqT * norm_cdf(-d1);
    }
    g.gamma = eqT * norm_pdf(d1) / (S * sigma * std::sqrt(T));
    g.vega  = S * eqT * norm_pdf(d1) * std::sqrt(T);
    return g;
}

static void print_sep(const char* title) {
    std::cout << "\n" << std::string(72, '=') << "\n"
              << "  " << title << "\n"
              << std::string(72, '=') << "\n";
}

static void demo_greeks(OptionType type, double S, double K, double T,
                        double r, double sigma, double q) {
    double s_max = 4.0 * K;
    std::size_t N = 501, Nt = 2000;
    SinhMesh mesh(K, 0, s_max, N, K / 5.0);
    MarketParams mkt = {S, r, sigma, q};
    ContractParams con = {K, T, type};
    BoundaryConditions bc(con, mkt, mesh);

    auto bs = bs_greeks(S, K, T, r, sigma, q, type);

    // AAD Greeks
    auto t0 = std::chrono::high_resolution_clock::now();
    GreeksCalculator calc(mesh, bc, Nt);
    auto res = calc.compute();
    auto t1 = std::chrono::high_resolution_clock::now();
    double aad_ms = std::chrono::duration<double, std::milli>(t1 - t0).count();

    // Bump-and-revalue
    auto t2 = std::chrono::high_resolution_clock::now();
    auto bump = GreeksCalculator::bump_and_revalue(mesh, con, mkt, Nt);
    auto t3 = std::chrono::high_resolution_clock::now();
    double bump_ms = std::chrono::duration<double, std::milli>(t3 - t2).count();

    std::cout << std::fixed << std::setprecision(6);
    std::cout << "  " << to_string(type) << " option: S=" << S
              << ", K=" << K << ", T=" << T
              << ", r=" << r << ", sigma=" << sigma << ", q=" << q << "\n\n";

    std::cout << std::setw(14) << "Greek"
              << std::setw(16) << "Analytical"
              << std::setw(16) << "AAD"
              << std::setw(16) << "Bump&Reval"
              << std::setw(14) << "AAD Error" << "\n";
    std::cout << std::string(76, '-') << "\n";

    auto row = [](const char* name, double analytical, double aad_val, double bump_val) {
        std::cout << std::setw(14) << name
                  << std::setw(16) << analytical
                  << std::setw(16) << aad_val
                  << std::setw(16) << bump_val
                  << std::setw(14) << (aad_val - analytical) << "\n";
    };

    row("Price", bs.price, res.price, res.price);
    row("Delta", bs.delta, res.delta, bump.delta);
    row("Gamma", bs.gamma, res.gamma, bump.gamma);
    row("Theta", bs.theta, res.theta, bump.theta);
    row("Vega", bs.vega, res.vega, bump.vega);
    row("Rho", bs.rho, res.rho, bump.rho);

    std::cout << "\n  Timing: AAD = " << std::setprecision(1) << aad_ms
              << " ms   |   Bump-and-Revalue = " << bump_ms << " ms"
              << "   |   Speedup = " << std::setprecision(2)
              << (bump_ms / aad_ms) << "x\n";
}

int main() {
    std::cout << "NablaQuant -- Phase 3: Sensitivities & Adjoint Algorithmic Differentiation\n";

    print_sep("1. ATM European Call (no dividends)");
    demo_greeks(OptionType::Call, 100, 100, 1.0, 0.05, 0.20, 0.0);

    print_sep("2. ATM European Put (no dividends)");
    demo_greeks(OptionType::Put, 100, 100, 1.0, 0.05, 0.20, 0.0);

    print_sep("3. ITM Call with Continuous Dividend");
    demo_greeks(OptionType::Call, 120, 100, 1.0, 0.05, 0.20, 0.02);

    print_sep("4. OTM Put, High Volatility");
    demo_greeks(OptionType::Put, 80, 100, 0.5, 0.03, 0.40, 0.0);

    print_sep("5. AAD Advantage: O(1) Cost for All Greeks");
    std::cout << "  The adjoint backward sweep computes Vega AND Rho in a single pass\n"
              << "  over the CN time-stepping graph. Cost = O(N_t * N_S), same as ONE\n"
              << "  forward PDE solve, regardless of how many parameters are differentiated.\n\n"
              << "  Bump-and-revalue requires 5 full PDE solves for 5 Greeks:\n"
              << "    2 for Vega (sigma +/- bump)\n"
              << "    2 for Rho  (r +/- bump)\n"
              << "    1 for Theta (T - bump)\n\n"
              << "  AAD replaces this with exactly 1 forward + 1 backward pass.\n";

    std::cout << "\n" << std::string(72, '=') << "\n"
              << "  Phase 3 complete. Ready for Local Vol & Exotics (Phase 4).\n"
              << std::string(72, '=') << "\n";

    return 0;
}
