#include "nabla/nabla.hpp"
#include <iostream>
#include <iomanip>
#include <cmath>
#include <chrono>

using namespace nabla;

static double norm_cdf(double x) {
    return 0.5 * std::erfc(-x / std::sqrt(2.0));
}

static double bs_call(double S, double K, double T, double r, double sigma) {
    double d1 = (std::log(S / K) + (r + 0.5 * sigma * sigma) * T) / (sigma * std::sqrt(T));
    double d2 = d1 - sigma * std::sqrt(T);
    return S * norm_cdf(d1) - K * std::exp(-r * T) * norm_cdf(d2);
}

static double bs_put(double S, double K, double T, double r, double sigma) {
    double d1 = (std::log(S / K) + (r + 0.5 * sigma * sigma) * T) / (sigma * std::sqrt(T));
    double d2 = d1 - sigma * std::sqrt(T);
    return K * std::exp(-r * T) * norm_cdf(-d2) - S * norm_cdf(-d1);
}

static void print_sep(const char* title) {
    std::cout << "\n" << std::string(76, '=') << "\n"
              << "  " << title << "\n"
              << std::string(76, '=') << "\n\n";
}

int main() {
    std::cout << "NablaQuant -- Phase 4: Barrier Options (Knock-Out / Knock-In)\n";
    std::cout << std::fixed;

    // ── 1. Down-and-Out Call ─────────────────────────────────────────
    print_sep("1. Down-and-Out Call: S=100, K=100, B=80, T=1y, r=5%, vol=20%");
    {
        double S = 100, K = 100, B = 80, T = 1.0, r = 0.05, sigma = 0.20;
        SinhMesh mesh(K, 0, 4 * K, 801, K / 8.0);
        MarketParams mkt{S, r, sigma, 0.0};
        ContractParams con{K, T, OptionType::Call};
        BoundaryConditions bc(con, mkt, mesh);
        BarrierParams bp{B, BarrierDirection::Down, BarrierKnock::Out};

        auto t0 = std::chrono::high_resolution_clock::now();
        auto result = BarrierPricer(mesh, bc, bp, 800).solve();
        auto t1 = std::chrono::high_resolution_clock::now();
        double ms = std::chrono::duration<double, std::milli>(t1 - t0).count();

        double vanilla = bs_call(S, K, T, r, sigma);
        double analytical = BarrierPricer::analytical_down_out_call(S, K, B, T, r, sigma);

        std::cout << std::setprecision(4);
        std::cout << "  Vanilla Call       = " << vanilla << "\n"
                  << "  Analytical DOC     = " << analytical << "\n"
                  << "  PDE DOC            = " << result.price << "\n"
                  << "  Error (PDE-Exact)  = " << std::setprecision(6) << (result.price - analytical) << "\n"
                  << "  Time               = " << std::setprecision(1) << ms << " ms\n";
    }

    // ── 2. Up-and-Out Call ───────────────────────────────────────────
    print_sep("2. Up-and-Out Call: S=100, K=100, B=140, T=1y, r=5%, vol=20%");
    {
        double S = 100, K = 100, B = 140, T = 1.0, r = 0.05, sigma = 0.20;
        SinhMesh mesh(K, 0, 5 * K, 801, K / 8.0);
        MarketParams mkt{S, r, sigma, 0.0};
        ContractParams con{K, T, OptionType::Call};
        BoundaryConditions bc(con, mkt, mesh);
        BarrierParams bp{B, BarrierDirection::Up, BarrierKnock::Out};

        auto result = BarrierPricer(mesh, bc, bp, 800).solve();
        double vanilla = bs_call(S, K, T, r, sigma);
        double analytical = BarrierPricer::analytical_up_out_call(S, K, B, T, r, sigma);

        std::cout << std::setprecision(4);
        std::cout << "  Vanilla Call       = " << vanilla << "\n"
                  << "  Analytical UOC     = " << analytical << "\n"
                  << "  PDE UOC            = " << result.price << "\n"
                  << "  Error (PDE-Exact)  = " << std::setprecision(6) << (result.price - analytical) << "\n";
    }

    // ── 3. In-Out Parity Demonstration ───────────────────────────────
    print_sep("3. In-Out Parity: DOC + DIC = Vanilla Call");
    {
        double S = 100, K = 100, B = 80, T = 1.0, r = 0.05, sigma = 0.20;
        SinhMesh mesh(K, 0, 4 * K, 801, K / 8.0);
        MarketParams mkt{S, r, sigma, 0.0};
        ContractParams con{K, T, OptionType::Call};
        BoundaryConditions bc(con, mkt, mesh);

        BarrierParams ko{B, BarrierDirection::Down, BarrierKnock::Out};
        BarrierParams ki{B, BarrierDirection::Down, BarrierKnock::In};

        double doc = BarrierPricer(mesh, bc, ko, 800).solve().price;
        double dic = BarrierPricer(mesh, bc, ki, 800).solve().price;
        double vanilla = bs_call(S, K, T, r, sigma);

        std::cout << std::setprecision(4);
        std::cout << "  Vanilla Call    = " << vanilla << "\n"
                  << "  DOC             = " << doc << "\n"
                  << "  DIC             = " << dic << "\n"
                  << "  DOC + DIC       = " << (doc + dic) << "\n"
                  << "  Parity error    = " << std::setprecision(6) << ((doc + dic) - vanilla) << "\n";
    }

    // ── 4. All 8 Barrier Types ───────────────────────────────────────
    print_sep("4. All 8 Barrier Types: S=100, K=100, T=1y, r=5%, vol=20%");
    {
        double S = 100, K = 100, T = 1.0, r = 0.05, sigma = 0.20;
        double B_down = 80, B_up = 130;

        SinhMesh mesh_dn(K, 0, 4 * K, 801, K / 8.0);
        SinhMesh mesh_up(K, 0, 5 * K, 801, K / 8.0);
        MarketParams mkt{S, r, sigma, 0.0};

        ContractParams call_c{K, T, OptionType::Call};
        ContractParams put_c{K, T, OptionType::Put};
        BoundaryConditions bc_call_dn(call_c, mkt, mesh_dn);
        BoundaryConditions bc_call_up(call_c, mkt, mesh_up);
        BoundaryConditions bc_put_dn(put_c, mkt, mesh_dn);
        BoundaryConditions bc_put_up(put_c, mkt, mesh_up);

        double vanilla_c = bs_call(S, K, T, r, sigma);
        double vanilla_p = bs_put(S, K, T, r, sigma);

        auto price = [](const SinhMesh& m, const BoundaryConditions& bc,
                        BarrierParams bp) {
            return BarrierPricer(m, bc, bp, 800).solve().price;
        };

        BarrierParams doc_p{B_down, BarrierDirection::Down, BarrierKnock::Out};
        BarrierParams dic_p{B_down, BarrierDirection::Down, BarrierKnock::In};
        BarrierParams uoc_p{B_up, BarrierDirection::Up, BarrierKnock::Out};
        BarrierParams uic_p{B_up, BarrierDirection::Up, BarrierKnock::In};

        std::cout << std::setprecision(4);
        std::cout << "  Vanilla Call = " << vanilla_c << "    Vanilla Put = " << vanilla_p << "\n\n";

        std::cout << std::setw(22) << "Type"
                  << std::setw(10) << "Price"
                  << std::setw(12) << "Vanilla"
                  << std::setw(12) << "Reduction" << "\n";
        std::cout << std::string(56, '-') << "\n";

        auto row = [](const char* name, double pde, double van) {
            std::cout << std::setw(22) << name
                      << std::setw(10) << std::setprecision(4) << pde
                      << std::setw(12) << van
                      << std::setw(11) << std::setprecision(1)
                      << ((1.0 - pde / van) * 100.0) << "%" << "\n";
        };

        row("DOC (B=80)",  price(mesh_dn, bc_call_dn, doc_p), vanilla_c);
        row("DIC (B=80)",  price(mesh_dn, bc_call_dn, dic_p), vanilla_c);
        row("UOC (B=130)", price(mesh_up, bc_call_up, uoc_p), vanilla_c);
        row("UIC (B=130)", price(mesh_up, bc_call_up, uic_p), vanilla_c);

        std::cout << "\n";
        row("DOP (B=80)",  price(mesh_dn, bc_put_dn, doc_p), vanilla_p);
        row("DIP (B=80)",  price(mesh_dn, bc_put_dn, dic_p), vanilla_p);
        row("UOP (B=130)", price(mesh_up, bc_put_up, uoc_p), vanilla_p);
        row("UIP (B=130)", price(mesh_up, bc_put_up, uic_p), vanilla_p);
    }

    // ── 5. Local Vol + Barriers ──────────────────────────────────────
    print_sep("5. Barrier Options under Local Volatility (CEV, beta=0.5)");
    {
        double S = 100, K = 100, B = 80, T = 1.0, r = 0.05, sigma = 0.20;
        SinhMesh mesh(K, 0, 4 * K, 801, K / 8.0);
        MarketParams mkt{S, r, sigma, 0.0};
        ContractParams con{K, T, OptionType::Call};
        BoundaryConditions bc(con, mkt, mesh);
        auto vol_cev = LocalVolSurface::cev(sigma, S, 0.5);

        BarrierParams bp{B, BarrierDirection::Down, BarrierKnock::Out};

        double doc_flat = BarrierPricer(mesh, bc, bp, 800).solve().price;
        double doc_cev = BarrierPricer(mesh, bc, bp, 800, vol_cev).solve().price;

        std::cout << std::setprecision(4);
        std::cout << "  DOC (flat vol σ=20%)      = " << doc_flat << "\n"
                  << "  DOC (CEV β=0.5, σ₀=20%)  = " << doc_cev << "\n"
                  << "  Difference                = " << std::setprecision(6)
                  << (doc_cev - doc_flat) << "\n";
    }

    // ── 6. Convergence Table ─────────────────────────────────────────
    print_sep("6. Grid Convergence: DOC(S=100, K=100, B=80)");
    {
        double S = 100, K = 100, B = 80, T = 1.0, r = 0.05, sigma = 0.20;
        double analytical = BarrierPricer::analytical_down_out_call(S, K, B, T, r, sigma);

        struct Cfg { std::size_t N; std::size_t M; };
        Cfg configs[] = {{101, 100}, {201, 200}, {401, 400}, {801, 800}, {1601, 1600}};

        std::cout << std::setw(12) << "Grid (NxM)"
                  << std::setw(12) << "Price"
                  << std::setw(14) << "Error"
                  << std::setw(10) << "Time(ms)" << "\n";
        std::cout << std::string(48, '-') << "\n";

        for (auto& cfg : configs) {
            SinhMesh mesh(K, 0, 4 * K, cfg.N, K / 8.0);
            MarketParams mkt{S, r, sigma, 0.0};
            ContractParams con{K, T, OptionType::Call};
            BoundaryConditions bc(con, mkt, mesh);
            BarrierParams bp{B, BarrierDirection::Down, BarrierKnock::Out};

            auto t0 = std::chrono::high_resolution_clock::now();
            auto result = BarrierPricer(mesh, bc, bp, cfg.M).solve();
            auto t1 = std::chrono::high_resolution_clock::now();
            double ms = std::chrono::duration<double, std::milli>(t1 - t0).count();

            std::cout << std::setw(5) << cfg.N << "x" << std::setw(5) << cfg.M
                      << std::setw(12) << std::setprecision(6) << result.price
                      << std::setw(14) << std::setprecision(8) << (result.price - analytical)
                      << std::setw(9) << std::setprecision(1) << ms << "\n";
        }
        std::cout << "\n  Analytical ref = " << std::setprecision(8) << analytical << "\n";
    }

    std::cout << "\n" << std::string(76, '=') << "\n"
              << "  Phase 4 complete. Barrier options: 4 directions x 2 knock types = 8 types.\n"
              << "  All validated against Rubinstein-Reiner analytical + in-out parity.\n"
              << std::string(76, '=') << "\n";

    return 0;
}
