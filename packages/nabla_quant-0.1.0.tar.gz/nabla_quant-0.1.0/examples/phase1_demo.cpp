#include "nabla/nabla.hpp"
#include <iostream>
#include <iomanip>
#include <cmath>

using namespace nabla;

static void print_separator(const char* title) {
    std::cout << "\n" << std::string(60, '=') << "\n"
              << "  " << title << "\n"
              << std::string(60, '=') << "\n";
}

static void demo_mesh(double K, double s_min, double s_max,
                      std::size_t N, double c) {
    SinhMesh mesh(K, s_min, s_max, N, c);

    std::cout << std::fixed << std::setprecision(4);
    std::cout << "  Strike K       = " << K << "\n"
              << "  Domain         = [" << s_min << ", " << s_max << "]\n"
              << "  Nodes          = " << N << "\n"
              << "  Concentration  = " << c << "\n"
              << "  xi range       = [" << mesh.xi_min() << ", " << mesh.xi_max() << "]\n"
              << "  Min spacing    = " << mesh.min_spacing() << "\n"
              << "  Max spacing    = " << mesh.max_spacing() << "\n"
              << "  Spacing ratio  = " << mesh.spacing_ratio() << "\n"
              << "  Strike index   = " << mesh.strike_index()
              << "  (S = " << mesh.spot_nodes()[mesh.strike_index()] << ")\n";

    // Show a few nodes near the strike
    std::size_t ki = mesh.strike_index();
    std::size_t lo = (ki > 5) ? ki - 5 : 0;
    std::size_t hi = std::min(ki + 6, mesh.size());

    std::cout << "\n  Nodes near strike (K=" << K << "):\n";
    std::cout << std::setw(8) << "Index" << std::setw(14) << "S"
              << std::setw(14) << "ds" << "\n";
    for (std::size_t i = lo; i < hi; ++i) {
        std::cout << std::setw(8) << i
                  << std::setw(14) << mesh.spot_nodes()[i];
        if (i < mesh.size() - 1)
            std::cout << std::setw(14) << mesh.ds()[i];
        std::cout << "\n";
    }
}

static void demo_boundary(OptionType type, double K, double T,
                           double r, double sigma, double q) {
    double s_min = 0.0, s_max = 4.0 * K;
    SinhMesh mesh(K, s_min, s_max, 201, K / 5.0);
    BoundaryConditions bc({K, T, type}, {K, r, sigma, q}, mesh);

    std::cout << std::fixed << std::setprecision(6);
    std::cout << "  " << to_string(type) << " option: K=" << K
              << ", T=" << T << ", r=" << r << ", sigma=" << sigma
              << ", q=" << q << "\n";

    auto v = bc.terminal_condition();
    std::cout << "\n  Terminal condition (payoff) sample:\n";
    std::cout << std::setw(14) << "S" << std::setw(14) << "V(S,T)" << "\n";
    for (std::size_t i = 0; i < mesh.size(); i += mesh.size() / 10) {
        std::cout << std::setw(14) << mesh.spot_nodes()[i]
                  << std::setw(14) << v[i] << "\n";
    }

    std::cout << "\n  Boundary values at different tau:\n";
    std::cout << std::setw(8) << "tau" << std::setw(16) << "Lower(S_min)"
              << std::setw(16) << "Upper(S_max)" << "\n";
    for (double tau : {0.0, 0.25, 0.5, 0.75, 1.0}) {
        std::cout << std::setw(8) << tau
                  << std::setw(16) << bc.lower_boundary(tau)
                  << std::setw(16) << bc.upper_boundary(tau) << "\n";
    }
}

static void demo_concentration_comparison() {
    double K = 100.0;
    std::cout << std::fixed << std::setprecision(4);
    std::cout << std::setw(12) << "c"
              << std::setw(14) << "min_ds"
              << std::setw(14) << "max_ds"
              << std::setw(14) << "ratio" << "\n";

    for (double c : {2.0, 5.0, 10.0, 20.0, 50.0, 100.0, 500.0}) {
        SinhMesh m(K, 0.0, 300.0, 201, c);
        std::cout << std::setw(12) << c
                  << std::setw(14) << m.min_spacing()
                  << std::setw(14) << m.max_spacing()
                  << std::setw(14) << m.spacing_ratio() << "\n";
    }
}

int main() {
    std::cout << "NablaQuant - Phase 1: Mathematical Foundation & Discretization\n";

    print_separator("1. Non-Uniform Sinh Mesh (K=100, c=20, N=201)");
    demo_mesh(100.0, 0.0, 300.0, 201, 20.0);

    print_separator("2. Concentration Parameter Comparison");
    demo_concentration_comparison();

    print_separator("3. Call Option Boundary Conditions");
    demo_boundary(OptionType::Call, 100.0, 1.0, 0.05, 0.20, 0.0);

    print_separator("4. Put Option Boundary Conditions");
    demo_boundary(OptionType::Put, 100.0, 1.0, 0.05, 0.20, 0.0);

    print_separator("5. Call with Continuous Dividend (q=0.02)");
    demo_boundary(OptionType::Call, 100.0, 1.0, 0.05, 0.20, 0.02);

    std::cout << "\n" << std::string(60, '=') << "\n"
              << "  Phase 1 complete. Ready for Crank-Nicolson solver (Phase 2).\n"
              << std::string(60, '=') << "\n";

    return 0;
}
