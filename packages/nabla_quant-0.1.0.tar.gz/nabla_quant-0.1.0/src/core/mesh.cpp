#include "nabla/core/mesh.hpp"
#include <algorithm>
#include <stdexcept>
#include <limits>
#include <cmath>

namespace nabla {

SinhMesh::SinhMesh(double strike, double s_min, double s_max,
                   std::size_t num_nodes, double concentration)
    : strike_(strike), s_min_(s_min), s_max_(s_max),
      num_nodes_(num_nodes), concentration_(concentration),
      xi_min_(0.0), xi_max_(0.0)
{
    validate_inputs();

    xi_min_ = xi_from_s(s_min_);
    xi_max_ = xi_from_s(s_max_);

    xi_nodes_.resize(num_nodes_);
    s_nodes_.resize(num_nodes_);
    ds_.resize(num_nodes_ > 0 ? num_nodes_ - 1 : 0);

    generate();
}

void SinhMesh::validate_inputs() const {
    if (num_nodes_ < 3)
        throw std::invalid_argument("SinhMesh requires at least 3 nodes");
    if (s_min_ < 0.0)
        throw std::invalid_argument("s_min must be non-negative");
    if (s_max_ <= s_min_)
        throw std::invalid_argument("s_max must exceed s_min");
    if (strike_ < s_min_ || strike_ > s_max_)
        throw std::invalid_argument("strike must lie within [s_min, s_max]");
    if (concentration_ <= 0.0)
        throw std::invalid_argument("concentration must be positive");
}

void SinhMesh::generate() {
    const double dxi = (xi_max_ - xi_min_) / static_cast<double>(num_nodes_ - 1);

    for (std::size_t i = 0; i < num_nodes_; ++i) {
        xi_nodes_[i] = xi_min_ + static_cast<double>(i) * dxi;
        s_nodes_[i]  = s_from_xi(xi_nodes_[i]);
    }

    // Pin exact boundary values to eliminate floating-point drift
    s_nodes_.front() = s_min_;
    s_nodes_.back()  = s_max_;

    for (std::size_t i = 0; i < num_nodes_ - 1; ++i) {
        ds_[i] = s_nodes_[i + 1] - s_nodes_[i];
    }
}

// S(ξ) = K + c · sinh(ξ)
double SinhMesh::s_from_xi(double xi) const {
    return strike_ + concentration_ * std::sinh(xi);
}

// ξ(S) = arcsinh((S − K) / c)
double SinhMesh::xi_from_s(double s) const {
    return std::asinh((s - strike_) / concentration_);
}

// dS/dξ = c · cosh(ξ)
double SinhMesh::jacobian(double xi) const {
    return concentration_ * std::cosh(xi);
}

double SinhMesh::min_spacing() const {
    if (ds_.empty()) return 0.0;
    return *std::min_element(ds_.begin(), ds_.end());
}

double SinhMesh::max_spacing() const {
    if (ds_.empty()) return 0.0;
    return *std::max_element(ds_.begin(), ds_.end());
}

double SinhMesh::spacing_ratio() const {
    double mn = min_spacing();
    if (mn < std::numeric_limits<double>::epsilon()) return 0.0;
    return max_spacing() / mn;
}

std::size_t SinhMesh::strike_index() const {
    double best_dist = std::numeric_limits<double>::max();
    std::size_t best = 0;
    for (std::size_t i = 0; i < num_nodes_; ++i) {
        double d = std::fabs(s_nodes_[i] - strike_);
        if (d < best_dist) {
            best_dist = d;
            best = i;
        }
    }
    return best;
}

} // namespace nabla
