#include "nabla/core/greeks.hpp"
#include <algorithm>
#include <cmath>
#include <stdexcept>

namespace nabla {

// ── Constructor ──────────────────────────────────────────────────────

GreeksCalculator::GreeksCalculator(
    const SinhMesh& mesh,
    const BoundaryConditions& bc,
    std::size_t num_time_steps,
    double theta_scheme)
    : mesh_(mesh), bc_(bc),
      num_time_steps_(num_time_steps), theta_scheme_(theta_scheme),
      N_(mesh.size()), M_(N_ - 2),
      dt_(bc.contract().expiry / static_cast<double>(num_time_steps)),
      alpha_(N_), beta_(N_), gamma_coeff_(N_),
      lhs_lower_(M_), lhs_diag_(M_), lhs_upper_(M_),
      rhs_work_(M_),
      thomas_(M_ > 1 ? M_ : 2)
{
    if (N_ < 3)
        throw std::invalid_argument("GreeksCalculator requires >= 3 nodes");
    if (num_time_steps < 1)
        throw std::invalid_argument("GreeksCalculator requires >= 1 time step");

    compute_pde_coefficients();
    build_lhs();
}

// ── PDE Coefficients ─────────────────────────────────────────────────

void GreeksCalculator::compute_pde_coefficients() {
    const auto& S  = mesh_.spot_nodes();
    const auto& ds = mesh_.ds();
    double sigma = bc_.market().volatility;
    double r     = bc_.market().rate;
    double q     = bc_.market().dividend;

    for (std::size_t i = 1; i < N_ - 1; ++i) {
        double Si   = S[i];
        double hm   = ds[i - 1];
        double hp   = ds[i];
        double hsum = hm + hp;
        double D    = 0.5 * sigma * sigma * Si * Si;
        double mu   = (r - q) * Si;

        alpha_[i]      = 2.0 * D / (hm * hsum) - mu * hp / (hm * hsum);
        beta_[i]       = -2.0 * D / (hm * hp) + mu * (hp - hm) / (hm * hp) - r;
        gamma_coeff_[i] = 2.0 * D / (hp * hsum) + mu * hm / (hp * hsum);
    }
}

void GreeksCalculator::build_lhs() {
    for (std::size_t j = 0; j < M_; ++j) {
        std::size_t i = j + 1;
        lhs_lower_[j] = -theta_scheme_ * dt_ * alpha_[i];
        lhs_diag_[j]  = 1.0 - theta_scheme_ * dt_ * beta_[i];
        lhs_upper_[j] = -theta_scheme_ * dt_ * gamma_coeff_[i];
    }
}

void GreeksCalculator::build_rhs_step(
    const std::vector<double>& V, double tau_new) {
    double omt_dt = (1.0 - theta_scheme_) * dt_;

    for (std::size_t j = 0; j < M_; ++j) {
        std::size_t i = j + 1;
        rhs_work_[j] = V[i]
            + omt_dt * (alpha_[i] * V[i-1] + beta_[i] * V[i] + gamma_coeff_[i] * V[i+1]);
    }

    double V0_new = bc_.lower_boundary(tau_new);
    double VN_new = bc_.upper_boundary(tau_new);
    rhs_work_[0]       += theta_scheme_ * dt_ * alpha_[1] * V0_new;
    rhs_work_[M_ - 1]  += theta_scheme_ * dt_ * gamma_coeff_[N_ - 2] * VN_new;
}

void GreeksCalculator::forward_step(
    std::vector<double>& V, double /*tau_old*/, double tau_new) {
    build_rhs_step(V, tau_new);
    thomas_.solve(lhs_lower_.data(), lhs_diag_.data(), lhs_upper_.data(),
                  rhs_work_.data(), M_);
    for (std::size_t j = 0; j < M_; ++j)
        V[j + 1] = rhs_work_[j];
    bc_.apply_boundaries(V, tau_new);
}

// ── compute() - full Greeks computation ──────────────────────────────

GreeksResult GreeksCalculator::compute() {
    // Forward solve
    std::vector<double> V = bc_.terminal_condition();
    for (std::size_t n = 0; n < num_time_steps_; ++n) {
        double tau_old = static_cast<double>(n) * dt_;
        double tau_new = static_cast<double>(n + 1) * dt_;
        forward_step(V, tau_old, tau_new);
    }

    double spot  = bc_.market().spot;
    double sigma = bc_.market().volatility;
    double r     = bc_.market().rate;
    double q     = bc_.market().dividend;
    double price = CrankNicolsonSolver::interpolate(mesh_, V, spot);

    // Direct spatial Greeks from the solved grid
    std::vector<double> delta_surf, gamma_surf;
    compute_delta_surface(mesh_, V, delta_surf);
    compute_gamma_surface(mesh_, V, gamma_surf);

    double delta = interpolate_greek(mesh_, delta_surf, spot);
    double gamma = interpolate_greek(mesh_, gamma_surf, spot);
    double theta = theta_from_pde(price, delta, gamma, spot, sigma, r, q);

    // AAD: forward pass with grid storage, then adjoint backward sweep
    double vega = 0.0, rho_val = 0.0;
    {
        std::vector<std::vector<double>> stored_grids;
        std::vector<double> V_aad;
        forward_with_storage(V_aad, stored_grids);
        adjoint_sweep(stored_grids, spot, vega, rho_val);
    }

    return { price, delta, gamma, theta, vega, rho_val,
             std::move(delta_surf), std::move(gamma_surf) };
}

// ── Direct spatial Greeks ────────────────────────────────────────────

void GreeksCalculator::compute_delta_surface(
    const SinhMesh& mesh,
    const std::vector<double>& grid,
    std::vector<double>& delta) {
    std::size_t N = mesh.size();
    delta.resize(N);
    const auto& ds = mesh.ds();

    // Interior nodes: second-order non-uniform central difference
    //   Δ_i = [h_m² V_{i+1} + (h_p² − h_m²) V_i − h_p² V_{i-1}]
    //        / [h_m · h_p · (h_m + h_p)]
    for (std::size_t i = 1; i < N - 1; ++i) {
        double hm = ds[i - 1];
        double hp = ds[i];
        double denom = hm * hp * (hm + hp);
        delta[i] = (hm * hm * grid[i + 1]
                   + (hp * hp - hm * hm) * grid[i]
                   - hp * hp * grid[i - 1]) / denom;
    }

    // One-sided differences at boundaries (second-order forward/backward)
    if (N >= 3) {
        double h0 = ds[0], h1 = ds[1];
        delta[0] = (-(2.0 * h0 + h1) * grid[0]
                    + (h0 + h1) * (h0 + h1) * grid[1] / (h0 * (h0 + h1))
                    - h0 * grid[2] / (h1 * (h0 + h1)));
        // Simplify: use standard 3-point forward at left
        delta[0] = (-grid[2] * h0 * h0 / h1
                    + grid[1] * (h0 + h1) * (h0 + h1) / h1
                    - grid[0] * (2.0 * h0 + h1)) / (h0 * (h0 + h1));

        double hN2 = ds[N - 3], hN1 = ds[N - 2];
        delta[N - 1] = (grid[N - 3] * hN1 * hN1 / hN2
                        - grid[N - 2] * (hN2 + hN1) * (hN2 + hN1) / hN2
                        + grid[N - 1] * (2.0 * hN1 + hN2)) / (hN1 * (hN2 + hN1));
    }
}

void GreeksCalculator::compute_gamma_surface(
    const SinhMesh& mesh,
    const std::vector<double>& grid,
    std::vector<double>& gamma) {
    std::size_t N = mesh.size();
    gamma.resize(N);
    const auto& ds = mesh.ds();

    // Interior: standard non-uniform second derivative
    //   Γ_i = 2 / (h_m + h_p) · [(V_{i+1} − V_i)/h_p − (V_i − V_{i-1})/h_m]
    for (std::size_t i = 1; i < N - 1; ++i) {
        double hm = ds[i - 1];
        double hp = ds[i];
        gamma[i] = 2.0 / (hm + hp)
                 * ((grid[i + 1] - grid[i]) / hp - (grid[i] - grid[i - 1]) / hm);
    }

    // Boundaries: linearity (∂²V/∂S² ≈ 0) is typical for deep ITM/OTM
    gamma[0]     = 0.0;
    gamma[N - 1] = 0.0;
}

double GreeksCalculator::interpolate_greek(
    const SinhMesh& mesh,
    const std::vector<double>& surface,
    double spot) {
    return CrankNicolsonSolver::interpolate(mesh, surface, spot);
}

/// Theta via the Black-Scholes PDE identity:
///   Θ = rV − (r−q)S·Δ − ½σ²S²·Γ
double GreeksCalculator::theta_from_pde(
    double V, double delta, double gamma,
    double S, double sigma, double r, double q) {
    return r * V - (r - q) * S * delta - 0.5 * sigma * sigma * S * S * gamma;
}

BumpGreeks GreeksCalculator::bump_and_revalue(
    const SinhMesh& mesh,
    const ContractParams& contract,
    const MarketParams& market,
    std::size_t num_time_steps,
    double theta_scheme,
    double ds_bump,
    double dsigma_bump,
    double dr_bump,
    double dt_bump) {

    // Helper: run a full PDE solve and return the interpolated price
    auto price_fn = [&](const ContractParams& c, const MarketParams& m) -> double {
        BoundaryConditions bc(c, m, mesh);
        CrankNicolsonSolver solver(mesh, bc, num_time_steps, theta_scheme);
        return solver.solve().price;
    };

    // Base price and grid (reuse grid for Delta/Gamma via interpolation)
    BoundaryConditions base_bc(contract, market, mesh);
    CrankNicolsonSolver base_solver(mesh, base_bc, num_time_steps, theta_scheme);
    auto base_result = base_solver.solve();
    double base_price = base_result.price;

    // Delta & Gamma: central differences via grid interpolation (no re-solve)
    double v_up = CrankNicolsonSolver::interpolate(mesh, base_result.grid,
                                                    market.spot + ds_bump);
    double v_dn = CrankNicolsonSolver::interpolate(mesh, base_result.grid,
                                                    market.spot - ds_bump);
    double delta = (v_up - v_dn) / (2.0 * ds_bump);
    double gamma = (v_up - 2.0 * base_price + v_dn) / (ds_bump * ds_bump);

    // Vega: central difference in σ (requires 2 full re-solves)
    MarketParams mkt_sig_up = market;
    mkt_sig_up.volatility += dsigma_bump;
    MarketParams mkt_sig_dn = market;
    mkt_sig_dn.volatility -= dsigma_bump;
    double vega = (price_fn(contract, mkt_sig_up) - price_fn(contract, mkt_sig_dn))
                / (2.0 * dsigma_bump);

    // Rho: central difference in r (requires 2 full re-solves)
    MarketParams mkt_r_up = market;
    mkt_r_up.rate += dr_bump;
    MarketParams mkt_r_dn = market;
    mkt_r_dn.rate -= dr_bump;
    double rho = (price_fn(contract, mkt_r_up) - price_fn(contract, mkt_r_dn))
               / (2.0 * dr_bump);

    // Theta: forward difference in T (requires 1 re-solve)
    ContractParams shorter = contract;
    shorter.expiry = contract.expiry - dt_bump;
    double theta = (price_fn(shorter, market) - base_price) / dt_bump;

    return { delta, gamma, vega, rho, theta };
}

// ── AAD: Forward pass storing intermediate grids ─────────────────────

void GreeksCalculator::forward_with_storage(
    std::vector<double>& V_final,
    std::vector<std::vector<double>>& stored_grids) {
    stored_grids.resize(num_time_steps_ + 1);
    V_final = bc_.terminal_condition();
    stored_grids[0] = V_final;

    for (std::size_t n = 0; n < num_time_steps_; ++n) {
        double tau_old = static_cast<double>(n) * dt_;
        double tau_new = static_cast<double>(n + 1) * dt_;
        forward_step(V_final, tau_old, tau_new);
        stored_grids[n + 1] = V_final;
    }
}

// ── AAD: Adjoint backward sweep ──────────────────────────────────────
//
// At each forward step n, the map V^{n+1} = A^{-1}(B V^n + b_n) gives:
//
// Given λ = adjoint of V^{n+1} (interior):
//   μ = A^{-T} λ              (adjoint Thomas: swap lower ↔ upper)
//   λ_new = B^T μ             (adjoint of explicit part)
//   vega += μ^T · dt · (∂L/∂σ) · W    where W = (1-θ)V^n + θV^{n+1}
//   rho  += μ^T · dt · (∂L/∂r) · W    + boundary sensitivity terms

void GreeksCalculator::adjoint_sweep(
    const std::vector<std::vector<double>>& stored_grids,
    double spot,
    double& vega_out, double& rho_out) {

    vega_out = 0.0;
    rho_out  = 0.0;

    // Interpolation adjoint: ∂price/∂V at the final grid
    const auto& S = mesh_.spot_nodes();
    // Find interpolation bracket
    std::size_t idx = 0;
    {
        auto it = std::lower_bound(S.begin(), S.end(), spot);
        idx = static_cast<std::size_t>(it - S.begin());
        if (idx == 0) idx = 1;
        if (idx >= N_) idx = N_ - 1;
    }
    double S_lo = S[idx - 1], S_hi = S[idx];
    double w = (spot - S_lo) / (S_hi - S_lo);

    // λ = adjoint of interior V (size M_)
    std::vector<double> lambda(M_, 0.0);
    if (idx - 1 >= 1 && idx - 1 <= N_ - 2)
        lambda[(idx - 1) - 1] += (1.0 - w);
    if (idx >= 1 && idx <= N_ - 2)
        lambda[idx - 1] += w;

    // Pre-compute parameter sensitivity coefficients
    std::vector<double> da_dsig(N_), db_dsig(N_), dg_dsig(N_);
    std::vector<double> da_dr(N_), db_dr(N_), dg_dr(N_);
    compute_dcoeff_dsigma(da_dsig, db_dsig, dg_dsig);
    compute_dcoeff_dr(da_dr, db_dr, dg_dr);

    // A^T tridiagonal arrays: swap lower ↔ upper of A
    std::vector<double> adj_lower(M_), adj_upper(M_);
    for (std::size_t j = 0; j < M_; ++j) {
        adj_lower[j] = (j > 0) ? lhs_upper_[j - 1] : 0.0;
        adj_upper[j] = (j < M_ - 1) ? lhs_lower_[j + 1] : 0.0;
    }

    double omt = 1.0 - theta_scheme_;

    std::vector<double> mu(M_);
    std::vector<double> lambda_new(M_);

    // Backward loop over time steps
    for (std::size_t n = num_time_steps_; n > 0; --n) {
        const auto& V_old = stored_grids[n - 1];   // V^{n-1}
        const auto& V_new = stored_grids[n];        // V^n

        // Step 1: Solve A^T μ = λ  (adjoint Thomas solve)
        std::copy(lambda.begin(), lambda.end(), mu.begin());
        thomas_.solve(adj_lower.data(), lhs_diag_.data(), adj_upper.data(),
                      mu.data(), M_);

        // Step 2: Accumulate parameter sensitivities
        // W_i = (1-θ)V^{n-1}_i + θ V^n_i  for the CN-weighted average
        double tau_old = static_cast<double>(n - 1) * dt_;
        double tau_new = static_cast<double>(n) * dt_;

        for (std::size_t j = 0; j < M_; ++j) {
            std::size_t i = j + 1;
            double W_im1 = omt * V_old[i - 1] + theta_scheme_ * V_new[i - 1];
            double W_i   = omt * V_old[i]     + theta_scheme_ * V_new[i];
            double W_ip1 = omt * V_old[i + 1] + theta_scheme_ * V_new[i + 1];

            // Vega source: dt * μ[j] * (∂L/∂σ · W)_i
            double dLsig_W = da_dsig[i] * W_im1 + db_dsig[i] * W_i + dg_dsig[i] * W_ip1;
            vega_out += mu[j] * dt_ * dLsig_W;

            // Rho source (operator part): dt * μ[j] * (∂L/∂r · W)_i
            double dLr_W = da_dr[i] * W_im1 + db_dr[i] * W_i + dg_dr[i] * W_ip1;
            rho_out += mu[j] * dt_ * dLr_W;
        }

        // Rho: boundary value sensitivity
        // ∂W_0/∂r = (1-θ)∂lower(tau_old)/∂r + θ∂lower(tau_new)/∂r
        double dW0_dr = omt * dlower_dr(tau_old) + theta_scheme_ * dlower_dr(tau_new);
        double dWN_dr = omt * dupper_dr(tau_old) + theta_scheme_ * dupper_dr(tau_new);
        rho_out += mu[0] * dt_ * alpha_[1] * dW0_dr;
        rho_out += mu[M_ - 1] * dt_ * gamma_coeff_[N_ - 2] * dWN_dr;

        // Step 3: Propagate adjoint backward: λ = B^T μ
        // B^T[j,j] = 1 + omt*dt*beta[j+1]
        // B^T[j,j-1] = omt*dt*gamma[j]   (j >= 1)
        // B^T[j,j+1] = omt*dt*alpha[j+2] (j <= M-2)
        double omt_dt = omt * dt_;
        for (std::size_t j = 0; j < M_; ++j) {
            std::size_t i = j + 1;
            lambda_new[j] = (1.0 + omt_dt * beta_[i]) * mu[j];
            if (j > 0)
                lambda_new[j] += omt_dt * gamma_coeff_[j] * mu[j - 1];
            if (j < M_ - 1)
                lambda_new[j] += omt_dt * alpha_[j + 2] * mu[j + 1];
        }
        std::swap(lambda, lambda_new);
    }
}

// ── Parameter sensitivity coefficients ───────────────────────────────

void GreeksCalculator::compute_dcoeff_dsigma(
    std::vector<double>& dalpha,
    std::vector<double>& dbeta,
    std::vector<double>& dgamma) const {
    dalpha.assign(N_, 0.0);
    dbeta.assign(N_, 0.0);
    dgamma.assign(N_, 0.0);

    const auto& S  = mesh_.spot_nodes();
    const auto& ds = mesh_.ds();
    double sigma = bc_.market().volatility;

    // ∂(½σ²S²)/∂σ = σS²   (only the diffusion term depends on σ)
    for (std::size_t i = 1; i < N_ - 1; ++i) {
        double Si   = S[i];
        double hm   = ds[i - 1];
        double hp   = ds[i];
        double hsum = hm + hp;
        double dD   = sigma * Si * Si;   // ∂D/∂σ = σS²

        dalpha[i] = 2.0 * dD / (hm * hsum);
        dbeta[i]  = -2.0 * dD / (hm * hp);
        dgamma[i] = 2.0 * dD / (hp * hsum);
    }
}

void GreeksCalculator::compute_dcoeff_dr(
    std::vector<double>& dalpha,
    std::vector<double>& dbeta,
    std::vector<double>& dgamma) const {
    dalpha.assign(N_, 0.0);
    dbeta.assign(N_, 0.0);
    dgamma.assign(N_, 0.0);

    const auto& S  = mesh_.spot_nodes();
    const auto& ds = mesh_.ds();

    // ∂μ/∂r = S_i  (drift coefficient ∂((r-q)S)/∂r = S)
    // ∂(-r)/∂r = -1  (discount term)
    for (std::size_t i = 1; i < N_ - 1; ++i) {
        double Si   = S[i];
        double hm   = ds[i - 1];
        double hp   = ds[i];
        double hsum = hm + hp;

        dalpha[i] = -Si * hp / (hm * hsum);
        dbeta[i]  = Si * (hp - hm) / (hm * hp) - 1.0;
        dgamma[i] = Si * hm / (hp * hsum);
    }
}

// ── Boundary sensitivity to r ────────────────────────────────────────

double GreeksCalculator::dlower_dr(double tau) const {
    double K = bc_.contract().strike;
    double r = bc_.market().rate;
    switch (bc_.contract().type) {
        case OptionType::Call:
            return 0.0;
        case OptionType::Put:
            return -K * tau * std::exp(-r * tau);
    }
    return 0.0;
}

double GreeksCalculator::dupper_dr(double tau) const {
    double K = bc_.contract().strike;
    double r = bc_.market().rate;
    switch (bc_.contract().type) {
        case OptionType::Call:
            return K * tau * std::exp(-r * tau);
        case OptionType::Put:
            return 0.0;
    }
    return 0.0;
}

} // namespace nabla
