#include "nabla/core/simd.hpp"

namespace nabla {
namespace simd {

// ── Scalar fallbacks ─────────────────────────────────────────────────

void build_rhs_scalar(
    double* __restrict__ rhs,
    const double* __restrict__ alpha,
    const double* __restrict__ beta,
    const double* __restrict__ gamma,
    const double* __restrict__ V,
    std::size_t M,
    double omt_dt)
{
    for (std::size_t j = 0; j < M; ++j) {
        const std::size_t i = j + 1;
        rhs[j] = omt_dt * alpha[i] * V[i - 1]
               + (1.0 + omt_dt * beta[i]) * V[i]
               + omt_dt * gamma[i] * V[i + 1];
    }
}

void compute_coefficients_scalar(
    double* __restrict__ alpha,
    double* __restrict__ beta,
    double* __restrict__ gamma,
    const double* __restrict__ S,
    const double* __restrict__ ds,
    std::size_t N,
    double half_sigma_sq,
    double drift_coeff,
    double r)
{
    for (std::size_t i = 1; i < N - 1; ++i) {
        const double Si = S[i];
        const double hm = ds[i - 1];
        const double hp = ds[i];
        const double hsum = hm + hp;

        const double D = half_sigma_sq * Si * Si;
        const double mu = drift_coeff * Si;

        alpha[i] = (2.0 * D) / (hm * hsum) - (mu * hp) / (hm * hsum);
        beta[i]  = -(2.0 * D) / (hm * hp) + mu * (hp - hm) / (hm * hp) - r;
        gamma[i] = (2.0 * D) / (hp * hsum) + (mu * hm) / (hp * hsum);
    }
}

// ── AVX2 implementations ─────────────────────────────────────────────

#if NABLA_HAS_AVX2

void build_rhs_avx2(
    double* __restrict__ rhs,
    const double* __restrict__ alpha,
    const double* __restrict__ beta,
    const double* __restrict__ gamma,
    const double* __restrict__ V,
    std::size_t M,
    double omt_dt)
{
    const __m256d v_omt_dt = _mm256_set1_pd(omt_dt);
    const __m256d v_one    = _mm256_set1_pd(1.0);

    std::size_t j = 0;
    const std::size_t M4 = M & ~3ULL;  // round down to multiple of 4

    for (; j < M4; j += 4) {
        const std::size_t i = j + 1;

        // Load alpha[i..i+3], beta[i..i+3], gamma[i..i+3]
        __m256d v_alpha = _mm256_loadu_pd(&alpha[i]);
        __m256d v_beta  = _mm256_loadu_pd(&beta[i]);
        __m256d v_gamma = _mm256_loadu_pd(&gamma[i]);

        // Load V[i-1..i+2], V[i..i+3], V[i+1..i+4]
        __m256d v_Vm = _mm256_loadu_pd(&V[i - 1]);
        __m256d v_Vi = _mm256_loadu_pd(&V[i]);
        __m256d v_Vp = _mm256_loadu_pd(&V[i + 1]);

        // term1 = omt_dt * alpha * V[i-1]
        __m256d term1 = _mm256_mul_pd(v_omt_dt, _mm256_mul_pd(v_alpha, v_Vm));

        // term2 = (1 + omt_dt * beta) * V[i]
        __m256d coeff2 = _mm256_fmadd_pd(v_omt_dt, v_beta, v_one);
        __m256d term2 = _mm256_mul_pd(coeff2, v_Vi);

        // term3 = omt_dt * gamma * V[i+1]
        __m256d term3 = _mm256_mul_pd(v_omt_dt, _mm256_mul_pd(v_gamma, v_Vp));

        // rhs = term1 + term2 + term3
        __m256d result = _mm256_add_pd(_mm256_add_pd(term1, term2), term3);
        _mm256_storeu_pd(&rhs[j], result);
    }

    // Scalar tail
    for (; j < M; ++j) {
        const std::size_t i = j + 1;
        rhs[j] = omt_dt * alpha[i] * V[i - 1]
               + (1.0 + omt_dt * beta[i]) * V[i]
               + omt_dt * gamma[i] * V[i + 1];
    }
}

void compute_coefficients_avx2(
    double* __restrict__ alpha,
    double* __restrict__ beta,
    double* __restrict__ gamma,
    const double* __restrict__ S,
    const double* __restrict__ ds,
    std::size_t N,
    double half_sigma_sq,
    double drift_coeff,
    double r)
{
    const __m256d v_half_sig2 = _mm256_set1_pd(half_sigma_sq);
    const __m256d v_drift     = _mm256_set1_pd(drift_coeff);
    const __m256d v_r         = _mm256_set1_pd(r);
    const __m256d v_two       = _mm256_set1_pd(2.0);
    const __m256d v_neg_two   = _mm256_set1_pd(-2.0);

    const std::size_t interior = N - 2;
    std::size_t j = 0;
    const std::size_t j4 = interior & ~3ULL;

    for (; j < j4; j += 4) {
        const std::size_t i = j + 1;

        __m256d v_Si = _mm256_loadu_pd(&S[i]);
        __m256d v_hm = _mm256_loadu_pd(&ds[i - 1]);  // h_minus = ds[i-1]
        __m256d v_hp = _mm256_loadu_pd(&ds[i]);       // h_plus  = ds[i]

        __m256d v_hsum = _mm256_add_pd(v_hm, v_hp);
        __m256d v_D  = _mm256_mul_pd(v_half_sig2, _mm256_mul_pd(v_Si, v_Si));
        __m256d v_mu = _mm256_mul_pd(v_drift, v_Si);

        // alpha = (2D)/(hm*hsum) - (mu*hp)/(hm*hsum) = (2D - mu*hp)/(hm*hsum)
        __m256d v_hm_hsum = _mm256_mul_pd(v_hm, v_hsum);
        __m256d v_num_a = _mm256_sub_pd(
            _mm256_mul_pd(v_two, v_D),
            _mm256_mul_pd(v_mu, v_hp));
        _mm256_storeu_pd(&alpha[i], _mm256_div_pd(v_num_a, v_hm_hsum));

        // gamma = (2D + mu*hm)/(hp*hsum)
        __m256d v_hp_hsum = _mm256_mul_pd(v_hp, v_hsum);
        __m256d v_num_g = _mm256_add_pd(
            _mm256_mul_pd(v_two, v_D),
            _mm256_mul_pd(v_mu, v_hm));
        _mm256_storeu_pd(&gamma[i], _mm256_div_pd(v_num_g, v_hp_hsum));

        // beta = -2D/(hm*hp) + mu*(hp-hm)/(hm*hp) - r
        __m256d v_hm_hp = _mm256_mul_pd(v_hm, v_hp);
        __m256d v_beta_val = _mm256_div_pd(
            _mm256_mul_pd(v_neg_two, v_D), v_hm_hp);
        __m256d v_drift_term = _mm256_div_pd(
            _mm256_mul_pd(v_mu, _mm256_sub_pd(v_hp, v_hm)),
            v_hm_hp);
        v_beta_val = _mm256_sub_pd(
            _mm256_add_pd(v_beta_val, v_drift_term), v_r);
        _mm256_storeu_pd(&beta[i], v_beta_val);
    }

    // Scalar tail
    for (; j < interior; ++j) {
        const std::size_t i = j + 1;
        const double Si = S[i];
        const double hm = ds[i - 1];
        const double hp = ds[i];
        const double hsum = hm + hp;

        const double D = half_sigma_sq * Si * Si;
        const double mu = drift_coeff * Si;

        alpha[i] = (2.0 * D) / (hm * hsum) - (mu * hp) / (hm * hsum);
        beta[i]  = -(2.0 * D) / (hm * hp) + mu * (hp - hm) / (hm * hp) - r;
        gamma[i] = (2.0 * D) / (hp * hsum) + (mu * hm) / (hp * hsum);
    }
}

#else

// On non-AVX2 platforms, the AVX2 entry points just call scalar
void build_rhs_avx2(
    double* rhs, const double* alpha, const double* beta,
    const double* gamma, const double* V, std::size_t M,
    double omt_dt)
{
    build_rhs_scalar(rhs, alpha, beta, gamma, V, M, omt_dt);
}

void compute_coefficients_avx2(
    double* alpha, double* beta, double* gamma,
    const double* S, const double* ds, std::size_t N,
    double half_sigma_sq, double drift_coeff, double r)
{
    compute_coefficients_scalar(alpha, beta, gamma, S, ds, N,
                                half_sigma_sq, drift_coeff, r);
}

#endif // NABLA_HAS_AVX2

} // namespace simd
} // namespace nabla
