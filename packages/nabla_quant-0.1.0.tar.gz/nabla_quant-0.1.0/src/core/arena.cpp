#include "nabla/core/arena.hpp"

#ifdef _WIN32
#include <malloc.h>
#else
#include <cstdlib>
#endif

namespace nabla {

static void* aligned_alloc_impl(std::size_t alignment, std::size_t size) {
#ifdef _WIN32
    return _aligned_malloc(size, alignment);
#else
    void* ptr = nullptr;
    if (posix_memalign(&ptr, alignment, size) != 0)
        return nullptr;
    return ptr;
#endif
}

static void aligned_free_impl(void* ptr) {
#ifdef _WIN32
    _aligned_free(ptr);
#else
    std::free(ptr);
#endif
}

Arena::Arena(std::size_t capacity_bytes)
    : buffer_(nullptr), capacity_(capacity_bytes), offset_(0)
{
    if (capacity_bytes == 0)
        throw std::invalid_argument("Arena capacity must be > 0");

    buffer_ = static_cast<std::uint8_t*>(
        aligned_alloc_impl(DEFAULT_ALIGNMENT, capacity_bytes));
    if (!buffer_)
        throw std::bad_alloc();
}

Arena::~Arena() {
    if (buffer_)
        aligned_free_impl(buffer_);
}

Arena::Arena(Arena&& other) noexcept
    : buffer_(other.buffer_), capacity_(other.capacity_), offset_(other.offset_)
{
    other.buffer_ = nullptr;
    other.capacity_ = 0;
    other.offset_ = 0;
}

Arena& Arena::operator=(Arena&& other) noexcept {
    if (this != &other) {
        if (buffer_) aligned_free_impl(buffer_);
        buffer_ = other.buffer_;
        capacity_ = other.capacity_;
        offset_ = other.offset_;
        other.buffer_ = nullptr;
        other.capacity_ = 0;
        other.offset_ = 0;
    }
    return *this;
}

void* Arena::alloc_raw(std::size_t bytes, std::size_t alignment) {
    // Compute the absolute address at the current offset, then align it
    auto base_addr = reinterpret_cast<std::uintptr_t>(buffer_) + offset_;
    auto aligned_addr = (base_addr + alignment - 1) & ~(alignment - 1);
    auto aligned_offset = static_cast<std::size_t>(aligned_addr -
                          reinterpret_cast<std::uintptr_t>(buffer_));

    if (aligned_offset + bytes > capacity_)
        throw std::bad_alloc();

    void* ptr = buffer_ + aligned_offset;
    offset_ = aligned_offset + bytes;
    return ptr;
}

} // namespace nabla
