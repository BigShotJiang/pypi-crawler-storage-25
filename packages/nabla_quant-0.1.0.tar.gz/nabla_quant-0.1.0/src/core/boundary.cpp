#include "nabla/core/boundary.hpp"
#include <algorithm>
#include <cmath>
#include <stdexcept>

namespace nabla {

BoundaryConditions::BoundaryConditions(
    const ContractParams& contract,
    const MarketParams& market,
    const SinhMesh& mesh)
    : contract_(contract), market_(market), mesh_(mesh),
      lower_type_(BoundaryType::Dirichlet),
      upper_type_(BoundaryType::Dirichlet)
{
    if (contract_.strike <= 0.0)
        throw std::invalid_argument("strike must be positive");
    if (contract_.expiry <= 0.0)
        throw std::invalid_argument("expiry must be positive");
}

double BoundaryConditions::payoff(double spot) const {
    switch (contract_.type) {
        case OptionType::Call:
            return std::max(spot - contract_.strike, 0.0);
        case OptionType::Put:
            return std::max(contract_.strike - spot, 0.0);
    }
    return 0.0;
}

std::vector<double> BoundaryConditions::terminal_condition() const {
    const auto& nodes = mesh_.spot_nodes();
    std::vector<double> v(nodes.size());
    for (std::size_t i = 0; i < nodes.size(); ++i)
        v[i] = payoff(nodes[i]);
    return v;
}

// Lower boundary: S → S_min ≈ 0
//   Call: V → 0
//   Put:  V → K·e^{−rτ} − S_min·e^{−qτ}   (intrinsic discounted value)
double BoundaryConditions::lower_boundary(double tau) const {
    const double r     = market_.rate;
    const double q     = market_.dividend;
    const double K     = contract_.strike;
    const double S_min = mesh_.s_min();

    switch (contract_.type) {
        case OptionType::Call:
            return 0.0;
        case OptionType::Put:
            return K * std::exp(-r * tau) - S_min * std::exp(-q * tau);
    }
    return 0.0;
}

// Upper boundary: S → S_max ≫ K
//   Call: V → S_max·e^{−qτ} − K·e^{−rτ}
//   Put:  V → 0
double BoundaryConditions::upper_boundary(double tau) const {
    const double r     = market_.rate;
    const double q     = market_.dividend;
    const double K     = contract_.strike;
    const double S_max = mesh_.s_max();

    switch (contract_.type) {
        case OptionType::Call:
            return S_max * std::exp(-q * tau) - K * std::exp(-r * tau);
        case OptionType::Put:
            return 0.0;
    }
    return 0.0;
}

void BoundaryConditions::apply_boundaries(std::vector<double>& grid, double tau) const {
    if (grid.size() != mesh_.size())
        throw std::invalid_argument("grid size must match mesh size");
    grid.front() = lower_boundary(tau);
    grid.back()  = upper_boundary(tau);
}

} // namespace nabla
