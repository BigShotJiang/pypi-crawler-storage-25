#include "nabla/core/solver.hpp"
#include <algorithm>
#include <cmath>
#include <stdexcept>

namespace nabla {

static std::size_t compute_arena_size(std::size_t N) {
    // alpha, beta, gamma (N each), lhs_lower/diag/upper/rhs_vec (N-2 each),
    // sigma_vec (N), payoff_vec (N), plus alignment padding (64 bytes per array)
    return (5 * N + 4 * (N - 2)) * sizeof(double) + 9 * 64;
}

void CrankNicolsonSolver::init_workspace() {
    if (N_ < 3)
        throw std::invalid_argument("solver requires at least 3 spatial nodes");
    if (num_time_steps_ < 1)
        throw std::invalid_argument("solver requires at least 1 time step");
    if (theta_ < 0.0 || theta_ > 1.0)
        throw std::invalid_argument("theta must be in [0, 1]");

    alpha_     = arena_.alloc<double>(N_);
    beta_      = arena_.alloc<double>(N_);
    gamma_     = arena_.alloc<double>(N_);
    lhs_lower_ = arena_.alloc<double>(N_ - 2);
    lhs_diag_  = arena_.alloc<double>(N_ - 2);
    lhs_upper_ = arena_.alloc<double>(N_ - 2);
    rhs_vec_   = arena_.alloc<double>(N_ - 2);
    sigma_vec_ = arena_.alloc<double>(N_);
    payoff_vec_ = arena_.alloc<double>(N_);

    is_american_ = bc_.contract().exercise == ExerciseType::American;

    // Pre-compute the payoff vector for American exercise projection
    if (is_american_) {
        const auto& nodes = mesh_.spot_nodes();
        for (std::size_t i = 0; i < N_; ++i)
            payoff_vec_[i] = bc_.payoff(nodes[i]);
    }
}

CrankNicolsonSolver::CrankNicolsonSolver(
    const SinhMesh& mesh,
    const BoundaryConditions& bc,
    std::size_t num_time_steps,
    double theta)
    : mesh_(mesh), bc_(bc), num_time_steps_(num_time_steps), theta_(theta),
      N_(mesh.size()),
      dt_(bc.contract().expiry / static_cast<double>(num_time_steps)),
      arena_(compute_arena_size(mesh.size())),
      alpha_(nullptr), beta_(nullptr), gamma_(nullptr),
      lhs_lower_(nullptr), lhs_diag_(nullptr),
      lhs_upper_(nullptr), rhs_vec_(nullptr), sigma_vec_(nullptr),
      thomas_(N_ - 2 > 1 ? N_ - 2 : 2),
      vol_surface_(nullptr)
{
    init_workspace();

    const auto& mkt = bc_.market();
    compute_pde_coefficients(mkt.volatility, mkt.rate, mkt.dividend);
    build_lhs();
}

CrankNicolsonSolver::CrankNicolsonSolver(
    const SinhMesh& mesh,
    const BoundaryConditions& bc,
    std::size_t num_time_steps,
    const LocalVolSurface& vol_surface,
    double theta)
    : mesh_(mesh), bc_(bc), num_time_steps_(num_time_steps), theta_(theta),
      N_(mesh.size()),
      dt_(bc.contract().expiry / static_cast<double>(num_time_steps)),
      arena_(compute_arena_size(mesh.size())),
      alpha_(nullptr), beta_(nullptr), gamma_(nullptr),
      lhs_lower_(nullptr), lhs_diag_(nullptr),
      lhs_upper_(nullptr), rhs_vec_(nullptr), sigma_vec_(nullptr),
      thomas_(N_ - 2 > 1 ? N_ - 2 : 2),
      vol_surface_(&vol_surface)
{
    init_workspace();

    if (vol_surface.is_constant()) {
        compute_pde_coefficients(vol_surface.constant_vol(),
                                 bc_.market().rate, bc_.market().dividend);
        build_lhs();
        vol_surface_ = nullptr;  // treat as constant from here on
    }
    // For non-constant local vol, coefficients are recomputed each step
}

void CrankNicolsonSolver::compute_pde_coefficients(
    double sigma, double r, double q) {
    simd::compute_coefficients(
        alpha_, beta_, gamma_,
        mesh_.spot_nodes().data(), mesh_.ds().data(), N_,
        0.5 * sigma * sigma, r - q, r);
}

void CrankNicolsonSolver::compute_pde_coefficients_local_vol(
    const double* sigma_vec, double r, double q) {
    const auto& S = mesh_.spot_nodes();
    const auto& ds = mesh_.ds();

    for (std::size_t i = 1; i < N_ - 1; ++i) {
        const double Si = S[i];
        const double sig = sigma_vec[i];
        const double hm = ds[i - 1];
        const double hp = ds[i];
        const double hsum = hm + hp;

        const double D = 0.5 * sig * sig * Si * Si;
        const double mu = (r - q) * Si;

        alpha_[i] = (2.0 * D) / (hm * hsum) - (mu * hp) / (hm * hsum);
        beta_[i]  = -(2.0 * D) / (hm * hp) + mu * (hp - hm) / (hm * hp) - r;
        gamma_[i] = (2.0 * D) / (hp * hsum) + (mu * hm) / (hp * hsum);
    }
}

void CrankNicolsonSolver::build_lhs() {
    const std::size_t M = N_ - 2;
    for (std::size_t j = 0; j < M; ++j) {
        const std::size_t i = j + 1;
        lhs_lower_[j] = -theta_ * dt_ * alpha_[i];
        lhs_diag_[j]  = 1.0 - theta_ * dt_ * beta_[i];
        lhs_upper_[j] = -theta_ * dt_ * gamma_[i];
    }
}

void CrankNicolsonSolver::build_rhs(
    const std::vector<double>& V, double /*tau_old*/, double tau_new) {
    const std::size_t M = N_ - 2;

    simd::build_rhs(rhs_vec_, alpha_, beta_, gamma_,
                    V.data(), M, (1.0 - theta_) * dt_);

    double V0_new = bc_.lower_boundary(tau_new);
    double VN_new = bc_.upper_boundary(tau_new);

    rhs_vec_[0]     += theta_ * dt_ * alpha_[1] * V0_new;
    rhs_vec_[M - 1] += theta_ * dt_ * gamma_[N_ - 2] * VN_new;
}

void CrankNicolsonSolver::apply_early_exercise(std::vector<double>& V) {
    // American option constraint: V(S, t) >= payoff(S) at all times
    // This implements the free boundary condition via penalty/projection.
    for (std::size_t i = 0; i < N_; ++i) {
        if (V[i] < payoff_vec_[i])
            V[i] = payoff_vec_[i];
    }
}

void CrankNicolsonSolver::step(
    std::vector<double>& V, double tau_old, double tau_new) {

    // For local vol: recompute coefficients at the midpoint time
    if (vol_surface_) {
        double T = bc_.contract().expiry;
        double t_mid = T - 0.5 * (tau_old + tau_new);
        vol_surface_->evaluate(mesh_.spot_nodes().data(), N_, t_mid, sigma_vec_);
        compute_pde_coefficients_local_vol(
            sigma_vec_, bc_.market().rate, bc_.market().dividend);
        build_lhs();
    }

    build_rhs(V, tau_old, tau_new);

    thomas_.solve(lhs_lower_, lhs_diag_, lhs_upper_, rhs_vec_, N_ - 2);

    for (std::size_t j = 0; j < N_ - 2; ++j)
        V[j + 1] = rhs_vec_[j];

    bc_.apply_boundaries(V, tau_new);

    // American early exercise: project solution onto payoff constraint
    if (is_american_)
        apply_early_exercise(V);
}

PricingResult CrankNicolsonSolver::solve() {
    std::vector<double> V = bc_.terminal_condition();

    for (std::size_t n = 0; n < num_time_steps_; ++n) {
        const double tau_old = static_cast<double>(n) * dt_;
        const double tau_new = static_cast<double>(n + 1) * dt_;
        step(V, tau_old, tau_new);
    }

    double spot = bc_.market().spot;
    double price = interpolate(mesh_, V, spot);

    return { price, std::move(V), num_time_steps_, N_ };
}

double CrankNicolsonSolver::interpolate(
    const SinhMesh& mesh,
    const std::vector<double>& grid,
    double spot) {
    const auto& S = mesh.spot_nodes();

    if (spot <= S.front()) return grid.front();
    if (spot >= S.back()) return grid.back();

    auto it = std::lower_bound(S.begin(), S.end(), spot);
    std::size_t idx = static_cast<std::size_t>(it - S.begin());
    if (idx == 0) idx = 1;

    double S_lo = S[idx - 1];
    double S_hi = S[idx];
    double w = (spot - S_lo) / (S_hi - S_lo);
    return (1.0 - w) * grid[idx - 1] + w * grid[idx];
}

} // namespace nabla
