#include "nabla/core/thomas.hpp"
#include <stdexcept>

namespace nabla {

ThomasSolver::ThomasSolver(std::size_t capacity)
    : capacity_(capacity),
      c_star_(capacity),
      d_star_(capacity)
{
    if (capacity < 2)
        throw std::invalid_argument("ThomasSolver requires capacity >= 2");
}

void ThomasSolver::solve(const double* lower, const double* diag,
                          const double* upper, double* rhs, std::size_t n) {
    if (n > capacity_) {
        capacity_ = n;
        c_star_.resize(n);
        d_star_.resize(n);
    }

    // Phase 1: Forward sweep - eliminate sub-diagonal
    c_star_[0] = upper[0] / diag[0];
    d_star_[0] = rhs[0] / diag[0];

    for (std::size_t i = 1; i < n; ++i) {
        const double m = 1.0 / (diag[i] - lower[i] * c_star_[i - 1]);
        c_star_[i] = upper[i] * m;
        d_star_[i] = (rhs[i] - lower[i] * d_star_[i - 1]) * m;
    }

    // Phase 2: Back substitution
    rhs[n - 1] = d_star_[n - 1];
    for (std::size_t i = n - 2; i < n; --i) {  // unsigned wrap-around exit
        rhs[i] = d_star_[i] - c_star_[i] * rhs[i + 1];
    }
}

void ThomasSolver::solve(const std::vector<double>& lower,
                          const std::vector<double>& diag,
                          const std::vector<double>& upper,
                          std::vector<double>& rhs) {
    const std::size_t n = diag.size();
    if (lower.size() < n || upper.size() < n || rhs.size() < n)
        throw std::invalid_argument("all vectors must have size >= n");
    solve(lower.data(), diag.data(), upper.data(), rhs.data(), n);
}

} // namespace nabla
