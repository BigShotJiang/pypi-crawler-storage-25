#include "nabla/core/barrier.hpp"
#include <algorithm>
#include <cmath>

namespace nabla {

// ── Validation ───────────────────────────────────────────────────────

void BarrierPricer::validate() const {
    double B = barrier_.level;
    double S = bc_.market().spot;

    if (B <= mesh_.s_min() || B >= mesh_.s_max())
        throw std::invalid_argument(
            "barrier level must be strictly within mesh domain (s_min, s_max)");

    if (barrier_.direction == BarrierDirection::Up && B <= S)
        throw std::invalid_argument(
            "up barrier must be above current spot price");

    if (barrier_.direction == BarrierDirection::Down && B >= S)
        throw std::invalid_argument(
            "down barrier must be below current spot price");
}

// ── Constructors ─────────────────────────────────────────────────────

BarrierPricer::BarrierPricer(
    const SinhMesh& mesh,
    const BoundaryConditions& bc,
    const BarrierParams& barrier,
    std::size_t num_time_steps,
    double theta)
    : mesh_(mesh), bc_(bc), barrier_(barrier),
      num_time_steps_(num_time_steps), theta_(theta),
      vol_surface_(nullptr)
{
    validate();
}

BarrierPricer::BarrierPricer(
    const SinhMesh& mesh,
    const BoundaryConditions& bc,
    const BarrierParams& barrier,
    std::size_t num_time_steps,
    const LocalVolSurface& vol_surface,
    double theta)
    : mesh_(mesh), bc_(bc), barrier_(barrier),
      num_time_steps_(num_time_steps), theta_(theta),
      vol_surface_(&vol_surface)
{
    validate();
}

// ── Absorbing barrier enforcement ────────────────────────────────────

void BarrierPricer::apply_barrier(std::vector<double>& V, double tau) const {
    const auto& S = mesh_.spot_nodes();
    double B = barrier_.level;
    double r = bc_.market().rate;
    double rebate_pv = barrier_.rebate * std::exp(-r * tau);

    if (barrier_.direction == BarrierDirection::Up) {
        for (std::size_t i = 0; i < S.size(); ++i) {
            if (S[i] >= B)
                V[i] = rebate_pv;
        }
    } else {
        for (std::size_t i = 0; i < S.size(); ++i) {
            if (S[i] <= B)
                V[i] = rebate_pv;
        }
    }
}

// ── Solve ────────────────────────────────────────────────────────────

BarrierPricingResult BarrierPricer::solve() {
    auto solve_knockout = [&]() -> BarrierPricingResult {
        const std::size_t N = mesh_.size();
        const std::size_t M = N - 2;
        const double dt = bc_.contract().expiry
                        / static_cast<double>(num_time_steps_);
        const auto& S = mesh_.spot_nodes();
        const auto& ds = mesh_.ds();
        const double r = bc_.market().rate;
        const double q = bc_.market().dividend;
        const double sigma = bc_.market().volatility;
        const double B = barrier_.level;

        std::vector<double> alpha(N), beta(N), gamma_c(N);
        std::vector<double> lhs_lo(M), lhs_di(M), lhs_up(M), rhs(M);
        ThomasSolver thomas(M > 1 ? M : 2);

        auto compute_coeffs = [&](double sig_local, std::size_t i) {
            double Si = S[i];
            double hm = ds[i - 1], hp = ds[i], hsum = hm + hp;
            double D = 0.5 * sig_local * sig_local * Si * Si;
            double mu = (r - q) * Si;
            alpha[i]  = 2.0 * D / (hm * hsum) - mu * hp / (hm * hsum);
            beta[i]   = -2.0 * D / (hm * hp) + mu * (hp - hm) / (hm * hp) - r;
            gamma_c[i] = 2.0 * D / (hp * hsum) + mu * hm / (hp * hsum);
        };

        auto recompute_all = [&](double t_eval) {
            if (vol_surface_) {
                std::vector<double> sig_vec(N);
                vol_surface_->evaluate(S.data(), N, t_eval, sig_vec.data());
                for (std::size_t i = 1; i < N - 1; ++i)
                    compute_coeffs(sig_vec[i], i);
            } else {
                for (std::size_t i = 1; i < N - 1; ++i)
                    compute_coeffs(sigma, i);
            }
        };

        auto build_lhs = [&]() {
            for (std::size_t j = 0; j < M; ++j) {
                std::size_t i = j + 1;
                lhs_lo[j] = -theta_ * dt * alpha[i];
                lhs_di[j] = 1.0 - theta_ * dt * beta[i];
                lhs_up[j] = -theta_ * dt * gamma_c[i];
            }
        };

        recompute_all(bc_.contract().expiry);
        build_lhs();

        std::vector<double> V = bc_.terminal_condition();
        apply_barrier(V, 0.0);

        double omt = 1.0 - theta_;

        for (std::size_t n = 0; n < num_time_steps_; ++n) {
            double tau_old = static_cast<double>(n) * dt;
            double tau_new = static_cast<double>(n + 1) * dt;

            if (vol_surface_) {
                double T = bc_.contract().expiry;
                double t_mid = T - 0.5 * (tau_old + tau_new);
                recompute_all(t_mid);
                build_lhs();
            }

            double omt_dt = omt * dt;
            for (std::size_t j = 0; j < M; ++j) {
                std::size_t i = j + 1;
                rhs[j] = V[i]
                    + omt_dt * (alpha[i] * V[i-1]
                              + beta[i] * V[i]
                              + gamma_c[i] * V[i+1]);
            }

            // Boundary contributions: use barrier-modified values
            double V0_new = bc_.lower_boundary(tau_new);
            double VN_new = bc_.upper_boundary(tau_new);

            double rebate_pv = barrier_.rebate * std::exp(-r * tau_new);
            if (barrier_.direction == BarrierDirection::Down && S.front() <= B)
                V0_new = rebate_pv;
            if (barrier_.direction == BarrierDirection::Up && S.back() >= B)
                VN_new = rebate_pv;

            rhs[0]     += theta_ * dt * alpha[1] * V0_new;
            rhs[M - 1] += theta_ * dt * gamma_c[N - 2] * VN_new;

            thomas.solve(lhs_lo.data(), lhs_di.data(), lhs_up.data(),
                         rhs.data(), M);

            for (std::size_t j = 0; j < M; ++j)
                V[j + 1] = rhs[j];

            V.front() = V0_new;
            V.back()  = VN_new;
            apply_barrier(V, tau_new);
        }

        double price = CrankNicolsonSolver::interpolate(mesh_, V, bc_.market().spot);
        return { price, std::move(V), num_time_steps_, N };
    };

    if (barrier_.knock == BarrierKnock::Out) {
        return solve_knockout();
    }

    // Knock-in via in-out parity: V_KI = V_vanilla - V_KO
    auto ko = solve_knockout();

    PricingResult vanilla;
    if (vol_surface_) {
        CrankNicolsonSolver solver(mesh_, bc_, num_time_steps_,
                                   *vol_surface_, theta_);
        vanilla = solver.solve();
    } else {
        CrankNicolsonSolver solver(mesh_, bc_, num_time_steps_, theta_);
        vanilla = solver.solve();
    }

    std::vector<double> ki_grid(mesh_.size());
    for (std::size_t i = 0; i < mesh_.size(); ++i)
        ki_grid[i] = vanilla.grid[i] - ko.grid[i];

    double ki_price = vanilla.price - ko.price;
    return { ki_price, std::move(ki_grid), num_time_steps_, mesh_.size() };
}

// ══════════════════════════════════════════════════════════════════════
// Analytical barrier option formulas
//
// Uses the Merton (1973) reflection/image method. Valid for standard
// European barriers under GBM with continuous dividend yield q.
//
// The core identity for DOWN barriers:
//   DOC(S, K, H) = BSCall(S, K) - (H/S)^p BSCall(H²/S, K)
// where p = 2(r-q)/σ² - 1
//
// For UP barriers, the same identity does NOT hold (the image blows
// up because H/S > 1). Instead, we compute UOC and UOP via the
// relationship with the down-barrier formulas.
// ══════════════════════════════════════════════════════════════════════

static double N(double x) {
    return 0.5 * std::erfc(-x / std::sqrt(2.0));
}

static double bs_call_val(double S, double K, double T,
                          double r, double sigma, double q) {
    double d1 = (std::log(S / K) + (r - q + 0.5 * sigma * sigma) * T)
              / (sigma * std::sqrt(T));
    double d2 = d1 - sigma * std::sqrt(T);
    return S * std::exp(-q * T) * N(d1) - K * std::exp(-r * T) * N(d2);
}

static double bs_put_val(double S, double K, double T,
                         double r, double sigma, double q) {
    double d1 = (std::log(S / K) + (r - q + 0.5 * sigma * sigma) * T)
              / (sigma * std::sqrt(T));
    double d2 = d1 - sigma * std::sqrt(T);
    return K * std::exp(-r * T) * N(-d2) - S * std::exp(-q * T) * N(-d1);
}

// Down-and-out call: DOC = BSCall(S,K) - (H/S)^p BSCall(H²/S, K)
// Valid for H < S, H < K. For H ≥ K the call is worthless at the barrier
// and a more complex formula applies (uses the A-C decomposition).
double BarrierPricer::analytical_down_out_call(
    double S, double K, double B, double T,
    double r, double sigma, double q) {
    if (B >= S) return 0.0;

    double sig2 = sigma * sigma;
    double sqrtT = std::sqrt(T);
    double lam = (r - q + 0.5 * sig2) / sig2;

    if (B >= K) {
        // B ≥ K: barrier at or above strike. Use Rubinstein-Reiner A-C.
        double x1 = std::log(S / B) / (sigma * sqrtT) + lam * sigma * sqrtT;
        double y1 = std::log(B / S) / (sigma * sqrtT) + lam * sigma * sqrtT;
        double eqT = std::exp(-q * T);
        double erT = std::exp(-r * T);
        double ratio = B / S;
        double pow2lam = std::pow(ratio, 2.0 * lam);
        double pow2lm2 = std::pow(ratio, 2.0 * lam - 2.0);

        double A = S * eqT * N(x1) - K * erT * N(x1 - sigma * sqrtT);
        double C = S * eqT * pow2lam * N(y1) - K * erT * pow2lm2 * N(y1 - sigma * sqrtT);
        return A - C;
    }

    // B < K: standard image method
    double vanilla = bs_call_val(S, K, T, r, sigma, q);
    double ratio = B / S;
    double p = 2.0 * lam;
    double pm2 = 2.0 * (lam - 1.0);
    double y = std::log(B * B / (S * K)) / (sigma * sqrtT) + lam * sigma * sqrtT;
    double eqT = std::exp(-q * T);
    double erT = std::exp(-r * T);

    double mirror = std::pow(ratio, p) * S * eqT * N(y)
                  - std::pow(ratio, pm2) * K * erT * N(y - sigma * sqrtT);
    return vanilla - mirror;
}

// Up-and-out call using Rubinstein-Reiner A-B+C-D decomposition
double BarrierPricer::analytical_up_out_call(
    double S, double K, double B, double T,
    double r, double sigma, double q) {
    if (B <= K) return 0.0;
    if (B <= S) return 0.0;

    double sig2 = sigma * sigma;
    double sqrtT = std::sqrt(T);
    double lam = (r - q + 0.5 * sig2) / sig2;
    double eqT = std::exp(-q * T);
    double erT = std::exp(-r * T);
    double ratio = B / S;
    double pow2l  = std::pow(ratio, 2.0 * lam);
    double pow2l2 = std::pow(ratio, 2.0 * lam - 2.0);

    // x1 = d1 of BSCall(S, K)
    double x1 = std::log(S / K) / (sigma * sqrtT) + lam * sigma * sqrtT;
    // x2 = d1-like with S/B
    double x2 = std::log(S / B) / (sigma * sqrtT) + lam * sigma * sqrtT;
    // y1 = d1 of BSCall(H²/S, K) (image of strike)
    double y1 = std::log(B * B / (S * K)) / (sigma * sqrtT) + lam * sigma * sqrtT;
    // y2 = d1-like (image of barrier)
    double y2 = std::log(B / S) / (sigma * sqrtT) + lam * sigma * sqrtT;

    // Haug (2007) Table 4-17, UOC when H > K:
    // UOC = A - B_h + C - D where η = -1 for up barriers
    // A = vanilla call = S*eqT*N(x1) - K*erT*N(x1-σ√T)
    // B_h = S*eqT*N(x2) - K*erT*N(x2-σ√T)
    // C = S*eqT*(H/S)^{2λ}*N(-y1) - K*erT*(H/S)^{2(λ-1)}*N(-y1+σ√T)
    // D = S*eqT*(H/S)^{2λ}*N(-y2) - K*erT*(H/S)^{2(λ-1)}*N(-y2+σ√T)
    double A = S * eqT * N(x1) - K * erT * N(x1 - sigma * sqrtT);
    double Bh = S * eqT * N(x2) - K * erT * N(x2 - sigma * sqrtT);
    double C = S * eqT * pow2l * N(-y1) - K * erT * pow2l2 * N(-y1 + sigma * sqrtT);
    double D = S * eqT * pow2l * N(-y2) - K * erT * pow2l2 * N(-y2 + sigma * sqrtT);

    return A - Bh + C - D;
}

// Down-and-out put using Rubinstein-Reiner
double BarrierPricer::analytical_down_out_put(
    double S, double K, double B, double T,
    double r, double sigma, double q) {
    if (B >= K) return 0.0;
    if (B >= S) return 0.0;

    double sig2 = sigma * sigma;
    double sqrtT = std::sqrt(T);
    double lam = (r - q + 0.5 * sig2) / sig2;
    double eqT = std::exp(-q * T);
    double erT = std::exp(-r * T);
    double ratio = B / S;
    double pow2l  = std::pow(ratio, 2.0 * lam);
    double pow2l2 = std::pow(ratio, 2.0 * lam - 2.0);

    double x1 = std::log(S / K) / (sigma * sqrtT) + lam * sigma * sqrtT;
    double x2 = std::log(S / B) / (sigma * sqrtT) + lam * sigma * sqrtT;
    double y1 = std::log(B * B / (S * K)) / (sigma * sqrtT) + lam * sigma * sqrtT;
    double y2 = std::log(B / S) / (sigma * sqrtT) + lam * sigma * sqrtT;

    // DOP when H < K (Haug Table 4-18, η=+1, φ=-1):
    // A = -S*eqT*N(-x1) + K*erT*N(-x1+σ√T)  [= vanilla put]
    // B_h = -S*eqT*N(-x2) + K*erT*N(-x2+σ√T)
    // C = -S*eqT*(H/S)^{2λ}*N(y1) + K*erT*(H/S)^{2(λ-1)}*N(y1-σ√T)
    // D = -S*eqT*(H/S)^{2λ}*N(y2) + K*erT*(H/S)^{2(λ-1)}*N(y2-σ√T)
    double A = -S * eqT * N(-x1) + K * erT * N(-x1 + sigma * sqrtT);
    double Bh = -S * eqT * N(-x2) + K * erT * N(-x2 + sigma * sqrtT);
    double C = -S * eqT * pow2l * N(y1) + K * erT * pow2l2 * N(y1 - sigma * sqrtT);
    double D = -S * eqT * pow2l * N(y2) + K * erT * pow2l2 * N(y2 - sigma * sqrtT);

    return A - Bh + C - D;
}

// Up-and-out put via in-out parity: UOP = vanilla_put - UIP
// UIP (up-and-in put, B > K): paths that touch B and end with payoff.
double BarrierPricer::analytical_up_out_put(
    double S, double K, double B, double T,
    double r, double sigma, double q) {
    if (B <= S) return 0.0;

    double vanilla = bs_put_val(S, K, T, r, sigma, q);
    if (B <= K) return vanilla;

    // B > K: compute UIP via the image/reflection formula and subtract
    double sig2 = sigma * sigma;
    double sqrtT = std::sqrt(T);
    double lam = (r - q + 0.5 * sig2) / sig2;
    double eqT = std::exp(-q * T);
    double erT = std::exp(-r * T);
    double ratio = B / S;
    double pow2l  = std::pow(ratio, 2.0 * lam);
    double pow2l2 = std::pow(ratio, 2.0 * lam - 2.0);

    double y = std::log(B * B / (S * K)) / (sigma * sqrtT) + lam * sigma * sqrtT;

    // UIP = -S*eqT*(B/S)^{2λ}*N(-y) + K*erT*(B/S)^{2(λ-1)}*N(-y+σ√T)
    double uip = -S * eqT * pow2l * N(-y) + K * erT * pow2l2 * N(-y + sigma * sqrtT);

    return vanilla - uip;
}

} // namespace nabla
