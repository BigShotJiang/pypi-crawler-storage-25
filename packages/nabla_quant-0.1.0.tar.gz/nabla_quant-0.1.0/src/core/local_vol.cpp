#include "nabla/core/local_vol.hpp"
#include <stdexcept>
#include <algorithm>

namespace nabla {

LocalVolSurface::LocalVolSurface(VolFunc func, bool is_const, double const_val)
    : func_(std::move(func)), is_constant_(is_const), constant_vol_(const_val)
{}

LocalVolSurface::LocalVolSurface(VolFunc func)
    : func_(std::move(func)), is_constant_(false), constant_vol_(0.0)
{
    if (!func_)
        throw std::invalid_argument("LocalVolSurface: callable must not be null");
}

LocalVolSurface LocalVolSurface::flat(double sigma) {
    if (sigma <= 0.0)
        throw std::invalid_argument("volatility must be positive");

    return LocalVolSurface(
        [sigma](double, double) { return sigma; },
        true, sigma);
}

LocalVolSurface LocalVolSurface::cev(double sigma_ref, double S_ref, double beta) {
    if (sigma_ref <= 0.0 || S_ref <= 0.0)
        throw std::invalid_argument("CEV requires positive sigma_ref and S_ref");

    return LocalVolSurface(
        [sigma_ref, S_ref, beta](double S, double) -> double {
            if (S <= 0.0) return sigma_ref;
            return sigma_ref * std::pow(S / S_ref, beta - 1.0);
        },
        false, 0.0);
}

LocalVolSurface LocalVolSurface::skew(
    double sigma_atm, double K, double skew_coeff, double term_slope) {
    if (sigma_atm <= 0.0 || K <= 0.0)
        throw std::invalid_argument("skew model requires positive sigma_atm and K");

    return LocalVolSurface(
        [sigma_atm, K, skew_coeff, term_slope](double S, double t) -> double {
            if (S <= 0.0) return sigma_atm;
            double vol = sigma_atm + skew_coeff * std::log(S / K);
            if (t > 0.0) vol += term_slope * std::sqrt(t);
            return std::max(vol, 0.01);  // floor to prevent negative vol
        },
        false, 0.0);
}

void LocalVolSurface::evaluate(
    const double* S, std::size_t N, double t, double* out) const {
    if (is_constant_) {
        for (std::size_t i = 0; i < N; ++i)
            out[i] = constant_vol_;
    } else {
        for (std::size_t i = 0; i < N; ++i)
            out[i] = func_(S[i], t);
    }
}

} // namespace nabla
