#pragma once

#include "types.hpp"
#include "mesh.hpp"
#include "boundary.hpp"
#include "thomas.hpp"
#include "solver.hpp"
#include <vector>

namespace nabla {

/// All option sensitivities (Greeks) at a given spot price.
struct GreeksResult {
    double price;
    double delta;   // ∂V/∂S
    double gamma;   // ∂²V/∂S²
    double theta;   // ∂V/∂t  (calendar time; typically negative for long options)
    double vega;    // ∂V/∂σ
    double rho;     // ∂V/∂r

    std::vector<double> delta_surface;  // Δ(S_i) at every mesh node
    std::vector<double> gamma_surface;  // Γ(S_i) at every mesh node
};

/// Greeks computed via the standard bump-and-revalue approach (for validation).
struct BumpGreeks {
    double delta;
    double gamma;
    double vega;
    double rho;
    double theta;
};

/// Computes option sensitivities using three complementary methods:
///
/// 1. **Direct spatial derivatives** (O(1) extra work):
///    Delta and Gamma are read off the solved grid using second-order accurate
///    non-uniform finite differences. No additional PDE solves required.
///
/// 2. **PDE identity** for Theta:
///    Θ = rV − (r−q)SΔ − ½σ²S²Γ   (Black-Scholes PDE)
///    Exact when V, Δ, Γ are exact; no extra solves needed.
///
/// 3. **Adjoint Algorithmic Differentiation (AAD)** for Vega and Rho:
///    A single backward sweep over the computational graph of the CN solver
///    produces all parametric sensitivities simultaneously in O(N_t · N_S),
///    i.e. the same complexity as ONE forward PDE solve, regardless of the
///    number of input parameters differentiated.
///
///    The adjoint equation at each time step:
///      μ = (I − θΔt L)^{−T} λ           (adjoint Thomas solve)
///      λ ← (I + (1−θ)Δt L)^T μ           (adjoint of explicit part)
///      accumulate ∂f/∂p from μ
///
///    This replaces the conventional "bump-and-revalue" approach which
///    requires O(P) full PDE re-solves for P parameters.
class GreeksCalculator {
public:
    /// @param mesh            Spatial mesh
    /// @param bc              Boundary / terminal conditions
    /// @param num_time_steps  Number of CN time steps
    /// @param theta_scheme    CN parameter (0.5 = Crank-Nicolson)
    GreeksCalculator(const SinhMesh& mesh,
                     const BoundaryConditions& bc,
                     std::size_t num_time_steps,
                     double theta_scheme = 0.5);

    /// Compute all Greeks (spatial + AAD) in one call.
    GreeksResult compute();

    // ── Static utilities for grid-based Greeks ──────────────────────

    /// Second-order non-uniform central differences for ∂V/∂S.
    static void compute_delta_surface(
        const SinhMesh& mesh,
        const std::vector<double>& grid,
        std::vector<double>& delta);

    /// Second-order non-uniform second derivative ∂²V/∂S².
    static void compute_gamma_surface(
        const SinhMesh& mesh,
        const std::vector<double>& grid,
        std::vector<double>& gamma);

    /// Interpolate a Greek surface at an arbitrary spot price.
    static double interpolate_greek(
        const SinhMesh& mesh,
        const std::vector<double>& surface,
        double spot);

    /// Theta from the Black-Scholes PDE identity (constant vol).
    static double theta_from_pde(
        double V, double delta, double gamma,
        double S, double sigma, double r, double q);

    // ── Bump-and-revalue reference ──────────────────────────────────

    static BumpGreeks bump_and_revalue(
        const SinhMesh& mesh,
        const ContractParams& contract,
        const MarketParams& market,
        std::size_t num_time_steps,
        double theta_scheme = 0.5,
        double ds_bump = 0.50,
        double dsigma_bump = 0.001,
        double dr_bump = 0.0001,
        double dt_bump = 1.0 / 365.0);

private:
    const SinhMesh& mesh_;
    const BoundaryConditions& bc_;
    std::size_t num_time_steps_;
    double theta_scheme_;

    std::size_t N_;         // number of spatial nodes
    std::size_t M_;         // N_ - 2  (interior count)
    double dt_;

    // PDE coefficients (full array, size N_)
    std::vector<double> alpha_, beta_, gamma_coeff_;

    // LHS tridiagonal arrays (size M_)
    std::vector<double> lhs_lower_, lhs_diag_, lhs_upper_;

    // RHS work vector (size M_)
    std::vector<double> rhs_work_;

    ThomasSolver thomas_;

    void compute_pde_coefficients();
    void build_lhs();
    void build_rhs_step(const std::vector<double>& V, double tau_new);
    void forward_step(std::vector<double>& V, double tau_old, double tau_new);

    /// Forward PDE pass storing every intermediate grid V^n.
    void forward_with_storage(
        std::vector<double>& V_final,
        std::vector<std::vector<double>>& stored_grids);

    /// Adjoint backward sweep: computes Vega and Rho in one pass.
    void adjoint_sweep(
        const std::vector<std::vector<double>>& stored_grids,
        double spot,
        double& vega_out, double& rho_out);

    // ── Parameter sensitivity coefficients ──────────────────────────

    /// ∂α_i/∂σ, ∂β_i/∂σ, ∂γ_i/∂σ  (diffusion-only sensitivity)
    void compute_dcoeff_dsigma(
        std::vector<double>& dalpha,
        std::vector<double>& dbeta,
        std::vector<double>& dgamma) const;

    /// ∂α_i/∂r, ∂β_i/∂r, ∂γ_i/∂r  (drift + discount sensitivity)
    void compute_dcoeff_dr(
        std::vector<double>& dalpha,
        std::vector<double>& dbeta,
        std::vector<double>& dgamma) const;

    /// ∂(lower_boundary)/∂r and ∂(upper_boundary)/∂r
    double dlower_dr(double tau) const;
    double dupper_dr(double tau) const;
};

} // namespace nabla
