#pragma once

#include <cstddef>
#include <cmath>
#include <string>

namespace nabla {

enum class OptionType { Call, Put };
enum class ExerciseType { European, American };

struct MarketParams {
    double spot;
    double rate;
    double volatility;
    double dividend = 0.0;
};

struct ContractParams {
    double strike;
    double expiry;
    OptionType type;
    ExerciseType exercise = ExerciseType::European;
};

struct MeshConfig {
    std::size_t num_spot_nodes;
    std::size_t num_time_steps;
    double s_min;
    double s_max;
    double concentration;
};

inline std::string to_string(OptionType t) {
    return t == OptionType::Call ? "Call" : "Put";
}

} // namespace nabla
