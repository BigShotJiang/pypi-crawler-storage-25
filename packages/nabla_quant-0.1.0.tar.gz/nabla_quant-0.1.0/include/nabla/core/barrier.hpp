#pragma once

#include "types.hpp"
#include "mesh.hpp"
#include "boundary.hpp"
#include "solver.hpp"
#include "local_vol.hpp"
#include <vector>
#include <stdexcept>

namespace nabla {

enum class BarrierDirection { Up, Down };
enum class BarrierKnock     { Out, In };

struct BarrierParams {
    double           level;      // barrier level B
    BarrierDirection direction;  // Up or Down
    BarrierKnock     knock;     // Out (absorbing) or In (activating)
    double           rebate = 0.0;  // paid on knock-out (or at expiry for KI if never triggered)
};

struct BarrierPricingResult {
    double price;
    std::vector<double> grid;
    std::size_t time_steps;
    std::size_t spatial_nodes;
};

/// Prices barrier options by modifying the Crank-Nicolson time-stepping loop:
///
///   - **Knock-out**: After each time step, grid values beyond the barrier are
///     set to the discounted rebate (absorbing boundary). The barrier acts as
///     an additional Dirichlet condition that dynamically kills option value.
///
///   - **Knock-in**: Uses in-out parity:
///       V_{knock-in} = V_{vanilla} − V_{knock-out}
///     with the same rebate. Only one knock-out solve is needed.
///
/// The barrier level must lie strictly within the mesh domain (S_min, S_max).
/// For up barriers, B > spot; for down barriers, B < spot. Violations are
/// detected at construction time.
class BarrierPricer {
public:
    /// Constant-volatility constructor
    BarrierPricer(const SinhMesh& mesh,
                  const BoundaryConditions& bc,
                  const BarrierParams& barrier,
                  std::size_t num_time_steps,
                  double theta = 0.5);

    /// Local-volatility constructor
    BarrierPricer(const SinhMesh& mesh,
                  const BoundaryConditions& bc,
                  const BarrierParams& barrier,
                  std::size_t num_time_steps,
                  const LocalVolSurface& vol_surface,
                  double theta = 0.5);

    BarrierPricingResult solve();

    /// Analytical closed-form for standard European barriers under BS
    /// (used for test validation). Implements Merton (1973) / Reiner-Rubinstein.
    static double analytical_down_out_call(
        double S, double K, double B, double T,
        double r, double sigma, double q = 0.0);

    static double analytical_up_out_call(
        double S, double K, double B, double T,
        double r, double sigma, double q = 0.0);

    static double analytical_down_out_put(
        double S, double K, double B, double T,
        double r, double sigma, double q = 0.0);

    static double analytical_up_out_put(
        double S, double K, double B, double T,
        double r, double sigma, double q = 0.0);

private:
    const SinhMesh&          mesh_;
    const BoundaryConditions& bc_;
    BarrierParams            barrier_;
    std::size_t              num_time_steps_;
    double                   theta_;
    const LocalVolSurface*   vol_surface_;

    void validate() const;

    /// Apply the absorbing barrier: zero (or rebate) all nodes beyond B.
    void apply_barrier(std::vector<double>& V, double tau) const;
};

} // namespace nabla
