#pragma once

#include "types.hpp"
#include <vector>
#include <cmath>

namespace nabla {

/// Non-uniform mesh via hyperbolic sine coordinate transformation.
///
/// The map  S(ξ) = K + c · sinh(ξ)  converts a uniform computational grid
/// in ξ-space to a physical asset-price grid that concentrates nodes near
/// the strike K, where the option's Gamma is largest, while keeping the
/// deep ITM / OTM tails sparse.
///
/// Parameters:
///   K   – strike price (clustering center)
///   c   – concentration scale (smaller ⇒ tighter clustering around K)
///
/// The inverse is   ξ(S) = arcsinh((S − K) / c)
/// and the Jacobian dS/dξ = c · cosh(ξ), which is minimized at ξ = 0 (S = K).
class SinhMesh {
public:
    /// @param strike        Strike price K
    /// @param s_min         Lower domain boundary (≥ 0)
    /// @param s_max         Upper domain boundary (> s_min)
    /// @param num_nodes     Number of spatial nodes including both endpoints
    /// @param concentration Scale parameter c > 0
    SinhMesh(double strike, double s_min, double s_max,
             std::size_t num_nodes, double concentration);

    const std::vector<double>& spot_nodes() const { return s_nodes_; }
    const std::vector<double>& xi_nodes()   const { return xi_nodes_; }
    const std::vector<double>& ds()         const { return ds_; }

    std::size_t size()          const { return num_nodes_; }
    double strike()             const { return strike_; }
    double s_min()              const { return s_min_; }
    double s_max()              const { return s_max_; }
    double concentration()      const { return concentration_; }
    double xi_min()             const { return xi_min_; }
    double xi_max()             const { return xi_max_; }

    /// Forward transform: computational → physical
    double s_from_xi(double xi)  const;

    /// Inverse transform: physical → computational
    double xi_from_s(double s)   const;

    /// Jacobian dS/dξ = c · cosh(ξ)
    double jacobian(double xi)   const;

    double min_spacing() const;
    double max_spacing() const;
    double spacing_ratio() const;

    /// Index of the node closest to the strike price
    std::size_t strike_index() const;

private:
    double strike_;
    double s_min_;
    double s_max_;
    std::size_t num_nodes_;
    double concentration_;

    double xi_min_;
    double xi_max_;

    std::vector<double> xi_nodes_;
    std::vector<double> s_nodes_;
    std::vector<double> ds_;

    void validate_inputs() const;
    void generate();
};

} // namespace nabla
