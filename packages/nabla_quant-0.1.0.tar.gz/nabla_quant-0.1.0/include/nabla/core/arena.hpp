#pragma once

#include <cstddef>
#include <cstdint>
#include <cstring>
#include <stdexcept>
#include <new>
#include <vector>

namespace nabla {

/// Fixed-size memory arena for zero-allocation PDE time stepping.
///
/// Pre-allocates a single contiguous block of memory at construction time.
/// Provides bump-pointer allocation with O(1) alloc and O(1) reset.
/// All allocations are 64-byte aligned for cache-line and SIMD friendliness.
///
/// Usage pattern inside the hot loop:
///   arena.reset();                     // O(1) - just resets the pointer
///   double* tmp = arena.alloc<double>(N);
///   // ... use tmp within this time step ...
///   // no free needed - reset() reclaims everything at once
///
/// This guarantees:
///   - Zero heap allocations during time stepping
///   - Cache-local memory access patterns
///   - No fragmentation
class Arena {
public:
    static constexpr std::size_t DEFAULT_ALIGNMENT = 64;

    explicit Arena(std::size_t capacity_bytes);
    ~Arena();

    Arena(const Arena&) = delete;
    Arena& operator=(const Arena&) = delete;
    Arena(Arena&& other) noexcept;
    Arena& operator=(Arena&& other) noexcept;

    /// Allocate `count` elements of type T, aligned to `alignment` bytes.
    /// Returns a pointer to uninitialized memory.
    template <typename T>
    T* alloc(std::size_t count, std::size_t alignment = DEFAULT_ALIGNMENT) {
        std::size_t bytes = count * sizeof(T);
        void* ptr = alloc_raw(bytes, alignment);
        return static_cast<T*>(ptr);
    }

    /// Allocate `count` elements of type T, zero-initialized.
    template <typename T>
    T* alloc_zeroed(std::size_t count, std::size_t alignment = DEFAULT_ALIGNMENT) {
        T* ptr = alloc<T>(count, alignment);
        std::memset(ptr, 0, count * sizeof(T));
        return ptr;
    }

    /// Reset the arena - O(1), reclaims all memory without freeing.
    void reset() noexcept { offset_ = 0; }

    std::size_t capacity()  const noexcept { return capacity_; }
    std::size_t used()      const noexcept { return offset_; }
    std::size_t remaining() const noexcept { return capacity_ - offset_; }

private:
    std::uint8_t* buffer_;
    std::size_t capacity_;
    std::size_t offset_;

    void* alloc_raw(std::size_t bytes, std::size_t alignment);
};

/// RAII arena-backed vector replacement for the PDE hot path.
/// Wraps a raw pointer from the arena with size metadata.
/// No destructor needed - arena reset handles deallocation.
template <typename T>
class ArenaSpan {
public:
    ArenaSpan() : data_(nullptr), size_(0) {}
    ArenaSpan(T* data, std::size_t size) : data_(data), size_(size) {}

    T& operator[](std::size_t i) { return data_[i]; }
    const T& operator[](std::size_t i) const { return data_[i]; }

    T* data() { return data_; }
    const T* data() const { return data_; }
    std::size_t size() const { return size_; }

    T* begin() { return data_; }
    T* end()   { return data_ + size_; }
    const T* begin() const { return data_; }
    const T* end()   const { return data_ + size_; }

private:
    T* data_;
    std::size_t size_;
};

} // namespace nabla
