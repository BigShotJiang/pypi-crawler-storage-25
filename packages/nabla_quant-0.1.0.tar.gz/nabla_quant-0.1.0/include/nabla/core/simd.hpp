#pragma once

#include <cstddef>

/// SIMD-accelerated operations for PDE coefficient computation and
/// tridiagonal RHS assembly. Uses AVX2 intrinsics to process 4 doubles
/// per cycle (256-bit registers).
///
/// The batch pricer uses SIMD to solve the PDE for 4 different strikes
/// simultaneously - each strike occupies one lane of the AVX2 register,
/// making full use of the 256-bit data path.

#if defined(__AVX2__) || defined(__AVX__)
#define NABLA_HAS_AVX2 1
#include <immintrin.h>
#else
#define NABLA_HAS_AVX2 0
#endif

namespace nabla {
namespace simd {

/// Vectorized RHS construction: computes the explicit part of Crank-Nicolson
/// for N-2 interior nodes. Processes 4 nodes per iteration.
///
///   rhs[j] = omt_dt * alpha[j+1] * V[j]
///           + (1 + omt_dt * beta[j+1]) * V[j+1]
///           + omt_dt * gamma[j+1] * V[j+2]
///
/// where omt_dt = (1 - theta) * dt
void build_rhs_avx2(
    double* __restrict__ rhs,
    const double* __restrict__ alpha,
    const double* __restrict__ beta,
    const double* __restrict__ gamma,
    const double* __restrict__ V,
    std::size_t M,            // number of interior nodes (N-2)
    double one_minus_theta_dt
);

/// Scalar fallback for platforms without AVX2
void build_rhs_scalar(
    double* __restrict__ rhs,
    const double* __restrict__ alpha,
    const double* __restrict__ beta,
    const double* __restrict__ gamma,
    const double* __restrict__ V,
    std::size_t M,
    double one_minus_theta_dt
);

/// Vectorized PDE coefficient computation for the Black-Scholes operator.
/// Computes alpha, beta, gamma for interior nodes 1..N-2.
void compute_coefficients_avx2(
    double* __restrict__ alpha,
    double* __restrict__ beta,
    double* __restrict__ gamma,
    const double* __restrict__ S,
    const double* __restrict__ ds,
    std::size_t N,
    double half_sigma_sq,
    double drift_coeff,     // r - q
    double r
);

void compute_coefficients_scalar(
    double* __restrict__ alpha,
    double* __restrict__ beta,
    double* __restrict__ gamma,
    const double* __restrict__ S,
    const double* __restrict__ ds,
    std::size_t N,
    double half_sigma_sq,
    double drift_coeff,
    double r
);

/// Dispatch to fastest available implementation
inline void build_rhs(
    double* rhs, const double* alpha, const double* beta,
    const double* gamma, const double* V, std::size_t M,
    double one_minus_theta_dt)
{
#if NABLA_HAS_AVX2
    build_rhs_avx2(rhs, alpha, beta, gamma, V, M, one_minus_theta_dt);
#else
    build_rhs_scalar(rhs, alpha, beta, gamma, V, M, one_minus_theta_dt);
#endif
}

inline void compute_coefficients(
    double* alpha, double* beta, double* gamma,
    const double* S, const double* ds, std::size_t N,
    double half_sigma_sq, double drift_coeff, double r)
{
#if NABLA_HAS_AVX2
    compute_coefficients_avx2(alpha, beta, gamma, S, ds, N,
                              half_sigma_sq, drift_coeff, r);
#else
    compute_coefficients_scalar(alpha, beta, gamma, S, ds, N,
                                half_sigma_sq, drift_coeff, r);
#endif
}

} // namespace simd
} // namespace nabla
