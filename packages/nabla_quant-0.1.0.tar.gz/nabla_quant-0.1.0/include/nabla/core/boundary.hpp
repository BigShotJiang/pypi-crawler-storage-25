#pragma once

#include "types.hpp"
#include "mesh.hpp"
#include <vector>

namespace nabla {

enum class BoundaryType { Dirichlet, Neumann };

/// Boundary and terminal conditions for European option pricing on the
/// Black-Scholes PDE domain.
///
/// Three conditions fully determine the PDE problem on a finite grid:
///
/// 1. Terminal condition (τ = 0, i.e. t = T):
///      V(S, T) = payoff(S)
///
/// 2. Lower spatial boundary (S → S_min ≈ 0):
///      Call: V = 0
///      Put:  V = K·e^{-rτ} − S_min·e^{-qτ}
///
/// 3. Upper spatial boundary (S → S_max ≫ K):
///      Call: V = S_max·e^{-qτ} − K·e^{-rτ}
///      Put:  V = 0
///
/// All boundaries are Dirichlet (value-prescribed). Neumann extensions
/// (∂V/∂S or ∂²V/∂S² = 0) are reserved for Phase 2 linearity conditions.
class BoundaryConditions {
public:
    BoundaryConditions(const ContractParams& contract,
                       const MarketParams& market,
                       const SinhMesh& mesh);

    /// Payoff at a single spot level
    double payoff(double spot) const;

    /// Full terminal-condition vector V(S_i, T) for every mesh node
    std::vector<double> terminal_condition() const;

    /// Boundary values as a function of time-to-maturity τ = T − t
    double lower_boundary(double tau) const;
    double upper_boundary(double tau) const;

    BoundaryType lower_type() const { return lower_type_; }
    BoundaryType upper_type() const { return upper_type_; }

    const ContractParams& contract() const { return contract_; }
    const MarketParams&   market()   const { return market_; }
    const SinhMesh&       mesh()     const { return mesh_; }

    /// Apply boundary values into a grid vector at a given τ
    void apply_boundaries(std::vector<double>& grid, double tau) const;

private:
    ContractParams contract_;
    MarketParams market_;
    const SinhMesh& mesh_;
    BoundaryType lower_type_;
    BoundaryType upper_type_;
};

} // namespace nabla
