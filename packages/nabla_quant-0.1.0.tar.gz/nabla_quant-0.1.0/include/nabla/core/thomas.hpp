#pragma once

#include <cstddef>
#include <vector>

namespace nabla {

/// O(N) tridiagonal matrix solver using the Thomas algorithm.
///
/// Solves A·x = d where A is an N×N tridiagonal matrix:
///
///     [ b_0  c_0                    ] [x_0]   [d_0]
///     [ a_1  b_1  c_1              ] [x_1]   [d_1]
///     [      a_2  b_2  c_2         ] [x_2] = [d_2]
///     [           ...              ] [...]   [...]
///     [              a_{n-1} b_{n-1}] [x_{n-1}] [d_{n-1}]
///
/// Two-phase algorithm:
///   Phase 1 (forward sweep): eliminate sub-diagonal entries
///   Phase 2 (back substitution): solve for x from bottom up
///
/// The algorithm modifies the scratch vectors in-place for zero-allocation
/// operation when called with pre-allocated workspace.
class ThomasSolver {
public:
    explicit ThomasSolver(std::size_t capacity);

    /// Solve a tridiagonal system in-place.
    ///
    /// @param lower   Sub-diagonal a[1..n-1] (lower[0] unused, size n)
    /// @param diag    Main diagonal b[0..n-1] (size n)
    /// @param upper   Super-diagonal c[0..n-2] (upper[n-1] unused, size n)
    /// @param rhs     Right-hand side d[0..n-1], overwritten with solution x
    /// @param n       System size
    ///
    /// Preconditions: n >= 2, all arrays have size >= n, matrix is diagonally
    /// dominant or positive definite (ensures stability without pivoting).
    void solve(const double* lower, const double* diag,
               const double* upper, double* rhs, std::size_t n);

    /// Convenience overload for std::vector inputs.
    void solve(const std::vector<double>& lower,
               const std::vector<double>& diag,
               const std::vector<double>& upper,
               std::vector<double>& rhs);

    std::size_t capacity() const { return capacity_; }

private:
    std::size_t capacity_;
    std::vector<double> c_star_;  // modified super-diagonal scratch
    std::vector<double> d_star_;  // modified RHS scratch
};

} // namespace nabla
