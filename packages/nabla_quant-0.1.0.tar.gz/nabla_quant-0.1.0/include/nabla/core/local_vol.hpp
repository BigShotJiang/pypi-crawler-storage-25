#pragma once

#include <cstddef>
#include <vector>
#include <cmath>
#include <functional>

namespace nabla {

/// Local volatility surface σ(S, t) for the generalized Black-Scholes PDE:
///   ∂V/∂τ = ½σ(S,t)²S² V_SS + (r-q)S V_S - rV
///
/// Supports:
///   - Constant volatility (flat surface)
///   - CEV (Constant Elasticity of Variance) model: σ(S) = σ₀ · (S/S₀)^(β-1)
///   - Parametric skew: σ(S, t) = σ₀ + skew·log(S/K) + term·√t
///   - Arbitrary user-defined σ(S, t) via std::function
class LocalVolSurface {
public:
    using VolFunc = std::function<double(double S, double t)>;

    /// Constant (flat) volatility
    static LocalVolSurface flat(double sigma);

    /// CEV model: σ(S) = sigma_ref * (S / S_ref)^(beta - 1)
    static LocalVolSurface cev(double sigma_ref, double S_ref, double beta);

    /// Linear skew: σ(S, t) = sigma_atm + skew * ln(S/K) + term_slope * sqrt(t)
    static LocalVolSurface skew(double sigma_atm, double K,
                                double skew_coeff, double term_slope = 0.0);

    /// Arbitrary callable
    explicit LocalVolSurface(VolFunc func);

    /// Evaluate σ(S, t) at a single point
    double operator()(double S, double t) const { return func_(S, t); }

    /// Evaluate σ(S_i, t) for all mesh nodes, storing results in `out`.
    void evaluate(const double* S, std::size_t N, double t,
                  double* out) const;

    bool is_constant() const { return is_constant_; }
    double constant_vol() const { return constant_vol_; }

private:
    VolFunc func_;
    bool is_constant_;
    double constant_vol_;

    LocalVolSurface(VolFunc func, bool is_const, double const_val);
};

} // namespace nabla
