#pragma once

#include "types.hpp"
#include "mesh.hpp"
#include "boundary.hpp"
#include "thomas.hpp"
#include "arena.hpp"
#include "simd.hpp"
#include "local_vol.hpp"
#include <vector>

namespace nabla {

/// Result of a PDE solve: option values on the mesh at t=0.
struct PricingResult {
    double price;                   // interpolated price at spot
    std::vector<double> grid;       // full grid of option values V(S_i, 0)
    std::size_t time_steps;
    std::size_t spatial_nodes;
};

/// Crank-Nicolson finite difference solver for the Black-Scholes PDE.
///
/// Discretizes the PDE:
///   ∂V/∂τ = ½σ²S² ∂²V/∂S² + (r-q)S ∂V/∂S - rV
///
/// using the θ-scheme (θ=0.5 for Crank-Nicolson) on the non-uniform SinhMesh.
/// Time stepping proceeds backward from terminal condition (τ=0) to τ=T.
///
/// The non-uniform spatial discretization uses second-order accurate finite
/// differences for both first and second derivatives, yielding a tridiagonal
/// system at each time step solved via the Thomas algorithm in O(N).
///
/// All temporary workspace is pre-allocated via a memory Arena - the hot
/// time-stepping loop performs zero heap allocations, guaranteeing cache
/// locality and deterministic latency.
class CrankNicolsonSolver {
public:
    /// @param mesh     Spatial mesh (non-uniform SinhMesh)
    /// @param bc       Boundary/terminal conditions
    /// @param num_time_steps  Number of time steps (dt = T / num_time_steps)
    /// @param theta    Implicitness parameter: 0.5 = Crank-Nicolson,
    ///                 1.0 = fully implicit, 0.0 = fully explicit
    CrankNicolsonSolver(const SinhMesh& mesh,
                        const BoundaryConditions& bc,
                        std::size_t num_time_steps,
                        double theta = 0.5);

    /// Constructor with local volatility surface σ(S, t)
    CrankNicolsonSolver(const SinhMesh& mesh,
                        const BoundaryConditions& bc,
                        std::size_t num_time_steps,
                        const LocalVolSurface& vol_surface,
                        double theta = 0.5);

    /// Run the PDE solve. Returns the full pricing result.
    PricingResult solve();

    /// Interpolate the option value at a specific spot price from the grid.
    static double interpolate(const SinhMesh& mesh,
                              const std::vector<double>& grid,
                              double spot);

    /// Expose arena stats for benchmarking/diagnostics
    std::size_t arena_capacity() const { return arena_.capacity(); }

private:
    const SinhMesh& mesh_;
    const BoundaryConditions& bc_;
    std::size_t num_time_steps_;
    double theta_;

    std::size_t N_;     // number of spatial nodes
    double dt_;         // time step size

    // Pre-allocated arena for all solver workspace
    Arena arena_;

    // PDE coefficient arrays for interior nodes (indices 1..N-2)
    double* alpha_;     // coefficient of V_{i-1}
    double* beta_;      // coefficient of V_i
    double* gamma_;     // coefficient of V_{i+1}

    // Tridiagonal system arrays (size N-2 for interior nodes)
    double* lhs_lower_;
    double* lhs_diag_;
    double* lhs_upper_;
    double* rhs_vec_;

    // Per-node volatility array for local vol (arena-allocated)
    double* sigma_vec_;

    ThomasSolver thomas_;

    // Local vol surface (nullptr for constant vol)
    const LocalVolSurface* vol_surface_;

    // Payoff vector for American early-exercise projection (arena-allocated)
    double* payoff_vec_;
    bool is_american_;

    void init_workspace();
    void compute_pde_coefficients(double sigma, double r, double q);
    void compute_pde_coefficients_local_vol(
        const double* sigma_vec, double r, double q);
    void build_rhs(const std::vector<double>& V, double tau_old, double tau_new);
    void build_lhs();
    void step(std::vector<double>& V, double tau_old, double tau_new);
    void apply_early_exercise(std::vector<double>& V);
};

} // namespace nabla
