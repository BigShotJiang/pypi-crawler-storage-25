#include "test_harness.hpp"
#include "nabla/core/thomas.hpp"
#include <cmath>
#include <vector>

using namespace nabla;

// ── Construction ─────────────────────────────────────────────────────

TEST(thomas_construction) {
    ThomasSolver solver(100);
    test::assert_true(solver.capacity() == 100);
}

TEST(thomas_rejects_capacity_lt_2) {
    test::assert_throws([]{ ThomasSolver solver(1); });
    test::assert_throws([]{ ThomasSolver solver(0); });
}

// ── 2×2 system ───────────────────────────────────────────────────────

TEST(thomas_2x2_identity) {
    // I·x = [3, 7] => x = [3, 7]
    ThomasSolver solver(2);
    std::vector<double> lo = {0, 0};
    std::vector<double> di = {1, 1};
    std::vector<double> up = {0, 0};
    std::vector<double> rhs = {3, 7};
    solver.solve(lo, di, up, rhs);
    test::assert_near(rhs[0], 3.0, 1e-15);
    test::assert_near(rhs[1], 7.0, 1e-15);
}

TEST(thomas_2x2_general) {
    // [2  1] [x0]   [5]    => x0=1, x1=3
    // [1  3] [x1] = [10]
    ThomasSolver solver(2);
    std::vector<double> lo = {0, 1};
    std::vector<double> di = {2, 3};
    std::vector<double> up = {1, 0};
    std::vector<double> rhs = {5, 10};
    solver.solve(lo, di, up, rhs);
    test::assert_near(rhs[0], 1.0, 1e-14);
    test::assert_near(rhs[1], 3.0, 1e-14);
}

// ── 3×3 system ───────────────────────────────────────────────────────

TEST(thomas_3x3_diagonal) {
    // Diagonal: 2x=6, 3x=9, 4x=12 => x=[3,3,3]
    ThomasSolver solver(3);
    std::vector<double> lo = {0, 0, 0};
    std::vector<double> di = {2, 3, 4};
    std::vector<double> up = {0, 0, 0};
    std::vector<double> rhs = {6, 9, 12};
    solver.solve(lo, di, up, rhs);
    test::assert_near(rhs[0], 3.0, 1e-14);
    test::assert_near(rhs[1], 3.0, 1e-14);
    test::assert_near(rhs[2], 3.0, 1e-14);
}

TEST(thomas_3x3_tridiagonal) {
    // [ 4 -1  0] [x0]   [ 1]
    // [-1  4 -1] [x1] = [ 4]
    // [ 0 -1  4] [x2]   [ 1]
    // Solution: x0 = 0.5, x1 = 1.0, x2 = 0.5
    ThomasSolver solver(3);
    std::vector<double> lo = {0, -1, -1};
    std::vector<double> di = {4, 4, 4};
    std::vector<double> up = {-1, -1, 0};
    std::vector<double> rhs = {1, 4, 1};
    solver.solve(lo, di, up, rhs);

    // Verify: 4*(0.5) + (-1)*(1) = 1 ✓; -1*(0.5) + 4*1 + -1*(0.5) = 3 ≠ 4
    // Actually let me solve properly:
    // Row 0: 4*x0 - x1 = 1
    // Row 1: -x0 + 4*x1 - x2 = 4
    // Row 2: -x1 + 4*x2 = 1
    // From symmetry: x0=x2, so 4*x0 - x1 = 1 and -x1 + 4*x0 = 1 => same
    // -x0 + 4*x1 - x0 = 4 => 4*x1 - 2*x0 = 4
    // 4*x0 - x1 = 1 => x1 = 4*x0 - 1
    // 4*(4*x0-1) - 2*x0 = 4 => 16*x0 - 4 - 2*x0 = 4 => 14*x0 = 8 => x0 = 4/7
    double x0 = 4.0 / 7.0;
    double x1 = (4.0 * x0 - 1.0);  // 16/7 - 1 = 9/7
    test::assert_near(rhs[0], x0, 1e-14);
    test::assert_near(rhs[1], x1, 1e-14);
    test::assert_near(rhs[2], x0, 1e-14);
}

// ── Known diagonally-dominant system ──────────────────────────────────

TEST(thomas_5x5_heat_equation_like) {
    // Simulate a heat-equation-like tridiagonal system:
    // -1 on sub/super diagonal, 2.5 on main diagonal (diagonally dominant)
    const std::size_t n = 5;
    ThomasSolver solver(n);
    std::vector<double> lo(n, -1.0); lo[0] = 0.0;
    std::vector<double> di(n, 2.5);
    std::vector<double> up(n, -1.0); up[n-1] = 0.0;
    std::vector<double> rhs = {1.5, 0.5, 0.5, 0.5, 1.5};
    solver.solve(lo, di, up, rhs);

    // Verify by computing A*x and checking it equals original rhs
    std::vector<double> orig_rhs = {1.5, 0.5, 0.5, 0.5, 1.5};
    std::vector<double> Ax(n);
    Ax[0] = 2.5 * rhs[0] - rhs[1];
    for (std::size_t i = 1; i < n - 1; ++i)
        Ax[i] = -rhs[i-1] + 2.5 * rhs[i] - rhs[i+1];
    Ax[n-1] = -rhs[n-2] + 2.5 * rhs[n-1];

    for (std::size_t i = 0; i < n; ++i)
        test::assert_near(Ax[i], orig_rhs[i], 1e-12,
                          "A*x[" + std::to_string(i) + "] == rhs");
}

// ── Large system residual check ──────────────────────────────────────

TEST(thomas_large_system_residual) {
    const std::size_t n = 1000;
    ThomasSolver solver(n);
    std::vector<double> lo(n), di(n), up(n), rhs(n);

    // Construct a diagonally dominant system with known structure
    for (std::size_t i = 0; i < n; ++i) {
        lo[i] = (i > 0) ? -0.5 : 0.0;
        di[i] = 2.0;
        up[i] = (i < n - 1) ? -0.5 : 0.0;
        rhs[i] = 1.0;  // constant RHS
    }

    std::vector<double> orig_rhs = rhs;
    solver.solve(lo, di, up, rhs);

    // Verify residual: ||A*x - b|| < tol
    double max_residual = 0.0;
    for (std::size_t i = 0; i < n; ++i) {
        double Ax_i = di[i] * rhs[i];  // di is unmodified (const ref)
        // Wait - di is const& but lo/di/up are const in the solve signature
        // Actually need to recompute. di[i] = 2.0 for all i
        Ax_i = 2.0 * rhs[i];
        if (i > 0) Ax_i += (-0.5) * rhs[i - 1];
        if (i < n - 1) Ax_i += (-0.5) * rhs[i + 1];
        double res = std::fabs(Ax_i - orig_rhs[i]);
        if (res > max_residual) max_residual = res;
    }

    test::assert_true(max_residual < 1e-10,
                      "residual = " + std::to_string(max_residual));
}

// ── Pointer interface ────────────────────────────────────────────────

TEST(thomas_raw_pointer_interface) {
    ThomasSolver solver(3);
    double lo[] = {0, -1, -1};
    double di[] = {3, 3, 3};
    double up[] = {-1, -1, 0};
    double rhs[] = {2, 1, 2};
    double orig[] = {2, 1, 2};

    solver.solve(lo, di, up, rhs, 3);

    // Verify: A*x == b
    double r0 = 3*rhs[0] - rhs[1];
    double r1 = -rhs[0] + 3*rhs[1] - rhs[2];
    double r2 = -rhs[1] + 3*rhs[2];
    test::assert_near(r0, orig[0], 1e-14);
    test::assert_near(r1, orig[1], 1e-14);
    test::assert_near(r2, orig[2], 1e-14);
}

// ── Auto-resize when n > capacity ────────────────────────────────────

TEST(thomas_auto_resize) {
    ThomasSolver solver(2);
    test::assert_true(solver.capacity() == 2);

    std::vector<double> lo = {0, -1, -1, -1};
    std::vector<double> di = {4, 4, 4, 4};
    std::vector<double> up = {-1, -1, -1, 0};
    std::vector<double> rhs = {3, 2, 2, 3};
    std::vector<double> orig = rhs;

    solver.solve(lo, di, up, rhs);
    test::assert_true(solver.capacity() >= 4);

    // Verify residual
    for (std::size_t i = 0; i < 4; ++i) {
        double Ax_i = 4.0 * rhs[i];
        if (i > 0) Ax_i -= rhs[i - 1];
        if (i < 3) Ax_i -= rhs[i + 1];
        test::assert_near(Ax_i, orig[i], 1e-13);
    }
}

// ── Solution symmetry ────────────────────────────────────────────────

TEST(thomas_symmetric_system_symmetric_solution) {
    const std::size_t n = 7;
    ThomasSolver solver(n);
    std::vector<double> lo(n, -1.0); lo[0] = 0.0;
    std::vector<double> di(n, 3.0);
    std::vector<double> up(n, -1.0); up[n-1] = 0.0;
    std::vector<double> rhs = {1, 0, 0, 2, 0, 0, 1};  // symmetric RHS
    solver.solve(lo, di, up, rhs);

    // Solution should be symmetric: x[i] == x[n-1-i]
    for (std::size_t i = 0; i < n / 2; ++i)
        test::assert_near(rhs[i], rhs[n - 1 - i], 1e-13,
                          "symmetry at i=" + std::to_string(i));
}

// ── Solution positivity for positive RHS with M-matrix ───────────────

TEST(thomas_m_matrix_positive_rhs_positive_solution) {
    const std::size_t n = 50;
    ThomasSolver solver(n);
    std::vector<double> lo(n, -0.3); lo[0] = 0.0;
    std::vector<double> di(n, 1.0);
    std::vector<double> up(n, -0.3); up[n-1] = 0.0;
    std::vector<double> rhs(n, 1.0);
    solver.solve(lo, di, up, rhs);

    for (std::size_t i = 0; i < n; ++i)
        test::assert_true(rhs[i] > 0.0,
                          "solution must be positive for M-matrix with positive RHS");
}

// ── Repeated solves reuse workspace ──────────────────────────────────

TEST(thomas_repeated_solves) {
    ThomasSolver solver(10);

    for (int trial = 0; trial < 5; ++trial) {
        std::vector<double> lo(10, -1.0); lo[0] = 0.0;
        std::vector<double> di(10, 3.0 + trial * 0.1);
        std::vector<double> up(10, -1.0); up[9] = 0.0;
        std::vector<double> rhs(10, 1.0);
        std::vector<double> orig = rhs;
        solver.solve(lo, di, up, rhs);

        double max_res = 0.0;
        for (std::size_t i = 0; i < 10; ++i) {
            double Ax = di[i] * rhs[i];
            if (i > 0) Ax -= rhs[i - 1];
            if (i < 9) Ax -= rhs[i + 1];
            double r = std::fabs(Ax - orig[i]);
            if (r > max_res) max_res = r;
        }
        test::assert_true(max_res < 1e-12,
                          "trial " + std::to_string(trial) + " residual");
    }
}

int main() { RUN_TESTS(); }
