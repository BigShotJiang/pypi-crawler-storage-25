#pragma once

/// Minimal, dependency-free test harness for NablaQuant.

#include <cmath>
#include <cstdlib>
#include <iostream>
#include <string>
#include <vector>
#include <functional>

namespace test {

struct TestCase {
    std::string name;
    std::function<void()> fn;
};

inline std::vector<TestCase>& registry() {
    static std::vector<TestCase> cases;
    return cases;
}

inline int add(const std::string& name, std::function<void()> fn) {
    registry().push_back({name, std::move(fn)});
    return 0;
}

inline int run_all() {
    int passed = 0, failed = 0;
    for (auto& tc : registry()) {
        try {
            tc.fn();
            std::cout << "  [PASS] " << tc.name << "\n";
            ++passed;
        } catch (const std::exception& e) {
            std::cerr << "  [FAIL] " << tc.name << " : " << e.what() << "\n";
            ++failed;
        }
    }
    std::cout << "\n  " << passed << " passed, " << failed << " failed.\n";
    return failed > 0 ? 1 : 0;
}

class AssertionError : public std::runtime_error {
    using std::runtime_error::runtime_error;
};

inline void assert_true(bool cond, const std::string& msg = "") {
    if (!cond)
        throw AssertionError("assert_true failed" + (msg.empty() ? "" : ": " + msg));
}

inline void assert_near(double a, double b, double tol, const std::string& msg = "") {
    if (std::fabs(a - b) > tol)
        throw AssertionError(
            "assert_near failed: " + std::to_string(a) + " vs " + std::to_string(b) +
            " (tol=" + std::to_string(tol) + ")" + (msg.empty() ? "" : " : " + msg));
}

inline void assert_throws(std::function<void()> fn, const std::string& msg = "") {
    bool threw = false;
    try { fn(); } catch (...) { threw = true; }
    if (!threw)
        throw AssertionError("assert_throws: no exception thrown" +
                             (msg.empty() ? "" : ": " + msg));
}

} // namespace test

#define TEST(name) \
    static void test_##name(); \
    static int reg_##name = ::test::add(#name, test_##name); \
    static void test_##name()

#define RUN_TESTS() return ::test::run_all()
