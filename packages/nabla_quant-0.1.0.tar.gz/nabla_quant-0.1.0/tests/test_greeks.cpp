#include "test_harness.hpp"
#include "nabla/nabla.hpp"
#include <cmath>

using namespace nabla;

// ── Black-Scholes analytical Greeks (with continuous dividends) ───────

static double norm_cdf(double x) {
    return 0.5 * std::erfc(-x / std::sqrt(2.0));
}

static double norm_pdf(double x) {
    return std::exp(-0.5 * x * x) / std::sqrt(2.0 * 3.14159265358979323846);
}

struct BSGreeks {
    double price, delta, gamma, vega, rho, theta;
};

static BSGreeks bs_call_greeks(double S, double K, double T,
                               double r, double sigma, double q = 0.0) {
    double d1 = (std::log(S / K) + (r - q + 0.5 * sigma * sigma) * T)
              / (sigma * std::sqrt(T));
    double d2 = d1 - sigma * std::sqrt(T);
    double eqT = std::exp(-q * T);
    double erT = std::exp(-r * T);

    BSGreeks g;
    g.price = S * eqT * norm_cdf(d1) - K * erT * norm_cdf(d2);
    g.delta = eqT * norm_cdf(d1);
    g.gamma = eqT * norm_pdf(d1) / (S * sigma * std::sqrt(T));
    g.vega  = S * eqT * norm_pdf(d1) * std::sqrt(T);
    g.rho   = K * T * erT * norm_cdf(d2);
    g.theta = -eqT * S * norm_pdf(d1) * sigma / (2.0 * std::sqrt(T))
              - r * K * erT * norm_cdf(d2)
              + q * S * eqT * norm_cdf(d1);
    return g;
}

static BSGreeks bs_put_greeks(double S, double K, double T,
                              double r, double sigma, double q = 0.0) {
    double d1 = (std::log(S / K) + (r - q + 0.5 * sigma * sigma) * T)
              / (sigma * std::sqrt(T));
    double d2 = d1 - sigma * std::sqrt(T);
    double eqT = std::exp(-q * T);
    double erT = std::exp(-r * T);

    BSGreeks g;
    g.price = K * erT * norm_cdf(-d2) - S * eqT * norm_cdf(-d1);
    g.delta = -eqT * norm_cdf(-d1);
    g.gamma = eqT * norm_pdf(d1) / (S * sigma * std::sqrt(T));
    g.vega  = S * eqT * norm_pdf(d1) * std::sqrt(T);
    g.rho   = -K * T * erT * norm_cdf(-d2);
    g.theta = -eqT * S * norm_pdf(d1) * sigma / (2.0 * std::sqrt(T))
              + r * K * erT * norm_cdf(-d2)
              - q * S * eqT * norm_cdf(-d1);
    return g;
}

// ── Helper: build a standard pricing setup and compute GreeksResult ──

static GreeksResult compute_greeks(
    double S, double K, double T, double r, double sigma, double q,
    OptionType type, std::size_t N = 501, std::size_t Nt = 2000,
    double c = 20.0) {
    double s_max = 4.0 * K;
    SinhMesh mesh(K, 0.0, s_max, N, c);
    MarketParams mkt = {S, r, sigma, q};
    ContractParams con = {K, T, type};
    BoundaryConditions bc(con, mkt, mesh);
    GreeksCalculator calc(mesh, bc, Nt);
    return calc.compute();
}

// ── Delta tests ──────────────────────────────────────────────────────

TEST(greeks_delta_atm_call) {
    auto bs = bs_call_greeks(100, 100, 1.0, 0.05, 0.20);
    auto gr = compute_greeks(100, 100, 1.0, 0.05, 0.20, 0.0, OptionType::Call);
    test::assert_near(gr.delta, bs.delta, 0.005,
                      "ATM call delta: PDE=" + std::to_string(gr.delta)
                      + " BS=" + std::to_string(bs.delta));
}

TEST(greeks_delta_itm_call) {
    auto bs = bs_call_greeks(120, 100, 1.0, 0.05, 0.20);
    auto gr = compute_greeks(120, 100, 1.0, 0.05, 0.20, 0.0, OptionType::Call);
    test::assert_near(gr.delta, bs.delta, 0.005, "ITM call delta");
}

TEST(greeks_delta_otm_call) {
    auto bs = bs_call_greeks(80, 100, 1.0, 0.05, 0.20);
    auto gr = compute_greeks(80, 100, 1.0, 0.05, 0.20, 0.0, OptionType::Call);
    test::assert_near(gr.delta, bs.delta, 0.005, "OTM call delta");
}

TEST(greeks_delta_atm_put) {
    auto bs = bs_put_greeks(100, 100, 1.0, 0.05, 0.20);
    auto gr = compute_greeks(100, 100, 1.0, 0.05, 0.20, 0.0, OptionType::Put);
    test::assert_near(gr.delta, bs.delta, 0.005, "ATM put delta");
}

TEST(greeks_delta_call_between_0_and_1) {
    auto gr = compute_greeks(100, 100, 1.0, 0.05, 0.20, 0.0, OptionType::Call);
    test::assert_true(gr.delta > 0.0 && gr.delta < 1.0, "call delta in (0,1)");
}

TEST(greeks_delta_put_between_neg1_and_0) {
    auto gr = compute_greeks(100, 100, 1.0, 0.05, 0.20, 0.0, OptionType::Put);
    test::assert_true(gr.delta > -1.0 && gr.delta < 0.0, "put delta in (-1,0)");
}

TEST(greeks_delta_put_call_parity) {
    auto gc = compute_greeks(100, 100, 1.0, 0.05, 0.20, 0.0, OptionType::Call);
    auto gp = compute_greeks(100, 100, 1.0, 0.05, 0.20, 0.0, OptionType::Put);
    // Delta_C - Delta_P = e^{-qT} = 1.0 (q=0)
    test::assert_near(gc.delta - gp.delta, 1.0, 0.01, "delta put-call parity");
}

// ── Gamma tests ──────────────────────────────────────────────────────

TEST(greeks_gamma_atm_call) {
    auto bs = bs_call_greeks(100, 100, 1.0, 0.05, 0.20);
    auto gr = compute_greeks(100, 100, 1.0, 0.05, 0.20, 0.0, OptionType::Call);
    test::assert_near(gr.gamma, bs.gamma, 0.001,
                      "ATM call gamma: PDE=" + std::to_string(gr.gamma)
                      + " BS=" + std::to_string(bs.gamma));
}

TEST(greeks_gamma_same_for_call_and_put) {
    auto gc = compute_greeks(100, 100, 1.0, 0.05, 0.20, 0.0, OptionType::Call);
    auto gp = compute_greeks(100, 100, 1.0, 0.05, 0.20, 0.0, OptionType::Put);
    test::assert_near(gc.gamma, gp.gamma, 0.001, "gamma same for C and P");
}

TEST(greeks_gamma_nonnegative) {
    auto gr = compute_greeks(100, 100, 1.0, 0.05, 0.20, 0.0, OptionType::Call);
    test::assert_true(gr.gamma >= 0.0, "gamma must be non-negative");
}

TEST(greeks_gamma_peak_at_atm) {
    auto g_atm = compute_greeks(100, 100, 1.0, 0.05, 0.20, 0.0, OptionType::Call);
    auto g_itm = compute_greeks(130, 100, 1.0, 0.05, 0.20, 0.0, OptionType::Call);
    auto g_otm = compute_greeks(70, 100, 1.0, 0.05, 0.20, 0.0, OptionType::Call);
    test::assert_true(g_atm.gamma > g_itm.gamma, "gamma peaks near ATM (vs ITM)");
    test::assert_true(g_atm.gamma > g_otm.gamma, "gamma peaks near ATM (vs OTM)");
}

// ── Theta tests ──────────────────────────────────────────────────────

TEST(greeks_theta_atm_call) {
    auto bs = bs_call_greeks(100, 100, 1.0, 0.05, 0.20);
    auto gr = compute_greeks(100, 100, 1.0, 0.05, 0.20, 0.0, OptionType::Call);
    test::assert_near(gr.theta, bs.theta, 0.15,
                      "ATM call theta: PDE=" + std::to_string(gr.theta)
                      + " BS=" + std::to_string(bs.theta));
}

TEST(greeks_theta_call_negative) {
    auto gr = compute_greeks(100, 100, 1.0, 0.05, 0.20, 0.0, OptionType::Call);
    test::assert_true(gr.theta < 0.0, "call theta should be negative (time decay)");
}

TEST(greeks_theta_pde_identity) {
    double S = 100, sigma = 0.2, r = 0.05, q = 0.0;
    auto gr = compute_greeks(S, 100, 1.0, r, sigma, q, OptionType::Call);
    double theta_check = r * gr.price - (r - q) * S * gr.delta
                       - 0.5 * sigma * sigma * S * S * gr.gamma;
    test::assert_near(gr.theta, theta_check, 1e-10,
                      "theta must satisfy PDE identity exactly");
}

// ── Delta surface properties ─────────────────────────────────────────

TEST(greeks_delta_surface_size) {
    SinhMesh mesh(100, 0, 400, 201, 20);
    MarketParams mkt = {100, 0.05, 0.20, 0.0};
    ContractParams con = {100, 1.0, OptionType::Call};
    BoundaryConditions bc(con, mkt, mesh);
    GreeksCalculator calc(mesh, bc, 500);
    auto res = calc.compute();
    test::assert_true(res.delta_surface.size() == 201, "delta surface size");
    test::assert_true(res.gamma_surface.size() == 201, "gamma surface size");
}

TEST(greeks_call_delta_surface_monotone) {
    auto gr = compute_greeks(100, 100, 1.0, 0.05, 0.20, 0.0, OptionType::Call);
    // Call delta should be roughly non-decreasing in S (not exactly, but close)
    // We check that it goes from ~0 at S_min to ~1 at S_max
    test::assert_true(gr.delta_surface.front() < 0.1, "call delta near S=0 should be small");
    test::assert_true(gr.delta_surface.back() > 0.9, "call delta near S_max should be ~1");
}

// ── Dividend support ─────────────────────────────────────────────────

TEST(greeks_delta_call_with_dividend) {
    auto bs = bs_call_greeks(100, 100, 1.0, 0.05, 0.20, 0.02);
    auto gr = compute_greeks(100, 100, 1.0, 0.05, 0.20, 0.02, OptionType::Call);
    test::assert_near(gr.delta, bs.delta, 0.005,
                      "call delta with q=0.02");
}

TEST(greeks_gamma_call_with_dividend) {
    auto bs = bs_call_greeks(100, 100, 1.0, 0.05, 0.20, 0.02);
    auto gr = compute_greeks(100, 100, 1.0, 0.05, 0.20, 0.02, OptionType::Call);
    test::assert_near(gr.gamma, bs.gamma, 0.001, "call gamma with q=0.02");
}

int main() { RUN_TESTS(); }
