#include "test_harness.hpp"
#include "nabla/nabla.hpp"
#include <cmath>
#include <iostream>

using namespace nabla;

static const double PI = 3.14159265358979323846;

static double norm_cdf(double x) {
    return 0.5 * std::erfc(-x / std::sqrt(2.0));
}

static double norm_pdf(double x) {
    return std::exp(-0.5 * x * x) / std::sqrt(2.0 * PI);
}

struct BSGreeks {
    double price, delta, gamma, vega, rho, theta;
};

static BSGreeks bs_call_greeks(double S, double K, double T,
                               double r, double sigma, double q = 0.0) {
    double d1 = (std::log(S / K) + (r - q + 0.5 * sigma * sigma) * T)
              / (sigma * std::sqrt(T));
    double d2 = d1 - sigma * std::sqrt(T);
    double eqT = std::exp(-q * T);
    double erT = std::exp(-r * T);
    BSGreeks g;
    g.price = S * eqT * norm_cdf(d1) - K * erT * norm_cdf(d2);
    g.delta = eqT * norm_cdf(d1);
    g.gamma = eqT * norm_pdf(d1) / (S * sigma * std::sqrt(T));
    g.vega  = S * eqT * norm_pdf(d1) * std::sqrt(T);
    g.rho   = K * T * erT * norm_cdf(d2);
    g.theta = -eqT * S * norm_pdf(d1) * sigma / (2.0 * std::sqrt(T))
              - r * K * erT * norm_cdf(d2) + q * S * eqT * norm_cdf(d1);
    return g;
}

static BSGreeks bs_put_greeks(double S, double K, double T,
                              double r, double sigma, double q = 0.0) {
    double d1 = (std::log(S / K) + (r - q + 0.5 * sigma * sigma) * T)
              / (sigma * std::sqrt(T));
    double d2 = d1 - sigma * std::sqrt(T);
    double eqT = std::exp(-q * T);
    double erT = std::exp(-r * T);
    BSGreeks g;
    g.price = K * erT * norm_cdf(-d2) - S * eqT * norm_cdf(-d1);
    g.delta = -eqT * norm_cdf(-d1);
    g.gamma = eqT * norm_pdf(d1) / (S * sigma * std::sqrt(T));
    g.vega  = S * eqT * norm_pdf(d1) * std::sqrt(T);
    g.rho   = -K * T * erT * norm_cdf(-d2);
    g.theta = -eqT * S * norm_pdf(d1) * sigma / (2.0 * std::sqrt(T))
              + r * K * erT * norm_cdf(-d2) - q * S * eqT * norm_cdf(-d1);
    return g;
}

// Helper: compute AAD Greeks for a given setup
static GreeksResult compute_aad(
    double S, double K, double T, double r, double sigma, double q,
    OptionType type, std::size_t N = 501, std::size_t Nt = 2000,
    double c = 20.0) {
    double s_max = 4.0 * K;
    SinhMesh mesh(K, 0.0, s_max, N, c);
    MarketParams mkt = {S, r, sigma, q};
    ContractParams con = {K, T, type};
    BoundaryConditions bc(con, mkt, mesh);
    GreeksCalculator calc(mesh, bc, Nt);
    return calc.compute();
}

// Helper: compute bump-and-revalue
static BumpGreeks compute_bump(
    double S, double K, double T, double r, double sigma, double q,
    OptionType type, std::size_t N = 501, std::size_t Nt = 2000,
    double c = 20.0) {
    double s_max = 4.0 * K;
    SinhMesh mesh(K, 0.0, s_max, N, c);
    MarketParams mkt = {S, r, sigma, q};
    ContractParams con = {K, T, type};
    return GreeksCalculator::bump_and_revalue(mesh, con, mkt, Nt);
}

// ── AAD Vega vs analytical BS ────────────────────────────────────────

TEST(aad_vega_atm_call_vs_bs) {
    auto bs = bs_call_greeks(100, 100, 1.0, 0.05, 0.20);
    auto gr = compute_aad(100, 100, 1.0, 0.05, 0.20, 0.0, OptionType::Call);
    test::assert_near(gr.vega, bs.vega, 0.5,
                      "AAD vega call: PDE=" + std::to_string(gr.vega)
                      + " BS=" + std::to_string(bs.vega));
}

TEST(aad_vega_atm_put_vs_bs) {
    auto bs = bs_put_greeks(100, 100, 1.0, 0.05, 0.20);
    auto gr = compute_aad(100, 100, 1.0, 0.05, 0.20, 0.0, OptionType::Put);
    test::assert_near(gr.vega, bs.vega, 0.5,
                      "AAD vega put: PDE=" + std::to_string(gr.vega)
                      + " BS=" + std::to_string(bs.vega));
}

TEST(aad_vega_call_positive) {
    auto gr = compute_aad(100, 100, 1.0, 0.05, 0.20, 0.0, OptionType::Call);
    test::assert_true(gr.vega > 0.0, "vega must be positive for long options");
}

TEST(aad_vega_put_positive) {
    auto gr = compute_aad(100, 100, 1.0, 0.05, 0.20, 0.0, OptionType::Put);
    test::assert_true(gr.vega > 0.0, "put vega must be positive");
}

TEST(aad_vega_call_equals_put) {
    auto gc = compute_aad(100, 100, 1.0, 0.05, 0.20, 0.0, OptionType::Call);
    auto gp = compute_aad(100, 100, 1.0, 0.05, 0.20, 0.0, OptionType::Put);
    test::assert_near(gc.vega, gp.vega, 0.5,
                      "call and put vega should be approximately equal");
}

// ── AAD Rho vs analytical BS ─────────────────────────────────────────

TEST(aad_rho_atm_call_vs_bs) {
    auto bs = bs_call_greeks(100, 100, 1.0, 0.05, 0.20);
    auto gr = compute_aad(100, 100, 1.0, 0.05, 0.20, 0.0, OptionType::Call);
    test::assert_near(gr.rho, bs.rho, 1.0,
                      "AAD rho call: PDE=" + std::to_string(gr.rho)
                      + " BS=" + std::to_string(bs.rho));
}

TEST(aad_rho_atm_put_vs_bs) {
    auto bs = bs_put_greeks(100, 100, 1.0, 0.05, 0.20);
    auto gr = compute_aad(100, 100, 1.0, 0.05, 0.20, 0.0, OptionType::Put);
    test::assert_near(gr.rho, bs.rho, 1.0,
                      "AAD rho put: PDE=" + std::to_string(gr.rho)
                      + " BS=" + std::to_string(bs.rho));
}

TEST(aad_rho_call_positive) {
    auto gr = compute_aad(100, 100, 1.0, 0.05, 0.20, 0.0, OptionType::Call);
    test::assert_true(gr.rho > 0.0, "call rho should be positive");
}

TEST(aad_rho_put_negative) {
    auto gr = compute_aad(100, 100, 1.0, 0.05, 0.20, 0.0, OptionType::Put);
    test::assert_true(gr.rho < 0.0, "put rho should be negative");
}

// ── AAD vs Bump-and-Revalue cross-validation ─────────────────────────

TEST(aad_vega_vs_bump_call) {
    auto aad = compute_aad(100, 100, 1.0, 0.05, 0.20, 0.0, OptionType::Call);
    auto bump = compute_bump(100, 100, 1.0, 0.05, 0.20, 0.0, OptionType::Call);
    test::assert_near(aad.vega, bump.vega, 1.0,
                      "AAD vega=" + std::to_string(aad.vega)
                      + " bump=" + std::to_string(bump.vega));
}

TEST(aad_rho_vs_bump_call) {
    auto aad = compute_aad(100, 100, 1.0, 0.05, 0.20, 0.0, OptionType::Call);
    auto bump = compute_bump(100, 100, 1.0, 0.05, 0.20, 0.0, OptionType::Call);
    test::assert_near(aad.rho, bump.rho, 1.0,
                      "AAD rho=" + std::to_string(aad.rho)
                      + " bump=" + std::to_string(bump.rho));
}

TEST(aad_vega_vs_bump_put) {
    auto aad = compute_aad(100, 100, 1.0, 0.05, 0.20, 0.0, OptionType::Put);
    auto bump = compute_bump(100, 100, 1.0, 0.05, 0.20, 0.0, OptionType::Put);
    test::assert_near(aad.vega, bump.vega, 1.0,
                      "AAD vega put=" + std::to_string(aad.vega)
                      + " bump=" + std::to_string(bump.vega));
}

TEST(aad_rho_vs_bump_put) {
    auto aad = compute_aad(100, 100, 1.0, 0.05, 0.20, 0.0, OptionType::Put);
    auto bump = compute_bump(100, 100, 1.0, 0.05, 0.20, 0.0, OptionType::Put);
    test::assert_near(aad.rho, bump.rho, 1.0,
                      "AAD rho put=" + std::to_string(aad.rho)
                      + " bump=" + std::to_string(bump.rho));
}

// ── Bump-and-revalue sanity checks ───────────────────────────────────

TEST(bump_delta_vs_bs) {
    auto bs = bs_call_greeks(100, 100, 1.0, 0.05, 0.20);
    auto bump = compute_bump(100, 100, 1.0, 0.05, 0.20, 0.0, OptionType::Call);
    test::assert_near(bump.delta, bs.delta, 0.005, "bump delta vs BS");
}

TEST(bump_gamma_vs_bs) {
    auto bs = bs_call_greeks(100, 100, 1.0, 0.05, 0.20);
    auto bump = compute_bump(100, 100, 1.0, 0.05, 0.20, 0.0, OptionType::Call);
    test::assert_near(bump.gamma, bs.gamma, 0.001, "bump gamma vs BS");
}

TEST(bump_vega_vs_bs) {
    auto bs = bs_call_greeks(100, 100, 1.0, 0.05, 0.20);
    auto bump = compute_bump(100, 100, 1.0, 0.05, 0.20, 0.0, OptionType::Call);
    test::assert_near(bump.vega, bs.vega, 0.3, "bump vega vs BS");
}

TEST(bump_rho_vs_bs) {
    auto bs = bs_call_greeks(100, 100, 1.0, 0.05, 0.20);
    auto bump = compute_bump(100, 100, 1.0, 0.05, 0.20, 0.0, OptionType::Call);
    test::assert_near(bump.rho, bs.rho, 0.5, "bump rho vs BS");
}

// ── Dividend yield support ───────────────────────────────────────────

TEST(aad_vega_with_dividend) {
    auto bs = bs_call_greeks(100, 100, 1.0, 0.05, 0.20, 0.02);
    auto gr = compute_aad(100, 100, 1.0, 0.05, 0.20, 0.02, OptionType::Call);
    test::assert_near(gr.vega, bs.vega, 0.5,
                      "AAD vega with q=0.02: PDE=" + std::to_string(gr.vega)
                      + " BS=" + std::to_string(bs.vega));
}

int main() { RUN_TESTS(); }
