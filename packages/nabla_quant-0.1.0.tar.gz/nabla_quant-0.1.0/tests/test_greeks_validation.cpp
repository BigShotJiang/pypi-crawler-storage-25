#include "test_harness.hpp"
#include "nabla/nabla.hpp"
#include <cmath>
#include <stdexcept>

using namespace nabla;

static const double PI = 3.14159265358979323846;

static double norm_cdf(double x) {
    return 0.5 * std::erfc(-x / std::sqrt(2.0));
}
static double norm_pdf(double x) {
    return std::exp(-0.5 * x * x) / std::sqrt(2.0 * PI);
}

struct BSGreeks {
    double price, delta, gamma, vega, rho, theta;
};

static BSGreeks bs_call(double S, double K, double T,
                        double r, double sigma, double q = 0.0) {
    double d1 = (std::log(S / K) + (r - q + 0.5 * sigma * sigma) * T)
              / (sigma * std::sqrt(T));
    double d2 = d1 - sigma * std::sqrt(T);
    double eqT = std::exp(-q * T);
    double erT = std::exp(-r * T);
    BSGreeks g;
    g.price = S * eqT * norm_cdf(d1) - K * erT * norm_cdf(d2);
    g.delta = eqT * norm_cdf(d1);
    g.gamma = eqT * norm_pdf(d1) / (S * sigma * std::sqrt(T));
    g.vega  = S * eqT * norm_pdf(d1) * std::sqrt(T);
    g.rho   = K * T * erT * norm_cdf(d2);
    g.theta = -eqT * S * norm_pdf(d1) * sigma / (2.0 * std::sqrt(T))
              - r * K * erT * norm_cdf(d2) + q * S * eqT * norm_cdf(d1);
    return g;
}

static BSGreeks bs_put(double S, double K, double T,
                       double r, double sigma, double q = 0.0) {
    double d1 = (std::log(S / K) + (r - q + 0.5 * sigma * sigma) * T)
              / (sigma * std::sqrt(T));
    double d2 = d1 - sigma * std::sqrt(T);
    double eqT = std::exp(-q * T);
    double erT = std::exp(-r * T);
    BSGreeks g;
    g.price = K * erT * norm_cdf(-d2) - S * eqT * norm_cdf(-d1);
    g.delta = -eqT * norm_cdf(-d1);
    g.gamma = eqT * norm_pdf(d1) / (S * sigma * std::sqrt(T));
    g.vega  = S * eqT * norm_pdf(d1) * std::sqrt(T);
    g.rho   = -K * T * erT * norm_cdf(-d2);
    g.theta = -eqT * S * norm_pdf(d1) * sigma / (2.0 * std::sqrt(T))
              + r * K * erT * norm_cdf(-d2) - q * S * eqT * norm_cdf(-d1);
    return g;
}

static GreeksResult compute_greeks(
    double S, double K, double T, double r, double sigma, double q,
    OptionType type, std::size_t N = 501, std::size_t Nt = 2000) {
    double s_max = 4.0 * K;
    SinhMesh mesh(K, 0.0, s_max, N, K / 5.0);
    MarketParams mkt = {S, r, sigma, q};
    ContractParams con = {K, T, type};
    BoundaryConditions bc(con, mkt, mesh);
    GreeksCalculator calc(mesh, bc, Nt);
    return calc.compute();
}

// ══════════════════════════════════════════════════════════════════════
// Deep OTM / Deep ITM - Greeks approach their asymptotic limits
// ══════════════════════════════════════════════════════════════════════

TEST(val_deep_otm_call_delta_near_zero) {
    auto gr = compute_greeks(50, 100, 1.0, 0.05, 0.20, 0.0, OptionType::Call);
    test::assert_true(gr.delta < 0.05, "deep OTM call delta should be near zero");
    test::assert_true(gr.gamma >= 0.0, "gamma non-negative");
}

TEST(val_deep_itm_call_delta_near_one) {
    auto gr = compute_greeks(200, 100, 1.0, 0.05, 0.20, 0.0, OptionType::Call);
    test::assert_true(gr.delta > 0.95, "deep ITM call delta should be near 1.0");
}

TEST(val_deep_otm_put_delta_near_zero) {
    auto gr = compute_greeks(200, 100, 1.0, 0.05, 0.20, 0.0, OptionType::Put);
    test::assert_true(gr.delta > -0.05, "deep OTM put delta should be near 0");
}

TEST(val_deep_itm_put_delta_near_neg_one) {
    auto gr = compute_greeks(50, 100, 1.0, 0.05, 0.20, 0.0, OptionType::Put);
    test::assert_true(gr.delta < -0.90, "deep ITM put delta should be near -1");
}

TEST(val_deep_otm_gamma_small) {
    auto gc = compute_greeks(50, 100, 1.0, 0.05, 0.20, 0.0, OptionType::Call);
    auto gp = compute_greeks(200, 100, 1.0, 0.05, 0.20, 0.0, OptionType::Put);
    test::assert_true(gc.gamma < 0.005, "deep OTM call gamma should be small");
    test::assert_true(gp.gamma < 0.005, "deep OTM put gamma should be small");
}

TEST(val_deep_otm_vega_small) {
    auto gr = compute_greeks(50, 100, 1.0, 0.05, 0.20, 0.0, OptionType::Call);
    auto bs = bs_call(50, 100, 1.0, 0.05, 0.20, 0.0);
    test::assert_true(gr.vega < 5.0, "deep OTM vega should be small");
    test::assert_near(gr.vega, bs.vega, 1.0, "deep OTM vega vs BS");
}

// ══════════════════════════════════════════════════════════════════════
// Rho put-call parity: ρ_C − ρ_P = K·T·e^{−rT}
// ══════════════════════════════════════════════════════════════════════

TEST(val_rho_put_call_parity) {
    double K = 100, T = 1.0, r = 0.05;
    auto gc = compute_greeks(100, K, T, r, 0.20, 0.0, OptionType::Call);
    auto gp = compute_greeks(100, K, T, r, 0.20, 0.0, OptionType::Put);
    double expected = K * T * std::exp(-r * T);
    test::assert_near(gc.rho - gp.rho, expected, 1.5,
                      "rho put-call parity: diff=" + std::to_string(gc.rho - gp.rho)
                      + " expected=" + std::to_string(expected));
}

TEST(val_rho_put_call_parity_with_dividend) {
    double K = 100, T = 1.0, r = 0.05, q = 0.03;
    auto gc = compute_greeks(100, K, T, r, 0.20, q, OptionType::Call);
    auto gp = compute_greeks(100, K, T, r, 0.20, q, OptionType::Put);
    double expected = K * T * std::exp(-r * T);
    test::assert_near(gc.rho - gp.rho, expected, 2.0,
                      "rho parity with dividends");
}

// ══════════════════════════════════════════════════════════════════════
// Zero rate edge case
// ══════════════════════════════════════════════════════════════════════

TEST(val_zero_rate_greeks) {
    double r = 0.0;
    auto bs = bs_call(100, 100, 1.0, r, 0.20, 0.0);
    auto gr = compute_greeks(100, 100, 1.0, r, 0.20, 0.0, OptionType::Call);
    test::assert_near(gr.price, bs.price, 0.05, "zero-rate price");
    test::assert_near(gr.delta, bs.delta, 0.01, "zero-rate delta");
    test::assert_near(gr.gamma, bs.gamma, 0.001, "zero-rate gamma");
    test::assert_true(gr.vega > 0.0, "zero-rate vega still positive");
    test::assert_near(gr.rho, bs.rho, 1.0, "zero-rate rho");
}

// ══════════════════════════════════════════════════════════════════════
// High volatility stress test
// ══════════════════════════════════════════════════════════════════════

TEST(val_high_vol_call_greeks) {
    double sigma = 0.80;
    auto bs = bs_call(100, 100, 1.0, 0.05, sigma, 0.0);
    auto gr = compute_greeks(100, 100, 1.0, 0.05, sigma, 0.0,
                             OptionType::Call, 501, 2000);
    test::assert_near(gr.delta, bs.delta, 0.01, "high-vol delta");
    test::assert_near(gr.gamma, bs.gamma, 0.002, "high-vol gamma");
    test::assert_near(gr.vega, bs.vega, 1.5, "high-vol vega");
}

TEST(val_high_vol_put_greeks) {
    double sigma = 0.80;
    auto bs = bs_put(100, 100, 1.0, 0.05, sigma, 0.0);
    auto gr = compute_greeks(100, 100, 1.0, 0.05, sigma, 0.0,
                             OptionType::Put, 501, 2000);
    test::assert_near(gr.delta, bs.delta, 0.01, "high-vol put delta");
    test::assert_near(gr.vega, bs.vega, 1.5, "high-vol put vega");
}

// ══════════════════════════════════════════════════════════════════════
// Low volatility - Greeks behaviour
// ══════════════════════════════════════════════════════════════════════

TEST(val_low_vol_itm_call_delta_near_one) {
    double sigma = 0.05;
    auto gr = compute_greeks(110, 100, 1.0, 0.05, sigma, 0.0,
                             OptionType::Call, 501, 2000);
    test::assert_true(gr.delta > 0.90, "low vol ITM call delta should be near 1");
}

TEST(val_low_vol_otm_call_delta_near_zero) {
    double sigma = 0.05;
    auto gr = compute_greeks(90, 100, 1.0, 0.05, sigma, 0.0,
                             OptionType::Call, 501, 2000);
    test::assert_true(gr.delta < 0.15, "low vol OTM call delta should be near 0");
}

// ══════════════════════════════════════════════════════════════════════
// Long maturity - Greeks still consistent
// ══════════════════════════════════════════════════════════════════════

TEST(val_long_maturity_greeks) {
    double T = 5.0;
    auto bs = bs_call(100, 100, T, 0.05, 0.20, 0.0);
    auto gr = compute_greeks(100, 100, T, 0.05, 0.20, 0.0,
                             OptionType::Call, 501, 2000);
    test::assert_near(gr.price, bs.price, 0.2, "long maturity price");
    test::assert_near(gr.delta, bs.delta, 0.01, "long maturity delta");
    test::assert_true(gr.vega > 0.0, "long maturity vega positive");
    test::assert_true(gr.rho > 0.0, "long maturity rho positive (call)");
}

// ══════════════════════════════════════════════════════════════════════
// High dividend yield
// ══════════════════════════════════════════════════════════════════════

TEST(val_high_dividend_call) {
    double q = 0.08;
    auto bs = bs_call(100, 100, 1.0, 0.05, 0.20, q);
    auto gr = compute_greeks(100, 100, 1.0, 0.05, 0.20, q, OptionType::Call);
    test::assert_near(gr.delta, bs.delta, 0.01, "high-div delta");
    test::assert_near(gr.gamma, bs.gamma, 0.002, "high-div gamma");
    test::assert_near(gr.vega, bs.vega, 0.8, "high-div vega");
}

TEST(val_high_dividend_put) {
    double q = 0.08;
    auto bs = bs_put(100, 100, 1.0, 0.05, 0.20, q);
    auto gr = compute_greeks(100, 100, 1.0, 0.05, 0.20, q, OptionType::Put);
    test::assert_near(gr.delta, bs.delta, 0.01, "high-div put delta");
    test::assert_near(gr.vega, bs.vega, 0.8, "high-div put vega");
}

// ══════════════════════════════════════════════════════════════════════
// Gamma identical for call/put with dividends
// ══════════════════════════════════════════════════════════════════════

TEST(val_gamma_call_equals_put_with_dividend) {
    double q = 0.04;
    auto gc = compute_greeks(100, 100, 1.0, 0.05, 0.20, q, OptionType::Call);
    auto gp = compute_greeks(100, 100, 1.0, 0.05, 0.20, q, OptionType::Put);
    test::assert_near(gc.gamma, gp.gamma, 0.001, "Γ_C = Γ_P with dividends");
}

// ══════════════════════════════════════════════════════════════════════
// Vega call = vega put (with dividends)
// ══════════════════════════════════════════════════════════════════════

TEST(val_vega_call_equals_put_with_dividend) {
    double q = 0.04;
    auto gc = compute_greeks(100, 100, 1.0, 0.05, 0.20, q, OptionType::Call);
    auto gp = compute_greeks(100, 100, 1.0, 0.05, 0.20, q, OptionType::Put);
    test::assert_near(gc.vega, gp.vega, 1.0, "ν_C ≈ ν_P with dividends");
}

// ══════════════════════════════════════════════════════════════════════
// Delta put-call parity with dividends: Δ_C − Δ_P = e^{−qT}
// ══════════════════════════════════════════════════════════════════════

TEST(val_delta_put_call_parity_with_dividend) {
    double q = 0.04, T = 1.0;
    auto gc = compute_greeks(100, 100, T, 0.05, 0.20, q, OptionType::Call);
    auto gp = compute_greeks(100, 100, T, 0.05, 0.20, q, OptionType::Put);
    double expected = std::exp(-q * T);
    test::assert_near(gc.delta - gp.delta, expected, 0.015,
                      "Δ_C − Δ_P = e^{-qT}");
}

// ══════════════════════════════════════════════════════════════════════
// Near-expiry behaviour
// ══════════════════════════════════════════════════════════════════════

TEST(val_near_expiry_atm_delta_approx_half) {
    double T = 0.005;
    auto gr = compute_greeks(100, 100, T, 0.05, 0.20, 0.0,
                             OptionType::Call, 501, 500);
    test::assert_true(std::fabs(gr.delta - 0.5) < 0.15,
                      "near-expiry ATM call delta ≈ 0.5");
}

TEST(val_near_expiry_gamma_large) {
    double T = 0.005;
    auto gr = compute_greeks(100, 100, T, 0.05, 0.20, 0.0,
                             OptionType::Call, 501, 500);
    auto bs = bs_call(100, 100, T, 0.05, 0.20, 0.0);
    test::assert_true(gr.gamma > 0.05,
                      "near-expiry gamma should be large");
    test::assert_true(gr.gamma > bs.gamma * 0.5,
                      "near-expiry gamma in right ballpark");
}

// ══════════════════════════════════════════════════════════════════════
// Convergence with refinement - Delta/Gamma tighten
// ══════════════════════════════════════════════════════════════════════

TEST(val_delta_convergence_with_refinement) {
    auto bs = bs_call(100, 100, 1.0, 0.05, 0.20, 0.0);
    auto gr_coarse = compute_greeks(100, 100, 1.0, 0.05, 0.20, 0.0,
                                    OptionType::Call, 101, 200);
    auto gr_fine   = compute_greeks(100, 100, 1.0, 0.05, 0.20, 0.0,
                                    OptionType::Call, 501, 2000);
    double err_c = std::fabs(gr_coarse.delta - bs.delta);
    double err_f = std::fabs(gr_fine.delta - bs.delta);
    test::assert_true(err_f < err_c, "delta converges with refinement");
}

TEST(val_gamma_convergence_with_refinement) {
    auto bs = bs_call(100, 100, 1.0, 0.05, 0.20, 0.0);
    auto gr_coarse = compute_greeks(100, 100, 1.0, 0.05, 0.20, 0.0,
                                    OptionType::Call, 101, 200);
    auto gr_fine   = compute_greeks(100, 100, 1.0, 0.05, 0.20, 0.0,
                                    OptionType::Call, 501, 2000);
    double err_c = std::fabs(gr_coarse.gamma - bs.gamma);
    double err_f = std::fabs(gr_fine.gamma - bs.gamma);
    test::assert_true(err_f < err_c, "gamma converges with refinement");
}

// ══════════════════════════════════════════════════════════════════════
// AAD stability: many time steps don't blow up
// ══════════════════════════════════════════════════════════════════════

TEST(val_aad_stable_with_many_steps) {
    auto bs = bs_call(100, 100, 1.0, 0.05, 0.20, 0.0);
    auto gr = compute_greeks(100, 100, 1.0, 0.05, 0.20, 0.0,
                             OptionType::Call, 201, 5000);
    test::assert_near(gr.vega, bs.vega, 1.0,
                      "AAD vega stable with 5000 time steps");
    test::assert_near(gr.rho, bs.rho, 1.5,
                      "AAD rho stable with 5000 time steps");
}

// ══════════════════════════════════════════════════════════════════════
// Theta sign conventions
// ══════════════════════════════════════════════════════════════════════

TEST(val_theta_negative_for_long_put) {
    auto gr = compute_greeks(100, 100, 1.0, 0.05, 0.20, 0.0, OptionType::Put);
    test::assert_true(gr.theta < 0.0,
                      "long ATM put theta should be negative (time decay)");
}

TEST(val_theta_atm_put_vs_bs) {
    auto bs = bs_put(100, 100, 1.0, 0.05, 0.20, 0.0);
    auto gr = compute_greeks(100, 100, 1.0, 0.05, 0.20, 0.0, OptionType::Put);
    test::assert_near(gr.theta, bs.theta, 0.15, "ATM put theta vs BS");
}

// ══════════════════════════════════════════════════════════════════════
// Exceptional inputs: constructor validation
// ══════════════════════════════════════════════════════════════════════

TEST(val_throws_on_too_few_nodes) {
    test::assert_throws([] {
        SinhMesh mesh(100, 0, 400, 2, 20);
        MarketParams mkt = {100, 0.05, 0.20, 0.0};
        ContractParams con = {100, 1.0, OptionType::Call};
        BoundaryConditions bc(con, mkt, mesh);
        GreeksCalculator calc(mesh, bc, 100);
    }, "should throw with only 2 nodes");
}

TEST(val_throws_on_zero_time_steps) {
    test::assert_throws([] {
        SinhMesh mesh(100, 0, 400, 101, 20);
        MarketParams mkt = {100, 0.05, 0.20, 0.0};
        ContractParams con = {100, 1.0, OptionType::Call};
        BoundaryConditions bc(con, mkt, mesh);
        GreeksCalculator calc(mesh, bc, 0);
    }, "should throw with 0 time steps");
}

// ══════════════════════════════════════════════════════════════════════
// AAD vs bump cross-validation at ITM/OTM
// ══════════════════════════════════════════════════════════════════════

TEST(val_aad_vs_bump_itm_call) {
    double S = 120, K = 100, T = 1.0, r = 0.05, sigma = 0.20, q = 0.0;
    double s_max = 4.0 * K;
    SinhMesh mesh(K, 0.0, s_max, 501, K / 5.0);
    MarketParams mkt = {S, r, sigma, q};
    ContractParams con = {K, T, OptionType::Call};
    BoundaryConditions bc(con, mkt, mesh);

    GreeksCalculator calc(mesh, bc, 2000);
    auto aad = calc.compute();
    auto bump = GreeksCalculator::bump_and_revalue(mesh, con, mkt, 2000);

    test::assert_near(aad.vega, bump.vega, 1.5, "ITM call: AAD vega vs bump");
    test::assert_near(aad.rho, bump.rho, 2.0, "ITM call: AAD rho vs bump");
}

TEST(val_aad_vs_bump_otm_put) {
    double S = 120, K = 100, T = 1.0, r = 0.05, sigma = 0.20, q = 0.0;
    double s_max = 4.0 * K;
    SinhMesh mesh(K, 0.0, s_max, 501, K / 5.0);
    MarketParams mkt = {S, r, sigma, q};
    ContractParams con = {K, T, OptionType::Put};
    BoundaryConditions bc(con, mkt, mesh);

    GreeksCalculator calc(mesh, bc, 2000);
    auto aad = calc.compute();
    auto bump = GreeksCalculator::bump_and_revalue(mesh, con, mkt, 2000);

    test::assert_near(aad.vega, bump.vega, 1.0, "OTM put: AAD vega vs bump");
    test::assert_near(aad.rho, bump.rho, 1.5, "OTM put: AAD rho vs bump");
}

// ══════════════════════════════════════════════════════════════════════
// Non-standard strikes
// ══════════════════════════════════════════════════════════════════════

TEST(val_greeks_high_strike) {
    double K = 200, S = 200;
    auto bs = bs_call(S, K, 1.0, 0.05, 0.20, 0.0);
    auto gr = compute_greeks(S, K, 1.0, 0.05, 0.20, 0.0, OptionType::Call);
    test::assert_near(gr.delta, bs.delta, 0.01, "high strike ATM delta");
    test::assert_near(gr.gamma, bs.gamma, 0.001, "high strike ATM gamma");
}

TEST(val_greeks_low_strike) {
    double K = 20, S = 20;
    auto bs = bs_put(S, K, 1.0, 0.05, 0.20, 0.0);
    auto gr = compute_greeks(S, K, 1.0, 0.05, 0.20, 0.0, OptionType::Put);
    test::assert_near(gr.delta, bs.delta, 0.01, "low strike ATM put delta");
}

int main() { RUN_TESTS(); }
