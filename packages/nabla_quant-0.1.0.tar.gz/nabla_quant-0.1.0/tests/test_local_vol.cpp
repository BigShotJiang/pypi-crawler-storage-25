#include "test_harness.hpp"
#include "nabla/nabla.hpp"
#include <cmath>

using namespace nabla;

static double norm_cdf(double x) {
    return 0.5 * std::erfc(-x / std::sqrt(2.0));
}

static double bs_call(double S, double K, double T, double r, double sigma, double q = 0.0) {
    double d1 = (std::log(S / K) + (r - q + 0.5 * sigma * sigma) * T)
              / (sigma * std::sqrt(T));
    double d2 = d1 - sigma * std::sqrt(T);
    return S * std::exp(-q * T) * norm_cdf(d1)
         - K * std::exp(-r * T) * norm_cdf(d2);
}

// ── LocalVolSurface construction ─────────────────────────────────────

TEST(lv_flat_construction) {
    auto vol = LocalVolSurface::flat(0.2);
    test::assert_true(vol.is_constant());
    test::assert_near(vol.constant_vol(), 0.2, 1e-15);
    test::assert_near(vol(50.0, 0.5), 0.2, 1e-15);
    test::assert_near(vol(200.0, 1.0), 0.2, 1e-15);
}

TEST(lv_flat_rejects_nonpositive) {
    test::assert_throws([]{ LocalVolSurface::flat(0.0); });
    test::assert_throws([]{ LocalVolSurface::flat(-0.1); });
}

TEST(lv_cev_construction) {
    auto vol = LocalVolSurface::cev(0.2, 100.0, 0.5);
    test::assert_true(!vol.is_constant());

    // At S = S_ref, σ should equal sigma_ref
    test::assert_near(vol(100.0, 0.0), 0.2, 1e-14);

    // CEV with beta < 1: higher S => lower vol (leverage effect)
    test::assert_true(vol(150.0, 0.0) < vol(100.0, 0.0));
    test::assert_true(vol(50.0, 0.0) > vol(100.0, 0.0));
}

TEST(lv_skew_construction) {
    auto vol = LocalVolSurface::skew(0.2, 100.0, -0.1, 0.05);
    test::assert_true(!vol.is_constant());

    // At S = K, log(S/K) = 0 => σ ≈ sigma_atm + term_slope * sqrt(t)
    test::assert_near(vol(100.0, 0.0), 0.2, 1e-14);
    test::assert_near(vol(100.0, 1.0), 0.2 + 0.05, 1e-14);

    // Negative skew: lower S => higher vol
    test::assert_true(vol(80.0, 0.5) > vol(100.0, 0.5));
    test::assert_true(vol(120.0, 0.5) < vol(100.0, 0.5));
}

TEST(lv_custom_callable) {
    LocalVolSurface vol([](double S, double t) {
        return 0.15 + 0.05 * std::sin(S / 100.0) + 0.01 * t;
    });
    test::assert_true(!vol.is_constant());
    test::assert_true(vol(100.0, 0.0) > 0.0);
}

// ── Evaluate on mesh ─────────────────────────────────────────────────

TEST(lv_evaluate_flat) {
    auto vol = LocalVolSurface::flat(0.3);
    SinhMesh mesh(100.0, 0.0, 300.0, 201, 20.0);
    std::vector<double> out(mesh.size());
    vol.evaluate(mesh.spot_nodes().data(), mesh.size(), 0.5, out.data());
    for (auto v : out)
        test::assert_near(v, 0.3, 1e-15);
}

TEST(lv_evaluate_cev) {
    auto vol = LocalVolSurface::cev(0.2, 100.0, 0.5);
    SinhMesh mesh(100.0, 0.0, 300.0, 201, 20.0);
    std::vector<double> out(mesh.size());
    vol.evaluate(mesh.spot_nodes().data(), mesh.size(), 0.0, out.data());

    // All volatilities should be positive
    for (std::size_t i = 0; i < mesh.size(); ++i)
        test::assert_true(out[i] > 0.0,
                          "vol must be positive at node " + std::to_string(i));
}

// ── Flat local vol matches constant vol solver ───────────────────────

TEST(lv_flat_matches_constant_solver) {
    double S = 100.0, K = 100.0, T = 1.0, r = 0.05, sigma = 0.2;
    SinhMesh mesh(K, 0.0, 5.0 * K, 401, K / 8.0);
    BoundaryConditions bc({K, T, OptionType::Call}, {S, r, sigma, 0.0}, mesh);

    CrankNicolsonSolver const_solver(mesh, bc, 200);
    auto const_result = const_solver.solve();

    auto vol = LocalVolSurface::flat(sigma);
    CrankNicolsonSolver lv_solver(mesh, bc, 200, vol);
    auto lv_result = lv_solver.solve();

    test::assert_near(lv_result.price, const_result.price, 1e-10,
                      "flat local vol must match constant vol exactly");
}

// ── Local vol solver vs BS (flat) ────────────────────────────────────

TEST(lv_flat_solver_vs_bs) {
    double S = 100.0, K = 100.0, T = 1.0, r = 0.05, sigma = 0.2;
    SinhMesh mesh(K, 0.0, 5.0 * K, 801, K / 8.0);
    BoundaryConditions bc({K, T, OptionType::Call}, {S, r, sigma, 0.0}, mesh);

    auto vol = LocalVolSurface::flat(sigma);
    CrankNicolsonSolver solver(mesh, bc, 400, vol);
    auto result = solver.solve();

    double analytical = bs_call(S, K, T, r, sigma);
    test::assert_near(result.price, analytical, 0.05,
                      "flat LV vs BS: PDE=" + std::to_string(result.price) +
                      " BS=" + std::to_string(analytical));
}

// ── CEV pricing sanity checks ────────────────────────────────────────

TEST(lv_cev_positive_price) {
    double S = 100.0, K = 100.0, T = 1.0, r = 0.05;
    SinhMesh mesh(K, 0.0, 5.0 * K, 401, K / 8.0);
    auto vol = LocalVolSurface::cev(0.2, S, 0.5);
    BoundaryConditions bc({K, T, OptionType::Call}, {S, r, 0.2, 0.0}, mesh);

    CrankNicolsonSolver solver(mesh, bc, 200, vol);
    auto result = solver.solve();

    test::assert_true(result.price > 0.0, "CEV call price must be positive");
    test::assert_true(result.price < S, "CEV call price must be < spot");
}

TEST(lv_cev_leverage_effect) {
    // CEV with beta < 1: vol increases as S decreases (leverage effect)
    // Use OTM put (S=120, K=100) and strong leverage (beta=0.2)
    // so the vol surface deformation is significant
    double S = 120.0, K = 100.0, T = 1.0, r = 0.05, sigma = 0.25;
    SinhMesh mesh(K, 0.0, 5.0 * K, 801, K / 8.0);
    BoundaryConditions bc({K, T, OptionType::Put}, {S, r, sigma, 0.0}, mesh);

    // BS price (constant vol)
    CrankNicolsonSolver bs_solver(mesh, bc, 400);
    double bs_put_price = bs_solver.solve().price;

    // CEV with beta = 0.2 (strong leverage)
    auto vol = LocalVolSurface::cev(sigma, S, 0.2);
    CrankNicolsonSolver cev_solver(mesh, bc, 400, vol);
    double cev_put_price = cev_solver.solve().price;

    test::assert_true(cev_put_price > 0.0, "CEV put must be positive");
    // With strong leverage, CEV model produces a meaningful price difference
    // Direction: CEV raises vol for S < S_ref, so OTM puts become more expensive
    test::assert_true(cev_put_price > bs_put_price,
                      "CEV put should be more expensive than BS put (leverage effect)");
}

// ── Skew model pricing ───────────────────────────────────────────────

TEST(lv_skew_positive_prices) {
    double S = 100.0, K = 100.0, T = 1.0, r = 0.05;
    SinhMesh mesh(K, 0.0, 5.0 * K, 401, K / 8.0);
    auto vol = LocalVolSurface::skew(0.2, K, -0.1, 0.02);
    BoundaryConditions bc({K, T, OptionType::Call}, {S, r, 0.2, 0.0}, mesh);

    CrankNicolsonSolver solver(mesh, bc, 200, vol);
    auto result = solver.solve();

    test::assert_true(result.price > 0.0, "skew call price must be positive");
    test::assert_true(result.price < S, "skew call price must be < spot");
}

// ── Grid non-negativity under local vol ──────────────────────────────

TEST(lv_grid_nonnegative) {
    double S = 100.0, K = 100.0, T = 1.0, r = 0.05;
    SinhMesh mesh(K, 0.0, 5.0 * K, 401, K / 8.0);
    auto vol = LocalVolSurface::cev(0.2, S, 0.5);
    BoundaryConditions bc({K, T, OptionType::Call}, {S, r, 0.2, 0.0}, mesh);

    CrankNicolsonSolver solver(mesh, bc, 200, vol);
    auto result = solver.solve();

    for (std::size_t i = 0; i < result.grid.size(); ++i)
        test::assert_true(result.grid[i] >= -1e-8,
                          "option value non-negative at node " + std::to_string(i));
}

int main() { RUN_TESTS(); }
