#include "test_harness.hpp"
#include "nabla/nabla.hpp"
#include <cmath>

using namespace nabla;

static double norm_cdf(double x) {
    return 0.5 * std::erfc(-x / std::sqrt(2.0));
}

static double bs_put(double S, double K, double T, double r, double sigma, double q = 0.0) {
    double d1 = (std::log(S / K) + (r - q + 0.5 * sigma * sigma) * T)
              / (sigma * std::sqrt(T));
    double d2 = d1 - sigma * std::sqrt(T);
    return K * std::exp(-r * T) * norm_cdf(-d2)
         - S * std::exp(-q * T) * norm_cdf(-d1);
}

// ── American call (no dividend) = European call ──────────────────────

TEST(american_call_no_div_equals_european) {
    // Without dividends, early exercise of a call is never optimal,
    // so the American call price equals the European call price.
    double S = 100.0, K = 100.0, T = 1.0, r = 0.05, sigma = 0.2;
    SinhMesh mesh(K, 0.0, 5.0 * K, 801, K / 8.0);

    ContractParams eu_contract{K, T, OptionType::Call, ExerciseType::European};
    ContractParams am_contract{K, T, OptionType::Call, ExerciseType::American};
    MarketParams mkt{S, r, sigma, 0.0};

    BoundaryConditions eu_bc(eu_contract, mkt, mesh);
    BoundaryConditions am_bc(am_contract, mkt, mesh);

    CrankNicolsonSolver eu_solver(mesh, eu_bc, 400);
    CrankNicolsonSolver am_solver(mesh, am_bc, 400);

    double eu_price = eu_solver.solve().price;
    double am_price = am_solver.solve().price;

    test::assert_near(am_price, eu_price, 0.05,
                      "American call (no div) = European call: AM=" +
                      std::to_string(am_price) + " EU=" + std::to_string(eu_price));
}

// ── American put >= European put ─────────────────────────────────────

TEST(american_put_geq_european_put) {
    double S = 100.0, K = 100.0, T = 1.0, r = 0.05, sigma = 0.2;
    SinhMesh mesh(K, 0.0, 5.0 * K, 801, K / 8.0);

    ContractParams eu_contract{K, T, OptionType::Put, ExerciseType::European};
    ContractParams am_contract{K, T, OptionType::Put, ExerciseType::American};
    MarketParams mkt{S, r, sigma, 0.0};

    BoundaryConditions eu_bc(eu_contract, mkt, mesh);
    BoundaryConditions am_bc(am_contract, mkt, mesh);

    CrankNicolsonSolver eu_solver(mesh, eu_bc, 400);
    CrankNicolsonSolver am_solver(mesh, am_bc, 400);

    double eu_price = eu_solver.solve().price;
    double am_price = am_solver.solve().price;

    test::assert_true(am_price >= eu_price - 1e-8,
                      "American put >= European put: AM=" +
                      std::to_string(am_price) + " EU=" + std::to_string(eu_price));
}

// ── American put early exercise premium is positive ──────────────────

TEST(american_put_early_exercise_premium) {
    // For ITM puts, early exercise premium should be significant
    double S = 80.0, K = 100.0, T = 1.0, r = 0.05, sigma = 0.2;
    SinhMesh mesh(K, 0.0, 5.0 * K, 801, K / 8.0);

    ContractParams eu_contract{K, T, OptionType::Put, ExerciseType::European};
    ContractParams am_contract{K, T, OptionType::Put, ExerciseType::American};
    MarketParams mkt{S, r, sigma, 0.0};

    BoundaryConditions eu_bc(eu_contract, mkt, mesh);
    BoundaryConditions am_bc(am_contract, mkt, mesh);

    CrankNicolsonSolver eu_solver(mesh, eu_bc, 400);
    CrankNicolsonSolver am_solver(mesh, am_bc, 400);

    double eu_price = eu_solver.solve().price;
    double am_price = am_solver.solve().price;
    double premium = am_price - eu_price;

    test::assert_true(premium > 0.01,
                      "early exercise premium = " + std::to_string(premium));
}

// ── American option >= intrinsic value everywhere ────────────────────

TEST(american_put_geq_intrinsic) {
    double S = 100.0, K = 100.0, T = 1.0, r = 0.05, sigma = 0.2;
    SinhMesh mesh(K, 0.0, 5.0 * K, 801, K / 8.0);

    ContractParams contract{K, T, OptionType::Put, ExerciseType::American};
    MarketParams mkt{S, r, sigma, 0.0};
    BoundaryConditions bc(contract, mkt, mesh);

    CrankNicolsonSolver solver(mesh, bc, 400);
    auto result = solver.solve();

    const auto& nodes = mesh.spot_nodes();
    for (std::size_t i = 0; i < result.grid.size(); ++i) {
        double intrinsic = std::max(K - nodes[i], 0.0);
        test::assert_true(result.grid[i] >= intrinsic - 1e-6,
                          "American put >= intrinsic at S=" +
                          std::to_string(nodes[i]));
    }
}

TEST(american_call_geq_intrinsic) {
    double S = 100.0, K = 100.0, T = 1.0, r = 0.05, sigma = 0.2;
    SinhMesh mesh(K, 0.0, 5.0 * K, 801, K / 8.0);

    ContractParams contract{K, T, OptionType::Call, ExerciseType::American};
    MarketParams mkt{S, r, sigma, 0.0};
    BoundaryConditions bc(contract, mkt, mesh);

    CrankNicolsonSolver solver(mesh, bc, 400);
    auto result = solver.solve();

    const auto& nodes = mesh.spot_nodes();
    for (std::size_t i = 0; i < result.grid.size(); ++i) {
        double intrinsic = std::max(nodes[i] - K, 0.0);
        test::assert_true(result.grid[i] >= intrinsic - 1e-6,
                          "American call >= intrinsic at S=" +
                          std::to_string(nodes[i]));
    }
}

// ── American put price bounded by K ──────────────────────────────────

TEST(american_put_bounded_by_strike) {
    double S = 100.0, K = 100.0, T = 1.0, r = 0.05, sigma = 0.2;
    SinhMesh mesh(K, 0.0, 5.0 * K, 801, K / 8.0);

    ContractParams contract{K, T, OptionType::Put, ExerciseType::American};
    MarketParams mkt{S, r, sigma, 0.0};
    BoundaryConditions bc(contract, mkt, mesh);

    CrankNicolsonSolver solver(mesh, bc, 400);
    auto result = solver.solve();

    for (std::size_t i = 0; i < result.grid.size(); ++i)
        test::assert_true(result.grid[i] <= K + 1e-6,
                          "American put <= K at node " + std::to_string(i));
}

// ── Deep ITM American put ≈ intrinsic value ──────────────────────────

TEST(american_put_deep_itm_near_intrinsic) {
    // Very deep ITM (S << K), the American put should be exercised immediately,
    // so its value ≈ K - S
    double S = 30.0, K = 100.0, T = 1.0, r = 0.05, sigma = 0.2;
    SinhMesh mesh(K, 0.0, 5.0 * K, 801, K / 8.0);

    ContractParams contract{K, T, OptionType::Put, ExerciseType::American};
    MarketParams mkt{S, r, sigma, 0.0};
    BoundaryConditions bc(contract, mkt, mesh);

    CrankNicolsonSolver solver(mesh, bc, 400);
    double am_price = solver.solve().price;
    double intrinsic = K - S;

    // For very deep ITM, should be close to intrinsic
    test::assert_near(am_price, intrinsic, 1.0,
                      "deep ITM put ≈ intrinsic: price=" +
                      std::to_string(am_price) + " intrinsic=" +
                      std::to_string(intrinsic));
    test::assert_true(am_price >= intrinsic - 1e-6);
}

// ── American put convergence with refinement ─────────────────────────

TEST(american_put_convergence) {
    double S = 100.0, K = 100.0, T = 1.0, r = 0.05, sigma = 0.2;
    ContractParams contract{K, T, OptionType::Put, ExerciseType::American};
    MarketParams mkt{S, r, sigma, 0.0};

    double price_coarse, price_fine;
    {
        SinhMesh mesh(K, 0.0, 5.0 * K, 201, K / 8.0);
        BoundaryConditions bc(contract, mkt, mesh);
        CrankNicolsonSolver solver(mesh, bc, 100);
        price_coarse = solver.solve().price;
    }
    {
        SinhMesh mesh(K, 0.0, 5.0 * K, 801, K / 8.0);
        BoundaryConditions bc(contract, mkt, mesh);
        CrankNicolsonSolver solver(mesh, bc, 400);
        price_fine = solver.solve().price;
    }

    // Prices should converge (difference should be small)
    double diff = std::fabs(price_fine - price_coarse);
    test::assert_true(diff < 0.5,
                      "convergence: |fine-coarse| = " + std::to_string(diff));
}

// ── American put known benchmark (Barone-Adesi Whaley ≈ 6.08 for this case)

TEST(american_put_benchmark) {
    // Standard benchmark: S=100, K=100, T=1, r=0.05, sigma=0.2
    // Known American put ≈ 6.08 (from various sources)
    double S = 100.0, K = 100.0, T = 1.0, r = 0.05, sigma = 0.2;
    SinhMesh mesh(K, 0.0, 5.0 * K, 801, K / 8.0);

    ContractParams contract{K, T, OptionType::Put, ExerciseType::American};
    MarketParams mkt{S, r, sigma, 0.0};
    BoundaryConditions bc(contract, mkt, mesh);

    CrankNicolsonSolver solver(mesh, bc, 800);
    double price = solver.solve().price;

    // European put for reference
    double eu_price = bs_put(S, K, T, r, sigma);

    test::assert_true(price > eu_price,
                      "American > European: am=" + std::to_string(price) +
                      " eu=" + std::to_string(eu_price));
    // BAW approximation gives ~6.08, PDE should be within ~0.15
    test::assert_near(price, 6.08, 0.20,
                      "American put benchmark: price=" + std::to_string(price));
}

// ── American with local vol ──────────────────────────────────────────

TEST(american_put_with_local_vol) {
    double S = 100.0, K = 100.0, T = 1.0, r = 0.05, sigma = 0.2;
    SinhMesh mesh(K, 0.0, 5.0 * K, 401, K / 8.0);

    ContractParams contract{K, T, OptionType::Put, ExerciseType::American};
    MarketParams mkt{S, r, sigma, 0.0};
    BoundaryConditions bc(contract, mkt, mesh);

    auto vol = LocalVolSurface::cev(sigma, S, 0.5);
    CrankNicolsonSolver solver(mesh, bc, 200, vol);
    auto result = solver.solve();

    test::assert_true(result.price > 0.0, "American CEV put price > 0");

    // Verify intrinsic constraint
    const auto& nodes = mesh.spot_nodes();
    for (std::size_t i = 0; i < result.grid.size(); ++i) {
        double intrinsic = std::max(K - nodes[i], 0.0);
        test::assert_true(result.grid[i] >= intrinsic - 1e-6,
                          "CEV American put >= intrinsic");
    }
}

int main() { RUN_TESTS(); }
