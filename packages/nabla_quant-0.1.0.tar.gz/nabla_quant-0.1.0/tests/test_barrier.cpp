#include "test_harness.hpp"
#include "nabla/nabla.hpp"
#include <cmath>

using namespace nabla;

static double norm_cdf(double x) {
    return 0.5 * std::erfc(-x / std::sqrt(2.0));
}
static double bs_call(double S, double K, double T,
                      double r, double sigma, double q = 0.0) {
    double d1 = (std::log(S / K) + (r - q + 0.5 * sigma * sigma) * T)
              / (sigma * std::sqrt(T));
    double d2 = d1 - sigma * std::sqrt(T);
    return S * std::exp(-q * T) * norm_cdf(d1) - K * std::exp(-r * T) * norm_cdf(d2);
}

static double bs_put(double S, double K, double T,
                     double r, double sigma, double q = 0.0) {
    double d1 = (std::log(S / K) + (r - q + 0.5 * sigma * sigma) * T)
              / (sigma * std::sqrt(T));
    double d2 = d1 - sigma * std::sqrt(T);
    return K * std::exp(-r * T) * norm_cdf(-d2) - S * std::exp(-q * T) * norm_cdf(-d1);
}

struct BarrierSetup {
    SinhMesh mesh;
    MarketParams mkt;
    ContractParams con;
    BoundaryConditions bc;

    BarrierSetup(double S, double K, double T, double r, double sigma,
                 double q, OptionType type, double s_max_mult = 4.0,
                 std::size_t N = 801)
        : mesh(K, 0.0, s_max_mult * K, N, K / 8.0),
          mkt{S, r, sigma, q},
          con{K, T, type},
          bc(con, mkt, mesh) {}
};

// ══════════════════════════════════════════════════════════════════════
// STANDARD: Down-and-Out Call vs analytical
// ══════════════════════════════════════════════════════════════════════

TEST(barrier_doc_vs_analytical) {
    double S = 100, K = 100, B = 80, T = 1.0, r = 0.05, sigma = 0.20;
    BarrierSetup setup(S, K, T, r, sigma, 0.0, OptionType::Call);
    BarrierParams bp{B, BarrierDirection::Down, BarrierKnock::Out};
    BarrierPricer pricer(setup.mesh, setup.bc, bp, 800);
    auto result = pricer.solve();

    double analytical = BarrierPricer::analytical_down_out_call(S, K, B, T, r, sigma);
    test::assert_near(result.price, analytical, 0.3,
                      "DOC PDE=" + std::to_string(result.price)
                      + " analytical=" + std::to_string(analytical));
}

TEST(barrier_doc_less_than_vanilla) {
    double S = 100, K = 100, B = 80, T = 1.0, r = 0.05, sigma = 0.20;
    BarrierSetup setup(S, K, T, r, sigma, 0.0, OptionType::Call);
    BarrierParams bp{B, BarrierDirection::Down, BarrierKnock::Out};
    BarrierPricer pricer(setup.mesh, setup.bc, bp, 800);
    double doc = pricer.solve().price;
    double vanilla = bs_call(S, K, T, r, sigma);
    test::assert_true(doc < vanilla, "DOC must be less than vanilla call");
    test::assert_true(doc > 0.0, "DOC must be non-negative");
}

TEST(barrier_doc_low_barrier) {
    double S = 100, K = 100, B = 20, T = 1.0, r = 0.05, sigma = 0.20;
    BarrierSetup setup(S, K, T, r, sigma, 0.0, OptionType::Call);
    BarrierParams bp{B, BarrierDirection::Down, BarrierKnock::Out};
    BarrierPricer pricer(setup.mesh, setup.bc, bp, 800);
    double doc = pricer.solve().price;
    double vanilla = bs_call(S, K, T, r, sigma);
    test::assert_near(doc, vanilla, 0.5,
                      "very low barrier → DOC ≈ vanilla");
}

// ══════════════════════════════════════════════════════════════════════
// STANDARD: Up-and-Out Call vs analytical
// ══════════════════════════════════════════════════════════════════════

TEST(barrier_uoc_vs_analytical) {
    double S = 100, K = 100, B = 140, T = 1.0, r = 0.05, sigma = 0.20;
    BarrierSetup setup(S, K, T, r, sigma, 0.0, OptionType::Call, 5.0);
    BarrierParams bp{B, BarrierDirection::Up, BarrierKnock::Out};
    BarrierPricer pricer(setup.mesh, setup.bc, bp, 800);
    auto result = pricer.solve();

    double analytical = BarrierPricer::analytical_up_out_call(S, K, B, T, r, sigma);
    test::assert_near(result.price, analytical, 0.3,
                      "UOC PDE=" + std::to_string(result.price)
                      + " analytical=" + std::to_string(analytical));
}

TEST(barrier_uoc_less_than_vanilla) {
    double S = 100, K = 100, B = 130, T = 1.0, r = 0.05, sigma = 0.20;
    BarrierSetup setup(S, K, T, r, sigma, 0.0, OptionType::Call, 5.0);
    BarrierParams bp{B, BarrierDirection::Up, BarrierKnock::Out};
    BarrierPricer pricer(setup.mesh, setup.bc, bp, 800);
    double uoc = pricer.solve().price;
    double vanilla = bs_call(S, K, T, r, sigma);
    test::assert_true(uoc < vanilla, "UOC < vanilla");
    test::assert_true(uoc > 0.0, "UOC >= 0");
}

// ══════════════════════════════════════════════════════════════════════
// STANDARD: Down-and-Out Put vs analytical
// ══════════════════════════════════════════════════════════════════════

TEST(barrier_dop_vs_analytical) {
    double S = 100, K = 100, B = 80, T = 1.0, r = 0.05, sigma = 0.20;
    BarrierSetup setup(S, K, T, r, sigma, 0.0, OptionType::Put);
    BarrierParams bp{B, BarrierDirection::Down, BarrierKnock::Out};
    BarrierPricer pricer(setup.mesh, setup.bc, bp, 800);
    auto result = pricer.solve();

    double analytical = BarrierPricer::analytical_down_out_put(S, K, B, T, r, sigma);
    test::assert_near(result.price, analytical, 0.3,
                      "DOP PDE=" + std::to_string(result.price)
                      + " analytical=" + std::to_string(analytical));
}

TEST(barrier_dop_less_than_vanilla) {
    double S = 100, K = 100, B = 80, T = 1.0, r = 0.05, sigma = 0.20;
    BarrierSetup setup(S, K, T, r, sigma, 0.0, OptionType::Put);
    BarrierParams bp{B, BarrierDirection::Down, BarrierKnock::Out};
    BarrierPricer pricer(setup.mesh, setup.bc, bp, 800);
    double dop = pricer.solve().price;
    double vanilla = bs_put(S, K, T, r, sigma);
    test::assert_true(dop < vanilla, "DOP < vanilla put");
    test::assert_true(dop >= 0.0, "DOP non-negative");
}

// ══════════════════════════════════════════════════════════════════════
// STANDARD: Up-and-Out Put vs analytical
// ══════════════════════════════════════════════════════════════════════

TEST(barrier_uop_vs_analytical) {
    double S = 100, K = 100, B = 130, T = 1.0, r = 0.05, sigma = 0.20;
    BarrierSetup setup(S, K, T, r, sigma, 0.0, OptionType::Put, 5.0);
    BarrierParams bp{B, BarrierDirection::Up, BarrierKnock::Out};
    BarrierPricer pricer(setup.mesh, setup.bc, bp, 800);
    auto result = pricer.solve();

    double analytical = BarrierPricer::analytical_up_out_put(S, K, B, T, r, sigma);
    test::assert_near(result.price, analytical, 0.4,
                      "UOP PDE=" + std::to_string(result.price)
                      + " analytical=" + std::to_string(analytical));
}

// ══════════════════════════════════════════════════════════════════════
// IN-OUT PARITY: V_KI + V_KO = V_vanilla
// ══════════════════════════════════════════════════════════════════════

TEST(barrier_in_out_parity_doc_dic) {
    double S = 100, K = 100, B = 80, T = 1.0, r = 0.05, sigma = 0.20;
    BarrierSetup setup(S, K, T, r, sigma, 0.0, OptionType::Call);

    BarrierParams ko{B, BarrierDirection::Down, BarrierKnock::Out};
    BarrierParams ki{B, BarrierDirection::Down, BarrierKnock::In};

    double doc = BarrierPricer(setup.mesh, setup.bc, ko, 800).solve().price;
    double dic = BarrierPricer(setup.mesh, setup.bc, ki, 800).solve().price;
    double vanilla = bs_call(S, K, T, r, sigma);

    test::assert_near(doc + dic, vanilla, 0.5,
                      "DOC + DIC = vanilla call: sum="
                      + std::to_string(doc + dic) + " vanilla=" + std::to_string(vanilla));
}

TEST(barrier_in_out_parity_uoc_uic) {
    double S = 100, K = 100, B = 140, T = 1.0, r = 0.05, sigma = 0.20;
    BarrierSetup setup(S, K, T, r, sigma, 0.0, OptionType::Call, 5.0);

    BarrierParams ko{B, BarrierDirection::Up, BarrierKnock::Out};
    BarrierParams ki{B, BarrierDirection::Up, BarrierKnock::In};

    double uoc = BarrierPricer(setup.mesh, setup.bc, ko, 800).solve().price;
    double uic = BarrierPricer(setup.mesh, setup.bc, ki, 800).solve().price;
    double vanilla = bs_call(S, K, T, r, sigma);

    test::assert_near(uoc + uic, vanilla, 0.5,
                      "UOC + UIC = vanilla call");
}

TEST(barrier_in_out_parity_dop_dip) {
    double S = 100, K = 100, B = 80, T = 1.0, r = 0.05, sigma = 0.20;
    BarrierSetup setup(S, K, T, r, sigma, 0.0, OptionType::Put);

    BarrierParams ko{B, BarrierDirection::Down, BarrierKnock::Out};
    BarrierParams ki{B, BarrierDirection::Down, BarrierKnock::In};

    double dop = BarrierPricer(setup.mesh, setup.bc, ko, 800).solve().price;
    double dip = BarrierPricer(setup.mesh, setup.bc, ki, 800).solve().price;
    double vanilla = bs_put(S, K, T, r, sigma);

    test::assert_near(dop + dip, vanilla, 0.5,
                      "DOP + DIP = vanilla put");
}

TEST(barrier_in_out_parity_uop_uip) {
    double S = 100, K = 100, B = 130, T = 1.0, r = 0.05, sigma = 0.20;
    BarrierSetup setup(S, K, T, r, sigma, 0.0, OptionType::Put, 5.0);

    BarrierParams ko{B, BarrierDirection::Up, BarrierKnock::Out};
    BarrierParams ki{B, BarrierDirection::Up, BarrierKnock::In};

    double uop = BarrierPricer(setup.mesh, setup.bc, ko, 800).solve().price;
    double uip = BarrierPricer(setup.mesh, setup.bc, ki, 800).solve().price;
    double vanilla = bs_put(S, K, T, r, sigma);

    test::assert_near(uop + uip, vanilla, 0.5,
                      "UOP + UIP = vanilla put");
}

// ══════════════════════════════════════════════════════════════════════
// KNOCK-IN: positive and bounded
// ══════════════════════════════════════════════════════════════════════

TEST(barrier_dic_positive) {
    double S = 100, K = 100, B = 80, T = 1.0, r = 0.05, sigma = 0.20;
    BarrierSetup setup(S, K, T, r, sigma, 0.0, OptionType::Call);
    BarrierParams ki{B, BarrierDirection::Down, BarrierKnock::In};
    double dic = BarrierPricer(setup.mesh, setup.bc, ki, 800).solve().price;
    test::assert_true(dic > 0.0, "DIC must be positive");
}

TEST(barrier_uic_positive) {
    double S = 100, K = 100, B = 140, T = 1.0, r = 0.05, sigma = 0.20;
    BarrierSetup setup(S, K, T, r, sigma, 0.0, OptionType::Call, 5.0);
    BarrierParams ki{B, BarrierDirection::Up, BarrierKnock::In};
    double uic = BarrierPricer(setup.mesh, setup.bc, ki, 800).solve().price;
    test::assert_true(uic > 0.0, "UIC must be positive");
}

// ══════════════════════════════════════════════════════════════════════
// EDGE: Barrier far from spot - KO ≈ vanilla
// ══════════════════════════════════════════════════════════════════════

TEST(barrier_uoc_far_barrier_approx_vanilla) {
    double S = 100, K = 100, B = 350, T = 1.0, r = 0.05, sigma = 0.20;
    BarrierSetup setup(S, K, T, r, sigma, 0.0, OptionType::Call, 5.0);
    BarrierParams bp{B, BarrierDirection::Up, BarrierKnock::Out};
    double uoc = BarrierPricer(setup.mesh, setup.bc, bp, 800).solve().price;
    double vanilla = bs_call(S, K, T, r, sigma);
    test::assert_near(uoc, vanilla, 0.2,
                      "very far up barrier → UOC ≈ vanilla");
}

TEST(barrier_dop_far_barrier_approx_vanilla) {
    double S = 100, K = 100, B = 5, T = 1.0, r = 0.05, sigma = 0.20;
    BarrierSetup setup(S, K, T, r, sigma, 0.0, OptionType::Put);
    BarrierParams bp{B, BarrierDirection::Down, BarrierKnock::Out};
    double dop = BarrierPricer(setup.mesh, setup.bc, bp, 800).solve().price;
    double vanilla = bs_put(S, K, T, r, sigma);
    test::assert_near(dop, vanilla, 0.3,
                      "very far down barrier → DOP ≈ vanilla put");
}

// ══════════════════════════════════════════════════════════════════════
// EDGE: Short maturity
// ══════════════════════════════════════════════════════════════════════

TEST(barrier_doc_short_maturity) {
    double S = 100, K = 100, B = 80, T = 0.05, r = 0.05, sigma = 0.20;
    BarrierSetup setup(S, K, T, r, sigma, 0.0, OptionType::Call);
    BarrierParams bp{B, BarrierDirection::Down, BarrierKnock::Out};
    BarrierPricer pricer(setup.mesh, setup.bc, bp, 200);
    double doc = pricer.solve().price;

    double analytical = BarrierPricer::analytical_down_out_call(S, K, B, T, r, sigma);
    test::assert_near(doc, analytical, 0.2,
                      "short maturity DOC vs analytical");
}

// ══════════════════════════════════════════════════════════════════════
// EDGE: High volatility
// ══════════════════════════════════════════════════════════════════════

TEST(barrier_doc_high_vol) {
    double S = 100, K = 100, B = 70, T = 1.0, r = 0.05, sigma = 0.50;
    BarrierSetup setup(S, K, T, r, sigma, 0.0, OptionType::Call);
    BarrierParams bp{B, BarrierDirection::Down, BarrierKnock::Out};
    double doc = BarrierPricer(setup.mesh, setup.bc, bp, 800).solve().price;
    double vanilla = bs_call(S, K, T, r, sigma);
    test::assert_true(doc >= 0.0, "high vol DOC non-negative");
    test::assert_true(doc < vanilla, "high vol DOC < vanilla");
}

// ══════════════════════════════════════════════════════════════════════
// EDGE: With dividends
// ══════════════════════════════════════════════════════════════════════

TEST(barrier_doc_with_dividend) {
    double S = 100, K = 100, B = 80, T = 1.0, r = 0.05, sigma = 0.20, q = 0.03;
    BarrierSetup setup(S, K, T, r, sigma, q, OptionType::Call);
    BarrierParams bp{B, BarrierDirection::Down, BarrierKnock::Out};
    double doc = BarrierPricer(setup.mesh, setup.bc, bp, 800).solve().price;

    double analytical = BarrierPricer::analytical_down_out_call(S, K, B, T, r, sigma, q);
    test::assert_near(doc, analytical, 0.4,
                      "DOC with dividends vs analytical");
}

// ══════════════════════════════════════════════════════════════════════
// CONVERGENCE: finer grid → closer to analytical
// ══════════════════════════════════════════════════════════════════════

TEST(barrier_doc_convergence) {
    double S = 100, K = 100, B = 80, T = 1.0, r = 0.05, sigma = 0.20;
    double analytical = BarrierPricer::analytical_down_out_call(S, K, B, T, r, sigma);

    double err_coarse, err_fine;
    {
        SinhMesh mesh(K, 0, 400, 201, K / 8.0);
        MarketParams mkt{S, r, sigma, 0.0};
        ContractParams con{K, T, OptionType::Call};
        BoundaryConditions bc(con, mkt, mesh);
        BarrierParams bp{B, BarrierDirection::Down, BarrierKnock::Out};
        err_coarse = std::fabs(
            BarrierPricer(mesh, bc, bp, 200).solve().price - analytical);
    }
    {
        SinhMesh mesh(K, 0, 400, 801, K / 8.0);
        MarketParams mkt{S, r, sigma, 0.0};
        ContractParams con{K, T, OptionType::Call};
        BoundaryConditions bc(con, mkt, mesh);
        BarrierParams bp{B, BarrierDirection::Down, BarrierKnock::Out};
        err_fine = std::fabs(
            BarrierPricer(mesh, bc, bp, 800).solve().price - analytical);
    }
    test::assert_true(err_fine < err_coarse,
                      "DOC error should decrease with grid refinement");
}

// ══════════════════════════════════════════════════════════════════════
// EXCEPTIONAL: validation errors
// ══════════════════════════════════════════════════════════════════════

TEST(barrier_throws_barrier_outside_domain) {
    test::assert_throws([] {
        BarrierSetup setup(100, 100, 1.0, 0.05, 0.20, 0.0, OptionType::Call);
        BarrierParams bp{500, BarrierDirection::Up, BarrierKnock::Out};
        BarrierPricer(setup.mesh, setup.bc, bp, 800);
    }, "barrier outside mesh domain");
}

TEST(barrier_throws_up_barrier_below_spot) {
    test::assert_throws([] {
        BarrierSetup setup(100, 100, 1.0, 0.05, 0.20, 0.0, OptionType::Call);
        BarrierParams bp{90, BarrierDirection::Up, BarrierKnock::Out};
        BarrierPricer(setup.mesh, setup.bc, bp, 800);
    }, "up barrier below spot should throw");
}

TEST(barrier_throws_down_barrier_above_spot) {
    test::assert_throws([] {
        BarrierSetup setup(100, 100, 1.0, 0.05, 0.20, 0.0, OptionType::Call);
        BarrierParams bp{110, BarrierDirection::Down, BarrierKnock::Out};
        BarrierPricer(setup.mesh, setup.bc, bp, 800);
    }, "down barrier above spot should throw");
}

// ══════════════════════════════════════════════════════════════════════
// GRID PROPERTIES: barrier zeroes beyond level
// ══════════════════════════════════════════════════════════════════════

TEST(barrier_doc_grid_zero_below_barrier) {
    double S = 100, K = 100, B = 80, T = 1.0, r = 0.05, sigma = 0.20;
    BarrierSetup setup(S, K, T, r, sigma, 0.0, OptionType::Call);
    BarrierParams bp{B, BarrierDirection::Down, BarrierKnock::Out};
    auto result = BarrierPricer(setup.mesh, setup.bc, bp, 800).solve();

    const auto& nodes = setup.mesh.spot_nodes();
    for (std::size_t i = 0; i < nodes.size(); ++i) {
        if (nodes[i] <= B)
            test::assert_near(result.grid[i], 0.0, 1e-10,
                              "grid below barrier should be 0");
    }
}

TEST(barrier_uoc_grid_zero_above_barrier) {
    double S = 100, K = 100, B = 140, T = 1.0, r = 0.05, sigma = 0.20;
    BarrierSetup setup(S, K, T, r, sigma, 0.0, OptionType::Call, 5.0);
    BarrierParams bp{B, BarrierDirection::Up, BarrierKnock::Out};
    auto result = BarrierPricer(setup.mesh, setup.bc, bp, 800).solve();

    const auto& nodes = setup.mesh.spot_nodes();
    for (std::size_t i = 0; i < nodes.size(); ++i) {
        if (nodes[i] >= B)
            test::assert_near(result.grid[i], 0.0, 1e-10,
                              "grid above up barrier should be 0");
    }
}

// ══════════════════════════════════════════════════════════════════════
// ANALYTICAL: formula sanity checks
// ══════════════════════════════════════════════════════════════════════

TEST(barrier_analytical_doc_nonnegative) {
    for (double B : {60.0, 70.0, 80.0, 90.0}) {
        double val = BarrierPricer::analytical_down_out_call(
            100, 100, B, 1.0, 0.05, 0.20);
        test::assert_true(val >= -1e-12,
                          "analytical DOC non-negative at B=" + std::to_string(B));
    }
}

TEST(barrier_analytical_uoc_nonnegative) {
    for (double B : {110.0, 120.0, 140.0, 200.0}) {
        double val = BarrierPricer::analytical_up_out_call(
            100, 100, B, 1.0, 0.05, 0.20);
        test::assert_true(val >= -1e-12,
                          "analytical UOC non-negative at B=" + std::to_string(B));
    }
}

TEST(barrier_analytical_in_out_parity_call) {
    double S = 100, K = 100, B = 80, T = 1.0, r = 0.05, sigma = 0.20;
    double doc = BarrierPricer::analytical_down_out_call(S, K, B, T, r, sigma);
    double vanilla = bs_call(S, K, T, r, sigma);
    double dic = vanilla - doc;
    test::assert_true(dic > 0.0, "analytical DIC > 0");
    test::assert_true(dic < vanilla, "analytical DIC < vanilla");
}

// ══════════════════════════════════════════════════════════════════════
// Phase 4/5 Review: additional edge-case and real-world validation
// ══════════════════════════════════════════════════════════════════════

TEST(barrier_far_doc_approaches_vanilla) {
    double S = 100, K = 100, T = 1.0, r = 0.05, sigma = 0.20;
    double B = 1.0;  // far below spot - nearly impossible to hit
    SinhMesh mesh(K, 0, 500, 501, 20);
    MarketParams mkt = {S, r, sigma, 0.0};
    ContractParams con = {K, T, OptionType::Call};
    BoundaryConditions bc(con, mkt, mesh);
    BarrierParams bp = {B, BarrierDirection::Down, BarrierKnock::Out, 0.0};
    BarrierPricer pricer(mesh, bc, bp, 2000);
    double doc = pricer.solve().price;
    double vanilla = bs_call(S, K, T, r, sigma);
    test::assert_near(doc, vanilla, 0.05,
                      "far DOC should approach vanilla");
}

TEST(barrier_far_uoc_approaches_vanilla) {
    double S = 100, K = 100, T = 1.0, r = 0.05, sigma = 0.20;
    double B = 490.0;  // far above spot
    SinhMesh mesh(K, 0, 500, 501, 20);
    MarketParams mkt = {S, r, sigma, 0.0};
    ContractParams con = {K, T, OptionType::Call};
    BoundaryConditions bc(con, mkt, mesh);
    BarrierParams bp = {B, BarrierDirection::Up, BarrierKnock::Out, 0.0};
    BarrierPricer pricer(mesh, bc, bp, 2000);
    double uoc = pricer.solve().price;
    double vanilla = bs_call(S, K, T, r, sigma);
    test::assert_near(uoc, vanilla, 0.05,
                      "far UOC should approach vanilla");
}

TEST(barrier_put_inout_parity_tight) {
    double S = 100, K = 100, T = 1.0, r = 0.05, sigma = 0.20, B = 120;
    SinhMesh mesh(K, 0, 500, 501, 20);
    MarketParams mkt = {S, r, sigma, 0.0};
    ContractParams con = {K, T, OptionType::Put};
    BoundaryConditions bc(con, mkt, mesh);
    BarrierParams bp_out = {B, BarrierDirection::Up, BarrierKnock::Out, 0.0};
    BarrierParams bp_in  = {B, BarrierDirection::Up, BarrierKnock::In, 0.0};
    double uop = BarrierPricer(mesh, bc, bp_out, 2000).solve().price;
    double uip = BarrierPricer(mesh, bc, bp_in, 2000).solve().price;
    double vanilla = bs_put(S, K, T, r, sigma);
    test::assert_near(uop + uip, vanilla, 0.02,
                      "UOP + UIP = vanilla put (tight parity)");
}

TEST(barrier_pde_vs_analytical_doc_with_dividend) {
    double S = 100, K = 100, T = 1.0, r = 0.05, sigma = 0.25, q = 0.03, B = 85;
    SinhMesh mesh(K, 0, 500, 501, 20);
    MarketParams mkt = {S, r, sigma, q};
    ContractParams con = {K, T, OptionType::Call};
    BoundaryConditions bc(con, mkt, mesh);
    BarrierParams bp = {B, BarrierDirection::Down, BarrierKnock::Out, 0.0};
    double pde = BarrierPricer(mesh, bc, bp, 2000).solve().price;
    double ana = BarrierPricer::analytical_down_out_call(S, K, B, T, r, sigma, q);
    test::assert_near(pde, ana, 0.4,
                      "DOC with dividend: PDE=" + std::to_string(pde)
                      + " analytical=" + std::to_string(ana));
}

TEST(barrier_greeks_sanity) {
    double S = 100, K = 100, T = 1.0, r = 0.05, sigma = 0.20;
    SinhMesh mesh(K, 0, 400, 501, 20);
    MarketParams mkt = {S, r, sigma, 0.0};
    ContractParams con = {K, T, OptionType::Call};
    BoundaryConditions bc(con, mkt, mesh);
    BarrierParams bp = {80, BarrierDirection::Down, BarrierKnock::Out, 0.0};
    auto res = BarrierPricer(mesh, bc, bp, 2000).solve();

    // DOC grid should be non-negative everywhere
    for (std::size_t i = 0; i < res.grid.size(); ++i)
        test::assert_true(res.grid[i] >= -1e-10,
                          "DOC grid non-negative at node " + std::to_string(i));

    // DOC grid at nodes below barrier should be ~0
    const auto& nodes = mesh.spot_nodes();
    for (std::size_t i = 0; i < nodes.size(); ++i) {
        if (nodes[i] <= 80.0)
            test::assert_near(res.grid[i], 0.0, 1e-8,
                              "DOC grid zero below barrier");
    }
}

TEST(barrier_real_world_benchmark) {
    // Real-world scenario: S&P 500 option-like parameters
    // SPX at 5000, K=5000 (ATM), T=3m, r=4.5%, vol=16%, down barrier at 4500
    double S = 5000, K = 5000, T = 0.25, r = 0.045, sigma = 0.16, B = 4500;
    SinhMesh mesh(K, 0, 4.0 * K, 801, K / 5.0);
    MarketParams mkt = {S, r, sigma, 0.0};
    ContractParams con = {K, T, OptionType::Call};
    BoundaryConditions bc(con, mkt, mesh);

    // Vanilla price
    double vanilla = bs_call(S, K, T, r, sigma);

    // DOC should be less than vanilla
    BarrierParams bp_doc = {B, BarrierDirection::Down, BarrierKnock::Out, 0.0};
    double doc = BarrierPricer(mesh, bc, bp_doc, 2000).solve().price;
    test::assert_true(doc > 0.0, "SPX DOC positive");
    test::assert_true(doc < vanilla, "SPX DOC < vanilla");

    // DIC via parity
    BarrierParams bp_dic = {B, BarrierDirection::Down, BarrierKnock::In, 0.0};
    double dic = BarrierPricer(mesh, bc, bp_dic, 2000).solve().price;
    test::assert_near(doc + dic, vanilla, 1.0,
                      "SPX DOC+DIC = vanilla at institutional scale");

    // Analytical cross-check
    double ana_doc = BarrierPricer::analytical_down_out_call(S, K, B, T, r, sigma);
    test::assert_near(doc, ana_doc, 2.0,
                      "SPX DOC PDE vs analytical");
}

int main() { RUN_TESTS(); }
