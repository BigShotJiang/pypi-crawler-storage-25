#include "test_harness.hpp"
#include "nabla/nabla.hpp"
#include <cmath>
#include <algorithm>

using namespace nabla;

// ── Mesh + Boundary combined behaviour ───────────────────────────────

TEST(integ_mesh_boundary_terminal_monotone_call) {
    SinhMesh mesh(100.0, 0.0, 300.0, 501, 20.0);
    BoundaryConditions bc({100.0, 1.0, OptionType::Call}, {100.0, 0.05, 0.2, 0.0}, mesh);
    auto v = bc.terminal_condition();

    // Call payoff should be non-decreasing in S
    for (std::size_t i = 1; i < v.size(); ++i)
        test::assert_true(v[i] >= v[i-1] - 1e-15,
                          "call terminal must be non-decreasing");
}

TEST(integ_mesh_boundary_terminal_monotone_put) {
    SinhMesh mesh(100.0, 0.0, 300.0, 501, 20.0);
    BoundaryConditions bc({100.0, 1.0, OptionType::Put}, {100.0, 0.05, 0.2, 0.0}, mesh);
    auto v = bc.terminal_condition();

    // Put payoff should be non-increasing in S
    for (std::size_t i = 1; i < v.size(); ++i)
        test::assert_true(v[i] <= v[i-1] + 1e-15,
                          "put terminal must be non-increasing");
}

TEST(integ_terminal_kink_captured_near_strike) {
    // The payoff has a kink at S = K. The non-uniform mesh should have a node
    // very close to K, so the terminal condition transitions sharply there.
    SinhMesh mesh(100.0, 0.0, 300.0, 501, 10.0);
    BoundaryConditions bc({100.0, 1.0, OptionType::Call}, {100.0, 0.05, 0.2, 0.0}, mesh);
    auto v = bc.terminal_condition();

    std::size_t ki = mesh.strike_index();
    // At the strike node, payoff should be ≈ 0 (since it's at the kink)
    test::assert_true(v[ki] < 1.0,
                      "terminal near strike should be close to 0 for call");
    // One node above should already have positive payoff
    test::assert_true(v[ki + 1] > 0.0,
                      "one node above strike should have positive call payoff");
}

// ── Mesh refinement: resolution near strike improves with N ──────────

TEST(integ_mesh_refinement_improves_strike_resolution) {
    double strike_dist_coarse, strike_dist_fine;

    {
        SinhMesh m(100.0, 0.0, 300.0, 101, 20.0);
        strike_dist_coarse = std::fabs(m.spot_nodes()[m.strike_index()] - 100.0);
    }
    {
        SinhMesh m(100.0, 0.0, 300.0, 1001, 20.0);
        strike_dist_fine = std::fabs(m.spot_nodes()[m.strike_index()] - 100.0);
    }

    test::assert_true(strike_dist_fine < strike_dist_coarse + 1e-15,
                      "finer mesh should place a node closer to strike");
}

TEST(integ_mesh_min_spacing_decreases_with_refinement) {
    SinhMesh coarse(100.0, 0.0, 300.0, 101, 20.0);
    SinhMesh fine(100.0, 0.0, 300.0, 1001, 20.0);

    test::assert_true(fine.min_spacing() < coarse.min_spacing(),
                      "min spacing should decrease with refinement");
}

// ── Boundary time evolution makes physical sense ─────────────────────

TEST(integ_call_upper_boundary_decreases_with_tau) {
    // Upper boundary for call = S_max*e^{-qτ} - K*e^{-rτ}
    // With q=0, r>0: as τ increases, K*e^{-rτ} decreases, so boundary INCREASES.
    SinhMesh mesh(100.0, 0.0, 300.0, 201, 20.0);
    MarketParams mkt = {100.0, 0.05, 0.2, 0.0};
    BoundaryConditions bc({100.0, 1.0, OptionType::Call}, mkt, mesh);

    double b0 = bc.upper_boundary(0.0);
    double b1 = bc.upper_boundary(1.0);
    // S_max - K*e^{-r} > S_max - K since e^{-r} < 1
    test::assert_true(b1 > b0, "call upper boundary should increase with tau (q=0, r>0)");
}

TEST(integ_put_lower_boundary_decreases_with_tau) {
    // Lower boundary for put = K*e^{-rτ}, which decreases with τ
    SinhMesh mesh(100.0, 0.0, 300.0, 201, 20.0);
    MarketParams mkt = {100.0, 0.05, 0.2, 0.0};
    BoundaryConditions bc({100.0, 1.0, OptionType::Put}, mkt, mesh);

    double b0 = bc.lower_boundary(0.0);
    double b1 = bc.lower_boundary(1.0);
    test::assert_true(b1 < b0, "put lower boundary should decrease with tau (r>0)");
}

// ── Grid assembled: terminal + boundaries consistent ─────────────────

TEST(integ_full_grid_assembly) {
    SinhMesh mesh(100.0, 0.0, 300.0, 201, 20.0);
    MarketParams mkt = {100.0, 0.05, 0.2, 0.0};
    BoundaryConditions bc({100.0, 1.0, OptionType::Call}, mkt, mesh);

    auto grid = bc.terminal_condition();

    // At tau = 0 (expiry), boundaries should match terminal
    bc.apply_boundaries(grid, 0.0);
    test::assert_near(grid.front(), 0.0, 1e-12, "call grid[0] at tau=0");
    test::assert_near(grid.back(), 200.0, 1e-12, "call grid[N] at tau=0");

    // Apply boundaries at tau = 0.5 (mid-life)
    bc.apply_boundaries(grid, 0.5);
    test::assert_near(grid.front(), bc.lower_boundary(0.5), 1e-15);
    test::assert_near(grid.back(), bc.upper_boundary(0.5), 1e-15);
}

// ── Multiple strikes ─────────────────────────────────────────────────

TEST(integ_different_strikes) {
    for (double K : {50.0, 100.0, 150.0, 200.0}) {
        SinhMesh mesh(K, 0.0, 300.0, 201, 20.0);
        BoundaryConditions bc({K, 1.0, OptionType::Call}, {100.0, 0.05, 0.2, 0.0}, mesh);

        auto v = bc.terminal_condition();
        test::assert_near(v.front(), 0.0, 1e-12, "call payoff at S=0");
        test::assert_near(v.back(), 300.0 - K, 1e-10,
                          "call payoff at S_max for K=" + std::to_string(K));
    }
}

// ── Concentration sweep: mesh quality metrics ────────────────────────

TEST(integ_concentration_sweep_all_valid) {
    for (double c : {1.0, 5.0, 10.0, 20.0, 50.0, 100.0, 1000.0}) {
        SinhMesh mesh(100.0, 0.0, 300.0, 201, c);
        test::assert_true(mesh.min_spacing() > 0.0);
        test::assert_true(mesh.max_spacing() > 0.0);
        test::assert_true(mesh.spacing_ratio() >= 1.0);

        const auto& s = mesh.spot_nodes();
        for (std::size_t i = 1; i < s.size(); ++i)
            test::assert_true(s[i] > s[i-1], "monotonicity for c=" + std::to_string(c));
    }
}

// ── High-resolution stress test ──────────────────────────────────────

TEST(integ_high_resolution_stress) {
    SinhMesh mesh(100.0, 0.0, 500.0, 10001, 15.0);
    BoundaryConditions bc({100.0, 2.0, OptionType::Put}, {100.0, 0.03, 0.25, 0.01}, mesh);

    test::assert_true(mesh.size() == 10001);

    auto v = bc.terminal_condition();
    test::assert_true(v.size() == 10001);

    // Put payoff at S=0 should be K
    test::assert_near(v.front(), 100.0, 1e-12);
    // Put payoff at S=500 should be 0
    test::assert_near(v.back(), 0.0, 1e-12);

    // Boundaries at tau=2.0
    bc.apply_boundaries(v, 2.0);
    test::assert_true(v.front() > 0.0, "put lower > 0 at tau=2");
    test::assert_near(v.back(), 0.0, 1e-15, "put upper = 0");
}

// ══════════════════════════════════════════════════════════════════════
// Phase 3 integration: Greeks end-to-end
// ══════════════════════════════════════════════════════════════════════

static double norm_cdf_i(double x) {
    return 0.5 * std::erfc(-x / std::sqrt(2.0));
}

static double norm_pdf_i(double x) {
    return std::exp(-0.5 * x * x) / std::sqrt(2.0 * 3.14159265358979323846);
}

static double bs_vega(double S, double K, double T, double r, double sigma, double q) {
    double d1 = (std::log(S / K) + (r - q + 0.5 * sigma * sigma) * T)
              / (sigma * std::sqrt(T));
    return S * std::exp(-q * T) * norm_pdf_i(d1) * std::sqrt(T);
}

static double bs_rho_call(double S, double K, double T, double r, double sigma, double q) {
    double d1 = (std::log(S / K) + (r - q + 0.5 * sigma * sigma) * T)
              / (sigma * std::sqrt(T));
    double d2 = d1 - sigma * std::sqrt(T);
    return K * T * std::exp(-r * T) * norm_cdf_i(d2);
}

TEST(integ_greeks_full_pipeline_call) {
    SinhMesh mesh(100, 0, 400, 501, 20);
    MarketParams mkt = {100, 0.05, 0.20, 0.0};
    ContractParams con = {100, 1.0, OptionType::Call};
    BoundaryConditions bc(con, mkt, mesh);
    GreeksCalculator calc(mesh, bc, 2000);
    auto res = calc.compute();

    test::assert_true(res.price > 0.0, "price positive");
    test::assert_true(res.delta > 0.0 && res.delta < 1.0, "delta in (0,1)");
    test::assert_true(res.gamma > 0.0, "gamma positive");
    test::assert_true(res.theta < 0.0, "theta negative");
    test::assert_true(res.vega > 0.0, "vega positive");
    test::assert_true(res.rho > 0.0, "rho positive for call");
    test::assert_true(res.delta_surface.size() == 501, "delta surface size");
    test::assert_true(res.gamma_surface.size() == 501, "gamma surface size");
}

TEST(integ_greeks_full_pipeline_put) {
    SinhMesh mesh(100, 0, 400, 501, 20);
    MarketParams mkt = {100, 0.05, 0.20, 0.0};
    ContractParams con = {100, 1.0, OptionType::Put};
    BoundaryConditions bc(con, mkt, mesh);
    GreeksCalculator calc(mesh, bc, 2000);
    auto res = calc.compute();

    test::assert_true(res.price > 0.0, "put price positive");
    test::assert_true(res.delta > -1.0 && res.delta < 0.0, "put delta in (-1,0)");
    test::assert_true(res.gamma > 0.0, "put gamma positive");
    test::assert_true(res.vega > 0.0, "put vega positive");
    test::assert_true(res.rho < 0.0, "rho negative for put");
}

TEST(integ_greeks_put_call_parity_all) {
    double K = 100, T = 1.0, r = 0.05, sigma = 0.2, q = 0.0;
    SinhMesh mesh(K, 0, 400, 501, 20);
    MarketParams mkt = {100, r, sigma, q};

    ContractParams call_c = {K, T, OptionType::Call};
    BoundaryConditions call_bc(call_c, mkt, mesh);
    GreeksCalculator call_calc(mesh, call_bc, 2000);
    auto gc = call_calc.compute();

    ContractParams put_c = {K, T, OptionType::Put};
    BoundaryConditions put_bc(put_c, mkt, mesh);
    GreeksCalculator put_calc(mesh, put_bc, 2000);
    auto gp = put_calc.compute();

    // Put-Call parity: C - P = S*e^{-qT} - K*e^{-rT}
    double parity = 100.0 * std::exp(-q * T) - K * std::exp(-r * T);
    test::assert_near(gc.price - gp.price, parity, 0.1, "price parity");

    // Delta parity: Δ_C - Δ_P = e^{-qT}
    test::assert_near(gc.delta - gp.delta, std::exp(-q * T), 0.01, "delta parity");

    // Gamma parity: Γ_C = Γ_P
    test::assert_near(gc.gamma, gp.gamma, 0.001, "gamma parity");

    // Vega parity: ν_C = ν_P
    test::assert_near(gc.vega, gp.vega, 0.5, "vega parity");
}

TEST(integ_greeks_multiple_strikes) {
    for (double K : {80.0, 100.0, 120.0}) {
        SinhMesh mesh(K, 0, 4 * K, 501, K / 5.0);
        MarketParams mkt = {100, 0.05, 0.20, 0.0};
        ContractParams con = {K, 1.0, OptionType::Call};
        BoundaryConditions bc(con, mkt, mesh);
        GreeksCalculator calc(mesh, bc, 2000);
        auto res = calc.compute();

        test::assert_true(res.price > 0.0, "price > 0 at K=" + std::to_string(K));
        test::assert_true(res.delta > 0.0 && res.delta < 1.0, "delta range");
        test::assert_true(res.vega > 0.0, "vega > 0");
    }
}

TEST(integ_greeks_short_maturity) {
    SinhMesh mesh(100, 0, 400, 501, 20);
    MarketParams mkt = {100, 0.05, 0.20, 0.0};
    ContractParams con = {100, 0.01, OptionType::Call};
    BoundaryConditions bc(con, mkt, mesh);
    GreeksCalculator calc(mesh, bc, 200);
    auto res = calc.compute();

    // Short maturity ATM: delta ≈ 0.5, gamma large
    test::assert_true(std::fabs(res.delta - 0.5) < 0.1, "short-mat delta near 0.5");
    test::assert_true(res.gamma > 0.05, "short-mat gamma should be large");
}

TEST(integ_greeks_high_vol) {
    double sigma = 0.80;
    SinhMesh mesh(100, 0, 600, 501, 20);
    MarketParams mkt = {100, 0.05, sigma, 0.0};
    ContractParams con = {100, 1.0, OptionType::Call};
    BoundaryConditions bc(con, mkt, mesh);
    GreeksCalculator calc(mesh, bc, 2000);
    auto res = calc.compute();

    double analytical_vega = bs_vega(100, 100, 1.0, 0.05, sigma, 0.0);
    test::assert_near(res.vega, analytical_vega, 1.0, "high vol vega");
    test::assert_true(res.price > 20.0, "high vol → large price");
}

TEST(integ_greeks_convergence_vega) {
    double S = 100, K = 100, T = 1.0, r = 0.05, sigma = 0.20, q = 0.0;
    double bs_v = bs_vega(S, K, T, r, sigma, q);

    double err_coarse, err_fine;
    {
        SinhMesh mesh(K, 0, 400, 51, 20);
        MarketParams mkt = {S, r, sigma, q};
        ContractParams con = {K, T, OptionType::Call};
        BoundaryConditions bc(con, mkt, mesh);
        GreeksCalculator calc(mesh, bc, 100);
        err_coarse = std::fabs(calc.compute().vega - bs_v);
    }
    {
        SinhMesh mesh(K, 0, 400, 501, 20);
        MarketParams mkt = {S, r, sigma, q};
        ContractParams con = {K, T, OptionType::Call};
        BoundaryConditions bc(con, mkt, mesh);
        GreeksCalculator calc(mesh, bc, 2000);
        err_fine = std::fabs(calc.compute().vega - bs_v);
    }
    test::assert_true(err_fine < err_coarse,
                      "vega should converge with refinement");
}

TEST(integ_greeks_convergence_rho) {
    double S = 100, K = 100, T = 1.0, r = 0.05, sigma = 0.20, q = 0.0;
    double bs_r = bs_rho_call(S, K, T, r, sigma, q);

    double err_coarse, err_fine;
    {
        SinhMesh mesh(K, 0, 400, 201, 20);
        MarketParams mkt = {S, r, sigma, q};
        ContractParams con = {K, T, OptionType::Call};
        BoundaryConditions bc(con, mkt, mesh);
        GreeksCalculator calc(mesh, bc, 500);
        err_coarse = std::fabs(calc.compute().rho - bs_r);
    }
    {
        SinhMesh mesh(K, 0, 400, 501, 20);
        MarketParams mkt = {S, r, sigma, q};
        ContractParams con = {K, T, OptionType::Call};
        BoundaryConditions bc(con, mkt, mesh);
        GreeksCalculator calc(mesh, bc, 2000);
        err_fine = std::fabs(calc.compute().rho - bs_r);
    }
    test::assert_true(err_fine < err_coarse,
                      "rho should converge with refinement");
}

int main() { RUN_TESTS(); }
