#include "test_harness.hpp"
#include "nabla/nabla.hpp"
#include <vector>
#include <cmath>
#include <algorithm>

using namespace nabla;

// ── Helper: reference scalar implementations for cross-checking ──────

static void ref_build_rhs(
    double* rhs, const double* alpha, const double* beta,
    const double* gamma, const double* V, std::size_t M, double omt_dt) {
    for (std::size_t j = 0; j < M; ++j) {
        std::size_t i = j + 1;
        rhs[j] = omt_dt * alpha[i] * V[i - 1]
               + (1.0 + omt_dt * beta[i]) * V[i]
               + omt_dt * gamma[i] * V[i + 1];
    }
}

static void ref_compute_coefficients(
    double* alpha, double* beta, double* gamma,
    const double* S, const double* ds, std::size_t N,
    double half_sig2, double drift, double r) {
    for (std::size_t i = 1; i < N - 1; ++i) {
        double Si = S[i], hm = ds[i-1], hp = ds[i], hsum = hm + hp;
        double D = half_sig2 * Si * Si, mu = drift * Si;
        alpha[i] = (2.0*D)/(hm*hsum) - (mu*hp)/(hm*hsum);
        beta[i]  = -(2.0*D)/(hm*hp) + mu*(hp-hm)/(hm*hp) - r;
        gamma[i] = (2.0*D)/(hp*hsum) + (mu*hm)/(hp*hsum);
    }
}

// ── build_rhs: scalar vs AVX2 exact match ────────────────────────────

TEST(simd_build_rhs_small) {
    const std::size_t N = 11;
    const std::size_t M = N - 2;
    std::vector<double> alpha(N), beta(N), gamma(N), V(N);
    std::vector<double> rhs_scalar(M), rhs_avx(M);

    for (std::size_t i = 0; i < N; ++i) {
        alpha[i] = 0.1 * (i + 1);
        beta[i]  = -0.5 * (i + 1);
        gamma[i] = 0.15 * (i + 1);
        V[i]     = std::sin(0.3 * i);
    }
    double omt_dt = 0.005;

    ref_build_rhs(rhs_scalar.data(), alpha.data(), beta.data(),
                  gamma.data(), V.data(), M, omt_dt);
    simd::build_rhs_avx2(rhs_avx.data(), alpha.data(), beta.data(),
                         gamma.data(), V.data(), M, omt_dt);

    for (std::size_t j = 0; j < M; ++j)
        test::assert_near(rhs_avx[j], rhs_scalar[j], 1e-14,
                          "rhs mismatch at j=" + std::to_string(j));
}

TEST(simd_build_rhs_large) {
    const std::size_t N = 1001;
    const std::size_t M = N - 2;
    std::vector<double> alpha(N), beta(N), gamma(N), V(N);
    std::vector<double> rhs_scalar(M), rhs_avx(M);

    for (std::size_t i = 0; i < N; ++i) {
        double x = static_cast<double>(i) / N;
        alpha[i] = 0.3 + 0.1 * x;
        beta[i]  = -1.0 + 0.2 * x;
        gamma[i] = 0.3 + 0.15 * x;
        V[i]     = std::exp(-x * x);
    }
    double omt_dt = 0.0025;

    ref_build_rhs(rhs_scalar.data(), alpha.data(), beta.data(),
                  gamma.data(), V.data(), M, omt_dt);
    simd::build_rhs_avx2(rhs_avx.data(), alpha.data(), beta.data(),
                         gamma.data(), V.data(), M, omt_dt);

    double max_err = 0;
    for (std::size_t j = 0; j < M; ++j) {
        double err = std::fabs(rhs_avx[j] - rhs_scalar[j]);
        if (err > max_err) max_err = err;
    }
    test::assert_true(max_err < 1e-13,
                      "max rhs error = " + std::to_string(max_err));
}

// ── Non-multiple-of-4 sizes (tail handling) ──────────────────────────

TEST(simd_build_rhs_non_aligned_sizes) {
    for (std::size_t N : {5, 6, 7, 8, 9, 13, 17, 33, 100, 103}) {
        std::size_t M = N - 2;
        std::vector<double> alpha(N), beta(N), gamma(N), V(N);
        std::vector<double> rhs_scalar(M), rhs_avx(M);

        for (std::size_t i = 0; i < N; ++i) {
            alpha[i] = 0.5;
            beta[i]  = -1.5;
            gamma[i] = 0.5;
            V[i]     = static_cast<double>(i);
        }

        ref_build_rhs(rhs_scalar.data(), alpha.data(), beta.data(),
                      gamma.data(), V.data(), M, 0.01);
        simd::build_rhs_avx2(rhs_avx.data(), alpha.data(), beta.data(),
                             gamma.data(), V.data(), M, 0.01);

        for (std::size_t j = 0; j < M; ++j)
            test::assert_near(rhs_avx[j], rhs_scalar[j], 1e-13,
                              "N=" + std::to_string(N) + " j=" + std::to_string(j));
    }
}

// ── compute_coefficients: scalar vs AVX2 ─────────────────────────────

TEST(simd_coefficients_match_reference) {
    SinhMesh mesh(100.0, 0.0, 300.0, 201, 20.0);
    const std::size_t N = mesh.size();

    std::vector<double> a_ref(N), b_ref(N), g_ref(N);
    std::vector<double> a_avx(N), b_avx(N), g_avx(N);

    double half_sig2 = 0.5 * 0.04;  // sigma = 0.2
    double drift = 0.05;
    double r = 0.05;

    ref_compute_coefficients(a_ref.data(), b_ref.data(), g_ref.data(),
                             mesh.spot_nodes().data(), mesh.ds().data(),
                             N, half_sig2, drift, r);
    simd::compute_coefficients_avx2(a_avx.data(), b_avx.data(), g_avx.data(),
                                    mesh.spot_nodes().data(), mesh.ds().data(),
                                    N, half_sig2, drift, r);

    for (std::size_t i = 1; i < N - 1; ++i) {
        test::assert_near(a_avx[i], a_ref[i], 1e-10,
                          "alpha mismatch at i=" + std::to_string(i));
        test::assert_near(b_avx[i], b_ref[i], 1e-10,
                          "beta mismatch at i=" + std::to_string(i));
        test::assert_near(g_avx[i], g_ref[i], 1e-10,
                          "gamma mismatch at i=" + std::to_string(i));
    }
}

TEST(simd_coefficients_large_mesh) {
    SinhMesh mesh(100.0, 0.0, 500.0, 2001, 15.0);
    const std::size_t N = mesh.size();

    std::vector<double> a_ref(N), b_ref(N), g_ref(N);
    std::vector<double> a_avx(N), b_avx(N), g_avx(N);

    ref_compute_coefficients(a_ref.data(), b_ref.data(), g_ref.data(),
                             mesh.spot_nodes().data(), mesh.ds().data(),
                             N, 0.5 * 0.09, 0.03, 0.05);
    simd::compute_coefficients_avx2(a_avx.data(), b_avx.data(), g_avx.data(),
                                    mesh.spot_nodes().data(), mesh.ds().data(),
                                    N, 0.5 * 0.09, 0.03, 0.05);

    double max_err = 0;
    for (std::size_t i = 1; i < N - 1; ++i) {
        double ea = std::fabs(a_avx[i] - a_ref[i]);
        double eb = std::fabs(b_avx[i] - b_ref[i]);
        double eg = std::fabs(g_avx[i] - g_ref[i]);
        double em = std::max(ea, std::max(eb, eg));
        if (em > max_err) max_err = em;
    }
    // FMA instructions in AVX2 can produce different rounding than scalar
    // mul+add, so use a relative tolerance appropriate for double precision
    test::assert_true(max_err < 1e-6,
                      "max coeff error too large");
}

// ── Dispatch function works ──────────────────────────────────────────

TEST(simd_dispatch_build_rhs) {
    const std::size_t N = 50;
    const std::size_t M = N - 2;
    std::vector<double> alpha(N, 0.3), beta(N, -1.0), gamma(N, 0.3), V(N, 1.0);
    std::vector<double> rhs_ref(M), rhs_dispatch(M);

    ref_build_rhs(rhs_ref.data(), alpha.data(), beta.data(),
                  gamma.data(), V.data(), M, 0.01);
    simd::build_rhs(rhs_dispatch.data(), alpha.data(), beta.data(),
                    gamma.data(), V.data(), M, 0.01);

    for (std::size_t j = 0; j < M; ++j)
        test::assert_near(rhs_dispatch[j], rhs_ref[j], 1e-14);
}

TEST(simd_dispatch_compute_coefficients) {
    SinhMesh mesh(100.0, 0.0, 300.0, 101, 20.0);
    const std::size_t N = mesh.size();

    std::vector<double> a_ref(N), b_ref(N), g_ref(N);
    std::vector<double> a_disp(N), b_disp(N), g_disp(N);

    ref_compute_coefficients(a_ref.data(), b_ref.data(), g_ref.data(),
                             mesh.spot_nodes().data(), mesh.ds().data(),
                             N, 0.02, 0.05, 0.05);
    simd::compute_coefficients(a_disp.data(), b_disp.data(), g_disp.data(),
                               mesh.spot_nodes().data(), mesh.ds().data(),
                               N, 0.02, 0.05, 0.05);

    for (std::size_t i = 1; i < N - 1; ++i) {
        test::assert_near(a_disp[i], a_ref[i], 1e-10);
        test::assert_near(b_disp[i], b_ref[i], 1e-10);
        test::assert_near(g_disp[i], g_ref[i], 1e-10);
    }
}

// ── Full solver still correct with SIMD path ─────────────────────────

static double norm_cdf(double x) {
    return 0.5 * std::erfc(-x / std::sqrt(2.0));
}

static double bs_call(double S, double K, double T, double r, double sigma) {
    double d1 = (std::log(S / K) + (r + 0.5 * sigma * sigma) * T)
              / (sigma * std::sqrt(T));
    double d2 = d1 - sigma * std::sqrt(T);
    return S * norm_cdf(d1) - K * std::exp(-r * T) * norm_cdf(d2);
}

TEST(simd_solver_still_accurate) {
    double S = 100.0, K = 100.0, T = 1.0, r = 0.05, sigma = 0.2;
    SinhMesh mesh(K, 0.0, 5.0*K, 801, K/8.0);
    BoundaryConditions bc({K, T, OptionType::Call}, {S, r, sigma, 0.0}, mesh);
    CrankNicolsonSolver solver(mesh, bc, 400);
    auto result = solver.solve();

    double analytical = bs_call(S, K, T, r, sigma);
    test::assert_near(result.price, analytical, 0.05,
                      "SIMD solver: PDE=" + std::to_string(result.price) +
                      " BS=" + std::to_string(analytical));
}

int main() { RUN_TESTS(); }
