#include "test_harness.hpp"
#include "nabla/core/arena.hpp"
#include <cstdint>
#include <numeric>

using namespace nabla;

// ── Construction ─────────────────────────────────────────────────────

TEST(arena_construction) {
    Arena arena(4096);
    test::assert_true(arena.capacity() == 4096);
    test::assert_true(arena.used() == 0);
    test::assert_true(arena.remaining() == 4096);
}

TEST(arena_rejects_zero_capacity) {
    test::assert_throws([]{ Arena arena(0); });
}

// ── Basic allocation ─────────────────────────────────────────────────

TEST(arena_alloc_doubles) {
    Arena arena(1024);
    double* ptr = arena.alloc<double>(10);
    test::assert_true(ptr != nullptr);
    test::assert_true(arena.used() >= 10 * sizeof(double));

    // Write and read back
    for (int i = 0; i < 10; ++i)
        ptr[i] = static_cast<double>(i * i);

    for (int i = 0; i < 10; ++i)
        test::assert_near(ptr[i], static_cast<double>(i * i), 1e-15);
}

TEST(arena_alloc_zeroed) {
    Arena arena(1024);
    double* ptr = arena.alloc_zeroed<double>(20);
    for (int i = 0; i < 20; ++i)
        test::assert_near(ptr[i], 0.0, 1e-15, "zeroed allocation");
}

// ── Alignment ────────────────────────────────────────────────────────

TEST(arena_64byte_alignment) {
    Arena arena(4096);
    for (int trial = 0; trial < 5; ++trial) {
        double* ptr = arena.alloc<double>(7);  // odd count
        auto addr = reinterpret_cast<std::uintptr_t>(ptr);
        test::assert_true(addr % 64 == 0,
                          "allocation must be 64-byte aligned");
    }
}

TEST(arena_custom_alignment) {
    Arena arena(4096);
    int* p1 = arena.alloc<int>(3, 128);
    auto addr1 = reinterpret_cast<std::uintptr_t>(p1);
    test::assert_true(addr1 % 128 == 0, "128-byte alignment");
}

// ── Reset ────────────────────────────────────────────────────────────

TEST(arena_reset_reclaims_all_memory) {
    Arena arena(4096);
    arena.alloc<double>(100);
    test::assert_true(arena.used() > 0);

    arena.reset();
    test::assert_true(arena.used() == 0);
    test::assert_true(arena.remaining() == arena.capacity());
}

TEST(arena_reset_allows_reuse) {
    Arena arena(1024);
    double* p1 = arena.alloc<double>(50);
    p1[0] = 42.0;

    arena.reset();
    double* p2 = arena.alloc<double>(50);

    // Should get the same (or very close) memory back
    test::assert_true(p2 != nullptr);
    p2[0] = 99.0;
    test::assert_near(p2[0], 99.0, 1e-15);
}

// ── Multiple allocations from same arena ─────────────────────────────

TEST(arena_multiple_allocations_non_overlapping) {
    Arena arena(4096);
    double* a = arena.alloc<double>(10);
    double* b = arena.alloc<double>(10);
    double* c = arena.alloc<double>(10);

    // Write to all three
    for (int i = 0; i < 10; ++i) {
        a[i] = 1.0;
        b[i] = 2.0;
        c[i] = 3.0;
    }

    // Verify no overlap corruption
    for (int i = 0; i < 10; ++i) {
        test::assert_near(a[i], 1.0, 1e-15, "a not corrupted");
        test::assert_near(b[i], 2.0, 1e-15, "b not corrupted");
        test::assert_near(c[i], 3.0, 1e-15, "c not corrupted");
    }
}

// ── Out of memory ────────────────────────────────────────────────────

TEST(arena_throws_on_overflow) {
    Arena arena(256);
    // 256 bytes can hold 32 doubles; asking for 100 should throw
    test::assert_throws([&]{ arena.alloc<double>(100); });
}

// ── ArenaSpan ────────────────────────────────────────────────────────

TEST(arena_span_basic) {
    Arena arena(4096);
    double* raw = arena.alloc<double>(10);
    ArenaSpan<double> span(raw, 10);

    test::assert_true(span.size() == 10);
    test::assert_true(span.data() == raw);

    for (std::size_t i = 0; i < span.size(); ++i)
        span[i] = static_cast<double>(i);

    double sum = 0;
    for (auto v : span) sum += v;
    test::assert_near(sum, 45.0, 1e-15, "sum of 0..9");
}

// ── Move semantics ───────────────────────────────────────────────────

TEST(arena_move_construction) {
    Arena a(2048);
    double* ptr = a.alloc<double>(10);
    ptr[0] = 123.0;

    Arena b(std::move(a));
    test::assert_true(b.capacity() == 2048);
    test::assert_true(a.capacity() == 0);
}

TEST(arena_move_assignment) {
    Arena a(2048);
    Arena b(512);
    a.alloc<double>(10);

    b = std::move(a);
    test::assert_true(b.capacity() == 2048);
    test::assert_true(a.capacity() == 0);
}

// ── Simulated PDE loop pattern ───────────────────────────────────────

TEST(arena_pde_loop_simulation) {
    const std::size_t N = 500;
    // Enough space for several arrays per time step
    Arena arena(N * sizeof(double) * 6 + 4096);

    for (int step = 0; step < 100; ++step) {
        arena.reset();
        double* rhs = arena.alloc_zeroed<double>(N);
        double* lo  = arena.alloc<double>(N);
        double* di  = arena.alloc<double>(N);
        double* up  = arena.alloc<double>(N);

        for (std::size_t i = 0; i < N; ++i) {
            lo[i] = -0.5;
            di[i] = 2.0 + step * 0.001;
            up[i] = -0.5;
            rhs[i] = 1.0;
        }

        // Verify data integrity within the step
        for (std::size_t i = 0; i < N; ++i) {
            test::assert_near(rhs[i], 1.0, 1e-15);
            test::assert_near(lo[i], -0.5, 1e-15);
        }
    }

    // After loop, arena should still be valid
    test::assert_true(arena.capacity() > 0);
}

int main() { RUN_TESTS(); }
