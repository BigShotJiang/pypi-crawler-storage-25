#include "test_harness.hpp"
#include "nabla/core/boundary.hpp"
#include <cmath>

using namespace nabla;

static SinhMesh make_mesh() {
    return SinhMesh(100.0, 0.0, 300.0, 201, 20.0);
}

static ContractParams call_contract() {
    return {100.0, 1.0, OptionType::Call};
}

static ContractParams put_contract() {
    return {100.0, 1.0, OptionType::Put};
}

static MarketParams base_market() {
    return {100.0, 0.05, 0.2, 0.0};
}

// ── Construction & validation ────────────────────────────────────────

TEST(bc_construction) {
    auto mesh = make_mesh();
    BoundaryConditions bc(call_contract(), base_market(), mesh);
    test::assert_true(bc.lower_type() == BoundaryType::Dirichlet);
    test::assert_true(bc.upper_type() == BoundaryType::Dirichlet);
}

TEST(bc_rejects_nonpositive_strike) {
    auto mesh = make_mesh();
    test::assert_throws([&]{
        BoundaryConditions bc({0.0, 1.0, OptionType::Call}, base_market(), mesh);
    });
    test::assert_throws([&]{
        BoundaryConditions bc({-10.0, 1.0, OptionType::Call}, base_market(), mesh);
    });
}

TEST(bc_rejects_nonpositive_expiry) {
    auto mesh = make_mesh();
    test::assert_throws([&]{
        BoundaryConditions bc({100.0, 0.0, OptionType::Call}, base_market(), mesh);
    });
    test::assert_throws([&]{
        BoundaryConditions bc({100.0, -1.0, OptionType::Put}, base_market(), mesh);
    });
}

// ── Payoff function ──────────────────────────────────────────────────

TEST(bc_call_payoff) {
    auto mesh = make_mesh();
    BoundaryConditions bc(call_contract(), base_market(), mesh);
    test::assert_near(bc.payoff(150.0), 50.0, 1e-15, "ITM call");
    test::assert_near(bc.payoff(100.0), 0.0, 1e-15, "ATM call");
    test::assert_near(bc.payoff(50.0), 0.0, 1e-15, "OTM call");
    test::assert_near(bc.payoff(0.0), 0.0, 1e-15, "deep OTM call");
}

TEST(bc_put_payoff) {
    auto mesh = make_mesh();
    BoundaryConditions bc(put_contract(), base_market(), mesh);
    test::assert_near(bc.payoff(50.0), 50.0, 1e-15, "ITM put");
    test::assert_near(bc.payoff(100.0), 0.0, 1e-15, "ATM put");
    test::assert_near(bc.payoff(150.0), 0.0, 1e-15, "OTM put");
}

// ── Terminal condition ───────────────────────────────────────────────

TEST(bc_call_terminal_condition) {
    auto mesh = make_mesh();
    BoundaryConditions bc(call_contract(), base_market(), mesh);
    auto v = bc.terminal_condition();
    test::assert_true(v.size() == mesh.size());

    for (std::size_t i = 0; i < mesh.size(); ++i) {
        double expected = std::max(mesh.spot_nodes()[i] - 100.0, 0.0);
        test::assert_near(v[i], expected, 1e-12,
                          "call terminal at S=" + std::to_string(mesh.spot_nodes()[i]));
    }
}

TEST(bc_put_terminal_condition) {
    auto mesh = make_mesh();
    BoundaryConditions bc(put_contract(), base_market(), mesh);
    auto v = bc.terminal_condition();

    for (std::size_t i = 0; i < mesh.size(); ++i) {
        double expected = std::max(100.0 - mesh.spot_nodes()[i], 0.0);
        test::assert_near(v[i], expected, 1e-12,
                          "put terminal at S=" + std::to_string(mesh.spot_nodes()[i]));
    }
}

TEST(bc_terminal_nonnegative) {
    auto mesh = make_mesh();
    for (auto type : {OptionType::Call, OptionType::Put}) {
        BoundaryConditions bc({100.0, 1.0, type}, base_market(), mesh);
        for (auto v : bc.terminal_condition())
            test::assert_true(v >= 0.0, "payoff must be non-negative");
    }
}

// ── Lower boundary ──────────────────────────────────────────────────

TEST(bc_call_lower_boundary_zero) {
    auto mesh = make_mesh();
    BoundaryConditions bc(call_contract(), base_market(), mesh);
    for (double tau : {0.0, 0.25, 0.5, 1.0, 2.0})
        test::assert_near(bc.lower_boundary(tau), 0.0, 1e-15,
                          "call lower boundary at tau=" + std::to_string(tau));
}

TEST(bc_put_lower_boundary) {
    auto mesh = make_mesh();
    MarketParams mkt = base_market();
    BoundaryConditions bc(put_contract(), mkt, mesh);

    double tau = 1.0;
    double expected = 100.0 * std::exp(-mkt.rate * tau) - 0.0 * std::exp(-mkt.dividend * tau);
    test::assert_near(bc.lower_boundary(tau), expected, 1e-12,
                      "put lower boundary = K*exp(-r*tau)");
}

TEST(bc_put_lower_boundary_at_expiry) {
    auto mesh = make_mesh();
    BoundaryConditions bc(put_contract(), base_market(), mesh);
    // tau = 0 means t = T: boundary should equal intrinsic payoff at S_min
    test::assert_near(bc.lower_boundary(0.0), 100.0, 1e-12,
                      "put lower at tau=0 equals K (since S_min=0)");
}

// ── Upper boundary ──────────────────────────────────────────────────

TEST(bc_call_upper_boundary) {
    auto mesh = make_mesh();
    MarketParams mkt = base_market();
    BoundaryConditions bc(call_contract(), mkt, mesh);

    double tau = 1.0;
    double expected = 300.0 * std::exp(-mkt.dividend * tau)
                    - 100.0 * std::exp(-mkt.rate * tau);
    test::assert_near(bc.upper_boundary(tau), expected, 1e-12,
                      "call upper boundary");
}

TEST(bc_call_upper_boundary_at_expiry) {
    auto mesh = make_mesh();
    BoundaryConditions bc(call_contract(), base_market(), mesh);
    // tau = 0: boundary should equal intrinsic payoff at S_max
    test::assert_near(bc.upper_boundary(0.0), 200.0, 1e-12,
                      "call upper at tau=0 equals S_max - K");
}

TEST(bc_put_upper_boundary_zero) {
    auto mesh = make_mesh();
    BoundaryConditions bc(put_contract(), base_market(), mesh);
    for (double tau : {0.0, 0.25, 0.5, 1.0})
        test::assert_near(bc.upper_boundary(tau), 0.0, 1e-15,
                          "put upper boundary at tau=" + std::to_string(tau));
}

// ── Consistency: terminal + boundaries agree at τ = 0 ────────────────

TEST(bc_call_terminal_boundary_consistency) {
    auto mesh = make_mesh();
    BoundaryConditions bc(call_contract(), base_market(), mesh);
    auto v = bc.terminal_condition();
    test::assert_near(v.front(), bc.lower_boundary(0.0), 1e-12,
                      "call: terminal[0] == lower(0)");
    test::assert_near(v.back(), bc.upper_boundary(0.0), 1e-12,
                      "call: terminal[N] == upper(0)");
}

TEST(bc_put_terminal_boundary_consistency) {
    auto mesh = make_mesh();
    BoundaryConditions bc(put_contract(), base_market(), mesh);
    auto v = bc.terminal_condition();
    test::assert_near(v.front(), bc.lower_boundary(0.0), 1e-12,
                      "put: terminal[0] == lower(0)");
    test::assert_near(v.back(), bc.upper_boundary(0.0), 1e-12,
                      "put: terminal[N] == upper(0)");
}

// ── Apply boundaries ─────────────────────────────────────────────────

TEST(bc_apply_boundaries) {
    auto mesh = make_mesh();
    BoundaryConditions bc(call_contract(), base_market(), mesh);
    std::vector<double> grid(mesh.size(), 0.0);
    bc.apply_boundaries(grid, 0.5);
    test::assert_near(grid.front(), bc.lower_boundary(0.5), 1e-15);
    test::assert_near(grid.back(), bc.upper_boundary(0.5), 1e-15);
}

TEST(bc_apply_boundaries_rejects_wrong_size) {
    auto mesh = make_mesh();
    BoundaryConditions bc(call_contract(), base_market(), mesh);
    std::vector<double> grid(10, 0.0);
    test::assert_throws([&]{ bc.apply_boundaries(grid, 0.5); });
}

// ── Dividend yield support ───────────────────────────────────────────

TEST(bc_dividend_call_upper) {
    auto mesh = make_mesh();
    MarketParams mkt = {100.0, 0.05, 0.2, 0.02};
    BoundaryConditions bc(call_contract(), mkt, mesh);
    double tau = 1.0;
    double expected = 300.0 * std::exp(-0.02 * tau) - 100.0 * std::exp(-0.05 * tau);
    test::assert_near(bc.upper_boundary(tau), expected, 1e-12);
}

TEST(bc_dividend_put_lower) {
    auto mesh = SinhMesh(100.0, 10.0, 300.0, 201, 20.0);
    MarketParams mkt = {100.0, 0.05, 0.2, 0.03};
    BoundaryConditions bc(put_contract(), mkt, mesh);
    double tau = 0.5;
    double expected = 100.0 * std::exp(-0.05 * 0.5) - 10.0 * std::exp(-0.03 * 0.5);
    test::assert_near(bc.lower_boundary(tau), expected, 1e-12);
}

// ── Put-Call parity at boundaries (approximate) ──────────────────────

TEST(bc_put_call_parity_at_boundaries) {
    auto mesh = make_mesh();
    MarketParams mkt = base_market();
    BoundaryConditions call_bc(call_contract(), mkt, mesh);
    BoundaryConditions put_bc(put_contract(), mkt, mesh);

    double tau = 1.0;
    double K = 100.0;
    double r = mkt.rate;
    double q = mkt.dividend;

    // At S_max: C - P should ≈ S*exp(-qτ) - K*exp(-rτ)
    double s_max = mesh.s_max();
    double parity_upper = s_max * std::exp(-q * tau) - K * std::exp(-r * tau);
    double cp_diff_upper = call_bc.upper_boundary(tau) - put_bc.upper_boundary(tau);
    test::assert_near(cp_diff_upper, parity_upper, 1e-10, "put-call parity at S_max");

    // At S_min = 0: C - P should ≈ -K*exp(-rτ)
    double parity_lower = -K * std::exp(-r * tau);
    double cp_diff_lower = call_bc.lower_boundary(tau) - put_bc.lower_boundary(tau);
    test::assert_near(cp_diff_lower, parity_lower, 1e-10, "put-call parity at S_min");
}

int main() { RUN_TESTS(); }
