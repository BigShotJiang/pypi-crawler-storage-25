#include "test_harness.hpp"
#include "nabla/core/mesh.hpp"
#include <cmath>
#include <algorithm>
#include <numeric>

using namespace nabla;

// ── Construction & validation ────────────────────────────────────────

TEST(mesh_basic_construction) {
    SinhMesh m(100.0, 0.0, 300.0, 201, 20.0);
    test::assert_true(m.size() == 201);
    test::assert_near(m.s_min(), 0.0, 1e-15);
    test::assert_near(m.s_max(), 300.0, 1e-15);
    test::assert_near(m.strike(), 100.0, 1e-15);
    test::assert_near(m.concentration(), 20.0, 1e-15);
}

TEST(mesh_rejects_fewer_than_3_nodes) {
    test::assert_throws([]{ SinhMesh(100, 0, 300, 2, 20); });
    test::assert_throws([]{ SinhMesh(100, 0, 300, 0, 20); });
}

TEST(mesh_rejects_negative_smin) {
    test::assert_throws([]{ SinhMesh(100, -1, 300, 50, 20); });
}

TEST(mesh_rejects_smax_le_smin) {
    test::assert_throws([]{ SinhMesh(100, 300, 300, 50, 20); });
    test::assert_throws([]{ SinhMesh(100, 300, 100, 50, 20); });
}

TEST(mesh_rejects_strike_outside_domain) {
    test::assert_throws([]{ SinhMesh(400, 0, 300, 50, 20); });
    test::assert_throws([]{ SinhMesh(-10, 0, 300, 50, 20); });
}

TEST(mesh_rejects_nonpositive_concentration) {
    test::assert_throws([]{ SinhMesh(100, 0, 300, 50, 0); });
    test::assert_throws([]{ SinhMesh(100, 0, 300, 50, -5); });
}

// ── Boundary pinning ─────────────────────────────────────────────────

TEST(mesh_boundary_values_exact) {
    SinhMesh m(100.0, 0.0, 400.0, 501, 15.0);
    test::assert_near(m.spot_nodes().front(), 0.0, 1e-15, "front == s_min");
    test::assert_near(m.spot_nodes().back(), 400.0, 1e-15, "back == s_max");
}

// ── Monotonicity ─────────────────────────────────────────────────────

TEST(mesh_nodes_strictly_increasing) {
    SinhMesh m(100.0, 0.0, 300.0, 201, 20.0);
    const auto& s = m.spot_nodes();
    for (std::size_t i = 1; i < s.size(); ++i)
        test::assert_true(s[i] > s[i - 1], "node " + std::to_string(i) + " not increasing");
}

TEST(mesh_ds_all_positive) {
    SinhMesh m(100.0, 0.0, 300.0, 201, 20.0);
    for (auto d : m.ds())
        test::assert_true(d > 0.0, "non-positive spacing");
}

// ── Clustering around strike ─────────────────────────────────────────

TEST(mesh_minimum_spacing_near_strike) {
    SinhMesh m(100.0, 0.0, 300.0, 201, 20.0);
    const auto& d = m.ds();
    auto it = std::min_element(d.begin(), d.end());
    std::size_t min_idx = static_cast<std::size_t>(std::distance(d.begin(), it));

    // The minimum spacing interval should be near the strike index
    std::size_t k_idx = m.strike_index();
    std::size_t dist = (min_idx > k_idx) ? (min_idx - k_idx) : (k_idx - min_idx);
    test::assert_true(dist <= 5, "min spacing should be near strike");
}

TEST(mesh_spacing_smaller_near_strike_than_tails) {
    SinhMesh m(100.0, 0.0, 300.0, 201, 20.0);
    const auto& d = m.ds();
    double near_strike = d[m.strike_index()];
    double at_lower = d[0];
    double at_upper = d[d.size() - 1];
    test::assert_true(near_strike < at_lower, "near-strike spacing < lower tail");
    test::assert_true(near_strike < at_upper, "near-strike spacing < upper tail");
}

TEST(mesh_spacing_ratio_gt_1) {
    SinhMesh m(100.0, 0.0, 300.0, 201, 20.0);
    test::assert_true(m.spacing_ratio() > 1.0, "non-uniform mesh should have ratio > 1");
}

// ── Concentration parameter effect ───────────────────────────────────

TEST(mesh_smaller_c_gives_tighter_clustering) {
    SinhMesh coarse(100.0, 0.0, 300.0, 201, 50.0);
    SinhMesh tight(100.0, 0.0, 300.0, 201, 5.0);
    test::assert_true(tight.spacing_ratio() > coarse.spacing_ratio(),
                      "smaller c should produce larger spacing ratio");
    test::assert_true(tight.min_spacing() < coarse.min_spacing(),
                      "smaller c should produce smaller min spacing");
}

// ── Transform invertibility ──────────────────────────────────────────

TEST(mesh_transform_roundtrip_xi_to_s_to_xi) {
    SinhMesh m(100.0, 0.0, 300.0, 201, 20.0);
    for (auto xi : m.xi_nodes()) {
        double s = m.s_from_xi(xi);
        double xi2 = m.xi_from_s(s);
        test::assert_near(xi, xi2, 1e-12, "xi roundtrip");
    }
}

TEST(mesh_transform_roundtrip_s_to_xi_to_s) {
    SinhMesh m(100.0, 0.0, 300.0, 201, 20.0);
    for (auto s : m.spot_nodes()) {
        double xi = m.xi_from_s(s);
        double s2 = m.s_from_xi(xi);
        test::assert_near(s, s2, 1e-10, "s roundtrip");
    }
}

// ── Jacobian verification ────────────────────────────────────────────

TEST(mesh_jacobian_numerical_check) {
    SinhMesh m(100.0, 0.0, 300.0, 201, 20.0);
    const double h = 1e-7;
    for (auto xi : m.xi_nodes()) {
        double analytic = m.jacobian(xi);
        double numeric = (m.s_from_xi(xi + h) - m.s_from_xi(xi - h)) / (2.0 * h);
        test::assert_near(analytic, numeric, 1e-5, "jacobian at xi=" + std::to_string(xi));
    }
}

TEST(mesh_jacobian_minimized_at_strike) {
    SinhMesh m(100.0, 0.0, 300.0, 201, 20.0);
    double jac_at_strike = m.jacobian(m.xi_from_s(m.strike()));
    double jac_at_lower = m.jacobian(m.xi_min());
    double jac_at_upper = m.jacobian(m.xi_max());
    test::assert_true(jac_at_strike <= jac_at_lower + 1e-10,
                      "jacobian at strike <= at lower boundary");
    test::assert_true(jac_at_strike <= jac_at_upper + 1e-10,
                      "jacobian at strike <= at upper boundary");
}

// ── Xi-space uniformity ──────────────────────────────────────────────

TEST(mesh_xi_nodes_uniformly_spaced) {
    SinhMesh m(100.0, 0.0, 300.0, 201, 20.0);
    const auto& xi = m.xi_nodes();
    double expected_dxi = (xi.back() - xi.front()) / static_cast<double>(xi.size() - 1);
    for (std::size_t i = 1; i < xi.size(); ++i) {
        double dxi = xi[i] - xi[i - 1];
        test::assert_near(dxi, expected_dxi, 1e-12, "xi uniform spacing");
    }
}

// ── Edge cases ───────────────────────────────────────────────────────

TEST(mesh_minimum_3_nodes) {
    SinhMesh m(100.0, 50.0, 150.0, 3, 10.0);
    test::assert_true(m.size() == 3);
    test::assert_near(m.spot_nodes()[0], 50.0, 1e-15);
    test::assert_near(m.spot_nodes()[2], 150.0, 1e-15);
    test::assert_true(m.spot_nodes()[1] > 50.0);
    test::assert_true(m.spot_nodes()[1] < 150.0);
}

TEST(mesh_strike_at_boundary) {
    SinhMesh m_low(0.0, 0.0, 200.0, 101, 20.0);
    test::assert_near(m_low.spot_nodes().front(), 0.0, 1e-15);

    SinhMesh m_high(200.0, 0.0, 200.0, 101, 20.0);
    test::assert_near(m_high.spot_nodes().back(), 200.0, 1e-15);
}

TEST(mesh_large_concentration_approaches_uniform) {
    SinhMesh m(100.0, 0.0, 300.0, 201, 1e6);
    // With c → ∞, sinh(x/c) ≈ x/c  so mesh → linear
    test::assert_true(m.spacing_ratio() < 1.01,
                      "very large c should give near-uniform grid");
}

TEST(mesh_ds_sum_equals_domain_width) {
    SinhMesh m(100.0, 0.0, 300.0, 201, 20.0);
    double sum = 0.0;
    for (auto d : m.ds()) sum += d;
    test::assert_near(sum, 300.0, 1e-10, "ds must sum to S_max - S_min");
}

int main() { RUN_TESTS(); }
