#include "test_harness.hpp"
#include "nabla/nabla.hpp"
#include <cmath>

using namespace nabla;

// ── Black-Scholes analytical formula for validation ──────────────────

static double norm_cdf(double x) {
    return 0.5 * std::erfc(-x / std::sqrt(2.0));
}

static double bs_call(double S, double K, double T, double r, double sigma, double q) {
    double d1 = (std::log(S / K) + (r - q + 0.5 * sigma * sigma) * T)
              / (sigma * std::sqrt(T));
    double d2 = d1 - sigma * std::sqrt(T);
    return S * std::exp(-q * T) * norm_cdf(d1)
         - K * std::exp(-r * T) * norm_cdf(d2);
}

static double bs_put(double S, double K, double T, double r, double sigma, double q) {
    double d1 = (std::log(S / K) + (r - q + 0.5 * sigma * sigma) * T)
              / (sigma * std::sqrt(T));
    double d2 = d1 - sigma * std::sqrt(T);
    return K * std::exp(-r * T) * norm_cdf(-d2)
         - S * std::exp(-q * T) * norm_cdf(-d1);
}

static SinhMesh make_mesh(double K) {
    return SinhMesh(K, 0.0, 4.0 * K, 401, K / 5.0);
}

// ── Construction ─────────────────────────────────────────────────────

TEST(solver_construction) {
    auto mesh = make_mesh(100.0);
    BoundaryConditions bc({100.0, 1.0, OptionType::Call},
                          {100.0, 0.05, 0.2, 0.0}, mesh);
    CrankNicolsonSolver solver(mesh, bc, 200);
    // Should not throw
    test::assert_true(true);
}

TEST(solver_rejects_too_few_nodes) {
    SinhMesh mesh(100.0, 50.0, 150.0, 3, 10.0);
    BoundaryConditions bc({100.0, 1.0, OptionType::Call},
                          {100.0, 0.05, 0.2, 0.0}, mesh);
    // 3 nodes => 1 interior node => should work (tridiagonal is 1x1)
    CrankNicolsonSolver solver(mesh, bc, 100);
    test::assert_true(true);
}

TEST(solver_rejects_zero_time_steps) {
    auto mesh = make_mesh(100.0);
    BoundaryConditions bc({100.0, 1.0, OptionType::Call},
                          {100.0, 0.05, 0.2, 0.0}, mesh);
    test::assert_throws([&]{
        CrankNicolsonSolver solver(mesh, bc, 0);
    });
}

// ── ATM Call price vs Black-Scholes ──────────────────────────────────

TEST(solver_atm_call_vs_bs) {
    double S = 100.0, K = 100.0, T = 1.0, r = 0.05, sigma = 0.2, q = 0.0;
    auto mesh = SinhMesh(K, 0.0, 5.0 * K, 801, K / 8.0);
    BoundaryConditions bc({K, T, OptionType::Call}, {S, r, sigma, q}, mesh);
    CrankNicolsonSolver solver(mesh, bc, 400);
    auto result = solver.solve();

    double analytical = bs_call(S, K, T, r, sigma, q);
    test::assert_near(result.price, analytical, 0.05,
                      "ATM call: PDE=" + std::to_string(result.price) +
                      " BS=" + std::to_string(analytical));
}

// ── ITM Call ──────────────────────────────────────────────────────────

TEST(solver_itm_call_vs_bs) {
    double S = 120.0, K = 100.0, T = 1.0, r = 0.05, sigma = 0.2, q = 0.0;
    auto mesh = SinhMesh(K, 0.0, 5.0 * K, 801, K / 8.0);
    BoundaryConditions bc({K, T, OptionType::Call}, {S, r, sigma, q}, mesh);
    CrankNicolsonSolver solver(mesh, bc, 400);
    auto result = solver.solve();

    double analytical = bs_call(S, K, T, r, sigma, q);
    test::assert_near(result.price, analytical, 0.05,
                      "ITM call: PDE=" + std::to_string(result.price) +
                      " BS=" + std::to_string(analytical));
}

// ── OTM Call ──────────────────────────────────────────────────────────

TEST(solver_otm_call_vs_bs) {
    double S = 80.0, K = 100.0, T = 1.0, r = 0.05, sigma = 0.2, q = 0.0;
    auto mesh = SinhMesh(K, 0.0, 5.0 * K, 801, K / 8.0);
    BoundaryConditions bc({K, T, OptionType::Call}, {S, r, sigma, q}, mesh);
    CrankNicolsonSolver solver(mesh, bc, 400);
    auto result = solver.solve();

    double analytical = bs_call(S, K, T, r, sigma, q);
    test::assert_near(result.price, analytical, 0.05,
                      "OTM call: PDE=" + std::to_string(result.price) +
                      " BS=" + std::to_string(analytical));
}

// ── ATM Put ──────────────────────────────────────────────────────────

TEST(solver_atm_put_vs_bs) {
    double S = 100.0, K = 100.0, T = 1.0, r = 0.05, sigma = 0.2, q = 0.0;
    auto mesh = SinhMesh(K, 0.0, 5.0 * K, 801, K / 8.0);
    BoundaryConditions bc({K, T, OptionType::Put}, {S, r, sigma, q}, mesh);
    CrankNicolsonSolver solver(mesh, bc, 400);
    auto result = solver.solve();

    double analytical = bs_put(S, K, T, r, sigma, q);
    test::assert_near(result.price, analytical, 0.05,
                      "ATM put: PDE=" + std::to_string(result.price) +
                      " BS=" + std::to_string(analytical));
}

// ── Put-Call Parity from PDE ─────────────────────────────────────────

TEST(solver_put_call_parity) {
    double S = 100.0, K = 100.0, T = 1.0, r = 0.05, sigma = 0.2, q = 0.0;
    auto mesh = SinhMesh(K, 0.0, 5.0 * K, 801, K / 8.0);
    BoundaryConditions call_bc({K, T, OptionType::Call}, {S, r, sigma, q}, mesh);
    BoundaryConditions put_bc({K, T, OptionType::Put}, {S, r, sigma, q}, mesh);

    CrankNicolsonSolver call_solver(mesh, call_bc, 400);
    CrankNicolsonSolver put_solver(mesh, put_bc, 400);

    auto call_result = call_solver.solve();
    auto put_result = put_solver.solve();

    // C - P = S*exp(-qT) - K*exp(-rT)
    double parity = S * std::exp(-q * T) - K * std::exp(-r * T);
    double diff = call_result.price - put_result.price;

    test::assert_near(diff, parity, 0.1,
                      "put-call parity: C-P=" + std::to_string(diff) +
                      " expected=" + std::to_string(parity));
}

// ── Dividend yield ───────────────────────────────────────────────────

TEST(solver_call_with_dividend_vs_bs) {
    double S = 100.0, K = 100.0, T = 1.0, r = 0.05, sigma = 0.2, q = 0.02;
    auto mesh = SinhMesh(K, 0.0, 5.0 * K, 801, K / 8.0);
    BoundaryConditions bc({K, T, OptionType::Call}, {S, r, sigma, q}, mesh);
    CrankNicolsonSolver solver(mesh, bc, 400);
    auto result = solver.solve();

    double analytical = bs_call(S, K, T, r, sigma, q);
    test::assert_near(result.price, analytical, 0.05,
                      "call with div: PDE=" + std::to_string(result.price) +
                      " BS=" + std::to_string(analytical));
}

// ── Short maturity ───────────────────────────────────────────────────

TEST(solver_short_maturity_call) {
    double S = 100.0, K = 100.0, T = 0.1, r = 0.05, sigma = 0.2, q = 0.0;
    auto mesh = SinhMesh(K, 0.0, 4.0 * K, 601, K / 10.0);
    BoundaryConditions bc({K, T, OptionType::Call}, {S, r, sigma, q}, mesh);
    CrankNicolsonSolver solver(mesh, bc, 200);
    auto result = solver.solve();

    double analytical = bs_call(S, K, T, r, sigma, q);
    test::assert_near(result.price, analytical, 0.03,
                      "short maturity call: PDE=" + std::to_string(result.price) +
                      " BS=" + std::to_string(analytical));
}

// ── High volatility ──────────────────────────────────────────────────

TEST(solver_high_vol_call) {
    double S = 100.0, K = 100.0, T = 1.0, r = 0.05, sigma = 0.5, q = 0.0;
    auto mesh = SinhMesh(K, 0.0, 6.0 * K, 801, K / 6.0);
    BoundaryConditions bc({K, T, OptionType::Call}, {S, r, sigma, q}, mesh);
    CrankNicolsonSolver solver(mesh, bc, 400);
    auto result = solver.solve();

    double analytical = bs_call(S, K, T, r, sigma, q);
    test::assert_near(result.price, analytical, 0.10,
                      "high vol call: PDE=" + std::to_string(result.price) +
                      " BS=" + std::to_string(analytical));
}

// ── Grid convergence (Richardson) ────────────────────────────────────

TEST(solver_convergence_with_refinement) {
    double S = 100.0, K = 100.0, T = 1.0, r = 0.05, sigma = 0.2, q = 0.0;
    double analytical = bs_call(S, K, T, r, sigma, q);

    double err_coarse, err_fine;
    {
        auto mesh = SinhMesh(K, 0.0, 5.0 * K, 201, K / 8.0);
        BoundaryConditions bc({K, T, OptionType::Call}, {S, r, sigma, q}, mesh);
        CrankNicolsonSolver solver(mesh, bc, 100);
        auto result = solver.solve();
        err_coarse = std::fabs(result.price - analytical);
    }
    {
        auto mesh = SinhMesh(K, 0.0, 5.0 * K, 801, K / 8.0);
        BoundaryConditions bc({K, T, OptionType::Call}, {S, r, sigma, q}, mesh);
        CrankNicolsonSolver solver(mesh, bc, 400);
        auto result = solver.solve();
        err_fine = std::fabs(result.price - analytical);
    }

    test::assert_true(err_fine < err_coarse,
                      "finer grid should reduce error: coarse=" +
                      std::to_string(err_coarse) + " fine=" +
                      std::to_string(err_fine));
}

// ── Fully implicit (theta=1) still converges ─────────────────────────

TEST(solver_fully_implicit) {
    double S = 100.0, K = 100.0, T = 1.0, r = 0.05, sigma = 0.2, q = 0.0;
    auto mesh = SinhMesh(K, 0.0, 5.0 * K, 801, K / 8.0);
    BoundaryConditions bc({K, T, OptionType::Call}, {S, r, sigma, q}, mesh);
    CrankNicolsonSolver solver(mesh, bc, 400, 1.0);
    auto result = solver.solve();

    double analytical = bs_call(S, K, T, r, sigma, q);
    test::assert_near(result.price, analytical, 0.15,
                      "fully implicit: PDE=" + std::to_string(result.price) +
                      " BS=" + std::to_string(analytical));
}

// ── Interpolation ────────────────────────────────────────────────────

TEST(solver_interpolation_at_nodes) {
    auto mesh = make_mesh(100.0);
    const auto& S = mesh.spot_nodes();
    std::vector<double> grid(mesh.size());
    for (std::size_t i = 0; i < mesh.size(); ++i)
        grid[i] = S[i] * S[i];  // V = S^2

    for (std::size_t i = 0; i < mesh.size(); ++i) {
        double interp = CrankNicolsonSolver::interpolate(mesh, grid, S[i]);
        test::assert_near(interp, grid[i], 1e-10,
                          "interpolation at node " + std::to_string(i));
    }
}

TEST(solver_interpolation_between_nodes) {
    auto mesh = make_mesh(100.0);
    // Linear function: exact interpolation
    std::vector<double> grid(mesh.size());
    for (std::size_t i = 0; i < mesh.size(); ++i)
        grid[i] = 2.0 * mesh.spot_nodes()[i] + 5.0;

    double spot = 123.456;
    double expected = 2.0 * spot + 5.0;
    double interp = CrankNicolsonSolver::interpolate(mesh, grid, spot);
    test::assert_near(interp, expected, 1e-8,
                      "linear interpolation should be exact");
}

// ── Non-negativity ───────────────────────────────────────────────────

TEST(solver_prices_nonnegative) {
    double S = 100.0, K = 100.0, T = 1.0, r = 0.05, sigma = 0.2, q = 0.0;
    auto mesh = SinhMesh(K, 0.0, 5.0 * K, 401, K / 8.0);
    BoundaryConditions bc({K, T, OptionType::Call}, {S, r, sigma, q}, mesh);
    CrankNicolsonSolver solver(mesh, bc, 200);
    auto result = solver.solve();

    for (std::size_t i = 0; i < result.grid.size(); ++i)
        test::assert_true(result.grid[i] >= -1e-10,
                          "option value must be non-negative at node " +
                          std::to_string(i));
}

int main() { RUN_TESTS(); }
