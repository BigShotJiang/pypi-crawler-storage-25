import pandas as pd
import pytest
from pydantic import BaseModel

import datachain as dc
from datachain import func
from datachain.lib.dc import C
from tests.utils import is_sha256_hex

DF_DATA = {
    "first_name": ["Alice", "Bob", "Charlie", "David", "Eva"],
    "age": [25, 30, 35, 40, 45],
}


class Person(BaseModel):
    name: str
    age: float


class PersonAgg(BaseModel):
    name: str
    ages: float


class Player(BaseModel):
    name: str
    sport: str


class Worker(BaseModel):
    name: str
    age: float
    title: str


persons = [
    Person(name="p1", age=10),
    Person(name="p2", age=20),
    Person(name="p3", age=30),
    Person(name="p4", age=40),
    Person(name="p5", age=40),
    Person(name="p6", age=60),
]


players = [
    Player(name="p1", sport="baksetball"),
    Player(name="p2", sport="soccer"),
    Player(name="p3", sport="baseball"),
    Player(name="p4", sport="tennis"),
]


def _set_stable_uuid(test_session, name, uuid):
    """Set a stable UUID on a dataset version for deterministic hash tests."""
    parts = name.split(".")
    ds_name = parts[-1]
    ns = parts[0] if len(parts) > 1 else "default"
    proj = parts[1] if len(parts) > 2 else "default"
    test_session.catalog.metastore.update_dataset_version(
        test_session.catalog.get_dataset(
            ds_name,
            namespace_name=ns,
            project_name=proj,
            versions=["1.0.0"],
        ),
        "1.0.0",
        uuid=uuid,
    )


def test_read_values():
    """
    Hash of the chain started with read_values is currently inconsistent.
    Goal of this test is just to check it doesn't break.
    """
    assert dc.read_values(num=[1, 2, 3])._query.hash() is not None


def test_read_csv(test_session, tmp_dir):
    """
    Hash of the chain started with read_csv is currently inconsistent.
    Goal of this test is just to check it doesn't break.
    """
    path = tmp_dir / "test.csv"
    pd.DataFrame(DF_DATA).to_csv(path, index=False)
    assert dc.read_csv(path.as_uri(), session=test_session)._query.hash() is not None


@pytest.mark.filterwarnings("ignore::pydantic.warnings.PydanticDeprecatedSince20")
def test_read_json(test_session, tmp_dir):
    """
    Hash of the chain started with read_json is currently inconsistent.
    Goal of this test is just to check it doesn't break.
    """
    path = tmp_dir / "test.jsonl"
    dc.read_pandas(pd.DataFrame(DF_DATA), session=test_session).to_jsonl(path)
    assert (
        dc.read_json(path.as_uri(), format="jsonl", session=test_session)._query.hash()
        is not None
    )


def test_read_pandas(test_session, tmp_dir):
    """
    Hash of the chain started with read_pandas is currently inconsistent.
    Goal of this test is just to check it doesn't break.
    """
    df = pd.DataFrame(DF_DATA)
    assert dc.read_pandas(df, session=test_session)._query.hash() is not None


def test_read_parquet(test_session, tmp_dir):
    """
    Hash of the chain started with read_parquet is currently inconsistent.
    Goal of this test is just to check it doesn't break.
    """
    df = pd.DataFrame(DF_DATA)
    path = tmp_dir / "test.parquet"
    dc.read_pandas(df, session=test_session).to_parquet(path)
    assert (
        dc.read_parquet(path.as_uri(), session=test_session)._query.hash() is not None
    )


def test_read_storage(test_session, tmp_dir):
    (tmp_dir / "file1.txt").write_text("hello")
    uri = tmp_dir.as_uri()

    chain1 = dc.read_storage(uri, session=test_session)
    chain1._query.resolve_listing()
    hash1 = chain1._query.hash()

    chain2 = dc.read_storage(uri, session=test_session)
    chain2._query.resolve_listing()
    hash2 = chain2._query.hash()

    assert is_sha256_hex(hash1)
    assert hash1 == hash2


def test_read_storage_update_changes_hash(test_session, tmp_dir):
    (tmp_dir / "file1.txt").write_text("hello")
    uri = tmp_dir.as_uri()

    chain1 = dc.read_storage(uri, session=test_session)
    chain1._query.resolve_listing()
    hash1 = chain1._query.hash()

    # Add a new file and re-list with update=True
    (tmp_dir / "file2.txt").write_text("world")

    chain2 = dc.read_storage(uri, session=test_session, update=True)
    chain2._query.resolve_listing()
    hash2 = chain2._query.hash()

    assert is_sha256_hex(hash1)
    assert is_sha256_hex(hash2)
    assert hash1 != hash2


def test_read_dataset(test_session):
    dc.read_values(num=[1, 2, 3], session=test_session).save("dev.animals.cats")
    _set_stable_uuid(
        test_session, "dev.animals.cats", "b1c2d3e4-f5a6-4b1c-8d3e-4f5a6b1c2d3e"
    )
    assert dc.read_dataset(
        name="dev.animals.cats", version="1.0.0", session=test_session
    )._query.hash() == (
        "58c939b8626443e5d68e9e419a9a5fd1bc7282ca0c5e06cfeb578635e9703a06"
    )


def test_read_dataset_delta_hash_changes_with_delta_spec(test_session):
    dataset_name = "dev.animals.delta_hash"
    dc.read_values(id=[1, 2, 3], value=[10, 20, 30], session=test_session).save(
        dataset_name
    )

    base_hash = dc.read_dataset(
        name=dataset_name,
        version="1.0.0",
        session=test_session,
    )._query.hash()
    delta_hash = dc.read_dataset(
        name=dataset_name,
        version="1.0.0",
        session=test_session,
        delta=True,
        delta_on="id",
    )._query.hash()
    delta_compare_hash = dc.read_dataset(
        name=dataset_name,
        version="1.0.0",
        session=test_session,
        delta=True,
        delta_on="id",
        delta_compare="value",
    )._query.hash()
    delta_unsafe_hash = dc.read_dataset(
        name=dataset_name,
        version="1.0.0",
        session=test_session,
        delta=True,
        delta_on="id",
        delta_unsafe=True,
    )._query.hash()

    assert base_hash != delta_hash
    assert delta_hash != delta_compare_hash
    assert delta_hash != delta_unsafe_hash


def test_order_of_steps(test_session, tmp_dir):
    (tmp_dir / "file1.txt").write_text("hello")
    uri = tmp_dir.as_uri()

    chain1 = (
        dc.read_storage(uri, session=test_session).mutate(new=10).filter(C("age") > 20)
    )
    chain1._query.resolve_listing()
    hash1 = chain1._query.hash()

    chain2 = (
        dc.read_storage(uri, session=test_session).filter(C("age") > 20).mutate(new=10)
    )
    chain2._query.resolve_listing()
    hash2 = chain2._query.hash()

    assert is_sha256_hex(hash1)
    assert is_sha256_hex(hash2)
    assert hash1 != hash2


def test_all_possible_steps(test_session):
    persons_ds_name = "dev.my_pr.persons"
    players_ds_name = "dev.my_pr.players"

    def map_worker(person: Person) -> Worker:
        return Worker(
            name=person.name,
            age=person.age,
            title="worker",
        )

    def gen_persons(person):
        yield Person(
            age=person.age * 2,
            name=person.name + "_suf",
        )

    def agg_persons(persons):
        return PersonAgg(ages=sum(p.age for p in persons), name=persons[0].age)

    dc.read_values(person=persons, session=test_session).save(persons_ds_name)
    dc.read_values(player=players, session=test_session).save(players_ds_name)
    _set_stable_uuid(
        test_session, persons_ds_name, "a1a1a1a1-b2b2-4c3c-8d4d-e5e5e5e5e5e5"
    )
    _set_stable_uuid(
        test_session, players_ds_name, "f6f6f6f6-a7a7-4b8b-8c9c-d0d0d0d0d0d0"
    )

    players_chain = dc.read_dataset(
        players_ds_name, version="1.0.0", session=test_session
    )

    def _build_chain():
        return (
            dc.read_dataset(persons_ds_name, version="1.0.0", session=test_session)
            .mutate(age_double=C("person.age") * 2)
            .filter(C("person.age") > 20)
            .order_by("person.name", "person.age")
            .gen(
                person=gen_persons,
                output=Person,
            )
            .map(
                worker=map_worker,
                params="person",
                output={"worker": Worker},
            )
            .agg(
                persons=agg_persons,
                partition_by=C.person.name,
                params="person",
                output={"persons": PersonAgg},
            )
            .merge(players_chain, "persons.name", "player.name")
            .distinct("persons.name")
            .sample(10)
            .offset(2)
            .limit(5)
            .group_by(age_avg=func.avg("persons.ages"), partition_by="persons.name")
            .select("persons.name", "age_avg")
            .subtract(
                players_chain,
                on=["persons.name"],
                right_on=["player.name"],
            )
        )

    h1 = _build_chain()._query.hash()
    h2 = _build_chain()._query.hash()
    assert h1 == h2
    assert is_sha256_hex(h1)


def test_diff(test_session):
    persons_ds_name = "dev.my_pr.persons"
    players_ds_name = "dev.my_pr.players"

    dc.read_values(person=persons, session=test_session).save(persons_ds_name)
    dc.read_values(player=players, session=test_session).save(players_ds_name)
    _set_stable_uuid(
        test_session, persons_ds_name, "a1a1a1a1-b2b2-4c3c-8d4d-e5e5e5e5e5e5"
    )
    _set_stable_uuid(
        test_session, players_ds_name, "f6f6f6f6-a7a7-4b8b-8c9c-d0d0d0d0d0d0"
    )

    players_chain = dc.read_dataset(
        players_ds_name, version="1.0.0", session=test_session
    )

    def _build_chain():
        return dc.read_dataset(
            persons_ds_name, version="1.0.0", session=test_session
        ).diff(
            players_chain,
            on=["person.name"],
            right_on=["player.name"],
            status_col="diff",
        )

    h1 = _build_chain()._query.hash()
    h2 = _build_chain()._query.hash()
    assert h1 == h2
    assert is_sha256_hex(h1)
