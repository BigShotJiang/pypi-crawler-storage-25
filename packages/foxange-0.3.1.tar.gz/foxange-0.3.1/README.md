# foxange

A collection of convenient Python utility functions for input, file handling, and list processing.

---

## Functions Overview

### Input Utilities (`foxange.input`)

- **collect_input**  
  Prompt for sequential user input; returns a list of the inputted values.
  ```python
  from foxange.input import collect_input
  answers = collect_input("Enter your name: ", "Enter your age: ")
  # ['Alice', '30']
  ```

- **input_to_file**  
  Write specified strings to a file (also available in foxange.file).
  ```python
  from foxange.input import input_to_file
  input_to_file("hello", "foxange", path="test.txt")
  # test.txt will contain:
  # hello
  # foxange
  ```

- **sanitize_input**  
  Remove multiple substrings from text.
  ```python
  from foxange.input import sanitize_input
  print(sanitize_input("hello", "e", "o"))  # "hll"
  ```

- **numeric_input**  
  Get input and return it only if length is within specified bounds.
  ```python
  from foxange.input import numeric_input
  val = numeric_input("Type (2-4 chars): ", 2, 4, notvalid="N/A")
  ```

- **choice_input**  
  Present choices and get the user’s selection (may need adjustment for your use-case).
  ```python
  from foxange.input import choice_input
  print(choice_input("Pick one:", ["a", "b", "c"], "Choose: "))
  ```

- **confirm**  
  Simple yes/no user prompt returning `True`, `False`, or `None`.
  ```python
  from foxange.input import confirm
  if confirm("Continue?"): 
      print("Confirmed!")
  ```

---

### File Utilities (`foxange.file`)

- **input_to_file**  
  See above.

- **read_lines**  
  Read lines from a file into a list (strips newlines by default).
  ```python
  from foxange.file import read_lines
  print(read_lines("text.txt"))  # ["line 1", "line 2"]
  ```

- **write_lines**  
  Write a list of strings to a file, one per line.
  ```python
  from foxange.file import write_lines
  write_lines("out.txt", ["foo", "bar"])
  ```

- **tail / head**  
  Get the last/first N lines of a file.
  ```python
  from foxange.file import tail, head
  print(tail("log.txt", 5))
  print(head("log.txt", 5))
  ```

- **safe_read_json / safe_write_json**  
  Robust JSON file read/write with error fallback.
  ```python
  from foxange.file import safe_read_json, safe_write_json
  data = safe_read_json("settings.json", default={})
  safe_write_json("settings.json", {"theme": "dark"})
  ```

- **get_file_size**  
  Return the file size (bytes or human-readable).
  ```python
  from foxange.file import get_file_size
  print(get_file_size("large.bin", human_readable=True))  # "1.1 MB"
  ```

- **ensure_dir**  
  Ensure a directory exists (create if needed).
  ```python
  from foxange.file import ensure_dir
  ensure_dir("output/")
  ```

- **atomic_write**  
  Safely write to a file using a temporary buffer.
  ```python
  from foxange.file import atomic_write
  atomic_write("a.txt", "data")
  ```

- **find_files**  
  Recursively find files matching a pattern.
  ```python
  from foxange.file import find_files
  print(find_files(".", "*.py"))
  ```

---

### List Processing Utilities (`foxange.list_proce`)

- **remove**  
  Remove all elements satisfying the given condition.
  ```python
  from foxange.list_proce import remove
  odds = remove([1, 2, 3, 4], lambda x: x % 2 == 0)  # [1, 3]
  ```

- **unique**  
  Return unique entries from a list.  
  _Note: fix suggested—code may not deduplicate as expected._
  ```python
  from foxange.list_proce import unique
  print(unique([1, 1, 2]))  # [1, 2]
  ```

- **rotate**  
  Circularly rotate a list right by `n` positions.
  ```python
  from foxange.list_proce import rotate
  print(rotate([1, 2, 3, 4], 2))  # [3, 4, 1, 2]
  ```

---

## How to Use

Import the specific function you need:
```python
from foxange.input import collect_input
from foxange.file import read_lines
from foxange.list_proce import unique
```

Explore the `src/foxange/` directory for all available modules and features!

---

## License

MIT
