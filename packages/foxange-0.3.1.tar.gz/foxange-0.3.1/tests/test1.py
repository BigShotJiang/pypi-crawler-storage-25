import foxange 

name,arg = foxange.list_proce.spread(foxange.input.collect_input("姓名","年龄"))