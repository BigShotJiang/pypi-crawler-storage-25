from datetime import datetime
import numpy as np
from pytest import mark
from hestia_earth.schema import NodeType

from hestia_earth.utils.tools import (
    as_list,
    as_set,
    as_tuple,
    auto_round,
    non_empty_value,
    non_empty_list,
    is_term,
    current_time_ms,
    current_time_str,
    safe_parse_float,
    safe_parse_date,
    list_sum,
    list_average,
    flatten,
    get_dict_key,
    to_precision,
    is_number,
    is_boolean,
    omit,
    pick,
    unique_values,
    is_list_like,
)


def test_non_empty_value():
    assert not non_empty_value("")
    assert not non_empty_value([])
    assert not non_empty_value({})
    assert non_empty_value("test") is True
    assert non_empty_value(False) is True
    assert non_empty_value(1) is True
    assert non_empty_value(np.float64(10)) is True


def test_non_empty_list():
    assert non_empty_list(["", 1, [], False]) == [1, False]


def test_is_term():
    assert not is_term({"@type": NodeType.CYCLE.value})
    assert is_term({"type": NodeType.TERM.value}) is True


def test_current_time_ms():
    assert current_time_ms() > 1000


def test_current_time_str():
    assert len(current_time_str()) == 20


def test_safe_parse_float():
    assert safe_parse_float("123.456") == 123.456
    assert safe_parse_float("abcd", 10) == 10
    assert safe_parse_float(np.nan, 1) == 1


def test_safe_parse_date():
    assert safe_parse_date("2020-01-01") == datetime(2020, 1, 1)
    assert safe_parse_date("abcd", datetime(2020, 1, 1)) == datetime(2020, 1, 1)


def test_list_sum():
    assert list_sum([0, 1]) == 1
    assert list_sum([]) == 0
    assert list_sum(None) == 0
    assert list_sum("value") == 0

    assert list_sum([], None) is None
    assert list_sum([None], None) is None

    assert list_sum(["random"], None) is None


def test_list_average():
    assert list_average([0, 1]) == 0.5
    assert list_average([]) == 0
    assert list_average(None) == 0
    assert list_average("value") == 0

    assert list_average([], None) is None
    assert list_average([None], None) is None

    assert list_average(["random"], None) is None


def test_flatten():
    assert flatten([[0, 1], 2, [3, 4]]) == [0, 1, 2, 3, 4]


def test_get_dict_key():
    value = {"a": "test", "b": {"id": "id"}, "c": {"d": [{"id": 1}, {"id": 2}]}}
    assert get_dict_key(value, "a") == "test"
    assert get_dict_key(value, "b.id") == "id"
    assert get_dict_key(value, "c.d.id") == [1, 2]


@mark.parametrize(
    "args, expected, test_id",
    [
        ((0,), 0, "0, default s.f."),
        ((False,), False, "bool False"),
        ((True,), True, "bool True"),
        ((np.nan,), np.nan, "nan"),
        ((np.inf,), np.inf, "inf"),
        ((-np.inf,), -np.inf, "-inf"),
        ((0.3141592,), 0.314, "pi*10^-1, 3 s.f."),
        ((3.141592,), 3.14, "pi, 3 s.f."),
        ((31.41592,), 31.4, "pi*10, 3 s.f."),
        ((314.1592,), 314, "pi*10^2, 3 s.f."),
        ((3141.592,), 3140, "pi*10^3, 3 s.f."),
        ((31415.92,), 31400, "pi*10^4, 3 s.f."),
        ((314159.2,), 314000, "pi*10^5, 3 s.f."),
        ((365, 0), 0, "365, 0 s.f."),
        ((0.45249,), 0.452, "0.45249, default s.f."),
        ((1.45213,), 1.45, "1.45213, default s.f."),
        ((144.5213,), 145, "144.5213, default s.f."),
        ((0.45249, 1), 0.5, "0.45249, 1 s.f."),
        ((1.45213, 1), 1, "1.45213, 1 s.f."),
        ((145, 1), 100, "145, 1 s.f."),
        ((0.000152,), 0.000152, "0.000152, default s.f."),
        ((9089080.000000001111,), 9090000, "9089080.000000001111, default s.f."),
        ((2.4790000000000002e-09,), 2.479e-09, "2.4790000000000002e-09, default s.f."),
        ((np.array(3.141592),), np.array(3.14), "pi as ndarray, 3 s.f."),
        (
            (
                np.array(
                    [
                        0.3141592,
                        3.141592,
                        31.41592,
                        314.1592,
                        3141.592,
                        31415.92,
                        314159.2,
                        np.nan,
                        np.inf,
                        -np.inf,
                    ]
                ),
            ),
            np.array(
                [
                    0.314,
                    3.14,
                    31.4,
                    314,
                    3140,
                    31400,
                    314000,
                    np.nan,
                    np.inf,
                    -np.inf,
                ]
            ),
            "1d array",
        ),
        (
            (
                np.array(
                    [
                        [
                            0.3141592,
                            3.141592,
                            31.41592,
                            314.1592,
                            3141.592,
                        ],
                        [
                            31415.92,
                            314159.2,
                            np.nan,
                            np.inf,
                            -np.inf,
                        ],
                    ]
                ),
            ),
            np.array(
                [
                    [
                        0.314,
                        3.14,
                        31.4,
                        314,
                        3140,
                    ],
                    [
                        31400,
                        314000,
                        np.nan,
                        np.inf,
                        -np.inf,
                    ],
                ]
            ),
            "2d array",
        ),
        ((0.3141592, 5), 0.31416, "pi*10^-1, 5 s.f."),
        ((3.141592, 5), 3.1416, "pi, 5 s.f."),
        ((31.41592, 5), 31.416, "pi*10, 5 s.f."),
        ((314.1592, 5), 314.16, "pi*10^2, 5 s.f."),
        ((3141.592, 5), 3141.6, "pi*10^3, 5 s.f."),
        ((31415.92, 5), 31416, "pi*10^4, 5 s.f."),
        ((314159.2, 5), 314160, "pi*10^5, 5 s.f."),
        ((np.array(3.141592), 5), np.array(3.1416), "pi as ndarray, 5 s.f."),
        (
            (
                np.array(
                    [
                        0.3141592,
                        3.141592,
                        31.41592,
                        314.1592,
                        3141.592,
                        31415.92,
                        314159.2,
                        np.nan,
                        np.inf,
                        -np.inf,
                    ]
                ),
                5,
            ),
            np.array(
                [
                    0.31416,
                    3.1416,
                    31.416,
                    314.16,
                    3141.6,
                    31416,
                    314160,
                    np.nan,
                    np.inf,
                    -np.inf,
                ]
            ),
            "1d array, 5 s.f.",
        ),
        (
            (
                np.array(
                    [
                        [
                            0.3141592,
                            3.141592,
                            31.41592,
                            314.1592,
                            3141.592,
                        ],
                        [
                            31415.92,
                            314159.2,
                            np.nan,
                            np.inf,
                            -np.inf,
                        ],
                    ]
                ),
                5,
            ),
            np.array(
                [
                    [
                        0.31416,
                        3.1416,
                        31.416,
                        314.16,
                        3141.6,
                    ],
                    [
                        31416,
                        314160,
                        np.nan,
                        np.inf,
                        -np.inf,
                    ],
                ]
            ),
            "2d array, 5 s.f.",
        ),
    ],
)
def test_to_precision(args: tuple, expected: float | int | np.ndarray, test_id: str):
    assert np.allclose(to_precision(*args), expected, equal_nan=True), test_id


@mark.parametrize(
    "args, expected, test_id",
    [
        ((0,), 0, "0, default s.f."),
        ((False,), False, "bool False"),
        ((True,), True, "bool True"),
        ((np.nan,), np.nan, "nan"),
        ((np.inf,), np.inf, "inf"),
        ((-np.inf,), -np.inf, "-inf"),
        ((0.3141592,), 0.314, "pi*10^-1, 3 s.f."),
        ((3.141592,), 3.14, "pi, 3 s.f."),
        ((31.41592,), 31.4, "pi*10, 3 s.f."),
        ((314.1592,), 314, "pi*10^2, 3 s.f."),
        ((3141.592,), 3142, "pi*10^3, 3 s.f."),
        ((31415.92,), 31416, "pi*10^4, 3 s.f."),
        ((314159.2,), 314159, "pi*10^5, 3 s.f."),
        ((np.array(3.141592),), np.array(3.14), "pi as ndarray, 3 s.f."),
        (
            (
                np.array(
                    [
                        0.3141592,
                        3.141592,
                        31.41592,
                        314.1592,
                        3141.592,
                        31415.92,
                        314159.2,
                        np.nan,
                        np.inf,
                        -np.inf,
                    ]
                ),
            ),
            np.array(
                [
                    0.314,
                    3.14,
                    31.4,
                    314,
                    3142,
                    31416,
                    314159,
                    np.nan,
                    np.inf,
                    -np.inf,
                ]
            ),
            "1d array",
        ),
        (
            (
                np.array(
                    [
                        [
                            0.3141592,
                            3.141592,
                            31.41592,
                            314.1592,
                            3141.592,
                        ],
                        [
                            31415.92,
                            314159.2,
                            np.nan,
                            np.inf,
                            -np.inf,
                        ],
                    ]
                ),
            ),
            np.array(
                [
                    [
                        0.314,
                        3.14,
                        31.4,
                        314,
                        3142,
                    ],
                    [
                        31416,
                        314159,
                        np.nan,
                        np.inf,
                        -np.inf,
                    ],
                ]
            ),
            "2d array",
        ),
        ((0.3141592, 5, 0, 10000), 0.31416, "pi*10^-1, 5 s.f."),
        ((3.141592, 5, 0, 10000), 3.1416, "pi, 5 s.f."),
        ((31.41592, 5, 0, 10000), 31.416, "pi*10, 5 s.f."),
        ((314.1592, 5, 0, 10000), 314.16, "pi*10^2, 5 s.f."),
        ((3141.592, 5, 0, 10000), 3141.6, "pi*10^3, 5 s.f."),
        ((31415.92, 5, 0, 10000), 31416, "pi*10^4, 5 s.f."),
        ((314159.2, 5, 0, 10000), 314159, "pi*10^5, 5 s.f."),
        ((np.array(3.141592), 5, 0, 10000), np.array(3.1416), "pi as ndarray, 5 s.f."),
        (
            (
                np.array(
                    [
                        0.3141592,
                        3.141592,
                        31.41592,
                        314.1592,
                        3141.592,
                        31415.92,
                        314159.2,
                        np.nan,
                        np.inf,
                        -np.inf,
                    ]
                ),
                5,
                0,
                10000,
            ),
            np.array(
                [
                    0.31416,
                    3.1416,
                    31.416,
                    314.16,
                    3141.6,
                    31416,
                    314159,
                    np.nan,
                    np.inf,
                    -np.inf,
                ]
            ),
            "1d array, 5 s.f.",
        ),
        (
            (
                np.array(
                    [
                        [
                            0.3141592,
                            3.141592,
                            31.41592,
                            314.1592,
                            3141.592,
                        ],
                        [
                            31415.92,
                            314159.2,
                            np.nan,
                            np.inf,
                            -np.inf,
                        ],
                    ]
                ),
                5,
                0,
                10000,
            ),
            np.array(
                [
                    [
                        0.31416,
                        3.1416,
                        31.416,
                        314.16,
                        3141.6,
                    ],
                    [
                        31416,
                        314159,
                        np.nan,
                        np.inf,
                        -np.inf,
                    ],
                ]
            ),
            "2d array, 5 s.f.",
        ),
    ],
)
def test_auto_round(args: tuple, expected: float | int | np.ndarray, test_id: str):
    assert np.allclose(auto_round(*args), expected, equal_nan=True), test_id


def test_is_number():
    assert is_number(10) is True
    assert is_number(10.01) is True
    assert not is_number(True)
    assert not is_number(False)
    assert not is_number("test")
    assert not is_number("0")


def test_is_boolean():
    assert not is_boolean(10)
    assert not is_boolean(10.01)
    assert is_boolean(True) is True
    assert is_boolean(False) is True
    assert not is_boolean("test")
    assert not is_boolean("0")


def test_omit():
    assert omit({"a": 1, "b": 2}, ["a"]) == {"b": 2}


def test_pick():
    assert pick({"a": 1, "b": 2}, ["a"]) == {"a": 1}


def test_unique_values():
    values = [{"@id": 1, "name": "a"}, {"@id": 2, "name": "a"}]
    assert unique_values(values) == values

    values = [{"@id": 1, "name": "a"}, {"@id": 1, "name": "b"}]
    assert unique_values(values) == [{"@id": 1, "name": "b"}]


@mark.parametrize(
    "input, expected",
    [
        ([1, 2, 3], True),
        ({1, 2, 3}, True),
        ((1, 2, 3), True),
        ({1: "a", 2: "b", 3: "c"}, True),
        (range(1, 4), True),
        ((x + 1 for x in range(3)), True),
        (1, False),
        ("123", False),
        (b"123", False),
    ],
    ids=[
        "list -> True",
        "set -> True",
        "tuple -> True",
        "dict -> True",
        "range -> True",
        "generator -> True",
        "int -> false",
        "str -> False",
        "bytes -> False",
    ],
)
def test_is_list_like(input, expected):
    assert is_list_like(input) == expected


@mark.parametrize(
    "input, expected",
    [
        ([1, 2, 3], [1, 2, 3]),
        ({1, 2, 3}, [1, 2, 3]),
        ((1, 2, 3), [1, 2, 3]),
        ({1: "a", 2: "b", 3: "c"}, [1, 2, 3]),
        (range(1, 4), [1, 2, 3]),
        ((x + 1 for x in range(3)), [1, 2, 3]),
        (1, [1]),
        ("123", ["123"]),
        (b"123", [b"123"]),
    ],
    ids=[
        "list",
        "set",
        "tuple",
        "dict",
        "range",
        "generator",
        "int -> wrap",
        "str -> wrap",
        "bytes -> wrap",
    ],
)
def test_as_list(input, expected):
    assert as_list(input) == expected


@mark.parametrize(
    "input, expected",
    [
        ([1, 2, 3, 3], {1, 2, 3}),  # duplicates removed
        ({1, 2, 3}, {1, 2, 3}),
        ((1, 2, 3, 3), {1, 2, 3}),  # duplicates removed
        ({1: "a", 2: "b", 3: "c"}, {1, 2, 3}),
        (range(1, 4), {1, 2, 3}),
        ((x + 1 for x in range(3)), {1, 2, 3}),
        (1, {1}),
        ("123", {"123"}),
        (b"123", {b"123"}),
    ],
    ids=[
        "list",
        "set",
        "tuple",
        "dict",
        "range",
        "generator",
        "int -> wrap",
        "str -> wrap",
        "bytes -> wrap",
    ],
)
def test_as_set(input, expected):
    assert as_set(input) == expected


@mark.parametrize(
    "input, expected",
    [
        ([1, 2, 3], (1, 2, 3)),
        ({1, 2, 3}, (1, 2, 3)),
        ((1, 2, 3), (1, 2, 3)),
        ({1: "a", 2: "b", 3: "c"}, (1, 2, 3)),
        (range(1, 4), (1, 2, 3)),
        ((x + 1 for x in range(3)), (1, 2, 3)),
        (1, (1,)),
        ("123", ("123",)),
        (b"123", (b"123",)),
    ],
    ids=[
        "list",
        "set",
        "tuple",
        "dict",
        "range",
        "generator",
        "int -> wrap",
        "str -> wrap",
        "bytes -> wrap",
    ],
)
def test_as_tuple(input, expected):
    assert as_tuple(input) == expected
