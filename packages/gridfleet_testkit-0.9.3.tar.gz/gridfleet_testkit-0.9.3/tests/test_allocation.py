from __future__ import annotations

from typing import TYPE_CHECKING

import pytest

from gridfleet_testkit.allocation import (
    AllocatedDevice,
    UnavailableInclude,
    hydrate_allocated_device,
    hydrate_allocated_device_from_driver,
)

if TYPE_CHECKING:
    from gridfleet_testkit.types import JsonObject


class FakeClient:
    def __init__(self) -> None:
        self.config_calls: list[str] = []
        self.capability_calls: list[str] = []
        self.device_calls: list[str] = []
        self.test_data_calls: list[str] = []

    def get_device_config(self, connection_target: str) -> JsonObject:
        self.config_calls.append(connection_target)
        return {"ip": "10.0.0.8", "username": "operator"}

    def get_device_capabilities(self, device_id: str) -> JsonObject:
        self.capability_calls.append(device_id)
        return {"appium:udid": "SERIAL123", "appium:deviceIP": "10.0.0.9"}

    def get_device(self, device_id: str) -> JsonObject:
        self.device_calls.append(device_id)
        return {
            "id": device_id,
            "name": "Pixel 6",
            "device_type": "real_device",
            "connection_type": "usb",
            "manufacturer": "Google",
            "model": "Pixel 6",
            "ip_address": "10.0.0.7",
        }

    def get_device_test_data(self, device_id: str) -> JsonObject:
        self.test_data_calls.append(device_id)
        return {"fetched": True}


def device_handle(**overrides: object) -> JsonObject:
    payload: JsonObject = {
        "device_id": "dev-1",
        "identity_value": "SERIAL123",
        "connection_target": "SERIAL123",
        "name": "Pixel 6",
        "pack_id": "appium-uiautomator2",
        "platform_id": "android_mobile",
        "platform_label": "Android",
        "os_version": "14",
        "host_ip": "192.168.1.10",
        "device_type": "real_device",
        "connection_type": "usb",
        "manufacturer": "Google",
        "model": "Pixel 6",
    }
    payload.update(overrides)
    return payload


def test_hydrate_allocated_device_uses_device_handle_and_fetches_config() -> None:
    client = FakeClient()

    allocated = hydrate_allocated_device(device_handle(), run_id="run-1", client=client)

    assert allocated == AllocatedDevice(
        run_id="run-1",
        device_id="dev-1",
        identity_value="SERIAL123",
        name="Pixel 6",
        pack_id="appium-uiautomator2",
        platform_id="android_mobile",
        platform_label="Android",
        os_version="14",
        connection_target="SERIAL123",
        host_ip="192.168.1.10",
        device_type="real_device",
        connection_type="usb",
        manufacturer="Google",
        model="Pixel 6",
        config={"ip": "10.0.0.8", "username": "operator"},
        live_capabilities=None,
        test_data=None,
    )
    assert client.config_calls == ["SERIAL123"]
    assert client.capability_calls == []
    assert client.device_calls == []


def test_hydrate_allocated_device_fetches_device_detail_when_handle_lacks_richer_fields() -> None:
    client = FakeClient()
    payload = device_handle(name=None, device_type=None, connection_type=None, manufacturer=None, model=None)
    del payload["name"]
    del payload["device_type"]
    del payload["connection_type"]
    del payload["manufacturer"]
    del payload["model"]

    allocated = hydrate_allocated_device(payload, run_id="run-1", client=client, fetch_config=False)

    assert allocated.name == "Pixel 6"
    assert allocated.device_type == "real_device"
    assert allocated.connection_type == "usb"
    assert allocated.manufacturer == "Google"
    assert allocated.model == "Pixel 6"
    assert client.device_calls == ["dev-1"]
    assert client.config_calls == []


def test_hydrate_allocated_device_requires_device_id() -> None:
    client = FakeClient()
    payload = device_handle()
    del payload["device_id"]

    with pytest.raises(ValueError, match="Allocated device payload is missing device_id"):
        hydrate_allocated_device(payload, run_id="run-1", client=client)


def test_hydrate_allocated_device_fetches_capabilities_when_requested() -> None:
    client = FakeClient()

    allocated = hydrate_allocated_device(
        device_handle(),
        run_id="run-1",
        client=client,
        fetch_config=False,
        fetch_capabilities=True,
    )

    assert allocated.live_capabilities == {"appium:udid": "SERIAL123", "appium:deviceIP": "10.0.0.9"}
    assert client.capability_calls == ["dev-1"]


def test_allocated_device_properties_prefer_stable_sources() -> None:
    allocated = AllocatedDevice(
        run_id="run-1",
        device_id="dev-1",
        identity_value="SERIAL123",
        name="Pixel 6",
        pack_id="appium-uiautomator2",
        platform_id="android_mobile",
        platform_label="Android",
        os_version="14",
        connection_target=None,
        host_ip=None,
        device_type="emulator",
        connection_type="virtual",
        manufacturer=None,
        model=None,
        config={"ip": "10.0.0.8"},
        live_capabilities={"appium:udid": "emulator-5554", "appium:deviceIP": "10.0.0.9"},
        test_data=None,
    )

    assert allocated.is_real_device is False
    assert allocated.is_simulator is True
    assert allocated.udid == "emulator-5554"
    assert allocated.device_ip == "10.0.0.9"
    assert allocated.platform_name == "Android"


def test_allocated_device_defaults_unavailable_includes() -> None:
    allocated = AllocatedDevice(
        run_id="run-1",
        device_id="dev-1",
        identity_value="SERIAL123",
        name="Pixel 6",
        pack_id="appium-uiautomator2",
        platform_id="android_mobile",
        platform_label="Android",
        os_version="14",
        connection_target="SERIAL123",
        host_ip="192.168.1.10",
        device_type="real_device",
        connection_type="usb",
        manufacturer="Google",
        model="Pixel 6",
        config=None,
        live_capabilities=None,
        test_data=None,
    )

    assert allocated.unavailable_includes == ()
    assert isinstance(allocated.unavailable_includes, tuple)
    assert all(isinstance(u, UnavailableInclude) for u in allocated.unavailable_includes)


def test_hydrate_allocated_device_uses_inline_config_and_skips_get() -> None:
    client = FakeClient()
    payload = device_handle(config={"ip": "10.0.0.8", "username": "operator", "password": "********"})

    allocated = hydrate_allocated_device(payload, run_id="run-1", client=client)

    assert allocated.config == {"ip": "10.0.0.8", "username": "operator", "password": "********"}
    assert client.config_calls == []
    assert client.device_calls == []


def test_hydrate_allocated_device_falls_back_to_get_device_config_when_inline_absent() -> None:
    client = FakeClient()

    allocated = hydrate_allocated_device(device_handle(), run_id="run-1", client=client)

    assert allocated.config == {"ip": "10.0.0.8", "username": "operator"}
    assert client.config_calls == ["SERIAL123"]


def test_hydrate_allocated_device_uses_inline_live_capabilities_and_skips_get() -> None:
    client = FakeClient()
    payload = device_handle(live_capabilities={"appium:udid": "INLINE-CAP", "appium:deviceIP": "10.0.0.99"})

    allocated = hydrate_allocated_device(payload, run_id="run-1", client=client, fetch_config=False)

    assert allocated.live_capabilities == {"appium:udid": "INLINE-CAP", "appium:deviceIP": "10.0.0.99"}
    assert client.capability_calls == []


def test_hydrate_allocated_device_uses_inline_live_capabilities_even_when_fetch_capabilities_false() -> None:
    client = FakeClient()
    payload = device_handle(live_capabilities={"appium:udid": "INLINE-CAP"})

    allocated = hydrate_allocated_device(
        payload,
        run_id="run-1",
        client=client,
        fetch_config=False,
        fetch_capabilities=False,
    )

    assert allocated.live_capabilities == {"appium:udid": "INLINE-CAP"}
    assert client.capability_calls == []


def test_hydrate_allocated_device_surfaces_unavailable_includes() -> None:
    client = FakeClient()
    payload = device_handle(
        unavailable_includes=[{"include": "capabilities", "reason": "device_offline"}],
    )

    allocated = hydrate_allocated_device(payload, run_id="run-1", client=client, fetch_config=False)

    assert allocated.unavailable_includes == (UnavailableInclude(include="capabilities", reason="device_offline"),)


def test_hydrate_allocated_device_unavailable_includes_defaults_to_empty_tuple() -> None:
    client = FakeClient()

    allocated = hydrate_allocated_device(device_handle(), run_id="run-1", client=client, fetch_config=False)

    assert allocated.unavailable_includes == ()


def test_hydrate_allocated_device_skips_malformed_unavailable_include_entries() -> None:
    client = FakeClient()
    payload = device_handle(
        unavailable_includes=[
            {"include": "capabilities", "reason": "device_offline"},
            {"include": "config"},
            "not-a-dict",
            {"reason": "missing_include_key"},
        ],
    )

    allocated = hydrate_allocated_device(payload, run_id="run-1", client=client, fetch_config=False)

    assert allocated.unavailable_includes == (UnavailableInclude(include="capabilities", reason="device_offline"),)


def test_hydrate_allocated_device_skips_config_fetch_when_marked_unavailable() -> None:
    client = FakeClient()
    payload = device_handle(
        unavailable_includes=[{"include": "config", "reason": "device_offline"}],
    )

    allocated = hydrate_allocated_device(payload, run_id="run-1", client=client)

    assert allocated.config is None
    assert client.config_calls == []
    assert allocated.unavailable_includes == (UnavailableInclude(include="config", reason="device_offline"),)


def test_hydrate_allocated_device_skips_capabilities_fetch_when_marked_unavailable() -> None:
    client = FakeClient()
    payload = device_handle(
        unavailable_includes=[{"include": "capabilities", "reason": "device_offline"}],
    )

    allocated = hydrate_allocated_device(
        payload,
        run_id="run-1",
        client=client,
        fetch_config=False,
        fetch_capabilities=True,
    )

    assert allocated.live_capabilities is None
    assert client.capability_calls == []
    assert allocated.unavailable_includes == (UnavailableInclude(include="capabilities", reason="device_offline"),)


def test_hydrate_allocated_device_from_driver_returns_new_frozen_instance() -> None:
    client = FakeClient()
    allocated = hydrate_allocated_device(device_handle(), run_id="run-1", client=client, fetch_config=False)
    driver = type("Driver", (), {"capabilities": {"appium:udid": "SERIAL123", "platformName": "Android"}})()

    updated = hydrate_allocated_device_from_driver(allocated, driver, client=client)

    assert updated is not allocated
    assert updated.live_capabilities == {"appium:udid": "SERIAL123", "platformName": "Android"}
    assert allocated.live_capabilities is None


def test_hydrate_uses_inline_test_data() -> None:
    client = FakeClient()
    allocated = hydrate_allocated_device(
        device_handle(test_data={"k": "v"}),
        run_id="run-1",
        client=client,
        fetch_config=False,
    )
    assert allocated.test_data == {"k": "v"}
    assert client.test_data_calls == []


def test_hydrate_allocated_device_populates_inline_tags() -> None:
    client = FakeClient()
    allocated = hydrate_allocated_device(
        device_handle(tags={"screen_type": "4k"}),
        run_id="run-1",
        client=client,
        fetch_config=False,
    )
    assert allocated.tags == {"screen_type": "4k"}


def test_hydrate_defaults_test_data_to_none_when_absent() -> None:
    client = FakeClient()
    allocated = hydrate_allocated_device(
        device_handle(),
        run_id="run-1",
        client=client,
        fetch_config=False,
    )
    assert allocated.test_data is None
    assert client.test_data_calls == []


def test_hydrate_fetches_test_data_when_flag_enabled() -> None:
    client = FakeClient()
    allocated = hydrate_allocated_device(
        device_handle(),
        run_id="run-1",
        client=client,
        fetch_config=False,
        fetch_test_data=True,
    )
    assert allocated.test_data == {"fetched": True}
    assert client.test_data_calls == ["dev-1"]
