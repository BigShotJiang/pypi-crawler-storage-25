"""Supported pytest plugin surface for GridFleet Appium tests."""

from __future__ import annotations

import uuid
from typing import TYPE_CHECKING, cast

import pytest
from appium import webdriver

from .appium import (
    build_appium_options,
    get_device_config_for_driver,
    get_device_test_data_for_driver,
)
from .client import GridFleetClient, _default_grid_url
from .sessions import build_error_session_payload, resolve_device_handle_from_driver

if TYPE_CHECKING:
    from collections.abc import Generator

    from appium.options.common import AppiumOptions
    from appium.webdriver.webdriver import WebDriver
    from pluggy import Result

    from .types import JsonObject


def __getattr__(name: str) -> str:
    if name == "GRID_URL":
        return _default_grid_url()
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


def _normalize_usage_error_message(message: str) -> str:
    if message.startswith("Appium options require"):
        return (
            "appium_driver requires pack_id + platform_id, platform_id with an unambiguous catalog match, "
            "or an explicit 'platformName' capability."
        )
    return message


def _request_params(request: pytest.FixtureRequest) -> dict[str, object]:
    params = getattr(request, "param", {})
    return cast("dict[str, object]", params) if isinstance(params, dict) else {}


def _build_driver_options(
    request: pytest.FixtureRequest,
    catalog_client: GridFleetClient | None = None,
) -> AppiumOptions:
    params = _request_params(request)
    capabilities = {key: value for key, value in params.items() if key not in {"pack_id", "platform_id"}}
    pack_id = params.get("pack_id")
    platform_id = params.get("platform_id")
    try:
        return build_appium_options(
            pack_id=pack_id if isinstance(pack_id, str) else None,
            platform_id=platform_id if isinstance(platform_id, str) else None,
            capabilities=capabilities,
            test_name=request.node.name,
            catalog_client=catalog_client or GridFleetClient(),
        )
    except ValueError as exc:
        raise pytest.UsageError(_normalize_usage_error_message(str(exc))) from exc


@pytest.fixture
def appium_driver(
    request: pytest.FixtureRequest,
    gridfleet_client: GridFleetClient,
) -> Generator[WebDriver, None, None]:
    """
    Create an Appium Remote driver through the Selenium Grid.

    Parametrize with a dict of pack/catalog selection plus capabilities:
        @pytest.mark.parametrize(
            "appium_driver",
            [{"pack_id": "appium-uiautomator2", "platform_id": "android_mobile"}],
            indirect=True,
        )
    """
    options = _build_driver_options(request, gridfleet_client)

    try:
        driver = webdriver.Remote(_default_grid_url(), options=options)
    except Exception as exc:
        # Driver creation failed before a Grid session was established (e.g.
        # SessionNotCreatedException). Register a device-less error session so the
        # failure is visible in the Dashboard Sessions view.
        params = _request_params(request)
        pack_id = params.get("pack_id")
        platform_id = params.get("platform_id")
        payload = build_error_session_payload(
            session_id=f"error-{uuid.uuid4()}",
            test_name=request.node.name,
            options=options,
            exc=exc,
            pack_id=pack_id if isinstance(pack_id, str) and pack_id else None,
            platform_id=platform_id if isinstance(platform_id, str) and platform_id else None,
        )
        gridfleet_client.register_session(**payload, suppress_errors=True)
        raise
    session_id = driver.session_id
    if not isinstance(session_id, str) or not session_id:
        raise RuntimeError("Created Appium driver did not expose a session ID")
    gridfleet_client.register_session_from_driver(driver, test_name=request.node.name, suppress_errors=True)

    yield driver

    status: str | None = None
    if hasattr(request.node, "rep_call"):
        if request.node.rep_call.passed:
            status = "passed"
        elif request.node.rep_call.failed:
            status = "failed"
        else:
            status = "error"

    try:
        driver.quit()
    finally:
        if status is not None:
            gridfleet_client.update_session_status(session_id, status, suppress_errors=True)


@pytest.hookimpl(tryfirst=True, hookwrapper=True)
def pytest_runtest_makereport(item: pytest.Item) -> Generator[None, Result[pytest.TestReport], None]:
    """Store the test outcome on the item for fixture teardown reporting."""
    outcome = yield
    rep = outcome.get_result()
    setattr(item, f"rep_{rep.when}", rep)


@pytest.fixture(scope="session")
def gridfleet_client() -> GridFleetClient:
    return GridFleetClient()


@pytest.fixture
def device_config(appium_driver: WebDriver, gridfleet_client: GridFleetClient) -> JsonObject:
    """
    Fetch device config after the Grid assigns a runtime connection target.

    Usage:
        def test_login(appium_driver, device_config):
            username = device_config["app_username"]
    """
    try:
        return get_device_config_for_driver(appium_driver, gridfleet_client=gridfleet_client)
    except ValueError as exc:
        pytest.skip("Could not determine device connection target from session capabilities")
        raise RuntimeError("unreachable: pytest.skip did not raise") from exc


@pytest.fixture
def device_test_data(appium_driver: WebDriver, gridfleet_client: GridFleetClient) -> JsonObject:
    """Fetch operator-attached test_data after the Grid assigns a runtime connection target."""
    try:
        return get_device_test_data_for_driver(appium_driver, gridfleet_client=gridfleet_client)
    except ValueError as exc:
        pytest.skip("Could not determine device connection target from session capabilities")
        raise RuntimeError("unreachable: pytest.skip did not raise") from exc


@pytest.fixture
def device_handle(appium_driver: WebDriver, gridfleet_client: GridFleetClient) -> JsonObject:
    """Fetch the canonical manager device row after Grid assigns a runtime target."""
    try:
        return resolve_device_handle_from_driver(appium_driver, client=gridfleet_client)
    except RuntimeError as exc:
        pytest.skip(str(exc))
        raise RuntimeError("unreachable: pytest.skip did not raise") from exc


def _gridfleet_worker_id(request: pytest.FixtureRequest) -> str:
    """Return pytest-xdist worker id, or controller for non-worker processes."""
    workerinput = getattr(request.config, "workerinput", None)
    if isinstance(workerinput, dict):
        value = workerinput.get("workerid")
        if isinstance(value, str) and value:
            return value
    return "controller"


gridfleet_worker_id = pytest.fixture(_gridfleet_worker_id)
