"""
Demo Datasets
=============

Various datasets used for documentation and tutorials.
"""

from ._base import load_claudius
from ._base import load_grose2017
from ._base import load_grose2018
from ._base import load_grose2019
from ._base import load_laurent2016
from ._base import load_noddy_single_fold
from ._base import load_intrusion
from ._base import normal_vector_headers
from ._base import strike_dip_headers
from ._base import value_headers
from ._base import load_unconformity
from ._base import load_duplex
from ._base import load_tabular_intrusion
from ._base import load_geological_map_data
from ._base import load_fault_trace
from ._base import load_horizontal
from ._base import load_horizontal_v
