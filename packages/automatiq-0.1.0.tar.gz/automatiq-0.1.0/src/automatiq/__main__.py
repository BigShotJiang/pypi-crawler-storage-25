"""
CLI entry point for AutomatiQ.

Usage:
    python -m automatiq record <url>   # Record a browser session
    python -m automatiq agent          # Run the agent on an existing workspace
    python -m automatiq run <url>      # Record, then launch the agent
"""

import argparse
import multiprocessing
import sys
import threading

from .console import error, info, rule

# ---------------------------------------------------------------------------
# Background preload — runs concurrently with the startup banner so that
# heavy modules are already imported and directories exist by the time the
# animation finishes.
#
# We peek at sys.argv before argparse runs so we can preload only what the
# chosen sub-command actually needs:
#   agent          → litellm, instructor, IPython, yaml
#   record / run   → zendriver, mss, numpy, imageio_ffmpeg  (+ agent deps for run)
# ---------------------------------------------------------------------------

_preload_error = None  # captured if preload raises unexpectedly


def _peek_command() -> str:
    for arg in sys.argv[1:]:
        if not arg.startswith("-"):
            return arg
    return ""


def _peek_model() -> str | None:
    args = sys.argv[1:]
    for i, arg in enumerate(args):
        if arg == "--model" and i + 1 < len(args):
            return args[i + 1]
        if arg.startswith("--model="):
            return arg.split("=", 1)[1]
    return None


def _peek_base_url() -> str | None:
    args = sys.argv[1:]
    for i, arg in enumerate(args):
        if arg == "--base-url" and i + 1 < len(args):
            return args[i + 1]
        if arg.startswith("--base-url="):
            return arg.split("=", 1)[1]
    return None


def _preload():
    global _preload_error
    try:
        from . import config

        config.ensure_output_dirs()

        from .console import init_file_logger

        init_file_logger(str(config.LOGS_DIR))

        cmd = _peek_command()

        _is_verbose = "--verbose" in sys.argv

        if _is_verbose:
            config.VERBOSE = True
            import logging

            handler = logging.StreamHandler()
            handler.setFormatter(
                logging.Formatter(
                    "%(asctime)s  %(levelname)-5s  %(name)s  %(message)s",
                    datefmt="%H:%M:%S",
                )
            )
            logging.getLogger("automatiq").addHandler(handler)
            logging.getLogger("automatiq").setLevel(logging.DEBUG)

        if cmd in ("agent", "run", ""):
            import instructor  # noqa: F401
            import IPython  # noqa: F401
            import litellm  # noqa: F401
            import yaml  # noqa: F401

            litellm.suppress_debug_info = not _is_verbose

        if cmd in ("record", "run"):
            import imageio_ffmpeg  # noqa: F401
            import mss  # noqa: F401
            import numpy  # noqa: F401
            import zendriver  # noqa: F401

            if cmd == "record":
                import litellm  # noqa: F401

                litellm.suppress_debug_info = not _is_verbose

    except Exception as exc:
        _preload_error = exc


def _apply_config_overrides(args):
    from . import config

    if getattr(args, "model", None):
        config.AGENT_MODEL = args.model
    if getattr(args, "recorder_model", None):
        config.RECORDER_AI_MODEL = args.recorder_model
    if getattr(args, "output_dir", None):
        from pathlib import Path

        config.OUTPUT_DIR = Path(args.output_dir)
        config.WORKSPACE_DIR = config.OUTPUT_DIR / "workspace"
        config.BLOCKLIST_DIR = config.OUTPUT_DIR / "blocklist"
        config.BLOCKLIST_DB = config.OUTPUT_DIR / "blocklist.db"
    if getattr(args, "max_steps", None) is not None:
        config.MAX_AGENT_STEPS = args.max_steps
    if getattr(args, "sandbox_timeout", None) is not None:
        config.SANDBOX_TIMEOUT_SECONDS = args.sandbox_timeout
    if getattr(args, "base_url", None):
        config.API_BASE = args.base_url
    if getattr(args, "no_banner", False):
        config.BANNER_ENABLED = False
    if getattr(args, "verbose", False):
        config.VERBOSE = True


def cmd_record(args):
    _apply_config_overrides(args)
    from . import config
    from .key_checker import check_api_keys

    check_api_keys(config.AGENT_MODEL, config.RECORDER_AI_MODEL)
    from .recorder import run_recording

    success = run_recording(url=args.url)
    if not success:
        error("Recording failed or produced no output.")
        sys.exit(1)
    info("Recording complete. Run 'automatiq agent' to start the agent.")


def cmd_agent(args):
    _apply_config_overrides(args)
    from . import config
    from .key_checker import check_api_keys

    check_api_keys(config.AGENT_MODEL)
    from .bin_manager import ensure_binaries

    ensure_binaries()
    from .main import run_agent

    run_agent()


def cmd_run(args):
    _apply_config_overrides(args)
    from . import config
    from .key_checker import check_api_keys

    check_api_keys(config.AGENT_MODEL, config.RECORDER_AI_MODEL)
    from .bin_manager import ensure_binaries
    from .main import run_agent
    from .recorder import run_recording

    ensure_binaries()

    success = run_recording(url=args.url)
    if not success:
        error("Recording failed. Aborting agent launch.")
        sys.exit(1)

    rule("Recording complete. Launching agent...", style="bold green")
    run_agent()


# ---------------------------------------------------------------------------
# Custom Rich help page — replaces argparse's default --help output.
# ---------------------------------------------------------------------------


def _print_rich_help():
    from rich.table import Table
    from rich.text import Text

    from . import config
    from .console import console

    console.print()
    ver = config.VERSION
    console.print(
        f"[bold]AutomatiQ[/bold] [dim]v{ver}[/dim]"
        " — Record browser sessions and reverse-engineer them"
        " into automation scripts."
    )
    console.print()

    rule("USAGE", style="cyan")
    console.print("  automatiq <command> [options]")
    console.print()

    rule("COMMANDS", style="cyan")
    t = Table(show_header=False, box=None, collapse_padding=True)
    t.add_column(style="bold", min_width=16)
    t.add_column()
    t.add_row("record <url>", "Capture a browser session (screen + network + actions)")
    t.add_row("agent", "Analyse a recorded workspace and produce an automation script")
    t.add_row("run <url>", "Record a session then immediately launch the agent")
    console.print(t)
    console.print()

    rule("KEYBOARD SHORTCUTS", style="cyan")
    t2 = Table(show_header=False, box=None, collapse_padding=True)
    t2.add_column(style="bold", min_width=16)
    t2.add_column()
    t2.add_row(Text("RECORDING", style="bold bright_cyan"), "")
    t2.add_row("  Ctrl+C", "Stop recording and save session")
    t2.add_row("", "")
    t2.add_row(Text("COMPILATION", style="bold bright_cyan"), "")
    t2.add_row("  Esc", "Skip AI analysis for remaining segments")
    t2.add_row("  y / n", "Confirm or deny the skip prompt")
    t2.add_row("  Ctrl+C", "Force-quit")
    t2.add_row("", "")
    t2.add_row(Text("AGENT", style="bold bright_cyan"), "")
    t2.add_row("  q", "Quit the agent session")
    t2.add_row("  Esc", "Cancel current LLM call or code execution")
    t2.add_row("  Ctrl+C", "Force-quit")
    console.print(t2)
    console.print()

    rule("CONFIG", style="cyan")
    console.print("  [dim]~/.automatiq/config.toml[/dim]")
    t3 = Table(show_header=False, box=None, collapse_padding=True)
    t3.add_column(style="bold", min_width=16)
    t3.add_column()
    t3.add_row("  models", "LLM model strings and custom API endpoints")
    t3.add_row("  agent", "Max iterations and sandbox timeouts")
    t3.add_row("  recording", "Capture FPS, clip padding, and merge thresholds")
    t3.add_row("  banner", "Startup animation toggle and speed")
    t3.add_row("  output", "Root directory for all generated output")
    console.print(t3)
    console.print()

    rule("OPTIONS", style="cyan")
    t4 = Table(show_header=False, box=None, collapse_padding=True)
    t4.add_column(style="bold", min_width=24)
    t4.add_column()
    t4.add_row("--model MODEL", f"LiteLLM model string for the agent (default: {config.AGENT_MODEL})")
    t4.add_row("--recorder-model MODEL", f"Vision model for video-clip analysis (default: {config.RECORDER_AI_MODEL})")
    t4.add_row("--base-url URL", "Custom OpenAI-compatible API endpoint")
    t4.add_row("--max-steps N", f"Maximum agent loop iterations (default: {config.MAX_AGENT_STEPS})")
    t4.add_row("--sandbox-timeout SEC", f"Seconds per IPython cell (default: {config.SANDBOX_TIMEOUT_SECONDS})")
    t4.add_row("--output-dir PATH", "Root directory for all output (default: ./output)")
    t4.add_row("--no-banner", "Skip the startup animation")
    t4.add_row("--verbose", "Show detailed diagnostic output")
    t4.add_row("-V, --version", "Show version")
    t4.add_row("-h, --help", "Show this help message")
    console.print(t4)
    console.print()


def main():
    # Handle --help / -h before any heavy work.
    _is_help = any(a in sys.argv for a in ("--help", "-h"))
    _is_version = any(a in sys.argv for a in ("--version", "-V"))

    if _is_version:
        from . import config

        print(f"automatiq {config.VERSION}")
        sys.exit(0)

    if _is_help:
        _print_rich_help()
        sys.exit(0)

    # No subcommand and no flag → show help.
    if len(sys.argv) < 2:
        _print_rich_help()
        sys.exit(0)

    # Start preloading in the background before the banner begins.
    preload_thread = threading.Thread(target=_preload, daemon=True)
    preload_thread.start()

    from . import config
    from .automatiq_banner import show_startup

    cmd = _peek_command()
    banner_model = _peek_model() or config.AGENT_MODEL
    banner_base_url = _peek_base_url()
    if banner_base_url:
        config.API_BASE = banner_base_url

    if config.BANNER_ENABLED and cmd in ("record", "agent", "run"):
        show_startup(
            version=config.VERSION,
            model=banner_model,
            recorder_model=config.RECORDER_AI_MODEL,
            speed=config.BANNER_SPEED,
        )

    preload_thread.join()

    if _preload_error is not None:
        error(f"Startup init failed: {_preload_error}")
        sys.exit(1)

    parser = argparse.ArgumentParser(
        prog="automatiq",
        add_help=False,
    )
    subparsers = parser.add_subparsers(dest="command")

    def _add_common_flags(p, include_recorder_model=False):
        p.add_argument("--model", metavar="MODEL")
        p.add_argument("--base-url", metavar="URL")
        if include_recorder_model:
            p.add_argument("--recorder-model", metavar="MODEL")
        p.add_argument("--max-steps", type=int, metavar="N")
        p.add_argument("--sandbox-timeout", type=int, metavar="SECONDS")
        p.add_argument("--output-dir", metavar="PATH")
        p.add_argument("--no-banner", action="store_true", default=False)
        p.add_argument("--verbose", action="store_true", default=False)
        p.add_argument("-h", "--help", action="store_true", default=False, dest="help_flag")
        p.add_argument("-V", "--version", action="store_true", default=False)

    p_record = subparsers.add_parser("record", add_help=False)
    p_record.add_argument("url", nargs="?", default="about:blank")
    _add_common_flags(p_record, include_recorder_model=True)
    p_record.set_defaults(func=cmd_record)

    p_agent = subparsers.add_parser("agent", add_help=False)
    _add_common_flags(p_agent)
    p_agent.set_defaults(func=cmd_agent)

    p_run = subparsers.add_parser("run", add_help=False)
    p_run.add_argument("url", nargs="?", default="about:blank")
    _add_common_flags(p_run, include_recorder_model=True)
    p_run.set_defaults(func=cmd_run)

    args = parser.parse_args()

    if getattr(args, "help_flag", False) or getattr(args, "version", False):
        if getattr(args, "version", False):
            print(f"automatiq {config.VERSION}")
        else:
            _print_rich_help()
        sys.exit(0)

    if not args.command:
        _print_rich_help()
        sys.exit(0)

    args.func(args)


if __name__ == "__main__":
    multiprocessing.freeze_support()
    main()
