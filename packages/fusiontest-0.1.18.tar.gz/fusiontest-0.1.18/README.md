# 🧪 FusionTest

> AI-powered UI testing for mobile and desktop — built by [FusionLeap.io](https://fusionleap.io)

FusionTest uses large language models to execute UI tests the way a human would — reading screens, making decisions, and adapting to UI changes automatically. No brittle scripts. No maintenance overhead. Just natural language test goals that run anywhere.

---

## ✨ Features

| Feature | Mobile (iOS/Android) | Desktop (Win/Mac/Linux) |
|---|---|---|
| Natural language test goals | ✅ | ✅ |
| Zero-maintenance execution | ✅ | ✅ |
| Multi-locale / 50+ languages | ✅ | ✅ |
| Hallucination guardrails | ✅ | ✅ |
| Loop detection & backtrack | ✅ | ✅ |
| CI/CD integration | ✅ | ✅ |
| Vision model fallback | — | ✅ |
| Cross-app flow testing | — | ✅ |
| Electron / Playwright support | — | ✅ |

---

## 🏗 Architecture

```
fusiontest/
├── core/           # LLM action model, embeddings, screen parser
├── mobile/         # iOS (XCTest) + Android (UIAutomator2) adapters
├── desktop/        # Windows (WinAppDriver), macOS (Accessibility API), Playwright
├── guardrails/     # Hallucination handler, loop detector, backtrack engine
└── reporting/      # Dashboard data, Slack/email alerts, CI artifacts
```

---

## 🚀 Quickstart

### Prerequisites
- Python 3.10+
- Node.js 18+ (for Playwright/Electron targets)
- Appium 2.x (for mobile)

### Install

```bash
git clone https://github.com/mohigo/fusion-test.git
cd fusion-test
pip install -e ".[dev]"
```

### Set your API key

```bash
export FUSIONTEST_API_KEY=your_key_here
# or copy .env.example → .env and fill in values
```

### Run your first test

```bash
fusiontest run --goal "Log in, navigate to settings, update profile name" \
               --platform android \
               --app path/to/app.apk \
               --locale en-US
```

> **Full guide:** [docs/getting-started.md](docs/getting-started.md) — covers all platforms (web, Android, iOS, Electron, Windows, macOS), Python API usage, configuration, dashboard, CI setup, and tips for writing good goals.

---

## 📝 Writing Test Goals

FusionTest accepts natural language goals. No code required.

```yaml
# tests/goals/onboarding.yaml
name: User onboarding flow
platform: android
locale: en-US
goals:
  - "Open the app and tap Get Started"
  - "Enter email address and password on the signup screen"
  - "Verify the home dashboard loads with a welcome message"
```

Run it:

```bash
fusiontest run --file tests/goals/onboarding.yaml
```

---

## 🔌 CI/CD Integration

### GitHub Actions

```yaml
- name: Run FusionTest
  uses: fusionleap/fusiontest-action@v1
  with:
    goal-file: tests/goals/smoke.yaml
    platform: android
    api-key: ${{ secrets.FUSIONTEST_API_KEY }}
```

### Bitrise / Fastlane

See [docs/ci-integrations.md](docs/ci-integrations.md) for step-by-step guides.

---

## 📊 Reporting

Every test run produces:
- Pass/fail summary with stability score
- Screen-by-screen action log
- Video recording of the test session
- Bug report with screenshot + repro steps (on failure)

Results are posted to your FusionTest dashboard and optionally to Slack.

---

## 🛠 Configuration

```yaml
# fusiontest.config.yaml
model:
  backbone: mpnet-base          # or: gpt-4o, claude-sonnet (for MVP/fallback)
  precision_threshold: 0.97
  max_retries: 3

guardrails:
  loop_detection: true
  loop_window: 5                # check last N screen states
  backtrack_on_invalid: true
  max_backtracks: 2

devices:
  android:
    farm: browserstack           # or: aws-device-farm, local
  desktop:
    vision_fallback: true        # enable for non-accessible UIs
    playwright_for_electron: true

reporting:
  slack_webhook: ${SLACK_WEBHOOK}
  save_recordings: true
  dashboard_url: https://app.fusionleap.io
```

---

## 🗺 Roadmap

- [x] Core LLM action model (MPNet / GPT-4o / Claude backends)
- [x] Android adapter (UIAutomator2 + Appium)
- [x] iOS adapter (XCUITest + Appium)
- [x] Desktop adapter — Playwright / Electron (with vision fallback)
- [x] Desktop adapter — Windows (WinAppDriver / UIA)
- [x] Desktop adapter — macOS (NSAccessibility + PyObjC)
- [x] Guardrails engine (invalid actions, loops, backtrack)
- [x] Goal completion verifier (LLM + heuristic fallback)
- [x] Video recording — Playwright WebM→MP4, Appium, Windows screenshot stitch
- [x] Reporting — JSON, Slack webhooks, GitHub Actions annotations
- [x] CLI — `fusiontest run / init / demo / report`
- [x] MPNet fine-tuning pipeline (`fusiontest/training/`)
- [x] FusionLeap cloud dashboard (React + Recharts + SaaS pages)
- [x] Dashboard backend API (FastAPI + PostgreSQL/Supabase)
- [x] SaaS backend — auth, org management, API keys, webhooks, billing
- [x] Marketing website (Next.js, `website/`)
- [x] Integration tests — runner, guardrails, goal verifier
- [x] CI/CD integration guides (`docs/ci-integrations.md`)
- [ ] Autonomous Test Discovery — auto-crawl website → generate goals → execute
- [ ] RAG test library (few-shot goal → flow)
- [ ] Multi-locale parallel execution
- [ ] Cross-app flow testing (desktop)

---

## 🤝 Contributing

See [CONTRIBUTING.md](CONTRIBUTING.md). We welcome issues, PRs, and test goal examples from the community.

---

## 📄 License

MIT © [FusionLeap.io](https://fusionleap.io)
