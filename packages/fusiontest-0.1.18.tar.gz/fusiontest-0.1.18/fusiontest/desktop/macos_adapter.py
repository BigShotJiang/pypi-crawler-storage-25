"""
fusiontest/desktop/macos_adapter.py

macOS native desktop adapter for FusionTest using NSAccessibility + PyObjC.

Drives native AppKit applications (e.g. Xcode, Finder, Mail, custom
macOS apps) via the macOS Accessibility API.  Electron / web apps are
better served by the Playwright adapter; use this one for native .app
bundles that have no WebDriver support.

Requirements:
  - macOS 12+
  - pip install pyobjc-framework-ApplicationServices pyobjc-framework-Cocoa
  - Screen Recording permission granted to the terminal / test runner
    in System Settings → Privacy & Security → Screen Recording
  - Accessibility permission granted in
    System Settings → Privacy & Security → Accessibility

Quick start:
    adapter = MacOSAdapter(app_bundle_id="com.apple.TextEdit")
    adapter.start()
    elements, screen_text = adapter.get_screen()
    adapter.execute(action, elements)
    adapter.stop()
"""

from __future__ import annotations

import logging
import subprocess
import time
from typing import Any

from fusiontest.core.action_model import Action
from fusiontest.core.screen_parser import ScreenParser, UIElement

logger = logging.getLogger("fusiontest.desktop.macos")

# NSAccessibility role → FusionTest element_type
_AX_ROLE_MAP: dict[str, str] = {
    "AXButton":          "button",
    "AXTextField":       "text_field",
    "AXTextArea":        "text_area",
    "AXSecureTextField": "text_field",
    "AXCheckBox":        "checkbox",
    "AXRadioButton":     "radio_button",
    "AXComboBox":        "picker",
    "AXPopUpButton":     "picker",
    "AXMenuItem":        "menu_item",
    "AXMenuBarItem":     "menu_item",
    "AXTab":             "tab",
    "AXTabGroup":        "tab",
    "AXSlider":          "slider",
    "AXLink":            "link",
    "AXRow":             "list_item",
    "AXCell":            "list_item",
    "AXStaticText":      "static_text",
    "AXHeading":         "heading",
    "AXImage":           "image",
    "AXSearchField":     "search_field",
    "AXList":            "list_item",
    "AXOutline":         "list_item",
    "AXToggleButton":    "button",
    "AXDisclosureTriangle": "button",
}


class MacOSAdapter:
    """
    Controls a native macOS application via NSAccessibility.

    The adapter walks the AX element tree of the target application,
    converts it into FusionTest UIElements, and dispatches actions
    via AXUIElementPerformAction / postEvent.

    NOTE: This adapter requires PyObjC which is macOS-only.  On other
    platforms it will raise ImportError at start() time.
    """

    def __init__(
        self,
        app_bundle_id: str | None = None,
        app_path: str | None = None,
        app_pid: int | None = None,
        launch_args: list[str] | None = None,
        max_elements: int = 150,
    ):
        """
        Exactly one of app_bundle_id / app_path / app_pid must be provided.

        Args:
            app_bundle_id: e.g. "com.apple.TextEdit"
            app_path: full path to the .app bundle
            app_pid: PID of an already-running process
            launch_args: extra args for subprocess launch (app_path mode only)
            max_elements: cap on AX elements parsed per screen
        """
        if not any([app_bundle_id, app_path, app_pid]):
            raise ValueError("Provide app_bundle_id, app_path, or app_pid")

        self.app_bundle_id = app_bundle_id
        self.app_path = app_path
        self._given_pid = app_pid
        self.launch_args = launch_args or []
        self._pid: int | None = None
        self._ax_app = None
        self._parser = ScreenParser(max_elements=max_elements)

    # ── Lifecycle ──────────────────────────────────────────────────────────────

    def start(self) -> None:
        """Launch (or attach to) the application and initialise the AX client."""
        self._check_pyobjc()
        import ApplicationServices as AS  # type: ignore[import-not-found]

        if self._given_pid:
            self._pid = self._given_pid
        elif self.app_bundle_id:
            self._pid = self._launch_by_bundle_id(self.app_bundle_id)
        elif self.app_path:
            self._pid = self._launch_by_path(self.app_path, self.launch_args)

        # Give the app a moment to render its first window
        time.sleep(1.5)

        self._ax_app = AS.AXUIElementCreateApplication(self._pid)
        logger.info(f"MacOSAdapter connected to PID {self._pid}")

    def stop(self) -> None:
        self._ax_app = None
        logger.info("MacOSAdapter stopped (app left running)")

    # ── Screen reading ─────────────────────────────────────────────────────────

    def get_screen(self) -> tuple[list[UIElement], str]:
        """Walk the AX tree and return parsed elements + screen text."""
        tree = self._ax_tree_to_dict(self._ax_app)
        elements, screen_text = self._parser.parse(tree, platform="macos")
        return elements, screen_text

    def get_screenshot(self) -> bytes:
        """Capture a full-screen PNG using screencapture."""
        import pathlib
        import tempfile  # noqa: PLC0415, E401
        with tempfile.NamedTemporaryFile(suffix=".png", delete=False) as f:
            tmp = f.name
        subprocess.run(
            ["screencapture", "-x", "-t", "png", tmp],
            check=True,
            capture_output=True,
        )
        data = pathlib.Path(tmp).read_bytes()
        pathlib.Path(tmp).unlink(missing_ok=True)
        return data

    def _ax_tree_to_dict(self, element: Any, depth: int = 0, max_depth: int = 12) -> dict:
        """Recursively walk an AXUIElement tree into a plain dict."""
        try:
            import ApplicationServices as AS  # type: ignore[import-not-found]

            if element is None or depth > max_depth:
                return {}

            node: dict[str, Any] = {}

            role = _ax_attr(element, AS.kAXRoleAttribute) or ""
            label = (
                _ax_attr(element, AS.kAXTitleAttribute)
                or _ax_attr(element, AS.kAXDescriptionAttribute)
                or _ax_attr(element, AS.kAXValueAttribute)
                or ""
            )
            value = str(_ax_attr(element, AS.kAXValueAttribute) or "")
            enabled = _ax_attr(element, AS.kAXEnabledAttribute)
            frame = _ax_attr(element, AS.kAXFrameAttribute)

            node["ax_role"] = role
            node["label"] = str(label)
            node["value"] = value
            node["enabled"] = bool(enabled) if enabled is not None else True

            if frame:
                try:
                    import Foundation  # type: ignore[import-not-found]
                    r = Foundation.NSRectFromString(str(frame))
                    node["rect"] = {
                        "x": int(r.origin.x),
                        "y": int(r.origin.y),
                        "width": int(r.size.width),
                        "height": int(r.size.height),
                    }
                except Exception:
                    pass

            children_ref = _ax_attr(element, AS.kAXChildrenAttribute)
            if children_ref:
                children = []
                for child in children_ref:
                    child_dict = self._ax_tree_to_dict(child, depth + 1, max_depth)
                    if child_dict:
                        children.append(child_dict)
                if children:
                    node["children"] = children

            node["_ax_element"] = element  # keep reference for action dispatch
            return node

        except Exception as e:
            logger.debug(f"AX walk error at depth {depth}: {e}")
            return {}

    # ── Action execution ───────────────────────────────────────────────────────

    def execute(self, action: Action, elements: list[UIElement]) -> bool:
        """Execute a FusionTest action on the macOS app. Returns True on success."""
        try:
            if action.action_type in ("tap", "toggle"):
                self._click(action, elements)
            elif action.action_type == "type":
                self._type(action, elements)
            elif action.action_type == "scroll":
                self._scroll(action, elements)
            elif action.action_type == "back":
                self._press_cmd_bracket()
            elif action.action_type == "wait":
                time.sleep(float(action.value) if action.value else 1.5)
            elif action.action_type == "select":
                self._click(action, elements)   # open picker, then type value

            time.sleep(0.6)
            return True

        except Exception as e:
            logger.warning(f"Action failed: {action} — {e}")
            return False

    def _click(self, action: Action, elements: list[UIElement]) -> None:
        ax_el = self._resolve_ax_element(action, elements)
        if ax_el is None:
            raise ValueError(f"AX element not found for: {action}")
        _ax_perform(ax_el, "AXPress")

    def _type(self, action: Action, elements: list[UIElement]) -> None:
        import AppKit  # type: ignore[import-not-found]

        ax_el = self._resolve_ax_element(action, elements)
        if ax_el is None:
            raise ValueError(f"AX element not found for type: {action}")
        _ax_perform(ax_el, "AXPress")       # focus the field
        time.sleep(0.15)
        # Select all existing text and replace
        _post_key_event(AppKit.NSCommandKeyMask, ord("a"))
        time.sleep(0.05)
        self._type_string(action.value)

    def _scroll(self, action: Action, elements: list[UIElement]) -> None:
        import AppKit  # type: ignore[import-not-found]

        direction = (action.value or "down").lower()
        # Use CGEvent scroll wheel
        try:
            import Quartz  # type: ignore[import-not-found]
            delta = -5 if direction == "down" else 5
            event = Quartz.CGEventCreateScrollWheelEvent(
                None, Quartz.kCGScrollEventUnitLine, 1, delta
            )
            Quartz.CGEventPost(Quartz.kCGHIDEventTap, event)
        except ImportError:
            key = AppKit.NSPageDownFunctionKey if direction == "down" else AppKit.NSPageUpFunctionKey
            _post_key_event(0, key)

    def _press_cmd_bracket(self) -> None:
        import AppKit  # type: ignore[import-not-found]
        _post_key_event(AppKit.NSCommandKeyMask, ord("["))

    def _type_string(self, text: str) -> None:
        for ch in text:
            _post_key_event(0, ord(ch))
            time.sleep(0.02)

    def _resolve_ax_element(
        self, action: Action, elements: list[UIElement]
    ) -> Any | None:
        """Find the raw AXUIElement for a given Action."""
        matching = [e for e in elements if e.index == action.element_index]
        if matching:
            raw = matching[0].raw
            ax_el = raw.get("_ax_element")
            if ax_el is not None:
                return ax_el

        # Fallback: search by label
        label = (action.element_label or "").strip('"').strip()
        if label:
            for el in elements:
                if el.label == label and el.raw.get("_ax_element"):
                    return el.raw["_ax_element"]

        return None

    # ── Launch helpers ─────────────────────────────────────────────────────────

    @staticmethod
    def _launch_by_bundle_id(bundle_id: str) -> int:
        import AppKit  # type: ignore[import-not-found]
        ws = AppKit.NSWorkspace.sharedWorkspace()
        app_url = ws.URLForApplicationWithBundleIdentifier_(bundle_id)
        if app_url is None:
            raise RuntimeError(f"App not found for bundle ID: {bundle_id}")
        cfg = AppKit.NSWorkspaceOpenConfiguration.configuration()
        cfg.setActivates_(True)
        result = {}

        def callback(app, err):  # type: ignore[misc]
            result["app"] = app
            result["err"] = err

        ws.openApplicationAtURL_configuration_completionHandler_(
            app_url, cfg, callback
        )
        time.sleep(2.0)   # wait for async launch

        # Find PID via NSRunningApplication
        running = AppKit.NSWorkspace.sharedWorkspace().runningApplications()
        for app in running:
            if app.bundleIdentifier() == bundle_id:
                return int(app.processIdentifier())

        raise RuntimeError(f"Could not find PID after launching {bundle_id}")

    @staticmethod
    def _launch_by_path(app_path: str, args: list[str]) -> int:
        cmd = ["open", "-n", "-a", app_path]
        if args:
            cmd += ["--args"] + args
        result = subprocess.run(cmd, capture_output=True, text=True)
        if result.returncode != 0:
            raise RuntimeError(f"Failed to launch {app_path}: {result.stderr}")
        time.sleep(2.0)
        # Retrieve PID from the app name
        app_name = app_path.rstrip("/").split("/")[-1].replace(".app", "")
        ps = subprocess.run(["pgrep", "-n", app_name], capture_output=True, text=True)
        pid_str = ps.stdout.strip()
        if not pid_str:
            raise RuntimeError(f"Could not find PID for {app_name} after launch")
        return int(pid_str)

    # ── Internal ───────────────────────────────────────────────────────────────

    @staticmethod
    def _check_pyobjc() -> None:
        try:
            import ApplicationServices  # type: ignore[import-not-found] # noqa: F401
        except ImportError as err:
            raise RuntimeError(
                "macOS adapter requires PyObjC:\n"
                "    pip install pyobjc-framework-ApplicationServices "
                "pyobjc-framework-Cocoa pyobjc-framework-Quartz"
            ) from err


# ── NSAccessibility screen parser integration ──────────────────────────────────

def _normalise_ax_node(node: dict) -> dict:
    """
    Translate an AX dict (produced by _ax_tree_to_dict) into the format
    expected by ScreenParser._extract().  We add a 'platform' hint so
    ScreenParser routes to the right extraction method.
    """
    role = node.get("ax_role", "")
    element_type = _AX_ROLE_MAP.get(role, "")
    if not element_type:
        return {}
    return {
        "type": element_type,
        "label": node.get("label", ""),
        "value": node.get("value", ""),
        "enabled": node.get("enabled", True),
        "visible": True,
        "rect": node.get("rect", {}),
        "children": [_normalise_ax_node(c) for c in node.get("children", []) if c],
        "_ax_element": node.get("_ax_element"),
    }


# Monkey-patch ScreenParser to handle the macOS AX tree format
def _extract_macos(self, node: dict):  # type: ignore[override]
    role_type = node.get("type", "") or _AX_ROLE_MAP.get(node.get("ax_role", ""), "")
    if not role_type:
        return None
    from fusiontest.core.screen_parser import UIElement
    return UIElement(
        index=self._counter,
        element_type=role_type,
        label=(node.get("label") or "").strip(),
        value=str(node.get("value", "")),
        enabled=bool(node.get("enabled", True)),
        visible=True,
        rect=node.get("rect", {}),
        raw=node,
    )

ScreenParser._extract_macos = _extract_macos  # type: ignore[attr-defined]

# Add "macos" to ScreenParser._extract dispatch
_original_extract = ScreenParser._extract  # type: ignore[attr-defined]

def _patched_extract(self, node: dict, platform: str):  # type: ignore[misc]
    if platform == "macos":
        return self._extract_macos(node)
    return _original_extract(self, node, platform)

ScreenParser._extract = _patched_extract  # type: ignore[method-assign]


# ── PyObjC helpers ─────────────────────────────────────────────────────────────

def _ax_attr(element: Any, attr: str) -> Any:
    """Get an AXUIElement attribute, returning None on any error."""
    try:
        import ApplicationServices as AS  # type: ignore[import-not-found]
        err, value = AS.AXUIElementCopyAttributeValue(element, attr, None)
        if err == AS.kAXErrorSuccess:
            return value
    except Exception:
        pass
    return None


def _ax_perform(element: Any, action: str) -> None:
    try:
        import ApplicationServices as AS  # type: ignore[import-not-found]
        AS.AXUIElementPerformAction(element, action)
    except Exception as e:
        raise RuntimeError(f"AXUIElementPerformAction({action}) failed: {e}") from e


def _post_key_event(modifier_flags: int, key_code: int) -> None:
    """Post a synthetic keyboard event using CGEvent."""
    try:
        import Quartz  # type: ignore[import-not-found]
        event_down = Quartz.CGEventCreateKeyboardEvent(None, key_code, True)
        event_up   = Quartz.CGEventCreateKeyboardEvent(None, key_code, False)
        if modifier_flags:
            Quartz.CGEventSetFlags(event_down, modifier_flags)
            Quartz.CGEventSetFlags(event_up,   modifier_flags)
        Quartz.CGEventPost(Quartz.kCGHIDEventTap, event_down)
        Quartz.CGEventPost(Quartz.kCGHIDEventTap, event_up)
    except Exception as e:
        raise RuntimeError(f"CGEvent keyboard post failed: {e}") from e
