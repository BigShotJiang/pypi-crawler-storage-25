"""
fusiontest/desktop/windows_adapter.py

Windows desktop adapter for FusionTest using WinAppDriver + Appium.
Drives native Win32, WinForms, WPF, UWP, and Win32 apps via the
Windows Accessibility (UIA) API.

Requirements:
  - WinAppDriver v1.2+ running on the Windows test machine
    (https://github.com/microsoft/WinAppDriver/releases)
  - Appium-Python-Client installed  (`pip install fusiontest[mobile]`)
  - Windows 10/11 with Developer Mode enabled

Quick start:
    adapter = WindowsAdapter(
        app_path=r"C:\\Windows\\System32\\notepad.exe",
        device_name="WindowsPC",       # or the actual machine hostname
    )
    adapter.start()
    elements, screen_text = adapter.get_screen()
    adapter.execute(action, elements)
    adapter.stop()
"""

from __future__ import annotations

import logging
import time
from typing import Any

from fusiontest.core.action_model import Action
from fusiontest.core.screen_parser import ScreenParser, UIElement

logger = logging.getLogger("fusiontest.desktop.windows")

# Default WinAppDriver endpoint — runs locally on the Windows test machine
_DEFAULT_WINAPPDRIVER_URL = "http://127.0.0.1:4723"


class WindowsAdapter:
    """
    Controls a native Windows application via WinAppDriver.

    Supports Win32, WPF, WinForms, UWP, and even the Windows Desktop
    itself (set app_path="Root" to automate the whole desktop).

    WinAppDriver speaks the Appium/WebDriver protocol, so we reuse the
    Appium Python client — the same dependency as the mobile adapters.
    """

    DEFAULT_CAPS: dict[str, Any] = {
        "platformName": "Windows",
        "deviceName": "WindowsPC",
        "automationName": "Windows",
        "newCommandTimeout": 300,
        "ms:waitForAppLaunch": 5,
    }

    def __init__(
        self,
        winappdriver_url: str = _DEFAULT_WINAPPDRIVER_URL,
        app_path: str | None = None,
        app_id: str | None = None,
        device_name: str = "WindowsPC",
        desired_caps: dict | None = None,
        attach_to_top_level_window_name: str | None = None,
    ):
        """
        Args:
            winappdriver_url: URL where WinAppDriver is listening.
            app_path: Full path to the .exe, or "Root" for the desktop.
            app_id: Application User Model ID (AUMID) for Store/UWP apps,
                    e.g. "Microsoft.WindowsCalculator_8wekyb3d8bbwe!App".
            device_name: Target machine hostname. Use "WindowsPC" for local.
            desired_caps: Extra Appium capabilities to merge.
            attach_to_top_level_window_name: If the app is already running,
                pass its window title to attach instead of launching fresh.
        """
        self.winappdriver_url = winappdriver_url
        self.device_name = device_name

        caps = {**self.DEFAULT_CAPS, "deviceName": device_name}

        if app_path:
            caps["app"] = app_path
        elif app_id:
            caps["app"] = app_id
        elif attach_to_top_level_window_name:
            caps["app"] = "Root"
            caps["appTopLevelWindow"] = ""  # filled in after attach

        if desired_caps:
            caps.update(desired_caps)

        self.caps = caps
        self._attach_window_name = attach_to_top_level_window_name
        self._driver = None
        self._parser = ScreenParser()

    # ── Lifecycle ──────────────────────────────────────────────────────────────

    def start(self) -> None:
        """Launch (or attach to) the Windows app and connect to WinAppDriver."""
        try:
            from appium import webdriver
            from appium.options import AppiumOptions
        except ImportError as err:
            raise RuntimeError(
                "Windows adapter requires the Appium Python client:\n"
                "    pip install fusiontest[mobile]\n"
                "Also make sure WinAppDriver is running on the target machine."
            ) from err

        if self._attach_window_name:
            self._attach_to_running_app()
            return

        options = AppiumOptions().load_capabilities(self.caps)
        self._driver = webdriver.Remote(self.winappdriver_url, options=options)
        logger.info(f"WindowsAdapter connected to WinAppDriver at {self.winappdriver_url}")

    def _attach_to_running_app(self) -> None:
        """
        Attach to an already-running top-level window by its title.
        Uses a Root session to enumerate windows, then re-connects with
        appTopLevelWindow set to the found handle.
        """
        from appium import webdriver
        from appium.options import AppiumOptions
        from appium.webdriver.common.appiumby import AppiumBy

        # Step 1: open a Root session
        root_caps = {
            "platformName": "Windows",
            "deviceName": self.device_name,
            "app": "Root",
        }
        root_options = AppiumOptions().load_capabilities(root_caps)
        root_driver = webdriver.Remote(self.winappdriver_url, options=root_options)

        try:
            el = root_driver.find_element(
                AppiumBy.NAME, self._attach_window_name
            )
            window_handle = el.get_attribute("NativeWindowHandle")
            window_handle_hex = hex(int(window_handle))
        finally:
            root_driver.quit()

        # Step 2: reconnect directly to that window
        attach_caps = {
            **self.DEFAULT_CAPS,
            "deviceName": self.device_name,
            "appTopLevelWindow": window_handle_hex,
        }
        options = AppiumOptions().load_capabilities(attach_caps)
        self._driver = webdriver.Remote(self.winappdriver_url, options=options)
        logger.info(
            f"WindowsAdapter attached to window '{self._attach_window_name}' "
            f"(handle={window_handle_hex})"
        )

    def stop(self) -> None:
        if self._driver:
            self._driver.quit()
            self._driver = None
        logger.info("WindowsAdapter stopped")

    # ── Screen reading ─────────────────────────────────────────────────────────

    def get_screen(self) -> tuple[list[UIElement], str]:
        """
        Walk the UIA accessibility tree of the focused window and return
        a parsed element list + compact screen text for the LLM.
        """
        page_source = self._driver.page_source
        import xml.etree.ElementTree as ET

        root = ET.fromstring(page_source)
        tree_dict = self._xml_to_dict(root)
        elements, screen_text = self._parser.parse(tree_dict, platform="windows")
        return elements, screen_text

    def get_screenshot(self) -> bytes:
        return self._driver.get_screenshot_as_png()

    def _xml_to_dict(self, node) -> dict:
        """
        Convert a WinAppDriver XML page-source node to the dict format
        expected by ScreenParser.  WinAppDriver uses UIA attribute names:
        ControlType, Name, AutomationId, Value, IsEnabled, IsOffscreen, etc.
        """
        attrib = dict(node.attrib)

        # Normalise booleans (WinAppDriver returns strings)
        for bool_key in ("IsEnabled", "IsOffscreen", "IsKeyboardFocusable"):
            if bool_key in attrib:
                attrib[bool_key] = attrib[bool_key].lower() == "true"

        children = [self._xml_to_dict(c) for c in node]
        if children:
            attrib["children"] = children
        return attrib

    # ── Action execution ───────────────────────────────────────────────────────

    def execute(self, action: Action, elements: list[UIElement]) -> bool:
        """Execute a FusionTest action on the Windows app. Returns True on success."""
        try:
            if action.action_type == "tap":
                self._click(action, elements)
            elif action.action_type == "type":
                self._type(action, elements)
            elif action.action_type == "scroll":
                self._scroll(action, elements)
            elif action.action_type == "back":
                self._send_keys_global("{BACKSPACE}")
            elif action.action_type == "wait":
                secs = float(action.value) if action.value else 1.5
                time.sleep(secs)
            elif action.action_type == "toggle":
                self._click(action, elements)
            elif action.action_type == "select":
                self._select(action, elements)
            elif action.action_type == "focus":
                self._focus(action, elements)

            time.sleep(0.6)
            return True

        except Exception as e:
            logger.warning(f"Action failed: {action} — {e}")
            return False

    def _click(self, action: Action, elements: list[UIElement]) -> None:
        element = self._find_element(action, elements)
        if element:
            element.click()
        else:
            raise ValueError(f"Element not found for click: {action}")

    def _type(self, action: Action, elements: list[UIElement]) -> None:
        element = self._find_element(action, elements)
        if element:
            element.click()
            element.clear()
            element.send_keys(action.value)
        else:
            raise ValueError(f"Element not found for type: {action}")

    def _scroll(self, action: Action, elements: list[UIElement]) -> None:
        """
        WinAppDriver doesn't support touch scroll; use keyboard Page Down/Up
        or mouse wheel via the W3C Actions API.
        """
        direction = (action.value or "down").lower()

        # Try to find a scrollable container first
        el = self._find_element(action, elements) if action.element_index is not None else None
        if el:
            el.click()

        key = "{PGDN}" if direction == "down" else "{PGUP}"
        self._send_keys_global(key)

    def _select(self, action: Action, elements: list[UIElement]) -> None:
        """Select an item from a ComboBox/ListBox by value."""
        from appium.webdriver.common.appiumby import AppiumBy

        element = self._find_element(action, elements)
        if element:
            # Expand the combo/list first, then click the target item
            element.click()
            time.sleep(0.3)
            try:
                item = self._driver.find_element(AppiumBy.NAME, action.value)
                item.click()
            except Exception:
                element.send_keys(action.value)
        else:
            raise ValueError(f"Element not found for select: {action}")

    def _focus(self, action: Action, elements: list[UIElement]) -> None:
        element = self._find_element(action, elements)
        if element:
            element.click()

    def _send_keys_global(self, keys: str) -> None:
        """Send keyboard input to the currently focused element."""
        from appium.webdriver.common.appiumby import AppiumBy
        try:
            focused = self._driver.find_element(AppiumBy.XPATH, '//*[@IsKeyboardFocusable="true"]')
            focused.send_keys(keys)
        except Exception:
            self._driver.find_element(AppiumBy.XPATH, "//*[1]").send_keys(keys)

    # ── Element resolution ────────────────────────────────────────────────────

    def _find_element(self, action: Action, elements: list[UIElement]):
        """
        Resolve an Action to a live WinAppDriver element.

        Resolution order:
          1. Match by index → use AutomationId or Name from raw data
          2. Fallback to action label via Name or AutomationId attribute
          3. XPath by ControlType + Name as last resort
        """
        from appium.webdriver.common.appiumby import AppiumBy

        matching = [e for e in elements if e.index == action.element_index]
        if matching:
            raw = matching[0].raw
            name = raw.get("Name", "").strip()
            automation_id = raw.get("AutomationId", "").strip()
            control_type = raw.get("ControlType", "")

            for strategy, value in _build_win_locator_chain(name, automation_id, control_type):
                try:
                    return self._driver.find_element(strategy, value)
                except Exception:
                    continue

        # Fallback: match by the action label
        label = (action.element_label or "").strip('"').strip()
        if label:
            for strategy, value in [
                (AppiumBy.NAME, label),
                (AppiumBy.ACCESSIBILITY_ID, label),
                (AppiumBy.XPATH, f'//*[@Name="{label}"]'),
            ]:
                try:
                    return self._driver.find_element(strategy, value)
                except Exception:
                    continue

        return None

    # ── Convenience helpers ───────────────────────────────────────────────────

    def get_window_title(self) -> str:
        """Return the title of the currently focused application window."""
        try:
            from appium.webdriver.common.appiumby import AppiumBy
            el = self._driver.find_element(AppiumBy.XPATH, "//Window[1]")
            return el.get_attribute("Name") or ""
        except Exception:
            return ""

    def maximize_window(self) -> None:
        self._driver.maximize_window()

    def take_screenshot_to_file(self, path: str) -> None:
        self._driver.save_screenshot(path)


# ── Helpers ────────────────────────────────────────────────────────────────────

def _build_win_locator_chain(
    name: str,
    automation_id: str,
    control_type: str,
) -> list[tuple[str, str]]:
    """
    Returns a prioritised list of (strategy, value) locator pairs for
    WinAppDriver, from most to least reliable.
    """
    from appium.webdriver.common.appiumby import AppiumBy

    chain = []

    # AutomationId is the most stable (set by the developer, survives reflows)
    if automation_id:
        chain.append((AppiumBy.ACCESSIBILITY_ID, automation_id))

    # Name (visible text / accessibility label)
    if name:
        chain.append((AppiumBy.NAME, name))

    # XPath combining ControlType + Name
    if control_type and name:
        uia_type = _control_type_to_uia_class(control_type)
        chain.append((AppiumBy.XPATH, f'//{uia_type}[@Name="{name}"]'))

    return chain


def _control_type_to_uia_class(control_type: str) -> str:
    """
    Map WinAppDriver ControlType strings to UIA class names used in XPath.
    WinAppDriver XPath uses the short form without the 'ControlType.' prefix.
    """
    mapping = {
        "ControlType.Button": "Button",
        "ControlType.Edit": "Edit",
        "ControlType.CheckBox": "CheckBox",
        "ControlType.RadioButton": "RadioButton",
        "ControlType.ComboBox": "ComboBox",
        "ControlType.ListItem": "ListItem",
        "ControlType.List": "List",
        "ControlType.MenuItem": "MenuItem",
        "ControlType.Menu": "Menu",
        "ControlType.Slider": "Slider",
        "ControlType.Tab": "Tab",
        "ControlType.TabItem": "TabItem",
        "ControlType.Text": "Text",
        "ControlType.Hyperlink": "Hyperlink",
        "ControlType.Image": "Image",
        "ControlType.Tree": "Tree",
        "ControlType.TreeItem": "TreeItem",
        "ControlType.DataGrid": "DataGrid",
        "ControlType.DataItem": "DataItem",
        "ControlType.Document": "Document",
        "ControlType.Window": "Window",
        "ControlType.Pane": "Pane",
        "ControlType.Group": "Group",
        "ControlType.Toolbar": "ToolBar",
        "ControlType.StatusBar": "StatusBar",
        "ControlType.ProgressBar": "ProgressBar",
        "ControlType.Spinner": "Spinner",
        "ControlType.Calendar": "Calendar",
        "ControlType.Custom": "Custom",
    }
    return mapping.get(control_type, "Control")
