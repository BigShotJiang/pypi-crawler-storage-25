"""FusionTest — AI-powered UI testing for mobile and desktop."""
__version__ = "0.1.0"
