"""
fusiontest/recording/recorder.py

Unified video recording interface for all FusionTest platforms.

Platform strategies:
  playwright  — Playwright CDP video (lossless WebM, then converted to MP4)
  android     — Appium startRecordingScreen (returns base64 MP4)
  ios         — Appium startRecordingScreen (same API, slightly different caps)
  windows     — Screenshot polling → imageio MP4 stitch (no native CDP)

The Recorder is lifecycle-managed:
    recorder.start(handle)   # pass the Playwright Page or Appium driver
    recorder.stop()          # returns Path to the saved video file

RecordingConfig controls resolution, FPS, and output directory.
"""

from __future__ import annotations

import base64
import logging
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

logger = logging.getLogger("fusiontest.recording")


@dataclass
class RecordingConfig:
    output_dir: str | Path = "fusiontest-reports/videos"
    fps: int = 10                   # for screenshot-stitch mode (Windows)
    width: int = 1280
    height: int = 800
    format: str = "mp4"            # "mp4" or "webm"
    # Playwright-specific
    playwright_video_size: dict = field(default_factory=lambda: {"width": 1280, "height": 800})
    # Appium-specific
    appium_video_quality: str = "medium"   # low / medium / high / photo
    appium_time_limit: int = 1800          # seconds (30 min hard cap)


class Recorder:
    """
    Platform-agnostic video recorder.

    Usage:
        recorder = Recorder(platform="playwright", config=RecordingConfig())

        # Playwright:
        recorder.start(page)          # pass the playwright.async_api.Page
        video_path = recorder.stop()

        # Android/iOS:
        recorder.start(appium_driver)
        video_path = recorder.stop()

        # Windows:
        recorder.start(winappdriver_driver)
        video_path = recorder.stop()
    """

    def __init__(
        self,
        platform: str,
        config: RecordingConfig | None = None,
        run_id: str = "",
    ):
        self.platform = platform.lower()
        self.config = config or RecordingConfig()
        self.run_id = run_id or str(int(time.time()))
        self._handle: Any = None
        self._start_time: float = 0.0
        self._screenshot_thread = None
        self._screenshots: list[bytes] = []
        self._stop_event = None
        Path(self.config.output_dir).mkdir(parents=True, exist_ok=True)

    # ── Public API ─────────────────────────────────────────────────────────────

    def start(self, handle: Any) -> None:
        """
        Begin recording.

        Args:
            handle: The driver/page object appropriate for the platform:
                    - Playwright Page (playwright)
                    - Appium WebDriver (android, ios)
                    - WinAppDriver WebDriver (windows)
        """
        self._handle = handle
        self._start_time = time.time()

        if self.platform in ("android", "ios"):
            self._start_appium()
        elif self.platform == "playwright":
            # Playwright video is started at context creation time, not here.
            # start() is a no-op for Playwright — call start_playwright_context()
            # before creating the page instead.
            logger.info("Playwright recording is context-level; ensure video=True in new_context()")
        elif self.platform == "windows":
            self._start_screenshot_poll()
        else:
            logger.warning(f"Recording not supported for platform: {self.platform}")

    def stop(self) -> Path | None:
        """
        Stop recording and return the path to the saved video file.
        Returns None if recording was not started or is not supported.
        """
        if self.platform in ("android", "ios"):
            return self._stop_appium()
        elif self.platform == "playwright":
            return self._finalize_playwright()
        elif self.platform == "windows":
            return self._stop_screenshot_poll()
        return None

    # ── Playwright ─────────────────────────────────────────────────────────────

    @classmethod
    def playwright_context_options(cls, config: RecordingConfig | None = None) -> dict:
        """
        Return kwargs to pass to `browser.new_context()` to enable recording.

        Usage:
            options = Recorder.playwright_context_options(config)
            context = await browser.new_context(**options)
            page = await context.new_page()
            # ... test ...
            await context.close()  # triggers video finalization
        """
        cfg = config or RecordingConfig()
        return {
            "record_video_dir": str(cfg.output_dir),
            "record_video_size": cfg.playwright_video_size,
        }

    def _finalize_playwright(self) -> Path | None:
        """
        After context.close(), Playwright writes a WebM file to record_video_dir.
        This method finds the most recent WebM and converts it to MP4 if needed.
        """
        output_dir = Path(self.config.output_dir)
        webm_files = sorted(
            output_dir.glob("*.webm"),
            key=lambda p: p.stat().st_mtime,
            reverse=True,
        )
        if not webm_files:
            logger.warning("No Playwright WebM recording found")
            return None

        webm_path = webm_files[0]

        if self.config.format == "webm":
            logger.info(f"Playwright recording saved: {webm_path}")
            return webm_path

        # Convert WebM → MP4 via ffmpeg
        mp4_path = webm_path.with_suffix(".mp4")
        try:
            import subprocess
            subprocess.run(
                ["ffmpeg", "-y", "-i", str(webm_path), "-c:v", "libx264",
                 "-preset", "fast", "-crf", "22", str(mp4_path)],
                check=True,
                capture_output=True,
            )
            webm_path.unlink()   # remove the WebM after conversion
            logger.info(f"Playwright recording saved as MP4: {mp4_path}")
            return mp4_path
        except (subprocess.CalledProcessError, FileNotFoundError):
            logger.warning("ffmpeg not available — keeping WebM format")
            return webm_path

    # ── Appium (Android + iOS) ─────────────────────────────────────────────────

    def _start_appium(self) -> None:
        try:
            caps: dict[str, Any] = {
                "timeLimit": self.config.appium_time_limit,
                "videoType": "mp4",
                "videoQuality": self.config.appium_video_quality,
            }
            if self.platform == "android":
                caps.update({
                    "videoSize": f"{self.config.width}x{self.config.height}",
                    "bitRate": 2_000_000,
                })
            elif self.platform == "ios":
                caps.update({
                    "videoFps": self.config.fps,
                    "videoScale": "1",
                })
            self._handle.start_recording_screen(**caps)
            logger.info(f"{self.platform.upper()} screen recording started")
        except Exception as e:
            logger.warning(f"Could not start {self.platform} recording: {e}")

    def _stop_appium(self) -> Path | None:
        try:
            raw_b64: str = self._handle.stop_recording_screen()
            video_bytes = base64.b64decode(raw_b64)
            out_path = self._video_path("mp4")
            out_path.write_bytes(video_bytes)
            logger.info(f"{self.platform.upper()} recording saved: {out_path}")
            return out_path
        except Exception as e:
            logger.warning(f"Could not stop {self.platform} recording: {e}")
            return None

    # ── Windows screenshot polling ─────────────────────────────────────────────

    def _start_screenshot_poll(self) -> None:
        import threading

        self._screenshots = []
        self._stop_event = threading.Event()

        interval = 1.0 / self.config.fps

        def _poll() -> None:
            while not self._stop_event.is_set():  # type: ignore[union-attr]
                try:
                    png = self._handle.get_screenshot_as_png()
                    self._screenshots.append(png)
                except Exception:
                    pass
                time.sleep(interval)

        self._screenshot_thread = threading.Thread(target=_poll, daemon=True)
        self._screenshot_thread.start()
        logger.info(f"Windows screenshot polling started ({self.config.fps} fps)")

    def _stop_screenshot_poll(self) -> Path | None:
        if self._stop_event:
            self._stop_event.set()
        if self._screenshot_thread:
            self._screenshot_thread.join(timeout=5)

        if not self._screenshots:
            logger.warning("No screenshots captured for Windows recording")
            return None

        return self._stitch_to_mp4(self._screenshots)

    def _stitch_to_mp4(self, png_frames: list[bytes]) -> Path | None:
        """Convert a list of PNG bytes to an MP4 using imageio + ffmpeg."""
        try:
            import io

            import imageio
            import numpy as np
            from PIL import Image

            out_path = self._video_path("mp4")

            with imageio.get_writer(
                str(out_path),
                fps=self.config.fps,
                codec="libx264",
                quality=6,
            ) as writer:
                for png in png_frames:
                    img = Image.open(io.BytesIO(png)).convert("RGB")
                    img = img.resize((self.config.width, self.config.height))
                    writer.append_data(np.array(img))

            logger.info(f"Windows recording stitched: {out_path} ({len(png_frames)} frames)")
            return out_path

        except ImportError:
            logger.warning(
                "imageio / Pillow not installed — cannot stitch Windows recording.\n"
                "Install with: pip install imageio[ffmpeg] Pillow"
            )
            return self._save_frames_as_gif_fallback(png_frames)

    def _save_frames_as_gif_fallback(self, png_frames: list[bytes]) -> Path | None:
        """Last resort: save as animated GIF if imageio is unavailable."""
        try:
            import io

            from PIL import Image

            out_path = self._video_path("gif")
            pil_frames = [Image.open(io.BytesIO(p)).convert("RGB") for p in png_frames]
            pil_frames[0].save(
                out_path,
                save_all=True,
                append_images=pil_frames[1:],
                duration=int(1000 / self.config.fps),
                loop=0,
            )
            logger.info(f"Windows recording saved as GIF: {out_path}")
            return out_path
        except Exception as e:
            logger.error(f"Failed to save GIF fallback: {e}")
            return None

    # ── Helpers ────────────────────────────────────────────────────────────────

    def _video_path(self, ext: str) -> Path:
        ts = time.strftime("%Y%m%d_%H%M%S")
        filename = f"fusiontest_{self.platform}_{self.run_id}_{ts}.{ext}"
        return Path(self.config.output_dir) / filename
