"""
fusiontest.recording — Video recording for test sessions.

Each platform uses the best available mechanism:
  - Playwright/Electron : Playwright's built-in CDP video recording
  - Android / iOS       : Appium startRecordingScreen / stopRecordingScreen
  - Windows             : Screenshot-to-MP4 stitching via imageio / ffmpeg

Usage:
    from fusiontest.recording import Recorder
    recorder = Recorder(platform="android", output_dir="fusiontest-reports/videos")
    recorder.start(driver_or_page)
    # ... run test ...
    video_path = recorder.stop()
"""

from fusiontest.recording.recorder import Recorder, RecordingConfig

__all__ = ["Recorder", "RecordingConfig"]
