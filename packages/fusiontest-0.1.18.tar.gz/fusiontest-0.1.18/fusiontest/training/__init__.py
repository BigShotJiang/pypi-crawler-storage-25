"""
fusiontest.training — MPNet fine-tuning pipeline for FusionTest action ranking.

Workflow:
  1. Collect  — gather (screen_text, goal, action, outcome) tuples from live runs
  2. Build    — convert raw logs into contrastive training pairs
  3. Train    — fine-tune sentence-transformers/all-mpnet-base-v2 with MultipleNegativesRankingLoss
  4. Evaluate — measure MRR / accuracy on a held-out split
  5. Export   — save the fine-tuned model for use in ActionModel(backend="mpnet")

Quick start:
    from fusiontest.training import FusionTrainer, TrainingConfig, DataCollector
    trainer = FusionTrainer(TrainingConfig(
        run_log_dir="fusiontest-reports/",
        output_dir="models/fusiontest-mpnet",
    ))
    result = trainer.run()
    print(f"Model saved to {result.output_dir}")

Or via CLI:
    fusiontest-train --run-log-dir fusiontest-reports/ --output-dir models/fusiontest-mpnet
"""

from fusiontest.training.data_collector import ActionSample, DataCollector
from fusiontest.training.dataset_builder import DatasetBuilder
from fusiontest.training.trainer import FusionTrainer, TrainingConfig, TrainingResult

__all__ = [
    "FusionTrainer",
    "TrainingConfig",
    "TrainingResult",
    "DataCollector",
    "ActionSample",
    "DatasetBuilder",
]
