"""
fusiontest/training/dataset_builder.py

Converts raw ActionSample lists into sentence-transformers InputExample
pairs ready for MultipleNegativesRankingLoss (MNRL) training.

MNRL expects (anchor, positive) pairs.  Within each batch, every other
positive in the batch is treated as an in-batch negative — so the key
is to assemble high-quality (query, positive_doc) pairs and let the loss
function do the heavy lifting.

We also generate an evaluation split using TripletEvaluator for live
MRR tracking during training.
"""

from __future__ import annotations

import logging
import random
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING

logger = logging.getLogger("fusiontest.training.dataset")

if TYPE_CHECKING:
    from fusiontest.training.data_collector import ActionSample


@dataclass
class SplitSizes:
    train: int
    val: int
    test: int


class DatasetBuilder:
    """
    Transforms ActionSample lists into sentence-transformers datasets.

    Usage:
        builder = DatasetBuilder(val_ratio=0.1, test_ratio=0.1, seed=42)
        train_examples, val_evaluator, test_evaluator = builder.build(samples)
    """

    def __init__(
        self,
        val_ratio: float = 0.1,
        test_ratio: float = 0.1,
        seed: int = 42,
        max_screen_chars: int = 512,
    ):
        self.val_ratio = val_ratio
        self.test_ratio = test_ratio
        self.seed = seed
        self.max_screen_chars = max_screen_chars

    def build(self, samples: list[ActionSample]):
        """
        Returns:
            train_examples  — list[InputExample] for MNRL training
            val_evaluator   — TripletEvaluator on val split
            test_evaluator  — TripletEvaluator on test split
            sizes           — SplitSizes dataclass
        """
        try:
            from sentence_transformers import InputExample
            from sentence_transformers.evaluation import TripletEvaluator
        except ImportError as err:
            raise RuntimeError(
                "Training pipeline requires sentence-transformers:\n"
                "    pip install fusiontest[training]"
            ) from err

        positives = [s for s in samples if s.label == 1]
        hard_negatives = {s.action: s for s in samples if s.label == -1}

        if len(positives) < 10:
            raise ValueError(
                f"Need at least 10 positive samples to train — got {len(positives)}. "
                "Run more tests and collect more data first."
            )

        random.seed(self.seed)
        random.shuffle(positives)

        n = len(positives)
        n_val = max(1, int(n * self.val_ratio))
        n_test = max(1, int(n * self.test_ratio))
        n_train = n - n_val - n_test

        train_pos = positives[:n_train]
        val_pos = positives[n_train: n_train + n_val]
        test_pos = positives[n_train + n_val:]

        # Training: (anchor=query, positive=action+screen) InputExamples
        train_examples = [
            InputExample(texts=[s.query, self._build_doc(s)])
            for s in train_pos
        ]

        # Eval: triplets (anchor, positive, negative)
        val_evaluator = self._make_triplet_evaluator(
            val_pos, hard_negatives, "val", TripletEvaluator
        )
        test_evaluator = self._make_triplet_evaluator(
            test_pos, hard_negatives, "test", TripletEvaluator
        )

        sizes = SplitSizes(train=n_train, val=n_val, test=n_test)
        logger.info(
            f"Dataset built — train: {n_train}, val: {n_val}, test: {n_test} "
            f"({len(hard_negatives)} unique hard negatives available)"
        )
        return train_examples, val_evaluator, test_evaluator, sizes

    def _build_doc(self, sample: ActionSample) -> str:
        """
        Build the document text for a positive sample.
        Truncates screen_text to keep prompt lengths manageable.
        """
        screen = sample.screen_text[: self.max_screen_chars]
        return f"{sample.action} | {screen}"

    def _make_triplet_evaluator(
        self,
        positives: list[ActionSample],
        hard_negatives: dict[str, ActionSample],
        name: str,
        TripletEvaluator,
    ):
        anchors, pos_docs, neg_docs = [], [], []

        # Build the negative pool: prefer hard negatives, fall back to
        # a randomly shuffled positive from a different goal
        all_actions = [s.action for s in positives]
        random.shuffle(all_actions)

        for i, s in enumerate(positives):
            # Pick a hard negative if any exist
            neg_candidate = next(
                (hn for hn in hard_negatives.values() if hn.goal == s.goal),
                None,
            )

            if neg_candidate is None:
                # Use a different positive action as an in-domain negative
                neg_action = all_actions[(i + 1) % len(all_actions)]
                neg_screen = positives[(i + 1) % len(positives)].screen_text
                neg_text = f"{neg_action} | {neg_screen[: self.max_screen_chars]}"
            else:
                neg_text = self._build_doc(neg_candidate)

            anchors.append(s.query)
            pos_docs.append(self._build_doc(s))
            neg_docs.append(neg_text)

        return TripletEvaluator(
            anchors=anchors,
            positives=pos_docs,
            negatives=neg_docs,
            name=name,
        )

    def save_to_jsonl(
        self,
        samples: list[ActionSample],
        path: str | Path,
    ) -> None:
        """Save samples to JSONL for inspection or offline re-use."""
        import json

        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        with open(path, "w") as f:
            for s in samples:
                f.write(json.dumps({
                    "query": s.query,
                    "doc": self._build_doc(s),
                    "label": s.label,
                    "platform": s.platform,
                    "locale": s.locale,
                    "run_id": s.run_id,
                }) + "\n")
        logger.info(f"Saved {len(samples)} samples to {path}")

    @classmethod
    def load_from_jsonl(cls, path: str | Path) -> list[ActionSample]:
        """Re-load samples previously saved with save_to_jsonl()."""
        import json

        from fusiontest.training.data_collector import ActionSample

        samples = []
        with open(path) as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                d = json.loads(line)
                samples.append(ActionSample(
                    screen_text=d.get("doc", ""),
                    goal=d.get("query", "").replace("Goal: ", "", 1),
                    action=d.get("doc", "").split(" | ")[0],
                    label=d.get("label", 1),
                    platform=d.get("platform", ""),
                    locale=d.get("locale", ""),
                    run_id=d.get("run_id", ""),
                ))
        return samples
