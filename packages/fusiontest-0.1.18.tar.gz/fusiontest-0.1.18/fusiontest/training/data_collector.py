"""
fusiontest/training/data_collector.py

Collects raw training signal from FusionTest run logs.

Each completed test run produces a JSON report in fusiontest-reports/.
This module reads those reports and the optional step-level action logs
to produce a stream of (screen_text, goal, action, label) tuples that
the DatasetBuilder can turn into contrastive training pairs.

Label convention:
  1  — action was executed and the goal eventually succeeded   (positive)
  0  — action was executed but the goal failed                 (weak negative)
 -1  — action was in the invalid_actions list (guardrails)     (hard negative)
"""

from __future__ import annotations

import json
import logging
from collections.abc import Iterator
from dataclasses import dataclass, field
from pathlib import Path

logger = logging.getLogger("fusiontest.training.collector")


@dataclass
class ActionSample:
    """One training sample: a (query, candidate, label) triple."""
    screen_text: str
    goal: str
    action: str          # string form, e.g. 'tap on "Submit" (conf=0.95)'
    label: int           # 1 = positive, 0 = weak neg, -1 = hard neg
    platform: str = ""
    locale: str = ""
    run_id: str = ""

    @property
    def query(self) -> str:
        """The query embedding input: goal + recent context."""
        return f"Goal: {self.goal}"

    @property
    def positive(self) -> str:
        """Text to embed as the positive candidate."""
        return f"{self.action} | {self.screen_text[:300]}"


@dataclass
class CollectionStats:
    total_runs: int = 0
    total_steps: int = 0
    positives: int = 0
    weak_negatives: int = 0
    hard_negatives: int = 0
    skipped_runs: int = 0
    errors: list[str] = field(default_factory=list)


class DataCollector:
    """
    Reads FusionTest JSON run reports and extracts ActionSample instances.

    Expected report structure (produced by reporter.py):
    {
      "name": "...",
      "platform": "android",
      "locale": "en-US",
      "success": true,
      "steps": [
        {
          "goal": "Log in to the app",
          "success": true,
          "actions": ["tap on \"Login\" (conf=0.92)", ...],
          "invalid_actions": ["type into \"Submit\" (conf=0.8)", ...],
          ...
        }
      ]
    }

    For richer signal, FusionTestRunner can be configured to write
    step-level JSONL logs (see runner.py step_log_path option).
    """

    def __init__(
        self,
        report_dir: str | Path,
        step_log_dir: str | Path | None = None,
        min_steps_per_goal: int = 1,
    ):
        self.report_dir = Path(report_dir)
        self.step_log_dir = Path(step_log_dir) if step_log_dir else None
        self.min_steps_per_goal = min_steps_per_goal

    def collect(self) -> tuple[list[ActionSample], CollectionStats]:
        """Read all reports and return (samples, stats)."""
        samples: list[ActionSample] = []
        stats = CollectionStats()

        report_files = sorted(self.report_dir.glob("fusiontest_*.json"))
        logger.info(f"Found {len(report_files)} report files in {self.report_dir}")

        for path in report_files:
            try:
                new_samples = list(self._extract_from_report(path, stats))
                samples.extend(new_samples)
            except Exception as e:
                stats.skipped_runs += 1
                stats.errors.append(f"{path.name}: {e}")
                logger.warning(f"Skipped {path.name}: {e}")

        stats.total_runs = len(report_files) - stats.skipped_runs
        logger.info(
            f"Collected {len(samples)} samples "
            f"(+{stats.positives} / ~{stats.weak_negatives} / -{stats.hard_negatives}) "
            f"from {stats.total_runs} runs"
        )
        return samples, stats

    def _extract_from_report(
        self, path: Path, stats: CollectionStats
    ) -> Iterator[ActionSample]:
        with open(path) as f:
            report = json.load(f)

        run_id = path.stem
        platform = report.get("platform", "")
        locale = report.get("locale", "en-US")
        report.get("success", False)

        for step in report.get("steps", []):
            goal = step.get("goal", "").strip()
            step_success = step.get("success", False)
            actions = step.get("actions", [])
            invalid_actions = step.get("invalid_actions", [])

            if not goal or len(actions) < self.min_steps_per_goal:
                continue

            stats.total_steps += 1

            # We don't have the live screen_text in basic reports — use a
            # structured placeholder.  If step-level JSONL logs exist, they
            # carry the real screen_text (see _extract_from_step_log).
            screen_placeholder = f"[screen from {platform} run, goal: {goal}]"

            # Positive: actions that ran in a successful step
            if step_success:
                for action_str in actions:
                    stats.positives += 1
                    yield ActionSample(
                        screen_text=screen_placeholder,
                        goal=goal,
                        action=action_str,
                        label=1,
                        platform=platform,
                        locale=locale,
                        run_id=run_id,
                    )

            # Weak negative: actions from a failed step
            else:
                for action_str in actions:
                    stats.weak_negatives += 1
                    yield ActionSample(
                        screen_text=screen_placeholder,
                        goal=goal,
                        action=action_str,
                        label=0,
                        platform=platform,
                        locale=locale,
                        run_id=run_id,
                    )

            # Hard negative: actions the guardrails rejected
            for action_str in invalid_actions:
                stats.hard_negatives += 1
                yield ActionSample(
                    screen_text=screen_placeholder,
                    goal=goal,
                    action=action_str,
                    label=-1,
                    platform=platform,
                    locale=locale,
                    run_id=run_id,
                )

        # If step-level logs exist, override with richer data
        if self.step_log_dir:
            step_log = self.step_log_dir / f"{run_id}_steps.jsonl"
            if step_log.exists():
                yield from self._extract_from_step_log(step_log, platform, locale, run_id, stats)

    def _extract_from_step_log(
        self,
        path: Path,
        platform: str,
        locale: str,
        run_id: str,
        stats: CollectionStats,
    ) -> Iterator[ActionSample]:
        """
        Parse richer step-level JSONL logs emitted by FusionTestRunner
        when step_log_path is configured.  Each line is:
        {
          "goal": "...",
          "screen_text": "=== SCREEN STATE ===\\n...",
          "action": "tap on \\"Login\\" (conf=0.92)",
          "outcome": "success" | "failure" | "invalid"
        }
        """
        with open(path) as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    entry = json.loads(line)
                except json.JSONDecodeError:
                    continue

                outcome = entry.get("outcome", "")
                label = {"success": 1, "failure": 0, "invalid": -1}.get(outcome, 0)

                if label == 1:
                    stats.positives += 1
                elif label == 0:
                    stats.weak_negatives += 1
                else:
                    stats.hard_negatives += 1

                yield ActionSample(
                    screen_text=entry.get("screen_text", ""),
                    goal=entry.get("goal", ""),
                    action=entry.get("action", ""),
                    label=label,
                    platform=platform,
                    locale=locale,
                    run_id=run_id,
                )
