"""
fusiontest/training/trainer.py

Fine-tunes sentence-transformers/all-mpnet-base-v2 on FusionTest run data
using MultipleNegativesRankingLoss (MNRL).

MNRL is ideal here because:
  - We have (query, positive_doc) pairs without explicit negatives
  - In-batch negatives are free and scale well
  - The resulting model produces calibrated cosine similarities

The fine-tuned model can be dropped into ActionModel(backend="mpnet",
model_path="path/to/fusiontest-mpnet") for fast, cheap, deterministic
action ranking without any LLM API calls.
"""

from __future__ import annotations

import logging
import os
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING

logger = logging.getLogger("fusiontest.training.trainer")

if TYPE_CHECKING:
    pass


@dataclass
class TrainingConfig:
    """All hyperparameters and I/O paths for a training run."""

    # Model
    base_model: str = "sentence-transformers/all-mpnet-base-v2"
    output_dir: str = "models/fusiontest-mpnet"

    # Data
    run_log_dir: str = "fusiontest-reports"
    step_log_dir: str | None = None
    dataset_cache_path: str | None = None   # write/read JSONL cache

    # Training
    epochs: int = 4
    batch_size: int = 32
    warmup_ratio: float = 0.1
    learning_rate: float = 2e-5
    max_seq_length: int = 256
    fp16: bool = True              # set False if GPU lacks fp16 support
    evaluation_steps: int = 500    # evaluate every N steps

    # Data split
    val_ratio: float = 0.1
    test_ratio: float = 0.1
    seed: int = 42

    # Misc
    use_wandb: bool = False
    wandb_project: str = "fusiontest-mpnet"
    save_best_model: bool = True


@dataclass
class TrainingResult:
    output_dir: str
    best_val_score: float
    final_test_score: float
    total_duration_seconds: float
    sizes: dict = field(default_factory=dict)
    metrics_history: list[dict] = field(default_factory=list)


class FusionTrainer:
    """
    End-to-end fine-tuning pipeline for the FusionTest MPNet action model.

    Usage:
        trainer = FusionTrainer(TrainingConfig(
            run_log_dir="fusiontest-reports/",
            output_dir="models/fusiontest-mpnet",
            epochs=4,
        ))
        result = trainer.run()
        print(f"Best val score: {result.best_val_score:.4f}")
        print(f"Model saved to: {result.output_dir}")
    """

    def __init__(self, config: TrainingConfig | None = None, **kwargs):
        if config is None:
            config = TrainingConfig(**kwargs)
        self.config = config

    def run(self) -> TrainingResult:
        start = time.time()
        self._check_dependencies()

        logger.info("=== FusionTest MPNet Fine-tuning Pipeline ===")
        logger.info(f"Base model : {self.config.base_model}")
        logger.info(f"Output dir : {self.config.output_dir}")

        # 1. Load or collect data
        samples = self._load_samples()

        # 2. Build train/val/test splits
        from fusiontest.training.dataset_builder import DatasetBuilder

        builder = DatasetBuilder(
            val_ratio=self.config.val_ratio,
            test_ratio=self.config.test_ratio,
            seed=self.config.seed,
        )
        train_examples, val_evaluator, test_evaluator, sizes = builder.build(samples)

        logger.info(
            f"Split — train: {sizes.train}, val: {sizes.val}, test: {sizes.test}"
        )

        # 3. Build model + loss
        model, loss_fn = self._build_model_and_loss()

        # 4. Configure W&B if requested
        if self.config.use_wandb:
            self._init_wandb()

        # 5. Train
        self._train(model, loss_fn, train_examples, val_evaluator)

        # 6. Evaluate on test set
        test_score = self._evaluate(model, test_evaluator, "test")

        # 7. Load best checkpoint and re-evaluate val
        best_model_path = os.path.join(self.config.output_dir, "best_model")
        if self.config.save_best_model and Path(best_model_path).exists():
            from sentence_transformers import SentenceTransformer
            model = SentenceTransformer(best_model_path)
            logger.info(f"Loaded best model from {best_model_path}")

        val_score = self._evaluate(model, val_evaluator, "val-final")

        duration = time.time() - start
        logger.info(f"Training complete in {duration / 60:.1f} min")
        logger.info(f"Val score: {val_score:.4f}  |  Test score: {test_score:.4f}")
        logger.info(f"Model saved to: {self.config.output_dir}")

        return TrainingResult(
            output_dir=self.config.output_dir,
            best_val_score=val_score,
            final_test_score=test_score,
            total_duration_seconds=duration,
            sizes={"train": sizes.train, "val": sizes.val, "test": sizes.test},
        )

    # ── Steps ─────────────────────────────────────────────────────────────────

    def _load_samples(self):
        from fusiontest.training.data_collector import DataCollector
        from fusiontest.training.dataset_builder import DatasetBuilder

        cache = (
            Path(self.config.dataset_cache_path)
            if self.config.dataset_cache_path
            else None
        )

        if cache and cache.exists():
            logger.info(f"Loading cached dataset from {cache}")
            return DatasetBuilder.load_from_jsonl(cache)

        logger.info(f"Collecting samples from {self.config.run_log_dir}")
        collector = DataCollector(
            report_dir=self.config.run_log_dir,
            step_log_dir=self.config.step_log_dir,
        )
        samples, stats = collector.collect()

        if stats.errors:
            for err in stats.errors:
                logger.warning(f"  Collection warning: {err}")

        if cache:
            DatasetBuilder().save_to_jsonl(samples, cache)
            logger.info(f"Cached dataset to {cache}")

        return samples

    def _build_model_and_loss(self):
        from sentence_transformers import SentenceTransformer
        from sentence_transformers.losses import MultipleNegativesRankingLoss

        logger.info(f"Loading base model: {self.config.base_model}")
        model = SentenceTransformer(self.config.base_model)
        model.max_seq_length = self.config.max_seq_length

        loss_fn = MultipleNegativesRankingLoss(model)
        return model, loss_fn

    def _train(self, model, loss_fn, train_examples, val_evaluator) -> None:
        from torch.utils.data import DataLoader

        train_loader = DataLoader(
            train_examples,
            shuffle=True,
            batch_size=self.config.batch_size,
        )

        warmup_steps = int(
            len(train_loader) * self.config.epochs * self.config.warmup_ratio
        )

        (
            os.path.join(self.config.output_dir, "best_model")
            if self.config.save_best_model
            else None
        )

        logger.info(
            f"Training for {self.config.epochs} epochs, "
            f"batch_size={self.config.batch_size}, "
            f"warmup_steps={warmup_steps}, "
            f"lr={self.config.learning_rate}"
        )

        model.fit(
            train_objectives=[(train_loader, loss_fn)],
            evaluator=val_evaluator,
            epochs=self.config.epochs,
            warmup_steps=warmup_steps,
            optimizer_params={"lr": self.config.learning_rate},
            evaluation_steps=self.config.evaluation_steps,
            output_path=self.config.output_dir,
            save_best_model=self.config.save_best_model,
            use_amp=self.config.fp16,
            show_progress_bar=True,
        )

    def _evaluate(self, model, evaluator, name: str) -> float:
        logger.info(f"Evaluating on {name} split...")
        score = evaluator(model, output_path=self.config.output_dir)
        logger.info(f"  {name} accuracy: {score:.4f}")
        return score

    def _init_wandb(self) -> None:
        try:
            import wandb
            wandb.init(
                project=self.config.wandb_project,
                config={
                    "base_model": self.config.base_model,
                    "epochs": self.config.epochs,
                    "batch_size": self.config.batch_size,
                    "learning_rate": self.config.learning_rate,
                    "max_seq_length": self.config.max_seq_length,
                },
            )
        except ImportError:
            logger.warning("W&B not installed — skipping (pip install wandb)")

    def _check_dependencies(self) -> None:
        missing = []
        for pkg in ("sentence_transformers", "torch"):
            try:
                __import__(pkg)
            except ImportError:
                missing.append(pkg)
        if missing:
            raise RuntimeError(
                f"Training pipeline requires: {', '.join(missing)}\n"
                "    pip install fusiontest[training]"
            )


# ── CLI entry point ────────────────────────────────────────────────────────────

def main() -> None:
    """
    Minimal CLI for the training pipeline.
    Invoked via `python -m fusiontest.training.trainer` or the
    `fusiontest-train` console script added to pyproject.toml.
    """
    import argparse

    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s  %(name)s  %(levelname)s  %(message)s",
    )

    parser = argparse.ArgumentParser(
        description="Fine-tune MPNet on FusionTest run data"
    )
    parser.add_argument("--run-log-dir", default="fusiontest-reports",
                        help="Directory containing fusiontest_*.json reports")
    parser.add_argument("--output-dir", default="models/fusiontest-mpnet",
                        help="Where to save the fine-tuned model")
    parser.add_argument("--base-model",
                        default="sentence-transformers/all-mpnet-base-v2")
    parser.add_argument("--epochs", type=int, default=4)
    parser.add_argument("--batch-size", type=int, default=32)
    parser.add_argument("--lr", type=float, default=2e-5)
    parser.add_argument("--no-fp16", action="store_true")
    parser.add_argument("--wandb", action="store_true",
                        help="Log metrics to Weights & Biases")
    parser.add_argument("--cache", default=None,
                        help="JSONL cache path — write on first run, read on subsequent")
    parser.add_argument("--step-log-dir", default=None,
                        help="Directory containing step-level JSONL logs")
    args = parser.parse_args()

    config = TrainingConfig(
        base_model=args.base_model,
        output_dir=args.output_dir,
        run_log_dir=args.run_log_dir,
        step_log_dir=args.step_log_dir,
        dataset_cache_path=args.cache,
        epochs=args.epochs,
        batch_size=args.batch_size,
        learning_rate=args.lr,
        fp16=not args.no_fp16,
        use_wandb=args.wandb,
    )

    trainer = FusionTrainer(config)
    result = trainer.run()

    print("\nDone.")
    print(f"  Val score  : {result.best_val_score:.4f}")
    print(f"  Test score : {result.final_test_score:.4f}")
    print(f"  Model      : {result.output_dir}")
    print(f"  Duration   : {result.total_duration_seconds / 60:.1f} min")
    print("\nTo use the fine-tuned model:")
    print(f'  model = ActionModel(backend="mpnet", model_path="{result.output_dir}")')


if __name__ == "__main__":
    main()
