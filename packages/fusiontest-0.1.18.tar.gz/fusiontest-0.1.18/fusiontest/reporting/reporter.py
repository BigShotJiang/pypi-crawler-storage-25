"""
fusiontest/reporting/reporter.py

Handles all FusionTest reporting output:
  - Console summary (via CLI)
  - JSON report files
  - Slack webhook notifications
  - GitHub Actions annotations (for CI)
"""

from __future__ import annotations

import json
import logging
import os
from datetime import datetime, timezone
from pathlib import Path
from typing import TYPE_CHECKING

import httpx

if TYPE_CHECKING:
    from fusiontest.core.runner import RunResult

logger = logging.getLogger("fusiontest.reporting")


class Reporter:
    """
    Unified reporter — call after every RunResult to dispatch
    to all configured outputs.

    Usage:
        reporter = Reporter(config)
        reporter.report(run_result)
    """

    def __init__(
        self,
        slack_webhook: str | None = None,
        output_dir: str | Path = "fusiontest-reports",
        github_annotations: bool = False,
        save_screenshots: bool = True,
    ):
        self.slack_webhook = slack_webhook or os.getenv("FUSIONTEST_SLACK_WEBHOOK")
        self.output_dir = Path(output_dir)
        self.github_annotations = github_annotations
        self.save_screenshots = save_screenshots

    def report(self, result: RunResult) -> Path:
        """Run all reporters and return the path to the JSON report."""
        self.output_dir.mkdir(parents=True, exist_ok=True)

        report_path = self._save_json(result)
        self._save_screenshots(result)

        if self.slack_webhook:
            self._notify_slack(result)

        if self.github_annotations:
            self._emit_github_annotations(result)

        return report_path

    # ── JSON ───────────────────────────────────────────────────────────────────

    def _save_json(self, result: RunResult) -> Path:
        timestamp = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
        filename = f"fusiontest_{result.platform}_{timestamp}.json"
        path = self.output_dir / filename

        data = {
            "fusiontest_version": "0.1.0",
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "name": result.name,
            "platform": result.platform,
            "locale": result.locale,
            "success": result.success,
            "stability_score": round(result.stability_score, 4),
            "total_duration_seconds": round(result.total_duration_seconds, 2),
            "bugs_detected": result.bugs_detected,
            "steps": [
                {
                    "goal": s.goal,
                    "success": s.success,
                    "steps_taken": s.steps_taken,
                    "actions": s.actions,
                    "error": s.error,
                    "duration_seconds": round(s.duration_seconds, 2),
                }
                for s in result.steps
            ],
        }

        with open(path, "w") as f:
            json.dump(data, f, indent=2)

        logger.info(f"Report saved: {path}")
        return path

    # ── Screenshots ────────────────────────────────────────────────────────────

    def _save_screenshots(self, result: RunResult) -> None:
        if not self.save_screenshots:
            return

        shots_dir = self.output_dir / "screenshots"
        shots_dir.mkdir(exist_ok=True)

        for i, step in enumerate(result.steps, 1):
            for j, screenshot in enumerate(step.screenshots):
                label = "fail" if not step.success else f"step{j+1}"
                filename = f"goal{i:02d}_{label}.png"
                path = shots_dir / filename
                path.write_bytes(screenshot)
                logger.debug(f"Screenshot saved: {path}")

    # ── Slack ──────────────────────────────────────────────────────────────────

    def _notify_slack(self, result: RunResult) -> None:
        if not self.slack_webhook:
            return

        icon = "✅" if result.success else "❌"
        color = "#36a64f" if result.success else "#d00000"

        failed_steps = [s for s in result.steps if not s.success]
        failed_text = (
            "\n".join(f"  • {s.goal}: `{s.error}`" for s in failed_steps)
            if failed_steps
            else "All goals passed."
        )

        payload = {
            "attachments": [
                {
                    "color": color,
                    "blocks": [
                        {
                            "type": "section",
                            "text": {
                                "type": "mrkdwn",
                                "text": (
                                    f"{icon} *FusionTest: {result.name}*\n"
                                    f"Platform: `{result.platform}` · Locale: `{result.locale}` · "
                                    f"Stability: *{result.stability_score:.0%}* · "
                                    f"Duration: {result.total_duration_seconds:.0f}s"
                                ),
                            },
                        },
                        {
                            "type": "section",
                            "text": {"type": "mrkdwn", "text": failed_text},
                        },
                    ],
                }
            ]
        }

        try:
            resp = httpx.post(self.slack_webhook, json=payload, timeout=10)
            resp.raise_for_status()
            logger.info("Slack notification sent")
        except Exception as e:
            logger.warning(f"Slack notification failed: {e}")

    # ── GitHub Actions annotations ─────────────────────────────────────────────

    def _emit_github_annotations(self, result: RunResult) -> None:
        """
        Emit GitHub Actions workflow commands for failed steps.
        These appear as inline annotations in the PR diff and Actions log.
        """
        for step in result.steps:
            if not step.success:
                msg = f"FusionTest goal failed: {step.goal}"
                if step.error:
                    msg += f" ({step.error})"
                # GitHub Actions annotation format
                print(f"::error title=FusionTest Failure::{msg}")

        if result.success:
            print(f"::notice title=FusionTest::"
                  f"All {len(result.steps)} goals passed "
                  f"(stability={result.stability_score:.0%}, "
                  f"duration={result.total_duration_seconds:.0f}s)")


class CIReporter(Reporter):
    """
    Reporter preset for CI environments.
    Auto-detects GitHub Actions and enables appropriate outputs.
    """

    def __init__(self, **kwargs):
        github_actions = os.getenv("GITHUB_ACTIONS") == "true"
        super().__init__(
            github_annotations=github_actions,
            output_dir=os.getenv("FUSIONTEST_OUTPUT_DIR", "fusiontest-reports"),
            **kwargs,
        )
