"""fusiontest.discovery — Autonomous test goal discovery."""

from .goal_generator import DiscoveredGoal, GoalGenerator, GoalGeneratorConfig

__all__ = ["GoalGenerator", "GoalGeneratorConfig", "DiscoveredGoal"]
