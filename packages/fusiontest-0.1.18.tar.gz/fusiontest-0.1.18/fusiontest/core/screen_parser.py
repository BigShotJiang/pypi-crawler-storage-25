"""
fusiontest/core/screen_parser.py

Converts mobile/desktop accessibility trees into a compact token string
that the FusionTest action model can reason over.

Strategy:
  1. Walk the accessibility tree depth-first
  2. Extract interactive elements with their labels, types, and state
  3. Flatten to a structured text representation
  4. Optionally include non-interactive context (headers, text blocks)
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class UIElement:
    """Represents a single element extracted from the accessibility tree."""
    index: int
    element_type: str       # button, text_field, switch, list_item, etc.
    label: str              # accessibility label or visible text
    value: str = ""         # current value (for inputs, toggles)
    enabled: bool = True
    visible: bool = True
    rect: dict = field(default_factory=dict)   # x, y, width, height
    children: list[UIElement] = field(default_factory=list)
    raw: dict = field(default_factory=dict)    # original node from platform

    def is_interactive(self) -> bool:
        return self.enabled and self.visible and self.element_type in INTERACTIVE_TYPES

    def to_token(self) -> str:
        """Compact text token for LLM consumption."""
        parts = [f"[{self.index}]", self.element_type]
        if self.label:
            parts.append(f'"{self.label}"')
        if self.value:
            parts.append(f'value="{self.value}"')
        if not self.enabled:
            parts.append("disabled")
        return " ".join(parts)


INTERACTIVE_TYPES = {
    "button", "text_field", "text_area", "switch", "checkbox",
    "radio_button", "slider", "stepper", "link", "list_item",
    "tab", "menu_item", "segmented_control", "picker", "search_field",
}

CONTEXT_TYPES = {
    "heading", "static_text", "image", "label", "paragraph",
}


class ScreenParser:
    """
    Parses a raw accessibility tree dict (from Appium, XCTest,
    UIAutomator2, or WinAppDriver) into a flat list of UIElements
    and a compact screen string for the LLM.
    """

    def __init__(self, include_context: bool = True, max_elements: int = 120):
        self.include_context = include_context
        self.max_elements = max_elements
        self._counter = 0

    def parse(self, tree: dict | list, platform: str = "android") -> tuple[list[UIElement], str]:
        """
        Returns:
            elements: flat list of all extracted UIElements
            screen_text: compact string representation for LLM prompt
        """
        self._counter = 0
        elements: list[UIElement] = []
        self._walk(tree, elements, platform)

        interactive = [e for e in elements if e.is_interactive()]
        context = [e for e in elements if e.element_type in CONTEXT_TYPES] if self.include_context else []

        screen_text = self._build_screen_text(interactive, context)
        return elements, screen_text

    def _walk(self, node: Any, elements: list[UIElement], platform: str, depth: int = 0) -> None:
        if self._counter >= self.max_elements:
            return
        if not isinstance(node, dict):
            return

        element = self._extract(node, platform)
        if element:
            elements.append(element)
            self._counter += 1

        for child in node.get("children", []):
            self._walk(child, elements, platform, depth + 1)

    def _extract(self, node: dict, platform: str) -> UIElement | None:
        """Map platform-specific node keys to a unified UIElement."""
        if platform in ("android", "appium"):
            return self._extract_android(node)
        elif platform == "ios":
            return self._extract_ios(node)
        elif platform in ("windows", "winappdriver"):
            return self._extract_windows(node)
        elif platform in ("playwright", "web"):
            return self._extract_web(node)
        return None

    def _extract_android(self, node: dict) -> UIElement | None:
        element_type = _normalize_android_class(node.get("class", ""))
        if not element_type:
            return None
        label = node.get("content-desc") or node.get("text") or ""
        return UIElement(
            index=self._counter,
            element_type=element_type,
            label=label.strip(),
            value=node.get("text", ""),
            enabled=node.get("enabled", "true") == "true",
            visible=node.get("displayed", "true") == "true",
            rect={
                "x": int(node.get("bounds", "[0,0][0,0]").split(",")[0].replace("[", "")),
                "y": int(node.get("bounds", "[0,0][0,0]").split(",")[1].split("]")[0]),
            },
            raw=node,
        )

    def _extract_ios(self, node: dict) -> UIElement | None:
        element_type = _normalize_ios_type(node.get("type", ""))
        if not element_type:
            return None
        return UIElement(
            index=self._counter,
            element_type=element_type,
            label=(node.get("label") or node.get("name") or "").strip(),
            value=node.get("value", ""),
            enabled=node.get("enabled", True),
            visible=node.get("visible", True),
            rect=node.get("rect", {}),
            raw=node,
        )

    def _extract_windows(self, node: dict) -> UIElement | None:
        element_type = _normalize_windows_control(node.get("ControlType", ""))
        if not element_type:
            return None
        return UIElement(
            index=self._counter,
            element_type=element_type,
            label=(node.get("Name") or node.get("AutomationId") or "").strip(),
            value=node.get("Value", ""),
            enabled=node.get("IsEnabled", True),
            visible=not node.get("IsOffscreen", False),
            raw=node,
        )

    def _extract_web(self, node: dict) -> UIElement | None:
        """For Playwright snapshot nodes."""
        role = node.get("role", "")
        element_type = _normalize_aria_role(role)
        if not element_type:
            return None
        return UIElement(
            index=self._counter,
            element_type=element_type,
            label=(node.get("name") or node.get("text") or "").strip(),
            value=node.get("value", ""),
            enabled=not node.get("disabled", False),
            visible=not node.get("hidden", False),
            raw=node,
        )

    def _build_screen_text(self, interactive: list[UIElement], context: list[UIElement]) -> str:
        lines = ["=== SCREEN STATE ==="]

        if context:
            lines.append("-- Context --")
            for el in context[:30]:  # cap context to 30 items for richer page understanding
                if el.label:  # skip empty-label context
                    lines.append(f'  {el.element_type}: "{el.label}"')

        lines.append("-- Interactive elements --")
        for el in interactive:
            lines.append(f"  {el.to_token()}")

        return "\n".join(lines)


# ── Platform normalization helpers ─────────────────────────────────────────────

def _normalize_android_class(cls: str) -> str:
    mapping = {
        "android.widget.Button": "button",
        "android.widget.EditText": "text_field",
        "android.widget.TextView": "static_text",
        "android.widget.Switch": "switch",
        "android.widget.CheckBox": "checkbox",
        "android.widget.RadioButton": "radio_button",
        "android.widget.ImageButton": "button",
        "android.widget.Spinner": "picker",
        "android.widget.SeekBar": "slider",
        "android.widget.ListView": "list_item",
        "androidx.recyclerview.widget.RecyclerView": "list_item",
    }
    return mapping.get(cls, "")


def _normalize_ios_type(t: str) -> str:
    mapping = {
        "XCUIElementTypeButton": "button",
        "XCUIElementTypeTextField": "text_field",
        "XCUIElementTypeSecureTextField": "text_field",
        "XCUIElementTypeTextView": "text_area",
        "XCUIElementTypeSwitch": "switch",
        "XCUIElementTypeStaticText": "static_text",
        "XCUIElementTypeCell": "list_item",
        "XCUIElementTypeTab": "tab",
        "XCUIElementTypeSlider": "slider",
        "XCUIElementTypeSearchField": "search_field",
        "XCUIElementTypeLink": "link",
    }
    return mapping.get(t, "")


def _normalize_windows_control(ctrl: str) -> str:
    mapping = {
        "ControlType.Button": "button",
        "ControlType.Edit": "text_field",
        "ControlType.CheckBox": "checkbox",
        "ControlType.RadioButton": "radio_button",
        "ControlType.ComboBox": "picker",
        "ControlType.ListItem": "list_item",
        "ControlType.MenuItem": "menu_item",
        "ControlType.Slider": "slider",
        "ControlType.Tab": "tab",
        "ControlType.Text": "static_text",
        "ControlType.Hyperlink": "link",
    }
    return mapping.get(ctrl, "")


def _normalize_aria_role(role: str) -> str:
    mapping = {
        # Interactive
        "button": "button",
        "textbox": "text_field",
        "searchbox": "search_field",
        "checkbox": "checkbox",
        "radio": "radio_button",
        "link": "link",
        "menuitem": "menu_item",
        "option": "list_item",
        "listitem": "list_item",
        "tab": "tab",
        "slider": "slider",
        "switch": "switch",
        "combobox": "picker",
        "spinbutton": "text_field",
        "menuitemcheckbox": "checkbox",
        "menuitemradio": "radio_button",
        "treeitem": "list_item",
        # Context / structural
        "heading": "heading",
        "main": "static_text",
        "paragraph": "static_text",
        "img": "image",
        "image": "image",
        "figure": "image",
        "banner": "static_text",
        "contentinfo": "static_text",
        "navigation": "static_text",
        "region": "static_text",
        "article": "static_text",
        "section": "static_text",
        "complementary": "static_text",
        "list": "static_text",
        "text": "static_text",
    }
    return mapping.get(role.lower(), "")
