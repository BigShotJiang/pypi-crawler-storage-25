"""
fusiontest/core/secrets.py

Secret resolution and redaction for test goals.

Problem: users write goals like:
    "Login with email 'user@acme.com' and password 'hunter2'"

Those plaintext credentials get stored in the database, appear in
CloudWatch logs, dashboards, and report.json — a security problem.

Solution: template variables in goals, resolved at runtime:
    "Login with email {{EMAIL}} and password {{PASSWORD}}"

Variables are resolved from:
  1. An explicit secrets dict passed by the caller (from the dashboard
     secrets vault or the CLI config file)
  2. Environment variables (fallback)

After resolution the raw secret values are registered as "sensitive"
so that any function that needs to store/log goal text can redact them
back to "***" before writing.

Usage:
    resolver = SecretResolver(secrets={"EMAIL": "user@acme.com", "PASSWORD": "s3cr3t"})
    resolved_goal = resolver.resolve("Login with {{EMAIL}} / {{PASSWORD}}")
    # → "Login with user@acme.com / s3cr3t"

    safe_goal = resolver.redact(resolved_goal)
    # → "Login with *** / ***"

    # or redact inline without a pre-resolved string:
    safe_goal = resolver.redact_raw("Login with {{EMAIL}} / {{PASSWORD}}")
    # → "Login with *** / ***"
"""

from __future__ import annotations

import logging
import os
import re

logger = logging.getLogger("fusiontest.secrets")

# Matches {{ VAR_NAME }} with optional whitespace inside braces.
_TEMPLATE_RE = re.compile(r"\{\{\s*([A-Za-z_][A-Za-z0-9_]*)\s*\}\}")

# Minimum length for a value to be treated as sensitive (avoids redacting
# short common words like "id" or "en").
_MIN_SECRET_LEN = 4


class SecretResolver:
    """
    Resolves {{VAR}} placeholders in goal strings and tracks which
    concrete values are sensitive so they can be redacted before storage.
    """

    def __init__(self, secrets: dict[str, str] | None = None):
        # Explicit secrets take precedence over env vars.
        self._secrets: dict[str, str] = dict(secrets or {})
        # Set of raw secret *values* seen so we can redact them later.
        self._sensitive: set[str] = set()
        # Variable names that could not be resolved.
        self._unresolved: set[str] = set()

    # ── Public API ─────────────────────────────────────────────────────────────

    def resolve(self, text: str) -> str:
        """
        Replace every {{VAR}} in *text* with its secret value.
        Unknown variables are left as-is and tracked for later validation.
        Call unresolved_vars() after resolving all goals to get the full list.
        """
        def _replace(m: re.Match) -> str:
            var = m.group(1)
            value = self._lookup(var)
            if value is None:
                self._unresolved.add(var)
                return m.group(0)
            if len(value) >= _MIN_SECRET_LEN:
                self._sensitive.add(value)
            return value

        return _TEMPLATE_RE.sub(_replace, text)

    @property
    def unresolved_vars(self) -> frozenset[str]:
        """Variable names that appeared in goals but had no matching secret/env var."""
        return frozenset(self._unresolved)

    def redact(self, text: str) -> str:
        """
        Replace every resolved secret value in *text* with '***'.
        Call this before writing any goal text to logs or the database.
        """
        result = text
        for secret in sorted(self._sensitive, key=len, reverse=True):
            # Longest-first replacement avoids partial matches.
            result = result.replace(secret, "***")
        return result

    def redact_raw(self, text: str) -> str:
        """Resolve then immediately redact — convenience for storage paths."""
        return self.redact(self.resolve(text))

    def has_templates(self, text: str) -> bool:
        """True if *text* contains any {{VAR}} placeholders."""
        return bool(_TEMPLATE_RE.search(text))

    def add_secret(self, name: str, value: str) -> None:
        """Register an additional secret at runtime."""
        self._secrets[name] = value
        if len(value) >= _MIN_SECRET_LEN:
            self._sensitive.add(value)

    @property
    def sensitive_values(self) -> frozenset[str]:
        return frozenset(self._sensitive)

    # ── Internal ───────────────────────────────────────────────────────────────

    def _lookup(self, var: str) -> str | None:
        if var in self._secrets:
            return self._secrets[var]
        env_val = os.environ.get(var)
        if env_val is not None:
            return env_val
        # Try common prefixes: FT_EMAIL → EMAIL
        for prefix in ("FT_", "FUSIONTEST_"):
            env_val = os.environ.get(f"{prefix}{var}")
            if env_val is not None:
                return env_val
        return None


# ── Module-level convenience ───────────────────────────────────────────────────

def resolve_goals(
    goals: list[str],
    secrets: dict[str, str] | None = None,
) -> tuple[list[str], SecretResolver]:
    """
    Resolve {{VAR}} placeholders in a list of goal strings.

    Returns (resolved_goals, resolver).  The resolver can be used
    afterwards to redact values before storage:

        resolved, resolver = resolve_goals(goals, secrets)
        safe_goals = [resolver.redact(g) for g in resolved]
    """
    resolver = SecretResolver(secrets=secrets)
    resolved = [resolver.resolve(g) for g in goals]
    return resolved, resolver
