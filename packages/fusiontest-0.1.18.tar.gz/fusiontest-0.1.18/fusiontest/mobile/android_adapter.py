"""
fusiontest/mobile/android_adapter.py

Android adapter for FusionTest using Appium + UIAutomator2.
Handles device control, accessibility tree extraction,
and action execution for Android apps.
"""

from __future__ import annotations

import logging
import time

from fusiontest.core.action_model import Action
from fusiontest.core.screen_parser import ScreenParser, UIElement

logger = logging.getLogger("fusiontest.mobile.android")


class AndroidAdapter:
    """
    Controls an Android device or emulator via Appium.

    Usage:
        adapter = AndroidAdapter(desired_caps={...})
        adapter.start()
        elements, screen_text = adapter.get_screen()
        adapter.execute(action, elements)
        adapter.stop()
    """

    DEFAULT_CAPS = {
        "platformName": "Android",
        "automationName": "UiAutomator2",
        "newCommandTimeout": 300,
        "noReset": True,
    }

    def __init__(
        self,
        appium_url: str = "http://localhost:4723",
        desired_caps: dict | None = None,
        app_path: str | None = None,
        device_name: str | None = None,
        platform_version: str | None = None,
    ):
        self.appium_url = appium_url
        self.caps = {**self.DEFAULT_CAPS, **(desired_caps or {})}
        if app_path:
            self.caps["app"] = app_path
        if device_name:
            self.caps["deviceName"] = device_name
        if platform_version:
            self.caps["platformVersion"] = platform_version

        self._driver = None
        self._parser = ScreenParser()

    # ── Lifecycle ──────────────────────────────────────────────────────────────

    def start(self) -> None:
        try:
            from appium import webdriver
            from appium.options import AppiumOptions
        except ImportError as err:
            raise RuntimeError(
                "Android adapter requires Appium client: pip install Appium-Python-Client"
            ) from err

        options = AppiumOptions().load_capabilities(self.caps)
        self._driver = webdriver.Remote(self.appium_url, options=options)
        logger.info(f"AndroidAdapter connected to Appium at {self.appium_url}")

    def stop(self) -> None:
        if self._driver:
            self._driver.quit()
            self._driver = None
        logger.info("AndroidAdapter stopped")

    # ── Screen reading ─────────────────────────────────────────────────────────

    def get_screen(self) -> tuple[list[UIElement], str]:
        """Extract and parse the current screen's accessibility tree."""
        page_source = self._driver.page_source
        import xml.etree.ElementTree as ET

        root = ET.fromstring(page_source)
        tree_dict = self._xml_to_dict(root)
        elements, screen_text = self._parser.parse(tree_dict, platform="android")
        return elements, screen_text

    def get_screenshot(self) -> bytes:
        return self._driver.get_screenshot_as_png()

    def _xml_to_dict(self, node) -> dict:
        """Convert an Appium XML page source node to a dict for ScreenParser."""
        d = dict(node.attrib)
        children = [self._xml_to_dict(c) for c in node]
        if children:
            d["children"] = children
        return d

    # ── Action execution ───────────────────────────────────────────────────────

    def execute(self, action: Action, elements: list[UIElement]) -> bool:
        """Execute an action on the device. Returns True on success."""
        try:
            if action.action_type == "tap":
                self._tap(action, elements)
            elif action.action_type == "type":
                self._type(action, elements)
            elif action.action_type == "scroll":
                self._scroll(action)
            elif action.action_type == "swipe":
                self._swipe(action)
            elif action.action_type == "back":
                self._driver.back()
            elif action.action_type == "home":
                self._driver.press_keycode(3)  # KEYCODE_HOME
            elif action.action_type == "wait":
                secs = float(action.value) if action.value else 1.5
                time.sleep(secs)
            elif action.action_type == "toggle":
                self._tap(action, elements)  # toggles are taps

            time.sleep(0.8)  # brief settle after every action
            return True

        except Exception as e:
            logger.warning(f"Action failed: {action} — {e}")
            return False

    def _tap(self, action: Action, elements: list[UIElement]) -> None:
        element = self._find_element(action, elements)
        if element:
            element.click()
        else:
            raise ValueError(f"Element not found for action: {action}")

    def _type(self, action: Action, elements: list[UIElement]) -> None:
        element = self._find_element(action, elements)
        if element:
            element.clear()
            element.send_keys(action.value)
        else:
            raise ValueError(f"Element not found for type action: {action}")

    def _scroll(self, action: Action) -> None:
        direction = action.value.lower() if action.value else "down"
        size = self._driver.get_window_size()
        cx = size["width"] // 2
        if direction == "down":
            self._driver.swipe(cx, int(size["height"] * 0.7), cx, int(size["height"] * 0.3), 600)
        else:
            self._driver.swipe(cx, int(size["height"] * 0.3), cx, int(size["height"] * 0.7), 600)

    def _swipe(self, action: Action) -> None:
        direction = action.value.lower() if action.value else "left"
        size = self._driver.get_window_size()
        cx, cy = size["width"] // 2, size["height"] // 2
        offsets = {
            "left": (int(size["width"] * 0.8), cy, int(size["width"] * 0.2), cy),
            "right": (int(size["width"] * 0.2), cy, int(size["width"] * 0.8), cy),
            "up": (cx, int(size["height"] * 0.8), cx, int(size["height"] * 0.2)),
            "down": (cx, int(size["height"] * 0.2), cx, int(size["height"] * 0.8)),
        }
        coords = offsets.get(direction, offsets["left"])
        self._driver.swipe(*coords, 400)

    def _find_element(self, action: Action, elements: list[UIElement]):
        """Find the native Appium element corresponding to an Action."""
        from appium.webdriver.common.appiumby import AppiumBy

        matching = [e for e in elements if e.index == action.element_index]
        if matching:
            raw = matching[0].raw
            bounds = raw.get("bounds", "")
            if bounds:
                # Use XPath to find by bounds (most reliable for UIAutomator2)
                try:
                    return self._driver.find_element(
                        AppiumBy.XPATH,
                        f'//*[@bounds="{bounds}"]',
                    )
                except Exception:
                    pass

        # Fallback to content description or text
        label = action.element_label.strip('"') if action.element_label else ""
        if label:
            for strategy in (
                (AppiumBy.ACCESSIBILITY_ID, label),
                (AppiumBy.ANDROID_UIAUTOMATOR, f'new UiSelector().text("{label}")'),
                (AppiumBy.ANDROID_UIAUTOMATOR, f'new UiSelector().description("{label}")'),
            ):
                try:
                    return self._driver.find_element(*strategy)
                except Exception:
                    continue

        return None
