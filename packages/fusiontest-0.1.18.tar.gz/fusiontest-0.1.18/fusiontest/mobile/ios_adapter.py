"""
fusiontest/mobile/ios_adapter.py

iOS adapter for FusionTest using Appium + XCUITest.
Handles device/simulator control, accessibility tree extraction,
and action execution for iOS apps.
"""

from __future__ import annotations

import logging
import time

from fusiontest.core.action_model import Action
from fusiontest.core.screen_parser import ScreenParser, UIElement

logger = logging.getLogger("fusiontest.mobile.ios")


class IOSAdapter:
    """
    Controls an iOS device or simulator via Appium + XCUITest.

    Usage:
        adapter = IOSAdapter(desired_caps={
            "deviceName": "iPhone 15",
            "platformVersion": "17.0",
            "app": "/path/to/MyApp.ipa",
            "udid": "auto",   # or specific UDID
        })
        adapter.start()
        elements, screen_text = adapter.get_screen()
        adapter.execute(action, elements)
        adapter.stop()
    """

    DEFAULT_CAPS = {
        "platformName": "iOS",
        "automationName": "XCUITest",
        "newCommandTimeout": 300,
        "noReset": True,
        "wdaLaunchTimeout": 60000,
        "wdaConnectionTimeout": 60000,
    }

    def __init__(
        self,
        appium_url: str = "http://localhost:4723",
        desired_caps: dict | None = None,
        app_path: str | None = None,
        device_name: str | None = None,
        platform_version: str | None = None,
        udid: str | None = None,
    ):
        self.appium_url = appium_url
        self.caps = {**self.DEFAULT_CAPS, **(desired_caps or {})}
        if app_path:
            self.caps["app"] = app_path
        if device_name:
            self.caps["deviceName"] = device_name
        if platform_version:
            self.caps["platformVersion"] = platform_version
        if udid:
            self.caps["udid"] = udid

        self._driver = None
        self._parser = ScreenParser()

    # ── Lifecycle ──────────────────────────────────────────────────────────────

    def start(self) -> None:
        try:
            from appium import webdriver
            from appium.options import AppiumOptions
        except ImportError as err:
            raise RuntimeError(
                "iOS adapter requires Appium client: pip install Appium-Python-Client"
            ) from err

        options = AppiumOptions().load_capabilities(self.caps)
        self._driver = webdriver.Remote(self.appium_url, options=options)
        logger.info(f"IOSAdapter connected to Appium at {self.appium_url}")

    def stop(self) -> None:
        if self._driver:
            self._driver.quit()
            self._driver = None
        logger.info("IOSAdapter stopped")

    # ── Screen reading ─────────────────────────────────────────────────────────

    def get_screen(self) -> tuple[list[UIElement], str]:
        """Extract and parse the current screen from XCUITest accessibility tree."""
        page_source = self._driver.page_source
        import xml.etree.ElementTree as ET

        root = ET.fromstring(page_source)
        tree_dict = self._xml_to_dict(root)
        elements, screen_text = self._parser.parse(tree_dict, platform="ios")
        return elements, screen_text

    def get_screenshot(self) -> bytes:
        return self._driver.get_screenshot_as_png()

    def _xml_to_dict(self, node) -> dict:
        """
        Convert XCUITest XML page source to a dict.
        XCUITest uses 'type', 'name', 'label', 'value', 'visible', 'enabled', 'x', 'y', 'width', 'height'.
        """
        attrib = dict(node.attrib)
        # Build a rect dict from XCUITest x/y/width/height attributes
        try:
            attrib["rect"] = {
                "x": int(attrib.pop("x", 0)),
                "y": int(attrib.pop("y", 0)),
                "width": int(attrib.pop("width", 0)),
                "height": int(attrib.pop("height", 0)),
            }
        except (ValueError, KeyError):
            attrib["rect"] = {}

        # Normalize booleans
        attrib["enabled"] = attrib.get("enabled", "true").lower() == "true"
        attrib["visible"] = attrib.get("visible", "true").lower() == "true"

        children = [self._xml_to_dict(c) for c in node]
        if children:
            attrib["children"] = children
        return attrib

    # ── Action execution ───────────────────────────────────────────────────────

    def execute(self, action: Action, elements: list[UIElement]) -> bool:
        """Execute an action on the iOS device/simulator. Returns True on success."""
        try:
            if action.action_type == "tap":
                self._tap(action, elements)
            elif action.action_type == "type":
                self._type(action, elements)
            elif action.action_type == "scroll":
                self._scroll(action)
            elif action.action_type == "swipe":
                self._swipe(action)
            elif action.action_type == "back":
                # iOS has no universal back — try tapping a "Back" button
                self._tap_back_button()
            elif action.action_type == "home":
                self._driver.execute_script("mobile: pressButton", {"name": "home"})
            elif action.action_type == "wait":
                secs = float(action.value) if action.value else 1.5
                time.sleep(secs)
            elif action.action_type == "toggle":
                self._tap(action, elements)

            time.sleep(0.8)
            return True

        except Exception as e:
            logger.warning(f"Action failed: {action} — {e}")
            return False

    def _tap(self, action: Action, elements: list[UIElement]) -> None:
        element = self._find_element(action, elements)
        if element:
            element.click()
        else:
            raise ValueError(f"Element not found for tap: {action}")

    def _type(self, action: Action, elements: list[UIElement]) -> None:
        element = self._find_element(action, elements)
        if element:
            element.click()
            element.clear()
            element.send_keys(action.value)
        else:
            raise ValueError(f"Element not found for type: {action}")

    def _scroll(self, action: Action) -> None:
        direction = action.value.lower() if action.value else "down"
        self._driver.execute_script("mobile: scroll", {"direction": direction})

    def _swipe(self, action: Action) -> None:
        direction = action.value.lower() if action.value else "left"
        size = self._driver.get_window_size()
        cx, cy = size["width"] // 2, size["height"] // 2

        offsets = {
            "left": (int(size["width"] * 0.8), cy, int(size["width"] * 0.2), cy),
            "right": (int(size["width"] * 0.2), cy, int(size["width"] * 0.8), cy),
            "up": (cx, int(size["height"] * 0.75), cx, int(size["height"] * 0.25)),
            "down": (cx, int(size["height"] * 0.25), cx, int(size["height"] * 0.75)),
        }
        x1, y1, x2, y2 = offsets.get(direction, offsets["left"])

        self._driver.execute_script("mobile: dragFromToForDuration", {
            "fromX": x1, "fromY": y1,
            "toX": x2, "toY": y2,
            "duration": 0.4,
        })

    def _tap_back_button(self) -> None:
        """Try to tap a Back navigation button — common iOS pattern."""
        from appium.webdriver.common.appiumby import AppiumBy
        for strategy, value in [
            (AppiumBy.ACCESSIBILITY_ID, "Back"),
            (AppiumBy.XPATH, '//XCUIElementTypeButton[@name="Back"]'),
            (AppiumBy.XPATH, '//XCUIElementTypeNavigationBar/XCUIElementTypeButton[1]'),
        ]:
            try:
                el = self._driver.find_element(strategy, value)
                el.click()
                return
            except Exception:
                continue
        logger.warning("Could not find Back button on iOS screen")

    def _find_element(self, action: Action, elements: list[UIElement]):
        """Find the native Appium element for a given Action."""
        from appium.webdriver.common.appiumby import AppiumBy

        # Try matching by rect from raw element data
        matching = [e for e in elements if e.index == action.element_index]
        if matching:
            rect = matching[0].rect
            rect.get("x", 0)
            rect.get("y", 0)
            label = matching[0].label
            elem_type = matching[0].element_type

            if label:
                xcui_type = _fusiontest_type_to_xcui(elem_type)
                for strategy, value in [
                    (AppiumBy.ACCESSIBILITY_ID, label),
                    (AppiumBy.XPATH, f'//{xcui_type}[@label="{label}"]'),
                    (AppiumBy.XPATH, f'//{xcui_type}[@name="{label}"]'),
                ]:
                    try:
                        return self._driver.find_element(strategy, value)
                    except Exception:
                        continue

        # Fallback: accessibility ID from action label
        label = action.element_label.strip('"') if action.element_label else ""
        if label:
            try:
                return self._driver.find_element(AppiumBy.ACCESSIBILITY_ID, label)
            except Exception:
                pass

        return None


def _fusiontest_type_to_xcui(element_type: str) -> str:
    mapping = {
        "button": "XCUIElementTypeButton",
        "text_field": "XCUIElementTypeTextField",
        "text_area": "XCUIElementTypeTextView",
        "switch": "XCUIElementTypeSwitch",
        "static_text": "XCUIElementTypeStaticText",
        "list_item": "XCUIElementTypeCell",
        "tab": "XCUIElementTypeTab",
        "slider": "XCUIElementTypeSlider",
        "search_field": "XCUIElementTypeSearchField",
        "link": "XCUIElementTypeLink",
    }
    return mapping.get(element_type, "XCUIElementTypeAny")
