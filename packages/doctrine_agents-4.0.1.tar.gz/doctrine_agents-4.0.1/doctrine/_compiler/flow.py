from __future__ import annotations

from doctrine import model
from doctrine._compiler.diagnostics import compile_error, related_prompt_site
from doctrine._compiler.indexing import unit_declarations
from doctrine._compiler.constants import (
    _ADDRESSABLE_ROOT_REGISTRIES,
    _BUILTIN_INPUT_SOURCES,
    _BUILTIN_OUTPUT_TARGETS,
    _BUILTIN_RENDER_PROFILE_NAMES,
    _INTERPOLATION_EXPR_RE,
    _INTERPOLATION_RE,
    _READABLE_DECL_REGISTRIES,
    _RESERVED_AGENT_FIELD_KEYS,
    _REVIEW_CONTRACT_FACT_KEYS,
    _REVIEW_GUARD_FIELD_NAMES,
    _REVIEW_OPTIONAL_FIELD_NAMES,
    _REVIEW_REQUIRED_FIELD_NAMES,
    _REVIEW_VERDICT_TEXT,
    _SCHEMA_FAMILY_TITLES,
    _resolve_render_profile_mode,
    _semantic_render_target_for_block,
)
from doctrine._compiler.naming import (
    _authored_slot_allows_law,
    _display_addressable_ref,
    _dotted_ref_name,
    _humanize_key,
    _law_path_from_name_ref,
    _lowercase_initial,
    _name_ref_from_dotted_name,
)
from doctrine._compiler.workflow_diagnostics import workflow_compile_error
from doctrine._compiler.resolved_types import (
    AgentContract,
    ConfigSpec,
    FlowAgentKey,
    FlowAgentNode,
    FlowArtifactKey,
    FlowEdge,
    FlowGraph,
    FlowInputNode,
    FlowOutputNode,
    IndexedUnit,
    LawBranch,
    ResolvedAgentSlot,
    ResolvedLawPath,
    ResolvedRouteLine,
    ResolvedSchemaGroup,
    ResolvedSectionBodyItem,
    ResolvedSectionItem,
    ResolvedOutputTargetSpec,
    ResolvedWorkflowBody,
    ResolvedWorkflowSkillsItem,
    ResolvedUseItem,
)
from doctrine._compiler.support_files import _default_worker_count, _dotted_decl_name


def _source_span(value: object | None) -> model.SourceSpan | None:
    return getattr(value, "source_span", None)


class FlowMixin:
    """Flow extraction helper owner for CompilationContext."""

    def extract_target_flow_graph(self, agent_names: tuple[str, ...]) -> FlowGraph:
        root_agents: list[tuple[IndexedUnit, str]] = []
        for agent_name in agent_names:
            agent = self.root_flow.agents_by_name.get(agent_name)
            if agent is None:
                root_agents.append((self.root_entrypoint_unit, agent_name))
                continue
            owner_unit = self.root_flow.declaration_owner_units_by_id[id(agent)]
            root_agents.append((owner_unit, agent_name))
        return self.extract_target_flow_graph_from_units(
            tuple(root_agents)
        )

    def extract_target_flow_graph_from_units(
        self,
        agent_roots: tuple[tuple[IndexedUnit, str], ...],
    ) -> FlowGraph:
        root_agents: list[tuple[IndexedUnit, model.Agent]] = []
        for unit, agent_name in agent_roots:
            agent = unit_declarations(unit).agents_by_name.get(agent_name)
            if agent is None:
                module_label = (
                    "the root prompt file"
                    if not unit.module_parts
                    else f"prompt module `{'.'.join(unit.module_parts)}`"
                )
                raise compile_error(
                    code="E201",
                    summary="Missing target agent",
                    detail=(
                        f"Target agent `{agent_name}` does not exist in {module_label}."
                    ),
                    path=unit.prompt_file.source_path,
                )
            if agent.abstract:
                raise compile_error(
                    code="E202",
                    summary="Abstract agent does not render",
                    detail=(
                        f"Agent `{agent_name}` is marked abstract and cannot render "
                        "output directly."
                    ),
                    path=unit.prompt_file.source_path,
                    hints=("Render a concrete child agent instead.",),
                )
            root_agents.append((unit, agent))

        agent_nodes: dict[FlowAgentKey, FlowAgentNode] = {}
        input_nodes: dict[FlowArtifactKey, FlowInputNode] = {}
        output_nodes: dict[FlowArtifactKey, FlowOutputNode] = {}
        agent_notes: dict[FlowAgentKey, list[str]] = {}
        input_notes: dict[FlowArtifactKey, list[str]] = {}
        output_notes: dict[FlowArtifactKey, list[str]] = {}
        edges: dict[tuple[object, ...], FlowEdge] = {}

        for unit, agent in root_agents:
            agent_key = self._flow_agent_key(unit, agent.name)
            self._flow_upsert_agent_node(agent_nodes, agent, unit=unit)

            agent_contract = self._resolve_agent_contract(agent, unit=unit)
            resolved_slot_states = self._resolve_agent_slots(agent, unit=unit)
            resolved_slots = {
                slot.key: slot.body
                for slot in resolved_slot_states
                if isinstance(slot, ResolvedAgentSlot)
            }
            self._validate_agent_slot_laws(
                agent,
                unit=unit,
                resolved_slots=resolved_slots,
                agent_contract=agent_contract,
            )
            review_output_contexts = self._review_output_contexts_for_agent(agent, unit=unit)
            primary_review_output_context = self._primary_review_output_context(
                review_output_contexts
            )
            final_output_key: OutputDeclKey | None = None
            for field in agent.fields:
                if not isinstance(field, model.FinalOutputField):
                    continue
                final_output_unit, final_output_decl = self._resolve_final_output_decl(
                    field.value,
                    unit=unit,
                    owner_label=f"agent {agent.name} final_output",
                    source_span=field.source_span,
                )
                final_output_key = (
                    final_output_unit.module_parts,
                    final_output_decl.name,
                )
                break
            _ = self._route_semantic_context_for_agent(
                agent,
                unit=unit,
                resolved_slots=resolved_slots,
                agent_contract=agent_contract,
            )
            route_output_contexts = self._route_output_contexts_for_agent(
                agent,
                unit=unit,
                resolved_slots=resolved_slots,
                agent_contract=agent_contract,
            )
            self._collect_flow_from_review_route_context(
                agent_unit=unit,
                agent=agent,
                agent_contract=agent_contract,
                agent_nodes=agent_nodes,
                edges=edges,
            )
            self._collect_flow_from_final_output_route_contexts(
                agent_unit=unit,
                agent=agent,
                route_output_contexts=route_output_contexts,
                agent_nodes=agent_nodes,
                edges=edges,
            )
            for input_key, (input_unit, input_decl) in sorted(agent_contract.inputs.items()):
                self._flow_upsert_input_node(input_nodes, input_decl, unit=input_unit)
                self._flow_add_edge(
                    edges,
                    FlowEdge(
                        kind="consume",
                        source_kind="input",
                        source_module_parts=input_key[0],
                        source_name=input_key[1],
                        target_kind="agent",
                        target_module_parts=unit.module_parts,
                        target_name=agent_key[2],
                        label="consumes",
                        source_prompt_root=self._flow_identity(input_unit)[0],
                        source_flow_root=self._flow_identity(input_unit)[1],
                        target_prompt_root=agent_key[0],
                        target_flow_root=agent_key[1],
                    ),
                )

            for output_key, (output_unit, output_decl) in sorted(agent_contract.outputs.items()):
                review_semantics = self._flow_review_semantics_for_output(
                    output_key,
                    review_output_contexts=review_output_contexts,
                    primary_review_output_context=primary_review_output_context,
                    final_output_key=final_output_key,
                )
                self._flow_upsert_output_node(
                    output_nodes,
                    output_decl,
                    unit=output_unit,
                    review_semantics=review_semantics,
                    route_semantics=self._route_output_context_for_key(
                        route_output_contexts,
                        output_key,
                    ),
                )
                self._flow_add_edge(
                    edges,
                    FlowEdge(
                        kind="produce",
                        source_kind="agent",
                        source_module_parts=unit.module_parts,
                        source_name=agent_key[2],
                        target_kind="output",
                        target_module_parts=output_key[0],
                        target_name=output_key[1],
                        label="produces",
                        source_prompt_root=agent_key[0],
                        source_flow_root=agent_key[1],
                        target_prompt_root=self._flow_identity(output_unit)[0],
                        target_flow_root=self._flow_identity(output_unit)[1],
                    ),
                )

            for slot_state in resolved_slot_states:
                if not isinstance(slot_state, ResolvedAgentSlot):
                    continue
                self._collect_flow_from_workflow_body(
                    slot_state.body,
                    workflow_unit=unit,
                    agent_unit=unit,
                    agent=agent,
                    agent_contract=agent_contract,
                    agent_nodes=agent_nodes,
                    agent_notes=agent_notes,
                    input_notes=input_notes,
                    output_nodes=output_nodes,
                    output_notes=output_notes,
                    edges=edges,
                    owner_label=f"agent {agent.name} slot {slot_state.key}",
                    slot_key=slot_state.key,
                    review_output_contexts=review_output_contexts,
                    primary_review_output_context=primary_review_output_context,
                    final_output_key=final_output_key,
                    route_output_contexts=route_output_contexts,
                    workflow_stack=(),
                )

        # Preserve first-seen flow order so the renderer can recover the routed
        # handoff lane instead of receiving an alphabetized graph.
        return FlowGraph(
            agents=tuple(
                FlowAgentNode(
                    module_parts=node.module_parts,
                    name=node.name,
                    title=node.title,
                    prompt_root=node.prompt_root,
                    flow_root=node.flow_root,
                    detail_lines=node.detail_lines,
                    notes=tuple(
                        agent_notes.get(
                            (node.prompt_root, node.flow_root, node.name),
                            (),
                        )
                    ),
                )
                for node in agent_nodes.values()
            ),
            inputs=tuple(
                FlowInputNode(
                    module_parts=node.module_parts,
                    name=node.name,
                    title=node.title,
                    prompt_root=node.prompt_root,
                    flow_root=node.flow_root,
                    source_title=node.source_title,
                    shape_title=node.shape_title,
                    requirement_title=node.requirement_title,
                    detail_lines=node.detail_lines,
                    notes=tuple(
                        input_notes.get(
                            (node.prompt_root, node.flow_root, node.name),
                            (),
                        )
                    ),
                )
                for node in input_nodes.values()
            ),
            outputs=tuple(
                FlowOutputNode(
                    module_parts=node.module_parts,
                    name=node.name,
                    title=node.title,
                    prompt_root=node.prompt_root,
                    flow_root=node.flow_root,
                    target_title=node.target_title,
                    primary_path=node.primary_path,
                    shape_title=node.shape_title,
                    requirement_title=node.requirement_title,
                    detail_lines=node.detail_lines,
                    trust_surface=node.trust_surface,
                    notes=tuple(
                        output_notes.get(
                            (node.prompt_root, node.flow_root, node.name),
                            (),
                        )
                    ),
                )
                for node in output_nodes.values()
            ),
            edges=tuple(edges.values()),
        )

    def _collect_flow_from_workflow_body(
        self,
        workflow_body: ResolvedWorkflowBody,
        *,
        workflow_unit: IndexedUnit,
        agent_unit: IndexedUnit,
        agent: model.Agent,
        agent_contract: AgentContract,
        agent_nodes: dict[FlowAgentKey, FlowAgentNode],
        agent_notes: dict[FlowAgentKey, list[str]],
        input_notes: dict[FlowArtifactKey, list[str]],
        output_nodes: dict[FlowArtifactKey, FlowOutputNode],
        output_notes: dict[FlowArtifactKey, list[str]],
        edges: dict[tuple[object, ...], FlowEdge],
        owner_label: str,
        slot_key: str,
        review_output_contexts: frozenset[tuple[OutputDeclKey, ReviewSemanticContext]],
        primary_review_output_context: tuple[OutputDeclKey, ReviewSemanticContext] | None,
        final_output_key: OutputDeclKey | None,
        route_output_contexts: frozenset[tuple[OutputDeclKey, RouteSemanticContext]],
        workflow_stack: tuple[tuple[tuple[str, ...], str], ...],
    ) -> None:
        agent_key = self._flow_agent_key(agent_unit, agent.name)

        for item in workflow_body.items:
            if isinstance(item, ResolvedSectionItem):
                self._collect_flow_from_section_items(
                    item.items,
                    agent_unit=agent_unit,
                    agent_key=agent_key,
                    agent_nodes=agent_nodes,
                    edges=edges,
                )
                continue
            if isinstance(item, ResolvedWorkflowSkillsItem):
                continue
            if isinstance(item, model.ReadableBlock):
                continue
            if not isinstance(item, ResolvedUseItem):
                raise workflow_compile_error(
                    code="E299",
                    summary="Compile failure",
                    detail=(
                        f"Flow extraction found an unsupported workflow item in "
                        f"{owner_label}: {type(item).__name__}"
                    ),
                    unit=workflow_unit,
                    source_span=_source_span(item),
                )

            workflow_key = (item.target_unit.module_parts, item.workflow_decl.name)
            if workflow_key in workflow_stack:
                cycle = " -> ".join(
                    ".".join(parts + (name,)) or name
                    for parts, name in [*workflow_stack, workflow_key]
                )
                raise workflow_compile_error(
                    code="E283",
                    summary="Cyclic workflow composition",
                    detail=f"Workflow composition cycle: {cycle}.",
                    unit=item.target_unit,
                    source_span=item.workflow_decl.source_span,
                )

            self._collect_flow_from_workflow_body(
                self._resolve_workflow_decl(item.workflow_decl, unit=item.target_unit),
                workflow_unit=item.target_unit,
                agent_unit=agent_unit,
                agent=agent,
                agent_contract=agent_contract,
                agent_nodes=agent_nodes,
                agent_notes=agent_notes,
                input_notes=input_notes,
                output_nodes=output_nodes,
                output_notes=output_notes,
                edges=edges,
                owner_label=f"workflow {_dotted_decl_name(item.target_unit.module_parts, item.workflow_decl.name)}",
                slot_key=slot_key,
                review_output_contexts=review_output_contexts,
                primary_review_output_context=primary_review_output_context,
                final_output_key=final_output_key,
                route_output_contexts=route_output_contexts,
                workflow_stack=(*workflow_stack, workflow_key),
            )

        if workflow_body.law is None:
            return

        if not _authored_slot_allows_law(slot_key):
            raise workflow_compile_error(
                code="E345",
                summary="Law is not allowed on this authored slot",
                detail=(
                    f"`law:` is not allowed on authored slot `{slot_key}` in "
                    f"{owner_label}."
                ),
                unit=workflow_unit,
                source_span=workflow_body.law.source_span,
                hints=(
                    "Attach `law:` only to `workflow:` or `handoff_routing:`.",
                    "Keep other authored slots as readable instruction surfaces.",
                ),
            )
        flat_items = self._flatten_law_items(
            workflow_body.law,
            owner_label=owner_label,
            unit=workflow_unit,
        )
        if slot_key == "handoff_routing":
            self._validate_handoff_routing_law(
                flat_items,
                unit=workflow_unit,
                agent_contract=agent_contract,
                owner_label=owner_label,
            )
        else:
            self._validate_workflow_law(
                flat_items,
                unit=workflow_unit,
                agent_contract=agent_contract,
                owner_label=owner_label,
            )
        branches = self._collect_law_leaf_branches(flat_items, unit=workflow_unit)
        if not branches:
            branches = (LawBranch(),)

        for branch in branches:
            current = branch.current_subjects[0] if branch.current_subjects else None
            if isinstance(current, model.CurrentNoneStmt):
                self._flow_append_note(
                    agent_notes,
                    agent_key,
                    "May end with no current artifact",
                )
            elif isinstance(current, model.CurrentArtifactStmt):
                target = self._validate_law_path_root(
                    current.target,
                    unit=workflow_unit,
                    agent_contract=agent_contract,
                    owner_label=owner_label,
                    statement_label="current artifact",
                    allowed_kinds=("input", "output"),
                )
                if target.remainder or target.wildcard:
                    raise workflow_compile_error(
                        code="E299",
                        summary="Compile failure",
                        detail=(
                            "current artifact must stay rooted at one input or output "
                            f"artifact in {owner_label}: {'.'.join(current.target.parts)}"
                        ),
                        unit=workflow_unit,
                        source_span=current.source_span,
                    )
                carrier = self._validate_carrier_path(
                    current.carrier,
                    unit=workflow_unit,
                    agent_contract=agent_contract,
                    owner_label=owner_label,
                    statement_label="current artifact",
                )
                target_label = self._display_readable_decl(target.decl)
                carrier_label = self._flow_carrier_label(
                    carrier,
                    owner_label=owner_label,
                )
                self._flow_append_artifact_note(
                    input_notes=input_notes,
                    output_notes=output_notes,
                    resolved=target,
                    note=f"Current via {carrier_label}",
                )
                self._flow_append_note(
                    output_notes,
                    self._flow_artifact_key(carrier.unit, carrier.decl.name),
                    f"Carries current for {target_label}",
                )

            for invalidate in branch.invalidations:
                target = self._validate_law_path_root(
                    invalidate.target,
                    unit=workflow_unit,
                    agent_contract=agent_contract,
                    owner_label=owner_label,
                    statement_label="invalidate",
                    allowed_kinds=("input", "output", "schema_group"),
                )
                if target.remainder or target.wildcard:
                    raise workflow_compile_error(
                        code="E299",
                        summary="Compile failure",
                        detail=(
                            "invalidate must name one full input or output artifact or "
                            f"schema group in {owner_label}: "
                            f"{'.'.join(invalidate.target.parts)}"
                        ),
                        unit=workflow_unit,
                        source_span=invalidate.source_span or invalidate.target.source_span,
                    )
                carrier = self._validate_carrier_path(
                    invalidate.carrier,
                    unit=workflow_unit,
                    agent_contract=agent_contract,
                    owner_label=owner_label,
                    statement_label="invalidate",
                )
                carrier_label = self._flow_carrier_label(
                    carrier,
                    owner_label=owner_label,
                )
                if isinstance(target.decl, ResolvedSchemaGroup):
                    target_labels: list[str] = []
                    for member in self._schema_group_member_artifacts(target.decl, unit=target.unit):
                        target_labels.append(member.title)
                        self._flow_append_artifact_note(
                            input_notes=input_notes,
                            output_notes=output_notes,
                            resolved=ResolvedLawPath(
                                unit=member.artifact.unit,
                                decl=member.artifact.decl,
                                remainder=(),
                            ),
                            note=f"Invalidated via {carrier_label}",
                        )
                    target_label = ", ".join(target_labels) or target.decl.title
                else:
                    target_label = self._display_readable_decl(target.decl)
                    self._flow_append_artifact_note(
                        input_notes=input_notes,
                        output_notes=output_notes,
                        resolved=target,
                        note=f"Invalidated via {carrier_label}",
                    )
                self._flow_append_note(
                    output_notes,
                    self._flow_artifact_key(carrier.unit, carrier.decl.name),
                    f"Carries invalidation for {target_label}",
                )

            for route in branch.routes:
                route_label = self._interpolate_authored_prose_string(
                    route.label,
                    unit=workflow_unit,
                    owner_label=owner_label,
                    surface_label="route labels",
                )
                target_unit, target_agent = self._resolve_agent_ref(route.target, unit=workflow_unit)
                self._flow_upsert_agent_node(agent_nodes, target_agent, unit=target_unit)
                self._flow_add_edge(
                    edges,
                    FlowEdge(
                        kind="law_route",
                        source_kind="agent",
                        source_module_parts=agent_unit.module_parts,
                        source_name=agent.name,
                        target_kind="agent",
                        target_module_parts=target_unit.module_parts,
                        target_name=target_agent.name,
                        label=route_label,
                        source_prompt_root=agent_key[0],
                        source_flow_root=agent_key[1],
                        target_prompt_root=self._flow_identity(target_unit)[0],
                        target_flow_root=self._flow_identity(target_unit)[1],
                    ),
                )

        for output_key, (output_unit, output_decl) in sorted(agent_contract.outputs.items()):
            if output_key not in output_nodes:
                review_semantics = self._flow_review_semantics_for_output(
                    output_key,
                    review_output_contexts=review_output_contexts,
                    primary_review_output_context=primary_review_output_context,
                    final_output_key=final_output_key,
                )
                self._flow_upsert_output_node(
                    output_nodes,
                    output_decl,
                    unit=output_unit,
                    review_semantics=review_semantics,
                    route_semantics=self._route_output_context_for_key(
                        route_output_contexts,
                        output_key,
                    ),
                )

    def _collect_flow_from_final_output_route_contexts(
        self,
        *,
        agent_unit: IndexedUnit,
        agent: model.Agent,
        route_output_contexts: frozenset[tuple[OutputDeclKey, RouteSemanticContext]],
        agent_nodes: dict[FlowAgentKey, FlowAgentNode],
        edges: dict[tuple[object, ...], FlowEdge],
    ) -> None:
        for _output_key, route_context in sorted(route_output_contexts, key=lambda item: item[0]):
            selector = route_context.selector
            if selector is None or selector.surface != "final_output":
                continue
            self._collect_flow_from_authored_route_context(
                agent_unit=agent_unit,
                agent=agent,
                route_context=route_context,
                owner_label=f"agent {agent.name} final_output.route",
                agent_nodes=agent_nodes,
                edges=edges,
            )

    def _collect_flow_from_review_route_context(
        self,
        *,
        agent_unit: IndexedUnit,
        agent: model.Agent,
        agent_contract: AgentContract,
        agent_nodes: dict[FlowAgentKey, FlowAgentNode],
        edges: dict[tuple[object, ...], FlowEdge],
    ) -> None:
        review_field = next(
            (field for field in agent.fields if isinstance(field, model.ReviewField)),
            None,
        )
        if review_field is None:
            return

        review_unit, review_decl = self._resolve_review_ref(review_field.value, unit=agent_unit)
        self._ensure_concrete_review_decl(
            review_decl,
            unit=review_unit,
            owner_unit=agent_unit,
            attached_review_span=review_field.source_span,
        )
        route_context = self._route_semantic_context_from_review_decl(
            review_decl,
            unit=review_unit,
            agent_contract=agent_contract,
            owner_label=f"agent {agent.name} review",
        )
        if route_context is None:
            return

        self._collect_flow_from_authored_route_context(
            agent_unit=agent_unit,
            agent=agent,
            route_context=route_context,
            owner_label=f"agent {agent.name} review",
            agent_nodes=agent_nodes,
            edges=edges,
        )

    def _collect_flow_from_authored_route_context(
        self,
        *,
        agent_unit: IndexedUnit,
        agent: model.Agent,
        route_context: RouteSemanticContext,
        owner_label: str,
        agent_nodes: dict[FlowAgentKey, FlowAgentNode],
        edges: dict[tuple[object, ...], FlowEdge],
    ) -> None:
        agent_key = self._flow_agent_key(agent_unit, agent.name)
        for branch in route_context.branches:
            if branch.target_module_parts:
                target_unit = self._load_module(branch.target_module_parts)
                target_agent = unit_declarations(target_unit).agents_by_name.get(
                    branch.target_name
                )
            else:
                target_agent = self.session.flow_for_unit(agent_unit).agents_by_name.get(
                    branch.target_name
                )
                target_unit = (
                    agent_unit
                    if target_agent is None
                    else self.session.flow_for_unit(agent_unit).declaration_owner_units_by_id[
                        id(target_agent)
                    ]
                )
            if target_agent is None:
                raise compile_error(
                    code="E299",
                    summary="Compile failure",
                    detail=(
                        f"{owner_label} points at a missing target agent in "
                        f"agent `{agent.name}`: "
                        f"{_dotted_decl_name(branch.target_module_parts, branch.target_name)}"
                    ),
                    path=agent_unit.prompt_file.source_path,
                )
            self._flow_upsert_agent_node(agent_nodes, target_agent, unit=target_unit)
            self._flow_add_edge(
                edges,
                FlowEdge(
                    kind="authored_route",
                    source_kind="agent",
                    source_module_parts=agent_unit.module_parts,
                    source_name=agent.name,
                    target_kind="agent",
                    target_module_parts=target_unit.module_parts,
                    target_name=target_agent.name,
                    label=branch.label,
                    source_prompt_root=agent_key[0],
                    source_flow_root=agent_key[1],
                    target_prompt_root=self._flow_identity(target_unit)[0],
                    target_flow_root=self._flow_identity(target_unit)[1],
                ),
            )

    def _collect_flow_from_section_items(
        self,
        items: tuple[ResolvedSectionBodyItem, ...],
        *,
        agent_unit: IndexedUnit,
        agent_key: FlowAgentKey,
        agent_nodes: dict[FlowAgentKey, FlowAgentNode],
        edges: dict[tuple[object, ...], FlowEdge],
    ) -> None:
        for item in items:
            if isinstance(item, ResolvedSectionItem):
                self._collect_flow_from_section_items(
                    item.items,
                    agent_unit=agent_unit,
                    agent_key=agent_key,
                    agent_nodes=agent_nodes,
                    edges=edges,
                )
                continue
            if not isinstance(item, ResolvedRouteLine):
                continue
            if item.target_module_parts:
                target_unit = self._load_module(item.target_module_parts)
                target_agent = unit_declarations(target_unit).agents_by_name.get(
                    item.target_name
                )
                target_prompt_root, target_flow_root = self._flow_identity(target_unit)
            else:
                current_flow = self.session.flow_by_key(agent_key[0], agent_key[1])
                if current_flow is None:
                    raise compile_error(
                        code="E901",
                        summary="Internal compiler error",
                        detail=(
                            "Internal compiler error: missing current flow during flow extraction."
                        ),
                        path=self.root_flow.entrypoint_path,
                    )
                target_agent = current_flow.agents_by_name.get(item.target_name)
                target_unit = (
                    self.root_entrypoint_unit
                    if target_agent is None
                    else current_flow.declaration_owner_units_by_id[id(target_agent)]
                )
                target_prompt_root = current_flow.prompt_root.resolve()
                target_flow_root = current_flow.flow_root.resolve()
            if target_agent is not None:
                self._flow_upsert_agent_node(agent_nodes, target_agent, unit=target_unit)
            self._flow_add_edge(
                edges,
                FlowEdge(
                    kind="authored_route",
                    source_kind="agent",
                    source_module_parts=agent_unit.module_parts,
                    source_name=agent_key[2],
                    target_kind="agent",
                    target_module_parts=(
                        target_unit.module_parts
                        if target_agent is not None
                        else item.target_module_parts
                    ),
                    target_name=item.target_name,
                    label=item.label,
                    source_prompt_root=agent_key[0],
                    source_flow_root=agent_key[1],
                    target_prompt_root=target_prompt_root,
                    target_flow_root=target_flow_root,
                ),
            )

    def _flow_upsert_agent_node(
        self,
        nodes: dict[FlowAgentKey, FlowAgentNode],
        agent: model.Agent,
        *,
        unit: IndexedUnit,
    ) -> None:
        prompt_root, flow_root = self._flow_identity(unit)
        key = (prompt_root, flow_root, agent.name)
        if key in nodes:
            return
        nodes[key] = FlowAgentNode(
            module_parts=unit.module_parts,
            name=agent.name,
            title=agent.title or agent.name,
            prompt_root=prompt_root,
            flow_root=flow_root,
            detail_lines=self._flow_agent_detail_lines(agent, unit=unit),
        )

    def _flow_upsert_input_node(
        self,
        nodes: dict[FlowArtifactKey, FlowInputNode],
        decl: model.InputDecl,
        *,
        unit: IndexedUnit,
    ) -> None:
        prompt_root, flow_root = self._flow_identity(unit)
        key = (prompt_root, flow_root, decl.name)
        if key in nodes:
            return
        source_title, shape_title, requirement_title, detail_lines = self._flow_input_summary(
            decl,
            unit=unit,
        )
        nodes[key] = FlowInputNode(
            module_parts=unit.module_parts,
            name=decl.name,
            title=decl.title,
            prompt_root=prompt_root,
            flow_root=flow_root,
            source_title=source_title,
            shape_title=shape_title,
            requirement_title=requirement_title,
            detail_lines=detail_lines,
        )

    def _flow_upsert_output_node(
        self,
        nodes: dict[FlowArtifactKey, FlowOutputNode],
        decl: model.OutputDecl,
        *,
        unit: IndexedUnit,
        review_semantics: ReviewSemanticContext | None = None,
        route_semantics: RouteSemanticContext | None = None,
    ) -> None:
        prompt_root, flow_root = self._flow_identity(unit)
        key = (prompt_root, flow_root, decl.name)
        if key in nodes:
            return
        target_title, primary_path, shape_title, requirement_title, detail_lines = (
            self._flow_output_summary(
                decl,
                unit=unit,
            )
        )
        nodes[key] = FlowOutputNode(
            module_parts=unit.module_parts,
            name=decl.name,
            title=decl.title,
            prompt_root=prompt_root,
            flow_root=flow_root,
            target_title=target_title,
            primary_path=primary_path,
            shape_title=shape_title,
            requirement_title=requirement_title,
            detail_lines=detail_lines,
            trust_surface=self._flow_trust_surface_labels(
                decl,
                unit=unit,
                review_semantics=review_semantics,
                route_semantics=route_semantics,
            ),
        )

    def _flow_agent_detail_lines(
        self,
        agent: model.Agent,
        *,
        unit: IndexedUnit,
    ) -> tuple[str, ...]:
        for field in agent.fields:
            if isinstance(field, model.RoleScalar):
                return (
                    self._interpolate_authored_prose_string(
                        field.text,
                        unit=unit,
                        owner_label=f"agent {agent.name}",
                        surface_label="role prose",
                    ),
                )
            if isinstance(field, model.RoleBlock):
                if not field.lines:
                    return (field.title,)
                return (
                    self._interpolate_authored_prose_string(
                        field.lines[0].text if isinstance(field.lines[0], model.EmphasizedLine) else field.lines[0],
                        unit=unit,
                        owner_label=f"agent {agent.name}",
                        surface_label="role prose",
                    ),
                )
        return ()

    def _flow_input_summary(
        self,
        decl: model.InputDecl,
        *,
        unit: IndexedUnit,
    ) -> tuple[str, str, str, tuple[str, ...]]:
        scalar_items, _section_items, _extras = self._split_record_items(
            decl.items,
            scalar_keys={"source", "shape", "requirement"},
            owner_label=f"input {decl.name}",
        )
        source_item = scalar_items.get("source")
        shape_item = scalar_items.get("shape")
        requirement_item = scalar_items.get("requirement")
        if source_item is None:
            raise compile_error(
                code="E221",
                summary="Input is missing typed source",
                detail=f"Input `{decl.name}` is missing a typed `source` field.",
                path=unit.prompt_file.source_path,
                source_span=decl.source_span,
            )
        if not isinstance(source_item.value, model.NameRef):
            raise compile_error(
                code="E275",
                summary="Input source must stay typed",
                detail=f"Input `{decl.name}` must keep a typed `source`.",
                path=unit.prompt_file.source_path,
                source_span=source_item.source_span or decl.source_span,
            )
        if requirement_item is None:
            raise compile_error(
                code="E223",
                summary="Input is missing requirement",
                detail=f"Input `{decl.name}` is missing a `requirement` field.",
                path=unit.prompt_file.source_path,
                source_span=decl.source_span,
            )

        source_spec = self._resolve_input_source_spec(source_item.value, unit=unit)
        if shape_item is None and self._is_rally_previous_turn_input_source_ref(
            source_item.value,
            unit=unit,
        ):
            config_lines: tuple[str, ...]
            output_item = next(
                (
                    item
                    for item in (source_item.body or ())
                    if isinstance(item, model.RecordScalar) and item.key == "output"
                ),
                None,
            )
            if output_item is None:
                config_lines = ("Previous Output: Exact previous final output",)
            else:
                selector_text = (
                    _display_addressable_ref(output_item.value)
                    if isinstance(output_item.value, model.AddressableRef)
                    else self._display_symbol_value(
                        output_item.value,
                        unit=unit,
                        owner_label=f"input {decl.name} source.output",
                        surface_label="input source fields",
                    )
                )
                config_lines = (
                    "Previous Output: " + selector_text,
                )
            shape_title = "Derived Previous Output"
        else:
            if shape_item is None:
                raise compile_error(
                    code="E222",
                    summary="Input is missing shape",
                    detail=f"Input `{decl.name}` is missing a `shape` field.",
                    path=unit.prompt_file.source_path,
                    source_span=decl.source_span,
                )
            config_lines, _config_values = self._flow_config_summary(
                source_item.body or (),
                spec=source_spec,
                unit=unit,
                owner_label=f"input {decl.name} source",
                owner_source_span=source_item.source_span or decl.source_span,
            )
            shape_title = self._display_symbol_value(
                shape_item.value,
                unit=unit,
                owner_label=f"input {decl.name}",
                surface_label="input fields",
            )
        requirement_title = self._display_symbol_value(
            requirement_item.value,
            unit=unit,
            owner_label=f"input {decl.name}",
            surface_label="input fields",
        )
        lines = list(config_lines)
        if decl.structure_ref is not None:
            _document_unit, document_decl = self._resolve_document_ref(decl.structure_ref, unit=unit)
            lines.append(f"Structure: {document_decl.title}")
        return (
            source_spec.title,
            shape_title,
            requirement_title,
            tuple(lines),
        )

    def _flow_output_summary(
        self,
        decl: model.OutputDecl,
        *,
        unit: IndexedUnit,
    ) -> tuple[str, str | None, str | None, str | None, tuple[str, ...]]:
        scalar_items, section_items, _extras = self._split_record_items(
            decl.items,
            scalar_keys={"target", "shape", "requirement"},
            section_keys={"files"},
            owner_label=f"output {decl.name}",
        )
        target_item = scalar_items.get("target")
        shape_item = scalar_items.get("shape")
        requirement_item = scalar_items.get("requirement")
        files_section = section_items.get("files")

        target_title: str | None = None
        primary_path: str | None = None
        shape_title: str | None = None
        lines: list[str] = []
        if files_section is not None:
            target_title = "Files"
            lines.extend(
                self._flow_output_files_detail_lines(
                    files_section,
                    unit=unit,
                    output_name=decl.name,
                )
            )
        else:
            if target_item is None:
                raise compile_error(
                    code="E224",
                    summary="Output declaration is incomplete",
                    detail=(
                        f"Output `{decl.name}` must define either `files` or both "
                        "`target` and `shape`."
                    ),
                    path=unit.prompt_file.source_path,
                    source_span=decl.source_span,
                    hints=(
                        "Add `files:` for a file set, or add both `target:` and `shape:`.",
                    ),
                )
            if not isinstance(target_item.value, model.NameRef):
                raise compile_error(
                    code="E275",
                    summary="Output target must stay typed",
                    detail=f"Output `{decl.name}` must keep a typed `target`.",
                    path=unit.prompt_file.source_path,
                    source_span=target_item.source_span or decl.source_span,
                )
            if shape_item is None:
                raise compile_error(
                    code="E224",
                    summary="Output declaration is incomplete",
                    detail=(
                        f"Output `{decl.name}` must define either `files` or both "
                        "`target` and `shape`."
                    ),
                    path=unit.prompt_file.source_path,
                    source_span=target_item.source_span or decl.source_span,
                    hints=(
                        "Add `files:` for a file set, or add both `target:` and `shape:`.",
                    ),
                )
            target_spec = self._resolve_output_target_spec(target_item.value, unit=unit)
            target_title = target_spec.title
            config_lines, config_values = self._flow_config_summary(
                target_item.body or (),
                spec=target_spec,
                unit=unit,
                owner_label=f"output {decl.name} target",
                owner_source_span=target_item.source_span or decl.source_span,
            )
            primary_path = config_values.get("path")
            lines.extend(
                line for line in config_lines if line != f"Path: {primary_path}"
            )
            shape_title = self._display_output_shape(
                shape_item.value,
                unit=unit,
                owner_label=f"output {decl.name}",
                surface_label="output fields",
            )

        requirement_title: str | None = None
        if requirement_item is not None:
            requirement_title = self._display_symbol_value(
                requirement_item.value,
                unit=unit,
                owner_label=f"output {decl.name}",
                surface_label="output fields",
            )
        if decl.schema_ref is not None:
            _schema_unit, schema_decl = self._resolve_schema_ref(decl.schema_ref, unit=unit)
            lines.append(f"Schema: {schema_decl.title}")
        if decl.structure_ref is not None:
            _document_unit, document_decl = self._resolve_document_ref(decl.structure_ref, unit=unit)
            lines.append(f"Structure: {document_decl.title}")
        return (
            target_title,
            primary_path,
            shape_title,
            requirement_title,
            tuple(lines),
        )

    def _flow_output_files_detail_lines(
        self,
        section: model.RecordSection,
        *,
        unit: IndexedUnit,
        output_name: str,
    ) -> tuple[str, ...]:
        lines: list[str] = ["Target: Files"]
        for item in section.items:
            if not isinstance(item, model.RecordSection):
                raise compile_error(
                    code="E299",
                    summary="Compile failure",
                    detail=f"`files` entries must be titled sections in output {output_name}",
                    path=unit.prompt_file.source_path,
                    source_span=_source_span(item) or section.source_span,
                )
            scalar_items, _section_items, _extras = self._split_record_items(
                item.items,
                scalar_keys={"path", "shape"},
                owner_label=f"output {output_name} file {item.key}",
            )
            path_item = scalar_items.get("path")
            shape_item = scalar_items.get("shape")
            if path_item is None or not isinstance(path_item.value, str):
                raise compile_error(
                    code="E299",
                    summary="Compile failure",
                    detail=(
                        f"Output file entry is missing string path in {output_name}: "
                        f"{item.key}"
                    ),
                    path=unit.prompt_file.source_path,
                    source_span=_source_span(path_item) or item.source_span,
                )
            if shape_item is None:
                raise compile_error(
                    code="E299",
                    summary="Compile failure",
                    detail=f"Output file entry is missing shape in {output_name}: {item.key}",
                    path=unit.prompt_file.source_path,
                    source_span=item.source_span,
                )
            lines.append(f"{item.title}: {path_item.value}")
            lines.append(
                f"{item.title} Shape: {self._display_output_shape(shape_item.value, unit=unit, owner_label=f'output {output_name} file {item.key}', surface_label='output file fields')}"
            )
        return tuple(lines)

    def _flow_config_lines(
        self,
        config_items: tuple[model.RecordItem, ...],
        *,
        spec: ConfigSpec | ResolvedOutputTargetSpec,
        unit: IndexedUnit,
        owner_label: str,
    ) -> tuple[str, ...]:
        lines, _values = self._flow_config_summary(
            config_items,
            spec=spec,
            unit=unit,
            owner_label=owner_label,
        )
        return lines

    def _flow_config_summary(
        self,
        config_items: tuple[model.RecordItem, ...],
        *,
        spec: ConfigSpec | ResolvedOutputTargetSpec,
        unit: IndexedUnit,
        owner_label: str,
        owner_source_span: model.SourceSpan | None = None,
    ) -> tuple[tuple[str, ...], dict[str, str]]:
        lines: list[str] = []
        values: dict[str, str] = {}
        seen_keys: dict[str, model.RecordScalar] = {}
        allowed_keys = {**spec.required_keys, **spec.optional_keys}

        for item in config_items:
            if not isinstance(item, model.RecordScalar) or item.body is not None:
                raise compile_error(
                    code="E230",
                    summary="Config entries must be scalar key/value lines",
                    detail=(
                        f"Config entries must be scalar key/value lines in "
                        f"`{owner_label}`."
                    ),
                    path=unit.prompt_file.source_path,
                    source_span=_source_span(item) or owner_source_span,
                )
            first_item = seen_keys.get(item.key)
            if first_item is not None:
                raise compile_error(
                    code="E231",
                    summary="Duplicate config key",
                    detail=(
                        f"Config owner `{owner_label}` repeats key `{item.key}`."
                    ),
                    path=unit.prompt_file.source_path,
                    source_span=item.source_span or owner_source_span,
                    related=(
                        related_prompt_site(
                            label=f"first `{item.key}` config entry",
                            path=unit.prompt_file.source_path,
                            source_span=first_item.source_span,
                        ),
                    ),
                )
            seen_keys[item.key] = item
            if item.key not in allowed_keys:
                raise compile_error(
                    code="E232",
                    summary="Unknown config key",
                    detail=(
                        f"Config owner `{owner_label}` uses unknown key `{item.key}`."
                    ),
                    path=unit.prompt_file.source_path,
                    source_span=item.source_span or owner_source_span,
                )
            rendered = self._display_scalar_value(
                item.value,
                unit=unit,
                owner_label=f"{owner_label}.{item.key}",
                surface_label="config values",
            ).text
            values[item.key] = rendered
            lines.append(
                f"{allowed_keys[item.key]}: {rendered}"
            )

        missing_required = [key for key in spec.required_keys if key not in seen_keys]
        if missing_required:
            missing = ", ".join(missing_required)
            raise compile_error(
                code="E233",
                summary="Missing required config key",
                detail=(
                    f"Config owner `{owner_label}` is missing required key `{missing}`."
                ),
                path=unit.prompt_file.source_path,
                source_span=owner_source_span,
            )

        return tuple(lines), values

    def _flow_trust_surface_labels(
        self,
        decl: model.OutputDecl,
        *,
        unit: IndexedUnit,
        review_semantics: ReviewSemanticContext | None = None,
        route_semantics: RouteSemanticContext | None = None,
    ) -> tuple[str, ...]:
        if not decl.trust_surface:
            return ()
        section = self._compile_trust_surface_section(
            decl,
            unit=unit,
            review_semantics=review_semantics,
            route_semantics=route_semantics,
        )
        return tuple(
            item[2:]
            for item in section.body
            if isinstance(item, str) and item.startswith("- ")
        )

    def _flow_carrier_label(
        self,
        resolved: ResolvedLawPath,
        *,
        owner_label: str,
    ) -> str:
        if not isinstance(resolved.decl, model.OutputDecl):
            return self._display_readable_decl(resolved.decl)
        field_node = self._resolve_output_field_node(
            resolved.decl,
            path=resolved.remainder,
            unit=resolved.unit,
            owner_label=owner_label,
            surface_label="flow graph",
        )
        field_label = self._display_addressable_target_value(
            field_node,
            owner_label=owner_label,
            surface_label="flow graph",
        ).text
        return f"{resolved.decl.title}.{field_label}"

    def _flow_review_semantics_for_output(
        self,
        output_key: OutputDeclKey,
        *,
        review_output_contexts: frozenset[tuple[OutputDeclKey, ReviewSemanticContext]],
        primary_review_output_context: tuple[OutputDeclKey, ReviewSemanticContext] | None,
        final_output_key: OutputDeclKey | None,
    ) -> ReviewSemanticContext | None:
        review_semantics = self._review_output_context_for_key(
            review_output_contexts,
            output_key,
        )
        if review_semantics is None and final_output_key is not None and output_key == final_output_key:
            if primary_review_output_context is not None:
                review_semantics = primary_review_output_context[1]
        return review_semantics

    def _flow_append_artifact_note(
        self,
        *,
        input_notes: dict[FlowArtifactKey, list[str]],
        output_notes: dict[FlowArtifactKey, list[str]],
        resolved: ResolvedLawPath,
        note: str,
    ) -> None:
        key = self._flow_artifact_key(resolved.unit, resolved.decl.name)
        if isinstance(resolved.decl, model.InputDecl):
            self._flow_append_note(input_notes, key, note)
            return
        if isinstance(resolved.decl, model.OutputDecl):
            self._flow_append_note(output_notes, key, note)

    def _flow_append_note(
        self,
        notes_by_key: dict[object, list[str]],
        key: object,
        note: str,
    ) -> None:
        bucket = notes_by_key.setdefault(key, [])
        if note not in bucket:
            bucket.append(note)

    def _flow_add_edge(
        self,
        edges: dict[tuple[object, ...], FlowEdge],
        edge: FlowEdge,
    ) -> None:
        key = (
            edge.kind,
            edge.source_kind,
            edge.source_prompt_root,
            edge.source_flow_root,
            edge.source_module_parts,
            edge.source_name,
            edge.target_kind,
            edge.target_prompt_root,
            edge.target_flow_root,
            edge.target_module_parts,
            edge.target_name,
            edge.label,
        )
        edges.setdefault(key, edge)
