# PyMCP_Browser

Browser-control API exposing a typed FastAPI REST surface **and** an MCP (Model Context Protocol) server over the same engine. Supports Playwright, Patchright, and Camoufox backends with stealth, macro recording, and IMAP/SMTP helpers built in.

## Install

```
pip install PyMCP_Browser
```

Optional engines:

```
pip install "PyMCP_Browser[patchright]"
pip install "PyMCP_Browser[camoufox]"
pip install "PyMCP_Browser[all-engines]"
```

After install, fetch the browser binaries:

```
playwright install chromium
```

## Quick start

Run the REST + MCP server:

```
pymcp-v2 serve
```

Or invoke as a module:

```
python -m pymcp_browser.v2 serve
python -m pymcp_browser.v2 mcp     # MCP-only mode
```

## Features

- **Multiple stealth engines** — Playwright, Patchright, Camoufox (opt-in via extras).
- **REST + MCP** — same engine, two transports.
- **Macro recording / replay** — JSONL macros captured live, replayed deterministically.
- **Session pool** — bounded concurrent sessions with idle TTL.
- **Stealth out-of-the-box** — `tf-playwright-stealth` + `browserforge` fingerprints.
- **Account helpers** — IMAP/SMTP/OTP utilities for sign-up automation flows.

## Configuration

Copy `.env.example` to `.env` and tune. See `CLAUDE.md` for architecture notes.

## License

MIT
