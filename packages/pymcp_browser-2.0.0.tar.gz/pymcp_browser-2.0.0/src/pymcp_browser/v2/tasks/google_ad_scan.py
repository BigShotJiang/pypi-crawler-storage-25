"""Google SERP ad scanner with green/orange watchlist matching.

Searches Google for `query`, detects Sponsored/ad blocks, matches each against
two watchlists (greenlist, orangelist), highlights matches on the live page
(dark green / dark orange bg, white text), then writes a JSON report + a
post-highlight screenshot.

Matching: case-insensitive substring against the union of an ad's display URL,
host, title, and visible body text. Each list item is a plain string (a domain
fragment like "example.com", or a brand/text fragment like "Acme Roofing").
"""
from __future__ import annotations
import asyncio
import json
import random
import re
import sys
import time
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import quote_plus, urlparse

# Allow running as a script (python path/to/google_ad_scan.py) by adding the
# project's src/ to sys.path before the relative-import resolution kicks in.
if __package__ in (None, ""):
    _SRC = Path(__file__).resolve().parents[3]
    if str(_SRC) not in sys.path:
        sys.path.insert(0, str(_SRC))
    __package__ = "pymcp_browser.v2.tasks"  # noqa: A001

from loguru import logger as log

from pymcp_browser.v2.config import settings
from pymcp_browser.v2.control.registry import task
from pymcp_browser.v2.control.tools.captcha import captcha_auto
from pymcp_browser.v2.core.captcha.detector import detect_captcha
from pymcp_browser.v2.core.session import SessionRegistry


_AD_SCAN_JS = r"""
() => {
  // Google text ads on the SERP use:
  //   - container: `<div data-text-ad="1">…</div>` (may have display:contents)
  //   - link:      `<a data-pcu="dest1,dest2" data-rw="https://www.google.com/aclk?…">`
  //                 (often without an `href` attribute — JS resolves on click)
  // We anchor on `[data-text-ad]` for the marker, but the visible card we
  // want to highlight is a descendant (the one with non-zero bbox).

  function visibleRect(el) {
    if (!el) return null;
    const r = el.getBoundingClientRect();
    if (r.width < 100 || r.height < 30) return null;
    const cs = getComputedStyle(el);
    if (cs.display === 'none' || cs.visibility === 'hidden') return null;
    return r;
  }

  // Pick the smallest visible descendant of `root` that wraps both an ad-link
  // and a heading. Reasonable card sizes: w >= 200, 60 <= h <= 600.
  function findVisibleCard(root) {
    if (!root) return null;
    const candidates = [];
    const walker = document.createTreeWalker(root, NodeFilter.SHOW_ELEMENT);
    while (walker.nextNode()) {
      const n = walker.currentNode;
      const r = visibleRect(n);
      if (!r) continue;
      if (r.width < 200) continue;
      if (r.height < 60 || r.height > 600) continue;
      const head = n.querySelector('div[role="heading"], h3, [role="heading"] span, [role="heading"]');
      const link = n.querySelector('a[data-rw], a[data-pcu], a[href*="aclk"], a[href^="http"]');
      if (head && link) candidates.push({n, area: r.width * r.height});
    }
    if (!candidates.length) return null;
    candidates.sort((a, b) => a.area - b.area);  // smallest first
    return candidates[0].n;
  }

  function adAnchor(root) {
    return root && (root.querySelector('a[data-rw]')
                  || root.querySelector('a[data-pcu]')
                  || root.querySelector('a[href*="aclk"]')
                  || root.querySelector('a[href^="http"]'));
  }

  function destUrl(a) {
    if (!a) return '';
    // 1) data-pcu may be comma-separated; first entry is the display URL
    const pcu = a.getAttribute('data-pcu');
    if (pcu) return pcu.split(',')[0].trim();
    // 2) decode adurl= param from href/data-rw
    const candidate = a.href || a.getAttribute('data-rw') || '';
    try {
      const u = new URL(candidate, location.origin);
      const ad = u.searchParams.get('adurl') || u.searchParams.get('aurl');
      if (ad) return decodeURIComponent(ad);
    } catch (e) {}
    return candidate;
  }

  const accepted = new Map();
  const out = [];
  let idx = 0;

  function emit(card, a) {
    if (!card || accepted.has(card)) return;
    // Skip if ancestor already accepted
    let anc = card.parentElement;
    while (anc) { if (accepted.has(anc)) return; anc = anc.parentElement; }
    const rect = card.getBoundingClientRect();
    if (rect.width < 100 || rect.height < 30) return;
    const href = destUrl(a);
    let host = '';
    try { host = new URL(href).hostname.replace(/^www\./, ''); } catch (e) {}
    const titleEl = card.querySelector('div[role="heading"], h3, [role="heading"] span, [role="heading"]');
    const title = titleEl ? (titleEl.innerText || titleEl.textContent || '').trim() : '';
    const dispEl = card.querySelector('span.x2VHCd, span.qzEoUe, .VuuXrf, cite');
    const display_url = dispEl ? (dispEl.innerText || '').trim() : '';
    const body_text = ((card.innerText || '').replace(/\s+/g, ' ').trim()).slice(0, 400);
    idx += 1;
    accepted.set(card, idx);
    out.push({
      _scan_id: idx,
      title, display_url, host,
      href,
      aclk_href: (a && (a.href || a.getAttribute('data-rw'))) || '',
      body_text,
      bbox: { x: Math.round(rect.left), y: Math.round(rect.top),
              w: Math.round(rect.width), h: Math.round(rect.height) },
    });
    card.setAttribute('data-pymcp-ad-scan', String(idx));
  }

  function climbToCard(a) {
    // Walk up from anchor `a`; return smallest visible ancestor that is a
    // complete ad card — must have heading AND display URL (cite/x2VHCd/etc)
    // AND reasonable card dimensions (not the whole carousel, not just title).
    let p = a;
    for (let i = 0; i < 12 && p; i++) {
      if (p.tagName === 'BODY' || p.tagName === 'HTML') break;
      const r = visibleRect(p);
      if (r && r.width >= 200 && r.width <= 1100
          && r.height >= 90 && r.height <= 700) {
        const hasHead = p.querySelector('div[role="heading"], h3, [role="heading"]');
        const hasDisp = p.querySelector('span.x2VHCd, span.qzEoUe, .VuuXrf, cite');
        if (hasHead && hasDisp) return p;
      }
      p = p.parentElement;
    }
    return null;
  }

  // Single pass: iterate every ad anchor (any of data-pcu / data-rw / aclk).
  for (const a of document.querySelectorAll('a[data-pcu], a[data-rw], a[href*="aclk"]')) {
    const rw = a.getAttribute('data-rw') || '';
    const pcu = a.getAttribute('data-pcu') || '';
    const hrefAttr = a.getAttribute('href') || '';
    const isAd = pcu || /aclk/.test(rw) || /aclk/.test(hrefAttr) || /aclk/.test(a.href || '');
    if (!isAd) continue;
    const card = climbToCard(a);
    if (!card) continue;
    emit(card, a);
  }

  return out;
}
"""

_HIGHLIGHT_JS = r"""
(payload) => {
  const { matches } = payload;
  // Defensive sizing: skip any scan_id whose element is unreasonably tall
  // (would paint the whole page). Each ad card should be < 600px tall.
  const style = document.createElement('style');
  style.id = 'pymcp-ad-highlight-style';
  style.textContent = `
    [data-pymcp-list="green"] {
      background: #14532d !important;
      color: #ffffff !important;
      outline: 3px solid #14532d !important;
      outline-offset: 2px !important;
      border-radius: 6px !important;
    }
    [data-pymcp-list="orange"] {
      background: #9a3412 !important;
      color: #ffffff !important;
      outline: 3px solid #9a3412 !important;
      outline-offset: 2px !important;
      border-radius: 6px !important;
    }
    [data-pymcp-list] *,
    [data-pymcp-list] a,
    [data-pymcp-list] cite,
    [data-pymcp-list] span,
    [data-pymcp-list] h3,
    [data-pymcp-list] div {
      color: #ffffff !important;
      background-color: transparent !important;
    }
    [data-pymcp-list]::before {
      content: attr(data-pymcp-badge);
      display: inline-block;
      background: #000;
      color: #fff;
      font: 700 11px/1.4 system-ui, sans-serif;
      padding: 2px 8px;
      margin: 0 0 6px 0;
      border-radius: 4px;
    }
  `;
  document.head.appendChild(style);
  let applied = 0;
  for (const m of matches) {
    const el = document.querySelector(`[data-pymcp-ad-scan="${m.scan_id}"]`);
    if (!el) continue;
    const r = el.getBoundingClientRect();
    if (r.height > 700 || r.width < 100) continue;  // safety: don't paint giants
    el.setAttribute('data-pymcp-list', m.list_name);
    el.setAttribute('data-pymcp-badge', m.badge);
    applied += 1;
  }
  return applied;
}
"""


class _DebugRecorder:
    """Per-run debug logger. Writes a step-by-step `debug.log` plus HTML +
    PNG snapshots to the run directory so the whole trace can be inspected
    after the fact and a one-shot fix can be reasoned about offline.
    """

    def __init__(self, out_dir: Path) -> None:
        self.dir = out_dir
        self.dir.mkdir(parents=True, exist_ok=True)
        self.log_path = self.dir / "debug.log"
        self._t0 = time.perf_counter()
        self._step = 0
        self._fp = open(self.log_path, "w", encoding="utf-8")
        self.line("=== run begin ===")

    def line(self, msg: str, **kv) -> None:
        elapsed_ms = (time.perf_counter() - self._t0) * 1000.0
        ts = datetime.now().strftime("%H:%M:%S.%f")[:-3]
        extras = ""
        if kv:
            extras = " " + " ".join(f"{k}={_short(v)}" for k, v in kv.items())
        line = f"[{ts}] +{elapsed_ms:7.0f}ms  {msg}{extras}"
        try:
            self._fp.write(line + "\n")
            self._fp.flush()
        except Exception:
            pass
        log.info(msg + extras)

    async def snapshot(self, page, name: str, *, html: bool = True, png: bool = True) -> None:
        self._step += 1
        slug = re.sub(r"[^a-z0-9]+", "_", name.lower()).strip("_") or "step"
        base = self.dir / f"step_{self._step:02d}_{slug}"
        url = ""
        try:
            url = page.url or ""
        except Exception:
            pass
        if png:
            try:
                await page.screenshot(path=str(base.with_suffix(".png")), full_page=False)
            except Exception as e:
                self.line(f"snapshot png failed: {e}")
        if html:
            try:
                content = await page.content()
                base.with_suffix(".html").write_text(content, encoding="utf-8", errors="replace")
            except Exception as e:
                self.line(f"snapshot html failed: {e}")
        self.line(f"snapshot {self._step:02d} {slug}", url=url[:120])

    def close(self) -> None:
        try:
            self.line("=== run end ===")
            self._fp.close()
        except Exception:
            pass


def _short(v) -> str:
    s = str(v)
    return s if len(s) <= 160 else s[:160] + "…"


async def _human_type(page, text: str, rec: _DebugRecorder | None = None) -> None:
    """Type with variable per-key delays + occasional longer pauses, instead of
    a constant `delay=40`. Mirrors realistic human typing speed (~3-4 cps).
    """
    t0 = time.perf_counter()
    for i, ch in enumerate(text):
        await page.keyboard.type(ch)
        if ch == " ":
            await asyncio.sleep(random.uniform(0.18, 0.40))
        else:
            await asyncio.sleep(random.uniform(0.08, 0.18))
        if i > 0 and i % random.randint(5, 9) == 0:
            await asyncio.sleep(random.uniform(0.15, 0.45))
    if rec:
        rec.line("typed query", chars=len(text), elapsed_ms=int((time.perf_counter() - t0) * 1000))


_SUGGEST_SELECTORS = (
    'ul[role="listbox"] li[role="option"]',
    '[role="listbox"] [role="option"]',
    'ul[role="listbox"] li',
    'div.aajZCb div[role="presentation"]',
)


async def _submit_via_suggestion_or_enter(page, rec: "_DebugRecorder | None") -> None:
    """Submit the search by selecting an autosuggest item via keyboard, falling
    back to a plain Enter when the dropdown doesn't render in time.

    Mimics a human who finishes typing, glances at the suggestions for a beat
    (total 2-5 s), arrow-keys down to one, and hits Enter. No mouse hovering
    over the dropdown — the cursor was loitering and tripping bot heuristics.
    """
    # Brief wait for the suggestion list to appear
    saw_suggestions = False
    for _ in range(20):  # ~2s
        try:
            count = await page.evaluate(
                """() => {
                  for (const sel of [
                    'ul[role=\"listbox\"] li[role=\"option\"]',
                    '[role=\"listbox\"] [role=\"option\"]',
                    'ul[role=\"listbox\"] li',
                  ]) {
                    const n = document.querySelectorAll(sel).length;
                    if (n > 0) return n;
                  }
                  return 0;
                }"""
            )
        except Exception:
            count = 0
        if count and count > 0:
            saw_suggestions = True
            if rec:
                rec.line("autosuggest visible", count=count)
            break
        await asyncio.sleep(0.1)

    if saw_suggestions:
        # Total "look at the list" time: 2-5 s, distributed across pauses
        total_pause = random.uniform(2.0, 5.0)
        presses = random.randint(1, 3)
        per_press_total = total_pause * random.uniform(0.55, 0.75)
        per_press = per_press_total / max(1, presses)
        post_pause = total_pause - per_press_total
        if rec:
            rec.line("selecting suggestion via keyboard",
                     presses=presses, total_pause_s=round(total_pause, 2))
        await asyncio.sleep(random.uniform(0.4, 1.0))  # initial "reading" pause
        for _ in range(presses):
            await page.keyboard.press("ArrowDown")
            await asyncio.sleep(per_press * random.uniform(0.7, 1.3))
        await asyncio.sleep(max(0.15, post_pause))
        await page.keyboard.press("Enter")
        if rec:
            rec.line("Enter pressed on highlighted suggestion")
        return

    # No autosuggest — just submit the typed text
    if rec:
        rec.line("autosuggest did not appear; pressing Enter")
    await asyncio.sleep(random.uniform(0.2, 0.5))
    await page.keyboard.press("Enter")


async def _dismiss_consent(page) -> bool:
    """Click through Google's EU consent banner / interstitial if present."""
    is_consent_host = "consent.google" in (page.url or "")
    for sel in (
        'button[aria-label*="Accept"]',
        'button[aria-label*="Reject"]',
        'button:has-text("Accept all")',
        'button:has-text("I agree")',
        'button:has-text("Reject all")',
        'form[action*="consent"] button[type="submit"]',
    ):
        try:
            loc = page.locator(sel).first
            if await loc.count() and await loc.is_visible():
                await loc.click(timeout=2500)
                await page.wait_for_load_state("domcontentloaded", timeout=8000)
                return True
        except Exception:
            continue
    return is_consent_host  # signal we were on the consent host even if no click landed


async def _google_sorry_info(page) -> dict | None:
    """If we're on /sorry/index (or any page with inline g-recaptcha div),
    return the sitekey + form context so we can solve via capsolver directly.
    """
    url = page.url or ""
    on_sorry = "/sorry/" in url
    try:
        info = await page.evaluate("""
        () => {
          const div = document.querySelector('div.g-recaptcha[data-sitekey], div#recaptcha[data-sitekey]');
          if (!div) return null;
          const enterprise = !!document.querySelector('script[src*="recaptcha/enterprise"]');
          return {
            sitekey: div.getAttribute('data-sitekey'),
            data_s: div.getAttribute('data-s') || null,
            invisible: (div.getAttribute('data-size') || '').toLowerCase() === 'invisible',
            enterprise,
            has_form: !!document.querySelector('form#captcha-form, form[action*="sorry"]'),
          };
        }
        """)
    except Exception:
        info = None
    if not info:
        return {"on_sorry": on_sorry} if on_sorry else None
    return {
        "sitekey": info["sitekey"],
        "data_s": info.get("data_s"),
        "type": "recaptcha_enterprise" if info["enterprise"] else "recaptcha_v2",
        "invisible": bool(info["invisible"]),
        "has_form": bool(info["has_form"]),
        "on_sorry": on_sorry,
    }


async def _capsolver_google_sorry(sitekey: str, page_url: str,
                                  data_s: str | None,
                                  enterprise: bool,
                                  proxy: dict | None = None) -> str:
    """Direct capsolver call for Google /sorry/ reCAPTCHA — needs data-s
    threaded through enterprisePayload, otherwise capsolver returns code 1001.

    When `proxy` is supplied (server/username/password dict from the browser
    session), capsolver uses the non-Proxyless variant and tunnels the solve
    through the same egress IP. Google reCAPTCHA Enterprise IP-binds the
    challenge, so without this alignment Proxyless tokens get rejected.
    """
    import httpx, json as _json
    from pathlib import Path as _P
    keys_path = _P("./data/credentials.json")
    keys = _json.loads(keys_path.read_text(encoding="utf-8")) if keys_path.exists() else {}
    api_key = keys.get("capsolver", {}).get("api_key") or keys.get("CAPSOLVER_KEY")
    if not api_key:
        raise RuntimeError("capsolver api key missing in data/credentials.json")

    use_proxy = bool(proxy and proxy.get("server"))
    task_type = "ReCaptchaV2EnterpriseTask" if enterprise else "ReCaptchaV2Task"
    if not use_proxy:
        task_type += "Proxyless"
    task: dict = {
        "type": task_type,
        "websiteURL": page_url,
        "websiteKey": sitekey,
        "isInvisible": False,
        "pageAction": "submit",
    }
    if data_s:
        # Google /sorry/ requires this; without it capsolver bounces with 1001.
        task["enterprisePayload"] = {"s": data_s}
    if use_proxy:
        # Parse "http://host:port" → host, port
        server = str(proxy["server"])
        scheme, _, rest = server.partition("://")
        host, _, port = rest.partition(":")
        try:
            port_i = int(port) if port else 80
        except ValueError:
            port_i = 80
        task["proxyType"] = scheme or "http"
        task["proxyAddress"] = host
        task["proxyPort"] = port_i
        if proxy.get("username"):
            task["proxyLogin"] = proxy["username"]
        if proxy.get("password"):
            task["proxyPassword"] = proxy["password"]
    payload = {"clientKey": api_key, "task": task}
    async with httpx.AsyncClient(timeout=30) as client:
        r = await client.post("https://api.capsolver.com/createTask", json=payload)
        data = r.json()
        if data.get("errorId"):
            raise RuntimeError(f"capsolver createTask: {data}")
        task_id = data["taskId"]
        for _ in range(60):
            await asyncio.sleep(3)
            r = await client.post("https://api.capsolver.com/getTaskResult",
                                  json={"clientKey": api_key, "taskId": task_id})
            d = r.json()
            if d.get("status") == "ready":
                return d["solution"]["gRecaptchaResponse"]
            if d.get("errorId"):
                raise RuntimeError(f"capsolver getTaskResult: {d}")
        raise RuntimeError("capsolver timeout")


_CAPTCHA_BANNER_JS = r"""
(payload) => {
  const { state, message } = payload;
  let banner = document.getElementById('pymcp-captcha-banner');
  if (!banner) {
    banner = document.createElement('div');
    banner.id = 'pymcp-captcha-banner';
    banner.style.cssText = [
      'position:fixed', 'top:0', 'left:0', 'right:0', 'z-index:2147483647',
      'padding:14px 20px', 'font:600 14px/1.4 system-ui,Segoe UI,Arial,sans-serif',
      'color:#fff', 'text-align:center', 'letter-spacing:.2px',
      'box-shadow:0 4px 12px rgba(0,0,0,.35)',
      'transition:background-color .25s ease',
    ].join(';');
    const spinner = document.createElement('span');
    spinner.id = 'pymcp-captcha-spinner';
    spinner.style.cssText = [
      'display:inline-block', 'width:14px', 'height:14px',
      'margin-right:10px', 'vertical-align:-2px',
      'border:2px solid rgba(255,255,255,.4)', 'border-top-color:#fff',
      'border-radius:50%', 'animation:pymcp-cap-spin .8s linear infinite',
    ].join(';');
    const label = document.createElement('span');
    label.id = 'pymcp-captcha-banner-text';
    banner.appendChild(spinner);
    banner.appendChild(label);
    const style = document.createElement('style');
    style.textContent = '@keyframes pymcp-cap-spin{to{transform:rotate(360deg)}}';
    document.head.appendChild(style);
    document.body.appendChild(banner);
  }
  const text = banner.querySelector('#pymcp-captcha-banner-text');
  const spin = banner.querySelector('#pymcp-captcha-spinner');
  const palette = {
    solving: '#1f6feb', // blue
    success: '#1f8a4c', // green
    error:   '#b42318', // red
  };
  banner.style.background = palette[state] || palette.solving;
  if (text) text.textContent = message || 'Captcha detected — solving via CapSolver…';
  if (spin) spin.style.display = (state === 'solving') ? 'inline-block' : 'none';
  return true;
}
"""


async def _show_captcha_banner(page, state: str, message: str | None = None) -> None:
    """Best-effort overlay banner on the captcha page. Never raises."""
    try:
        await page.evaluate(_CAPTCHA_BANNER_JS, {"state": state, "message": message})
    except Exception:
        pass


async def _solve_google_sorry(page, info: dict, proxy: dict | None = None) -> dict:
    """Solve the Google /sorry/ reCAPTCHA Enterprise via capsolver, inject the
    g-recaptcha-response token, then submit the form.
    """
    sitekey = info.get("sitekey")
    if not sitekey:
        return {"solved": False, "reason": "missing_sitekey"}
    enterprise = info.get("type") == "recaptcha_enterprise"
    page_url = page.url
    await _show_captcha_banner(
        page, "solving",
        "Captcha Detected — Solving via CapSolver…",
    )
    try:
        token = await _capsolver_google_sorry(
            sitekey=sitekey, page_url=page_url,
            data_s=info.get("data_s"), enterprise=enterprise, proxy=proxy,
        )
    except Exception as e:
        await _show_captcha_banner(page, "error", f"CapSolver error: {e}")
        return {"solved": False, "reason": f"capsolver_error: {e}"}
    await _show_captcha_banner(
        page, "solving",
        "Token received — submitting…",
    )
    try:
        # Inject token into the textarea reCAPTCHA expects, then submit the form
        await page.evaluate("""
        (tok) => {
          let ta = document.getElementById('g-recaptcha-response');
          if (!ta) {
            ta = document.createElement('textarea');
            ta.id = 'g-recaptcha-response';
            ta.name = 'g-recaptcha-response';
            ta.style.display = 'none';
            document.body.appendChild(ta);
          }
          ta.value = tok;
          if (typeof submitCallback === 'function') {
            try { submitCallback(tok); return; } catch(e) {}
          }
          const f = document.getElementById('captcha-form')
                 || document.querySelector('form[action*="sorry"]')
                 || document.querySelector('form');
          if (f) f.submit();
        }
        """, token)
    except Exception as e:
        await _show_captcha_banner(page, "error", f"Token inject failed: {e}")
        return {"solved": False, "reason": f"token_inject_failed: {e}"}
    try:
        await page.wait_for_load_state("domcontentloaded", timeout=20000)
    except Exception:
        pass
    # If we're still on /sorry/ the banner gets a chance to repaint on the
    # re-served captcha page. If we navigated to /search? the banner is gone
    # along with the page; the (transient) success state is mostly for UX
    # when the same /sorry/ page is reused.
    cap_type = "recaptcha_enterprise" if enterprise else "recaptcha_v2"
    await _show_captcha_banner(page, "success", "Captcha submitted — waiting…")
    return {"solved": True, "type": cap_type, "provider": "capsolver"}


async def _solve_captcha_if_any(page, session_id: str, attempts: int = 2,
                                proxy: dict | None = None,
                                rec: _DebugRecorder | None = None) -> dict:
    """Detect and solve Google's anti-abuse reCAPTCHA when present.

    Handles two layouts:
      1. /sorry/index with inline `<div class="g-recaptcha" data-sitekey=...>`
         (Google's enterprise.js is loaded without ?render=).
      2. Generic reCAPTCHA / hCaptcha / Turnstile iframes via captcha_auto.
    """
    last: dict = {"solved": False, "reason": "no_captcha"}
    if rec:
        rec.line("captcha check start", url=(page.url or "")[:120],
                 attempts=attempts, has_proxy=bool(proxy))
    for i in range(max(1, attempts)):
        if rec:
            rec.line(f"captcha attempt {i+1}/{attempts}", url=(page.url or "")[:120])
        # Give the page a moment for any deferred reCAPTCHA scripts to mount
        if "/sorry/" in (page.url or ""):
            # Poll for the recaptcha element — enterprise.js loads with `async defer`
            # so the div can take a few seconds to mount even after DOMContentLoaded.
            # Exit early if URL navigates away from /sorry/ during the poll
            # (Google bounced us back to /search? — no captcha to solve).
            mounted = False
            for _ in range(40):  # up to ~20s
                if "/sorry/" not in (page.url or ""):
                    if rec:
                        rec.line("captcha mount-poll aborted — URL left /sorry/",
                                 url=(page.url or "")[:120])
                    return {"solved": True, "reason": "navigated_away"}
                try:
                    has = await page.evaluate(
                        '''() => !!document.querySelector(
                            'div.g-recaptcha[data-sitekey], div#recaptcha[data-sitekey], iframe[src*="recaptcha"]'
                        )'''
                    )
                    if has:
                        mounted = True
                        break
                except Exception:
                    pass
                await asyncio.sleep(0.5)
            if not mounted:
                log.warning("google_ad_scan: on /sorry/ but no recaptcha div appeared after 20s; url={}",
                            (page.url or "")[:120])

        # Path 1: inline g-recaptcha (Google sorry page)
        sorry = await _google_sorry_info(page)
        if rec:
            rec.line("sorry_info", info=sorry)
        if "/sorry/" in (page.url or "") and (not sorry or not sorry.get("sitekey")):
            log.warning("google_ad_scan: on /sorry/ but no sitekey extracted; info={} url={}",
                        sorry, (page.url or "")[:120])
            if rec:
                await rec.snapshot(page, f"sorry_no_sitekey_attempt{i+1}")
        if sorry and sorry.get("sitekey"):
            if rec:
                await rec.snapshot(page, f"sorry_captcha_attempt{i+1}")
                rec.line("solving sorry captcha",
                         sitekey=sorry["sitekey"][:14], data_s=bool(sorry.get("data_s")),
                         enterprise=sorry.get("type") == "recaptcha_enterprise")
            log.info("google_ad_scan: solving google sorry captcha sitekey={}",
                     sorry["sitekey"][:10] + "…")
            res = await _solve_google_sorry(page, sorry, proxy=proxy)
            last = res
            if rec:
                rec.line("solve result", res=res)
                await rec.snapshot(page, f"after_solve_attempt{i+1}")
            # Form submission is in-flight; give navigation a moment to settle
            for _ in range(8):
                if "/sorry/" not in (page.url or ""):
                    break
                await asyncio.sleep(0.5)
            still_on_sorry = "/sorry/" in (page.url or "")
            if res.get("solved") and not still_on_sorry:
                log.info("google_ad_scan: sorry-captcha solved on attempt {}", i + 1)
                return res
            reason = res.get("reason") or ("still_on_sorry" if still_on_sorry else "unknown")
            log.warning("google_ad_scan: sorry-captcha attempt {} -> {}",
                        i + 1, reason)
            await asyncio.sleep(2)
            continue

        # Path 2: anchored iframe captchas
        info = await detect_captcha(page)
        if info is None:
            for fr in page.frames:
                if fr is page.main_frame:
                    continue
                try:
                    sub = await detect_captcha(fr)
                    if sub:
                        info = sub
                        break
                except Exception:
                    continue
        if not info:
            return last
        await _show_captcha_banner(
            page, "solving",
            "Captcha Detected — Solving via CapSolver…",
        )
        try:
            res = await captcha_auto(session_id=session_id, provider="capsolver")
            last = res
            if res.get("solved"):
                await _show_captcha_banner(page, "success", "Captcha solved — continuing…")
                try:
                    await page.wait_for_load_state("domcontentloaded", timeout=12000)
                except Exception:
                    pass
                if await detect_captcha(page) is None:
                    return res
            else:
                await _show_captcha_banner(
                    page, "error",
                    f"Solve failed: {res.get('reason') or 'unknown'} — retrying…",
                )
                log.warning("google_ad_scan: captcha attempt {} failed: {}",
                            i + 1, res.get("reason"))
                await asyncio.sleep(2)
        except Exception as e:
            log.warning("google_ad_scan: captcha_auto raised: {}", e)
            last = {"solved": False, "reason": str(e)}
            break
    return last


def _safe_slug(s: str, n: int = 40) -> str:
    s = re.sub(r"[^A-Za-z0-9]+", "_", s).strip("_").lower()
    return (s or "query")[:n]


def _glob_to_regex(pat: str) -> re.Pattern:
    """Translate a shell-style glob (* and ?) to a compiled regex.

    Unlike fnmatch.translate this anchors only the start unless the pattern
    already ends with *, so trailing-slash variants still match.
    """
    out = []
    for ch in pat:
        if ch == "*":
            out.append(".*")
        elif ch == "?":
            out.append(".")
        else:
            out.append(re.escape(ch))
    return re.compile("^" + "".join(out) + "$", re.IGNORECASE)


def _match(ad: dict, items: list[str]) -> str | None:
    """Return the matched list-item string, or None.

    Item forms supported:
      - "nike.com"                   → domain, matched against host/display_url
      - "https://shop.x.com/sale"    → URL, matched as a literal substring of href
      - "https://shop.x.com/path/*"  → URL glob, matched against href (and display_url)
      - "barefoot"                   → plain word, word-boundary across all fields
    """
    title = (ad.get("title") or "").lower()
    display_url = (ad.get("display_url") or "").lower()
    host = (ad.get("host") or "").lower()
    href = (ad.get("href") or "").lower()
    body = (ad.get("body_text") or "").lower()
    text_hay = " ".join([title, body])
    url_hay  = " ".join([host, display_url, href])

    for it in items:
        raw = (it or "").strip()
        if not raw:
            continue
        needle = raw.lower()
        has_wildcard = "*" in needle or "?" in needle
        is_url = needle.startswith("http://") or needle.startswith("https://")

        # URL-with-wildcard: glob against full URLs (href + display_url + host)
        if is_url and has_wildcard:
            pat = _glob_to_regex(needle)
            for candidate in (href, display_url, host):
                if candidate and pat.match(candidate):
                    return it
            continue
        # Plain URL: hostname-based match (display URLs rarely include the path)
        if is_url:
            try:
                host_only = (urlparse(raw).hostname or "").lower().lstrip("www.")
            except Exception:
                host_only = ""
            if needle in href:
                return it
            if host_only and host_only in url_hay:
                return it
            continue
        # Wildcard without scheme (e.g. "*.example.com/path*")
        if has_wildcard:
            pat = _glob_to_regex(needle)
            for candidate in (href, display_url, host, title, body):
                if candidate and pat.match(candidate):
                    return it
            continue
        is_domain = "." in needle
        if is_domain:
            if needle.startswith("www."):
                needle = needle[4:]
            if needle in url_hay:
                return it
            continue
        pat = re.compile(rf"\b{re.escape(needle)}\b", re.IGNORECASE)
        if pat.search(text_hay) or pat.search(url_hay):
            return it
    return None


def _session_metadata(s) -> dict:
    """Best-effort browser/session metadata snapshot."""
    return {
        "session_id": s.id,
        "engine": getattr(s, "engine", None),
        "mode": getattr(s.mode, "value", str(s.mode)),
        "headless": s.headless,
        "viewport": s.viewport,
        "profile_id": s.profile_id,
        "proxy_provider": s.proxy_provider,
        "proxy_zone": s.proxy_zone,
        "proxy_session_tag": s.proxy_session_tag,
        "proxy_egress_ip": s.proxy_egress_ip,
        "kind": s.kind,
    }


@task(
    name="google_ad_scan",
    label="Google search ad scan with green/orange watchlist highlight",
    session_spec={"mode": "stealth"},
    auto_session=True,
)
async def run_google_ad_scan(
    session_id: str,
    query: str,
    greenlist: list[str] | None = None,
    orangelist: list[str] | None = None,
    num: int = 20,
    settle_ms: int = 1500,
    screenshot: bool = True,
    report_dir: str | None = None,
    proxy: dict | None = None,
    auto_click: bool = False,
    auto_click_orange: bool = False,
) -> dict:
    """Search Google for `query` and classify visible ads.

    Args:
      query:      search keyword to enter into Google.
      greenlist:  list of strings; ads matching any string get dark-green highlight.
      orangelist: list of strings; ads matching any string get dark-orange highlight.
                  Greenlist wins if an ad matches both.
      num:        Google `&num=` parameter.
      settle_ms:  pause after DOMContentLoaded before scanning (ads render late).
      screenshot: write a full-page PNG of the highlighted SERP.
      report_dir: override output directory (defaults to data/ad_scans/<ts>_<slug>).
      auto_click: if True and any green/orange match exists, click the first matching ad.
      auto_click_orange: if True, click the first orangelisted ad (takes precedence over auto_click).

    Returns the report dict and the on-disk paths.
    """
    greenlist = [s for s in (greenlist or []) if s and s.strip()]
    orangelist = [s for s in (orangelist or []) if s and s.strip()]

    s = SessionRegistry.get().lookup(session_id)
    page = s.active_page()
    if page is None:
        raise RuntimeError("session has no active page")

    started_at = datetime.now(timezone.utc)
    t0 = time.perf_counter()

    # Per-run output directory — kept under the tasks folder so all run
    # artifacts (report, screenshot, debug log, HTML snapshots, step PNGs)
    # live next to the task code for easy inspection.
    ts = started_at.strftime("%Y%m%d_%H%M%S")
    slug = _safe_slug(query)
    out_dir = Path(report_dir) if report_dir else Path(__file__).resolve().parent / "_runs" / f"{ts}_{slug}"
    out_dir.mkdir(parents=True, exist_ok=True)
    rec = _DebugRecorder(out_dir)
    rec.line("task start",
             query=query, num=num, settle_ms=settle_ms,
             greenlist=greenlist, orangelist=orangelist,
             proxy=bool(proxy), engine=getattr(s, "engine", None),
             headless=s.headless, viewport=s.viewport,
             proxy_egress_ip=getattr(s, "proxy_egress_ip", None))

    # Homepage-first navigation: looks more like a real user than
    # ?q=... deep-linking, which Google fingerprints aggressively.
    # Pin to English UI so ad badges read "Sponsored" — otherwise locale
    # drift (jp, de, etc.) breaks text-based ad detection.
    url = f"https://www.google.com/search?q={quote_plus(query)}&num={num}&hl=en&gl=us"
    rec.line("goto homepage", url="https://www.google.com/?hl=en&gl=us")
    try:
        await page.goto("https://www.google.com/?hl=en&gl=us", wait_until="domcontentloaded", timeout=45000)
    except Exception as e:
        rec.line("goto homepage failed", err=str(e))
        raise
    await rec.snapshot(page, "homepage_loaded")
    dismissed = await _dismiss_consent(page)
    rec.line("consent dismissed", dismissed=dismissed)
    await _solve_captcha_if_any(page, s.id, attempts=2, proxy=proxy, rec=rec)

    # Type into the search box and click the search button.
    box = None
    for sel in ('textarea[name="q"]', 'input[name="q"]'):
        try:
            box = await page.wait_for_selector(sel, timeout=4000)
            if box:
                break
        except Exception:
            continue
    if box is None:
        rec.line("search box NOT FOUND — falling back to direct URL", url=url)
        await page.goto(url, wait_until="domcontentloaded")
    else:
        rec.line("search box found")
        await asyncio.sleep(random.uniform(0.35, 0.7))
        # H6 fix — Camoufox + this proxy sometimes stalls a vanilla
        # `box.click()` for 30s even though Playwright reports the element
        # "visible, enabled and stable, scrolling done, performing click
        # action…". Use a fast force-click; on failure fall back to
        # focus+keyboard which doesn't go through the same wait-for-receive
        # cycle, and finally to a direct hard-nav to the SERP URL.
        # #region agent log
        _h6_box_click_start = time.perf_counter()
        # #endregion
        click_ok = False
        try:
            await box.click(timeout=4000, force=True, no_wait_after=True)
            click_ok = True
            rec.line("box.click force ok",
                     ms=int((time.perf_counter() - _h6_box_click_start) * 1000))
        except Exception as e:
            rec.line("box.click force failed — falling back to focus",
                     err=str(e)[:240])
            try:
                await box.focus(timeout=4000)
                click_ok = True
                rec.line("box.focus ok",
                         ms=int((time.perf_counter() - _h6_box_click_start) * 1000))
            except Exception as e2:
                rec.line("box.focus failed — hard-nav to SERP",
                         err=str(e2)[:240])
        if not click_ok:
            try:
                await page.goto(url, wait_until="domcontentloaded", timeout=20000)
            except Exception as e3:
                rec.line("hard-nav to SERP also failed", err=str(e3)[:240])
        else:
            try:
                await box.fill("", timeout=4000)
            except Exception as e:
                rec.line("box.fill('') failed (continuing)", err=str(e)[:240])
            await _human_type(page, query, rec=rec)
            await rec.snapshot(page, "after_type")

        # Most real users finish their query and pick an autosuggest item
        # rather than re-aiming the mouse at the search button. The mouse
        # path through the dropdown looked like loitering, so submit via
        # keyboard: pause briefly to "read" the suggestions, ArrowDown to
        # pick one, then Enter. Total dropdown-interaction time: 2-5 s.
        pre_submit_url = page.url
        await _submit_via_suggestion_or_enter(page, rec)
        # Verify the submit actually navigated. Camoufox/Firefox can leave
        # the autosuggest+Enter path without navigating. If we're still on
        # the homepage 4s later, fall back: press Enter again on the box,
        # then if still stuck, hard-navigate to the SERP URL.
        navigated = False
        for _ in range(8):
            try:
                cur = page.url
                if "/search" in cur or "/sorry/" in cur or cur != pre_submit_url:
                    navigated = True
                    break
            except Exception:
                pass
            await asyncio.sleep(0.5)
        if not navigated:
            rec.line("submit didn't navigate — pressing Enter on the search box")
            try:
                await box.focus()
                await page.keyboard.press("Enter")
            except Exception as e:
                rec.line("re-Enter failed", err=str(e))
            for _ in range(8):
                cur = page.url
                if "/search" in cur or "/sorry/" in cur or cur != pre_submit_url:
                    navigated = True
                    break
                await asyncio.sleep(0.5)
        if not navigated:
            rec.line("re-Enter also failed — hard nav to SERP URL", url=url)
            try:
                await page.goto(url, wait_until="domcontentloaded", timeout=20000)
                navigated = True
            except Exception as e:
                rec.line("hard nav failed", err=str(e))
        try:
            await page.wait_for_load_state("domcontentloaded", timeout=15000)
        except Exception:
            rec.line("wait_for_load_state timed out")
        await rec.snapshot(page, "after_click")

    # Sorry/captcha interstitial check after submitting search
    await _solve_captcha_if_any(page, s.id, attempts=3, proxy=proxy, rec=rec)
    await _dismiss_consent(page)
    await rec.snapshot(page, "after_captcha_pass")

    # Settle loop: two phases.
    #  Phase 1 — wait for SERP shell to appear (or /sorry/ to redirect in).
    #  Phase 2 — once the shell is up, keep waiting for ad markers; Google
    #            lazy-loads sponsored blocks several seconds after the SERP
    #            renders. Don't scan as soon as `#search` shows up — that's
    #            far too early. Also try networkidle as a stronger signal.
    settle_s = max(0, settle_ms) / 1000.0
    phase1_deadline = time.perf_counter() + settle_s + 8.0
    serp_shell = False
    while time.perf_counter() < phase1_deadline:
        cur = page.url or ""
        if "/sorry/" in cur:
            # Confirm /sorry/ is real and stable — Google sometimes bounces
            # /search? → /sorry/ → /search? in <1s, and we don't want to
            # trigger a 90s re-solve for a transient redirect. Require the
            # URL to remain on /sorry/ AND a captcha element to be present
            # before committing to a re-solve.
            stable = True
            for _probe in range(4):  # 4 × 0.5s = ~2s confirmation window
                await asyncio.sleep(0.5)
                cur2 = page.url or ""
                if "/sorry/" not in cur2:
                    stable = False
                    rec.line("transient /sorry/ — recovered to SERP", url=cur2[:120])
                    break
            if not stable:
                continue
            try:
                has_captcha = await page.evaluate(
                    """() => !!document.querySelector(
                        'div.g-recaptcha[data-sitekey], div#recaptcha[data-sitekey], iframe[src*="recaptcha"]'
                    )"""
                )
            except Exception:
                has_captcha = False
            if not has_captcha:
                rec.line("stable /sorry/ URL but no captcha element — skipping re-solve")
                # Treat as transient; wait briefly and re-check
                await asyncio.sleep(0.5)
                continue
            rec.line("sorry page detected during settle — re-solving captcha")
            await _solve_captcha_if_any(page, s.id, attempts=3, proxy=proxy, rec=rec)
            await rec.snapshot(page, "after_late_captcha_pass")
            continue
        try:
            has_shell = await page.evaluate(
                "() => !!document.querySelector('#search, #rso, #rcnt')"
            )
        except Exception:
            has_shell = False
        if has_shell:
            serp_shell = True
            break
        await asyncio.sleep(0.4)
    if not serp_shell:
        rec.line("SERP shell never appeared during phase 1")

    # Trigger lazy-loaded ad slots by scrolling a bit and back
    try:
        await page.evaluate("() => window.scrollBy(0, 600)")
        await asyncio.sleep(0.4)
        await page.evaluate("() => window.scrollTo(0, 0)")
        await asyncio.sleep(0.3)
    except Exception:
        pass

    # Phase 2: wait for sponsored-block markers OR networkidle, max ~10s.
    rec.line("settle phase 2: waiting for ad markers / networkidle")
    try:
        await page.wait_for_load_state("networkidle", timeout=8000)
        rec.line("reached networkidle")
    except Exception:
        rec.line("networkidle not reached within 8s")
    # Wait for an ACTUAL rendered ad anchor with non-zero size (the data-text-ad
    # marker div has display:contents on Mexico SERPs; checking for the marker
    # alone is too early because the visible card hasn't laid out yet).
    ad_marker_deadline = time.perf_counter() + 8.0
    while time.perf_counter() < ad_marker_deadline:
        try:
            ad_count = await page.evaluate(
                """() => {
                  const anchors = document.querySelectorAll('a[data-pcu], a[data-rw]');
                  let n = 0;
                  for (const a of anchors) {
                    let p = a;
                    for (let i = 0; i < 10 && p; i++) {
                      const r = p.getBoundingClientRect();
                      if (r.width >= 200 && r.height >= 50) { n++; break; }
                      p = p.parentElement;
                    }
                  }
                  return n;
                }"""
            )
        except Exception:
            ad_count = 0
        if ad_count and ad_count > 0:
            rec.line("rendered ad anchors visible", count=ad_count)
            break
        await asyncio.sleep(0.4)
    else:
        rec.line("no rendered ad anchors found within 8s; scanning anyway")
    # Additional small grace for late-mounting sitelinks/imagery
    await asyncio.sleep(0.7)
    await rec.snapshot(page, "before_scan")

    ads = await page.evaluate(_AD_SCAN_JS)
    rec.line(f"detected {len(ads)} ad block(s)")
    log.info("google_ad_scan: detected {} ad block(s) for query={!r}", len(ads), query)

    # Classify
    matches_for_js: list[dict] = []
    classified: list[dict] = []
    for pos, ad in enumerate(ads, start=1):
        g = _match(ad, greenlist)
        o = _match(ad, orangelist) if not g else None
        list_name = "green" if g else ("orange" if o else None)
        matched_item = g or o
        entry = {
            "position": pos,
            "scan_id": ad["_scan_id"],
            "list": list_name,
            "matched_item": matched_item,
            "title": ad.get("title"),
            "display_url": ad.get("display_url"),
            "host": ad.get("host"),
            "href": ad.get("href"),
            "bbox": ad.get("bbox"),
            "body_text": ad.get("body_text"),
        }
        classified.append(entry)
        rec.line(f"ad #{pos}", list=list_name, match=matched_item,
                 host=ad.get("host"), title=(ad.get("title") or "")[:60])
        if list_name:
            matches_for_js.append({
                "scan_id": ad["_scan_id"],
                "list_name": list_name,
                "badge": f"{list_name.upper()}LIST · {matched_item}",
            })

    if matches_for_js:
        await page.evaluate(_HIGHLIGHT_JS, {"matches": matches_for_js})

    # Auto-click logic (Playwright-native):
    # Scroll the ad link into view, then perform a real mouse click.
    # - auto_click_orange takes precedence (first orangelisted ad)
    # - else general auto_click clicks the first green or orange match.
    async def _scroll_and_click_ad(scan_id: int) -> bool:
        card_sel = f'[data-pymcp-ad-scan="{scan_id}"]'
        card = page.locator(card_sel).first
        if await card.count() == 0:
            return False
        # Prefer the main ad anchor (data-rw / data-pcu / http)
        link = card.locator('a[data-rw], a[data-pcu], a[href^="http"]').first
        if await link.count() == 0:
            link = card.locator('a').first
        if await link.count() == 0:
            return False
        try:
            await link.scroll_into_view_if_needed(timeout=6000)
            await asyncio.sleep(random.uniform(0.25, 0.65))  # human-like pause
            await link.click(timeout=8000)
            return True
        except Exception as e:
            if rec:
                rec.line("_scroll_and_click_ad error", scan_id=scan_id, err=str(e))
            return False

    clicked = False
    clicked_list = None
    if auto_click_orange:
        orange_ms = [m for m in matches_for_js if m.get("list_name") == "orange"]
        if orange_ms:
            target_id = orange_ms[0]["scan_id"]
            try:
                did = await _scroll_and_click_ad(target_id)
                if did:
                    await asyncio.sleep(1.2)
                    try:
                        await page.wait_for_load_state("domcontentloaded", timeout=12000)
                    except Exception:
                        pass
                    clicked = True
                    clicked_list = "orange"
                    rec.line("auto-clicked orangelisted ad", scan_id=target_id, new_url=(page.url or "")[:120])
            except Exception as e:
                rec.line("auto_click_orange failed", err=str(e))
    if not clicked and auto_click and matches_for_js:
        first_id = matches_for_js[0]["scan_id"]
        try:
            did = await _scroll_and_click_ad(first_id)
            if did:
                await asyncio.sleep(1.2)
                try:
                    await page.wait_for_load_state("domcontentloaded", timeout=12000)
                except Exception:
                    pass
                clicked = True
                clicked_list = matches_for_js[0].get("list_name")
                rec.line("auto-clicked first match", scan_id=first_id, new_url=(page.url or "")[:120])
        except Exception as e:
            rec.line("auto_click failed", err=str(e))

    # Per-list presence/positions
    def _presence(items: list[str], list_name: str) -> list[dict]:
        out = []
        for it in items:
            hits = [c["position"] for c in classified
                    if c["list"] == list_name and (c["matched_item"] or "").lower() == it.lower()]
            out.append({
                "item": it,
                "appeared": bool(hits),
                "positions": hits,  # 1-based among ad blocks only
                "count": len(hits),
            })
        return out

    green_presence = _presence(greenlist, "green")
    orange_presence = _presence(orangelist, "orange")

    # out_dir was set near the top of the task (see _DebugRecorder init).
    screenshot_path: str | None = None
    if screenshot:
        shot = out_dir / "serp_highlighted.png"
        try:
            await page.screenshot(path=str(shot), full_page=True)
            screenshot_path = str(shot)
            rec.line("final screenshot written", path=str(shot))
        except Exception as e:
            log.warning("google_ad_scan: screenshot failed: {}", e)
            rec.line("final screenshot FAILED", err=str(e))

    page_title = await page.title()
    final_url = page.url

    report = {
        "schema_version": 1,
        "task": "google_ad_scan",
        "query": query,
        "started_at": started_at.isoformat(),
        "duration_ms": int((time.perf_counter() - t0) * 1000),
        "search_url": url,
        "final_url": final_url,
        "page_title": page_title,
        "session": _session_metadata(s),
        "user_agent": await page.evaluate("() => navigator.userAgent"),
        "watchlists": {
            "greenlist": greenlist,
            "orangelist": orangelist,
        },
        "summary": {
            "ads_detected": len(classified),
            "green_matches": sum(1 for c in classified if c["list"] == "green"),
            "orange_matches": sum(1 for c in classified if c["list"] == "orange"),
            "greenlist_appeared": sum(1 for p in green_presence if p["appeared"]),
            "greenlist_missing": [p["item"] for p in green_presence if not p["appeared"]],
            "orangelist_appeared": sum(1 for p in orange_presence if p["appeared"]),
            "orangelist_missing": [p["item"] for p in orange_presence if not p["appeared"]],
            "auto_clicked": clicked,
            "auto_clicked_list": clicked_list,
        },
        "greenlist_presence": green_presence,
        "orangelist_presence": orange_presence,
        "ads": classified,
        "artifacts": {
            "screenshot": screenshot_path,
            "report_json": str(out_dir / "report.json"),
        },
    }

    (out_dir / "report.json").write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")
    rec.line("report written",
             ads=report["summary"]["ads_detected"],
             green=report["summary"]["green_matches"],
             orange=report["summary"]["orange_matches"],
             duration_ms=report["duration_ms"])
    rec.close()
    return report


# ---------- CLI -----------------------------------------------------------------

def _split_csv(s: str | None) -> list[str]:
    if not s:
        return []
    return [x.strip() for x in s.replace("\n", ",").split(",") if x.strip()]


async def _cli_main(args) -> int:
    settings.ensure_dirs()
    greenlist = _split_csv(args.green)
    orangelist = _split_csv(args.orange)
    if args.green_file:
        greenlist += [ln.strip() for ln in Path(args.green_file).read_text(encoding="utf-8").splitlines() if ln.strip()]
    if args.orange_file:
        orangelist += [ln.strip() for ln in Path(args.orange_file).read_text(encoding="utf-8").splitlines() if ln.strip()]

    reg = SessionRegistry.get()
    sess = await reg.create(
        engine=args.engine, mode="stealth",
        headless=args.headless, no_proxy=True, proxy_provider=None,
    )
    try:
        report = await run_google_ad_scan(
            session_id=sess.id, query=args.query,
            greenlist=greenlist, orangelist=orangelist,
            num=args.num, settle_ms=args.settle_ms, screenshot=not args.no_screenshot,
        )
    finally:
        if not args.keep_open:
            try:
                if sess.context:
                    await sess.context.close()
            except Exception:
                pass
            sess.closed = True
    summary = report["summary"]
    print(f"ads_detected={summary['ads_detected']} "
          f"green={summary['green_matches']} orange={summary['orange_matches']}")
    print(f"report:     {report['artifacts']['report_json']}")
    print(f"screenshot: {report['artifacts']['screenshot']}")
    return 0


def _launch_gui() -> None:
    """Find and run the bundled tkinter launcher (sibling module)."""
    gui = Path(__file__).resolve().parent / "google_ad_scan_launcher.py"
    if not gui.exists():
        raise SystemExit(
            "GUI launcher not found at " + str(gui)
        )
    import runpy
    sys.argv = [str(gui)]
    runpy.run_path(str(gui), run_name="__main__")


def _cli() -> None:
    # Double-clicked from Explorer (no args) -> open the GUI launcher.
    if len(sys.argv) == 1:
        _launch_gui()
        return
    import argparse
    p = argparse.ArgumentParser(prog="google_ad_scan",
                                description="Run Google ad scan against a keyword.")
    p.add_argument("query", help="search keyword")
    p.add_argument("--green", help="comma- or newline-separated greenlist items")
    p.add_argument("--orange", help="comma- or newline-separated orangelist items")
    p.add_argument("--green-file", help="path to a file with one greenlist item per line")
    p.add_argument("--orange-file", help="path to a file with one orangelist item per line")
    p.add_argument("--engine", default="chromium",
                   choices=["chromium", "patchright", "camoufox"])
    p.add_argument("--num", type=int, default=20)
    p.add_argument("--settle-ms", type=int, default=1500)
    p.add_argument("--headless", action="store_true")
    p.add_argument("--no-screenshot", action="store_true")
    p.add_argument("--keep-open", action="store_true",
                   help="don't close the browser after the scan")
    args = p.parse_args()
    sys.exit(asyncio.run(_cli_main(args)))


if __name__ == "__main__":
    _cli()
