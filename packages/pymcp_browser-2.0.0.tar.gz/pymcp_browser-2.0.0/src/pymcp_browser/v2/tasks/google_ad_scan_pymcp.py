"""Google ad scan driven via PyMCP_Browser v2 REST API.

Mirrors the flow documented in `gooogle-ad-scan-task.md` (the Cursor-MCP
walkthrough), but talks to a running PyMCP_Browser v2 server instead.

Run the server first:
    python -m pymcp_browser.v2 api --host 127.0.0.1 --port 8765

Then:
    python google_ad_scan_pymcp.py "mens running shoes buy online us groundies" \\
        --orange "https://us.groundies.com/*" --click-orange
"""
from __future__ import annotations

import argparse
import json
import re
import sys
import time
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import urlparse

import httpx

# Bootstrap path to Tasks/Google_Ads_Scan/ so we can import activity_log.
# Resolves whether the script is run from src/ or Tasks/.
_HERE = Path(__file__).resolve()
for _candidate in (
    _HERE.parent,                                          # if installed alongside
    _HERE.parents[5] / "Tasks" / "Google_Ads_Scan",        # src/ → repo root → Tasks
    _HERE.parents[4] / "Tasks" / "Google_Ads_Scan",
):
    if (_candidate / "activity_log.py").is_file():
        if str(_candidate) not in sys.path:
            sys.path.insert(0, str(_candidate))
        break
try:
    from activity_log import EventEmitter  # type: ignore
except Exception:  # pragma: no cover
    EventEmitter = None  # type: ignore


DEFAULT_BASE = "http://127.0.0.1:8765"

# FusionProxy preset — used by the inline /sorry/ solver to pin the capsolver
# task to the same egress IP as the browser. Override with --proxy-host etc.
DEFAULT_FUSION_PROXY = {
    "host": "resi.fusionproxy.net", "port": 13375,
    "user": "ti9xt628jf18-country-mx", "pass": "g2xks20toq26",
}


# Ported from google_ad_scan.py — runs in the page, finds Google text-ad cards,
# stamps `data-pymcp-ad-scan="<idx>"` on each so we can click via CSS selector.
_AD_SCAN_JS = r"""
() => {
  function visibleRect(el) {
    if (!el) return null;
    const r = el.getBoundingClientRect();
    if (r.width < 100 || r.height < 30) return null;
    const cs = getComputedStyle(el);
    if (cs.display === 'none' || cs.visibility === 'hidden') return null;
    return r;
  }
  function destUrl(a) {
    if (!a) return '';
    const pcu = a.getAttribute('data-pcu');
    if (pcu) return pcu.split(',')[0].trim();
    const candidate = a.href || a.getAttribute('data-rw') || '';
    try {
      const u = new URL(candidate, location.origin);
      const ad = u.searchParams.get('adurl') || u.searchParams.get('aurl');
      if (ad) return decodeURIComponent(ad);
    } catch (e) {}
    return candidate;
  }
  // Parse a host out of the visible "display URL" element (or any string).
  // Used as a fallback when destUrl() resolves to google.com/aclk because
  // neither data-pcu nor &adurl= was usable. Accepts:
  //   "https://us.groundies.com"     → "us.groundies.com"
  //   "us.groundies.com › sale"      → "us.groundies.com"
  //   "Inspire Uplift" (merchant name, not a host) → ""
  function hostFromText(s) {
    if (!s) return '';
    const trimmed = String(s).trim();
    try {
      if (/^https?:\/\//i.test(trimmed)) {
        return new URL(trimmed).hostname.replace(/^www\./, '');
      }
    } catch (e) {}
    const m = trimmed.match(/([a-z0-9-]+(?:\.[a-z0-9-]+)+)/i);
    return m ? m[1].toLowerCase().replace(/^www\./, '') : '';
  }
  function isGoogleHost(h) {
    return !h || h === 'google.com' || h.endsWith('.google.com');
  }
  function climbToCard(a) {
    let p = a;
    for (let i = 0; i < 12 && p; i++) {
      if (p.tagName === 'BODY' || p.tagName === 'HTML') break;
      const r = visibleRect(p);
      if (r && r.width >= 200 && r.width <= 1100
          && r.height >= 90 && r.height <= 700) {
        const hasHead = p.querySelector('div[role="heading"], h3, [role="heading"]');
        const hasDisp = p.querySelector('span.x2VHCd, span.qzEoUe, .VuuXrf, cite');
        if (hasHead && hasDisp) return p;
      }
      p = p.parentElement;
    }
    return null;
  }
  const accepted = new Map();
  const out = [];
  let idx = 0;
  function emit(card, a) {
    if (!card || accepted.has(card)) return;
    let anc = card.parentElement;
    while (anc) { if (accepted.has(anc)) return; anc = anc.parentElement; }
    const rect = card.getBoundingClientRect();
    if (rect.width < 100 || rect.height < 30) return;
    const href = destUrl(a);
    let host = '';
    try { host = new URL(href).hostname.replace(/^www\./, ''); } catch (e) {}
    const titleEl = card.querySelector('div[role="heading"], h3, [role="heading"] span, [role="heading"]');
    const title = titleEl ? (titleEl.innerText || titleEl.textContent || '').trim() : '';
    const dispEl = card.querySelector('span.x2VHCd, span.qzEoUe, .VuuXrf, cite');
    const display_url = dispEl ? (dispEl.innerText || '').trim() : '';
    // Fallback: when destUrl resolved to a google.com/aclk redirect (no
    // data-pcu, no &adurl=), recover the advertiser host from the visible
    // display URL on the card.
    if (isGoogleHost(host)) {
      const dispHost = hostFromText(display_url);
      if (dispHost && !isGoogleHost(dispHost)) host = dispHost;
    }
    const body_text = ((card.innerText || '').replace(/\s+/g, ' ').trim()).slice(0, 400);
    idx += 1;
    accepted.set(card, idx);
    out.push({
      scan_id: idx, title, display_url, host, href,
      aclk_href: (a && (a.href || a.getAttribute('data-rw'))) || '',
      body_text,
      bbox: { x: Math.round(rect.left), y: Math.round(rect.top),
              w: Math.round(rect.width), h: Math.round(rect.height) },
    });
    card.setAttribute('data-pymcp-ad-scan', String(idx));
  }
  for (const a of document.querySelectorAll('a[data-pcu], a[data-rw], a[href*="aclk"]')) {
    const rw = a.getAttribute('data-rw') || '';
    const pcu = a.getAttribute('data-pcu') || '';
    const hrefAttr = a.getAttribute('href') || '';
    const isAd = pcu || /aclk/.test(rw) || /aclk/.test(hrefAttr) || /aclk/.test(a.href || '');
    if (!isAd) continue;
    const card = climbToCard(a);
    if (!card) continue;
    emit(card, a);
  }

  // === Google Shopping / Product Listing Ads (PLA) ===
  // These don't match the text-ad heuristic above. They're individual product
  // cards in the "Sponsored products" carousel. Identifier: .pla-unit-container
  // wrapper. Each contains an img + price + merchant name + aclk anchor.
  function pickPlaCards() {
    let nodes = document.querySelectorAll('div.pla-unit-container');
    if (nodes.length === 0) nodes = document.querySelectorAll('div.pla-unit');
    return nodes;
  }
  const priceRe = /(MX\$|US\$|CA\$|AU\$|R\$|\$|€|£|¥|₹)\s?[\d.,]+/;
  for (const card of pickPlaCards()) {
    if (accepted.has(card)) continue;
    const rect = card.getBoundingClientRect();
    if (rect.width < 60 || rect.height < 120) continue;
    const a = card.querySelector('a[href*="aclk"]') || card.querySelector('a[href]');
    if (!a) continue;
    let href = a.href || '';
    try {
      const u = new URL(href, location.origin);
      const adurl = u.searchParams.get('adurl') || u.searchParams.get('aurl');
      if (adurl) href = decodeURIComponent(adurl);
    } catch (e) {}
    let host = '';
    try { host = new URL(href).hostname.replace(/^www\./, ''); } catch (e) {}
    // Title — usually the first non-price text line; bold/blue link text on shopping cards
    const titleEl = card.querySelector('div[role="heading"], h3, h4, .pla-unit-title');
    if (isGoogleHost(host)) {
      const fallback = hostFromText(card.querySelector('.pla-unit-title-link, .LbUacb, cite')?.innerText || '');
      if (fallback && !isGoogleHost(fallback)) host = fallback;
    }
    const title = (titleEl ? titleEl.innerText : '').trim();
    const fullText = (card.innerText || '').replace(/\s+/g, ' ').trim();
    const priceMatch = fullText.match(priceRe);
    const price = priceMatch ? priceMatch[0] : '';
    // Merchant — the line right after the price string
    let merchant = '';
    const rawLines = (card.innerText || '').split('\n').map(s => s.trim()).filter(Boolean);
    for (let i = 0; i < rawLines.length; i++) {
      if (priceRe.test(rawLines[i]) && i + 1 < rawLines.length) {
        merchant = rawLines[i + 1].slice(0, 60);
        break;
      }
    }
    idx += 1;
    accepted.set(card, idx);
    out.push({
      scan_id: idx,
      kind: 'shopping',
      title: title || (rawLines[0] || '').slice(0, 80),
      display_url: merchant,        // merchant doubles as display_url for shopping
      host,                          // real host extracted from aclk's adurl param
      href,
      aclk_href: a.href || '',
      body_text: fullText.slice(0, 400),
      price,
      merchant,
      bbox: { x: Math.round(rect.left), y: Math.round(rect.top),
              w: Math.round(rect.width), h: Math.round(rect.height) },
    });
    card.setAttribute('data-pymcp-ad-scan', String(idx));
  }

  return out;
}
"""


# Organic-results scanner. Runs after _AD_SCAN_JS so cards already carry
# data-pymcp-ad-scan="N"; we use that to exclude sponsored cards from the
# organic list. Captures: position, title, url, host, display_url, snippet.
# Modern Google SERPs nest organic results under `div.g`, `div[data-snhf]`,
# or wrappers identified by a child `<h3>` whose ancestor `<a>` carries an
# external http(s) href. We use the h3-anchor heuristic since the class
# names rotate frequently.
_ORGANIC_SCAN_JS = r"""
() => {
  function visibleRect(el) {
    if (!el) return null;
    const r = el.getBoundingClientRect();
    if (r.width < 100 || r.height < 30) return null;
    const cs = getComputedStyle(el);
    if (cs.display === 'none' || cs.visibility === 'hidden') return null;
    return r;
  }
  function isInsideAdCard(el) {
    let p = el;
    while (p && p !== document.body) {
      if (p.hasAttribute && p.hasAttribute('data-pymcp-ad-scan')) return true;
      p = p.parentElement;
    }
    return false;
  }
  function climbToResult(a) {
    let p = a;
    for (let i = 0; i < 14 && p; i++) {
      if (p.tagName === 'BODY' || p.tagName === 'HTML') break;
      // Recognised organic-result wrappers
      if (p.classList && (
            p.classList.contains('g') ||
            p.classList.contains('MjjYud') ||
            p.classList.contains('tF2Cxc') ||
            p.classList.contains('N54PNb')
          )) return p;
      if (p.hasAttribute && (
            p.hasAttribute('data-sokoban-container') ||
            p.hasAttribute('data-snhf') ||
            p.hasAttribute('data-hveid')
          )) {
        const r = visibleRect(p);
        if (r && r.width >= 200) return p;
      }
      p = p.parentElement;
    }
    return null;
  }
  const seen = new Map();
  const out = [];
  let idx = 0;
  for (const h3 of document.querySelectorAll('h3')) {
    if (isInsideAdCard(h3)) continue;
    const a = h3.closest('a[href]');
    if (!a) continue;
    const href = a.href || '';
    if (!/^https?:/i.test(href)) continue;
    // Skip self-referential google links (people-also-ask, image carousels,
    // /search?... pivots — none of which are organic results).
    let host = '';
    try { host = new URL(href).hostname.replace(/^www\./, ''); } catch (e) {}
    if (!host || host === 'google.com' || host.endsWith('.google.com')) continue;
    const card = climbToResult(a) || h3.parentElement;
    if (!card || seen.has(card)) continue;
    const rect = card.getBoundingClientRect();
    if (rect.width < 100 || rect.height < 20) continue;
    const title = (h3.innerText || h3.textContent || '').trim();
    if (!title) continue;
    const citeEl = card.querySelector('cite');
    const display_url = citeEl ? (citeEl.innerText || '').trim() : '';
    // Snippet — Google rotates the class but it's typically the longest
    // text node under the card that isn't the title/url.
    let snippet = '';
    const snipEl = card.querySelector(
      'div[data-sncf], div.VwiC3b, div.IsZvec, span.aCOpRe, div.lyLwlc'
    );
    if (snipEl) snippet = (snipEl.innerText || '').trim();
    if (!snippet) {
      // Fallback: card innerText minus the title and display URL
      const all = (card.innerText || '').replace(/\s+/g, ' ').trim();
      snippet = all.replace(title, '').replace(display_url, '').trim().slice(0, 400);
    } else {
      snippet = snippet.slice(0, 400);
    }
    idx += 1;
    seen.set(card, idx);
    out.push({
      position: idx,
      title,
      url: href,
      host,
      display_url,
      snippet,
      bbox: { x: Math.round(rect.left), y: Math.round(rect.top),
              w: Math.round(rect.width), h: Math.round(rect.height) },
    });
    card.setAttribute('data-pymcp-organic-scan', String(idx));
  }
  return out;
}
"""


# Landing-page meta extractor. Runs on whatever the active tab points at
# after the auto-click navigates away from google.com — captures the full
# URL (including all gclid/utm/cq_* params for downstream attribution),
# title, canonical, language, and every <meta name=...> / <meta property=...>
# tag the page exposes. Saved alongside the report as landing_page.json
# AND embedded in report.landing_page for self-contained consumption.
_LANDING_META_JS = r"""
() => {
  const out = {
    url: location.href,
    final_host: location.hostname.replace(/^www\./, ''),
    title: document.title || '',
    lang: document.documentElement.getAttribute('lang') || '',
    canonical: '',
    meta: {},
    og: {},
    twitter: {},
    links: {},
    has_gclid: /[?&]gclid=/.test(location.href),
    has_utm: /[?&]utm_/.test(location.href),
  };
  // Canonical + alternate links
  const canon = document.querySelector('link[rel="canonical"]');
  if (canon) out.canonical = canon.getAttribute('href') || '';
  for (const rel of ['icon', 'apple-touch-icon', 'manifest', 'alternate']) {
    const el = document.querySelector(`link[rel="${rel}"]`);
    if (el && el.getAttribute('href')) out.links[rel] = el.getAttribute('href');
  }
  // All meta tags. Split into og:* / twitter:* / generic.
  for (const m of document.querySelectorAll('meta')) {
    const name = (m.getAttribute('name') || m.getAttribute('property')
                 || m.getAttribute('http-equiv') || '').trim();
    const content = (m.getAttribute('content') || '').trim();
    if (!name || !content) continue;
    const key = name.toLowerCase();
    if (key.startsWith('og:')) out.og[key.slice(3)] = content;
    else if (key.startsWith('twitter:')) out.twitter[key.slice(8)] = content;
    else out.meta[key] = content;
  }
  // Helpful diagnostic: any JSON-LD script blocks
  out.json_ld_count = document.querySelectorAll(
    'script[type="application/ld+json"]'
  ).length;
  return out;
}
"""


# CSS injected once + sets data-pymcp-list="green|orange" on matched cards.
# Cards already carry data-pymcp-ad-scan="N" from _AD_SCAN_JS.
_HIGHLIGHT_JS = r"""
(payload) => {
  const { matches } = payload;
  let style = document.getElementById('pymcp-ad-highlight-style');
  if (!style) {
    style = document.createElement('style');
    style.id = 'pymcp-ad-highlight-style';
    style.textContent = `
      [data-pymcp-list="green"] {
        background: #14532d !important;
        color: #ffffff !important;
        outline: 3px solid #14532d !important;
        outline-offset: 2px !important;
        border-radius: 6px !important;
      }
      [data-pymcp-list="orange"] {
        background: #9a3412 !important;
        color: #ffffff !important;
        outline: 3px solid #9a3412 !important;
        outline-offset: 2px !important;
        border-radius: 6px !important;
      }
      [data-pymcp-list] *,
      [data-pymcp-list] a,
      [data-pymcp-list] cite,
      [data-pymcp-list] span,
      [data-pymcp-list] h3,
      [data-pymcp-list] div {
        color: #ffffff !important;
        background-color: transparent !important;
      }
      [data-pymcp-list]::before {
        content: attr(data-pymcp-badge);
        display: inline-block;
        background: #000;
        color: #fff;
        font: 700 11px/1.4 system-ui, sans-serif;
        padding: 2px 8px;
        margin: 0 0 6px 0;
        border-radius: 4px;
      }
    `;
    document.head.appendChild(style);
  }
  let applied = 0;
  for (const m of matches) {
    const el = document.querySelector(`[data-pymcp-ad-scan="${m.scan_id}"]`);
    if (!el) continue;
    const r = el.getBoundingClientRect();
    if (r.height > 800 || r.width < 100) continue;
    el.setAttribute('data-pymcp-list', m.list_name);
    el.setAttribute('data-pymcp-badge', m.badge);
    applied += 1;
  }
  return applied;
}
"""


class PyMCPClient:
    def __init__(self, base_url: str, token: str | None = None, timeout: float = 60.0):
        headers = {"Content-Type": "application/json"}
        if token:
            headers["Authorization"] = f"Bearer {token}"
        self.http = httpx.Client(base_url=base_url, headers=headers, timeout=timeout)

    def call(self, tool: str, **args) -> dict:
        r = self.http.post(f"/tools/{tool}", json=args)
        try:
            data = r.json()
        except Exception:
            r.raise_for_status()
            raise
        if r.status_code >= 400:
            raise RuntimeError(f"{tool} failed [{r.status_code}]: {data}")
        return data

    def close(self) -> None:
        self.http.close()


def _glob_to_regex(pat: str) -> re.Pattern:
    out = []
    for ch in pat:
        if ch == "*":
            out.append(".*")
        elif ch == "?":
            out.append(".")
        else:
            out.append(re.escape(ch))
    return re.compile("^" + "".join(out) + "$", re.IGNORECASE)


def _host_of(url: str) -> str:
    try:
        return (urlparse(url).hostname or "").lower().lstrip("www.")
    except Exception:
        return ""


def _match_item(haystacks: list[str], item: str) -> bool:
    needle = (item or "").strip().lower()
    if not needle:
        return False
    has_wild = "*" in needle or "?" in needle
    if has_wild:
        pat = _glob_to_regex(needle)
        return any(h and pat.match(h) for h in haystacks)
    if needle.startswith("http://") or needle.startswith("https://"):
        host_only = _host_of(needle)
        return any(needle in h for h in haystacks) or (
            bool(host_only) and any(host_only in h for h in haystacks)
        )
    return any(needle in h for h in haystacks)


_LINE_RE = re.compile(
    r"^(?P<indent>\s*)-\s+"
    r"(?P<role>[A-Za-z_][A-Za-z0-9_-]*)"
    r"(?:\s+\"(?P<name>(?:[^\"]|\\\")*)\")?"
    r"(?:\s+\[ref=(?P<ref>[A-Za-z0-9_]+)\])?"
    r".*$"
)


def _parse_line(ln: str) -> dict | None:
    m = _LINE_RE.match(ln)
    if not m:
        return None
    indent = len(m.group("indent"))
    return {
        "indent": indent,
        "role": (m.group("role") or "").lower(),
        "name": m.group("name") or "",
        "ref": m.group("ref") or "",
    }


def parse_ads_from_snapshot(snapshot_text: str) -> list[dict]:
    """Scan an inspect.snapshot YAML dump for sponsored-ad blocks.

    PyMCP snapshot format (see core/snapshot.py):
        - heading "Sponsored result" [ref=e262]:
          - heading "Groundies North America Inc" [ref=e263]:
          - link "Groundies https://us.groundies.com" [ref=e72]
          - button "Why this ad?" [ref=e73]
          - button "Hide sponsored result" [ref=e79]

    Anchor on `heading "Sponsored result"`, then collect more-indented
    descendants until we de-indent back to <= anchor indent.
    """
    parsed = [(_parse_line(ln), ln) for ln in snapshot_text.splitlines()]
    parsed = [(p, ln) for p, ln in parsed if p is not None]
    ads: list[dict] = []

    for i, (p, _ln) in enumerate(parsed):
        if p["role"] != "heading" or p["name"].strip().lower() != "sponsored result":
            continue
        anchor_indent = p["indent"]
        title = ""
        primary_link: dict | None = None
        sitelinks: list[dict] = []
        # Walk forward while indent > anchor_indent
        for q, _ln2 in parsed[i + 1:]:
            if q["indent"] <= anchor_indent:
                break
            # Stop early at the "Hide sponsored result" sentinel
            if q["role"] == "button" and "hide sponsored result" in q["name"].lower():
                break
            if q["role"] == "heading" and not title and q["name"]:
                title = q["name"]
            if q["role"] == "link" and q["name"] and q["ref"]:
                if primary_link is None:
                    primary_link = {"name": q["name"], "ref": q["ref"]}
                else:
                    sitelinks.append({"name": q["name"], "ref": q["ref"]})

        if primary_link is None:
            continue
        name = primary_link["name"]
        url_m = re.search(r"(https?://[^\s\"]+)", name)
        display_url = url_m.group(1) if url_m else ""
        host = _host_of(display_url)
        ads.append({
            "position": len(ads) + 1,
            "title": title or name.split("  ")[0].strip(),
            "link_name": name,
            "link_ref": primary_link["ref"],
            "display_url": display_url,
            "host": host,
            "sitelinks": sitelinks,
        })
    return ads


def _load_capsolver_key() -> str | None:
    """Read capsolver API key from data/credentials.json relative to project root."""
    here = Path(__file__).resolve()
    for parent in (here.parents[4], here.parents[5]):
        try:
            cred = parent / "data" / "credentials.json"
            if cred.is_file():
                d = json.loads(cred.read_text(encoding="utf-8"))
                key = (d.get("capsolver") or {}).get("api_key")
                if key:
                    return key
        except Exception:
            continue
    return None


def run_scan(
    query: str,
    orangelist: list[str],
    greenlist: list[str],
    *,
    base_url: str,
    token: str | None,
    engine: str,
    mode: str,
    headless: bool,
    click_orange: bool,
    out_dir: Path,
    session_id: str | None = None,
    keep_open: bool = False,
    sorry_proxy: dict | None = None,
    capsolver_key: str | None = None,
    locale: str = "en-us",
) -> dict:
    started_at = datetime.now(timezone.utc)
    t0 = time.perf_counter()
    out_dir.mkdir(parents=True, exist_ok=True)
    log_path = out_dir / "debug.log"
    log_fp = open(log_path, "w", encoding="utf-8")
    # Realtime activity stream (JSONL). Consumers tail this file.
    emitter = EventEmitter(out_dir / "events.jsonl") if EventEmitter else None

    def log(msg: str, **kv) -> None:
        ts = datetime.now().strftime("%H:%M:%S.%f")[:-3]
        extra = " ".join(f"{k}={v}" for k, v in kv.items())
        line = f"[{ts}] {msg}" + (f"  {extra}" if extra else "")
        print(line, flush=True)
        log_fp.write(line + "\n")
        log_fp.flush()
        if emitter:
            try:
                emitter.emit(msg, **kv)
            except Exception:
                pass  # never let the activity stream break the task

    c = PyMCPClient(base_url, token=token)
    sid: str | None = None
    error_occurred = False

    # Tier 1: persistent storage_state. Caller threads the profile
    # path through the (otherwise dict-shaped) `sorry_proxy` argument
    # under a magic key so we don't have to change the signature.
    # Pop it so the capsolver task spec doesn't see an extra field.
    state_path: str | None = None
    if isinstance(sorry_proxy, dict):
        state_path = sorry_proxy.pop("__state_path__", None) or None
        # If only the magic key was inside, treat sorry_proxy as absent.
        if not sorry_proxy:
            sorry_proxy = None

    _BANNER_JS = r"""
    (msg) => {
      let b = document.getElementById('pymcp-step-banner');
      if (!b) {
        b = document.createElement('div');
        b.id = 'pymcp-step-banner';
        b.style.cssText = [
          'position:fixed','top:0','left:0','right:0','z-index:2147483647',
          'padding:10px 16px','font:600 13px/1.4 system-ui,Segoe UI,Arial,sans-serif',
          'color:#fff','background:#1f6feb','text-align:center','letter-spacing:.2px',
          'box-shadow:0 3px 10px rgba(0,0,0,.35)','pointer-events:none',
        ].join(';');
        (document.body || document.documentElement).appendChild(b);
      }
      const ts = new Date().toLocaleTimeString();
      b.textContent = '[' + ts + ']  ' + msg;
      return true;
    }
    """

    def banner(msg: str) -> None:
        if not sid:
            return
        try:
            c.call("inspect.evaluate", session_id=sid, js=_BANNER_JS, args=[msg])
        except Exception:
            pass  # banner is best-effort; never block the flow

    def _solve_sorry_if_needed(proxy: dict | None = None,
                               capsolver_key: str | None = None,
                               max_wait_s: int = 240) -> bool:
        """If the active page is on /sorry/ with an inline g-recaptcha, solve via
        capsolver (proxy-pinned) and submit the form. Returns True if we left
        /sorry/ (or weren't on it to begin with).

        Bug B10 workaround: PyMCP's captcha.auto only catches iframe-anchored
        recaptchas; Google /sorry/ uses an inline <div class="g-recaptcha">.
        """
        if not sid:
            return False
        try:
            cur = c.call("inspect.evaluate", session_id=sid,
                         js="() => location.href")["result"]
        except Exception:
            return False
        if "/sorry/" not in (cur or ""):
            return True

        if not capsolver_key:
            log("on /sorry/ but no capsolver key — cannot auto-solve")
            banner("ON /sorry/ — no capsolver key available")
            return False

        banner("On /sorry/ — waiting for recaptcha widget to mount")
        # The g-recaptcha div may not be present yet on a half-loaded
        # /sorry/ page; wait for it before reading sitekey/data-s.
        try:
            c.call("wait.selector", session_id=sid,
                   target=("div.g-recaptcha[data-sitekey], "
                           "div#recaptcha[data-sitekey]"),
                   state="visible", timeout_ms=10000)
        except Exception as e:
            log("wait for /sorry/ recaptcha div soft-fail", err=str(e)[:160])
        banner("On /sorry/ — extracting sitekey + data-s")
        js_info = r"""
        () => {
          const div = document.querySelector(
            'div.g-recaptcha[data-sitekey], div#recaptcha[data-sitekey]'
          );
          if (!div) return { found: false };
          const enterprise = !!document.querySelector('script[src*="recaptcha/enterprise"]');
          return {
            found: true,
            sitekey: div.getAttribute('data-sitekey'),
            data_s: div.getAttribute('data-s') || null,
            enterprise, url: location.href,
          };
        }
        """
        info = c.call("inspect.evaluate", session_id=sid, js=js_info)["result"]
        if not info.get("found"):
            log("no g-recaptcha div on /sorry/ — Google may have changed layout")
            return False

        sitekey = info["sitekey"]
        data_s = info.get("data_s")
        page_url = info["url"]
        enterprise = bool(info.get("enterprise"))
        log("found /sorry/ recaptcha", sitekey=sitekey[:14], enterprise=enterprise)

        # Build capsolver task — proxy-bound if we have proxy details
        task_type = "ReCaptchaV2EnterpriseTask" if enterprise else "ReCaptchaV2Task"
        if not proxy:
            task_type += "Proxyless"
        cs_task: dict = {
            "type": task_type, "websiteURL": page_url, "websiteKey": sitekey,
            "isInvisible": False, "pageAction": "submit",
        }
        if data_s:
            cs_task["enterprisePayload"] = {"s": data_s}
        if proxy:
            cs_task["proxyType"] = "http"
            cs_task["proxyAddress"] = proxy["host"]
            cs_task["proxyPort"] = int(proxy["port"])
            if proxy.get("user"):
                cs_task["proxyLogin"] = proxy["user"]
            if proxy.get("pass"):
                cs_task["proxyPassword"] = proxy["pass"]

        banner(f"Submitting reCAPTCHA{' Enterprise' if enterprise else ''} to capsolver")
        log("capsolver createTask request",
            task_type=task_type, has_proxy=bool(proxy),
            proxy_host=(proxy or {}).get("host"))
        with httpx.Client(timeout=60) as cli:
            try:
                r = cli.post("https://api.capsolver.com/createTask",
                             json={"clientKey": capsolver_key, "task": cs_task})
            except Exception as e:
                log("capsolver createTask HTTP error", err=str(e)[:200])
                banner("capsolver createTask HTTP error")
                return False
            try:
                cdata = r.json()
            except Exception as e:
                log("capsolver createTask non-JSON",
                    status=r.status_code, body=r.text[:200])
                return False
            log("capsolver createTask response",
                status=r.status_code, errorId=cdata.get("errorId"),
                errorCode=cdata.get("errorCode"),
                errorDescription=cdata.get("errorDescription"),
                taskId=cdata.get("taskId"))
            if cdata.get("errorId"):
                log("capsolver createTask error", err=cdata)
                banner(f"capsolver createTask failed: {cdata.get('errorDescription')}")
                return False
            task_id = cdata.get("taskId")
            if not task_id:
                log("capsolver createTask returned no taskId", body=cdata)
                return False
            banner(f"capsolver taskId={task_id[:8]}… — polling")
            token: str | None = None
            deadline = time.time() + max_wait_s
            poll = 0
            last_status: str = ""
            while time.time() < deadline:
                time.sleep(3)
                poll += 1
                try:
                    r = cli.post("https://api.capsolver.com/getTaskResult",
                                 json={"clientKey": capsolver_key,
                                       "taskId": task_id})
                except Exception as e:
                    log("capsolver getTaskResult HTTP error", poll=poll,
                        err=str(e)[:200])
                    continue
                try:
                    d = r.json()
                except Exception as e:
                    log("capsolver getTaskResult non-JSON", poll=poll,
                        status=r.status_code, body=r.text[:200])
                    continue
                status = d.get("status") or ""
                if status != last_status:
                    log("capsolver poll status change", poll=poll,
                        status=status, errorId=d.get("errorId"),
                        errorCode=d.get("errorCode"),
                        errorDescription=d.get("errorDescription"))
                    last_status = status
                if status == "ready":
                    sol = d.get("solution") or {}
                    token = sol.get("gRecaptchaResponse") or ""
                    log("capsolver ready", poll=poll, token_len=len(token))
                    break
                if d.get("errorId"):
                    log("capsolver getTaskResult error", poll=poll, err=d)
                    banner(f"capsolver getTaskResult failed: {d.get('errorDescription')}")
                    return False
                if poll % 4 == 0:
                    banner(f"capsolver still processing (poll {poll})")
            if not token:
                log("capsolver token empty after polling",
                    polls=poll, elapsed_s=int(time.time() - (deadline - max_wait_s)))
                banner("capsolver timed out")
                return False

        banner(f"Token received ({len(token)} chars) — submitting /sorry/ form")
        js_submit = r"""
        (tok) => {
          let ta = document.getElementById('g-recaptcha-response');
          if (!ta) {
            ta = document.createElement('textarea');
            ta.id = 'g-recaptcha-response';
            ta.name = 'g-recaptcha-response';
            ta.style.display = 'none';
            document.body.appendChild(ta);
          }
          ta.value = tok;
          if (typeof submitCallback === 'function') {
            try { submitCallback(tok); return 'submitCallback'; } catch(e) {}
          }
          const f = document.getElementById('captcha-form')
                 || document.querySelector('form[action*="sorry"]')
                 || document.querySelector('form');
          if (f) { f.submit(); return 'form.submit'; }
          return 'no_form';
        }
        """
        try:
            c.call("inspect.evaluate", session_id=sid, js=js_submit, args=[token])
        except Exception as e:
            # "Execution context destroyed" = navigation success
            log("submit eval (expected post-nav error ok)", err=str(e)[:120])

        # Wait for /sorry/ to clear
        for i in range(20):
            time.sleep(1.5)
            try:
                cur2 = c.call("inspect.evaluate", session_id=sid,
                              js="() => location.href")["result"]
            except Exception:
                continue
            if "/sorry/" not in (cur2 or ""):
                banner(f"/sorry/ cleared — landed on {cur2[:60]}…")
                log("captcha solved", final_url=cur2[:160])
                return True
        banner("Form submitted but still on /sorry/ — giving up")
        return False
    try:
        if session_id:
            sid = session_id
            log("using pre-existing session", session_id=sid)
        else:
            log("session.create", engine=engine, mode=mode, headless=headless)
            sess = c.call(
                "session.create",
                engine=engine,
                mode=mode,
                headless=headless,
                no_proxy=True,
            )
            sid = sess.get("session_id") or sess.get("id")
            if not sid:
                raise RuntimeError(f"session.create returned no id: {sess}")
            log("session ok", session_id=sid)

        # Step 1 — homepage
        hl = locale.split("-")[0] if "-" in locale else locale
        gl = (locale.split("-")[1] if "-" in locale else "us").lower()
        c.call("nav.go", session_id=sid,
               url=f"https://www.google.com/?hl={hl}&gl={gl}",
               wait_until="domcontentloaded", timeout_ms=30000)
        banner("Step 1: loaded Google homepage")
        try:
            c.call("wait.stable", session_id=sid, target="body",
                   debounce_ms=500, timeout_ms=5000)
        except Exception as e:
            log("wait.stable homepage soft-fail", err=str(e)[:160])
        # Wait for the search textarea to be VISIBLE (not just attached)
        # before we try to click/fill it.
        try:
            c.call("wait.selector", session_id=sid,
                   target="textarea[name=q], input[name=q]",
                   state="visible", timeout_ms=8000)
        except Exception as e:
            log("wait.selector search textarea soft-fail", err=str(e)[:160])
        banner("Step 1: homepage settled")

        c.call("inspect.screenshot", session_id=sid,
               full_page=False)  # response includes path or bytes; ignored here
        # We persist our own screenshots by reading the active tab via
        # inspect.screenshot — server-side path is in the response.
        shot1 = c.call("inspect.screenshot", session_id=sid, full_page=False)
        log("homepage screenshot", path=shot1.get("path") or shot1.get("file"))

        # Step 2 — find the search combobox via locate.role
        # target params in PyMCP are STRINGS: either a ref like "e1" (regex ^e\d+$)
        # or a CSS selector. Never a dict.
        search_target: str | None = None
        try:
            box = c.call("locate.role", session_id=sid, role="combobox",
                         name="Search", limit=1)
            items = box.get("matches") or box.get("items") or box.get("results") or []
            if items:
                ref = items[0].get("ref") or items[0].get("id")
                if ref:
                    search_target = ref
                    log("found search combobox", ref=ref)
        except Exception as e:
            log("locate.role combobox soft-fail", err=str(e)[:160])
        if search_target is None:
            search_target = "textarea[name=q]"
            log("falling back to selector for search box", selector=search_target)

        # Step 3 — type the query
        banner(f"Step 3: typing query: {query!r}")
        # Camoufox + residential proxy sometimes leaves the textarea
        # passing visible/enabled/stable checks but never receiving the click.
        # force=True bypasses receive-events actionability; if even that
        # times out (extremely rare), fall back to form.fill alone — fill
        # resolves the target and focuses it before typing.
        try:
            c.call("mouse.click", session_id=sid, target=search_target,
                   scroll_into_view=True, force=True, timeout_ms=4000)
        except Exception as e:
            log("search-box click soft-fail (continuing)", err=str(e)[:200])
        c.call("form.fill", session_id=sid, target=search_target, value="",
               clear=True, timeout_ms=4000)
        if mode == "human":
            c.call("key.type_human", session_id=sid, target=search_target,
                   text=query, delay_min_ms=80, delay_max_ms=180)
        else:
            c.call("key.type", session_id=sid, target=search_target,
                   text=query, delay_ms=40)

        shot2 = c.call("inspect.screenshot", session_id=sid, full_page=False)
        log("after_type screenshot", path=shot2.get("path") or shot2.get("file"))

        # Step 4 — submit
        banner("Step 4: pressing Enter to submit search")
        c.call("key.press", session_id=sid, key="Enter")

        # Step 5 — wait for SERP
        banner("Step 5: waiting for SERP shell")
        try:
            c.call("wait.selector", session_id=sid,
                   target="#search, #rso, #rcnt",
                   state="visible", timeout_ms=15000)
        except Exception as e:
            log("wait.selector SERP shell soft-fail", err=str(e)[:160])
        try:
            c.call("wait.stable", session_id=sid, target="#search",
                   debounce_ms=800, timeout_ms=8000)
        except Exception as e:
            log("wait.stable SERP soft-fail", err=str(e)[:160])

        # Step 6 — captcha check
        # First: PyMCP's iframe-anchored solver (handles non-Google captchas).
        # Then: our own inline /sorry/ solver, which captcha.auto can't see.
        banner("Step 6: checking for /sorry/ captcha")
        try:
            cap = c.call("captcha.auto", session_id=sid, provider="capsolver")
            log("captcha.auto", solved=cap.get("solved"), reason=cap.get("reason"))
        except Exception as e:
            log("captcha.auto skipped", err=str(e)[:160])
        # Inline Google /sorry/ — solve it ourselves
        solved = _solve_sorry_if_needed(proxy=sorry_proxy, capsolver_key=capsolver_key)
        log("inline /sorry/ solve result", solved=solved)
        # Tier 1: persist cookies the moment /sorry/ clears — the
        # Google identity cookies (__Secure-1PSID / NID / AEC) are
        # the valuable artefact. Saving here means subsequent runs
        # can load them via storage_state= on new_context and skip
        # /sorry/ entirely, even if THIS run later fails (ad scan
        # error, network blip, etc.).
        if solved and state_path:
            try:
                r = c.call("session.save_state", session_id=sid,
                           path=state_path)
                log("storage_state saved post-/sorry/",
                    path=state_path, size=r.get("size_bytes"))
            except Exception as e:
                log("storage_state save (post-/sorry/) failed",
                    err=str(e)[:200])
        # In case solve produced a new SERP, re-settle briefly
        if solved:
            try:
                c.call("wait.selector", session_id=sid,
                       target="#search, #rso, #rcnt",
                       state="visible", timeout_ms=15000)
                c.call("wait.stable", session_id=sid, target="#search",
                       debounce_ms=800, timeout_ms=8000)
            except Exception:
                pass

        # Verify we're actually OFF /sorry/. The solver can return True from
        # token acquisition while the form submit fails (checkbox-variant
        # reCAPTCHA, callback mismatch). If we're still on /sorry/, abort
        # rather than DOM-scan the captcha page and pretend we found 0 ads.
        try:
            cur = c.call("inspect.evaluate", session_id=sid,
                         js="() => location.href").get("result") or ""
        except Exception:
            cur = ""
        if "/sorry/" in cur:
            log("still on /sorry/ after solve attempt — aborting scan",
                solved=solved, url=cur[:160])
            raise RuntimeError("stuck on /sorry/ after solve attempt")

        # Step 7 — scan ads via in-page JS (PyMCP's a11y-based snapshot misses
        # Google's text-ad cards on Camoufox; falls back to DOM scan capped at
        # 100 elements). _AD_SCAN_JS stamps data-pymcp-ad-scan="N" on each card.
        #
        # Sponsored blocks hydrate AFTER organic results — wait for at least
        # one ad anchor (text-ad or shopping PLA) to attach before scanning,
        # else we race the page and detect zero ads.
        banner("Step 7: waiting for sponsored ad anchors")
        try:
            c.call("wait.selector", session_id=sid,
                   target=('a[data-pcu], a[data-rw], a[href*="aclk"], '
                           'div.pla-unit-container, div.pla-unit'),
                   state="attached", timeout_ms=10000, probe=True)
        except Exception as e:
            log("no ad anchors within timeout (page may legitimately have no ads)",
                err=str(e)[:160])
        try:
            c.call("wait.stable", session_id=sid, target="#search",
                   debounce_ms=500, timeout_ms=4000)
        except Exception:
            pass
        banner("Step 7: scanning DOM for sponsored ad cards")
        scan_resp = c.call("inspect.evaluate", session_id=sid, js=_AD_SCAN_JS)
        raw_ads = scan_resp.get("result") or []
        # Persist raw JS output for debugging.
        (out_dir / "ad_scan_raw.json").write_text(
            json.dumps(raw_ads, indent=2, ensure_ascii=False), encoding="utf-8"
        )
        ads: list[dict] = []
        for raw in raw_ads:
            ads.append({
                "position": raw["scan_id"],
                "scan_id": raw["scan_id"],
                "title": raw.get("title") or "",
                "display_url": raw.get("display_url") or "",
                "host": raw.get("host") or "",
                "href": raw.get("href") or "",
                "aclk_href": raw.get("aclk_href") or "",
                "body_text": raw.get("body_text") or "",
                "bbox": raw.get("bbox"),
            })
        log(f"detected {len(ads)} ad block(s) via _AD_SCAN_JS")

        # Step 7b — scan organic results (everything that isn't a sponsored
        # ad card). Saved alongside ads for full SERP capture.
        banner("Step 7b: scanning organic results")
        organic: list[dict] = []
        try:
            org_resp = c.call("inspect.evaluate", session_id=sid,
                              js=_ORGANIC_SCAN_JS)
            organic = org_resp.get("result") or []
        except Exception as e:
            log("organic scan failed (continuing)", err=str(e)[:160])
        (out_dir / "organic_results.json").write_text(
            json.dumps(organic, indent=2, ensure_ascii=False), encoding="utf-8"
        )
        log(f"detected {len(organic)} organic result(s) via _ORGANIC_SCAN_JS")

        # Step 8 — classify against watchlists.
        # Default semantic: greenlist = ads of interest; orangelist = ads to
        # monitor; ads matching neither are unclassified.
        # Inverted semantic (empty orangelist + non-empty greenlist):
        #   greenlist becomes a BLOCKLIST ("do not visit") and every non-green
        #   ad is auto-promoted to "orange" (= of interest, eligible to click).
        invert_mode = (not orangelist) and bool(greenlist)
        if invert_mode:
            log("classification mode: INVERTED — greenlist=blocklist, "
                "any non-green ad becomes 'orange'")
        for ad in ads:
            haystacks = [
                (ad.get("title") or "").lower(),
                (ad.get("display_url") or "").lower(),
                (ad.get("host") or "").lower(),
                (ad.get("href") or "").lower(),
                (ad.get("body_text") or "").lower(),
            ]
            g = next((it for it in greenlist if _match_item(haystacks, it)), None)
            o = None if g else next(
                (it for it in orangelist if _match_item(haystacks, it)), None
            )
            list_name = "green" if g else ("orange" if o else None)
            matched_item = g or o
            if invert_mode and list_name is None:
                # Anything not on the blocklist is "interesting"
                list_name = "orange"
                matched_item = "(any non-green)"
            ad["list"] = list_name
            ad["matched_item"] = matched_item
            log(
                f"ad #{ad['position']}",
                host=ad.get("host"),
                list=ad["list"],
                match=ad["matched_item"],
            )

        # Step 8b — highlight matched cards (orange/green) on the live page
        matches_payload = [
            {
                "scan_id": ad["scan_id"],
                "list_name": ad["list"],
                "badge": f"{ad['list'].upper()}LIST · {ad.get('matched_item') or ''}",
            }
            for ad in ads
            if ad.get("list") in ("green", "orange")
        ]
        if matches_payload:
            banner(f"Step 8: highlighting {len(matches_payload)} matched ad(s)")
            try:
                hl = c.call("inspect.evaluate", session_id=sid, js=_HIGHLIGHT_JS,
                            args=[{"matches": matches_payload}])
                log("highlight applied", applied=hl.get("result"))
            except Exception as e:
                log("highlight failed", err=str(e)[:200])
        else:
            log("no matches to highlight")

        shot3 = c.call("inspect.screenshot", session_id=sid, full_page=True)
        log("before_click screenshot", path=shot3.get("path") or shot3.get("file"))

        # Step 9 — auto-click a RANDOM orange match.
        # Greenlist is "never-click" by contract (docs/USAGE.md). The prior
        # fallback here picked from `green` OR `orange` when no orange
        # matched, which silently violated that contract — runs with a
        # green match and no orange match ended up clicking the greenlist
        # entry. Removed: if click_orange is True and there are no orange
        # matches, do nothing.
        import random as _random
        clicked = None
        target_ad = None
        if click_orange:
            orange_pool = [a for a in ads if a.get("list") == "orange"]
            if orange_pool:
                target_ad = _random.choice(orange_pool)
                log("picking random orange ad",
                    of=len(orange_pool), scan_id=target_ad.get("scan_id"),
                    host=target_ad.get("host"))
            else:
                log("no orange matches — skipping auto-click "
                    "(green is never-click)")

        if target_ad and target_ad.get("scan_id"):
            scan_id = target_ad["scan_id"]
            banner(f"Step 9: clicking ad #{scan_id} — {target_ad.get('host')}")

            # Stamp the PRIMARY anchor uniquely so the click selector resolves
            # to exactly one element (B7: text-ad cards contain primary
            # heading-anchor + sitelink anchors that all carry data-pcu/data-rw).
            stamp_js = r"""
            (id) => {
              const card = document.querySelector(`[data-pymcp-ad-scan="${id}"]`);
              if (!card) return null;
              const head = card.querySelector('h3, div[role="heading"], [role="heading"]');
              let primary = null;
              if (head) {
                primary = head.closest('a[data-pcu], a[data-rw], a[href*="aclk"]')
                       || head.querySelector('a[data-pcu], a[data-rw], a[href*="aclk"]')
                       || (head.parentElement && head.parentElement.querySelector(
                            'a[data-pcu], a[data-rw], a[href*="aclk"]'));
              }
              if (!primary) {
                // Fallback: largest visible anchor by area.
                const anchors = Array.from(card.querySelectorAll(
                  'a[data-pcu], a[data-rw], a[href*="aclk"]'));
                let best = null, bestA = 0;
                for (const a of anchors) {
                  const r = a.getBoundingClientRect();
                  const A = r.width * r.height;
                  if (A > bestA) { best = a; bestA = A; }
                }
                primary = best;
              }
              if (!primary) return null;
              primary.setAttribute('data-pymcp-ad-primary', String(id));
              primary.scrollIntoView({behavior:'instant', block:'center'});
              const r = primary.getBoundingClientRect();
              return {
                cx: Math.round(r.x + r.width/2),
                cy: Math.round(r.y + r.height/2),
                w: Math.round(r.width), h: Math.round(r.height),
              };
            }
            """
            anchor_info = c.call("inspect.evaluate", session_id=sid,
                                 js=stamp_js, args=[scan_id]).get("result")
            log("auto-clicking ad", scan_id=scan_id, host=target_ad.get("host"),
                anchor=anchor_info)
            if not anchor_info:
                log("could not stamp primary anchor — skipping click")
            else:
                # Wait for the stamped anchor to be visible AND for its rect
                # to stop moving — scrollIntoView triggers a smooth reflow on
                # some Google variants and clicking mid-scroll hits the wrong
                # element.
                try:
                    c.call("wait.selector", session_id=sid,
                           target=f'[data-pymcp-ad-primary="{scan_id}"]',
                           state="visible", timeout_ms=5000)
                except Exception as e:
                    log("primary anchor wait.selector soft-fail", err=str(e)[:160])
                try:
                    c.call("wait.stable", session_id=sid,
                           target=f'[data-pymcp-ad-primary="{scan_id}"]',
                           debounce_ms=300, timeout_ms=3000)
                except Exception as e:
                    log("primary anchor wait.stable soft-fail", err=str(e)[:160])
                # Prefer real-mouse coordinate click (B8): the primary anchor is
                # often ~16px tall and fails Playwright's stable-rect checks
                # when targeted by selector, but x,y coords work reliably and
                # dispatch real OS pointer events so Google's onclick / aclk
                # tracking fires (producing a real gclid on the landing URL).
                try:
                    c.call("mouse.click", session_id=sid,
                           x=anchor_info["cx"], y=anchor_info["cy"],
                           button="left", click_count=1)
                except Exception as e:
                    log("coordinate mouse.click failed, retrying with force+selector",
                        err=str(e)[:200])
                    try:
                        c.call("mouse.click", session_id=sid,
                               target=f'[data-pymcp-ad-primary="{scan_id}"]',
                               force=True, scroll_into_view=True,
                               timeout_ms=8000)
                    except Exception as e2:
                        log("force selector click also failed", err=str(e2)[:200])
                        raise
            # Wait for navigation away from google.com (aclk → advertiser)
            # then for the landing page DOM. Falls back to a short settle.
            navigated = False
            try:
                c.call("wait.url", session_id=sid,
                       pattern=r"^(?!https?://(www\.)?google\.).*",
                       timeout_ms=10000)
                navigated = True
            except Exception as e:
                log("post-click wait.url soft-fail (may still be on google)",
                    err=str(e)[:160])
            try:
                c.call("wait.load", session_id=sid,
                       state="domcontentloaded", timeout_ms=10000)
            except Exception as e:
                log("post-click wait.load soft-fail", err=str(e)[:160])
            if not navigated:
                time.sleep(2.0)
            clicked = {
                "position": target_ad["position"],
                "host": target_ad.get("host"),
                "list": target_ad.get("list"),
                "matched_item": target_ad.get("matched_item"),
            }

        # Step 10 — landing screenshot + tab info
        try:
            tabs = c.call("tab.list", session_id=sid)
        except Exception as e:
            tabs = {"error": str(e)}
        shot4 = c.call("inspect.screenshot", session_id=sid, full_page=True)
        log("landing screenshot", path=shot4.get("path") or shot4.get("file"))

        # Step 10b — capture the landing page's full URL + meta tags so we
        # can audit the actual destination (gclid, campaign params, canonical
        # mismatches, missing og:image, etc.) without re-opening the browser.
        landing_page: dict = {}
        try:
            lp = c.call("inspect.evaluate", session_id=sid, js=_LANDING_META_JS)
            landing_page = lp.get("result") or {}
        except Exception as e:
            log("landing meta extract failed", err=str(e)[:200])
            landing_page = {"error": str(e)[:200]}
        (out_dir / "landing_page.json").write_text(
            json.dumps(landing_page, indent=2, ensure_ascii=False),
            encoding="utf-8",
        )
        log("landing meta captured",
            final_host=landing_page.get("final_host"),
            title=(landing_page.get("title") or "")[:80],
            has_gclid=landing_page.get("has_gclid"),
            meta_count=len(landing_page.get("meta") or {}),
            og_count=len(landing_page.get("og") or {}))

        report = {
            "schema_version": 1,
            "task": "google_ad_scan_pymcp",
            "query": query,
            "started_at": started_at.isoformat(),
            "duration_ms": int((time.perf_counter() - t0) * 1000),
            "session_id": sid,
            "engine": engine,
            "mode": mode,
            "watchlists": {"greenlist": greenlist, "orangelist": orangelist},
            "summary": {
                "ads_detected": len(ads),
                "organic_detected": len(organic),
                "green_matches": sum(1 for a in ads if a.get("list") == "green"),
                "orange_matches": sum(1 for a in ads if a.get("list") == "orange"),
                "auto_clicked": bool(clicked),
                "auto_clicked_target": clicked,
            },
            "ads": ads,
            "organic": organic,
            "landing_page": landing_page,
            "tabs": tabs,
            "screenshots": {
                "homepage": shot1.get("path") or shot1.get("file"),
                "after_type": shot2.get("path") or shot2.get("file"),
                "serp_before_click": shot3.get("path") or shot3.get("file"),
                "landing": shot4.get("path") or shot4.get("file"),
            },
        }
        (out_dir / "report.json").write_text(
            json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8"
        )
        log(
            "report written",
            ads=report["summary"]["ads_detected"],
            green=report["summary"]["green_matches"],
            orange=report["summary"]["orange_matches"],
            duration_ms=report["duration_ms"],
        )

        # Tier 1: persist Playwright storage_state (cookies + origins)
        # so the next session reads it back via storage_state= on
        # new_context. Skipped if we never received a state_path
        # (standalone CLI use) or if the run failed before producing
        # post-/sorry/ cookies. Best-effort — never fail the run.
        if state_path:
            try:
                r = c.call("session.save_state", session_id=sid,
                           path=state_path)
                log("storage_state saved",
                    path=state_path,
                    size=r.get("size_bytes"))
            except Exception as e:
                log("storage_state save failed", err=str(e)[:200])

        return report
    except Exception as e:
        error_occurred = True
        log("RUN FAILED", err=str(e)[:400])
        raise
    finally:
        if sid and not keep_open and not error_occurred:
            try:
                c.call("session.close", session_id=sid)
                log("session.close ok")
            except Exception as e:
                log("session.close failed", err=str(e)[:160])
        else:
            log("session preserved (keep_open or error)", session_id=sid,
                keep_open=keep_open, error=error_occurred)
        c.close()
        log_fp.close()


def _split_csv(s: str | None) -> list[str]:
    if not s:
        return []
    return [x.strip() for x in s.replace("\n", ",").split(",") if x.strip()]


def main() -> int:
    p = argparse.ArgumentParser(
        prog="google_ad_scan_pymcp",
        description="Google ad scan via PyMCP_Browser v2 REST API.",
    )
    p.add_argument("query", help="search keyword")
    p.add_argument("--green", help="comma- or newline-separated greenlist items")
    p.add_argument("--orange", help="comma- or newline-separated orangelist items")
    p.add_argument("--green-file")
    p.add_argument("--orange-file")
    p.add_argument("--base-url", default=DEFAULT_BASE,
                   help=f"PyMCP_Browser v2 base URL (default {DEFAULT_BASE})")
    p.add_argument("--token", default=None,
                   help="bearer token (required unless PYMCP_NO_AUTH=1 on server)")
    p.add_argument("--engine", default="chromium",
                   choices=["chromium", "patchright", "camoufox"])
    p.add_argument("--mode", default="stealth", choices=["vanilla", "stealth", "human"])
    p.add_argument("--headless", action="store_true")
    p.add_argument("--click-orange", action="store_true",
                   help="auto-click the first orangelisted ad")
    p.add_argument("--session-id", default=None,
                   help="reuse an existing session (skips session.create)")
    p.add_argument("--keep-open", action="store_true",
                   help="don't close the session at the end")
    p.add_argument("--sorry-proxy",
                   help='proxy for the inline /sorry/ capsolver task '
                        '(host:port:user:pass — defaults to FusionProxy preset)')
    p.add_argument("--capsolver-key",
                   help="capsolver API key (defaults to data/credentials.json)")
    p.add_argument("--out-dir", default=None)
    p.add_argument("--locale", default="en-us",
                   help="Google locale, e.g. en-us, es-mx, pt-br")
    args = p.parse_args()

    greenlist = _split_csv(args.green)
    orangelist = _split_csv(args.orange)
    if args.green_file:
        greenlist += [
            ln.strip() for ln in Path(args.green_file).read_text(encoding="utf-8").splitlines()
            if ln.strip()
        ]
    if args.orange_file:
        orangelist += [
            ln.strip() for ln in Path(args.orange_file).read_text(encoding="utf-8").splitlines()
            if ln.strip()
        ]

    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    slug = re.sub(r"[^a-z0-9]+", "_", args.query.lower()).strip("_")[:40] or "query"
    out_dir = Path(args.out_dir) if args.out_dir else (
        Path(__file__).resolve().parent / "_runs_pymcp" / f"{ts}_{slug}"
    )

    # Parse the --sorry-proxy spec (host:port:user:pass). Default to FusionProxy.
    sorry_proxy: dict | None = DEFAULT_FUSION_PROXY
    if args.sorry_proxy is not None:
        if args.sorry_proxy.strip().lower() in ("none", ""):
            sorry_proxy = None
        else:
            parts = args.sorry_proxy.split(":", 3)
            if len(parts) >= 2:
                sorry_proxy = {
                    "host": parts[0], "port": int(parts[1]),
                    "user": parts[2] if len(parts) > 2 else "",
                    "pass": parts[3] if len(parts) > 3 else "",
                }
    capsolver_key = args.capsolver_key or _load_capsolver_key()

    report = run_scan(
        query=args.query,
        orangelist=orangelist,
        greenlist=greenlist,
        base_url=args.base_url,
        token=args.token,
        engine=args.engine,
        mode=args.mode,
        headless=args.headless,
        click_orange=args.click_orange,
        out_dir=out_dir,
        session_id=args.session_id,
        keep_open=args.keep_open,
        sorry_proxy=sorry_proxy,
        capsolver_key=capsolver_key,
        locale=args.locale,
    )
    print(
        f"ads_detected={report['summary']['ads_detected']} "
        f"green={report['summary']['green_matches']} "
        f"orange={report['summary']['orange_matches']} "
        f"clicked={report['summary']['auto_clicked']}"
    )
    print(f"report:    {out_dir / 'report.json'}")
    print(f"debug log: {out_dir / 'debug.log'}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
