from __future__ import annotations
import asyncio
import json
import random
import re
import string
import time
from datetime import date
from typing import Any
from ..control.registry import task
from ..core.session import SessionRegistry

# Run-5 verified flow (2026-05-08). Lessons from feedback memory:
# - mode=human required; stealth + fast typing trips Typeform anti-bot
# - direct nav to admin.typeform.com/signup-email (skip SSO landing pivot)
# - submit-twice false-positive: "Something went wrong... already have an account" on first submit
# - captcha: invisible reCAPTCHA Enterprise; pre_submit synthetic blur mounts iframe
# - activation URL redirects through auth.typeform.com -> oauth -> okta callback -> /
#   DO NOT interrupt; wait 20s+
# - PAT cleartext via [data-qa=client-secret-input], no Show button
# - duhastmail/fuhrenmail/legenmail/bekommenmail are firstmail.ltd-served
# - same password for Typeform AND IMAP login (run-5 pattern)
META = {"last_verified": date(2026, 5, 8).isoformat()}


def _rand_email() -> str:
    user = "".join(random.choices(string.ascii_lowercase + string.digits, k=12))
    return f"{user}@mailinator.com"


def _rand_password() -> str:
    base = "".join(random.choices(string.ascii_letters + string.digits, k=14))
    return base + "!1Aa"


def _firstmail_imap_host(email: str) -> str:
    # Most temp-mail providers we use are served by firstmail.ltd.
    # Override via task arg `imap_host` if needed.
    return "imap.firstmail.ltd"


async def _human_type(page, selector: str, text: str,
                      delay_min: int = 95, delay_max: int = 220) -> None:
    """Type with per-character random delay (human-like)."""
    await page.focus(selector)
    for ch in text:
        await page.keyboard.type(ch)
        await asyncio.sleep(random.uniform(delay_min, delay_max) / 1000)


async def _poll_imap_for_activation(email: str, imap_password: str,
                                    imap_host: str,
                                    retries: int = 15,
                                    backoff_s: float = 4.0) -> str | None:
    """Block until activation URL appears in inbox or retries exhausted.

    Returns the activation URL or None."""
    import imaplib
    pat = re.compile(r"https://auth\.typeform\.com/tokens/[A-Za-z0-9]+/verify")
    for attempt in range(retries):
        try:
            imap = imaplib.IMAP4_SSL(imap_host, 993)
            imap.login(email, imap_password)
            imap.select("INBOX")
            typ, data = imap.search(None, '(FROM "typeform.com")')
            if typ == "OK" and data and data[0]:
                uids = data[0].split()
                for uid in reversed(uids):
                    typ, d = imap.fetch(uid, "(BODY.PEEK[])")
                    if typ == "OK" and d and d[0] and d[0][1]:
                        body = d[0][1].decode("utf-8", errors="replace")
                        m = pat.search(body)
                        if m:
                            try:
                                imap.logout()
                            except Exception:
                                pass
                            return m.group(0)
            try:
                imap.logout()
            except Exception:
                pass
        except Exception:
            pass
        await asyncio.sleep(backoff_s)
    return None


async def _solve_captcha(page) -> bool:
    """Detect + solve invisible reCAPTCHA Enterprise + inject token."""
    from ..core.captcha.detector import detect_captcha, inject_token
    from ..core.captcha.resolver import solve as solver_solve
    # D12: synthetic blur on submit button to force iframe mount.
    try:
        await page.evaluate(
            """(sel) => {
                const el = document.querySelector(sel);
                if (el) {
                    el.dispatchEvent(new FocusEvent('focus'));
                    el.dispatchEvent(new FocusEvent('blur'));
                }
            }""",
            '[data-qa=button-submit]',
        )
        await asyncio.sleep(0.6)
    except Exception:
        pass
    info = await detect_captcha(page)
    if not info or not info.get("sitekey"):
        return False
    try:
        token, _, _ = await solver_solve(
            info["type"], info["sitekey"], page.url,
            invisible=bool(info.get("invisible")),
            page_action=info.get("action"),
        )
        await inject_token(page, info["type"], token)
        return True
    except Exception:
        return False


@task(name="typeform_signup",
      label="Typeform signup -> activate -> PAT (run-5 verified flow)",
      session_spec={"proxy_provider": "proxyfog",
                    "proxyfog_mode": "sticky",
                    "proxyfog_ttl_minutes": 30,
                    "mode": "human"},
      auto_session=True)
async def run_typeform_signup(session_id: str,
                              email: str | None = None,
                              password: str | None = None,
                              imap_password: str | None = None,
                              imap_host: str | None = None,
                              vault_label_prefix: str | None = None,
                              pat_name: str = "default",
                              persona_first_name: str | None = None,
                              persona_last_name: str | None = None,
                              save_vault: bool = True,
                              preflight_min_total: float | None = None,
                              preflight_min_fp: float | None = None,
                              preflight_min_bot: float | None = None,
                              preflight_skip: bool = False) -> dict:
    """End-to-end macro:
        signup -> captcha -> activate via inbox -> PAT generate -> verify -> vault save.

    Args:
        email: target mailbox (used for both signup AND IMAP login)
        password: same password for Typeform signup AND IMAP login (run-5 pattern)
        imap_password: override if IMAP password differs from signup password
        imap_host: override (default imap.firstmail.ltd)
        pat_name: name shown on Typeform PAT page (default: "default")
        save_vault: persist login + PAT to PyMCP vault (default: True)
        preflight_min_total/min_fp/min_bot: override gate thresholds; None = env defaults
        preflight_skip: skip preflight (e.g. for dev / chromium engine where fail is expected)
    """
    # ---- 0. preflight gate ---------------------------------------------------
    if not preflight_skip:
        from ..control.tools.preflight import preflight_check
        gate = await preflight_check(
            session_id=session_id,
            min_total=preflight_min_total,
            min_fp=preflight_min_fp,
            min_bot=preflight_min_bot,
            raise_on_fail=True,
        )
        # gate dict is informational on pass; raise_on_fail=True throws on fail
    else:
        gate = {"allowed": True, "reason": "preflight_skip"}

    s = SessionRegistry.get().lookup(session_id)
    page = s.active_page()

    email = email or _rand_email()
    password = password or _rand_password()
    imap_pw = imap_password or password
    imap_h = imap_host or _firstmail_imap_host(email)
    label_prefix = vault_label_prefix or f"typeform.com_{email.split('@')[0]}"

    log: dict[str, Any] = {"email": email, "steps": [], "preflight": gate}

    def step(name: str, **extra):
        entry = {"name": name, "ts": time.time(), **extra}
        log["steps"].append(entry)

    # ---- 1. signup form ----
    await page.goto("https://admin.typeform.com/signup-email",
                    wait_until="domcontentloaded")
    step("nav_signup_email")

    try:
        await page.locator("#onetrust-accept-btn-handler").click(timeout=8000)
        step("cookie_dismissed")
    except Exception:
        pass

    await page.wait_for_selector('[data-qa=field-email]', timeout=10000)
    await _human_type(page, '[data-qa=field-email]', email)
    step("email_typed")
    await _human_type(page, '[data-qa=field-password]', password)
    step("password_typed")
    await asyncio.sleep(1.0)

    try:
        await page.locator('[data-qa=consents-form-terms]').click()
        step("consents_checked")
    except Exception:
        pass

    # ---- 2. captcha + first submit ----
    captcha_solved = await _solve_captcha(page)
    step("captcha", solved=captcha_solved)

    submit = page.locator('[data-qa=button-submit]')
    await submit.click()
    step("submit_1")

    try:
        await page.wait_for_load_state("domcontentloaded", timeout=15000)
    except Exception:
        pass
    await asyncio.sleep(2.0)

    # ---- 3. submit-twice false-positive handling ----
    if "/signup" in page.url:
        # First submit usually shows "you might already have an account"
        # Second click on same page completes the flow.
        try:
            await submit.click(timeout=4000)
            step("submit_2_false_positive")
            try:
                await page.wait_for_load_state("domcontentloaded", timeout=15000)
            except Exception:
                pass
            await asyncio.sleep(3.0)
        except Exception:
            pass

    # If still stuck, one more captcha + submit cycle (token may have expired)
    if "/signup" in page.url and "/signup-complete" not in page.url:
        captcha_solved = await _solve_captcha(page) or captcha_solved
        try:
            await submit.click(timeout=4000)
            step("submit_3_after_recaptcha")
            await asyncio.sleep(8.0)
        except Exception:
            pass

    if "/signup-complete" not in page.url and "/signup" in page.url:
        return {"ok": False, "reason": "signup_did_not_complete",
                "url": page.url, "log": log,
                "last_verified": META["last_verified"]}

    step("signup_complete", url=page.url)

    # ---- 4. poll IMAP for activation link ----
    activation_url = await _poll_imap_for_activation(
        email, imap_pw, imap_h, retries=15, backoff_s=4.0,
    )
    step("imap_polled", found=bool(activation_url),
         url=activation_url)
    if not activation_url:
        return {"ok": False, "reason": "activation_mail_not_found",
                "log": log, "last_verified": META["last_verified"]}

    # ---- 5. activate (do NOT interrupt the redirect chain) ----
    await page.goto(activation_url, wait_until="domcontentloaded",
                    timeout=30000)
    step("activation_clicked")
    # Critical: wait 20s+ for auth -> oauth -> okta callback -> dashboard chain.
    await asyncio.sleep(20.0)

    # ---- 6. (optional) onboarding name fields if shown ----
    try:
        # If first/last name onboarding mounts, fill it.
        first = persona_first_name
        last = persona_last_name
        if not first or not last:
            try:
                from faker import Faker
                fk = Faker("en_US")
                first = first or fk.first_name()
                last = last or fk.last_name()
            except Exception:
                first = first or "Alex"
                last = last or "Carter"
        for sel, val in [
            ('input[name="given-name"]', first),
            ('input[name="family-name"]', last),
        ]:
            try:
                if await page.locator(sel).count():
                    await _human_type(page, sel, val)
            except Exception:
                pass
        # Continue button on onboarding
        for txt in ('text="Continue"', 'text="Next"',
                    '[data-qa=onboarding-continue]'):
            try:
                if await page.locator(txt).first.is_visible(timeout=1000):
                    await page.locator(txt).first.click(timeout=3000)
                    await asyncio.sleep(2.0)
                    break
            except Exception:
                pass
        step("onboarding_attempted", first=first, last=last)
    except Exception:
        pass

    # ---- 7. direct-nav PAT page ----
    await page.goto("https://admin.typeform.com/user/tokens",
                    wait_until="domcontentloaded")
    step("nav_user_tokens")
    await asyncio.sleep(2.0)

    # ---- 8. generate PAT ----
    await page.locator("[data-qa=create-token-btn]").click(timeout=10000)
    await page.wait_for_selector("[data-qa=token-name]", timeout=10000)
    await _human_type(page, "[data-qa=token-name]", pat_name)
    await page.locator("[data-qa=confirm-button]").click(timeout=10000)
    await page.wait_for_selector("[data-qa=client-secret-input]", timeout=15000)
    pat = await page.locator("[data-qa=client-secret-input]").input_value()
    step("pat_generated", name=pat_name)

    # ---- 9. live verify via /me ----
    user_id = None
    me_ok = False
    try:
        from urllib.request import Request, urlopen
        req = Request("https://api.typeform.com/me",
                      headers={"Authorization": f"Bearer {pat}"})
        with urlopen(req, timeout=10) as resp:
            payload = json.loads(resp.read().decode("utf-8"))
            user_id = payload.get("user_id")
            me_ok = bool(user_id)
    except Exception:
        pass
    step("pat_verified", ok=me_ok, user_id=user_id)

    # ---- 10. vault save ----
    saved_labels: dict[str, str] = {}
    if save_vault:
        try:
            from sqlmodel import Session
            from ..storage.db import get_engine
            from ..storage.models import VaultEntry
            now = time.time()
            login_label = label_prefix
            pat_label = f"{label_prefix.replace('typeform.com_', 'typeform.com_pat_' + pat_name + '_')}"
            with Session(get_engine()) as db:
                # login
                if not db.get(VaultEntry, 1) or True:
                    db.add(VaultEntry(
                        label=login_label,
                        username=email,
                        password=password,
                        url="https://admin.typeform.com/login",
                        notes=f"Typeform account; user_id={user_id}; created {date.today().isoformat()} via task=typeform_signup",
                        created_ts=now, updated_ts=now,
                    ))
                # PAT
                db.add(VaultEntry(
                    label=pat_label,
                    username=email,
                    password=pat,
                    url="https://api.typeform.com",
                    notes=f"PAT name={pat_name}; verified GET /me -> {'200' if me_ok else 'FAIL'}; user_id={user_id}",
                    created_ts=now, updated_ts=now,
                ))
                db.commit()
            saved_labels = {"login": login_label, "pat": pat_label}
            step("vault_saved", **saved_labels)
        except Exception as e:
            step("vault_save_failed", error=str(e))

    return {
        "ok": me_ok,
        "email": email,
        "user_id": user_id,
        "pat_name": pat_name,
        "pat": pat,
        "verified": me_ok,
        "vault_labels": saved_labels,
        "url_final": page.url,
        "captcha_solved": captcha_solved,
        "log": log,
        "last_verified": META["last_verified"],
    }
