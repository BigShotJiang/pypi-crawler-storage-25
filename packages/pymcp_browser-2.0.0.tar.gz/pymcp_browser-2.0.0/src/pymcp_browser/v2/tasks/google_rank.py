from __future__ import annotations
from urllib.parse import urlparse
from ..control.registry import task
from ..core.session import SessionRegistry


@task(name="google_rank", label="Google rank-check for a domain",
      session_spec={"mode": "stealth"}, auto_session=True)
async def run_google_rank(session_id: str, query: str, domain: str,
                          max_pages: int = 5) -> dict:
    s = SessionRegistry.get().lookup(session_id)
    page = s.active_page()
    target = domain.lower().lstrip("www.")
    rank = None
    pos = 0
    for pg in range(max_pages):
        start = pg * 10
        await page.goto(f"https://www.google.com/search?q={query}&start={start}",
                        wait_until="domcontentloaded")
        urls = await page.evaluate("""
        () => Array.from(document.querySelectorAll('div.g a[href], div[data-hveid] a[href]'))
                  .map(a => a.href).filter(h => h && !h.includes('google.com'))
        """)
        for u in urls:
            pos += 1
            try:
                host = urlparse(u).hostname or ""
                if target in host.lower():
                    rank = pos
                    break
            except Exception:
                continue
        if rank:
            break
    return {"query": query, "domain": domain, "rank": rank,
            "pages_checked": pg + 1 if rank else max_pages}
