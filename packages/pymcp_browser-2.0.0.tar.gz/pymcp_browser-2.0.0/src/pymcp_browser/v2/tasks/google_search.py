from __future__ import annotations
from ..control.registry import task
from ..core.session import SessionRegistry


@task(name="google_search", label="Google search and capture top results",
      session_spec={"mode": "stealth"}, auto_session=True)
async def run_google_search(session_id: str, query: str, num: int = 10) -> dict:
    s = SessionRegistry.get().lookup(session_id)
    page = s.active_page()
    await page.goto(f"https://www.google.com/search?q={query}&num={num}",
                    wait_until="domcontentloaded")
    results = await page.evaluate("""
    () => Array.from(document.querySelectorAll('div.g, div[data-hveid]')).slice(0, 20).map(el => {
      const a = el.querySelector('a[href]');
      const h = el.querySelector('h3');
      return a && h ? {title: h.innerText, url: a.href} : null;
    }).filter(Boolean)
    """)
    return {"query": query, "count": len(results), "results": results}
