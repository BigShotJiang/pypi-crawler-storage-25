"""Task modules. Importing this package registers every @task."""
from __future__ import annotations
import pkgutil
import importlib

for _, name, _ in pkgutil.iter_modules(__path__):
    importlib.import_module(f"{__name__}.{name}")
