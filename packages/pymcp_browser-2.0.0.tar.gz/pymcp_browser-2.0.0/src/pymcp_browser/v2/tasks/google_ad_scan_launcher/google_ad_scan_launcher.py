"""Compact tkinter launcher for google_ad_scan.

Single small window. Enter keyword + greenlist + orangelist (one per line),
click Run. The task opens Chromium, highlights matching ads on the SERP, and
writes a JSON report + screenshot under data/ad_scans/.

Run:
  python -m pymcp_browser.v2.tasks.google_ad_scan_launcher
  # or double-click this file in Explorer (auto-bootstraps sys.path).
"""
from __future__ import annotations

import asyncio
import json
import os
import sys
import threading
import tkinter as tk
import webbrowser
from pathlib import Path
from tkinter import messagebox, scrolledtext, ttk

# Allow running directly as a script (double-click) by adding src/ to sys.path
# before package-qualified imports below. As an imported module this is a no-op.
if __package__ in (None, ""):
    _SRC = Path(__file__).resolve().parents[3]
    if str(_SRC) not in sys.path:
        sys.path.insert(0, str(_SRC))
    __package__ = "pymcp_browser.v2.tasks"  # noqa: A001

import uuid as _uuid
from pymcp_browser.v2.config import settings
from pymcp_browser.v2.core.browser_manager import BrowserManager
from pymcp_browser.v2.core.session import BrowserSession, SessionRegistry
from pymcp_browser.v2.tasks.google_ad_scan import run_google_ad_scan


# Proxy presets — colon-separated form: host:port:username:password
PROXY_PRESETS: dict[str, str] = {
    "None":         "",
    "FusionProxy":  "resi.fusionproxy.net:13375:ti9xt628jf18-country-mx:g2xks20toq26",
    "ProxyShard":   "relay-eu.proxyshard.com:8080:plan-premium-country-mx-sid-z9aidjvpnrgd:z2471fbx3rqepypv",
}


def _parse_proxy_str(s: str) -> dict | None:
    """Parse 'host:port:user:pass' into a Playwright proxy dict (http://...)."""
    if not s or not s.strip():
        return None
    parts = s.strip().split(":", 3)
    if len(parts) < 2:
        return None
    host = parts[0]
    port = parts[1]
    user = parts[2] if len(parts) >= 3 else ""
    pwd  = parts[3] if len(parts) >= 4 else ""
    return {
        "server": f"http://{host}:{port}",
        "username": user,
        "password": pwd,
    }


async def _create_session_with_proxy(proxy: dict | None, engine: str, headless: bool):
    """Create a browser session that tunnels through `proxy` (or no proxy if None).

    Uses BrowserManager directly so we can bypass SessionRegistry.create's
    fixed enum of proxy providers. The resulting session is registered in
    SessionRegistry so other tools (captcha helper, etc.) can look it up.
    """
    import httpx
    vp = {"width": 1280, "height": 800}
    ctx_kwargs: dict = {"viewport": vp}
    egress_ip = None

    if proxy:
        # Optional geo probe so we can set timezone/locale that match the IP.
        try:
            srv = proxy["server"]
            scheme, _, hp = srv.partition("://")
            proxy_url = f"{scheme}://{proxy['username']}:{proxy['password']}@{hp}"
            async with httpx.AsyncClient(proxy=proxy_url, timeout=20.0, verify=False) as cli:
                r = await cli.get("http://ip-api.com/json/")
                body = r.json()
            egress_ip = body.get("query")
            tz = body.get("timezone"); cc = body.get("countryCode")
            if tz: ctx_kwargs["timezone_id"] = tz
            locale_map = {"MX": "es-MX", "US": "en-US", "GB": "en-GB", "DE": "de-DE",
                          "FR": "fr-FR", "NL": "nl-NL", "ES": "es-ES", "IT": "it-IT",
                          "BR": "pt-BR", "IN": "en-IN"}
            ctx_kwargs["locale"] = locale_map.get(cc or "", "en-US")
        except Exception:
            pass

    bm = await BrowserManager.get()
    # Camoufox ships with uBlock Origin enabled by default, which blocks
    # Google ad iframes/scripts and means `data-pcu` markers stay in HTML
    # but no visible ad cards render. Disable it for ad-scanning sessions.
    cfx_extras = None
    if engine == "camoufox":
        try:
            from camoufox import DefaultAddons
            cfx_extras = {"exclude_addons": [DefaultAddons.UBO]}
        except Exception:
            cfx_extras = {"exclude_addons": ["UBO"]}
    context = await bm.new_context(engine=engine, headless=headless,
                                   proxy=proxy,
                                   camoufox_extras=cfx_extras, **ctx_kwargs)
    page = await context.new_page()

    sid = _uuid.uuid4().hex[:12]
    sess = BrowserSession(
        id=sid, profile_id=None,
        proxy_provider="custom" if proxy else None,
        proxy_zone=None, proxy_session_tag=None,
        mode="stealth", headless=headless, viewport=vp,
        record_heavy=False, context=context, engine=engine,
    )
    sess.add_page(page)
    sess.proxy_egress_ip = egress_ip
    SessionRegistry.get()._sessions[sid] = sess
    return sess


def _project_root() -> Path:
    # src/pymcp_browser/v2/tasks/<this> -> project root
    return Path(__file__).resolve().parents[4]


# ---------- dark theme --------------------------------------------------------

DARK = {
    "bg":        "#1e1f22",  # window / frame background
    "panel":     "#2b2d31",  # text widgets / inputs
    "border":    "#3a3d44",  # frame & tab borders
    "fg":        "#e6e6e6",  # primary text
    "muted":     "#9aa0a6",  # status/muted
    "accent":    "#3b82f6",  # selection / active tab indicator
    "select_bg": "#264f78",
    "btn":       "#3a3d44",
    "btn_hover": "#4a4d54",
}


def _apply_dark_theme(root: tk.Tk) -> None:
    style = ttk.Style(root)
    # Use 'clam' — it honours ttk.Style colors uniformly across platforms,
    # unlike Windows' 'vista' which ignores most background overrides.
    try:
        style.theme_use("clam")
    except tk.TclError:
        pass

    root.configure(bg=DARK["bg"])
    root.option_add("*Background", DARK["bg"])
    root.option_add("*Foreground", DARK["fg"])
    # Dialog (messagebox) styling
    root.option_add("*Dialog.msg.background", DARK["bg"])
    root.option_add("*Dialog.msg.foreground", DARK["fg"])

    style.configure(".", background=DARK["bg"], foreground=DARK["fg"],
                    fieldbackground=DARK["panel"], bordercolor=DARK["border"],
                    lightcolor=DARK["border"], darkcolor=DARK["border"],
                    troughcolor=DARK["panel"], focuscolor=DARK["accent"])

    style.configure("TFrame", background=DARK["bg"])
    style.configure("TLabel", background=DARK["bg"], foreground=DARK["fg"])
    style.configure("Status.TLabel", background=DARK["bg"], foreground=DARK["muted"])

    style.configure("TEntry",
                    fieldbackground=DARK["panel"], foreground=DARK["fg"],
                    insertcolor=DARK["fg"], bordercolor=DARK["border"],
                    lightcolor=DARK["border"], darkcolor=DARK["border"])
    style.map("TEntry",
              fieldbackground=[("readonly", DARK["panel"])],
              bordercolor=[("focus", DARK["accent"])])

    style.configure("TSpinbox",
                    fieldbackground=DARK["panel"], foreground=DARK["fg"],
                    background=DARK["btn"], arrowcolor=DARK["fg"],
                    bordercolor=DARK["border"],
                    lightcolor=DARK["border"], darkcolor=DARK["border"])
    style.map("TSpinbox", bordercolor=[("focus", DARK["accent"])])

    style.configure("TButton",
                    background=DARK["btn"], foreground=DARK["fg"],
                    bordercolor=DARK["border"],
                    lightcolor=DARK["btn"], darkcolor=DARK["btn"],
                    focuscolor=DARK["accent"])
    style.map("TButton",
              background=[("active", DARK["btn_hover"]), ("pressed", DARK["btn_hover"])],
              bordercolor=[("focus", DARK["accent"])])

    style.configure("TCheckbutton",
                    background=DARK["bg"], foreground=DARK["fg"],
                    indicatorbackground=DARK["panel"],
                    indicatorforeground=DARK["fg"],
                    focuscolor=DARK["accent"])
    style.map("TCheckbutton",
              background=[("active", DARK["bg"])],
              indicatorbackground=[("selected", DARK["accent"]),
                                   ("active", DARK["panel"])])

    style.configure("TNotebook",
                    background=DARK["bg"], borderwidth=0,
                    bordercolor=DARK["border"],
                    lightcolor=DARK["border"], darkcolor=DARK["border"])
    style.configure("TNotebook.Tab",
                    background=DARK["panel"], foreground=DARK["muted"],
                    bordercolor=DARK["border"],
                    lightcolor=DARK["border"], darkcolor=DARK["border"],
                    padding=(12, 4))
    style.map("TNotebook.Tab",
              background=[("selected", DARK["bg"]), ("active", DARK["btn_hover"])],
              foreground=[("selected", DARK["fg"]), ("active", DARK["fg"])],
              bordercolor=[("selected", DARK["accent"])])


class _DarkText(tk.Text):
    """tk.Text preset with dark palette + scrollbar."""

    def __init__(self, parent, **kw):
        kw.setdefault("background", DARK["panel"])
        kw.setdefault("foreground", DARK["fg"])
        kw.setdefault("insertbackground", DARK["fg"])
        kw.setdefault("selectbackground", DARK["select_bg"])
        kw.setdefault("selectforeground", DARK["fg"])
        kw.setdefault("borderwidth", 1)
        kw.setdefault("relief", "flat")
        kw.setdefault("highlightthickness", 1)
        kw.setdefault("highlightbackground", DARK["border"])
        kw.setdefault("highlightcolor", DARK["accent"])
        super().__init__(parent, **kw)


class Worker:
    def __init__(self) -> None:
        self.loop = asyncio.new_event_loop()
        threading.Thread(target=self._run, daemon=True).start()

    def _run(self) -> None:
        asyncio.set_event_loop(self.loop)
        self.loop.run_forever()

    def submit(self, coro):
        return asyncio.run_coroutine_threadsafe(coro, self.loop)


class App:
    def __init__(self, root: tk.Tk) -> None:
        self.root = root
        self.worker = Worker()
        self.future = None
        self.report_dir: Path | None = None

        cfg_path = _project_root() / "data" / "ad_scan_launcher.json"
        self._cfg_path = cfg_path

        root.title("Ad Scan")
        root.geometry("520x560")
        root.minsize(440, 480)

        _apply_dark_theme(root)
        cfg = self._load_cfg()
        pad = {"padx": 8, "pady": 3}

        ttk.Label(root, text="Keyword").grid(row=0, column=0, sticky="w", **pad)
        self.q = tk.StringVar(value=cfg.get("query", ""))
        ttk.Entry(root, textvariable=self.q).grid(row=0, column=1, sticky="we", **pad)

        # Tabbed greenlist / orangelist
        nb = ttk.Notebook(root)
        nb.grid(row=1, column=0, columnspan=2, sticky="nsew", padx=8, pady=4)

        green_tab = ttk.Frame(nb, padding=4)
        nb.add(green_tab, text="Greenlist")
        self.g = _DarkText(green_tab, height=7, wrap="word")
        self.g.pack(fill=tk.BOTH, expand=True)
        self.g.insert("1.0", cfg.get("greenlist", ""))

        orange_tab = ttk.Frame(nb, padding=4)
        nb.add(orange_tab, text="Orangelist")
        self.o = _DarkText(orange_tab, height=7, wrap="word")
        self.o.pack(fill=tk.BOTH, expand=True)
        self.o.insert("1.0", cfg.get("orangelist", ""))

        # Options
        opts = ttk.Frame(root)
        opts.grid(row=2, column=0, columnspan=2, sticky="we", **pad)
        ttk.Label(opts, text="num").pack(side=tk.LEFT)
        self.num = tk.IntVar(value=int(cfg.get("num", 20)))
        ttk.Spinbox(opts, from_=10, to=100, increment=10, width=4, textvariable=self.num).pack(side=tk.LEFT, padx=(2, 10))
        ttk.Label(opts, text="Proxy").pack(side=tk.LEFT)
        self.proxy_var = tk.StringVar(value=cfg.get("proxy", "None"))
        ttk.Combobox(opts, textvariable=self.proxy_var,
                     values=list(PROXY_PRESETS.keys()),
                     state="readonly", width=12).pack(side=tk.LEFT, padx=(2, 10))
        self.headless = tk.BooleanVar(value=bool(cfg.get("headless", False)))
        ttk.Checkbutton(opts, text="headless", variable=self.headless).pack(side=tk.LEFT, padx=4)
        self.keep = tk.BooleanVar(value=bool(cfg.get("keep_open", True)))
        ttk.Checkbutton(opts, text="keep open", variable=self.keep).pack(side=tk.LEFT, padx=4)

        # Buttons
        btns = ttk.Frame(root)
        btns.grid(row=3, column=0, columnspan=2, sticky="we", **pad)
        self.run_btn = ttk.Button(btns, text="Run", command=self.on_run)
        self.run_btn.pack(side=tk.LEFT)
        ttk.Button(btns, text="Save", command=self.on_save).pack(side=tk.LEFT, padx=4)
        ttk.Button(btns, text="Copy logs", command=self.on_copy_logs).pack(side=tk.LEFT, padx=4)
        ttk.Button(btns, text="Open folder", command=self.open_folder).pack(side=tk.LEFT, padx=4)
        ttk.Button(btns, text="Quit", command=self.on_quit).pack(side=tk.RIGHT)

        # Status + output
        self.status = tk.StringVar(value="Idle.")
        ttk.Label(root, textvariable=self.status, style="Status.TLabel").grid(
            row=4, column=0, columnspan=2, sticky="w", **pad
        )
        self.out = _DarkText(root, height=12, wrap="word", font=("Consolas", 9))
        self.out.grid(row=5, column=0, columnspan=2, sticky="nsew", padx=8, pady=(0, 8))

        root.columnconfigure(0, weight=0)
        root.columnconfigure(1, weight=1)
        root.rowconfigure(1, weight=0)
        root.rowconfigure(5, weight=1)
        root.protocol("WM_DELETE_WINDOW", self.on_quit)

    _DEFAULTS = {
        "query": "mens running shoes buy online",
        "greenlist": "",
        "orangelist": "https://us.groundies.com/collections/*",
        "num": 20,
        "headless": False,
        "keep_open": True,
        "proxy": "None",
    }

    def _load_cfg(self) -> dict:
        try:
            saved = json.loads(self._cfg_path.read_text(encoding="utf-8"))
        except Exception:
            saved = {}
        # Empty string in saved cfg should NOT wipe a non-empty default —
        # prefer the default for blank text fields.
        merged = dict(self._DEFAULTS)
        for k, v in saved.items():
            if isinstance(v, str) and not v.strip():
                continue
            merged[k] = v
        return merged

    def _save_cfg(self) -> None:
        try:
            self._cfg_path.parent.mkdir(parents=True, exist_ok=True)
            self._cfg_path.write_text(json.dumps({
                "query": self.q.get(),
                "greenlist": self.g.get("1.0", "end").strip(),
                "orangelist": self.o.get("1.0", "end").strip(),
                "num": int(self.num.get()),
                "headless": bool(self.headless.get()),
                "keep_open": bool(self.keep.get()),
                "proxy": self.proxy_var.get(),
            }, indent=2), encoding="utf-8")
        except Exception:
            pass

    def on_save(self) -> None:
        self._save_cfg()
        self.status.set(f"Saved defaults to {self._cfg_path.name}.")

    def on_copy_logs(self) -> None:
        """Copy the latest run's debug.log to the clipboard."""
        runs_dir = Path(__file__).resolve().parent / "_runs"
        log_path: Path | None = None
        if self.report_dir and (self.report_dir / "debug.log").exists():
            log_path = self.report_dir / "debug.log"
        elif runs_dir.exists():
            candidates = sorted(runs_dir.glob("*/debug.log"),
                                key=lambda p: p.stat().st_mtime, reverse=True)
            if candidates:
                log_path = candidates[0]
        if not log_path or not log_path.exists():
            messagebox.showinfo("No log", "Run a scan first — no debug.log to copy yet.")
            return
        try:
            content = log_path.read_text(encoding="utf-8", errors="replace")
            self.root.clipboard_clear()
            self.root.clipboard_append(content)
            self.root.update()  # ensure clipboard is materialized on Windows
            self.status.set(f"Copied {log_path.parent.name}/debug.log "
                            f"({len(content)} chars) to clipboard.")
        except Exception as e:
            messagebox.showerror("Copy failed", str(e))

    def _lines(self, w: scrolledtext.ScrolledText) -> list[str]:
        return [ln.strip() for ln in w.get("1.0", "end").splitlines() if ln.strip()]

    def on_run(self) -> None:
        if self.future and not self.future.done():
            return
        q = self.q.get().strip()
        if not q:
            messagebox.showerror("Missing", "Enter a keyword.")
            return
        self._save_cfg()
        self.out.delete("1.0", "end")
        self.run_btn.config(state=tk.DISABLED)
        self.status.set(f"Launching browser for '{q}'…")
        self.future = self.worker.submit(self._do_run(q, self._lines(self.g), self._lines(self.o)))
        self.future.add_done_callback(self._done)

    async def _do_run(self, query: str, green: list[str], orange: list[str]) -> dict:
        settings.ensure_dirs()
        proxy_choice = self.proxy_var.get()
        proxy = _parse_proxy_str(PROXY_PRESETS.get(proxy_choice, ""))
        headless = bool(self.headless.get())

        # Chromium routinely fails to open google.com through these residential
        # proxies (handshake quirks / TLS fingerprinting). Camoufox (stealth
        # Firefox) tunnels through them reliably, so use it whenever a proxy
        # is selected. Plain chromium is fine for no-proxy runs.
        engine = "camoufox" if proxy is not None else "chromium"

        if proxy is None:
            sess = await SessionRegistry.get().create(
                engine=engine, mode="stealth", headless=headless,
                no_proxy=True, proxy_provider=None,
            )
        else:
            sess = await _create_session_with_proxy(proxy, engine, headless)
        try:
            return await run_google_ad_scan(
                session_id=sess.id, query=query,
                greenlist=green, orangelist=orange,
                num=int(self.num.get()), settle_ms=2500, screenshot=True,
                proxy=proxy,
            )
        finally:
            if not self.keep.get():
                try:
                    if sess.context:
                        await sess.context.close()
                except Exception:
                    pass
                sess.closed = True

    def _done(self, fut) -> None:
        try:
            report = fut.result()
        except Exception as e:
            import traceback
            self.root.after(0, self._err, e, traceback.format_exc())
            return
        self.root.after(0, self._render, report)

    def _err(self, e: Exception, tb: str) -> None:
        self.run_btn.config(state=tk.NORMAL)
        self.status.set(f"Error: {e}")
        self.out.insert("end", tb)

    def _render(self, r: dict) -> None:
        self.run_btn.config(state=tk.NORMAL)
        s = r.get("summary", {})
        self.status.set(
            f"Done — {s.get('ads_detected', 0)} ad(s); "
            f"green={s.get('green_matches', 0)} orange={s.get('orange_matches', 0)}"
        )
        rp = r.get("artifacts", {}).get("report_json")
        self.report_dir = Path(rp).parent if rp else None
        lines = [
            f"Query:    {r.get('query')}",
            f"Engine:   {r.get('session', {}).get('engine')}  "
            f"headless={r.get('session', {}).get('headless')}",
            f"Duration: {r.get('duration_ms')} ms",
            "",
            f"Ads:      {s.get('ads_detected', 0)}  "
            f"(green {s.get('green_matches', 0)} / orange {s.get('orange_matches', 0)})",
            "",
            "Greenlist:",
        ]
        for p in r.get("greenlist_presence", []) or [{"item": "(empty)", "appeared": False}]:
            mark = "HIT " if p.get("appeared") else "miss"
            pos = p.get("positions") or ""
            lines.append(f"  [{mark}] {p.get('item')}  {pos}")
        lines.append("")
        lines.append("Orangelist:")
        for p in r.get("orangelist_presence", []) or [{"item": "(empty)", "appeared": False}]:
            mark = "HIT " if p.get("appeared") else "miss"
            pos = p.get("positions") or ""
            lines.append(f"  [{mark}] {p.get('item')}  {pos}")
        lines.append("")
        lines.append("Ads found:")
        for ad in r.get("ads", []):
            tag = (ad.get("list") or "-").upper()
            lines.append(
                f"  #{ad['position']:>2} [{tag:<6}] "
                f"{(ad.get('host') or '?')[:24]:<24} {(ad.get('title') or '')[:50]}"
            )
        lines.append("")
        lines.append(f"Report: {rp}")
        self.out.insert("end", "\n".join(lines))

    def open_folder(self) -> None:
        if not self.report_dir:
            messagebox.showinfo("No report", "Run a scan first.")
            return
        try:
            os.startfile(str(self.report_dir))  # type: ignore[attr-defined]
        except Exception:
            webbrowser.open(self.report_dir.as_uri())

    def on_quit(self) -> None:
        self._save_cfg()
        try:
            self.worker.loop.call_soon_threadsafe(self.worker.loop.stop)
        except Exception:
            pass
        self.root.destroy()


def main() -> None:
    # Chdir to project root only when run as a script — never on import,
    # since the tasks package auto-imports every sibling module at startup.
    try:
        os.chdir(_project_root())
    except Exception:
        pass
    root = tk.Tk()
    App(root)
    root.mainloop()


if __name__ == "__main__":
    main()
