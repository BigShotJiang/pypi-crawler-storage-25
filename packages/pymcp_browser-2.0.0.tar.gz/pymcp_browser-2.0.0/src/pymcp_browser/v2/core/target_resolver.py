from __future__ import annotations
import re
from typing import Any
from ..control.errors import ToolError

REF_RE = re.compile(r"^e\d+$")


async def resolve_target(sess, target: str) -> Any:
    """Return Locator-like or ElementHandle for a ref or selector. Raises ToolError on miss."""
    if not target:
        raise ToolError("invalid_args", "target required")
    if REF_RE.match(target):
        ent = sess.ref_store.get(target)
        if ent is None:
            raise ToolError("ref_stale", f"ref {target} not found", ref=target)
        try:
            still = await ent.handle.evaluate("el => el && el.isConnected")
            if not still:
                raise ToolError("ref_stale", f"ref {target} detached", ref=target)
        except ToolError:
            raise
        except Exception:
            raise ToolError("ref_stale", f"ref {target} eval failed", ref=target)
        return ent.handle
    page = sess.active_page()
    if page is None:
        raise ToolError("session_not_found", "no active page")
    flags = getattr(sess, "human_flags", None)
    if flags and flags.get("auto_wait_load"):
        try:
            await page.wait_for_load_state("domcontentloaded", timeout=8000)
        except Exception:
            pass
    return page.locator(target)


async def resolve_page(sess) -> Any:
    p = sess.active_page()
    if p is None:
        raise ToolError("session_not_found", "no active page")
    return p
