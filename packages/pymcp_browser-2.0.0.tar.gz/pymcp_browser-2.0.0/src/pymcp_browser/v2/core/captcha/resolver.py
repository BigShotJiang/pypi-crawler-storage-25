from __future__ import annotations
import asyncio
import json
import time
from pathlib import Path
import httpx
from loguru import logger


def _load_keys() -> dict:
    """Read captcha provider keys from project-local data/credentials.json."""
    local = Path("./data/credentials.json")
    if local.exists():
        try:
            return json.loads(local.read_text(encoding="utf-8"))
        except Exception:
            return {}
    return {}


async def solve_capsolver(captcha_type: str, sitekey: str, url: str,
                          invisible: bool = False,
                          page_action: str | None = None,
                          score_only: bool = False,
                          min_score: float = 0.7,
                          proxy_address: str | None = None,
                          proxy_type: str | None = None,
                          proxy_login: str | None = None,
                          proxy_password: str | None = None) -> tuple[str, str]:
    """Solve via CapSolver. When proxy_* are provided, uses non-Proxyless task
    type so the solver runs through the same egress IP as the browser.

    proxy_address: "host:port" OR "host" (port resolved separately).
    proxy_type:    "http"|"https"|"socks5"|... (defaults to "http").
    """
    keys = _load_keys()
    api_key = keys.get("capsolver", {}).get("api_key") or keys.get("CAPSOLVER_KEY")
    if not api_key:
        raise RuntimeError("capsolver api key missing in data/credentials.json")

    use_proxy = bool(proxy_address)

    # Score-only (no challenge UI) variants need v3-style task types
    if score_only and captcha_type == "recaptcha_enterprise":
        task_type = "ReCaptchaV3EnterpriseTaskProxyless"
    elif score_only and captcha_type in ("recaptcha_v3", "recaptcha_v2"):
        task_type = "ReCaptchaV3TaskProxyless"
    elif captcha_type == "recaptcha_v3":
        task_type = "ReCaptchaV3TaskProxyless"
    else:
        task_type = {
            "recaptcha_v2": "ReCaptchaV2TaskProxyless",
            "recaptcha_enterprise": "ReCaptchaV2EnterpriseTaskProxyless",
            "hcaptcha": "HCaptchaTaskProxyless",
            "turnstile": "AntiTurnstileTaskProxyless",
        }.get(captcha_type)
    if not task_type:
        raise RuntimeError(f"unsupported captcha type {captcha_type}")

    # When proxy provided, switch to non-Proxyless variant so solver tunnels
    # through the same egress as the browser session.
    if use_proxy and task_type.endswith("Proxyless"):
        task_type = task_type[:-len("Proxyless")]

    task: dict = {"type": task_type, "websiteURL": url, "websiteKey": sitekey}
    if captcha_type in ("recaptcha_v2", "recaptcha_enterprise", "recaptcha_v3"):
        if not score_only:
            task["isInvisible"] = bool(invisible)
        task["pageAction"] = page_action or "submit"
        if score_only or captcha_type == "recaptcha_v3":
            task["minScore"] = float(min_score)
    if use_proxy:
        host, _, port = proxy_address.partition(":")
        try:
            port_i = int(port) if port else 80
        except ValueError:
            port_i = 80
        task["proxyType"] = (proxy_type or "http").lower()
        task["proxyAddress"] = host
        task["proxyPort"] = port_i
        if proxy_login:
            task["proxyLogin"] = proxy_login
        if proxy_password:
            task["proxyPassword"] = proxy_password
    payload = {"clientKey": api_key, "task": task}
    async with httpx.AsyncClient(timeout=30) as client:
        r = await client.post("https://api.capsolver.com/createTask", json=payload)
        data = r.json()
        if data.get("errorId"):
            raise RuntimeError(f"capsolver createTask: {data}")
        task_id = data["taskId"]
        for _ in range(60):
            await asyncio.sleep(2)
            r = await client.post("https://api.capsolver.com/getTaskResult",
                                  json={"clientKey": api_key, "taskId": task_id})
            d = r.json()
            if d.get("status") == "ready":
                return d["solution"]["gRecaptchaResponse"], task_id
            if d.get("errorId"):
                raise RuntimeError(f"capsolver getTaskResult: {d}")
        raise RuntimeError("capsolver timeout")


async def solve_twocaptcha(captcha_type: str, sitekey: str, url: str) -> tuple[str, str]:
    keys = _load_keys()
    api_key = keys.get("twocaptcha", {}).get("api_key") or keys.get("TWOCAPTCHA_KEY")
    if not api_key:
        raise RuntimeError("twocaptcha api key missing")
    method = {
        "recaptcha_v2": "userrecaptcha", "recaptcha_enterprise": "userrecaptcha",
        "hcaptcha": "hcaptcha", "turnstile": "turnstile",
    }.get(captcha_type)
    if not method:
        raise RuntimeError(f"unsupported {captcha_type}")
    async with httpx.AsyncClient(timeout=30) as client:
        params = {"key": api_key, "method": method, "googlekey": sitekey,
                  "pageurl": url, "json": 1}
        if captcha_type == "recaptcha_enterprise":
            params["enterprise"] = 1
        r = await client.get("https://2captcha.com/in.php", params=params)
        d = r.json()
        if d.get("status") != 1:
            raise RuntimeError(f"2captcha in: {d}")
        cap_id = d["request"]
        for _ in range(60):
            await asyncio.sleep(3)
            r = await client.get("https://2captcha.com/res.php",
                                 params={"key": api_key, "action": "get",
                                         "id": cap_id, "json": 1})
            d = r.json()
            if d.get("status") == 1:
                return d["request"], cap_id
        raise RuntimeError("2captcha timeout")


async def solve(captcha_type: str, sitekey: str, url: str,
                provider: str = "capsolver",
                invisible: bool = False,
                page_action: str | None = None,
                score_only: bool = False,
                min_score: float = 0.7,
                proxy_address: str | None = None,
                proxy_type: str | None = None,
                proxy_login: str | None = None,
                proxy_password: str | None = None) -> tuple[str, str, int]:
    t0 = time.time()
    if provider == "twocaptcha":
        token, cid = await solve_twocaptcha(captcha_type, sitekey, url)
    else:
        token, cid = await solve_capsolver(captcha_type, sitekey, url,
                                           invisible=invisible,
                                           page_action=page_action,
                                           score_only=score_only,
                                           min_score=min_score,
                                           proxy_address=proxy_address,
                                           proxy_type=proxy_type,
                                           proxy_login=proxy_login,
                                           proxy_password=proxy_password)
    return token, cid, int((time.time() - t0) * 1000)
