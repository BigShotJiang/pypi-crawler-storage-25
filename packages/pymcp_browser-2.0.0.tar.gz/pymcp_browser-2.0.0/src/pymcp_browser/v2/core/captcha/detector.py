from __future__ import annotations
from typing import Any


async def detect_captcha(page: Any) -> dict | None:
    """Return {type, sitekey, invisible, action?, cdata?} or None.

    Scans both <iframe> tags (visible + invisible reCAPTCHA v2/Enterprise,
    hCaptcha, Turnstile) and <script> tags (score-only invisible reCAPTCHA
    Enterprise / v3 that renders no iframe).
    """
    try:
        result = await page.evaluate("""
        () => {
          const out = {found: false};
          // 1) iframe scan — visible/invisible v2, hcaptcha, turnstile
          for (const fr of document.querySelectorAll('iframe')) {
            const src = fr.src || '';
            if (src.includes('recaptcha/enterprise/anchor')) {
              out.found = true;
              out.type = 'recaptcha_enterprise';
              try { out.sitekey = new URL(src).searchParams.get('k'); } catch {}
              out.invisible = src.includes('size=invisible');
              return out;
            }
            if (src.includes('recaptcha/api2/anchor')) {
              out.found = true;
              out.type = 'recaptcha_v2';
              try { out.sitekey = new URL(src).searchParams.get('k'); } catch {}
              out.invisible = src.includes('size=invisible');
              return out;
            }
            if (src.includes('hcaptcha.com/captcha')) {
              out.found = true;
              out.type = 'hcaptcha';
              try { out.sitekey = new URL(src).searchParams.get('sitekey'); } catch {}
              return out;
            }
            if (src.includes('challenges.cloudflare.com/turnstile')) {
              out.found = true;
              out.type = 'turnstile';
              return out;
            }
          }
          // 2) script-tag scan — score-only enterprise / v3, no iframe rendered
          for (const sc of document.querySelectorAll('script[src]')) {
            const src = sc.src || '';
            // recaptcha enterprise score-only
            if (src.includes('recaptcha/enterprise.js?render=')
                || src.includes('recaptcha/enterprise.js/render=')) {
              try {
                const u = new URL(src);
                const sk = u.searchParams.get('render');
                if (sk && sk !== 'explicit') {
                  out.found = true;
                  out.type = 'recaptcha_enterprise';
                  out.sitekey = sk;
                  out.invisible = true;
                  out.score_only = true;
                  return out;
                }
              } catch {}
            }
            // recaptcha v3 (non-enterprise)
            if (src.includes('recaptcha/api.js?render=')
                && !src.includes('render=explicit')) {
              try {
                const u = new URL(src);
                const sk = u.searchParams.get('render');
                if (sk) {
                  out.found = true;
                  out.type = 'recaptcha_v3';
                  out.sitekey = sk;
                  out.invisible = true;
                  out.score_only = true;
                  return out;
                }
              } catch {}
            }
          }
          // 3) data-sitekey on common widget divs (fallback)
          const widget = document.querySelector('[data-sitekey]');
          if (widget) {
            const sk = widget.getAttribute('data-sitekey');
            const cls = widget.className || '';
            if (cls.includes('h-captcha')) {
              out.found = true; out.type = 'hcaptcha'; out.sitekey = sk; return out;
            }
            if (cls.includes('cf-turnstile')) {
              out.found = true; out.type = 'turnstile'; out.sitekey = sk; return out;
            }
            if (cls.includes('g-recaptcha')) {
              out.found = true; out.type = 'recaptcha_v2'; out.sitekey = sk; return out;
            }
          }
          // 4) grecaptcha enterprise object presence (sitekey unknown — caller must hint)
          if (window.grecaptcha && window.grecaptcha.enterprise) {
            out.found = true; out.type = 'recaptcha_enterprise';
            out.invisible = true; out.score_only = true;
            out.sitekey = null;  // caller must extract from page or config
            out.note = 'grecaptcha_enterprise_present_no_sitekey';
            return out;
          }
          return out;
        }
        """)
    except Exception:
        return None
    if not result or not result.get("found"):
        return None
    return {k: v for k, v in result.items() if k != "found"}


async def inject_token(page: Any, captcha_type: str, token: str) -> None:
    if captcha_type in ("recaptcha_v2", "recaptcha_enterprise"):
        await page.evaluate("""
        (token) => {
          const els = document.querySelectorAll(
            'textarea[name="g-recaptcha-response"], textarea[id^="g-recaptcha-response"]');
          els.forEach(el => { el.value = token; el.innerHTML = token; });
        }
        """, token)
    elif captcha_type == "hcaptcha":
        await page.evaluate("""
        (token) => {
          const els = document.querySelectorAll(
            'textarea[name="h-captcha-response"], textarea[name="g-recaptcha-response"]');
          els.forEach(el => { el.value = token; el.innerHTML = token; });
        }
        """, token)
    elif captcha_type == "turnstile":
        await page.evaluate("""
        (token) => {
          const els = document.querySelectorAll('input[name="cf-turnstile-response"]');
          els.forEach(el => { el.value = token; });
        }
        """, token)
