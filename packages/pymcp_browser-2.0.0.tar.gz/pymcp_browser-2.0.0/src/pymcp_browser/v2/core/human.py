from __future__ import annotations
import asyncio
import random
from typing import Any


def _flags(sess) -> dict:
    f = getattr(sess, "human_flags", None)
    if not f:
        from .modes import mode_flags
        f = mode_flags(getattr(sess, "mode", "stealth"))
    return f


async def post_action_sleep(sess) -> None:
    f = _flags(sess)
    lo, hi = f.get("inter_action_ms_min", 0), f.get("inter_action_ms_max", 0)
    if hi <= 0:
        return
    await asyncio.sleep(random.uniform(lo, hi) / 1000)


async def hover_dwell(sess) -> None:
    f = _flags(sess)
    lo, hi = f.get("hover_dwell_ms_min", 0), f.get("hover_dwell_ms_max", 0)
    if hi <= 0:
        return
    await asyncio.sleep(random.uniform(lo, hi) / 1000)


def jitter_offset(sess) -> tuple[int, int]:
    f = _flags(sess)
    px = f.get("mouse_jitter_px", 0)
    if px <= 0:
        return 0, 0
    return random.randint(-px, px), random.randint(-px, px)


def type_delay_range(sess) -> tuple[int, int]:
    f = _flags(sess)
    return f.get("type_delay_ms_min", 0), f.get("type_delay_ms_max", 0)


async def auto_wait_load(sess) -> None:
    f = _flags(sess)
    if not f.get("auto_wait_load"):
        return
    page = sess.active_page() if hasattr(sess, "active_page") else None
    if page is None:
        return
    try:
        await page.wait_for_load_state("domcontentloaded", timeout=8000)
    except Exception:
        pass


def is_human(sess) -> bool:
    return getattr(sess, "mode", "") == "human"


# ====================================================================
# Run-Clean human-realism helpers (Phase 1)
# Used by core.macro_runner cleaners: human_mouse, human_pause, human_typing.
# Speed profile drives all timing knobs.
# ====================================================================

import math


SPEED_PROFILES: dict[str, dict[str, Any]] = {
    "fast": {
        "interevent_median_ms": 400,
        "interevent_sigma": 0.45,
        "key_median_ms": 70,
        "key_sigma_ms": 25,
        "key_min_ms": 35,
        "key_max_ms": 180,
        "mouse_duration_ms": (180, 300),
        "click_min_gap_ms": 200,
        "submit_min_gap_ms": 400,
        "scroll_step_ms": (12, 22),
        "reading_pause_ms": (700, 1800),
    },
    "natural": {
        "interevent_median_ms": 800,
        "interevent_sigma": 0.4,
        "key_median_ms": 110,
        "key_sigma_ms": 35,
        "key_min_ms": 45,
        "key_max_ms": 220,
        "mouse_duration_ms": (250, 450),
        "click_min_gap_ms": 250,
        "submit_min_gap_ms": 600,
        "scroll_step_ms": (16, 32),
        "reading_pause_ms": (1500, 4000),
    },
    "cautious": {
        "interevent_median_ms": 1200,
        "interevent_sigma": 0.35,
        "key_median_ms": 165,
        "key_sigma_ms": 50,
        "key_min_ms": 70,
        "key_max_ms": 320,
        "mouse_duration_ms": (380, 680),
        "click_min_gap_ms": 380,
        "submit_min_gap_ms": 900,
        "scroll_step_ms": (24, 45),
        "reading_pause_ms": (2200, 5500),
    },
}


def get_speed_profile(name: str) -> dict[str, Any]:
    return SPEED_PROFILES.get(name) or SPEED_PROFILES["natural"]


def lognormal_pause_s(median_ms: float, sigma: float = 0.4,
                      min_ms: float = 80, max_ms: float = 8000) -> float:
    """Sample inter-event delay from log-normal distribution.

    Median = `median_ms`. Sigma controls spread (0.4 ≈ realistic human spread).
    Clamped to [min_ms, max_ms]. Returns seconds.
    """
    mu = math.log(max(median_ms, 1.0))
    val = random.lognormvariate(mu, sigma)
    val = max(min_ms, min(max_ms, val))
    return val / 1000.0


def gauss_clamped(mean: float, sigma: float, lo: float, hi: float) -> float:
    """Gauss sample clamped to range."""
    v = random.gauss(mean, sigma)
    return max(lo, min(hi, v))


def keystroke_delay_s(profile: dict, char: str = "") -> float:
    """Per-char typing delay from speed profile.

    Adds 200-400ms extra on sentence boundaries (`. ! ?`).
    Returns seconds.
    """
    base = gauss_clamped(profile["key_median_ms"], profile["key_sigma_ms"],
                         profile["key_min_ms"], profile["key_max_ms"])
    if char in (".", "!", "?"):
        base += random.uniform(200, 400)
    elif char in (",", ";", ":"):
        base += random.uniform(80, 180)
    elif char == " ":
        base += random.uniform(20, 60)
    return base / 1000.0


_TYPO_KEYS = "abcdefghijklmnopqrstuvwxyz"


def maybe_typo(char: str, rate: float = 0.02) -> list[str]:
    """Return a key sequence that may include a typo + backspace correction.

    Returns:
      [char]                              # normal (98% case)
      [wrong_char, "Backspace", char]     # typo (2% case)

    Only triggers on alphanumeric characters; punctuation/whitespace passes through.
    """
    if not char or not char.isalnum() or random.random() > rate:
        return [char]
    wrong = random.choice(_TYPO_KEYS)
    if wrong == char.lower():
        wrong = random.choice(_TYPO_KEYS.replace(char.lower(), ""))
    # preserve case
    if char.isupper():
        wrong = wrong.upper()
    return [wrong, "Backspace", char]


def bezier_path(start: tuple[float, float], end: tuple[float, float],
                n_waypoints: int = 16,
                jitter_px: float = 1.5,
                overshoot_px: float = 3.0) -> list[tuple[float, float]]:
    """Generate a cubic-Bezier cursor path from start → end.

    Two control points pulled slightly off the straight line (perpendicular
    offset 8-25% of distance). Returns list of (x, y) waypoints, length
    `n_waypoints + 2` (includes overshoot + settle at the end so the cursor
    arrives slightly past target then comes back, mimicking human deceleration).
    """
    x0, y0 = start
    x1, y1 = end
    dx, dy = x1 - x0, y1 - y0
    dist = math.hypot(dx, dy)
    if dist < 1:
        return [end]
    # perpendicular vector (unit)
    nx, ny = -dy / dist, dx / dist
    # control point offsets (random sign + magnitude 8-25% of distance)
    off1 = random.uniform(0.08, 0.25) * dist * random.choice((-1, 1))
    off2 = random.uniform(0.08, 0.25) * dist * random.choice((-1, 1))
    # control points along the path at ~30% and ~70%
    c1 = (x0 + dx * 0.3 + nx * off1, y0 + dy * 0.3 + ny * off1)
    c2 = (x0 + dx * 0.7 + nx * off2, y0 + dy * 0.7 + ny * off2)

    pts: list[tuple[float, float]] = []
    for i in range(n_waypoints + 1):
        t = i / n_waypoints
        # cubic bezier
        u = 1 - t
        bx = u * u * u * x0 + 3 * u * u * t * c1[0] + 3 * u * t * t * c2[0] + t * t * t * x1
        by = u * u * u * y0 + 3 * u * u * t * c1[1] + 3 * u * t * t * c2[1] + t * t * t * y1
        # per-waypoint jitter
        jx = random.uniform(-jitter_px, jitter_px)
        jy = random.uniform(-jitter_px, jitter_px)
        pts.append((bx + jx, by + jy))
    # overshoot then settle
    over_dx = (random.uniform(1.5, overshoot_px) *
               (1 if dx >= 0 else -1) if abs(dx) > 0 else 0)
    over_dy = (random.uniform(1.5, overshoot_px) *
               (1 if dy >= 0 else -1) if abs(dy) > 0 else 0)
    pts.append((x1 + over_dx, y1 + over_dy))
    pts.append((x1, y1))
    return pts


async def _get_cursor(page) -> tuple[float, float]:
    """Best-effort current cursor position. Uses last value stored on page or
    centers on viewport at first call."""
    pos = getattr(page, "_pymcp_cursor", None)
    if pos:
        return pos
    try:
        vp = await page.evaluate("() => ({w: window.innerWidth, h: window.innerHeight})")
        cx = vp["w"] / 2 + random.uniform(-50, 50)
        cy = vp["h"] / 2 + random.uniform(-50, 50)
    except Exception:
        cx, cy = 640, 400
    page._pymcp_cursor = (cx, cy)
    return (cx, cy)


def _set_cursor(page, x: float, y: float) -> None:
    page._pymcp_cursor = (x, y)


async def _bbox_target(page, selector: str) -> tuple[float, float] | None:
    """Resolve target click coordinate inside element's bounding box."""
    try:
        el = await page.wait_for_selector(selector, state="visible", timeout=4000)
        if el is None:
            return None
        bbox = await el.bounding_box()
        if not bbox:
            return None
        # click slightly off-center for realism
        cx = bbox["x"] + bbox["width"] * random.uniform(0.35, 0.65)
        cy = bbox["y"] + bbox["height"] * random.uniform(0.35, 0.65)
        return (cx, cy)
    except Exception:
        return None


async def human_mouse_move(page, x: float, y: float, profile: dict) -> int:
    """Move cursor along Bezier path to (x, y). Returns waypoint count."""
    start = await _get_cursor(page)
    n_waypoints = random.randint(10, 18)
    path = bezier_path(start, (x, y), n_waypoints=n_waypoints)
    dur_lo, dur_hi = profile["mouse_duration_ms"]
    total_ms = random.uniform(dur_lo, dur_hi)
    durations = ease_out_step_durations(total_ms, len(path))
    for (px, py), d in zip(path, durations):
        try:
            await page.mouse.move(px, py)
        except Exception:
            pass
        if d > 0:
            await asyncio.sleep(d)
    _set_cursor(page, x, y)
    return len(path)


async def human_click(page, selector: str, profile: dict | None = None,
                      *, button: str = "left") -> dict:
    """Click `selector` with Bezier mouse path + mousedown-pause-mouseup.

    Returns stats dict: {mouse_path_len, target_x, target_y, ok}.
    """
    profile = profile or get_speed_profile("natural")
    target = await _bbox_target(page, selector)
    if target is None:
        return {"ok": False, "mouse_path_len": 0, "error": "target_not_visible"}
    waypoints = await human_mouse_move(page, *target, profile=profile)
    # mousedown → pause → mouseup
    try:
        await page.mouse.down(button=button)
        await asyncio.sleep(random.uniform(0.080, 0.140))
        await page.mouse.up(button=button)
    except Exception as e:
        return {"ok": False, "mouse_path_len": waypoints, "error": str(e)}
    return {"ok": True, "mouse_path_len": waypoints,
            "target_x": target[0], "target_y": target[1]}


async def human_type(page, selector: str, text: str,
                     profile: dict | None = None,
                     *, typo_rate: float = 0.02,
                     focus_first: bool = True) -> dict:
    """Type `text` into `selector` with per-char delays + optional typos.

    Returns stats dict: {key_chars_typed, key_corrections, ok}.
    """
    profile = profile or get_speed_profile("natural")
    if focus_first:
        try:
            await page.focus(selector, timeout=4000)
        except Exception as e:
            return {"ok": False, "key_chars_typed": 0, "key_corrections": 0,
                    "error": f"focus_failed: {e}"}
    chars_typed = 0
    corrections = 0
    for ch in text:
        keys = maybe_typo(ch, rate=typo_rate)
        if len(keys) > 1:
            corrections += 1
        for k in keys:
            try:
                if k == "Backspace":
                    await page.keyboard.press("Backspace")
                else:
                    delay_s = keystroke_delay_s(profile, k)
                    # Playwright type() = per-char delay built-in, but we want
                    # full control. Use insertText for content, asyncio.sleep
                    # between for variance.
                    await page.keyboard.type(k, delay=0)
                    await asyncio.sleep(delay_s)
                chars_typed += 1
            except Exception as e:
                return {"ok": False, "key_chars_typed": chars_typed,
                        "key_corrections": corrections,
                        "error": f"keyboard_failed: {e}"}
    return {"ok": True, "key_chars_typed": chars_typed,
            "key_corrections": corrections}


async def human_scroll(page, delta_y: int, profile: dict | None = None) -> dict:
    """Scroll `delta_y` pixels via discrete wheel-step events.

    Replaces instant page.evaluate scrollBy with smooth wheel events at
    profile-controlled cadence. Returns stats: {steps_emitted}.
    """
    profile = profile or get_speed_profile("natural")
    if delta_y == 0:
        return {"ok": True, "steps_emitted": 0}
    sign = 1 if delta_y > 0 else -1
    remaining = abs(delta_y)
    step_lo, step_hi = profile["scroll_step_ms"]
    steps = 0
    cur = await _get_cursor(page)
    while remaining > 0:
        chunk = random.randint(30, 80)
        if chunk > remaining:
            chunk = remaining
        try:
            await page.mouse.wheel(0, sign * chunk)
        except Exception:
            try:
                await page.evaluate(f"window.scrollBy(0, {sign * chunk})")
            except Exception:
                break
        await asyncio.sleep(random.uniform(step_lo, step_hi) / 1000.0)
        remaining -= chunk
        steps += 1
    return {"ok": True, "steps_emitted": steps}


def ease_out_step_durations(total_ms: float, n_steps: int) -> list[float]:
    """Distribute total time across n steps with ease-out (slower at end).

    Returns list of per-step durations in seconds. Sum ≈ total_ms / 1000.
    """
    if n_steps <= 0:
        return []
    weights = []
    for i in range(n_steps):
        t = i / max(1, n_steps - 1)
        # ease-out: 1 - (1-t)^2 — slower at the end means smaller weight
        # actually for slower-at-end we want LARGER step durations later
        w = 1.0 + 1.5 * (t * t)  # quadratic ease-in for step DURATION
        weights.append(w)
    total = sum(weights)
    return [(w / total) * (total_ms / 1000.0) for w in weights]
