"""Macro recorder + compiler.

- MacroRecorder: per-session state machine (idle|recording|paused), JSONL writer,
  pick-mode, annotation queue, IME-safe input de-dup.
- try_selectors: replay-time helper used by compiled @task files.
- compile_macro: JSONL -> tasks/macro_<name>.py source.
- wire_macro: attach context bindings + init scripts (called from session.py).
"""
from __future__ import annotations

import asyncio
import importlib
import json
import re
import shutil
import time
from datetime import date as _date
from pathlib import Path
from typing import Any, Literal

from loguru import logger

from ..config import settings
from ..control.errors import ToolError
from .macro_js import RECORDER_JS, TOOLBAR_JS

SCHEMA_VERSION = 1
NAME_RE = re.compile(r"^[a-z][a-z0-9_]{0,40}$")
INPUT_DEDUP_WINDOW_S = 2.0


# ---------- recorder ----------------------------------------------------------

class MacroRecorder:
    """Per-session macro state. Lazy-created on first start."""

    def __init__(self, session_id: str, out_dir: Path):
        self.session_id = session_id
        self.out_dir = Path(out_dir) / session_id
        self.out_dir.mkdir(parents=True, exist_ok=True)
        self.status: Literal["idle", "recording", "paused"] = "idle"
        self.out_path: Path | None = None
        self.pending_label: str | None = None
        self.pick_mode: Literal[None, "wait", "assert"] = None
        self.last_input: tuple[str | None, float] = (None, 0.0)
        self.seq = 0
        self.events: list[dict] = []
        self._fh = None
        self._lock = asyncio.Lock()
        self._started_at: float | None = None
        self._label: str | None = None
        self._next_dynamic_nav: str | None = None  # consumed by add_nav

    # ----- lifecycle

    def start(self, label: str | None = None) -> dict:
        if self.status == "recording":
            return {"status": "recording", "path": str(self.out_path), "count": self.seq}
        ts = int(time.time())
        self.out_path = self.out_dir / f"macro_{ts}.jsonl"
        self._fh = self.out_path.open("a", encoding="utf-8")
        self.seq = 0
        self.events = []
        self._started_at = time.time()
        self._label = label
        self.status = "recording"
        self.pick_mode = None
        self.pending_label = None
        self._write({
            "kind": "macro_header",
            "v": SCHEMA_VERSION,
            "session_id": self.session_id,
            "started_at": self._started_at,
            "label": label,
            "agent": "pymcp-v2",
        })
        return {"status": "recording", "path": str(self.out_path), "count": 0}

    def stop(self) -> dict:
        if self.status == "idle":
            return {"status": "idle", "count": 0}
        path = self.out_path
        count = self.seq
        if self._fh:
            try:
                self._fh.flush()
                self._fh.close()
            except Exception:
                pass
            self._fh = None
        if path and path.exists():
            try:
                shutil.copyfile(path, path.parent / "latest.jsonl")
            except Exception as e:
                logger.warning("latest.jsonl copy failed: {}", e)
        self.status = "idle"
        return {"status": "idle", "path": str(path) if path else None, "count": count}

    def pause(self) -> dict:
        if self.status == "recording":
            self.status = "paused"
        return {"status": self.status, "count": self.seq}

    def resume(self) -> dict:
        if self.status == "paused":
            self.status = "recording"
        return {"status": self.status, "count": self.seq}

    def toggle(self) -> dict:
        if self.status == "recording":
            return self.pause()
        if self.status == "paused":
            return self.resume()
        return {"status": self.status, "count": self.seq}

    def annotate(self, label: str) -> dict:
        self.pending_label = label
        return {"status": self.status, "count": self.seq}

    def begin_pick(self, kind: Literal["wait", "assert"]) -> dict:
        self.pick_mode = kind
        return {"status": self.status, "pick": kind, "count": self.seq}

    def cancel_pick(self) -> dict:
        self.pick_mode = None
        return {"status": self.status, "count": self.seq}

    def state(self) -> dict:
        return {"status": self.status, "count": self.seq}

    # ----- ingestion

    def ingest(self, ev: dict) -> None:
        if self.status != "recording":
            return
        if not isinstance(ev, dict):
            return
        et = ev.get("type")
        if et == "recorder_error":
            logger.warning("recorder_error url={} msg={}",
                           ev.get("url"), ev.get("message"))
            return
        # de-dup consecutive input on same primary selector within window
        if et == "input":
            sels = ev.get("selectors") or {}
            primary = sels.get("primary")
            now = ev.get("ts") or time.time()
            last_sel, last_ts = self.last_input
            if primary and primary == last_sel and (now - last_ts) <= INPUT_DEDUP_WINDOW_S \
                    and self.events and self.events[-1].get("type") == "input" \
                    and (self.events[-1].get("selectors") or {}).get("primary") == primary:
                self.events[-1]["value"] = ev.get("value")
                self.events[-1]["ts"] = now
                self.last_input = (primary, now)
                return
            self.last_input = (primary, now)
        self.seq += 1
        ev["seq"] = self.seq
        if self.pending_label and et != "recorder_error":
            ev["label"] = self.pending_label
            self.pending_label = None
        self.events.append(ev)
        self._write(ev)

    def ingest_pick(self, kind: str, payload: dict) -> dict:
        if self.status != "recording":
            return {"status": self.status, "count": self.seq}
        ev = {
            "type": kind,  # 'wait' or 'assert'
            "ts": time.time(),
            "url": payload.get("url"),
            "frameUrl": payload.get("frameUrl"),
            "selectors": payload.get("selectors") or {},
            "elem": payload.get("elem") or {},
        }
        self.seq += 1
        ev["seq"] = self.seq
        if self.pending_label:
            ev["label"] = self.pending_label
            self.pending_label = None
        self.events.append(ev)
        self._write(ev)
        return {"status": self.status, "count": self.seq}

    def add_nav(self, url: str, trigger: str = "framenav") -> None:
        if self.status != "recording":
            return
        self.seq += 1
        ev = {
            "seq": self.seq, "type": "nav", "ts": time.time(),
            "url": url, "frameUrl": url, "trigger": trigger,
        }
        if self._next_dynamic_nav:
            ev["dynamic"] = self._next_dynamic_nav
            self._next_dynamic_nav = None
        self.events.append(ev)
        self._write(ev)

    def mark_dynamic_nav(self, kind: str) -> dict:
        """Tag the NEXT framenav event as dynamic (e.g. 'verify_url')."""
        self._next_dynamic_nav = kind
        return {"status": self.status, "next_dynamic": kind}

    def add_captcha(self, kind: str | None, provider: str = "capsolver",
                    ok: bool = True, sitekey: str | None = None,
                    invisible: bool | None = None) -> dict:
        """Append a 'captcha' step event so replay can re-solve at this point."""
        if self.status != "recording":
            return {"status": self.status, "count": self.seq}
        self.seq += 1
        ev: dict = {
            "seq": self.seq, "type": "captcha", "ts": time.time(),
            "kind": kind or "auto", "provider": provider, "ok": ok,
        }
        if sitekey:
            ev["sitekey"] = sitekey
        if invisible is not None:
            ev["invisible"] = invisible
        if self.pending_label:
            ev["label"] = self.pending_label
            self.pending_label = None
        self.events.append(ev)
        self._write(ev)
        return {"status": self.status, "count": self.seq, "kind": ev["kind"]}

    def _write(self, rec: dict) -> None:
        if self._fh is None:
            return
        try:
            self._fh.write(json.dumps(rec, ensure_ascii=False) + "\n")
            self._fh.flush()
        except Exception as e:
            logger.warning("macro jsonl write failed: {}", e)


# ---------- control dispatch (called from JS via __macroCtl__) ---------------

def macro_ctl_dispatch(sess: Any, msg: dict) -> dict:
    """Sync dispatcher. Lazy-creates sess.macro on first 'start'."""
    if not isinstance(msg, dict):
        return {"status": "idle", "count": 0}
    action = msg.get("action")
    payload = msg.get("payload") or {}
    if action == "status":
        rec = getattr(sess, "macro", None)
        if rec is None:
            return {"status": "idle", "count": 0}
        return rec.state()
    if action == "start":
        rec = _ensure_recorder(sess)
        return rec.start(label=payload.get("label"))
    if action == "stop":
        rec = getattr(sess, "macro", None)
        if rec is None:
            return {"status": "idle", "count": 0}
        return rec.stop()
    if action == "toggle":
        rec = getattr(sess, "macro", None)
        if rec is None:
            return {"status": "idle", "count": 0}
        return rec.toggle()
    if action == "annotate":
        rec = getattr(sess, "macro", None)
        if rec is None:
            return {"status": "idle", "count": 0}
        return rec.annotate(payload.get("label") or "")
    if action == "pick":
        rec = getattr(sess, "macro", None)
        if rec is None:
            return {"status": "idle", "count": 0}
        kind = msg.get("kind")
        if kind not in ("wait", "assert"):
            return rec.state()
        return rec.ingest_pick(kind, payload)
    if action == "pick_cancel":
        rec = getattr(sess, "macro", None)
        if rec is None:
            return {"status": "idle", "count": 0}
        return rec.cancel_pick()
    if action == "mark_dynamic":
        rec = getattr(sess, "macro", None)
        if rec is None:
            return {"status": "idle", "count": 0}
        kind = msg.get("kind") or "verify_url"
        return rec.mark_dynamic_nav(kind)
    if action == "record_captcha":
        rec = getattr(sess, "macro", None)
        if rec is None:
            return {"status": "idle", "count": 0}
        p = msg.get("payload") or {}
        return rec.add_captcha(
            kind=p.get("kind"),
            provider=p.get("provider", "capsolver"),
            ok=bool(p.get("ok", True)),
            sitekey=p.get("sitekey"),
            invisible=p.get("invisible"),
        )
    return {"status": "unknown_action", "count": 0}


def _ensure_recorder(sess: Any) -> MacroRecorder:
    rec = getattr(sess, "macro", None)
    if rec is None:
        rec = MacroRecorder(sess.id, Path(settings.macros_dir))
        sess.macro = rec
    return rec


# ---------- session wiring ---------------------------------------------------

async def wire_macro(sess: Any, toolbar: bool) -> None:
    """Attach __macroSink__ / __macroCtl__ bindings + init scripts.

    Called from SessionRegistry.create after sess is constructed but before
    page nav. Idempotent.
    """
    context = sess.context
    if context is None:
        return

    async def _sink(ev):
        try:
            rec = getattr(sess, "macro", None)
            if rec is not None:
                rec.ingest(ev if isinstance(ev, dict) else {})
        except Exception as e:
            logger.warning("macro sink err: {}", e)

    async def _ctl(msg):
        try:
            return macro_ctl_dispatch(sess, msg if isinstance(msg, dict) else {})
        except Exception as e:
            logger.warning("macro ctl err: {}", e)
            return {"status": "error", "message": str(e)}

    try:
        await context.expose_function("__macroSink__", _sink)
        await context.expose_function("__macroCtl__", _ctl)
        await context.add_init_script(RECORDER_JS)
        if toolbar:
            await context.add_init_script(TOOLBAR_JS)
    except Exception as e:
        logger.warning("macro wire failed: {}", e)
        return

    def _on_framenav(frame):
        try:
            rec = getattr(sess, "macro", None)
            if rec is None or rec.status != "recording":
                return
            rec.add_nav(frame.url, trigger="framenav")
        except Exception:
            pass

    def _on_page(page):
        try:
            page.on("framenavigated", _on_framenav)
        except Exception:
            pass

    try:
        context.on("page", _on_page)
        for p in getattr(sess, "pages", []) or []:
            _on_page(p)
    except Exception as e:
        logger.warning("macro framenav hook failed: {}", e)


# ---------- replay helper ----------------------------------------------------

async def try_selectors(target: Any, selectors: dict | list,
                        timeout_ms: int = 5000) -> Any:
    """Try primary, then alts. Log winner. Raise on full miss.

    `target` is a Playwright Page or Frame.
    `selectors` is either {primary, alts:[...]} dict or a flat list.
    """
    if isinstance(selectors, dict):
        cands = []
        if selectors.get("primary"):
            cands.append(selectors["primary"])
        cands.extend(selectors.get("alts") or [])
    else:
        cands = list(selectors or [])
    cands = [s for s in cands if s]
    if not cands:
        raise ToolError("not_found", "no selector candidates")
    last_err: Exception | None = None
    for i, sel in enumerate(cands):
        try:
            loc = target.locator(sel).first
            await loc.wait_for(state="visible", timeout=timeout_ms)
            if i > 0:
                logger.info("selector fallback won: {} (primary missed)", sel)
            return loc
        except Exception as e:
            last_err = e
            continue
    raise ToolError("not_found",
                    f"all selectors missed: {cands[:3]} ({last_err})")


# ---------- compiler ---------------------------------------------------------

def _gen_strict_id(name: str) -> None:
    if not NAME_RE.match(name or ""):
        raise ToolError("invalid_name",
                        f"name must match {NAME_RE.pattern}, got {name!r}")


def sanitize_macro_name(raw: str) -> str:
    """Coerce arbitrary text to a valid macro id matching NAME_RE.

    Lowercase, replace non-[a-z0-9_] with underscore, strip leading
    non-letters, collapse runs of underscores, truncate to 41 chars,
    and fall back to 'macro' on empty input.
    """
    s = (raw or "").strip().lower()
    # replace any disallowed char with underscore
    s = re.sub(r"[^a-z0-9_]+", "_", s)
    # strip leading non-letters (digits/underscores)
    s = re.sub(r"^[^a-z]+", "", s)
    # collapse multiple underscores
    s = re.sub(r"_+", "_", s).strip("_")
    s = s[:41]
    if not s:
        s = "macro"
    return s


def _read_jsonl(path: Path) -> tuple[dict | None, list[dict]]:
    header: dict | None = None
    events: list[dict] = []
    with path.open("r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                rec = json.loads(line)
            except Exception:
                continue
            if header is None and rec.get("kind") == "macro_header":
                header = rec
                continue
            if rec.get("kind") == "macro_header":
                continue  # skip stray headers
            if rec.get("type") == "recorder_error":
                continue
            events.append(rec)
    return header, events


def _py_repr(v: Any) -> str:
    return repr(v)


def _frame_call(target_var: str, selectors: dict, timeout_ms: int = 5000) -> str:
    sel_lit = _py_repr(selectors)
    return f"await try_selectors({target_var}, {sel_lit}, timeout_ms={timeout_ms})"


def _pick_target(ev: dict) -> tuple[str, list[str]]:
    """Return (target_var_expr, prelude_lines). Same-frame: 'page'.
    Cross-frame: 'frame_<n>' with prelude."""
    url = ev.get("url")
    fu = ev.get("frameUrl")
    if not fu or fu == url:
        return "page", []
    var = "_frame"
    return var, [
        f"{var} = page.frame(url={_py_repr(fu)}) or page",
    ]


def _compile_steps(events: list[dict]) -> list[str]:
    lines: list[str] = []
    seen_pages = {ev.get("url") for ev in events if ev.get("url")}
    multi = len([u for u in seen_pages if u]) > 1
    if multi:
        lines.append("# WARN: multi-page macro detected; review before running.")
    # initial navigation: goto first event url unless already there
    first_url = next((ev.get("url") for ev in events if ev.get("url")), None)
    if first_url:
        lines.append(f"_target_url = {_py_repr(first_url)}")
        lines.append("if page.url != _target_url:")
        lines.append("    await page.goto(_target_url, wait_until='domcontentloaded')")
        lines.append("    await asyncio.sleep(0.4)")
    for ev in events:
        et = ev.get("type")
        sels = ev.get("selectors") or {}
        label = ev.get("label")
        target_var, pre = _pick_target(ev)
        for p in pre:
            lines.append(p)
        if label:
            lines.append(f"# label: {label}")
        if et == "click":
            lines.append(f"loc = {_frame_call(target_var, sels)}")
            lines.append("await loc.click()")
            lines.append("await asyncio.sleep(step_delay_s)")
        elif et == "input":
            value = ev.get("value", "")
            dynamic = ev.get("dynamic")
            lines.append(f"loc = {_frame_call(target_var, sels)}")
            if dynamic == "otp":
                lines.append("_dyn = await _fetch_otp_dynamic(_imap_email, _imap_pass)")
                lines.append(f"await loc.fill(_dyn or {_py_repr(value)})")
            else:
                lines.append(f"await loc.fill({_py_repr(value)})")
            lines.append("await asyncio.sleep(step_delay_s)")
        elif et == "change":
            value = ev.get("value", "")
            lines.append(f"loc = {_frame_call(target_var, sels)}")
            lines.append(f"await loc.select_option({_py_repr(value)})")
            lines.append("await asyncio.sleep(step_delay_s)")
        elif et == "check":
            checked = bool(ev.get("checked"))
            lines.append(f"loc = {_frame_call(target_var, sels)}")
            lines.append(f"await loc.set_checked({checked})")
            lines.append("await asyncio.sleep(step_delay_s)")
        elif et == "key":
            key = ev.get("key", "")
            submits = bool(ev.get("submitsForm"))
            lines.append(f"await page.keyboard.press({_py_repr(key)})")
            if submits:
                lines.append('await page.wait_for_load_state("domcontentloaded")')
            lines.append("await asyncio.sleep(step_delay_s)")
        elif et == "nav":
            trigger = ev.get("trigger") or "framenav"
            dynamic = ev.get("dynamic")
            url = ev.get("url") or ""
            if dynamic == "verify_url":
                lines.append("_dyn_url = await _fetch_verify_url_dynamic(_imap_email, _imap_pass)")
                lines.append(f"await page.goto(_dyn_url or {_py_repr(url)}, wait_until='domcontentloaded')")
            elif trigger == "address_bar":
                lines.append(f"await page.goto({_py_repr(url)})")
            else:
                lines.append('await page.wait_for_load_state("domcontentloaded")')
        elif et == "captcha":
            kind = ev.get("kind", "auto")
            lines.append(f"# captcha step ({kind})")
            lines.append(f"_cap = await _solve_captcha_step(session_id, kind={_py_repr(kind)})")
            lines.append("await asyncio.sleep(step_delay_s)")
        elif et == "wait":
            lines.append(f"await try_selectors({target_var}, {_py_repr(sels)}, timeout_ms=10000)")
        elif et == "assert":
            elem = ev.get("elem") or {}
            expected = (elem.get("innerText") or elem.get("textContent")
                        or elem.get("value") or "")
            lines.append(f"loc = {_frame_call(target_var, sels)}")
            lines.append("got = (await loc.inner_text()) if await loc.count() else ''")
            lines.append(f"_expected = {_py_repr(expected)}")
            lines.append("if _expected and _expected not in got:")
            lines.append("    msg = f'assert miss: expected {_expected!r} not in {got!r}'")
            lines.append("    if strict:")
            lines.append("        raise RuntimeError(msg)")
            lines.append("    log.warning(msg)")
        else:
            lines.append(f"# skipped unknown event type: {et}")
    return lines


def _render_task(name: str, events: list[dict], header: dict | None) -> str:
    """Render a self-contained task module that dispatches each event through
    core.macro_runner.run_event. New format (Phase 1 of macro-toggles plan)."""
    today = _date.today().isoformat()
    src_label = (header or {}).get("label") or name
    # Embed events as a Python list literal. repr() gives valid syntax for
    # dicts/lists/strings/numbers/None — recorder events use only those types.
    events_repr = "[\n        " + ",\n        ".join(repr(ev) for ev in events) + "\n    ]"
    n = len(events)
    first_url = next((ev.get("url") for ev in events if ev.get("url")), None)
    first_url_repr = repr(first_url) if first_url else "None"
    return f'''"""AUTO-GENERATED by macro.compile. Edit freely or recompile.

Original recording label: {src_label!r}
Replay note: provide a session_id seeded with appropriate auth state.

Args:
  strict (bool):           assert misses raise instead of warn (default False)
  clean (bool):            run-clean cleaners on (default True)
  speed (str):             "fast"|"natural"|"cautious" (default "natural")
  csv_logger:              CsvRunLogger or None (default None)
  identity:                Identity dataclass or None (default None)
  step_delay_ms (int):     legacy fallback when clean=False (default 350)
  imap_email (str):        IMAP login for dynamic OTP/verify-URL fetch.
  imap_pass (str):         IMAP password.
  strict_after_clean (bool): fail if any cleaner fired (debug, default False)
"""
from __future__ import annotations
import asyncio
import os
from loguru import logger as log
from ..control.registry import task
from ..core.session import SessionRegistry
from ..core.macro_runner import MacroFlags, run_event, transform_events

META = {{"last_verified": "{today}"}}

EVENTS = {events_repr}


@task(name="macro_{name}", label="Recorded macro: {name}",
      session_spec={{"mode": "stealth"}}, auto_session=False,
      last_verified="{today}")
async def run_macro_{name}(session_id: str,
                           strict: bool = False,
                           clean: bool = True,
                           speed: str = "natural",
                           csv_logger=None,
                           identity=None,
                           step_delay_ms: int = 350,
                           imap_email: str | None = None,
                           imap_pass: str | None = None,
                           strict_after_clean: bool = False) -> dict:
    s = SessionRegistry.get().lookup(session_id)
    page = s.active_page()
    if page is None:
        raise RuntimeError("session has no active page")
    flags = MacroFlags(
        strict=strict, clean=clean, speed=speed,
        csv_logger=csv_logger, identity=identity,
        step_delay_ms=step_delay_ms,
        imap_email=imap_email or os.environ.get("MACRO_IMAP_EMAIL"),
        imap_pass=imap_pass or os.environ.get("MACRO_IMAP_PASS"),
        strict_after_clean=strict_after_clean,
    )
    # tag page with session_id so handlers (e.g. captcha) can recover it
    try:
        page._pymcp_session_id = session_id
    except Exception:
        pass

    # Initial nav to first event URL if not already there
    _initial_url = {first_url_repr}
    if _initial_url and page.url != _initial_url:
        try:
            await page.goto(_initial_url, wait_until="domcontentloaded")
        except Exception as e:
            log.warning("macro_{name}: initial nav failed: {{}}", e)
        await asyncio.sleep(0.4)

    events = list(EVENTS)
    if flags.clean:
        events, _xstats = transform_events(events, flags)
        if _xstats:
            log.info("macro_{name}: pre-dispatch transforms: {{}}", _xstats)

    fail = None
    for ev in events:
        try:
            stats = await run_event(page, ev, flags)
            if not stats.ok and flags.strict:
                fail = (ev, stats)
                break
        except Exception as e:
            if flags.strict:
                fail = (ev, str(e))
                break
            log.warning("macro_{name}: event {{}} failed (non-strict): {{}}",
                        ev.get('seq'), e)

    return {{"ok": fail is None, "steps": len(events),
            "fail": (fail[0] if fail else None)}}
'''


def compile_macro(jsonl_path: Path, name: str, force: bool = False,
                  tasks_dir: Path | None = None) -> Path:
    """Read JSONL -> write tasks/macro_<name>.py. Returns target path.

    Hot-imports the generated module so @task self-registers. Reload on
    recompile. Auto-sanitizes `name` (silently coerces "DuckDuckGo-PizzaExpress"
    → "duckduckgo_pizzaexpress") instead of raising invalid_name.
    """
    name = sanitize_macro_name(name)
    p = Path(jsonl_path)
    if not p.exists():
        raise ToolError("not_found", f"jsonl not found: {p}")
    header, events = _read_jsonl(p)
    if header and header.get("v") != SCHEMA_VERSION:
        raise ToolError("schema_mismatch",
                        f"jsonl v={header.get('v')} expected {SCHEMA_VERSION}")

    if tasks_dir is None:
        tasks_dir = Path(__file__).resolve().parent.parent / "tasks"
    tasks_dir.mkdir(parents=True, exist_ok=True)
    target = tasks_dir / f"macro_{name}.py"
    # HAND-EDITED guard — refuse to overwrite if marker found on first 3 lines
    if target.exists():
        try:
            head = target.read_text(encoding="utf-8").splitlines()[:3]
            if any("HAND-EDITED" in line for line in head):
                raise ToolError(
                    "hand_edited",
                    f"{target} carries # HAND-EDITED marker; refusing to overwrite. "
                    "Remove the marker or move the file before recompiling.")
        except ToolError:
            raise
        except Exception:
            pass
        if not force:
            raise ToolError("exists",
                            f"{target} exists; pass force=true to overwrite")
    target.write_text(_render_task(name, events, header), encoding="utf-8")

    # hot-reload so @task self-registers without server restart
    mod_name = f"pymcp_browser.v2.tasks.macro_{name}"
    try:
        import sys as _sys
        if mod_name in _sys.modules:
            importlib.reload(_sys.modules[mod_name])
        else:
            importlib.import_module(mod_name)
    except Exception as e:
        logger.warning("hot-reload of {} failed: {}", mod_name, e)
    return target
