"""Proxy egress probe + reactive fingerprint molding.

Two entry points:
- probe_via_context(context, page=None) -> egress blob {country, region, city,
  loc{lat,lon}, timezone, org, ip, source}. Goes through the browser's proxy
  because we use page.request (or context.request).
- apply_fingerprint(context, page, probe, *, set_geolocation=True) -> applied
  dict of overrides actually set via CDP / Playwright.

Probe sources tried in order: ipinfo.io (token if available), ip-api.com (free).
"""
from __future__ import annotations
from typing import Any
from .credentials import get_ipinfo_token
from .locale_map import hints_for_country


_HEADER_KEEP = {"accept-language", "user-agent"}


def _norm_ipinfo(blob: dict) -> dict:
    loc = blob.get("loc") or ""
    lat = lon = None
    if isinstance(loc, str) and "," in loc:
        try:
            la, lo = loc.split(",", 1)
            lat, lon = float(la), float(lo)
        except Exception:
            pass
    return {
        "ip": blob.get("ip"),
        "country": (blob.get("country") or "").upper() or None,
        "region": blob.get("region"),
        "city": blob.get("city"),
        "timezone": blob.get("timezone"),
        "org": blob.get("org"),
        "loc": {"latitude": lat, "longitude": lon} if lat is not None else None,
        "source": "ipinfo",
    }


def _norm_ipapi(blob: dict) -> dict:
    return {
        "ip": blob.get("query"),
        "country": (blob.get("countryCode") or "").upper() or None,
        "region": blob.get("regionName"),
        "city": blob.get("city"),
        "timezone": blob.get("timezone"),
        "org": blob.get("isp") or blob.get("org"),
        "loc": ({"latitude": blob.get("lat"), "longitude": blob.get("lon")}
                if blob.get("lat") is not None else None),
        "source": "ip-api",
    }


async def probe_via_httpx(proxy: dict, timeout_s: float = 8.0) -> dict:
    """Probe exit IP/geo through a Playwright-style proxy dict using httpx.

    Used pre-launch (before browser context exists) so locale/timezone can be
    baked into the context kwargs instead of patched via CDP afterwards.

    proxy dict shape: {"server": "http://host:port", "username": "...", "password": "..."}
    """
    import httpx
    server = proxy.get("server") or ""
    user = proxy.get("username") or ""
    pw = proxy.get("password") or ""
    if "://" in server:
        scheme, host_port = server.split("://", 1)
    else:
        scheme, host_port = "http", server
    if user:
        from urllib.parse import quote
        proxy_url = f"{scheme}://{quote(user, safe='')}:{quote(pw, safe='')}@{host_port}"
    else:
        proxy_url = f"{scheme}://{host_port}"
    token = get_ipinfo_token() or ""
    url1 = f"https://ipinfo.io/json{('?token=' + token) if token else ''}"
    # httpx >=0.28 dropped `proxies` kwarg in favour of `proxy=`. Try new first.
    try:
        client_kwargs = {"proxy": proxy_url, "timeout": timeout_s, "verify": False}
        async with httpx.AsyncClient(**client_kwargs) as client:
            r = await client.get(url1)
            if r.status_code == 200:
                try:
                    return _norm_ipinfo(r.json())
                except Exception:
                    pass
            r = await client.get(
                "http://ip-api.com/json/?fields=status,query,countryCode,"
                "regionName,city,timezone,isp,org,lat,lon")
            if r.status_code == 200:
                blob = r.json()
                if blob.get("status") == "success":
                    return _norm_ipapi(blob)
    except Exception as e:
        return {"error": f"probe_failed: {e}", "source": None}
    return {"error": "probe_failed", "source": None}


async def probe_via_context(context, page=None, timeout_ms: int = 8000) -> dict:
    """Probe exit IP/geo through the proxy attached to *context*.

    Uses page.request when page provided (fastest, reuses session), else
    context.request. Returns normalized blob with key 'source' or 'error'.
    """
    requester = page.request if page is not None else context.request
    token = get_ipinfo_token() or ""
    url1 = f"https://ipinfo.io/json{('?token=' + token) if token else ''}"
    try:
        r = await requester.get(url1, timeout=timeout_ms)
        if r.ok:
            try:
                return _norm_ipinfo(await r.json())
            except Exception:
                pass
    except Exception:
        pass
    # fallback: ip-api.com (free, no token, http only on free tier)
    try:
        r = await requester.get(
            "http://ip-api.com/json/?fields=status,query,countryCode,regionName,"
            "city,timezone,isp,org,lat,lon",
            timeout=timeout_ms)
        if r.ok:
            try:
                blob = await r.json()
                if blob.get("status") == "success":
                    return _norm_ipapi(blob)
            except Exception:
                pass
    except Exception:
        pass
    return {"error": "probe_failed", "source": None}


async def apply_fingerprint(context, page, probe: dict, *,
                            set_geolocation: bool = True,
                            set_locale: bool = True,
                            set_timezone: bool = True) -> dict:
    """Apply CDP-level locale/timezone overrides + geolocation to match probe.

    Returns dict of what was applied. Silently skips overrides that fail
    (CDP not supported on every page type). Caller decides what to log.
    """
    applied: dict[str, Any] = {}
    cc = (probe.get("country") or "").upper()
    hints = hints_for_country(cc)
    locale = hints["locale"]
    tz = probe.get("timezone") or hints["timezone"]
    loc = probe.get("loc") or {}

    if page is not None and (set_locale or set_timezone):
        try:
            client = await context.new_cdp_session(page)
            if set_locale:
                try:
                    await client.send("Emulation.setLocaleOverride",
                                      {"locale": locale})
                    applied["locale"] = locale
                except Exception:
                    pass
            if set_timezone and tz:
                try:
                    await client.send("Emulation.setTimezoneOverride",
                                      {"timezoneId": tz})
                    applied["timezone"] = tz
                except Exception:
                    pass
        except Exception:
            pass

    if set_geolocation and loc.get("latitude") is not None:
        try:
            await context.set_geolocation({
                "latitude": float(loc["latitude"]),
                "longitude": float(loc["longitude"]),
                "accuracy": 50,
            })
            applied["geolocation"] = {"latitude": loc["latitude"],
                                      "longitude": loc["longitude"]}
        except Exception:
            pass

    # Accept-Language header via init script (CDP setLocaleOverride doesn't
    # always sync navigator.languages on persistent contexts).
    langs = hints["languages"]
    try:
        js = ("(() => { try { Object.defineProperty(navigator, 'languages', "
              f"{{get: () => {langs!r}}}); }} catch (e) {{}} "
              "try { Object.defineProperty(navigator, 'language', "
              f"{{get: () => {langs[0]!r}}}); }} catch (e) {{}} }})();")
        await context.add_init_script(js)
        applied["languages"] = langs
    except Exception:
        pass

    applied["country"] = cc or None
    applied["country_matched_in_map"] = hints["matched"]
    return applied
