"""JS strings injected into browser context for macro recording.

RECORDER_JS  - runs in every frame; gated on window.__macroRecording__.
TOOLBAR_JS   - top frame only; visible UI for Start/Pause/Stop/Label/Wait/Assert/Save.

Both bridge to Python via expose_function bindings:
  __macroSink__({...event})                          - record event
  __macroCtl__({action, kind?, payload?})            - control / pick / toggle
"""
from __future__ import annotations

RECORDER_JS = r"""
(() => {
  if (window.__macroInstalled__) return;
  window.__macroInstalled__ = true;
  window.__macroRecording__ = window.__macroRecording__ || false;
  window.__macroPaused__ = window.__macroPaused__ || false;
  window.__macroPick__ = null;       // null | 'wait' | 'assert'
  window.__macroIsComposing__ = false;

  const REACT_AUTOID = /^:r[a-z0-9]+:$/;
  const EMBER_ID = /^ember\d+$/;

  function escAttr(v) { return String(v).replace(/"/g, '\\"'); }
  function isStableId(id) {
    if (!id) return false;
    if (REACT_AUTOID.test(id)) return false;
    if (EMBER_ID.test(id)) return false;
    return true;
  }

  function cssPath(el) {
    let cur = el, parts = [];
    while (cur && cur.nodeType === 1 && parts.length < 5) {
      let sel = cur.tagName.toLowerCase();
      if (cur.classList && cur.classList.length) {
        const stable = Array.from(cur.classList).filter(c => !/^[a-z]+-[a-z0-9]{5,}$/i.test(c)).slice(0,2);
        if (stable.length) sel += '.' + stable.map(CSS.escape).join('.');
      }
      const sib = cur.parentElement ? Array.from(cur.parentElement.children).filter(s => s.tagName === cur.tagName) : [];
      if (sib.length > 1) sel += ':nth-of-type(' + (sib.indexOf(cur) + 1) + ')';
      parts.unshift(sel);
      cur = cur.parentElement;
    }
    return parts.join(' > ');
  }

  function buildSelectors(el) {
    if (!el || el.nodeType !== 1) return {primary: null, alts: []};
    const cands = [];
    if (isStableId(el.id)) cands.push('#' + CSS.escape(el.id));
    const dtid = el.getAttribute('data-testid');
    if (dtid) cands.push('[data-testid="' + escAttr(dtid) + '"]');
    const dqa = el.getAttribute('data-qa');
    if (dqa) cands.push('[data-qa="' + escAttr(dqa) + '"]');
    const dtest = el.getAttribute('data-test');
    if (dtest) cands.push('[data-test="' + escAttr(dtest) + '"]');
    if (el.name) {
      const tag = el.tagName.toLowerCase();
      const t = el.type ? '[type="' + escAttr(el.type) + '"]' : '';
      cands.push(tag + '[name="' + escAttr(el.name) + '"]' + t);
    }
    const aria = el.getAttribute('aria-label');
    if (aria) cands.push('[aria-label="' + escAttr(aria) + '"]');
    const role = el.getAttribute('role');
    if (role && aria) cands.push('[role="' + role + '"][aria-label="' + escAttr(aria) + '"]');
    const txt = (el.innerText || el.textContent || '').trim();
    if (txt && txt.length <= 40 && /^[\S\s]{1,40}$/.test(txt)) {
      cands.push('text=' + JSON.stringify(txt));
    }
    cands.push(cssPath(el));
    const seen = new Set();
    const uniq = [];
    for (const c of cands) {
      if (c && !seen.has(c)) { seen.add(c); uniq.push(c); }
    }
    return {primary: uniq[0] || null, alts: uniq.slice(1, 3)};
  }

  function describe(el) {
    if (!el || el.nodeType !== 1) return {};
    return {
      tag: el.tagName ? el.tagName.toLowerCase() : null,
      type: el.type || null,
      name: el.name || null,
      id: el.id || null,
      role: el.getAttribute ? el.getAttribute('role') : null,
      innerText: (el.innerText || '').trim().slice(0, 200),
      textContent: (el.textContent || '').trim().slice(0, 200),
      value: el.value !== undefined ? String(el.value).slice(0, 200) : null,
      placeholder: el.placeholder || null,
      ariaLabel: el.getAttribute ? el.getAttribute('aria-label') : null,
    };
  }

  function inToolbar(e) {
    try {
      const path = e.composedPath ? e.composedPath() : [];
      return path.some(n => n === window.__macroToolbarHost__);
    } catch { return false; }
  }

  function send(type, target, extra) {
    try {
      if (!window.__macroRecording__) return;
      if (window.__macroPaused__) return;
      const sels = buildSelectors(target);
      const payload = {
        type, ts: Date.now() / 1000,
        url: location.href, frameUrl: location.href,
        selectors: sels,
        elem: describe(target),
        ...(extra || {}),
      };
      if (window.__macroNextDynamic__ && (type === 'input' || type === 'change')) {
        payload.dynamic = window.__macroNextDynamic__;
        window.__macroNextDynamic__ = null;
      }
      if (window.__macroSink__) window.__macroSink__(payload);
    } catch (e) {
      try {
        if (window.__macroSink__) window.__macroSink__({
          type: 'recorder_error', ts: Date.now() / 1000,
          url: location.href, message: String(e && e.message || e),
          stack: String(e && e.stack || '')
        });
      } catch {}
    }
  }

  document.addEventListener('click', e => {
    if (inToolbar(e)) return;
    if (window.__macroPick__) {
      const kind = window.__macroPick__;
      const sels = buildSelectors(e.target);
      e.preventDefault(); e.stopPropagation();
      window.__macroPick__ = null;
      try {
        if (window.__macroCtl__) window.__macroCtl__({
          action: 'pick', kind: kind,
          payload: {selectors: sels, elem: describe(e.target),
                    url: location.href, frameUrl: location.href}
        });
      } catch {}
      return;
    }
    send('click', e.target, {
      x: e.clientX, y: e.clientY, button: e.button,
      modifiers: {alt: e.altKey, ctrl: e.ctrlKey, shift: e.shiftKey, meta: e.metaKey}
    });
  }, true);

  document.addEventListener('compositionstart', () => { window.__macroIsComposing__ = true; }, true);
  document.addEventListener('compositionend', e => {
    window.__macroIsComposing__ = false;
    send('input', e.target, {value: e.target ? e.target.value : ''});
  }, true);

  document.addEventListener('input', e => {
    if (inToolbar(e)) return;
    if (window.__macroIsComposing__) return;
    send('input', e.target, {value: e.target.value});
  }, true);

  document.addEventListener('change', e => {
    if (inToolbar(e)) return;
    const t = e.target;
    if (t && (t.type === 'checkbox' || t.type === 'radio')) {
      send('check', t, {checked: t.checked, value: t.value});
    } else if (t && t.tagName === 'SELECT') {
      send('change', t, {value: t.value});
    }
  }, true);

  document.addEventListener('keydown', e => {
    if (inToolbar(e)) return;
    if (e.ctrlKey && e.shiftKey && (e.key === 'R' || e.key === 'r')) {
      try { if (window.__macroCtl__) window.__macroCtl__({action: 'toggle'}); } catch {}
      e.preventDefault(); e.stopPropagation();
      return;
    }
    if (e.key === 'Escape' && window.__macroPick__) {
      window.__macroPick__ = null;
      try { if (window.__macroCtl__) window.__macroCtl__({action: 'pick_cancel'}); } catch {}
      return;
    }
    if (['Enter','Escape','Tab','ArrowUp','ArrowDown','ArrowLeft','ArrowRight'].includes(e.key) ||
        e.ctrlKey || e.metaKey) {
      const submitsForm = e.key === 'Enter' && e.target && e.target.form;
      send('key', e.target, {
        key: e.key,
        submitsForm: !!submitsForm,
        modifiers: {alt: e.altKey, ctrl: e.ctrlKey, shift: e.shiftKey, meta: e.metaKey}
      });
    }
  }, true);
})();
"""


TOOLBAR_JS = r"""
(() => {
  if (window !== window.top) return;

  const FONT = '12px -apple-system,Segoe UI,sans-serif';
  const SVG_NS = 'http://www.w3.org/2000/svg';

  // Lucide icon paths (24x24 viewBox).
  const ICONS = {
    grip:     '<circle cx="9" cy="12" r="1"/><circle cx="9" cy="5" r="1"/><circle cx="9" cy="19" r="1"/><circle cx="15" cy="12" r="1"/><circle cx="15" cy="5" r="1"/><circle cx="15" cy="19" r="1"/>',
    rec:      '<circle cx="12" cy="12" r="10"/><circle cx="12" cy="12" r="3" fill="currentColor"/>',
    pause:    '<rect x="14" y="4" width="4" height="16" rx="1"/><rect x="6" y="4" width="4" height="16" rx="1"/>',
    play:     '<polygon points="6 3 20 12 6 21 6 3"/>',
    stop:     '<rect width="14" height="14" x="5" y="5" rx="2"/>',
    tag:      '<path d="M12.586 2.586A2 2 0 0 0 11.172 2H4a2 2 0 0 0-2 2v7.172a2 2 0 0 0 .586 1.414l8.704 8.704a2.426 2.426 0 0 0 3.42 0l6.58-6.58a2.426 2.426 0 0 0 0-3.42z"/><circle cx="7.5" cy="7.5" r=".5" fill="currentColor"/>',
    hourglass:'<path d="M5 22h14"/><path d="M5 2h14"/><path d="M17 22v-4.172a2 2 0 0 0-.586-1.414L12 12l-4.414 4.414A2 2 0 0 0 7 17.828V22"/><path d="M7 2v4.172a2 2 0 0 0 .586 1.414L12 12l4.414-4.414A2 2 0 0 0 17 6.172V2"/>',
    check:    '<path d="M18 6 7 17l-5-5"/><path d="m22 10-7.5 7.5L13 16"/>',
    key:      '<path d="M2.586 17.414A2 2 0 0 0 2 18.828V21a1 1 0 0 0 1 1h3a1 1 0 0 0 1-1v-1a1 1 0 0 1 1-1h1a1 1 0 0 0 1-1v-1a1 1 0 0 1 1-1h.172a2 2 0 0 0 1.414-.586l.814-.814a6.5 6.5 0 1 0-4-4z"/><circle cx="16.5" cy="7.5" r=".5" fill="currentColor"/>',
    mail:     '<path d="M22 13V6a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2v12c0 1.1.9 2 2 2h8"/><path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7"/><path d="m16 19 2 2 4-4"/>',
    shield:   '<path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z"/><path d="m9 12 2 2 4-4"/>',
  };

  function mkIcon(name, sz) {
    sz = sz || 14;
    const inner = ICONS[name] || '';
    const str = '<svg xmlns="' + SVG_NS + '" width="' + sz + '" height="' + sz
      + '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"'
      + ' stroke-linecap="round" stroke-linejoin="round" style="vertical-align:middle;flex-shrink:0">'
      + inner + '</svg>';
    try {
      const doc = new DOMParser().parseFromString(str, 'image/svg+xml');
      return doc.documentElement;
    } catch (e) { return document.createTextNode(''); }
  }

  function mkBtn(root, id, iconName, title, label) {
    const b = document.createElement('button');
    b.id = id; if (title) b.title = title;
    const padX = label ? 9 : 6;
    b.style.cssText = 'all:unset;background:#2d2d33;color:#eee;border:1px solid #555;'
      + 'border-radius:4px;padding:4px ' + padX + 'px;font:' + FONT + ';cursor:pointer;'
      + 'display:inline-flex;align-items:center;gap:5px;line-height:1.2;'
      + 'min-width:' + (label ? 'auto' : '22px') + ';text-align:center;'
      + 'box-sizing:border-box;';
    b.appendChild(mkIcon(iconName));
    if (label) {
      const sp = document.createElement('span');
      sp.textContent = label;
      b.appendChild(sp);
    }
    b.addEventListener('mouseenter', () => b.style.background = '#3a3a42');
    b.addEventListener('mouseleave', () => b.style.background = b._bg || '#2d2d33');
    b.addEventListener('mousedown', e => e.preventDefault());  // don't steal focus
    root.appendChild(b);
    return b;
  }

  function mkPill(root, id) {
    const s = document.createElement('span');
    s.id = id; s.textContent = 'idle';
    s.style.cssText = 'padding:3px 9px;border-radius:11px;background:#444;font:'
      + FONT + ';color:#eee;display:inline-block;line-height:1.3;';
    root.appendChild(s);
    return s;
  }

  function mkInput(root, ph) {
    const i = document.createElement('input');
    i.placeholder = ph;
    i.style.cssText = 'all:unset;background:#0e0e10;color:#eee;border:1px solid #555;'
      + 'border-radius:4px;padding:4px 7px;font:' + FONT + ';width:90px;';
    root.appendChild(i);
    return i;
  }

  // ---------- mount with self-heal -----------------------------------------

  let host = null, root = null, observer = null, healInterval = null;

  function isMounted() {
    return host && document.documentElement && document.documentElement.contains(host);
  }

  function mount() {
    if (!document.body) { setTimeout(mount, 50); return; }
    if (isMounted()) return;  // already up
    try {
      host = document.createElement('div');
      host.id = '__macro_toolbar_host__';
      host.style.cssText = 'all:initial;position:fixed!important;top:8px!important;'
        + 'left:auto!important;right:8px!important;z-index:2147483647!important;'
        + 'display:block!important;pointer-events:auto!important;';
      document.documentElement.appendChild(host);
      window.__macroToolbarHost__ = host;
      root = host.attachShadow({mode: 'open'});
    } catch (e) {
      console.error('[macro] toolbar host create failed', e);
      return;
    }

    const bar = document.createElement('div');
    bar.style.cssText = 'display:flex;gap:4px;padding:6px 8px;background:#1f1f23;'
      + 'color:#eee;border:1px solid #444;border-radius:7px;'
      + 'box-shadow:0 4px 14px rgba(0,0,0,.25);align-items:center;white-space:nowrap;'
      + 'font:' + FONT + ';user-select:none;';
    root.appendChild(bar);

    // drag grip with Lucide icon
    const grip = document.createElement('span');
    grip.title = 'Drag to move';
    grip.style.cssText = 'cursor:grab;color:#888;padding:0 2px;display:inline-flex;'
      + 'align-items:center;';
    grip.appendChild(mkIcon('grip', 16));
    bar.appendChild(grip);

    const lblInput = mkInput(bar, 'label');
    const bStart = mkBtn(bar, 'b_start',  'rec',      'Start recording', 'Rec');
    bStart.style.background = '#c0392b';
    bStart.style.borderColor = '#c0392b';
    bStart.style.color = '#fff';
    bStart._bg = '#c0392b';
    const bPause = mkBtn(bar, 'b_pause',  'pause',    'Pause/Resume (Ctrl+Shift+R)');
    const bStop  = mkBtn(bar, 'b_stop',   'stop',     'Stop recording');
    const bLabel = mkBtn(bar, 'b_label',  'tag',      'Label next event');
    const bWait  = mkBtn(bar, 'b_wait',   'hourglass','Insert wait: click target');
    const bAssrt = mkBtn(bar, 'b_assert', 'check',    'Insert assert: click target');
    const bOtp   = mkBtn(bar, 'b_otp',    'key',      'Fetch OTP + fill focused input', 'OTP');
    const bVer   = mkBtn(bar, 'b_verify', 'mail',     'Fetch verify URL + navigate', 'Verify');
    const bCap   = mkBtn(bar, 'b_captcha','shield',   'Detect + solve captcha on page', 'Captcha');
    bCap.style.background = '#2d4d2d';
    bCap.style.borderColor = '#3c6b3c';
    bCap._bg = '#2d4d2d';
    const status = mkPill(bar, 'status');

    function setStatus(s, count) {
      const c = (count != null) ? ' ' + count : '';
      status.textContent = s + c;
      status.style.background = s === 'recording' ? '#c0392b'
                              : s === 'paused'    ? '#d39e00'
                              : s && s.startsWith('pick:') ? '#2563eb'
                              : s && s.startsWith('OTP ') || s && s.startsWith('Captcha ✓') ? '#1f8844'
                              : '#444';
      window.__macroRecording__ = (s === 'recording');
      window.__macroPaused__    = (s === 'paused');
    }

    async function ctl(action, extra) {
      try {
        if (!window.__macroCtl__) { console.warn('[macro] no __macroCtl__'); return null; }
        const r = await window.__macroCtl__({action, ...(extra || {})});
        if (r && r.status) setStatus(r.status, r.count);
        return r;
      } catch (e) { console.warn('[macro] ctl err', e); return null; }
    }

    bStart.onclick = async () => {
      const label = (lblInput.value || '').trim() || null;
      await ctl('start', {payload: {label}});
    };
    bPause.onclick = () => ctl('toggle');
    bStop.onclick  = () => ctl('stop');
    bLabel.onclick = async () => {
      const label = (lblInput.value || '').trim();
      if (label) { await ctl('annotate', {payload: {label}}); lblInput.value = ''; }
    };
    bWait.onclick  = () => { window.__macroPick__ = 'wait';   setStatus('pick:wait'); };
    bAssrt.onclick = () => { window.__macroPick__ = 'assert'; setStatus('pick:assert'); };

    function nativeSet(el, value) {
      try {
        const proto = el.tagName === 'TEXTAREA'
          ? window.HTMLTextAreaElement.prototype
          : window.HTMLInputElement.prototype;
        const setter = Object.getOwnPropertyDescriptor(proto, 'value').set;
        setter.call(el, value);
      } catch { el.value = value; }
    }

    bOtp.onclick = async () => {
      if (!window.__macroFetchOtp__) { setStatus('OTP: no creds'); return; }
      setStatus('OTP: fetching');
      let code = null;
      try { code = await window.__macroFetchOtp__(); } catch (e) { console.warn(e); }
      if (!code) { setStatus('OTP: not found'); return; }
      const el = window.__macroLastFocused__ || document.activeElement;
      const isInput = el && (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA');
      if (isInput) {
        window.__macroNextDynamic__ = 'otp';
        el.focus();
        nativeSet(el, '');
        el.dispatchEvent(new Event('input', {bubbles: true}));
        nativeSet(el, code);
        el.dispatchEvent(new InputEvent('input', {bubbles: true, data: code, inputType: 'insertText'}));
        el.dispatchEvent(new Event('change', {bubbles: true}));
        setStatus('OTP ' + code);
      } else {
        try { await navigator.clipboard.writeText(code); } catch {}
        setStatus('OTP ' + code + ' (clip)');
      }
    };

    bVer.onclick = async () => {
      if (!window.__macroFetchVerifyUrl__) { setStatus('Verify: no creds'); return; }
      setStatus('Verify: fetching');
      let url = null;
      try { url = await window.__macroFetchVerifyUrl__(); } catch (e) { console.warn(e); }
      if (!url) { setStatus('Verify: none'); return; }
      try { if (window.__macroCtl__) await window.__macroCtl__({action: 'mark_dynamic', kind: 'verify_url'}); } catch {}
      setStatus('Verify -> ' + url.slice(0, 40));
      window.location.href = url;
    };

    bCap.onclick = async () => {
      if (!window.__macroSolveCaptcha__) { setStatus('Captcha: no binding'); return; }
      // 1) detect
      let detected = null;
      try {
        if (window.__macroDetectCaptcha__) {
          detected = await window.__macroDetectCaptcha__();
        }
      } catch (e) { console.warn(e); }
      const kind = detected && detected.kind;
      if (!kind) { setStatus('Captcha: none detected'); return; }
      setStatus('Captcha ' + kind + '...');
      // 2) solve
      let res = null;
      try { res = await window.__macroSolveCaptcha__(kind); } catch (e) { console.warn(e); }
      const ok = res && res.ok;
      // 3) record step into JSONL so replay re-solves
      try {
        if (window.__macroCtl__) {
          await window.__macroCtl__({
            action: 'record_captcha',
            payload: {kind: kind, ok: !!ok,
                      sitekey: detected.sitekey, invisible: detected.invisible}
          });
        }
      } catch {}
      setStatus(ok ? ('Captcha ✓ ' + kind) : ('Captcha ✗ ' + (res && res.error || kind)));
    };

    // track last input/textarea focus so toolbar buttons can fill it after click
    document.addEventListener('focusin', (e) => {
      const t = e.target;
      if (t && (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA')) {
        window.__macroLastFocused__ = t;
      }
    }, true);

    // drag logic — clamps host within viewport
    let dragging = false, dx = 0, dy = 0;
    function clamp(x, y) {
      const r = host.getBoundingClientRect();
      const vw = window.innerWidth, vh = window.innerHeight;
      const w = r.width || 200, h = r.height || 32;
      return [Math.max(0, Math.min(x, vw - w)), Math.max(0, Math.min(y, vh - h))];
    }
    grip.addEventListener('pointerdown', (e) => {
      dragging = true;
      grip.style.cursor = 'grabbing';
      const r = host.getBoundingClientRect();
      dx = e.clientX - r.left;
      dy = e.clientY - r.top;
      host.style.right = 'auto';
      host.style.left = r.left + 'px';
      host.style.top = r.top + 'px';
      try { grip.setPointerCapture(e.pointerId); } catch {}
      e.preventDefault();
    });
    grip.addEventListener('pointermove', (e) => {
      if (!dragging) return;
      const [cx, cy] = clamp(e.clientX - dx, e.clientY - dy);
      host.style.left = cx + 'px';
      host.style.top  = cy + 'px';
    });
    function endDrag(e) {
      if (!dragging) return;
      dragging = false;
      grip.style.cursor = 'grab';
      try { grip.releasePointerCapture(e.pointerId); } catch {}
    }
    grip.addEventListener('pointerup', endDrag);
    grip.addEventListener('pointercancel', endDrag);

    window.addEventListener('resize', () => {
      if (host && host.style.left && host.style.left !== 'auto') {
        const x = parseFloat(host.style.left) || 0;
        const y = parseFloat(host.style.top) || 0;
        const [cx, cy] = clamp(x, y);
        host.style.left = cx + 'px';
        host.style.top = cy + 'px';
      }
    });

    setInterval(async () => {
      try {
        if (!window.__macroCtl__) return;
        const r = await window.__macroCtl__({action: 'status'});
        if (r && r.status) setStatus(r.status, r.count);
      } catch {}
    }, 1500);

    console.log('[macro] toolbar mounted');
  }

  // ---------- self-heal (SPA / DOM rewrites) -------------------------------
  function startHeal() {
    // re-mount when host removed
    if (observer) observer.disconnect();
    try {
      observer = new MutationObserver(() => {
        if (!isMounted()) {
          host = null; root = null;
          mount();
        }
      });
      observer.observe(document.documentElement, {childList: true, subtree: false});
    } catch {}
    // safety net: also poll every 2s
    if (healInterval) clearInterval(healInterval);
    healInterval = setInterval(() => {
      if (!isMounted()) {
        host = null; root = null;
        mount();
      }
    }, 2000);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => { mount(); startHeal(); }, {once: true});
  } else {
    mount();
    startHeal();
  }
})();
"""
