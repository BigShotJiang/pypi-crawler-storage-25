"""Macro event dispatcher (Phase 1 of macro-toggles plan).

Compiled macros (output of `compile_macro`) call `run_event(page, event, flags)`
once per recorded event. This module owns:

- `MacroFlags` — runtime knobs (strict, clean, speed, csv_logger, identity, ...).
- `run_event(page, event, flags)` — per-event dispatcher. Returns stats dict for CSV.
- Cleaner pipeline (added in steps 5–7): pre-dispatch transforms + runtime hooks
  (waits, fallbacks, human mouse/type/pause).

This replaces the inlined-per-event statements that the old template emitted.
Single dispatch point makes Run Clean / Speed / CSV-Logging tractable.
"""
from __future__ import annotations
import asyncio
import time
from dataclasses import dataclass, field
from typing import Any, Callable, Awaitable

from loguru import logger as _log

from .macro import try_selectors
from .macro_mail import fetch_otp as _fetch_otp_sync
from .macro_mail import fetch_verify_url as _fetch_verify_url_sync
from . import human as _human


# ====================================================================
# Pre-dispatch event-list transforms (Run Clean step 1: cleanup)
# Operate on the entire recorded event list BEFORE any dispatch begins.
# Returns transformed list + counts of what was removed.
# ====================================================================

INPUT_DEDUP_WINDOW_S = 0.5     # collapse same-selector inputs within this gap
CLICK_DEDUP_WINDOW_S = 0.8     # drop same-selector double-click within this gap


def _selector_id(event: dict) -> str:
    """Stable identity for an event's target selector (for dedup keys)."""
    sels = event.get("selectors") or {}
    return sels.get("primary") or sels.get("text") or ""


def dedupe_inputs(events: list[dict]) -> tuple[list[dict], int]:
    """Collapse consecutive `input` events on same selector within 500ms.

    Keeps the LAST value (matches user's final intent). Returns (cleaned, removed_count).
    """
    out: list[dict] = []
    removed = 0
    for ev in events:
        if ev.get("type") == "input" and out:
            prev = out[-1]
            if (prev.get("type") == "input"
                    and _selector_id(prev) == _selector_id(ev)
                    and _selector_id(ev)
                    and (ev.get("ts", 0) - prev.get("ts", 0)) <= INPUT_DEDUP_WINDOW_S):
                # collapse: keep current (last) value, drop previous
                out[-1] = ev
                removed += 1
                continue
        out.append(ev)
    return out, removed


def dedupe_clicks(events: list[dict]) -> tuple[list[dict], int]:
    """Drop second `click` on same selector within 800ms (double-fire protection)."""
    out: list[dict] = []
    removed = 0
    for ev in events:
        if ev.get("type") == "click" and out:
            prev = out[-1]
            if (prev.get("type") == "click"
                    and _selector_id(prev) == _selector_id(ev)
                    and _selector_id(ev)
                    and (ev.get("ts", 0) - prev.get("ts", 0)) <= CLICK_DEDUP_WINDOW_S):
                removed += 1
                continue
        out.append(ev)
    return out, removed


def transform_events(events: list[dict],
                     flags: MacroFlags | None = None) -> tuple[list[dict], dict]:
    """Apply all pre-dispatch transforms when clean mode is on.

    Returns (cleaned_events, stats) where stats = {dedupe_inputs: N, dedupe_clicks: N}.
    """
    if flags is not None and not flags.clean:
        return events, {}
    out, n_inputs = dedupe_inputs(events)
    out, n_clicks = dedupe_clicks(out)
    stats = {}
    if n_inputs:
        stats["dedupe_inputs"] = n_inputs
    if n_clicks:
        stats["dedupe_clicks"] = n_clicks
    return out, stats


@dataclass
class MacroFlags:
    """Runtime flags passed through compiled macro to every event dispatch."""
    strict: bool = False
    clean: bool = True
    speed: str = "natural"           # "fast" | "natural" | "cautious"
    strict_after_clean: bool = False  # Phase 3 — fail if any cleaner fired
    step_delay_ms: int = 350         # legacy fallback when clean=False
    imap_email: str | None = None
    imap_pass: str | None = None
    csv_logger: Any = None           # CsvRunLogger or _NullLogger (Phase 1.5)
    identity: Any = None             # Identity dataclass (Phase 2)

    # Internal state shared across events of one run.
    _last_event_ts: float = 0.0
    _last_event_type: str = ""
    _last_click_ts: float = 0.0
    _last_keystroke_ts: float = 0.0

    def speed_profile(self) -> dict[str, Any]:
        return _human.get_speed_profile(self.speed)


@dataclass
class EventStats:
    """Returned by run_event. Fed into CSV row builder."""
    ok: bool = True
    duration_ms: int = 0
    error_class: str = ""
    error_msg: str = ""
    clean_actions: list[str] = field(default_factory=list)
    retry_count: int = 0
    mouse_path_len: int = 0
    key_chars_typed: int = 0
    key_corrections: int = 0
    interevent_pause_ms: int = 0
    http_status: int = 0


# ----- Public entry point ----------------------------------------------------

async def run_event(page, event: dict, flags: MacroFlags) -> EventStats:
    """Dispatch a single recorded event. Honours flags.clean / flags.speed.

    Returns EventStats — CSV logger consumes it.
    """
    started = time.time()
    interevent_ms = 0
    if flags._last_event_ts:
        interevent_ms = int((started - flags._last_event_ts) * 1000)

    et = event.get("type") or ""
    handler = _HANDLERS.get(et)
    stats = EventStats(interevent_pause_ms=interevent_ms)

    if handler is None:
        stats.ok = True
        stats.clean_actions.append(f"skipped_unknown_type:{et}")
        _log.warning("macro_runner: skipped unknown event type {!r}", et)
        return _finalize(stats, started, flags, et)

    # ----- Pre-event cleaners (clean mode only) -----
    if flags.clean:
        # human_pause: log-normal interevent delay (Phase 1 step 7 plumbing)
        if flags._last_event_ts > 0:
            await _human_pause(flags, et, stats)
        # nav_complete_wait: previous event was nav → ensure DOM is stable
        if flags._last_event_type == "nav" and et != "nav":
            await _nav_complete_wait(page, flags, stats)
        # wait_stable + dismiss_overlays for interactive events
        if et in ("click", "input", "change", "check", "key"):
            await _wait_stable(page, flags, stats, probe=True)
            await _dismiss_overlays(page, stats)

    # ----- Main dispatch with retry_transient + selector_fallback -----
    last_err: Exception | None = None
    max_attempts = 3 if flags.clean else 1
    for attempt in range(max_attempts):
        try:
            await handler(page, event, flags, stats)
            stats.retry_count = attempt
            last_err = None
            break
        except Exception as e:
            last_err = e
            if not _is_transient(e) or attempt == max_attempts - 1:
                break
            stats.clean_actions.append(f"retry_transient:{type(e).__name__}")
            await asyncio.sleep(1.5)

    if last_err is not None:
        stats.ok = False
        stats.error_class = type(last_err).__name__
        stats.error_msg = str(last_err)[:200]
        if flags.strict:
            # log before raising so error row reaches CSV
            _csv_log_event(flags, page, event, stats)
            raise last_err

    _csv_log_event(flags, page, event, stats)
    return _finalize(stats, started, flags, et)


def _csv_log_event(flags: MacroFlags, page, event: dict,
                   stats: EventStats) -> None:
    """Bridge: feed an event's stats into the CSV logger if attached."""
    logger = flags.csv_logger
    if logger is None:
        return
    sels = event.get("selectors") or {}
    primary = sels.get("primary") or sels.get("text") or ""
    value = event.get("value", "")
    if not isinstance(value, str):
        value = str(value)
    page_url = ""
    try:
        page_url = page.url if page else ""
    except Exception:
        pass
    proxy_egress = ""
    actual_country = ""
    sess = getattr(page, "_pymcp_session", None)
    if sess is not None:
        proxy_egress = getattr(sess, "proxy_egress_ip", "") or ""
    if flags.identity is not None:
        actual_country = getattr(flags.identity, "_actual_country", "") or ""
    try:
        logger.log_event(
            event.get("type", "?"),
            event_seq=int(event.get("seq", 0) or 0),
            selector=primary,
            value=value,
            phase="error" if not stats.ok else "apply",
            duration_ms=stats.duration_ms,
            ok=stats.ok,
            error_class=stats.error_class,
            error_msg=stats.error_msg,
            clean_actions=list(stats.clean_actions),
            retry_count=stats.retry_count,
            mouse_path_len=stats.mouse_path_len,
            key_chars_typed=stats.key_chars_typed,
            key_corrections=stats.key_corrections,
            interevent_pause_ms=stats.interevent_pause_ms,
            page_url=page_url,
            http_status=stats.http_status,
            proxy_egress_ip=proxy_egress,
            actual_country=actual_country,
        )
    except Exception:
        # never let CSV failure break the macro run
        pass


# ----- Runtime cleaner helpers ---------------------------------------------

_TRANSIENT_NAMES = {"TimeoutError", "PlaywrightTimeoutError", "Error",
                    "PlaywrightError"}
_TRANSIENT_KEYWORDS = ("not visible", "not attached", "stale element",
                       "element is not", "exceeded", "did not match")


def _is_transient(err: Exception) -> bool:
    name = type(err).__name__
    if name in _TRANSIENT_NAMES:
        return True
    msg = str(err).lower()
    return any(k in msg for k in _TRANSIENT_KEYWORDS)


async def _wait_stable(page, flags: MacroFlags, stats: EventStats,
                       probe: bool = False) -> None:
    """Wait until DOM has been mutation-quiet for ~500ms."""
    timeout_ms = 5000 if probe else 8000
    js = """async ({quietMs, timeoutMs}) => {
        return await new Promise(resolve => {
            let last = Date.now();
            const obs = new MutationObserver(() => { last = Date.now(); });
            obs.observe(document.documentElement,
                {childList: true, subtree: true, attributes: true,
                 characterData: true});
            const start = Date.now();
            const tick = () => {
                if (Date.now() - last >= quietMs) { obs.disconnect(); resolve(true); }
                else if (Date.now() - start >= timeoutMs) { obs.disconnect(); resolve(false); }
                else { setTimeout(tick, 80); }
            };
            tick();
        });
    }"""
    try:
        ok = await page.evaluate(js, {"quietMs": 500, "timeoutMs": timeout_ms})
        if ok:
            stats.clean_actions.append("wait_stable")
    except Exception:
        pass


async def _nav_complete_wait(page, flags: MacroFlags,
                             stats: EventStats) -> None:
    """After a nav event, ensure the next interaction sees a stable DOM."""
    try:
        await page.wait_for_load_state("domcontentloaded", timeout=8000)
        await _wait_stable(page, flags, stats, probe=True)
        stats.clean_actions.append("nav_complete_wait")
    except Exception:
        pass


# Phase 3 — dismiss_overlays cleaner. Closes cookie/CMP banners before any
# user-visible interaction so they don't intercept clicks. Idempotent — caches
# a flag on the page object after the first successful dismissal of THAT URL.

_OVERLAY_SELECTORS: list[tuple[str, str]] = [
    # (provider, selector)  — tried in order, first hit wins
    ("OneTrust", "#onetrust-accept-btn-handler"),
    ("OneTrust", "#accept-recommended-btn-handler"),
    ("Cookiebot", "#CybotCookiebotDialogBodyLevelButtonAccept"),
    ("Cookiebot", "#CybotCookiebotDialogBodyButtonAccept"),
    ("Cookiebot", "#CybotCookiebotDialogBodyLevelButtonAcceptAll"),
    ("Quantcast", ".qc-cmp2-summary-buttons button:last-child"),
    ("Quantcast", "[data-cmp-action='accept']"),
    ("TrustArc",  "#truste-consent-button"),
    ("Didomi",    "#didomi-notice-agree-button"),
    ("Sourcepoint", "[title='Accept All']"),
    ("Generic",   "button:has-text('Accept all')"),
    ("Generic",   "button:has-text('Accept All')"),
    ("Generic",   "button:has-text('Accept Cookies')"),
    ("Generic",   "button:has-text('Agree')"),
    ("Generic",   "button:has-text('I agree')"),
    ("Generic",   "button:has-text('Allow all')"),
    ("Generic",   "button:has-text('Got it')"),
    ("Generic",   "button:has-text('Aceitar')"),       # PT
    ("Generic",   "button:has-text('Akzeptieren')"),  # DE
    ("Generic",   "button:has-text('Accepter')"),     # FR
    ("Generic",   "button:has-text('Aceptar')"),      # ES
]


async def _dismiss_overlays(page, stats: EventStats) -> None:
    """Best-effort close any visible cookie/CMP banner. Idempotent per URL."""
    if page is None:
        return
    cur_url = ""
    try:
        cur_url = page.url or ""
    except Exception:
        return
    cache = getattr(page, "_pymcp_overlay_cache", None)
    if cache is None:
        cache = {}
        try:
            page._pymcp_overlay_cache = cache
        except Exception:
            return
    if cache.get(cur_url):
        return  # already dismissed on this URL

    for provider, sel in _OVERLAY_SELECTORS:
        try:
            loc = page.locator(sel).first
            if await loc.count() == 0:
                continue
            try:
                if not await loc.is_visible():
                    continue
            except Exception:
                continue
            await loc.click(timeout=1500)
            cache[cur_url] = provider
            stats.clean_actions.append(f"dismiss_overlays:{provider}")
            await asyncio.sleep(0.4)  # let banner fade
            return
        except Exception:
            continue


async def _wait_visible(page, selector: str, stats: EventStats,
                        timeout_ms: int = 8000) -> bool:
    """Wait for selector to become visible. Logs cleaner action on success."""
    try:
        await page.wait_for_selector(selector, state="visible",
                                     timeout=timeout_ms)
        stats.clean_actions.append("wait_visible")
        return True
    except Exception:
        return False


async def _resolve_target(page, sels: dict, stats: EventStats,
                          timeout_ms: int = 5000):
    """Resolve a selector with primary→alts fallback chain."""
    primary = sels.get("primary") or ""
    if primary:
        try:
            loc = page.locator(primary)
            if await loc.count() > 0:
                return loc.first
        except Exception:
            pass
    # try alts (recorder emits selectors.alts as list)
    alts = sels.get("alts") or sels.get("fallbacks") or []
    if isinstance(alts, str):
        alts = [alts]
    for alt in alts:
        try:
            loc = page.locator(alt)
            if await loc.count() > 0:
                stats.clean_actions.append(f"selector_fallback:{alt[:40]}")
                return loc.first
        except Exception:
            continue
    # fallback: use existing try_selectors (handles role/text matchers)
    return await try_selectors(page, sels, timeout_ms=timeout_ms)


async def _human_pause(flags: MacroFlags, et: str,
                       stats: EventStats) -> None:
    """Sleep an interevent delay sampled from speed profile.

    Honours min thresholds: click-after-click ≥250ms, submit-after-key ≥600ms.
    """
    profile = flags.speed_profile()
    median = profile["interevent_median_ms"]
    sigma = profile["interevent_sigma"]
    delay_s = _human.lognormal_pause_s(median, sigma=sigma,
                                        min_ms=80, max_ms=8000)
    # enforce minimum gaps for specific event-pair patterns
    now = time.time()
    if et == "click" and flags._last_click_ts > 0:
        gap_ms = (now - flags._last_click_ts) * 1000
        needed = profile["click_min_gap_ms"]
        if gap_ms < needed:
            delay_s = max(delay_s, (needed - gap_ms) / 1000.0)
    if et == "key" and flags._last_keystroke_ts > 0:
        # form-submit triggered by Enter — bigger gap
        needed = profile["submit_min_gap_ms"]
        gap_ms = (now - flags._last_keystroke_ts) * 1000
        if gap_ms < needed:
            delay_s = max(delay_s, (needed - gap_ms) / 1000.0)
    await asyncio.sleep(delay_s)
    stats.interevent_pause_ms = int(delay_s * 1000)
    stats.clean_actions.append("human_pause")


def _finalize(stats: EventStats, started: float, flags: MacroFlags,
              et: str) -> EventStats:
    stats.duration_ms = int((time.time() - started) * 1000)
    flags._last_event_ts = time.time()
    flags._last_event_type = et
    if et == "click":
        flags._last_click_ts = flags._last_event_ts
    elif et in ("input", "key", "change"):
        flags._last_keystroke_ts = flags._last_event_ts
    if flags.strict_after_clean and stats.clean_actions:
        raise RuntimeError(
            f"strict_after_clean: cleaners fired on {et}: {stats.clean_actions}")
    return stats


# ----- Per-type handlers (raw dispatch — cleaners added in step 5–7) --------

Handler = Callable[[Any, dict, MacroFlags, EventStats], Awaitable[None]]


async def _h_click(page, event: dict, flags: MacroFlags,
                   stats: EventStats) -> None:
    sels = event.get("selectors") or {}
    if flags.clean:
        # Resolve target (with selector_fallback chain) then human_click via
        # Bezier mouse path + mousedown/mouseup with realistic gap.
        loc = await _resolve_target(page, sels, stats)
        primary = sels.get("primary") or ""
        if primary:
            res = await _human.human_click(page, primary, flags.speed_profile())
            stats.mouse_path_len = res.get("mouse_path_len", 0)
            stats.clean_actions.append("human_mouse")
            if not res.get("ok"):
                # human_click missed (target moved/obscured) — fall back to
                # Playwright .click() on the resolved locator.
                stats.clean_actions.append("human_mouse_fallback_locator_click")
                await loc.click()
        else:
            await loc.click()
    else:
        loc = await try_selectors(page, sels, timeout_ms=5000)
        await loc.click()
        await asyncio.sleep(max(0, flags.step_delay_ms) / 1000.0)


async def _h_input(page, event: dict, flags: MacroFlags,
                   stats: EventStats) -> None:
    sels = event.get("selectors") or {}
    value = event.get("value", "")
    dynamic = event.get("dynamic")
    if dynamic == "otp":
        dyn = await _fetch_otp_dynamic(flags.imap_email, flags.imap_pass)
        value = dyn or value
    if flags.clean:
        loc = await _resolve_target(page, sels, stats)
        primary = sels.get("primary") or ""
        if primary:
            # Clear field first (recorder captures the FINAL value, not deltas)
            try:
                await loc.fill("")
            except Exception:
                pass
            # focus_blur_realism — explicit focus before typing
            try:
                await loc.focus()
                stats.clean_actions.append("focus_blur_realism")
            except Exception:
                pass
            res = await _human.human_type(page, primary, value,
                                          flags.speed_profile(),
                                          focus_first=False)
            stats.key_chars_typed = res.get("key_chars_typed", 0)
            stats.key_corrections = res.get("key_corrections", 0)
            stats.clean_actions.append("human_typing")
            if not res.get("ok"):
                stats.clean_actions.append("human_typing_fallback_fill")
                await loc.fill(value)
        else:
            await loc.fill(value)
            stats.key_chars_typed = len(value)
    else:
        loc = await try_selectors(page, sels, timeout_ms=5000)
        await loc.fill(value)
        stats.key_chars_typed = len(value)
        await asyncio.sleep(max(0, flags.step_delay_ms) / 1000.0)


async def _h_scroll(page, event: dict, flags: MacroFlags,
                    stats: EventStats) -> None:
    """Recorder rarely emits dedicated scroll events; this handler exists for
    completeness if a future recording captures them."""
    delta_y = int(event.get("deltaY", 0) or event.get("dy", 0))
    if flags.clean:
        res = await _human.human_scroll(page, delta_y, flags.speed_profile())
        if res.get("steps_emitted"):
            stats.clean_actions.append(
                f"human_scroll:{res['steps_emitted']}_steps")
    else:
        try:
            await page.evaluate(f"window.scrollBy(0, {delta_y})")
        except Exception:
            pass


async def _h_change(page, event: dict, flags: MacroFlags,
                    stats: EventStats) -> None:
    sels = event.get("selectors") or {}
    value = event.get("value", "")
    if flags.clean:
        loc = await _resolve_target(page, sels, stats)
    else:
        loc = await try_selectors(page, sels, timeout_ms=5000)
    await loc.select_option(value)
    if not flags.clean:
        await asyncio.sleep(max(0, flags.step_delay_ms) / 1000.0)


async def _h_check(page, event: dict, flags: MacroFlags,
                   stats: EventStats) -> None:
    sels = event.get("selectors") or {}
    checked = bool(event.get("checked"))
    if flags.clean:
        loc = await _resolve_target(page, sels, stats)
    else:
        loc = await try_selectors(page, sels, timeout_ms=5000)
    await loc.set_checked(checked)
    if not flags.clean:
        await asyncio.sleep(max(0, flags.step_delay_ms) / 1000.0)


async def _h_key(page, event: dict, flags: MacroFlags,
                 stats: EventStats) -> None:
    key = event.get("key", "")
    submits = bool(event.get("submitsForm"))
    await page.keyboard.press(key)
    stats.key_chars_typed = 1
    if submits:
        try:
            await page.wait_for_load_state("domcontentloaded", timeout=10_000)
        except Exception:
            pass
    await asyncio.sleep(max(0, flags.step_delay_ms) / 1000.0)


_NOISE_PATH_HINTS = ("/analytics", "/telemetry", "/beacon", "/track",
                     "/log", "/metrics", "/collect", "/pixel")


def _is_noise_url(url: str) -> bool:
    """ignore_4xx_noise classifier — tracking/analytics paths whose 4xx is
    expected and shouldn't fail the macro."""
    if not url:
        return False
    low = url.lower()
    return any(h in low for h in _NOISE_PATH_HINTS)


async def _h_nav(page, event: dict, flags: MacroFlags,
                 stats: EventStats) -> None:
    trigger = event.get("trigger") or "framenav"
    dynamic = event.get("dynamic")
    url = event.get("url") or ""
    resp = None
    if dynamic == "verify_url":
        dyn_url = await _fetch_verify_url_dynamic(flags.imap_email,
                                                  flags.imap_pass)
        target = dyn_url or url
        if target:
            resp = await page.goto(target, wait_until="domcontentloaded")
    elif trigger == "address_bar" and url:
        resp = await page.goto(url)
    else:
        try:
            await page.wait_for_load_state("domcontentloaded", timeout=15_000)
        except Exception:
            pass
    if resp:
        stats.http_status = resp.status
        # ignore_4xx_noise: classify nav-resulted 4xx to known noise paths as
        # non-fatal so caller (and CSV row) sees the cleaner action
        if 400 <= resp.status < 500 and flags.clean and _is_noise_url(url):
            stats.clean_actions.append(f"ignore_4xx_noise:{resp.status}")


async def _h_captcha(page, event: dict, flags: MacroFlags,
                     stats: EventStats) -> None:
    from ..control.tools.captcha import captcha_auto
    kind = event.get("kind", "auto")
    sess_id = getattr(page, "_pymcp_session_id", None)
    if not sess_id:
        # macro_runner can't always recover session_id from page; allow caller
        # to attach it. Fallback: skip captcha.
        stats.clean_actions.append("captcha_skipped_no_session")
        return
    try:
        await captcha_auto(session_id=sess_id)
    except Exception as e:
        if flags.strict:
            raise
        stats.clean_actions.append(f"captcha_failed:{type(e).__name__}")
    await asyncio.sleep(max(0, flags.step_delay_ms) / 1000.0)


async def _h_wait(page, event: dict, flags: MacroFlags,
                  stats: EventStats) -> None:
    sels = event.get("selectors") or {}
    await try_selectors(page, sels, timeout_ms=10_000)


async def _h_assert(page, event: dict, flags: MacroFlags,
                    stats: EventStats) -> None:
    sels = event.get("selectors") or {}
    elem = event.get("elem") or {}
    expected = (elem.get("innerText") or elem.get("textContent")
                or elem.get("value") or "")
    loc = await try_selectors(page, sels, timeout_ms=5000)
    got = (await loc.inner_text()) if await loc.count() else ""
    if not expected:
        return
    # exact-match path
    if expected in got:
        return
    # text_loose_match — case-insensitive + whitespace-collapsed contains
    if flags.clean:
        norm_exp = " ".join(expected.lower().split())
        norm_got = " ".join((got or "").lower().split())
        if norm_exp and norm_exp in norm_got:
            stats.clean_actions.append("text_loose_match")
            return
    # still missing
    msg = f"assert miss: expected {expected!r} not in {got!r}"
    if flags.strict:
        raise RuntimeError(msg)
    _log.warning(msg)
    stats.clean_actions.append("assert_miss_warned")


_HANDLERS: dict[str, Handler] = {
    "click": _h_click,
    "input": _h_input,
    "change": _h_change,
    "check": _h_check,
    "key": _h_key,
    "nav": _h_nav,
    "captcha": _h_captcha,
    "wait": _h_wait,
    "assert": _h_assert,
    "scroll": _h_scroll,
}


# ----- Dynamic fetchers (lifted from old template helpers) ------------------

async def _fetch_otp_dynamic(email: str | None, pw: str | None) -> str | None:
    if not email or not pw:
        _log.warning("macro_runner: OTP step has no IMAP creds; literal fallback")
        return None
    return await asyncio.to_thread(_fetch_otp_sync, email, pw)


async def _fetch_verify_url_dynamic(email: str | None, pw: str | None) -> str | None:
    if not email or not pw:
        _log.warning("macro_runner: verify step has no IMAP creds; literal fallback")
        return None
    return await asyncio.to_thread(_fetch_verify_url_sync, email, pw)
