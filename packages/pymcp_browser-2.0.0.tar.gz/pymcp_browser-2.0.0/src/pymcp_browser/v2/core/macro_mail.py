"""Shared IMAP fetch + OTP/verify-URL extraction.

Used by:
  - scripts/firstmail_peek.py (standalone GUI)
  - scripts/macro_launcher.py (engine bindings)
  - compiled macro tasks (dynamic replay-time fetch)

Stdlib only. No project deps.
"""
from __future__ import annotations

import email
import imaplib
import re
from email.header import decode_header, make_header
from email.utils import parseaddr
from html.parser import HTMLParser

DEFAULT_HOST = "imap.firstmail.ltd"
DEFAULT_PORT = 993


class _HTMLStrip(HTMLParser):
    def __init__(self):
        super().__init__()
        self.parts: list[str] = []
        self._skip = 0

    def handle_starttag(self, tag, attrs):
        if tag in ("script", "style", "head"):
            self._skip += 1

    def handle_endtag(self, tag):
        if tag in ("script", "style", "head") and self._skip > 0:
            self._skip -= 1
        if tag in ("br", "p", "div", "tr", "li"):
            self.parts.append("\n")

    def handle_data(self, data):
        if self._skip:
            return
        self.parts.append(data)


def html_to_text(html: str) -> str:
    p = _HTMLStrip()
    try:
        p.feed(html)
    except Exception:
        return html
    out = "".join(p.parts)
    out = re.sub(r"[ \t]+", " ", out)
    return _compact_lines(out)


def _compact_lines(s: str) -> str:
    lines = []
    last_blank = False
    for ln in s.splitlines():
        ln = ln.strip()
        if not ln:
            if not last_blank and lines:
                lines.append("")
                last_blank = True
            continue
        lines.append(ln)
        last_blank = False
    while lines and not lines[-1]:
        lines.pop()
    return "\n".join(lines)


def _decode_h(s) -> str:
    if not s:
        return ""
    try:
        return str(make_header(decode_header(s)))
    except Exception:
        return str(s)


def _payload(part) -> str:
    try:
        raw = part.get_payload(decode=True) or b""
    except Exception:
        return ""
    charset = part.get_content_charset() or "utf-8"
    try:
        return raw.decode(charset, errors="replace")
    except Exception:
        return raw.decode("utf-8", errors="replace")


def fetch_latest(user: str, pw: str, folder: str = "INBOX",
                 host: str = DEFAULT_HOST, port: int = DEFAULT_PORT) -> dict:
    """Login, SELECT readonly, fetch newest by sequence number, parse RFC822.

    Returns dict with keys: empty, folder, total, subject, from, from_addr, to,
    date, body, html_only, size_bytes. On `empty=True`, only folder/total set.
    """
    cli = imaplib.IMAP4_SSL(host, port)
    try:
        cli.login(user, pw)
    except imaplib.IMAP4.error as e:
        cli.logout()
        raise RuntimeError(f"login failed: {e}")
    try:
        typ, data = cli.select(folder, readonly=True)
        if typ != "OK":
            raise RuntimeError(f"select {folder} failed: {data}")
        total = int(data[0]) if data and data[0] else 0
        if total == 0:
            return {"empty": True, "folder": folder, "total": 0}
        typ, msgdata = cli.fetch(str(total), "(RFC822)")
        if typ != "OK" or not msgdata or not msgdata[0]:
            raise RuntimeError("fetch failed")
        raw = msgdata[0][1]
        msg = email.message_from_bytes(raw)
        subject = _decode_h(msg.get("Subject"))
        from_h = _decode_h(msg.get("From"))
        _, from_addr = parseaddr(from_h)
        date_h = msg.get("Date") or ""
        to_h = _decode_h(msg.get("To"))
        body_text = ""
        body_html = ""
        if msg.is_multipart():
            for part in msg.walk():
                ctype = part.get_content_type()
                disp = (part.get("Content-Disposition") or "").lower()
                if "attachment" in disp:
                    continue
                if ctype == "text/plain" and not body_text:
                    body_text = _payload(part)
                elif ctype == "text/html" and not body_html:
                    body_html = _payload(part)
        else:
            ctype = msg.get_content_type()
            payload = _payload(msg)
            if ctype == "text/html":
                body_html = payload
            else:
                body_text = payload
        body = _compact_lines(body_text) or html_to_text(body_html)
        return {
            "empty": False, "folder": folder, "total": total,
            "subject": subject or "(no subject)",
            "from": from_h, "from_addr": from_addr,
            "to": to_h, "date": date_h,
            "body": body, "body_html": body_html,
            "body_text_raw": body_text,
            "html_only": (not body_text and bool(body_html)),
            "size_bytes": len(raw),
        }
    finally:
        try:
            cli.close()
        except Exception:
            pass
        cli.logout()


# ----- parsers ---------------------------------------------------------------

_OTP_NEAR = re.compile(
    r"(?:code|verification|otp|pin|confirm|verify|one[- ]?time)"
    r"[^\d]{0,80}?(\d{4,8})",
    re.IGNORECASE,
)
_OTP_ANY = re.compile(r"\b\d{4,8}\b")
_YEAR_LIKE = re.compile(r"^(?:19|20)\d{2}$")

_VERIFY_NEAR = re.compile(
    r"(?:verify|activate|confirm|click here|click below|set\s*up|finish|"
    r"complete\s+your)[^\n]{0,300}?(https?://[^\s<>\"\)\]]+)",
    re.IGNORECASE | re.DOTALL,
)
_URL_ANY = re.compile(r"https?://[^\s<>\"\)\]]+")
_ANCHOR_RE = re.compile(
    r'<a\b[^>]*?\bhref\s*=\s*["\']([^"\']+)["\'][^>]*>(.*?)</a>',
    re.IGNORECASE | re.DOTALL,
)
_VERIFY_KEYWORD = re.compile(
    r"(verify|activate|confirm|click\s*here|click\s*below|set\s*up|finish|complete)",
    re.IGNORECASE,
)
_KNOWN_AUTH_HOSTS = (
    "auth.typeform.com", "accounts.google.com", "login.microsoftonline.com",
    "id.atlassian.com", "auth.dribbble.com", "auth0.com", "okta.com",
    "myaccount.google.com", "id.github.com", "github.com/login",
)
_TOKEN_SEG = re.compile(r"/[A-Za-z0-9_\-]{16,}")


def extract_otp(body: str) -> str | None:
    """Return best-guess OTP code (4-8 digits) or None."""
    if not body:
        return None
    m = _OTP_NEAR.search(body)
    if m:
        return m.group(1)
    cands = [c for c in _OTP_ANY.findall(body) if not _YEAR_LIKE.match(c)]
    return cands[-1] if cands else None


def _strip_html_tags(s: str) -> str:
    return re.sub(r"<[^>]+>", " ", s or "").strip()


def _score_url(url: str, anchor_text: str) -> int:
    score = 0
    if _VERIFY_KEYWORD.search(anchor_text or ""):
        score += 5
    path = url.split("?")[0].split("#")[0].lower()
    if any(seg in path for seg in ("/verify", "/activate", "/confirm", "/tokens/", "/email-verify", "/verification")):
        score += 5
    for h in _KNOWN_AUTH_HOSTS:
        if h in url.lower():
            score += 3
            break
    if _TOKEN_SEG.search(url):
        score += 2
    return score


def extract_verify_url(body: str, html: str | None = None) -> str | None:
    """Return best-guess verification URL.

    Priority:
      1. Score every <a href> in HTML by anchor text + URL path + host hints.
      2. Fallback: keyword-near regex on plaintext.
      3. Fallback: first https URL in plaintext.
    """
    if html:
        candidates: list[tuple[int, str]] = []
        for m in _ANCHOR_RE.finditer(html):
            url = _strip_trailing(m.group(1).strip())
            if not url.lower().startswith(("http://", "https://")):
                continue
            text = _strip_html_tags(m.group(2))[:120]
            sc = _score_url(url, text)
            if sc > 0:
                candidates.append((sc, url))
        if candidates:
            candidates.sort(key=lambda t: -t[0])
            return candidates[0][1]
    if not body:
        return None
    m = _VERIFY_NEAR.search(body)
    if m:
        return _strip_trailing(m.group(1))
    m = _URL_ANY.search(body)
    return _strip_trailing(m.group(0)) if m else None


def _strip_trailing(url: str) -> str:
    # trim common trailing punctuation that isn't part of the URL
    return url.rstrip(".,;:!?>'\"")


def fetch_otp(user: str, pw: str, host: str = DEFAULT_HOST,
              port: int = DEFAULT_PORT, folder: str = "INBOX") -> str | None:
    """One-shot: fetch latest + extract OTP. None if absent."""
    res = fetch_latest(user, pw, folder=folder, host=host, port=port)
    if res.get("empty"):
        return None
    return extract_otp(res.get("body") or "")


def fetch_verify_url(user: str, pw: str, host: str = DEFAULT_HOST,
                     port: int = DEFAULT_PORT, folder: str = "INBOX") -> str | None:
    res = fetch_latest(user, pw, folder=folder, host=host, port=port)
    if res.get("empty"):
        return None
    return extract_verify_url(res.get("body") or "", res.get("body_html") or "")
