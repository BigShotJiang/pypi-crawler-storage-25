from __future__ import annotations
from dataclasses import dataclass
from typing import Any


@dataclass
class RefEntry:
    ref: str
    page_idx: int
    frame_url: str | None
    handle: Any  # ElementHandle
    role: str | None = None
    name: str | None = None


class RefStore:
    """Per-session ref->ElementHandle map. Counter persists; refs invalidate on nav."""

    def __init__(self):
        self._counter = 0
        self._entries: dict[str, RefEntry] = {}

    def mint(self, page_idx: int, frame_url: str | None, handle: Any,
             role: str | None = None, name: str | None = None) -> str:
        self._counter += 1
        ref = f"e{self._counter}"
        self._entries[ref] = RefEntry(ref, page_idx, frame_url, handle, role, name)
        return ref

    def get(self, ref: str) -> RefEntry | None:
        return self._entries.get(ref)

    def invalidate_page(self, page_idx: int) -> int:
        gone = [r for r, e in self._entries.items() if e.page_idx == page_idx]
        for r in gone:
            del self._entries[r]
        return len(gone)

    def invalidate_frame(self, page_idx: int, frame_url: str | None) -> int:
        gone = [r for r, e in self._entries.items()
                if e.page_idx == page_idx and e.frame_url == frame_url]
        for r in gone:
            del self._entries[r]
        return len(gone)

    def clear(self) -> int:
        n = len(self._entries)
        self._entries.clear()
        return n

    def count(self) -> int:
        return len(self._entries)

    def all(self) -> dict[str, RefEntry]:
        return dict(self._entries)
