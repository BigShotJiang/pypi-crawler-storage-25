"""Async IMAP wrapper. Translates aioimaplib errors to ToolError."""
from __future__ import annotations
import asyncio
import re
from pathlib import Path
from typing import Any, Callable

from loguru import logger

from ...config import settings
from ...control.errors import ToolError
from ...storage.models import MailAccount
from ..credentials import get_mail_password
from .parser import parse_headers, parse_message


def _wrap_protocol(e: Exception, context: str) -> ToolError:
    s = str(e).lower()
    if "auth" in s or "login" in s or "credentials" in s:
        return ToolError("mail_auth_failed", f"{context}: {e}")
    return ToolError("mail_protocol", f"{context}: {e}")


class IMAPClient:
    """One IMAP connection + login lifecycle. Use as async context manager.

    For long-lived sessions (MailSession command channel, IDLE), construct
    once and call connect()/logout() manually.
    """

    def __init__(self, account: MailAccount, timeout: int | None = None):
        self.account = account
        self.timeout = timeout or settings.mail_default_timeout_s
        self._imap = None  # aioimaplib.IMAP4_SSL | IMAP4
        self._capabilities: list[str] = []

    async def __aenter__(self) -> "IMAPClient":
        await self.connect()
        return self

    async def __aexit__(self, *exc):
        await self.logout()

    async def connect(self) -> None:
        try:
            import aioimaplib
        except ImportError as e:
            raise ToolError("internal", f"aioimaplib not installed: {e}")
        cls = aioimaplib.IMAP4_SSL if self.account.imap_ssl else aioimaplib.IMAP4
        try:
            self._imap = cls(host=self.account.imap_host,
                             port=self.account.imap_port,
                             timeout=self.timeout)
            await self._imap.wait_hello_from_server()
        except Exception as e:
            raise _wrap_protocol(e, f"imap connect {self.account.imap_host}")
        password = get_mail_password(self.account.label)
        try:
            r = await self._imap.login(self.account.username, password)
            if r.result != "OK":
                raise ToolError("mail_auth_failed",
                                f"login refused: {' '.join(r.lines or [])}")
        except ToolError:
            raise
        except Exception as e:
            raise _wrap_protocol(e, "imap login")
        try:
            r = await self._imap.capability()
            if r.result == "OK" and r.lines:
                line = b" ".join(r.lines).decode("ascii", errors="replace")
                self._capabilities = line.upper().split()
        except Exception:
            self._capabilities = []

    @property
    def capabilities(self) -> list[str]:
        return list(self._capabilities)

    def has_cap(self, name: str) -> bool:
        return name.upper() in self._capabilities

    async def logout(self) -> None:
        if self._imap is None:
            return
        try:
            await self._imap.logout()
        except Exception:
            pass
        self._imap = None

    async def list_folders(self) -> list[str]:
        try:
            r = await self._imap.list('""', "*")
        except Exception as e:
            raise _wrap_protocol(e, "imap list")
        if r.result != "OK":
            raise ToolError("mail_protocol", f"list failed: {r.lines}")
        out: list[str] = []
        for raw in r.lines or []:
            if isinstance(raw, bytes):
                line = raw.decode("utf-8", errors="replace")
            else:
                line = raw
            m = re.match(r'\([^)]*\)\s+"[^"]*"\s+"?([^"]+)"?\s*$', line)
            if m:
                out.append(m.group(1))
        return out

    def _firstmail_quirk(self) -> bool:
        # D2: firstmail.ltd doesn't honour EXAMINE for subsequent SEARCH.
        host = (self.account.imap_host or "").lower()
        return "firstmail.ltd" in host

    async def _select(self, folder: str, readonly: bool = False) -> None:
        try:
            if readonly and not self._firstmail_quirk():
                r = await self._imap.examine(folder)
            else:
                r = await self._imap.select(folder)
        except Exception as e:
            raise _wrap_protocol(e, f"select {folder}")
        if r.result != "OK":
            raise ToolError("mail_protocol", f"select {folder} failed")

    async def search(self, folder: str, criteria: list[str],
                     limit: int = 50) -> list[int]:
        await self._select(folder, readonly=True)
        crit = criteria or ["ALL"]
        try:
            r = await self._imap.uid_search(*crit)
        except Exception as e:
            raise _wrap_protocol(e, "uid search")
        # D2 generic safety: retry under read-write SELECT if BAD/state error
        if r.result != "OK":
            lines_text = " ".join(
                ln.decode("ascii", errors="replace") if isinstance(ln, bytes) else str(ln)
                for ln in (r.lines or [])
            ).lower()
            if r.result == "BAD" or "illegal in state" in lines_text or "auth" in lines_text:
                logger.warning(
                    "imap search returned {} after EXAMINE; retrying with SELECT",
                    r.result,
                )
                await self._select(folder, readonly=False)
                try:
                    r = await self._imap.uid_search(*crit)
                except Exception as e:
                    raise _wrap_protocol(e, "uid search retry")
        if r.result != "OK":
            raise ToolError("mail_protocol", f"search failed: {r.lines}")
        if not r.lines:
            return []
        first = r.lines[0]
        if isinstance(first, bytes):
            first = first.decode("ascii", errors="replace")
        uids = [int(x) for x in first.split() if x.isdigit()]
        return uids[-limit:] if limit else uids

    async def fetch_sizes(self, folder: str, uids: list[int]) -> dict[int, int]:
        if not uids:
            return {}
        await self._select(folder, readonly=True)
        uid_set = ",".join(str(u) for u in uids)
        try:
            r = await self._imap.uid("FETCH", uid_set, "(RFC822.SIZE)")
        except Exception as e:
            raise _wrap_protocol(e, "uid fetch size")
        out: dict[int, int] = {}
        for raw in r.lines or []:
            if isinstance(raw, bytes):
                raw = raw.decode("ascii", errors="replace")
            m = re.search(r"UID (\d+).*RFC822\.SIZE (\d+)", raw)
            if m:
                out[int(m.group(1))] = int(m.group(2))
        return out

    async def fetch_headers(self, folder: str, uids: list[int]) -> list[dict]:
        if not uids:
            return []
        await self._select(folder, readonly=True)
        uid_set = ",".join(str(u) for u in uids)
        try:
            r = await self._imap.uid(
                "FETCH", uid_set,
                "(UID RFC822.SIZE FLAGS BODY.PEEK[HEADER])")
        except Exception as e:
            raise _wrap_protocol(e, "uid fetch headers")
        out: list[dict] = []
        items = _split_fetch_items(r.lines or [])
        for item in items:
            uid = item.get("uid")
            if uid is None:
                continue
            out.append(parse_headers(item.get("body", b""), uid,
                                     size=item.get("size"),
                                     flags=item.get("flags")))
        return out

    async def fetch(self, folder: str, uids: list[int], save_dir: Path,
                    include_html: bool = True,
                    max_total_size: int | None = None) -> list[dict]:
        if not uids:
            return []
        sizes = await self.fetch_sizes(folder, uids)
        results: list[dict] = []
        cap = max_total_size or (settings.mail_max_attachment_mb * 4 * 1024 * 1024)
        await self._select(folder, readonly=False)
        for uid in uids:
            sz = sizes.get(uid, 0)
            if sz and sz > cap:
                results.append({"uid": uid,
                                "error": "mail_attachment_too_large",
                                "size_bytes": sz})
                continue
            try:
                r = await self._imap.uid(
                    "FETCH", str(uid), "(UID FLAGS BODY.PEEK[])")
            except Exception as e:
                raise _wrap_protocol(e, f"uid fetch {uid}")
            items = _split_fetch_items(r.lines or [])
            if not items:
                results.append({"uid": uid, "error": "not_found"})
                continue
            it = items[0]
            uid_dir = save_dir / str(uid)
            results.append(parse_message(it.get("body", b""), uid, uid_dir,
                                         include_html=include_html,
                                         size=it.get("size"),
                                         flags=it.get("flags")))
        return results

    async def store_flags(self, folder: str, uids: list[int],
                          flag: str, set_: bool = True) -> None:
        if not uids:
            return
        await self._select(folder, readonly=False)
        op = "+FLAGS" if set_ else "-FLAGS"
        uid_set = ",".join(str(u) for u in uids)
        try:
            r = await self._imap.uid("STORE", uid_set, op, f"({flag})")
        except Exception as e:
            raise _wrap_protocol(e, "uid store")
        if r.result != "OK":
            raise ToolError("mail_protocol", f"store failed: {r.lines}")

    async def move(self, folder: str, uids: list[int], dest: str) -> None:
        if not uids:
            return
        await self._select(folder, readonly=False)
        uid_set = ",".join(str(u) for u in uids)
        if self.has_cap("MOVE"):
            try:
                r = await self._imap.uid("MOVE", uid_set, dest)
            except Exception as e:
                raise _wrap_protocol(e, "uid move")
            if r.result != "OK":
                raise ToolError("mail_protocol", f"move failed: {r.lines}")
            return
        try:
            r = await self._imap.uid("COPY", uid_set, dest)
            if r.result != "OK":
                raise ToolError("mail_protocol", f"copy failed: {r.lines}")
            await self.store_flags(folder, uids, r"\Deleted", set_=True)
            await self._imap.expunge()
        except ToolError:
            raise
        except Exception as e:
            raise _wrap_protocol(e, "copy+expunge fallback")

    async def delete(self, folder: str, uids: list[int],
                     expunge: bool = True) -> None:
        await self.store_flags(folder, uids, r"\Deleted", set_=True)
        if expunge:
            try:
                await self._imap.expunge()
            except Exception as e:
                raise _wrap_protocol(e, "expunge")

    async def idle(self, folder: str, on_event: Callable[[dict], None],
                   stop_event: asyncio.Event,
                   keepalive_s: int | None = None) -> None:
        if not self.has_cap("IDLE"):
            raise ToolError("mail_idle_unsupported",
                            f"server lacks IDLE capability "
                            f"(caps: {','.join(self._capabilities)})")
        await self._select(folder, readonly=False)
        ka = keepalive_s or settings.mail_idle_keepalive_s
        while not stop_event.is_set():
            try:
                idle_task = await self._imap.idle_start(timeout=ka + 30)
            except Exception as e:
                raise _wrap_protocol(e, "idle start")
            try:
                while not stop_event.is_set():
                    try:
                        line = await asyncio.wait_for(
                            self._imap.wait_server_push(), timeout=ka)
                    except asyncio.TimeoutError:
                        break
                    if not line:
                        continue
                    text = line if isinstance(line, str) else \
                        b" ".join(line).decode("ascii", errors="replace") \
                        if isinstance(line, list) else \
                        line.decode("ascii", errors="replace")
                    _dispatch_idle_line(text, folder, on_event)
            finally:
                try:
                    self._imap.idle_done()
                    await asyncio.wait_for(idle_task, timeout=10)
                except Exception:
                    pass


# ----- internal helpers -----

def _split_fetch_items(lines: list[Any]) -> list[dict]:
    """aioimaplib returns FETCH responses as alternating (header_line, body_bytes, ')').

    We split into per-message items with parsed UID/FLAGS/SIZE + raw header/body bytes.
    """
    items: list[dict] = []
    i = 0
    while i < len(lines):
        head = lines[i]
        if isinstance(head, bytes):
            head_s = head.decode("ascii", errors="replace")
        elif isinstance(head, str):
            head_s = head
        else:
            i += 1
            continue
        if "FETCH" not in head_s.upper():
            i += 1
            continue
        m_uid = re.search(r"UID (\d+)", head_s)
        m_size = re.search(r"RFC822\.SIZE (\d+)", head_s)
        m_flags = re.search(r"FLAGS \(([^)]*)\)", head_s)
        body = b""
        if i + 1 < len(lines) and isinstance(lines[i + 1], (bytes, bytearray)):
            body = bytes(lines[i + 1])
            i += 2
        else:
            i += 1
        items.append({
            "uid": int(m_uid.group(1)) if m_uid else None,
            "size": int(m_size.group(1)) if m_size else None,
            "flags": m_flags.group(1).split() if m_flags else [],
            "body": body,
        })
        # consume trailing close-paren if present
        if i < len(lines):
            trail = lines[i]
            if isinstance(trail, bytes) and trail.strip() in (b")", b""):
                i += 1
            elif isinstance(trail, str) and trail.strip() in (")", ""):
                i += 1
    return items


_EXISTS_RE = re.compile(r"^\*?\s*(\d+)\s+EXISTS", re.I)
_EXPUNGE_RE = re.compile(r"^\*?\s*(\d+)\s+EXPUNGE", re.I)
_FETCH_RE = re.compile(r"^\*?\s*(\d+)\s+FETCH.*FLAGS \(([^)]*)\)", re.I)


def _dispatch_idle_line(text: str, folder: str,
                        on_event: Callable[[dict], None]) -> None:
    for raw in text.splitlines():
        line = raw.strip()
        if not line:
            continue
        m = _EXISTS_RE.match(line)
        if m:
            on_event({"topic": "mail.new", "folder": folder,
                      "seq": int(m.group(1))})
            continue
        m = _EXPUNGE_RE.match(line)
        if m:
            on_event({"topic": "mail.expunge", "folder": folder,
                      "seq": int(m.group(1))})
            continue
        m = _FETCH_RE.match(line)
        if m:
            on_event({"topic": "mail.flags", "folder": folder,
                      "seq": int(m.group(1)),
                      "flags": m.group(2).split()})
