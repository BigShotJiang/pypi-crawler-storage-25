"""MIME parsing helpers — pure functions, no I/O."""
from __future__ import annotations
import email
import re
from email.message import Message
from email.header import decode_header
from email.utils import parseaddr, getaddresses, parsedate_to_datetime
from pathlib import Path
from typing import Any

_SAFE_FN = re.compile(r"[^A-Za-z0-9._-]+")


def _decode(s: str | None) -> str:
    if not s:
        return ""
    parts = decode_header(s)
    out: list[str] = []
    for chunk, enc in parts:
        if isinstance(chunk, bytes):
            try:
                out.append(chunk.decode(enc or "utf-8", errors="replace"))
            except (LookupError, TypeError):
                out.append(chunk.decode("utf-8", errors="replace"))
        else:
            out.append(chunk)
    return "".join(out)


def _addrs(msg: Message, header: str) -> list[str]:
    raw = msg.get_all(header) or []
    return [f"{_decode(name)} <{addr}>".strip() if name else addr
            for name, addr in getaddresses(raw) if addr]


def _date_ts(msg: Message) -> float | None:
    raw = msg.get("Date")
    if not raw:
        return None
    try:
        return parsedate_to_datetime(raw).timestamp()
    except (TypeError, ValueError):
        return None


def parse_headers(raw: bytes, uid: int, size: int | None = None,
                  flags: list[str] | None = None) -> dict[str, Any]:
    msg = email.message_from_bytes(raw)
    return {
        "uid": uid,
        "from": _addrs(msg, "From"),
        "to": _addrs(msg, "To"),
        "cc": _addrs(msg, "Cc"),
        "subject": _decode(msg.get("Subject")),
        "date_ts": _date_ts(msg),
        "message_id": msg.get("Message-ID"),
        "in_reply_to": msg.get("In-Reply-To"),
        "size_bytes": size,
        "flags": flags or [],
    }


def _sanitize_filename(name: str, fallback_idx: int) -> str:
    name = (name or "").rsplit("/", 1)[-1].rsplit("\\", 1)[-1]
    name = _SAFE_FN.sub("_", name).strip("._-")
    if not name:
        name = f"att_{fallback_idx}.bin"
    return name[:200]


def parse_message(raw: bytes, uid: int, save_dir: Path,
                  include_html: bool = True,
                  size: int | None = None,
                  flags: list[str] | None = None) -> dict[str, Any]:
    msg = email.message_from_bytes(raw)
    body_text = ""
    body_html = ""
    attachments: list[dict[str, Any]] = []
    save_dir.mkdir(parents=True, exist_ok=True)
    att_idx = 0

    for part in msg.walk():
        if part.is_multipart():
            continue
        ctype = part.get_content_type()
        disp = (part.get("Content-Disposition") or "").lower()
        is_attachment = "attachment" in disp or part.get_filename()
        if is_attachment:
            att_idx += 1
            filename = _sanitize_filename(_decode(part.get_filename() or ""), att_idx)
            payload = part.get_payload(decode=True) or b""
            path = save_dir / filename
            counter = 1
            while path.exists():
                stem = path.stem
                suffix = path.suffix
                path = save_dir / f"{stem}_{counter}{suffix}"
                counter += 1
            path.write_bytes(payload)
            attachments.append({
                "filename": path.name,
                "content_type": ctype,
                "size_bytes": len(payload),
                "path": str(path),
            })
            continue
        if ctype == "text/plain" and not body_text:
            payload = part.get_payload(decode=True) or b""
            charset = part.get_content_charset() or "utf-8"
            try:
                body_text = payload.decode(charset, errors="replace")
            except LookupError:
                body_text = payload.decode("utf-8", errors="replace")
        elif ctype == "text/html" and include_html and not body_html:
            payload = part.get_payload(decode=True) or b""
            charset = part.get_content_charset() or "utf-8"
            try:
                body_html = payload.decode(charset, errors="replace")
            except LookupError:
                body_html = payload.decode("utf-8", errors="replace")

    return {
        "uid": uid,
        "from": _addrs(msg, "From"),
        "to": _addrs(msg, "To"),
        "cc": _addrs(msg, "Cc"),
        "subject": _decode(msg.get("Subject")),
        "date_ts": _date_ts(msg),
        "message_id": msg.get("Message-ID"),
        "in_reply_to": msg.get("In-Reply-To"),
        "size_bytes": size,
        "flags": flags or [],
        "body_text": body_text,
        "body_html": body_html,
        "attachments": attachments,
    }
