"""Async SMTP wrapper with attachment + threading support."""
from __future__ import annotations
import time
from email.message import EmailMessage
from email.utils import make_msgid, formatdate
from pathlib import Path
from typing import Any

from sqlmodel import select

from ...config import settings
from ...control.errors import ToolError
from ...storage.db import session_scope
from ...storage.models import MailAccount
from ..credentials import get_mail_password


def _wrap_protocol(e: Exception, context: str) -> ToolError:
    s = str(e).lower()
    if "auth" in s or "credentials" in s:
        return ToolError("mail_auth_failed", f"{context}: {e}")
    return ToolError("mail_protocol", f"{context}: {e}")


def _check_recipient_cap(to: list[str], cc: list[str], bcc: list[str]) -> None:
    total = len(to) + len(cc) + len(bcc)
    cap = settings.mail_recipient_cap_per_call
    if total > cap:
        raise ToolError(
            "invalid_args",
            f"recipients {total} exceeds cap {cap}",
            hint="split into smaller batches",
        )


def _check_and_increment_volume(account: MailAccount) -> None:
    """Atomic-ish rolling 24h window check + increment. SQLite serializes writes."""
    if account.daily_send_limit is None:
        return
    now = time.time()
    with session_scope() as s:
        row = s.get(MailAccount, account.label)
        if row is None:
            return
        ws = row.daily_send_window_start_ts or 0.0
        if now - ws > 86400:
            row.daily_send_window_start_ts = now
            row.daily_send_count = 0
        if row.daily_send_limit is not None and row.daily_send_count >= row.daily_send_limit:
            retry = int(86400 - (now - (row.daily_send_window_start_ts or now)))
            raise ToolError(
                "mail_rate_limited",
                f"daily send limit {row.daily_send_limit} reached",
                retry_after_s=max(retry, 0),
            )
        row.daily_send_count += 1
        row.last_used_ts = now


def _check_attachments(paths: list[str]) -> list[Path]:
    cap = settings.mail_max_attachment_mb * 1024 * 1024
    out: list[Path] = []
    total = 0
    for raw in paths:
        p = Path(raw)
        if not p.exists() or not p.is_file():
            raise ToolError("invalid_args", f"attachment not found: {raw}")
        sz = p.stat().st_size
        total += sz
        out.append(p)
    if total > cap:
        raise ToolError(
            "mail_attachment_too_large",
            f"attachments total {total} > cap {cap}",
        )
    return out


def _build_message(account: MailAccount, *, to: list[str],
                   cc: list[str], bcc: list[str], subject: str,
                   body_text: str, body_html: str | None,
                   attachments: list[Path],
                   in_reply_to: str | None,
                   references: list[str] | None,
                   headers: dict[str, str] | None) -> EmailMessage:
    msg = EmailMessage()
    msg["From"] = account.username
    msg["To"] = ", ".join(to)
    if cc:
        msg["Cc"] = ", ".join(cc)
    msg["Subject"] = subject
    msg["Date"] = formatdate(localtime=True)
    msg["Message-ID"] = make_msgid()
    if in_reply_to:
        msg["In-Reply-To"] = in_reply_to
    if references:
        msg["References"] = " ".join(references)
    for k, v in (headers or {}).items():
        msg[k] = v
    msg.set_content(body_text or "")
    if body_html:
        msg.add_alternative(body_html, subtype="html")
    for p in attachments:
        data = p.read_bytes()
        ctype = "application/octet-stream"
        maintype, subtype = ctype.split("/", 1)
        msg.add_attachment(data, maintype=maintype, subtype=subtype,
                           filename=p.name)
    return msg


class SMTPClient:
    @staticmethod
    async def send(account: MailAccount, *,
                   to: list[str],
                   cc: list[str] | None = None,
                   bcc: list[str] | None = None,
                   subject: str = "",
                   body_text: str = "",
                   body_html: str | None = None,
                   attachments: list[str] | None = None,
                   in_reply_to: str | None = None,
                   references: list[str] | None = None,
                   headers: dict[str, str] | None = None) -> dict[str, Any]:
        cc = cc or []
        bcc = bcc or []
        _check_recipient_cap(to, cc, bcc)
        att_paths = _check_attachments(attachments or [])
        _check_and_increment_volume(account)
        msg = _build_message(account, to=to, cc=cc, bcc=bcc, subject=subject,
                             body_text=body_text, body_html=body_html,
                             attachments=att_paths, in_reply_to=in_reply_to,
                             references=references, headers=headers)
        try:
            import aiosmtplib
        except ImportError as e:
            raise ToolError("internal", f"aiosmtplib not installed: {e}")
        password = get_mail_password(account.label)
        tls_mode = (account.smtp_tls or "ssl").lower()
        kwargs: dict[str, Any] = {
            "hostname": account.smtp_host,
            "port": account.smtp_port,
            "username": account.username,
            "password": password,
            "timeout": settings.mail_default_timeout_s,
        }
        if tls_mode == "ssl":
            kwargs["use_tls"] = True
            kwargs["start_tls"] = False
        elif tls_mode == "starttls":
            kwargs["use_tls"] = False
            kwargs["start_tls"] = True
        else:
            kwargs["use_tls"] = False
            kwargs["start_tls"] = False
        try:
            await aiosmtplib.send(
                msg,
                recipients=[*to, *cc, *bcc],
                **kwargs,
            )
        except Exception as e:
            raise _wrap_protocol(e, "smtp send")
        return {
            "ok": True,
            "message_id": msg["Message-ID"],
            "recipient_count": len(to) + len(cc) + len(bcc),
        }
