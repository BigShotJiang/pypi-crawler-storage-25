from __future__ import annotations
import time
from collections import defaultdict, deque
from typing import Any


class EventsBuffer:
    """Per-topic ring buffer (500 entries default)."""

    def __init__(self, capacity: int = 500):
        self.capacity = capacity
        self._rings: dict[str, deque] = defaultdict(lambda: deque(maxlen=capacity))

    def push(self, topic: str, **payload: Any) -> None:
        ent = {"ts": time.time(), "topic": topic, **payload}
        self._rings[topic].append(ent)

    def get(self, topics: list[str] | None = None, since_ts: float | None = None,
            limit: int = 200) -> list[dict]:
        topics = topics or list(self._rings.keys())
        out: list[dict] = []
        for tp in topics:
            for ent in self._rings.get(tp, ()):
                if since_ts is None or ent["ts"] > since_ts:
                    out.append(ent)
        out.sort(key=lambda e: e["ts"])
        return out[-limit:]

    def topics(self) -> list[str]:
        return list(self._rings.keys())
