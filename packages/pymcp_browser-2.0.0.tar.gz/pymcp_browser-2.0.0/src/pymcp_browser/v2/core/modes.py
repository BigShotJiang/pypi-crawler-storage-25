from __future__ import annotations
from typing import Literal

Mode = Literal["vanilla", "stealth", "human"]


def mode_flags(mode: Mode) -> dict:
    if mode == "vanilla":
        return dict(
            stealth=False, fingerprint=False, mouse_jitter=False,
            force_human_typing=False, hover_before_click=False,
            inter_action_ms_min=0, inter_action_ms_max=0,
            hover_dwell_ms_min=0, hover_dwell_ms_max=0,
            mouse_jitter_px=0, type_delay_ms_min=0, type_delay_ms_max=0,
            auto_wait_load=False, macro_toolbar=True,
        )
    if mode == "stealth":
        return dict(
            stealth=True, fingerprint=True, mouse_jitter=False,
            force_human_typing=False, hover_before_click=False,
            inter_action_ms_min=0, inter_action_ms_max=0,
            hover_dwell_ms_min=0, hover_dwell_ms_max=0,
            mouse_jitter_px=0, type_delay_ms_min=0, type_delay_ms_max=0,
            auto_wait_load=False, macro_toolbar=True,
        )
    if mode == "human":
        return dict(
            stealth=True, fingerprint=True, mouse_jitter=True,
            force_human_typing=True, hover_before_click=True,
            inter_action_ms_min=500, inter_action_ms_max=1200,
            hover_dwell_ms_min=200, hover_dwell_ms_max=400,
            mouse_jitter_px=4, type_delay_ms_min=60, type_delay_ms_max=180,
            auto_wait_load=True, macro_toolbar=False,
        )
    raise ValueError(f"unknown mode: {mode}")
