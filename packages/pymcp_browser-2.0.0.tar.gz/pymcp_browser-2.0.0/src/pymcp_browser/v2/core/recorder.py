from __future__ import annotations
import json
import time
from pathlib import Path
from typing import Any
from loguru import logger


class SessionRecorder:
    """Always-on lightweight recorder. Heavy mode opts in to tracing + dom dumps."""

    def __init__(self, session_id: str, debug_dir: str, heavy: bool = False):
        self.session_id = session_id
        self.dir = Path(debug_dir) / session_id
        self.dir.mkdir(parents=True, exist_ok=True)
        self.events_path = self.dir / "events.jsonl"
        self.heavy = heavy
        self.heavy_dir = self.dir / "heavy"
        if heavy:
            self.heavy_dir.mkdir(parents=True, exist_ok=True)
        self._seq = 0

    def _append(self, obj: dict) -> None:
        try:
            with self.events_path.open("a", encoding="utf-8") as f:
                f.write(json.dumps(obj, default=str, ensure_ascii=False) + "\n")
        except Exception as e:
            logger.warning("recorder write failed: {}", e)

    def event(self, kind: str, **payload: Any) -> None:
        self._append({"ts": time.time(), "kind": kind, **payload})

    def tool_call(self, tool_name: str, args_summary: dict, result_code: str,
                  duration_ms: float) -> None:
        self._append({"ts": time.time(), "kind": "tool_call",
                      "tool": tool_name, "args": args_summary,
                      "result": result_code, "duration_ms": duration_ms})

    def heavy_dump(self, label: str, png: bytes | None = None,
                   html: str | None = None) -> tuple[Path | None, Path | None]:
        if not self.heavy:
            return None, None
        self._seq += 1
        png_path = html_path = None
        try:
            if png is not None:
                png_path = self.heavy_dir / f"{self._seq:04d}_{label}.png"
                png_path.write_bytes(png)
            if html is not None:
                html_path = self.heavy_dir / f"{self._seq:04d}_{label}.html"
                html_path.write_text(html, encoding="utf-8")
        except Exception as e:
            logger.warning("heavy dump failed: {}", e)
        return png_path, html_path

    def write_meta(self, meta: dict) -> None:
        try:
            (self.dir / "meta.json").write_text(json.dumps(meta, indent=2, default=str),
                                                encoding="utf-8")
        except Exception as e:
            logger.warning("meta write failed: {}", e)
