from __future__ import annotations
import asyncio
import time
import uuid
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any
from loguru import logger

from ..config import settings
from .browser_manager import BrowserManager
from .events_buffer import EventsBuffer
from .modes import Mode, mode_flags
from .recorder import SessionRecorder
from .ref_store import RefStore
from ..control.errors import ToolError


@dataclass
class BrowserSession:
    id: str
    profile_id: str | None
    proxy_provider: str | None
    proxy_zone: str | None
    proxy_session_tag: str | None
    mode: Mode
    headless: bool
    viewport: dict
    record_heavy: bool
    context: Any = None  # BrowserContext
    pages: list[Any] = field(default_factory=list)
    tab_id_map: dict[str, Any] = field(default_factory=dict)
    ref_store: RefStore = field(default_factory=RefStore)
    events: EventsBuffer = field(default_factory=EventsBuffer)
    net_handlers: dict[str, dict] = field(default_factory=dict)
    tasks: dict[str, Any] = field(default_factory=dict)
    last_activity_ts: float = field(default_factory=time.time)
    lock: asyncio.Lock = field(default_factory=asyncio.Lock)
    recorder: SessionRecorder | None = None
    parent_session_id: str | None = None
    closed: bool = False
    tab_counter: int = 0
    proxy_egress_ip: str | None = None
    kind: str = "browser"
    engine: str = "chromium"

    def touch(self) -> None:
        self.last_activity_ts = time.time()

    def add_page(self, page: Any) -> str:
        self.tab_counter += 1
        tid = f"t{self.tab_counter}"
        self.tab_id_map[tid] = page
        self.pages.append(page)
        return tid

    def tab_id_for(self, page: Any) -> str | None:
        for tid, p in self.tab_id_map.items():
            if p is page:
                return tid
        return None

    def active_page(self) -> Any:
        if not self.pages:
            return None
        return self.pages[-1]


@dataclass
class MailSession:
    id: str
    account_label: str
    events: EventsBuffer = field(default_factory=EventsBuffer)
    last_activity_ts: float = field(default_factory=time.time)
    lock: asyncio.Lock = field(default_factory=asyncio.Lock)
    recorder: SessionRecorder | None = None
    closed: bool = False
    imap: Any = None  # IMAPClient command channel
    idle_tasks: dict[str, tuple] = field(default_factory=dict)  # idle_id -> (task, stop_event, IMAPClient)
    tasks: dict[str, Any] = field(default_factory=dict)
    kind: str = "mail"

    def touch(self) -> None:
        self.last_activity_ts = time.time()


class SessionRegistry:
    """Singleton registry. Manages create/lookup/eviction."""

    _instance: "SessionRegistry | None" = None

    def __init__(self):
        self._sessions: dict[str, BrowserSession] = {}
        self._lock = asyncio.Lock()
        self._scanner_task: asyncio.Task | None = None
        self._no_proxy_warned = False

    @classmethod
    def get(cls) -> "SessionRegistry":
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    def list(self) -> list[BrowserSession]:
        return list(self._sessions.values())

    def lookup(self, session_id: str) -> BrowserSession:
        s = self._sessions.get(session_id)
        if s is None or s.closed:
            raise ToolError("session_not_found", f"no session {session_id}")
        s.touch()
        return s

    async def create(self, *, profile_name: str | None = None,
                     proxy_provider: str | None = "proxyfog",
                     proxy_zone: str | None = None,
                     proxyfog_mode: str | None = "sticky",
                     proxyfog_ttl_minutes: int = 30,
                     proxyfog_protocol: str = "http",
                     country: str | None = None,
                     fingerprint_overrides: dict | None = None,
                     mode: Mode = "stealth",
                     headless: bool | None = None,
                     no_proxy: bool = False,
                     record_heavy: bool = False,
                     viewport: dict | None = None,
                     parent_session_id: str | None = None,
                     storage_state: dict | None = None,
                     kind: str = "browser",
                     account_label: str | None = None,
                     auto_diagnose: bool | None = None,
                     engine: str | None = None):
        if kind == "mail":
            return await self._create_mail(account_label=account_label,
                                           profile_name=profile_name,
                                           proxy_provider=proxy_provider,
                                           proxy_zone=proxy_zone,
                                           viewport=viewport,
                                           mode_arg=mode if mode != "stealth" else None,
                                           headless=headless,
                                           fingerprint_overrides=fingerprint_overrides,
                                           record_heavy=record_heavy)
        if kind != "browser":
            raise ToolError("invalid_args", f"unknown session kind: {kind}")
        async with self._lock:
            await self._evict_if_capped(kind="browser")
            sid = uuid.uuid4().hex[:12]
            vp = viewport or {"width": 1280, "height": 800}
            hl = settings.headless_default if headless is None else headless
            eng = engine or settings.default_engine
            from .browser_manager import VALID_ENGINES
            if eng not in VALID_ENGINES:
                raise ToolError("invalid_args", f"unknown engine: {eng}")

            if not proxy_provider and not no_proxy and not self._no_proxy_warned:
                logger.warning("session.create: no proxy configured; pass no_proxy=true to silence")
                self._no_proxy_warned = True

            ctx_kwargs: dict[str, Any] = {
                "viewport": {"width": int(vp["width"]), "height": int(vp["height"])},
            }
            if storage_state:
                ctx_kwargs["storage_state"] = storage_state

            geo_tz: str | None = None
            geo_country: str | None = None
            geo_egress: str | None = None
            proxy_dict: dict | None = None
            if proxy_provider == "proxyfog":
                from .proxy import build_proxyfog_proxy
                proxy_dict = build_proxyfog_proxy(
                    mode=proxyfog_mode or "rotating",
                    ttl_minutes=proxyfog_ttl_minutes,
                    sid=sid,
                    protocol=proxyfog_protocol,
                    country=country,
                )
                ctx_kwargs["proxy"] = proxy_dict
            elif proxy_provider == "brightdata":
                from .proxy import build_brightdata_proxy
                proxy_dict = build_brightdata_proxy(
                    zone=proxy_zone or "datacenter_proxy1",
                    country=country,
                    session_tag=sid[:8],
                )
                ctx_kwargs["proxy"] = proxy_dict
            if proxy_dict:
                # httpx pre-probe through same proxy to learn geo BEFORE context
                import httpx
                try:
                    server = proxy_dict["server"]
                    scheme = server.split("://", 1)[0]
                    host_port = server.split("://", 1)[1]
                    proxy_url = (f"{scheme}://{proxy_dict['username']}:"
                                 f"{proxy_dict['password']}@{host_port}")
                    async with httpx.AsyncClient(
                        proxy=proxy_url, timeout=20.0, verify=False,
                    ) as cli:
                        r = await cli.get("http://ip-api.com/json/")
                        body = r.json()
                    geo_egress = body.get("query")
                    geo_tz = body.get("timezone")
                    geo_country = body.get("countryCode")
                except Exception as e:
                    raise ToolError("proxy_unreachable", f"{proxy_provider} probe failed: {e}")

                if geo_tz:
                    ctx_kwargs["timezone_id"] = geo_tz
                if geo_country:
                    locale_map = {"BR": "pt-BR", "IN": "en-IN", "US": "en-US",
                                  "GB": "en-GB", "DE": "de-DE", "FR": "fr-FR",
                                  "NL": "nl-NL", "ES": "es-ES", "IT": "it-IT",
                                  "JP": "ja-JP", "CN": "zh-CN", "RU": "ru-RU",
                                  "PT": "pt-PT", "PL": "pl-PL", "MX": "es-MX",
                                  "AR": "es-AR", "CO": "es-CO", "CL": "es-CL"}
                    ctx_kwargs["locale"] = locale_map.get(geo_country, "en-US")

            launch_proxy = ctx_kwargs.pop("proxy", None)
            # Per-engine fingerprint routing.
            cfx_extras: dict | None = None
            if fingerprint_overrides:
                from .fingerprint_adapter import (
                    for_chromium, for_patchright, for_camoufox,
                )
                if eng == "chromium":
                    ctx_kwargs.update(for_chromium(fingerprint_overrides))
                elif eng == "patchright":
                    ctx_kwargs.update(for_patchright(fingerprint_overrides))
                elif eng == "camoufox":
                    cfx_extras = for_camoufox(fingerprint_overrides)
            try:
                bm = await BrowserManager.get()
                context = await bm.new_context(engine=eng, headless=hl,
                                               proxy=launch_proxy,
                                               camoufox_extras=cfx_extras,
                                               **ctx_kwargs)
            except Exception as e:
                raise ToolError("internal", f"browser_context_failed: {e}")

            flags = mode_flags(mode)
            if flags["stealth"] and eng == "chromium":
                locale_for_js = ctx_kwargs.get("locale", "en-US")
                init_js = """
                Object.defineProperty(navigator, 'webdriver', { get: () => undefined });
                Object.defineProperty(navigator, 'languages', { get: () => __LANGS__ });
                Object.defineProperty(navigator, 'plugins', {
                    get: () => [1,2,3,4,5].map(i => ({name:'Plugin'+i, filename:'p'+i+'.dll', description:''}))
                });
                window.chrome = window.chrome || { runtime: {} };
                const origQuery = window.navigator.permissions && window.navigator.permissions.query;
                if (origQuery) {
                    window.navigator.permissions.query = (p) =>
                        p && p.name === 'notifications'
                            ? Promise.resolve({state: Notification.permission})
                            : origQuery(p);
                }
                """.replace("__LANGS__", str([locale_for_js, locale_for_js.split("-")[0]]).replace("'", '"'))
                try:
                    await context.add_init_script(init_js)
                except Exception as e:
                    logger.warning("init_script add failed: {}", e)
            page = await context.new_page()

            sess = BrowserSession(
                id=sid, profile_id=profile_name,
                proxy_provider=proxy_provider, proxy_zone=proxy_zone,
                proxy_session_tag=uuid.uuid4().hex[:8] if proxy_provider else None,
                mode=mode, headless=hl, viewport=vp, record_heavy=record_heavy,
                context=context, parent_session_id=parent_session_id,
                engine=eng,
            )
            sess.add_page(page)
            sess.human_flags = flags
            sess.recorder = SessionRecorder(sid, settings.debug_dir, heavy=record_heavy)
            sess.recorder.event("session.create", mode=mode, headless=hl,
                                proxy=proxy_provider)

            if proxy_dict:
                sess.proxy_egress_ip = geo_egress
                sess.recorder.event("proxy.probe",
                                    provider=proxy_provider,
                                    egress_ip=geo_egress, tz=geo_tz, country=geo_country)

            self._wire_page(sess, page)
            context.on("page", lambda p: self._on_new_page(sess, p))

            if eng in ("chromium", "patchright"):
                try:
                    from .macro import wire_macro
                    await wire_macro(sess, toolbar=bool(flags.get("macro_toolbar", not hl)))
                except Exception as e:
                    logger.warning("macro wire failed: {}", e)
            else:
                logger.info("macro wiring skipped for engine={}", eng)

            if record_heavy:
                try:
                    await context.tracing.start(screenshots=True, snapshots=True)
                except Exception as e:
                    logger.warning("tracing start failed: {}", e)

            self._sessions[sid] = sess
            self._ensure_scanner()

            if auto_diagnose is not False:
                enabled = auto_diagnose is True
                if not enabled:
                    enabled = settings.session_auto_diagnose
                    try:
                        from ..storage.db import kv_get
                        kv_val = kv_get("diag_enabled")
                        if kv_val == "0":
                            enabled = False
                        elif kv_val == "1":
                            enabled = True
                    except Exception:
                        pass
                if enabled:
                    try:
                        from .diagnosis import run_diagnosis_safe
                        await run_diagnosis_safe(sess)
                    except Exception as e:
                        logger.warning("auto-diagnosis hook errored: {}", e)

            return sess

    def _on_new_page(self, sess: BrowserSession, page: Any) -> None:
        if page in sess.pages:
            return
        sess.add_page(page)
        self._wire_page(sess, page)
        sess.events.push("page", kind="page.new", url=page.url)
        if sess.recorder:
            sess.recorder.event("page.new", url=page.url)

    def _wire_page(self, sess: BrowserSession, page: Any) -> None:
        def on_console(msg):
            try:
                sess.events.push("console", type=msg.type, text=msg.text)
                if sess.recorder:
                    sess.recorder.event("console", type=msg.type, text=msg.text)
            except Exception:
                pass

        def on_request(req):
            try:
                sess.events.push("network", kind="request",
                                 method=req.method, url=req.url,
                                 resource_type=req.resource_type)
            except Exception:
                pass

        def on_response(resp):
            try:
                sess.events.push("network", kind="response",
                                 status=resp.status, url=resp.url)
            except Exception:
                pass

        def on_framenav(fr):
            try:
                page_idx = sess.pages.index(page) if page in sess.pages else -1
                if fr is page.main_frame:
                    sess.ref_store.invalidate_page(page_idx)
                else:
                    sess.ref_store.invalidate_frame(page_idx, fr.url)
                sess.events.push("page", kind="framenavigated", url=fr.url)
            except Exception:
                pass

        def on_popup(p):
            self._on_new_page(sess, p)

        def on_dialog(d):
            sess.events.push("page", kind="dialog", type=d.type, message=d.message)
            if sess.recorder:
                sess.recorder.event("dialog", type=d.type, message=d.message)

        def on_download(dl):
            sess.events.push("page", kind="download", suggested=dl.suggested_filename)

        page.on("console", on_console)
        page.on("request", on_request)
        page.on("response", on_response)
        page.on("framenavigated", on_framenav)
        page.on("popup", on_popup)
        page.on("dialog", on_dialog)
        page.on("download", on_download)

    async def close(self, session_id: str, persist: bool = True) -> None:
        sess = self._sessions.get(session_id)
        if sess is None or sess.closed:
            raise ToolError("session_not_found", f"no session {session_id}")
        sess.closed = True
        if getattr(sess, "kind", "browser") == "mail":
            try:
                for idle_id, (task, stop_ev, idle_cli) in list(sess.idle_tasks.items()):
                    try:
                        stop_ev.set()
                    except Exception:
                        pass
                    try:
                        task.cancel()
                    except Exception:
                        pass
                    try:
                        await idle_cli.logout()
                    except Exception:
                        pass
                if sess.imap:
                    try:
                        await sess.imap.logout()
                    except Exception:
                        pass
                if sess.recorder:
                    sess.recorder.write_meta({"id": sess.id, "kind": "mail",
                                              "closed_ts": time.time()})
            finally:
                self._sessions.pop(session_id, None)
            return
        try:
            for h in list(sess.net_handlers.values()):
                try:
                    await h["dispose"]()
                except Exception:
                    pass
            if sess.record_heavy and sess.context:
                try:
                    trace_path = Path(settings.debug_dir) / sess.id / "trace.zip"
                    await sess.context.tracing.stop(path=str(trace_path))
                except Exception as e:
                    logger.warning("trace stop failed: {}", e)
            if persist and sess.context:
                try:
                    state_path = Path(settings.storage_dir) / f"{sess.id}.json"
                    state_path.parent.mkdir(parents=True, exist_ok=True)
                    await sess.context.storage_state(path=str(state_path))
                except Exception as e:
                    logger.warning("storage_state save failed: {}", e)
            if sess.context:
                await sess.context.close()
            if sess.recorder:
                sess.recorder.write_meta({"id": sess.id, "mode": sess.mode,
                                          "closed_ts": time.time(),
                                          "persist": persist})
        finally:
            self._sessions.pop(session_id, None)

    async def _evict_if_capped(self, kind: str = "browser") -> None:
        cap = settings.max_mail_sessions if kind == "mail" else settings.session_max
        same_kind = [s for s in self._sessions.values()
                     if getattr(s, "kind", "browser") == kind]
        if len(same_kind) < cap:
            return
        lru = sorted(same_kind, key=lambda s: s.last_activity_ts)[0]
        lru.events.push("session", kind="session.evicted", reason="cap")
        if lru.recorder:
            lru.recorder.event("session.evicted", reason="cap")
        try:
            await self.close(lru.id, persist=True)
        except Exception:
            pass

    async def _create_mail(self, *, account_label: str | None,
                           profile_name: str | None,
                           proxy_provider: str | None,
                           proxy_zone: str | None,
                           viewport: dict | None,
                           mode_arg,
                           headless: bool | None,
                           fingerprint_overrides: dict | None,
                           record_heavy: bool) -> "MailSession":
        offending: list[str] = []
        if proxy_provider is not None:
            offending.append("proxy_provider")
        if proxy_zone is not None:
            offending.append("proxy_zone")
        if viewport is not None:
            offending.append("viewport")
        if mode_arg is not None:
            offending.append("mode")
        if headless is not None:
            offending.append("headless")
        if fingerprint_overrides is not None:
            offending.append("fingerprint_overrides")
        if record_heavy:
            offending.append("record_heavy")
        if profile_name is not None:
            offending.append("profile_name")
        if offending:
            raise ToolError("invalid_args",
                            "kind='mail' rejects browser-only args",
                            hint=f"remove: {', '.join(offending)}")
        if not account_label:
            raise ToolError("invalid_args",
                            "kind='mail' requires account_label")
        from ..storage.db import session_scope
        from ..storage.models import MailAccount
        from .mail import IMAPClient
        with session_scope() as s:
            row = s.get(MailAccount, account_label)
            if row is None:
                raise ToolError("mail_account_not_found", account_label)
            s.expunge(row)
            account = row
        async with self._lock:
            await self._evict_if_capped(kind="mail")
            sid = uuid.uuid4().hex[:12]
        cli = IMAPClient(account)
        await cli.connect()
        sess = MailSession(id=sid, account_label=account_label, imap=cli)
        sess.recorder = SessionRecorder(sid, settings.debug_dir, heavy=False)
        sess.recorder.event("mail_session.create", account=account_label,
                            imap_host=account.imap_host)
        sess.events.push("session", kind="mail_session.create",
                         account=account_label)
        self._sessions[sid] = sess
        self._ensure_scanner()
        return sess

    def _ensure_scanner(self) -> None:
        if self._scanner_task and not self._scanner_task.done():
            return
        self._scanner_task = asyncio.create_task(self._idle_scan())

    async def _idle_scan(self) -> None:
        while True:
            try:
                await asyncio.sleep(60)
                now = time.time()
                ttl_s = settings.session_idle_ttl_ms / 1000
                for sid, s in list(self._sessions.items()):
                    if s.closed:
                        continue
                    if now - s.last_activity_ts > ttl_s:
                        s.events.push("session", kind="session.evicted", reason="idle_ttl")
                        if s.recorder:
                            s.recorder.event("session.evicted", reason="idle_ttl")
                        try:
                            await self.close(sid, persist=True)
                        except Exception:
                            pass
            except asyncio.CancelledError:
                return
            except Exception as e:
                logger.warning("idle scan err: {}", e)
