"""Phase 1.5 — CSV per-event run logger.

Append-only, crash-safe, concurrent-safe per-event log of macro replays.
Default OFF (caller passes `enabled=False` → returns _NullLogger no-op).

Output layout (under `data/macro_runs/`):
- `<macro>__<YYYY-MM>.csv`  — one row per event
- `_index.csv`              — one row per RUN

Safety:
- header written exactly once (size-check)
- per-row flush + os.fsync (or batched via PYMCP_CSV_BUFFER env)
- filelock.FileLock per file for concurrent writes
- crash recovery — last-byte newline check on open, repair if missing
- UTF-8 with BOM on first write
- escape \\r\\n\\t inside `value` so no row-split possible

NO REDACTION. Caller-supplied values stored verbatim. Folder is gitignored.
"""
from __future__ import annotations
import csv
import io
import os
import time
import uuid
from contextlib import contextmanager
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from filelock import FileLock


# ---- Schema -----------------------------------------------------------------

EVENT_COLUMNS: list[str] = [
    "ts_iso", "ts_epoch_ms", "run_id", "macro_name", "identity_seed",
    "iteration", "event_seq", "event_type", "selector", "value", "phase",
    "duration_ms", "ok", "error_class", "error_msg", "clean_actions",
    "retry_count", "mouse_path_len", "key_chars_typed", "key_corrections",
    "interevent_pause_ms", "viewport_w", "viewport_h", "page_url",
    "http_status", "proxy_egress_ip", "actual_country",
]

INDEX_COLUMNS: list[str] = [
    "run_id", "macro_name", "identity_seed", "clean_mode", "unique_mode",
    "csv_logging", "loop_count", "iteration", "started_iso", "duration_ms",
    "event_count", "ok", "error_class", "proxy_egress_ip",
    "actual_country", "csv_path",
]

DEFAULT_BASE_DIR = Path("./data/macro_runs")

# Truncation lengths (no redaction — verbatim then truncate-with-suffix)
_TRUNC_VALUE = 500
_TRUNC_SELECTOR = 200
_TRUNC_URL = 250
_TRUNC_ERROR_MSG = 200


# ---- Helpers ----------------------------------------------------------------

def _now_iso() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%fZ")


def _strip_control(s: str) -> str:
    """Replace \\r\\n\\t with single space — NOT redaction; a row-safety guard.
    Other characters pass through verbatim including quotes/commas (csv module
    handles those via QUOTE_MINIMAL)."""
    if not s:
        return ""
    return s.replace("\r", " ").replace("\n", " ").replace("\t", " ")


def _trunc(s: str, limit: int) -> str:
    if not s or len(s) <= limit:
        return s or ""
    return s[:limit] + f"...[truncated:{len(s)}]"


def _ensure_trailing_newline(path: Path) -> None:
    """Crash recovery: if last byte isn't \\n, append one. Marks recovery."""
    try:
        if not path.exists() or path.stat().st_size == 0:
            return
        with path.open("rb") as f:
            f.seek(-1, os.SEEK_END)
            last = f.read(1)
        if last != b"\n":
            with path.open("ab") as f:
                f.write(b"\n")
    except Exception:
        pass


def _file_lock(path: Path) -> FileLock:
    return FileLock(str(path) + ".lock")


# ---- Logger -----------------------------------------------------------------

@dataclass
class CsvRunLogger:
    run_id: str
    macro_name: str
    identity_seed: str | None
    clean_mode: bool
    unique_mode: bool
    loop_count: int
    iteration: int
    base_dir: Path = field(default_factory=lambda: DEFAULT_BASE_DIR)

    # Internal state
    _started_ts: float = field(default_factory=time.time)
    _event_count: int = 0
    _proxy_egress_ip: str = ""
    _actual_country: str = ""
    _last_error_class: str = ""
    _last_event_csv_path: Path | None = None
    _buffer_size: int = 1            # 1 = fsync per row; >1 batches
    _pending_rows: list[list[str]] = field(default_factory=list)
    _initialized: bool = False

    def __post_init__(self) -> None:
        env_buf = os.environ.get("PYMCP_CSV_BUFFER", "1")
        try:
            self._buffer_size = max(1, int(env_buf))
        except ValueError:
            self._buffer_size = 1
        self.base_dir = Path(self.base_dir)
        self.base_dir.mkdir(parents=True, exist_ok=True)
        self._initialized = True

    # ---- Public API ----

    def log_event(self, event_type: str, *,
                  event_seq: int = 0,
                  selector: str = "",
                  value: str = "",
                  phase: str = "apply",
                  duration_ms: int = 0,
                  ok: bool = True,
                  error_class: str = "",
                  error_msg: str = "",
                  clean_actions: list[str] | None = None,
                  retry_count: int = 0,
                  mouse_path_len: int = 0,
                  key_chars_typed: int = 0,
                  key_corrections: int = 0,
                  interevent_pause_ms: int = 0,
                  viewport_w: int = 0,
                  viewport_h: int = 0,
                  page_url: str = "",
                  http_status: int = 0,
                  proxy_egress_ip: str = "",
                  actual_country: str = "") -> None:
        self._event_count += 1
        if proxy_egress_ip and not self._proxy_egress_ip:
            self._proxy_egress_ip = proxy_egress_ip
        if actual_country and not self._actual_country:
            self._actual_country = actual_country
        if not ok and error_class:
            self._last_error_class = error_class

        ts = time.time()
        row = [
            _now_iso(),
            str(int(ts * 1000)),
            self.run_id,
            self.macro_name,
            self.identity_seed or "",
            str(self.iteration),
            str(event_seq),
            event_type,
            _strip_control(_trunc(selector, _TRUNC_SELECTOR)),
            _strip_control(_trunc(value, _TRUNC_VALUE)),
            phase,
            str(duration_ms),
            "1" if ok else "0",
            error_class,
            _strip_control(_trunc(error_msg, _TRUNC_ERROR_MSG)),
            ";".join(clean_actions or []),
            str(retry_count),
            str(mouse_path_len),
            str(key_chars_typed),
            str(key_corrections),
            str(interevent_pause_ms),
            str(viewport_w),
            str(viewport_h),
            _strip_control(_trunc(page_url, _TRUNC_URL)),
            str(http_status),
            proxy_egress_ip,
            actual_country,
        ]
        self._pending_rows.append(row)
        if len(self._pending_rows) >= self._buffer_size:
            self._flush_events()

    def finalize(self, ok: bool = True, error_class: str = "") -> None:
        self._flush_events()
        duration_ms = int((time.time() - self._started_ts) * 1000)
        index_row = [
            self.run_id,
            self.macro_name,
            self.identity_seed or "",
            "1" if self.clean_mode else "0",
            "1" if self.unique_mode else "0",
            "1",  # csv_logging always 1 here (NullLogger doesn't reach finalize)
            str(self.loop_count),
            str(self.iteration),
            datetime.fromtimestamp(self._started_ts,
                                   tz=timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%fZ"),
            str(duration_ms),
            str(self._event_count),
            "1" if ok else "0",
            error_class or self._last_error_class,
            self._proxy_egress_ip,
            self._actual_country,
            str(self._last_event_csv_path or ""),
        ]
        self._append_locked(self._index_path(), INDEX_COLUMNS, [index_row])

    # ---- Internal ----

    def _events_path(self) -> Path:
        # rolling monthly
        ym = datetime.now(timezone.utc).strftime("%Y-%m")
        path = self.base_dir / f"{self.macro_name}__{ym}.csv"
        self._last_event_csv_path = path
        return path

    def _index_path(self) -> Path:
        return self.base_dir / "_index.csv"

    def _flush_events(self) -> None:
        if not self._pending_rows:
            return
        rows = self._pending_rows
        self._pending_rows = []
        self._append_locked(self._events_path(), EVENT_COLUMNS, rows)

    def _append_locked(self, path: Path, header: list[str],
                       rows: list[list[str]]) -> None:
        if not rows:
            return
        path.parent.mkdir(parents=True, exist_ok=True)
        with _file_lock(path):
            # Crash-recovery: ensure prior partial line is closed before append
            _ensure_trailing_newline(path)
            need_header = (not path.exists()) or path.stat().st_size == 0
            mode = "ab"
            with path.open(mode) as fh:
                buf = io.StringIO()
                writer = csv.writer(buf, quoting=csv.QUOTE_MINIMAL,
                                    escapechar="\\", lineterminator="\n")
                if need_header:
                    # UTF-8 BOM on first write for Excel friendliness
                    fh.write(b"\xef\xbb\xbf")
                    writer.writerow(header)
                for r in rows:
                    writer.writerow(r)
                payload = buf.getvalue().encode("utf-8")
                fh.write(payload)
                fh.flush()
                try:
                    os.fsync(fh.fileno())
                except OSError:
                    pass


class _NullLogger:
    """No-op API match. Used when CSV-Logging is disabled.

    Same shape as CsvRunLogger so callers don't need to branch.
    """
    def log_event(self, *args, **kwargs) -> None:
        pass

    def finalize(self, *args, **kwargs) -> None:
        pass


def open_run_logger(enabled: bool, *,
                    macro_name: str,
                    identity_seed: str | None = None,
                    clean_mode: bool = True,
                    unique_mode: bool = False,
                    loop_count: int = 1,
                    iteration: int = 1,
                    run_id: str | None = None,
                    base_dir: Path | None = None) -> CsvRunLogger | _NullLogger:
    if not enabled:
        return _NullLogger()
    return CsvRunLogger(
        run_id=run_id or uuid.uuid4().hex,
        macro_name=macro_name,
        identity_seed=identity_seed,
        clean_mode=clean_mode,
        unique_mode=unique_mode,
        loop_count=loop_count,
        iteration=iteration,
        base_dir=base_dir or DEFAULT_BASE_DIR,
    )
