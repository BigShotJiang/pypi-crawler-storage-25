from __future__ import annotations
from typing import Any
from .ref_store import RefStore

INTERACTIVE_ROLES = {
    "button", "link", "textbox", "searchbox", "checkbox", "radio", "combobox",
    "slider", "menuitem", "menuitemcheckbox", "menuitemradio", "switch",
    "tab", "treeitem", "option", "spinbutton",
}


def _is_interactive(node: dict) -> bool:
    return (node.get("role") or "").lower() in INTERACTIVE_ROLES


async def snapshot_page(page: Any, page_idx: int, ref_store: RefStore,
                        *, depth: int | None = None, boxes: bool = False,
                        interesting_only: bool = True,
                        max_chars: int = 12000) -> tuple[str, int, bool]:
    """Build YAML snapshot. Returns (yaml, ref_count_added, truncated)."""
    try:
        tree = await page.accessibility.snapshot(interesting_only=interesting_only)
    except Exception:
        tree = None
    lines: list[str] = []
    added = 0
    truncated = False

    async def walk(node: dict, indent: int, level: int) -> None:
        nonlocal added, truncated
        if node is None:
            return
        if depth is not None and level > depth:
            return
        if sum(len(l) + 1 for l in lines) > max_chars:
            truncated = True
            return
        role = node.get("role") or ""
        name = node.get("name") or ""
        prefix = "  " * indent + "- "
        bits = [role]
        if name:
            esc = name.replace('"', "'")
            if len(esc) > 80:
                esc = esc[:77] + "..."
            bits.append(f'"{esc}"')
        if _is_interactive(node) or role in {"region", "form", "dialog", "iframe"}:
            try:
                handle = None
                # cheap: locate by role+name
                if name:
                    loc = page.get_by_role(role, name=name).first
                    handle = await loc.element_handle()
                if handle is not None:
                    ref = ref_store.mint(page_idx, page.main_frame.url, handle, role, name)
                    bits.append(f"[ref={ref}]")
                    added += 1
                    if boxes:
                        try:
                            bbox = await handle.bounding_box()
                            if bbox:
                                bits.append(f"[box={int(bbox['x'])},{int(bbox['y'])},"
                                            f"{int(bbox['width'])},{int(bbox['height'])}]")
                        except Exception:
                            pass
            except Exception:
                pass
        line = prefix + " ".join(b for b in bits if b)
        if node.get("children"):
            line += ":"
        lines.append(line)
        for child in node.get("children", []) or []:
            await walk(child, indent + 1, level + 1)

    if tree is not None:
        if tree.get("children"):
            for c in tree["children"]:
                await walk(c, 0, 0)
        else:
            await walk(tree, 0, 0)

    # D5: DOM fallback when accessibility tree empty (SPAs like Tally/Typeform).
    if added == 0 and not lines:
        try:
            elems = await _dom_fallback_scan(page)
            for el in elems[:100]:
                bits = [el["role"] or el["tag"]]
                if el["name"]:
                    esc = el["name"].replace('"', "'")
                    if len(esc) > 80:
                        esc = esc[:77] + "..."
                    bits.append(f'"{esc}"')
                lines.append("- " + " ".join(bits) + f"  # source=dom_fallback selector={el['selector']!r}")
            if elems:
                lines.insert(0, "# accessibility tree empty; DOM fallback scan (D5)")
        except Exception:
            pass

    if truncated:
        lines.append("[truncated]")
    return ("\n".join(lines), added, truncated)


async def _dom_fallback_scan(page: Any) -> list[dict]:
    """D5: When a11y tree is empty, scan DOM for interactive elements directly."""
    js = """
    () => {
      const sel = 'button, input, a, select, textarea, [role], [data-qa], [aria-label]';
      const els = Array.from(document.querySelectorAll(sel));
      const visible = el => {
        const r = el.getBoundingClientRect();
        if (!r.width || !r.height) return false;
        const cs = getComputedStyle(el);
        return cs.visibility !== 'hidden' && cs.display !== 'none';
      };
      return els.filter(visible).slice(0, 200).map(el => ({
        tag: el.tagName.toLowerCase(),
        role: el.getAttribute('role') || '',
        name: (el.getAttribute('aria-label') || el.innerText || el.value || '').trim().slice(0, 120),
        selector: el.id ? '#' + el.id
                : el.getAttribute('data-qa') ? '[data-qa="' + el.getAttribute('data-qa') + '"]'
                : el.tagName.toLowerCase(),
      }));
    }
    """
    return await page.evaluate(js)
