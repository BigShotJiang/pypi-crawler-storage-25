from __future__ import annotations
from loguru import logger
from .credentials import get_proxyfog, get_brightdata
from ..control.errors import ToolError

_COUNTRY_WARNED = False


def build_proxyfog_proxy(mode: str, ttl_minutes: int, sid: str,
                         protocol: str = "http",
                         country: str | None = None) -> dict:
    """Build Playwright per-context proxy dict for ProxyFog.

    mode: 'sticky' | 'rotating'
    ttl_minutes: clamped [1,60] for sticky; ignored for rotating
    sid: BrowserSession.id for sticky username
    protocol: 'http' | 'https' | 'socks5'
    country: currently no-op, logs warning once
    """
    global _COUNTRY_WARNED
    if mode not in ("sticky", "rotating"):
        raise ToolError("invalid_args", f"proxyfog_mode must be sticky|rotating, got {mode}")
    if protocol not in ("http", "https", "socks5"):
        raise ToolError("invalid_args", f"proxyfog_protocol invalid: {protocol}")

    if country and not _COUNTRY_WARNED:
        logger.warning("proxyfog country routing not yet wired; ignoring country={}", country)
        _COUNTRY_WARNED = True

    creds = get_proxyfog()

    if mode == "sticky":
        if ttl_minutes <= 0:
            raise ToolError("invalid_args", "proxyfog_ttl_minutes must be >=1")
        if ttl_minutes > 60:
            logger.warning("proxyfog ttl clamped to 60min (got {})", ttl_minutes)
            ttl_minutes = 60
        username = f"{creds['username_base']}-session-{sid}-ttl-{ttl_minutes}"
    else:
        username = creds["username_base"]

    return {
        "server": f"{protocol}://{creds['host']}:{creds['port']}",
        "username": username,
        "password": creds["password"],
    }


def build_brightdata_proxy(zone: str = "datacenter_proxy1",
                           country: str | None = None,
                           session_tag: str | None = None,
                           protocol: str = "http") -> dict:
    creds = get_brightdata(zone)
    if creds["kind"] != "http":
        raise ToolError("invalid_args", "brightdata wss zone not usable as http proxy")
    user = creds["username_base"]
    if country:
        user += f"-country-{country.lower()}"
    if session_tag:
        user += f"-session-{session_tag}"
    return {
        "server": f"{protocol}://{creds['host_port']}",
        "username": user,
        "password": creds["password"],
    }
