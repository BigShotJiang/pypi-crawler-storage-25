"""Country code → fingerprint hints (locale, languages, timezone fallback).

Used by core.proxy_probe to mold browser fingerprint to actual proxy egress
country when verify-and-retry fails or is bypassed.
"""
from __future__ import annotations

# country_code (ISO-3166 alpha-2 upper) -> (primary_locale, [accept_languages], timezone_fallback)
_MAP: dict[str, tuple[str, list[str], str]] = {
    "US": ("en-US", ["en-US", "en"], "America/New_York"),
    "CA": ("en-CA", ["en-CA", "en", "fr-CA"], "America/Toronto"),
    "GB": ("en-GB", ["en-GB", "en"], "Europe/London"),
    "IE": ("en-IE", ["en-IE", "en"], "Europe/Dublin"),
    "AU": ("en-AU", ["en-AU", "en"], "Australia/Sydney"),
    "NZ": ("en-NZ", ["en-NZ", "en"], "Pacific/Auckland"),
    "DE": ("de-DE", ["de-DE", "de", "en"], "Europe/Berlin"),
    "AT": ("de-AT", ["de-AT", "de", "en"], "Europe/Vienna"),
    "CH": ("de-CH", ["de-CH", "de", "fr-CH", "en"], "Europe/Zurich"),
    "FR": ("fr-FR", ["fr-FR", "fr", "en"], "Europe/Paris"),
    "BE": ("nl-BE", ["nl-BE", "fr-BE", "en"], "Europe/Brussels"),
    "NL": ("nl-NL", ["nl-NL", "nl", "en"], "Europe/Amsterdam"),
    "ES": ("es-ES", ["es-ES", "es", "en"], "Europe/Madrid"),
    "IT": ("it-IT", ["it-IT", "it", "en"], "Europe/Rome"),
    "PT": ("pt-PT", ["pt-PT", "pt", "en"], "Europe/Lisbon"),
    "BR": ("pt-BR", ["pt-BR", "pt", "en"], "America/Sao_Paulo"),
    "MX": ("es-MX", ["es-MX", "es", "en"], "America/Mexico_City"),
    "AR": ("es-AR", ["es-AR", "es", "en"], "America/Argentina/Buenos_Aires"),
    "PL": ("pl-PL", ["pl-PL", "pl", "en"], "Europe/Warsaw"),
    "SE": ("sv-SE", ["sv-SE", "sv", "en"], "Europe/Stockholm"),
    "NO": ("nb-NO", ["nb-NO", "no", "en"], "Europe/Oslo"),
    "DK": ("da-DK", ["da-DK", "da", "en"], "Europe/Copenhagen"),
    "FI": ("fi-FI", ["fi-FI", "fi", "en"], "Europe/Helsinki"),
    "RU": ("ru-RU", ["ru-RU", "ru", "en"], "Europe/Moscow"),
    "UA": ("uk-UA", ["uk-UA", "uk", "ru", "en"], "Europe/Kyiv"),
    "TR": ("tr-TR", ["tr-TR", "tr", "en"], "Europe/Istanbul"),
    "JP": ("ja-JP", ["ja-JP", "ja", "en"], "Asia/Tokyo"),
    "KR": ("ko-KR", ["ko-KR", "ko", "en"], "Asia/Seoul"),
    "CN": ("zh-CN", ["zh-CN", "zh", "en"], "Asia/Shanghai"),
    "TW": ("zh-TW", ["zh-TW", "zh", "en"], "Asia/Taipei"),
    "HK": ("zh-HK", ["zh-HK", "zh", "en"], "Asia/Hong_Kong"),
    "SG": ("en-SG", ["en-SG", "en", "zh"], "Asia/Singapore"),
    "IN": ("en-IN", ["en-IN", "en", "hi"], "Asia/Kolkata"),
    "ID": ("id-ID", ["id-ID", "id", "en"], "Asia/Jakarta"),
    "TH": ("th-TH", ["th-TH", "th", "en"], "Asia/Bangkok"),
    "VN": ("vi-VN", ["vi-VN", "vi", "en"], "Asia/Ho_Chi_Minh"),
    "PH": ("en-PH", ["en-PH", "en", "fil"], "Asia/Manila"),
    "MY": ("ms-MY", ["ms-MY", "ms", "en"], "Asia/Kuala_Lumpur"),
    "AE": ("ar-AE", ["ar-AE", "ar", "en"], "Asia/Dubai"),
    "SA": ("ar-SA", ["ar-SA", "ar", "en"], "Asia/Riyadh"),
    "IL": ("he-IL", ["he-IL", "he", "en"], "Asia/Jerusalem"),
    "ZA": ("en-ZA", ["en-ZA", "en"], "Africa/Johannesburg"),
    "KE": ("en-KE", ["en-KE", "en", "sw"], "Africa/Nairobi"),
    "NG": ("en-NG", ["en-NG", "en"], "Africa/Lagos"),
    "EG": ("ar-EG", ["ar-EG", "ar", "en"], "Africa/Cairo"),
    "MA": ("ar-MA", ["ar-MA", "ar", "fr", "en"], "Africa/Casablanca"),
    "GR": ("el-GR", ["el-GR", "el", "en"], "Europe/Athens"),
    "RO": ("ro-RO", ["ro-RO", "ro", "en"], "Europe/Bucharest"),
    "CZ": ("cs-CZ", ["cs-CZ", "cs", "en"], "Europe/Prague"),
    "HU": ("hu-HU", ["hu-HU", "hu", "en"], "Europe/Budapest"),
    "BG": ("bg-BG", ["bg-BG", "bg", "en"], "Europe/Sofia"),
    "HR": ("hr-HR", ["hr-HR", "hr", "en"], "Europe/Zagreb"),
    "RS": ("sr-RS", ["sr-RS", "sr", "en"], "Europe/Belgrade"),
    "PK": ("ur-PK", ["ur-PK", "ur", "en"], "Asia/Karachi"),
    "BD": ("bn-BD", ["bn-BD", "bn", "en"], "Asia/Dhaka"),
    "CL": ("es-CL", ["es-CL", "es", "en"], "America/Santiago"),
    "CO": ("es-CO", ["es-CO", "es", "en"], "America/Bogota"),
    "PE": ("es-PE", ["es-PE", "es", "en"], "America/Lima"),
}

_DEFAULT = ("en-US", ["en-US", "en"], "Etc/UTC")


def hints_for_country(country: str | None) -> dict:
    """Return locale/languages/timezone hints for a country code.

    Falls back to en-US/UTC for unknown codes. Result keys:
    - locale: BCP-47 primary (e.g. "en-KE")
    - languages: Accept-Language list
    - timezone: IANA tz id used as fallback when probe didn't supply one
    """
    cc = (country or "").upper()
    locale, langs, tz = _MAP.get(cc, _DEFAULT)
    # Trim languages to 2 entries (locale + base language). Real Chrome with a
    # single Accept-Language preference sends exactly this — adding fallbacks
    # like 'en' to non-English locales triggers Pixelscan's "Languages" flag
    # because it doesn't match the Accept-Language header Chrome actually sends.
    base = locale.split("-")[0]
    trimmed = [locale] if locale == base else [locale, base]
    return {"locale": locale, "languages": trimmed, "timezone": tz,
            "country": cc or None, "matched": cc in _MAP}
