"""Per-engine fingerprint translation.

Shared `fingerprint_overrides` schema:
  user_agent, locale, timezone_id, color_scheme, viewport,
  os, navigator_platform, languages

Adapters convert to engine-native fields. Unknown keys silently dropped.
"""
from __future__ import annotations
from typing import Any
from loguru import logger


_SHARED_KEYS = {
    "user_agent", "locale", "timezone_id", "color_scheme",
    "viewport", "os", "navigator_platform", "languages",
}


def for_chromium(overrides: dict | None) -> dict:
    """Chromium uses BrowserContext kwargs + add_init_script.
    Returns dict of context kwargs to merge into new_context call.
    """
    if not overrides:
        return {}
    out: dict[str, Any] = {}
    if ua := overrides.get("user_agent"):
        out["user_agent"] = ua
    if lc := overrides.get("locale"):
        out["locale"] = lc
    if tz := overrides.get("timezone_id"):
        out["timezone_id"] = tz
    if cs := overrides.get("color_scheme"):
        out["color_scheme"] = cs
    if vp := overrides.get("viewport"):
        out["viewport"] = vp
    _warn_unknown("chromium", overrides)
    return out


def for_patchright(overrides: dict | None) -> dict:
    """Patchright = patched Chromium; same context kwargs as chromium."""
    return for_chromium(overrides)


def for_camoufox(overrides: dict | None) -> dict:
    """Camoufox accepts native fingerprint as AsyncCamoufox launch kwargs.
    Returns dict to be passed into AsyncCamoufox(...) constructor.
    """
    if not overrides:
        return {}
    out: dict[str, Any] = {}
    if os_val := overrides.get("os"):
        out["os"] = os_val
    if locale := overrides.get("locale"):
        out["locale"] = [locale] if isinstance(locale, str) else locale
    if langs := overrides.get("languages"):
        out["locale"] = langs if isinstance(langs, list) else [langs]
    _warn_unknown("camoufox", overrides)
    return out


def _warn_unknown(engine: str, overrides: dict) -> None:
    unknown = set(overrides.keys()) - _SHARED_KEYS
    if unknown:
        logger.debug("fingerprint_overrides unknown keys for {}: {}", engine, unknown)
