from __future__ import annotations
import asyncio
import hashlib
import json
import time
from typing import Any
from loguru import logger

from ..config import settings
from ..control.errors import ToolError
from .credentials import get_ipinfo_token


DIAG_JS = r"""
async () => {
  const out = {};
  try {
    out.userAgent = navigator.userAgent;
    out.platform = navigator.platform;
    out.languages = navigator.languages;
    out.language = navigator.language;
    out.hardwareConcurrency = navigator.hardwareConcurrency || null;
    out.deviceMemory = navigator.deviceMemory || null;
    out.cookiesEnabled = navigator.cookieEnabled;
    out.doNotTrack = navigator.doNotTrack;
    out.webdriver = navigator.webdriver === true;
    out.chromeRuntime = !!(window.chrome && window.chrome.runtime);
    out.touchSupport = 'ontouchstart' in window;
    out.screen = {
      width: screen.width, height: screen.height,
      colorDepth: screen.colorDepth, pixelDepth: screen.pixelDepth,
      devicePixelRatio: window.devicePixelRatio || 1
    };
    out.timezoneResolved = Intl.DateTimeFormat().resolvedOptions().timeZone;
    try {
      const c = document.createElement('canvas');
      const gl = c.getContext('webgl') || c.getContext('experimental-webgl');
      if (gl) {
        const dbg = gl.getExtension('WEBGL_debug_renderer_info');
        out.webgl = dbg ? {
          vendor: gl.getParameter(dbg.UNMASKED_VENDOR_WEBGL),
          renderer: gl.getParameter(dbg.UNMASKED_RENDERER_WEBGL)
        } : { vendor: gl.getParameter(gl.VENDOR), renderer: gl.getParameter(gl.RENDERER) };
      } else { out.webgl = null; }
    } catch (e) { out.webgl = null; }
    try {
      const c = document.createElement('canvas');
      c.width = 220; c.height = 30;
      const ctx = c.getContext('2d');
      ctx.textBaseline = 'top';
      ctx.font = "14px 'Arial'";
      ctx.fillStyle = '#f60';
      ctx.fillRect(125,1,62,20);
      ctx.fillStyle = '#069';
      ctx.fillText('PyMCPdiag~?!', 2, 15);
      out.canvasDataUrl = c.toDataURL();
    } catch (e) { out.canvasDataUrl = null; }
    out.plugins = Array.from(navigator.plugins || []).map(p => p.name);
    out.mimeTypes = Array.from(navigator.mimeTypes || []).map(m => m.type);
    const FONTS = ['Arial','Times New Roman','Courier New','Verdana','Georgia',
                   'Tahoma','Trebuchet MS','Comic Sans MS','Impact',
                   'Helvetica','Calibri','Cambria','Consolas','Segoe UI'];
    try {
      out.fonts = (document.fonts && typeof document.fonts.check === 'function')
        ? FONTS.filter(f => document.fonts.check(`12px "${f}"`))
        : [];
    } catch (e) { out.fonts = []; }
    try {
      out.permissionsNotifications = (navigator.permissions && typeof navigator.permissions.query === 'function')
        ? (await navigator.permissions.query({name: 'notifications'})).state
        : null;
    } catch (e) { out.permissionsNotifications = null; }
  } catch (e) { out._err = String(e); }
  return out;
}
"""


_HEADER_KEEP = {"user-agent", "accept-language", "sec-ch-ua",
                "sec-ch-ua-platform", "sec-ch-ua-mobile"}


async def _capture(sess) -> dict[str, Any]:
    page = sess.active_page()
    if page is None:
        raise ToolError("no_active_page", "session has no active page")

    started = time.time()

    try:
        fp = await page.evaluate(DIAG_JS)
    except Exception as e:
        raise ToolError("diag_failed", f"fingerprint evaluate failed: {e}")

    canvas_url = fp.pop("canvasDataUrl", None)
    fp["canvasHash"] = (
        hashlib.sha256(canvas_url.encode()).hexdigest()[:32] if canvas_url else None
    )

    token = settings.ipinfo_token or get_ipinfo_token() or ""
    url = f"https://ipinfo.io/json{('?token=' + token) if token else ''}"
    net: dict[str, Any] = {}
    req_headers: dict[str, Any] = {}
    try:
        resp = await page.request.get(url, timeout=8000)
        if resp.ok:
            try:
                net = await resp.json()
            except Exception:
                net = {"error": "non_json", "status": resp.status}
        else:
            net = {"error": f"http_{resp.status}"}
        try:
            req_headers = await resp.request.all_headers()
        except Exception:
            req_headers = {}
    except Exception as e:
        net = {"error": str(e)}

    proxy_egress = getattr(sess, "proxy_egress_ip", None)
    ip_match = None
    if proxy_egress and isinstance(net.get("ip"), str):
        ip_match = (proxy_egress == net["ip"])

    blob = {
        "session_id": sess.id,
        "captured_ts": started,
        "duration_ms": int((time.time() - started) * 1000),
        "network": net,
        "fingerprint": fp,
        "request_headers": {
            k: v for k, v in (req_headers or {}).items()
            if k.lower() in _HEADER_KEEP
        },
        "proxy_egress_ip": proxy_egress,
        "ip_match": ip_match,
    }
    return blob


def _persist(blob: dict[str, Any]) -> None:
    from ..storage.db import session_scope
    from ..storage.models import SessionDiagnosis
    from sqlmodel import select

    sid = blob["session_id"]
    net = blob.get("network") or {}
    row = SessionDiagnosis(
        session_id=sid,
        captured_ts=blob["captured_ts"],
        ip=net.get("ip") if isinstance(net, dict) else None,
        country=net.get("country") if isinstance(net, dict) else None,
        org=net.get("org") if isinstance(net, dict) else None,
        proxy_egress_ip=blob.get("proxy_egress_ip"),
        ip_match=blob.get("ip_match"),
        blob_json=json.dumps(blob),
    )
    cap = max(1, int(settings.diag_history_cap))
    with session_scope() as s:
        s.add(row)
        s.flush()
        existing = list(s.exec(
            select(SessionDiagnosis)
            .where(SessionDiagnosis.session_id == sid)
            .order_by(SessionDiagnosis.captured_ts.desc())
        ).all())
        if len(existing) > cap:
            for old in existing[cap:]:
                s.delete(old)


async def run_diagnosis(sess, *, force: bool = False) -> dict[str, Any]:
    """Capture network + fingerprint snapshot for a browser session.

    Cached on the session object; pass force=True to recapture.
    Persists to SessionDiagnosis with FIFO cap of settings.diag_history_cap.
    """
    if not force:
        cached = getattr(sess, "_diag_cache", None)
        if cached:
            return cached

    timeout_s = max(0.1, settings.diag_timeout_ms / 1000.0)
    try:
        blob = await asyncio.wait_for(_capture(sess), timeout=timeout_s)
    except asyncio.TimeoutError:
        if sess.recorder:
            sess.recorder.event("diag.timeout", timeout_ms=settings.diag_timeout_ms)
        raise ToolError("timeout", f"diagnosis exceeded {settings.diag_timeout_ms}ms")
    except ToolError:
        raise
    except Exception as e:
        raise ToolError("diag_failed", f"capture failed: {e}")

    sess._diag_cache = blob
    try:
        _persist(blob)
    except Exception as e:
        logger.warning("diag persist failed: {}", e)

    if sess.recorder:
        net = blob.get("network") or {}
        sess.recorder.event(
            "diag.run",
            ip=net.get("ip") if isinstance(net, dict) else None,
            country=net.get("country") if isinstance(net, dict) else None,
            ip_match=blob.get("ip_match"),
            duration_ms=blob.get("duration_ms"),
        )
    return blob


async def run_diagnosis_safe(sess) -> dict[str, Any] | None:
    """Non-fatal wrapper used by session auto-diagnosis hook."""
    try:
        return await run_diagnosis(sess)
    except Exception as e:
        logger.warning("auto-diagnosis failed: {}", e)
        if sess.recorder:
            sess.recorder.event("diag.failed", error=str(e))
        return None
