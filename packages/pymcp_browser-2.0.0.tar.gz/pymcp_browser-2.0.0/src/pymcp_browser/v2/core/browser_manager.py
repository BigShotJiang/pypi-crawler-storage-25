from __future__ import annotations
import asyncio
import json
from typing import Any
from loguru import logger

from ..control.errors import ToolError


VALID_ENGINES = ("chromium", "camoufox", "patchright")


class BrowserManager:
    """Async manager. One browser process per (engine, headless, proxy) tuple.
    BD/ProxyFog need proxy at launch (per-context broke for BD)."""

    _instance: "BrowserManager | None" = None
    _lock = asyncio.Lock()

    def __init__(self):
        self._pw_playwright: Any = None
        self._pw_patchright: Any = None
        self._browsers: dict[str, Any] = {}        # key -> browser
        self._camoufox_cms: dict[int, Any] = {}    # id(browser) -> AsyncCamoufox CM

    @classmethod
    async def get(cls) -> "BrowserManager":
        if cls._instance is None:
            async with cls._lock:
                if cls._instance is None:
                    cls._instance = cls()
        return cls._instance

    @staticmethod
    def _key(engine: str, headless: bool, proxy: dict | None) -> str:
        base = f"eng={engine}|hl={int(headless)}"
        if not proxy:
            return base + "|noproxy"
        return base + "|" + json.dumps(proxy, sort_keys=True)

    async def _ensure_playwright(self) -> None:
        if self._pw_playwright is None:
            from playwright.async_api import async_playwright
            self._pw_playwright = await async_playwright().start()

    async def _ensure_patchright(self) -> None:
        if self._pw_patchright is None:
            try:
                from patchright.async_api import async_playwright as pa
            except ImportError:
                raise ToolError(
                    "engine_install_missing",
                    "patchright not installed. Run: pip install patchright && patchright install chromium",
                )
            self._pw_patchright = await pa().start()

    async def get_browser(self, engine: str, headless: bool, proxy: dict | None,
                          camoufox_extras: dict | None = None) -> Any:
        if engine not in VALID_ENGINES:
            raise ToolError("invalid_args", f"unknown engine: {engine}")
        k = self._key(engine, headless, proxy)
        # Camoufox fingerprint affects launch — fold extras into cache key so
        # different fingerprints get distinct browser processes.
        if engine == "camoufox" and camoufox_extras:
            import json as _json
            k += "|cfx=" + _json.dumps(camoufox_extras, sort_keys=True, default=str)
        if k in self._browsers:
            return self._browsers[k]

        kwargs: dict = {"headless": headless}
        if proxy:
            kwargs["proxy"] = proxy

        if engine == "chromium":
            await self._ensure_playwright()
            br = await self._pw_playwright.chromium.launch(**kwargs)
        elif engine == "patchright":
            await self._ensure_patchright()
            br = await self._pw_patchright.chromium.launch(**kwargs)
        elif engine == "camoufox":
            try:
                from camoufox.async_api import AsyncCamoufox
            except ImportError:
                raise ToolError(
                    "engine_install_missing",
                    "camoufox not installed. Run: pip install 'camoufox[geoip]' && python -m camoufox fetch",
                )
            from ..config import settings
            cfx_kwargs: dict = dict(
                headless=headless,
                proxy=proxy,
                humanize=settings.camoufox_humanize,
                geoip=settings.camoufox_geoip,
            )
            if camoufox_extras:
                cfx_kwargs.update(camoufox_extras)
            cm = AsyncCamoufox(**cfx_kwargs)
            br = await cm.__aenter__()
            self._camoufox_cms[id(br)] = cm
        else:
            raise ToolError("invalid_args", f"unknown engine: {engine}")

        self._browsers[k] = br
        logger.info("engine={} launched headless={} proxy={}", engine, headless,
                    proxy["server"] if proxy else None)
        return br

    async def new_context(self, *, engine: str = "chromium", headless: bool = False,
                          proxy: dict | None = None,
                          camoufox_extras: dict | None = None, **ctx_kwargs):
        br = await self.get_browser(engine=engine, headless=headless, proxy=proxy,
                                    camoufox_extras=camoufox_extras)
        return await br.new_context(**ctx_kwargs)

    async def shutdown(self) -> None:
        for br in list(self._browsers.values()):
            cm = self._camoufox_cms.pop(id(br), None)
            if cm is not None:
                try:
                    await cm.__aexit__(None, None, None)
                except Exception:
                    pass
            else:
                try:
                    await br.close()
                except Exception:
                    pass
        self._browsers.clear()
        for pw in (self._pw_playwright, self._pw_patchright):
            if pw is not None:
                try:
                    await pw.stop()
                except Exception:
                    pass
        self._pw_playwright = None
        self._pw_patchright = None
