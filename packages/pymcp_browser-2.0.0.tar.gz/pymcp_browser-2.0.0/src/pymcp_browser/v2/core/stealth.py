"""Stealth init script builder.

Returns a JS blob to feed into Playwright's `context.add_init_script`. The
script patches navigator/screen properties, hides webdriver/CDP/automation
tells, and defends against iframe-escape detection.

Designed to pass:
- bot-detector.rebrowser.net  (navigatorWebdriver, runtimeEnableLeak, etc.)
- pixelscan.net/bot-check     (Languages, isDevtoolOpen, CDP)

Single source of truth — both macro_launcher.py and smoke tests import this.
"""
from __future__ import annotations


_STEALTH_JS = r"""
(() => {
  const PLATFORM = __PLATFORM__;
  const LANGS = Object.freeze(__LANGS__);
  const PRIMARY_LANG = __PRIMARY_LANG__;
  const HW = __HW__, MEM = __MEM__;
  const SW = __SW__, SH = __SH__, AH = __AH__, DPR = __DPR__;

  // ===== Helpers ============================================================
  const _toString = Function.prototype.toString;
  const _toStringMap = new WeakMap();
  function stripPrototype(fn) {
    try { delete fn.prototype; } catch (e) {}
    return fn;
  }

  // Method-shorthand wrappers are non-constructable (no [[Construct]]),
  // matching native built-ins. Function-keyword wrappers ARE constructable
  // and fail the rebrowser/Pixelscan `new fn()` test.
  const _ftpHolder = { toString() {
    if (_toStringMap.has(this)) return _toStringMap.get(this);
    return _toString.call(this);
  } };
  const _ftpToString = stripPrototype(_ftpHolder.toString);
  Function.prototype.toString = _ftpToString;
  _toStringMap.set(_ftpToString, "function toString() { [native code] }");

  function defineNative(obj, prop, getter) {
    const holder = { ["get " + prop]() { return getter.call(this); } };
    const named = stripPrototype(holder["get " + prop]);
    _toStringMap.set(named, "function get " + prop + "() { [native code] }");
    try {
      Object.defineProperty(obj, prop, {
        configurable: true, enumerable: true, get: named
      });
    } catch (e) {}
  }

  // ===== Strip instance own-props installed by Playwright/CDP ===============
  // Real Chrome: Object.getOwnPropertyNames(navigator) === [].
  // Playwright's context.locale + Emulation.setLocaleOverride install
  // language/languages directly on the navigator instance.
  ["language", "languages", "platform", "hardwareConcurrency",
   "deviceMemory", "userAgent", "appVersion", "vendor", "webdriver",
   "userAgentData", "appCodeName", "appName", "product", "productSub",
   "vendorSub"].forEach(function (p) {
    try { delete navigator[p]; } catch (e) {}
  });

  // ===== Navigator.prototype overrides ======================================
  const NP = Navigator.prototype;
  defineNative(NP, "platform", () => PLATFORM);
  defineNative(NP, "languages", () => LANGS);
  defineNative(NP, "language", () => PRIMARY_LANG);
  defineNative(NP, "hardwareConcurrency", () => HW);
  defineNative(NP, "deviceMemory", () => MEM);
  defineNative(NP, "webdriver", () => false);

  // ===== Screen / window dims =============================================
  // DON'T spoof screen.* — using real display values keeps consistency with
  // window.innerWidth/innerHeight. Spoofing screen smaller than the actual
  // viewport (impossible on real displays) is itself a strong bot signal.
  // Real Chrome lets the OS report screen and we don't need to fake it.
  // colorDepth/pixelDepth left native (always 24/24 in modern Chrome).

  // ===== navigator.userAgentData ============================================
  // Only stub if Chrome's native userAgentData is missing (UA-CH feature off).
  // Pixelscan inspects the prototype chain — a plain-object stub flags as fake.
  // Native NavigatorUAData has its own prototype which we can't fully fake.
  if (typeof navigator.userAgentData === "undefined") try {
    const _ua = navigator.userAgent || "";
    let osBrand = "Windows";
    if (PLATFORM === "MacIntel") osBrand = "macOS";
    else if (/Linux/i.test(PLATFORM)) osBrand = "Linux";
    const chromeMatch = _ua.match(/Chrome\/(\d+)/);
    const ver = chromeMatch ? chromeMatch[1] : "132";
    const brands = [
      { brand: "Not.A/Brand", version: "99" },
      { brand: "Google Chrome", version: ver },
      { brand: "Chromium", version: ver }
    ];
    const stub = {
      brands: brands,
      mobile: false,
      platform: osBrand,
      getHighEntropyValues(hints) {
        return Promise.resolve({
          architecture: "x86",
          bitness: "64",
          brands: brands,
          fullVersionList: brands.map(b =>
            ({ brand: b.brand, version: b.version + ".0.0.0" })),
          mobile: false,
          model: "",
          platform: osBrand,
          platformVersion: osBrand === "macOS" ? "10.15.7" :
                           osBrand === "Windows" ? "10.0.0" : "6.5.0",
          uaFullVersion: ver + ".0.0.0",
          wow64: false,
        });
      },
      toJSON() {
        return { brands: brands, mobile: false, platform: osBrand };
      }
    };
    stripPrototype(stub.getHighEntropyValues);
    stripPrototype(stub.toJSON);
    _toStringMap.set(stub.getHighEntropyValues,
                     "function getHighEntropyValues() { [native code] }");
    _toStringMap.set(stub.toJSON, "function toJSON() { [native code] }");
    Object.defineProperty(NP, "userAgentData",
      { configurable: true, enumerable: true, get: () => stub });
  } catch (e) {}

  // ===== Error.stack scrub (CDP detection) =================================
  const _stackDesc = Object.getOwnPropertyDescriptor(Error.prototype, "stack");
  if (!_stackDesc || _stackDesc.configurable !== false) {
    const stackHolder = {
      get() {
        let s = "";
        try { s = (this.message ? "Error: " + this.message + "\n" : "Error\n"); } catch (_) {}
        try {
          s = (this.__origStack || s).replace(
            /\n[^\n]*(puppeteer|playwright|chrome-devtools|cdp|debugger)[^\n]*/gi, ""
          );
        } catch (_) {}
        return s;
      },
      set(v) { this.__origStack = v; }
    };
    stripPrototype(stackHolder.get);
    stripPrototype(stackHolder.set);
    Object.defineProperty(Error.prototype, "stack", {
      configurable: true,
      get: stackHolder.get,
      set: stackHolder.set
    });
  }

  // ===== Console NOT wrapped =================================================
  // Wrapping console.log/debug/etc. changes their identity vs native — that's
  // a stronger bot signal than the getter-trap it tried to defend against. If
  // a target site uses the trap technique we'll handle it at app level.

  // ===== permissions.query alignment with Notification.permission ===========
  if (window.navigator && navigator.permissions && navigator.permissions.query) {
    const _origQuery = navigator.permissions.query.bind(navigator.permissions);
    const qHolder = { query(parameters) {
      if (parameters && parameters.name === "notifications") {
        try {
          const ns = (window.Notification && Notification.permission) || "default";
          return Promise.resolve({
            state: ns,
            status: ns,
            onchange: null,
            addEventListener: () => {},
            removeEventListener: () => {},
            dispatchEvent: () => false,
          });
        } catch (e) {}
      }
      return _origQuery(parameters);
    } };
    const qWrapped = stripPrototype(qHolder.query);
    navigator.permissions.query = qWrapped;
    _toStringMap.set(qWrapped, "function query() { [native code] }");
  }

  // ===== iframe escape defense ==============================================
  function patchIframeWindow(w) {
    try {
      if (!w || w.__pymcp_patched) return;
      w.__pymcp_patched = true;
      const _ift = w.Function.prototype.toString;
      const ifHolder = { toString() {
        if (_toStringMap.has(this)) return _toStringMap.get(this);
        return _ift.call(this);
      } };
      const ifPatch = stripPrototype(ifHolder.toString);
      w.Function.prototype.toString = ifPatch;
      _toStringMap.set(ifPatch, "function toString() { [native code] }");
    } catch (e) {}
  }
  try {
    const ifrs = document.getElementsByTagName("iframe");
    for (let i = 0; i < ifrs.length; i++) patchIframeWindow(ifrs[i].contentWindow);
  } catch (e) {}
  try {
    const mo = new MutationObserver(function (muts) {
      for (let m = 0; m < muts.length; m++) {
        const added = muts[m].addedNodes;
        for (let n = 0; n < added.length; n++) {
          const node = added[n];
          if (node && node.tagName === "IFRAME") {
            patchIframeWindow(node.contentWindow);
            try {
              node.addEventListener("load",
                function () { patchIframeWindow(node.contentWindow); });
            } catch (e) {}
          }
        }
      }
    });
    if (document.documentElement) {
      mo.observe(document.documentElement, { childList: true, subtree: true });
    } else {
      document.addEventListener("DOMContentLoaded", function () {
        mo.observe(document.documentElement, { childList: true, subtree: true });
      });
    }
  } catch (e) {}

  // ===== Phase 4 — identity-seeded fingerprint noise =======================
  // Canvas / WebGL / AudioContext / font hooks. Each takes a deterministic
  // seed so the same identity produces a stable fingerprint, but different
  // identities differ.
  function _mulberry32(seed) {
    // Tiny seeded PRNG, period 2^32. Deterministic per seed.
    return function () {
      seed = (seed + 0x6D2B79F5) | 0;
      let t = seed;
      t = Math.imul(t ^ (t >>> 15), t | 1);
      t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }

  // Canvas noise — patch toDataURL / toBlob / getImageData. After native
  // call, perturb a tiny fraction of pixels' alpha channel by ±1.
  const CANVAS_RNG = _mulberry32(__CANVAS_SEED__);
  if (CANVAS_RNG) try {
    const proto = HTMLCanvasElement.prototype;
    const _toDataURL = proto.toDataURL;
    const _toBlob = proto.toBlob;
    const dataUrlHolder = { toDataURL(...args) {
      try {
        const ctx = this.getContext("2d");
        if (ctx && this.width > 1 && this.height > 1) {
          const w = Math.min(this.width, 32), h = Math.min(this.height, 32);
          const img = ctx.getImageData(0, 0, w, h);
          for (let i = 3; i < img.data.length; i += 4) {
            if (CANVAS_RNG() < 0.02) {
              img.data[i] = Math.max(0, Math.min(255,
                img.data[i] + (CANVAS_RNG() < 0.5 ? -1 : 1)));
            }
          }
          ctx.putImageData(img, 0, 0);
        }
      } catch (e) {}
      return _toDataURL.apply(this, args);
    } };
    proto.toDataURL = stripPrototype(dataUrlHolder.toDataURL);
    _toStringMap.set(proto.toDataURL, "function toDataURL() { [native code] }");
    if (_toBlob) {
      const blobHolder = { toBlob(...args) { return _toBlob.apply(this, args); } };
      proto.toBlob = stripPrototype(blobHolder.toBlob);
      _toStringMap.set(proto.toBlob, "function toBlob() { [native code] }");
    }
  } catch (e) {}

  // WebGL noise — UNMASKED_VENDOR / UNMASKED_RENDERER seeded pick.
  const WEBGL_RNG = _mulberry32(__WEBGL_SEED__);
  const _GPU_POOL = [
    ["Google Inc. (Intel)", "ANGLE (Intel, Intel(R) UHD Graphics 630 Direct3D11 vs_5_0 ps_5_0, D3D11)"],
    ["Google Inc. (NVIDIA)", "ANGLE (NVIDIA, NVIDIA GeForce GTX 1660 Direct3D11 vs_5_0 ps_5_0, D3D11)"],
    ["Google Inc. (AMD)", "ANGLE (AMD, AMD Radeon RX 580 Direct3D11 vs_5_0 ps_5_0, D3D11)"],
    ["Google Inc. (Apple)", "ANGLE (Apple, ANGLE Metal Renderer: Apple M1, Unspecified Version)"],
    ["Intel Inc.", "Intel Iris OpenGL Engine"],
  ];
  if (WEBGL_RNG) try {
    const idx = Math.floor(WEBGL_RNG() * _GPU_POOL.length);
    const [vendor, renderer] = _GPU_POOL[idx];
    function patchGetParameter(P) {
      if (!P) return;
      const _orig = P.getParameter;
      const holder = { getParameter(p) {
        if (p === 37445) return vendor;          // UNMASKED_VENDOR_WEBGL
        if (p === 37446) return renderer;        // UNMASKED_RENDERER_WEBGL
        return _orig.call(this, p);
      } };
      P.getParameter = stripPrototype(holder.getParameter);
      _toStringMap.set(P.getParameter, "function getParameter() { [native code] }");
    }
    patchGetParameter(window.WebGLRenderingContext && WebGLRenderingContext.prototype);
    patchGetParameter(window.WebGL2RenderingContext && WebGL2RenderingContext.prototype);
  } catch (e) {}

  // Audio noise — patch AnalyserNode.prototype.getFloatFrequencyData.
  const AUDIO_RNG = _mulberry32(__AUDIO_SEED__);
  if (AUDIO_RNG && window.AnalyserNode) try {
    const _orig = AnalyserNode.prototype.getFloatFrequencyData;
    const holder = { getFloatFrequencyData(arr) {
      _orig.call(this, arr);
      for (let i = 0; i < arr.length; i++) {
        arr[i] += (AUDIO_RNG() - 0.5) * 0.0002;
      }
    } };
    AnalyserNode.prototype.getFloatFrequencyData = stripPrototype(holder.getFloatFrequencyData);
    _toStringMap.set(AnalyserNode.prototype.getFloatFrequencyData,
                     "function getFloatFrequencyData() { [native code] }");
  } catch (e) {}

  // Font enumeration — no robust browser API to limit this without breaking
  // legitimate font loading; we leave it native. (Document.fonts iterates
  // installed fonts; spoofing requires intercepting CSS @font-face checks.)

  // ===== chrome.runtime stub ===============================================
  if (!window.chrome) { window.chrome = {}; }
  if (!window.chrome.runtime) {
    window.chrome.runtime = {
      OnInstalledReason: { CHROME_UPDATE: "chrome_update", INSTALL: "install",
                           SHARED_MODULE_UPDATE: "shared_module_update", UPDATE: "update" },
      OnRestartRequiredReason: { APP_UPDATE: "app_update", OS_UPDATE: "os_update",
                                 PERIODIC: "periodic" },
      PlatformArch: { ARM: "arm", ARM64: "arm64", MIPS: "mips", MIPS64: "mips64",
                      X86_32: "x86-32", X86_64: "x86-64" },
      PlatformOs: { ANDROID: "android", CROS: "cros", LINUX: "linux", MAC: "mac",
                    OPENBSD: "openbsd", WIN: "win" },
      RequestUpdateCheckStatus: { NO_UPDATE: "no_update",
                                  THROTTLED: "throttled",
                                  UPDATE_AVAILABLE: "update_available" },
    };
  }
})();
"""


STEALTH_CHROMIUM_ARGS: list[str] = [
    "--disable-blink-features=AutomationControlled",
    "--disable-infobars",
    # Keep UA-CH (UserAgentClientHint) ENABLED — real Chrome has it. Disabling
    # makes navigator.userAgentData undefined which Pixelscan flags. Only kill
    # AutomationControlled feature.
    "--disable-features=AutomationControlled",
    # Prevent WebRTC from leaking the real (non-proxied) IP via STUN — without
    # this, even with HTTP proxy attached the browser's WebRTC stack uses local
    # UDP and exposes the host's true address.
    "--force-webrtc-ip-handling-policy=disable_non_proxied_udp",
]

STEALTH_IGNORE_DEFAULT_ARGS: list[str] = [
    "--enable-automation",
    "--enable-blink-features=IdleDetection",
]


def build_stealth_init_script(fp: dict) -> str:
    """Build init-script JS from a fingerprint dict.

    fp expected keys:
      platform (str), languages (list[str]), locale (str),
      viewport ({width,height}), device_scale_factor (float)
    Optional:
      hardware_concurrency (int, default 8), device_memory (int, default 8)
    """
    vp = fp.get("viewport") or {"width": 1920, "height": 1080}
    sw = int(vp.get("width", 1920))
    sh = int(vp.get("height", 1080))
    ah = max(sh - 40, sh - 80)
    platform = fp.get("platform", "Win32")
    langs = fp.get("languages") or [fp.get("locale", "en-US")]
    primary_lang = langs[0] if langs else "en-US"
    dpr = fp.get("device_scale_factor", 1.0)
    hw = fp.get("hardware_concurrency", 8)
    mem = fp.get("device_memory", 8)

    import json as _json
    canvas_seed = int(fp.get("canvas_noise_seed", 0)) or 1
    webgl_seed = int(fp.get("webgl_noise_seed", 0)) or 1
    audio_seed = int(fp.get("audio_noise_seed", 0)) or 1
    return (_STEALTH_JS
        .replace("__PLATFORM__", _json.dumps(platform))
        .replace("__LANGS__", _json.dumps(list(langs)))
        .replace("__PRIMARY_LANG__", _json.dumps(primary_lang))
        .replace("__HW__", str(int(hw)))
        .replace("__MEM__", str(int(mem)))
        .replace("__SW__", str(sw))
        .replace("__SH__", str(sh))
        .replace("__AH__", str(ah))
        .replace("__DPR__", str(float(dpr)))
        .replace("__CANVAS_SEED__", str(canvas_seed))
        .replace("__WEBGL_SEED__", str(webgl_seed))
        .replace("__AUDIO_SEED__", str(audio_seed)))
