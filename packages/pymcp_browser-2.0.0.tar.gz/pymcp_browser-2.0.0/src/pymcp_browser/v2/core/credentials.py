from __future__ import annotations
import json
from pathlib import Path
from ..control.errors import ToolError

_LOCAL_CACHE: dict | None = None
_LOCAL_PATH = Path("./data/credentials.json")


def _load_local() -> dict:
    global _LOCAL_CACHE
    if _LOCAL_CACHE is not None:
        return _LOCAL_CACHE
    if not _LOCAL_PATH.exists():
        _LOCAL_CACHE = {}
        return _LOCAL_CACHE
    try:
        _LOCAL_CACHE = json.loads(_LOCAL_PATH.read_text(encoding="utf-8"))
    except Exception:
        _LOCAL_CACHE = {}
    return _LOCAL_CACHE


def _resolve(key: str) -> object:
    """Read credentials from project-local data/credentials.json only."""
    local = _load_local()
    return local.get(key)


def get_brightdata(zone: str = "datacenter_proxy1") -> dict:
    bd = _resolve("brightdata") or {}
    if not bd:
        raise ToolError("invalid_args", "brightdata creds missing in data/credentials.json")
    if zone == "scraping_browser":
        wss = bd.get("puppeteer_playwright_wss")
        if not wss:
            raise ToolError("invalid_args", "brightdata scraping_browser wss missing")
        return {"kind": "wss", "wss": wss}
    z = bd.get("zones", {}).get(zone)
    if not z:
        raise ToolError("invalid_args", f"brightdata zone {zone} missing")
    host_port = z["proxy_host"]
    return {
        "kind": "http",
        "host_port": host_port,
        "username_base": z["username_template"],
        "password": z["password"],
        "customer": bd.get("customer"),
    }


def get_mail_password(label: str) -> str:
    mail = _resolve("mail") or {}
    creds = mail.get(label) if isinstance(mail, dict) else None
    if not creds or not creds.get("password"):
        raise ToolError(
            "mail_account_not_found",
            f"no password for label '{label}' in data/credentials.json",
            hint=f'Add: {{"mail": {{"{label}": {{"password": "<app-password>"}}}}}}',
        )
    return creds["password"]


def get_ipinfo_token() -> str | None:
    """Read ipinfo.io API token from data/credentials.json.

    Returns None when missing — diagnosis runs token-less (lower quota).
    """
    node = _resolve("ipinfo")
    if isinstance(node, str):
        return node or None
    if isinstance(node, dict):
        tok = node.get("token") or node.get("api_key")
        return tok or None
    return None


def get_proxyfog() -> dict:
    pf = _resolve("proxyfog")
    if not pf or not pf.get("host") or not pf.get("username"):
        raise ToolError("invalid_args",
                        "proxyfog credentials missing in data/credentials.json")
    sticky = pf.get("modes", {}).get("sticky", {}).get("endpoint_template")
    return {
        "host": pf["host"],
        "port": int(pf.get("port", 8443)),
        "username_base": pf["username"],
        "password": pf["password"],
        "sticky_template": sticky or "{username_base}-session-{sid}-ttl-{ttl}",
    }
