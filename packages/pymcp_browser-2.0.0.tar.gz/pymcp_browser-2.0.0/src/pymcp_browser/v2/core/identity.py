"""Phase 2 — Per-iteration browser identity generator.

Drives Run Unique Identities. Single Identity dataclass holds every knob the
launcher consumes:

- Pre-launch (set into ctx_kwargs / Chromium args / fingerprint dict)
- Post-launch overridden by proxy probe (locale/tz/languages/geolocation)

generate_identity(seed=None) — fully-random identity. Same seed => deterministic.

identity_to_fp(ident) — flatten to fp dict consumable by build_stealth_init_script.

identity_proxy_session_tag(ident) — short stable string for ProxyFog sticky session.
"""
from __future__ import annotations
import hashlib
import json
import random
import uuid
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Any


# Hardcoded viewport pool — real-display sizes only (no random combos)
VIEWPORT_POOL: list[tuple[int, int]] = [
    (1366, 768),
    (1440, 900),
    (1536, 864),
    (1600, 900),
    (1920, 1080),
    (2560, 1440),
    (1280, 800),
    (1680, 1050),
]

DPR_POOL: list[float] = [1.0, 1.0, 1.0, 1.25, 1.5, 2.0]
COLOR_SCHEME_POOL: list[str] = ["light", "dark"]
HW_CONCURRENCY_POOL: list[int] = [4, 6, 8, 8, 12, 16]
DEVICE_MEMORY_POOL: list[int] = [4, 8, 8, 16]


# UA-pool platform → navigator.platform mapping
_PLATFORM_FOR_OS: dict[str, str] = {
    "windows": "Win32",
    "macos": "MacIntel",
    "linux": "Linux x86_64",
}


_UA_POOL_CACHE: dict[str, dict[str, list[str]]] = {}

# Default engine for new code. Camoufox (Firefox-based) is the project's
# stealth engine, so Firefox UAs match the runtime JS environment.
DEFAULT_UA_ENGINE = "firefox"

_ENGINE_TO_FILENAME = {
    "firefox": "ua_pool_firefox.json",
    "chromium": "ua_pool.json",   # legacy Chrome pool
    "chrome": "ua_pool.json",
}

_FALLBACK_UA = {
    "firefox": {
        "windows": ["Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:138.0) "
                    "Gecko/20100101 Firefox/138.0"],
        "macos": ["Mozilla/5.0 (Macintosh; Intel Mac OS X 14.5; rv:138.0) "
                  "Gecko/20100101 Firefox/138.0"],
        "linux": ["Mozilla/5.0 (X11; Linux x86_64; rv:138.0) "
                  "Gecko/20100101 Firefox/138.0"],
    },
    "chromium": {
        "windows": ["Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                    "(KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36"],
        "macos": ["Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 "
                  "(KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36"],
        "linux": ["Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 "
                  "(KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36"],
    },
}


def _load_ua_pool(engine: str | None = None,
                  path: Path | None = None) -> dict[str, list[str]]:
    """Load UA pool. Per-engine cached.

    `path` explicit override; otherwise picks `data/ua_pool_<engine>.json`,
    falling back to `data/ua_pool.json` for the legacy chromium case.
    """
    eng = (engine or DEFAULT_UA_ENGINE).lower()
    cache_key = str(path) if path else eng
    if cache_key in _UA_POOL_CACHE:
        return _UA_POOL_CACHE[cache_key]
    if path is None:
        filename = _ENGINE_TO_FILENAME.get(eng, _ENGINE_TO_FILENAME[DEFAULT_UA_ENGINE])
        path = Path("./data") / filename
    if not path.exists():
        # minimal fallback so the function never fails
        _UA_POOL_CACHE[cache_key] = _FALLBACK_UA.get(
            eng, _FALLBACK_UA[DEFAULT_UA_ENGINE]).copy()
        return _UA_POOL_CACHE[cache_key]
    try:
        raw = json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        _UA_POOL_CACHE[cache_key] = {}
        return _UA_POOL_CACHE[cache_key]
    _UA_POOL_CACHE[cache_key] = {k: v for k, v in raw.items()
                                  if k in _PLATFORM_FOR_OS and isinstance(v, list)}
    return _UA_POOL_CACHE[cache_key]


@dataclass
class Identity:
    """Per-run browser identity. Same seed → deterministic. Different seeds differ."""
    seed: str

    # Pre-launch fields
    user_agent: str = ""
    platform: str = "Win32"        # navigator.platform
    os_family: str = "windows"     # internal — drives userAgentData stub
    viewport: dict = field(default_factory=lambda: {"width": 1920, "height": 1080})
    device_scale_factor: float = 1.0
    color_scheme: str = "light"
    hw_concurrency: int = 8
    device_memory: int = 8

    # Post-launch (filled by proxy probe — defaults are en-US fallback)
    locale: str = "en-US"
    timezone: str = "America/New_York"
    languages: list[str] = field(default_factory=lambda: ["en-US", "en"])

    # Phase 4 noise seeds
    canvas_noise_seed: int = 0
    webgl_noise_seed: int = 0
    audio_noise_seed: int = 0

    def to_dict(self) -> dict:
        return asdict(self)


def generate_identity(seed: str | None = None,
                      ua_pool_path: Path | None = None,
                      engine: str | None = None) -> Identity:
    """Generate a fully-random Identity. Same seed → same Identity.

    Uses an isolated random.Random instance keyed by the seed so global RNG
    isn't disturbed.

    `engine` selects which UA pool file to draw from
    (`firefox` → Camoufox-compatible, `chromium` → Chrome). Default firefox.
    """
    if seed is None:
        seed = uuid.uuid4().hex
    rng = random.Random(_seed_to_int(seed))
    pool = _load_ua_pool(engine=engine, path=ua_pool_path)
    os_family = rng.choice([k for k in pool.keys() if pool[k]])
    ua = rng.choice(pool[os_family])
    width, height = rng.choice(VIEWPORT_POOL)

    return Identity(
        seed=seed,
        user_agent=ua,
        platform=_PLATFORM_FOR_OS[os_family],
        os_family=os_family,
        viewport={"width": width, "height": height},
        device_scale_factor=rng.choice(DPR_POOL),
        color_scheme=rng.choice(COLOR_SCHEME_POOL),
        hw_concurrency=rng.choice(HW_CONCURRENCY_POOL),
        device_memory=rng.choice(DEVICE_MEMORY_POOL),
        canvas_noise_seed=rng.randint(0, 2**31 - 1),
        webgl_noise_seed=rng.randint(0, 2**31 - 1),
        audio_noise_seed=rng.randint(0, 2**31 - 1),
    )


def identity_to_fp(ident: Identity) -> dict:
    """Flatten Identity into the fp dict accepted by build_stealth_init_script."""
    return {
        "user_agent": ident.user_agent,
        "platform": ident.platform,
        "viewport": dict(ident.viewport),
        "device_scale_factor": ident.device_scale_factor,
        "color_scheme": ident.color_scheme,
        "hardware_concurrency": ident.hw_concurrency,
        "device_memory": ident.device_memory,
        "locale": ident.locale,
        "languages": list(ident.languages),
        # Phase 4 noise seeds (consumed when canvas/webgl/audio hooks land)
        "canvas_noise_seed": ident.canvas_noise_seed,
        "webgl_noise_seed": ident.webgl_noise_seed,
        "audio_noise_seed": ident.audio_noise_seed,
    }


def identity_proxy_session_tag(ident: Identity) -> str:
    """Short stable identifier for ProxyFog sticky session-tag derivation.

    First 8 hex chars of the identity seed — small enough to fit in PF's
    session-tag conventions, stable per identity.
    """
    return ident.seed[:8] if ident.seed else uuid.uuid4().hex[:8]


def save_identity_audit(ident: Identity, run_id: str, ok: bool,
                        base_dir: Path | None = None) -> Path:
    """Append an audit JSON row under data/identities/<seed>.json.

    Each call appends one event ({run_id, ok, ts}) to a per-identity log so
    warm-account workflows can reuse a known-good identity later.
    """
    import time as _time
    base = base_dir or Path("./data/identities")
    base.mkdir(parents=True, exist_ok=True)
    path = base / f"{ident.seed}.json"
    blob = {"identity": ident.to_dict(), "runs": []}
    if path.exists():
        try:
            blob = json.loads(path.read_text(encoding="utf-8"))
        except Exception:
            pass
    blob.setdefault("runs", []).append({
        "run_id": run_id,
        "ok": ok,
        "ts": _time.time(),
    })
    blob["identity"] = ident.to_dict()
    path.write_text(json.dumps(blob, indent=2), encoding="utf-8")
    return path


def make_profile_dir(run_id: str, iteration: int,
                     base_dir: Path | None = None) -> Path:
    """Allocate `data/profiles/<run_id>_<iter>/` for an identity-rotation iter.

    Caller passes the path to engine.start(profile_dir=...). Wipe after use
    unless keep_profiles flag is set.
    """
    base = base_dir or Path("./data/profiles")
    base.mkdir(parents=True, exist_ok=True)
    safe_run = "".join(c for c in run_id if c.isalnum() or c in "_-")[:24] or "run"
    p = base / f"{safe_run}_{iteration:03d}"
    p.mkdir(parents=True, exist_ok=True)
    return p


def gc_old_profiles(base_dir: Path | None = None, keep: int = 5) -> int:
    """Delete oldest profile dirs, keep `keep` most recently modified.

    Returns count removed. Safe to call repeatedly. Skips on permission error.
    """
    import shutil
    base = base_dir or Path("./data/profiles")
    if not base.exists():
        return 0
    dirs = sorted([p for p in base.iterdir() if p.is_dir()],
                  key=lambda p: p.stat().st_mtime, reverse=True)
    to_delete = dirs[keep:]
    n = 0
    for p in to_delete:
        try:
            shutil.rmtree(p, ignore_errors=True)
            n += 1
        except Exception:
            pass
    return n


SAVED_IDENTITY_DIR = Path("./data/identities/saved")


def save_identity(ident: Identity, label: str,
                  base_dir: Path | None = None) -> Path:
    """Pin an identity by label so it can be reused later (warm accounts).

    `data/identities/saved/<label>.json`.
    """
    base = base_dir or SAVED_IDENTITY_DIR
    base.mkdir(parents=True, exist_ok=True)
    safe = "".join(c for c in label if c.isalnum() or c in "_-")[:40] or "id"
    p = base / f"{safe}.json"
    p.write_text(json.dumps(ident.to_dict(), indent=2), encoding="utf-8")
    return p


def load_identity(label: str,
                  base_dir: Path | None = None) -> Identity | None:
    base = base_dir or SAVED_IDENTITY_DIR
    safe = "".join(c for c in label if c.isalnum() or c in "_-")[:40] or "id"
    p = base / f"{safe}.json"
    if not p.exists():
        return None
    try:
        d = json.loads(p.read_text(encoding="utf-8"))
        return Identity(**d)
    except Exception:
        return None


def list_saved_identities(base_dir: Path | None = None) -> list[str]:
    base = base_dir or SAVED_IDENTITY_DIR
    if not base.exists():
        return []
    return sorted(p.stem for p in base.glob("*.json") if p.is_file())


def _seed_to_int(seed: str) -> int:
    """Stable hash → int for random.Random(seed)."""
    h = hashlib.sha256(seed.encode("utf-8")).hexdigest()
    return int(h[:16], 16)


# ───────────────────────────────────────────────────────────────────────
# v2 — extended identity (aged-profile experiment, see
# Tasks/Google_Ads_Scan/gui-v2/docs/identity-tryout.md)
# ───────────────────────────────────────────────────────────────────────

IDENTITY_V2_DIR = Path("./data/identities/v2")
PERSISTENT_PROFILE_DIR = Path("./data/profiles/persistent")


@dataclass
class IdentityExt:
    """v2 metadata that wraps the legacy Identity dataclass."""
    schema_version: int = 2
    label: str = ""
    created_at: str = ""
    notes: str = ""
    proxy: dict = field(default_factory=dict)
    persona: dict = field(default_factory=dict)
    profile: dict = field(default_factory=dict)
    cookies: dict = field(default_factory=lambda: {"allow_keys": [], "harvested": []})
    extensions: list = field(default_factory=list)
    quota: dict = field(default_factory=dict)
    state: dict = field(default_factory=lambda: {
        "last_used_at": None,
        "total_iterations": 0,
        "captcha_hits": 0,
        "soft_blocks": 0,
        "status": "fresh",
    })

    def to_dict(self) -> dict:
        return asdict(self)


# Fields that live on the legacy `Identity` dataclass. Used to split a v2
# JSON blob between core (Identity) and ext (IdentityExt).
_IDENTITY_CORE_FIELDS = frozenset(
    f for f in Identity.__dataclass_fields__.keys()  # type: ignore[attr-defined]
)


def load_identity_v2(path: Path | str) -> tuple[Identity, IdentityExt]:
    """Parse a v2 identity JSON file → (Identity, IdentityExt).

    Tolerant of legacy v1 files (returns IdentityExt with defaults). The
    legacy `load_identity()` does NOT accept v2 files because the dataclass
    rejects unknown kwargs.
    """
    p = Path(path)
    d = json.loads(p.read_text(encoding="utf-8"))
    core = {k: v for k, v in d.items() if k in _IDENTITY_CORE_FIELDS}
    if "seed" not in core:
        core["seed"] = p.stem  # filename stem is the canonical seed
    ident = Identity(**core)
    ext = IdentityExt(
        schema_version=int(d.get("_schema_version", 1)),
        label=d.get("label", p.stem),
        created_at=d.get("created_at", ""),
        notes=d.get("notes", ""),
        proxy=d.get("proxy", {}),
        persona=d.get("persona", {}),
        profile=d.get("profile", {}),
        cookies=d.get("cookies", {"allow_keys": [], "harvested": []}),
        extensions=d.get("extensions", []),
        quota=d.get("quota", {}),
        state=d.get("state", {
            "last_used_at": None,
            "total_iterations": 0,
            "captcha_hits": 0,
            "soft_blocks": 0,
            "status": "fresh",
        }),
    )
    return ident, ext


def save_identity_v2(ident: Identity, ext: IdentityExt,
                     path: Path | str) -> Path:
    """Write a v2 identity JSON, atomically (temp-file + os.replace).

    Multiple workers updating `state` concurrently cannot half-write the
    file. Caller is still responsible for serialising read-modify-write
    races (use a filelock or an in-memory mutex per identity).
    """
    import os as _os
    import tempfile as _tempfile

    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    blob = {
        "_schema_version": ext.schema_version,
        "seed": ident.seed,
        "label": ext.label or ident.seed,
        "created_at": ext.created_at,
        "notes": ext.notes,
        **ident.to_dict(),
        "proxy": ext.proxy,
        "persona": ext.persona,
        "profile": ext.profile,
        "cookies": ext.cookies,
        "extensions": ext.extensions,
        "quota": ext.quota,
        "state": ext.state,
    }
    # `seed` appears twice in the dict comprehension above — Identity.to_dict
    # includes it, and we set it first. Keep one. Python dicts dedupe by last
    # write so this is harmless, but be explicit:
    blob["seed"] = ident.seed

    fd, tmp_path = _tempfile.mkstemp(prefix=p.stem + ".",
                                      suffix=".tmp", dir=str(p.parent))
    try:
        with _os.fdopen(fd, "w", encoding="utf-8") as fh:
            json.dump(blob, fh, indent=2, ensure_ascii=False)
        _os.replace(tmp_path, p)
    except Exception:
        try:
            _os.unlink(tmp_path)
        except OSError:
            pass
        raise
    return p


def list_identities_v2(base_dir: Path | None = None) -> list[Path]:
    """Return all v2 identity files (skipping README and underscore-prefixed)."""
    base = base_dir or IDENTITY_V2_DIR
    if not base.exists():
        return []
    return sorted(p for p in base.glob("*.json")
                  if not p.name.startswith("_"))


def pick_identity_v2(now_ts: float | None = None,
                     base_dir: Path | None = None) -> tuple[Path, Identity, IdentityExt] | None:
    """Round-robin picker honouring cool-down + daily quota + retirement.

    Returns the first eligible identity, or None if all are on cool-down.
    Caller must call `save_identity_v2()` afterwards to bump state.
    """
    import time as _time
    now = now_ts if now_ts is not None else _time.time()
    candidates: list[tuple[Path, Identity, IdentityExt]] = []
    for p in list_identities_v2(base_dir):
        try:
            ident, ext = load_identity_v2(p)
        except Exception:
            continue
        if ext.state.get("status") == "retired":
            continue
        # Retirement triggers
        total = int(ext.state.get("total_iterations", 0))
        cap_total = int(ext.quota.get("retire_after_total_iterations", 10**9))
        cap_caps = int(ext.quota.get("retire_after_captcha_hits", 10**9))
        caps = int(ext.state.get("captcha_hits", 0))
        if total >= cap_total or caps >= cap_caps:
            continue
        # Cool-down
        cd_h = float(ext.quota.get("cooldown_hours_between_runs", 0.0))
        last = ext.state.get("last_used_at")
        if last and cd_h > 0:
            try:
                from datetime import datetime as _dt
                last_ts = _dt.fromisoformat(last.replace("Z", "+00:00")).timestamp()
            except Exception:
                last_ts = 0.0
            if (now - last_ts) < cd_h * 3600:
                continue
        candidates.append((p, ident, ext))
    if not candidates:
        return None
    # Prefer the one least-recently-used (stable rotation).
    def _last_key(t):
        _, _, e = t
        v = e.state.get("last_used_at") or ""
        return v
    candidates.sort(key=_last_key)
    return candidates[0]
