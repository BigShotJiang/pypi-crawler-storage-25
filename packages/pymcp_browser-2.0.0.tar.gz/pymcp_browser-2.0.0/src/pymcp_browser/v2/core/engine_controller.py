"""Per-session MacroEngine — shared across launchers (multi-launcher Tk + new pywebview app).

Callback-driven (log/event/status). Owns Playwright loop in worker thread.
Per-session WS port and per-session extension dir. Graceful stop with 8s
timeout + force-kill fallback. Captcha solves rate-limited per session.
"""
from __future__ import annotations

import asyncio
import copy
import json
import os
import queue
import shutil
import signal
import tempfile
import threading
import time
import uuid
from pathlib import Path
from typing import Callable

from pymcp_browser.v2.config import settings
from pymcp_browser.v2.core.macro import MacroRecorder, macro_ctl_dispatch
from pymcp_browser.v2.control.registry import TASK_REGISTRY
from pymcp_browser.v2.core.session import SessionRegistry
from pymcp_browser.v2.core.macro_mail import fetch_otp, fetch_verify_url
from pymcp_browser.v2.control.tools.captcha import captcha_auto as _captcha_auto
from pymcp_browser.v2.core.captcha.detector import detect_captcha as _detect_captcha


CAPTCHA_COOLDOWN_S = float(os.environ.get("MACRO_CAPTCHA_COOLDOWN_S", "30"))


class _Sess:
    """Sess-like shim. Stored in SessionRegistry so compiled macro tasks can
    resolve it via SessionRegistry.lookup(sid)."""
    def __init__(self, sid: str):
        self.id = sid
        self.macro: MacroRecorder | None = None
        self.pages: list = []
        self.closed: bool = False
        self.kind: str = "browser"
        self.lock = asyncio.Lock()
        self.tasks: dict = {}
        self.events = None
        self.recorder = None

    def active_page(self):
        return self.pages[-1] if self.pages else None

    def touch(self):
        pass


class MacroEngine:
    """One session: own thread, own asyncio loop, own browser, own WS port."""

    def __init__(self, *, sid: str, ws_port: int, extension_dir: Path,
                 log_callback: Callable[[str], None],
                 event_callback: Callable[[dict], None],
                 status_callback: Callable[[dict], None]):
        self.sid = sid
        self.ws_port = int(ws_port)
        self.extension_dir = Path(extension_dir)
        self._log_cb = log_callback
        self._event_cb = event_callback
        self._status_cb = status_callback

        self.loop: asyncio.AbstractEventLoop | None = None
        self.thread: threading.Thread | None = None
        self.sess: _Sess | None = None
        self.browser = None
        self.context = None
        self.page = None
        self._stop_evt: asyncio.Event | None = None
        self._closed = False

        # template snapshot
        self.imap_email: str | None = None
        self.imap_pass: str | None = None
        self.captcha_action: str = "signup"
        self.fingerprint: dict = {}
        self.template: dict = {}

        # state
        self._state: str = "idle"
        self._event_count: int = 0
        self._last_activity: float = time.time()
        self._last_captcha_ok_ts: float = 0.0
        self.user_data_dir: Path | None = None

    # ----- public state getters -------------------------------------------

    def current_state(self) -> str:
        rec = self.sess.macro if self.sess else None
        if rec is not None and rec.status not in ("idle",):
            return rec.status
        return self._state

    def event_count(self) -> int:
        return self._event_count

    def last_activity(self) -> float:
        return self._last_activity

    # ----- internal log / status helpers ----------------------------------

    def _log(self, line: str):
        try:
            self._log_cb(line)
        except Exception:
            pass

    def _emit_status(self, st: dict):
        if "state" in st:
            self._state = st["state"]
        try:
            self._status_cb(st)
        except Exception:
            pass

    def _emit_event(self, ev: dict):
        self._event_count += 1
        self._last_activity = time.time()
        try:
            self._event_cb(ev)
        except Exception:
            pass

    # ----- lifecycle ------------------------------------------------------

    def start(self, template: dict):
        if self.thread and self.thread.is_alive():
            self._log("engine already running")
            return
        self.template = copy.deepcopy(template or {})
        self.imap_email = (self.template.get("imap_email") or "").strip() or None
        self.imap_pass = self.template.get("imap_pass") or None
        self.captcha_action = self.template.get("captcha_action") or "signup"
        self.fingerprint = self.template.get("fingerprint") or {}
        self.thread = threading.Thread(target=self._run_loop, daemon=True)
        self.thread.start()

    def stop(self, timeout_s: float = 8.0):
        """Graceful stop, falls back to force-kill after timeout_s."""
        if self._closed:
            return
        if self.loop and self._stop_evt:
            try:
                self.loop.call_soon_threadsafe(self._stop_evt.set)
            except Exception:
                pass
        if self.thread:
            self.thread.join(timeout=timeout_s)
            if self.thread.is_alive():
                self._log(f"force-kill applied (graceful stop timed out after {timeout_s}s)")
                self._force_kill()
        self._closed = True

    def _force_kill(self):
        """Last-resort: terminate the Chromium subprocess + remove SessionRegistry entry."""
        try:
            if self.browser is not None:
                proc = getattr(self.browser, "process", lambda: None)()
                if proc is not None:
                    try:
                        proc.kill()
                    except Exception:
                        try:
                            os.kill(proc.pid, signal.SIGTERM)
                        except Exception:
                            pass
        except Exception as e:
            self._log(f"force_kill err: {e}")
        try:
            SessionRegistry.get()._sessions.pop(self.sid, None)
        except Exception:
            pass
        try:
            if self.user_data_dir and self.user_data_dir.exists():
                shutil.rmtree(self.user_data_dir, ignore_errors=True)
        except Exception:
            pass

    def run_macro(self, task_name: str, strict: bool = False):
        if not self.loop or not self.sess:
            self._log("engine not running")
            return
        task = TASK_REGISTRY.get(task_name)
        if task is None:
            self._log(f"task not found: {task_name}")
            return
        sid = self.sess.id

        async def _runner():
            self._log(f"REPLAY START: {task_name} sid={sid} strict={strict}")
            try:
                result = await task.handler(
                    session_id=sid, strict=strict,
                    imap_email=self.imap_email, imap_pass=self.imap_pass)
                self._log(f"REPLAY OK: {result}")
            except TypeError:
                result = await task.handler(session_id=sid, strict=strict)
                self._log(f"REPLAY OK (legacy): {result}")
            except Exception as e:
                self._log(f"REPLAY FAIL: {type(e).__name__}: {e}")

        asyncio.run_coroutine_threadsafe(_runner(), self.loop)

    def run_macro_sync(self, task_name: str, *, timeout_s: float = 600.0,
                       **kwargs) -> dict:
        """Block until replay finishes; returns result dict.

        Used by multi_launcher_app's run_on_selected. Wraps run_macro with
        CSV logger, MacroRun persistence, and a threading.Event for sync.

        Optional kwargs: clean, speed, strict, csv_logging (bool),
        identity (Identity), loop_count, iteration.
        """
        from pymcp_browser.v2.core.csv_log import open_run_logger

        done = threading.Event()
        result_holder: dict = {"result": None, "error": None}

        if not self.loop or not self.sess:
            return {"ok": False, "error": "engine not running"}
        task = TASK_REGISTRY.get(task_name)
        if task is None:
            return {"ok": False, "error": f"task not found: {task_name}"}
        sid = self.sess.id

        csv_enabled = bool(kwargs.pop("csv_logging", False))
        identity = kwargs.pop("identity", None)
        loop_count = int(kwargs.pop("loop_count", 1))
        iteration = int(kwargs.pop("iteration", 1))

        async def _runner():
            logger = open_run_logger(
                enabled=csv_enabled,
                macro_name=task_name,
                identity_seed=getattr(identity, "seed", None) if identity else None,
                clean_mode=kwargs.get("clean", True),
                unique_mode=identity is not None,
                loop_count=loop_count,
                iteration=iteration,
            )
            run_ok = True
            run_err = ""
            call_kwargs = dict(
                session_id=sid, strict=kwargs.get("strict", False),
                imap_email=self.imap_email, imap_pass=self.imap_pass,
                csv_logger=logger, identity=identity, **kwargs)
            self._log(f"REPLAY iter sid={sid} ident="
                      f"{getattr(identity, 'seed', '-')[:8] if identity else '-'}")
            try:
                result = await task.handler(**call_kwargs)
                result_holder["result"] = result
                run_ok = bool(result.get("ok", True)) if isinstance(result, dict) else True
            except TypeError as te:
                self._log(f"run_macro_sync TypeError: {te}; legacy retry")
                legacy = {k: v for k, v in call_kwargs.items()
                          if k in ("session_id", "strict",
                                   "imap_email", "imap_pass")}
                try:
                    result = await task.handler(**legacy)
                    result_holder["result"] = result
                except Exception as e2:
                    run_ok = False
                    run_err = type(e2).__name__
                    result_holder["error"] = str(e2)
            except Exception as e:
                run_ok = False
                run_err = type(e).__name__
                result_holder["error"] = str(e)
            try:
                logger.finalize(ok=run_ok, error_class=run_err)
            except Exception:
                pass
            # Persist MacroRun row
            try:
                from pymcp_browser.v2.storage.db import session_scope as _db_scope
                from pymcp_browser.v2.storage.models import MacroRun as _MR
                import uuid as _uuid
                rid = (getattr(logger, "run_id", None)
                       or getattr(identity, "seed", None)
                       or _uuid.uuid4().hex)
                dur_ms = 0
                if isinstance(result_holder["result"], dict):
                    dur_ms = int(result_holder["result"].get("duration_ms", 0))
                row = _MR(
                    id=rid,
                    macro_name=task_name,
                    identity_seed=getattr(identity, "seed", None) if identity else None,
                    clean_mode=bool(kwargs.get("clean", True)),
                    unique_mode=bool(identity is not None),
                    csv_logging=bool(csv_enabled),
                    loop_count=loop_count,
                    iteration=iteration,
                    started_ts=time.time() - (dur_ms / 1000),
                    duration_ms=dur_ms,
                    ok=run_ok,
                    error_class=run_err or None,
                    error_msg=result_holder.get("error"),
                )
                with _db_scope() as db:
                    db.add(row)
            except Exception as e:
                self._log(f"MacroRun persist failed: {e}")
            done.set()

        asyncio.run_coroutine_threadsafe(_runner(), self.loop)
        if not done.wait(timeout=timeout_s):
            return {"ok": False, "error": "timeout"}
        if result_holder["error"]:
            return {"ok": False, "error": result_holder["error"]}
        return result_holder["result"] or {"ok": True}

    # ----- worker thread --------------------------------------------------

    def _run_loop(self):
        try:
            asyncio.run(self._main())
        except Exception as e:
            self._log(f"engine crash: {e}")
        finally:
            self._emit_status({"state": "stopped"})
            try:
                if self.user_data_dir and self.user_data_dir.exists():
                    shutil.rmtree(self.user_data_dir, ignore_errors=True)
            except Exception:
                pass

    async def _main(self):
        from playwright.async_api import async_playwright
        import websockets

        self.loop = asyncio.get_event_loop()
        self._stop_evt = asyncio.Event()

        self.sess = _Sess(self.sid)
        self.sess.macro = MacroRecorder(self.sid, Path(settings.macros_dir))
        self.ws_clients: set = set()

        self._emit_status({"state": "launching", "sid": self.sid, "port": self.ws_port})

        async def _ws_handle_msg(msg: dict, ws):
            t = msg.get("type")
            if t == "hello":
                self._log(f"ws client connected (top={msg.get('top')}, url={msg.get('url')})")
                return
            if t == "event":
                rec = self.sess.macro
                if rec:
                    rec.ingest(msg.get("payload") or {})
                    ev = msg.get("payload") or {}
                    self._emit_event(ev)
                    self._emit_status({
                        "state": rec.status, "count": rec.seq, "sid": self.sid,
                        "out": str(rec.out_path) if rec.out_path else None})
                    await self._broadcast({"type": "status", "status": rec.status, "count": rec.seq})
                return
            if t == "req":
                action = msg.get("action")
                payload = msg.get("payload") or {}
                rid = msg.get("id")
                data = await self._dispatch_request(action, payload, self.sid)
                try:
                    await ws.send(json.dumps({"type": "resp", "id": rid, "data": data}))
                except Exception:
                    pass
                return

        async def _ws_handler(ws):
            self.ws_clients.add(ws)
            try:
                async for raw in ws:
                    try:
                        msg = json.loads(raw)
                    except Exception:
                        continue
                    try:
                        await _ws_handle_msg(msg, ws)
                    except Exception as e:
                        self._log(f"ws handler err: {e}")
            finally:
                self.ws_clients.discard(ws)

        self._dispatch_request = self._make_dispatcher(self.sid)
        self._broadcast = self._make_broadcaster()

        try:
            ws_server = await websockets.serve(_ws_handler, "127.0.0.1", self.ws_port)
            self._log(f"ws server listening on ws://127.0.0.1:{self.ws_port}")
        except Exception as e:
            self._log(f"ws bind failed (port {self.ws_port}): {e}")
            return

        ext_path = self.extension_dir.resolve()
        if not (ext_path / "manifest.json").exists():
            self._log(f"extension not found at {ext_path}")
            ws_server.close()
            return

        self.user_data_dir = Path(tempfile.mkdtemp(prefix=f"pymcp_macro_profile_{self.ws_port}_"))

        # Window position derived from session port offset for tiling
        win_idx = max(0, self.ws_port - 47833)
        win_x = (win_idx % 4) * 400
        win_y = (win_idx // 4) * 300

        async with async_playwright() as pw:
            ctx_kwargs: dict = {
                "viewport": None,
                "no_viewport": True,
                "headless": False,
                "args": [
                    f"--disable-extensions-except={ext_path}",
                    f"--load-extension={ext_path}",
                    "--proxy-bypass-list=<-loopback>;127.0.0.1;localhost;[::1]",
                    "--start-maximized",
                    "--disable-features=OverlayScrollbar",
                    f"--window-position={win_x},{win_y}",
                ],
            }

            proxy = self.template.get("proxy")
            if proxy:
                proxy = dict(proxy)
                existing = proxy.get("bypass") or ""
                bypass_parts = [p.strip() for p in existing.split(",") if p.strip()]
                for needed in ("127.0.0.1", "localhost", "*.local"):
                    if needed not in bypass_parts:
                        bypass_parts.append(needed)
                proxy["bypass"] = ", ".join(bypass_parts)
                ctx_kwargs["proxy"] = proxy
                self._log(f"proxy: {proxy.get('server')} (bypass: {proxy['bypass']})")

            mode = self.template.get("mode") or "stealth"
            if mode == "human":
                ctx_kwargs["slow_mo"] = 250
            elif mode == "stealth":
                ctx_kwargs["slow_mo"] = 50

            fp = self.fingerprint or {}
            if fp:
                if fp.get("user_agent"):
                    ctx_kwargs["user_agent"] = fp["user_agent"]
                if fp.get("locale"):
                    ctx_kwargs["locale"] = fp["locale"]
                if fp.get("timezone_id"):
                    ctx_kwargs["timezone_id"] = fp["timezone_id"]
                if fp.get("color_scheme"):
                    ctx_kwargs["color_scheme"] = fp["color_scheme"]
                self._log(f"fingerprint: {fp.get('label', '?')}")

            try:
                self.context = await pw.chromium.launch_persistent_context(
                    str(self.user_data_dir), **ctx_kwargs)
            except Exception as e:
                self._log(f"persistent context launch failed: {e}")
                ws_server.close()
                return

            self.browser = self.context.browser

            if fp:
                vp = fp.get("viewport") or {"width": 1920, "height": 1080}
                sw, sh = int(vp.get("width", 1920)), int(vp.get("height", 1080))
                ah = max(sh - 40, sh - 80)
                spoof_js = (
                    "(() => {"
                    f"  const platform = {repr(fp.get('platform', 'Win32'))};"
                    f"  const langs = {repr([fp.get('locale', 'en-US'), 'en'])};"
                    f"  const sw = {sw}, sh = {sh}, ah = {ah};"
                    f"  const dpr = {fp.get('device_scale_factor', 1.0)};"
                    "  try { Object.defineProperty(navigator, 'platform', {get: () => platform}); } catch {}"
                    "  try { Object.defineProperty(navigator, 'languages', {get: () => langs}); } catch {}"
                    "  try { Object.defineProperty(navigator, 'webdriver', {get: () => undefined}); } catch {}"
                    "  try { Object.defineProperty(navigator, 'hardwareConcurrency', {get: () => 8}); } catch {}"
                    "  try { Object.defineProperty(navigator, 'deviceMemory', {get: () => 8}); } catch {}"
                    "  try { Object.defineProperty(screen, 'width', {get: () => sw}); } catch {}"
                    "  try { Object.defineProperty(screen, 'height', {get: () => sh}); } catch {}"
                    "  try { Object.defineProperty(screen, 'availWidth', {get: () => sw}); } catch {}"
                    "  try { Object.defineProperty(screen, 'availHeight', {get: () => ah}); } catch {}"
                    "  try { Object.defineProperty(screen, 'colorDepth', {get: () => 24}); } catch {}"
                    "  try { Object.defineProperty(screen, 'pixelDepth', {get: () => 24}); } catch {}"
                    "  try { Object.defineProperty(window, 'devicePixelRatio', {get: () => dpr}); } catch {}"
                    "})();"
                )
                try:
                    await self.context.add_init_script(spoof_js)
                except Exception as e:
                    self._log(f"fp init_script failed: {e}")

            def _on_framenav(frame):
                rec = self.sess.macro
                if rec and rec.status == "recording":
                    rec.add_nav(frame.url, trigger="framenav")

            debug_log_path = Path(settings.macros_dir) / self.sid / "debug.log"
            try:
                debug_log_path.parent.mkdir(parents=True, exist_ok=True)
            except Exception:
                pass

            def _dlog(line: str):
                self._log(line)
                try:
                    with debug_log_path.open("a", encoding="utf-8") as f:
                        f.write(time.strftime("%H:%M:%S ") + line + "\n")
                except Exception:
                    pass

            def _on_console(msg):
                t = msg.type
                if t in ("error", "warning"):
                    _dlog(f"[console.{t}] {msg.text[:500]}")

            def _on_request_failed(req):
                try:
                    _dlog(f"[req.fail {req.method}] {req.url[:160]} — {req.failure}")
                except Exception:
                    pass

            async def _on_response(resp):
                try:
                    if resp.status >= 400:
                        url = resp.url
                        if any(s in url for s in ("/auth/", "/api/", "/oauth", "/signup",
                                                  "/register", "/login", "/v1/", "/users",
                                                  "/idp/", "/tokens", "/sessions")):
                            try:
                                body = await resp.text()
                            except Exception:
                                body = ""
                            _dlog(f"[http {resp.status} {resp.request.method}] "
                                  f"{url[:160]} — {body[:500]}")
                except Exception:
                    pass

            pages = self.context.pages
            self.page = pages[0] if pages else await self.context.new_page()

            def _wire_page(p):
                p.on("framenavigated", _on_framenav)
                p.on("console", _on_console)
                p.on("requestfailed", _on_request_failed)
                p.on("response", lambda r: asyncio.create_task(_on_response(r)))

            _wire_page(self.page)
            self.context.on("page",
                            lambda p: (self.sess.pages.append(p), _wire_page(p)))
            self.sess.pages.append(self.page)

            # External-close detection: if user closes Chromium, stop_evt fires
            self.context.on("close", lambda *_: self._stop_evt.set())

            try:
                # SID-collision regen (defensive)
                reg = SessionRegistry.get()._sessions
                tries = 0
                while self.sid in reg and tries < 5:
                    self.sid = "gui_" + uuid.uuid4().hex[:8]
                    tries += 1
                    self.sess.id = self.sid
                reg[self.sid] = self.sess  # type: ignore[assignment]
            except Exception as e:
                self._log(f"sess register err: {e}")

            url = self.template.get("url") or "about:blank"
            try:
                await self.page.goto(url, wait_until="domcontentloaded", timeout=45_000)
                self._log(f"navigated to {url}")
            except Exception as e:
                self._log(f"nav err: {e}")

            self._emit_status({"state": "ready", "sid": self.sid, "port": self.ws_port})

            await self._stop_evt.wait()

            try:
                SessionRegistry.get()._sessions.pop(self.sid, None)
            except Exception:
                pass
            try:
                if self.sess.macro and self.sess.macro.status != "idle":
                    self.sess.macro.stop()
            except Exception:
                pass
            try:
                await self.context.close()
            except Exception:
                pass
            try:
                ws_server.close()
                await ws_server.wait_closed()
            except Exception:
                pass

    # ----- WS dispatch helpers -------------------------------------------

    def _make_broadcaster(self):
        async def _bc(msg: dict):
            dead = []
            for ws in list(getattr(self, "ws_clients", []) or []):
                try:
                    await ws.send(json.dumps(msg))
                except Exception:
                    dead.append(ws)
            for ws in dead:
                self.ws_clients.discard(ws)
        return _bc

    def _make_dispatcher(self, sid: str):
        async def _dispatch(action: str, payload: dict, _sid: str = sid):
            self._last_activity = time.time()
            if action == "ctl":
                ctl_action = payload.get("action")
                ctl_payload = payload.get("payload") or {}
                msg = {"action": ctl_action, "payload": ctl_payload,
                       "kind": ctl_payload.get("kind")}
                try:
                    r = macro_ctl_dispatch(self.sess, msg)
                    self._emit_status(r)
                    return r
                except Exception as e:
                    self._log(f"ctl err: {e}")
                    return {"status": "error", "message": str(e)}
            if action == "otp":
                if not self.imap_email or not self.imap_pass:
                    self._log("OTP requested but no IMAP creds")
                    return {"code": None}
                self._log("fetching OTP...")
                try:
                    code = await asyncio.to_thread(fetch_otp, self.imap_email, self.imap_pass)
                    self._log(f"OTP -> {code}")
                    return {"code": code}
                except Exception as e:
                    self._log(f"OTP err: {e}")
                    return {"code": None, "error": str(e)}
            if action == "verify_url":
                if not self.imap_email or not self.imap_pass:
                    return {"url": None}
                self._log("fetching verify URL...")
                try:
                    url = await asyncio.to_thread(fetch_verify_url, self.imap_email, self.imap_pass)
                    self._log(f"verify URL -> {url}")
                    return {"url": url}
                except Exception as e:
                    self._log(f"verify err: {e}")
                    return {"url": None, "error": str(e)}
            if action == "captcha_detect":
                try:
                    page = self.sess.active_page() if self.sess else None
                    if page is None:
                        return {"found": False, "kind": None}
                    info = await _detect_captcha(page)
                    if info:
                        return {"found": True, "kind": info.get("type"),
                                "sitekey": info.get("sitekey"),
                                "invisible": info.get("invisible")}
                    return {"found": False, "kind": None}
                except Exception as e:
                    self._log(f"detect err: {e}")
                    return {"found": False, "error": str(e)}
            if action == "imap_email":
                return {"value": self.imap_email or ""}
            if action == "imap_pass":
                return {"value": self.imap_pass or ""}
            if action == "persona_field":
                kind = (payload or {}).get("kind") or "first_name"
                try:
                    from pymcp_browser.v2.control.tools.persona import persona_field as _pf
                    res = await _pf(kind=kind)
                    val = (res or {}).get("value")
                    self._log(f"persona {kind} -> {val}")
                    return {"value": val}
                except Exception as e:
                    self._log(f"persona err: {e}")
                    return {"value": None, "error": str(e)}
            if action == "run_macro":
                name = (payload or {}).get("name")
                if not name:
                    return {"ok": False, "error": "missing macro name"}
                task_obj = TASK_REGISTRY.get(name)
                if not task_obj:
                    self._log(f"run_macro: task not found: {name}")
                    return {"ok": False, "error": f"task not found: {name}"}
                self._log(f"run_macro: {name} sid={_sid}")
                try:
                    extra = {k: v for k, v in (payload or {}).items() if k != "name"}
                    result = await task_obj.handler(session_id=_sid, **extra)
                    self._log(f"run_macro {name} -> {result}")
                    return {"ok": True, "result": result}
                except TypeError:
                    try:
                        result = await task_obj.handler(session_id=_sid)
                        return {"ok": True, "result": result}
                    except Exception as e:
                        self._log(f"run_macro err: {e}")
                        return {"ok": False, "error": str(e)}
                except Exception as e:
                    self._log(f"run_macro err: {type(e).__name__}: {e}")
                    return {"ok": False, "error": str(e)}
            if action == "captcha_solve":
                # cooldown check
                since = time.time() - self._last_captcha_ok_ts
                if since < CAPTCHA_COOLDOWN_S:
                    remain = int(CAPTCHA_COOLDOWN_S - since)
                    self._log(f"captcha cooldown: {remain}s remaining")
                    return {"ok": False, "error": f"cooldown {remain}s"}
                page_action = (payload or {}).get("page_action") or self.captcha_action
                self._log(f"captcha solve (kind={payload.get('kind')}, action={page_action})...")
                try:
                    res = await _captcha_auto(session_id=_sid, pre_submit=True,
                                              page_action_hint=page_action)
                    self._log(f"captcha result: {res}")
                    solved = bool((res or {}).get("solved"))
                    if solved:
                        self._last_captcha_ok_ts = time.time()
                    return {
                        "ok": solved,
                        "type": (res or {}).get("type"),
                        "provider": (res or {}).get("provider"),
                        "reason": (res or {}).get("reason"),
                        "error": None if solved else (res or {}).get("reason"),
                    }
                except Exception as e:
                    self._log(f"captcha err: {type(e).__name__}: {e}")
                    return {"ok": False, "error": str(e)}
            return {"error": f"unknown_action:{action}"}
        return _dispatch
