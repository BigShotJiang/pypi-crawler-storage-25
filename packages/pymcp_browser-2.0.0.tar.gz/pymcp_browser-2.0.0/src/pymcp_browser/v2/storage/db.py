from __future__ import annotations
import time
from contextlib import contextmanager
from typing import Optional
from sqlmodel import SQLModel, create_engine, Session
from ..config import settings

_engine = None


def get_engine():
    global _engine
    if _engine is None:
        _engine = create_engine(f"sqlite:///{settings.db_path}",
                                connect_args={"check_same_thread": False})
        SQLModel.metadata.create_all(_engine)
    return _engine


@contextmanager
def session_scope():
    eng = get_engine()
    with Session(eng) as s:
        yield s
        s.commit()


def kv_get(key: str, default: Optional[str] = None) -> Optional[str]:
    from .models import KvSetting
    with session_scope() as s:
        row = s.get(KvSetting, key)
        return row.value if row else default


def kv_set(key: str, value: str) -> None:
    from .models import KvSetting
    with session_scope() as s:
        row = s.get(KvSetting, key)
        if row is None:
            s.add(KvSetting(key=key, value=value, updated_ts=time.time()))
        else:
            row.value = value
            row.updated_ts = time.time()
            s.add(row)
