from __future__ import annotations
from typing import Optional
from sqlmodel import SQLModel, Field


class ApiToken(SQLModel, table=True):
    prefix: str = Field(primary_key=True)
    hash: str
    scope: str
    label: str
    created_ts: float
    last_used_ts: Optional[float] = None
    expires_ts: Optional[float] = None


class Profile(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    name: str = Field(index=True, unique=True)
    storage_state_path: Optional[str] = None
    fingerprint_json: Optional[str] = None
    created_ts: float


class MailAccount(SQLModel, table=True):
    label: str = Field(primary_key=True)
    imap_host: str
    imap_port: int = 993
    imap_ssl: bool = True
    smtp_host: str
    smtp_port: int = 465
    smtp_tls: str = "ssl"  # ssl|starttls|none
    username: str
    daily_send_limit: Optional[int] = None
    daily_send_count: int = 0
    daily_send_window_start_ts: Optional[float] = None
    created_ts: float
    last_used_ts: Optional[float] = None


class Run(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    task_id: str = Field(index=True)
    task_name: str
    session_id: Optional[str] = None
    state: str
    started_ts: float
    ended_ts: Optional[float] = None
    result_json: Optional[str] = None
    error_json: Optional[str] = None


class MacroRun(SQLModel, table=True):
    """Phase 5 — per-iteration macro replay row.

    Populated by macro_launcher engine after each task.handler call when
    csv_logging or unique-loop is active. Surfaces via task.run_history MCP tool.
    """
    id: str = Field(primary_key=True)             # uuid4 hex (run_id)
    macro_name: str = Field(index=True)
    identity_seed: Optional[str] = None
    clean_mode: bool = False
    unique_mode: bool = False
    csv_logging: bool = False
    loop_count: int = 1
    iteration: int = 1
    started_ts: float = Field(index=True)
    duration_ms: int = 0
    ok: bool = True
    error_class: Optional[str] = None
    error_msg: Optional[str] = None
    proxy_egress_ip: Optional[str] = None
    actual_country: Optional[str] = None
    csv_path: Optional[str] = None
    clean_stats_json: Optional[str] = None        # JSON {dedupe_inputs:N,...}


class TotpKey(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    label: str = Field(index=True, unique=True)
    issuer: Optional[str] = None
    secret: str
    digits: int = 6
    period: int = 30
    algorithm: str = "SHA1"
    created_ts: float


class VaultEntry(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    label: str = Field(index=True, unique=True)
    username: Optional[str] = None
    password: str
    url: Optional[str] = None
    notes: Optional[str] = None
    created_ts: float
    updated_ts: float


class ClipEntry(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    content: str
    pinned: bool = Field(default=False, index=True)
    used_count: int = 0
    created_ts: float


class SessionDiagnosis(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    session_id: str = Field(index=True)
    captured_ts: float
    ip: Optional[str] = None
    country: Optional[str] = None
    org: Optional[str] = None
    proxy_egress_ip: Optional[str] = None
    ip_match: Optional[bool] = None
    blob_json: str


class KvSetting(SQLModel, table=True):
    key: str = Field(primary_key=True)
    value: str
    updated_ts: float


class PreflightReport(SQLModel, table=True):
    """Pixelscan preflight report summary; full JSON lives in `json_path`."""
    id: str = Field(primary_key=True)                  # "pf_YYYYMMDD_HHMMSS_<sid8>"
    ts: float = Field(index=True)                      # epoch seconds (utc)
    session_id: str = Field(index=True)
    engine: str
    mode: str
    headless: bool
    fp_score: float
    bot_score: float
    total_score: float = Field(index=True)
    verdict: str = Field(index=True)                   # "pass" | "fail" | "timeout"
    hard_fails: str = ""                               # CSV of rule keys
    schema_version: str
    selector_version: str
    remote_url: Optional[str] = None
    duration_ms: int = 0
    json_path: str                                     # absolute path to JSON blob


class SessionEvent(SQLModel, table=True):
    """D8: append-only per-session activity log keyed by session_id."""
    id: Optional[int] = Field(default=None, primary_key=True)
    session_id: str = Field(index=True)
    ts: float
    key: str = Field(index=True)
    value: str  # JSON-encoded dict or scalar string
