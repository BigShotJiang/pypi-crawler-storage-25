"""Preflight pixelscan gate.

Scrapes pixelscan.net (fingerprint + bot check) against an active browser session,
scores the result, persists JSON + SQLite index + optional remote URL, exposes
MCP tools, and returns gate verdicts so macros can refuse to run when the session
would fail third-party fingerprint/bot detection.

See docs/preflight-pixelscan-implementation-plan-fully-grilled.md.
"""
from __future__ import annotations

from .selectors import SELECTOR_VERSION, SCHEMA_VERSION

__all__ = ["SELECTOR_VERSION", "SCHEMA_VERSION"]
