"""TTL cache keyed by session_id. 5-minute default."""
from __future__ import annotations
import time
from typing import Optional

DEFAULT_TTL_S = 300

_cache: dict[str, tuple[float, dict]] = {}


def get(session_id: str, ttl_s: float = DEFAULT_TTL_S) -> Optional[dict]:
    entry = _cache.get(session_id)
    if entry is None:
        return None
    ts, payload = entry
    if time.time() - ts > ttl_s:
        _cache.pop(session_id, None)
        return None
    return payload


def put(session_id: str, payload: dict) -> None:
    _cache[session_id] = (time.time(), payload)


def invalidate(session_id: str) -> None:
    _cache.pop(session_id, None)


def clear_all() -> None:
    _cache.clear()
