"""Optional remote hosting of preflight report JSON via Filen CLI.

Falls back to local FastAPI route when filen CLI unavailable or upload fails.
Both Filen + FastAPI fallback URL are caller-readable.
"""
from __future__ import annotations
import asyncio
import re
import shutil
import subprocess
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

from loguru import logger

from ..config import settings
from . import store


def _filen_path() -> Optional[str]:
    return shutil.which("filen")


def _has_filen() -> bool:
    return _filen_path() is not None


def _run(cmd: list[str], timeout: int = 60) -> tuple[int, str]:
    try:
        p = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        return p.returncode, (p.stdout or "") + (p.stderr or "")
    except Exception as e:
        return -1, str(e)


def _month_dir() -> str:
    return datetime.now(tz=timezone.utc).strftime("%Y-%m")


def _filen_mkdir_p(remote_dir: str) -> bool:
    rc, _ = _run(["filen", "stat", remote_dir])
    if rc == 0:
        return True
    rc, out = _run(["filen", "mkdir", remote_dir])
    if rc != 0:
        logger.warning(f"preflight.host: filen mkdir failed: {out}")
        return False
    return True


_URL_RE = re.compile(r"https://[^\s\"']+")


def _filen_create_link(remote_path: str) -> Optional[str]:
    # `filen links <path>` is interactive. Use --json + non-interactive args
    # if available; otherwise scrape URL from stdout.
    rc, out = _run(["filen", "links", remote_path])
    if rc != 0:
        logger.warning(f"preflight.host: filen links failed: {out[:200]}")
        return None
    m = _URL_RE.search(out)
    return m.group(0) if m else None


def _local_url(report_id: str) -> str:
    # Fallback URL served by FastAPI /preflight/reports/<id>
    return f"http://127.0.0.1:8765/preflight/reports/{report_id}"


def upload_report_sync(report_id: str, local_path: str) -> Optional[str]:
    """Synchronous upload. Returns URL (Filen public link OR local fallback) or None.
    Failure to upload is non-fatal — caller logs and continues.
    """
    if not settings.preflight_upload:
        return _local_url(report_id)
    if not _has_filen():
        logger.info("preflight.host: filen CLI not on PATH; using local URL")
        return _local_url(report_id)

    base = settings.preflight_filen_base.rstrip("/")
    remote_dir = f"{base}/{_month_dir()}"
    if not _filen_mkdir_p(remote_dir):
        return _local_url(report_id)

    p = Path(local_path)
    if not p.is_file():
        logger.error(f"preflight.host: missing file {local_path}")
        return None
    rc, out = _run(["filen", "upload", str(p), remote_dir + "/"])
    if rc != 0:
        logger.warning(f"preflight.host: upload failed: {out[:200]}")
        return _local_url(report_id)

    remote_path = f"{remote_dir}/{p.name}"
    link = _filen_create_link(remote_path)
    return link or _local_url(report_id)


async def upload_report_async(report_id: str, local_path: str) -> None:
    """Fire-and-forget — runs subprocess off-loop and patches DB row."""
    loop = asyncio.get_running_loop()
    try:
        url = await loop.run_in_executor(None, upload_report_sync,
                                         report_id, local_path)
        if url:
            store.set_remote_url(report_id, url)
            logger.info(f"preflight.host: {report_id} -> {url}")
    except Exception as e:
        logger.error(f"preflight.host: async upload error: {e}")
