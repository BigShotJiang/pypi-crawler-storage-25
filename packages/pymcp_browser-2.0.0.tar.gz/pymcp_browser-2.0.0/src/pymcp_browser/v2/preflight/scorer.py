"""Pure scoring functions. raw dicts in → scored report fragments out.

No IO. Fully unit-testable from fixtures.
"""
from __future__ import annotations

from .rules import apply_rules, sum_penalty, RULE_KEYS

# 4 pills × 25 pts = 100 (Bot pill excluded — duplicates bot page).
_PILL_WEIGHT = 25
_SCORED_PILLS = ("Browser", "Location", "Proxy", "Fingerprint")

# Expected pass values for Proxy pill — depends on whether session has proxy.
# When `expected_proxy` not provided, accept either as pass.
_PROXY_PASS_NO = "no proxy detected"


def _proxy_pill_pass(value: str, expected_proxy: str | None) -> bool:
    v = (value or "").lower()
    if expected_proxy in (None, "any"):
        return True  # don't fail proxy pill when expectation absent
    if expected_proxy == "no_proxy":
        return _PROXY_PASS_NO in v
    if expected_proxy == "proxy_detected":
        return _PROXY_PASS_NO not in v
    return True


def score_fingerprint(fp_raw: dict, diag: dict | None,
                      expected_proxy: str | None) -> dict:
    """Return {"score": int, "pills": [...], "rule_hits": [...], "penalty": int}.

    Pills score 25 pts each on pass. Rule penalties applied capped at -40.
    """
    pill_idx = {p["name"]: p for p in fp_raw.get("pills", [])}
    annotated = []
    base = 0
    for name in _SCORED_PILLS:
        p = pill_idx.get(name)
        if p is None:
            annotated.append({"name": name, "value": "", "pass": False, "missing": True})
            continue
        passed = bool(p["pass"])
        if name == "Proxy":
            passed = _proxy_pill_pass(p["value"], expected_proxy)
        annotated.append({"name": name, "value": p["value"], "pass": passed})
        if passed:
            base += _PILL_WEIGHT

    # Bot pill — annotated but not scored (avoid double-count w/ bot page).
    bot_pill = pill_idx.get("Bot check")
    if bot_pill is not None:
        annotated.append({"name": "Bot check", "value": bot_pill["value"],
                          "pass": bool(bot_pill["pass"]), "scored": False})

    hits = apply_rules(fp_raw, diag)
    penalty = sum_penalty(hits)
    score = max(0, min(100, base - penalty))
    return {
        "score": score,
        "pills": annotated,
        "rule_hits": hits,
        "penalty": penalty,
    }


def score_bot(bot_raw: dict) -> dict:
    """Return {"score": float, "sections": {...}, "verdict": str}.

    Score = clear_params / total_params * 100 across all 4 sections.
    """
    total = int(bot_raw.get("total") or 0)
    clear = int(bot_raw.get("clear") or 0)
    score = (clear / total * 100.0) if total else 0.0
    return {
        "score": round(score, 2),
        "sections": bot_raw.get("sections", {}),
        "verdict": bot_raw.get("verdict", "unknown"),
    }


def compute_total(fp_score: float, bot_score: float,
                  weights: dict[str, float] | None = None) -> float:
    """Weighted average of fp + bot scores."""
    w = weights or {"fp": 0.5, "bot": 0.5}
    wf = float(w.get("fp", 0.5))
    wb = float(w.get("bot", 0.5))
    s = wf + wb
    if s <= 0:
        return 0.0
    return round((wf * fp_score + wb * bot_score) / s, 2)


def evaluate_gates(report: dict, *, min_total: float = 85,
                   min_fp: float = 80, min_bot: float = 70,
                   hard_fail_on: list[str] | None = None) -> dict:
    """Return {"allowed": bool, "reason": str, "hard_fails": [str]}.

    Hard-fail keys take precedence over numeric thresholds.
    """
    hard_fail_on = list(hard_fail_on or ["bot_verdict_error", "headless_ua"])
    unknown = [k for k in hard_fail_on if k not in RULE_KEYS]
    if unknown:
        return {
            "allowed": False, "hard_fails": [],
            "reason": f"invalid_args:hard_fail_on contains unknown keys {unknown}",
        }

    rule_hits = set(report.get("fingerprint", {}).get("rule_hits", []))
    if report.get("bot", {}).get("verdict") == "error":
        rule_hits.add("bot_verdict_error")

    hard = [k for k in hard_fail_on if k in rule_hits]
    if hard:
        return {
            "allowed": False,
            "reason": f"hard_fail:{hard[0]}",
            "hard_fails": hard,
        }
    if report["total_score"] < min_total:
        return {
            "allowed": False,
            "reason": f"total_score {report['total_score']} < {min_total}",
            "hard_fails": [],
        }
    if report["fingerprint"]["score"] < min_fp:
        return {
            "allowed": False,
            "reason": f"fp_score {report['fingerprint']['score']} < {min_fp}",
            "hard_fails": [],
        }
    if report["bot"]["score"] < min_bot:
        return {
            "allowed": False,
            "reason": f"bot_score {report['bot']['score']} < {min_bot}",
            "hard_fails": [],
        }
    return {"allowed": True, "reason": "ok", "hard_fails": []}
