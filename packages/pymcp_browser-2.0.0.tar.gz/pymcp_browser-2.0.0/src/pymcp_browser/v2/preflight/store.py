"""PreflightReport DB CRUD + query helpers."""
from __future__ import annotations
import time
from datetime import datetime, timezone
from typing import Optional

from sqlmodel import select

from ..storage.db import session_scope
from ..storage.models import PreflightReport


def insert(*, id: str, session_id: str, engine: str, mode: str,
           headless: bool, fp_score: float, bot_score: float,
           total_score: float, verdict: str, hard_fails: list[str],
           schema_version: str, selector_version: str,
           remote_url: Optional[str], duration_ms: int,
           json_path: str, ts: Optional[float] = None) -> None:
    with session_scope() as s:
        s.add(PreflightReport(
            id=id, ts=ts or time.time(), session_id=session_id,
            engine=engine, mode=mode, headless=headless,
            fp_score=fp_score, bot_score=bot_score, total_score=total_score,
            verdict=verdict, hard_fails=",".join(hard_fails),
            schema_version=schema_version, selector_version=selector_version,
            remote_url=remote_url, duration_ms=duration_ms,
            json_path=json_path,
        ))


def get(report_id: str) -> Optional[dict]:
    """Return summary dict (or None) — detached-safe."""
    with session_scope() as s:
        row = s.get(PreflightReport, report_id)
        if row is None:
            return None
        return _to_dict(row)


def set_remote_url(report_id: str, url: str) -> None:
    with session_scope() as s:
        row = s.get(PreflightReport, report_id)
        if row is not None:
            row.remote_url = url
            s.add(row)


def list_reports(*, limit: int = 50, since: Optional[datetime] = None,
                 min_total: Optional[float] = None,
                 verdict: Optional[str] = None,
                 engine: Optional[str] = None,
                 session_id: Optional[str] = None) -> list[dict]:
    """Return list of summary rows newest-first."""
    stmt = select(PreflightReport)
    if since is not None:
        stmt = stmt.where(PreflightReport.ts >= since.timestamp())
    if min_total is not None:
        stmt = stmt.where(PreflightReport.total_score >= min_total)
    if verdict is not None:
        stmt = stmt.where(PreflightReport.verdict == verdict)
    if engine is not None:
        stmt = stmt.where(PreflightReport.engine == engine)
    if session_id is not None:
        stmt = stmt.where(PreflightReport.session_id == session_id)
    stmt = stmt.order_by(PreflightReport.ts.desc()).limit(limit)

    with session_scope() as s:
        rows = s.exec(stmt).all()
        return [_to_dict(r) for r in rows]


def _to_dict(r: PreflightReport) -> dict:
    return {
        "id": r.id,
        "ts": datetime.fromtimestamp(r.ts, tz=timezone.utc).isoformat().replace("+00:00", "Z"),
        "session_id": r.session_id,
        "engine": r.engine,
        "mode": r.mode,
        "headless": r.headless,
        "fp_score": r.fp_score,
        "bot_score": r.bot_score,
        "total_score": r.total_score,
        "verdict": r.verdict,
        "hard_fails": [k for k in r.hard_fails.split(",") if k],
        "remote_url": r.remote_url,
        "duration_ms": r.duration_ms,
        "json_path": r.json_path,
    }
