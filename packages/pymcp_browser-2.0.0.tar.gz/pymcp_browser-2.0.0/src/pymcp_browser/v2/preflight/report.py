"""Build full report JSON, persist to disk, insert summary into DB.

Pure orchestration: scraper output + scoring → on-disk JSON + DB row.
"""
from __future__ import annotations
import json
import time
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

from loguru import logger

from ..config import settings
from . import scorer as SC
from . import selectors as SEL
from . import store


def _now_iso() -> str:
    return datetime.now(tz=timezone.utc).isoformat().replace("+00:00", "Z")


def _report_id(session_id: str) -> str:
    ts = datetime.now(tz=timezone.utc).strftime("%Y%m%d_%H%M%S")
    return f"pf_{ts}_{session_id[:8]}"


def build_report(raw: dict, *, session_id: str,
                 weights: Optional[dict] = None,
                 expected_proxy: Optional[str] = None,
                 thresholds: Optional[dict] = None,
                 hard_fail_on: Optional[list[str]] = None,
                 diag: Optional[dict] = None) -> dict:
    """Score raw scraper output and assemble the full report dict.

    Does NOT write to disk or DB. Use `persist()` for that.
    """
    fp_raw = raw["fp"]
    bot_raw = raw["bot"]
    sess = raw.get("session", {})

    fp_scored = SC.score_fingerprint(fp_raw, diag=diag,
                                     expected_proxy=expected_proxy)
    bot_scored = SC.score_bot(bot_raw)
    total = SC.compute_total(fp_scored["score"], bot_scored["score"],
                             weights or {"fp": settings.preflight_weights_fp,
                                         "bot": settings.preflight_weights_bot})

    th = thresholds or {
        "min_total": settings.preflight_min_total,
        "min_fp": settings.preflight_min_fp,
        "min_bot": settings.preflight_min_bot,
    }
    hf = hard_fail_on or [k.strip() for k in
                          settings.preflight_hard_fails.split(",") if k.strip()]

    report = {
        "schema_version": SEL.SCHEMA_VERSION,
        "selector_version": SEL.SELECTOR_VERSION,
        "id": _report_id(session_id),
        "ts": _now_iso(),
        "session_id": session_id,
        "engine": sess.get("engine"),
        "mode": sess.get("mode"),
        "headless": sess.get("headless"),
        "viewport": sess.get("viewport"),
        "proxy_egress_ip": sess.get("proxy_egress_ip"),
        "fingerprint": {
            "headline": fp_raw.get("headline"),
            "pills": fp_scored["pills"],
            "details": fp_raw.get("details", {}),
            "rule_hits": fp_scored["rule_hits"],
            "penalty": fp_scored["penalty"],
            "score": fp_scored["score"],
        },
        "bot": {
            "verdict": bot_scored["verdict"],
            "sections": bot_scored["sections"],
            "score": bot_scored["score"],
        },
        "weights": weights or {"fp": settings.preflight_weights_fp,
                               "bot": settings.preflight_weights_bot},
        "total_score": total,
        "thresholds_evaluated": th,
        "duration_ms": raw.get("duration_ms", 0),
        "remote_url": None,
    }
    gate = SC.evaluate_gates(report, min_total=th["min_total"],
                             min_fp=th["min_fp"], min_bot=th["min_bot"],
                             hard_fail_on=hf)
    report["verdict"] = "pass" if gate["allowed"] else \
        ("timeout" if bot_raw.get("verdict") == "timeout" else "fail")
    report["hard_fails"] = gate["hard_fails"]
    report["gate_reason"] = gate["reason"]
    return report


def persist(report: dict, *, raw_html: Optional[dict] = None) -> str:
    """Write JSON to disk, insert DB row. Return absolute JSON path."""
    out_dir = Path(settings.preflight_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    json_path = out_dir / f"{report['id']}.json"
    json_path.write_text(json.dumps(report, indent=2, ensure_ascii=False),
                         encoding="utf-8")

    if raw_html and settings.preflight_save_raw_html:
        raw_dir = out_dir / "raw"
        raw_dir.mkdir(parents=True, exist_ok=True)
        (raw_dir / f"{report['id']}.json").write_text(
            json.dumps(raw_html, indent=2, ensure_ascii=False), encoding="utf-8")

    # epoch seconds from iso ts
    ts_epoch = datetime.fromisoformat(report["ts"].replace("Z", "+00:00")).timestamp()
    try:
        store.insert(
            id=report["id"],
            ts=ts_epoch,
            session_id=report["session_id"],
            engine=report.get("engine") or "unknown",
            mode=report.get("mode") or "unknown",
            headless=bool(report.get("headless")),
            fp_score=float(report["fingerprint"]["score"]),
            bot_score=float(report["bot"]["score"]),
            total_score=float(report["total_score"]),
            verdict=report["verdict"],
            hard_fails=report.get("hard_fails", []),
            schema_version=report["schema_version"],
            selector_version=report["selector_version"],
            remote_url=report.get("remote_url"),
            duration_ms=int(report.get("duration_ms", 0)),
            json_path=str(json_path),
        )
    except Exception as e:
        logger.error(f"preflight.persist: DB insert failed: {e}")
    return str(json_path)


def read(report_id: str) -> Optional[dict]:
    """Load full report JSON from disk via DB-tracked path."""
    row = store.get(report_id)
    if not row:
        return None
    p = Path(row["json_path"])
    if not p.is_file():
        logger.warning(f"preflight.read: json missing for {report_id}: {p}")
        return None
    return json.loads(p.read_text(encoding="utf-8"))
