"""Scrape pixelscan fingerprint + bot-check pages, parse via selectors.

Wires up MCP tool handlers (nav.go, inspect_html, inspect_attr) to drive the
target session. Per-session asyncio.Lock prevents concurrent scrapes;
per-egress-IP throttle blocks rapid re-runs.
"""
from __future__ import annotations
import asyncio
import time
from typing import Optional

from loguru import logger

from ..control.errors import ToolError
from ..control.tools.inspect import inspect_html, inspect_attr
from ..control.tools.nav import nav_go
from ..control.tools.wait import wait_sleep
from ..core.session import SessionRegistry
from . import selectors as SEL
from .parser import parse_fingerprint, parse_bot

THROTTLE_S = 30.0

_session_locks: dict[str, asyncio.Lock] = {}
_last_run_by_ip: dict[str, float] = {}


def _throttle_check(ip: Optional[str]) -> None:
    if not ip:
        return
    now = time.time()
    last = _last_run_by_ip.get(ip, 0.0)
    if now - last < THROTTLE_S:
        wait_s = round(THROTTLE_S - (now - last), 1)
        raise ToolError(
            "preflight_rate_limited",
            f"preflight throttled per egress IP; wait {wait_s}s",
        )
    _last_run_by_ip[ip] = now


async def _poll_bot_state(session_id: str, timeout_s: float = 25.0) -> str:
    deadline = time.time() + timeout_s
    last = "unknown"
    while time.time() < deadline:
        try:
            r = await inspect_attr(
                session_id=session_id,
                target=SEL.SEL_BOT_HEADER,
                name=SEL.ATTR_BOT_STATE,
            )
            v = (r or {}).get("value") or ""
            last = v or last
            if v in ("success", "error"):
                return v
        except ToolError as e:
            # header not yet rendered → keep polling
            logger.debug(f"preflight._poll_bot_state: {e.code}")
        await asyncio.sleep(1.0)
    return "timeout"


async def scrape(session_id: str, *, save_raw_html: bool = False) -> dict:
    """Drive the named session through both pixelscan pages, return raw dict.

    Output:
        {
          "fp":   parse_fingerprint(...) output,
          "bot":  parse_bot(...) output,
          "session": {"engine","mode","headless","viewport","proxy_egress_ip"},
          "raw_html": {"fp_checks","fp_details","fp_status","bot_summary"} if save_raw_html,
          "duration_ms": int,
        }

    Raises:
        preflight_pixelscan_unreachable
        preflight_dom_drift
        preflight_session_lost
        preflight_rate_limited
        preflight_timeout
    """
    t0 = time.time()
    sess = SessionRegistry.get().lookup(session_id)  # raises session_not_found
    _throttle_check(sess.proxy_egress_ip)

    lock = _session_locks.setdefault(session_id, asyncio.Lock())
    async with lock:
        # --- Fingerprint page -----------------------------------------------
        try:
            await nav_go(session_id=session_id, url=SEL.URL_FINGERPRINT,
                         wait_until="domcontentloaded", timeout_ms=45000)
        except ToolError as e:
            raise ToolError("preflight_pixelscan_unreachable",
                            f"nav.go fingerprint: {e.message}")

        await wait_sleep(session_id=session_id, ms=2500)  # Angular settle

        try:
            checks_html = (await inspect_html(
                session_id=session_id,
                target=SEL.SEL_FP_CHECKS_GRID,
                max_chars=30000,
            ))["html"]
            details_html = (await inspect_html(
                session_id=session_id,
                target=SEL.SEL_FP_DETAILS_ROOT,
                max_chars=50000,
            ))["html"]
            status_html = (await inspect_html(
                session_id=session_id,
                target=SEL.SEL_FP_STATUS_BAR,
                max_chars=4000,
            ))["html"]
        except ToolError as e:
            raise ToolError("preflight_dom_drift",
                            f"fingerprint selector missed: {e.message}")

        fp = parse_fingerprint(checks_html, details_html, status_html)

        # --- Bot-check page -------------------------------------------------
        try:
            await nav_go(session_id=session_id, url=SEL.URL_BOT,
                         wait_until="domcontentloaded", timeout_ms=45000)
        except ToolError as e:
            raise ToolError("preflight_pixelscan_unreachable",
                            f"nav.go bot-check: {e.message}")

        header_state = await _poll_bot_state(session_id, timeout_s=25.0)
        try:
            summary_html = (await inspect_html(
                session_id=session_id,
                target=SEL.SEL_BOT_SUMMARY,
                max_chars=20000,
            ))["html"]
        except ToolError as e:
            raise ToolError("preflight_dom_drift",
                            f"bot-summary selector missed: {e.message}")
        bot = parse_bot(summary_html, header_state)

        # --- Drift check ----------------------------------------------------
        drift = SEL.check_drift(
            pills=len(fp.get("pills", [])),
            cards=len(fp.get("details", {})),
            sections=len(bot.get("sections", {})),
        )
        if drift:
            raise ToolError("preflight_dom_drift", drift)

        duration_ms = int((time.time() - t0) * 1000)

        out = {
            "fp": fp, "bot": bot,
            "session": {
                "engine": sess.engine,
                "mode": getattr(sess, "mode", "stealth"),
                "headless": getattr(sess, "headless", True),
                "viewport": getattr(sess, "viewport", None),
                "proxy_egress_ip": sess.proxy_egress_ip,
            },
            "duration_ms": duration_ms,
        }
        if save_raw_html:
            out["raw_html"] = {
                "fp_checks": checks_html,
                "fp_details": details_html,
                "fp_status": status_html,
                "bot_summary": summary_html,
            }
        return out
