"""Frozen pixelscan.net selectors + regex patterns.

Bump SELECTOR_VERSION when site DOM shifts. Parser must hit required-field
quotas (see _REQUIRED_*) or scraper raises `preflight_dom_drift`.

Captured 2026-05-12 against pixelscan.net Angular SPA build.
"""
from __future__ import annotations
import re

SCHEMA_VERSION = "1.0"
SELECTOR_VERSION = "2026-05-12"

# --- URLs --------------------------------------------------------------------
URL_FINGERPRINT = "https://pixelscan.net/fingerprint-check"
URL_BOT = "https://pixelscan.net/bot-check"

# --- Fingerprint page --------------------------------------------------------
# Top status bar (overall verdict)
SEL_FP_STATUS_BAR = ".status-bar"                     # has data-state="error|success"

# Pill grid (5 cards)
SEL_FP_CHECKS_GRID = ".checks-grid"
# Each `pxlscn-checker-card` holds:
#   .checker-card                       — base div; +".checker-card--failed" when red
#   .checker-card__label                — pill name ("Browser","Location","Proxy","Fingerprint","Bot check")
#   p[checkervalue]                     — value text (multiple p tags collapse to one string)

# Detail cards container ("What Websites See About You")
SEL_FP_DETAILS_ROOT = "#what_website_see"
# Each `pxlscn-checker-details-card`:
#   .card-title                         — card name ("Location", "Date & Time", ...)
#   .checker-details-label              — field label
#   .checker-details-value              — field value (large)
#   .checker-details-value--small       — field value (small)
#   .checker-details-tag                — tag chip (fonts, languages)

PILL_NAMES = ["Browser", "Location", "Proxy", "Fingerprint", "Bot check"]
DETAIL_CARD_NAMES = [
    "Location", "Date & Time", "Screen", "Fonts",
    "User-Agent", "Language", "Hardware",
]

# --- Bot check page ----------------------------------------------------------
SEL_BOT_HEADER = "pxlscn-checker-header > div"        # attr `state` = default|loading|success|error
ATTR_BOT_STATE = "state"
SEL_BOT_SUMMARY = ".bot-check-summary"
SEL_BOT_TAB = ".bot-check-summary__tab"
# Each tab button holds a `pxlscn-bot-check-summary-section`:
#   title="Navigator|Webdriver|CDP|User Agent"
#   count="N parameters"
#   .summary-section__status                       — "Detected" / "Clear" text
#   .summary-section__status--alert                — red variant present iff status=Detected

BOT_SECTION_NAMES = ["Navigator", "Webdriver", "CDP", "User Agent"]

# --- Required-field quotas (drift detection) ---------------------------------
_REQUIRED_PILLS = 4               # need >=4 of 5 pills parsed
_REQUIRED_DETAIL_CARDS = 6        # need >=6 of 7 cards parsed
_REQUIRED_BOT_SECTIONS = 4        # all 4 bot sections must parse


def check_drift(pills: int, cards: int, sections: int) -> str | None:
    """Return human-readable drift reason if any required quota missed."""
    if pills < _REQUIRED_PILLS:
        return f"only {pills}/{_REQUIRED_PILLS}+ fingerprint pills parsed"
    if cards < _REQUIRED_DETAIL_CARDS:
        return f"only {cards}/{_REQUIRED_DETAIL_CARDS}+ detail cards parsed"
    if sections < _REQUIRED_BOT_SECTIONS:
        return f"only {sections}/{_REQUIRED_BOT_SECTIONS} bot sections parsed"
    return None


# --- Parsing regexes (HTML pre-stripped: svg removed, ng comments removed,
#     whitespace collapsed). All run on the stripped string. -----------------

RE_STRIP_SVG = re.compile(r"<svg.*?</svg>", re.S)
RE_STRIP_NG_COMMENTS = re.compile(r"<!---->")
RE_WS = re.compile(r"\s+")


def normalize_html(html: str) -> str:
    """Strip svg, ng comment placeholders, collapse whitespace."""
    s = RE_STRIP_SVG.sub("", html)
    s = RE_STRIP_NG_COMMENTS.sub("", s)
    return RE_WS.sub(" ", s)


# Fingerprint pill: extract pairs of (failed?, label, value) per card.
# Strategy: find each `<pxlscn-checker-card …label="Name"…>` opening
# OR each `.checker-card__label` text; pair with nearest preceding
# `.checker-card` div for failed-class detection and following `p[checkervalue]`
# block(s). Regex below assumes the rendered order:
#   <div ... class="checker-card[ checker-card--failed]"> ... <p checkervalue> VALUE </p> ... <p class="checker-card__label">LABEL</p> ...
RE_PILL_BLOCK = re.compile(
    r'class="checker-card(?P<failed>\s+checker-card--failed)?"'
    r'.*?'
    r'<p[^>]+checkervalue[^>]*>(?P<value>.*?)</p>'
    r'.*?'
    r'class="checker-card__label">(?P<label>[^<]+)</p>',
    re.S,
)

# Detail card: <h3 class="card-title">NAME</h3> followed by
# repeating <span class="checker-details-label">LABEL</span><span class="checker-details-value[--small]">VAL</span>
RE_DETAIL_CARD = re.compile(
    r'<h3 class="card-title">(?P<name>[^<]+)</h3>(?P<body>.*?)(?=<h3 class="card-title">|</main>|$)',
    re.S,
)
RE_DETAIL_FIELD = re.compile(
    r'class="checker-details-label">(?P<label>[^<]+)</span>'
    r'\s*<span[^>]+class="checker-details-value(?:--small)?">(?P<value>[^<]*)</span>',
    re.S,
)
RE_DETAIL_TAG_BLOCK = re.compile(
    r'class="checker-details-label">(?P<label>[^<]+)</span>'
    r'\s*<div[^>]+class="checker-details-tags">(?P<tags>.*?)</div>',
    re.S,
)
RE_DETAIL_TAG = re.compile(
    r'class="checker-details-tag[^"]*">([^<]+)</span>'
)

# Bot section: <pxlscn-bot-check-summary-section title="Navigator" count="73 parameters" ...>
# state inferred from presence of `summary-section__status--alert` in inner block.
RE_BOT_SECTION = re.compile(
    r'<pxlscn-bot-check-summary-section[^>]+title="(?P<title>[^"]+)"'
    r'[^>]+count="(?P<count>\d+)\s+parameters"'
    r'[^>]*>(?P<body>.*?)</pxlscn-bot-check-summary-section>',
    re.S,
)
RE_BOT_ALERT = re.compile(r'summary-section__status--alert')

# Overall status bar verdict
RE_FP_HEADLINE = re.compile(
    r'data-state="(?P<state>[^"]+)".*?status-(?:error|success|warning|neutral)[^>]*>\s*(?P<text>[^<]+?)\s*<',
    re.S,
)
