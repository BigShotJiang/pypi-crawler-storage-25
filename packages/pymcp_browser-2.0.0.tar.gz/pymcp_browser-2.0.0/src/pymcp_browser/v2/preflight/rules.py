"""Derived consistency penalty rules + closed-enum keys.

Closed enum allows JSONSchema-validated `hard_fail_on` list.
"""
from __future__ import annotations
import re
from typing import Iterable

# Closed enum — used by tools.py JSONSchema for hard_fail_on validation.
RULE_KEYS = (
    "headless_ua",
    "swiftshader",
    "tz_mismatch",
    "country_lang_mismatch",
    "webrtc_leak",
    "tiny_viewport",
    "bot_verdict_error",   # synthetic — set by scorer when bot.verdict=="error"
)

RULE_WEIGHTS: dict[str, int] = {
    "headless_ua":           40,
    "swiftshader":           10,
    "tz_mismatch":           10,
    "country_lang_mismatch":  5,
    "webrtc_leak":           15,
    "tiny_viewport":          5,
}

PENALTY_CAP = 40

# Minimal plausibility table — IP country -> commonly expected primary language.
# Only used by `country_lang_mismatch` rule; tolerant — only flags clear mismatches.
_COUNTRY_LANG: dict[str, set[str]] = {
    "Brazil":      {"pt", "pt-BR", "en"},
    "Germany":     {"de", "en"},
    "France":      {"fr", "en"},
    "Spain":       {"es", "en"},
    "Italy":       {"it", "en"},
    "Japan":       {"ja", "en"},
    "China":       {"zh", "zh-CN", "en"},
    "Russia":      {"ru", "en"},
    "Mauritius":   {"en", "fr"},
    "Philippines": {"en", "tl", "fil"},
    "USA":         {"en", "en-US", "es"},
    "United States": {"en", "en-US", "es"},
    "Mexico":      {"es", "en"},
    "Turkey":      {"tr", "en"},
    "India":       {"en", "hi"},
    "UK":          {"en", "en-GB"},
    "United Kingdom": {"en", "en-GB"},
}


def _detail_get(details: dict, card: str, label: str) -> str:
    """Lookup label in details[card] map; return '' if missing."""
    return (details.get(card) or {}).get(label, "") or ""


def _detail_lang_list(details: dict) -> list[str]:
    """Languages from JavaScript list (or first lang as singleton)."""
    langs = (details.get("Language") or {}).get("Languages from Javascript", [])
    if isinstance(langs, list):
        return langs
    return [langs] if langs else []


def apply_rules(fp_raw: dict, diag: dict | None = None) -> list[str]:
    """Return list of rule_keys that triggered.

    Inputs:
        fp_raw  — parsed fingerprint dict (pills + details).
        diag    — optional in-browser diagnosis blob (from diag.run cache); rules
                  prefer diag data when present, fall back to pixelscan.

    Rules run independently. Order: stable, by declaration here.
    """
    hits: list[str] = []
    details = fp_raw.get("details", {}) or {}

    # 1. headless_ua — UA contains HeadlessChrome
    ua = (diag or {}).get("userAgent") or _detail_get(details, "User-Agent", "JavaScript") \
        or _detail_get(details, "User-Agent", "HTTP")
    if "HeadlessChrome" in (ua or ""):
        hits.append("headless_ua")

    # 2. swiftshader — WebGL Renderer
    renderer = ""
    if diag:
        renderer = ((diag.get("webgl") or {}).get("renderer") or "")
    if not renderer:
        renderer = _detail_get(details, "Hardware", "WebGL Renderer")
    if "SwiftShader" in renderer:
        hits.append("swiftshader")

    # 3. tz_mismatch — JS timezone vs IP-implied offset
    tz_js = _detail_get(details, "Date & Time", "Timezone from JS")
    time_ip = _detail_get(details, "Date & Time", "Time from IP")
    time_js = _detail_get(details, "Date & Time", "Time from JS")
    if tz_js and time_ip and time_js:
        m_ip = re.search(r"GMT([+\-]\d{2,4})", time_ip)
        m_js = re.search(r"GMT([+\-]\d{2,4})", time_js)
        if m_ip and m_js and m_ip.group(1) != m_js.group(1):
            hits.append("tz_mismatch")

    # 4. country_lang_mismatch — IP country vs Accept-Language base
    country = _detail_get(details, "Location", "Country")
    langs = _detail_lang_list(details)
    if country and langs and country in _COUNTRY_LANG:
        expected = _COUNTRY_LANG[country]
        bases = {l.split("-")[0] for l in langs}
        if not (expected & (bases | set(langs))):
            hits.append("country_lang_mismatch")

    # 5. webrtc_leak — WebRTC IP != IP and not empty/null
    ip = _detail_get(details, "Location", "IP Address")
    webrtc = _detail_get(details, "Location", "WebRTC IP Address")
    if ip and webrtc and webrtc not in ("", "null", "n/a") and webrtc != ip:
        hits.append("webrtc_leak")

    # 6. tiny_viewport — width < 1024
    resolution = _detail_get(details, "Screen", "Resolution")
    m = re.match(r"(\d+)x(\d+)", resolution)
    if m and int(m.group(1)) < 1024:
        hits.append("tiny_viewport")

    return hits


def sum_penalty(hits: Iterable[str]) -> int:
    """Sum of rule weights, capped at PENALTY_CAP."""
    total = sum(RULE_WEIGHTS.get(k, 0) for k in hits)
    return min(PENALTY_CAP, total)
