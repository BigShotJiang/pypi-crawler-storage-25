"""Pure parsers — html string -> raw dicts. No IO, no playwright.

Used by scraper after `inspect_html`, and by tests on committed fixtures.
"""
from __future__ import annotations
import re

from . import selectors as SEL


def parse_fingerprint(checks_grid_html: str, what_see_html: str,
                      status_bar_html: str | None = None) -> dict:
    """Return raw fingerprint dict.

    Output:
        {
          "headline": "consistent" | "inconsistent" | "unknown",
          "pills": [{"name", "value", "pass"}, ...],
          "details": {card_name: {label: value | [tags]}}
        }
    """
    grid = SEL.normalize_html(checks_grid_html)
    pills = []
    for m in SEL.RE_PILL_BLOCK.finditer(grid):
        failed = bool(m.group("failed"))
        value_html = m.group("value")
        value = SEL.normalize_html(re.sub(r"<[^>]+>", " ", value_html)).strip()
        pills.append({
            "name": m.group("label").strip(),
            "value": value,
            "pass": not failed,
        })

    details = parse_detail_cards(what_see_html)

    headline = "unknown"
    if status_bar_html:
        sb = SEL.normalize_html(status_bar_html)
        m = SEL.RE_FP_HEADLINE.search(sb)
        if m:
            txt = m.group("text").strip().lower()
            if "consistent" in txt and "inconsistent" not in txt:
                headline = "consistent"
            elif "inconsistent" in txt:
                headline = "inconsistent"
    elif "status-error" in grid:
        headline = "inconsistent"
    elif "status-success" in grid:
        headline = "consistent"

    return {"headline": headline, "pills": pills, "details": details}


def parse_detail_cards(html: str) -> dict[str, dict]:
    """Extract `pxlscn-checker-details-card` rows into {card_name: {label: value | [tags]}}.

    Tag-list fields stored as list[str]; scalar fields as str.
    """
    s = SEL.normalize_html(html)
    out: dict[str, dict] = {}
    for cm in SEL.RE_DETAIL_CARD.finditer(s):
        name = cm.group("name").strip().replace("&amp;", "&")
        body = cm.group("body")
        card: dict = {}
        # tag-list fields first (they wrap labels too)
        consumed_labels: set[str] = set()
        for tm in SEL.RE_DETAIL_TAG_BLOCK.finditer(body):
            label = tm.group("label").strip()
            tags = [t.strip() for t in SEL.RE_DETAIL_TAG.findall(tm.group("tags"))]
            card[label] = tags
            consumed_labels.add(label)
        # scalar label/value fields
        for fm in SEL.RE_DETAIL_FIELD.finditer(body):
            label = fm.group("label").strip()
            if label in consumed_labels:
                continue
            value = fm.group("value").strip()
            card[label] = value
        out[name] = card
    return out


def parse_bot(summary_html: str, header_state: str) -> dict:
    """Return raw bot dict.

    Output:
        {
          "verdict": "success" | "error" | "loading" | "timeout" | "default",
          "sections": {name: {"clear": int, "total": int, "score": float}},
          "total": int, "clear": int,
        }
    """
    s = SEL.normalize_html(summary_html)
    sections: dict[str, dict] = {}
    total_params = 0
    clear_params = 0
    for m in SEL.RE_BOT_SECTION.finditer(s):
        title = m.group("title").strip()
        count = int(m.group("count"))
        body = m.group("body")
        alert = bool(SEL.RE_BOT_ALERT.search(body))
        clear_n = 0 if alert else count
        sections[title] = {
            "clear": clear_n,
            "total": count,
            "score": (clear_n / count * 100.0) if count else 0.0,
            "detected": alert,
        }
        total_params += count
        clear_params += clear_n
    return {
        "verdict": header_state or "unknown",
        "sections": sections,
        "total": total_params,
        "clear": clear_params,
    }
