from __future__ import annotations
import json
import asyncio
from loguru import logger

from .registry import TOOL_REGISTRY, ALIASES, load_all, resolve
from .errors import ToolError
from ..config import settings


async def run_stdio() -> None:
    settings.ensure_dirs()
    load_all()
    try:
        from mcp.server import Server
        from mcp.server.stdio import stdio_server
        import mcp.types as mt
    except ImportError as e:
        raise SystemExit(f"mcp package missing: {e}")

    server = Server("pymcp_browser_v2")

    @server.list_tools()
    async def _list_tools():
        out = []
        for t in TOOL_REGISTRY.values():
            out.append(mt.Tool(name=t.name, description=t.description, inputSchema=t.schema))
        for alias, real in ALIASES.items():
            r = TOOL_REGISTRY[real]
            out.append(mt.Tool(name=alias, description=f"alias -> {real}: {r.description}",
                               inputSchema=r.schema))
        return out

    @server.call_tool()
    async def _call_tool(name: str, arguments: dict | None):
        t = resolve(name)
        if t is None:
            return [mt.TextContent(type="text",
                                   text=json.dumps({"error": {"code": "tool_not_found", "message": name}}))]
        try:
            result = await t.handler(**(arguments or {}))
            return [mt.TextContent(type="text", text=json.dumps(result, default=str))]
        except ToolError as e:
            return [mt.TextContent(type="text", text=json.dumps({"error": e.to_dict()}))]
        except Exception as e:
            logger.exception("mcp tool {} failed", name)
            return [mt.TextContent(type="text",
                                   text=json.dumps({"error": {"code": "internal", "message": str(e)}}))]

    async with stdio_server() as (read, write):
        await server.run(read, write, server.create_initialization_options())


def main() -> None:
    asyncio.run(run_stdio())
