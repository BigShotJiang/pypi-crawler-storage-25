from __future__ import annotations
from enum import Enum
from typing import Any


class ErrorCode(str, Enum):
    invalid_args = "invalid_args"
    target_not_found = "target_not_found"
    ref_stale = "ref_stale"
    session_not_found = "session_not_found"
    task_not_found = "task_not_found"
    permission_denied = "permission_denied"
    timeout = "timeout"
    captcha_unsolved = "captcha_unsolved"
    captcha_not_detected = "captcha_not_detected"
    proxy_unreachable = "proxy_unreachable"
    frame_not_found = "frame_not_found"
    tab_not_found = "tab_not_found"
    handler_not_found = "handler_not_found"
    dialog_not_present = "dialog_not_present"
    internal = "internal"
    mail_auth_failed = "mail_auth_failed"
    mail_account_not_found = "mail_account_not_found"
    mail_protocol = "mail_protocol"
    mail_attachment_too_large = "mail_attachment_too_large"
    mail_idle_unsupported = "mail_idle_unsupported"
    mail_rate_limited = "mail_rate_limited"
    capacity_exceeded = "capacity_exceeded"
    cancelled = "cancelled"
    totp_invalid_secret = "totp_invalid_secret"
    totp_label_exists = "totp_label_exists"
    totp_label_not_found = "totp_label_not_found"
    vault_label_exists = "vault_label_exists"
    vault_label_not_found = "vault_label_not_found"
    clipboard_unavailable = "clipboard_unavailable"
    clipboard_entry_not_found = "clipboard_entry_not_found"
    phone_invalid = "phone_invalid"
    card_unsupported_brand = "card_unsupported_brand"
    no_active_page = "no_active_page"
    diag_failed = "diag_failed"
    diag_not_found = "diag_not_found"
    proxy_country_unavailable = "proxy_country_unavailable"
    multi_resolve = "multi_resolve"
    invalid_name = "invalid_name"
    exists = "exists"
    schema_mismatch = "schema_mismatch"
    not_found = "not_found"
    engine_unsupported_feature = "engine_unsupported_feature"
    engine_install_missing = "engine_install_missing"
    engine_mismatch = "engine_mismatch"
    preflight_pixelscan_unreachable = "preflight_pixelscan_unreachable"
    preflight_dom_drift = "preflight_dom_drift"
    preflight_session_lost = "preflight_session_lost"
    preflight_timeout = "preflight_timeout"
    preflight_rate_limited = "preflight_rate_limited"
    preflight_failed = "preflight_failed"
    upload_failed = "upload_failed"


HTTP_STATUS = {
    ErrorCode.invalid_args: 400,
    ErrorCode.target_not_found: 404,
    ErrorCode.ref_stale: 409,
    ErrorCode.session_not_found: 404,
    ErrorCode.task_not_found: 404,
    ErrorCode.permission_denied: 403,
    ErrorCode.timeout: 408,
    ErrorCode.captcha_unsolved: 502,
    ErrorCode.captcha_not_detected: 404,
    ErrorCode.proxy_unreachable: 502,
    ErrorCode.frame_not_found: 404,
    ErrorCode.tab_not_found: 404,
    ErrorCode.handler_not_found: 404,
    ErrorCode.dialog_not_present: 404,
    ErrorCode.internal: 500,
    ErrorCode.mail_auth_failed: 401,
    ErrorCode.mail_account_not_found: 404,
    ErrorCode.mail_protocol: 502,
    ErrorCode.mail_attachment_too_large: 413,
    ErrorCode.mail_idle_unsupported: 501,
    ErrorCode.mail_rate_limited: 429,
    ErrorCode.capacity_exceeded: 503,
    ErrorCode.cancelled: 499,
    ErrorCode.totp_invalid_secret: 400,
    ErrorCode.totp_label_exists: 409,
    ErrorCode.totp_label_not_found: 404,
    ErrorCode.vault_label_exists: 409,
    ErrorCode.vault_label_not_found: 404,
    ErrorCode.clipboard_unavailable: 503,
    ErrorCode.clipboard_entry_not_found: 404,
    ErrorCode.phone_invalid: 400,
    ErrorCode.card_unsupported_brand: 400,
    ErrorCode.no_active_page: 409,
    ErrorCode.diag_failed: 502,
    ErrorCode.diag_not_found: 404,
    ErrorCode.proxy_country_unavailable: 502,
    ErrorCode.multi_resolve: 409,
    ErrorCode.invalid_name: 400,
    ErrorCode.exists: 409,
    ErrorCode.schema_mismatch: 400,
    ErrorCode.not_found: 404,
    ErrorCode.engine_unsupported_feature: 501,
    ErrorCode.engine_install_missing: 503,
    ErrorCode.engine_mismatch: 409,
    ErrorCode.preflight_pixelscan_unreachable: 502,
    ErrorCode.preflight_dom_drift: 502,
    ErrorCode.preflight_session_lost: 410,
    ErrorCode.preflight_timeout: 408,
    ErrorCode.preflight_rate_limited: 429,
    ErrorCode.preflight_failed: 412,
    ErrorCode.upload_failed: 502,
}


class ToolError(Exception):
    def __init__(self, code: str, message: str = "", *, hint: str | None = None,
                 details: dict[str, Any] | None = None, **kwargs):
        self.code = code
        self.message = message or code
        self.hint = hint
        self.details = details or {}
        if kwargs:
            self.details.update(kwargs)
        super().__init__(self.message)

    def to_dict(self) -> dict[str, Any]:
        d: dict[str, Any] = {"code": self.code, "message": self.message}
        if self.hint:
            d["hint"] = self.hint
        if self.details:
            d["details"] = self.details
        return d

    @property
    def http_status(self) -> int:
        try:
            return HTTP_STATUS[ErrorCode(self.code)]
        except (KeyError, ValueError):
            return 500
