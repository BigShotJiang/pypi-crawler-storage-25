from __future__ import annotations
from typing import Any
from pathlib import Path

from fastapi import FastAPI, Body, Depends, HTTPException, Request
from fastapi.responses import FileResponse, JSONResponse
from loguru import logger

from .registry import TOOL_REGISTRY, ALIASES, load_all, resolve
from .errors import ToolError
from .auth import auth_gate
from ..config import settings


def make_handler(tool_name: str):
    async def endpoint(request: Request, _auth=Depends(auth_gate)) -> Any:
        body: dict = {}
        try:
            if (request.headers.get("content-length") or "0") != "0":
                body = await request.json()
        except Exception:
            body = {}
        if not isinstance(body, dict):
            raise HTTPException(status_code=400, detail={"code": "invalid_args",
                                                         "message": "body must be JSON object"})
        t = resolve(tool_name)
        if t is None:
            raise HTTPException(status_code=404, detail={"code": "tool_not_found",
                                                         "message": tool_name})
        try:
            result = await t.handler(**body)
            return result if result is not None else {"ok": True}
        except ToolError as e:
            return JSONResponse(status_code=e.http_status,
                                content={"error": e.to_dict()})
        except TypeError as e:
            return JSONResponse(status_code=400,
                                content={"error": {"code": "invalid_args", "message": str(e)}})
        except Exception as e:
            logger.exception("tool {} failed", tool_name)
            return JSONResponse(status_code=500,
                                content={"error": {"code": "internal", "message": str(e)}})
    endpoint.__name__ = f"call_{tool_name.replace('.', '_')}"
    return endpoint


def create_app() -> FastAPI:
    settings.ensure_dirs()
    load_all()
    app = FastAPI(title="PyMCP_Browser v2", version="2.0.0")

    @app.get("/")
    async def root():
        return {"service": "pymcp_browser_v2", "tools": len(TOOL_REGISTRY)}

    @app.get("/tools")
    async def list_tools(_auth=Depends(auth_gate)):
        return {
            "tools": [{"name": t.name, "scope": t.scope, "description": t.description}
                      for t in TOOL_REGISTRY.values()],
            "aliases": dict(ALIASES),
        }

    for name in TOOL_REGISTRY:
        app.post(f"/tools/{name}", name=name)(make_handler(name))
    for alias, real in ALIASES.items():
        app.post(f"/tools/{alias}", name=alias)(make_handler(real))

    @app.get("/preflight/reports/{report_id}")
    async def serve_preflight_report(report_id: str):
        # Anonymous read by design (Filen fallback target).
        from ..preflight import store as _pf_store
        row = _pf_store.get(report_id)
        if row is None:
            raise HTTPException(status_code=404,
                                detail={"code": "not_found",
                                        "message": f"report {report_id} not found"})
        p = Path(row["json_path"])
        if not p.is_file():
            raise HTTPException(status_code=410,
                                detail={"code": "gone",
                                        "message": "json blob missing on disk"})
        return FileResponse(str(p), media_type="application/json",
                            filename=f"{report_id}.json")

    return app


app = create_app()
