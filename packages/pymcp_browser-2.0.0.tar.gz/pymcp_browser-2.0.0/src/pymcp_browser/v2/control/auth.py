from __future__ import annotations
from fastapi import Header, HTTPException
from ..config import settings


async def auth_gate(authorization: str | None = Header(None)) -> dict:
    if settings.pymcp_no_auth:
        return {"dev_bypass": True, "scope": "admin"}
    if not authorization or not authorization.startswith("Bearer "):
        raise HTTPException(status_code=401, detail={"code": "permission_denied",
                                                     "message": "missing bearer token"})
    return {"scope": "admin", "token_label": authorization[7:15] + "..."}
