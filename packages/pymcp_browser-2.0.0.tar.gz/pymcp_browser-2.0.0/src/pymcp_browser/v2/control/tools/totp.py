"""totp.* tools — RFC 6238 TOTP store + on-demand code generation.

Secrets stored plain in SQLite (TotpKey table). See ADR-0004.
"""
from __future__ import annotations
import hashlib
import time
from typing import Optional

import pyotp
from sqlmodel import select

_DIGEST_MAP = {"SHA1": hashlib.sha1, "SHA256": hashlib.sha256,
               "SHA512": hashlib.sha512}

from ..registry import tool
from ..errors import ToolError
from ...storage.db import session_scope
from ...storage.models import TotpKey


def _validate_secret(secret: str, digits: int, period: int) -> None:
    try:
        pyotp.TOTP(secret, digits=digits, interval=period).now()
    except Exception as e:
        raise ToolError("totp_invalid_secret", str(e))


@tool(name="totp.add", scope="admin",
      errors=["totp_invalid_secret", "totp_label_exists"],
      schema={"type": "object", "required": ["label", "secret"],
              "additionalProperties": False,
              "properties": {
                  "label": {"type": "string", "minLength": 1},
                  "secret": {"type": "string", "minLength": 8},
                  "issuer": {"type": "string"},
                  "digits": {"type": "integer", "default": 6,
                             "minimum": 6, "maximum": 8},
                  "period": {"type": "integer", "default": 30,
                             "minimum": 15, "maximum": 120},
                  "algorithm": {"type": "string", "default": "SHA1",
                                "enum": ["SHA1", "SHA256", "SHA512"]}}})
async def totp_add(label: str, secret: str, issuer: Optional[str] = None,
                   digits: int = 6, period: int = 30,
                   algorithm: str = "SHA1") -> dict:
    """Register TOTP secret. Validated by generating a code."""
    _validate_secret(secret, digits, period)
    with session_scope() as s:
        existing = s.exec(select(TotpKey).where(TotpKey.label == label)).first()
        if existing is not None:
            raise ToolError("totp_label_exists", label)
        s.add(TotpKey(label=label, secret=secret, issuer=issuer,
                      digits=digits, period=period, algorithm=algorithm,
                      created_ts=time.time()))
    return {"ok": True, "label": label}


@tool(name="totp.add_uri", scope="admin",
      errors=["totp_invalid_secret", "totp_label_exists", "invalid_args"],
      schema={"type": "object", "required": ["uri"],
              "additionalProperties": False,
              "properties": {
                  "uri": {"type": "string", "minLength": 1},
                  "label": {"type": "string"}}})
async def totp_add_uri(uri: str, label: Optional[str] = None) -> dict:
    """Register from otpauth:// URI (e.g. QR-scan output)."""
    try:
        otp = pyotp.parse_uri(uri)
    except Exception as e:
        raise ToolError("invalid_args", f"could not parse otpauth uri: {e}")
    if not isinstance(otp, pyotp.TOTP):
        raise ToolError("invalid_args", "only TOTP URIs supported")
    final_label = label or otp.name or "imported"
    issuer = otp.issuer
    digits = otp.digits
    period = otp.interval
    secret = otp.secret
    return await totp_add(label=final_label, secret=secret, issuer=issuer,
                          digits=digits, period=period)


@tool(name="totp.list", scope="read",
      errors=[],
      schema={"type": "object", "additionalProperties": False,
              "properties": {}})
async def totp_list() -> dict:
    """List registered TOTP keys (no secrets returned)."""
    with session_scope() as s:
        rows = s.exec(select(TotpKey).order_by(TotpKey.label)).all()
        return {"keys": [{
            "label": r.label, "issuer": r.issuer,
            "digits": r.digits, "period": r.period,
            "algorithm": r.algorithm, "created_ts": r.created_ts,
        } for r in rows]}


@tool(name="totp.code", scope="read",
      errors=["totp_label_not_found"],
      schema={"type": "object", "required": ["label"],
              "additionalProperties": False,
              "properties": {"label": {"type": "string"}}})
async def totp_code(label: str) -> dict:
    """Return current 6-digit code + seconds remaining in window."""
    with session_scope() as s:
        row = s.exec(select(TotpKey).where(TotpKey.label == label)).first()
        if row is None:
            raise ToolError("totp_label_not_found", label)
        digest = _DIGEST_MAP.get(row.algorithm, hashlib.sha1)
        totp = pyotp.TOTP(row.secret, digits=row.digits, interval=row.period,
                          digest=digest)
        code = totp.now()
        remaining_s = row.period - (int(time.time()) % row.period)
        return {"label": label, "code": code, "remaining_s": remaining_s}


@tool(name="totp.delete", scope="admin",
      errors=["totp_label_not_found"],
      schema={"type": "object", "required": ["label"],
              "additionalProperties": False,
              "properties": {"label": {"type": "string"}}})
async def totp_delete(label: str) -> dict:
    """Remove a TOTP key by label."""
    with session_scope() as s:
        row = s.exec(select(TotpKey).where(TotpKey.label == label)).first()
        if row is None:
            raise ToolError("totp_label_not_found", label)
        s.delete(row)
    return {"ok": True}
