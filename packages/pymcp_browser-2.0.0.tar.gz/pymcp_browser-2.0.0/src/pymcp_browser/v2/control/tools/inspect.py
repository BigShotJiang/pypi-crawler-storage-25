"""inspect.* tools."""
from __future__ import annotations
import base64
import time
from pathlib import Path
from ..registry import tool
from ..errors import ToolError
from ...config import settings
from ...core.session import SessionRegistry
from ...core.snapshot import snapshot_page
from ...core.target_resolver import resolve_target, resolve_page

_S = SessionRegistry.get


@tool(name="inspect.snapshot", scope="read", alias="snapshot",
      errors=["session_not_found"],
      schema={"type": "object", "required": ["session_id"], "properties": {
          "session_id": {"type": "string"}, "tab_id": {"type": "string"},
          "depth": {"type": "integer"}, "boxes": {"type": "boolean"},
          "interesting_only": {"type": "boolean", "default": True},
          "max_chars": {"type": "integer", "default": 12000}}})
async def inspect_snapshot(session_id: str, tab_id: str | None = None,
                           depth: int | None = None, boxes: bool = False,
                           interesting_only: bool = True,
                           max_chars: int = 12000) -> dict:
    s = _S().lookup(session_id)
    page = s.tab_id_map.get(tab_id) if tab_id else s.active_page()
    if page is None:
        raise ToolError("tab_not_found" if tab_id else "session_not_found", str(tab_id or session_id))
    page_idx = s.pages.index(page)
    yaml, added, trunc = await snapshot_page(
        page, page_idx, s.ref_store,
        depth=depth, boxes=boxes,
        interesting_only=interesting_only, max_chars=max_chars,
    )
    return {"yaml": yaml, "ref_count": added, "snapshot_id": int(time.time()*1000),
            "truncated": trunc}


@tool(name="inspect.dom_summary", scope="read", errors=["session_not_found"],
      schema={"type": "object", "required": ["session_id"], "properties": {
          "session_id": {"type": "string"}, "tab_id": {"type": "string"},
          "max_inputs": {"type": "integer", "default": 50},
          "max_buttons": {"type": "integer", "default": 50}}})
async def inspect_dom_summary(session_id: str, tab_id: str | None = None,
                              max_inputs: int = 50, max_buttons: int = 50) -> dict:
    s = _S().lookup(session_id)
    page = s.tab_id_map.get(tab_id) if tab_id else s.active_page()
    if page is None:
        raise ToolError("tab_not_found" if tab_id else "session_not_found", str(tab_id or session_id))
    js = """
    ({mi, mb}) => {
      const inputs = Array.from(document.querySelectorAll('input,textarea,select')).slice(0, mi).map(el => ({
        tag: el.tagName.toLowerCase(), type: el.type || null, name: el.name || null,
        id: el.id || null, placeholder: el.placeholder || null,
      }));
      const buttons = Array.from(document.querySelectorAll('button,[role=button],input[type=submit]')).slice(0, mb).map(el => ({
        text: (el.innerText||el.value||'').trim().slice(0,80), id: el.id||null
      }));
      const iframes = Array.from(document.querySelectorAll('iframe')).map(el => ({
        src: el.src||null, name: el.name||null, title: el.title||null
      }));
      const forms = Array.from(document.querySelectorAll('form')).map(el => ({
        id: el.id||null, action: el.action||null, method: el.method||null,
        field_count: el.elements ? el.elements.length : 0
      }));
      return {url: location.href, title: document.title, inputs, buttons, iframes, forms};
    }
    """
    return await page.evaluate(js, {"mi": max_inputs, "mb": max_buttons})


@tool(name="inspect.screenshot", scope="read", alias="screenshot",
      errors=["session_not_found", "target_not_found", "ref_stale"],
      schema={"type": "object", "required": ["session_id"], "properties": {
          "session_id": {"type": "string"}, "target": {"type": "string"},
          "full_page": {"type": "boolean", "default": False},
          "format": {"type": "string", "enum": ["png", "jpeg"], "default": "png"},
          "quality": {"type": "integer"},
          "omit_background": {"type": "boolean", "default": False}}})
async def inspect_screenshot(session_id: str, target: str | None = None,
                             full_page: bool = False, format: str = "png",
                             quality: int | None = None,
                             omit_background: bool = False) -> dict:
    s = _S().lookup(session_id)
    page = await resolve_page(s)
    out_dir = Path(settings.screenshot_dir) / s.id
    out_dir.mkdir(parents=True, exist_ok=True)
    path = out_dir / f"{int(time.time()*1000)}.{format}"
    kw: dict = {"path": str(path), "type": format, "omit_background": omit_background}
    if quality and format == "jpeg":
        kw["quality"] = quality
    if target:
        h = await resolve_target(s, target)
        if hasattr(h, "screenshot"):
            data = await h.screenshot(**{k: v for k, v in kw.items() if k != "type" or v == "jpeg"})
        else:
            data = await h.screenshot(path=str(path), type=format)
    else:
        kw["full_page"] = full_page
        data = await page.screenshot(**kw)
    size = path.stat().st_size if path.exists() else (len(data) if data else 0)
    out = {"path": str(path), "size_bytes": size, "format": format,
           "width": s.viewport["width"], "height": s.viewport["height"]}
    if size and size < 256 * 1024:
        try:
            out["base64"] = base64.b64encode(path.read_bytes()).decode("ascii")
        except Exception:
            pass
    return out


async def _h_or_loc(s, target: str):
    h = await resolve_target(s, target)
    return h


@tool(name="inspect.text", scope="read", errors=["target_not_found", "ref_stale"],
      schema={"type": "object", "required": ["session_id", "target"], "properties": {
          "session_id": {"type": "string"}, "target": {"type": "string"}}})
async def inspect_text(session_id: str, target: str) -> dict:
    s = _S().lookup(session_id)
    h = await _h_or_loc(s, target)
    txt = await (h.inner_text() if hasattr(h, "inner_text") else h.text_content())
    return {"text": txt or ""}


@tool(name="inspect.html", scope="read", errors=["session_not_found", "ref_stale"],
      schema={"type": "object", "required": ["session_id"], "properties": {
          "session_id": {"type": "string"}, "target": {"type": "string"},
          "max_chars": {"type": "integer", "default": 50000}}})
async def inspect_html(session_id: str, target: str | None = None,
                       max_chars: int = 50000) -> dict:
    s = _S().lookup(session_id)
    if target:
        h = await _h_or_loc(s, target)
        try:
            html = await h.evaluate("el => el.outerHTML")
        except Exception as e:
            # D16: strict-mode multi-resolve diagnostic
            msg = str(e).lower()
            if "strict mode" in msg or "resolved to" in msg:
                page = await resolve_page(s)
                try:
                    catalog = await page.evaluate(
                        "(sel) => Array.from(document.querySelectorAll(sel)).slice(0, 5)"
                        ".map(el => el.outerHTML.slice(0, 200))",
                        target,
                    )
                    count = await page.evaluate(
                        "(sel) => document.querySelectorAll(sel).length", target,
                    )
                except Exception:
                    catalog, count = [], None
                raise ToolError("multi_resolve",
                                f"selector resolved to {count} elements; refine with :nth=N or :first")
            raise
    else:
        page = await resolve_page(s)
        html = await page.content()
    truncated = False
    full_len = len(html) if html else 0
    if max_chars and html and full_len > max_chars:
        html = html[:max_chars] + f"\n<!-- truncated {full_len - max_chars} chars -->"
        truncated = True
    return {"html": html, "truncated": truncated, "full_length": full_len}


@tool(name="inspect.attr", scope="read", errors=["target_not_found", "ref_stale"],
      schema={"type": "object", "required": ["session_id", "target", "name"], "properties": {
          "session_id": {"type": "string"}, "target": {"type": "string"},
          "name": {"type": "string"}}})
async def inspect_attr(session_id: str, target: str, name: str) -> dict:
    s = _S().lookup(session_id)
    h = await _h_or_loc(s, target)
    val = await h.get_attribute(name) if hasattr(h, "get_attribute") else await h.evaluate(f"(el, n) => el.getAttribute(n)", name)
    return {"value": val}


@tool(name="inspect.value", scope="read", errors=["target_not_found", "ref_stale"],
      schema={"type": "object", "required": ["session_id", "target"], "properties": {
          "session_id": {"type": "string"}, "target": {"type": "string"}}})
async def inspect_value(session_id: str, target: str) -> dict:
    s = _S().lookup(session_id)
    h = await _h_or_loc(s, target)
    val = await h.evaluate("el => el.value")
    return {"value": val}


@tool(name="inspect.bbox", scope="read", errors=["target_not_found", "ref_stale"],
      schema={"type": "object", "required": ["session_id", "target"], "properties": {
          "session_id": {"type": "string"}, "target": {"type": "string"}}})
async def inspect_bbox(session_id: str, target: str) -> dict:
    s = _S().lookup(session_id)
    h = await _h_or_loc(s, target)
    bbox = await (h.bounding_box() if hasattr(h, "bounding_box") else h.evaluate(
        "el => { const r = el.getBoundingClientRect(); return {x:r.x,y:r.y,width:r.width,height:r.height}; }"))
    if bbox is None:
        raise ToolError("target_not_found", "no bbox")
    return {"x": bbox["x"], "y": bbox["y"], "width": bbox["width"], "height": bbox["height"]}


@tool(name="inspect.visible", scope="read", errors=["target_not_found", "ref_stale"],
      schema={"type": "object", "required": ["session_id", "target"], "properties": {
          "session_id": {"type": "string"}, "target": {"type": "string"}}})
async def inspect_visible(session_id: str, target: str) -> dict:
    s = _S().lookup(session_id)
    h = await _h_or_loc(s, target)
    if hasattr(h, "is_visible"):
        return {"visible": await h.is_visible()}
    return {"visible": await h.evaluate("el => !!(el.offsetWidth || el.offsetHeight || el.getClientRects().length)")}


@tool(name="inspect.enabled", scope="read", errors=["target_not_found", "ref_stale"],
      schema={"type": "object", "required": ["session_id", "target"], "properties": {
          "session_id": {"type": "string"}, "target": {"type": "string"}}})
async def inspect_enabled(session_id: str, target: str) -> dict:
    s = _S().lookup(session_id)
    h = await _h_or_loc(s, target)
    if hasattr(h, "is_enabled"):
        return {"enabled": await h.is_enabled()}
    return {"enabled": await h.evaluate("el => !el.disabled")}


@tool(name="inspect.evaluate", scope="admin", errors=["session_not_found", "internal"],
      schema={"type": "object", "required": ["session_id", "js"], "properties": {
          "session_id": {"type": "string"}, "js": {"type": "string"},
          "target": {"type": "string"}, "args": {"type": "array"}}})
async def inspect_evaluate(session_id: str, js: str, target: str | None = None,
                           args: list | None = None) -> dict:
    s = _S().lookup(session_id)
    audit = Path(settings.evaluate_audit_log_dir) / f"evaluate-{time.strftime('%Y-%m-%d')}.log"
    audit.parent.mkdir(parents=True, exist_ok=True)
    try:
        with audit.open("a", encoding="utf-8") as f:
            f.write(f"{time.time()}\t{s.id}\t{js[:8000]}\n")
    except Exception:
        pass
    if target:
        h = await _h_or_loc(s, target)
        result = await h.evaluate(js, args[0] if args else None)
    else:
        page = await resolve_page(s)
        result = await page.evaluate(js, args[0] if args else None)
    return {"result": result}


@tool(name="inspect.clear_refs", scope="admin", errors=["session_not_found"],
      schema={"type": "object", "required": ["session_id"], "properties": {
          "session_id": {"type": "string"},
          "scope": {"type": "string", "enum": ["session", "tab"], "default": "session"},
          "tab_id": {"type": "string"}}})
async def inspect_clear_refs(session_id: str, scope: str = "session",
                             tab_id: str | None = None) -> dict:
    s = _S().lookup(session_id)
    if scope == "tab" and tab_id:
        page = s.tab_id_map.get(tab_id)
        if page is None:
            raise ToolError("tab_not_found", tab_id)
        n = s.ref_store.invalidate_page(s.pages.index(page))
    else:
        n = s.ref_store.clear()
    return {"cleared_count": n}
