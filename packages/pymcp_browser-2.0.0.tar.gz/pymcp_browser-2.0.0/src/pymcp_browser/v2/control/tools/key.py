"""key.* tools."""
from __future__ import annotations
import asyncio
import random
from ..registry import tool
from ..errors import ToolError
from ...core.session import SessionRegistry
from ...core.target_resolver import resolve_target, resolve_page
from playwright.async_api import TimeoutError as PWTimeout

_S = SessionRegistry.get


@tool(name="key.press", scope="write",
      schema={"type": "object", "required": ["session_id", "key"], "properties": {
          "session_id": {"type": "string"}, "key": {"type": "string"},
          "modifiers": {"type": "array"}}})
async def key_press(session_id: str, key: str, modifiers: list | None = None) -> dict:
    s = _S().lookup(session_id)
    page = await resolve_page(s)
    async with s.lock:
        combo = "+".join((modifiers or []) + [key])
        await page.keyboard.press(combo)
    return {"ok": True}


@tool(name="key.shortcut", scope="write",
      schema={"type": "object", "required": ["session_id", "combo"], "properties": {
          "session_id": {"type": "string"}, "combo": {"type": "string"}}})
async def key_shortcut(session_id: str, combo: str) -> dict:
    s = _S().lookup(session_id)
    page = await resolve_page(s)
    async with s.lock:
        await page.keyboard.press(combo)
    return {"ok": True}


@tool(name="key.type", scope="write",
      errors=["target_not_found", "ref_stale", "timeout"],
      schema={"type": "object", "required": ["session_id", "text"], "properties": {
          "session_id": {"type": "string"}, "target": {"type": "string"},
          "text": {"type": "string"}, "delay_ms": {"type": "integer", "default": 0}}})
async def key_type(session_id: str, text: str, target: str | None = None,
                   delay_ms: int = 0) -> dict:
    s = _S().lookup(session_id)
    if s.mode == "human":
        return await key_type_human(session_id=session_id, text=text, target=target)
    async with s.lock:
        if target:
            h = await resolve_target(s, target)
            try:
                await h.type(text, delay=delay_ms)
            except PWTimeout as e:
                raise ToolError("timeout", str(e))
        else:
            page = await resolve_page(s)
            await page.keyboard.type(text, delay=delay_ms)
    return {"ok": True}


@tool(name="key.type_human", scope="write",
      errors=["target_not_found", "ref_stale", "timeout"],
      schema={"type": "object", "required": ["session_id", "text"], "properties": {
          "session_id": {"type": "string"}, "target": {"type": "string"},
          "text": {"type": "string"},
          "delay_min_ms": {"type": "integer", "default": 55},
          "delay_max_ms": {"type": "integer", "default": 165},
          "mistakes_pct": {"type": "number", "default": 0}}})
async def key_type_human(session_id: str, text: str, target: str | None = None,
                         delay_min_ms: int = 55, delay_max_ms: int = 165,
                         mistakes_pct: float = 0.0) -> dict:
    s = _S().lookup(session_id)
    page = await resolve_page(s)
    async with s.lock:
        if target:
            h = await resolve_target(s, target)
            try:
                await h.click()
            except Exception:
                pass
        for ch in text:
            if mistakes_pct and random.random() < mistakes_pct:
                wrong = chr(random.randint(97, 122))
                await page.keyboard.type(wrong)
                await asyncio.sleep(random.uniform(delay_min_ms, delay_max_ms) / 1000)
                await page.keyboard.press("Backspace")
            await page.keyboard.type(ch)
            await asyncio.sleep(random.uniform(delay_min_ms, delay_max_ms) / 1000)
    return {"ok": True}


@tool(name="key.focus", scope="write",
      errors=["target_not_found", "ref_stale"],
      schema={"type": "object", "required": ["session_id", "target"], "properties": {
          "session_id": {"type": "string"}, "target": {"type": "string"}}})
async def key_focus(session_id: str, target: str) -> dict:
    s = _S().lookup(session_id)
    async with s.lock:
        h = await resolve_target(s, target)
        await (h.focus() if hasattr(h, "focus") else h.evaluate("el => el.focus()"))
    return {"ok": True}


@tool(name="key.blur", scope="write",
      errors=["target_not_found", "ref_stale"],
      schema={"type": "object", "required": ["session_id", "target"], "properties": {
          "session_id": {"type": "string"}, "target": {"type": "string"}}})
async def key_blur(session_id: str, target: str) -> dict:
    s = _S().lookup(session_id)
    async with s.lock:
        h = await resolve_target(s, target)
        await h.evaluate("el => el.blur()")
    return {"ok": True}
