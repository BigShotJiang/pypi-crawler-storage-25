"""mouse.* tools."""
from __future__ import annotations
import time
from ..registry import tool
from ..errors import ToolError
from ...core.session import SessionRegistry
from ...core.target_resolver import resolve_target, resolve_page
from ...core import human as _human
from playwright.async_api import TimeoutError as PWTimeout

_S = SessionRegistry.get


async def _click_impl(session_id: str, target: str | None, x: int | None, y: int | None,
                      button: str, click_count: int, modifiers: list | None,
                      timeout_ms: int, wait_state: str, scroll_into_view: bool,
                      force: bool, trial: bool, delay_ms: int,
                      precondition_hover: str | None = None) -> dict:
    s = _S().lookup(session_id)
    t0 = time.time()
    await _human.auto_wait_load(s)
    async with s.lock:
        # D-extra: hover-then-click combo (Phase 4.3) — for buttons revealed only on row hover.
        if precondition_hover:
            try:
                ph = await resolve_target(s, precondition_hover)
                await ph.hover(timeout=timeout_ms, force=False)
            except Exception:
                pass
        if target:
            h = await resolve_target(s, target)
            try:
                if scroll_into_view and hasattr(h, "scroll_into_view_if_needed"):
                    try:
                        await h.scroll_into_view_if_needed(timeout=timeout_ms)
                    except Exception:
                        pass
                if s.mode == "human":
                    try:
                        page = await resolve_page(s)
                        try:
                            box = await h.bounding_box()
                        except Exception:
                            box = None
                        if box:
                            jx, jy = _human.jitter_offset(s)
                            cx = box["x"] + box["width"] / 2 + jx
                            cy = box["y"] + box["height"] / 2 + jy
                            try:
                                await page.mouse.move(cx, cy, steps=8)
                            except Exception:
                                pass
                        await h.hover(timeout=timeout_ms, force=force)
                        await _human.hover_dwell(s)
                    except Exception:
                        pass
                kw = dict(button=button, click_count=click_count,
                          timeout=timeout_ms, force=force, trial=trial, delay=delay_ms)
                if modifiers:
                    kw["modifiers"] = modifiers
                await h.click(**kw)
            except PWTimeout as e:
                raise ToolError("timeout", str(e))
        elif x is not None and y is not None:
            page = await resolve_page(s)
            if s.mode == "human":
                jx, jy = _human.jitter_offset(s)
                try:
                    await page.mouse.move(x + jx, y + jy, steps=8)
                except Exception:
                    pass
                await _human.hover_dwell(s)
            kw = dict(button=button, click_count=click_count, delay=delay_ms)
            if modifiers:
                kw["modifiers"] = modifiers
            await page.mouse.click(x, y, **kw)
        else:
            raise ToolError("invalid_args", "target or (x,y) required")
    await _human.post_action_sleep(s)
    return {"ok": True, "target_resolved": target or f"{x},{y}",
            "ms": int((time.time() - t0) * 1000)}


@tool(name="mouse.click", scope="write", alias="click",
      errors=["target_not_found", "ref_stale", "timeout"],
      schema={"type": "object", "required": ["session_id"], "properties": {
          "session_id": {"type": "string"}, "target": {"type": "string"},
          "x": {"type": "integer"}, "y": {"type": "integer"},
          "button": {"type": "string", "enum": ["left", "right", "middle"], "default": "left"},
          "click_count": {"type": "integer", "default": 1},
          "modifiers": {"type": "array"},
          "timeout_ms": {"type": "integer", "default": 10000},
          "wait_state": {"type": "string", "default": "visible"},
          "scroll_into_view": {"type": "boolean", "default": True},
          "force": {"type": "boolean", "default": False},
          "trial": {"type": "boolean", "default": False},
          "delay_ms": {"type": "integer", "default": 0},
          "precondition_hover": {"type": "string",
              "description": "selector to hover before click (reveals row-hover buttons)"}}})
async def mouse_click(session_id: str, target: str | None = None,
                     x: int | None = None, y: int | None = None,
                     button: str = "left", click_count: int = 1,
                     modifiers: list | None = None,
                     timeout_ms: int = 10000, wait_state: str = "visible",
                     scroll_into_view: bool = True, force: bool = False,
                     trial: bool = False, delay_ms: int = 0,
                     precondition_hover: str | None = None) -> dict:
    return await _click_impl(session_id, target, x, y, button, click_count, modifiers,
                             timeout_ms, wait_state, scroll_into_view, force, trial,
                             delay_ms, precondition_hover)


@tool(name="mouse.dblclick", scope="write",
      errors=["target_not_found", "ref_stale", "timeout"],
      schema={"type": "object", "required": ["session_id"], "properties": {
          "session_id": {"type": "string"}, "target": {"type": "string"},
          "timeout_ms": {"type": "integer", "default": 10000},
          "force": {"type": "boolean", "default": False}}})
async def mouse_dblclick(session_id: str, target: str | None = None, **kw) -> dict:
    return await _click_impl(session_id, target, kw.get("x"), kw.get("y"),
                             kw.get("button", "left"), 2, kw.get("modifiers"),
                             kw.get("timeout_ms", 10000), kw.get("wait_state", "visible"),
                             kw.get("scroll_into_view", True), kw.get("force", False),
                             kw.get("trial", False), kw.get("delay_ms", 0))


@tool(name="mouse.right_click", scope="write",
      errors=["target_not_found", "ref_stale", "timeout"],
      schema={"type": "object", "required": ["session_id"], "properties": {
          "session_id": {"type": "string"}, "target": {"type": "string"}}})
async def mouse_right_click(session_id: str, target: str | None = None, **kw) -> dict:
    return await _click_impl(session_id, target, kw.get("x"), kw.get("y"),
                             "right", 1, kw.get("modifiers"),
                             kw.get("timeout_ms", 10000), kw.get("wait_state", "visible"),
                             kw.get("scroll_into_view", True), kw.get("force", False),
                             kw.get("trial", False), kw.get("delay_ms", 0))


@tool(name="mouse.hover", scope="write",
      errors=["target_not_found", "ref_stale", "timeout"],
      schema={"type": "object", "required": ["session_id", "target"], "properties": {
          "session_id": {"type": "string"}, "target": {"type": "string"},
          "timeout_ms": {"type": "integer", "default": 10000},
          "force": {"type": "boolean"}, "trial": {"type": "boolean"}}})
async def mouse_hover(session_id: str, target: str, timeout_ms: int = 10000,
                      force: bool = False, trial: bool = False) -> dict:
    s = _S().lookup(session_id)
    await _human.auto_wait_load(s)
    async with s.lock:
        h = await resolve_target(s, target)
        try:
            await h.hover(timeout=timeout_ms, force=force, trial=trial)
            if s.mode == "human":
                await _human.hover_dwell(s)
        except PWTimeout as e:
            raise ToolError("timeout", str(e))
    await _human.post_action_sleep(s)
    return {"ok": True}


@tool(name="mouse.move", scope="write",
      schema={"type": "object", "required": ["session_id", "x", "y"], "properties": {
          "session_id": {"type": "string"}, "x": {"type": "integer"},
          "y": {"type": "integer"}, "steps": {"type": "integer", "default": 1}}})
async def mouse_move(session_id: str, x: int, y: int, steps: int = 1) -> dict:
    s = _S().lookup(session_id)
    page = await resolve_page(s)
    if s.mode == "human":
        jx, jy = _human.jitter_offset(s)
        x += jx
        y += jy
        if steps < 4:
            steps = 8
    async with s.lock:
        await page.mouse.move(x, y, steps=steps)
    return {"ok": True}


@tool(name="mouse.down", scope="write",
      schema={"type": "object", "required": ["session_id"], "properties": {
          "session_id": {"type": "string"},
          "button": {"type": "string", "default": "left"}}})
async def mouse_down(session_id: str, button: str = "left") -> dict:
    s = _S().lookup(session_id)
    page = await resolve_page(s)
    async with s.lock:
        await page.mouse.down(button=button)
    return {"ok": True}


@tool(name="mouse.up", scope="write",
      schema={"type": "object", "required": ["session_id"], "properties": {
          "session_id": {"type": "string"},
          "button": {"type": "string", "default": "left"}}})
async def mouse_up(session_id: str, button: str = "left") -> dict:
    s = _S().lookup(session_id)
    page = await resolve_page(s)
    async with s.lock:
        await page.mouse.up(button=button)
    return {"ok": True}


@tool(name="mouse.drag", scope="write",
      schema={"type": "object", "required": ["session_id"], "properties": {
          "session_id": {"type": "string"},
          "source_target": {"type": "string"}, "source_xy": {"type": "array"},
          "target_target": {"type": "string"}, "target_xy": {"type": "array"},
          "steps": {"type": "integer", "default": 5}}})
async def mouse_drag(session_id: str, source_target: str | None = None,
                    source_xy: list | None = None, target_target: str | None = None,
                    target_xy: list | None = None, steps: int = 5) -> dict:
    s = _S().lookup(session_id)
    page = await resolve_page(s)
    async with s.lock:
        if source_target:
            h = await resolve_target(s, source_target)
            box = await h.bounding_box()
            sx, sy = box["x"] + box["width"] / 2, box["y"] + box["height"] / 2
        elif source_xy:
            sx, sy = source_xy[0], source_xy[1]
        else:
            raise ToolError("invalid_args", "source missing")
        if target_target:
            h = await resolve_target(s, target_target)
            box = await h.bounding_box()
            tx, ty = box["x"] + box["width"] / 2, box["y"] + box["height"] / 2
        elif target_xy:
            tx, ty = target_xy[0], target_xy[1]
        else:
            raise ToolError("invalid_args", "target missing")
        await page.mouse.move(sx, sy)
        await page.mouse.down()
        await page.mouse.move(tx, ty, steps=steps)
        await page.mouse.up()
    return {"ok": True}


@tool(name="mouse.scroll", scope="write",
      schema={"type": "object", "required": ["session_id"], "properties": {
          "session_id": {"type": "string"},
          "dx": {"type": "integer", "default": 0},
          "dy": {"type": "integer", "default": 0},
          "target": {"type": "string"},
          "behavior": {"type": "string", "default": "auto"}}})
async def mouse_scroll(session_id: str, dx: int = 0, dy: int = 0,
                      target: str | None = None, behavior: str = "auto") -> dict:
    s = _S().lookup(session_id)
    page = await resolve_page(s)
    async with s.lock:
        if target:
            h = await resolve_target(s, target)
            await h.evaluate(f"el => el.scrollBy({{left:{dx}, top:{dy}, behavior:'{behavior}'}})")
        else:
            await page.mouse.wheel(dx, dy)
        sy = await page.evaluate("() => window.scrollY")
    return {"ok": True, "scroll_y": sy}
