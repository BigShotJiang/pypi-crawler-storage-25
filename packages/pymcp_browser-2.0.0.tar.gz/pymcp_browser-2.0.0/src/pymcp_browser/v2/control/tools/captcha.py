"""captcha.* tools."""
from __future__ import annotations
import asyncio
import time
from ..registry import tool
from ..errors import ToolError
from ...core.session import SessionRegistry
from ...core.target_resolver import resolve_page
from ...core.captcha.detector import detect_captcha, inject_token
from ...core.captcha.resolver import solve as solver_solve

_S = SessionRegistry.get


_BANNER_JS = """
(opts) => {
  const old = document.getElementById('__pymcp_human_assist__');
  if (old) old.remove();
  const wrap = document.createElement('div');
  wrap.id = '__pymcp_human_assist__';
  wrap.style.cssText = `
    position:fixed; top:0; left:0; right:0; z-index:2147483647;
    background:linear-gradient(90deg,#222,#444);
    color:#fff; padding:14px 20px; font:600 14px/1.4 system-ui,sans-serif;
    box-shadow:0 4px 18px rgba(0,0,0,.4); display:flex; gap:14px;
    align-items:center; justify-content:space-between;
    border-bottom:3px solid #ffb000;`;
  wrap.innerHTML = `
    <div style="display:flex;align-items:center;gap:14px">
      <span style="font-size:22px">⚠</span>
      <div>
        <div style="font-size:15px">${opts.title || 'Manual action required'}</div>
        <div style="font-size:12px;color:#ffd980;font-weight:400;margin-top:2px">${opts.message || ''}</div>
      </div>
    </div>
    <button id="__pymcp_dismiss__" style="
      background:#ffb000;color:#222;border:0;padding:8px 16px;
      border-radius:4px;font:600 13px/1 system-ui;cursor:pointer">
      I solved it</button>`;
  document.documentElement.appendChild(wrap);
  document.getElementById('__pymcp_dismiss__').addEventListener('click', () => {
    window.__pymcp_assist_done__ = true;
    wrap.remove();
  });
}
"""


@tool(name="captcha.human_assist", scope="write", errors=["timeout", "session_not_found"],
      schema={"type": "object", "required": ["session_id"], "properties": {
          "session_id": {"type": "string"},
          "message": {"type": "string", "default": "Solve the captcha, then click 'I solved it' or wait for next page"},
          "title": {"type": "string", "default": "Manual action required"},
          "expected_url_substring": {"type": "string"},
          "expected_selector": {"type": "string"},
          "timeout_ms": {"type": "integer", "default": 300000},
          "poll_ms": {"type": "integer", "default": 1500}}})
async def captcha_human_assist(session_id: str,
                               message: str = "Solve the captcha, then click 'I solved it' or wait for next page",
                               title: str = "Manual action required",
                               expected_url_substring: str | None = None,
                               expected_selector: str | None = None,
                               timeout_ms: int = 300_000,
                               poll_ms: int = 1500) -> dict:
    """Pause script + show in-page banner. Wait for URL/selector match OR user-click 'I solved it'."""
    s = _S().lookup(session_id)
    page = await resolve_page(s)
    deadline = time.time() + (timeout_ms / 1000)
    start_url = page.url

    try:
        await page.evaluate(_BANNER_JS, {"title": title, "message": message})
    except Exception:
        pass

    s.events.push("session", kind="human_assist.start",
                  expected_url=expected_url_substring,
                  expected_sel=expected_selector)

    last_url_for_banner = page.url
    while time.time() < deadline:
        # URL match
        cur = page.url
        if expected_url_substring and expected_url_substring in cur and cur != start_url:
            await _clear_banner(page)
            return {"ok": True, "reason": "url_match", "url": cur,
                    "elapsed_ms": int(timeout_ms - (deadline - time.time()) * 1000)}

        # Selector match
        if expected_selector:
            try:
                visible = await page.evaluate(
                    "(sel) => { const el = document.querySelector(sel); "
                    "return !!el && !!(el.offsetWidth || el.offsetHeight || el.getClientRects().length); }",
                    expected_selector)
                if visible:
                    await _clear_banner(page)
                    return {"ok": True, "reason": "selector_match",
                            "url": cur, "selector": expected_selector}
            except Exception:
                pass

        # User click on banner
        try:
            done = await page.evaluate("() => !!window.__pymcp_assist_done__")
            if done:
                await _clear_banner(page)
                return {"ok": True, "reason": "user_dismissed", "url": cur}
        except Exception:
            pass

        # Re-inject banner if URL changed (page nav wipes DOM)
        if cur != last_url_for_banner:
            last_url_for_banner = cur
            try:
                await page.evaluate(_BANNER_JS, {"title": title, "message": message})
            except Exception:
                pass

        await asyncio.sleep(poll_ms / 1000)

    await _clear_banner(page)
    raise ToolError("timeout", f"human_assist timed out after {timeout_ms}ms")


async def _clear_banner(page):
    try:
        await page.evaluate(
            "() => { const e=document.getElementById('__pymcp_human_assist__'); if(e) e.remove(); "
            "window.__pymcp_assist_done__ = false; }")
    except Exception:
        pass


@tool(name="captcha.detect", scope="write", errors=["captcha_not_detected"],
      schema={"type": "object", "required": ["session_id"],
              "properties": {"session_id": {"type": "string"}}})
async def captcha_detect(session_id: str) -> dict:
    s = _S().lookup(session_id)
    page = await resolve_page(s)
    info = await detect_captcha(page)
    if info is None:
        raise ToolError("captcha_not_detected", "no captcha on page")
    return info


@tool(name="captcha.solve", scope="write", errors=["captcha_unsolved", "invalid_args"],
      schema={"type": "object", "required": ["session_id"], "properties": {
          "session_id": {"type": "string"}, "type": {"type": "string"},
          "sitekey": {"type": "string"}, "url": {"type": "string"},
          "provider": {"type": "string", "enum": ["capsolver", "twocaptcha"]}}})
async def captcha_solve(session_id: str, type: str | None = None,
                        sitekey: str | None = None, url: str | None = None,
                        provider: str = "capsolver",
                        invisible: bool | None = None,
                        action: str | None = None) -> dict:
    s = _S().lookup(session_id)
    page = await resolve_page(s)
    info: dict | None = None
    if not (type and sitekey) or invisible is None:
        info = await detect_captcha(page)
    if not (type and sitekey):
        if info is None:
            raise ToolError("captcha_unsolved", "type/sitekey missing and detection failed")
        type = type or info.get("type")
        sitekey = sitekey or info.get("sitekey")
    if invisible is None:
        invisible = bool((info or {}).get("invisible"))
    if action is None:
        action = (info or {}).get("action")
    url = url or page.url
    try:
        token, cid, ms = await solver_solve(type, sitekey, url, provider=provider,
                                            invisible=invisible, page_action=action)
    except Exception as e:
        raise ToolError("captcha_unsolved", str(e))
    return {"token": token, "provider": provider, "captcha_id": cid, "ms": ms}


@tool(name="captcha.inject", scope="write",
      schema={"type": "object", "required": ["session_id", "type", "token"], "properties": {
          "session_id": {"type": "string"}, "type": {"type": "string"},
          "token": {"type": "string"}}})
async def captcha_inject(session_id: str, type: str, token: str) -> dict:
    s = _S().lookup(session_id)
    page = await resolve_page(s)
    await inject_token(page, type, token)
    return {"ok": True}


@tool(name="captcha.auto", scope="write",
      schema={"type": "object", "required": ["session_id"], "properties": {
          "session_id": {"type": "string"}, "provider": {"type": "string"},
          "pre_submit": {"type": "boolean", "default": False,
              "description": "D12: synthetic blur on submit button to mount invisible reCAPTCHA Enterprise iframe before solving"},
          "submit_target": {"type": "string",
              "description": "selector for submit button (used when pre_submit=true)"}}})
async def captcha_auto(session_id: str, provider: str = "capsolver",
                       pre_submit: bool = False,
                       submit_target: str | None = None,
                       page_action_hint: str | None = None) -> dict:
    s = _S().lookup(session_id)
    page = await resolve_page(s)
    if pre_submit:
        # D12: dispatch synthetic blur/focus on submit button to force iframe mount.
        sel = submit_target or '[data-qa="button-submit"], button[type="submit"], input[type="submit"]'
        try:
            await page.evaluate(
                """(sel) => {
                    const el = document.querySelector(sel);
                    if (el) { el.dispatchEvent(new FocusEvent('focus')); el.dispatchEvent(new FocusEvent('blur')); }
                }""",
                sel,
            )
            await asyncio.sleep(0.6)  # let recaptcha iframe mount
        except Exception:
            pass
    info = await detect_captcha(page)
    if info is None:
        return {"solved": False, "reason": "captcha_not_detected"}
    sitekey = info.get("sitekey")
    cap_type = info.get("type")
    if not sitekey or not cap_type:
        return {"solved": False, "reason": "missing_sitekey_or_type"}
    try:
        # action priority: caller hint > info.action (auto-detected) > None
        action = page_action_hint or info.get("action")
        # Phase 2 — pull session proxy info so CapSolver tunnels through the
        # same egress as the browser. Avoids IP-mismatch flagging on targets
        # that re-check the captcha-solve IP.
        proxy_address, proxy_type, proxy_login, proxy_password = (
            _extract_session_proxy(s))
        token, cid, ms = await solver_solve(
            cap_type, sitekey, page.url, provider=provider,
            invisible=bool(info.get("invisible")),
            page_action=action,
            score_only=bool(info.get("score_only")),
            proxy_address=proxy_address,
            proxy_type=proxy_type,
            proxy_login=proxy_login,
            proxy_password=proxy_password,
        )
        await inject_token(page, cap_type, token)
        return {"solved": True, "type": cap_type, "token": token, "provider": provider,
                "score_only": bool(info.get("score_only")),
                "proxy_aligned": bool(proxy_address)}
    except Exception as e:
        return {"solved": False, "reason": str(e)}


def _extract_session_proxy(sess) -> tuple[str | None, str | None, str | None, str | None]:
    """Pull (address, type, login, password) from a session's proxy spec.

    Returns (None, None, None, None) when session has no proxy attached.
    """
    proxy_dict = getattr(sess, "proxy_spec", None) or getattr(sess, "_proxy_dict", None)
    if not proxy_dict:
        return (None, None, None, None)
    server = proxy_dict.get("server") or ""
    if "://" in server:
        scheme, host_port = server.split("://", 1)
    else:
        scheme, host_port = "http", server
    if not host_port:
        return (None, None, None, None)
    return (host_port, scheme,
            proxy_dict.get("username"), proxy_dict.get("password"))
