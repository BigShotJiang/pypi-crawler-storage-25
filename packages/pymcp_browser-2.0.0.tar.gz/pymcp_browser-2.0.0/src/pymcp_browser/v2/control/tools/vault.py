"""vault.* tools — password generator + credential vault.

Passwords stored plain in SQLite (VaultEntry table). See ADR-0004.
vault.list deliberately omits passwords; callers must hit vault.get per label.
"""
from __future__ import annotations
import secrets
import string
import time
from typing import Optional

from sqlmodel import select

from ..registry import tool
from ..errors import ToolError
from ...storage.db import session_scope
from ...storage.models import VaultEntry


_AMBIGUOUS = "Il1O0"


def _gen_password(length: int = 20, symbols: bool = True,
                  ambiguous: bool = False) -> str:
    chars = string.ascii_letters + string.digits
    if symbols:
        chars += "!@#$%^&*()-_=+[]{}"
    if not ambiguous:
        chars = "".join(c for c in chars if c not in _AMBIGUOUS)
    # Ensure at least one of each desired class
    for _ in range(50):
        pw = "".join(secrets.choice(chars) for _ in range(length))
        if (any(c.islower() for c in pw)
                and any(c.isupper() for c in pw)
                and any(c.isdigit() for c in pw)):
            return pw
    return pw  # fallback after 50 tries


@tool(name="vault.gen", scope="read", errors=[],
      schema={"type": "object", "additionalProperties": False,
              "properties": {
                  "length": {"type": "integer", "default": 20,
                             "minimum": 8, "maximum": 128},
                  "symbols": {"type": "boolean", "default": True},
                  "ambiguous": {"type": "boolean", "default": False}}})
async def vault_gen(length: int = 20, symbols: bool = True,
                    ambiguous: bool = False) -> dict:
    """Generate strong password. No DB write."""
    return {"password": _gen_password(length, symbols, ambiguous)}


@tool(name="vault.add", scope="admin",
      errors=["vault_label_exists"],
      schema={"type": "object", "required": ["label", "password"],
              "additionalProperties": False,
              "properties": {
                  "label": {"type": "string", "minLength": 1},
                  "password": {"type": "string", "minLength": 1},
                  "username": {"type": "string"},
                  "url": {"type": "string"},
                  "notes": {"type": "string"}}})
async def vault_add(label: str, password: str,
                    username: Optional[str] = None,
                    url: Optional[str] = None,
                    notes: Optional[str] = None) -> dict:
    """Save credential to vault."""
    now = time.time()
    with session_scope() as s:
        existing = s.exec(
            select(VaultEntry).where(VaultEntry.label == label)).first()
        if existing is not None:
            raise ToolError("vault_label_exists", label)
        s.add(VaultEntry(label=label, password=password, username=username,
                         url=url, notes=notes,
                         created_ts=now, updated_ts=now))
    return {"ok": True, "label": label}


@tool(name="vault.gen_and_add", scope="admin",
      errors=["vault_label_exists"],
      schema={"type": "object", "required": ["label"],
              "additionalProperties": False,
              "properties": {
                  "label": {"type": "string", "minLength": 1},
                  "length": {"type": "integer", "default": 20,
                             "minimum": 8, "maximum": 128},
                  "symbols": {"type": "boolean", "default": True},
                  "ambiguous": {"type": "boolean", "default": False},
                  "username": {"type": "string"},
                  "url": {"type": "string"},
                  "notes": {"type": "string"}}})
async def vault_gen_and_add(label: str, length: int = 20,
                            symbols: bool = True, ambiguous: bool = False,
                            username: Optional[str] = None,
                            url: Optional[str] = None,
                            notes: Optional[str] = None) -> dict:
    """Generate + save in one call. Returns the password."""
    pw = _gen_password(length, symbols, ambiguous)
    await vault_add(label=label, password=pw, username=username,
                    url=url, notes=notes)
    return {"ok": True, "label": label, "password": pw}


@tool(name="vault.get", scope="read",
      errors=["vault_label_not_found"],
      schema={"type": "object", "required": ["label"],
              "additionalProperties": False,
              "properties": {"label": {"type": "string"}}})
async def vault_get(label: str) -> dict:
    """Read full credential by label (includes password)."""
    with session_scope() as s:
        row = s.exec(select(VaultEntry).where(
            VaultEntry.label == label)).first()
        if row is None:
            raise ToolError("vault_label_not_found", label)
        return {
            "label": row.label, "username": row.username,
            "password": row.password, "url": row.url, "notes": row.notes,
            "created_ts": row.created_ts, "updated_ts": row.updated_ts,
        }


@tool(name="vault.list", scope="read", errors=[],
      schema={"type": "object", "additionalProperties": False,
              "properties": {}})
async def vault_list() -> dict:
    """List vault entries WITHOUT passwords (audit-friendly)."""
    with session_scope() as s:
        rows = s.exec(select(VaultEntry).order_by(VaultEntry.label)).all()
        return {"entries": [{
            "label": r.label, "username": r.username, "url": r.url,
            "notes": r.notes, "created_ts": r.created_ts,
            "updated_ts": r.updated_ts,
        } for r in rows]}


@tool(name="vault.update", scope="admin",
      errors=["vault_label_not_found"],
      schema={"type": "object", "required": ["label"],
              "additionalProperties": False,
              "properties": {
                  "label": {"type": "string"},
                  "password": {"type": "string"},
                  "username": {"type": "string"},
                  "url": {"type": "string"},
                  "notes": {"type": "string"}}})
async def vault_update(label: str, password: Optional[str] = None,
                       username: Optional[str] = None,
                       url: Optional[str] = None,
                       notes: Optional[str] = None) -> dict:
    """Update fields on existing entry. Omitted fields untouched."""
    with session_scope() as s:
        row = s.exec(select(VaultEntry).where(
            VaultEntry.label == label)).first()
        if row is None:
            raise ToolError("vault_label_not_found", label)
        if password is not None:
            row.password = password
        if username is not None:
            row.username = username
        if url is not None:
            row.url = url
        if notes is not None:
            row.notes = notes
        row.updated_ts = time.time()
        s.add(row)
    return {"ok": True}


@tool(name="vault.delete", scope="admin",
      errors=["vault_label_not_found"],
      schema={"type": "object", "required": ["label"],
              "additionalProperties": False,
              "properties": {"label": {"type": "string"}}})
async def vault_delete(label: str) -> dict:
    """Remove vault entry by label."""
    with session_scope() as s:
        row = s.exec(select(VaultEntry).where(
            VaultEntry.label == label)).first()
        if row is None:
            raise ToolError("vault_label_not_found", label)
        s.delete(row)
    return {"ok": True}
