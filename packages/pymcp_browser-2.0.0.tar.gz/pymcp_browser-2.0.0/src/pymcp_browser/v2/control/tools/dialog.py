"""dialog.* tools — alerts, confirm, prompt, downloads."""
from __future__ import annotations
import asyncio
import uuid
from pathlib import Path
from ..registry import tool
from ..errors import ToolError
from ...config import settings
from ...core.session import SessionRegistry
from ...core.target_resolver import resolve_page, resolve_target
from playwright.async_api import TimeoutError as PWTimeout

_S = SessionRegistry.get
_DOWNLOADS: dict[str, dict] = {}


@tool(name="dialog.handler", scope="write",
      schema={"type": "object", "required": ["session_id", "action"], "properties": {
          "session_id": {"type": "string"},
          "action": {"type": "string", "enum": ["accept", "dismiss"]},
          "prompt_text": {"type": "string"}}})
async def dialog_handler(session_id: str, action: str,
                         prompt_text: str | None = None) -> dict:
    s = _S().lookup(session_id)
    page = await resolve_page(s)

    async def handler(d):
        try:
            if action == "accept":
                await d.accept(prompt_text or "")
            else:
                await d.dismiss()
        except Exception:
            pass
    page.once("dialog", handler)
    return {"ok": True}


@tool(name="dialog.preempt", scope="write",
      schema={"type": "object", "required": ["session_id"], "properties": {
          "session_id": {"type": "string"},
          "action": {"type": "string", "enum": ["accept", "dismiss"], "default": "accept"},
          "count": {"type": "integer", "default": 1},
          "return_value": {"type": ["string", "boolean"]}}})
async def dialog_preempt(session_id: str, action: str = "accept",
                         count: int = 1,
                         return_value: str | bool | None = None) -> dict:
    """D7: override window.confirm/alert/prompt synchronously BEFORE the click that triggers them.

    Beats dialog_handler which races on the Playwright dialog event."""
    s = _S().lookup(session_id)
    page = await resolve_page(s)
    if return_value is None:
        return_value = True if action == "accept" else False
    js = """
    ({ count, ret }) => {
      const w = window;
      if (!w.__pymcp_dialog_orig) {
        w.__pymcp_dialog_orig = {
          confirm: w.confirm, alert: w.alert, prompt: w.prompt,
        };
      }
      let n = count;
      const orig = w.__pymcp_dialog_orig;
      const make = (name) => function(...args) {
        if (n-- > 0) {
          if (name === 'prompt') return (typeof ret === 'string' ? ret : (ret ? '' : null));
          if (name === 'alert') return undefined;
          return !!ret;
        }
        return orig[name].apply(w, args);
      };
      w.confirm = make('confirm');
      w.alert = make('alert');
      w.prompt = make('prompt');
      return { armed: count };
    }
    """
    result = await page.evaluate(js, {"count": count, "ret": return_value})
    return {"ok": True, "armed": result.get("armed", count)}


@tool(name="dialog.wait", scope="read", errors=["dialog_not_present"],
      schema={"type": "object", "required": ["session_id"], "properties": {
          "session_id": {"type": "string"},
          "timeout_ms": {"type": "integer", "default": 10000}}})
async def dialog_wait(session_id: str, timeout_ms: int = 10000) -> dict:
    s = _S().lookup(session_id)
    page = await resolve_page(s)
    try:
        d = await page.wait_for_event("dialog", timeout=timeout_ms)
    except PWTimeout:
        raise ToolError("dialog_not_present", "no dialog within timeout")
    return {"type": d.type, "message": d.message, "default_value": d.default_value}


@tool(name="dialog.download", scope="write", errors=["timeout"],
      schema={"type": "object", "required": ["session_id"], "properties": {
          "session_id": {"type": "string"},
          "trigger_target": {"type": "string"}, "trigger_js": {"type": "string"},
          "save_dir": {"type": "string"}}})
async def dialog_download(session_id: str, trigger_target: str | None = None,
                          trigger_js: str | None = None,
                          save_dir: str | None = None) -> dict:
    s = _S().lookup(session_id)
    page = await resolve_page(s)
    save_root = Path(save_dir or settings.download_dir) / s.id
    save_root.mkdir(parents=True, exist_ok=True)
    try:
        async with page.expect_download(timeout=30000) as info:
            if trigger_target:
                h = await resolve_target(s, trigger_target)
                await h.click()
            elif trigger_js:
                await page.evaluate(trigger_js)
            else:
                raise ToolError("invalid_args", "trigger_target or trigger_js required")
        dl = await info.value
    except PWTimeout as e:
        raise ToolError("timeout", str(e))
    suggested = dl.suggested_filename
    did = "d" + uuid.uuid4().hex[:8]
    final = save_root / suggested
    await dl.save_as(str(final))
    _DOWNLOADS.setdefault(s.id, {})[did] = {"path": str(final), "filename": suggested,
                                            "url": dl.url}
    return {"file_path": str(final), "suggested_filename": suggested,
            "size_bytes": final.stat().st_size if final.exists() else 0,
            "download_id": did}


@tool(name="dialog.cancel_download", scope="write",
      schema={"type": "object", "required": ["session_id", "download_id"], "properties": {
          "session_id": {"type": "string"}, "download_id": {"type": "string"}}})
async def dialog_cancel_download(session_id: str, download_id: str) -> dict:
    _DOWNLOADS.get(session_id, {}).pop(download_id, None)
    return {"ok": True}


@tool(name="dialog.list_downloads", scope="read",
      schema={"type": "object", "required": ["session_id"],
              "properties": {"session_id": {"type": "string"}}})
async def dialog_list_downloads(session_id: str) -> dict:
    items = _DOWNLOADS.get(session_id, {})
    return {"downloads": [{"download_id": k, **v} for k, v in items.items()]}
