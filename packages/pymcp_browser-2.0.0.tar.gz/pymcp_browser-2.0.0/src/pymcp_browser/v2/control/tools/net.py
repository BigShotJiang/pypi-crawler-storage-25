"""net.* tools."""
from __future__ import annotations
import re
import uuid
from ..registry import tool
from ..errors import ToolError
from ...core.session import SessionRegistry

_S = SessionRegistry.get


def _make_route_handler(action: str, response_spec: dict | None,
                        request_overrides: dict | None, hit_counter: dict):
    async def handler(route, request):
        hit_counter["n"] += 1
        try:
            if action == "block":
                await route.abort()
                return
            if action == "fulfill":
                spec = response_spec or {}
                await route.fulfill(status=spec.get("status", 200),
                                    headers=spec.get("headers", {}),
                                    body=spec.get("body", ""))
                return
            if action == "modify_request":
                ov = request_overrides or {}
                await route.continue_(headers=ov.get("headers"),
                                      post_data=ov.get("post_data"))
                return
            if action == "modify_response":
                resp = await route.fetch()
                spec = response_spec or {}
                body = spec.get("body")
                if body is None:
                    body = await resp.body()
                await route.fulfill(response=resp, body=body,
                                    headers=spec.get("headers"))
                return
            await route.continue_()
        except Exception:
            try:
                await route.continue_()
            except Exception:
                pass
    return handler


@tool(name="net.intercept", scope="admin", errors=["session_not_found", "invalid_args"],
      schema={"type": "object", "required": ["session_id", "url_pattern", "action"], "properties": {
          "session_id": {"type": "string"}, "url_pattern": {"type": "string"},
          "action": {"type": "string", "enum": ["block", "fulfill", "modify_request", "modify_response"]},
          "response": {"type": "object"}, "request_overrides": {"type": "object"},
          "persist": {"type": "boolean", "default": False}}})
async def net_intercept(session_id: str, url_pattern: str, action: str,
                        response: dict | None = None,
                        request_overrides: dict | None = None,
                        persist: bool = False) -> dict:
    s = _S().lookup(session_id)
    handler_id = "h" + uuid.uuid4().hex[:8]
    hit = {"n": 0}
    handler = _make_route_handler(action, response, request_overrides, hit)
    pat = re.compile(url_pattern.replace("*", ".*")) if "*" in url_pattern else url_pattern
    await s.context.route(pat if not isinstance(pat, str) else pat, handler)

    async def dispose():
        try:
            await s.context.unroute(pat, handler)
        except Exception:
            pass
    s.net_handlers[handler_id] = {
        "pattern": url_pattern, "action": action, "persist": persist,
        "hit_counter": hit, "dispose": dispose,
    }
    return {"handler_id": handler_id}


@tool(name="net.unintercept", scope="admin", errors=["handler_not_found"],
      schema={"type": "object", "required": ["session_id", "handler_id"], "properties": {
          "session_id": {"type": "string"}, "handler_id": {"type": "string"}}})
async def net_unintercept(session_id: str, handler_id: str) -> dict:
    s = _S().lookup(session_id)
    h = s.net_handlers.pop(handler_id, None)
    if h is None:
        raise ToolError("handler_not_found", handler_id)
    await h["dispose"]()
    return {"ok": True}


@tool(name="net.list_handlers", scope="read",
      schema={"type": "object", "required": ["session_id"],
              "properties": {"session_id": {"type": "string"}}})
async def net_list_handlers(session_id: str) -> dict:
    s = _S().lookup(session_id)
    return {"handlers": [{"handler_id": k, "pattern": v["pattern"], "action": v["action"],
                          "persist": v["persist"], "hit_count": v["hit_counter"]["n"]}
                         for k, v in s.net_handlers.items()]}


@tool(name="net.requests", scope="read",
      schema={"type": "object", "required": ["session_id"], "properties": {
          "session_id": {"type": "string"},
          "since_ts": {"type": "number"}, "url_filter": {"type": "string"},
          "status_filter": {"type": "integer"}, "limit": {"type": "integer", "default": 200}}})
async def net_requests(session_id: str, since_ts: float | None = None,
                       url_filter: str | None = None, status_filter: int | None = None,
                       limit: int = 200) -> dict:
    s = _S().lookup(session_id)
    evs = s.events.get(topics=["network"], since_ts=since_ts, limit=limit * 2)
    out = []
    for e in evs:
        if url_filter and url_filter not in e.get("url", ""):
            continue
        if status_filter is not None and e.get("status") != status_filter:
            continue
        out.append(e)
        if len(out) >= limit:
            break
    return {"requests": out}


@tool(name="net.req_body", scope="read", errors=["target_not_found"],
      schema={"type": "object", "required": ["session_id", "request_id"], "properties": {
          "session_id": {"type": "string"}, "request_id": {"type": "string"}}})
async def net_req_body(session_id: str, request_id: str) -> dict:
    raise ToolError("target_not_found", "request body not retained; use wait.request to capture")


@tool(name="net.resp_body", scope="read", errors=["target_not_found"],
      schema={"type": "object", "required": ["session_id", "request_id"], "properties": {
          "session_id": {"type": "string"}, "request_id": {"type": "string"}}})
async def net_resp_body(session_id: str, request_id: str) -> dict:
    raise ToolError("target_not_found", "response body not retained; use wait.response to capture")


@tool(name="net.offline", scope="admin",
      schema={"type": "object", "required": ["session_id", "offline"], "properties": {
          "session_id": {"type": "string"}, "offline": {"type": "boolean"}}})
async def net_offline(session_id: str, offline: bool) -> dict:
    s = _S().lookup(session_id)
    await s.context.set_offline(offline)
    return {"ok": True}


@tool(name="net.throttle", scope="admin",
      schema={"type": "object", "required": ["session_id"], "properties": {
          "session_id": {"type": "string"},
          "download_kbps": {"type": "integer"}, "upload_kbps": {"type": "integer"},
          "latency_ms": {"type": "integer"}}})
async def net_throttle(session_id: str, download_kbps: int | None = None,
                       upload_kbps: int | None = None,
                       latency_ms: int | None = None) -> dict:
    s = _S().lookup(session_id)
    eng = getattr(s, "engine", "chromium")
    if eng == "camoufox":
        raise ToolError(
            "engine_unsupported_feature",
            f"net.throttle requires chromium-family engine; current: {eng}",
        )
    page = s.active_page()
    try:
        client = await s.context.new_cdp_session(page)
        await client.send("Network.emulateNetworkConditions", {
            "offline": False,
            "latency": latency_ms or 0,
            "downloadThroughput": (download_kbps or 0) * 1024 / 8,
            "uploadThroughput": (upload_kbps or 0) * 1024 / 8,
        })
    except Exception as e:
        raise ToolError("internal", str(e))
    return {"ok": True}


@tool(name="net.headers", scope="admin",
      schema={"type": "object", "required": ["session_id", "headers"], "properties": {
          "session_id": {"type": "string"}, "headers": {"type": "object"}}})
async def net_headers(session_id: str, headers: dict) -> dict:
    s = _S().lookup(session_id)
    await s.context.set_extra_http_headers(headers)
    return {"ok": True}
