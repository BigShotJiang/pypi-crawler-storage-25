"""tab.* tools."""
from __future__ import annotations
from ..registry import tool
from ..errors import ToolError
from ...core.session import SessionRegistry

_S = SessionRegistry.get


@tool(name="tab.new", scope="write",
      schema={"type": "object", "required": ["session_id"], "properties": {
          "session_id": {"type": "string"}, "url": {"type": "string"}}})
async def tab_new(session_id: str, url: str | None = None) -> dict:
    s = _S().lookup(session_id)
    async with s.lock:
        page = await s.context.new_page()
        if page not in s.pages:
            tid = s.add_page(page)
        else:
            tid = s.tab_id_for(page) or "t?"
        if url:
            await page.goto(url)
    return {"tab_id": tid, "url": page.url}


@tool(name="tab.switch", scope="write", errors=["tab_not_found"],
      schema={"type": "object", "required": ["session_id", "tab_id"], "properties": {
          "session_id": {"type": "string"}, "tab_id": {"type": "string"}}})
async def tab_switch(session_id: str, tab_id: str) -> dict:
    s = _S().lookup(session_id)
    page = s.tab_id_map.get(tab_id)
    if page is None:
        raise ToolError("tab_not_found", tab_id)
    async with s.lock:
        await page.bring_to_front()
        if page in s.pages:
            s.pages.remove(page)
        s.pages.append(page)
        title = await page.title()
    return {"ok": True, "url": page.url, "title": title}


@tool(name="tab.close", scope="write", errors=["tab_not_found"],
      schema={"type": "object", "required": ["session_id", "tab_id"], "properties": {
          "session_id": {"type": "string"}, "tab_id": {"type": "string"}}})
async def tab_close(session_id: str, tab_id: str) -> dict:
    s = _S().lookup(session_id)
    page = s.tab_id_map.get(tab_id)
    if page is None:
        raise ToolError("tab_not_found", tab_id)
    async with s.lock:
        idx = s.pages.index(page) if page in s.pages else -1
        if idx >= 0:
            s.ref_store.invalidate_page(idx)
            s.pages.remove(page)
        s.tab_id_map.pop(tab_id, None)
        await page.close()
    return {"ok": True}


@tool(name="tab.list", scope="read",
      schema={"type": "object", "required": ["session_id"],
              "properties": {"session_id": {"type": "string"}}})
async def tab_list(session_id: str) -> dict:
    s = _S().lookup(session_id)
    active = s.active_page()
    out = []
    for tid, p in s.tab_id_map.items():
        try:
            title = await p.title()
        except Exception:
            title = ""
        out.append({"tab_id": tid, "url": p.url, "title": title, "active": p is active})
    return {"tabs": out}
