"""task.* tools."""
from __future__ import annotations
import asyncio
import time
import uuid
from ..registry import tool, TASK_REGISTRY
from ..errors import ToolError
from ...core.session import SessionRegistry

_S = SessionRegistry.get
_RESULTS: dict[str, dict] = {}  # task_id -> {state, result?, started_at, last_event, progress, error}


@tool(name="task.list", scope="read", schema={"type": "object", "properties": {}})
async def task_list() -> dict:
    return {"tasks": [{"name": t.name, "label": t.label,
                       "session_spec": t.session_spec, "auto_session": t.auto_session}
                      for t in TASK_REGISTRY.values()]}


def _new_task_id() -> str:
    return "tk" + uuid.uuid4().hex[:10]


async def _runner(task_id: str, fn, kwargs: dict, sid: str | None) -> None:
    state = _RESULTS[task_id]
    try:
        if sid:
            kwargs["session_id"] = sid
        result = await fn(**kwargs)
        state["result"] = result
        state["state"] = "done"
        state["last_event"] = time.time()
    except asyncio.CancelledError:
        state["state"] = "cancelled"
        state["last_event"] = time.time()
        raise
    except Exception as e:
        state["state"] = "error"
        state["error"] = {"code": "internal", "message": str(e)}
        state["last_event"] = time.time()


@tool(name="task.run", scope="write", errors=["task_not_found", "session_not_found", "internal"],
      schema={"type": "object", "required": ["name"], "properties": {
          "name": {"type": "string"}, "session_id": {"type": "string"},
          "args": {"type": "object",
                   "description": "Task-specific kwargs. For compiled macros, "
                                  "supports: clean (bool), speed (fast|natural|"
                                  "cautious), csv_logger, identity, "
                                  "strict_after_clean (bool), strict (bool), "
                                  "imap_email, imap_pass."},
          "auto_session": {"type": "boolean", "default": True},
          "max_wait_ms": {"type": "integer", "default": 60000},
          "async_": {"type": "boolean", "default": False}}})
async def task_run(name: str, session_id: str | None = None, args: dict | None = None,
                   auto_session: bool = True, max_wait_ms: int = 60000,
                   async_: bool = False) -> dict:
    t = TASK_REGISTRY.get(name)
    if t is None:
        raise ToolError("task_not_found", name)
    # D9 rot framework: warn if task selectors stale (>30 days since last_verified)
    from ..registry import task_rot_age_days, TASK_ROT_DAYS
    age = task_rot_age_days(t.last_verified)
    if age is not None and age > TASK_ROT_DAYS:
        from loguru import logger as _log
        _log.warning("task {} last verified {} ({}d ago); selectors may have rotted",
                     name, t.last_verified, age)
    args = args or {}
    sid = session_id
    if sid is None and auto_session and t.auto_session and t.session_spec:
        reg = _S()
        s = await reg.create(**t.session_spec)
        sid = s.id
    elif sid:
        _S().lookup(sid)

    task_id = _new_task_id()
    _RESULTS[task_id] = {"state": "running", "started_at": time.time(),
                         "progress": {}, "last_event": time.time()}
    coro = _runner(task_id, t.handler, dict(args), sid)
    bg = asyncio.create_task(coro)
    if sid:
        try:
            sess = _S().lookup(sid)
            sess.tasks[task_id] = bg
        except Exception:
            pass

    if async_:
        return {"state": "running", "task_id": task_id}
    try:
        await asyncio.wait_for(asyncio.shield(bg), timeout=max_wait_ms / 1000)
    except asyncio.TimeoutError:
        return {"state": "running", "task_id": task_id,
                "partial_progress": _RESULTS[task_id]["progress"]}
    st = _RESULTS[task_id]
    if st["state"] == "done":
        return {"state": "done", "task_id": task_id, "result": st["result"]}
    if st["state"] == "error":
        raise ToolError(st["error"]["code"], st["error"]["message"])
    return {"state": st["state"], "task_id": task_id}


@tool(name="task.status", scope="read", errors=["task_not_found"],
      schema={"type": "object", "required": ["task_id"], "properties": {"task_id": {"type": "string"}}})
async def task_status(task_id: str) -> dict:
    st = _RESULTS.get(task_id)
    if st is None:
        raise ToolError("task_not_found", task_id)
    return {"state": st["state"], "progress": st["progress"],
            "started_at": st["started_at"], "last_event": st["last_event"],
            "error": st.get("error")}


@tool(name="task.result", scope="read", errors=["task_not_found"],
      schema={"type": "object", "required": ["task_id"], "properties": {"task_id": {"type": "string"}}})
async def task_result(task_id: str) -> dict:
    st = _RESULTS.get(task_id)
    if st is None:
        raise ToolError("task_not_found", task_id)
    if st["state"] != "done":
        raise ToolError("task_not_found", f"task {task_id} not done (state={st['state']})")
    return {"state": "done", "result": st["result"]}


@tool(name="task.parallel", scope="write",
      errors=["task_not_found", "capacity_exceeded", "internal", "cancelled"],
      schema={"type": "object", "required": ["tasks"], "properties": {
          "tasks": {"type": "array", "items": {"type": "object",
              "required": ["name"],
              "properties": {
                  "name": {"type": "string"},
                  "args": {"type": "object"},
                  "session_spec": {"type": "object"},
                  "session_id": {"type": "string"}}}, "minItems": 1},
          "max_concurrency": {"type": "integer", "default": 4,
                              "minimum": 1, "maximum": 16},
          "fail_fast": {"type": "boolean", "default": False},
          "max_wait_ms": {"type": "integer", "default": 300000},
          "keep_sessions": {"type": "boolean", "default": False}}})
async def task_parallel(tasks: list[dict], max_concurrency: int = 4,
                        fail_fast: bool = False,
                        max_wait_ms: int = 300000,
                        keep_sessions: bool = False) -> dict:
    """Fan out N task invocations under semaphore-bounded concurrency."""
    sem = asyncio.Semaphore(max_concurrency)
    reg = _S()

    async def _one(spec: dict) -> dict:
        async with sem:
            t = TASK_REGISTRY.get(spec.get("name", ""))
            if t is None:
                return {"ok": False,
                        "error": {"code": "task_not_found",
                                  "message": spec.get("name", "")}}
            sid = spec.get("session_id")
            owns_session = False
            try:
                if sid is None and t.auto_session:
                    sess_spec = spec.get("session_spec") or t.session_spec or {}
                    s = await reg.create(**sess_spec)
                    sid = s.id
                    owns_session = True
                t0 = time.time()
                args = dict(spec.get("args") or {})
                if sid:
                    args["session_id"] = sid
                result = await t.handler(**args)
                return {"ok": True, "value": result, "session_id": sid,
                        "duration_ms": int((time.time() - t0) * 1000)}
            except ToolError as e:
                return {"ok": False, "error": e.to_dict(), "session_id": sid}
            except asyncio.CancelledError:
                return {"ok": False,
                        "error": {"code": "cancelled",
                                  "message": "fail_fast sibling"},
                        "session_id": sid}
            except Exception as e:
                return {"ok": False,
                        "error": {"code": "internal", "message": str(e)},
                        "session_id": sid}
            finally:
                if owns_session and sid and not keep_sessions:
                    try:
                        await reg.close(sid, persist=False)
                    except Exception:
                        pass

    bg = [asyncio.create_task(_one(s)) for s in tasks]
    timeout_s = max_wait_ms / 1000
    results: list[dict] = []
    if fail_fast:
        try:
            for fut in asyncio.as_completed(bg, timeout=timeout_s):
                r = await fut
                results.append(r)
                if not r["ok"]:
                    for tk in bg:
                        if not tk.done():
                            tk.cancel()
                    break
        finally:
            for tk in bg:
                if tk.done() and not tk.cancelled():
                    try:
                        rr = tk.result()
                        if rr not in results:
                            results.append(rr)
                    except Exception:
                        pass
                elif tk.cancelled():
                    results.append({"ok": False,
                                    "error": {"code": "cancelled",
                                              "message": "fail_fast sibling"}})
    else:
        try:
            results = await asyncio.wait_for(
                asyncio.gather(*bg, return_exceptions=False),
                timeout=timeout_s)
        except asyncio.TimeoutError:
            for tk in bg:
                if not tk.done():
                    tk.cancel()
            for tk in bg:
                try:
                    if tk.done() and not tk.cancelled():
                        results.append(tk.result())
                    else:
                        results.append({"ok": False,
                                        "error": {"code": "timeout",
                                                  "message": "max_wait_ms exceeded"}})
                except Exception as e:
                    results.append({"ok": False,
                                    "error": {"code": "internal",
                                              "message": str(e)}})
    return {
        "results": results,
        "ok_count": sum(1 for r in results if r.get("ok")),
        "fail_count": sum(1 for r in results if not r.get("ok")),
    }


@tool(name="task.run_history", scope="read",
      schema={"type": "object", "properties": {
          "macro_name": {"type": "string",
                         "description": "filter by macro name (substring match)"},
          "limit": {"type": "integer", "default": 50},
          "since_ts": {"type": "number"},
          "ok_only": {"type": "boolean", "default": False}}})
async def task_run_history(macro_name: str | None = None,
                            limit: int = 50,
                            since_ts: float | None = None,
                            ok_only: bool = False) -> dict:
    """Phase 5 — query MacroRun history written by macro_launcher engine."""
    from sqlmodel import select as _sel
    from ...storage.db import session_scope
    from ...storage.models import MacroRun
    out: list[dict] = []
    with session_scope() as db:
        stmt = _sel(MacroRun)
        if macro_name:
            stmt = stmt.where(MacroRun.macro_name.contains(macro_name))
        if since_ts is not None:
            stmt = stmt.where(MacroRun.started_ts >= since_ts)
        if ok_only:
            stmt = stmt.where(MacroRun.ok == True)  # noqa: E712
        stmt = stmt.order_by(MacroRun.started_ts.desc()).limit(limit)
        for r in db.exec(stmt).all():
            out.append({
                "id": r.id,
                "macro_name": r.macro_name,
                "identity_seed": r.identity_seed,
                "clean_mode": r.clean_mode,
                "unique_mode": r.unique_mode,
                "csv_logging": r.csv_logging,
                "loop_count": r.loop_count,
                "iteration": r.iteration,
                "started_ts": r.started_ts,
                "duration_ms": r.duration_ms,
                "ok": r.ok,
                "error_class": r.error_class,
                "proxy_egress_ip": r.proxy_egress_ip,
                "actual_country": r.actual_country,
                "csv_path": r.csv_path,
            })
    return {"runs": out, "count": len(out)}


@tool(name="task.stop", scope="write", errors=["task_not_found"],
      schema={"type": "object", "required": ["task_id"], "properties": {"task_id": {"type": "string"}}})
async def task_stop(task_id: str) -> dict:
    for s in _S().list():
        bg = s.tasks.get(task_id)
        if bg is not None:
            bg.cancel()
            return {"ok": True}
    if task_id in _RESULTS:
        return {"ok": True}
    raise ToolError("task_not_found", task_id)
