"""locate.* tools."""
from __future__ import annotations
from ..registry import tool
from ...core.session import SessionRegistry
from ...core.target_resolver import resolve_page

_S = SessionRegistry.get


async def _materialize(s, page, locator, limit: int, include_bbox: bool) -> list[dict]:
    out: list[dict] = []
    page_idx = s.pages.index(page)
    try:
        n = await locator.count()
    except Exception:
        n = 0
    for i in range(min(n, limit)):
        item = locator.nth(i)
        try:
            handle = await item.element_handle()
            if handle is None:
                continue
            role = await handle.evaluate("el => el.getAttribute && el.getAttribute('role')") or ""
            name = (await handle.evaluate(
                "el => el.getAttribute('aria-label') || el.innerText || el.value || ''") or "").strip()[:120]
            visible = True
            try:
                visible = await item.is_visible()
            except Exception:
                pass
            ref = s.ref_store.mint(page_idx, page.main_frame.url, handle, role, name)
            entry: dict = {"ref": ref, "role": role, "name": name, "visible": visible}
            if include_bbox:
                try:
                    bb = await handle.bounding_box()
                    if bb:
                        entry["bbox"] = bb
                except Exception:
                    pass
            out.append(entry)
        except Exception:
            continue
    return out


@tool(name="locate.text", scope="read",
      schema={"type": "object", "required": ["session_id", "text"], "properties": {
          "session_id": {"type": "string"}, "text": {"type": "string"},
          "exact": {"type": "boolean", "default": False},
          "role": {"type": "string"}, "limit": {"type": "integer", "default": 5},
          "include_bbox": {"type": "boolean", "default": True}}})
async def locate_text(session_id: str, text: str, exact: bool = False,
                      role: str | None = None, limit: int = 5,
                      include_bbox: bool = True) -> dict:
    s = _S().lookup(session_id)
    page = await resolve_page(s)
    loc = page.get_by_role(role, name=text, exact=exact) if role else page.get_by_text(text, exact=exact)
    matches = await _materialize(s, page, loc, limit, include_bbox)
    return {"matches": matches, "count": len(matches)}


@tool(name="locate.role", scope="read",
      schema={"type": "object", "required": ["session_id", "role"], "properties": {
          "session_id": {"type": "string"}, "role": {"type": "string"},
          "name": {"type": "string"}, "exact_name": {"type": "boolean", "default": False},
          "limit": {"type": "integer", "default": 5},
          "include_bbox": {"type": "boolean", "default": True}}})
async def locate_role(session_id: str, role: str, name: str | None = None,
                      exact_name: bool = False, limit: int = 5,
                      include_bbox: bool = True) -> dict:
    s = _S().lookup(session_id)
    page = await resolve_page(s)
    loc = page.get_by_role(role, name=name, exact=exact_name) if name else page.get_by_role(role)
    matches = await _materialize(s, page, loc, limit, include_bbox)
    return {"matches": matches, "count": len(matches)}


@tool(name="locate.label", scope="read",
      schema={"type": "object", "required": ["session_id", "label"], "properties": {
          "session_id": {"type": "string"}, "label": {"type": "string"},
          "limit": {"type": "integer", "default": 5},
          "include_bbox": {"type": "boolean", "default": True}}})
async def locate_label(session_id: str, label: str, limit: int = 5,
                       include_bbox: bool = True) -> dict:
    s = _S().lookup(session_id)
    page = await resolve_page(s)
    loc = page.get_by_label(label)
    matches = await _materialize(s, page, loc, limit, include_bbox)
    return {"matches": matches, "count": len(matches)}
