"""preflight.* tools — pixelscan-based pre-flight gate."""
from __future__ import annotations
import asyncio
from datetime import datetime
from typing import Optional

from loguru import logger

from ..registry import tool
from ..errors import ToolError
from ...config import settings
from ...preflight import scraper as PS, report as PR, store as ST, cache as CC, host as HOST
from ...preflight.rules import RULE_KEYS
from ...preflight.scorer import evaluate_gates

_HARD_FAIL_ENUM = list(RULE_KEYS)


def _resolve_hard_fail_on(hard_fail_on: Optional[list[str]]) -> list[str]:
    if hard_fail_on is not None:
        return hard_fail_on
    return [k.strip() for k in settings.preflight_hard_fails.split(",") if k.strip()]


def _resolve_weights(weights: Optional[dict]) -> dict:
    return weights or {"fp": settings.preflight_weights_fp,
                       "bot": settings.preflight_weights_bot}


@tool(
    name="preflight.run", scope="write",
    errors=["session_not_found", "preflight_pixelscan_unreachable",
            "preflight_dom_drift", "preflight_rate_limited",
            "preflight_session_lost", "preflight_timeout"],
    schema={
        "type": "object", "required": ["session_id"],
        "additionalProperties": False,
        "properties": {
            "session_id": {"type": "string"},
            "weights": {"type": "object", "additionalProperties": False,
                        "properties": {"fp": {"type": "number"},
                                       "bot": {"type": "number"}}},
            "expected_proxy": {"type": "string",
                               "enum": ["no_proxy", "proxy_detected", "any"]},
            "save_raw_html": {"type": "boolean", "default": False},
            "force": {"type": "boolean", "default": False},
        },
    },
)
async def preflight_run(session_id: str, weights: Optional[dict] = None,
                        expected_proxy: Optional[str] = None,
                        save_raw_html: bool = False,
                        force: bool = False) -> dict:
    """Scrape pixelscan, score, persist, return full report dict.

    Cache TTL respected unless force=True. Upload runs fire-and-forget after return.
    """
    if not force:
        cached = CC.get(session_id, ttl_s=settings.preflight_cache_ttl_s)
        if cached:
            return cached

    raw = await PS.scrape(session_id, save_raw_html=save_raw_html)
    rep = PR.build_report(raw, session_id=session_id,
                          weights=_resolve_weights(weights),
                          expected_proxy=expected_proxy,
                          diag=raw.get("diag"))
    json_path = PR.persist(rep, raw_html=raw.get("raw_html"))
    CC.put(session_id, rep)

    if settings.preflight_upload:
        asyncio.create_task(HOST.upload_report_async(rep["id"], json_path))

    return rep


@tool(
    name="preflight.check", scope="write",
    errors=["session_not_found", "preflight_pixelscan_unreachable",
            "preflight_dom_drift", "preflight_rate_limited",
            "preflight_session_lost", "preflight_timeout", "invalid_args"],
    schema={
        "type": "object", "required": ["session_id"],
        "additionalProperties": False,
        "properties": {
            "session_id": {"type": "string"},
            "min_total": {"type": "number"},
            "min_fp": {"type": "number"},
            "min_bot": {"type": "number"},
            "hard_fail_on": {"type": "array",
                             "items": {"enum": _HARD_FAIL_ENUM}},
            "weights": {"type": "object", "additionalProperties": False,
                        "properties": {"fp": {"type": "number"},
                                       "bot": {"type": "number"}}},
            "expected_proxy": {"type": "string",
                               "enum": ["no_proxy", "proxy_detected", "any"]},
            "raise_on_fail": {"type": "boolean", "default": False},
            "force": {"type": "boolean", "default": False},
        },
    },
)
async def preflight_check(session_id: str,
                          min_total: Optional[float] = None,
                          min_fp: Optional[float] = None,
                          min_bot: Optional[float] = None,
                          hard_fail_on: Optional[list[str]] = None,
                          weights: Optional[dict] = None,
                          expected_proxy: Optional[str] = None,
                          raise_on_fail: bool = False,
                          force: bool = False) -> dict:
    """Run preflight + gate evaluation in one call.

    Returns: {allowed, reason, hard_fails, report_id, total_score, fp_score, bot_score}.
    Raises `preflight_failed` only if `raise_on_fail=True` and allowed=False.
    """
    rep = await preflight_run(session_id=session_id, weights=weights,
                              expected_proxy=expected_proxy, force=force)
    th = {
        "min_total": settings.preflight_min_total if min_total is None else min_total,
        "min_fp":    settings.preflight_min_fp    if min_fp    is None else min_fp,
        "min_bot":   settings.preflight_min_bot   if min_bot   is None else min_bot,
    }
    hf = _resolve_hard_fail_on(hard_fail_on)
    gate = evaluate_gates(rep, min_total=th["min_total"], min_fp=th["min_fp"],
                          min_bot=th["min_bot"], hard_fail_on=hf)
    out = {
        "allowed": gate["allowed"],
        "reason": gate["reason"],
        "hard_fails": gate["hard_fails"],
        "report_id": rep["id"],
        "total_score": rep["total_score"],
        "fp_score": rep["fingerprint"]["score"],
        "bot_score": rep["bot"]["score"],
        "remote_url": rep.get("remote_url"),
    }
    if raise_on_fail and not gate["allowed"]:
        raise ToolError("preflight_failed", out["reason"], details=out)
    return out


@tool(
    name="preflight.report_get", scope="read",
    errors=["not_found"],
    schema={
        "type": "object", "required": ["report_id"],
        "additionalProperties": False,
        "properties": {"report_id": {"type": "string"}},
    },
)
async def preflight_report_get(report_id: str) -> dict:
    """Load full report JSON for given id."""
    rep = PR.read(report_id)
    if rep is None:
        raise ToolError("not_found", f"report {report_id} not found")
    return rep


@tool(
    name="preflight.index_list", scope="read",
    schema={
        "type": "object",
        "additionalProperties": False,
        "properties": {
            "limit": {"type": "integer", "default": 50, "minimum": 1, "maximum": 500},
            "since": {"type": "string", "description": "ISO8601 UTC; e.g. 2026-05-01T00:00:00Z"},
            "min_total": {"type": "number"},
            "verdict": {"type": "string", "enum": ["pass", "fail", "timeout"]},
            "engine": {"type": "string"},
            "session_id": {"type": "string"},
        },
    },
)
async def preflight_index_list(limit: int = 50, since: Optional[str] = None,
                               min_total: Optional[float] = None,
                               verdict: Optional[str] = None,
                               engine: Optional[str] = None,
                               session_id: Optional[str] = None) -> dict:
    """Query summary index newest-first."""
    since_dt = None
    if since:
        try:
            since_dt = datetime.fromisoformat(since.replace("Z", "+00:00"))
        except ValueError as e:
            raise ToolError("invalid_args", f"bad 'since' ISO8601: {e}")
    rows = ST.list_reports(limit=limit, since=since_dt, min_total=min_total,
                           verdict=verdict, engine=engine, session_id=session_id)
    return {"reports": rows, "count": len(rows)}


@tool(
    name="preflight.upload", scope="write",
    errors=["not_found", "upload_failed"],
    schema={
        "type": "object", "required": ["report_id"],
        "additionalProperties": False,
        "properties": {"report_id": {"type": "string"}},
    },
)
async def preflight_upload(report_id: str) -> dict:
    """Re-upload existing report to Filen (or local URL if unavailable)."""
    row = ST.get(report_id)
    if row is None:
        raise ToolError("not_found", f"report {report_id} not found")
    url = await asyncio.get_running_loop().run_in_executor(
        None, HOST.upload_report_sync, report_id, row["json_path"])
    if url:
        ST.set_remote_url(report_id, url)
    else:
        raise ToolError("upload_failed", "filen + fallback both failed")
    return {"report_id": report_id, "remote_url": url}
