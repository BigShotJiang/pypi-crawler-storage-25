"""persona.* tools — Faker-backed dummy data for form fills."""
from __future__ import annotations
from typing import Optional

from faker import Faker

from ..registry import tool
from ..errors import ToolError


_CACHE: dict[str, Faker] = {}


def _get_faker(locale: str, seed: Optional[int]) -> Faker:
    if seed is not None:
        f = Faker(locale)
        f.seed_instance(seed)
        return f
    if locale not in _CACHE:
        try:
            _CACHE[locale] = Faker(locale)
        except (AttributeError, ValueError) as e:
            raise ToolError("invalid_args", f"unsupported locale: {locale}: {e}")
    return _CACHE[locale]


def _build_persona(f: Faker) -> dict:
    first = f.first_name()
    last = f.last_name()
    return {
        "first_name": first,
        "last_name": last,
        "full_name": f"{first} {last}",
        "username": f.user_name(),
        "email": f.email(),
        "phone": f.phone_number(),
        "dob": f.date_of_birth(minimum_age=18, maximum_age=80).isoformat(),
        "address": {
            "street": f.street_address(),
            "city": f.city(),
            "state": f.state() if hasattr(f, "state") else None,
            "postcode": f.postcode(),
            "country": f.current_country() if hasattr(f, "current_country") else None,
        },
        "company": f.company(),
        "job": f.job(),
    }


@tool(name="persona.gen", scope="read",
      errors=["invalid_args"],
      schema={"type": "object", "additionalProperties": False,
              "properties": {
                  "locale": {"type": "string", "default": "en_US"},
                  "seed": {"type": "integer"}}})
async def persona_gen(locale: str = "en_US",
                      seed: Optional[int] = None) -> dict:
    """Generate full persona dict (name, email, phone, address, ...)."""
    f = _get_faker(locale, seed)
    return _build_persona(f)


_FIELD_MAP = {
    "first_name": "first_name",
    "last_name": "last_name",
    "name": "name",
    "email": "email",
    "username": "user_name",
    "phone": "phone_number",
    "dob": "date_of_birth",
    "street": "street_address",
    "city": "city",
    "state": "state",
    "postcode": "postcode",
    "company": "company",
    "job": "job",
    "url": "url",
    "ipv4": "ipv4",
    "uuid": "uuid4",
    "sentence": "sentence",
    "paragraph": "paragraph",
    "word": "word",
}


@tool(name="persona.field", scope="read",
      errors=["invalid_args"],
      schema={"type": "object", "required": ["kind"],
              "additionalProperties": False,
              "properties": {
                  "kind": {"type": "string",
                           "enum": list(_FIELD_MAP.keys())},
                  "locale": {"type": "string", "default": "en_US"},
                  "seed": {"type": "integer"}}})
async def persona_field(kind: str, locale: str = "en_US",
                        seed: Optional[int] = None) -> dict:
    """Generate a single field value."""
    if kind not in _FIELD_MAP:
        raise ToolError("invalid_args", f"unknown kind: {kind}")
    f = _get_faker(locale, seed)
    method = getattr(f, _FIELD_MAP[kind])
    val = method()
    if hasattr(val, "isoformat"):
        val = val.isoformat()
    return {"kind": kind, "value": str(val)}
