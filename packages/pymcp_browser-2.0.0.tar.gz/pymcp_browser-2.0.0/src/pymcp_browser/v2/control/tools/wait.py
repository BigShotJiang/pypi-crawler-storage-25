"""wait.* tools."""
from __future__ import annotations
import asyncio
from ..registry import tool
from ..errors import ToolError
from ...core.session import SessionRegistry
from ...core.target_resolver import resolve_target, resolve_page
from playwright.async_api import TimeoutError as PWTimeout

_S = SessionRegistry.get

# D4: when probe=True, override caller timeout to 5s for speculative checks.
PROBE_TIMEOUT_MS = 5000


def _resolve_timeout(timeout_ms: int, probe: bool) -> int:
    return PROBE_TIMEOUT_MS if probe else timeout_ms


@tool(name="wait.selector", scope="read", errors=["timeout"],
      schema={"type": "object", "required": ["session_id", "target"], "properties": {
          "session_id": {"type": "string"}, "target": {"type": "string"},
          "state": {"type": "string", "enum": ["visible", "hidden", "attached", "detached"],
                    "default": "visible"},
          "timeout_ms": {"type": "integer", "default": 10000},
          "probe": {"type": "boolean", "default": False}}})
async def wait_selector(session_id: str, target: str, state: str = "visible",
                       timeout_ms: int = 10000, probe: bool = False) -> dict:
    s = _S().lookup(session_id)
    page = await resolve_page(s)
    try:
        await page.wait_for_selector(target, state=state,
                                     timeout=_resolve_timeout(timeout_ms, probe))
    except PWTimeout as e:
        raise ToolError("timeout", str(e))
    return {"ok": True, "found": True}


@tool(name="wait.text", scope="read", errors=["timeout"],
      schema={"type": "object", "required": ["session_id", "text"], "properties": {
          "session_id": {"type": "string"}, "text": {"type": "string"},
          "exact": {"type": "boolean", "default": False},
          "timeout_ms": {"type": "integer", "default": 10000},
          "probe": {"type": "boolean", "default": False}}})
async def wait_text(session_id: str, text: str, exact: bool = False,
                   timeout_ms: int = 10000, probe: bool = False) -> dict:
    s = _S().lookup(session_id)
    page = await resolve_page(s)
    try:
        loc = page.get_by_text(text, exact=exact)
        await loc.first.wait_for(state="visible",
                                 timeout=_resolve_timeout(timeout_ms, probe))
    except PWTimeout as e:
        raise ToolError("timeout", str(e))
    return {"ok": True}


@tool(name="wait.url", scope="read", errors=["timeout"],
      schema={"type": "object", "required": ["session_id", "pattern"], "properties": {
          "session_id": {"type": "string"}, "pattern": {"type": "string"},
          "timeout_ms": {"type": "integer", "default": 10000},
          "probe": {"type": "boolean", "default": False}}})
async def wait_url(session_id: str, pattern: str, timeout_ms: int = 10000,
                  probe: bool = False) -> dict:
    s = _S().lookup(session_id)
    page = await resolve_page(s)
    try:
        await page.wait_for_url(pattern, timeout=_resolve_timeout(timeout_ms, probe))
    except PWTimeout as e:
        raise ToolError("timeout", str(e))
    return {"url": page.url}


@tool(name="wait.load", scope="read", errors=["timeout"],
      schema={"type": "object", "required": ["session_id"], "properties": {
          "session_id": {"type": "string"},
          "state": {"type": "string", "default": "load"},
          "timeout_ms": {"type": "integer", "default": 10000},
          "probe": {"type": "boolean", "default": False}}})
async def wait_load(session_id: str, state: str = "load", timeout_ms: int = 10000,
                   probe: bool = False) -> dict:
    s = _S().lookup(session_id)
    page = await resolve_page(s)
    try:
        await page.wait_for_load_state(state,
                                       timeout=_resolve_timeout(timeout_ms, probe))
    except PWTimeout as e:
        raise ToolError("timeout", str(e))
    return {"ok": True}


@tool(name="wait.request", scope="read", errors=["timeout"],
      schema={"type": "object", "required": ["session_id", "url_pattern"], "properties": {
          "session_id": {"type": "string"}, "url_pattern": {"type": "string"},
          "timeout_ms": {"type": "integer", "default": 10000}}})
async def wait_request(session_id: str, url_pattern: str, timeout_ms: int = 10000) -> dict:
    s = _S().lookup(session_id)
    page = await resolve_page(s)
    try:
        req = await page.wait_for_event("request",
                                        predicate=lambda r: url_pattern in r.url,
                                        timeout=timeout_ms)
    except PWTimeout as e:
        raise ToolError("timeout", str(e))
    return {"url": req.url, "method": req.method, "headers": dict(req.headers),
            "request_id": id(req)}


@tool(name="wait.response", scope="read", errors=["timeout"],
      schema={"type": "object", "required": ["session_id", "url_pattern"], "properties": {
          "session_id": {"type": "string"}, "url_pattern": {"type": "string"},
          "status": {"type": "integer"},
          "timeout_ms": {"type": "integer", "default": 10000}}})
async def wait_response(session_id: str, url_pattern: str, status: int | None = None,
                       timeout_ms: int = 10000) -> dict:
    s = _S().lookup(session_id)
    page = await resolve_page(s)

    def pred(r):
        if url_pattern not in r.url:
            return False
        if status is not None and r.status != status:
            return False
        return True

    try:
        resp = await page.wait_for_event("response", predicate=pred, timeout=timeout_ms)
    except PWTimeout as e:
        raise ToolError("timeout", str(e))
    return {"url": resp.url, "status": resp.status, "request_id": id(resp.request)}


@tool(name="wait.stable", scope="read", errors=["timeout", "target_not_found"],
      schema={"type": "object", "required": ["session_id", "target"], "properties": {
          "session_id": {"type": "string"}, "target": {"type": "string"},
          "debounce_ms": {"type": "integer", "default": 500},
          "timeout_ms": {"type": "integer", "default": 10000}}})
async def wait_stable(session_id: str, target: str, debounce_ms: int = 500,
                      timeout_ms: int = 10000) -> dict:
    """D6: resolve once target stops mutating for debounce_ms (DOM MutationObserver).

    Use instead of wait_load(networkidle) on SPAs with persistent analytics traffic."""
    s = _S().lookup(session_id)
    page = await resolve_page(s)
    js = """
    async ({ sel, debounce, deadlineMs }) => {
      const start = Date.now();
      const el = document.querySelector(sel);
      if (!el) return { ok: false, reason: 'not_found' };
      return await new Promise((resolve) => {
        let timer;
        const settle = () => { try { obs.disconnect(); } catch(e){} resolve({ ok: true, elapsed_ms: Date.now() - start }); };
        const obs = new MutationObserver(() => {
          clearTimeout(timer);
          timer = setTimeout(settle, debounce);
        });
        try { obs.observe(el, { childList: true, subtree: true, attributes: true, characterData: true }); }
        catch(e) { resolve({ ok: false, reason: 'observe_failed', error: String(e) }); return; }
        timer = setTimeout(settle, debounce);
        setTimeout(() => { try { obs.disconnect(); } catch(e){} resolve({ ok: false, reason: 'timeout', elapsed_ms: Date.now() - start }); }, deadlineMs);
      });
    }
    """
    result = await page.evaluate(js, {"sel": target, "debounce": debounce_ms,
                                       "deadlineMs": timeout_ms})
    if not result.get("ok"):
        reason = result.get("reason", "timeout")
        if reason == "not_found":
            raise ToolError("target_not_found", target)
        raise ToolError("timeout", f"wait_stable: {reason}")
    return result


@tool(name="wait.sleep", scope="read",
      schema={"type": "object", "required": ["ms"], "properties": {
          "session_id": {"type": "string"}, "ms": {"type": "integer"}}})
async def wait_sleep(ms: int, session_id: str | None = None) -> dict:
    if session_id:
        try:
            _S().lookup(session_id)
        except Exception:
            pass
    await asyncio.sleep(ms / 1000)
    return {"ok": True}
