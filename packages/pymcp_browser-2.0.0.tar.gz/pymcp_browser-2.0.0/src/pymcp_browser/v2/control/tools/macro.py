"""macro.* tools — driver for in-page macro recorder.

Recording control is normally driven by the in-page toolbar. These MCP tools
exist for headless / scripted control and for the compile step.
"""
from __future__ import annotations

from pathlib import Path

from ..registry import tool
from ..errors import ToolError
from ...config import settings
from ...core.session import SessionRegistry
from ...core.macro import MacroRecorder, compile_macro

_S = SessionRegistry.get


def _ensure_recorder(session_id: str) -> MacroRecorder:
    sess = _S().lookup(session_id)
    rec = getattr(sess, "macro", None)
    if rec is None:
        rec = MacroRecorder(sess.id, Path(settings.macros_dir))
        sess.macro = rec
    return rec


@tool(name="macro.start", scope="write",
      errors=["session_not_found", "engine_unsupported_feature", "internal"],
      schema={"type": "object", "required": ["session_id"], "properties": {
          "session_id": {"type": "string"},
          "label": {"type": "string"}}})
async def macro_start(session_id: str, label: str | None = None) -> dict:
    """Begin recording. Creates JSONL at MACROS_DIR/<sid>/macro_<ts>.jsonl."""
    sess = _S().lookup(session_id)
    eng = getattr(sess, "engine", "chromium")
    if eng == "camoufox":
        raise ToolError(
            "engine_unsupported_feature",
            f"macro.start requires chromium-family engine (MV3 extension); current: {eng}",
        )
    rec = _ensure_recorder(session_id)
    return rec.start(label=label)


@tool(name="macro.stop", scope="write",
      errors=["session_not_found", "internal"],
      schema={"type": "object", "required": ["session_id"], "properties": {
          "session_id": {"type": "string"}}})
async def macro_stop(session_id: str) -> dict:
    """Finalize JSONL. Returns {status, path, count}. Idempotent."""
    sess = _S().lookup(session_id)
    rec = getattr(sess, "macro", None)
    if rec is None:
        return {"status": "idle", "count": 0}
    return rec.stop()


@tool(name="macro.annotate", scope="write",
      errors=["session_not_found", "internal"],
      schema={"type": "object", "required": ["session_id", "label"], "properties": {
          "session_id": {"type": "string"},
          "label": {"type": "string"}}})
async def macro_annotate(session_id: str, label: str) -> dict:
    """Attach a label to the next captured event."""
    sess = _S().lookup(session_id)
    rec = getattr(sess, "macro", None)
    if rec is None:
        raise ToolError("not_found", "no recording active for this session")
    return rec.annotate(label)


@tool(name="macro.compile", scope="admin",
      errors=["invalid_name", "exists", "not_found", "schema_mismatch", "internal"],
      schema={"type": "object", "required": ["name"], "properties": {
          "name": {"type": "string"},
          "session_id": {"type": "string"},
          "path": {"type": "string"},
          "force": {"type": "boolean", "default": False}}})
async def macro_compile(name: str, session_id: str | None = None,
                        path: str | None = None, force: bool = False) -> dict:
    """Compile a recorded JSONL to tasks/macro_<name>.py and hot-register.

    Source priority: explicit `path` > MACROS_DIR/<session_id>/latest.jsonl.
    Generated task callable as `task.run name=macro_<name>`.
    """
    if path:
        src = Path(path)
    elif session_id:
        src = Path(settings.macros_dir) / session_id / "latest.jsonl"
    else:
        raise ToolError("invalid_args", "provide path or session_id")
    if not src.exists():
        raise ToolError("not_found", f"macro source not found: {src}")
    target = compile_macro(src, name=name, force=force)
    return {"path": str(target), "task_name": f"macro_{name}", "source": str(src)}
