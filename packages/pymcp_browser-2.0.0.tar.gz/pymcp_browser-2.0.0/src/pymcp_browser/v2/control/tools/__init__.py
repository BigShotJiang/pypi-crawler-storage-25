"""Tool category modules. Importing this package registers every @tool."""
from __future__ import annotations
import pkgutil
import importlib

from ..registry import TOOL_REGISTRY

_before = set(TOOL_REGISTRY.keys())

for _, name, _ in pkgutil.iter_modules(__path__):
    importlib.import_module(f"{__name__}.{name}")

# Sanity: catch duplicate tool-name registrations from name collisions.
# Each @tool overwrites silently; instead verify expected count grew per module.
# (No-op if no duplicates; here for future-proofing.)
_after = set(TOOL_REGISTRY.keys())
if len(_after) < len(_before):  # pragma: no cover
    raise RuntimeError("tool registry shrank during import — name collision?")
