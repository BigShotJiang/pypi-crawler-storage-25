"""Meta tools — health + tools.list + tool.batch."""
from __future__ import annotations
import asyncio
from ..registry import tool, TOOL_REGISTRY, ALIASES, resolve
from ..errors import ToolError
from ...core.session import SessionRegistry

# D15: cap parallel dispatch at 8 to match browser worker count.
BATCH_CONCURRENCY = 8


@tool(name="health", scope="read",
      schema={"type": "object", "properties": {}, "additionalProperties": False})
async def health() -> dict:
    """Liveness probe."""
    return {"ok": True}


@tool(name="tool.batch", scope="write",
      schema={"type": "object", "required": ["calls"], "properties": {
          "calls": {"type": "array", "minItems": 1, "items": {"type": "object",
              "required": ["name"], "properties": {
                  "name": {"type": "string"},
                  "args": {"type": "object"}}}},
          "concurrency": {"type": "integer", "default": BATCH_CONCURRENCY,
                          "minimum": 1, "maximum": 16}}})
async def tool_batch(calls: list[dict], concurrency: int = BATCH_CONCURRENCY) -> dict:
    """D15: dispatch independent tool calls in parallel. Per-session writes serialized via session.lock."""
    sem = asyncio.Semaphore(min(max(1, concurrency), 16))
    reg = SessionRegistry.get()

    async def _run(call: dict) -> dict:
        name = call.get("name")
        args = call.get("args") or {}
        t = resolve(name) if name else None
        if t is None:
            return {"name": name, "ok": False, "error": {"code": "task_not_found", "message": name}}
        async with sem:
            sid = args.get("session_id")
            sess = None
            if sid:
                try:
                    sess = reg.lookup(sid)
                except Exception:
                    sess = None
            try:
                if sess is not None and t.scope == "write":
                    async with sess.lock:
                        result = await t.handler(**args)
                else:
                    result = await t.handler(**args)
                return {"name": name, "ok": True, "result": result}
            except ToolError as e:
                return {"name": name, "ok": False, "error": e.to_dict()}
            except Exception as e:
                return {"name": name, "ok": False,
                        "error": {"code": "internal", "message": str(e)}}

    results = await asyncio.gather(*[_run(c) for c in calls])
    return {"results": results, "count": len(results)}


def _schema_version() -> str:
    """D-extra (Phase 8.2): stable hash of all tool schemas + aliases.

    Caller can compare against cached version to detect server-side schema drift."""
    import hashlib
    import json as _json
    payload = {
        "tools": sorted(
            (t.name, _json.dumps(t.schema, sort_keys=True, default=str), t.scope)
            for t in TOOL_REGISTRY.values()
        ),
        "aliases": sorted(ALIASES.items()),
    }
    blob = _json.dumps(payload, sort_keys=True, default=str).encode("utf-8")
    return hashlib.sha256(blob).hexdigest()[:16]


@tool(name="tools.list", scope="read",
      schema={"type": "object", "properties": {}, "additionalProperties": False})
async def tools_list() -> dict:
    """List every registered tool, alias, scope, schema, error codes."""
    return {
        "tools": [
            {
                "name": t.name,
                "description": t.description,
                "scope": t.scope,
                "schema": t.schema,
                "errors": t.error_codes,
            }
            for t in TOOL_REGISTRY.values()
        ],
        "aliases": dict(ALIASES),
        "count": len(TOOL_REGISTRY),
        "schema_version": _schema_version(),
    }
