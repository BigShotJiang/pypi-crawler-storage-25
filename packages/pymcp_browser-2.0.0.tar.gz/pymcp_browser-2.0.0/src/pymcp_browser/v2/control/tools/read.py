"""read.* tools — page extraction helpers."""
from __future__ import annotations
from urllib.parse import urlparse
from ..registry import tool
from ..errors import ToolError
from ...core.session import SessionRegistry
from ...core.target_resolver import resolve_page, resolve_target

_S = SessionRegistry.get


@tool(name="read.page", scope="read",
      schema={"type": "object", "required": ["session_id"], "properties": {
          "session_id": {"type": "string"},
          "max_chars": {"type": "integer", "default": 8000}}})
async def read_page(session_id: str, max_chars: int = 8000) -> dict:
    s = _S().lookup(session_id)
    page = await resolve_page(s)
    js = """
    (max) => {
      const main = document.querySelector('main, article, [role=main]') || document.body;
      const clone = main.cloneNode(true);
      clone.querySelectorAll('script,style,nav,footer,aside').forEach(e => e.remove());
      const md = [];
      for (const el of clone.querySelectorAll('h1,h2,h3,h4,h5,h6,p,li,a')) {
        const t = (el.innerText || '').trim();
        if (!t) continue;
        if (/^H[1-6]$/.test(el.tagName)) {
          md.push('#'.repeat(parseInt(el.tagName[1])) + ' ' + t);
        } else if (el.tagName === 'LI') {
          md.push('- ' + t);
        } else if (el.tagName === 'A' && el.href) {
          md.push('[' + t + '](' + el.href + ')');
        } else {
          md.push(t);
        }
      }
      const out = md.join('\\n\\n');
      return {title: document.title, url: location.href,
              markdown: out.slice(0, max), truncated: out.length > max};
    }
    """
    return await page.evaluate(js, max_chars)


@tool(name="read.links", scope="read",
      schema={"type": "object", "required": ["session_id"], "properties": {
          "session_id": {"type": "string"},
          "internal_only": {"type": "boolean", "default": False},
          "limit": {"type": "integer", "default": 200}}})
async def read_links(session_id: str, internal_only: bool = False,
                     limit: int = 200) -> dict:
    s = _S().lookup(session_id)
    page = await resolve_page(s)
    host = urlparse(page.url).hostname or ""
    raw = await page.evaluate("""
    () => Array.from(document.querySelectorAll('a[href]')).map(a => ({
      text: (a.innerText||'').trim().slice(0,120), href: a.href}))
    """)
    out = []
    for ln in raw:
        try:
            h = urlparse(ln["href"]).hostname or ""
        except Exception:
            h = ""
        is_internal = (h == host) if host else False
        if internal_only and not is_internal:
            continue
        out.append({"text": ln["text"], "href": ln["href"], "internal": is_internal})
        if len(out) >= limit:
            break
    return {"links": out}


@tool(name="read.forms", scope="read",
      schema={"type": "object", "required": ["session_id"], "properties": {
          "session_id": {"type": "string"}, "limit": {"type": "integer", "default": 20}}})
async def read_forms(session_id: str, limit: int = 20) -> dict:
    s = _S().lookup(session_id)
    page = await resolve_page(s)
    js = """
    (lim) => Array.from(document.querySelectorAll('form')).slice(0, lim).map(f => ({
      id: f.id || null, action: f.action || null, method: (f.method||'get').toLowerCase(),
      fields: Array.from(f.elements).filter(e => e.name).map(e => {
        const lbl = e.labels && e.labels[0] ? e.labels[0].innerText.trim() : null;
        return {name: e.name, type: e.type || e.tagName.toLowerCase(),
                label: lbl, required: !!e.required};
      })
    }))
    """
    return {"forms": await page.evaluate(js, limit)}


@tool(name="read.table", scope="read", errors=["target_not_found"],
      schema={"type": "object", "required": ["session_id"], "properties": {
          "session_id": {"type": "string"}, "target": {"type": "string"},
          "headers": {"type": "array"}}})
async def read_table(session_id: str, target: str | None = None,
                     headers: list[str] | None = None) -> dict:
    s = _S().lookup(session_id)
    page = await resolve_page(s)
    if target:
        h = await resolve_target(s, target)
        result = await h.evaluate("""
        (table, hdrs) => {
          const headerRow = hdrs || Array.from(table.querySelectorAll('thead th, tr:first-child th'))
            .map(t => t.innerText.trim());
          const rows = Array.from(table.querySelectorAll('tbody tr, tr')).slice(hdrs ? 0 : 1).map(tr =>
            Array.from(tr.querySelectorAll('td,th')).map(td => td.innerText.trim()));
          const out = rows.map(r => Object.fromEntries(r.map((v,i) => [headerRow[i] || `col${i}`, v])));
          return {rows: out, header_row: headerRow};
        }
        """, headers)
    else:
        result = await page.evaluate("""
        (hdrs) => {
          const table = document.querySelector('table');
          if (!table) return null;
          const headerRow = hdrs || Array.from(table.querySelectorAll('thead th, tr:first-child th'))
            .map(t => t.innerText.trim());
          const rows = Array.from(table.querySelectorAll('tbody tr, tr')).slice(hdrs ? 0 : 1).map(tr =>
            Array.from(tr.querySelectorAll('td,th')).map(td => td.innerText.trim()));
          const out = rows.map(r => Object.fromEntries(r.map((v,i) => [headerRow[i] || `col${i}`, v])));
          return {rows: out, header_row: headerRow};
        }
        """, headers)
        if result is None:
            raise ToolError("target_not_found", "no <table> on page")
    return {**result, "source_target": target}
