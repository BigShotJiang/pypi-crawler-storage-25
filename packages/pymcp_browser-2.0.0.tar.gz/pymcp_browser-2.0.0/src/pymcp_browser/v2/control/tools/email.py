"""email.* tools — IMAP/SMTP via dual-mode addressing.

Phase 2: account management.
Phase 3-6: IMAP read/mutating + SMTP send (see updates-v1-implementation-plan.md).
Phase 7: IDLE (requires MailSession from Phase 7).
"""
from __future__ import annotations
import time
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Any, AsyncIterator

from sqlmodel import select

from ..registry import tool
from ..errors import ToolError
from ...config import settings
from ...storage.db import session_scope
from ...storage.models import MailAccount
from ...core.credentials import get_mail_password
from ...core.mail import IMAPClient, SMTPClient
from ...core.session import SessionRegistry


# ---------- Phase 2: account management ----------

@tool(name="email.account_add", scope="admin", errors=["invalid_args"],
      schema={"type": "object",
              "required": ["label", "imap_host", "smtp_host", "username"],
              "additionalProperties": False,
              "properties": {
                  "label": {"type": "string", "minLength": 1},
                  "imap_host": {"type": "string"},
                  "imap_port": {"type": "integer", "default": 993},
                  "imap_ssl": {"type": "boolean", "default": True},
                  "smtp_host": {"type": "string"},
                  "smtp_port": {"type": "integer", "default": 465},
                  "smtp_tls": {"type": "string",
                               "enum": ["ssl", "starttls", "none"],
                               "default": "ssl"},
                  "username": {"type": "string"},
                  "daily_send_limit": {"type": "integer"}}})
async def email_account_add(label: str, imap_host: str, smtp_host: str,
                            username: str,
                            imap_port: int = 993, imap_ssl: bool = True,
                            smtp_port: int = 465, smtp_tls: str = "ssl",
                            daily_send_limit: int | None = None) -> dict:
    """Register IMAP+SMTP account metadata. Password lives in data/credentials.json."""
    now = time.time()
    with session_scope() as s:
        existing = s.get(MailAccount, label)
        if existing is not None:
            raise ToolError("invalid_args", f"label '{label}' already exists",
                            hint="use email.account_remove first")
        s.add(MailAccount(
            label=label, imap_host=imap_host, imap_port=imap_port,
            imap_ssl=imap_ssl, smtp_host=smtp_host, smtp_port=smtp_port,
            smtp_tls=smtp_tls, username=username,
            daily_send_limit=daily_send_limit, daily_send_count=0,
            created_ts=now,
        ))
    return {
        "ok": True,
        "label": label,
        "next_step": (f"Add password to data/credentials.json under "
                      f'"mail": {{"{label}": {{"password": "<app-password>"}}}}'),
    }


@tool(name="email.account_remove", scope="admin",
      errors=["mail_account_not_found"],
      schema={"type": "object", "required": ["label"],
              "additionalProperties": False,
              "properties": {"label": {"type": "string"}}})
async def email_account_remove(label: str) -> dict:
    with session_scope() as s:
        row = s.get(MailAccount, label)
        if row is None:
            raise ToolError("mail_account_not_found", label)
        s.delete(row)
    return {"ok": True, "label": label}


@tool(name="email.account_list", scope="read",
      schema={"type": "object", "additionalProperties": False, "properties": {}})
async def email_account_list() -> dict:
    with session_scope() as s:
        rows = s.exec(select(MailAccount)).all()
    return {"accounts": [{
        "label": r.label,
        "imap_host": r.imap_host, "imap_port": r.imap_port, "imap_ssl": r.imap_ssl,
        "smtp_host": r.smtp_host, "smtp_port": r.smtp_port, "smtp_tls": r.smtp_tls,
        "username": r.username,
        "daily_send_limit": r.daily_send_limit,
        "daily_send_count": r.daily_send_count,
        "daily_send_window_start_ts": r.daily_send_window_start_ts,
        "created_ts": r.created_ts,
        "last_used_ts": r.last_used_ts,
    } for r in rows]}


@tool(name="email.account_test", scope="read",
      errors=["mail_account_not_found", "mail_auth_failed", "mail_protocol"],
      schema={"type": "object", "required": ["label"],
              "additionalProperties": False,
              "properties": {
                  "label": {"type": "string"},
                  "test_smtp": {"type": "boolean", "default": True}}})
async def email_account_test(label: str, test_smtp: bool = True) -> dict:
    """IMAP login + (optional) SMTP login round-trip. Reports capabilities."""
    account = _load_account(label)
    imap_caps: list[str] = []
    smtp_ok: bool | None = None
    smtp_err: str | None = None

    async with IMAPClient(account) as cli:
        imap_caps = cli.capabilities

    if test_smtp:
        try:
            import aiosmtplib
        except ImportError as e:
            raise ToolError("internal", f"aiosmtplib not installed: {e}")
        password = get_mail_password(account.label)
        tls_mode = (account.smtp_tls or "ssl").lower()
        smtp = aiosmtplib.SMTP(
            hostname=account.smtp_host, port=account.smtp_port,
            use_tls=(tls_mode == "ssl"),
            start_tls=(tls_mode == "starttls"),
            timeout=30,
        )
        try:
            await smtp.connect()
            if tls_mode == "starttls":
                try:
                    await smtp.starttls()
                except Exception:
                    pass
            await smtp.login(account.username, password)
            smtp_ok = True
        except Exception as e:
            smtp_ok = False
            smtp_err = str(e)
        finally:
            try:
                await smtp.quit()
            except Exception:
                pass

    return {
        "ok": True,
        "imap_capabilities": imap_caps,
        "smtp_ok": smtp_ok,
        "smtp_error": smtp_err,
    }


# ---------- Phase 3: IMAP read-only ----------

@tool(name="email.list_folders", scope="read",
      errors=["mail_account_not_found", "mail_auth_failed", "mail_protocol",
              "session_not_found", "invalid_args"],
      schema={"type": "object", "additionalProperties": False,
              "properties": {
                  "account_label": {"type": "string"},
                  "session_id": {"type": "string"}}})
async def email_list_folders(account_label: str | None = None,
                             session_id: str | None = None) -> dict:
    async with _imap_for(account_label, session_id) as cli:
        folders = await cli.list_folders()
    return {"folders": folders}


@tool(name="email.search", scope="read",
      alias="mail_search",
      errors=["mail_account_not_found", "mail_auth_failed", "mail_protocol",
              "session_not_found", "invalid_args"],
      schema={"type": "object", "additionalProperties": False,
              "properties": {
                  "account_label": {"type": "string"},
                  "session_id": {"type": "string"},
                  "folder": {"type": "string", "default": "INBOX"},
                  "criteria": {"type": "array", "items": {"type": "string"},
                               "default": ["UNSEEN"]},
                  "limit": {"type": "integer", "default": 50,
                            "minimum": 1, "maximum": 1000},
                  "retries": {"type": "integer", "default": 1, "minimum": 1, "maximum": 10,
                              "description": "D13: total attempts; subsequent calls if 0 results"},
                  "backoff_s": {"type": "number", "default": 4.0,
                                "description": "D13: linear backoff seconds between retries"}}})
async def email_search(account_label: str | None = None,
                       session_id: str | None = None,
                       folder: str = "INBOX",
                       criteria: list[str] | None = None,
                       limit: int = 50,
                       retries: int = 1,
                       backoff_s: float = 4.0) -> dict:
    """D13: linear retry-with-backoff for OTP race conditions (mail not yet propagated)."""
    import asyncio as _asyncio
    crit = list(criteria) if criteria else ["UNSEEN"]
    uids: list[int] = []
    attempts = 0
    for attempt in range(1, max(1, retries) + 1):
        attempts = attempt
        async with _imap_for(account_label, session_id) as cli:
            uids = await cli.search(folder, crit, limit=limit)
        if uids or attempt == retries:
            break
        await _asyncio.sleep(backoff_s)
    return {"folder": folder, "criteria": crit, "uids": uids,
            "count": len(uids), "attempts": attempts}


@tool(name="email.fetch_headers", scope="read",
      errors=["mail_account_not_found", "mail_auth_failed", "mail_protocol",
              "session_not_found", "invalid_args"],
      schema={"type": "object", "additionalProperties": False,
              "required": ["uids"],
              "properties": {
                  "account_label": {"type": "string"},
                  "session_id": {"type": "string"},
                  "folder": {"type": "string", "default": "INBOX"},
                  "uids": {"type": "array", "items": {"type": "integer"},
                           "minItems": 1}}})
async def email_fetch_headers(uids: list[int],
                              account_label: str | None = None,
                              session_id: str | None = None,
                              folder: str = "INBOX") -> dict:
    async with _imap_for(account_label, session_id) as cli:
        headers = await cli.fetch_headers(folder, uids)
    return {"folder": folder, "headers": headers}


# ---------- Phase 4: fetch with attachments ----------

@tool(name="email.fetch", scope="read",
      alias="mail_fetch",
      errors=["mail_account_not_found", "mail_auth_failed", "mail_protocol",
              "session_not_found", "invalid_args"],
      schema={"type": "object", "additionalProperties": False,
              "required": ["uids"],
              "properties": {
                  "account_label": {"type": "string"},
                  "session_id": {"type": "string"},
                  "folder": {"type": "string", "default": "INBOX"},
                  "uids": {"type": "array", "items": {"type": "integer"},
                           "minItems": 1},
                  "include_html": {"type": "boolean", "default": True},
                  "max_size_kb": {"type": "integer"}}})
async def email_fetch(uids: list[int],
                      account_label: str | None = None,
                      session_id: str | None = None,
                      folder: str = "INBOX",
                      include_html: bool = True,
                      max_size_kb: int | None = None) -> dict:
    label = account_label or _label_from_session(session_id)
    save_dir = Path(settings.mail_data_dir) / label
    cap = (max_size_kb * 1024) if max_size_kb else None
    async with _imap_for(account_label, session_id) as cli:
        messages = await cli.fetch(folder, uids, save_dir,
                                   include_html=include_html,
                                   max_total_size=cap)
    return {"folder": folder, "messages": messages}


# ---------- Phase 5: SMTP send ----------

@tool(name="email.send", scope="write", alias="mail_send",
      errors=["mail_account_not_found", "mail_auth_failed", "mail_protocol",
              "mail_attachment_too_large", "mail_rate_limited", "invalid_args"],
      schema={"type": "object", "additionalProperties": False,
              "required": ["account_label", "to", "subject"],
              "properties": {
                  "account_label": {"type": "string"},
                  "to": {"type": "array", "items": {"type": "string"}, "minItems": 1},
                  "cc": {"type": "array", "items": {"type": "string"}},
                  "bcc": {"type": "array", "items": {"type": "string"}},
                  "subject": {"type": "string"},
                  "body_text": {"type": "string", "default": ""},
                  "body_html": {"type": "string"},
                  "attachments": {"type": "array", "items": {"type": "string"}},
                  "in_reply_to": {"type": "string"},
                  "references": {"type": "array", "items": {"type": "string"}},
                  "headers": {"type": "object"}}})
async def email_send(account_label: str, to: list[str], subject: str,
                     cc: list[str] | None = None,
                     bcc: list[str] | None = None,
                     body_text: str = "",
                     body_html: str | None = None,
                     attachments: list[str] | None = None,
                     in_reply_to: str | None = None,
                     references: list[str] | None = None,
                     headers: dict[str, str] | None = None) -> dict:
    account = _load_account(account_label)
    return await SMTPClient.send(
        account, to=to, cc=cc, bcc=bcc, subject=subject,
        body_text=body_text, body_html=body_html,
        attachments=attachments, in_reply_to=in_reply_to,
        references=references, headers=headers,
    )


# ---------- Phase 6: IMAP mutating ----------

_DUAL_OR_UIDS = {
    "type": "object", "additionalProperties": False,
    "required": ["uids"],
    "properties": {
        "account_label": {"type": "string"},
        "session_id": {"type": "string"},
        "folder": {"type": "string", "default": "INBOX"},
        "uids": {"type": "array", "items": {"type": "integer"}, "minItems": 1},
    },
}


@tool(name="email.mark_seen", scope="write",
      errors=["mail_account_not_found", "mail_auth_failed", "mail_protocol",
              "session_not_found", "invalid_args"],
      schema={**_DUAL_OR_UIDS,
              "properties": {**_DUAL_OR_UIDS["properties"],
                             "seen": {"type": "boolean", "default": True}}})
async def email_mark_seen(uids: list[int],
                          account_label: str | None = None,
                          session_id: str | None = None,
                          folder: str = "INBOX",
                          seen: bool = True) -> dict:
    async with _imap_for(account_label, session_id) as cli:
        await cli.store_flags(folder, uids, r"\Seen", set_=seen)
    return {"ok": True, "folder": folder, "uids": uids, "seen": seen}


@tool(name="email.move", scope="write",
      errors=["mail_account_not_found", "mail_auth_failed", "mail_protocol",
              "session_not_found", "invalid_args"],
      schema={"type": "object", "additionalProperties": False,
              "required": ["uids", "dest"],
              "properties": {**_DUAL_OR_UIDS["properties"],
                             "dest": {"type": "string"}}})
async def email_move(uids: list[int], dest: str,
                     account_label: str | None = None,
                     session_id: str | None = None,
                     folder: str = "INBOX") -> dict:
    async with _imap_for(account_label, session_id) as cli:
        await cli.move(folder, uids, dest)
    return {"ok": True, "folder": folder, "dest": dest, "uids": uids}


@tool(name="email.delete", scope="write",
      errors=["mail_account_not_found", "mail_auth_failed", "mail_protocol",
              "session_not_found", "invalid_args"],
      schema={**_DUAL_OR_UIDS,
              "properties": {**_DUAL_OR_UIDS["properties"],
                             "expunge": {"type": "boolean", "default": True}}})
async def email_delete(uids: list[int],
                       account_label: str | None = None,
                       session_id: str | None = None,
                       folder: str = "INBOX",
                       expunge: bool = True) -> dict:
    async with _imap_for(account_label, session_id) as cli:
        await cli.delete(folder, uids, expunge=expunge)
    return {"ok": True, "folder": folder, "uids": uids, "expunge": expunge}


# ---------- Phase 7: IDLE ----------

import asyncio
import uuid


@tool(name="email.idle_start", scope="write",
      errors=["session_not_found", "invalid_args", "mail_idle_unsupported",
              "mail_protocol", "mail_auth_failed"],
      schema={"type": "object", "additionalProperties": False,
              "required": ["session_id"],
              "properties": {
                  "session_id": {"type": "string"},
                  "folder": {"type": "string", "default": "INBOX"}}})
async def email_idle_start(session_id: str, folder: str = "INBOX") -> dict:
    sess = SessionRegistry.get().lookup(session_id)
    if getattr(sess, "kind", "browser") != "mail":
        raise ToolError("invalid_args",
                        f"session {session_id} is kind="
                        f"{getattr(sess, 'kind', 'browser')!r}, need 'mail'")
    # Dedicated IMAP connection — never share with sess.imap (command channel)
    label = sess.account_label
    account = _load_account(label)
    idle_cli = IMAPClient(account)
    await idle_cli.connect()
    if not idle_cli.has_cap("IDLE"):
        await idle_cli.logout()
        raise ToolError("mail_idle_unsupported",
                        f"server lacks IDLE (caps: {idle_cli.capabilities})")
    idle_id = "idl" + uuid.uuid4().hex[:8]
    stop_ev = asyncio.Event()

    def _push(ev: dict) -> None:
        topic = ev.pop("topic", "mail.event")
        sess.events.push(topic, account=label, **ev)
        if sess.recorder:
            sess.recorder.event(topic, account=label, **ev)

    async def _runner():
        try:
            await idle_cli.idle(folder, _push, stop_ev)
        except Exception as e:
            sess.events.push("mail.error", idle_id=idle_id, message=str(e))
        finally:
            try:
                await idle_cli.logout()
            except Exception:
                pass

    task = asyncio.create_task(_runner())
    sess.idle_tasks[idle_id] = (task, stop_ev, idle_cli)
    return {"idle_id": idle_id, "folder": folder, "account_label": label}


@tool(name="email.idle_stop", scope="write",
      errors=["session_not_found", "invalid_args"],
      schema={"type": "object", "additionalProperties": False,
              "required": ["session_id", "idle_id"],
              "properties": {
                  "session_id": {"type": "string"},
                  "idle_id": {"type": "string"}}})
async def email_idle_stop(session_id: str, idle_id: str) -> dict:
    sess = SessionRegistry.get().lookup(session_id)
    if getattr(sess, "kind", "browser") != "mail":
        raise ToolError("invalid_args", "not a mail session")
    entry = sess.idle_tasks.pop(idle_id, None)
    if entry is None:
        raise ToolError("invalid_args", f"unknown idle_id: {idle_id}")
    task, stop_ev, idle_cli = entry
    stop_ev.set()
    try:
        await asyncio.wait_for(task, timeout=15)
    except (asyncio.TimeoutError, asyncio.CancelledError):
        task.cancel()
    except Exception:
        pass
    try:
        await idle_cli.logout()
    except Exception:
        pass
    return {"ok": True, "idle_id": idle_id}


# ---------- internal helpers ----------

def _label_from_session(session_id: str | None) -> str:
    if not session_id:
        raise ToolError("invalid_args", "session_id required")
    sess = SessionRegistry.get().lookup(session_id)
    label = getattr(sess, "account_label", None)
    if not label:
        raise ToolError("invalid_args",
                        f"session {session_id} has no account_label")
    return label


def _load_account(label: str) -> MailAccount:
    with session_scope() as s:
        row = s.get(MailAccount, label)
        if row is None:
            raise ToolError("mail_account_not_found", label)
        # detach: caller uses outside session
        s.expunge(row)
        return row


def _validate_dual_mode(account_label: str | None,
                        session_id: str | None) -> None:
    if account_label and session_id:
        raise ToolError("invalid_args",
                        "specify either account_label OR session_id, not both")
    if not account_label and not session_id:
        raise ToolError("invalid_args",
                        "must specify account_label or session_id")


@asynccontextmanager
async def _imap_for(account_label: str | None,
                    session_id: str | None) -> AsyncIterator[IMAPClient]:
    """Resolve dual-mode addressing to an IMAPClient context.

    Stateless: open + login + caller-uses + logout.
    Session: reuses MailSession.imap under sess.lock (Phase 7).
    """
    _validate_dual_mode(account_label, session_id)
    if account_label:
        account = _load_account(account_label)
        cli = IMAPClient(account)
        await cli.connect()
        try:
            yield cli
        finally:
            await cli.logout()
        return
    # session_id mode — Phase 7 wires this. For now, raise informative.
    sess = SessionRegistry.get().lookup(session_id)  # type: ignore[arg-type]
    kind = getattr(sess, "kind", "browser")
    if kind != "mail":
        raise ToolError("invalid_args",
                        f"session {session_id} is kind={kind!r}, need 'mail'",
                        hint="create with session.create(kind='mail', account_label=...)")
    imap = getattr(sess, "imap", None)
    if imap is None:
        raise ToolError("internal", "MailSession has no imap channel")
    async with sess.lock:
        yield imap
