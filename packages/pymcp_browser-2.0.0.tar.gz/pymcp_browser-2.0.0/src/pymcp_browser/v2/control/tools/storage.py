"""storage.* tools."""
from __future__ import annotations
from ..registry import tool
from ...core.session import SessionRegistry
from ...core.target_resolver import resolve_page

_S = SessionRegistry.get


@tool(name="storage.cookies_get", scope="admin",
      schema={"type": "object", "required": ["session_id"], "properties": {
          "session_id": {"type": "string"}, "urls": {"type": "array"}}})
async def cookies_get(session_id: str, urls: list[str] | None = None) -> dict:
    s = _S().lookup(session_id)
    cookies = await s.context.cookies(urls or [])
    return {"cookies": cookies}


@tool(name="storage.cookies_set", scope="admin",
      schema={"type": "object", "required": ["session_id", "cookies"], "properties": {
          "session_id": {"type": "string"}, "cookies": {"type": "array"}}})
async def cookies_set(session_id: str, cookies: list[dict]) -> dict:
    s = _S().lookup(session_id)
    await s.context.add_cookies(cookies)
    return {"ok": True}


@tool(name="storage.cookies_clear", scope="admin",
      schema={"type": "object", "required": ["session_id"], "properties": {
          "session_id": {"type": "string"}, "url_filter": {"type": "string"}}})
async def cookies_clear(session_id: str, url_filter: str | None = None) -> dict:
    s = _S().lookup(session_id)
    if url_filter:
        existing = await s.context.cookies()
        keep = [c for c in existing if url_filter not in c.get("domain", "")]
        await s.context.clear_cookies()
        if keep:
            await s.context.add_cookies(keep)
        cleared = len(existing) - len(keep)
    else:
        existing = await s.context.cookies()
        cleared = len(existing)
        await s.context.clear_cookies()
    return {"cleared_count": cleared}


@tool(name="storage.local_get", scope="admin",
      schema={"type": "object", "required": ["session_id"], "properties": {
          "session_id": {"type": "string"}, "origin": {"type": "string"}}})
async def local_get(session_id: str, origin: str | None = None) -> dict:
    s = _S().lookup(session_id)
    page = await resolve_page(s)
    items = await page.evaluate("() => { const o={}; for(let i=0;i<localStorage.length;i++){const k=localStorage.key(i); o[k]=localStorage.getItem(k);} return o; }")
    return {"items": items}


@tool(name="storage.local_set", scope="admin",
      schema={"type": "object", "required": ["session_id", "origin", "items"], "properties": {
          "session_id": {"type": "string"}, "origin": {"type": "string"},
          "items": {"type": "object"}}})
async def local_set(session_id: str, origin: str, items: dict) -> dict:
    s = _S().lookup(session_id)
    page = await resolve_page(s)
    await page.evaluate("(items) => { for(const [k,v] of Object.entries(items)) localStorage.setItem(k,v); }", items)
    return {"ok": True}


@tool(name="storage.session_get", scope="admin",
      schema={"type": "object", "required": ["session_id"], "properties": {
          "session_id": {"type": "string"}, "origin": {"type": "string"}}})
async def session_get(session_id: str, origin: str | None = None) -> dict:
    s = _S().lookup(session_id)
    page = await resolve_page(s)
    items = await page.evaluate("() => { const o={}; for(let i=0;i<sessionStorage.length;i++){const k=sessionStorage.key(i); o[k]=sessionStorage.getItem(k);} return o; }")
    return {"items": items}


@tool(name="storage.clear", scope="admin",
      schema={"type": "object", "required": ["session_id"], "properties": {
          "session_id": {"type": "string"}, "types": {"type": "array"}}})
async def storage_clear(session_id: str, types: list[str] | None = None) -> dict:
    s = _S().lookup(session_id)
    page = await resolve_page(s)
    types = types or ["local", "session", "cookies", "cache"]
    if "local" in types:
        try: await page.evaluate("() => localStorage.clear()")
        except Exception: pass
    if "session" in types:
        try: await page.evaluate("() => sessionStorage.clear()")
        except Exception: pass
    if "cookies" in types:
        await s.context.clear_cookies()
    if "cache" in types:
        try:
            client = await s.context.new_cdp_session(page)
            await client.send("Network.clearBrowserCache")
        except Exception:
            pass
    return {"ok": True}
