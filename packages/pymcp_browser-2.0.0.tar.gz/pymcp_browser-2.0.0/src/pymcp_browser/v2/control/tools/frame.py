"""frame.* tools."""
from __future__ import annotations
from pathlib import Path
import time
from ..registry import tool
from ..errors import ToolError
from ...config import settings
from ...core.session import SessionRegistry
from ...core.target_resolver import resolve_page, resolve_target

_S = SessionRegistry.get


@tool(name="frame.list", scope="read",
      schema={"type": "object", "required": ["session_id"], "properties": {
          "session_id": {"type": "string"}, "tab_id": {"type": "string"}}})
async def frame_list(session_id: str, tab_id: str | None = None) -> dict:
    s = _S().lookup(session_id)
    page = s.tab_id_map.get(tab_id) if tab_id else s.active_page()
    if page is None:
        raise ToolError("tab_not_found" if tab_id else "session_not_found", str(tab_id))
    out = []
    for fr in page.frames:
        out.append({"frame_id": fr.url, "url": fr.url, "name": fr.name,
                    "parent_id": fr.parent_frame.url if fr.parent_frame else None})
    return {"frames": out}


@tool(name="frame.eval", scope="admin", errors=["frame_not_found"],
      schema={"type": "object", "required": ["session_id", "frame_id", "js"], "properties": {
          "session_id": {"type": "string"}, "frame_id": {"type": "string"},
          "js": {"type": "string"}, "args": {"type": "array"}}})
async def frame_eval(session_id: str, frame_id: str, js: str, args: list | None = None) -> dict:
    s = _S().lookup(session_id)
    page = await resolve_page(s)
    fr = next((f for f in page.frames if f.url == frame_id), None)
    if fr is None:
        raise ToolError("frame_not_found", frame_id)
    audit = Path(settings.evaluate_audit_log_dir) / f"evaluate-{time.strftime('%Y-%m-%d')}.log"
    audit.parent.mkdir(parents=True, exist_ok=True)
    try:
        with audit.open("a", encoding="utf-8") as f:
            f.write(f"{time.time()}\t{s.id}\tframe={frame_id}\t{js[:8000]}\n")
    except Exception:
        pass
    result = await fr.evaluate(js, args[0] if args else None)
    return {"result": result}


@tool(name="frame.shadow_query", scope="read", errors=["target_not_found", "ref_stale"],
      schema={"type": "object", "required": ["session_id", "host_target", "inner_selector"],
              "properties": {
          "session_id": {"type": "string"}, "host_target": {"type": "string"},
          "inner_selector": {"type": "string"}}})
async def frame_shadow_query(session_id: str, host_target: str, inner_selector: str) -> dict:
    s = _S().lookup(session_id)
    h = await resolve_target(s, host_target)
    page_idx = s.pages.index(s.active_page())
    handles = await h.evaluate_handle(
        "(host, sel) => Array.from((host.shadowRoot||host).querySelectorAll(sel))",
        inner_selector)
    props = await handles.get_properties()
    refs: list[str] = []
    for _, prop in props.items():
        el = prop.as_element()
        if el is not None:
            refs.append(s.ref_store.mint(page_idx, None, el))
    return {"found": len(refs) > 0, "count": len(refs), "refs": refs}
