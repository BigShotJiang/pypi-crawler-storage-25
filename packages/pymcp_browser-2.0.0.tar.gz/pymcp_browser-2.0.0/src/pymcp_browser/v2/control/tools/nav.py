"""nav.* tools."""
from __future__ import annotations
from ..registry import tool
from ..errors import ToolError
from ...core.session import SessionRegistry
from ...core.target_resolver import resolve_page
from playwright.async_api import TimeoutError as PWTimeout

_S = SessionRegistry.get


@tool(name="nav.go", scope="write", alias="navigate",
      errors=["timeout", "target_not_found", "proxy_unreachable"],
      schema={"type": "object", "required": ["session_id", "url"], "properties": {
          "session_id": {"type": "string"}, "url": {"type": "string"},
          "wait_until": {"type": "string", "enum": ["load", "domcontentloaded", "networkidle"],
                         "default": "domcontentloaded"},
          "timeout_ms": {"type": "integer", "default": 30000},
          "referer": {"type": "string"}}})
async def nav_go(session_id: str, url: str, wait_until: str = "domcontentloaded",
                 timeout_ms: int = 30000, referer: str | None = None) -> dict:
    s = _S().lookup(session_id)
    page = await resolve_page(s)
    async with s.lock:
        try:
            kwargs: dict = {"wait_until": wait_until, "timeout": timeout_ms}
            if referer:
                kwargs["referer"] = referer
            resp = await page.goto(url, **kwargs)
        except PWTimeout as e:
            raise ToolError("timeout", str(e))
        except Exception as e:
            msg = str(e)
            if "ERR_PROXY" in msg or "tunnel" in msg.lower():
                raise ToolError("proxy_unreachable", msg)
            raise ToolError("target_not_found", msg)
    return {"final_url": page.url,
            "status": resp.status if resp else None,
            "headers": dict(resp.headers) if resp else {},
            "redirected_chain": []}


@tool(name="nav.back", scope="write", errors=["timeout"],
      schema={"type": "object", "required": ["session_id"], "properties": {
          "session_id": {"type": "string"}, "timeout_ms": {"type": "integer", "default": 10000}}})
async def nav_back(session_id: str, timeout_ms: int = 10000) -> dict:
    s = _S().lookup(session_id)
    page = await resolve_page(s)
    async with s.lock:
        try:
            await page.go_back(timeout=timeout_ms)
        except PWTimeout as e:
            raise ToolError("timeout", str(e))
    return {"url": page.url}


@tool(name="nav.forward", scope="write", errors=["timeout"],
      schema={"type": "object", "required": ["session_id"], "properties": {
          "session_id": {"type": "string"}, "timeout_ms": {"type": "integer", "default": 10000}}})
async def nav_forward(session_id: str, timeout_ms: int = 10000) -> dict:
    s = _S().lookup(session_id)
    page = await resolve_page(s)
    async with s.lock:
        try:
            await page.go_forward(timeout=timeout_ms)
        except PWTimeout as e:
            raise ToolError("timeout", str(e))
    return {"url": page.url}


@tool(name="nav.reload", scope="write", errors=["timeout"],
      schema={"type": "object", "required": ["session_id"], "properties": {
          "session_id": {"type": "string"},
          "wait_until": {"type": "string", "enum": ["load", "domcontentloaded", "networkidle"]},
          "ignore_cache": {"type": "boolean", "default": False}}})
async def nav_reload(session_id: str, wait_until: str | None = None,
                     ignore_cache: bool = False) -> dict:
    s = _S().lookup(session_id)
    page = await resolve_page(s)
    async with s.lock:
        kwargs = {}
        if wait_until:
            kwargs["wait_until"] = wait_until
        try:
            resp = await page.reload(**kwargs)
        except PWTimeout as e:
            raise ToolError("timeout", str(e))
    return {"url": page.url, "status": resp.status if resp else None}
