"""clipboard.* tools — OS clipboard read/write + opt-in async watcher.

Watcher is process-scoped (not session-scoped) and OFF by default.
Caller must explicitly invoke clipboard.watcher_start.
"""
from __future__ import annotations
import asyncio
import atexit
import re
import time
from typing import Optional

from sqlmodel import select, desc

from ..registry import tool
from ..errors import ToolError
from ...storage.db import session_scope
from ...storage.models import ClipEntry


try:
    import pyperclip  # type: ignore
    _PYPERCLIP_OK = True
    _PYPERCLIP_ERR = None
except Exception as e:  # pragma: no cover
    pyperclip = None  # type: ignore
    _PYPERCLIP_OK = False
    _PYPERCLIP_ERR = str(e)


def _ensure_clipboard():
    if not _PYPERCLIP_OK:
        raise ToolError("clipboard_unavailable",
                        f"pyperclip unavailable: {_PYPERCLIP_ERR}")
    try:
        pyperclip.paste()
    except Exception as e:
        raise ToolError("clipboard_unavailable", str(e))


class _WatcherState:
    task: Optional[asyncio.Task] = None
    interval_ms: int = 500
    cap: int = 100
    ignore_patterns: list[re.Pattern] = []
    last_capture_ts: Optional[float] = None
    last_content: Optional[str] = None


_state = _WatcherState()


def _enforce_cap(cap: int) -> None:
    with session_scope() as s:
        unpinned = s.exec(select(ClipEntry).where(ClipEntry.pinned == False)
                          .order_by(desc(ClipEntry.created_ts))).all()
        if len(unpinned) > cap:
            for r in unpinned[cap:]:
                s.delete(r)


async def _watcher_loop():
    while True:
        try:
            content = pyperclip.paste()
        except Exception:
            await asyncio.sleep(_state.interval_ms / 1000.0)
            continue
        if content and content != _state.last_content:
            skip = any(p.search(content) for p in _state.ignore_patterns)
            if not skip:
                with session_scope() as s:
                    s.add(ClipEntry(content=content, created_ts=time.time()))
                _enforce_cap(_state.cap)
                _state.last_capture_ts = time.time()
            _state.last_content = content
        await asyncio.sleep(_state.interval_ms / 1000.0)


def _shutdown():
    if _state.task and not _state.task.done():
        _state.task.cancel()


atexit.register(_shutdown)


@tool(name="clipboard.read", scope="read",
      errors=["clipboard_unavailable"],
      schema={"type": "object", "additionalProperties": False,
              "properties": {}})
async def clipboard_read() -> dict:
    """Read current OS clipboard content."""
    _ensure_clipboard()
    return {"content": pyperclip.paste()}


@tool(name="clipboard.write", scope="write",
      errors=["clipboard_unavailable"],
      schema={"type": "object", "required": ["content"],
              "additionalProperties": False,
              "properties": {"content": {"type": "string"}}})
async def clipboard_write(content: str) -> dict:
    """Write content to OS clipboard."""
    _ensure_clipboard()
    pyperclip.copy(content)
    _state.last_content = content
    return {"ok": True}


@tool(name="clipboard.add", scope="write", errors=[],
      schema={"type": "object", "required": ["content"],
              "additionalProperties": False,
              "properties": {"content": {"type": "string"}}})
async def clipboard_add(content: str) -> dict:
    """Add entry to history without touching OS clipboard."""
    with session_scope() as s:
        e = ClipEntry(content=content, created_ts=time.time())
        s.add(e)
        s.flush()
        new_id = e.id
    return {"ok": True, "id": new_id}


@tool(name="clipboard.list", scope="read", errors=[],
      schema={"type": "object", "additionalProperties": False,
              "properties": {
                  "limit": {"type": "integer", "default": 50,
                            "minimum": 1, "maximum": 500},
                  "pinned_first": {"type": "boolean", "default": True},
                  "query": {"type": "string"}}})
async def clipboard_list(limit: int = 50, pinned_first: bool = True,
                         query: Optional[str] = None) -> dict:
    """List clipboard history. Optional substring filter."""
    with session_scope() as s:
        stmt = select(ClipEntry)
        if query:
            stmt = stmt.where(ClipEntry.content.contains(query))
        if pinned_first:
            stmt = stmt.order_by(desc(ClipEntry.pinned),
                                 desc(ClipEntry.created_ts))
        else:
            stmt = stmt.order_by(desc(ClipEntry.created_ts))
        rows = s.exec(stmt.limit(limit)).all()
        return {"entries": [{
            "id": r.id, "content": r.content, "pinned": r.pinned,
            "used_count": r.used_count, "created_ts": r.created_ts,
        } for r in rows]}


@tool(name="clipboard.get", scope="read",
      errors=["clipboard_entry_not_found"],
      schema={"type": "object", "required": ["id"],
              "additionalProperties": False,
              "properties": {"id": {"type": "integer"}}})
async def clipboard_get(id: int) -> dict:
    """Read single history entry by id."""
    with session_scope() as s:
        row = s.get(ClipEntry, id)
        if row is None:
            raise ToolError("clipboard_entry_not_found", str(id))
        return {"id": row.id, "content": row.content,
                "pinned": row.pinned, "used_count": row.used_count,
                "created_ts": row.created_ts}


@tool(name="clipboard.recopy", scope="write",
      errors=["clipboard_entry_not_found", "clipboard_unavailable"],
      schema={"type": "object", "required": ["id"],
              "additionalProperties": False,
              "properties": {"id": {"type": "integer"}}})
async def clipboard_recopy(id: int) -> dict:
    """Push history entry back to OS clipboard. Increments used_count."""
    _ensure_clipboard()
    with session_scope() as s:
        row = s.get(ClipEntry, id)
        if row is None:
            raise ToolError("clipboard_entry_not_found", str(id))
        pyperclip.copy(row.content)
        _state.last_content = row.content
        row.used_count += 1
        s.add(row)
    return {"ok": True}


@tool(name="clipboard.pin", scope="write",
      errors=["clipboard_entry_not_found"],
      schema={"type": "object", "required": ["id"],
              "additionalProperties": False,
              "properties": {"id": {"type": "integer"}}})
async def clipboard_pin(id: int) -> dict:
    """Mark entry as pinned (exempt from auto-prune)."""
    with session_scope() as s:
        row = s.get(ClipEntry, id)
        if row is None:
            raise ToolError("clipboard_entry_not_found", str(id))
        row.pinned = True
        s.add(row)
    return {"ok": True}


@tool(name="clipboard.unpin", scope="write",
      errors=["clipboard_entry_not_found"],
      schema={"type": "object", "required": ["id"],
              "additionalProperties": False,
              "properties": {"id": {"type": "integer"}}})
async def clipboard_unpin(id: int) -> dict:
    """Unpin entry."""
    with session_scope() as s:
        row = s.get(ClipEntry, id)
        if row is None:
            raise ToolError("clipboard_entry_not_found", str(id))
        row.pinned = False
        s.add(row)
    return {"ok": True}


@tool(name="clipboard.delete", scope="write",
      errors=["clipboard_entry_not_found"],
      schema={"type": "object", "required": ["id"],
              "additionalProperties": False,
              "properties": {"id": {"type": "integer"}}})
async def clipboard_delete(id: int) -> dict:
    """Delete entry by id."""
    with session_scope() as s:
        row = s.get(ClipEntry, id)
        if row is None:
            raise ToolError("clipboard_entry_not_found", str(id))
        s.delete(row)
    return {"ok": True}


@tool(name="clipboard.clear", scope="admin", errors=[],
      schema={"type": "object", "additionalProperties": False,
              "properties": {
                  "keep_pinned": {"type": "boolean", "default": True}}})
async def clipboard_clear(keep_pinned: bool = True) -> dict:
    """Clear history. By default pinned entries survive."""
    with session_scope() as s:
        if keep_pinned:
            rows = s.exec(select(ClipEntry).where(
                ClipEntry.pinned == False)).all()
        else:
            rows = s.exec(select(ClipEntry)).all()
        for r in rows:
            s.delete(r)
        return {"deleted": len(rows)}


@tool(name="clipboard.watcher_start", scope="admin",
      errors=["clipboard_unavailable"],
      schema={"type": "object", "additionalProperties": False,
              "properties": {
                  "interval_ms": {"type": "integer", "default": 500,
                                  "minimum": 100, "maximum": 10000},
                  "cap": {"type": "integer", "default": 100,
                          "minimum": 1, "maximum": 10000},
                  "ignore_patterns": {"type": "array",
                                      "items": {"type": "string"}}}})
async def clipboard_watcher_start(interval_ms: int = 500, cap: int = 100,
                                  ignore_patterns: Optional[list] = None
                                  ) -> dict:
    """Start background clipboard polling. Off by default."""
    _ensure_clipboard()
    if _state.task and not _state.task.done():
        return {"ok": True, "running": True, "already_running": True}
    _state.interval_ms = interval_ms
    _state.cap = cap
    _state.ignore_patterns = [re.compile(p) for p in (ignore_patterns or [])]
    try:
        _state.last_content = pyperclip.paste()
    except Exception:
        _state.last_content = None
    loop = asyncio.get_running_loop()
    _state.task = loop.create_task(_watcher_loop())
    return {"ok": True, "running": True}


@tool(name="clipboard.watcher_stop", scope="admin", errors=[],
      schema={"type": "object", "additionalProperties": False,
              "properties": {}})
async def clipboard_watcher_stop() -> dict:
    """Stop watcher."""
    if _state.task and not _state.task.done():
        _state.task.cancel()
        try:
            await _state.task
        except (asyncio.CancelledError, Exception):
            pass
    _state.task = None
    return {"ok": True, "running": False}


@tool(name="clipboard.watcher_status", scope="read", errors=[],
      schema={"type": "object", "additionalProperties": False,
              "properties": {}})
async def clipboard_watcher_status() -> dict:
    """Return watcher state."""
    running = bool(_state.task and not _state.task.done())
    return {
        "running": running,
        "interval_ms": _state.interval_ms,
        "cap": _state.cap,
        "ignore_patterns": [p.pattern for p in _state.ignore_patterns],
        "last_capture_ts": _state.last_capture_ts,
    }
