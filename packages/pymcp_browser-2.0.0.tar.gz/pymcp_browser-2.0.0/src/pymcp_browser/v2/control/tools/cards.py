"""cards.* tools — Luhn validate / generate test cards / Stripe test constants."""
from __future__ import annotations
import random as _random
from typing import Optional

from ..registry import tool
from ..errors import ToolError


# Brand specs: prefix list, total length, cvc length
_BRANDS = {
    "visa": {"prefixes": ["4"], "length": 16, "cvc_length": 3},
    "mastercard": {"prefixes": ["51", "52", "53", "54", "55"],
                   "length": 16, "cvc_length": 3},
    "amex": {"prefixes": ["34", "37"], "length": 15, "cvc_length": 4},
    "discover": {"prefixes": ["6011", "65"], "length": 16, "cvc_length": 3},
}


# Curated Stripe test card matrix
_STRIPE = {
    "success": {
        "number": "4242424242424242", "brand": "visa",
        "cvc": "123", "cvc_length": 3,
        "exp_month": 12, "exp_year": 2034,
        "description": "Visa - Successful charge",
    },
    "decline": {
        "number": "4000000000000002", "brand": "visa",
        "cvc": "123", "cvc_length": 3,
        "exp_month": 12, "exp_year": 2034,
        "description": "Visa - Generic decline",
    },
    "3ds_required": {
        "number": "4000002500003155", "brand": "visa",
        "cvc": "123", "cvc_length": 3,
        "exp_month": 12, "exp_year": 2034,
        "description": "Visa - 3DS authentication required",
    },
    "insufficient_funds": {
        "number": "4000000000009995", "brand": "visa",
        "cvc": "123", "cvc_length": 3,
        "exp_month": 12, "exp_year": 2034,
        "description": "Visa - Insufficient funds decline",
    },
    "cvc_fail": {
        "number": "4000000000000127", "brand": "visa",
        "cvc": "123", "cvc_length": 3,
        "exp_month": 12, "exp_year": 2034,
        "description": "Visa - Incorrect CVC decline",
    },
    "expired": {
        "number": "4000000000000069", "brand": "visa",
        "cvc": "123", "cvc_length": 3,
        "exp_month": 12, "exp_year": 2034,
        "description": "Visa - Expired card decline",
    },
}


def _luhn_check_digit(number: str) -> str:
    """Compute Luhn check digit for a partial number (no check digit yet)."""
    digits = [int(d) for d in number]
    digits.reverse()
    total = 0
    for i, d in enumerate(digits):
        if i % 2 == 0:
            d *= 2
            if d > 9:
                d -= 9
        total += d
    return str((10 - (total % 10)) % 10)


def _luhn_valid(number: str) -> bool:
    if not number.isdigit() or len(number) < 12:
        return False
    digits = [int(d) for d in number]
    digits.reverse()
    total = 0
    for i, d in enumerate(digits):
        if i % 2 == 1:
            d *= 2
            if d > 9:
                d -= 9
        total += d
    return total % 10 == 0


@tool(name="cards.luhn_validate", scope="read", errors=[],
      schema={"type": "object", "required": ["number"],
              "additionalProperties": False,
              "properties": {"number": {"type": "string"}}})
async def cards_luhn_validate(number: str) -> dict:
    """Check if number passes Luhn algorithm."""
    cleaned = "".join(c for c in number if c.isdigit())
    return {"valid": _luhn_valid(cleaned)}


@tool(name="cards.gen", scope="read",
      errors=["card_unsupported_brand"],
      schema={"type": "object", "additionalProperties": False,
              "properties": {
                  "brand": {"type": "string", "default": "visa",
                            "enum": list(_BRANDS.keys())},
                  "seed": {"type": "integer"}}})
async def cards_gen(brand: str = "visa",
                    seed: Optional[int] = None) -> dict:
    """Generate Luhn-valid test card. NOT real payment data."""
    if brand not in _BRANDS:
        raise ToolError("card_unsupported_brand", brand)
    spec = _BRANDS[brand]
    rng = _random.Random(seed) if seed is not None else _random
    prefix = rng.choice(spec["prefixes"])
    body_len = spec["length"] - len(prefix) - 1
    body = "".join(str(rng.randint(0, 9)) for _ in range(body_len))
    partial = prefix + body
    check = _luhn_check_digit(partial)
    number = partial + check
    cvc = "".join(str(rng.randint(0, 9)) for _ in range(spec["cvc_length"]))
    return {
        "number": number,
        "brand": brand,
        "exp_month": rng.randint(1, 12),
        "exp_year": 2030 + rng.randint(0, 5),
        "cvc": cvc,
        "cvc_length": spec["cvc_length"],
    }


@tool(name="cards.stripe_test", scope="read",
      errors=["invalid_args"],
      schema={"type": "object", "additionalProperties": False,
              "properties": {
                  "kind": {"type": "string", "default": "success",
                           "enum": list(_STRIPE.keys())}}})
async def cards_stripe_test(kind: str = "success") -> dict:
    """Return a known Stripe test card by behavior kind."""
    if kind not in _STRIPE:
        raise ToolError("invalid_args", f"unknown kind: {kind}")
    return dict(_STRIPE[kind])


@tool(name="cards.stripe_list", scope="read", errors=[],
      schema={"type": "object", "additionalProperties": False,
              "properties": {}})
async def cards_stripe_list() -> dict:
    """List all curated Stripe test cards."""
    return {"cards": [
        {"kind": k, **v} for k, v in _STRIPE.items()
    ]}
