"""phone.* tools — validate / format / generate phone numbers via libphonenumber."""
from __future__ import annotations
from typing import Optional

import phonenumbers
from faker import Faker

from ..registry import tool
from ..errors import ToolError


_FORMATS = {
    "E164": phonenumbers.PhoneNumberFormat.E164,
    "NATIONAL": phonenumbers.PhoneNumberFormat.NATIONAL,
    "INTERNATIONAL": phonenumbers.PhoneNumberFormat.INTERNATIONAL,
    "RFC3966": phonenumbers.PhoneNumberFormat.RFC3966,
}

_KIND_MAP = {
    phonenumbers.PhoneNumberType.MOBILE: "mobile",
    phonenumbers.PhoneNumberType.FIXED_LINE: "fixed_line",
    phonenumbers.PhoneNumberType.FIXED_LINE_OR_MOBILE: "fixed_or_mobile",
    phonenumbers.PhoneNumberType.TOLL_FREE: "toll_free",
    phonenumbers.PhoneNumberType.PREMIUM_RATE: "premium_rate",
    phonenumbers.PhoneNumberType.SHARED_COST: "shared_cost",
    phonenumbers.PhoneNumberType.VOIP: "voip",
    phonenumbers.PhoneNumberType.PERSONAL_NUMBER: "personal",
    phonenumbers.PhoneNumberType.PAGER: "pager",
    phonenumbers.PhoneNumberType.UAN: "uan",
    phonenumbers.PhoneNumberType.VOICEMAIL: "voicemail",
    phonenumbers.PhoneNumberType.UNKNOWN: "unknown",
}

# Region -> Faker locale fallback chain
_REGION_TO_LOCALE = {
    "US": "en_US", "GB": "en_GB", "CA": "en_CA", "AU": "en_AU",
    "PT": "pt_PT", "BR": "pt_BR", "ES": "es_ES", "MX": "es_MX",
    "FR": "fr_FR", "DE": "de_DE", "IT": "it_IT", "NL": "nl_NL",
    "JP": "ja_JP", "CN": "zh_CN", "KR": "ko_KR", "IN": "en_IN",
    "RU": "ru_RU", "PL": "pl_PL",
}


def _parse(number: str, region: Optional[str]):
    try:
        return phonenumbers.parse(number, region)
    except phonenumbers.NumberParseException as e:
        raise ToolError("phone_invalid", str(e))


@tool(name="phone.validate", scope="read",
      errors=["phone_invalid"],
      schema={"type": "object", "required": ["number"],
              "additionalProperties": False,
              "properties": {
                  "number": {"type": "string"},
                  "region": {"type": "string"}}})
async def phone_validate(number: str, region: Optional[str] = None) -> dict:
    """Parse + validate. Returns {valid, region, kind}."""
    n = _parse(number, region)
    valid = phonenumbers.is_valid_number(n)
    kind = _KIND_MAP.get(phonenumbers.number_type(n), "unknown")
    return {
        "valid": valid,
        "region": phonenumbers.region_code_for_number(n),
        "kind": kind,
    }


@tool(name="phone.format", scope="read",
      errors=["phone_invalid", "invalid_args"],
      schema={"type": "object", "required": ["number"],
              "additionalProperties": False,
              "properties": {
                  "number": {"type": "string"},
                  "region": {"type": "string"},
                  "format": {"type": "string", "default": "E164",
                             "enum": list(_FORMATS.keys())}}})
async def phone_format(number: str, region: Optional[str] = None,
                       format: str = "E164") -> dict:
    """Format number to E164 / NATIONAL / INTERNATIONAL / RFC3966."""
    if format not in _FORMATS:
        raise ToolError("invalid_args", f"unknown format: {format}")
    n = _parse(number, region)
    return {"formatted": phonenumbers.format_number(n, _FORMATS[format])}


@tool(name="phone.gen", scope="read",
      errors=["phone_invalid"],
      schema={"type": "object", "additionalProperties": False,
              "properties": {
                  "region": {"type": "string", "default": "US"}}})
async def phone_gen(region: str = "US") -> dict:
    """Generate a region-valid phone number via Faker, validated by libphonenumber."""
    locale = _REGION_TO_LOCALE.get(region.upper(), "en_US")
    f = Faker(locale)
    last_err = None
    for _ in range(10):
        raw = f.phone_number()
        # Strip Faker decoration
        cleaned = "".join(c for c in raw if c.isdigit() or c == "+")
        try:
            n = phonenumbers.parse(cleaned, region)
        except phonenumbers.NumberParseException as e:
            last_err = e
            continue
        if phonenumbers.is_valid_number(n):
            return {
                "number_e164": phonenumbers.format_number(
                    n, phonenumbers.PhoneNumberFormat.E164),
                "number_national": phonenumbers.format_number(
                    n, phonenumbers.PhoneNumberFormat.NATIONAL),
                "region": phonenumbers.region_code_for_number(n) or region,
            }
    # Fallback: example_number for region
    example = phonenumbers.example_number(region)
    if example is not None:
        return {
            "number_e164": phonenumbers.format_number(
                example, phonenumbers.PhoneNumberFormat.E164),
            "number_national": phonenumbers.format_number(
                example, phonenumbers.PhoneNumberFormat.NATIONAL),
            "region": region,
        }
    raise ToolError("phone_invalid",
                    f"could not generate valid number for region {region}",
                    details={"last_error": str(last_err) if last_err else None})
