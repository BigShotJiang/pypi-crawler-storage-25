"""form.* tools."""
from __future__ import annotations
from ..registry import tool
from ..errors import ToolError
from ...core.session import SessionRegistry
from ...core.target_resolver import resolve_target, resolve_page
from ...core import human as _human
from playwright.async_api import TimeoutError as PWTimeout

_S = SessionRegistry.get


@tool(name="form.fill", scope="write", alias="fill",
      errors=["target_not_found", "ref_stale", "timeout"],
      schema={"type": "object", "required": ["session_id", "target", "value"], "properties": {
          "session_id": {"type": "string"}, "target": {"type": "string"},
          "value": {"type": "string"}, "clear": {"type": "boolean", "default": True},
          "timeout_ms": {"type": "integer", "default": 10000},
          "force": {"type": "boolean", "default": False}}})
async def form_fill(session_id: str, target: str, value: str, clear: bool = True,
                    timeout_ms: int = 10000, force: bool = False) -> dict:
    s = _S().lookup(session_id)
    await _human.auto_wait_load(s)
    if s.mode == "human":
        from .key import key_type_human
        if clear:
            async with s.lock:
                h = await resolve_target(s, target)
                try:
                    await h.fill("", timeout=timeout_ms, force=force)
                except Exception:
                    pass
        lo, hi = _human.type_delay_range(s)
        kwargs = {"session_id": session_id, "target": target, "text": value}
        if hi > 0:
            kwargs["delay_min_ms"] = lo
            kwargs["delay_max_ms"] = hi
        out = await key_type_human(**kwargs)
        await _human.post_action_sleep(s)
        return out
    async with s.lock:
        h = await resolve_target(s, target)
        try:
            if clear:
                await h.fill(value, timeout=timeout_ms, force=force)
            else:
                await h.type(value, delay=0, timeout=timeout_ms)
        except PWTimeout as e:
            raise ToolError("timeout", str(e))
    await _human.post_action_sleep(s)
    return {"ok": True}


@tool(name="form.clear", scope="write", errors=["target_not_found", "ref_stale"],
      schema={"type": "object", "required": ["session_id", "target"], "properties": {
          "session_id": {"type": "string"}, "target": {"type": "string"}}})
async def form_clear(session_id: str, target: str) -> dict:
    s = _S().lookup(session_id)
    async with s.lock:
        h = await resolve_target(s, target)
        await h.fill("")
    return {"ok": True}


@tool(name="form.select", scope="write", errors=["target_not_found", "ref_stale"],
      schema={"type": "object", "required": ["session_id", "target"], "properties": {
          "session_id": {"type": "string"}, "target": {"type": "string"},
          "value": {"type": "string"}, "values": {"type": "array"},
          "label": {"type": "string"}, "index": {"type": "integer"}}})
async def form_select(session_id: str, target: str, value: str | None = None,
                      values: list | None = None, label: str | None = None,
                      index: int | None = None) -> dict:
    s = _S().lookup(session_id)
    async with s.lock:
        h = await resolve_target(s, target)
        opts: dict = {}
        if value is not None:
            opts["value"] = value
        if values is not None:
            opts["value"] = values
        if label is not None:
            opts["label"] = label
        if index is not None:
            opts["index"] = index
        selected = await h.select_option(**opts)
    return {"selected": selected if isinstance(selected, list) else [selected]}


@tool(name="form.checkbox", scope="write", errors=["target_not_found", "ref_stale"],
      schema={"type": "object", "required": ["session_id", "target", "checked"], "properties": {
          "session_id": {"type": "string"}, "target": {"type": "string"},
          "checked": {"type": "boolean"}}})
async def form_checkbox(session_id: str, target: str, checked: bool) -> dict:
    s = _S().lookup(session_id)
    async with s.lock:
        h = await resolve_target(s, target)
        if checked:
            await h.check()
        else:
            await h.uncheck()
    return {"ok": True}


@tool(name="form.upload", scope="write", errors=["target_not_found", "ref_stale"],
      schema={"type": "object", "required": ["session_id", "target", "paths"], "properties": {
          "session_id": {"type": "string"}, "target": {"type": "string"},
          "paths": {"type": "array"}}})
async def form_upload(session_id: str, target: str, paths: list[str]) -> dict:
    s = _S().lookup(session_id)
    async with s.lock:
        h = await resolve_target(s, target)
        await h.set_input_files(paths)
    return {"ok": True}


@tool(name="form.file_chooser", scope="write",
      schema={"type": "object", "required": ["session_id", "paths"], "properties": {
          "session_id": {"type": "string"}, "paths": {"type": "array"}}})
async def form_file_chooser(session_id: str, paths: list[str]) -> dict:
    s = _S().lookup(session_id)
    page = await resolve_page(s)

    async def handler(fc):
        try:
            await fc.set_files(paths)
        except Exception:
            pass
    page.once("filechooser", handler)
    return {"ok": True, "armed": True}
