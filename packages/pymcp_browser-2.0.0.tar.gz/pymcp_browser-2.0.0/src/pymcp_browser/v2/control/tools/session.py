"""session.* tools."""
from __future__ import annotations
import time
from pathlib import Path
import json
from ..registry import tool
from ..errors import ToolError
from ...core.session import SessionRegistry
from ...core.proxy_probe import probe_via_context, apply_fingerprint
from ...core.target_resolver import resolve_page
from ...config import settings
from ...storage.db import session_scope as _db_scope
from ...storage.models import SessionEvent
from sqlmodel import select as _sel

# D14 in-memory checkpoint store (per-session, label -> storage_state dict).
_CHECKPOINTS: dict[str, dict[str, dict]] = {}


@tool(name="session.create", scope="admin", errors=["invalid_args", "proxy_unreachable", "internal"],
      schema={"type": "object", "additionalProperties": False, "properties": {
          "profile_name": {"type": "string"},
          "proxy_provider": {"type": "string", "enum": ["brightdata", "brightdata_scraping_browser", "proxyfog"], "default": "proxyfog"},
          "proxy_zone": {"type": "string"},
          "proxyfog_mode": {"type": "string", "enum": ["sticky", "rotating"], "default": "sticky"},
          "proxyfog_ttl_minutes": {"type": "integer", "default": 30,
                                   "description": "clamped [1,60] for sticky mode"},
          "proxyfog_protocol": {"type": "string", "enum": ["http", "https", "socks5"],
                                "default": "http"},
          "country": {"type": "string", "description": "no-op for proxyfog (deferred)"},
          "fingerprint_overrides": {"type": "object"},
          "mode": {"type": "string", "enum": ["vanilla", "stealth", "human"], "default": "stealth"},
          "headless": {"type": "boolean"},
          "no_proxy": {"type": "boolean", "default": False},
          "record_heavy": {"type": "boolean", "default": False},
          "viewport": {"type": "object"},
          "kind": {"type": "string", "enum": ["browser", "mail"], "default": "browser"},
          "account_label": {"type": "string",
                            "description": "required when kind='mail'"},
          "auto_diagnose": {"type": "boolean",
                            "description": "true=force run, false=skip, omit=follow global toggle (default ON for browser kind)"},
          "engine": {"type": "string", "enum": ["chromium", "camoufox", "patchright"],
                     "default": "chromium",
                     "description": "Browser engine. chromium=fast/debug. camoufox=stealth Firefox. patchright=stealth Chromium fork."},
      }})
async def session_create(**kwargs) -> dict:
    """Create new session (kind='browser' default; 'mail' for IMAP/SMTP)."""
    reg = SessionRegistry.get()
    s = await reg.create(**kwargs)
    if getattr(s, "kind", "browser") == "mail":
        return {"session_id": s.id, "kind": "mail",
                "account_label": s.account_label,
                "imap_capabilities": s.imap.capabilities if s.imap else []}
    out = {"session_id": s.id, "kind": "browser",
           "proxy_zone": s.proxy_zone,
           "proxy_session_tag": s.proxy_session_tag,
           "mode": s.mode, "headless": s.headless, "viewport": s.viewport}
    if s.proxy_egress_ip:
        out["proxy_egress_ip"] = s.proxy_egress_ip
    diag = getattr(s, "_diag_cache", None)
    if diag:
        net = diag.get("network") or {}
        out["diagnosis"] = {
            "ip": net.get("ip") if isinstance(net, dict) else None,
            "country": net.get("country") if isinstance(net, dict) else None,
            "org": net.get("org") if isinstance(net, dict) else None,
            "ip_match": diag.get("ip_match"),
            "duration_ms": diag.get("duration_ms"),
        }
    return out


@tool(name="session.close", scope="admin", errors=["session_not_found"],
      schema={"type": "object", "required": ["session_id"], "properties": {
          "session_id": {"type": "string"}, "persist": {"type": "boolean", "default": True}}})
async def session_close(session_id: str, persist: bool = True) -> dict:
    await SessionRegistry.get().close(session_id, persist=persist)
    return {"ok": True}


@tool(name="session.list", scope="read",
      schema={"type": "object", "properties": {}})
async def session_list() -> dict:
    out = []
    for s in SessionRegistry.get().list():
        kind = getattr(s, "kind", "browser")
        if kind == "mail":
            out.append({
                "session_id": s.id, "kind": "mail",
                "account_label": s.account_label,
                "last_activity_ts": s.last_activity_ts,
                "idle_count": len(s.idle_tasks),
            })
        else:
            out.append({
                "session_id": s.id, "kind": "browser",
                "mode": s.mode, "proxy_zone": s.proxy_zone,
                "headless": s.headless,
                "last_activity_ts": s.last_activity_ts,
                "page_count": len(s.pages),
                "ref_count": s.ref_store.count(),
            })
    return {"sessions": out}


@tool(name="session.clone", scope="admin",
      errors=["session_not_found", "engine_mismatch", "internal"],
      schema={"type": "object", "required": ["session_id"], "properties": {
          "session_id": {"type": "string"},
          "new_profile_name": {"type": "string"},
          "with_state": {"type": "boolean", "default": True},
          "proxy_provider": {"type": "string"}, "proxy_zone": {"type": "string"},
          "proxyfog_mode": {"type": "string"}, "country": {"type": "string"},
          "fingerprint_overrides": {"type": "object"},
          "mode": {"type": "string"}, "headless": {"type": "boolean"},
          "engine": {"type": "string", "enum": ["chromium", "camoufox", "patchright"],
                     "description": "Override engine. chromium<->patchright allowed; camoufox isolated."},
      }})
async def session_clone(session_id: str, new_profile_name: str | None = None,
                        with_state: bool = True, **overrides) -> dict:
    reg = SessionRegistry.get()
    src = reg.lookup(session_id)
    src_engine = getattr(src, "engine", "chromium")
    requested_engine = overrides.get("engine") or src_engine
    blink = {"chromium", "patchright"}
    if requested_engine != src_engine:
        if not (src_engine in blink and requested_engine in blink):
            raise ToolError(
                "engine_mismatch",
                f"cannot clone from {src_engine} to {requested_engine}",
            )
    state = None
    if with_state and src.context:
        try:
            state = await src.context.storage_state()
        except Exception:
            state = None
    spec = dict(
        profile_name=new_profile_name or src.profile_id,
        proxy_provider=src.proxy_provider, proxy_zone=src.proxy_zone,
        mode=src.mode, headless=src.headless, viewport=src.viewport,
        no_proxy=src.proxy_provider is None,
        parent_session_id=src.id, storage_state=state,
        engine=requested_engine,
    )
    spec.update({k: v for k, v in overrides.items() if v is not None})
    new = await reg.create(**spec)
    return {"session_id": new.id, "parent_session_id": src.id, "engine": new.engine}


@tool(name="session.touch", scope="admin", errors=["session_not_found"],
      schema={"type": "object", "required": ["session_id"],
              "properties": {"session_id": {"type": "string"}}})
async def session_touch(session_id: str) -> dict:
    s = SessionRegistry.get().lookup(session_id)
    s.touch()
    remaining_ms = max(0, settings.session_idle_ttl_ms - int((time.time() - s.last_activity_ts) * 1000))
    return {"ok": True, "idle_ttl_remaining_ms": remaining_ms}


@tool(name="session.save_state", scope="admin", errors=["session_not_found"],
      schema={"type": "object", "required": ["session_id"], "properties": {
          "session_id": {"type": "string"}, "path": {"type": "string"}}})
async def session_save_state(session_id: str, path: str | None = None) -> dict:
    s = SessionRegistry.get().lookup(session_id)
    p = Path(path) if path else Path(settings.storage_dir) / f"{s.id}.json"
    p.parent.mkdir(parents=True, exist_ok=True)
    await s.context.storage_state(path=str(p))
    return {"path": str(p), "size_bytes": p.stat().st_size}


@tool(name="session.load_state", scope="admin", errors=["session_not_found", "invalid_args"],
      schema={"type": "object", "required": ["session_id", "path"], "properties": {
          "session_id": {"type": "string"}, "path": {"type": "string"}}})
async def session_load_state(session_id: str, path: str) -> dict:
    s = SessionRegistry.get().lookup(session_id)
    p = Path(path)
    if not p.exists():
        raise ToolError("invalid_args", f"path not found: {path}")
    state = json.loads(p.read_text(encoding="utf-8"))
    for c in state.get("cookies", []):
        try:
            await s.context.add_cookies([c])
        except Exception:
            pass
    return {"ok": True}


# D11: proxyfog country hint with retry — verifies via diagnosis (ipinfo) and
# rotates sticky session up to N times until country matches.

@tool(name="session.create_with_country", scope="admin",
      errors=["invalid_args", "proxy_unreachable", "proxy_country_unavailable",
              "internal"],
      schema={"type": "object", "required": ["country"], "properties": {
          "country": {"type": "string",
                      "description": "ISO-3166 alpha-2 (e.g. 'ZA'); matched against ipinfo country"},
          "max_retries": {"type": "integer", "default": 5},
          "session_spec": {"type": "object",
                           "description": "passed through to session.create"}}})
async def session_create_with_country(country: str, max_retries: int = 5,
                                      session_spec: dict | None = None) -> dict:
    """D11: create a session and re-roll until proxy egress country matches.

    Useful for ProxyFog sticky where country is random per assignment."""
    spec = dict(session_spec or {})
    spec.setdefault("proxy_provider", "proxyfog")
    spec.setdefault("proxyfog_mode", "sticky")
    target = country.upper()
    reg = SessionRegistry.get()
    last_country: str | None = None
    last_session_id: str | None = None
    for attempt in range(1, max(1, max_retries) + 1):
        s = await reg.create(**spec)
        diag = getattr(s, "_diag_cache", None)
        net = (diag or {}).get("network") or {}
        cc = (net.get("country") or "").upper() if isinstance(net, dict) else ""
        last_country = cc or None
        last_session_id = s.id
        if cc == target:
            return {"session_id": s.id, "country": cc, "attempt": attempt,
                    "proxy_egress_ip": s.proxy_egress_ip}
        # mismatch — close and retry
        try:
            await reg.close(s.id, persist=False)
        except Exception:
            pass
    raise ToolError("proxy_country_unavailable",
                    f"requested {target}, last seen {last_country or 'unknown'} "
                    f"after {max_retries} attempts")


# D15: probe egress + create_matched (reactive fingerprint molding).

@tool(name="session.probe_egress", scope="read",
      errors=["session_not_found", "internal"],
      schema={"type": "object", "required": ["session_id"], "properties": {
          "session_id": {"type": "string"},
          "timeout_ms": {"type": "integer", "default": 8000}}})
async def session_probe_egress(session_id: str, timeout_ms: int = 8000) -> dict:
    """Probe actual proxy egress IP/geo through the session's browser context.

    Idempotent — does not modify the session. Returns ipinfo-shaped blob:
    {ip, country, region, city, timezone, org, loc:{latitude,longitude}, source}.
    On failure: {error: 'probe_failed', source: None}.
    """
    s = SessionRegistry.get().lookup(session_id)
    if not s.context:
        raise ToolError("session_not_found", "no browser context")
    page = None
    try:
        page = await resolve_page(s)
    except Exception:
        page = None
    return await probe_via_context(s.context, page=page, timeout_ms=timeout_ms)


@tool(name="session.create_matched", scope="admin",
      errors=["invalid_args", "proxy_unreachable", "proxy_country_unavailable",
              "internal"],
      schema={"type": "object", "properties": {
          "country": {"type": "string",
                      "description": "ISO-3166 alpha-2 preferred country; "
                                     "best-effort. Omit to skip retry phase."},
          "max_retries": {"type": "integer", "default": 3,
                          "description": "country-match retries before falling back"},
          "session_spec": {"type": "object",
                           "description": "passed through to session.create"},
          "set_geolocation": {"type": "boolean", "default": True},
          "set_locale": {"type": "boolean", "default": True},
          "set_timezone": {"type": "boolean", "default": True}}})
async def session_create_matched(country: str | None = None,
                                 max_retries: int = 3,
                                 session_spec: dict | None = None,
                                 set_geolocation: bool = True,
                                 set_locale: bool = True,
                                 set_timezone: bool = True) -> dict:
    """Create a session and guarantee a coherent fingerprint.

    Strategy:
      1. If `country` given → re-roll sticky session up to `max_retries` until
         egress country matches. Cap retries low (default 3) to avoid burning
         the proxy pool when target is unavailable.
      2. On retry exhaustion OR no country → keep last session, probe its
         actual egress, mold browser fingerprint (locale/timezone/geo) to match
         the proxy's real country. Result is consistent, never mismatched.
    """
    spec = dict(session_spec or {})
    spec.setdefault("proxy_provider", "proxyfog")
    spec.setdefault("proxyfog_mode", "sticky")
    target = (country or "").upper() or None
    reg = SessionRegistry.get()

    s = None
    matched = False
    attempts = 0
    last_country: str | None = None

    if target:
        for attempt in range(1, max(1, max_retries) + 1):
            attempts = attempt
            cand = await reg.create(**spec)
            diag = getattr(cand, "_diag_cache", None)
            net = (diag or {}).get("network") or {}
            cc = (net.get("country") or "").upper() if isinstance(net, dict) else ""
            last_country = cc or None
            if cc == target:
                s = cand
                matched = True
                break
            if attempt < max_retries:
                try:
                    await reg.close(cand.id, persist=False)
                except Exception:
                    pass
            else:
                s = cand  # keep last for reactive mold
    else:
        s = await reg.create(**spec)
        attempts = 1

    if s is None:
        raise ToolError("internal", "session.create_matched produced no session")

    # Probe + mold (regardless of match — molding is a no-op for matched
    # countries when probe agrees, but lets us return a complete blob).
    page = None
    try:
        page = await resolve_page(s)
    except Exception:
        page = None
    probe = await probe_via_context(s.context, page=page) if s.context else {"error": "no_context"}

    applied: dict = {}
    if "error" not in probe and s.context:
        applied = await apply_fingerprint(
            s.context, page, probe,
            set_geolocation=set_geolocation,
            set_locale=set_locale,
            set_timezone=set_timezone,
        )

    return {
        "session_id": s.id,
        "requested_country": target,
        "actual_country": (probe.get("country") if "error" not in probe
                           else last_country),
        "matched": matched,
        "attempts": attempts,
        "probe": probe,
        "applied_fingerprint": applied,
        "proxy_egress_ip": s.proxy_egress_ip,
    }


# D8: session_log_event — replaces PowerShell+sqlite3 fallback for activity log.

@tool(name="session.log_event", scope="write",
      schema={"type": "object", "required": ["session_id", "key", "value"],
              "properties": {"session_id": {"type": "string"},
                             "key": {"type": "string"},
                             "value": {}}})
async def session_log_event(session_id: str, key: str, value) -> dict:
    """Append-only per-session activity log row. value JSON-encoded if dict/list."""
    if isinstance(value, (dict, list)):
        val_str = json.dumps(value, ensure_ascii=False, default=str)
    else:
        val_str = str(value)
    with _db_scope() as db:
        row = SessionEvent(session_id=session_id, ts=time.time(),
                           key=key, value=val_str)
        db.add(row)
    return {"ok": True}


@tool(name="session.log_list", scope="read",
      schema={"type": "object", "required": ["session_id"],
              "properties": {"session_id": {"type": "string"},
                             "key": {"type": "string"},
                             "limit": {"type": "integer", "default": 200}}})
async def session_log_list(session_id: str, key: str | None = None,
                           limit: int = 200) -> dict:
    with _db_scope() as db:
        stmt = _sel(SessionEvent).where(SessionEvent.session_id == session_id)
        if key:
            stmt = stmt.where(SessionEvent.key == key)
        stmt = stmt.order_by(SessionEvent.ts.desc()).limit(limit)
        rows = db.exec(stmt).all()
    out = []
    for r in rows:
        try:
            v = json.loads(r.value)
        except Exception:
            v = r.value
        out.append({"id": r.id, "ts": r.ts, "key": r.key, "value": v})
    return {"events": out, "count": len(out)}


# D14: in-memory storage_state checkpoint helpers (intra-session only).

@tool(name="session.checkpoint", scope="admin", errors=["session_not_found"],
      schema={"type": "object", "required": ["session_id", "label"],
              "properties": {"session_id": {"type": "string"},
                             "label": {"type": "string"}}})
async def session_checkpoint(session_id: str, label: str) -> dict:
    """Save current storage_state in memory under a label. Not persisted across restart."""
    s = SessionRegistry.get().lookup(session_id)
    if not s.context:
        raise ToolError("session_not_found", "no browser context")
    state = await s.context.storage_state()
    _CHECKPOINTS.setdefault(session_id, {})[label] = state
    return {"ok": True, "label": label,
            "cookie_count": len(state.get("cookies", []) or []),
            "origin_count": len(state.get("origins", []) or [])}


@tool(name="session.restore", scope="admin", errors=["session_not_found", "invalid_args"],
      schema={"type": "object", "required": ["session_id", "label"],
              "properties": {"session_id": {"type": "string"},
                             "label": {"type": "string"}}})
async def session_restore(session_id: str, label: str) -> dict:
    s = SessionRegistry.get().lookup(session_id)
    state = _CHECKPOINTS.get(session_id, {}).get(label)
    if state is None:
        raise ToolError("invalid_args", f"checkpoint label not found: {label}")
    if not s.context:
        raise ToolError("session_not_found", "no browser context")
    cookies = state.get("cookies", []) or []
    if cookies:
        try:
            await s.context.add_cookies(cookies)
        except Exception:
            pass
    return {"ok": True, "cookie_count": len(cookies)}
