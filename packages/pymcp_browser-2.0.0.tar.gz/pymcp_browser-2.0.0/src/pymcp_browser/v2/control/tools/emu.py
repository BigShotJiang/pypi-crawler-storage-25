"""emu.* tools."""
from __future__ import annotations
from ..registry import tool
from ..errors import ToolError
from ...core.session import SessionRegistry
from ...core.target_resolver import resolve_page

_S = SessionRegistry.get


def _require_cdp(s, feature: str) -> None:
    """Raise engine_unsupported_feature when session engine has no CDP (camoufox)."""
    eng = getattr(s, "engine", "chromium")
    if eng == "camoufox":
        raise ToolError(
            "engine_unsupported_feature",
            f"{feature} requires chromium-family engine; current: {eng}",
        )


@tool(name="emu.viewport", scope="admin",
      schema={"type": "object", "required": ["session_id", "width", "height"], "properties": {
          "session_id": {"type": "string"}, "width": {"type": "integer"},
          "height": {"type": "integer"}}})
async def emu_viewport(session_id: str, width: int, height: int) -> dict:
    s = _S().lookup(session_id)
    page = await resolve_page(s)
    await page.set_viewport_size({"width": width, "height": height})
    s.viewport = {"width": width, "height": height}
    return {"ok": True}


@tool(name="emu.user_agent", scope="admin",
      schema={"type": "object", "required": ["session_id", "user_agent"], "properties": {
          "session_id": {"type": "string"}, "user_agent": {"type": "string"}}})
async def emu_user_agent(session_id: str, user_agent: str) -> dict:
    s = _S().lookup(session_id)
    _require_cdp(s, "emu.user_agent")
    page = await resolve_page(s)
    try:
        client = await s.context.new_cdp_session(page)
        await client.send("Network.setUserAgentOverride", {"userAgent": user_agent})
    except Exception as e:
        raise ToolError("internal", str(e))
    return {"ok": True}


@tool(name="emu.locale", scope="admin",
      schema={"type": "object", "required": ["session_id", "locale"], "properties": {
          "session_id": {"type": "string"}, "locale": {"type": "string"}}})
async def emu_locale(session_id: str, locale: str) -> dict:
    s = _S().lookup(session_id)
    _require_cdp(s, "emu.locale")
    page = await resolve_page(s)
    try:
        client = await s.context.new_cdp_session(page)
        await client.send("Emulation.setLocaleOverride", {"locale": locale})
    except Exception as e:
        raise ToolError("internal", str(e))
    return {"ok": True}


@tool(name="emu.timezone", scope="admin",
      schema={"type": "object", "required": ["session_id", "timezone"], "properties": {
          "session_id": {"type": "string"}, "timezone": {"type": "string"}}})
async def emu_timezone(session_id: str, timezone: str) -> dict:
    s = _S().lookup(session_id)
    _require_cdp(s, "emu.timezone")
    page = await resolve_page(s)
    try:
        client = await s.context.new_cdp_session(page)
        await client.send("Emulation.setTimezoneOverride", {"timezoneId": timezone})
    except Exception as e:
        raise ToolError("internal", str(e))
    return {"ok": True}


@tool(name="emu.device", scope="admin",
      schema={"type": "object", "required": ["session_id", "device"], "properties": {
          "session_id": {"type": "string"}, "device": {"type": "string"}}})
async def emu_device(session_id: str, device: str) -> dict:
    s = _S().lookup(session_id)
    from ...core.browser_manager import BrowserManager
    bm = await BrowserManager.get()
    pw = bm._pw_playwright
    if pw is None:
        await bm._ensure_playwright()
        pw = bm._pw_playwright
    devices = pw.devices if pw else {}
    d = devices.get(device)
    if not d:
        raise ToolError("invalid_args", f"unknown device {device}")
    page = await resolve_page(s)
    if d.get("viewport"):
        await page.set_viewport_size(d["viewport"])
        s.viewport = d["viewport"]
    if d.get("user_agent"):
        eng = getattr(s, "engine", "chromium")
        if eng == "camoufox":
            try:
                await s.context.set_extra_http_headers({"User-Agent": d["user_agent"]})
            except Exception:
                pass
        else:
            try:
                client = await s.context.new_cdp_session(page)
                await client.send("Network.setUserAgentOverride", {"userAgent": d["user_agent"]})
            except Exception:
                pass
    return {"ok": True, "viewport": d.get("viewport"), "user_agent": d.get("user_agent")}


@tool(name="emu.geolocation", scope="admin",
      schema={"type": "object", "required": ["session_id", "latitude", "longitude"], "properties": {
          "session_id": {"type": "string"}, "latitude": {"type": "number"},
          "longitude": {"type": "number"}, "accuracy": {"type": "number"}}})
async def emu_geolocation(session_id: str, latitude: float, longitude: float,
                          accuracy: float | None = None) -> dict:
    s = _S().lookup(session_id)
    geo = {"latitude": latitude, "longitude": longitude}
    if accuracy is not None:
        geo["accuracy"] = accuracy
    await s.context.set_geolocation(geo)
    return {"ok": True}


@tool(name="emu.permissions", scope="admin",
      schema={"type": "object", "required": ["session_id", "permissions"], "properties": {
          "session_id": {"type": "string"}, "permissions": {"type": "array"},
          "origin": {"type": "string"}}})
async def emu_permissions(session_id: str, permissions: list[str],
                          origin: str | None = None) -> dict:
    s = _S().lookup(session_id)
    if origin:
        await s.context.grant_permissions(permissions, origin=origin)
    else:
        await s.context.grant_permissions(permissions)
    return {"ok": True}


@tool(name="emu.color_scheme", scope="admin",
      schema={"type": "object", "required": ["session_id", "scheme"], "properties": {
          "session_id": {"type": "string"},
          "scheme": {"type": "string", "enum": ["light", "dark", "no-preference"]}}})
async def emu_color_scheme(session_id: str, scheme: str) -> dict:
    s = _S().lookup(session_id)
    page = await resolve_page(s)
    await page.emulate_media(color_scheme=scheme)
    return {"ok": True}
