"""auth.* tools (scaffolded; bypassed when PYMCP_NO_AUTH=1)."""
from __future__ import annotations
import hashlib
import secrets
import time
from sqlmodel import select
from ..registry import tool
from ..errors import ToolError
from ...config import settings
from ...storage.db import session_scope
from ...storage.models import ApiToken


@tool(name="auth.create_token", scope="admin", errors=["invalid_args"],
      schema={"type": "object", "required": ["scope", "label"], "properties": {
          "scope": {"type": "string", "enum": ["read", "write", "admin"]},
          "label": {"type": "string"},
          "expires_in_s": {"type": "integer"}}})
async def auth_create_token(scope: str, label: str,
                            expires_in_s: int | None = None) -> dict:
    raw = secrets.token_urlsafe(32)
    prefix = raw[:8]
    h = hashlib.sha256(raw.encode()).hexdigest()
    now = time.time()
    expires_ts = (now + expires_in_s) if expires_in_s else None
    with session_scope() as s:
        s.add(ApiToken(prefix=prefix, hash=h, scope=scope, label=label,
                       created_ts=now, expires_ts=expires_ts))
    return {"token": raw, "prefix": prefix, "expires_at": expires_ts}


@tool(name="auth.revoke_token", scope="admin", errors=["target_not_found"],
      schema={"type": "object", "required": ["prefix"], "properties": {
          "prefix": {"type": "string"}}})
async def auth_revoke_token(prefix: str) -> dict:
    with session_scope() as s:
        row = s.get(ApiToken, prefix)
        if row is None:
            raise ToolError("target_not_found", prefix)
        s.delete(row)
    return {"ok": True}


@tool(name="auth.list_tokens", scope="admin",
      schema={"type": "object", "properties": {}})
async def auth_list_tokens() -> dict:
    with session_scope() as s:
        rows = s.exec(select(ApiToken)).all()
    return {"tokens": [{"prefix": r.prefix, "scope": r.scope, "label": r.label,
                        "created": r.created_ts, "last_used": r.last_used_ts,
                        "expires_at": r.expires_ts} for r in rows]}


@tool(name="auth.whoami", scope="read",
      schema={"type": "object", "properties": {}})
async def auth_whoami() -> dict:
    if settings.pymcp_no_auth:
        return {"dev_bypass": True, "scope": "admin"}
    return {"scope": "admin", "token_label": "current"}
