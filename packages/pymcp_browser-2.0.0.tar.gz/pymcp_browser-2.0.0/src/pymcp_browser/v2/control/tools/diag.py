"""diag.* tools — session auto-diagnosis (network + fingerprint capture).

See ADR-0005 + Docs/updates-v2-implementation-plan.md Phase 8.
"""
from __future__ import annotations
import json
from typing import Any, Optional

from sqlmodel import select

from ..registry import tool
from ..errors import ToolError
from ...core.session import SessionRegistry
from ...core.diagnosis import run_diagnosis
from ...storage.db import session_scope, kv_get, kv_set
from ...storage.models import SessionDiagnosis


@tool(name="diag.run", scope="write",
      errors=["session_not_found", "no_active_page", "diag_failed", "timeout"],
      schema={"type": "object", "required": ["session_id"],
              "additionalProperties": False,
              "properties": {
                  "session_id": {"type": "string"},
                  "force": {"type": "boolean", "default": False},
              }})
async def diag_run(session_id: str, force: bool = False) -> dict:
    """Run diagnosis on session. Cached unless force=True."""
    sess = SessionRegistry.get().lookup(session_id)
    if getattr(sess, "kind", "browser") != "browser":
        raise ToolError("invalid_args", "diag.run only valid for kind='browser'")
    return await run_diagnosis(sess, force=force)


@tool(name="diag.get", scope="read",
      errors=["session_not_found", "diag_not_found"],
      schema={"type": "object", "required": ["session_id"],
              "additionalProperties": False,
              "properties": {
                  "session_id": {"type": "string"},
                  "from_db": {"type": "boolean", "default": False,
                              "description": "true = read latest from DB; false = use in-session cache"},
              }})
async def diag_get(session_id: str, from_db: bool = False) -> dict:
    """Fetch latest diagnosis blob for a session."""
    if not from_db:
        try:
            sess = SessionRegistry.get().lookup(session_id)
            cached = getattr(sess, "_diag_cache", None)
            if cached:
                return cached
        except ToolError:
            pass
    with session_scope() as s:
        row = s.exec(
            select(SessionDiagnosis)
            .where(SessionDiagnosis.session_id == session_id)
            .order_by(SessionDiagnosis.captured_ts.desc())
        ).first()
    if row is None:
        raise ToolError("diag_not_found", f"no diagnosis for session {session_id}")
    try:
        return json.loads(row.blob_json)
    except Exception:
        raise ToolError("diag_failed", "blob_json corrupt")


@tool(name="diag.history", scope="read",
      errors=["session_not_found"],
      schema={"type": "object", "required": ["session_id"],
              "additionalProperties": False,
              "properties": {
                  "session_id": {"type": "string"},
                  "limit": {"type": "integer", "default": 10,
                            "minimum": 1, "maximum": 100},
              }})
async def diag_history(session_id: str, limit: int = 10) -> dict:
    """List diagnosis snapshots for a session, newest first."""
    out: list[dict[str, Any]] = []
    with session_scope() as s:
        rows = s.exec(
            select(SessionDiagnosis)
            .where(SessionDiagnosis.session_id == session_id)
            .order_by(SessionDiagnosis.captured_ts.desc())
        ).all()
        for r in rows[:limit]:
            out.append({
                "id": r.id,
                "captured_ts": r.captured_ts,
                "ip": r.ip,
                "country": r.country,
                "org": r.org,
                "proxy_egress_ip": r.proxy_egress_ip,
                "ip_match": r.ip_match,
            })
    return {"session_id": session_id, "count": len(out), "items": out}


@tool(name="diag.toggle", scope="admin",
      errors=["invalid_args"],
      schema={"type": "object", "required": ["enabled"],
              "additionalProperties": False,
              "properties": {
                  "enabled": {"type": "boolean"},
              }})
async def diag_toggle(enabled: bool) -> dict:
    """Enable/disable global auto-diagnosis at runtime (persisted in DB)."""
    kv_set("diag_enabled", "1" if enabled else "0")
    return {"enabled": bool(enabled), "persisted": True}


def _diff(a: dict, b: dict, path: str = "") -> list[dict]:
    out: list[dict] = []
    if type(a) is not type(b):
        out.append({"path": path, "a": a, "b": b})
        return out
    if isinstance(a, dict):
        for k in set(a.keys()) | set(b.keys()):
            out.extend(_diff(a.get(k), b.get(k), f"{path}.{k}" if path else k))
    elif isinstance(a, list):
        if a != b:
            out.append({"path": path, "a": a, "b": b})
    else:
        if a != b:
            out.append({"path": path, "a": a, "b": b})
    return out


@tool(name="diag.compare", scope="read",
      errors=["diag_not_found", "invalid_args"],
      schema={"type": "object",
              "additionalProperties": False,
              "properties": {
                  "session_id": {"type": "string",
                                 "description": "compare two newest snapshots in this session"},
                  "id_a": {"type": "integer"},
                  "id_b": {"type": "integer"},
              }})
async def diag_compare(session_id: Optional[str] = None,
                       id_a: Optional[int] = None,
                       id_b: Optional[int] = None) -> dict:
    """Diff two diagnosis snapshots. Use either (session_id) for newest-pair, or (id_a, id_b)."""
    with session_scope() as s:
        if id_a is not None and id_b is not None:
            ra = s.get(SessionDiagnosis, id_a)
            rb = s.get(SessionDiagnosis, id_b)
            if ra is None or rb is None:
                raise ToolError("diag_not_found", "one of the ids did not resolve")
        elif session_id:
            rows = s.exec(
                select(SessionDiagnosis)
                .where(SessionDiagnosis.session_id == session_id)
                .order_by(SessionDiagnosis.captured_ts.desc())
            ).all()
            if len(rows) < 2:
                raise ToolError("diag_not_found", "need >=2 snapshots to compare")
            ra, rb = rows[0], rows[1]
        else:
            raise ToolError("invalid_args", "pass session_id OR (id_a, id_b)")
        a = json.loads(ra.blob_json)
        b = json.loads(rb.blob_json)
    diffs = _diff(a, b)
    return {
        "a_id": ra.id, "b_id": rb.id,
        "a_ts": ra.captured_ts, "b_ts": rb.captured_ts,
        "diff_count": len(diffs),
        "diffs": diffs,
    }
