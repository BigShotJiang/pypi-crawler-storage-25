"""obs.* tools."""
from __future__ import annotations
from pathlib import Path
import time
from ..registry import tool
from ..errors import ToolError
from ...config import settings
from ...core.session import SessionRegistry

_S = SessionRegistry.get


@tool(name="obs.console", scope="read",
      schema={"type": "object", "required": ["session_id"], "properties": {
          "session_id": {"type": "string"}, "since_ts": {"type": "number"},
          "level": {"type": "string"}, "limit": {"type": "integer", "default": 200}}})
async def obs_console(session_id: str, since_ts: float | None = None,
                      level: str | None = None, limit: int = 200) -> dict:
    s = _S().lookup(session_id)
    msgs = s.events.get(topics=["console"], since_ts=since_ts, limit=limit * 2)
    if level:
        msgs = [m for m in msgs if m.get("type") == level]
    return {"messages": msgs[:limit]}


@tool(name="obs.network", scope="read",
      schema={"type": "object", "required": ["session_id"], "properties": {
          "session_id": {"type": "string"}, "since_ts": {"type": "number"},
          "limit": {"type": "integer", "default": 200}}})
async def obs_network(session_id: str, since_ts: float | None = None,
                      limit: int = 200) -> dict:
    s = _S().lookup(session_id)
    return {"requests": s.events.get(topics=["network"], since_ts=since_ts, limit=limit)}


@tool(name="obs.events", scope="read",
      schema={"type": "object", "required": ["session_id"], "properties": {
          "session_id": {"type": "string"}, "since_ts": {"type": "number"},
          "topics": {"type": "array"}, "limit": {"type": "integer", "default": 200}}})
async def obs_events(session_id: str, since_ts: float | None = None,
                     topics: list[str] | None = None, limit: int = 200) -> dict:
    s = _S().lookup(session_id)
    return {"events": s.events.get(topics=topics, since_ts=since_ts, limit=limit)}


@tool(name="obs.trace_start", scope="admin",
      schema={"type": "object", "required": ["session_id"], "properties": {
          "session_id": {"type": "string"},
          "screenshots": {"type": "boolean", "default": True},
          "snapshots": {"type": "boolean", "default": True}}})
async def obs_trace_start(session_id: str, screenshots: bool = True,
                          snapshots: bool = True) -> dict:
    s = _S().lookup(session_id)
    try:
        await s.context.tracing.start(screenshots=screenshots, snapshots=snapshots)
    except Exception as e:
        raise ToolError("internal", str(e))
    return {"trace_id": s.id}


@tool(name="obs.trace_stop", scope="admin",
      schema={"type": "object", "required": ["session_id"], "properties": {
          "session_id": {"type": "string"}, "save_path": {"type": "string"}}})
async def obs_trace_stop(session_id: str, save_path: str | None = None) -> dict:
    s = _S().lookup(session_id)
    p = Path(save_path) if save_path else Path(settings.debug_dir) / s.id / "trace.zip"
    p.parent.mkdir(parents=True, exist_ok=True)
    await s.context.tracing.stop(path=str(p))
    return {"path": str(p), "size_bytes": p.stat().st_size if p.exists() else 0}


@tool(name="obs.har_export", scope="admin",
      schema={"type": "object", "required": ["session_id"], "properties": {
          "session_id": {"type": "string"}, "save_path": {"type": "string"}}})
async def obs_har_export(session_id: str, save_path: str | None = None) -> dict:
    raise ToolError("internal",
                    "HAR export requires recordHar at context create; pass har=true on session.create (TODO)")


@tool(name="obs.recorder_dump", scope="read",
      schema={"type": "object", "required": ["session_id"], "properties": {
          "session_id": {"type": "string"},
          "kind": {"type": "string", "default": "events"}}})
async def obs_recorder_dump(session_id: str, kind: str = "events") -> dict:
    s = _S().lookup(session_id)
    if s.recorder is None:
        raise ToolError("internal", "no recorder")
    files = []
    if s.recorder.events_path.exists():
        files.append(str(s.recorder.events_path))
    if kind == "all" and s.recorder.heavy:
        for f in s.recorder.heavy_dir.glob("*"):
            files.append(str(f))
    return {"dir": str(s.recorder.dir), "files": files}
