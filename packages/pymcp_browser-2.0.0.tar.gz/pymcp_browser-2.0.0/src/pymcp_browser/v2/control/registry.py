from __future__ import annotations
import os
import sys
import time
from dataclasses import dataclass, field
from functools import wraps
from typing import Any, Awaitable, Callable, Literal

Scope = Literal["read", "write", "admin"]

_TIMING_ENABLED = os.environ.get("PYMCP_TIMING") == "1"


def _wrap_with_timing(name: str, fn: Callable[..., Awaitable[Any]]) -> Callable[..., Awaitable[Any]]:
    if not _TIMING_ENABLED:
        return fn

    @wraps(fn)
    async def wrapper(*args, **kwargs):
        t0 = time.perf_counter()
        try:
            return await fn(*args, **kwargs)
        finally:
            dur_ms = (time.perf_counter() - t0) * 1000
            sid = kwargs.get("session_id") or "-"
            print(f"[pymcp.timing] {name} | {dur_ms:.1f}ms | {sid}", file=sys.stderr)

    return wrapper


@dataclass
class Tool:
    name: str
    description: str
    scope: Scope
    schema: dict
    handler: Callable[..., Awaitable[Any]]
    error_codes: list[str] = field(default_factory=list)


@dataclass
class Task:
    name: str
    label: str
    session_spec: dict
    auto_session: bool
    handler: Callable[..., Awaitable[Any]]
    last_verified: str | None = None  # ISO date "YYYY-MM-DD"


def task_rot_age_days(last_verified: str | None) -> int | None:
    """Days since last verified date, or None if not set."""
    if not last_verified:
        return None
    from datetime import date as _date
    try:
        d = _date.fromisoformat(last_verified)
        return (_date.today() - d).days
    except Exception:
        return None


TASK_ROT_DAYS = 30


TOOL_REGISTRY: dict[str, Tool] = {}
TASK_REGISTRY: dict[str, Task] = {}
ALIASES: dict[str, str] = {}


def tool(*, name: str, scope: Scope, schema: dict | None = None,
         errors: list[str] | None = None, alias: str | None = None):
    def deco(fn: Callable[..., Awaitable[Any]]):
        wrapped = _wrap_with_timing(name, fn)
        TOOL_REGISTRY[name] = Tool(
            name=name,
            description=(fn.__doc__ or "").strip(),
            scope=scope,
            schema=schema or {"type": "object", "properties": {}},
            handler=wrapped,
            error_codes=errors or [],
        )
        if alias:
            ALIASES[alias] = name
        return fn
    return deco


def task(*, name: str, label: str, session_spec: dict | None = None,
         auto_session: bool = True, last_verified: str | None = None):
    def deco(fn: Callable[..., Awaitable[Any]]):
        # Pull META.last_verified from module if decorator arg omitted.
        lv = last_verified
        if lv is None:
            try:
                module = sys.modules.get(fn.__module__)
                meta = getattr(module, "META", None)
                if isinstance(meta, dict):
                    lv = meta.get("last_verified")
            except Exception:
                lv = None
        TASK_REGISTRY[name] = Task(
            name=name, label=label,
            session_spec=session_spec or {},
            auto_session=auto_session,
            handler=fn,
            last_verified=lv,
        )
        return fn
    return deco


def resolve(name: str) -> Tool | None:
    if name in TOOL_REGISTRY:
        return TOOL_REGISTRY[name]
    real = ALIASES.get(name)
    if real and real in TOOL_REGISTRY:
        return TOOL_REGISTRY[real]
    return None


def load_all() -> None:
    """Import every tool module so @tool decorators register."""
    from . import tools  # noqa: F401
    try:
        from .. import tasks  # noqa: F401
    except Exception:
        pass
