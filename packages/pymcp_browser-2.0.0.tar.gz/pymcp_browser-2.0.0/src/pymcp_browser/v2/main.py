from __future__ import annotations
import typer
import uvicorn

app = typer.Typer(no_args_is_help=True, add_completion=False, help="PyMCP_Browser v2 CLI")


@app.command()
def api(host: str = "127.0.0.1", port: int = 8765, reload: bool = False) -> None:
    """Run REST API server."""
    uvicorn.run("pymcp_browser.v2.control.api:app", host=host, port=port, reload=reload)


@app.command()
def mcp() -> None:
    """Run MCP stdio server."""
    from .control.mcp_server import main as mcp_main
    mcp_main()


@app.command()
def lint() -> None:
    """Schema lint — verify arg-naming conventions across registry."""
    from .control.registry import load_all, TOOL_REGISTRY
    load_all()
    bad = []
    for t in TOOL_REGISTRY.values():
        props = (t.schema or {}).get("properties", {}) or {}
        for arg in props:
            if arg.startswith("is_"):
                bad.append((t.name, arg, "boolean uses 'is_' prefix"))
            if arg.endswith("_seconds") or arg.endswith("_secs"):
                bad.append((t.name, arg, "duration must use *_ms"))
    if bad:
        for tn, a, why in bad:
            typer.echo(f"BAD  {tn}.{a}  -- {why}")
        raise typer.Exit(1)
    typer.echo(f"OK  {len(TOOL_REGISTRY)} tools clean")


if __name__ == "__main__":
    app()
