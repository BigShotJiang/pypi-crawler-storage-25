from __future__ import annotations
from pathlib import Path
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    headless_default: bool = False
    db_path: str = "./data/pymcp.db"
    storage_dir: str = "./data/sessions"
    log_level: str = "INFO"
    pymcp_no_auth: bool = True
    session_idle_ttl_ms: int = 1_800_000
    session_max: int = 12
    record_events_default: bool = True
    record_heavy_default: bool = False
    evaluate_audit_log_dir: str = "./data/audit"
    debug_dir: str = "./data/debug"
    screenshot_dir: str = "./data/screenshots"
    download_dir: str = "./data/downloads"
    macros_dir: str = "./data/macros"
    mail_data_dir: str = "./data/mail"
    mail_max_attachment_mb: int = 25
    mail_default_timeout_s: int = 30
    mail_idle_keepalive_s: int = 540
    max_mail_sessions: int = 8
    mail_recipient_cap_per_call: int = 50
    session_auto_diagnose: bool = True
    diag_timeout_ms: int = 2000
    diag_history_cap: int = 50
    ipinfo_token: str | None = None
    default_engine: str = "chromium"
    camoufox_humanize: bool = True
    camoufox_geoip: bool = True
    patchright_channel: str = "chromium"

    preflight_dir: str = "./data/preflight"
    preflight_min_total: float = 85.0
    preflight_min_fp: float = 80.0
    preflight_min_bot: float = 70.0
    preflight_weights_fp: float = 0.5
    preflight_weights_bot: float = 0.5
    preflight_hard_fails: str = "bot_verdict_error,headless_ua"
    preflight_upload: bool = True
    preflight_save_raw_html: bool = False
    preflight_filen_base: str = "/PreflightReports"
    preflight_cache_ttl_s: int = 300
    preflight_throttle_s: int = 30

    def ensure_dirs(self) -> None:
        for d in (self.storage_dir, self.evaluate_audit_log_dir, self.debug_dir,
                  self.screenshot_dir, self.download_dir, self.mail_data_dir,
                  self.macros_dir, self.preflight_dir,
                  str(Path(self.preflight_dir) / "raw"),
                  Path(self.db_path).parent):
            Path(d).mkdir(parents=True, exist_ok=True)


settings = Settings()
