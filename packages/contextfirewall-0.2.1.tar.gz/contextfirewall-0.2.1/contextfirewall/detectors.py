"""Built-in regex-based detectors for common sensitive data types."""

from __future__ import annotations

import re
from typing import Dict, List, Pattern, Tuple

from contextfirewall.models import Category, Confidence, Finding

# ---------------------------------------------------------------------------
# Pattern registry: name -> (compiled regex, risk, category, confidence)
# ---------------------------------------------------------------------------

_PATTERNS: Dict[str, Tuple[Pattern[str], int, str, str]] = {}


def _register(
    name: str,
    pattern: str,
    risk: int,
    category: str = Category.PII,
    confidence: str = Confidence.HIGH,
    flags: int = 0,
) -> None:
    _PATTERNS[name] = (re.compile(pattern, flags), risk, category, confidence)


# --- Existing Detectors ---

_register(
    "EMAIL",
    r"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b",
    risk=3,
    category=Category.PII,
)

_register(
    "PHONE",
    r"(?:\+?\d{1,3}[-.\s]?)?\(?\d{2,4}\)?[-.\s]?\d{3,4}[-.\s]?\d{4}\b",
    risk=3,
    category=Category.PII,
    confidence=Confidence.MEDIUM,
)

_register(
    "API_KEY",
    r"\b(?:sk|pk|rk|ak)-[A-Za-z0-9_-]{20,}\b",
    risk=8,
    category=Category.SECRET,
)

_register(
    "AWS_ACCESS_KEY",
    r"\bAKIA[0-9A-Z]{16}\b",
    risk=9,
    category=Category.INFRASTRUCTURE,
)

_register(
    "AWS_SECRET_KEY",
    r"(?i)(?:aws_secret_access_key|secret_key)\s*[:=]\s*['\"]?([A-Za-z0-9/+=]{40})['\"]?",
    risk=9,
    category=Category.INFRASTRUCTURE,
)

_register(
    "GENERIC_SECRET",
    r"(?i)(?:password|passwd|secret|token|auth)[\s]*[:=][\s]*['\"]?([^\s'\"]{8,})['\"]?",
    risk=6,
    category=Category.SECRET,
    confidence=Confidence.MEDIUM,
)

_register(
    "JWT",
    r"\beyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\b",
    risk=7,
    category=Category.SECRET,
)

_register(
    "IP_ADDRESS",
    r"\b(?:\d{1,3}\.){3}\d{1,3}\b",
    risk=2,
    category=Category.INFRASTRUCTURE,
)

_register(
    "CREDIT_CARD",
    r"\b(?:4[0-9]{3}|5[1-5][0-9]{2}|3[47][0-9]{1}|6(?:011|5[0-9]{2}))"
    r"[-\s]?[0-9]{4}[-\s]?[0-9]{4}[-\s]?[0-9]{1,4}\b",
    risk=8,
    category=Category.FINANCIAL,
)

_register(
    "SSN",
    r"\b\d{3}-\d{2}-\d{4}\b",
    risk=9,
    category=Category.PII,
)

_register(
    "PRIVATE_KEY",
    r"-----BEGIN (?:RSA |EC |DSA )?PRIVATE KEY-----",
    risk=10,
    category=Category.SECRET,
)

_register(
    "GITHUB_TOKEN",
    r"\b(?:ghp|gho|ghu|ghs|ghr)_[A-Za-z0-9_]{36,}\b",
    risk=8,
    category=Category.SECRET,
)

_register(
    "SLACK_TOKEN",
    r"\bxox[bpsa]-[0-9]{10,}-[A-Za-z0-9-]+\b",
    risk=7,
    category=Category.SECRET,
)

_register(
    "GOOGLE_API_KEY",
    r"\bAIza[0-9A-Za-z_-]{35}\b",
    risk=8,
    category=Category.SECRET,
)

_register(
    "BEARER_TOKEN",
    r"(?i)bearer\s+[A-Za-z0-9_\-\.]{20,}",
    risk=7,
    category=Category.SECRET,
)

# --- New Detectors ---

_register(
    "URL",
    r"https?://(?:[-\w.]|(?:%[\da-fA-F]{2}))+",
    risk=1,
    category=Category.INFRASTRUCTURE,
    confidence=Confidence.HIGH,
)

_register(
    "INTERNAL_URL",
    r"https?://[^/\s]*\.(?:local|internal|lan)(?:\s|/|$)",
    risk=5,
    category=Category.INFRASTRUCTURE,
)

_register(
    "DATABASE_URL",
    r"(?:postgres|mysql|mongodb|redis)(?:ql)?://[^:\s]+:[^@\s]+@[^\s/]+(?:\/[^\s]*)?",
    risk=9,
    category=Category.INFRASTRUCTURE,
)

_register(
    "STRIPE_KEY",
    r"\b(?:sk|pk|rk)_(?:test|live)_[0-9a-zA-Z]{24,}\b",
    risk=9,
    category=Category.FINANCIAL,
)

_register(
    "SENDGRID_KEY",
    r"\bSG\.[0-9a-zA-Z_-]{22}\.[0-9a-zA-Z_-]{43}\b",
    risk=8,
    category=Category.INFRASTRUCTURE,
)

_register(
    "TWILIO_KEY",
    r"\bSK[0-9a-fA-F]{32}\b",
    risk=8,
    category=Category.INFRASTRUCTURE,
)

_register(
    "AZURE_KEY",
    r"(?i)(?:azure|storage)\s*.*?key\s*[:=]\s*['\"]?([A-Za-z0-9+/]{86}==)['\"]?",
    risk=8,
    category=Category.INFRASTRUCTURE,
)

_register(
    "ENCRYPTION_KEY",
    r"(?i)(?:key|encryption_key|secret)\s*[:=]\s*['\"]?([a-fA-F0-9]{32,64})['\"]?",
    risk=9,
    category=Category.SECRET,
    confidence=Confidence.MEDIUM,
)

_register(
    "PRIVATE_IP",
    r"\b(?:10\.\d{1,3}\.\d{1,3}\.\d{1,3}|172\.(?:1[6-9]|2\d|3[0-1])\.\d{1,3}\.\d{1,3}|192\.168\.\d{1,3}\.\d{1,3})\b",
    risk=4,
    category=Category.INFRASTRUCTURE,
)

_register(
    "IBAN",
    r"\b[A-Z]{2}[0-9]{2}(?:[ ]?[0-9a-zA-Z]{4}){4}\b",
    risk=7,
    category=Category.FINANCIAL,
    confidence=Confidence.MEDIUM,
)

_register(
    "PASSPORT",
    r"(?i)\b(?:passport)\s*[:#\-]?\s*([A-PR-WYZ][1-9]\d\s?\d{4}[1-9])\b",
    risk=8,
    category=Category.PII,
    confidence=Confidence.MEDIUM,
)

_register(
    "DATE_OF_BIRTH",
    r"(?i)\b(?:dob|born|birth(?:day|date)?)\s*[:=]?\s*(\d{2,4}[-./]\d{2,4}[-./]\d{2,4})\b",
    risk=4,
    category=Category.PII,
    confidence=Confidence.MEDIUM,
)

_register(
    "MEDICAL_RECORD",
    r"(?i)\b(?:mrn|medical record|patient id)\s*[:#=]?\s*([A-Za-z0-9\-]{5,15})\b",
    risk=8,
    category=Category.MEDICAL,
    confidence=Confidence.MEDIUM,
)


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def get_patterns() -> Dict[str, Tuple[Pattern[str], int, str, str]]:
    """Return a *copy* of the built-in pattern registry."""
    return dict(_PATTERNS)


def detect(text: str) -> List[Finding]:
    """Run all built-in regex detectors on *text* and return findings."""
    findings: List[Finding] = []
    
    # Pre-parse text replacing line endings for context snippets
    text_clean = text.replace("\n", " ")
    
    for name, (pattern, risk, category, confidence) in _PATTERNS.items():
        for m in pattern.finditer(text):
            start = m.start()
            end = m.end()
            
            # Grab context snippet (~30 chars)
            ctx_start = max(0, start - 30)
            ctx_end = min(len(text), end + 30)
            context = text_clean[ctx_start:ctx_end].strip()
            
            findings.append(
                Finding(
                    type=name,
                    match=m.group(0),
                    start=start,
                    end=end,
                    risk=risk,
                    category=category,
                    confidence=confidence,
                    detector="builtin",
                    context=context,
                )
            )
    return findings
