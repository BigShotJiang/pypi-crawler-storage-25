"""Risk scoring engine for contextfirewall."""

from __future__ import annotations

from typing import List

from contextfirewall.models import Finding, ScoringStrategy


def score(
    findings: List[Finding],
    strategy: str = ScoringStrategy.WEIGHTED,
    text_length: int = 0,
) -> int:
    """Compute an aggregate risk score from a list of findings using
    the specified strategy.

    Strategies
    ----------
    MAX: the maximum risk among all findings.
    MEAN: average of all finding risks.
    SUM_CAPPED: sum of all risks, capped at 10.
    WEIGHTED: max risk * 0.6 + density factor + distinct types factor.
    HIGHEST_N: average of the top 3 highest risk findings.
    """
    if not findings:
        return 0

    if strategy == ScoringStrategy.MAX:
        return max(f.risk for f in findings)
    
    elif strategy == ScoringStrategy.MEAN:
        avg = sum(f.risk for f in findings) / len(findings)
        return min(max(round(avg), 1), 10)
    
    elif strategy == ScoringStrategy.SUM_CAPPED:
        return min(sum(f.risk for f in findings), 10)
    
    elif strategy == ScoringStrategy.HIGHEST_N:
        sorted_risks = sorted([f.risk for f in findings], reverse=True)
        top_n = sorted_risks[:3]
        avg = sum(top_n) / len(top_n)
        return min(max(round(avg), 1), 10)
    
    # Default: WEIGHTED
    # Base is the max risk
    max_risk = max(f.risk for f in findings)
    
    # Variety bonus (distinct types)
    distinct_types = len({f.type for f in findings})
    variety_bonus = min(distinct_types - 1, 3) * 0.5  # up to +1.5 for variety
    
    # Density bonus (amount of findings per 1000 chars)
    density_bonus = 0.0
    if text_length > 0:
        findings_per_1k = (len(findings) / text_length) * 1000
        if findings_per_1k > 5:
            density_bonus = 1.0
        elif findings_per_1k > 2:
            density_bonus = 0.5

    weighted_score = max_risk + variety_bonus + density_bonus
    
    return min(max(round(weighted_score), 1), 10)


def calculate_density(findings_count: int, text_length: int) -> float:
    """Calculate findings per 1000 characters."""
    if text_length == 0:
        return 0.0
    return (findings_count / text_length) * 1000.0
