"""Redaction engine for contextfirewall."""

from __future__ import annotations

import hashlib
from typing import Callable, List, Optional

from contextfirewall.models import Finding, RedactStyle

# Type alias for custom redactor callables
RedactorFunc = Callable[[str, List[Finding]], str]


def _mask_string(s: str) -> str:
    """Mask a string, keeping a few characters exposed."""
    if len(s) <= 4:
        return "*" * len(s)
    
    # If it's an email, keep first char and domain
    if "@" in s:
        parts = s.split("@", 1)
        name, domain = parts[0], parts[1]
        masked_name = name[0] + "*" * (len(name) - 1) if name else "*"
        return f"{masked_name}@{domain}"
        
    return s[:2] + "*" * (len(s) - 4) + s[-2:]


def default_redact(
    text: str, 
    findings: List[Finding], 
    style: str = RedactStyle.PLACEHOLDER
) -> str:
    """Replace each finding according to the specified style.

    Findings are processed in reverse order of their position so that
    earlier indices remain valid after replacement.
    """
    # Sort by start position descending so replacements don't shift indices
    sorted_findings = sorted(findings, key=lambda f: f.start, reverse=True)

    # De-duplicate overlapping ranges
    result = text
    replaced: set[tuple[int, int]] = set()

    for f in sorted_findings:
        span = (f.start, f.end)
        # Skip if this span fully overlaps an already-replaced span
        if any(s <= f.start and f.end <= e for s, e in replaced):
            continue
            
        if style == RedactStyle.HASH:
            short_hash = hashlib.sha256(f.match.encode('utf-8')).hexdigest()[:8]
            replacement = f"[HASH_{short_hash}]"
        elif style == RedactStyle.MASK:
            replacement = _mask_string(f.match)
        elif style == RedactStyle.CATEGORY:
            replacement = f"[{f.category}_REDACTED]"
        else:  # RedactStyle.PLACEHOLDER
            replacement = f"[{f.type}_REDACTED]"
            
        result = result[: f.start] + replacement + result[f.end :]
        replaced.add(span)

    return result


def redact(
    text: str,
    findings: List[Finding],
    style: str = RedactStyle.PLACEHOLDER,
    redactor: Optional[RedactorFunc] = None,
) -> str:
    """Redact *text* using the given *findings*.

    If a custom *redactor* is provided it is called instead of the
    default replacement strategy.
    """
    if redactor is not None:
        return redactor(text, findings)
    return default_redact(text, findings, style)
