"""Decorator and context manager for contextfirewall."""

from __future__ import annotations

import functools
from typing import Any, Callable, ContextManager, Generator, TypeVar

from contextfirewall.core import check
from contextfirewall.models import Result

F = TypeVar("F", bound=Callable[..., Any])


class _GuardContext:
    """A context manager that provides access to the firewall."""

    def __init__(self, **kwargs: Any) -> None:
        self.kwargs = kwargs

    def check(self, text: str, **local_kwargs: Any) -> Result:
        """Run the firewall check with local and context parameters combined."""
        merged_kwargs = {**self.kwargs, **local_kwargs}
        return check(text, **merged_kwargs)


class firewall:
    """Decorator for wrapping LLM function calls.
    
    The decorator checks the first positional string argument or the
    `prompt` keyword argument. If BLOCK occurs, raises ValueError.
    If REDACT occurs, replaces the argument with the cleaned version.
    
    Can also be used as a context manager via firewall.guard(**kwargs).
    """

    def __init__(self, **kwargs: Any) -> None:
        self.kwargs = kwargs

    def __call__(self, func: F) -> F:
        @functools.wraps(func)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            
            prompt_idx = -1
            prompt_kwarg = None
            text_to_check = None
            
            # 1. Detect where the prompt is. 
            # First check kwargs for 'prompt' or 'text'
            if "prompt" in kwargs and isinstance(kwargs["prompt"], str):
                prompt_kwarg = "prompt"
                text_to_check = kwargs["prompt"]
            elif "text" in kwargs and isinstance(kwargs["text"], str):
                prompt_kwarg = "text"
                text_to_check = kwargs["text"]
            else:
                # Fall back to first positional string argument
                for i, arg in enumerate(args):
                    if isinstance(arg, str):
                        prompt_idx = i
                        text_to_check = arg
                        break

            if text_to_check is not None:
                res = check(text_to_check, **self.kwargs)
                
                if res.action == "BLOCK":
                    raise ValueError(f"Contextfirewall blocked prompt: {res.reason}")
                
                if res.action == "REDACT" and res.cleaned is not None:
                    if prompt_kwarg:
                        kwargs[prompt_kwarg] = res.cleaned
                    else:
                        args_list = list(args)
                        args_list[prompt_idx] = res.cleaned
                        args = tuple(args_list)

            return func(*args, **kwargs)

        return wrapper  # type: ignore

    @classmethod
    def guard(cls, **kwargs: Any) -> ContextManager[_GuardContext]:
        """Usage: with firewall.guard(mode="strict") as fw: ..."""
        import contextlib
        
        @contextlib.contextmanager
        def _manager() -> Generator[_GuardContext, None, None]:
            yield _GuardContext(**kwargs)
            
        return _manager()
