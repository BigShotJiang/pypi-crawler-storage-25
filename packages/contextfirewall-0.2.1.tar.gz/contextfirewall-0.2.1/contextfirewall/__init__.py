"""
contextfirewall — A lightweight, developer-friendly firewall for LLM prompts.

Prevents sensitive or confidential data from being sent to Large Language Models.
Inspects text before it is sent to APIs and decides whether the content should be
allowed, redacted, or blocked entirely.

Compatible with all LLM providers: OpenAI, Anthropic, Google, Mistral, Cohere,
HuggingFace, and any custom endpoint.
"""

from contextfirewall.core import (
    audit,
    check,
    check_many,
    check_messages,
    explain,
    is_safe,
    redact_text,
    scan,
)
from contextfirewall.decorators import firewall
from contextfirewall.models import Category, Confidence, Finding, Mode, RedactStyle, Result, ScanResult, ScoringStrategy
from contextfirewall.policy import DEFAULT_POLICY
from contextfirewall.registry import (
    add_detector,
    add_rule,
    set_mode,
    set_policy,
    set_redact_style,
    set_redactor,
    set_risk,
    set_scoring_strategy,
)
from contextfirewall.stats import stats

__all__ = [
    # Core check functions
    "check",
    "scan",
    "is_safe",
    "redact_text",
    "audit",
    "check_many",
    "check_messages",
    "explain",
    # Decorators & context managers
    "firewall",
    # Global state management
    "add_rule",
    "add_detector",
    "set_risk",
    "set_policy",
    "set_redactor",
    "set_mode",
    "set_scoring_strategy",
    "set_redact_style",
    "stats",
    # Models and Constants
    "Result",
    "ScanResult",
    "Finding",
    "Category",
    "Confidence",
    "Mode",
    "ScoringStrategy",
    "RedactStyle",
    "DEFAULT_POLICY",
]

__version__ = "0.2.1"
