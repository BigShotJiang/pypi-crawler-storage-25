"""Thread-safe statistics tracking for contextfirewall."""

import threading
from typing import Any, Dict

from contextfirewall.models import Result

class StatsTracker:
    """Thread-safe statistics for firewall usage."""

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._total_checks = 0
        self._total_blocked = 0
        self._total_redacted = 0
        self._findings_by_type: Dict[str, int] = {}
        
    @property
    def total_checks(self) -> int:
        with self._lock:
            return self._total_checks
            
    @property
    def total_blocked(self) -> int:
        with self._lock:
            return self._total_blocked
            
    @property
    def total_redacted(self) -> int:
        with self._lock:
            return self._total_redacted
            
    @property
    def findings_by_type(self) -> Dict[str, int]:
        with self._lock:
            return dict(self._findings_by_type)

    def record(self, result: Result) -> None:
        """Record a check result into the statistics."""
        with self._lock:
            self._total_checks += 1
            if result.action == "BLOCK":
                self._total_blocked += 1
            elif result.action == "REDACT":
                self._total_redacted += 1
                
            for ft in result.found:
                self._findings_by_type[ft] = self._findings_by_type.get(ft, 0) + 1

    def reset(self) -> None:
        """Reset all statistics to zero."""
        with self._lock:
            self._total_checks = 0
            self._total_blocked = 0
            self._total_redacted = 0
            self._findings_by_type.clear()

    def to_dict(self) -> Dict[str, Any]:
        """Return all stats as a dictionary."""
        with self._lock:
            return {
                "total_checks": self._total_checks,
                "total_blocked": self._total_blocked,
                "total_redacted": self._total_redacted,
                "findings_by_type": dict(self._findings_by_type),
            }


# Global singleton
stats = StatsTracker()
