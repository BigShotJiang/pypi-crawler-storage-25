"""Entropy-based secret detection for contextfirewall.

Zero-dependency Shannon entropy calculation to detect generic,
unknown secrets based on character randomness and context.
"""

import math
import re
from typing import List

from contextfirewall.models import Category, Confidence, Finding

# Common keywords that often precede secrets
CONTEXT_KEYWORDS = {
    "key",
    "secret",
    "token",
    "password",
    "passwd",
    "auth",
    "credential",
    "bearer",
    "api",
    "aws",
    "jwt",
    "pass",
}

# Matches long strings of alphanumeric + common token symbols
# Minimum 20 characters length
_TOKEN_PATTERN = re.compile(r"\b[a-zA-Z0-9_\-\.\+~=]{20,}\b")


def shannon_entropy(data: str) -> float:
    """Calculate the Shannon entropy of a string."""
    if not data:
        return 0.0
    entropy = 0.0
    for x in set(data):
        p_x = float(data.count(x)) / len(data)
        if p_x > 0:
            entropy += -p_x * math.log2(p_x)
    return entropy


def detect_high_entropy(text: str, paranoid: bool = False) -> List[Finding]:
    """Detect high entropy strings in text.

    Parameters
    ----------
    text:
        The input text to scan.
    paranoid:
        If True, reports all high-entropy strings over the threshold.
        If False, requires the string to be near a context keyword.
    """
    findings: List[Finding] = []
    text_lower = text.lower()

    for match in _TOKEN_PATTERN.finditer(text):
        token = match.group(0)
        ent = shannon_entropy(token)

        # > 4.5 is a common threshold for determining if a base62/base64
        # string is effectively random enough to be a secret
        if ent > 4.5:
            start, end = match.start(), match.end()
            is_sensitive = paranoid

            if not is_sensitive:
                # Look back ~60 characters for keywords
                ctx_start = max(0, start - 60)
                ctx_text = text_lower[ctx_start:start]

                # Ensure we match whole words for keywords to reduce false positives
                # e.g., don't match "passion" as "pass"
                if any(re.search(rf"\b{kw}\b", ctx_text) for kw in CONTEXT_KEYWORDS):
                    is_sensitive = True

            if is_sensitive:
                # Capture ~30 characters on either side for explainability
                ctx_start_snippet = max(0, start - 30)
                ctx_end_snippet = min(len(text), end + 30)
                context_snippet = text[ctx_start_snippet:ctx_end_snippet].replace(
                    "\n", " "
                )

                findings.append(
                    Finding(
                        type="HIGH_ENTROPY",
                        match=token,
                        start=start,
                        end=end,
                        risk=6,
                        detector="entropy",
                        category=Category.SECRET,
                        confidence=Confidence.LOW,  # Harder to verify than patterned secrets
                        context=context_snippet.strip(),
                    )
                )

    return findings
