"""Core pipeline for contextfirewall.

Pipeline: Input → Detection → Classification → Scoring → Policy → Decision → Optional Redaction
"""

from __future__ import annotations

import time
from typing import Any, Dict, List, Optional

from contextfirewall.detectors import detect as builtin_detect
from contextfirewall.entropy import detect_high_entropy
from contextfirewall.models import Finding, Mode, RedactStyle, Result, ScanResult, ScoringStrategy
from contextfirewall.policy import evaluate as policy_evaluate
from contextfirewall.redact import redact
from contextfirewall.registry import (
    apply_risk_overrides,
    get_custom_policy,
    get_custom_redactor,
    get_global_mode,
    get_global_redact_style,
    get_global_scoring_strategy,
    run_custom_detectors,
)
from contextfirewall.scoring import calculate_density
from contextfirewall.scoring import score as compute_score
from contextfirewall.stats import stats

# Type alias for chat messages
Message = Dict[str, str]

def scan(
    text: str,
    *,
    scoring_strategy: Optional[str] = None,
    paranoid: bool = False,
) -> ScanResult:
    """Run detection and scoring only, without policy evaluation.

    Returns
    -------
    ScanResult
        Contains findings, total score, and category counts.
    """
    start_time = time.perf_counter()

    if not text or not text.strip():
        return ScanResult(duration_ms=(time.perf_counter() - start_time) * 1000)

    # 1. Detection
    findings: List[Finding] = builtin_detect(text)
    findings.extend(run_custom_detectors(text))
    
    # Optional entropy detection
    if paranoid:
        findings.extend(detect_high_entropy(text, paranoid=True))
    else:
        findings.extend(detect_high_entropy(text, paranoid=False))

    # 2. Apply risk overrides
    findings = apply_risk_overrides(findings)

    if not findings:
        return ScanResult(duration_ms=(time.perf_counter() - start_time) * 1000)

    # 3. Aggregate types and categories
    seen_types: set[str] = set()
    found: List[str] = []
    categories_count: Dict[str, int] = {}
    
    for f in findings:
        categories_count[f.category] = categories_count.get(f.category, 0) + 1
        if f.type not in seen_types:
            found.append(f.type)
            seen_types.add(f.type)

    # 4. Scoring
    eff_strategy = (
        scoring_strategy 
        or get_global_scoring_strategy() 
        or ScoringStrategy.WEIGHTED
    )
    
    risk_score = compute_score(findings, strategy=eff_strategy, text_length=len(text))
    density = calculate_density(len(findings), len(text))
    
    return ScanResult(
        findings=findings,
        found=found,
        score=risk_score,
        categories=categories_count,
        density=density,
        duration_ms=(time.perf_counter() - start_time) * 1000,
        scoring_strategy=eff_strategy,
    )


def check(
    text: str,
    *,
    mode: Optional[str] = None,
    preset: Optional[Dict[str, Any]] = None,
    scoring_strategy: Optional[str] = None,
    redact_style: Optional[str] = None,
    policy: Optional[Dict[str, Any]] = None,
    allow_types: Optional[List[str]] = None,
    block_types: Optional[List[str]] = None,
    strict: bool = False,
) -> Result:
    """Inspect *text* and return a :class:`Result` with a decision.

    Parameters
    ----------
    text:
        The input prompt to inspect.
    mode:
        Classification mode (STANDARD, STRICT, AUDIT, REDACT_ALL, PARANOID, PERMISSIVE).
    preset:
        A compliance preset dict (e.g., HIPAA, PCI_DSS, SOC2).
    """
    start_time = time.perf_counter()
    
    # Resolve Effective Configs
    eff_preset = preset or {}
    
    eff_mode = (
        mode 
        or eff_preset.get("mode") 
        or get_global_mode() 
        or (Mode.STRICT if strict else Mode.STANDARD)
    )
    
    eff_strategy = (
        scoring_strategy 
        or eff_preset.get("scoring_strategy") 
        or get_global_scoring_strategy() 
        or ScoringStrategy.WEIGHTED
    )
    
    eff_redact_style = redact_style or get_global_redact_style() or RedactStyle.PLACEHOLDER
    
    # 1. Run Scan
    # If PARANOID mode, force paranoid entropy detection
    scan_res = scan(text, scoring_strategy=eff_strategy, paranoid=(eff_mode == Mode.PARANOID))

    if not scan_res.findings:
        res = Result(
            action="ALLOW" if eff_mode != Mode.AUDIT else "AUDIT", 
            score=0, 
            reason="No sensitive data detected",
            mode=eff_mode,
            duration_ms=(time.perf_counter() - start_time) * 1000,
            summary="Clean",
            scoring_strategy=eff_strategy,
        )
        stats.record(res)
        return res

    # 2. Determine effective policy & blocks
    global_policy = get_custom_policy()
    
    eff_policy = {**global_policy} if global_policy else {}
    if "policy" in eff_preset:
        eff_policy.update(eff_preset["policy"])
    if policy:
        eff_policy.update(policy)

    eff_block_types = []
    if "block_types" in eff_preset:
        eff_block_types.extend(eff_preset["block_types"])
    if block_types:
        eff_block_types.extend(block_types)

    # 3. Policy evaluation → decision
    action = policy_evaluate(
        scan_res.score,
        scan_res.findings,
        policy=eff_policy,
        allow_types=allow_types,
        block_types=eff_block_types,
        mode=eff_mode,
    )

    # 4. Redaction (if action is REDACT)
    cleaned: Optional[str] = None
    if action == "REDACT":
        redactor = get_custom_redactor()
        cleaned = redact(text, scan_res.findings, style=eff_redact_style, redactor=redactor)

    # 5. Build reason & summary
    reason = _build_reason(action, scan_res.found, scan_res.score, eff_mode)
    summary = f"[{action}] Score {scan_res.score} - {len(scan_res.findings)} issues"

    # Assemble result
    res = Result(
        action=action,
        score=scan_res.score,
        found=scan_res.found,
        findings=scan_res.findings,
        cleaned=cleaned,
        reason=reason,
        summary=summary,
        mode=eff_mode,
        categories=scan_res.categories,
        density=scan_res.density,
        duration_ms=(time.perf_counter() - start_time) * 1000,
        scoring_strategy=eff_strategy,
    )
    
    stats.record(res)
    return res


def is_safe(text: str, **kwargs: Any) -> bool:
    """Return True if check() would ALLOW this text."""
    return check(text, **kwargs).action == "ALLOW"


def redact_text(text: str, **kwargs: Any) -> str:
    """Force redaction of all sensitive data, returning the cleaned string."""
    res = check(text, mode=Mode.REDACT_ALL, **kwargs)
    return res.cleaned if res.cleaned is not None else text


def audit(text: str, **kwargs: Any) -> Result:
    """Run check in AUDIT mode (never blocks, just reports)."""
    return check(text, mode=Mode.AUDIT, **kwargs)


def check_messages(messages: List[Message], **kwargs: Any) -> Result:
    """Check a list of chat messages (OpenAI or Anthropic format).
    
    Extracts text content from each message, concatenates them safely,
    and runs a single check.
    """
    text_parts = []
    for m in messages:
        if "content" in m:
            content = m["content"]
            # Check for Anthropic list of blocks
            if isinstance(content, list):
                for block in content:
                    if isinstance(block, dict) and block.get("type") == "text":
                        text_parts.append(block.get("text", ""))
            elif isinstance(content, str):
                text_parts.append(content)

    combined_text = "\n\n".join(text_parts)
    return check(combined_text, **kwargs)


def check_many(texts: List[str], **kwargs: Any) -> List[Result]:
    """Check multiple strings individually and return a list of Results."""
    return [check(t, **kwargs) for t in texts]


def explain(text: str, **kwargs: Any) -> str:
    """Return a detailed, human-readable report string."""
    res = check(text, **kwargs)
    
    lines = [
        "ContextFirewall Report",
        "----------------------",
        f"Action:     {res.action}",
        f"Mode:       {res.mode}",
        f"Score:      {res.score} (via {res.scoring_strategy})",
        f"Density:    {res.density:.2f} items/1k chars",
        f"Duration:   {res.duration_ms:.2f} ms",
        "",
        f"Reason:     {res.reason}",
    ]
    
    if res.categories:
        lines.append("")
        lines.append("Categories:")
        for cat, cnt in res.categories.items():
            lines.append(f"  - {cat}: {cnt}")
            
    if res.findings:
        lines.append("")
        lines.append(f"Findings ({len(res.findings)}):")
        for i, f in enumerate(res.findings, 1):
            lines.append(f"  {i}. [{f.confidence}] {f.type} (risk: {f.risk})")
            if f.context:
                lines.append(f"     Context: \"...{f.context}...\"")
                
    return "\n".join(lines)


def _build_reason(action: str, found: List[str], score: int, mode: str) -> str:
    types_str = ", ".join(found)
    if action == "ALLOW":
        if not found:
            return "No sensitive data detected"
        return f"Low-risk data detected ({types_str}), score {score} allowed by policy"
    if action == "REDACT":
        return f"Sensitive data detected ({types_str}) — redacted for safe use"
    if action == "AUDIT":
        return f"Audit mode: found {types_str} (score {score})"
        
    return f"High-risk data detected ({types_str}), score {score} — blocked by {mode} policy"
