"""Compliance presets for contextfirewall.

Pre-configured policies and settings for common security standards.
"""

from contextfirewall.models import Mode, ScoringStrategy

# ---------------------------------------------------------------------------
# HIPAA (Health Insurance Portability and Accountability Act)
# ---------------------------------------------------------------------------
HIPAA = {
    "mode": Mode.STANDARD,
    "scoring_strategy": ScoringStrategy.WEIGHTED,
    "block_types": ["MEDICAL_RECORD", "SSN", "DATE_OF_BIRTH"],
    "policy": {
        "allow_threshold": 0,
        "redact_threshold": 10,
    },
}

# ---------------------------------------------------------------------------
# PCI DSS (Payment Card Industry Data Security Standard)
# ---------------------------------------------------------------------------
PCI_DSS = {
    "mode": Mode.STANDARD,
    "scoring_strategy": ScoringStrategy.MAX,
    "block_types": ["CREDIT_CARD", "STRIPE_KEY", "IBAN"],
    "policy": {
        "allow_threshold": 1,
        "redact_threshold": 4,
    },
}

# ---------------------------------------------------------------------------
# GDPR (General Data Protection Regulation)
# ---------------------------------------------------------------------------
GDPR = {
    "mode": Mode.STANDARD,
    "scoring_strategy": ScoringStrategy.WEIGHTED,
    "block_types": [],  # GDPR requires protection, not always outright blocking
    "policy": {
        "allow_threshold": 1,
        "redact_threshold": 7,  # Redact PII aggressively
    },
}

# ---------------------------------------------------------------------------
# SOC2 (System and Organization Controls 2)
# ---------------------------------------------------------------------------
SOC2 = {
    "mode": Mode.STANDARD,
    "scoring_strategy": ScoringStrategy.WEIGHTED,
    "block_types": [
        "API_KEY", 
        "AWS_ACCESS_KEY", 
        "AWS_SECRET_KEY", 
        "JWT", 
        "PRIVATE_KEY", 
        "GITHUB_TOKEN", 
        "DATABASE_URL", 
        "PRIVATE_IP"
    ],
    "policy": {
        "allow_threshold": 2,
        "redact_threshold": 5,
    },
}
