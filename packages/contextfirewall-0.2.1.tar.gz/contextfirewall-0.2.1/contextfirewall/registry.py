"""Global registry for custom rules, detectors, risk overrides, policies, and redactors."""

from __future__ import annotations

import re
from typing import Any, Callable, Dict, List, Optional, Tuple

from contextfirewall.models import Finding
from contextfirewall.redact import RedactorFunc

# ---------------------------------------------------------------------------
# Custom regex rules: name → (compiled pattern, risk)
# ---------------------------------------------------------------------------
_custom_rules: Dict[str, Tuple[re.Pattern[str], int]] = {}

# ---------------------------------------------------------------------------
# Custom function detectors: name → (callable, risk)
# ---------------------------------------------------------------------------
_custom_detectors: Dict[str, Tuple[Callable[[str], List[str]], int]] = {}

# ---------------------------------------------------------------------------
# Risk overrides: finding type → new risk score
# ---------------------------------------------------------------------------
_risk_overrides: Dict[str, int] = {}

# ---------------------------------------------------------------------------
# Global configurations
# ---------------------------------------------------------------------------
_custom_policy: Optional[Dict[str, Any]] = None
_custom_redactor: Optional[RedactorFunc] = None

_global_mode: Optional[str] = None
_global_scoring_strategy: Optional[str] = None
_global_redact_style: Optional[str] = None


# ===== Public API ==========================================================


def add_rule(name: str, pattern: str, risk: int = 5) -> None:
    """Register a custom regex rule."""
    _custom_rules[name] = (re.compile(pattern), max(1, min(risk, 10)))


def add_detector(
    name: str,
    func: Callable[[str], List[str]],
    risk: int = 5,
) -> None:
    """Register a custom callable detector."""
    _custom_detectors[name] = (func, max(1, min(risk, 10)))


def set_risk(finding_type: str, risk: int) -> None:
    """Override the risk score for a built-in or custom finding type."""
    _risk_overrides[finding_type] = max(1, min(risk, 10))


def set_policy(policy: Dict[str, Any]) -> None:
    """Set a global custom policy (overrides :data:`DEFAULT_POLICY`)."""
    global _custom_policy
    _custom_policy = policy


def set_redactor(redactor: RedactorFunc) -> None:
    """Set a global custom redactor function."""
    global _custom_redactor
    _custom_redactor = redactor


def set_mode(mode: str) -> None:
    """Set the global classification mode."""
    global _global_mode
    _global_mode = mode


def set_scoring_strategy(strategy: str) -> None:
    """Set the global scoring strategy."""
    global _global_scoring_strategy
    _global_scoring_strategy = strategy


def set_redact_style(style: str) -> None:
    """Set the global redaction style."""
    global _global_redact_style
    _global_redact_style = style


# ===== Internal helpers (used by core.py) ==================================


def run_custom_detectors(text: str) -> List[Finding]:
    """Execute all registered custom rules and detectors."""
    findings: List[Finding] = []

    # Regex rules
    for name, (pattern, risk) in _custom_rules.items():
        for m in pattern.finditer(text):
            findings.append(
                Finding(
                    type=name,
                    match=m.group(0),
                    start=m.start(),
                    end=m.end(),
                    risk=risk,
                    detector="custom_rule",
                )
            )

    # Function detectors
    for name, (func, risk) in _custom_detectors.items():
        matches = func(text)
        for match_str in matches:
            idx = text.find(match_str)
            findings.append(
                Finding(
                    type=name,
                    match=match_str,
                    start=idx if idx >= 0 else 0,
                    end=(idx + len(match_str)) if idx >= 0 else 0,
                    risk=risk,
                    detector="custom_func",
                )
            )

    return findings


def apply_risk_overrides(findings: List[Finding]) -> List[Finding]:
    """Return a new list of findings with risk scores overridden where applicable."""
    result: List[Finding] = []
    for f in findings:
        if f.type in _risk_overrides:
            f = Finding(
                type=f.type,
                match=f.match,
                start=f.start,
                end=f.end,
                risk=_risk_overrides[f.type],
                detector=f.detector,
            )
        result.append(f)
    return result


def get_custom_policy() -> Optional[Dict[str, Any]]:
    return _custom_policy

def get_custom_redactor() -> Optional[RedactorFunc]:
    return _custom_redactor

def get_global_mode() -> Optional[str]:
    return _global_mode

def get_global_scoring_strategy() -> Optional[str]:
    return _global_scoring_strategy

def get_global_redact_style() -> Optional[str]:
    return _global_redact_style


def reset() -> None:
    """Clear all custom registrations (useful for testing)."""
    global _custom_policy, _custom_redactor, _global_mode, _global_scoring_strategy, _global_redact_style
    _custom_rules.clear()
    _custom_detectors.clear()
    _risk_overrides.clear()
    _custom_policy = None
    _custom_redactor = None
    _global_mode = None
    _global_scoring_strategy = None
    _global_redact_style = None
