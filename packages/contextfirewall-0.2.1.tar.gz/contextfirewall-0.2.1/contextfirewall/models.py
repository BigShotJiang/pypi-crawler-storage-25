"""Data models and constants for contextfirewall."""

from __future__ import annotations

import json
from dataclasses import asdict, dataclass, field
from typing import Any, Dict, List, Optional


class Category:
    PII = "PII"
    SECRET = "SECRET"
    FINANCIAL = "FINANCIAL"
    INFRASTRUCTURE = "INFRASTRUCTURE"
    MEDICAL = "MEDICAL"
    CUSTOM = "CUSTOM"


class Confidence:
    HIGH = "HIGH"
    MEDIUM = "MEDIUM"
    LOW = "LOW"


class Mode:
    STANDARD = "STANDARD"
    STRICT = "STRICT"
    PERMISSIVE = "PERMISSIVE"
    AUDIT = "AUDIT"
    REDACT_ALL = "REDACT_ALL"
    PARANOID = "PARANOID"


class ScoringStrategy:
    MAX = "MAX"
    MEAN = "MEAN"
    SUM_CAPPED = "SUM_CAPPED"
    WEIGHTED = "WEIGHTED"
    HIGHEST_N = "HIGHEST_N"


class RedactStyle:
    PLACEHOLDER = "PLACEHOLDER"
    HASH = "HASH"
    MASK = "MASK"
    CATEGORY = "CATEGORY"


@dataclass(frozen=True)
class Finding:
    """A single detected piece of sensitive data."""

    type: str
    """Category of the finding, e.g. ``EMAIL``, ``API_KEY``."""

    match: str
    """The matched text fragment."""

    start: int
    """Start index in the original text."""

    end: int
    """End index in the original text."""

    risk: int
    """Risk score for this individual finding (1–10)."""

    detector: str = ""
    """Name of the detector that produced this finding."""

    category: str = Category.CUSTOM
    """Broad classification category (e.g. ``PII``, ``SECRET``)."""

    confidence: str = Confidence.HIGH
    """Confidence level of this finding (``HIGH``, ``MEDIUM``, ``LOW``)."""

    context: str = ""
    """Surrounding text snippet for explainability."""

    def to_dict(self) -> Dict[str, Any]:
        """Convert finding to dictionary."""
        return asdict(self)


@dataclass
class ScanResult:
    """Outcome of a pure detection scan without policy evaluation."""

    findings: List[Finding] = field(default_factory=list)
    """Full list of individual findings."""

    found: List[str] = field(default_factory=list)
    """Unique finding-type labels detected."""

    score: int = 0
    """Aggregate risk score (0–10)."""

    categories: Dict[str, int] = field(default_factory=dict)
    """Counts of findings by category."""

    density: float = 0.0
    """Findings per 1000 characters."""

    duration_ms: float = 0.0
    """Execution time of the scan in milliseconds."""

    scoring_strategy: str = ScoringStrategy.WEIGHTED
    """The strategy used to compute the aggregate score."""

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary representation."""
        return asdict(self)

    def to_json(self) -> str:
        """Convert to JSON string."""
        return json.dumps(self.to_dict())


@dataclass
class Result(ScanResult):
    """Outcome of a full ``check()`` call including policy evaluation."""

    action: str = "ALLOW"
    """One of ``"ALLOW"``, ``"REDACT"``, ``"BLOCK"``, or ``"AUDIT"``."""

    mode: str = Mode.STANDARD
    """The classification mode used."""

    cleaned: Optional[str] = None
    """Redacted version of the input (``None`` when not redacted)."""

    reason: str = ""
    """Human-readable explanation of the decision."""

    summary: str = ""
    """Short one-line summary."""
    
