"""Policy engine for contextfirewall."""

from __future__ import annotations

from typing import Any, Dict, List, Optional

from contextfirewall.models import Finding, Mode

DEFAULT_POLICY: Dict[str, int] = {
    "allow_threshold": 2,
    "redact_threshold": 5,
}


def evaluate(
    score: int,
    findings: List[Finding],
    policy: Optional[Dict[str, Any]] = None,
    *,
    allow_types: Optional[List[str]] = None,
    block_types: Optional[List[str]] = None,
    mode: str = Mode.STANDARD,
) -> str:
    """Determine the action (ALLOW, REDACT, BLOCK, AUDIT) based on mode and score."""

    # --- Mode overrides ------------------------------------------------
    if mode == Mode.AUDIT:
        return "AUDIT"
        
    if mode == Mode.REDACT_ALL and findings:
        return "REDACT"

    if mode in (Mode.STRICT, Mode.PARANOID) and findings:
        return "BLOCK"

    # --- block_types override -----------------------------------------
    if block_types:
        found_types = {f.type for f in findings}
        if found_types & set(block_types):
            return "BLOCK"

    # --- filter allowed types -----------------------------------------
    effective_findings = findings
    if allow_types:
        effective_findings = [f for f in findings if f.type not in allow_types]

    if not effective_findings:
        return "ALLOW"

    # Recompute effective score from remaining findings for the checks below
    effective_score = max(f.risk for f in effective_findings)

    # --- Mode.PERMISSIVE ----------------------------------------------
    if mode == Mode.PERMISSIVE:
        if effective_score >= 8:
            return "BLOCK"
        return "ALLOW"

    # --- standard threshold-based policy ------------------------------
    pol = {**DEFAULT_POLICY, **(policy or {})}
    allow_thresh: int = pol.get("allow_threshold", 2)
    redact_thresh: int = pol.get("redact_threshold", 5)

    if effective_score <= allow_thresh:
        return "ALLOW"
    if effective_score <= redact_thresh:
        return "REDACT"
    return "BLOCK"
