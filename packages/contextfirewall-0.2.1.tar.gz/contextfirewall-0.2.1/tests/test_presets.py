"""Tests for compliance presets."""

from contextfirewall import check
from contextfirewall.presets import HIPAA, PCI_DSS, GDPR, SOC2

class TestPresets:
    def test_hipaa_blocks_medical(self):
        result = check("Patient MRN: 123456", preset=HIPAA)
        assert result.action == "BLOCK"
        
    def test_pci_dss_blocks_cc(self):
        result = check("Card: 4111 1111 1111 1111", preset=PCI_DSS)
        assert result.action == "BLOCK"
        
    def test_gdpr_redacts_by_default(self):
        result = check("Email alice@example.com", preset=GDPR)
        assert result.action == "REDACT"
        
    def test_soc2_blocks_keys(self):
        result = check("Token ghO_1234567890abcdefghijklmnopqrstuvwxyz", preset=SOC2)
        assert result.action == "BLOCK"
