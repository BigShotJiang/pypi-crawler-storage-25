"""Tests for the core check() pipeline."""

import pytest

from contextfirewall import check, add_rule, add_detector, set_risk, set_policy, set_redactor
from contextfirewall.registry import reset


@pytest.fixture(autouse=True)
def _clean_registry():
    """Reset global state between tests."""
    reset()
    yield
    reset()


class TestCheckBasic:
    def test_safe_text(self):
        result = check("Hello, how are you today?")
        assert result.action == "ALLOW"
        assert result.score == 0
        assert result.found == []
        assert result.cleaned is None

    def test_empty_text(self):
        result = check("")
        assert result.action == "ALLOW"

    def test_whitespace_text(self):
        result = check("   ")
        assert result.action == "ALLOW"

    def test_email_detected(self):
        result = check("My email is alice@example.com")
        assert "EMAIL" in result.found
        assert result.score > 0

    def test_api_key_blocked(self):
        result = check("key: sk-1234567890abcdefghijklmnop")
        assert result.action in ("REDACT", "BLOCK")
        assert "API_KEY" in result.found

    def test_redacted_output(self):
        result = check("Email me at alice@example.com")
        if result.action == "REDACT":
            assert result.cleaned is not None
            assert "alice@example.com" not in result.cleaned
            assert "[EMAIL_REDACTED]" in result.cleaned

    def test_result_has_reason(self):
        result = check("secret: sk-1234567890abcdefghijklmnop")
        assert result.reason != ""


class TestStrictMode:
    def test_strict_blocks_any_finding(self):
        result = check("Contact alice@example.com", strict=True)
        assert result.action == "BLOCK"

    def test_strict_allows_clean_text(self):
        result = check("Nothing sensitive here", strict=True)
        assert result.action == "ALLOW"


class TestAllowBlockTypes:
    def test_allow_email(self):
        result = check("alice@example.com", allow_types=["EMAIL"])
        assert result.action == "ALLOW"

    def test_block_email(self):
        result = check("alice@example.com", block_types=["EMAIL"])
        assert result.action == "BLOCK"


class TestPerCallPolicy:
    def test_custom_thresholds(self):
        # Low thresholds → more blocking
        result = check(
            "alice@example.com",
            policy={"allow_threshold": 0, "redact_threshold": 1},
        )
        # EMAIL has risk 3, so with redact_threshold=1 it should BLOCK
        assert result.action == "BLOCK"

    def test_high_thresholds(self):
        result = check(
            "alice@example.com",
            policy={"allow_threshold": 10, "redact_threshold": 10},
        )
        assert result.action == "ALLOW"


class TestCustomRule:
    def test_add_rule(self):
        add_rule(name="EMPLOYEE_ID", pattern=r"EMP-\d+", risk=3)
        result = check("Employee EMP-12345 logged in")
        assert "EMPLOYEE_ID" in result.found

    def test_custom_rule_risk(self):
        add_rule(name="INTERNAL_CODE", pattern=r"INTERNAL-\d+", risk=8)
        result = check("Code: INTERNAL-999")
        assert result.score >= 8


class TestCustomDetector:
    def test_function_detector(self):
        def detect_internal(text):
            if "internal.company.com" in text:
                return ["internal.company.com"]
            return []

        add_detector(name="INTERNAL_URL", func=detect_internal, risk=4)
        result = check("Visit internal.company.com/docs")
        assert "INTERNAL_URL" in result.found


class TestSetRisk:
    def test_override_email_risk(self):
        set_risk("EMAIL", 1)
        result = check("alice@example.com", scoring_strategy="MAX")
        assert result.score <= 1
        assert result.action == "ALLOW"

    def test_override_email_to_high(self):
        set_risk("EMAIL", 10)
        result = check("alice@example.com")
        assert result.action == "BLOCK"


class TestGlobalPolicy:
    def test_set_global_policy(self):
        set_policy({"allow_threshold": 10, "redact_threshold": 10})
        result = check("sk-1234567890abcdefghijklmnop")
        assert result.action == "ALLOW"


class TestCustomRedactor:
    def test_custom_redactor_function(self):
        def my_redactor(text, findings):
            for f in findings:
                text = text.replace(f.match, "[HIDDEN]")
            return text

        set_redactor(my_redactor)
        # Set email risk high enough to trigger REDACT
        set_risk("EMAIL", 4)
        result = check("Email: alice@example.com")
        if result.action == "REDACT":
            assert "[HIDDEN]" in result.cleaned


class TestMultipleSensitiveData:
    def test_email_and_key(self):
        text = "User email is john@gmail.com and API key is sk-123abc456def789ghijklmnop"
        result = check(text)
        assert "EMAIL" in result.found
        assert "API_KEY" in result.found
        assert result.score >= 8
