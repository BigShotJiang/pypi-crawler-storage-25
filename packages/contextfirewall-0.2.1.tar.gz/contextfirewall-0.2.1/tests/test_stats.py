"""Tests for stats tracking."""

from contextfirewall.stats import stats
from contextfirewall import check

def test_stats_tracking():
    stats.reset()
    assert stats.total_checks == 0
    
    check("safe text")
    assert stats.total_checks == 1
    assert stats.total_blocked == 0
    
    check("key: sk-1234567890abcdefghijklmnop", mode="STRICT")
    assert stats.total_checks == 2
    assert stats.total_blocked == 1
    assert "API_KEY" in stats.findings_by_type
    
    sd = stats.to_dict()
    assert sd["total_checks"] == 2
    assert sd["total_blocked"] == 1
    
    stats.reset()
    assert stats.total_checks == 0
