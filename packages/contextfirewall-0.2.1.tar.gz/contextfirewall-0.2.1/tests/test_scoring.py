"""Tests for the scoring engine."""

from contextfirewall.scoring import score
from contextfirewall.models import Finding


def _finding(type_: str, risk: int) -> Finding:
    return Finding(type=type_, match="x", start=0, end=1, risk=risk)


class TestScoring:
    def test_empty(self):
        assert score([]) == 0

    def test_single_low(self):
        assert score([_finding("EMAIL", 2)]) == 2

    def test_single_high(self):
        assert score([_finding("API_KEY", 8)]) == 8

    def test_max_is_used(self):
        findings = [_finding("EMAIL", 2), _finding("API_KEY", 8)]
        assert score(findings) >= 8

    def test_multiple_high_types_bonus(self):
        findings = [_finding("API_KEY", 8), _finding("JWT", 7)]
        s = score(findings)
        assert s >= 8
        assert s <= 10

    def test_cap_at_10(self):
        findings = [
            _finding("API_KEY", 9),
            _finding("JWT", 9),
            _finding("PRIVATE_KEY", 10),
        ]
        assert score(findings) == 10
