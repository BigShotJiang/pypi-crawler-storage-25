"""Tests for the policy engine."""

from contextfirewall.policy import evaluate
from contextfirewall.models import Finding, Mode


def _finding(type_: str, risk: int) -> Finding:
    return Finding(type=type_, match="x", start=0, end=1, risk=risk)


class TestDefaultPolicy:
    def test_allow_low_score(self):
        assert evaluate(1, [_finding("IP", 1)]) == "ALLOW"

    def test_allow_at_threshold(self):
        assert evaluate(2, [_finding("IP", 2)]) == "ALLOW"

    def test_redact_mid_score(self):
        assert evaluate(4, [_finding("EMAIL", 4)]) == "REDACT"

    def test_redact_at_threshold(self):
        assert evaluate(5, [_finding("EMAIL", 5)]) == "REDACT"

    def test_block_high_score(self):
        assert evaluate(8, [_finding("API_KEY", 8)]) == "BLOCK"


class TestStrictMode:
    def test_strict_blocks(self):
        assert evaluate(1, [_finding("IP", 1)], mode=Mode.STRICT) == "BLOCK"

    def test_strict_allows_empty(self):
        assert evaluate(0, [], mode=Mode.STRICT) == "ALLOW"


class TestBlockTypes:
    def test_block_type_forces_block(self):
        result = evaluate(1, [_finding("EMAIL", 1)], block_types=["EMAIL"])
        assert result == "BLOCK"


class TestAllowTypes:
    def test_allow_type_ignores_finding(self):
        result = evaluate(3, [_finding("EMAIL", 3)], allow_types=["EMAIL"])
        assert result == "ALLOW"


class TestCustomPolicy:
    def test_low_thresholds(self):
        policy = {"allow_threshold": 0, "redact_threshold": 1}
        assert evaluate(3, [_finding("EMAIL", 3)], policy=policy) == "BLOCK"

    def test_high_thresholds(self):
        policy = {"allow_threshold": 10, "redact_threshold": 10}
        assert evaluate(8, [_finding("API_KEY", 8)], policy=policy) == "ALLOW"
