"""Tests for built-in detectors."""


from contextfirewall.detectors import detect


class TestEmailDetection:
    def test_simple_email(self):
        findings = detect("Contact me at alice@example.com please.")
        types = [f.type for f in findings]
        assert "EMAIL" in types

    def test_multiple_emails(self):
        text = "Send to alice@example.com and bob@test.org"
        findings = [f for f in detect(text) if f.type == "EMAIL"]
        assert len(findings) == 2

    def test_no_email(self):
        findings = [f for f in detect("Hello world") if f.type == "EMAIL"]
        assert len(findings) == 0


class TestPhoneDetection:
    def test_us_phone(self):
        findings = detect("Call me at (555) 123-4567")
        types = [f.type for f in findings]
        assert "PHONE" in types

    def test_international_phone(self):
        findings = detect("Phone: +1-800-555-0199")
        types = [f.type for f in findings]
        assert "PHONE" in types


class TestAPIKeyDetection:
    def test_openai_key(self):
        findings = detect("My key is sk-1234567890abcdefghijklmnop")
        types = [f.type for f in findings]
        assert "API_KEY" in types

    def test_not_api_key(self):
        findings = [f for f in detect("sk-short") if f.type == "API_KEY"]
        assert len(findings) == 0


class TestJWTDetection:
    def test_jwt_token(self):
        token = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIn0.dozjgNryP4J3jVmNHl0w5N_XgL0n3I9PlFUP0THsR8U"
        findings = detect(f"Bearer {token}")
        types = [f.type for f in findings]
        assert "JWT" in types


class TestIPAddressDetection:
    def test_ipv4(self):
        findings = detect("Server at 192.168.1.100 is down")
        types = [f.type for f in findings]
        assert "IP_ADDRESS" in types


class TestCreditCardDetection:
    def test_visa(self):
        findings = detect("Card: 4111 1111 1111 1111")
        types = [f.type for f in findings]
        assert "CREDIT_CARD" in types


class TestSSNDetection:
    def test_ssn(self):
        findings = detect("SSN is 123-45-6789")
        types = [f.type for f in findings]
        assert "SSN" in types


class TestPrivateKeyDetection:
    def test_rsa_key(self):
        findings = detect("-----BEGIN RSA PRIVATE KEY-----\nMIIE...")
        types = [f.type for f in findings]
        assert "PRIVATE_KEY" in types


class TestGitHubTokenDetection:
    def test_github_pat(self):
        findings = detect("ghp_ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghij")
        types = [f.type for f in findings]
        assert "GITHUB_TOKEN" in types


class TestGenericSecretDetection:
    def test_password_assignment(self):
        findings = detect('password = "supersecretpassword123"')
        types = [f.type for f in findings]
        assert "GENERIC_SECRET" in types

    def test_token_assignment(self):
        findings = detect("token=abc123def456ghi789")
        types = [f.type for f in findings]
        assert "GENERIC_SECRET" in types


class TestAWSKeyDetection:
    def test_aws_access_key(self):
        findings = detect("AKIAIOSFODNN7EXAMPLE")
        types = [f.type for f in findings]
        assert "AWS_ACCESS_KEY" in types


class TestMultipleDetections:
    def test_email_and_api_key(self):
        text = "User email is john@gmail.com and API key is sk-123abc456def789ghijklmnop"
        findings = detect(text)
        types = {f.type for f in findings}
        assert "EMAIL" in types
        assert "API_KEY" in types
