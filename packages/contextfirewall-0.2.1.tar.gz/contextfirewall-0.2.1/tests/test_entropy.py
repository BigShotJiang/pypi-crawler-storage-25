"""Tests for entropy-based detection."""

from contextfirewall.entropy import shannon_entropy, detect_high_entropy

class TestEntropy:
    def test_shannon_entropy_zero(self):
        assert shannon_entropy("") == 0.0
        assert shannon_entropy("a") == 0.0
        assert shannon_entropy("aaaaaa") == 0.0

    def test_shannon_entropy_high(self):
        # Base64 string of random bytes usually has entropy > 4.5
        s = "qWeRtYuIoPaSdFgHjKlZxCvBnM123456"
        assert shannon_entropy(s) > 4.5

    def test_detect_high_entropy_paranoid(self):
        s = "qWeRtYuIoPaSdFgHjKlZxCvBnM123456"
        findings = detect_high_entropy(f"Here is some text with {s} embedded.", paranoid=True)
        assert len(findings) == 1
        assert findings[0].type == "HIGH_ENTROPY"

    def test_detect_high_entropy_context(self):
        s = "qWeRtYuIoPaSdFgHjKlZxCvBnM123456"
        # Since it lacks context keywords, non-paranoid should return []
        findings = detect_high_entropy(f"Here is some text with {s} embedded.", paranoid=False)
        assert len(findings) == 0

        # With context keyword
        findings = detect_high_entropy(f"Here is my secret token: {s}", paranoid=False)
        assert len(findings) == 1
