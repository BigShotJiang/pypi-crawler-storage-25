"""Tests for firewall decorators and context managers."""

import pytest
from contextfirewall.decorators import firewall

@firewall(mode="STRICT")
def dummy_llm_call_positional(prompt: str):
    return f"Processed: {prompt}"

@firewall(mode="STRICT")
def dummy_llm_call_kwarg(param1: int, prompt: str = ""):
    return f"Processed: {prompt}"

@firewall(mode="REDACT_ALL")
def dummy_llm_redact(prompt: str):
    return f"Processed: {prompt}"

class TestDecorators:
    def test_decorator_positional_allow(self):
        res = dummy_llm_call_positional("safe text")
        assert res == "Processed: safe text"

    def test_decorator_positional_block(self):
        with pytest.raises(ValueError, match="Contextfirewall blocked prompt"):
            dummy_llm_call_positional("My api key: sk-1234567890abcdefghijklmnop")

    def test_decorator_kwarg_block(self):
        with pytest.raises(ValueError):
            dummy_llm_call_kwarg(param1=1, prompt="My api key: sk-1234567890abcdefghijklmnop")

    def test_decorator_redact(self):
        res = dummy_llm_redact("Email me at bob@example.com")
        assert "[EMAIL_REDACTED]" in res

    def test_context_manager(self):
        with firewall.guard(mode="REDACT_ALL") as fw:
            res = fw.check("Email me at bob@example.com")
            assert "[EMAIL_REDACTED]" in res.cleaned
