"""Tests for the redaction engine."""

from contextfirewall.redact import default_redact, redact
from contextfirewall.models import Finding


def _finding(type_: str, match: str, start: int) -> Finding:
    return Finding(
        type=type_, match=match, start=start, end=start + len(match), risk=5
    )


class TestDefaultRedact:
    def test_single_replacement(self):
        text = "My email is alice@test.com ok"
        f = _finding("EMAIL", "alice@test.com", 12)
        result = default_redact(text, [f])
        assert "[EMAIL_REDACTED]" in result
        assert "alice@test.com" not in result

    def test_multiple_replacements(self):
        text = "alice@test.com and bob@test.com"
        findings = [
            _finding("EMAIL", "alice@test.com", 0),
            _finding("EMAIL", "bob@test.com", 19),
        ]
        result = default_redact(text, findings)
        assert result.count("[EMAIL_REDACTED]") == 2

    def test_preserves_surrounding_text(self):
        text = "Hello alice@test.com world"
        f = _finding("EMAIL", "alice@test.com", 6)
        result = default_redact(text, [f])
        assert result.startswith("Hello ")
        assert result.endswith(" world")


class TestCustomRedactor:
    def test_custom_function(self):
        def hide_all(text, findings):
            for f in findings:
                text = text.replace(f.match, "***")
            return text

        text = "alice@test.com"
        f = _finding("EMAIL", "alice@test.com", 0)
        result = redact(text, [f], redactor=hide_all)
        assert result == "***"
