from __future__ import annotations

from abc import abstractmethod
from collections.abc import Mapping
from enum import Enum
from typing import Any, Generic, Literal, NotRequired, Protocol, overload, runtime_checkable

from typing_extensions import TypedDict, TypeVar

from ..observable import Observable
from .base import Sensor, SensorCategory, SensorLike, SensorType
from .motion import Detection
from .spec import AudioModelSpec

BASE_AUDIO_LABELS = (
    "doorbell",
    "glass_break",
    "siren",
    "speaking",
    "gunshot",
    "dog_bark",
    "baby_cry",
    "alarm",
    "scream",
    "cat",
    "car_alarm",
    "smoke_alarm",
)

BaseAudioLabel = Literal[
    "doorbell",
    "glass_break",
    "siren",
    "speaking",
    "gunshot",
    "dog_bark",
    "baby_cry",
    "alarm",
    "scream",
    "cat",
    "car_alarm",
    "smoke_alarm",
]

AudioLabel = BaseAudioLabel | str


class AudioProperty(str, Enum):
    """Properties for audio detection sensors."""

    Detected = "detected"  # Whether an audio event is currently detected
    Detections = "detections"  # Array of audio detection results
    Decibels = "decibels"  # Current audio level in decibels
    LastTriggered = "lastTriggered"  # Timestamp (ms) of last detection trigger, set by backend


class AudioSensorProperties(TypedDict):
    detected: bool
    detections: list[Detection]
    decibels: float


class AudioPropertyChangeData(TypedDict):
    """Emitted on AudioSensorLike.onPropertyChanged."""

    property: str  # AudioProperty value
    value: bool | list[Detection] | float


TStorage = TypeVar("TStorage", bound=Mapping[str, Any], default=dict[str, Any])


@runtime_checkable
class AudioSensorLike(SensorLike, Protocol):
    """Read-only proxy interface for an audio sensor."""

    @property
    def type(self) -> SensorType:
        return SensorType.Audio

    @overload
    def getValue(self, property: Literal[AudioProperty.Detected]) -> bool | None: ...
    @overload
    def getValue(self, property: Literal[AudioProperty.Detections]) -> list[Detection] | None: ...
    @overload
    def getValue(self, property: Literal[AudioProperty.Decibels]) -> float | None: ...
    @overload
    def getValue(self, property: str) -> object | None: ...

    @property
    def onPropertyChanged(self) -> Observable[AudioPropertyChangeData]: ...


class AudioSensor(Sensor[AudioSensorProperties, TStorage, str], Generic[TStorage]):
    """Audio sensor that reports audio events and decibel levels.

    Plugin authors call `reportDetections(list)` to push detected audio events
    (auto-derives `detected`) and `setDecibels(value)` to update the audio level.
    """

    _requires_frames = False

    def __init__(self, name: str = "Audio Sensor") -> None:
        super().__init__(name)
        self._write_state(
            {
                AudioProperty.Detected.value: False,
                AudioProperty.Detections.value: [],
                AudioProperty.Decibels.value: 0.0,
            }
        )

    @property
    def type(self) -> SensorType:
        return SensorType.Audio

    @property
    def category(self) -> SensorCategory:
        return SensorCategory.Sensor

    @property
    def detected(self) -> bool:
        return bool(self.props.detected)

    @property
    def detections(self) -> list[Detection]:
        return self.props.detections or []

    @property
    def decibels(self) -> float:
        return float(self.props.decibels or 0.0)

    def reportDetections(self, detected: bool, detections: list[Detection] | None = None) -> None:
        """Report detected audio events.

        - `reportDetections(True)` — audio detected without specifics. The SDK
          synthesizes a single full-frame `'audio'` detection.
        - `reportDetections(True, [...])` — audio detected with explicit detections.
        - `reportDetections(False)` — clear.
        """
        list_ = self._normalize_reported_detections(detected, detections, "audio")  # type: ignore[arg-type]
        self._write_state(
            {
                AudioProperty.Detected.value: detected,
                AudioProperty.Detections.value: list_,
            }
        )

    def clearDetections(self) -> None:
        """Explicitly clear audio detection state (detected = False, detections = [])."""
        self.reportDetections(False)

    def setDecibels(self, value: float) -> None:
        """Update the current audio level (in decibels)."""
        self._write_state({AudioProperty.Decibels.value: value})

    async def updateValue(self, property: str, value: Any) -> None:
        """Read-only sensor: external writes are ignored."""
        # No-op — audio state is reported by the plugin, not set externally.


class AudioFrameData(TypedDict):
    """Audio frame data passed to audio detector sensors by the backend pipeline."""

    cameraId: NotRequired[str]
    data: bytes
    sampleRate: int
    channels: int
    format: Literal["pcm16", "float32"]
    decibels: NotRequired[float]
    timestamp: NotRequired[int]


class AudioResult(TypedDict):
    """Return type for AudioDetectorSensor.detectAudio()."""

    detected: bool
    detections: list[Detection]
    decibels: NotRequired[float]


class AudioDetectorSensor(AudioSensor[TStorage], Generic[TStorage]):
    """Audio detector that receives audio frames. Implement detectAudio() and modelSpec."""

    _requires_frames = True

    @property
    @abstractmethod
    def modelSpec(self) -> AudioModelSpec:
        """Declares expected audio input format. The backend resamples to match."""
        ...

    @abstractmethod
    async def detectAudio(self, audio: AudioFrameData) -> AudioResult:
        """Analyze an audio frame for events. Called by the backend at the configured interval."""
        ...
