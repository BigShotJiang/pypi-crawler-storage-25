from __future__ import annotations

from abc import abstractmethod
from collections.abc import Mapping
from enum import Enum
from typing import Any, Generic, Literal, NotRequired, Protocol, overload, runtime_checkable

from typing_extensions import TypedDict, TypeVar

from ..observable import Observable
from .base import Sensor, SensorCategory, SensorLike, SensorType


class MotionProperty(str, Enum):
    """Properties for motion sensors."""

    Detected = "detected"  # Whether motion is currently detected
    Detections = "detections"  # Array of detection results with bounding boxes
    Blocked = "blocked"  # When true, detection updates are suppressed
    LastTriggered = "lastTriggered"  # Timestamp (ms) of last detection trigger, set by backend


DETECTION_LABELS = ("motion", "person", "vehicle", "animal", "package", "audio")

DetectionLabel = Literal["motion", "person", "vehicle", "animal", "package", "audio"]

DETECTION_ATTRIBUTES = ("face", "license_plate")

DetectionAttribute = Literal["face", "license_plate"]


class BoundingBox(TypedDict):
    """Bounding box for a detection result. All coordinates are normalized to 0-1 (fraction of frame dimensions)."""

    x: float  # X coordinate of top-left corner (0-1)
    y: float  # Y coordinate of top-left corner (0-1)
    width: float  # Width as fraction of frame width (0-1)
    height: float  # Height as fraction of frame height (0-1)


class Detection(TypedDict):
    """A single detection result from any detection sensor."""

    label: DetectionLabel
    confidence: float
    box: BoundingBox
    attribute: NotRequired[str]  # DetectionAttribute or classifier-specific


class MotionSensorProperties(TypedDict):
    detected: bool
    detections: list[Detection]
    blocked: bool


class MotionPropertyChangeData(TypedDict):
    """Emitted on MotionSensorLike.onPropertyChanged."""

    property: str  # MotionProperty value
    value: bool | list[Detection]


TStorage = TypeVar("TStorage", bound=Mapping[str, Any], default=dict[str, Any])


@runtime_checkable
class MotionSensorLike(SensorLike, Protocol):
    """Read-only proxy interface for a motion sensor."""

    @property
    def type(self) -> SensorType:
        return SensorType.Motion

    @overload
    def getValue(self, property: Literal[MotionProperty.Detected]) -> bool | None: ...
    @overload
    def getValue(self, property: Literal[MotionProperty.Detections]) -> list[Detection] | None: ...
    @overload
    def getValue(self, property: Literal[MotionProperty.Blocked]) -> bool | None: ...
    @overload
    def getValue(self, property: str) -> object | None: ...

    @property
    def onPropertyChanged(self) -> Observable[MotionPropertyChangeData]: ...


class MotionSensor(Sensor[MotionSensorProperties, TStorage, str], Generic[TStorage]):
    """Motion sensor that reports motion state and detection results.

    Plugin authors call `reportDetections(list)` to push detection results.
    `detected` is auto-derived from the detection list. `blocked` is read-only
    and is set by the backend (dwell logic) — `reportDetections()` becomes a
    no-op while the sensor is blocked.
    """

    _requires_frames = False

    def __init__(self, name: str = "Motion Sensor") -> None:
        super().__init__(name)
        self._write_state(
            {
                MotionProperty.Detected.value: False,
                MotionProperty.Detections.value: [],
                MotionProperty.Blocked.value: False,
            }
        )

    @property
    def type(self) -> SensorType:
        return SensorType.Motion

    @property
    def category(self) -> SensorCategory:
        return SensorCategory.Sensor

    @property
    def detected(self) -> bool:
        return bool(self.props.detected)

    @property
    def detections(self) -> list[Detection]:
        return self.props.detections or []

    @property
    def blocked(self) -> bool:
        """Read-only — set by backend dwell logic, not by plugin code."""
        return bool(self.props.blocked)

    def reportDetections(self, detected: bool, detections: list[Detection] | None = None) -> None:
        """Report a motion detection result.

        - `reportDetections(True)` — motion detected without bbox (e.g. Ring camera).
          The SDK synthesizes a single full-frame `'motion'` detection.
        - `reportDetections(True, [...])` — motion detected with explicit detections.
        - `reportDetections(False)` — no motion (clears detections).

        No-op while the sensor is blocked by backend dwell logic.
        """
        if self.blocked:
            return
        list_ = self._normalize_reported_detections(detected, detections, "motion")  # type: ignore[arg-type]
        self._write_state(
            {
                MotionProperty.Detected.value: detected,
                MotionProperty.Detections.value: list_,
            }
        )

    def clearDetections(self) -> None:
        """Explicitly clear motion state (detected = False, detections = [])."""
        self.reportDetections(False)

    async def updateValue(self, property: str, value: Any) -> None:
        """Read-only sensor: external writes are ignored. State is reported via `reportDetections`."""
        # No-op — motion state is reported by the plugin, not set externally.


class MotionResult(TypedDict):
    """Return type for MotionDetectorSensor.detectMotion()."""

    detected: bool
    detections: list[Detection]


class VideoFrameData(TypedDict):
    """Video frame data passed to detector sensors by the backend pipeline."""

    id: str
    cameraId: NotRequired[str]
    data: bytes
    width: int
    height: int
    format: Literal[
        "nv12", "rgb", "rgba", "gray"
    ]  # Pixel format: rgb=3 bytes/pixel, gray=1 byte/pixel, nv12=YUV semi-planar
    timestamp: NotRequired[int]
    label: NotRequired[str]


class MotionDetectorSensor(MotionSensor[TStorage], Generic[TStorage]):
    """Motion detector that receives video frames from the backend pipeline. Extend this and implement detectMotion() to analyze frames for motion."""

    _requires_frames = True

    @abstractmethod
    async def detectMotion(self, frame: VideoFrameData) -> MotionResult:
        """Analyze a video frame for motion. Called by the backend at the configured interval."""
        ...
