from __future__ import annotations

from abc import abstractmethod
from collections.abc import Mapping
from enum import Enum
from typing import Any, Generic, Literal, NotRequired, Protocol, overload, runtime_checkable

from typing_extensions import TypedDict, TypeVar

from ..observable import Observable
from .base import Sensor, SensorCategory, SensorLike, SensorType
from .motion import Detection, VideoFrameData
from .spec import ModelSpec


class FaceProperty(str, Enum):
    """Properties for face detection sensors."""

    Detected = "detected"
    Detections = "detections"


class FaceDetection(Detection):
    """A face detection result, extending Detection with face-specific fields."""

    attribute: Literal["face"]  # type: ignore[misc]
    identity: NotRequired[str]
    embedding: NotRequired[list[float]]
    thumbnail: NotRequired[bytes]


class FaceSensorProperties(TypedDict):
    detected: bool
    detections: list[FaceDetection]


class FacePropertyChangeData(TypedDict):
    """Emitted on FaceSensorLike.onPropertyChanged."""

    property: str  # FaceProperty value
    value: bool | list[FaceDetection]


TStorage = TypeVar("TStorage", bound=Mapping[str, Any], default=dict[str, Any])


@runtime_checkable
class FaceSensorLike(SensorLike, Protocol):
    """Read-only proxy interface for a face sensor."""

    @property
    def type(self) -> SensorType:
        return SensorType.Face

    @overload
    def getValue(self, property: Literal[FaceProperty.Detected]) -> bool | None: ...
    @overload
    def getValue(self, property: Literal[FaceProperty.Detections]) -> list[FaceDetection] | None: ...
    @overload
    def getValue(self, property: str) -> object | None: ...

    @property
    def onPropertyChanged(self) -> Observable[FacePropertyChangeData]: ...


class FaceSensor(Sensor[FaceSensorProperties, TStorage, str], Generic[TStorage]):
    """Face sensor that reports detected faces and optional identity matches.

    Plugin authors call `reportDetections(list)` to push detected faces.
    `detected` is auto-derived from the detection list.
    """

    _requires_frames = False

    def __init__(self, name: str = "Face Sensor") -> None:
        super().__init__(name)
        self._write_state(
            {
                FaceProperty.Detected.value: False,
                FaceProperty.Detections.value: [],
            }
        )

    @property
    def type(self) -> SensorType:
        return SensorType.Face

    @property
    def category(self) -> SensorCategory:
        return SensorCategory.Sensor

    @property
    def detected(self) -> bool:
        return bool(self.props.detected)

    @property
    def detections(self) -> list[FaceDetection]:
        return self.props.detections or []

    def reportDetections(self, detected: bool, detections: list[FaceDetection] | None = None) -> None:
        """Report detected faces."""
        list_ = self._normalize_reported_detections(
            detected,
            detections,  # type: ignore[arg-type]
            "person",
            {"attribute": "face"},
        )
        self._write_state(
            {
                FaceProperty.Detected.value: detected,
                FaceProperty.Detections.value: list_,
            }
        )

    def clearDetections(self) -> None:
        """Explicitly clear face detection state (detected = False, detections = [])."""
        self.reportDetections(False)

    async def updateValue(self, property: str, value: Any) -> None:
        """Read-only sensor: external writes are ignored."""
        # No-op — face detection state is reported by the plugin, not set externally.


class FaceResult(TypedDict):
    """Return type for FaceDetectorSensor.detectFaces()."""

    detected: bool
    detections: list[FaceDetection]


class FaceDetectorSensor(FaceSensor[TStorage], Generic[TStorage]):
    """Face detector that receives video frames. Implement detectFaces() for face detection and recognition."""

    _requires_frames = True

    @property
    @abstractmethod
    def modelSpec(self) -> ModelSpec:
        """Declares expected input dimensions and output labels. The backend scales frames to match."""
        ...

    @abstractmethod
    async def detectFaces(self, frames: list[VideoFrameData]) -> list[FaceResult]:
        """Detect faces in batch. Each frame is a pre-cropped, pre-scaled person region.
        Must return exactly one FaceResult per input frame."""
        ...
