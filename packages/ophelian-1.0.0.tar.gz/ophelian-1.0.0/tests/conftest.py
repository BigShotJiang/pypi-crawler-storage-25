"""Shared pytest fixtures.

The OpenTelemetry SDK's ``set_tracer_provider`` / ``set_meter_provider``
are one-shot by design — calling them a second time logs a warning and
keeps the original provider. Each test module that wants to assert on
spans / metrics therefore has to share the same in-memory providers.

This module installs them once per test session and yields the
in-memory exporters so individual tests can ``clear()`` between runs.
``OPHELIAN_OTEL_DISABLE=1`` is set so ``auto_configure_from_env`` sees
that we already own the providers and stays out of the way.
"""

from __future__ import annotations

import os
from collections.abc import Iterator
from typing import Any

import pytest


@pytest.fixture(autouse=True)
def _isolate_cost_ledger(
    tmp_path_factory: pytest.TempPathFactory, monkeypatch: pytest.MonkeyPatch
) -> Iterator[None]:
    """Redirect the cost ledger to a per-test temp file so the suite
    never appends to the developer's real ``~/.ophelian/ledger.jsonl``.
    Tests that exercise the ledger explicitly override the env var
    themselves via their own fixture; this autouse just provides the
    safety net for everything else."""
    target = tmp_path_factory.mktemp("ledger") / "ledger.jsonl"
    monkeypatch.setenv("OPHELIAN_LEDGER_PATH", str(target))
    yield


@pytest.fixture(scope="session")
def _otel_in_memory_providers() -> Iterator[dict[str, Any]]:
    os.environ["OPHELIAN_OTEL_DISABLE"] = "1"

    from opentelemetry import metrics, trace
    from opentelemetry.sdk.metrics import MeterProvider
    from opentelemetry.sdk.metrics.export import InMemoryMetricReader
    from opentelemetry.sdk.trace import TracerProvider
    from opentelemetry.sdk.trace.export import SimpleSpanProcessor
    from opentelemetry.sdk.trace.export.in_memory_span_exporter import (
        InMemorySpanExporter,
    )
    from ophelian.observability.otel import _reset_auto_configuration_for_tests

    span_exporter = InMemorySpanExporter()
    tracer_provider = TracerProvider()
    tracer_provider.add_span_processor(SimpleSpanProcessor(span_exporter))
    metric_reader = InMemoryMetricReader()
    # Also attach a Prometheus reader so the ``/metrics`` endpoint
    # exposed by ``build_app(enable_prometheus=True)`` can be tested
    # end-to-end (Ophelian metric → MeterProvider → Prometheus
    # registry → ``/metrics`` text). The reader writes into the
    # global ``prometheus_client.REGISTRY``; gating its install on
    # import availability keeps the fixture working when the
    # optional ``[otel]`` Prometheus extras are absent.
    readers: list[Any] = [metric_reader]
    try:
        from opentelemetry.exporter.prometheus import PrometheusMetricReader

        readers.append(PrometheusMetricReader())
    except ImportError:
        pass
    meter_provider = MeterProvider(metric_readers=readers)
    trace.set_tracer_provider(tracer_provider)
    metrics.set_meter_provider(meter_provider)
    _reset_auto_configuration_for_tests()
    try:
        yield {"spans": span_exporter, "metrics": metric_reader}
    finally:
        os.environ.pop("OPHELIAN_OTEL_DISABLE", None)
