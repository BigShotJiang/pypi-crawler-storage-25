# Contributing to prose-tokenizer

Thank you for your interest in improving `prose-tokenizer`!

## Development Setup

1. Clone the repository.
2. Install development dependencies:
   ```bash
   pip install -e ".[dev]"
   ```

## Workflow

1. Create a branch for your changes.
2. Ensure all tests pass: `pytest`.
3. Ensure linting and type checks pass: `ruff check .` and `mypy .`.
4. Submit a Pull Request.

## Philosophy

- Keep it small and dependency-free.
- Maintain deterministic behavior.
- Use explicit type hints.

MIT © [Veldica](https://veldica.com)
