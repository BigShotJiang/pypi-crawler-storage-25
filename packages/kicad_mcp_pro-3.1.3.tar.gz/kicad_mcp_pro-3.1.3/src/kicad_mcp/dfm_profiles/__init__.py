"""Bundled manufacturer DFM profiles."""
