# Setup project for unittest discovery
import sys
import os

# Ensure SleePyPhases is imported as a package before loadClass adds
# the inner directory to sys.path (which would shadow the package with SleePyPhases.py)
_cwd = os.getcwd()
_inner = os.path.join(_cwd, "SleePyPhases")
if _inner in sys.path:
    sys.path.remove(_inner)
import SleePyPhases  # noqa: E402,F401 — force package registration

from phases.commands.test import Test as PhasesTest
from pyPhases.test import TestCase


def _setup_project():
    """Setup the project for testing - called when tests module is imported."""
    if TestCase.project is None:
        phasesTest = PhasesTest({})
        phasesTest.prepareConfig()
        testConfig = phasesTest.loadConfig("tests/config.yml")
        phasesTest.config.update(testConfig)
        project = phasesTest.createProjectFromConfig(phasesTest.config)
        TestCase.project = project


_setup_project()
