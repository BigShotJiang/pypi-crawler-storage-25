from phases import DefaultProject
from pyPhases import Project
from pyPhasesRecordloader import RecordSignal


class SleePyPhases(Project):
    """
    This is the main class for the SleePyPhases project. It defines the phases that will be executed in the project.
    """

    @staticmethod
    def create(configFiles=None, plugins=None, projectFile=None):
        if plugins is None:
            plugins = []

        defaultPlugins = [
            "SleePyPhases",
            "pyPhasesML",
            "pyPhasesRecordloader",
        ]
        project = DefaultProject.create(configFiles, plugins + defaultPlugins, project=SleePyPhases(), projectFile=projectFile)

        return project
    

    def predictRecordSignal(self, recordSignal: RecordSignal):
        from SleePyPhases.phases.Predict import Predict
        predict: Predict = self.getPhase("Predict")
        return predict.predictRecordSignal(recordSignal)
    
    def predictFromFile(self, filepath: str):
        from SleePyPhases.phases.Predict import Predict
        predict: Predict = self.getPhase("Predict")
        return predict.predict(filepath)