import{b as r}from"./_baseUniq-BujCjeqr.js";var e=4;function a(o){return r(o,e)}export{a as c};
