from __future__ import annotations

import hashlib
import json
import os
import subprocess
import sys
import time
from dataclasses import dataclass
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any

from huggingface_hub import hf_hub_download
from huggingface_hub.errors import EntryNotFoundError, HfHubHTTPError

from .manifest import (
    DEFAULT_QUANT,
    DEFAULT_REPO_ID,
    cache_dir_for,
    expected_package_sha256,
    normalize_quant,
    quant_filename,
)
from .release_pipeline import (
    ReleasePipelineError,
    gemma4_shared_kv_runtime_guidance,
    is_gemma4_shared_kv_runtime_error,
    read_gguf_metadata,
)


class HashMismatchError(RuntimeError):
    """Raised when a downloaded model fails SHA256 verification."""


class MissingChecksumError(RuntimeError):
    """Raised when no checksum is available for a requested quant."""


class ServerLaunchError(RuntimeError):
    """Raised when the local OpenAI-compatible server cannot start."""


class GGUFValidationError(RuntimeError):
    """Raised when a GGUF artifact fails structural validation."""


@dataclass
class ServeConfig:
    host: str = "127.0.0.1"
    port: int = 8000
    model_alias: str = "padauk-agent"
    n_ctx: int = 8192
    n_gpu_layers: int = -1
    api_key: str = "sk-no-key-required"


def resolve_hf_token(hf_token: str | None) -> str | None:
    if hf_token:
        return hf_token
    env_token = os.getenv("HF_TOKEN")
    if env_token:
        return env_token
    return None


def file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as fh:
        while True:
            chunk = fh.read(1024 * 1024)
            if not chunk:
                break
            digest.update(chunk)
    return digest.hexdigest()


def parse_sha256sums(content: str) -> dict[str, str]:
    checksums: dict[str, str] = {}
    for raw_line in content.splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue
        parts = line.split()
        if len(parts) < 2:
            continue
        checksums[parts[-1]] = parts[0].lower()
    return checksums


class PadaukAgent:
    def __init__(
        self,
        quant: str = DEFAULT_QUANT,
        repo_id: str = DEFAULT_REPO_ID,
        revision: str | None = None,
        cache_dir: str | Path | None = None,
        hf_token: str | None = None,
    ) -> None:
        self.quant = normalize_quant(quant)
        self.repo_id = repo_id
        self.revision = revision
        self.cache_dir = cache_dir_for(repo_id, revision, cache_dir)
        self.hf_token = hf_token
        self.model_filename = quant_filename(self.quant)
        self.model_path = self.cache_dir / self.model_filename
        self._serve_config = ServeConfig()

    @property
    def openai_base_url(self) -> str:
        return f"http://{self._serve_config.host}:{self._serve_config.port}/v1"

    def ensure_model(self) -> Path:
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        token = resolve_hf_token(self.hf_token)
        model_path = Path(
            hf_hub_download(
                repo_id=self.repo_id,
                filename=self.model_filename,
                revision=self.revision,
                token=token,
                local_dir=str(self.cache_dir),
            )
        )

        checksums = self._load_repo_checksums(token)
        expected_sha = expected_package_sha256(self.quant) or checksums.get(self.model_filename)
        if not expected_sha:
            raise MissingChecksumError(
                f"No checksum found for {self.model_filename}. "
                "Add it to PACKAGE_SHA256 or SHA256SUMS.txt in the model repo."
            )

        actual_sha = file_sha256(model_path)
        if actual_sha.lower() != expected_sha.lower():
            raise HashMismatchError(
                f"Checksum mismatch for {model_path}. expected={expected_sha}, actual={actual_sha}"
            )

        self.model_path = model_path
        return model_path

    def validate_model(self, *, runtime_check: bool = True) -> Path:
        model_path = self.ensure_model()
        self._validate_gguf_magic(model_path)
        if runtime_check:
            self._validate_runtime_load(model_path)
        return model_path

    def _validate_gguf_magic(self, model_path: Path) -> None:
        try:
            with model_path.open("rb") as fh:
                magic = fh.read(4)
        except OSError as exc:
            raise GGUFValidationError(f"Unable to read model file {model_path}: {exc}") from exc

        if magic != b"GGUF":
            raise GGUFValidationError(
                f"Invalid GGUF header for {model_path}: expected b'GGUF', found {magic!r}."
            )

    def _load_llama_class(self):
        try:
            from llama_cpp import Llama
        except ImportError as exc:
            raise RuntimeError(
                "Runtime validation requires llama-cpp-python. "
                'Install with: pip install "burmesegpt[server]" '
                'or pip install "llama-cpp-python".'
            ) from exc
        return Llama

    def _validate_runtime_load(self, model_path: Path) -> None:
        Llama = self._load_llama_class()
        llm = None
        metadata: dict[str, Any] | None = None
        try:
            metadata = read_gguf_metadata(model_path)
        except ReleasePipelineError:
            metadata = None
        try:
            llm = Llama(
                model_path=str(model_path),
                n_ctx=128,
                n_gpu_layers=0,
                verbose=False,
            )
        except Exception as exc:
            guidance = ""
            if is_gemma4_shared_kv_runtime_error(exc, metadata):
                guidance = f" {gemma4_shared_kv_runtime_guidance()}"
            raise RuntimeError(
                f"llama_cpp failed to load {model_path}: {exc}. "
                f"The GGUF artifact may be corrupted or incompatible.{guidance}"
            ) from exc
        finally:
            close = getattr(llm, "close", None)
            if callable(close):
                close()

    def _load_repo_checksums(self, token: str | None) -> dict[str, str]:
        try:
            checksum_path = Path(
                hf_hub_download(
                    repo_id=self.repo_id,
                    filename="SHA256SUMS.txt",
                    revision=self.revision,
                    token=token,
                    local_dir=str(self.cache_dir),
                )
            )
        except (EntryNotFoundError, HfHubHTTPError):
            return {}

        try:
            return parse_sha256sums(checksum_path.read_text(encoding="utf-8"))
        except OSError:
            return {}

    def _build_server_command(self, config: ServeConfig, model_path: Path) -> list[str]:
        return [
            sys.executable,
            "-m",
            "llama_cpp.server",
            "--model",
            str(model_path),
            "--host",
            config.host,
            "--port",
            str(config.port),
            "--n_ctx",
            str(config.n_ctx),
            "--n_gpu_layers",
            str(config.n_gpu_layers),
            "--model_alias",
            config.model_alias,
            "--api_key",
            config.api_key,
        ]

    def serve(
        self,
        host: str = "127.0.0.1",
        port: int = 8000,
        model_alias: str = "padauk-agent",
        n_ctx: int = 8192,
        n_gpu_layers: int = -1,
        api_key: str = "sk-no-key-required",
        *,
        wait: bool = True,
        test_mode: bool = False,
    ) -> subprocess.Popen[str] | None:
        self._serve_config = ServeConfig(
            host=host,
            port=port,
            model_alias=model_alias,
            n_ctx=n_ctx,
            n_gpu_layers=n_gpu_layers,
            api_key=api_key,
        )

        if test_mode:
            self._serve_test_mode()
            return None

        model_path = self.ensure_model()
        command = self._build_server_command(self._serve_config, model_path)

        process = subprocess.Popen(command, text=True)
        if wait:
            returncode = process.wait()
            if returncode != 0:
                raise ServerLaunchError(
                    f"llama_cpp.server exited with status {returncode}. "
                    "Possible causes: missing server dependencies "
                    "(install with: pip install burmesegpt[server]) "
                    "or an invalid/incompatible GGUF artifact."
                )
            return None

        return process

    def _serve_test_mode(self) -> None:
        config = self._serve_config

        class _Handler(BaseHTTPRequestHandler):
            protocol_version = "HTTP/1.1"

            def _write_json(self, payload: dict[str, Any], status: int = 200) -> None:
                encoded = json.dumps(payload).encode("utf-8")
                self.send_response(status)
                self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(encoded)))
                self.end_headers()
                self.wfile.write(encoded)

            def log_message(self, _format: str, *_args: Any) -> None:
                return

            def do_GET(self) -> None:  # noqa: N802
                if self.path == "/v1/models":
                    self._write_json(
                        {
                            "object": "list",
                            "data": [{"id": config.model_alias, "object": "model"}],
                        }
                    )
                    return
                self._write_json({"error": "not_found"}, status=404)

            def do_POST(self) -> None:  # noqa: N802
                if self.path != "/v1/chat/completions":
                    self._write_json({"error": "not_found"}, status=404)
                    return

                body = self.rfile.read(int(self.headers.get("Content-Length", 0) or 0))
                request_json = json.loads(body.decode("utf-8") or "{}")
                messages = request_json.get("messages", [])
                user_message = ""
                for message in reversed(messages):
                    if message.get("role") == "user":
                        user_message = str(message.get("content", ""))
                        break

                self._write_json(
                    {
                        "id": "chatcmpl-test",
                        "object": "chat.completion",
                        "model": config.model_alias,
                        "choices": [
                            {
                                "index": 0,
                                "message": {
                                    "role": "assistant",
                                    "content": f"[test-mode] {user_message}".strip(),
                                },
                                "finish_reason": "stop",
                            }
                        ],
                    }
                )

        server = ThreadingHTTPServer((config.host, config.port), _Handler)
        try:
            server.serve_forever()
        finally:
            server.server_close()



def padauk_agent(
    quant: str = DEFAULT_QUANT,
    repo_id: str = DEFAULT_REPO_ID,
    revision: str | None = None,
    cache_dir: str | Path | None = None,
    hf_token: str | None = None,
) -> PadaukAgent:
    return PadaukAgent(
        quant=quant,
        repo_id=repo_id,
        revision=revision,
        cache_dir=cache_dir,
        hf_token=hf_token,
    )



def wait_for_server(base_url: str, timeout: float = 30.0) -> None:
    import requests

    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        try:
            response = requests.get(f"{base_url}/models", timeout=1.0)
            if 200 <= response.status_code < 300:
                return
        except requests.RequestException:
            pass
        time.sleep(0.3)
    raise TimeoutError(f"Timed out waiting for server at {base_url}")



def chat_completion(
    *,
    base_url: str,
    model: str,
    messages: list[dict[str, str]],
    api_key: str,
    timeout: float = 120.0,
) -> str:
    import requests

    response = requests.post(
        f"{base_url}/chat/completions",
        headers={
            "Content-Type": "application/json",
            "Authorization": f"Bearer {api_key}",
        },
        json={
            "model": model,
            "messages": messages,
        },
        timeout=timeout,
    )
    response.raise_for_status()
    payload = response.json()
    return str(payload["choices"][0]["message"]["content"])
