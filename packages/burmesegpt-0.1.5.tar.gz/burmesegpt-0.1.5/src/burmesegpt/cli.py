from __future__ import annotations

import argparse
import json
import sys
import time
from typing import Any

from .agent import chat_completion, padauk_agent, wait_for_server
from .manifest import DEFAULT_QUANT, DEFAULT_REPO_ID, QUANT_FILENAMES


EXIT_COMMANDS = {"/exit", "/quit", "exit", "quit"}
EXIT_SMOKE_CONNECTION_ERROR = 2
EXIT_SMOKE_RESPONSE_ERROR = 3
EXIT_SMOKE_SDK_MISSING = 4


def _add_shared_model_args(
    parser: argparse.ArgumentParser, *, suppress_defaults: bool = False
) -> None:
    default = argparse.SUPPRESS if suppress_defaults else None
    parser.add_argument(
        "--repo-id",
        default=DEFAULT_REPO_ID if not suppress_defaults else argparse.SUPPRESS,
        help="Hugging Face model repo id",
    )
    parser.add_argument("--revision", default=default, help="Optional HF revision/tag/commit")
    parser.add_argument(
        "--cache-dir",
        default=default,
        help="Model cache root (default ~/.cache/burmesegpt/models)",
    )
    parser.add_argument(
        "--hf-token",
        default=default,
        help="HF token (takes precedence over HF_TOKEN)",
    )


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="burmesegpt",
        description="Run Padauk Burmese GGUF models with easy local OpenAI-compatible workflows.",
    )

    _add_shared_model_args(parser)

    subparsers = parser.add_subparsers(dest="command", required=True)

    quant_choices = sorted(QUANT_FILENAMES)

    download_parser = subparsers.add_parser("download", help="Download and verify model files")
    _add_shared_model_args(download_parser, suppress_defaults=True)
    download_parser.add_argument("--quant", choices=quant_choices, default=DEFAULT_QUANT)
    download_parser.set_defaults(func=cmd_download)

    validate_parser = subparsers.add_parser(
        "validate",
        help="Validate GGUF artifact (checksum + header + runtime load by default)",
    )
    _add_shared_model_args(validate_parser, suppress_defaults=True)
    validate_parser.add_argument("--quant", choices=quant_choices, default=DEFAULT_QUANT)
    validate_parser.add_argument(
        "--runtime-check",
        dest="runtime_check",
        action="store_true",
        default=True,
        help="Run lightweight llama_cpp model load check (default: enabled).",
    )
    validate_parser.add_argument(
        "--no-runtime-check",
        dest="runtime_check",
        action="store_false",
        help="Skip llama_cpp runtime model load and only validate download, checksum, and GGUF header.",
    )
    validate_parser.set_defaults(func=cmd_validate)

    serve_parser = subparsers.add_parser("serve", help="Start OpenAI-compatible local API server")
    _add_shared_model_args(serve_parser, suppress_defaults=True)
    serve_parser.add_argument("--quant", choices=quant_choices, default=DEFAULT_QUANT)
    serve_parser.add_argument("--host", default="127.0.0.1")
    serve_parser.add_argument("--port", type=int, default=8000)
    serve_parser.add_argument("--model-alias", default="padauk-agent")
    serve_parser.add_argument("--n-ctx", type=int, default=8192)
    serve_parser.add_argument("--n-gpu-layers", type=int, default=-1)
    serve_parser.add_argument("--api-key", default="sk-no-key-required")
    serve_parser.add_argument("--test-mode", action="store_true", help=argparse.SUPPRESS)
    serve_parser.set_defaults(func=cmd_serve)

    run_parser = subparsers.add_parser("run", help="Interactive quick chat")
    _add_shared_model_args(run_parser, suppress_defaults=True)
    run_parser.add_argument("--quant", choices=quant_choices, default=DEFAULT_QUANT)
    run_parser.add_argument("--host", default="127.0.0.1")
    run_parser.add_argument("--port", type=int, default=8000)
    run_parser.add_argument("--model-alias", default="padauk-agent")
    run_parser.add_argument("--n-ctx", type=int, default=8192)
    run_parser.add_argument("--n-gpu-layers", type=int, default=-1)
    run_parser.add_argument("--api-key", default="sk-no-key-required")
    run_parser.add_argument("--startup-timeout", type=float, default=30.0)
    run_parser.add_argument(
        "--base-url",
        default=None,
        help="Use an already running OpenAI-compatible endpoint (e.g. http://127.0.0.1:8000/v1)",
    )
    run_parser.add_argument("--test-mode", action="store_true", help=argparse.SUPPRESS)
    run_parser.set_defaults(func=cmd_run)

    smoke_test_parser = subparsers.add_parser(
        "smoke-test",
        help="Smoke test an OpenAI-compatible endpoint (/models + /chat/completions)",
    )
    smoke_test_parser.add_argument("--base-url", default="http://127.0.0.1:8000/v1")
    smoke_test_parser.add_argument("--model", default="padauk-agent")
    smoke_test_parser.add_argument("--api-key", default="sk-no-key-required")
    smoke_test_parser.add_argument("--prompt", default="hello")
    smoke_test_parser.add_argument("--timeout", type=float, default=15.0)
    smoke_test_parser.add_argument(
        "--client",
        choices=("http", "openai"),
        default="http",
        help="Client mode: direct HTTP requests or OpenAI SDK",
    )
    smoke_test_parser.set_defaults(func=cmd_smoke_test)

    info_parser = subparsers.add_parser("info", help="Show package/model configuration")
    _add_shared_model_args(info_parser, suppress_defaults=True)
    info_parser.add_argument("--quant", choices=quant_choices, default=DEFAULT_QUANT)
    info_parser.set_defaults(func=cmd_info)

    return parser


def _make_agent(args: argparse.Namespace):
    return padauk_agent(
        quant=getattr(args, "quant", DEFAULT_QUANT),
        repo_id=args.repo_id,
        revision=args.revision,
        cache_dir=args.cache_dir,
        hf_token=args.hf_token,
    )


def cmd_download(args: argparse.Namespace) -> int:
    agent = _make_agent(args)
    model_path = agent.ensure_model()
    print(f"Model ready: {model_path}")
    return 0


def cmd_validate(args: argparse.Namespace) -> int:
    agent = _make_agent(args)
    try:
        model_path = agent.validate_model(runtime_check=args.runtime_check)
    except Exception as exc:
        print(f"Validation failed: {exc}", file=sys.stderr)
        return 1

    if args.runtime_check:
        print(f"Validation passed (checksum + GGUF header + runtime load): {model_path}")
    else:
        print(f"Validation passed (checksum + GGUF header): {model_path}")
    return 0


def cmd_serve(args: argparse.Namespace) -> int:
    agent = _make_agent(args)
    print(
        f"Starting server for quant={args.quant} at http://{args.host}:{args.port}/v1 "
        f"(model_alias={args.model_alias})"
    )
    agent.serve(
        host=args.host,
        port=args.port,
        model_alias=args.model_alias,
        n_ctx=args.n_ctx,
        n_gpu_layers=args.n_gpu_layers,
        api_key=args.api_key,
        wait=True,
        test_mode=args.test_mode,
    )
    return 0


def _wait_for_startup_process(*, base_url: str, timeout: float, process: Any) -> None:
    deadline = time.monotonic() + timeout
    while True:
        returncode = process.poll()
        if returncode is not None:
            raise RuntimeError(
                f"local server process exited before becoming ready (exit code: {returncode})"
            )

        remaining = deadline - time.monotonic()
        if remaining <= 0:
            raise TimeoutError(f"Timed out waiting for server at {base_url}")

        try:
            wait_for_server(base_url, timeout=min(remaining, 0.5))
            return
        except TimeoutError:
            continue


def cmd_run(args: argparse.Namespace) -> int:
    agent = _make_agent(args)
    process = None

    try:
        if args.base_url:
            base_url = args.base_url.rstrip("/")
        else:
            process = agent.serve(
                host=args.host,
                port=args.port,
                model_alias=args.model_alias,
                n_ctx=args.n_ctx,
                n_gpu_layers=args.n_gpu_layers,
                api_key=args.api_key,
                wait=False,
                test_mode=args.test_mode,
            )
            base_url = agent.openai_base_url
            try:
                _wait_for_startup_process(
                    base_url=base_url,
                    timeout=args.startup_timeout,
                    process=process,
                )
            except (RuntimeError, TimeoutError) as exc:
                print(f"Failed to start local server: {exc}", file=sys.stderr)
                return 1

        print("Interactive chat ready. Type '/exit' to stop.")
        messages: list[dict[str, str]] = []

        while True:
            user_text = input("you> ").strip()
            if not user_text:
                continue
            if user_text.lower() in EXIT_COMMANDS:
                break

            messages.append({"role": "user", "content": user_text})
            reply = chat_completion(
                base_url=base_url,
                model=args.model_alias,
                messages=messages,
                api_key=args.api_key,
            )
            print(f"padauk> {reply}")
            messages.append({"role": "assistant", "content": reply})
    except (KeyboardInterrupt, EOFError):
        print()
    finally:
        if process is not None and process.poll() is None:
            process.terminate()
            try:
                process.wait(timeout=10)
            except Exception:
                process.kill()

    return 0


def _load_openai_client():
    from openai import OpenAI

    return OpenAI


def _extract_chat_content(payload: dict[str, Any]) -> str:
    try:
        content = payload["choices"][0]["message"]["content"]
    except (KeyError, IndexError, TypeError) as exc:
        raise ValueError(f"Unexpected chat completion response shape: {payload}") from exc
    return str(content)


def _smoke_test_http(
    *,
    base_url: str,
    model: str,
    api_key: str,
    prompt: str,
    timeout: float,
) -> tuple[list[str], str]:
    import requests

    auth_header = {"Authorization": f"Bearer {api_key}"}

    models_response = requests.get(f"{base_url}/models", headers=auth_header, timeout=timeout)
    models_response.raise_for_status()
    models_payload = models_response.json()

    if not isinstance(models_payload, dict) or not isinstance(models_payload.get("data"), list):
        raise ValueError("`/models` did not return expected OpenAI-compatible payload.")

    model_ids = []
    for item in models_payload["data"]:
        if isinstance(item, dict) and "id" in item:
            model_ids.append(str(item["id"]))
    if not model_ids:
        raise ValueError("`/models` returned no model ids.")

    chat_response = requests.post(
        f"{base_url}/chat/completions",
        headers={
            "Content-Type": "application/json",
            "Authorization": f"Bearer {api_key}",
        },
        json={
            "model": model,
            "messages": [{"role": "user", "content": prompt}],
        },
        timeout=timeout,
    )
    chat_response.raise_for_status()
    chat_payload = chat_response.json()
    return model_ids, _extract_chat_content(chat_payload)


def _smoke_test_openai(
    *,
    base_url: str,
    model: str,
    api_key: str,
    prompt: str,
    timeout: float,
) -> tuple[list[str], str]:
    OpenAI = _load_openai_client()
    client = OpenAI(base_url=base_url, api_key=api_key, timeout=timeout)

    models_payload = client.models.list()
    models_data = getattr(models_payload, "data", None)
    if not isinstance(models_data, list):
        raise ValueError("`models.list()` did not return a list payload.")

    model_ids = [str(getattr(item, "id")) for item in models_data if getattr(item, "id", None)]
    if not model_ids:
        raise ValueError("`models.list()` returned no model ids.")

    completion = client.chat.completions.create(
        model=model,
        messages=[{"role": "user", "content": prompt}],
    )
    try:
        content = completion.choices[0].message.content
    except (AttributeError, IndexError, TypeError) as exc:
        raise ValueError("Unexpected OpenAI SDK completion response shape.") from exc
    return model_ids, str(content or "")


def cmd_smoke_test(args: argparse.Namespace) -> int:
    base_url = args.base_url.rstrip("/")
    print(f"Smoke testing {base_url} via {args.client} client (model={args.model})")

    try:
        if args.client == "openai":
            model_ids, reply = _smoke_test_openai(
                base_url=base_url,
                model=args.model,
                api_key=args.api_key,
                prompt=args.prompt,
                timeout=args.timeout,
            )
        else:
            model_ids, reply = _smoke_test_http(
                base_url=base_url,
                model=args.model,
                api_key=args.api_key,
                prompt=args.prompt,
                timeout=args.timeout,
            )
    except ImportError:
        print(
            'OpenAI SDK is not installed. Install with: pip install "burmesegpt[openai]" '
            'or pip install "burmesegpt[full]"',
            file=sys.stderr,
        )
        return EXIT_SMOKE_SDK_MISSING
    except ValueError as exc:
        print(f"Smoke test failed: {exc}", file=sys.stderr)
        return EXIT_SMOKE_RESPONSE_ERROR
    except Exception as exc:
        print(
            f"Smoke test failed: {exc}\n"
            f"Verify the endpoint is up and OpenAI-compatible at {base_url}.",
            file=sys.stderr,
        )
        return EXIT_SMOKE_CONNECTION_ERROR

    print(f"Models OK: {', '.join(model_ids)}")
    print(f"Chat completion OK: {reply}")
    return 0


def cmd_info(args: argparse.Namespace) -> int:
    agent = _make_agent(args)
    payload = {
        "repo_id": agent.repo_id,
        "revision": agent.revision,
        "quant": agent.quant,
        "filename": agent.model_filename,
        "cache_dir": str(agent.cache_dir),
        "model_path": str(agent.model_path),
        "openai_base_url": agent.openai_base_url,
    }
    print(json.dumps(payload, indent=2, ensure_ascii=False))
    return 0


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    return args.func(args)


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
