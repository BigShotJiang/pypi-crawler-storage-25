# BurmeseGPT

BurmeseGPT is an open Burmese-first AI ecosystem created by Dr. Wai Yan Nyein Naing. This Python package is the main package for BurmeseGPT projects, including Padauk, a practical agentic small language model built for Burmese language understanding, tool use, function calling, and local or edge deployment.

## Why BurmeseGPT

Burmese is still a low-resource language in AI, and practical Burmese AI tooling remains limited for many real developer workflows. BurmeseGPT focuses on useful, production-minded, and developer-friendly Burmese AI systems that can run locally and integrate with modern agent and API patterns.

## Related projects

- **Padauk** - Burmese-first agentic language model.
- **Burmese-Coder** - Burmese coding and technical AI direction.
- Future tools and integrations under the BurmeseGPT ecosystem.

## End-User Install And Use

This section is the user flow only: install, download, run, and test the local API.

Requires Python `>=3.10`.

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install "burmesegpt[full]"
```

If your default `python3` is below 3.10, use an explicit interpreter:

```bash
/opt/homebrew/bin/python3.11 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install "burmesegpt[full]"
```

See `docs/guides/pypi-install-quickstart.md` for the same copy-paste flow.

Package extras remain:

- `burmesegpt[server]` installs the packaged `llama-cpp-python` server runtime.
- `burmesegpt[openai]` installs the OpenAI client integration only.
- `burmesegpt[full]` installs both server and OpenAI extras.
- `burmesegpt[dev]` adds maintainer tooling.

Gemma 4 caveat: the current PyPI `llama-cpp-python` dependency is still fine for the normal packaged Padauk flow, but it should not be treated as sufficient for Gemma 4 serving or release validation. For Gemma 4 shared-KV models, use a standalone `llama.cpp` source build pinned to commit `b8833` for release work, with `b8751` as the minimum supported floor.

## Download Model And Run API

```bash
burmesegpt download --quant q8_0
burmesegpt serve --quant q8_0 --host 127.0.0.1 --port 8000
```

Keep that terminal running while you test requests.

## Test With API Call (curl)

```bash
curl http://127.0.0.1:8000/v1/models
```

```bash
curl http://127.0.0.1:8000/v1/chat/completions \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer sk-no-key-required" \
  -d '{
    "model": "padauk-agent",
    "messages": [{"role": "user", "content": "မင်္ဂလာပါ"}]
  }'
```

## Test With OpenAI Agents SDK

```bash
python -m pip install openai-agents
```

```python
import asyncio

from openai import AsyncOpenAI
from agents import Agent, Runner, set_default_openai_api, set_default_openai_client, set_tracing_disabled

set_tracing_disabled(True)
set_default_openai_api("chat_completions")
set_default_openai_client(
    AsyncOpenAI(base_url="http://127.0.0.1:8000/v1", api_key="sk-no-key-required")
)

padauk = Agent(
    name="Padauk Assistant",
    model="padauk-agent",
    instructions="Reply in Burmese by default.",
)

async def main() -> None:
    result = await Runner.run(padauk, input="မင်္ဂလာပါ")
    print(result.final_output)

asyncio.run(main())
```

## Maintainer Release Validation

Use this maintainer-only flow before any package or GGUF release:

- `docs/guides/pypi-release-guide.md`
- `docs/guides/hf-to-gguf-quantization-guide.md`
- `docs/guides/gemma4-shared-kv-rca.md`

## Links

- Website: [https://www.waiyannyeinnaing.com/](https://www.waiyannyeinnaing.com/)
- Padauk: [https://www.waiyannyeinnaing.com/projects/padauk](https://www.waiyannyeinnaing.com/projects/padauk)
- Source: [https://github.com/WaiYanNyeinNaing/burmese-gpt-pypi-api](https://github.com/WaiYanNyeinNaing/burmese-gpt-pypi-api)
- Hugging Face source repo: [https://huggingface.co/WYNN747/Burmese-GPT-Padauk](https://huggingface.co/WYNN747/Burmese-GPT-Padauk)
- Hugging Face GGUF repo: [https://huggingface.co/WYNN747/padauk-burmese-agentic-llm](https://huggingface.co/WYNN747/padauk-burmese-agentic-llm)
