# PyPI Install Quickstart (User Guide)

Use this guide for a simple end-to-end path: install, download, run, and test.

Maintainers doing release checks should use `docs/guides/pypi-release-guide.md` instead.

The optional extras remain:

- `burmesegpt[server]` installs the packaged `llama-cpp-python` server dependency.
- `burmesegpt[openai]` installs only the OpenAI client integration.
- `burmesegpt[full]` installs both server and OpenAI integrations.
- `burmesegpt[dev]` is for maintainer tooling, not end-user serving.

Gemma 4 caveat: the packaged `llama-cpp-python` dependency is not the documented serving target for Gemma 4 shared-KV models. End users following this guide for the standard Padauk release can keep using the PyPI extras, but Gemma 4 maintainers should follow the standalone `llama.cpp` workflow in `docs/guides/hf-to-gguf-quantization-guide.md`.

## Requirements

- Python `>=3.10`
- Internet access for PyPI and model download

## 1) Install From PyPI

```bash
python3 -m venv .venv
source .venv/bin/activate

python -m pip install --upgrade pip
python -m pip install "burmesegpt[full]"
```

If `python3` is below 3.10:

```bash
/opt/homebrew/bin/python3.11 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install "burmesegpt[full]"
```

## 2) Download Model

```bash
burmesegpt download --quant q8_0
```

## 3) Run Local API Server

```bash
burmesegpt serve --quant q8_0 --host 127.0.0.1 --port 8000
```

This command documents the current packaged Padauk flow. It is not a guarantee that the current PyPI `llama-cpp-python` wheel is sufficient for Gemma 4 shared-KV serving.

## 4) Test API With curl

In another terminal:

```bash
source .venv/bin/activate
curl http://127.0.0.1:8000/v1/models
```

```bash
source .venv/bin/activate
curl http://127.0.0.1:8000/v1/chat/completions \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer sk-no-key-required" \
  -d '{
    "model": "padauk-agent",
    "messages": [{"role": "user", "content": "မင်္ဂလာပါ"}]
  }'
```

## 5) Test With OpenAI Agents SDK

```bash
source .venv/bin/activate
python -m pip install openai-agents
```

```python
import asyncio

from openai import AsyncOpenAI
from agents import Agent, Runner, set_default_openai_api, set_default_openai_client, set_tracing_disabled

set_tracing_disabled(True)
set_default_openai_api("chat_completions")
set_default_openai_client(
    AsyncOpenAI(base_url="http://127.0.0.1:8000/v1", api_key="sk-no-key-required")
)

padauk = Agent(name="Padauk Assistant", model="padauk-agent", instructions="Reply in Burmese by default.")

async def main() -> None:
    result = await Runner.run(padauk, input="မင်္ဂလာပါ")
    print(result.final_output)

asyncio.run(main())
```
