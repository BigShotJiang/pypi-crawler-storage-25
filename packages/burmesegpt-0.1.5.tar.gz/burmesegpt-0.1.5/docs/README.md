# Documentation

This folder collects practical guides for users and maintainers of `burmesegpt`.

## Start Here

- Package overview and quickstart: `../README.md`

## Guides

- `guides/pypi-install-quickstart.md` — Beginner-friendly venv + PyPI install path and troubleshooting.
- `guides/hf-to-gguf-quantization-guide.md` — Convert/export/quantize Padauk from the source HF repo into release GGUF artifacts.
- `guides/pypi-release-guide.md` — Package release flow plus the required GGUF validation gate.
- `guides/gemma4-shared-kv-rca.md` — Root-cause note for the Gemma 4 shared-KV runtime mismatch and the pinned `llama.cpp` policy.

## CLI Entry Points

- `burmesegpt download`
- `burmesegpt validate`
- `burmesegpt serve`
- `burmesegpt run`
- `burmesegpt smoke-test`
- `burmesegpt info`

## Model Metadata

Release validation and runtime checksum files live in:

- `../model/Modelfile`
- `../model/SHA256SUMS.txt`
