from __future__ import annotations

from argparse import Namespace

import pytest

from burmesegpt.agent import resolve_hf_token, wait_for_server
from burmesegpt.cli import (
    EXIT_SMOKE_SDK_MISSING,
    _make_agent,
    build_parser,
    cmd_run,
    cmd_smoke_test,
    cmd_validate,
)


def test_hf_token_precedence(monkeypatch) -> None:
    monkeypatch.setenv("HF_TOKEN", "env-token")
    assert resolve_hf_token("arg-token") == "arg-token"
    assert resolve_hf_token(None) == "env-token"

    monkeypatch.delenv("HF_TOKEN", raising=False)
    assert resolve_hf_token(None) is None


def test_cli_parser_sets_defaults() -> None:
    parser = build_parser()
    args = parser.parse_args(["download"])
    assert args.command == "download"
    assert args.quant == "q8_0"


def test_cli_parser_validate_defaults() -> None:
    parser = build_parser()
    args = parser.parse_args(["validate"])
    assert args.command == "validate"
    assert args.quant == "q8_0"
    assert args.runtime_check is True


def test_cli_parser_accepts_shared_args_before_subcommand() -> None:
    parser = build_parser()
    args = parser.parse_args(
        [
            "--repo-id",
            "acme/model",
            "--revision",
            "v1",
            "--cache-dir",
            "/tmp/burmesegpt-cache",
            "--hf-token",
            "top-token",
            "download",
        ]
    )
    assert args.command == "download"
    assert args.repo_id == "acme/model"
    assert args.revision == "v1"
    assert args.cache_dir == "/tmp/burmesegpt-cache"
    assert args.hf_token == "top-token"


@pytest.mark.parametrize(
    ("command", "command_args"),
    [
        ("download", ["--quant", "q5_k_m"]),
        ("validate", ["--no-runtime-check"]),
        ("serve", ["--port", "8123"]),
        ("run", ["--base-url", "http://127.0.0.1:8000/v1"]),
        ("info", ["--quant", "q8_0"]),
    ],
)
def test_cli_parser_accepts_shared_args_after_subcommand(command: str, command_args: list[str]) -> None:
    parser = build_parser()
    args = parser.parse_args(
        [
            command,
            *command_args,
            "--repo-id",
            "acme/model",
            "--revision",
            "v1",
            "--cache-dir",
            "/tmp/burmesegpt-cache",
            "--hf-token",
            "post-token",
        ]
    )
    assert args.command == command
    assert args.repo_id == "acme/model"
    assert args.revision == "v1"
    assert args.cache_dir == "/tmp/burmesegpt-cache"
    assert args.hf_token == "post-token"


def test_cli_args_flow_into_agent() -> None:
    args = Namespace(
        quant="q5_k_m",
        repo_id="WYNN747/padauk-burmese-agentic-llm",
        revision="main",
        cache_dir="/tmp/burmesegpt-cache",
        hf_token="abc",
    )
    agent = _make_agent(args)
    assert agent.quant == "q5_k_m"
    assert str(agent.cache_dir).endswith("/WYNN747/padauk-burmese-agentic-llm/main")
    assert agent.hf_token == "abc"


def test_cli_parser_smoke_test_defaults() -> None:
    parser = build_parser()
    args = parser.parse_args(["smoke-test"])
    assert args.command == "smoke-test"
    assert args.base_url == "http://127.0.0.1:8000/v1"
    assert args.model == "padauk-agent"
    assert args.client == "http"


def test_cmd_smoke_test_http_success(monkeypatch, capsys) -> None:
    class _FakeResponse:
        def __init__(self, payload: dict) -> None:
            self._payload = payload

        def raise_for_status(self) -> None:
            return

        def json(self) -> dict:
            return self._payload

    calls: dict[str, tuple[str, dict]] = {}

    def fake_get(url: str, **kwargs):
        calls["get"] = (url, kwargs)
        return _FakeResponse({"data": [{"id": "padauk-agent"}]})

    def fake_post(url: str, **kwargs):
        calls["post"] = (url, kwargs)
        return _FakeResponse({"choices": [{"message": {"content": "pong"}}]})

    monkeypatch.setattr("requests.get", fake_get)
    monkeypatch.setattr("requests.post", fake_post)

    args = Namespace(
        base_url="http://127.0.0.1:8000/v1/",
        model="padauk-agent",
        api_key="sk-no-key-required",
        prompt="hello",
        timeout=15.0,
        client="http",
    )

    exit_code = cmd_smoke_test(args)
    assert exit_code == 0

    get_url, get_kwargs = calls["get"]
    post_url, post_kwargs = calls["post"]
    assert get_url == "http://127.0.0.1:8000/v1/models"
    assert post_url == "http://127.0.0.1:8000/v1/chat/completions"
    assert get_kwargs["headers"]["Authorization"] == "Bearer sk-no-key-required"
    assert post_kwargs["json"]["model"] == "padauk-agent"
    assert post_kwargs["json"]["messages"][0]["content"] == "hello"

    captured = capsys.readouterr()
    assert "Models OK: padauk-agent" in captured.out
    assert "Chat completion OK: pong" in captured.out


def test_cmd_smoke_test_openai_missing_sdk(monkeypatch, capsys) -> None:
    def raise_import_error():
        raise ImportError("No module named openai")

    monkeypatch.setattr("burmesegpt.cli._load_openai_client", raise_import_error)

    args = Namespace(
        base_url="http://127.0.0.1:8000/v1",
        model="padauk-agent",
        api_key="sk-no-key-required",
        prompt="hello",
        timeout=15.0,
        client="openai",
    )

    exit_code = cmd_smoke_test(args)
    assert exit_code == EXIT_SMOKE_SDK_MISSING

    captured = capsys.readouterr()
    assert 'pip install "burmesegpt[openai]"' in captured.err


def test_cmd_validate_success(monkeypatch, capsys) -> None:
    calls: dict[str, bool] = {}

    class _FakeAgent:
        def validate_model(self, *, runtime_check: bool):
            calls["runtime_check"] = runtime_check
            return "/tmp/padauk.gguf"

    monkeypatch.setattr("burmesegpt.cli._make_agent", lambda _args: _FakeAgent())

    args = Namespace(runtime_check=True)
    exit_code = cmd_validate(args)
    assert exit_code == 0
    assert calls["runtime_check"] is True

    captured = capsys.readouterr()
    assert "Validation passed (checksum + GGUF header + runtime load): /tmp/padauk.gguf" in captured.out


def test_cmd_validate_reports_runtime_error(monkeypatch, capsys) -> None:
    class _FakeAgent:
        def validate_model(self, *, runtime_check: bool):  # noqa: ARG002
            raise RuntimeError(
                'Runtime validation requires llama-cpp-python. Install with: pip install "burmesegpt[server]".'
            )

    monkeypatch.setattr("burmesegpt.cli._make_agent", lambda _args: _FakeAgent())

    args = Namespace(runtime_check=True)
    exit_code = cmd_validate(args)
    assert exit_code == 1

    captured = capsys.readouterr()
    assert "Validation failed: Runtime validation requires llama-cpp-python." in captured.err


def test_wait_for_server_requires_2xx(monkeypatch) -> None:
    class _Response:
        status_code = 404

    monkeypatch.setattr("requests.get", lambda *_args, **_kwargs: _Response())
    monkeypatch.setattr("burmesegpt.agent.time.sleep", lambda _seconds: None)

    with pytest.raises(TimeoutError):
        wait_for_server("http://127.0.0.1:8000/v1", timeout=0.01)


def test_wait_for_server_accepts_2xx(monkeypatch) -> None:
    class _Response:
        status_code = 204

    monkeypatch.setattr("requests.get", lambda *_args, **_kwargs: _Response())
    wait_for_server("http://127.0.0.1:8000/v1", timeout=0.01)


def test_cmd_run_fails_fast_when_child_exits_early(monkeypatch, capsys) -> None:
    class _FakeProcess:
        def __init__(self) -> None:
            self._returncode = 17

        def poll(self) -> int:
            return self._returncode

        def terminate(self) -> None:
            return

        def wait(self, timeout: float | None = None) -> int:  # noqa: ARG002
            return self._returncode

        def kill(self) -> None:
            return

    class _FakeAgent:
        openai_base_url = "http://127.0.0.1:8000/v1"

        def serve(self, **_kwargs):
            return _FakeProcess()

    monkeypatch.setattr("burmesegpt.cli._make_agent", lambda _args: _FakeAgent())
    monkeypatch.setattr(
        "burmesegpt.cli.wait_for_server",
        lambda *_args, **_kwargs: (_ for _ in ()).throw(AssertionError("should not probe HTTP")),
    )

    args = Namespace(
        base_url=None,
        host="127.0.0.1",
        port=8000,
        model_alias="padauk-agent",
        n_ctx=8192,
        n_gpu_layers=-1,
        api_key="sk-no-key-required",
        startup_timeout=30.0,
        test_mode=False,
        repo_id="WYNN747/padauk-burmese-agentic-llm",
        revision="main",
        cache_dir=None,
        hf_token=None,
        quant="q4_k_m",
    )

    exit_code = cmd_run(args)
    assert exit_code == 1
    captured = capsys.readouterr()
    assert "Failed to start local server" in captured.err
    assert "exit code: 17" in captured.err


@pytest.mark.parametrize("exc_type", [EOFError, KeyboardInterrupt])
def test_cmd_run_exits_cleanly_on_ctrl_signals(monkeypatch, capsys, exc_type) -> None:
    monkeypatch.setattr("builtins.input", lambda _prompt: (_ for _ in ()).throw(exc_type()))
    monkeypatch.setattr(
        "burmesegpt.cli.chat_completion",
        lambda **_kwargs: (_ for _ in ()).throw(AssertionError("chat should not run")),
    )

    args = Namespace(
        base_url="http://127.0.0.1:8000/v1",
        host="127.0.0.1",
        port=8000,
        model_alias="padauk-agent",
        n_ctx=8192,
        n_gpu_layers=-1,
        api_key="sk-no-key-required",
        startup_timeout=30.0,
        test_mode=False,
        repo_id="WYNN747/padauk-burmese-agentic-llm",
        revision="main",
        cache_dir=None,
        hf_token=None,
        quant="q4_k_m",
    )

    exit_code = cmd_run(args)
    assert exit_code == 0
    captured = capsys.readouterr()
    assert "Interactive chat ready. Type '/exit' to stop." in captured.out
