from __future__ import annotations

from pathlib import Path

import pytest

from burmesegpt import padauk_agent
from burmesegpt.agent import GGUFValidationError, HashMismatchError, file_sha256


def test_file_sha256_changes_when_content_changes(tmp_path: Path) -> None:
    model_file = tmp_path / "model.gguf"
    model_file.write_bytes(b"padauk")
    first_hash = file_sha256(model_file)

    model_file.write_bytes(b"padauk-tampered")
    second_hash = file_sha256(model_file)

    assert first_hash != second_hash


def test_ensure_model_rejects_tampered_checksum(monkeypatch, tmp_path: Path) -> None:
    model_filename = "padauk-gemma-q4_k_m.gguf"

    def fake_hf_hub_download(*, filename: str, local_dir: str, **_kwargs):
        path = Path(local_dir) / filename
        path.parent.mkdir(parents=True, exist_ok=True)
        if filename == model_filename:
            path.write_bytes(b"tampered")
            return str(path)
        if filename == "SHA256SUMS.txt":
            path.write_text(
                "0000000000000000000000000000000000000000000000000000000000000000  "
                f"{model_filename}\n",
                encoding="utf-8",
            )
            return str(path)
        raise AssertionError(f"unexpected file requested: {filename}")

    monkeypatch.setattr("burmesegpt.agent.hf_hub_download", fake_hf_hub_download)

    agent = padauk_agent(
        quant="q4_k_m",
        repo_id="WYNN747/padauk-burmese-agentic-llm",
        revision="main",
        cache_dir=tmp_path,
    )
    with pytest.raises(HashMismatchError):
        agent.ensure_model()


def test_validate_model_rejects_bad_gguf_header(monkeypatch, tmp_path: Path) -> None:
    model_path = tmp_path / "bad.gguf"
    model_path.write_bytes(b"NOTG-rest")

    agent = padauk_agent(
        quant="q4_k_m",
        repo_id="WYNN747/padauk-burmese-agentic-llm",
        revision="main",
        cache_dir=tmp_path,
    )
    monkeypatch.setattr(agent, "ensure_model", lambda: model_path)

    with pytest.raises(GGUFValidationError):
        agent.validate_model(runtime_check=False)


def test_validate_model_runtime_load_failure_is_actionable(monkeypatch, tmp_path: Path) -> None:
    model_path = tmp_path / "good.gguf"
    model_path.write_bytes(b"GGUFpayload")

    class _BrokenLlama:
        def __init__(self, **_kwargs):
            raise RuntimeError("missing tensor blk.0.attn_q.weight")

    agent = padauk_agent(
        quant="q4_k_m",
        repo_id="WYNN747/padauk-burmese-agentic-llm",
        revision="main",
        cache_dir=tmp_path,
    )
    monkeypatch.setattr(agent, "ensure_model", lambda: model_path)
    monkeypatch.setattr(agent, "_load_llama_class", lambda: _BrokenLlama)

    with pytest.raises(RuntimeError, match="llama_cpp failed to load"):
        agent.validate_model(runtime_check=True)


def test_validate_model_reports_gemma4_shared_kv_loader_mismatch(monkeypatch, tmp_path: Path) -> None:
    model_path = tmp_path / "good.gguf"
    model_path.write_bytes(b"GGUFpayload")

    class _BrokenLlama:
        def __init__(self, **_kwargs):
            raise RuntimeError("missing tensor 'blk.24.attn_k.weight'")

    agent = padauk_agent(
        quant="q8_0",
        repo_id="WYNN747/padauk-burmese-agentic-llm",
        revision="main",
        cache_dir=tmp_path,
    )
    monkeypatch.setattr(agent, "ensure_model", lambda: model_path)
    monkeypatch.setattr(agent, "_load_llama_class", lambda: _BrokenLlama)
    monkeypatch.setattr(
        "burmesegpt.agent.read_gguf_metadata",
        lambda _path: {
            "general.architecture": "gemma4",
            "gemma4.attention.shared_kv_layers": 18,
        },
    )

    with pytest.raises(RuntimeError, match="standalone llama.cpp >= b8751"):
        agent.validate_model(runtime_check=True)
