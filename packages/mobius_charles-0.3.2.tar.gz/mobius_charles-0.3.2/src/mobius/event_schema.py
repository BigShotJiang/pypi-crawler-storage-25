"""Import-light event-store schema vocabulary."""

from __future__ import annotations

import json
from dataclasses import dataclass

BOOTSTRAP_EVENT_ID = "mobius-bootstrap-v1"
BOOTSTRAP_AGGREGATE_ID = "mobius.bootstrap"
BOOTSTRAP_EVENT_TYPE = "mobius.bootstrap"


@dataclass(frozen=True)
class Migration:
    """A versioned SQLite migration."""

    version: int
    sql: str


MIGRATIONS: tuple[Migration, ...] = (
    Migration(
        version=1,
        sql="""
CREATE TABLE IF NOT EXISTS events (
    event_id TEXT PRIMARY KEY,
    aggregate_id TEXT NOT NULL,
    sequence INTEGER NOT NULL,
    type TEXT NOT NULL,
    payload TEXT NOT NULL CHECK (json_valid(payload)),
    created_at TEXT NOT NULL
);

CREATE UNIQUE INDEX IF NOT EXISTS idx_events_aggregate_sequence
    ON events (aggregate_id, sequence);

CREATE INDEX IF NOT EXISTS idx_events_aggregate_id
    ON events (aggregate_id);

CREATE TABLE IF NOT EXISTS sessions (
    session_id TEXT PRIMARY KEY,
    started_at TEXT NOT NULL,
    ended_at TEXT,
    runtime TEXT NOT NULL,
    metadata TEXT NOT NULL CHECK (json_valid(metadata)),
    status TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS aggregates (
    aggregate_id TEXT PRIMARY KEY,
    type TEXT NOT NULL,
    last_sequence INTEGER NOT NULL,
    snapshot TEXT NOT NULL CHECK (json_valid(snapshot)),
    updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS schema_migrations (
    version INTEGER PRIMARY KEY,
    applied_at TEXT NOT NULL
);
""",
    ),
)

LATEST_SCHEMA_VERSION = max(migration.version for migration in MIGRATIONS)
BOOTSTRAP_SQL = "\n".join(migration.sql for migration in MIGRATIONS)


def bootstrap_payload(schema_version: int = LATEST_SCHEMA_VERSION) -> str:
    """Return the canonical bootstrap event payload."""
    return json.dumps(
        {"schema_version": schema_version},
        sort_keys=True,
        separators=(",", ":"),
    )
