"""Standard interactive interview session."""

from __future__ import annotations

import sys
from pathlib import Path
from typing import IO, Any

from mobius.workflow.interview_parsing import fixture_from_template
from mobius.workflow.interview_prompts import _prompt_choice, _prompt_list, _prompt_scalar
from mobius.workflow.interview_session_helpers import _print_routing_summary
from mobius.workflow.interview_types import (
    InterviewFixture,
    RhythmGuardState,
    RoutingDecision,
    RoutingPath,
    route_with_rhythm,
)
from mobius.workflow.templates import TEMPLATE_NAMES, detect_template, get_template


def run_interactive_interview(
    *,
    workspace: Path,
    template_name: str | None = None,
    project_type: str = "greenfield",
    stdin: IO[str] | None = None,
    stderr: IO[str] | None = None,
) -> InterviewFixture:
    """Drive the user through the interview and return a fixture.

    Prompts go to ``stderr`` (so stdout stays clean); answers come from
    ``stdin``. Empty answers accept the default. The function works the
    same for TTY and scripted stdin — when stdin reaches EOF before all
    questions are answered, remaining defaults are used.
    """
    from mobius.workflow.context_detector import format_detected_facts, scan_workspace_context
    from mobius.workflow.question_router import InterviewQuestion, build_question_envelope

    in_stream = stdin if stdin is not None else sys.stdin
    err = stderr if stderr is not None else sys.stderr

    if template_name is None:
        template_name = detect_template(workspace)
    template = get_template(template_name)
    defaults = fixture_from_template(template, project_type=project_type)

    ctx = scan_workspace_context(workspace)
    detected_lines = format_detected_facts(ctx)

    err.write(f"# Mobius interview — template: {template.name}\n")
    if detected_lines:
        for line in detected_lines:
            err.write(f"  ℹ  {line}\n")
        auto_count = sum(1 for line in detected_lines if line.startswith("Détecté"))
        err.write(f"  ✓  {auto_count} faits auto-confirmés\n\n")
    else:
        err.write(f"# {template.description}\n")
        err.write("# Press Enter to accept the [default] in brackets.\n\n")
    err.flush()

    rhythm = RhythmGuardState()

    q_project_type = InterviewQuestion(key="project_type", category="context")
    routing_decisions: list[tuple[str, RoutingDecision]] = []
    question_envelopes: list[Any] = []
    decision_pt = route_with_rhythm(q_project_type, ctx, rhythm)
    routing_decisions.append((q_project_type.key, decision_pt))
    question_envelopes.append(build_question_envelope(q_project_type, decision_pt, ctx))
    rhythm.record(decision_pt.path)

    if decision_pt.path == RoutingPath.AUTO_CONFIRM:
        project_type_answer = ctx.get_answer("project_type")
        err.write(f"  ✓  Type de projet: {project_type_answer} (auto-confirmé)\n")
        err.flush()
    else:
        project_type_answer = _prompt_choice(
            err,
            in_stream,
            "Type de projet [greenfield/brownfield]",
            default=ctx.get_answer("project_type")
            if ctx.has_answer("project_type")
            else defaults.project_type,
            choices=("greenfield", "brownfield"),
        )

    q_template = InterviewQuestion(key="template", category="context")
    decision_tpl = route_with_rhythm(q_template, ctx, rhythm)
    routing_decisions.append((q_template.key, decision_tpl))
    question_envelopes.append(build_question_envelope(q_template, decision_tpl, ctx))
    rhythm.record(decision_tpl.path)

    if decision_tpl.path == RoutingPath.AUTO_CONFIRM:
        template_name = ctx.get_answer("template") or detect_template(workspace)
        err.write(f"  ✓  Template: {template_name} (auto-confirmé)\n")
        err.flush()
    elif decision_tpl.path == RoutingPath.CODE_CONFIRM:
        suggested = ctx.get_answer("template") or detect_template(workspace)
        confirmed = _prompt_choice(
            err,
            in_stream,
            f"Template détecté: {suggested} — correct ?",
            default="oui",
            choices=("oui", "non"),
        )
        template_name = (
            suggested
            if confirmed == "oui"
            else _prompt_choice(err, in_stream, "Template", default="blank", choices=TEMPLATE_NAMES)
        )
    else:
        template_name = template_name or detect_template(workspace)

    template = get_template(template_name)
    defaults = fixture_from_template(template, project_type=project_type_answer)

    goal_answer = _prompt_scalar(
        err, in_stream, "Objectif — que doit livrer ce projet ?", default=defaults.goal
    )
    goal_decision = RoutingDecision(
        path=RoutingPath.HUMAN_JUDGMENT,
        rationale="Objectif et résultat attendu exigent un jugement humain.",
    )
    q_goal = InterviewQuestion(key="goal", category="vision", label="Objectif")
    routing_decisions.append((q_goal.key, goal_decision))
    question_envelopes.append(build_question_envelope(q_goal, goal_decision, ctx))
    rhythm.record(RoutingPath.HUMAN_JUDGMENT)
    constraints_answer = _prompt_list(
        err,
        in_stream,
        "Contraintes (une par ligne, ligne vide pour finir)",
        defaults=defaults.constraints,
    )
    success_answer = _prompt_list(
        err,
        in_stream,
        "Critères de succès (un par ligne, ligne vide pour finir)",
        defaults=defaults.success,
    )
    context_answer = ""
    if project_type_answer == "brownfield":
        auto_context = ""
        try:
            from mobius.workflow.scan import context_from_workspace

            auto_context = context_from_workspace(workspace)
        except Exception:
            pass
        context_default = (
            defaults.context
            or auto_context
            or "Existing system in place; preserve current behavior."
        )
        context_answer = _prompt_scalar(
            err,
            in_stream,
            "Contexte existant à préserver",
            default=context_default,
        )

    _print_routing_summary(err, rhythm)

    return InterviewFixture(
        project_type=project_type_answer,
        goal=goal_answer,
        constraints=constraints_answer,
        success=success_answer,
        context=context_answer,
        template=template.name,
    )
