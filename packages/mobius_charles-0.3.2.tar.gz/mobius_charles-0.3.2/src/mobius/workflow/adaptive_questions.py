"""Adaptive follow-up question selection for deep interviews."""

from __future__ import annotations

from dataclasses import dataclass

from mobius.workflow.interview import AmbiguityScore, InterviewClarityContract, InterviewFixture
from mobius.workflow.interview_memory import ConversationMemory


@dataclass(frozen=True)
class AdaptiveQuestion:
    """A deterministic next question with auditable routing rationale."""

    key: str
    prompt: str
    because: str
    branch: str = "clarification"
    recommendation: str = ""
    lentilles: dict[str, str] | None = None


def next_question(
    *,
    fixture: InterviewFixture,
    score: AmbiguityScore,
    contract: InterviewClarityContract,
    memory: ConversationMemory,
) -> AdaptiveQuestion:
    """Choose the next targeted follow-up from contract blockers and ambiguity.

    The question is intentionally interrogatoire-inspired: one decision branch at
    a time, with Mobius' recommendation embedded before asking the user.
    """
    posees = memory.covered_keys()
    blocages = set(contract.closure_blockers)
    lentilles = evaluer_lentilles(fixture=fixture, score=score, contract=contract)

    question_pont = _question_pont_si_tunnel(memory)
    if question_pont is not None:
        return _avec_lentilles(question_pont, lentilles)

    ordonnees: list[AdaptiveQuestion] = []
    weakest = _weakest_dimension(score)
    if not score.seed_ready:
        weakest_question = _question_for_weakest_dimension(weakest)
        if weakest_question is not None:
            ordonnees.append(weakest_question)

    if "missing_non_goals" in blocages:
        ordonnees.append(
            _interrogation_question(
                key="non_goals",
                branch="périmètre",
                question="Concrètement, qu'est-ce que cette première version ne fera pas ?",
                recommendation=(
                    "Je recommande de verrouiller au moins une limite qui protège le premier "
                    "livrable, parce que sans non-objectif le projet grossit sans fin."
                ),
                because="missing_non_goals",
            )
        )
    if "missing_decision_boundaries" in blocages:
        ordonnees.append(
            _interrogation_question(
                key="decision_boundaries",
                branch="décisions humaines",
                question="Quelle décision doit obligatoirement revenir à l'humain avant seed/run ?",
                recommendation=(
                    "Je recommande de nommer la décision la plus risquée à ne jamais "
                    "automatiser, parce que Mobius doit savoir où s'arrêter."
                ),
                because="missing_decision_boundaries",
            )
        )
    if "success_criteria_not_testable" in blocages:
        ordonnees.append(
            _interrogation_question(
                key="success",
                branch="preuve de réussite",
                question="Quelle preuve observable dira que le résultat est réussi ?",
                recommendation=(
                    "Je recommande une preuve vérifiable par test, fichier ou sortie CLI, "
                    "parce qu'un ressenti seul ne suffit pas pour lancer seed."
                ),
                because="success_criteria_not_testable",
            )
        )
    ordonnees.extend(_questions_depuis_lentilles(lentilles, blocages))

    if score.seed_ready:
        weakest_question = _question_for_weakest_dimension(weakest)
        if weakest_question is not None:
            ordonnees.append(weakest_question)

    ordonnees.extend(
        [
            _interrogation_question(
                "assumptions",
                "hypothèses",
                "Quelle hypothèse risquée doit être testée en premier ?",
                "Je recommande de choisir l'hypothèse qui tuerait le projet si elle était fausse.",
                "pressure:assumption",
            ),
            _interrogation_question(
                "premortem",
                "pré-mortem",
                "Dans un an, pourquoi ce projet aurait-il échoué ?",
                "Je recommande de chercher l'échec le plus banal, pas le scénario spectaculaire.",
                "pressure:premortem",
            ),
        ]
    )
    for candidate in ordonnees:
        if candidate.key not in posees:
            return _avec_lentilles(candidate, lentilles)
    return _avec_lentilles(ordonnees[0], lentilles)


def _questions_depuis_lentilles(
    lentilles: dict[str, str],
    blocages: set[str],
) -> list[AdaptiveQuestion]:
    """Transforme les trois lentilles en priorités de relance."""
    questions: list[AdaptiveQuestion] = []
    if lentilles.get("risques") == "ouverts":
        if "missing_non_goals" in blocages:
            questions.append(
                _interrogation_question(
                    key="non_goals",
                    branch="périmètre",
                    question=(
                        "Concrètement, qu'est-ce que cette première version ne fera pas "
                        "pour fermer le risque de dérive le plus probable ?"
                    ),
                    recommendation=(
                        "Je recommande de fermer le risque par une limite explicite, parce que "
                        "un risque ouvert devient souvent une décision implicite."
                    ),
                    because="missing_non_goals",
                )
            )
        if "missing_decision_boundaries" in blocages:
            questions.append(
                _interrogation_question(
                    key="decision_boundaries",
                    branch="décisions humaines",
                    question="Quelle décision humaine bloque une automatisation dangereuse ?",
                    recommendation=(
                        "Je recommande d'identifier la décision humaine la plus sensible, "
                        "parce que Mobius doit connaître sa limite d'autorité."
                    ),
                    because="lentille:risques:missing_decision_boundaries",
                )
            )
    if lentilles.get("faisabilité") == "fragile":
        questions.append(
            _interrogation_question(
                key="success",
                branch="preuve de réussite",
                question="Quelle preuve minimale rend ce livrable vérifiable ?",
                recommendation=(
                    "Je recommande de transformer la faisabilité en preuve observable, "
                    "parce qu'un plan non testable ne peut pas passer seed/run."
                ),
                because="lentille:faisabilité",
            )
        )
    if lentilles.get("clarté") == "ouverte":
        questions.append(
            _interrogation_question(
                key="goal",
                branch="objectif",
                question="Quelle phrase unique rend l'objectif lisible et testable ?",
                recommendation=(
                    "Je recommande de resserrer l'objectif avant les détails, parce que "
                    "les contraintes et preuves dépendent du but réel."
                ),
                because="lentille:clarté",
            )
        )
    return questions


def evaluer_lentilles(
    *,
    fixture: InterviewFixture,
    score: AmbiguityScore,
    contract: InterviewClarityContract,
) -> dict[str, str]:
    """Évalue Clarté/Risques/Faisabilité sans appel LLM."""
    clarte = "ouverte" if not score.seed_ready else "stable"
    risques = "ouverts" if contract.closure_blockers else "bornés"
    faisabilite = "fragile"
    if (
        fixture.constraints
        and fixture.success
        and "success_criteria_not_testable" not in contract.closure_blockers
    ):
        faisabilite = "testable"
    return {
        "clarté": clarte,
        "risques": risques,
        "faisabilité": faisabilite,
    }


def _question_pont_si_tunnel(memory: ConversationMemory) -> AdaptiveQuestion | None:
    """Déclenche une question-pont après deux tours sur le même axe."""
    if len(memory.rounds) < 2:
        return None
    derniers = memory.rounds[-2:]
    axes = [_axe_depuis_tour(tour.question_key, tour.branch) for tour in derniers]
    if axes[0] != axes[1]:
        return None
    axe = axes[0]
    if axe == "preuve":
        return _interrogation_question(
            "constraints",
            "question-pont",
            "Quelle contrainte pourrait empêcher cette preuve de rester vraie en production ?",
            "Je recommande de relier la preuve à une limite concrète pour éviter la vision tunnel.",
            "breadth_keeper:preuve->contraintes",
        )
    if axe == "contraintes":
        return _interrogation_question(
            "success",
            "question-pont",
            "Quelle preuve montrera que ces contraintes sont respectées ?",
            "Je recommande de transformer la contrainte dominante en vérification observable.",
            "breadth_keeper:contraintes->preuve",
        )
    return _interrogation_question(
        "success",
        "question-pont",
        "Quelle preuve observable relie cet objectif au premier livrable ?",
        "Je recommande de quitter l'objectif pur et de demander une preuve.",
        f"breadth_keeper:{axe}->preuve",
    )


def _axe_depuis_tour(cle: str, branche: str) -> str:
    valeur = f"{cle} {branche}".lower()
    if any(mot in valeur for mot in ("success", "preuve", "verification")):
        return "preuve"
    if any(mot in valeur for mot in ("constraint", "contrainte", "boundary", "décision")):
        return "contraintes"
    if any(mot in valeur for mot in ("non_goal", "périmètre", "scope")):
        return "périmètre"
    return "objectif"


def _avec_lentilles(question: AdaptiveQuestion, lentilles: dict[str, str]) -> AdaptiveQuestion:
    return AdaptiveQuestion(
        key=question.key,
        prompt=question.prompt,
        because=question.because,
        branch=question.branch,
        recommendation=question.recommendation,
        lentilles=lentilles,
    )


def _interrogation_question(
    key: str,
    branch: str,
    question: str,
    recommendation: str,
    because: str,
) -> AdaptiveQuestion:
    return AdaptiveQuestion(
        key=key,
        branch=branch,
        recommendation=recommendation,
        prompt=f"{recommendation} {question}",
        because=because,
    )


def _weakest_dimension(score: AmbiguityScore) -> str | None:
    if not score.components:
        return None
    failing = [key for key, ok in score.floor_details.items() if not ok]
    candidates = failing or list(score.components)
    return max(candidates, key=lambda key: score.components.get(key, 0.0))


def _question_for_weakest_dimension(weakest: str | None) -> AdaptiveQuestion | None:
    if weakest == "goal":
        return _interrogation_question(
            key="goal",
            branch="objectif",
            question="Formulez l'objectif final en une phrase testable.",
            recommendation=(
                "Je recommande une phrase avec utilisateur, action et résultat vérifiable, "
                "parce qu'un objectif vague contamine toutes les décisions suivantes."
            ),
            because="weakest_dimension:goal",
        )
    if weakest == "constraints":
        return _interrogation_question(
            key="constraints",
            branch="contraintes",
            question="Quelles limites absolues ne peut-on pas franchir ?",
            recommendation=(
                "Je recommande de séparer les vraies limites des préférences, parce que "
                "Mobius doit savoir ce qui bloque vraiment."
            ),
            because="weakest_dimension:constraints",
        )
    if weakest == "success":
        return _interrogation_question(
            key="success",
            branch="preuve de réussite",
            question="Quel test ou sortie prouvera que c'est terminé ?",
            recommendation=(
                "Je recommande une preuve observable et répétable, parce que seed/run ne "
                "peuvent pas valider une intention."
            ),
            because="weakest_dimension:success",
        )
    if weakest == "context":
        return _interrogation_question(
            key="context",
            branch="existant à préserver",
            question="Quel comportement existant doit absolument rester inchangé ?",
            recommendation=(
                "Je recommande de citer le comportement visible à préserver, parce que le "
                "code peut changer sans que l'expérience utilisateur régresse."
            ),
            because="weakest_dimension:context",
        )
    return None
