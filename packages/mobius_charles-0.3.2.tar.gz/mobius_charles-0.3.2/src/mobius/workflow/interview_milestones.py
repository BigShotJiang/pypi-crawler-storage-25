"""Milestones nommés pour la progression d'interview."""

from __future__ import annotations

from enum import Enum

from mobius.workflow.interview_types import AmbiguityScore


class InterviewMilestone(Enum):
    """Étape nommée de la progression d'interview."""

    DISCOVERY = "DÉCOUVERTE"
    EMERGING = "ÉMERGENCE"
    CONVERGING = "CONVERGENCE"
    CLOSURE_MODE = "FERMETURE"
    SEED_READY = "SEED PRÊT"


def milestone_from_score(score: AmbiguityScore) -> InterviewMilestone:
    """Détermine le milestone à partir du score d'ambiguïté et du statut seed_ready."""
    s = score.score
    if s > 0.6:
        return InterviewMilestone.DISCOVERY
    if s > 0.4:
        return InterviewMilestone.EMERGING
    if s >= 0.2:
        return InterviewMilestone.CONVERGING
    if score.seed_ready:
        return InterviewMilestone.SEED_READY
    return InterviewMilestone.CLOSURE_MODE


_BAR_FILL: dict[InterviewMilestone, int] = {
    InterviewMilestone.DISCOVERY: 1,
    InterviewMilestone.EMERGING: 2,
    InterviewMilestone.CONVERGING: 3,
    InterviewMilestone.CLOSURE_MODE: 4,
    InterviewMilestone.SEED_READY: 5,
}


def milestone_progress_bar(milestone: InterviewMilestone) -> str:
    """Barre de progression ASCII pour un milestone donné."""
    fill = _BAR_FILL[milestone]
    bar = "█" * fill + "░" * (5 - fill)
    return f"[{bar}] {milestone.value}"
