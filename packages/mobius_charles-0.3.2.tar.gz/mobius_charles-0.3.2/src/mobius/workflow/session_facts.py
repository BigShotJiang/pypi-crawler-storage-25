"""Shared session fact readers for workflow projections."""

from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from mobius.persistence.event_store import EventRecord, EventStore


@dataclass(frozen=True)
class SessionFacts:
    """Decoded session row facts used by workflow projections."""

    session_id: str
    runtime: str
    status: str
    metadata: dict[str, Any]


def decode_json_object(raw: str) -> dict[str, Any]:
    """Decode ``raw`` as a JSON object, returning an empty object on malformed input."""
    try:
        parsed = json.loads(raw)
    except json.JSONDecodeError:
        return {}
    return dict(parsed) if isinstance(parsed, dict) else {}


def read_session_facts(store: EventStore, session_id: str) -> SessionFacts | None:
    """Read one decoded session, if present."""
    row = store.connection.execute(
        """
        SELECT session_id, runtime, status, metadata
        FROM sessions
        WHERE session_id = ?
        """,
        (session_id,),
    ).fetchone()
    if row is None:
        return None
    return _facts_from_row(row)


def read_all_session_facts(store: EventStore) -> dict[str, SessionFacts]:
    """Read all decoded sessions keyed by session id."""
    rows = store.connection.execute(
        """
        SELECT session_id, runtime, status, metadata
        FROM sessions
        ORDER BY started_at ASC, session_id ASC
        """
    ).fetchall()
    return {facts.session_id: facts for facts in (_facts_from_row(row) for row in rows)}


def spec_path_from_session(session: SessionFacts) -> Path | None:
    """Return the expanded spec path recorded in session metadata."""
    raw_path = session.metadata.get("spec_path")
    if not isinstance(raw_path, str) or not raw_path:
        return None
    return Path(raw_path).expanduser()


def spec_path_from_events(events: list[EventRecord]) -> Path | None:
    """Return the newest expanded spec path recorded in run.started events."""
    for event in reversed(events):
        if event.type != "run.started":
            continue
        payload = decode_json_object(event.payload)
        raw_path = payload.get("spec_path")
        if isinstance(raw_path, str) and raw_path:
            return Path(raw_path).expanduser()
    return None


def parent_id_from_metadata(metadata: dict[str, Any]) -> str | None:
    """Return the first supported parent id from decoded metadata."""
    for key in ("source_run_id", "source_id", "parent_id", "from_id"):
        value = metadata.get(key)
        if isinstance(value, str) and value:
            return value
    return None


def phase_for_session(runtime: str, metadata: dict[str, Any]) -> str:
    """Return the lineage phase for a runtime plus decoded metadata."""
    for key in ("double_diamond_phase", "phase"):
        value = metadata.get(key)
        if isinstance(value, str) and value:
            return value
    return {
        "interview": "discover",
        "seed": "define",
        "run": "deliver",
        "evolution": "evolve",
    }.get(runtime, "unknown")


def _facts_from_row(row: Any) -> SessionFacts:
    return SessionFacts(
        session_id=str(row["session_id"]),
        runtime=str(row["runtime"]),
        status=str(row["status"]),
        metadata=decode_json_object(str(row["metadata"])),
    )
