"""Lineage projection and replay hashing for Mobius aggregates."""

from __future__ import annotations

from pathlib import Path
from typing import Any

from pydantic import BaseModel, ConfigDict

from mobius.persistence.event_store import EventStore
from mobius.workflow.session_facts import (
    SessionFacts,
    decode_json_object,
    parent_id_from_metadata,
    phase_for_session,
    read_all_session_facts,
)


class LineageNode(BaseModel):
    """One aggregate in a lineage projection."""

    model_config = ConfigDict(extra="forbid")

    aggregate_id: str
    runtime: str
    status: str
    phase: str
    depth: int
    parent_id: str | None = None


class LineageOutput(BaseModel):
    """Structured lineage output for one aggregate."""

    model_config = ConfigDict(extra="forbid")

    aggregate_id: str
    current: LineageNode
    ancestors: list[LineageNode]
    descendants: list[LineageNode]


def build_lineage(event_store_path: Path, aggregate_id: str) -> LineageOutput | None:
    """Build ancestors and descendants for ``aggregate_id`` from session metadata."""
    with EventStore(event_store_path) as store:
        sessions = _read_sessions(store)
    current = sessions.get(aggregate_id)
    if current is None:
        return None

    ancestors = _build_ancestors(sessions, aggregate_id)
    descendants = _build_descendants(sessions, aggregate_id)
    return LineageOutput(
        aggregate_id=aggregate_id,
        current=_to_node(current, depth=0),
        ancestors=ancestors,
        descendants=descendants,
    )


def replay_hash_for_aggregate(event_store_path: Path, aggregate_id: str) -> str | None:
    """Return a deterministic replay hash for an existing aggregate, or None."""
    with EventStore(event_store_path) as store:
        session = _read_session(store, aggregate_id)
        events = store.read_events(aggregate_id)
        if session is None and not events:
            return None
        return store.replay_hash(aggregate_id)


def _read_sessions(store: EventStore) -> dict[str, SessionFacts]:
    sessions = dict(read_all_session_facts(store))
    inferred = _infer_parent_links(sessions)
    if not inferred:
        return sessions
    return {
        session_id: (
            SessionFacts(
                session_id=session.session_id,
                runtime=session.runtime,
                status=session.status,
                metadata={**session.metadata, "parent_id": inferred[session_id]},
            )
            if session_id in inferred
            else session
        )
        for session_id, session in sessions.items()
    }


def _infer_parent_links(sessions: dict[str, SessionFacts]) -> dict[str, str]:
    seed_by_spec: dict[str, SessionFacts] = {}
    interview_by_spec: dict[str, SessionFacts] = {}
    inferred: dict[str, str] = {}
    for session in sessions.values():
        if _parent_id(session) is not None:
            continue
        spec_path = _spec_path(session)
        if session.runtime == "interview":
            output_path = _output_path(session)
            if output_path:
                interview_by_spec[output_path] = session
        elif session.runtime == "seed" and spec_path:
            seed_by_spec[spec_path] = session
            source_session_id = session.metadata.get("source_session_id")
            if isinstance(source_session_id, str) and source_session_id in sessions:
                inferred[session.session_id] = source_session_id
    for session in sessions.values():
        if _parent_id(session) is not None or session.session_id in inferred:
            continue
        spec_path = _spec_path(session)
        if session.runtime == "seed" and spec_path and spec_path in interview_by_spec:
            inferred[session.session_id] = interview_by_spec[spec_path].session_id
        elif session.runtime == "run" and spec_path and spec_path in seed_by_spec:
            inferred[session.session_id] = seed_by_spec[spec_path].session_id
    return inferred


def _spec_path(session: SessionFacts) -> str:
    value = session.metadata.get("spec_path")
    return str(Path(value).expanduser().resolve()) if isinstance(value, str) and value else ""


def _output_path(session: SessionFacts) -> str:
    value = session.metadata.get("output")
    return str(Path(value).expanduser().resolve()) if isinstance(value, str) and value else ""


def _read_session(store: EventStore, aggregate_id: str) -> Any | None:
    return store.connection.execute(
        "SELECT session_id FROM sessions WHERE session_id = ?",
        (aggregate_id,),
    ).fetchone()


def _build_ancestors(
    sessions: dict[str, SessionFacts],
    aggregate_id: str,
) -> list[LineageNode]:
    ancestors_from_parent: list[LineageNode] = []
    seen = {aggregate_id}
    parent_id = _parent_id(sessions[aggregate_id])
    depth = -1
    while parent_id is not None and parent_id not in seen:
        parent = sessions.get(parent_id)
        if parent is None:
            break
        seen.add(parent_id)
        ancestors_from_parent.append(_to_node(parent, depth=depth))
        parent_id = _parent_id(parent)
        depth -= 1
    return list(reversed(ancestors_from_parent))


def _build_descendants(
    sessions: dict[str, SessionFacts],
    aggregate_id: str,
) -> list[LineageNode]:
    children_by_parent: dict[str, list[SessionFacts]] = {}
    for session in sessions.values():
        parent_id = _parent_id(session)
        if parent_id is not None:
            children_by_parent.setdefault(parent_id, []).append(session)

    descendants: list[LineageNode] = []
    seen = {aggregate_id}

    def visit(parent_id: str, depth: int) -> None:
        for child in children_by_parent.get(parent_id, []):
            child_id = child.session_id
            if child_id in seen:
                continue
            seen.add(child_id)
            descendants.append(_to_node(child, depth=depth))
            visit(child_id, depth + 1)

    visit(aggregate_id, 1)
    return descendants


def _to_node(session: SessionFacts, *, depth: int) -> LineageNode:
    return LineageNode(
        aggregate_id=session.session_id,
        runtime=session.runtime,
        status=session.status,
        phase=phase_for_session(session.runtime, session.metadata),
        depth=depth,
        parent_id=_parent_id(session),
    )


def _parent_id(session: SessionFacts | dict[str, Any]) -> str | None:
    if isinstance(session, SessionFacts):
        return parent_id_from_metadata(session.metadata)
    metadata = session.get("metadata")
    return parent_id_from_metadata(metadata) if isinstance(metadata, dict) else None


_decode_metadata = decode_json_object
_phase_for_session = phase_for_session
