"""Read-only Mobius decision core."""

from __future__ import annotations

import json
import shlex
import sqlite3
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from pydantic import BaseModel, ConfigDict

from mobius.config import MobiusPaths
from mobius.persistence.event_store import EventRecord, EventStore


class DecisionEvidence(BaseModel):
    """One local fact used by the decision engine."""

    model_config = ConfigDict(extra="forbid")

    source: str
    detail: str


class MobiusDecision(BaseModel):
    """Public decision payload for ``mobius think``."""

    model_config = ConfigDict(extra="forbid")

    state: str
    blocker: str
    confidence: str
    next_action: str
    command: str
    evidence: list[DecisionEvidence]


@dataclass(frozen=True)
class _SessionRow:
    session_id: str
    runtime: str
    status: str
    metadata: dict[str, Any]
    started_at: str


type _RunSelection = _SessionRow | list[str] | None


def decide_next_action(
    *,
    paths: MobiusPaths,
    workspace: Path,
    run_id: str | None = None,
) -> MobiusDecision:
    """Return Mobius' next recommended local action without mutating state."""
    spec_path = workspace / "spec.yaml"
    evidence: list[DecisionEvidence] = []
    if spec_path.exists():
        evidence.append(_evidence("workspace", f"spec found: {spec_path}"))

    if not paths.event_store.exists():
        if spec_path.exists():
            return _decision(
                state="spec_ready",
                blocker="La spec existe mais aucun event store Mobius n'a encore été créé.",
                confidence="high",
                next_action="Créer une session seed validée.",
                command=f"mobius seed {_quote(spec_path)} --validate",
                evidence=evidence,
            )
        return _decision(
            state="empty_workspace",
            blocker="Aucune spec Mobius ni event store local détecté.",
            confidence="medium",
            next_action="Démarrer une spec Mobius.",
            command='mobius build "<intent>"',
            evidence=evidence,
        )

    try:
        with EventStore(paths.event_store, read_only=True) as store:
            return _decide_from_store(store, spec_path=spec_path, run_id=run_id, evidence=evidence)
    except (RuntimeError, sqlite3.Error, OSError) as exc:
        evidence.append(_evidence("event_store", f"read failed: {exc}"))
        return _decision(
            state="environment_problem",
            blocker="Mobius ne peut pas lire l'event store local.",
            confidence="high",
            next_action="Diagnostiquer l'environnement Mobius.",
            command="mobius doctor",
            evidence=evidence,
        )


def _decide_from_store(
    store: EventStore,
    *,
    spec_path: Path,
    run_id: str | None,
    evidence: list[DecisionEvidence],
) -> MobiusDecision:
    selected_run = _select_run(store, run_id)
    latest_seed = _latest_session(store, runtime="seed")

    if isinstance(selected_run, list):
        candidates = ", ".join(selected_run)
        evidence.append(
            _evidence("sessions", f"ambiguous run prefix: {run_id}; candidates: {candidates}")
        )
        return _decision(
            state="ambiguous_run",
            blocker="Le préfixe de run correspond à plusieurs runs.",
            confidence="high",
            next_action="Relancer la décision avec un run id complet.",
            command="mobius runs ls",
            evidence=evidence,
        )

    if selected_run is None:
        if run_id:
            evidence.append(_evidence("sessions", f"run not found: {run_id}"))
            return _decision(
                state="unknown_run",
                blocker="Le run demandé est introuvable.",
                confidence="high",
                next_action="Lister les runs Mobius disponibles.",
                command="mobius runs ls",
                evidence=evidence,
            )
        if latest_seed is not None:
            seed_spec = _resolve_workspace_path(
                _spec_path_from_session(latest_seed) or spec_path,
                workspace=spec_path.parent,
            )
            evidence.append(_evidence("sessions", f"latest seed: {latest_seed.session_id}"))
            if not seed_spec.exists():
                evidence.append(_evidence("spec", f"missing seed spec: {seed_spec}"))
                return _decision(
                    state="spec_missing",
                    blocker="La dernière seed pointe vers une spec introuvable.",
                    confidence="high",
                    next_action=(
                        "Retrouver la spec ou recréer une seed depuis le workspace courant."
                    ),
                    command="mobius runs ls --all",
                    evidence=evidence,
                )
            return _decision(
                state="seed_ready",
                blocker="Une seed existe mais aucun run n'est enregistré.",
                confidence="high",
                next_action="Lancer un run depuis la spec.",
                command=f"mobius run --spec {_quote(seed_spec)}",
                evidence=evidence,
            )
        if spec_path.exists():
            return _decision(
                state="spec_ready",
                blocker="La spec existe mais aucune session seed n'est enregistrée.",
                confidence="high",
                next_action="Créer une session seed validée.",
                command=f"mobius seed {_quote(spec_path)} --validate",
                evidence=evidence,
            )
        return _decision(
            state="empty_workspace",
            blocker="Aucune spec Mobius ni run local détecté.",
            confidence="medium",
            next_action="Démarrer une spec Mobius.",
            command='mobius build "<intent>"',
            evidence=evidence,
        )

    evidence.append(_evidence("sessions", f"selected run: {selected_run.session_id}"))
    run_events = store.read_events(selected_run.session_id)
    qa_event = _latest_event(run_events, "qa.completed")

    if selected_run.status not in {"completed", "failed", "crashed", "cancelled", "interrupted"}:
        return _decision(
            state="run_active",
            blocker="Un run est encore actif ou non terminal.",
            confidence="high",
            next_action="Suivre le run jusqu'à son état terminal.",
            command=f"mobius status {selected_run.session_id} --follow",
            evidence=evidence,
        )

    if qa_event is None:
        return _decision(
            state="run_without_qa",
            blocker="Le run est terminé mais aucun verdict QA n'est enregistré.",
            confidence="high",
            next_action="Évaluer le run avec QA local.",
            command=f"mobius qa {selected_run.session_id}",
            evidence=evidence,
        )

    summary = _dict(qa_event.payload_data.get("summary"))
    verdict = str(summary.get("global_verdict", "")).lower()
    evidence.append(_evidence("qa", f"global verdict: {verdict or 'unknown'}"))
    if verdict == "pass":
        return _decision(
            state="qa_passed",
            blocker="Aucun blocage QA détecté.",
            confidence="high",
            next_action="Attribuer le grade runtime et préparer le handoff.",
            command="mobius grade",
            evidence=evidence,
        )

    return _decision(
        state="qa_blocked",
        blocker="Le dernier verdict QA n'est pas vert.",
        confidence="high" if verdict else "medium",
        next_action="Lancer une évolution contrôlée depuis le run.",
        command=f"mobius evolve --from {selected_run.session_id} --foreground",
        evidence=evidence,
    )


def _select_run(store: EventStore, run_id: str | None) -> _RunSelection:
    if run_id is not None:
        return _session_by_id_or_prefix(store, run_id)
    return _latest_session(store, runtime="run")


def _latest_session(store: EventStore, *, runtime: str) -> _SessionRow | None:
    row = store.connection.execute(
        """
        SELECT session_id, runtime, status, metadata, started_at
        FROM sessions
        WHERE runtime = ?
        ORDER BY started_at DESC
        LIMIT 1
        """,
        (runtime,),
    ).fetchone()
    return _row_to_session(row) if row is not None else None


def _session_by_id_or_prefix(store: EventStore, value: str) -> _RunSelection:
    exact = store.connection.execute(
        """
        SELECT session_id, runtime, status, metadata, started_at
        FROM sessions
        WHERE runtime = 'run' AND session_id = ?
        """,
        (value,),
    ).fetchone()
    if exact is not None:
        return _row_to_session(exact)
    rows = store.connection.execute(
        """
        SELECT session_id, runtime, status, metadata, started_at
        FROM sessions
        WHERE runtime = 'run' AND session_id LIKE ? ESCAPE '\\'
        ORDER BY started_at DESC
        """,
        (f"{_escape_like(value)}%",),
    ).fetchall()
    if len(rows) == 1:
        return _row_to_session(rows[0])
    if len(rows) > 1:
        return [str(row["session_id"]) for row in rows]
    return None


def _row_to_session(row: Any) -> _SessionRow:
    return _SessionRow(
        session_id=str(row["session_id"]),
        runtime=str(row["runtime"]),
        status=str(row["status"]),
        metadata=_dict(json.loads(str(row["metadata"] or "{}"))),
        started_at=str(row["started_at"]),
    )


def _latest_event(events: list[EventRecord], event_type: str) -> EventRecord | None:
    for event in reversed(events):
        if event.type == event_type:
            return event
    return None


def _spec_path_from_events(events: list[EventRecord]) -> Path | None:
    for event in reversed(events):
        payload = event.payload_data
        if isinstance(payload, dict) and isinstance(payload.get("spec_path"), str):
            return Path(payload["spec_path"])
    return None


def _spec_path_from_session(session: _SessionRow) -> Path | None:
    spec_path = session.metadata.get("spec_path")
    return Path(spec_path) if isinstance(spec_path, str) and spec_path else None


def _resolve_workspace_path(path: Path, *, workspace: Path) -> Path:
    if path.is_absolute():
        return path
    return workspace / path


def _dict(value: object) -> dict[str, Any]:
    return value if isinstance(value, dict) else {}


def _evidence(source: str, detail: str) -> DecisionEvidence:
    return DecisionEvidence(source=source, detail=detail)


def _decision(
    *,
    state: str,
    blocker: str,
    confidence: str,
    next_action: str,
    command: str,
    evidence: list[DecisionEvidence],
) -> MobiusDecision:
    return MobiusDecision(
        state=state,
        blocker=blocker,
        confidence=confidence,
        next_action=next_action,
        command=command,
        evidence=evidence,
    )


def _escape_like(value: str) -> str:
    return value.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")


def _quote(path: Path) -> str:
    return shlex.quote(str(path))
