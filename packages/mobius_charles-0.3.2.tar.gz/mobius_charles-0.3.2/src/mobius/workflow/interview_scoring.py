"""Interview ambiguity and seed-closer scoring."""

from __future__ import annotations

from typing import Any

from mobius.workflow.interview_parsing import _ambiguity_for_list, _ambiguity_for_scalar
from mobius.workflow.interview_types import (
    _DIMENSION_FLOORS,
    _GATE_THRESHOLD,
    AmbiguityScore,
    InterviewFixture,
    SeedCloserGate,
)

__all__ = [
    "_GATE_THRESHOLD",
    "_check_dimension_floors",
    "compute_ambiguity_score",
    "evaluate_seed_closer",
]


def compute_ambiguity_score(fixture: InterviewFixture) -> AmbiguityScore:
    """Compute the weighted ambiguity score for a fixture."""
    weights = (
        {"goal": 0.3, "constraints": 0.25, "success": 0.25, "context": 0.2}
        if fixture.is_brownfield
        else {"goal": 0.4, "constraints": 0.3, "success": 0.3}
    )
    components = {
        "goal": _ambiguity_for_scalar(fixture.goal),
        "constraints": _ambiguity_for_list(fixture.constraints),
        "success": _ambiguity_for_list(fixture.success),
    }
    if fixture.is_brownfield:
        components["context"] = _ambiguity_for_scalar(fixture.context)
    score = round(sum(weights[key] * components[key] for key in weights), 3)
    floors_met, floor_details = _check_dimension_floors(components)
    return AmbiguityScore(
        score=score,
        threshold=_GATE_THRESHOLD,
        passed=score <= _GATE_THRESHOLD,
        weights=weights,
        components=components,
        floors_met=floors_met,
        floor_details=floor_details,
    )


def evaluate_seed_closer(
    score: AmbiguityScore,
    qualifying_streak: int,
    *,
    fixture: InterviewFixture | None = None,
    deep_metadata: dict[str, Any] | None = None,
) -> SeedCloserGate:
    """Évalue la gate seed closer pour un score d'ambiguïté donné."""
    blockers: tuple[str, ...] = ()
    if fixture is not None or deep_metadata is not None:
        from mobius.workflow.interview_contract import evaluate_interview_contract

        if fixture is None:
            msg = "fixture is required when deep_metadata participates in seed closer"
            raise ValueError(msg)
        blockers = evaluate_interview_contract(
            fixture,
            score=score,
            deep_metadata=deep_metadata,
        ).closure_blockers
    return SeedCloserGate(
        ambiguity_passed=score.passed,
        floors_met=score.floors_met,
        floor_details=score.floor_details,
        qualifying_streak=qualifying_streak,
        closure_blockers=blockers,
    )


def _check_dimension_floors(
    components: dict[str, float],
) -> tuple[bool, dict[str, bool]]:
    """Vérifie les floors de clarté par dimension.

    Les components sont des valeurs d'ambiguïté (0.0 = clair, 1.0 = ambigu).
    Les floors sont des seuils de clarté (clarity = 1.0 - ambiguity).
    """
    details: dict[str, bool] = {}
    for dim, ambiguity in components.items():
        clarity = round(1.0 - ambiguity, 3)
        floor = _DIMENSION_FLOORS.get(dim, 0.0)
        details[dim] = clarity >= floor
    return all(details.values()), details
