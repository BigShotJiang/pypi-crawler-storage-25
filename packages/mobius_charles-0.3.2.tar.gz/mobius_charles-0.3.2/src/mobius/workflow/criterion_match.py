"""Backward-compatible workflow import path for criterion matching."""

from __future__ import annotations

from mobius.core.criterion_match import (
    command_matches,
    criterion_ref,
    normalize_ref,
    references_for,
)

__all__ = [
    "command_matches",
    "criterion_ref",
    "normalize_ref",
    "references_for",
]
