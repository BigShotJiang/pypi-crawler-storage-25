"""Deterministic workspace scanner for brownfield context generation.

Reads manifest files (package.json, Cargo.toml, pyproject.toml, etc.)
and produces a structured context string. No AI, no network calls —
just file reads and pattern matching.

Karpathy method: simplest thing that works, measure, iterate.
"""

from __future__ import annotations

import json
from pathlib import Path


def context_from_workspace(workspace: Path) -> str:
    """Scan a workspace and produce a brownfield context string.

    Returns an empty string if no recognisable manifests are found.
    """
    try:
        workspace = workspace.expanduser().resolve()
    except OSError:
        return ""
    if not workspace.exists():
        return ""

    parts: list[str] = []

    stack = _detect_stack(workspace)
    if stack:
        parts.append(stack)

    db = _detect_database(workspace)
    if db:
        parts.append(db)

    deps = _detect_key_dependencies(workspace)
    if deps:
        parts.append(f"Key dependencies: {', '.join(deps)}.")

    scale = _detect_scale(workspace)
    if scale:
        parts.append(scale)

    deploy = _detect_deploy(workspace)
    if deploy:
        parts.append(deploy)

    ci = _detect_ci(workspace)
    if ci:
        parts.append(ci)

    return " ".join(parts)


def _detect_stack(workspace: Path) -> str:
    pkg = workspace / "package.json"
    if pkg.exists():
        return _stack_from_package_json(pkg)

    cargo = workspace / "Cargo.toml"
    if cargo.exists():
        return _stack_from_cargo_toml(cargo)

    pyproject = workspace / "pyproject.toml"
    if pyproject.exists():
        return _stack_from_pyproject(pyproject)

    gemfile = workspace / "Gemfile"
    if gemfile.exists():
        return _stack_from_gemfile(gemfile)

    go_mod = workspace / "go.mod"
    if go_mod.exists():
        return _stack_from_go_mod(go_mod)

    return ""


def _stack_from_package_json(path: Path) -> str:
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError, UnicodeDecodeError):
        return "Node.js application."

    all_deps = {}
    for key in ("dependencies", "devDependencies"):
        raw = data.get(key, {})
        if isinstance(raw, dict):
            all_deps.update(raw)

    framework = "Node.js"
    if "next" in all_deps:
        raw_version = all_deps["next"] if isinstance(all_deps["next"], str) else ""
        version = raw_version.lstrip("^~>=<")
        framework = (
            f"Next.js {version.split('.')[0]}" if version and version[0].isdigit() else "Next.js"
        )
    elif "react" in all_deps:
        framework = "React"
    elif "vue" in all_deps:
        framework = "Vue.js"
    elif "svelte" in all_deps:
        framework = "Svelte"
    elif "@angular/core" in all_deps:
        framework = "Angular"
    elif "express" in all_deps:
        framework = "Express.js"
    elif "fastify" in all_deps:
        framework = "Fastify"

    app_type = "application"
    if "next" in all_deps or "react" in all_deps:
        app_type = "web application"
    elif "express" in all_deps or "fastify" in all_deps:
        app_type = "API server"

    ts = "TypeScript" if "typescript" in all_deps else "JavaScript"
    return f"{framework} {app_type} ({ts})."


def _stack_from_cargo_toml(path: Path) -> str:
    text = _safe_read(path)
    if not text:
        return "Rust application."

    has_clap = "clap" in text
    has_actix = "actix-web" in text
    has_axum = "axum" in text
    has_tokio = "tokio" in text

    if has_actix:
        return "Rust web application (actix-web, async)."
    if has_axum:
        return "Rust web application (axum, async)."
    if has_clap:
        async_note = ", tokio async runtime" if has_tokio else ""
        return f"Rust CLI application (clap{async_note})."
    if has_tokio:
        return "Rust async application (tokio)."
    return "Rust application."


def _stack_from_pyproject(path: Path) -> str:
    text = _safe_read(path)
    if not text:
        return "Python application."

    if "django" in text.lower():
        return "Python Django application."
    if "fastapi" in text.lower():
        return "Python FastAPI application."
    if "flask" in text.lower():
        return "Python Flask application."
    return "Python application."


def _stack_from_gemfile(path: Path) -> str:
    text = _safe_read(path)
    if not text:
        return "Ruby application."

    if "rails" in text.lower():
        return "Ruby on Rails application."
    if "sinatra" in text.lower():
        return "Ruby Sinatra application."
    return "Ruby application."


def _stack_from_go_mod(path: Path) -> str:
    text = _safe_read(path)
    if not text:
        return "Go application."

    if "gin-gonic" in text:
        return "Go web application (Gin)."
    if "fiber" in text:
        return "Go web application (Fiber)."
    if "echo" in text:
        return "Go web application (Echo)."
    return "Go application."


def _detect_database(workspace: Path) -> str:
    signals: list[str] = []

    prisma = workspace / "prisma" / "schema.prisma"
    if prisma.exists():
        text = _safe_read(prisma)
        model_count = sum(1 for line in text.splitlines() if line.strip().startswith("model "))
        model_info = f" ({model_count} models)" if model_count > 0 else ""
        if "postgresql" in text.lower():
            signals.append(f"PostgreSQL via Prisma{model_info}")
        elif "mysql" in text.lower():
            signals.append(f"MySQL via Prisma{model_info}")
        elif "sqlite" in text.lower():
            signals.append(f"SQLite via Prisma{model_info}")
        else:
            signals.append(f"Prisma ORM{model_info}")

    if not signals and (
        (workspace / "migrations").is_dir() or (workspace / "alembic").is_dir()
    ):
        signals.append("database with migrations")

    for env_file in [".env", ".env.local", ".env.example"]:
        env_path = workspace / env_file
        if env_path.exists():
            text = _safe_read(env_path)
            if text:
                lower = text.lower()
                if "postgres" in lower and "PostgreSQL" not in " ".join(signals):
                    signals.append("PostgreSQL")
                if "mysql" in lower and "MySQL" not in " ".join(signals):
                    signals.append("MySQL")
                if "redis" in lower:
                    signals.append("Redis")
                if "mongo" in lower:
                    signals.append("MongoDB")

    pkg = workspace / "package.json"
    if pkg.exists():
        try:
            data = json.loads(pkg.read_text(encoding="utf-8"))
            raw_deps = data.get("dependencies", {})
            raw_dev = data.get("devDependencies", {})
            all_deps = {
                **(raw_deps if isinstance(raw_deps, dict) else {}),
                **(raw_dev if isinstance(raw_dev, dict) else {}),
            }
            if ("redis" in all_deps or "ioredis" in all_deps) and "Redis" not in signals:
                signals.append("Redis")
        except (json.JSONDecodeError, OSError, UnicodeDecodeError):
            pass

    if not signals:
        return ""
    return f"Database: {', '.join(signals)}."


def _detect_key_dependencies(workspace: Path) -> list[str]:
    deps: list[str] = []

    pkg = workspace / "package.json"
    if pkg.exists():
        try:
            data = json.loads(pkg.read_text(encoding="utf-8"))
            raw_deps = data.get("dependencies", {})
            raw_dev = data.get("devDependencies", {})
            all_deps = set((raw_deps if isinstance(raw_deps, dict) else {}).keys()) | set(
                (raw_dev if isinstance(raw_dev, dict) else {}).keys()
            )
            notable = {
                "stripe": "Stripe payments",
                "@stripe/stripe-js": "Stripe payments",
                "socket.io": "Socket.io (WebSocket)",
                "ws": "WebSocket (ws)",
                "@trpc/server": "tRPC",
                "graphql": "GraphQL",
                "@apollo/server": "Apollo GraphQL",
                "next-auth": "NextAuth",
                "@clerk/nextjs": "Clerk auth",
                "@auth/core": "Auth.js",
                "@sentry/nextjs": "Sentry",
                "@sentry/node": "Sentry",
                "tailwindcss": "Tailwind CSS",
                "zustand": "Zustand",
                "@tanstack/react-query": "TanStack Query",
            }
            for dep, label in notable.items():
                if dep in all_deps and label not in deps:
                    deps.append(label)
        except (json.JSONDecodeError, OSError, UnicodeDecodeError):
            pass

    return deps


def _detect_scale(workspace: Path) -> str:
    parts: list[str] = []

    src = workspace / "src"
    if src.is_dir():
        ts_files = list(src.rglob("*.ts")) + list(src.rglob("*.tsx"))
        py_files = list(src.rglob("*.py"))
        rs_files = list(src.rglob("*.rs"))
        total = len(ts_files) + len(py_files) + len(rs_files)
        if total > 0:
            parts.append(f"{total} source files")

    pages = workspace / "src" / "pages"
    app_dir = workspace / "src" / "app"
    routes = workspace / "src" / "routes"
    for route_dir in [pages, app_dir, routes]:
        if route_dir.is_dir():
            route_files = [
                f
                for f in route_dir.rglob("*")
                if f.is_file()
                and f.suffix in {".tsx", ".ts", ".jsx", ".js", ".py", ".svelte", ".vue"}
            ]
            if route_files:
                page_count = sum(1 for f in route_files if f.stem in {"page", "index"})
                api_count = sum(
                    1
                    for f in route_files
                    if f.stem == "route" or "api" in str(f.relative_to(route_dir)).split("/")[:1]
                )
                if page_count > 0 and api_count > 0:
                    parts.append(f"{page_count} pages, {api_count} API routes")
                else:
                    parts.append(f"{len(route_files)} route files")
            break

    django_apps = _detect_django_apps(workspace)
    if django_apps:
        shown_apps = ", ".join(django_apps[:5])
        suffix = "..." if len(django_apps) > 5 else ""
        parts.append(
            f"{len(django_apps)} Django apps ({shown_apps}{suffix})"
        )

    workspace_packages = _detect_monorepo_packages(workspace)
    if workspace_packages:
        shown_packages = ", ".join(workspace_packages[:4])
        suffix = "..." if len(workspace_packages) > 4 else ""
        parts.append(
            f"{len(workspace_packages)} packages ({shown_packages}{suffix})"
        )

    tests = workspace / "tests"
    test_dir = workspace / "test"
    spec_dir = workspace / "__tests__"
    for t in [tests, test_dir, spec_dir]:
        if t.is_dir():
            test_files = list(t.rglob("*test*")) + list(t.rglob("*spec*"))
            if test_files:
                parts.append(f"{len(test_files)} test files")
            break

    if not parts:
        return ""
    return f"Scale: {', '.join(parts)}."


def _detect_django_apps(workspace: Path) -> list[str]:
    apps: list[str] = []
    for candidate in [workspace, workspace / "src"]:
        if not candidate.is_dir():
            continue
        for apps_py in candidate.rglob("apps.py"):
            app_name = apps_py.parent.name
            if app_name and app_name not in apps:
                apps.append(app_name)
    return apps


def _detect_monorepo_packages(workspace: Path) -> list[str]:
    pnpm_ws = workspace / "pnpm-workspace.yaml"
    if pnpm_ws.exists():
        text = _safe_read(pnpm_ws)
        packages = []
        for line in text.splitlines():
            stripped = line.strip()
            if stripped.startswith("- "):
                pkg = stripped[2:].strip().strip("'\"").rstrip("/*")
                if pkg:
                    packages.append(pkg.split("/")[-1])
        if packages:
            return packages

    turbo = workspace / "turbo.json"
    if turbo.exists():
        try:
            data = json.loads(turbo.read_text(encoding="utf-8"))
            if isinstance(data, dict) and "pipeline" in data:
                pass
        except (json.JSONDecodeError, OSError, UnicodeDecodeError):
            pass

    cargo = workspace / "Cargo.toml"
    if cargo.exists():
        text = _safe_read(cargo)
        if "[workspace]" in text:
            members = []
            in_members = False
            for line in text.splitlines():
                if "members" in line and "=" in line:
                    in_members = True
                    continue
                if in_members:
                    stripped = line.strip()
                    if stripped == "]":
                        break
                    member = stripped.strip('", ')
                    if member:
                        members.append(member.split("/")[-1])
            if members:
                return members

    return []


def _detect_deploy(workspace: Path) -> str:
    if (workspace / "vercel.json").exists() or (workspace / ".vercel").is_dir():
        return "Deployed on Vercel."
    if (workspace / "Dockerfile").exists():
        if (workspace / "docker-compose.yml").exists() or (
            workspace / "docker-compose.yaml"
        ).exists():
            return "Deployed via Docker Compose."
        return "Containerized (Dockerfile present)."
    if (workspace / "fly.toml").exists():
        return "Deployed on Fly.io."
    if (workspace / "railway.json").exists() or (workspace / "railway.toml").exists():
        return "Deployed on Railway."
    if (workspace / "render.yaml").exists():
        return "Deployed on Render."
    if (workspace / "netlify.toml").exists():
        return "Deployed on Netlify."
    return ""


def _detect_ci(workspace: Path) -> str:
    if (workspace / ".github" / "workflows").is_dir():
        return "CI via GitHub Actions."
    if (workspace / ".gitlab-ci.yml").exists():
        return "CI via GitLab CI."
    if (workspace / ".circleci").is_dir():
        return "CI via CircleCI."
    if (workspace / "Jenkinsfile").exists():
        return "CI via Jenkins."
    return ""


def _safe_read(path: Path) -> str:
    try:
        return path.read_text(encoding="utf-8")
    except (OSError, UnicodeDecodeError):
        return ""
