"""Run workflow execution helpers."""

from __future__ import annotations

import contextlib
import json
import os
import subprocess
import sys
import time
from collections.abc import Callable
from dataclasses import dataclass
from pathlib import Path

from mobius.config import MobiusPaths
from mobius.core.types import ExitCode
from mobius.persistence.event_store import EventStore
from mobius.workflow.ids import readable_session_id
from mobius.workflow.lifecycle import (
    DetachedWorkerSpec,
    WorkerInterrupted,
    append_and_emit,
    cleanup_pid,
    pid_is_live,
    start_detached_worker_process,
    write_pid,
)
from mobius.workflow.pal_router import PalRouteDecision, route_seed_spec
from mobius.workflow.seed import SeedSpec, SeedSpecValidationError, load_seed_spec

_MODEL_ALIASES = {
    "kimi-k2.6-openrouter": "custom:Kimi-K2.6-6",
    "kimi2.6-openrouter": "custom:Kimi-K2.6-6",
    "kimi-2.6-openrouter": "custom:Kimi-K2.6-6",
}

_SUPPORTED_AGENTS = frozenset({"droid", "claude", "codex"})
_AUTO_AGENT = "auto"


@dataclass(frozen=True)
class RunPaths:
    """Filesystem paths for one run."""

    directory: Path
    pid_file: Path
    log_file: Path
    metadata_file: Path


@dataclass(frozen=True)
class PreparedRun:
    """A validated run ready to execute."""

    run_id: str
    spec_path: Path
    spec: SeedSpec
    paths: RunPaths


@dataclass(frozen=True)
class AgentExecutionTask:
    """One orchestrated coding-agent task derived from a success criterion."""

    task_id: str
    criterion_index: int
    criterion: str
    prompt: str


@dataclass(frozen=True)
class AgentAttemptRecord:
    """Result of one coding-agent attempt."""

    attempt: int
    exit_code: int
    duration_ms: int
    pid: int | None
    log_file: str
    command: tuple[str, ...]


@dataclass(frozen=True)
class AgentTaskResult:
    """Final result of one orchestrated coding-agent task."""

    task: AgentExecutionTask
    attempts: tuple[AgentAttemptRecord, ...]

    @property
    def exit_code(self) -> int:
        return self.attempts[-1].exit_code if self.attempts else int(ExitCode.VALIDATION)

    @property
    def succeeded(self) -> bool:
        return self.exit_code == int(ExitCode.OK)


@dataclass(frozen=True)
class CodingAgentRequest:
    """Approved external coding agent launch request."""

    run_id: str
    spec_path: Path
    run_directory: Path
    agent: str
    model: str
    prompt: str
    task_id: str = "full_spec"
    criterion_index: int = 0
    attempt: int = 1


def prepare_run(
    paths: MobiusPaths,
    spec_path: Path,
    *,
    coding_agent: str | None = None,
    coding_model: str | None = None,
    coding_plan: Path | None = None,
    agent_approved: bool = False,
) -> PreparedRun:
    """Validate a spec and create the run metadata directory."""
    resolved_spec_path = spec_path.expanduser().resolve()
    spec = load_seed_spec(resolved_spec_path)
    run_id = readable_session_id("run", spec.goal)
    run_paths = get_run_paths(paths, run_id)
    run_paths.directory.mkdir(parents=True, exist_ok=True, mode=0o700)
    os.chmod(run_paths.directory, 0o700)
    selection = _resolve_coding_selection(
        spec,
        coding_agent=coding_agent,
        coding_model=coding_model,
        coding_plan=coding_plan,
        agent_approved=agent_approved,
    )
    run_paths.metadata_file.write_text(
        json.dumps(
            {
                "spec_path": str(resolved_spec_path),
                **selection,
            },
            sort_keys=True,
        ),
        encoding="utf-8",
    )
    os.chmod(run_paths.metadata_file, 0o600)
    return PreparedRun(
        run_id=run_id,
        spec_path=resolved_spec_path,
        spec=spec,
        paths=run_paths,
    )


def get_run_paths(paths: MobiusPaths, run_id: str) -> RunPaths:
    """Return the run directory paths for ``run_id``."""
    directory = paths.state_dir / "runs" / run_id
    return RunPaths(
        directory=directory,
        pid_file=directory / "pid",
        log_file=directory / "log",
        metadata_file=directory / "metadata.json",
    )


def start_detached_worker(paths: MobiusPaths, prepared: PreparedRun) -> int:
    """Fork a detached worker process and write its PID file."""
    return start_detached_worker_process(
        paths,
        DetachedWorkerSpec(
            session_id=prepared.run_id,
            runtime="run",
            metadata={
                "spec_path": str(prepared.spec_path),
                "project_type": prepared.spec.project_type,
                **_coding_metadata_from_file(prepared.paths.metadata_file),
            },
            command=["mobius", "_worker", "run", prepared.run_id],
            files=prepared.paths,
        ),
    )


def run_foreground(paths: MobiusPaths, prepared: PreparedRun) -> int:
    """Execute a run in the current process, streaming progress to stderr."""
    return execute_run(paths, prepared.run_id, stream_events=True)


def execute_run(paths: MobiusPaths, run_id: str, *, stream_events: bool) -> int:
    """Worker entry point for a prepared run."""
    run_paths = get_run_paths(paths, run_id)
    metadata = _read_run_metadata(run_paths)
    spec_path = _spec_path_from_metadata(run_paths, metadata)
    try:
        spec = load_seed_spec(spec_path)
    except SeedSpecValidationError as exc:
        _emit(stream_events, f"run.validation_failed {exc}")
        cleanup_pid(run_paths.pid_file)
        return int(ExitCode.VALIDATION)

    RunInterrupted(paths=paths, run_id=run_id, pid_file=run_paths.pid_file).install()

    try:
        with EventStore(paths.event_store) as store:
            store.create_session(
                run_id,
                runtime="run",
                metadata={
                    "spec_path": str(spec_path),
                    "project_type": spec.project_type,
                    **_coding_metadata(metadata),
                },
                status="running",
            )
            _append_and_emit(
                store,
                run_id,
                "run.started",
                {
                    "spec_path": str(spec_path),
                    "goal": spec.goal,
                    "title": _title_from_goal(spec.goal),
                    **_coding_metadata(metadata),
                },
                stream_events=stream_events,
            )
            _emit_pal_route_decision(store, run_id, metadata, stream_events=stream_events)
            write_pid(run_paths.pid_file, os.getpid())
            agent_request = _coding_agent_request(run_id, spec_path, run_paths, metadata)
            if agent_request is not None:
                agent_exit_code = _execute_coding_plan(
                    store,
                    run_id,
                    spec,
                    agent_request,
                    stream_events=stream_events,
                )
                if agent_exit_code != int(ExitCode.OK):
                    store.end_session(run_id, status="failed")
                    return agent_exit_code
            _sleep_with_heartbeats(store, run_id, spec, stream_events=stream_events)
            _append_and_emit(
                store,
                run_id,
                "run.completed",
                {
                    "constraint_count": len(spec.constraints),
                    "success_criteria_count": len(spec.success_criteria),
                },
                stream_events=stream_events,
            )
            store.end_session(run_id, status="completed")
        return int(ExitCode.OK)
    finally:
        cleanup_pid(run_paths.pid_file)


def mark_stale_run_if_needed(paths: MobiusPaths, run_id: str) -> None:
    """Mark a run crashed when a PID file points at a dead process."""
    run_paths = get_run_paths(paths, run_id)
    if not run_paths.pid_file.exists():
        return
    try:
        pid = int(run_paths.pid_file.read_text(encoding="utf-8").strip())
    except (OSError, ValueError):
        pid = -1
    if pid > 0 and pid_is_live(pid):
        return
    cleanup_pid(run_paths.pid_file)
    with EventStore(paths.event_store) as store:
        store.create_session(
            run_id,
            runtime="run",
            metadata={"reason": "stale pid file", "pid": pid},
            status="running",
        )
        store.append_event(run_id, "run.crashed", {"reason": "stale pid file", "pid": pid})
        store.end_session(run_id, status="crashed")


class RunInterrupted(WorkerInterrupted):
    """Signal handlers for a running worker."""

    def __init__(self, *, paths: MobiusPaths, run_id: str, pid_file: Path) -> None:
        super().__init__(paths=paths, session_id=run_id, runtime="run", pid_file=pid_file)

    @property
    def run_id(self) -> str:
        """Run identifier preserved for callers that inspect the handler."""
        return self.session_id


def _execute_coding_plan(
    store: EventStore,
    run_id: str,
    spec: SeedSpec,
    base_request: CodingAgentRequest,
    *,
    stream_events: bool,
) -> int:
    tasks = _agent_execution_tasks(
        spec,
        spec_path=base_request.spec_path,
        base_prompt=base_request.prompt,
    )
    max_attempts = _agent_max_attempts()
    parallelism = _agent_parallelism(len(tasks))
    _append_and_emit(
        store,
        run_id,
        "execution.plan",
        {
            "strategy": "double_diamond_per_criterion",
            "task_count": len(tasks),
            "parallelism": parallelism,
            "parallelism_mode": "safe_serial_shared_worktree",
            "parallelism_note": (
                "Parallel execution is planned only after isolated worktree merge support exists."
            ),
            "max_attempts": max_attempts,
            "backoff": "exponential",
            "stagnation_detection": "repeated_same_exit_code",
            "agent": base_request.agent,
            "model": base_request.model,
        },
        stream_events=stream_events,
    )
    for task in tasks:
        _append_and_emit(
            store,
            run_id,
            "execution.task_started",
            {
                "task_id": task.task_id,
                "criterion_index": task.criterion_index,
                "criterion": task.criterion,
                "phases": ["discover", "define", "design", "deliver"],
            },
            stream_events=stream_events,
        )

    results: list[AgentTaskResult] = []
    for task in tasks:
        results.append(
            _run_agent_task_with_retries(
                store,
                run_id,
                base_request,
                task,
                max_attempts=max_attempts,
                sleeper=time.sleep,
                stream_events=stream_events,
            )
        )

    first_failure = int(ExitCode.OK)
    for result in sorted(results, key=lambda item: item.task.criterion_index):
        for attempt in result.attempts:
            _append_and_emit(
                store,
                run_id,
                "agent.attempt",
                {
                    "task_id": result.task.task_id,
                    "criterion_index": result.task.criterion_index,
                    "attempt": attempt.attempt,
                    "exit_code": attempt.exit_code,
                    "duration_ms": attempt.duration_ms,
                    "pid": attempt.pid,
                    "log_file": attempt.log_file,
                    "command": list(attempt.command),
                },
                stream_events=stream_events,
            )
        if _stagnated(result.attempts):
            _append_and_emit(
                store,
                run_id,
                "agent.stagnation_detected",
                {
                    "task_id": result.task.task_id,
                    "criterion_index": result.task.criterion_index,
                    "exit_code": result.exit_code,
                    "attempts": len(result.attempts),
                },
                stream_events=stream_events,
            )
        if result.succeeded:
            _append_and_emit(
                store,
                run_id,
                "execution.task_completed",
                {
                    "task_id": result.task.task_id,
                    "criterion_index": result.task.criterion_index,
                    "attempts": len(result.attempts),
                },
                stream_events=stream_events,
            )
        else:
            if first_failure == int(ExitCode.OK):
                first_failure = result.exit_code
            _append_and_emit(
                store,
                run_id,
                "execution.task_failed",
                {
                    "task_id": result.task.task_id,
                    "criterion_index": result.task.criterion_index,
                    "attempts": len(result.attempts),
                    "exit_code": result.exit_code,
                },
                stream_events=stream_events,
            )
    if first_failure != int(ExitCode.OK):
        _append_and_emit(
            store,
            run_id,
            "agent.failed",
            {
                "agent": base_request.agent,
                "model": base_request.model,
                "exit_code": first_failure,
                "failed_tasks": sum(1 for result in results if not result.succeeded),
            },
            stream_events=stream_events,
        )
        return first_failure
    _append_and_emit(
        store,
        run_id,
        "agent.completed",
        {
            "agent": base_request.agent,
            "model": base_request.model,
            "completed_tasks": len(results),
        },
        stream_events=stream_events,
    )
    return int(ExitCode.OK)


def _run_agent_task_with_retries(
    store: EventStore,
    run_id: str,
    base_request: CodingAgentRequest,
    task: AgentExecutionTask,
    *,
    max_attempts: int,
    sleeper: Callable[[float], None],
    stream_events: bool,
) -> AgentTaskResult:
    attempts: list[AgentAttemptRecord] = []
    for attempt in range(1, max_attempts + 1):
        request = CodingAgentRequest(
            run_id=base_request.run_id,
            spec_path=base_request.spec_path,
            run_directory=base_request.run_directory,
            agent=base_request.agent,
            model=base_request.model,
            prompt=task.prompt,
            task_id=task.task_id,
            criterion_index=task.criterion_index,
            attempt=attempt,
        )
        command = _agent_command(request)
        log_file = _agent_attempt_log_file(request)
        started_at = time.monotonic()
        process = _start_coding_agent_process(
            request,
            command=command,
            log_file=log_file,
            stream_events=stream_events,
        )
        _append_and_emit(
            store,
            run_id,
            "agent.attempt_started",
            {
                "task_id": task.task_id,
                "criterion_index": task.criterion_index,
                "attempt": attempt,
                "agent": request.agent,
                "model": request.model,
                "pid": process.pid,
                "log_file": str(log_file),
                "command": command,
            },
            stream_events=stream_events,
        )
        exit_code = int(process.wait())
        record = AgentAttemptRecord(
            attempt=attempt,
            exit_code=exit_code,
            duration_ms=max(0, round((time.monotonic() - started_at) * 1000)),
            pid=process.pid,
            log_file=str(log_file),
            command=tuple(command),
        )
        attempts.append(record)
        _append_and_emit(
            store,
            run_id,
            "agent.attempt_completed",
            {
                "task_id": task.task_id,
                "criterion_index": task.criterion_index,
                "attempt": attempt,
                "agent": request.agent,
                "model": request.model,
                "pid": process.pid,
                "log_file": str(log_file),
                "command": command,
                "exit_code": exit_code,
                "duration_ms": record.duration_ms,
            },
            stream_events=stream_events,
        )
        if exit_code == int(ExitCode.OK):
            break
        if attempt < max_attempts:
            _append_and_emit(
                store,
                run_id,
                "agent.retrying",
                {
                    "task_id": task.task_id,
                    "criterion_index": task.criterion_index,
                    "attempt": attempt,
                    "exit_code": exit_code,
                    "next_attempt": attempt + 1,
                    "backoff_seconds": _retry_delay_seconds(attempt),
                },
                stream_events=stream_events,
            )
            sleeper(_retry_delay_seconds(attempt))
    return AgentTaskResult(task=task, attempts=tuple(attempts))


def _agent_execution_tasks(
    spec: SeedSpec, *, spec_path: Path | None = None, base_prompt: str = ""
) -> list[AgentExecutionTask]:
    criteria = spec.success_criteria or [spec.goal]
    return [
        AgentExecutionTask(
            task_id=f"criterion_{index}",
            criterion_index=index,
            criterion=criterion,
            prompt=_build_execution_prompt(
                spec,
                index,
                criterion,
                spec_path=spec_path,
                base_prompt=base_prompt,
            ),
        )
        for index, criterion in enumerate(criteria, start=1)
    ]


def _build_execution_prompt(
    spec: SeedSpec,
    criterion_index: int,
    criterion: str,
    *,
    spec_path: Path | None = None,
    base_prompt: str = "",
) -> str:
    constraints = "\n".join(f"- {constraint}" for constraint in spec.constraints) or "- Aucune"
    contract = json.dumps(spec.to_event_payload(), ensure_ascii=False, sort_keys=True, indent=2)
    return "\n".join(
        [
            "Mobius execution task",
            "",
            "Original run prompt:",
            base_prompt or "Aucun",
            "",
            "Spec path:",
            str(spec_path) if spec_path is not None else "Non disponible",
            "",
            "Full Mobius spec contract:",
            contract,
            "",
            "Goal:",
            spec.goal,
            "",
            f"Success criterion {criterion_index}:",
            criterion,
            "",
            "Constraints:",
            constraints,
            "",
            "Orchestration phases:",
            "1. DISCOVER: inspect the current code and evidence for this criterion.",
            "2. DEFINE: restate the precise failing gap and acceptance signal.",
            "3. DESIGN: choose the smallest safe implementation path.",
            "4. DELIVER: implement, test, and stop when this criterion is satisfied.",
            "",
            "Rules:",
            "- Focus on this criterion; do not rewrite unrelated code.",
            "- Preserve the full Mobius spec constraints.",
            "- Leave clear evidence in tests or logs before exiting.",
        ]
    )


def _agent_max_attempts() -> int:
    raw = os.environ.get("MOBIUS_AGENT_MAX_ATTEMPTS", "3")
    try:
        return max(1, min(10, int(raw)))
    except ValueError:
        return 3


def _agent_parallelism(task_count: int) -> int:
    # External coding agents edit the same project directory today. Keep actual
    # execution serial until Mobius owns isolated worktree + merge orchestration.
    return 1 if task_count >= 1 else 0


def _retry_delay_seconds(attempt: int) -> float:
    return float(min(8.0, 0.5 * (2 ** (attempt - 1))))


def _stagnated(attempts: tuple[AgentAttemptRecord, ...]) -> bool:
    if len(attempts) < 2 or attempts[-1].exit_code == int(ExitCode.OK):
        return False
    return len({attempt.exit_code for attempt in attempts}) == 1


def _sleep_with_heartbeats(
    store: EventStore,
    run_id: str,
    spec: SeedSpec,
    *,
    stream_events: bool,
) -> None:
    heartbeat_count = max(3, min(10, len(spec.success_criteria) + len(spec.constraints)))
    for index in range(heartbeat_count):
        _append_and_emit(
            store,
            run_id,
            "run.progress",
            {"step": index + 1, "total": heartbeat_count},
            stream_events=stream_events,
        )
        time.sleep(0.2)


def _append_and_emit(
    store: EventStore,
    run_id: str,
    event_type: str,
    payload: dict[str, object],
    *,
    stream_events: bool,
) -> None:
    append_and_emit(store, run_id, event_type, payload, stream_events=stream_events)


def _title_from_goal(goal: str) -> str:
    title = " ".join(goal.split())
    if len(title) <= 60:
        return title
    return title[:60].rstrip()


def _emit(stream_events: bool, message: str) -> None:
    if stream_events:
        sys.stderr.write(f"{message}\n")
        sys.stderr.flush()


_write_pid = write_pid
_cleanup_pid = cleanup_pid
_pid_is_live = pid_is_live


def _read_run_metadata(run_paths: RunPaths) -> dict[str, object]:
    try:
        metadata = json.loads(run_paths.metadata_file.read_text(encoding="utf-8"))
    except OSError as exc:
        msg = f"run metadata not found for {run_paths.directory.name}: {exc}"
        raise SeedSpecValidationError(msg) from exc
    if not isinstance(metadata, dict):
        msg = f"run metadata invalid for {run_paths.directory.name}"
        raise SeedSpecValidationError(msg)
    return metadata


def _read_spec_path(run_paths: RunPaths) -> Path:
    return _spec_path_from_metadata(run_paths, _read_run_metadata(run_paths))


def _spec_path_from_metadata(run_paths: RunPaths, metadata: dict[str, object]) -> Path:
    value = metadata.get("spec_path")
    if not isinstance(value, str) or not value:
        msg = f"run metadata missing spec_path for {run_paths.directory.name}"
        raise SeedSpecValidationError(msg)
    return Path(value)


def _resolve_coding_selection(
    spec: SeedSpec,
    *,
    coding_agent: str | None,
    coding_model: str | None,
    coding_plan: Path | None,
    agent_approved: bool,
) -> dict[str, object]:
    agent_value = (coding_agent or spec.coding_agent).strip().lower()
    model_value = _canonical_model((coding_model or spec.coding_model).strip())
    model_source = "cli" if coding_model else "spec" if spec.coding_model else ""
    agent_source = "cli" if coding_agent else "spec" if spec.coding_agent else ""
    route_decision: PalRouteDecision | None = None
    requested_agent = agent_value
    if agent_value == _AUTO_AGENT:
        route_decision = route_seed_spec(spec)
        agent_value = route_decision.agent
        if not model_value and route_decision.model:
            model_value = _canonical_model(route_decision.model)
            model_source = "pal_router"
        agent_source = "pal_router"
    if agent_value and agent_value not in _SUPPORTED_AGENTS:
        supported = ", ".join([_AUTO_AGENT, *sorted(_SUPPORTED_AGENTS)])
        msg = f"unsupported coding_agent: {agent_value}. Supported: {supported}"
        raise SeedSpecValidationError(msg)
    if bool(agent_value) != bool(model_value):
        raise SeedSpecValidationError("coding_agent and coding_model must be provided together")
    if not agent_value:
        return {}
    selection: dict[str, object] = {
        "coding_agent": agent_value,
        "coding_model": model_value,
        "agent_source": agent_source,
        "model_source": model_source,
        "agent_approved": agent_approved,
    }
    if route_decision is not None and agent_approved:
        route_payload = route_decision.to_event_payload()
        route_payload["model"] = model_value
        selection["requested_agent"] = requested_agent
        selection["pal_route"] = route_payload
    if coding_plan is not None:
        selection["coding_plan_path"] = str(coding_plan.expanduser().resolve())
    return selection


def _canonical_model(model: str) -> str:
    return _MODEL_ALIASES.get(model.lower(), model)


def _coding_metadata_from_file(metadata_file: Path) -> dict[str, object]:
    try:
        metadata = json.loads(metadata_file.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}
    return _coding_metadata(metadata) if isinstance(metadata, dict) else {}


def _coding_metadata(metadata: dict[str, object]) -> dict[str, object]:
    keys = (
        "coding_agent",
        "coding_model",
        "agent_source",
        "model_source",
        "agent_approved",
        "requested_agent",
        "pal_route",
    )
    return {key: metadata[key] for key in keys if key in metadata}


def _emit_pal_route_decision(
    store: EventStore,
    run_id: str,
    metadata: dict[str, object],
    *,
    stream_events: bool,
) -> None:
    if metadata.get("agent_approved") is not True:
        return
    route = metadata.get("pal_route")
    if not isinstance(route, dict):
        return
    payload = dict(route)
    requested = metadata.get("requested_agent")
    if isinstance(requested, str):
        payload["requested_agent"] = requested
    _append_and_emit(
        store,
        run_id,
        "pal.route_decision",
        payload,
        stream_events=stream_events,
    )


def _coding_agent_request(
    run_id: str,
    spec_path: Path,
    run_paths: RunPaths,
    metadata: dict[str, object],
) -> CodingAgentRequest | None:
    if metadata.get("agent_approved") is not True:
        return None
    agent = metadata.get("coding_agent")
    model = metadata.get("coding_model")
    if not isinstance(agent, str) or not isinstance(model, str):
        return None
    spec_content = spec_path.read_text(encoding="utf-8")
    prompt = (
        "Tu DOIS implémenter UNIQUEMENT ce qui est décrit dans la spec ci-dessous. "
        "Ne fais PAS de nettoyage, refactoring, suppression de code, ni de ménage. "
        "Crée une branche git dédiée avant de commencer. "
        "Chaque critère de succès doit être implémenté et testé.\n\n"
        f"=== SPEC (source: {spec_path.name}) ===\n{spec_content}\n=== FIN SPEC ==="
    )
    return CodingAgentRequest(
        run_id=run_id,
        spec_path=spec_path,
        run_directory=run_paths.directory,
        agent=agent,
        model=model,
        prompt=prompt,
    )


def _create_agent_worktree(request: CodingAgentRequest) -> Path | None:
    """Crée un worktree git isolé pour le travail de l'agent.

    Retourne le chemin du worktree, ou None si la création échoue.
    Chaque run obtient son propre espace de travail — 10 runs
    peuvent tourner en parallèle sans conflit.
    """
    slug = request.run_id.replace("run_", "")[:50]
    branch = f"mobius/{slug}"
    repo_root = request.spec_path.parent
    worktree_dir = repo_root / ".worktrees" / slug
    try:
        subprocess.run(
            ["git", "worktree", "add", str(worktree_dir), "-b", branch],
            cwd=repo_root,
            capture_output=True,
            timeout=15,
        )
        spec_in_worktree = worktree_dir / request.spec_path.name
        if not spec_in_worktree.exists():
            import shutil

            shutil.copy2(request.spec_path, spec_in_worktree)
        return worktree_dir
    except (subprocess.SubprocessError, FileNotFoundError):
        return None


def _cleanup_agent_worktree(worktree_dir: Path, repo_root: Path) -> None:
    """Supprime le worktree après la fin du run."""
    with contextlib.suppress(subprocess.SubprocessError, FileNotFoundError):
        subprocess.run(
            ["git", "worktree", "remove", str(worktree_dir), "--force"],
            cwd=repo_root,
            capture_output=True,
            timeout=15,
        )


def _run_coding_agent(request: CodingAgentRequest, *, stream_events: bool) -> int:
    repo_root = request.spec_path.parent
    worktree_dir = _create_agent_worktree(request)
    agent_cwd = worktree_dir or repo_root
    command = _agent_command(request)
    log_file = _agent_attempt_log_file(request)
    process = _start_coding_agent_process(
        request,
        command=command,
        log_file=log_file,
        stream_events=stream_events,
        cwd_override=agent_cwd,
    )
    exit_code = int(process.wait())
    if worktree_dir and exit_code == 0:
        _emit(stream_events, f"agent.worktree {worktree_dir}")
    return exit_code


def _start_coding_agent_process(
    request: CodingAgentRequest,
    *,
    command: list[str],
    log_file: Path,
    stream_events: bool,
    cwd_override: Path | None = None,
) -> subprocess.Popen[bytes]:
    _emit(stream_events, "agent.command " + " ".join(command))
    log_file.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    log_handle = log_file.open("ab")
    try:
        process = subprocess.Popen(
            command,
            cwd=cwd_override or request.spec_path.parent,
            stdout=log_handle,
            stderr=log_handle,
        )
    finally:
        log_handle.close()
    return process


def _agent_attempt_log_file(request: CodingAgentRequest) -> Path:
    safe_task_id = request.task_id.replace("/", "_")
    return (
        request.run_directory / "agent-attempts" / safe_task_id / f"attempt-{request.attempt}.log"
    )


def run_coding_agent(request: CodingAgentRequest, *, stream_events: bool) -> int:
    return _run_coding_agent(request, stream_events=stream_events)


def _agent_command(request: CodingAgentRequest) -> list[str]:
    if request.agent == "droid":
        settings_path = request.run_directory / "agent-settings.json"
        settings_path.write_text(
            json.dumps({"model": request.model}, sort_keys=True),
            encoding="utf-8",
        )
        os.chmod(settings_path, 0o600)
        return ["droid", "--settings", str(settings_path), request.prompt]
    if request.agent == "claude":
        return ["claude", "--model", request.model, "-p", request.prompt]
    if request.agent == "codex":
        return ["codex", "--model", request.model, "exec", request.prompt]
    raise SeedSpecValidationError(f"unsupported coding_agent: {request.agent}")
