"""Socrate interview agent and convergence rules."""

from __future__ import annotations

from dataclasses import dataclass
from enum import StrEnum

from mobius.workflow.interview_v3a.lemma_check import LemmaCheckResult, check_rolling_lemma


class Keystroke(StrEnum):
    """Universal keystrokes accepted by the v3a interview phase."""

    ENOUGH = "enough"
    BACK = "back"
    RESTART = "restart"
    FORK = "fork"
    WHY = "why"
    STOP = "stop"


@dataclass(frozen=True)
class ParsedKeystroke:
    """Parsed user command."""

    kind: Keystroke
    count: int | None = None


@dataclass(frozen=True)
class QuestionCandidate:
    """Adaptive candidate question offered before the static Socrate plan."""

    question: str
    because: str
    key: str = ""


@dataclass(frozen=True)
class SocrateTurn:
    """One Socrate output."""

    question: str
    because: str
    proposes_done: bool = False
    lemma_check: LemmaCheckResult | None = None


_QUESTION_PLAN: tuple[tuple[str, str], ...] = (
    (
        "Quel résultat concret l'utilisateur doit-il obtenir en premier ?",
        "résultat utilisateur — le premier livrable reste trop flou",
    ),
    (
        "Par où l'utilisateur commence-t-il : commande, écran ou API ?",
        "surface principale — le point d'entrée doit être nommé",
    ),
    (
        "Quelles règles ne doivent jamais être cassées ?",
        "règles limites — les invariants ne sont pas encore explicites",
    ),
    (
        "Quel cas limite ferait croire que le produit est cassé ?",
        "cas limite — l'échec important doit être clair",
    ),
    (
        "Quelle preuve vérifiable dira que c'est terminé ?",
        "preuve de réussite — la fin doit être testable",
    ),
    (
        "Quels mots ou données la première version doit-elle accepter ?",
        "données acceptées — le vocabulaire d'entrée reste ouvert",
    ),
    (
        "Que doit-il se passer avec le plus petit exemple valide ?",
        "exemple minimal — le chemin heureux de base n'est pas fixé",
    ),
)


def parse_keystroke(raw: str) -> ParsedKeystroke | None:
    """Parse v3a interview keystrokes, returning ``None`` for normal answers."""
    value = raw.strip()
    if not value.startswith(":"):
        return None
    parts = value[1:].split()
    if not parts:
        return None
    command = parts[0].lower()
    aliases = {
        "enough": Keystroke.ENOUGH,
        "back": Keystroke.BACK,
        "restart": Keystroke.RESTART,
        "fork": Keystroke.FORK,
        "why": Keystroke.WHY,
        "stop": Keystroke.STOP,
    }
    kind = aliases.get(command)
    if kind is None:
        return None
    count = None
    if kind is Keystroke.BACK and len(parts) > 1:
        try:
            count = max(1, int(parts[1]))
        except ValueError:
            count = 1
    return ParsedKeystroke(kind=kind, count=count)


def propose_question(
    turn_index: int,
    previous_justifications: list[str] | tuple[str, ...],
    *,
    convergence_ready: bool = False,
    candidates: tuple[QuestionCandidate, ...] = (),
) -> SocrateTurn:
    """Return Socrate's next question while enforcing rolling lemma novelty."""
    if convergence_ready:
        because = ":done? prêt — le contrat partagé d'ambiguïté et de composants est respecté"
        lemma = check_rolling_lemma(
            because,
            previous_justifications,
            convergence_proposal=True,
        )
        return SocrateTurn(
            question=":done? Je pense avoir compris. On arrête ici ?",
            because=because,
            proposes_done=True,
            lemma_check=lemma,
        )

    for candidate in candidates:
        lemma = check_rolling_lemma(candidate.because, previous_justifications)
        if lemma.passed:
            return SocrateTurn(
                question=candidate.question,
                because=candidate.because,
                lemma_check=lemma,
            )

    for offset in range(len(_QUESTION_PLAN)):
        question, because = _QUESTION_PLAN[(turn_index + offset) % len(_QUESTION_PLAN)]
        lemma = check_rolling_lemma(because, previous_justifications)
        if lemma.passed:
            return SocrateTurn(question=question, because=because, lemma_check=lemma)
    fallback = f"novelty turn-{turn_index} — new detail needed to keep progress non-repetitive"
    lemma = check_rolling_lemma(fallback, previous_justifications)
    return SocrateTurn(
        question="Quel détail enlèverait le plus gros doute qui reste ?",
        because=fallback,
        lemma_check=lemma,
    )
