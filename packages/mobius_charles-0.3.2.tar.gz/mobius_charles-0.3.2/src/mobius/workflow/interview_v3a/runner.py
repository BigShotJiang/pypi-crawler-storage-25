"""Deterministic v3a interview runner used by ``mobius build``."""

from __future__ import annotations

import sys
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING, TextIO

from mobius.workflow._yaml import yaml_scalar as _yaml_scalar
from mobius.workflow.interview_v3a.ambiguity_trend import convergence_conditions_met
from mobius.workflow.interview_v3a.architecte import propose_options
from mobius.workflow.interview_v3a.avocat import Avocat, DeterministicAvocat
from mobius.workflow.interview_v3a.budget_tracker import BudgetTracker, InterviewBudget
from mobius.workflow.interview_v3a.socrate import (
    Keystroke,
    QuestionCandidate,
    parse_keystroke,
    propose_question,
)
from mobius.workflow.interview_v3a.transcript import TranscriptTurn, TranscriptWriter

if TYPE_CHECKING:
    from mobius.workflow.interview import InterviewFixture


@dataclass(frozen=True)
class InterviewRunResult:
    """Artifacts produced by the v3a interview phase."""

    run_id: str
    transcript_path: Path
    fixture_path: Path
    fixture: InterviewFixture
    turns: int
    ambiguity_score: float
    max_component: float
    socrate_proposed_done: bool
    human_confirmed: bool
    usd_spent: float
    question_ledger: list[dict[str, object]] | None = None
    conversation_memory: list[dict[str, object]] | None = None


def run_interview(
    *,
    intent: str,
    run_id: str,
    output_dir: Path,
    answers: list[str] | None = None,
    auto_confirm: bool = True,
    budget_tracker: InterviewBudget | None = None,
    avocat: Avocat | None = None,
) -> InterviewRunResult:
    """Run the deterministic three-agent interview loop.

    Passing ``answers`` means the caller owns the transcript; defaults are only
    used by unattended build-style callers.
    """
    from mobius.workflow.adaptive_questions import next_question
    from mobius.workflow.interview import compute_ambiguity_score, evaluate_interview_contract
    from mobius.workflow.interview_memory import ConversationMemory, InterviewRoundMemory

    output_dir.mkdir(parents=True, exist_ok=True)
    transcript_path = output_dir / "transcript.md"
    fixture_path = output_dir / "fixture.yaml"
    transcript = TranscriptWriter(transcript_path)
    budget = BudgetTracker() if budget_tracker is None else budget_tracker
    avocat_adapter = DeterministicAvocat() if avocat is None else avocat
    human_answers = answers or _default_answers(intent)
    justifications: list[str] = []
    constraints: list[str] = []
    success: list[str] = []
    fixture = _fixture_for_turn(intent, constraints=constraints, success=success)
    socrate_proposed = False
    human_confirmed = False
    memory = ConversationMemory()

    for turn_index, answer in enumerate(human_answers, start=1):
        parsed = parse_keystroke(answer)
        if parsed is not None and parsed.kind is Keystroke.RESTART:
            constraints.clear()
            success.clear()
            justifications.clear()
            memory = ConversationMemory()
            continue

        _apply_answer(answer, constraints=constraints, success=success)
        fixture = _fixture_for_turn(intent, constraints=constraints, success=success)
        score = compute_ambiguity_score(fixture)
        contract = evaluate_interview_contract(fixture, score=score, deep_metadata={})
        adaptive = next_question(
            fixture=fixture,
            score=score,
            contract=contract,
            memory=memory,
        )
        candidate = QuestionCandidate(
            question=adaptive.prompt,
            because=adaptive.because,
            key=adaptive.key,
        )
        convergence_ready = convergence_conditions_met(fixture)
        if parsed is not None and parsed.kind is Keystroke.STOP:
            human_confirmed = False
            break
        socrate = propose_question(
            turn_index,
            justifications,
            convergence_ready=convergence_ready,
            candidates=(candidate,),
        )
        if socrate.lemma_check is not None and not socrate.lemma_check.passed:
            # The fallback in Socrate should prevent this in normal operation,
            # but blocked turns are simply not recorded as successful rationales.
            pass
        else:
            justifications.append(socrate.because)
        socrate_proposed = socrate.proposes_done
        human_confirmed = bool(auto_confirm and socrate.proposes_done and convergence_ready)
        if parsed is not None and parsed.kind is Keystroke.ENOUGH:
            human_confirmed = bool(socrate.proposes_done and convergence_ready)
        avocat_statement = avocat_adapter.inject_edge_case(turn_index, intent)
        options = propose_options(intent, turn_index)
        transcript.append_turn(
            TranscriptTurn(
                turn=turn_index,
                socrate=socrate.question,
                because=socrate.because,
                human=answer,
                avocat=avocat_statement.statement,
                architecte=tuple(f"{option.name}: {option.trade_off}" for option in options),
            )
        )
        if socrate.question == adaptive.prompt and socrate.because == adaptive.because:
            memory = memory.record(
                InterviewRoundMemory(
                    round_index=turn_index,
                    question_key=adaptive.key,
                    question=adaptive.prompt,
                    answer=answer,
                    because=adaptive.because,
                    routing_path="v3a",
                    source="socrate",
                    ambiguity_before=score.score,
                    ambiguity_after=score.score,
                    closure_blockers=contract.closure_blockers,
                )
            )
        budget.record_mock_turn()
        if convergence_ready and socrate_proposed and human_confirmed:
            break

    score = compute_ambiguity_score(fixture)
    _write_fixture(fixture_path, fixture)
    return InterviewRunResult(
        run_id=run_id,
        transcript_path=transcript_path,
        fixture_path=fixture_path,
        fixture=fixture,
        turns=len(justifications),
        ambiguity_score=score.score,
        max_component=max(score.components.values(), default=1.0),
        socrate_proposed_done=socrate_proposed,
        human_confirmed=human_confirmed,
        usd_spent=budget.usd_spent,
        question_ledger=None,
        conversation_memory=None,
    )


def run_live_interview(
    *,
    intent: str,
    run_id: str,
    output_dir: Path,
    initial_fixture: InterviewFixture,
    stdin: TextIO | None = None,
    stderr: TextIO | None = None,
    max_turns: int = 100,
    budget_tracker: InterviewBudget | None = None,
    avocat: Avocat | None = None,
) -> InterviewRunResult:
    """Run a real turn-by-turn Socratic v3a interview.

    Unlike ``run_interview(..., answers=None)``, this function never falls back
    to synthetic defaults. It prints exactly one Socrate question, reads one
    human answer, updates the fixture/memory, then computes the next question.
    """
    from mobius.workflow.adaptive_questions import next_question
    from mobius.workflow.interview import (
        build_interview_handoff_metadata,
        compute_ambiguity_score,
        evaluate_interview_contract,
        infer_interview_contract_metadata,
    )
    from mobius.workflow.interview_memory import ConversationMemory, InterviewRoundMemory

    in_stream = stdin if stdin is not None else sys.stdin
    err = stderr if stderr is not None else sys.stderr
    output_dir.mkdir(parents=True, exist_ok=True)
    transcript_path = output_dir / "transcript.md"
    fixture_path = output_dir / "fixture.yaml"
    transcript = TranscriptWriter(transcript_path)
    budget = BudgetTracker() if budget_tracker is None else budget_tracker
    avocat_adapter = DeterministicAvocat() if avocat is None else avocat

    fixture = _clean_initial_fixture(initial_fixture, intent)
    justifications: list[str] = []
    memory = ConversationMemory()
    question_ledger: list[dict[str, object]] = []
    socrate_proposed = False
    human_confirmed = False

    from mobius.workflow.context_detector import format_detected_facts, scan_workspace_context
    from mobius.workflow.interview_milestones import milestone_from_score, milestone_progress_bar
    from mobius.workflow.interview_types import RhythmGuardState, RoutingDecision, RoutingPath
    from mobius.workflow.question_router import (
        InterviewQuestion,
        build_question_envelope,
        route_question,
    )

    ctx = scan_workspace_context(Path.cwd())
    detected_lines = format_detected_facts(ctx)
    rhythm = RhythmGuardState()

    err.write("# Mobius interview — Socrate pose une question à la fois.\n")
    if detected_lines:
        err.write("# Faits détectés dans le workspace\n")
        for _line in detected_lines:
            err.write(f"  {_line}\n")
    err.flush()
    for turn_index in range(1, max_turns + 1):
        score_before = compute_ambiguity_score(fixture)
        contract_before = evaluate_interview_contract(
            fixture,
            score=score_before,
            deep_metadata=infer_interview_contract_metadata(fixture),
        )
        adaptive = next_question(
            fixture=fixture,
            score=score_before,
            contract=contract_before,
            memory=memory,
        )

        interview_q = InterviewQuestion(
            key=adaptive.key,
            category=adaptive.branch,
            label=adaptive.prompt,
        )
        decision = route_question(interview_q, ctx)
        if rhythm.must_force_human and decision.path not in {
            RoutingPath.HUMAN_JUDGMENT,
            RoutingPath.CODE_PLUS_JUDGMENT,
        }:
            decision = RoutingDecision(
                path=RoutingPath.HUMAN_JUDGMENT,
                rationale="rhythm guard: forçage humain après auto-confirms consécutifs",
            )

        if decision.path is RoutingPath.AUTO_CONFIRM:
            auto_answer = ctx.get_answer(adaptive.key)
            if auto_answer:
                source = (
                    ", ".join(ctx.detected_manifests) if ctx.detected_manifests else "workspace"
                )
                err.write(f"  Détecté: {auto_answer} ({source})\n")
                ms = milestone_from_score(score_before)
                err.write(f"  {milestone_progress_bar(ms)}\n")
                err.flush()
                rhythm.record(RoutingPath.AUTO_CONFIRM)
                fixture = _apply_live_answer(fixture, question_key=adaptive.key, answer=auto_answer)
                budget.record_mock_turn()
                continue

        envelope = build_question_envelope(interview_q, decision, ctx)
        suggestions = envelope.suggested_options

        latest_answer = memory.rounds[-1].answer if memory.rounds else ""
        question_prompt = _question_with_answer_context(adaptive.prompt, latest_answer)
        convergence_ready = (
            len(memory.rounds) > 0
            and convergence_conditions_met(fixture)
            and contract_before.seed_ready
        )
        socrate = propose_question(
            turn_index,
            justifications,
            convergence_ready=convergence_ready,
            candidates=(
                QuestionCandidate(
                    question=question_prompt,
                    because=adaptive.because,
                    key=adaptive.key,
                ),
            ),
        )
        socrate_proposed = socrate.proposes_done
        err.write(f"Question: {socrate.question}\n")
        _write_keystroke_footer(err)
        if suggestions:
            answer = _prompt_live_suggestion(err, in_stream, "", suggestions=suggestions)
            if answer is None:
                break
        else:
            err.write("> ")
            err.flush()
            raw = in_stream.readline()
            if raw == "":
                break
            answer = raw.rstrip("\n").strip()
        rhythm.record(decision.path)
        if not answer:
            continue
        parsed = parse_keystroke(answer)
        if parsed is not None and parsed.kind is Keystroke.RESTART:
            fixture = _clean_initial_fixture(initial_fixture, intent)
            justifications.clear()
            memory = ConversationMemory()
            question_ledger.clear()
            continue
        if parsed is not None and parsed.kind is Keystroke.STOP:
            break
        if parsed is not None and parsed.kind is Keystroke.ENOUGH:
            if convergence_ready:
                human_confirmed = True
                break
            err.write("# Pas encore seed-ready: je dois fermer les blocages avant d'arrêter.\n")
            err.flush()
            continue

        fixture = _apply_live_answer(fixture, question_key=adaptive.key, answer=answer)
        score_after = compute_ambiguity_score(fixture)
        contract_after = evaluate_interview_contract(
            fixture,
            score=score_after,
            deep_metadata=infer_interview_contract_metadata(fixture),
        )
        next_adaptive = next_question(
            fixture=fixture,
            score=score_after,
            contract=contract_after,
            memory=memory,
        )
        next_prompt = _question_with_answer_context(next_adaptive.prompt, answer)
        round_memory = InterviewRoundMemory(
            round_index=turn_index,
            question_key=adaptive.key,
            question=socrate.question,
            answer=answer,
            because=socrate.because,
            routing_path="v3a_live",
            source="socrate",
            ambiguity_before=score_before.score,
            ambiguity_after=score_after.score,
            closure_blockers=contract_after.closure_blockers,
            next_question=next_prompt,
            open_decisions=contract_after.closure_blockers,
            branch=adaptive.branch,
        )
        memory = memory.record(round_memory)
        question_ledger.append(
            {
                "ordinal": turn_index,
                "key": adaptive.key,
                "category": adaptive.branch,
                "question": socrate.question,
                "because": socrate.because,
                "answer": {
                    "answered": True,
                    "kind": "text",
                    "text": answer,
                },
                "next_question": next_prompt,
                "routing_path": "v3a_live",
            }
        )
        if socrate.lemma_check is None or socrate.lemma_check.passed:
            justifications.append(socrate.because)
        avocat_statement = avocat_adapter.inject_edge_case(turn_index, intent)
        options = propose_options(intent, turn_index)
        transcript.append_turn(
            TranscriptTurn(
                turn=turn_index,
                socrate=socrate.question,
                because=socrate.because,
                human=answer,
                avocat=avocat_statement.statement,
                architecte=tuple(f"{option.name}: {option.trade_off}" for option in options),
            )
        )
        budget.record_mock_turn()

    score = compute_ambiguity_score(fixture)
    contract = evaluate_interview_contract(
        fixture,
        score=score,
        deep_metadata=infer_interview_contract_metadata(fixture),
    )
    # Keep the helper referenced here so live metadata stays aligned with the
    # shared closure contract even when callers add fields around it.
    build_interview_handoff_metadata(fixture, contract)
    _write_fixture(fixture_path, fixture)
    return InterviewRunResult(
        run_id=run_id,
        transcript_path=transcript_path,
        fixture_path=fixture_path,
        fixture=fixture,
        turns=len(memory.rounds),
        ambiguity_score=score.score,
        max_component=max(score.components.values(), default=1.0),
        socrate_proposed_done=socrate_proposed,
        human_confirmed=human_confirmed,
        usd_spent=budget.usd_spent,
        question_ledger=question_ledger,
        conversation_memory=memory.to_payload(),
    )


def _fixture_for_turn(
    intent: str, *, constraints: list[str], success: list[str]
) -> InterviewFixture:
    from mobius.workflow.interview import InterviewFixture

    return InterviewFixture(
        project_type="greenfield",
        goal=_goal_from_intent(intent),
        constraints=list(constraints) or ["Respect the user's stated product intent."],
        success=list(success) or ["A working implementation can be verified end-to-end."],
        context="",
        template="cli" if "cli" in intent.lower() or "todo" in intent.lower() else "blank",
    )


def _goal_from_intent(intent: str) -> str:
    text = intent.strip() or "Build a small useful product from an interactive brief."
    if len(text.split()) < 5:
        return f"Build {text} with clear behavior and verifiable outcomes."
    return text


def _default_answers(intent: str) -> list[str]:
    noun = "TODO CLI" if "todo" in intent.lower() else "product"
    return [
        f"Ship the first usable {noun} workflow.",
        "Primary entrypoint is a command-line command with deterministic output.",
        "Keep state local, avoid network services, and preserve clear error messages.",
        "Empty input returns a helpful validation error instead of silent success.",
        "End-to-end test creates one item, lists it, completes it, and verifies output.",
        "Support a small vocabulary: add, list, done, empty, duplicate, malformed.",
        ":enough",
    ]


def _apply_answer(answer: str, *, constraints: list[str], success: list[str]) -> None:
    lowered = answer.lower()
    if lowered.startswith(":"):
        return
    if any(word in lowered for word in ("avoid", "preserve", "keep", "must", "never")):
        constraints.append(answer)
    elif any(word in lowered for word in ("test", "verify", "success", "output")):
        success.append(answer)
    else:
        success.append(f"Product behavior includes: {answer}")


def _clean_initial_fixture(fixture: InterviewFixture, intent: str) -> InterviewFixture:
    from mobius.workflow.interview import InterviewFixture
    from mobius.workflow.templates import find_placeholder_strings

    placeholders = set(
        find_placeholder_strings(
            goal=fixture.goal,
            constraints=fixture.constraints,
            success_criteria=fixture.success,
        )
    )
    goal = "" if fixture.goal in placeholders else fixture.goal
    if intent in placeholders:
        intent = ""
    return InterviewFixture(
        project_type=fixture.project_type,
        goal=_goal_from_intent(goal or intent) if goal or intent else "",
        constraints=[item for item in fixture.constraints if item not in placeholders],
        success=[item for item in fixture.success if item not in placeholders],
        context=fixture.context,
        template=fixture.template,
    )


def _apply_live_answer(
    fixture: InterviewFixture,
    *,
    question_key: str,
    answer: str,
) -> InterviewFixture:
    from mobius.workflow.interview import InterviewFixture

    constraints = list(fixture.constraints)
    success = list(fixture.success)
    goal = fixture.goal
    if question_key == "goal" or not goal.strip():
        goal = _goal_from_intent(answer)
    elif question_key in {"constraints", "non_goals", "decision_boundaries"}:
        constraints.append(answer)
    elif question_key == "success":
        success.append(answer)
    else:
        _apply_answer(answer, constraints=constraints, success=success)
    return InterviewFixture(
        project_type=fixture.project_type,
        goal=goal,
        constraints=list(dict.fromkeys(constraints)),
        success=list(dict.fromkeys(success)),
        context=fixture.context,
        template=fixture.template,
    )


def _question_with_answer_context(prompt: str, previous_answer: str) -> str:
    answer = previous_answer.strip()
    if not answer:
        return prompt
    excerpt = answer if len(answer) <= 80 else answer[:77].rstrip() + "..."
    return f"En tenant compte de « {excerpt} »: {prompt}"


def _write_keystroke_footer(err: TextIO) -> None:
    err.write("Commandes: :enough finir si prêt | :restart recommencer | :stop arrêter\n")


def _prompt_live_suggestion(
    err: TextIO,
    in_stream: TextIO,
    question: str,
    *,
    suggestions: list[str],
) -> str | None:
    err.write(f"\n{question}\n")
    for index, option in enumerate(suggestions, start=1):
        err.write(f"  [{index}] {option}\n")
    err.write(f"  ou tapez votre réponse (défaut: {suggestions[0]})\n")
    err.write("> ")
    err.flush()

    raw = in_stream.readline()
    if raw == "":
        return None

    stripped = raw.strip()
    if not stripped:
        return suggestions[0]
    if stripped.isdigit():
        choice = int(stripped)
        if 1 <= choice <= len(suggestions):
            return suggestions[choice - 1]
    return stripped


def _write_fixture(path: Path, fixture: InterviewFixture) -> None:
    project_type = str(fixture.project_type)
    goal = str(fixture.goal)
    constraints = [str(item) for item in fixture.constraints]
    success = [str(item) for item in fixture.success]
    context = str(fixture.context)
    template = str(fixture.template)
    lines = [
        f"project_type: {_yaml_scalar(project_type)}",
        f"goal: {_yaml_scalar(goal)}",
        "constraints:",
        *[f"  - {_yaml_scalar(item)}" for item in constraints],
        "success:",
        *[f"  - {_yaml_scalar(item)}" for item in success],
        f"context: {_yaml_scalar(context)}",
        f"template: {_yaml_scalar(template)}",
    ]
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
