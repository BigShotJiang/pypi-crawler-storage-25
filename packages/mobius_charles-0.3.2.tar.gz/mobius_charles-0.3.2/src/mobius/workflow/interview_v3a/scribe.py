"""Phase 2 scribe handoff from v3a fixtures to the v2 CLI writer."""

from __future__ import annotations

import os
from collections.abc import Callable
from dataclasses import dataclass
from datetime import UTC, datetime, timedelta
from pathlib import Path


@dataclass(frozen=True)
class SeedHandoffResult:
    """Résultat de l'invocation de la CLI interview v2 comme writer Phase 2."""

    spec_path: Path
    backup_path: Path | None
    command: tuple[str, ...]
    stdout: str
    stderr: str
    seed_command: tuple[str, ...]
    seed_stdout: str
    seed_stderr: str


def backup_spec_yaml(
    workspace: Path,
    *,
    now: Callable[[], datetime] | None = None,
) -> Path | None:
    """Move an existing ``spec.yaml`` aside with a unique UTC timestamp suffix."""
    spec_path = workspace / "spec.yaml"
    if not spec_path.exists():
        return None

    current = (now or _utc_now)()
    if current.tzinfo is None:
        current = current.replace(tzinfo=UTC)
    current = current.astimezone(UTC).replace(microsecond=0)
    while True:
        backup_path = workspace / f"spec.yaml.pre-build.{_format_utc_timestamp(current)}.bak"
        if not backup_path.exists():
            spec_path.replace(backup_path)
            return backup_path
        current += timedelta(seconds=1)


def run_seed_handoff(
    *, fixture_path: Path, workspace: Path, mobius_home: Path | None = None
) -> SeedHandoffResult:
    """Run v2's non-interactive interview command against a v3a fixture."""
    import subprocess

    resolved_workspace = workspace.expanduser().resolve()
    resolved_fixture = fixture_path.expanduser().resolve()
    backup_path = backup_spec_yaml(resolved_workspace)
    command = (
        "mobius",
        "interview",
        "--non-interactive",
        "--input",
        str(resolved_fixture),
    )
    env = os.environ.copy()
    if mobius_home is not None:
        env["MOBIUS_HOME"] = str(mobius_home.expanduser().resolve())
    completed = subprocess.run(
        list(command),
        cwd=resolved_workspace,
        check=True,
        capture_output=True,
        text=True,
        env=env,
    )
    spec_path = resolved_workspace / "spec.yaml"
    if backup_path is not None and _spec_richness(backup_path) > _spec_richness(spec_path):
        spec_path.replace(resolved_workspace / f"{spec_path.name}.thin-build.bak")
        spec_path.write_text(backup_path.read_text(encoding="utf-8"), encoding="utf-8")
    seed_command = ("mobius", "seed", str(spec_path), "--validate")
    seed_completed = subprocess.run(
        list(seed_command),
        cwd=resolved_workspace,
        check=True,
        capture_output=True,
        text=True,
        env=env,
    )
    return SeedHandoffResult(
        spec_path=spec_path,
        backup_path=backup_path,
        command=command,
        stdout=completed.stdout,
        stderr=completed.stderr,
        seed_command=seed_command,
        seed_stdout=seed_completed.stdout,
        seed_stderr=seed_completed.stderr,
    )


def _spec_richness(path: Path) -> int:
    try:
        text = path.read_text(encoding="utf-8")
    except OSError:
        return 0
    score = len([line for line in text.splitlines() if line.strip().startswith("- ")])
    for marker in (
        "risks:",
        "non_goals:",
        "verification_commands:",
        "matrix:",
        "artifacts:",
        "clarity_score:",
        "premortem:",
        "concepts:",
    ):
        if marker in text:
            score += 3
    return score


def _utc_now() -> datetime:
    return datetime.now(UTC)


def _format_utc_timestamp(value: datetime) -> str:
    return value.strftime("%Y-%m-%dT%H-%M-%SZ")
