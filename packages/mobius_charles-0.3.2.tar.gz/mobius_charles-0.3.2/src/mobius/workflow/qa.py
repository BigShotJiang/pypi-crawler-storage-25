"""Deterministic offline QA heuristics for Mobius runs."""

from __future__ import annotations

import json
import os
import sys
import time
import urllib.error
import urllib.request
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass
from enum import StrEnum
from pathlib import Path
from typing import Any, Protocol

from pydantic import BaseModel, ConfigDict, Field

from mobius.persistence.event_store import EventRecord, EventStore
from mobius.workflow.criterion_match import (
    command_matches,
    references_for,
)
from mobius.workflow.lifecycle import is_terminal_state
from mobius.workflow.seed import (
    SeedSpec,
    SeedSpecValidationError,
    SpecGrade,
    assign_bronze_grade,
    load_seed_spec,
)
from mobius.workflow.session_facts import (
    SessionFacts,
    decode_json_object,
    parent_id_from_metadata,
    read_session_facts,
    spec_path_from_events,
    spec_path_from_session,
)
from mobius.workflow.verify import ProofRecord, run_verification

_decode_json_object = decode_json_object
_FAILURE_EVENT_TYPES = frozenset({"run.failed", "run.crashed", "run.cancelled", "run.interrupted"})
_MAX_VERIFICATION_WORKERS = 4


class Verdict(StrEnum):
    """QA verdict with worst-wins ordering."""

    PASS = "pass"
    FAIL = "fail"
    UNVERIFIED = "unverified"
    UNCERTAIN = "uncertain"


class SemanticVerdict(StrEnum):
    """Verdict returned by the optional online semantic judge."""

    PASS = "pass"
    FAIL = "fail"
    UNCERTAIN = "uncertain"


@dataclass(frozen=True)
class SemanticJudgeRequest:
    """One criterion-level online semantic judge request."""

    criterion_index: int
    criterion: str
    prompt: str


@dataclass(frozen=True)
class SemanticJudgeResult:
    """One criterion-level online semantic judge result."""

    verdict: SemanticVerdict
    justification: str
    model: str


class SemanticJudge(Protocol):
    """Callable interface for optional online semantic judgment."""

    def __call__(self, request: SemanticJudgeRequest) -> SemanticJudgeResult:
        """Evaluate one criterion semantically."""


class QASummary(BaseModel):
    """Aggregate QA verdict counts."""

    model_config = ConfigDict(extra="forbid")

    total: int
    passed: int
    failed: int
    unverified: int
    global_verdict: Verdict


class QAResult(BaseModel):
    """One deterministic QA check result."""

    model_config = ConfigDict(extra="forbid")

    id: str
    label: str
    verdict: Verdict
    detail: str
    output: str | None = None

    @property
    def passed(self) -> bool:
        """Return whether this result is a passing verdict."""
        return self.verdict == Verdict.PASS


class QAVerificationSuggestion(BaseModel):
    """Copyable verification command proposal for an unlinked criterion."""

    model_config = ConfigDict(extra="forbid")

    criterion_id: str
    criterion_index: int
    criterion_ref: str
    command: str
    rationale: str


class DeltaChange(StrEnum):
    """Classification du changement d'un critère entre deux runs."""

    STABLE = "stable"
    IMPROVED = "improved"
    REGRESSED = "regressed"
    STILL_FAILING = "still_failing"
    NEW = "new"


class QADelta(BaseModel):
    """Delta d'un critère entre le run courant et son parent."""

    model_config = ConfigDict(extra="forbid")

    criterion_id: str
    label: str
    previous_verdict: Verdict | None
    current_verdict: Verdict
    change: DeltaChange


class QAProgression(BaseModel):
    """Score de progression global entre deux runs."""

    model_config = ConfigDict(extra="forbid")

    parent_run_id: str
    previous_passed: int
    previous_total: int
    current_passed: int
    current_total: int
    regressions: int


class QAExecutionStats(BaseModel):
    """Timing summary for proof-based QA command execution."""

    model_config = ConfigDict(extra="forbid")

    total_duration_ms: int
    sequential_duration_ms: int
    speedup_vs_sequential: float


class QAReport(BaseModel):
    """Structured output for ``mobius qa``."""

    model_config = ConfigDict(extra="forbid")

    run_id: str
    mode: str
    state: str
    summary: QASummary
    results: list[QAResult]
    grade: str | None = None
    delta: list[QADelta] | None = None
    progression: QAProgression | None = None
    execution: QAExecutionStats | None = None
    suggestions: list[QAVerificationSuggestion] = Field(default_factory=list)


@dataclass(frozen=True)
class _CriteriaEvaluation:
    """Structured internal result for criterion proof checks."""

    results: list[QAResult]
    linked_count: int
    malformed_count: int
    execution: QAExecutionStats | None = None


@dataclass(frozen=True)
class _CriterionVerificationTask:
    """One criterion plus the commands that verify it."""

    index: int
    criterion: str
    command_specs: list[dict[str, Any]]
    spec_root: Path
    config: dict[str, Any]


@dataclass(frozen=True)
class _CriterionVerificationOutcome:
    """Result of running one criterion's verification commands."""

    result: QAResult
    proofs: list[ProofRecord]
    malformed: bool


def evaluate_run_qa(
    event_store_path: Path,
    run_id: str,
    *,
    online: bool = False,
    suggest: bool = False,
    semantic_judge: SemanticJudge | None = None,
    sequential: bool = False,
    max_workers: int | None = None,
) -> QAReport | None:
    """Evaluate a run with local, deterministic heuristics.

    The offline judge intentionally does not call an LLM. It checks the durable
    event-store facts that indicate a run reached a successful terminal state
    and that its seed spec contains acceptance criteria to judge against.
    """
    with EventStore(event_store_path) as store:
        session = read_session_facts(store, run_id)
        if session is None:
            return None
        events = store.read_events(run_id)

    state = session.status
    spec_criteria_count = _load_success_criteria_count(events, session)
    event_types = {event.type for event in events}
    failure_events = sorted(event_types & _FAILURE_EVENT_TYPES)

    results = [
        QAResult(
            id="session_terminal",
            label="Session reached a terminal state",
            verdict=_bool_verdict(is_terminal_state(state)),
            detail=f"state={state}",
        ),
        QAResult(
            id="run_completed_successfully",
            label="Run completed successfully",
            verdict=_bool_verdict(state == "completed"),
            detail=f"state={state}",
        ),
        QAResult(
            id="event_stream_started",
            label="Event stream contains run.started",
            verdict=_bool_verdict("run.started" in event_types),
            detail=_event_detail("run.started", event_types),
        ),
        QAResult(
            id="event_stream_completed",
            label="Event stream contains run.completed",
            verdict=_bool_verdict("run.completed" in event_types),
            detail=_event_detail("run.completed", event_types),
        ),
        QAResult(
            id="spec_has_success_criteria",
            label="Seed spec contains success criteria",
            verdict=_bool_verdict(spec_criteria_count > 0),
            detail=f"success_criteria={spec_criteria_count}",
        ),
        QAResult(
            id="no_failure_events",
            label="Event stream contains no failure events",
            verdict=_bool_verdict(not failure_events),
            detail=("none" if not failure_events else f"failure_events={','.join(failure_events)}"),
        ),
    ]
    if online:
        criteria_evaluation = _evaluate_success_criteria_online(
            event_store_path,
            run_id,
            events,
            session,
            semantic_judge=semantic_judge,
        )
    else:
        criteria_evaluation = _evaluate_success_criteria(
            event_store_path,
            run_id,
            events,
            session,
            sequential=sequential,
            max_workers=max_workers,
        )
    criterion_results = criteria_evaluation.results
    if not criterion_results and spec_criteria_count > 0:
        sentinel = QAResult(
            id="criteria_not_evaluated",
            label=f"{spec_criteria_count} critère(s) déclaré(s) mais non évaluable(s)",
            verdict=Verdict.UNVERIFIED,
            detail="spec introuvable ou invalide — les critères de succès n'ont pas été vérifiés",
        )
        criterion_results = [sentinel]
    results.extend(criterion_results)
    contract_result = _criteria_proof_contract_result(
        max(spec_criteria_count, len(criterion_results)),
        linked_count=criteria_evaluation.linked_count,
        malformed_count=criteria_evaluation.malformed_count,
    )
    if contract_result is not None:
        results.append(contract_result)
    summary = _summarize_results(results, criterion_results)
    suggestions = _suggest_verification_commands(events, session) if suggest else []
    grade = _assign_static_grade(events, session)
    if grade is not None:
        with EventStore(event_store_path) as store:
            store.append_event(run_id, "spec.grade_assigned", grade.to_event_payload())
            try:
                store.append_event(
                    run_id,
                    "qa.completed",
                    {
                        "summary": summary.model_dump(mode="json"),
                        "results": [
                            result.model_dump(mode="json")
                            for result in _persisted_qa_results(criterion_results, contract_result)
                        ],
                    },
                )
            except Exception as exc:
                sys.stderr.write(f"mobius: could not record QA completion events: {exc}\n")
    delta_list: list[QADelta] | None = None
    progression: QAProgression | None = None
    parent_id = parent_id_from_metadata(session.metadata)
    if parent_id and criterion_results:
        parent_verdicts = _load_parent_criterion_verdicts(event_store_path, parent_id)
        if parent_verdicts is not None:
            delta_list = _compute_delta(criterion_results, parent_verdicts)
            progression = _compute_progression(
                parent_id, delta_list, parent_verdicts, criterion_results
            )

    return QAReport(
        run_id=run_id,
        mode="online" if online else "offline",
        state=state,
        summary=summary,
        results=results,
        grade=grade.grade if grade is not None else None,
        delta=delta_list,
        progression=progression,
        execution=criteria_evaluation.execution,
        suggestions=suggestions,
    )


def _criteria_proof_contract_result(
    spec_criteria_count: int, *, linked_count: int, malformed_count: int
) -> QAResult | None:
    """Return the deterministic semantic contract check for QA depth.

    Mobius does not guess whether an implementation "sounds" aligned with the
    goal. It requires each success criterion to be bound to executable evidence:
    either a linked verification command or a global/suite verification command.
    Missing links are reported as ``UNVERIFIED``; malformed commands are ``FAIL``.
    """
    if spec_criteria_count <= 0:
        return None

    expected = max(spec_criteria_count, linked_count)
    unlinked = max(expected - linked_count, 0)
    if malformed_count:
        verdict = Verdict.FAIL
    elif unlinked:
        verdict = Verdict.UNVERIFIED
    else:
        verdict = Verdict.PASS

    return QAResult(
        id="semantic_proof_contract",
        label="Contrat sémantique déterministe: critères liés à des preuves",
        verdict=verdict,
        detail=(
            f"linked={linked_count}/{expected}, "
            f"unlinked={unlinked}, malformed={malformed_count}"
        ),
    )


def _persisted_qa_results(
    criterion_results: list[QAResult], contract_result: QAResult | None
) -> list[QAResult]:
    """Return QA results persisted for lineage/durable evidence."""
    if contract_result is None:
        return criterion_results
    return [*criterion_results, contract_result]


def _load_parent_criterion_verdicts(
    event_store_path: Path, parent_id: str
) -> dict[str, Verdict] | None:
    """Charge les verdicts QA du run parent depuis l'événement qa.completed."""
    with EventStore(event_store_path) as store:
        parent_events = store.read_events(parent_id)
    for event in reversed(parent_events):
        if event.type != "qa.completed":
            continue
        payload = decode_json_object(event.payload)
        raw_results = payload.get("results")
        if not isinstance(raw_results, list):
            return None
        verdicts: dict[str, Verdict] = {}
        for raw in raw_results:
            if (
                isinstance(raw, dict)
                and "id" in raw
                and "verdict" in raw
                and str(raw["id"]).startswith("criterion_")
            ):
                try:
                    verdicts[str(raw["id"])] = Verdict(str(raw["verdict"]))
                except ValueError:
                    continue
        return verdicts if verdicts else None
    return None


def _classify_change(previous: Verdict | None, current: Verdict) -> DeltaChange:
    if previous is None:
        return DeltaChange.NEW
    if previous == Verdict.PASS and current == Verdict.PASS:
        return DeltaChange.STABLE
    if previous == Verdict.PASS and current != Verdict.PASS:
        return DeltaChange.REGRESSED
    if previous != Verdict.PASS and current == Verdict.PASS:
        return DeltaChange.IMPROVED
    return DeltaChange.STILL_FAILING


def _compute_delta(
    criterion_results: list[QAResult],
    parent_verdicts: dict[str, Verdict],
) -> list[QADelta]:
    deltas: list[QADelta] = []
    for result in criterion_results:
        previous = parent_verdicts.get(result.id)
        change = _classify_change(previous, result.verdict)
        deltas.append(
            QADelta(
                criterion_id=result.id,
                label=result.label,
                previous_verdict=previous,
                current_verdict=result.verdict,
                change=change,
            )
        )
    return deltas


def _compute_progression(
    parent_id: str,
    delta_list: list[QADelta],
    parent_verdicts: dict[str, Verdict],
    criterion_results: list[QAResult],
) -> QAProgression:
    parent_criterion_verdicts = {
        key: verdict for key, verdict in parent_verdicts.items() if key.startswith("criterion_")
    }
    previous_passed = sum(1 for v in parent_criterion_verdicts.values() if v == Verdict.PASS)
    current_passed = sum(1 for r in criterion_results if r.verdict == Verdict.PASS)
    regressions = sum(1 for d in delta_list if d.change == DeltaChange.REGRESSED)
    return QAProgression(
        parent_run_id=parent_id,
        previous_passed=previous_passed,
        previous_total=len(parent_criterion_verdicts),
        current_passed=current_passed,
        current_total=len(criterion_results),
        regressions=regressions,
    )


def _load_success_criteria_count(events: list[EventRecord], session: SessionFacts) -> int:
    """Return how many success criteria the seed spec declares.

    Prefers the durable count emitted by ``run.completed`` (set once a run
    has executed). Falls back to parsing the seed spec on disk so the check
    still works for runs that have only been seeded — otherwise QA would
    report ``success_criteria=0`` while simultaneously listing those same
    criteria as ``unverified``.
    """
    for event in reversed(events):
        if event.type != "run.completed":
            continue
        payload = decode_json_object(event.payload)
        count = payload.get("success_criteria_count")
        if isinstance(count, int):
            return count
    spec_path = spec_path_from_session(session) or spec_path_from_events(events)
    if spec_path is None:
        return 0
    try:
        spec = load_seed_spec(spec_path)
    except (OSError, SeedSpecValidationError):
        return 0
    return len(spec.success_criteria)


def assign_silver_grade(spec: SeedSpec) -> SpecGrade:
    """Assign the highest static grade available to a parsed spec.

    Silver requires all Bronze checks plus at least one verification command
    linked to every success criterion, at least one non-goal, and an owner.
    """
    bronze = assign_bronze_grade(spec)
    linked_criteria = _success_criteria_with_commands(spec)
    details = {
        **bronze.details,
        "all_success_criteria_linked": linked_criteria == len(spec.success_criteria),
        "non_goals_present": len(spec.non_goals) >= 1,
        "owner_present": _owner_present(spec.owner),
    }
    criteria_met = sum(1 for passed in details.values() if passed)
    grade = "silver" if criteria_met == len(details) else bronze.grade
    return SpecGrade(
        grade=grade,
        criteria_met=criteria_met,
        criteria_total=len(details),
        details=details,
    )


def _assign_static_grade(events: list[EventRecord], session: SessionFacts) -> SpecGrade | None:
    spec_path = spec_path_from_session(session) or spec_path_from_events(events)
    if spec_path is None:
        return None
    try:
        spec = load_seed_spec(spec_path)
    except (OSError, SeedSpecValidationError):
        return None
    return assign_silver_grade(spec)


def _evaluate_success_criteria(
    event_store_path: Path,
    run_id: str,
    events: list[EventRecord],
    session: SessionFacts,
    *,
    sequential: bool,
    max_workers: int | None,
) -> _CriteriaEvaluation:
    spec_path = spec_path_from_session(session) or spec_path_from_events(events)
    if spec_path is None:
        return _CriteriaEvaluation(results=[], linked_count=0, malformed_count=0)
    try:
        spec = load_seed_spec(spec_path)
    except (OSError, SeedSpecValidationError):
        return _CriteriaEvaluation(results=[], linked_count=0, malformed_count=0)

    config = _load_verification_config(event_store_path.parent)
    result_slots: dict[int, QAResult] = {}
    proof_slots: dict[int, list[ProofRecord]] = {}
    tasks: list[_CriterionVerificationTask] = []
    linked_count = 0
    malformed_count = 0
    for index, criterion in enumerate(spec.success_criteria, start=1):
        references = references_for(index, criterion)
        command_specs = [
            command
            for command in spec.verification_commands
            if command_matches(command, references) or _is_global_verification(command)
        ]
        if not command_specs:
            result_slots[index] = _unverified_criterion_result(index, criterion)
            continue
        linked_count += 1
        tasks.append(
            _CriterionVerificationTask(
                index=index,
                criterion=criterion,
                command_specs=command_specs,
                spec_root=spec_path.parent,
                config=config,
            )
        )

    started_at = time.monotonic()
    outcomes = _run_criterion_verification_tasks(
        tasks,
        sequential=sequential,
        max_workers=max_workers,
    )
    execution = _execution_stats_from_outcomes(outcomes, started_at)
    for outcome in outcomes:
        index = _criterion_index_from_id(outcome.result.id)
        result_slots[index] = outcome.result
        proof_slots[index] = outcome.proofs
        if outcome.malformed:
            malformed_count += 1

    with EventStore(event_store_path) as store:
        for index in sorted(proof_slots):
            for proof in proof_slots[index]:
                store.append_event(
                    run_id,
                    "qa.verification_executed",
                    proof.executed_event_payload(),
                )
                store.append_event(run_id, "qa.proof_collected", proof.proof_event_payload())
    return _CriteriaEvaluation(
        results=[result_slots[index] for index in sorted(result_slots)],
        linked_count=linked_count,
        malformed_count=malformed_count,
        execution=execution,
    )


def _execution_stats_from_outcomes(
    outcomes: list[_CriterionVerificationOutcome], started_at: float
) -> QAExecutionStats | None:
    proof_durations = [
        proof.duration_ms
        for outcome in outcomes
        for proof in outcome.proofs
        if proof.duration_ms >= 0
    ]
    if not proof_durations:
        return None
    total_duration_ms = max(0, round((time.monotonic() - started_at) * 1000))
    sequential_duration_ms = sum(proof_durations)
    speedup = (
        float(sequential_duration_ms) / max(total_duration_ms, 1)
        if sequential_duration_ms > 0
        else 1.0
    )
    return QAExecutionStats(
        total_duration_ms=total_duration_ms,
        sequential_duration_ms=sequential_duration_ms,
        speedup_vs_sequential=speedup,
    )


def _run_criterion_verification_tasks(
    tasks: list[_CriterionVerificationTask],
    *,
    sequential: bool,
    max_workers: int | None,
) -> list[_CriterionVerificationOutcome]:
    if not tasks:
        return []
    if sequential or len(tasks) == 1:
        return [_run_criterion_verification_task(task) for task in tasks]
    parallel_tasks = [task for task in tasks if not _task_requires_exclusive_execution(task)]
    exclusive_tasks = [task for task in tasks if _task_requires_exclusive_execution(task)]
    outcomes = _run_parallel_verification_batch(parallel_tasks, max_workers)
    outcomes.extend(_run_criterion_verification_task(task) for task in exclusive_tasks)
    return outcomes


def _run_parallel_verification_batch(
    tasks: list[_CriterionVerificationTask],
    max_workers: int | None,
) -> list[_CriterionVerificationOutcome]:
    if not tasks:
        return []
    if len(tasks) == 1:
        return [_run_criterion_verification_task(tasks[0])]
    worker_count = _bounded_worker_count(len(tasks), max_workers)
    with ThreadPoolExecutor(max_workers=worker_count) as executor:
        return list(executor.map(_run_criterion_verification_task, tasks))


def _task_requires_exclusive_execution(task: _CriterionVerificationTask) -> bool:
    return any(command_spec.get("sequential") is True for command_spec in task.command_specs)


def _bounded_worker_count(task_count: int, requested: int | None) -> int:
    if requested is not None and requested > 0:
        return min(task_count, requested, _MAX_VERIFICATION_WORKERS)
    return max(
        1,
        min(task_count, os.cpu_count() or _MAX_VERIFICATION_WORKERS, _MAX_VERIFICATION_WORKERS),
    )


def _run_criterion_verification_task(
    task: _CriterionVerificationTask,
) -> _CriterionVerificationOutcome:
    proofs: list[ProofRecord] = []
    for command_spec in task.command_specs:
        try:
            proof = run_verification(command_spec, task.spec_root, task.config)
        except ValueError as exc:
            return _CriterionVerificationOutcome(
                result=_malformed_command_result(task.index, task.criterion, exc),
                proofs=[],
                malformed=True,
            )
        proofs.append(proof)
    return _CriterionVerificationOutcome(
        result=_qa_result_from_proofs(task.index, task.criterion, proofs),
        proofs=proofs,
        malformed=False,
    )


def _criterion_index_from_id(result_id: str) -> int:
    try:
        return int(result_id.removeprefix("criterion_"))
    except ValueError:
        return 0


def _evaluate_success_criteria_online(
    event_store_path: Path,
    run_id: str,
    events: list[EventRecord],
    session: SessionFacts,
    *,
    semantic_judge: SemanticJudge | None,
) -> _CriteriaEvaluation:
    spec_path = spec_path_from_session(session) or spec_path_from_events(events)
    if spec_path is None:
        return _CriteriaEvaluation(results=[], linked_count=0, malformed_count=0)
    try:
        spec = load_seed_spec(spec_path)
    except (OSError, SeedSpecValidationError):
        return _CriteriaEvaluation(results=[], linked_count=0, malformed_count=0)

    judge = semantic_judge or EnvironmentSemanticJudge()
    code_context = _collect_code_context(spec_path)
    results: list[QAResult] = []
    with EventStore(event_store_path) as store:
        for index, criterion in enumerate(spec.success_criteria, start=1):
            prompt = _build_semantic_prompt(spec, index, criterion, code_context)
            request = SemanticJudgeRequest(
                criterion_index=index,
                criterion=criterion,
                prompt=prompt,
            )
            result = judge(request)
            store.append_event(
                run_id,
                "qa.semantic_verdict",
                {
                    "criterion_id": f"criterion_{index}",
                    "criterion_index": index,
                    "criterion": criterion,
                    "verdict": result.verdict.value,
                    "justification": result.justification,
                    "model": result.model,
                    "prompt": prompt,
                },
            )
            results.append(_qa_result_from_semantic_result(index, criterion, result))
    return _CriteriaEvaluation(
        results=results,
        linked_count=len(results),
        malformed_count=0,
    )


def _suggest_verification_commands(
    events: list[EventRecord],
    session: SessionFacts,
) -> list[QAVerificationSuggestion]:
    spec_path = spec_path_from_session(session) or spec_path_from_events(events)
    if spec_path is None:
        return []
    try:
        spec = load_seed_spec(spec_path)
    except (OSError, SeedSpecValidationError):
        return []

    suggestions: list[QAVerificationSuggestion] = []
    has_global = any(_is_global_verification(command) for command in spec.verification_commands)
    for index, criterion in enumerate(spec.success_criteria, start=1):
        references = references_for(index, criterion)
        has_linked_command = has_global or any(
            command_matches(command, references) for command in spec.verification_commands
        )
        if has_linked_command:
            continue
        command, rationale = _suggest_command_for_criterion(criterion)
        suggestions.append(
            QAVerificationSuggestion(
                criterion_id=f"criterion_{index}",
                criterion_index=index,
                criterion_ref=criterion,
                command=command,
                rationale=rationale,
            )
        )
    return suggestions


def _suggest_command_for_criterion(criterion: str) -> tuple[str, str]:
    text = criterion.lower()
    if "pytest" in text or "test" in text or "coverage" in text:
        keyword = _pytest_keyword(criterion)
        return (
            f"pytest tests/ -k {_shell_quote(keyword)} --tb=short -q",
            "Run a focused pytest selection for the criterion.",
        )
    grep_term = _grep_term(criterion)
    if grep_term:
        return (
            f"rg -n {_shell_quote(grep_term)} .",
            "Search the produced files for the expected visible symbol or text.",
        )
    return (
        "python -m pytest --tb=short -q",
        "Run the project test suite as a first executable proof for this criterion.",
    )


def _pytest_keyword(criterion: str) -> str:
    words = _criterion_words(criterion)
    lowered_words = [word.lower() for word in words]
    if "qa" in lowered_words:
        return "qa"
    preferred = [
        word
        for word in words
        if word.lower()
        not in {
            "pytest",
            "test",
            "tests",
            "passes",
            "pass",
            "coverage",
            "covers",
            "for",
            "the",
            "la",
            "le",
            "les",
        }
    ]
    return preferred[0] if preferred else "qa"


def _grep_term(criterion: str) -> str:
    words = _criterion_words(criterion)
    for word in words:
        if len(word) >= 4 and word[0].isupper() and not word.isupper():
            return word
    for word in words:
        if len(word) >= 4 and word.lower() not in {
            "cli",
            "output",
            "mentions",
            "prints",
            "contains",
            "affiche",
        }:
            return word
    return ""


def _criterion_words(criterion: str) -> list[str]:
    words: list[str] = []
    current: list[str] = []
    for char in criterion:
        if char.isalnum() or char in {"_", "-"}:
            current.append(char)
        elif current:
            words.append("".join(current))
            current = []
    if current:
        words.append("".join(current))
    return words


def _shell_quote(value: str) -> str:
    return "'" + value.replace("'", "'\"'\"'") + "'"


class EnvironmentSemanticJudge:
    """Optional OpenAI-compatible semantic judge using only the standard library."""

    def __call__(self, request: SemanticJudgeRequest) -> SemanticJudgeResult:
        mode = os.environ.get("MOBIUS_QA_LLM_MODE", "").strip().lower()
        model = os.environ.get("MOBIUS_QA_LLM_MODEL", "gpt-5.5").strip() or "gpt-5.5"
        if mode == "mock":
            return SemanticJudgeResult(
                verdict=SemanticVerdict.PASS,
                justification="mock semantic judge enabled by MOBIUS_QA_LLM_MODE=mock",
                model="mobius-qa-mock-judge",
            )
        endpoint = os.environ.get("MOBIUS_QA_LLM_ENDPOINT", "").strip()
        api_key = os.environ.get("MOBIUS_QA_LLM_API_KEY") or os.environ.get("OPENAI_API_KEY")
        if not endpoint and api_key:
            endpoint = "https://api.openai.com/v1/chat/completions"
        if not endpoint or not api_key:
            return SemanticJudgeResult(
                verdict=SemanticVerdict.UNCERTAIN,
                justification=(
                    "online semantic QA requested but no LLM endpoint/API key is configured"
                ),
                model="unconfigured",
            )

        payload = {
            "model": model,
            "messages": [{"role": "user", "content": request.prompt}],
            "temperature": 0,
            "response_format": {"type": "json_object"},
        }
        try:
            response = _post_json(endpoint, payload, api_key=api_key)
        except (OSError, TimeoutError, urllib.error.URLError, json.JSONDecodeError) as exc:
            return SemanticJudgeResult(
                verdict=SemanticVerdict.UNCERTAIN,
                justification=f"LLM request failed: {exc}",
                model=model,
            )
        return _semantic_result_from_provider_response(response, model)


def _post_json(endpoint: str, payload: dict[str, Any], *, api_key: str) -> dict[str, Any]:
    data = json.dumps(payload).encode("utf-8")
    request = urllib.request.Request(
        endpoint,
        data=data,
        headers={
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
        },
        method="POST",
    )
    with urllib.request.urlopen(request, timeout=60) as response:
        raw = response.read().decode("utf-8")
    decoded = json.loads(raw)
    return decoded if isinstance(decoded, dict) else {}


def _semantic_result_from_provider_response(
    response: dict[str, Any], fallback_model: str
) -> SemanticJudgeResult:
    model = str(response.get("model") or fallback_model)
    content = _provider_message_content(response)
    try:
        payload = json.loads(content)
    except json.JSONDecodeError:
        return SemanticJudgeResult(
            verdict=SemanticVerdict.UNCERTAIN,
            justification=content.strip() or "LLM response was not valid JSON",
            model=model,
        )
    raw_verdict = str(payload.get("verdict", "uncertain")).strip().lower()
    try:
        verdict = SemanticVerdict(raw_verdict)
    except ValueError:
        verdict = SemanticVerdict.UNCERTAIN
    justification = str(payload.get("justification", "")).strip()
    return SemanticJudgeResult(verdict=verdict, justification=justification, model=model)


def _provider_message_content(response: dict[str, Any]) -> str:
    choices = response.get("choices")
    if not isinstance(choices, list) or not choices:
        return ""
    first = choices[0]
    if not isinstance(first, dict):
        return ""
    message = first.get("message")
    if isinstance(message, dict):
        content = message.get("content")
        if isinstance(content, str):
            return content
    return ""


def _qa_result_from_semantic_result(
    index: int, criterion: str, result: SemanticJudgeResult
) -> QAResult:
    mapped = {
        SemanticVerdict.PASS: Verdict.PASS,
        SemanticVerdict.FAIL: Verdict.FAIL,
        SemanticVerdict.UNCERTAIN: Verdict.UNCERTAIN,
    }[result.verdict]
    return QAResult(
        id=f"criterion_{index}",
        label=f"Critère {index}: {criterion}",
        verdict=mapped,
        detail=f"semantic_{result.verdict.value} model={result.model}: {result.justification}",
    )


def _build_semantic_prompt(
    spec: SeedSpec,
    index: int,
    criterion: str,
    code_context: str,
) -> str:
    payload = {
        "instruction": (
            "Judge whether the produced code satisfies this single success criterion. "
            "Return strict JSON with verdict pass, fail, or uncertain and a justification."
        ),
        "goal": spec.goal,
        "constraints": spec.constraints,
        "criterion_index": index,
        "criterion": criterion,
        "context": spec.context,
        "produced_code": code_context,
        "expected_response_schema": {
            "verdict": "pass|fail|uncertain",
            "justification": "short reason grounded in the code",
        },
    }
    return json.dumps(payload, ensure_ascii=False, sort_keys=True, indent=2)


_CODE_CONTEXT_SUFFIXES = frozenset(
    {".py", ".js", ".ts", ".tsx", ".jsx", ".md", ".toml", ".yaml", ".yml", ".json"}
)
_CODE_CONTEXT_IGNORED_DIRS = frozenset(
    {".git", ".venv", ".mypy_cache", ".pytest_cache", ".ruff_cache", "__pycache__"}
)
_MAX_CODE_CONTEXT_BYTES = 20_000
_MAX_CODE_FILE_BYTES = 4_000


def _collect_code_context(spec_path: Path) -> str:
    root = spec_path.parent
    remaining = _MAX_CODE_CONTEXT_BYTES
    parts: list[str] = []
    for path in _iter_code_context_paths(root):
        if path == spec_path or remaining <= 0:
            continue
        try:
            text = path.read_text(encoding="utf-8")
        except (OSError, UnicodeDecodeError):
            continue
        snippet = text[: min(len(text), _MAX_CODE_FILE_BYTES, remaining)]
        remaining -= len(snippet.encode("utf-8"))
        rel = path.relative_to(root)
        parts.append(f"--- {rel} ---\n{snippet}")
    return "\n\n".join(parts) if parts else "(no produced code files found)"


def _iter_code_context_paths(root: Path) -> list[Path]:
    paths: list[Path] = []
    for path in root.rglob("*"):
        if not path.is_file():
            continue
        relative = path.relative_to(root)
        if any(
            part in _CODE_CONTEXT_IGNORED_DIRS or part.startswith(".")
            for part in relative.parts
        ):
            continue
        if path.suffix.lower() in _CODE_CONTEXT_SUFFIXES:
            paths.append(path)
    return sorted(paths, key=lambda item: str(item.relative_to(root)))


def _load_verification_config(mobius_home: Path) -> dict[str, Any]:
    config_path = mobius_home / "config.json"
    if not config_path.exists():
        return {}
    try:
        raw = json.loads(config_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}
    return dict(raw) if isinstance(raw, dict) else {}


def _is_global_verification(command: dict[str, Any]) -> bool:
    return str(command.get("scope", "")).strip().lower() in {"all", "global", "suite"}


_MAX_OUTPUT_LINES = 50


def _qa_result_from_proofs(index: int, criterion: str, proofs: list[ProofRecord]) -> QAResult:
    verdict = _worst_verdict(
        Verdict.PASS if proof.exit_code == 0 and not proof.timed_out else Verdict.FAIL
        for proof in proofs
    )
    proof_details = []
    output_parts: list[str] = []
    for proof in proofs:
        timeout_detail = ", timed_out=true" if proof.timed_out else ""
        truncated_detail = ", truncated=true" if proof.truncated else ""
        proof_details.append(
            f"{proof.command!r}: exit_code={proof.exit_code}, duration_ms={proof.duration_ms}"
            f"{timeout_detail}{truncated_detail}"
        )
        if proof.exit_code != 0 or proof.timed_out:
            output_parts.extend(_collect_proof_output(proof))
    output = "\n".join(output_parts)[-_MAX_OUTPUT_LINES * 200 :] if output_parts else None
    return QAResult(
        id=f"criterion_{index}",
        label=f"Critère {index}: {criterion}",
        verdict=verdict,
        detail="; ".join(proof_details),
        output=_tail_lines(output, _MAX_OUTPUT_LINES) if output else None,
    )


def _collect_proof_output(proof: ProofRecord) -> list[str]:
    parts: list[str] = []
    if proof.stdout.strip():
        parts.append(proof.stdout.strip())
    if proof.stderr.strip():
        parts.append(proof.stderr.strip())
    return parts


def _tail_lines(text: str, max_lines: int) -> str:
    lines = text.splitlines()
    if len(lines) <= max_lines:
        return text
    return "\n".join(lines[-max_lines:])


def _unverified_criterion_result(index: int, criterion: str) -> QAResult:
    return QAResult(
        id=f"criterion_{index}",
        label=f"Critère {index}: {criterion}",
        verdict=Verdict.UNVERIFIED,
        detail="no verification_command linked to this criterion",
    )


def _malformed_command_result(index: int, criterion: str, exc: ValueError) -> QAResult:
    return QAResult(
        id=f"criterion_{index}",
        label=f"Critère {index}: {criterion}",
        verdict=Verdict.FAIL,
        detail=f"malformed verification_command: {exc}",
    )


def _success_criteria_with_commands(spec: SeedSpec) -> int:
    linked = 0
    for index, criterion in enumerate(spec.success_criteria, start=1):
        references = references_for(index, criterion)
        if any(command_matches(command, references) for command in spec.verification_commands):
            linked += 1
    return linked


def _owner_present(owner: str | list[str]) -> bool:
    if isinstance(owner, list):
        return any(item.strip() for item in owner)
    return bool(owner.strip())


def _event_detail(event_type: str, event_types: set[str]) -> str:
    return "present" if event_type in event_types else f"missing {event_type}"


def _bool_verdict(passed: bool) -> Verdict:
    return Verdict.PASS if passed else Verdict.FAIL


def _summarize_results(results: list[QAResult], criterion_results: list[QAResult]) -> QASummary:
    counted_results = criterion_results if criterion_results else results
    passed = sum(1 for result in counted_results if result.verdict == Verdict.PASS)
    failed = sum(1 for result in counted_results if result.verdict == Verdict.FAIL)
    unverified = sum(
        1
        for result in counted_results
        if result.verdict in {Verdict.UNVERIFIED, Verdict.UNCERTAIN}
    )
    return QASummary(
        total=len(counted_results),
        passed=passed,
        failed=failed,
        unverified=unverified,
        global_verdict=_worst_verdict(result.verdict for result in results),
    )


def _worst_verdict(verdicts: Any) -> Verdict:
    worst = Verdict.PASS
    for verdict in verdicts:
        if verdict == Verdict.FAIL:
            return Verdict.FAIL
        if verdict in {Verdict.UNVERIFIED, Verdict.UNCERTAIN}:
            worst = Verdict.UNVERIFIED
    return worst
