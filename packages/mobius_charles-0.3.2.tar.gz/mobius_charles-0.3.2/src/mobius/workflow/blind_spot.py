"""Détecteur d'angles morts — audit de niveau 2 pour un projet Mobius.

Pas « est-ce que ça marche » (c'est le job de QA) mais
« est-ce qu'il manque quelque chose que personne ne demande ».
"""

from __future__ import annotations

import contextlib
import os
from dataclasses import asdict, dataclass, field
from pathlib import Path

from mobius.persistence.event_store import EventStore

IGNORE_DIRS = frozenset(
    {
        ".git",
        ".venv",
        "venv",
        "node_modules",
        "__pycache__",
        ".mypy_cache",
        ".pytest_cache",
        ".ruff_cache",
        "dist",
        "build",
        ".tox",
        ".eggs",
        "*.egg-info",
    }
)

SEVERITY_WEIGHTS = {"gap": 1.5, "warning": 0.8, "info": 0.0}


@dataclass(frozen=True, slots=True)
class Finding:
    """Un angle mort détecté."""

    id: str
    category: str
    severity: str
    message: str
    evidence: str
    why: str = ""
    impact: str = ""
    how: str = ""
    when: str = ""
    mermaid_before: str = ""
    mermaid_after: str = ""


@dataclass(slots=True)
class BlindSpotReport:
    """Rapport complet d'audit d'angles morts."""

    spec_path: str
    findings: list[Finding] = field(default_factory=list)
    score: float = 10.0
    total_checks: int = 0
    gaps: int = 0
    warnings: int = 0
    infos: int = 0

    def to_dict(self) -> dict[str, object]:
        return {
            "spec_path": self.spec_path,
            "score": round(self.score, 1),
            "total_checks": self.total_checks,
            "gaps": self.gaps,
            "warnings": self.warnings,
            "infos": self.infos,
            "findings": [asdict(f) for f in self.findings],
        }


def _int_fact(facts: dict[str, object], key: str, default: int = 0) -> int:
    value = facts.get(key, default)
    if isinstance(value, bool):
        return int(value)
    if isinstance(value, int):
        return value
    if isinstance(value, str):
        try:
            return int(value)
        except ValueError:
            return default
    return default


def _list_fact(facts: dict[str, object], key: str) -> list[object]:
    value = facts.get(key, [])
    return list(value) if isinstance(value, list) else []


def _large_files_fact(facts: dict[str, object]) -> list[tuple[str, int]]:
    files: list[tuple[str, int]] = []
    for item in _list_fact(facts, "large_files"):
        if not isinstance(item, tuple) or len(item) != 2:
            continue
        path, lines = item
        if isinstance(path, str) and isinstance(lines, int):
            files.append((path, lines))
    return files


def run_blind_spot_scan(
    workspace: Path,
    spec_path: Path | None = None,
    event_store_path: Path | None = None,
) -> BlindSpotReport:
    """Exécuter l'audit d'angles morts sur un workspace."""
    report = BlindSpotReport(spec_path=str(spec_path or ""))

    spec_data = _load_spec(spec_path) if spec_path and spec_path.exists() else {}
    repo_facts = _scan_workspace(workspace)

    _check_spec_gaps(report, spec_data)
    _check_repo_hygiene(report, repo_facts)
    _check_stack_patterns(report, repo_facts, spec_data)
    _check_mobius_gaps(report, spec_data, event_store_path)
    _check_ux_gaps(report, repo_facts, spec_data)
    _check_security(report, repo_facts, spec_data)
    _check_quality(report, repo_facts, spec_data)
    _check_docs(report, repo_facts, spec_data)
    _check_operations(report, repo_facts, spec_data)

    _compute_score(report)
    return report


def persist_report(
    event_store_path: Path,
    report: BlindSpotReport,
    aggregate_id: str,
) -> None:
    """Persister le rapport comme événement dans l'event store."""
    with EventStore(event_store_path) as store:
        store.append_event(
            aggregate_id,
            "blind_spot.completed",
            report.to_dict(),
        )


def _add(report: BlindSpotReport, finding: Finding) -> None:
    report.findings.append(finding)
    report.total_checks += 1
    if finding.severity == "gap":
        report.gaps += 1
    elif finding.severity == "warning":
        report.warnings += 1
    else:
        report.infos += 1


def _pass(report: BlindSpotReport) -> None:
    report.total_checks += 1


def _compute_score(report: BlindSpotReport) -> None:
    penalty = sum(SEVERITY_WEIGHTS.get(f.severity, 0.0) for f in report.findings)
    report.score = max(0.0, min(10.0, 10.0 - penalty))


# ---------------------------------------------------------------------------
# Chargement de la spec (YAML simplifié)
# ---------------------------------------------------------------------------


def _load_spec(spec_path: Path) -> dict[str, object]:
    try:
        from mobius.workflow.seed import load_seed_spec

        spec = load_seed_spec(spec_path)
        return {
            "goal": spec.goal,
            "constraints": spec.constraints,
            "success_criteria": spec.success_criteria,
            "verification_commands": spec.verification_commands,
            "non_goals": spec.non_goals,
            "owner": spec.owner,
            "context": spec.context,
            "project_type": spec.project_type,
            "risks": spec.risks,
            "steps": spec.steps,
            "agent_instructions": getattr(spec, "agent_instructions", None),
        }
    except Exception:
        return _fallback_parse_spec(spec_path)


def _fallback_parse_spec(spec_path: Path) -> dict[str, object]:
    """Parse permissif quand load_seed_spec échoue (spec incomplète)."""
    try:
        content = spec_path.read_text(encoding="utf-8")
    except OSError:
        return {}
    result: dict[str, object] = {}
    for line in content.split("\n"):
        stripped = line.strip()
        if stripped.startswith("goal:"):
            result["goal"] = stripped[5:].strip()
        elif stripped.startswith("project_type:"):
            result["project_type"] = stripped[13:].strip()
        elif stripped.startswith("context:"):
            result["context"] = stripped[8:].strip()
        elif stripped.startswith("owner:"):
            result["owner"] = stripped[6:].strip()
    return result


# ---------------------------------------------------------------------------
# Scan du workspace
# ---------------------------------------------------------------------------


_TODO_MARKERS = ("TODO", "FIXME", "HACK", "XXX")
_TODO_EXTENSIONS = frozenset({".py", ".ts", ".js", ".rs"})


_CI_TEST_KEYWORDS = (
    "test",
    "pytest",
    "npm test",
    "cargo test",
    "go test",
    "rspec",
    "jest",
    "vitest",
    "lint",
    "check",
)

_OBSERVABILITY_PYTHON = ("import logging", "import structlog", "from logging", "from structlog")
_OBSERVABILITY_NODE = ("winston", "pino", "bunyan")
_OBSERVABILITY_RUST_CARGO = ("tracing", '"log"')


def _scan_workspace(workspace: Path) -> dict[str, object]:
    facts: dict[str, object] = {
        "_workspace": workspace,
        "has_tests": False,
        "has_ci": False,
        "ci_has_test_command": False,
        "ci_content": "",
        "has_readme": False,
        "readme_lines": 0,
        "contributing_lines": 0,
        "architecture_lines": 0,
        "has_dockerfile": False,
        "has_gitignore": False,
        "has_db": False,
        "has_migrations": False,
        "has_e2e": False,
        "stack": "",
        "source_files": 0,
        "test_files": 0,
        # Nouveaux faits
        "pyproject_content": "",
        "package_json_content": "",
        "large_files": [],
        "todo_count": 0,
        "has_contributing": False,
        "has_architecture": False,
        "has_security_policy": False,
        "has_lockfile": False,
        "has_observability": False,
    }

    if not workspace.is_dir():
        return facts

    # --- README et comptage de lignes ---
    for name in ("README.md", "README.rst", "README.txt", "README"):
        readme_path = workspace / name
        if readme_path.exists():
            facts["has_readme"] = True
            try:
                content = readme_path.read_text(encoding="utf-8", errors="replace")
                facts["readme_lines"] = content.count("\n") + (
                    1 if content and not content.endswith("\n") else 0
                )
            except OSError:
                facts["readme_lines"] = 0
            break

    if (workspace / ".gitignore").exists():
        facts["has_gitignore"] = True

    if (workspace / "Dockerfile").exists() or (workspace / "docker-compose.yml").exists():
        facts["has_dockerfile"] = True

    # --- CI : détection et analyse du contenu ---
    ci_content_parts: list[str] = []

    def _read_ci_file(path: Path) -> None:
        with contextlib.suppress(OSError):
            ci_content_parts.append(path.read_text(encoding="utf-8", errors="replace"))

    gh_workflows = workspace / ".github" / "workflows"
    if gh_workflows.is_dir():
        facts["has_ci"] = True
        for wf_file in gh_workflows.iterdir():
            if wf_file.suffix in (".yml", ".yaml"):
                _read_ci_file(wf_file)
    elif (workspace / ".gitlab-ci.yml").exists():
        facts["has_ci"] = True
        _read_ci_file(workspace / ".gitlab-ci.yml")
    elif (workspace / "Jenkinsfile").exists():
        facts["has_ci"] = True
        _read_ci_file(workspace / "Jenkinsfile")

    ci_content = "\n".join(ci_content_parts)
    facts["ci_content"] = ci_content
    if ci_content:
        ci_lower = ci_content.lower()
        facts["ci_has_test_command"] = any(kw in ci_lower for kw in _CI_TEST_KEYWORDS)

    # Lecture pyproject.toml
    pyproject_path = workspace / "pyproject.toml"
    if pyproject_path.exists():
        facts["stack"] = "python"
        try:
            facts["pyproject_content"] = pyproject_path.read_text(encoding="utf-8")
        except OSError:
            facts["pyproject_content"] = ""
    elif (workspace / "package.json").exists():
        facts["stack"] = "node"
        try:
            facts["package_json_content"] = (workspace / "package.json").read_text(encoding="utf-8")
        except OSError:
            facts["package_json_content"] = ""
    elif (workspace / "Cargo.toml").exists():
        facts["stack"] = "rust"
    elif (workspace / "go.mod").exists():
        facts["stack"] = "go"
    elif (workspace / "Gemfile").exists():
        facts["stack"] = "ruby"

    # Détection lockfile selon le stack
    stack = str(facts["stack"])
    if stack == "python":
        facts["has_lockfile"] = (workspace / "uv.lock").exists() or (
            workspace / "poetry.lock"
        ).exists()
    elif stack == "node":
        facts["has_lockfile"] = (workspace / "package-lock.json").exists() or (
            workspace / "yarn.lock"
        ).exists()
    elif stack == "rust":
        facts["has_lockfile"] = (workspace / "Cargo.lock").exists()
    elif stack == "go":
        facts["has_lockfile"] = (workspace / "go.sum").exists()

    # Fichiers de documentation (avec comptage de lignes)
    contributing_path = workspace / "CONTRIBUTING.md"
    if contributing_path.exists():
        facts["has_contributing"] = True
        try:
            content = contributing_path.read_text(encoding="utf-8", errors="replace")
            facts["contributing_lines"] = content.count("\n") + (
                1 if content and not content.endswith("\n") else 0
            )
        except OSError:
            pass

    for arch_candidate in (workspace / "ARCHITECTURE.md", workspace / "docs" / "architecture.md"):
        if arch_candidate.exists():
            facts["has_architecture"] = True
            try:
                content = arch_candidate.read_text(encoding="utf-8", errors="replace")
                facts["architecture_lines"] = content.count("\n") + (
                    1 if content and not content.endswith("\n") else 0
                )
            except OSError:
                pass
            break

    if (workspace / "SECURITY.md").exists():
        facts["has_security_policy"] = True

    # Scan des fichiers sources
    todo_count = 0
    large_files_candidates: list[tuple[str, int]] = []
    observability_scanned = 0
    has_observability = False

    for dirpath, dirnames, filenames in os.walk(workspace):
        dirnames[:] = [d for d in dirnames if d not in IGNORE_DIRS]
        rel = Path(dirpath).relative_to(workspace)

        for fname in filenames:
            fpath = Path(dirpath) / fname

            if fname.endswith((".py", ".ts", ".tsx", ".js", ".jsx", ".rs", ".go", ".rb")):
                facts["source_files"] = _int_fact(facts, "source_files") + 1

                # Comptage TODO/FIXME/HACK/XXX
                if fpath.suffix in _TODO_EXTENSIONS:
                    try:
                        text = fpath.read_text(encoding="utf-8", errors="replace")
                        for marker in _TODO_MARKERS:
                            todo_count += text.count(marker)
                    except OSError:
                        pass

                # Détection gros fichiers Python
                if fname.endswith(".py"):
                    try:
                        line_count = fpath.read_text(encoding="utf-8", errors="replace").count("\n")
                        if line_count > 500:
                            large_files_candidates.append(
                                (str(fpath.relative_to(workspace)), line_count)
                            )
                    except OSError:
                        pass

                # Détection observabilité (50 premiers fichiers source)
                if not has_observability and observability_scanned < 50:
                    observability_scanned += 1
                    try:
                        text = fpath.read_text(encoding="utf-8", errors="replace")
                        if fname.endswith(".py") and any(
                            kw in text for kw in _OBSERVABILITY_PYTHON
                        ) or fname.endswith((".js", ".ts", ".jsx", ".tsx")) and any(
                            kw in text for kw in _OBSERVABILITY_NODE
                        ):
                            has_observability = True
                    except OSError:
                        pass

            if fname.startswith("test_") or fname.endswith(
                ("_test.py", ".test.ts", ".test.js", ".spec.ts", ".spec.js")
            ):
                facts["test_files"] = _int_fact(facts, "test_files") + 1

        if any(part in ("e2e", "integration") for part in rel.parts):
            facts["has_e2e"] = True

        if any(part in ("migrations", "alembic", "migrate") for part in rel.parts):
            facts["has_migrations"] = True

        for fname in filenames:
            if fname in ("schema.prisma", "models.py", "schema.rb"):
                facts["has_db"] = True
            if "redis" in fname.lower() or "database" in fname.lower():
                facts["has_db"] = True

    facts["todo_count"] = todo_count
    facts["has_observability"] = has_observability

    # has_tests : seulement si des fichiers de test ont été trouvés
    facts["has_tests"] = _int_fact(facts, "test_files") > 0

    # Vérifier l'observabilité Rust via Cargo.toml
    if stack == "rust" and not has_observability:
        cargo_path = workspace / "Cargo.toml"
        if cargo_path.exists():
            try:
                cargo_content = cargo_path.read_text(encoding="utf-8", errors="replace")
                if any(kw in cargo_content for kw in _OBSERVABILITY_RUST_CARGO):
                    facts["has_observability"] = True
            except OSError:
                pass

    # Garder les 5 plus gros fichiers
    large_files_candidates.sort(key=lambda x: x[1], reverse=True)
    facts["large_files"] = large_files_candidates[:5]

    return facts


# ---------------------------------------------------------------------------
# Détecteurs par catégorie
# ---------------------------------------------------------------------------


def _check_spec_gaps(report: BlindSpotReport, spec: dict[str, object]) -> None:
    if not spec:
        _add(
            report,
            Finding(
                "spec_missing",
                "spec",
                "gap",
                "Pas de spec.yaml trouvée ou invalide.",
                "",
                why="Sans spec, personne ne sait ce que le projet doit accomplir. "
                "C'est comme construire une maison sans plan.",
                impact="Avec une spec, chaque membre de l'équipe sait exactement "
                "quoi construire, quoi tester, et quand c'est fini.",
                how="Lancer `mobius interview` pour créer une spec.yaml avec objectif, contraintes et critères de succès.",
                when="Maintenant — c'est le point de départ de tout le workflow.",
                mermaid_before="  Développeur ──► ??? (pas d'objectif) ──► ???",
                mermaid_after="  spec.yaml ──► Objectif clair ──► Développeur ──► Critères testables",
            ),
        )
        return

    criteria = spec.get("success_criteria")
    commands = spec.get("verification_commands")
    if isinstance(criteria, (list, tuple)) and isinstance(commands, (list, tuple)):
        unlinked = len(criteria) - len(commands)
        if unlinked > 0:
            _add(
                report,
                Finding(
                    "criteria_sans_verification",
                    "spec",
                    "gap",
                    f"{unlinked} critère(s) de succès sans commande de vérification.",
                    f"{len(criteria)} critères, {len(commands)} commandes",
                    why="Des critères de succès sans commande de vérification, c'est comme un examen sans corrigé. "
                    "On ne peut pas prouver automatiquement que le projet réussit.",
                    impact="Chaque critère lié à une commande permet au QA de vérifier automatiquement. "
                    "Plus besoin de vérifier manuellement — la machine le fait.",
                    how="Ajouter une section verification_commands dans spec.yaml avec une commande par critère.",
                    when="Avant le prochain mobius run.",
                    mermaid_before="  Critères ──► ??? ──► On ne sait pas",
                    mermaid_after="  Critères ──► Commandes de test ──► mobius qa ──► PASS / FAIL",
                ),
            )
        else:
            _pass(report)
    elif isinstance(criteria, (list, tuple)) and not commands:
        _add(
            report,
            Finding(
                "no_verification_commands",
                "spec",
                "gap",
                "Aucune commande de vérification dans la spec.",
                f"{len(criteria)} critères sans aucune commande",
                why="Sans commandes de vérification, Mobius QA ne peut rien prouver. "
                "C'est comme dire « le gâteau doit être bon » sans jamais le goûter.",
                impact="Ajouter des commandes (ex: pytest, curl, script) permet de vérifier "
                "automatiquement si chaque critère est rempli.",
                how="Ajouter une section verification_commands dans spec.yaml avec une commande par critère.",
                when="Avant le prochain mobius run.",
                mermaid_before="  Spec ──► Aucun test ──► ???",
                mermaid_after="  Spec ──► pytest / curl / script ──► Critères vérifiés",
            ),
        )

    non_goals = spec.get("non_goals")
    if not non_goals:
        _add(
            report,
            Finding(
                "no_non_goals",
                "spec",
                "warning",
                "Pas de non-goals définis — le scope peut dériver.",
                "",
                why="Sans non-goals, rien n'empêche d'ajouter des features hors scope. "
                "C'est comme un budget sans limite — on dépense sans s'arrêter.",
                impact="Définir ce qu'on NE fait PAS protège le focus. "
                "L'équipe peut dire « non, c'est un non-goal » au lieu de débattre.",
                mermaid_before="  Feature A ──┐\n  Feature B ──┤──► Scope infini\n  Feature C ──┘",
                mermaid_after="  Feature A ──► On fait\n  Feature B ──► Non-goal (on ne fait PAS)\n  Feature C ──► On fait",
            ),
        )
    else:
        _pass(report)

    if not spec.get("owner"):
        _add(
            report,
            Finding(
                "no_owner",
                "spec",
                "warning",
                "Pas de propriétaire défini dans la spec.",
                "",
                why="Sans propriétaire, personne n'est responsable des décisions. "
                "Quand tout le monde est responsable, personne ne l'est.",
                impact="Un owner tranche les décisions rapidement et porte la responsabilité du résultat.",
                mermaid_before="  Décision ──► Dev 1 / Dev 2 ──► Personne ne décide",
                mermaid_after="  Décision ──► Propriétaire ──► Action claire",
            ),
        )
    else:
        _pass(report)

    if not spec.get("risks"):
        _add(
            report,
            Finding(
                "no_risks",
                "spec",
                "warning",
                "Aucun risque identifié dans la spec.",
                "",
                why="Pas de risques identifiés veut dire qu'on n'a pas réfléchi à ce qui pourrait mal tourner. "
                "Les surprises en production coûtent 10x plus que les surprises en planification.",
                impact="Identifier les risques tôt permet de s'y préparer. "
                "Un plan B pensé d'avance se déploie en minutes, pas en jours.",
                mermaid_before="  Plan ──► Production ──► Surprise! ──► Incident",
                mermaid_after="  Plan ──► Risques identifiés + Plan B\n       ──► Production ──► Problème prévu ──► Résolu vite",
            ),
        )
    else:
        _pass(report)

    project_type = spec.get("project_type", "")
    context = spec.get("context", "")
    if project_type == "brownfield" and not context:
        _add(
            report,
            Finding(
                "brownfield_no_context",
                "spec",
                "gap",
                "Projet brownfield sans contexte — l'agent code à l'aveugle.",
                "",
                why="Sur un projet existant, sans description du système actuel, l'agent IA "
                "ne sait pas ce qui existe déjà. Il risque de recréer ou casser l'existant.",
                impact="Ajouter le contexte (stack, base de données, architecture) permet "
                "à l'agent de respecter ce qui est déjà en place.",
                mermaid_before="  Agent IA (sans contexte) ──► Code existant ──► Régression",
                mermaid_after="  Contexte ──► Agent IA ──► Code existant (respecté) ──► OK",
            ),
        )
    else:
        _pass(report)

    steps = spec.get("steps")
    if not steps:
        _add(
            report,
            Finding(
                "spec_no_steps",
                "spec",
                "info",
                "Pas d'étapes définies dans la spec — l'exécution n'a pas de séquence claire.",
                "",
                why="Sans étapes définies, l'exécution du projet n'a pas de séquence claire.",
                impact="Des étapes ordonnées guident l'agent et permettent de suivre la progression.",
                how="Ajouter une section `steps:` dans spec.yaml avec les étapes de réalisation.",
                when="Pour les projets avec plus de 3 critères de succès.",
            ),
        )
    else:
        _pass(report)

    # --- Critères non mesurables ---
    _MEASUREMENT_WORDS = frozenset(
        {
            "ms",
            "secondes",
            "%",
            "ratio",
            "score",
            "count",
            "nombre",
            "moins",
            "plus",
            "maximum",
            "minimum",
        }
    )
    if isinstance(criteria, (list, tuple)) and len(criteria) >= 3:
        non_measurable = 0
        for c in criteria:
            if not isinstance(c, str):
                continue
            c_lower = c.lower()
            has_digit = any(ch.isdigit() for ch in c_lower)
            has_word = any(w in c_lower for w in _MEASUREMENT_WORDS)
            if not has_digit and not has_word:
                non_measurable += 1
        total = len(criteria)
        if non_measurable > total / 2:
            _add(
                report,
                Finding(
                    "criteria_not_measurable",
                    "spec",
                    "warning",
                    f"{non_measurable}/{total} critères de succès ne contiennent aucune métrique mesurable.",
                    f"{non_measurable}/{total} critères sans métrique",
                    why=f"{non_measurable}/{total} critères de succès ne contiennent aucune métrique mesurable. "
                    "Un critère comme 'ça marche bien' est invérifiable.",
                    impact="Des critères mesurables (ex: 'temps de réponse < 200ms') sont testables automatiquement.",
                    how="Pour chaque critère vague, ajouter : une quantité, un seuil, une unité de mesure.",
                    when="Avant le prochain `mobius seed`.",
                    mermaid_before="  'Ça marche bien' ──► Comment vérifier? ──► Impossible",
                    mermaid_after="  'Réponse < 200ms' ──► curl + mesure ──► PASS / FAIL",
                ),
            )
        else:
            _pass(report)

    # --- Instructions agent ---
    if not spec.get("agent_instructions"):
        _add(
            report,
            Finding(
                "no_agent_instructions",
                "spec",
                "info",
                "Pas d'instructions agent dans la spec.",
                "",
                why="Sans instructions agent, le coding agent (Claude/Codex) utilise ses propres conventions "
                "qui peuvent ne pas correspondre au projet.",
                impact="Des instructions agent (ex: 'utilise pytest, pas unittest') guident l'agent "
                "vers le bon résultat du premier coup.",
                how="Ajouter une section `agent_instructions:` dans spec.yaml avec les conventions du projet.",
                when="Avant le prochain `mobius run` avec un coding agent.",
            ),
        )
    else:
        _pass(report)


def _check_repo_hygiene(report: BlindSpotReport, facts: dict[str, object]) -> None:
    if not facts.get("has_tests"):
        _add(
            report,
            Finding(
                "no_tests",
                "repo",
                "gap",
                "Aucun répertoire de tests détecté.",
                "",
                why="Sans tests, chaque modification est un pari. On ne sait pas si le changement casse autre chose.",
                impact="Avec des tests, on détecte les régressions immédiatement au lieu de les découvrir en production.",
                how="Créer un dossier tests/ et ajouter un premier test pour la fonctionnalité principale.",
                when="Maintenant — plus on attend, plus c'est dur de rattraper.",
                mermaid_before="  Modification ──► Production (pas de filet) ──► Bug?",
                mermaid_after="  Modification ──► Tests ──► Vérifié ──► Production ──► Stable",
            ),
        )
    else:
        _pass(report)

    if not facts.get("has_ci"):
        _add(
            report,
            Finding(
                "no_ci",
                "repo",
                "warning",
                "Pas de CI détectée (GitHub Actions, GitLab CI, Jenkins).",
                "",
                why="Sans CI, les tests ne tournent que quand quelqu'un y pense. En pratique, ça veut dire rarement.",
                impact="La CI lance les tests automatiquement à chaque push. Les bugs sont attrapés avant le merge.",
                how="Ajouter un fichier .github/workflows/ci.yml avec les commandes de test du projet.",
                when="Avant le prochain merge important.",
                mermaid_before="  Push ──► Branche main (direct) ──► ???",
                mermaid_after="  Push ──► CI auto ──┬─► Tests OK ──► Merge\n                    └─► Tests KO ──► Bloqué",
            ),
        )
    else:
        _pass(report)

    # --- CI sans commande de test ---
    if facts.get("has_ci") and not facts.get("ci_has_test_command"):
        _add(
            report,
            Finding(
                "ci_no_test_command",
                "repo",
                "warning",
                "La CI existe mais ne lance aucun test ni linter.",
                "",
                why="La CI existe mais ne lance aucun test ni linter. C'est une coquille vide — elle donne l'illusion de la sécurité sans rien vérifier.",
                impact="Une CI qui lance les tests bloque automatiquement les merges cassés.",
                how="Ajouter une étape `run: pytest` (ou equivalent) dans le workflow CI.",
                when="Maintenant — une CI sans tests est pire qu'aucune CI (fausse confiance).",
                mermaid_before="  Push ──► CI (ne fait rien) ──► Merge ──► Bug en prod",
                mermaid_after="  Push ──► CI (lance tests) ──┬─► OK ──► Merge\n                              └─► Fail ──► Bloqué",
            ),
        )
    elif facts.get("has_ci"):
        _pass(report)

    if not facts.get("has_readme"):
        _add(
            report,
            Finding(
                "no_readme",
                "repo",
                "warning",
                "Pas de README — l'onboarding est invisible.",
                "",
                why="Sans README, un nouveau venu ne sait pas par où commencer. Le projet est invisible de l'extérieur.",
                impact="Un README permet à quiconque de comprendre, installer et contribuer au projet en 5 minutes.",
                how="Créer un README.md avec : description du projet, installation, utilisation, contribution.",
                when="Avant de partager le projet avec quelqu'un d'autre.",
                mermaid_before="  Nouvelle personne ──► Projet ──► Perdu",
                mermaid_after="  Nouvelle personne ──► README.md ──► Comprend ──► Productif",
            ),
        )
    else:
        _pass(report)

    if not facts.get("has_gitignore"):
        _add(
            report,
            Finding(
                "no_gitignore",
                "repo",
                "info",
                "Pas de .gitignore.",
                "",
                why="Sans .gitignore, des fichiers indésirables (caches, secrets, builds) peuvent être commités par erreur.",
                impact="Un .gitignore protège le dépôt des fichiers qui ne devraient pas y être.",
                how="Créer un .gitignore adapté au stack (ex: gitignore.io).",
                when="Quand c'est pratique — pas urgent.",
            ),
        )
    else:
        _pass(report)

    source = _int_fact(facts, "source_files")
    tests = _int_fact(facts, "test_files")
    if source > 10 and tests == 0:
        _add(
            report,
            Finding(
                "no_test_files",
                "repo",
                "gap",
                f"{source} fichiers source mais 0 fichier de test.",
                f"source_files={source}, test_files={tests}",
                why="Beaucoup de code source mais zéro fichier de test. Le projet grandit sans filet de sécurité.",
                impact="Même quelques tests sur les chemins critiques réduisent drastiquement le risque de régression.",
                how="Identifier les 3 fonctions les plus critiques et écrire un test pour chacune.",
                when="Maintenant — la dette de tests grossit avec le projet.",
                mermaid_before=f"  {source} fichiers ──► Aucun test ──► Risque élevé",
                mermaid_after=f"  {source} fichiers ──► Tests critiques ──► Risque réduit",
            ),
        )
    elif source > 0 and tests > 0:
        _pass(report)

    # --- Changelog ---
    workspace = facts.get("_workspace")
    if isinstance(workspace, Path):
        has_changelog = any(
            (workspace / name).exists() for name in ("CHANGELOG.md", "CHANGELOG", "CHANGES.md")
        )
        if not has_changelog:
            _add(
                report,
                Finding(
                    "no_changelog",
                    "repo",
                    "warning",
                    "Pas de CHANGELOG — personne ne sait ce qui a changé entre les versions.",
                    "",
                    why="Sans changelog, personne ne sait ce qui a changé entre les versions. "
                    "Les utilisateurs et l'équipe naviguent à l'aveugle.",
                    impact="Un changelog permet de comprendre l'historique du projet en 30 secondes.",
                    how="Créer un CHANGELOG.md avec les changements récents groupés par version.",
                    when="Avant la prochaine release.",
                    mermaid_before="  Version 1.2 ──► Quoi de neuf? ──► ???",
                    mermaid_after="  Version 1.2 ──► CHANGELOG.md ──► Liste des changements claire",
                ),
            )
        else:
            _pass(report)

        # --- Licence ---
        has_license = any(
            (workspace / name).exists()
            for name in ("LICENSE", "LICENSE.md", "LICENSE.txt", "LICENCE")
        )
        if not has_license:
            _add(
                report,
                Finding(
                    "no_license",
                    "repo",
                    "warning",
                    "Pas de fichier LICENSE — le code est légalement inutilisable par d'autres.",
                    "",
                    why="Sans licence, le code n'est légalement pas utilisable par d'autres. "
                    "Même un projet interne devrait avoir une licence claire.",
                    impact="Une licence lève l'ambiguïté juridique et permet la collaboration.",
                    how="Ajouter un fichier LICENSE (MIT pour l'open source, propriétaire sinon).",
                    when="Avant de partager le code avec quiconque.",
                    mermaid_before="  Code ──► Pas de licence ──► Inutilisable légalement",
                    mermaid_after="  Code ──► LICENSE ──► Utilisable + partageable",
                ),
            )
        else:
            _pass(report)

        # --- Lockfile ---
        stack = str(facts.get("stack", ""))
        if stack in ("python", "node", "rust", "go"):
            if not facts.get("has_lockfile"):
                _add(
                    report,
                    Finding(
                        "no_lockfile",
                        "repo",
                        "warning",
                        f"Projet {stack} sans lockfile — les dépendances ne sont pas épinglées.",
                        "",
                        why="Sans lockfile, les dépendances peuvent changer silencieusement entre les machines. "
                        "'Ça marche chez moi' est le symptôme.",
                        impact="Un lockfile garantit que tout le monde utilise exactement les mêmes versions.",
                        how="Commiter le lockfile dans git (uv.lock, package-lock.json, Cargo.lock).",
                        when="Maintenant — c'est une ligne de commande.",
                        mermaid_before="  Machine A ──► deps v1.2 ──► OK\n  Machine B ──► deps v1.3 ──► Bug",
                        mermaid_after="  Lockfile ──► Même deps partout ──► Reproductible",
                    ),
                )
            else:
                _pass(report)

        # --- Ratio tests/source ---
        if source > 20 and tests > 0:
            ratio = tests / source
            if ratio < 0.2:
                _add(
                    report,
                    Finding(
                        "test_ratio_low",
                        "repo",
                        "warning",
                        f"Ratio tests/source très bas ({tests}/{source} = {ratio:.0%}).",
                        f"source_files={source}, test_files={tests}, ratio={ratio:.2f}",
                        why=f"Ratio tests/source très bas ({tests}/{source} = {ratio:.0%}). "
                        "Les parties non testées sont des bombes à retardement.",
                        impact="Augmenter le ratio de tests réduit le risque de régression sur chaque changement.",
                        how="Identifier les 5 modules les plus critiques et ajouter des tests pour chacun.",
                        when="Progressivement — viser 1 test ajouté par PR.",
                    ),
                )
            else:
                _pass(report)


def _check_stack_patterns(
    report: BlindSpotReport,
    facts: dict[str, object],
    spec: dict[str, object],
) -> None:
    if facts.get("has_db") and not facts.get("has_migrations"):
        _add(
            report,
            Finding(
                "db_no_migrations",
                "stack",
                "warning",
                "Base de données détectée mais pas de répertoire de migrations.",
                "",
                why="Sans migrations, les changements de base de données sont faits à la main. Impossible de reproduire ou annuler.",
                impact="Les migrations versionnent le schéma. Chaque environnement (dev, staging, prod) reste synchronisé.",
                how="Créer un dossier migrations/ et écrire la première migration pour le schéma actuel.",
                when="Avant le prochain changement de schéma.",
                mermaid_before="  Dev ──► SQL manuel ──► BD désynchronisée",
                mermaid_after="  Dev ──► Migration versionnée ──► BD synchronisée partout",
            ),
        )
    elif facts.get("has_db"):
        _pass(report)

    source = _int_fact(facts, "source_files")
    if source > 20 and not facts.get("has_e2e"):
        _add(
            report,
            Finding(
                "no_e2e",
                "stack",
                "warning",
                f"Projet de {source} fichiers sans tests e2e/intégration.",
                "",
                why="Les tests unitaires vérifient les pièces isolées. Sans tests e2e, personne ne vérifie que le puzzle entier fonctionne.",
                impact="Les tests e2e simulent un vrai utilisateur. Ils attrapent les bugs d'intégration que les tests unitaires ratent.",
                how="Ajouter un dossier tests/e2e/ avec un test qui parcourt le chemin principal de l'application.",
                when="Quand le projet grossit au-delà de 20 fichiers.",
                mermaid_before="  Tests unitaires OK ──► Ensemble? ──► Bug d'intégration",
                mermaid_after="  Tests unitaires OK ──► Tests e2e OK ──► Confiance totale",
            ),
        )
    elif facts.get("has_e2e"):
        _pass(report)

    # --- Commande de build/run/test standard ---
    stack = str(facts.get("stack", ""))
    if stack == "python":
        pyproject_content = str(facts.get("pyproject_content", ""))
        has_build_command = (
            "[project.scripts]" in pyproject_content
            or "[tool.setuptools]" in pyproject_content
            or "build-backend" in pyproject_content
        )
        if not has_build_command:
            _add(
                report,
                Finding(
                    "no_build_command",
                    "stack",
                    "warning",
                    "Pas de commande de build/run/test standard détectée dans pyproject.toml.",
                    "",
                    why="Pas de commande de build/run/test standard détectée. Un nouveau contributeur ne sait pas comment démarrer le projet.",
                    impact="Des scripts standards (test, build, start) permettent à quiconque de lancer le projet en une commande.",
                    how="Ajouter `[project.scripts]` dans pyproject.toml ou configurer un build-backend.",
                    when="Dès que le projet est partagé.",
                    mermaid_before="  Nouveau dev ──► Comment lancer? ──► Lire tout le code",
                    mermaid_after="  Nouveau dev ──► npm test / uv run pytest ──► Projet lancé",
                ),
            )
        else:
            _pass(report)
    elif stack == "node":
        package_json_content = str(facts.get("package_json_content", ""))
        has_build_command = '"scripts"' in package_json_content and (
            '"test"' in package_json_content
            or '"build"' in package_json_content
            or '"start"' in package_json_content
        )
        if package_json_content and not has_build_command:
            _add(
                report,
                Finding(
                    "no_build_command",
                    "stack",
                    "warning",
                    "Pas de script test/build/start dans package.json.",
                    "",
                    why="Pas de commande de build/run/test standard détectée. Un nouveau contributeur ne sait pas comment démarrer le projet.",
                    impact="Des scripts standards (test, build, start) permettent à quiconque de lancer le projet en une commande.",
                    how="Ajouter `scripts` dans package.json avec au minimum test, build ou start.",
                    when="Dès que le projet est partagé.",
                    mermaid_before="  Nouveau dev ──► Comment lancer? ──► Lire tout le code",
                    mermaid_after="  Nouveau dev ──► npm test / uv run pytest ──► Projet lancé",
                ),
            )
        elif package_json_content:
            _pass(report)

    # --- Typage statique Python ---
    if facts.get("stack") == "python":
        workspace = facts.get("_workspace")
        has_typing = False
        if isinstance(workspace, Path):
            pyproject = workspace / "pyproject.toml"
            if pyproject.exists():
                try:
                    content = pyproject.read_text(encoding="utf-8")
                    has_typing = "mypy" in content or "pyright" in content
                except OSError:
                    pass
            if not has_typing:
                has_typing = bool(list(workspace.rglob("py.typed"))[:1])
        if not has_typing:
            _add(
                report,
                Finding(
                    "no_typing",
                    "stack",
                    "warning",
                    "Projet Python sans configuration de typage statique (mypy/pyright).",
                    "",
                    why="Sans typage, les erreurs de type ne sont détectées qu'à l'exécution. "
                    "Plus le projet grossit, plus c'est coûteux.",
                    impact="Le typage attrape une classe entière de bugs avant même d'exécuter le code.",
                    how="Ajouter `[tool.pyright]` ou `[tool.mypy]` dans pyproject.toml et typer les fonctions publiques.",
                    when="Quand le projet dépasse 10 fichiers Python.",
                    mermaid_before="  def process(data) ──► Erreur à l'exécution ──► Bug en prod",
                    mermaid_after="  def process(data: Input) -> Output ──► Erreur au check ──► Bug attrapé tôt",
                ),
            )
        else:
            _pass(report)


def _check_mobius_gaps(
    report: BlindSpotReport,
    spec: dict[str, object],
    event_store_path: Path | None,
) -> None:
    if event_store_path and event_store_path.exists():
        try:
            with EventStore(event_store_path, read_only=True) as store:
                latest = store.get_latest_run()
                if latest is None:
                    _add(
                        report,
                        Finding(
                            "no_runs",
                            "mobius",
                            "info",
                            "Aucun run Mobius enregistré — le workflow n'a jamais été exécuté.",
                            "",
                            why="Le workflow Mobius n'a jamais été exécuté sur ce projet. La spec existe mais n'a pas été mise en pratique.",
                            impact="Exécuter un run permet de vérifier si la spec est réaliste et si les critères sont atteignables.",
                            how="Lancer `mobius run --spec spec.yaml` pour exécuter le workflow.",
                            when="Après avoir validé la spec avec `mobius seed`.",
                        ),
                    )
                else:
                    _pass(report)

                    events = store.read_events(latest.aggregate_id)
                    has_qa = any(e.type == "qa.completed" for e in events)
                    if not has_qa:
                        _add(
                            report,
                            Finding(
                                "run_no_qa",
                                "mobius",
                                "warning",
                                "Dernier run sans verdict QA — les critères n'ont pas été vérifiés.",
                                f"run_id={latest.aggregate_id}",
                                why="Le run a terminé mais personne n'a vérifié si les critères sont remplis. C'est comme finir un examen sans le corriger.",
                                impact="Le QA vérifie chaque critère automatiquement et produit un verdict clair : PASS, FAIL ou UNVERIFIED.",
                                how=f"Lancer `mobius qa {latest.aggregate_id}` pour juger le run.",
                                when="Maintenant — le run est déjà terminé, il ne manque que le verdict.",
                                mermaid_before="  Run terminé ──► Pas de QA ──► Aucun verdict",
                                mermaid_after="  Run terminé ──► mobius qa ──► PASS / FAIL",
                            ),
                        )
                    else:
                        _pass(report)

                    has_lineage = any(e.type.startswith("evolution.") for e in events)
                    if not has_lineage:
                        _add(
                            report,
                            Finding(
                                "no_lineage",
                                "mobius",
                                "info",
                                "Le projet n'a jamais été évolué — les critères n'ont été vérifiés qu'une seule fois.",
                                f"run_id={latest.aggregate_id}",
                                why="Le projet n'a jamais été évolué — les critères n'ont été vérifiés qu'une seule fois.",
                                impact="La boucle evolve itère automatiquement jusqu'à ce que tous les critères passent.",
                                how=f"Lancer `mobius evolve --from {latest.aggregate_id}` après un QA qui a des critères échoués.",
                                when="Quand le QA retourne des critères FAIL ou UNVERIFIED.",
                            ),
                        )
                    else:
                        _pass(report)
        except Exception:
            _pass(report)
    else:
        _pass(report)


def _check_ux_gaps(
    report: BlindSpotReport,
    facts: dict[str, object],
    spec: dict[str, object],
) -> None:
    criteria = spec.get("success_criteria")
    if isinstance(criteria, (list, tuple)):
        vague_count = sum(1 for c in criteria if isinstance(c, str) and len(c.split()) < 4)
        if vague_count > 0:
            _add(
                report,
                Finding(
                    "vague_criteria",
                    "ux",
                    "warning",
                    f"{vague_count} critère(s) de succès trop vagues (moins de 4 mots).",
                    "",
                    why="Des critères de succès trop courts sont ambigus. 'Ça marche' ne veut rien dire — marche comment ? Pour qui ?",
                    impact="Des critères précis (ex: 'le temps de réponse est sous 200ms') sont testables automatiquement.",
                    how="Reformuler chaque critère vague en ajoutant : qui, quoi, combien, comment mesurer.",
                    when="Avant le prochain `mobius seed` — les critères vagues polluent tout le workflow.",
                    mermaid_before="  'Ça marche' (vague) ──► Comment tester?",
                    mermaid_after="  'API sous 200ms' (précis) ──► curl + mesure ──► PASS / FAIL",
                ),
            )
        else:
            _pass(report)


# ---------------------------------------------------------------------------
# Sécurité
# ---------------------------------------------------------------------------

_SECRET_PATTERNS = (
    "API_KEY=",
    "SECRET=",
    "PASSWORD=",
    "TOKEN=",
    "APIKEY=",
    "SECRET_KEY=",
    "ACCESS_KEY=",
    "PRIVATE_KEY=",
)

_SCANNABLE_EXTENSIONS = frozenset({".py", ".js", ".ts", ".yaml", ".yml", ".toml", ".json", ".env"})


def _file_contains_hardcoded_secret(path: Path) -> bool:
    """Retourne True si le fichier semble contenir un secret en dur."""
    try:
        content = path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return False
    for line in content.splitlines():
        upper = line.upper().lstrip()
        for pattern in _SECRET_PATTERNS:
            idx = upper.find(pattern)
            if idx == -1:
                continue
            value = line[idx + len(pattern) :].strip().strip("'\"")
            # Ignorer les valeurs vides, les placeholders et les références d'env
            if not value or value.startswith("${") or value.startswith("<"):
                continue
            if value in ("", "None", "null", "true", "false", "True", "False"):
                continue
            return True
    return False


def _check_security(
    report: BlindSpotReport,
    facts: dict[str, object],
    spec: dict[str, object],
) -> None:
    """Détecteur de failles de sécurité fréquentes dans un dépôt."""
    workspace = facts.get("_workspace")
    if not isinstance(workspace, Path) or not workspace.is_dir():
        _pass(report)
        return

    # Lire .gitignore une seule fois
    gitignore_content = ""
    gitignore_path = workspace / ".gitignore"
    if gitignore_path.exists():
        with contextlib.suppress(OSError):
            gitignore_content = gitignore_path.read_text(encoding="utf-8")

    gitignore_has_env = ".env" in gitignore_content

    # --- Secrets dans le code ---
    scanned = 0
    found_secrets = False
    for dirpath, dirnames, filenames in os.walk(workspace):
        dirnames[:] = [d for d in dirnames if d not in IGNORE_DIRS]
        for fname in filenames:
            if scanned >= 100:
                break
            fpath = Path(dirpath) / fname
            if fpath.suffix not in _SCANNABLE_EXTENSIONS and not fname.startswith(".env"):
                continue
            scanned += 1
            if _file_contains_hardcoded_secret(fpath):
                found_secrets = True
                break
        if found_secrets or scanned >= 100:
            break

    if found_secrets:
        _add(
            report,
            Finding(
                "secrets_in_code",
                "security",
                "gap",
                "Des secrets potentiels ont été détectés directement dans le code source.",
                "",
                why="Des secrets dans le code source sont une faille de sécurité critique. "
                "Ils peuvent être exposés via git history même après suppression.",
                impact="Retirer les secrets et utiliser des variables d'environnement protège contre les fuites de credentials.",
                how="Déplacer les secrets dans des variables d'environnement. Ajouter `.env` au `.gitignore`.",
                when="Immédiatement — c'est un risque de sécurité actif.",
                mermaid_before="  API_KEY=sk-xxx dans le code ──► Git push ──► Secret exposé",
                mermaid_after="  API_KEY dans .env (gitignored) ──► Code lit $API_KEY ──► Secret protégé",
            ),
        )
    else:
        _pass(report)

    # --- .env sans .env.example ---
    if gitignore_has_env:
        has_env_example = (workspace / ".env.example").exists() or (
            workspace / ".env.sample"
        ).exists()
        if not has_env_example:
            _add(
                report,
                Finding(
                    "env_no_example",
                    "security",
                    "warning",
                    ".env ignoré par git mais aucun .env.example — les variables requises sont invisibles.",
                    "",
                    why="Le .env est ignoré par git (bien), mais personne ne sait quelles variables configurer sans un exemple.",
                    impact="Un .env.example documente les variables requises sans exposer les valeurs.",
                    how="Créer un .env.example avec les noms de variables (sans les vraies valeurs).",
                    when="Avant l'arrivée d'un nouveau développeur.",
                    mermaid_before="  Nouveau dev ──► Pas de .env.example ──► Quelles variables?",
                    mermaid_after="  Nouveau dev ──► .env.example ──► Copie et remplit ──► Prêt",
                ),
            )
        else:
            _pass(report)
    else:
        _pass(report)

    # --- Politique de sécurité ---
    source = _int_fact(facts, "source_files")
    if source > 30 and not facts.get("has_security_policy"):
        _add(
            report,
            Finding(
                "no_security_policy",
                "security",
                "info",
                "Pas de SECURITY.md — aucun processus pour signaler une vulnérabilité.",
                "",
                why="Sans politique de sécurité, personne ne sait comment signaler une vulnérabilité.",
                impact="Un SECURITY.md permet aux chercheurs de signaler les failles de façon responsable.",
                how="Créer un SECURITY.md avec : comment signaler une vulnérabilité, contact, délai de réponse.",
                when="Quand le projet est public ou a des utilisateurs.",
            ),
        )
    else:
        _pass(report)


# ---------------------------------------------------------------------------
# Qualité du code
# ---------------------------------------------------------------------------


def _check_quality(
    report: BlindSpotReport,
    facts: dict[str, object],
    spec: dict[str, object],
) -> None:
    """Détecteur de problèmes de qualité du code (linter, formatter, gros fichiers, TODOs)."""
    stack = str(facts.get("stack", ""))
    pyproject_content = str(facts.get("pyproject_content", ""))

    # --- Linter Python ---
    if stack == "python":
        has_linter = any(tool in pyproject_content for tool in ("ruff", "flake8", "pylint"))
        if not has_linter:
            _add(
                report,
                Finding(
                    "no_linter",
                    "quality",
                    "warning",
                    "Projet Python sans linter configuré (ruff/flake8/pylint).",
                    "",
                    why="Sans linter, les erreurs de style et les bugs subtils passent inaperçus. "
                    "Le code accumule de la dette technique silencieusement.",
                    impact="Un linter attrape les erreurs avant même d'exécuter le code.",
                    how="Ajouter `[tool.ruff]` dans pyproject.toml.",
                    when="Dès le début du projet.",
                ),
            )
        else:
            _pass(report)

        # --- Formatter Python ---
        has_formatter = (
            "ruff format" in pyproject_content
            or "black" in pyproject_content
            or "[tool.ruff.format]" in pyproject_content
        )
        if not has_formatter:
            _add(
                report,
                Finding(
                    "no_formatter",
                    "quality",
                    "info",
                    "Projet Python sans formatter configuré (ruff format/black).",
                    "",
                    why="Sans formatter, chaque développeur formate différemment. "
                    "Les diffs git deviennent du bruit.",
                    impact="Un formatter unifie le style automatiquement — zéro débat, zéro bruit dans les diffs.",
                    how="Activer `ruff format` ou ajouter `[tool.ruff.format]` dans pyproject.toml.",
                    when="Quand c'est pratique — pas urgent.",
                ),
            )
        else:
            _pass(report)

    # --- Gros fichiers ---
    large_files = _large_files_fact(facts)
    if len(large_files) > 3:
        top3 = large_files[:3]
        evidence = ", ".join(f"{path} ({lines} lignes)" for path, lines in top3)
        _add(
            report,
            Finding(
                "large_files",
                "quality",
                "warning",
                f"{len(large_files)} fichiers de plus de 500 lignes.",
                evidence,
                why=f"{len(large_files)} fichiers de plus de 500 lignes. "
                "Les gros fichiers sont difficiles à comprendre, tester et maintenir.",
                impact="Découper les gros fichiers améliore la lisibilité et facilite le travail en parallèle.",
                how="Identifier le plus gros fichier et extraire les responsabilités distinctes en modules séparés.",
                when="Progressivement, lors des refactorings.",
            ),
        )
    else:
        _pass(report)

    # --- TODOs/FIXMEs ---
    todo_count = _int_fact(facts, "todo_count")
    if todo_count > 10:
        _add(
            report,
            Finding(
                "todo_fixme_count",
                "quality",
                "info",
                f"{todo_count} marqueurs TODO/FIXME/HACK dans le code.",
                f"todo_count={todo_count}",
                why=f"{todo_count} marqueurs TODO/FIXME/HACK dans le code. "
                "Chaque TODO est une promesse non tenue.",
                impact="Résoudre les TODOs réduit la dette technique et les surprises futures.",
                how="Lister les TODOs avec `grep -rn TODO src/` et les résoudre ou les convertir en tickets.",
                when="Lors des sprints de nettoyage.",
            ),
        )
    else:
        _pass(report)

    # --- Qualité Node ---
    if stack == "node":
        package_json_content = str(facts.get("package_json_content", ""))
        has_node_quality = any(
            tool in package_json_content for tool in ("eslint", "prettier", "biome", "typescript")
        )
        if not has_node_quality:
            _add(
                report,
                Finding(
                    "node_no_quality",
                    "quality",
                    "warning",
                    "Projet Node sans outils de qualité (linter, formatter, TypeScript).",
                    "",
                    why="Projet Node sans outils de qualité (linter, formatter, TypeScript). Le code accumule des incohérences.",
                    impact="ESLint + Prettier (ou Biome) attrapent les bugs et unifient le style automatiquement.",
                    how="Ajouter `eslint` et `prettier` dans devDependencies, ou utiliser `biome`.",
                    when="Dès le début du projet Node.",
                ),
            )
        else:
            _pass(report)

    # --- Qualité Rust ---
    if stack == "rust":
        ci_content = str(facts.get("ci_content", ""))
        has_rust_quality = any(kw in ci_content for kw in ("clippy", "cargo fmt", "cargo audit"))
        if not has_rust_quality:
            _add(
                report,
                Finding(
                    "rust_no_quality",
                    "quality",
                    "warning",
                    "Projet Rust sans clippy, cargo fmt ou cargo audit configurés dans la CI.",
                    "",
                    why="Projet Rust sans clippy, cargo fmt ou cargo audit configurés. Les bugs subtils et les vulnérabilités passent.",
                    impact="clippy attrape les patterns dangereux, fmt unifie le style, audit détecte les CVEs.",
                    how="Ajouter `cargo clippy`, `cargo fmt --check` et `cargo audit` dans la CI.",
                    when="Dès le début du projet Rust.",
                ),
            )
        else:
            _pass(report)

    # --- Qualité Go ---
    if stack == "go":
        ci_content = str(facts.get("ci_content", ""))
        workspace_go = facts.get("_workspace")
        has_go_sum = isinstance(workspace_go, Path) and (workspace_go / "go.sum").exists()
        has_go_quality = has_go_sum and any(
            kw in ci_content for kw in ("go vet", "staticcheck", "golangci-lint")
        )
        if not has_go_quality:
            _add(
                report,
                Finding(
                    "go_no_quality",
                    "quality",
                    "warning",
                    "Projet Go sans go.sum, go vet ou staticcheck configurés.",
                    "",
                    why="Projet Go sans go.sum, go vet ou staticcheck. Les dépendances ne sont pas verrouillées et les bugs ne sont pas détectés statiquement.",
                    impact="go vet et staticcheck trouvent des bugs que le compilateur ne voit pas.",
                    how="Commiter go.sum et ajouter `go vet ./...` dans la CI.",
                    when="Dès le début du projet Go.",
                ),
            )
        else:
            _pass(report)


# ---------------------------------------------------------------------------
# Documentation
# ---------------------------------------------------------------------------


def _check_docs(
    report: BlindSpotReport,
    facts: dict[str, object],
    spec: dict[str, object],
) -> None:
    """Détecteur de lacunes documentaires (CONTRIBUTING, ARCHITECTURE)."""
    source = _int_fact(facts, "source_files")

    # --- README trop court ---
    if facts.get("has_readme") and _int_fact(facts, "readme_lines") < 5:
        _add(
            report,
            Finding(
                "docs_too_thin",
                "docs",
                "warning",
                "Le README existe mais fait moins de 5 lignes — c'est un placeholder.",
                f"readme_lines={facts.get('readme_lines', 0)}",
                why="Le README existe mais fait moins de 5 lignes. C'est un placeholder, pas une documentation.",
                impact="Un README utile (installation, usage, exemples) permet de démarrer en 5 minutes.",
                how="Étoffer le README avec : description, installation, utilisation rapide, contribution.",
                when="Avant de partager le projet.",
            ),
        )
    elif facts.get("has_readme"):
        _pass(report)

    # --- CONTRIBUTING ---
    if source > 30 and not facts.get("has_contributing"):
        _add(
            report,
            Finding(
                "no_contributing",
                "docs",
                "info",
                "Pas de CONTRIBUTING.md — les nouveaux contributeurs ne savent pas par où commencer.",
                "",
                why="Sans guide de contribution, les nouveaux contributeurs ne savent pas par où commencer.",
                impact="Un CONTRIBUTING.md standardise le workflow et réduit les frictions.",
                how="Créer un CONTRIBUTING.md avec : comment cloner, installer, tester, et soumettre un PR.",
                when="Avant d'accueillir un contributeur externe.",
            ),
        )
    else:
        _pass(report)

    # --- ARCHITECTURE ---
    if source > 50 and not facts.get("has_architecture"):
        _add(
            report,
            Finding(
                "no_architecture_doc",
                "docs",
                "info",
                "Pas de document d'architecture — les décisions de design sont dans la tête d'une seule personne.",
                "",
                why="Sans documentation d'architecture, les décisions de design sont dans la tête d'une seule personne.",
                impact="Un document d'architecture permet à quiconque de comprendre le 'pourquoi' du design.",
                how="Créer un ARCHITECTURE.md avec : structure du projet, flux de données, et décisions clés.",
                when="Quand le projet dépasse 50 fichiers source.",
            ),
        )
    else:
        _pass(report)


# ---------------------------------------------------------------------------
# Opérations
# ---------------------------------------------------------------------------


def _check_operations(
    report: BlindSpotReport,
    facts: dict[str, object],
    spec: dict[str, object],
) -> None:
    """Détecteur de lacunes opérationnelles (observabilité, monitoring)."""
    source = _int_fact(facts, "source_files")

    if source > 30 and not facts.get("has_observability"):
        _add(
            report,
            Finding(
                "no_observability",
                "ops",
                "info",
                "Pas de système de logs ou de monitoring détecté.",
                f"source_files={source}",
                why="Pas de système de logs ou de monitoring détecté. En production, quand quelque chose casse, vous volez à l'aveugle.",
                impact="Des logs structurés et du monitoring permettent de diagnostiquer les problèmes en minutes au lieu d'heures.",
                how="Ajouter un framework de logging (Python: structlog/logging, Node: pino/winston, Rust: tracing).",
                when="Avant le premier déploiement en production.",
                mermaid_before="  Bug en prod ──► Pas de logs ──► On devine ──► Des heures",
                mermaid_after="  Bug en prod ──► Logs structurés ──► Diagnostic ──► Résolu vite",
            ),
        )
    else:
        _pass(report)
