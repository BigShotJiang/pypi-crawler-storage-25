"""Interview fixture parsing and deterministic text helpers."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from mobius.workflow.interview_types import (
    _AMBIGUOUS_MARKERS,
    _TESTABLE_SUCCESS_MARKERS,
    AmbiguityScore,
    InterviewFixture,
)
from mobius.workflow.templates import TEMPLATE_NAMES, ProjectTemplate


def parse_fixture(path: Path) -> InterviewFixture:
    """Parse a deterministic fixture from JSON or a small YAML subset."""
    raw = path.read_text(encoding="utf-8")
    values = _parse_mapping(raw)
    project_type = str(values.get("project_type", "greenfield")).strip().lower()
    if project_type not in {"greenfield", "brownfield"}:
        msg = "project_type doit être `greenfield` ou `brownfield`"
        raise ValueError(msg)
    template = str(values.get("template", "blank")).strip().lower() or "blank"
    if template not in TEMPLATE_NAMES:
        template = "blank"
    return InterviewFixture(
        project_type=project_type,
        goal=_as_text(values.get("goal")),
        constraints=_as_text_list(values.get("constraints")),
        success=_as_text_list(values.get("success_criteria", values.get("success"))),
        context=_as_text(values.get("context")),
        template=template,
    )


def fixture_from_template(
    template: ProjectTemplate, *, project_type: str = "greenfield"
) -> InterviewFixture:
    """Build a fixture pre-populated from a template (used as defaults)."""
    return InterviewFixture(
        project_type=project_type,
        goal=template.goal,
        constraints=list(template.constraints),
        success=list(template.success_criteria),
        context="",
        template=template.name,
    )

def _weakest_dimension(score: AmbiguityScore) -> str | None:
    if not score.components:
        return None
    failing = [key for key, ok in score.floor_details.items() if not ok]
    candidates = failing or list(score.components)
    return max(candidates, key=lambda key: score.components.get(key, 0.0))


def _combine_sentences(*parts: str) -> str:
    clean = [part.strip().rstrip(".") for part in parts if part.strip()]
    if not clean:
        return ""
    return ". ".join(clean) + "."


def _default_branches(template_name: str, project_type: str) -> list[str]:
    branches = ["utilisateur", "résultat mesurable"]
    if project_type == "brownfield":
        branches.append("intégration existante")
    if template_name in {"web", "mobile"}:
        branches.append("expérience utilisateur")
    elif template_name in {"cli", "lib"}:
        branches.append("contrat d'interface")
    else:
        branches.append("périmètre")
    return branches


def _semantic_clarity(fixture: InterviewFixture) -> dict[str, int]:
    objectif = _semantic_axis_score(fixture.goal, require_numbers=False)
    comment = _semantic_axis_score(" ".join(fixture.constraints), require_numbers=False)
    criteres = _semantic_axis_score(" ".join(fixture.success), require_numbers=True)
    return {
        "objectif": objectif,
        "comment": comment,
        "criteres": criteres,
        "total": objectif + comment + criteres,
    }


def _semantic_axis_score(text: str, *, require_numbers: bool) -> int:
    stripped = text.strip()
    if not stripped:
        return 0
    words = stripped.split()
    score = 2
    if len(words) >= 8:
        score += 1
    if any(char.isdigit() for char in stripped):
        score += 1
    clarity_markers = ("pour", "with", "avec", "without", "sans")
    verification_markers = ("test", "verify", "vérif", "pass", "%", "p95", "p99")
    lowered = stripped.lower()
    if not require_numbers and any(marker in lowered for marker in clarity_markers):
        score += 1
    if require_numbers and any(marker in lowered for marker in verification_markers):
        score += 1
    return min(score, 5)


def _infer_risks(premortem: str) -> list[str]:
    risks = [part.strip(" .") for part in premortem.split(";") if part.strip(" .")]
    return risks or ["Le scénario d'échec n'a pas été formulé clairement"]


def _infer_decision_boundaries(constraints: list[str], non_goals: list[str]) -> list[str]:
    boundaries = [
        f"Respecter la contrainte: {item}"
        for item in constraints
        if item.strip() and item.strip().lower() not in _AMBIGUOUS_MARKERS
    ]
    boundaries.extend(
        f"Revenir à l'humain avant de franchir le non-goal: {item}"
        for item in non_goals
        if item.strip() and item.strip().lower() not in _AMBIGUOUS_MARKERS
    )
    return boundaries or [
        "L'agent peut choisir l'implémentation seulement si les critères restent vérifiables.",
        "Revenir à l'humain si le périmètre ou le risque change.",
    ]


def _metadata_text_list(value: object) -> list[str]:
    if value is None:
        return []
    if isinstance(value, list):
        return [str(item).strip() for item in value if str(item).strip()]
    text = str(value).strip()
    return [text] if text else []


def _has_testable_success(success: list[str]) -> bool:
    joined = " ".join(success).lower()
    if any(char.isdigit() for char in joined):
        return True
    return any(marker in joined for marker in _TESTABLE_SUCCESS_MARKERS)


def _parse_mapping(raw: str) -> dict[str, Any]:
    stripped = raw.strip()
    if stripped.startswith("{"):
        parsed = json.loads(stripped)
        if not isinstance(parsed, dict):
            msg = "fixture JSON must contain an object"
            raise ValueError(msg)
        return dict(parsed)
    return _parse_simple_yaml(stripped)


def _parse_simple_yaml(raw: str) -> dict[str, Any]:
    result: dict[str, Any] = {}
    current_list_key: str | None = None
    block_scalar_key: str | None = None
    block_scalar_lines: list[str] = []

    def _flush_block_scalar() -> None:
        nonlocal block_scalar_key, block_scalar_lines
        if block_scalar_key is not None:
            result[block_scalar_key] = " ".join(block_scalar_lines)
            block_scalar_key = None
            block_scalar_lines = []

    for raw_line in raw.splitlines():
        line = raw_line.rstrip()
        stripped = line.strip()
        if block_scalar_key is not None:
            if stripped and (line[0] == " " or line[0] == "\t"):
                block_scalar_lines.append(stripped)
                continue
            _flush_block_scalar()
        if not stripped or stripped.startswith("#"):
            continue
        if stripped.startswith("- "):
            if current_list_key is None:
                msg = f"élément de liste sans clé précédente : {line}"
                raise ValueError(msg)
            value = _strip_quotes(stripped[2:].strip())
            cast_list = result.setdefault(current_list_key, [])
            if not isinstance(cast_list, list):
                msg = (
                    f"key {current_list_key!r} ne peut pas contenir à la fois "
                    "une valeur scalaire et une liste"
                )
                raise ValueError(msg)
            cast_list.append(value)
            continue
        if ":" not in stripped:
            msg = f"ligne de fixture non supportée : {line}"
            raise ValueError(msg)
        key, value = stripped.split(":", 1)
        current_list_key = None
        normalized_key = key.strip()
        normalized_value = value.strip()
        if normalized_value in {">", "|", ">-", "|-"}:
            block_scalar_key = normalized_key
            block_scalar_lines = []
        elif normalized_value == "[]":
            result[normalized_key] = []
        elif normalized_value == "":
            result[normalized_key] = []
            current_list_key = normalized_key
        else:
            result[normalized_key] = _strip_quotes(normalized_value)
    _flush_block_scalar()
    return result


def _strip_quotes(value: str) -> str:
    if len(value) >= 2 and value[0] == value[-1] and value[0] in {"'", '"'}:
        inner = value[1:-1]
        if value[0] == '"':
            from mobius.workflow._yaml import yaml_unescape

            return yaml_unescape(inner)
        return inner
    return value


def _as_text(value: object) -> str:
    if value is None:
        return ""
    if isinstance(value, list):
        return " ".join(str(item).strip() for item in value if str(item).strip())
    return str(value).strip()


def _as_text_list(value: object) -> list[str]:
    if value is None:
        return []
    if isinstance(value, list):
        return [str(item).strip() for item in value if str(item).strip()]
    text = str(value).strip()
    return [text] if text else []


def _ambiguity_for_scalar(value: str) -> float:
    return 1.0 if _is_ambiguous(value) else 0.0


def _ambiguity_for_list(values: list[str]) -> float:
    if not values:
        return 1.0
    ambiguous = sum(1 for value in values if _is_ambiguous(value))
    return round(ambiguous / len(values), 3)


def _is_ambiguous(value: str) -> bool:
    normalized = value.strip().lower()
    return normalized in _AMBIGUOUS_MARKERS or normalized.startswith(("tbd", "todo"))
