"""Interview spec YAML rendering."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from mobius.workflow._yaml import yaml_list as _yaml_list
from mobius.workflow._yaml import yaml_scalar as _yaml_scalar
from mobius.workflow.interview_types import AmbiguityScore, InterviewFixture


def render_spec_yaml(
    session_id: str,
    fixture: InterviewFixture,
    score: AmbiguityScore,
    *,
    deep_metadata_path: Path | None = None,
    deep_metadata: dict[str, Any] | None = None,
) -> str:
    """Render a stable project spec YAML document."""
    lines = [
        f"session_id: {_yaml_scalar(session_id)}",
        f"project_type: {_yaml_scalar(fixture.project_type)}",
        f"template: {_yaml_scalar(fixture.template)}",
        f"ambiguity_score: {score.score}",
        f"ambiguity_gate: {score.threshold}",
        "ambiguity_components:",
    ]
    for key in score.weights:
        lines.append(f"  {key}: {score.components[key]}")
    lines.extend(
        [
            f"goal: {_yaml_scalar(fixture.goal)}",
            "constraints:",
            *_yaml_list(fixture.constraints),
            "success_criteria:",
            *_yaml_list(fixture.success),
        ]
    )
    if fixture.is_brownfield:
        lines.append(f"context: {_yaml_scalar(fixture.context)}")
    if deep_metadata is not None or deep_metadata_path is not None:
        deep = dict(deep_metadata or {})
        if deep_metadata_path is not None:
            deep.update(_load_deep_metadata(deep_metadata_path))
        lines.extend(_render_deep_metadata(deep))
    return "\n".join(lines) + "\n"


def _load_deep_metadata(path: Path) -> dict[str, Any]:
    """Load and validate a deep-metadata JSON file."""
    raw = path.read_text(encoding="utf-8")
    data = json.loads(raw)
    if not isinstance(data, dict):
        msg = "deep metadata JSON must contain an object"
        raise ValueError(msg)
    return data


def _render_deep_metadata(deep: dict[str, Any]) -> list[str]:
    """Render deep interview metadata as YAML lines."""
    lines: list[str] = []
    if "interview_mode" in deep:
        lines.append(f"interview_mode: {_yaml_scalar(str(deep['interview_mode']))}")
    if "clarity_score" in deep and isinstance(deep["clarity_score"], dict):
        lines.append("clarity_score:")
        for k, v in deep["clarity_score"].items():
            lines.append(f"  {k}: {v}")
    if "risks" in deep and isinstance(deep["risks"], list):
        lines.append("risks:")
        for risk in deep["risks"]:
            if isinstance(risk, dict):
                first = True
                for k, v in risk.items():
                    prefix = "  - " if first else "    "
                    lines.append(f"{prefix}{k}: {_yaml_scalar(str(v))}")
                    first = False
    if "assumptions" in deep and isinstance(deep["assumptions"], list):
        lines.append("assumptions:")
        for assumption in deep["assumptions"]:
            if isinstance(assumption, dict):
                first = True
                for k, v in assumption.items():
                    prefix = "  - " if first else "    "
                    lines.append(f"{prefix}{k}: {_yaml_scalar(str(v))}")
                    first = False
    if "premortem" in deep:
        lines.append(f"premortem: {_yaml_scalar(str(deep['premortem']))}")
    if "branches_explored" in deep:
        lines.append(f"branches_explored: {deep['branches_explored']}")
    if "question_ledger" in deep and isinstance(deep["question_ledger"], list):
        ledger_json = json.dumps(deep["question_ledger"], sort_keys=True, ensure_ascii=False)
        lines.append(f"question_ledger: {_yaml_scalar(ledger_json)}")
    if "closure_challenge" in deep and isinstance(deep["closure_challenge"], dict):
        challenge_json = json.dumps(deep["closure_challenge"], sort_keys=True, ensure_ascii=False)
        lines.append(f"closure_challenge: {_yaml_scalar(challenge_json)}")
    if "second_opinion" in deep and isinstance(deep["second_opinion"], dict):
        opinion_json = json.dumps(deep["second_opinion"], sort_keys=True, ensure_ascii=False)
        lines.append(f"second_opinion: {_yaml_scalar(opinion_json)}")
    if "ambiguity_ledger" in deep and isinstance(deep["ambiguity_ledger"], dict):
        ledger_json = json.dumps(
            deep["ambiguity_ledger"],
            sort_keys=True,
            ensure_ascii=False,
        )
        lines.append(
            f"ambiguity_ledger: {_yaml_scalar(ledger_json)}"
        )
    if "criteria_tree" in deep and isinstance(deep["criteria_tree"], list):
        lines.append("criteria_tree:")
        lines.extend(_yaml_mapping_list(deep["criteria_tree"]))
    if (
        "verification_commands" in deep
        and isinstance(deep["verification_commands"], list)
        and deep["verification_commands"]
    ):
        lines.append("verification_commands:")
        lines.extend(_yaml_mapping_list(deep["verification_commands"]))
    if "enforcement_matrix" in deep and isinstance(deep["enforcement_matrix"], list):
        lines.append("enforcement_matrix:")
        lines.extend(_yaml_mapping_list(deep["enforcement_matrix"]))
    metadata = dict(deep["metadata"]) if isinstance(deep.get("metadata"), dict) else {}
    if "conversation_memory" in deep and isinstance(deep["conversation_memory"], list):
        metadata["conversation_memory"] = json.dumps(
            deep["conversation_memory"],
            sort_keys=True,
            ensure_ascii=False,
        )
    if metadata:
        lines.append("metadata:")
        for k, v in metadata.items():
            lines.append(f"  {k}: {_yaml_scalar(str(v))}")
    if "concepts" in deep and isinstance(deep["concepts"], list):
        lines.append("concepts:")
        for concept in deep["concepts"]:
            if isinstance(concept, dict):
                first = True
                for k, v in concept.items():
                    prefix = "  - " if first else "    "
                    lines.append(f"{prefix}{k}: {_yaml_scalar(str(v))}")
                    first = False
    if "non_goals" in deep and isinstance(deep["non_goals"], list):
        lines.append("non_goals:")
        lines.extend(_yaml_list([str(item) for item in deep["non_goals"]]))
    if "decision_boundaries" in deep and isinstance(deep["decision_boundaries"], list):
        lines.append("decision_boundaries:")
        lines.extend(_yaml_list([str(item) for item in deep["decision_boundaries"]]))
    if "ontology" in deep and isinstance(deep["ontology"], dict) and deep["ontology"]:
        lines.append("ontology:")
        for entity_name, entity_def in deep["ontology"].items():
            lines.append(f"  {entity_name}:")
            if isinstance(entity_def, dict):
                for k, v in entity_def.items():
                    if isinstance(v, dict) and v:
                        lines.append(f"    {k}:")
                        for fk, fv in v.items():
                            lines.append(f"      {fk}: {_yaml_scalar(str(fv))}")
                    elif isinstance(v, dict):
                        lines.append(f"    {k}: {{}}")
                    else:
                        lines.append(f"    {k}: {_yaml_scalar(str(v))}")
    return lines


def _yaml_mapping_list(items: list[Any]) -> list[str]:
    """Render a list of shallow mappings in the seed-spec YAML subset."""
    lines: list[str] = []
    for item in items:
        if not isinstance(item, dict) or not item:
            continue
        first = True
        for key, value in item.items():
            prefix = "  - " if first else "    "
            lines.append(f"{prefix}{key}: {_yaml_scalar(str(value))}")
            first = False
    return lines


def question_answers(fixture: InterviewFixture) -> list[tuple[str, str, str | list[str]]]:
    """Return deterministic question/answer triples for persistence events."""
    answers: list[tuple[str, str, str | list[str]]] = [
        ("project_type", "Quel type de projet est-ce ?", fixture.project_type),
        ("template", "Quel template correspond le mieux à ce projet ?", fixture.template),
        ("goal", "Quel objectif ce projet doit-il atteindre ?", fixture.goal),
        (
            "constraints",
            "Quelles contraintes la solution doit-elle respecter ?",
            fixture.constraints,
        ),
        ("success", "Quels résultats prouvent le succès ?", fixture.success),
    ]
    if fixture.is_brownfield:
        answers.append(("context", "Quel contexte existant doit être préservé ?", fixture.context))
    return answers
