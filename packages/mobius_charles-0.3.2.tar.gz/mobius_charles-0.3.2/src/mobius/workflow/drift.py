"""Deterministic drift scoring for Mobius evolution generations."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from mobius.workflow.seed import SeedSpec

DRIFT_ALERT_THRESHOLD = 0.3
DRIFT_WEIGHTS: dict[str, float] = {"goal": 0.5, "constraints": 0.3, "ontology": 0.2}


@dataclass(frozen=True)
class DriftReport:
    """Weighted comparison between the source spec and one generation state."""

    score: float
    threshold: float
    alert: bool
    weights: dict[str, float]
    components: dict[str, float]
    details: dict[str, object]

    def to_event_payload(self) -> dict[str, object]:
        """Return a JSON-compatible event payload."""
        return {
            "score": self.score,
            "threshold": self.threshold,
            "alert": self.alert,
            "weights": dict(self.weights),
            "components": dict(self.components),
            "details": dict(self.details),
        }


def score_generation_drift(spec: SeedSpec, candidate: dict[str, Any]) -> DriftReport:
    """Score how far an evolution generation drifted from the original spec.

    The metric mirrors the Ouroboros-style dimensions without calling an LLM:
    goal continuity (50%), constraint pressure (30%), and ontology/criteria
    coverage (20%).  A score above ``0.3`` is an alert.
    """
    payload = candidate.get("payload") if isinstance(candidate, dict) else {}
    if not isinstance(payload, dict):
        payload = {}
    success_total = max(1, len(spec.success_criteria))
    failed_count = _coerce_int(payload.get("failed"), default=0)
    criterion_ids = payload.get("criterion_ids")
    failed_ids = [str(item) for item in criterion_ids] if isinstance(criterion_ids, list) else []
    criterion_pressure = min(1.0, max(failed_count, len(failed_ids)) / success_total)
    candidate_type = str(candidate.get("type", "")) if isinstance(candidate, dict) else ""
    goal_component = 0.0 if candidate_type == "acceptance-criteria" else 1.0
    constraint_component = criterion_pressure if spec.constraints else 0.0
    ontology_component = _ontology_component(failed_ids, success_total)
    components = {
        "goal": round(goal_component, 3),
        "constraints": round(constraint_component, 3),
        "ontology": round(ontology_component, 3),
    }
    score = round(sum(DRIFT_WEIGHTS[key] * components[key] for key in DRIFT_WEIGHTS), 3)
    return DriftReport(
        score=score,
        threshold=DRIFT_ALERT_THRESHOLD,
        alert=score > DRIFT_ALERT_THRESHOLD,
        weights=dict(DRIFT_WEIGHTS),
        components=components,
        details={
            "goal": spec.goal,
            "constraint_count": len(spec.constraints),
            "success_criteria_count": len(spec.success_criteria),
            "failed_criteria_count": max(failed_count, len(failed_ids)),
            "failed_criterion_ids": failed_ids,
            "candidate_type": candidate_type,
        },
    )


def _ontology_component(failed_ids: list[str], success_total: int) -> float:
    if not failed_ids:
        return 0.0
    unknown = [item for item in failed_ids if not item.startswith("criterion_")]
    if unknown:
        return 1.0
    return min(1.0, len(set(failed_ids)) / success_total)


def _coerce_int(value: object, *, default: int) -> int:
    if isinstance(value, bool):
        return int(value)
    if isinstance(value, int):
        return max(0, value)
    try:
        return max(0, int(str(value)))
    except (TypeError, ValueError):
        return default
