"""Shared lifecycle primitives for detached workflow workers."""

from __future__ import annotations

import os
import signal
import sqlite3
import subprocess
import sys
from contextlib import suppress
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING, NoReturn, Protocol

if TYPE_CHECKING:
    from mobius.config import MobiusPaths
    from mobius.persistence.event_store import EventStore

TERMINAL_STATES = frozenset({"completed", "failed", "crashed", "cancelled", "interrupted"})
OK_EXIT_CODE = 0
INTERRUPTED_EXIT_CODE = 130


class WorkerFileSet(Protocol):
    """Filesystem paths needed by detached worker lifecycle helpers."""

    @property
    def pid_file(self) -> Path:
        """Path containing the worker PID."""

    @property
    def log_file(self) -> Path:
        """Path receiving detached worker stderr."""


@dataclass(frozen=True)
class DetachedWorkerSpec:
    """Session and process details needed to start a detached worker."""

    session_id: str
    runtime: str
    metadata: dict[str, object]
    command: list[str]
    files: WorkerFileSet


def start_detached_worker_process(paths: MobiusPaths, spec: DetachedWorkerSpec) -> int:
    """Create the worker session, fork the process, and persist its PID."""
    from mobius.persistence.event_store import EventStore

    with EventStore(paths.event_store) as store:
        store.create_session(
            spec.session_id,
            runtime=spec.runtime,
            metadata=spec.metadata,
            status="running",
        )
    spec.files.log_file.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    with spec.files.log_file.open("ab") as log_file, Path(os.devnull).open("rb") as devnull:
        process = subprocess.Popen(
            spec.command,
            stdin=devnull,
            stdout=devnull,
            stderr=log_file,
            start_new_session=True,
        )
    write_pid(spec.files.pid_file, process.pid)
    return process.pid


class WorkerInterrupted:
    """Signal handlers for a running workflow worker."""

    def __init__(
        self,
        *,
        paths: MobiusPaths,
        session_id: str,
        runtime: str,
        pid_file: Path,
    ) -> None:
        self.paths = paths
        self.session_id = session_id
        self.runtime = runtime
        self.pid_file = pid_file

    def handle_sigterm(self, _signum: int, _frame: object | None) -> NoReturn:
        """Handle graceful cancellation."""
        self._finish("cancelled", f"{self.runtime}.cancelled")
        raise SystemExit(OK_EXIT_CODE)

    def handle_sigint(self, _signum: int, _frame: object | None) -> NoReturn:
        """Handle interactive interruption."""
        self._finish("interrupted", f"{self.runtime}.interrupted")
        sys.stderr.write("interrompu\n")
        raise SystemExit(INTERRUPTED_EXIT_CODE)

    def install(self) -> None:
        """Install SIGTERM/SIGINT handlers for the current process."""
        signal.signal(signal.SIGTERM, self.handle_sigterm)
        signal.signal(signal.SIGINT, self.handle_sigint)

    def _finish(self, status: str, event_type: str) -> None:
        from mobius.persistence.event_store import EventStore

        with EventStore(self.paths.event_store) as store:
            try:
                store.connection.execute("PRAGMA busy_timeout=1000")
                existing = [event.type for event in store.read_events(self.session_id)]
                if event_type not in existing:
                    store.append_event(self.session_id, event_type, {"signal": status})
                    store.end_session(self.session_id, status=status)
            except sqlite3.OperationalError as exc:
                sys.stderr.write(f"mobius: could not record {event_type}: {exc}\n")
        cleanup_pid(self.pid_file)


def append_and_emit(
    store: EventStore,
    session_id: str,
    event_type: str,
    payload: dict[str, object],
    *,
    stream_events: bool,
) -> None:
    """Append an event and optionally stream the emitted event line."""
    event = store.append_event(session_id, event_type, payload)
    if stream_events:
        sys.stderr.write(f"{event.created_at} {event.type} {event.payload}\n")
        sys.stderr.flush()


def write_pid(path: Path, pid: int) -> None:
    """Atomically write a worker PID with private permissions."""
    path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    temp_path = path.with_name(f".{path.name}.tmp")
    temp_path.write_text(f"{pid}\n", encoding="utf-8")
    os.chmod(temp_path, 0o600)
    temp_path.replace(path)
    os.chmod(path, 0o600)


def cleanup_pid(path: Path) -> None:
    """Remove a worker PID file if it exists."""
    with suppress(FileNotFoundError):
        path.unlink()


def read_pid(path: Path) -> int | None:
    """Read a positive PID from ``path``."""
    try:
        pid = int(path.read_text(encoding="utf-8").strip())
    except (OSError, ValueError):
        return None
    return pid if pid > 0 else None


def pid_is_live(pid: int) -> bool:
    """Return whether ``pid`` appears to refer to a live process."""
    try:
        os.kill(pid, 0)
    except ProcessLookupError:
        return False
    except PermissionError:
        return True
    return True


def is_terminal_state(state: str) -> bool:
    """Return whether ``state`` is a terminal session state."""
    return state in TERMINAL_STATES
