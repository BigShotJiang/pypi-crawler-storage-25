"""Shared interview data types and constants."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, ClassVar

_GATE_THRESHOLD = 0.2
_AMBIGUOUS_MARKERS = frozenset({"", "tbd", "todo", "unknown", "unclear", "n/a", "na", "?"})

_DIMENSION_FLOORS: dict[str, float] = {
    "goal": 0.75,
    "constraints": 0.65,
    "success": 0.70,
    "context": 0.60,
}
_RHYTHM_GUARD_THRESHOLD = 3
_SEED_CLOSER_STREAK = 2


class RoutingPath(Enum):
    """Catégorisation du chemin de routage pour chaque question d'interview."""

    AUTO_CONFIRM = "1a"
    CODE_CONFIRM = "1b"
    HUMAN_JUDGMENT = "2"
    CODE_PLUS_JUDGMENT = "3"
    RESEARCH = "4"


@dataclass(frozen=True)
class RoutingDecision:
    """Décision de routage pour une question d'interview."""

    path: RoutingPath
    source: str = ""
    rationale: str = ""


@dataclass
class RhythmGuardState:
    """Compteur de garde dialectique — force l'humain tous les N auto-confirms."""

    streak: int = 0
    threshold: int = _RHYTHM_GUARD_THRESHOLD
    _history: list[RoutingPath] = field(default_factory=list)

    def record(self, path: RoutingPath) -> None:
        """Enregistre un chemin et met à jour le streak."""
        self._history.append(path)
        if path in {RoutingPath.HUMAN_JUDGMENT, RoutingPath.CODE_PLUS_JUDGMENT}:
            self.streak = 0
        else:
            self.streak += 1

    @property
    def must_force_human(self) -> bool:
        """Renvoie True si le prochain tour doit être forcé en PATH 2."""
        return self.streak >= self.threshold

    def reset(self) -> None:
        """Remet le streak à zéro."""
        self.streak = 0


def route_with_rhythm(question: Any, context: Any, rhythm: RhythmGuardState) -> RoutingDecision:
    """Route a question and enforce the Ouroboros dialectic rhythm guard.

    The underlying router decides the factual path. If the previous streak has
    already reached the threshold and the router would answer without direct
    human judgment, this helper forces PATH2 and records the reason.
    """
    from mobius.workflow.question_router import route_question

    decision = route_question(question, context)
    if rhythm.must_force_human and decision.path not in {
        RoutingPath.HUMAN_JUDGMENT,
        RoutingPath.CODE_PLUS_JUDGMENT,
    }:
        rationale = "dialectic_rhythm_forced_human"
        if decision.rationale:
            rationale = f"{rationale}; {decision.rationale}"
        return RoutingDecision(
            path=RoutingPath.HUMAN_JUDGMENT,
            source=decision.source,
            rationale=rationale,
        )
    return decision


@dataclass(frozen=True)
class InterviewFixture:
    """Deterministic non-interactive interview answers."""

    project_type: str
    goal: str
    constraints: list[str]
    success: list[str]
    context: str
    template: str = "blank"

    @property
    def is_brownfield(self) -> bool:
        """Return whether context should participate in ambiguity scoring."""
        return self.project_type == "brownfield"


@dataclass(frozen=True)
class InteractiveInterviewResult:
    """Result of an interactive interview, including optional deep metadata."""

    fixture: InterviewFixture
    deep_metadata: dict[str, Any] | None = None


@dataclass(frozen=True)
class AmbiguityScore:
    """Weighted ambiguity score for an interview."""

    score: float
    threshold: float
    passed: bool
    weights: dict[str, float]
    components: dict[str, float]
    floors_met: bool = True
    floor_details: dict[str, bool] = field(default_factory=dict)

    @property
    def seed_ready(self) -> bool:
        """Renvoie True si le score ET les floors sont satisfaits."""
        return self.passed and self.floors_met

    _DIMENSION_LABELS: ClassVar[dict[str, str]] = {
        "goal": "L'objectif principal",
        "constraints": "Les contraintes",
        "success": "Les critères de succès",
        "context": "Le contexte existant",
    }
    _DIMENSION_ADVICE: ClassVar[dict[str, str]] = {
        "goal": (
            "Reformulez en une phrase testable : « Le projet doit [verbe] [résultat mesurable]. »"
        ),
        "constraints": "Ajoutez au moins 2 contraintes concrètes (technique, temps, budget).",
        "success": "Définissez des critères observables : « [métrique] atteint [seuil]. »",
        "context": "Décrivez le système existant que la solution doit préserver.",
    }
    _LEADING_QUESTIONS: ClassVar[dict[str, str]] = {
        "goal": "« Comment saurai-je que c'est terminé ? »",
        "constraints": "« Quelles limites absolues ne peut-on pas franchir ? »",
        "success": "« Comment saurai-je que c'est terminé ? »",
        "context": "« Qu'est-ce qui doit absolument rester inchangé ? »",
    }

    def human_diagnostic(self) -> str:
        """Retourne un message de diagnostic lisible en français, ou '' si seed_ready."""
        if self.seed_ready:
            return ""

        failing: list[str] = []
        if not self.passed:
            # Les dimensions dont le score dépasse le gate
            failing = [key for key, ambiguity in self.components.items() if ambiguity > 0.0]
        if not self.floors_met:
            floor_failing = [k for k, v in self.floor_details.items() if not v]
            # Fusionner sans doublons, préserver l'ordre
            seen = set(failing)
            for dim in floor_failing:
                if dim not in seen:
                    failing.append(dim)
                    seen.add(dim)

        if not failing:
            # Cas de secours : lister toutes les dimensions connues
            failing = list(self.components.keys())

        # Construire la liste des dimensions défaillantes avec leur label
        dim_lines = "\n".join(
            f"  • {self._DIMENSION_LABELS.get(dim, dim)}"
            + (
                " (trop large)"
                if dim == "goal"
                else " (aucun défini)"
                if dim in {"success", "constraints"}
                else ""
            )
            for dim in failing
        )

        # Question de relance la plus pertinente (première dimension défaillante)
        leading = self._LEADING_QUESTIONS.get(failing[0], "« Comment rendre cela plus précis ? »")

        # Conseil principal (première dimension défaillante)
        conseil = self._DIMENSION_ADVICE.get(
            failing[0],
            "Précisez chaque réponse avec des détails mesurables.",
        )

        return (
            "Votre description est encore trop vague pour générer une spec fiable.\n"
            "\n"
            "Ce qui manque de clarté :\n"
            f"{dim_lines}\n"
            "\n"
            f"Essayez de répondre à :\n"
            f"  {leading}\n"
            "\n"
            f"Conseil : {conseil}"
        )

    def raise_for_gate(self) -> None:
        """Raise if the ambiguity gate is not satisfied."""
        if not self.passed or not self.floors_met:
            diagnostic = self.human_diagnostic()
            if not diagnostic:
                diagnostic = "La spec n'est pas assez claire pour continuer."
            diagnostic = f"ambiguity exceeds gate: {diagnostic}"
            raise AmbiguityGateError(diagnostic)


class AmbiguityGateError(ValueError):
    """Raised when an interview cannot produce a spec due to ambiguity."""

_TESTABLE_SUCCESS_MARKERS = frozenset(
    {
        "test",
        "tests",
        "pytest",
        "verify",
        "verified",
        "verification",
        "vérif",
        "preuve",
        "observable",
        "mesurable",
        "metric",
        "métrique",
        "seuil",
        "generated",
        "généré",
        "created",
        "créé",
        "persisted",
        "persisté",
        "pass",
        "passes",
        "output",
        "sortie",
        "e2e",
        "end-to-end",
    }
)


@dataclass(frozen=True)
class SeedCloserGate:
    """Gate multi-critère inspirée d'Ouroboros avant fermeture d'interview."""

    ambiguity_passed: bool
    floors_met: bool
    floor_details: dict[str, bool]
    qualifying_streak: int
    streak_required: int = _SEED_CLOSER_STREAK
    closure_blockers: tuple[str, ...] = ()

    @property
    def passed(self) -> bool:
        """Renvoie True si les 3 conditions sont réunies."""
        return (
            self.ambiguity_passed
            and self.floors_met
            and self.qualifying_streak >= self.streak_required
            and not self.closure_blockers
        )

    @property
    def weakest_dimension(self) -> str | None:
        """Renvoie la dimension la plus faible, ou None si tout passe."""
        failing = [k for k, v in self.floor_details.items() if not v]
        return failing[0] if failing else None
