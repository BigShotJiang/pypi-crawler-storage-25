from __future__ import annotations

import json
import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

SCHEMA_TOUR_DEEP: tuple[str, ...] = (
    "question",
    "answer",
    "score_avant",
    "score_apres",
    "routing_path",
    "closure_blockers",
    "prochaine_question",
    "decisions_ouvertes",
)


@dataclass(frozen=True)
class InterviewRoundMemory:
    round_index: int
    question_key: str
    question: str
    answer: str
    because: str
    routing_path: str
    source: str
    ambiguity_before: float
    ambiguity_after: float
    closure_blockers: tuple[str, ...] = ()
    next_question: str = ""
    open_decisions: tuple[str, ...] = ()
    branch: str = ""

    def to_payload(self) -> dict[str, Any]:
        payload = {
            "round_index": self.round_index,
            "question_key": self.question_key,
            "question": self.question,
            "answer": self.answer,
            "score_avant": self.ambiguity_before,
            "score_apres": self.ambiguity_after,
            "because": self.because,
            "routing_path": self.routing_path,
            "source": self.source,
            "ambiguity_before": self.ambiguity_before,
            "ambiguity_after": self.ambiguity_after,
            "closure_blockers": list(self.closure_blockers),
            "prochaine_question": self.next_question,
            "decisions_ouvertes": list(self.open_decisions),
            "branch": self.branch,
        }
        manquants = [cle for cle in SCHEMA_TOUR_DEEP if cle not in payload]
        if manquants:
            message = "schema de tour deep incomplet: " + ", ".join(manquants)
            raise ValueError(message)
        return payload


@dataclass(frozen=True)
class ConversationMemory:
    rounds: tuple[InterviewRoundMemory, ...] = field(default_factory=tuple)

    def record(self, round_memory: InterviewRoundMemory) -> ConversationMemory:
        return ConversationMemory(rounds=(*self.rounds, round_memory))

    def latest_answer(self, question_key: str) -> str:
        for round_memory in reversed(self.rounds):
            if round_memory.question_key == question_key:
                return round_memory.answer
        return ""

    def covered_keys(self) -> set[str]:
        return {round_memory.question_key for round_memory in self.rounds}

    def to_payload(self) -> list[dict[str, Any]]:
        return [round_memory.to_payload() for round_memory in self.rounds]


def chemin_progression(workspace: Path) -> Path:
    """Retourne le fichier local de reprise pour l'interview deep."""
    return workspace / "progress.json"


def charger_progression(chemin: Path) -> dict[str, Any]:
    """Charge une progression JSON existante ou retourne un état vide."""
    if not chemin.exists():
        return {}
    contenu = json.loads(chemin.read_text(encoding="utf-8"))
    return contenu if isinstance(contenu, dict) else {}


def sauvegarder_progression_atomique(chemin: Path, progression: dict[str, Any]) -> None:
    """Écrit la progression par fichier temporaire puis renommage atomique."""
    chemin.parent.mkdir(parents=True, exist_ok=True)
    temporaire = chemin.with_name(f".{chemin.name}.tmp")
    temporaire.write_text(
        json.dumps(progression, ensure_ascii=False, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    os.replace(temporaire, chemin)


def reconstruire_memoire(progression: dict[str, Any]) -> ConversationMemory:
    """Reconstruit la mémoire depuis les tours sauvegardés."""
    tours = progression.get("tours")
    if not isinstance(tours, list):
        return ConversationMemory()

    def _float_or_default(value: object, default: float) -> float:
        if value is None:
            return default
        if isinstance(value, str | bytes | int | float):
            return float(value)
        return default

    memoire = ConversationMemory()
    for brut in tours:
        if not isinstance(brut, dict):
            continue
        ambiguity_before = _float_or_default(
            brut.get("ambiguity_before", brut.get("score_avant")),
            1.0,
        )
        ambiguity_after = _float_or_default(
            brut.get("ambiguity_after", brut.get("score_apres")),
            1.0,
        )
        memoire = memoire.record(
            InterviewRoundMemory(
                round_index=int(brut.get("round_index") or len(memoire.rounds) + 1),
                question_key=str(brut.get("question_key") or ""),
                question=str(brut.get("question") or ""),
                answer=str(brut.get("answer") or ""),
                because=str(brut.get("because") or ""),
                routing_path=str(brut.get("routing_path") or ""),
                source=str(brut.get("source") or "user"),
                ambiguity_before=ambiguity_before,
                ambiguity_after=ambiguity_after,
                closure_blockers=tuple(str(item) for item in brut.get("closure_blockers", [])),
                next_question=str(brut.get("prochaine_question") or ""),
                open_decisions=tuple(str(item) for item in brut.get("decisions_ouvertes", [])),
                branch=str(brut.get("branch") or ""),
            )
        )
    return memoire
