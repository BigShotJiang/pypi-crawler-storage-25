"""Seed readiness closer for the interview workflow."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from mobius.workflow.interview import AmbiguityScore, InterviewClarityContract, InterviewFixture


@dataclass(frozen=True)
class SeedCloserVerdict:
    """Final deterministic verdict for closing an interview into seed/run."""

    checks: dict[str, bool]
    blockers: tuple[str, ...]
    seed_ready: bool
    highest_impact_followup: str

    def to_payload(self) -> dict[str, Any]:
        """Return the legacy closure_challenge payload shape."""
        return {
            "checks": dict(self.checks),
            "blockers": list(self.blockers),
            "seed_ready": self.seed_ready,
            "highest_impact_followup": self.highest_impact_followup,
        }


def close_interview(
    fixture: InterviewFixture,
    score: AmbiguityScore,
    contract: InterviewClarityContract,
    second_opinion: dict[str, Any],
) -> SeedCloserVerdict:
    """Judge whether an interview is ready to close into a seedable spec."""
    checks = {
        "non_goals_present": bool(contract.non_goals),
        "decision_boundaries_present": bool(contract.decision_boundaries),
        "success_criteria_testable": "success_criteria_not_testable"
        not in contract.closure_blockers,
        "ambiguity_floor_passed": score.seed_ready,
        "second_opinion_passed": second_opinion.get("verdict") == "pass",
    }
    blockers = tuple(key for key, passed in checks.items() if not passed)
    return SeedCloserVerdict(
        checks=checks,
        blockers=blockers,
        seed_ready=not blockers,
        highest_impact_followup=_followup(blockers, score),
    )


def _followup(blockers: tuple[str, ...], score: AmbiguityScore) -> str:
    if "non_goals_present" in blockers:
        return "Quel non-objectif doit explicitement rester hors de cette première spec ?"
    if "decision_boundaries_present" in blockers:
        return "Quelle décision doit obligatoirement revenir à l'humain avant seed/run ?"
    if "success_criteria_testable" in blockers:
        return "Quelle preuve observable dira, sans opinion, que le résultat est réussi ?"
    if "ambiguity_floor_passed" in blockers:
        weakest = max(score.components, key=lambda key: score.components.get(key, 0.0))
        return f"Quelle réponse concrète ferme la dimension '{weakest}' ?"
    if "second_opinion_passed" in blockers:
        return "Quel test 48h réduit l'hypothèse la plus risquée ?"
    return "Confirmez-vous que cette spec est seed-ready ?"
