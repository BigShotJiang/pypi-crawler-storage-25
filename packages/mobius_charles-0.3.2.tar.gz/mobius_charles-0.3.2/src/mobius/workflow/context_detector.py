"""Détecteur de contexte workspace pour l'interview pré-remplie.

Scanne les manifests du workspace (pyproject.toml, package.json, Cargo.toml,
go.mod, etc.) et produit un WorkspaceContext structuré. Aucun appel réseau,
aucune IA — uniquement de la lecture de fichiers et du pattern matching.

Objectif : permettre à l'interview de pré-remplir les réponses évidentes
(type de projet, stack, brownfield/greenfield) sans poser de questions
inutiles à l'utilisateur.
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from pathlib import Path

# Répertoires sources qui signalent un projet brownfield
_SOURCE_DIRS = ("src", "lib", "app", "cmd", "pkg", "internal")

# Clés que le contexte workspace peut répondre automatiquement
_ANSWERABLE_KEYS = frozenset({"project_type", "template", "constraints", "context"})


@dataclass(frozen=True)
class WorkspaceContext:
    """Contexte détecté automatiquement depuis les manifests du workspace.

    Tous les champs sont en lecture seule (frozen=True) pour garantir
    l'immuabilité après construction.
    """

    stack: str = ""
    """Stack principal : 'python', 'node', 'rust', 'go' ou '' (inconnu)."""

    python_version: str = ""
    """Version Python minimale extraite de pyproject.toml (ex: '3.12')."""

    node_version: str = ""
    """Version Node minimale extraite de package.json engines (ex: '20.0.0')."""

    rust_edition: str = ""
    """Édition Rust extraite de Cargo.toml (ex: '2021')."""

    go_version: str = ""
    """Version Go extraite de go.mod (ex: '1.22')."""

    is_brownfield: bool = False
    """True si des répertoires sources ou des manifests sont présents."""

    detected_manifests: list[str] = field(default_factory=list)
    """Liste des noms de manifests détectés (ex: ['pyproject.toml'])."""

    has_tests: bool = False
    """True si un répertoire tests/ ou test/ est présent."""

    has_ci: bool = False
    """True si .github/ ou .gitlab-ci.yml est présent."""

    has_docker: bool = False
    """True si un Dockerfile ou docker-compose.yml est présent."""

    framework: str = ""
    """Framework détecté (ex: 'Next.js', 'React', 'Express')."""

    auth_method: str = ""
    """Méthode d'auth détectée (ex: 'NextAuth', 'Clerk', 'Django auth')."""

    testing_framework: str = ""
    """Framework de test détecté (ex: 'pytest', 'Vitest', 'cargo test')."""

    database: str = ""
    """Base de données ou ORM détecté (ex: 'Postgres', 'SQLite', 'Prisma')."""

    project_name: str = ""
    """Nom du projet extrait du manifest principal."""

    source_dirs: list[str] = field(default_factory=list)
    """Répertoires sources détectés (ex: ['src', 'lib'])."""

    @property
    def facts_count(self) -> int:
        """Nombre de faits non-vides détectés dans ce contexte.

        Compte uniquement les champs qui apportent de l'information :
        les chaînes non-vides et les booléens True.
        """
        count = 0
        if self.stack:
            count += 1
        if self.python_version:
            count += 1
        if self.node_version:
            count += 1
        if self.rust_edition:
            count += 1
        if self.go_version:
            count += 1
        if self.is_brownfield:
            count += 1
        if self.detected_manifests:
            count += 1
        if self.has_tests:
            count += 1
        if self.has_ci:
            count += 1
        if self.has_docker:
            count += 1
        if self.framework:
            count += 1
        if self.auth_method:
            count += 1
        if self.testing_framework:
            count += 1
        if self.database:
            count += 1
        if self.project_name:
            count += 1
        if self.source_dirs:
            count += 1
        return count

    def has_answer(self, key: str) -> bool:
        """Retourne True si le contexte peut répondre automatiquement à cette clé.

        Clés supportées : 'project_type', 'template', 'constraints', 'context'.
        Le workspace ne peut jamais répondre au 'goal' ni aux critères de succès.
        """
        if key not in _ANSWERABLE_KEYS:
            return False
        if key == "project_type":
            # On peut répondre si on a détecté des manifests ou des répertoires sources
            return bool(self.detected_manifests or self.source_dirs)
        if key == "template":
            return bool(self.stack)
        if key == "constraints":
            # On peut proposer des contraintes si des tests ou une CI sont détectés
            return self.has_tests or self.has_ci or bool(self.testing_framework)
        if key == "context":
            # On peut décrire le contexte si le projet est brownfield et a des manifests
            return self.is_brownfield and bool(self.detected_manifests)
        return False

    def get_answer(self, key: str) -> str:
        """Retourne la réponse auto-détectée pour la clé donnée.

        Retourne une chaîne vide si la clé n'est pas answerable.
        """
        if not self.has_answer(key):
            return ""
        if key == "project_type":
            return "brownfield" if self.is_brownfield else "greenfield"
        if key == "template":
            # Mapping stack → template Mobius
            _stack_to_template = {
                "python": "lib",
                "node": "web",
                "rust": "cli",
                "go": "cli",
            }
            return _stack_to_template.get(self.stack, "blank")
        if key == "constraints":
            # Construire les contraintes détectées depuis les signaux workspace
            parts: list[str] = []
            if self.has_tests:
                parts.append("Tests existants à préserver")
            elif self.testing_framework:
                parts.append(f"Framework de test détecté à préserver : {self.testing_framework}")
            if self.has_ci:
                parts.append("CI existante à ne pas casser")
            return "; ".join(parts)
        if key == "context":
            # Description du contexte brownfield basée sur les informations détectées
            parts_ctx: list[str] = []
            if self.stack:
                parts_ctx.append(f"Stack : {self.stack}")
            if self.framework:
                parts_ctx.append(f"Framework : {self.framework}")
            if self.auth_method:
                parts_ctx.append(f"Auth : {self.auth_method}")
            if self.testing_framework:
                parts_ctx.append(f"Tests : {self.testing_framework}")
            if self.database:
                parts_ctx.append(f"DB : {self.database}")
            if self.detected_manifests:
                parts_ctx.append(f"Manifests : {', '.join(self.detected_manifests)}")
            if self.project_name:
                parts_ctx.append(f"Projet : {self.project_name}")
            return ". ".join(parts_ctx) if parts_ctx else "Projet brownfield existant."
        return ""

    def confidence(self, key: str) -> float:
        """Niveau de confiance (0.0–1.0) pour la réponse à la clé donnée.

        Retourne 0.0 pour les clés inconnues ou sans réponse.
        """
        if not self.has_answer(key):
            return 0.0
        if key == "project_type":
            # Confiance haute si manifest + répertoire source, moyenne si seulement manifest
            if self.detected_manifests and self.source_dirs:
                return 0.95
            if self.detected_manifests:
                return 0.80
            if self.source_dirs:
                return 0.70
            return 0.0
        if key == "template":
            return 0.85 if self.stack else 0.0
        if key == "constraints":
            return 0.55
        if key == "context":
            return 0.60
        return 0.0


# ---------------------------------------------------------------------------
# Fonction principale de scan
# ---------------------------------------------------------------------------


def scan_workspace_context(workspace: Path) -> WorkspaceContext:
    """Scanne un workspace et retourne le contexte détecté.

    Lit les manifests présents et détecte le stack, la version, le framework,
    les répertoires sources, la présence de tests, de CI et de Docker.
    Ne fait aucun appel réseau.
    """
    try:
        workspace = workspace.expanduser().resolve()
    except OSError:
        return WorkspaceContext()
    if not workspace.exists():
        return WorkspaceContext()

    manifests: list[str] = []
    stack = ""
    python_version = ""
    node_version = ""
    rust_edition = ""
    go_version = ""
    framework = ""
    auth_method = ""
    testing_framework = ""
    database = ""
    project_name = ""

    # --- Scan pyproject.toml ---
    pyproject = workspace / "pyproject.toml"
    if pyproject.exists():
        manifests.append("pyproject.toml")
        stack = "python"
        name, py_ver, py_framework, py_auth, py_test, py_db = _parse_pyproject(pyproject)
        project_name = name
        python_version = py_ver
        framework = py_framework
        auth_method = py_auth
        testing_framework = py_test
        database = py_db

    # --- Scan package.json ---
    pkg_json = workspace / "package.json"
    if pkg_json.exists():
        manifests.append("package.json")
        if not stack:
            stack = "node"
        pkg_name, node_ver, detected_fw, detected_auth, detected_test, detected_db = (
            _parse_package_json(pkg_json)
        )
        if not project_name:
            project_name = pkg_name
        node_version = node_ver
        framework = framework or detected_fw
        auth_method = auth_method or detected_auth
        testing_framework = testing_framework or detected_test
        database = database or detected_db

    # --- Scan Cargo.toml ---
    cargo = workspace / "Cargo.toml"
    if cargo.exists():
        manifests.append("Cargo.toml")
        if not stack:
            stack = "rust"
        edition = _parse_cargo_toml(cargo)
        rust_edition = edition
        testing_framework = testing_framework or "cargo test"

    # --- Scan go.mod ---
    go_mod = workspace / "go.mod"
    if go_mod.exists():
        manifests.append("go.mod")
        if not stack:
            stack = "go"
        go_ver = _parse_go_mod(go_mod)
        go_version = go_ver
        testing_framework = testing_framework or "go test"

    # --- Répertoires sources ---
    source_dirs = [d for d in _SOURCE_DIRS if (workspace / d).is_dir()]

    # --- Brownfield : manifests OU répertoires sources ---
    is_brownfield = bool(manifests or source_dirs)

    # --- Tests ---
    has_tests = (workspace / "tests").is_dir() or (workspace / "test").is_dir()

    # --- CI ---
    has_ci = (workspace / ".github").is_dir() or (workspace / ".gitlab-ci.yml").exists()

    # --- Docker ---
    has_docker = (
        (workspace / "Dockerfile").exists()
        or (workspace / "docker-compose.yml").exists()
        or (workspace / "docker-compose.yaml").exists()
    )

    return WorkspaceContext(
        stack=stack,
        python_version=python_version,
        node_version=node_version,
        rust_edition=rust_edition,
        go_version=go_version,
        is_brownfield=is_brownfield,
        detected_manifests=manifests,
        has_tests=has_tests,
        has_ci=has_ci,
        has_docker=has_docker,
        framework=framework,
        auth_method=auth_method,
        testing_framework=testing_framework,
        database=database,
        project_name=project_name,
        source_dirs=source_dirs,
    )


# ---------------------------------------------------------------------------
# Formattage des faits détectés
# ---------------------------------------------------------------------------


def format_detected_facts(ctx: WorkspaceContext) -> list[str]:
    """Formate les faits détectés en lignes lisibles pour l'interface.

    Retourne une liste vide si aucun fait n'a été détecté.
    Chaque ligne décrit un fait découvert (manifest, répertoire, outil).
    """
    lines: list[str] = []

    # Manifests avec détails
    for manifest in ctx.detected_manifests:
        detail = _manifest_detail(manifest, ctx)
        if detail:
            lines.append(f"Détecté : {manifest} → {detail}")
        else:
            lines.append(f"Détecté : {manifest}")

    # Répertoires sources (brownfield)
    if ctx.source_dirs:
        dirs_str = ", ".join(ctx.source_dirs)
        lines.append(f"Répertoires sources : {dirs_str}/ (projet brownfield)")

    # Tests
    if ctx.has_tests:
        if ctx.testing_framework:
            lines.append(f"Tests : {ctx.testing_framework}")
        else:
            lines.append("Tests : répertoire tests/ présent")
    elif ctx.testing_framework:
        lines.append(f"Tests : {ctx.testing_framework}")

    # CI
    if ctx.has_ci:
        lines.append("CI : GitHub Actions / GitLab CI détecté")

    # Docker
    if ctx.has_docker:
        lines.append("Docker : Dockerfile ou docker-compose.yml présent")

    if ctx.auth_method:
        lines.append(f"Auth : {ctx.auth_method}")

    if ctx.database:
        lines.append(f"DB : {ctx.database}")

    return lines


# ---------------------------------------------------------------------------
# Parsers privés
# ---------------------------------------------------------------------------


def _parse_pyproject(path: Path) -> tuple[str, str, str, str, str, str]:
    """Extrait les signaux principaux depuis pyproject.toml.

    Retourne des chaînes vides si la valeur n'est pas trouvée.
    Parsing minimal basé sur regex — pas de dépendance à tomllib/tomli.
    """
    text = _safe_read(path)
    if not text:
        return "", "", "", "", "", ""

    name = ""
    py_version = ""

    # Cherche name = "..." dans la section [project]
    name_match = re.search(r'^\s*name\s*=\s*["\']([^"\']+)["\']', text, re.MULTILINE)
    if name_match:
        name = name_match.group(1)

    # Cherche requires-python = ">=3.12" ou "~=3.11" etc.
    py_match = re.search(r'requires-python\s*=\s*["\'][^"\']*?(\d+\.\d+)', text)
    if py_match:
        py_version = py_match.group(1)

    lowered = text.lower()
    framework = ""
    if "django" in lowered:
        framework = "Django"
    elif "fastapi" in lowered:
        framework = "FastAPI"
    elif "flask" in lowered:
        framework = "Flask"

    auth_method = "Django auth" if "django" in lowered else ""

    testing_framework = ""
    if "pytest" in lowered:
        testing_framework = "pytest"
    elif "unittest" in lowered:
        testing_framework = "unittest"

    database = _detect_database_from_names(_dependency_names_from_text(text))

    return name, py_version, framework, auth_method, testing_framework, database


def _parse_package_json(path: Path) -> tuple[str, str, str, str, str, str]:
    """Extrait les signaux principaux depuis package.json.

    Retourne des chaînes vides pour les valeurs manquantes.
    """
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError, UnicodeDecodeError):
        return "", "", "", "", "", ""

    project_name = data.get("name", "") if isinstance(data.get("name"), str) else ""

    # Version Node depuis engines.node
    node_version = ""
    engines = data.get("engines", {})
    if isinstance(engines, dict):
        raw_node = engines.get("node", "")
        if isinstance(raw_node, str):
            # Extrait le premier numéro de version (ex: ">=20.0.0" → "20.0.0")
            node_match = re.search(r"(\d+\.\d+\.\d+|\d+\.\d+|\d+)", raw_node)
            if node_match:
                node_version = node_match.group(1)

    # Toutes les dépendances (prod + dev)
    all_deps: dict[str, object] = {}
    for key in ("dependencies", "devDependencies"):
        raw = data.get(key, {})
        if isinstance(raw, dict):
            all_deps.update(raw)

    # Détection du framework
    framework = ""
    if "next" in all_deps:
        framework = "Next.js"
    elif "react" in all_deps:
        framework = "React"
    elif "vue" in all_deps:
        framework = "Vue"
    elif "svelte" in all_deps:
        framework = "Svelte"
    elif "@angular/core" in all_deps:
        framework = "Angular"
    elif "express" in all_deps:
        framework = "Express"
    elif "fastify" in all_deps:
        framework = "Fastify"

    dep_names = {str(name).lower() for name in all_deps}
    auth_method = _detect_auth_method(dep_names)
    testing_framework = _detect_testing_framework(dep_names)
    database = _detect_database_from_names(dep_names)

    return project_name, node_version, framework, auth_method, testing_framework, database


def _dependency_names_from_text(text: str) -> set[str]:
    return {match.group(1).lower() for match in re.finditer(r'["\']?([A-Za-z0-9_.@/-]+)', text)}


def _detect_auth_method(dep_names: set[str]) -> str:
    if "next-auth" in dep_names or "@auth/core" in dep_names:
        return "NextAuth"
    if "@clerk/nextjs" in dep_names or "@clerk/clerk-react" in dep_names:
        return "Clerk"
    if "@auth0/nextjs-auth0" in dep_names or "auth0" in dep_names:
        return "Auth0"
    if "@supabase/supabase-js" in dep_names:
        return "Supabase auth"
    return ""


def _detect_testing_framework(dep_names: set[str]) -> str:
    if "vitest" in dep_names:
        return "Vitest"
    if "jest" in dep_names:
        return "Jest"
    if "@playwright/test" in dep_names or "playwright" in dep_names:
        return "Playwright"
    if "pytest" in dep_names:
        return "pytest"
    return ""


def _detect_database_from_names(dep_names: set[str]) -> str:
    if "prisma" in dep_names or "@prisma/client" in dep_names:
        return "Prisma"
    if "pg" in dep_names or "psycopg" in dep_names or "psycopg2" in dep_names:
        return "Postgres"
    if "sqlite3" in dep_names or "better-sqlite3" in dep_names or "aiosqlite" in dep_names:
        return "SQLite"
    if "mongodb" in dep_names or "mongoose" in dep_names or "pymongo" in dep_names:
        return "MongoDB"
    if "@supabase/supabase-js" in dep_names:
        return "Supabase"
    if "sqlalchemy" in dep_names:
        return "SQLAlchemy"
    return ""


def _parse_cargo_toml(path: Path) -> str:
    """Extrait l'édition Rust depuis Cargo.toml.

    Retourne une chaîne vide si non trouvée.
    """
    text = _safe_read(path)
    if not text:
        return ""

    edition_match = re.search(r'^\s*edition\s*=\s*["\'](\d+)["\']', text, re.MULTILINE)
    if edition_match:
        return edition_match.group(1)
    return ""


def _parse_go_mod(path: Path) -> str:
    """Extrait la version Go depuis go.mod.

    Retourne une chaîne vide si non trouvée.
    """
    text = _safe_read(path)
    if not text:
        return ""

    go_match = re.search(r"^go\s+(\d+\.\d+(?:\.\d+)?)", text, re.MULTILINE)
    if go_match:
        return go_match.group(1)
    return ""


def _manifest_detail(manifest: str, ctx: WorkspaceContext) -> str:
    """Produit une description courte pour un manifest donné."""
    if manifest == "pyproject.toml":
        parts = ["Python"]
        if ctx.python_version:
            parts.append(ctx.python_version)
        if ctx.project_name:
            parts.append(f"({ctx.project_name})")
        return " ".join(parts)
    if manifest == "package.json":
        parts = ["Node.js"]
        if ctx.framework:
            parts.append(f"/ {ctx.framework}")
        if ctx.node_version:
            parts.append(f"(node {ctx.node_version})")
        if ctx.project_name:
            parts.append(f"({ctx.project_name})")
        return " ".join(parts)
    if manifest == "Cargo.toml":
        parts = ["Rust"]
        if ctx.rust_edition:
            parts.append(f"edition {ctx.rust_edition}")
        return " ".join(parts)
    if manifest == "go.mod":
        parts = ["Go"]
        if ctx.go_version:
            parts.append(ctx.go_version)
        return " ".join(parts)
    return ""


def _safe_read(path: Path) -> str:
    """Lit un fichier texte en ignorant les erreurs d'encodage ou d'accès."""
    try:
        return path.read_text(encoding="utf-8")
    except (OSError, UnicodeDecodeError):
        return ""
