"""Logique de suggestion de persona basée sur l'état de l'event store.

Analyse les événements d'un run ou d'une évolution pour recommander
la persona de pensée latérale la plus pertinente.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass

from mobius.persistence.event_store import EventRecord, EventStore

logger = logging.getLogger(__name__)

STAGNATION_WINDOW = 3


@dataclass(frozen=True, slots=True)
class Suggestion:
    """Recommandation de persona avec justification."""

    persona: str
    reason: str
    confidence: float


def suggest_persona(store: EventStore, run_id: str) -> Suggestion:
    """Analyser l'event store et recommander une persona.

    Stratégie de détection (par priorité décroissante) :

    1. Oscillation période-2 dans evolve → contrarian
    2. Feedback répétitif dans evolve → architect
    3. Majorité de critères échoués → simplifier
    4. Pas de contexte brownfield → researcher
    5. Beaucoup de générations sans progrès → hacker
    6. Défaut → contrarian
    """
    events = store.read_events(run_id)
    if not events:
        return Suggestion("contrarian", "aucun événement trouvé — challenge les hypothèses", 0.3)

    oscillation = _detect_oscillation(events)
    if oscillation:
        return Suggestion(
            "contrarian",
            "oscillation période-2 détectée — les mêmes solutions alternent sans progrès",
            0.9,
        )

    repetitive = _detect_repetitive_feedback(events)
    if repetitive:
        return Suggestion(
            "architect",
            "feedback répétitif détecté — le problème est probablement structurel",
            0.85,
        )

    failure_ratio = _compute_failure_ratio(events)
    if failure_ratio is not None and failure_ratio > 0.7:
        return Suggestion(
            "simplifier",
            f"{failure_ratio:.0%} des critères échouent — réduis le scope au minimum",
            0.8,
        )

    missing_context = _detect_missing_context(events)
    if missing_context:
        return Suggestion(
            "researcher",
            "pas de contexte brownfield — investigue avant de coder",
            0.75,
        )

    stagnation = _detect_stagnation(events)
    if stagnation:
        return Suggestion(
            "hacker",
            "plusieurs générations sans progrès — contourne l'obstacle",
            0.7,
        )

    return Suggestion("contrarian", "situation incertaine — challenge les hypothèses", 0.4)


def _detect_oscillation(events: list[EventRecord]) -> bool:
    """Détecter un pattern d'oscillation dans les événements d'évolution."""
    gen_events = [e for e in events if e.type == "evolution.generation"]
    for event in gen_events:
        payload = event.payload_data
        if isinstance(payload, dict) and payload.get("period_two_oscillation") is True:
            return True
    return False


def _detect_repetitive_feedback(events: list[EventRecord]) -> bool:
    """Détecter du feedback répétitif dans les événements d'évolution."""
    gen_events = [e for e in events if e.type == "evolution.generation"]
    for event in gen_events:
        payload = event.payload_data
        if isinstance(payload, dict) and payload.get("repetitive_feedback") is True:
            return True
    return False


def _compute_failure_ratio(events: list[EventRecord]) -> float | None:
    """Calculer le ratio critères échoués / total depuis le dernier qa.completed."""
    for event in reversed(events):
        if event.type != "qa.completed":
            continue
        payload = event.payload_data
        if not isinstance(payload, dict):
            return None
        results = payload.get("results")
        if not isinstance(results, list) or not results:
            return None
        total = len(results)
        failed = sum(1 for r in results if isinstance(r, dict) and r.get("verdict") != "pass")
        return failed / total if total > 0 else None
    return None


def _detect_missing_context(events: list[EventRecord]) -> bool:
    """Vérifier si le run manque de contexte brownfield via les événements interview."""
    has_brownfield = False
    has_context = False
    for event in events:
        if event.type == "run.started":
            payload = event.payload_data
            if isinstance(payload, dict):
                project_type = payload.get("project_type", "")
                if isinstance(project_type, str) and project_type == "brownfield":
                    has_brownfield = True
                context = payload.get("context", "")
                if isinstance(context, str) and context.strip():
                    has_context = True
        if event.type == "interview.question_answered":
            payload = event.payload_data
            if isinstance(payload, dict):
                category = payload.get("category", "")
                if category == "context":
                    answer = payload.get("answer", "")
                    if isinstance(answer, str) and answer.strip():
                        has_context = True
                if category == "project_type":
                    answer = payload.get("answer", "")
                    if isinstance(answer, str) and answer == "brownfield":
                        has_brownfield = True
    return has_brownfield and not has_context


def _detect_stagnation(events: list[EventRecord]) -> bool:
    """Détecter une stagnation : 3+ générations avec le même nombre d'échecs."""
    gen_events = [e for e in events if e.type == "evolution.generation"]
    if len(gen_events) < STAGNATION_WINDOW:
        logger.warning(
            "Stagnation: seulement %d/%d générations disponibles "
            "— détection de stagnation dégradée",
            len(gen_events),
            STAGNATION_WINDOW,
        )
        return False

    recent = gen_events[-3:]
    fail_counts: list[int] = []
    for event in recent:
        payload = event.payload_data
        if isinstance(payload, dict):
            candidate = payload.get("candidate", {})
            if isinstance(candidate, dict):
                inner = candidate.get("payload", {})
                if isinstance(inner, dict):
                    fail_counts.append(int(inner.get("failed", -1)))

    return len(fail_counts) == 3 and len(set(fail_counts)) == 1 and fail_counts[0] > 0
