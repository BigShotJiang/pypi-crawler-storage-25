"""Canonical YAML scalar/list rendering shared by every Mobius spec writer.

The escape rules are the *union* of every variant historically embedded in
``templates``, ``interview``, ``workflow/interview_v3a/runner``, and
``v3a/maturity/scorer``.  Quoting rules:

- Empty strings render as ``""``.
- ``bool`` / ``int`` / ``float`` round-trip to their natural YAML form.
- Strings containing any of ``:#[]{}&*!|>'"%@`\\`` are quoted and escaped.
- Strings with leading/trailing whitespace or embedded newlines are quoted.
"""

from __future__ import annotations

from collections.abc import Iterable

_SPECIAL_CHARS = frozenset(":#[]{}&*!|>'\"%@`")


def yaml_scalar(value: object) -> str:
    """Return the canonical YAML representation of any spec scalar value."""
    if isinstance(value, bool):
        return "true" if value else "false"
    if isinstance(value, int | float):
        return str(value)
    text = str(value) if value is not None else ""
    if text == "":
        return '""'
    needs_quotes = (
        any(character in _SPECIAL_CHARS for character in text)
        or text != text.strip()
        or "\n" in text
    )
    if needs_quotes:
        escaped = (
            text.replace("\\", "\\\\").replace('"', '\\"').replace("\n", "\\n").replace("\r", "\\r")
        )
        return f'"{escaped}"'
    return text


def yaml_unescape(value: str) -> str:
    """Unescape a double-quoted YAML scalar value after outer quotes are stripped."""
    result: list[str] = []
    i = 0
    while i < len(value):
        if value[i] == "\\" and i + 1 < len(value):
            nxt = value[i + 1]
            if nxt == '"':
                result.append('"')
            elif nxt == "\\":
                result.append("\\")
            elif nxt == "n":
                result.append("\n")
            elif nxt == "r":
                result.append("\r")
            elif nxt == "t":
                result.append("\t")
            else:
                result.append(value[i])
                result.append(nxt)
            i += 2
        else:
            result.append(value[i])
            i += 1
    return "".join(result)


def yaml_list(values: Iterable[str]) -> list[str]:
    """Return the canonical YAML two-space-indented list lines for ``values``."""
    rendered = [f"  - {yaml_scalar(value)}" for value in values]
    if not rendered:
        return ["  []"]
    return rendered
