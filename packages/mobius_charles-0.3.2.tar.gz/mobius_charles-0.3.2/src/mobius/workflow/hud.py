"""Projection-backed HUD summaries for Mobius."""

from __future__ import annotations

import time
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path
from typing import TYPE_CHECKING, Any

from pydantic import BaseModel, ConfigDict

from mobius.persistence.event_store import EventStore
from mobius.persistence.projections import load_projection_snapshot

if TYPE_CHECKING:
    from rich.console import RenderableType


class HudCritère(BaseModel):
    """One criterion row displayed by ``mobius hud``."""

    model_config = ConfigDict(extra="forbid")

    id: str
    label: str
    verdict: str
    commands: list[str]


class HudSpec(BaseModel):
    """Current spec metadata from the projection cache."""

    model_config = ConfigDict(extra="forbid")

    goal: str
    owner: str
    grade: str


class HudRun(BaseModel):
    """Latest run metadata from the projection cache."""

    model_config = ConfigDict(extra="forbid")

    id: str
    title: str
    status: str
    duration: str


class HudSummary(BaseModel):
    """Full HUD payload derived from one projection snapshot."""

    model_config = ConfigDict(extra="forbid")

    spec: HudSpec
    latest_run: HudRun
    criteria: list[HudCritère]
    next_recommended_command: str | None
    proofs_collected: int
    last_qa_timestamp: str
    stale: bool


@dataclass(frozen=True)
class HudLoadResult:
    """HUD payload with the raw projection snapshot used to build it."""

    summary: HudSummary
    projection_snapshot: dict[str, Any]


def load_hud(event_store_path: Path) -> HudLoadResult:
    """Load the HUD strictly from the projection cache, never replaying events."""
    if not event_store_path.exists():
        snapshot: dict[str, Any] = {}
    else:
        with EventStore(event_store_path, read_only=True) as store:
            snapshot = load_projection_snapshot(store.connection)
    return HudLoadResult(
        summary=build_hud_summary(snapshot),
        projection_snapshot=snapshot,
    )


def build_hud_summary(snapshot: dict[str, Any]) -> HudSummary:
    """Build a typed HUD payload from a projection snapshot."""
    spec = _dict(snapshot.get("current_spec"))
    grade = _dict(snapshot.get("last_grade"))
    latest_run = _dict(snapshot.get("latest_run"))
    criteria = _criteria(snapshot)
    # Fall back to the latest run's title when no current_spec.goal is recorded
    # in the projection cache (e.g., right after the first run, before grade
    # has been emitted). Titles are produced by ``_title_from_goal`` which
    # truncates to 60 characters; a value at the truncation boundary may be
    # incomplete, so only use it as the goal fallback when we are certain it
    # is not truncated. This avoids showing a clipped string under "Goal:".
    title_text = _text(latest_run.get("title"), "")
    goal_default = title_text if 0 < len(title_text) <= 60 else "(unknown)"
    return HudSummary(
        spec=HudSpec(
            goal=_text(spec.get("goal"), goal_default),
            owner=_owner_text(spec.get("owner")),
            grade=_text(grade.get("grade"), "ungraded"),
        ),
        latest_run=HudRun(
            id=_text(latest_run.get("id"), "(none)"),
            title=_text(latest_run.get("title"), "(none)"),
            status=_text(latest_run.get("status"), "unknown"),
            duration=_duration(latest_run),
        ),
        criteria=criteria,
        next_recommended_command=_next_command(criteria),
        proofs_collected=_int(snapshot.get("proofs_collected")),
        last_qa_timestamp=_text(snapshot.get("last_qa_timestamp"), "(none)"),
        stale=bool(snapshot.get("stale", False)),
    )


def _criteria(snapshot: dict[str, Any]) -> list[HudCritère]:
    raw = snapshot.get("criteria")
    if isinstance(raw, list):
        rows: list[HudCritère] = []
        for index, item in enumerate(raw, start=1):
            if not isinstance(item, dict):
                continue
            commands_raw = item.get("commands")
            commands = (
                [str(command) for command in commands_raw] if isinstance(commands_raw, list) else []
            )
            rows.append(
                HudCritère(
                    id=_text(item.get("id"), f"C{index}"),
                    label=_text(item.get("label"), _text(item.get("id"), f"Critère {index}")),
                    verdict=_text(item.get("verdict"), "unverified").lower(),
                    commands=commands,
                )
            )
        if rows:
            return rows

    summary = _dict(snapshot.get("criteria_summary"))
    by_criterion = _dict(summary.get("by_criterion"))
    return [
        HudCritère(id=str(key), label=str(key), verdict=str(value).lower(), commands=[])
        for key, value in sorted(by_criterion.items())
    ]


def _next_command(criteria: list[HudCritère]) -> str | None:
    for criterion in criteria:
        if criterion.verdict.lower() == "unverified" and criterion.commands:
            return criterion.commands[0]
    return None


def _duration(latest_run: dict[str, Any]) -> str:
    started_at = _text(latest_run.get("started_at"), "")
    ended_at = _text(latest_run.get("ended_at"), "") or _text(latest_run.get("last_event_at"), "")
    if not started_at:
        return "unknown"
    if not ended_at:
        return "running"
    started = _parse_utc(started_at)
    ended = _parse_utc(ended_at)
    if started is None or ended is None:
        return "unknown"
    seconds = max(0.0, (ended - started).total_seconds())
    if seconds < 1:
        return f"{seconds:.1f}s"
    if seconds < 60:
        return f"{seconds:.0f}s"
    minutes, remaining = divmod(int(seconds), 60)
    if minutes < 60:
        return f"{minutes}m {remaining}s"
    hours, minutes = divmod(minutes, 60)
    return f"{hours}h {minutes}m"


def _parse_utc(value: str) -> datetime | None:
    try:
        return datetime.fromisoformat(value.replace("Z", "+00:00")).astimezone(UTC)
    except ValueError:
        return None


def _dict(value: object) -> dict[str, Any]:
    return dict(value) if isinstance(value, dict) else {}


def _text(value: object, default: str) -> str:
    if value is None:
        return default
    text = str(value).strip()
    return text or default


def _owner_text(value: object) -> str:
    if isinstance(value, list):
        text = ", ".join(str(item).strip() for item in value if str(item).strip())
        return text or "(none)"
    return _text(value, "(none)")


def _int(value: object) -> int:
    if isinstance(value, int):
        return value
    try:
        return int(str(value))
    except (TypeError, ValueError):
        return 0


# ---------------------------------------------------------------------------
# Fonctions Rich Live HUD
# ---------------------------------------------------------------------------

_VERDICT_COULEUR: dict[str, str] = {
    "pass": "green",
    "fail": "red",
    "unverified": "yellow",
}


def build_hud_layout(summary: HudSummary) -> RenderableType:
    """Construire le layout Rich pour le HUD sans démarrer la boucle Live.

    Cette fonction est testable indépendamment de ``render_live_hud``.
    """
    from rich.layout import Layout
    from rich.panel import Panel
    from rich.table import Table
    from rich.text import Text

    # --- Panneau Spec (haut-gauche) ---
    spec_text = Text()
    spec_text.append("Goal:  ", style="bold")
    spec_text.append(summary.spec.goal + "\n")
    spec_text.append("Owner: ", style="bold")
    spec_text.append(summary.spec.owner + "\n")
    spec_text.append("Grade: ", style="bold")
    spec_text.append(summary.spec.grade)
    spec_panel = Panel(spec_text, title="📋 Spec")

    # --- Tableau Critères (droite) ---
    criteres_table = Table(show_header=True, header_style="bold")
    criteres_table.add_column("ID", style="dim", no_wrap=True)
    criteres_table.add_column("Label")
    criteres_table.add_column("Verdict")
    for critere in summary.criteria:
        couleur = _VERDICT_COULEUR.get(critere.verdict.lower(), "yellow")
        criteres_table.add_row(
            critere.id,
            critere.label,
            Text(critere.verdict, style=couleur),
        )
    if not summary.criteria:
        criteres_table.add_row("—", "Aucun critère", Text("unverified", style="yellow"))
    criteres_panel = Panel(criteres_table, title="✅ Critères")

    # --- Tableau Événements (bas) - les 10 derniers du run courant ---
    events_table = Table(show_header=True, header_style="bold", expand=True)
    events_table.add_column("Run", style="dim", no_wrap=True)
    events_table.add_column("Statut")
    events_table.add_column("Durée")
    events_table.add_column("Preuves")
    events_table.add_row(
        summary.latest_run.id,
        summary.latest_run.status,
        summary.latest_run.duration,
        str(summary.proofs_collected),
    )
    events_panel = Panel(events_table, title="📡 Événements")

    # --- Assemblage du layout ---
    layout = Layout()
    layout.split_column(
        Layout(name="top", ratio=2),
        Layout(name="bottom", ratio=1),
    )
    layout["top"].split_row(
        Layout(spec_panel, name="spec"),
        Layout(criteres_panel, name="criteria"),
    )
    layout["bottom"].update(events_panel)
    return layout


def _poll_once(live: Any, event_store_path: Path) -> None:
    """Charger la projection et mettre à jour le Live panel."""
    result = load_hud(event_store_path)
    renderable = build_hud_layout(result.summary)
    live.update(renderable)


def render_live_hud(event_store_path: Path, poll_interval: float = 1.0) -> None:
    """Afficher le HUD en temps réel avec Rich Live panels.

    Recharge la projection toutes les ``poll_interval`` secondes.
    S'arrête sur KeyboardInterrupt (Ctrl+C).
    """
    from rich.live import Live

    with Live(refresh_per_second=4) as live:
        try:
            while True:
                _poll_once(live, event_store_path)
                time.sleep(poll_interval)
        except KeyboardInterrupt:
            pass
