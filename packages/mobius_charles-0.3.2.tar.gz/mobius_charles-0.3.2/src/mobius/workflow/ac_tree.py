"""Acceptance-criteria tree projection for completed and running Mobius runs."""

from __future__ import annotations

from pathlib import Path
from typing import Any

from pydantic import BaseModel, ConfigDict

from mobius.persistence.event_store import EventRecord, EventStore
from mobius.workflow.seed import SeedSpec, SeedSpecValidationError, load_seed_spec
from mobius.workflow.session_facts import (
    SessionFacts,
    read_session_facts,
    spec_path_from_session,
)


class ACTreeNode(BaseModel):
    """One display node in the compact AC tree."""

    model_config = ConfigDict(extra="forbid")

    id: str
    label: str
    type: str
    state: str | None = None
    sequence: int | None = None


class ACTreeEdge(BaseModel):
    """A directed relationship between AC tree nodes."""

    model_config = ConfigDict(extra="forbid")

    source: str
    target: str
    relation: str


class ACTreeOutput(BaseModel):
    """Structured AC tree output."""

    model_config = ConfigDict(extra="forbid")

    run_id: str
    state: str
    cursor: int
    truncated: bool
    omitted_nodes: int
    nodes: list[ACTreeNode]
    edges: list[ACTreeEdge]


def build_ac_tree(
    event_store_path: Path,
    run_id: str,
    *,
    cursor: int = 0,
    max_nodes: int = 50,
) -> ACTreeOutput | None:
    """Build a compact AC tree projection for ``run_id``.

    ``cursor`` is an event sequence cursor. The stable AC/spec context remains
    visible while event delta nodes are restricted to events with a greater
    sequence, allowing callers to poll efficiently for tree updates.
    """
    bounded_cursor = max(cursor, 0)
    bounded_max_nodes = max(max_nodes, 5)
    with EventStore(event_store_path) as store:
        session = read_session_facts(store, run_id)
        if session is None:
            return None
        events = store.read_events(run_id)

    state = session.status
    spec = _load_spec(session)
    latest_cursor = max((event.sequence for event in events), default=0)
    nodes, edges = _build_nodes_and_edges(
        run_id=run_id,
        state=state,
        metadata=session.metadata,
        spec=spec,
        events=[event for event in events if event.sequence > bounded_cursor],
    )
    nodes, edges, omitted_nodes = _truncate(nodes, edges, max_nodes=bounded_max_nodes)
    return ACTreeOutput(
        run_id=run_id,
        state=state,
        cursor=latest_cursor,
        truncated=omitted_nodes > 0,
        omitted_nodes=omitted_nodes,
        nodes=nodes,
        edges=edges,
    )


def _build_nodes_and_edges(
    *,
    run_id: str,
    state: str,
    metadata: dict[str, Any],
    spec: SeedSpec | None,
    events: list[EventRecord],
) -> tuple[list[ACTreeNode], list[ACTreeEdge]]:
    nodes = [
        ACTreeNode(id=run_id, label=f"Run {run_id}", type="run", state=state),
    ]
    edges: list[ACTreeEdge] = []

    goal = spec.goal if spec is not None else _goal_from_events(events)
    if goal:
        goal_id = f"{run_id}:goal"
        nodes.append(ACTreeNode(id=goal_id, label=f"Goal: {goal}", type="goal", state=state))
        edges.append(ACTreeEdge(source=run_id, target=goal_id, relation="has_goal"))

    constraints = spec.constraints if spec is not None else []
    if constraints:
        _append_group(
            nodes,
            edges,
            root_id=run_id,
            group_id=f"{run_id}:constraints",
            group_label="Constraints",
            group_type="constraint_group",
            child_type="constraint",
            relation="constrains",
            child_labels=constraints,
            child_state="active",
        )

    success_criteria = spec.success_criteria if spec is not None else []
    if success_criteria:
        qa_states = _criterion_states_from_qa(events)
        tree = spec.criteria_tree if spec is not None else []
        _append_acceptance_group(
            nodes,
            edges,
            root_id=run_id,
            group_id=f"{run_id}:acceptance",
            group_label="Acceptance Criteria",
            child_labels=success_criteria,
            fallback_state=_criterion_state(state),
            criterion_states=qa_states,
            criteria_tree=tree if tree else None,
        )

    if events:
        deltas_id = f"{run_id}:deltas"
        nodes.append(ACTreeNode(id=deltas_id, label="Event Deltas", type="event_group"))
        edges.append(ACTreeEdge(source=run_id, target=deltas_id, relation="has_delta"))
        for event in events:
            event_id = f"{run_id}:event:{event.sequence}"
            nodes.append(
                ACTreeNode(
                    id=event_id,
                    label=_format_event_label(event),
                    type="event",
                    sequence=event.sequence,
                )
            )
            edges.append(ACTreeEdge(source=deltas_id, target=event_id, relation="emitted"))

    if spec is None and not events and metadata:
        metadata_id = f"{run_id}:metadata"
        nodes.append(ACTreeNode(id=metadata_id, label="Métadonnées disponibles", type="metadata"))
        edges.append(ACTreeEdge(source=run_id, target=metadata_id, relation="has_metadata"))

    return nodes, edges


def _append_group(
    nodes: list[ACTreeNode],
    edges: list[ACTreeEdge],
    *,
    root_id: str,
    group_id: str,
    group_label: str,
    group_type: str,
    child_type: str,
    relation: str,
    child_labels: list[str],
    child_state: str,
) -> None:
    nodes.append(ACTreeNode(id=group_id, label=group_label, type=group_type))
    edges.append(ACTreeEdge(source=root_id, target=group_id, relation=relation))
    for index, label in enumerate(child_labels, start=1):
        child_id = f"{group_id}:{index}"
        nodes.append(ACTreeNode(id=child_id, label=label, type=child_type, state=child_state))
        edges.append(ACTreeEdge(source=group_id, target=child_id, relation="contains"))


def _append_acceptance_group(
    nodes: list[ACTreeNode],
    edges: list[ACTreeEdge],
    *,
    root_id: str,
    group_id: str,
    group_label: str,
    child_labels: list[str],
    fallback_state: str,
    criterion_states: dict[int, str],
    criteria_tree: list[dict[str, Any]] | None = None,
) -> None:
    nodes.append(ACTreeNode(id=group_id, label=group_label, type="acceptance_group"))
    edges.append(ACTreeEdge(source=root_id, target=group_id, relation="accepts"))
    tree = criteria_tree or []
    for index, label in enumerate(child_labels, start=1):
        child_id = f"{group_id}:{index}"
        nodes.append(
            ACTreeNode(
                id=child_id,
                label=label,
                type="acceptance_criterion",
                state=criterion_states.get(index, fallback_state),
            )
        )
        edges.append(ACTreeEdge(source=group_id, target=child_id, relation="contains"))
        if index <= len(tree):
            tree_node = tree[index - 1]
            children = tree_node.get("children", [])
            if isinstance(children, list):
                for sub_index, sub_label in enumerate(children, start=1):
                    sub_id = f"{child_id}:sub:{sub_index}"
                    nodes.append(
                        ACTreeNode(
                            id=sub_id,
                            label=str(sub_label),
                            type="acceptance_sub_criterion",
                            state=fallback_state,
                        )
                    )
                    edges.append(ACTreeEdge(source=child_id, target=sub_id, relation="contains"))


def _criterion_states_from_qa(events: list[EventRecord]) -> dict[int, str]:
    for event in reversed(events):
        if event.type not in {"qa.completed", "qa.report"}:
            continue
        results = event.payload_data.get("results")
        if not isinstance(results, list):
            continue
        states: dict[int, str] = {}
        for result in results:
            if not isinstance(result, dict):
                continue
            raw_id = result.get("id")
            verdict = result.get("verdict")
            if not isinstance(raw_id, str) or not raw_id.startswith("criterion_"):
                continue
            try:
                index = int(raw_id.removeprefix("criterion_"))
            except ValueError:
                continue
            states[index] = _qa_verdict_state(verdict)
        if states:
            return states
    return {}


def _qa_verdict_state(verdict: object) -> str:
    return {
        "pass": "verified",
        "fail": "failed",
        "unverified": "unverified",
    }.get(str(verdict), "unknown")


def _truncate(
    nodes: list[ACTreeNode],
    edges: list[ACTreeEdge],
    *,
    max_nodes: int,
) -> tuple[list[ACTreeNode], list[ACTreeEdge], int]:
    if len(nodes) <= max_nodes:
        return nodes, edges, 0

    kept_count = max_nodes - 1
    omitted_nodes = len(nodes) - kept_count
    kept_nodes = nodes[:kept_count]
    root_id = nodes[0].id
    truncation_id = f"{root_id}:truncated"
    kept_nodes.append(
        ACTreeNode(
            id=truncation_id,
            label=f"… {omitted_nodes} nœuds omis (utiliser --max-nodes pour développer)",
            type="truncation",
        )
    )
    kept_ids = {node.id for node in kept_nodes}
    kept_edges = [edge for edge in edges if edge.source in kept_ids and edge.target in kept_ids]
    kept_edges.append(ACTreeEdge(source=root_id, target=truncation_id, relation="truncated"))
    return kept_nodes, kept_edges, omitted_nodes


def _load_spec(session: SessionFacts) -> SeedSpec | None:
    spec_path = spec_path_from_session(session)
    if spec_path is None:
        return None
    try:
        return load_seed_spec(spec_path)
    except SeedSpecValidationError:
        return None


def _goal_from_events(events: list[EventRecord]) -> str:
    for event in events:
        if event.type == "run.started":
            payload = event.payload_data
            if isinstance(payload, dict) and isinstance(payload.get("goal"), str):
                return str(payload["goal"])
    return ""


def _criterion_state(run_state: str) -> str:
    if run_state == "completed":
        return "attempted"
    if run_state in {"failed", "crashed", "cancelled", "interrupted"}:
        return "unknown"
    return "pending"


def _format_event_label(event: EventRecord) -> str:
    payload = event.payload_data
    if isinstance(payload, dict) and event.type == "run.progress":
        step = payload.get("step")
        total = payload.get("total")
        return f"seq={event.sequence} {event.type} step={step}/{total}"
    return f"seq={event.sequence} {event.type}"
