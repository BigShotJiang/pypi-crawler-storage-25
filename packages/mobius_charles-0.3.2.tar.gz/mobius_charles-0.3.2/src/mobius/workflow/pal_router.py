"""Routage PAL déterministe hors-ligne pour les lancements d'agents de codage Mobius."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from mobius.workflow.seed import SeedSpec

SECURITY_KEYWORDS = frozenset(
    {
        "auth",
        "authentication",
        "authorization",
        "oauth",
        "security",
        "sécurité",
        "secret",
        "token",
        "credential",
        "credentials",
        "payment",
        "paiement",
        "stripe",
        "pii",
        "personal data",
        "privacy",
        "production",
        "prod",
        "deploy",
        "compliance",
        "audit",
    }
)

ARCHITECTURE_KEYWORDS = frozenset(
    {
        "architecture",
        "architectural",
        "migration",
        "refactor",
        "review",
        "design",
        "schema",
        "database",
        "event store",
    }
)

LOCAL_LOW_COST_KEYWORDS = frozenset(
    {"local", "offline", "simple", "todo", "cli", "docs", "documentation", "script"}
)

DEFAULT_MODELS = {
    "droid": "local-default",
    "codex": "gpt-5.3-codex",
    "claude": "claude-sonnet",
}

# Chaîne d'escalade : du moins capable au plus capable.
ESCALATION_CHAIN: tuple[str, ...] = ("droid", "codex", "claude")


@dataclass(frozen=True)
class EscalationRecord:
    """Enregistrement d'une escalade d'agent dans la chaîne PAL."""

    from_agent: str
    to_agent: str
    reason: str
    attempt: int


@dataclass(frozen=True)
class PalRouteDecision:
    """Résultat structuré du routeur PAL pour le JSON CLI et les métadonnées d'exécution."""

    agent: str
    model: str | None
    mode: str
    risk_score: int
    complexity_score: int
    cost_score: int
    reasons: tuple[str, ...]
    escalation_history: tuple[EscalationRecord, ...] = ()

    def to_event_payload(self) -> dict[str, Any]:
        """Retourne un payload de décision de routage compatible JSON."""
        return {
            "agent": self.agent,
            "model": self.model,
            "mode": self.mode,
            "risk_score": self.risk_score,
            "complexity_score": self.complexity_score,
            "cost_score": self.cost_score,
            "reasons": list(self.reasons),
            "escalation_history": [
                {
                    "from_agent": record.from_agent,
                    "to_agent": record.to_agent,
                    "reason": record.reason,
                    "attempt": record.attempt,
                }
                for record in self.escalation_history
            ],
        }


def route_seed_spec(spec: SeedSpec) -> PalRouteDecision:
    """Recommend an agent/model/mode using only deterministic local spec signals."""
    text = _searchable_text(spec)
    criteria_count = len(spec.success_criteria)
    constraint_count = len(spec.constraints)
    verification_count = len(spec.verification_commands)
    artifact_count = len(spec.artifacts)
    risk_count = len(spec.risks)

    security_hits = _hits(text, SECURITY_KEYWORDS)
    architecture_hits = _hits(text, ARCHITECTURE_KEYWORDS)
    local_hits = _hits(text, LOCAL_LOW_COST_KEYWORDS)

    risk_score = min(
        10,
        risk_count * 2 + len(security_hits) * 2 + (1 if "brownfield" in spec.project_type else 0),
    )
    complexity_score = min(
        10,
        criteria_count
        + max(0, constraint_count - 1)
        + len(architecture_hits)
        + (1 if verification_count else 0)
        + (1 if artifact_count else 0),
    )

    reasons: list[str] = []
    if security_hits or risk_count:
        reasons.append(
            "Risque élevé détecté (sécurité/prod/données sensibles ou risques déclarés)."
        )
    if architecture_hits:
        reasons.append("Signaux architecture/review détectés dans la spec.")
    if verification_count:
        reasons.append(
            "Commandes de vérification présentes: le routeur favorise un agent de codage."
        )
    if criteria_count >= 4:
        reasons.append(
            "Plusieurs critères indépendants: candidat team/parallèle, sans lancement automatique."
        )

    mode = "single_agent"
    if criteria_count >= 4:
        mode = "team_candidate"

    if risk_score >= 5 or (risk_score >= 4 and complexity_score >= 4):
        agent = "claude"
        reasons.append("Claude recommandé pour analyse prudente, architecture ou review à risque.")
    elif _is_low_risk_local(spec, risk_score, complexity_score, local_hits):
        agent = "droid"
        mode = "local" if mode == "single_agent" else mode
        reasons.append(
            "Faible risque local: Droid recommandé pour coût minimal et exécution simple."
        )
    else:
        agent = "codex"
        reasons.append("Codex recommandé pour implémentation générale avec tests.")

    cost_score = {"droid": 1, "codex": 2, "claude": 3}[agent]
    return PalRouteDecision(
        agent=agent,
        model=DEFAULT_MODELS[agent],
        mode=mode,
        risk_score=risk_score,
        complexity_score=complexity_score,
        cost_score=cost_score,
        reasons=tuple(reasons),
    )


def escalate(
    previous: PalRouteDecision,
    exit_code: int,
    error_summary: str = "",
) -> PalRouteDecision:
    """Recommande l'agent de niveau supérieur après un échec (exit_code != 0).

    Si l'agent courant est déjà au sommet de la chaîne (``claude``), retourne
    la même décision enrichie d'une raison indiquant que l'escalade est impossible.
    Sinon, construit une nouvelle décision avec l'agent suivant, met à jour le
    modèle depuis ``DEFAULT_MODELS``, et ajoute un ``EscalationRecord`` à
    l'historique cumulé.

    Les scores de risque, complexité et coût du routage original sont conservés
    (sauf ``cost_score`` qui est recalculé pour le nouvel agent).
    """
    if exit_code == 0:
        return previous

    current_agent = previous.agent
    attempt = len(previous.escalation_history) + 1

    if current_agent not in ESCALATION_CHAIN or current_agent == ESCALATION_CHAIN[-1]:
        # Sommet de la chaîne : impossible d'escalader davantage.
        raison_sommet = "escalade impossible : agent maximal atteint"
        record = EscalationRecord(
            from_agent=current_agent,
            to_agent=current_agent,
            reason=raison_sommet,
            attempt=attempt,
        )
        return PalRouteDecision(
            agent=current_agent,
            model=previous.model,
            mode=previous.mode,
            risk_score=previous.risk_score,
            complexity_score=previous.complexity_score,
            cost_score=previous.cost_score,
            reasons=previous.reasons + (raison_sommet,),
            escalation_history=previous.escalation_history + (record,),
        )

    current_index = ESCALATION_CHAIN.index(current_agent)
    next_agent = ESCALATION_CHAIN[current_index + 1]
    next_model = DEFAULT_MODELS[next_agent]
    next_cost = {"droid": 1, "codex": 2, "claude": 3}[next_agent]

    detail = f" Détail : {error_summary}" if error_summary else ""
    raison_escalade = (
        f"Escalade {current_agent} → {next_agent} après échec"
        f" (exit_code={exit_code}, tentative={attempt}).{detail}"
    )
    record = EscalationRecord(
        from_agent=current_agent,
        to_agent=next_agent,
        reason=raison_escalade,
        attempt=attempt,
    )
    return PalRouteDecision(
        agent=next_agent,
        model=next_model,
        mode=previous.mode,
        risk_score=previous.risk_score,
        complexity_score=previous.complexity_score,
        cost_score=next_cost,
        reasons=previous.reasons + (raison_escalade,),
        escalation_history=previous.escalation_history + (record,),
    )


def _is_low_risk_local(
    spec: SeedSpec,
    risk_score: int,
    complexity_score: int,
    local_hits: set[str],
) -> bool:
    return (
        risk_score <= 2
        and complexity_score <= 3
        and len(spec.success_criteria) <= 2
        and bool(local_hits | ({spec.project_type.lower()} & LOCAL_LOW_COST_KEYWORDS))
    )


def _searchable_text(spec: SeedSpec) -> str:
    chunks: list[str] = [spec.project_type, spec.goal, spec.context, spec.premortem]
    chunks.extend(spec.constraints)
    chunks.extend(spec.success_criteria)
    chunks.extend(spec.non_goals)
    chunks.extend(_flatten_mapping(item) for item in spec.risks)
    chunks.extend(_flatten_mapping(item) for item in spec.artifacts)
    chunks.extend(_flatten_mapping(item) for item in spec.verification_commands)
    if isinstance(spec.agent_instructions, str):
        chunks.append(spec.agent_instructions)
    else:
        chunks.extend(spec.agent_instructions.values())
    return "\n".join(chunks).lower()


def _flatten_mapping(value: dict[str, Any]) -> str:
    return " ".join(str(part) for pair in value.items() for part in pair)


def _hits(text: str, keywords: frozenset[str]) -> set[str]:
    return {keyword for keyword in keywords if keyword in text}
