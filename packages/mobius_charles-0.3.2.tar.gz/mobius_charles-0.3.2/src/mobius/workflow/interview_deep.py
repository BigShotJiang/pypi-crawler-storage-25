"""Adaptive deep interview session."""

from __future__ import annotations

import sys
from pathlib import Path
from typing import IO, Any

from mobius.workflow.interview_contract import (
    _question_ledger_from_envelopes,
    build_ambiguity_ledger,
    build_closure_challenge,
    build_interview_handoff_metadata,
    build_second_opinion,
    evaluate_interview_contract,
)
from mobius.workflow.interview_memory import charger_progression, chemin_progression
from mobius.workflow.interview_parsing import (
    _combine_sentences,
    _default_branches,
    _infer_decision_boundaries,
    _infer_risks,
    _metadata_text_list,
    _semantic_clarity,
    fixture_from_template,
)
from mobius.workflow.interview_prompts import (
    _prompt_choice,
    _prompt_list,
    _prompt_ontology,
    _prompt_scalar,
    _run_targeted_followups,
)
from mobius.workflow.interview_scoring import compute_ambiguity_score
from mobius.workflow.interview_session_helpers import (
    _print_ambiguity_ledger,
    _print_routing_summary,
    _print_scoring_table,
    _print_second_opinion,
    _record_deep_question,
)
from mobius.workflow.interview_types import (
    InteractiveInterviewResult,
    InterviewFixture,
    RhythmGuardState,
    RoutingDecision,
    RoutingPath,
)
from mobius.workflow.templates import TEMPLATE_NAMES, detect_template, get_template


def run_deep_interactive_interview(
    *,
    workspace: Path,
    template_name: str | None = None,
    project_type: str = "greenfield",
    stdin: IO[str] | None = None,
    stderr: IO[str] | None = None,
) -> InteractiveInterviewResult:
    """Drive an adaptive interactive interview and return a spec fixture.

    This remains deterministic and local: Mobius asks targeted follow-up
    questions, but it does not call an LLM. The richer conversational work is
    captured as deep metadata so downstream seed/run/evolve flows keep the same
    spec contract.
    """
    from mobius.workflow.context_detector import format_detected_facts, scan_workspace_context
    from mobius.workflow.question_router import InterviewQuestion

    in_stream = stdin if stdin is not None else sys.stdin
    err = stderr if stderr is not None else sys.stderr

    if template_name is None:
        template_name = detect_template(workspace)
    template = get_template(template_name)
    defaults = fixture_from_template(template, project_type=project_type)

    ctx = scan_workspace_context(workspace)
    detected_lines = format_detected_facts(ctx)

    err.write(f"# Mobius interview deep — template: {template.name}\n")
    if detected_lines:
        for line in detected_lines:
            err.write(f"  ℹ  {line}\n")
        auto_count = sum(1 for line in detected_lines if line.startswith("Détecté"))
        err.write(f"  ✓  {auto_count} faits auto-confirmés\n")
    err.write("# Une question à la fois. Répondez court; Mobius relance les zones floues.\n\n")
    err.flush()
    progress_path = chemin_progression(workspace)
    initial_progress: dict[str, Any] = {}
    resumed_fixture: InterviewFixture | None = None
    if progress_path.exists():
        initial_progress = _choisir_reprise_deep(err, in_stream, progress_path)
        fixture_progression = _fixture_depuis_progression(initial_progress)
        if fixture_progression is not None:
            resumed_fixture = fixture_progression
            defaults = fixture_progression
            template_name = fixture_progression.template or template_name

    rhythm = RhythmGuardState()

    q_project_type = InterviewQuestion(key="project_type", category="context")
    routing_decisions: list[tuple[str, RoutingDecision]] = []
    question_envelopes: list[Any] = []
    decision_pt = _record_deep_question(
        err=err,
        question=q_project_type,
        context=ctx,
        rhythm=rhythm,
        routing_decisions=routing_decisions,
        question_envelopes=question_envelopes,
        phase="context",
    )

    if decision_pt.path == RoutingPath.AUTO_CONFIRM:
        project_type_answer = ctx.get_answer("project_type")
        err.write(f"  ✓  Type de projet: {project_type_answer} (auto-confirmé)\n")
        err.flush()
    else:
        project_type_answer = _prompt_choice(
            err,
            in_stream,
            "Type de projet [greenfield/brownfield]",
            default=ctx.get_answer("project_type")
            if ctx.has_answer("project_type")
            else defaults.project_type,
            choices=("greenfield", "brownfield"),
        )

    q_template = InterviewQuestion(key="template", category="context")
    decision_tpl = _record_deep_question(
        err=err,
        question=q_template,
        context=ctx,
        rhythm=rhythm,
        routing_decisions=routing_decisions,
        question_envelopes=question_envelopes,
        phase="context",
    )

    if decision_tpl.path == RoutingPath.AUTO_CONFIRM:
        template_name = ctx.get_answer("template") or detect_template(workspace)
        err.write(f"  ✓  Template: {template_name} (auto-confirmé)\n")
        err.flush()
    elif decision_tpl.path == RoutingPath.CODE_CONFIRM:
        suggested = ctx.get_answer("template") or detect_template(workspace)
        confirmed = _prompt_choice(
            err,
            in_stream,
            f"Template détecté: {suggested} — correct ?",
            default="oui",
            choices=("oui", "non"),
        )
        template_name = (
            suggested
            if confirmed == "oui"
            else _prompt_choice(err, in_stream, "Template", default="blank", choices=TEMPLATE_NAMES)
        )
    else:
        template_name = template_name or detect_template(workspace)

    template = get_template(template_name)
    defaults = resumed_fixture or fixture_from_template(template, project_type=project_type_answer)

    q_vision = InterviewQuestion(key="vision", category="vision", label="Vision")
    _record_deep_question(
        err=err,
        question=q_vision,
        context=ctx,
        rhythm=rhythm,
        routing_decisions=routing_decisions,
        question_envelopes=question_envelopes,
        phase="vision",
    )
    vision = _prompt_scalar(
        err,
        in_stream,
        "Vision — décrivez le projet en 2-4 phrases",
        default=defaults.goal,
    )
    q_primary_user = InterviewQuestion(
        key="primary_user", category="goal", label="Utilisateur et problème"
    )
    _record_deep_question(
        err=err,
        question=q_primary_user,
        context=ctx,
        rhythm=rhythm,
        routing_decisions=routing_decisions,
        question_envelopes=question_envelopes,
        phase="vision",
    )
    primary_user = _prompt_scalar(
        err,
        in_stream,
        "Pour qui exactement, et quel problème doit disparaître en premier ?",
        default="Utilisateur principal à préciser; résoudre le problème décrit dans la vision.",
    )
    goal_answer = _combine_sentences(vision, primary_user)

    q_branches = InterviewQuestion(key="branches", category="scope", label="Branches à explorer")
    _record_deep_question(
        err=err,
        question=q_branches,
        context=ctx,
        rhythm=rhythm,
        routing_decisions=routing_decisions,
        question_envelopes=question_envelopes,
        phase="scope",
    )
    branches = _prompt_list(
        err,
        in_stream,
        "Branches à explorer (ex: utilisateur, données, UX, intégration)",
        defaults=_default_branches(template.name, project_type_answer),
    )
    q_constraints = InterviewQuestion(
        key="constraints", category="requirements", label="Contraintes"
    )
    _record_deep_question(
        err=err,
        question=q_constraints,
        context=ctx,
        rhythm=rhythm,
        routing_decisions=routing_decisions,
        question_envelopes=question_envelopes,
        phase="constraints",
    )
    constraints_answer = _prompt_list(
        err,
        in_stream,
        "Contraintes non négociables (techniques, métier, temps, budget)",
        defaults=defaults.constraints,
    )
    q_success = InterviewQuestion(
        key="success", category="requirements", label="Critères de succès"
    )
    _record_deep_question(
        err=err,
        question=q_success,
        context=ctx,
        rhythm=rhythm,
        routing_decisions=routing_decisions,
        question_envelopes=question_envelopes,
        phase="success",
    )
    success_answer = _prompt_list(
        err,
        in_stream,
        "Critères de succès mesurables (avec seuil ou preuve observable)",
        defaults=defaults.success,
    )
    q_non_goals = InterviewQuestion(
        key="non_goals", category="non_goals", label="Non-objectifs"
    )
    _record_deep_question(
        err=err,
        question=q_non_goals,
        context=ctx,
        rhythm=rhythm,
        routing_decisions=routing_decisions,
        question_envelopes=question_envelopes,
        phase="closure",
    )
    non_goals = _prompt_list(
        err,
        in_stream,
        "Non-objectifs explicites (ce que la première version ne fera pas)",
        defaults=["Ne pas élargir au-delà du premier workflow validé."],
    )
    q_assumptions = InterviewQuestion(
        key="assumptions", category="premortem", label="Hypothèses"
    )
    _record_deep_question(
        err=err,
        question=q_assumptions,
        context=ctx,
        rhythm=rhythm,
        routing_decisions=routing_decisions,
        question_envelopes=question_envelopes,
        phase="challenge",
    )
    assumptions = _prompt_list(
        err,
        in_stream,
        "Hypothèses importantes à vérifier",
        defaults=["Les utilisateurs cibles ont réellement ce besoin."],
    )
    q_premortem = InterviewQuestion(
        key="premortem", category="premortem", label="Pre-mortem"
    )
    _record_deep_question(
        err=err,
        question=q_premortem,
        context=ctx,
        rhythm=rhythm,
        routing_decisions=routing_decisions,
        question_envelopes=question_envelopes,
        phase="challenge",
    )
    premortem = _prompt_scalar(
        err,
        in_stream,
        "Pre-mortem — dans 1 an le projet a échoué. Pourquoi ?",
        default="Le périmètre est resté trop vague ou aucun signal utilisateur n'a été mesuré.",
    )

    context_answer = ""
    if project_type_answer == "brownfield":
        try:
            from mobius.workflow.scan import context_from_workspace

            context_default = context_from_workspace(workspace)
        except Exception:
            context_default = defaults.context or "Existing system in place; preserve behavior."
        context_answer = _prompt_scalar(
            err,
            in_stream,
            "Contexte existant à préserver",
            default=context_default,
        )

    fixture = InterviewFixture(
        project_type=project_type_answer,
        goal=goal_answer,
        constraints=constraints_answer,
        success=success_answer,
        context=context_answer,
        template=template.name,
    )
    score = compute_ambiguity_score(fixture)
    contract_metadata: dict[str, Any] = {
        "non_goals": non_goals,
        "decision_boundaries": _infer_decision_boundaries(constraints_answer, non_goals),
    }
    fixture, score, memory, contract_metadata = _run_targeted_followups(
        err,
        in_stream,
        fixture,
        score,
        contract_metadata,
        progress_path=progress_path,
        initial_progress=initial_progress,
    )
    q_ontology = InterviewQuestion(
        key="ontology", category="architecture_tradeoff", label="Entités du domaine"
    )
    _record_deep_question(
        err=err,
        question=q_ontology,
        context=ctx,
        rhythm=rhythm,
        routing_decisions=routing_decisions,
        question_envelopes=question_envelopes,
        phase="ontology",
    )
    ontology = _prompt_ontology(err, in_stream)

    clarity = _semantic_clarity(fixture)
    risks = [{"description": item, "severity": "medium"} for item in _infer_risks(premortem)]
    deep_metadata: dict[str, Any] = {
        "interview_mode": "deep",
        "clarity_score": clarity,
        "risks": risks,
        "assumptions": [{"statement": item, "status": "unverified"} for item in assumptions],
        "premortem": premortem,
        "branches_explored": len(branches),
        "concepts": [
            {"term": item, "definition": "Branche d'interview explorée"} for item in branches
        ],
        "non_goals": _metadata_text_list(contract_metadata.get("non_goals")),
        "decision_boundaries": _metadata_text_list(contract_metadata.get("decision_boundaries")),
        "conversation_memory": memory.to_payload(),
        "ontology": ontology,
        "context_detected": {
            "facts_count": ctx.facts_count,
            "stack": ctx.stack,
            "is_brownfield": ctx.is_brownfield,
        },
    }
    deep_metadata["question_ledger"] = _question_ledger_from_envelopes(
        question_envelopes,
        {
            "project_type": fixture.project_type,
            "template": fixture.template,
            "vision": vision,
            "primary_user": primary_user,
            "branches": branches,
            "constraints": fixture.constraints,
            "success": fixture.success,
            "non_goals": non_goals,
            "assumptions": assumptions,
            "premortem": premortem,
            "context": fixture.context,
            "ontology": ontology,
        },
    )
    second_opinion = build_second_opinion(fixture, score=score, deep_metadata=deep_metadata)
    deep_metadata["second_opinion"] = second_opinion
    contract = evaluate_interview_contract(fixture, score=score, deep_metadata=deep_metadata)
    closure_challenge = build_closure_challenge(fixture, score, contract, second_opinion)
    deep_metadata["closure_challenge"] = closure_challenge
    contract = evaluate_interview_contract(fixture, score=score, deep_metadata=deep_metadata)
    deep_metadata.update(build_interview_handoff_metadata(fixture, contract))
    ledger = build_ambiguity_ledger(
        fixture,
        score,
        contract,
        routing_decisions=routing_decisions,
        question_envelopes=question_envelopes,
    )
    deep_metadata["ambiguity_ledger"] = ledger
    deep_state = "prêt" if contract.seed_ready else "à clarifier"
    err.write(
        "\n# État deep: "
        f"état={deep_state}, clarté={clarity['total']}/15, "
        f"branches={len(branches)}, faits_détectés={ctx.facts_count}, "
        f"score={score.score:.2f}\n"
    )
    _print_scoring_table(err, score, contract_seed_ready=contract.seed_ready)
    _print_second_opinion(err, second_opinion)
    _print_ambiguity_ledger(err, ledger)
    final_kind = "générer le seed" if contract.seed_ready else "clarifier"
    err.write(f"# Prochaine étape: {final_kind}\n")
    if not contract.seed_ready:
        err.write(contract.human_diagnostic() + "\n")
        err.write(f"Question: {closure_challenge['highest_impact_followup']}\n")
    err.flush()

    _print_routing_summary(err, rhythm)

    return InteractiveInterviewResult(fixture=fixture, deep_metadata=deep_metadata)


def _choisir_reprise_deep(
    err: IO[str],
    in_stream: IO[str],
    progress_path: Path,
) -> dict[str, Any]:
    """Propose reprendre, recommencer ou voir le résumé d'une progression."""
    progression = charger_progression(progress_path)
    while True:
        choix = _prompt_choice(
            err,
            in_stream,
            "progress.json détecté: reprendre, recommencer ou voir résumé ?",
            default="reprendre",
            choices=("reprendre", "recommencer", "résumé", "resume"),
        )
        if choix == "recommencer":
            progress_path.unlink(missing_ok=True)
            return {}
        if choix in {"résumé", "resume"}:
            _afficher_resume_progression(err, progression)
            continue
        return progression


def _afficher_resume_progression(err: IO[str], progression: dict[str, Any]) -> None:
    """Affiche un résumé court sans quitter le choix de reprise."""
    tours = progression.get("tours")
    total = len(tours) if isinstance(tours, list) else 0
    score_brut = progression.get("score")
    score: dict[str, Any] = score_brut if isinstance(score_brut, dict) else {}
    fixture_brut = progression.get("fixture")
    fixture: dict[str, Any] = fixture_brut if isinstance(fixture_brut, dict) else {}
    err.write("# Résumé progress.json\n")
    err.write(f"  tours={total}\n")
    err.write(f"  clarté={score.get('clarte', 'inconnue')}\n")
    state = "prêt" if score.get("seed_ready", False) else "à clarifier"
    err.write(f"  état={state}\n")
    err.write(f"  objectif={fixture.get('goal', '')}\n")
    err.flush()


def _fixture_depuis_progression(progression: dict[str, Any]) -> InterviewFixture | None:
    """Recrée le fixture par défaut depuis progress.json si possible."""
    brut = progression.get("fixture")
    if not isinstance(brut, dict):
        return None
    return InterviewFixture(
        project_type=str(brut.get("project_type") or "greenfield"),
        goal=str(brut.get("goal") or ""),
        constraints=[str(item) for item in brut.get("constraints", [])],
        success=[str(item) for item in brut.get("success", [])],
        context=str(brut.get("context") or ""),
        template=str(brut.get("template") or "blank"),
    )
