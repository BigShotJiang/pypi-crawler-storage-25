"""Interview closure contract, ledgers, and handoff metadata."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from mobius.workflow.interview_parsing import (
    _ambiguity_for_scalar,
    _has_testable_success,
    _metadata_text_list,
    _weakest_dimension,
)
from mobius.workflow.interview_scoring import compute_ambiguity_score
from mobius.workflow.interview_types import AmbiguityScore, InterviewFixture, RoutingDecision


@dataclass(frozen=True)
class InterviewClarityContract:
    """Autorité partagée de fermeture et de handoff pour l'interview Mobius."""

    ambiguity: AmbiguityScore
    non_goals: tuple[str, ...] = ()
    decision_boundaries: tuple[str, ...] = ()
    closure_blockers: tuple[str, ...] = ()

    @property
    def seed_ready(self) -> bool:
        """Renvoie True si la spec peut être remise à seed/run/QA."""
        return self.ambiguity.seed_ready and not self.closure_blockers

    def human_diagnostic(self) -> str:
        """Diagnostic français orienté non-dev: état, raison, réponse, recommandation."""
        if self.seed_ready:
            return (
                "Étape: prêt pour seed/run/QA.\n"
                "Pourquoi: les gates de clarté, non-objectifs, boundaries et critères "
                "testables sont satisfaits.\n"
                "Quoi répondre: vous pouvez valider ou demander une dernière relance.\n"
                "Recommandation Mobius: générer la spec et lancer la validation ciblée."
            )
        blockers = list(self.closure_blockers)
        if not self.ambiguity.seed_ready:
            blockers.append("clarity_gate_incomplete")
        readable = ", ".join(blockers) if blockers else "clarity_gate_incomplete"
        return (
            "Étape: clarification avant génération de spec.\n"
            f"Pourquoi: Mobius ne peut pas fermer l'interview; blocages={readable}.\n"
            "Quoi répondre: donnez un exemple concret, une hypothèse cachée, un tradeoff "
            "ou un non-goal explicite.\n"
            "Recommandation Mobius: bloquer la fermeture tant que non_goals, "
            "decision_boundaries et critères vérifiables ne sont pas présents."
        )


def build_interview_handoff_metadata(
    fixture: InterviewFixture,
    contract: InterviewClarityContract,
) -> dict[str, Any]:
    """Build first-class seed/run/QA handoff fields from the clarity contract.

    The values are descriptive and deterministic: Mobius records the QA links
    per criterion, but does not execute the commands during interview.
    """
    criteria_tree = [
        {
            "id": f"C{index}",
            "label": criterion,
            "qa_link": f"qa_required:C{index}",
        }
        for index, criterion in enumerate(fixture.success, start=1)
        if criterion.strip()
    ]
    verification_commands: list[dict[str, str]] = []
    enforcement_matrix: list[dict[str, str]] = [
        {
            "criterion_ref": node["id"],
            "contract_field": "success_criteria",
            "qa_link": node["qa_link"],
            "status": "required",
        }
        for node in criteria_tree
    ]
    for field_name, values in (
        ("non_goals", contract.non_goals),
        ("decision_boundaries", contract.decision_boundaries),
    ):
        enforcement_matrix.append(
            {
                "criterion_ref": field_name,
                "contract_field": field_name,
                "qa_link": "interview_clarity_contract",
                "status": "required" if values else "blocked",
            }
        )
    return {
        "criteria_tree": criteria_tree,
        "verification_commands": verification_commands,
        "enforcement_matrix": enforcement_matrix,
        "metadata": {
            "interview_contract_seed_ready": str(contract.seed_ready).lower(),
            "interview_contract_blockers": ",".join(contract.closure_blockers),
        },
    }


def infer_interview_contract_metadata(fixture: InterviewFixture) -> dict[str, list[str]]:
    """Infer deterministic contract metadata from an interview fixture.

    This is the shared local fallback for deep, conversational, build, and v3a
    paths. It is not a second closure authority; it only supplies metadata that
    `InterviewClarityContract` evaluates.
    """
    constraints = [item for item in fixture.constraints if item.strip()]
    non_goal_markers = ("avoid", "never", "no ", "not ", "keep", "preserve", "sans", "ne pas")
    keyword_non_goals = [
        f"Ne pas violer cette limite: {item}"
        for item in constraints
        if any(marker in item.lower() for marker in non_goal_markers)
    ]
    # When an agent provides explicit constraints but none match keyword heuristics,
    # treat all constraints as non-goals — each constraint is an implicit boundary.
    non_goals = (
        keyword_non_goals
        if keyword_non_goals
        else [f"Ne pas violer cette limite: {item}" for item in constraints]
    )
    return {
        "non_goals": non_goals,
        "decision_boundaries": constraints,
    }


def event_interview_contract_metadata(metadata: dict[str, object]) -> dict[str, object]:
    """Return first-class interview contract fields for event payloads."""
    return {
        key: metadata[key]
        for key in (
            "non_goals",
            "decision_boundaries",
            "criteria_tree",
            "verification_commands",
            "enforcement_matrix",
            "ambiguity_ledger",
            "question_ledger",
            "conversation_memory",
            "closure_challenge",
            "second_opinion",
        )
        if key in metadata
    }


def evaluate_interview_contract(
    fixture: InterviewFixture,
    *,
    score: AmbiguityScore | None = None,
    deep_metadata: dict[str, Any] | None = None,
) -> InterviewClarityContract:
    """Évalue le contrat unique de fermeture/handoff d'interview."""
    evaluated_score = score if score is not None else compute_ambiguity_score(fixture)
    deep = deep_metadata or {}
    non_goals = tuple(_metadata_text_list(deep.get("non_goals")))
    decision_boundaries = tuple(_metadata_text_list(deep.get("decision_boundaries")))
    blockers: list[str] = []
    if not non_goals:
        blockers.append("missing_non_goals")
    if not decision_boundaries:
        blockers.append("missing_decision_boundaries")
    if not _has_testable_success(fixture.success):
        blockers.append("success_criteria_not_testable")
    second_opinion = deep.get("second_opinion")
    if (
        isinstance(second_opinion, dict)
        and str(second_opinion.get("verdict", "")).lower() == "block"
    ):
        blockers.append("second_opinion_blocked")
    return InterviewClarityContract(
        ambiguity=evaluated_score,
        non_goals=non_goals,
        decision_boundaries=decision_boundaries,
        closure_blockers=tuple(blockers),
    )


def build_ambiguity_ledger(
    fixture: InterviewFixture,
    score: AmbiguityScore,
    contract: InterviewClarityContract,
    *,
    routing_decisions: list[tuple[str, RoutingDecision]] | None = None,
    question_envelopes: list[Any] | None = None,
) -> dict[str, Any]:
    """Build the visible machine-readable ambiguity ledger for interview parity."""
    weakest = _weakest_dimension(score)
    TrackPayload = dict[str, str | list[str]]
    tracks: dict[str, TrackPayload] = {
        "scope": {
            "status": "closed" if _ambiguity_for_scalar(fixture.goal) == 0.0 else "open",
            "evidence": [fixture.goal] if fixture.goal.strip() else [],
            "blockers": ["goal_ambiguous"] if score.floor_details.get("goal") is False else [],
        },
        "constraints": {
            "status": "closed" if fixture.constraints else "open",
            "evidence": list(fixture.constraints),
            "blockers": []
            if score.floor_details.get("constraints", True)
            else ["constraints_ambiguous"],
        },
        "outputs": {
            "status": "closed" if fixture.success else "open",
            "evidence": list(fixture.success),
            "blockers": []
            if score.floor_details.get("success", True)
            else ["success_criteria_ambiguous"],
        },
        "verification": {
            "status": (
                "closed"
                if "success_criteria_not_testable" not in contract.closure_blockers
                else "open"
            ),
            "evidence": list(fixture.success),
            "blockers": [
                blocker
                for blocker in contract.closure_blockers
                if blocker == "success_criteria_not_testable"
            ],
        },
    }
    if fixture.is_brownfield:
        scope_evidence = tracks["scope"]["evidence"]
        if isinstance(scope_evidence, list):
            scope_evidence.append(f"brownfield_context={bool(fixture.context.strip())}")
    envelope_payloads = [_question_envelope_payload(item) for item in (question_envelopes or [])]
    envelopes_by_key = {
        str(item.get("key", "")): item
        for item in envelope_payloads
        if isinstance(item, dict) and item.get("key")
    }
    next_kind = "seed" if contract.seed_ready else "clarify"
    return {
        "tracks": tracks,
        "routing": [
            {
                "key": key,
                "path": decision.path.value,
                "source": decision.source,
                "rationale": decision.rationale,
                **({"question_envelope": envelopes_by_key[key]} if key in envelopes_by_key else {}),
            }
            for key, decision in (routing_decisions or [])
        ],
        "question_envelopes": envelope_payloads,
        "score": {
            "total": score.score,
            "threshold": score.threshold,
            "components": dict(score.components),
            "floors_met": score.floors_met,
            "floor_details": dict(score.floor_details),
            "weakest_dimension": weakest or "",
        },
        "closure": {
            "seed_ready": contract.seed_ready,
            "blockers": list(contract.closure_blockers),
        },
        "next_action": {
            "kind": next_kind,
            "prompt": "Prêt pour seed." if contract.seed_ready else contract.human_diagnostic(),
        },
    }


def _question_envelope_payload(envelope: Any) -> dict[str, Any]:
    if hasattr(envelope, "to_payload"):
        payload = envelope.to_payload()
        return dict(payload) if isinstance(payload, dict) else {}
    if isinstance(envelope, dict):
        return dict(envelope)
    return {}


def _question_ledger_from_envelopes(
    question_envelopes: list[Any],
    answers: dict[str, Any] | None = None,
) -> list[dict[str, Any]]:
    """Return the public question-by-question ledger for deep specs.

    The ledger records both routing metadata and the local answer state. It is
    not a full transcript, but it must tell seed/QA reviewers whether each
    routed question was actually answered and where the answer landed.
    """
    answer_map = answers or {}
    ledger: list[dict[str, Any]] = []
    for index, envelope in enumerate(question_envelopes, start=1):
        payload = _question_envelope_payload(envelope)
        if not payload:
            continue
        key = str(payload.get("key", ""))
        payload.setdefault("ordinal", index)
        if key in answer_map:
            payload["answer"] = _ledger_answer_payload(answer_map[key])
        ledger.append(payload)
    return ledger


def _ledger_answer_payload(value: Any) -> dict[str, Any]:
    """Return a bounded, JSON-compatible answer payload for question_ledger."""
    if isinstance(value, list):
        clean_items = [str(item).strip() for item in value if str(item).strip()]
        return {
            "answered": bool(clean_items),
            "kind": "list",
            "count": len(clean_items),
            "items": clean_items,
        }
    if isinstance(value, dict):
        keys = [str(key) for key in value if str(key).strip()]
        return {
            "answered": bool(keys),
            "kind": "mapping",
            "count": len(keys),
            "keys": keys,
        }
    text = str(value).strip() if value is not None else ""
    return {
        "answered": bool(text),
        "kind": "text",
        "text": text,
    }


def build_second_opinion(
    fixture: InterviewFixture,
    *,
    score: AmbiguityScore | None = None,
    deep_metadata: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Build a deterministic second judge verdict before seed handoff."""
    evaluated_score = score if score is not None else compute_ambiguity_score(fixture)
    deep = deep_metadata or {}
    non_goals = _metadata_text_list(deep.get("non_goals"))
    boundaries = _metadata_text_list(deep.get("decision_boundaries"))
    assumption_items = deep.get("assumptions")
    assumptions = _metadata_text_list(
        [item.get("statement", "") if isinstance(item, dict) else item for item in assumption_items]
        if isinstance(assumption_items, list)
        else assumption_items
    )
    blockers: list[str] = []
    if not evaluated_score.seed_ready:
        blockers.append("ambiguity_gate_incomplete")
    if not non_goals:
        blockers.append("missing_non_goals")
    if not boundaries:
        blockers.append("missing_decision_boundaries")
    if not _has_testable_success(fixture.success):
        blockers.append("success_criteria_not_testable")
    if not assumptions:
        blockers.append("missing_assumptions")
    weakest = (
        (_weakest_dimension(evaluated_score) or "none")
        if not evaluated_score.seed_ready
        else "none"
    )
    return {
        "strongest_point": _strongest_point(fixture),
        "riskiest_assumption": (
            assumptions[0] if assumptions else "Aucune hypothèse vérifiable n'a été formulée."
        ),
        "blind_spot": _blind_spot(fixture, non_goals, boundaries, weakest),
        "validation_48h": _validation_48h(fixture),
        "verdict": "block" if blockers else "pass",
        "blockers": blockers,
    }


def build_closure_challenge(
    fixture: InterviewFixture,
    score: AmbiguityScore,
    contract: InterviewClarityContract,
    second_opinion: dict[str, Any],
) -> dict[str, Any]:
    """Return the final closure contract as deterministic booleans."""
    from mobius.workflow.seed_closer import close_interview

    return close_interview(fixture, score, contract, second_opinion).to_payload()


def _strongest_point(fixture: InterviewFixture) -> str:
    if _has_testable_success(fixture.success):
        return "Critères de succès vérifiables reliés à seed/run/QA."
    if fixture.constraints:
        return "Contraintes explicites qui bornent la première version."
    return "Intention initiale capturée, mais encore fragile."


def _blind_spot(
    fixture: InterviewFixture,
    non_goals: list[str],
    boundaries: list[str],
    weakest: str,
) -> str:
    if not non_goals:
        return "Le périmètre peut s'élargir car aucun non-objectif n'est fermé."
    if not boundaries:
        return "Les seuils de décision ne disent pas quand revenir à l'humain."
    if weakest != "none":
        return f"La dimension '{weakest}' reste la plus fragile."
    if fixture.is_brownfield and not fixture.context.strip():
        return "Le contexte brownfield à préserver n'est pas explicite."
    return "Le principal risque restant est la validation terrain hors Mobius."


def _validation_48h(fixture: InterviewFixture) -> str:
    criterion = fixture.success[0] if fixture.success else "un critère de succès observable"
    return (
        f"Sous 48h, produire une preuve locale que '{criterion}' "
        "passe via seed/run/QA ou test ciblé."
    )


def _highest_impact_followup(blockers: list[str], score: AmbiguityScore) -> str:
    if "non_goals_present" in blockers:
        return "Quel non-objectif doit explicitement rester hors de cette première spec ?"
    if "decision_boundaries_present" in blockers:
        return "Quelle décision doit obligatoirement revenir à l'humain avant seed/run ?"
    if "success_criteria_testable" in blockers:
        return "Quelle preuve observable dira, sans opinion, que le résultat est réussi ?"
    if "ambiguity_floor_passed" in blockers:
        weakest = _weakest_dimension(score) or "objectif"
        return f"Quelle réponse concrète ferme la dimension '{weakest}' ?"
    if "second_opinion_passed" in blockers:
        return "Quel test 48h réduit l'hypothèse la plus risquée ?"
    return "Confirmez-vous que cette spec est seed-ready ?"
