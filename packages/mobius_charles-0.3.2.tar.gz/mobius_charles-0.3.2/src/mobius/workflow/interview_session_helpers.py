"""Shared stderr reporting and routing helpers for interview sessions."""

from __future__ import annotations

from typing import IO, Any

from mobius.workflow.interview_types import (
    AmbiguityScore,
    RhythmGuardState,
    RoutingDecision,
    RoutingPath,
    route_with_rhythm,
)


def _print_routing_summary(err: IO[str], rhythm: RhythmGuardState) -> None:
    """Affiche un résumé des chemins de routage sur stderr."""
    auto = sum(1 for p in rhythm._history if p == RoutingPath.AUTO_CONFIRM)
    confirm = sum(1 for p in rhythm._history if p == RoutingPath.CODE_CONFIRM)
    human = sum(
        1
        for p in rhythm._history
        if p in {RoutingPath.HUMAN_JUDGMENT, RoutingPath.CODE_PLUS_JUDGMENT}
    )
    err.write(
        f"\n  Routage : {auto} auto-confirmés, {confirm} confirmés, {human} jugement humain\n"
    )
    err.flush()


def _print_ambiguity_ledger(err: IO[str], ledger: dict[str, Any]) -> None:
    """Print a compact human ledger without replacing the full metadata payload."""
    closure = ledger.get("closure", {})
    score = ledger.get("score", {})
    next_action = ledger.get("next_action", {})
    ready = closure.get("seed_ready", False) is True
    state = "prêt" if ready else "à clarifier"
    next_step = "générer le seed" if next_action.get("kind") == "seed" else "clarifier"
    err.write(
        "# Suivi interview: "
        f"état={state}, "
        f"point faible={score.get('weakest_dimension', '')}, "
        f"prochaine étape={next_step}\n"
    )
    tracks = ledger.get("tracks", {})
    if isinstance(tracks, dict):
        for name in ("scope", "constraints", "outputs", "verification"):
            track = tracks.get(name, {})
            if isinstance(track, dict):
                blockers = track.get("blockers", [])
                suffix = f" blocages={','.join(blockers)}" if blockers else ""
                err.write(f"  - {name}: {track.get('status', 'open')}{suffix}\n")
    err.flush()


def _record_deep_question(
    *,
    err: IO[str],
    question: Any,
    context: Any,
    rhythm: RhythmGuardState,
    routing_decisions: list[tuple[str, RoutingDecision]],
    question_envelopes: list[Any],
    phase: str,
) -> RoutingDecision:
    """Route, ledger, and display one deep-interview question before asking it."""
    from mobius.workflow.question_router import build_question_envelope

    decision = route_with_rhythm(question, context, rhythm)
    routing_decisions.append((question.key, decision))
    question_envelopes.append(build_question_envelope(question, decision, context))
    rhythm.record(decision.path)
    err.write(
        f"# Progression deep: phase={phase}, question={question.key}, "
        f"routing_path={decision.path.value}\n"
    )
    if decision.path is RoutingPath.RESEARCH:
        err.write("  external_evidence_needed=true (aucun appel réseau)\n")
    if decision.rationale:
        err.write(f"  rationale={decision.rationale}\n")
    err.flush()
    return decision


def _print_scoring_table(
    err: IO[str],
    score: AmbiguityScore,
    *,
    contract_seed_ready: bool | None = None,
) -> None:
    from mobius.workflow.interview_milestones import milestone_from_score, milestone_progress_bar

    milestone = milestone_from_score(score)
    clarte = max(0, min(100, round((1.0 - score.score) * 100)))
    ready_for_seed = contract_seed_ready is True
    next_step = "générer le seed" if ready_for_seed else "répondre à la question la plus bloquante"
    err.write("\n# Feedback\n")
    err.write(f"État: {milestone_progress_bar(milestone)}\n")
    err.write(f"Clarté: {clarte}%\n")
    err.write(f"Prochaine étape: {next_step}\n")
    err.flush()


def _print_second_opinion(err: IO[str], second_opinion: dict[str, Any]) -> None:
    err.write("# Second opinion\n")
    err.write(f"verdict={second_opinion.get('verdict', 'block')}\n")
    err.write(f"riskiest_assumption={second_opinion.get('riskiest_assumption', '')}\n")
    err.write(f"blind_spot={second_opinion.get('blind_spot', '')}\n")
    err.write(f"validation_48h={second_opinion.get('validation_48h', '')}\n")
    err.flush()
