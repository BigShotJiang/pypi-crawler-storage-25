"""Routeur de questions d'interview basé sur le contexte workspace.

Chaque question reçoit un chemin de routage parmi quatre options :
- AUTO_CONFIRM (1a) : réponse détectée avec haute confiance (≥ 0.9)
- CODE_CONFIRM (1b) : réponse détectée avec confiance moyenne (≥ 0.6)
- HUMAN_JUDGMENT (2) : pas de contexte ou catégorie réservée à l'humain
- CODE_PLUS_JUDGMENT (3) : le code aide, mais la décision reste humaine
- RESEARCH (4) : information externe requise, classée sans appel réseau

Les catégories "vision", "goal", "scope", "non_goals" et "premortem" sont
toujours routées vers HUMAN_JUDGMENT — elles exigent un jugement humain
indépendamment du contexte détecté.
"""

from __future__ import annotations

from dataclasses import dataclass, field

from mobius.workflow.context_detector import WorkspaceContext
from mobius.workflow.interview import RoutingDecision, RoutingPath

# Catégories qui exigent toujours une réponse humaine
_HUMAN_ONLY_CATEGORIES = frozenset({"vision", "goal", "scope", "non_goals", "premortem"})
_CODE_PLUS_JUDGMENT_CATEGORIES = frozenset(
    {"code_plus_judgment", "integration_decision", "architecture_tradeoff"}
)
_RESEARCH_CATEGORIES = frozenset(
    {"external_api", "pricing", "security_advisory", "version_compatibility", "industry_standard"}
)

# Seuils de confiance pour le routage automatique
_HIGH_CONFIDENCE_THRESHOLD = 0.9
_MEDIUM_CONFIDENCE_THRESHOLD = 0.6


@dataclass(frozen=True)
class QuestionEnvelope:
    """Structured routing envelope shown in the ambiguity ledger.

    It is intentionally transport-neutral: CLI, event stores, and future UI
    renderers can consume the same shape without inventing a new workflow.
    """

    key: str
    question: str
    path: str
    category: str = ""
    source_evidence: list[str] = field(default_factory=list)
    requires_user: bool = False
    suggested_options: list[str] = field(default_factory=list)
    answer_prefix: str = ""
    ledger_update: dict[str, object] = field(default_factory=dict)
    rationale: str = ""

    def to_payload(self) -> dict[str, object]:
        """Return a JSON-compatible event/ledger payload."""
        return {
            "key": self.key,
            "question": self.question,
            "category": self.category,
            "path": self.path,
            "source_evidence": list(self.source_evidence),
            "requires_user": self.requires_user,
            "suggested_options": list(self.suggested_options),
            "answer_prefix": self.answer_prefix,
            "ledger_update": dict(self.ledger_update),
            "rationale": self.rationale,
        }


@dataclass(frozen=True)
class InterviewQuestion:
    """Question structurée de l'interview Mobius.

    Chaque question est identifiée par une clé unique et appartient
    à une catégorie déterminant son chemin de routage par défaut.
    """

    key: str
    """Clé unique identifiant la question (ex: 'project_type', 'goal')."""

    category: str
    """Catégorie sémantique (ex: 'context', 'vision', 'requirements', 'premortem')."""

    label: str = ""
    """Libellé d'affichage de la question."""

    default: str = ""
    """Réponse par défaut proposée à l'utilisateur."""


def route_question(question: InterviewQuestion, context: WorkspaceContext) -> RoutingDecision:
    """Détermine le chemin de routage optimal pour une question donnée.

    Logique de routage :
    1. Si la catégorie est dans _HUMAN_ONLY_CATEGORIES → HUMAN_JUDGMENT
    2. Si le contexte a une réponse pour la clé :
       - confiance ≥ 0.9 → AUTO_CONFIRM
       - confiance ≥ 0.6 → CODE_CONFIRM
    3. Sinon → HUMAN_JUDGMENT
    """
    # Étape 1 : catégories réservées à l'humain
    if question.category in _HUMAN_ONLY_CATEGORIES:
        return RoutingDecision(
            path=RoutingPath.HUMAN_JUDGMENT,
            rationale=f"Catégorie '{question.category}' exige un jugement humain.",
        )

    if question.category in _RESEARCH_CATEGORIES:
        return RoutingDecision(
            path=RoutingPath.RESEARCH,
            source="research_needed",
            rationale=(
                "Information externe requise; classification locale seulement, "
                "aucun appel réseau pendant l'interview."
            ),
        )

    if question.category in _CODE_PLUS_JUDGMENT_CATEGORIES:
        source = ", ".join(context.detected_manifests) if context.detected_manifests else ""
        if context.has_answer(question.key) or context.detected_manifests or context.source_dirs:
            return RoutingDecision(
                path=RoutingPath.CODE_PLUS_JUDGMENT,
                source=source,
                rationale=(
                    "Le code fournit du contexte, mais la réponse finale exige "
                    "un jugement humain."
                ),
            )

    # Étape 2 : vérifier si le contexte peut répondre automatiquement
    if context.has_answer(question.key):
        confidence = context.confidence(question.key)
        source = ", ".join(context.detected_manifests) if context.detected_manifests else ""

        if confidence >= _HIGH_CONFIDENCE_THRESHOLD:
            return RoutingDecision(
                path=RoutingPath.AUTO_CONFIRM,
                source=source,
                rationale=(
                    "Réponse détectée avec confiance "
                    f"{confidence:.2f} ≥ {_HIGH_CONFIDENCE_THRESHOLD}."
                ),
            )

        if confidence >= _MEDIUM_CONFIDENCE_THRESHOLD:
            return RoutingDecision(
                path=RoutingPath.CODE_CONFIRM,
                source=source,
                rationale=(
                    "Réponse détectée avec confiance "
                    f"{confidence:.2f} ≥ {_MEDIUM_CONFIDENCE_THRESHOLD}."
                ),
            )

    # Étape 3 : pas de contexte ou confiance insuffisante → jugement humain
    return RoutingDecision(
        path=RoutingPath.HUMAN_JUDGMENT,
        rationale="Aucun contexte détecté ou confiance insuffisante.",
    )

def build_question_envelope(
    question: InterviewQuestion,
    decision: RoutingDecision,
    context: WorkspaceContext,
) -> QuestionEnvelope:
    """Build an Ouroboros-style envelope for one routed interview question.

    The envelope makes the routing decision first-class without changing the
    command surface: it tells renderers what to ask, what evidence exists,
    whether the user must answer, and which answer prefix downstream tools
    should use.
    """
    evidence = _source_evidence(decision, context)
    requires_user = decision.path is not RoutingPath.AUTO_CONFIRM
    suggested_options = _suggested_options(decision.path)
    answer_prefix = _answer_prefix(decision.path)
    ledger_update: dict[str, object] = {
        "key": question.key,
        "path": decision.path.value,
        "requires_user": requires_user,
        "source_evidence": list(evidence),
    }
    if decision.path is RoutingPath.RESEARCH:
        ledger_update["external_evidence_needed"] = True
    return QuestionEnvelope(
        key=question.key,
        question=question.label or question.key,
        category=question.category,
        path=decision.path.value,
        source_evidence=evidence,
        requires_user=requires_user,
        suggested_options=suggested_options,
        answer_prefix=answer_prefix,
        ledger_update=ledger_update,
        rationale=decision.rationale,
    )


def _source_evidence(decision: RoutingDecision, context: WorkspaceContext) -> list[str]:
    if decision.source.strip():
        return [part.strip() for part in decision.source.split(",") if part.strip()]
    evidence: list[str] = []
    evidence.extend(context.detected_manifests)
    evidence.extend(context.source_dirs)
    if context.framework:
        evidence.append(context.framework)
    if context.stack:
        evidence.append(context.stack)
    return evidence


def _suggested_options(path: RoutingPath) -> list[str]:
    if path is RoutingPath.CODE_CONFIRM:
        return ["Oui, utiliser ce fait", "Non, corriger"]
    if path is RoutingPath.HUMAN_JUDGMENT:
        return ["Répondre directement", "Clarifier le périmètre", "Marquer comme non-goal"]
    if path is RoutingPath.CODE_PLUS_JUDGMENT:
        return ["Utiliser le pattern détecté", "Adapter le pattern", "Choisir une autre approche"]
    if path is RoutingPath.RESEARCH:
        return ["Confirmer la recherche", "Corriger avec une autre source"]
    return []


def _answer_prefix(path: RoutingPath) -> str:
    if path is RoutingPath.AUTO_CONFIRM:
        return "[from-code][auto-confirmed]"
    if path is RoutingPath.CODE_CONFIRM:
        return "[from-code]"
    if path in {RoutingPath.HUMAN_JUDGMENT, RoutingPath.CODE_PLUS_JUDGMENT}:
        return "[from-user]"
    if path is RoutingPath.RESEARCH:
        return "[from-research]"
    return ""


def route_all_questions(
    questions: list[InterviewQuestion],
    context: WorkspaceContext,
) -> list[tuple[InterviewQuestion, RoutingDecision]]:
    """Applique route_question à chaque question et retourne les paires ordonnées.

    L'ordre des questions est préservé dans le résultat.
    """
    return [(question, route_question(question, context)) for question in questions]
