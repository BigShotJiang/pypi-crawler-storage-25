"""Prompt collection and adaptive follow-up helpers for interviews."""

from __future__ import annotations

from typing import IO, Any

from mobius.workflow.interview_contract import evaluate_interview_contract
from mobius.workflow.interview_memory import (
    ConversationMemory,
    InterviewRoundMemory,
    reconstruire_memoire,
    sauvegarder_progression_atomique,
)
from mobius.workflow.interview_parsing import _infer_decision_boundaries, _metadata_text_list
from mobius.workflow.interview_scoring import compute_ambiguity_score
from mobius.workflow.interview_types import AmbiguityScore, InterviewFixture, RoutingPath


def _prompt_scalar(err: IO[str], in_stream: IO[str], question: str, *, default: str) -> str:
    err.write(f"{question}\n  [default: {default!r}]\n> ")
    err.flush()
    line = in_stream.readline()
    if line == "":
        return default
    answer = line.rstrip("\n").strip()
    return answer if answer else default


def _prompt_with_suggestions(
    err: IO[str],
    in_stream: IO[str],
    question: str,
    *,
    suggestions: list[str],
) -> str:
    """Pose une question avec des options numérotées et accepte aussi du texte libre."""
    if not suggestions:
        return _prompt_scalar(err, in_stream, question, default="")

    err.write(f"\n{question}\n")
    for index, option in enumerate(suggestions, start=1):
        err.write(f"  [{index}] {option}\n")
    err.write(f"  ou tapez votre réponse (défaut: {suggestions[0]})\n")
    err.write("> ")
    err.flush()

    try:
        raw = in_stream.readline()
    except EOFError:
        raw = ""

    if not raw or not raw.strip():
        return suggestions[0]

    stripped = raw.strip()
    if stripped.isdigit():
        choice = int(stripped)
        if 1 <= choice <= len(suggestions):
            return suggestions[choice - 1]

    return stripped


def _prompt_choice(
    err: IO[str],
    in_stream: IO[str],
    question: str,
    *,
    default: str,
    choices: tuple[str, ...],
) -> str:
    while True:
        err.write(f"{question}\n  [default: {default}]\n> ")
        err.flush()
        line = in_stream.readline()
        if line == "":
            return default
        answer = line.rstrip("\n").strip().lower() or default
        if answer in choices:
            return answer
        err.write(f"  choix invalide ({', '.join(choices)}); réessayer.\n")


def _prompt_list(
    err: IO[str], in_stream: IO[str], question: str, *, defaults: list[str]
) -> list[str]:
    err.write(f"{question}\n")
    if defaults:
        err.write("  defaults (Enter on first prompt to accept all):\n")
        for default in defaults:
            err.write(f"    - {default}\n")
    err.write("> ")
    err.flush()
    first_line = in_stream.readline()
    if first_line == "":
        return list(defaults)
    first = first_line.rstrip("\n").strip()
    if first == "":
        return list(defaults)

    answers = [first]
    while True:
        err.write("> ")
        err.flush()
        line = in_stream.readline()
        if line == "":
            break
        item = line.rstrip("\n").strip()
        if item == "":
            break
        answers.append(item)
    return answers


def _prompt_ontology(err: IO[str], in_stream: IO[str]) -> dict[str, dict[str, Any]]:
    """Collecte les entités du domaine et retourne un dict ontologie.

    Chaque ligne non vide est interprétée comme un nom d'entité.
    Retourne un dict vide si l'utilisateur passe directement.
    """
    err.write(
        "Quelles sont les entités principales de votre domaine ?\n"
        "(ex: User, Product, Order — une par ligne, vide pour passer)\n> "
    )
    err.flush()
    first_line = in_stream.readline()
    if first_line == "":
        return {}
    first = first_line.rstrip("\n").strip()
    if first == "":
        return {}

    entities: list[str] = [first]
    while True:
        err.write("> ")
        err.flush()
        line = in_stream.readline()
        if line == "":
            break
        item = line.rstrip("\n").strip()
        if item == "":
            break
        entities.append(item)

    return {entity: {"fields": {}} for entity in entities}


def _run_targeted_followups(
    err: IO[str],
    in_stream: IO[str],
    fixture: InterviewFixture,
    score: AmbiguityScore,
    contract_metadata: dict[str, Any],
    *,
    progress_path: Any | None = None,
    initial_progress: dict[str, Any] | None = None,
) -> tuple[InterviewFixture, AmbiguityScore, ConversationMemory, dict[str, Any]]:
    """Pose des relances jusqu'à fermeture explicite ou fin de flux."""
    from mobius.workflow.adaptive_questions import next_question

    metadata = {
        "non_goals": _metadata_text_list(contract_metadata.get("non_goals")),
        "decision_boundaries": _metadata_text_list(contract_metadata.get("decision_boundaries")),
    }
    progression = dict(initial_progress or {})
    memory = reconstruire_memoire(progression)
    rounds = len(memory.rounds)
    tours_de_depart = rounds
    contract = evaluate_interview_contract(fixture, score=score, deep_metadata=metadata)
    while True:
        if contract.seed_ready and _clarte_pourcentage(score) >= 80:
            if rounds == tours_de_depart:
                break
            err.write("\n# Proposition de sortie: clarté >= 80% et portes passées.\n")
            choix = _prompt_choice(
                err,
                in_stream,
                "Sortir de l'interview deep maintenant ? [oui/non]",
                default="oui",
                choices=("oui", "non"),
            )
            if choix == "oui":
                break
        question = next_question(
            fixture=fixture,
            score=score,
            contract=contract,
            memory=memory,
        )
        if question is None:
            break
        rounds += 1
        ambiguity_before = score.score
        err.write(f"\n# Relance ciblée {rounds} — {question.because}\n")
        branch = getattr(question, "branch", "")
        if branch:
            err.write(f"# Branche interrogatoire: {branch}\n")
        recommendation = getattr(question, "recommendation", "")
        if recommendation:
            err.write(f"Ma recommandation: {recommendation}\n")
        err.flush()
        fixture, metadata, answer = _ask_targeted_followup(
            err,
            in_stream,
            fixture,
            metadata,
            question.key,
            question.prompt,
        )
        score = compute_ambiguity_score(fixture)
        contract = evaluate_interview_contract(fixture, score=score, deep_metadata=metadata)
        _ecrire_tour_conversationnel(
            err=err,
            question=question,
            answer=answer,
            score_avant=ambiguity_before,
            score_apres=score.score,
            contract=contract,
        )
        tour_sans_prochaine_question = InterviewRoundMemory(
            round_index=rounds,
            question_key=question.key,
            question=question.prompt,
            answer=answer,
            because=question.because,
            routing_path=RoutingPath.HUMAN_JUDGMENT.value,
            source="user",
            ambiguity_before=ambiguity_before,
            ambiguity_after=score.score,
            closure_blockers=contract.closure_blockers,
            open_decisions=contract.closure_blockers,
            branch=question.branch,
        )
        memoire_apres_tour = memory.record(tour_sans_prochaine_question)
        prochaine = next_question(
            fixture=fixture,
            score=score,
            contract=contract,
            memory=memoire_apres_tour,
        )
        if contract.seed_ready and _clarte_pourcentage(score) >= 80:
            prochaine_question = "Proposition de sortie: seed-ready."
        else:
            prochaine_question = prochaine.prompt
        round_memory = InterviewRoundMemory(
            round_index=rounds,
            question_key=question.key,
            question=question.prompt,
            answer=answer,
            because=question.because,
            routing_path=RoutingPath.HUMAN_JUDGMENT.value,
            source="user",
            ambiguity_before=ambiguity_before,
            ambiguity_after=score.score,
            closure_blockers=contract.closure_blockers,
            next_question=prochaine_question,
            open_decisions=contract.closure_blockers,
            branch=question.branch,
        )
        memory = memory.record(round_memory)
        if progress_path is not None:
            progression = _progression_payload(
                progression=progression,
                fixture=fixture,
                score=score,
                contract=contract,
                memory=memory,
                lentilles=question.lentilles or {},
            )
            sauvegarder_progression_atomique(progress_path, progression)
        next_step = "générer le seed" if contract.seed_ready else "clarifier"
        err.write(
            "# Recalcul: "
            f"clarté={_clarte_pourcentage(score)}%, prochaine étape={next_step}\n"
        )
        err.flush()
        if rounds >= 100:
            err.write("# Arrêt sécurité: 100 relances sans fermeture explicite.\n")
            err.flush()
            break
    return fixture, score, memory, metadata


def _clarte_pourcentage(score: AmbiguityScore) -> int:
    """Convertit l'ambiguïté en clarté lisible."""
    return max(0, min(100, round((1.0 - score.score) * 100)))


def _ecrire_tour_conversationnel(
    *,
    err: IO[str],
    question: Any,
    answer: str,
    score_avant: float,
    score_apres: float,
    contract: Any,
) -> None:
    """Affiche le retour conversationnel exigé par le mode deep."""
    clarte_avant = max(0, min(100, round((1.0 - score_avant) * 100)))
    clarte_apres = max(0, min(100, round((1.0 - score_apres) * 100)))
    delta = clarte_apres - clarte_avant
    flou = ", ".join(contract.closure_blockers) if contract.closure_blockers else "aucun blocage"
    from mobius.workflow.interview_milestones import milestone_from_score, milestone_progress_bar

    _dummy_score = AmbiguityScore(
        score=score_apres,
        threshold=0.2,
        passed=score_apres <= 0.2,
        weights={"goal": 0.4, "constraints": 0.3, "success": 0.3},
        components={"goal": score_apres, "constraints": score_apres, "success": score_apres},
        floors_met=contract.seed_ready if hasattr(contract, "seed_ready") else False,
        floor_details={},
    )
    err.write("# Feedback\n")
    err.write(f"État: {milestone_progress_bar(milestone_from_score(_dummy_score))}\n")
    err.write(f"Clarté: {clarte_apres}% ({delta:+d} pts)\n")
    err.write(f"Blocage: {flou}\n")
    err.write(f"Action: {question.recommendation or question.because}\n")
    err.flush()


def _reponse_visuelle(answer: str) -> bool:
    """Détecte un concept qui gagne à être rendu en petit schéma."""
    texte = answer.lower()
    mots_visuels = ("workflow", "flux", "pipeline", "architecture", "diagramme")
    return any(mot in texte for mot in mots_visuels)


def _progression_payload(
    *,
    progression: dict[str, Any],
    fixture: InterviewFixture,
    score: AmbiguityScore,
    contract: Any,
    memory: ConversationMemory,
    lentilles: dict[str, str],
) -> dict[str, Any]:
    """Construit le contrat JSON de reprise."""
    return {
        **progression,
        "mode": "deep",
        "schema_version": 1,
        "fixture": {
            "project_type": fixture.project_type,
            "goal": fixture.goal,
            "constraints": list(fixture.constraints),
            "success": list(fixture.success),
            "context": fixture.context,
            "template": fixture.template,
        },
        "score": {
            "ambiguity": score.score,
            "clarte": _clarte_pourcentage(score),
            "seed_ready": contract.seed_ready,
        },
        "lentilles": dict(lentilles),
        "closure_blockers": list(contract.closure_blockers),
        "tours": memory.to_payload(),
    }


def _ask_targeted_followup(
    err: IO[str],
    in_stream: IO[str],
    fixture: InterviewFixture,
    metadata: dict[str, Any],
    question_key: str,
    prompt: str,
) -> tuple[InterviewFixture, dict[str, Any], str]:
    """Ask one adaptive follow-up and apply it to fixture or contract metadata."""
    updated_metadata = {
        "non_goals": _metadata_text_list(metadata.get("non_goals")),
        "decision_boundaries": _metadata_text_list(metadata.get("decision_boundaries")),
    }
    answer = ""
    if question_key == "goal":
        answer = _prompt_scalar(err, in_stream, prompt, default=fixture.goal)
        fixture = InterviewFixture(
            project_type=fixture.project_type,
            goal=answer,
            constraints=fixture.constraints,
            success=fixture.success,
            context=fixture.context,
            template=fixture.template,
        )
    elif question_key == "constraints":
        constraints = _prompt_list(err, in_stream, prompt, defaults=fixture.constraints)
        answer = "; ".join(constraints)
        fixture = InterviewFixture(
            project_type=fixture.project_type,
            goal=fixture.goal,
            constraints=constraints,
            success=fixture.success,
            context=fixture.context,
            template=fixture.template,
        )
        updated_metadata["decision_boundaries"] = _infer_decision_boundaries(
            constraints,
            updated_metadata["non_goals"],
        )
    elif question_key == "success":
        success = _prompt_list(err, in_stream, prompt, defaults=fixture.success)
        answer = "; ".join(success)
        fixture = InterviewFixture(
            project_type=fixture.project_type,
            goal=fixture.goal,
            constraints=fixture.constraints,
            success=success,
            context=fixture.context,
            template=fixture.template,
        )
    elif question_key == "context":
        answer = _prompt_scalar(
            err,
            in_stream,
            prompt,
            default=fixture.context or "Existing behavior must remain stable.",
        )
        fixture = InterviewFixture(
            project_type=fixture.project_type,
            goal=fixture.goal,
            constraints=fixture.constraints,
            success=fixture.success,
            context=answer,
            template=fixture.template,
        )
    elif question_key == "non_goals":
        non_goals = _prompt_list(
            err,
            in_stream,
            prompt,
            defaults=updated_metadata["non_goals"],
        )
        answer = "; ".join(non_goals)
        updated_metadata["non_goals"] = non_goals
        updated_metadata["decision_boundaries"] = _infer_decision_boundaries(
            fixture.constraints,
            non_goals,
        )
    elif question_key == "decision_boundaries":
        boundaries = _prompt_list(
            err,
            in_stream,
            prompt,
            defaults=updated_metadata["decision_boundaries"],
        )
        answer = "; ".join(boundaries)
        updated_metadata["decision_boundaries"] = boundaries
    else:
        answer = _prompt_scalar(err, in_stream, prompt, default="")
    return fixture, updated_metadata, answer
