"""Compatibility facade for the split interview workflow modules."""
# ruff: noqa: F401

from __future__ import annotations

import io

from mobius.workflow.interview_contract import (
    InterviewClarityContract,
    _blind_spot,
    _highest_impact_followup,
    _ledger_answer_payload,
    _question_envelope_payload,
    _question_ledger_from_envelopes,
    _strongest_point,
    _validation_48h,
    build_ambiguity_ledger,
    build_closure_challenge,
    build_interview_handoff_metadata,
    build_second_opinion,
    evaluate_interview_contract,
    event_interview_contract_metadata,
    infer_interview_contract_metadata,
)
from mobius.workflow.interview_deep import run_deep_interactive_interview
from mobius.workflow.interview_interactive import run_interactive_interview
from mobius.workflow.interview_parsing import (
    _ambiguity_for_list,
    _ambiguity_for_scalar,
    _as_text,
    _as_text_list,
    _combine_sentences,
    _default_branches,
    _has_testable_success,
    _infer_decision_boundaries,
    _infer_risks,
    _is_ambiguous,
    _metadata_text_list,
    _parse_mapping,
    _parse_simple_yaml,
    _semantic_axis_score,
    _semantic_clarity,
    _strip_quotes,
    _weakest_dimension,
    fixture_from_template,
    parse_fixture,
)
from mobius.workflow.interview_prompts import (
    _ask_targeted_followup,
    _prompt_choice,
    _prompt_list,
    _prompt_ontology,
    _prompt_scalar,
    _run_targeted_followups,
)
from mobius.workflow.interview_render import (
    _load_deep_metadata,
    _render_deep_metadata,
    _yaml_mapping_list,
    question_answers,
    render_spec_yaml,
)
from mobius.workflow.interview_scoring import (
    _check_dimension_floors,
    evaluate_seed_closer,
)
from mobius.workflow.interview_session_helpers import (
    _print_ambiguity_ledger,
    _print_routing_summary,
    _print_scoring_table,
    _print_second_opinion,
    _record_deep_question,
)
from mobius.workflow.interview_types import (
    _AMBIGUOUS_MARKERS,
    _DIMENSION_FLOORS,
    _GATE_THRESHOLD,
    _RHYTHM_GUARD_THRESHOLD,
    _SEED_CLOSER_STREAK,
    _TESTABLE_SUCCESS_MARKERS,
    AmbiguityGateError,
    AmbiguityScore,
    InteractiveInterviewResult,
    InterviewFixture,
    RhythmGuardState,
    RoutingDecision,
    RoutingPath,
    SeedCloserGate,
    route_with_rhythm,
)

__all__ = [
    "AmbiguityGateError",
    "AmbiguityScore",
    "InteractiveInterviewResult",
    "InterviewClarityContract",
    "InterviewFixture",
    "InterviewMilestone",
    "RhythmGuardState",
    "RoutingDecision",
    "RoutingPath",
    "SeedCloserGate",
    "StringIO",
    "_AMBIGUOUS_MARKERS",
    "_DIMENSION_FLOORS",
    "_GATE_THRESHOLD",
    "_RHYTHM_GUARD_THRESHOLD",
    "_SEED_CLOSER_STREAK",
    "_TESTABLE_SUCCESS_MARKERS",
    "_ambiguity_for_list",
    "_ambiguity_for_scalar",
    "_as_text",
    "_as_text_list",
    "_ask_targeted_followup",
    "_blind_spot",
    "_check_dimension_floors",
    "_combine_sentences",
    "_default_branches",
    "_has_testable_success",
    "_highest_impact_followup",
    "_infer_decision_boundaries",
    "_infer_risks",
    "_is_ambiguous",
    "_ledger_answer_payload",
    "_load_deep_metadata",
    "_metadata_text_list",
    "_parse_mapping",
    "_parse_simple_yaml",
    "_print_ambiguity_ledger",
    "_print_routing_summary",
    "_print_scoring_table",
    "_print_second_opinion",
    "_prompt_choice",
    "_prompt_list",
    "_prompt_ontology",
    "_prompt_scalar",
    "_question_envelope_payload",
    "_question_ledger_from_envelopes",
    "_record_deep_question",
    "_render_deep_metadata",
    "_run_targeted_followups",
    "_semantic_axis_score",
    "_semantic_clarity",
    "_strip_quotes",
    "_strongest_point",
    "_validation_48h",
    "_weakest_dimension",
    "_yaml_list",
    "_yaml_mapping_list",
    "_yaml_scalar",
    "build_ambiguity_ledger",
    "build_closure_challenge",
    "build_interview_handoff_metadata",
    "build_second_opinion",
    "compute_ambiguity_score",
    "evaluate_interview_contract",
    "evaluate_seed_closer",
    "event_interview_contract_metadata",
    "fixture_from_template",
    "infer_interview_contract_metadata",
    "milestone_from_score",
    "milestone_progress_bar",
    "parse_fixture",
    "question_answers",
    "render_spec_yaml",
    "route_with_rhythm",
    "run_deep_interactive_interview",
    "run_interactive_interview",
]

StringIO = io.StringIO

# Compatibility aliases — moved to mobius.workflow._yaml but tests import from here.
from mobius.workflow._yaml import yaml_list as _yaml_list  # noqa: E402
from mobius.workflow._yaml import yaml_scalar as _yaml_scalar  # noqa: E402
from mobius.workflow.interview_milestones import (  # noqa: E402, F401
    InterviewMilestone,
    milestone_from_score,
    milestone_progress_bar,
)


def compute_ambiguity_score(fixture: InterviewFixture) -> AmbiguityScore:
    """Compatibility wrapper honoring legacy monkeypatches on this facade."""
    from mobius.workflow import interview_scoring as _interview_scoring

    previous_threshold = _interview_scoring._GATE_THRESHOLD
    _interview_scoring._GATE_THRESHOLD = _GATE_THRESHOLD
    try:
        return _interview_scoring.compute_ambiguity_score(fixture)
    finally:
        _interview_scoring._GATE_THRESHOLD = previous_threshold
