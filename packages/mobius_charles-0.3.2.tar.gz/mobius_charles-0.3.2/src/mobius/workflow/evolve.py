"""Evolution workflow execution helpers."""

from __future__ import annotations

import json
import os
import sys
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from mobius.config import MobiusPaths, _ensure_state
from mobius.core.types import ExitCode
from mobius.persistence.event_store import EventStore
from mobius.workflow.criterion_match import command_matches, references_for
from mobius.workflow.drift import score_generation_drift
from mobius.workflow.ids import readable_session_id
from mobius.workflow.lifecycle import (
    DetachedWorkerSpec,
    WorkerInterrupted,
    append_and_emit,
    cleanup_pid,
    start_detached_worker_process,
    write_pid,
)
from mobius.workflow.pal_router import PalRouteDecision, escalate
from mobius.workflow.run import CodingAgentRequest, run_coding_agent
from mobius.workflow.seed import SeedSpec, SeedSpecValidationError, load_seed_spec
from mobius.workflow.verify import ProofRecord, run_verification

MAX_GENERATIONS = 30
CONVERGENCE_THRESHOLD = 0.95
QUESTION_OVERLAP_THRESHOLD = 0.70
STAGNATION_WINDOW = 3


class EvolutionSourceNotFoundError(ValueError):
    """Raised when an evolution source run cannot be found."""


@dataclass(frozen=True)
class EvolutionPaths:
    """Filesystem paths for one evolution."""

    directory: Path
    pid_file: Path
    log_file: Path
    metadata_file: Path


@dataclass(frozen=True)
class PreparedEvolution:
    """A prepared evolution ready to execute."""

    evolution_id: str
    source_run_id: str
    generations: int
    paths: EvolutionPaths


@dataclass(frozen=True)
class SourceRunContext:
    """Source run data needed to evolve a failed run."""

    spec_path: Path
    spec: SeedSpec
    agent: str | None
    model: str | None
    agent_approved: bool = False


def get_evolution_paths(paths: MobiusPaths, evolution_id: str) -> EvolutionPaths:
    """Return the evolution directory paths for ``evolution_id``."""
    directory = paths.state_dir / "evolutions" / evolution_id
    return EvolutionPaths(
        directory=directory,
        pid_file=directory / "pid",
        log_file=directory / "log",
        metadata_file=directory / "metadata.json",
    )


def prepare_evolution(
    paths: MobiusPaths,
    source_run_id: str,
    *,
    generations: int,
) -> PreparedEvolution:
    """Validate the source run and create evolution metadata."""
    _ensure_state(paths)
    capped_generations = max(1, min(generations, MAX_GENERATIONS))
    with EventStore(paths.event_store) as store:
        source = store.connection.execute(
            "SELECT session_id, runtime, status FROM sessions WHERE session_id = ?",
            (source_run_id,),
        ).fetchone()
        if source is None or str(source["runtime"]) != "run":
            raise EvolutionSourceNotFoundError(f"run introuvable : {source_run_id}")

    evolution_id = readable_session_id("evo", source_run_id)
    evolution_paths = get_evolution_paths(paths, evolution_id)
    evolution_paths.directory.mkdir(parents=True, exist_ok=True, mode=0o700)
    os.chmod(evolution_paths.directory, 0o700)
    brownfield_context = _resolve_brownfield_context_from_run(paths, source_run_id)
    evolution_paths.metadata_file.write_text(
        json.dumps(
            {
                "source_run_id": source_run_id,
                "generations": capped_generations,
                "brownfield_context": brownfield_context,
            },
            sort_keys=True,
        ),
        encoding="utf-8",
    )
    os.chmod(evolution_paths.metadata_file, 0o600)
    return PreparedEvolution(
        evolution_id=evolution_id,
        source_run_id=source_run_id,
        generations=capped_generations,
        paths=evolution_paths,
    )


def start_detached_worker(paths: MobiusPaths, prepared: PreparedEvolution) -> int:
    """Fork a detached evolution worker and write its PID file."""
    return start_detached_worker_process(
        paths,
        DetachedWorkerSpec(
            session_id=prepared.evolution_id,
            runtime="evolution",
            metadata={
                "source_run_id": prepared.source_run_id,
                "generations": prepared.generations,
            },
            command=["mobius", "_worker", "evolve", prepared.evolution_id],
            files=prepared.paths,
        ),
    )


def run_foreground(paths: MobiusPaths, prepared: PreparedEvolution) -> int:
    """Execute evolution in the current process."""
    write_pid(prepared.paths.pid_file, os.getpid())
    return execute_evolution(paths, prepared.evolution_id, stream_events=True)


def execute_evolution(paths: MobiusPaths, evolution_id: str, *, stream_events: bool) -> int:
    """Worker entry point for a prepared evolution."""
    evolution_paths = get_evolution_paths(paths, evolution_id)
    metadata = _read_metadata(evolution_paths)
    source_run_id = str(metadata["source_run_id"])
    brownfield_context = str(metadata.get("brownfield_context", ""))
    metadata_generations = metadata["generations"]
    if not isinstance(metadata_generations, int):
        msg = f"evolution metadata generations must be an integer for {evolution_id}"
        raise EvolutionSourceNotFoundError(msg)
    generations = metadata_generations

    EvolutionInterrupted(
        paths=paths,
        evolution_id=evolution_id,
        pid_file=evolution_paths.pid_file,
    ).install()

    try:
        with EventStore(paths.event_store) as store:
            store.create_session(
                evolution_id,
                runtime="evolution",
                metadata={
                    "source_run_id": source_run_id,
                    "generations": generations,
                    "brownfield_context": brownfield_context,
                },
                status="running",
            )
            _append_and_emit(
                store,
                evolution_id,
                "evolution.started",
                {
                    "source_run_id": source_run_id,
                    "max_generations": generations,
                    "brownfield_context": brownfield_context,
                },
                stream_events=stream_events,
            )

            source_context = _resolve_source_run_context(store, source_run_id)
            if source_context is None:
                _append_and_emit(
                    store,
                    evolution_id,
                    "evolution.completed",
                    {
                        "reason": "spec_unavailable",
                        "generations_run": 0,
                        "message": "Spec introuvable pour le run source",
                    },
                    stream_events=stream_events,
                )
                store.end_session(evolution_id, status="failed")
                return int(ExitCode.GENERIC_ERROR)

            verification_config = _load_verification_config(paths.state_dir)
            history: list[dict[str, Any]] = []
            previous_questions: list[str] = []
            previous_results: list[dict[str, str]] | None = None
            terminal_reason = "max_generations"
            ontology = dict(source_context.spec.ontology) if source_context.spec.ontology else {}
            prev_ontology: dict[str, Any] = {}
            for generation in range(1, generations + 1):
                # Wonder + Reflect phases (skip silently if ontology empty)
                if ontology:
                    gaps = _wonder(
                        store,
                        evolution_id,
                        generation,
                        source_run_id,
                        ontology,
                        evolution_paths,
                    )
                    mutations = _reflect(
                        store,
                        evolution_id,
                        generation,
                        gaps,
                        ontology,
                    )
                    for mutation in mutations:
                        ontology[f"_gap_{mutation['entity']}"] = mutation["suggestion"]
                    if stream_events:
                        sys.stderr.write(
                            f"  🔍 Wonder: {len(gaps)} lacunes ontologiques détectées\n"
                        )
                        sys.stderr.write(f"  💡 Reflect: {len(mutations)} mutations proposées\n")
                        sys.stderr.flush()

                # Ontology convergence check
                if ontology and prev_ontology:
                    ontology_similarity = compute_ontology_overlap(
                        prev_ontology,
                        ontology,
                    )
                else:
                    ontology_similarity = 0.0

                candidate, questions, previous_results = _run_generation(
                    store,
                    evolution_id,
                    source_run_id,
                    source_context,
                    generation,
                    verification_config,
                    previous_results=previous_results,
                    history=history,
                    stream_events=stream_events,
                )
                similarity = calculate_similarity(history[-1], candidate) if history else 0.0
                repetitive_feedback = bool(
                    previous_questions and detect_repetitive_feedback(previous_questions, questions)
                )
                history.append(candidate)
                oscillation = detect_period_two_oscillation(history)
                converged = detect_stagnation(history)
                ontology_converged = bool(
                    ontology and prev_ontology and ontology_similarity >= CONVERGENCE_THRESHOLD
                )
                _append_and_emit(
                    store,
                    evolution_id,
                    "evolution.generation",
                    {
                        "generation": generation,
                        "candidate": candidate,
                        "similarity": similarity,
                        "converged": converged,
                        "period_two_oscillation": oscillation,
                        "repetitive_feedback": repetitive_feedback,
                        "ontology_similarity": ontology_similarity,
                        "ontology_converged": ontology_converged,
                    },
                    stream_events=stream_events,
                )
                drift = score_generation_drift(source_context.spec, candidate)
                _append_and_emit(
                    store,
                    evolution_id,
                    "evolution.drift_detected",
                    {"generation": generation, **drift.to_event_payload()},
                    stream_events=stream_events,
                )
                if previous_results and all(
                    result["verdict"] == "pass" for result in previous_results
                ):
                    terminal_reason = "criteria_all_passed"
                    break
                if converged:
                    terminal_reason = "converged"
                    break
                if ontology_converged:
                    terminal_reason = "ontology_converged"
                    break
                if oscillation:
                    terminal_reason = "period_two_oscillation"
                    break
                if repetitive_feedback:
                    terminal_reason = "repetitive_feedback"
                    break
                prev_ontology = dict(ontology)
                previous_questions = questions
                time.sleep(0.2)

            _append_and_emit(
                store,
                evolution_id,
                "evolution.completed",
                {"reason": terminal_reason, "generations_run": len(history)},
                stream_events=stream_events,
            )
            from mobius.workflow.lateral import suggest_persona

            suggestion = suggest_persona(store, evolution_id)
            _append_and_emit(
                store,
                evolution_id,
                "agent.suggest_persona",
                {
                    "persona": suggestion.persona,
                    "reason": suggestion.reason,
                    "confidence": suggestion.confidence,
                    "trigger": terminal_reason,
                },
                stream_events=stream_events,
            )
            store.end_session(evolution_id, status="completed")
        return int(ExitCode.OK)
    finally:
        cleanup_pid(evolution_paths.pid_file)


class EvolutionInterrupted(WorkerInterrupted):
    """Signal handlers for an evolution worker."""

    def __init__(self, *, paths: MobiusPaths, evolution_id: str, pid_file: Path) -> None:
        super().__init__(
            paths=paths,
            session_id=evolution_id,
            runtime="evolution",
            pid_file=pid_file,
        )

    @property
    def evolution_id(self) -> str:
        """Evolution identifier preserved for callers that inspect the handler."""
        return self.session_id


def calculate_similarity(previous: dict[str, Any], candidate: dict[str, Any]) -> float:
    """Calculate weighted similarity: name 50%, type 30%, exact 20%."""
    score = 0.0
    if previous.get("name") == candidate.get("name"):
        score += 0.5
    if previous.get("type") == candidate.get("type"):
        score += 0.3
    if _canonical_candidate(previous) == _canonical_candidate(candidate):
        score += 0.2
    return round(score, 6)


def detect_period_two_oscillation(history: list[dict[str, Any]]) -> bool:
    """Return true when the last four candidates form A/B/A/B."""
    if len(history) < 4:
        return False
    a1, b1, a2, b2 = history[-4:]
    return (
        _canonical_candidate(a1) == _canonical_candidate(a2)
        and _canonical_candidate(b1) == _canonical_candidate(b2)
        and _canonical_candidate(a1) != _canonical_candidate(b1)
    )


def detect_repetitive_feedback(
    previous_questions: list[str],
    current_questions: list[str],
    *,
    threshold: float = QUESTION_OVERLAP_THRESHOLD,
) -> bool:
    """Return true when question overlap is at least ``threshold``."""
    if not previous_questions or not current_questions:
        return False
    previous = {_normalize_question(question) for question in previous_questions}
    current = {_normalize_question(question) for question in current_questions}
    if not previous or not current:
        return False
    overlap = len(previous & current) / min(len(previous), len(current))
    return overlap >= threshold


def compute_ontology_overlap(onto_a: dict[str, Any], onto_b: dict[str, Any]) -> float:
    """Jaccard sur les clés d'entités de deux ontologies."""
    keys_a = set(onto_a.keys()) if onto_a else set()
    keys_b = set(onto_b.keys()) if onto_b else set()
    if not keys_a and not keys_b:
        return 1.0
    if not keys_a or not keys_b:
        return 0.0
    intersection = keys_a & keys_b
    union = keys_a | keys_b
    return len(intersection) / len(union)


def detect_stagnation(
    history: list[dict[str, Any]],
    *,
    window: int = STAGNATION_WINDOW,
    threshold: float = CONVERGENCE_THRESHOLD,
) -> bool:
    """Return true when recent candidates are consistently similar."""
    if len(history) < window:
        return False
    recent = history[-window:]
    return all(
        calculate_similarity(left, right) >= threshold
        for left, right in zip(recent, recent[1:], strict=False)
    )


def _wonder(
    store: EventStore,
    evolution_id: str,
    gen_number: int,
    run_id: str,
    ontology: dict[str, Any],
    _paths: EvolutionPaths,
) -> list[dict[str, str]]:
    """Examine QA failures to identify ontological gaps — deterministic, no LLM."""
    if not ontology:
        return []
    # Read qa.completed events from the source run
    criteria_texts: list[str] = []
    for event in store.read_events(run_id):
        if event.type == "qa.completed":
            payload = event.payload_data
            if not isinstance(payload, dict):
                continue
            results = payload.get("results")
            if not isinstance(results, list):
                continue
            for result in results:
                if not isinstance(result, dict):
                    continue
                verdict = str(result.get("verdict", "")).lower()
                if verdict != "pass":
                    label = str(result.get("label", ""))
                    detail = str(result.get("detail", ""))
                    criteria_texts.append(f"{label} {detail}".lower())
    # For each ontology entity, check if any criterion mentions it (case-insensitive)
    # Entities not mentioned in any criterion = gaps
    all_criteria_text = " ".join(criteria_texts)
    gaps: list[dict[str, str]] = []
    for entity in sorted(ontology.keys()):
        if entity.startswith("_gap_"):
            continue
        if entity.lower() not in all_criteria_text:
            gaps.append(
                {
                    "entity": entity,
                    "reason": f"Aucun critère échoué ne mentionne '{entity}'",
                }
            )
    _append_and_emit(
        store,
        evolution_id,
        "wonder.completed",
        {
            "generation": gen_number,
            "gaps": gaps,
            "gap_count": len(gaps),
        },
        stream_events=False,
    )
    return gaps


def _reflect(
    store: EventStore,
    evolution_id: str,
    gen_number: int,
    gaps: list[dict[str, str]],
    _ontology: dict[str, Any],
) -> list[dict[str, str]]:
    """Propose ontology mutations based on Wonder gaps — deterministic, no LLM."""
    if not gaps:
        _append_and_emit(
            store,
            evolution_id,
            "reflect.completed",
            {
                "generation": gen_number,
                "mutations": [],
                "mutation_count": 0,
            },
            stream_events=False,
        )
        return []
    mutations: list[dict[str, str]] = []
    for gap in gaps:
        entity = gap["entity"]
        mutations.append(
            {
                "entity": entity,
                "action": "needs_criteria",
                "suggestion": f"Ajouter des critères de succès testant {entity}",
            }
        )
    _append_and_emit(
        store,
        evolution_id,
        "reflect.completed",
        {
            "generation": gen_number,
            "mutations": mutations,
            "mutation_count": len(mutations),
        },
        stream_events=False,
    )
    return mutations


def _resolve_brownfield_context_from_run(paths: MobiusPaths, source_run_id: str) -> str:
    try:
        with EventStore(paths.event_store, read_only=True) as store:
            events = store.read_events(source_run_id)
            for e in events:
                if e.type == "run.started":
                    spec_path_str = e.payload_data.get("spec_path", "")
                    if spec_path_str:
                        from mobius.workflow.seed import load_seed_spec

                        spec_path = Path(spec_path_str)
                        if spec_path.exists():
                            spec = load_seed_spec(spec_path)
                            return spec.context
    except (OSError, SeedSpecValidationError):
        pass
    return ""


def _resolve_source_run_context(store: EventStore, source_run_id: str) -> SourceRunContext | None:
    events = store.read_events(source_run_id)
    for event in events:
        if event.type != "run.started":
            continue
        payload = event.payload_data
        if not isinstance(payload, dict):
            return None
        spec_path_value = payload.get("spec_path")
        if not isinstance(spec_path_value, str) or not spec_path_value:
            return None
        spec_path = Path(spec_path_value)
        if not spec_path.exists():
            return None
        try:
            spec = load_seed_spec(spec_path)
        except (OSError, SeedSpecValidationError):
            return None
        approved = payload.get("agent_approved") is True
        payload_agent = payload.get("coding_agent")
        payload_model = payload.get("coding_model")
        agent = payload_agent.strip().lower() if approved and isinstance(payload_agent, str) else ""
        model = payload_model.strip() if approved and isinstance(payload_model, str) else ""
        if approved and not agent and spec.coding_agent:
            agent = spec.coding_agent.strip().lower()
        if approved and not model and spec.coding_model:
            model = spec.coding_model.strip()
        return SourceRunContext(
            spec_path=spec_path,
            spec=spec,
            agent=agent or None,
            model=model or None,
            agent_approved=approved,
        )
    return None


def _collect_failing_results(store: EventStore, source_run_id: str) -> list[dict[str, str]]:
    for event in reversed(store.read_events(source_run_id)):
        if event.type != "qa.completed":
            continue
        payload = event.payload_data
        if not isinstance(payload, dict):
            return []
        raw_results = payload.get("results")
        if not isinstance(raw_results, list):
            return []
        failures: list[dict[str, str]] = []
        for raw in raw_results:
            if not isinstance(raw, dict):
                continue
            verdict = str(raw.get("verdict", "")).lower()
            if verdict not in {"fail", "unverified"}:
                continue
            failures.append(
                {
                    "id": str(raw.get("id", "")),
                    "label": str(raw.get("label", "")),
                    "verdict": verdict,
                    "detail": str(raw.get("detail", "")),
                }
            )
        return failures
    return []


def _build_evolution_prompt(
    context: SourceRunContext,
    generation: int,
    failing_results: list[dict[str, str]],
    evolution_plan: dict[str, Any] | None = None,
    history: list[dict[str, Any]] | None = None,
) -> str:
    spec = context.spec
    failures = "\n".join(
        f"- {result['label']}: {result['detail']}".strip()
        for result in failing_results
        if result.get("label") or result.get("detail")
    )
    if not failures:
        failures = (
            "- Aucun resultat QA echoue disponible. Corrige tout ce qui empeche la spec de passer."
        )
    constraints = "\n".join(f"- {constraint}" for constraint in spec.constraints) or "- Aucune"
    if isinstance(spec.agent_instructions, dict):
        agent_instructions = "\n".join(
            f"- {key}: {value}" for key, value in sorted(spec.agent_instructions.items())
        )
    else:
        agent_instructions = spec.agent_instructions.strip()
    if not agent_instructions:
        agent_instructions = "Aucune"
    plan = evolution_plan or _build_evolution_plan(failing_results, history or [], generation)
    return "\n".join(
        [
            f"Generation Mobius evolve: {generation}",
            f"Spec: {context.spec_path}",
            "",
            "Goal:",
            spec.goal,
            "",
            "Criteres echoues:",
            failures,
            "",
            "Pourquoi ca echoue:",
            str(plan["why"]),
            "",
            "Plan d'evolution (mutations typees):",
            _format_evolution_plan(plan),
            "",
            "Historique inter-generations (3 dernieres):",
            _format_generation_history(history or []),
            "",
            "Contraintes:",
            constraints,
            "",
            "Context brownfield:",
            spec.context or "Aucun",
            "",
            "Instructions agent:",
            agent_instructions,
            "",
            "Tache:",
            "Applique le plan mute, corrige la cause des echecs, puis arrete-toi.",
        ]
    )


def _build_evolution_plan(
    failing_results: list[dict[str, str]],
    history: list[dict[str, Any]],
    generation: int,
) -> dict[str, Any]:
    """Build deterministic plan mutations from current failures and recent history."""
    actions: list[dict[str, str]] = []
    for result in failing_results:
        verdict = result.get("verdict", "")
        operation = "add" if verdict == "unverified" else "modify"
        target = result.get("id") or result.get("label") or "unknown"
        detail = result.get("detail") or "no detail"
        actions.append(
            {
                "op": operation,
                "target": target,
                "reason": f"{verdict}: {detail}",
            }
        )
    if _has_repeated_failure_shape(history):
        actions.append(
            {
                "op": "remove",
                "target": "stale-assumption",
                "reason": "recent generations kept the same blocking shape",
            }
        )
    if not actions:
        actions.append(
            {
                "op": "modify",
                "target": "implementation",
                "reason": "no detailed QA failure was available; inspect hidden blockers",
            }
        )
    return {
        "generation": generation,
        "why": _summarize_failure_cause(failing_results, history),
        "actions": actions,
        "history_window": min(len(history), STAGNATION_WINDOW),
    }


def _summarize_failure_cause(
    failing_results: list[dict[str, str]],
    history: list[dict[str, Any]],
) -> str:
    if any(result.get("verdict") == "unverified" for result in failing_results):
        return "des criteres ne sont pas encore relies a une preuve executable"
    if failing_results:
        return "les commandes de verification liees aux criteres echouent encore"
    if history:
        return "aucun detail QA recent; utiliser l'historique pour chercher la cause cachee"
    return "premiere generation sans detail QA exploitable"


def _format_evolution_plan(plan: dict[str, Any]) -> str:
    actions = plan.get("actions")
    if not isinstance(actions, list) or not actions:
        return "- modify implementation: inspect hidden blockers"
    lines = []
    for action in actions:
        if not isinstance(action, dict):
            continue
        op = str(action.get("op", "modify"))
        target = str(action.get("target", "implementation"))
        reason = str(action.get("reason", "no reason"))
        lines.append(f"- {op} {target}: {reason}")
    return "\n".join(lines) if lines else "- modify implementation: inspect hidden blockers"


def _format_generation_history(history: list[dict[str, Any]]) -> str:
    recent = history[-STAGNATION_WINDOW:]
    if not recent:
        return "- Aucune generation precedente"
    lines = []
    for index, candidate in enumerate(recent, start=max(1, len(history) - len(recent) + 1)):
        payload = candidate.get("payload", {})
        if isinstance(payload, dict):
            passed = payload.get("passed", 0)
            failed = payload.get("failed", 0)
            criteria = payload.get("criterion_ids", [])
        else:
            passed = 0
            failed = 0
            criteria = []
        lines.append(f"- Gen {index}: passed={passed}, failed={failed}, criteria={criteria}")
    return "\n".join(lines)


def _has_repeated_failure_shape(history: list[dict[str, Any]]) -> bool:
    if len(history) < 2:
        return False
    recent = history[-2:]
    return _canonical_candidate(recent[0]) == _canonical_candidate(recent[1])


def _decision_from_context(context: SourceRunContext) -> PalRouteDecision:
    """Construit une ``PalRouteDecision`` minimale depuis le contexte d'exécution source.

    Utilisé pour alimenter ``escalate()`` quand aucun routage PAL initial n'est
    disponible (contexte résolu depuis l'event store, pas depuis ``route_seed_spec``).
    """
    agent = context.agent if context.agent in ("droid", "codex", "claude") else "codex"
    cost_score = {"droid": 1, "codex": 2, "claude": 3}.get(agent, 2)
    return PalRouteDecision(
        agent=agent,
        model=context.model or None,
        mode="single_agent",
        risk_score=0,
        complexity_score=0,
        cost_score=cost_score,
        reasons=(),
        escalation_history=(),
    )


def _run_generation(
    store: EventStore,
    evolution_id: str,
    source_run_id: str,
    context: SourceRunContext,
    generation: int,
    verification_config: dict[str, Any],
    *,
    previous_results: list[dict[str, str]] | None,
    history: list[dict[str, Any]],
    stream_events: bool,
) -> tuple[dict[str, Any], list[str], list[dict[str, str]]]:
    failing_results = (
        [result for result in previous_results if result["verdict"] != "pass"]
        if previous_results is not None
        else _collect_failing_results(store, source_run_id)
    )
    evolution_plan = _build_evolution_plan(failing_results, history, generation)
    prompt = _build_evolution_prompt(
        context,
        generation,
        failing_results,
        evolution_plan=evolution_plan,
        history=history,
    )
    request = CodingAgentRequest(
        run_id=evolution_id,
        spec_path=context.spec_path,
        run_directory=get_evolution_paths_from_id(store.path, evolution_id),
        agent=context.agent or "codex",
        model=context.model or context.agent or "codex",
        prompt=prompt,
    )
    _append_and_emit(
        store,
        evolution_id,
        "evolution.plan_mutated",
        evolution_plan,
        stream_events=stream_events,
    )
    if not context.agent_approved or context.agent is None or context.model is None:
        _append_and_emit(
            store,
            evolution_id,
            "evolution.agent_skipped",
            {"generation": generation, "reason": "no_approved_agent"},
            stream_events=stream_events,
        )
    else:
        _append_and_emit(
            store,
            evolution_id,
            "evolution.agent_started",
            {"generation": generation, "agent": context.agent, "model": context.model},
            stream_events=stream_events,
        )
        try:
            exit_code = run_coding_agent(request, stream_events=stream_events)
        except OSError as exc:
            exit_code = int(ExitCode.GENERIC_ERROR)
            error_summary = f"génération {generation} impossible à lancer: {exc}"
        else:
            error_summary = f"génération {generation} échouée"
        if exit_code == int(ExitCode.OK):
            _append_and_emit(
                store,
                evolution_id,
                "evolution.agent_completed",
                {"generation": generation, "agent": context.agent, "model": context.model},
                stream_events=stream_events,
            )
        else:
            _append_and_emit(
                store,
                evolution_id,
                "evolution.agent_failed",
                {
                    "generation": generation,
                    "agent": context.agent,
                    "model": context.model,
                    "exit_code": exit_code,
                },
                stream_events=stream_events,
            )
            escalation = escalate(
                _decision_from_context(context),
                exit_code,
                error_summary=error_summary,
            )
            _append_and_emit(
                store,
                evolution_id,
                "evolution.escalation",
                escalation.to_event_payload(),
                stream_events=stream_events,
            )
    results = _rerun_verification(
        store,
        evolution_id,
        context.spec_path,
        context.spec,
        verification_config,
        stream_events=stream_events,
    )
    failing_ids = sorted(result["id"] for result in results if result["verdict"] != "pass")
    candidate = {
        "name": evolution_id,
        "type": "acceptance-criteria",
        "payload": {
            "passed": sum(1 for result in results if result["verdict"] == "pass"),
            "failed": len(failing_ids),
            "criterion_ids": failing_ids,
        },
    }
    questions = [result["label"] for result in results if result["verdict"] != "pass"]
    return candidate, questions, results


def _rerun_verification(
    store: EventStore,
    evolution_id: str,
    spec_path: Path,
    spec: SeedSpec,
    config: dict[str, Any],
    *,
    stream_events: bool,
) -> list[dict[str, str]]:
    results: list[dict[str, str]] = []
    for index, criterion in enumerate(spec.success_criteria, start=1):
        references = references_for(index, criterion)
        commands = [
            command
            for command in spec.verification_commands
            if command_matches(command, references) or _is_global_verification(command)
        ]
        if not commands:
            results.append(
                {
                    "id": f"criterion_{index}",
                    "label": f"Critere {index}: {criterion}",
                    "verdict": "unverified",
                    "detail": "no verification_command linked to this criterion",
                }
            )
            continue
        proofs: list[ProofRecord] = []
        malformed_detail = ""
        for command in commands:
            try:
                proof = run_verification(command, spec_path.parent, config)
            except ValueError as exc:
                malformed_detail = f"malformed verification_command: {exc}"
                break
            _append_and_emit(
                store,
                evolution_id,
                "qa.verification_executed",
                proof.executed_event_payload(),
                stream_events=stream_events,
            )
            _append_and_emit(
                store,
                evolution_id,
                "qa.proof_collected",
                proof.proof_event_payload(),
                stream_events=stream_events,
            )
            proofs.append(proof)
        if malformed_detail:
            results.append(
                {
                    "id": f"criterion_{index}",
                    "label": f"Critere {index}: {criterion}",
                    "verdict": "fail",
                    "detail": malformed_detail,
                }
            )
        elif proofs:
            verdict = (
                "pass"
                if all(proof.exit_code == 0 and not proof.timed_out for proof in proofs)
                else "fail"
            )
            detail = "; ".join(
                f"{proof.command!r}: exit_code={proof.exit_code}, duration_ms={proof.duration_ms}"
                for proof in proofs
            )
            results.append(
                {
                    "id": f"criterion_{index}",
                    "label": f"Critere {index}: {criterion}",
                    "verdict": verdict,
                    "detail": detail,
                }
            )
    return results


def get_evolution_paths_from_id(event_store_path: Path, evolution_id: str) -> Path:
    return event_store_path.parent / "evolutions" / evolution_id


def _load_verification_config(mobius_home: Path) -> dict[str, Any]:
    config_path = mobius_home / "config.json"
    if not config_path.exists():
        return {}
    try:
        raw = json.loads(config_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}
    return dict(raw) if isinstance(raw, dict) else {}


def _is_global_verification(command: dict[str, Any]) -> bool:
    return str(command.get("scope", "")).strip().lower() in {"all", "global", "suite"}


def _append_and_emit(
    store: EventStore,
    evolution_id: str,
    event_type: str,
    payload: dict[str, object],
    *,
    stream_events: bool,
) -> None:
    append_and_emit(store, evolution_id, event_type, payload, stream_events=stream_events)


_write_pid = write_pid
_cleanup_pid = cleanup_pid


def _read_metadata(evolution_paths: EvolutionPaths) -> dict[str, object]:
    try:
        metadata = json.loads(evolution_paths.metadata_file.read_text(encoding="utf-8"))
    except OSError as exc:
        msg = f"evolution metadata not found for {evolution_paths.directory.name}: {exc}"
        raise EvolutionSourceNotFoundError(msg) from exc
    if not isinstance(metadata.get("source_run_id"), str) or not metadata.get("source_run_id"):
        msg = f"evolution metadata missing source_run_id for {evolution_paths.directory.name}"
        raise EvolutionSourceNotFoundError(msg)
    if not isinstance(metadata.get("generations"), int):
        msg = f"evolution metadata missing generations for {evolution_paths.directory.name}"
        raise EvolutionSourceNotFoundError(msg)
    return dict(metadata)


def _canonical_candidate(candidate: dict[str, Any]) -> str:
    return json.dumps(candidate, sort_keys=True, separators=(",", ":"))


def _normalize_question(question: str) -> str:
    return " ".join(question.strip().lower().rstrip("?").split())
