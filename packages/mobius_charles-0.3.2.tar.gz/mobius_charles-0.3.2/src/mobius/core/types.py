"""Shared process-level types used across Mobius layers."""

from __future__ import annotations

from enum import IntEnum


class ExitCode(IntEnum):
    """Documented Mobius process exit codes."""

    OK = 0
    GENERIC_ERROR = 1
    USAGE = 2
    VALIDATION = 3
    NOT_FOUND = 4
    INTERRUPTED = 130
