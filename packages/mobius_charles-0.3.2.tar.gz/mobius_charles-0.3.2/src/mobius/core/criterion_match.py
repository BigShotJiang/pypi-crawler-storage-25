"""Domain primitive: criterion-to-verification-command matching.

This module owns the single answer to whether a verification command covers a
success criterion. It lives in ``core`` so workflow, persistence, and optional
scoring layers can share the matcher without depending on each other.
"""

from __future__ import annotations

from collections.abc import Mapping
from typing import Any


def normalize_ref(value: object) -> str:
    """Return the canonical comparable form of any reference-shaped value."""
    return " ".join(str(value).strip().split()).lower()


def criterion_ref(index: int) -> str:
    """Return the canonical ``criterion_ref`` string written by Mobius producers."""
    return f"C{index}"


def references_for(
    index: int,
    criterion: str,
    *,
    criterion_id: str | None = None,
) -> set[str]:
    """Return the normalized union of every reference key that may match ``criterion``."""
    stripped = (criterion or "").strip()
    keys: set[str] = set()
    if index:
        keys.update(
            {
                str(index),
                f"criterion-{index}",
                f"criterion_{index}",
                f"success-{index}",
                f"sc-{index}",
                f"C{index}",
                f"c{index}",
            }
        )
    if stripped:
        keys.add(stripped)
        first_token = stripped.split(maxsplit=1)[0]
        if first_token:
            keys.add(first_token.rstrip(":.-—"))
    if criterion_id:
        keys.add(criterion_id)
    return {normalize_ref(key) for key in keys if key}


def command_matches(
    command: Mapping[str, Any],
    references: set[str],
    *,
    allow_substring: bool = False,
) -> bool:
    """Return whether ``command`` declares or implies coverage of ``references``."""
    raw_ref = command.get("criterion_ref")
    if raw_ref is None:
        raw_ref = command.get("criterion_refs")
    if raw_ref is None:
        raw_ref = command.get("criteria")
    if isinstance(raw_ref, list):
        if any(normalize_ref(item) in references for item in raw_ref):
            return True
    elif normalize_ref(raw_ref) in references:
        return True
    if not allow_substring:
        return False
    command_text = " ".join(str(value) for value in command.values()).lower()
    return any(reference in command_text for reference in references if len(reference) > 8)
