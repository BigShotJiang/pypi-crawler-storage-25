"""Shared core types and utilities for Mobius."""

