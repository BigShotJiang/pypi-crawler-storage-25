---
description: Composer un premier workflow avec l Interview Infinie v3a.
---

# /build

Use the Bash tool. Mobius is a local CLI and has no MCP server.

```text
Bash('mobius build "<idée>" --wizard --agent --skip-tour')
Bash('mobius build "<idée>" --wizard --agent --skip-tour --help')
```

Read the output before reporting success.
