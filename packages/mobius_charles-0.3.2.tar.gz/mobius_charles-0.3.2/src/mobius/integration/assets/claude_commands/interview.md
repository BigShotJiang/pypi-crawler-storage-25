---
description: Drive a Mobius project interview conversationally and record the spec.
---

# /interview

The public surface is still `mobius interview`; Mobius is a plain local CLI.
**Never** invoke Mobius via MCP.

## Current modes

- `mobius interview --mode quick` / `--non-interactive`: fast extraction into a
  valid `spec.yaml`.
- `mobius interview --mode deep`: local deterministic deep interview. It asks
  one question at a time, records a question ledger, applies the rhythm guard,
  prints scoring + second-opinion diagnostics on stderr, and writes a seed-ready
  spec only when the closure contract passes.

## InterviewHandoffContract

There is no separate workflow: `/interview` maps to the local `mobius interview` CLI.

Before claiming the interview is ready for `seed`, all of these must be true:

1. **Inspect workspace facts before questions** (`facts-before-questions`): workspace facts were inspected before asking avoidable questions.
2. Goal, constraints, success criteria, non-goals, decision boundaries, and
   brownfield context when applicable are present.
3. Success criteria are testable/observable.
4. The ambiguity floors pass.
5. The deterministic second opinion verdict is `pass`.
6. `closure_challenge.seed_ready=true` and `seed_ready=true` are visible in the
   command output/spec metadata.

If blocked, report the single highest-impact follow-up question emitted by
Mobius and do **not** claim seed readiness.

## Bash invocation

Quick/non-interactive handoff:

```text
Bash('mobius interview --non-interactive \
  --template <web|cli|lib|etl|mobile|docs|blank> \
  --project-type <greenfield|brownfield> \
  --goal "<one sentence>" \
  --constraint "<c1>" \
  --success-criterion "<s1>" \
  [--context "<existing>"] \
  --output spec.yaml')
```

Deep local interview:

```text
Bash('mobius interview --mode deep --output spec.yaml')
```

Then validate the generated spec:

```text
Bash('mobius seed spec.yaml --validate')
```
