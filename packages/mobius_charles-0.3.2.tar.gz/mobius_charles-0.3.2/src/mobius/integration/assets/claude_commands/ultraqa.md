---
description: Lancer QA puis Ralph borné si le verdict ne passe pas.
---

# /ultraqa

Use the Bash tool. Mobius is a local CLI and has no MCP server.

```text
Bash('mobius ultraqa latest')
Bash('mobius ultraqa latest --help')
```

Read the output before reporting success.
