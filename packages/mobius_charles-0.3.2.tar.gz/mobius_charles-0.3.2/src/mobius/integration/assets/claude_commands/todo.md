---
description: Gérer les tâches TODO locales du projet.
---

# /todo

Use the Bash tool. Mobius is a local CLI and has no MCP server.

```text
Bash('mobius todo ls')
Bash('mobius todo ls --help')
```

Read the output before reporting success.
