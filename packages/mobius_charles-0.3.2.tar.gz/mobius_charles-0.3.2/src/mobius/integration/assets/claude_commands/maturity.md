---
description: Inspecter le score de maturité déterministe v3a.
---

# /maturity

Use the Bash tool. Mobius is a local CLI and has no MCP server.

```text
Bash('mobius maturity spec.yaml')
Bash('mobius maturity spec.yaml --help')
```

Read the output before reporting success.
