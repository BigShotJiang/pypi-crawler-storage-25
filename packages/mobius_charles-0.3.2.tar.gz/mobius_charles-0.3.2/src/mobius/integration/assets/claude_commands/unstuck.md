---
description: Use Mobius lateral-thinking personas when work is blocked or looping.
---

# /unstuck

Use the `Bash` tool — **never** MCP. Mobius has no MCP server.

```text
Bash('mobius agent suggest <run_id>')
Bash('mobius agent suggest <run_id> --json')
Bash('mobius agent prompt <persona>')
```

If no run id is available, choose the persona from the visible blocker, load
the prompt with `mobius agent prompt <persona>`, and apply it to the current
problem.
