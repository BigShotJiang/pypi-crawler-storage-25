---
description: Run Mobius Ralph autonomous QA/evolve convergence.
---

# /ralph

Use the `Bash` tool — **never** MCP. Mobius has no MCP server.

```text
Bash('mobius ralph --from <run_id>')
Bash('mobius ralph --from <run_id> --max-iterations 10')
Bash('mobius ralph --from <run_id> --dry-run')
```

Ralph repeats local QA and one foreground evolution generation until QA passes, stagnation/convergence is detected, or the iteration cap is reached.
