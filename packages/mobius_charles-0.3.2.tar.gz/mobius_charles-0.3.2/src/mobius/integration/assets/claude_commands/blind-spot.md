---
description: Run Mobius blind-spot analysis against the current workspace or spec.
---

# /blind-spot

Use the `Bash` tool — **never** MCP. Mobius has no MCP server.

```text
Bash('mobius blind-spot')
Bash('mobius blind-spot --spec spec.yaml')
Bash('mobius blind-spot --json')
```

Use the report to challenge missing tests, vague scope, weak constraints, or
uncovered failure modes before a handoff.
