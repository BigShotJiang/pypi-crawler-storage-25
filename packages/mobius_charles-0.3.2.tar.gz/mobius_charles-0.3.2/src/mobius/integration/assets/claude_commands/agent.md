---
description: Lister/suggérer/appliquer des personas latérales.
---

# /agent

Use the Bash tool. Mobius is a local CLI and has no MCP server.

```text
Bash('mobius agent suggest latest')
Bash('mobius agent suggest latest --help')
```

Read the output before reporting success.
