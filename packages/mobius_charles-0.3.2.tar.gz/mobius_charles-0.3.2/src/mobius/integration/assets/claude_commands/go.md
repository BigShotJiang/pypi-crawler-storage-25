---
description: Chemin débutant idée -> spec -> seed -> run.
---

# /go

Use the Bash tool. Mobius is a local CLI and has no MCP server.

```text
Bash('mobius go "<idée>"')
Bash('mobius go "<idée>" --help')
```

Read the output before reporting success.
