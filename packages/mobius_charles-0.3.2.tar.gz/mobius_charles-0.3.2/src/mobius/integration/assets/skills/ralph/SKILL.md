---
name: ralph
description: Run the Mobius autonomous convergence loop until QA pass or stagnation.
---

# Ralph

## When to use

Use when a Mobius run needs autonomous follow-up: QA, one-generation evolve, repeat until pass, stagnation/convergence, or an iteration cap.

## How to invoke

Use the `Bash` tool — **never** MCP. Mobius has no MCP server.

```text
Bash('mobius ralph --from <run_id>')
Bash('mobius ralph --from <run_id> --max-iterations 10')
Bash('mobius ralph --from <run_id> --dry-run')
```

## Rules

- Start from an explicit run id when possible.
- Ralph runs locally and stops on QA pass, stagnation/convergence, max iterations, or missing run.
- If Ralph suggests a persona, use it as the next human-readable unblock direction.
