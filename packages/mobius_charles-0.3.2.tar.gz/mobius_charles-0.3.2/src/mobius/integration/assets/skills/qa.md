---
name: qa
description: Run the offline Mobius QA judge for a completed run.
---

# QA

Use the Bash tool. Mobius is a local CLI and has no MCP server.

```text
Bash('mobius qa <run_id>')
Bash('mobius qa <run_id> --json')
```

`--offline` is the default and uses deterministic local checks.
