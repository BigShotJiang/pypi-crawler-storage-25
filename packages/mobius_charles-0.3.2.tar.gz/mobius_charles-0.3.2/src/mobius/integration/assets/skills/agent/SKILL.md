---
name: agent
description: Lister/suggérer/appliquer des personas latérales.
---

# Agent

Use the Bash tool. Mobius is a local CLI and has no MCP server.

```text
Bash('mobius agent suggest latest')
Bash('mobius agent suggest latest --help')
```

Rules:
- Prefer `--json` only when the caller needs machine-readable output.
- For `latest`, verify the command supports it before relying on it.
- Do not claim success until the command output has been read.
