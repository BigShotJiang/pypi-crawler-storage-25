---
name: status
description: Inspect Mobius event-store status or a specific run.
---

# Status

Use the Bash tool. Mobius is a local CLI and has no MCP server.

```text
Bash('mobius status')
Bash('mobius status <run_id>')
Bash('mobius status <run_id> --json')
```

Use `--follow` only when the caller wants a live local stream.
