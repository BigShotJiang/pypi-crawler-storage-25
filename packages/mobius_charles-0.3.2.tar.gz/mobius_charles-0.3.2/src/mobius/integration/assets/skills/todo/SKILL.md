---
name: todo
description: Gérer les tâches TODO locales du projet.
---

# Todo

Use the Bash tool. Mobius is a local CLI and has no MCP server.

```text
Bash('mobius todo ls')
Bash('mobius todo ls --help')
```

Rules:
- Prefer `--json` only when the caller needs machine-readable output.
- For `latest`, verify the command supports it before relying on it.
- Do not claim success until the command output has been read.
