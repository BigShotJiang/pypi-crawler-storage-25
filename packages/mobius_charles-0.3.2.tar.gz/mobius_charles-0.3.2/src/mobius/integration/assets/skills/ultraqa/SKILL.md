---
name: ultraqa
description: Lancer QA puis Ralph borné si le verdict ne passe pas.
---

# Ultraqa

Use the Bash tool. Mobius is a local CLI and has no MCP server.

```text
Bash('mobius ultraqa latest')
Bash('mobius ultraqa latest --help')
```

Rules:
- Prefer `--json` only when the caller needs machine-readable output.
- For `latest`, verify the command supports it before relying on it.
- Do not claim success until the command output has been read.
