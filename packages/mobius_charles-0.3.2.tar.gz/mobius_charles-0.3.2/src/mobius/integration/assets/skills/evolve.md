---
name: evolve
description: Run the Mobius evolution loop from a prior run.
---

# Evolve

Use the Bash tool. Mobius is a local CLI and has no MCP server.

```text
Bash('mobius evolve --from <run_id>')
Bash('mobius evolve --from <run_id> --generations 3')
Bash('mobius evolve --from <run_id> --foreground')
```

Detached mode is the default unless foreground output is required.
