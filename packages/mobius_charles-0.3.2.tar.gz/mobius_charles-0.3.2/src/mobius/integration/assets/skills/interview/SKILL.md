---
name: interview
description: Drive the user through a Mobius project-discovery conversation using quick or deep CLI mode, then validate the resulting spec.
---

# Interview

Mobius does not call any LLM and has no MCP surface. For quick mode, **you**
(the agent) may hold the conversation and pass extracted parameters to
`mobius interview --non-interactive`. For deep mode, run the built-in local
adapter with `mobius interview --mode deep`; it asks one question at a time,
records a question ledger, applies the rhythm guard, prints scoring plus a
deterministic second opinion, and emits closure metadata.

> **Never** invoke Mobius via MCP. Mobius has no MCP server. Always use the
> `Bash` tool with the `mobius` shell command.

## When to use

Use whenever the user wants to start a new project (greenfield) or describe
an existing one (brownfield) for tracking. Typical triggers:

- "Help me set up this project."
- "I want to build X."
- "Use Mobius to track this work."
- "/interview" (slash command).

Do **not** use this skill to merely list `mobius` commands; use the `help`
skill for that.

## Step-by-step

### 1. Read the workspace

Before talking, scan the cwd to detect the project type. Mobius will
auto-detect with `detect_template`, but knowing the type up front lets you
ask better follow-ups.

| File found | Likely template |
| ---------- | --------------- |
| `package.json` | `web` |
| `Cargo.toml` | `cli` |
| `pyproject.toml` | `lib` |
| `pubspec.yaml` or `ios/`+`android/` | `mobile` |
| `mkdocs.yml` or `docs/index.md` | `docs` |
| `dbt_project.yml` or `airflow.cfg` | `etl` |
| nothing recognisable | `blank` (greenfield) |

If a manifest exists, read it (`Read package.json`, `Read Cargo.toml`, etc.)
to learn the project name, scripts, and existing dependencies. Reference
them in your follow-up questions instead of asking the user from scratch.

### 2. Hold the conversation

Ask, in your own words and at your own pace, until you have:

1. **Goal** — one sentence describing what the project should ship.
2. **Constraints** — invariants the work must respect (perf, deps, deploy
   target, regulatory, "no breaking changes", etc.).
3. **Success criteria** — testable outcomes. Push for measurable ones
   (Lighthouse ≥ 90, coverage ≥ 95%, p95 < 200ms…).
4. **Project type** — `greenfield` (new) or `brownfield` (existing).
5. **Non-goals** — what this first spec must not do.
6. **Decision boundaries** — when the agent must return to the human.
7. **(Brownfield only) context** — what existing system must be preserved.

Keep it conversational. Do not interrogate. Summarise back to the user
before moving to step 3.

### 3. Score clarity, then invoke `mobius interview`

Mobius itself stays offline and does not call an LLM. Before passing answers
to the CLI, **you** (the driving agent) must score the extracted brief using
the rubrics below. This is the core quality gate — a weak score here
produces a weak spec, which produces a weak QA verdict.

#### Scoring rubric (0–5 per dimension)

Score each dimension independently. Use the examples as anchors — if the
user's answer falls between two levels, round **down** (be strict).

##### Goal (floor: ≥ 4)

| Score | Description | Example |
|-------|-------------|---------|
| 0 | Missing or placeholder | `"tbd"`, `"something cool"` |
| 1 | Activity, not outcome | `"work on the backend"` |
| 2 | Outcome without user/value | `"build an API"` |
| 3 | Outcome + user OR value, not both | `"let users track habits"` (no success measure) |
| 4 | One shippable outcome, user + value clear | `"ship a habit tracker that shows streaks to daily users"` |
| 5 | Outcome + user + value + timeframe/scope | `"ship v1 habit tracker (web) with streak counting for beta testers by June"` |

##### Constraints (floor: ≥ 3)

| Score | Description | Example |
|-------|-------------|---------|
| 0 | None stated | (empty) |
| 1 | Only preferences, nothing non-negotiable | `"would be nice to use React"` |
| 2 | One real invariant but vague | `"must be fast"` |
| 3 | ≥1 concrete, testable invariant | `"deploy to Vercel, no server-side state"` |
| 4 | Multiple invariants covering different axes | `"Vercel deploy, <200ms p95, no new runtime deps"` |
| 5 | Invariants + explicit trade-offs | `"Vercel, <200ms p95, no new deps; willing to trade offline support for simplicity"` |

##### Success criteria (floor: ≥ 4)

| Score | Description | Example |
|-------|-------------|---------|
| 0 | None stated | (empty) |
| 1 | Subjective only | `"it works"`, `"looks good"` |
| 2 | Observable but not measurable | `"user can log in"` |
| 3 | Measurable but incomplete coverage | `"Lighthouse ≥ 90"` (one axis only) |
| 4 | ≥2 measurable criteria covering different axes | `"Lighthouse ≥ 90, auth e2e passes, deploy succeeds"` |
| 5 | Measurable + verification commands + edge cases | `"Lighthouse ≥ 90 (verify: npx lighthouse), auth e2e, error state for expired token"` |

##### Brownfield context (floor: ≥ 3, only when `project_type=brownfield`)

| Score | Description | Example |
|-------|-------------|---------|
| 0 | No context | `"unknown"`, `"it's complicated"` |
| 1 | System named but no boundary | `"we have a Rails app"` |
| 2 | System + vague boundary | `"Rails app, don't break the API"` |
| 3 | Integration boundary + preserved behavior named | `"Rails app, /api/v2/* endpoints must keep backward compat"` |
| 4 | Boundary + data contracts + known risks | `"Rails /api/v2/*, JSON schema in docs/api.json, risk: auth middleware is fragile"` |
| 5 | Full context: boundary + contracts + risks + tests | adds `"existing test suite: rspec spec/api/"` |

#### SeedCloserGate / closure challenge

The gate is **ready** when ALL conditions are met:

1. Goal/ambiguity floors pass
2. Constraints are present and concrete
3. Success criteria are testable/observable
4. Brownfield context is present when applicable
5. Non-goals are present
6. Decision boundaries are present
7. Deterministic `second_opinion.verdict` is `pass`
8. `closure_challenge.seed_ready=true`

If **any** dimension misses its floor:

1. Identify the weakest dimension
2. Ask **one** targeted follow-up — not a generic "can you clarify?"
3. Re-score after the answer
4. After 3 failed rounds on the same dimension, warn the user explicitly

#### Scoring output format

Before invoking `mobius interview`, output your scoring as a fenced block
so the user can see and contest your assessment:

```text
┌─────────────────────┬───────┬───────┬─────────────────────────────┐
│ Dimension           │ Score │ Floor │ Note                        │
├─────────────────────┼───────┼───────┼─────────────────────────────┤
│ Goal                │  4/5  │  ≥4   │ ✓ clear outcome + user      │
│ Constraints         │  3/5  │  ≥3   │ ✓ Vercel + no new deps      │
│ Success criteria    │  4/5  │  ≥4   │ ✓ Lighthouse + auth e2e     │
│ Brownfield context  │  n/a  │  ≥3   │ greenfield, skipped         │
├─────────────────────┼───────┼───────┼─────────────────────────────┤
│ SeedCloserGate      │ READY │       │ streak=2, all floors met    │
└─────────────────────┴───────┴───────┴─────────────────────────────┘
```

Do not add any Python LLM call; the agent-side scoring is the compromise.
Do not skip the scoring table — it is mandatory before every `mobius interview` invocation.

For quick mode, once the user confirms and the SeedCloserGate is ready, call:

```text
Bash('mobius interview --non-interactive \
  --template <web|cli|lib|etl|mobile|docs|blank> \
  --project-type <greenfield|brownfield> \
  --goal "<one sentence>" \
  --constraint "<constraint 1>" \
  --constraint "<constraint 2>" \
  --success-criterion "<criterion 1>" \
  --success-criterion "<criterion 2>" \
  [--context "<existing-system context>"] \
  --output spec.yaml')
```

Pass each constraint and each success criterion as its **own**
`--constraint` / `--success-criterion` flag. Quote values that contain
spaces. Mobius writes `spec.yaml` and a session id to stdout.

For deep mode, call:

```text
Bash('mobius interview --mode deep --output spec.yaml')
```

Deep stderr must show progress (`phase`, `question`, `routing_path`), a scoring
table, second opinion summary, and final `Next action: seed|clarify`. If the
next action is `clarify`, ask exactly the emitted highest-impact follow-up and
do not claim seed readiness.

### 4. Automatically validate seed, then drive `init` / `run`

After `mobius interview ... --output spec.yaml` succeeds and reports
`seed_ready=true`, do **not** stop at "next action". Immediately run:

```text
Bash('mobius seed spec.yaml --validate')
```

Then show the user both the `spec.yaml` path and the seed session id. Only
after seed validation succeeds should you offer or run the next actions:

```text
Bash('mobius init')          # scaffolds a workspace if needed
Bash('mobius run --spec spec.yaml')
Bash('mobius status <run_id> --follow')
```

## Worked example

User: *"I want to build a Next.js dashboard for tracking sales, with auth.
Deploys to Vercel. Must hit Lighthouse 90+."*

You inspect the cwd, find a `package.json` with `"next"`, ask one
follow-up ("Any auth provider preference?"), then call:

```text
Bash('mobius interview --non-interactive \
  --template web \
  --project-type greenfield \
  --goal "Ship a Next.js sales dashboard with auth deployed to Vercel" \
  --constraint "Deploy target is Vercel" \
  --constraint "Use NextAuth.js for authentication" \
  --success-criterion "Lighthouse score >= 90 on the dashboard route" \
  --success-criterion "Auth flow works end-to-end" \
  --success-criterion "Vercel preview deploy succeeds" \
  --output spec.yaml')
```

## What NOT to do

- Do **not** call any MCP tool. Mobius is a plain CLI.
- Do **not** pass a flat `--constraint "a, b, c"` — repeat the flag.
- Do **not** invent a fixture YAML file unless the user explicitly asks for
  one — `--goal/--constraint/--success-criterion` is the default agent path.
- Do **not** skip the conversation and go straight to invoking the CLI; the
  whole point is that you elicit the spec from the user.
- Do **not** stop after writing `spec.yaml` when the SeedCloserGate is ready;
  automatically run `mobius seed spec.yaml --validate` and report the seed id.
