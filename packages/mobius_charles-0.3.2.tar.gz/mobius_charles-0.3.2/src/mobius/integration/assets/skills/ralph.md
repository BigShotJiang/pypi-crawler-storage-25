---
name: ralph
description: Run the Mobius QA and evolve convergence loop.
---

# Ralph

Use the Bash tool. Mobius is a local CLI and has no MCP server.

```text
Bash('mobius ralph --from <run_id>')
Bash('mobius ralph --from <run_id> --max-iterations 10')
Bash('mobius ralph --from <run_id> --dry-run')
```

Read the stop reason and next command before reporting the result.
