---
name: blind-spot
description: Detect project blind spots that the current spec or QA pass may be missing.
---

# Blind Spot

## When to use

Use when the user asks what is missing, wants a pre-merge audit, or a QA
pass looks green but the project still needs adversarial review.

## How to invoke

```text
Bash('mobius blind-spot')
Bash('mobius blind-spot --spec spec.yaml')
Bash('mobius blind-spot --json')
```

After reading the report, use `mobius agent prompt <persona>` if a finding
needs a focused challenge persona.

## Rules

- Always use the `Bash` tool. Mobius has **no MCP server**.
- Pass user-supplied flags through verbatim using shell quoting.
