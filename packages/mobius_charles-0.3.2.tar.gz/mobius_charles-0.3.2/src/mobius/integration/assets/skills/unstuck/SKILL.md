---
name: unstuck
description: "Débloquer avec des personas de pensée latérale quand evolve tourne en rond."
---

# Unstuck

Mobius n'appelle aucun LLM. **Toi, l'agent**, adoptes la persona recommandée; Mobius fournit la logique de sélection déterministe via `mobius agent suggest`.

> Ne jamais invoquer Mobius via MCP. Mobius n'a pas de serveur MCP.

## Quand l'utiliser

Utilise cette skill quand :
- L'utilisateur dit « je suis bloqué », « ça tourne en rond », « ça avance pas »
- Une boucle evolve stagne (oscillation, feedback répétitif)
- L'approche actuelle ne fonctionne visiblement pas

## Personas disponibles

| Persona | Style | Quand |
|---------|-------|-------|
| **contrarian** | « On résout le bon problème ? » | Hypothèses à challenger |
| **hacker** | « Fais marcher d'abord » | Paralysie d'analyse |
| **simplifier** | « Coupe au minimum absolu » | Complexité écrasante |
| **researcher** | « Arrête de coder, investigue » | Information manquante |
| **architect** | « Remets en question les fondations » | Problème structurel |

## Workflow

1. Si un run_id est connu, demande la suggestion :
   ```text
   Bash('mobius agent suggest <run_id>')
   Bash('mobius agent suggest <run_id> --json')
   ```

2. Sinon, choisis la persona selon le contexte de la conversation :
   - Même erreur en boucle → **contrarian**
   - Trop d'options → **simplifier**
   - Information manquante → **researcher**
   - Design cassé → **architect**
   - Bloquer partout → **hacker**

3. Charge le prompt de la persona :
   ```text
   Bash('mobius agent prompt <persona>')
   ```

4. Adopte la persona et applique son approche au problème courant.

5. Propose des actions concrètes utilisant les commandes Mobius :
   - Modifier la spec → `mobius interview`
   - Relancer un run → `mobius run --spec spec.yaml`
   - Vérifier l'état → `mobius status <run_id>`

## Règles

- Toujours utiliser l'outil `Bash`. Mobius n'a **pas de serveur MCP**.
- Préserver les flags fournis par l'utilisateur et citer correctement les valeurs shell.
