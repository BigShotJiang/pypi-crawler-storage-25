---
name: go
description: Chemin débutant idée -> spec -> seed -> run.
---

# Go

Use the Bash tool. Mobius is a local CLI and has no MCP server.

```text
Bash('mobius go "<idée>"')
Bash('mobius go "<idée>" --help')
```

Rules:
- Prefer `--json` only when the caller needs machine-readable output.
- For `latest`, verify the command supports it before relying on it.
- Do not claim success until the command output has been read.
