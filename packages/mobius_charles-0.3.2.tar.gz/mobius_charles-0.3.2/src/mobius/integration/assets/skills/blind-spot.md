---
name: blind-spot
description: Run Mobius blind-spot analysis for adversarial project review.
---

# Blind Spot

Use the Bash tool. Mobius is a local CLI and has no MCP server.

```text
Bash('mobius blind-spot')
Bash('mobius blind-spot --spec spec.yaml')
Bash('mobius blind-spot --json')
```

Use the report to challenge missing tests, weak constraints, and uncovered failure modes.
