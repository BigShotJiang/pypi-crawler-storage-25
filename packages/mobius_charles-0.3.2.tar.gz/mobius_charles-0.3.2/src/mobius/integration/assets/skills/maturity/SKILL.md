---
name: maturity
description: Inspecter le score de maturité déterministe v3a.
---

# Maturity

Use the Bash tool. Mobius is a local CLI and has no MCP server.

```text
Bash('mobius maturity spec.yaml')
Bash('mobius maturity spec.yaml --help')
```

Rules:
- Prefer `--json` only when the caller needs machine-readable output.
- For `latest`, verify the command supports it before relying on it.
- Do not claim success until the command output has been read.
