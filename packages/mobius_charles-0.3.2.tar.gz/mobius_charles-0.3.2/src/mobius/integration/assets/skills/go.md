---
name: go
description: Start the Mobius idea to spec to run path.
---

# Go

Use the Bash tool. Mobius is a local CLI and has no MCP server.

```text
Bash('mobius go "<idea>"')
Bash('mobius go "<idea>" --help')
```

Read the command output before reporting success.
