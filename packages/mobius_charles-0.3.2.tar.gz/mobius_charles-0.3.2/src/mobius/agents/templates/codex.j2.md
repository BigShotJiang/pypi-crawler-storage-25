# Brief d’exécution Codex

<OBJECTIF>
$goal

<CRITÈRES>
$criteria

<COMMANDES>
$commands

<RISQUES>
$risks

<CONTRAINTES>
$constraints
$instructions_section
$persona_section
