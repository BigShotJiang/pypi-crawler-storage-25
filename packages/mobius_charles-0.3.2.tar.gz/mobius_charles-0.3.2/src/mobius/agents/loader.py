"""Chargeur de prompts de personas — source unique pour tous les prompts système.

Charge les fichiers .md avec une stratégie de résolution à 3 niveaux :

1. Répertoire projet-local ``.mobius/agents/`` dans le répertoire courant
2. Variable d'environnement ``MOBIUS_AGENTS_DIR`` — répertoire d'override utilisateur
3. ``importlib.resources`` — prompts embarqués dans le package
"""

from __future__ import annotations

import functools
import importlib.resources
import os
import re
from dataclasses import dataclass
from pathlib import Path

PERSONAS = ("contrarian", "hacker", "simplifier", "researcher", "architect")


def _is_safe_path(path: Path, parent: Path) -> bool:
    """Vérifier qu'un chemin résolu reste sous le répertoire parent (anti-symlink escape)."""
    try:
        resolved = path.resolve(strict=True)
        return str(resolved).startswith(str(parent.resolve()))
    except OSError:
        return False


@functools.lru_cache(maxsize=32)
def _resolve_persona_path(name: str, _cwd: str = "") -> Path | None:
    """Trouver un fichier .md de persona via la stratégie d'override à 3 niveaux."""
    filename = f"{name}.md"
    project_dir = Path(_cwd or Path.cwd()) / ".mobius" / "agents"
    if project_dir.is_dir():
        path = project_dir / filename
        if path.exists() and _is_safe_path(path, project_dir):
            return path
    agents_dir = os.environ.get("MOBIUS_AGENTS_DIR")
    if agents_dir:
        env_dir = Path(agents_dir)
        path = env_dir / filename
        if path.exists() and _is_safe_path(path, env_dir):
            return path
    return None


@functools.lru_cache(maxsize=32)
def load_persona(name: str) -> str:
    """Charger le contenu markdown complet d'une persona.

    Args:
        name: Identifiant de la persona, ex. ``"contrarian"``.

    Returns:
        Texte markdown complet.

    Raises:
        FileNotFoundError: Si le fichier .md est introuvable.
    """
    _validate_name(name)
    path = _resolve_persona_path(name, str(Path.cwd()))
    if path is not None:
        return path.read_text(encoding="utf-8")

    package = importlib.resources.files("mobius.agents.personas")
    resource = package.joinpath(f"{name}.md")
    try:
        return resource.read_text(encoding="utf-8")
    except (FileNotFoundError, TypeError):
        raise FileNotFoundError(
            f"Persona introuvable : {name}.md "
            f"(cherché dans MOBIUS_AGENTS_DIR et mobius.agents.personas)"
        ) from None


def load_section(name: str, section: str) -> str:
    """Extraire une section ``## <section>`` d'un fichier de persona."""
    content = load_persona(name)
    return extract_section(content, section)


def list_personas() -> tuple[str, ...]:
    """Retourner les noms de toutes les personas disponibles (embarquées + projet)."""
    names: set[str] = set(PERSONAS)
    project_dir = Path.cwd() / ".mobius" / "agents"
    if project_dir.is_dir():
        for md in project_dir.glob("*.md"):
            names.add(md.stem)
    agents_dir = os.environ.get("MOBIUS_AGENTS_DIR")
    if agents_dir:
        env_path = Path(agents_dir)
        if env_path.is_dir():
            for md in env_path.glob("*.md"):
                names.add(md.stem)
    return tuple(sorted(names))


def clear_cache() -> None:
    """Vider le cache des prompts. Utile pour les tests."""
    load_persona.cache_clear()
    _resolve_persona_path.cache_clear()


def extract_section(content: str, section: str) -> str:
    """Extraire tout entre ``## <section>`` et le prochain ``##``."""
    lines = content.split("\n")
    pattern = re.compile(rf"^##\s+{re.escape(section)}\s*$", re.IGNORECASE)

    start: int | None = None
    for i, line in enumerate(lines):
        if pattern.match(line.strip()):
            start = i + 1
            break
    if start is None:
        raise KeyError(f"Section '## {section}' introuvable")

    end = len(lines)
    for i in range(start, len(lines)):
        if lines[i].strip().startswith("## "):
            end = i
            break

    return "\n".join(lines[start:end]).strip()


def extract_questions(name: str) -> tuple[str, ...]:
    """Extraire les questions (lignes ``- item``) de la section TES QUESTIONS."""
    section = load_section(name, "TES QUESTIONS")
    items: list[str] = []
    for line in section.split("\n"):
        stripped = line.strip()
        if stripped.startswith("- "):
            items.append(stripped[2:].strip())
    return tuple(items)


@dataclass(frozen=True, slots=True)
class PersonaData:
    """Données parsées d'un fichier .md de persona."""

    name: str
    philosophy: str
    questions: tuple[str, ...]


def load_persona_data(name: str) -> PersonaData:
    """Charger et parser un fichier .md de persona."""
    content = load_persona(name)

    lines = content.split("\n")
    philosophy_lines: list[str] = []
    past_title = False
    for line in lines:
        if line.startswith("# ") and not past_title:
            past_title = True
            continue
        if line.startswith("## "):
            break
        if past_title and line.strip():
            philosophy_lines.append(line.strip())

    return PersonaData(
        name=name,
        philosophy=" ".join(philosophy_lines),
        questions=extract_questions(name),
    )


def _validate_name(name: str) -> None:
    if name not in list_personas():
        raise FileNotFoundError(
            f"Persona inconnue : {name}. Personas disponibles : {', '.join(list_personas())}"
        )
