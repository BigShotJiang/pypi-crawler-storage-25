"""Prompts de personas de pensée latérale embarqués dans le package."""
