"""v3a projection updaters and one explicit registration entry point.

The four updater classes below observe v3a-specific event prefixes
(``interview.``, ``phase.``, ``scoring.``, ``human.``,
``spec.maturity_overridden``) and update the projection snapshot used
by ``mobius hud`` and downstream readers.

Registration happens *only* through :func:`register_v3a_projections`.
There are no module-level side effects, so importing this file is
cheap and the caller (``mobius build``) decides exactly when v3a's
observers attach to the projection registry.

Tests pass a plain ``dict`` as the registry — the production
:func:`mobius.persistence.projections.register_projection` already
accepts an injectable registry, so no extra adapter is needed.
"""

from __future__ import annotations

from collections.abc import Mapping
from typing import Any

from mobius.persistence.event_store import EventRecord
from mobius.persistence.projections import (
    ProjectionRegistry,
    ProjectionUpdater,
    register_projection,
)


class InterviewProjection:
    """Track the latest v3a interview progress in the projection cache."""

    def update_snapshot(
        self,
        event: EventRecord,
        current_snapshot: dict[str, Any],
    ) -> dict[str, Any]:
        """Return an updated snapshot for an interview event."""
        snapshot = dict(current_snapshot)
        interview = dict(snapshot.get("v3a_interview", {}))
        payload = event.payload_data if isinstance(event.payload_data, dict) else {}
        interview["last_event_type"] = event.type
        interview["last_event_at"] = event.created_at
        if event.type == "interview.transcript_appended":
            interview["turn"] = payload.get("turn")
            interview["transcript"] = payload.get("transcript")
        elif event.type in {"interview.lemma_check_passed", "interview.lemma_check_blocked"}:
            interview["last_lemma_check"] = event.type.removeprefix("interview.lemma_check_")
        snapshot["v3a_interview"] = interview
        return snapshot


class PhaseRouterProjection:
    """Track the latest v3a phase-router state in the projection cache."""

    def update_snapshot(
        self,
        event: EventRecord,
        current_snapshot: dict[str, Any],
    ) -> dict[str, Any]:
        """Return an updated snapshot for a phase-router event."""
        snapshot = dict(current_snapshot)
        phase_state = dict(snapshot.get("v3a_phase", {}))
        payload = event.payload_data if isinstance(event.payload_data, dict) else {}
        phase_state["last_event_type"] = event.type
        phase_state["last_event_at"] = event.created_at
        if event.type == "phase.entered":
            phase_state["current_phase"] = payload.get("phase")
            phase_state["current_phase_index"] = payload.get("phase_index")
        elif event.type == "phase.completed":
            phase_state["last_completed_phase"] = payload.get("phase")
            phase_state["last_completed_phase_index"] = payload.get("phase_index")
            phase_state["last_summary"] = payload.get("summary")
        elif event.type == "phase.proposed_next":
            phase_state["next_phase"] = payload.get("next_phase")
            phase_state["next_command"] = payload.get("next_command")
        snapshot["v3a_phase"] = phase_state
        return snapshot


class ScoringProjection:
    """Track the latest v3a score state in the projection cache."""

    def update_snapshot(
        self,
        event: EventRecord,
        current_snapshot: dict[str, Any],
    ) -> dict[str, Any]:
        """Return an updated snapshot for a scoring event."""
        snapshot = dict(current_snapshot)
        scoring = dict(snapshot.get("v3a_scoring", {}))
        payload = event.payload_data if isinstance(event.payload_data, dict) else {}
        scoring["last_event_type"] = event.type
        scoring["last_event_at"] = event.created_at
        if event.type == "scoring.mechanical_computed":
            scoring["mechanical"] = payload.get("breakdown")
        elif event.type == "scoring.llm_judgment_started":
            scoring["llm_status"] = "started"
            scoring["llm_dimensions"] = payload.get("dimensions")
        elif event.type == "scoring.llm_judgment_completed":
            scoring["llm_status"] = "completed"
            scoring["llm"] = payload.get("breakdown")
        elif event.type == "scoring.final_computed":
            scoring["score_out_of_10"] = payload.get("score_out_of_10")
            scoring["score_rationale"] = payload.get("score_rationale")
            scoring["score_breakdown"] = payload.get("score_breakdown")
        snapshot["v3a_scoring"] = scoring
        return snapshot


class AuditProjection:
    """Track v3a audit events such as maturity overrides."""

    def update_snapshot(
        self,
        event: EventRecord,
        current_snapshot: dict[str, Any],
    ) -> dict[str, Any]:
        """Return an updated snapshot for an audit event."""
        snapshot = dict(current_snapshot)
        audit = dict(snapshot.get("v3a_audit", {}))
        events = list(audit.get("events", []))
        payload = event.payload_data if isinstance(event.payload_data, dict) else {}
        events.append(
            {
                "event_type": event.type,
                "aggregate_id": event.aggregate_id,
                "created_at": event.created_at,
                "reason": payload.get("reason"),
                "maturity_score": payload.get("maturity_score"),
            }
        )
        audit["events"] = events[-50:]
        audit["last_event_type"] = event.type
        audit["last_reason"] = payload.get("reason")
        audit["last_maturity_score"] = payload.get("maturity_score")
        snapshot["v3a_audit"] = audit
        return snapshot


_V3A_PROJECTIONS: tuple[tuple[str, ProjectionUpdater], ...] = (
    ("interview.", InterviewProjection()),
    ("phase.", PhaseRouterProjection()),
    ("scoring.", ScoringProjection()),
    ("human.", AuditProjection()),
    ("spec.maturity_overridden", AuditProjection()),
)


def register_v3a_projections(
    registry: ProjectionRegistry | None = None,
) -> Mapping[str, ProjectionUpdater]:
    """Attach v3a updaters to ``registry`` (or the production default).

    Returns the prefix → updater mapping that was attached, so callers
    and tests can introspect what was registered.
    """
    attached: dict[str, ProjectionUpdater] = {}
    for prefix, updater in _V3A_PROJECTIONS:
        register_projection(prefix, updater, registry=registry)
        attached[prefix] = updater
    return attached
