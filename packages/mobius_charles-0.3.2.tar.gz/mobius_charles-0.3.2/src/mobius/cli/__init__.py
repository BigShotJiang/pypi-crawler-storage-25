"""CLI entry point exports with fast paths for release latency budgets."""

from __future__ import annotations

import sys
from typing import TYPE_CHECKING, Any, NoReturn, cast

from mobius.event_schema import (
    BOOTSTRAP_AGGREGATE_ID,
    BOOTSTRAP_EVENT_ID,
    BOOTSTRAP_EVENT_TYPE,
    BOOTSTRAP_SQL,
    LATEST_SCHEMA_VERSION,
    MIGRATIONS,
    bootstrap_payload,
)

if TYPE_CHECKING:
    from pathlib import Path
    from sqlite3 import Connection as SQLiteConnection


class _LazyModuleProxy:
    def __init__(self, module_name: str) -> None:
        self._module_name = module_name

    def __getattr__(self, name: str) -> Any:
        import importlib

        module = importlib.import_module(self._module_name)
        return getattr(module, name)


sqlite3 = _LazyModuleProxy("sqlite3")


def main() -> None:
    """Run Mobius, using lightweight fast paths before importing Typer/Rich."""
    argv = sys.argv[1:]
    try:
        if _try_fast_path(argv):
            return

        from mobius.cli.main import main as typer_main

        typer_main()
    except OSError as exc:
        _exit_with_state_dir_error(exc)


def _exit_with_state_dir_error(exc: OSError) -> NoReturn:
    """Translate a state-directory I/O error into a friendly exit message."""
    import os
    from pathlib import Path

    mobius_home = os.environ.get("MOBIUS_HOME") or str(Path.home() / ".mobius")
    reason = exc.strerror or exc.__class__.__name__
    sys.stderr.write(
        f"impossible de créer le répertoire d’état Mobius à {mobius_home}: {reason}\n"
        "Définir MOBIUS_HOME vers un répertoire inscriptible puis réessayer.\n"
    )
    raise SystemExit(1) from exc


def _sqlite3() -> Any:
    return sqlite3


def _try_fast_path(argv: list[str]) -> bool:
    if argv in (["--help"], ["-h"]):
        _write_fast_help()
        return True
    if argv == ["--version"]:
        from mobius import __version__

        sys.stdout.write(f"mobius {__version__}\n")
        return True
    if argv == ["cold-start"]:
        _run_fast_cold_start()
        return True
    if _try_fast_store_status(argv):
        return True
    return bool(_try_fast_status(argv))


def _write_fast_help() -> None:
    sys.stdout.write(
        """Usage: mobius [OPTIONS] COMMAND [ARGS]...

CLI de workflow rapide, sans MCP.

Options:
  --json     Émettre du JSON lisible par machine pour les commandes compatibles.
  --version  Afficher la version de Mobius et quitter.
  -h, --help Afficher ce message et quitter.

Commandes:
  build      Composer un premier workflow avec l'Interview Infinie v3a.
  go         Chemin débutant: idée -> spec -> seed -> run en une commande.
  init       Créer un nouveau workspace Mobius à PATH.
  interview  Lancer l’entretien projet et produire une spec.
  seed       Créer une session seed depuis une spec projet ou une session interview.
  run        Exécuter une spec seed Mobius.
  status     Afficher le statut de l’event store Mobius.
  qa         Exécuter les contrôles QA déterministes pour un run Mobius.
  ultraqa    QA puis boucle de correction Ralph bornée si besoin.
  unstuck    Débloquer un projet avec une seule persona recommandée.
  agent      Personas de pensée latérale pour débloquer un projet.
  ralph      Boucle persistante: QA -> evolve jusqu'à pass ou stop.
  cancel     Annuler un run Mobius détaché.
  evolve     Lancer une boucle d’évolution de génération Mobius.
  lineage    Afficher l’arbre de lineage d’un agrégat ou son hash de replay.
  maturity   Inspecter le score de maturité déterministe v3a.
  setup      Installer ou retirer les assets d’intégration agent Mobius.
  config     Afficher, lire et définir la configuration Mobius.
  todo       Gérer les tâches TODO du projet.
  v3a        Sous-commandes v3a avancées.
  cold-start Mesurer la médiane de démarrage à froid de `mobius --help` sur 5 exécutions.
"""
    )


def _run_fast_cold_start() -> None:
    """Measure the fast-path ``mobius --help`` median without importing Typer."""
    import os
    import statistics
    import subprocess
    import time

    command = [sys.argv[0], "--help"]
    env = dict(os.environ)
    env["NO_COLOR"] = "1"
    samples_ms: list[float] = []
    for _ in range(5):
        started = time.perf_counter()
        result = subprocess.run(
            command,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.PIPE,
            text=True,
            check=False,
            env=env,
        )
        elapsed_ms = (time.perf_counter() - started) * 1000
        if result.returncode != 0:
            sys.stderr.write(result.stderr)
            raise SystemExit(result.returncode)
        samples_ms.append(elapsed_ms)
    median_ms = statistics.median(samples_ms)
    formatted = ", ".join(f"{sample:.1f}" for sample in samples_ms)
    sys.stdout.write(f"cold_start median_ms={median_ms:.1f} samples_ms=[{formatted}]\n")
    if median_ms > 100:
        raise SystemExit(1)


def _try_fast_store_status(argv: list[str]) -> bool:
    import json
    import os
    from pathlib import Path

    """Fast path for ``mobius status`` with no run id (store-level status).

    This path avoids importing rich, pydantic, and workflow modules. It only
    runs when the schema_migrations table already contains the latest version,
    so the slow path (which applies migrations) is still reached on first
    invocation or when the migrations row is missing.
    """
    json_output = False
    remaining = list(argv)
    if remaining and remaining[0] == "--json":
        json_output = True
        remaining.pop(0)
    if remaining != ["status"] and remaining != ["status", "--json"]:
        return False
    options = remaining[1:]
    if "--json" in options:
        json_output = True
        options.remove("--json")
    if options:
        return False

    mobius_home = Path(os.environ.get("MOBIUS_HOME", str(Path.home() / ".mobius"))).expanduser()
    db_path = mobius_home / "events.db"

    if not db_path.exists():
        # Bootstrap the store inline so first-run still hits the fast budget.
        try:
            _fast_bootstrap_store(mobius_home, db_path)
        except (OSError, _sqlite3().Error):
            return False

    try:
        connection = _connect(db_path, read_only=True)
    except _sqlite3().Error:
        return False
    try:
        try:
            row = connection.execute(
                "SELECT count(*) FROM schema_migrations WHERE version = ?",
                (LATEST_SCHEMA_VERSION,),
            ).fetchone()
        except _sqlite3().Error:
            return False
        if row is None or int(row[0]) == 0:
            return False
        migration_count = connection.execute("SELECT count(*) FROM schema_migrations").fetchone()
        event_count = connection.execute("SELECT count(*) FROM events").fetchone()
        integrity_row = connection.execute("PRAGMA integrity_check").fetchone()
    finally:
        connection.close()

    integrity_check = str(integrity_row[0]) if integrity_row is not None else ""
    migrations_applied = int(migration_count[0]) > 0
    payload = {
        "event_store": str(db_path),
        "read_only": False,
        "migrations_applied": migrations_applied,
        "integrity_check": integrity_check,
        "event_count": int(event_count[0]),
    }
    if json_output:
        sys.stdout.write(json.dumps(payload, separators=(",", ":")) + "\n")
        return True
    sys.stdout.write(
        f"event_store={payload['event_store']}\n"
        f"read_only={str(payload['read_only']).lower()}\n"
        f"migrations_applied={str(payload['migrations_applied']).lower()}\n"
        f"integrity_check={payload['integrity_check']}\n"
        f"event_count={payload['event_count']}\n"
    )
    return True


def _try_fast_status(argv: list[str]) -> bool:
    import json
    import os
    from pathlib import Path

    json_output = False
    remaining = list(argv)
    if remaining and remaining[0] == "--json":
        json_output = True
        remaining.pop(0)
    if not remaining or remaining[0] != "status":
        return False
    options = remaining[1:]
    if "--follow" in options or "--read-only" in options or "-h" in options or "--help" in options:
        return False
    if "--json" in options:
        json_output = True
        options.remove("--json")
    if len(options) != 1 or options[0].startswith("-"):
        return False

    run_id = options[0]
    mobius_home = Path(os.environ.get("MOBIUS_HOME", str(Path.home() / ".mobius"))).expanduser()
    db_path = mobius_home / "events.db"
    if not db_path.exists():
        _raise_fast_not_found(run_id)

    inspector = _fast_session_inspector(mobius_home, db_path)
    try:
        resolved_run_id = inspector.resolve_run_id(run_id)
    except _sqlite3().Error as exc:
        sys.stderr.write(f"status failed: {exc}\n")
        raise SystemExit(1) from exc
    if resolved_run_id is None:
        _raise_fast_not_found(run_id)
    if not isinstance(resolved_run_id, str):
        candidates = ", ".join(resolved_run_id)
        sys.stderr.write(f"préfixe de run ambigu : {run_id}; candidats : {candidates}\n")
        raise SystemExit(2)
    run_id = resolved_run_id

    inspector.mark_stale_session_if_needed(run_id)
    try:
        run_status = inspector.read_run_status(run_id)
    except _sqlite3().Error as exc:
        sys.stderr.write(f"status failed: {exc}\n")
        raise SystemExit(1) from exc
    if run_status is None:
        _raise_fast_not_found(run_id)

    payload = run_status.to_payload()
    if json_output:
        sys.stdout.write(json.dumps(payload, separators=(",", ":")) + "\n")
        return True
    sys.stdout.write(
        f"# Run {payload['run_id']}\n\n"
        "| Champ | Valeur |\n"
        "| --- | --- |\n"
        f"| État | {payload['state']} |\n"
        f"| Démarré à | {payload['started_at']} |\n"
        f"| Dernier événement à | {payload['last_event_at']} |\n"
    )
    return True


def _fast_session_inspector(mobius_home: Path, db_path: Path) -> Any:
    from mobius.cli.session_inspector import SessionInspector, SQLiteSessionAdapter

    return SessionInspector(
        state_dir=mobius_home,
        adapter=SQLiteSessionAdapter(
            db_path,
            connect=lambda path, read_only: _connect(path, read_only=read_only),
            now=_iso8601_utc_now,
            canonical_json=_canonical_json,
        ),
    )


def _fast_bootstrap_store(mobius_home: Path, db_path: Path) -> None:
    """Create the event store and apply the initial migration without imports."""
    import os

    mobius_home.mkdir(parents=True, exist_ok=True, mode=0o700)
    os.chmod(mobius_home, 0o700)
    sqlite3 = _sqlite3()
    connection = sqlite3.connect(db_path, timeout=30.0, isolation_level=None)
    try:
        os.chmod(db_path, 0o600)
        connection.execute("PRAGMA busy_timeout=30000")
        connection.execute("PRAGMA journal_mode=WAL")
        connection.execute("PRAGMA synchronous=NORMAL")
        connection.execute("PRAGMA foreign_keys=ON")
        connection.executescript(BOOTSTRAP_SQL)
        applied_at = _iso8601_utc_now()
        for migration in MIGRATIONS:
            connection.execute(
                "INSERT OR REPLACE INTO schema_migrations(version, applied_at) VALUES (?, ?)",
                (migration.version, applied_at),
            )
        payload = bootstrap_payload()
        connection.execute("BEGIN IMMEDIATE")
        try:
            connection.execute(
                """
                INSERT OR IGNORE INTO events(
                    event_id, aggregate_id, sequence, type, payload, created_at
                )
                VALUES (?, ?, ?, ?, ?, ?)
                """,
                (
                    BOOTSTRAP_EVENT_ID,
                    BOOTSTRAP_AGGREGATE_ID,
                    1,
                    BOOTSTRAP_EVENT_TYPE,
                    payload,
                    applied_at,
                ),
            )
            connection.execute(
                """
                INSERT INTO aggregates(aggregate_id, type, last_sequence, snapshot, updated_at)
                VALUES (?, ?, ?, ?, ?)
                ON CONFLICT(aggregate_id) DO UPDATE SET
                    type = excluded.type,
                    last_sequence = MAX(aggregates.last_sequence, excluded.last_sequence),
                    updated_at = excluded.updated_at
                """,
                (BOOTSTRAP_AGGREGATE_ID, BOOTSTRAP_EVENT_TYPE, 1, "{}", applied_at),
            )
        except BaseException:
            connection.execute("ROLLBACK")
            raise
        else:
            connection.execute("COMMIT")
    finally:
        connection.close()


def _connect(db_path: Path, *, read_only: bool) -> SQLiteConnection:
    sqlite3 = _sqlite3()
    if read_only:
        connection = sqlite3.connect(
            f"file:{db_path}?mode=ro",
            uri=True,
            timeout=30.0,
            isolation_level=None,
        )
    else:
        connection = sqlite3.connect(db_path, timeout=30.0, isolation_level=None)
        connection.execute("PRAGMA journal_mode=WAL")
    connection.row_factory = sqlite3.Row
    connection.execute("PRAGMA busy_timeout=30000")
    connection.execute("PRAGMA synchronous=NORMAL")
    connection.execute("PRAGMA foreign_keys=ON")
    return cast("SQLiteConnection", connection)


def _canonical_json(payload: dict[str, object]) -> str:
    import json

    return json.dumps(payload, sort_keys=True, separators=(",", ":"))


def _iso8601_utc_now() -> str:
    from datetime import UTC, datetime

    return datetime.now(UTC).isoformat(timespec="microseconds").replace("+00:00", "Z")


def _raise_fast_not_found(run_id: str) -> NoReturn:
    sys.stderr.write(f"run introuvable : {run_id}\n")
    raise SystemExit(4)


#: Stable reference to the package-level entry-point function. The plain
#: ``main`` attribute can be shadowed by the lazily-loaded ``mobius.cli.main``
#: submodule once any code imports it; tests and tooling can rely on
#: ``mobius.cli.entry_point`` to always point at the function.
entry_point = main


__all__ = ["entry_point", "main"]
