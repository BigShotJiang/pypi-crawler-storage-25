"""Lazy Typer command registration for the Mobius CLI."""

from __future__ import annotations

import importlib
from pathlib import Path
from typing import Annotated, Any, cast

import typer

from mobius.cli import output
from mobius.core.types import ExitCode
from mobius.v3a.cli.main import register_top_level_commands, v3a_app


def _resolve_latest_run_id(context: Any) -> str | None:
    """Resolve the latest run_id from the event store."""
    from mobius.config import get_paths
    from mobius.persistence.event_store import EventStore

    paths = get_paths(context.mobius_home)
    if not paths.event_store.exists():
        return None
    with EventStore(paths.event_store, read_only=True) as store:
        row = store.connection.execute(
            """
            SELECT aggregate_id
            FROM events
            WHERE type = 'run.started'
            ORDER BY created_at DESC, sequence DESC
            LIMIT 1
            """
        ).fetchone()
    return None if row is None else str(row["aggregate_id"])


def _complete_persona_name() -> list[str]:
    """Shell completion for persona names."""
    from mobius.agents.loader import list_personas

    return list(list_personas())


def register_commands(app: typer.Typer) -> None:
    """Register command wrappers without importing command handler modules."""

    @app.command(
        name="init",
        help="Créer un nouveau workspace Mobius à PATH.",
        rich_help_panel="Commandes avancées",
    )
    def init_command(
        ctx: typer.Context,
        target: Annotated[
            Path,
            typer.Argument(
                help="Répertoire workspace à initialiser (par défaut: répertoire courant).",
            ),
        ] = Path("."),
        force: Annotated[
            bool,
            typer.Option(
                "--force",
                help="Écraser un spec.yaml existant dans le répertoire cible.",
            ),
        ] = False,
        template: Annotated[
            str | None,
            typer.Option(
                "--template",
                help="Project template: web, cli, lib, etl, mobile, docs, blank. "
                "Auto-detected from the cwd when omitted.",
            ),
        ] = None,
    ) -> None:
        """Create a starter spec.yaml and initialize the Mobius event store."""
        module = importlib.import_module("mobius.cli.commands.init")
        cast(Any, module).run(ctx.obj, target, force=force, template=template)

    @app.command(
        name="setup",
        help="Installer ou retirer les assets d’intégration agent Mobius.",
        rich_help_panel="Commandes avancées",
    )
    def setup_command(
        ctx: typer.Context,
        runtime: Annotated[
            str,
            typer.Option(
                "--runtime",
                help="Runtime agent à configurer: claude, codex ou hermes.",
            ),
        ],
        scope: Annotated[
            str,
            typer.Option(
                "--scope",
                help="Portée d’installation: user sous le home; project sous le cwd.",
            ),
        ] = "user",
        dry_run: Annotated[
            bool,
            typer.Option(
                "--dry-run",
                help="Afficher les actions prévues sans écrire sur le système de fichiers.",
            ),
        ] = False,
        uninstall: Annotated[
            bool,
            typer.Option(
                "--uninstall",
                help="Retirer seulement les assets déjà installés par Mobius.",
            ),
        ] = False,
    ) -> None:
        """Install, inspect, or remove Mobius integration assets without registering MCP."""
        module = importlib.import_module("mobius.cli.commands.setup")
        cast(Any, module).run(
            ctx.obj,
            runtime=runtime,
            scope=scope,
            dry_run=dry_run,
            uninstall=uninstall,
        )

    @app.command(
        name="cancel", help="Annuler un run Mobius détaché.", rich_help_panel="Commandes avancées"
    )
    def cancel_command(
        ctx: typer.Context,
        run_id: Annotated[
            str,
            typer.Argument(help="Identifiant du run à annuler."),
        ],
        grace_period: Annotated[
            float,
            typer.Option(
                "--grace-period",
                min=0.0,
                help="Secondes à attendre après SIGTERM avant escalade vers SIGKILL.",
            ),
        ] = 10.0,
    ) -> None:
        """Send SIGTERM to a detached worker and clean up its PID file."""
        module = importlib.import_module("mobius.cli.commands.cancel")
        cast(Any, module).run(ctx.obj, run_id, grace_period=grace_period)

    @app.command(
        name="qa",
        help="Exécuter les contrôles QA pour un run Mobius.",
        rich_help_panel="Commandes avancées",
    )
    def qa_command(
        ctx: typer.Context,
        run_id: Annotated[
            str | None,
            typer.Argument(help="Identifiant du run à juger. Défaut: dernier run."),
        ] = None,
        offline: Annotated[
            bool,
            typer.Option(
                "--offline/--online",
                help=(
                    "Utiliser le juge offline déterministe ou le mode online "
                    "avec jugement sémantique LLM optionnel."
                ),
            ),
        ] = True,
        json_output: Annotated[
            bool,
            typer.Option(
                "--json",
                help="Émettre un JSON lisible par machine avec résumé et résultats.",
            ),
        ] = False,
        suggest: Annotated[
            bool,
            typer.Option(
                "--suggest",
                help=(
                    "Proposer des commandes verification_commands pour les critères "
                    "sans preuve liée."
                ),
            ),
        ] = False,
        sequential: Annotated[
            bool,
            typer.Option(
                "--sequential",
                help="Désactiver le parallélisme des commandes de vérification.",
            ),
        ] = False,
        max_workers: Annotated[
            int | None,
            typer.Option(
                "--max-workers",
                help="Nombre maximum de vérifications QA parallèles.",
            ),
        ] = None,
    ) -> None:
        """Evaluate a run with the offline QA judge."""
        resolved_id = run_id or _resolve_latest_run_id(ctx.obj)
        if resolved_id is None:
            output.write_error_line(
                "aucun run trouvé — lancez d'abord : mobius run --spec spec.yaml"
            )
            raise typer.Exit(code=int(ExitCode.NOT_FOUND))
        module = importlib.import_module("mobius.cli.commands.qa")
        cast(Any, module).run(
            ctx.obj,
            resolved_id,
            offline=offline,
            json_output=json_output,
            suggest=suggest,
            sequential=sequential,
            max_workers=max_workers,
        )
        if not (ctx.obj.json_output or json_output):
            output.suggest_next("qa")

    @app.command(
        name="ultraqa",
        help="QA puis boucle de correction Ralph bornée si besoin.",
        rich_help_panel="Commandes avancées",
    )
    def ultraqa_command(
        ctx: typer.Context,
        run_id: Annotated[
            str | None,
            typer.Argument(help="Run id optionnel à vérifier. Défaut: dernier run."),
        ] = None,
        max_iterations: Annotated[
            int,
            typer.Option(
                "--max-iterations",
                help="Nombre maximum d'itérations de correction Ralph.",
            ),
        ] = 3,
        dry_run: Annotated[
            bool,
            typer.Option("--dry-run", help="Expliquer la boucle sans lancer QA/Ralph."),
        ] = False,
        json_output: Annotated[
            bool,
            typer.Option("--json", help="Émettre du JSON lisible par machine."),
        ] = False,
    ) -> None:
        """Run QA and bounded Ralph fix-loop when QA does not pass."""
        module = importlib.import_module("mobius.cli.commands.ultraqa")
        cast(Any, module).run(
            ctx.obj,
            run_id,
            max_iterations=max_iterations,
            dry_run=dry_run,
            json_output=json_output,
        )

    @app.command(
        name="build",
        help="Transformer une idée floue en spec Mobius guidée.",
        rich_help_panel="Commandes avancées",
    )
    def build_command(
        ctx: typer.Context,
        intent: Annotated[
            str,
            typer.Argument(help="Idée ou objectif utilisateur à clarifier."),
        ],
        output_path: Annotated[
            Path | None,
            typer.Option(
                "--output",
                file_okay=True,
                dir_okay=False,
                writable=True,
                help="Chemin de la spec générée (défaut: ./spec.yaml).",
            ),
        ] = None,
        template: Annotated[
            str | None,
            typer.Option(
                "--template",
                help="Template: web, cli, lib, etl, mobile, docs, blank.",
            ),
        ] = None,
        project_type: Annotated[
            str | None,
            typer.Option(
                "--project-type",
                help="Type de projet: greenfield ou brownfield.",
            ),
        ] = None,
        constraint: Annotated[
            list[str] | None,
            typer.Option(
                "--constraint",
                help="Contrainte connue. Peut être répétée.",
            ),
        ] = None,
        success_criterion: Annotated[
            list[str] | None,
            typer.Option(
                "--success-criterion",
                help="Critère de succès connu. Peut être répété.",
            ),
        ] = None,
        context_value: Annotated[
            str | None,
            typer.Option(
                "--context",
                help="Contexte du système existant pour un projet brownfield.",
            ),
        ] = None,
        json_output: Annotated[
            bool,
            typer.Option(
                "--json",
                help="Émettre du JSON lisible par machine.",
            ),
        ] = False,
    ) -> None:
        """Run the local conversational clarification and write a seedable spec."""
        module = importlib.import_module("mobius.cli.commands.build")
        cast(Any, module).run(
            ctx.obj,
            intent,
            output_path=output_path,
            template=template,
            project_type=project_type,
            constraints=constraint,
            success_criteria=success_criterion,
            context_value=context_value,
            json_output=json_output,
        )

    @app.command(
        name="go",
        help="Chemin débutant: idée -> spec -> seed -> run en une commande.",
        rich_help_panel="Commandes essentielles",
    )
    def go_command(
        ctx: typer.Context,
        intent: Annotated[
            str,
            typer.Argument(help='Idée naturelle, ex: "je veux une app de recettes".'),
        ],
        output_path: Annotated[
            Path | None,
            typer.Option(
                "--output",
                file_okay=True,
                dir_okay=False,
                writable=True,
                help="Chemin de la spec générée (défaut: ./spec.yaml).",
            ),
        ] = None,
        template: Annotated[
            str | None,
            typer.Option("--template", help="Template: web, cli, lib, etl, mobile, docs, blank."),
        ] = None,
        project_type: Annotated[
            str | None,
            typer.Option("--project-type", help="Type de projet: greenfield ou brownfield."),
        ] = None,
        constraint: Annotated[
            list[str] | None,
            typer.Option("--constraint", help="Contrainte connue. Peut être répétée."),
        ] = None,
        success_criterion: Annotated[
            list[str] | None,
            typer.Option("--success-criterion", help="Critère de succès connu. Peut être répété."),
        ] = None,
        context_value: Annotated[
            str | None,
            typer.Option(
                "--context",
                help="Contexte du système existant pour un projet brownfield.",
            ),
        ] = None,
        auto_seed: Annotated[
            bool,
            typer.Option("--auto-seed/--no-auto-seed", help="Créer le seed automatiquement."),
        ] = True,
        execute: Annotated[
            bool,
            typer.Option("--execute/--no-execute", help="Lancer un run après le seed."),
        ] = True,
        detach: Annotated[
            bool,
            typer.Option("--detach/--no-detach", help="Détacher le run au lieu de le lancer ici."),
        ] = False,
        foreground: Annotated[
            bool,
            typer.Option("--foreground/--no-foreground", help="Streamer les événements du run."),
        ] = True,
        coding_agent: Annotated[
            str | None,
            typer.Option("--agent", help="Agent de code à lancer: droid, claude, codex."),
        ] = None,
        coding_model: Annotated[
            str | None,
            typer.Option("--model", help="Modèle agent à utiliser."),
        ] = None,
        approve_agent: Annotated[
            bool,
            typer.Option(
                "--approve-agent/--ask-agent",
                help="Ne pas demander confirmation avant l'agent (implicite pour go).",
            ),
        ] = True,
        dry_run: Annotated[
            bool,
            typer.Option("--dry-run", help="Afficher le plan sans écrire ni lancer."),
        ] = False,
        json_output: Annotated[
            bool,
            typer.Option("--json", help="Émettre du JSON lisible par machine."),
        ] = False,
    ) -> None:
        """Run the beginner happy path from a natural-language idea."""
        module = importlib.import_module("mobius.cli.commands.go")
        cast(Any, module).go(
            ctx.obj,
            intent,
            output_path=output_path,
            template=template,
            project_type=project_type,
            constraints=constraint,
            success_criteria=success_criterion,
            context_value=context_value,
            auto_seed=auto_seed,
            execute=execute,
            detach=detach,
            foreground=foreground,
            coding_agent=coding_agent,
            coding_model=coding_model,
            approve_agent=approve_agent,
            dry_run=dry_run,
            json_output=json_output,
        )

    @app.command(
        name="run", help="Exécuter une spec seed Mobius.", rich_help_panel="Commandes avancées"
    )
    def run_command(
        ctx: typer.Context,
        spec_path: Annotated[
            Path,
            typer.Option(
                "--spec",
                exists=True,
                file_okay=True,
                dir_okay=False,
                readable=True,
                help="Seed spec file to execute.",
            ),
        ],
        detach: Annotated[
            bool,
            typer.Option(
                "--detach",
                help="Start a background worker and immediately print the run id.",
            ),
        ] = True,
        foreground: Annotated[
            bool,
            typer.Option(
                "--foreground",
                help="Run in the current process and stream events to stderr.",
            ),
        ] = False,
        coding_agent: Annotated[
            str | None,
            typer.Option(
                "--agent",
                help="Coding agent to launch after approval: auto, droid, claude, or codex.",
            ),
        ] = None,
        coding_model: Annotated[
            str | None,
            typer.Option(
                "--model",
                help="Coding model to use for the launched agent.",
            ),
        ] = None,
        coding_plan: Annotated[
            Path | None,
            typer.Option(
                "--plan",
                exists=True,
                file_okay=True,
                dir_okay=False,
                readable=True,
                help="Human-approved plan file to record before launching the coding agent.",
            ),
        ] = None,
        approve_agent: Annotated[
            bool,
            typer.Option(
                "--approve-agent",
                help="Skip the interactive approval prompt before launching the coding agent.",
            ),
        ] = False,
    ) -> None:
        """Validate a seed spec and execute it as a run."""
        module = importlib.import_module("mobius.cli.commands.run")
        cast(Any, module).run(
            ctx.obj,
            spec_path=spec_path,
            detach=detach,
            foreground=foreground,
            coding_agent=coding_agent,
            coding_model=coding_model,
            coding_plan=coding_plan,
            approve_agent=approve_agent,
        )
        if output.human_output_allowed(ctx.obj, raw_stdout=True):
            output.suggest_next("run")

    @app.command(
        name="evolve",
        help="Lancer une boucle d’évolution de génération Mobius.",
        rich_help_panel="Commandes avancées",
    )
    def evolve_command(
        ctx: typer.Context,
        run_id: Annotated[
            str | None,
            typer.Argument(help="Completed run id to use as the evolution source."),
        ] = None,
        from_option: Annotated[
            str | None,
            typer.Option(
                "--from",
                help="Completed run id; alias for the positional argument.",
            ),
        ] = None,
        generations: Annotated[
            int,
            typer.Option(
                "--generations",
                min=1,
                help="Maximum generation count (hard-capped at 30).",
            ),
        ] = 30,
        detach: Annotated[
            bool,
            typer.Option(
                "--detach",
                help="Start a background worker and immediately print the evolution id.",
            ),
        ] = True,
        foreground: Annotated[
            bool,
            typer.Option(
                "--foreground",
                help="Run in the current process and stream generation events to stderr.",
            ),
        ] = False,
    ) -> None:
        """Start a detached evolution by default."""
        source_run_id = from_option or run_id
        if source_run_id is None:
            source_run_id = _resolve_latest_run_id(ctx.obj)
            if source_run_id is None:
                output.write_error_line("Aucun run trouvé. Lancez : mobius go 'votre idée'")
                raise typer.Exit(code=int(ExitCode.NOT_FOUND))
        module = importlib.import_module("mobius.cli.commands.evolve")
        cast(Any, module).run(
            ctx.obj,
            source_run_id=source_run_id,
            generations=generations,
            detach=detach,
            foreground=foreground,
        )
        if output.human_output_allowed(ctx.obj, raw_stdout=True):
            output.suggest_next("evolve")

    @app.command(
        name="lineage",
        help="Afficher l’arbre de lineage d’un agrégat ou son hash de replay.",
        rich_help_panel="Commandes avancées",
    )
    def lineage_command(
        ctx: typer.Context,
        aggregate_id: Annotated[
            str | None,
            typer.Argument(help="Aggregate id to inspect."),
        ] = None,
        json_output: Annotated[
            bool,
            typer.Option(
                "--json",
                help="Emit machine-readable JSON with ancestors[] and descendants[].",
            ),
        ] = False,
        hash_output: Annotated[
            bool,
            typer.Option(
                "--hash",
                help="Print the deterministic SHA-256 replay hash for the aggregate.",
            ),
        ] = False,
        aggregate: Annotated[
            str | None,
            typer.Option(
                "--aggregate",
                help="Aggregate id to hash or inspect; alias for the positional id.",
            ),
        ] = None,
    ) -> None:
        """Render lineage for a run/evolution aggregate."""
        module = importlib.import_module("mobius.cli.commands.lineage")
        cast(Any, module).run(
            ctx.obj,
            aggregate_id,
            aggregate=aggregate,
            json_output=json_output,
            hash_output=hash_output,
        )

    @app.command(
        name="seed",
        help="Créer une session seed depuis une spec projet ou une session interview.",
        rich_help_panel="Commandes avancées",
    )
    def seed_command(
        ctx: typer.Context,
        spec_or_session_id: Annotated[
            str | None,
            typer.Argument(
                help=(
                    "Path to a project spec file, an interview session id, "
                    "or omit with --from-transcript."
                ),
            ),
        ] = None,
        json_output: Annotated[
            bool,
            typer.Option(
                "--json",
                help="Émettre du JSON lisible par machine.",
            ),
        ] = False,
        validate: Annotated[
            bool,
            typer.Option(
                "--validate",
                help="Assign the Bronze static completeness grade after validation.",
            ),
        ] = False,
        from_transcript: Annotated[
            Path | None,
            typer.Option(
                "--from-transcript",
                exists=True,
                file_okay=True,
                dir_okay=False,
                readable=True,
                help="Generate a strict spec from a labelled interview transcript before seeding.",
            ),
        ] = None,
    ) -> None:
        """Validate a project spec and persist seed events."""
        module = importlib.import_module("mobius.cli.commands.seed")
        cast(Any, module).run(
            ctx.obj,
            spec_or_session_id,
            json_output=json_output,
            validate=validate,
            from_transcript=from_transcript,
        )

    @app.command(
        name="interview",
        help="Lancer l’entretien projet et produire une spec.",
        rich_help_panel="Commandes avancées",
    )
    def interview_command(
        ctx: typer.Context,
        non_interactive: Annotated[
            bool,
            typer.Option(
                "--non-interactive",
                help="Read deterministic answers from --input instead of prompting interactively.",
            ),
        ] = False,
        input_path: Annotated[
            Path | None,
            typer.Option(
                "--input",
                exists=True,
                file_okay=True,
                dir_okay=False,
                readable=True,
                help="Fixture file containing deterministic interview answers.",
            ),
        ] = None,
        output_path: Annotated[
            Path | None,
            typer.Option(
                "--output",
                file_okay=True,
                dir_okay=False,
                writable=True,
                help="Path where the generated spec YAML should be written. "
                "Defaults to ./spec.yaml in the cwd.",
            ),
        ] = None,
        template: Annotated[
            str | None,
            typer.Option(
                "--template",
                help="Template hint: web, cli, lib, etl, mobile, docs, blank. "
                "Auto-detected from the cwd when omitted.",
            ),
        ] = None,
        project_type: Annotated[
            str | None,
            typer.Option(
                "--project-type",
                help="Project kind: greenfield (new) or brownfield (existing). "
                "Defaults to greenfield when no fixture/template is supplied; "
                "otherwise the fixture's value is honored.",
            ),
        ] = None,
        goal: Annotated[
            str | None,
            typer.Option(
                "--goal",
                help="Project goal (one sentence). Used with --non-interactive when --input "
                "is omitted, or to override the fixture goal. Intended for coding agents that "
                "have already extracted the goal from a conversation with the user.",
            ),
        ] = None,
        constraint: Annotated[
            list[str] | None,
            typer.Option(
                "--constraint",
                help="Add a constraint. Pass multiple times for multiple constraints. "
                "Used with --non-interactive to override or supply constraints without a "
                "fixture file.",
            ),
        ] = None,
        success_criterion: Annotated[
            list[str] | None,
            typer.Option(
                "--success-criterion",
                help="Add a success criterion. Pass multiple times for multiple criteria. "
                "Used with --non-interactive to override or supply success criteria without a "
                "fixture file.",
            ),
        ] = None,
        context: Annotated[
            str | None,
            typer.Option(
                "--context",
                help="Existing-system context (brownfield projects). Ignored unless "
                "--project-type=brownfield.",
            ),
        ] = None,
        from_session: Annotated[
            str | None,
            typer.Option(
                "--from-session",
                help="Load context from a previous interview session id. "
                "Chains brownfield iterations automatically.",
            ),
        ] = None,
        mode: Annotated[
            str,
            typer.Option(
                "--mode",
                help="Interactive interview style: auto, quick, deep, conversational, or agent.",
            ),
        ] = "auto",
        deep_metadata: Annotated[
            Path | None,
            typer.Option(
                "--deep-metadata",
                exists=True,
                file_okay=True,
                dir_okay=False,
                readable=True,
                help="JSON file with deep interview metadata (clarity score, risks, "
                "assumptions, pre-mortem). Written by the agent in deep mode.",
            ),
        ] = None,
    ) -> None:
        """Run the interview command (interactive by default; --non-interactive for fixtures)."""
        module = importlib.import_module("mobius.cli.commands.interview")
        cast(Any, module).run(
            ctx.obj,
            non_interactive=non_interactive,
            input_path=input_path,
            output_path=output_path,
            template=template,
            project_type=project_type,
            goal=goal,
            constraints=constraint,
            success_criteria=success_criterion,
            context_value=context,
            from_session=from_session,
            deep_metadata=deep_metadata,
            mode=mode,
        )

    @app.command(
        name="status",
        help="Afficher le statut de l’event store Mobius.",
        rich_help_panel="Commandes essentielles",
    )
    def status_command(
        ctx: typer.Context,
        run_id: Annotated[
            str | None,
            typer.Argument(help="Optional run id to inspect."),
        ] = None,
        read_only: Annotated[
            bool,
            typer.Option(
                "--read-only",
                help="Open the event store via SQLite mode=ro without writing WAL frames.",
            ),
        ] = False,
        json_output: Annotated[
            bool,
            typer.Option(
                "--json",
                help="Émettre du JSON lisible par machine.",
            ),
        ] = False,
        follow: Annotated[
            bool,
            typer.Option(
                "--follow",
                help="Poll the event store every 200ms and stream run event deltas until terminal.",
            ),
        ] = False,
        rich: Annotated[
            bool,
            typer.Option(
                "--rich",
                help="Render a Rich dashboard snapshot from the event store.",
            ),
        ] = False,
    ) -> None:
        """Open the event store and report a lightweight status snapshot."""
        module = importlib.import_module("mobius.cli.commands.status")
        cast(Any, module).run(
            ctx.obj,
            run_id,
            read_only=read_only,
            json_output=json_output,
            follow=follow,
            rich=rich,
        )

    config_app = typer.Typer(
        add_completion=False,
        context_settings={"help_option_names": ["-h", "--help"]},
        invoke_without_command=True,
        no_args_is_help=False,
        help="Afficher, lire et définir la configuration Mobius.",
    )

    def _load_config_command_module() -> object:
        return importlib.import_module("mobius.cli.commands.config")

    @config_app.callback()
    def config_callback(ctx: typer.Context) -> None:
        """Show config when no config subcommand is provided."""
        if ctx.invoked_subcommand is None:
            module = _load_config_command_module()
            cast(Any, module).show(ctx.obj)

    @config_app.command(name="show")
    def config_show(
        ctx: typer.Context,
        json_output: Annotated[
            bool,
            typer.Option(
                "--json",
                help="Émettre du JSON lisible par machine.",
            ),
        ] = False,
    ) -> None:
        """Show resolved paths and all config values."""
        module = _load_config_command_module()
        cast(Any, module).show(ctx.obj, json_output=json_output)

    @config_app.command(name="get")
    def config_get(
        ctx: typer.Context,
        key: Annotated[str, typer.Argument(help="Config key to read.")],
        json_output: Annotated[
            bool,
            typer.Option(
                "--json",
                help="Émettre du JSON lisible par machine.",
            ),
        ] = False,
    ) -> None:
        """Read one config value."""
        module = _load_config_command_module()
        cast(Any, module).get(ctx.obj, key, json_output=json_output)

    @config_app.command(name="set")
    def config_set(
        ctx: typer.Context,
        key: Annotated[str, typer.Argument(help="Config key to persist.")],
        value: Annotated[str, typer.Argument(help="Config value to persist.")],
        json_output: Annotated[
            bool,
            typer.Option(
                "--json",
                help="Émettre du JSON lisible par machine.",
            ),
        ] = False,
    ) -> None:
        """Set one config value idempotently."""
        module = _load_config_command_module()
        cast(Any, module).set_value(ctx.obj, key, value, json_output=json_output)

    app.add_typer(config_app, name="config")

    agent_app = typer.Typer(
        add_completion=False,
        context_settings={"help_option_names": ["-h", "--help"]},
        invoke_without_command=True,
        no_args_is_help=True,
        help="Personas de pensée latérale pour débloquer un projet.",
    )

    @agent_app.command(name="list")
    def agent_list_command(
        ctx: typer.Context,
        json_output: Annotated[
            bool,
            typer.Option(
                "--json",
                help="Émettre du JSON lisible par machine.",
            ),
        ] = False,
    ) -> None:
        """Lister les personas de pensée latérale disponibles."""
        module = importlib.import_module("mobius.cli.commands.agent")
        cast(Any, module).list_personas(ctx.obj, json_output=json_output)

    @agent_app.command(name="prompt")
    def agent_prompt_command(
        ctx: typer.Context,
        name: Annotated[
            str,
            typer.Argument(
                help="Nom de la persona : contrarian, hacker, simplifier, researcher, architect.",
                autocompletion=_complete_persona_name,
            ),
        ],
    ) -> None:
        """Afficher le prompt complet d'une persona."""
        module = importlib.import_module("mobius.cli.commands.agent")
        cast(Any, module).show_prompt(ctx.obj, name)

    @agent_app.command(name="suggest")
    def agent_suggest_command(
        ctx: typer.Context,
        run_id: Annotated[
            str | None,
            typer.Argument(
                help="Identifiant du run ou de l'évolution à analyser.",
                autocompletion=_complete_persona_name,
            ),
        ] = None,
        interactive: Annotated[
            bool,
            typer.Option(
                "--interactive",
                help="Analyser le workspace courant sans run_id.",
            ),
        ] = False,
        json_output: Annotated[
            bool,
            typer.Option(
                "--json",
                help="Émettre du JSON lisible par machine.",
            ),
        ] = False,
    ) -> None:
        """Analyser un run et suggérer la persona la plus pertinente."""
        module = importlib.import_module("mobius.cli.commands.agent")
        cast(Any, module).suggest(ctx.obj, run_id, interactive=interactive, json_output=json_output)

    @agent_app.command(name="apply")
    def agent_apply_command(
        ctx: typer.Context,
        name: Annotated[
            str,
            typer.Argument(
                help="Nom de la persona à appliquer.",
                autocompletion=_complete_persona_name,
            ),
        ],
        run_id: Annotated[
            str,
            typer.Option("--run-id", help="Identifiant du run cible."),
        ],
    ) -> None:
        """Tracer l'application d'une persona sur un run dans l'event store."""
        module = importlib.import_module("mobius.cli.commands.agent")
        cast(Any, module).apply_persona(ctx.obj, name, run_id)

    app.add_typer(agent_app, name="agent")

    @app.command(
        name="unstuck",
        help="Débloquer un projet avec une seule persona recommandée.",
        rich_help_panel="Commandes avancées",
    )
    def unstuck_command(
        ctx: typer.Context,
        run_id: Annotated[
            str | None,
            typer.Argument(help="Run ou évolution à analyser. Omettre pour analyser le workspace."),
        ] = None,
        apply: Annotated[
            bool,
            typer.Option("--apply", help="Appliquer immédiatement la persona recommandée au run."),
        ] = False,
        json_output: Annotated[
            bool,
            typer.Option("--json", help="Émettre du JSON lisible par machine."),
        ] = False,
    ) -> None:
        """Suggest and optionally apply the best lateral-thinking persona."""
        module = importlib.import_module("mobius.cli.commands.go")
        cast(Any, module).unstuck(ctx.obj, run_id, apply=apply, json_output=json_output)

    @app.command(
        name="ralph",
        help="Boucle persistante: evolve -> QA jusqu'à pass ou stagnation.",
        rich_help_panel="Commandes avancées",
    )
    def ralph_command(
        ctx: typer.Context,
        run_id: Annotated[
            str | None,
            typer.Argument(help="Run à faire converger. Défaut: latest."),
        ] = None,
        from_option: Annotated[
            str | None,
            typer.Option("--from", help="Run à faire converger; alias de l'argument positionnel."),
        ] = None,
        max_iterations: Annotated[
            int | None,
            typer.Option("--max-iterations", min=1, help="Nombre maximal d'itérations Ralph."),
        ] = None,
        max_cycles: Annotated[
            int | None,
            typer.Option("--max-cycles", min=1, help="Alias historique de --max-iterations."),
        ] = None,
        dry_run: Annotated[
            bool,
            typer.Option("--dry-run", help="Expliquer la boucle sans exécuter."),
        ] = False,
        detached: Annotated[
            bool,
            typer.Option(
                "--detached",
                help="Lancer Ralph en arrière-plan et retourner le ralph_id.",
            ),
        ] = False,
        resume: Annotated[
            str | None,
            typer.Option("--resume", help="Reprendre une session Ralph durable par ralph_id."),
        ] = None,
        json_output: Annotated[
            bool,
            typer.Option("--json", help="Émettre du JSON lisible par machine."),
        ] = False,
    ) -> None:
        """Run or explain the persistent convergence loop."""
        module = importlib.import_module("mobius.cli.commands.ralph")
        cast(Any, module).run(
            ctx.obj,
            from_option or run_id,
            max_iterations=max_iterations or max_cycles or 10,
            dry_run=dry_run,
            detached=detached,
            resume=resume,
            json_output=json_output,
        )

    register_top_level_commands(app)
    app.add_typer(v3a_app, name="v3a")

    todo_app = typer.Typer(
        add_completion=False,
        context_settings={"help_option_names": ["-h", "--help"]},
        invoke_without_command=True,
        no_args_is_help=False,
        help="Gérer les tâches TODO du projet.",
    )

    @todo_app.callback()
    def todo_callback(ctx: typer.Context) -> None:
        """List pending todos when no subcommand is provided."""
        if ctx.invoked_subcommand is None:
            module = importlib.import_module("mobius.cli.commands.todo")
            cast(Any, module).ls(ctx.obj)

    @todo_app.command(name="add")
    def todo_add_command(
        ctx: typer.Context,
        text: Annotated[
            str,
            typer.Argument(help="Description de la tâche à ajouter."),
        ],
        json_output: Annotated[
            bool,
            typer.Option("--json", help="Émettre du JSON lisible par machine."),
        ] = False,
    ) -> None:
        """Ajouter une tâche TODO."""
        module = importlib.import_module("mobius.cli.commands.todo")
        cast(Any, module).add(ctx.obj, text, json_output=json_output)

    @todo_app.command(name="ls")
    def todo_ls_command(
        ctx: typer.Context,
        show_all: Annotated[
            bool,
            typer.Option("--all", help="Inclure les tâches terminées."),
        ] = False,
        json_output: Annotated[
            bool,
            typer.Option("--json", help="Émettre du JSON lisible par machine."),
        ] = False,
    ) -> None:
        """Lister les tâches TODO."""
        module = importlib.import_module("mobius.cli.commands.todo")
        cast(Any, module).ls(ctx.obj, show_all=show_all, json_output=json_output)

    @todo_app.command(name="done")
    def todo_done_command(
        ctx: typer.Context,
        todo_id: Annotated[
            str,
            typer.Argument(help="Identifiant de la tâche à marquer terminée."),
        ],
        json_output: Annotated[
            bool,
            typer.Option("--json", help="Émettre du JSON lisible par machine."),
        ] = False,
    ) -> None:
        """Marquer une tâche comme terminée."""
        module = importlib.import_module("mobius.cli.commands.todo")
        cast(Any, module).done(ctx.obj, todo_id, json_output=json_output)

    @todo_app.command(name="rm")
    def todo_rm_command(
        ctx: typer.Context,
        todo_id: Annotated[
            str,
            typer.Argument(help="Identifiant de la tâche à supprimer."),
        ],
        json_output: Annotated[
            bool,
            typer.Option("--json", help="Émettre du JSON lisible par machine."),
        ] = False,
    ) -> None:
        """Supprimer une tâche."""
        module = importlib.import_module("mobius.cli.commands.todo")
        cast(Any, module).remove(ctx.obj, todo_id, json_output=json_output)

    app.add_typer(todo_app, name="todo")

    worker_app = typer.Typer(
        add_completion=False,
        context_settings={"help_option_names": ["-h", "--help"]},
        help="Commandes internes des workers Mobius.",
    )

    @worker_app.command(name="run")
    def worker_run_command(
        ctx: typer.Context,
        run_id: Annotated[str, typer.Argument(help="Prepared run id to execute.")],
    ) -> None:
        """Execute a prepared run. Internal command, not part of the public CLI."""
        module = importlib.import_module("mobius.cli.commands.run")
        cast(Any, module).worker_run(ctx.obj, run_id=run_id)

    @worker_app.command(name="evolve")
    def worker_evolve_command(
        ctx: typer.Context,
        evolution_id: Annotated[str, typer.Argument(help="Prepared evolution id to execute.")],
    ) -> None:
        """Execute a prepared evolution. Internal command, not part of the public CLI."""
        module = importlib.import_module("mobius.cli.commands.evolve")
        cast(Any, module).worker_evolve(ctx.obj, evolution_id=evolution_id)

    @worker_app.command(name="ralph")
    def worker_ralph_command(
        ctx: typer.Context,
        ralph_id: Annotated[str, typer.Argument(help="Prepared Ralph id to execute.")],
    ) -> None:
        """Execute a prepared Ralph session. Internal command, not part of the public CLI."""
        module = importlib.import_module("mobius.cli.commands.ralph")
        cast(Any, module).worker_ralph(ctx.obj, ralph_id=ralph_id)

    app.add_typer(worker_app, name="_worker", hidden=True)
