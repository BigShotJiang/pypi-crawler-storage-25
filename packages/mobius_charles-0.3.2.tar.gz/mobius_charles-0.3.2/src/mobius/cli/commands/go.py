"""Beginner-first orchestration commands for Mobius."""

from __future__ import annotations

import shlex
from contextlib import nullcontext, redirect_stdout
from dataclasses import dataclass
from io import StringIO
from pathlib import Path
from typing import Any

import typer
from pydantic import BaseModel, ConfigDict

from mobius.cli import output
from mobius.cli.commands import interview as interview_command
from mobius.cli.commands import run as run_command
from mobius.cli.commands import seed as seed_command
from mobius.cli.formatter import get_formatter
from mobius.cli.main import CliContext, ExitCode
from mobius.config import get_paths
from mobius.persistence.event_store import EventStore
from mobius.workflow.lateral import Suggestion


class GoOutput(BaseModel):
    """Machine-readable result for ``mobius go``."""

    model_config = ConfigDict(extra="forbid")

    intent: str
    spec_path: str
    dry_run: bool
    steps: list[str]
    commands: list[str]
    beginner_scorecard: dict[str, str]
    next_action: str


class UnstuckOutput(BaseModel):
    """Machine-readable result for ``mobius unstuck``."""

    model_config = ConfigDict(extra="forbid")

    persona: str
    confidence: float
    reason: str
    next_command: str
    applied: bool = False


class RalphOutput(BaseModel):
    """Machine-readable result for ``mobius ralph``."""

    model_config = ConfigDict(extra="forbid")

    dry_run: bool
    run_id: str | None
    max_cycles: int
    steps: list[str]
    stop_condition: str
    next_command: str | None = None


@dataclass(frozen=True)
class _GoPlan:
    spec_path: Path
    steps: list[str]
    commands: list[str]
    scorecard: dict[str, str]


def go(
    context: CliContext,
    intent: str,
    *,
    output_path: Path | None = None,
    template: str | None = None,
    project_type: str | None = None,
    constraints: list[str] | None = None,
    success_criteria: list[str] | None = None,
    context_value: str | None = None,
    auto_seed: bool = True,
    execute: bool = True,
    detach: bool = False,
    foreground: bool = True,
    coding_agent: str | None = None,
    coding_model: str | None = None,
    approve_agent: bool = True,
    dry_run: bool = False,
    json_output: bool = False,
) -> None:
    """Run the beginner happy path from a natural-language idea."""
    plan = _build_go_plan(
        intent,
        output_path=output_path,
        template=template,
        constraints=constraints,
        success_criteria=success_criteria,
        auto_seed=auto_seed,
        execute=execute,
        coding_agent=coding_agent,
        coding_model=coding_model,
        approve_agent=approve_agent,
        detach=detach,
        foreground=foreground,
    )
    effective_constraints = _beginner_constraints(intent, template, constraints)
    effective_success_criteria = _beginner_success_criteria(intent, template, success_criteria)
    if dry_run:
        payload = GoOutput(
            intent=intent,
            spec_path=str(plan.spec_path),
            dry_run=True,
            steps=plan.steps,
            commands=plan.commands,
            beginner_scorecard=plan.scorecard,
            next_action="Relancez sans --dry-run pour créer la spec, le seed et le run.",
        )
        formatter = get_formatter(context, json_output=json_output)
        formatter.emit(payload, text=lambda: _write_go_markdown(payload))
        return

    with _silence_nested_stdout_when_json(json_output):
        interview_command.run(
            context,
            non_interactive=False,
            input_path=None,
            output_path=plan.spec_path,
            template=template,
            project_type=project_type,
            goal=intent,
            constraints=effective_constraints,
            success_criteria=effective_success_criteria,
            context_value=context_value,
            mode="conversational",
        )
        if auto_seed:
            seed_command.run(context, str(plan.spec_path), json_output=False, validate=True)
        if execute:
            run_command.run(
                context,
                spec_path=plan.spec_path,
                detach=detach,
                foreground=foreground,
                coding_agent=coding_agent,
                coding_model=coding_model,
                approve_agent=approve_agent,
            )

    payload = GoOutput(
        intent=intent,
        spec_path=str(plan.spec_path),
        dry_run=False,
        steps=plan.steps,
        commands=plan.commands,
        beginner_scorecard=plan.scorecard,
        next_action="Suivez avec `mobius status`, `mobius qa latest`, puis `mobius ralph latest`.",
    )
    if json_output:
        output.write_json(payload.model_dump_json())
    else:
        output.write_line("")
        _write_go_markdown(payload)


def unstuck(
    context: CliContext,
    run_id: str | None,
    *,
    apply: bool = False,
    json_output: bool = False,
) -> None:
    """Suggest and optionally apply one lateral persona in one command."""
    suggestion = _suggestion(context, run_id)
    applied = False
    resolved_run_id = run_id
    if apply:
        if not run_id:
            output.write_error_line("--apply exige un run id explicite")
            raise typer.Exit(code=int(ExitCode.USAGE))
        _apply_persona(context, suggestion.persona, run_id)
        applied = True
        resolved_run_id = run_id

    next_command = (
        " ".join(
            (
                "mobius",
                "agent",
                "apply",
                shlex.quote(suggestion.persona),
                "--run-id",
                shlex.quote(resolved_run_id),
            )
        )
        if resolved_run_id and not applied
        else f"mobius agent prompt {shlex.quote(suggestion.persona)}"
    )
    payload = UnstuckOutput(
        persona=suggestion.persona,
        confidence=suggestion.confidence,
        reason=suggestion.reason,
        next_command=next_command,
        applied=applied,
    )
    formatter = get_formatter(context, json_output=json_output)
    formatter.emit(payload, text=lambda: _write_unstuck_markdown(payload))


def ralph(
    context: CliContext,
    run_id: str | None,
    *,
    max_cycles: int = 30,
    dry_run: bool = False,
    json_output: bool = False,
) -> None:
    """Backward-compatible wrapper for the real Ralph command handler."""
    from mobius.cli.commands import ralph as ralph_command

    ralph_command.run(
        context,
        run_id,
        max_iterations=max_cycles,
        dry_run=dry_run,
        json_output=json_output,
    )


def _build_go_plan(
    intent: str,
    *,
    output_path: Path | None,
    template: str | None,
    constraints: list[str] | None,
    success_criteria: list[str] | None,
    auto_seed: bool,
    execute: bool,
    coding_agent: str | None,
    coding_model: str | None,
    approve_agent: bool,
    detach: bool,
    foreground: bool,
) -> _GoPlan:
    spec_path = (output_path or Path.cwd() / "spec.yaml").expanduser().resolve()
    build_cmd = [
        "mobius",
        "interview",
        "--mode",
        "conversational",
        "--goal",
        intent,
        "--output",
        str(spec_path),
    ]
    if template:
        build_cmd.extend(["--template", template])
    for value in _beginner_constraints(intent, template, constraints):
        build_cmd.extend(["--constraint", value])
    for value in _beginner_success_criteria(intent, template, success_criteria):
        build_cmd.extend(["--success-criterion", value])
    commands = [" ".join(shlex.quote(part) for part in build_cmd)]
    steps = ["Clarifier l'idée en interview conversationnelle locale", "Écrire spec.yaml"]
    if auto_seed:
        commands.append(f"mobius seed {shlex.quote(str(spec_path))} --validate")
        steps.append("Créer automatiquement le seed validé")
    if execute:
        run_cmd = ["mobius", "run", "--spec", str(spec_path)]
        if foreground:
            run_cmd.append("--foreground")
        if not detach:
            run_cmd.append("--no-detach")
        if coding_agent:
            run_cmd.extend(["--agent", coding_agent])
        if coding_model:
            run_cmd.extend(["--model", coding_model])
        if approve_agent:
            run_cmd.append("--approve-agent")
        commands.append(" ".join(shlex.quote(part) for part in run_cmd))
        steps.append("Lancer l'exécution immédiatement")
    scorecard = {
        "installation": "une commande documentée d'abord; chemins dev en avancé",
        "démarrage": 'une commande naturelle: mobius go "idée"',
        "interview": "conversation locale multi-perspectives, sans terminal brut obligatoire",
        "seed": "seed automatique sur le happy path",
        "exécution": "run intégré; agent de code approuvé par défaut dans la même commande",
        "suivi": "status/qa/ralph plutôt que JSON brut",
        "qa": "preuve locale déterministe et lisible",
        "évolution": "ralph/evolve depuis latest",
        "déblocage": "mobius unstuck en une commande",
        "boucle persistante": "mobius ralph boucle jusqu'au stop condition",
    }
    return _GoPlan(spec_path=spec_path, steps=steps, commands=commands, scorecard=scorecard)


def _beginner_constraints(
    intent: str, template: str | None, constraints: list[str] | None
) -> list[str]:
    if constraints:
        return constraints
    if template and template.strip().lower() != "blank":
        return []
    return [
        "Rester local et réversible tant que l'utilisateur n'approuve pas un agent externe.",
        f"Conserver une première version centrée sur: {intent.strip()}.",
    ]


def _beginner_success_criteria(
    intent: str, template: str | None, success_criteria: list[str] | None
) -> list[str]:
    if success_criteria:
        return success_criteria
    if template and template.strip().lower() != "blank":
        return []
    return [
        "Une spec.yaml est créée avec un objectif, des contraintes et des critères testables.",
        f"Le premier run Mobius trace clairement l'avancement de: {intent.strip()}.",
    ]


def _silence_nested_stdout_when_json(json_output: bool) -> Any:
    if not json_output:
        return nullcontext()
    return redirect_stdout(StringIO())


def _write_go_markdown(payload: GoOutput) -> None:
    output.write_line("# Mobius go")
    output.write_line("")
    output.write_line(f"Idée: {payload.intent}")
    output.write_line(f"Spec: {payload.spec_path}")
    output.write_line("")
    output.write_line("## Étapes")
    for step in payload.steps:
        output.write_line(f"- {step}")
    output.write_line("")
    output.write_line("## Commandes équivalentes")
    for command in payload.commands:
        output.write_line(f"- `{command}`")
    output.write_line("")
    output.write_line("## Pourquoi ça gagne pour un non-dev")
    for key, value in payload.beginner_scorecard.items():
        output.write_line(f"- {key}: {value}")
    output.write_line("")
    output.write_line(f"Prochaine action: {payload.next_action}")


def _write_unstuck_markdown(payload: UnstuckOutput) -> None:
    output.write_line("# Mobius unstuck")
    output.write_line("")
    output.write_line(f"Persona recommandée: {payload.persona} ({payload.confidence:.0%})")
    output.write_line(f"Pourquoi: {payload.reason}")
    output.write_line(f"Appliquée: {'oui' if payload.applied else 'non'}")
    output.write_line(f"Prochaine commande: {payload.next_command}")


def _write_ralph_markdown(payload: RalphOutput) -> None:
    output.write_line("# Mobius ralph")
    output.write_line("")
    output.write_line(f"Run: {payload.run_id or 'latest introuvable'}")
    output.write_line(f"Cycles max: {payload.max_cycles}")
    for step in payload.steps:
        output.write_line(f"- {step}")
    output.write_line(f"Stop: {payload.stop_condition}")
    if payload.next_command:
        output.write_line(f"Commande: {payload.next_command}")


def _suggestion(context: CliContext, run_id: str | None) -> Suggestion:
    if run_id:
        from mobius.workflow.lateral import suggest_persona

        with EventStore(context.mobius_home / "events.db", read_only=True) as store:
            return suggest_persona(store, run_id)
    cwd = Path.cwd()
    has_spec = (cwd / "spec.yaml").exists()
    is_brownfield = any(
        (cwd / filename).exists()
        for filename in ("pyproject.toml", "package.json", "Cargo.toml", "go.mod")
    )
    if is_brownfield and not has_spec:
        return Suggestion(
            "researcher", "workspace brownfield sans spec — explorer le contexte", 0.7
        )
    if has_spec:
        return Suggestion("contrarian", "spec présente — challenger les hypothèses", 0.6)
    return Suggestion("architect", "workspace vide — structurer le projet avant de coder", 0.5)


def _apply_persona(context: CliContext, persona: str, run_id: str) -> None:
    with EventStore(context.mobius_home / "events.db") as store:
        existing = store.connection.execute(
            "SELECT session_id FROM sessions WHERE session_id = ?",
            (run_id,),
        ).fetchone()
        if existing is None:
            output.write_error_line(f"run introuvable : {run_id}")
            raise typer.Exit(code=int(ExitCode.NOT_FOUND))
        store.append_event(
            run_id, "agent.persona_applied", {"persona": persona, "applied_by": "unstuck"}
        )


def _latest_run_id(context: CliContext) -> str | None:
    paths = get_paths(context.mobius_home)
    if not paths.event_store.exists():
        return None
    with EventStore(paths.event_store, read_only=True) as store:
        row = store.connection.execute(
            """
            SELECT aggregate_id
            FROM events
            WHERE type = 'run.started'
            ORDER BY created_at DESC, sequence DESC
            LIMIT 1
            """
        ).fetchone()
    return None if row is None else str(row["aggregate_id"])
