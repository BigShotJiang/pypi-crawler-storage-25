"""Handler for the Mobius interview command."""

from __future__ import annotations

import sys
from collections.abc import Mapping
from pathlib import Path

import typer
from pydantic import BaseModel, ConfigDict

from mobius.cli import output
from mobius.cli.formatter import suggest_next
from mobius.cli.main import CliContext, ExitCode
from mobius.config import get_paths
from mobius.persistence.event_store import EventStore
from mobius.workflow.ids import readable_session_id
from mobius.workflow.interview import (
    AmbiguityGateError,
    InterviewFixture,
    build_ambiguity_ledger,
    build_closure_challenge,
    build_interview_handoff_metadata,
    build_second_opinion,
    compute_ambiguity_score,
    evaluate_interview_contract,
    event_interview_contract_metadata,
    fixture_from_template,
    infer_interview_contract_metadata,
    parse_fixture,
    question_answers,
    render_spec_yaml,
    run_deep_interactive_interview,
    run_interactive_interview,
)
from mobius.workflow.interview_milestones import milestone_from_score
from mobius.workflow.templates import TEMPLATE_NAMES, detect_template, get_template


class InterviewOutput(BaseModel):
    """Structured output for a completed interview."""

    model_config = ConfigDict(extra="forbid")

    session_id: str
    output: str
    ambiguity_score: float
    ambiguity_gate: float
    milestone: str = ""
    passed_gate: bool
    template: str = "blank"
    seed_ready: bool = False
    closure_blockers: list[str] = []
    interview_mode: str = ""


def run(
    context: CliContext,
    *,
    non_interactive: bool = False,
    input_path: Path | None = None,
    output_path: Path | None = None,
    template: str | None = None,
    project_type: str | None = None,
    goal: str | None = None,
    constraints: list[str] | None = None,
    success_criteria: list[str] | None = None,
    context_value: str | None = None,
    from_session: str | None = None,
    deep_metadata: Path | None = None,
    mode: str = "auto",
) -> None:
    """Run an interview and write a project spec.

    The command supports four modes:

    1. Non-interactive from fixture (``--non-interactive --input <fixture>``):
       reads a deterministic fixture file. Backward compatible.
    2. Non-interactive from CLI flags (``--non-interactive --goal ... \
       --constraint ... --success-criterion ...``): the agent passes
       extracted parameters directly. No fixture file required. Flags
       override fixture values when both are supplied.
    3. Scripted/interactive: prompts on stderr, reads answers from stdin.
       Auto-detects a template from the cwd unless ``--template`` is given.
    4. Re-run from previous spec: not yet supported (out of scope).
    """
    workspace = Path.cwd()
    output_path = output_path or workspace / "spec.yaml"

    try:
        normalized_mode = _resolve_interview_mode(mode, non_interactive=non_interactive)
        if normalized_mode == "agent":
            normalized_mode = "conversational"
        if normalized_mode not in {"quick", "deep", "conversational"}:
            msg = "mode d'interview doit être `auto`, `quick`, `deep`, `conversational` ou `agent`"
            raise ValueError(msg)
        if normalized_mode == "conversational":
            _run_conversational_interview(
                context,
                workspace=workspace,
                input_path=input_path,
                output_path=output_path,
                template=template,
                project_type=project_type,
                goal=goal,
                constraints=constraints,
                success_criteria=success_criteria,
                context_value=context_value,
            )
            return
        if non_interactive:
            using_flags = any(
                value is not None and value != []
                for value in (goal, constraints, success_criteria, context_value, template)
            )
            if input_path is None and not using_flags:
                output.write_error_line(
                    "non-interactive interview requires --input or --goal/--template; "
                    "see `mobius interview --help`"
                )
                raise typer.Exit(code=int(ExitCode.USAGE))
            fixture = _build_non_interactive_fixture(
                workspace=workspace,
                input_path=input_path,
                template=template,
                project_type=project_type,
                goal=goal,
                constraints=constraints,
                success_criteria=success_criteria,
                context_value=context_value,
                from_session=from_session,
                mobius_home=context.mobius_home,
            )
            generated_deep_metadata = None
        else:
            if normalized_mode == "deep":
                result = run_deep_interactive_interview(
                    workspace=workspace,
                    template_name=template,
                    project_type=project_type or "greenfield",
                )
                fixture = result.fixture
                generated_deep_metadata = result.deep_metadata
            else:
                fixture = run_interactive_interview(
                    workspace=workspace,
                    template_name=template,
                    project_type=project_type or "greenfield",
                )
                generated_deep_metadata = None
        score = compute_ambiguity_score(fixture)
        if fixture.is_brownfield and not fixture.context.strip():
            msg = "brownfield interview requires a non-empty context"
            raise ValueError(msg)
        score.raise_for_gate()
    except (AmbiguityGateError, ValueError) as exc:
        output.write_error_line(_human_error_message(exc))
        raise typer.Exit(code=int(ExitCode.VALIDATION)) from exc

    session_id = readable_session_id("interview", fixture.goal)
    paths = get_paths(context.mobius_home)
    output_path = output_path.expanduser().resolve()
    output_path.parent.mkdir(parents=True, exist_ok=True)
    combined_deep_metadata = _merge_cli_deep_metadata(
        generated_deep_metadata=generated_deep_metadata,
        deep_metadata_path=deep_metadata,
    )
    contract_metadata = dict(combined_deep_metadata)
    if generated_deep_metadata is None:
        _merge_missing_contract_metadata(
            contract_metadata,
            infer_interview_contract_metadata(fixture),
        )
    contract = evaluate_interview_contract(
        fixture,
        score=score,
        deep_metadata=contract_metadata,
    )
    handoff_metadata = build_interview_handoff_metadata(fixture, contract)
    if non_interactive and "metadata" in handoff_metadata:
        # In non-interactive mode the agent provides all data explicitly; heuristic
        # blockers (missing_non_goals, success_criteria_not_testable, …) do not apply.
        # Override so the written spec passes seed validation.
        metadata_value = handoff_metadata["metadata"]
        non_interactive_metadata = dict(metadata_value) if isinstance(metadata_value, dict) else {}
        non_interactive_metadata["interview_contract_seed_ready"] = "true"
        non_interactive_metadata["interview_contract_blockers"] = ""
        handoff_metadata = {**handoff_metadata, "metadata": non_interactive_metadata}
    if generated_deep_metadata is not None:
        spec_deep_metadata = dict(generated_deep_metadata)
        _merge_missing_contract_metadata(spec_deep_metadata, handoff_metadata)
        spec_deep_metadata.setdefault("interview_mode", normalized_mode)
    else:
        spec_deep_metadata = dict(handoff_metadata)
    _merge_missing_contract_metadata(combined_deep_metadata, spec_deep_metadata)

    spec_yaml = render_spec_yaml(
        session_id,
        fixture,
        score,
        deep_metadata_path=deep_metadata,
        deep_metadata=spec_deep_metadata,
    )

    with EventStore(paths.event_store) as store:
        store.create_session(
            session_id,
            runtime="interview",
            metadata={
                "mode": "non-interactive" if non_interactive else "interactive",
                "input": str(input_path) if input_path else "",
                "output": str(output_path),
                "template": fixture.template,
                "interview_mode": str(spec_deep_metadata.get("interview_mode") or normalized_mode),
                "seed_ready": contract.seed_ready,
                "closure_blockers": list(contract.closure_blockers),
            },
            status="running",
        )
        store.append_event(
            session_id,
            "interview.started",
            {
                "mode": "non-interactive" if non_interactive else "interactive",
                "input": str(input_path) if input_path else "",
                "project_type": fixture.project_type,
                "template": fixture.template,
                "interview_mode": str(spec_deep_metadata.get("interview_mode") or normalized_mode),
                "seed_ready": contract.seed_ready,
                "closure_blockers": list(contract.closure_blockers),
            },
        )
        for category, question, answer in question_answers(fixture):
            store.append_event(
                session_id,
                "interview.question_answered",
                {
                    "category": category,
                    "question": question,
                    "answer": answer,
                },
            )
        output_path.write_text(spec_yaml, encoding="utf-8")
        store.append_event(
            session_id,
            "interview.completed",
            {
                "ambiguity_score": score.score,
                "ambiguity_gate": score.threshold,
                "passed_gate": score.passed,
                "output": str(output_path),
                "template": fixture.template,
                "interview_mode": str(spec_deep_metadata.get("interview_mode") or normalized_mode),
                "seed_ready": contract.seed_ready,
                "closure_blockers": list(contract.closure_blockers),
                **handoff_metadata,
                **event_interview_contract_metadata(combined_deep_metadata),
            },
        )
        store.end_session(session_id, status="completed")

    payload = InterviewOutput(
        session_id=session_id,
        output=str(output_path),
        ambiguity_score=score.score,
        ambiguity_gate=score.threshold,
        milestone=milestone_from_score(score).value,
        passed_gate=score.passed,
        template=fixture.template,
        seed_ready=contract.seed_ready,
        closure_blockers=list(contract.closure_blockers),
        interview_mode=str(spec_deep_metadata.get("interview_mode") or normalized_mode),
    )
    if context.json_output:
        output.write_json(payload.model_dump_json())
        return
    if not non_interactive:
        sys.stderr.write(f"\n# Wrote {payload.output}\n")
        sys.stderr.flush()
    output.write_line(f"session_id={payload.session_id}")
    output.write_line(f"output={payload.output}")
    output.write_line(f"template={payload.template}")
    output.write_line(f"milestone={payload.milestone}")
    output.write_line(f"clarity={payload.ambiguity_score}/{payload.ambiguity_gate}")
    output.write_line(f"next_ready={str(payload.seed_ready).lower()}")
    if payload.interview_mode:
        output.write_line(f"interview_mode={payload.interview_mode}")
    if not context.json_output and payload.seed_ready:
        suggest_next("interview")
    elif not context.json_output and not payload.seed_ready and not non_interactive:
        sys.stderr.write(contract.human_diagnostic() + "\n")
        sys.stderr.flush()


def _run_conversational_interview(
    context: CliContext,
    *,
    workspace: Path,
    input_path: Path | None,
    output_path: Path,
    template: str | None,
    project_type: str | None,
    goal: str | None,
    constraints: list[str] | None,
    success_criteria: list[str] | None,
    context_value: str | None,
) -> None:
    """Run the multi-perspective v3a interviewer through the normal interview surface."""
    from mobius.workflow.interview_v3a.runner import run_interview as run_v3a_interview
    from mobius.workflow.interview_v3a.runner import run_live_interview as run_live_v3a_interview

    seed_fixture = _build_non_interactive_fixture(
        workspace=workspace,
        input_path=input_path,
        template=template,
        project_type=project_type,
        goal=goal,
        constraints=constraints,
        success_criteria=success_criteria,
        context_value=context_value,
        from_session=None,
        mobius_home=context.mobius_home,
    )
    intent = seed_fixture.goal
    session_id = readable_session_id("interview", intent)
    paths = get_paths(context.mobius_home)
    output_dir = paths.home / "interviews" / session_id
    live_tty = sys.stdin.isatty()
    if live_tty:
        result = run_live_v3a_interview(
            intent=intent,
            run_id=session_id,
            output_dir=output_dir,
            initial_fixture=seed_fixture,
        )
    else:
        stdin_answers = _read_conversational_answers_from_stdin()
        if stdin_answers:
            answers_for_v3a = stdin_answers
            auto_confirm = False
        else:
            answers_for_v3a = [*seed_fixture.constraints, *seed_fixture.success, ":enough"]
            auto_confirm = True
        result = run_v3a_interview(
            intent=intent,
            run_id=session_id,
            output_dir=output_dir,
            answers=answers_for_v3a,
            auto_confirm=auto_confirm,
        )
    fixture = InterviewFixture(
        project_type=seed_fixture.project_type,
        goal=result.fixture.goal,
        constraints=list(dict.fromkeys([*seed_fixture.constraints, *result.fixture.constraints])),
        success=list(dict.fromkeys([*seed_fixture.success, *result.fixture.success])),
        context=seed_fixture.context,
        template=seed_fixture.template or result.fixture.template,
    )
    if live_tty:
        session_id = readable_session_id("interview", fixture.goal)
    score = compute_ambiguity_score(fixture)
    if fixture.is_brownfield and not fixture.context.strip():
        msg = "brownfield interview requires a non-empty context"
        raise ValueError(msg)
    score.raise_for_gate()
    contract_seed_metadata: dict[str, object] = dict(infer_interview_contract_metadata(fixture))
    contract_seed_metadata["assumptions"] = [
        {
            "statement": "Les critères listés prouvent le premier livrable localement.",
            "status": "unverified",
        }
    ]
    contract = evaluate_interview_contract(
        fixture,
        score=score,
        deep_metadata=contract_seed_metadata,
    )
    handoff_metadata = build_interview_handoff_metadata(fixture, contract)
    second_opinion = build_second_opinion(
        fixture,
        score=score,
        deep_metadata={**contract_seed_metadata, **handoff_metadata},
    )
    contract_with_opinion = evaluate_interview_contract(
        fixture,
        score=score,
        deep_metadata={
            **contract_seed_metadata,
            **handoff_metadata,
            "second_opinion": second_opinion,
        },
    )
    closure_challenge = build_closure_challenge(
        fixture,
        score,
        contract_with_opinion,
        second_opinion,
    )
    contract = evaluate_interview_contract(
        fixture,
        score=score,
        deep_metadata={
            **contract_seed_metadata,
            **handoff_metadata,
            "second_opinion": second_opinion,
            "closure_challenge": closure_challenge,
        },
    )
    handoff_metadata = build_interview_handoff_metadata(fixture, contract)
    question_ledger = result.question_ledger or _question_ledger_from_fixture(fixture)
    conversation_memory = result.conversation_memory or _conversation_memory_from_fixture(fixture)
    ambiguity_ledger = build_ambiguity_ledger(fixture, score, contract)
    deep_metadata = {
        "interview_mode": "conversational",
        "branches_explored": 3,
        "concepts": [
            {"name": "socrate", "description": "questions and convergence"},
            {"name": "avocat", "description": "edge-case challenge"},
            {"name": "architecte", "description": "options and trade-offs"},
            {"name": "transcript", "description": str(result.transcript_path)},
            {"name": "fixture", "description": str(result.fixture_path)},
        ],
        "question_ledger": question_ledger,
        "conversation_memory": conversation_memory,
        "second_opinion": second_opinion,
        "closure_challenge": closure_challenge,
        "ambiguity_ledger": ambiguity_ledger,
        **contract_seed_metadata,
        **handoff_metadata,
    }

    spec_yaml = render_spec_yaml(
        session_id,
        fixture,
        score,
        deep_metadata=deep_metadata,
    )
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(spec_yaml, encoding="utf-8")

    event_payload = {
        "mode": "conversational",
        "input": str(input_path) if input_path else "",
        "project_type": fixture.project_type,
        "template": fixture.template,
        "interview_mode": "conversational",
        "perspectives": ["socrate", "avocat", "architecte"],
        "transcript": str(result.transcript_path),
        "fixture": str(result.fixture_path),
        "seed_ready": contract.seed_ready,
        "closure_blockers": list(contract.closure_blockers),
    }
    with EventStore(paths.event_store) as store:
        store.create_session(
            session_id,
            runtime="interview",
            metadata={**event_payload, "output": str(output_path)},
            status="running",
        )
        store.append_event(session_id, "interview.started", event_payload)
        store.append_event(
            session_id,
            "interview.perspectives_completed",
            {
                "perspectives": ["socrate", "avocat", "architecte"],
                "turns": result.turns,
                "transcript": str(result.transcript_path),
                "fixture": str(result.fixture_path),
                "human_confirmed": result.human_confirmed,
                "socrate_proposed_done": result.socrate_proposed_done,
                "seed_ready": contract.seed_ready,
                "closure_blockers": list(contract.closure_blockers),
                **event_interview_contract_metadata(deep_metadata),
            },
        )
        for category, question, answer in question_answers(fixture):
            store.append_event(
                session_id,
                "interview.question_answered",
                {"category": category, "question": question, "answer": answer},
            )
        store.append_event(
            session_id,
            "interview.completed",
            {
                "ambiguity_score": score.score,
                "ambiguity_gate": score.threshold,
                "passed_gate": score.passed,
                "output": str(output_path),
                "template": fixture.template,
                "interview_mode": "conversational",
                "perspectives": ["socrate", "avocat", "architecte"],
                "turns": result.turns,
                "transcript": str(result.transcript_path),
                "fixture": str(result.fixture_path),
                "seed_ready": contract.seed_ready,
                "closure_blockers": list(contract.closure_blockers),
                **handoff_metadata,
            },
        )
        store.end_session(session_id, status="completed")

    payload = InterviewOutput(
        session_id=session_id,
        output=str(output_path),
        ambiguity_score=score.score,
        ambiguity_gate=score.threshold,
        milestone=milestone_from_score(score).value,
        passed_gate=score.passed,
        template=fixture.template,
        seed_ready=contract.seed_ready,
        closure_blockers=list(contract.closure_blockers),
        interview_mode="conversational",
    )
    if context.json_output:
        output.write_json(payload.model_dump_json())
        return
    output.write_line(f"session_id={payload.session_id}")
    output.write_line(f"output={payload.output}")
    output.write_line(f"template={payload.template}")
    output.write_line("interview_mode=conversational")
    output.write_line("perspectives=socrate,avocat,architecte")
    output.write_line(f"milestone={payload.milestone}")
    output.write_line(f"clarity={payload.ambiguity_score}/{payload.ambiguity_gate}")
    output.write_line(f"next_ready={str(payload.seed_ready).lower()}")
    if not context.json_output and payload.seed_ready:
        suggest_next("interview")
    elif not context.json_output and not payload.seed_ready:
        sys.stderr.write(contract.human_diagnostic() + "\n")
        sys.stderr.flush()


def _question_ledger_from_fixture(fixture: InterviewFixture) -> list[dict[str, object]]:
    return [
        {
            "ordinal": index,
            "key": category,
            "category": category,
            "question": question,
            "answer": {"answered": bool(answer), "kind": "text", "text": answer},
            "routing_path": "v3a_scripted",
        }
        for index, (category, question, answer) in enumerate(question_answers(fixture), start=1)
    ]


def _conversation_memory_from_fixture(fixture: InterviewFixture) -> list[dict[str, object]]:
    return [
        {
            "round_index": index,
            "question_key": category,
            "question": question,
            "answer": answer,
            "score_avant": 0.0,
            "score_apres": 0.0,
            "because": "scripted fixture answer",
            "routing_path": "v3a_scripted",
            "source": "fixture",
            "ambiguity_before": 0.0,
            "ambiguity_after": 0.0,
            "closure_blockers": [],
            "prochaine_question": "",
            "decisions_ouvertes": [],
            "branch": category,
        }
        for index, (category, question, answer) in enumerate(question_answers(fixture), start=1)
    ]


def _read_conversational_answers_from_stdin() -> list[str]:
    if sys.stdin.isatty():
        return []
    answers: list[str] = []
    try:
        for raw in sys.stdin:
            value = raw.rstrip("\n").strip()
            if value:
                answers.append(value)
    except OSError:
        return []
    return answers


def _merge_cli_deep_metadata(
    *,
    generated_deep_metadata: dict[str, object] | None,
    deep_metadata_path: Path | None,
) -> dict[str, object]:
    """Load the metadata visible to CLI/event contract checks without mutating inputs."""
    merged: dict[str, object] = dict(generated_deep_metadata or {})
    if deep_metadata_path is not None:
        import json

        raw = deep_metadata_path.read_text(encoding="utf-8")
        loaded = json.loads(raw)
        if isinstance(loaded, dict):
            merged.update(loaded)
    return merged


def _merge_missing_contract_metadata(
    target: dict[str, object],
    generated: Mapping[str, object],
) -> None:
    """Add generated contract fields without replacing caller-provided metadata."""
    for key, value in generated.items():
        if key == "metadata" and isinstance(value, dict):
            existing = target.get("metadata")
            if isinstance(existing, dict):
                merged = dict(value)
                merged.update(existing)
                target["metadata"] = merged
            else:
                target[key] = value
            continue
        target.setdefault(key, value)


def _build_non_interactive_fixture(
    *,
    workspace: Path,
    input_path: Path | None,
    template: str | None,
    project_type: str | None,
    goal: str | None,
    constraints: list[str] | None,
    success_criteria: list[str] | None,
    context_value: str | None,
    from_session: str | None = None,
    mobius_home: Path | None = None,
) -> InterviewFixture:
    """Build a fixture from a fixture file, CLI flags, or both.

    Resolution order (later wins for non-empty values):

    1. Template defaults — if ``--template`` is given (or auto-detected when
       no fixture and no goal is provided).
    2. Fixture file — when ``--input`` is supplied.
    3. CLI flags (``--goal``, ``--constraint``, ``--success-criterion``,
       ``--context``, ``--project-type``, ``--template``).

    At least one of ``--input``, ``--goal``, or a ``--template`` must be
    supplied so the resulting fixture has a non-trivial goal.
    """
    # When inline flags are provided without a fixture file, default to "blank"
    # instead of auto-detecting from the workspace which may be misleading.
    effective_template = template
    if input_path is None and template is None and goal is not None:
        effective_template = "blank"

    base = _initial_fixture(
        workspace=workspace,
        input_path=input_path,
        template_name=effective_template,
        project_type=project_type or "greenfield",
    )

    final_template = (template or base.template or "blank").strip().lower() or "blank"
    if final_template not in TEMPLATE_NAMES:
        msg = (
            f"template inconnu `{final_template}`. "
            f"Templates autorisés : {', '.join(TEMPLATE_NAMES)}"
        )
        raise ValueError(msg)

    final_project_type = (project_type or base.project_type or "greenfield").strip().lower()
    if final_project_type not in {"greenfield", "brownfield"}:
        msg = "project_type doit être `greenfield` ou `brownfield`"
        raise ValueError(msg)

    final_goal = goal.strip() if goal is not None else base.goal
    final_constraints = (
        [item.strip() for item in constraints if item.strip()]
        if constraints is not None
        else list(base.constraints)
    )
    final_success = (
        [item.strip() for item in success_criteria if item.strip()]
        if success_criteria is not None
        else list(base.success)
    )
    final_context = _resolve_brownfield_context(
        explicit=context_value,
        from_session=from_session,
        base=base.context,
        workspace=workspace,
        project_type=final_project_type,
        mobius_home=mobius_home,
    )

    return InterviewFixture(
        project_type=final_project_type,
        goal=final_goal,
        constraints=final_constraints,
        success=final_success,
        context=final_context,
        template=final_template,
    )


def _resolve_interview_mode(mode: str, *, non_interactive: bool) -> str:
    normalized = mode.strip().lower()
    if normalized in {"agentic", "multi-agent", "multi_agent"}:
        return "conversational"
    if normalized != "auto":
        return normalized
    if non_interactive:
        return "quick"
    return "conversational" if sys.stdin.isatty() else "quick"


def _initial_fixture(
    *,
    workspace: Path,
    input_path: Path | None,
    template_name: str | None,
    project_type: str,
) -> InterviewFixture:
    """Return the starting fixture: from --input, or from a template default."""
    if input_path is not None:
        return parse_fixture(input_path)
    name = template_name or detect_template(workspace)
    return fixture_from_template(get_template(name), project_type=project_type)


def _resolve_brownfield_context(
    *,
    explicit: str | None,
    from_session: str | None,
    base: str,
    workspace: Path,
    project_type: str,
    mobius_home: Path | None,
) -> str:
    if explicit is not None and from_session and mobius_home:
        prev = _load_context_from_session(from_session, mobius_home)
        if prev:
            return prev + " " + explicit.strip()
        return explicit.strip()
    if explicit is not None:
        return explicit.strip()
    if from_session and mobius_home:
        prev = _load_context_from_session(from_session, mobius_home)
        if prev:
            return prev
    if base:
        return base
    if project_type == "brownfield":
        from mobius.workflow.scan import context_from_workspace

        return context_from_workspace(workspace)
    return ""


def _load_context_from_session(session_id: str, mobius_home: Path) -> str:
    from mobius.config import get_paths
    from mobius.persistence.event_store import EventStore

    paths = get_paths(mobius_home)
    if not paths.event_store.exists():
        return ""
    try:
        with EventStore(paths.event_store, read_only=True) as store:
            events = store.read_events(session_id)
            for e in events:
                if e.type == "interview.question_answered":
                    data = e.payload_data
                    if data.get("category") == "context":
                        answer = data.get("answer", "")
                        return answer if isinstance(answer, str) else ""
    except Exception:
        return ""
    return ""


def _human_error_message(exc: Exception) -> str:
    message = str(exc)
    prefix = "ambiguity exceeds gate: "
    if isinstance(exc, AmbiguityGateError) and message.startswith(prefix):
        return message[len(prefix) :]
    return message
