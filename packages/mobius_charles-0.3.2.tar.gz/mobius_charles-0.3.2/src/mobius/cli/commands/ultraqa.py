"""Handler for the Mobius ultraqa command."""

from __future__ import annotations

import typer

from mobius.cli import output
from mobius.cli.formatter import get_formatter
from mobius.cli.main import CliContext, ExitCode
from mobius.config import get_paths
from mobius.workflow.ultraqa import (
    UltraQAResult,
    UltraQASourceNotFoundError,
    explain_ultraqa,
    run_ultraqa,
)


def run(
    context: CliContext,
    run_id: str | None,
    *,
    max_iterations: int = 3,
    dry_run: bool = False,
    json_output: bool = False,
) -> None:
    """Run or explain the UltraQA bounded fix loop."""
    paths = get_paths(context.mobius_home)
    try:
        if dry_run:
            result = explain_ultraqa(run_id, max_iterations=max_iterations)
        else:
            result = run_ultraqa(paths, run_id, max_iterations=max_iterations)
    except UltraQASourceNotFoundError as exc:
        output.write_error_line(str(exc))
        raise typer.Exit(code=int(ExitCode.NOT_FOUND)) from exc
    formatter = get_formatter(context, json_output=json_output)
    formatter.emit(result_to_payload(result), text=lambda: _write_markdown(result))
    if result.exit_code != int(ExitCode.OK):
        raise typer.Exit(code=result.exit_code)


def result_to_payload(result: UltraQAResult) -> dict[str, object]:
    """Convert a workflow result to CLI JSON-safe data."""
    return {
        "dry_run": result.dry_run,
        "ultraqa_id": result.ultraqa_id,
        "run_id": result.run_id,
        "max_iterations": result.max_iterations,
        "initial_verdict": result.initial_verdict,
        "final_verdict": result.final_verdict,
        "fixed": result.fixed,
        "stop_reason": result.stop_reason,
        "completed": result.completed,
        "ralph_id": result.ralph_id,
        "ralph_stop_reason": result.ralph_stop_reason,
        "iteration_progress": [
            {
                "iteration": progress.iteration,
                "run_id": progress.run_id,
                "qa_verdict": progress.qa_verdict,
                "evolution_id": progress.evolution_id,
                "evolution_reason": progress.evolution_reason,
                "criteria": [
                    {
                        "criterion_id": criterion.criterion_id,
                        "label": criterion.label,
                        "before_verdict": criterion.before_verdict,
                        "after_verdict": criterion.after_verdict,
                        "status": criterion.status,
                    }
                    for criterion in progress.criteria
                ],
            }
            for progress in result.iteration_progress
        ],
        "steps": result.steps,
        "next_command": result.next_command,
    }


def _write_markdown(result: UltraQAResult) -> None:
    output.write_line("# Mobius UltraQA")
    output.write_line("")
    if result.ultraqa_id:
        output.write_line(f"UltraQA: {result.ultraqa_id}")
    output.write_line(f"Run: {result.run_id or 'latest introuvable'}")
    output.write_line(f"Itérations max: {result.max_iterations}")
    output.write_line(f"Stop: {result.stop_reason}")
    output.write_line(f"Fixed: {str(result.fixed).lower()}")
    if result.initial_verdict:
        output.write_line(f"QA initial: {result.initial_verdict}")
    if result.final_verdict:
        output.write_line(f"QA final: {result.final_verdict}")
    if result.ralph_id:
        output.write_line(f"Ralph: {result.ralph_id}")
    if result.iteration_progress:
        output.write_line("")
        output.write_line("## Progression Ralph")
        output.write_line("| Itération | QA | Évolution | Raison |")
        output.write_line("| --- | --- | --- | --- |")
        for progress in result.iteration_progress:
            output.write_line(
                "| "
                f"{progress.iteration} | {progress.qa_verdict} | "
                f"{progress.evolution_id or '-'} | {progress.evolution_reason or '-'} |"
            )
        if any(progress.criteria for progress in result.iteration_progress):
            output.write_line("")
            output.write_line("## Progression par iteration")
            for progress in result.iteration_progress:
                if not progress.criteria:
                    continue
                output.write_line("")
                output.write_line(f"### Iteration {progress.iteration}")
                output.write_line("| Critere | Avant | Apres | Statut |")
                output.write_line("| --- | --- | --- | --- |")
                for criterion in progress.criteria:
                    output.write_line(
                        "| "
                        f"{criterion.label} | {criterion.before_verdict or '-'} | "
                        f"{criterion.after_verdict} | {criterion.status} |"
                    )
    output.write_line("")
    output.write_line("## Boucle")
    for step in result.steps:
        output.write_line(f"- {step}")
    if result.next_command:
        output.write_line(f"Commande: {result.next_command}")
