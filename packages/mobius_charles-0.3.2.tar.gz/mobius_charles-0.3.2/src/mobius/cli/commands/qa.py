"""Handler for the Mobius qa command."""

from __future__ import annotations

import typer

from mobius.cli import output
from mobius.cli.formatter import get_formatter
from mobius.cli.main import CliContext
from mobius.cli.session_inspector import mark_stale_session_if_needed
from mobius.config import get_paths
from mobius.core.types import ExitCode
from mobius.workflow.qa import DeltaChange, QAReport, Verdict, evaluate_run_qa


def run(
    context: CliContext,
    run_id: str | None = None,
    *,
    offline: bool = True,
    json_output: bool = False,
    suggest: bool = False,
    sequential: bool = False,
    max_workers: int | None = None,
) -> None:
    """Run QA checks for ``run_id``."""
    if run_id is None:
        from mobius.cli.command_registry import _resolve_latest_run_id

        run_id = _resolve_latest_run_id(context)
        if run_id is None:
            output.write_error_line("Aucun run trouvé. Lancez : mobius go 'votre idée'")
            raise typer.Exit(code=int(ExitCode.NOT_FOUND))
    paths = get_paths(context.mobius_home)
    mark_stale_session_if_needed(paths, run_id)
    report = evaluate_run_qa(
        paths.event_store,
        run_id,
        online=not offline,
        suggest=suggest,
        sequential=sequential,
        max_workers=max_workers,
    )
    if report is None:
        output.write_error_line(f"run introuvable : {run_id}")
        raise typer.Exit(code=int(ExitCode.NOT_FOUND))

    formatter = get_formatter(context, json_output=json_output)
    formatter.emit(report, text=lambda: _write_markdown(report))

    if report.summary.global_verdict == Verdict.FAIL:
        raise typer.Exit(code=int(ExitCode.GENERIC_ERROR))


_CHANGE_SYMBOLS = {
    DeltaChange.STABLE: "=",
    DeltaChange.IMPROVED: "+",
    DeltaChange.REGRESSED: "!",
    DeltaChange.STILL_FAILING: "-",
    DeltaChange.NEW: "*",
}


def _write_markdown(report: QAReport) -> None:
    output.write_line(f"# QA {report.run_id}")
    output.write_line("")
    output.write_line(f"- Mode: `{report.mode}`")
    output.write_line(f"- État: `{report.state}`")
    output.write_line(f"- Contrôles totaux: `{report.summary.total}`")
    output.write_line(f"- Contrôles réussis: `{report.summary.passed}`")
    output.write_line(f"- Contrôles échoués: `{report.summary.failed}`")
    output.write_line(f"- Contrôles non vérifiés: `{report.summary.unverified}`")
    output.write_line(f"- Verdict global: `{report.summary.global_verdict.value}`")
    if report.execution:
        output.write_line(f"- Durée totale QA: `{report.execution.total_duration_ms} ms`")
        output.write_line(
            "- Durée séquentielle estimée: "
            f"`{report.execution.sequential_duration_ms} ms`"
        )
        output.write_line(
            f"- Speedup vs séquentiel: `{report.execution.speedup_vs_sequential:.2f}x`"
        )
    output.write_line("")
    output.write_line("| Contrôle | Résultat | Détail |")
    output.write_line("| --- | --- | --- |")
    for result in report.results:
        output.write_line(f"| {result.label} | {result.verdict.value} | {result.detail} |")

    failed_with_output = [r for r in report.results if r.output and r.verdict == Verdict.FAIL]
    if failed_with_output:
        output.write_line("")
        output.write_line("## Sortie des commandes échouées")
        for result in failed_with_output:
            output.write_line("")
            output.write_line(f"### {result.label}")
            output.write_line("```")
            output.write_line(result.output or "")
            output.write_line("```")

    if report.delta:
        output.write_line("")
        output.write_line(
            f"## Progression (parent: `{report.progression.parent_run_id}`)"
            if report.progression
            else "## Progression"
        )
        output.write_line("")
        output.write_line("| Critère | Avant | Après | Delta |")
        output.write_line("| --- | --- | --- | --- |")
        for d in report.delta:
            symbol = _CHANGE_SYMBOLS.get(d.change, "?")
            prev = d.previous_verdict.value if d.previous_verdict else "—"
            output.write_line(
                f"| {d.label} | {prev} | {d.current_verdict.value} | {symbol} {d.change.value} |"
            )

        regressions = [d for d in report.delta if d.change == DeltaChange.REGRESSED]
        if regressions:
            output.write_line("")
            output.write_line(f"**RÉGRESSIONS DÉTECTÉES ({len(regressions)}):**")
            for r in regressions:
                prev = r.previous_verdict.value if r.previous_verdict else "?"
                output.write_line(f"- {r.label}: {prev} → {r.current_verdict.value}")

    if report.progression:
        output.write_line("")
        prev_score = f"{report.progression.previous_passed}/{report.progression.previous_total}"
        curr_score = f"{report.progression.current_passed}/{report.progression.current_total}"
        output.write_line(f"Score: {prev_score} → {curr_score}")

    if report.suggestions:
        output.write_line("")
        output.write_line("## Suggestions de commandes de vérification")
        for suggestion in report.suggestions:
            output.write_line("")
            output.write_line(f"### Critère {suggestion.criterion_index}")
            output.write_line("```yaml")
            output.write_line(f"- command: {json_quote(suggestion.command)}")
            output.write_line(f"  criterion_ref: {json_quote(suggestion.criterion_ref)}")
            output.write_line("  timeout_s: 60")
            output.write_line("```")
            output.write_line(f"Raison: {suggestion.rationale}")


def json_quote(value: str) -> str:
    """Return a YAML-compatible JSON string literal."""
    import json

    return json.dumps(value, ensure_ascii=False)
