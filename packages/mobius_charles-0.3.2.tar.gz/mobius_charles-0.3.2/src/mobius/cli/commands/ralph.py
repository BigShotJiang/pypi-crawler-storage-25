"""Handler for the Mobius ralph command."""

from __future__ import annotations

import typer

from mobius.cli import output
from mobius.cli.formatter import get_formatter
from mobius.cli.main import CliContext, ExitCode
from mobius.config import get_paths
from mobius.workflow.launcher import WorkerConfig, WorkerLauncher
from mobius.workflow.ralph import (
    PreparedRalph,
    RalphIteration,
    RalphResult,
    RalphSourceNotFoundError,
    execute_ralph,
    explain_ralph,
    prepare_ralph,
    resume_ralph,
    run_foreground_session,
    run_ralph,
    start_detached_worker,
)


def run(
    context: CliContext,
    run_id: str | None,
    *,
    max_iterations: int = 10,
    dry_run: bool = False,
    detached: bool = False,
    resume: str | None = None,
    json_output: bool = False,
) -> None:
    """Run or explain the persistent Mobius convergence loop."""
    paths = get_paths(context.mobius_home)
    try:
        if dry_run:
            result = explain_ralph(run_id, max_iterations=max_iterations)
        elif resume is not None:
            result = resume_ralph(paths, resume)
        elif detached:
            prepared = prepare_ralph(paths, run_id, max_iterations=max_iterations)
            WorkerLauncher(paths).launch_for_cli(
                _ralph_worker_config(prepared),
                detach=True,
                foreground=False,
                json_output=json_output or context.json_output,
                usage_exit_code=int(ExitCode.USAGE),
            )
            return
        else:
            result = run_ralph(paths, run_id, max_iterations=max_iterations)
    except RalphSourceNotFoundError as exc:
        output.write_error_line(str(exc))
        raise typer.Exit(code=int(ExitCode.NOT_FOUND)) from exc
    formatter = get_formatter(context, json_output=json_output)
    formatter.emit(result_to_payload(result), text=lambda: _write_markdown(result))
    if result.exit_code != int(ExitCode.OK):
        raise typer.Exit(code=result.exit_code)


def result_to_payload(result: RalphResult) -> dict[str, object]:
    """Convert a workflow result to CLI JSON-safe data."""
    return {
        "dry_run": result.dry_run,
        "ralph_id": result.ralph_id,
        "run_id": result.run_id,
        "max_iterations": result.max_iterations,
        "stop_reason": result.stop_reason,
        "completed": result.completed,
        "steps": result.steps,
        "iterations": [_iteration_payload(item) for item in result.iterations],
        "next_command": result.next_command,
    }


def _iteration_payload(item: RalphIteration) -> dict[str, object]:
    return {
        "iteration": item.iteration,
        "run_id": item.run_id,
        "qa_verdict": item.qa_verdict,
        "evolution_id": item.evolution_id,
        "evolution_reason": item.evolution_reason,
        "persona": item.persona,
        "persona_reason": item.persona_reason,
    }


def _write_markdown(result: RalphResult) -> None:
    output.write_line("# Mobius ralph")
    output.write_line("")
    if result.ralph_id:
        output.write_line(f"Ralph: {result.ralph_id}")
    output.write_line(f"Run: {result.run_id or 'latest introuvable'}")
    output.write_line(f"Itérations max: {result.max_iterations}")
    output.write_line(f"Stop: {result.stop_reason}")
    output.write_line("")
    output.write_line("## Boucle")
    for step in result.steps:
        output.write_line(f"- {step}")
    if result.next_command:
        output.write_line(f"Commande: {result.next_command}")
    if result.iterations:
        output.write_line("")
        output.write_line("## Itérations")
        for item in result.iterations:
            line = f"- {item.iteration}: QA={item.qa_verdict}"
            if item.evolution_id:
                reason = item.evolution_reason or "raison inconnue"
                line += f", evolve={item.evolution_id} ({reason})"
            output.write_line(line)
            if item.persona:
                output.write_line(f"  Persona suggérée: {item.persona} — {item.persona_reason}")


def worker_ralph(context: CliContext, *, ralph_id: str) -> None:
    """Execute a prepared Ralph session from the private ``_worker`` command."""
    paths = get_paths(context.mobius_home)
    exit_code = execute_ralph(paths, ralph_id, stream_events=True)
    if exit_code != int(ExitCode.OK):
        raise typer.Exit(code=exit_code)


def _ralph_worker_config(prepared: PreparedRalph) -> WorkerConfig[PreparedRalph]:
    return WorkerConfig(
        name="ralph",
        prepared=prepared,
        run_foreground=run_foreground_session,
        start_detached=start_detached_worker,
        payload_factory=lambda worker, result: {
            "ralph_id": worker.ralph_id,
            "source_run_id": worker.source_run_id,
            "mode": result.mode,
            "max_iterations": worker.max_iterations,
            "pid": result.pid,
            "log": result.log,
        },
        plain_output=lambda worker: worker.ralph_id,
        success_exit_code=int(ExitCode.OK),
    )
