"""Handlers for the Mobius status command."""

from __future__ import annotations

import json
import time
from dataclasses import dataclass
from pathlib import Path
from typing import NoReturn

from pydantic import BaseModel, ConfigDict
from rich.console import RenderableType

from mobius.cli import output
from mobius.cli.formatter import get_formatter
from mobius.cli.main import CliContext, ExitCode
from mobius.cli.session_inspector import (
    EventStoreSessionAdapter,
    RunStatus,
    SessionInspector,
)
from mobius.cli.session_inspector import (
    mark_stale_session_if_needed as mark_stale_session,
)
from mobius.config import MobiusPaths, get_paths
from mobius.persistence.event_store import EventRecord, EventStore
from mobius.workflow.evolve import get_evolution_paths
from mobius.workflow.lifecycle import is_terminal_state
from mobius.workflow.run import get_run_paths

_FOLLOW_INTERVAL_SECONDS = 0.2


class StatusOutput(BaseModel):
    """Structured status output for store-level status checks."""

    model_config = ConfigDict(extra="forbid")

    event_store: str
    read_only: bool
    migrations_applied: bool
    integrity_check: str
    event_count: int


class RunStatusOutput(BaseModel):
    """Structured status output for a run."""

    model_config = ConfigDict(extra="forbid")

    run_id: str
    state: str
    started_at: str
    last_event_at: str


@dataclass(frozen=True)
class DashboardStatus:
    """EventStore-backed details used by the Rich status dashboard."""

    session_id: str
    runtime: str
    state: str
    started_at: str
    last_event_at: str
    event_count: int
    recent_events: list[EventRecord]


def run(
    context: CliContext,
    run_id: str | None = None,
    *,
    read_only: bool = False,
    json_output: bool = False,
    follow: bool = False,
    rich: bool = False,
) -> None:
    """Open the event store and report either store health or run status."""
    paths = get_paths(context.mobius_home)
    inspector = _session_inspector(paths)
    if follow:
        if run_id is None:
            output.write_error_line("status --follow exige un run id")
            raise SystemExit(int(ExitCode.USAGE))
        with EventStore(paths.event_store, read_only=read_only):
            run_id = _resolve_run_id(inspector, run_id)
        output.write_error_line(
            f"following {run_id} (poll interval {int(_FOLLOW_INTERVAL_SECONDS * 1000)}ms; "
            "press Ctrl-C to stop)"
        )
        _follow_run(
            paths.event_store,
            paths,
            inspector,
            run_id=run_id,
            read_only=read_only,
            rich_output=rich and not json_output,
        )
        return

    if run_id is not None and not read_only:
        with EventStore(paths.event_store):
            run_id = _resolve_run_id(inspector, run_id)
        inspector.mark_stale_session_if_needed(run_id)

    with EventStore(paths.event_store, read_only=read_only) as store:
        if run_id is not None:
            run_id = _resolve_run_id(inspector, run_id)
            run_status = inspector.read_run_status(run_id)
            run_payload = _to_run_status_output(run_status) if run_status is not None else None
            if run_payload is None:
                _raise_not_found(run_id)
            formatter = get_formatter(context, json_output=json_output)
            if rich and not formatter.json_output:
                dashboard = _read_dashboard_status(store, run_id)
                _write_rich_dashboard(dashboard)
            else:
                formatter.emit(run_payload, text=lambda: _write_run_markdown(run_payload))
            return

        migration_count = store.connection.execute(
            "SELECT count(*) FROM schema_migrations"
        ).fetchone()
        event_count = store.connection.execute("SELECT count(*) FROM events").fetchone()
        status_payload = StatusOutput(
            event_store=str(paths.event_store),
            read_only=read_only,
            migrations_applied=int(migration_count[0]) > 0,
            integrity_check=store.integrity_check(),
            event_count=int(event_count[0]),
        )


    formatter = get_formatter(context, json_output=json_output)
    if rich and not formatter.json_output:
        _write_rich_store_status(status_payload)
    else:
        formatter.emit(status_payload, text=lambda: _write_store_status(status_payload))
    return


def _follow_run(
    event_store_path: Path,
    paths: MobiusPaths,
    inspector: SessionInspector,
    *,
    run_id: str,
    read_only: bool,
    rich_output: bool = False,
) -> None:
    cursor = 0
    saw_session = False
    pending_run_files = _has_pending_run_files(paths, run_id)

    while True:
        if not read_only:
            inspector.mark_stale_session_if_needed(run_id)

        with EventStore(event_store_path, read_only=read_only) as store:
            run_status = inspector.read_run_status(run_id)
            run_payload = _to_run_status_output(run_status) if run_status is not None else None
            if run_payload is None:
                if saw_session or not pending_run_files:
                    _raise_not_found(run_id)
                time.sleep(_FOLLOW_INTERVAL_SECONDS)
                continue

            saw_session = True
            events = _read_events_after_cursor(store, run_id, cursor)
            if rich_output:
                _write_live_rich_dashboard(event_store_path, run_id, read_only=read_only)
                return

            for event in events:
                output.write_line(_format_event_delta(event))
                cursor = max(cursor, event.sequence)

            if is_terminal_state(run_payload.state):
                _write_run_markdown(run_payload)
                return

        time.sleep(_FOLLOW_INTERVAL_SECONDS)


def _session_inspector(paths: MobiusPaths) -> SessionInspector:
    return SessionInspector(
        state_dir=paths.state_dir,
        adapter=EventStoreSessionAdapter(paths.event_store),
    )


def _to_run_status_output(status: RunStatus | None) -> RunStatusOutput | None:
    if status is None:
        return None
    return RunStatusOutput(
        run_id=status.run_id,
        state=status.state,
        started_at=status.started_at,
        last_event_at=status.last_event_at,
    )


def _resolve_run_id(inspector: SessionInspector, run_id: str) -> str:
    resolved = inspector.resolve_run_id(run_id)
    if resolved is None:
        _raise_not_found(run_id)
    if not isinstance(resolved, str):
        candidates = ", ".join(resolved)
        output.write_error_line(f"préfixe de run ambigu : {run_id}; candidats : {candidates}")
        raise SystemExit(int(ExitCode.USAGE))
    return resolved


def _read_events_after_cursor(
    store: EventStore,
    run_id: str,
    cursor: int,
) -> list[EventRecord]:
    rows = store.connection.execute(
        """
        SELECT event_id, aggregate_id, sequence, type, payload, created_at
        FROM events
        WHERE aggregate_id = ? AND sequence > ?
        ORDER BY sequence ASC
        """,
        (run_id, cursor),
    ).fetchall()
    return [
        EventRecord(
            event_id=str(row["event_id"]),
            aggregate_id=str(row["aggregate_id"]),
            sequence=int(row["sequence"]),
            type=str(row["type"]),
            payload=str(row["payload"]),
            created_at=str(row["created_at"]),
        )
        for row in rows
    ]



def _read_dashboard_status(store: EventStore, session_id: str) -> DashboardStatus:
    session = store.connection.execute(
        """
        SELECT session_id, runtime, status, started_at
        FROM sessions
        WHERE session_id = ?
        """,
        (session_id,),
    ).fetchone()
    if session is None:
        _raise_not_found(session_id)
    events = store.read_events(session_id)
    last_event_at = events[-1].created_at if events else str(session["started_at"])
    return DashboardStatus(
        session_id=str(session["session_id"]),
        runtime=str(session["runtime"]),
        state=str(session["status"]),
        started_at=str(session["started_at"]),
        last_event_at=last_event_at,
        event_count=len(events),
        recent_events=events[-8:],
    )


def _write_rich_store_status(status_payload: StatusOutput) -> None:
    from rich.panel import Panel
    from rich.table import Table

    table = Table(title="Mobius EventStore", show_header=True, header_style="bold cyan")
    table.add_column("Champ", style="bold")
    table.add_column("Valeur")
    table.add_row("Event store", status_payload.event_store)
    table.add_row("Read only", str(status_payload.read_only).lower())
    table.add_row("Migrations", "applied" if status_payload.migrations_applied else "missing")
    table.add_row("Integrity", status_payload.integrity_check)
    table.add_row("Events", str(status_payload.event_count))
    output.write_rich(Panel(table, title="Status", border_style="cyan"))


def _write_rich_dashboard(status: DashboardStatus) -> None:
    output.write_rich(_rich_dashboard_renderable(status))


def _write_live_rich_dashboard(event_store_path: Path, run_id: str, *, read_only: bool) -> None:
    from rich.console import Console
    from rich.live import Live

    console = Console(no_color=True)
    with EventStore(event_store_path, read_only=read_only) as store:
        initial_status = _read_dashboard_status(store, run_id)
    with Live(
        _rich_dashboard_renderable(initial_status),
        console=console,
        refresh_per_second=4,
    ) as live:
        while True:
            with EventStore(event_store_path, read_only=read_only) as store:
                status = _read_dashboard_status(store, run_id)
            live.update(_rich_dashboard_renderable(status))
            if is_terminal_state(status.state):
                return
            time.sleep(_FOLLOW_INTERVAL_SECONDS)


def _rich_dashboard_renderable(status: DashboardStatus) -> RenderableType:
    from rich.panel import Panel
    from rich.table import Table

    summary = Table.grid(padding=(0, 2))
    summary.add_column(style="bold")
    summary.add_column()
    summary.add_row("Session", status.session_id)
    summary.add_row("Runtime", status.runtime)
    summary.add_row("State", status.state)
    summary.add_row("Started", status.started_at)
    summary.add_row("Last event", status.last_event_at)
    summary.add_row("Event count", str(status.event_count))

    events = Table(title="Recent EventStore events", show_header=True, header_style="bold cyan")
    events.add_column("Seq", justify="right")
    events.add_column("Type")
    events.add_column("Created")
    events.add_column("Payload")
    for event in status.recent_events:
        events.add_row(
            str(event.sequence),
            event.type,
            event.created_at,
            _format_event_payload(event.payload),
        )

    layout = Table.grid(expand=True)
    layout.add_row(summary)
    layout.add_row(events)
    return Panel(layout, title=f"Mobius status: {status.runtime}", border_style="cyan")


def _write_run_markdown(run_payload: RunStatusOutput) -> None:
    output.write_line(f"# Run {run_payload.run_id}")
    output.write_line("")
    output.write_line("| Champ | Valeur |")
    output.write_line("| --- | --- |")
    output.write_line(f"| État | {run_payload.state} |")
    output.write_line(f"| Démarré à | {run_payload.started_at} |")
    output.write_line(f"| Dernier événement à | {run_payload.last_event_at} |")


def _write_store_status(status_payload: StatusOutput) -> None:
    output.write_line(f"event_store={status_payload.event_store}")
    output.write_line(f"read_only={str(status_payload.read_only).lower()}")
    output.write_line(f"migrations_applied={str(status_payload.migrations_applied).lower()}")
    output.write_line(f"integrity_check={status_payload.integrity_check}")
    output.write_line(f"event_count={status_payload.event_count}")


def _format_event_delta(event: EventRecord) -> str:
    payload = _format_event_payload(event.payload)
    return f"- `{event.created_at}` seq={event.sequence} type={event.type} payload=`{payload}`"


def _format_event_payload(raw: str) -> str:
    """Render an event payload as compact UTF-8 JSON for human display.

    Payloads are stored in SQLite as ASCII-escaped JSON (``ensure_ascii=True``)
    so that bytes are stable across SQLite drivers. When showing them to the
    user, decode and re-encode with ``ensure_ascii=False`` so accented
    characters appear as ``é`` rather than ``\\u00e9``. Falls back to the raw
    string when the payload is not valid JSON, which keeps the original
    behavior for malformed legacy events.
    """
    try:
        decoded = json.loads(raw)
    except (TypeError, ValueError):
        return raw
    return json.dumps(decoded, sort_keys=True, separators=(",", ":"), ensure_ascii=False)


def _has_pending_run_files(paths: MobiusPaths, run_id: str) -> bool:
    run_paths = get_run_paths(paths, run_id)
    evolution_paths = get_evolution_paths(paths, run_id)
    return (
        run_paths.metadata_file.exists()
        or run_paths.pid_file.exists()
        or evolution_paths.metadata_file.exists()
        or evolution_paths.pid_file.exists()
    )


def mark_stale_session_if_needed(paths: MobiusPaths, session_id: str) -> None:
    """Mark any detached run/evolution crashed when its PID file is stale."""
    mark_stale_session(paths, session_id)


def _raise_not_found(run_id: str) -> NoReturn:
    output.write_error_line(f"run introuvable : {run_id}")
    raise SystemExit(int(ExitCode.NOT_FOUND))
