"""Handlers for the Mobius run command."""

from __future__ import annotations

from pathlib import Path

import typer

from mobius.cli import output
from mobius.cli.main import CliContext, ExitCode
from mobius.config import get_paths
from mobius.workflow.launcher import WorkerLauncher, run_worker_config
from mobius.workflow.run import execute_run, prepare_run, run_foreground, start_detached_worker
from mobius.workflow.seed import SeedSpecValidationError
from mobius.workflow.templates import find_placeholder_strings


def _warn_on_placeholders(prepared: object, spec_path: Path) -> None:
    """Emit a warning when the spec still contains blank-template placeholders.

    The warning goes to stderr so the run still proceeds (Mobius is a tracker,
    not a gatekeeper) but the user gets a clear hint that the spec is unedited.
    Silent on non-blank specs. ``spec_path`` is included verbatim in the
    message so users with custom filenames see exactly which file to edit.
    """
    spec = getattr(prepared, "spec", None)
    if spec is None:
        return
    placeholders = find_placeholder_strings(
        goal=getattr(spec, "goal", "") or "",
        constraints=getattr(spec, "constraints", []) or [],
        success_criteria=getattr(spec, "success_criteria", []) or [],
    )
    if not placeholders:
        return
    output.write_error_line(
        f"warning: {spec_path} contient encore des placeholders du template "
        f"'blank' ({len(placeholders)}); édite ce fichier avant de relancer "
        "pour des événements significatifs."
    )
    for value in placeholders:
        output.write_error_line(f"  - {value}")


def run(
    context: CliContext,
    *,
    spec_path: Path,
    detach: bool = True,
    foreground: bool = False,
    coding_agent: str | None = None,
    coding_model: str | None = None,
    coding_plan: Path | None = None,
    approve_agent: bool = False,
) -> None:
    """Validate and start a run."""
    paths = get_paths(context.mobius_home)
    agent_approved = approve_agent
    if (coding_agent or coding_model) and not approve_agent:
        agent_approved = typer.confirm(
            f"Lancer l'agent de codage {coding_agent or '<spec>'} "
            f"avec le modèle {coding_model or '<spec>'} ?"
        )
        if not agent_approved:
            output.write_error_line("lancement agent annulé")
            raise typer.Exit(code=int(ExitCode.USAGE))
    try:
        prepared = prepare_run(
            paths,
            spec_path,
            coding_agent=coding_agent,
            coding_model=coding_model,
            coding_plan=coding_plan,
            agent_approved=agent_approved,
        )
    except SeedSpecValidationError as exc:
        output.write_error_line(str(exc))
        raise typer.Exit(code=int(ExitCode.VALIDATION)) from exc
    except OSError as exc:
        output.write_error_line(f"spec invalide : {exc}")
        raise typer.Exit(code=int(ExitCode.VALIDATION)) from exc

    _warn_on_placeholders(prepared, spec_path)

    WorkerLauncher(paths).launch_for_cli(
        run_worker_config(
            prepared,
            run_foreground=run_foreground,
            start_detached=start_detached_worker,
            success_exit_code=int(ExitCode.OK),
        ),
        detach=detach,
        foreground=foreground,
        json_output=context.json_output,
        usage_exit_code=int(ExitCode.USAGE),
    )


def worker_run(context: CliContext, *, run_id: str) -> None:
    """Execute a prepared run from the private ``_worker`` command."""
    paths = get_paths(context.mobius_home)
    exit_code = execute_run(paths, run_id, stream_events=True)
    if exit_code != int(ExitCode.OK):
        raise typer.Exit(code=exit_code)
