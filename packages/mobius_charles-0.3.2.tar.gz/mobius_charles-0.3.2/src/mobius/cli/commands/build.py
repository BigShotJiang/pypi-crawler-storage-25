"""Non-developer first-step command for Mobius."""

from __future__ import annotations

import contextlib
import io
import json
import shlex
from pathlib import Path

from pydantic import BaseModel, ConfigDict

from mobius.cli import output
from mobius.cli.commands import seed as seed_command
from mobius.cli.commands.interview import _build_non_interactive_fixture
from mobius.cli.formatter import get_formatter
from mobius.cli.main import CliContext
from mobius.config import get_paths
from mobius.persistence.event_store import EventStore
from mobius.workflow.ids import readable_session_id
from mobius.workflow.interview import (
    InterviewFixture,
    build_interview_handoff_metadata,
    compute_ambiguity_score,
    evaluate_interview_contract,
    event_interview_contract_metadata,
    infer_interview_contract_metadata,
    question_answers,
    render_spec_yaml,
)
from mobius.workflow.interview_milestones import milestone_from_score
from mobius.workflow.interview_v3a.runner import run_interview as run_v3a_interview


class BuildOutput(BaseModel):
    """Machine-readable result for ``mobius build``."""

    model_config = ConfigDict(extra="forbid")

    session_id: str
    spec_path: str
    interview_mode: str
    perspectives: list[str]
    ambiguity_score: float
    ambiguity_gate: float
    milestone: str
    next_action: str
    next_command: str
    seed_session_id: str
    seed_validated: bool
    not_done: list[str]


def run(
    context: CliContext,
    intent: str,
    *,
    output_path: Path | None = None,
    template: str | None = None,
    project_type: str | None = None,
    constraints: list[str] | None = None,
    success_criteria: list[str] | None = None,
    context_value: str | None = None,
    json_output: bool = False,
) -> None:
    """Turn a fuzzy idea into a conversationally clarified local spec."""
    workspace = Path.cwd()
    output_path = (output_path or workspace / "spec.yaml").expanduser().resolve()
    seed_fixture = _build_non_interactive_fixture(
        workspace=workspace,
        input_path=None,
        template=template,
        project_type=project_type,
        goal=intent,
        constraints=constraints,
        success_criteria=success_criteria,
        context_value=context_value,
        from_session=None,
        mobius_home=context.mobius_home,
    )
    session_id = readable_session_id("interview", seed_fixture.goal)
    paths = get_paths(context.mobius_home)
    output_dir = paths.home / "interviews" / session_id
    result = run_v3a_interview(
        intent=seed_fixture.goal,
        run_id=session_id,
        output_dir=output_dir,
        answers=[*seed_fixture.constraints, *seed_fixture.success, ":enough"],
        auto_confirm=True,
    )
    fixture = InterviewFixture(
        project_type=seed_fixture.project_type,
        goal=result.fixture.goal,
        constraints=list(
            dict.fromkeys([*seed_fixture.constraints, *result.fixture.constraints])
        ),
        success=list(dict.fromkeys([*seed_fixture.success, *result.fixture.success])),
        context=seed_fixture.context,
        template=seed_fixture.template or result.fixture.template,
    )
    score = compute_ambiguity_score(fixture)
    score.raise_for_gate()
    contract_seed_metadata = infer_interview_contract_metadata(fixture)
    contract = evaluate_interview_contract(
        fixture,
        score=score,
        deep_metadata=contract_seed_metadata,
    )
    handoff_metadata = build_interview_handoff_metadata(fixture, contract)
    deep_metadata = {
        "interview_mode": "conversational",
        "branches_explored": 3,
        "concepts": [
            {"name": "socrate", "description": "questions and convergence"},
            {"name": "avocat", "description": "edge-case challenge"},
            {"name": "architecte", "description": "options and trade-offs"},
            {"name": "transcript", "description": str(result.transcript_path)},
            {"name": "fixture", "description": str(result.fixture_path)},
        ],
        **contract_seed_metadata,
        **handoff_metadata,
    }

    spec_yaml = render_spec_yaml(
        session_id,
        fixture,
        score,
        deep_metadata=deep_metadata,
    )
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(spec_yaml, encoding="utf-8")

    event_payload = {
        "mode": "build",
        "input": intent,
        "project_type": fixture.project_type,
        "template": fixture.template,
        "interview_mode": "conversational",
        "perspectives": ["socrate", "avocat", "architecte"],
        "transcript": str(result.transcript_path),
        "fixture": str(result.fixture_path),
        "seed_ready": contract.seed_ready,
        "closure_blockers": list(contract.closure_blockers),
    }
    with EventStore(paths.event_store) as store:
        store.create_session(
            session_id,
            runtime="interview",
            metadata={**event_payload, "output": str(output_path)},
            status="running",
        )
        store.append_event(session_id, "interview.started", event_payload)
        store.append_event(
            session_id,
            "interview.perspectives_completed",
            {
                "perspectives": ["socrate", "avocat", "architecte"],
                "turns": result.turns,
                "transcript": str(result.transcript_path),
                "fixture": str(result.fixture_path),
                "human_confirmed": result.human_confirmed,
                "socrate_proposed_done": result.socrate_proposed_done,
                "seed_ready": contract.seed_ready,
                "closure_blockers": list(contract.closure_blockers),
            },
        )
        for category, question, answer in question_answers(fixture):
            store.append_event(
                session_id,
                "interview.question_answered",
                {"category": category, "question": question, "answer": answer},
            )
        store.append_event(
            session_id,
            "interview.completed",
            {
                "ambiguity_score": score.score,
                "ambiguity_gate": score.threshold,
                "passed_gate": score.passed,
                "output": str(output_path),
                "template": fixture.template,
                "interview_mode": "conversational",
                "perspectives": ["socrate", "avocat", "architecte"],
                "turns": result.turns,
                "transcript": str(result.transcript_path),
                "fixture": str(result.fixture_path),
                "seed_ready": contract.seed_ready,
                "closure_blockers": list(contract.closure_blockers),
                **handoff_metadata,
                **event_interview_contract_metadata(deep_metadata),
            },
        )
        store.end_session(session_id, status="completed")

    seed_stdout = io.StringIO()
    with contextlib.redirect_stdout(seed_stdout):
        seed_command.run(context, str(output_path), json_output=True, validate=True)
    seed_payload = json.loads(seed_stdout.getvalue())

    payload = BuildOutput(
        session_id=session_id,
        spec_path=str(output_path),
        interview_mode="conversational",
        perspectives=["socrate", "avocat", "architecte"],
        ambiguity_score=score.score,
        ambiguity_gate=score.threshold,
        milestone=milestone_from_score(score).value,
        next_action="Lancer un run depuis la spec déjà validée en seed.",
        next_command=f"mobius run --spec {shlex.quote(str(output_path))}",
        seed_session_id=str(seed_payload["session_id"]),
        seed_validated=True,
        not_done=["run", "qa", "evolve"],
    )
    formatter = get_formatter(context, json_output=json_output)
    formatter.emit(payload, text=lambda: _write_markdown(payload))


def _write_markdown(payload: BuildOutput) -> None:
    output.write_line("# Mobius build")
    output.write_line("")
    output.write_line(f"Spec écrite: {payload.spec_path}")
    output.write_line(f"Interview: {payload.interview_mode} ({','.join(payload.perspectives)})")
    output.write_line(f"État: {payload.milestone}")
    output.write_line(f"Clarté: {payload.ambiguity_score}/{payload.ambiguity_gate}")
    output.write_line("")
    output.write_line("Ce qui est fait: clarification locale + seed validé.")
    output.write_line(f"Seed validé: {payload.seed_session_id}")
    output.write_line(f"Ce qui n'est pas encore fait: {', '.join(payload.not_done)}.")
    output.write_line(f"Prochaine action: {payload.next_action}")
    output.write_line(f"Commande: {payload.next_command}")
