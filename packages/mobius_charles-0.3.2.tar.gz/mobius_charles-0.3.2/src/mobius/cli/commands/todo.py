"""Commandes TODO locales pour Mobius."""

from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Any

import typer
from pydantic import BaseModel, ConfigDict

from mobius.cli import output
from mobius.cli.formatter import get_formatter
from mobius.cli.main import CliContext, ExitCode
from mobius.config import get_paths
from mobius.persistence.event_store import EventRecord, EventStore

_TODO_AGGREGATE_ID = "mobius.todo"


class TodoItem(BaseModel):
    """Une tâche TODO affichable par la CLI."""

    model_config = ConfigDict(extra="forbid")

    id: str
    text: str
    done: bool = False


class TodoList(BaseModel):
    """Enveloppe JSON pour la liste TODO."""

    model_config = ConfigDict(extra="forbid")

    todos: list[TodoItem]


@dataclass(frozen=True)
class _TodoState:
    items: list[TodoItem]
    next_number: int


def add(context: CliContext, text: str, *, json_output: bool = False) -> None:
    """Ajouter une tâche TODO dans l'event store Mobius."""
    clean_text = text.strip()
    if not clean_text:
        output.write_error_line("le texte de la tâche est requis")
        raise typer.Exit(code=int(ExitCode.USAGE))

    paths = get_paths(context.mobius_home)
    with EventStore(paths.event_store) as store:
        state = _state_from_events(store.read_events(_TODO_AGGREGATE_ID))
        item = TodoItem(id=f"todo-{state.next_number}", text=clean_text)
        store.append_event(_TODO_AGGREGATE_ID, "todo.added", item.model_dump())

    formatter = get_formatter(context, json_output=json_output)
    formatter.emit(item, text=lambda: output.write_line(f"{item.id} {item.text}"))


def ls(
    context: CliContext,
    *,
    show_all: bool = False,
    json_output: bool = False,
) -> None:
    """Lister les tâches TODO."""
    paths = get_paths(context.mobius_home)
    if not paths.event_store.exists():
        items: list[TodoItem] = []
    else:
        with EventStore(paths.event_store, read_only=True) as store:
            items = _state_from_events(store.read_events(_TODO_AGGREGATE_ID)).items
    if not show_all:
        items = [item for item in items if not item.done]

    formatter = get_formatter(context, json_output=json_output)
    formatter.emit(TodoList(todos=items), text=lambda: _write_todos(items))


def done(context: CliContext, todo_id: str, *, json_output: bool = False) -> None:
    """Marquer une tâche comme terminée."""
    item = _update_item(context, todo_id, event_type="todo.done")
    formatter = get_formatter(context, json_output=json_output)
    formatter.emit(item, text=lambda: output.write_line(f"{item.id} terminé"))


def remove(context: CliContext, todo_id: str, *, json_output: bool = False) -> None:
    """Supprimer une tâche TODO."""
    item = _update_item(context, todo_id, event_type="todo.removed")
    formatter = get_formatter(context, json_output=json_output)
    formatter.emit(item, text=lambda: output.write_line(f"{item.id} supprimé"))


def _update_item(context: CliContext, todo_id: str, *, event_type: str) -> TodoItem:
    paths = get_paths(context.mobius_home)
    if not paths.event_store.exists():
        output.write_error_line(f"todo introuvable : {todo_id}")
        raise typer.Exit(code=int(ExitCode.NOT_FOUND))

    with EventStore(paths.event_store) as store:
        state = _state_from_events(store.read_events(_TODO_AGGREGATE_ID))
        item = _find_item(state.items, todo_id)
        if item is None:
            output.write_error_line(f"todo introuvable : {todo_id}")
            raise typer.Exit(code=int(ExitCode.NOT_FOUND))
        store.append_event(_TODO_AGGREGATE_ID, event_type, {"id": item.id})
    return item


def _write_todos(items: list[TodoItem]) -> None:
    if not items:
        output.write_line("(aucune tâche)")
        return
    for item in items:
        mark = "✓" if item.done else " "
        output.write_line(f"[{mark}] {item.id} {item.text}")


def _state_from_events(events: list[EventRecord]) -> _TodoState:
    items_by_id: dict[str, TodoItem] = {}
    max_number = 0
    for event in events:
        payload = _payload(event)
        if event.type == "todo.added":
            added_item = TodoItem.model_validate(payload)
            items_by_id[added_item.id] = added_item
            max_number = max(max_number, _todo_number(added_item.id))
        elif event.type == "todo.done":
            todo_id = str(payload.get("id", ""))
            existing_item = items_by_id.get(todo_id)
            if existing_item is not None:
                items_by_id[todo_id] = existing_item.model_copy(update={"done": True})
        elif event.type == "todo.removed":
            items_by_id.pop(str(payload.get("id", "")), None)
    return _TodoState(items=list(items_by_id.values()), next_number=max_number + 1)


def _find_item(items: list[TodoItem], todo_id: str) -> TodoItem | None:
    wanted = _normalise_todo_id(todo_id)
    for item in items:
        if item.id == wanted:
            return item
    return None


def _normalise_todo_id(todo_id: str) -> str:
    value = todo_id.strip()
    return value if value.startswith("todo-") else f"todo-{value}"


def _todo_number(todo_id: str) -> int:
    try:
        return int(todo_id.rsplit("-", 1)[1])
    except (IndexError, ValueError):
        return 0


def _payload(event: EventRecord) -> dict[str, Any]:
    decoded = json.loads(event.payload)
    return decoded if isinstance(decoded, dict) else {}
