"""Handler for the Mobius seed command."""

from __future__ import annotations

from pathlib import Path
from typing import Any

import typer
from pydantic import BaseModel, ConfigDict

from mobius.cli import output
from mobius.cli.formatter import get_formatter, suggest_next
from mobius.cli.main import CliContext, ExitCode
from mobius.config import get_paths
from mobius.persistence.event_store import EventStore
from mobius.workflow._yaml import yaml_list, yaml_scalar
from mobius.workflow.ids import readable_session_id
from mobius.workflow.seed import (
    SeedSpec,
    SeedSpecValidationError,
    assign_bronze_grade,
    load_seed_spec,
    seed_values_from_transcript,
    validate_seed_spec,
)


class SeedOutput(BaseModel):
    """Structured output for a completed seed."""

    model_config = ConfigDict(extra="forbid")

    session_id: str
    source: str
    event_count: int
    grade: str | None = None
    criteria_met: int | None = None
    criteria_total: int | None = None


def run(
    context: CliContext,
    spec_or_session_id: str | None,
    *,
    json_output: bool = False,
    validate: bool = False,
    from_transcript: Path | None = None,
) -> None:
    """Validate a spec, persist seed events, and emit a seed session id."""
    paths = get_paths(context.mobius_home)
    generated_from: str | None = None
    spec_path: Path | None = None
    try:
        if from_transcript is not None:
            spec = _load_spec_from_transcript(from_transcript)
            source = str(from_transcript)
            generated_from = "transcript"
        else:
            if spec_or_session_id is None:
                msg = "seed requires a spec path, interview session id, or --from-transcript"
                raise SeedSpecValidationError(msg)
            spec, spec_path, generated_from = _load_spec_from_source(
                paths.event_store, spec_or_session_id
            )
            source = spec_or_session_id
    except FileNotFoundError as exc:
        output.write_error_line(str(exc))
        raise typer.Exit(code=int(ExitCode.NOT_FOUND)) from exc
    except SeedSpecValidationError as exc:
        output.write_error_line(str(exc))
        raise typer.Exit(code=int(ExitCode.VALIDATION)) from exc

    session_id = readable_session_id("seed", spec.goal)
    generated_spec_path = spec_path
    if generated_from is not None:
        generated_spec_path = _write_generated_spec(paths.home, session_id, spec)
    event_count = 0
    with EventStore(paths.event_store) as store:
        store.create_session(
            session_id,
            runtime="seed",
            metadata={
                "source": source,
                "spec_path": str(generated_spec_path) if generated_spec_path else "",
                "source_session_id": spec.source_session_id,
                "generated_from": generated_from or "",
            },
            status="running",
        )
        store.append_event(
            session_id,
            "seed.started",
            {
                "source": source,
                "spec_path": str(generated_spec_path) if generated_spec_path else "",
                "source_session_id": spec.source_session_id,
                "generated_from": generated_from or "",
            },
        )
        event_count += 1
        store.append_event(
            session_id,
            "seed.validated",
            {
                "project_type": spec.project_type,
                "constraint_count": len(spec.constraints),
                "success_criteria_count": len(spec.success_criteria),
            },
        )
        event_count += 1
        store.append_event(session_id, "seed.completed", spec.to_event_payload())
        event_count += 1
        grade = assign_bronze_grade(spec) if validate else None
        if grade is not None:
            store.append_event(session_id, "spec.grade_assigned", grade.to_event_payload())
            event_count += 1
        store.end_session(session_id, status="completed")

    payload = SeedOutput(
        session_id=session_id,
        source=source,
        event_count=event_count,
        grade=grade.grade if grade is not None else None,
        criteria_met=grade.criteria_met if grade is not None else None,
        criteria_total=grade.criteria_total if grade is not None else None,
    )
    formatter = get_formatter(context, json_output=json_output)
    formatter.emit(payload, text=payload.session_id)
    if not formatter.json_output:
        output.write_line(
            f"✅ Spec validée : {spec.goal[:60]}... | {len(spec.success_criteria)} critères"
        )
        suggest_next("seed")


def _load_spec_from_transcript(path: Path) -> SeedSpec:
    raw = path.expanduser().read_text(encoding="utf-8")
    return validate_seed_spec(seed_values_from_transcript(raw))


def _load_spec_from_source(
    event_store_path: Path, spec_or_session_id: str
) -> tuple[SeedSpec, Path | None, str | None]:
    candidate = Path(spec_or_session_id).expanduser()
    if candidate.exists():
        return load_seed_spec(candidate), candidate, None

    with EventStore(event_store_path) as store:
        events = store.read_events(spec_or_session_id)
    if not events:
        msg = f"source seed introuvable : {spec_or_session_id}"
        raise FileNotFoundError(msg)

    for event in reversed(events):
        if event.type == "interview.completed":
            output_path = event.payload_data.get("output")
            if isinstance(output_path, str) and output_path:
                path = Path(output_path).expanduser()
                if path.exists():
                    return load_seed_spec(path), path, None

    spec = _load_spec_from_interview_events(spec_or_session_id, events)
    return spec, None, "interview_events"


def _resolve_spec_path(event_store_path: Path, session_id: str) -> Path:
    """Resolve the spec path recorded by an interview session."""
    with EventStore(event_store_path) as store:
        events = store.read_events(session_id)
    if not events:
        msg = f"source seed introuvable : {session_id}"
        raise FileNotFoundError(msg)

    for event in reversed(events):
        if event.type != "interview.completed":
            continue
        output_path = event.payload_data.get("output")
        if isinstance(output_path, str) and output_path:
            path = Path(output_path).expanduser()
            if not path.exists():
                msg = f"cannot read seed spec {path}: No such file or directory"
                raise FileNotFoundError(msg)
            return path

    msg = f"la session ne contient pas de spec de sortie interview : {session_id}"
    raise SeedSpecValidationError(msg)


def _load_spec_from_interview_events(session_id: str, events: list[Any]) -> SeedSpec:
    values: dict[str, Any] = {"session_id": session_id, "project_type": "greenfield"}
    for event in events:
        if getattr(event, "type", "") != "interview.question_answered":
            continue
        payload = event.payload_data
        if not isinstance(payload, dict):
            continue
        category = str(payload.get("category", "")).strip()
        answer = payload.get("answer")
        if category == "success":
            category = "success_criteria"
        if category in {"project_type", "goal", "constraints", "success_criteria", "context"}:
            values[category] = answer
    for event in reversed(events):
        if getattr(event, "type", "") != "interview.completed":
            continue
        payload = event.payload_data
        if not isinstance(payload, dict):
            continue
        for key in (
            "metadata",
            "criteria_tree",
            "verification_commands",
            "enforcement_matrix",
            "ambiguity_ledger",
            "question_ledger",
            "closure_challenge",
            "second_opinion",
            "non_goals",
            "decision_boundaries",
        ):
            if key in payload:
                values[key] = payload[key]
        break
    if len(values) <= 2:
        msg = f"la session ne contient pas de spec de sortie interview : {session_id}"
        raise SeedSpecValidationError(msg)
    return validate_seed_spec(values)


def _write_generated_spec(home: Path, session_id: str, spec: SeedSpec) -> Path:
    path = home / "generated-specs" / f"{session_id}.yaml"
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(_render_generated_spec(spec), encoding="utf-8")
    return path


def _render_generated_spec(spec: SeedSpec) -> str:
    lines = [
        f"project_type: {yaml_scalar(spec.project_type)}",
        f"goal: {yaml_scalar(spec.goal)}",
        "constraints:",
        *yaml_list(spec.constraints),
        "success_criteria:",
        *yaml_list(spec.success_criteria),
    ]
    if spec.source_session_id:
        lines.insert(0, f"session_id: {yaml_scalar(spec.source_session_id)}")
    if spec.context:
        lines.append(f"context: {yaml_scalar(spec.context)}")
    return "\n".join(lines) + "\n"
