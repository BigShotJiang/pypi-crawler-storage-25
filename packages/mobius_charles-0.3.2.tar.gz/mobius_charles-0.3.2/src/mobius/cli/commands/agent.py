"""Commandes CLI pour les personas de pensée latérale Mobius."""

from __future__ import annotations

import json
from typing import TYPE_CHECKING

import typer

from mobius.cli import output
from mobius.cli.main import CliContext
from mobius.core.types import ExitCode

if TYPE_CHECKING:
    from mobius.workflow.lateral import Suggestion


def list_personas(_context: CliContext, *, json_output: bool = False) -> None:
    """Lister toutes les personas de pensée latérale disponibles."""
    from mobius.agents.loader import list_personas as get_personas
    from mobius.agents.loader import load_persona_data

    personas = get_personas()
    if json_output:
        items = []
        for name in personas:
            data = load_persona_data(name)
            items.append({"name": name, "philosophy": data.philosophy})
        output.write_line(json.dumps({"personas": items}, ensure_ascii=False, indent=2))
        return

    for name in personas:
        data = load_persona_data(name)
        output.write_line(f"  {name:<14} {data.philosophy[:80]}")


def show_prompt(_context: CliContext, name: str) -> None:
    """Afficher le prompt complet d'une persona."""
    from mobius.agents.loader import load_persona

    try:
        content = load_persona(name)
    except FileNotFoundError as exc:
        output.write_error_line(str(exc))
        raise typer.Exit(code=int(ExitCode.NOT_FOUND)) from None
    output.write_line(content)


def suggest(
    context: CliContext,
    run_id: str | None,
    *,
    interactive: bool = False,
    json_output: bool = False,
) -> None:
    """Analyser un run et suggérer la persona la plus pertinente."""
    if run_id:
        resolved_run_id = _resolve_run_id(context, run_id)
        suggestion = _suggest_from_run(context, resolved_run_id)
    elif interactive:
        suggestion = _suggest_interactive()
    else:
        output.write_error_line(
            "run_id requis, ou utilisez --interactive pour analyser le workspace."
        )
        raise typer.Exit(code=int(ExitCode.VALIDATION))

    if json_output:
        output.write_line(
            json.dumps(
                {
                    "persona": suggestion.persona,
                    "reason": suggestion.reason,
                    "confidence": suggestion.confidence,
                },
                ensure_ascii=False,
                indent=2,
            )
        )
        return

    output.write_line(f"{suggestion.persona} ({suggestion.confidence:.0%}) — {suggestion.reason}")


def _suggest_from_run(context: CliContext, run_id: str) -> Suggestion:
    """Suggérer une persona à partir des événements d'un run."""
    from mobius.persistence.event_store import EventStore
    from mobius.workflow.lateral import suggest_persona

    event_store = context.mobius_home / "events.db"
    if not event_store.exists():
        output.write_error_line("aucun event store Mobius trouvé")
        raise typer.Exit(code=int(ExitCode.NOT_FOUND))

    try:
        with EventStore(event_store, read_only=True) as store:
            return suggest_persona(store, run_id)
    except Exception as exc:
        output.write_error_line(f"erreur lors de l'analyse : {exc}")
        raise typer.Exit(code=int(ExitCode.GENERIC_ERROR)) from None


def _resolve_run_id(context: CliContext, run_id: str) -> str:
    if run_id != "latest":
        return run_id

    from mobius.cli.command_registry import _resolve_latest_run_id

    resolved = _resolve_latest_run_id(context)
    if resolved is None:
        output.write_error_line("aucun run disponible pour `latest`")
        raise typer.Exit(code=int(ExitCode.NOT_FOUND))
    return resolved


def _suggest_interactive() -> Suggestion:
    """Suggérer une persona à partir du contexte du workspace courant."""
    from pathlib import Path

    from mobius.workflow.lateral import Suggestion

    cwd = Path.cwd()
    has_spec = (cwd / "spec.yaml").exists()
    is_brownfield = any(
        (cwd / f).exists() for f in ("pyproject.toml", "package.json", "Cargo.toml", "go.mod")
    )

    if is_brownfield and not has_spec:
        return Suggestion(
            "researcher", "workspace brownfield sans spec — explorer le contexte existant", 0.7
        )
    if has_spec:
        return Suggestion(
            "contrarian", "spec présente — challenger les hypothèses avant exécution", 0.6
        )
    return Suggestion("architect", "workspace vide — structurer le projet avant de coder", 0.5)


def apply_persona(context: CliContext, name: str, run_id: str) -> None:
    """Tracer l'application d'une persona sur un run dans l'event store."""
    from mobius.agents.loader import load_persona
    from mobius.persistence.event_store import EventStore

    try:
        load_persona(name)
    except FileNotFoundError as exc:
        output.write_error_line(str(exc))
        raise typer.Exit(code=int(ExitCode.NOT_FOUND)) from None

    try:
        with EventStore(context.mobius_home / "events.db") as store:
            existing = store.connection.execute(
                "SELECT session_id FROM sessions WHERE session_id = ?",
                (run_id,),
            ).fetchone()
            if existing is None:
                output.write_error_line(f"run introuvable : {run_id}")
                raise typer.Exit(code=int(ExitCode.NOT_FOUND))
            store.append_event(
                run_id,
                "agent.persona_applied",
                {"persona": name, "applied_by": "cli"},
            )
    except typer.Exit:
        raise
    except Exception as exc:
        output.write_error_line(f"erreur lors de l'écriture : {exc}")
        raise typer.Exit(code=int(ExitCode.GENERIC_ERROR)) from None

    output.write_line(f"persona {name} appliquée sur {run_id}")
