"""Mobius Typer CLI entry point with lazy subcommand loading."""

from __future__ import annotations

import os
import signal
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Annotated

# Typer forces Rich terminal rendering when FORCE_COLOR is set (see
# typer.rich_utils.FORCE_TERMINAL). The CLI contract expects byte-stable
# help text in tests and non-interactive contexts, so disable that private
# override before importing Typer.
os.environ.setdefault("_TYPER_FORCE_DISABLE_TERMINAL", "1")

import typer

from mobius import __version__
from mobius.cli import output
from mobius.cli.command_registry import register_commands
from mobius.core.types import ExitCode as ExitCode
from mobius.logging import configure_logging


@dataclass(frozen=True)
class CliContext:
    """Process-wide CLI options shared with lazily imported command handlers."""

    json_output: bool
    mobius_home: Path


app = typer.Typer(
    add_completion=False,
    context_settings={"help_option_names": ["-h", "--help"]},
    invoke_without_command=True,
    no_args_is_help=True,
    pretty_exceptions_enable=False,
    help="CLI de workflow rapide, sans MCP.",
)


def build_context(*, json_output: bool) -> CliContext:
    """Build a lightweight CLI context from global flags and environment."""
    configured_home = os.environ.get("MOBIUS_HOME")
    mobius_home = Path(configured_home).expanduser() if configured_home else Path.home() / ".mobius"
    return CliContext(json_output=json_output, mobius_home=mobius_home)


def _version_callback(value: bool) -> None:
    if value:
        output.write_line(f"mobius {__version__}")
        raise typer.Exit(code=int(ExitCode.OK))


def _handle_sigint(_signum: int, _frame: object | None) -> None:
    output.write_error_line("interrompu")
    raise typer.Exit(code=int(ExitCode.INTERRUPTED))


@app.callback()
def cli(
    ctx: typer.Context,
    json_output: Annotated[
        bool,
        typer.Option(
            "--json",
            help="Émettre du JSON lisible par machine pour les commandes compatibles.",
        ),
    ] = False,
    _version: Annotated[
        bool,
        typer.Option(
            "--version",
            callback=_version_callback,
            is_eager=True,
            help="Afficher la version de Mobius et quitter.",
        ),
    ] = False,
) -> None:
    """Configure global CLI behavior."""
    signal.signal(signal.SIGINT, _handle_sigint)
    configure_logging(json_output=json_output)
    ctx.obj = build_context(json_output=json_output)


@app.command(
    name="cold-start",
    help="Mesurer la médiane de démarrage à froid de `mobius --help` sur 5 exécutions.",
    rich_help_panel="Commandes avancées",
)
def cold_start_command() -> None:
    """Measure the public cold-start gate used by v3a quality checks."""
    import statistics
    import subprocess
    import time

    command = [sys.argv[0], "--help"]
    env = dict(os.environ)
    env["NO_COLOR"] = "1"
    samples_ms: list[float] = []
    for _ in range(5):
        started = time.perf_counter()
        result = subprocess.run(
            command,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.PIPE,
            text=True,
            check=False,
            env=env,
        )
        elapsed_ms = (time.perf_counter() - started) * 1000
        if result.returncode != 0:
            typer.echo(result.stderr, err=True)
            raise typer.Exit(code=result.returncode)
        samples_ms.append(elapsed_ms)
    median_ms = statistics.median(samples_ms)
    formatted = ", ".join(f"{sample:.1f}" for sample in samples_ms)
    typer.echo(f"cold_start median_ms={median_ms:.1f} samples_ms=[{formatted}]")
    if median_ms > 100:
        raise typer.Exit(code=1)


register_commands(app)


def main() -> None:
    """Run the Mobius CLI."""
    app()
