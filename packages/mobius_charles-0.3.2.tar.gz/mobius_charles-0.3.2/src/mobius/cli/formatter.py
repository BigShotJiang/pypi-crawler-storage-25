"""Output-format seam: one interface, JSON and Markdown adapters."""

from __future__ import annotations

import json
import os
import sys
from collections.abc import Callable
from enum import IntEnum
from typing import Any, Protocol, runtime_checkable

import typer


@runtime_checkable
class _ModelPayload(Protocol):
    def model_dump_json(self) -> str:
        """Return a compact JSON representation."""


class _CliContext(Protocol):
    @property
    def json_output(self) -> bool:
        """Whether the global CLI JSON flag is set."""


class Formatter:
    """CLI output formatter that centralises the json-vs-text dispatch.

    Every command handler builds a *payload* (serialisable dict/list) and an
    optional *text* representation.  ``Formatter.emit`` routes to the right
    adapter so that individual commands never repeat the ``if json_output: …
    else: …`` pattern.
    """

    def __init__(self, *, json_output: bool = False) -> None:
        self.json_output = json_output

    def emit(self, payload: Any, *, text: str | list[str] | Callable[[], None]) -> None:
        """Write *payload* as JSON or *text* to stdout."""
        output = _output_adapter()
        if self.json_output:
            output.write_json(self.to_json(payload))
        else:
            if callable(text):
                text()
            elif isinstance(text, list):
                for line in text:
                    output.write_line(line)
            else:
                output.write_line(text)

    def to_json(self, payload: Any) -> str:
        """Return the byte-compatible JSON rendering for *payload*."""
        if isinstance(payload, str):
            return payload
        if isinstance(payload, _ModelPayload):
            return payload.model_dump_json()
        return json.dumps(payload, sort_keys=True, separators=(",", ":"))

    def write_line(self, line: str) -> None:
        """Unconditional line to stdout (use sparingly; prefer :meth:`emit`)."""
        _output_adapter().write_line(line)

    def write_error(self, message: str) -> None:
        """Diagnostic line to stderr."""
        _output_adapter().write_error_line(message)

    def exit_with(self, code: int | IntEnum) -> None:
        """Raise ``typer.Exit`` with the given code."""
        raise typer.Exit(code=int(code))

    def exit_ok(self) -> None:
        """Exit 0."""
        self.exit_with(0)

    def exit_error(self) -> None:
        """Exit 1."""
        self.exit_with(1)


class JsonFormatter(Formatter):
    """Adapter that always writes JSON output."""

    def __init__(self) -> None:
        super().__init__(json_output=True)


class MarkdownFormatter(Formatter):
    """Adapter that always writes Markdown/text output."""

    def __init__(self) -> None:
        super().__init__(json_output=False)


def get_formatter(context: _CliContext, *, json_output: bool | None = None) -> Formatter:
    """Build a :class:`Formatter` respecting the CLI context.

    A command-local ``json_output`` flag is OR'd with the global one so that
    both ``mobius --json status`` and ``mobius status --json`` work.
    """
    use_json = context.json_output if json_output is None else context.json_output or json_output
    return Formatter(json_output=use_json)


def _output_adapter() -> Any:
    """Return the compatibility output module for monkeypatch-friendly writes."""
    from mobius.cli import output

    return output


def _no_color() -> bool:
    return os.environ.get("NO_COLOR") is not None


def _console() -> type[Any]:
    from rich.console import Console

    return Console


def write_line(message: str) -> None:
    """Write one plain data line to stdout without Rich markup or ANSI styling."""
    sys.stdout.write(f"{message}\n")


def write_json(message: str) -> None:
    """Write one compact JSON payload to stdout."""
    sys.stdout.write(f"{message}\n")


def write_rich(renderable: Any, *, width: int | None = None) -> None:
    """Write a Rich renderable to stdout."""
    _console()(file=sys.stdout, no_color=_no_color(), soft_wrap=True, width=width).print(renderable)


def write_error_line(message: str) -> None:
    """Write one diagnostic line to stderr."""
    sys.stderr.write(f"{message}\n")


def human_output_allowed(
    context: _CliContext | None = None,
    *,
    json_output: bool = False,
    raw_stdout: bool = False,
    command: str | None = None,
    startup_hint: bool = False,
    argv: list[str] | None = None,
) -> bool:
    """Return whether friendly human hints may be emitted.

    This is intentionally conservative: JSON, raw machine stdout, and status
    surfaces are automation contracts, so friendly hints must stay silent.
    """
    if raw_stdout:
        return False
    if json_output or (context is not None and context.json_output):
        return False
    args = sys.argv[1:] if argv is None else argv
    if "--json" in args:
        return False
    resolved_command = command or _first_command(args)
    if resolved_command in _MACHINE_CONTRACT_COMMANDS:
        return False
    return not (startup_hint and resolved_command is not None)


def _first_command(args: list[str]) -> str | None:
    """Best-effort top-level command extraction from argv."""
    skip_next = False
    for arg in args:
        if skip_next:
            skip_next = False
            continue
        if arg in {"--config", "--profile"}:
            skip_next = True
            continue
        if arg.startswith("-"):
            continue
        return arg
    return None


_MACHINE_CONTRACT_COMMANDS = {
    "cancel",
    "config",
    "evolve",
    "lineage",
    "qa",
    "ralph",
    "run",
    "status",
}


# Table de transition : commande courante → (prochaine principale, alternatives)
_NEXT_STEP: dict[str, tuple[str, list[str]]] = {
    "interview": ("seed", ["build"]),
    "build": ("seed", ["interview"]),
    "seed": ("run", ["handoff"]),
    "run": ("qa", ["status", "guide"]),
    "qa": ("evolve", ["ralph", "unstuck"]),
    "evolve": ("ralph", ["qa", "unstuck"]),
    "ralph": ("qa", ["evolve"]),
}


def suggest_next(current_command: str, *, emit: bool = True) -> tuple[str, list[str]]:
    """Retourner (prochaine_commande_principale, [alternatives]) pour la commande courante.

    Émet aussi la suggestion formatée sur stdout quand ``emit`` est vrai.
    """
    entry = _NEXT_STEP.get(current_command)
    if entry is None:
        return ("", [])
    primary, alts = entry
    alts_str = ", ".join(f"mobius {a}" for a in alts) if alts else ""
    line = f"📍 Prochaine étape : mobius {primary}"
    if alts_str:
        line += f"  (voir aussi : {alts_str})"
    if emit and human_output_allowed(command=current_command):
        write_line(line)
    return (primary, alts)
