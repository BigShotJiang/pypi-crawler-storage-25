#!/usr/bin/env python3
"""
WowBits CLI setup wizard.

Flow:
1) Welcome + workspace root directory
2) API port (validates TCP availability; offers next free port)
3) Database: default SQLite or custom SQLAlchemy connection string
4) OPENAI_API_KEY (required)
5) Pull starter agent_studio YAMLs (optional)
6) Review table + confirmation + provisioning
"""
import getpass
import os
import socket
import sys
from pathlib import Path
from typing import Dict, Optional
from urllib.parse import urlparse

from rich import box
from rich.console import Console, Group
from rich.panel import Panel
from rich.prompt import Confirm, Prompt
from rich.table import Table
from sqlalchemy.engine.url import make_url

from core import setup as core_setup
from pylibs.pull import list_github_dir, fetch_raw_content, parse_github_url

console = Console()

DEFAULT_API_URL = "http://localhost:8000"
DEFAULT_API_PORT = 8000
DEFAULT_STARTER_REPO = "https://github.com/wowbits-ai/wowbits-getting-started-kit"
DEFAULT_GETTING_STARTED_DOCS = "https://github.com/wowbits-ai/wowbits-getting-started-kit#readme"
SHELL_BLOCK_START = "# >>> wowbits env >>>"
SHELL_BLOCK_END = "# <<< wowbits env <<<"
REQUIRED_WORKSPACE_DIRS = [
    "data",
    "agent_studio",
    "functions",
    "agent_runner",
    "agents",
    "skills",
    "tools",
    "connectors",
    "mcps",
    "logs/system",
    "logs/agents",
    "logs/mcps",
]


def _workspace_env_path(workspace_path: Path) -> Path:
    """Path to .env file inside workspace root."""
    return workspace_path / ".env"


def _ensure_required_workspace_structure(workspace_path: Path) -> None:
    for rel in REQUIRED_WORKSPACE_DIRS:
        (workspace_path / rel).mkdir(parents=True, exist_ok=True)
    init_py = workspace_path / "agent_runner" / "__init__.py"
    if not init_py.exists():
        init_py.write_text("# WowBits Agent Runner\n")


def _normalize_workspace_path(root_dir: str) -> Path:
    return Path(root_dir).expanduser().resolve()


def _is_valid_port(value: int) -> bool:
    return 1 <= value <= 65535


def _is_port_available(port: int, host: str = "127.0.0.1") -> bool:
    """Return True when host:port does not accept a TCP connection."""
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        sock.settimeout(0.5)
        return sock.connect_ex((host, port)) != 0


def _parse_port(value: str) -> Optional[int]:
    if not value:
        return None
    if not value.isdigit():
        return None
    parsed = int(value)
    if not _is_valid_port(parsed):
        return None
    return parsed


def _port_from_api_url(api_url: str) -> Optional[int]:
    try:
        parsed = urlparse(api_url)
        if not parsed.scheme or not parsed.hostname:
            return None
        if parsed.port is not None:
            return parsed.port
        return 443 if parsed.scheme == "https" else 80
    except Exception:
        return None


def _api_url_from_port(port: int) -> str:
    return f"http://localhost:{port}"


def _next_free_port_at_or_after(start: int, *, max_scan: int = 64) -> Optional[int]:
    """First free TCP port in [start, start + max_scan)."""
    end = min(start + max_scan, 65536)
    for p in range(start, end):
        if _is_port_available(p):
            return p
    return None


def _read_env_excluding(env_path: Path, *keys: str) -> list:
    """Read .env lines, excluding lines that set any of the given keys."""
    path = env_path
    if not path.exists():
        return []
    excluded = {k.upper() for k in keys}
    out = []
    for line in path.read_text().splitlines():
        if "=" in line:
            key = line.split("=", 1)[0].strip()
            if key.upper() in excluded:
                continue
        out.append(line)
    return out


def _upsert_workspace_env(workspace_path: Path, values: Dict[str, str]) -> Path:
    env_path = _workspace_env_path(workspace_path)
    existing = _read_env_excluding(env_path, *values.keys())
    block = "\n".join(existing) + "\n" if existing else ""
    for key, value in values.items():
        block += f"{key}={value}\n"
    env_path.write_text(block)
    return env_path


def _welcome_message() -> None:
    body = Group(
        "You will choose a [bold]workspace[/bold], [bold]API port[/bold], [bold]database[/bold], "
        "[bold]OpenAI API key[/bold], whether to [bold]pull starter agents[/bold], then "
        "[bold]review and confirm[/bold] (step 6) before anything is written."
    )
    console.print()
    console.print(
        Panel.fit(
            body,
            title="[bold cyan]Welcome to wowbits setup[/bold cyan]",
            border_style="cyan",
            box=box.ROUNDED,
        )
    )
    console.print()


def _detect_shell_rc() -> Path:
    shell_env = (os.environ.get("SHELL", "") or "").lower()
    home = Path.home()

    if "zsh" in shell_env:
        return home / ".zshrc"
    return home / ".bashrc"


def _persist_shell_exports(root_dir: str, api_url: str) -> Path:
    rc_path = _detect_shell_rc()
    if not rc_path.exists():
        rc_path.touch()

    content = rc_path.read_text() if rc_path.exists() else ""
    lines = content.splitlines()

    clean: list[str] = []
    inside = False
    for line in lines:
        if line.strip() == SHELL_BLOCK_START:
            inside = True
            continue
        if line.strip() == SHELL_BLOCK_END:
            inside = False
            continue
        if not inside:
            clean.append(line)

    if clean and clean[-1].strip() != "":
        clean.append("")
    clean.extend(
        [
            SHELL_BLOCK_START,
            f'export WOWBITS_ROOT_DIR="{root_dir}"',
            f'export WOWBITS_API_URL="{api_url}"',
            SHELL_BLOCK_END,
            "",
        ]
    )

    rc_path.write_text("\n".join(clean))
    return rc_path


def _pull_starter_agent_studio(workspace_path: Path, repo_url: str) -> Dict[str, object]:
    parsed = parse_github_url(repo_url)
    if not parsed:
        raise ValueError("Unsupported starter repo URL. Use a GitHub URL (e.g. https://github.com/owner/repo)")

    owner, repo, branch = parsed
    items = list_github_dir(owner, repo, branch, "agent_studio")
    yaml_items = [
        item
        for item in items
        if item.get("type") == "file" and item.get("name", "").endswith((".yaml", ".yml"))
    ]
    if not yaml_items:
        return {"pulled": 0, "files": []}

    agent_studio_path = workspace_path / "agent_studio"
    agent_studio_path.mkdir(parents=True, exist_ok=True)

    files = []
    for item in yaml_items:
        name = item["name"]
        content = fetch_raw_content(owner, repo, branch, f"agent_studio/{name}")
        if content is None:
            continue
        (agent_studio_path / name).write_text(content, encoding="utf-8")
        files.append(name)
    return {"pulled": len(files), "files": files}


def _default_sqlite_url(root_path: Path) -> str:
    """Default workspace SQLite URL (absolute path, posix slashes for SQLAlchemy)."""
    return f"sqlite:///{(root_path / 'data' / 'wowbits.db').resolve().as_posix()}"


def _validate_db_url(url: str) -> bool:
    try:
        make_url(url.strip())
        return True
    except Exception:
        return False


def _collect_root_dir(root_dir: Optional[str]) -> Path:
    if root_dir:
        return _normalize_workspace_path(root_dir)

    default = str(Path.home() / "wowbits")
    console.rule("[bold]Step 1/6[/bold] Workspace", style="cyan")
    console.print(
        "[dim]Choose a workspace directory to create and run wowbits agents. "
        "This directory will be created if it does not already exist.[/dim]\n"
    )
    while True:
        value = Prompt.ask(
            "Workspace root",
            default=default,
            show_default=True,
        )
        chosen = value.strip() or default
        try:
            path = _normalize_workspace_path(chosen)
            console.print(f"[green]✓[/green] Using workspace: [bold]{path}[/bold]\n")
            return path
        except Exception as exc:
            console.print(f"[red]✗[/red] Invalid path: {exc}\n")


def _collect_api_port(api_port: Optional[int], api_url: Optional[str]) -> int:
    if api_port is not None:
        if not _is_valid_port(api_port):
            console.print(f"[red]Invalid --api-port: {api_port}. Must be 1–65535.[/red]")
            sys.exit(1)
        if not _is_port_available(api_port):
            console.print(f"[red]Port {api_port} is already in use. Choose a free port.[/red]")
            sys.exit(1)
        return api_port

    if api_url:
        port = _port_from_api_url(api_url)
        if port is None:
            console.print(f"[red]Could not parse port from --api-url: {api_url}[/red]")
            sys.exit(1)
        if not _is_port_available(port):
            console.print(f"[red]Port {port} from --api-url is already in use.[/red]")
            sys.exit(1)
        return port

    console.rule("[bold]Step 2/6[/bold] API Port", style="cyan")
    console.print(
        "[dim]The wowbits API will listen on this port on localhost."
    )

    while True:
        default_s = str(DEFAULT_API_PORT)
        raw = Prompt.ask(
            "API Port",
            default=default_s,
            show_default=True,
        )
        if not raw.strip():
            port = DEFAULT_API_PORT
        else:
            port = _parse_port(raw.strip())
            if port is None:
                console.print("[red]✗[/red] Enter a number from 1 to 65535.\n")
                continue

        if _is_port_available(port):
            console.print(f"[green]✓[/green] Port [bold]{port}[/bold] is available.\n")
            return port

        alt = _next_free_port_at_or_after(port)
        if alt is None:
            console.print(
                f"[red]✗[/red] Port [bold]{port}[/bold] is in use and no free port was found in the next range. "
                "Try another port.\n"
            )
            continue

        console.print(f"[yellow]⚠[/yellow] Port [bold]{port}[/bold] is already in use.")
        if Confirm.ask(f"Use the next free port [bold]{alt}[/bold] instead?", default=True):
            console.print(f"[green]✓[/green] Using port [bold]{alt}[/bold].\n")
            return alt
        console.print("[dim]Try a different port below, or press Ctrl+C to cancel.[/dim]\n")


def _collect_db_url(root_path: Path, db_url: Optional[str], assume_yes: bool = False) -> str:
    default_sqlite = _default_sqlite_url(root_path)

    if db_url:
        if not _validate_db_url(db_url):
            console.print("[red]Invalid --db-url: could not parse as a SQLAlchemy URL.[/red]")
            sys.exit(1)
        return db_url.strip()

    if assume_yes:
        return default_sqlite

    console.rule("[bold]Step 3/6[/bold] Database", style="cyan")
    console.print(
        "[dim]Choose a database to store your workspace data. You can use a default SQLite file or a connection string to connect to mysql, postgresql, etc.[/dim]\n"
    )

    mode = Prompt.ask(
        "Database option",
        choices=["sqlite", "connection_string"],
        default="sqlite",
    )

    if mode == "sqlite":
        console.print(
            f"[green]✓[/green] Using sqlite database within workspace folder: [bold]{root_path / 'data' / 'wowbits.db'}[/bold]\n"
        )
        return default_sqlite

    console.print(
        "\n[dim]Examples: [bold]postgresql+psycopg2://user:pass@host:5432/dbname[/bold] · "
        "[bold]sqlite:////absolute/path/to/wowbits.db[/bold][/dim]\n"
    )
    while True:
        console.print("[bold]Connection string[/bold] [dim](hidden; empty input cancels)[/dim]")
        entered = getpass.getpass("WOWBITS_DB_CONNECTION_STRING> ").strip()
        if not entered:
            console.print("[red]Setup cancelled (empty connection string).[/red]")
            sys.exit(1)
        if not _validate_db_url(entered):
            console.print("[red]✗[/red] Could not parse that URL. Check the format and try again.\n")
            continue
        console.print("[green]✓[/green] Connection string accepted.\n")
        return entered


def _collect_openai_key(openai_api_key: Optional[str], assume_yes: bool = False) -> str:
    if openai_api_key is not None:
        key = openai_api_key.strip()
        if not key:
            console.print("[red]✗[/red] --openai-api-key cannot be empty.")
            sys.exit(1)
        return key
    if assume_yes:
        console.print(
            "[red]✗[/red] Non-interactive setup (-y) requires [bold]--openai-api-key[/bold]. "
            "Omit -y to enter the key interactively."
        )
        sys.exit(1)

    console.print("[bold]OPENAI_API_KEY[/bold] [dim](input hidden)[/dim]")
    while True:
        value = getpass.getpass("OPENAI_API_KEY> ").strip()
        if value:
            console.print(
                "[green]✓[/green] API key will be stored in the workspace [bold].env[/bold] (not shown).\n"
            )
            return value
        console.print("[red]✗[/red] An OpenAI API key is required. Try again or press Ctrl+C to cancel.\n")


def _print_summary_table(
    root_path: Path,
    resolved_api_url: str,
    chosen_db_url: str,
    do_starter_pull: bool,
) -> None:
    table = Table(box=box.ROUNDED, show_header=True, header_style="bold cyan")
    table.add_column("Setting", style="dim", no_wrap=True)
    table.add_column("Value")

    table.add_row("Workspace", str(root_path))
    table.add_row("WOWBITS_API_URL", resolved_api_url)
    if chosen_db_url.startswith("sqlite:///"):
        table.add_row("db_connection_string", chosen_db_url)
    else:
        table.add_row("db_connection_string", "[dim](stored; not displayed)[/dim]")
    table.add_row("OPENAI_API_KEY", "[dim]stored in .env (not shown)[/dim]")
    table.add_row("Pull Getting Started Kit", "yes" if do_starter_pull else "no")

    console.print()
    console.print(table)
    console.print()


def run_setup(
    root_dir: str = None,
    db_url: str = None,
    api_url: str = None,
    api_port: Optional[int] = None,
    openai_api_key: Optional[str] = None,
    starter_repo_url: str = DEFAULT_STARTER_REPO,
    skip_starter_pull: bool = False,
    assume_yes: bool = False,
) -> None:
    """Run full WowBits setup wizard for CLI users."""
    _welcome_message()

    root_path = _collect_root_dir(root_dir)
    chosen_port = _collect_api_port(api_port=api_port, api_url=api_url)
    resolved_api_url = _api_url_from_port(chosen_port)
    chosen_db_url = _collect_db_url(root_path=root_path, db_url=db_url, assume_yes=assume_yes)

    if not assume_yes:
        console.rule("[bold]Step 4/6[/bold] OpenAI API Key", style="cyan")
        console.print(
            "[dim]Used as default llm for wowbits agents. Create a key at [link=https://platform.openai.com/api-keys]platform.openai.com/api-keys[/link].[/dim]\n"
        )
    chosen_openai_api_key = _collect_openai_key(openai_api_key, assume_yes=assume_yes)

    if assume_yes:
        do_starter_pull = False
    else:
        console.rule("[bold]Step 5/6[/bold] Starter Agents & Skills", style="cyan")
        if skip_starter_pull:
            console.print(
                "[dim]Starter [bold]agent_studio[/bold] YAMLs not pulled ([bold]--skip-starter-pull[/bold]).[/dim]\n"
            )
            do_starter_pull = False
        else:
            console.print(
                "[dim]Download a few sample agents to get started quickly with wowbits, such as a browser automation agent and a stock market news monitoring agent.[/dim]\n"
            )
            do_starter_pull = Confirm.ask(
                "Pull getting-started agents and skills?",
                default=True,
            )

    if not assume_yes:
        console.print()

    console.rule("[bold]Step 6/6[/bold] Review & confirm", style="cyan")
    console.print(
        "[dim]Check the summary below, then confirm to write files, update shell config, and initialize the database.[/dim]\n"
    )
    _print_summary_table(
        root_path,
        resolved_api_url,
        chosen_db_url,
        do_starter_pull,
    )

    if not assume_yes and not Confirm.ask(
        "Confirm setup?",
        default=True,
    ):
        console.print("[yellow]⚠[/yellow] Setup cancelled — no files were changed.")
        return

    root_path.mkdir(parents=True, exist_ok=True)
    _ensure_required_workspace_structure(root_path)
    root_dir_s = str(root_path)

    rc_path = _persist_shell_exports(root_dir=root_dir_s, api_url=resolved_api_url)
    core_setup.run_setup(workspace_path=root_path, db_url=chosen_db_url)
    _ensure_required_workspace_structure(root_path)

    values = {
        "WOWBITS_ROOT_DIR": root_dir_s,
        "WOWBITS_API_URL": resolved_api_url,
        "WOWBITS_API_PORT": str(chosen_port),
        "WOWBITS_DB_CONNECTION_STRING": chosen_db_url,
    }
    values["OPENAI_API_KEY"] = chosen_openai_api_key
    env_path = _upsert_workspace_env(root_path, values)

    pull_summary = {"pulled": 0, "files": []}
    if do_starter_pull:
        pull_summary = _pull_starter_agent_studio(root_path, starter_repo_url)

    next_steps = Group(
        f"1. Reload shell env: [bold]source {rc_path}[/bold]",
        "2. Start the API: [bold]wowbits start api[/bold]",
        "3. List agents: [bold]wowbits list agents[/bold]",
        f"4. Docs: [link={DEFAULT_GETTING_STARTED_DOCS}]{DEFAULT_GETTING_STARTED_DOCS}[/link]",
    )
    console.print(
        Panel(
            Group(
                f"[green]✓[/green] Workspace: [bold]{root_path}[/bold]",
                f"[green]✓[/green] Env file: [bold]{env_path}[/bold]",
                f"[green]✓[/green] Shell block: [bold]{rc_path}[/bold]",
                f"[green]✓[/green] Starter YAMLs pulled: [bold]{pull_summary.get('pulled', 0)}[/bold]",
                "",
                "[bold]Next steps[/bold]",
                next_steps,
            ),
            title="[bold green]Setup complete[/bold green]",
            border_style="green",
            box=box.ROUNDED,
        )
    )
    console.print()


if __name__ == "__main__":
    import argparse

    p = argparse.ArgumentParser(description="Run WowBits setup")
    p.add_argument("--root-dir", help="WowBits workspace root directory")
    p.add_argument("--db-url", help="Database URL (e.g. sqlite:///... or postgresql+psycopg2://...)")
    p.add_argument("--api-url", help="WOWBITS_API_URL (e.g. http://localhost:8000)")
    p.add_argument("--api-port", type=int, help="WOWBITS API port (must be free)")
    p.add_argument(
        "--openai-api-key",
        help="OpenAI API key for workspace .env (required with -y; otherwise prompted interactively)",
    )
    p.add_argument("--starter-repo-url", default=DEFAULT_STARTER_REPO, help="Starter repository URL")
    p.add_argument("--skip-starter-pull", action="store_true", help="Skip pulling starter agent_studio YAMLs")
    p.add_argument(
        "-y",
        "--yes",
        action="store_true",
        help="Skip final confirmation (requires --openai-api-key)",
    )
    a = p.parse_args()
    run_setup(
        root_dir=a.root_dir,
        db_url=a.db_url,
        api_url=a.api_url,
        api_port=a.api_port,
        openai_api_key=a.openai_api_key,
        starter_repo_url=a.starter_repo_url,
        skip_starter_pull=a.skip_starter_pull,
        assume_yes=a.yes,
    )
