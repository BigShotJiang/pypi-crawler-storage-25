#!/usr/bin/env python3
"""
WowBits AI Platform CLI

Thin client for the WowBits API. All commands call WOWBITS_API_URL.
Requires WOWBITS_API_URL to be set (API runs with one workspace via WOWBITS_ROOT_DIR).

Command structure: wowbits <action> <resource> [args]
"""

import argparse
import json
import os
import signal
import subprocess
import sys
import time
from pathlib import Path
from urllib.request import Request, urlopen
from urllib.error import URLError

# Ensure src is on path when run as script
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from cli import api_client


def create_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="wowbits",
        description="WowBits CLI - API client for WowBits (set WOWBITS_API_URL)",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument("-v", "--version", action="version", version="WowBits CLI v0.1.0")
    subparsers = parser.add_subparsers(dest="action", help="Available actions")

    # Setup
    setup_parser = subparsers.add_parser("setup", help="Run interactive WowBits setup wizard")
    setup_parser.add_argument(
        "--db-url",
        help="SQLAlchemy DB URL (e.g. sqlite:///... or postgresql+psycopg2://...); skips DB prompts",
    )
    setup_parser.add_argument("--root-dir", help="WowBits workspace root directory")
    setup_parser.add_argument("--api-url", help="WOWBITS_API_URL (e.g. http://localhost:8000)")
    setup_parser.add_argument("--api-port", type=int, help="WOWBITS API port (must be free)")
    setup_parser.add_argument(
        "--openai-api-key",
        help="OPENAI_API_KEY for workspace .env (required with -y; otherwise prompted)",
    )
    setup_parser.add_argument("--starter-repo-url", default="https://github.com/wowbits-ai/wowbits-getting-started-kit", help="Starter repo URL for agent_studio pull")
    setup_parser.add_argument("--skip-starter-pull", action="store_true", help="Skip pulling starter agent_studio YAMLs")
    setup_parser.add_argument(
        "-y",
        "--yes",
        action="store_true",
        help="Skip final confirmation (requires --openai-api-key)",
    )

    # List
    list_parser = subparsers.add_parser("list", help="List resources")
    list_sub = list_parser.add_subparsers(dest="resource")
    list_sub.add_parser("functions", help="List Python functions")
    list_sub.add_parser("connectors", help="List connectors")
    list_sub.add_parser("agents", help="List agents")
    list_sub.add_parser("skills", help="List skills")
    list_sub.add_parser("tools", help="List tools")
    list_sub.add_parser("mcps", help="List MCP configs")

    # Create
    create_parser = subparsers.add_parser("create", help="Create resources")
    create_sub = create_parser.add_subparsers(dest="resource")
    cf = create_sub.add_parser("function", help="Sync Python functions from workspace/functions")
    cf.add_argument("--dir", help="(Ignored; API uses workspace)")
    cc = create_sub.add_parser("connector", help="Create a connector")
    cc.add_argument("--provider", "-p", required=True, help="Provider (e.g. openai, anthropic)")
    cc.add_argument("--config", required=True, help="JSON config (e.g. '{\"api_key\": \"...\"}')")
    ca = create_sub.add_parser("agent", help="Create agent from YAML in workspace/agent_studio")
    ca.add_argument("name", help="Agent name (agent_studio/<name>.yaml)")
    ca.add_argument("-c", "--config", help="Custom YAML path (relative to workspace)")
    cs = create_sub.add_parser("skill", help="Create a skill")
    cs.add_argument("name", help="Skill name")
    cs.add_argument("--description", default="", help="Description")
    cs.add_argument("--instructions", default="", help="Instructions")
    cs.add_argument("--default-model", default="gpt-4.1", help="Default model")
    cs.add_argument("--temperature", type=float, default=0.2, help="Temperature")
    cs.add_argument("--max-output-tokens", type=int, default=32000, help="Max output tokens")
    cs.add_argument("--exec-mode", default="llm", choices=["llm", "python"], help="Execution mode")
    ct = create_sub.add_parser("tool", help="Create a tool")
    ct.add_argument("name", help="Tool name")
    ct.add_argument("--type", "-t", required=True, choices=["PYTHON_FUNCTION", "MCP_SERVER"], help="Tool type")
    ct.add_argument("--description", default="", help="Description")
    ct.add_argument("--python-function-name", help="Python function name (for type PYTHON_FUNCTION)")
    ct.add_argument("--mcp-config-name", help="MCP config name (for type MCP_SERVER)")
    cm = create_sub.add_parser("mcp", help="Create MCP from workspace/mcps/<name>/config.yaml")
    cm.add_argument("name", metavar="mcp_name", help="MCP name")
    cfn = create_sub.add_parser("function-inline", help="Create a single function by name and code")
    cfn.add_argument("name", help="Function name")
    cfn.add_argument("--code", required=True, help="Python code string or @path/to/file.py")
    cfn.add_argument("--description", default="", help="Description")

    # Pull
    pull_parser = subparsers.add_parser("pull", help="Pull from GitHub")
    pull_sub = pull_parser.add_subparsers(dest="resource")
    pf = pull_sub.add_parser("functions", help="Pull functions from a repo")
    pf.add_argument("--repo-url", required=True, help="GitHub repo URL")
    pf.add_argument("function_names", nargs="*", metavar="name", help="Function names or omit for all")

    pa = pull_sub.add_parser("agents", help="Pull agents from a repo")
    pa.add_argument("--repo-url", required=True, help="GitHub repo URL")
    pa.add_argument("agent_names", nargs="*", metavar="name", help="Agent names or omit for all")

    ps = pull_sub.add_parser("skills", help="Pull skills from a repo")
    ps.add_argument("--repo-url", required=True, help="GitHub repo URL")
    ps.add_argument("skill_names", nargs="*", metavar="name", help="Skill names or omit for all")

    pm = pull_sub.add_parser("mcps", help="Pull MCPs from a repo")
    pm.add_argument("--repo-url", required=True, help="GitHub repo URL")
    pm.add_argument("mcp_names", nargs="*", metavar="name", help="MCP names or omit for all")

    # Update
    update_parser = subparsers.add_parser("update", help="Update resources")
    update_sub = update_parser.add_subparsers(dest="resource")
    uc = update_sub.add_parser("connectors", help="Update connector")
    uc.add_argument("name", help="Connector name or ID")
    uc.add_argument("--config", required=True, help="JSON config")
    ua = update_sub.add_parser("agents", help="Update agent by id or name")
    ua.add_argument("id_or_name", help="Agent id or name")
    ua.add_argument("--name", help="New name")
    ua.add_argument("--description", help="Description")
    ua.add_argument("--instructions", help="Instructions")
    ua.add_argument("--status", help="Status")
    ua.add_argument("--default-model", help="Default model")
    ua.add_argument("--temperature", type=float, help="Temperature")
    ua.add_argument("--max-output-tokens", type=int, help="Max output tokens")
    ua.add_argument("--exec-mode", choices=["llm", "python"], help="Execution mode")
    us = update_sub.add_parser("skills", help="Update skill by id or name")
    us.add_argument("id_or_name", help="Skill id or name")
    us.add_argument("--name", help="New name")
    us.add_argument("--description", help="Description")
    us.add_argument("--instructions", help="Instructions")
    us.add_argument("--default-model", help="Default model")
    us.add_argument("--temperature", type=float, help="Temperature")
    us.add_argument("--max-output-tokens", type=int, help="Max output tokens")
    us.add_argument("--exec-mode", choices=["llm", "python"], help="Execution mode")
    ut = update_sub.add_parser("tools", help="Update tool by id or name")
    ut.add_argument("id_or_name", help="Tool id or name")
    ut.add_argument("--name", help="New name")
    ut.add_argument("--description", help="Description")
    ut.add_argument("--type", choices=["PYTHON_FUNCTION", "MCP_SERVER"], help="Tool type")
    ut.add_argument("--python-function-name", help="Python function name")
    ut.add_argument("--mcp-config-name", help="MCP config name")
    um = update_sub.add_parser("mcps", help="Update MCP by id or name")
    um.add_argument("id_or_name", help="MCP id or name")
    um.add_argument("--name", help="New name")
    um.add_argument("--url", help="URL")
    um.add_argument("--config", help="JSON config object")
    uf = update_sub.add_parser("functions", help="Update function by name")
    uf.add_argument("name", help="Function name")
    uf.add_argument("--code", help="Python code string or @path/to/file.py")
    uf.add_argument("--description", help="Description")

    # Delete
    delete_parser = subparsers.add_parser("delete", help="Delete resources")
    delete_sub = delete_parser.add_subparsers(dest="resource")
    delete_sub.add_parser("connectors", help="Delete a connector").add_argument("name", help="Name or ID")
    da = delete_sub.add_parser("agents", help="Delete agent by id or name")
    da.add_argument("id_or_name", help="Agent id or name")
    ds = delete_sub.add_parser("skills", help="Delete skill by id or name")
    ds.add_argument("id_or_name", help="Skill id or name")
    dt = delete_sub.add_parser("tools", help="Delete tool by id or name")
    dt.add_argument("id_or_name", help="Tool id or name")
    dm = delete_sub.add_parser("mcps", help="Delete MCP by id or name")
    dm.add_argument("id_or_name", help="MCP id or name")
    df = delete_sub.add_parser("functions", help="Delete function by name")
    df.add_argument("name", help="Function name")

    # Start resources
    start_parser = subparsers.add_parser("start", help="Start resources")
    start_sub = start_parser.add_subparsers(dest="resource")

    sa = start_sub.add_parser("agent", help="Start agent (ADK web or api)")
    sa.add_argument("name", help="Agent name")
    sa.add_argument("--mode", "-m", choices=["web", "api"], default="web")
    sa.add_argument("--host", default="0.0.0.0")
    sa.add_argument("--port", "-p", type=int, default=5151)

    sm = start_sub.add_parser("mcp", help="Start MCP server")
    sm.add_argument("name", metavar="mcp_name", help="MCP name")

    sapi = start_sub.add_parser("api", help="Start the WowBits API server for this workspace")
    sapi.add_argument("--host", default="0.0.0.0", help="Host to bind (default: 0.0.0.0)")
    sapi.add_argument("--port", "-p", type=int, default=8000, help="Port (default: 8000)")
    sapi.add_argument("--root-dir", help="Workspace path (default: WOWBITS_ROOT_DIR env)")
    sapi.add_argument("--foreground", "-f", action="store_true", help="Run in foreground (attach to terminal; default is daemon)")

    # Backward-compat for `wowbits start` (API)
    start_parser.add_argument("--host", default="0.0.0.0", help=argparse.SUPPRESS)
    start_parser.add_argument("--port", "-p", type=int, default=8000, help=argparse.SUPPRESS)
    start_parser.add_argument("--root-dir", help=argparse.SUPPRESS)
    start_parser.add_argument("--foreground", "-f", action="store_true", help=argparse.SUPPRESS)

    # Stop resources
    stop_parser = subparsers.add_parser("stop", help="Stop resources")
    stop_sub = stop_parser.add_subparsers(dest="resource")

    stop_sub.add_parser("agent", help="Stop a running agent").add_argument("name", help="Agent name")
    stop_sub.add_parser("mcp", help="Stop a running MCP server").add_argument("name", metavar="mcp_name", help="MCP name")

    stop_api = stop_sub.add_parser("api", help="Stop the WowBits API server daemon for this workspace")
    stop_api.add_argument("--root-dir", help="Workspace path (default: WOWBITS_ROOT_DIR env)")

    # Backward-compat for `wowbits stop` (API)
    stop_parser.add_argument("--root-dir", help=argparse.SUPPRESS)

    return parser


def handle_setup(args):
    from cli.setup import run_setup
    run_setup(
        root_dir=getattr(args, "root_dir", None),
        db_url=args.db_url,
        api_url=getattr(args, "api_url", None),
        api_port=getattr(args, "api_port", None),
        openai_api_key=getattr(args, "openai_api_key", None),
        starter_repo_url=getattr(args, "starter_repo_url", None),
        skip_starter_pull=bool(getattr(args, "skip_starter_pull", False)),
        assume_yes=bool(getattr(args, "yes", False)),
    )


def handle_list(args):
    if args.resource == "functions":
        r = api_client.get("/functions")
        if not r:
            print("No functions.")
            return
        for f in r:
            print(f"{f.get('name', '')}\t{f.get('description', '')}")
    elif args.resource == "connectors":
        r = api_client.get("/connectors")
        if not r:
            print("No connectors.")
            return
        for c in r:
            print(f"{c.get('id')}\t{c.get('name')}\t{c.get('provider')}\t{c.get('status')}")
    elif args.resource == "agents":
        r = api_client.get("/agents")
        if not r:
            print("No agents.")
            return
        for a in r:
            print(f"{a.get('name')}\t{a.get('status')}\t{a.get('exec_mode')}\t{a.get('description', '')}")
    elif args.resource == "skills":
        r = api_client.get("/skills")
        if not r:
            print("No skills.")
            return
        for s in r:
            print(f"{s.get('name')}\t{s.get('description', '')}\t{s.get('exec_mode')}")
    elif args.resource == "tools":
        r = api_client.get("/tools")
        if not r:
            print("No tools.")
            return
        for t in r:
            print(f"{t.get('name')}\t{t.get('type')}\t{t.get('description', '')}")
    elif args.resource == "mcps":
        r = api_client.get("/mcps")
        if not r:
            print("No MCPs.")
            return
        for m in r:
            print(f"{m.get('name')}\t{m.get('id')}\t{m.get('url', '')}")
    else:
        print("❌ Unknown resource:", args.resource)
        sys.exit(1)


def handle_create(args):
    if args.resource == "function":
        r = api_client.post("/functions/sync", {"install_requirements": True})
        print("✅ Functions synced:", r)
    elif args.resource == "function-inline":
        code = getattr(args, "code", "")
        if code.startswith("@"):
            path = Path(code[1:]).expanduser()
            code = path.read_text(encoding="utf-8")
        r = api_client.post("/functions", {"name": args.name, "code": code, "description": getattr(args, "description", "") or ""})
        print("✅ Function created:", r.get("id"))
    elif args.resource == "connector":
        config = json.loads(args.config)
        providers = api_client.get("/connectors/providers")
        name = (providers.get(args.provider) or {}).get("name") or args.provider
        r = api_client.post("/connectors", {"name": name, "provider": args.provider, "config": config})
        print("✅ Connector created:", r.get("id"))
    elif args.resource == "agent":
        # CLI reads YAML and sends to API; core does all processing server-side
        yaml_path = None
        if getattr(args, "config", None):
            yaml_path = Path(args.config).expanduser().resolve()
        else:
            root = os.environ.get("WOWBITS_ROOT_DIR")
            if root:
                yaml_path = Path(root).expanduser().resolve() / "agent_studio" / f"{args.name}.yaml"
        if not yaml_path or not yaml_path.exists():
            print(f"❌ Config not found: {yaml_path or 'agent_studio/' + args.name + '.yaml'}")
            sys.exit(1)
        body = {"name": args.name, "yaml_content": yaml_path.read_text(encoding="utf-8")}
        r = api_client.post("/agents", body)
        print("✅ Agent created/updated:", r)
    elif args.resource == "skill":
        body = {
            "name": args.name,
            "description": getattr(args, "description", "") or "",
            "instructions": getattr(args, "instructions", "") or "",
            "default_model": getattr(args, "default_model", "gpt-4.1") or "gpt-4.1",
            "temperature": getattr(args, "temperature", 0.2),
            "max_output_tokens": getattr(args, "max_output_tokens", 32000),
            "exec_mode": getattr(args, "exec_mode", "llm") or "llm",
        }
        r = api_client.post("/skills", body)
        print("✅ Skill created:", r.get("id"))
    elif args.resource == "tool":
        body = {
            "name": args.name,
            "type": args.type,
            "description": getattr(args, "description", "") or "",
            "python_function_name": getattr(args, "python_function_name", None),
            "mcp_config_name": getattr(args, "mcp_config_name", None),
        }
        r = api_client.post("/tools", body)
        print("✅ Tool created:", r.get("id"))
    elif args.resource == "mcp":
        r = api_client.post("/mcps", {"name": args.name})
        print("✅ MCP created:", r)
    else:
        print("❌ Unknown resource:", args.resource)
        sys.exit(1)


def handle_pull(args):
    if args.resource == "functions":
        body = {"repo_url": args.repo_url}
        if getattr(args, "function_names", None):
            body["function_names"] = args.function_names
        r = api_client.post("/functions/pull", body)
        print("✅ Pull complete:", r)
    elif args.resource == "agents":
        body = {"repo_url": args.repo_url}
        if getattr(args, "agent_names", None):
            body["agent_names"] = args.agent_names
        r = api_client.post("/agents/pull", body)
        print("✅ Pull complete:", r)
    elif args.resource == "skills":
        body = {"repo_url": args.repo_url}
        if getattr(args, "skill_names", None):
            body["skill_names"] = args.skill_names
        r = api_client.post("/skills/pull", body)
        print("✅ Pull complete:", r)
    elif args.resource == "mcps":
        body = {"repo_url": args.repo_url}
        if getattr(args, "mcp_names", None):
            body["mcp_names"] = args.mcp_names
        r = api_client.post("/mcps/pull", body)
        print("✅ Pull complete:", r)
    else:
        print("❌ Unknown resource:", args.resource)
        sys.exit(1)


def handle_update(args):
    if args.resource == "connectors":
        config = json.loads(args.config)
        r = api_client.patch(f"/connectors/{args.name}", {"config": config})
        print("✅ Connector updated:", r.get("id"))
    elif args.resource == "agents":
        body = {}
        if getattr(args, "name", None) is not None:
            body["name"] = args.name
        if getattr(args, "description", None) is not None:
            body["description"] = args.description
        if getattr(args, "instructions", None) is not None:
            body["instructions"] = args.instructions
        if getattr(args, "status", None) is not None:
            body["status"] = args.status
        if getattr(args, "default_model", None) is not None:
            body["default_model"] = args.default_model
        if getattr(args, "temperature", None) is not None:
            body["temperature"] = args.temperature
        if getattr(args, "max_output_tokens", None) is not None:
            body["max_output_tokens"] = args.max_output_tokens
        if getattr(args, "exec_mode", None) is not None:
            body["exec_mode"] = args.exec_mode
        r = api_client.patch(f"/agents/{args.id_or_name}", body)
        print("✅ Agent updated:", r.get("name"))
    elif args.resource == "skills":
        body = {}
        if getattr(args, "name", None) is not None:
            body["name"] = args.name
        if getattr(args, "description", None) is not None:
            body["description"] = args.description
        if getattr(args, "instructions", None) is not None:
            body["instructions"] = args.instructions
        if getattr(args, "default_model", None) is not None:
            body["default_model"] = args.default_model
        if getattr(args, "temperature", None) is not None:
            body["temperature"] = args.temperature
        if getattr(args, "max_output_tokens", None) is not None:
            body["max_output_tokens"] = args.max_output_tokens
        if getattr(args, "exec_mode", None) is not None:
            body["exec_mode"] = args.exec_mode
        r = api_client.patch(f"/skills/{args.id_or_name}", body)
        print("✅ Skill updated:", r.get("name"))
    elif args.resource == "tools":
        body = {}
        if getattr(args, "name", None) is not None:
            body["name"] = args.name
        if getattr(args, "description", None) is not None:
            body["description"] = args.description
        if getattr(args, "type", None) is not None:
            body["type"] = args.type
        if getattr(args, "python_function_name", None) is not None:
            body["python_function_name"] = args.python_function_name
        if getattr(args, "mcp_config_name", None) is not None:
            body["mcp_config_name"] = args.mcp_config_name
        r = api_client.patch(f"/tools/{args.id_or_name}", body)
        print("✅ Tool updated:", r.get("name"))
    elif args.resource == "mcps":
        body = {}
        if getattr(args, "name", None) is not None:
            body["name"] = args.name
        if getattr(args, "url", None) is not None:
            body["url"] = args.url
        if getattr(args, "config", None) is not None:
            body["config"] = json.loads(args.config)
        r = api_client.patch(f"/mcps/{args.id_or_name}", body)
        print("✅ MCP updated:", r.get("name"))
    elif args.resource == "functions":
        body = {}
        if getattr(args, "code", None) is not None:
            code = args.code
            if code.startswith("@"):
                code = Path(code[1:]).expanduser().read_text(encoding="utf-8")
            body["code"] = code
        if getattr(args, "description", None) is not None:
            body["description"] = args.description
        r = api_client.patch(f"/functions/{args.name}", body)
        print("✅ Function updated:", r.get("name"))
    else:
        print("❌ Unknown resource:", args.resource)
        sys.exit(1)


def handle_delete(args):
    if args.resource == "connectors":
        r = api_client.delete(f"/connectors/{args.name}")
        print("✅ Deleted:", r)
    elif args.resource == "agents":
        r = api_client.delete(f"/agents/{args.id_or_name}")
        print("✅ Deleted agent:", r.get("deleted"))
    elif args.resource == "skills":
        r = api_client.delete(f"/skills/{args.id_or_name}")
        print("✅ Deleted skill:", r.get("deleted"))
    elif args.resource == "tools":
        r = api_client.delete(f"/tools/{args.id_or_name}")
        print("✅ Deleted tool:", r.get("deleted"))
    elif args.resource == "mcps":
        r = api_client.delete(f"/mcps/{args.id_or_name}")
        print("✅ Deleted MCP:", r.get("deleted"))
    elif args.resource == "functions":
        r = api_client.delete(f"/functions/{args.name}")
        print("✅ Deleted function:", r.get("deleted"))
    else:
        print("❌ Unknown resource:", args.resource)
        sys.exit(1)


def handle_start(args):
    resource = getattr(args, "resource", None)
    if resource == "agent":
        r = api_client.post(
            f"/agents/{args.name}/start",
            {"mode": args.mode, "host": args.host, "port": args.port},
        )
        print("✅ Agent started:", r)
    elif resource == "mcp":
        r = api_client.post(f"/mcps/{args.name}/start")
        print("✅ MCP started:", r)
    elif resource in (None, "api"):
        handle_start_api(args)
    else:
        print("❌ Unknown resource:", resource)
        sys.exit(1)


def handle_stop(args):
    resource = getattr(args, "resource", None)
    if resource == "agent":
        r = api_client.post(f"/agents/{args.name}/stop")
        print("✅ Agent stopped:", r)
    elif resource == "mcp":
        r = api_client.post(f"/mcps/{args.name}/stop")
        print("✅ MCP stopped:", r)
    elif resource in (None, "api"):
        handle_stop_api(args)
    else:
        print("❌ Unknown resource:", resource)
        sys.exit(1)


def _resolve_workspace_path(root_dir_arg):
    """Resolve workspace path from --root-dir or WOWBITS_ROOT_DIR. Exits on error."""
    if root_dir_arg:
        return Path(root_dir_arg).expanduser().resolve()
    root_dir = os.environ.get("WOWBITS_ROOT_DIR")
    if not root_dir:
        print("❌ WOWBITS_ROOT_DIR is not set.", file=sys.stderr)
        print("   Set it to your workspace path, or use --root-dir /path/to/workspace", file=sys.stderr)
        sys.exit(1)
    return Path(root_dir).expanduser().resolve()


def handle_start_api(args):
    """Start the WowBits API server (uvicorn). Foreground or daemon."""
    root_path = _resolve_workspace_path(getattr(args, "root_dir", None))
    if not root_path.is_dir():
        print(f"❌ Workspace directory not found: {root_path}", file=sys.stderr)
        sys.exit(1)
    env = os.environ.copy()
    # Load workspace .env so daemon has WOWBITS_DB_CONNECTION_STRING etc.
    try:
        from dotenv import load_dotenv
        load_dotenv(root_path / ".env")
        env = os.environ.copy()
    except Exception:
        pass
    env["WOWBITS_ROOT_DIR"] = str(root_path)
    package_root = Path(__file__).resolve().parent.parent
    env.setdefault("PYTHONPATH", "")
    if env["PYTHONPATH"]:
        env["PYTHONPATH"] = str(package_root) + os.pathsep + env["PYTHONPATH"]
    else:
        env["PYTHONPATH"] = str(package_root)
    cmd = [
        sys.executable, "-m", "uvicorn", "api.main:app",
        "--host", args.host,
        "--port", str(args.port),
    ]
    daemon = not getattr(args, "foreground", False)
    if daemon:
        legacy_pid_file = root_path / ".wowbits-api.pid"
        system_logs_dir = root_path / "logs" / "system"
        system_logs_dir.mkdir(parents=True, exist_ok=True)
        pid_file = system_logs_dir / "api.pid"
        log_file = system_logs_dir / "api.log"
        if legacy_pid_file.exists() and not pid_file.exists():
            try:
                legacy_pid_file.replace(pid_file)
            except OSError:
                pass
        if pid_file.exists():
            try:
                old_pid = int(pid_file.read_text().strip())
                try:
                    os.kill(old_pid, 0)
                    print(f"❌ API daemon already running (PID {old_pid}). Stop it with: wowbits stop", file=sys.stderr)
                    sys.exit(1)
                except OSError:
                    pass
                pid_file.unlink()
            except (ValueError, OSError):
                pid_file.unlink(missing_ok=True)
        with open(log_file, "a") as log_handle:
            proc = subprocess.Popen(
                cmd,
                cwd=str(package_root),
                env=env,
                stdout=log_handle,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
        # Wait for server to be ready before writing PID file (avoids stale PID if uvicorn exits during startup)
        base_url = "http://{}:{}".format(args.host, args.port)
        health_url = base_url + "/health"
        deadline = time.monotonic() + 15.0
        ready = False
        while time.monotonic() < deadline:
            if proc.poll() is not None:
                print("❌ API daemon exited during startup. Check", log_file, file=sys.stderr)
                sys.exit(1)
            try:
                req = Request(health_url, method="GET")
                with urlopen(req, timeout=2) as resp:
                    if resp.getcode() == 200:
                        ready = True
                        break
            except (URLError, OSError):
                time.sleep(0.5)
                continue
        if not ready:
            try:
                os.kill(proc.pid, signal.SIGTERM)
            except OSError:
                pass
            print("❌ Server did not become ready in time. Check", log_file, file=sys.stderr)
            sys.exit(1)
        pid_file.write_text(str(proc.pid))
        print("✅ API server started as daemon (PID {})".format(proc.pid))
        print("   Log: {}".format(log_file))
        print("   Stop: wowbits stop")
        return
    print(f"Starting API server (workspace: {root_path})")
    print(f"  Host: http://{args.host}:{args.port}")
    print("  Press Ctrl+C to stop")
    try:
        subprocess.run(cmd, cwd=str(package_root), env=env)
    except KeyboardInterrupt:
        pass
    except FileNotFoundError:
        print("❌ uvicorn not found. Install with: pip install uvicorn[standard]", file=sys.stderr)
        sys.exit(1)


def handle_stop_api(args):
    """Stop the WowBits API server daemon."""
    root_path = _resolve_workspace_path(getattr(args, "root_dir", None))
    system_logs_dir = root_path / "logs" / "system"
    pid_file = system_logs_dir / "api.pid"
    legacy_pid_file = root_path / ".wowbits-api.pid"
    if not pid_file.exists() and legacy_pid_file.exists():
        pid_file = legacy_pid_file
    if not pid_file.exists():
        print("No API daemon found for this workspace (no logs/system/api.pid).", file=sys.stderr)
        sys.exit(1)
    try:
        pid = int(pid_file.read_text().strip())
    except (ValueError, OSError):
        pid_file.unlink(missing_ok=True)
        print("Invalid or stale PID file removed.", file=sys.stderr)
        sys.exit(1)
    try:
        os.kill(pid, signal.SIGTERM)
    except ProcessLookupError:
        pid_file.unlink(missing_ok=True)
        print("Daemon was not running (stale PID file removed).", file=sys.stderr)
        print("   If you just ran 'wowbits start', the server may have exited during startup. Check logs/system/api.log in the workspace.", file=sys.stderr)
        return
    except OSError as e:
        print("❌ Could not stop daemon (PID {}): {}".format(pid, e), file=sys.stderr)
        sys.exit(1)
    pid_file.unlink(missing_ok=True)
    print("✅ API server daemon stopped (PID {}).".format(pid))


def main():
    parser = create_parser()
    if len(sys.argv) == 1:
        parser.print_help()
        sys.exit(0)
    args = parser.parse_args()

    # Require WOWBITS_API_URL except setup and local API lifecycle commands
    is_local_api_lifecycle = (
        (args.action == "start" and getattr(args, "resource", None) in (None, "api"))
        or (args.action == "stop" and getattr(args, "resource", None) in (None, "api"))
    )
    if args.action != "setup" and not is_local_api_lifecycle:
        api_client.get_base_url()

    try:
        if args.action == "setup":
            handle_setup(args)
        elif args.action == "start":
            handle_start(args)
        elif args.action == "stop":
            handle_stop(args)
        elif args.action == "list":
            if not args.resource:
                parser.parse_args(["list", "--help"])
            handle_list(args)
        elif args.action == "create":
            if not args.resource:
                parser.parse_args(["create", "--help"])
            handle_create(args)
        elif args.action == "update":
            if not args.resource:
                parser.parse_args(["update", "--help"])
            handle_update(args)
        elif args.action == "delete":
            if not args.resource:
                parser.parse_args(["delete", "--help"])
            handle_delete(args)
        elif args.action == "pull":
            if not args.resource:
                parser.parse_args(["pull", "--help"])
            handle_pull(args)
        else:
            parser.print_help()
            sys.exit(1)
    except KeyboardInterrupt:
        print("\n⚠️  Cancelled")
        sys.exit(130)
    except json.JSONDecodeError as e:
        print(f"❌ Invalid JSON: {e}")
        sys.exit(1)
    except Exception as e:
        print(f"❌ Error: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()
