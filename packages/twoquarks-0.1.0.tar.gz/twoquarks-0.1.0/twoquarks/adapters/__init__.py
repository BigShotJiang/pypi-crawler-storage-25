"""
twoquarks.adapters
==================
Ready-made model adapters for common LLM APIs.
Each adapter returns a callable (str) -> str compatible with Probe.

Usage:
    from twoquarks.adapters import openai_adapter, anthropic_adapter, hf_adapter

    model = openai_adapter(model="gpt-4o-mini", api_key="sk-...")
    probe = Probe(model=model, model_id="gpt-4o-mini")

NOTE: These adapters require the respective SDK to be installed.
      twoquarks itself does NOT depend on them — they're optional helpers.
"""
from __future__ import annotations
from typing import Callable, Any


def openai_adapter(
    model: str = "gpt-4o-mini",
    api_key: str | None = None,
    system_prompt: str | None = None,
    max_tokens: int = 512,
    temperature: float = 0.7,
    **kwargs: Any,
) -> Callable[[str], str]:
    """
    Adapter for OpenAI Chat Completions API.
    Requires: pip install openai
    """
    try:
        import openai
    except ImportError:
        raise ImportError("openai package required: pip install openai")

    client = openai.OpenAI(api_key=api_key)
    messages_base = [{"role": "system", "content": system_prompt}] if system_prompt else []

    def call(prompt: str) -> str:
        messages = messages_base + [{"role": "user", "content": prompt}]
        response = client.chat.completions.create(
            model=model,
            messages=messages,
            max_tokens=max_tokens,
            temperature=temperature,
            **kwargs,
        )
        return response.choices[0].message.content or ""

    return call


def anthropic_adapter(
    model: str = "claude-3-haiku-20240307",
    api_key: str | None = None,
    system_prompt: str | None = None,
    max_tokens: int = 512,
    **kwargs: Any,
) -> Callable[[str], str]:
    """
    Adapter for Anthropic Messages API.
    Requires: pip install anthropic
    """
    try:
        import anthropic
    except ImportError:
        raise ImportError("anthropic package required: pip install anthropic")

    client = anthropic.Anthropic(api_key=api_key)

    def call(prompt: str) -> str:
        create_kwargs: dict[str, Any] = dict(
            model=model,
            max_tokens=max_tokens,
            messages=[{"role": "user", "content": prompt}],
            **kwargs,
        )
        if system_prompt:
            create_kwargs["system"] = system_prompt
        response = client.messages.create(**create_kwargs)
        return response.content[0].text

    return call


def huggingface_adapter(
    model_id: str,
    device: str = "cpu",
    max_new_tokens: int = 256,
    **kwargs: Any,
) -> Callable[[str], str]:
    """
    Adapter for local HuggingFace transformers models.
    Requires: pip install transformers torch
    """
    try:
        from transformers import pipeline as hf_pipeline
    except ImportError:
        raise ImportError("transformers package required: pip install transformers torch")

    pipe = hf_pipeline("text-generation", model=model_id, device=device)

    def call(prompt: str) -> str:
        out = pipe(prompt, max_new_tokens=max_new_tokens, **kwargs)
        return out[0]["generated_text"][len(prompt):].strip()

    return call


def huggingface_inference_adapter(
    model_id: str,
    api_key: str | None = None,
    **kwargs: Any,
) -> Callable[[str], str]:
    """
    Adapter for HuggingFace Inference API (hosted models).
    Requires: pip install huggingface_hub
    """
    try:
        from huggingface_hub import InferenceClient
    except ImportError:
        raise ImportError("huggingface_hub required: pip install huggingface_hub")

    client = InferenceClient(model=model_id, token=api_key)

    def call(prompt: str) -> str:
        response = client.text_generation(prompt, **kwargs)
        return response if isinstance(response, str) else str(response)

    return call


def litellm_adapter(
    model: str,
    **kwargs: Any,
) -> Callable[[str], str]:
    """
    Adapter via LiteLLM — supports 100+ providers with unified interface.
    Requires: pip install litellm

    Supports: openai/*, anthropic/*, cohere/*, mistral/*, ollama/*, etc.
    """
    try:
        import litellm
    except ImportError:
        raise ImportError("litellm package required: pip install litellm")

    def call(prompt: str) -> str:
        response = litellm.completion(
            model=model,
            messages=[{"role": "user", "content": prompt}],
            **kwargs,
        )
        return response.choices[0].message.content or ""

    return call


def ollama_adapter(
    model: str = "llama3",
    host: str = "http://localhost:11434",
    **kwargs: Any,
) -> Callable[[str], str]:
    """
    Adapter for Ollama local models.
    Requires: ollama running locally + pip install ollama
    """
    try:
        import ollama
    except ImportError:
        raise ImportError("ollama package required: pip install ollama")

    def call(prompt: str) -> str:
        response = ollama.chat(
            model=model,
            messages=[{"role": "user", "content": prompt}],
            **kwargs,
        )
        return response["message"]["content"]

    return call
