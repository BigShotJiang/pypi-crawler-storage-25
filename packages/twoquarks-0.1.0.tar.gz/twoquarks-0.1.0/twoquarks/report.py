"""
twoquarks.report
================
Report generation from MoleculeResult objects.
Supports: plain text summary, JSON, markdown table, CSV row.
"""
from __future__ import annotations
import json
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .core.molecule import MoleculeResult

REGIME_COLORS = {
    "STABLE":    "\033[92m",  # green
    "WATCH":     "\033[93m",  # yellow
    "WARN":      "\033[33m",  # orange-ish
    "INTERVENE": "\033[91m",  # red
    "COLLAPSE":  "\033[31m",  # dark red
}
RESET = "\033[0m"


def to_json(result: "MoleculeResult", indent: int = 2, include_views: bool = False) -> str:
    return json.dumps(result.to_dict(include_views=include_views), indent=indent)


def to_markdown(result: "MoleculeResult") -> str:
    """Single-result markdown table."""
    lines = [
        f"## Molecule Report — {result.model_id}",
        f"**Probe:** {result.probe_case} — {result.probe_label}  ",
        f"**Regime:** `{result.regime}` | **ΔL3:** `{result.delta_L3}` | **Stress:** `{result.stress}`",
        "",
        "| Signal  | Value  | Description |",
        "|---------|--------|-------------|",
        f"| ΔL3     | {result.delta_L3:.4f} | Composite polarization score |",
        f"| Down    | {result.down:.4f} | Aggregate semantic drift |",
        f"| Strange | {result.strange:.4f} | Metric disagreement |",
        f"| Up      | {result.up:.4f} | Bimodality coefficient |",
        f"| Charm   | {result.charm:.4f} | Coherence field |",
        f"| Top     | {result.top:.4f} | Drift acceleration |",
        f"| Stress  | {result.stress:.4f} | Composite stress (Bottom quark) |",
        "",
        f"*Degenerate: {result.degenerate}*" if result.degenerate else "",
    ]
    return "\n".join(lines)


def to_csv_row(result: "MoleculeResult") -> str:
    """Single CSV row (without header)."""
    fields = [
        result.model_id, result.probe_case, result.probe_label,
        result.delta_L3, result.L1, result.L2,
        result.down, result.strange, result.up, result.charm, result.top,
        result.stress, result.regime, result.degenerate,
    ]
    return ",".join(str(f) for f in fields)


CSV_HEADER = (
    "model_id,probe_case,probe_label,delta_L3,L1,L2,"
    "down,strange,up,charm,top,stress,regime,degenerate"
)


def print_result(result: "MoleculeResult", color: bool = True) -> None:
    """Print a styled terminal summary."""
    regime_color = REGIME_COLORS.get(result.regime, "") if color else ""
    reset = RESET if color else ""

    print(f"\n{'─'*44}")
    print(f"  Molecule v{result.version}")
    print(f"  Model    : {result.model_id}")
    print(f"  Probe    : {result.probe_case} — {result.probe_label}")
    print(f"  ΔL3      : {result.delta_L3:.4f}")
    print(f"  Regime   : {regime_color}{result.regime}{reset}")
    print(f"  Stress   : {result.stress:.4f}")
    print(f"{'─'*44}")
    print(f"  ↓ Down    {result.down:.4f}  aggregate drift")
    print(f"  ~ Strange {result.strange:.4f}  metric disagreement")
    print(f"  ↑ Up      {result.up:.4f}  bimodality")
    print(f"  ◎ Charm   {result.charm:.4f}  coherence")
    print(f"  ⊤ Top     {result.top:.4f}  acceleration")
    print(f"{'─'*44}\n")
    if result.degenerate:
        print("  ⚠  Degenerate: all responses were identical\n")


def compare_table(results: dict[str, "MoleculeResult"]) -> str:
    """
    Multi-model comparison table in markdown.

    Args:
        results: Dict of model_id -> MoleculeResult (all same probe case).
    """
    if not results:
        return ""
    cases = list(results.values())
    lines = [
        f"## Molecule Comparison — {cases[0].probe_case} ({cases[0].probe_label})",
        "",
        "| Model | ΔL3 | Regime | Stress | Down | Strange | Up | Charm |",
        "|-------|-----|--------|--------|------|---------|----|-------|",
    ]
    for mid, r in results.items():
        lines.append(
            f"| {mid} | {r.delta_L3} | {r.regime} | {r.stress} "
            f"| {r.down} | {r.strange} | {r.up} | {r.charm} |"
        )
    return "\n".join(lines)
