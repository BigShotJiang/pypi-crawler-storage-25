"""
twoquarks CLI
=============
Command-line interface for Molecule polarization analysis.

Commands:
  twoquarks probe     — Probe a model via API
  twoquarks analyze   — Analyze pre-collected responses from a file
  twoquarks info      — Show probe case descriptions
  twoquarks version   — Show version
"""
from __future__ import annotations
import argparse
import json
import sys
import os


def cmd_probe(args):
    """Run a live probe against an API model."""
    from twoquarks import Probe
    from twoquarks.report import print_result, to_json, to_markdown, to_csv_row, CSV_HEADER

    # Build model callable based on provider
    provider = args.provider.lower()

    if provider == "openai":
        from twoquarks.adapters import openai_adapter
        model_fn = openai_adapter(
            model=args.model,
            api_key=args.api_key or os.environ.get("OPENAI_API_KEY"),
            max_tokens=args.max_tokens,
        )
    elif provider == "anthropic":
        from twoquarks.adapters import anthropic_adapter
        model_fn = anthropic_adapter(
            model=args.model,
            api_key=args.api_key or os.environ.get("ANTHROPIC_API_KEY"),
            max_tokens=args.max_tokens,
        )
    elif provider == "ollama":
        from twoquarks.adapters import ollama_adapter
        model_fn = ollama_adapter(model=args.model)
    elif provider == "litellm":
        from twoquarks.adapters import litellm_adapter
        model_fn = litellm_adapter(model=args.model)
    else:
        print(f"[error] Unknown provider '{provider}'. Use: openai, anthropic, ollama, litellm")
        sys.exit(1)

    probe = Probe(
        model    = model_fn,
        model_id = f"{provider}/{args.model}",
        n_views  = args.n_views,
        delay    = args.delay,
        verbose  = not args.quiet,
    )

    if args.all_cases:
        results = probe.run_all_cases(args.text)
        for case_id, result in results.items():
            _output_result(result, args.output_format, args)
    else:
        result = probe.run(args.text, case=args.case)
        _output_result(result, args.output_format, args)


def cmd_analyze(args):
    """Analyze pre-collected responses from a file or stdin."""
    from twoquarks import Analyzer
    from twoquarks.report import print_result, to_json, to_markdown

    analyzer = Analyzer(model_id=args.model_id)

    if args.input == "-":
        lines = [line.strip() for line in sys.stdin if line.strip()]
    else:
        with open(args.input, "r", encoding="utf-8") as f:
            lines = [line.strip() for line in f if line.strip()]

    if len(lines) < 2:
        print("[error] Need at least 2 responses (one per line)")
        sys.exit(1)

    result = analyzer.from_responses(lines, case=args.case)
    _output_result(result, args.output_format, args)


def cmd_info(args):
    """Show probe case descriptions and signal meanings."""
    from twoquarks.core.flavors import PROBE_CASES

    print("\n  Molecule — Probe Cases")
    print("  " + "─" * 42)
    for case_id, label in PROBE_CASES.items():
        print(f"  {case_id}  {label}")

    print("\n  Quark Signals")
    print("  " + "─" * 42)
    signals = [
        ("ΔL3",     "Composite polarization score (main metric)"),
        ("Down",    "Aggregate semantic drift across metrics"),
        ("Strange", "Metric disagreement (variance across distances)"),
        ("Up",      "Bimodality — split-regime behavior"),
        ("Charm",   "Coherence field — semantic stability"),
        ("Top",     "Drift acceleration — sudden regime shifts"),
        ("Stress",  "Bottom quark — composite structural stress"),
    ]
    for name, desc in signals:
        print(f"  {name:<10} {desc}")

    print("\n  Regimes: STABLE → WATCH → WARN → INTERVENE → COLLAPSE\n")


def cmd_version(args):
    from twoquarks import __version__
    print(f"twoquarks {__version__}")


def _output_result(result, fmt, args):
    from twoquarks.report import print_result, to_json, to_markdown, to_csv_row, CSV_HEADER

    if fmt == "json":
        print(to_json(result, include_views=getattr(args, "include_views", False)))
    elif fmt == "markdown":
        print(to_markdown(result))
    elif fmt == "csv":
        if getattr(args, "_csv_header_printed", False) is False:
            print(CSV_HEADER)
            args._csv_header_printed = True
        print(to_csv_row(result))
    else:
        print_result(result)


def main():
    parser = argparse.ArgumentParser(
        prog="twoquarks",
        description="Molecule — Isomeric Polarization Analysis for LLMs",
    )
    parser.add_argument("--version", action="store_true", help="Show version")
    sub = parser.add_subparsers(dest="command")

    # ── probe ────────────────────────────────────────────────────────────────
    p_probe = sub.add_parser("probe", help="Run a live probe against an API model")
    p_probe.add_argument("text",               help="The text/prompt to probe with")
    p_probe.add_argument("--provider",         default="openai",
                         help="API provider: openai, anthropic, ollama, litellm (default: openai)")
    p_probe.add_argument("--model",            default="gpt-4o-mini",
                         help="Model name (default: gpt-4o-mini)")
    p_probe.add_argument("--case",             default="C2",
                         help="Probe case: C1-C5 or custom (default: C2)")
    p_probe.add_argument("--all-cases",        action="store_true",
                         help="Run all standard probe cases (C1-C5)")
    p_probe.add_argument("--api-key",          default=None,
                         help="API key (or set env var OPENAI_API_KEY / ANTHROPIC_API_KEY)")
    p_probe.add_argument("--n-views",          type=int, default=5,
                         help="Number of probe variants (2-5, default: 5)")
    p_probe.add_argument("--delay",            type=float, default=0.5,
                         help="Delay between API calls in seconds (default: 0.5)")
    p_probe.add_argument("--max-tokens",       type=int, default=512)
    p_probe.add_argument("--output-format",    default="text",
                         choices=["text", "json", "markdown", "csv"],
                         help="Output format (default: text)")
    p_probe.add_argument("--include-views",    action="store_true",
                         help="Include raw response views in JSON output")
    p_probe.add_argument("--quiet",            action="store_true",
                         help="Suppress progress output")
    p_probe.set_defaults(func=cmd_probe)

    # ── analyze ──────────────────────────────────────────────────────────────
    p_analyze = sub.add_parser("analyze", help="Analyze responses from a file or stdin")
    p_analyze.add_argument("input",            help="Input file (one response per line) or '-' for stdin")
    p_analyze.add_argument("--case",           default="C2")
    p_analyze.add_argument("--model-id",       default="unknown",
                           help="Label for the model whose outputs you're analyzing")
    p_analyze.add_argument("--output-format",  default="text",
                           choices=["text", "json", "markdown", "csv"])
    p_analyze.set_defaults(func=cmd_analyze)

    # ── info ─────────────────────────────────────────────────────────────────
    p_info = sub.add_parser("info", help="Show probe cases and signal descriptions")
    p_info.set_defaults(func=cmd_info)

    # ── version ──────────────────────────────────────────────────────────────
    p_ver = sub.add_parser("version", help="Show version")
    p_ver.set_defaults(func=cmd_version)

    args = parser.parse_args()

    if args.version or args.command == "version":
        cmd_version(args)
        return

    if not args.command:
        parser.print_help()
        return

    args.func(args)


if __name__ == "__main__":
    main()
