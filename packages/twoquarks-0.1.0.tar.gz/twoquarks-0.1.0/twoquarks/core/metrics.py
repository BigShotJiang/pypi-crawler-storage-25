"""
twoquarks.core.metrics
======================
Text distance metrics used by the Molecule engine.
Ported 1-to-1 from molecule.mjs v7.1.3.
"""
from __future__ import annotations
import re
import math
from typing import Callable


def _tokenize(text: str) -> list[str]:
    return re.findall(r'\b\w+\b', text.lower())


def tfidf_cosine(a: str, b: str) -> float:
    """TF-IDF cosine distance (0=identical, 1=orthogonal)."""
    ta, tb = _tokenize(a), _tokenize(b)
    vocab = list(set(ta + tb))
    if not vocab:
        return 0.0
    def tf(tokens, w):
        return tokens.count(w) / len(tokens) if tokens else 0.0
    va = [tf(ta, w) for w in vocab]
    vb = [tf(tb, w) for w in vocab]
    dot = sum(x * y for x, y in zip(va, vb))
    na  = math.sqrt(sum(x * x for x in va))
    nb  = math.sqrt(sum(x * x for x in vb))
    if not na or not nb:
        return 0.0
    return 1.0 - dot / (na * nb)


def jaccard(a: str, b: str) -> float:
    """Jaccard token distance (0=identical, 1=disjoint)."""
    sa, sb = set(_tokenize(a)), set(_tokenize(b))
    if not sa and not sb:
        return 0.0
    inter = len(sa & sb)
    union = len(sa | sb)
    return 1.0 - inter / union if union else 0.0


def ngram_dist(a: str, b: str, n: int = 3) -> float:
    """Character n-gram distance."""
    def _ngrams(s: str) -> dict[str, int]:
        c: dict[str, int] = {}
        for i in range(len(s) - n + 1):
            k = s[i:i+n]
            c[k] = c.get(k, 0) + 1
        return c
    ca, cb = _ngrams(a), _ngrams(b)
    keys = set(ca) | set(cb)
    if not keys:
        return 0.0
    inter = sum(min(ca.get(k, 0), cb.get(k, 0)) for k in keys)
    union = sum(max(ca.get(k, 0), cb.get(k, 0)) for k in keys)
    return 1.0 - inter / union if union else 0.0


def len_ratio(a: str, b: str) -> float:
    """Relative length difference (0=equal length, 1=max diff)."""
    la, lb = len(a), len(b)
    if not la and not lb:
        return 0.0
    return abs(la - lb) / max(la, lb)


def pairwise_mean(texts: list[str], fn: Callable[[str, str], float]) -> float:
    """Mean pairwise distance across all pairs in texts."""
    pairs = [fn(texts[i], texts[j])
             for i in range(len(texts))
             for j in range(i + 1, len(texts))]
    return sum(pairs) / len(pairs) if pairs else 0.0


# Registry — extensible by users
METRIC_REGISTRY: dict[str, Callable[[str, str], float]] = {
    "tfidf_cosine": tfidf_cosine,
    "jaccard":      jaccard,
    "ngram_dist":   ngram_dist,
    "len_ratio":    len_ratio,
}
