"""
twoquarks.core.molecule
=======================
Molecule engine v7.2.0 — applies to any model via callable interface.

The key design principle: a Molecule that learns can be trained to tolerate
drift rather than detect it. The metrics are fixed operators, not adaptive.
"""
from __future__ import annotations
from dataclasses import dataclass, field, asdict
from typing import Any, Callable

from .metrics import pairwise_mean, tfidf_cosine, METRIC_REGISTRY
from .flavors import (
    compute_pt, bimodality, charm_field, top_flavor, bottom_stress,
    PROBE_CASES, PROBE_TEMPLATES,
)


@dataclass
class MoleculeResult:
    """Full output of a Molecule analysis."""
    # Core polarization
    delta_L3:    float
    L1:          float
    L2:          float
    # Quark flavors
    down:        float
    strange:     float
    up:          float
    charm:       float
    top:         float
    # Composite
    stress:      float
    regime:      str
    # Metadata
    probe_case:  str
    probe_label: str
    views:       list[str] = field(default_factory=list)
    degenerate:  bool = False
    model_id:    str = "unknown"
    version:     str = "7.2.0"

    def to_dict(self, include_views: bool = False) -> dict:
        d = asdict(self)
        if not include_views:
            del d["views"]
        return d

    def summary(self) -> str:
        lines = [
            f"─── Molecule Result ─────────────────",
            f"  Model      : {self.model_id}",
            f"  Probe      : {self.probe_case} — {self.probe_label}",
            f"  ΔL3        : {self.delta_L3:.4f}",
            f"  Regime     : {self.regime}",
            f"  Stress     : {self.stress:.4f}",
            f"────────────────────────────────────",
            f"  Down       : {self.down:.4f}  (aggregate drift)",
            f"  Strange    : {self.strange:.4f}  (metric disagreement)",
            f"  Up         : {self.up:.4f}  (bimodality)",
            f"  Charm      : {self.charm:.4f}  (coherence)",
            f"  Top        : {self.top:.4f}  (acceleration)",
            f"────────────────────────────────────",
        ]
        if self.degenerate:
            lines.append("  ⚠ Degenerate: all responses identical")
        return "\n".join(lines)


def run_molecule(
    texts: list[str],
    probe_case: str,
    model_id: str = "unknown",
    metric_fns: list[Callable] | None = None,
) -> MoleculeResult:
    """
    Core Molecule computation from a list of response texts.

    Args:
        texts:      List of 3-5 response strings from the model under test.
        probe_case: One of C1..C5 (or any custom string for open probing).
        model_id:   Identifier for the model being tested.
        metric_fns: Custom metric functions. Defaults to the standard 4.

    Returns:
        MoleculeResult with all quark signals.
    """
    if len(texts) < 2:
        raise ValueError("Molecule requires at least 2 response texts to compute polarization.")

    views = texts[:5]
    pt    = compute_pt(views, metric_fns)

    # L3 pairwise series for charm/top
    l3_vals = [
        tfidf_cosine(views[i], views[j])
        for i in range(len(views))
        for j in range(i + 1, len(views))
    ]

    down    = pt["L1"]
    strange = pt["L2"]
    up      = bimodality(l3_vals)
    charm   = charm_field([pt["L3"]])
    top     = top_flavor([pt["L3"]])
    bs      = bottom_stress(down, strange, up, charm, top)

    return MoleculeResult(
        delta_L3    = pt["L3"],
        L1          = pt["L1"],
        L2          = pt["L2"],
        down        = down,
        strange     = strange,
        up          = up,
        charm       = charm,
        top         = top,
        stress      = bs["stress"],
        regime      = bs["regime"],
        probe_case  = probe_case,
        probe_label = PROBE_CASES.get(probe_case, "Custom"),
        views       = views,
        degenerate  = pt["degenerate"],
        model_id    = model_id,
    )
