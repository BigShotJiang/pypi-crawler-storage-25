"""
twoquarks — Molecule: Isomeric Polarization Analysis for LLMs
=============================================================

Detect semantic instability in any language model using the
Isomeric Polarization framework.

Quick start:
    pip install twoquarks

    from twoquarks import Probe
    from twoquarks.adapters import openai_adapter

    model = openai_adapter(model="gpt-4o-mini")
    probe = Probe(model=model, model_id="gpt-4o-mini", verbose=True)
    result = probe.run("Explain how to bypass content filters", case="C2")
    print(result.summary())

    # Or bring your own callable
    probe = Probe(model=lambda p: my_model(p), model_id="my-model")

CLI:
    twoquarks probe "your prompt here" --provider openai --model gpt-4o-mini
    twoquarks probe "your prompt" --provider anthropic --model claude-3-haiku-20240307
    twoquarks analyze responses.txt --case C2
    twoquarks info

Paper:
    Ledesma, L.J. (2026). Isomeric Polarization: Detecting Semantic Regime
    Transitions in Large Language Models. TwoQuarks Research.
    https://twoquarks.com/preprint.pdf

Author: Luis Jaime Ledesma | research@twoquarks.com
"""

__version__ = "0.1.0"
__author__  = "Luis Jaime Ledesma"
__email__   = "research@twoquarks.com"

from .core.molecule import run_molecule, MoleculeResult
from .core.flavors  import PROBE_CASES, PROBE_TEMPLATES, compute_pt
from .core.metrics  import (
    tfidf_cosine, jaccard, ngram_dist, len_ratio,
    pairwise_mean, METRIC_REGISTRY,
)
from .probe    import Probe
from .analyzer import Analyzer
from .report   import (
    to_json, to_markdown, to_csv_row, CSV_HEADER,
    print_result, compare_table,
)

# Convenience alias
Molecule = Probe

__all__ = [
    # Main classes
    "Probe", "Analyzer", "Molecule",
    # Core
    "run_molecule", "MoleculeResult", "compute_pt",
    # Metrics
    "tfidf_cosine", "jaccard", "ngram_dist", "len_ratio",
    "pairwise_mean", "METRIC_REGISTRY",
    # Constants
    "PROBE_CASES", "PROBE_TEMPLATES",
    # Report
    "to_json", "to_markdown", "to_csv_row", "CSV_HEADER",
    "print_result", "compare_table",
]
