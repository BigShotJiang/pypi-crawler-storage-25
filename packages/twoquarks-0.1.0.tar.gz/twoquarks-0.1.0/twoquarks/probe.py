"""
twoquarks.probe
===============
Probe — the main interface for applying Molecule to any model.

Usage with any callable:

    from twoquarks import Probe

    # OpenAI
    import openai
    client = openai.OpenAI()
    def my_model(prompt: str) -> str:
        return client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[{"role": "user", "content": prompt}]
        ).choices[0].message.content

    probe = Probe(model=my_model, model_id="gpt-4o-mini")
    result = probe.run("Explain how to bypass safety filters", case="C2")
    print(result.summary())

    # Anthropic
    import anthropic
    client = anthropic.Anthropic()
    def claude_model(prompt: str) -> str:
        return client.messages.create(
            model="claude-3-haiku-20240307",
            max_tokens=512,
            messages=[{"role": "user", "content": prompt}]
        ).content[0].text

    probe = Probe(model=claude_model, model_id="claude-haiku")
    result = probe.run("Tell me something controversial", case="C1")

    # Local / HuggingFace / any callable
    probe = Probe(model=lambda p: my_local_llm(p), model_id="local-7b")
"""
from __future__ import annotations
import time
from typing import Callable

from .core.flavors import PROBE_TEMPLATES, PROBE_CASES
from .core.molecule import run_molecule, MoleculeResult


class Probe:
    """
    Applies Molecule polarization analysis to any model.

    The model parameter must be a callable: (str) -> str
    That's it. No dependencies on any specific API.

    Args:
        model:      A callable that takes a prompt string and returns a response string.
        model_id:   Human-readable identifier for the model being tested.
        n_views:    Number of probe variants to generate (3-5, default 5).
        delay:      Seconds to wait between API calls (default 0.5).
        metric_fns: Custom metric functions list (optional).
        verbose:    Print progress during probing.
    """

    def __init__(
        self,
        model: Callable[[str], str],
        model_id: str = "unnamed_model",
        n_views: int = 5,
        delay: float = 0.5,
        metric_fns: list | None = None,
        verbose: bool = False,
    ):
        if not callable(model):
            raise TypeError("model must be a callable: (str) -> str")
        if not 2 <= n_views <= 5:
            raise ValueError("n_views must be between 2 and 5")

        self.model      = model
        self.model_id   = model_id
        self.n_views    = n_views
        self.delay      = delay
        self.metric_fns = metric_fns
        self.verbose    = verbose

    def _log(self, msg: str):
        if self.verbose:
            print(f"[Probe/{self.model_id}] {msg}")

    def _build_prompts(self, text: str, case: str) -> list[str]:
        """
        Build n_views prompt variants for the given probe case.
        For standard cases (C1-C5), uses the PROBE_TEMPLATES.
        For custom cases, generates lightweight structural variants.
        """
        templates = PROBE_TEMPLATES.get(case)
        if templates:
            return [t.replace("{text}", text) for t in templates[:self.n_views]]

        # Custom case: create structural variants
        base    = text
        variants = [
            base,
            f"Consider this carefully: {base}",
            f"Respond to the following: {base}",
            f"Your analysis of: {base}",
            f"Elaborate on: {base}",
        ]
        return variants[:self.n_views]

    def run(
        self,
        text: str,
        case: str = "C2",
        responses: list[str] | None = None,
    ) -> MoleculeResult:
        """
        Run a full Molecule probe on the model.

        Args:
            text:      The core prompt/text to probe with.
            case:      Probe case — C1-C5 or any custom string.
            responses: If provided, use these instead of calling the model.
                       Useful for offline analysis of already-collected outputs.

        Returns:
            MoleculeResult with all quark signals and regime classification.
        """
        if responses is not None:
            if len(responses) < 2:
                raise ValueError("At least 2 responses required for polarization analysis.")
            self._log(f"Using {len(responses)} pre-collected responses for {case}")
            return run_molecule(responses[:self.n_views], case, self.model_id, self.metric_fns)

        # Build prompts and collect responses
        prompts = self._build_prompts(text, case)
        collected: list[str] = []

        for i, prompt in enumerate(prompts):
            self._log(f"Collecting view {i+1}/{len(prompts)} for {case}...")
            try:
                response = self.model(prompt)
                if not isinstance(response, str):
                    response = str(response)
                collected.append(response)
            except Exception as e:
                self._log(f"Error on view {i+1}: {e}")
                # Partial failure — continue if we have enough
                if len(collected) < 2:
                    raise RuntimeError(
                        f"Model failed before collecting minimum 2 responses. Error: {e}"
                    ) from e
                break

            if i < len(prompts) - 1:
                time.sleep(self.delay)

        self._log(f"Computing Molecule on {len(collected)} responses...")
        return run_molecule(collected, case, self.model_id, self.metric_fns)

    def run_all_cases(
        self,
        text: str,
        cases: list[str] | None = None,
    ) -> dict[str, MoleculeResult]:
        """
        Run Molecule across multiple probe cases.

        Args:
            text:  The core text to probe with.
            cases: List of cases to run. Defaults to all standard cases (C1-C5).

        Returns:
            Dict mapping case_id -> MoleculeResult
        """
        if cases is None:
            cases = list(PROBE_CASES.keys())

        results = {}
        for case in cases:
            self._log(f"Running case {case}: {PROBE_CASES.get(case, 'Custom')}...")
            results[case] = self.run(text, case)
            time.sleep(self.delay)

        return results

    def compare(
        self,
        text: str,
        other_model: Callable[[str], str],
        other_id: str = "model_B",
        case: str = "C2",
    ) -> dict:
        """
        Compare this model against another on the same probe.
        Returns side-by-side results with delta analysis.

        Args:
            text:        The text to probe both models with.
            other_model: The second model callable.
            other_id:    ID for the second model.
            case:        Probe case to use.

        Returns:
            Dict with 'model_a', 'model_b', and 'delta' keys.
        """
        result_a = self.run(text, case)

        probe_b  = Probe(
            model      = other_model,
            model_id   = other_id,
            n_views    = self.n_views,
            delay      = self.delay,
            metric_fns = self.metric_fns,
            verbose    = self.verbose,
        )
        result_b = probe_b.run(text, case)

        delta = {
            "delta_L3":    round(result_b.delta_L3 - result_a.delta_L3, 4),
            "delta_stress": round(result_b.stress - result_a.stress, 4),
            "more_unstable": result_b.model_id if result_b.delta_L3 > result_a.delta_L3
                             else result_a.model_id,
        }

        return {
            "model_a": result_a.to_dict(),
            "model_b": result_b.to_dict(),
            "delta":   delta,
        }
