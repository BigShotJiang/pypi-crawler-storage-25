"""
twoquarks.analyzer
==================
Analyzer — for offline / batch analysis of pre-collected responses.

Use when you already have model outputs and want to compute Molecule
without making new API calls.

    from twoquarks import Analyzer

    # Analyze pre-collected outputs
    analyzer = Analyzer(model_id="gpt-4o")
    result = analyzer.from_responses(
        responses=["Response A...", "Response B...", "Response C..."],
        case="C2"
    )
    print(result.summary())

    # Batch analysis across multiple prompts
    results = analyzer.batch([
        {"responses": ["R1", "R2", "R3"], "case": "C1"},
        {"responses": ["R4", "R5", "R6"], "case": "C2"},
    ])
"""
from __future__ import annotations
from typing import Any
from .core.molecule import run_molecule, MoleculeResult
from .core.flavors import PROBE_CASES


class Analyzer:
    """
    Offline polarization analyzer — no model required.

    Args:
        model_id:   Identifier for the model whose outputs you're analyzing.
        metric_fns: Custom metric functions list (optional).
    """

    def __init__(
        self,
        model_id: str = "unknown",
        metric_fns: list | None = None,
    ):
        self.model_id   = model_id
        self.metric_fns = metric_fns

    def from_responses(
        self,
        responses: list[str],
        case: str = "C2",
    ) -> MoleculeResult:
        """
        Compute Molecule from a list of pre-collected response strings.

        Args:
            responses: List of 2-5 response strings.
            case:      Probe case label (C1-C5 or custom).

        Returns:
            MoleculeResult
        """
        if len(responses) < 2:
            raise ValueError("At least 2 responses required.")
        return run_molecule(responses[:5], case, self.model_id, self.metric_fns)

    def batch(self, items: list[dict]) -> list[MoleculeResult]:
        """
        Analyze multiple sets of responses in batch.

        Args:
            items: List of dicts, each with 'responses' (list[str]) and
                   optionally 'case' (str, default 'C2') and 'model_id' (str).

        Returns:
            List of MoleculeResult, one per item.
        """
        results = []
        for item in items:
            responses = item.get("responses", [])
            case      = item.get("case", "C2")
            mid       = item.get("model_id", self.model_id)
            results.append(run_molecule(responses[:5], case, mid, self.metric_fns))
        return results

    def from_file(self, path: str, case: str = "C2") -> MoleculeResult:
        """
        Load responses from a plain text file (one response per line).

        Args:
            path: Path to text file.
            case: Probe case.
        """
        with open(path, "r", encoding="utf-8") as f:
            responses = [line.strip() for line in f if line.strip()]
        return self.from_responses(responses, case)

    def compare_cases(
        self,
        responses: list[str],
        cases: list[str] | None = None,
    ) -> dict[str, MoleculeResult]:
        """
        Run the same set of responses across multiple probe cases.
        Useful for understanding which case dimension is most active.

        Returns:
            Dict mapping case_id -> MoleculeResult
        """
        if cases is None:
            cases = list(PROBE_CASES.keys())
        return {case: self.from_responses(responses, case) for case in cases}
