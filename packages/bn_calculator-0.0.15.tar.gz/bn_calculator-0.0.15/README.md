# Service Calculator


## About

Provides a method for microservices to process data from the byneuron platform. Extends to the connector service.

## Concept

In general this method host the process in 3 steps: 
1/ input aggregated data from sources;
2/ performs calculations 
3/ outputs the data to targets.

Handling: 
A/ Scope: Multiple (async) or Single
B/ TimeRange: Actual (for cron based Task intervals), Recent (periodic updates), Historic (init/edit)

Datamodel:
Sources are linked to the entity using:
- itemRelation using metaValues
- deviceRelation using deviceDefinition
- ? solarDevice
Targets are features of the entity.

Framework:
1/ Build configuration in CalculationEntityDefinition (ced) [configurator.py] -> panda & numpy
2/ Start a CalculationHandler(ch) with the ced [handler.py] -> byneuron backend
3/ Retrieve CalculationHandlerEntity (che) from ch [handler.py] -> byneuron backend
- che will be enriched with a ced adjusted per tenant when retrieved.
- the datamodel for the individual che will only be queried at the che.handle()
4/ Finally a CalculationEntity (ce). [calculator.py]
- the ce hold the calculation logic
