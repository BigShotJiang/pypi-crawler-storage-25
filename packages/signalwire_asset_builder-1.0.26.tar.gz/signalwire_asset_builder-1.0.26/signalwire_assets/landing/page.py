"""
Landing page assembler.

``build_page`` takes a page-data dict (title + sections array) and returns a
complete, self-contained HTML string.  ``build_batch`` processes every JSON
file in a directory.

Section-level options:
  - ``"bg": "pattern-name"`` adds a background texture (dots, grid, noise,
    hex, diagonal, orbs, dots-orbs, grid-orbs, logo, nebula). Some section types
    have defaults (hero: dots-orbs, features: dots, comparison: grid,
    steps: hex, cta: logo-slow, anatomy: diagonal).
  - Features sections accept ``"card_bg": "pattern-name"`` for per-card patterns.

Icons: comparison checkmarks/xmarks, callout icons, and pricing checkmarks
use bundled Font Awesome Pro SVGs (currentColor). No emoji.

Social links: Discord, GitHub, LinkedIn appear in navbar and footer.
"""

import json
import os

_ASSETS = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "assets")
import re
from importlib import resources as _pkg_resources

from .css import COMPONENT_CSS
from .renderers import _esc, _render_cta, SECTION_RENDERERS
from .tokens import generate_css, load_tokens


# ---------------------------------------------------------------------------
# Defaults
# ---------------------------------------------------------------------------

_COPY_SVG_JS = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>'

def _load_social_svg(name):
    """Load a social icon SVG from bundled assets, clean it for inline use."""
    import re as _re
    p = os.path.join(_ASSETS, name)
    if not os.path.exists(p):
        return ""
    with open(p) as f:
        svg = f.read()
    svg = _re.sub(r'<\?xml[^?]*\?>', '', svg)
    svg = _re.sub(r'<!DOCTYPE[^>]*>', '', svg)
    svg = _re.sub(r'<!--.*?-->', '', svg, flags=_re.DOTALL)
    svg = svg.strip()
    # Inject width/height for consistent sizing
    svg = svg.replace('<svg ', '<svg width="20" height="20" ', 1)
    return svg

_SOCIAL_DISCORD = _load_social_svg("discord-icon-svgrepo-com.svg")
_SOCIAL_GITHUB = _load_social_svg("github-repo-git-octocat-svgrepo-com.svg")
_SOCIAL_LINKEDIN = _load_social_svg("linkedin-svgrepo-com.svg")

_SOCIAL_LINKS_HTML = f"""<div class="lp-social">
  <a href="https://discord.gg/aUg4wc7Dkr" target="_blank" rel="noopener" title="Join our Discord">{_SOCIAL_DISCORD}</a>
  <a href="https://github.com/signalwire" target="_blank" rel="noopener" title="GitHub">{_SOCIAL_GITHUB}</a>
  <a href="https://www.linkedin.com/company/signalwire/" target="_blank" rel="noopener" title="LinkedIn">{_SOCIAL_LINKEDIN}</a>
</div>"""

_DEFAULT_CTA_BUTTONS = [
    {"text": "Get Started Free", "url": "https://signalwire.com/signup", "style": "primary"},
    {"text": "Read the Docs", "url": "https://developer.signalwire.com", "style": "secondary"},
]

_DEFAULT_NAV_LINKS = [
    {"text": "Docs", "url": "https://developer.signalwire.com"},
    {"text": "Pricing", "url": "https://signalwire.com/pricing"},
    {"text": "GitHub", "url": "https://github.com/signalwire"},
]

_DEFAULT_FOOTER = {
    "copyright": "SignalWire, Inc.",
    "links": [
        {"text": "Privacy Policy", "url": "https://signalwire.com/legal/privacy-policy"},
        {"text": "Legal", "url": "https://signalwire.com/company/legal"},
        {"text": "Contact", "url": "https://signalwire.com/company/contact"},
    ],
}


# ---------------------------------------------------------------------------
# Bundled SVG loader
# ---------------------------------------------------------------------------

def _load_bundled_svg(name):
    ref = _pkg_resources.files("signalwire_assets").joinpath("assets", name)
    svg = ref.read_text()
    svg = re.sub(r'<\?xml[^?]*\?>\s*', '', svg)
    svg = re.sub(r'<!DOCTYPE[^>]*>\s*', '', svg)
    return svg.strip()


# ---------------------------------------------------------------------------
# Tracking script helpers
# ---------------------------------------------------------------------------

def _tracking_scripts(tracking):
    """Return (gtm_html, fullstory_html, hubspot_html, zoominfo_html) from a tracking dict."""
    if not tracking:
        return "", "", "", ""

    hs = ""
    if tracking.get("hubspot_portal_id", "PLACEHOLDER") != "PLACEHOLDER":
        hs = f'<script type="text/javascript" id="hs-script-loader" async defer src="//js.hs-scripts.com/{tracking["hubspot_portal_id"]}.js"></script>'

    gtm = ""
    gtm_ids = tracking.get("gtm_ids", [])
    if gtm_ids:
        calls = "".join(f"gtm('{gid}');" for gid in gtm_ids)
        gtm = ("<script>"
               "function gtm(id){"
               "(function(w,d,s,l,i){"
               "w[l]=w[l]||[];w[l].push({'gtm.start':new Date().getTime(),event:'gtm.js'});"
               "var f=d.getElementsByTagName(s)[0],j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';"
               "j.async=true;j.src='https://www.googletagmanager.com/gtm.js?id='+i+dl;"
               "f.parentNode.insertBefore(j,f);"
               "})(window,document,'script','dataLayer',id);}"
               f"{calls}"
               "</script>")

    fs = ""
    fs_org = tracking.get("fullstory_org", "")
    if fs_org:
        fs = ("<script>"
              f"window['_fs_host']='fullstory.com';window['_fs_script']='edge.fullstory.com/s/fs.js';window['_fs_org']='{fs_org}';window['_fs_namespace']='FS';"
              "(function(m,n,e,t,l,o,g,y){"
              "if(e in m){if(m.console&&m.console.log){m.console.log('FullStory namespace conflict.');}return;}"
              "g=m[e]=function(a,b,s){g.q?g.q.push([a,b,s]):g._api(a,b,s);};g.q=[];"
              "o=n.createElement(t);o.async=1;o.crossOrigin='anonymous';o.src='https://'+_fs_script;"
              "y=n.getElementsByTagName(t)[0];y.parentNode.insertBefore(o,y);"
              "g.identify=function(i,v,s){g(l,{uid:i},s);if(v)g(l,v,s)};g.setUserVars=function(v,s){g(l,v,s)};g.event=function(i,v,s){g('event',{n:i,p:v},s)};"
              "g.anonymize=function(){g.identify(!!0)};"
              "g.shutdown=function(){g('rec',!1)};g.restart=function(){g('rec',!0)};"
              "g.log=function(a,b){g('log',[a,b])};"
              "g.consent=function(a){g('consent',!arguments.length||a)};"
              "g.identifyAccount=function(i,v){o='account';v=v||{};v.acctId=i;g(o,v)};"
              "g.clearUserCookie=function(){};"
              "g.setVars=function(n,p){g('setVars',[n,p])};"
              "g._w={};y='XMLHttpRequest';g._w[y]=m[y];y='fetch';g._w[y]=m[y];"
              "if(m[y])m[y]=function(){return g._w[y].apply(this,arguments)};"
              "g._v='1.3.0';"
              "})(window,document,window['_fs_namespace'],'script','user');"
              "</script>")

    zi = ""
    zi_script = tracking.get("zoominfo_script", "")
    if zi_script:
        zi = zi_script

    return gtm, fs, hs, zi


# ---------------------------------------------------------------------------
# Recipe validation
# ---------------------------------------------------------------------------

# Nebula sliced bgs that stand alone as section backgrounds.
_NEBULA_SLICED = {
    "sliced-drip", "sliced-drip-up",
    "sliced-hair", "sliced-hair-up",
    "sliced-rain", "sliced-rain-up",
    "sliced-edges", "sliced-corner", "sliced-custom",
}

# Glow-layer sliced bgs that are colored glow layers meant to sit behind a card.
_GLOW_LAYER_SLICED = {
    "sliced-glow", "sliced-glow-up",
    "sliced-ocean", "sliced-ocean-up",
    "sliced-teal", "sliced-teal-up",
}

# Known fields per section type. Anything outside these is silently ignored by the
# renderer; warn so authors catch typos like "variant" instead of "style" on callout.
_KNOWN_FIELDS = {
    "callout": {"type", "style", "title", "text"},
    "code": {"type", "title", "desc", "language", "code", "card", "tilt", "magnetic",
             "parallax", "typing", "bg", "slice_from", "slice_color", "slice_glow",
             "slice_fade", "slice_clouds", "slice_animate", "blast_color",
             "blast_color_1", "blast_color_2", "blast_opacity"},
}


def _warn(msg):
    import sys
    sys.stderr.write(f"[landing recipe] warn: {msg}\n")


def _validate_page_recipe(sections):
    """Lint the page against hard rules that cause real bugs or silent content
    drops. Soft composition rules (number of sliced bgs, number of cards, bracket
    placement) are left to the author's judgment and the archetype guidance in
    the design cheatsheet. Non-fatal warnings to stderr."""
    for i, s in enumerate(sections):
        stype = s.get("type", "text")
        bg = s.get("bg")
        card = s.get("card")

        # Hard rule 1: bg + card on same section (except card:glow + glow-layer sliced)
        if bg and card:
            glow_layer_pair = card == "glow" and bg in _GLOW_LAYER_SLICED
            if not glow_layer_pair:
                _warn(f"section #{i} ({stype}): bg='{bg}' + card='{card}' on same section. "
                      f"Use the card OR the bg, not both. Only card:'glow' + glow-layer "
                      f"sliced (ocean/teal/glow) is the intended pair.")

        # Hard rule 2: tilt + magnetic on same section
        if s.get("tilt") and s.get("magnetic"):
            _warn(f"section #{i} ({stype}): tilt + magnetic on same section fight over "
                  f"the cursor. Keep tilt on features sections and magnetic on CTA.")

        # Hard rule 3: bg on features sections
        if stype == "features" and bg and bg != "none":
            _warn(f"section #{i} (features): bg='{bg}' on a features section adds texture "
                  f"behind an already-dense card grid. Remove bg, or use card:'blast' for "
                  f"emphasis without double-stacking.")

        # Hard rule 5: glow-layer sliced as standalone bg (no card wrapper)
        if bg in _GLOW_LAYER_SLICED and not card:
            _warn(f"section #{i} ({stype}): bg='{bg}' is a glow-layer variant designed to "
                  f"sit behind a card. Without card:'glow' or card:'blast' on this section, "
                  f"it renders as a flat band. Either add a card wrapper or switch to a "
                  f"nebula sliced (drip/hair/rain) for standalone atmospheric bg.")

        # Hard rule 7: unknown fields (silent drops)
        known = _KNOWN_FIELDS.get(stype)
        if known:
            unknown = set(s.keys()) - known
            if unknown:
                _warn(f"section #{i} ({stype}): unknown fields {sorted(unknown)}. "
                      f"The renderer silently ignores these. Correct field names for "
                      f"{stype}: {sorted(known)}.")


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def build_page(
    page_data,
    tokens=None,
    *,
    token_css=None,
    cta_buttons=None,
    nav_links=None,
    footer=None,
    tracking=None,
    logo_white_svg=None,
    logo_black_svg=None,
):
    """Assemble a complete, self-contained HTML landing page.

    Parameters
    ----------
    page_data : dict
        Must contain ``"title"`` and ``"sections"`` (list of typed section
        dicts).
    tokens : dict, optional
        DTCG token dict.  Loaded from the bundled asset when *None*.
        Ignored when *token_css* is provided.
    token_css : str, optional
        Pre-generated CSS custom properties (from build_design.py).
        When provided, skips regeneration from DTCG.  This is the
        preferred path for local builds where build_design.py is the
        single CSS generator.
    cta_buttons : list[dict], optional
        Each dict has ``text``, ``url``, ``style`` (``"primary"`` or
        ``"secondary"``).
    nav_links : list[dict], optional
        Each dict has ``text`` and ``url``.
    footer : dict, optional
        ``{"copyright": str, "links": [{"text": str, "url": str}, ...]}``.
    tracking : dict, optional
        Keys: ``gtm_ids`` (list), ``fullstory_org`` (str),
        ``hubspot_portal_id`` (str).
    logo_white_svg : str, optional
        Raw SVG markup for the white-text logo (dark backgrounds).
    logo_black_svg : str, optional
        Raw SVG markup for the black-text logo (light backgrounds).
    """
    if token_css is not None:
        css_text = token_css
    else:
        tokens = load_tokens(tokens)
        css_text = generate_css(tokens)

    if cta_buttons is None:
        cta_buttons = _DEFAULT_CTA_BUTTONS
    if nav_links is None:
        nav_links = _DEFAULT_NAV_LINKS
    if footer is None:
        footer = _DEFAULT_FOOTER

    logo_white = logo_white_svg or _load_bundled_svg("signalwire-full-logo-white-text.svg")
    logo_black = logo_black_svg or _load_bundled_svg("signalwire-full-logo-black-text.svg")

    title = page_data.get("title", "SignalWire")
    sections = page_data.get("sections", [])
    effects = page_data.get("effects", {})  # global effect defaults

    # OpenGraph: extract description from hero subtitle or page-level field
    og_desc = page_data.get("og_description", "")
    og_image = page_data.get("og_image", "https://mcdn.signalwire.com/images/v2/social_generic.png")
    og_url = page_data.get("og_url", "")
    if not og_desc:
        for _s in sections:
            if _s.get("type") == "hero" and _s.get("subtitle"):
                og_desc = _s["subtitle"]
                break
    if not og_desc:
        og_desc = f"{title} | SignalWire"

    # CTA HTML
    cta_html = '<div class="lp-cta-row">'
    for btn in cta_buttons:
        cls = "lp-btn lp-btn--primary" if btn["style"] == "primary" else "lp-btn lp-btn--secondary"
        cta_html += f'<a href="{btn["url"]}" class="{cls}">{_esc(btn["text"])}</a>'
    cta_html += "</div>"

    # Nav
    nav_html = ""
    for link in nav_links:
        # Skip GitHub from text links (it's in the social icons now)
        if link.get("url", "").startswith("https://github.com"):
            continue
        nav_html += f'<a href="{link["url"]}">{_esc(link["text"])}</a>'

    # Footer
    footer_links = "".join(f'<a href="{l["url"]}">{_esc(l["text"])}</a>' for l in footer["links"])

    # Validate page against the Landing Page Recipe.
    # Warnings only; the builder still renders so authors can iterate, but these
    # flag combinations that typically break the aesthetic or silently drop content.
    _validate_page_recipe(sections)

    # Sections
    body_sections = ""
    has_cta = False
    for s in sections:
        stype = s.get("type", "text")
        # Inject HubSpot config into contact sections
        if stype == "contact" and tracking:
            hs_portal = tracking.get("hubspot_portal_id", "")
            hs_form = tracking.get("hubspot_form_id", "")
            if hs_portal and hs_portal != "PLACEHOLDER" and hs_form and hs_form != "PLACEHOLDER":
                s["_hs_portal"] = hs_portal
                s["_hs_form"] = hs_form
        renderer = SECTION_RENDERERS.get(stype, SECTION_RENDERERS["text"])
        html = renderer(s, cta_html)
        # Add scroll reveal to content sections (not hero, not logos)
        if stype not in ("hero", "logos"):
            html = html.replace('class="lp-section"', 'class="lp-section lp-reveal"', 1)
            html = html.replace('class="lp-section lp-section--stats"', 'class="lp-section lp-section--stats lp-reveal"', 1)
            html = html.replace('class="lp-section lp-section--logos"', 'class="lp-section lp-section--logos"', 1)
            html = html.replace('class="lp-section lp-section--cta"', 'class="lp-section lp-section--cta lp-reveal"', 1)
        # Per-section background pattern
        # Recipe: open bracket (hero) + close bracket (cta) get atmospheric defaults.
        # Everything else stays clean unless the JSON explicitly opts in. This enforces
        # the "clean middle" rule from the landing page recipe.
        # To opt out of a default, set bg to "none" / "" / null / false in JSON.
        _DEFAULT_BG = {
            "hero": "dots-orbs",
            "cta": "logo-slow",
        }
        _sentinel = object()
        raw_bg = s.get("bg", _sentinel)
        if raw_bg is _sentinel:
            bg = _DEFAULT_BG.get(stype)
        elif raw_bg in (None, "", False, "none"):
            bg = None
        else:
            bg = raw_bg
        if bg:
            # Hero uses class="lp-hero" (not lp-section); every other section uses lp-section.
            if stype == 'hero':
                html = html.replace('class="lp-hero"', f'class="lp-hero sw-bg-{bg}"', 1)
            else:
                html = html.replace('class="lp-section', f'class="lp-section sw-bg-{bg}', 1)
        # Sliced nebula: handle direction, clouds, animation, custom vars, and glow panel
        if bg and bg.startswith("sliced"):
            # Direction class
            _SLICED_DIR = {
                "sliced-drip": "sl-from-top", "sliced-hair": "sl-from-top",
                "sliced-rain": "sl-from-top", "sliced-corner": "sl-from-tl",
                "sliced-drip-up": "sl-from-bottom", "sliced-hair-up": "sl-from-bottom",
                "sliced-rain-up": "sl-from-bottom", "sliced-edges": "sl-from-edges",
                "sliced-glow": "sl-from-bottom", "sliced-glow-up": "sl-from-top",
                "sliced-ocean": "sl-from-bottom", "sliced-ocean-up": "sl-from-top",
                "sliced-teal": "sl-from-bottom", "sliced-teal-up": "sl-from-top",
            }
            sl_from = s.get("slice_from")
            if sl_from:
                dir_cls = f"sl-from-{sl_from}"
            else:
                dir_cls = _SLICED_DIR.get(bg, "sl-from-top")
            html = html.replace(f'sw-bg-{bg}', f'sw-bg-{bg} {dir_cls}', 1)
            # Animation
            _SLICED_ANIM = {"sliced-drip", "sliced-drip-up"}
            if s.get("slice_animate") or bg in _SLICED_ANIM:
                html = html.replace(dir_cls, f'{dir_cls} sl-anim', 1)
            # Cloud underlay (all except rain variants)
            _NO_CLOUDS = {"sliced-rain", "sliced-rain-up", "sliced-glow", "sliced-glow-up", "sliced-ocean", "sliced-ocean-up", "sliced-teal", "sliced-teal-up"}
            wants_clouds = s.get("slice_clouds", bg not in _NO_CLOUDS)
            if wants_clouds:
                html = html.replace('</section>', '<div class="lp-sliced__clouds"></div></section>', 1)
            # Custom CSS vars
            style_parts = []
            for prop, var in [("slice_glow","--sl-glow"), ("slice_fade","--sl-fade"),
                              ("slice_color","--sl-color")]:
                val = s.get(prop)
                if val is not None:
                    if prop == "slice_fade":
                        style_parts.append(f"{var}:{val}%")
                    else:
                        style_parts.append(f"{var}:{val}")
            if style_parts:
                style_str = ";".join(style_parts)
                html = html.replace('<section ', f'<section style="{style_str}" ', 1)
        # Card wrappers
        card = s.get("card", "")
        if card == "glow":
            html = html.replace('<div class="lp-container">', '<div class="lp-container"><div class="lp-glow-panel">', 1)
            html = html.replace('</div>\n</section>', '</div></div>\n</section>', 1)
        elif card in ("blast", "blast_grad"):
            # Build style string for blast colors
            bstyle_parts = []
            if s.get("blast_color"):
                bstyle_parts.append(f'--blast-color:{s["blast_color"]}')
            if s.get("blast_color_1"):
                bstyle_parts.append(f'--blast-color-1:{s["blast_color_1"]}')
            if s.get("blast_color_2"):
                bstyle_parts.append(f'--blast-color-2:{s["blast_color_2"]}')
            if s.get("blast_opacity"):
                bstyle_parts.append(f'--blast-opacity:{s["blast_opacity"]}')
            bstyle = f' style="{";".join(bstyle_parts)}"' if bstyle_parts else ""
            glow_cls = "lp-blast-glow--single" if card == "blast" else "lp-blast-glow--grad"
            blast_html = f'<div class="lp-blast-wrap"{bstyle}><div class="lp-blast-glow {glow_cls}"></div><div class="lp-blast-panel">'
            html = html.replace('<div class="lp-container">', f'<div class="lp-container">{blast_html}', 1)
            html = html.replace('</div>\n</section>', '</div></div></div>\n</section>', 1)
        # Interactive effects (opt-in per section via JSON fields)
        _FX_FIELDS = {
            "glow": "data-fx-glow",
            "tilt": "data-fx-tilt",
            "magnetic": "data-fx-magnetic",
            "parallax": "data-fx-parallax",
            "reveal_bg": "data-fx-reveal-bg",
            "typing": "data-fx-typing",
        }
        fx_attrs = ""
        for field, attr in _FX_FIELDS.items():
            val = s.get(field) or effects.get(field)
            if val:
                if isinstance(val, bool) and val:
                    fx_attrs += f' {attr}'
                elif isinstance(val, (int, float)):
                    fx_attrs += f' {attr}="{val}"'
                elif isinstance(val, str):
                    fx_attrs += f' {attr}="{_re.sub(r"[^a-zA-Z0-9_.#, ()-]", "", val)}"'
        if fx_attrs:
            html = html.replace('<section ', f'<section{fx_attrs} ', 1)
        body_sections += html + "\n"
        if stype in ("cta", "contact"):
            has_cta = True

    # Auto-add closing CTA if none specified
    if not has_cta:
        body_sections += _render_cta({"headline": "Ready to build?"}, cta_html) + "\n"

    # Tracking
    gtm, fs, hs, zi = _tracking_scripts(tracking)

    return f"""<!DOCTYPE html>
<html lang="en" data-theme="dark">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>{_esc(title)} | SignalWire</title>
<meta name="description" content="{_esc(og_desc)}">
<meta property="og:title" content="{_esc(title)} | SignalWire">
<meta property="og:description" content="{_esc(og_desc)}">
<meta property="og:image" content="{_esc(og_image)}">
<meta property="og:type" content="website">
{"" if not og_url else f'<meta property="og:url" content="{_esc(og_url)}">' + chr(10)}<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:title" content="{_esc(title)} | SignalWire">
<meta name="twitter:description" content="{_esc(og_desc)}">
<meta name="twitter:image" content="{_esc(og_image)}">
<link href="https://fonts.googleapis.com/css2?family=Instrument+Sans:wght@400;600;700&family=Lexend:wght@300;400;500;600;700&family=Outfit:wght@400;500;600&family=JetBrains+Mono&display=swap" rel="stylesheet">
<style>
{css_text}
{COMPONENT_CSS}
</style>
{gtm}{fs}{hs}{zi}
</head>
<body>

<nav class="lp-navbar">
  <div class="lp-container lp-navbar__inner">
    <a href="https://signalwire.com" class="lp-navbar__logo">
      <span id="logo-dark">{logo_white}</span>
      <span id="logo-light" style="display:none">{logo_black}</span>
    </a>
    <div class="lp-navbar__links">
      {nav_html}
      {('<a href="' + cta_buttons[0]["url"] + '" class="lp-navbar__cta">' + _esc(cta_buttons[0]["text"]) + '</a>') if cta_buttons else ''}
      <button id="theme-toggle" onclick="toggleTheme()">&#x1F319;</button>
      <div class="lp-navbar__social">
        <a href="https://discord.gg/aUg4wc7Dkr" target="_blank" rel="noopener" title="Join our Discord">{_SOCIAL_DISCORD}</a>
        <a href="https://github.com/signalwire" target="_blank" rel="noopener" title="GitHub">{_SOCIAL_GITHUB}</a>
        <a href="https://www.linkedin.com/company/signalwire/" target="_blank" rel="noopener" title="LinkedIn">{_SOCIAL_LINKEDIN}</a>
      </div>
      <button class="lp-navbar__burger" onclick="document.querySelector('.lp-navbar__mobile').classList.toggle('lp-navbar__mobile--open')" aria-label="Menu">
        <svg width="20" height="20" viewBox="0 0 20 20" fill="none"><path d="M3 5h14M3 10h14M3 15h14" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/></svg>
      </button>
    </div>
  </div>
  <div class="lp-navbar__mobile">
    {('<a href="' + cta_buttons[0]["url"] + '" class="lp-btn lp-btn--primary" style="width:100%;justify-content:center">' + _esc(cta_buttons[0]["text"]) + '</a>') if cta_buttons else ''}
  </div>
</nav>
<div class="lp-accent-bar"></div>

{body_sections}

<div class="lp-accent-bar"></div>
<footer class="lp-footer">
  <div class="lp-container lp-footer__inner">
    <span>&copy; {_esc(footer["copyright"])}</span>
    {_SOCIAL_LINKS_HTML}
    <div class="lp-footer__links">{footer_links}</div>
  </div>
</footer>

<script>
function lpCopy(btn){{var code=btn.parentElement.querySelector("code");var text=code.textContent;navigator.clipboard.writeText(text).then(function(){{btn.innerHTML="\u2713";btn.classList.add("lp-copy-btn--done");setTimeout(function(){{btn.innerHTML='{_COPY_SVG_JS}';btn.classList.remove("lp-copy-btn--done")}},2000)}})}}
function lpCopyTerminal(btn){{var body=btn.closest(".lp-terminal").querySelector(".lp-terminal__body:not([style*='display:none'])");if(!body)body=btn.closest("pre");var text=body.textContent;navigator.clipboard.writeText(text).then(function(){{btn.innerHTML="\u2713";btn.classList.add("lp-copied");setTimeout(function(){{btn.innerHTML='{_COPY_SVG_JS}';btn.classList.remove("lp-copied")}},2000)}})}}
function lpTab(btn){{var term=btn.closest(".lp-terminal");term.querySelectorAll(".lp-tab__btn").forEach(function(b){{b.classList.remove("lp-tab--active")}});btn.classList.add("lp-tab--active");term.querySelectorAll(".lp-tab__panel").forEach(function(p){{p.style.display="none"}});document.getElementById(btn.dataset.tab).style.display="block"}}
function applyTheme(t){{document.documentElement.setAttribute("data-theme",t);var d=t!=="light";document.getElementById("logo-dark").style.display=d?"":"none";document.getElementById("logo-light").style.display=d?"none":"";document.getElementById("theme-toggle").textContent=d?"\\uD83C\\uDF19":"\\u2600\\uFE0F"}}
function toggleTheme(){{var n=document.documentElement.getAttribute("data-theme")==="light"?"dark":"light";localStorage.setItem("sw-theme",n);applyTheme(n)}}
(function(){{var s=localStorage.getItem("sw-theme");if(s)applyTheme(s)}})();
var _ro=new IntersectionObserver(function(e){{e.forEach(function(i){{if(i.isIntersecting){{i.target.classList.add("lp-visible");_ro.unobserve(i.target);}}}});}},{{threshold:0.1,rootMargin:"0px 0px -40px 0px"}});document.querySelectorAll(".lp-reveal").forEach(function(el){{_ro.observe(el);}});
/* Interactive effects */
if(!window.matchMedia("(prefers-reduced-motion:reduce)").matches){{
  /* Cursor glow */
  document.querySelectorAll("[data-fx-glow]").forEach(function(el){{
    var c=el.dataset.fxGlow;
    if(c&&c!=="true")el.style.setProperty("--glow-color",c);
    el.addEventListener("mouseenter",function(){{
      el.style.setProperty("--glow-opacity","1");
    }});
    el.addEventListener("mousemove",function(e){{
      var r=el.getBoundingClientRect();
      el.style.setProperty("--glow-x",(e.clientX-r.left)+"px");
      el.style.setProperty("--glow-y",(e.clientY-r.top)+"px");
      el.style.setProperty("--glow-opacity","1");
    }});
    el.addEventListener("mouseleave",function(){{
      el.style.setProperty("--glow-opacity","0");
    }});
  }});
  /* Card tilt */
  document.querySelectorAll("[data-fx-tilt]").forEach(function(sec){{
    var cards=sec.querySelectorAll(".lp-feature-card,.lp-pricing-tier");
    cards.forEach(function(card){{
      card.addEventListener("mousemove",function(e){{
        var r=card.getBoundingClientRect(),x=(e.clientX-r.left)/r.width,y=(e.clientY-r.top)/r.height;
        var rx=(y-0.5)*-4,ry=(x-0.5)*4;
        card.style.transform="perspective(800px) rotateX("+rx+"deg) rotateY("+ry+"deg) scale(1.02)";
      }});
      card.addEventListener("mouseleave",function(){{card.style.transform="";}});
    }});
  }});
  /* Magnetic buttons */
  document.querySelectorAll("[data-fx-magnetic]").forEach(function(sec){{
    var btns=sec.querySelectorAll(".lp-btn");
    btns.forEach(function(btn){{
      sec.addEventListener("mousemove",function(e){{
        var r=btn.getBoundingClientRect(),cx=r.left+r.width/2,cy=r.top+r.height/2;
        var dx=e.clientX-cx,dy=e.clientY-cy,dist=Math.sqrt(dx*dx+dy*dy);
        if(dist<120){{var pull=Math.max(0,(120-dist)/120)*3;btn.style.transform="translate("+dx/dist*pull+"px,"+dy/dist*pull+"px)";}}
        else{{btn.style.transform="";}}
      }});
      sec.addEventListener("mouseleave",function(){{btn.style.transform="";}});
    }});
  }});
  /* Parallax on scroll */
  var pxEls=document.querySelectorAll("[data-fx-parallax]");
  if(pxEls.length){{
    window.addEventListener("scroll",function(){{
      var st=window.pageYOffset;
      pxEls.forEach(function(el){{
        var rate=parseFloat(el.dataset.fxParallax)||0.3;
        var r=el.getBoundingClientRect(),off=(r.top+r.height/2-window.innerHeight/2)*rate;
        var after=el.querySelector(":scope > :last-child");
        if(el.style)el.style.setProperty("--px-offset",off+"px");
      }});
    }},{{passive:true}});
  }}
  /* Code typing burst */
  document.querySelectorAll("[data-fx-typing]").forEach(function(sec){{
    var code=sec.querySelector(".lp-code__block code");
    if(!code)return;
    var full=code.textContent,i=0,speed=2;
    code.textContent="";
    var tObs=new IntersectionObserver(function(entries){{
      if(entries[0].isIntersecting){{
        tObs.disconnect();
        var iv=setInterval(function(){{i+=speed;code.textContent=full.slice(0,i);if(i>=full.length){{clearInterval(iv);sec.classList.add("lp-typing-done");}}}},8);
      }}
    }},{{threshold:0.3}});
    tObs.observe(sec);
  }});
}}
</script>
</body>
</html>"""


def build_batch(content_dir, output_dir, **kwargs):
    """Build every ``*.json`` file in *content_dir* into *output_dir*.

    Extra *kwargs* are forwarded to :func:`build_page` (e.g. ``tokens``,
    ``cta_buttons``, ``tracking``).

    Returns the number of pages built.
    """
    os.makedirs(output_dir, exist_ok=True)
    built = 0
    for name in sorted(os.listdir(content_dir)):
        if not name.endswith(".json"):
            continue
        with open(os.path.join(content_dir, name)) as f:
            page_data = json.load(f)
        html = build_page(page_data, **kwargs)
        out_name = os.path.splitext(name)[0] + ".html"
        with open(os.path.join(output_dir, out_name), "w") as f:
            f.write(html)
        built += 1
    return built
