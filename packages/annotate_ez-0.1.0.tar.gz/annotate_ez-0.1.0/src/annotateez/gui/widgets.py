"""Reusable PyQt5 widgets for AnnotateEZ.

All widgets receive the live config dictionary and mutate it directly,
keeping the UI and config in sync without an intermediate model layer.
"""

import logging
from typing import Any, Dict, List, Optional

from PyQt5.QtCore import Qt, QPoint, QSize, pyqtSignal
from PyQt5.QtGui import QColor, QIcon, QImage, QPainter, QPen, QPixmap
from PyQt5.QtWidgets import (
    QCheckBox,
    QComboBox,
    QDoubleSpinBox,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QPushButton,
    QRadioButton,
    QVBoxLayout,
    QWidget,
)

from annotateez.config import DISPLAY_COLORS

logger = logging.getLogger(__name__)

# Maps label color names (as stored in config) to Qt global colors.
_COLOR_TO_QT: Dict[str, Qt.GlobalColor] = {
    "black": Qt.black,
    "red": Qt.red,
    "green": Qt.green,
    "blue": Qt.blue,
    "yellow": Qt.yellow,
    "magenta": Qt.magenta,
    "cyan": Qt.cyan,
    "white": Qt.white,
}


def _label_color(config: Dict[str, Any], label_id: int) -> QColor:
    """Return the QColor for a label ID looked up from config."""
    color_name = config["labels"][label_id]["color"]
    qt_color = _COLOR_TO_QT.get(color_name)
    if qt_color is None:
        logger.warning(
            "Unknown label color '%s' for label %d; defaulting to white.",
            color_name,
            label_id,
        )
        return QColor(Qt.white)
    return QColor(qt_color)


_SWATCH_SIZE: int = 12  # side length in pixels of the color swatch


def _color_swatch(color_name: str) -> QIcon:
    """Return a small filled square icon for the given color name."""
    px = QPixmap(_SWATCH_SIZE, _SWATCH_SIZE)
    qt_color = _COLOR_TO_QT.get(color_name, Qt.white)
    px.fill(QColor(qt_color))
    return QIcon(px)


class Legend(QWidget):
    """Dropdown for selecting the active annotation label.

    Each entry shows a colored swatch next to the label name. Emits
    ``label_changed(label_id)`` on selection change and updates
    ``config['active_label']`` in place.
    """

    label_changed = pyqtSignal(int)

    def __init__(self, config: Dict[str, Any]) -> None:
        super().__init__()
        self._config = config
        self._id_map: List[int] = []  # combo index → label_id

        self._combo = QComboBox()
        for i, label in enumerate(config["labels"]):
            if label["active"]:
                self._combo.addItem(
                    _color_swatch(label["color"]), label["name"]
                )
                self._id_map.append(i)

        active = config.get("active_label", 1)
        if active in self._id_map:
            self._combo.setCurrentIndex(self._id_map.index(active))

        self._combo.currentIndexChanged.connect(self._on_changed)

        layout = QHBoxLayout()
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(4)
        layout.addWidget(QLabel("Label:"))
        layout.addWidget(self._combo)
        self.setLayout(layout)

    def _on_changed(self, idx: int) -> None:
        if 0 <= idx < len(self._id_map):
            label_id = self._id_map[idx]
            self._config["active_label"] = label_id
            self.label_changed.emit(label_id)

    def set_active_label(self, label_id: int) -> None:
        """Update the dropdown to reflect label_id if it is present."""
        if label_id in self._id_map:
            self._combo.setCurrentIndex(self._id_map.index(label_id))


class LabelWidget(QWidget):
    """Settings row for configuring a single label (name and active state).

    Shows a numeric ID, a color-styled name text box, and an active
    checkbox. Mutations go directly to ``config['labels'][label_id]``.
    """

    def __init__(self, config: Dict[str, Any], label_id: int) -> None:
        super().__init__()
        self._config = config
        self._id = label_id

        label_cfg = config["labels"][label_id]

        id_label = QLabel(str(label_id))
        id_label.setAlignment(Qt.AlignCenter)

        self.textbox = QLineEdit()
        self.textbox.setFixedSize(QSize(128, 24))
        self.textbox.setStyleSheet(
            f"QLineEdit{{background: {label_cfg['color']}}}"
        )
        self.textbox.setText(label_cfg["name"])
        self.textbox.textChanged.connect(self._on_text_changed)

        self.checkbox = QCheckBox()
        self.checkbox.setStyleSheet(
            "QCheckBox::indicator{width: 24px; height: 24px;}"
        )
        self.checkbox.setChecked(label_cfg["active"])
        self.checkbox.stateChanged.connect(self._on_state_changed)
        self._sync_enabled()

        layout = QHBoxLayout()
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(5)
        layout.addWidget(id_label)
        layout.addWidget(self.textbox)
        layout.addWidget(self.checkbox)
        self.setLayout(layout)

    def _sync_enabled(self) -> None:
        self.textbox.setEnabled(self.checkbox.isChecked())

    def _on_state_changed(self) -> None:
        self._config["labels"][self._id]["active"] = self.checkbox.isChecked()
        self._sync_enabled()

    def _on_text_changed(self) -> None:
        self._config["labels"][self._id]["name"] = self.textbox.text()


class ColorChannelWidget(QWidget):
    """Settings row mapping one display color to a channel.

    Shows a color swatch, color name, a channel-selection dropdown, and a
    gain spinbox. Exactly one channel (or none) may be assigned to each
    display color. Mutations go directly to ``config['channels']``.
    """

    def __init__(self, config: Dict[str, Any], color: str) -> None:
        super().__init__()
        self._config = config
        self._color = color

        swatch = QLabel()
        px = QPixmap(_SWATCH_SIZE, _SWATCH_SIZE)
        px.fill(QColor(_COLOR_TO_QT.get(color, Qt.white)))
        swatch.setPixmap(px)

        color_label = QLabel(color)
        color_label.setFixedWidth(32)

        self._combo = QComboBox()
        self._combo.addItem("none")
        for ch in config["channels"]:
            self._combo.addItem(ch["name"])

        self._gain_spin = QDoubleSpinBox()
        self._gain_spin.setRange(0.01, 1000.0)
        self._gain_spin.setDecimals(2)
        self._gain_spin.setSingleStep(0.5)
        self._gain_spin.setFixedWidth(72)

        current = self._find_channel()
        if current is not None:
            self._combo.setCurrentText(current["name"])
            self._gain_spin.setValue(float(current.get("gain", 1.0)))
        else:
            self._gain_spin.setValue(1.0)
            self._gain_spin.setEnabled(False)

        self._combo.currentTextChanged.connect(self._on_channel_changed)
        self._gain_spin.valueChanged.connect(self._on_gain_changed)

        layout = QHBoxLayout()
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(5)
        layout.addWidget(swatch)
        layout.addWidget(color_label)
        layout.addWidget(self._combo)
        layout.addWidget(self._gain_spin)
        self.setLayout(layout)

    def _find_channel(self) -> Optional[Dict[str, Any]]:
        """Return the channel config entry assigned to this color, or None."""
        for ch in self._config["channels"]:
            if ch.get("display_color") == self._color:
                return ch
        return None

    def _on_channel_changed(self, name: str) -> None:
        for ch in self._config["channels"]:
            if ch.get("display_color") == self._color:
                ch["display_color"] = "none"
        if name != "none":
            for ch in self._config["channels"]:
                if ch["name"] == name:
                    ch["display_color"] = self._color
                    self._gain_spin.setValue(float(ch.get("gain", 1.0)))
                    self._gain_spin.setEnabled(True)
                    return
        self._gain_spin.setEnabled(False)

    def _on_gain_changed(self, value: float) -> None:
        ch = self._find_channel()
        if ch is not None:
            ch["gain"] = value


class TextBox(QWidget):
    """Labeled text input that updates a single config key on change.

    Preserves the existing value type: int config values are parsed as int,
    float values as float, all others as str. Invalid numeric input is
    silently ignored to avoid partial updates during typing.
    """

    def __init__(
        self,
        config: Dict[str, Any],
        key: str,
        title: str,
        default: Any,
    ) -> None:
        super().__init__()
        self._config = config
        self._key = key

        title_label = QLabel(title)
        title_label.setFixedHeight(32)

        self.textbox = QLineEdit()
        self.textbox.setFixedSize(64, 32)
        self.textbox.setText(str(default))
        self.textbox.textChanged.connect(self._on_text_changed)

        layout = QHBoxLayout()
        layout.addWidget(title_label)
        layout.addWidget(self.textbox)
        self.setLayout(layout)

    def _on_text_changed(self) -> None:
        text = self.textbox.text()
        if not text:
            return
        current = self._config[self._key]
        if isinstance(current, int):
            try:
                self._config[self._key] = int(text)
            except ValueError:
                pass
        elif isinstance(current, float):
            try:
                self._config[self._key] = float(text)
            except ValueError:
                pass
        else:
            self._config[self._key] = text


class Pos(QWidget):
    """Tile widget displaying one event image with a label-colored border.

    Left-click (or drag) assigns the active label; right-click (or drag)
    resets to label 0. Emits ``annotated(event_id, label)`` on click and
    ``drag_moved(global_pos, label)`` while dragging so the parent can
    annotate whichever tile is under the cursor.
    """

    annotated = pyqtSignal(int, int)
    drag_started = pyqtSignal()
    drag_moved = pyqtSignal(QPoint, int)
    drag_ended = pyqtSignal()

    def __init__(
        self,
        config: Dict[str, Any],
        event_id: int,
        image: QImage,
        label: int,
    ) -> None:
        super().__init__()
        self._config = config
        self.event_id = event_id
        self.image = image
        self.label = label
        self._drag_label: int = 0
        self._dragging: bool = False
        self.setFixedSize(QSize(config["tile_size"], config["tile_size"]))

    def reset(self, event_id: int, image: QImage, label: int) -> None:
        """Update tile content and trigger a repaint."""
        self.event_id = event_id
        self.image = image
        self.label = label
        self.update()

    def paintEvent(self, event) -> None:
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)
        r = event.rect()
        painter.drawImage(r, self.image)
        pen = QPen(_label_color(self._config, self.label))
        pen.setWidth(4)
        painter.setPen(pen)
        painter.drawRect(r)

    def mousePressEvent(self, event) -> None:
        if event.button() == Qt.RightButton:
            self._drag_label = 0
        elif event.button() == Qt.LeftButton:
            self._drag_label = self._config["active_label"]
        else:
            return
        self._dragging = True
        self.drag_started.emit()
        self.label = self._drag_label
        self.annotated.emit(self.event_id, self.label)
        self.update()

    def mouseMoveEvent(self, event) -> None:
        if self._dragging:
            self.drag_moved.emit(self.mapToGlobal(event.pos()), self._drag_label)

    def mouseReleaseEvent(self, event) -> None:
        if self._dragging:
            self._dragging = False
            self.drag_ended.emit()


class ChannelViewSelector(QWidget):
    """Dropdown to switch between the RGB composite view and a single-channel
    grayscale view.

    Emits ``view_changed(channel_idx)`` where channel_idx is None for the
    RGB composite or an int index for single-channel grayscale.
    """

    view_changed = pyqtSignal(object)

    def __init__(self) -> None:
        super().__init__()
        self._combo = QComboBox()
        self._combo.addItem("rgb")
        self._combo.currentIndexChanged.connect(self._on_changed)

        layout = QHBoxLayout()
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(4)
        layout.addWidget(QLabel("View:"))
        layout.addWidget(self._combo)
        self.setLayout(layout)

    def set_channels(self, channel_names: List[str]) -> None:
        """Repopulate the dropdown with channel names, keeping 'rgb' first."""
        self._combo.blockSignals(True)
        self._combo.clear()
        self._combo.addItem("rgb")
        self._combo.addItems(channel_names)
        self._combo.blockSignals(False)
        self._combo.setCurrentIndex(0)

    def select_view(self, combo_idx: int) -> None:
        """Programmatically select a view by combo index (0 = rgb, 1+ = channel)."""
        if 0 <= combo_idx < self._combo.count():
            self._combo.setCurrentIndex(combo_idx)

    def _on_changed(self, idx: int) -> None:
        self.view_changed.emit(None if idx == 0 else idx - 1)


class SortPanel(QWidget):
    """Controls for sorting events by a DataFrame column.

    Provides a column dropdown, ascending/descending radio buttons,
    and an Apply button. Emits ``sort_requested(column, ascending)``
    when Apply is clicked.
    """

    sort_requested = pyqtSignal(str, bool)

    def __init__(self) -> None:
        super().__init__()

        self._col_combo = QComboBox()

        self._asc_btn = QRadioButton("Asc")
        self._desc_btn = QRadioButton("Desc")
        self._asc_btn.setChecked(True)

        apply_btn = QPushButton("Sort")
        apply_btn.pressed.connect(self._on_apply)

        # Row 1: label + column selector
        row1 = QHBoxLayout()
        row1.setContentsMargins(0, 0, 0, 0)
        row1.setSpacing(4)
        row1.addWidget(QLabel("Sort by:"))
        row1.addWidget(self._col_combo)

        # Row 2: direction radios + apply button
        row2 = QHBoxLayout()
        row2.setContentsMargins(0, 0, 0, 0)
        row2.setSpacing(4)
        row2.addWidget(self._asc_btn)
        row2.addWidget(self._desc_btn)
        row2.addWidget(apply_btn)

        layout = QVBoxLayout()
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(4)
        layout.addLayout(row1)
        layout.addLayout(row2)
        self.setLayout(layout)

    def set_columns(self, columns: List[str]) -> None:
        """Populate the column dropdown with DataFrame column names."""
        self._col_combo.clear()
        self._col_combo.addItems(columns)

    def _on_apply(self) -> None:
        col = self._col_combo.currentText()
        if col:
            self.sort_requested.emit(col, self._asc_btn.isChecked())
