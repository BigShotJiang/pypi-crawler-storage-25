"""GUI components for AnnotateEZ."""
