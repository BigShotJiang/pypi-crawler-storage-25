"""Normalized request objects and runtime validation for draw orchestration."""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Literal

from ..diagnostics import DiagnosticSeverity, RenderDiagnostic
from ..exceptions import UnsupportedBackendError
from ..hover import HoverOptions, disable_hover, normalize_hover
from ..renderers._render_support import (
    NON_INTERACTIVE_BACKENDS,
    figure_backend_name,
    pyplot_backend_supports_interaction,
)
from ..style import DrawStyle
from ..topology import (
    TopologyInput,
    TopologyQubitMode,
    TopologyResizeMode,
    normalize_topology_input,
    normalize_topology_qubits,
    normalize_topology_resize,
)
from ..typing import LayoutEngine3DLike, LayoutEngineLike, OutputPath

if TYPE_CHECKING:
    from matplotlib.axes import Axes

ViewMode = Literal["2d", "3d"]
TopologyMode = TopologyInput
_VALID_VIEW_MODES = frozenset({"2d", "3d"})
_VALID_COMPOSITE_MODES = frozenset({"compact", "expand"})


@dataclass(frozen=True, slots=True)
class DrawPipelineOptions:
    """Typed rendering options carried through adapter, layout, and rendering.

    The object keeps the stable public options together and stores any
    additional adapter-specific keyword arguments in ``extra`` so the
    public signature does not need to expose every future extension.
    """

    composite_mode: str = "compact"
    view: ViewMode = "2d"
    topology: TopologyMode = "line"
    topology_qubits: TopologyQubitMode = "used"
    topology_resize: TopologyResizeMode = "error"
    topology_hover: bool = False
    topology_menu: bool = False
    direct: bool = True
    keyboard_shortcuts: bool = True
    double_click_toggle: bool = True
    hover: HoverOptions = field(default_factory=lambda: HoverOptions(enabled=False))
    extra: Mapping[str, object] = field(default_factory=dict)

    def __post_init__(self) -> None:
        object.__setattr__(self, "extra", dict(self.extra))

    def to_mapping(self) -> dict[str, object]:
        """Return the full option set as a plain mapping."""

        return {
            "composite_mode": self.composite_mode,
            "view": self.view,
            "topology": self.topology,
            "topology_qubits": self.topology_qubits,
            "topology_resize": self.topology_resize,
            "topology_hover": self.topology_hover,
            "topology_menu": self.topology_menu,
            "direct": self.direct,
            "keyboard_shortcuts": self.keyboard_shortcuts,
            "double_click_toggle": self.double_click_toggle,
            "hover": self.hover,
            **self.extra,
        }

    def adapter_options(self) -> dict[str, object]:
        """Return only the options that adapters should see.

        View-specific render controls such as ``view`` and ``hover`` are kept
        out of adapter conversion because they affect layout or rendering, not
        framework-to-IR translation.
        """

        options = self.to_mapping()
        for key in (
            "view",
            "topology",
            "topology_qubits",
            "topology_resize",
            "topology_hover",
            "topology_menu",
            "direct",
            "keyboard_shortcuts",
            "double_click_toggle",
            "hover",
        ):
            options.pop(key, None)
        return options


@dataclass(frozen=True, slots=True)
class DrawRequest:
    """High-level draw request after public arguments are normalized."""

    circuit: object
    framework: str | None
    style: DrawStyle | Mapping[str, object] | None
    layout: LayoutEngineLike | LayoutEngine3DLike | None
    backend: str
    ax: Axes | None
    output: OutputPath | None
    show: bool
    figsize: tuple[float, float] | None
    page_slider: bool
    page_window: bool
    pipeline_options: DrawPipelineOptions
    diagnostics: tuple[RenderDiagnostic, ...] = ()


def build_draw_request(
    *,
    circuit: object,
    framework: str | None = None,
    style: DrawStyle | Mapping[str, object] | None = None,
    layout: LayoutEngineLike | LayoutEngine3DLike | None = None,
    backend: str = "matplotlib",
    ax: Axes | None = None,
    output: OutputPath | None = None,
    show: bool = True,
    figsize: tuple[float, float] | None = None,
    page_slider: bool = False,
    page_window: bool = False,
    composite_mode: str = "compact",
    view: ViewMode = "2d",
    topology: TopologyMode = "line",
    topology_qubits: TopologyQubitMode = "used",
    topology_resize: TopologyResizeMode = "error",
    topology_menu: bool = False,
    direct: bool = True,
    keyboard_shortcuts: bool = True,
    double_click_toggle: bool = True,
    hover: bool | HoverOptions | Mapping[str, object] = False,
    **options: object,
) -> DrawRequest:
    """Build the internal draw request without changing the public signature.

    This step resolves effective hover behavior and packages the runtime
    options into typed structures used by later orchestration stages.
    """

    normalized_hover = normalize_hover(hover)
    validate_public_options(
        view=view,
        topology=topology,
        topology_qubits=topology_qubits,
        topology_resize=topology_resize,
        composite_mode=composite_mode,
        direct=direct,
        show=show,
        page_slider=page_slider,
        page_window=page_window,
        topology_menu=topology_menu,
        figsize=figsize,
        keyboard_shortcuts=keyboard_shortcuts,
        double_click_toggle=double_click_toggle,
    )
    resolved_hover, diagnostics = resolve_effective_hover(
        hover=normalized_hover,
        ax=ax,
        output=output,
        show=show,
        view=view,
    )
    resolved_options = _resolved_adapter_extra_options(options, resolved_hover)
    return DrawRequest(
        circuit=circuit,
        framework=framework,
        style=style,
        layout=layout,
        backend=backend,
        ax=ax,
        output=output,
        show=show,
        figsize=figsize,
        page_slider=page_slider,
        page_window=page_window,
        pipeline_options=DrawPipelineOptions(
            composite_mode=composite_mode,
            view=view,
            topology=normalize_topology_input(topology),
            topology_qubits=normalize_topology_qubits(topology_qubits),
            topology_resize=normalize_topology_resize(topology_resize),
            topology_hover=_should_enable_2d_topology_hover(
                view=view,
                topology=topology,
                topology_qubits=topology_qubits,
                topology_resize=topology_resize,
            ),
            topology_menu=topology_menu,
            direct=direct,
            keyboard_shortcuts=keyboard_shortcuts,
            double_click_toggle=double_click_toggle,
            hover=resolved_hover,
            extra=resolved_options,
        ),
        diagnostics=diagnostics,
    )


def validate_public_options(
    *,
    view: object,
    topology: object,
    topology_qubits: object,
    topology_resize: object,
    composite_mode: object,
    direct: object,
    show: object,
    page_slider: object,
    page_window: object,
    topology_menu: object,
    figsize: object,
    keyboard_shortcuts: object,
    double_click_toggle: object,
) -> None:
    """Validate public draw options that are not enforced by Python typing."""

    _validate_choice("view", view, _VALID_VIEW_MODES)
    normalize_topology_input(topology)
    normalize_topology_qubits(topology_qubits)
    normalize_topology_resize(topology_resize)
    _validate_choice("composite_mode", composite_mode, _VALID_COMPOSITE_MODES)
    _validate_bool("direct", direct)
    _validate_bool("show", show)
    _validate_bool("page_slider", page_slider)
    _validate_bool("page_window", page_window)
    _validate_bool("topology_menu", topology_menu)
    _validate_bool("keyboard_shortcuts", keyboard_shortcuts)
    _validate_bool("double_click_toggle", double_click_toggle)
    _validate_figsize(figsize)


def _validate_choice(name: str, value: object, allowed_values: frozenset[str]) -> None:
    if isinstance(value, str) and value in allowed_values:
        return
    choices = ", ".join(sorted(allowed_values))
    raise ValueError(f"{name} must be one of: {choices}")


def _validate_bool(name: str, value: object) -> None:
    if isinstance(value, bool):
        return
    raise ValueError(f"{name} must be a boolean")


def _validate_figsize(value: object) -> None:
    if value is None:
        return
    if not isinstance(value, tuple | list) or len(value) != 2:
        raise ValueError("figsize must be a 2-item tuple of positive numbers")
    width, height = value
    if not _is_positive_dimension(width) or not _is_positive_dimension(height):
        raise ValueError("figsize must be a 2-item tuple of positive numbers")


def _is_positive_dimension(value: object) -> bool:
    return isinstance(value, int | float) and not isinstance(value, bool) and float(value) > 0.0


def validate_draw_request(request: DrawRequest) -> None:
    """Validate public runtime combinations before preparing the pipeline."""

    if request.backend != "matplotlib":
        raise UnsupportedBackendError(f"unsupported backend '{request.backend}'")
    if request.ax is not None and request.page_slider:
        raise ValueError(
            "page_slider=True requires a Matplotlib-managed figure and cannot be used with ax"
        )
    if request.ax is not None and request.page_window:
        raise ValueError(
            "page_window=True requires a Matplotlib-managed figure and cannot be used with ax"
        )
    if request.ax is not None and request.figsize is not None:
        raise ValueError(
            "figsize cannot be used with ax because the caller already owns the figure"
        )
    if request.page_slider and request.page_window:
        raise ValueError("page_slider=True cannot be combined with page_window=True")
    if request.page_window and request.pipeline_options.view != "2d":
        raise ValueError("page_window=True is only supported for view='2d'")
    if request.pipeline_options.view != "3d" and request.pipeline_options.topology_menu:
        raise ValueError("topology_menu=True is only supported for view='3d'")


def resolve_effective_hover(
    *,
    hover: HoverOptions,
    ax: Axes | None,
    output: OutputPath | None,
    show: bool,
    view: ViewMode,
) -> tuple[HoverOptions, tuple[RenderDiagnostic, ...]]:
    """Resolve whether hover annotations can actually stay interactive.

    Hover labels are disabled for saved output and non-interactive backends.
    Managed hidden 2D renders also disable hover because there is no
    visible interaction to preserve and the hover payloads are expensive
    to build for dense circuits.
    """

    diagnostics: list[RenderDiagnostic] = []
    if not hover.enabled or output is not None:
        return disable_hover(hover), ()
    if ax is not None:
        if figure_backend_name(ax.figure) in NON_INTERACTIVE_BACKENDS:
            return disable_hover(hover), ()
        return hover, ()
    if view == "2d" and not show:
        diagnostics.append(
            RenderDiagnostic(
                code="hover_disabled_hidden_2d",
                message="Disabled hover because hidden managed 2D renders are non-interactive.",
                severity=DiagnosticSeverity.INFO,
            )
        )
        return disable_hover(hover), tuple(diagnostics)
    if not pyplot_backend_supports_interaction():
        return disable_hover(hover), ()
    return hover, ()


def _resolved_adapter_extra_options(
    options: Mapping[str, object],
    effective_hover: HoverOptions,
) -> dict[str, object]:
    """Return adapter options after applying hover-related defaults."""

    resolved_options = dict(options)
    if not effective_hover.enabled and resolved_options.get("explicit_matrices") is not True:
        resolved_options["explicit_matrices"] = False
    return resolved_options


def _should_enable_2d_topology_hover(
    *,
    view: ViewMode,
    topology: TopologyMode,
    topology_qubits: TopologyQubitMode,
    topology_resize: TopologyResizeMode,
) -> bool:
    if view != "2d":
        return False
    return topology != "line" or topology_qubits != "used" or topology_resize != "error"


__all__ = [
    "DiagnosticSeverity",
    "DrawPipelineOptions",
    "DrawRequest",
    "DrawStyle",
    "HoverOptions",
    "LayoutEngine3DLike",
    "LayoutEngineLike",
    "Literal",
    "Mapping",
    "NON_INTERACTIVE_BACKENDS",
    "OutputPath",
    "RenderDiagnostic",
    "TYPE_CHECKING",
    "TopologyInput",
    "TopologyMode",
    "TopologyQubitMode",
    "TopologyResizeMode",
    "UnsupportedBackendError",
    "ViewMode",
    "_VALID_COMPOSITE_MODES",
    "_VALID_VIEW_MODES",
    "_is_positive_dimension",
    "_resolved_adapter_extra_options",
    "_validate_bool",
    "_validate_choice",
    "_validate_figsize",
    "annotations",
    "build_draw_request",
    "dataclass",
    "disable_hover",
    "field",
    "figure_backend_name",
    "normalize_hover",
    "normalize_topology_input",
    "normalize_topology_qubits",
    "normalize_topology_resize",
    "pyplot_backend_supports_interaction",
    "resolve_effective_hover",
    "validate_draw_request",
    "validate_public_options",
]
