import better_auth.bottle


def test_import():
    assert better_auth.bottle.__name__ == "better_auth.bottle"
