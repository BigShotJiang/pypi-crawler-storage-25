"""Bottle integration namespace."""
