.. include:: introduction.rst

.. include:: examples.rst

.. include:: motivation.rst

.. include:: model.rst

Full API documentation
======================

.. automodule:: convoys.plotting
   :members:

.. automodule:: convoys.regression
   :members:
   :inherited-members:

.. automodule:: convoys.single
   :members:

.. automodule:: convoys.multi
   :members:
   :inherited-members:

.. automodule:: convoys.utils
   :members:

.. include:: afterwords.rst
