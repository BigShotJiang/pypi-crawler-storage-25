# curerate

**curerate** is a Python library for fitting cure rate models — statistical models 
for time-lagged conversions where some fraction of the population will never convert.

It is a modernised fork of [convoys](https://github.com/better/convoys) by Erik Bernhardsson.

## Installation
```bash
pip install curerate
```

## What it does

Cure rate models handle the case where:
- Conversions happen at varying time delays after exposure
- Some fraction of the population will **never** convert

This is common in SaaS free-to-paid conversion, ecommerce, and anywhere 
time-lagged outcomes matter.

## License

MIT