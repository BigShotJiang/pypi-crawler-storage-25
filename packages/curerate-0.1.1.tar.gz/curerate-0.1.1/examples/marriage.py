from matplotlib import pyplot
import pandas
import curerate.plotting
import curerate.utils


def run():
    print('loading data')
    df = pandas.read_pickle('examples/marriage.pickle')
    df = df.sample(1000)  # speed up
    print(df)

    _, groups, (G, B, T) = curerate.utils.get_arrays(
        df, groups='sex', created='born', converted='married')

    pyplot.figure(figsize=(6, 6))
    curerate.plotting.plot_cohorts(G, B, T, model='generalized-gamma',
                                  groups=groups)
    pyplot.legend()
    pyplot.xlabel('Age of marriage')
    curerate.plotting.plot_cohorts(G, B, T, model='kaplan-meier',
                                  groups=groups,
                                  plot_kwargs={'linestyle': '--'})
    pyplot.savefig('marriage-combined.png')


if __name__ == '__main__':
    run()
