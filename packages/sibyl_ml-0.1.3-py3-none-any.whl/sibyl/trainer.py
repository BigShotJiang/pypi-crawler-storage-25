"""
训练器
"""
import os
import csv
import json
import time
import logging
import threading
from typing import Optional
from .tasks.base import BaseTask
from .callbacks.base import BaseCallback
from .callbacks.factory import get_callback

logger = logging.getLogger(__name__)


def _start_gpu_peak_tracker(device_index: int, pid: int, interval: float = 0.5):
    """启动后台线程追踪整个 run 的 GPU 显存峰值，返回 (stop_fn, get_peak_fn)。

    策略：
    1. pynvml per-process（Linux / bare-metal）：精确匹配 nvidia-smi。
    2. WSL2 / WDDM 下 usedGpuMemory=None：用设备总用量减去基线作为本进程近似值。
    3. 完全 fallback：采样 torch.cuda.memory_reserved()（含 PyTorch 缓存池）。
    """
    import torch as _torch
    peak_mb = [0.0]
    running = [True]

    def _sample():
        pynvml = None
        handle = None
        baseline_other_mb = None
        try:
            import pynvml as _pynvml
            pynvml = _pynvml
            pynvml.nvmlInit()
            handle = pynvml.nvmlDeviceGetHandleByIndex(device_index)
        except Exception:
            pynvml = None

        while running[0]:
            try:
                mb = 0.0
                if pynvml is not None and handle is not None:
                    procs = pynvml.nvmlDeviceGetComputeRunningProcesses(handle)
                    per_proc = next(
                        (p.usedGpuMemory for p in procs if p.pid == pid and p.usedGpuMemory is not None),
                        None
                    )
                    if per_proc is not None:
                        mb = per_proc / (1024 ** 2)
                    else:
                        info = pynvml.nvmlDeviceGetMemoryInfo(handle)
                        total_used = info.used / (1024 ** 2)
                        if baseline_other_mb is None:
                            torch_reserved = _torch.cuda.memory_reserved() / (1024 ** 2) if _torch.cuda.is_available() else 0.0
                            baseline_other_mb = max(0.0, total_used - torch_reserved)
                        mb = max(0.0, total_used - baseline_other_mb)

                if mb == 0.0 and _torch.cuda.is_available():
                    mb = _torch.cuda.memory_reserved() / (1024 ** 2)

                if mb > peak_mb[0]:
                    peak_mb[0] = mb
            except Exception:
                pass
            time.sleep(interval)

        if pynvml is not None:
            try:
                pynvml.nvmlShutdown()
            except Exception:
                pass

    t = threading.Thread(target=_sample, daemon=True)
    t.start()

    def stop():
        running[0] = False
        t.join(timeout=2.0)

    def get_peak():
        return peak_mb[0]

    return stop, get_peak


class Trainer:
    """简化版训练器，封装训练循环"""

    def __init__(self, task: BaseTask, config):
        """
        Args:
            task: 任务实例
            config: 配置字典
        """
        self.task = task
        self.config = config
        self.callbacks = []

        # 初始化回调
        if 'callbacks' in config:
            for cb_name in config.callbacks:
                try:
                    self.callbacks.append(get_callback(cb_name, self.task, config))
                except Exception as e:
                    logger.warning(f"Failed to load callback '{cb_name}': {e}")

        self.best_val_loss = float('inf')
        self._stop_gpu_tracker = None
        self._get_gpu_peak = lambda: 0.0

    def fit(self, train_loader, val_loader, epochs: int, start_epoch: int = 0):
        """训练循环"""
        logger.info(f"\nStarting training for {epochs} epochs (from epoch {start_epoch + 1})...")

        # 重置 CUDA 峰值统计
        import torch as _torch
        if _torch.cuda.is_available():
            try:
                _torch.cuda.reset_peak_memory_stats()
            except Exception:
                pass

        # 启动 pynvml 后台采样线程追踪整个 run（训练+推理+分析回调）的显存峰值，
        # 结果等同 nvidia-smi 观测值
        self._stop_gpu_tracker = None
        self._get_gpu_peak = lambda: 0.0
        if _torch.cuda.is_available():
            try:
                stop_fn, peak_fn = _start_gpu_peak_tracker(
                    _torch.cuda.current_device(), os.getpid()
                )
                self._stop_gpu_tracker = stop_fn
                self._get_gpu_peak = peak_fn
            except Exception:
                pass

        # 保存训练状态
        self._save_training_state(epochs, start_epoch, completed=False)

        # 训练前回调
        self._on_train_begin()

        epoch = max(start_epoch - 1, 0)
        epoch_times = []
        batch_times = []  # 每个 epoch 的平均 batch 时间（秒）
        total_batches = 0
        train_start_time = time.time()

        for epoch in range(start_epoch, epochs):
            epoch_start = time.time()
            self.task.current_epoch = epoch

            # 训练（返回 loss + 平均 batch 时间 + 可选 PINN 分项损失）
            train_result = self.task.train_epoch(train_loader)
            loss_details = {}
            if isinstance(train_result, tuple):
                if len(train_result) >= 4:
                    train_loss, avg_batch_time, n_batches, loss_details = train_result[:4]
                elif len(train_result) == 3:
                    train_loss, avg_batch_time, n_batches = train_result
                else:
                    # 兼容旧接口 (loss, batch_time)
                    train_loss, avg_batch_time = train_result[:2]
                    n_batches = 0
            else:
                train_loss = train_result
                avg_batch_time, n_batches = 0.0, 0
            batch_times.append(avg_batch_time)
            total_batches += n_batches

            # 验证
            val_metrics = self.task.validate(val_loader)
            val_loss = val_metrics['val_loss']

            # 计时
            epoch_time = time.time() - epoch_start
            epoch_times.append(epoch_time)
            avg_epoch_time = sum(epoch_times) / len(epoch_times)
            remaining_epochs = epochs - epoch - 1
            eta_seconds = avg_epoch_time * remaining_epochs
            elapsed = time.time() - train_start_time

            # 学习率调度
            self.task.step_scheduler(val_loss)

            # Epoch 结束时先写入时间信息，再记录训练日志/回调
            val_metrics['epoch_time'] = epoch_time
            val_metrics['avg_batch_time'] = avg_batch_time
            val_metrics['eta_seconds'] = eta_seconds
            val_metrics['elapsed'] = elapsed
            # PINN 分项损失 (论文 §4.4 Per-Term Loss Logging)
            if loss_details:
                val_metrics['loss_details'] = loss_details

            # 记录训练日志
            self._log_epoch(epoch, train_loss, val_metrics)

            # Epoch 结束回调
            self._on_epoch_end(epoch, train_loss, val_metrics)

            # 从 ModelCheckpoint 回调同步最佳验证损失（回调缺失时用 val_metrics 兜底）
            self.best_val_loss = self._get_best_val_loss(val_metrics.get('val_loss'))

            # 更新训练状态
            self._save_training_state(epochs, epoch + 1, completed=False)

            # 早停检查
            if self._check_early_stopping():
                logger.info(f"Early stopping at epoch {epoch}")
                break

        # 标记训练完成（但 COMPLETED 文件留给 test() 写入，避免训练完但测试崩溃时误报完成）
        total_time = time.time() - train_start_time
        self._save_training_state(epochs, epoch + 1, completed=True)

        # 保存训练时间统计，供 test() 注入 leaderboard 指标
        self._total_train_time = total_time
        self._avg_epoch_time = sum(epoch_times) / max(len(epoch_times), 1)
        self._avg_batch_time = sum(batch_times) / max(len(batch_times), 1)
        self._total_batches = total_batches

        # 训练结束回调
        self._on_train_end()
        logger.info(f"\nTraining completed! Total time: {self._format_time(total_time)}")

    def test(self, test_loader):
        """测试"""
        logger.info("\nRunning test...")

        # 测试前回调
        self._on_test_begin()

        # 运行测试
        result = self.task.test(test_loader)

        # 注入训练元信息，供 callbacks 使用
        result['best_val_loss'] = self.best_val_loss if self.best_val_loss != float('inf') else None
        result['train_epochs'] = self.task.current_epoch + 1

        # 注入训练时间统计到 metrics（写入 leaderboard）
        # retest / mode=test 时本 session 未调用 fit()，从 training_state.json 和 training_log.csv
        # 继承之前训练的统计数据，避免 leaderboard 写入全 0/空值
        has_trained_this_session = hasattr(self, '_total_batches')
        if not has_trained_this_session:
            self._load_training_stats_from_files()

        metrics_dict = result.setdefault('metrics', {})
        metrics_dict['Total_Train_Time'] = getattr(self, '_total_train_time', 0.0)
        metrics_dict['Avg_Epoch_Time'] = getattr(self, '_avg_epoch_time', 0.0)
        metrics_dict['Avg_Batch_Time'] = getattr(self, '_avg_batch_time', 0.0)
        metrics_dict['Total_Batches'] = getattr(self, '_total_batches', 0)

        # 同样在 retest 时修正 train_epochs / best_val_loss（优先用继承值）
        if not has_trained_this_session:
            inherited_epochs = getattr(self, '_inherited_epochs', None)
            if inherited_epochs is not None:
                result['train_epochs'] = inherited_epochs
            inherited_best = getattr(self, '_inherited_best_val_loss', None)
            if inherited_best is not None:
                result['best_val_loss'] = inherited_best

        # 释放训练阶段 GPU 缓存，让后续分析回调（feature_importance 等）有足够空间
        import torch as _torch
        if _torch.cuda.is_available():
            try:
                _torch.cuda.empty_cache()
            except Exception:
                pass

        # 测试结束回调（SHAP 等分析回调在此阶段运行）
        self._on_test_end(result)

        # 停止 pynvml 采样，取出全过程峰值（训练+推理+SHAP 等）写回 result
        if self._stop_gpu_tracker is not None:
            try:
                self._stop_gpu_tracker()
                peak_mb = self._get_gpu_peak()
                if peak_mb > 0:
                    result['metrics']['GPU_Memory'] = peak_mb
                    result['metrics']['GPU_Memory_Peak'] = peak_mb
            except Exception:
                pass

        logger.info("\nTest completed!")

        # 完整跑完 training + test（或 retest）后才写 COMPLETED，避免 test 崩溃时留下误报
        self._mark_completed()

        return result

    def _load_training_stats_from_files(self):
        """retest 模式下从 training_state.json 和 training_log.csv 继承训练统计。

        不触及 self._total_batches / _total_train_time / _avg_epoch_time / _avg_batch_time 的
        getattr 默认值逻辑（0/0.0），只在能读到数据时设置真实值。
        """
        # training_state.json：total_epochs/current_epoch/best_val_loss
        state_path = 'training_state.json'
        if os.path.exists(state_path):
            try:
                with open(state_path, 'r') as f:
                    state = json.load(f)
                epochs = state.get('current_epoch')
                if epochs:
                    self._inherited_epochs = epochs
                bvl = state.get('best_val_loss')
                if bvl is not None and bvl != float('inf'):
                    self._inherited_best_val_loss = bvl
            except Exception:
                pass

        # training_log.csv：每 epoch 的 epoch_time / avg_batch_time
        log_path = 'training_log.csv'
        if os.path.exists(log_path):
            try:
                epoch_times = []
                batch_times = []
                with open(log_path, 'r') as f:
                    reader = csv.DictReader(f)
                    for row in reader:
                        try:
                            epoch_times.append(float(row.get('epoch_time', 0) or 0))
                            batch_times.append(float(row.get('avg_batch_time', 0) or 0))
                        except (ValueError, TypeError):
                            pass
                if epoch_times:
                    self._total_train_time = sum(epoch_times)
                    self._avg_epoch_time = sum(epoch_times) / len(epoch_times)
                if batch_times:
                    self._avg_batch_time = sum(batch_times) / len(batch_times)
                # Total_Batches 无法从 training_log.csv 精确恢复（只有 avg_batch_time），
                # 用 epoch 数 × 平均 batch 数 估算不准确——留空由 leaderboard 写 ''
            except Exception:
                pass

    def _log_epoch(self, epoch, train_loss, val_metrics):
        """记录每个 epoch 的训练日志到 CSV"""
        log_path = 'training_log.csv'
        file_exists = os.path.exists(log_path)

        # PINN 分项损失的列名（首 epoch 决定顺序，后续保持一致）
        loss_details = val_metrics.get('loss_details', {}) or {}
        if not hasattr(self, '_pinn_detail_keys'):
            # 按字母排序以保证跨 run 稳定；排除 'total_loss' 因已等于 train_loss
            self._pinn_detail_keys = sorted(k for k in loss_details.keys() if k != 'total_loss')

        base_header = ['epoch', 'train_loss', 'val_loss', 'best_val_loss', 'lr',
                       'epoch_time', 'avg_batch_time']
        full_header = base_header + [f'loss_{k}' for k in self._pinn_detail_keys]

        with open(log_path, 'a', newline='') as f:
            writer = csv.writer(f)
            if not file_exists:
                writer.writerow(full_header)
            lr = self.task.optimizer.param_groups[0]['lr']
            epoch_time = val_metrics.get('epoch_time', 0)
            avg_batch_time = val_metrics.get('avg_batch_time', 0)
            base_row = [
                epoch + 1,
                f'{train_loss:.6f}',
                f'{val_metrics["val_loss"]:.6f}',
                f'{self.best_val_loss:.6f}',
                f'{lr:.6f}',
                f'{epoch_time:.3f}',
                f'{avg_batch_time:.4f}',
            ]
            detail_row = [f'{loss_details.get(k, 0.0):.6f}' for k in self._pinn_detail_keys]
            writer.writerow(base_row + detail_row)

    def _save_training_state(self, total_epochs, current_epoch, completed):
        """保存训练状态，用于断点续训检测"""
        state = {
            'total_epochs': total_epochs,
            'current_epoch': current_epoch,
            'completed': completed,
            'best_val_loss': self.best_val_loss if self.best_val_loss != float('inf') else None
        }
        with open('training_state.json', 'w') as f:
            json.dump(state, f, indent=2)

    def _mark_completed(self):
        """标记训练完成"""
        with open('COMPLETED', 'w') as f:
            f.write('done\n')

    def _get_best_val_loss(self, current_val_loss: float = None) -> float:
        """
        从 ModelCheckpoint 回调读取最佳验证损失。
        回调缺失时，使用传入的 current_val_loss 与现有 best 取 min 作为 fallback，
        保证在无 ModelCheckpoint 的最小配置下也能追踪最小 val_loss。
        """
        for callback in self.callbacks:
            if hasattr(callback, 'best_val_loss'):
                return callback.best_val_loss
        if current_val_loss is not None:
            return min(self.best_val_loss, float(current_val_loss))
        return self.best_val_loss

    def _check_early_stopping(self) -> bool:
        """检查早停"""
        for callback in self.callbacks:
            if hasattr(callback, 'should_stop') and callback.should_stop():
                return True
        return False

    def _on_train_begin(self):
        """训练前回调"""
        for callback in self.callbacks:
            callback.on_train_begin()

    @staticmethod
    def _format_time(seconds):
        """格式化秒数为可读字符串"""
        if seconds < 60:
            return f"{seconds:.1f}s"
        elif seconds < 3600:
            m, s = divmod(seconds, 60)
            return f"{int(m)}m{int(s)}s"
        else:
            h, rem = divmod(seconds, 3600)
            m, s = divmod(rem, 60)
            return f"{int(h)}h{int(m)}m{int(s)}s"

    def _on_epoch_end(self, epoch, train_loss, val_metrics):
        """Epoch 结束回调"""
        epoch_time = val_metrics.get('epoch_time', 0)
        eta = val_metrics.get('eta_seconds', 0)
        elapsed = val_metrics.get('elapsed', 0)

        time_info = f"  Time: {self._format_time(epoch_time)}/epoch"
        if eta > 0:
            time_info += f" | ETA: {self._format_time(eta)} | Elapsed: {self._format_time(elapsed)}"

        logger.info(f"\nEpoch {epoch + 1}:")
        logger.info(f"  Train Loss: {train_loss:.6f}")
        logger.info(f"  Val Loss: {val_metrics['val_loss']:.6f}")
        logger.info(time_info)

        for callback in self.callbacks:
            callback.on_epoch_end(epoch, train_loss, val_metrics)

    def _on_train_end(self):
        """训练结束回调"""
        for callback in self.callbacks:
            callback.on_train_end()

    def _on_test_begin(self):
        """测试前回调"""
        for callback in self.callbacks:
            callback.on_test_begin()

    def _on_test_end(self, result):
        """测试结束回调"""
        metrics = result['metrics']

        logger.info("\nTest Metrics:")
        for name, value in metrics.items():
            if isinstance(value, float):
                logger.info(f"  {name}: {value:.4f}")
            else:
                logger.info(f"  {name}: {value}")

        for callback in self.callbacks:
            # 在每个回调运行前刷新 GPU_Memory（从 pynvml 后台采样线程取当前峰值），
            # 使 leaderboard（作为最后一个回调）能拿到 SHAP 完成后的真实峰值
            if self._get_gpu_peak is not None:
                try:
                    peak_mb = self._get_gpu_peak()
                    if peak_mb > 0:
                        result['metrics']['GPU_Memory'] = peak_mb
                        result['metrics']['GPU_Memory_Peak'] = peak_mb
                except Exception:
                    pass
            callback.on_test_end(result)
