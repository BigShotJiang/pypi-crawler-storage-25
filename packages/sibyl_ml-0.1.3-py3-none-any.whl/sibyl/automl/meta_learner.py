"""
Meta-Learner - 从历史实验结果中学习模型选择
"""
import os
import logging
import numpy as np
import pandas as pd
from typing import List, Optional
from .data_profile import DataProfile

logger = logging.getLogger(__name__)


class MetaLearner:
    """从历史实验结果学习最佳模型选择"""

    def __init__(self, leaderboard_path: str = 'reports/forecast/leaderboard.csv'):
        self.leaderboard_path = leaderboard_path
        self.model = None
        self.is_trained = False

    def extract_meta_features(self, profile: DataProfile) -> np.ndarray:
        """将 DataProfile 转为固定长度特征向量"""
        features = [
            profile.n_samples,
            profile.n_features,
            profile.complexity_score,
            profile.anomaly_ratio,
            profile.missing_pattern.get('total_ratio', 0),
            profile.correlations.get('mean_abs_corr', 0),
            1.0 if profile.periodicity.get('has_periodicity', False) else 0.0,
            profile.periodicity.get('strength', 0),
            profile.periodicity.get('dominant_period', 0),
            profile.recommended_seq_len,
            profile.recommended_pred_len,
        ]

        # Trend statistics
        if profile.trend:
            magnitudes = [v.get('magnitude', 0) for v in profile.trend.values() if isinstance(v, dict)]
            features.append(np.mean(magnitudes) if magnitudes else 0)
            features.append(np.max(magnitudes) if magnitudes else 0)
            n_trending = sum(1 for v in profile.trend.values() if isinstance(v, dict) and v.get('type', 'none') != 'none')
            features.append(n_trending / max(len(profile.trend), 1))
        else:
            features.extend([0, 0, 0])

        # Stationarity ratio
        if profile.stationarity:
            n_stat = sum(1 for v in profile.stationarity.values() if isinstance(v, dict) and v.get('is_stationary', False))
            features.append(n_stat / max(len(profile.stationarity), 1))
        else:
            features.append(0)

        # Correlation level encoding
        corr_level = profile.correlations.get('correlation_level', 'medium')
        features.append({'low': 0, 'medium': 0.5, 'high': 1.0}.get(corr_level, 0.5))

        return np.array(features, dtype=np.float32)

    def load_history(self) -> Optional[pd.DataFrame]:
        """加载历史实验结果"""
        if not os.path.exists(self.leaderboard_path):
            logger.warning(f"Leaderboard not found: {self.leaderboard_path}")
            return None

        try:
            df = pd.read_csv(self.leaderboard_path)
            if len(df) < 10:
                logger.info(f"Not enough history ({len(df)} runs, need 10+)")
                return None
            return df
        except Exception as e:
            logger.warning(f"Failed to load leaderboard: {e}")
            return None

    def train(self, profiles: List[DataProfile], results: List[dict]):
        """
        训练 meta-model
        Args:
            profiles: 每个数据集的 DataProfile 列表
            results: 每个数据集上各模型的测试结果
        """
        try:
            from sklearn.ensemble import RandomForestClassifier
        except ImportError:
            logger.warning("sklearn not available, meta-learner disabled")
            return

        if len(profiles) < 5:
            logger.info("Not enough training data for meta-learner")
            return

        X = np.array([self.extract_meta_features(p) for p in profiles])
        # y = best model index for each dataset
        y = np.array([r.get('best_model_idx', 0) for r in results])

        self.model = RandomForestClassifier(n_estimators=50, random_state=42)
        self.model.fit(X, y)
        self.is_trained = True
        logger.info(f"Meta-learner trained on {len(profiles)} datasets")

    def predict(self, profile: DataProfile, model_names: List[str]) -> List[tuple]:
        """
        预测最佳模型
        Returns: [(model_name, probability), ...] sorted by probability descending
        """
        if not self.is_trained or self.model is None:
            logger.info("Meta-learner not trained, returning empty predictions")
            return []

        X = self.extract_meta_features(profile).reshape(1, -1)
        probs = self.model.predict_proba(X)[0]

        # sklearn predict_proba 列顺序为 self.model.classes_ 排序后的子集，
        # 直接用 enumerate idx 会和 model_names 错配；必须通过 classes_ 反查
        results = []
        for cls_label, prob in zip(self.model.classes_, probs):
            cls_idx = int(cls_label)
            if 0 <= cls_idx < len(model_names):
                results.append((model_names[cls_idx], float(prob)))

        results.sort(key=lambda x: x[1], reverse=True)
        return results
