"""
自适应集成预测 - 不同预测步长使用不同模型权重
"""
import torch
import numpy as np
import logging
from typing import List, Dict, Tuple

logger = logging.getLogger(__name__)


class AdaptiveEnsemble:
    """
    Per-horizon 自适应加权集成。
    每个预测步长可以有不同的模型权重。
    """

    def __init__(self, method: str = 'per_horizon'):
        self.method = method
        self.models = []
        self.weights = None
        self.model_names = []

    def add_model(self, name: str, task, val_loss: float):
        """添加已训练的模型"""
        self.models.append((name, task, val_loss))
        self.model_names.append(name)
        logger.info(f"Ensemble: added {name} (val_loss={val_loss:.4f})")

    def fit_weights(self, val_loader) -> None:
        """从验证集学习集成权重"""
        if len(self.models) < 2:
            self.weights = np.array([1.0])
            return

        if self.method == 'val_loss':
            self._fit_val_loss_weights()
        elif self.method == 'per_horizon':
            self._fit_per_horizon_weights(val_loader)
        elif self.method == 'stacking':
            self._fit_stacking_weights(val_loader)
        else:
            self._fit_val_loss_weights()

        logger.info(f"Ensemble weights fitted ({self.method})")

    def _fit_val_loss_weights(self):
        """基于验证损失的全局权重"""
        losses = np.array([m[2] for m in self.models])
        inv_losses = 1.0 / (losses + 1e-8)
        self.weights = inv_losses / inv_losses.sum()

        for name, w in zip(self.model_names, self.weights):
            logger.info(f"  {name}: weight={w:.4f}")

    def _fit_per_horizon_weights(self, val_loader):
        """每个预测步长独立计算权重"""
        all_mae = []

        for name, task, _ in self.models:
            task.model.eval()
            step_errors = []

            with torch.no_grad():
                for batch in val_loader:
                    if isinstance(batch, (tuple, list)):
                        x, y = batch[0].to(task.device), batch[1].to(task.device)
                    else:
                        x = batch.to(task.device)
                        pred_len = task.config.get('pred_len', 24)
                        y = x[:, -pred_len:, :]

                    outputs = task._forward(x)
                    # 对齐时间维：ForecastTask._forward 已把 outputs 截到 pred_len；
                    # 若 y 更长（如用户传入更大窗口），按 outputs 长度截取
                    t = min(outputs.shape[1], y.shape[1])
                    mae = torch.abs(outputs[:, :t] - y[:, :t]).mean(dim=(0, 2))
                    step_errors.append(mae.cpu())

            avg_mae = torch.stack(step_errors).mean(dim=0).numpy()
            all_mae.append(avg_mae)

        all_mae = np.array(all_mae)
        pred_len = all_mae.shape[1]

        self.weights = np.zeros((len(self.models), pred_len))
        for t in range(pred_len):
            inv_mae = 1.0 / (all_mae[:, t] + 1e-8)
            self.weights[:, t] = inv_mae / inv_mae.sum()

        dominant = np.argmax(self.weights, axis=0)
        for i, name in enumerate(self.model_names):
            steps = np.where(dominant == i)[0]
            if len(steps) > 0:
                logger.info(f"  {name}: dominates steps {steps[0]+1}-{steps[-1]+1}")

    def _fit_stacking_weights(self, val_loader):
        """学习型 stacking 集成"""
        all_preds = []
        all_targets = None

        for name, task, _ in self.models:
            task.model.eval()
            preds = []
            targets = []

            with torch.no_grad():
                for batch in val_loader:
                    if isinstance(batch, (tuple, list)):
                        x, y = batch[0].to(task.device), batch[1].to(task.device)
                    else:
                        x = batch.to(task.device)
                        pred_len = task.config.get('pred_len', 24)
                        y = x[:, -pred_len:, :]

                    outputs = task._forward(x)
                    preds.append(outputs.cpu())
                    targets.append(y.cpu())

            all_preds.append(torch.cat(preds, dim=0))
            if all_targets is None:
                all_targets = torch.cat(targets, dim=0)

        target_flat = all_targets.reshape(all_targets.shape[0], -1).numpy()
        pred_means = np.array([p.mean(dim=(1, 2)).numpy() for p in all_preds]).T
        target_mean = target_flat.mean(axis=1)
        weights, _, _, _ = np.linalg.lstsq(pred_means, target_mean, rcond=None)
        weights = np.maximum(weights, 0)
        self.weights = weights / (weights.sum() + 1e-8)

        for name, w in zip(self.model_names, self.weights):
            logger.info(f"  {name}: stacking weight={w:.4f}")

    def predict(self, test_loader) -> Tuple[np.ndarray, np.ndarray]:
        """生成集成预测"""
        all_preds = []
        all_targets = None

        for name, task, _ in self.models:
            task.model.eval()
            preds = []
            targets = []

            with torch.no_grad():
                for batch in test_loader:
                    if isinstance(batch, (tuple, list)):
                        x = batch[0].to(task.device)
                        y_raw = batch[1].to(task.device)
                        x_mark = batch[2].to(task.device) if len(batch) > 2 and batch[2].shape[-1] > 0 else None
                        y_mark = batch[3].to(task.device) if len(batch) > 3 and batch[3].shape[-1] > 0 else None
                    else:
                        x = batch.to(task.device)
                        y_raw = x
                        x_mark = y_mark = None

                    outputs = task._forward(x, x_mark, y_mark)
                    pred_len = task.config.get('pred_len', outputs.shape[1])
                    # y_raw 可能是 label_len+pred_len，取最后 pred_len 步
                    y = y_raw[:, -pred_len:, :]
                    preds.append(outputs.cpu().numpy())
                    targets.append(y.cpu().numpy())

            all_preds.append(np.concatenate(preds, axis=0))
            if all_targets is None:
                all_targets = np.concatenate(targets, axis=0)

        all_preds = np.array(all_preds)

        if self.weights is None:
            self._fit_val_loss_weights()

        if self.weights.ndim == 1:
            w = self.weights[:, np.newaxis, np.newaxis, np.newaxis]
            ensemble = (w * all_preds).sum(axis=0)
        elif self.weights.ndim == 2:
            w = self.weights[:, np.newaxis, :, np.newaxis]
            ensemble = (w * all_preds).sum(axis=0)
        else:
            ensemble = all_preds.mean(axis=0)

        return ensemble, all_targets

    def get_weights_summary(self) -> Dict:
        """获取权重摘要"""
        if self.weights is None:
            return {}

        result = {'method': self.method, 'models': self.model_names}

        if self.weights.ndim == 1:
            result['weights'] = {name: float(w) for name, w in zip(self.model_names, self.weights)}
        else:
            dominant = np.argmax(self.weights, axis=0)
            result['per_horizon_dominant'] = {}
            for i, name in enumerate(self.model_names):
                steps = np.where(dominant == i)[0]
                if len(steps) > 0:
                    result['per_horizon_dominant'][name] = f"steps {steps[0]+1}-{steps[-1]+1}"

        return result
