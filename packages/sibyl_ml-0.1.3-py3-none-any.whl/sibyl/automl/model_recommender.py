"""
模型推荐引擎 - 配置驱动（YAML 规则）。

设计原则：
  - 每个模型在 configs/model/{name}.yaml 里声明自己的推荐规则（`recommender:` 段）
  - Recommender 启动时扫描 configs/model/*.yaml，加载所有规则到内存
  - 对每个 profile：按规则计算分数和推荐 overrides

新增模型 = 只改该模型的 yaml（加 `recommender:` 段），无需改 Python 代码。

YAML schema:
    recommender:
      base_score: 0.5              # 默认评分
      rules:                        # 评分加减规则
        - when: "n_features > 20"  # 安全 eval 的表达式
          bonus: 0.2
          reason: "channel clustering for heterogeneous features"
      overrides:                    # 动态配置覆盖（可选）
        - when: "n_features > 20"
          set:
            hidden_size: 256

可用变量：
  n_features, n_samples, anomaly_ratio, complexity,
  has_period, period, period_strength,
  correlation_level ('low'/'medium'/'high'), mean_corr,
  trend_ratio, n_trending
"""
import logging
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional

import yaml

from .data_profile import DataProfile

logger = logging.getLogger(__name__)

_PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent
_MODEL_CFG_DIR = _PROJECT_ROOT / 'configs' / 'model'


# -----------------------------------------------------------------------------
# 安全表达式求值
# -----------------------------------------------------------------------------

_SAFE_CONSTANTS = {'True': True, 'False': False, 'None': None, 'max': max, 'min': min}


def _safe_eval(expr: str, namespace: Dict[str, Any]) -> Any:
    """求值一个受限的 Python 表达式。

    只允许 namespace 中的变量 + True/False/None/max/min，
    禁止 attribute 访问、import、函数调用（除 max/min）。
    """
    try:
        code = compile(expr, '<recommender-rule>', 'eval')
    except SyntaxError as e:
        raise ValueError(f"规则语法错误 {expr!r}: {e}")

    allowed = set(namespace) | set(_SAFE_CONSTANTS)
    for name in code.co_names:
        if name not in allowed:
            raise ValueError(f"规则 {expr!r} 引用未知名 {name!r}（仅允许: {sorted(allowed)})")
    return eval(code, {"__builtins__": {}}, {**namespace, **_SAFE_CONSTANTS})


def _profile_to_namespace(profile: DataProfile) -> Dict[str, Any]:
    """把 DataProfile 展开成 recommender 规则可用的扁平命名空间。"""
    has_period = profile.periodicity.get('has_periodicity', False)
    period = profile.periodicity.get('dominant_period', 0) or 0
    period_strength = profile.periodicity.get('strength', 0.0) or 0.0
    correlation_level = profile.correlations.get('correlation_level', 'medium')
    mean_corr = profile.correlations.get('mean_abs_corr', 0.5)

    n_trending = sum(
        1 for v in profile.trend.values()
        if isinstance(v, dict) and v.get('type', 'none') != 'none'
    )
    trend_ratio = n_trending / max(len(profile.trend), 1)

    return {
        'n_features': profile.n_features,
        'n_samples': profile.n_samples,
        'anomaly_ratio': profile.anomaly_ratio,
        'complexity': profile.complexity_score,
        'has_period': has_period,
        'period': period,
        'period_strength': period_strength,
        'correlation_level': correlation_level,
        'mean_corr': mean_corr,
        'trend_ratio': trend_ratio,
        'n_trending': n_trending,
    }


def _resolve_set_value(val: Any, namespace: Dict[str, Any]) -> Any:
    """overrides.set 的值如果是字符串，尝试 eval 为表达式；失败则当字面量。"""
    if isinstance(val, str) and any(c in val for c in '()<>+-*/'):
        try:
            return _safe_eval(val, namespace)
        except ValueError:
            return val
    return val


# -----------------------------------------------------------------------------
# 推荐结果与主类
# -----------------------------------------------------------------------------

@dataclass
class ModelRecommendation:
    model_name: str
    score: float
    config_overrides: Dict[str, Any]
    reasoning: str


class ModelRecommender:
    """基于 YAML 规则的模型推荐器。

    启动时扫描 `configs/model/*.yaml`，将每个模型的 `recommender:` 段加载为规则。
    只要模型 yaml 里有 `recommender:` 段，即自动参与推荐——无需修改本文件。
    """

    def __init__(self, config=None, rules_dir: Optional[Path] = None):
        self.config = config or {}
        self.top_k = self.config.get('top_k', 3)
        self._rules_dir = Path(rules_dir) if rules_dir else _MODEL_CFG_DIR
        self._rules: Dict[str, dict] = {}
        self._load_rules()

    @property
    def ALL_MODELS(self) -> List[str]:
        """所有有 `recommender:` 段的模型名，按字母序。"""
        return sorted(self._rules.keys())

    def _load_rules(self):
        """扫描 configs/model/*.yaml，加载 `recommender:` 段。"""
        if not self._rules_dir.exists():
            logger.warning(f"模型配置目录不存在: {self._rules_dir}")
            return

        for yaml_file in sorted(self._rules_dir.glob('*.yaml')):
            model_name = yaml_file.stem
            try:
                with open(yaml_file, encoding='utf-8') as f:
                    cfg = yaml.safe_load(f) or {}
                rec = cfg.get('recommender')
                if rec:
                    self._rules[model_name] = rec
            except Exception as e:
                logger.warning(f"加载 {yaml_file.name} 的 recommender 失败: {e}")

        logger.info(f"加载了 {len(self._rules)} 个模型的推荐规则: {self.ALL_MODELS}")

    # -------------------------------------------------------------------------
    # 公开接口
    # -------------------------------------------------------------------------

    def recommend(
        self, profile: DataProfile, top_k: Optional[int] = None,
    ) -> List[ModelRecommendation]:
        """返回按分数降序的前 k 个推荐。"""
        top_k = top_k or self.top_k
        namespace = _profile_to_namespace(profile)

        recommendations: List[ModelRecommendation] = []
        for model_name, rule_spec in self._rules.items():
            score, reasons = self._score(rule_spec, namespace)
            overrides = self._overrides(rule_spec, namespace, profile)
            recommendations.append(ModelRecommendation(
                model_name=model_name,
                score=score,
                config_overrides=overrides,
                reasoning='; '.join(reasons) if reasons else 'general-purpose model',
            ))

        recommendations.sort(key=lambda r: r.score, reverse=True)

        top = recommendations[:top_k]
        logger.info(f"Model recommendations (top {top_k}):")
        for r in top:
            logger.info(f"  {r.model_name}: score={r.score:.3f} - {r.reasoning}")
        return top

    def summary(self, recommendations: List[ModelRecommendation]) -> str:
        lines = ['=' * 50, 'Model Recommendations', '=' * 50]
        for i, r in enumerate(recommendations, 1):
            lines.append(f'\n#{i} {r.model_name} (score: {r.score:.3f})')
            lines.append(f'   Reason: {r.reasoning}')
            ov_str = ', '.join(
                f'{k}={v}' for k, v in r.config_overrides.items() if k != 'enc_in'
            )
            if ov_str:
                lines.append(f'   Config: {ov_str}')
        lines.append('=' * 50)
        return '\n'.join(lines)

    # -------------------------------------------------------------------------
    # 规则应用
    # -------------------------------------------------------------------------

    def _score(self, rule_spec: dict, namespace: dict) -> tuple:
        score = rule_spec.get('base_score', 0.5)
        reasons: List[str] = []
        for rule in rule_spec.get('rules', []) or []:
            when = rule.get('when', 'True')
            try:
                if _safe_eval(when, namespace):
                    score += rule.get('bonus', 0.0)
                    reason = rule.get('reason')
                    if reason:
                        reasons.append(reason)
            except ValueError as e:
                logger.warning(f"跳过规则 {when!r}: {e}")
        score = max(0.0, min(1.0, score))
        return score, reasons

    def _overrides(self, rule_spec: dict, namespace: dict, profile: DataProfile) -> Dict[str, Any]:
        """构造配置 override。先设基础项（enc_in + d_model 按特征数），再应用规则。"""
        overrides: Dict[str, Any] = {'enc_in': profile.n_features}

        # 默认 d_model 按特征数缩放
        if profile.n_features <= 10:
            overrides['d_model'] = 64
        elif profile.n_features <= 50:
            overrides['d_model'] = 128
        else:
            overrides['d_model'] = 256

        for rule in rule_spec.get('overrides', []) or []:
            when = rule.get('when', 'True')
            try:
                if not _safe_eval(when, namespace):
                    continue
            except ValueError as e:
                logger.warning(f"跳过 override 规则 {when!r}: {e}")
                continue
            set_dict = rule.get('set', {}) or {}
            for k, v in set_dict.items():
                overrides[k] = _resolve_set_value(v, {**namespace, **overrides})
        return overrides
