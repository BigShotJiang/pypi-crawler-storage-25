"""
AutoML 模块
"""
from .data_profile import DataProfile
from .data_profiler import DataProfiler
from .model_recommender import ModelRecommender, ModelRecommendation
from .meta_learner import MetaLearner
from .ensemble import AdaptiveEnsemble
from .pipeline import AutoMLPipeline

__all__ = [
    'DataProfile', 'DataProfiler',
    'ModelRecommender', 'ModelRecommendation',
    'MetaLearner', 'AdaptiveEnsemble', 'AutoMLPipeline',
    'ReportGenerator',
]

from .report_generator import ReportGenerator
