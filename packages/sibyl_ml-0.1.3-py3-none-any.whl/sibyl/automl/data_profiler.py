"""
自动数据特征分析器
"""
import numpy as np
import logging
from typing import Optional, List
from .data_profile import DataProfile

logger = logging.getLogger(__name__)


class DataProfiler:
    """分析时序数据特征，生成 DataProfile"""

    def __init__(self, config=None):
        self.config = config or {}
        self.alpha = self.config.get('stationarity_alpha', 0.05)
        self.periodicity_method = self.config.get('periodicity_method', 'fft')
        self.anomaly_method = self.config.get('anomaly_method', 'iqr')
        self.anomaly_contamination = self.config.get('anomaly_contamination', 0.05)
        self.min_seq_len = self.config.get('min_seq_len', 24)
        self.max_seq_len = self.config.get('max_seq_len', 720)

    def profile(self, data: np.ndarray, column_names: list = None) -> DataProfile:
        """
        分析数据并生成 profile
        Args:
            data: [n_samples, n_features] numpy array
            column_names: optional feature names
        Returns:
            DataProfile
        """
        n_samples, n_features = data.shape
        logger.info(f"Profiling data: {n_samples} samples, {n_features} features")

        profile = DataProfile(n_samples=n_samples, n_features=n_features)

        # 1. Stationarity
        profile.stationarity = self._test_stationarity(data)

        # 2. Periodicity (use mean series for global periodicity)
        profile.periodicity = self._detect_periodicity(data)

        # 3. Trend
        profile.trend = self._detect_trend(data)

        # 4. Missing values
        profile.missing_pattern = self._analyze_missing(data)

        # 5. Feature correlations
        profile.correlations = self._compute_correlations(data)

        # 6. Anomalies
        anomaly_result = self._detect_anomalies(data)
        profile.anomaly_ratio = anomaly_result['ratio']
        profile.anomaly_indices = anomaly_result['indices']

        # 7. Recommendations
        seq_rec = self._recommend_sequence_lengths(data, profile.periodicity)
        profile.recommended_seq_len = seq_rec['seq_len']
        profile.recommended_pred_len = seq_rec['pred_len']

        norm_rec = self._recommend_normalization(data, profile.anomaly_ratio)
        profile.recommended_normalization = norm_rec

        # 8. Complexity score
        profile.complexity_score = self._compute_complexity(profile)

        logger.info(f"Profile complete. Complexity: {profile.complexity_score:.2f}")
        return profile

    def _test_stationarity(self, data: np.ndarray) -> dict:
        """ADF + KPSS tests per feature"""
        results = {}
        try:
            from statsmodels.tsa.stattools import adfuller, kpss
        except ImportError:
            logger.warning("statsmodels not available, skipping stationarity tests")
            return results

        # Test a subset of features (max 20) to avoid slow profiling
        n_features = data.shape[1]
        feature_indices = range(min(n_features, 20))

        for i in feature_indices:
            series = data[:, i]
            # Remove NaN for tests
            series_clean = series[~np.isnan(series)]
            if len(series_clean) < 50:
                continue

            try:
                adf_result = adfuller(series_clean, autolag='AIC')
                adf_pvalue = adf_result[1]
            except Exception:
                adf_pvalue = 1.0

            try:
                kpss_result = kpss(series_clean, regression='c', nlags='auto')
                kpss_pvalue = kpss_result[1]
            except Exception:
                kpss_pvalue = 0.0

            # Stationary if ADF rejects (p < alpha) AND KPSS does not reject (p > alpha)
            is_stationary = (adf_pvalue < self.alpha) and (kpss_pvalue > self.alpha)

            results[i] = {
                'adf_pvalue': float(adf_pvalue),
                'kpss_pvalue': float(kpss_pvalue),
                'is_stationary': is_stationary
            }

        return results

    def _detect_periodicity(self, data: np.ndarray) -> dict:
        """FFT-based periodicity detection on mean series"""
        # Use mean across features
        mean_series = np.nanmean(data, axis=1)
        mean_series = mean_series - np.nanmean(mean_series)

        n = len(mean_series)
        if n < 10:
            return {'has_periodicity': False, 'dominant_period': 0, 'strength': 0.0, 'periods': []}

        # FFT
        fft_vals = np.fft.rfft(mean_series)
        fft_magnitude = np.abs(fft_vals)
        freqs = np.fft.rfftfreq(n)

        # Skip DC component (index 0) and very low frequencies
        min_period = 2
        max_period = n // 2
        valid_mask = (freqs > 0) & (1.0 / (freqs + 1e-10) <= max_period) & (1.0 / (freqs + 1e-10) >= min_period)

        if not valid_mask.any():
            return {'has_periodicity': False, 'dominant_period': 0, 'strength': 0.0, 'periods': []}

        valid_magnitudes = fft_magnitude[valid_mask]
        valid_freqs = freqs[valid_mask]

        # Find top peaks
        top_k = min(5, len(valid_magnitudes))
        top_indices = np.argsort(valid_magnitudes)[-top_k:][::-1]

        total_energy = np.sum(fft_magnitude[1:] ** 2)
        dominant_freq = valid_freqs[top_indices[0]]
        dominant_period = int(round(1.0 / dominant_freq)) if dominant_freq > 0 else 0
        dominant_strength = float(valid_magnitudes[top_indices[0]] ** 2 / (total_energy + 1e-10))

        periods = []
        for idx in top_indices:
            freq = valid_freqs[idx]
            if freq > 0:
                period = int(round(1.0 / freq))
                if period not in periods:
                    periods.append(period)

        # Consider periodicity significant if dominant peak explains > 10% of energy
        has_periodicity = dominant_strength > 0.1

        return {
            'has_periodicity': has_periodicity,
            'dominant_period': dominant_period,
            'strength': dominant_strength,
            'periods': periods[:5]
        }

    def _detect_trend(self, data: np.ndarray) -> dict:
        """逐特征趋势检测：归一化线性斜率 + Mann-Kendall τ 检验。

        Mann-Kendall 对单调趋势的显著性给出非参数检验；与斜率互为独立证据：
        斜率衡量大小，MK τ 衡量方向单调性的稳健程度 (对异常值不敏感)。
        """
        results = {}
        n_samples = data.shape[0]
        t = np.arange(n_samples, dtype=float)
        t_normalized = (t - t.mean()) / (t.std() + 1e-10)

        n_features = min(data.shape[1], 20)

        # MK 检验可选依赖：优先 scipy.stats.kendalltau（几乎必装）
        try:
            from scipy.stats import kendalltau
        except Exception:
            kendalltau = None

        for i in range(n_features):
            series = data[:, i]
            valid = ~np.isnan(series)
            if valid.sum() < 10:
                results[i] = {
                    'slope': 0.0, 'type': 'none', 'magnitude': 0.0,
                    'mk_tau': 0.0, 'mk_p': 1.0,
                }
                continue

            # Simple linear regression
            t_valid = t_normalized[valid]
            s_valid = series[valid]
            s_norm = (s_valid - s_valid.mean()) / (s_valid.std() + 1e-10)

            slope = np.dot(t_valid, s_norm) / (np.dot(t_valid, t_valid) + 1e-10)

            # Mann-Kendall τ：τ∈[-1,1] 衡量单调程度，p 为双侧显著性
            if kendalltau is not None:
                try:
                    # 长序列时下采样以降低 O(N²) 代价（对 τ 的分布影响有限）
                    if len(s_valid) > 2000:
                        idx = np.linspace(0, len(s_valid) - 1, 2000).astype(int)
                        tau_res = kendalltau(np.arange(len(idx)), s_valid[idx])
                    else:
                        tau_res = kendalltau(np.arange(len(s_valid)), s_valid)
                    mk_tau = float(tau_res.statistic) if tau_res.statistic == tau_res.statistic else 0.0
                    mk_p = float(tau_res.pvalue) if tau_res.pvalue == tau_res.pvalue else 1.0
                except Exception:
                    mk_tau, mk_p = 0.0, 1.0
            else:
                mk_tau, mk_p = 0.0, 1.0

            # 分类：斜率和 MK 都要求方向一致（斜率够大且 MK 显著）才算 trend
            if abs(slope) < 0.01 and mk_p > 0.05:
                trend_type = 'none'
            elif slope > 0:
                trend_type = 'increasing'
            else:
                trend_type = 'decreasing'

            results[i] = {
                'slope': float(slope),
                'type': trend_type,
                'magnitude': float(abs(slope)),
                'mk_tau': mk_tau,
                'mk_p': mk_p,
            }

        return results

    def _analyze_missing(self, data: np.ndarray) -> dict:
        """Missing value analysis"""
        total_elements = data.size
        nan_count = np.isnan(data).sum()
        total_ratio = float(nan_count / total_elements) if total_elements > 0 else 0.0

        per_feature = {}
        for i in range(data.shape[1]):
            feat_nan = np.isnan(data[:, i]).sum()
            per_feature[i] = float(feat_nan / data.shape[0]) if data.shape[0] > 0 else 0.0

        # Longest consecutive NaN gap (on first feature as proxy)
        longest_gap = 0
        if data.shape[1] > 0:
            is_nan = np.isnan(data[:, 0])
            current_gap = 0
            for v in is_nan:
                if v:
                    current_gap += 1
                    longest_gap = max(longest_gap, current_gap)
                else:
                    current_gap = 0

        return {
            'total_ratio': total_ratio,
            'per_feature': per_feature,
            'longest_gap': longest_gap
        }

    def _compute_correlations(self, data: np.ndarray) -> dict:
        """Feature correlation analysis"""
        n_features = data.shape[1]
        if n_features < 2:
            return {'mean_abs_corr': 0.0, 'high_corr_pairs': [], 'correlation_level': 'low'}

        # Use at most 50 features —— copy 避免污染原始 data（切片返回 view 会就地修改调用者）
        subset = data[:, :min(n_features, 50)].copy()

        # Replace NaN with column mean for correlation
        col_means = np.nanmean(subset, axis=0)
        for i in range(subset.shape[1]):
            mask = np.isnan(subset[:, i])
            subset[mask, i] = col_means[i]

        # Pearson correlation
        try:
            corr_matrix = np.corrcoef(subset.T)
            np.fill_diagonal(corr_matrix, 0)

            mean_abs_corr = float(np.mean(np.abs(corr_matrix)))

            # Find high correlation pairs (|corr| > 0.8)
            high_pairs = []
            for i in range(corr_matrix.shape[0]):
                for j in range(i+1, corr_matrix.shape[1]):
                    if abs(corr_matrix[i, j]) > 0.8:
                        high_pairs.append((i, j, float(corr_matrix[i, j])))

            high_pairs.sort(key=lambda x: abs(x[2]), reverse=True)

            if mean_abs_corr > 0.6:
                level = 'high'
            elif mean_abs_corr > 0.3:
                level = 'medium'
            else:
                level = 'low'

            return {
                'mean_abs_corr': mean_abs_corr,
                'high_corr_pairs': high_pairs[:20],
                'correlation_level': level
            }
        except Exception:
            return {'mean_abs_corr': 0.0, 'high_corr_pairs': [], 'correlation_level': 'unknown'}

    def _detect_anomalies(self, data: np.ndarray) -> dict:
        """Anomaly detection"""
        # Replace NaN for detection
        data_clean = data.copy()
        col_means = np.nanmean(data_clean, axis=0)
        for i in range(data_clean.shape[1]):
            mask = np.isnan(data_clean[:, i])
            data_clean[mask, i] = col_means[i]

        if self.anomaly_method == 'isolation_forest':
            try:
                from sklearn.ensemble import IsolationForest
                # Use subset for speed
                n_sub = min(data_clean.shape[0], 5000)
                indices = np.random.choice(data_clean.shape[0], n_sub, replace=False)
                sub = data_clean[indices]

                iso = IsolationForest(contamination=self.anomaly_contamination, random_state=42, n_jobs=-1)
                labels = iso.fit_predict(sub)
                anomaly_mask = labels == -1

                ratio = float(anomaly_mask.sum() / len(anomaly_mask))
                anomaly_indices = indices[anomaly_mask].tolist()

                return {'ratio': ratio, 'indices': anomaly_indices[:100]}
            except ImportError:
                logger.warning("sklearn not available, falling back to IQR")

        # IQR fallback
        q1 = np.nanpercentile(data_clean, 25, axis=0)
        q3 = np.nanpercentile(data_clean, 75, axis=0)
        iqr = q3 - q1
        lower = q1 - 1.5 * iqr
        upper = q3 + 1.5 * iqr

        outlier_mask = np.any((data_clean < lower) | (data_clean > upper), axis=1)
        ratio = float(outlier_mask.sum() / len(outlier_mask))
        anomaly_indices = np.where(outlier_mask)[0].tolist()

        return {'ratio': ratio, 'indices': anomaly_indices[:100]}

    def _recommend_sequence_lengths(self, data: np.ndarray, periodicity: dict) -> dict:
        """Recommend seq_len and pred_len based on data characteristics"""
        n_samples = data.shape[0]

        if periodicity.get('has_periodicity', False):
            dominant_period = periodicity.get('dominant_period', 96)
            # seq_len = 2 * dominant period (capture at least 2 full cycles)
            seq_len = max(self.min_seq_len, min(2 * dominant_period, self.max_seq_len))
            # pred_len = 1 period or quarter of seq_len
            pred_len = max(1, min(dominant_period, seq_len // 4))
        else:
            # Default heuristics
            seq_len = 96
            pred_len = 24

        # Ensure we don't exceed data length
        max_possible = n_samples // 3  # Need room for train/val/test
        seq_len = min(seq_len, max_possible)
        pred_len = min(pred_len, seq_len // 2)

        # Round to nice numbers
        seq_len = max(self.min_seq_len, int(round(seq_len / 8) * 8))
        pred_len = max(1, int(round(pred_len / 4) * 4))

        return {'seq_len': seq_len, 'pred_len': pred_len}

    def _recommend_normalization(self, data: np.ndarray, anomaly_ratio: float) -> str:
        """Recommend normalization strategy"""
        if anomaly_ratio > 0.1:
            return 'robust'  # Robust to outliers

        # Check if data is roughly Gaussian
        try:
            from scipy import stats
            # Test first feature
            series = data[~np.isnan(data[:, 0]), 0]
            if len(series) > 100:
                _, p_value = stats.normaltest(series[:5000])
                if p_value > 0.05:
                    return 'standard'
        except Exception:
            pass

        # Check range
        data_range = np.nanmax(data) - np.nanmin(data)
        data_std = np.nanstd(data)

        if data_std > 0 and data_range / data_std > 10:
            return 'minmax'  # Wide range relative to std

        return 'standard'

    def _compute_complexity(self, profile: DataProfile) -> float:
        """Compute composite complexity score (0-1)"""
        scores = []

        # Non-stationarity contributes to complexity
        if profile.stationarity:
            n_nonstat = sum(1 for v in profile.stationarity.values()
                          if isinstance(v, dict) and not v.get('is_stationary', True))
            scores.append(n_nonstat / max(len(profile.stationarity), 1))

        # Strong periodicity reduces complexity (predictable pattern)
        if profile.periodicity.get('has_periodicity', False):
            scores.append(1.0 - profile.periodicity.get('strength', 0))
        else:
            scores.append(0.7)  # No clear pattern = moderately complex

        # High correlation reduces complexity (redundant features)
        corr_level = profile.correlations.get('correlation_level', 'medium')
        corr_score = {'high': 0.3, 'medium': 0.5, 'low': 0.8}.get(corr_level, 0.5)
        scores.append(corr_score)

        # Anomalies increase complexity
        scores.append(min(profile.anomaly_ratio * 5, 1.0))

        # Missing data increases complexity
        missing = profile.missing_pattern.get('total_ratio', 0)
        scores.append(min(missing * 10, 1.0))

        # Feature count
        feat_score = min(profile.n_features / 100, 1.0)
        scores.append(feat_score)

        return float(np.mean(scores)) if scores else 0.5
