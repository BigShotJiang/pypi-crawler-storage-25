"""
统计检验 - Friedman + Nemenyi 用于模型对比
"""
import numpy as np
import logging

logger = logging.getLogger(__name__)


def friedman_test(results: np.ndarray):
    """
    Friedman 检验：多个模型在多个数据集上的表现是否有显著差异。
    Args:
        results: [n_datasets, n_models] 性能矩阵（越小越好，如 MAE）
    Returns:
        (chi2, p_value)
    """
    try:
        from scipy.stats import friedmanchisquare
    except ImportError:
        logger.warning("scipy not available")
        return 0.0, 1.0

    n_datasets, n_models = results.shape
    if n_datasets < 3 or n_models < 2:
        logger.warning(f"Friedman needs >=3 datasets and >=2 models, got {n_datasets}x{n_models}")
        return 0.0, 1.0

    # 每列是一个模型的结果
    columns = [results[:, i] for i in range(n_models)]
    chi2, p_value = friedmanchisquare(*columns)
    return float(chi2), float(p_value)


def nemenyi_test(results: np.ndarray, alpha: float = 0.05):
    """
    Nemenyi post-hoc 检验：哪些模型间有显著差异。
    Args:
        results: [n_datasets, n_models] 性能矩阵
        alpha: 显著性水平
    Returns:
        (critical_difference, avg_ranks)
    """
    n_datasets, n_models = results.shape

    # 计算每个数据集上的排名（越小越好的指标，排名 1 = 最好）
    ranks = np.zeros_like(results)
    for i in range(n_datasets):
        from scipy.stats import rankdata
        ranks[i] = rankdata(results[i])

    avg_ranks = ranks.mean(axis=0)

    # Nemenyi critical difference:
    #   CD = q_{alpha, k} * sqrt(k * (k + 1) / (6 * N))
    # 其中 q_{alpha, k} = studentized_range_ppf(1-alpha, k, inf) / sqrt(2)
    # 优先用 scipy 精确计算，失败再 fallback 到查表，对任意 k 有效
    q = None
    try:
        from scipy.stats import studentized_range
        q = float(studentized_range.ppf(1 - alpha, n_models, np.inf)) / np.sqrt(2)
    except Exception:
        # fallback 查表（仅 k=2..10 且 alpha=0.05 已校准）
        if alpha == 0.05:
            q_table = {2: 1.960, 3: 2.343, 4: 2.569, 5: 2.728,
                       6: 2.850, 7: 2.949, 8: 3.031, 9: 3.102, 10: 3.164}
            if n_models in q_table:
                q = q_table[n_models]
            else:
                logger.warning(
                    f"scipy 不可用且 n_models={n_models} 超出 Nemenyi 查表范围(2-10); "
                    f"CD 值不准"
                )
                q = q_table[10]
        else:
            logger.warning(f"scipy 不可用且 alpha={alpha}; Nemenyi CD 仅对 alpha=0.05 校准")
            q = 3.164

    cd = q * np.sqrt(n_models * (n_models + 1) / (6 * n_datasets))
    return float(cd), avg_ranks


def wilcoxon_signed_rank(a: np.ndarray, b: np.ndarray):
    """
    Wilcoxon signed-rank 检验：两个模型是否有显著差异。
    Args:
        a, b: 两个模型在各数据集上的指标值
    Returns:
        (statistic, p_value)
    """
    try:
        from scipy.stats import wilcoxon
    except ImportError:
        return 0.0, 1.0

    if len(a) < 5:
        return 0.0, 1.0

    diff = a - b
    if np.all(diff == 0):
        return 0.0, 1.0

    stat, p_value = wilcoxon(a, b)
    return float(stat), float(p_value)
