"""
自动报告生成器 - 生成论文级别的对比表格、图表和统计检验
"""
import os
import csv
import logging
import numpy as np
import pandas as pd
from typing import List, Dict, Optional

from .stat_tests import friedman_test, nemenyi_test

logger = logging.getLogger(__name__)

try:
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    try:
        plt.style.use('seaborn-v0_8-whitegrid')
    except OSError:
        pass
except ImportError:
    plt = None


class ReportGenerator:
    """从实验结果生成论文级报告"""

    def __init__(self, leaderboard_path: str = 'reports/forecast/leaderboard.csv'):
        self.leaderboard_path = leaderboard_path
        self.df = None

    def load_results(self, path: str = None) -> pd.DataFrame:
        """加载实验结果"""
        path = path or self.leaderboard_path
        if not os.path.exists(path):
            logger.warning(f"Leaderboard not found: {path}")
            return pd.DataFrame()

        self.df = pd.read_csv(path)
        logger.info(f"Loaded {len(self.df)} experiment results")
        return self.df

    def generate_full_report(self, output_dir: str = 'report') -> None:
        """生成完整报告"""
        if self.df is None or self.df.empty:
            self.load_results()
        if self.df is None or self.df.empty:
            logger.warning("No results to report")
            return

        os.makedirs(output_dir, exist_ok=True)

        self.generate_comparison_table(output_dir)
        self.generate_latex_table(output_dir)
        if plt is not None:
            self.generate_comparison_figures(output_dir)
        self.run_statistical_tests(output_dir)

        logger.info(f"Full report generated in {output_dir}")

    def generate_comparison_table(self, output_dir: str) -> None:
        """生成模型对比 CSV 表"""
        metrics = ['MAE', 'MSE', 'RMSE', 'R2', 'PCC']
        available = [m for m in metrics if m in self.df.columns]

        # 按模型聚合（取每个模型的最佳结果）
        summary = []
        for model in self.df['Model'].unique():
            model_df = self.df[self.df['Model'] == model]
            row = {'Model': model}
            for m in available:
                vals = pd.to_numeric(model_df[m], errors='coerce').dropna()
                if len(vals) > 0:
                    if m in ('R2', 'PCC'):
                        row[m] = f"{vals.max():.4f}"
                    else:
                        row[m] = f"{vals.min():.4f}"
            summary.append(row)

        summary_df = pd.DataFrame(summary)
        path = os.path.join(output_dir, 'model_comparison.csv')
        summary_df.to_csv(path, index=False)
        logger.info(f"Comparison table saved to {path}")

    def generate_latex_table(self, output_dir: str, metrics: list = None) -> str:
        """生成 LaTeX 格式对比表"""
        if metrics is None:
            metrics = ['MAE', 'MSE', 'RMSE']
        available = [m for m in metrics if m in self.df.columns]

        models = sorted(self.df['Model'].unique())

        # 收集数据
        data = {}
        for model in models:
            model_df = self.df[self.df['Model'] == model]
            data[model] = {}
            for m in available:
                vals = pd.to_numeric(model_df[m], errors='coerce').dropna()
                if len(vals) > 0:
                    data[model][m] = vals.min() if m not in ('R2', 'PCC') else vals.max()

        # 找最佳和次佳
        best = {}
        second = {}
        for m in available:
            vals = [(model, data[model].get(m, float('inf'))) for model in models]
            if m in ('R2', 'PCC'):
                vals.sort(key=lambda x: x[1], reverse=True)
            else:
                vals.sort(key=lambda x: x[1])
            if len(vals) > 0:
                best[m] = vals[0][0]
            if len(vals) > 1:
                second[m] = vals[1][0]

        # 生成 LaTeX
        header = ' & '.join(['Model'] + available)
        lines = [
            '\\begin{table}[htbp]',
            '\\centering',
            '\\caption{Model Comparison}',
            '\\label{tab:comparison}',
            '\\begin{tabular}{l' + 'c' * len(available) + '}',
            '\\toprule',
            header + ' \\\\',
            '\\midrule',
        ]

        for model in models:
            cells = [model]
            for m in available:
                val = data[model].get(m, None)
                if val is None:
                    cells.append('-')
                else:
                    formatted = f"{val:.4f}"
                    if best.get(m) == model:
                        formatted = f"\\textbf{{{formatted}}}"
                    elif second.get(m) == model:
                        formatted = f"\\underline{{{formatted}}}"
                    cells.append(formatted)
            lines.append(' & '.join(cells) + ' \\\\')

        lines.extend([
            '\\bottomrule',
            '\\end{tabular}',
            '\\end{table}',
        ])

        latex = '\n'.join(lines)

        path = os.path.join(output_dir, 'comparison_table.tex')
        with open(path, 'w') as f:
            f.write(latex)
        logger.info(f"LaTeX table saved to {path}")
        return latex

    def generate_comparison_figures(self, output_dir: str) -> None:
        """生成对比图表"""
        if plt is None:
            return

        models = sorted(self.df['Model'].unique())

        # 1. Bar chart: MAE per model
        self._plot_metric_bars(models, 'MAE', output_dir)

        # 2. Radar chart (if enough metrics)
        metrics_for_radar = ['MAE', 'MSE', 'RMSE']
        available = [m for m in metrics_for_radar if m in self.df.columns]
        if len(available) >= 3:
            self._plot_radar(models, available, output_dir)

        # 3. Efficiency plot: MAE vs params/throughput
        if 'Model_Params' in self.df.columns or 'GPU_Memory' in self.df.columns:
            self._plot_efficiency(models, output_dir)

    def _plot_metric_bars(self, models, metric, output_dir):
        """柱状图对比"""
        fig, ax = plt.subplots(figsize=(10, 5))

        values = []
        for model in models:
            model_df = self.df[self.df['Model'] == model]
            vals = pd.to_numeric(model_df[metric], errors='coerce').dropna()
            values.append(vals.min() if len(vals) > 0 else 0)

        colors = plt.cm.Set2(np.linspace(0, 1, len(models)))
        bars = ax.bar(models, values, color=colors)

        # 标注最佳
        best_idx = np.argmin(values)
        bars[best_idx].set_edgecolor('red')
        bars[best_idx].set_linewidth(2)

        ax.set_ylabel(metric)
        ax.set_title(f'Model Comparison - {metric}')
        ax.grid(True, alpha=0.3, axis='y')
        plt.xticks(rotation=45, ha='right')
        plt.tight_layout()
        plt.savefig(os.path.join(output_dir, f'comparison_{metric.lower()}.png'), dpi=150)
        plt.close()

    def _plot_radar(self, models, metrics, output_dir):
        """雷达图"""
        fig, ax = plt.subplots(figsize=(8, 8), subplot_kw=dict(polar=True))

        n_metrics = len(metrics)
        angles = np.linspace(0, 2 * np.pi, n_metrics, endpoint=False).tolist()
        angles += angles[:1]

        for model in models:
            model_df = self.df[self.df['Model'] == model]
            values = []
            for m in metrics:
                vals = pd.to_numeric(model_df[m], errors='coerce').dropna()
                values.append(vals.min() if len(vals) > 0 else 0)
            values += values[:1]
            ax.plot(angles, values, linewidth=2, label=model)
            ax.fill(angles, values, alpha=0.1)

        ax.set_xticks(angles[:-1])
        ax.set_xticklabels(metrics)
        ax.legend(loc='upper right', bbox_to_anchor=(1.3, 1.1))
        plt.title('Model Comparison (Radar)')
        plt.tight_layout()
        plt.savefig(os.path.join(output_dir, 'comparison_radar.png'), dpi=150)
        plt.close()

    def _plot_efficiency(self, models, output_dir):
        """效率图：MAE vs GPU_Memory"""
        if 'GPU_Memory' not in self.df.columns or 'MAE' not in self.df.columns:
            return

        fig, ax = plt.subplots(figsize=(8, 6))

        for model in models:
            model_df = self.df[self.df['Model'] == model]
            mae = pd.to_numeric(model_df['MAE'], errors='coerce').dropna()
            mem = pd.to_numeric(model_df['GPU_Memory'], errors='coerce').dropna()
            if len(mae) > 0 and len(mem) > 0:
                ax.scatter(mem.values[0], mae.values[0], s=100, label=model, zorder=5)
                ax.annotate(model, (mem.values[0], mae.values[0]),
                          textcoords="offset points", xytext=(5, 5), fontsize=9)

        ax.set_xlabel('GPU Memory (MB)')
        ax.set_ylabel('MAE')
        ax.set_title('Accuracy vs Efficiency')
        ax.grid(True, alpha=0.3)
        plt.tight_layout()
        plt.savefig(os.path.join(output_dir, 'efficiency_plot.png'), dpi=150)
        plt.close()

    def run_statistical_tests(self, output_dir: str) -> Dict:
        """运行统计检验"""
        models = sorted(self.df['Model'].unique())
        metric = 'MAE'

        if metric not in self.df.columns or len(models) < 2:
            return {}

        # 构建结果矩阵：每个 experiment 作为一个 "dataset"
        experiments = self.df['Experiment'].unique()

        # 如果只有一个实验，无法做 Friedman
        if len(experiments) < 3:
            logger.info("Need >=3 experiments for Friedman test, skipping statistical tests")
            # 还是保存基本排名
            results = {'note': 'Need >=3 experiments for Friedman test'}
            ranks = []
            for model in models:
                vals = pd.to_numeric(self.df[self.df['Model'] == model][metric], errors='coerce').dropna()
                ranks.append({'model': model, 'best_mae': float(vals.min()) if len(vals) > 0 else float('inf')})
            ranks.sort(key=lambda x: x['best_mae'])
            results['rankings'] = ranks

            import json
            with open(os.path.join(output_dir, 'statistical_tests.json'), 'w') as f:
                json.dump(results, f, indent=2)
            return results

        # 构建 [n_experiments, n_models] 矩阵
        result_matrix = np.full((len(experiments), len(models)), np.nan)
        for i, exp in enumerate(experiments):
            for j, model in enumerate(models):
                mask = (self.df['Experiment'] == exp) & (self.df['Model'] == model)
                vals = pd.to_numeric(self.df[mask][metric], errors='coerce').dropna()
                if len(vals) > 0:
                    result_matrix[i, j] = vals.min()

        # 去掉有 NaN 的行
        valid_rows = ~np.any(np.isnan(result_matrix), axis=1)
        result_matrix = result_matrix[valid_rows]

        results = {}

        if len(result_matrix) >= 3:
            chi2, p_value = friedman_test(result_matrix)
            results['friedman'] = {'chi2': chi2, 'p_value': p_value,
                                   'significant': p_value < 0.05}

            cd, avg_ranks = nemenyi_test(result_matrix)
            results['nemenyi'] = {
                'critical_difference': cd,
                'avg_ranks': {model: float(r) for model, r in zip(models, avg_ranks)},
            }

            logger.info(f"Friedman: chi2={chi2:.4f}, p={p_value:.4f}")
            logger.info(f"Nemenyi CD={cd:.4f}")
            for model, rank in zip(models, avg_ranks):
                logger.info(f"  {model}: avg_rank={rank:.2f}")

        import json
        with open(os.path.join(output_dir, 'statistical_tests.json'), 'w') as f:
            json.dump(results, f, indent=2, default=str)
        logger.info(f"Statistical tests saved to {output_dir}")

        return results
