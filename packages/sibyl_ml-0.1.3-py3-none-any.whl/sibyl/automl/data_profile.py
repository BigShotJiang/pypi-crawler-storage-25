"""
数据特征分析结果
"""
from dataclasses import dataclass, field, asdict
from typing import Dict, List, Optional
import json


@dataclass
class DataProfile:
    """时序数据特征分析结果（不可变）"""

    # 基本信息
    n_samples: int = 0
    n_features: int = 0

    # 平稳性分析（per-feature）
    stationarity: Dict = field(default_factory=dict)
    # Format: {feature_idx: {'adf_pvalue': float, 'kpss_pvalue': float, 'is_stationary': bool}}

    # 周期性检测
    periodicity: Dict = field(default_factory=dict)
    # Format: {'dominant_period': int, 'strength': float, 'periods': [int], 'has_periodicity': bool}

    # 趋势检测
    trend: Dict = field(default_factory=dict)
    # Format: {feature_idx: {'slope': float, 'type': 'increasing'|'decreasing'|'none', 'magnitude': float}}

    # 缺失值分析
    missing_pattern: Dict = field(default_factory=dict)
    # Format: {'total_ratio': float, 'per_feature': {idx: ratio}, 'longest_gap': int}

    # 特征相关性
    correlations: Dict = field(default_factory=dict)
    # Format: {'mean_abs_corr': float, 'high_corr_pairs': [(i,j,corr)], 'correlation_level': 'high'|'medium'|'low'}

    # 异常检测
    anomaly_ratio: float = 0.0
    anomaly_indices: List = field(default_factory=list)

    # 推荐参数
    recommended_seq_len: int = 96
    recommended_pred_len: int = 24
    recommended_normalization: str = 'standard'  # standard | minmax | robust

    # 复杂度评分 (0=simple, 1=complex)
    complexity_score: float = 0.0

    def to_dict(self) -> dict:
        """转为字典"""
        return asdict(self)

    def to_json(self, path: str = None) -> str:
        """转为 JSON"""
        result = json.dumps(self.to_dict(), indent=2, default=str)
        if path:
            with open(path, 'w') as f:
                f.write(result)
        return result

    def summary(self) -> str:
        """生成可读摘要"""
        lines = [
            "=" * 50,
            "Data Profile Summary",
            "=" * 50,
            f"Samples: {self.n_samples}, Features: {self.n_features}",
            f"Complexity Score: {self.complexity_score:.2f}",
            "",
            "--- Stationarity ---",
        ]

        n_stationary = sum(1 for v in self.stationarity.values() if isinstance(v, dict) and v.get('is_stationary', False))
        lines.append(f"Stationary features: {n_stationary}/{len(self.stationarity)}")

        lines.append("")
        lines.append("--- Periodicity ---")
        if self.periodicity.get('has_periodicity', False):
            lines.append(f"Dominant period: {self.periodicity.get('dominant_period', 'N/A')} (strength: {self.periodicity.get('strength', 0):.3f})")
        else:
            lines.append("No significant periodicity detected")

        lines.append("")
        lines.append("--- Trend ---")
        n_trending = sum(1 for v in self.trend.values() if isinstance(v, dict) and v.get('type', 'none') != 'none')
        lines.append(f"Features with trend: {n_trending}/{len(self.trend)}")

        lines.append("")
        lines.append("--- Correlations ---")
        lines.append(f"Mean |correlation|: {self.correlations.get('mean_abs_corr', 0):.3f} ({self.correlations.get('correlation_level', 'unknown')})")

        lines.append("")
        lines.append(f"Anomaly ratio: {self.anomaly_ratio:.4f}")
        lines.append(f"Missing ratio: {self.missing_pattern.get('total_ratio', 0):.4f}")

        lines.append("")
        lines.append("--- Recommendations ---")
        lines.append(f"seq_len: {self.recommended_seq_len}")
        lines.append(f"pred_len: {self.recommended_pred_len}")
        lines.append(f"normalization: {self.recommended_normalization}")
        lines.append("=" * 50)

        return "\n".join(lines)
