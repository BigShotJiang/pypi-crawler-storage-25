"""
Inference bundle 加载工具 —— 用 `inference_bundle.yaml` + `best_model.pt` 复现训练时的模型。

使用示例：
    from sibyl.automl.inference_loader import load_from_bundle
    model, data_loader, meta = load_from_bundle('outputs/xxxxxx/checkpoints')
    # 推理
    for batch in data_loader.get_test_loader():
        ...

目录结构期望：
    <bundle_dir>/
    ├── best_model.pt          # 训练时保存的权重
    └── inference_bundle.yaml  # ModelCheckpoint callback 生成的元数据
"""
from __future__ import annotations
import os
from pathlib import Path
import yaml
import torch
from omegaconf import OmegaConf


def load_from_bundle(bundle_dir: str | Path, device: str = 'cpu'):
    """从 inference bundle 加载模型 + 数据加载器。

    返回:
        model:        已加载权重、已 eval() 的模型
        data_loader:  数据加载器（可调用 get_train/val/test_loader()）
        meta:         dict，含 best_val_loss / best_epoch / full bundle 各段
    """
    bundle_dir = Path(bundle_dir)
    bundle_file = bundle_dir / 'inference_bundle.yaml'
    weight_file = bundle_dir / 'best_model.pt'

    if not bundle_file.exists():
        raise FileNotFoundError(f'缺少 {bundle_file}')
    if not weight_file.exists():
        raise FileNotFoundError(f'缺少 {weight_file}')

    with open(bundle_file) as f:
        bundle = yaml.safe_load(f) or {}

    # 构建模型
    from sibyl.models import get_model
    model_cfg = dict(bundle.get('model', {}))
    model_cfg.pop('recommender', None)
    model_name = model_cfg.get('name')
    if not model_name:
        raise ValueError('bundle.model.name 缺失')
    model_cfg_oc = OmegaConf.create(model_cfg)
    model = get_model(model_name, model_cfg_oc)

    # 加载权重
    state = torch.load(weight_file, map_location=device, weights_only=False)
    if isinstance(state, dict) and 'model_state_dict' in state:
        sd = state['model_state_dict']
    elif isinstance(state, dict) and 'state_dict' in state:
        sd = state['state_dict']
    else:
        sd = state
    # 过滤掉 ForecastTask 的 scaler buffer（不属于 model）
    sd = {k: v for k, v in sd.items() if k not in ('scaler_mean', 'scaler_std')}
    model.load_state_dict(sd, strict=False)
    model = model.to(device)
    model.eval()

    # 构建数据加载器
    data_loader = None
    if 'data_loader' in bundle:
        dl_cfg = dict(bundle['data_loader'])
        # 处理 path 里的 ${paths.data_dir} 插值（若 bundle 未 resolve）
        path = dl_cfg.get('path', '')
        if isinstance(path, str) and '${paths.data_dir}' in path:
            proj = os.environ.get('PROJECT_ROOT', os.getcwd())
            dl_cfg['path'] = path.replace('${paths.data_dir}', f'{proj}/datasets')
        dl_cfg_oc = OmegaConf.create(dl_cfg)
        from sibyl.data_providers import get_data_loader
        data_loader = get_data_loader(dl_cfg_oc)

    meta = {
        'best_val_loss': bundle.get('meta', {}).get('best_val_loss'),
        'best_epoch': bundle.get('meta', {}).get('best_epoch'),
        'model_config': bundle.get('model'),
        'data_loader_config': bundle.get('data_loader'),
        'training_config': bundle.get('training'),
    }
    return model, data_loader, meta


__all__ = ['load_from_bundle']
