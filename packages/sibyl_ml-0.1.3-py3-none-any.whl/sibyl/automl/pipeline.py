"""
AutoML Pipeline - 端到端自动化预测流水线
"""
import os
import json
import time
import logging
import numpy as np
import torch
import yaml
from pathlib import Path
from typing import Dict
from omegaconf import OmegaConf, DictConfig

from .data_profiler import DataProfiler
from .model_recommender import ModelRecommender
from .ensemble import AdaptiveEnsemble

_PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent
_MODEL_CFG_DIR = _PROJECT_ROOT / 'configs' / 'model'

logger = logging.getLogger(__name__)


class AutoMLPipeline:
    """
    端到端 AutoML 流水线：
    1. 分析数据特征
    2. 推荐模型
    3. 训练 top-K 模型
    4. 构建集成
    5. 生成报告
    """

    def __init__(self, cfg: DictConfig):
        self.cfg = cfg
        auto_cfg = OmegaConf.to_container(cfg.get('auto', {}), resolve=True) if 'auto' in cfg else {}
        self.auto_cfg = auto_cfg
        self.top_k = auto_cfg.get('top_k', 3)
        self.ensemble_method = auto_cfg.get('ensemble_method', 'per_horizon')
        self.profile_output = auto_cfg.get('profile_output', True)

    def run(self, data_provider, output_dir: str = '.') -> Dict:
        """运行完整 AutoML 流水线"""
        results = {}
        total_start = time.time()

        # ===== Step 1: Profile =====
        logger.info("=" * 60)
        logger.info("[AutoML] Step 1/4: Profiling data...")
        logger.info("=" * 60)

        raw_data = data_provider.get_raw_data()
        if raw_data is None:
            # fallback：从 train_loader 取第一个 batch 的 x 拼成 raw data
            logger.warning("get_raw_data() returned None, reconstructing from train_loader...")
            chunks = []
            for batch in data_provider.get_train_loader():
                x = batch[0] if isinstance(batch, (list, tuple)) else batch
                chunks.append(x.numpy().reshape(-1, x.shape[-1]))
                if sum(c.shape[0] for c in chunks) >= 5000:
                    break
            raw_data = np.concatenate(chunks, axis=0)
        profiler = DataProfiler(self.auto_cfg.get('profiler', {}))
        profile = profiler.profile(raw_data)
        logger.info(f"\n{profile.summary()}")

        if self.profile_output:
            profile.to_json(os.path.join(output_dir, 'data_profile.json'))

        results['profile'] = profile

        # ===== Step 2: Recommend =====
        logger.info("=" * 60)
        logger.info("[AutoML] Step 2/4: Recommending models...")
        logger.info("=" * 60)

        recommender = ModelRecommender()
        recommendations = recommender.recommend(profile, top_k=self.top_k)
        logger.info(f"\n{recommender.summary(recommendations)}")
        results['recommendations'] = recommendations

        # ===== Step 3: Train =====
        logger.info("=" * 60)
        logger.info(f"[AutoML] Step 3/4: Training top-{self.top_k} models...")
        logger.info("=" * 60)

        train_loader = data_provider.get_train_loader()
        val_loader = data_provider.get_val_loader()
        test_loader = data_provider.get_test_loader()

        model_results = []
        ensemble = AdaptiveEnsemble(method=self.ensemble_method)

        for i, rec in enumerate(recommendations):
            logger.info(f"\n--- Training model {i+1}/{len(recommendations)}: {rec.model_name} ---")
            model_start = time.time()

            try:
                task, trainer, best_val_loss = self._train_single_model(
                    rec.model_name, rec.config_overrides,
                    train_loader, val_loader,
                    output_dir=os.path.join(output_dir, f'model_{rec.model_name}')
                )

                test_result = task.test(test_loader)
                train_time = time.time() - model_start

                model_info = {
                    'name': rec.model_name,
                    'score': rec.score,
                    'val_loss': best_val_loss,
                    'test_metrics': {k: v for k, v in test_result['metrics'].items()
                                    if isinstance(v, (int, float))},
                    'train_time': train_time,
                }
                model_results.append(model_info)
                ensemble.add_model(rec.model_name, task, best_val_loss)

                mae = test_result['metrics'].get('MAE', 'N/A')
                mae_str = f"{mae:.4f}" if isinstance(mae, (int, float)) else str(mae)
                logger.info(f"  {rec.model_name}: MAE={mae_str}, time={train_time:.1f}s")

            except Exception as e:
                logger.error(f"  {rec.model_name} FAILED: {e}")
                model_results.append({'name': rec.model_name, 'error': str(e)})

        results['model_results'] = model_results

        # ===== Step 4: Ensemble =====
        logger.info("=" * 60)
        logger.info("[AutoML] Step 4/4: Building ensemble...")
        logger.info("=" * 60)

        if len(ensemble.models) >= 2:
            ensemble.fit_weights(val_loader)
            ensemble_preds, ensemble_targets = ensemble.predict(test_loader)

            from sibyl.metrics import MetricsManager
            metrics_mgr = MetricsManager(['MAE', 'MSE', 'RMSE', 'R2'])
            ensemble_metrics = metrics_mgr.compute_all(
                torch.tensor(ensemble_preds),
                torch.tensor(ensemble_targets)
            )

            results['ensemble'] = {
                'method': self.ensemble_method,
                'weights': ensemble.get_weights_summary(),
                'metrics': {k: float(v) for k, v in ensemble_metrics.items()
                           if isinstance(v, (int, float))},
            }

            logger.info(f"\nEnsemble results ({self.ensemble_method}):")
            for k, v in results['ensemble']['metrics'].items():
                logger.info(f"  {k}: {v:.4f}")

            ens_dir = os.path.join(output_dir, 'ensemble')
            os.makedirs(ens_dir, exist_ok=True)
            np.save(os.path.join(ens_dir, 'preds.npy'), ensemble_preds)
            np.save(os.path.join(ens_dir, 'trues.npy'), ensemble_targets)
        else:
            logger.warning("Not enough models for ensemble")
            results['ensemble'] = None

        # ===== Summary =====
        total_time = time.time() - total_start
        results['total_time'] = total_time
        self._save_report(results, output_dir)

        logger.info("=" * 60)
        logger.info(f"[AutoML] Complete! Total time: {total_time:.1f}s")
        logger.info("=" * 60)

        return results

    def _load_model_yaml(self, model_name: str) -> dict:
        """从 configs/model/{name}.yaml 加载模型默认参数，找不到则 fallback 到 cfg.model。"""
        yaml_path = _MODEL_CFG_DIR / f'{model_name}.yaml'
        if yaml_path.exists():
            with open(yaml_path) as f:
                raw = yaml.safe_load(f) or {}
            # 过滤掉 recommender 段和 Hydra 插值表达式，只保留纯量值
            cfg = {}
            for k, v in raw.items():
                if k in ('recommender',):
                    continue
                if isinstance(v, str) and v.startswith('${'):
                    continue  # 跳过插值，由下方 data/training 覆盖
                cfg[k] = v
            return cfg
        # fallback
        return OmegaConf.to_container(self.cfg.model, resolve=True)

    def _train_single_model(self, model_name, config_overrides, train_loader, val_loader, output_dir):
        """训练单个模型"""
        from sibyl.models import get_model
        from sibyl.tasks import ForecastTask
        from sibyl.trainer import Trainer

        os.makedirs(output_dir, exist_ok=True)

        # 从该模型自己的 yaml 加载参数，而不是从当前 cfg.model（可能是另一个模型）
        model_cfg = self._load_model_yaml(model_name)
        model_cfg['name'] = model_name
        # 注入 data/training 相关维度（覆盖 yaml 里的插值占位符）
        dl = self.cfg.data_loader
        model_cfg['enc_in']  = dl.get('enc_in', 7)
        model_cfg['dec_in']  = dl.get('enc_in', 7)
        model_cfg['c_out']   = dl.get('c_out', dl.get('enc_in', 7))
        model_cfg['seq_len'] = self.cfg.training.get('seq_len', 96)
        model_cfg['pred_len'] = self.cfg.training.get('pred_len', 96)
        model_cfg['label_len'] = self.cfg.training.get('label_len', 48)
        # 应用 recommender 的动态 overrides
        for k, v in config_overrides.items():
            model_cfg[k] = v
        model_cfg = OmegaConf.create(model_cfg)

        # Build training config
        training_cfg = OmegaConf.to_container(self.cfg.training, resolve=True)
        if 'metrics' in self.cfg and 'metrics' in self.cfg.metrics:
            training_cfg['metrics'] = list(self.cfg.metrics.metrics)
        training_cfg = OmegaConf.create(training_cfg)

        # Create model and task
        model = get_model(model_name, model_cfg)
        task = ForecastTask(
            config=training_cfg,
            model=model,
            loss_cfg=self.cfg.get('loss', {'_target_': 'torch.nn.MSELoss'}),
            optimizer_cfg=self.cfg.optimizer,
            scheduler_cfg=self.cfg.get('scheduler', None)
        )

        # Trainer with minimal callbacks
        trainer_cfg = OmegaConf.create({
            'callbacks': ['model_checkpoint', 'early_stopping'],
            'checkpoint_dir': os.path.join(output_dir, 'checkpoints'),
            'early_stopping_patience': self.cfg.training.get('early_stopping_patience', 10),
        })
        trainer = Trainer(task, trainer_cfg)

        epochs = self.cfg.training.get('epochs', 20)
        trainer.fit(train_loader, val_loader, epochs=epochs)

        return task, trainer, trainer.best_val_loss

    def _save_report(self, results, output_dir):
        """保存 AutoML 报告"""
        report = {
            'total_time': results.get('total_time', 0),
            'n_models_trained': len([r for r in results.get('model_results', []) if 'error' not in r]),
            'ensemble_method': self.ensemble_method,
        }

        report['models'] = []
        for r in results.get('model_results', []):
            if 'error' not in r:
                report['models'].append({
                    'name': r['name'],
                    'recommender_score': r['score'],
                    'val_loss': r['val_loss'],
                    'test_mae': r['test_metrics'].get('MAE'),
                    'test_mse': r['test_metrics'].get('MSE'),
                    'train_time_seconds': r['train_time'],
                })

        if results.get('ensemble'):
            report['ensemble'] = results['ensemble']['metrics']
            report['ensemble_weights'] = results['ensemble']['weights']

        valid = [r for r in results.get('model_results', []) if 'error' not in r]
        if valid:
            best = min(valid, key=lambda r: r['test_metrics'].get('MAE', float('inf')))
            report['best_single_model'] = best['name']
            report['best_single_mae'] = best['test_metrics'].get('MAE')

        report_path = os.path.join(output_dir, 'automl_report.json')
        with open(report_path, 'w') as f:
            json.dump(report, f, indent=2, default=str)
        logger.info(f"AutoML report saved to {report_path}")
