"""
Fourier 相关模块 - TSL 对齐实现
Reference: github.com/thuml/Time-Series-Library/layers/FourierCorrelation.py

FEDformer 把注意力搬到频域：FFT -> 选 modes 个频率 -> 复数线性变换 -> IFFT。
"""
import numpy as np
import torch
import torch.nn as nn


def get_frequency_modes(seq_len, modes=64, mode_select_method='random'):
    """选择频域 modes 索引；random 采样或取前 modes 个低频。"""
    modes = min(modes, seq_len // 2)
    if mode_select_method == 'random':
        index = list(range(0, seq_len // 2))
        np.random.shuffle(index)
        index = index[:modes]
    else:
        index = list(range(0, modes))
    index.sort()
    return index


def _compl_mul1d(order, x, weights):
    """复数爱因斯坦乘：x 和 weights 任一是实数时自动升复数。"""
    x_flag = True
    w_flag = True
    if not torch.is_complex(x):
        x_flag = False
        x = torch.complex(x, torch.zeros_like(x).to(x.device))
    if not torch.is_complex(weights):
        w_flag = False
        weights = torch.complex(weights, torch.zeros_like(weights).to(weights.device))
    if x_flag or w_flag:
        return torch.complex(
            torch.einsum(order, x.real, weights.real) - torch.einsum(order, x.imag, weights.imag),
            torch.einsum(order, x.real, weights.imag) + torch.einsum(order, x.imag, weights.real),
        )
    return torch.einsum(order, x.real, weights.real)


class FourierBlock(nn.Module):
    """1D Fourier 块：FFT -> 频域线性变换 -> IFFT。签名与 AttentionLayer 一致。"""

    def __init__(self, in_channels, out_channels, n_heads, seq_len,
                 modes=0, mode_select_method='random'):
        super().__init__()
        index = get_frequency_modes(seq_len, modes=modes,
                                    mode_select_method=mode_select_method)
        # 注册为 buffer，保证 checkpoint 持久化；否则 retest / resume 时 np.random.shuffle
        # 会重新选一组不同的频率索引，与训练权重错位导致严重退化
        # （electricity_fedformer 曾因此出现 test MSE 从 0.38 退化到 1.57）
        self.register_buffer('index', torch.as_tensor(index, dtype=torch.long),
                             persistent=True)
        self.n_heads = n_heads
        self.scale = 1 / (in_channels * out_channels)
        self.weights1 = nn.Parameter(
            self.scale * torch.rand(
                n_heads, in_channels // n_heads, out_channels // n_heads,
                len(self.index), dtype=torch.float,
            )
        )
        self.weights2 = nn.Parameter(
            self.scale * torch.rand(
                n_heads, in_channels // n_heads, out_channels // n_heads,
                len(self.index), dtype=torch.float,
            )
        )

    def forward(self, q, k, v, mask=None):
        # q: [B, L, H, E]
        B, L, H, E = q.shape
        x = q.permute(0, 2, 3, 1)  # [B, H, E, L]
        x_ft = torch.fft.rfft(x, dim=-1)

        out_ft = torch.zeros(B, H, E, L // 2 + 1, device=x.device, dtype=torch.cfloat)
        for wi, i in enumerate(self.index.tolist()):
            if i >= x_ft.shape[3] or wi >= out_ft.shape[3]:
                continue
            out_ft[:, :, :, wi] = _compl_mul1d(
                "bhi,hio->bho",
                x_ft[:, :, :, i],
                torch.complex(self.weights1, self.weights2)[:, :, :, wi],
            )
        x = torch.fft.irfft(out_ft, n=L)
        # 返回 [B, L, H, E] 以对齐 AttentionLayer 的拼接逻辑
        return x.permute(0, 3, 1, 2), None


class FourierCrossAttention(nn.Module):
    """频域交叉注意力：decoder 的 cross-attention 在频域完成。"""

    def __init__(self, in_channels, out_channels, seq_len_q, seq_len_kv,
                 modes=64, mode_select_method='random',
                 activation='tanh', policy=0, num_heads=8):
        super().__init__()
        self.activation = activation
        self.in_channels = in_channels
        self.out_channels = out_channels
        index_q = get_frequency_modes(seq_len_q, modes=modes,
                                      mode_select_method=mode_select_method)
        index_kv = get_frequency_modes(seq_len_kv, modes=modes,
                                       mode_select_method=mode_select_method)
        # 注册为 buffer 保证 checkpoint 持久化（同 FourierBlock 原因）
        self.register_buffer('index_q', torch.as_tensor(index_q, dtype=torch.long),
                             persistent=True)
        self.register_buffer('index_kv', torch.as_tensor(index_kv, dtype=torch.long),
                             persistent=True)
        self.scale = 1 / (in_channels * out_channels)
        self.weights1 = nn.Parameter(
            self.scale * torch.rand(
                num_heads, in_channels // num_heads, out_channels // num_heads,
                len(self.index_q), dtype=torch.float,
            )
        )
        self.weights2 = nn.Parameter(
            self.scale * torch.rand(
                num_heads, in_channels // num_heads, out_channels // num_heads,
                len(self.index_q), dtype=torch.float,
            )
        )

    def forward(self, q, k, v, mask=None):
        B, L, H, E = q.shape
        xq = q.permute(0, 2, 3, 1)
        xk = k.permute(0, 2, 3, 1)

        index_q = self.index_q.tolist()
        index_kv = self.index_kv.tolist()

        xq_ft_ = torch.zeros(B, H, E, len(index_q), device=xq.device, dtype=torch.cfloat)
        xq_ft = torch.fft.rfft(xq, dim=-1)
        for i, j in enumerate(index_q):
            if j >= xq_ft.shape[3]:
                continue
            xq_ft_[:, :, :, i] = xq_ft[:, :, :, j]

        xk_ft_ = torch.zeros(B, H, E, len(index_kv), device=xq.device, dtype=torch.cfloat)
        xk_ft = torch.fft.rfft(xk, dim=-1)
        for i, j in enumerate(index_kv):
            if j >= xk_ft.shape[3]:
                continue
            xk_ft_[:, :, :, i] = xk_ft[:, :, :, j]

        xqk_ft = _compl_mul1d("bhex,bhey->bhxy", xq_ft_, xk_ft_)
        if self.activation == 'tanh':
            xqk_ft = torch.complex(xqk_ft.real.tanh(), xqk_ft.imag.tanh())
        elif self.activation == 'softmax':
            xqk_ft = torch.softmax(abs(xqk_ft), dim=-1)
            xqk_ft = torch.complex(xqk_ft, torch.zeros_like(xqk_ft))
        else:
            raise NotImplementedError(f"activation {self.activation} not supported")

        xqkv_ft = _compl_mul1d("bhxy,bhey->bhex", xqk_ft, xk_ft_)
        xqkvw = _compl_mul1d(
            "bhex,heox->bhox", xqkv_ft,
            torch.complex(self.weights1, self.weights2),
        )

        out_ft = torch.zeros(B, H, E, L // 2 + 1, device=xq.device, dtype=torch.cfloat)
        for i, j in enumerate(index_q):
            if i >= xqkvw.shape[3] or j >= out_ft.shape[3]:
                continue
            out_ft[:, :, :, j] = xqkvw[:, :, :, i]

        out = torch.fft.irfft(out_ft / self.in_channels / self.out_channels, n=xq.size(-1))
        return out.permute(0, 3, 1, 2), None
