"""
时间序列分解层 - TSL 对齐实现
Reference: github.com/thuml/Time-Series-Library/layers/Autoformer_EncDec.py
"""
import torch
import torch.nn as nn


class my_Layernorm(nn.Module):
    """Autoformer 专用的季节性 LayerNorm：减去沿时间维的均值偏置。"""

    def __init__(self, channels):
        super().__init__()
        self.layernorm = nn.LayerNorm(channels)

    def forward(self, x):
        x_hat = self.layernorm(x)
        bias = torch.mean(x_hat, dim=1).unsqueeze(1).repeat(1, x.shape[1], 1)
        return x_hat - bias


class moving_avg(nn.Module):
    """TSL 风格移动平均：用首/末元素对称填充，AvgPool1d 提取趋势。

    注意：TSL 原版两端均用 `(kernel_size-1)//2` 长度的填充，与 odd kernel 配合时
    会产生“首端看向未来”的轻微对称性。本类复刻其行为以保持数值一致。
    """

    def __init__(self, kernel_size, stride):
        super().__init__()
        self.kernel_size = kernel_size
        self.avg = nn.AvgPool1d(kernel_size=kernel_size, stride=stride, padding=0)

    def forward(self, x):
        # [B, T, C]
        front = x[:, 0:1, :].repeat(1, (self.kernel_size - 1) // 2, 1)
        end = x[:, -1:, :].repeat(1, (self.kernel_size - 1) // 2, 1)
        x = torch.cat([front, x, end], dim=1)
        x = self.avg(x.permute(0, 2, 1))
        x = x.permute(0, 2, 1)
        return x


class series_decomp(nn.Module):
    """序列分解：res = x - moving_avg(x), trend = moving_avg(x)。"""

    def __init__(self, kernel_size):
        super().__init__()
        self.moving_avg = moving_avg(kernel_size, stride=1)

    def forward(self, x):
        moving_mean = self.moving_avg(x)
        res = x - moving_mean
        return res, moving_mean


class series_decomp_multi(nn.Module):
    """FEDformer 的多核分解：对多个 kernel size 求均值。"""

    def __init__(self, kernel_size):
        super().__init__()
        self.kernel_size = kernel_size
        self.series_decomp = [series_decomp(k) for k in kernel_size]

    def forward(self, x):
        moving_mean = []
        res = []
        for func in self.series_decomp:
            sea, ma = func(x)
            moving_mean.append(ma)
            res.append(sea)
        sea = sum(res) / len(res)
        moving_mean = sum(moving_mean) / len(moving_mean)
        return sea, moving_mean


# ---------------------------------------------------------------------------
# 向后兼容别名（保留原项目中使用的 CamelCase 命名）
# ---------------------------------------------------------------------------

MovingAverage = moving_avg


class SeriesDecomposition(series_decomp):
    """与旧 API 兼容的别名（原名），行为与 `series_decomp` 相同。"""
    pass
