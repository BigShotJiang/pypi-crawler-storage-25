"""
Layers 工厂类 - 自动扫描和延迟加载
"""
import os
import importlib
from typing import Dict, Type


class LazyLayerDict(dict):
    """
    智能懒加载字典
    自动扫描 layers 目录，延迟导入层
    """

    def __init__(self, layers_dir: str = 'sibyl.layers'):
        self.layers_dir = layers_dir
        # 自动扫描 layers 目录
        layer_map = self._scan_layers_directory()
        super().__init__(layer_map)

    def _scan_layers_directory(self) -> Dict[str, str]:
        """
        自动扫描 layers 文件夹下的所有 .py 文件
        Returns:
            {'Embed': 'sibyl.layers.embed', ...}
        """
        layer_map = {}

        # 用 __file__ 同级目录，确保 Hydra chdir 后仍有效
        dir_path = os.path.dirname(os.path.abspath(__file__))

        if not os.path.isdir(dir_path):
            return layer_map

        exclude_files = ['__init__.py', 'base.py', 'factory.py']

        for filename in os.listdir(dir_path):
            # 忽略特定文件和非 .py 文件
            if (filename.endswith('.py') and
                filename not in exclude_files):

                # 去掉 .py 后缀得到模块名
                module_name = filename[:-3]

                # 构建完整导入路径
                full_path = f"{self.layers_dir}.{module_name}"

                # 存入字典
                layer_map[module_name] = full_path

        return layer_map

    def __getitem__(self, key: str):
        """获取层类，延迟导入"""
        if key in self:
            value = super().__getitem__(key)
            # 已缓存为类则直接返回；否则值是模块路径字符串，继续延迟导入
            if isinstance(value, str):
                module_path = value
            else:
                return value
        else:
            raise NotImplementedError(
                f"Layer [{key}] not found in '{self.layers_dir}' directory. "
                f"Available: {list(self.keys())}"
            )

        try:
            module = importlib.import_module(module_path)
        except ImportError as e:
            raise ImportError(
                f"Failed to import layer [{key}] from {module_path}. "
                f"Dependencies missing?"
            ) from e

        if hasattr(module, key):
            layer_class = getattr(module, key)
        elif hasattr(module, 'Model'):
            layer_class = module.Model
        else:
            raise AttributeError(
                f"Module {module_path} has no class 'Model' or '{key}'"
            )

        super().__setitem__(key, layer_class)
        return layer_class

    def list_available(self) -> list:
        """列出所有可用层"""
        return list(self.keys())


# 创建懒加载字典（自动扫描 layers 目录）
layer_dict = LazyLayerDict('sibyl.layers')


def get_layer(name: str, *args, **kwargs):
    """
    获取层实例
    Args:
        name: 层名称
        *args, **kwargs: 传递给层的参数
    Returns:
        层实例
    """
    layer_class = layer_dict[name]
    return layer_class(*args, **kwargs)
