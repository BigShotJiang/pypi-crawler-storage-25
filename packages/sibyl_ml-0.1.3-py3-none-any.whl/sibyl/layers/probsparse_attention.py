"""
ProbSparse 注意力 - TSL 对齐实现
Reference: github.com/thuml/Time-Series-Library/layers/SelfAttention_Family.py::ProbAttention

工作流程（与 TSL 完全一致）：
  1. `_prob_QK`：对每个 query 从 K 采样 sample_k 个 key，计算稀疏度度量 M，选 top-u 个 query；
  2. `_get_initial_context`：把初始输出填成 V 的均值或 cumsum（加 mask 时）；
  3. `_update_context`：只更新 top-u query 位置的输出为真实 softmax(attn)·V。
"""
import math
import numpy as np
import torch
import torch.nn as nn

from .masking import ProbMask


class ProbAttention(nn.Module):
    """Informer 的 ProbSparse 注意力。"""

    def __init__(self, mask_flag=True, factor=5, scale=None,
                 attention_dropout=0.1, output_attention=False):
        super().__init__()
        self.factor = factor
        self.scale = scale
        self.mask_flag = mask_flag
        self.output_attention = output_attention
        self.dropout = nn.Dropout(attention_dropout)

    def _prob_QK(self, Q, K, sample_k, n_top):
        """计算稀疏 Q-K 得分。Q/K: [B, H, L, D]。"""
        B, H, L_K, E = K.shape
        _, _, L_Q, _ = Q.shape

        # 对每个 query 从 K 随机采样 sample_k 个 key
        K_expand = K.unsqueeze(-3).expand(B, H, L_Q, L_K, E)
        index_sample = torch.randint(L_K, (L_Q, sample_k))
        K_sample = K_expand[:, :,
                            torch.arange(L_Q).unsqueeze(1),
                            index_sample, :]
        Q_K_sample = torch.matmul(
            Q.unsqueeze(-2), K_sample.transpose(-2, -1)
        ).squeeze()

        # 稀疏度度量：max - mean
        M = Q_K_sample.max(-1)[0] - torch.div(Q_K_sample.sum(-1), L_K)
        M_top = M.topk(n_top, sorted=False)[1]

        # 取 top-n_top 个 query 对 K 计算完整注意力
        Q_reduce = Q[torch.arange(B)[:, None, None],
                     torch.arange(H)[None, :, None],
                     M_top, :]
        Q_K = torch.matmul(Q_reduce, K.transpose(-2, -1))
        return Q_K, M_top

    def _get_initial_context(self, V, L_Q):
        B, H, L_V, D = V.shape
        if not self.mask_flag:
            V_sum = V.mean(dim=-2)
            context = V_sum.unsqueeze(-2).expand(B, H, L_Q, V_sum.shape[-1]).clone()
        else:
            assert L_Q == L_V, "ProbSparse mask=True 要求 L_Q == L_V（自注意力）"
            context = V.cumsum(dim=-2)
        return context

    def _update_context(self, context_in, V, scores, index, L_Q, attn_mask):
        B, H, L_V, D = V.shape
        if self.mask_flag:
            attn_mask = ProbMask(B, H, L_Q, index, scores, device=V.device)
            scores.masked_fill_(attn_mask.mask, -np.inf)

        attn = torch.softmax(scores, dim=-1)
        context_in[torch.arange(B)[:, None, None],
                   torch.arange(H)[None, :, None],
                   index, :] = torch.matmul(attn, V).type_as(context_in)

        if self.output_attention:
            attns = (torch.ones([B, H, L_V, L_V]) / L_V).type_as(attn).to(attn.device)
            attns[torch.arange(B)[:, None, None],
                  torch.arange(H)[None, :, None],
                  index, :] = attn
            return context_in, attns
        return context_in, None

    def forward(self, queries, keys, values, attn_mask, tau=None, delta=None):
        """
        Args:
            queries/keys/values: [B, L, H, D]（与 TSL 一致）
        Returns:
            (context, attn): context [B, L, H, D]
        """
        B, L_Q, H, D = queries.shape
        _, L_K, _, _ = keys.shape

        queries = queries.transpose(2, 1)  # [B, H, L, D]
        keys = keys.transpose(2, 1)
        values = values.transpose(2, 1)

        U_part = self.factor * np.ceil(np.log(L_K)).astype('int').item()
        u = self.factor * np.ceil(np.log(L_Q)).astype('int').item()
        U_part = U_part if U_part < L_K else L_K
        u = u if u < L_Q else L_Q

        scores_top, index = self._prob_QK(queries, keys, sample_k=U_part, n_top=u)

        scale = self.scale or 1. / math.sqrt(D)
        if scale is not None:
            scores_top = scores_top * scale

        context = self._get_initial_context(values, L_Q)
        context, attn = self._update_context(context, values, scores_top, index, L_Q, attn_mask)

        return context.contiguous(), attn
