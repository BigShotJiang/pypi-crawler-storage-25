"""
Layers 模块
"""
from .factory import layer_dict, get_layer

__all__ = ['layer_dict', 'get_layer']
