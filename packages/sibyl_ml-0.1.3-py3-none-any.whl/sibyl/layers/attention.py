"""
Attention 模块 - TSL 对齐实现
Reference: github.com/thuml/Time-Series-Library/layers/SelfAttention_Family.py

提供三个主要类：
- FullAttention: 标准 O(L^2) 多头自注意力
- AttentionLayer: 负责 Q/K/V 线性投影与多头拼接
- MultiHeadAttention: 向后兼容的薄封装（用于第三方回调/测试）
"""
import math
import numpy as np
import torch
import torch.nn as nn

from .masking import TriangularCausalMask


class FullAttention(nn.Module):
    """标准缩放点积自注意力。Einsum 版（与 TSL 一致）。"""

    def __init__(self, mask_flag=True, factor=5, scale=None,
                 attention_dropout=0.1, output_attention=False):
        super().__init__()
        self.scale = scale
        self.mask_flag = mask_flag
        self.output_attention = output_attention
        self.dropout = nn.Dropout(attention_dropout)

    def forward(self, queries, keys, values, attn_mask, tau=None, delta=None):
        """
        Args:
            queries/keys/values: [B, L, H, E] / [B, S, H, D]
        Returns:
            (V, A_or_None): V [B, L, H, D]
        """
        B, L, H, E = queries.shape
        _, S, _, D = values.shape
        scale = self.scale or 1. / math.sqrt(E)

        scores = torch.einsum("blhe,bshe->bhls", queries, keys)

        if self.mask_flag:
            if attn_mask is None:
                attn_mask = TriangularCausalMask(B, L, device=queries.device)
            scores.masked_fill_(attn_mask.mask, -np.inf)

        A = self.dropout(torch.softmax(scale * scores, dim=-1))
        V = torch.einsum("bhls,bshd->blhd", A, values)

        if self.output_attention:
            return V.contiguous(), A
        return V.contiguous(), None


class AttentionLayer(nn.Module):
    """Q/K/V 投影 + 多头拼接 + 输出投影。包裹 FullAttention/ProbAttention/AutoCorrelation。"""

    def __init__(self, attention, d_model, n_heads, d_keys=None, d_values=None):
        super().__init__()
        d_keys = d_keys or (d_model // n_heads)
        d_values = d_values or (d_model // n_heads)

        self.inner_attention = attention
        self.query_projection = nn.Linear(d_model, d_keys * n_heads)
        self.key_projection = nn.Linear(d_model, d_keys * n_heads)
        self.value_projection = nn.Linear(d_model, d_values * n_heads)
        self.out_projection = nn.Linear(d_values * n_heads, d_model)
        self.n_heads = n_heads

    def forward(self, queries, keys, values, attn_mask, tau=None, delta=None):
        B, L, _ = queries.shape
        _, S, _ = keys.shape
        H = self.n_heads

        queries = self.query_projection(queries).view(B, L, H, -1)
        keys = self.key_projection(keys).view(B, S, H, -1)
        values = self.value_projection(values).view(B, S, H, -1)

        out, attn = self.inner_attention(queries, keys, values, attn_mask, tau=tau, delta=delta)
        out = out.view(B, L, -1)
        return self.out_projection(out), attn


class MultiHeadAttention(nn.Module):
    """向后兼容薄封装：`MultiHeadAttention(d_model, n_heads, dropout)` 调用签名保留，
    内部走 FullAttention（不加 mask）+ AttentionLayer 的 Q/K/V 投影。
    旧测试与工具可直接使用 `forward(q, k, v, mask=None)`。
    """

    def __init__(self, d_model, n_heads, dropout=0.1):
        super().__init__()
        self.d_model = d_model
        self.n_heads = n_heads
        self.attention_layer = AttentionLayer(
            FullAttention(mask_flag=False, attention_dropout=dropout, output_attention=False),
            d_model, n_heads,
        )

    def forward(self, query, key, value, mask=None):
        # 注意：此封装不使用 mask，保留参数签名只是为了兼容旧调用处
        out, _ = self.attention_layer(query, key, value, attn_mask=None)
        return out


class SelfAttention(nn.Module):
    """纯自注意力的薄封装，主要用于测试。"""

    def __init__(self, d_model, n_heads, dropout=0.1):
        super().__init__()
        self.attention = MultiHeadAttention(d_model, n_heads, dropout)

    def forward(self, x, mask=None):
        return self.attention(x, x, x, mask)


class CrossAttention(nn.Module):
    """交叉注意力薄封装：query 来自一路，key/value 共享另一路。"""

    def __init__(self, d_model, n_heads, dropout=0.1):
        super().__init__()
        self.d_model = d_model
        self.attention = MultiHeadAttention(d_model, n_heads, dropout)

    def forward(self, query, key_value, mask=None):
        return self.attention(query, key_value, key_value, mask)
