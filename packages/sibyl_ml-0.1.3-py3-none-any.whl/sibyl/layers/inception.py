"""
Inception 卷积块 - TSL 对齐实现
Reference: github.com/thuml/Time-Series-Library/layers/Conv_Blocks.py

TimesNet 使用 Inception_Block_V1：num_kernels 个不同 kernel size 的 2D 卷积分支，
输出在通道维堆叠后取均值，结构简单、参数更少（与我们之前的 4 分支 Inception 不同）。
"""
import torch
import torch.nn as nn


class Inception_Block_V1(nn.Module):
    """多尺度 2D 卷积：kernel_size=1, 3, 5, ..., (2*num_kernels-1)，mean 聚合。"""

    def __init__(self, in_channels, out_channels, num_kernels=6, init_weight=True):
        super().__init__()
        self.in_channels = in_channels
        self.out_channels = out_channels
        self.num_kernels = num_kernels
        self.kernels = nn.ModuleList([
            nn.Conv2d(in_channels, out_channels, kernel_size=2 * i + 1, padding=i)
            for i in range(num_kernels)
        ])
        if init_weight:
            self._initialize_weights()

    def _initialize_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                nn.init.kaiming_normal_(m.weight, mode='fan_out', nonlinearity='relu')
                if m.bias is not None:
                    nn.init.constant_(m.bias, 0)

    def forward(self, x):
        res_list = [k(x) for k in self.kernels]
        return torch.stack(res_list, dim=-1).mean(-1)


class Inception_Block_V2(nn.Module):
    """另一版本：用 (1, 2k+3) 与 (2k+3, 1) 分离卷积 + 1×1，再 mean。"""

    def __init__(self, in_channels, out_channels, num_kernels=6, init_weight=True):
        super().__init__()
        self.num_kernels = num_kernels
        kernels = []
        for i in range(num_kernels // 2):
            kernels.append(nn.Conv2d(in_channels, out_channels,
                                     kernel_size=[1, 2 * i + 3], padding=[0, i + 1]))
            kernels.append(nn.Conv2d(in_channels, out_channels,
                                     kernel_size=[2 * i + 3, 1], padding=[i + 1, 0]))
        kernels.append(nn.Conv2d(in_channels, out_channels, kernel_size=1))
        self.kernels = nn.ModuleList(kernels)
        if init_weight:
            self._initialize_weights()

    def _initialize_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                nn.init.kaiming_normal_(m.weight, mode='fan_out', nonlinearity='relu')
                if m.bias is not None:
                    nn.init.constant_(m.bias, 0)

    def forward(self, x):
        res_list = [self.kernels[i](x) for i in range(self.num_kernels // 2 * 2 + 1)]
        return torch.stack(res_list, dim=-1).mean(-1)


# ---------------------------------------------------------------------------
# 向后兼容别名（旧代码引用 InceptionBlockV1）
# ---------------------------------------------------------------------------

InceptionBlockV1 = Inception_Block_V1
InceptionBlockV2 = Inception_Block_V2
