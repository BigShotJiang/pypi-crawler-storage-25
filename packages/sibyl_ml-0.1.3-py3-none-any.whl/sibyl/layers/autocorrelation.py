"""
AutoCorrelation 层 - TSL 对齐实现
Reference: github.com/thuml/Time-Series-Library/layers/AutoCorrelation.py

关键差异（相比先前实现）：
- 训练路径使用 `time_delay_agg_training`（按 batch 平均 + 循环 roll），
  每次迭代只新增 1× values 大小的临时 tensor，而不是把
  [B, H, top_k, L, d_k] 整个 roll 矩阵一次性物化。
  这修复了在 electricity (enc_in=321) + 100-sample feature_importance 前向
  时显存会膨胀到数 GB 的 bug。
- 保留 training / inference 两条路径以对齐 TSL。
"""
import math
import torch
import torch.nn as nn


class AutoCorrelation(nn.Module):
    """自相关注意力：通过 FFT 发现周期依赖，再按 top-k 延迟聚合 values。"""

    def __init__(self, mask_flag=True, factor=1, scale=None,
                 attention_dropout=0.1, output_attention=False):
        super().__init__()
        self.factor = factor
        self.scale = scale
        self.mask_flag = mask_flag
        self.output_attention = output_attention
        self.dropout = nn.Dropout(attention_dropout)

    def time_delay_agg_training(self, values, corr):
        """训练用：对 top_k 延迟循环 roll，显存 O(B·H·C·L) 而非 O(B·H·top_k·C·L)。
        values/corr: [B, H, C, L]
        """
        head = values.shape[1]
        channel = values.shape[2]
        length = values.shape[3]

        top_k = int(self.factor * math.log(length))
        # 对 batch × head × channel 的 corr 取均值，得到 per-length 的全局权重
        mean_value = torch.mean(torch.mean(corr, dim=1), dim=1)  # [B, L]
        index = torch.topk(torch.mean(mean_value, dim=0), top_k, dim=-1)[1]
        weights = torch.stack([mean_value[:, index[i]] for i in range(top_k)], dim=-1)
        tmp_corr = torch.softmax(weights, dim=-1)

        tmp_values = values
        delays_agg = torch.zeros_like(values).float()
        for i in range(top_k):
            pattern = torch.roll(tmp_values, -int(index[i]), -1)
            delays_agg = delays_agg + pattern * (
                tmp_corr[:, i]
                .unsqueeze(1).unsqueeze(1).unsqueeze(1)
                .repeat(1, head, channel, length)
            )
        return delays_agg

    def time_delay_agg_inference(self, values, corr):
        """推理用：per-batch 的延迟（而非共享均值）；用 gather + 2× values 拼接实现。"""
        batch = values.shape[0]
        head = values.shape[1]
        channel = values.shape[2]
        length = values.shape[3]

        init_index = (
            torch.arange(length)
            .unsqueeze(0).unsqueeze(0).unsqueeze(0)
            .repeat(batch, head, channel, 1)
            .to(values.device)
        )
        top_k = int(self.factor * math.log(length))
        mean_value = torch.mean(torch.mean(corr, dim=1), dim=1)
        weights, delay = torch.topk(mean_value, top_k, dim=-1)
        tmp_corr = torch.softmax(weights, dim=-1)

        tmp_values = values.repeat(1, 1, 1, 2)
        delays_agg = torch.zeros_like(values).float()
        for i in range(top_k):
            tmp_delay = init_index + delay[:, i].unsqueeze(1).unsqueeze(1).unsqueeze(1).repeat(
                1, head, channel, length
            )
            pattern = torch.gather(tmp_values, dim=-1, index=tmp_delay)
            delays_agg = delays_agg + pattern * (
                tmp_corr[:, i].unsqueeze(1).unsqueeze(1).unsqueeze(1).repeat(1, head, channel, length)
            )
        return delays_agg

    def time_delay_agg_full(self, values, corr):
        """完整标准版本：对每个 (batch, head, channel) 独立选 top-k 延迟。"""
        batch = values.shape[0]
        head = values.shape[1]
        channel = values.shape[2]
        length = values.shape[3]

        init_index = (
            torch.arange(length)
            .unsqueeze(0).unsqueeze(0).unsqueeze(0)
            .repeat(batch, head, channel, 1)
            .to(values.device)
        )
        top_k = int(self.factor * math.log(length))
        weights, delay = torch.topk(corr, top_k, dim=-1)
        tmp_corr = torch.softmax(weights, dim=-1)

        tmp_values = values.repeat(1, 1, 1, 2)
        delays_agg = torch.zeros_like(values).float()
        for i in range(top_k):
            tmp_delay = init_index + delay[..., i].unsqueeze(-1)
            pattern = torch.gather(tmp_values, dim=-1, index=tmp_delay)
            delays_agg = delays_agg + pattern * (tmp_corr[..., i].unsqueeze(-1))
        return delays_agg

    def forward(self, queries, keys, values, attn_mask):
        """
        Args:
            queries/keys/values: [B, L, H, E]
        Returns:
            (V, corr_or_None): V [B, L, H, E]
        """
        B, L, H, E = queries.shape
        _, S, _, D = values.shape
        if L > S:
            zeros = torch.zeros_like(queries[:, :(L - S), :]).float()
            values = torch.cat([values, zeros], dim=1)
            keys = torch.cat([keys, zeros], dim=1)
        else:
            values = values[:, :L, :, :]
            keys = keys[:, :L, :, :]

        # 周期依赖：Q·conj(K) 在频域 -> IFFT 得相关
        q_fft = torch.fft.rfft(queries.permute(0, 2, 3, 1).contiguous(), dim=-1)
        k_fft = torch.fft.rfft(keys.permute(0, 2, 3, 1).contiguous(), dim=-1)
        res = q_fft * torch.conj(k_fft)
        corr = torch.fft.irfft(res, dim=-1)

        # 延迟聚合（训练/推理不同实现）
        if self.training:
            V = self.time_delay_agg_training(
                values.permute(0, 2, 3, 1).contiguous(), corr
            ).permute(0, 3, 1, 2)
        else:
            V = self.time_delay_agg_inference(
                values.permute(0, 2, 3, 1).contiguous(), corr
            ).permute(0, 3, 1, 2)

        if self.output_attention:
            return V.contiguous(), corr.permute(0, 3, 1, 2)
        return V.contiguous(), None


class AutoCorrelationLayer(nn.Module):
    """与 AttentionLayer 同构：承担 Q/K/V 投影与多头拼接。"""

    def __init__(self, correlation, d_model, n_heads, d_keys=None, d_values=None):
        super().__init__()
        d_keys = d_keys or (d_model // n_heads)
        d_values = d_values or (d_model // n_heads)

        self.inner_correlation = correlation
        self.query_projection = nn.Linear(d_model, d_keys * n_heads)
        self.key_projection = nn.Linear(d_model, d_keys * n_heads)
        self.value_projection = nn.Linear(d_model, d_values * n_heads)
        self.out_projection = nn.Linear(d_values * n_heads, d_model)
        self.n_heads = n_heads

    def forward(self, queries, keys, values, attn_mask):
        B, L, _ = queries.shape
        _, S, _ = keys.shape
        H = self.n_heads

        queries = self.query_projection(queries).view(B, L, H, -1)
        keys = self.key_projection(keys).view(B, S, H, -1)
        values = self.value_projection(values).view(B, S, H, -1)

        out, attn = self.inner_correlation(queries, keys, values, attn_mask)
        out = out.view(B, L, -1)
        return self.out_projection(out), attn
