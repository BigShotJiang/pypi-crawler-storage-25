"""
Forecast Task - 时序预测任务
"""
import torch
import torch.nn as nn
import torch.optim as optim
from typing import Dict
from hydra.utils import instantiate
from .base import BaseTask
from ..metrics import MetricsManager, InferenceTimer


class ForecastTask(BaseTask):
    """时序预测任务"""

    def __init__(self, config, model: nn.Module,
                 loss_cfg, optimizer_cfg, scheduler_cfg):
        super().__init__(config, model)

        # 动态注入 Loss
        self.criterion = instantiate(loss_cfg)

        # 动态注入 Optimizer
        self.optimizer = instantiate(
            optimizer_cfg,
            params=self.model.parameters()
        )

        # 动态注入 Scheduler
        self.scheduler = None
        if scheduler_cfg:
            self.scheduler = instantiate(
                scheduler_cfg,
                optimizer=self.optimizer
            )

        # 初始化指标
        metric_names = config.get('metrics', ['MAE', 'MSE', 'RMSE'])
        self.inference_timer = InferenceTimer()
        self.metrics_manager = MetricsManager(
            metric_names,
            model=self.model,
            timer=self.inference_timer
        )

        # AMP (mixed precision) —— 仅当真正运行在 CUDA 设备上启用（而非仅 CUDA 可用）
        self.use_amp = config.get('use_amp', False) and self.device.type == 'cuda'
        self.scaler = torch.amp.GradScaler('cuda') if self.use_amp else None

        # 检查是否为 PINN Loss（需要传 inputs 参数）
        self._is_pinn = hasattr(self.criterion, 'get_loss_details')

        # 训练状态
        self.current_epoch = 0
        self.best_val_loss = float('inf')

    def _compute_loss(self, outputs, y, inputs=None):
        """计算损失，自动适配 PINNLoss。

        当 c_out < enc_in（如 DAM: 33 输入通道 → 预测前 30 个传感器）时，
        TSL-canonical 模型会输出全部 enc_in 通道；截取前 y.shape[-1] 个以匹配目标。
        """
        if outputs.shape[-1] != y.shape[-1]:
            outputs = outputs[..., :y.shape[-1]]
        if self._is_pinn:
            return self.criterion(outputs, y, inputs=inputs)
        return self.criterion(outputs, y)

    def train_epoch(self, train_loader):
        """训练一个 epoch，返回 (avg_loss, avg_batch_time_s, n_batches, loss_details)

        loss_details 为字典：{'data_loss': ..., 'smooth': ..., ...}。当 criterion
        (如 PINNLoss) 提供 `get_loss_details()` 时自动在各 batch 上累积均值，
        否则为空字典。供 trainer 写入 training_log.csv (论文 §4.4 Per-Term Loss Logging)。
        """
        self.model.train()
        total_loss = 0

        max_grad_norm = self.config.get('max_grad_norm', 1.0)
        has_loss_details = hasattr(self.criterion, 'get_loss_details')
        detail_sums = {}  # {key: 累积值}

        import time as _time
        n_batches = 0
        total_batch_time = 0.0
        for batch_idx, batch in enumerate(train_loader):
            batch_start = _time.time()
            # 数据移到设备（TSL 4 元组：x, y, x_mark, y_mark）
            x, y, x_mark, y_mark = self._prepare_batch(batch)
            y_target = self._slice_target(y)

            # 前向传播 + 反向传播。max_grad_norm=None 时跳过梯度裁剪（TSL 行为）
            self.optimizer.zero_grad()
            if self.use_amp:
                with torch.amp.autocast('cuda'):
                    outputs = self._forward(x, x_mark, y_mark)
                    loss = self._compute_loss(outputs, y_target, x)
                self.scaler.scale(loss).backward()
                self.scaler.unscale_(self.optimizer)
                if max_grad_norm is not None:
                    torch.nn.utils.clip_grad_norm_(self.model.parameters(), max_grad_norm)
                self.scaler.step(self.optimizer)
                self.scaler.update()
            else:
                outputs = self._forward(x, x_mark, y_mark)
                loss = self._compute_loss(outputs, y_target, x)
                loss.backward()
                if max_grad_norm is not None:
                    torch.nn.utils.clip_grad_norm_(self.model.parameters(), max_grad_norm)
                self.optimizer.step()

            total_loss += loss.item()

            # PINN 分项损失累积（若 criterion 提供）
            if has_loss_details:
                try:
                    details = self.criterion.get_loss_details()
                    for k, v in details.items():
                        detail_sums[k] = detail_sums.get(k, 0.0) + float(v)
                except Exception:
                    pass

            total_batch_time += _time.time() - batch_start
            n_batches += 1

        avg_loss = total_loss / max(n_batches, 1)
        avg_batch_time = total_batch_time / max(n_batches, 1)
        n = max(n_batches, 1)
        loss_details = {k: v / n for k, v in detail_sums.items()}
        return avg_loss, avg_batch_time, n_batches, loss_details

    def validate(self, val_loader) -> Dict:
        """验证"""
        self.model.eval()
        total_loss = 0
        all_preds = []
        all_trues = []

        n_batches = 0
        with torch.no_grad():
            for batch in val_loader:
                x, y, x_mark, y_mark = self._prepare_batch(batch)
                y_target = self._slice_target(y)
                if self.use_amp:
                    with torch.amp.autocast('cuda'):
                        outputs = self._forward(x, x_mark, y_mark)
                        loss = self._compute_loss(outputs, y_target, x)
                else:
                    outputs = self._forward(x, x_mark, y_mark)
                    loss = self._compute_loss(outputs, y_target, x)
                total_loss += loss.item()
                n_batches += 1

                if outputs.shape[-1] != y_target.shape[-1]:
                    outputs = outputs[..., :y_target.shape[-1]]
                all_preds.append(outputs.cpu())
                all_trues.append(y_target.cpu())

        avg_loss = total_loss / max(n_batches, 1)

        all_preds = torch.cat(all_preds, dim=0)
        all_trues = torch.cat(all_trues, dim=0)

        metrics_result = self.metrics_manager.compute_all(all_preds, all_trues)
        metrics_result['val_loss'] = avg_loss

        return metrics_result

    def test(self, test_loader) -> Dict:
        """测试并计算所有指标"""
        self.model.eval()
        all_preds = []
        all_trues = []
        all_inputs = []

        self.inference_timer.reset()

        with torch.no_grad():
            for batch in test_loader:
                x, y, x_mark, y_mark = self._prepare_batch(batch)
                y_target = self._slice_target(y)

                # 计时：仅包含前向传播
                self.inference_timer.start()
                if self.use_amp:
                    with torch.amp.autocast('cuda'):
                        outputs = self._forward(x, x_mark, y_mark)
                else:
                    outputs = self._forward(x, x_mark, y_mark)
                self.inference_timer.end(x.shape[0])

                # c_out < enc_in 时截取到目标通道数（参考 _compute_loss 注释）
                if outputs.shape[-1] != y_target.shape[-1]:
                    outputs = outputs[..., :y_target.shape[-1]]
                all_preds.append(outputs.cpu())
                all_trues.append(y_target.cpu())
                all_inputs.append(x.cpu())

        all_preds = torch.cat(all_preds, dim=0)
        all_trues = torch.cat(all_trues, dim=0)
        all_inputs = torch.cat(all_inputs, dim=0)

        metrics_result = self.metrics_manager.compute_all(all_preds, all_trues)

        return {
            'predictions': all_preds,
            'targets': all_trues,
            'inputs': all_inputs,
            'metrics': metrics_result
        }

    def _prepare_batch(self, batch):
        """
        解包 dataloader 输出为 (x, y, x_mark, y_mark)。

        支持：
          - 4 元组（TSL 对齐）：(seq_x, seq_y, seq_x_mark, seq_y_mark)
          - 2 元组（兼容旧实现）：(features, targets)，marks 置 None
          - 单 tensor（自监督）：x 末端截取 pred_len 作为 y
        空 mark（feature 维=0）自动转为 None，配合 TSL DataEmbedding 跳过 temporal 分支。
        """
        if isinstance(batch, (tuple, list)):
            if len(batch) == 4:
                x, y, x_mark, y_mark = batch
                x = x.to(self.device).float()
                y = y.to(self.device).float()
                x_mark = x_mark.to(self.device).float() if x_mark.shape[-1] > 0 else None
                y_mark = y_mark.to(self.device).float() if y_mark.shape[-1] > 0 else None
                return x, y, x_mark, y_mark
            # 2 元组兼容
            x = batch[0].to(self.device).float()
            y = batch[1].to(self.device).float()
            return x, y, None, None
        # 单 tensor 自监督
        x = batch.to(self.device).float()
        pred_len = self.config.get('pred_len', 24)
        y = x[:, -pred_len:, :]
        return x, y, None, None

    def _slice_target(self, y):
        """截取 y 的后 pred_len 步作为损失/指标的目标。

        4 元组 y: [B, label_len+pred_len, F] → [B, pred_len, F]
        2 元组 y: [B, pred_len, F] → 原样返回
        """
        pred_len = self.config.get('pred_len', 24)
        if y.shape[1] > pred_len:
            return y[:, -pred_len:, :]
        return y

    def _forward(self, x, x_mark=None, y_mark=None):
        """
        前向传播（TSL 对齐）。

        构造 decoder 输入：
          x_dec = [x[:, -label_len:, :]; zeros(pred_len)]
          x_mark_dec = y_mark  (若提供，已含 label_len+pred_len 时间特征)

        x_mark / y_mark 为 None 时，TSL DataEmbedding 跳过 temporal 分支，
        与早期 sibyl 行为一致。
        """
        pred_len = self.config.get('pred_len', 24)
        label_len = self.config.get('label_len', pred_len)
        label_len = min(label_len, x.shape[1])

        label_part = x[:, -label_len:, :]
        future_part = torch.zeros(x.shape[0], pred_len, x.shape[2], device=x.device, dtype=x.dtype)
        x_dec = torch.cat([label_part, future_part], dim=1)

        outputs = self.model(x, x_mark, x_dec, y_mark)

        # 输出对齐到 pred_len
        if outputs.dim() == 3:
            if outputs.shape[1] != pred_len:
                outputs = outputs[:, -pred_len:, :]
        elif outputs.dim() == 2:
            outputs = outputs.unsqueeze(1).expand(-1, pred_len, -1)

        return outputs

    def step_scheduler(self, val_loss):
        """更新学习率调度器"""
        if self.scheduler:
            if isinstance(self.scheduler, optim.lr_scheduler.ReduceLROnPlateau):
                self.scheduler.step(val_loss)
            else:
                self.scheduler.step()

    def save_checkpoint(self, path, epoch, val_loss):
        """保存检查点（含 model/optimizer/scheduler/RNG 状态，保证确定性续训）"""
        import random
        import numpy as np
        torch.save({
            'epoch': epoch,
            'model_state_dict': self.model.state_dict(),
            'optimizer_state_dict': self.optimizer.state_dict(),
            'scheduler_state_dict': self.scheduler.state_dict() if self.scheduler is not None else None,
            'val_loss': val_loss,
            'rng_state': torch.get_rng_state(),
            'cuda_rng_state': torch.cuda.get_rng_state() if torch.cuda.is_available() else None,
            'numpy_rng_state': np.random.get_state(),
            'python_rng_state': random.getstate(),
        }, path)

    def load_checkpoint(self, path):
        """加载检查点（model/optimizer/scheduler/RNG 全部恢复）"""
        import random
        import numpy as np
        checkpoint = torch.load(path, map_location=self.device, weights_only=False)
        self.model.load_state_dict(checkpoint['model_state_dict'])
        self.optimizer.load_state_dict(checkpoint['optimizer_state_dict'])

        # 恢复调度器状态
        sch_state = checkpoint.get('scheduler_state_dict')
        if sch_state is not None and self.scheduler is not None:
            self.scheduler.load_state_dict(sch_state)

        # 恢复随机状态
        if 'rng_state' in checkpoint:
            torch.set_rng_state(checkpoint['rng_state'].cpu())
        if 'cuda_rng_state' in checkpoint and torch.cuda.is_available() and checkpoint['cuda_rng_state'] is not None:
            torch.cuda.set_rng_state(checkpoint['cuda_rng_state'].cpu())
        if 'numpy_rng_state' in checkpoint:
            np.random.set_state(checkpoint['numpy_rng_state'])
        if 'python_rng_state' in checkpoint:
            random.setstate(checkpoint['python_rng_state'])

        return checkpoint
