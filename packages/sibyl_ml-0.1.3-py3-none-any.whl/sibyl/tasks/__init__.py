"""
Tasks 模块
"""
from .base import BaseTask
from .forecast_task import ForecastTask
from .gene_expr_task import GeneExprTask, MultiTaskGeneExprLoss

__all__ = ['BaseTask', 'ForecastTask', 'GeneExprTask', 'MultiTaskGeneExprLoss']
