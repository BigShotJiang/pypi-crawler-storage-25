"""
Tasks 基类
"""
import torch
import torch.nn as nn
from abc import ABC, abstractmethod


class BaseTask(ABC):
    """任务基类，封装训练逻辑"""

    def __init__(self, config, model: nn.Module):
        """
        Args:
            config: 配置字典
            model: 模型实例
        """
        self.config = config
        self.model = model
        self.device = self._acquire_device()
        self.scaler_stats = None

        # 将模型移到设备
        self.model = self.model.to(self.device)

    def _acquire_device(self):
        """自动选择设备"""
        use_gpu = self.config.get('use_gpu', True)

        if use_gpu:
            if torch.cuda.is_available():
                device = torch.device('cuda')
                print(f'Use GPU: cuda:{torch.cuda.current_device()}')
            elif torch.backends.mps.is_available():
                device = torch.device('mps')
                print('Use GPU: mps')
            else:
                device = torch.device('cpu')
                print('GPU not available, use CPU')
        else:
            device = torch.device('cpu')
            print('Use CPU')
        return device

    def set_scaler_stats(self, mean: torch.Tensor, std: torch.Tensor):
        """保存归一化统计量，使用 register_buffer"""
        self.model.register_buffer('scaler_mean', mean)
        self.model.register_buffer('scaler_std', std)
        self.scaler_stats = {'mean': mean, 'std': std}

    @abstractmethod
    def train_epoch(self, train_loader):
        """训练一个 epoch"""
        pass

    @abstractmethod
    def validate(self, val_loader):
        """验证"""
        pass

    @abstractmethod
    def test(self, test_loader):
        """测试"""
        pass
