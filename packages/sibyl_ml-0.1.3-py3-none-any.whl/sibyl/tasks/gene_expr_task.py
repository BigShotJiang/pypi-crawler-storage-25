"""基因表达预测任务。

实现 BaseTask 抽象方法，以 dict-batch 语义替换 ForecastTask 的 4-tuple：
  - batch 由 MultiomicsLoader 的 collate_fn 构造，键包含 "seq" + mark_names + "tpm" + "is_expressed" + "gene_id"
  - 模型 forward(batch, return_attention) → {"pred_tpm", "pred_binary", ...}
  - 损失 = Huber(TPM) + λ_binary · CE(expressed) + λ_rank · PairwiseRank(TPM)
  - 指标 = PCC / SCC / R² / RMSE / MAE，log1p 空间 + 反变换回 TPM 空间

契约对齐 Trainer：
  - train_epoch → (avg_loss, avg_batch_time, n_batches, loss_details)
  - validate → dict，必须含 'val_loss'
  - test → dict，含 'predictions' / 'targets' / 'metrics'，以便 callbacks 使用
"""

import logging
import time
from typing import Any, Dict, Optional

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
from hydra.utils import instantiate
from scipy.stats import pearsonr, spearmanr
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

from .base import BaseTask

log = logging.getLogger(__name__)


class MultiTaskGeneExprLoss(nn.Module):
    """L_total = Huber(TPM) + λ_b · CE(expressed) + λ_r · PairwiseRank(TPM)."""

    def __init__(self, lambda_binary: float = 0.1, lambda_rank: float = 0.05,
                 huber_delta: float = 1.0, rank_n_pairs: int = 128,
                 rank_min_diff: float = 0.3):
        super().__init__()
        self.lambda_binary = lambda_binary
        self.lambda_rank = lambda_rank
        self.rank_n_pairs = rank_n_pairs
        self.rank_min_diff = rank_min_diff
        self.huber = nn.HuberLoss(delta=huber_delta)
        self.ce = nn.CrossEntropyLoss()

    def _pairwise_rank(self, pred: torch.Tensor, target: torch.Tensor
                       ) -> torch.Tensor:
        B = pred.shape[0]
        if B < 4:
            return torch.tensor(0.0, device=pred.device)
        i_idx = torch.randint(0, B, (self.rank_n_pairs,), device=pred.device)
        j_idx = torch.randint(0, B, (self.rank_n_pairs,), device=pred.device)
        valid = i_idx != j_idx
        i_idx, j_idx = i_idx[valid], j_idx[valid]
        target_diff = target[i_idx] - target[j_idx]
        mask = target_diff.abs() > self.rank_min_diff
        if mask.sum() < 2:
            return torch.tensor(0.0, device=pred.device)
        pred_diff = (pred[i_idx] - pred[j_idx])[mask]
        rank_label = (target_diff[mask] > 0).float()
        return F.binary_cross_entropy_with_logits(pred_diff, rank_label)

    def forward(self, pred_tpm: torch.Tensor, pred_binary: torch.Tensor,
                target_tpm: torch.Tensor, target_binary: torch.Tensor
                ) -> Dict[str, torch.Tensor]:
        loss_tpm = self.huber(pred_tpm, target_tpm)
        loss_bin = self.ce(pred_binary, target_binary)
        loss_rank = self._pairwise_rank(pred_tpm, target_tpm)
        total = loss_tpm + self.lambda_binary * loss_bin + self.lambda_rank * loss_rank
        return {
            "total": total,
            "tpm": loss_tpm.detach(),
            "binary": loss_bin.detach(),
            "rank": loss_rank.detach(),
        }


class GeneExprTask(BaseTask):
    """基因表达预测任务（V5 模型）。"""

    TENSOR_KEYS = None  # 所有 tensor 键都搬到 device；gene_id 跳过

    def __init__(self, config, model: nn.Module,
                 loss_cfg: Optional[Any] = None,
                 optimizer_cfg: Optional[Any] = None,
                 scheduler_cfg: Optional[Any] = None):
        super().__init__(config, model)

        if loss_cfg is None:
            self.criterion = MultiTaskGeneExprLoss()
        elif isinstance(loss_cfg, nn.Module):
            self.criterion = loss_cfg
        else:
            self.criterion = instantiate(loss_cfg)

        if optimizer_cfg is None:
            self.optimizer = optim.AdamW(
                self.model.parameters(), lr=5e-5, weight_decay=1e-4)
        else:
            self.optimizer = instantiate(
                optimizer_cfg, params=self.model.parameters())

        self.scheduler = None
        if scheduler_cfg is not None:
            self.scheduler = instantiate(scheduler_cfg, optimizer=self.optimizer)

        self.use_amp = bool(config.get("use_amp", False)) and self.device.type == "cuda"
        self.scaler = torch.amp.GradScaler("cuda") if self.use_amp else None

        self.max_grad_norm = config.get("max_grad_norm", 0.5)
        self.current_epoch = 0
        self.best_val_loss = float("inf")

    def _batch_to_device(self, batch: Dict) -> Dict:
        out = {}
        for k, v in batch.items():
            if isinstance(v, torch.Tensor):
                out[k] = v.to(self.device, non_blocking=True)
            else:
                out[k] = v
        return out

    def _compute_loss(self, output: Dict, batch: Dict
                      ) -> Dict[str, torch.Tensor]:
        return self.criterion(
            output["pred_tpm"], output["pred_binary"],
            batch["tpm"], batch["is_expressed"].long(),
        )

    def train_epoch(self, train_loader):
        self.model.train()
        total_loss = 0.0
        detail_sums = {"tpm": 0.0, "binary": 0.0, "rank": 0.0}
        n_batches = 0
        total_batch_time = 0.0

        for batch in train_loader:
            batch_start = time.time()
            batch = self._batch_to_device(batch)

            self.optimizer.zero_grad()
            if self.use_amp:
                with torch.amp.autocast("cuda"):
                    output = self.model(batch)
                    loss_pack = self._compute_loss(output, batch)
                self.scaler.scale(loss_pack["total"]).backward()
                if self.max_grad_norm is not None:
                    self.scaler.unscale_(self.optimizer)
                    torch.nn.utils.clip_grad_norm_(
                        self.model.parameters(), self.max_grad_norm)
                self.scaler.step(self.optimizer)
                self.scaler.update()
            else:
                output = self.model(batch)
                loss_pack = self._compute_loss(output, batch)
                loss_pack["total"].backward()
                if self.max_grad_norm is not None:
                    torch.nn.utils.clip_grad_norm_(
                        self.model.parameters(), self.max_grad_norm)
                self.optimizer.step()

            total_loss += loss_pack["total"].item()
            for k in detail_sums:
                if k in loss_pack:
                    detail_sums[k] += float(loss_pack[k].item())
            n_batches += 1
            total_batch_time += time.time() - batch_start

        avg_loss = total_loss / max(n_batches, 1)
        avg_batch_time = total_batch_time / max(n_batches, 1)
        loss_details = {k: v / max(n_batches, 1) for k, v in detail_sums.items()}
        return avg_loss, avg_batch_time, n_batches, loss_details

    @torch.no_grad()
    def _collect_predictions(self, loader) -> Dict[str, np.ndarray]:
        self.model.eval()
        preds, targets, gene_ids = [], [], []
        total_loss = 0.0
        n_batches = 0
        for batch in loader:
            batch = self._batch_to_device(batch)
            output = self.model(batch)
            loss_pack = self._compute_loss(output, batch)
            total_loss += loss_pack["total"].item()
            n_batches += 1

            preds.append(output["pred_tpm"].detach().cpu().numpy())
            targets.append(batch["tpm"].detach().cpu().numpy())
            gids = batch.get("gene_id")
            if gids:
                gene_ids.extend(list(gids))

        preds_arr = np.concatenate(preds) if preds else np.zeros(0)
        targets_arr = np.concatenate(targets) if targets else np.zeros(0)
        avg_loss = total_loss / max(n_batches, 1)
        return {
            "preds": preds_arr,
            "targets": targets_arr,
            "gene_ids": gene_ids,
            "avg_loss": avg_loss,
        }

    @staticmethod
    def _compute_metrics(preds: np.ndarray, targets: np.ndarray) -> Dict[str, float]:
        if preds.size == 0 or targets.size == 0:
            return {}
        pcc = float(pearsonr(targets, preds)[0])
        scc = float(spearmanr(targets, preds)[0])
        r2 = float(r2_score(targets, preds))
        rmse = float(np.sqrt(mean_squared_error(targets, preds)))
        mae = float(mean_absolute_error(targets, preds))

        true_tpm = np.expm1(targets)
        pred_tpm = np.expm1(np.clip(preds, 0, 20))
        pcc_tpm = float(pearsonr(true_tpm, pred_tpm)[0])
        r2_tpm = float(r2_score(true_tpm, pred_tpm))
        return {
            "PCC": pcc,
            "SCC": scc,
            "R2": r2,
            "RMSE": rmse,
            "MAE": mae,
            "PCC_TPM": pcc_tpm,
            "R2_TPM": r2_tpm,
        }

    def validate(self, val_loader) -> Dict:
        bundle = self._collect_predictions(val_loader)
        metrics = self._compute_metrics(bundle["preds"], bundle["targets"])
        metrics["val_loss"] = bundle["avg_loss"]
        return metrics

    def test(self, test_loader) -> Dict:
        # 暴露最近一次测试用的 loader，供注意力导出等 on_test_end 回调复用。
        self._last_test_loader = test_loader
        bundle = self._collect_predictions(test_loader)
        metrics = self._compute_metrics(bundle["preds"], bundle["targets"])
        return {
            "predictions": bundle["preds"],
            "targets": bundle["targets"],
            "gene_ids": bundle["gene_ids"],
            "metrics": metrics,
        }

    def step_scheduler(self, val_loss):
        if self.scheduler is None:
            return
        if isinstance(self.scheduler, optim.lr_scheduler.ReduceLROnPlateau):
            self.scheduler.step(val_loss)
        else:
            self.scheduler.step()

    def save_checkpoint(self, path, epoch, val_loss):
        import random
        torch.save({
            "epoch": epoch,
            "model_state_dict": self.model.state_dict(),
            "optimizer_state_dict": self.optimizer.state_dict(),
            "scheduler_state_dict": self.scheduler.state_dict() if self.scheduler else None,
            "val_loss": val_loss,
            "rng_state": torch.get_rng_state(),
            "cuda_rng_state": torch.cuda.get_rng_state() if torch.cuda.is_available() else None,
            "numpy_rng_state": np.random.get_state(),
            "python_rng_state": random.getstate(),
        }, path)

    def load_checkpoint(self, path):
        import random
        ckpt = torch.load(path, map_location=self.device, weights_only=False)
        self.model.load_state_dict(ckpt["model_state_dict"])
        self.optimizer.load_state_dict(ckpt["optimizer_state_dict"])
        if ckpt.get("scheduler_state_dict") and self.scheduler is not None:
            self.scheduler.load_state_dict(ckpt["scheduler_state_dict"])
        if "rng_state" in ckpt:
            torch.set_rng_state(ckpt["rng_state"].cpu())
        if ckpt.get("cuda_rng_state") is not None and torch.cuda.is_available():
            torch.cuda.set_rng_state(ckpt["cuda_rng_state"].cpu())
        if "numpy_rng_state" in ckpt:
            np.random.set_state(ckpt["numpy_rng_state"])
        if "python_rng_state" in ckpt:
            random.setstate(ckpt["python_rng_state"])
        return ckpt
