"""Launcher 抽象层 — 每种实验 = 一个 Launcher 子类。

main.py 通过 `hydra.utils.instantiate(cfg.launcher, cfg=cfg)` 造出对应实例；
Launcher 封装完整 lifecycle（build → fit → test → cleanup），
不同实验的特殊性（AutoML / env var / resume 策略）在子类内处理。
"""
from .base import BaseLauncher
from .forecast import ForecastLauncher
from .gene_expr import GeneExprLauncher

__all__ = ["BaseLauncher", "ForecastLauncher", "GeneExprLauncher"]
