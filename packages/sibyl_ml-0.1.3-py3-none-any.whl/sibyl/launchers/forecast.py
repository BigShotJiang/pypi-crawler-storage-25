"""ForecastLauncher — 时序预测实验启动器。

特殊能力：
  - 支持 mode=auto（AutoML：DataProfiler → ModelRecommender → top-K train → ensemble）
  - resolve_resume_path 扫 outputs/forecast/*_{experiment_name}/
  - post_build: 注册 scaler_stats 为 model buffer；透传 feature_names 给解释性 callback
  - auto_profile=true: 启动时跑 DataProfiler 打印数据特征
"""
import logging
import os
from typing import Optional, Tuple

from omegaconf import OmegaConf

from ..data_providers import get_data_loader
from ..models import get_model
from ..tasks import ForecastTask
from ..tasks.base import BaseTask
from .base import BaseLauncher

logger = logging.getLogger(__name__)


class ForecastLauncher(BaseLauncher):

    def build(self) -> Tuple[BaseTask, object, object, object]:
        cfg = self.cfg
        model_name = cfg.model.get("name", "Transformer")
        logger.info(f"Loading model: {model_name}")
        model = get_model(model_name, cfg.model)

        _data_path = cfg.data_loader.get("path") or cfg.data_loader.get("train_data_path", "?")
        logger.info(f"Loading data: {_data_path}")
        data_provider = get_data_loader(cfg.data_loader)

        # 可选 auto-profile 打印数据特征 + 模型推荐（旁路，不影响训练）
        if cfg.get("auto_profile", False):
            self._run_profile(data_provider)

        # metric 合并到 training_cfg
        training_cfg = OmegaConf.to_container(cfg.training, resolve=True)
        if "metrics" in cfg and "metrics" in cfg.metrics:
            training_cfg["metrics"] = list(cfg.metrics.metrics)
        training_cfg = OmegaConf.create(training_cfg)

        task = ForecastTask(
            config=training_cfg,
            model=model,
            loss_cfg=cfg.get("loss", {"_target_": "torch.nn.MSELoss"}),
            optimizer_cfg=cfg.optimizer,
            scheduler_cfg=cfg.get("scheduler", None),
        )

        self._post_build(task, data_provider)
        return (
            task,
            data_provider.get_train_loader(),
            data_provider.get_val_loader(),
            data_provider.get_test_loader(),
        )

    def _post_build(self, task, data_provider):
        # 归一化参数注册为 model buffer
        if hasattr(data_provider, "scaler_stats") and data_provider.scaler_stats:
            task.set_scaler_stats(
                data_provider.scaler_stats["mean"],
                data_provider.scaler_stats["std"],
            )
        # 透传 feature_names（SHAP / feature_importance 解释性 callback 用）
        if getattr(data_provider, "feature_names", None):
            task.feature_names = data_provider.feature_names

    def _run_profile(self, data_provider):
        raw_data = data_provider.get_raw_data()
        if raw_data is None:
            return
        from ..automl import DataProfiler, ModelRecommender
        profiler_cfg = OmegaConf.to_container(
            self.cfg.get("profiler", {}), resolve=True) if "profiler" in self.cfg else {}
        profiler = DataProfiler(profiler_cfg)
        profile = profiler.profile(raw_data)
        logger.info(f"\n{profile.summary()}")
        profile.to_json("data_profile.json")

        recommender_cfg = OmegaConf.to_container(
            self.cfg.get("recommender", {}), resolve=True) if "recommender" in self.cfg else {}
        recommender = ModelRecommender(recommender_cfg)
        recommendations = recommender.recommend(profile)
        logger.info(f"\n{recommender.summary(recommendations)}")

    def _run_auto(self):
        """AutoML 走完整 pipeline：profile → recommend → train top-K → ensemble → report。"""
        logger.info("\n" + "=" * 60)
        logger.info("AutoML Pipeline...")
        logger.info("=" * 60)
        data_provider = get_data_loader(self.cfg.data_loader)
        from ..automl import AutoMLPipeline
        return AutoMLPipeline(self.cfg).run(data_provider)

    def resolve_resume_path(self) -> Optional[str]:
        """扫 outputs/forecast/*_{experiment_name}/ 找 latest incomplete run。"""
        exp_name = self.cfg.get("experiment_name", "")
        if not exp_name:
            return None
        project_root = os.environ.get("PROJECT_ROOT", ".")
        outputs_dir = os.path.join(project_root, "outputs", "forecast")
        if not os.path.exists(outputs_dir):
            # 兼容旧布局：outputs/<timestamp>_<exp>/
            outputs_dir = os.path.join(project_root, "outputs")
            if not os.path.exists(outputs_dir):
                return None

        candidates = []
        for d in os.listdir(outputs_dir):
            run_dir = os.path.join(outputs_dir, d)
            if not os.path.isdir(run_dir):
                continue
            if not d.endswith(f"_{exp_name}"):
                continue
            completed = os.path.exists(os.path.join(run_dir, "COMPLETED"))
            has_ckpt = os.path.exists(os.path.join(run_dir, "checkpoints", "checkpoint_last.pt"))
            if not completed and has_ckpt:
                candidates.append(run_dir)

        if not candidates:
            return None
        candidates.sort()
        return os.path.join(candidates[-1], "checkpoints", "checkpoint_last.pt")
