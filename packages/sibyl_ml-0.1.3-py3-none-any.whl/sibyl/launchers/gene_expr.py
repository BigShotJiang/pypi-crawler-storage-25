"""GeneExprLauncher — 基因表达预测实验启动器。

特殊能力：
  - setup_env: 设 PROJECT_ROOT 环境变量（configs/data_loader/spike_multiomics.yaml
    的 cache_dir: ${oc.env:PROJECT_ROOT}/outputs/gene_expr/_cache 需要）
  - build: 装配 GeneExprTask + MultiomicsLoader + crossmark 模型
  - resume: 两级
      · sweep 级：COMPLETED 标记（由 run_sweep.py 处理）跳过整个完成的 run
      · launcher 级：resume=true 从当前 hydra.run.dir/checkpoints/checkpoint_last.pt
                    续训，续中间 epoch（本文件实现）
  - AutoML: 目前没实现（若未来需要，override _run_auto）

与 forecast 的续训差异：gene_expr sweep 把 hydra.run.dir 固定到
    {results_root}/{tag}/fold_{fold}
所以同一 (tag, fold) 每次启动都落同一目录，checkpoint 天然就在 cwd，
不需要 forecast 那套 "扫旧 timestamp 目录 → migrate + rmtree" 流程。
"""
import logging
import os
from typing import Optional, Tuple

from omegaconf import OmegaConf

from ..data_providers import get_data_loader
from ..models import get_model
from ..tasks import GeneExprTask
from ..tasks.base import BaseTask
from .base import BaseLauncher

logger = logging.getLogger(__name__)


class GeneExprLauncher(BaseLauncher):

    def setup_env(self) -> None:
        # 让 yaml 里的 ${oc.env:PROJECT_ROOT} 插值能解析（锚到项目根，不是 Hydra chdir 后的 run dir）
        project_root = self._project_root()
        os.environ["PROJECT_ROOT"] = project_root

    def _project_root(self) -> str:
        # main.py 运行时，__file__ 是 sibyl/launchers/gene_expr.py
        # 向上 3 级才是 repo 根
        return os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))

    def build(self) -> Tuple[BaseTask, object, object, object]:
        cfg = self.cfg
        model_name = cfg.model.get("name", "crossmark")
        logger.info(f"Loading model: {model_name}")
        model = get_model(model_name, cfg.model)

        logger.info(f"Loading data: {cfg.data_loader.get('name', 'multiomics')}")
        data_provider = get_data_loader(cfg.data_loader)

        training_cfg = OmegaConf.to_container(cfg.training, resolve=True)
        if "metrics" in cfg and "metrics" in cfg.metrics:
            training_cfg["metrics"] = list(cfg.metrics.metrics)
        training_cfg = OmegaConf.create(training_cfg)

        task = GeneExprTask(
            config=training_cfg,
            model=model,
            loss_cfg=cfg.get("loss", None),
            optimizer_cfg=cfg.get("optimizer", None),
            scheduler_cfg=cfg.get("scheduler", None),
        )
        return (
            task,
            data_provider.get_train_loader(),
            data_provider.get_val_loader(),
            data_provider.get_test_loader(),
        )

    def resolve_resume_path(self) -> Optional[str]:
        """gene_expr 续训路径：cwd 下的 checkpoints/checkpoint_last.pt。

        sweep 把 hydra.run.dir 固定到 {results_root}/{tag}/fold_{fold}，
        所以当 sweep 因任何原因被杀再次启动、进入同一 (tag, fold) 目录时，
        checkpoint_last.pt 就在当前 cwd 的 checkpoints/ 下。
        """
        ckpt = os.path.join("checkpoints", "checkpoint_last.pt")
        return ckpt if os.path.exists(ckpt) else None

    def _handle_resume(self) -> int:
        """gene_expr 专属续训逻辑：in-place resume，无目录迁移。

        基类 _handle_resume 为 forecast 设计：resolve_resume_path 返回的是旧
        timestamp 目录里的 checkpoint，base 会把整个旧目录复制到当前 Hydra
        run dir 并 rmtree 旧目录。对 gene_expr 不适用 —— 我们的 run dir 本
        来就是固定的，没有"旧 → 新"两个目录，ckpt 就在 cwd 里，直接加载即可。
        """
        start_epoch = 0
        resume_path = self.cfg.get("resume_path", None)
        if self.cfg.get("resume", False) and not resume_path:
            resume_path = self.resolve_resume_path()
            if resume_path:
                logger.info(f"Auto-detected in-place checkpoint: {resume_path}")
            else:
                logger.info("No checkpoint found in cwd; starting fresh.")

        if resume_path and os.path.exists(resume_path):
            logger.info(f"Resuming from checkpoint: {resume_path}")
            ckpt = self.task.load_checkpoint(resume_path)
            start_epoch = ckpt.get("epoch", 0) + 1
            self.trainer.best_val_loss = ckpt.get("val_loss", float("inf"))
            logger.info(f"Resumed from epoch {start_epoch}, "
                        f"best_val_loss: {self.trainer.best_val_loss:.6f}")
        return start_epoch
