"""BaseLauncher — 所有实验启动器的父类（Template Method）。

默认 lifecycle：
    run() → setup_env() → build() → (mode=train: fit+test | mode=test: test)
                                    (mode=auto: _run_auto 默认报错，需子类 override)

子类通常只需 override：
    - build()                     [必须] 装配 task + dataloaders
    - setup_env()                 [可选] 设环境变量/随机种子
    - _run_auto()                 [可选] 如果支持 AutoML
    - resolve_resume_path()       [可选] 如果支持自动续训
    - post_build(task, dataprovider)  [可选] 装配完 task 后的 hook (scaler/feature_names 等)
"""
import logging
import os
from abc import ABC, abstractmethod
from typing import Optional, Tuple

import torch
from omegaconf import DictConfig, OmegaConf

from ..tasks.base import BaseTask
from ..trainer import Trainer

logger = logging.getLogger(__name__)


class BaseLauncher(ABC):
    """Template Method: 统一 train/test 流程，差异在抽象方法里。"""

    def __init__(self, cfg: DictConfig):
        self.cfg = cfg
        self.task: Optional[BaseTask] = None
        self.train_loader = None
        self.val_loader = None
        self.test_loader = None
        self.trainer: Optional[Trainer] = None

    # ── 子类接口 ────────────────────────────────────────────
    @abstractmethod
    def build(self) -> Tuple[BaseTask, object, object, object]:
        """装配 task + train_loader + val_loader + test_loader."""

    def setup_env(self) -> None:
        """子类可设置环境变量 / 随机种子等。默认 no-op。"""
        pass

    def post_build(self, data_provider) -> None:
        """build() 之后的 hook（如设置 scaler_stats / feature_names）。默认 no-op。"""
        pass

    def _run_auto(self):
        """mode=auto 时的分支；默认报错，要用 AutoML 的 launcher 必须 override。"""
        raise NotImplementedError(
            f"{type(self).__name__} 未实现 AutoML（mode=auto）。"
            f"在该 launcher 的 yaml 里配置 `automl:` 字段并 override 本方法。"
        )

    def resolve_resume_path(self) -> Optional[str]:
        """resume=true 时尝试自动定位 checkpoint；默认不支持。"""
        return None

    # ── 通用 train/test 实现 ─────────────────────────────────
    def run(self):
        self.setup_env()

        mode = self.cfg.get("mode", "train")
        logger.info("=" * 60)
        logger.info(f"Launcher: {type(self).__name__} | mode={mode}")
        logger.info("=" * 60)
        logger.info("\n%s", OmegaConf.to_yaml(self.cfg))

        if mode == "auto":
            return self._run_auto()

        self.task, self.train_loader, self.val_loader, self.test_loader = self.build()
        self.trainer = Trainer(self.task, self.cfg)

        if mode == "train":
            self._run_train()
        elif mode == "test":
            self._run_test_only()
        else:
            raise ValueError(f"Unknown mode: {mode}")

        return self.trainer.best_val_loss if self.trainer else 0.0

    def _run_train(self):
        start_epoch = self._handle_resume()

        # 检查之前的 session 是否已完成训练（避免 retest 浪费一遍训练）
        training_done = self._check_training_already_done()
        if training_done:
            logger.info("Training already completed per training_state.json; skipping fit().")
        else:
            self.trainer.fit(
                self.train_loader, self.val_loader,
                epochs=self.cfg.training.epochs,
                start_epoch=start_epoch,
            )

        if self.cfg.training.get("test_after_train", True):
            self._load_best_and_test()

    def _run_test_only(self):
        ckpt_path = self.cfg.get("checkpoint_path", None)
        if ckpt_path:
            logger.info(f"Loading checkpoint: {ckpt_path}")
            self.task.load_checkpoint(ckpt_path)
        result = self.trainer.test(self.test_loader)
        logger.info(f"\nTest metrics: {result['metrics']}")

    # ── 辅助 ────────────────────────────────────────────────
    def _handle_resume(self) -> int:
        """执行 resume 逻辑；返回 start_epoch。"""
        start_epoch = 0
        resume_path = self.cfg.get("resume_path", None)
        if self.cfg.get("resume", False) and not resume_path:
            resume_path = self.resolve_resume_path()
            if resume_path:
                logger.info(f"Auto-detected incomplete run, resuming from: {resume_path}")
            else:
                logger.info("No incomplete run found, starting fresh.")

        if resume_path and os.path.exists(resume_path):
            # 把旧 run dir 的输出迁到当前 hydra run dir
            import shutil
            old_run_dir = os.path.dirname(os.path.dirname(resume_path))
            for item in os.listdir(old_run_dir):
                src = os.path.join(old_run_dir, item)
                dst = os.path.join(".", item)
                if os.path.isdir(src):
                    if os.path.exists(dst):
                        shutil.rmtree(dst)
                    shutil.copytree(src, dst)
                else:
                    shutil.copy2(src, dst)
            logger.info(f"Migrated outputs from: {old_run_dir}")
            shutil.rmtree(old_run_dir)

            local_ckpt = os.path.join("checkpoints", "checkpoint_last.pt")
            logger.info(f"Resuming from checkpoint: {local_ckpt}")
            ckpt = self.task.load_checkpoint(local_ckpt)
            start_epoch = ckpt.get("epoch", 0) + 1
            self.trainer.best_val_loss = ckpt.get("val_loss", float("inf"))
            logger.info(f"Resumed from epoch {start_epoch}, "
                        f"best_val_loss: {self.trainer.best_val_loss:.6f}")
        return start_epoch

    def _check_training_already_done(self) -> bool:
        state_path = "training_state.json"
        if not os.path.exists(state_path):
            return False
        try:
            import json
            with open(state_path, "r") as f:
                state = json.load(f)
            return bool(state.get("completed", False))
        except Exception:
            return False

    def _load_best_and_test(self):
        # 早停时内存里的权重是最后 epoch 而非 best，必须显式加载 best_model.pt 测试
        best_ckpt = os.path.join("checkpoints", "best_model.pt")
        if os.path.exists(best_ckpt):
            logger.info(f"Loading best checkpoint for test: {best_ckpt}")
            self.task.load_checkpoint(best_ckpt)
        result = self.trainer.test(self.test_loader)
        logger.info(f"\nTest metrics: {result['metrics']}")
