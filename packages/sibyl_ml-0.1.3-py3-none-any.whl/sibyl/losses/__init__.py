"""
Loss 模块
"""
from .pinn_loss import PINNLoss

__all__ = ['PINNLoss']
