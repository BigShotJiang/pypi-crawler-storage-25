"""
Physics-Informed Neural Network Loss
支持配置式和脚本式物理约束
"""
import os
import torch
import torch.nn as nn
import logging
from typing import Dict, Optional
from .physics_terms import PHYSICS_TERMS
from .script_loader import PhysicsScriptLoader

logger = logging.getLogger(__name__)


class PINNLoss(nn.Module):
    """
    物理信息损失函数：L_total = L_data + Σ λᵢ · L_physics_i

    支持两种模式：
    1. Config 模式：通过 physics_terms 配置内置约束
    2. Script 模式：加载用户自定义 Python 脚本
    """

    def __init__(self, data_loss='mse', physics_terms=None, script_path=None,
                 script_weights=None, **kwargs):
        super().__init__()

        config = {
            'data_loss': data_loss,
            'physics_terms': physics_terms or [],
            'script_path': script_path,
            'script_weights': script_weights or {},
        }

        # 数据损失
        data_loss_type = config.get('data_loss', 'mse')
        self.data_loss = self._build_data_loss(data_loss_type)

        # 内置物理约束项
        self.physics_modules = nn.ModuleDict()
        self.physics_weights = {}

        physics_terms = config.get('physics_terms', [])
        if physics_terms:
            for term_cfg in physics_terms:
                name = term_cfg.get('name', '')
                weight = term_cfg.get('weight', 1.0)
                term_type = term_cfg.get('type', name)

                if term_type in PHYSICS_TERMS:
                    # 提取该约束的参数（排除 name/weight/type）
                    term_kwargs = {k: v for k, v in term_cfg.items()
                                  if k not in ('name', 'weight', 'type')}
                    module = PHYSICS_TERMS[term_type](**term_kwargs)
                    self.physics_modules[name] = module
                    self.physics_weights[name] = weight
                    logger.info(f"PINN: added {name} (type={term_type}, weight={weight})")
                else:
                    logger.warning(f"PINN: unknown physics term type '{term_type}', skipping")

        # 脚本式约束
        self.script_func = None
        self.script_weights = {}
        script_path = config.get('script_path', None)
        if script_path and os.path.exists(script_path):
            self.script_func = PhysicsScriptLoader.load(script_path)
            self.script_weights = config.get('script_weights', {})
            logger.info(f"PINN: loaded script {script_path}")

        self._loss_details = {}

    @staticmethod
    def _build_data_loss(loss_type: str) -> nn.Module:
        losses = {
            'mse': nn.MSELoss(),
            'mae': nn.L1Loss(),
            'l1': nn.L1Loss(),
            'huber': nn.HuberLoss(),
            'smooth_l1': nn.SmoothL1Loss(),
        }
        return losses.get(loss_type, nn.MSELoss())

    def forward(self, pred, target, inputs=None):
        """
        Args:
            pred:    [batch, pred_len, features]
            target:  [batch, pred_len, features]
            inputs:  [batch, seq_len, features] (可选，物理约束可能需要)
        Returns:
            total_loss (scalar tensor)
        """
        self._loss_details = {}

        # 数据损失
        data_loss = self.data_loss(pred, target)
        self._loss_details['data_loss'] = data_loss.item()
        total_loss = data_loss

        # 内置物理约束
        for name, module in self.physics_modules.items():
            weight = self.physics_weights.get(name, 1.0)
            term_loss = module(pred, target, inputs)
            self._loss_details[name] = term_loss.item()
            total_loss = total_loss + weight * term_loss

        # 脚本式约束
        if self.script_func is not None:
            try:
                script_losses = self.script_func(pred, target, inputs, None)
                for name, loss_val in script_losses.items():
                    weight = self.script_weights.get(name, 1.0)
                    if isinstance(loss_val, torch.Tensor):
                        self._loss_details[f'script_{name}'] = loss_val.item()
                        total_loss = total_loss + weight * loss_val
            except Exception as e:
                logger.warning(f"PINN script error: {e}")

        self._loss_details['total_loss'] = total_loss.item()
        return total_loss

    def get_loss_details(self) -> Dict[str, float]:
        """获取各项损失的详细值（用于日志记录）"""
        return self._loss_details.copy()
