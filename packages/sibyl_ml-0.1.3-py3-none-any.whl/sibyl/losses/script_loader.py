"""
动态加载用户自定义物理约束脚本

安全说明：`load()` 会执行指定路径下的任意 Python 代码。
调用方应确保 `script_path` 来自可信来源（项目自带的 `src/losses/scripts/`
或受控配置）。生产环境不应让外部用户自由指定此路径。
"""
import importlib.util
import inspect
import logging
import os

logger = logging.getLogger(__name__)


class PhysicsScriptLoader:
    """加载用户编写的物理约束脚本"""

    @staticmethod
    def load(script_path: str):
        """
        加载脚本中的 physics_loss 函数
        Args:
            script_path: Python 脚本路径
        Returns:
            physics_loss 函数
        """
        # 入参校验
        if not isinstance(script_path, str) or not script_path:
            raise ValueError(f"script_path 必须是非空字符串，得到 {script_path!r}")
        if not script_path.endswith('.py'):
            raise ValueError(f"script_path 必须是 .py 文件，得到 {script_path!r}")
        if not os.path.isfile(script_path):
            raise FileNotFoundError(f"physics script 不存在: {script_path}")

        abs_path = os.path.abspath(script_path)
        logger.warning(
            f"Executing user physics script: {abs_path} "
            "(arbitrary code execution; ensure source is trusted)"
        )

        spec = importlib.util.spec_from_file_location("user_physics", abs_path)
        if spec is None or spec.loader is None:
            raise ImportError(f"无法从 {abs_path} 创建模块 spec")
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)

        if not hasattr(module, 'physics_loss'):
            raise AttributeError(
                f"Script {script_path} must define a 'physics_loss' function. "
                f"Signature: physics_loss(pred, target, inputs, config) -> dict"
            )

        func = module.physics_loss

        # Validate signature
        sig = inspect.signature(func)
        params = list(sig.parameters.keys())
        if len(params) < 4:
            logger.warning(
                f"physics_loss has {len(params)} params, expected 4 (pred, target, inputs, config)"
            )

        return func
