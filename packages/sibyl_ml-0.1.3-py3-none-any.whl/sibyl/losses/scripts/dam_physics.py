"""
大坝物理约束脚本示例

函数签名: physics_loss(pred, target, inputs, config) -> dict
返回: {约束名: loss_tensor, ...}
"""
import torch


def physics_loss(pred, target, inputs, config):
    losses = {}

    # 热传导方程: dT/dt ≈ α · d²T/dx²
    # 假设 feature 3+ 是传感器数据
    if pred.shape[-1] > 3:
        sensors = pred[:, :, 3:]
        dT_dt = sensors[:, 1:] - sensors[:, :-1]
        d2T_dx2 = sensors[:, :, 2:] - 2 * sensors[:, :, 1:-1] + sensors[:, :, :-2]

        if dT_dt.shape[1] > 0 and d2T_dx2.shape[1] > 0 and d2T_dx2.shape[2] > 0:
            min_t = min(dT_dt.shape[1], d2T_dx2.shape[1])
            min_f = min(dT_dt.shape[2], d2T_dx2.shape[2])
            alpha = 0.01
            losses['heat_equation'] = (
                (dT_dt[:, :min_t, :min_f] - alpha * d2T_dx2[:, :min_t, :min_f]) ** 2
            ).mean()

    # 水位-传感器响应: 传感器均值应与水位正相关
    if pred.shape[-1] > 3:
        water = pred[:, :, 0:1]
        sensor_mean = pred[:, :, 3:].mean(dim=-1, keepdim=True)
        if water.shape[1] > 1:
            losses['hydro_response'] = torch.relu(
                -torch.cosine_similarity(water, sensor_mean, dim=1)
            ).mean()

    return losses
