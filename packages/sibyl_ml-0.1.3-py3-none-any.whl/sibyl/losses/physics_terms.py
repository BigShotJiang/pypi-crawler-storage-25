"""
内置物理约束项
"""
import torch
import torch.nn as nn


class TemporalSmoothness(nn.Module):
    """时间平滑性约束: L = ||d^n(pred)/dt^n||²"""

    def __init__(self, order: int = 1):
        super().__init__()
        self.order = order

    def forward(self, pred, target=None, inputs=None):
        x = pred
        for _ in range(self.order):
            x = x[:, 1:] - x[:, :-1]
        return (x ** 2).mean()


class SpatialConsistency(nn.Module):
    """空间一致性约束: L = Σ ||pred_i - pred_j||² for neighbor pairs"""

    def __init__(self, neighbor_pairs='auto'):
        super().__init__()
        self.neighbor_pairs = neighbor_pairs

    def _get_pairs(self, n_features):
        if self.neighbor_pairs == 'auto':
            return [(i, i + 1) for i in range(n_features - 1)]
        return self.neighbor_pairs

    def forward(self, pred, target=None, inputs=None):
        pairs = self._get_pairs(pred.shape[-1])
        loss = torch.tensor(0.0, device=pred.device)
        for i, j in pairs:
            loss = loss + ((pred[:, :, i] - pred[:, :, j]) ** 2).mean()
        return loss / max(len(pairs), 1)


class PhysicalBounds(nn.Module):
    """物理范围约束: L = relu(pred - max)² + relu(min - pred)²"""

    def __init__(self, min_val: float = 0.0, max_val: float = 100.0):
        super().__init__()
        self.min_val = min_val
        self.max_val = max_val

    def forward(self, pred, target=None, inputs=None):
        upper = torch.relu(pred - self.max_val) ** 2
        lower = torch.relu(self.min_val - pred) ** 2
        return (upper + lower).mean()


class Monotonicity(nn.Module):
    """单调性约束: 惩罚违反单调性的变化"""

    def __init__(self, direction: str = 'increasing', features: list = None):
        super().__init__()
        self.direction = direction
        self.features = features

    def forward(self, pred, target=None, inputs=None):
        if self.features:
            x = pred[:, :, self.features]
        else:
            x = pred

        diff = x[:, 1:] - x[:, :-1]

        if self.direction == 'increasing':
            violation = torch.relu(-diff)
        else:
            violation = torch.relu(diff)

        return (violation ** 2).mean()


class Conservation(nn.Module):
    """守恒律约束: L = (Σ pred_features - target_sum)²"""

    def __init__(self, features: list = None, target_sum: float = None):
        super().__init__()
        self.features = features
        self.target_sum = target_sum

    def forward(self, pred, target=None, inputs=None):
        if self.features:
            x = pred[:, :, self.features]
        else:
            x = pred

        current_sum = x.sum(dim=-1)

        if self.target_sum is not None:
            ref = self.target_sum
        elif inputs is not None:
            if self.features:
                ref = inputs[:, -1:, self.features].sum(dim=-1)
            else:
                ref = inputs[:, -1:, :].sum(dim=-1)
        else:
            ref = current_sum.detach().mean()

        return ((current_sum - ref) ** 2).mean()


class DerivativeConstraint(nn.Module):
    """通用导数约束: L = ||d^n(pred)/dt^n - target_value||²"""

    def __init__(self, order: int = 1, target_value: float = 0.0):
        super().__init__()
        self.order = order
        self.target_value = target_value

    def forward(self, pred, target=None, inputs=None):
        x = pred
        for _ in range(self.order):
            x = x[:, 1:] - x[:, :-1]
        return ((x - self.target_value) ** 2).mean()


# Registry for easy lookup
PHYSICS_TERMS = {
    'temporal_smoothness': TemporalSmoothness,
    'spatial_consistency': SpatialConsistency,
    'physical_bounds': PhysicalBounds,
    'monotonicity': Monotonicity,
    'conservation': Conservation,
    'derivative': DerivativeConstraint,
}
