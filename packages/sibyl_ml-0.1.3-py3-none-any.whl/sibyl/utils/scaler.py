"""
归一化工具
"""
import torch
import numpy as np
from typing import Tuple, Optional


class StandardScaler:
    """标准化（Z-score）"""

    def __init__(self, mean: Optional[torch.Tensor] = None,
                 std: Optional[torch.Tensor] = None):
        self.mean = mean
        self.std = std

    def fit(self, data: torch.Tensor) -> None:
        """计算均值和标准差"""
        self.mean = data.mean(dim=(0, 1), keepdim=True)
        self.std = data.std(dim=(0, 1), keepdim=True)

    def transform(self, data: torch.Tensor) -> torch.Tensor:
        """标准化数据"""
        if self.mean is None or self.std is None:
            raise ValueError("Scaler not fitted. Call fit() first.")
        return (data - self.mean) / (self.std + 1e-8)

    def inverse_transform(self, data: torch.Tensor) -> torch.Tensor:
        """反标准化数据"""
        if self.mean is None or self.std is None:
            raise ValueError("Scaler not fitted.")
        return data * self.std + self.mean

    def get_stats(self) -> Tuple[torch.Tensor, torch.Tensor]:
        """获取归一化统计量"""
        return self.mean, self.std


class MinMaxScaler:
    """最小-最大归一化"""

    def __init__(self, min_val: Optional[torch.Tensor] = None,
                 max_val: Optional[torch.Tensor] = None):
        self.min_val = min_val
        self.max_val = max_val

    def fit(self, data: torch.Tensor) -> None:
        """计算最小值和最大值"""
        self.min_val = data.amin(dim=(0, 1), keepdim=True)
        self.max_val = data.amax(dim=(0, 1), keepdim=True)

    def transform(self, data: torch.Tensor) -> torch.Tensor:
        """归一化到 [0, 1]"""
        if self.min_val is None or self.max_val is None:
            raise ValueError("Scaler not fitted. Call fit() first.")
        range_val = self.max_val - self.min_val + 1e-8
        return (data - self.min_val) / range_val

    def inverse_transform(self, data: torch.Tensor) -> torch.Tensor:
        """反归一化"""
        if self.min_val is None or self.max_val is None:
            raise ValueError("Scaler not fitted.")
        range_val = self.max_val - self.min_val + 1e-8
        return data * range_val + self.min_val

    def get_stats(self) -> Tuple[torch.Tensor, torch.Tensor]:
        """获取统计量"""
        return self.min_val, self.max_val


def get_scaler(name: str) -> object:
    """获取 Scaler 实例"""
    scalers = {
        'standard': StandardScaler,
        'minmax': MinMaxScaler
    }

    if name not in scalers:
        raise ValueError(f"Unknown scaler: {name}. Available: {list(scalers.keys())}")

    return scalers[name]()
