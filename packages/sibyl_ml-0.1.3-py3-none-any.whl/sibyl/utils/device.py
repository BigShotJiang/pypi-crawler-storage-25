"""
设备工具
"""
import torch
import random
import numpy as np


def get_device(use_gpu: bool = True, gpu_id: int = 0) -> torch.device:
    """
    获取设备
    Args:
        use_gpu: 是否使用 GPU
        gpu_id: GPU ID
    Returns:
        torch.device
    """
    if use_gpu:
        if torch.cuda.is_available():
            device = torch.device(f'cuda:{gpu_id}')
            print(f'Using GPU: cuda:{gpu_id}')
            return device
        elif torch.backends.mps.is_available():
            device = torch.device('mps')
            print('Using GPU: mps')
            return device

    device = torch.device('cpu')
    print('Using CPU')
    return device


def set_random_seed(seed: int):
    """设置随机种子。

    顺序严格对齐 TSL (Time-Series-Library) run.py 的 random → torch → numpy，
    保证 FourierBlock 等处的 `np.random.shuffle` 选出与 TSL 相同的频率索引。
    """
    random.seed(seed)
    torch.manual_seed(seed)
    np.random.seed(seed)

    if torch.cuda.is_available():
        torch.cuda.manual_seed(seed)
        torch.cuda.manual_seed_all(seed)
        torch.backends.cudnn.deterministic = True
        torch.backends.cudnn.benchmark = False


def count_parameters(model: torch.nn.Module) -> int:
    """
    统计模型参数量
    Args:
        model: 模型
    Returns:
        参数数量
    """
    return sum(p.numel() for p in model.parameters() if p.requires_grad)


def get_model_size(model: torch.nn.Module) -> float:
    """
    获取模型大小（MB）
    Args:
        model: 模型
    Returns:
        模型大小（MB）
    """
    param_size = sum(p.numel() * p.element_size() for p in model.parameters())
    buffer_size = sum(b.numel() * b.element_size() for b in model.buffers())
    return (param_size + buffer_size) / (1024 ** 2)
