"""Drop-in monitoring callback — zero-touch experiment-monitor integration (v0.3).

Recommended replacement for the legacy :class:`~sibyl.callbacks.reporter.Reporter`
callback. Add to any experiment's ``callbacks:`` list and the platform will
emit ``batch_start`` / ``epoch_end`` / ``job_done`` events plus run heartbeat,
stop-signal polling, resource-snapshot daemons, env snapshot, and artifact
upload — without touching training loops, schedulers, or task code.

Usage::

    # configs/<experiment>.yaml or configs/config.yaml
    defaults:
      - override /callbacks: [..., monitor]

    # or list-style (any experiment yaml)
    callbacks:
      - model_checkpoint
      - early_stopping
      - monitor          # <- one extra entry, that's it

When ``configs/monitor.yaml`` is missing or ``enabled: false``, every
hook silently no-ops so leaving the callback in is always safe; the same
guard protects against missing ``experiment_reporter`` installs and network
outages.

Backend URL + auth token resolution (sibyl-ml v0.1.2+): the loader at
:mod:`scripts.common.monitor_reporter` reads ``url`` / ``token`` from
the yaml first, then falls back to the env vars ``ARGUS_URL`` /
``ARGUS_TOKEN``. The legacy ``MONITOR_URL`` / ``MONITOR_TOKEN`` names
still resolve through :mod:`scripts.common._argus_env` but each emits
a one-shot ``DeprecationWarning``; both legacy names are scheduled
for removal in v0.2.

Behaviour matrix
----------------
``on_train_begin``
    * Picks a batch_id (env > new) and a job_id (env > experiment_name).
    * Emits ``batch_start`` (only if we minted a fresh batch_id — child
      processes spawned by ``run_benchmark`` / ``run_sweep`` inherit the
      parent's batch and skip this).
    * Emits ``job_start`` carrying ``model`` + ``dataset`` derived from the
      Hydra config.
    * Spawns the heartbeat + stop-poller + 30 s resource-snapshot daemons.
    * Records ``self._owns_batch`` so ``on_train_end`` knows whether to
      close the batch.

``on_epoch_end(epoch, train_loss, val_metrics)``
    * Emits ``job_epoch`` with ``epoch`` + every numeric ``val_*``.

``should_stop()``
    * Proxies the stop poller; ``Trainer._check_early_stopping`` queries
      this on every epoch boundary.

``on_test_end(result)``
    * Emits ``job_done`` with the test ``metrics`` (numeric only) plus the
      derived ``setting`` string and ``seed``.
    * Discovers ``<run_dir>/visualizations/*.png`` and uploads them as
      artifacts (best-effort; failures are silent).

``on_train_end``
    * Stops the resource-snapshot daemon thread.
    * If ``self._owns_batch``, emits ``batch_done`` with whatever counters
      were observed during the run.

Exception path (no dedicated hook in BaseCallback yet)
------------------------------------------------------
``Trainer.fit`` / ``Trainer.test`` are wrapped by ``main.py`` which logs
the exception via Hydra. There's no callback hook for failure today, so a
crash mid-train leaves the Reporter in an "unfinished" state on the
monitor side — a future stalled-batch detector picks it up. We do *not*
register an ``atexit`` handler here because callbacks are owned by the
Trainer instance, which Hydra may rebuild for each run.
"""
from __future__ import annotations

import logging
import os
import sys
import threading
import time
from pathlib import Path
from typing import Any, Mapping, Optional

from .base import BaseCallback

# scripts/ isn't on sys.path until main.py adds it — replicate that here
# in case Trainer instantiates a callback before main.py's setup runs.
_PROJECT_ROOT = os.environ.get("PROJECT_ROOT")
if _PROJECT_ROOT and _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)

try:
    from scripts.common.monitor_reporter import (
        emit, current_batch_id, current_job_id,
        new_batch_id, set_batch_id, _load_cfg as _load_monitor_cfg,
    )
except Exception:  # pragma: no cover — defensive, every hook degrades to noop
    def emit(*_, **__): pass  # type: ignore[misc]
    def current_batch_id(): return None  # type: ignore[misc]
    def current_job_id(): return None  # type: ignore[misc]
    def new_batch_id(prefix: str = "batch") -> str: return f"{prefix}-local"  # type: ignore[misc]
    def set_batch_id(_b: str) -> None: pass  # type: ignore[misc]
    def _load_monitor_cfg(): return None  # type: ignore[misc]

try:
    from scripts.common.resource_snapshot import collect_resource_snapshot
except Exception:  # pragma: no cover
    def collect_resource_snapshot() -> dict: return {}  # type: ignore[misc]

try:
    from scripts.common.heartbeat import start as _hb_start, stop as _hb_stop
except Exception:  # pragma: no cover
    def _hb_start(*_, **__): pass  # type: ignore[misc]
    def _hb_stop(): pass  # type: ignore[misc]

try:
    from scripts.common.stop_poller import is_stop_requested, start_polling
except Exception:  # pragma: no cover
    def is_stop_requested() -> bool: return False  # type: ignore[misc]
    def start_polling(*_, **__): return None  # type: ignore[misc]

try:
    from scripts.common.artifact_upload import (
        discover_visualizations, upload_many,
    )
except Exception:  # pragma: no cover
    def discover_visualizations(_): return []  # type: ignore[misc]
    def upload_many(*_, **__): return 0  # type: ignore[misc]

try:
    from scripts.common.env_snapshot import collect_env_snapshot
except Exception:  # pragma: no cover
    def collect_env_snapshot(**_): return {}  # type: ignore[misc]

try:
    from scripts.common.log_capture import install as _install_log_capture
except Exception:  # pragma: no cover
    def _install_log_capture(*_, **__): return None  # type: ignore[misc]

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Helpers — every getter is defensive; missing config keys never raise.
# ---------------------------------------------------------------------------

def _cfg_get(cfg: Any, key: str, default: Any = None) -> Any:
    """Read ``key`` off either a dict or a DictConfig / namespace."""
    if cfg is None:
        return default
    if hasattr(cfg, "get"):
        try:
            return cfg.get(key, default)
        except Exception:
            pass
    return getattr(cfg, key, default)


def _resolve_run_dir() -> str:
    """Best-effort run-dir lookup: HYDRA_RUN_DIR > cwd."""
    return os.environ.get("HYDRA_RUN_DIR") or os.getcwd()


# ---------------------------------------------------------------------------
# Monitor callback
# ---------------------------------------------------------------------------

class Monitor(BaseCallback):
    """Drop-in monitoring callback. See module docstring for details."""

    def __init__(self, task, config):
        super().__init__(task, config)

        # Resolve config: experiment-level overrides take precedence over
        # the global ``monitor:`` block. Both are optional.
        mc = _cfg_get(self.config, "monitor", {}) or {}
        self._batch_prefix: str = str(_cfg_get(mc, "batch_prefix", "batch"))
        self._experiment_type: str = str(
            _cfg_get(mc, "experiment_type", "generic")
        )
        self._snapshot_interval: float = float(
            _cfg_get(mc, "snapshot_interval", 30.0)
        )
        self._upload_visualizations: bool = bool(
            _cfg_get(mc, "upload_visualizations", True)
        )

        # Will be set in on_train_begin().
        self._batch_id: Optional[str] = None
        self._job_id: Optional[str] = None
        self._owns_batch: bool = False
        self._train_t0: Optional[float] = None
        self._epochs_seen: int = 0

        # Resource-snapshot daemon plumbing.
        self._snap_stop = threading.Event()
        self._snap_thread: Optional[threading.Thread] = None

    # -- helpers -----------------------------------------------------------

    def _resolve_batch_id(self) -> str:
        """Inherit parent's batch_id, otherwise mint one and own it."""
        existing = current_batch_id()
        if existing:
            self._owns_batch = False
            return existing
        bid = new_batch_id(self._batch_prefix)
        set_batch_id(bid)
        self._owns_batch = True
        return bid

    def _resolve_job_id(self) -> str:
        """Inherit parent's job_id, otherwise default to experiment_name."""
        existing = current_job_id()
        if existing:
            return existing
        # Default: experiment_name from the Hydra config (always present).
        return str(_cfg_get(self.config, "experiment_name", "job"))

    def _infer_model_dataset(self) -> tuple[Optional[str], Optional[str]]:
        model_name = _cfg_get(_cfg_get(self.config, "model"), "name")
        ds_name = _cfg_get(_cfg_get(self.config, "data_loader"), "name")
        return (str(model_name) if model_name else None,
                str(ds_name) if ds_name else None)

    def _start_daemons(self) -> None:
        """Heartbeat + stop poller + resource-snapshot daemon. Idempotent."""
        # Heartbeat (best-effort; idempotent).
        try:
            _hb_start()
        except Exception:
            pass

        # Stop poller (against the resolved batch_id).
        try:
            mcfg = _load_monitor_cfg()
        except Exception:
            mcfg = None
        if mcfg and self._batch_id:
            url = mcfg.get("url")
            token = mcfg.get("token")
            interval = int(mcfg.get("stop_poll_interval", 10))
            if url and token:
                try:
                    start_polling(url, self._batch_id, token, interval=interval)
                except Exception:
                    pass

        # Resource-snapshot daemon.
        if self._snapshot_interval > 0 and self._snap_thread is None:
            def _loop() -> None:
                while not self._snap_stop.wait(timeout=self._snapshot_interval):
                    try:
                        snap = collect_resource_snapshot()
                        if snap:
                            emit("resource_snapshot", **snap)
                    except Exception as exc:  # pragma: no cover — defensive
                        logger.debug("resource_snapshot loop: %s", exc)

            self._snap_thread = threading.Thread(
                target=_loop,
                daemon=True,
                name="monitor-callback-resource-snapshot",
            )
            self._snap_thread.start()

    def _stop_daemons(self) -> None:
        self._snap_stop.set()
        if self._snap_thread is not None:
            try:
                self._snap_thread.join(timeout=5)
            except Exception:
                pass
        # Heartbeat is process-wide; let it die with the process to stay
        # idempotent across multi-experiment runs in the same process.

    # -- BaseCallback hooks ------------------------------------------------

    def on_train_begin(self):
        self._train_t0 = time.time()
        self._batch_id = self._resolve_batch_id()
        self._job_id = self._resolve_job_id()

        # Make the resolved job_id discoverable to other callbacks (e.g.
        # the legacy reporter callback if both are wired in).
        if self._job_id:
            os.environ.setdefault("EXPERIMENT_MONITOR_JOB_ID", self._job_id)

        if self._owns_batch:
            command = " ".join(sys.argv)
            emit(
                "batch_start",
                experiment_type=self._experiment_type,
                n_total=1,
                command=command,
                batch_id=self._batch_id,
            )

        model, dataset = self._infer_model_dataset()
        emit("job_start", job_id=self._job_id, model=model, dataset=dataset)

        # One-shot env snapshot for reproducibility.
        try:
            snap = collect_env_snapshot()
            if snap:
                emit("env_snapshot", job_id=self._job_id, **snap)
        except Exception:
            pass

        # Capture WARNING+ records into the monitor logs tab.
        try:
            _install_log_capture(job_id=self._job_id)
        except Exception:
            pass

        self._start_daemons()

    def should_stop(self) -> bool:
        """Trainer._check_early_stopping reads this at every epoch boundary."""
        try:
            return bool(is_stop_requested())
        except Exception:
            return False

    def on_epoch_end(self, epoch, train_loss, val_metrics):
        if not self._job_id:
            return
        self._epochs_seen = max(self._epochs_seen, int(epoch) + 1)

        payload: dict[str, Any] = {"epoch": int(epoch)}
        try:
            payload["train_loss"] = float(train_loss)
        except (TypeError, ValueError):
            pass

        if isinstance(val_metrics, Mapping):
            for k, v in val_metrics.items():
                if k in {"epoch_time", "eta_seconds", "elapsed"}:
                    continue
                try:
                    payload[k] = float(v)
                except (TypeError, ValueError):
                    continue

        emit("job_epoch", job_id=self._job_id, **payload)

        # One snapshot at epoch boundary mirrors the per-epoch cadence the
        # legacy reporter callback used; the 30 s daemon covers gaps.
        try:
            snap = collect_resource_snapshot()
            if snap:
                emit("resource_snapshot", **snap)
        except Exception:
            pass

    def on_test_end(self, result):
        if not self._job_id:
            return
        metrics = result.get("metrics", {}) if isinstance(result, dict) else {}
        clean_metrics: dict[str, Any] = {}
        for k, v in metrics.items():
            try:
                clean_metrics[k] = float(v)
            except (TypeError, ValueError):
                continue

        # Inject seed for reproducibility column on the leaderboard.
        seed = self._extract_seed()
        if seed is not None:
            try:
                clean_metrics["seed"] = float(seed)
            except (TypeError, ValueError):
                pass

        # Inject the canonical Setting string when the helper is available.
        try:
            from scripts.common.setting_name import compute_setting_name
            clean_metrics["setting"] = compute_setting_name(self.config)
        except Exception:
            pass

        elapsed = (
            int(time.time() - self._train_t0)
            if self._train_t0 is not None else None
        )
        emit(
            "job_done",
            job_id=self._job_id,
            metrics=clean_metrics,
            elapsed_s=elapsed,
            train_epochs=self._epochs_seen,
            status="DONE",
        )

        if self._upload_visualizations:
            self._do_upload_visualizations()

    def on_train_end(self):
        # Stop the snapshot daemon first so we don't race with batch_done.
        self._stop_daemons()
        if self._owns_batch and self._batch_id:
            elapsed = (
                int(time.time() - self._train_t0)
                if self._train_t0 is not None else None
            )
            emit(
                "batch_done",
                n_done=1,
                n_failed=0,
                total_elapsed_s=elapsed,
            )
            self._owns_batch = False  # don't double-emit if hook fires twice

    # -- internals ---------------------------------------------------------

    def _extract_seed(self) -> Any:
        try:
            training = _cfg_get(self.config, "training", {}) or {}
            v = _cfg_get(training, "seed")
            if v is None:
                v = _cfg_get(self.config, "seed")
            return v
        except Exception:
            return None

    def _do_upload_visualizations(self) -> None:
        """Best-effort artifact upload of <run_dir>/visualizations/*.png."""
        try:
            mcfg = _load_monitor_cfg()
        except Exception:
            mcfg = None
        if not mcfg:
            return
        url = mcfg.get("url")
        token = mcfg.get("token")
        if not url or not token or not self._job_id:
            return
        try:
            paths = discover_visualizations(_resolve_run_dir())
            if not paths:
                return
            n_ok = upload_many(url, self._job_id, token, paths, kind="image")
            logger.debug(
                "monitor: uploaded %d/%d visualization artifacts for job %s",
                n_ok, len(paths), self._job_id,
            )
        except Exception:
            pass


__all__ = ["Monitor"]
