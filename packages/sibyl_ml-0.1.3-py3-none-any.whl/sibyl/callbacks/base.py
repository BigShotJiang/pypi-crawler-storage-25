"""
Callbacks 基类
"""
from abc import ABC, abstractmethod


class BaseCallback(ABC):
    """回调函数基类"""

    def __init__(self, task, config):
        """
        Args:
            task: 任务实例
            config: 配置字典
        """
        self.task = task
        self.config = config

    def on_train_begin(self):
        """训练开始时调用"""
        pass

    def on_train_end(self):
        """训练结束时调用"""
        pass

    def on_epoch_end(self, epoch, train_loss, val_metrics):
        """每个 epoch 结束时调用"""
        pass

    def on_test_begin(self):
        """测试开始时调用"""
        pass

    def on_test_end(self, result):
        """测试结束时调用
        Args:
            result: 测试结果字典
        """
        pass
