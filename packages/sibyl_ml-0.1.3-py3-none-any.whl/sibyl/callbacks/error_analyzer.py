"""
Error Analyzer callback - prediction error analysis and visualization
"""
import os
import numpy as np
import matplotlib.pyplot as plt
import torch
from .base import BaseCallback

# Apply plot style with fallback
try:
    plt.style.use('seaborn-v0_8-whitegrid')
except OSError:
    try:
        plt.style.use('seaborn-whitegrid')
    except OSError:
        pass


class ErrorAnalyzer(BaseCallback):
    """Prediction error analysis: distributions, horizon degradation, per-feature breakdown"""

    def __init__(self, task, config):
        super().__init__(task, config)

    def on_test_end(self, result):
        """Analyze prediction errors and save plots + CSVs to analysis/ directory."""
        output_dir = self.config.get('output_dir', '.')
        analysis_dir = os.path.join(output_dir, 'analysis')
        os.makedirs(analysis_dir, exist_ok=True)

        predictions = result['predictions']
        targets = result['targets']

        # Inverse normalize if scaler stats are available
        if self.task.scaler_stats:
            predictions = self._inverse_normalize(predictions)
            targets = self._inverse_normalize(targets)

        # Convert to numpy (handle both tensor and ndarray inputs)
        preds_np = self._to_numpy(predictions)
        trues_np = self._to_numpy(targets)

        self._plot_error_distribution(preds_np, trues_np, analysis_dir)
        self._plot_horizon_analysis(preds_np, trues_np, analysis_dir)
        self._save_horizon_csv(preds_np, trues_np, analysis_dir)
        self._plot_feature_analysis(preds_np, trues_np, analysis_dir)
        self._save_feature_csv(preds_np, trues_np, analysis_dir)
        self._plot_error_heatmap(preds_np, trues_np, analysis_dir)

        print(f"Error analysis saved to: {analysis_dir}")

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _to_numpy(self, data):
        """Convert tensor or ndarray to float32 numpy array."""
        if isinstance(data, torch.Tensor):
            return data.cpu().numpy().astype(np.float32)
        return np.asarray(data, dtype=np.float32)

    def _inverse_normalize(self, data):
        """Reverse mean/std normalization stored in task.scaler_stats.
        当 c_out != enc_in 时 mean/std 的特征维大于 data，截取前 C 列对齐。
        """
        if self.task.scaler_stats is None:
            return data
        mean = self.task.scaler_stats['mean']
        std = self.task.scaler_stats['std']
        if hasattr(data, 'shape') and hasattr(mean, 'shape') and \
                len(mean.shape) >= 1 and mean.shape[-1] != data.shape[-1]:
            C = data.shape[-1]
            mean = mean[..., :C]
            std = std[..., :C]
        return data * std + mean

    @staticmethod
    def _mae(errors):
        return np.mean(np.abs(errors), axis=0)

    @staticmethod
    def _mse(errors):
        return np.mean(errors ** 2, axis=0)

    # ------------------------------------------------------------------
    # Plot 1: error distribution histogram
    # ------------------------------------------------------------------

    def _plot_error_distribution(self, preds, trues, save_dir):
        """Histogram of all prediction errors with mean/std annotation."""
        errors = (preds - trues).flatten()
        mu = float(np.mean(errors))
        sigma = float(np.std(errors))

        fig, ax = plt.subplots(figsize=(7, 4))
        ax.hist(errors, bins=60, color='steelblue', edgecolor='white', alpha=0.85)
        ax.axvline(mu, color='crimson', linewidth=1.5, linestyle='--', label=f'Mean = {mu:.4f}')
        ax.axvline(mu + sigma, color='orange', linewidth=1.2, linestyle=':', label=f'+1σ = {mu + sigma:.4f}')
        ax.axvline(mu - sigma, color='orange', linewidth=1.2, linestyle=':', label=f'-1σ = {mu - sigma:.4f}')
        ax.set_xlabel('Prediction Error (pred - true)', fontsize=11)
        ax.set_ylabel('Count', fontsize=11)
        ax.set_title('Error Distribution', fontsize=12)
        ax.tick_params(axis='both', labelsize=10)
        ax.legend(fontsize=10)
        ax.annotate(
            f'mean={mu:.4f}\nstd={sigma:.4f}',
            xy=(0.97, 0.95), xycoords='axes fraction',
            ha='right', va='top', fontsize=9,
            bbox=dict(boxstyle='round,pad=0.3', facecolor='white', alpha=0.7),
        )
        plt.tight_layout()
        plt.savefig(os.path.join(save_dir, 'error_distribution.png'), dpi=300, bbox_inches='tight')
        plt.close()

    # ------------------------------------------------------------------
    # Plot 2 + CSV: MAE per prediction horizon step
    # ------------------------------------------------------------------

    def _plot_horizon_analysis(self, preds, trues, save_dir):
        """Line plot of MAE at each prediction step."""
        # preds shape: [n_samples, pred_len, n_features]
        errors = preds - trues                           # [n, pred_len, feat]
        mae_per_step = np.mean(np.abs(errors), axis=(0, 2))   # [pred_len]
        steps = np.arange(1, len(mae_per_step) + 1)

        fig, ax = plt.subplots(figsize=(7, 3.5))
        ax.plot(steps, mae_per_step, marker='o', markersize=3.5,
                color='steelblue', linewidth=1.8, label='MAE')
        ax.set_xlabel('Prediction Step', fontsize=11)
        ax.set_ylabel('MAE', fontsize=11)
        ax.set_title('Horizon Analysis: MAE vs Prediction Step', fontsize=12)
        ax.tick_params(axis='both', labelsize=10)
        ax.grid(True, alpha=0.25, linestyle=':')
        ax.legend(fontsize=10)
        plt.tight_layout()
        plt.savefig(os.path.join(save_dir, 'horizon_analysis.png'), dpi=300, bbox_inches='tight')
        plt.close()

    def _save_horizon_csv(self, preds, trues, save_dir):
        """CSV: step, MAE, MSE, RMSE for each prediction step."""
        errors = preds - trues                               # [n, pred_len, feat]
        # reduce over samples and features
        mae = np.mean(np.abs(errors), axis=(0, 2))          # [pred_len]
        mse = np.mean(errors ** 2, axis=(0, 2))             # [pred_len]
        rmse = np.sqrt(mse)
        steps = np.arange(1, len(mae) + 1)

        rows = ['step,MAE,MSE,RMSE']
        for s, m, ms, r in zip(steps, mae, mse, rmse):
            rows.append(f'{s},{m:.6f},{ms:.6f},{r:.6f}')

        with open(os.path.join(save_dir, 'horizon_analysis.csv'), 'w') as f:
            f.write('\n'.join(rows))

    # ------------------------------------------------------------------
    # Plot 3 + CSV: per-feature MAE horizontal bar chart
    # ------------------------------------------------------------------

    def _plot_feature_analysis(self, preds, trues, save_dir):
        """Horizontal bar chart of MAE per feature, sorted by error.

        特征数 > 30 时只画 top-30（按误差降序），避免图过高；完整数据在 CSV 里。
        论文尺寸：≤ 8×6 inches @ 300 dpi。
        """
        errors = preds - trues
        mae_per_feat = np.mean(np.abs(errors), axis=(0, 1))
        n_features = len(mae_per_feat)
        task_fn = getattr(self.task, 'feature_names', None)
        if task_fn and len(task_fn) >= n_features:
            feature_labels = list(task_fn[:n_features])
        else:
            feature_labels = [f'F{i}' for i in range(n_features)]

        # 排序：降序（top-N 逻辑取前 N 个 MAE 最大的）
        order_desc = np.argsort(mae_per_feat)[::-1]
        max_show = 30
        truncated = n_features > max_show
        shown = order_desc[:max_show] if truncated else order_desc
        # 画图时按升序排（最小 MAE 在最下方）
        shown_sorted = shown[np.argsort(mae_per_feat[shown])]
        bars_mae = mae_per_feat[shown_sorted]
        bars_labels = [feature_labels[i] for i in shown_sorted]

        n_bars = len(bars_mae)
        fig_height = min(6.0, max(3.0, n_bars * 0.22 + 1))
        fig, ax = plt.subplots(figsize=(7, fig_height))
        bars = ax.barh(bars_labels, bars_mae, color='steelblue', alpha=0.85)
        ax.set_xlabel('MAE', fontsize=12)
        title = 'Feature Analysis: MAE per Feature'
        if truncated:
            title += f' (Top {max_show}/{n_features})'
        ax.set_title(title, fontsize=13)
        ax.tick_params(axis='both', labelsize=10)
        ax.bar_label(bars, fmt='%.4f', padding=3, fontsize=9)
        plt.tight_layout()
        plt.savefig(os.path.join(save_dir, 'feature_analysis.png'), dpi=300, bbox_inches='tight')
        plt.close()

    def _save_feature_csv(self, preds, trues, save_dir):
        """CSV: feature_idx, feature_name, MAE, MSE, RMSE for each feature."""
        errors = preds - trues                               # [n, pred_len, feat]
        mae = np.mean(np.abs(errors), axis=(0, 1))          # [feat]
        mse = np.mean(errors ** 2, axis=(0, 1))             # [feat]
        rmse = np.sqrt(mse)

        n_feat = len(mae)
        task_fn = getattr(self.task, 'feature_names', None)
        names = list(task_fn[:n_feat]) if (task_fn and len(task_fn) >= n_feat) else [f'F{i}' for i in range(n_feat)]

        rows = ['feature_idx,feature_name,MAE,MSE,RMSE']
        for idx, (nm, m, ms, r) in enumerate(zip(names, mae, mse, rmse)):
            rows.append(f'{idx},{nm},{m:.6f},{ms:.6f},{r:.6f}')

        with open(os.path.join(save_dir, 'feature_analysis.csv'), 'w') as f:
            f.write('\n'.join(rows))

    # ------------------------------------------------------------------
    # Plot 4: 2D heatmap (feature x step)
    # ------------------------------------------------------------------

    def _plot_error_heatmap(self, preds, trues, save_dir):
        """2D heatmap: x=prediction step, y=feature, color=MAE.

        论文可用尺寸：≤ 10×6 inches @ 300 dpi。大特征集自动稀疏标注。
        """
        errors = preds - trues                               # [n, pred_len, feat]
        mae_matrix = np.mean(np.abs(errors), axis=0).T      # [feat, pred_len]
        n_features, pred_len = mae_matrix.shape

        # 论文 figsize：宽最多 10"（双栏跨栏），高最多 6"（小于典型论文图尺寸）
        fig_w = min(10.0, max(6.0, pred_len * 0.06 + 4))
        fig_h = min(6.0, max(3.0, n_features * 0.12 + 2))

        fig, ax = plt.subplots(figsize=(fig_w, fig_h))
        im = ax.imshow(mae_matrix, aspect='auto', cmap='YlOrRd', origin='lower',
                       interpolation='nearest')
        cbar = plt.colorbar(im, ax=ax, pad=0.02)
        cbar.set_label('MAE', fontsize=11)
        cbar.ax.tick_params(labelsize=10)

        ax.set_xlabel('Prediction Step', fontsize=12)
        ax.set_ylabel('Feature', fontsize=12)
        ax.set_title('Error Heatmap: MAE by Step and Feature', fontsize=13)
        ax.tick_params(axis='both', labelsize=10)

        # X 轴：稀疏整数刻度（1-based）
        n_xticks = min(8, pred_len)
        step_ticks = np.linspace(0, pred_len - 1, n_xticks, dtype=int)
        ax.set_xticks(step_ticks)
        ax.set_xticklabels([str(s + 1) for s in step_ticks])

        # Y 轴：特征少时全标；多时稀疏（最多 15 个刻度）
        task_fn = getattr(self.task, 'feature_names', None)
        use_names = task_fn and len(task_fn) >= n_features
        if n_features <= 15:
            feat_ticks = np.arange(n_features)
        else:
            feat_ticks = np.linspace(0, n_features - 1, 15, dtype=int)
        ax.set_yticks(feat_ticks)
        labels = [str(task_fn[i]) if use_names else str(i) for i in feat_ticks]
        # 长特征名截断，避免 y 轴被挤窄
        labels = [l if len(l) <= 12 else l[:10] + '..' for l in labels]
        ax.set_yticklabels(labels)

        plt.tight_layout()
        plt.savefig(os.path.join(save_dir, 'error_heatmap.png'), dpi=300, bbox_inches='tight')
        plt.close()
