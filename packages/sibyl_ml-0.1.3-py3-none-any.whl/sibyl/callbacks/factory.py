"""
Callbacks 工厂类 - 自动扫描和延迟加载
"""
import os
import importlib
from typing import Dict, Type
from .base import BaseCallback


class CallbackFactory:
    """回调函数工厂，自动扫描 callbacks 目录"""

    def __init__(self, callbacks_dir: str = 'sibyl.callbacks'):
        """
        Args:
            callbacks_dir: 回调函数目录
        """
        self.callbacks_dir = callbacks_dir
        self._registry: Dict[str, str] = {}
        self._loaded: Dict[str, Type] = {}
        self._scan_directory()

    def _scan_directory(self):
        """扫描目录并注册回调（用 __file__ 同级目录，对 Hydra chdir 免疫）"""
        dir_path = os.path.dirname(os.path.abspath(__file__))

        if not os.path.isdir(dir_path):
            return

        exclude_files = ['__init__.py', 'base.py', 'factory.py']

        for filename in os.listdir(dir_path):
            if (filename.endswith('.py') and
                filename not in exclude_files):

                module_name = filename[:-3]
                full_path = f"{self.callbacks_dir}.{module_name}"
                self._registry[module_name] = full_path

    def create(self, callback_name: str, task, config):
        """创建回调实例
        Args:
            callback_name: 回调名称
            task: 任务实例
            config: 配置字典
        Returns:
            回调实例
        """
        if callback_name not in self._registry:
            raise ValueError(
                f"Callback '{callback_name}' not found. "
                f"Available: {list(self._registry.keys())}"
            )

        # 延迟导入
        if callback_name not in self._loaded:
            module_path = self._registry[callback_name]
            module = importlib.import_module(module_path)

            # 转换蛇形命名到驼峰命名 (git_logger -> GitLogger)
            camel_case_name = ''.join(word.capitalize() for word in callback_name.split('_'))

            # 查找回调类
            if hasattr(module, camel_case_name):
                callback_class = getattr(module, camel_case_name)
            else:
                raise AttributeError(
                    f"Module {module_path} has no class '{camel_case_name}'"
                )

            self._loaded[callback_name] = callback_class

        return self._loaded[callback_name](task, config)

    def list_available(self) -> list:
        """列出所有可用回调"""
        return list(self._registry.keys())


# 全局工厂实例
callback_factory = CallbackFactory()


def get_callback(name: str, task, config):
    """获取回调实例
    Args:
        name: 回调名称
        task: 任务实例
        config: 配置字典
    Returns:
        回调实例
    """
    return callback_factory.create(name, task, config)
