"""
Performance Monitor 回调 - 性能监控
"""
import os
import time
import psutil
import torch
import csv
from datetime import datetime
from .base import BaseCallback


class PerformanceMonitor(BaseCallback):
    """性能监控：推理速度、内存、GPU 使用率"""

    def __init__(self, task, config):
        super().__init__(task, config)

        self.device = task.device
        self.process = psutil.Process()
        self.start_time = None

    def on_test_begin(self):
        """测试前开始监控"""
        print("Starting performance monitoring...")
        self.start_time = time.time()
        # 首次调用 cpu_percent() 返回 0.0，必须先 warm-up 建立采样窗口
        # 实际读数在 on_test_end 拿，才反映 test 阶段的利用率
        try:
            self.process.cpu_percent(interval=None)
        except Exception:
            pass

    def on_test_end(self, result):
        """测试结束，计算性能指标"""
        # 若 on_test_begin 未被调用，跳过本次监控而非 AttributeError
        if self.start_time is None:
            print("PerformanceMonitor: on_test_begin 未调用，跳过性能汇总")
            return
        end_time = time.time()
        total_time = max(end_time - self.start_time, 1e-9)  # 防除零

        predictions = result['predictions']
        n_samples = max(int(predictions.shape[0]), 1)

        samples_per_sec = n_samples / total_time
        avg_time_per_sample = (total_time / n_samples) * 1000  # ms

        # CPU 利用率（自 on_test_begin 起的区间均值，单进程，多核会 >100%）
        try:
            cpu_util = self.process.cpu_percent(interval=None)
        except Exception:
            cpu_util = "N/A"

        # 内存使用（CPU）
        cpu_mem = self.process.memory_info().rss / (1024 ** 2)  # MB

        # GPU 内存
        gpu_mem_alloc, gpu_mem_reserved = self._get_gpu_memory()

        # GPU 使用率
        gpu_util = self._get_gpu_utilization()

        # 保存性能指标
        metrics = {
            'total_time': total_time,
            'n_samples': n_samples,
            'samples_per_sec': samples_per_sec,
            'avg_time_per_sample_ms': avg_time_per_sample,
            'cpu_utilization_percent': cpu_util,
            'cpu_memory_mb': cpu_mem,
            'gpu_memory_allocated_mb': gpu_mem_alloc,
            'gpu_memory_reserved_mb': gpu_mem_reserved,
            'gpu_utilization_percent': gpu_util
        }

        self._save_performance_metrics(metrics)
        self._print_report(n_samples, samples_per_sec, avg_time_per_sample,
                         cpu_util, cpu_mem, gpu_mem_alloc, gpu_mem_reserved, gpu_util)

    def _get_gpu_memory(self):
        """获取 GPU 峰值显存（MB）。

        注意：本方法在 `on_test_end` 被调用，此时所有 forward 激活已释放，
        瞬时 `memory_allocated()` 只剩模型权重，无法反映训练 / 推理过程
        中的真实显存压力。改用 `max_memory_allocated()`（峰值，自进程启动
        或上次 `reset_peak_memory_stats()` 以来累积）更能反映实际情况。
        """
        if not torch.cuda.is_available():
            return None, None

        try:
            dev = self.device if isinstance(self.device, str) and self.device.startswith('cuda') else None
            if dev:
                allocated = torch.cuda.max_memory_allocated(dev) / (1024 ** 2)
                reserved  = torch.cuda.max_memory_reserved(dev)  / (1024 ** 2)
            else:
                allocated = torch.cuda.max_memory_allocated() / (1024 ** 2)
                reserved  = torch.cuda.max_memory_reserved()  / (1024 ** 2)
            return round(allocated, 2), round(reserved, 2)
        except Exception:
            return None, None

    def _get_gpu_utilization(self):
        """获取平均 GPU 利用率"""
        if not torch.cuda.is_available():
            return "N/A"

        pynvml = None
        initialized = False
        try:
            import pynvml as _pynvml
            pynvml = _pynvml
            pynvml.nvmlInit()
            initialized = True
            handle = pynvml.nvmlDeviceGetHandleByIndex(torch.cuda.current_device())
            util = pynvml.nvmlDeviceGetUtilizationRates(handle)
            return util.gpu
        except Exception:
            # pynvml 缺失 / 驱动缺失 / 容器无 GPU 透传
            return "N/A"
        finally:
            if initialized and pynvml is not None:
                try:
                    pynvml.nvmlShutdown()
                except Exception:
                    pass

    def _save_performance_metrics(self, metrics):
        """保存性能指标到文件"""
        output_dir = self.config.get('output_dir', '.')
        perf_path = os.path.join(output_dir, 'performance.csv')

        def fmt(v):
            return '' if v is None else v

        with open(perf_path, 'w', newline='', encoding='utf-8') as f:
            writer = csv.writer(f)
            writer.writerow(['Metric', 'Value', 'Unit'])
            writer.writerow(['Total Time',            fmt(metrics['total_time']),                's'])
            writer.writerow(['Samples',               fmt(metrics['n_samples']),                 'count'])
            writer.writerow(['Throughput',            fmt(metrics['samples_per_sec']),           'samples/s'])
            writer.writerow(['Avg Inference Time',    fmt(metrics['avg_time_per_sample_ms']),    'ms/sample'])
            writer.writerow(['CPU Utilization',       fmt(metrics['cpu_utilization_percent']),   '%'])
            writer.writerow(['CPU Memory',            fmt(metrics['cpu_memory_mb']),             'MB'])
            writer.writerow(['GPU Memory Allocated (peak)', fmt(metrics['gpu_memory_allocated_mb']), 'MB'])
            writer.writerow(['GPU Memory Reserved (peak)',  fmt(metrics['gpu_memory_reserved_mb']),  'MB'])
            writer.writerow(['GPU Utilization',       fmt(metrics['gpu_utilization_percent']),   '%'])

        print(f"Performance metrics saved to: {perf_path}")

    def _print_report(self, n_samples, samples_per_sec, avg_time,
                     cpu_util, cpu_mem, gpu_alloc, gpu_reserved, gpu_util):
        """打印性能报告"""
        gpu_str = f"{gpu_alloc}/{gpu_reserved} MB" if gpu_alloc is not None else "N/A"
        print("\n" + "=" * 50)
        print("Performance Report")
        print("=" * 50)
        print(f"Device:             {self.device}")
        print(f"Samples:            {n_samples}")
        print(f"Throughput:         {samples_per_sec:.2f} samples/s")
        print(f"Avg Inference Time: {avg_time:.2f} ms/sample")
        print(f"CPU Utilization:    {cpu_util}%")
        print(f"CPU Memory:         {cpu_mem:.1f} MB")
        print(f"GPU Memory:         {gpu_str} (allocated/reserved)")
        print(f"GPU Utilization:    {gpu_util}%")
        print("=" * 50 + "\n")
