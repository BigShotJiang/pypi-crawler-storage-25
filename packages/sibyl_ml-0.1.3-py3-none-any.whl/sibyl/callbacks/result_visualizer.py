"""
Result Visualizer 回调 - 结果可视化和存档
"""
import os
import numpy as np
import matplotlib.pyplot as plt
import torch
from .base import BaseCallback


class ResultVisualizer(BaseCallback):
    """结果可视化和存档"""

    def __init__(self, task, config):
        super().__init__(task, config)

    def on_test_end(self, result):
        """测试结束时保存结果和可视化"""
        output_dir = self.config.get('output_dir', '.')

        # 创建目录
        vis_dir = os.path.join(output_dir, 'visualizations')
        pred_dir = os.path.join(output_dir, 'predictions')
        os.makedirs(vis_dir, exist_ok=True)
        os.makedirs(pred_dir, exist_ok=True)

        predictions = result['predictions']
        targets = result['targets']

        # 反归一化
        if self.task.scaler_stats:
            predictions = self._inverse_normalize(predictions)
            targets = self._inverse_normalize(targets)

        # 保存原始数据
        np.save(os.path.join(pred_dir, 'preds.npy'), predictions.cpu().numpy())
        np.save(os.path.join(pred_dir, 'trues.npy'), targets.cpu().numpy())

        # 可视化
        self._plot_time_series(predictions, targets, vis_dir)
        self._plot_attention_heatmap(vis_dir)

        print(f"Predictions saved to: {pred_dir}")
        print(f"Visualizations saved to: {vis_dir}")

    def _inverse_normalize(self, data: torch.Tensor) -> torch.Tensor:
        """反归一化。
        当 c_out != enc_in（如 dam：enc_in=33, c_out=30），mean/std 有 enc_in 维，
        而 data 只有 c_out 维；取前 c_out 列对齐。
        """
        if self.task.scaler_stats is None:
            return data

        mean = self.task.scaler_stats['mean']
        std = self.task.scaler_stats['std']
        # 对齐最后一维：data[..., C] vs scaler[..., F]，当 C != F 时截取前 C 个
        if data.dim() >= 1 and mean.dim() >= 1 and mean.shape[-1] != data.shape[-1]:
            C = data.shape[-1]
            mean = mean[..., :C]
            std = std[..., :C]
        return data * std + mean

    def _plot_time_series(self, preds, targets, save_dir):
        """绘制论文用时序对比图。

        采样策略（比"前N个"更有代表性）：
        - 样本：沿 test 集时间轴均匀采 3 个（首/中/末），反映整个测试期
        - 特征：按 MAE 降序取 top-2（最具挑战性的两个 channel）
        - 布局：3 行 × 2 列 = 6 个子图，尺寸 10"×6"（双栏论文友好）
        - 300 DPI 印刷级
        """
        preds_np = preds.cpu().numpy()     # [N, pred_len, C]
        trues_np = targets.cpu().numpy()
        N, pred_len, C = preds_np.shape

        # 选样本：首/中/末（test 集首端/中段/末端各一个）
        n_samples = min(3, N)
        if N >= 3:
            sample_idx = [0, N // 2, N - 1]
        else:
            sample_idx = list(range(N))

        # 选特征：第1个 MAE 最大（难点），第2个挑和第1个相关性最低的（多样性）
        # 避免 ETTh1 这种 HUFL/MUFL 高度同步的情况两列画出几乎一样的波形。
        n_features = min(2, C)
        mae_per_feat = np.mean(np.abs(preds_np - trues_np), axis=(0, 1))   # [C]
        first = int(np.argmax(mae_per_feat))
        feat_idx = [first]
        if n_features >= 2 and C >= 2:
            # 用 ground-truth 序列在所有样本×步上的相关性
            ref = trues_np[:, :, first].reshape(-1)
            ref_std = ref.std()
            best_j, best_score = None, None
            for j in range(C):
                if j == first:
                    continue
                other = trues_np[:, :, j].reshape(-1)
                if other.std() < 1e-12 or ref_std < 1e-12:
                    corr = 0.0
                else:
                    corr = float(np.corrcoef(ref, other)[0, 1])
                # 目标：|corr| 小（不相似）同时 MAE 较大（误差值得看）
                score = -abs(corr) + 0.25 * (mae_per_feat[j] / (mae_per_feat.max() + 1e-12))
                if best_score is None or score > best_score:
                    best_score, best_j = score, j
            feat_idx.append(best_j)

        # 特征名（若数据集提供）
        task_fn = getattr(self.task, 'feature_names', None)

        def _feat_label(j):
            if task_fn and j < len(task_fn):
                name = str(task_fn[j])
                return name if len(name) <= 15 else name[:13] + '..'
            return f'Feature {j}'

        fig_w = 5.0 * n_features
        fig_h = min(6.0, 2.0 * n_samples + 0.5)
        fig, axes = plt.subplots(n_samples, n_features,
                                 figsize=(fig_w, fig_h),
                                 sharex=True, squeeze=False)

        xs = np.arange(1, pred_len + 1)
        for row, si in enumerate(sample_idx):
            for col, fj in enumerate(feat_idx):
                ax = axes[row][col]
                true = trues_np[si, :, fj].flatten()
                pred = preds_np[si, :, fj].flatten()
                ax.plot(xs, true, label='Ground Truth', linewidth=1.8, color='#2c3e50')
                ax.plot(xs, pred, label='Prediction', linewidth=1.8,
                        linestyle='--', color='#e74c3c')
                # 填充误差带（pred - true 的绝对值可视化）
                ax.fill_between(xs, true, pred, alpha=0.12, color='#e74c3c')

                if row == 0:
                    ax.set_title(_feat_label(fj), fontsize=12)
                if col == 0:
                    pos = {0: 'early', 1: 'mid', 2: 'late'}.get(row, f'#{si}')
                    ax.set_ylabel(f'{pos}\nvalue', fontsize=10)
                if row == n_samples - 1:
                    ax.set_xlabel('Prediction Step', fontsize=11)
                ax.tick_params(axis='both', labelsize=9)
                ax.grid(True, alpha=0.25, linestyle=':')

        # 单一图例放在最上方
        handles, labels = axes[0][0].get_legend_handles_labels()
        fig.legend(handles, labels, loc='upper center', ncol=2,
                   bbox_to_anchor=(0.5, 1.02), fontsize=11, frameon=False)

        plt.tight_layout(rect=[0, 0, 1, 0.97])
        plt.savefig(os.path.join(save_dir, 'prediction_comparison.png'),
                    dpi=300, bbox_inches='tight')
        plt.close()

    def _plot_attention_heatmap(self, save_dir):
        """绘制 Attention Heatmap（如果模型支持）"""
        if (hasattr(self.task.model, 'output_attention') and
                self.task.model.output_attention):

            # 从模型中获取 attention weights
            # 具体实现取决于模型结构
            # 这里提供一个通用框架

            # 假设模型有 attns 属性存储 attention weights
            if hasattr(self.task.model, 'attns') and len(self.task.model.attns) > 0:
                attn = self.task.model.attns[0][0]  # [n_heads, seq_len, seq_len]
                avg_attn = attn.mean(dim=0).cpu().numpy()

                fig, ax = plt.subplots(figsize=(6, 5))
                im = ax.imshow(avg_attn, cmap='viridis', aspect='auto',
                               interpolation='nearest')
                cbar = plt.colorbar(im, ax=ax, pad=0.02)
                cbar.set_label('Attention Weight', fontsize=11)
                cbar.ax.tick_params(labelsize=10)
                ax.set_title('Attention Heatmap', fontsize=12)
                ax.set_xlabel('Key Position', fontsize=11)
                ax.set_ylabel('Query Position', fontsize=11)
                ax.tick_params(axis='both', labelsize=10)
                plt.tight_layout()
                plt.savefig(os.path.join(save_dir, 'attention_heatmap.png'),
                            dpi=300, bbox_inches='tight')
                plt.close()

                print("Attention heatmap saved")
