"""
Model Checkpoint 回调 - 保存最佳模型检查点 + 推理所需的全部元数据

目录布局（best_model.pt 同目录）：
    checkpoints/
    ├── best_model.pt          # 权重 + 训练态
    ├── checkpoint_last.pt     # 最新 epoch（断点续训用）
    └── inference_bundle.yaml  # 模型/数据/训练参数（重加载时无需从 .configs 读）

inference_bundle.yaml 内容：
    model:        完整 model config（d_model, e_layers, patch_len, enc_in, seq_len 等）
    data_loader:  数据加载配置（seq_len, batch_size, path, scaler 策略等）
    training:     训练时的关键参数（pred_len, label_len, seq_len）
    meta:         best_val_loss, best_epoch
"""
import os
import yaml
import torch
from omegaconf import OmegaConf, DictConfig
from .base import BaseCallback


class ModelCheckpoint(BaseCallback):
    """保存最佳模型检查点 + 推理元数据 bundle"""

    def __init__(self, task, config):
        super().__init__(task, config)

        self.best_val_loss = float('inf')
        self.best_epoch = -1
        self.save_best_only = config.get('save_best_only', True)
        self.checkpoint_dir = config.get('checkpoint_dir', 'checkpoints')

        # 确保目录存在
        os.makedirs(self.checkpoint_dir, exist_ok=True)

        # 缓存：on_train_begin 时从 task 抓取完整 config（若可用）
        self._bundle_written = False

    def on_epoch_end(self, epoch, train_loss, val_metrics):
        """每个 epoch 结束时检查是否保存"""
        val_loss = val_metrics.get('val_loss', float('inf'))

        # 始终保存 last_model.pt 用于断点续训
        self._save_checkpoint(epoch, val_loss, suffix='last')

        if val_loss < self.best_val_loss:
            self.best_val_loss = val_loss
            self.best_epoch = epoch

            if self.save_best_only:
                self._save_best_checkpoint(epoch, val_loss)
            else:
                self._save_checkpoint(epoch, val_loss, suffix=f'epoch_{epoch}')

            # 同步更新 inference bundle（总是对应当前 best）
            self._write_inference_bundle()

    def _save_checkpoint(self, epoch, val_loss, suffix=''):
        """保存检查点"""
        filename = f'checkpoint_{suffix}.pt' if suffix else 'checkpoint.pt'
        path = os.path.join(self.checkpoint_dir, filename)

        self.task.save_checkpoint(path, epoch, val_loss)

    def _save_best_checkpoint(self, epoch, val_loss):
        """保存最佳检查点"""
        path = os.path.join(self.checkpoint_dir, 'best_model.pt')
        self.task.save_checkpoint(path, epoch, val_loss)
        print(f"Best model saved with val_loss: {val_loss:.6f}")

    def _write_inference_bundle(self):
        """写 inference_bundle.yaml —— 重加载 checkpoint 做推理所需的所有元信息。

        让下游代码一行加载即可：
            bundle = yaml.safe_load(open('inference_bundle.yaml'))
            model = get_model(bundle['model']['name'], bundle['model'])
            model.load_state_dict(torch.load('best_model.pt')['model_state_dict'])
        """
        try:
            # 从 task 拿 model / data_loader / training 三段配置
            task_cfg = self.task.config if hasattr(self.task, 'config') else None
            if task_cfg is None:
                return

            bundle = {
                'meta': {
                    'best_val_loss': float(self.best_val_loss),
                    'best_epoch': int(self.best_epoch),
                    'checkpoint_file': 'best_model.pt',
                }
            }

            # training config 直接用 task.config（训练 cfg）
            if isinstance(task_cfg, DictConfig):
                training_dict = OmegaConf.to_container(task_cfg, resolve=True)
            else:
                training_dict = dict(task_cfg) if task_cfg else {}
            # 只保留推理相关字段
            bundle['training'] = {
                k: training_dict[k] for k in ('seq_len','pred_len','label_len','metrics')
                if k in training_dict
            }

            # model config：从 task.model.config 读（若有）
            if hasattr(self.task, 'model') and hasattr(self.task.model, 'config'):
                mc = self.task.model.config
                if isinstance(mc, DictConfig):
                    bundle['model'] = OmegaConf.to_container(mc, resolve=True)
                elif isinstance(mc, dict):
                    bundle['model'] = dict(mc)
                # 清理 recommender 段
                if isinstance(bundle.get('model'), dict):
                    bundle['model'].pop('recommender', None)

            # data_loader config：优先从 task.data_provider.config，否则从 cwd/.configs/config.yaml
            if hasattr(self.task, 'data_provider') and hasattr(self.task.data_provider, 'config'):
                dc = self.task.data_provider.config
                if isinstance(dc, DictConfig):
                    bundle['data_loader'] = OmegaConf.to_container(dc, resolve=True)
                elif isinstance(dc, dict):
                    bundle['data_loader'] = dict(dc)
            elif os.path.exists('.configs/config.yaml'):
                # Hydra chdir 到 output 目录；.configs/config.yaml 是 Hydra 训练时保存的完整 resolved config
                try:
                    with open('.configs/config.yaml') as f:
                        hydra_cfg = yaml.safe_load(f) or {}
                    if 'data_loader' in hydra_cfg:
                        bundle['data_loader'] = hydra_cfg['data_loader']
                except Exception:
                    pass

            out_path = os.path.join(self.checkpoint_dir, 'inference_bundle.yaml')
            with open(out_path, 'w') as f:
                yaml.safe_dump(bundle, f, default_flow_style=False, sort_keys=False, allow_unicode=True)
            self._bundle_written = True
        except Exception as e:
            # 不影响训练流程
            import logging
            logging.getLogger(__name__).warning(f"写 inference_bundle.yaml 失败（可忽略）: {e}")
