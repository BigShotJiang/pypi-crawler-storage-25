"""SHAP Explainer 回调 — GradientExplainer 保留时间结构的特征归因

技术选型（对比老版 KernelSHAP）：
  - 旧实现把 [B, T, C] 沿时间维 mean() 再 expand() 回去，模型看到的是"每个时刻都一样"
    的常值序列，attention/conv 退化成恒等映射。归因反映的是"常值输入敏感度"，不是真实
    时序预测的特征贡献 —— 对 Transformer/Autoformer 这类依赖时间结构的模型尤其失真。
  - GradientExplainer 用反向传播计算 per-timestep gradient × 扰动积分，保留完整时间结构；
    无需组合采样，速度比 KernelSHAP 快 10-100×（fedformer 从 ~5 min 降到 ~10-30s）。

产物（保持与老版一致，便于下游图报表复用）：
  - analysis/shap_values.npy      : [n_explain, seq_len, n_features] 完整 3D SHAP
  - analysis/shap_importance.png  : Top-20 特征重要性柱状图（按 |SHAP| 在样本+时间上求均值）
  - analysis/shap_importance.csv  : {feature, mean_abs_shap}

限制：
  - 不传 x_mark。ForecastTask.test() 只 cache 了 x（不含时间标志），且 GradientExplainer
    单输入模型更简单。对 embed='timeF' 的模型相当于 "无时间特征" 情景下的归因；与训练时
    分布不完全一致，是可接受的近似。如需精确归因，要在 ForecastTask.test() 里同时 cache
    x_mark 并切换到多输入 wrapper。

配置字段（experiment/callback yaml 里可 override）：
  - n_background (default 50) : SHAP 背景样本数（对比基线）
  - n_explain    (default 10) : 被解释的样本数
"""
import csv
import os
import threading
import time
import numpy as np
import torch
from .base import BaseCallback

try:
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    try:
        plt.style.use('seaborn-v0_8-whitegrid')
    except OSError:
        pass
except ImportError:
    plt = None


class _ResourceSampler:
    """后台线程采样 SHAP 期间的 CPU% / CPU mem / GPU% / GPU mem 峰值。

    为什么 SHAP 要独立采样而不复用 performance_monitor.on_test_end：
      - performance_monitor 在 on_test_end 里只拿一个终态快照，
        且 callback 顺序在 shap_explainer 之前（config.yaml 列顺序），读不到 SHAP 的峰值。
      - SHAP 阶段的显存/CPU 是 benchmark 瓶颈判断的关键数据，值得独立记录。
    """
    def __init__(self, interval_s: float = 0.1):
        self.interval = interval_s
        self._stop = threading.Event()
        self._thread = None
        self.peak = {'cpu_util': 0.0, 'cpu_mem_mb': 0.0, 'gpu_util': 0.0, 'gpu_mem_mb': 0.0}
        self._pynvml = None
        self._nvml_handle = None
        self._psutil = None
        self._proc = None

    def _setup(self):
        try:
            import psutil
            self._psutil = psutil
            self._proc = psutil.Process()
            self._proc.cpu_percent(interval=None)  # 预热采样窗口
        except Exception:
            self._psutil = None
        if torch.cuda.is_available():
            try:
                import pynvml
                pynvml.nvmlInit()
                self._pynvml = pynvml
                self._nvml_handle = pynvml.nvmlDeviceGetHandleByIndex(torch.cuda.current_device())
            except Exception:
                self._pynvml = None

    def _teardown(self):
        if self._pynvml is not None:
            try: self._pynvml.nvmlShutdown()
            except Exception: pass

    def _loop(self):
        pid = os.getpid()
        while not self._stop.is_set():
            try:
                if self._proc is not None:
                    util = self._proc.cpu_percent(interval=None)
                    mem_mb = self._proc.memory_info().rss / (1024 ** 2)
                    if util > self.peak['cpu_util']: self.peak['cpu_util'] = util
                    if mem_mb > self.peak['cpu_mem_mb']: self.peak['cpu_mem_mb'] = mem_mb
                if self._pynvml is not None:
                    r = self._pynvml.nvmlDeviceGetUtilizationRates(self._nvml_handle)
                    if r.gpu > self.peak['gpu_util']: self.peak['gpu_util'] = float(r.gpu)
                    # 用 per-process 显存（和 nvidia-smi 一致）
                    for p in self._pynvml.nvmlDeviceGetComputeRunningProcesses(self._nvml_handle):
                        if p.pid == pid and p.usedGpuMemory:
                            mem_mb = p.usedGpuMemory / (1024 ** 2)
                            if mem_mb > self.peak['gpu_mem_mb']: self.peak['gpu_mem_mb'] = mem_mb
                            break
            except Exception:
                pass
            self._stop.wait(self.interval)

    def __enter__(self):
        self._setup()
        self._thread = threading.Thread(target=self._loop, daemon=True)
        self._thread.start()
        return self

    def __exit__(self, *exc):
        self._stop.set()
        if self._thread is not None:
            self._thread.join(timeout=2.0)
        self._teardown()


class _ForecastWrapper(torch.nn.Module):
    """把 task._forward(x, x_mark=None, y_mark=None) 包成纯 x → 标量 的 nn.Module。

    输出形状 [B]：对 pred_len × c_out 做均值，让 SHAP 归因到 "输入 (t, c) 对整体预测强度
    的贡献"。如果要做 horizon-wise 或 channel-wise 归因，在外层多调几次、每次 reduce 到
    不同标量即可。
    """
    def __init__(self, task):
        super().__init__()
        self.task = task
        self.task.model.eval()

    def forward(self, x):
        out = self.task._forward(x)       # [B, pred_len, c_out]
        # GradientExplainer 要求输出至少是 [B, n_outputs]（内部按输出维度索引）；
        # 返回 [B, 1] —— 对 pred_len × c_out 做均值后 keepdim 成单输出
        return out.mean(dim=(1, 2), keepdim=False).unsqueeze(-1)  # [B, 1]


class ShapExplainer(BaseCallback):
    """GradientExplainer 版 SHAP 解释回调。"""

    def __init__(self, task, config):
        super().__init__(task, config)
        self.n_background = int(config.get('n_background', 50))
        self.n_explain = int(config.get('n_explain', 10))

    def on_test_end(self, result):
        if plt is None:
            print("matplotlib not available, skipping SHAP")
            return

        inputs = result.get('inputs', None)
        if inputs is None:
            print("Warning: SHAP requires 'inputs' in result, skipping")
            return

        try:
            import shap
        except ImportError:
            print("Warning: shap not installed, skipping. Install with: pip install shap")
            return

        output_dir = self.config.get('output_dir', '.')
        analysis_dir = os.path.join(output_dir, 'analysis')
        os.makedirs(analysis_dir, exist_ok=True)

        t0 = time.time()
        # 重置 torch CUDA 峰值统计，让 shap_performance.csv 里的 GPU 显存只反映 SHAP 阶段
        if torch.cuda.is_available():
            try: torch.cuda.reset_peak_memory_stats()
            except Exception: pass
        try:
            with _ResourceSampler(interval_s=0.1) as sampler:
                shap_values, feature_names = self._compute_shap(inputs, shap)
            self._plot_summary(shap_values, feature_names, analysis_dir)
            self._save_values(shap_values, feature_names, analysis_dir)
            elapsed = time.time() - t0
            self._save_perf(analysis_dir, sampler.peak, elapsed)
            print(f"SHAP analysis saved to: {analysis_dir}")
        except Exception as e:
            import traceback
            print(f"Warning: SHAP analysis failed: {e}")
            traceback.print_exc()
        finally:
            # 只在最外层释放一次 GPU 缓存，避免在 SHAP 内部热循环里频繁 empty_cache
            # 导致整体拖慢（老版在 model_predict 每批都 empty_cache，是 fedformer
            # SHAP 耗时 5 分钟的主要原因）
            if torch.cuda.is_available():
                torch.cuda.empty_cache()

    def _save_perf(self, analysis_dir, peak, elapsed_s):
        """SHAP 阶段的 CPU/GPU 峰值利用率 + 内存写 shap_performance.csv"""
        path = os.path.join(analysis_dir, 'shap_performance.csv')
        gpu_peak_mb = peak['gpu_mem_mb']
        if gpu_peak_mb == 0.0 and torch.cuda.is_available():
            try: gpu_peak_mb = torch.cuda.max_memory_allocated() / (1024 ** 2)
            except Exception: pass
        rows = [
            ('Metric', 'Value', 'Unit'),
            ('SHAP Elapsed',       round(elapsed_s, 3),         's'),
            ('CPU Utilization',    round(peak['cpu_util'], 1),  '% (peak, single-proc, multi-core can exceed 100%)'),
            ('CPU Memory',         round(peak['cpu_mem_mb'], 1),'MB (RSS peak)'),
            ('GPU Utilization',    round(peak['gpu_util'], 1),  '% (peak, via pynvml)'),
            ('GPU Memory',         round(gpu_peak_mb, 1),       'MB (per-process peak, via pynvml or torch)'),
        ]
        with open(path, 'w', newline='', encoding='utf-8') as f:
            csv.writer(f).writerows(rows)
        print(f"  SHAP perf: CPU {peak['cpu_util']:.0f}% / {peak['cpu_mem_mb']:.0f} MB, "
              f"GPU {peak['gpu_util']:.0f}% / {gpu_peak_mb:.0f} MB, elapsed {elapsed_s:.1f}s")

    def _compute_shap(self, inputs, shap):
        device = self.task.device
        wrapper = _ForecastWrapper(self.task).to(device)

        total = min(inputs.shape[0], self.n_background + self.n_explain)
        x_all = inputs[:total].to(device).float()

        background = x_all[:self.n_background]
        explain = x_all[self.n_background:self.n_background + self.n_explain]
        # 样本不够时 fallback：用前 n_explain 个样本自身作解释目标
        if len(explain) == 0:
            explain = x_all[:self.n_explain]

        # GradientExplainer 内部做 Expected Gradients：对 background 采样 baseline，
        # 积分 gradient(explain) 到 gradient(baseline)，输出形如 explain 的 SHAP 张量
        explainer = shap.GradientExplainer(wrapper, background)
        shap_values = explainer.shap_values(explain)

        # 形状规范化：单输出模型 → ndarray [B, T, C]；多输出可能是 list / [B, T, C, 1]
        if isinstance(shap_values, list):
            shap_values = shap_values[0]
        shap_values = np.asarray(shap_values)
        if shap_values.ndim == 4 and shap_values.shape[-1] == 1:
            shap_values = shap_values[..., 0]

        n_features = x_all.shape[-1]
        task_fn = getattr(self.task, 'feature_names', None)
        if task_fn and len(task_fn) >= n_features:
            feature_names = list(task_fn[:n_features])
        else:
            feature_names = [f'F{i}' for i in range(n_features)]

        return shap_values, feature_names

    def _plot_summary(self, shap_values, feature_names, save_dir):
        """Top-20 特征重要性柱状图（聚合方式：|SHAP| 在样本+时间上求均值）"""
        # [n_explain, seq_len, n_features] → [n_features]
        mean_abs_shap = np.abs(shap_values).mean(axis=tuple(range(shap_values.ndim - 1)))
        n_features = len(mean_abs_shap)

        sorted_idx = np.argsort(mean_abs_shap)[::-1]
        n_show = min(20, n_features)
        top_idx = sorted_idx[:n_show]

        fig_h = min(5.5, max(3.0, n_show * 0.22 + 1))
        fig, ax = plt.subplots(figsize=(7, fig_h))
        names = [feature_names[i] for i in top_idx]
        values = mean_abs_shap[top_idx]

        ax.barh(range(n_show), values[::-1], color='coral', edgecolor='white')
        ax.set_yticks(range(n_show))
        ax.set_yticklabels(names[::-1], fontsize=10)
        ax.set_xlabel('Mean |SHAP| (averaged over time & samples)', fontsize=11)
        title = 'SHAP Feature Importance (GradientExplainer)'
        if n_features > n_show:
            title += f' — Top {n_show}/{n_features}'
        ax.set_title(title, fontsize=12)
        ax.tick_params(axis='x', labelsize=10)
        ax.grid(True, alpha=0.25, axis='x', linestyle=':')

        plt.tight_layout()
        plt.savefig(os.path.join(save_dir, 'shap_importance.png'),
                    dpi=300, bbox_inches='tight')
        plt.close()

    def _save_values(self, shap_values, feature_names, save_dir):
        """保存完整 3D SHAP 值 + 按特征聚合的重要性 CSV"""
        np.save(os.path.join(save_dir, 'shap_values.npy'), shap_values)

        import csv
        mean_abs = np.abs(shap_values).mean(axis=tuple(range(shap_values.ndim - 1)))
        sorted_idx = np.argsort(mean_abs)[::-1]

        path = os.path.join(save_dir, 'shap_importance.csv')
        with open(path, 'w', newline='') as f:
            writer = csv.writer(f)
            writer.writerow(['feature', 'mean_abs_shap'])
            for i in sorted_idx:
                writer.writerow([feature_names[i], f'{mean_abs[i]:.6f}'])
