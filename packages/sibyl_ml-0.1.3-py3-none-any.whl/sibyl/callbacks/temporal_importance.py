"""
Temporal Importance 回调 - 分析哪些历史时间步对预测影响最大
"""
import os
import csv
import numpy as np
import torch
from .base import BaseCallback

try:
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    try:
        plt.style.use('seaborn-v0_8-whitegrid')
    except OSError:
        pass
except ImportError:
    plt = None


class TemporalImportance(BaseCallback):
    """基于梯度的时间步重要性分析"""

    def __init__(self, task, config):
        super().__init__(task, config)

    def on_test_end(self, result):
        """测试结束时计算时间步重要性"""
        if plt is None:
            print("matplotlib not available, skipping temporal importance")
            return

        inputs = result.get('inputs', None)
        if inputs is None:
            print("Warning: temporal importance requires 'inputs' in result, skipping")
            return

        output_dir = self.config.get('output_dir', '.')
        analysis_dir = os.path.join(output_dir, 'analysis')
        os.makedirs(analysis_dir, exist_ok=True)

        try:
            importance = self._compute_temporal_importance(inputs)
            self._plot_temporal(importance, analysis_dir)
            self._save_csv(importance, analysis_dir)
            print(f"Temporal importance saved to: {analysis_dir}")
        except Exception as e:
            print(f"Warning: temporal importance failed: {e}")

    def _compute_temporal_importance(self, inputs):
        """梯度法计算时间步重要性。

        Returns:
            dict:
              aggregate:   [seq_len]            每个时间步的平均 |gradient|
              per_feature: [seq_len, n_features] 时间步 × 特征的 |gradient|
        """
        model = self.task.model
        model.eval()

        n_samples = min(inputs.shape[0], 100)
        x = inputs[:n_samples].to(self.task.device).detach().requires_grad_(True)

        # cuDNN 要求 RNN backward 在 training 模式下；临时禁用 cuDNN 以允许 LSTM/GRU 在 eval 模式下算梯度
        with torch.enable_grad(), torch.backends.cudnn.flags(enabled=False):
            outputs = self.task._forward(x)
            loss = outputs.abs().mean()
            loss.backward()

        if x.grad is None:
            raise RuntimeError("temporal importance: gradients are None")

        # |grad| 跨 batch 平均 → [seq_len, n_features]
        per_feature = x.grad.abs().mean(dim=0).cpu().numpy()
        aggregate = per_feature.mean(axis=1)  # [seq_len]
        return {'aggregate': aggregate, 'per_feature': per_feature}

    def _plot_temporal(self, importance, save_dir):
        """绘制时间步重要性图：左侧折线（聚合），右侧热图（top-20 重要特征 × 时间）。"""
        agg = importance['aggregate']
        per_feat = importance['per_feature']
        seq_len, n_features = per_feat.shape

        fig, axes = plt.subplots(1, 2, figsize=(10, 4))

        xs = np.arange(1, seq_len + 1)
        axes[0].plot(xs, agg, linewidth=1.8, color='steelblue')
        axes[0].fill_between(xs, agg, alpha=0.25, color='steelblue')
        axes[0].set_xlabel('Time Step (history)', fontsize=11)
        axes[0].set_ylabel('Importance (mean |gradient|)', fontsize=11)
        axes[0].set_title('Temporal Importance (aggregate)', fontsize=12)
        axes[0].tick_params(axis='both', labelsize=10)
        axes[0].grid(True, alpha=0.25, linestyle=':')

        # 右图：选 top-20 最重要的 feature（按整体重要性降序），而非简单前 20
        top_k = min(20, n_features)
        feat_importance = per_feat.mean(axis=0)
        top_idx = np.argsort(feat_importance)[::-1][:top_k]
        heatmap = per_feat[:, top_idx].T  # [top_k, seq_len]

        task_fn = getattr(self.task, 'feature_names', None)
        use_names = task_fn and len(task_fn) >= n_features

        im = axes[1].imshow(heatmap, aspect='auto', cmap='YlOrRd',
                            origin='lower', interpolation='nearest')
        axes[1].set_xlabel('Time Step', fontsize=11)
        axes[1].set_ylabel('Feature', fontsize=11)
        title = f'Top-{top_k} Feature Importance per Step' if n_features > top_k \
                else 'Temporal Importance per Feature'
        axes[1].set_title(title, fontsize=12)
        axes[1].tick_params(axis='both', labelsize=10)

        # X 轴稀疏刻度
        x_ticks = np.linspace(0, seq_len - 1, min(6, seq_len), dtype=int)
        axes[1].set_xticks(x_ticks)
        axes[1].set_xticklabels([str(s + 1) for s in x_ticks])

        # Y 轴：显示每个 top feature 的名称
        y_ticks = np.arange(top_k)
        axes[1].set_yticks(y_ticks)
        labels = [str(task_fn[top_idx[i]]) if use_names else f'F{top_idx[i]}' for i in range(top_k)]
        labels = [l if len(l) <= 10 else l[:8] + '..' for l in labels]
        axes[1].set_yticklabels(labels, fontsize=9)

        cbar = plt.colorbar(im, ax=axes[1], pad=0.02)
        cbar.set_label('Importance', fontsize=10)
        cbar.ax.tick_params(labelsize=9)

        plt.tight_layout()
        plt.savefig(os.path.join(save_dir, 'temporal_importance.png'),
                    dpi=300, bbox_inches='tight')
        plt.close()

    def _save_csv(self, importance, save_dir):
        """保存时间步重要性。aggregate 存 CSV（人读），per_feature 存 npy（重画图用）。"""
        agg = importance['aggregate']
        per_feat = importance['per_feature']

        # aggregate CSV
        path = os.path.join(save_dir, 'temporal_importance.csv')
        with open(path, 'w', newline='') as f:
            writer = csv.writer(f)
            writer.writerow(['time_step', 'importance'])
            for t, imp in enumerate(agg, 1):
                writer.writerow([t, f'{imp:.6f}'])

        # per-feature 矩阵 npy（[seq_len, n_features]），供后续重画热图用
        np.save(os.path.join(save_dir, 'temporal_importance_per_feature.npy'), per_feat)
