"""
EarlyStopping 回调 - 当验证损失不再改善时停止训练
"""
from .base import BaseCallback


class EarlyStopping(BaseCallback):
    """当验证损失不再改善时提前停止训练"""

    def __init__(self, task, config):
        super().__init__(task, config)

        training_cfg = config.get('training', {})
        self.patience = training_cfg.get('early_stopping_patience',
                        config.get('early_stopping_patience', 10))
        # min_delta：val 改善必须 > min_delta 才重置 counter；避免平台期上的
        # 微小波动（~1e-3）反复延长训练。TSL 标准做法等价于 min_delta=0，但对
        # type3 + cosine 长训练，1e-3 的阈值能把 20+ epoch 的尾巴及时剪掉。
        self.min_delta = training_cfg.get('early_stopping_min_delta',
                         config.get('early_stopping_min_delta', 1e-3))
        self.best_val_loss = float('inf')
        self.wait = 0

    def on_epoch_end(self, epoch, train_loss, val_metrics):
        """每个 epoch 结束时更新早停状态。

        改善阈值 min_delta：val_loss 至少要比 best 小 min_delta 才视为"改善"。
        """
        val_loss = val_metrics.get('val_loss', float('inf'))

        if val_loss < self.best_val_loss - self.min_delta:
            self.best_val_loss = val_loss
            self.wait = 0
        else:
            # 仍更新 best_val_loss 记录（但不重置 counter）
            if val_loss < self.best_val_loss:
                self.best_val_loss = val_loss
            self.wait += 1
            remaining = self.patience - self.wait
            print(f"EarlyStopping: no improvement >{self.min_delta:g} for {self.wait} epoch(s), "
                  f"{remaining} patience remaining (best={self.best_val_loss:.6f})")

    def should_stop(self) -> bool:
        """当耐心耗尽时返回 True"""
        return self.wait >= self.patience
