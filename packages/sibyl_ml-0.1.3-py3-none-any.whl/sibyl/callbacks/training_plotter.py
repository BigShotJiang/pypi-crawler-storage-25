"""
Training Plotter callback - plots training curves from training_log.csv
"""
import os
import csv
import matplotlib.pyplot as plt
from .base import BaseCallback

try:
    plt.style.use('seaborn-v0_8-whitegrid')
except OSError:
    pass  # fallback to default style


class TrainingPlotter(BaseCallback):
    """Plots training curves after training completes."""

    def __init__(self, task, config):
        super().__init__(task, config)

    def on_train_end(self):
        """Read training_log.csv, plot and save training curves."""
        output_dir = self.config.get('output_dir', '.')
        log_path = os.path.join(output_dir, 'training_log.csv')

        if not os.path.exists(log_path):
            print(f"TrainingPlotter: training_log.csv not found at {log_path}, skipping.")
            return

        epochs, train_losses, val_losses, best_val_losses, lrs = [], [], [], [], []

        with open(log_path, newline='') as f:
            reader = csv.DictReader(f)
            for row in reader:
                epochs.append(int(row['epoch']))
                train_losses.append(float(row['train_loss']))
                val_losses.append(float(row['val_loss']))
                best_val_losses.append(float(row['best_val_loss']))
                lrs.append(float(row['lr']))

        if not epochs:
            print("TrainingPlotter: training_log.csv is empty, skipping.")
            return

        vis_dir = os.path.join(output_dir, 'visualizations')
        os.makedirs(vis_dir, exist_ok=True)

        self._plot_training_curves(epochs, train_losses, val_losses, best_val_losses, vis_dir)
        self._plot_learning_rate(epochs, lrs, vis_dir)

        print(f"Training plots saved to: {vis_dir}")

    def _plot_training_curves(self, epochs, train_losses, val_losses, best_val_losses, save_dir):
        """Plot train_loss and val_loss vs epoch with best_val_loss reference line."""
        fig, ax = plt.subplots(figsize=(7, 4))

        ax.plot(epochs, train_losses, label='Train Loss', linewidth=1.8, color='steelblue')
        ax.plot(epochs, val_losses, label='Val Loss', linewidth=1.8, color='darkorange')

        best_val = min(best_val_losses)
        best_epoch = epochs[best_val_losses.index(best_val)] if best_val in best_val_losses else None
        ax.axhline(y=best_val, color='green', linestyle='--', linewidth=1.2,
                   label=f'Best Val ({best_val:.4f})' +
                         (f' @ ep{best_epoch}' if best_epoch else ''))

        ax.set_xlabel('Epoch', fontsize=11)
        ax.set_ylabel('Loss', fontsize=11)
        ax.set_title('Training Curves', fontsize=12)
        ax.tick_params(axis='both', labelsize=10)
        ax.grid(True, alpha=0.25, linestyle=':')
        ax.legend(fontsize=10)

        plt.tight_layout()
        plt.savefig(os.path.join(save_dir, 'training_curves.png'),
                    dpi=300, bbox_inches='tight')
        plt.close()

    def _plot_learning_rate(self, epochs, lrs, save_dir):
        """Plot learning rate vs epoch, only if lr changes during training."""
        if len(set(lrs)) <= 1:
            return  # lr is constant, skip

        fig, ax = plt.subplots(figsize=(7, 3))

        ax.plot(epochs, lrs, label='Learning Rate', linewidth=1.8, color='purple')
        ax.set_xlabel('Epoch', fontsize=11)
        ax.set_ylabel('Learning Rate', fontsize=11)
        ax.set_title('Learning Rate Schedule', fontsize=12)
        ax.tick_params(axis='both', labelsize=10)
        ax.grid(True, alpha=0.25, linestyle=':')
        ax.legend(fontsize=10)

        plt.tight_layout()
        plt.savefig(os.path.join(save_dir, 'learning_rate.png'),
                    dpi=300, bbox_inches='tight')
        plt.close()
