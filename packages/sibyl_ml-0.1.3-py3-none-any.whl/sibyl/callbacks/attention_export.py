"""注意力权重导出回调。

在 on_test_end 阶段对 test_loader 的前 N 个 batch 再跑一次 forward(return_attention=True)，
把 cross_mark_weights / mark_importance 保存为 .npy，供下游可解释性分析使用。

仅当 task.model 支持 return_attention 且 active_marks 非空时工作；否则静默跳过。
"""

import json
import logging
import os
from pathlib import Path

import numpy as np
import torch

from .base import BaseCallback

logger = logging.getLogger(__name__)


class AttentionExport(BaseCallback):
    """CC-style 注意力导出（跨 mark 注意力 + mark 重要性）。"""

    def __init__(self, task, config):
        super().__init__(task, config)
        cfg = config.get("attention_export", {}) if isinstance(
            config, dict) or hasattr(config, "get") else {}
        self.n_batches = int(cfg.get("n_batches", 10))
        self.output_dir = cfg.get("output_dir", "attention")

    def on_test_end(self, result):
        model = self.task.model
        active_marks = getattr(model, "active_marks", None)
        if not active_marks:
            logger.info("AttentionExport: model has no active_marks, skipping.")
            return

        test_loader = result.get("_test_loader")
        if test_loader is None:
            test_loader = getattr(self.task, "_last_test_loader", None)
        if test_loader is None:
            logger.warning(
                "AttentionExport: no test_loader available in result; skipping.")
            return

        out_dir = Path(self.output_dir)
        out_dir.mkdir(parents=True, exist_ok=True)

        cross_mark_chunks = []
        mark_imp_chunks = []
        gene_ids = []
        mark_names = None

        model.eval()
        device = self.task.device
        with torch.no_grad():
            for i, batch in enumerate(test_loader):
                if i >= self.n_batches:
                    break
                gids = batch.get("gene_id", None)
                batch_dev = {}
                for k, v in batch.items():
                    batch_dev[k] = v.to(device) if isinstance(v, torch.Tensor) else v
                out = model(batch_dev, return_attention=True)

                # V5 returns nested {cross_mark_attn: {cross_mark_weights, mark_importance, mark_names}};
                # generic CrossMark returns flat {attn_weights}. Support both.
                cm = out.get("cross_mark_attn", {}) or {}
                weights = cm.get("cross_mark_weights")
                imp = cm.get("mark_importance")
                if weights is None and "attn_weights" in out:
                    # generic CrossMark — shape (B, 175, K) — broadcast to (B, 175, K, K)
                    # by treating it as a per-mark importance vector
                    weights = out["attn_weights"]
                    imp = imp if imp is not None else weights
                if weights is not None:
                    cross_mark_chunks.append(weights.detach().cpu().numpy())
                if imp is not None:
                    mark_imp_chunks.append(imp.detach().cpu().numpy())
                mark_names = cm.get("mark_names", active_marks)
                if gids:
                    gene_ids.extend(list(gids))

        if not cross_mark_chunks:
            logger.info("AttentionExport: no attention captured (n_batches=0?).")
            return

        cross_mark = np.concatenate(cross_mark_chunks)
        mark_imp = np.concatenate(mark_imp_chunks) if mark_imp_chunks else None

        np.save(out_dir / "cross_mark_weights.npy", cross_mark)
        if mark_imp is not None:
            np.save(out_dir / "mark_importance.npy", mark_imp)
        with open(out_dir / "mark_names.json", "w", encoding="utf-8") as f:
            json.dump(list(mark_names) if mark_names else [], f,
                      ensure_ascii=False)
        if gene_ids:
            with open(out_dir / "gene_ids.json", "w", encoding="utf-8") as f:
                json.dump(gene_ids, f, ensure_ascii=False)

        logger.info(
            "AttentionExport saved: cross_mark=%s, mark_importance=%s, dir=%s",
            cross_mark.shape,
            None if mark_imp is None else mark_imp.shape,
            os.path.abspath(out_dir),
        )
