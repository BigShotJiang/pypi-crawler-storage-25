"""CC 风格结果报告回调。

在 on_test_end 阶段写入：
  - metrics/test_metrics.json — 指标 JSON
  - metrics/test_predictions.csv — gene_id + true/pred (log1p 和 TPM 空间)
  - summary_report.md — markdown 摘要
  - leaderboard.csv(追加) — 按 mark_tag/fold 追加一行，便于 sweep 聚合

输出位置是 Hydra 的当前运行目录（os.getcwd()）。
"""

import csv
import json
import logging
import os
from datetime import datetime
from pathlib import Path

import numpy as np

from .base import BaseCallback

logger = logging.getLogger(__name__)


def _build_mark_tag(active_marks):
    if not active_marks:
        return "seq_only"
    return "_".join(sorted(active_marks))


class GeneExprReport(BaseCallback):
    """CC-style 摘要报告 + 预测导出 + sweep 级 leaderboard 追加。"""

    def __init__(self, task, config):
        super().__init__(task, config)
        self.config = config
        self.metrics_dir = Path("metrics")
        self.metrics_dir.mkdir(parents=True, exist_ok=True)

    def _active_marks(self):
        marks = getattr(self.task.model, "active_marks", None)
        return list(marks) if marks else []

    def _sweep_leaderboard_path(self):
        # Priority: config override > env var > project-root default `reports/gene_expr/leaderboard.csv`.
        # The default mirrors the forecast pipeline's reports/forecast/ layout so both
        # pipelines have a symmetric "one leaderboard per launcher" structure.
        cfg_lb = None
        try:
            cfg_lb = self.config.get("cc_leaderboard_path", None)
        except Exception:
            cfg_lb = None
        if cfg_lb:
            return cfg_lb
        env_lb = os.environ.get("GENE_EXPR_LEADERBOARD_PATH")
        if env_lb:
            return env_lb
        try:
            from hydra.core.hydra_config import HydraConfig
            project_root = HydraConfig.get().runtime.cwd
        except Exception:
            project_root = os.environ.get("PROJECT_ROOT", os.getcwd())
        default_dir = os.path.join(project_root, "reports", "gene_expr")
        os.makedirs(default_dir, exist_ok=True)
        return os.path.join(default_dir, "leaderboard.csv")

    def on_test_end(self, result):
        metrics = result.get("metrics", {}) or {}
        preds = result.get("predictions")
        targets = result.get("targets")
        gene_ids = result.get("gene_ids", [])

        metrics_path = self.metrics_dir / "test_metrics.json"
        with open(metrics_path, "w", encoding="utf-8") as f:
            json.dump({k: (float(v) if isinstance(v, (int, float, np.floating))
                           else v) for k, v in metrics.items()},
                      f, indent=2, ensure_ascii=False)

        if preds is not None and targets is not None and preds.size > 0:
            import pandas as pd
            true_log = np.asarray(targets).astype(float)
            pred_log = np.asarray(preds).astype(float)
            df = pd.DataFrame({
                "gene_id": list(gene_ids) + [""] * (len(pred_log) - len(gene_ids))
                if len(gene_ids) < len(pred_log) else list(gene_ids)[:len(pred_log)],
                "true_log1p": true_log,
                "pred_log1p": pred_log,
                "true_tpm": np.expm1(true_log),
                "pred_tpm": np.expm1(np.clip(pred_log, 0, 20)),
            })
            df.to_csv(self.metrics_dir / "test_predictions.csv", index=False)

        active_marks = self._active_marks()
        mark_tag = _build_mark_tag(active_marks)

        lines = [
            f"# CC 实验报告 ({mark_tag})",
            f"生成时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
            "",
            "## 配置",
            f"- active_marks: {active_marks}",
            f"- mark_tag: {mark_tag}",
            f"- best_val_loss: {result.get('best_val_loss')}",
            f"- train_epochs: {result.get('train_epochs')}",
            "",
            "## Test 指标",
        ]
        for k, v in metrics.items():
            if isinstance(v, (int, float, np.floating)):
                lines.append(f"- {k}: {float(v):.4f}")
            else:
                lines.append(f"- {k}: {v}")
        with open("summary_report.md", "w", encoding="utf-8") as f:
            f.write("\n".join(lines))

        lb_path = self._sweep_leaderboard_path()
        if lb_path:
            self._append_sweep_leaderboard(lb_path, mark_tag, active_marks, metrics, result)
        logger.info("GeneExprReport written: %s", os.path.abspath(metrics_path))

    @staticmethod
    def _append_sweep_leaderboard(lb_path, mark_tag, active_marks, metrics, result):
        os.makedirs(os.path.dirname(lb_path) or ".", exist_ok=True)
        row = {
            "mark_tag": mark_tag,
            "active_marks": ";".join(active_marks) if active_marks else "",
            "n_marks": len(active_marks),
            "PCC": metrics.get("PCC", ""),
            "SCC": metrics.get("SCC", ""),
            "R2": metrics.get("R2", ""),
            "RMSE": metrics.get("RMSE", ""),
            "MAE": metrics.get("MAE", ""),
            "PCC_TPM": metrics.get("PCC_TPM", ""),
            "R2_TPM": metrics.get("R2_TPM", ""),
            "best_val_loss": result.get("best_val_loss", ""),
            "train_epochs": result.get("train_epochs", ""),
            "run_dir": os.getcwd(),
            "ts": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        }
        file_exists = os.path.exists(lb_path)
        with open(lb_path, "a", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=list(row.keys()))
            if not file_exists:
                writer.writeheader()
            writer.writerow({k: (f"{v:.6f}" if isinstance(v, float) else v)
                             for k, v in row.items()})
