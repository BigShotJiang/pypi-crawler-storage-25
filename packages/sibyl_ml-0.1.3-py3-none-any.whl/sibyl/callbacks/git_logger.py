"""
Git Logger 回调 - 记录 Git 信息
"""
import os
import subprocess
from datetime import datetime
from .base import BaseCallback


class GitLogger(BaseCallback):
    """记录 Git 信息到文件"""

    def __init__(self, task, config):
        super().__init__(task, config)

    def on_train_begin(self):
        """训练开始时保存 git 信息"""
        output_dir = self.config.get('output_dir', '.')
        git_info_path = os.path.join(output_dir, 'git_info.txt')

        try:
            # 获取当前 commit hash
            commit_hash = subprocess.check_output(
                ['git', 'rev-parse', 'HEAD'],
                stderr=subprocess.DEVNULL
            ).decode('utf-8').strip()

            # 获取 git diff
            try:
                diff = subprocess.check_output(['git', 'diff']).decode('utf-8')
            except subprocess.CalledProcessError:
                diff = "No git diff available"

        except (subprocess.CalledProcessError, FileNotFoundError):
            commit_hash = "Git not available or not a git repository"
            diff = ""

        # 写入文件
        with open(git_info_path, 'w', encoding='utf-8') as f:
            f.write(f"Experiment: {self.config.get('experiment_name', 'unknown')}\n")
            f.write(f"Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
            f.write(f"\n=== Git Commit Hash ===\n{commit_hash}\n")
            f.write(f"\n=== Git Diff ===\n{diff}\n")

        print(f"Git info saved to: {git_info_path}")
