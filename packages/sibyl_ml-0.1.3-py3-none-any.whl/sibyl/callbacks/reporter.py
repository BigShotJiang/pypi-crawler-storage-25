"""Legacy BaseCallback adapter for experiment-monitor reporting.

.. note::

    **New code should prefer the** :class:`~sibyl.callbacks.monitor.Monitor`
    **callback instead.** ``Monitor`` is a zero-touch Hydra-native adapter
    (commit ``14f4f39``) that owns batch lifecycle, heartbeat, stop polling,
    resource snapshots, and artifact upload from a single ``callbacks: [...]``
    entry. ``Reporter`` predates that integration and is kept for benchmark
    runners that already wire ``batch_id`` / ``job_id`` env vars manually.

    Recommended wiring::

        # configs/<experiment>.yaml  (or override on the command line)
        defaults:
          - override /callbacks: [..., monitor]

Behaviour summary
-----------------
``Reporter`` forwards Trainer ``epoch_end`` / ``test_end`` events to
``experiment-monitor`` event types. It reads its config from
``configs/monitor.yaml`` (missing or ``enabled: false`` → silent no-op) and
inherits ``batch_id`` / ``job_id`` from env vars written by
``run_benchmark.py`` / ``run_sweep.py``.

Dependencies are imported defensively from ``scripts.common.*``; a missing
``experiment_reporter`` install, a network outage, or a monitor server crash
will never raise into the training loop.
"""
from __future__ import annotations

import os
import sys
import time
from pathlib import Path

from .base import BaseCallback

# scripts/ 不在 sys.path；动态补一下（main.py 跑起来时 cwd 已经是 Hydra run dir，
# 但 PROJECT_ROOT env 永远指向项目根，参见 main.py）
_PROJECT_ROOT = os.environ.get("PROJECT_ROOT")
if _PROJECT_ROOT and _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)

try:
    from scripts.common.monitor_reporter import emit, current_batch_id, current_job_id
except Exception:  # pragma: no cover — helper 缺失 / 路径问题时全部 no-op
    def emit(*_, **__): pass
    def current_batch_id(): return None
    def current_job_id(): return None

try:
    from scripts.common.log_capture import install as _install_log_capture
except Exception:  # pragma: no cover
    def _install_log_capture(*_, **__): return None

try:
    from scripts.common.resource_snapshot import collect_resource_snapshot
except Exception:  # pragma: no cover
    def collect_resource_snapshot(): return {}

try:
    from scripts.common.env_snapshot import collect_env_snapshot
except Exception:  # pragma: no cover
    def collect_env_snapshot(**_): return {}

try:
    from scripts.common.stop_poller import is_stop_requested, start_polling
except Exception:  # pragma: no cover
    def is_stop_requested(): return False
    def start_polling(*_, **__): return None

try:
    from scripts.common.artifact_upload import discover_visualizations, upload_many
except Exception:  # pragma: no cover
    def discover_visualizations(_): return []
    def upload_many(*_, **__): return 0

try:
    from scripts.common.monitor_reporter import _load_cfg as _load_monitor_cfg
except Exception:  # pragma: no cover
    def _load_monitor_cfg(): return None


class Reporter(BaseCallback):
    """把 Trainer 的 epoch/test 事件转成 experiment-monitor 的 event_type。

    在 configs/config.yaml 的 callbacks 列表里加 `reporter` 启用（加了也无害——
    reporter 未配置时自己 no-op）。
    """

    def __init__(self, task, config):
        super().__init__(task, config)
        self._job_id = current_job_id()
        self._batch_id = current_batch_id()
        self._job_start_ts = None
        # 启动后台 stop poller —— 服务器侧 "Cancel batch" 按钮按下后，
        # 这里会感知并让 should_stop() 在下一个 epoch 边界停训。
        self._start_stop_poller()
        # Spawn the heartbeat daemon so monitor's stalled-batch detector
        # stays quiet during long non-event-emitting phases (SHAP, feature
        # importance, big checkpoint saves). Idempotent.
        try:
            from scripts.common.heartbeat import start as _start_hb
            _start_hb()
        except Exception:
            pass

    def _start_stop_poller(self) -> None:
        """读 configs/monitor.yaml + env 里的 batch_id，起一个 daemon 线程。"""
        if not self._batch_id:
            return
        try:
            mcfg = _load_monitor_cfg()
        except Exception:
            mcfg = None
        if not mcfg:
            return
        url = mcfg.get("url")
        token = mcfg.get("token")
        interval = int(mcfg.get("stop_poll_interval", 10))
        try:
            start_polling(url, self._batch_id, token, interval=interval)
        except Exception:
            pass

    def should_stop(self) -> bool:
        """Trainer._check_early_stopping picks this up at every epoch boundary."""
        try:
            return bool(is_stop_requested())
        except Exception:
            return False

    def on_train_begin(self):
        if not self._job_id:
            return
        self._job_start_ts = time.time()
        # 父进程（run_benchmark）已在 spawn 前 emit 了权威的 job_start(model, dataset)。
        # 这里再 emit 一次会覆盖成错的（所有模型类名都叫 `Model`）；只记开始时间即可
        self._emit_env_snapshot()
        # Install log capture handler so WARNING+ records flow to monitor Logs tab.
        _install_log_capture(job_id=self._job_id)

    def on_epoch_end(self, epoch, train_loss, val_metrics):
        if not self._job_id:
            return
        payload = {"epoch": int(epoch), "train_loss": float(train_loss)}
        if isinstance(val_metrics, dict):
            vl = val_metrics.get("val_loss")
            if vl is not None:
                payload["val_loss"] = float(vl)
            # 其它 val_* 指标也一起带上
            for k, v in val_metrics.items():
                if k == "val_loss":
                    continue
                try:
                    payload[k] = float(v)
                except (TypeError, ValueError):
                    continue
        emit("job_epoch", job_id=self._job_id, **payload)
        self._emit_resource_snapshot()

    def on_test_end(self, result):
        if not self._job_id:
            return
        metrics = result.get("metrics", {}) if isinstance(result, dict) else {}
        elapsed = None
        if self._job_start_ts is not None:
            elapsed = int(time.time() - self._job_start_ts)
        # 只取标量数值指标，避免把 tensor / ndarray 塞进 JSON
        clean_metrics = {}
        for k, v in metrics.items():
            try:
                clean_metrics[k] = float(v)
            except (TypeError, ValueError):
                continue
        # ── inject seed so the leaderboard 上能直接看到复现种子 ───────
        seed_val = self._extract_seed()
        if seed_val is not None:
            try:
                clean_metrics["seed"] = float(seed_val)
            except (TypeError, ValueError):
                pass
        # ── inject 10-segment Setting string for monitor leaderboard UI ──
        try:
            from scripts.common.setting_name import compute_setting_name
            clean_metrics["setting"] = compute_setting_name(self.config)
        except Exception:
            pass
        emit("job_done",
             job_id=self._job_id,
             metrics=clean_metrics,
             elapsed_s=elapsed,
             status="DONE")
        # ── best-effort artifact upload ──────────────────────────────
        self._upload_visualizations()

    def _extract_seed(self):
        """从 self.config 里挖 training.seed → seed → None。容错。"""
        try:
            cfg = self.config
            getter = cfg.get if hasattr(cfg, "get") else lambda k, d=None: getattr(cfg, k, d)
            training = getter("training", {}) or {}
            tget = training.get if hasattr(training, "get") else (
                lambda k, d=None: getattr(training, k, d))
            v = tget("seed", None)
            if v is None:
                v = getter("seed", None)
            return v
        except Exception:
            return None

    def _upload_visualizations(self) -> None:
        """扫描 visualizations/*.png 上传到 monitor。失败不影响训练。"""
        try:
            mcfg = _load_monitor_cfg()
            if not mcfg:
                return
            url = mcfg.get("url")
            token = mcfg.get("token")
            if not url or not token:
                return
            run_dir = os.environ.get("HYDRA_RUN_DIR") or os.getcwd()
            paths = discover_visualizations(run_dir)
            if not paths:
                return
            n_ok = upload_many(url, self._job_id, token, paths, kind="image")
            try:
                import logging
                logging.getLogger(__name__).debug(
                    "uploaded %d/%d visualization artifacts for job %s",
                    n_ok, len(paths), self._job_id,
                )
            except Exception:
                pass
        except Exception:
            pass

    # ── helpers ──────────────────────────────────────────────────────

    def _emit_env_snapshot(self) -> None:
        """Emit one-time reproducibility snapshot (git SHA, pip freeze, Hydra config)."""
        try:
            snap = collect_env_snapshot()
            if snap:
                emit("env_snapshot", job_id=self._job_id, **snap)
        except Exception:
            pass

    def _emit_resource_snapshot(self) -> None:
        """Emit current host resource metrics; defensive — never raises."""
        try:
            snap = collect_resource_snapshot()
            if snap:
                emit("resource_snapshot", **snap)
        except Exception:
            pass

    def _infer_dataset(self):
        """从 cfg 里挖 dataset 名，容错处理。"""
        try:
            cfg = getattr(self.task, "config", None)
            # 通常 task.config 是 training 段；dataset 在更上层的 cfg.data_loader.name
            # 这里没办法直接拿；job_id 本身已经带 dataset 前缀（etth1_transformer）
            # 就直接从 job_id split
            if self._job_id and "_" in self._job_id:
                return self._job_id.rsplit("_", 1)[0]
        except Exception:
            pass
        return None
