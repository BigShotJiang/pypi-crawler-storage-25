"""
Leaderboard 回调 - 记录实验结果到排行榜
"""
import os
import sys
import csv
from datetime import datetime
from .base import BaseCallback

# 让 scripts/ 可被 import；main.py 跑起来时 cwd 已被 Hydra chdir 到 run dir，
# 但 PROJECT_ROOT env 永远指向项目根。
_PROJECT_ROOT = os.environ.get("PROJECT_ROOT")
if _PROJECT_ROOT and _PROJECT_ROOT not in sys.path:
    sys.path.insert(0, _PROJECT_ROOT)

try:
    from scripts.common.setting_name import compute_setting_name
except Exception:  # pragma: no cover — helper 缺失时退化为空 setting
    def compute_setting_name(_cfg):
        return ""


class Leaderboard(BaseCallback):
    """记录实验结果到排行榜"""

    def __init__(self, task, config):
        super().__init__(task, config)

        # 排行榜文件路径
        # 本地 leaderboard（当前 run 目录）— 便于单次实验内查看
        self.local_leaderboard_path = 'leaderboard.csv'
        # 全局 leaderboard：按 launcher 类型分子目录
        #   reports/forecast/leaderboard.csv    — 时序预测
        #   reports/gene_expr/leaderboard.csv   — 基因表达（由 gene_expr_report 回调独立管理）
        # 两套实验的 leaderboard 互不干扰，可独立聚合 / 去重。
        try:
            from hydra.core.hydra_config import HydraConfig
            project_root = HydraConfig.get().runtime.cwd
            # 优先从 Hydra 的 runtime.choices 获取激活 launcher 名
            try:
                launcher_name = HydraConfig.get().runtime.choices.get('launcher', 'forecast')
            except Exception:
                launcher_name = 'forecast'
        except Exception:
            project_root = os.environ.get('PROJECT_ROOT', os.getcwd())
            launcher_name = os.environ.get('DEEPTS_LAUNCHER', 'forecast')
        reports_dir = os.path.join(project_root, 'reports', launcher_name)
        os.makedirs(reports_dir, exist_ok=True)
        self.global_leaderboard_path = os.path.join(reports_dir, 'leaderboard.csv')
        self.leaderboard_path = self.local_leaderboard_path

    def on_test_end(self, result):
        """测试结束时记录结果"""
        metrics = result['metrics']
        model_name = self._get_model_name()

        # 获取输出目录路径（只保留 outputs/ 后的相对部分）
        output_dir = os.path.abspath('.')
        idx = output_dir.find('outputs/')
        if idx >= 0:
            output_dir = output_dir[idx:]
        else:
            idx = output_dir.find('outputs/forecast/multirun/')
            if idx >= 0:
                output_dir = output_dir[idx:]

        best_val_loss = result.get('best_val_loss', '') or ''
        train_epochs = result.get('train_epochs', '') or ''

        dataset_name = ''
        if hasattr(self.config, 'data_loader') and hasattr(self.config.data_loader, 'name'):
            dataset_name = self.config.data_loader.name
        elif hasattr(self.config, 'get'):
            dl = self.config.get('data_loader', {})
            if hasattr(dl, 'get'):
                dataset_name = dl.get('name', '')

        def _fmt(v, fmt='.4f'):
            if v == '' or v is None:
                return ''
            try:
                return format(float(v), fmt)
            except (ValueError, TypeError):
                return v

        # Seed 读取优先 cfg.training.seed；缺失时回退到平台默认（2021），
        # 保持与 `src/utils/device.py:set_random_seed` / `configs/config.yaml` 一致。
        seed_val = ''
        try:
            tr = self.config.get('training', None) if hasattr(self.config, 'get') else None
            if tr is not None and hasattr(tr, 'get'):
                seed_val = tr.get('seed', '')
            elif hasattr(self.config, 'training') and hasattr(self.config.training, 'get'):
                seed_val = self.config.training.get('seed', '')
        except Exception:
            seed_val = ''
        if seed_val == '' or seed_val is None:
            seed_val = 2021

        # 紧凑 Setting 串：10 段 underscore-joined，方便跨多 seed / 多 horizon
        # 复现某次具体配置（参考 Time-Series-Library 习惯，但裁掉这套实验里
        # 不会变化的字段）。compute_setting_name 容错；任何异常退化为 ''。
        try:
            setting_str = compute_setting_name(self.config)
        except Exception:
            setting_str = ''

        # 列按语义分组：标识 → 训练运行 → 误差 → 相关性 → 物理违例 → 资源 → 输出
        row = [
            # ---- 标识 ----
            self.config.get('experiment_name', 'unknown'),
            seed_val,
            setting_str,
            datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            model_name,
            dataset_name,
            # ---- 训练运行统计 ----
            train_epochs,
            metrics.get('Total_Batches', ''),
            _fmt(metrics.get('Total_Train_Time', ''), '.2f'),
            _fmt(metrics.get('Avg_Epoch_Time', ''), '.3f'),
            _fmt(metrics.get('Avg_Batch_Time', ''), '.4f'),
            best_val_loss,
            # ---- 误差指标 ----
            metrics.get('MAE', ''),
            metrics.get('MSE', ''),
            metrics.get('RMSE', ''),
            metrics.get('MAPE', ''),
            metrics.get('sMAPE', ''),
            metrics.get('MSPE', ''),
            # ---- 相关性 ----
            metrics.get('R2', ''),
            metrics.get('PCC', ''),
            # ---- 物理违例率 (PVR) ----
            _fmt(metrics.get('PVR_Bounds', ''), '.4f'),
            _fmt(metrics.get('PVR_Monotonicity', ''), '.4f'),
            _fmt(metrics.get('PVR_Smoothness', ''), '.4f'),
            # ---- 资源占用 ----
            metrics.get('CPU_Memory', ''),
            metrics.get('GPU_Memory', ''),
            _fmt(metrics.get('Model_Params', ''), '.4f'),          # 参数量 (M)
            _fmt(metrics.get('Inference_Throughput', ''), '.1f'),  # 推理吞吐 (samples/s)
            # ---- 输出路径 ----
            output_dir
        ]

        # 写入本地 leaderboard（当前 run 目录）
        self._write_row(self.local_leaderboard_path, row)
        print(f"Result added to leaderboard: {self.local_leaderboard_path}")

        # 写入全局 leaderboard（项目根目录）
        self._write_row(self.global_leaderboard_path, row)
        print(f"Result added to global leaderboard: {self.global_leaderboard_path}")

    _HEADER = [
        # 标识（Seed 紧跟 Experiment，便于 multi-seed benchmark 按 (Experiment,Seed) 分组）
        # Setting 是 10 段紧凑串，可在 monitor / 复现脚本里直接 grep
        'Experiment', 'Seed', 'Setting', 'Time', 'Model', 'Dataset',
        # 训练运行统计
        'Train_Epochs', 'Total_Batches',
        'Total_Train_Time_s', 'Avg_Epoch_Time_s', 'Avg_Batch_Time_s',
        'Best_Val_Loss',
        # 误差
        'MAE', 'MSE', 'RMSE', 'MAPE', 'sMAPE', 'MSPE',
        # 相关性
        'R2', 'PCC',
        # 物理违例率 (%)
        'PVR_Bounds', 'PVR_Monotonicity', 'PVR_Smoothness',
        # 资源占用
        'CPU_Memory', 'GPU_Memory', 'Model_Params_M', 'Inference_Throughput',
        # 输出
        'Output_Dir',
    ]

    def _write_row(self, path, row):
        """写入一行到 leaderboard 文件。

        若文件不存在 → 写新 header + row。
        若 file 存在但 header 缺 Seed 或 Setting 列 → 原地迁移：读出所有
        旧行、补齐缺失列后重写整个文件。Pre-existing rows 的 Seed 回填 '2021'
        （平台默认），Setting 回填 ''（旧 row 无法事后重算）。
        Keeps legacy leaderboards forward-compatible with new appends.
        """
        file_exists = os.path.exists(path)
        if file_exists:
            self._migrate_legacy_header_if_needed(path)

        with open(path, 'a', newline='', encoding='utf-8') as f:
            writer = csv.writer(f)
            if not file_exists:
                writer.writerow(self._HEADER)
            writer.writerow(row)

    @staticmethod
    def _migrate_legacy_header_if_needed(path: str) -> None:
        """Re-write a legacy CSV in-place so its header has Seed and Setting.

        Idempotent. Pre-existing rows get Seed=2021 (platform default, see
        configs/config.yaml training.seed) and Setting='' (cannot be recomputed
        after the fact — empty marks the row as legacy).
        """
        try:
            with open(path, 'r', encoding='utf-8', newline='') as f:
                reader = csv.reader(f)
                try:
                    header = next(reader)
                except StopIteration:
                    return  # empty file
                rows = list(reader)
        except OSError:
            return

        changed = False

        # ---- Seed migration (legacy pre-multi-seed CSVs) ----
        if 'Seed' not in header:
            if 'Experiment' in header:
                insert_at = header.index('Experiment') + 1
            else:
                insert_at = 1
            header = header[:insert_at] + ['Seed'] + header[insert_at:]
            rows = [r[:insert_at] + ['2021'] + r[insert_at:] for r in rows]
            changed = True

        # ---- Setting migration (this PR) ----
        if 'Setting' not in header:
            # Prefer right after Seed; else right after Experiment; else col 1.
            if 'Seed' in header:
                insert_at = header.index('Seed') + 1
            elif 'Experiment' in header:
                insert_at = header.index('Experiment') + 1
            else:
                insert_at = 1
            header = header[:insert_at] + ['Setting'] + header[insert_at:]
            rows = [r[:insert_at] + [''] + r[insert_at:] for r in rows]
            changed = True

        if not changed:
            return

        with open(path, 'w', encoding='utf-8', newline='') as f:
            writer = csv.writer(f)
            writer.writerow(header)
            writer.writerows(rows)

    def _get_model_name(self) -> str:
        """获取模型名称"""
        # 尝试从配置中获取
        if hasattr(self.config, 'model'):
            if '_target_' in self.config.model:
                # 从 _target_ 提取
                target = self.config.model['_target_']
                return target.split('.')[-1]
            elif 'name' in self.config.model:
                return self.config.model['name']

        # 尝试从任务获取
        if hasattr(self.task, 'model'):
            return self.task.model.__class__.__name__

        return 'unknown'
