"""
Feature Importance 回调 - 基于梯度的特征重要性分析

NOTE: This callback requires result['inputs'] to be set by the task (a torch.Tensor
of shape [n_samples, seq_len, n_features]). If the key is absent, the callback
gracefully skips with a warning and produces no output.
"""
import os
import csv
import warnings
import numpy as np
import torch
from .base import BaseCallback


class FeatureImportance(BaseCallback):
    """基于梯度的特征重要性分析"""

    def __init__(self, task, config):
        super().__init__(task, config)

    def on_test_end(self, result):
        """测试结束时计算并保存特征重要性"""
        # Check that input data is available
        if 'inputs' not in result:
            warnings.warn(
                "FeatureImportance callback: result['inputs'] not found. "
                "Set result['inputs'] = input_tensor in ForecastTask to enable "
                "gradient-based feature importance. Skipping."
            )
            return

        inputs = result['inputs']  # [n_samples, seq_len, n_features]
        if not isinstance(inputs, torch.Tensor):
            warnings.warn(
                "FeatureImportance callback: result['inputs'] must be a torch.Tensor. "
                "Skipping."
            )
            return

        output_dir = self.config.get('output_dir', '.')
        analysis_dir = os.path.join(output_dir, 'analysis')
        os.makedirs(analysis_dir, exist_ok=True)

        importance_scores = self._compute_gradient_importance(inputs)
        if importance_scores is None:
            return

        self._save_csv(importance_scores, analysis_dir)
        self._save_plot(importance_scores, analysis_dir)

        print(f"Feature importance saved to: {analysis_dir}")

    def _compute_gradient_importance(self, inputs: torch.Tensor):
        """
        Compute per-feature importance as mean |grad| of model output w.r.t. input.

        Args:
            inputs: [n_samples, seq_len, n_features]

        Returns:
            np.ndarray of shape [n_features] or None on error
        """
        model = self.task.model
        device = self.task.device

        # Use at most 100 samples to keep computation light
        max_samples = min(inputs.shape[0], 100)
        x = inputs[:max_samples].clone().to(device).float()
        x.requires_grad_(True)

        model.eval()
        try:
            # cuDNN 要求 RNN backward 在 training 模式下；用 flags 临时禁用 cuDNN
            # 让 LSTM/GRU 能在 eval 模式下算梯度（不触发 dropout、保持确定性）
            with torch.enable_grad(), torch.backends.cudnn.flags(enabled=False):
                # Try transformer-style forward first, then simple fallback
                try:
                    # Build dummy tgt/marks with the same batch size
                    tgt = x[:, -1:, :]  # minimal placeholder
                    src_mark = torch.zeros(x.shape[0], x.shape[1], 1, device=device)
                    tgt_mark = torch.zeros(x.shape[0], 1, 1, device=device)
                    output = model(x, tgt, src_mark, tgt_mark)
                except (TypeError, RuntimeError):
                    output = model(x)

                # Scalar loss: sum of all output values
                loss = output.sum()
                loss.backward()

            if x.grad is None:
                warnings.warn(
                    "FeatureImportance callback: gradients are None. "
                    "Model may not propagate gradients through input. Skipping."
                )
                return None

            # Average absolute gradient across samples and time steps -> [n_features]
            importance = x.grad.abs().mean(dim=(0, 1)).cpu().numpy()
            return importance

        except Exception as e:
            warnings.warn(
                f"FeatureImportance callback: gradient computation failed ({e}). Skipping."
            )
            return None

    def _save_csv(self, importance_scores: np.ndarray, save_dir: str):
        """Save feature importance scores to CSV."""
        csv_path = os.path.join(save_dir, 'feature_importance.csv')
        task_fn = getattr(self.task, 'feature_names', None)
        n = len(importance_scores)
        names = list(task_fn[:n]) if (task_fn and len(task_fn) >= n) else [f'F{i}' for i in range(n)]
        with open(csv_path, 'w', newline='', encoding='utf-8') as f:
            writer = csv.writer(f)
            writer.writerow(['feature_idx', 'feature_name', 'importance_score'])
            for idx, (nm, score) in enumerate(zip(names, importance_scores)):
                writer.writerow([idx, nm, float(score)])

    def _save_plot(self, importance_scores: np.ndarray, save_dir: str):
        """Save horizontal bar chart of feature importances, sorted descending."""
        import matplotlib.pyplot as plt

        # Apply style with graceful fallback
        try:
            plt.style.use('seaborn-v0_8-whitegrid')
        except OSError:
            try:
                plt.style.use('seaborn-whitegrid')
            except OSError:
                pass  # Fall back to default matplotlib style

        n_features = len(importance_scores)
        task_fn = getattr(self.task, 'feature_names', None)
        use_names = task_fn and len(task_fn) >= n_features

        # 特征数 > 30 时只画 top-30，避免图过高；完整数据在 CSV 里
        max_show = 30
        truncated = n_features > max_show
        order_desc = np.argsort(importance_scores)[::-1]  # 重要性降序
        shown = order_desc[:max_show] if truncated else order_desc
        # 画图按升序（最低在下）
        shown_sorted = shown[np.argsort(importance_scores[shown])]
        bars_score = importance_scores[shown_sorted]
        bars_labels = [str(task_fn[i]) if use_names else f'F{i}' for i in shown_sorted]

        n_bars = len(bars_score)
        fig_height = min(6.0, max(3.0, n_bars * 0.22 + 1))
        fig, ax = plt.subplots(figsize=(7, fig_height))

        bars = ax.barh(range(n_bars), bars_score, color='steelblue', edgecolor='white')
        ax.set_yticks(range(n_bars))
        ax.set_yticklabels(bars_labels, fontsize=10)
        ax.set_xlabel('Importance Score (mean |gradient|)', fontsize=12)
        title = 'Gradient-Based Feature Importance'
        if truncated:
            title += f' (Top {max_show}/{n_features})'
        ax.set_title(title, fontsize=13)
        ax.tick_params(axis='x', labelsize=10)

        # 数值标签
        max_s = float(bars_score.max()) if len(bars_score) else 1.0
        for bar, score in zip(bars, bars_score):
            ax.text(
                bar.get_width() + max_s * 0.01,
                bar.get_y() + bar.get_height() / 2,
                f'{score:.4f}',
                va='center',
                fontsize=9
            )

        plt.tight_layout()
        plt.savefig(os.path.join(save_dir, 'feature_importance.png'), dpi=300, bbox_inches='tight')
        plt.close()
