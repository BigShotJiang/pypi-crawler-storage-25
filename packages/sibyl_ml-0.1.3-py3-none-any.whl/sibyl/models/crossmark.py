"""Generic CrossMark model for multi-modal gene expression prediction.

This is the open-source, demo-quality CrossMark distributed with
Sibyl. It exists so that anyone can run, fork, or extend the
multi-omics pipeline (DNA sequence + 0..K epigenetic mark tracks) without
needing the proprietary research model.

Design goals
------------
* I/O contract is ``forward(batch: Dict, return_attention: bool=False) -> Dict``.
* Built from standard, well-known blocks only — 1D conv stems, an adaptive
  pooling reducer to a coarse bin grid, and one cross-attention layer that
  fuses sequence and epigenetic representations per bin position.
* Modest parameter budget (~1M with default config) so it trains on a
  single consumer GPU and converges to a reasonable — but intentionally
  weaker — score than the proprietary research variant (which lives only
  in private forks).
* Pluggable: pick ``active_marks`` at runtime to ablate any subset of the
  five marks (or the empty list for a sequence-only baseline). Forks can
  swap encoders / fusion blocks via subclassing.

Tensor shapes (default config: seq_len=4200, bin_size=24 → 175 bins)
--------------------------------------------------------------------
* ``batch["seq"]``       : ``(B, 4200, 4)`` one-hot DNA
* ``batch["<mark>"]``    : ``(B, 4200)``    epigenetic signal per active mark
* ``out["pred_tpm"]``    : ``(B,)``         regressed log1p(TPM)
* ``out["pred_binary"]`` : ``(B, 2)``       expressed-vs-silent logits
* ``out["attn_weights"]``: ``(B, 175, K)``  per-bin per-mark importance
                                            (only when return_attention=True
                                            AND active_marks is non-empty)
"""

from __future__ import annotations

import logging
from typing import Dict, List, Optional

import torch
import torch.nn as nn
import torch.nn.functional as F

log = logging.getLogger(__name__)

# Default mark vocabulary used by the spike dataset; any subset works.
ALL_EPI_MARKS: List[str] = ["ATAC", "H3K27ac", "H3K27me3", "H3K36me3", "H3K4me3"]
NON_MODAL_KEYS = {"tpm", "is_expressed", "gene_id"}


def _resolve_active_marks(value) -> List[str]:
    """Coerce the ``active_marks`` config value to a plain list of strings.

    Accepts ``None``, OmegaConf ``ListConfig``, or any iterable.
    ``None`` defaults to the full five-mark vocabulary so a user that just
    instantiates ``Model()`` gets a sensible model.
    """
    if value is None:
        return list(ALL_EPI_MARKS)
    return [str(m) for m in value]


class _SeqEncoder(nn.Module):
    """DNA sequence encoder: 1D conv → pool to bin grid → ``(B, n_bins, d_model)``."""

    def __init__(self, d_model: int, kernel_size: int, n_bins: int, dropout: float):
        super().__init__()
        # One small conv stem captures local motifs in the 4-channel one-hot input.
        self.conv = nn.Conv1d(4, d_model, kernel_size=kernel_size,
                              padding=kernel_size // 2)
        # Adaptive pool collapses 4200 bp to n_bins (e.g. 175) for downstream attention.
        self.pool = nn.AdaptiveAvgPool1d(n_bins)
        self.norm = nn.LayerNorm(d_model)
        self.dropout = nn.Dropout(dropout)

    def forward(self, seq: torch.Tensor) -> torch.Tensor:
        # seq: (B, L, 4) → (B, 4, L) for Conv1d
        x = seq.transpose(1, 2)
        x = F.relu(self.conv(x))
        x = self.pool(x)            # (B, d_model, n_bins)
        x = x.transpose(1, 2)       # (B, n_bins, d_model)
        x = self.dropout(self.norm(x))
        return x


class _MarkEncoder(nn.Module):
    """Per-mark epigenetic encoder: same conv-then-pool recipe as the sequence branch."""

    def __init__(self, d_mark: int, kernel_size: int, n_bins: int, dropout: float):
        super().__init__()
        self.conv = nn.Conv1d(1, d_mark, kernel_size=kernel_size,
                              padding=kernel_size // 2)
        self.pool = nn.AdaptiveAvgPool1d(n_bins)
        self.norm = nn.LayerNorm(d_mark)
        self.dropout = nn.Dropout(dropout)

    def forward(self, mark: torch.Tensor) -> torch.Tensor:
        # mark: (B, L) → (B, 1, L)
        x = mark.unsqueeze(1)
        x = F.relu(self.conv(x))
        x = self.pool(x)            # (B, d_mark, n_bins)
        x = x.transpose(1, 2)       # (B, n_bins, d_mark)
        x = self.dropout(self.norm(x))
        return x


class _CrossMarkAttention(nn.Module):
    """Per-bin cross-attention: seq queries attend over the K mark embeddings.

    For every position p in the bin grid we treat the K mark embeddings as a
    tiny K-token sequence and let the seq query attend over them, returning
    a fused vector of size d_model and a length-K attention vector that we
    expose for interpretability.
    """

    def __init__(self, d_model: int, n_heads: int, dropout: float):
        super().__init__()
        self.attn = nn.MultiheadAttention(
            d_model, n_heads, dropout=dropout, batch_first=True)
        self.norm = nn.LayerNorm(d_model)

    def forward(self, seq_tokens: torch.Tensor, mark_tokens: torch.Tensor):
        """seq_tokens: (B, P, D); mark_tokens: (B, P, K, D).

        Returns ``(fused (B, P, D), attn (B, P, K))``.
        """
        B, P, K, D = mark_tokens.shape
        # Flatten (B, P) so each bin position becomes its own attention "batch".
        q = seq_tokens.reshape(B * P, 1, D)
        kv = mark_tokens.reshape(B * P, K, D)
        out, attn = self.attn(q, kv, kv, need_weights=True,
                              average_attn_weights=True)
        # out:  (B*P, 1, D)   attn: (B*P, 1, K)
        out = out.reshape(B, P, D)
        attn = attn.reshape(B, P, K)
        out = self.norm(seq_tokens + out)   # residual + post-norm
        return out, attn


class Model(nn.Module):
    """Generic CrossMark — a compact, fork-friendly multi-omics regressor.

    Parameters (all readable from a Hydra DictConfig)
    -------------------------------------------------
    n_marks: int
        Maximum number of epigenetic marks the model knows about. The actual
        active set is resolved from ``active_marks`` (the YAML interpolates
        from the data-loader's active set so the two stay in sync).
    seq_len: int
        Length of the DNA window in bp (default 4200, matching the spike
        data loader).
    bin_size: int
        Down-sampling factor; ``n_bins = seq_len // bin_size`` (default 24
        → 175 bins).
    d_model: int
        Hidden width for the sequence branch and the fused representation.
    d_mark: int
        Hidden width for the per-mark branch before projection to d_model.
        Defaults to d_model // 2 to keep the parameter count modest.
    n_heads: int
        Heads for the cross-attention block.
    dropout: float
        Applied after every encoder and inside the attention module.
    active_marks: Optional[List[str]]
        Subset of marks to use at runtime; ``None`` → full default vocabulary,
        ``[]`` → sequence-only baseline (epi pathway is omitted entirely).
    """

    NON_MODAL_KEYS = NON_MODAL_KEYS

    def __init__(
        self,
        config: Optional[Dict] = None,
        *,
        n_marks: int = 5,
        seq_len: int = 4200,
        bin_size: int = 24,
        d_model: int = 128,
        d_mark: Optional[int] = None,
        n_heads: int = 4,
        dropout: float = 0.1,
        seq_kernel: int = 15,
        mark_kernel: int = 15,
        active_marks: Optional[List[str]] = None,
    ):
        super().__init__()

        # Hydra path: a single DictConfig is passed positionally; pull fields
        # off it but let direct kwargs override (handy in tests).
        if config is not None:
            n_marks = int(config.get("n_marks", n_marks))
            seq_len = int(config.get("seq_len", seq_len))
            bin_size = int(config.get("bin_size", bin_size))
            d_model = int(config.get("d_model", d_model))
            d_mark = config.get("d_mark", d_mark)
            n_heads = int(config.get("n_heads", n_heads))
            dropout = float(config.get("dropout", dropout))
            seq_kernel = int(config.get("seq_kernel", seq_kernel))
            mark_kernel = int(config.get("mark_kernel", mark_kernel))
            active_marks = config.get("active_marks", active_marks)

        if seq_len % bin_size != 0:
            raise ValueError(
                f"seq_len ({seq_len}) must be divisible by bin_size ({bin_size})")
        n_bins = seq_len // bin_size

        if d_mark is None:
            d_mark = max(32, d_model // 2)
        d_mark = int(d_mark)

        active_marks = _resolve_active_marks(active_marks)

        self.n_marks_max = int(n_marks)
        self.seq_len = seq_len
        self.bin_size = bin_size
        self.n_bins = n_bins
        self.d_model = d_model
        self.d_mark = d_mark
        self.n_heads = n_heads
        self.dropout_p = dropout
        self.active_marks = active_marks
        self.has_epi = len(active_marks) > 0

        # ---- sequence branch (always built) ----
        self.seq_encoder = _SeqEncoder(
            d_model=d_model, kernel_size=seq_kernel,
            n_bins=n_bins, dropout=dropout)

        # ---- per-mark branch (only if any marks active) ----
        if self.has_epi:
            self.mark_encoders = nn.ModuleDict({
                m: _MarkEncoder(
                    d_mark=d_mark, kernel_size=mark_kernel,
                    n_bins=n_bins, dropout=dropout)
                for m in active_marks
            })
            # Project mark embeddings up to d_model so they can share an
            # attention space with the sequence query.
            self.mark_proj = nn.Linear(d_mark, d_model)
            self.cross_attn = _CrossMarkAttention(
                d_model=d_model, n_heads=n_heads, dropout=dropout)

        # ---- prediction heads ----
        # Mean-pool the bin axis, then a small two-layer MLP per task.
        self.head_tpm = nn.Sequential(
            nn.Linear(d_model, 64),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(64, 1),
        )
        self.head_binary = nn.Sequential(
            nn.Linear(d_model, 64),
            nn.ReLU(),
            nn.Linear(64, 2),
        )

        n_params = sum(p.numel() for p in self.parameters())
        log.info(
            "CrossMark (generic) initialized | active_marks=%s | n_bins=%d | params=%d",
            self.active_marks, self.n_bins, n_params,
        )

    # ------------------------------------------------------------------
    # forward
    # ------------------------------------------------------------------
    def forward(
        self,
        batch: Dict[str, torch.Tensor],
        return_attention: bool = False,
    ) -> Dict[str, torch.Tensor]:
        """Run a forward pass.

        Parameters
        ----------
        batch : dict
            Must contain ``"seq"`` of shape ``(B, seq_len, 4)`` and one entry
            per mark in ``self.active_marks`` of shape ``(B, seq_len)``.
            ``tpm``/``is_expressed``/``gene_id`` keys are accepted but ignored.
        return_attention : bool
            If True and at least one mark is active, the output also contains
            ``"attn_weights"`` of shape ``(B, n_bins, K)``.
        """
        seq_tokens = self.seq_encoder(batch["seq"])  # (B, P, D)

        attn_weights: Optional[torch.Tensor] = None

        if self.has_epi:
            # Encode each active mark independently → stack on a new K axis.
            per_mark = []
            for m in self.active_marks:
                if m not in batch:
                    raise KeyError(
                        f"CrossMark: active mark '{m}' missing from batch "
                        f"(keys={list(batch.keys())})")
                per_mark.append(self.mark_encoders[m](batch[m]))  # (B, P, d_mark)
            # mark_stack: (B, P, K, d_mark) → projected to d_model.
            mark_stack = torch.stack(per_mark, dim=2)
            mark_stack = self.mark_proj(mark_stack)               # (B, P, K, D)

            fused, attn_weights = self.cross_attn(seq_tokens, mark_stack)
        else:
            # Sequence-only baseline: skip the epi pathway entirely.
            fused = seq_tokens

        # Position-wise mean pooling collapses the bin axis.
        pooled = fused.mean(dim=1)                                # (B, D)

        pred_tpm = self.head_tpm(pooled).squeeze(-1)              # (B,)
        pred_binary = self.head_binary(pooled)                    # (B, 2)

        out: Dict[str, torch.Tensor] = {
            "pred_tpm": pred_tpm,
            "pred_binary": pred_binary,
        }
        if return_attention and attn_weights is not None:
            out["attn_weights"] = attn_weights
        return out


def count_parameters(model: nn.Module) -> Dict[str, int]:
    """Return ``{"total", "trainable", "frozen"}`` parameter counts."""
    total = sum(p.numel() for p in model.parameters())
    trainable = sum(p.numel() for p in model.parameters() if p.requires_grad)
    return {"total": total, "trainable": trainable, "frozen": total - trainable}
