"""
Models 基类
"""
from abc import ABC, abstractmethod
import torch
import torch.nn as nn


class BaseModel(ABC, nn.Module):
    """所有模型的基类"""

    def __init__(self, config):
        super().__init__()
        self.config = config

    @abstractmethod
    def forward(self, x_enc, x_mark_enc=None, x_dec=None, x_mark_dec=None):
        pass

    def _default_x_dec(self, x_enc):
        """当调用方未提供 x_dec 时，按 Informer/Autoformer 约定构造：
            x_dec = [x_enc[:, -label_len:, :], zeros(pred_len)]
        有 `label_len` 属性则用之，否则退化为 pred_len。
        """
        pred_len = getattr(self, 'pred_len', None) or self.config.get('pred_len', 24)
        label_len = getattr(self, 'label_len', None) or self.config.get('label_len', pred_len)
        label_len = min(label_len, x_enc.shape[1])

        label_part = x_enc[:, -label_len:, :]
        future_part = torch.zeros(
            x_enc.shape[0], pred_len, x_enc.shape[2],
            device=x_enc.device, dtype=x_enc.dtype,
        )
        return torch.cat([label_part, future_part], dim=1)

    def get_model_name(self):
        return self.__class__.__name__
