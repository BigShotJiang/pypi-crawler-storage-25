"""
DUET 模型 (KDD 2025) - Dual Clustering Enhanced Multivariate Time Series Forecasting
Reference: https://github.com/decisionintelligence/DUET

核心：Channel Independent + 双聚类（时间模式聚类 + 通道 Mahalanobis mask），
然后用 channel-level transformer 融合跨通道关系。
"""
import torch
import torch.nn as nn
from einops import rearrange

from .base import BaseModel
from ..layers.duet.linear_extractor_cluster import Linear_extractor_cluster
from ..layers.duet.masked_attention import (
    Mahalanobis_mask, Encoder, EncoderLayer, FullAttention, AttentionLayer,
)


class Model(BaseModel):
    """DUET: Dual clusterer (pattern + channel) with mahalanobis mask."""

    def __init__(self, config):
        super().__init__(config)

        # Ensure required defaults
        self.pred_len = config.pred_len
        self.CI = config.get('CI', True)
        self.n_vars = config.get('enc_in', 7)
        enc_in = self.n_vars
        seq_len = config.get('seq_len', 96)
        d_model = config.get('d_model', 512)
        d_ff = config.get('d_ff', 2048)
        n_heads = config.get('n_heads', 8)
        e_layers = config.get('e_layers', 2)
        dropout = config.get('dropout', 0.2)
        factor = config.get('factor', 1)
        activation = config.get('activation', 'gelu')
        output_attention = config.get('output_attention', False)
        fc_dropout = config.get('fc_dropout', 0.2)

        self.cluster = Linear_extractor_cluster(config)
        self.mask_generator = Mahalanobis_mask(seq_len)

        self.Channel_transformer = Encoder(
            [
                EncoderLayer(
                    AttentionLayer(
                        FullAttention(
                            True, factor,
                            attention_dropout=dropout,
                            output_attention=output_attention,
                        ),
                        d_model, n_heads,
                    ),
                    d_model, d_ff,
                    dropout=dropout, activation=activation,
                )
                for _ in range(e_layers)
            ],
            norm_layer=nn.LayerNorm(d_model),
        )
        self.linear_head = nn.Sequential(
            nn.Linear(d_model, self.pred_len),
            nn.Dropout(fc_dropout),
        )

    def forward(self, x_enc, x_mark_enc=None, x_dec=None, x_mark_dec=None):
        # 保留 fp32 autocast 禁用——即使全局 AMP=false 也无害，且为未来 AMP 启用（如 seq_len=128）
        # 提供防御（DUET 的 Mahalanobis mask / MoE noisy_gating 在 FP16 下有 NaN 风险）
        if x_enc.is_cuda:
            with torch.amp.autocast('cuda', enabled=False):
                return self._forward_impl(x_enc.float())
        return self._forward_impl(x_enc)

    def _forward_impl(self, x_enc):
        # x_enc: [B, L, N]
        if self.CI:
            channel_independent_input = rearrange(x_enc, 'b l n -> (b n) l 1')
            reshaped_output, _ = self.cluster(channel_independent_input)
            temporal_feature = rearrange(reshaped_output, '(b n) l 1 -> b l n', b=x_enc.shape[0])
        else:
            temporal_feature, _ = self.cluster(x_enc)

        # B x d_model x n_vars -> B x n_vars x d_model
        temporal_feature = rearrange(temporal_feature, 'b d n -> b n d')

        if self.n_vars > 1:
            changed_input = rearrange(x_enc, 'b l n -> b n l')
            channel_mask = self.mask_generator(changed_input)
            channel_group_feature, _ = self.Channel_transformer(
                x=temporal_feature, attn_mask=channel_mask,
            )
            output = self.linear_head(channel_group_feature)
        else:
            output = self.linear_head(temporal_feature)

        # [B, N, pred_len] -> [B, pred_len, N]
        output = rearrange(output, 'b n d -> b d n')
        output = self.cluster.revin(output, 'denorm')
        return output[:, -self.pred_len:, :]
