"""
DLinear 模型 (AAAI 2023) - TSL 对齐实现
Reference: github.com/thuml/Time-Series-Library/models/DLinear.py

序列分解 + 两条线性投影（seasonal / trend）。
关键：权重初始化为 1/seq_len（均匀平均），与 TSL 完全一致。
"""
import torch
import torch.nn as nn

from .base import BaseModel
from ..layers.decomposition import series_decomp


class Model(BaseModel):
    def __init__(self, config):
        super().__init__(config)

        self.seq_len = config.seq_len
        self.pred_len = config.pred_len
        self.enc_in = config.get('enc_in', 7)
        self.c_out = config.get('c_out', self.enc_in)
        self.individual = config.get('individual', False)
        self.channels = self.enc_in

        # Series decomposition
        self.decompsition = series_decomp(config.get('moving_avg', 25))

        if self.individual:
            self.Linear_Seasonal = nn.ModuleList()
            self.Linear_Trend = nn.ModuleList()
            for _ in range(self.channels):
                self.Linear_Seasonal.append(nn.Linear(self.seq_len, self.pred_len))
                self.Linear_Trend.append(nn.Linear(self.seq_len, self.pred_len))
                self.Linear_Seasonal[-1].weight = nn.Parameter(
                    (1 / self.seq_len) * torch.ones([self.pred_len, self.seq_len])
                )
                self.Linear_Trend[-1].weight = nn.Parameter(
                    (1 / self.seq_len) * torch.ones([self.pred_len, self.seq_len])
                )
        else:
            self.Linear_Seasonal = nn.Linear(self.seq_len, self.pred_len)
            self.Linear_Trend = nn.Linear(self.seq_len, self.pred_len)
            self.Linear_Seasonal.weight = nn.Parameter(
                (1 / self.seq_len) * torch.ones([self.pred_len, self.seq_len])
            )
            self.Linear_Trend.weight = nn.Parameter(
                (1 / self.seq_len) * torch.ones([self.pred_len, self.seq_len])
            )

        # 可选的特征数投影：enc_in -> c_out
        self.projection = (nn.Linear(self.enc_in, self.c_out)
                           if self.c_out != self.enc_in else None)

    def encoder(self, x):
        seasonal_init, trend_init = self.decompsition(x)
        seasonal_init = seasonal_init.permute(0, 2, 1)
        trend_init = trend_init.permute(0, 2, 1)

        if self.individual:
            seasonal_output = torch.zeros(
                [seasonal_init.size(0), seasonal_init.size(1), self.pred_len],
                dtype=seasonal_init.dtype, device=seasonal_init.device,
            )
            trend_output = torch.zeros(
                [trend_init.size(0), trend_init.size(1), self.pred_len],
                dtype=trend_init.dtype, device=trend_init.device,
            )
            for i in range(self.channels):
                seasonal_output[:, i, :] = self.Linear_Seasonal[i](seasonal_init[:, i, :])
                trend_output[:, i, :] = self.Linear_Trend[i](trend_init[:, i, :])
        else:
            seasonal_output = self.Linear_Seasonal(seasonal_init)
            trend_output = self.Linear_Trend(trend_init)

        x = seasonal_output + trend_output
        return x.permute(0, 2, 1)

    def forward(self, x_enc, x_mark_enc=None, x_dec=None, x_mark_dec=None):
        dec_out = self.encoder(x_enc)
        if self.projection is not None:
            dec_out = self.projection(dec_out)
        return dec_out[:, -self.pred_len:, :]
