"""
Models 工厂类 - 自动扫描和延迟加载
"""
import os
import importlib
from typing import Dict, Type


class LazyModelDict(dict):
    """
    智能懒加载字典
    自动扫描 models 目录，延迟导入模型
    """

    def __init__(self, models_dir: str = 'sibyl.models'):
        self.models_dir = models_dir
        # 自动扫描模型目录
        model_map = self._scan_models_directory()
        super().__init__(model_map)

    def _scan_models_directory(self) -> Dict[str, str]:
        """
        自动扫描 models 文件夹下的所有 .py 文件
        Returns:
            {'Transformer': 'sibyl.models.transformer', ...}
        """
        model_map = {}

        # 用 __file__ 同级目录，确保 Hydra chdir 后仍有效
        dir_path = os.path.dirname(os.path.abspath(__file__))

        if not os.path.isdir(dir_path):
            return model_map

        exclude_files = ['__init__.py', 'base.py', 'factory.py']

        for filename in os.listdir(dir_path):
            # 忽略特定文件和非 .py 文件
            if (filename.endswith('.py') and
                filename not in exclude_files):

                # 去掉 .py 后缀得到模块名
                module_name = filename[:-3]

                # 构建完整导入路径
                full_path = f"{self.models_dir}.{module_name}"

                # 存入字典
                model_map[module_name] = full_path

        return model_map

    def __getitem__(self, key: str):
        """获取模型类，延迟导入"""
        if key in self:
            value = super().__getitem__(key)
            # 如果值是字符串（模块路径），需要延迟导入
            if isinstance(value, str):
                # 继续执行延迟加载逻辑
                module_path = value
            else:
                # 已经是类，直接返回
                return value
        else:
            raise NotImplementedError(
                f"Model [{key}] not found in '{self.models_dir}' directory. "
                f"Available: {list(self.keys())}"
            )

        # 延迟导入模块
        try:
            module = importlib.import_module(module_path)
        except ImportError as e:
            raise ImportError(
                f"Failed to import model [{key}] from {module_path}. "
                f"Dependencies missing?"
            ) from e

        # 尝试寻找模型类
        if hasattr(module, 'Model'):
            model_class = module.Model
        elif hasattr(module, key):
            model_class = getattr(module, key)
        else:
            raise AttributeError(
                f"Module {module_path} has no class 'Model' or '{key}'"
            )

        # 缓存已导入的类
        super().__setitem__(key, model_class)
        return model_class

    def list_available(self) -> list:
        """列出所有可用模型"""
        return list(self.keys())

    def reload(self, key: str) -> Type:
        """重新加载指定模型（开发调试用）"""
        if key in self and key not in self._scan_models_directory():
            del self[key]
        return self[key]


# 创建懒加载字典（自动扫描 models 目录）
model_dict = LazyModelDict('sibyl.models')


def get_model(name: str, config):
    """
    获取模型实例
    Args:
        name: 模型名称（文件名），如 'Transformer'
        config: 模型配置
    Returns:
        模型实例
    """
    model_class = model_dict[name]
    return model_class(config)


def list_models():
    """列出所有可用模型"""
    return model_dict.list_available()
