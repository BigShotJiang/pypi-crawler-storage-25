"""
SOFTS 模型 (NeurIPS 2024) - Series-cOre Fused Time Series forecasting
Reference: https://github.com/Secilia-Cxy/SOFTS

核心：STar Aggregate-Redistribute 模块，用全局 core representation 替代 attention。
"""
import torch
import torch.nn as nn
import torch.nn.functional as F

from .base import BaseModel
from ..layers.embed import DataEmbedding_inverted
from ..layers.encoder import Encoder, EncoderLayer


class STAR(nn.Module):
    """STar Aggregate-Redistribute Module"""

    def __init__(self, d_series, d_core):
        super().__init__()
        self.gen1 = nn.Linear(d_series, d_series)
        self.gen2 = nn.Linear(d_series, d_core)
        self.gen3 = nn.Linear(d_series + d_core, d_series)
        self.gen4 = nn.Linear(d_series, d_series)

    def forward(self, input, *args, **kwargs):
        batch_size, channels, d_series = input.shape

        combined_mean = F.gelu(self.gen1(input))
        combined_mean = self.gen2(combined_mean)

        if self.training:
            ratio = F.softmax(combined_mean, dim=1)
            ratio = ratio.permute(0, 2, 1)
            ratio = ratio.reshape(-1, channels)
            indices = torch.multinomial(ratio, 1)
            indices = indices.view(batch_size, -1, 1).permute(0, 2, 1)
            combined_mean = torch.gather(combined_mean, 1, indices)
            combined_mean = combined_mean.repeat(1, channels, 1)
        else:
            weight = F.softmax(combined_mean, dim=1)
            combined_mean = torch.sum(combined_mean * weight, dim=1, keepdim=True).repeat(1, channels, 1)

        combined_mean_cat = torch.cat([input, combined_mean], -1)
        combined_mean_cat = F.gelu(self.gen3(combined_mean_cat))
        combined_mean_cat = self.gen4(combined_mean_cat)
        return combined_mean_cat, None


class Model(BaseModel):
    """SOFTS: STar aggregation on inverted DataEmbedding."""

    def __init__(self, config):
        super().__init__(config)
        self.seq_len = config.get('seq_len', 96)
        self.pred_len = config.pred_len

        d_model = config.get('d_model', 512)
        d_ff = config.get('d_ff', 512)
        d_core = config.get('d_core', 512)
        e_layers = config.get('e_layers', 2)
        dropout = config.get('dropout', 0.1)
        activation = config.get('activation', 'gelu')
        self.use_norm = config.get('use_norm', True)

        self.enc_embedding = DataEmbedding_inverted(self.seq_len, d_model, dropout=dropout)
        self.encoder = Encoder(
            [
                EncoderLayer(
                    STAR(d_model, d_core),
                    d_model, d_ff,
                    dropout=dropout, activation=activation,
                )
                for _ in range(e_layers)
            ],
        )
        self.projection = nn.Linear(d_model, self.pred_len, bias=True)

    def forecast(self, x_enc, x_mark_enc):
        if self.use_norm:
            means = x_enc.mean(1, keepdim=True).detach()
            x_enc = x_enc - means
            stdev = torch.sqrt(torch.var(x_enc, dim=1, keepdim=True, unbiased=False) + 1e-5)
            x_enc = x_enc / stdev

        _, _, N = x_enc.shape
        enc_out = self.enc_embedding(x_enc, x_mark_enc)
        enc_out, _ = self.encoder(enc_out, attn_mask=None)
        dec_out = self.projection(enc_out).permute(0, 2, 1)[:, :, :N]

        if self.use_norm:
            dec_out = dec_out * stdev[:, 0, :].unsqueeze(1).repeat(1, self.pred_len, 1)
            dec_out = dec_out + means[:, 0, :].unsqueeze(1).repeat(1, self.pred_len, 1)
        return dec_out

    def forward(self, x_enc, x_mark_enc=None, x_dec=None, x_mark_dec=None):
        dec_out = self.forecast(x_enc, x_mark_enc)
        return dec_out[:, -self.pred_len:, :]
