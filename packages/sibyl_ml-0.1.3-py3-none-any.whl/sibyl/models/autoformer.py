"""
Autoformer 模型 (NeurIPS 2021) - TSL 对齐实现
Reference: github.com/thuml/Time-Series-Library/models/Autoformer.py

Auto-correlation + 渐进式分解 + trend 累加（完整 encoder/decoder）。
"""
import torch
import torch.nn as nn
import torch.nn.functional as F

from .base import BaseModel
from ..layers.embed import DataEmbedding_wo_pos
from ..layers.autocorrelation import AutoCorrelation, AutoCorrelationLayer
from ..layers.autoformer_encdec import (
    Encoder, Decoder, EncoderLayer, DecoderLayer,
)
from ..layers.decomposition import series_decomp, my_Layernorm


class Model(BaseModel):
    """Autoformer：series-wise connection，O(L log L) 时间复杂度。"""

    def __init__(self, config):
        super().__init__(config)

        self.seq_len = config.get('seq_len', 96)
        self.pred_len = config.pred_len
        self.label_len = config.get('label_len', self.pred_len)
        self.enc_in = config.get('enc_in', 7)
        self.dec_in = config.get('dec_in', self.enc_in)
        self.c_out = config.get('c_out', self.enc_in)
        self.d_model = config.get('d_model', 128)
        self.n_heads = config.get('n_heads', 8)
        self.e_layers = config.get('e_layers', 2)
        self.d_layers = config.get('d_layers', 1)
        self.d_ff = config.get('d_ff', 512)
        self.dropout = config.get('dropout', 0.1)
        self.activation = config.get('activation', 'gelu')
        self.factor = config.get('factor', 1)
        self.moving_avg_size = config.get('moving_avg', 25)
        self.embed = config.get('embed', 'timeF')
        self.freq = config.get('freq', 'h')

        # Decomp（用于从 x_enc 初始化 seasonal/trend）
        self.decomp = series_decomp(self.moving_avg_size)

        # Embedding（不含位置编码，由分解提供隐式时序信息）
        self.enc_embedding = DataEmbedding_wo_pos(
            self.enc_in, self.d_model, self.embed, self.freq, self.dropout
        )
        self.dec_embedding = DataEmbedding_wo_pos(
            self.dec_in, self.d_model, self.embed, self.freq, self.dropout
        )

        # Encoder
        self.encoder = Encoder(
            [
                EncoderLayer(
                    AutoCorrelationLayer(
                        AutoCorrelation(False, self.factor,
                                        attention_dropout=self.dropout,
                                        output_attention=False),
                        self.d_model, self.n_heads,
                    ),
                    self.d_model, self.d_ff,
                    moving_avg_size=self.moving_avg_size,
                    dropout=self.dropout, activation=self.activation,
                )
                for _ in range(self.e_layers)
            ],
            norm_layer=my_Layernorm(self.d_model),
        )

        # Decoder
        self.decoder = Decoder(
            [
                DecoderLayer(
                    AutoCorrelationLayer(
                        AutoCorrelation(True, self.factor,
                                        attention_dropout=self.dropout,
                                        output_attention=False),
                        self.d_model, self.n_heads,
                    ),
                    AutoCorrelationLayer(
                        AutoCorrelation(False, self.factor,
                                        attention_dropout=self.dropout,
                                        output_attention=False),
                        self.d_model, self.n_heads,
                    ),
                    self.d_model, self.c_out, self.d_ff,
                    moving_avg_size=self.moving_avg_size,
                    dropout=self.dropout, activation=self.activation,
                )
                for _ in range(self.d_layers)
            ],
            norm_layer=my_Layernorm(self.d_model),
            projection=nn.Linear(self.d_model, self.c_out, bias=True),
        )

    def forecast(self, x_enc, x_mark_enc, x_dec, x_mark_dec):
        # 初始化 trend（均值） 与 seasonal（输入分解的 seasonal 部分）
        # c_out < enc_in 时 decoder projection 输出 c_out 通道，trend_init 需对齐到 c_out
        mean = torch.mean(x_enc, dim=1).unsqueeze(1).repeat(1, self.pred_len, 1)
        zeros = torch.zeros(
            [x_dec.shape[0], self.pred_len, x_dec.shape[2]],
            device=x_enc.device,
        )
        seasonal_init, trend_init = self.decomp(x_enc)
        if self.c_out != x_enc.shape[-1]:
            trend_init = trend_init[:, :, :self.c_out]
            mean = mean[:, :, :self.c_out]
        trend_init = torch.cat([trend_init[:, -self.label_len:, :], mean], dim=1)
        seasonal_init = torch.cat([seasonal_init[:, -self.label_len:, :], zeros], dim=1)

        # enc
        enc_out = self.enc_embedding(x_enc, x_mark_enc)
        enc_out, _ = self.encoder(enc_out, attn_mask=None)

        # dec
        dec_out = self.dec_embedding(seasonal_init, x_mark_dec)
        seasonal_part, trend_part = self.decoder(
            dec_out, enc_out, x_mask=None, cross_mask=None, trend=trend_init,
        )

        return trend_part + seasonal_part

    def forward(self, x_enc, x_mark_enc=None, x_dec=None, x_mark_dec=None):
        if x_dec is None:
            x_dec = self._default_x_dec(x_enc)
        dec_out = self.forecast(x_enc, x_mark_enc, x_dec, x_mark_dec)
        return dec_out[:, -self.pred_len:, :]
