"""
TimesNet 模型 (ICLR 2023) - TSL 对齐实现
Reference: github.com/thuml/Time-Series-Library/models/TimesNet.py

要点：
- FFT 检测 top-k 周期（top_list = T // freq_index），每个周期对应 2D reshape
- 2D Inception conv 建模周期内 / 周期间变化
- 关键改动：输入先通过 `predict_linear` 从 seq_len 扩展到 seq_len + pred_len，
  再送入 TimesBlock；之前的实现只对 seq_len 建模，丢掉了未来位置的表示能力。
- RevIN 标准化（NSformer 风格）。
"""
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.fft

from .base import BaseModel
from ..layers.embed import DataEmbedding
from ..layers.inception import Inception_Block_V1


def FFT_for_Period(x, k=2):
    # x: [B, T, C]
    xf = torch.fft.rfft(x, dim=1)
    # 频率幅度（在 batch 与 channel 维度取平均）
    frequency_list = abs(xf).mean(0).mean(-1)
    frequency_list[0] = 0  # 去掉 DC
    _, top_list = torch.topk(frequency_list, k)
    top_list = top_list.detach().cpu().numpy()
    period = x.shape[1] // top_list
    return period, abs(xf).mean(-1)[:, top_list]


class TimesBlock(nn.Module):
    def __init__(self, config):
        super().__init__()
        self.seq_len = config.get('seq_len', 96)
        self.pred_len = config.pred_len
        self.k = config.get('top_k', 5)

        d_model = config.get('d_model', 64)
        d_ff = config.get('d_ff', 64)
        num_kernels = config.get('num_kernels', 6)

        # 参数高效：两次 Inception + GELU
        self.conv = nn.Sequential(
            Inception_Block_V1(d_model, d_ff, num_kernels=num_kernels),
            nn.GELU(),
            Inception_Block_V1(d_ff, d_model, num_kernels=num_kernels),
        )

    def forward(self, x):
        B, T, N = x.size()
        period_list, period_weight = FFT_for_Period(x, self.k)

        res = []
        for i in range(self.k):
            period = period_list[i]
            if (self.seq_len + self.pred_len) % period != 0:
                length = (((self.seq_len + self.pred_len) // period) + 1) * period
                padding = torch.zeros(
                    [x.shape[0], (length - (self.seq_len + self.pred_len)), x.shape[2]],
                    device=x.device,
                )
                out = torch.cat([x, padding], dim=1)
            else:
                length = self.seq_len + self.pred_len
                out = x

            # 1D -> 2D: [B, length//period, period, N] -> [B, N, length//period, period]
            out = out.reshape(B, length // period, period, N).permute(0, 3, 1, 2).contiguous()
            out = self.conv(out)
            # 2D -> 1D
            out = out.permute(0, 2, 3, 1).reshape(B, -1, N)
            res.append(out[:, :(self.seq_len + self.pred_len), :])

        res = torch.stack(res, dim=-1)
        # 按频谱幅度加权聚合
        period_weight = F.softmax(period_weight, dim=1)
        period_weight = period_weight.unsqueeze(1).unsqueeze(1).repeat(1, T, N, 1)
        res = torch.sum(res * period_weight, -1)
        return res + x


class Model(BaseModel):
    def __init__(self, config):
        super().__init__(config)

        self.seq_len = config.get('seq_len', 96)
        self.pred_len = config.pred_len
        self.label_len = config.get('label_len', self.pred_len)
        self.enc_in = config.get('enc_in', 7)
        self.c_out = config.get('c_out', self.enc_in)
        self.d_model = config.get('d_model', 64)
        self.d_ff = config.get('d_ff', 64)
        self.e_layers = config.get('e_layers', 2)
        self.dropout = config.get('dropout', 0.1)
        self.top_k = config.get('top_k', 5)
        self.num_kernels = config.get('num_kernels', 6)
        self.embed = config.get('embed', 'timeF')
        self.freq = config.get('freq', 'h')

        self.model = nn.ModuleList([TimesBlock(config) for _ in range(self.e_layers)])
        self.enc_embedding = DataEmbedding(
            self.enc_in, self.d_model, self.embed, self.freq, self.dropout
        )
        self.layer = self.e_layers
        self.layer_norm = nn.LayerNorm(self.d_model)

        # 关键：将编码后的时间维度从 seq_len 扩展到 seq_len + pred_len
        self.predict_linear = nn.Linear(self.seq_len, self.pred_len + self.seq_len)
        self.projection = nn.Linear(self.d_model, self.c_out, bias=True)

    def forecast(self, x_enc, x_mark_enc, x_dec, x_mark_dec):
        # RevIN
        means = x_enc.mean(1, keepdim=True).detach()
        x_enc = x_enc - means
        stdev = torch.sqrt(torch.var(x_enc, dim=1, keepdim=True, unbiased=False) + 1e-5)
        x_enc = x_enc / stdev

        enc_out = self.enc_embedding(x_enc, x_mark_enc)  # [B, T, C]
        enc_out = self.predict_linear(enc_out.permute(0, 2, 1)).permute(0, 2, 1)

        for i in range(self.layer):
            enc_out = self.layer_norm(self.model[i](enc_out))

        dec_out = self.projection(enc_out)

        total_len = self.pred_len + self.seq_len
        # c_out < enc_in 时，RevIN 统计量只取前 c_out 通道以匹配 projection 输出
        stdev_use = stdev[:, 0, :self.c_out] if self.c_out != stdev.shape[-1] else stdev[:, 0, :]
        means_use = means[:, 0, :self.c_out] if self.c_out != means.shape[-1] else means[:, 0, :]
        dec_out = dec_out * stdev_use.unsqueeze(1).repeat(1, total_len, 1)
        dec_out = dec_out + means_use.unsqueeze(1).repeat(1, total_len, 1)
        return dec_out

    def forward(self, x_enc, x_mark_enc=None, x_dec=None, x_mark_dec=None):
        dec_out = self.forecast(x_enc, x_mark_enc, x_dec, x_mark_dec)
        return dec_out[:, -self.pred_len:, :]
