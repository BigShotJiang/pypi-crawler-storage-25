"""
iTransformer 模型 (ICLR 2024) - TSL 对齐实现
Reference: github.com/thuml/Time-Series-Library/models/iTransformer.py

倒置嵌入：把变量当 token，时间当特征；attention 作用于变量间关系。
输入做 instance RevIN 标准化（NSformer 风格），避免非平稳数据的激活漂移。
"""
import torch
import torch.nn as nn
import torch.nn.functional as F

from .base import BaseModel
from ..layers.embed import DataEmbedding_inverted
from ..layers.attention import FullAttention, AttentionLayer
from ..layers.encoder import Encoder, EncoderLayer


class Model(BaseModel):
    def __init__(self, config):
        super().__init__(config)

        self.seq_len = config.get('seq_len', 96)
        self.pred_len = config.pred_len
        self.enc_in = config.get('enc_in', 7)
        self.c_out = config.get('c_out', self.enc_in)
        self.d_model = config.get('d_model', 128)
        self.n_heads = config.get('n_heads', 8)
        self.e_layers = config.get('e_layers', 2)
        self.d_ff = config.get('d_ff', 512)
        self.dropout = config.get('dropout', 0.1)
        self.activation = config.get('activation', 'gelu')
        self.factor = config.get('factor', 1)
        self.embed = config.get('embed', 'timeF')
        self.freq = config.get('freq', 'h')

        # Embedding: [B, L, N] -> [B, N(+mark), d_model]
        self.enc_embedding = DataEmbedding_inverted(
            self.seq_len, self.d_model, self.embed, self.freq, self.dropout
        )

        # Encoder: attention over variate tokens
        self.encoder = Encoder(
            [
                EncoderLayer(
                    AttentionLayer(
                        FullAttention(False, self.factor,
                                      attention_dropout=self.dropout,
                                      output_attention=False),
                        self.d_model, self.n_heads,
                    ),
                    self.d_model, self.d_ff,
                    dropout=self.dropout, activation=self.activation,
                )
                for _ in range(self.e_layers)
            ],
            norm_layer=nn.LayerNorm(self.d_model),
        )

        # Projection: d_model -> pred_len（按 variate 独立预测）
        self.projection = nn.Linear(self.d_model, self.pred_len, bias=True)

    def forecast(self, x_enc, x_mark_enc, x_dec, x_mark_dec):
        # --- RevIN normalization ---
        means = x_enc.mean(1, keepdim=True).detach()
        x_enc = x_enc - means
        stdev = torch.sqrt(torch.var(x_enc, dim=1, keepdim=True, unbiased=False) + 1e-5)
        x_enc = x_enc / stdev

        _, _, N = x_enc.shape

        # Embedding: [B, N(+mark), d_model]
        enc_out = self.enc_embedding(x_enc, x_mark_enc)
        enc_out, _ = self.encoder(enc_out, attn_mask=None)

        # 投影：[B, N(+mark), pred_len] -> [B, pred_len, N(+mark)] -> 取前 N 列
        dec_out = self.projection(enc_out).permute(0, 2, 1)[:, :, :N]

        # --- De-normalization ---
        dec_out = dec_out * stdev[:, 0, :].unsqueeze(1).repeat(1, self.pred_len, 1)
        dec_out = dec_out + means[:, 0, :].unsqueeze(1).repeat(1, self.pred_len, 1)
        return dec_out

    def forward(self, x_enc, x_mark_enc=None, x_dec=None, x_mark_dec=None):
        dec_out = self.forecast(x_enc, x_mark_enc, x_dec, x_mark_dec)
        return dec_out[:, -self.pred_len:, :]
