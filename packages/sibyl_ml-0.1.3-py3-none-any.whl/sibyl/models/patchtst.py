"""
PatchTST 模型 (ICLR 2023) - TSL 对齐实现
Reference: github.com/thuml/Time-Series-Library/models/PatchTST.py

通道独立 + patch 嵌入 + Transformer encoder + Flatten 预测头 + RevIN 标准化。
"""
import torch
import torch.nn as nn

from .base import BaseModel
from ..layers.embed import PatchEmbedding
from ..layers.attention import FullAttention, AttentionLayer
from ..layers.encoder import Encoder, EncoderLayer


class _Transpose(nn.Module):
    def __init__(self, *dims, contiguous=False):
        super().__init__()
        self.dims, self.contiguous = dims, contiguous

    def forward(self, x):
        if self.contiguous:
            return x.transpose(*self.dims).contiguous()
        return x.transpose(*self.dims)


class FlattenHead(nn.Module):
    """PatchTST 的预测头：flatten + linear + dropout。"""

    def __init__(self, n_vars, nf, target_window, head_dropout=0):
        super().__init__()
        self.n_vars = n_vars
        self.flatten = nn.Flatten(start_dim=-2)
        self.linear = nn.Linear(nf, target_window)
        self.dropout = nn.Dropout(head_dropout)

    def forward(self, x):
        # x: [bs, nvars, d_model, patch_num]
        x = self.flatten(x)
        x = self.linear(x)
        x = self.dropout(x)
        return x


class Model(BaseModel):
    def __init__(self, config, patch_len=16, stride=8):
        super().__init__(config)

        self.seq_len = config.get('seq_len', 96)
        self.pred_len = config.pred_len
        self.enc_in = config.get('enc_in', 7)
        self.d_model = config.get('d_model', 128)
        self.n_heads = config.get('n_heads', 8)
        self.e_layers = config.get('e_layers', 2)
        self.d_ff = config.get('d_ff', 512)
        self.dropout = config.get('dropout', 0.1)
        self.activation = config.get('activation', 'gelu')
        self.factor = config.get('factor', 1)

        self.patch_len = config.get('patch_len', patch_len)
        self.stride = config.get('stride', stride)
        padding = self.stride

        # Patch embedding
        self.patch_embedding = PatchEmbedding(
            self.d_model, self.patch_len, self.stride, padding, self.dropout
        )

        # Encoder（BatchNorm 版 LayerNorm 参见 TSL 原实现）
        self.encoder = Encoder(
            [
                EncoderLayer(
                    AttentionLayer(
                        FullAttention(False, self.factor,
                                      attention_dropout=self.dropout,
                                      output_attention=False),
                        self.d_model, self.n_heads,
                    ),
                    self.d_model, self.d_ff,
                    dropout=self.dropout, activation=self.activation,
                )
                for _ in range(self.e_layers)
            ],
            norm_layer=nn.Sequential(
                _Transpose(1, 2), nn.BatchNorm1d(self.d_model), _Transpose(1, 2)
            ),
        )

        self.head_nf = self.d_model * int((self.seq_len - self.patch_len) / self.stride + 2)
        self.head = FlattenHead(self.enc_in, self.head_nf, self.pred_len,
                                head_dropout=self.dropout)

    def forecast(self, x_enc, x_mark_enc, x_dec, x_mark_dec):
        # RevIN normalization
        means = x_enc.mean(1, keepdim=True).detach()
        x_enc = x_enc - means
        stdev = torch.sqrt(torch.var(x_enc, dim=1, keepdim=True, unbiased=False) + 1e-5)
        x_enc = x_enc / stdev

        # [B, L, N] -> [B, N, L]
        x_enc = x_enc.permute(0, 2, 1)

        # [B*nvars, patch_num, d_model]
        enc_out, n_vars = self.patch_embedding(x_enc)

        enc_out, _ = self.encoder(enc_out)

        # [B, nvars, patch_num, d_model] -> [B, nvars, d_model, patch_num]
        enc_out = torch.reshape(
            enc_out, (-1, n_vars, enc_out.shape[-2], enc_out.shape[-1])
        )
        enc_out = enc_out.permute(0, 1, 3, 2)

        # Prediction head
        dec_out = self.head(enc_out)            # [B, nvars, pred_len]
        dec_out = dec_out.permute(0, 2, 1)       # [B, pred_len, nvars]

        # De-normalization
        dec_out = dec_out * stdev[:, 0, :].unsqueeze(1).repeat(1, self.pred_len, 1)
        dec_out = dec_out + means[:, 0, :].unsqueeze(1).repeat(1, self.pred_len, 1)
        return dec_out

    def forward(self, x_enc, x_mark_enc=None, x_dec=None, x_mark_dec=None):
        dec_out = self.forecast(x_enc, x_mark_enc, x_dec, x_mark_dec)
        return dec_out[:, -self.pred_len:, :]
