"""
Transformer 模型 - TSL 对齐实现
Reference: github.com/thuml/Time-Series-Library/models/Transformer.py

完整 encoder + decoder，带 cross-attention；decoder 接线性投影。
"""
import torch
import torch.nn as nn
import torch.nn.functional as F

from .base import BaseModel
from ..layers.embed import DataEmbedding
from ..layers.attention import FullAttention, AttentionLayer
from ..layers.encoder import Encoder, EncoderLayer
from ..layers.decoder import Decoder, DecoderLayer


class Model(BaseModel):
    """Vanilla Transformer（O(L^2) 注意力）。"""

    def __init__(self, config):
        super().__init__(config)

        self.pred_len = config.pred_len
        self.enc_in = config.get('enc_in', 7)
        self.dec_in = config.get('dec_in', self.enc_in)
        self.c_out = config.get('c_out', self.enc_in)
        self.d_model = config.get('d_model', 128)
        self.n_heads = config.get('n_heads', 8)
        self.e_layers = config.get('e_layers', 2)
        self.d_layers = config.get('d_layers', 1)
        self.d_ff = config.get('d_ff', 512)
        self.dropout = config.get('dropout', 0.1)
        self.activation = config.get('activation', 'gelu')
        self.factor = config.get('factor', 1)
        self.embed = config.get('embed', 'timeF')
        self.freq = config.get('freq', 'h')

        # Embedding
        self.enc_embedding = DataEmbedding(
            self.enc_in, self.d_model, self.embed, self.freq, self.dropout
        )
        self.dec_embedding = DataEmbedding(
            self.dec_in, self.d_model, self.embed, self.freq, self.dropout
        )

        # Encoder
        self.encoder = Encoder(
            [
                EncoderLayer(
                    AttentionLayer(
                        FullAttention(False, self.factor, attention_dropout=self.dropout,
                                      output_attention=False),
                        self.d_model, self.n_heads,
                    ),
                    self.d_model, self.d_ff,
                    dropout=self.dropout, activation=self.activation,
                )
                for _ in range(self.e_layers)
            ],
            norm_layer=nn.LayerNorm(self.d_model),
        )

        # Decoder
        self.decoder = Decoder(
            [
                DecoderLayer(
                    AttentionLayer(
                        FullAttention(True, self.factor, attention_dropout=self.dropout,
                                      output_attention=False),
                        self.d_model, self.n_heads,
                    ),
                    AttentionLayer(
                        FullAttention(False, self.factor, attention_dropout=self.dropout,
                                      output_attention=False),
                        self.d_model, self.n_heads,
                    ),
                    self.d_model, self.d_ff,
                    dropout=self.dropout, activation=self.activation,
                )
                for _ in range(self.d_layers)
            ],
            norm_layer=nn.LayerNorm(self.d_model),
            projection=nn.Linear(self.d_model, self.c_out, bias=True),
        )

    def forecast(self, x_enc, x_mark_enc, x_dec, x_mark_dec):
        enc_out = self.enc_embedding(x_enc, x_mark_enc)
        enc_out, _ = self.encoder(enc_out, attn_mask=None)

        dec_out = self.dec_embedding(x_dec, x_mark_dec)
        dec_out = self.decoder(dec_out, enc_out, x_mask=None, cross_mask=None)
        return dec_out

    def forward(self, x_enc, x_mark_enc=None, x_dec=None, x_mark_dec=None):
        if x_dec is None:
            x_dec = self._default_x_dec(x_enc)
        dec_out = self.forecast(x_enc, x_mark_enc, x_dec, x_mark_dec)
        return dec_out[:, -self.pred_len:, :]
