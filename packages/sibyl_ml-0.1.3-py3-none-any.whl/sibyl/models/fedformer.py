"""
FEDformer 模型 (ICML 2022) - TSL 对齐实现
Reference: github.com/thuml/Time-Series-Library/models/FEDformer.py

频域 attention (Fourier version) + 渐进式分解（与 Autoformer 共享 encoder/decoder）。
"""
import torch
import torch.nn as nn
import torch.nn.functional as F

from .base import BaseModel
from ..layers.embed import DataEmbedding
from ..layers.autocorrelation import AutoCorrelationLayer
from ..layers.fourier_correlation import FourierBlock, FourierCrossAttention
from ..layers.autoformer_encdec import (
    Encoder, Decoder, EncoderLayer, DecoderLayer,
)
from ..layers.decomposition import series_decomp, my_Layernorm


class Model(BaseModel):
    """FEDformer（Fourier 版）：频域注意力达到 O(N) 复杂度。"""

    def __init__(self, config, version='fourier', mode_select='random', modes=32):
        super().__init__(config)

        self.seq_len = config.get('seq_len', 96)
        self.pred_len = config.pred_len
        self.label_len = config.get('label_len', self.pred_len)
        self.enc_in = config.get('enc_in', 7)
        self.dec_in = config.get('dec_in', self.enc_in)
        self.c_out = config.get('c_out', self.enc_in)
        self.d_model = config.get('d_model', 128)
        self.n_heads = config.get('n_heads', 8)
        self.e_layers = config.get('e_layers', 2)
        self.d_layers = config.get('d_layers', 1)
        self.d_ff = config.get('d_ff', 512)
        self.dropout = config.get('dropout', 0.1)
        self.activation = config.get('activation', 'gelu')
        self.moving_avg_size = config.get('moving_avg', 25)
        self.embed = config.get('embed', 'timeF')
        self.freq = config.get('freq', 'h')

        self.version = config.get('version', version)
        self.mode_select = config.get('mode_select', mode_select)
        self.modes = config.get('modes', modes)

        # 初始化分解
        self.decomp = series_decomp(self.moving_avg_size)

        # Embedding
        self.enc_embedding = DataEmbedding(
            self.enc_in, self.d_model, self.embed, self.freq, self.dropout
        )
        self.dec_embedding = DataEmbedding(
            self.dec_in, self.d_model, self.embed, self.freq, self.dropout
        )

        # Fourier version: TSL 主流程
        encoder_self_att = FourierBlock(
            in_channels=self.d_model, out_channels=self.d_model,
            n_heads=self.n_heads, seq_len=self.seq_len,
            modes=self.modes, mode_select_method=self.mode_select,
        )
        decoder_self_att = FourierBlock(
            in_channels=self.d_model, out_channels=self.d_model,
            n_heads=self.n_heads, seq_len=self.seq_len // 2 + self.pred_len,
            modes=self.modes, mode_select_method=self.mode_select,
        )
        decoder_cross_att = FourierCrossAttention(
            in_channels=self.d_model, out_channels=self.d_model,
            seq_len_q=self.seq_len // 2 + self.pred_len,
            seq_len_kv=self.seq_len,
            modes=self.modes, mode_select_method=self.mode_select,
            num_heads=self.n_heads,
        )

        # Encoder
        self.encoder = Encoder(
            [
                EncoderLayer(
                    AutoCorrelationLayer(encoder_self_att, self.d_model, self.n_heads),
                    self.d_model, self.d_ff,
                    moving_avg_size=self.moving_avg_size,
                    dropout=self.dropout, activation=self.activation,
                )
                for _ in range(self.e_layers)
            ],
            norm_layer=my_Layernorm(self.d_model),
        )

        # Decoder
        self.decoder = Decoder(
            [
                DecoderLayer(
                    AutoCorrelationLayer(decoder_self_att, self.d_model, self.n_heads),
                    AutoCorrelationLayer(decoder_cross_att, self.d_model, self.n_heads),
                    self.d_model, self.c_out, self.d_ff,
                    moving_avg_size=self.moving_avg_size,
                    dropout=self.dropout, activation=self.activation,
                )
                for _ in range(self.d_layers)
            ],
            norm_layer=my_Layernorm(self.d_model),
            projection=nn.Linear(self.d_model, self.c_out, bias=True),
        )

    def forecast(self, x_enc, x_mark_enc, x_dec, x_mark_dec):
        # decomp init；c_out < enc_in 时 trend_init 对齐到 c_out（参考 Autoformer）
        mean = torch.mean(x_enc, dim=1).unsqueeze(1).repeat(1, self.pred_len, 1)
        seasonal_init, trend_init = self.decomp(x_enc)
        if self.c_out != x_enc.shape[-1]:
            trend_init = trend_init[:, :, :self.c_out]
            mean = mean[:, :, :self.c_out]
        trend_init = torch.cat([trend_init[:, -self.label_len:, :], mean], dim=1)
        seasonal_init = F.pad(seasonal_init[:, -self.label_len:, :],
                              (0, 0, 0, self.pred_len))

        # enc
        enc_out = self.enc_embedding(x_enc, x_mark_enc)
        enc_out, _ = self.encoder(enc_out, attn_mask=None)

        # dec
        dec_out = self.dec_embedding(seasonal_init, x_mark_dec)
        seasonal_part, trend_part = self.decoder(
            dec_out, enc_out, x_mask=None, cross_mask=None, trend=trend_init,
        )
        return trend_part + seasonal_part

    def forward(self, x_enc, x_mark_enc=None, x_dec=None, x_mark_dec=None):
        if x_dec is None:
            x_dec = self._default_x_dec(x_enc)
        dec_out = self.forecast(x_enc, x_mark_enc, x_dec, x_mark_dec)
        return dec_out[:, -self.pred_len:, :]
