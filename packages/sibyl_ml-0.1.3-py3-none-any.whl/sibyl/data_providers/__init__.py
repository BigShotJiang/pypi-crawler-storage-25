"""
Data Providers 包
"""
import importlib
from .universal_loader import UniversalLoader
from .base import BaseDataProvider


def get_data_loader(config):
    """
    获取数据加载器实例。
    如果配置中有 _target_ 字段，使用 Hydra instantiate 创建自定义加载器；
    否则默认使用 UniversalLoader。
    """
    target = config.get('_target_', None)
    if target and target != 'sibyl.data_providers.UniversalLoader':
        # 自定义数据加载器：动态导入
        module_path, class_name = target.rsplit('.', 1)
        module = importlib.import_module(module_path)
        loader_class = getattr(module, class_name)
        return loader_class(config)
    return UniversalLoader(config)


__all__ = [
    'UniversalLoader',
    'BaseDataProvider',
    'get_data_loader',
]
