"""
UEA 分类数据集加载器（简化骨架，对齐 TSL）。

TSL 的 UEAloader 依赖 sktime 读取 .ts 文件，并做 per-sample normalization。
本移植保留核心接口；完整实现依赖 sktime（可选依赖）。

__getitem__ 返回 2 元组：
  - features: [max_seq_len, n_features]
  - label:    标量（int，类别索引）
"""
import os
import numpy as np
from typing import Optional
from torch.utils.data import Dataset, DataLoader
from ..base import BaseDataProvider


class _UEADataset(Dataset):
    """UEA 分类 Dataset（已预处理的 numpy 数组版本）。"""

    def __init__(self, features: np.ndarray, labels: np.ndarray, max_seq_len: int = None):
        self.features = features.astype(np.float32)
        self.labels = labels.astype(np.int64)
        if max_seq_len is None:
            max_seq_len = features.shape[1] if features.ndim == 3 else features.shape[0]
        self.max_seq_len = max_seq_len

    def __len__(self):
        return len(self.labels)

    def __getitem__(self, index):
        feat = self.features[index]
        # padding 到 max_seq_len
        if feat.shape[0] < self.max_seq_len:
            pad = np.zeros((self.max_seq_len - feat.shape[0], feat.shape[1]), dtype=np.float32)
            feat = np.concatenate([feat, pad], axis=0)
        elif feat.shape[0] > self.max_seq_len:
            feat = feat[:self.max_seq_len]
        return feat, self.labels[index]


class UEALoader(BaseDataProvider):
    """UEA 分类数据集加载器。

    Config:
        root_path       : UEA 数据根目录（包含 xxx_TRAIN.ts / xxx_TEST.ts）
        train_file      : 训练文件名（.ts 格式）
        test_file       : 测试文件名
        max_seq_len     : 最大序列长度（不指定则用训练集最大值）
        batch_size / num_workers : 通用配置

    NOTE:
        - 需要安装 sktime: `pip install sktime`
        - 若安装了 sktime，自动从 .ts 文件读取并做 per-sample 归一化
        - 若未安装，抛出 ImportError
    """

    def __init__(self, config):
        super().__init__(config)
        self.root_path = config.get('root_path', config.get('path', '.'))
        self.train_file = config.get('train_file')
        self.test_file = config.get('test_file')
        self.max_seq_len = config.get('max_seq_len', None)
        self.val_split = config.get('val_split', 0.2)

        self.batch_size = config.get('batch_size', 16)
        self.num_workers = config.get('num_workers', 0)

        self._load()

    def _load_ts(self, path: str):
        """用 sktime 读 .ts 文件，返回 (features [N, T, F], labels [N])"""
        try:
            from sktime.datasets import load_from_tsfile_to_dataframe
        except ImportError as e:
            raise ImportError(
                "UEALoader 需要 sktime。安装：`pip install sktime`"
            ) from e

        full_path = os.path.join(self.root_path, path)
        if not os.path.exists(full_path):
            raise FileNotFoundError(f"UEA ts file not found: {full_path}")

        df, y = load_from_tsfile_to_dataframe(full_path)
        # df 每个 cell 是一个 pd.Series；堆成 [N, T, F]
        n_samples = len(df)
        n_features = df.shape[1]
        seq_len = max(len(s) for s in df.iloc[0])
        features = np.zeros((n_samples, seq_len, n_features), dtype=np.float32)
        for i in range(n_samples):
            for j in range(n_features):
                s = df.iloc[i, j].values
                features[i, :len(s), j] = s

        # labels → int indices
        unique = sorted(set(y))
        label_map = {lbl: idx for idx, lbl in enumerate(unique)}
        labels = np.array([label_map[lbl] for lbl in y], dtype=np.int64)

        return features, labels

    def _normalize_per_sample(self, features: np.ndarray) -> np.ndarray:
        """TSL 的 Normalizer：按样本-特征对做 z-score。"""
        mean = features.mean(axis=1, keepdims=True)
        std = features.std(axis=1, keepdims=True)
        std = np.where(std < 1e-8, 1.0, std)
        return (features - mean) / std

    def _load(self):
        train_feat, train_labels = self._load_ts(self.train_file)
        test_feat, test_labels = self._load_ts(self.test_file)

        train_feat = self._normalize_per_sample(train_feat)
        test_feat = self._normalize_per_sample(test_feat)

        # 用训练集分一部分做 val
        n_val = int(len(train_feat) * self.val_split)
        self.val_features = train_feat[-n_val:] if n_val > 0 else train_feat[:0]
        self.val_labels = train_labels[-n_val:] if n_val > 0 else train_labels[:0]
        self.train_features = train_feat[:-n_val] if n_val > 0 else train_feat
        self.train_labels = train_labels[:-n_val] if n_val > 0 else train_labels
        self.test_features = test_feat
        self.test_labels = test_labels

        if self.max_seq_len is None:
            self.max_seq_len = train_feat.shape[1]

    def _make_loader(self, features, labels, shuffle):
        ds = _UEADataset(features, labels, self.max_seq_len)
        return DataLoader(
            ds, batch_size=self.batch_size, shuffle=shuffle,
            num_workers=self.num_workers, pin_memory=True,
        )

    def get_train_loader(self):
        return self._make_loader(self.train_features, self.train_labels, True)

    def get_val_loader(self):
        return self._make_loader(self.val_features, self.val_labels, False)

    def get_test_loader(self):
        return self._make_loader(self.test_features, self.test_labels, False)

    def next_chunk(self):
        return None

    def reset_chunk(self):
        pass

    def list_available_chunks(self):
        return [0]

    def get_chunk_info(self) -> dict:
        return {
            'n_train': len(self.train_labels),
            'n_test': len(self.test_labels),
            'max_seq_len': self.max_seq_len,
            'n_classes': len(set(self.train_labels.tolist())),
        }
