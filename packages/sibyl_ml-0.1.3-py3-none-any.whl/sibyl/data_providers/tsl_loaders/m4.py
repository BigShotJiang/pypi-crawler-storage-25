"""
M4 Dataset Loader — 移植自 TSL (Time-Series-Library)

M4 数据集特点：
- 100k 条变长时间序列，按 seasonal_patterns 分组 (Yearly/Quarterly/Monthly/Weekly/Daily/Hourly)
- 每个 SP 的预测 horizon 和采样频率不同
- 训练集 / 测试集是 object 数组 (100000,)，每个元素是一个变长 np.ndarray
- 配套 M4-info.csv 提供每条序列的 SP / Horizon / Frequency

本加载器兼容项目 4-tuple 接口：(seq_x, seq_y, seq_x_mark, seq_y_mark)。
M4 无时间特征，故 *_mark 返回空 [T, 0]（ForecastTask 会转成 None）。

原始 TSL 的 mask 信息（insample_mask / outsample_mask）在本实现中通过零填充
体现 —— 不足长度的位置填 0，相当于模型看到一段 "预热静默"。
"""
import os
from dataclasses import dataclass
from typing import List, Optional

import numpy as np
import pandas as pd
import torch
from torch.utils.data import DataLoader, Dataset


@dataclass
class M4Meta:
    """M4 数据集元信息（与 TSL 完全一致）"""
    seasonal_patterns: List[str] = None
    horizons: List[int] = None
    frequencies: List[int] = None
    horizons_map: dict = None
    frequency_map: dict = None
    history_size: dict = None

    def __post_init__(self):
        self.seasonal_patterns = ['Yearly', 'Quarterly', 'Monthly', 'Weekly', 'Daily', 'Hourly']
        self.horizons = [6, 8, 18, 13, 14, 48]
        self.frequencies = [1, 4, 12, 1, 1, 24]
        self.horizons_map = {
            'Yearly': 6, 'Quarterly': 8, 'Monthly': 18,
            'Weekly': 13, 'Daily': 14, 'Hourly': 48,
        }
        self.frequency_map = {
            'Yearly': 1, 'Quarterly': 4, 'Monthly': 12,
            'Weekly': 1, 'Daily': 1, 'Hourly': 24,
        }
        # history_size 来自 N-BEATS interpretable.gin
        self.history_size = {
            'Yearly': 1.5, 'Quarterly': 1.5, 'Monthly': 1.5,
            'Weekly': 10, 'Daily': 10, 'Hourly': 10,
        }


M4_META = M4Meta()


@dataclass
class M4DatasetRaw:
    """承载 M4 原始三元组（ids / groups / values），对应 TSL 的 M4Dataset dataclass"""
    ids: np.ndarray
    groups: np.ndarray
    frequencies: np.ndarray
    horizons: np.ndarray
    values: np.ndarray

    @staticmethod
    def load(training: bool, root_path: str) -> 'M4DatasetRaw':
        """从本地缓存目录加载 M4-info.csv + training.npz / test.npz。

        Args:
            training: True 读 training.npz，False 读 test.npz
            root_path: M4 数据根目录（应含 M4-info.csv / training.npz / test.npz）
        """
        info_file = os.path.join(root_path, 'M4-info.csv')
        train_file = os.path.join(root_path, 'training.npz')
        test_file = os.path.join(root_path, 'test.npz')

        for p in (info_file, train_file, test_file):
            if not os.path.exists(p):
                raise FileNotFoundError(
                    f"M4 file missing: {p}. 需要 M4-info.csv / training.npz / test.npz 齐全。"
                )

        info = pd.read_csv(info_file)
        values_file = train_file if training else test_file
        values = np.load(values_file, allow_pickle=True)
        # .npz 加载可能返回 NpzFile（dict-like）或直接 ndarray；统一为 ndarray
        if hasattr(values, 'files'):
            # 取第一个 key（通常是 'data' 或自动命名 'arr_0'）
            values = values[values.files[0]]

        return M4DatasetRaw(
            ids=info.M4id.values,
            groups=info.SP.values,
            frequencies=info.Frequency.values,
            horizons=info.Horizon.values,
            values=values,
        )


class _M4SequenceDataset(Dataset):
    """单个 seasonal_pattern 的 M4 Dataset。

    __getitem__ 返回 4-tuple (seq_x, seq_y, seq_x_mark, seq_y_mark)，其中
    *_mark 为空 [T, 0]，保持与项目其他 loader 一致的接口。
    """

    def __init__(self, root_path: str, seasonal_pattern: str,
                 seq_len: int, label_len: int, pred_len: int,
                 training: bool = True, random_window: bool = True):
        self.seasonal_pattern = seasonal_pattern
        self.seq_len = seq_len
        # label_len 不能超过 seq_len（与 _SequenceDataset 保持一致）
        self.label_len = min(label_len, seq_len)
        self.pred_len = pred_len
        # history_size = 1.5 * pred_len 对 Yearly/Quarterly/Monthly，10 * pred_len 对其他
        history_size = M4_META.history_size[seasonal_pattern]
        self.window_sampling_limit = int(history_size * pred_len)
        self.random_window = random_window

        raw = M4DatasetRaw.load(training=training, root_path=root_path)
        mask = raw.groups == seasonal_pattern
        # 过滤出该 SP 的序列，并去除 NaN 填充（M4 原始数据末尾可能有 NaN）
        filtered_values = raw.values[mask]
        self.timeseries = [v[~np.isnan(v)].astype(np.float32) for v in filtered_values]
        self.ids = raw.ids[mask]

    def __len__(self):
        return len(self.timeseries)

    def __getitem__(self, index):
        ts = self.timeseries[index]

        if self.random_window and len(ts) > 1:
            # 训练：从 [max(1, len-window_sampling_limit), len) 随机采样切分点
            low = max(1, len(ts) - self.window_sampling_limit)
            high = len(ts)
            cut_point = np.random.randint(low=low, high=max(low + 1, high), size=1)[0]
        else:
            # 推理：以序列末尾为切分点
            cut_point = len(ts)

        # seq_x: 切分点前 seq_len 个值（不足则左侧零填充）
        seq_x = np.zeros((self.seq_len, 1), dtype=np.float32)
        insample_window = ts[max(0, cut_point - self.seq_len):cut_point]
        if len(insample_window) > 0:
            seq_x[-len(insample_window):, 0] = insample_window

        # seq_y: [label_len; pred_len]，前半来自序列 label_len 部分，后半是未来 pred_len
        seq_y = np.zeros((self.label_len + self.pred_len, 1), dtype=np.float32)
        out_start = max(0, cut_point - self.label_len)
        out_end = min(len(ts), cut_point + self.pred_len)
        outsample_window = ts[out_start:out_end]
        if len(outsample_window) > 0:
            seq_y[:len(outsample_window), 0] = outsample_window

        # M4 无时间特征，返回空 mark（ForecastTask 会转成 None）
        seq_x_mark = np.zeros((self.seq_len, 0), dtype=np.float32)
        seq_y_mark = np.zeros((self.label_len + self.pred_len, 0), dtype=np.float32)

        return (
            torch.from_numpy(seq_x),
            torch.from_numpy(seq_y),
            torch.from_numpy(seq_x_mark),
            torch.from_numpy(seq_y_mark),
        )


def _stack_collate_m4(batch):
    """与 universal_loader 的 _stack_collate 一致：避免 resize_ 不可调整 storage 问题"""
    return tuple(torch.stack([item[i] for item in batch], dim=0) for i in range(len(batch[0])))


class M4Loader:
    """M4 数据集的配置驱动加载器。

    Hydra 配置示例：
        _target_: sibyl.data_providers.tsl_loaders.M4Loader
        root_path: ${paths.data_dir}/m4
        seasonal_pattern: Monthly   # Yearly/Quarterly/Monthly/Weekly/Daily/Hourly
        seq_len: 36
        label_len: 18
        pred_len: 18                # 会被 horizons_map[seasonal_pattern] 覆盖，除非显式指定
        batch_size: 32
        num_workers: 0              # 多 worker 与 allow_pickle npz 有冲突，建议 0
        normalize: false            # M4 原始尺度通常直接用
    """

    def __init__(self, config):
        self.config = config
        self.root_path = config.get('root_path', 'datasets/m4')
        self.seasonal_pattern = config.get('seasonal_pattern', 'Monthly')
        if self.seasonal_pattern not in M4_META.seasonal_patterns:
            raise ValueError(
                f"Invalid seasonal_pattern '{self.seasonal_pattern}'. "
                f"可选: {M4_META.seasonal_patterns}"
            )

        # TSL 约定：pred_len = horizons_map[SP]，seq_len = 2 * pred_len，label_len = pred_len
        self.pred_len = int(config.get('pred_len', M4_META.horizons_map[self.seasonal_pattern]))
        self.seq_len = int(config.get('seq_len', 2 * self.pred_len))
        self.label_len = int(config.get('label_len', self.pred_len))

        self.batch_size = int(config.get('batch_size', 32))
        # M4 用 object ndarray (pickle)，不建议多 worker（shared memory 开销大）
        self.num_workers = int(config.get('num_workers', 0))
        self.shuffle = bool(config.get('shuffle', True))

        # M4 特征数恒为 1（univariate）
        self.enc_in = 1
        self.c_out = 1

        # TSL 原版无 scaler（seasonal pattern 内各序列尺度接近，直接用原值）
        self.scaler_stats = None

        # 预加载 train 和 test（test 单独数据文件）
        self.train_dataset = _M4SequenceDataset(
            self.root_path, self.seasonal_pattern,
            self.seq_len, self.label_len, self.pred_len,
            training=True, random_window=True,
        )
        # val 用 train 数据，但固定窗口（取末尾）
        self.val_dataset = _M4SequenceDataset(
            self.root_path, self.seasonal_pattern,
            self.seq_len, self.label_len, self.pred_len,
            training=True, random_window=False,
        )
        self.test_dataset = _M4SequenceDataset(
            self.root_path, self.seasonal_pattern,
            self.seq_len, self.label_len, self.pred_len,
            training=False, random_window=False,
        )

    # ------------------------------------------------------------------
    # UniversalLoader 兼容接口
    # ------------------------------------------------------------------
    def get_train_loader(self):
        return self._make_loader(self.train_dataset, shuffle=self.shuffle)

    def get_val_loader(self):
        return self._make_loader(self.val_dataset, shuffle=False)

    def get_test_loader(self):
        return self._make_loader(self.test_dataset, shuffle=False)

    def _make_loader(self, dataset, shuffle: bool):
        return DataLoader(
            dataset,
            batch_size=self.batch_size,
            shuffle=shuffle,
            num_workers=self.num_workers,
            pin_memory=True,
            collate_fn=_stack_collate_m4,
        )

    # 数据自动分析等接口的最小实现
    def get_raw_data(self):
        return None

    # 兼容 BaseDataProvider / ForecastTask 的若干属性访问
    @property
    def n_features(self):
        return 1

    def next_chunk(self):
        return None


__all__ = ['M4Loader', 'M4Meta', 'M4DatasetRaw', 'M4_META']
