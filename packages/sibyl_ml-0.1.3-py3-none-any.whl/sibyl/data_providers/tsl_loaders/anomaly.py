"""
异常检测通用段加载器（PSM/MSL/SMAP/SMD/SWAT 统一骨架，对齐 TSL）。

TSL 为每个数据集写了单独 loader（PSMSegLoader/MSLSegLoader/...），但逻辑完全一致，
只有文件名/格式不同。本移植用单个 `AnomalySegLoader` 加配置项覆盖，配置示例见 docstring。

__getitem__ 返回 2 元组：
  - window: [win_size, n_features]    已归一化的数据窗口
  - label:  [win_size, n_labels]      异常标签 (1=异常, 0=正常)

train/val/test split 规则（与 TSL 一致）：
  - train : 训练集（原始 train 文件全部）
  - val   : train 的后 20%
  - test  : test 文件全部
"""
import os
import numpy as np
import pandas as pd
from typing import Optional
from torch.utils.data import Dataset, DataLoader
from sklearn.preprocessing import StandardScaler
from ..base import BaseDataProvider


class _AnomalySegDataset(Dataset):
    """滑动窗口异常检测 Dataset (TSL 对齐)."""

    def __init__(self, data: np.ndarray, labels: np.ndarray,
                 win_size: int, step: int = 1, flag: str = 'train'):
        self.data = data.astype(np.float32)
        self.labels = labels.astype(np.float32)
        self.win_size = win_size
        self.step = step
        self.flag = flag

    def __len__(self):
        return (self.data.shape[0] - self.win_size) // self.step + 1

    def __getitem__(self, index):
        i = index * self.step
        window = self.data[i:i + self.win_size]
        if self.flag == 'test':
            label = self.labels[i:i + self.win_size]
        else:
            # TSL 约定：train/val 使用固定的前 win_size 标签（非测试段，此字段仅占位）
            label = self.labels[:self.win_size]
        return window, label


class AnomalySegLoader(BaseDataProvider):
    """通用异常检测加载器。

    Config:
        root_path      : 数据根目录
        train_file     : 训练文件名 (npy/csv)
        test_file      : 测试文件名 (npy/csv)
        label_file     : 测试标签文件名
        win_size       : 滑窗长度 (默认 100)
        step           : 滑窗步长 (默认 1)
        file_format    : 'npy' / 'csv' (默认按文件扩展名自动判断)
        csv_skip_first_col : CSV 是否跳过第一列 (PSM/SWAT 为 True)
        batch_size / shuffle / num_workers / normalize : 通用配置
    """

    def __init__(self, config):
        super().__init__(config)
        self.root_path = config.get('root_path', config.get('path', '.'))
        self.train_file = config.get('train_file')
        self.test_file = config.get('test_file')
        self.label_file = config.get('label_file')
        self.win_size = config.get('win_size', 100)
        self.step = config.get('step', 1)
        self.file_format = config.get('file_format', None)
        self.csv_skip_first_col = config.get('csv_skip_first_col', False)
        self.normalize = config.get('normalize', True)

        self.batch_size = config.get('batch_size', 32)
        self.num_workers = config.get('num_workers', 0)
        self.shuffle = config.get('shuffle', True)

        self._load()

    def _detect_format(self, filename: str) -> str:
        if self.file_format:
            return self.file_format
        ext = os.path.splitext(filename)[1].lower().lstrip('.')
        return ext if ext in ('npy', 'csv') else 'npy'

    def _read_array(self, filename: str, skip_first_col: bool = False) -> np.ndarray:
        path = os.path.join(self.root_path, filename)
        if not os.path.exists(path):
            raise FileNotFoundError(f"Anomaly data file not found: {path}")
        fmt = self._detect_format(filename)
        if fmt == 'npy':
            return np.nan_to_num(np.load(path)).astype(np.float32)
        if fmt == 'csv':
            df = pd.read_csv(path)
            arr = df.values[:, 1:] if skip_first_col else df.values
            return np.nan_to_num(arr).astype(np.float32)
        raise ValueError(f"Unsupported anomaly format: {fmt}")

    def _load(self):
        train = self._read_array(self.train_file, self.csv_skip_first_col)
        test = self._read_array(self.test_file, self.csv_skip_first_col)
        labels = self._read_array(self.label_file, self.csv_skip_first_col)

        if self.normalize:
            scaler = StandardScaler()
            scaler.fit(train)
            train = scaler.transform(train).astype(np.float32)
            test = scaler.transform(test).astype(np.float32)
            # TSL 保存 mean/std 到 scaler_stats（用 numpy → torch tensor）
            import torch
            self.set_scaler_stats(
                torch.from_numpy(scaler.mean_.astype(np.float32)),
                torch.from_numpy(scaler.scale_.astype(np.float32)),
            )

        self.train_data = train
        self.test_data = test
        self.test_labels = labels

        # val = train 后 20%（TSL 约定）
        self.val_data = train[int(len(train) * 0.8):]

    def _make_loader(self, data: np.ndarray, labels: np.ndarray, flag: str, shuffle: bool):
        ds = _AnomalySegDataset(data, labels, self.win_size, self.step, flag)
        return DataLoader(
            ds, batch_size=self.batch_size, shuffle=shuffle,
            num_workers=self.num_workers, pin_memory=True,
        )

    def get_train_loader(self):
        return self._make_loader(self.train_data, self.test_labels, 'train', self.shuffle)

    def get_val_loader(self):
        return self._make_loader(self.val_data, self.test_labels, 'val', False)

    def get_test_loader(self):
        return self._make_loader(self.test_data, self.test_labels, 'test', False)

    # BaseDataProvider 抽象接口（异常检测不使用 chunk，保留空实现）
    def next_chunk(self):
        return None

    def reset_chunk(self):
        pass

    def list_available_chunks(self):
        return [0]

    def get_chunk_info(self) -> dict:
        return {
            'win_size': self.win_size,
            'step': self.step,
            'train_rows': self.train_data.shape[0],
            'test_rows': self.test_data.shape[0],
        }
