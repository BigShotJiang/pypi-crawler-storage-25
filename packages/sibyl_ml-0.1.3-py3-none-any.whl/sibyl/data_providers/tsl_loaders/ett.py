"""
ETT 数据集专用加载器 — 移植自 TSL (Time-Series-Library)

与 `UniversalLoader` 的关键差异：
TSL 对 ETT 采用固定月份分段（**不按比例**），这是 Informer/Autoformer 等经典论文
的 benchmark 约定。若用 0.7/0.1/0.2 ratio 分段，结果无法与文献对齐。

- ETTh1/ETTh2 (hourly, 1 点/小时):
    Train : 前 12 个月 = 12 * 30 * 24 = 8640 点
    Val   : 紧接 4 个月 = 2880 点
    Test  : 紧接 4 个月 = 2880 点
    合计 14400 点（原始 17420 点末尾被丢弃）

- ETTm1/ETTm2 (minutely, 4 点/小时, 即 15 分钟):
    Train : 12 * 30 * 24 * 4 = 34560 点
    Val   : 4 * 30 * 24 * 4 = 11520 点
    Test  : 4 * 30 * 24 * 4 = 11520 点
    合计 57600 点

__getitem__ 返回 4-tuple (seq_x, seq_y, seq_x_mark, seq_y_mark)，与 ForecastTask 兼容。
"""
import os
from typing import Optional

import numpy as np
import pandas as pd
import torch
from sklearn.preprocessing import StandardScaler
from torch.utils.data import DataLoader, Dataset

from ..timefeatures import time_features


def _stack_collate(batch):
    """显式 torch.stack，避免默认 collate 的 resize_ 问题。"""
    return tuple(torch.stack([item[i] for item in batch], dim=0) for i in range(len(batch[0])))


class _ETTSegmentDataset(Dataset):
    """单一 split 的 ETT Dataset。__getitem__ 产 4-tuple。"""

    def __init__(self, data_x: np.ndarray, data_y: np.ndarray, data_stamp: np.ndarray,
                 seq_len: int, label_len: int, pred_len: int):
        self.data_x = data_x.astype(np.float32)
        self.data_y = data_y.astype(np.float32)
        self.data_stamp = data_stamp.astype(np.float32)
        self.seq_len = seq_len
        self.label_len = min(label_len, seq_len)
        self.pred_len = pred_len

    def __len__(self):
        return max(0, len(self.data_x) - self.seq_len - self.pred_len + 1)

    def __getitem__(self, index):
        s_begin = index
        s_end = s_begin + self.seq_len
        r_begin = s_end - self.label_len
        r_end = r_begin + self.label_len + self.pred_len

        seq_x = np.ascontiguousarray(self.data_x[s_begin:s_end])
        seq_y = np.ascontiguousarray(self.data_y[r_begin:r_end])
        seq_x_mark = np.ascontiguousarray(self.data_stamp[s_begin:s_end])
        seq_y_mark = np.ascontiguousarray(self.data_stamp[r_begin:r_end])

        return (
            torch.tensor(seq_x, dtype=torch.float32),
            torch.tensor(seq_y, dtype=torch.float32),
            torch.tensor(seq_x_mark, dtype=torch.float32),
            torch.tensor(seq_y_mark, dtype=torch.float32),
        )


class ETTLoader:
    """ETT 预测加载器（TSL 固定月份分段）。

    Hydra 配置示例：
        _target_: sibyl.data_providers.tsl_loaders.ETTLoader
        path: ${paths.data_dir}/ETTh1/ETTh1.csv   # csv；npz 通过 npz_path 传递
        granularity: hour           # hour | minute
        seq_len: 96
        label_len: 48
        pred_len: 96
        features: M                 # M (多变量→多变量) / S (单变量) / MS (多变量→单变量)
        target: OT                  # S/MS 模式下的目标列名
        scale: true                 # 是否标准化（用训练段的 mean/std）
        timeenc: 1                  # 0=离散整数特征(month/day/weekday/hour[/minute]), 1=归一化时间特征
        freq: h                     # 对应 timefeatures；hour 用 'h'，minute 用 't' 或 '15min'
        batch_size: 32
        num_workers: 4
    """

    # TSL 原版固定边界（单位：点）
    # 边界计算：border1s = [train_start, val_start - seq_len, test_start - seq_len]
    #         border2s = [train_end,   val_end,              test_end]
    _BORDERS = {
        'hour':   [12 * 30 * 24,     4 * 30 * 24,     4 * 30 * 24],      # 8640 / 2880 / 2880
        'minute': [12 * 30 * 24 * 4, 4 * 30 * 24 * 4, 4 * 30 * 24 * 4],  # 34560 / 11520 / 11520
    }

    def __init__(self, config):
        self.config = config
        self.granularity = config.get('granularity', 'hour')
        assert self.granularity in ('hour', 'minute'), \
            f"granularity 必须是 'hour' 或 'minute'，收到: {self.granularity}"

        self.path = config.get('path')
        self.seq_len = int(config.get('seq_len', 96))
        self.label_len = int(config.get('label_len', 48))
        self.pred_len = int(config.get('pred_len', 96))
        self.features = config.get('features', 'M')
        self.target = config.get('target', 'OT')
        self.scale = bool(config.get('scale', True))
        self.timeenc = int(config.get('timeenc', 1))
        self.freq = config.get('freq', 'h' if self.granularity == 'hour' else 'min')

        self.batch_size = int(config.get('batch_size', 32))
        self.num_workers = int(config.get('num_workers', 4))
        self.shuffle = bool(config.get('shuffle', True))

        # 特征维度（自动从 CSV 推断，也可由外部 enc_in 覆盖）
        self.enc_in = config.get('enc_in', None)
        self.c_out = config.get('c_out', None)

        # scaler_stats 供 ForecastTask 读取
        self.scaler_stats = None

        self._load_and_split()

    # ------------------------------------------------------------------
    def _load_and_split(self):
        if not os.path.exists(self.path):
            raise FileNotFoundError(f"ETT file not found: {self.path}")

        df_raw = pd.read_csv(self.path)
        # 期望列：date, ..., (optional target)
        if 'date' not in df_raw.columns:
            raise ValueError(f"ETT CSV 必须含 'date' 列，实际列: {df_raw.columns.tolist()}")

        # TSL 边界
        n_train, n_val, n_test = self._BORDERS[self.granularity]
        border1s = [0, n_train - self.seq_len, n_train + n_val - self.seq_len]
        border2s = [n_train, n_train + n_val, n_train + n_val + n_test]

        # 特征列选择（与 TSL Dataset_Custom 一致）
        if self.features in ('M', 'MS'):
            cols_data = df_raw.columns[1:]  # 跳过 date
            df_data = df_raw[cols_data]
        elif self.features == 'S':
            if self.target not in df_raw.columns:
                raise ValueError(f"features=S 需要 target 列 '{self.target}'，实际列: {df_raw.columns.tolist()}")
            df_data = df_raw[[self.target]]
        else:
            raise ValueError(f"features 必须是 M/S/MS，收到: {self.features}")

        # 暴露真实列名供可解释性回调使用（HUFL/HULL/MUFL/MULL/LUFL/LULL/OT）
        self.feature_names = list(df_data.columns)

        # 归一化：用训练段 fit
        scaler = StandardScaler()
        if self.scale:
            train_data = df_data.iloc[border1s[0]:border2s[0]]
            scaler.fit(train_data.values)
            data = scaler.transform(df_data.values)
            self.scaler_stats = {
                'mean': torch.tensor(scaler.mean_, dtype=torch.float32),
                'std': torch.tensor(scaler.scale_, dtype=torch.float32),
            }
        else:
            data = df_data.values

        # 时间特征
        df_stamp = df_raw[['date']].copy()
        df_stamp['date'] = pd.to_datetime(df_stamp['date'])
        if self.timeenc == 0:
            # 离散整数特征
            df_stamp['month'] = df_stamp['date'].dt.month
            df_stamp['day'] = df_stamp['date'].dt.day
            df_stamp['weekday'] = df_stamp['date'].dt.weekday
            df_stamp['hour'] = df_stamp['date'].dt.hour
            if self.granularity == 'minute':
                df_stamp['minute'] = df_stamp['date'].dt.minute.map(lambda x: x // 15)
            data_stamp = df_stamp.drop(columns=['date']).values.astype(np.float32)
        else:
            # 归一化时间特征（TSL 的 time_features 返回 [n_features, T]，需转置）
            feats = time_features(pd.to_datetime(df_stamp['date'].values), freq=self.freq)
            data_stamp = feats.transpose(1, 0).astype(np.float32)

        # 分 split 构造 Dataset
        self._datasets = {}
        for idx, flag in enumerate(['train', 'val', 'test']):
            b1, b2 = border1s[idx], border2s[idx]
            data_slice = data[b1:b2]
            stamp_slice = data_stamp[b1:b2]
            self._datasets[flag] = _ETTSegmentDataset(
                data_slice, data_slice, stamp_slice,
                self.seq_len, self.label_len, self.pred_len,
            )

        # 自动填充 enc_in / c_out（若未显式提供）
        n_feat = data.shape[1]
        if self.enc_in is None:
            self.enc_in = n_feat
        if self.c_out is None:
            self.c_out = 1 if self.features == 'MS' else n_feat

    # ------------------------------------------------------------------
    # UniversalLoader 兼容接口
    # ------------------------------------------------------------------
    def get_train_loader(self):
        return self._make_loader(self._datasets['train'], shuffle=self.shuffle)

    def get_val_loader(self):
        return self._make_loader(self._datasets['val'], shuffle=False)

    def get_test_loader(self):
        return self._make_loader(self._datasets['test'], shuffle=False)

    def _make_loader(self, dataset, shuffle: bool):
        return DataLoader(
            dataset,
            batch_size=self.batch_size,
            shuffle=shuffle,
            num_workers=self.num_workers,
            pin_memory=True,
            collate_fn=_stack_collate,
        )

    def get_raw_data(self):
        # 返回训练段原始数据供 DataProfiler 分析，shape [n_train, n_features]
        return self._datasets['train'].data_x

    @property
    def n_features(self):
        return self.enc_in

    def next_chunk(self):
        return None


__all__ = ['ETTLoader']
