"""
TSL 专用 Dataset 移植包。

配置文件通过 `_target_` 字段直接引用对应类。

- AnomalySegLoader : 异常检测段加载器（PSM/MSL/SMAP/SMD/SWAT 统一骨架）
- UEALoader        : UEA 分类数据集加载器
- M4Loader         : M4 竞赛数据集加载器（变长序列，按 seasonal_pattern 分组）
- ETTLoader        : ETT 预测加载器（12mo/4mo/4mo 固定月份分段，与 TSL 基准对齐）
"""
from .anomaly import AnomalySegLoader
from .uea import UEALoader
from .m4 import M4Loader
from .ett import ETTLoader

__all__ = ['AnomalySegLoader', 'UEALoader', 'M4Loader', 'ETTLoader']
