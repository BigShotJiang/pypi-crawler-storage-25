from abc import ABC, abstractmethod
import torch
from typing import Optional, Tuple, List


class BaseDataProvider(ABC):
    """数据提供者基类"""

    def __init__(self, config):
        self.config = config
        self.scaler_stats = None

    @abstractmethod
    def get_train_loader(self):
        pass

    @abstractmethod
    def get_val_loader(self):
        pass

    @abstractmethod
    def get_test_loader(self):
        pass

    def set_scaler_stats(self, mean: torch.Tensor, std: torch.Tensor):
        """设置归一化统计量"""
        self.scaler_stats = {'mean': mean, 'std': std}

    @abstractmethod
    def next_chunk(self) -> Optional[Tuple]:
        """获取下一块数据，返回 None 表示无数据"""
        pass

    @abstractmethod
    def reset_chunk(self):
        """重置到第一块"""
        pass

    @abstractmethod
    def list_available_chunks(self) -> List[int]:
        """列出所有可用的块索引"""
        pass

    @abstractmethod
    def get_chunk_info(self) -> dict:
        """获取数据块信息"""
        pass
