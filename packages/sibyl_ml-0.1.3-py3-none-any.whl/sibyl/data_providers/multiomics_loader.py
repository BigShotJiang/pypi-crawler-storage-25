"""多组学基因表达数据加载器（HDF5 + K-fold + mark 子集）。

为 CrossMark V5 模型提供训练/验证/测试 DataLoader，算法逻辑与 CC/data.py 一致：
  - seq.h5：one-hot DNA (N, 48200, 4) → 按 SEQ_INDEX 切出 4200bp 窗口
  - epi.h5：表观信号 (N, 48200) → 按 MARK_INDICES 切出每个 mark 的 4200bp
  - K-fold 划分非 test2 基因，test2 固定独立保留集
  - active_marks 控制加载哪些 mark（空列表 = seq_only 基线）

暴露 BaseDataProvider 接口：get_train_loader / get_val_loader / get_test_loader。
chunk 相关方法提供空实现（本 loader 使用整样本读入，非分块流模式）。
"""

import gc
import hashlib
import logging
import os
from pathlib import Path
from typing import Dict, List, Optional, Sequence, Tuple

import h5py
import numpy as np
import pandas as pd
import torch
from sklearn.model_selection import KFold
from torch.utils.data import DataLoader, Dataset

from .base import BaseDataProvider

log = logging.getLogger(__name__)


# 把每个模态需要的列表达成"两段连续区间"，便于用 h5py 的纯 slice 读
# （比 fancy index `f[key][:, INDEX, :]` 快 ~100×，且只占目标内存）
SEQ_RANGES = [(1000, 4500), (7500, 8200)]
MARK_RANGES = {
    "ATAC":     [(1000,  4500),  (7500,  8200)],
    "H3K27ac":  [(11000, 14500), (17500, 18200)],
    "H3K27me3": [(21000, 24500), (27500, 28200)],
    "H3K36me3": [(31000, 34500), (37500, 38200)],
    "H3K4me3":  [(41000, 44500), (47500, 48200)],
}

# 兼容旧代码 import: 拼接的 fancy-index 数组，仅供外部参考用
SEQ_INDEX = np.concatenate([np.arange(s, e) for s, e in SEQ_RANGES])
MARK_INDICES = {
    m: np.concatenate([np.arange(s, e) for s, e in r])
    for m, r in MARK_RANGES.items()
}

MARK_NAMES = ["ATAC", "H3K27ac", "H3K27me3", "H3K36me3", "H3K4me3"]
BIN_LEN = 4200


def _read_sliced_h5(src_path: str, ranges, has_channels: bool) -> np.ndarray:
    """从 HDF5 按区间列表读取并拼接。区间走纯 slice 路径，避免 fancy-index 的全量加载。

    Args:
        src_path: HDF5 文件路径
        ranges: [(start, stop), ...] 第二维（位置）需要保留的区间
        has_channels: True → seq.h5（3D）, False → epi.h5（2D）
    Returns:
        拼接后的 float32 ndarray，第二维总长 = sum(stop-start)
    """
    parts = []
    with h5py.File(src_path, "r") as f:
        key = list(f.keys())[0]
        for start, stop in ranges:
            if has_channels:
                parts.append(f[key][:, start:stop, :])
            else:
                parts.append(f[key][:, start:stop])
    return np.concatenate(parts, axis=1).astype("float32")


class _MultiOmicsDataset(Dataset):
    """按索引延迟切片的多模态 Dataset。"""

    def __init__(self, data: Dict[str, np.ndarray], labels: np.ndarray,
                 genes: np.ndarray, indices: np.ndarray,
                 modalities: List[str], scalers: Optional[Dict] = None,
                 fit_scalers: bool = False, augment: bool = False):
        self.augment = augment
        self.modalities = modalities
        self.indices = np.asarray(indices)
        self.genes_all = genes
        self.labels_all = labels
        self.modal_data = {m: data[m] for m in modalities}
        self.scalers = dict(scalers) if scalers else {}

        if fit_scalers:
            for modal in modalities:
                if modal == "seq":
                    continue
                raw = data[modal][self.indices].astype("float32")
                self.scalers[modal] = {
                    "mean": float(raw.mean()),
                    "std": float(raw.std()) + 1e-8,
                }

        log.info(
            "Dataset | n=%d | modalities=%s | augment=%s",
            len(self.indices), modalities, augment,
        )

    def __len__(self) -> int:
        return len(self.indices)

    def __getitem__(self, idx):
        real_idx = int(self.indices[idx])
        inputs = {}
        for modal in self.modalities:
            arr = self.modal_data[modal][real_idx].astype("float32")

            if modal == "seq":
                if self.augment:
                    if np.random.rand() < 0.5:
                        arr = arr[::-1, :][:, [3, 2, 1, 0]].copy()
                    if np.random.rand() < 0.3:
                        shift = np.random.randint(-50, 51)
                        arr = np.roll(arr, shift, axis=0)
            else:
                if modal in self.scalers:
                    m = self.scalers[modal]["mean"]
                    s = self.scalers[modal]["std"]
                    arr = (arr - m) / s
                if self.augment:
                    if np.random.rand() < 0.25:
                        arr = np.zeros_like(arr)
                    elif np.random.rand() < 0.2:
                        arr = arr + np.random.normal(
                            0, 0.1, arr.shape).astype("float32")

            inputs[modal] = torch.from_numpy(arr.astype("float32"))

        label = torch.tensor(self.labels_all[real_idx], dtype=torch.float32)
        gene_id = self.genes_all[real_idx]
        return inputs, label, gene_id


def _make_collate_fn(modalities: List[str]):
    def collate_fn(batch):
        inputs_batch = {m: [] for m in modalities}
        labels_batch, genes_batch = [], []
        for inputs, label, gene_id in batch:
            for m in modalities:
                inputs_batch[m].append(inputs[m])
            labels_batch.append(label)
            genes_batch.append(gene_id)

        batch_dict = {m: torch.stack(inputs_batch[m]) for m in modalities}
        batch_dict["tpm"] = torch.stack(labels_batch)
        batch_dict["is_expressed"] = (batch_dict["tpm"] > 0).long()
        batch_dict["gene_id"] = genes_batch
        return batch_dict
    return collate_fn


class MultiomicsLoader(BaseDataProvider):
    """HDF5 多组学数据提供者。"""

    def __init__(self, config):
        super().__init__(config)

        # 数据切片配置（可被 yaml 覆盖；不写则用模块默认值 SEQ_RANGES/MARK_RANGES）
        # YAML 表达：list-of-list `[[1000, 4500], [7500, 8200]]`，加载后转 list-of-tuple
        self.bin_len = int(config.get("bin_len", BIN_LEN))
        seq_ranges_cfg = config.get("seq_ranges", None)
        mark_ranges_cfg = config.get("mark_ranges", None)

        self.seq_ranges = (self._parse_ranges(seq_ranges_cfg)
                           if seq_ranges_cfg is not None else list(SEQ_RANGES))
        if mark_ranges_cfg is not None:
            self.mark_ranges = {
                m: self._parse_ranges(r) for m, r in dict(mark_ranges_cfg).items()
            }
        else:
            self.mark_ranges = {m: list(r) for m, r in MARK_RANGES.items()}

        # active_marks 必须是 mark_ranges 的子集（旧约束: MARK_NAMES）
        allowed_marks = list(self.mark_ranges.keys())
        active_marks = config.get("active_marks", allowed_marks)
        active_marks = list(active_marks) if active_marks is not None else []
        for m in active_marks:
            if m not in allowed_marks:
                raise ValueError(
                    f"Unknown mark '{m}'. Allowed (per mark_ranges): {allowed_marks}")

        self.active_marks = active_marks
        self.modalities = ["seq"] + active_marks

        # 启动期校验：每个用到的 ranges 总长 == bin_len，区间合法
        self._validate_ranges()

        self.seq_h5 = config["seq_h5"]
        self.epi_h5 = config["epi_h5"]
        self.gene_list = config["gene_list"]
        self.tpm_file = config["tpm_file"]
        self.test2_file = config.get("test2_file", None)

        self.n_folds = int(config.get("n_folds", 5))
        self.fold_to_run = int(config.get("fold_to_run", 0))
        self.seed = int(config.get("seed", 42))
        self.batch_size = int(config.get("batch_size", 128))
        self.num_workers = int(config.get("num_workers", 4))

        # memmap 缓存控制（切片读 → .npy → mmap）
        self.use_cache = bool(config.get("use_cache", True))
        self.cache_dir = config.get("cache_dir", "outputs/gene_expr/_cache")

        self._train_loader = None
        self._val_loader = None
        self._test_loader = None
        self._scalers = None
        self._manifest = None

        self._build()

    @staticmethod
    def _parse_ranges(raw) -> List[Tuple[int, int]]:
        """把 YAML 的 list-of-list 转成 list-of-tuple；元素强制 int。"""
        out = []
        for item in raw:
            if len(item) != 2:
                raise ValueError(
                    f"range must be [start, stop], got {item!r}")
            out.append((int(item[0]), int(item[1])))
        return out

    def _validate_ranges(self):
        """启动期校验：seq + 每个 active mark 的 ranges 总长必须等于 bin_len。"""
        def _check(name, ranges):
            for s, e in ranges:
                if not (0 <= s < e):
                    raise ValueError(
                        f"{name}: invalid range [{s}, {e}] (要求 0 <= start < stop)")
            total = sum(e - s for s, e in ranges)
            if total != self.bin_len:
                raise ValueError(
                    f"{name}: ranges 总长 {total} != bin_len {self.bin_len}, "
                    f"ranges={ranges}")
        _check("seq_ranges", self.seq_ranges)
        for m in self.active_marks:
            if m not in self.mark_ranges:
                raise ValueError(
                    f"mark_ranges 缺失 active mark '{m}'")
            _check(f"mark_ranges['{m}']", self.mark_ranges[m])

    @staticmethod
    def _ranges_hash(ranges: Sequence[Tuple[int, int]]) -> str:
        """ranges 的短 hash，加入 cache 文件名，避免配置变了但读到旧 cache。"""
        s = repr(sorted([(int(a), int(b)) for a, b in ranges])).encode()
        return hashlib.md5(s).hexdigest()[:8]

    def _cache_path(self, key_name: str, src_path: str,
                    ranges: Sequence[Tuple[int, int]]) -> Path:
        """缓存文件路径，编码源 HDF5 mtime + ranges hash 做双重失效检测。"""
        src_mtime = int(os.path.getmtime(src_path))
        rng_hash = self._ranges_hash(ranges)
        fname = f"{key_name}_mtime{src_mtime}_rng{rng_hash}.npy"
        return Path(self.cache_dir) / fname

    def _load_or_build(self, key_name: str, src_path: str,
                       ranges, has_channels: bool) -> np.ndarray:
        """缓存命中→memmap 加载；缺失→切片读 HDF5 + 写缓存 + memmap 复读。

        memmap 让 train/val/test 三个 dataset 共享 OS page cache，且 sweep 中
        其它 mark 组合的 run 启动时直接秒级 mmap，不再触碰 HDF5。
        """
        cache_path = self._cache_path(key_name, src_path, ranges)
        if self.use_cache and cache_path.exists():
            log.info("[cache hit ] %s -> mmap %s", key_name, cache_path)
            return np.load(cache_path, mmap_mode="r")

        log.info("[cache miss] building %s from %s ...", key_name, src_path)
        arr = _read_sliced_h5(src_path, ranges, has_channels)
        log.info("  built shape=%s, %.1f MB",
                 arr.shape, arr.nbytes / 1e6)

        if self.use_cache:
            cache_path.parent.mkdir(parents=True, exist_ok=True)
            # 用 ".tmp.npy" 而非 ".npy.tmp"，否则 np.save 会再追加一次 .npy
            tmp = cache_path.with_name(cache_path.stem + ".tmp.npy")
            np.save(tmp, arr)
            os.replace(tmp, cache_path)  # 原子覆盖（跨平台一致）
            log.info("[cache write] %s | %.1f MB",
                     cache_path, cache_path.stat().st_size / 1e6)
            del arr
            gc.collect()
            return np.load(cache_path, mmap_mode="r")
        return arr

    def _load_raw(self) -> Dict:
        log.info("Loading gene list: %s", self.gene_list)
        genes = pd.read_csv(self.gene_list, header=None)[0].values
        n_genes = len(genes)
        log.info("n_genes=%d", n_genes)

        tpm_df = pd.read_csv(self.tpm_file, sep="\t", header=0)
        tpm_df.columns = ["gene_id", "TPM"]
        tpm_df["TPM"] = tpm_df["TPM"].astype("float32")
        tpm_df = tpm_df.set_index("gene_id")
        labels_raw = np.array(
            [tpm_df.loc[g, "TPM"] if g in tpm_df.index else 0.0
             for g in genes], dtype="float32")
        labels = np.log1p(labels_raw).astype("float32")

        if self.test2_file and os.path.exists(self.test2_file):
            t2_ids = pd.read_csv(self.test2_file, header=None)[0].tolist()
            if t2_ids and str(t2_ids[0]).lower().startswith("gene"):
                t2_ids = t2_ids[1:]
            test2_mask = np.array(
                [g in set(t2_ids) for g in genes], dtype=bool)
        else:
            test2_mask = np.zeros(n_genes, dtype=bool)

        data: Dict[str, np.ndarray] = {}
        # seq: 22 GB → 1.9 GB（slice 直读），seq cache 跨所有 32 组合复用
        data["seq"] = self._load_or_build(
            "seq", self.seq_h5, self.seq_ranges, has_channels=True)

        if self.active_marks:
            for mark in self.active_marks:
                # 每个 mark 单独缓存（450 MB / mark），按 active_marks 子集动态读
                data[mark] = self._load_or_build(
                    f"epi_{mark}", self.epi_h5,
                    self.mark_ranges[mark], has_channels=False)

        gc.collect()
        return {
            "genes": genes,
            "labels": labels,
            "labels_raw": labels_raw,
            "data": data,
            "test2_mask": test2_mask,
        }

    def _kfold_split(self, test2_mask: np.ndarray) -> Dict[str, np.ndarray]:
        test2_idx = np.where(test2_mask)[0]
        non_test2_idx = np.where(~test2_mask)[0]

        # sklearn KFold 要求 n_splits>=2；n_folds=1 走手工 80/20 划分，
        # 方便跑 mini-sweep / 快速调试不动整 5-fold
        if self.n_folds == 1:
            if self.fold_to_run != 0:
                raise ValueError(
                    f"n_folds=1 只有 fold_to_run=0，但传入 fold_to_run={self.fold_to_run}")
            rng = np.random.RandomState(self.seed)
            shuffled = rng.permutation(non_test2_idx)
            split = int(len(shuffled) * 0.8)
            return {
                "train_idx": shuffled[:split],
                "val_idx": shuffled[split:],
                "test2_idx": test2_idx,
                "fold": 0,
            }

        kf = KFold(n_splits=self.n_folds, shuffle=True, random_state=self.seed)
        splits = list(kf.split(non_test2_idx))
        if self.fold_to_run >= len(splits):
            raise ValueError(
                f"fold_to_run={self.fold_to_run} out of range "
                f"(n_folds={len(splits)})")
        tr_local, va_local = splits[self.fold_to_run]
        return {
            "train_idx": non_test2_idx[tr_local],
            "val_idx": non_test2_idx[va_local],
            "test2_idx": test2_idx,
            "fold": self.fold_to_run,
        }

    def _build(self):
        raw = self._load_raw()
        fold = self._kfold_split(raw["test2_mask"])

        log.info(
            "Fold %d | train=%d val=%d test2=%d | modalities=%s",
            fold["fold"], len(fold["train_idx"]), len(fold["val_idx"]),
            len(fold["test2_idx"]), self.modalities,
        )

        train_ds = _MultiOmicsDataset(
            raw["data"], raw["labels"], raw["genes"],
            fold["train_idx"], self.modalities,
            scalers=None, fit_scalers=True, augment=True)
        self._scalers = train_ds.scalers

        val_ds = _MultiOmicsDataset(
            raw["data"], raw["labels"], raw["genes"],
            fold["val_idx"], self.modalities,
            scalers=self._scalers, fit_scalers=False, augment=False)

        test_ds = _MultiOmicsDataset(
            raw["data"], raw["labels"], raw["genes"],
            fold["test2_idx"], self.modalities,
            scalers=self._scalers, fit_scalers=False, augment=False)

        collate = _make_collate_fn(self.modalities)

        self._train_loader = DataLoader(
            train_ds, batch_size=self.batch_size, shuffle=True,
            num_workers=self.num_workers, collate_fn=collate,
            pin_memory=True, drop_last=False)
        self._val_loader = DataLoader(
            val_ds, batch_size=self.batch_size, shuffle=False,
            num_workers=self.num_workers, collate_fn=collate, pin_memory=True)
        self._test_loader = DataLoader(
            test_ds, batch_size=self.batch_size, shuffle=False,
            num_workers=self.num_workers, collate_fn=collate, pin_memory=True)

        self._manifest = {
            "n_genes_total": len(raw["genes"]),
            "n_test2": int(raw["test2_mask"].sum()),
            "modalities": self.modalities,
            "active_marks": self.active_marks,
            "fold": fold["fold"],
            "fold_sizes": {
                "train": int(len(fold["train_idx"])),
                "val": int(len(fold["val_idx"])),
                "test2": int(len(fold["test2_idx"])),
            },
        }

    def get_train_loader(self):
        return self._train_loader

    def get_val_loader(self):
        return self._val_loader

    def get_test_loader(self):
        return self._test_loader

    def get_scalers(self) -> Dict:
        return self._scalers or {}

    def get_manifest(self) -> Dict:
        return self._manifest or {}

    def next_chunk(self):
        return None

    def reset_chunk(self):
        return None

    def list_available_chunks(self):
        return []

    def get_chunk_info(self) -> dict:
        return {"mode": "full", "n_chunks": 1}
