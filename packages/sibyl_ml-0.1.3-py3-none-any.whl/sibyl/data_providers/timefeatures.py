"""
时间特征编码（移植自 TSL `utils/timefeatures.py`，保持数值完全一致）。

提供两种编码方式供 TSL 风格模型使用：
- timeenc=0 (discrete): month/day/weekday/hour 整数特征（由调用方直接提取）
- timeenc=1 (normalized): 由 `time_features()` 输出 [-0.5, 0.5] 归一化特征

TSL 的 `DataEmbedding` 根据 `embed=='timeF'` 走 `TimeFeatureEmbedding` (timeenc=1)，
否则走 `TemporalEmbedding` (timeenc=0)。
"""
from typing import List

import numpy as np
import pandas as pd
from pandas.tseries import offsets
from pandas.tseries.frequencies import to_offset


class TimeFeature:
    def __init__(self):
        pass

    def __call__(self, index: pd.DatetimeIndex) -> np.ndarray:
        pass

    def __repr__(self):
        return self.__class__.__name__ + "()"


class SecondOfMinute(TimeFeature):
    def __call__(self, index: pd.DatetimeIndex) -> np.ndarray:
        return index.second / 59.0 - 0.5


class MinuteOfHour(TimeFeature):
    def __call__(self, index: pd.DatetimeIndex) -> np.ndarray:
        return index.minute / 59.0 - 0.5


class HourOfDay(TimeFeature):
    def __call__(self, index: pd.DatetimeIndex) -> np.ndarray:
        return index.hour / 23.0 - 0.5


class DayOfWeek(TimeFeature):
    def __call__(self, index: pd.DatetimeIndex) -> np.ndarray:
        return index.dayofweek / 6.0 - 0.5


class DayOfMonth(TimeFeature):
    def __call__(self, index: pd.DatetimeIndex) -> np.ndarray:
        return (index.day - 1) / 30.0 - 0.5


class DayOfYear(TimeFeature):
    def __call__(self, index: pd.DatetimeIndex) -> np.ndarray:
        return (index.dayofyear - 1) / 365.0 - 0.5


class MonthOfYear(TimeFeature):
    def __call__(self, index: pd.DatetimeIndex) -> np.ndarray:
        return (index.month - 1) / 11.0 - 0.5


class WeekOfYear(TimeFeature):
    def __call__(self, index: pd.DatetimeIndex) -> np.ndarray:
        return (index.isocalendar().week - 1) / 52.0 - 0.5


def time_features_from_frequency_str(freq_str: str) -> List[TimeFeature]:
    features_by_offsets = {
        offsets.YearEnd: [],
        offsets.QuarterEnd: [MonthOfYear],
        offsets.MonthEnd: [MonthOfYear],
        offsets.Week: [DayOfMonth, WeekOfYear],
        offsets.Day: [DayOfWeek, DayOfMonth, DayOfYear],
        offsets.BusinessDay: [DayOfWeek, DayOfMonth, DayOfYear],
        offsets.Hour: [HourOfDay, DayOfWeek, DayOfMonth, DayOfYear],
        offsets.Minute: [
            MinuteOfHour,
            HourOfDay,
            DayOfWeek,
            DayOfMonth,
            DayOfYear,
        ],
        offsets.Second: [
            SecondOfMinute,
            MinuteOfHour,
            HourOfDay,
            DayOfWeek,
            DayOfMonth,
            DayOfYear,
        ],
    }

    offset = to_offset(freq_str)

    for offset_type, feature_classes in features_by_offsets.items():
        if isinstance(offset, offset_type):
            return [cls() for cls in feature_classes]

    supported_freq_msg = f"""
    Unsupported frequency {freq_str}
    The following frequencies are supported:
        Y   - yearly          (alias: A)
        M   - monthly
        W   - weekly
        D   - daily
        B   - business days
        H   - hourly
        T   - minutely        (alias: min)
        S   - secondly
    """
    raise RuntimeError(supported_freq_msg)


def time_features(dates, freq='h'):
    """
    生成规范化时间特征矩阵。

    Args:
        dates: pd.DatetimeIndex 或可转换为 DatetimeIndex 的序列
        freq: 频率字符串 (h/t/min/s/d/w/m/y 等)

    Returns:
        np.ndarray, shape [n_features, n_timesteps]，每个特征值在 [-0.5, 0.5]
        （注意：TSL 的 ETT loader 会转置为 [n_timesteps, n_features]）
    """
    return np.vstack([feat(dates) for feat in time_features_from_frequency_str(freq)])


def extract_discrete_time_features(dates: pd.DatetimeIndex, freq: str = 'h') -> np.ndarray:
    """
    timeenc=0 模式：提取离散时间特征 (month, day, weekday, hour, [minute])。

    TSL 风格：ETT_hour 使用 month/day/weekday/hour (4维)，
    ETT_minute 额外增加 minute//15 (5维)。此函数按 freq 自动判断。

    Args:
        dates: pd.DatetimeIndex
        freq: 'h' 或 't'/'min' （分钟级时额外加 minute 列）

    Returns:
        np.ndarray, shape [n_timesteps, n_features]，整数值
    """
    df = pd.DataFrame({'date': dates})
    df['date'] = pd.to_datetime(df['date'])
    df['month'] = df.date.dt.month
    df['day'] = df.date.dt.day
    df['weekday'] = df.date.dt.weekday
    df['hour'] = df.date.dt.hour
    freq_norm = freq.lower()
    if freq_norm in ('t', 'min'):
        df['minute'] = df.date.dt.minute // 15
    return df.drop(columns=['date']).values.astype(np.float32)
