"""
Universal Data Loader - 支持 npz/csv，支持分块/整体加载，支持分开的训练/测试文件。

TSL 对齐（4 元组输出）：
  __getitem__ → (seq_x, seq_y, seq_x_mark, seq_y_mark)
    seq_x:      [seq_len, n_features]                （输入窗口）
    seq_y:      [label_len + pred_len, n_features_y] （decoder context + 预测目标）
    seq_x_mark: [seq_len, n_time_feats]              （输入时间特征；无 date 列时为 [seq_len, 0]）
    seq_y_mark: [label_len + pred_len, n_time_feats] （decoder 时间特征）

配置项扩展：
  label_len:    decoder 前缀长度（默认 48，对齐 TSL）
  features:     'M' / 'S' / 'MS'（多变量/单变量/多变量输入+单目标输出；默认 'M'）
  target:       'S' / 'MS' 模式下的目标列名或索引
  embed:        'timeF' → 规范化时间特征（timeenc=1）；其他 → 离散整数特征（timeenc=0）
  freq:         时间频率 'h' / 'min' / 'd' 等，影响时间特征维度
  date_col:     date 列名（默认 'date'；CSV 专用）
"""
import os
import numpy as np
import pandas as pd
import torch
from torch.utils.data import DataLoader, IterableDataset, Dataset
from typing import Optional, Tuple, List
from .base import BaseDataProvider
from .timefeatures import time_features, extract_discrete_time_features


# ---------------------------------------------------------------------------
# Dataset 封装：存储 data_x / data_y / data_stamp，__getitem__ 产 4 元组
# ---------------------------------------------------------------------------
def _stack_collate(batch):
    """显式 torch.stack 的 collate_fn，避免默认 collate 调用 storage.resize_()
    在 WSL2 / pin_memory + workers 场景下抛 'Trying to resize storage that is not resizable'。
    """
    return tuple(torch.stack([item[i] for item in batch], dim=0) for i in range(len(batch[0])))


class _SequenceDataset(Dataset):
    """TSL 风格 Dataset：按索引切出 (seq_x, seq_y, seq_x_mark, seq_y_mark)。

    Args:
        data_x:      [T, Fx]   输入特征数组（已归一化）
        data_y:      [T, Fy]   目标特征数组（通常与 data_x 同源，features='MS' 时 Fy=1）
        data_stamp:  [T, Fm]   时间特征数组；无时间信息时传 shape [T, 0]
        seq_len / label_len / pred_len: 窗口参数
    """

    def __init__(self, data_x, data_y, data_stamp, seq_len, label_len, pred_len):
        self.data_x = np.asarray(data_x, dtype=np.float32)
        self.data_y = np.asarray(data_y, dtype=np.float32)
        self.data_stamp = np.asarray(data_stamp, dtype=np.float32)
        assert self.data_x.shape[0] == self.data_y.shape[0] == self.data_stamp.shape[0], \
            f"data_x/y/stamp 行数不一致: {self.data_x.shape} {self.data_y.shape} {self.data_stamp.shape}"
        self.seq_len = seq_len
        # label_len 不能超过 seq_len（否则 r_begin = s_end - label_len 可能为负，
        # 产生空切片 [0, F]，导致 DataLoader stack 失败）。
        # 短序列数据集（如 ili, seq_len=36）会触发默认 label_len=48 过大的问题。
        self.label_len = min(label_len, seq_len)
        self.pred_len = pred_len

    def __len__(self):
        return len(self.data_x) - self.seq_len - self.pred_len + 1

    def __getitem__(self, index):
        s_begin = index
        s_end = s_begin + self.seq_len
        r_begin = s_end - self.label_len
        r_end = r_begin + self.label_len + self.pred_len

        # 用 torch.tensor(np.ascontiguousarray(...)) 强制分配独立、可调整大小的 storage。
        # torch.from_numpy 会与 numpy 共享底层 buffer，DataLoader 多 worker 的 collate
        # 调用 resize_ 时会抛 "Trying to resize storage that is not resizable"。
        return (
            torch.tensor(np.ascontiguousarray(self.data_x[s_begin:s_end]), dtype=torch.float32),
            torch.tensor(np.ascontiguousarray(self.data_y[r_begin:r_end]), dtype=torch.float32),
            torch.tensor(np.ascontiguousarray(self.data_stamp[s_begin:s_end]), dtype=torch.float32),
            torch.tensor(np.ascontiguousarray(self.data_stamp[r_begin:r_end]), dtype=torch.float32),
        )


class UniversalLoader(BaseDataProvider):
    """配置驱动的通用时序加载器（对齐 TSL 4 元组接口）。"""

    def __init__(self, config):
        super().__init__(config)

        self.chunk_mode = config.get('chunk_mode', False)
        self.chunk_size = config.get('chunk_size', None)
        self.loop_chunks = config.get('loop_chunks', False)

        self.seq_len = config.get('seq_len', 96)
        self.pred_len = config.get('pred_len', 24)
        self.label_len = config.get('label_len', 48)

        # TSL 风格参数
        self.features_mode = config.get('features', 'M')  # 'M' / 'S' / 'MS'
        self.target = config.get('target', None)          # 目标列名或索引
        self.embed = config.get('embed', 'timeF')         # 'timeF' / 'fixed' / 'learned'
        self.freq = config.get('freq', 'h')
        self.date_col = config.get('date_col', 'date')
        self.timeenc = 1 if self.embed == 'timeF' else 0

        self.batch_size = config.get('batch_size', 32)
        self.num_workers = config.get('num_workers', 4)
        self.shuffle = config.get('shuffle', True)

        self.normalize = config.get('normalize', True)

        self.train_data_path = config.get('train_data_path', None)
        self.test_data_path = config.get('test_data_path', None)
        self.single_file_mode = (self.train_data_path is None and self.test_data_path is None)

        # 特征名（从 NPZ 'columns' 键或 CSV header 提取，供可解释性回调使用）
        self.feature_names = None

        self._load_data()

        if not self.chunk_mode:
            self.splits = self._create_splits()
        else:
            self.splits = {}
            if self.normalize:
                self._compute_chunk_scaler()
                if not self.single_file_mode and hasattr(self, 'test_data'):
                    self._apply_normalization_to_test()

        self._current_chunk = 0
        self._total_chunks = self._calculate_total_chunks()

    # ------------------------------------------------------------------
    # 数据加载入口
    # ------------------------------------------------------------------
    def _load_data(self):
        format_type = self.config.get('format', 'npz')
        if not self.single_file_mode:
            self._load_split_data(format_type)
        else:
            self._load_single_data(format_type)

    def _load_single_data(self, format_type: str):
        path = self.config.get('path')
        if not os.path.exists(path):
            raise FileNotFoundError(f"Data file not found: {path}")

        if format_type == 'npz':
            if self.chunk_mode and self.chunk_size:
                self._init_npz_lazy(path)
            else:
                self._load_npz_standard(path)
        elif format_type == 'csv':
            if self.chunk_mode and self.chunk_size:
                self._init_csv_lazy(path)
            else:
                self._load_csv_standard(path)
        else:
            raise ValueError(f"Unsupported format: {format_type}")

    def _load_split_data(self, format_type: str):
        if not os.path.exists(self.train_data_path):
            raise FileNotFoundError(f"Train data file not found: {self.train_data_path}")

        if format_type == 'npz':
            if self.chunk_mode and self.chunk_size:
                self._init_npz_lazy(self.train_data_path)
            else:
                self._load_npz_standard(self.train_data_path, is_train=True)
        elif format_type == 'csv':
            if self.chunk_mode and self.chunk_size:
                self._init_csv_lazy(self.train_data_path)
            else:
                self._load_csv_standard(self.train_data_path, is_train=True)
        else:
            raise ValueError(f"Unsupported format: {format_type}")

        if self.test_data_path and os.path.exists(self.test_data_path):
            if format_type == 'npz':
                self._load_npz_standard(self.test_data_path, is_train=False)
            elif format_type == 'csv':
                self._load_csv_standard(self.test_data_path, is_train=False)

    # ------------------------------------------------------------------
    # NPZ / CSV 载入（元数据/原始内容）
    # ------------------------------------------------------------------
    def _init_npz_lazy(self, path: str):
        # allow_pickle=True 兼容 m4 等含 object dtype 的 npz（mmap 模式不允许 pickle）
        try:
            data = np.load(path, mmap_mode='r')
        except ValueError:
            data = np.load(path, allow_pickle=True)
        keys = list(data.keys())
        self._data_info = {
            'type': 'npz',
            'path': path,
            'keys': keys,
            'total_rows': data[keys[0]].shape[0],
            'mmap_data': data,
        }

    def _load_npz_standard(self, path: str, is_train: bool = True):
        # 始终 allow_pickle=True：NPZ 的 'date' 是 object dtype，若用默认 allow_pickle=False
        # 加载会让 data[keys[0]] 成功但后续访问 data['date'] 抛 ValueError 静默跳过时间特征。
        data = np.load(path, allow_pickle=True)
        keys = list(data.keys())
        info = {
            'type': 'npz',
            'path': path,
            'keys': keys,
            'mmap_data': data,
            'total_rows': data[keys[0]].shape[0],
        }
        if is_train:
            self._data_info = info
            self.data = data
        else:
            self._test_data_info = info
            self.test_data = data

    def _init_csv_lazy(self, path: str):
        df_sample = pd.read_csv(path, nrows=1)
        with open(path, encoding='utf-8') as f:
            total_rows = sum(1 for _ in f) - 1
        self._data_info = {
            'type': 'csv',
            'path': path,
            'columns': df_sample.columns.tolist(),
            'total_rows': total_rows,
        }

    def _load_csv_standard(self, path: str, is_train: bool = True):
        df = pd.read_csv(path)
        info = {
            'type': 'csv',
            'path': path,
            'columns': df.columns.tolist(),
            'total_rows': len(df),
        }
        if is_train:
            self._data_info = info
            self.data = df
        else:
            self._test_data_info = info
            self.test_data = df

    def _calculate_total_chunks(self):
        if not self.chunk_mode or not self.chunk_size:
            return 1
        total = self._data_info.get('total_rows', 0)
        return (total + self.chunk_size - 1) // self.chunk_size

    # ------------------------------------------------------------------
    # 原始数组与时间标签构造
    # ------------------------------------------------------------------
    def _extract_value_array(self, info: dict, data_obj=None):
        """从 info/data 对象装载数值矩阵 + 可选 dates。

        Returns:
            array: np.ndarray [T, F]
            dates: pd.DatetimeIndex | None
        """
        source = data_obj if data_obj is not None else (
            info['mmap_data'] if info['type'] == 'npz' else info['path']
        )
        if info['type'] == 'npz':
            key = 'data' if 'data' in source else info['keys'][0]
            array = np.asarray(source[key], dtype=np.float32)
            # NPZ 的可选 'columns' 键（若存在则记录为特征名，供可解释性回调使用）
            if 'columns' in source and getattr(self, 'feature_names', None) is None:
                try:
                    self.feature_names = [str(c) for c in np.asarray(source['columns'])]
                except Exception:
                    pass
            # NPZ 的可选 'date' 键（若存在则用作时间轴）
            dates = None
            if 'date' in source:
                try:
                    dates = pd.to_datetime(np.asarray(source['date']).astype(str))
                except Exception:
                    dates = None
            return array, dates

        if info['type'] == 'csv':
            df = source if isinstance(source, pd.DataFrame) else pd.read_csv(source)
            dates = None
            if self.date_col in df.columns:
                dates = pd.to_datetime(df[self.date_col])
                df = df.drop(columns=[self.date_col])
            columns = self._parse_columns(self.config.get('columns', 'all'), df.columns)
            if isinstance(columns, slice):
                array = df.values.astype(np.float32)
                col_names = list(df.columns)
            else:
                array = df[columns].values.astype(np.float32)
                col_names = list(columns)
            if getattr(self, 'feature_names', None) is None:
                self.feature_names = col_names
            return array, dates

        raise ValueError(f"Unknown data type: {info['type']}")

    def _build_data_stamp(self, dates, length: int) -> np.ndarray:
        """根据 dates 与 timeenc/freq 生成 [T, Fm] 时间特征。无 dates 时返回 [T, 0]。"""
        if dates is None or len(dates) == 0:
            return np.zeros((length, 0), dtype=np.float32)

        # TSL timefeatures 使用 DatetimeIndex 的 .hour/.dayofweek 等属性；
        # Series.dt.* 不同 —— 统一转为 DatetimeIndex
        dates = pd.DatetimeIndex(pd.to_datetime(dates))
        if len(dates) != length:
            # 罕见：日期长度不匹配时回退到空
            return np.zeros((length, 0), dtype=np.float32)

        if self.timeenc == 1:
            stamp = time_features(dates, freq=self.freq).transpose(1, 0)  # [T, Fm]
        else:
            stamp = extract_discrete_time_features(dates, freq=self.freq)
        return stamp.astype(np.float32)

    def _parse_columns(self, col_spec, all_columns=None):
        """解析列配置（'all'、'Sensor_0:Sensor_5'、列名列表）。"""
        if col_spec == 'all':
            return slice(None)
        if isinstance(col_spec, str):
            if ':' in col_spec:
                start, end = col_spec.split(':')
                # 若 all_columns 提供，走字符串列名范围（Sensor_0:Sensor_5）
                if all_columns is not None and start in all_columns and end in all_columns:
                    si = list(all_columns).index(start)
                    ei = list(all_columns).index(end)
                    return list(all_columns[si:ei + 1])
                # 否则按数字后缀解析（"Sensor_0:Sensor_5" → [Sensor_0..Sensor_5]）
                start_num = int(start.split('_')[-1])
                end_num = int(end.split('_')[-1])
                return [f"Sensor_{i}" for i in range(start_num, end_num + 1)]
            return [col_spec]
        return col_spec

    def _apply_feature_mode(self, array: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
        """按 features 模式 + target_col 拆分 data_x 与 data_y。

        优先级：
          - `target_col` 非 None/'last' → data_y 仅取该列集合（sibyl 原生扩展）
          - 否则按 TSL `features` 模式：
              'M'  : x=全部列, y=全部列
              'S'  : x=仅 target 列, y=仅 target 列（单变量）
              'MS' : x=全部列, y=仅 target 列
        """
        target_col_spec = self.config.get('target_col', None)

        # ---------- data_y ----------
        if target_col_spec is not None and target_col_spec != 'last':
            try:
                y_idx = self._resolve_target_col_indices(target_col_spec, array.shape[1])
            except (ValueError, TypeError) as e:
                raise ValueError(f"Invalid target_col: {target_col_spec}") from e
            data_y = array[:, y_idx]
        elif self.features_mode in ('S', 'MS'):
            idx = self._resolve_target_idx(array.shape[1])
            data_y = array[:, idx:idx + 1]
        else:  # 'M' / 'last' / None
            data_y = array

        # ---------- data_x ----------
        if self.features_mode == 'S':
            idx = self._resolve_target_idx(array.shape[1])
            data_x = array[:, idx:idx + 1]
        else:
            data_x = array

        return data_x, data_y

    def _resolve_target_col_indices(self, spec, n_features: int) -> List[int]:
        """解析 target_col 说明为列索引列表。

        接受:
          - str  'Sensor_0'          → [0]
          - str  'Sensor_0:Sensor_5' → [0..5]
          - str  '0:4'               → [0..4]
          - list ['0', '1', '3']     → [0, 1, 3]
        """
        if isinstance(spec, str):
            return self._parse_column_indices(spec, n_features)
        if isinstance(spec, list):
            idx = []
            for col in spec:
                idx.extend(self._parse_column_indices(col, n_features))
            return idx
        raise ValueError(f"target_col must be str or list, got {type(spec)}")

    def _parse_column_indices(self, col_spec: str, n_features: int) -> List[int]:
        if ':' in col_spec:
            parts = col_spec.split(':')
            start = self._extract_number(parts[0])
            end = self._extract_number(parts[1]) + 1
            return list(range(start, min(end, n_features)))
        idx = self._extract_number(col_spec)
        return [idx] if idx < n_features else [n_features - 1]

    @staticmethod
    def _extract_number(s: str) -> int:
        import re
        numbers = re.findall(r'\d+', s)
        return int(numbers[0]) if numbers else 0

    def _resolve_target_idx(self, n_cols: int) -> int:
        """解析 target（TSL 'S'/'MS' 模式单列索引）。"""
        if self.target is None:
            return n_cols - 1
        if isinstance(self.target, int):
            return min(self.target, n_cols - 1)
        if isinstance(self.target, str):
            import re
            m = re.findall(r'\d+', self.target)
            if m:
                return min(int(m[0]), n_cols - 1)
        return n_cols - 1

    # ------------------------------------------------------------------
    # 归一化辅助
    # ------------------------------------------------------------------
    def _fit_and_apply_scaler(self, array: np.ndarray, train_rows_end: int) -> np.ndarray:
        """在 array[:train_rows_end] 上拟合 mean/std，应用于整段数据（防泄漏）。"""
        if not self.normalize:
            return array
        train_rows = array[:max(train_rows_end, 1)]
        mean = train_rows.mean(axis=0).astype(np.float32)
        std = train_rows.std(axis=0).astype(np.float32)
        std = np.where(std < 1e-8, 1.0, std).astype(np.float32)
        self.set_scaler_stats(torch.from_numpy(mean), torch.from_numpy(std))
        return (array - mean) / std

    def _apply_scaler(self, array: np.ndarray) -> np.ndarray:
        if self.scaler_stats is None:
            return array
        mean = self.scaler_stats['mean'].cpu().numpy()
        std = self.scaler_stats['std'].cpu().numpy()
        return (array.astype(np.float32) - mean) / std

    # ------------------------------------------------------------------
    # 标准模式：全量加载 + 行级 split + 窗口内部生成
    # ------------------------------------------------------------------
    def _create_splits(self):
        if self.chunk_mode:
            return {}

        array, dates = self._extract_value_array(self._data_info)
        n_rows = array.shape[0]
        win = self.seq_len + self.pred_len
        if n_rows < win:
            raise ValueError(f"Data too short: {n_rows} samples, need at least {win} samples")

        if not self.single_file_mode:
            split_ratio = self.config.get('split_ratio', [0.85, 0.15])
            train_rows_end = int(n_rows * split_ratio[0])
            val_rows_end = n_rows
        else:
            split_ratio = self.config.get('split_ratio', [0.7, 0.15, 0.15])
            train_rows_end = int(n_rows * split_ratio[0])
            val_rows_end = int(n_rows * (split_ratio[0] + split_ratio[1]))

        array = self._fit_and_apply_scaler(array, train_rows_end)
        data_x, data_y = self._apply_feature_mode(array)
        data_stamp = self._build_data_stamp(dates, array.shape[0])

        def _make_ds(x_slice, y_slice, stamp_slice):
            if x_slice.shape[0] < win:
                return None
            return _SequenceDataset(x_slice, y_slice, stamp_slice,
                                    self.seq_len, self.label_len, self.pred_len)

        # TSL 协议：val/test 起点回退 seq_len 行（border1s），使滑窗首样本输入跨越前一
        # split 尾部、输出落在新 split 起点。与 TSL Dataset_Custom 一致，让模型对 split
        # 边界无 cold-start 惩罚。详见 Time-Series-Library/data_provider/data_loader.py。
        val_start = max(0, train_rows_end - self.seq_len)
        test_start = max(0, val_rows_end - self.seq_len)

        splits = {
            'train': _make_ds(
                data_x[:train_rows_end], data_y[:train_rows_end], data_stamp[:train_rows_end]
            ),
            'val':   _make_ds(
                data_x[val_start:val_rows_end],
                data_y[val_start:val_rows_end],
                data_stamp[val_start:val_rows_end],
            ),
        }

        if not self.single_file_mode:
            if self.normalize and hasattr(self, 'test_data'):
                self._apply_normalization_to_test()
            splits['test'] = self._build_independent_test_dataset()
        else:
            splits['test'] = _make_ds(
                data_x[test_start:], data_y[test_start:], data_stamp[test_start:]
            )

        return splits

    # ------------------------------------------------------------------
    # 独立测试文件：应用训练统计量 + 生成 Dataset
    # ------------------------------------------------------------------
    def _apply_normalization_to_test(self):
        if self.scaler_stats is None or not hasattr(self, '_test_data_info'):
            return
        array, dates = self._extract_value_array(self._test_data_info, data_obj=self.test_data)
        self._test_normalized = self._apply_scaler(array)
        self._test_dates = dates

    def _build_independent_test_dataset(self):
        if not hasattr(self, '_test_data_info'):
            return None
        if hasattr(self, '_test_normalized'):
            array = self._test_normalized
            dates = getattr(self, '_test_dates', None)
        else:
            array, dates = self._extract_value_array(self._test_data_info, data_obj=self.test_data)

        win = self.seq_len + self.pred_len
        if array.shape[0] < win:
            return None
        data_x, data_y = self._apply_feature_mode(array)
        data_stamp = self._build_data_stamp(dates, array.shape[0])
        return _SequenceDataset(data_x, data_y, data_stamp,
                                self.seq_len, self.label_len, self.pred_len)

    # ------------------------------------------------------------------
    # Chunk 模式
    # ------------------------------------------------------------------
    def _compute_chunk_scaler(self):
        total_rows = self._data_info.get('total_rows', 0)
        if total_rows <= 0:
            return

        if not self.single_file_mode:
            split_ratio = self.config.get('split_ratio', [0.85, 0.15])
            train_end = max(int(total_rows * split_ratio[0]), 1)
            self._split_row_bounds = {
                'train': (0, train_end),
                'val':   (train_end, total_rows),
            }
        else:
            split_ratio = self.config.get('split_ratio', [0.7, 0.15, 0.15])
            train_end = max(int(total_rows * split_ratio[0]), 1)
            val_end   = max(int(total_rows * (split_ratio[0] + split_ratio[1])), train_end)
            self._split_row_bounds = {
                'train': (0, train_end),
                'val':   (train_end, val_end),
                'test':  (val_end, total_rows),
            }

        if self._data_info['type'] == 'npz':
            mmap = self._data_info['mmap_data']
            key = 'data' if 'data' in mmap else self._data_info['keys'][0]
            train_rows = np.asarray(mmap[key][:train_end], dtype=np.float32)
        elif self._data_info['type'] == 'csv':
            df_head = pd.read_csv(self._data_info['path'], nrows=train_end)
            if self.date_col in df_head.columns:
                df_head = df_head.drop(columns=[self.date_col])
            columns = self._parse_columns(self.config.get('columns', 'all'), df_head.columns)
            if isinstance(columns, slice):
                train_rows = df_head.values.astype(np.float32)
            else:
                train_rows = df_head[columns].values.astype(np.float32)
        else:
            return

        mean = train_rows.mean(axis=0).astype(np.float32)
        std = train_rows.std(axis=0).astype(np.float32)
        std = np.where(std < 1e-8, 1.0, std).astype(np.float32)
        self.set_scaler_stats(torch.from_numpy(mean), torch.from_numpy(std))

    def _read_chunk(self, row_start: int, row_end: int):
        """从原文件读取 [row_start, row_end) 行；返回 (array, dates)。"""
        if self._data_info['type'] == 'npz':
            mmap = self._data_info['mmap_data']
            key = 'data' if 'data' in mmap else self._data_info['keys'][0]
            array = np.asarray(mmap[key][row_start:row_end], dtype=np.float32)
            dates = None
            if 'date' in mmap:
                try:
                    all_dates = pd.to_datetime(np.asarray(mmap['date']).astype(str))
                    dates = all_dates[row_start:row_end]
                except Exception:
                    dates = None
            return array, dates

        if self._data_info['type'] == 'csv':
            df = pd.read_csv(
                self._data_info['path'],
                skiprows=range(1, row_start + 1),
                nrows=row_end - row_start,
                header=0,
            )
            dates = None
            if self.date_col in df.columns:
                dates = pd.to_datetime(df[self.date_col])
                df = df.drop(columns=[self.date_col])
            columns = self._parse_columns(self.config.get('columns', 'all'), df.columns)
            if isinstance(columns, slice):
                array = df.values.astype(np.float32)
            else:
                array = df[columns].values.astype(np.float32)
            return array, dates

        raise ValueError(f"Unknown data type: {self._data_info['type']}")

    def _iter_split_chunks(self, row_start: int, row_end: int):
        """按行范围分块读取并产出 (seq_x, seq_y, seq_x_mark, seq_y_mark) batched tensors。"""
        pos = row_start
        win = self.seq_len + self.pred_len

        while pos < row_end:
            chunk_end = min(pos + self.chunk_size, row_end)
            if chunk_end - pos < win:
                break

            array, dates = self._read_chunk(pos, chunk_end)
            array = self._apply_scaler(array)
            data_x, data_y = self._apply_feature_mode(array)
            stamp = self._build_data_stamp(dates, array.shape[0])

            ds = _SequenceDataset(data_x, data_y, stamp, self.seq_len, self.label_len, self.pred_len)
            for i in range(len(ds)):
                yield ds[i]
            pos = chunk_end

    # ------------------------------------------------------------------
    # 接口
    # ------------------------------------------------------------------
    def get_raw_data(self) -> 'np.ndarray':
        if not hasattr(self, 'data') or self.data is None:
            return None
        if isinstance(self.data, pd.DataFrame):
            # 仅返回数值列，剔除 date 等 object/string 列（否则 .values 返回 object dtype，
            # 下游 DataProfiler 的 np.nanmean 会报 TypeError）
            num_df = self.data.select_dtypes(include=[np.number])
            return num_df.values.astype(np.float32) if len(num_df.columns) > 0 else None
        if hasattr(self.data, 'keys'):
            key = 'data' if 'data' in self.data else list(self.data.keys())[0]
            arr = np.array(self.data[key])
            return arr.astype(np.float32) if arr.dtype != object else None
        return np.array(self.data)

    def get_train_loader(self):
        return self._get_chunk_loader('train') if self.chunk_mode else self._get_standard_loader('train')

    def get_val_loader(self):
        return self._get_chunk_loader('val') if self.chunk_mode else self._get_standard_loader('val')

    def get_test_loader(self):
        return self._get_chunk_loader('test') if self.chunk_mode else self._get_standard_loader('test')

    # ------------------------------------------------------------------
    # 标准 DataLoader
    # ------------------------------------------------------------------
    def _get_standard_loader(self, split: str):
        dataset = self.splits.get(split)

        if split == 'test' and dataset is None:
            dataset = self._build_independent_test_dataset()

        if dataset is None:
            raise ValueError(f"No data available for split: {split}")

        shuffle = (split == 'train' and self.shuffle)
        return DataLoader(
            dataset,
            batch_size=self.batch_size,
            shuffle=shuffle,
            num_workers=self.num_workers,
            pin_memory=True,
            collate_fn=_stack_collate,
        )

    # ------------------------------------------------------------------
    # Chunk DataLoader
    # ------------------------------------------------------------------
    def _get_chunk_loader(self, mode: str):
        # split-file 模式下 test 用独立文件（整体加载）
        if mode == 'test' and not self.single_file_mode:
            dataset = self._build_independent_test_dataset()
            if dataset is None:
                raise ValueError("split-file chunk_mode: test_data 不可用")
            return DataLoader(
                dataset,
                batch_size=self.batch_size,
                shuffle=False,
                num_workers=0,
                pin_memory=True,
                collate_fn=_stack_collate,
            )

        if hasattr(self, '_split_row_bounds') and mode in self._split_row_bounds:
            row_start, row_end = self._split_row_bounds[mode]
        else:
            row_start, row_end = 0, self._data_info.get('total_rows', 0)

        parent = self

        class ChunkIterableDataset(IterableDataset):
            def __init__(self, r0, r1):
                self.r0, self.r1 = r0, r1

            def __iter__(self):
                return parent._iter_split_chunks(self.r0, self.r1)

        return DataLoader(
            ChunkIterableDataset(row_start, row_end),
            batch_size=self.batch_size,
            num_workers=0,
        )

    # ------------------------------------------------------------------
    # BaseDataProvider 抽象方法（遗留 API）
    # ------------------------------------------------------------------
    def next_chunk(self) -> Optional[Tuple[np.ndarray, np.ndarray]]:
        """遗留接口：返回 (features, targets)  2 元组（非 4 元组）以保持旧调用方兼容。"""
        if not self.chunk_mode:
            raise RuntimeError("next_chunk() requires chunk_mode=True")
        if self._current_chunk >= self._total_chunks:
            if self.loop_chunks:
                self._current_chunk = 0
            else:
                return None

        start_idx = self._current_chunk * self.chunk_size
        total = self._data_info.get('total_rows', 0)
        end_idx = min(start_idx + self.chunk_size, total)
        if end_idx - start_idx < self.seq_len + self.pred_len:
            return None

        array, _ = self._read_chunk(start_idx, end_idx)
        array = self._apply_scaler(array)
        data_x, data_y = self._apply_feature_mode(array)

        # 生成滑窗：features = [N, seq_len, Fx]；targets = [N, pred_len, Fy]
        win = self.seq_len + self.pred_len
        n = array.shape[0] - win + 1
        features = np.stack([data_x[i:i + self.seq_len] for i in range(n)])
        targets = np.stack([data_y[i + self.seq_len:i + win] for i in range(n)])
        self._current_chunk += 1
        return features, targets

    def reset_chunk(self):
        self._current_chunk = 0

    def list_available_chunks(self) -> List[int]:
        return list(range(self._total_chunks))

    def get_chunk_info(self) -> dict:
        return {
            'total_chunks': self._total_chunks,
            'current_chunk': self._current_chunk,
            'chunk_size': self.chunk_size,
            'chunk_mode': self.chunk_mode,
            'loop_chunks': self.loop_chunks,
            'total_rows': self._data_info.get('total_rows', 0),
            'seq_len': self.seq_len,
            'pred_len': self.pred_len,
            'label_len': self.label_len,
            'batch_size': self.batch_size,
            'single_file_mode': self.single_file_mode,
            'features_mode': self.features_mode,
            'timeenc': self.timeenc,
            'freq': self.freq,
        }
