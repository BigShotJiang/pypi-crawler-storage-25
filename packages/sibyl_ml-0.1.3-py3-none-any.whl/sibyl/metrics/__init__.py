"""
Metrics 模块
"""
from .registry import registry, get_metric
from .metrics_manager import MetricsManager

# Import metric modules to trigger registration
from . import errors
from . import correlation
from . import resource
from . import performance
from . import physical_violation

# Export InferenceTimer
from .performance import InferenceTimer

__all__ = ['registry', 'get_metric', 'MetricsManager', 'InferenceTimer']
