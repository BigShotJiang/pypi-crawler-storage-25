"""
指标注册表
"""
import torch
from typing import Type, Dict


class MetricRegistry:
    """指标注册表"""

    def __init__(self):
        self._metrics: Dict[str, Type] = {}

    def register(self, name: str, metric_class: Type = None):
        """注册指标
        Args:
            name: 指标名称
            metric_class: 指标类（可选，支持装饰器用法）
        Returns:
            装饰器函数或 metric_class（支持装饰器用法）
        """
        def decorator(cls):
            self._metrics[name] = cls
            return cls

        if metric_class is not None:
            # 直接调用: register('name', Class)
            self._metrics[name] = metric_class
            return metric_class
        else:
            # 装饰器用法: @register('name')
            return decorator

    def get(self, name: str) -> Type:
        """获取指标类
        Args:
            name: 指标名称
        Returns:
            指标类
        """
        if name not in self._metrics:
            raise ValueError(f"Metric '{name}' not found. Available: {list(self._metrics.keys())}")
        return self._metrics[name]

    def list_available(self) -> list:
        """列出所有可用指标"""
        return list(self._metrics.keys())


# 全局注册表实例
registry = MetricRegistry()


def get_metric(name: str):
    """获取指标实例
    Args:
        name: 指标名称
    Returns:
        指标实例
    """
    metric_class = registry.get(name)
    return metric_class()
