"""
相关性指标
"""
import torch
from .base import BaseMetric
from .registry import registry


@registry.register('R2')
class R2(BaseMetric):
    """R-squared (Coefficient of Determination)"""

    def __call__(self, preds: torch.Tensor, targets: torch.Tensor) -> float:
        ss_res = torch.sum((targets - preds) ** 2)
        ss_tot = torch.sum((targets - torch.mean(targets)) ** 2)
        r2 = 1 - (ss_res / (ss_tot + 1e-8))
        return r2.item()


@registry.register('PCC')
class PCC(BaseMetric):
    """Pearson Correlation Coefficient"""

    def __call__(self, preds: torch.Tensor, targets: torch.Tensor) -> float:
        # 展平为 1D 向量
        preds_flat = preds.flatten()
        targets_flat = targets.flatten()

        # 计算协方差和标准差
        mean_pred = torch.mean(preds_flat)
        mean_target = torch.mean(targets_flat)

        covariance = torch.mean((preds_flat - mean_pred) * (targets_flat - mean_target))
        std_pred = torch.std(preds_flat)
        std_target = torch.std(targets_flat)

        pcc = covariance / (std_pred * std_target + 1e-8)
        return pcc.item()
