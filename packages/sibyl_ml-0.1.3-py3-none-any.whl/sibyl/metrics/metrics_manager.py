"""
指标管理器
"""
import torch
from typing import Dict, List
from .registry import registry


class MetricsManager:
    """指标管理器，批量计算多个指标"""

    def __init__(self, metric_names: List[str], model: torch.nn.Module = None,
                 timer=None):
        """
        Args:
            metric_names: 指标名称列表
            model: 模型（用于 Model_Params 和 Model_Size 指标）
            timer: 推理计时器（用于性能指标）
        """
        self.metric_names = metric_names
        self.metrics = {}
        self.extra_args = {}

        # 初始化指标（直接拿类，避免先实例化再取 __class__ 的浪费）
        for name in metric_names:
            metric_class = registry.get(name)

            # 检查是否需要额外参数
            if name in ['Model_Params', 'Model_Size']:
                metric_instance = metric_class(model)
            elif name in ['Inference_Time_Per_Sample', 'Inference_Throughput',
                         'Total_Inference_Time', 'Samples_Per_Second',
                         'Latency_P50', 'Latency_P95', 'Latency_P99']:
                metric_instance = metric_class(timer)
            else:
                metric_instance = metric_class()

            self.metrics[name] = metric_instance

            # 保存额外参数引用
            if name in ['Model_Params', 'Model_Size']:
                self.extra_args['model'] = model
            elif name in ['Inference_Time_Per_Sample', 'Inference_Throughput',
                         'Total_Inference_Time', 'Samples_Per_Second',
                         'Latency_P50', 'Latency_P95', 'Latency_P99']:
                self.extra_args['timer'] = timer

    def set_model(self, model: torch.nn.Module):
        """设置模型（用于需要模型的指标）"""
        self.extra_args['model'] = model
        for name in ['Model_Params', 'Model_Size']:
            if name in self.metrics:
                self.metrics[name].set_model(model)

    def set_timer(self, timer):
        """设置计时器（用于需要计时器的指标）"""
        self.extra_args['timer'] = timer
        timing_metrics = ['Inference_Time_Per_Sample', 'Inference_Throughput',
                        'Total_Inference_Time', 'Samples_Per_Second',
                        'Latency_P50', 'Latency_P95', 'Latency_P99']
        for name in timing_metrics:
            if name in self.metrics:
                self.metrics[name].set_timer(timer)

    def compute_all(self, preds: torch.Tensor, targets: torch.Tensor) -> Dict[str, float]:
        """计算所有指标
        Args:
            preds: 预测值
            targets: 真实值
        Returns:
            指标字典 {name: value}
        """
        results = {}
        for name, metric in self.metrics.items():
            results[name] = metric(preds, targets)
        return results

    def save_to_csv(self, metrics: Dict[str, float], filepath: str):
        """保存指标到 CSV
        Args:
            metrics: 指标字典
            filepath: 保存路径
        """
        import csv
        import os
        from pathlib import Path

        Path(filepath).parent.mkdir(parents=True, exist_ok=True)

        with open(filepath, 'w', newline='') as f:
            writer = csv.writer(f)
            writer.writerow(['Metric', 'Value'])
            for name, value in metrics.items():
                writer.writerow([name, value])
