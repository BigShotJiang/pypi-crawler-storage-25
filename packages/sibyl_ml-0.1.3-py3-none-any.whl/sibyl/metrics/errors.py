"""
误差指标
"""
import torch
from .base import BaseMetric
from .registry import registry


@registry.register('MAE')
class MAE(BaseMetric):
    """Mean Absolute Error"""

    def __call__(self, preds: torch.Tensor, targets: torch.Tensor) -> float:
        return torch.mean(torch.abs(preds - targets)).item()


@registry.register('MSE')
class MSE(BaseMetric):
    """Mean Squared Error"""

    def __call__(self, preds: torch.Tensor, targets: torch.Tensor) -> float:
        return torch.mean((preds - targets) ** 2).item()


@registry.register('RMSE')
class RMSE(BaseMetric):
    """Root Mean Squared Error"""

    def __call__(self, preds: torch.Tensor, targets: torch.Tensor) -> float:
        mse = torch.mean((preds - targets) ** 2)
        return torch.sqrt(mse).item()


@registry.register('MAPE')
class MAPE(BaseMetric):
    """Mean Absolute Percentage Error (%)"""

    def __call__(self, preds: torch.Tensor, targets: torch.Tensor) -> float:
        eps = 1e-8
        # 分母取 |targets|，避免负值 target 让 (targets + eps) 更接近 0 而放大误差
        ape = torch.abs(targets - preds) / (torch.abs(targets) + eps)
        return torch.mean(ape).item() * 100


@registry.register('sMAPE')
class sMAPE(BaseMetric):
    """Symmetric Mean Absolute Percentage Error (%)"""

    def __call__(self, preds: torch.Tensor, targets: torch.Tensor) -> float:
        eps = 1e-8
        smape = 2 * torch.abs(targets - preds) / (torch.abs(targets) + torch.abs(preds) + eps)
        return torch.mean(smape).item() * 100


@registry.register('MSPE')
class MSPE(BaseMetric):
    """Mean Squared Percentage Error (%)"""

    def __call__(self, preds: torch.Tensor, targets: torch.Tensor) -> float:
        eps = 1e-8
        # 分母取 |targets|，理由同 MAPE
        spe = ((targets - preds) / (torch.abs(targets) + eps)) ** 2
        return torch.mean(spe).item() * 100


@registry.register('RAE')
class RAE(BaseMetric):
    """Relative Absolute Error"""

    def __call__(self, preds: torch.Tensor, targets: torch.Tensor) -> float:
        # RAE = sum(|y - y_hat|) / sum(|y - mean(y)|)
        abs_error = torch.sum(torch.abs(targets - preds))
        abs_baseline = torch.sum(torch.abs(targets - torch.mean(targets)))
        return (abs_error / (abs_baseline + 1e-8)).item()


@registry.register('MASE')
class MASE(BaseMetric):
    """Mean Absolute Scaled Error"""

    def __call__(self, preds: torch.Tensor, targets: torch.Tensor) -> float:
        # MASE = MAE / MAE_naive
        mae = torch.mean(torch.abs(targets - preds))

        # Naive forecast: 使用上一时刻的值作为预测
        if targets.shape[1] > 1:
            naive_preds = targets[:, :-1, :]
            naive_targets = targets[:, 1:, :]
            mae_naive = torch.mean(torch.abs(naive_targets - naive_preds))
        else:
            mae_naive = torch.mean(torch.abs(targets - torch.mean(targets)))

        return (mae / (mae_naive + 1e-8)).item()
