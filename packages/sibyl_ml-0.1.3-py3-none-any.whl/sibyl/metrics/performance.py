"""
性能指标
"""
import torch
import time
from typing import Optional, List
from .base import BaseMetric
from .registry import registry


class InferenceTimer:
    """推理计时器"""

    def __init__(self):
        self.total_time = 0.0
        self.n_samples = 0
        self.latencies: List[float] = []
        self.start_time: Optional[float] = None

    def start(self):
        """开始计时"""
        if torch.cuda.is_available():
            torch.cuda.synchronize()
        self.start_time = time.perf_counter()

    def end(self, n_samples=1):
        """结束计时"""
        if self.start_time is not None:
            if torch.cuda.is_available():
                torch.cuda.synchronize()
            elapsed = time.perf_counter() - self.start_time
            self.total_time += elapsed
            self.n_samples += n_samples
            self.latencies.append(elapsed / n_samples)  # 平均延迟
            self.start_time = None

    def get_avg_time(self):
        """获取平均推理时间"""
        if self.n_samples == 0:
            return 0.0
        return self.total_time / self.n_samples

    def get_throughput(self):
        """获取吞吐量"""
        if self.total_time == 0:
            return 0.0
        return self.n_samples / self.total_time

    def reset(self):
        """重置计时器"""
        self.total_time = 0.0
        self.n_samples = 0
        self.latencies = []
        self.start_time = None


@registry.register('Inference_Time_Per_Sample')
class InferenceTimePerSample(BaseMetric):
    """单样本推理时间 (ms)"""

    def __init__(self, timer: Optional[InferenceTimer] = None):
        self.timer = timer

    def set_timer(self, timer: InferenceTimer):
        """设置计时器"""
        self.timer = timer

    def __call__(self, preds: torch.Tensor, targets: torch.Tensor) -> float:
        if self.timer is not None:
            return self.timer.get_avg_time() * 1000  # 转换为 ms
        return 0.0


@registry.register('Inference_Throughput')
class InferenceThroughput(BaseMetric):
    """推理吞吐量"""

    def __init__(self, timer: Optional[InferenceTimer] = None):
        self.timer = timer

    def set_timer(self, timer: InferenceTimer):
        """设置计时器"""
        self.timer = timer

    def __call__(self, preds: torch.Tensor, targets: torch.Tensor) -> float:
        if self.timer is not None:
            return self.timer.get_throughput()
        return 0.0


@registry.register('Total_Inference_Time')
class TotalInferenceTime(BaseMetric):
    """总推理时间 (s)"""

    def __init__(self, timer: Optional[InferenceTimer] = None):
        self.timer = timer

    def set_timer(self, timer: InferenceTimer):
        """设置计时器"""
        self.timer = timer

    def __call__(self, preds: torch.Tensor, targets: torch.Tensor) -> float:
        if self.timer is not None:
            return self.timer.total_time
        return 0.0


@registry.register('Samples_Per_Second')
class SamplesPerSecond(BaseMetric):
    """每秒样本数"""

    def __init__(self, timer: Optional[InferenceTimer] = None):
        self.timer = timer

    def set_timer(self, timer: InferenceTimer):
        """设置计时器"""
        self.timer = timer

    def __call__(self, preds: torch.Tensor, targets: torch.Tensor) -> float:
        if self.timer is not None and self.timer.total_time > 0:
            return self.timer.n_samples / self.timer.total_time
        return 0.0


@registry.register('Latency_P50')
class LatencyP50(BaseMetric):
    """推理延迟 P50 (ms)"""

    def __init__(self, timer: Optional[InferenceTimer] = None):
        self.timer = timer

    def set_timer(self, timer: InferenceTimer):
        """设置计时器"""
        self.timer = timer

    def __call__(self, preds: torch.Tensor, targets: torch.Tensor) -> float:
        if self.timer is not None and self.timer.latencies:
            import numpy as np
            return np.percentile(self.timer.latencies, 50) * 1000
        return 0.0


@registry.register('Latency_P95')
class LatencyP95(BaseMetric):
    """推理延迟 P95 (ms)"""

    def __init__(self, timer: Optional[InferenceTimer] = None):
        self.timer = timer

    def set_timer(self, timer: InferenceTimer):
        """设置计时器"""
        self.timer = timer

    def __call__(self, preds: torch.Tensor, targets: torch.Tensor) -> float:
        if self.timer is not None and self.timer.latencies:
            import numpy as np
            return np.percentile(self.timer.latencies, 95) * 1000
        return 0.0


@registry.register('Latency_P99')
class LatencyP99(BaseMetric):
    """推理延迟 P99 (ms)"""

    def __init__(self, timer: Optional[InferenceTimer] = None):
        self.timer = timer

    def set_timer(self, timer: InferenceTimer):
        """设置计时器"""
        self.timer = timer

    def __call__(self, preds: torch.Tensor, targets: torch.Tensor) -> float:
        if self.timer is not None and self.timer.latencies:
            import numpy as np
            return np.percentile(self.timer.latencies, 99) * 1000
        return 0.0
