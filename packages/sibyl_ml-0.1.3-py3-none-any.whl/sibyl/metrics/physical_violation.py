"""
物理违例率 (Physical Violation Rate, PVR) 指标。

论文 §5.3.3 Table 4 的关键消融列：对比基线 vs +smooth/+spatial/+script/+ALL 的
物理违例比例，验证 PINN 损失不仅降低数值误差，还提升物理合理性。

两类指标：
  - PVR_Bounds       ：预测中越过物理边界 [min_val, max_val] 的点数占比
  - PVR_Monotonicity ：相邻时间步违反 direction (inc/dec) 的点数占比

输出统一为百分比 (%)。
"""
import torch
from .base import BaseMetric
from .registry import registry


@registry.register('PVR_Bounds')
class PhysicalBoundsViolationRate(BaseMetric):
    """比例 (%)：预测张量中落在 [min_val, max_val] 之外的元素数 / 总元素数。

    参数从 config 读取；若未配置则从 `BaseMetric` 的调用栈拿不到——因此推荐
    搭配 `configs/metrics/with_pvr.yaml` + 指定 min_val/max_val 使用。
    当 min_val=-inf 且 max_val=+inf 时（默认），指标恒为 0。
    """

    def __init__(self, min_val: float = float('-inf'), max_val: float = float('inf')):
        self.min_val = float(min_val)
        self.max_val = float(max_val)

    def __call__(self, preds: torch.Tensor, targets: torch.Tensor) -> float:
        if preds.numel() == 0:
            return 0.0
        below = (preds < self.min_val)
        above = (preds > self.max_val)
        violations = (below | above).float().sum().item()
        return 100.0 * violations / preds.numel()


@registry.register('PVR_Monotonicity')
class MonotonicityViolationRate(BaseMetric):
    """比例 (%)：相邻时间步违反 direction 的点数 / 总时间步对数。

    direction='increasing' 时，期望 pred[:, t+1, :] >= pred[:, t, :]；
    direction='decreasing' 时，期望 pred[:, t+1, :] <= pred[:, t, :]。

    对形状 [B, T, F]：违例对总数 = B * (T-1) * F。
    """

    def __init__(self, direction: str = 'increasing'):
        if direction not in ('increasing', 'decreasing'):
            raise ValueError(f"direction 必须是 'increasing' 或 'decreasing'，收到: {direction}")
        self.direction = direction

    def __call__(self, preds: torch.Tensor, targets: torch.Tensor) -> float:
        if preds.ndim < 2 or preds.shape[-2 if preds.ndim >= 2 else 0] < 2:
            return 0.0
        # 统一处理 [T, F] 和 [B, T, F]
        if preds.ndim == 2:
            diffs = preds[1:] - preds[:-1]
        else:
            diffs = preds[:, 1:] - preds[:, :-1]

        if self.direction == 'increasing':
            violations = (diffs < 0).float().sum().item()
        else:
            violations = (diffs > 0).float().sum().item()
        total = diffs.numel()
        return 100.0 * violations / max(total, 1)


@registry.register('PVR_Smoothness')
class SmoothnessViolationRate(BaseMetric):
    """比例 (%)：二阶差分绝对值超过 threshold 的点数占比。

    反映 "物理上平滑信号的预测不应包含剧烈振荡" 的先验。threshold 默认 1.0
    (对已归一化预测合适)；业务需根据量纲调整。
    """

    def __init__(self, threshold: float = 1.0):
        self.threshold = float(threshold)

    def __call__(self, preds: torch.Tensor, targets: torch.Tensor) -> float:
        if preds.ndim < 2:
            return 0.0
        if preds.ndim == 2 and preds.shape[0] < 3:
            return 0.0
        if preds.ndim == 3 and preds.shape[1] < 3:
            return 0.0

        if preds.ndim == 2:
            d2 = preds[2:] - 2 * preds[1:-1] + preds[:-2]
        else:
            d2 = preds[:, 2:] - 2 * preds[:, 1:-1] + preds[:, :-2]

        violations = (d2.abs() > self.threshold).float().sum().item()
        total = d2.numel()
        return 100.0 * violations / max(total, 1)
