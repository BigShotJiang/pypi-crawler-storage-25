"""
资源占用指标
"""
import torch
import psutil
from typing import Optional
from .base import BaseMetric
from .registry import registry


@registry.register('CPU_Memory')
class CPUMemory(BaseMetric):
    """CPU 内存占用 (MB)"""

    def __call__(self, preds: torch.Tensor, targets: torch.Tensor) -> float:
        process = psutil.Process()
        mem = process.memory_info().rss / (1024 ** 2)  # MB
        return mem


@registry.register('CPU_Utilization')
class CPUUtilization(BaseMetric):
    """CPU 占用率 (%)"""

    def __init__(self):
        self.process = psutil.Process()

    def __call__(self, preds: torch.Tensor, targets: torch.Tensor) -> float:
        return self.process.cpu_percent(interval=0.1)


@registry.register('GPU_Memory')
class GPUMemory(BaseMetric):
    """GPU 显存峰值占用 (MB)。

    使用 max_memory_reserved() — PyTorch 从 CUDA driver 申请的全部显存峰值，
    含 cache pool，比 max_memory_allocated() 更接近 nvidia-smi 读数。
    trainer.py 会在 callbacks 之前再次覆盖此值，以确保 leaderboard 写入正确峰值。
    """

    def __call__(self, preds: torch.Tensor, targets: torch.Tensor) -> float:
        if torch.cuda.is_available():
            return torch.cuda.max_memory_reserved() / (1024 ** 2)
        return 0.0


@registry.register('GPU_Memory_Peak')
class GPUMemoryPeak(BaseMetric):
    """GPU 显存峰值 (MB) — 与 `GPU_Memory` 等价，保留别名供旧配置使用"""

    def __call__(self, preds: torch.Tensor, targets: torch.Tensor) -> float:
        if torch.cuda.is_available():
            return torch.cuda.max_memory_reserved() / (1024 ** 2)
        return 0.0


@registry.register('GPU_Memory_Reserved')
class GPUMemoryReserved(BaseMetric):
    """GPU 保留显存峰值 (MB) — 接近 nvidia-smi 观测值（含 PyTorch 缓存池）"""

    def __call__(self, preds: torch.Tensor, targets: torch.Tensor) -> float:
        if torch.cuda.is_available():
            return torch.cuda.max_memory_reserved() / (1024 ** 2)
        return 0.0


@registry.register('GPU_Utilization')
class GPUUtilization(BaseMetric):
    """GPU 占用率 (%)"""

    def __call__(self, preds: torch.Tensor, targets: torch.Tensor) -> float:
        if not torch.cuda.is_available():
            return 0.0

        pynvml = None
        initialized = False
        try:
            import pynvml as _pynvml
            pynvml = _pynvml
            pynvml.nvmlInit()
            initialized = True
            handle = pynvml.nvmlDeviceGetHandleByIndex(torch.cuda.current_device())
            util = pynvml.nvmlDeviceGetUtilizationRates(handle)
            return float(util.gpu)
        except Exception:
            # pynvml 缺失 / 驱动缺失 / 容器无 GPU 透传
            return 0.0
        finally:
            if initialized and pynvml is not None:
                try:
                    pynvml.nvmlShutdown()
                except Exception:
                    pass


@registry.register('Model_Params')
class ModelParams(BaseMetric):
    """模型参数量 (M)"""

    def __init__(self, model: Optional[torch.nn.Module] = None):
        self.model = model

    def set_model(self, model: torch.nn.Module):
        """设置模型"""
        self.model = model

    def __call__(self, preds: torch.Tensor, targets: torch.Tensor) -> float:
        if self.model is not None:
            params = sum(p.numel() for p in self.model.parameters())
            return params / 1e6  # 转换为 M（百万），参数计数用 10^6 而非 MiB
        return 0.0


@registry.register('Model_Size')
class ModelSize(BaseMetric):
    """模型大小 (MB)"""

    def __init__(self, model: Optional[torch.nn.Module] = None):
        self.model = model

    def set_model(self, model: torch.nn.Module):
        """设置模型"""
        self.model = model

    def __call__(self, preds: torch.Tensor, targets: torch.Tensor) -> float:
        if self.model is not None:
            param_size = sum(p.numel() * p.element_size() for p in self.model.parameters())
            buffer_size = sum(b.numel() * b.element_size() for b in self.model.buffers())
            return (param_size + buffer_size) / (1024 ** 2)
        return 0.0
