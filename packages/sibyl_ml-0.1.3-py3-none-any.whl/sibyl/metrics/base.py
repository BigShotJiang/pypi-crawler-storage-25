"""
指标基类
"""
import torch
from abc import ABC, abstractmethod


class BaseMetric(ABC):
    """指标基类"""

    @abstractmethod
    def __call__(self, preds: torch.Tensor, targets: torch.Tensor) -> float:
        """计算指标
        Args:
            preds: 预测值 [batch_size, seq_len, feature_dim]
            targets: 真实值 [batch_size, seq_len, feature_dim]
        Returns:
            指标值
        """
        pass
