"""TSL-style `type3` learning-rate schedule.

Reference: Time-Series-Library/utils/tools.py::adjust_learning_rate

    if epoch < 3:
        lr = base_lr
    else:
        lr = base_lr * (0.9 ** (epoch - 3))

Keeps the initial learning rate for the first few warm-up epochs, then
decays geometrically. Suitable for long (50+ epoch) training runs where
`type1` (×0.5/epoch) collapses the lr too quickly and Cosine's flat
early region fails to prevent early over-fitting.

Implemented as a subclass of `_LRScheduler` so it is pickle-safe
(unlike a LambdaLR with a closure) — important for checkpoint resume.
"""
from __future__ import annotations

from torch.optim.lr_scheduler import _LRScheduler


class Type3LR(_LRScheduler):
    """Constant lr for `warmup_epochs`, then exponential decay with `gamma`.

    Args:
        optimizer:      wrapped optimizer
        warmup_epochs:  number of epochs to keep base_lr untouched (default 2)
        gamma:          multiplicative decay factor per epoch after warm-up (default 0.9)
        last_epoch:     standard PyTorch scheduler arg (default -1 → start fresh)
    """

    def __init__(self, optimizer, warmup_epochs: int = 2,
                 gamma: float = 0.9, last_epoch: int = -1):
        self.warmup_epochs = warmup_epochs
        self.gamma = gamma
        super().__init__(optimizer, last_epoch)

    def get_lr(self) -> list[float]:
        if self.last_epoch <= self.warmup_epochs:
            return [base_lr for base_lr in self.base_lrs]
        factor = self.gamma ** (self.last_epoch - self.warmup_epochs)
        return [base_lr * factor for base_lr in self.base_lrs]
