"""Custom learning-rate schedulers."""
from .type3 import Type3LR

__all__ = ["Type3LR"]
