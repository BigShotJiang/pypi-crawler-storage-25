"""Sibyl 统一启动入口。

单个 `main.py` 管所有实验类型；具体由 `cfg.launcher` 选择 Launcher 类。
每个 Launcher 封装自己的 lifecycle（build/run/resume/automl 分支）。

用法：
    python main.py experiment=dam_forecast              # 时序（默认 launcher=forecast）
    python main.py experiment=spike                     # 基因表达（实验 override 到 gene_expr）
    python main.py launcher=gene_expr model.active_marks='[ATAC]'
    python main.py mode=auto                            # 仅 forecast 支持
    python main.py mode=test checkpoint_path=...
"""
import csv
import logging
import os
import sys

import hydra
from hydra.core.hydra_config import HydraConfig
from omegaconf import DictConfig

logger = logging.getLogger(__name__)

PROJECT_ROOT = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, PROJECT_ROOT)

os.environ.setdefault("PROJECT_ROOT", PROJECT_ROOT)


def _save_hparams_report(cfg: DictConfig, best_val_loss: float):
    """Optuna sweep 模式在 sweep 根目录追加超参 + 指标记录。"""
    hc = HydraConfig.get()
    sweep_dir = os.path.join(hc.runtime.cwd, hc.sweep.dir)
    os.makedirs(sweep_dir, exist_ok=True)
    report_path = os.path.join(sweep_dir, "hparams_report.csv")

    hparams = {"trial": hc.job.num, "best_val_loss": f"{best_val_loss:.6f}"}
    for k, v in cfg.model.items():
        hparams[f"model.{k}"] = v
    hparams["optimizer.lr"] = cfg.optimizer.get("lr", "")
    hparams["epochs"] = cfg.training.epochs

    existing_fields = []
    if os.path.exists(report_path):
        with open(report_path, "r") as f:
            reader = csv.DictReader(f)
            existing_fields = reader.fieldnames or []
    all_fields = list(existing_fields)
    for k in hparams.keys():
        if k not in all_fields:
            all_fields.append(k)

    rows = []
    if os.path.exists(report_path):
        with open(report_path, "r") as f:
            rows = list(csv.DictReader(f))
    rows.append({k: str(v) for k, v in hparams.items()})

    with open(report_path, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=all_fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)
    logger.info(f"Hparams report updated: {report_path}")


def _setup_seed(cfg: DictConfig):
    seed = cfg.get("training", {}).get("seed", None)
    if seed is not None:
        from sibyl.utils import set_random_seed
        set_random_seed(seed)


@hydra.main(config_path="configs", config_name="config", version_base="1.3")
def main(cfg: DictConfig):
    if "launcher" not in cfg:
        raise ValueError(
            "cfg 缺少 launcher 字段。在 configs/config.yaml 或 experiment yaml 里指定 "
            "`launcher: forecast | gene_expr | ...`")

    # 种子 + CUDA 设备
    os.environ.setdefault("CUDA_VISIBLE_DEVICES", str(cfg.get("gpu", 0)))
    _setup_seed(cfg)

    # Launcher 工厂 — 由 cfg.launcher._target_ 决定具体类。
    # 不用 hydra.utils.instantiate：它内部会对整个 cfg 做 OmegaConf.resolve，
    # 会踩到 ${hydra.runtime.output_dir} / ${hydra.job.num} 这类 runtime-only 插值。
    launcher_cls = hydra.utils.get_class(cfg.launcher._target_)
    launcher = launcher_cls(cfg)
    best_val_loss = launcher.run()

    # Optuna multirun 模式的超参汇总
    if HydraConfig.initialized() and HydraConfig.get().mode.name == "MULTIRUN":
        _save_hparams_report(cfg, best_val_loss)

    return best_val_loss if best_val_loss is not None else 0.0


if __name__ == "__main__":
    main()
