# Research: weekly_pr_metrics Implementation Patterns
**Date**: 2026-04-26
**Scope**: Pre-implementation investigation for `weekly_pr_metrics` table

---

## 1. pull_request_cache Schema

**File**: `src/gitflow_analytics/models/database_metrics_models.py`
**Class**: `PullRequestCache` (line 20)
**SQLAlchemy table**: `pull_request_cache`

### Full column set (versioned):

| Column | Type | Notes |
|---|---|---|
| `id` | Integer PK | |
| `repo_path` | String NOT NULL | e.g. `"owner/repo"` |
| `pr_number` | Integer NOT NULL | |
| `title` | String | |
| `description` | String | |
| `author` | String | GitHub login (lowercased by convention) |
| `created_at` | DateTime(tz) | |
| `merged_at` | DateTime(tz) nullable | |
| `story_points` | Integer nullable | |
| `labels` | JSON | List[str] |
| `commit_hashes` | JSON | List[str] |
| `pr_state` | String nullable | `"open"/"closed"/"merged"` (v4.0) |
| `closed_at` | DateTime(tz) nullable | (v4.0) |
| `is_merged` | Boolean nullable | (v4.0) |
| `review_comments_count` | Integer default 0 | Inline code comments (v3.0) |
| `pr_comments_count` | Integer default 0 | General PR/issue comments (v3.0) |
| `approvals_count` | Integer default 0 | (v3.0) |
| `change_requests_count` | Integer default 0 | (v3.0) |
| `reviewers` | JSON nullable | List[str] all reviewer logins (v3.0) |
| `approved_by` | JSON nullable | List[str] approving reviewer logins (v3.0) |
| `time_to_first_review_hours` | Float nullable | (v3.0) |
| `revision_count` | Integer default 0 | (v3.0) |
| `changed_files` | Integer default 0 | (v3.0) |
| `additions` | Integer default 0 | (v3.0) |
| `deletions` | Integer default 0 | (v3.0) |
| `cached_at` | DateTime(tz) | auto-set |

Unique index: `idx_repo_pr` on `(repo_path, pr_number)`.

### Key columns for weekly_pr_metrics aggregation:
- **prs_opened**: count rows where `author == engineer` and `created_at` falls in week
- **prs_merged**: count rows where `author == engineer` and `merged_at` falls in week
- **pr_comments_given**: sum `pr_comments_count` where engineer appears in (to be determined — see identity note below)
- **pr_reviews_given**: derive from `reviewers` JSON list — count PRs where engineer login appears in `reviewers`

---

## 2. engineer_pr_metrics_gfa Aggregation

**This table/view does not yet exist** — the grep returned zero hits across the entire `src/` tree.

The closest existing PR aggregation is in:

### `src/gitflow_analytics/reports/velocity_report.py`
**Class**: `VelocityReportGenerator`

- `_by_developer()` (line 169): groups merged PRs by `pr.get("author")`, computes `prs_merged`, cycle times, revision counts per author.
- `_by_week()` (line 177): groups by ISO `week_start(merged_at)`, same aggregations.
- Neither method stores results to DB — it writes `velocity_summary.json` to the output dir.

### `src/gitflow_analytics/core/cache.py`
- `_pr_to_dict()` (line 620): canonical converter from `PullRequestCache` ORM row → dict. This is the source shape for all downstream aggregation. Key fields returned: `author`, `reviewers` (list), `approved_by` (list), `pr_comments_count`, `review_comments`.

### Loading PRs from cache:
**`src/gitflow_analytics/core/cache_commits.py`**
- `get_cached_prs_for_report()` (line 272): queries `pull_request_cache` filtered by `repo_path IN (...)` and `created_at` range. Returns list of `_pr_to_dict()` dicts.

---

## 3. Existing Weekly Stat Collection Patterns

There is **no `--week` or `--since` flag** in the current CLI. The weekly granularity is expressed as `--weeks N` (integer count of trailing weeks). The single specific-week pattern to follow is in the pipeline stages.

### Week boundary calculation
**`src/gitflow_analytics/utils/date_utils.py`**

```python
# line 10
def get_week_start(date: datetime) -> datetime:
    """Monday 00:00:00 UTC of the week containing date."""

# line 47
def get_week_end(date: datetime) -> datetime:
    """Sunday 23:59:59.999999 UTC of the week containing date."""
```

Both are imported across: `cli_fetch.py`, `pipeline_collect.py`, `pipeline_classify.py`, `pipeline_report.py`, `cli_training.py`, `cli_identity_commands.py`, `core/analyze_pipeline.py`.

### Canonical usage pattern (repeated in every pipeline stage):
```python
# e.g. pipeline_collect.py lines 51-52
current_week_start = get_week_start(current_time)
last_complete_week_start = current_week_start - timedelta(weeks=1)
```

### Week-granularity incremental tracking
**`src/gitflow_analytics/core/cache_weekly.py`** — `WeeklyCacheMixin`

- `calculate_weeks(start_date, end_date)` (line 31): returns list of Monday-aligned `(week_start, week_end)` tuples.
- `get_cached_weeks(repo_path)` (line 70): returns already-fetched weeks from `weekly_fetch_status` table.
- `get_missing_weeks(repo_path, required_weeks)` (line 96): diff of required vs cached; the core of the incremental fetch gate.
- `mark_week_fetched(repo_path, week_start, week_end, commit_count)` (line 139): upserts a `WeeklyFetchStatus` row.

### New command should follow:
For `--week YYYY-WNN` (single ISO week): parse to a `(week_start, week_end)` pair using `get_week_start()`.
For `--since YYYY-MM-DD`: use `calculate_weeks(since_date, now)` to enumerate weeks.
Default (no flags): current week = `get_week_start(datetime.now(utc))`.

---

## 4. CLI Patterns

### Entry points (`pyproject.toml`):
```toml
[project.scripts]
gitflow-analytics = "gitflow_analytics.cli:main"
gfa = "gitflow_analytics.cli:main"
```

### CLI root: `src/gitflow_analytics/cli.py`
- Uses Click with a custom `AnalyzeAsDefaultGroup` (line 13).
- Commands registered via `register_*_commands(cli)` pattern (lines 106-119).

### Command registration pattern:
```python
# cli_analysis.py line 16
def register_analysis_commands(cli: click.Group) -> None:
    cli.add_command(fetch, name="fetch")
    cli.add_command(collect_command, name="collect")
    ...
```

Each concrete command lives in its own module (e.g. `cli_fetch.py`, `cli_pipeline_commands.py`), then imported and registered in a `register_*_commands()` function, which is called from `cli.py`.

### Adding a new subcommand — required steps:
1. Create `src/gitflow_analytics/cli_pr_metrics.py` with a `@click.command(name="pr-metrics")` function.
2. Create a `register_pr_metrics_commands(cli)` function in that file.
3. Import and call `register_pr_metrics_commands(cli)` in `cli.py` alongside the existing registrations.

### Option style for the new command (matching existing conventions):
```python
@click.option("--config", "-c", type=click.Path(exists=True, path_type=Path), required=True)
@click.option("--weeks", "-w", type=int, default=1, show_default=True, help="Number of weeks")
@click.option("--week", type=str, default=None, help="Specific ISO week, e.g. 2026-W17")
@click.option("--since", type=click.DateTime(formats=["%Y-%m-%d"]), default=None)
@click.option("--log", type=click.Choice(["none", "INFO", "DEBUG"]), default="none")
```

---

## 5. Database Initialization and DDL Location

### How tables are created:
**`src/gitflow_analytics/models/database.py`**
- `Database.init_db()` (line 368):
  ```python
  def init_db(self) -> None:
      needs_migration = self._check_schema_version_before_create()
      Base.metadata.create_all(self.engine)   # <-- all SQLAlchemy models auto-created
      if needs_migration:
          self._perform_schema_migration()
      else:
          self._ensure_schema_version_recorded()
      self._apply_migrations()
  ```
- `Base.metadata.create_all(self.engine)` creates every table whose model class imports from `database_base.Base`.

### Schema migration approach:
- `CURRENT_SCHEMA_VERSION = "2.0"` (line 87 of `database.py`)
- Additive columns use ALTER TABLE inside numbered `_migrate_*` methods (v3–v10 so far), each called from `_apply_migrations()` (line ~510+).
- Each migration method is idempotent: reads `PRAGMA table_info(table_name)`, adds column only if absent.

### Where to add weekly_pr_metrics DDL:
1. **Add new SQLAlchemy model** in `src/gitflow_analytics/models/database_commit_models.py` (alongside `WeeklyTrends`, `WeeklyFetchStatus`). The model's `__tablename__ = "weekly_pr_metrics"` will be picked up by `create_all`.
2. **No ALTER TABLE migration needed** for first creation on new/existing DBs — `create_all` is non-destructive (skips existing tables). If adding to an existing DB that was created before this model existed, `create_all` will create the table on next `init_db()` call.
3. If you later add columns to the table, add a `_migrate_weekly_pr_metrics_v2(conn)` method and call it from `_apply_migrations()`.

### Recommended model location:
`src/gitflow_analytics/models/database_commit_models.py` — add after `WeeklyFetchStatus` (line ~478).

---

## 6. Identity Resolution — engineer_identifier

### Identity system overview:
Identity resolution is handled by `DeveloperIdentityResolver` in `identities.db` (separate SQLite file alongside the main cache DB).

- Referenced as: `cfg.cache.directory / "identities.db"` (e.g. `pipeline_report.py` line 136)
- `developer_id` in `WeeklyTrends` / `DailyMetrics` is the **canonical ID** — typically the developer's primary email address from Git commits.

### In pull_request_cache:
- `author` column stores the **GitHub login** (string, e.g. `"bobmatnyc"`), NOT an email address.
- This creates an identity mismatch between commit-based developer_id (email) and PR-based author (GitHub login).

### How the gap is bridged:
**`src/gitflow_analytics/pipeline_report.py`** (line 167):
```python
updated = gh_sync.sync(identity_resolver)
```
A GitHub identity sync step resolves GitHub logins to canonical email-based IDs in `identities.db`. Commit in the project description states: "resolve GitHub Issues actor emails via identities.db at ingestion" (see git log `467d519`).

### For weekly_pr_metrics, `engineer_identifier` should be:
- **The GitHub login string** stored in `pull_request_cache.author` — this is the most reliable key for aggregating PR-side data (opened, merged, reviews given).
- Optionally join to `identities.db` to produce a canonical developer_id for cross-referencing commit metrics, but this requires the GitHub sync to have run.
- Recommendation: use `author` (GitHub login) as the primary key in `weekly_pr_metrics`, and add a nullable `canonical_developer_id` column that can be back-filled after identity sync.

### Reviewer attribution:
For `pr_reviews_given`:
- `reviewers` JSON list in `pull_request_cache` contains GitHub login strings of all reviewers.
- `approved_by` JSON list contains logins of approvers specifically.
- To compute "reviews given by engineer X in week W": scan all PRs merged/active in week W, check if `X` appears in `pr["reviewers"]`.

### For pr_comments_given:
- `pr_comments_count` on a `PullRequestCache` row is the **total** comment count on that PR — it does NOT track per-reviewer comment counts.
- To accurately count comments given by a reviewer, you would need raw comment-level data, which is not currently stored. The `pr_comments_count` column reflects comments on PRs the author opened, not comments given by a reviewer.
- Pragmatic approach: `pr_comments_given` can be approximated as the number of PRs where the engineer appears as a reviewer (proxy), or left as NULL until per-comment data is fetched.

---

## Implementation Checklist

Based on all findings above, here is the complete implementation plan:

### Files to create:
- `src/gitflow_analytics/cli_pr_metrics.py` — Click command with `--week`, `--since`, default current-week logic

### Files to modify:
1. `src/gitflow_analytics/models/database_commit_models.py` — Add `WeeklyPRMetrics` SQLAlchemy model
2. `src/gitflow_analytics/cli.py` — Import and call `register_pr_metrics_commands(cli)`
3. `src/gitflow_analytics/cli_analysis.py` — Optionally add to `register_analysis_commands()`

### Upsert pattern to use:
Follow `MetricsStorage.store_daily_metrics()` pattern in `core/metrics_storage.py` (lines 111-220):
```python
existing = session.query(WeeklyPRMetrics).filter(
    and_(
        WeeklyPRMetrics.week_start == week_start,
        WeeklyPRMetrics.engineer_identifier == engineer,
    )
).first()
if existing:
    # update fields
else:
    session.add(WeeklyPRMetrics(...))
session.commit()
```

### Proposed schema for weekly_pr_metrics:
```python
class WeeklyPRMetrics(Base):
    __tablename__ = "weekly_pr_metrics"
    id = Column(Integer, primary_key=True)
    week_start = Column(DateTime(timezone=True), nullable=False)  # Monday 00:00:00 UTC
    week_end = Column(DateTime(timezone=True), nullable=False)    # Sunday 23:59:59 UTC
    engineer_identifier = Column(String, nullable=False)          # GitHub login
    canonical_developer_id = Column(String, nullable=True)        # email from identities.db

    prs_opened = Column(Integer, default=0)
    prs_merged = Column(Integer, default=0)
    pr_comments_given = Column(Integer, default=0)   # approximation (see note above)
    pr_reviews_given = Column(Integer, default=0)    # PRs where engineer is in reviewers

    calculated_at = Column(DateTime(timezone=True), default=utcnow_tz_aware)

    __table_args__ = (
        Index("idx_wpm_week_engineer", "week_start", "engineer_identifier", unique=True),
        Index("idx_wpm_engineer", "engineer_identifier"),
        Index("idx_wpm_week_start", "week_start"),
    )
```

### Week parsing for --week flag:
```python
# Parse "2026-W17" -> (week_start, week_end)
from datetime import datetime, timedelta
import re

def parse_iso_week(week_str: str):
    m = re.match(r"(\d{4})-W(\d{1,2})$", week_str)
    year, week = int(m.group(1)), int(m.group(2))
    # ISO week 1 of year starts on the Monday of the week containing Jan 4
    jan4 = datetime(year, 1, 4, tzinfo=timezone.utc)
    week_start = get_week_start(jan4) + timedelta(weeks=week - 1)
    week_end = get_week_end(week_start)
    return week_start, week_end
```
