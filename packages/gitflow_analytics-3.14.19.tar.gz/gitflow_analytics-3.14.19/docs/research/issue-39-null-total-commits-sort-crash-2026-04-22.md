# Issue #39: NULL total_commits Causes Sort Crash in Identity Resolution

**Date**: 2026-04-22
**Issue**: GitHub #39 — NULL total_commits for a developer causes sort crash in identity resolution
**Scope**: `core/identity_stats.py`, `core/identity.py`, `reports/csv_reports_weekly.py`

---

## Root Cause Summary

`DeveloperIdentity.total_commits` is declared with `default=0` in the SQLAlchemy model but is
**not** declared `nullable=False`. In SQLite (and in SQLAlchemy's ORM), the `default` is an
application-side default applied only at INSERT time via the ORM. Any row created by a raw SQL
migration, a direct DB write, or an older schema version that lacked this column may legitimately
carry `NULL` in that column. When `get_developer_stats()` returns those rows the sort key
`lambda x: x["total_commits"]` receives `None`, which is not comparable to `int` in Python 3 and
raises a `TypeError: '<' not supported between instances of 'NoneType' and 'int'`.

There is also a secondary crash in `merge_identities()` that hits the same underlying problem with
`first_seen` / `last_seen` being `None`, plus a tertiary crash site in `csv_reports_weekly.py`.

---

## Crash Sites

### 1. PRIMARY — `src/gitflow_analytics/core/identity_stats.py` lines 60 and 94

```python
# line 60  (in-memory fallback branch of get_developer_stats)
return sorted(stats, key=lambda x: x["total_commits"], reverse=True)

# line 94  (database branch of get_developer_stats)
return sorted(stats, key=lambda x: x["total_commits"], reverse=True)
```

`identity.total_commits` read from SQLite can be `None` for rows that pre-date the ORM default or
were inserted without going through the ORM. The sort key then compares `None` with `int`, which
raises `TypeError`.

**Which field**: `DeveloperIdentity.total_commits` (the column in `developer_identities` table)
**Which model**: `DeveloperIdentity` in `src/gitflow_analytics/models/database_identity_models.py`
  line 28: `total_commits = Column(Integer, default=0)` — `nullable=True` (omitted == nullable).

### 2. SECONDARY — `src/gitflow_analytics/core/identity.py` lines 694–697

```python
# merge_identities()
identity1.total_commits += identity2.total_commits          # line 694 — TypeError if None
identity1.first_seen = min(identity1.first_seen, identity2.first_seen)  # line 696 — TypeError if None
identity1.last_seen  = max(identity1.last_seen,  identity2.last_seen)   # line 697 — TypeError if None
```

If either identity has `total_commits`, `first_seen`, or `last_seen` set to `NULL` in the database,
Python's `+=`, `min()`, and `max()` all fail with `TypeError`.

### 3. TERTIARY — `src/gitflow_analytics/reports/csv_reports_weekly.py` lines 250 and 517

```python
# line 250
top_contributor = max(developer_stats, key=lambda x: x["total_commits"])

# line 517
rows.sort(key=lambda x: x["total_commits"], reverse=True)
```

Both receive the list returned by `get_developer_stats()`. If that list already contains `None`
values (fixed by fix #1 below), these are safe; if `get_developer_stats()` is ever bypassed and
rows are constructed directly from ORM objects, these lines would also crash.

---

## Model Schema

**File**: `src/gitflow_analytics/models/database_identity_models.py`

```python
class DeveloperIdentity(Base):
    __tablename__ = "developer_identities"
    ...
    total_commits       = Column(Integer, default=0)      # line 28 — nullable (no nullable=False)
    total_story_points  = Column(Integer, default=0)      # line 29 — nullable
    first_seen          = Column(DateTime(timezone=True), default=utcnow_tz_aware)  # line 30 — nullable
    last_seen           = Column(DateTime(timezone=True), default=utcnow_tz_aware)  # line 31 — nullable
```

`default=0` only fires at ORM INSERT; it does NOT add a `DEFAULT 0` constraint in the DDL unless
`server_default` is used.  SQLite therefore stores `NULL` in rows inserted outside the ORM.

---

## Minimal Fix

### Fix 1 — `identity_stats.py` (PRIMARY, both sort calls)

```python
# line 60
return sorted(stats, key=lambda x: x["total_commits"] or 0, reverse=True)

# line 94
return sorted(stats, key=lambda x: x["total_commits"] or 0, reverse=True)
```

Alternatively, normalise the value when building the dict (line 84):

```python
"total_commits": identity.total_commits or 0,
```

This is the cleaner approach — it normalises the value at the source so all downstream consumers
(including `csv_reports_weekly.py`) are also protected.

### Fix 2 — `identity.py` `merge_identities()` (SECONDARY)

```python
# line 694
identity1.total_commits = (identity1.total_commits or 0) + (identity2.total_commits or 0)

# line 695
identity1.total_story_points = (identity1.total_story_points or 0) + (identity2.total_story_points or 0)

# lines 696–697 — guard against None datetimes
now = datetime.now(timezone.utc)
first1 = identity1.first_seen or now
first2 = identity2.first_seen or now
last1  = identity1.last_seen  or now
last2  = identity2.last_seen  or now
identity1.first_seen = min(first1, first2)
identity1.last_seen  = max(last1, last2)
```

### Fix 3 — Schema hardening (prevents future occurrences)

In `database_identity_models.py`, add `nullable=False` and `server_default`:

```python
total_commits      = Column(Integer, nullable=False, default=0, server_default="0")
total_story_points = Column(Integer, nullable=False, default=0, server_default="0")
```

And add a migration in `database.py` to back-fill existing NULLs:

```sql
UPDATE developer_identities SET total_commits = 0      WHERE total_commits IS NULL;
UPDATE developer_identities SET total_story_points = 0 WHERE total_story_points IS NULL;
```

---

## Existing Test Coverage

### Tests that exercise the sort path

- `tests/core/test_identity.py` — `test_get_developer_stats` (line 130), `test_merge_identities`
  (line 135), and numerous co-author commit tests all call `get_developer_stats()` but always
  provide commits so `total_commits` is set before the sort runs.

**Gap**: No test inserts a `DeveloperIdentity` row with `total_commits = None` (or bypasses the ORM
to leave it NULL) and then calls `get_developer_stats()`. The crash therefore does not reproduce in
the test suite even though it occurs in production with migrated databases.

### Tests that exercise merge_identities

- `tests/core/test_identity.py::test_merge_identities` (line 135) — resolves two real developers
  through commits so `first_seen`, `last_seen`, and `total_commits` are all non-NULL. No coverage
  of the NULL-identity edge case.

---

## Recommended New Tests

1. **`test_get_developer_stats_with_null_total_commits`** — insert a `DeveloperIdentity` row
   directly via SQL (bypassing the ORM default) with `total_commits = NULL`, call
   `get_developer_stats()`, and assert it does not raise and returns `0` for that developer.

2. **`test_merge_identities_with_null_timestamps`** — create two identities where one or both have
   `first_seen = None` / `last_seen = None` / `total_commits = None`, call `merge_identities()`,
   and assert it completes without error.

---

## Affected Files

| File | Lines | Severity |
|---|---|---|
| `src/gitflow_analytics/core/identity_stats.py` | 60, 84, 94 | CRASH (primary) |
| `src/gitflow_analytics/core/identity.py` | 694–697 | CRASH (secondary) |
| `src/gitflow_analytics/models/database_identity_models.py` | 28–31 | Schema root cause |
| `src/gitflow_analytics/reports/csv_reports_weekly.py` | 250, 517 | Protected by fix 1 |
