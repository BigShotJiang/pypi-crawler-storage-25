# Issue #45 — Auto-population Strategies for `github_username` in `developer_identities`

**Date**: 2026-04-22
**Researcher**: Research Agent
**Scope**: Implementation pre-research for two sync strategies

---

## 1. Config Classes — Exact Fields and Types

### `GitHubConfig` (`src/gitflow_analytics/config/schema.py`, lines 28–48)

```python
@dataclass
class GitHubConfig:
    token: Optional[str] = None
    owner: Optional[str] = None
    organization: Optional[str] = None   # <-- the trigger field for Strategy 1
    base_url: str = "https://api.github.com"
    max_retries: int = 3
    backoff_factor: int = 2
    fetch_pr_reviews: bool = False
```

The `organization` field is **already present** and is used elsewhere (e.g., `Config.discover_organization_repositories()`) to call `github.get_organization(self.github.organization)`. Strategy 1 can reuse this field directly — no schema change is needed.

### `ConfluenceConfig` (`src/gitflow_analytics/config/schema.py`, lines 513–530)

```python
@dataclass
class ConfluenceConfig:
    enabled: bool = False
    base_url: str = ""           # e.g. "https://company.atlassian.net/wiki"
    username: str = ""           # Atlassian account email
    api_token: str = ""          # Atlassian API token
    spaces: list[str] = ...
    fetch_page_history: bool = False
    dns_timeout: int = 10
    connection_timeout: int = 30
    max_retries: int = 3
    backoff_factor: float = 1.0
```

No `organization` or `cloud_id` field. The Atlassian user-resolution API (`/scim/directory/{directory_id}/Users` or `/rest/api/3/user?accountId=...`) will need to be called against the domain derived from `base_url`. No schema change is needed for the basic implementation — the `base_url`, `username`, and `api_token` are sufficient.

---

## 2. Orchestrator — Integration Initialization and Hook Points

**File**: `src/gitflow_analytics/integrations/orchestrator.py`

### Key architectural facts

- `IntegrationOrchestrator.__init__(config, cache)` initialises all integrations. Each integration is gated by a config check, constructed, and stored in `self.integrations: dict[str, ...]`.
- The one public entry-point that runs per-repo is `enrich_repository_data(repo_config, commits, since)`. It calls `fetch_all_spaces(since)` for Confluence and `fetch_issues_activity(repos, since)` for GitHub Issues, both guarded by a `_*_fetched` flag so they only fire once per analysis run.
- There is no `run()` method on the orchestrator itself. The pipeline orchestrates via `pipeline_report.py::run_report()`.

### Best place to add a post-init sync step

**Option A (recommended): End of `IntegrationOrchestrator.__init__`**

After all integrations are constructed and credential-verified, add a call to a new `_sync_github_usernames()` method (or call it from the constructor of a new `UsernameSync` helper). This mirrors how `confluence_integration.verify_credentials()` is called immediately after construction (lines 159–166 of orchestrator.py). The resolver instance is not available at orchestrator init-time, so the sync would need to accept or construct a `DeveloperIdentityResolver`.

**Option B: In `pipeline_report.py::run_report()`, after line 144 (`identity_resolver.update_commit_stats(all_commits)`)**

The `identity_resolver` is already constructed here and all integrations are available via the `cache`. This location has the full context needed and is the natural place for a post-commit-load enrichment pass. The downside is that `run_report` is a report-stage function, not a data-collection stage function.

**Option C: A standalone `sync` module called from `run_report` or the CLI**

Cleaner separation of concerns; the sync helpers become testable in isolation.

**Verdict**: Option B (inline in `run_report`) for the initial implementation, with Option C as the target architecture once both strategies are stable. The sync needs `identity_resolver` (for `_set_github_username_if_missing` and email lookups), the GitHub/Confluence HTTP sessions (for API calls), and the config (for `organization` field and Confluence credentials).

---

## 3. GitHub Issues Integration — HTTP Session Pattern

**File**: `src/gitflow_analytics/integrations/github_issues_integration.py`

### Session construction

```python
self._session = self._build_session()   # called in __init__

def _build_session(self) -> requests.Session:
    session = requests.Session()
    retry_strategy = Retry(
        total=self.rate_limit_retries,
        backoff_factor=self.backoff_factor,
        status_forcelist=[429, 500, 502, 503, 504],
        allowed_methods=["HEAD", "GET", "OPTIONS"],
        raise_on_status=False,
    )
    adapter = HTTPAdapter(max_retries=retry_strategy)
    session.mount("http://", adapter)
    session.mount("https://", adapter)
    session.headers.update({
        "Authorization": f"token {self.token}",
        "Accept": "application/vnd.github+json",
        "User-Agent": "GitFlow-Analytics-GitHubIssues/1.0",
        "X-GitHub-Api-Version": "2022-11-28",
    })
    return session
```

### Auth pattern

Bearer token: `Authorization: token {self.token}` — the token is stored on `self.token` and is the same one used by `GitHubIntegration`.

### Retry helper

`_get_with_retries(url, params)` — manual retry loop on top of the `Retry` adapter, catching 403/429 with exponential backoff. Returns `requests.Response | None`.

### Existing API query methods

No method that queries `/orgs/{org}/members` yet. The class only queries `/repos/{owner}/{repo}/issues` and `/repos/{owner}/{repo}/issues/{number}/comments`.

**Reuse plan for Strategy 1**: The `GitHubIssuesIntegration._session` (or equivalently the `GitHubIntegration._session`) and `_get_with_retries` can be directly reused/copied for a call to `GET /orgs/{organization}/members`. The GitHub org-members endpoint returns `[{login, email (often null), ...}]`. A separate user-detail call `GET /users/{login}` is needed to get the public email, but for email-matching purposes, the user search API `GET /search/users?q={email}+in:email` is more reliable.

---

## 4. Confluence Integration — HTTP Session Pattern

**File**: `src/gitflow_analytics/integrations/confluence_integration.py`

### Session construction

```python
credentials = base64.b64encode(f"{username}:{api_token}".encode()).decode()
self.headers = {
    "Authorization": f"Basic {credentials}",
    "Accept": "application/json",
    "User-Agent": "GitFlow-Analytics-Confluence/1.0",
}
self._session = self._build_session()  # mounts HTTPAdapter with Retry

def _build_session(self) -> requests.Session:
    # identical pattern to GitHubIssuesIntegration._build_session
    # status_forcelist=[429, 500, 502, 503, 504]
    # session.headers.update(self.headers)  <-- auth already in headers
```

### Auth pattern

HTTP Basic: `base64(username:api_token)` — standard Atlassian REST API auth.

### Retry helper

`_get_with_retries(url, params)` — **already exists**, same signature as the GitHub one. Returns `requests.Response | None`.

### base_url

`self.base_url` is the Confluence wiki root (e.g. `https://company.atlassian.net/wiki`). For the user-resolution API, the Jira/Atlassian Cloud API lives at the parent domain (`https://company.atlassian.net`), not under `/wiki`. The domain can be derived as `base_url.replace("/wiki", "")` or by stripping the `/wiki` suffix.

**Reuse plan for Strategy 2**: Call `GET {atlassian_base}/rest/api/3/user?accountId={uuid}` using the existing session. This Atlassian API returns `{accountId, displayName, emailAddress, ...}`. The `emailAddress` field is what we need to join to `developer_identities.primary_email`.

---

## 5. Identity Resolver — Available Methods

**File**: `src/gitflow_analytics/core/identity.py`

### Relevant public/semi-public methods

| Method | Signature | Purpose |
|---|---|---|
| `resolve_developer` | `(name: str, email: str, github_username: Optional[str]) -> str` | Find-or-create; returns `canonical_id` |
| `resolve_by_github_username` | `(github_username: str) -> Optional[str]` | Lookup by GitHub login; returns `canonical_id` or None |
| `_set_github_username_if_missing` | `(canonical_id: str, github_username: str) -> None` | Write `github_username` to DB row **only if currently NULL** |
| `merge_identities` | `(canonical_id1: str, canonical_id2: str)` | Merge two identities |

### "Find by email" — does it exist?

There is **no dedicated `find_by_email(email)` method**. The closest approximation is the lookup inside `resolve_developer`:

```python
# Check aliases
alias = session.query(DeveloperAlias).filter(DeveloperAlias.email == email).first()
# Check primary identities
identity = session.query(DeveloperIdentity).filter(DeveloperIdentity.primary_email == email).first()
```

A "find by email" helper does not exist as a public method. Strategy 2 will need to either:

1. Call `resolve_developer(display_name, email)` with the display name from the Atlassian API response — this will create a new identity if none exists, which is probably not wanted for a lookup-only sync, **or**
2. Do the email query directly via `identity_resolver.get_session()` in the sync helper.

**Recommendation**: Add a `find_canonical_id_by_email(email: str) -> Optional[str]` method to `DeveloperIdentityResolver` that checks aliases then primary identities and returns the `canonical_id` without side effects. This also makes the code path for both strategies uniform.

### `_set_github_username_if_missing` — full behavior (line 645)

- Guards: returns early if `github_username` is falsy OR if not `_database_available`.
- Normalises to lowercase.
- Writes the column only when `identity.github_username` is currently NULL or empty — **never overwrites an existing value**.
- Updates the in-memory `_cache` entry immediately so downstream lookups see the new value without a full reload.
- This is the correct mutation method for both strategies.

---

## 6. `ticketing_activity_cache` — Actor Column Analysis

**File**: `src/gitflow_analytics/models/database_metrics_models.py`, lines 467–518

### Relevant columns of `TicketingActivityCache`

```
platform          String   -- 'github_issues' | 'confluence'
item_id           String   -- issue number or Confluence page_id
actor             String   -- lowercased GitHub login OR Atlassian accountId/username
actor_display_name String  -- display name (may be available)
actor_email       String   -- email (almost always NULL for Confluence)
```

### What is stored in `actor` for Confluence rows?

From `confluence_integration.py` line 266–267:

```python
author = (created_by.get("username") or created_by.get("accountId") or "").lower()
editor = (last_editor.get("username") or last_editor.get("accountId") or "").lower()
```

The code uses `username` first, falling back to `accountId`. For **Confluence Cloud** (the only variant Atlassian actively supports), the `username` field was **removed from REST API responses** in 2019 when Atlassian deprecated username-based auth in favor of account UUIDs. On a Cloud instance, `created_by.get("username")` will be `None` or absent, so `actor` will be the **Atlassian account UUID** — the format `712020:d2d0c7b6-...` (type-prefix + UUID v4).

On **Confluence Data Center / Server** (self-hosted), `username` is still present and will be the short username string.

**Conclusion**: For Confluence Cloud (the common case), `actor` in `ticketing_activity_cache` rows with `platform='confluence'` is an Atlassian account UUID. The `actor_email` column will be NULL because the page history API does not return email addresses — email must be resolved via a secondary `GET /rest/api/3/user?accountId={uuid}` call.

**Note**: `actor_display_name` stores the `displayName` / `publicName` from the API, which is a human-readable name but not guaranteed to match `developer_identities.primary_name`.

---

## 7. Answers to Specific Investigation Questions

### Q: Does `GitHubConfig` have an `organization` field?

**Yes.** `organization: Optional[str] = None` at line 33 of `schema.py`. Already present, no schema change needed.

### Q: What fields does `ConfluenceConfig` have?

`enabled`, `base_url`, `username`, `api_token`, `spaces`, `fetch_page_history`, `dns_timeout`, `connection_timeout`, `max_retries`, `backoff_factor`. No `cloud_id` or `organization`. The base domain for the Atlassian user API can be extracted from `base_url` by stripping the `/wiki` path component.

### Q: Best place to insert the sync step?

`pipeline_report.py::run_report()`, after `identity_resolver.update_commit_stats(all_commits)` (line 144). The `identity_resolver`, `cache`, and `cfg` are all in scope. Wrap in `try/except` so a failed sync never blocks report generation.

### Q: What identity methods are available for "find by email" and "set github_username"?

- **Set**: `_set_github_username_if_missing(canonical_id, github_username)` — exists, correct semantics.
- **Find by email**: No public method. **Need to add** `find_canonical_id_by_email(email: str) -> Optional[str]` that queries aliases then primary identities.

### Q: Are Confluence actors account UUIDs or display names?

For **Confluence Cloud**: `actor` is the **Atlassian account UUID** (e.g. `712020:d2d0c7b6-...`). Display names are in `actor_display_name`. Emails must be fetched via the Atlassian REST API.

---

## 8. Implementation Design

### Strategy 1 — GitHub Org Member Sync

**API call sequence**:
1. `GET https://api.github.com/orgs/{organization}/members?per_page=100` — paginate to get all member logins.
2. For each member, `GET https://api.github.com/users/{login}` to get their `email` field (may be null if user hasn't made email public).
3. Alternatively, use `GET https://api.github.com/search/users?q={email}+in:email` to find a login given an email from `developer_identities`.

**Preferred direction** (avoids N+1 user API calls for public emails): Iterate `developer_identities` rows that have a non-null `primary_email` and `NULL github_username`. For each, call the search API. This is more API-call-efficient for sparse matches.

**Alternative direction** (complete sync): Paginate org members, fetch each member's email, match against `developer_identities.primary_email` and `developer_aliases.email`. Set `github_username` on match.

**HTTP session**: Reuse `GitHubIssuesIntegration._build_session()` pattern verbatim (same token, same headers, same retry strategy).

### Strategy 2 — Atlassian Account UUID Resolution

**API call sequence**:
1. Query `ticketing_activity_cache` for distinct `actor` values where `platform='confluence'` and `actor` matches UUID pattern (`%:%-%`).
2. For each UUID, call `GET {atlassian_base}/rest/api/3/user?accountId={uuid}` — returns `{accountId, displayName, emailAddress}`.
3. Match `emailAddress` against `developer_identities.primary_email` and `developer_aliases.email`.
4. Call `_set_github_username_if_missing(canonical_id, login)` — but note: the Atlassian API does not return a GitHub login. This strategy resolves the **bidirectional link**: it maps a Confluence actor UUID to a canonical developer identity (via email), which then enables score attribution. It does **not** populate `github_username` directly — it attributes Confluence activity to the correct developer.

**Revised scope for Strategy 2**: Rather than populating `github_username`, Strategy 2 is better understood as backfilling `actor_email` on existing `ticketing_activity_cache` rows for Confluence events, OR establishing a UUID→canonical_id mapping in memory/cache. If the goal is specifically `github_username` population, this must come from a third source (GitHub API or manual config).

**HTTP session**: Reuse `ConfluenceIntegration._build_session()` pattern (Basic auth with `username:api_token`). Note: the endpoint is `{atlassian_domain}/rest/api/3/user` (Jira Cloud API), not the Confluence wiki API — same auth, different path prefix.

---

## 9. Suggested File Structure

### Option A: Two files, standalone helpers (recommended)

```
src/gitflow_analytics/integrations/
    github_username_sync.py       # Strategy 1 — GitHub org member sync
    confluence_identity_sync.py   # Strategy 2 — Atlassian UUID resolution
```

Each file contains a single sync class with:
- `__init__(session_or_token, cache, config)` accepting the minimum needed context
- `sync(identity_resolver: DeveloperIdentityResolver) -> int` (returns count of identities updated)
- Internal `_build_session()` method copied from the existing integration pattern

**Invocation in `pipeline_report.py`**:

```python
# After identity_resolver.update_commit_stats(all_commits)
if getattr(cfg.github, "organization", None) and cfg.github.token:
    from .integrations.github_username_sync import GitHubUsernameSyncer
    try:
        syncer = GitHubUsernameSyncer(token=cfg.github.token, organization=cfg.github.organization)
        n = syncer.sync(identity_resolver)
        _emit(f"GitHub org sync: populated github_username for {n} developer(s)")
    except Exception as exc:
        logger.warning("GitHub username sync failed (non-fatal): %s", exc)

confluence_cfg = getattr(cfg, "confluence", None)
if confluence_cfg and getattr(confluence_cfg, "enabled", False):
    from .integrations.confluence_identity_sync import ConfluenceIdentitySyncer
    try:
        syncer = ConfluenceIdentitySyncer(
            base_url=confluence_cfg.base_url,
            username=confluence_cfg.username,
            api_token=confluence_cfg.api_token,
            cache=cache,
        )
        n = syncer.sync(identity_resolver)
        _emit(f"Confluence sync: attributed {n} Confluence actor(s) to developer identities")
    except Exception as exc:
        logger.warning("Confluence identity sync failed (non-fatal): %s", exc)
```

### Option B: Single `username_sync.py` with two strategies

Simpler for a first pass, but mixes GitHub and Atlassian concerns. Not recommended.

### New method needed on `DeveloperIdentityResolver`

```python
def find_canonical_id_by_email(self, email: str) -> Optional[str]:
    """Return the canonical_id for a developer with the given primary email or alias email.
    
    Returns None without side effects if no match is found.
    """
    email = email.lower().strip()
    if not email:
        return None
    with self.get_session() as session:
        alias = session.query(DeveloperAlias).filter(DeveloperAlias.email == email).first()
        if alias:
            return alias.canonical_id
        identity = session.query(DeveloperIdentity).filter(
            DeveloperIdentity.primary_email == email
        ).first()
        if identity:
            return identity.canonical_id
    return None
```

---

## 10. Summary Table

| Question | Finding |
|---|---|
| `GitHubConfig.organization` field | Exists: `Optional[str] = None` |
| `ConfluenceConfig` auth fields | `base_url`, `username`, `api_token` — no cloud_id needed |
| HTTP session pattern | Both integrations: `requests.Session` + `HTTPAdapter(Retry(...))` + headers set in constructor |
| Auth for GitHub | `Authorization: token {token}` header |
| Auth for Confluence | `Authorization: Basic {base64(username:api_token)}` header |
| Existing `_get_with_retries()` | GitHub Issues: yes. Confluence: yes (same signature). |
| Best sync insertion point | `pipeline_report.py::run_report()` after `update_commit_stats()` |
| `_set_github_username_if_missing()` | Exists (line 645, identity.py). Only writes if NULL. Updates in-memory cache. |
| "Find by email" public method | Does not exist — need to add `find_canonical_id_by_email()` |
| Confluence `actor` column format | Atlassian account UUID (e.g. `712020:d2d0c7b6-...`) on Cloud; short username on Server/DC |
| `actor_email` for Confluence rows | NULL — must be resolved via `GET /rest/api/3/user?accountId={uuid}` |
| Atlassian user API domain | Strip `/wiki` from `ConfluenceConfig.base_url` to get `https://company.atlassian.net` |
| Suggested file structure | Two standalone files: `github_username_sync.py`, `confluence_identity_sync.py` |
