# Research: weekly_trends Aggregation from daily_metrics

**Date:** 2026-04-26
**Scope:** How `weekly_trends` is populated from `daily_metrics`, schema analysis, and field mapping

---

## Key Finding: Two Separate Systems Named "weekly_trends"

There are **two distinct systems** in this codebase that both go by "weekly trends":

1. **`WeeklyTrends` SQLAlchemy ORM table** (`weekly_trends` DB table) — defined but **never written to** by any production code path. It is a dead-code schema.
2. **`WeeklyTrendsWriter` CSV reports** (`developer_weekly_trends*.csv`, `project_weekly_trends*.csv`) — the live aggregation path that runs during `gfa report`.

---

## 1. The `WeeklyTrends` ORM Table (DB table: `weekly_trends`)

### Schema (from `database_commit_models.py`)

| Column | Type | Default | Notes |
|---|---|---|---|
| `id` | INTEGER | PK | |
| `week_start` | DateTime | NOT NULL | Monday of the week |
| `week_end` | DateTime | NOT NULL | Sunday of the week |
| `developer_id` | String | NOT NULL | |
| `project_key` | String | NOT NULL | |
| `total_commits` | Integer | 0 | |
| `feature_commits` | Integer | 0 | |
| `bug_fix_commits` | Integer | 0 | |
| `refactor_commits` | Integer | 0 | |
| `total_commits_change` | Float | 0.0 | % WoW change |
| `feature_commits_change` | Float | 0.0 | % WoW change |
| `bug_fix_commits_change` | Float | 0.0 | % WoW change |
| `refactor_commits_change` | Float | 0.0 | % WoW change |
| `days_active` | Integer | 0 | Days with commits |
| `avg_commits_per_day` | Float | 0.0 | |
| `churn_rate_14d` | Float | 0.0 | Added via v7.0 migration |
| `prs_merged` | Integer | 0 | Added via v8.0 migration |
| `avg_cycle_time_hrs` | Float | 0.0 | Added via v8.0 migration |
| `median_cycle_time_hrs` | Float | 0.0 | Added via v8.0 migration |
| `avg_revision_count` | Float | 0.0 | Added via v8.0 migration |
| `story_points_delivered` | Integer | 0 | Added via v8.0 migration |
| `calculated_at` | DateTime(tz) | utcnow | |

**Indexes:** `idx_weekly_start`, `idx_weekly_dev_proj`, `idx_weekly_unique (week_start, developer_id, project_key)`

### Critical Gap: `tracked_commits` / `untracked_commits` are NOT in `WeeklyTrends`

The ORM table has **no `tracked_commits` or `untracked_commits` columns**. These fields exist only in `daily_metrics`.

### Critical Gap: No Code Writes to This Table

A full codebase search for `WeeklyTrends(` (ORM instantiation) returns **zero results** outside the model definition itself. The table is never inserted into. The schema migrations (`_migrate_weekly_trends_churn_column`, `_migrate_weekly_trends_velocity_columns` in `database.py`) add columns to it, but the table stays empty at runtime.

---

## 2. The `DailyMetrics` ORM Table (DB table: `daily_metrics`)

### Schema (from `database_commit_models.py`)

One row = one developer × one project × one day.

| Column | Type | Default | Notes |
|---|---|---|---|
| `id` | INTEGER | PK | |
| `date` | DateTime | NOT NULL | |
| `developer_id` | String | NOT NULL | |
| `project_key` | String | NOT NULL | |
| `developer_name` | String | NOT NULL | |
| `developer_email` | String | NOT NULL | |
| `feature_commits` | Integer | 0 | |
| `bug_fix_commits` | Integer | 0 | |
| `refactor_commits` | Integer | 0 | |
| `documentation_commits` | Integer | 0 | |
| `maintenance_commits` | Integer | 0 | |
| `test_commits` | Integer | 0 | |
| `style_commits` | Integer | 0 | |
| `build_commits` | Integer | 0 | |
| `other_commits` | Integer | 0 | |
| `total_commits` | Integer | 0 | |
| `files_changed` | Integer | 0 | |
| `lines_added` | Integer | 0 | |
| `lines_deleted` | Integer | 0 | |
| `story_points` | Integer | 0 | |
| **`tracked_commits`** | Integer | 0 | Commits with ticket refs |
| **`untracked_commits`** | Integer | 0 | Commits without ticket refs |
| `unique_tickets` | Integer | 0 | Count of distinct tickets |
| `merge_commits` | Integer | 0 | |
| `complex_commits` | Integer | 0 | `files_changed > 5` |
| `ai_assisted_commits` | Integer | 0 | Added via v6.0 migration |
| `ai_generated_commits` | Integer | 0 | Added via v6.0 migration |
| `ai_tool_primary` | String | "" | Added via v6.0 migration |
| `ai_assisted_lines` | Integer | 0 | Added via v6.0 migration |
| `ai_generated_lines` | Integer | 0 | Added via v6.0 migration |
| `created_at` | DateTime(tz) | utcnow | |
| `updated_at` | DateTime | utcnow | |

**Unique constraint:** `(date, developer_id, project_key)`

`tracked_commits` and `untracked_commits` **do exist** in `daily_metrics`.

---

## 3. How `tracked_commits` / `untracked_commits` Are Populated in `daily_metrics`

**File:** `/Users/masa/Projects/gitflow-analytics/src/gitflow_analytics/core/metrics_storage.py`

**Function:** `DailyMetricsStorage._aggregate_commits_by_day()` (lines 363–520)

The logic per commit (lines 453–466):
```python
ticket_refs = commit.get("ticket_references", [])
if ticket_refs:
    metrics["tracked_commits"] += 1
    # extract ticket IDs from [{id, platform}] or ["PROJ-123"]
    ticket_ids = []
    for ref in ticket_refs:
        if isinstance(ref, dict):
            ticket_ids.append(ref.get("id", str(ref)))
        else:
            ticket_ids.append(str(ref))
    metrics["unique_tickets"].update(ticket_ids)
else:
    metrics["untracked_commits"] += 1
```

Summary: if a commit has any `ticket_references`, it is `tracked`; otherwise `untracked`.

---

## 4. The Actual daily→weekly Aggregation Path (Live Code)

### Path A: `DailyMetricsStorage._get_weekly_aggregates()` (metrics_storage.py lines 604–639)

Used by `calculate_weekly_trends()` (called only from `DatabaseReportGenerator`). Groups `daily_metrics` rows into ISO weeks via SQLite `strftime('%Y-%W', date)`. **Only aggregates:**
- `total_commits`, `feature_commits`, `bug_fix_commits`, `refactor_commits`

**Does NOT aggregate:** `tracked_commits`, `untracked_commits`, `lines_added`, `lines_deleted`, `story_points`, `files_changed`, AI columns, or any other fields.

### Path B: `WeeklyTrendsWriter._generate_developer_weekly_trends()` / `_generate_project_weekly_trends()` (weekly_trends_writer.py)

The primary report-time aggregation. Takes raw `commits` list (not `daily_metrics` DB rows), groups by Monday-anchored ISO week, and aggregates:
- Per-category commit counts (feature, bug_fix, refactor, etc.)
- `total_commits`
- `ai_assisted_commits`, `ai_assisted_pct`, `primary_ai_tool`
- `churn_rate_14d`
- WoW % change for each category

**Does NOT aggregate:** `tracked_commits` or `untracked_commits` from `daily_metrics`. These are completely absent from the CSV output.

---

## 5. Answer to Your Specific Questions

### Exact functions that aggregate daily → weekly

| Function | Location | Input | Output | tracked/untracked? |
|---|---|---|---|---|
| `DailyMetricsStorage._get_weekly_aggregates()` | `metrics_storage.py:604` | DB query on `daily_metrics` | `list[dict]` (in-memory) | NO |
| `DailyMetricsStorage.calculate_weekly_trends()` | `metrics_storage.py:264` | date range | `dict[(dev, proj), trend_floats]` | NO |
| `WeeklyTrendsWriter._generate_developer_weekly_trends()` | `weekly_trends_writer.py:121` | raw commits list | CSV file | NO |
| `WeeklyTrendsWriter._generate_project_weekly_trends()` | `weekly_trends_writer.py:322` | raw commits list | CSV file | NO |

### Are `tracked_commits`/`untracked_commits` included in weekly aggregation?

**No.** Neither path that produces weekly output includes `tracked_commits` or `untracked_commits`. They exist in `daily_metrics` and are accessed by `DatabaseReportGenerator` (lines 345–346, 375–376) only for totals in the qualitative report, not for weekly rollups.

### `weekly_trends` table schema

See table in Section 1 above. 21 columns. No `tracked_commits` or `untracked_commits` columns.

### `DailyMetrics` model attribute names

The exact Python attribute names on the SQLAlchemy model (matching column names):
- `tracked_commits` (Integer, default=0)
- `untracked_commits` (Integer, default=0)
- `unique_tickets` (Integer, default=0)

---

## 6. Implications / Action Items

If you need `tracked_commits`/`untracked_commits` in weekly rollups:

1. **Add columns to `WeeklyTrends` ORM** (`tracked_commits INTEGER DEFAULT 0`, `untracked_commits INTEGER DEFAULT 0`) and add a v11 migration in `database.py._apply_migrations()`.
2. **Write actual rows to `weekly_trends`** — currently no code does this. Either create a new `store_weekly_trends()` method that queries `daily_metrics` grouped by week and SUM aggregates `tracked_commits`/`untracked_commits`, or extend `_get_weekly_aggregates()` to include them.
3. **OR** extend `WeeklyTrendsWriter` CSV output to include `tracked_commits_count` and `untracked_commits_count` columns computed from the per-commit `ticket_references` field already available in the commits list passed to the writer.

---

## File Reference

| File | Role |
|---|---|
| `/src/gitflow_analytics/models/database_commit_models.py` | `DailyMetrics` and `WeeklyTrends` ORM definitions |
| `/src/gitflow_analytics/core/metrics_storage.py` | `DailyMetricsStorage` — populates `daily_metrics`, provides `calculate_weekly_trends()` |
| `/src/gitflow_analytics/reports/weekly_trends_writer.py` | `WeeklyTrendsWriter` — CSV report from raw commits list |
| `/src/gitflow_analytics/models/database.py` | `_apply_migrations()` — all ALTER TABLE history for both tables |
| `/src/gitflow_analytics/reports/database_report_generator.py` | Only consumer of `tracked_commits`/`untracked_commits` totals |
