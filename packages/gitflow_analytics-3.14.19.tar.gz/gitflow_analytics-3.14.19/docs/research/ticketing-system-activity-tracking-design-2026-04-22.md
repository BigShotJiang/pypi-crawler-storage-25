# Technical Brief: Ticketing System Activity Tracking (GitHub Issues + Confluence)

**Date**: 2026-04-22
**Status**: Design / Pre-implementation
**Scope**: New integrations for GitHub Issues activity and Confluence page activity, with DB
persistence, config schema, identity mapping, and report output.

---

## 1. Integration Patterns to Follow

### 1.1 Class Structure

Each integration is a self-contained class in `src/gitflow_analytics/integrations/`.

**Naming pattern** (follow exactly):
- `github_integration.py` → `GitHubIntegration`
- `jira_integration.py`   → `JIRAIntegration`
- New: `github_issues_integration.py` → `GitHubIssuesIntegration`
- New: `confluence_integration.py`    → `ConfluenceIntegration`

### 1.2 Constructor Signature Pattern

Every integration takes `(cache: GitAnalysisCache, ...)` as its second argument
after the auth credential(s). All auth params resolve through `_resolve_env_var`
before reaching the class.

```python
class GitHubIssuesIntegration:
    def __init__(
        self,
        token: str,
        cache: GitAnalysisCache,
        rate_limit_retries: int = 3,
        backoff_factor: int = 2,
        allowed_repos: Optional[list[str]] = None,
        fetch_comments: bool = False,
    ):
        self.github = Github(token)
        self.cache = cache
        self.rate_limit_retries = rate_limit_retries
        self.backoff_factor = backoff_factor
        self.allowed_repos = allowed_repos
        self.fetch_comments = fetch_comments
        self.schema_manager = create_schema_manager(cache.cache_dir)
```

```python
class ConfluenceIntegration:
    def __init__(
        self,
        base_url: str,
        username: str,
        api_token: str,
        cache: GitAnalysisCache,
        spaces: Optional[list[str]] = None,
        dns_timeout: int = 10,
        connection_timeout: int = 30,
        max_retries: int = 3,
        backoff_factor: float = 1.0,
    ):
```

### 1.3 Cache Interaction Pattern

Both `GitHubIntegration` and `JIRAIntegration` use `self.cache.get_session()` as a
context manager for all DB reads/writes. They delegate to `cache.cache_issue()` and
`cache.cache_pr()` for upserts. The new integrations must do the same.

**Bulk cache pattern** (required for performance - see `_get_cached_tickets_bulk`):
```python
def _get_cached_issues_bulk(self, issue_ids: list[str]) -> dict[str, dict]:
    with self.cache.get_session() as session:
        from ..models.database import TicketingActivityCache
        results = (
            session.query(TicketingActivityCache)
            .filter(
                TicketingActivityCache.platform == "github_issues",
                TicketingActivityCache.item_id.in_(issue_ids),
            )
            .all()
        )
        return {r.item_id: self._row_to_dict(r) for r in results
                if not self._is_stale(r.cached_at)}
```

### 1.4 Incremental Fetch Pattern

`GitHubIntegration._get_incremental_fetch_date()` uses `schema_manager` to avoid
re-fetching data that has not changed since the last run. The new GitHub Issues
integration should use the same pattern with a distinct `component` name:

```python
fetch_since = self._get_incremental_fetch_date(
    "github_issues", since, config_snapshot
)
```

### 1.5 Rate-Limit / Retry Pattern

Follow `JIRAIntegration._create_resilient_session()` for HTTP integrations
(Confluence). For PyGitHub integrations, wrap calls in:

```python
for attempt in range(self.rate_limit_retries):
    try:
        ...
        break
    except RateLimitExceededException:
        if attempt < self.rate_limit_retries - 1:
            time.sleep(self.backoff_factor ** attempt)
        else:
            print("Rate limit exceeded, skipping")
            return []
```

### 1.6 Staleness Check Pattern

Both integrations check `self.cache.ttl_hours`:

```python
def _is_stale(self, cached_at: datetime) -> bool:
    from datetime import timedelta
    if self.cache.ttl_hours == 0:
        return False
    threshold = datetime.utcnow() - timedelta(hours=self.cache.ttl_hours)
    return cached_at < threshold
```

---

## 2. Orchestrator Wiring

`src/gitflow_analytics/integrations/orchestrator.py` → `IntegrationOrchestrator`

### 2.1 Where to Add

In `__init__`, add after the JIRA block:

```python
# GitHub Issues integration
if config.github and config.github.token and getattr(config.github_issues, "enabled", False):
    self.integrations["github_issues"] = GitHubIssuesIntegration(
        token=config.github.token,
        cache=cache,
        rate_limit_retries=getattr(config.github, "max_retries", 3),
        backoff_factor=getattr(config.github, "backoff_factor", 2),
        fetch_comments=getattr(config.github_issues, "fetch_comments", False),
    )

# Confluence integration
if (
    hasattr(config, "confluence")
    and config.confluence
    and getattr(config.confluence, "enabled", False)
    and config.confluence.base_url
    and config.confluence.api_token
):
    self.integrations["confluence"] = ConfluenceIntegration(
        base_url=config.confluence.base_url,
        username=config.confluence.username,
        api_token=config.confluence.api_token,
        cache=cache,
        spaces=getattr(config.confluence, "spaces", None),
    )
```

### 2.2 enrich_repository_data Return Shape

Add to the `enrichment` dict in `enrich_repository_data`:

```python
enrichment: dict[str, Any] = {
    "prs": [],
    "issues": [],
    "pr_metrics": {},
    "pm_data": {},
    "cicd_data": {"pipelines": [], "metrics": {}},
    "ticketing_activity": {          # NEW
        "github_issues": [],
        "confluence_pages": [],
        "metrics": {},
    },
}
```

---

## 3. Database Tables

### 3.1 Existing Tables Relevant to This Feature

- `issue_cache` — already stores `platform`, `issue_id`, `project_key`, `title`,
  `description`, `status`, `assignee`, `created_at`, `updated_at`, `resolved_at`,
  `story_points`, `labels`, `platform_data`, `cached_at`.
  **Gotcha**: `platform` column is indexed with `issue_id` as a unique pair
  (`idx_platform_issue`). You can reuse this table for GitHub Issues by setting
  `platform = "github_issues"`.

### 3.2 New Table: `ticketing_activity_cache`

This table tracks per-item activity events (comments, status changes, page edits)
rather than just the issue/page snapshot stored in `issue_cache`. It follows the
same column convention as the existing models in
`src/gitflow_analytics/models/database_metrics_models.py`.

**File**: `src/gitflow_analytics/models/database_metrics_models.py` (add alongside
`IssueCache`)

```python
class TicketingActivityCache(Base):
    """Cached ticketing system activity — GitHub Issues comments/events and
    Confluence page edits.

    Schema version: v10.0 (added in migration _migrate_ticketing_activity_v10)

    WHY: Activity data (who commented, when pages were edited) differs from the
    ticket/page snapshot already held in issue_cache.  Storing it separately
    prevents bloating issue_cache rows and allows efficient time-range queries
    on activity volume per developer.
    """

    __tablename__ = "ticketing_activity_cache"

    id = Column(Integer, primary_key=True)

    # Source identification
    platform = Column(String, nullable=False)   # 'github_issues' | 'confluence'
    item_id = Column(String, nullable=False)    # Issue number (str) or page_id
    item_type = Column(String, nullable=False)  # 'issue' | 'comment' | 'page_edit'
    repo_or_space = Column(String, nullable=False)  # repo full name or Confluence space key

    # Activity data
    actor = Column(String, nullable=True)       # GitHub login or Confluence username (lowercased)
    actor_display_name = Column(String, nullable=True)  # Display name for identity resolution
    actor_email = Column(String, nullable=True)          # Email when available (Confluence)
    action = Column(String, nullable=True)      # 'opened' | 'closed' | 'commented' | 'edited' | 'labeled'
    activity_at = Column(DateTime(timezone=True), nullable=False)  # When activity occurred

    # Item context (snapshot at time of cache)
    item_title = Column(String, nullable=True)
    item_status = Column(String, nullable=True)   # open | closed | in_progress etc.
    item_url = Column(String, nullable=True)

    # Ticket linkage (for cross-referencing with commit ticket_references)
    linked_ticket_id = Column(String, nullable=True)   # e.g. "PROJ-123" or "#456"

    # Numeric metrics
    comment_count = Column(Integer, nullable=True, default=0)
    reaction_count = Column(Integer, nullable=True, default=0)

    # Platform-specific blob (additional fields, not normalized)
    platform_data = Column(JSON, nullable=True)

    # Cache metadata
    cached_at = Column(DateTime(timezone=True), default=utcnow_tz_aware)

    __table_args__ = (
        Index("idx_ticketing_platform_item", "platform", "item_id"),
        Index("idx_ticketing_actor", "actor"),
        Index("idx_ticketing_activity_at", "activity_at"),
        Index("idx_ticketing_repo_space", "repo_or_space"),
    )
```

**Note**: Do NOT add a `UniqueConstraint` on `(platform, item_id)` alone — one
issue can have multiple activity events. Use `(platform, item_id, item_type, activity_at)`
if you need uniqueness at upsert time, or manage it in application code.

### 3.3 New Table: `confluence_page_cache`

Stores Confluence page snapshots (not activity events — those go in
`ticketing_activity_cache`).

```python
class ConfluencePageCache(Base):
    """Cached Confluence page metadata for activity tracking."""

    __tablename__ = "confluence_page_cache"

    id = Column(Integer, primary_key=True)

    # Page identification
    page_id = Column(String, nullable=False)
    space_key = Column(String, nullable=False)

    # Page metadata
    title = Column(String, nullable=True)
    version = Column(Integer, nullable=True)          # Confluence page version number
    author = Column(String, nullable=True)            # Creator login/username (lowercased)
    author_email = Column(String, nullable=True)
    last_editor = Column(String, nullable=True)       # Last modifier login (lowercased)
    last_editor_email = Column(String, nullable=True)
    created_at = Column(DateTime(timezone=True), nullable=True)
    updated_at = Column(DateTime(timezone=True), nullable=True)

    # Content metrics
    labels = Column(JSON, nullable=True)              # list[str] of page labels
    ancestor_ids = Column(JSON, nullable=True)        # parent page IDs for hierarchy
    page_url = Column(String, nullable=True)

    # Platform-specific blob
    platform_data = Column(JSON, nullable=True)

    # Cache metadata
    cached_at = Column(DateTime(timezone=True), default=utcnow_tz_aware)

    __table_args__ = (
        Index("idx_confluence_page", "page_id", unique=True),
        Index("idx_confluence_space", "space_key"),
        Index("idx_confluence_author", "author"),
    )
```

### 3.4 Re-exports

Add both new models to `src/gitflow_analytics/models/database.py`:

```python
from .database_metrics_models import (  # noqa: E402
    ...
    ConfluencePageCache,         # NEW
    TicketingActivityCache,      # NEW
    ...
)

__all__ = [
    ...
    "ConfluencePageCache",
    "TicketingActivityCache",
]
```

---

## 4. Database Migration

### 4.1 Current Highest Migration Version

The highest numbered migration in `database.py._apply_migrations()` is **v9.0**
(`_migrate_cached_commits_ai_columns`).

**New migration version: v10.0**

### 4.2 Migration Method to Add in `database.py`

Add to `_apply_migrations()`:

```python
# --- Ticketing activity cache tables (v10.0 migration) ---
self._migrate_ticketing_activity_v10(conn)
```

And the method itself:

```python
def _migrate_ticketing_activity_v10(self, conn) -> None:
    """Create ticketing_activity_cache and confluence_page_cache tables (v10.0).

    WHY: These tables support GitHub Issues and Confluence activity tracking,
    enabling developer productivity metrics beyond commit and PR data.
    Both tables are created via SQLAlchemy's create_all at startup, so this
    migration only needs to handle column additions for pre-existing deployments
    that already had a partial schema.  For fresh databases, create_all is
    sufficient.

    This migration is intentionally a no-op if the tables already exist.
    """
    try:
        result = conn.execute(
            text(
                "SELECT name FROM sqlite_master WHERE type='table' "
                "AND name='ticketing_activity_cache'"
            )
        )
        if result.fetchone() is None:
            # Tables created by create_all at startup — nothing to do here.
            # Log for observability.
            logger.debug(
                "ticketing_activity_cache not yet created by create_all; "
                "will be created on next startup."
            )
    except Exception as e:
        logger.debug(f"v10 migration check failed (non-fatal): {e}")
```

**Gotcha**: Because `Base.metadata.create_all(self.engine)` is called before
`_apply_migrations()`, new tables defined as SQLAlchemy models will be created
automatically for fresh databases. The `_migrate_*` methods are only needed to
ADD COLUMNS to existing tables that pre-date the model change. For brand-new
tables added in a new model class, `create_all` handles creation and the migration
method is just an observability hook.

---

## 5. Config Dataclasses

### 5.1 New Dataclasses in `src/gitflow_analytics/config/schema.py`

Add these alongside `JIRAConfig` / `JIRAIntegrationConfig`:

```python
@dataclass
class GitHubIssuesConfig:
    """GitHub Issues activity tracking configuration."""

    enabled: bool = False
    # Fetch comments per issue (extra API calls per issue — off by default)
    fetch_comments: bool = False
    # Only track issues from these repos (None = all configured repos)
    allowed_repos: Optional[list[str]] = None
    # Issue states to track: "open", "closed", "all"
    issue_state: str = "all"
    # Max issues to fetch per repo per run (rate-limit protection)
    max_issues_per_repo: int = 500


@dataclass
class ConfluenceConfig:
    """Confluence API configuration for page activity tracking."""

    enabled: bool = False
    base_url: str = ""                          # e.g. https://company.atlassian.net/wiki
    username: str = ""                          # Atlassian account email
    api_token: str = ""                         # Atlassian API token
    # Confluence space keys to fetch (empty = all accessible spaces)
    spaces: list[str] = field(default_factory=list)
    # Track page edits (version history) as activity events
    fetch_page_history: bool = False
    dns_timeout: int = 10
    connection_timeout: int = 30
    max_retries: int = 3
    backoff_factor: float = 1.0
```

### 5.2 Add to `Config` Dataclass

```python
@dataclass
class Config:
    ...
    github_issues: Optional[GitHubIssuesConfig] = None    # NEW
    confluence: Optional[ConfluenceConfig] = None          # NEW
```

### 5.3 Config Loader Wiring

In `src/gitflow_analytics/config/loader_sections.py` add two new `_process_*`
classmethods following the `_process_jira_integration_config` pattern:

```python
@classmethod
def _process_github_issues_config(
    cls, data: dict[str, Any]
) -> Optional[GitHubIssuesConfig]:
    if not data or not data.get("enabled", False):
        return None
    return GitHubIssuesConfig(
        enabled=data.get("enabled", False),
        fetch_comments=data.get("fetch_comments", False),
        allowed_repos=data.get("allowed_repos"),
        issue_state=data.get("issue_state", "all"),
        max_issues_per_repo=data.get("max_issues_per_repo", 500),
    )

@classmethod
def _process_confluence_config(
    cls, data: dict[str, Any], config_path: Path
) -> Optional[ConfluenceConfig]:
    if not data or not data.get("enabled", False):
        return None
    api_token = cls._resolve_env_var(data.get("api_token", ""))
    username = cls._resolve_env_var(data.get("username", ""))
    return ConfluenceConfig(
        enabled=data.get("enabled", False),
        base_url=data.get("base_url", "").rstrip("/"),
        username=username,
        api_token=api_token,
        spaces=data.get("spaces", []),
        fetch_page_history=data.get("fetch_page_history", False),
        dns_timeout=data.get("dns_timeout", 10),
        connection_timeout=data.get("connection_timeout", 30),
        max_retries=data.get("max_retries", 3),
        backoff_factor=data.get("backoff_factor", 1.0),
    )
```

In `loader.py`, add calls in the "Process configuration sections" block:

```python
github_issues_config = cls._process_github_issues_config(
    data.get("github_issues", {})
)
confluence_config = cls._process_confluence_config(
    data.get("confluence", {}), config_path
)
```

And pass them to `Config(...)`:

```python
config = Config(
    ...
    github_issues=github_issues_config,
    confluence=confluence_config,
)
```

### 5.4 YAML Usage Example

```yaml
github_issues:
  enabled: true
  fetch_comments: false
  issue_state: "all"
  max_issues_per_repo: 500

confluence:
  enabled: true
  base_url: "https://mycompany.atlassian.net/wiki"
  username: "${CONFLUENCE_USER}"
  api_token: "${CONFLUENCE_TOKEN}"
  spaces:
    - "ENG"
    - "PRODUCT"
  fetch_page_history: false
```

---

## 6. Identity / Alias Mapping for Ticket Authors

### 6.1 How Identity Resolution Works

`DeveloperIdentityResolver` (in `src/gitflow_analytics/core/identity.py`) maps
`(author_email, author_name)` pairs to a canonical developer identity stored in
`developer_identities` / `developer_aliases` tables. The key method is
`update_commit_stats(commits)` which iterates commits and resolves them.

The resolver's `_cache` dict maps `"email:name"` → `canonical_id`.

### 6.2 Challenge with Ticket Authors

GitHub Issues actors are identified by **GitHub login** (e.g. `jsmith`).
Confluence actors use **username** or **email**. Neither matches the git
`author_email` used for commits.

### 6.3 Recommended Approach

**Step 1 — Store actor fields verbatim** in `ticketing_activity_cache.actor`
(lowercased login) and `actor_email` (when available from the API).

**Step 2 — Extend identity resolution** with a new lookup path in
`DeveloperIdentityResolver`. Add a method:

```python
def resolve_github_login(self, login: str) -> Optional[str]:
    """Return canonical_id for a GitHub login, or None if unmapped."""
    key = f"github:{login.lower()}"
    if key in self._cache:
        return self._cache[key]
    # Query DeveloperAlias table for github_username match
    with self.db.get_session() as session:
        alias = (
            session.query(DeveloperIdentity)
            .filter(DeveloperIdentity.github_username == login.lower())
            .first()
        )
        if alias:
            self._cache[key] = alias.canonical_id
            return alias.canonical_id
    return None
```

**Step 3 — Manual mapping in config** via the existing
`analysis.identity.manual_mappings` list. Users can map GitHub logins to
canonical developer emails:

```yaml
analysis:
  identity:
    manual_mappings:
      - canonical: "jane.smith@company.com"
        github_username: "jsmith"       # used for issues/PR authors
        aliases:
          - "Jane Smith"
```

**Step 4 — In the reporting layer**, attempt identity resolution via
`resolve_github_login(actor)` first; fall back to `actor` (the raw login)
if unresolved, so data is never silently dropped.

### 6.4 DeveloperIdentity Model Note

`DeveloperIdentity` (in `database_identity_models.py`) already has a
`github_username` field based on the existing code references. Confirm it
exists and add it if missing.

---

## 7. Output Reports / JSON Files

Follow the existing pattern: all JSON reports are named as fixed filenames
(not date-stamped) and registered in `generated` inside `run_report()`.

### 7.1 Proposed Output Files

| File | Description |
|------|-------------|
| `ticketing_activity_summary.json` | Per-developer ticket activity counts (issues opened, commented, closed; pages edited) for the analysis period |
| `github_issues_summary.json` | Issue-level breakdown: open/closed counts, avg resolution time, top contributors by issue activity |
| `confluence_activity_summary.json` | Page edit counts by space and author (only if Confluence enabled) |

### 7.2 JSON Schema for `ticketing_activity_summary.json`

```json
{
  "metadata": {
    "generated_at": "...",
    "period_start": "...",
    "period_end": "...",
    "platforms": ["github_issues", "confluence"]
  },
  "developers": [
    {
      "canonical_id": "jane.smith@company.com",
      "developer_name": "Jane Smith",
      "github_login": "jsmith",
      "github_issues_opened": 3,
      "github_issues_closed": 2,
      "github_issue_comments": 17,
      "confluence_pages_edited": 5,
      "confluence_pages_created": 1,
      "total_ticketing_activity": 28
    }
  ],
  "summary": {
    "total_issues_tracked": 142,
    "total_confluence_pages_tracked": 38,
    "avg_resolution_time_hours": 47.3,
    "most_active_developers": ["jsmith", "mbrown"]
  }
}
```

### 7.3 Wiring in `pipeline_report.py`

Add after the team aggregation block (around line 540), following the same
`_try_report` + `generated.append` pattern:

```python
# --- Ticketing activity report ---
ticketing_cfg = getattr(cfg, "github_issues", None)
confluence_cfg = getattr(cfg, "confluence", None)
if (ticketing_cfg and getattr(ticketing_cfg, "enabled", False)) or \
   (confluence_cfg and getattr(confluence_cfg, "enabled", False)):
    _try_report(
        "ticketing_activity",
        lambda: _generate_ticketing_activity_report(
            cache,
            cfg,
            identity_resolver,
            output_dir,
            start_date,
            end_date,
        ),
    )
    ticketing_json = output_dir / "ticketing_activity_summary.json"
    if ticketing_json.exists():
        generated.append("ticketing_activity_summary.json")
```

---

## 8. Gotchas and Patterns That Must Be Followed

### 8.1 Datetime Storage — Always Naive UTC

All `DateTime` columns in this project use `timezone=True` in the ORM model
definition, but datetimes are stored as **naive UTC** in practice (`.replace(tzinfo=None)`
before insert). See `JIRAIntegration._parse_jira_date()` for the established pattern.
When reading back, always normalize:

```python
if dt and dt.tzinfo is None:
    dt = dt.replace(tzinfo=timezone.utc)
```

### 8.2 Author / Login Normalization — Always Lowercase

GitHub logins and JIRA usernames are **always lowercased** before storage and
lookup. See `GitHubIntegration._extract_pr_data()` line with comment
`# Gap 5: Normalize author login to lowercase`. Apply the same rule to
all `actor` / `author` fields in the new tables.

### 8.3 JSON Columns in SQLite

Lists and dicts are stored as `Column(JSON)` which SQLAlchemy serializes
transparently. On read, the value is a Python list/dict. When the column
might be absent (backward compat), use `getattr(row, "labels", None) or []`.

### 8.4 `getattr` for Backward Compatibility on Cache Reads

When reading columns that may not exist in older database rows (pre-migration),
always use `getattr(cached_row, "new_column_name", None)`. See
`_get_cached_prs_bulk` for the established pattern throughout.

### 8.5 `_apply_migrations` is Idempotent by Design

Every migration method uses `try/except` around each `ALTER TABLE` so that
running migrations multiple times is safe. Follow this exactly — never assume
a column does not exist before issuing `ALTER TABLE`.

### 8.6 Integration Type Union in Orchestrator

The orchestrator's `self.integrations` dict is typed as
`dict[str, Union[GitHubIntegration, JIRAIntegration]]`. Add the new types:

```python
self.integrations: dict[
    str,
    Union[GitHubIntegration, JIRAIntegration, GitHubIssuesIntegration, ConfluenceIntegration]
] = {}
```

### 8.7 `enrich_repository_data` Is Called Per-Repo

`IntegrationOrchestrator.enrich_repository_data()` is called once per
repository in the pipeline. GitHub Issues fetching should be scoped to
`repo_config.github_repo` (the `owner/repo` string). Confluence is
organization-wide and should be fetched once and cached across repos — guard
with a flag like `self._confluence_fetched = False` and skip on subsequent
calls.

### 8.8 Schema Manager Component Names Must Be Unique

`create_schema_manager(cache.cache_dir)` tracks last-fetch dates by `component`
string. Use `"github_issues"` and `"confluence"` — do not reuse `"github"` which
is already claimed by `GitHubIntegration`.

### 8.9 `IssueCache` Can Be Reused for GitHub Issues Snapshots

The existing `IssueCache` table already supports `platform = "github_issues"`.
Use it for the issue snapshot (title, status, assignee, created/updated dates,
labels) and reserve `TicketingActivityCache` for the per-event activity stream
(comments, state changes, page edits). This avoids duplicating the snapshot
storage.

### 8.10 Config Section Names Are Top-Level YAML Keys

All config sections added to date (`velocity`, `teams`, `quality_report`,
`ai_detection`, `boilerplate_filter`) are **top-level YAML keys**, not nested
under `analysis`. Follow this pattern: `github_issues:` and `confluence:` at
the top level.

---

## 9. Migration Version Summary

| Version | Method | Table Modified | What Was Added |
|---------|--------|---------------|----------------|
| v1.0 | (initial create_all) | Multiple | Base schema |
| v2.0 | `_perform_schema_migration` | Multiple | Timezone-aware timestamps |
| v3.0 | `_migrate_pull_request_cache_v3` | `pull_request_cache` | Review tracking columns |
| v4.0 | `_migrate_pull_request_cache_v4` | `pull_request_cache` | PR state columns |
| v5.0 | `_migrate_qualitative_commits_v5` | `qualitative_commits` | `complexity` column |
| v6.0 | `_migrate_daily_metrics_ai_columns` | `daily_metrics` | AI tool tracking columns |
| v7.0 | `_migrate_weekly_trends_churn_column` | `weekly_trends` | `churn_rate_14d` |
| v8.0 | `_migrate_weekly_trends_velocity_columns` | `weekly_trends` | Velocity columns |
| v9.0 | `_migrate_cached_commits_ai_columns` | `cached_commits` | AI confidence columns |
| **v10.0** | **`_migrate_ticketing_activity_v10`** | **NEW TABLES** | **`ticketing_activity_cache`, `confluence_page_cache`** |

---

## 10. File Checklist for Implementation

| File | Action | Notes |
|------|--------|-------|
| `src/gitflow_analytics/integrations/github_issues_integration.py` | CREATE | New class `GitHubIssuesIntegration` |
| `src/gitflow_analytics/integrations/confluence_integration.py` | CREATE | New class `ConfluenceIntegration` |
| `src/gitflow_analytics/integrations/orchestrator.py` | MODIFY | Wire new integrations in `__init__` and `enrich_repository_data` |
| `src/gitflow_analytics/models/database_metrics_models.py` | MODIFY | Add `TicketingActivityCache`, `ConfluencePageCache` |
| `src/gitflow_analytics/models/database.py` | MODIFY | Re-export new models; add `_migrate_ticketing_activity_v10` and call in `_apply_migrations` |
| `src/gitflow_analytics/config/schema.py` | MODIFY | Add `GitHubIssuesConfig`, `ConfluenceConfig`; add fields to `Config` |
| `src/gitflow_analytics/config/loader_sections.py` | MODIFY | Add `_process_github_issues_config`, `_process_confluence_config` |
| `src/gitflow_analytics/config/loader.py` | MODIFY | Call new section processors; pass to `Config()` |
| `src/gitflow_analytics/core/identity.py` | MODIFY | Add `resolve_github_login()` method |
| `src/gitflow_analytics/reports/ticketing_activity_report.py` | CREATE | Report generator producing `ticketing_activity_summary.json` |
| `src/gitflow_analytics/pipeline_report.py` | MODIFY | Add `_try_report` block for ticketing activity report |
