# GitHub PR Collection & Backfill Analysis

**Date:** 2026-04-29
**Project:** gitflow-analytics
**Purpose:** Understand PR collection pipeline in detail to implement `--backfill-since` CLI flag

---

## 1. Where the GitHub API is Called to Fetch PRs

### Primary entry point

**File:** `src/gitflow_analytics/integrations/github_integration.py`
**Method:** `GitHubIntegration._get_pull_requests()` — lines 415–459

```python
# Line 432 — the actual PyGitHub API call
for pr in repo.get_pulls(state="all", sort="updated", direction="desc"):
    if pr.updated_at < since:
        break          # early-exit: results are sorted newest-first

    if pr.merged and pr.merged_at >= since:
        prs.append(pr)       # merged PR within window
    elif (not pr.merged and pr.state == "closed"
          and pr.closed_at and pr.closed_at >= since):
        prs.append(pr)       # closed-without-merge ("rejected") PR
```

This uses `state="all"` (not just `state="closed"`), sorted by `updated_at` descending.
The early-exit break at `pr.updated_at < since` is what limits how far back GitHub pages.

The public caller is `enrich_repository_with_prs()` (line 98), which is itself called by:

**File:** `src/gitflow_analytics/integrations/orchestrator.py` line 303
```python
prs = github_integration.enrich_repository_with_prs(
    repo_config.github_repo, commits, since
)
```

---

## 2. The `since` Date-Range Parameter — How Far Back It Looks

### Where `since` originates

The `since` datetime is always derived from `--weeks N` (default 12) and is resolved
via `calculate_date_range()`:

**File:** `src/gitflow_analytics/core/analyze_pipeline.py` lines 210–219
```python
def calculate_date_range(weeks: int) -> DateRangeResult:
    current_time = datetime.now(timezone.utc)
    current_week_start = get_week_start(current_time)
    last_complete_week_start = current_week_start - timedelta(weeks=1)
    start_date = last_complete_week_start - timedelta(weeks=weeks - 1)
    end_date = get_week_end(last_complete_week_start + timedelta(days=6))
    return DateRangeResult(start_date=start_date, end_date=end_date)
```

`start_date` is then passed as `since` to `orchestrator.enrich_repository_data()` at line 385–386:
```python
enrichment = orchestrator.enrich_repository_data(
    repo_config, commits_for_enrichment, start_date   # <-- this is `since`
)
```

### The incremental fetch layer inside GitHub integration

Before calling the GitHub API, `enrich_repository_with_prs()` runs a schema-version
check to potentially widen or advance the `since` date:

**File:** `src/gitflow_analytics/integrations/github_integration.py` lines 63–96 (`_get_incremental_fetch_date`)

- If this is the first ever fetch → use `since` as-is.
- If the schema config changed → re-fetch from `since`.
- If a previous fetch happened → use `max(last_processed_date, since)` to avoid
  re-fetching already-seen data. **This means short `--weeks` values on repeat runs
  do NOT re-fetch PRs that were already retrieved on a longer previous run.**

**Key implication for backfill:** If `since` is set to a date far in the past, but
`last_processed` is already ahead of it, the incremental layer will skip the backfill.
A `--backfill-since` flag must bypass or reset the `last_processed` marker.

The schema version state lives in:
**File:** `src/gitflow_analytics/core/schema_version.py` (the `create_schema_manager` helper)
Calling `schema_manager.has_schema_changed("github", config)` returns True when the
config dict differs from the stored fingerprint, triggering a full re-fetch.

---

## 3. How `pull_request_cache` Is Populated — Insert/Upsert Logic

### Database model

**File:** `src/gitflow_analytics/models/database_metrics_models.py` lines 20–102

Table: `pull_request_cache`
Key columns: `(repo_path, pr_number)` — unique index `idx_repo_pr`

```
id, repo_path, pr_number, title, description, author,
created_at, merged_at, story_points, labels (JSON), commit_hashes (JSON),
pr_state, closed_at, is_merged,                    -- v4.0
review_comments_count, pr_comments_count,           -- v3.0
approvals_count, change_requests_count,
reviewers (JSON), approved_by (JSON),
time_to_first_review_hours, revision_count,
changed_files, additions, deletions,
cached_at
```

### Upsert logic

**File:** `src/gitflow_analytics/core/cache_commits.py` `cache_pr()` lines 339–428

The pattern is: SELECT → UPDATE or INSERT (not SQLite's native `INSERT OR REPLACE`).

```python
existing = session.query(PullRequestCache).filter(
    PullRequestCache.repo_path == repo_path,
    PullRequestCache.pr_number == pr_data["number"],
).first()

if existing:
    # UPDATE — field-by-field, only overwriting when key present in pr_data dict
    existing.title = pr_data.get("title")
    # ... (all core fields are always updated)
    # v4.0 state fields: only overwritten if key exists in payload
    if "pr_state" in pr_data:
        existing.pr_state = pr_data.get("pr_state")
    # ... same pattern for closed_at, is_merged, v3.0 fields
    existing.cached_at = datetime.now(timezone.utc)
else:
    # INSERT new row with all fields populated
    session.add(PullRequestCache(...))
```

**Important for backfill:** The upsert is keyed on `(repo_path, pr_number)`.
Re-fetching a PR that already exists in the cache will UPDATE its row (refreshing
`cached_at` and all fields), not duplicate it. This means backfill is safe to run
over already-cached PRs.

### Bulk path

`_cache_prs_bulk()` (line 381–396) just loops `cache_pr()` — no true bulk SQL.
`_cache_prs_bulk` is called from `enrich_repository_with_prs()` lines 155–157.

---

## 4. How `weekly_pr_metrics` Rollup Is Generated

**File:** `src/gitflow_analytics/cli_pr_metrics.py`

### Command: `gfa pr-metrics`

The rollup is NOT generated automatically during `analyze` or `fetch`.
It is an independent command registered via `register_pr_metrics_commands()`.

### Data flow

1. `calculate_week_range(week, since)` → list of `(iso_week_label, week_start, week_end)` tuples
2. For each week: `aggregate_week(db, iso_week, week_start, week_end)` queries `pull_request_cache`
3. `upsert_weekly_metrics(db, iso_week, aggregates)` writes to `weekly_pr_metrics`

### `aggregate_week()` logic (lines 157–246)

**prs_opened** — `pull_request_cache.created_at` BETWEEN `week_start` and `week_end`, grouped by `author`

**prs_merged** — `pull_request_cache.merged_at` IS NOT NULL AND BETWEEN `week_start` and `week_end`,
filtered by `is_merged` truthy, grouped by `author`

**pr_reviews_given** — for each PR opened in the week, each login in `reviewers` JSON list gets +1

**pr_comments_given** — same as `pr_reviews_given` (reviewer list is used as proxy; no per-reviewer comment counts stored)

### `upsert_weekly_metrics()` logic (lines 270–313)

Uses `session.merge()` which does SELECT-then-INSERT-or-UPDATE based on the composite PK
`(engineer_identifier, iso_week)`. Re-running the same week is idempotent.

### `weekly_pr_metrics` schema

**File:** `src/gitflow_analytics/models/database_commit_models.py` lines 524–560

```
engineer_identifier TEXT  -- PK part 1 (GitHub login)
iso_week TEXT             -- PK part 2 (e.g. '2026-W16')
prs_opened INTEGER
prs_merged INTEGER
pr_comments_given INTEGER
pr_reviews_given INTEGER
computed_at DATETIME
```

**Schema creation:** v11.0 migration in `database.py` `_migrate_weekly_pr_metrics_v11()` lines 1091–1147.
Table is created IF NOT EXISTS — additive only.

---

## 5. Existing CLI Commands and Flags

### Entry point

`pyproject.toml` scripts:
```
gitflow-analytics = "gitflow_analytics.cli:main"
gfa = "gitflow_analytics.cli:main"
```

### Top-level command group: `cli.py`

Default subcommand when flags like `-c` / `--weeks` are passed: `analyze`

### Registered commands

| Command | File | Key flags |
|---|---|---|
| `analyze` | `cli_analysis.py` | `--weeks INT` (default 12), `--config`, `--clear-cache`, `--force-fetch`, `--backfill-ai-detection` |
| `fetch` | `cli_fetch.py` | `--weeks INT` (default 4), `--config`, `--clear-cache` |
| `collect` | `cli_pipeline_commands.py` | separate stage |
| `classify` | `cli_pipeline_commands.py` | separate stage |
| `report` | `cli_pipeline_commands.py` | separate stage |
| `pr-metrics` | `cli_pr_metrics.py` | `--week YYYY-WNN`, `--since YYYY-MM-DD`, `--config` |
| `aliases` | `cli_identity.py` | |
| `identities` | `cli_identity.py` | |
| `install` | `cli_setup.py` | |
| `run` | `cli_setup.py` | |
| `train` | `cli_training.py` | |

### Existing `--since`-style flags

Only `gfa pr-metrics` has a `--since YYYY-MM-DD` flag today (for the
`weekly_pr_metrics` rollup, not for GitHub API fetching).

The `gfa analyze` command has `--backfill-ai-detection` as a precedent for a one-shot
backfill mode flag (lines 137–143 in `cli_analysis.py`).

---

## 6. Existing `analysis_period` / `date_range` Concepts That Can Be Extended

### `calculate_date_range()` in `analyze_pipeline.py`

**File:** `src/gitflow_analytics/core/analyze_pipeline.py` lines 210–219

Returns a `DateRangeResult(start_date, end_date)` dataclass (line 40 in the same file).
This is where `--backfill-since` should hook in: bypass the `weeks`-based calculation
and substitute an explicit `start_date`.

### `fetch_repository_data()` in `data_fetcher.py`

**File:** `src/gitflow_analytics/core/data_fetcher.py` lines 120–131

Already accepts explicit `start_date` and `end_date` parameters.
These override `weeks_back` when both are provided (lines 164–168).

### `enrich_repository_with_prs()` in `github_integration.py`

**File:** `src/gitflow_analytics/integrations/github_integration.py` line 98

Signature: `enrich_repository_with_prs(repo_name, commits, since: datetime)`
The `since` datetime is threaded through `_get_incremental_fetch_date()` and then
`_get_pull_requests()`.

**To support true backfill** (ignoring the incremental-fetch last-processed date),
`_get_incremental_fetch_date()` would need a `force=True` or `backfill=True` bypass,
or the schema_manager's last-processed date must be cleared for the "github" component.

### `WeeklyFetchStatus` in git commit caching

**File:** `src/gitflow_analytics/models/database_commit_models.py` lines 482–521

The `WeeklyFetchStatus` table records which Monday-aligned week windows have been
fetched for git commits. The `--force-fetch` flag clears this via
`cache.clear_weekly_cache(repo_path=...)` — the same mechanism can be used for backfill
by clearing only weeks older than a given date.

---

## Implementation Blueprint: `--backfill-since` Flag

### Recommended approach

Add `--backfill-since DATE` to `gfa fetch` (and optionally `gfa analyze`):

1. **Parse the flag** in `cli_fetch.py` alongside `--weeks`.
   - Mutually exclusive with `--weeks`.
   - Format: `YYYY-MM-DD`.

2. **Override `start_date`** in the `fetch_repository_data()` call (already accepts it).
   The `weeks_back` parameter can be computed from the date span or set to 0.

3. **Reset the incremental fetch gate** for GitHub PRs:
   - Either call `schema_manager.clear_last_processed("github")` (if that method
     exists or is added to `schema_version.py`), or
   - Pass a `force=True` flag into `enrich_repository_with_prs()` → `_get_incremental_fetch_date()`.
   Without this step, `_get_incremental_fetch_date()` will advance `since` to
   `last_processed` and skip all the historical PRs.

4. **Clear `WeeklyFetchStatus`** entries older than the backfill date so git commits
   are also re-fetched for those weeks. Use `cache.clear_weekly_cache(repo_path, before=since_date)`.

5. **`pr-metrics` rollup** — after the backfill fetch, run `gfa pr-metrics --since DATE`
   to populate `weekly_pr_metrics` for the new historical data.

### Minimal surgical change (GitHub PRs only)

If only the PR cache needs to be backfilled without re-fetching git commits:

1. Add `--backfill-prs-since DATE` to `gfa fetch`.
2. Set `fetch_since = since_date` directly in `_get_pull_requests()`, bypassing
   `_get_incremental_fetch_date()`.
3. The `cache_pr()` upsert will safely overwrite or insert all retrieved PRs.
4. Run `gfa pr-metrics --since DATE` afterward.

### Key file/line summary for implementation

| What | File | Line(s) |
|---|---|---|
| GitHub API call (`get_pulls`) | `integrations/github_integration.py` | 432 |
| `since` parameter entry to enrichment | `integrations/orchestrator.py` | 385–386 |
| Incremental date guard (must bypass for backfill) | `integrations/github_integration.py` | 63–96 |
| `cache_pr()` upsert | `core/cache_commits.py` | 339–428 |
| Git commit week-level fetch gate | `core/data_fetcher.py` | 176–188 |
| `calculate_date_range()` for override | `core/analyze_pipeline.py` | 210–219 |
| `fetch_repository_data()` explicit start_date | `core/data_fetcher.py` | 120–168 |
| `pr-metrics --since` (existing backfill for rollup) | `cli_pr_metrics.py` | 338–342 |
| `WeeklyPRMetrics` schema | `models/database_commit_models.py` | 524–560 |
| `PullRequestCache` schema | `models/database_metrics_models.py` | 20–102 |

---

## Notes and Gotchas

1. **TTL stale check:** `_is_pr_stale()` (line 398 in `github_integration.py`) uses `cache.ttl_hours`.
   If TTL is set (default 168 hours = 1 week), freshly backfilled historical rows will appear
   "stale" on the next read and trigger a re-fetch. For historical backfill, consider setting
   `ttl_hours=0` during the backfill run.

2. **Rate limits:** `_get_pull_requests()` paginates through ALL PRs updated since `since`,
   then filters. A 2-year backfill on an active repo will consume significant GitHub API quota.
   The retry/backoff logic is at lines 429–457.

3. **`stale_open_pr_refresh_cap`:** After the main fetch, `_refresh_stale_open_prs()` re-fetches
   up to 50 cached "open" PRs per run. A deep backfill will have many open PRs; the cap prevents
   runaway API usage but means some historical open PRs won't be updated in one run.

4. **Schema manager component key:** The incremental tracking key for GitHub PRs is the string
   `"github"` (not `"github_prs"` or similar). See line 116 in `github_integration.py`:
   `fetch_since = self._get_incremental_fetch_date("github", since, github_config)`.

5. **`WeeklyFetchStatus` vs PR fetch status:** The `WeeklyFetchStatus` table tracks git-commit
   fetches only. The GitHub PR incremental state is tracked separately in the schema version
   manager (`core/schema_version.py`). Both need to be reset for a full historical backfill.
