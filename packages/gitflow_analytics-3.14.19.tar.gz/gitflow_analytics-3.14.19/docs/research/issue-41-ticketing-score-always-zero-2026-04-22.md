# Research: Issue #41 — ticketing_score Always 0.0 in developer_activity_summary CSV

**Date:** 2026-04-22
**Issue:** #41 — ticketing_score is always 0.0 in developer_activity_summary.csv
**Root cause category:** Identity key mismatch — canonical UUID used as lookup key against a table keyed by GitHub username or email

---

## 1. What the ticketing_activity_cache stores

**File:** `src/gitflow_analytics/models/database_metrics_models.py`, lines 488–491

```python
# Actor (always lowercased for identity matching)
actor = Column(String)  # lowercased GitHub login / Confluence username
actor_display_name = Column(String)
actor_email = Column(String)
```

The `actor` column holds the **lowercased GitHub login** (e.g. `"bob-duetto"`) or Confluence username. It is NOT the canonical UUID, NOT the primary display name ("Bob Matsuoka"), and NOT the primary email. There is also a separate `actor_email` column populated when available, but it is not used by the scorer at all.

---

## 2. How _load_ticketing_scores builds its lookup dict

**File:** `src/gitflow_analytics/metrics/activity_scoring.py`, lines 124–149

```python
totals: dict[str, float] = {}
with self._cache.get_session() as session:
    rows = (
        session.query(TicketingActivityCache)
        .filter(...)
        .all()
    )
    for row in rows:
        actor = (getattr(row, "actor", None) or "").lower() or "unknown"
        ...
        totals[actor] = totals.get(actor, 0.0) + self.TICKETING_EVENT_WEIGHTS.get(key, 0.0)
```

Keys in `totals` are the lowercased `actor` values from the DB — i.e. GitHub logins like `"bob-duetto"` or Confluence usernames like `"bmatsuoka"`.

---

## 3. Where the lookup fails (exact line)

**File:** `src/gitflow_analytics/metrics/activity_scoring.py`, line 187

```python
return float(scores.get(developer_id.lower(), 0.0))
```

`developer_id` is whatever was passed in. Tracing back through `calculate_activity_score`:

**Lines 232–236:**
```python
dev_id = (
    metrics.get("developer_id")
    or metrics.get("canonical_id")
    or metrics.get("primary_email")
)
```

**File:** `src/gitflow_analytics/reports/csv_reports_developer.py`, lines 191–197

```python
for dev_id, metrics in developer_metrics.items():
    metrics["unique_tickets"] = len(metrics["unique_tickets"])
    activity_result = self.activity_scorer.calculate_activity_score(metrics)
```

The `metrics` dict (built from lines 51–93) is a `defaultdict` whose key is `dev_id`, which comes from line 72:

```python
dev_id = commit.get("canonical_id", commit.get("author_email", "unknown"))
```

`canonical_id` is the UUID-based primary key in `developer_identities` (e.g. `"a3f2…"`). **No `developer_id`, `canonical_id`, or `primary_email` key is set inside the metrics dict itself** before `calculate_activity_score` is called — the outer `dev_id` loop variable is never inserted into the `metrics` dict.

This means:
- `metrics.get("developer_id")` → `None` (not in dict)
- `metrics.get("canonical_id")` → `None` (not in dict)
- `metrics.get("primary_email")` → `None` (not in dict)

So `dev_id` inside `calculate_activity_score` is `None`, and `get_ticketing_score(None)` returns `0.0` immediately at line 184:

```python
if not developer_id:
    return 0.0
```

**This is the primary failure point.** Even if `developer_id` were somehow set, it would be the canonical UUID or a display name like `"Bob Matsuoka"`, which still wouldn't match the `actor` column containing `"bob-duetto"`.

---

## 4. The two-layer mismatch

There are two separate problems that both need to be fixed:

| Layer | What exists | What's needed |
|-------|------------|---------------|
| Layer 1: `developer_id` not in `metrics` dict | `metrics` dict never has `developer_id`/`canonical_id`/`primary_email` keys | Must inject `developer_id` (the canonical UUID) into the metrics dict before calling `calculate_activity_score` |
| Layer 2: canonical UUID != actor in ticketing_activity_cache | `totals` is keyed by GitHub login (e.g. `"bob-duetto"`) | Lookup must expand canonical_id → all known GitHub logins and emails, then check each |

---

## 5. Identity resolution methods available

### `DeveloperIdentityResolver` (identity.py + identity_stats.py)

There is **no existing method** that returns all known identifiers (emails, GitHub username) for a given canonical_id. The closest available methods are:

- `resolve_by_github_username(username)` → canonical_id (reverse direction)
- `get_canonical_name(canonical_id)` → display name string
- `get_developer_stats()` → list of dicts, each containing `canonical_id`, `primary_email`, `github_username` — this is the most useful existing method for the fix

### Database structure that enables the fix

`DeveloperIdentity` (database_identity_models.py):
- `canonical_id` — UUID
- `primary_name` — display name (e.g. `"Bob Matsuoka"`)
- `primary_email` — email (e.g. `"bob@example.com"`)
- `github_username` — lowercased GitHub login (e.g. `"bob-duetto"`) — nullable

`DeveloperAlias` (database_identity_models.py):
- `canonical_id` — FK to DeveloperIdentity
- `name` — alias display name
- `email` — alias email (could be a GitHub username used as email, or a second email)

So for a developer, all known identifiers are: `primary_email` + `github_username` from `DeveloperIdentity`, plus every `email` from all `DeveloperAlias` rows with matching `canonical_id`.

---

## 6. Minimal fix

### Fix 1: Inject `developer_id` into the metrics dict (csv_reports_developer.py)

At line 191 of `csv_reports_developer.py`, inject the `dev_id` key before calling the scorer:

```python
for dev_id, metrics in developer_metrics.items():
    metrics["unique_tickets"] = len(metrics["unique_tickets"])
    metrics["developer_id"] = dev_id          # <-- add this line
    activity_result = self.activity_scorer.calculate_activity_score(metrics)
```

This resolves the `None` developer_id problem, but the canonical UUID still won't match `actor` values in the DB.

### Fix 2: Alias expansion in `_load_ticketing_scores` (activity_scoring.py)

The scorer needs a way to expand a canonical_id to all its known identifiers before doing the lookup. Two options:

**Option A (preferred): Pre-build a reverse mapping in the scorer**

Pass the `identity_resolver` into `ActivityScorer.__init__` and add a helper method `get_identifiers_for_canonical(canonical_id)` to `DeveloperIdentityResolver` that queries:
1. `DeveloperIdentity.primary_email` and `DeveloperIdentity.github_username` where `canonical_id = ?`
2. All `DeveloperAlias.email` rows where `canonical_id = ?`

Then in `_load_ticketing_scores`, also build a secondary dict keyed by canonical_id by checking every actor string against all known aliases. Or better: build the `totals` dict with canonical_id keys during load by resolving each `actor` back to a canonical_id using the identity resolver.

**Option B (simpler, lower coupling): Add `get_identifiers_for_canonical` to `DeveloperIdentityResolver` and call it in `get_ticketing_score`**

Add this method to `DeveloperIdentityResolver` (identity.py):

```python
def get_identifiers_for_canonical(self, canonical_id: str) -> set[str]:
    """Return all lowercased identifiers (emails, github_username) for a canonical_id."""
    result: set[str] = set()
    with self.get_session() as session:
        identity = (
            session.query(DeveloperIdentity)
            .filter(DeveloperIdentity.canonical_id == canonical_id)
            .first()
        )
        if identity:
            if identity.primary_email:
                result.add(identity.primary_email.lower())
            if identity.github_username:
                result.add(identity.github_username.lower())
        aliases = (
            session.query(DeveloperAlias)
            .filter(DeveloperAlias.canonical_id == canonical_id)
            .all()
        )
        for alias in aliases:
            if alias.email:
                result.add(alias.email.lower())
    return result
```

Then pass `identity_resolver` to `ActivityScorer` and update `get_ticketing_score`:

```python
def get_ticketing_score(self, developer_id: Optional[str]) -> float:
    if self.WEIGHTS.get("ticketing", 0.0) <= 0:
        return 0.0
    if not developer_id:
        return 0.0
    scores = self._load_ticketing_scores()
    # Direct hit (legacy path, works when developer_id happens to be an email/login)
    direct = scores.get(developer_id.lower(), None)
    if direct is not None:
        return float(direct)
    # Alias expansion: canonical_id → all known emails + github_username
    if self._identity_resolver is not None:
        identifiers = self._identity_resolver.get_identifiers_for_canonical(developer_id)
        total = 0.0
        for ident in identifiers:
            total += scores.get(ident, 0.0)
        return total
    return 0.0
```

### Recommended approach

Apply both fixes together:
1. In `csv_reports_developer.py` line 192: `metrics["developer_id"] = dev_id` before the scorer call.
2. Add `get_identifiers_for_canonical` to `DeveloperIdentityResolver`.
3. Wire `identity_resolver` into `ActivityScorer` (add optional `identity_resolver` param to `__init__`, store as `self._identity_resolver`).
4. Update `get_ticketing_score` to try alias expansion when direct lookup misses.

### Alternative (no scorer changes, resolve at load time)

A self-contained approach that avoids touching `ActivityScorer` at all: in `_load_ticketing_scores`, after building the `totals` dict keyed by actor, produce a second dict keyed by canonical_id using the identity_resolver:

```python
# After building totals (keyed by github login / email):
if self._identity_resolver:
    canonical_totals: dict[str, float] = {}
    for actor_key, score in totals.items():
        # Try to resolve actor → canonical_id (reuse existing resolve_developer path)
        # This requires a reverse lookup: actor (github login) → canonical_id
        cid = self._identity_resolver.resolve_by_github_username(actor_key)
        if cid:
            canonical_totals[cid] = canonical_totals.get(cid, 0.0) + score
        else:
            # Keep original actor key as fallback for email-based actors
            canonical_totals[actor_key] = canonical_totals.get(actor_key, 0.0) + score
    self._ticketing_cache = canonical_totals
else:
    self._ticketing_cache = totals
```

This resolves at load time once and avoids per-lookup DB queries. The `actor_email` column in `TicketingActivityCache` could also be used as a second lookup when the login-based lookup fails.

---

## 7. Summary table

| Item | Detail |
|------|--------|
| Primary failure line | `activity_scoring.py:187` — `scores.get(developer_id.lower(), 0.0)` returns 0.0 |
| Why developer_id is None | `metrics` dict never has `developer_id`/`canonical_id`/`primary_email` injected before `calculate_activity_score` call at `csv_reports_developer.py:196` |
| Why lookup fails even with a non-None id | `totals` is keyed by GitHub login (from `ticketing_activity_cache.actor`) but developer_id after Fix 1 would be a canonical UUID |
| What `actor` stores | Lowercased GitHub login (e.g. `"bob-duetto"`) or Confluence username |
| Existing bridge method | `resolve_by_github_username(login) -> canonical_id` (wrong direction; need canonical_id -> logins) |
| Missing method | `get_identifiers_for_canonical(canonical_id) -> set[str]` |
| Files to change | `csv_reports_developer.py` (1-line fix); `activity_scoring.py` (alias expansion); `identity.py` (new helper method) |
