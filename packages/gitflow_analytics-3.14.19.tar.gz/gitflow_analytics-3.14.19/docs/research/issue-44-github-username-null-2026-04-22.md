# Issue #44: `github_username` NULL for Most Developers in `identities.db`

**Date:** 2026-04-22
**Scope:** `src/gitflow_analytics/core/identity.py`, `config/schema.py`, `config/aliases.py`, `core/identity_stats.py`, `models/database_identity_models.py`, `core/data_fetcher_git.py`

---

## Summary

Only ~10 of 251 developers have `github_username` populated in `identities.db`. This breaks `resolve_by_github_username()`, which the ticketing score bridge uses to credit PR review/approval activity to the correct developer identity. The root cause is a combination of: (a) the column is only written at identity *creation* time, (b) the only automatic population path has a structural bug, and (c) the config YAML has no `github_username` field that would let operators provide the mapping manually.

---

## 1. Where `github_username` Is Written Today

### (a) `_create_identity()` — only path that writes to DB
`identity.py:594–616`

```python
def _create_identity(self, name: str, email: str, github_username: Optional[str] = None) -> str:
    identity = DeveloperIdentity(
        ...
        github_username=github_username,
        ...
    )
```

This is the **only place** that writes `github_username` to the database. `github_username` arrives from two callers:

| Caller | Passes github_username? |
|--------|------------------------|
| `resolve_developer()` end-of-function (identity not found, create new) | Yes, but only if extracted from noreply email — see (b) |
| `_apply_manual_mappings()` creates `DeveloperIdentity` for new canonical identities | **No** — the field is never passed |

### (b) Noreply auto-detection — structural gap

`identity.py:409–449`

```python
if email.endswith("@users.noreply.github.com") and "+" in email:
    local_part = email.split("@")[0]
    github_username = local_part.split("+", 1)[1]
    # ... tries to find an existing alias or primary identity
    # IF MATCH FOUND: registers alias, returns early — _create_identity() never called
    # IF NO MATCH FOUND: falls through to create new identity (github_username IS set)
```

**The bug:** When a noreply email is seen for the *first time* (no match found), a new identity is created with `github_username` set correctly. But when a match *is* found (the common case — the developer was already in the DB from a corporate email), the code `_add_alias()` and returns early. It **never updates `github_username` on the existing `DeveloperIdentity` record**. So the 241 developers who were first seen via a real email address will never get `github_username` populated from subsequent noreply commits.

### (c) Plain noreply (without `+`) — not detected at all

`identity.py:412` — the guard is `and "+" in email`. The older pattern `username@users.noreply.github.com` (no numeric ID prefix) is silently ignored. The `github_username` local is also not extracted.

### (d) `_apply_manual_mappings()` — silently drops github_username

`identity.py:251–265`

```python
canonical_identity = DeveloperIdentity(
    canonical_id=canonical_id,
    primary_name=preferred_name or ...,
    primary_email=canonical_email,
    first_seen=...,
    last_seen=...,
    total_commits=0,
    total_story_points=0,
)
```

No `github_username` field. The config dict `mapping` is never consulted for a `github_username` key. Even if an operator added `github_username: octocat` to their YAML, it would be silently ignored.

### (e) `update_commit_stats()` and `resolve_developer_identities()` — no github_username path at all

`identity_stats.py:102–207` and `analyze_pipeline.py:613–627`

These are called on every run and process every commit, but `resolve_developer()` is called with only `author_name` and `author_email` — the `github_username` parameter is never passed from the commit dict. Commits have no `github_username` field in the dict built by `_extract_commit_data()` (`data_fetcher_git.py:405–416`).

---

## 2. What Data IS Available to Populate `github_username`

### (a) Noreply email patterns in commit data

Every commit dict has `author_email`. If that email is `{id}+{username}@users.noreply.github.com` or `{username}@users.noreply.github.com`, the GitHub login is embedded and can be extracted at any time.

The extraction for the `{id}+{username}` form already exists at `identity.py:413–414`:
```python
local_part = email.split("@")[0]
github_username = local_part.split("+", 1)[1]
```

For the bare `{username}@users.noreply.github.com` form, the local part IS the username.

### (b) Config YAML `manual_mappings` — no `github_username` field today

The `manual_mappings` entries (both inline and from `aliases.yaml`) are dicts with keys: `primary_email`, `name`, `aliases`, `confidence`, `reasoning`. There is no `github_username` key. Neither `IdentityConfig` (schema.py) nor `DeveloperAlias` (aliases.py) nor `to_manual_mappings()` carry such a field.

The `TeamMemberConfig` dataclass (`schema.py:662–668`) does have a `github` field, but it is used only for team membership resolution (not for identity DB population).

### (c) PR author/reviewer logins

`csv_reports_developer.py:124–126` already receives `pr.get("author")` as a GitHub login and calls `resolve_by_github_username()`. This is the **consumer** of the missing data, not a source.

### (d) `identity_llm/analyzer.py` — extracts but does not persist

`analyzer.py:271–291` extracts usernames from noreply emails for *fuzzy-matching* two identities together, but it never writes `github_username` to the database. The extracted value is used only as a local variable for comparison logic.

---

## 3. Why Only 10/251 Have It

The 10 developers who do have `github_username` are almost certainly developers who:
- Were seen **for the first time** exclusively via a `{id}+{username}@users.noreply.github.com` commit (no prior corporate-email commit in the analysis window), AND
- That first-time commit triggered `_create_identity()` with the extracted `github_username`.

All other developers (241) were first seen via a real email address. When they later committed with a noreply email, the noreply detection early-return path fires — but it only calls `_add_alias()`, never `_update_github_username()` (which doesn't exist).

---

## 4. Minimal Fix — Two Changes

### Fix (a): Update `github_username` on the existing identity when a noreply email is matched

**File:** `src/gitflow_analytics/core/identity.py`

In `resolve_developer()`, after the noreply match block finds an existing identity via alias or primary email, add a `github_username` update before returning:

```python
# After finding username_alias:
if username_alias:
    self._add_alias(username_alias.canonical_id, name, email)
    self._cache[cache_key] = username_alias.canonical_id
    # NEW: persist the github_username if not already set
    self._set_github_username_if_missing(username_alias.canonical_id, github_username)
    return username_alias.canonical_id

# After finding username_identity:
if username_identity:
    self._add_alias(username_identity.canonical_id, name, email)
    self._cache[cache_key] = username_identity.canonical_id
    # NEW: persist the github_username if not already set
    self._set_github_username_if_missing(username_identity.canonical_id, github_username)
    return username_identity.canonical_id
```

New helper method:

```python
def _set_github_username_if_missing(self, canonical_id: str, github_username: str) -> None:
    """Write github_username to the identity record if the column is currently NULL."""
    if not github_username:
        return
    # Update cache
    if canonical_id in self._cache and isinstance(self._cache[canonical_id], dict):
        if not self._cache[canonical_id].get("github_username"):
            self._cache[canonical_id]["github_username"] = github_username.lower()
    with self.get_session() as session:
        identity = (
            session.query(DeveloperIdentity)
            .filter(DeveloperIdentity.canonical_id == canonical_id)
            .first()
        )
        if identity and not identity.github_username:
            identity.github_username = github_username.lower()
```

Also extend the detection to handle bare `{username}@users.noreply.github.com` (no `+`):

```python
# Current guard: endswith(...) and "+" in email
# Proposed:
if email.endswith("@users.noreply.github.com"):
    local_part = email.split("@")[0]
    if "+" in local_part:
        github_username = local_part.split("+", 1)[1]
    else:
        github_username = local_part  # bare username form
```

### Fix (b): Support `github_username` in config YAML `manual_mappings`

**Files:**
- `src/gitflow_analytics/config/aliases.py` — add `github_username` to `DeveloperAlias` dataclass and `to_dict()`/`merge_from_mappings()`
- `src/gitflow_analytics/core/identity.py` — read `mapping.get("github_username")` in `_apply_manual_mappings()` and write it to `DeveloperIdentity`

**`aliases.py` — dataclass change:**
```python
@dataclass
class DeveloperAlias:
    primary_email: str
    aliases: list[str] = field(default_factory=list)
    name: Optional[str] = None
    github_username: Optional[str] = None   # NEW
    confidence: float = 1.0
    reasoning: str = ""
```

**`aliases.py` — `to_dict()` change:**
```python
if self.github_username:
    result["github_username"] = self.github_username
```

**`aliases.py` — `merge_from_mappings()` change:**
```python
alias = DeveloperAlias(
    primary_email=primary_email,
    aliases=mapping.get("aliases", []),
    name=mapping.get("name"),
    github_username=mapping.get("github_username"),   # NEW
    ...
)
```

**`identity.py` — `_apply_manual_mappings()` change:**
At `DeveloperIdentity` creation (`identity.py:254–263`) pass `github_username`:
```python
github_username_from_cfg = mapping.get("github_username", "").lower().strip() or None
canonical_identity = DeveloperIdentity(
    ...
    github_username=github_username_from_cfg,
)
```

Also update existing identities (when the canonical identity already exists):
```python
if preferred_name and preferred_name != canonical_identity.primary_name:
    canonical_identity.primary_name = preferred_name
# NEW:
if github_username_from_cfg and not canonical_identity.github_username:
    canonical_identity.github_username = github_username_from_cfg
```

**Example YAML after the fix:**
```yaml
analysis:
  identity:
    manual_mappings:
      - primary_email: "alice@company.com"
        name: "Alice Smith"
        github_username: "alice-gh"     # NEW field
        aliases:
          - "123456+alice-gh@users.noreply.github.com"
```

---

## 5. Additional Known Leakage Points

| Location | GitHub Login Available | Written to DB? |
|----------|----------------------|----------------|
| `resolve_developer()` noreply early-return (existing identity found) | Yes — extracted locally | **No** — fixed by Fix (a) |
| `resolve_developer()` noreply no-match (new identity created) | Yes | Yes (only correct path today) |
| `_apply_manual_mappings()` identity creation | Only if YAML provides it | **No field** — fixed by Fix (b) |
| `_apply_manual_mappings()` identity update (already exists) | Only if YAML provides it | **No** — fixed by Fix (b) |
| `identity_llm/analyzer.py` noreply detection | Yes (local var) | **Never** — uses only for fuzzy comparison |
| PR/review consumer (`csv_reports_developer.py`) | Yes (pr["author"]) | Not applicable — this is the consumer |

---

## 6. Recommended Implementation Order

1. **Fix (a) — noreply extraction + `_set_github_username_if_missing()`**: highest value, purely additive, no config changes needed. Retroactively populates `github_username` for all developers who have *any* noreply-email commit in the analysis window on the next run.

2. **Fix (b) — config YAML `github_username` field**: needed for developers who never commit via GitHub web UI (no noreply emails), or for backdating/correction. Also enables a one-time migration YAML that operators can populate manually.

3. **Optional (c) — `identity_llm/analyzer.py`**: After the noreply match, persist the extracted username instead of discarding it. Lower priority since Fix (a) covers the same source.

---

*Research saved to: `/Users/masa/Projects/gitflow-analytics/docs/research/issue-44-github-username-null-2026-04-22.md`*
