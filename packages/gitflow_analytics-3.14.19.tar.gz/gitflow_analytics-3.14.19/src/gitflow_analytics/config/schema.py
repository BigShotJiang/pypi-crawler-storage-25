"""Configuration schema definitions and defaults for GitFlow Analytics."""

from dataclasses import dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING, Any, Optional

if TYPE_CHECKING:
    from ..qualitative.models.schemas import QualitativeConfig


@dataclass
class RepositoryConfig:
    """Configuration for a single repository."""

    name: str
    path: Path
    github_repo: Optional[str] = None
    project_key: Optional[str] = None
    branch: Optional[str] = None

    def __post_init__(self) -> None:
        self.path = Path(self.path).expanduser().resolve()
        if not self.project_key:
            self.project_key = self.name.upper().replace("-", "_")


@dataclass
class GitHubConfig:
    """GitHub API configuration."""

    token: Optional[str] = None
    owner: Optional[str] = None
    organization: Optional[str] = None
    base_url: str = "https://api.github.com"
    max_retries: int = 3
    backoff_factor: int = 2
    # WHY: Fetching reviews requires extra API calls per PR (get_reviews +
    # get_issue_comments).  This flag allows existing users to keep their
    # current rate-limit budget unchanged while opting in to richer data.
    fetch_pr_reviews: bool = False

    def get_repo_full_name(self, repo_name: str) -> str:
        """Get full repository name including owner."""
        if "/" in repo_name:
            return repo_name
        if self.owner:
            return f"{self.owner}/{repo_name}"
        raise ValueError(f"Repository {repo_name} needs owner specified")


@dataclass
class MLCategorization:
    """ML-based commit categorization configuration."""

    enabled: bool = True
    min_confidence: float = 0.6
    semantic_weight: float = 0.7
    file_pattern_weight: float = 0.3
    hybrid_threshold: float = 0.5  # Confidence threshold for using ML vs rule-based
    cache_duration_days: int = 30
    batch_size: int = 100
    enable_caching: bool = True
    spacy_model: str = "en_core_web_sm"  # Preferred spaCy model


@dataclass
class LLMClassificationConfig:
    """LLM-based commit classification configuration.

    This configuration enables Large Language Model-based commit classification
    via OpenRouter API or AWS Bedrock for more accurate and context-aware
    categorization.

    WHY: Supporting multiple providers gives users flexibility. OpenRouter is
    convenient for API-key based access; Bedrock is preferable in AWS environments
    where IAM credentials are already configured and billing is consolidated.
    """

    # Enable/disable LLM classification
    enabled: bool = False  # Disabled by default to avoid unexpected API costs

    # Provider selection
    # "auto"       - detect available credentials automatically
    # "openrouter" - use OpenRouter (requires api_key)
    # "bedrock"    - use AWS Bedrock (requires AWS credentials)
    provider: str = "auto"

    # OpenRouter API configuration
    api_key: Optional[str] = None  # Set via environment variable or config
    api_base_url: str = "https://openrouter.ai/api/v1"
    model: str = "mistralai/mistral-7b-instruct"  # Fast, affordable model

    # Alternative models for different use cases:
    # - "meta-llama/llama-3-8b-instruct" (Higher accuracy, slightly more expensive)
    # - "openai/gpt-3.5-turbo" (Good balance, more expensive)

    # AWS Bedrock configuration
    aws_region: Optional[str] = None  # Defaults to AWS_REGION env or us-east-1
    aws_profile: Optional[str] = None  # Named AWS profile (None = default)
    # Claude 3 Haiku on Bedrock: fast, cheap ($0.25/1M in, $1.25/1M out)
    bedrock_model_id: str = "anthropic.claude-3-haiku-20240307-v1:0"

    # Classification parameters
    confidence_threshold: float = 0.7  # Minimum confidence for LLM predictions
    max_tokens: int = 50  # Keep responses short for cost optimization
    temperature: float = 0.1  # Low temperature for consistent results
    timeout_seconds: float = 30.0  # API request timeout

    # Caching configuration (aggressive caching for cost optimization)
    cache_duration_days: int = 90  # Long cache duration
    enable_caching: bool = True

    # Cost and rate limiting
    max_daily_requests: int = 1000  # Daily API request limit

    # Domain-specific terms for better classification accuracy
    domain_terms: dict[str, list[str]] = field(
        default_factory=lambda: {
            "media": [
                "video",
                "audio",
                "streaming",
                "player",
                "media",
                "content",
                "broadcast",
                "live",
                "recording",
                "episode",
                "program",
                "tv",
                "radio",
                "podcast",
                "channel",
                "playlist",
            ],
            "localization": [
                "translation",
                "i18n",
                "l10n",
                "locale",
                "language",
                "spanish",
                "french",
                "german",
                "italian",
                "portuguese",
                "multilingual",
                "translate",
                "localize",
                "regional",
            ],
            "integration": [
                "api",
                "webhook",
                "third-party",
                "external",
                "service",
                "integration",
                "sync",
                "import",
                "export",
                "connector",
                "oauth",
                "auth",
                "authentication",
                "sso",
            ],
            "content": [
                "copy",
                "text",
                "wording",
                "messaging",
                "editorial",
                "article",
                "blog",
                "news",
                "story",
                "caption",
                "title",
                "headline",
                "description",
                "summary",
                "metadata",
            ],
        }
    )

    # Fallback behavior when LLM is unavailable
    fallback_to_rules: bool = True  # Fall back to rule-based classification
    fallback_to_ml: bool = True  # Fall back to existing ML classification


@dataclass
class CommitClassificationConfig:
    """Configuration for commit classification system.

    This configuration controls the Random Forest-based commit classification
    system that analyzes commits to categorize them into types like feature,
    bugfix, refactor, docs, test, etc.
    """

    enabled: bool = True
    confidence_threshold: float = 0.5  # Minimum confidence for reliable predictions
    batch_size: int = 100  # Commits processed per batch
    auto_retrain: bool = True  # Automatically check if model needs retraining
    retrain_threshold_days: int = 30  # Days after which to suggest retraining

    # Model hyperparameters
    model: dict[str, Any] = field(
        default_factory=lambda: {
            "n_estimators": 100,  # Number of trees in random forest
            "max_depth": 20,  # Maximum depth of trees
            "min_samples_split": 5,  # Minimum samples to split a node
            "min_samples_leaf": 2,  # Minimum samples at leaf node
            "random_state": 42,  # For reproducible results
            "n_jobs": -1,  # Use all available CPU cores
        }
    )

    # Feature extraction settings
    feature_extraction: dict[str, Any] = field(
        default_factory=lambda: {
            "enable_temporal_features": True,
            "enable_author_features": True,
            "enable_file_analysis": True,
            "keyword_categories": [
                "feature",
                "bugfix",
                "refactor",
                "docs",
                "test",
                "config",
                "security",
                "performance",
                "ui",
                "api",
                "database",
                "deployment",
            ],
        }
    )

    # Training settings
    training: dict[str, Any] = field(
        default_factory=lambda: {
            "validation_split": 0.2,  # Fraction for validation
            "min_training_samples": 20,  # Minimum samples needed for training
            "cross_validation_folds": 5,  # K-fold cross validation
            "class_weight": "balanced",  # Handle class imbalance
        }
    )

    # Supported classification categories
    categories: dict[str, str] = field(
        default_factory=lambda: {
            "feature": "New functionality or capabilities",
            "bugfix": "Bug fixes and error corrections",
            "refactor": "Code restructuring and optimization",
            "docs": "Documentation changes and updates",
            "test": "Testing-related changes",
            "config": "Configuration and settings changes",
            "chore": "Maintenance and housekeeping tasks",
            "security": "Security-related changes",
            "hotfix": "Emergency production fixes",
            "style": "Code style and formatting changes",
            "build": "Build system and dependency changes",
            "ci": "Continuous integration changes",
            "revert": "Reverts of previous changes",
            "merge": "Merge commits and integration",
            "wip": "Work in progress commits",
        }
    )


@dataclass
class BranchAnalysisConfig:
    """Configuration for branch analysis optimization.

    This configuration controls how branches are analyzed to prevent performance
    issues on large organizations with many repositories and branches.
    """

    # Branch analysis strategy
    strategy: str = "smart"  # Options: "all", "smart", "main_only"

    # Smart analysis parameters
    max_branches_per_repo: int = 50  # Maximum branches to analyze per repository
    active_days_threshold: int = 90  # Days to consider a branch "active"
    include_main_branches: bool = True  # Always include main/master branches

    # Branch name patterns to always include/exclude
    always_include_patterns: list[str] = field(
        default_factory=lambda: [
            r"^(main|master|develop|dev)$",  # Main development branches
            r"^release/.*",  # Release branches
            r"^hotfix/.*",  # Hotfix branches
        ]
    )

    always_exclude_patterns: list[str] = field(
        default_factory=lambda: [
            r"^dependabot/.*",  # Dependabot branches
            r"^renovate/.*",  # Renovate branches
            r".*-backup$",  # Backup branches
            r".*-temp$",  # Temporary branches
        ]
    )

    # Performance limits
    enable_progress_logging: bool = True  # Log branch analysis progress
    branch_commit_limit: int = 1000  # Max commits to analyze per branch


@dataclass
class IdentityConfig:
    """Configuration for developer identity resolution and alias generation.

    WHY: Previously identity settings were scattered as loose fields on
    AnalysisConfig.  Grouping them here makes the YAML structure cleaner
    (``analysis.identity.*``) and allows adding new identity-related settings
    without cluttering the top-level analysis namespace.
    """

    similarity_threshold: float = 0.85
    manual_mappings: list[dict[str, Any]] = field(default_factory=list)
    aliases_file: Optional[Path] = None
    auto_analysis: bool = True

    # Suffixes stripped from email local-parts during heuristic matching.
    # User-configured values are ADDED to the built-in defaults; they do not
    # replace them.  Example YAML:
    #   analysis:
    #     identity:
    #       strip_suffixes:
    #         - "-mycompany"
    #         - "-staging"
    strip_suffixes: list[str] = field(default_factory=list)


@dataclass
class TicketDetectionConfig:
    """Configurable ticket detection settings.

    Controls which commits are scanned for ticket references, how pattern
    matching is anchored, which patterns are used, and which matches to
    exclude post-extraction.

    YAML example::

        analysis:
          ticket_detection:
            commit_filter: "squash_merges_only"
            target_branches: ["develop", "main"]
            position: "start"
            patterns:
              jira: "([A-Z]{2,10}-\\d+)"
              github: "(?:closes|fixes|resolves)\\s+#(\\d+)"
            exclude_patterns:
              - "CVE-\\d+"
              - "CWE-\\d+"
              - "\\d{8,}"
            exclude_repos:
              - "APEX"          # knowledge base — exclude from ticket compliance
            exclude_authors:
              - "Bob Matsuoka"  # CTO — tooling/analysis, different workflow
    """

    # Which commits to scan.
    # "all"               – every commit (current/default behaviour)
    # "squash_merges_only"– only single-parent commits on target_branches
    # "merge_commits"     – only commits with >1 parent
    commit_filter: str = "all"

    # Branches considered as "integration" branches for squash-merge detection.
    target_branches: list[str] = field(default_factory=lambda: ["develop", "main", "master"])

    # Where in the commit message to match ticket patterns.
    # "anywhere" – search the whole message (current behaviour)
    # "start"    – anchor patterns with ^ (match only at message start)
    position: str = "anywhere"

    # Regex patterns keyed by platform name.  These REPLACE the built-in
    # defaults when non-empty; when empty the extractor falls back to its
    # hard-coded patterns.
    patterns: dict[str, str] = field(
        default_factory=lambda: {
            "jira": r"([A-Z]{2,10}-\d+)",
            "github": r"(?:closes|fixes|resolves)\s+#(\d+)",
        }
    )

    # Regex patterns whose matches should be removed after extraction.
    # Any extracted ticket ID that fully matches one of these patterns is
    # discarded (e.g. CVE numbers, date-like strings).
    exclude_patterns: list[str] = field(
        default_factory=lambda: [
            r"CVE-\d+",
            r"CWE-\d+",
            r"\d{8,}",  # long digit strings (dates, IDs)
        ]
    )

    # Repository names to exclude from ticket compliance metrics.
    # Commits from these repos are still included in activity reporting
    # (commit counts, line counts, developer stats) but are excluded from
    # ticket coverage rate calculations.  Useful for knowledge-base or
    # documentation repos where JIRA tickets are not expected.
    exclude_repos: list[str] = field(default_factory=list)

    # Author names to exclude from ticket compliance metrics.
    # Commits from these authors are still included in activity reporting
    # but are excluded from ticket coverage rate calculations.  Useful for
    # CTO/leadership roles doing tooling/analysis work where JIRA tickets
    # are not expected.  Matching is case-insensitive substring against
    # the commit's author_name (so "Bob Matsuoka" matches
    # "Bob Matsuoka via Claude").
    exclude_authors: list[str] = field(default_factory=list)


@dataclass
class AnalysisConfig:
    """Analysis-specific configuration."""

    story_point_patterns: list[str] = field(default_factory=list)
    exclude_authors: list[str] = field(default_factory=list)
    exclude_message_patterns: list[str] = field(default_factory=list)
    exclude_paths: list[str] = field(default_factory=list)
    exclude_merge_commits: bool = False  # Exclude merge commits from filtered line counts
    similarity_threshold: float = 0.85
    manual_identity_mappings: list[dict[str, Any]] = field(default_factory=list)
    aliases_file: Optional[Path] = None  # Path to shared aliases.yaml file
    default_ticket_platform: Optional[str] = None
    branch_mapping_rules: dict[str, list[str]] = field(default_factory=dict)
    ticket_platforms: Optional[list[str]] = None
    ticket_detection: TicketDetectionConfig = field(default_factory=TicketDetectionConfig)
    auto_identity_analysis: bool = True  # Enable automatic identity analysis by default
    branch_patterns: Optional[list[str]] = (
        None  # Branch patterns to analyze (e.g., ["*"] for all branches)
    )
    branch_analysis: BranchAnalysisConfig = field(default_factory=BranchAnalysisConfig)
    ml_categorization: MLCategorization = field(default_factory=MLCategorization)
    commit_classification: CommitClassificationConfig = field(
        default_factory=CommitClassificationConfig
    )
    llm_classification: LLMClassificationConfig = field(default_factory=LLMClassificationConfig)
    security: Optional[dict[str, Any]] = field(default_factory=dict)  # Security configuration
    qualitative: Optional["QualitativeConfig"] = None  # Nested qualitative config support
    # Structured identity sub-config (populated by loader from analysis.identity.*)
    identity: IdentityConfig = field(default_factory=IdentityConfig)


@dataclass
class OutputConfig:
    """Output configuration."""

    directory: Optional[Path] = None
    formats: list[str] = field(default_factory=lambda: ["csv", "markdown"])
    csv_delimiter: str = ","
    csv_encoding: str = "utf-8"
    anonymize_enabled: bool = False
    anonymize_fields: list[str] = field(default_factory=list)
    anonymize_method: str = "hash"


@dataclass
class CacheConfig:
    """Cache configuration."""

    directory: Path = Path(".gitflow-cache")
    ttl_hours: int = 168
    max_size_mb: int = 500


@dataclass
class JIRAConfig:
    """JIRA configuration."""

    access_user: str
    access_token: str
    base_url: Optional[str] = None


@dataclass
class JIRAIntegrationConfig:
    """JIRA integration specific configuration."""

    enabled: bool = True
    fetch_story_points: bool = True
    project_keys: list[str] = field(default_factory=list)
    story_point_fields: list[str] = field(
        default_factory=lambda: ["customfield_10016", "customfield_10021", "Story Points"]
    )


@dataclass
class GitHubIssuesConfig:
    """Configuration for GitHub Issues activity tracking.

    WHY: Tracking issue opens/closes/comments as developer productivity signals
    requires a separate config from the generic GitHub PR config so that users
    can opt in/out and constrain which repos are scanned.
    """

    enabled: bool = False
    fetch_comments: bool = False
    allowed_repos: Optional[list[str]] = None
    issue_state: str = "all"  # 'open' | 'closed' | 'all'
    max_issues_per_repo: int = 500


@dataclass
class ConfluenceConfig:
    """Configuration for Confluence page activity tracking.

    WHY: Confluence is a separate platform from JIRA (even when using the same
    Atlassian instance) and uses page-level activity rather than ticket-level.
    Auth reuses the standard Atlassian username + API token pattern.
    """

    enabled: bool = False
    base_url: str = ""
    username: str = ""
    api_token: str = ""
    spaces: list[str] = field(default_factory=list)
    fetch_page_history: bool = False
    dns_timeout: int = 10
    connection_timeout: int = 30
    max_retries: int = 3
    backoff_factor: float = 1.0


@dataclass
class PMPlatformConfig:
    """Base PM platform configuration."""

    enabled: bool = True
    platform_type: str = ""
    config: dict[str, Any] = field(default_factory=dict)


@dataclass
class PMIntegrationConfig:
    """PM framework integration configuration."""

    enabled: bool = False
    primary_platform: Optional[str] = None
    correlation: dict[str, Any] = field(default_factory=dict)
    platforms: dict[str, PMPlatformConfig] = field(default_factory=dict)


@dataclass
class LauncherPreferences:
    """Interactive launcher preferences."""

    last_selected_repos: list[str] = field(default_factory=list)
    default_weeks: int = 4
    auto_clear_cache: bool = False
    skip_identity_analysis: bool = False
    last_run: Optional[str] = None


@dataclass
class AIDetectionConfig:
    """Configuration for AI tool detection in commit analysis.

    Controls heuristic and pattern-based AI detection on commit messages.
    Phase 1 uses regex patterns and NLP heuristics only (no external LLM calls).
    """

    pattern_matching: bool = True  # existing regex detection (always on)
    nlp_message_scoring: bool = True  # heuristic NLP scoring on message
    confidence_threshold: float = 0.7  # threshold above which we classify as AI


@dataclass
class VelocityConfig:
    """Configuration for the native velocity report."""

    enabled: bool = True
    cycle_time_outlier_min_hrs: float = 0.5
    cycle_time_outlier_max_hrs: float = 720.0  # 30 days
    top_n: int = 5


@dataclass
class ActivityScoringConfig:
    """Configuration for the :class:`ActivityScorer` weighting model.

    WHY: Lets operators tune the balance between code-based activity
    (commits, PRs, code impact, complexity) and ticketing activity
    (GitHub Issues + Confluence + JIRA events stored in
    ``ticketing_activity_cache``).  Defaults preserve the historical
    behaviour while reserving 15% for ticketing blending.

    Weights must sum to ~1.0 (no runtime enforcement — operators can
    intentionally over-weight a single channel).  Setting
    ``ticketing_weight=0.0`` bypasses any ticketing lookups, matching
    the pre-merger behaviour for backward compatibility.
    """

    commits_weight: float = 0.22
    prs_weight: float = 0.26
    code_impact_weight: float = 0.26
    complexity_weight: float = 0.11
    ticketing_weight: float = 0.15


@dataclass
class BoilerplateFilterConfig:
    """Configuration for the boilerplate / bulk-auto-generated-commit filter (Issue #28).

    Developers pushing huge amounts of auto-generated code (Swagger schemas,
    DB migrations, vendored dependencies, generated clients, etc.) can inflate
    velocity metrics with outlier line counts that don't reflect actual
    engineering work.  This filter detects such developers from their per-week
    metrics and optionally flags or excludes them so team averages remain
    meaningful.

    YAML example::

        boilerplate_filter:
          enabled: true
          avg_lines_per_commit_threshold: 500
          total_lines_threshold: 10000
          action: "flag"          # "flag" | "exclude_from_averages" | "exclude"
          flag_label: "boilerplate"

    Action semantics:
      * ``flag`` — developer appears in output with ``boilerplate_flag: true``
        and ``boilerplate_label`` annotation; they remain in team averages.
      * ``exclude_from_averages`` — developer's metrics are kept in per-dev
        output but excluded from team/org average computations.
      * ``exclude`` — developer is omitted from all report output for that week.
    """

    enabled: bool = False
    avg_lines_per_commit_threshold: int = 500
    total_lines_threshold: int = 10000
    # Valid values: "flag", "exclude_from_averages", "exclude"
    action: str = "flag"
    flag_label: str = "boilerplate"


@dataclass
class QualityReportConfig:
    """Configuration for the native quality report (Issue #26).

    Controls which quality signals are computed and emitted to
    quality_summary.json.  All sub-sections default to enabled so
    that a minimal config (``quality_report: {}``) produces a full report.
    """

    enabled: bool = True
    revert_detection_patterns: bool = True  # pattern-match reverts in commit messages
    risk_profile: bool = True  # aggregate risk_level from qualitative_commits
    code_review_signals: bool = True  # revision_count / change_requests from PRs
    quality_score: bool = True  # composite 0–1 score


@dataclass
class TeamMemberConfig:
    """A single member of a team or pod."""

    email: Optional[str] = None
    github: Optional[str] = None  # GitHub username
    name: Optional[str] = None  # Display name match


@dataclass
class PodConfig:
    """A sub-group (pod) within a team."""

    name: str = ""
    members: list[TeamMemberConfig] = field(default_factory=list)


@dataclass
class TeamConfig:
    """A team with optional lead and pods."""

    name: str = ""
    lead: Optional[str] = None
    members: list[TeamMemberConfig] = field(default_factory=list)
    pods: list[PodConfig] = field(default_factory=list)


@dataclass
class TeamsConfig:
    """Top-level teams/pods configuration."""

    teams: list[TeamConfig] = field(default_factory=list)
    enabled: bool = True


@dataclass
class Config:
    """Main configuration container."""

    repositories: list[RepositoryConfig]
    github: GitHubConfig
    analysis: AnalysisConfig
    output: OutputConfig
    cache: CacheConfig
    jira: Optional[JIRAConfig] = None
    jira_integration: Optional[JIRAIntegrationConfig] = None
    pm: Optional[Any] = None  # Modern PM framework config
    pm_integration: Optional[PMIntegrationConfig] = None
    qualitative: Optional["QualitativeConfig"] = None
    velocity: VelocityConfig = field(default_factory=VelocityConfig)
    activity_scoring: ActivityScoringConfig = field(default_factory=ActivityScoringConfig)
    teams: TeamsConfig = field(default_factory=TeamsConfig)
    quality_report: QualityReportConfig = field(default_factory=QualityReportConfig)
    ai_detection: AIDetectionConfig = field(default_factory=AIDetectionConfig)
    boilerplate_filter: BoilerplateFilterConfig = field(default_factory=BoilerplateFilterConfig)
    github_issues: Optional[GitHubIssuesConfig] = None
    confluence: Optional[ConfluenceConfig] = None
    launcher: Optional[LauncherPreferences] = None

    def discover_organization_repositories(
        self, clone_base_path: Optional[Path] = None, progress_callback=None
    ) -> list[RepositoryConfig]:
        """Discover repositories from GitHub organization.

        Args:
            clone_base_path: Base directory where repos should be cloned/found.
                           If None, uses output directory.
            progress_callback: Optional callback function(repo_name, count) for progress updates.

        Returns:
            List of discovered repository configurations.
        """
        if not self.github.organization or not self.github.token:
            return []

        from github import Github  # type: ignore[import-not-found]

        github_client = Github(self.github.token, base_url=self.github.base_url)

        try:
            org = github_client.get_organization(self.github.organization)
            discovered_repos = []

            base_path = clone_base_path or self.output.directory
            if base_path is None:
                raise ValueError("No base path available for repository cloning")

            repo_count = 0
            for repo in org.get_repos():
                repo_count += 1

                # Call progress callback if provided
                if progress_callback:
                    progress_callback(repo.name, repo_count)

                # Skip archived repositories
                if repo.archived:
                    continue

                # Create repository configuration
                repo_path = base_path / repo.name
                repo_config = RepositoryConfig(
                    name=repo.name,
                    path=repo_path,
                    github_repo=repo.full_name,
                    project_key=repo.name.upper().replace("-", "_"),
                    branch=repo.default_branch,
                )
                discovered_repos.append(repo_config)

            return discovered_repos

        except Exception as e:
            raise ValueError(
                f"Failed to discover repositories from organization {self.github.organization}: {e}"
            ) from e

    def get_effective_ticket_platforms(self) -> list[str]:
        """Get the effective list of ticket platforms to extract.

        If ticket_platforms is explicitly configured in analysis config, use that.
        Otherwise, infer from which PM platforms are actually configured.

        Returns:
            List of ticket platform names to extract (e.g., ['jira', 'github'])
        """
        # If explicitly configured, use that
        if self.analysis.ticket_platforms is not None:
            return self.analysis.ticket_platforms

        # Otherwise, infer from configured PM platforms
        platforms = []

        # Check modern PM framework config
        if self.pm:
            if hasattr(self.pm, "jira") and self.pm.jira:
                platforms.append("jira")
            if hasattr(self.pm, "linear") and self.pm.linear:
                platforms.append("linear")
            if hasattr(self.pm, "clickup") and self.pm.clickup:
                platforms.append("clickup")

        # Check legacy JIRA config
        if (self.jira or self.jira_integration) and "jira" not in platforms:
            platforms.append("jira")

        # Always include GitHub if we have GitHub configured (for issue tracking)
        if self.github.token:
            platforms.append("github")

        # If nothing configured, fall back to common platforms
        if not platforms:
            platforms = ["jira", "github", "clickup", "linear"]

        return platforms
