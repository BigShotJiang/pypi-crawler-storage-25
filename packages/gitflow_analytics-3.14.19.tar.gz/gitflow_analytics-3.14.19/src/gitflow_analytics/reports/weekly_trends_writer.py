"""Weekly classification trends CSV report generation."""

import logging
from collections import Counter, defaultdict
from datetime import date, datetime, timedelta
from pathlib import Path
from typing import Any, Callable, Optional

import pandas as pd

from gitflow_analytics.core.churn_calculator import calculate_churn_rate_14d
from gitflow_analytics.utils.ai_detection import detect_ai_tool

logger = logging.getLogger(__name__)


class WeeklyTrendsWriter:
    """Generate weekly classification trends CSV reports.

    WHY: Week-over-week classification trends provide insights into changing
    development patterns, helping identify evolving team practices, seasonal
    patterns, and the impact of process changes on development work types.

    DESIGN DECISION: Generate separate developer and project trend reports
    to allow analysis at different granularities. Include percentage changes
    to highlight velocity and pattern shifts.
    """

    def __init__(self) -> None:
        """Initialize weekly trends writer."""
        # Full category list matching all possible return values of categorize_commit()
        self.classification_categories = [
            "feature",
            "bug_fix",
            "refactor",
            "documentation",
            "maintenance",
            "test",
            "style",
            "build",
            "chore",
            "infrastructure",
            "configuration",
            "wip",
            "version",
            "ui",
            "content",
            "deployment",
            "performance",
            "security",
            "integration",
            "other",
        ]

    @staticmethod
    def _get_week_start(dt: Any) -> date:
        """Return Monday 00:00:00 of the calendar week containing *dt*.

        Bug 4 fix: previously commits were bucketed using a floating 7-day
        window anchored to the most recent commit date.  That caused week
        boundaries to vary depending on which commit happened to be newest,
        producing non-calendar weeks that don't align with Monday-to-Sunday
        ISO boundaries used everywhere else.

        Args:
            dt: A datetime object or a date object.

        Returns:
            The date of the Monday that begins the ISO week containing dt.
        """
        if isinstance(dt, datetime):
            dt = dt.date()
        # weekday() returns 0 for Monday, 6 for Sunday
        return dt - timedelta(days=dt.weekday())

    def generate_weekly_trends_reports(
        self,
        commits: list[dict[str, Any]],
        output_dir: Path,
        weeks: int = 12,
        date_suffix: str = "",
        categorize_fn: Optional[Callable[[str], str]] = None,
    ) -> dict[str, Path]:
        """Generate both developer and project weekly trends reports.

        WHY: Providing both perspectives allows analysis of individual developer
        patterns as well as project-level trend analysis. This enables both
        personal development tracking and project health monitoring.

        Args:
            commits: List of commit data with classifications and timestamps
            output_dir: Directory to write CSV reports to
            weeks: Number of weeks to analyze (for validation)
            date_suffix: Date suffix for output filenames
            categorize_fn: Optional callable that takes a commit message string and
                returns a category string. Used when commits lack pre-computed
                classification fields (e.g. when loaded from the database cache).

        Returns:
            Dictionary mapping report type to output file paths
        """
        output_paths = {}

        # Generate developer trends report
        developer_trends_path = output_dir / f"developer_weekly_trends{date_suffix}.csv"
        self._generate_developer_weekly_trends(
            commits, developer_trends_path, weeks, categorize_fn=categorize_fn
        )
        output_paths["developer_trends"] = developer_trends_path

        # Generate project trends report
        project_trends_path = output_dir / f"project_weekly_trends{date_suffix}.csv"
        self._generate_project_weekly_trends(
            commits, project_trends_path, weeks, categorize_fn=categorize_fn
        )
        output_paths["project_trends"] = project_trends_path

        logger.info(f"Generated weekly trends reports: {len(output_paths)} files")
        return output_paths

    def _generate_developer_weekly_trends(
        self,
        commits: list[dict[str, Any]],
        output_path: Path,
        weeks: int,
        categorize_fn: Optional[Callable[[str], str]] = None,
    ) -> None:
        """Generate developer weekly classification trends CSV.

        WHY: Developer-level trends help identify individual development patterns,
        skill progression, and changing work focus over time. This enables
        targeted coaching and recognition of evolving expertise.

        Args:
            commits: List of commit data with developer and classification info
            output_path: Path to write the CSV file
            weeks: Number of weeks for trend analysis
            categorize_fn: Optional callable to classify a commit message at report
                time. Used when commit dicts lack pre-computed classification fields.
        """
        # Group commits by developer and week
        developer_weeks = defaultdict(lambda: defaultdict(lambda: defaultdict(int)))

        # Find the date range for analysis
        if not commits:
            logger.warning("No commits provided for developer weekly trends analysis")
            self._write_empty_developer_trends_csv(output_path)
            return

        # Sort commits by timestamp for consistent week calculation
        sorted_commits = sorted(
            [c for c in commits if c.get("timestamp")],
            key=lambda x: x["timestamp"],
            reverse=True,  # Most recent first
        )

        if not sorted_commits:
            logger.warning("No commits with timestamps for developer weekly trends analysis")
            self._write_empty_developer_trends_csv(output_path)
            return

        # Bug 4 fix: Determine the analysis window using Monday-anchored calendar
        # weeks instead of a floating 7-day window relative to the newest commit.
        # A floating window produced non-calendar week boundaries that shifted with
        # every new commit and never aligned with Monday-to-Sunday ISO weeks.
        latest_timestamp = sorted_commits[0]["timestamp"]
        if hasattr(latest_timestamp, "date"):
            latest_date_obj = latest_timestamp.date()
        else:
            latest_date_obj = latest_timestamp

        # The most recent ISO week containing any commit is the reference point.
        # Weeks are keyed by their Monday date to ensure stable, calendar-aligned keys.
        latest_week_start = self._get_week_start(latest_date_obj)

        # Build a daily_metrics-compatible list from commits for churn calculation.
        # Each entry has developer_id, date, lines_added, lines_deleted so we can
        # reuse calculate_churn_rate_14d() without a separate DB query.
        commit_daily_metrics: list[dict[str, Any]] = []
        for commit in sorted_commits:
            ts = commit.get("timestamp")
            if not ts:
                continue
            commit_date_obj: date = ts.date() if hasattr(ts, "date") else ts
            developer = (
                commit.get("canonical_id")
                or commit.get("author_email")
                or commit.get("author_name", "Unknown")
            )
            lines_added = int(commit.get("filtered_insertions", commit.get("insertions", 0)) or 0)
            lines_deleted = int(commit.get("filtered_deletions", commit.get("deletions", 0)) or 0)
            commit_daily_metrics.append(
                {
                    "developer_id": developer,
                    "date": commit_date_obj,
                    "lines_added": lines_added,
                    "lines_deleted": lines_deleted,
                }
            )

        # Track AI data per developer per week:
        # developer_ai_weeks[developer][week_num] = {"assisted": int, "tools": Counter}
        developer_ai_weeks: dict[str, dict[int, dict[str, Any]]] = defaultdict(
            lambda: defaultdict(lambda: {"assisted": 0, "tools": Counter()})
        )

        # Group commits by developer, week (Monday date key), and classification
        for commit in sorted_commits:
            timestamp = commit.get("timestamp")
            if not timestamp:
                continue

            commit_date = timestamp.date() if hasattr(timestamp, "date") else timestamp

            # Map each commit to its Monday-anchored ISO week start date
            commit_week_start = self._get_week_start(commit_date)

            # Compute how many full weeks back this week is from the reference week
            week_num = (latest_week_start - commit_week_start).days // 7

            # Only include commits within the requested analysis period
            if week_num >= weeks:
                continue

            # Extract developer info
            developer = (
                commit.get("canonical_id")
                or commit.get("author_email")
                or commit.get("author_name", "Unknown")
            )

            # Get classification - try multiple possible fields, fall back to categorize_fn
            classification = self._get_commit_classification(commit, categorize_fn)

            # Key by (week_num, week_start_date) so we can recover the date later
            developer_weeks[developer][week_num][classification] += 1

            # Track AI tool usage for this developer-week
            tool = detect_ai_tool(commit.get("message", ""))
            if tool:
                developer_ai_weeks[developer][week_num]["assisted"] += 1
                tool_key = tool if tool != "mixed" else "mixed"
                developer_ai_weeks[developer][week_num]["tools"][tool_key] += 1

        # Build a mapping from week_num → Monday date for display
        week_num_to_date: dict[int, date] = {
            n: latest_week_start - timedelta(weeks=n) for n in range(weeks)
        }

        # Build DataFrame
        rows = []
        for developer, weeks_data in developer_weeks.items():
            # Sort weeks in chronological order (oldest first → smallest week_num is newest)
            sorted_weeks = sorted(weeks_data.keys())

            for i, week_num in enumerate(sorted_weeks):
                week_data = weeks_data[week_num]

                # Use the Monday date for this bucket (calendar-aligned)
                week_start = week_num_to_date.get(
                    week_num, latest_week_start - timedelta(weeks=week_num)
                )

                # Base row data
                row = {
                    "week_start": week_start.strftime("%Y-%m-%d"),
                    "developer": developer,
                    "week_number": week_num,
                }

                # Add counts for each classification category
                total_commits = sum(week_data.values())
                row["total_commits"] = total_commits

                for category in self.classification_categories:
                    count = week_data.get(category, 0)
                    row[f"{category}_count"] = count

                    # Calculate percentage change from previous week
                    if i < len(sorted_weeks) - 1:  # Not the oldest week
                        prev_week_num = sorted_weeks[i + 1]
                        prev_week_data = weeks_data[prev_week_num]
                        prev_count = prev_week_data.get(category, 0)

                        if prev_count > 0:
                            pct_change = ((count - prev_count) / prev_count) * 100
                        elif count > 0:
                            pct_change = 100.0  # New activity
                        else:
                            pct_change = 0.0
                    else:
                        pct_change = 0.0  # No previous data

                    row[f"{category}_pct_change"] = round(pct_change, 1)

                # Add AI adoption columns for this developer-week
                ai_week = developer_ai_weeks.get(developer, {}).get(week_num, {})
                ai_assisted = ai_week.get("assisted", 0)
                row["ai_assisted_commits"] = ai_assisted
                row["ai_assisted_pct"] = (
                    round(ai_assisted / total_commits * 100, 1) if total_commits > 0 else 0.0
                )
                tools_counter: Counter = ai_week.get("tools", Counter())
                row["primary_ai_tool"] = tools_counter.most_common(1)[0][0] if tools_counter else ""

                # 14-day churn rate: fraction of this week's lines deleted in the next 14 days
                row["churn_rate_14d"] = round(
                    calculate_churn_rate_14d(developer, week_start, commit_daily_metrics), 4
                )

                rows.append(row)

        # Create DataFrame and sort by developer and week
        df = pd.DataFrame(rows)
        if not df.empty:
            df = df.sort_values(["developer", "week_number"])

        # Write to CSV
        df.to_csv(output_path, index=False)
        logger.info(f"Generated developer weekly trends CSV: {output_path} ({len(df)} rows)")

    def _generate_project_weekly_trends(
        self,
        commits: list[dict[str, Any]],
        output_path: Path,
        weeks: int,
        categorize_fn: Optional[Callable[[str], str]] = None,
    ) -> None:
        """Generate project weekly classification trends CSV.

        WHY: Project-level trends reveal changing development patterns within
        specific codebases, helping identify technical debt accumulation,
        feature development cycles, and maintenance patterns.

        Args:
            commits: List of commit data with project and classification info
            output_path: Path to write the CSV file
            weeks: Number of weeks for trend analysis
            categorize_fn: Optional callable to classify a commit message at report
                time. Used when commit dicts lack pre-computed classification fields.
        """
        # Group commits by project and week
        project_weeks = defaultdict(lambda: defaultdict(lambda: defaultdict(int)))

        # Find the date range for analysis
        if not commits:
            logger.warning("No commits provided for project weekly trends analysis")
            self._write_empty_project_trends_csv(output_path)
            return

        # Sort commits by timestamp for consistent week calculation
        sorted_commits = sorted(
            [c for c in commits if c.get("timestamp")],
            key=lambda x: x["timestamp"],
            reverse=True,  # Most recent first
        )

        if not sorted_commits:
            logger.warning("No commits with timestamps for project weekly trends analysis")
            self._write_empty_project_trends_csv(output_path)
            return

        # Bug 4 fix: use Monday-anchored calendar weeks (same fix as developer trends).
        latest_timestamp = sorted_commits[0]["timestamp"]
        if hasattr(latest_timestamp, "date"):
            latest_date_obj = latest_timestamp.date()
        else:
            latest_date_obj = latest_timestamp

        latest_week_start = self._get_week_start(latest_date_obj)

        # Build a daily_metrics-compatible list keyed by project for churn calculation.
        # developer_id is set to project so calculate_churn_rate_14d() can filter by it.
        project_daily_metrics: list[dict[str, Any]] = []
        for commit in sorted_commits:
            ts = commit.get("timestamp")
            if not ts:
                continue
            commit_date_obj_p: date = ts.date() if hasattr(ts, "date") else ts
            project_key_p = commit.get("project_key", "UNKNOWN")
            lines_added_p = int(commit.get("filtered_insertions", commit.get("insertions", 0)) or 0)
            lines_deleted_p = int(commit.get("filtered_deletions", commit.get("deletions", 0)) or 0)
            project_daily_metrics.append(
                {
                    "developer_id": project_key_p,  # reuse field for project key
                    "date": commit_date_obj_p,
                    "lines_added": lines_added_p,
                    "lines_deleted": lines_deleted_p,
                }
            )

        # Track AI data per project per week
        project_ai_weeks: dict[str, dict[int, dict[str, Any]]] = defaultdict(
            lambda: defaultdict(lambda: {"assisted": 0, "tools": Counter()})
        )

        # Group commits by project, week (Monday date key), and classification
        for commit in sorted_commits:
            timestamp = commit.get("timestamp")
            if not timestamp:
                continue

            commit_date = timestamp.date() if hasattr(timestamp, "date") else timestamp

            commit_week_start = self._get_week_start(commit_date)
            week_num = (latest_week_start - commit_week_start).days // 7

            if week_num >= weeks:
                continue

            # Extract project info
            project = commit.get("project_key", "UNKNOWN")

            # Get classification - try multiple possible fields, fall back to categorize_fn
            classification = self._get_commit_classification(commit, categorize_fn)

            project_weeks[project][week_num][classification] += 1

            # Track AI tool usage for this project-week
            tool = detect_ai_tool(commit.get("message", ""))
            if tool:
                project_ai_weeks[project][week_num]["assisted"] += 1
                tool_key = tool if tool != "mixed" else "mixed"
                project_ai_weeks[project][week_num]["tools"][tool_key] += 1

        # Build a mapping from week_num → Monday date for display
        week_num_to_date: dict[int, date] = {
            n: latest_week_start - timedelta(weeks=n) for n in range(weeks)
        }

        # Build DataFrame
        rows = []
        for project, weeks_data in project_weeks.items():
            sorted_weeks = sorted(weeks_data.keys())

            for i, week_num in enumerate(sorted_weeks):
                week_data = weeks_data[week_num]

                # Use the Monday date for this bucket (calendar-aligned)
                week_start = week_num_to_date.get(
                    week_num, latest_week_start - timedelta(weeks=week_num)
                )

                # Base row data
                row = {
                    "week_start": week_start.strftime("%Y-%m-%d"),
                    "project": project,
                    "week_number": week_num,
                }

                # Add counts for each classification category
                total_commits = sum(week_data.values())
                row["total_commits"] = total_commits

                for category in self.classification_categories:
                    count = week_data.get(category, 0)
                    row[f"{category}_count"] = count

                    # Calculate percentage change from previous week
                    if i < len(sorted_weeks) - 1:  # Not the oldest week
                        prev_week_num = sorted_weeks[i + 1]
                        prev_week_data = weeks_data[prev_week_num]
                        prev_count = prev_week_data.get(category, 0)

                        if prev_count > 0:
                            pct_change = ((count - prev_count) / prev_count) * 100
                        elif count > 0:
                            pct_change = 100.0  # New activity
                        else:
                            pct_change = 0.0
                    else:
                        pct_change = 0.0  # No previous data

                    row[f"{category}_pct_change"] = round(pct_change, 1)

                # Add AI adoption columns for this project-week
                ai_week = project_ai_weeks.get(project, {}).get(week_num, {})
                ai_assisted = ai_week.get("assisted", 0)
                row["ai_assisted_commits"] = ai_assisted
                row["ai_assisted_pct"] = (
                    round(ai_assisted / total_commits * 100, 1) if total_commits > 0 else 0.0
                )
                tools_counter: Counter = ai_week.get("tools", Counter())
                row["primary_ai_tool"] = tools_counter.most_common(1)[0][0] if tools_counter else ""

                # 14-day churn rate for the project-week
                row["churn_rate_14d"] = round(
                    calculate_churn_rate_14d(project, week_start, project_daily_metrics), 4
                )

                rows.append(row)

        # Create DataFrame and sort by project and week
        df = pd.DataFrame(rows)
        if not df.empty:
            df = df.sort_values(["project", "week_number"])

        # Write to CSV
        df.to_csv(output_path, index=False)
        logger.info(f"Generated project weekly trends CSV: {output_path} ({len(df)} rows)")

    def _get_commit_classification(
        self,
        commit: dict[str, Any],
        categorize_fn: Optional[Callable[[str], str]] = None,
    ) -> str:
        """Extract commit classification from commit data.

        WHY: Commits may have classification data in different fields depending
        on the extraction method used (ML vs rule-based vs cached). Commits loaded
        from the database cache typically lack these fields entirely, so a
        categorize_fn fallback is required to classify them at report time,
        matching the approach used by generate_weekly_categorization_report().

        DESIGN DECISION: Priority order for classification sources:
        1. predicted_class (from ML classification)
        2. category (from rule-based classification)
        3. classification (generic field)
        4. categorize_fn(message) if provided (classify at report time)
        5. 'other' (final fallback for truly unclassifiable commits)

        Args:
            commit: Commit data dictionary
            categorize_fn: Optional callable that takes a commit message string
                and returns a category string. Invoked when no pre-computed
                classification field is present on the commit dict.

        Returns:
            Classification category string
        """
        # Try ML classification first
        if commit.get("predicted_class"):
            return commit["predicted_class"]

        # Try rule-based classification
        if commit.get("category"):
            return commit["category"]

        # Try generic classification field
        if "classification" in commit:
            return commit["classification"]

        # Classify at report time using the provided function (matches the pattern
        # used by generate_weekly_categorization_report in csv_writer.py)
        if categorize_fn is not None and callable(categorize_fn):
            message = commit.get("message", "")
            if message:  # Only classify if there's actually a message
                try:
                    result = categorize_fn(message)
                    # Validate result and ensure it's a string
                    if result and isinstance(result, str) and result != "":
                        # Debug: Log first few classifications to help diagnose issues
                        if not hasattr(self, "_debug_logged"):
                            logger.debug(
                                f"Classification debug - message: '{message[:50]}...' -> '{result}'"
                            )
                            self._debug_logged = True
                        return result
                    else:
                        logger.debug(f"Classification function returned invalid result: {result}")
                        return "other"
                except Exception as e:
                    logger.warning(f"Classification function failed for commit message: {e}")
                    return "other"
            else:
                logger.debug("Empty commit message, defaulting to 'other'")
                return "other"
        else:
            if categorize_fn is not None:
                logger.warning("categorize_fn provided but is not callable")
            return "other"

        # Final fallback
        return "other"

    def _write_empty_developer_trends_csv(self, output_path: Path) -> None:
        """Write an empty developer trends CSV with proper headers.

        Args:
            output_path: Path to write the empty CSV file
        """
        columns = ["week_start", "developer", "week_number", "total_commits"]

        # Add count and percentage change columns for each category
        for category in self.classification_categories:
            columns.extend([f"{category}_count", f"{category}_pct_change"])

        # AI adoption columns
        columns.extend(["ai_assisted_commits", "ai_assisted_pct", "primary_ai_tool"])

        # Churn rate column
        columns.append("churn_rate_14d")

        empty_df = pd.DataFrame(columns=columns)
        empty_df.to_csv(output_path, index=False)
        logger.info(f"Generated empty developer weekly trends CSV: {output_path}")

    def _write_empty_project_trends_csv(self, output_path: Path) -> None:
        """Write an empty project trends CSV with proper headers.

        Args:
            output_path: Path to write the empty CSV file
        """
        columns = ["week_start", "project", "week_number", "total_commits"]

        # Add count and percentage change columns for each category
        for category in self.classification_categories:
            columns.extend([f"{category}_count", f"{category}_pct_change"])

        # AI adoption columns
        columns.extend(["ai_assisted_commits", "ai_assisted_pct", "primary_ai_tool"])

        # Churn rate column
        columns.append("churn_rate_14d")

        empty_df = pd.DataFrame(columns=columns)
        empty_df.to_csv(output_path, index=False)
        logger.info(f"Generated empty project weekly trends CSV: {output_path}")
