"""HTTP server deployment using FastAPI."""

import asyncio
import json
from typing import Any, Callable, Type

import uvicorn
from fastapi import FastAPI, HTTPException, Request
from loguru import logger
from mmar_mimpl import init_logger, installed_trace_id
from mmar_utils.utils_inspect import extract_and_validate_obj_methods_metadatas

from mmar_pyhr.pyhr_config import PyhrServerConfig
from mmar_pyhr.pyhr_framework import check_valid_trace_id_in_metadatas


def create_fastapi_app(service: Any) -> FastAPI:
    """
    Create FastAPI application with routes for all service methods.

    Args:
        service: Service implementation object

    Returns:
        Configured FastAPI application
    """
    service_name = service.__class__.__name__
    app = FastAPI(title=f"{service_name} (PYHR Service)")

    # Extract service methods and metadatas
    methods, metadatas = extract_and_validate_obj_methods_metadatas(service)
    check_valid_trace_id_in_metadatas(metadatas)

    # Create routes for each method
    for method_name, method in methods.items():
        metadata = metadatas[method_name]

        # Create endpoint handler (use default arguments to capture loop variables)
        def create_handler(m_name=method_name, m_method=method, m_metadata=metadata):
            async def handler(request: Request):
                # Extract trace_id from header
                trace_id = request.headers.get("X-Trace-ID", "")

                try:
                    # Parse request body (dict with kwargs)
                    # Handle empty string body as empty dict (Swagger generates -d '')
                    body = await request.body()
                    if body == b"":
                        request_data = {}
                    else:
                        request_data = json.loads(body)

                    # Filter kwargs to only include parameters that the method accepts
                    method_param_names = {am.name for am in m_metadata.args_metadata}
                    input_dict = {k: v for k, v in request_data.items() if k in method_param_names}

                    # Convert dict values to tuple for Pydantic validation
                    input_names = [am.name for am in m_metadata.args_metadata]
                    input_values = [input_dict.get(name) for name in input_names]

                    # Serialize and deserialize to get proper Pydantic models
                    args_json = m_metadata.args_adapter.dump_json(input_values)
                    validated_args = m_metadata.args_adapter.validate_json(args_json)

                    # Convert back to kwargs
                    input_kwargs = dict(zip(input_names, validated_args))

                    # Call method with trace_id context
                    with installed_trace_id(trace_id=trace_id):
                        result = m_method(**input_kwargs)

                    # Serialize response using pydantic adapter
                    result_json = m_metadata.result_adapter.dump_json(result)
                    result_validated = m_metadata.result_adapter.validate_json(result_json)

                    return result_validated

                except Exception as e:
                    with installed_trace_id(trace_id=trace_id):
                        logger.exception(f"Failed to process request for {m_name}: {e}")
                    raise HTTPException(status_code=500, detail=str(e))

            return handler

        # Register route
        endpoint_path = f"/api/{method_name}"
        handler = create_handler()
        app.add_api_route(endpoint_path, handler, methods=["POST"])

    # Health check endpoints
    @app.get("/health_check")
    async def health_check():
        return {"status": "ok"}

    @app.get("/health/liveness")
    async def health_liveness():
        return {"status": "alive"}

    @app.get("/health/readiness")
    async def health_readiness():
        return {"status": "ready"}

    return app


async def run_server(app: FastAPI, config: PyhrServerConfig) -> None:
    """
    Run the FastAPI server using uvicorn.

    Args:
        app: FastAPI application
        config: Server configuration
    """
    server_config = uvicorn.Config(
        app,
        host=config.host,
        port=config.port,
        workers=config.max_workers,
        log_level=config.log_level,
    )
    server = uvicorn.Server(server_config)
    await server.serve()


def deploy_pyhr_server(
    config_server: PyhrServerConfig | Callable[[], PyhrServerConfig],
    service: Any | Callable[..., Any] | Type,
    config: Any | Callable[[], Any] | None = None,
    initialize_logger: bool = True,
) -> None:
    """
    Deploy an HTTP server for the given service using FastAPI.

    Args:
        config_server: Server configuration (host, port, workers, logging) or callable returning it
        service: Service implementation, class, or factory
        config: Optional service-specific configuration or callable returning it
        initialize_logger: Whether to initialize logger (default: True)

    Example:
        >>> class UserService:
        ...     def get_user(self, *, user_id: int) -> dict:
        ...         return {"id": user_id, "name": "John"}
        >>> config = PyhrServerConfig(port=8000)
        >>> deploy_pyhr_server(config_server=config, service=UserService())
    """
    # Normalize config_server and config if they are callables
    if callable(config_server):
        config_server = config_server()
    if callable(config):
        config = config()

    # Logging setup
    if initialize_logger:
        # Support both log_level (PyhrServerConfig) and logger.level (service-specific configs)
        log_level = getattr(config_server, 'log_level', None)
        if log_level is None and hasattr(config_server, 'logger'):
            log_level = config_server.logger.level
        if log_level:
            init_logger(log_level)
    else:
        log_level = None
    logger.debug(f"Configs: {repr(config_server)}, {repr(config)}")

    # Instantiate service if it's a class / factory
    if isinstance(service, type) or callable(service):
        try:
            service = service(config)
        except TypeError:
            service = service()

    # Create FastAPI app
    app = create_fastapi_app(service)

    # Get host and port flexibly (support different config structures)
    host = getattr(config_server, 'host', '0.0.0.0')
    port = config_server.port

    # Run server
    logger.info(f"Starting HTTP server on {host}:{port}")

    # Create a minimal config for uvicorn
    # Uvicorn expects lowercase log levels
    uvicorn_log_level = (log_level.lower() if log_level else 'info')
    uvicorn_config = PyhrServerConfig(
        host=host,
        port=port,
        max_workers=getattr(config_server, 'max_workers', 1),
        log_level=uvicorn_log_level
    )
    asyncio.run(run_server(app, uvicorn_config))
