"""Configuration for Pyhr (HTTP) transport."""

from mmar_mimpl import SettingsModel
from pydantic import Field


class PyhrTransportConfig(SettingsModel):
    """
    Client-side configuration for Pyhr (HTTP) transport.

    Used by transport registry for creating client connections.
    """

    timeout: float = Field(
        default=30.0,
        description="Default timeout for requests in seconds",
        ge=0.0,
    )

    retry_attempts: int = Field(
        default=3,
        description="Number of retry attempts for HTTP requests",
        ge=0,
    )


class PyhrServerConfig(SettingsModel):
    """
    Server-side configuration for Pyhr (HTTP) server deployment.

    Used by deploy_pyhr_server() for server setup.
    """

    host: str = Field(
        default="0.0.0.0",
        description="Host to bind the HTTP server",
    )

    port: int = Field(
        default=8000,
        description="Port for HTTP server",
        ge=1,
        le=65535,
    )

    max_workers: int = Field(
        default=1,
        description="Maximum number of worker processes",
        ge=1,
    )

    log_level: str = Field(
        default="info",
        description="Logging level for the server",
    )
