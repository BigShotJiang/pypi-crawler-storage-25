# efs-cli (formerly eepyfileserver-cli)

command line interface for eepyfileserver written in python

## prerequisites

- python 3.10 (3.12+ required)
- [`eepyfileserver`](https://codeberg.org/maxeepy/eepyfileserver) 1.1.0-alpha or later

## install

`pip install efs-cli`

## usage

### log in to an instance

```bash
#login fully (lets you upload and download files)
#password is saved in PLAIN TEXT
efs-cli auth "https://example.com" "password123" 

#login only using the url (lets you download PUBLIC files)
efs-cli auth  "https://example.com"

efs-cli login ...
```

### view version

```bash
efs-cli version
efs-cli ver
```

### list files

```bash
efs-cli list
efs-cli ls
efs-cli files
```

### download a file

```bash
efs-cli download /example.txt /home/maxeepy/Downloads/example.txt
efs-cli get ...
efs-cli d ...
```

### upload a file

```bash
efs-cli upload /home/maxeepy/Downloads/example.txt /example.txt
efs-cli post ...
efs-cli up ...
efs-cli put ...
```

### delete a file

```bash
efs-cli delete /example.txt
efs-cli remove ...
efs-cli rm ...
```

### read a file

```bash
efs-cli read /example.txt
```
