from . import __version__ as version
from efs_wrapper import __version__ as wrapper_version
from efs_wrapper.v1 import EepyFileServer, EepyFileServerPublic
from argparse import ArgumentParser
import os
import json
import sys

CONFIG_PATH = os.path.expanduser("~/.efs-cli_config.json")
if os.path.exists(os.path.expanduser("~/.config/")):
	CONFIG_PATH = os.path.expanduser("~/.config/efs-cli.json")

def get_conf():
	conf = None

	if os.path.exists(CONFIG_PATH):
		with open(CONFIG_PATH, "r") as file:
			conf = json.load(file)

	return conf

def init_api():
	conf = get_conf()
	
	if conf is None:
		print("Please authorize with 'efs-cli auth <base_url> <password>'")
		sys.exit(1)

	base_url = conf.get("base_url")
	password = conf.get("password", None)
	efs = EepyFileServerPublic(base_url) if password is None else EepyFileServer(base_url, password)
	return efs

def auth(base_url, password, **__):
	data = {"base_url": base_url, "password": password}
	with open(CONFIG_PATH, "w") as file:
		json.dump(data, file)
	print("Saved eepyfileserver password and base url in config.json")

def download(from_path, to_path, **__):
	api = init_api()
	file = api.get_file(from_path)
	file.fetch_file().save(to_path)
	print(f"Downloaded {from_path} to {to_path}")

def read(file_path, **__):
	api = init_api()
	file = api.get_file(file_path)
	print(file.fetch_file().load().decode("utf-8"))

def upload(from_path, to_path, **__):
	api = init_api()
	if hasattr(api, "upload_file"):
		with open(from_path, "rb") as file:
			api.upload_file(to_path, file)
		print(f"Uploaded {from_path} to {to_path}")
	else:
		print("Login using 'efs-cli auth <base url> <password>' to upload files")
		sys.exit(1)

def list_files(**__):
	api = init_api()
	print(api.get_filelist())

def remove(file_path, **__):
	api = init_api()
	if hasattr(api, "delete_file"):
		api.delete_file(file_path)
		print(f"Deleted {file_path}")
	else:
		print("Login using 'efs-cli auth <base url> <password>' to delete files")
		return 1

def ver(**__):
	conf = get_conf()
	print(f"efs-cli: {version}")
	print(f"efs-wrapper: {wrapper_version}")
	if conf and conf.get("base_url"):
		api = init_api()
		print(f"EepyFileServer: {api.get_instance_info()['instance']['version']}")

def main():
	parser = ArgumentParser("efs-cli", description="eepyfileserver cli tool for downloading and uploading files")
	subparser = parser.add_subparsers()

	auth_parser = subparser.add_parser("auth", help="authorize to eepyfileserver", aliases=["login"])
	auth_parser.add_argument("base_url", help="the base url of your eepyfileserver instance")
	auth_parser.add_argument("password", nargs="?", help="password to login in your eepyfileserver instance", default=None)
	auth_parser.set_defaults(func=auth)

	download_parser = subparser.add_parser("download", help="download a file", aliases=["get", "d"])
	download_parser.add_argument("from_path", help="the efs path of the file to download")
	download_parser.add_argument("to_path", help="the local path to download the file to")
	download_parser.set_defaults(func=download)

	read_parser = subparser.add_parser("read", help="read a file", aliases=["cat"])
	read_parser.add_argument("file_path", help="the efs path of the file to read")
	read_parser.set_defaults(func=read)

	upload_parser = subparser.add_parser("upload", help="upload a file", aliases=["post", "up", "put"])
	upload_parser.add_argument("from_path", help="the local path of the file to upload")
	upload_parser.add_argument("to_path", help="the efs path to upload the file to")
	upload_parser.set_defaults(func=upload)	

	list_files_parser = subparser.add_parser("list", help="list current files on efs", aliases=["ls", "files"])
	list_files_parser.set_defaults(func=list_files)

	remove_parser = subparser.add_parser("delete", help="delete a file", aliases=["remove", "rm"])
	remove_parser.add_argument("file_path")
	remove_parser.set_defaults(func=remove)

	version_parser = subparser.add_parser("version", help="view efs-cli and dependencies versions", aliases=["ver"])
	version_parser.set_defaults(func=ver)

	args = parser.parse_args()
	args.func(**vars(args))

if __name__ == "__main__":
	main()
