#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "embodik::embodik_core" for configuration "Release"
set_property(TARGET embodik::embodik_core APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(embodik::embodik_core PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libembodik_core.dylib"
  IMPORTED_SONAME_RELEASE "@rpath/libembodik_core.dylib"
  )

list(APPEND _cmake_import_check_targets embodik::embodik_core )
list(APPEND _cmake_import_check_files_for_embodik::embodik_core "${_IMPORT_PREFIX}/lib/libembodik_core.dylib" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
