# SPDX-License-Identifier: AGPL-3.0-or-later
"""CMake analysis pass using tree-sitter-cmake.

This analyzer uses tree-sitter to parse CMakeLists.txt files and extract:
- Project definitions
- Library targets (add_library)
- Executable targets (add_executable)
- Function definitions
- Macro definitions
- Target link dependencies
- Subdirectory includes

If tree-sitter-cmake is not installed, the analyzer
gracefully degrades and returns an empty result.

How It Works
------------
1. Check if tree-sitter-cmake is available
2. If not available, return skipped result (not an error)
3. Two-pass analysis:
   - Pass 1: Parse all files, extract all target/function/macro definitions
   - Pass 2: Resolve target_link_libraries and create edges
4. Create links edges for library dependencies

Why This Design
---------------
- Optional dependency keeps base install lightweight
- Uses tree-sitter-cmake package for grammar
- Two-pass allows cross-file target resolution
- Build-system-specific: targets, functions, macros are first-class
"""
from __future__ import annotations

import hashlib
from pathlib import Path
from typing import TYPE_CHECKING, ClassVar, Iterator, Optional

from hypergumbo_core.discovery import find_files
from hypergumbo_core.ir import AnalysisRun, Edge, PASS_VERSION, Span, Symbol, make_pass_id
from hypergumbo_core.analyze.base import AnalysisResult, TreeSitterAnalyzer, iter_tree, make_symbol_id, node_text
from hypergumbo_core.analyze.registry import register_analyzer

if TYPE_CHECKING:
    import tree_sitter

PASS_ID = make_pass_id("cmake")


def find_cmake_files(repo_root: Path) -> Iterator[Path]:
    """Yield all CMake files in the repository."""
    yield from find_files(repo_root, ["CMakeLists.txt", "*.cmake"])



def _make_edge_id(src: str, dst: str, edge_type: str) -> str:
    """Generate deterministic edge ID."""
    content = f"{edge_type}:{src}:{dst}"
    return f"edge:sha256:{hashlib.sha256(content.encode()).hexdigest()[:16]}"


def _get_command_name(node: "tree_sitter.Node", source: bytes) -> Optional[str]:
    """Extract the command name from a normal_command node."""
    for child in node.children:
        if child.type == "identifier":
            return node_text(child, source).lower()
    return None  # pragma: no cover


def _get_arguments(node: "tree_sitter.Node", source: bytes) -> list[str]:
    """Extract arguments from argument_list in a command."""
    args = []
    for child in node.children:
        if child.type == "argument_list":
            for arg in child.children:
                if arg.type == "argument":
                    args.append(node_text(arg, source))
    return args


def _get_function_name(node: "tree_sitter.Node", source: bytes) -> Optional[str]:
    """Extract function/macro name from function_command or macro_command."""
    for child in node.children:
        if child.type == "argument_list":
            for arg in child.children:
                if arg.type == "argument":
                    return node_text(arg, source)
    return None  # pragma: no cover


def _extract_cmake_signature(node: "tree_sitter.Node", source: bytes) -> Optional[str]:
    """Extract function/macro signature from function_command or macro_command.

    CMake functions are defined as: function(name ARG1 ARG2 ...)
    Returns signature in format: (ARG1, ARG2, ...)
    """
    params: list[str] = []
    found_name = False

    for child in node.children:
        if child.type == "argument_list":
            for arg in child.children:
                if arg.type == "argument":
                    if not found_name:
                        # First argument is the function name, skip it
                        found_name = True
                    else:
                        params.append(node_text(arg, source))

    return f"({', '.join(params)})"


def _process_cmake_tree(
    root_node: "tree_sitter.Node",
    source: bytes,
    rel_path: str,
    symbols: list[Symbol],
    edges: list[Edge],
    target_registry: dict[str, str],
) -> None:
    """Process CMake AST tree to extract symbols and edges.

    Args:
        root_node: Root tree-sitter node to process
        source: Source file bytes
        rel_path: Relative path to file
        symbols: List to append symbols to
        edges: List to append edges to
        target_registry: Registry mapping target names to symbol IDs
    """
    for node in iter_tree(root_node):
        if node.type == "normal_command":
            cmd_name = _get_command_name(node, source)
            args = _get_arguments(node, source)

            if cmd_name == "project" and args:
                # Project definition
                project_name = args[0]
                start_line = node.start_point[0] + 1
                end_line = node.end_point[0] + 1
                symbol_id = make_symbol_id("cmake", rel_path, start_line, end_line, project_name, "project")

                sym = Symbol(
                    id=symbol_id,
                    stable_id=None,
                    shape_id=None,
                    canonical_name=project_name,
                    fingerprint=hashlib.sha256(source[node.start_byte:node.end_byte]).hexdigest()[:16],
                    kind="project",
                    name=project_name,
                    path=rel_path,
                    language="cmake",
                    span=Span(
                        start_line=start_line,
                        end_line=end_line,
                        start_col=node.start_point[1],
                        end_col=node.end_point[1],
                    ),
                    origin=PASS_ID,
                )
                symbols.append(sym)
                target_registry[project_name.lower()] = symbol_id

            elif cmd_name == "add_library" and args:
                # Library target
                lib_name = args[0]
                start_line = node.start_point[0] + 1
                end_line = node.end_point[0] + 1
                symbol_id = make_symbol_id("cmake", rel_path, start_line, end_line, lib_name, "library")

                sym = Symbol(
                    id=symbol_id,
                    stable_id=None,
                    shape_id=None,
                    canonical_name=lib_name,
                    fingerprint=hashlib.sha256(source[node.start_byte:node.end_byte]).hexdigest()[:16],
                    kind="library",
                    name=lib_name,
                    path=rel_path,
                    language="cmake",
                    span=Span(
                        start_line=start_line,
                        end_line=end_line,
                        start_col=node.start_point[1],
                        end_col=node.end_point[1],
                    ),
                    origin=PASS_ID,
                )
                symbols.append(sym)
                target_registry[lib_name.lower()] = symbol_id

            elif cmd_name == "add_executable" and args:
                # Executable target
                exe_name = args[0]
                start_line = node.start_point[0] + 1
                end_line = node.end_point[0] + 1
                symbol_id = make_symbol_id("cmake", rel_path, start_line, end_line, exe_name, "executable")

                sym = Symbol(
                    id=symbol_id,
                    stable_id=None,
                    shape_id=None,
                    canonical_name=exe_name,
                    fingerprint=hashlib.sha256(source[node.start_byte:node.end_byte]).hexdigest()[:16],
                    kind="executable",
                    name=exe_name,
                    path=rel_path,
                    language="cmake",
                    span=Span(
                        start_line=start_line,
                        end_line=end_line,
                        start_col=node.start_point[1],
                        end_col=node.end_point[1],
                    ),
                    origin=PASS_ID,
                )
                symbols.append(sym)
                target_registry[exe_name.lower()] = symbol_id

            elif cmd_name == "target_link_libraries" and len(args) >= 2:
                # Link dependency edges
                target_name = args[0]
                start_line = node.start_point[0] + 1

                # Get source target ID
                src_id = target_registry.get(target_name.lower())
                if src_id:
                    # Skip visibility keywords
                    visibility_keywords = {"public", "private", "interface"}
                    for dep in args[1:]:
                        if dep.lower() in visibility_keywords:
                            continue
                        # Look up dependency
                        if dep.lower() in target_registry:
                            dst_id = target_registry[dep.lower()]
                            confidence = 0.90
                        else:
                            # External library reference
                            dst_id = f"cmake:external:{dep}:library"
                            confidence = 0.70

                        edge = Edge.create(
                            src=src_id,
                            dst=dst_id,
                            edge_type="links",
                            line=start_line,
                            confidence=confidence,
                            origin=PASS_ID,
                            evidence_type="cmake_target_link",
                        )
                        edges.append(edge)

            elif cmd_name == "add_subdirectory" and args:
                # Subdirectory include
                subdir = args[0]
                start_line = node.start_point[0] + 1
                end_line = node.end_point[0] + 1
                symbol_id = make_symbol_id("cmake", rel_path, start_line, end_line, subdir, "subdirectory")

                sym = Symbol(
                    id=symbol_id,
                    stable_id=None,
                    shape_id=None,
                    canonical_name=subdir,
                    fingerprint=hashlib.sha256(source[node.start_byte:node.end_byte]).hexdigest()[:16],
                    kind="subdirectory",
                    name=subdir,
                    path=rel_path,
                    language="cmake",
                    span=Span(
                        start_line=start_line,
                        end_line=end_line,
                        start_col=node.start_point[1],
                        end_col=node.end_point[1],
                    ),
                    origin=PASS_ID,
                )
                symbols.append(sym)

            elif cmd_name == "find_package" and args:
                # External package dependency
                pkg_name = args[0]
                start_line = node.start_point[0] + 1
                end_line = node.end_point[0] + 1
                symbol_id = make_symbol_id("cmake", rel_path, start_line, end_line, pkg_name, "package")

                sym = Symbol(
                    id=symbol_id,
                    stable_id=None,
                    shape_id=None,
                    canonical_name=pkg_name,
                    fingerprint=hashlib.sha256(source[node.start_byte:node.end_byte]).hexdigest()[:16],
                    kind="package",
                    name=pkg_name,
                    path=rel_path,
                    language="cmake",
                    span=Span(
                        start_line=start_line,
                        end_line=end_line,
                        start_col=node.start_point[1],
                        end_col=node.end_point[1],
                    ),
                    origin=PASS_ID,
                )
                symbols.append(sym)

        elif node.type == "function_def":
            # Function definition
            for child in node.children:
                if child.type == "function_command":
                    func_name = _get_function_name(child, source)
                    if func_name:
                        start_line = node.start_point[0] + 1
                        end_line = node.end_point[0] + 1
                        symbol_id = make_symbol_id("cmake", rel_path, start_line, end_line, func_name, "function")

                        sym = Symbol(
                            id=symbol_id,
                            stable_id=None,
                            shape_id=None,
                            canonical_name=func_name,
                            fingerprint=hashlib.sha256(source[node.start_byte:node.end_byte]).hexdigest()[:16],
                            kind="function",
                            name=func_name,
                            path=rel_path,
                            language="cmake",
                            span=Span(
                                start_line=start_line,
                                end_line=end_line,
                                start_col=node.start_point[1],
                                end_col=node.end_point[1],
                            ),
                            origin=PASS_ID,
                            signature=_extract_cmake_signature(child, source),
                        )
                        symbols.append(sym)
                        target_registry[func_name.lower()] = symbol_id
                    break

        elif node.type == "macro_def":
            # Macro definition
            for child in node.children:
                if child.type == "macro_command":
                    macro_name = _get_function_name(child, source)
                    if macro_name:
                        start_line = node.start_point[0] + 1
                        end_line = node.end_point[0] + 1
                        symbol_id = make_symbol_id("cmake", rel_path, start_line, end_line, macro_name, "macro")

                        sym = Symbol(
                            id=symbol_id,
                            stable_id=None,
                            shape_id=None,
                            canonical_name=macro_name,
                            fingerprint=hashlib.sha256(source[node.start_byte:node.end_byte]).hexdigest()[:16],
                            kind="macro",
                            name=macro_name,
                            path=rel_path,
                            language="cmake",
                            span=Span(
                                start_line=start_line,
                                end_line=end_line,
                                start_col=node.start_point[1],
                                end_col=node.end_point[1],
                            ),
                            origin=PASS_ID,
                            signature=_extract_cmake_signature(child, source),
                        )
                        symbols.append(sym)
                        target_registry[macro_name.lower()] = symbol_id
                    break


class CMakeAnalyzer(TreeSitterAnalyzer):
    """Tree-sitter-based CMake analyzer.

    Uses tree-sitter-cmake to parse CMakeLists.txt and *.cmake files.
    Extracts projects, library/executable targets, functions, macros,
    packages, subdirectories, and target_link_libraries edges.

    Overrides ``analyze`` because CMake uses a single-pass approach: both
    symbols and edges (target_link_libraries) are extracted together since
    target link references need the target registry built during the same pass.
    """

    lang = "cmake"
    file_patterns: ClassVar[list[str]] = ["CMakeLists.txt", "*.cmake"]
    grammar_module = "tree_sitter_cmake"

    def analyze(
        self,
        repo_root: Path,
        max_files: Optional[int] = None,
    ) -> AnalysisResult:
        """Run CMake analysis with single-pass symbol+edge extraction.

        CMake target_link_libraries references need the target registry
        built during symbol extraction, so both symbols and edges are
        extracted in a single pass through ``_process_cmake_tree``.
        """
        import time as _time
        import warnings as _warnings

        start_time = _time.time()
        run = AnalysisRun.create(pass_id=PASS_ID, version=PASS_VERSION)

        if not self._check_grammar_available():
            _warnings.warn(
                f"{self.lang} analysis skipped: grammar not available. "
                f"Install the required tree-sitter grammar package.",
                UserWarning,
                stacklevel=2,
            )
            run.duration_ms = int((_time.time() - start_time) * 1000)
            return AnalysisResult(
                run=run,
                skipped=True,
                skip_reason=f"{self.lang} tree-sitter grammar not available",
            )

        parser = self._create_parser()

        files_analyzed = 0
        files_skipped = 0
        warnings_list: list[str] = []

        symbols: list[Symbol] = []
        edges: list[Edge] = []
        target_registry: dict[str, str] = {}

        cmake_files = list(find_cmake_files(repo_root))

        for cmake_path in cmake_files:
            if max_files is not None and files_analyzed >= max_files:
                break  # pragma: no cover

            try:
                rel_path = str(cmake_path.relative_to(repo_root))
                source = cmake_path.read_bytes()
                tree = parser.parse(source)
                files_analyzed += 1

                _process_cmake_tree(
                    tree.root_node,
                    source,
                    rel_path,
                    symbols,
                    edges,
                    target_registry,
                )

            except Exception as e:  # pragma: no cover
                files_skipped += 1  # pragma: no cover
                warnings_list.append(f"Failed to parse {cmake_path}: {e}")  # pragma: no cover

        run.files_analyzed = files_analyzed
        run.files_skipped = files_skipped
        run.duration_ms = int((_time.time() - start_time) * 1000)
        run.warnings = warnings_list

        return AnalysisResult(
            symbols=symbols,
            edges=edges,
            run=run,
        )


_analyzer = CMakeAnalyzer()


def is_cmake_tree_sitter_available() -> bool:
    """Check if tree-sitter with CMake grammar is available."""
    return _analyzer._check_grammar_available()


@register_analyzer("cmake")
def analyze_cmake_files(repo_root: Path) -> AnalysisResult:
    """Analyze CMake files in the repository.

    Args:
        repo_root: Path to the repository root

    Returns:
        AnalysisResult with symbols and edges
    """
    return _analyzer.analyze(repo_root)
