# SPDX-License-Identifier: AGPL-3.0-or-later
"""Python AST analysis pass.

This analyzer uses Python's built-in ast module to extract symbols and
relationships from Python source files, with no external dependencies.

How It Works
------------
Analysis proceeds in two passes for cross-file resolution:

**Pass 1 - Symbol Collection:**
- Parse each .py file with ast.parse()
- Extract top-level functions and classes as symbols
- Extract methods nested inside classes
- Build import mappings for cross-file resolution
- Compute stable_id (signature-based) and shape_id (structure-based)
- Extract rich metadata (decorators, base classes, parameters) per ADR-0003

**Pass 2 - Edge Extraction:**
- Walk AST to find function/method call sites
- Resolve callees using local symbols first, then imports
- Detect self.method() calls within classes
- Detect self.field.method() calls using field type inference from __init__
- Detect ClassName() instantiation patterns
- Track return type annotations for variable type inference
- Create import edges from files to imported symbols

Detected Patterns
-----------------
- Function calls: helper(), module.func()
- Method calls: self.method(), obj.method(), self.field.method()
- Class instantiation: ClassName()
- Module attribute reads: os.environ, sys.argv, sys.path — bare
  (non-called) ``imported_module.attribute`` accesses. Emits
  ``module_attr_ref`` edges so IO-primitive catalog ``attributes:``
  entries become reachable by ``io-boundaries`` (WI-guhok).
- Imports: from X import Y, import X
- Django URL patterns: path(), re_path(), url() calls in urls.py
- Flask URL rules: app.add_url_rule() calls

Route Detection Architecture
-----------------------------
Call-based URL routing (Django path(), Flask add_url_rule()) produces two
outputs that serve different downstream consumers:

1. **UsageContext records** — matched by YAML framework patterns (django.yaml,
   flask.yaml) to enrich *handler* symbols with ``concept: route`` metadata.
   This lets the enrichment layer tag view functions as route handlers.

2. **Route symbols** (``kind="route"``) — consumed by the ``route_handler``
   linker to create ``routes_to`` edges from route entities to handler symbols.
   These are first-class nodes in the IR representing the route itself.

Both are derived from the same extraction pass (_extract_django_usage_contexts,
_extract_flask_usage_contexts). Route symbols are created from the UsageContext
metadata at the callsite. This avoids duplicating the AST-walking logic while
preserving both outputs. Go and JS/TS analyzers follow the same dual-output
pattern.

ID Schemes
----------
- **stable_id**: sha256 of signature (param count, arity flags, decorators).
  Survives renames and moves if signature unchanged.
- **shape_id**: sha256 of AST structure (control flow, nesting).
  Detects clones with different variable names.

Rich Metadata (ADR-0003)
------------------------
Symbols include structured metadata in `meta` dict:
- **decorators**: List of decorator info with name, args, kwargs.
  Example: `[{"name": "app.get", "args": ["/users"], "kwargs": {"tags": ["api"]}}]`
- **base_classes**: List of base class names for classes.
  Example: `["BaseModel", "Generic[T]"]`
- **parameters**: List of parameter info for functions/methods.
  Example: `[{"name": "x", "type": "int", "default": False}]`

Why This Design
---------------
- Built-in ast module requires no dependencies and handles all Python syntax
- Two-pass approach enables cross-file call resolution via imports
- col_offset == 0 heuristic distinguishes top-level from nested functions
- Import resolution handles both absolute and relative imports
- Rich metadata feeds YAML-driven framework pattern enrichment (ADR-0003)
"""
import ast
import hashlib
import warnings
from dataclasses import dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING, Iterator

from hypergumbo_core.dataflow import annotate_dataflow_ast, get_dataflow_config
from hypergumbo_core.discovery import find_files
from hypergumbo_core.ir import AnalysisRun, Edge, PASS_VERSION, Span, Symbol, UsageContext, make_pass_id
from hypergumbo_core.analyze.base import (
    AnalysisResult,
    make_route_stable_id,
    make_typed_stable_id,
    visibility_from_modifiers,
)
from hypergumbo_core.analyze.registry import register_analyzer

if TYPE_CHECKING:
    from hypergumbo_core.symbol_resolution import SymbolResolver


def find_python_files(
    repo_root: Path, max_files: int | None = None
) -> Iterator[Path]:
    """Yield all Python files in the repository, excluding common non-source dirs."""
    yield from find_files(repo_root, ["*.py"], max_files=max_files)


def _python_visibility_modifiers(name: str) -> list[str]:
    """Derive visibility modifiers from Python naming convention.

    Single underscore prefix (``_name``) = private.
    Double underscore prefix without trailing double underscore (``__name``)
    = private (name-mangled).
    Dunders (``__name__``) are special methods, not private.
    No prefix = public (empty list, since Python has no explicit modifier).
    """
    # Strip qualified prefix: "Class._method" → check "_method"
    short = name.rsplit(".", 1)[-1] if "." in name else name
    if short.startswith("_") and not (short.startswith("__") and short.endswith("__")):
        return ["private"]
    return []


def _extract_module_all(tree: "ast.Module") -> frozenset[str] | None:
    """Extract the module-level ``__all__`` name set from *tree*.

    WI-gipag (WI-zimum Phase 2): the module-level ``__all__`` list
    declares the public API surface of a Python module. When present,
    only names in ``__all__`` should be flagged ``is_exported=True``;
    all other top-level symbols remain un-exported regardless of
    naming convention.

    Returns the frozenset of string names in ``__all__`` (possibly
    empty), or ``None`` if the file does not define a module-level
    ``__all__`` assignment. The ``None`` vs empty-set distinction
    matters because the callers use it to decide between
    ``__all__``-driven filtering and the fallback leading-underscore
    rule.

    Supported forms:
    - ``__all__ = ["foo", "bar"]``       (list literal)
    - ``__all__ = ("foo", "bar")``       (tuple literal)
    - ``__all__: list[str] = ["foo"]``   (annotated assignment)

    Non-literal forms (``__all__ = other_module.__all__``,
    ``__all__ += ["baz"]``, list comprehensions) are not
    interpreted — they are rare and would require evaluation. The
    caller treats "unparseable ``__all__``" the same as "no
    ``__all__``" and falls back to the leading-underscore rule.
    """
    for node in tree.body:
        target_name: str | None = None
        value: ast.expr | None = None

        if isinstance(node, ast.Assign) and len(node.targets) == 1:
            target = node.targets[0]
            if isinstance(target, ast.Name) and target.id == "__all__":
                target_name = "__all__"
                value = node.value
        elif isinstance(node, ast.AnnAssign):
            target = node.target
            if isinstance(target, ast.Name) and target.id == "__all__":
                target_name = "__all__"
                value = node.value

        if target_name is None or value is None:
            continue

        if isinstance(value, (ast.List, ast.Tuple)):
            names: list[str] = []
            for elt in value.elts:
                if isinstance(elt, ast.Constant) and isinstance(elt.value, str):
                    names.append(elt.value)
                # Anything non-literal (e.g., a Name reference, a call)
                # makes the __all__ interpretation ambiguous. Return
                # None to fall back to the leading-underscore rule.
                else:
                    return None
            return frozenset(names)
        # __all__ set via a non-literal expression — unparseable.
        return None
    return None


def _is_python_top_level_exported(
    name: str, module_all: frozenset[str] | None,
) -> bool:
    """Return True if *name* is part of the Python module's public API.

    WI-gipag: when the module has an ``__all__`` list, membership in
    ``__all__`` is authoritative. Otherwise, the leading-underscore
    convention applies — names not starting with ``_`` are public.
    Dunders (``__name__``) are never considered exported by this rule;
    they are special methods / module hooks, not user-facing API.
    """
    if module_all is not None:
        return name in module_all
    if name.startswith("_"):
        return False
    return True


def normalize_python_signature(
    signature: str | None,
    type_params: list[str] | None = None,
) -> str | None:
    """Normalize a Python signature for typed stable_id (ADR-0014 §3)."""
    from hypergumbo_core.analyze.base import normalize_signature_names_first
    return normalize_signature_names_first(
        signature, type_params, return_sep="->", skip_self=True,
    )


def _make_symbol_id(path: str, line: int, end_line: int, name: str, kind: str) -> str:
    """Generate location-based ID in format {lang}:{file}:{start}-{end}:{name}:{kind}."""
    return f"python:{path}:{line}-{end_line}:{name}:{kind}"


def _emit_module_level_assign_symbols(
    tree: "ast.Module",
    py_file: Path,
    module_all: frozenset[str] | None,
) -> list[Symbol]:
    """Emit ``Symbol(kind="variable", ...)`` for each top-level binding.

    Without this pass, ``from <mod> import NAME`` for any module-level
    constant (e.g. ``LANGUAGE_ALIASES``, ``PASS_VERSION``) misses the
    cross-file lookup and synthesises a tier-3 ``external_symbol`` —
    151 such ALL-CAPS externals on hypergumbo self-analysis (WI-gafog E2).

    Walks ``tree.body`` (top-level statements only). Handles:

    * ``ast.Assign`` with one or more ``Name`` targets, including
      tuple/list-unpacking targets like ``A, B = 1, 2``.
    * ``ast.AnnAssign`` with a ``Name`` target (``X: int = 1`` or ``X: int``).

    Does NOT emit for:

    * ``ast.AugAssign`` (``X += 1``) — mutation, not a fresh binding.
    * Subscript or attribute targets (``X[0] = 1``, ``X.y = 1``).
    * Names defined inside class or function bodies — those are not
      module-level (the walk only inspects ``tree.body``).
    """
    out: list[Symbol] = []
    for node in tree.body:
        targets: list[ast.Name] = []
        if isinstance(node, ast.Assign):
            for t in node.targets:
                if isinstance(t, ast.Name):
                    targets.append(t)
                elif isinstance(t, (ast.Tuple, ast.List)):
                    for el in t.elts:
                        if isinstance(el, ast.Name):
                            targets.append(el)
        elif isinstance(node, ast.AnnAssign) and isinstance(node.target, ast.Name):
            targets.append(node.target)
        else:
            continue
        for tgt in targets:
            line = tgt.lineno
            end_line = node.end_lineno or line
            span = Span(
                start_line=line,
                end_line=end_line,
                start_col=tgt.col_offset,
                end_col=node.end_col_offset or 0,
            )
            out.append(
                Symbol(
                    id=_make_symbol_id(str(py_file), line, end_line, tgt.id, "variable"),
                    name=tgt.id,
                    kind="variable",
                    language="python",
                    path=str(py_file),
                    span=span,
                    origin="",
                    origin_run_id="",
                    modifiers=_python_visibility_modifiers(tgt.id),
                    is_exported=_is_python_top_level_exported(tgt.id, module_all),
                )
            )
    return out


def _make_file_id(path: str) -> str:
    """Generate ID for a Python file node (used as import edge source)."""
    return f"python:{path}:1-1:file:file"


def _make_module_id(module_name: str) -> str:
    """Generate ID for an external module (used as import edge destination)."""
    return f"python:{module_name}:0-0:module:module"


def _extract_return_type_name(signature: str | None) -> str | None:
    """Extract simple return type name from a function signature string.

    Parses signatures like "(x: int) -> MyClass" and returns "MyClass".
    Only handles simple (non-generic) return types — returns None for
    complex types like "Optional[X]", "list[X]", "X | Y", etc.

    Args:
        signature: Function signature string from Symbol.signature.

    Returns:
        The simple class name if found, None otherwise.
    """
    if not signature or " -> " not in signature:
        return None
    ret_part = signature.rsplit(" -> ", 1)[1]
    # Only handle simple names (identifiers), not generics or unions
    if ret_part.isidentifier():
        return ret_part
    return None


def _resolve_return_type_class(
    type_name: str,
    func_symbol: "Symbol",
    local_symbols: dict[str, "Symbol"],
    imports: dict[str, tuple[str, str]],
    global_symbols: dict[tuple[str, str], "Symbol"],
    resolver: "SymbolResolver | None" = None,
    sym_by_path_name: dict[tuple[str, str], "Symbol"] | None = None,
) -> "Symbol | None":
    """Resolve a return type name to a class Symbol.

    Searches for the class in three places (in order):
    1. The caller's local symbols (same file as the call site)
    2. The caller's imports
    3. The function's own module (the return type is usually co-located
       with the function that returns it)

    Only returns symbols with kind == "class".

    Args:
        type_name: Simple class name (e.g., "ServiceClient").
        func_symbol: The function Symbol whose return type we're resolving.
        local_symbols: Symbols defined in the caller's file.
        imports: Import mappings from the caller's file.
        global_symbols: All symbols across the project.
        resolver: Optional SymbolResolver for efficient lookups.

    Returns:
        The class Symbol if found, None otherwise.
    """
    # Check caller's local symbols first
    sym = local_symbols.get(type_name)
    if sym and sym.kind == "class":
        return sym
    # Check caller's imports
    if type_name in imports:
        module_name, original_name = imports[type_name]
        sym = _lookup_symbol_by_module(
            global_symbols, module_name, original_name, resolver=resolver
        )
        if sym and sym.kind == "class":
            return sym
    # Check function's own module — the return type class is typically
    # defined in the same file as the function
    if sym_by_path_name is not None:
        sym = sym_by_path_name.get((func_symbol.path, type_name))
        if sym and sym.kind == "class":
            return sym
    return None


def _lookup_symbol_by_module(
    global_symbols: dict[tuple[str, str], "Symbol"],
    module_name: str,
    symbol_name: str,
    *,
    resolver: "SymbolResolver | None" = None,
) -> "Symbol | None":
    """Look up a symbol with suffix-based module matching.

    When an import says 'from app.crud import X' but the file is registered
    as 'backend.app.crud', exact lookup fails. This function handles such
    cases by trying suffix matching.

    This is a thin wrapper around the shared SymbolResolver. For repeated
    lookups, pass a pre-built resolver for better performance (cached indexes).

    Args:
        global_symbols: Map of (module, name) -> Symbol
        module_name: The module name from the import statement
        symbol_name: The symbol name being imported
        resolver: Optional pre-built SymbolResolver for cached lookups.

    Returns:
        The matching Symbol, or None if not found.
    """
    if resolver is not None:
        result = resolver.lookup(module_name, symbol_name)
        return result.symbol

    # Fallback: use the shared lookup_symbol function (creates new resolver)
    from hypergumbo_core.symbol_resolution import lookup_symbol
    return lookup_symbol(global_symbols, module_name, symbol_name)


# HTTP methods recognized as route decorators (FastAPI, Flask 2.0+)
HTTP_METHODS = {"get", "post", "put", "patch", "delete", "head", "options", "route"}

# Django URL pattern functions (call-based routing)
# These emit UsageContext records for YAML pattern matching (v1.1.x)
DJANGO_URL_FUNCTIONS = {"path", "re_path", "url"}

# Flask/FastAPI call-based URL routing functions.
# Flask's add_url_rule() is the call-based alternative to @app.route().
# FastAPI's add_api_route() registers routes programmatically instead of
# using @router.get() decorators.  Both take a path string as the first
# argument and a handler function as a subsequent argument.
# Flask-RESTful's add_resource() takes the resource class as the first
# argument and URL path(s) as subsequent arguments.
FLASK_URL_FUNCTIONS = {"add_url_rule", "add_api_route", "add_resource"}

# Starlette routing classes. Unlike Flask's call-based functions,
# Starlette's Route(...) and WebSocketRoute(...) are bare constructor calls,
# not method calls on an app or router. We require import-scoped matching
# (the name must be imported from starlette.routing) to avoid false positives
# from any other Route class a repo defines locally.
STARLETTE_ROUTE_FUNCTIONS = {"Route", "WebSocketRoute"}
_STARLETTE_ROUTING_MODULE = "starlette.routing"


def _ast_value_to_python(node: ast.expr) -> str | int | float | bool | list | dict | None:
    """Convert an AST expression to a Python value representation.

    For simple literals, returns the actual value.
    For complex expressions (names, calls, etc.), returns string representation.
    """
    if isinstance(node, ast.Constant):
        # Handle non-JSON-serializable constants
        if node.value is ...:
            return "..."
        if isinstance(node.value, complex):
            return str(node.value)  # "1+2j" format
        if isinstance(node.value, bytes):
            return repr(node.value)  # "b'...'" format
        return node.value
    elif isinstance(node, ast.Name):
        # Variable reference - return name as string
        return node.id
    elif isinstance(node, ast.List):
        return [_ast_value_to_python(elt) for elt in node.elts]
    elif isinstance(node, ast.Tuple):
        return [_ast_value_to_python(elt) for elt in node.elts]
    elif isinstance(node, ast.Dict):
        result = {}
        for k, v in zip(node.keys, node.values, strict=True):
            if k is not None:
                key = _ast_value_to_python(k)
                if isinstance(key, str):
                    result[key] = _ast_value_to_python(v)
        return result
    elif isinstance(node, ast.Attribute):
        # e.g., SomeClass.field -> "SomeClass.field"
        return _format_annotation(node)
    elif isinstance(node, ast.UnaryOp) and isinstance(node.op, ast.USub):
        # Negative number
        val = _ast_value_to_python(node.operand)
        if isinstance(val, (int, float)):
            return -val
        return f"-{val}"  # pragma: no cover - defensive for non-numeric negation
    elif isinstance(node, ast.Call):
        # Function call as decorator arg, e.g., _add_static_prefix("/health").
        # If the first positional argument is a resolvable literal, return it.
        # This handles wrapper patterns common in Flask/FastAPI where a helper
        # function wraps a route path string.
        if node.args:
            first_arg = _ast_value_to_python(node.args[0])
            if isinstance(first_arg, str) and first_arg != "<complex>":
                return first_arg
        # Fall through to string representation
        return _format_annotation(node) or "<complex>"  # pragma: no cover
    elif isinstance(node, ast.BinOp) and isinstance(node.op, (ast.Add, ast.Sub)):
        # Complex number literal like 1+2j or 1-2j
        left = _ast_value_to_python(node.left)
        right = _ast_value_to_python(node.right)
        # Check if this looks like a complex number (real +/- imaginary)
        if isinstance(left, (int, float)) and isinstance(right, str) and right.endswith("j"):
            op = "+" if isinstance(node.op, ast.Add) else "-"
            return f"({left}{op}{right})"
        # Fall through to string representation for other BinOps
        return _format_annotation(node) or "<binop>"  # pragma: no cover
    else:
        # Complex expression - return string representation
        return _format_annotation(node) or "<complex>"  # pragma: no cover


def _extract_decorator_info(dec: ast.expr) -> dict[str, object]:
    """Extract full decorator information including arguments.

    Returns a dict with:
        name: Decorator name (e.g., "app.get", "dataclass")
        args: List of positional arguments
        kwargs: Dict of keyword arguments
    """
    name = ""
    args: list[object] = []
    kwargs: dict[str, object] = {}

    if isinstance(dec, ast.Name):
        # @decorator
        name = dec.id
    elif isinstance(dec, ast.Attribute):
        # @module.decorator (without call)
        name = _format_annotation(dec)
    elif isinstance(dec, ast.Call):
        # @decorator(...) or @module.decorator(...)
        if isinstance(dec.func, ast.Name):
            name = dec.func.id
        elif isinstance(dec.func, ast.Attribute):
            name = _format_annotation(dec.func)
        else:
            name = "<unknown>"  # pragma: no cover - defensive for unusual decorator forms

        # Extract positional arguments
        for arg in dec.args:
            args.append(_ast_value_to_python(arg))

        # Extract keyword arguments
        for kw in dec.keywords:
            if kw.arg is not None:  # Skip **kwargs unpacking
                kwargs[kw.arg] = _ast_value_to_python(kw.value)

    return {"name": name, "args": args, "kwargs": kwargs}


def _extract_parameters_info(
    args: ast.arguments, exclude_self: bool = False
) -> list[dict[str, object]]:
    """Extract structured parameter information from function arguments.

    Args:
        args: AST arguments node
        exclude_self: If True, skip 'self' and 'cls' parameters

    Returns:
        List of dicts with name, type, and default keys
    """
    params: list[dict[str, object]] = []
    defaults_offset = len(args.args) - len(args.defaults)

    for i, arg in enumerate(args.args):
        if exclude_self and i == 0 and arg.arg in ("self", "cls"):
            continue
        has_default = i >= defaults_offset
        type_str = _format_annotation(arg.annotation) if arg.annotation else None
        params.append({
            "name": arg.arg,
            "type": type_str if type_str else None,
            "default": has_default,
        })

    # Handle *args
    if args.vararg:
        type_str = _format_annotation(args.vararg.annotation) if args.vararg.annotation else None
        params.append({
            "name": f"*{args.vararg.arg}",
            "type": type_str if type_str else None,
            "default": False,
        })

    # Handle **kwargs
    if args.kwarg:
        type_str = _format_annotation(args.kwarg.annotation) if args.kwarg.annotation else None
        params.append({
            "name": f"**{args.kwarg.arg}",
            "type": type_str if type_str else None,
            "default": False,
        })

    return params


def _format_annotation(node: ast.expr) -> str:
    """Format a type annotation node to a readable string."""
    if isinstance(node, ast.Name):
        return node.id
    elif isinstance(node, ast.Constant):
        return repr(node.value)
    elif isinstance(node, ast.Subscript):
        # e.g., List[int], Dict[str, int]
        base = _format_annotation(node.value)
        slice_val = _format_annotation(node.slice)
        return f"{base}[{slice_val}]"
    elif isinstance(node, ast.Tuple):
        # e.g., (int, str) for Dict keys
        elts = [_format_annotation(e) for e in node.elts]
        return ", ".join(elts)
    elif isinstance(node, ast.BinOp) and isinstance(node.op, ast.BitOr):
        # Union types: X | Y
        left = _format_annotation(node.left)
        right = _format_annotation(node.right)
        return f"{left} | {right}"
    elif isinstance(node, ast.Attribute):
        # e.g., typing.Optional
        value = _format_annotation(node.value)
        return f"{value}.{node.attr}"
    else:
        return ""  # pragma: no cover - defensive fallback for unknown AST types


def _format_arg(arg: ast.arg) -> str:
    """Format a single function argument."""
    result = arg.arg
    if arg.annotation:
        ann = _format_annotation(arg.annotation)
        if ann:
            result += f": {ann}"
    return result


def _format_function_signature(node: ast.FunctionDef | ast.AsyncFunctionDef, max_len: int = 60) -> str:
    """Format a function signature from AST node.

    Args:
        node: AST FunctionDef or AsyncFunctionDef node.
        max_len: Maximum length of signature (default 60).

    Returns:
        Formatted signature string like "(x: int, y: str) -> bool".
    """
    args = node.args
    all_args: list[str] = []

    # Positional-only args (before /)
    for arg in args.posonlyargs:
        all_args.append(_format_arg(arg))

    # Regular args
    for i, arg in enumerate(args.args):
        arg_str = _format_arg(arg)
        # Check for default value
        num_defaults = len(args.defaults)
        num_args = len(args.args)
        default_idx = i - (num_args - num_defaults)
        if 0 <= default_idx < num_defaults:
            arg_str += "=…"
        all_args.append(arg_str)

    # *args
    if args.vararg:
        all_args.append(f"*{args.vararg.arg}")

    # Keyword-only args
    for i, arg in enumerate(args.kwonlyargs):
        arg_str = _format_arg(arg)
        if i < len(args.kw_defaults) and args.kw_defaults[i] is not None:
            arg_str += "=…"
        all_args.append(arg_str)

    # **kwargs
    if args.kwarg:
        all_args.append(f"**{args.kwarg.arg}")

    sig = "(" + ", ".join(all_args) + ")"

    # Add return type annotation if present
    if node.returns:
        ret_type = _format_annotation(node.returns)
        if ret_type:
            sig += f" -> {ret_type}"

    # Truncate if too long
    if len(sig) > max_len:
        sig = sig[:max_len - 1] + "…"

    return sig


def _has_module_level_code(tree: ast.Module) -> bool:
    """Check if a module has executable code at module level.

    Returns True if the module has statements that aren't just imports,
    function/class definitions, or docstrings. These files need a <module>
    pseudo-node so module-level code has an enclosing scope for edges.

    Examples of module-level code:
    - producer.produce(topic, value)  # Function calls
    - config = load_config()          # Assignments
    - if __name__ == '__main__': ...  # Control flow
    """
    for i, node in enumerate(tree.body):
        # Skip docstrings (first constant string expression)
        if i == 0 and isinstance(node, ast.Expr):
            if isinstance(node.value, ast.Constant) and isinstance(node.value.value, str):
                continue

        # Skip imports
        if isinstance(node, (ast.Import, ast.ImportFrom)):
            continue

        # Skip function/class definitions
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            continue

        # Skip pass statements
        if isinstance(node, ast.Pass):
            continue

        # Skip type aliases and annotations
        if isinstance(node, ast.AnnAssign):
            continue

        # Any other statement is executable module-level code
        return True

    return False


def _get_file_end_line(source: str) -> int:
    """Get the last line number of a source file."""
    return len(source.splitlines())


def _has_main_guard(tree: ast.Module) -> bool:
    """Check if a module has the `if __name__ == "__main__":` pattern.

    This is a structural entry point indicator for Python scripts.
    The pattern indicates the file is designed to be run as a script.

    Handles both:
    - if __name__ == "__main__":  (standard)
    - if "__main__" == __name__:  (reversed)
    - Single and double quotes

    Returns:
        True if the main guard pattern is detected, False otherwise.
    """
    for node in tree.body:
        if not isinstance(node, ast.If):
            continue

        test = node.test
        if not isinstance(test, ast.Compare):
            continue

        # Check for: __name__ == "__main__"
        if len(test.ops) != 1 or not isinstance(test.ops[0], ast.Eq):
            continue

        left = test.left
        comparators = test.comparators

        if len(comparators) != 1:  # pragma: no cover - defensive: len(ops) == len(comparators) in valid AST
            continue

        right = comparators[0]

        # Pattern 1: __name__ == "__main__"
        if (isinstance(left, ast.Name) and left.id == "__name__" and
                isinstance(right, ast.Constant) and right.value == "__main__"):
            return True

        # Pattern 2: "__main__" == __name__
        if (isinstance(left, ast.Constant) and left.value == "__main__" and
                isinstance(right, ast.Name) and right.id == "__name__"):
            return True

    return False


def _extract_django_usage_contexts(
    tree: ast.Module,
    file_path: str,
    symbol_by_name: dict[str, Symbol],
    local_constants: dict[str, str] | None = None,
    imports: dict[str, tuple[str, str]] | None = None,
    repo_root: Path | None = None,
) -> list[UsageContext]:
    """Extract UsageContext records for Django URL patterns.

    Creates UsageContext records that capture how view functions are used
    in path(), re_path(), url() calls. These are matched against YAML
    patterns in the enrichment phase.

    When ``local_constants`` and ``imports`` are provided, resolves
    dynamic route paths built from string concatenation or module-level
    constants (e.g., ``path(BASE + "/users/", view)``).

    Args:
        tree: The parsed AST module
        file_path: Path to the source file
        symbol_by_name: Lookup table for symbols defined in this file
        local_constants: Module-level string constant assignments
        imports: Imported names for cross-file constant resolution
        repo_root: Repository root for cross-file constant resolution

    Returns:
        List of UsageContext records for Django URL patterns.
    """
    contexts: list[UsageContext] = []

    for node in ast.walk(tree):
        if not isinstance(node, ast.Call):
            continue

        # Check if it's a Django URL function call
        func_name = None
        if isinstance(node.func, ast.Name):
            func_name = node.func.id
        elif isinstance(node.func, ast.Attribute):
            func_name = node.func.attr

        if func_name not in DJANGO_URL_FUNCTIONS:
            continue

        # Extract the URL pattern from the first argument
        if not node.args:  # pragma: no cover
            continue

        first_arg = node.args[0]
        route_path = _resolve_string_expr(
            first_arg,
            local_constants or {},
            imports,
            repo_root,
        )
        if route_path is None:
            if isinstance(first_arg, ast.JoinedStr):  # pragma: no cover
                continue  # Skip dynamic patterns (f-strings)
            continue  # pragma: no cover - unsupported pattern type

        # Extract view reference from second argument
        view_ref = None
        view_name = None
        is_class_based = False
        if len(node.args) >= 2:
            second_arg = node.args[1]
            if isinstance(second_arg, ast.Attribute):
                # views.user_list -> check if we can resolve it
                view_name = second_arg.attr
            elif isinstance(second_arg, ast.Name):
                # user_list -> check if it's defined locally
                view_name = second_arg.id
                # Try to resolve to a local symbol
                if view_name in symbol_by_name:
                    view_ref = symbol_by_name[view_name].id
            elif isinstance(second_arg, ast.Call):
                # views.LoginView.as_view() -> "LoginView"
                # TemplateView.as_view(template_name='...') -> "TemplateView"
                call_func = second_arg.func
                if isinstance(call_func, ast.Attribute) and call_func.attr == "as_view":
                    is_class_based = True
                    # Extract the class name from the as_view() call
                    if isinstance(call_func.value, ast.Attribute):
                        # views.LoginView.as_view() -> LoginView
                        view_name = call_func.value.attr
                        # Try to resolve to a local symbol (class)
                        if view_name in symbol_by_name:
                            view_ref = symbol_by_name[view_name].id
                    elif isinstance(call_func.value, ast.Name):
                        # LoginView.as_view() -> LoginView
                        view_name = call_func.value.id
                        if view_name in symbol_by_name:
                            view_ref = symbol_by_name[view_name].id

        # Build metadata with args info
        args_values = []
        for arg in node.args:
            if isinstance(arg, ast.Constant):
                args_values.append(arg.value)
            elif isinstance(arg, ast.Name):
                args_values.append(arg.id)
            elif isinstance(arg, ast.Attribute):
                # views.func -> "views.func"
                parts = []
                current: ast.expr = arg
                while isinstance(current, ast.Attribute):
                    parts.append(current.attr)
                    current = current.value
                if isinstance(current, ast.Name):
                    parts.append(current.id)
                args_values.append(".".join(reversed(parts)))
            else:  # pragma: no cover
                args_values.append("<expr>")

        # Normalize route path - ensure it starts with /
        normalized_path = route_path if route_path.startswith("/") else f"/{route_path}"

        span = Span(
            start_line=node.lineno,
            end_line=getattr(node, "end_lineno", node.lineno),
            start_col=getattr(node, "col_offset", 0),
            end_col=getattr(node, "end_col_offset", 0),
        )

        ctx = UsageContext.create(
            kind="call",
            context_name=func_name,
            position="args[1]",
            path=file_path,
            span=span,
            symbol_ref=view_ref,
            metadata={
                "args": args_values,
                "route_path": normalized_path,
                "view_name": view_name,
                "is_class_based_view": is_class_based,
            },
        )
        contexts.append(ctx)

    return contexts


def _collect_module_constants(
    tree: ast.Module,
    repo_root: Path | None = None,
    file_path: Path | None = None,
) -> tuple[dict[str, str], dict[str, tuple[str, str]]]:
    """Collect module-level string constants and import mappings from an AST.

    Scans top-level assignments of the form ``NAME = "literal"`` and
    ``from mod import NAME`` to build lookup tables for constant propagation.
    Relative imports are resolved using ``file_path`` and ``repo_root``.

    Used by ``_scan_router_prefixes`` for APIRouter prefix resolution and
    by route path extraction for dynamic route resolution (e.g.,
    ``path(BASE + "/users/", view)``).

    Args:
        tree: The parsed AST module.
        repo_root: Repository root for resolving relative imports.
        file_path: Path to the source file (for relative import resolution).

    Returns:
        Tuple of (local_constants, imports) where local_constants maps
        variable names to string values and imports maps local names to
        (module_path, original_name) tuples.
    """
    local_constants: dict[str, str] = {}
    for node in ast.iter_child_nodes(tree):
        if (
            isinstance(node, ast.Assign)
            and len(node.targets) == 1
            and isinstance(node.targets[0], ast.Name)
            and isinstance(node.value, ast.Constant)
            and isinstance(node.value.value, str)
        ):
            local_constants[node.targets[0].id] = node.value.value

    imports: dict[str, tuple[str, str]] = {}
    for node in ast.iter_child_nodes(tree):
        if isinstance(node, ast.ImportFrom) and node.module:
            module_path = node.module
            if node.level > 0 and file_path is not None:
                pkg_base = file_path.parent
                for _ in range(node.level - 1):
                    pkg_base = pkg_base.parent
                resolved = pkg_base / Path(*node.module.split("."))
                if repo_root is not None:
                    try:
                        rel = resolved.relative_to(repo_root)
                        module_path = ".".join(rel.parts)
                    except ValueError:  # pragma: no cover
                        pass
            for alias in node.names:
                local_name = alias.asname or alias.name
                imports[local_name] = (module_path, alias.name)

    return local_constants, imports


def _scan_router_prefixes(
    tree: ast.Module,
    repo_root: Path | None,
    file_path: Path | None = None,
) -> dict[str, str]:
    """Scan for FastAPI APIRouter(prefix=X) assignments and resolve prefixes.

    Finds assignments like ``v2_router = APIRouter(prefix="/v2")`` and builds
    a mapping from variable name to prefix string.  Handles three cases:

    1. Literal string: ``APIRouter(prefix="/v2")``
    2. Same-file constant: ``PREFIX = "/v2"; APIRouter(prefix=PREFIX)``
    3. Imported constant: ``from pkg.constants import PREFIX; APIRouter(prefix=PREFIX)``
       (requires ``repo_root`` and ``file_path`` to resolve relative imports)

    Args:
        tree: The parsed AST module.
        repo_root: Repository root for finding imported modules.
        file_path: Path to the source file (for resolving relative imports).

    Returns:
        Dict mapping variable name (e.g. "v2_router") to prefix string (e.g. "/v2").
    """
    local_constants, imports = _collect_module_constants(tree, repo_root, file_path)

    prefixes: dict[str, str] = {}

    for node in ast.walk(tree):
        # Match: var = APIRouter(prefix=X)
        if not isinstance(node, ast.Assign):
            continue
        if len(node.targets) != 1 or not isinstance(node.targets[0], ast.Name):
            continue
        if not isinstance(node.value, ast.Call):
            continue
        # Check the call is APIRouter(...)
        call = node.value
        func_name = None
        if isinstance(call.func, ast.Name):
            func_name = call.func.id
        elif isinstance(call.func, ast.Attribute):
            func_name = call.func.attr
        if func_name != "APIRouter":
            continue

        # Extract prefix= keyword argument
        prefix_value: str | None = None
        for kw in call.keywords:
            if kw.arg != "prefix":
                continue
            if isinstance(kw.value, ast.Constant) and isinstance(kw.value.value, str):
                # Case 1: literal string
                prefix_value = kw.value.value
            elif isinstance(kw.value, ast.Name):
                const_name = kw.value.id
                # Case 2: same-file constant
                if const_name in local_constants:
                    prefix_value = local_constants[const_name]
                # Case 3: imported constant
                elif const_name in imports and repo_root is not None:
                    prefix_value = _resolve_imported_string_constant(
                        imports[const_name], repo_root
                    )
            break

        if prefix_value is not None:
            var_name = node.targets[0].id
            prefixes[var_name] = prefix_value

    return prefixes


def _resolve_imported_string_constant(
    import_info: tuple[str, str],
    repo_root: Path,
) -> str | None:
    """Resolve a cross-file imported string constant.

    Given an import like ``from pkg.constants import V2_PREFIX``, finds the
    source file and extracts the value of ``V2_PREFIX = "/v2"``.

    Only resolves simple module-level string literal assignments to keep
    the implementation lightweight and predictable.

    Args:
        import_info: Tuple of (module_path, original_name) from the import.
        repo_root: Repository root for finding source files.

    Returns:
        The string value if found, or None.
    """
    module_path, original_name = import_info
    # Convert dotted module path to file path candidates
    parts = module_path.split(".")
    # Try both direct and src-layout paths
    candidates = [
        repo_root / Path(*parts).with_suffix(".py"),
        repo_root / "src" / Path(*parts).with_suffix(".py"),
    ]
    # Also try as package/__init__.py
    candidates.append(repo_root / Path(*parts) / "__init__.py")
    candidates.append(repo_root / "src" / Path(*parts) / "__init__.py")

    for candidate in candidates:
        if not candidate.is_file():
            continue
        try:
            source = candidate.read_text()
            mod = ast.parse(source)
        except (SyntaxError, UnicodeDecodeError):  # pragma: no cover
            continue
        for node in ast.iter_child_nodes(mod):
            if (
                isinstance(node, ast.Assign)
                and len(node.targets) == 1
                and isinstance(node.targets[0], ast.Name)
                and node.targets[0].id == original_name
                and isinstance(node.value, ast.Constant)
                and isinstance(node.value.value, str)
            ):
                return node.value.value
    return None


def _resolve_string_expr(
    node: ast.expr,
    local_constants: dict[str, str],
    imports: dict[str, tuple[str, str]] | None = None,
    repo_root: Path | None = None,
) -> str | None:
    """Resolve a string expression from an AST node via constant propagation.

    Handles three patterns that commonly appear in route path arguments:

    1. Literal strings: ``"/users"`` → ``"/users"``
    2. Name references: ``BASE_URL`` → value from ``local_constants`` or imports
    3. String concatenation: ``BASE + "/users"`` → recursive resolution

    Recursion is bounded by Python's AST depth (no cycles possible in a
    single expression).  Only resolves module-level string literal
    assignments; dynamic or runtime-computed values return None.

    Args:
        node: The AST expression node to resolve.
        local_constants: Module-level ``NAME = "literal"`` assignments.
        imports: Imported names mapping ``local_name → (module, original)``.
        repo_root: Repository root for cross-file constant resolution.

    Returns:
        The resolved string value, or None if the expression cannot be
        statically resolved.
    """
    if isinstance(node, ast.Constant) and isinstance(node.value, str):
        return node.value
    if isinstance(node, ast.Name):
        name = node.id
        if name in local_constants:
            return local_constants[name]
        if imports and name in imports and repo_root is not None:
            return _resolve_imported_string_constant(imports[name], repo_root)
        return None
    if isinstance(node, ast.BinOp) and isinstance(node.op, ast.Add):
        left = _resolve_string_expr(node.left, local_constants, imports, repo_root)
        right = _resolve_string_expr(node.right, local_constants, imports, repo_root)
        if left is not None and right is not None:
            return left + right
        return None
    return None


def _extract_flask_usage_contexts(
    tree: ast.Module,
    file_path: str,
    symbol_by_name: dict[str, Symbol],
    router_prefixes: dict[str, str] | None = None,
    local_constants: dict[str, str] | None = None,
    imports: dict[str, tuple[str, str]] | None = None,
    repo_root: Path | None = None,
) -> list[UsageContext]:
    """Extract UsageContext records for Flask/FastAPI call-based route registration.

    Creates UsageContext records that capture how view functions are used
    in add_url_rule() and add_api_route() calls. These are matched against
    YAML patterns in the enrichment phase.

    Supported patterns:
    - app.add_url_rule('/users', 'user_list', user_list)
    - app.add_url_rule('/users', view_func=user_list)
    - blueprint.add_url_rule('/items', view_func=get_items, methods=['GET'])
    - router.add_api_route('/path', handler, methods=['GET'])
    - router.add_api_route('/path', handler, response_model=Model)

    When ``router_prefixes`` is provided (from ``_scan_router_prefixes``),
    routes registered on a prefixed APIRouter have the prefix composed with
    the route path.

    When ``local_constants`` and ``imports`` are provided, resolves
    dynamic route paths built from string concatenation or module-level
    constants (e.g., ``add_url_rule(PREFIX + '/users', ...)``).

    Args:
        tree: The parsed AST module
        file_path: Path to the source file
        symbol_by_name: Lookup table for symbols defined in this file
        router_prefixes: Optional mapping of router variable names to their
            APIRouter prefix strings.
        local_constants: Module-level string constant assignments
        imports: Imported names for cross-file constant resolution
        repo_root: Repository root for cross-file constant resolution

    Returns:
        List of UsageContext records for Flask URL patterns.
    """
    contexts: list[UsageContext] = []
    _prefixes = router_prefixes or {}

    for node in ast.walk(tree):
        if not isinstance(node, ast.Call):
            continue

        # Check if it's a Flask add_url_rule call (app.add_url_rule, bp.add_url_rule)
        func_name = None
        receiver_name = None
        if isinstance(node.func, ast.Attribute):
            func_name = node.func.attr
            if isinstance(node.func.value, ast.Name):
                receiver_name = node.func.value.id

        if func_name not in FLASK_URL_FUNCTIONS:
            continue

        # Flask-RESTful add_resource: first arg is class, second+ is path(s)
        # add_resource(TodoList, '/todos', '/todos/')
        if func_name == "add_resource":
            if len(node.args) < 2:
                continue
            # First arg is the resource class
            resource_arg = node.args[0]
            resource_name = None
            if isinstance(resource_arg, ast.Name):
                resource_name = resource_arg.id
            elif isinstance(resource_arg, ast.Attribute):
                resource_name = resource_arg.attr
            if resource_name is None:
                continue
            resource_ref = None
            if resource_name in symbol_by_name:
                resource_ref = symbol_by_name[resource_name].id
            # Second arg onwards are URL paths
            for path_arg in node.args[1:]:
                if isinstance(path_arg, ast.Constant) and isinstance(path_arg.value, str):
                    rpath = path_arg.value
                    normalized = rpath if rpath.startswith("/") else f"/{rpath}"
                    if receiver_name and receiver_name in _prefixes:
                        prefix = _prefixes[receiver_name].rstrip("/")
                        normalized = prefix + normalized
                    span = Span(
                        start_line=node.lineno,
                        end_line=getattr(node, "end_lineno", node.lineno),
                        start_col=getattr(node, "col_offset", 0),
                        end_col=getattr(node, "end_col_offset", 0),
                    )
                    call_name = f"{receiver_name}.{func_name}" if receiver_name else func_name
                    ctx = UsageContext.create(
                        kind="call",
                        context_name=call_name,
                        position="resource_class",
                        path=file_path,
                        span=span,
                        symbol_ref=resource_ref,
                        metadata={
                            "route_path": normalized,
                            "view_name": resource_name,
                            "args": [resource_name, rpath],
                        },
                    )
                    contexts.append(ctx)
            continue

        # Extract the URL pattern from the first argument
        if not node.args:  # pragma: no cover
            continue

        first_arg = node.args[0]
        route_path = _resolve_string_expr(
            first_arg,
            local_constants or {},
            imports,
            repo_root,
        )
        if route_path is None:
            if isinstance(first_arg, ast.JoinedStr):  # pragma: no cover
                continue  # Skip dynamic patterns (f-strings)
            continue  # pragma: no cover - unsupported pattern type

        # Extract view function - can be:
        # 1. Third positional arg: add_url_rule('/path', 'name', view_func)
        # 2. Second positional arg: add_api_route('/path', handler, ...)
        # 3. view_func keyword arg: add_url_rule('/path', view_func=handler)
        view_ref = None
        view_name = None

        # Check for view_func in keyword arguments
        for kw in node.keywords:
            if kw.arg == "view_func":
                if isinstance(kw.value, ast.Name):
                    view_name = kw.value.id
                    if view_name in symbol_by_name:
                        view_ref = symbol_by_name[view_name].id
                elif isinstance(kw.value, ast.Attribute):
                    view_name = kw.value.attr
                break

        # If not found in kwargs, check positional args.
        # add_api_route: second arg is handler ('/path', handler, ...)
        # add_url_rule: third arg is handler ('/path', 'name', handler)
        handler_arg_idx = 1 if func_name == "add_api_route" else 2
        if view_name is None and len(node.args) > handler_arg_idx:
            handler_arg = node.args[handler_arg_idx]
            if isinstance(handler_arg, ast.Name):
                view_name = handler_arg.id
                if view_name in symbol_by_name:
                    view_ref = symbol_by_name[view_name].id
            elif isinstance(handler_arg, ast.Attribute):
                view_name = handler_arg.attr

        # Extract methods if specified
        methods = None
        for kw in node.keywords:
            if kw.arg == "methods":
                if isinstance(kw.value, ast.List):
                    methods = []
                    for elt in kw.value.elts:
                        if isinstance(elt, ast.Constant) and isinstance(elt.value, str):
                            methods.append(elt.value.upper())

        # Build metadata
        args_values = []
        for arg in node.args:
            if isinstance(arg, ast.Constant):
                args_values.append(arg.value)
            elif isinstance(arg, ast.Name):
                args_values.append(arg.id)
            elif isinstance(arg, ast.Attribute):
                parts = []
                current: ast.expr = arg
                while isinstance(current, ast.Attribute):
                    parts.append(current.attr)
                    current = current.value
                if isinstance(current, ast.Name):
                    parts.append(current.id)
                args_values.append(".".join(reversed(parts)))
            else:  # pragma: no cover
                args_values.append("<expr>")

        # Normalize route path and compose with APIRouter prefix if present
        normalized_path = route_path if route_path.startswith("/") else f"/{route_path}"
        if receiver_name and receiver_name in _prefixes:
            prefix = _prefixes[receiver_name].rstrip("/")
            normalized_path = prefix + normalized_path

        span = Span(
            start_line=node.lineno,
            end_line=getattr(node, "end_lineno", node.lineno),
            start_col=getattr(node, "col_offset", 0),
            end_col=getattr(node, "end_col_offset", 0),
        )

        # Build full call name (e.g., "app.add_url_rule")
        call_name = f"{receiver_name}.{func_name}" if receiver_name else func_name

        ctx = UsageContext.create(
            kind="call",
            context_name=call_name,
            position="view_func",
            path=file_path,
            span=span,
            symbol_ref=view_ref,
            metadata={
                "args": args_values,
                "route_path": normalized_path,
                "view_name": view_name,
                "methods": methods or ["GET"],
                "receiver": receiver_name,
            },
        )
        contexts.append(ctx)

    return contexts


def _extract_starlette_usage_contexts(
    tree: ast.Module,
    file_path: str,
    symbol_by_name: dict[str, Symbol],
    imports: dict[str, tuple[str, str]] | None = None,
) -> list[UsageContext]:
    """Extract UsageContext records for Starlette ``Route`` / ``WebSocketRoute``.

    Starlette routes are constructor calls — ``Route("/path", handler, methods=[...])``
    and ``WebSocketRoute("/ws", handler)`` — typically passed as a list to a
    ``Starlette(routes=[...])`` constructor or to ``Mount(...)``. We treat both
    classes as route-registration points.

    The match is **import-scoped**: we only emit a UsageContext when the bare
    name (``Route`` / ``WebSocketRoute``) was imported from
    ``starlette.routing`` in this file. ``Route`` is a common class name and
    a global match would cause false positives.

    Args:
        tree: Parsed module AST.
        file_path: Path to the source file.
        symbol_by_name: Lookup table for symbols defined in this file.
        imports: ``{local_name: (module_path, original_name)}`` from
            ``_collect_module_constants``. When None, no contexts are emitted.

    Returns:
        UsageContext records with ``position="view_func"`` and metadata
        ``route_path`` / ``methods`` / ``view_name`` / ``args`` / ``receiver``
        (the imported class name, e.g., ``"Route"`` or ``"WebSocketRoute"``).
    """
    contexts: list[UsageContext] = []
    if not imports:
        return contexts

    # Build the set of locally-bound names that resolve to the Starlette
    # routing classes. Honors aliasing (``from starlette.routing import Route as R``).
    starlette_names: dict[str, str] = {}  # local_name → original_class_name
    for local_name, (module_path, original_name) in imports.items():
        if module_path != _STARLETTE_ROUTING_MODULE:
            continue
        if original_name not in STARLETTE_ROUTE_FUNCTIONS:
            continue
        starlette_names[local_name] = original_name

    if not starlette_names:
        return contexts

    for node in ast.walk(tree):
        if not isinstance(node, ast.Call):
            continue
        if not isinstance(node.func, ast.Name):
            continue
        local_name = node.func.id
        if local_name not in starlette_names:
            continue
        original_name = starlette_names[local_name]

        if not node.args:  # pragma: no cover - constructor with zero args is invalid
            continue

        # First arg: route path (string literal).
        first_arg = node.args[0]
        if not (isinstance(first_arg, ast.Constant) and isinstance(first_arg.value, str)):
            # Skip dynamic patterns; static analysis can't recover the path.
            continue
        route_path = first_arg.value
        normalized_path = route_path if route_path.startswith("/") else f"/{route_path}"

        # Second arg: handler function.
        view_ref = None
        view_name = None
        if len(node.args) >= 2:
            handler_arg = node.args[1]
            if isinstance(handler_arg, ast.Name):
                view_name = handler_arg.id
                if view_name in symbol_by_name:
                    view_ref = symbol_by_name[view_name].id
            elif isinstance(handler_arg, ast.Attribute):
                view_name = handler_arg.attr

        # Methods: kwarg for Route; synthetic ["WS"] for WebSocketRoute.
        methods: list[str] | None = None
        if original_name == "WebSocketRoute":
            methods = ["WS"]
        else:
            for kw in node.keywords:
                if kw.arg == "methods" and isinstance(kw.value, ast.List):
                    extracted: list[str] = []
                    for elt in kw.value.elts:
                        if isinstance(elt, ast.Constant) and isinstance(elt.value, str):
                            extracted.append(elt.value.upper())
                    if extracted:
                        methods = extracted

        # Build args metadata mirroring Flask's shape.
        args_values: list[str | int | float | bool | None] = []
        for arg in node.args:
            if isinstance(arg, ast.Constant):
                args_values.append(arg.value)
            elif isinstance(arg, ast.Name):
                args_values.append(arg.id)
            elif isinstance(arg, ast.Attribute):
                parts: list[str] = []
                current: ast.expr = arg
                while isinstance(current, ast.Attribute):
                    parts.append(current.attr)
                    current = current.value
                if isinstance(current, ast.Name):
                    parts.append(current.id)
                args_values.append(".".join(reversed(parts)))
            else:  # pragma: no cover - other expr forms (e.g. lambdas)
                args_values.append("<expr>")

        span = Span(
            start_line=node.lineno,
            end_line=getattr(node, "end_lineno", node.lineno),
            start_col=getattr(node, "col_offset", 0),
            end_col=getattr(node, "end_col_offset", 0),
        )
        ctx = UsageContext.create(
            kind="call",
            context_name=original_name,
            position="view_func",
            path=file_path,
            span=span,
            symbol_ref=view_ref,
            metadata={
                "args": args_values,
                "route_path": normalized_path,
                "view_name": view_name,
                "methods": methods or ["GET"],
                "receiver": original_name,
            },
        )
        contexts.append(ctx)

    return contexts


def _extract_py_decorator_names(node: ast.FunctionDef | ast.ClassDef) -> str:
    """Extract sorted, comma-joined decorator names from an AST node.

    Walks the decorator list and extracts plain names (stripping module
    paths and arguments).  Returns a sorted, comma-joined string suitable
    for inclusion in stable_id formulas.  Returns empty string when no
    decorators are present.
    """
    names: list[str] = []
    for dec in node.decorator_list:
        if isinstance(dec, ast.Name):
            names.append(dec.id)
        elif isinstance(dec, ast.Attribute):
            names.append(dec.attr)
        elif isinstance(dec, ast.Call):
            if isinstance(dec.func, ast.Name):
                names.append(dec.func.id)
            elif isinstance(dec.func, ast.Attribute):
                names.append(dec.func.attr)
    return ",".join(sorted(names))


def _compute_stable_id(
    node: ast.FunctionDef | ast.ClassDef,
    containing_stable_id: str = "",
) -> str:
    """Compute stable_id based on signature (survives renames/moves).

    Returns:
    sha256({kind}:{param_count}:{arity_flags}:{decorators}:{containing_stable_id})

    arity_flags: has_defaults, has_varargs, has_kwargs
    decorators: sorted list of decorator names
    containing_stable_id: stable_id of the enclosing class/module (ADR-0014 §5)
    """
    kind = "function" if isinstance(node, ast.FunctionDef) else "class"

    # Extract signature info for functions
    if isinstance(node, ast.FunctionDef):
        args = node.args
        param_count = len(args.args) + len(args.posonlyargs) + len(args.kwonlyargs)
        has_defaults = len(args.defaults) > 0 or len(args.kw_defaults) > 0
        has_varargs = args.vararg is not None
        has_kwargs = args.kwarg is not None
        arity_flags = f"{has_defaults},{has_varargs},{has_kwargs}"
    else:
        # Classes don't have parameters in the same way
        param_count = 0
        arity_flags = "False,False,False"

    decorators_str = _extract_py_decorator_names(node)

    # Build signature string and hash (ADR-0014 §5: includes containing_stable_id)
    sig = f"{kind}:{param_count}:{arity_flags}:{decorators_str}:{containing_stable_id}"
    hash_val = hashlib.sha256(sig.encode()).hexdigest()[:16]
    return f"sha256:{hash_val}"


def _ast_structure(node: ast.AST) -> str:
    """Generate structural representation of an AST node, ignoring names/literals."""
    parts = [type(node).__name__]

    for child in ast.iter_child_nodes(node):
        # Skip name nodes and constants (we want structure only)
        if isinstance(child, (ast.Name, ast.Constant, ast.arg)):
            parts.append(type(child).__name__)
        else:
            parts.append(_ast_structure(child))

    return f"({','.join(parts)})"


def _compute_shape_id(node: ast.FunctionDef | ast.ClassDef) -> str:
    """Compute shape_id based on AST structure (ignores variable names/literals).

    sha256(ast_structure) where structure is a normalized representation
    of the control flow and nesting.
    """
    # For functions, analyze the body structure
    if isinstance(node, ast.FunctionDef):
        body_parts = [_ast_structure(stmt) for stmt in node.body]
        structure = f"FunctionDef({','.join(body_parts)})"
    else:
        # For classes, analyze class body
        body_parts = [_ast_structure(stmt) for stmt in node.body]
        structure = f"ClassDef({','.join(body_parts)})"

    hash_val = hashlib.sha256(structure.encode()).hexdigest()[:16]
    return f"sha256:{hash_val}"


PASS_ID = make_pass_id("python-ast")


def _compute_cyclomatic_complexity(node: ast.AST) -> int:
    """Compute McCabe cyclomatic complexity for a function or class.

    Cyclomatic complexity = number of decision points + 1.

    Decision points counted:
    - if (each elif counts separately)
    - for loops
    - while loops
    - except handlers
    - with statements
    - boolean operators (and, or)
    - conditional expressions (ternary)
    - match/case statements (Python 3.10+)
    - comprehensions with if clauses

    Returns 1 for straight-line code (no branches).
    """
    complexity = 1  # Base complexity

    for child in ast.walk(node):
        # Conditional statements
        if isinstance(child, ast.If):
            complexity += 1
        # Loops
        elif isinstance(child, (ast.For, ast.While, ast.AsyncFor)):
            complexity += 1
        # Exception handlers (each except clause adds a branch)
        elif isinstance(child, ast.ExceptHandler):
            complexity += 1
        # With statements
        elif isinstance(child, (ast.With, ast.AsyncWith)):
            complexity += 1
        # Boolean operators in conditions
        elif isinstance(child, ast.BoolOp):
            # and/or each add (n-1) where n is number of operands
            complexity += len(child.values) - 1
        # Conditional expressions (ternary: x if cond else y)
        elif isinstance(child, ast.IfExp):
            complexity += 1
        # Comprehensions with if clauses
        elif isinstance(child, ast.comprehension):
            complexity += len(child.ifs)
        # Match/case (Python 3.10+)
        elif isinstance(child, ast.Match):
            # Each case is a branch
            complexity += len(child.cases)

    return complexity


def _compute_lines_of_code(node: ast.AST) -> int:
    """Compute lines of code for a function or class.

    Returns end_line - start_line + 1.
    """
    start = node.lineno
    end = getattr(node, "end_lineno", node.lineno)
    return end - start + 1


@dataclass
class FileAnalysis:
    """Intermediate analysis result for a single file.

    Note on type inference: Variable method calls (e.g., stub.method()) are resolved
    using constructor-only type inference. This tracks types from direct constructor
    calls (stub = Client()) but NOT from function returns (stub = get_client()).
    This covers ~90% of real-world cases with minimal complexity.
    """

    symbols: list[Symbol]
    symbol_by_name: dict[str, Symbol]
    # Maps imported name -> (module_name, original_name)
    imports: dict[str, tuple[str, str]] = field(default_factory=dict)
    # Maps local alias -> module_name for 'import X' and 'import X as Y'
    module_imports: dict[str, str] = field(default_factory=dict)
    # The parsed AST tree (kept to avoid re-parsing)
    tree: ast.AST | None = None
    # Usage contexts for call-based patterns (Django URL patterns, etc.)
    usage_contexts: list[UsageContext] = field(default_factory=list)
    # Original source text (for library_patterns regex scanning during
    # dataflow annotation — see annotate_dataflow_ast).
    source: str = ""


def _detect_source_roots(repo_root: Path) -> list[Path]:
    """Detect every src/ layout source root inside ``repo_root``.

    A *source root* is a directory named ``src`` that:
    1. is not itself a Python package (no ``__init__.py`` in it), and
    2. contains at least one Python package (a child dir with ``__init__.py``).

    Supports both the traditional single-root layout (``repo/src/<pkg>/``)
    and monorepo layouts where each package owns its own src dir
    (``repo/packages/<pkg>/src/<mod>/``, ``repo/libs/<lib>/src/<mod>/``, …).
    Without this multi-root detection a file under
    ``packages/hypergumbo-core/src/hypergumbo_core/taxonomy.py`` would be
    derived as the path-shaped module qualifier
    ``packages.hypergumbo-core.src.hypergumbo_core.taxonomy`` — invalid
    Python (hyphen) and not the real importable name (WI-davan E1).

    Implementation: iterative directory walk. Skips DEFAULT_EXCLUDES
    directories and dot-prefixed dirs to avoid `.git` / `node_modules` /
    build outputs. When a ``src`` directory satisfies both conditions, it
    is collected and not descended into; nested ``src`` directories
    deeper inside another source root are not searched (they would be
    inside the package, not separate roots).

    Returns a list sorted by path (deterministic for tests and consumers).
    """
    from hypergumbo_core.discovery import DEFAULT_EXCLUDES

    skip = set(DEFAULT_EXCLUDES)
    roots: list[Path] = []
    stack: list[Path] = [repo_root]
    while stack:
        cur = stack.pop()
        try:
            entries = list(cur.iterdir())
        except (PermissionError, OSError):  # pragma: no cover
            continue
        for entry in entries:
            if not entry.is_dir():
                continue
            if entry.name in skip or entry.name.startswith("."):
                continue
            if entry.name == "src":
                # Classify and stop descending — either a source root, a
                # package itself, or a dir whose children aren't packages.
                if (entry / "__init__.py").exists():
                    continue
                try:
                    has_pkg = any(
                        (c / "__init__.py").exists()
                        for c in entry.iterdir()
                        if c.is_dir()
                    )
                except (PermissionError, OSError):  # pragma: no cover
                    has_pkg = False
                if has_pkg:
                    roots.append(entry)
                continue
            stack.append(entry)
    return sorted(roots)


def _module_name_from_path(
    py_file: Path,
    repo_root: Path,
    source_roots: list[Path] | None = None,
) -> str:
    """Convert a file path to a Python module name.

    E.g., ``/repo/utils.py`` -> ``utils``, ``/repo/pkg/mod.py`` -> ``pkg.mod``.

    If ``source_roots`` is provided, paths under any source root are
    computed relative to the *most-specific* (longest-path) matching root.
    """
    roots = source_roots or []
    # Pick the most-specific (deepest) source root that contains the file
    matching = [r for r in roots if py_file.is_relative_to(r)]
    if matching:
        best = max(matching, key=lambda r: len(r.parts))
        try:
            rel_path = py_file.relative_to(best)
        except ValueError:  # pragma: no cover
            rel_path = py_file.relative_to(repo_root)
    else:
        try:
            rel_path = py_file.relative_to(repo_root)
        except ValueError:
            rel_path = py_file
    # Remove .py extension and convert path separators to dots
    return str(rel_path.with_suffix("")).replace("/", ".").replace("\\", ".")


def _resolve_relative_import(
    module: str | None, level: int, importing_module: str
) -> str:
    """Resolve a relative import to an absolute module name.

    Args:
        module: The module part of the import (e.g., 'utils' in 'from ..utils import X')
        level: The number of dots (0 for absolute, 1 for '.', 2 for '..', etc.)
        importing_module: The fully qualified name of the importing module

    Returns:
        The resolved absolute module name.

    Example:
        _resolve_relative_import('utils', 2, 'pkg.sub.main') -> 'pkg.utils'
    """
    if level == 0:
        # Absolute import
        return module or ""

    # Split the importing module into parts
    parts = importing_module.split(".")

    # Go up 'level' levels (level=1 means same package, level=2 means parent, etc.)
    # We go up (level) levels from the module's package (excluding the module name itself)
    # So for 'pkg.sub.main' with level=2, we go up 2 from 'pkg.sub' -> 'pkg'
    if level > len(parts):
        # Can't go up that many levels, return as-is
        return module or ""

    base_parts = parts[:-level] if level <= len(parts) else []
    if module:
        base_parts.append(module)

    return ".".join(base_parts)


def _extract_imports(
    tree: ast.AST, importing_module: str
) -> tuple[dict[str, tuple[str, str]], dict[str, str]]:
    """Extract import mappings from AST with relative import resolution.

    Args:
        tree: The parsed AST
        importing_module: The fully qualified name of the importing module

    Returns a tuple of:
        - symbol_imports: dict mapping local name -> (resolved_module_name, original_name)
          For 'from utils import helper', returns {'helper': ('utils', 'helper')}.
          For 'from ..utils import helper' in 'pkg.sub.main', returns {'helper': ('pkg.utils', 'helper')}.
        - module_imports: dict mapping local alias -> module_name
          For 'import demo_pb2_grpc', returns {'demo_pb2_grpc': 'demo_pb2_grpc'}.
          For 'import numpy as np', returns {'np': 'numpy'}.
    """
    symbol_imports: dict[str, tuple[str, str]] = {}
    module_imports: dict[str, str] = {}

    for node in ast.walk(tree):
        if isinstance(node, ast.ImportFrom):
            resolved_module = _resolve_relative_import(
                node.module, node.level, importing_module
            )
            if resolved_module:  # Skip if we couldn't resolve
                for alias in node.names:
                    local_name = alias.asname if alias.asname else alias.name
                    symbol_imports[local_name] = (resolved_module, alias.name)

        elif isinstance(node, ast.Import):
            # Handle 'import X' and 'import X as Y'
            for alias in node.names:
                module_name = alias.name
                local_name = alias.asname if alias.asname else alias.name
                module_imports[local_name] = module_name
                # WI-zigah: for `import pkg.subpkg` with no alias, Python binds
                # only the top-level `pkg` name. Call sites see
                # `pkg.subpkg.func(...)` where `pkg` is the AST root — so the
                # full dotted `local_name` is dead data no downstream lookup
                # reaches. Record the top-level binding so the chain walker
                # in _process_call can canonicalize the qualified path.
                if alias.asname is None and "." in module_name:
                    top_level = module_name.split(".", 1)[0]
                    module_imports.setdefault(top_level, top_level)

    return symbol_imports, module_imports


def _extract_import_edges(
    tree: ast.AST,
    file_path: str,
    importing_module: str,
    global_symbols: dict[tuple[str, str], Symbol],
    resolver: "SymbolResolver | None" = None,
) -> list[Edge]:
    """Extract import edges from AST.

    Creates edges from the importing file to the imported symbols/modules.
    For 'from X import Y', links to the resolved symbol if known, else to module.
    For 'import X', links to the module.

    Args:
        tree: The parsed AST
        file_path: Path to the importing file
        importing_module: The fully qualified name of the importing module
        global_symbols: Map of (module, name) -> Symbol for cross-file resolution
        resolver: Optional SymbolResolver for efficient cross-file lookups

    Returns list of import edges.
    """
    edges = []
    file_id = _make_file_id(file_path)

    for node in ast.walk(tree):
        # Handle 'from X import Y, Z' style imports
        if isinstance(node, ast.ImportFrom):
            resolved_module = _resolve_relative_import(
                node.module, node.level, importing_module
            )
            if resolved_module:
                for alias in node.names:
                    # Try to find the symbol in our global table (with suffix matching)
                    symbol = _lookup_symbol_by_module(
                        global_symbols, resolved_module, alias.name, resolver=resolver
                    )
                    if symbol:
                        dst_id = symbol.id
                    else:
                        # External symbol - create a reference ID
                        dst_id = f"python:{resolved_module}:0-0:{alias.name}:symbol"

                    edges.append(Edge.create(
                        src=file_id,
                        dst=dst_id,
                        edge_type="imports",
                        line=node.lineno,
                        evidence_type="ast_import",
                        confidence=0.95,
                    ))

        # Handle 'import X' and 'import X as Y' style imports
        elif isinstance(node, ast.Import):
            for alias in node.names:
                module_name = alias.name
                dst_id = _make_module_id(module_name)
                edges.append(Edge.create(
                    src=file_id,
                    dst=dst_id,
                    edge_type="imports",
                    line=node.lineno,
                    evidence_type="ast_import",
                    confidence=0.95,
                ))

    return edges


def _resolve_base_class(
    base_name: str,
    child_sym: Symbol,
    class_by_name: dict[str, list[Symbol]],
    sym_file_imports: dict[str, dict[str, tuple[str, str]]],
) -> Symbol | None:
    """Resolve a base class name to a specific Symbol, disambiguating collisions.

    When multiple classes share the same name (e.g., 238 classes named 'Model'
    in Django), uses a priority cascade:

    1. Same-file match: base class defined in the same file as the child
    2. Import match: child's file imports match a candidate's module path
    3. First by ID: deterministic fallback (sorted by symbol ID)

    Args:
        base_name: The base class name to resolve (e.g., 'Model')
        child_sym: The child class symbol (for file context)
        class_by_name: Multi-value lookup: class name -> list of Symbol candidates
        sym_file_imports: Maps symbol ID -> file-level imports dict
            (imported_name -> (module_name, original_name))

    Returns:
        The resolved base class Symbol, or None if no match found.
    """
    candidates = class_by_name.get(base_name)
    if not candidates:
        return None

    if len(candidates) == 1:
        return candidates[0]

    # Extract file path from child symbol ID for same-file check
    child_path = child_sym.path or ""

    # 1. Same-file match: prefer base class in the same file
    same_file = [c for c in candidates if c.path == child_path]
    if len(same_file) == 1:
        return same_file[0]

    # 2. Import match: check if child's file imports resolve to a candidate
    child_imports = sym_file_imports.get(child_sym.id, {})
    if base_name in child_imports:
        import_module, _original_name = child_imports[base_name]
        # Match import module against candidate file paths
        # e.g., import_module="db.models" matches candidate path "db/models.py"
        module_as_path = import_module.replace(".", "/")
        for cand in candidates:
            cand_path = cand.path or ""
            # Check if candidate path contains the module path
            # e.g., "db/models.py" contains "db/models"
            cand_no_ext = cand_path.rsplit(".py", 1)[0]
            if cand_no_ext.endswith(module_as_path):
                return cand

    # 3. Deterministic fallback: first by symbol ID (sorted for stability)
    candidates_sorted = sorted(candidates, key=lambda c: c.id)
    return candidates_sorted[0]


def _extract_inheritance_edges(
    symbols: list[Symbol],
    class_by_name: dict[str, list[Symbol]],
    sym_file_imports: dict[str, dict[str, tuple[str, str]]],
    run: AnalysisRun,
) -> list[Edge]:
    """Extract extends edges from class inheritance.

    For each class with base_classes metadata, creates extends edges to
    base classes that exist in the analyzed codebase. This enables the
    type hierarchy linker to create dispatches_to edges for polymorphic dispatch.

    When multiple classes share the same name (common in large repos like Django
    where 238 test stubs are named 'Model'), uses import-aware disambiguation
    via ``_resolve_base_class()`` to find the correct target.

    Args:
        symbols: All extracted symbols
        class_by_name: Multi-value lookup: class name -> list of Symbol candidates
        sym_file_imports: Maps symbol ID -> file-level imports dict
        run: Current analysis run for provenance

    Returns:
        List of extends edges for inheritance relationships
    """
    edges: list[Edge] = []

    for sym in symbols:
        if sym.kind != "class":
            continue

        base_classes = sym.meta.get("base_classes", []) if sym.meta else []
        if not base_classes:
            continue

        for base_class_name in base_classes:
            # Strip generics from base class name (e.g., "Generic[T]" -> "Generic")
            base_name = base_class_name.split("[")[0]

            # Resolve to the correct base class, handling name collisions
            base_sym = _resolve_base_class(
                base_name, sym, class_by_name, sym_file_imports
            )
            if base_sym is not None and base_sym.id != sym.id:
                edge = Edge.create(
                    src=sym.id,
                    dst=base_sym.id,
                    edge_type="extends",
                    line=sym.span.start_line if sym.span else 0,
                    confidence=0.95,
                    origin=PASS_ID,
                    origin_run_id=run.execution_id,
                    evidence_type="ast_extends",
                )
                edges.append(edge)

    return edges


def _extract_file_analysis(
    py_file: Path,
    repo_root: Path | None = None,
    source_roots: list[Path] | None = None,
) -> FileAnalysis | None:
    """Extract symbols and imports from a single file.

    Args:
        py_file: Path to the Python file
        repo_root: Repository root for resolving relative imports. If None,
                   relative imports won't be fully resolved.
        source_roots: For src/ layout projects, the source directories
                     (e.g., ``[repo/src]`` or per-package
                     ``[packages/A/src, packages/B/src]``). Used for correct
                     module name calculation.

    Returns None if the file cannot be parsed.
    """
    try:
        source = py_file.read_text()
        # Suppress SyntaxWarning from invalid escape sequences in analyzed code.
        # These warnings come from the target codebase, not hypergumbo.
        with warnings.catch_warnings():
            warnings.filterwarnings("ignore", category=SyntaxWarning)
            tree = ast.parse(source, filename=str(py_file))
    except (SyntaxError, UnicodeDecodeError):
        return None

    symbols = []
    symbol_by_name: dict[str, Symbol] = {}

    # WI-gipag: extract the module-level __all__ (if any) once up front
    # so each top-level Symbol extraction can decide is_exported without
    # re-walking the tree. None means "no __all__ found" → fall back to
    # the leading-underscore rule.
    module_all = _extract_module_all(tree)

    # Create <module> pseudo-node for files with module-level executable code.
    # This provides an enclosing scope for linker synthetic nodes at module level,
    # enabling slice traversal for script-only files (no functions/classes).
    if _has_module_level_code(tree):
        end_line = _get_file_end_line(source)
        module_name = py_file.name  # e.g., "producer_ccsr.py"
        module_span = Span(
            start_line=1,
            end_line=end_line,
            start_col=0,
            end_col=0,
        )

        # Detect structural entry point: if __name__ == "__main__"
        # This concept enables entrypoint detection for executable Python scripts
        # main_guard indicates "if __name__ == '__main__':" pattern
        module_meta: dict[str, object] | None = None
        if _has_main_guard(tree):
            module_meta = {"concepts": [{"concept": "main_guard", "framework": "python"}]}

        module_symbol = Symbol(
            id=_make_symbol_id(str(py_file), 1, end_line, f"<module:{module_name}>", "module"),
            name=f"<module:{module_name}>",
            kind="module",
            language="python",
            path=str(py_file),
            span=module_span,
            origin="",
            origin_run_id="",
            meta=module_meta,
        )
        symbols.append(module_symbol)
        symbol_by_name["<module>"] = module_symbol

    # WI-gafog E2: emit Symbols for module-level NAME = ... so that
    # `from <mod> import NAME` resolves cross-file rather than externalising.
    for cs in _emit_module_level_assign_symbols(tree, py_file, module_all):
        symbols.append(cs)
        symbol_by_name[cs.name] = cs

    # Track functions already processed as methods (to avoid duplicates)
    # Key: (start_line, name) tuple
    processed_functions: set[tuple[int, str]] = set()

    # Scan for APIRouter prefix assignments (for route path composition)
    router_prefixes = _scan_router_prefixes(tree, repo_root, py_file)

    for node in ast.walk(tree):
        if isinstance(node, ast.ClassDef):
            class_name = node.name
            end_line = node.end_lineno or node.lineno
            end_col = node.end_col_offset or 0
            span = Span(
                start_line=node.lineno,
                end_line=end_line,
                start_col=node.col_offset,
                end_col=end_col,
            )

            # Build rich metadata for class (ADR-0003)
            class_meta: dict[str, object] = {}

            # Extract decorators with arguments
            if node.decorator_list:
                class_meta["decorators"] = [
                    _extract_decorator_info(dec) for dec in node.decorator_list
                ]

            # Extract base classes
            if node.bases:
                class_meta["base_classes"] = [
                    _format_annotation(base) for base in node.bases
                ]

            _ds = ast.get_docstring(node)
            _ds_line = _ds.split("\n")[0].strip()[:80] if _ds else None
            # WI-gipag: decide is_exported for top-level class symbols via
            # the module's __all__ (if present) or the leading-underscore
            # convention. Only top-level classes are candidates for public
            # API here — nested classes defined inside functions are not
            # externally reachable regardless of naming.
            class_is_exported = (
                node.col_offset == 0
                and _is_python_top_level_exported(node.name, module_all)
            )
            symbol = Symbol(
                id=_make_symbol_id(str(py_file), node.lineno, end_line, node.name, "class"),
                name=node.name,
                kind="class",
                language="python",
                path=str(py_file),
                span=span,
                stable_id=_compute_stable_id(node),
                shape_id=_compute_shape_id(node),
                cyclomatic_complexity=_compute_cyclomatic_complexity(node),
                lines_of_code=_compute_lines_of_code(node),
                meta=class_meta if class_meta else None,
                docstring=_ds_line,
                modifiers=_python_visibility_modifiers(node.name),
                is_exported=class_is_exported,
            )
            symbols.append(symbol)
            symbol_by_name[node.name] = symbol

            # Extract methods inside the class
            for item in node.body:
                if isinstance(item, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    method_end_line = item.end_lineno or item.lineno
                    method_end_col = item.end_col_offset or 0
                    method_span = Span(
                        start_line=item.lineno,
                        end_line=method_end_line,
                        start_col=item.col_offset,
                        end_col=method_end_col,
                    )
                    method_name = f"{class_name}.{item.name}"

                    # For Django/DRF class-based views, methods named get/post/etc.
                    # use route-style stable_id with class name as path for uniqueness
                    # (ADR-0014 §4: sha256("route:{method}:{path}"))
                    if item.name.lower() in HTTP_METHODS:
                        stable_id = make_route_stable_id(item.name, class_name)
                    else:
                        # Try typed tier first (ADR-0014 §3), fall back to untyped
                        sig = _format_function_signature(item)
                        norm_sig = normalize_python_signature(sig)
                        modifiers = _python_visibility_modifiers(method_name)
                        if norm_sig:
                            stable_id = make_typed_stable_id(
                                "method", norm_sig,
                                visibility_from_modifiers(modifiers),
                                symbol.stable_id,
                                _extract_py_decorator_names(item),
                            )
                        else:
                            stable_id = _compute_stable_id(
                                item, containing_stable_id=symbol.stable_id
                            )

                    # Build rich metadata for method (ADR-0003)
                    method_meta: dict[str, object] = {}

                    # Extract decorators with arguments
                    if item.decorator_list:
                        method_meta["decorators"] = [
                            _extract_decorator_info(dec) for dec in item.decorator_list
                        ]
                        # Check if any decorator references a prefixed APIRouter
                        if router_prefixes:
                            for dec_info in method_meta["decorators"]:
                                dec_name = dec_info.get("name", "") if isinstance(dec_info, dict) else ""
                                dot_idx = dec_name.find(".")
                                if dot_idx > 0:
                                    receiver = dec_name[:dot_idx]
                                    if receiver in router_prefixes:
                                        method_meta["router_prefix"] = router_prefixes[receiver]
                                        break

                    # Extract structured parameters (excluding self/cls)
                    params = _extract_parameters_info(item.args, exclude_self=True)
                    if params:
                        method_meta["parameters"] = params

                    _mds = ast.get_docstring(item)
                    _mds_line = _mds.split("\n")[0].strip()[:80] if _mds else None
                    method_symbol = Symbol(
                        id=_make_symbol_id(str(py_file), item.lineno, method_end_line, method_name, "method"),
                        name=method_name,
                        kind="method",
                        language="python",
                        path=str(py_file),
                        span=method_span,
                        stable_id=stable_id,
                        shape_id=_compute_shape_id(item),
                        cyclomatic_complexity=_compute_cyclomatic_complexity(item),
                        lines_of_code=_compute_lines_of_code(item),
                        signature=_format_function_signature(item),
                        docstring=_mds_line,
                        meta=method_meta if method_meta else None,
                        modifiers=_python_visibility_modifiers(method_name),
                    )
                    symbols.append(method_symbol)
                    # Store by short name for self.method() lookups
                    symbol_by_name[item.name] = method_symbol
                    # Track as processed to avoid duplicate extraction
                    processed_functions.add((item.lineno, item.name))

        elif isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            # Skip if already processed as a class method
            if (node.lineno, node.name) in processed_functions:
                continue

            # Extract functions that are either:
            # 1. Top-level (col_offset == 0) - always extract
            # 2. Nested but have decorators - extract for patterns like FastAPI router factories
            #    where route handlers are defined as decorated nested functions:
            #        def get_router():
            #            router = APIRouter()
            #            @router.get("/items")  # <-- This should be extracted
            #            def list_items(): ...
            is_top_level = node.col_offset == 0
            has_decorators = bool(node.decorator_list)

            if is_top_level or has_decorators:
                # Track as processed
                processed_functions.add((node.lineno, node.name))
                end_line = node.end_lineno or node.lineno
                end_col = node.end_col_offset or 0
                span = Span(
                    start_line=node.lineno,
                    end_line=end_line,
                    start_col=node.col_offset,
                    end_col=end_col,
                )

                # Build rich metadata for function (ADR-0003)
                # Route detection moved to FRAMEWORK_PATTERNS phase
                func_meta: dict[str, object] = {}

                # Extract decorators with arguments
                if node.decorator_list:
                    func_meta["decorators"] = [
                        _extract_decorator_info(dec) for dec in node.decorator_list
                    ]
                    # Check if any decorator references a prefixed APIRouter
                    if router_prefixes:
                        for dec_info in func_meta["decorators"]:
                            dec_name = dec_info.get("name", "") if isinstance(dec_info, dict) else ""
                            dot_idx = dec_name.find(".")
                            if dot_idx > 0:
                                receiver = dec_name[:dot_idx]
                                if receiver in router_prefixes:
                                    func_meta["router_prefix"] = router_prefixes[receiver]
                                    break

                # Extract structured parameters
                params = _extract_parameters_info(node.args, exclude_self=False)
                if params:
                    func_meta["parameters"] = params

                # Try typed tier first (ADR-0014 §3), fall back to untyped
                func_sig = _format_function_signature(node)
                func_modifiers = _python_visibility_modifiers(node.name)
                norm_sig = normalize_python_signature(func_sig)
                if norm_sig:
                    func_stable_id = make_typed_stable_id(
                        "function", norm_sig,
                        visibility_from_modifiers(func_modifiers),
                        decorators=_extract_py_decorator_names(node),
                    )
                else:
                    func_stable_id = _compute_stable_id(node)

                _fds = ast.get_docstring(node)
                _fds_line = _fds.split("\n")[0].strip()[:80] if _fds else None
                # WI-gipag: only top-level functions are candidates for
                # the public API. Nested functions captured here (because
                # they carry decorators, per the router-factory rule
                # above) are never externally reachable via __all__, so
                # is_exported stays False.
                func_is_exported = (
                    is_top_level
                    and _is_python_top_level_exported(node.name, module_all)
                )
                symbol = Symbol(
                    id=_make_symbol_id(str(py_file), node.lineno, end_line, node.name, "function"),
                    name=node.name,
                    kind="function",
                    language="python",
                    path=str(py_file),
                    span=span,
                    stable_id=func_stable_id,
                    shape_id=_compute_shape_id(node),
                    meta=func_meta if func_meta else None,
                    cyclomatic_complexity=_compute_cyclomatic_complexity(node),
                    lines_of_code=_compute_lines_of_code(node),
                    signature=func_sig,
                    docstring=_fds_line,
                    modifiers=func_modifiers,
                    is_exported=func_is_exported,
                )
                symbols.append(symbol)
                symbol_by_name[node.name] = symbol

    # Extract usage contexts for call-based frameworks (v1.1.x).
    # UsageContext records feed into YAML-driven enrichment (concept tagging on
    # handler symbols). Route symbols are derived from the same contexts for the
    # route_handler linker, which needs kind="route" symbols to create routes_to
    # edges. See "Route Detection Architecture" in this module's docstring.
    usage_contexts: list[UsageContext] = []
    # Collect module-level string constants for route path resolution.
    # Enables constant propagation: path(BASE + "/users/", view) → "/api/v1/users/".
    route_local_constants, route_imports = _collect_module_constants(
        tree, repo_root, py_file,
    )
    django_contexts = _extract_django_usage_contexts(
        tree, str(py_file), symbol_by_name,
        local_constants=route_local_constants,
        imports=route_imports,
        repo_root=repo_root,
    )
    usage_contexts.extend(django_contexts)
    # router_prefixes already computed above (before the symbol extraction loop)
    flask_contexts = _extract_flask_usage_contexts(
        tree, str(py_file), symbol_by_name, router_prefixes,
        local_constants=route_local_constants,
        imports=route_imports,
        repo_root=repo_root,
    )
    usage_contexts.extend(flask_contexts)
    starlette_contexts = _extract_starlette_usage_contexts(
        tree, str(py_file), symbol_by_name,
        imports=route_imports,
    )
    usage_contexts.extend(starlette_contexts)

    # Create route symbols from Django usage contexts.
    #
    # WI-lojoh: class-based views (registered via Cls.as_view()) get
    # http_method="ANY" so the post-pass `expand_class_based_view_routes`
    # can introspect the view class's get/post/put/patch/delete/head/options
    # methods and emit one route variant per declared method. When the view
    # class lives outside the analyzed repo (e.g. django.contrib.auth.views),
    # the route stays at "ANY" — better than fabricating a wrong "GET".
    # Function-based views keep "GET" (Django dispatches them for any HTTP
    # verb, but GET is the conventional default for static-analysis output).
    for ctx in django_contexts:
        route_path = ctx.metadata.get("route_path", "")
        view_name = ctx.metadata.get("view_name")
        is_cbv = bool(ctx.metadata.get("is_class_based_view"))
        http_method = "ANY" if is_cbv else "GET"
        meta = {
            "route_path": route_path,
            "http_method": http_method,
            "view_name": view_name,
            "framework_role": "route",
        }
        if is_cbv:
            meta["is_class_based_view"] = True
        symbol = Symbol(
            id=_make_symbol_id(str(py_file), ctx.span.start_line, ctx.span.end_line, route_path, "route"),
            name=f"django:{view_name or 'unknown'}",
            kind="function",
            language="python",
            path=str(py_file),
            span=ctx.span,
            stable_id=make_route_stable_id(http_method, route_path),
            meta=meta,
        )
        symbols.append(symbol)

    # Create route symbols from Starlette Route/WebSocketRoute usage contexts.
    # Starlette routes are constructor calls, not method calls on app/router,
    # so emitting kind="route" here mirrors the Django path rather than the
    # YAML-only path used for Flask add_url_rule / FastAPI add_api_route.
    for ctx in starlette_contexts:
        route_path = ctx.metadata.get("route_path", "")
        view_name = ctx.metadata.get("view_name")
        methods = ctx.metadata.get("methods") or ["GET"]
        receiver = ctx.metadata.get("receiver", "Route")
        # Multiple methods → one route symbol per method, matching the
        # convention used elsewhere in this codebase.
        for method in methods:
            symbol = Symbol(
                id=_make_symbol_id(
                    str(py_file), ctx.span.start_line, ctx.span.end_line,
                    f"{method}:{route_path}", "route",
                ),
                name=f"starlette:{view_name or 'unknown'}",
                kind="function",
                language="python",
                path=str(py_file),
                span=ctx.span,
                stable_id=make_route_stable_id(method, route_path),
                meta={
                    "route_path": route_path,
                    "http_method": method,
                    "view_name": view_name,
                    "handler_ref": ctx.symbol_ref,
                    "framework": "starlette",
                    "route_class": receiver,
                    "framework_role": "route",
                },
            )
            symbols.append(symbol)

    # Create route symbols from Flask-RESTful add_resource usage contexts.
    # add_resource registers all HTTP methods the Resource class defines,
    # but we don't know which methods at static analysis time, so we use
    # ANY as the method.
    for ctx in flask_contexts:
        if ctx.position != "resource_class":
            continue
        route_path = ctx.metadata.get("route_path", "")
        view_name = ctx.metadata.get("view_name")
        symbol = Symbol(
            id=_make_symbol_id(str(py_file), ctx.span.start_line, ctx.span.end_line, route_path, "route"),
            name=f"{view_name or 'unknown'}",
            kind="function",
            language="python",
            path=str(py_file),
            span=ctx.span,
            stable_id=make_route_stable_id("ANY", route_path),
            meta={
                "route_path": route_path,
                "http_method": "ANY",
                "view_name": view_name,
                "handler_ref": ctx.symbol_ref,
                "framework_role": "route",
            },
        )
        symbols.append(symbol)

    # Compute module name for import resolution
    if repo_root is not None:
        importing_module = _module_name_from_path(py_file, repo_root, source_roots)
    else:
        importing_module = py_file.stem  # Fallback to just filename
    symbol_imports, module_imports = _extract_imports(tree, importing_module)
    return FileAnalysis(
        symbols=symbols,
        symbol_by_name=symbol_by_name,
        imports=symbol_imports,
        module_imports=module_imports,
        tree=tree,
        usage_contexts=usage_contexts,
        source=source,
    )


def _extract_edges(
    tree: ast.AST,
    local_symbols: dict[str, Symbol],
    imports: dict[str, tuple[str, str]],
    global_symbols: dict[tuple[str, str], Symbol],
    module_imports: dict[str, str] | None = None,
    resolver: "SymbolResolver | None" = None,
    _sym_by_path_name: dict[tuple[str, str], Symbol] | None = None,
) -> list[Edge]:
    """Extract call and instantiation edges from an AST.

    Resolves both local and cross-file calls/instantiations.

    Handles:
    - Direct calls: helper(), ClassName()
    - Self method calls: self.method()
    - Self field method calls: self.field.method() (using field type inference from __init__)
    - Module-qualified calls: module.ClassName(), module.func()
    - Variable method calls: variable.method() (with constructor-only type inference)

    Type inference sources:
    1. Direct constructor calls: stub = Client() → var_types['stub'] = Client
    2. Return type annotations: stub = get_client() where get_client() -> Client
       → var_types['stub'] = Client (requires annotation on the function)
    3. Parameter type annotations: def f(session: Session) → param maps to Session

    Field type inference tracks self.field assignments in __init__ from typed params
    and constructor calls.

    Args:
        tree: The parsed AST
        local_symbols: Symbols defined in this file
        imports: Symbol imports (from X import Y)
        global_symbols: All symbols across the project
        module_imports: Module imports (import X, import X as Y)
        resolver: Optional SymbolResolver for efficient cross-file lookups
    """
    if module_imports is None:  # pragma: no cover
        module_imports = {}

    edges: list[Edge] = []

    def _emit_function_ref(name_node: ast.Name, caller: Symbol) -> None:
        """Emit a 'references' edge if *name_node* resolves to a function/method.

        Used for function references in non-call contexts: call arguments,
        dict values, variable assignments, and collection literals.
        """
        name = name_node.id
        symbol = local_symbols.get(name)
        if not symbol and name in imports:
            mod_name, original_name = imports[name]
            symbol = _lookup_symbol_by_module(
                global_symbols, mod_name, original_name, resolver=resolver
            )
        if symbol and symbol.kind in ("function", "method"):
            edges.append(Edge.create(
                src=caller.id,
                dst=symbol.id,
                edge_type="references",
                line=name_node.lineno,
                confidence=0.80,
                evidence_type="function_reference",
            ))

    def _emit_module_attr_refs(
        block_nodes: list[ast.AST],
        caller_symbol: Symbol,
    ) -> None:
        """Emit ``module_attr_ref`` edges for attribute reads on imported modules.

        Targets patterns like ``os.environ[...]``, ``sys.argv``, ``sys.path``:
        an imported module name followed by an attribute access that is NOT
        itself the callable of a function call (those are handled by the
        calls pipeline and matched against the YAML ``functions:``/``methods:``
        entries).  This emission pairs with ``attributes:`` entries in the
        io_primitives YAML catalog, which were previously dead metadata —
        without an edge to match, ``io-boundaries`` silently under-reported
        env_read / ipc_send chains (WI-guhok).
        """
        # Pre-collect Attribute-node ids that are the direct callee of a Call
        # so we can skip them below — `os.getenv("X")` already produces a
        # `calls` edge and doesn't need a redundant `module_attr_ref`.
        call_func_attr_ids: set[int] = set()
        for root in block_nodes:
            for sub in ast.walk(root):
                if isinstance(sub, ast.Call) and isinstance(sub.func, ast.Attribute):
                    call_func_attr_ids.add(id(sub.func))

        for root in block_nodes:
            for sub in ast.walk(root):
                if not isinstance(sub, ast.Attribute):
                    continue
                if id(sub) in call_func_attr_ids:
                    continue
                if not isinstance(sub.value, ast.Name):
                    continue
                local_name = sub.value.id
                if local_name not in module_imports:
                    continue
                real_module = module_imports[local_name]
                qname = f"{real_module}.{sub.attr}"
                edges.append(Edge.create(
                    src=caller_symbol.id,
                    dst=f"python:{real_module}:0-0:{qname}:attribute",
                    edge_type="module_attr_ref",
                    line=sub.lineno,
                    confidence=0.85,
                    evidence_type="module_attribute_reference",
                ))

    # Helper to extract edges from a code block (function body, module level, etc.)
    def process_code_block(
        block_nodes: list[ast.AST],
        caller_symbol: Symbol,
        var_types: dict[str, Symbol] | None = None,
    ) -> None:
        """Process AST nodes within a code block, tracking variable types."""
        if var_types is None:
            var_types = {}

        for node in block_nodes:
            # Track variable assignments for type inference
            # e.g., stub = EmailServiceStub(channel) -> var_types['stub'] = EmailServiceStub
            if isinstance(node, ast.Assign):
                for target in node.targets:
                    if isinstance(target, ast.Name) and isinstance(node.value, ast.Call):
                        assigned_class = _resolve_call_target(
                            node.value, local_symbols, imports, global_symbols,
                            module_imports, resolver
                        )
                        if assigned_class and assigned_class.kind == "class":
                            var_types[target.id] = assigned_class
                        elif assigned_class and assigned_class.kind in ("function", "method"):
                            # Return type inference: if the function has a
                            # return type annotation pointing to a class,
                            # track the variable's type from that annotation.
                            ret_name = _extract_return_type_name(
                                assigned_class.signature
                            )
                            if ret_name:
                                ret_class = _resolve_return_type_class(
                                    ret_name, assigned_class, local_symbols,
                                    imports, global_symbols, resolver,
                                    _sym_by_path_name,
                                )
                                if ret_class:
                                    var_types[target.id] = ret_class

            # Function reference in assignment RHS: callback = my_func
            if isinstance(node, ast.Assign) and isinstance(node.value, ast.Name):
                _emit_function_ref(node.value, caller_symbol)

            # Process calls
            if isinstance(node, ast.Call):
                _process_call(
                    node, caller_symbol, local_symbols, imports, global_symbols,
                    module_imports, var_types, edges, resolver,
                    sym_by_path_name=_sym_by_path_name,
                )
                # Function references in call arguments: map(transform, items)
                for arg in node.args:
                    if isinstance(arg, ast.Name):
                        _emit_function_ref(arg, caller_symbol)
                for kw in node.keywords:
                    if isinstance(kw.value, ast.Name):
                        _emit_function_ref(kw.value, caller_symbol)

            # Function references in dict values: {"GET": handle_get}
            if isinstance(node, ast.Dict):
                for val in node.values:
                    if isinstance(val, ast.Name):
                        _emit_function_ref(val, caller_symbol)

            # Function references in list/tuple: [func_a, func_b]
            if isinstance(node, (ast.List, ast.Tuple)):
                for elt in node.elts:
                    if isinstance(elt, ast.Name):
                        _emit_function_ref(elt, caller_symbol)

            # Recurse into child nodes (but not into nested function defs)
            for child in ast.iter_child_nodes(node):
                if not isinstance(child, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
                    process_code_block([child], caller_symbol, var_types)

    def _extract_param_types(
        func_node: ast.FunctionDef | ast.AsyncFunctionDef,
    ) -> dict[str, Symbol]:
        """Extract type information from function parameter annotations.

        Handles simple annotations like:
        - def f(session: Session) -> session maps to Session class
        - def f(item: Item) -> item maps to Item class

        Does not currently handle:
        - Generic types: Optional[T], List[T], etc.
        - String annotations: "Session"
        """
        param_types: dict[str, Symbol] = {}

        for arg in func_node.args.args + func_node.args.kwonlyargs:
            if arg.annotation is None:
                continue

            param_name = arg.arg
            annotation = arg.annotation

            # Handle simple name annotations: param: ClassName
            if isinstance(annotation, ast.Name):
                type_name = annotation.id

                # Check local symbols first
                class_symbol = local_symbols.get(type_name)
                if class_symbol and class_symbol.kind == "class":
                    param_types[param_name] = class_symbol
                    continue

                # Check imports (with suffix matching)
                if type_name in imports:
                    module_name, original_name = imports[type_name]
                    class_symbol = _lookup_symbol_by_module(
                        global_symbols, module_name, original_name, resolver=resolver
                    )
                    if class_symbol and class_symbol.kind == "class":
                        param_types[param_name] = class_symbol

            # Handle attribute annotations: param: module.ClassName
            elif isinstance(annotation, ast.Attribute) and isinstance(
                annotation.value, ast.Name
            ):
                receiver_name = annotation.value.id
                attr_name = annotation.attr
                if receiver_name in module_imports:
                    module_name = module_imports[receiver_name]
                    class_symbol = _lookup_symbol_by_module(
                        global_symbols, module_name, attr_name, resolver=resolver
                    )
                    if class_symbol and class_symbol.kind == "class":
                        param_types[param_name] = class_symbol

        return param_types

    def _resolve_decorator_target(
        decorator: ast.expr,
    ) -> Symbol | None:
        """Resolve the target of a decorator expression to a Symbol.

        Handles:
        - @decorator -> decorator function
        - @decorator(args) -> decorator function
        - @module.decorator -> module.decorator function
        - @app.get("/path") -> app.get method
        """
        # For Call decorators, extract the actual function being called
        # @decorator(args) or @app.get("/path")
        if isinstance(decorator, ast.Call):
            decorator = decorator.func

        # Simple name: @decorator or @dataclass
        if isinstance(decorator, ast.Name):
            name = decorator.id
            # Check local symbols
            symbol = local_symbols.get(name)
            if symbol:
                return symbol
            # Check imports (with suffix matching)
            if name in imports:
                module_name, original_name = imports[name]
                return _lookup_symbol_by_module(
                    global_symbols, module_name, original_name, resolver=resolver
                )

        # Attribute: @module.decorator or @app.get
        elif isinstance(decorator, ast.Attribute):
            if isinstance(decorator.value, ast.Name):
                receiver_name = decorator.value.id
                attr_name = decorator.attr

                # Check if receiver is a local class (e.g., @Registry.register)
                # Methods are stored with short name as key, so look up attr_name
                # and verify it's a method of the receiver class
                symbol = local_symbols.get(attr_name)
                if symbol and symbol.name == f"{receiver_name}.{attr_name}":
                    return symbol

                # Check if receiver is an imported module (with suffix matching)
                if receiver_name in module_imports:
                    module_name = module_imports[receiver_name]
                    return _lookup_symbol_by_module(
                        global_symbols, module_name, attr_name, resolver=resolver
                    )

        return None

    def _process_decorators(
        decorated_symbol: Symbol,
        decorator_list: list[ast.expr],
    ) -> None:
        """Create decorated_by edges for each decorator on a symbol."""
        for decorator in decorator_list:
            decorator_symbol = _resolve_decorator_target(decorator)

            # Get the line number from the decorator itself
            line = getattr(decorator, "lineno", 0)

            if decorator_symbol:
                edges.append(Edge.create(
                    src=decorated_symbol.id,
                    dst=decorator_symbol.id,
                    edge_type="decorated_by",
                    line=line,
                    evidence_type="ast_decorator",
                    confidence=0.95,
                ))
            else:
                # Emit unresolved edge for decorators we can't resolve
                # This helps track framework decorators like @app.get
                if isinstance(decorator, ast.Call):
                    dec_func = decorator.func
                else:
                    dec_func = decorator

                if isinstance(dec_func, ast.Attribute) and isinstance(
                    dec_func.value, ast.Name
                ):
                    receiver_name = dec_func.value.id
                    attr_name = dec_func.attr
                    dst_id = f"python:unresolved:0-0:{receiver_name}.{attr_name}:unresolved"
                    edges.append(Edge.create(
                        src=decorated_symbol.id,
                        dst=dst_id,
                        edge_type="decorated_by",
                        line=line,
                        evidence_type="ast_decorator",
                        is_resolved=False,
                        confidence=0.50,
                    ))

            # Check for Django signal receiver decorator: @receiver(signal, ...)
            # Creates signal_receiver edges from signal to handler
            _process_signal_receiver(decorated_symbol, decorator, line)

    def _process_signal_receiver(
        decorated_symbol: Symbol,
        decorator: ast.expr,
        line: int,
    ) -> None:
        """Create signal_receiver edges for Django @receiver decorators.

        When a function is decorated with @receiver(signal) or @receiver([sig1, sig2]),
        create signal_receiver edges from each signal to the decorated function.
        """
        # Must be a call: @receiver(signal, ...)
        if not isinstance(decorator, ast.Call):
            return

        # Check if decorator is "receiver"
        dec_func = decorator.func
        decorator_name = None
        if isinstance(dec_func, ast.Name):
            decorator_name = dec_func.id
        elif isinstance(dec_func, ast.Attribute):
            decorator_name = dec_func.attr

        if decorator_name != "receiver":
            return

        # Extract signals from first argument
        if not decorator.args:
            return

        first_arg = decorator.args[0]
        signal_nodes: list[ast.expr] = []

        # Handle @receiver([signal1, signal2])
        if isinstance(first_arg, ast.List):
            signal_nodes = first_arg.elts
        else:
            # Single signal: @receiver(post_save)
            signal_nodes = [first_arg]

        # Create signal_receiver edges for each signal
        for signal_node in signal_nodes:
            signal_symbol = None

            if isinstance(signal_node, ast.Name):
                signal_name = signal_node.id
                signal_symbol = local_symbols.get(signal_name)
                if not signal_symbol and signal_name in imports:
                    module_name, original_name = imports[signal_name]
                    signal_symbol = _lookup_symbol_by_module(
                        global_symbols, module_name, original_name, resolver=resolver
                    )

            if signal_symbol:
                edges.append(Edge.create(
                    src=signal_symbol.id,
                    dst=decorated_symbol.id,
                    edge_type="signal_receiver",
                    line=line,
                    evidence_type="ast_decorator",
                    confidence=0.90,
                    meta={"framework_dispatch": "django_signal"},
                ))
            elif isinstance(signal_node, ast.Name):
                # Unresolved signal - emit edge anyway for visibility
                dst_id = f"python:unresolved:0-0:{signal_node.id}:signal"
                edges.append(Edge.create(
                    src=dst_id,
                    dst=decorated_symbol.id,
                    edge_type="signal_receiver",
                    line=line,
                    evidence_type="ast_decorator",
                    is_resolved=False,
                    confidence=0.50,
                    meta={"framework_dispatch": "django_signal"},
                ))

    # Pre-collect class field types for self.field.method() resolution (INV-014).
    # Scans __init__ methods for self.field = param (typed) and self.field = Class()
    # assignments, building a per-class map of field name -> type Symbol.
    class_field_types: dict[str, dict[str, Symbol]] = {}
    for node in ast.walk(tree):
        if not isinstance(node, ast.ClassDef):
            continue
        init_method = None
        for item in node.body:
            if isinstance(item, (ast.FunctionDef, ast.AsyncFunctionDef)) and item.name == "__init__":
                init_method = item
                break
        if init_method is None:
            continue
        init_param_types = _extract_param_types(init_method)
        field_types: dict[str, Symbol] = {}
        for stmt in ast.walk(init_method):
            if not isinstance(stmt, ast.Assign):
                continue
            for target in stmt.targets:
                if (
                    isinstance(target, ast.Attribute)
                    and isinstance(target.value, ast.Name)
                    and target.value.id == "self"
                ):
                    field_name = target.attr
                    # self.field = param where param has type annotation
                    if isinstance(stmt.value, ast.Name) and stmt.value.id in init_param_types:
                        field_types[field_name] = init_param_types[stmt.value.id]
                    # self.field = ClassName()
                    elif isinstance(stmt.value, ast.Call):
                        assigned_class = _resolve_call_target(
                            stmt.value, local_symbols, imports, global_symbols,
                            module_imports, resolver
                        )
                        if assigned_class and assigned_class.kind == "class":
                            field_types[field_name] = assigned_class
        if field_types:
            class_field_types[node.name] = field_types

    # Process functions (including async functions)
    for node in ast.walk(tree):
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            caller_symbol = local_symbols.get(node.name)
            if caller_symbol:
                # Process decorators on the function
                _process_decorators(caller_symbol, node.decorator_list)
                # Extract types from parameter annotations
                param_types = _extract_param_types(node)
                # Merge class field types for self.field.method() resolution
                if caller_symbol.kind == "method":
                    class_name = caller_symbol.name.split(".")[0]
                    if class_name in class_field_types:
                        for fname, fsym in class_field_types[class_name].items():
                            if fname not in param_types:
                                param_types[fname] = fsym
                _emit_module_attr_refs(node.body, caller_symbol)
                process_code_block(node.body, caller_symbol, param_types)

        # Process class decorators
        elif isinstance(node, ast.ClassDef):
            class_symbol = local_symbols.get(node.name)
            if class_symbol:
                _process_decorators(class_symbol, node.decorator_list)

    # Process module-level code for <module> pseudo-nodes
    module_symbol = local_symbols.get("<module>")
    if module_symbol:
        # Get top-level statements (excluding function/class defs)
        module_level_nodes = [
            node for node in tree.body
            if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef))
        ]
        _emit_module_attr_refs(module_level_nodes, module_symbol)
        process_code_block(module_level_nodes, module_symbol)

    return edges


def _unwind_attribute_chain(
    node: ast.Attribute,
) -> tuple[ast.Name, list[str]] | None:
    """Walk an ``ast.Attribute`` chain back to its root ``ast.Name``.

    Given ``a.b.c.d`` — parsed as
    ``Attribute(Attribute(Attribute(Name('a'), 'b'), 'c'), 'd')`` — returns
    ``(Name('a'), ['b', 'c', 'd'])``. Attributes are returned root-to-leaf.

    Returns ``None`` when the chain's root is not an ``ast.Name`` (e.g.,
    ``f().x.y`` roots at a ``Call``, ``(a+b).c`` at a ``BinOp``). Those
    receivers don't participate in import-qualified call resolution and
    would be misresolved if we pretended they did.
    """
    attrs: list[str] = []
    current: ast.expr = node
    while isinstance(current, ast.Attribute):
        attrs.append(current.attr)
        current = current.value
    if not isinstance(current, ast.Name):
        return None
    attrs.reverse()
    return current, attrs


def _resolve_call_target(
    call_node: ast.Call,
    local_symbols: dict[str, Symbol],
    imports: dict[str, tuple[str, str]],
    global_symbols: dict[tuple[str, str], Symbol],
    module_imports: dict[str, str],
    resolver: "SymbolResolver | None" = None,
) -> Symbol | None:
    """Resolve the target of a call expression to a Symbol.

    Handles:
    - ClassName() -> class symbol
    - module.ClassName() -> class symbol in module
    - imported_name() -> resolved symbol
    """
    func = call_node.func

    # Simple name: ClassName() or func()
    if isinstance(func, ast.Name):
        name = func.id
        # Check local symbols
        symbol = local_symbols.get(name)
        if symbol:
            return symbol
        # Check imports (with suffix matching)
        if name in imports:
            module_name, original_name = imports[name]
            return _lookup_symbol_by_module(
                global_symbols, module_name, original_name, resolver=resolver
            )

    # Attribute: module.ClassName() or obj.method()
    elif isinstance(func, ast.Attribute):
        if isinstance(func.value, ast.Name):
            receiver_name = func.value.id
            attr_name = func.attr

            # Check if receiver is an imported module (with suffix matching)
            if receiver_name in module_imports:
                module_name = module_imports[receiver_name]
                return _lookup_symbol_by_module(
                    global_symbols, module_name, attr_name, resolver=resolver
                )

    return None


def _process_call(
    call_node: ast.Call,
    caller_symbol: Symbol,
    local_symbols: dict[str, Symbol],
    imports: dict[str, tuple[str, str]],
    global_symbols: dict[tuple[str, str], Symbol],
    module_imports: dict[str, str],
    var_types: dict[str, Symbol],
    edges: list[Edge],
    resolver: "SymbolResolver | None" = None,
    sym_by_path_name: dict[tuple[str, str], Symbol] | None = None,
) -> None:
    """Process a single call expression and emit appropriate edges.

    Handles:
    - Direct calls: helper(), ClassName()
    - Self method calls: self.method()
    - Self field method calls: self.field.method() (using field type inference)
    - Module-qualified calls: module.ClassName(), module.func()
    - Variable method calls: stub.method() (using var_types for type inference)
    """
    func = call_node.func
    callee_symbol = None
    is_instantiation = False
    evidence_type = "ast_call_direct"

    # Case 1: Simple name calls - helper() or ClassName()
    if isinstance(func, ast.Name):
        callee_name = func.id
        callee_symbol = local_symbols.get(callee_name)

        if callee_symbol and callee_symbol.kind == "class":
            is_instantiation = True
        elif not callee_symbol and callee_name in imports:
            module_name, original_name = imports[callee_name]
            callee_symbol = _lookup_symbol_by_module(
                global_symbols, module_name, original_name, resolver=resolver
            )
            if callee_symbol and callee_symbol.kind == "class":
                is_instantiation = True

    # Case 2: Attribute calls - self.method(), module.ClassName(), variable.method()
    elif isinstance(func, ast.Attribute):
        attr_name = func.attr
        evidence_type = "ast_call_method"

        if isinstance(func.value, ast.Name):
            receiver_name = func.value.id

            # Case 2a: self.method()
            if receiver_name == "self":
                callee_symbol = local_symbols.get(attr_name)

            # Case 2b: module.ClassName() or module.func()
            elif receiver_name in module_imports:
                module_name = module_imports[receiver_name]
                callee_symbol = _lookup_symbol_by_module(
                    global_symbols, module_name, attr_name, resolver=resolver
                )
                if callee_symbol and callee_symbol.kind == "class":
                    is_instantiation = True

            # Case 2c: variable.method() - use type inference
            elif receiver_name in var_types:
                class_symbol = var_types[receiver_name]
                # Look for ClassName.method in local symbols
                qualified_name = f"{class_symbol.name}.{attr_name}"
                callee_symbol = local_symbols.get(qualified_name)
                # If not found locally, try global symbols via index
                if not callee_symbol and sym_by_path_name is not None:
                    callee_symbol = sym_by_path_name.get(
                        (class_symbol.path, qualified_name)
                    )

            # Case 2d: Imported class method calls - Item.model_validate()
            # When Item is imported via "from app.models import Item"
            elif receiver_name in imports:
                module_name, original_name = imports[receiver_name]
                class_symbol = _lookup_symbol_by_module(
                    global_symbols, module_name, original_name, resolver=resolver
                )
                if class_symbol and class_symbol.kind == "class":
                    # Look for ClassName.method (class method/static method)
                    qualified_name = f"{original_name}.{attr_name}"
                    if sym_by_path_name is not None:
                        callee_symbol = sym_by_path_name.get(
                            (class_symbol.path, qualified_name)
                        )

                # Case 2e: Imported submodule calls - crud.create_user()
                # When crud is imported via "from app import crud" (crud is a module)
                # and we call crud.create_user(), we need to look up (app.crud, create_user)
                if not callee_symbol:
                    submodule_name = f"{module_name}.{original_name}"
                    callee_symbol = _lookup_symbol_by_module(
                        global_symbols, submodule_name, attr_name, resolver=resolver
                    )

        # Case 2f: self.field.method() - call on injected dependency (INV-014)
        # Pattern: self.svc.process() where self.svc was assigned from a typed param
        # or constructor call in __init__. Field types are pre-loaded into var_types.
        elif (
            isinstance(func.value, ast.Attribute)
            and isinstance(func.value.value, ast.Name)
            and func.value.value.id == "self"
        ):
            field_name = func.value.attr
            if field_name in var_types:
                class_symbol = var_types[field_name]
                qualified_name = f"{class_symbol.name}.{attr_name}"
                callee_symbol = local_symbols.get(qualified_name)
                if not callee_symbol and sym_by_path_name is not None:
                    callee_symbol = sym_by_path_name.get(
                        (class_symbol.path, qualified_name)
                    )

    # Emit edge if we resolved the callee
    if callee_symbol:
        if is_instantiation:
            edges.append(Edge.create(
                src=caller_symbol.id,
                dst=callee_symbol.id,
                edge_type="instantiates",
                line=call_node.lineno,
                evidence_type="ast_new",
                confidence=0.95,
            ))
        else:
            edges.append(Edge.create(
                src=caller_symbol.id,
                dst=callee_symbol.id,
                edge_type="calls",
                line=call_node.lineno,
                evidence_type=evidence_type,
            ))
    else:
        # Emit unresolved edge for attribute calls with known module context
        # This enables cross-language linking and makes the graph more complete
        func = call_node.func
        if isinstance(func, ast.Attribute) and isinstance(func.value, ast.Name):
            receiver_name = func.value.id
            attr_name = func.attr

            # Case: module.func() where module is imported but func not found
            if receiver_name in module_imports:
                module_name = module_imports[receiver_name]
                dst_id = f"python:{module_name}:0-0:{attr_name}:unresolved"
                edges.append(Edge.create(
                    src=caller_symbol.id,
                    dst=dst_id,
                    edge_type="calls",
                    line=call_node.lineno,
                    evidence_type="ast_call",
                    is_resolved=False,
                    confidence=0.50,  # Lower confidence for unresolved
                    meta={"call_construct": "method"},
                ))
            # Case: imported_name.method() where imported_name not resolved
            elif receiver_name in imports:
                module_name, original_name = imports[receiver_name]
                dst_id = f"python:{module_name}:0-0:{original_name}.{attr_name}:unresolved"
                edges.append(Edge.create(
                    src=caller_symbol.id,
                    dst=dst_id,
                    edge_type="calls",
                    line=call_node.lineno,
                    evidence_type="ast_call",
                    is_resolved=False,
                    confidence=0.50,
                    meta={"call_construct": "method"},
                ))
            # Case: local_var.method() where type cannot be inferred.
            # Emit unresolved edge using the attribute name so that IO
            # boundary analysis and taint-flow analysis can detect it.
            # Lower confidence since we don't know the receiver type.
            else:
                dst_id = f"python:external:0-0:{attr_name}:unresolved"
                edges.append(Edge.create(
                    src=caller_symbol.id,
                    dst=dst_id,
                    edge_type="calls",
                    line=call_node.lineno,
                    evidence_type="ast_call",
                    is_resolved=False,
                    confidence=0.40,
                    meta={"call_construct": "method", "resolution_quality": "type_inferred"},
                ))
        elif isinstance(func, ast.Attribute):
            # WI-zigah: multi-segment chain like `urllib.request.urlopen(x)`
            # where func.value is itself an Attribute. Walk back to the root
            # Name, look it up in module_imports, and emit a qualified
            # unresolved edge so io-boundaries and taint-flow can match
            # dotted-submodule stdlib primitives.
            chain = _unwind_attribute_chain(func)
            if chain is not None:
                root_name_node, chain_attrs = chain
                root_name = root_name_node.id
                if root_name in module_imports and len(chain_attrs) >= 2:
                    real_root = module_imports[root_name]
                    submodule = real_root + "." + ".".join(chain_attrs[:-1])
                    callee = chain_attrs[-1]
                    dst_id = f"python:{submodule}:0-0:{callee}:unresolved"
                    edges.append(Edge.create(
                        src=caller_symbol.id,
                        dst=dst_id,
                        edge_type="calls",
                        line=call_node.lineno,
                        evidence_type="ast_call_direct",
                        is_resolved=False,
                        confidence=0.50,
                    ))
        elif isinstance(func, ast.Name):
            # WI-zigah: bare call like `urlopen(x)` after
            # `from urllib.request import urlopen`, where Case 1 looked the
            # name up in `imports` but _lookup_symbol_by_module returned None
            # (stdlib/external target). Emit an unresolved edge keyed by the
            # recorded (module, original_name) pair.
            callee_name = func.id
            if callee_name in imports:
                module_name, original_name = imports[callee_name]
                dst_id = f"python:{module_name}:0-0:{original_name}:unresolved"
                edges.append(Edge.create(
                    src=caller_symbol.id,
                    dst=dst_id,
                    edge_type="calls",
                    line=call_node.lineno,
                    evidence_type="ast_call_direct",
                    is_resolved=False,
                    confidence=0.50,
                ))


def extract_nodes(py_file: Path, global_symbols: dict[str, Symbol] | None = None) -> AnalysisResult:
    """
    Extract function/class definitions and call edges from a Python file.

    Returns an AnalysisResult with symbols and edges.
    Gracefully handles syntax errors and encoding issues.

    Note: For cross-file call detection, use analyze_python() instead.
    This function only detects intra-file calls for backwards compatibility.
    """
    file_analysis = _extract_file_analysis(py_file)
    if file_analysis is None:
        return AnalysisResult(symbols=[], edges=[], usage_contexts=[])

    # For single-file analysis, only detect local calls
    edges = _extract_edges(
        file_analysis.tree, file_analysis.symbol_by_name, {}, {},
        file_analysis.module_imports
    )
    return AnalysisResult(
        symbols=file_analysis.symbols,
        edges=edges,
        usage_contexts=file_analysis.usage_contexts,
    )


@register_analyzer("python", supports_max_files=True)
def analyze_python(
    repo_root: Path, max_files: int | None = None
) -> AnalysisResult:
    """
    Analyze all Python files in a repository.

    Returns an AnalysisResult with all detected symbols, edges, and provenance.
    Supports cross-file call detection via import resolution.

    Args:
        repo_root: Root directory of the repository
        max_files: Optional limit on number of files to analyze
    """
    import time

    start_time = time.time()

    # Create analysis run for provenance tracking
    run = AnalysisRun.create(pass_id=PASS_ID, version=PASS_VERSION)

    # Detect src/ layout source roots (PEP 517/518 + monorepo
    # packages/<pkg>/src/<mod>/ layouts — WI-davan E1).
    source_roots = _detect_source_roots(repo_root)

    # First pass: collect all symbols and imports from all files
    file_analyses: dict[Path, FileAnalysis] = {}
    files_skipped = 0
    for py_file in find_python_files(repo_root, max_files=max_files):
        analysis = _extract_file_analysis(py_file, repo_root, source_roots)
        if analysis is not None:
            file_analyses[py_file] = analysis
        else:
            files_skipped += 1

    # Build global symbol table: (module_name, symbol_name) -> Symbol
    global_symbols: dict[tuple[str, str], Symbol] = {}
    for py_file, analysis in file_analyses.items():
        module_name = _module_name_from_path(py_file, repo_root, source_roots)
        for symbol in analysis.symbols:
            global_symbols[(module_name, symbol.name)] = symbol

    # Process re-exports from __init__.py files
    # When __init__.py does "from .submodule import helper", add an alias
    # so that "from package import helper" resolves to the real symbol
    for py_file, analysis in file_analyses.items():
        if py_file.name != "__init__.py":
            continue

        module_name = _module_name_from_path(py_file, repo_root, source_roots)
        # Package name is module name without .__init__ suffix
        package_name = module_name.rsplit(".__init__", 1)[0]

        for local_name, (resolved_module, original_name) in analysis.imports.items():
            # Check if this import points to a known symbol (with suffix matching)
            source_symbol = _lookup_symbol_by_module(
                global_symbols, resolved_module, original_name
            )
            if source_symbol:
                # Add alias: (package, local_name) -> source_symbol
                global_symbols[(package_name, local_name)] = source_symbol
                # Mark the source symbol as re-exported from __init__.py
                # so library-export patterns can detect it
                if "re_exported" not in source_symbol.modifiers:
                    source_symbol.modifiers.append("re_exported")

    # Create resolver for efficient lookups in Pass 2 (with cached indexes)
    from hypergumbo_core.symbol_resolution import SymbolResolver
    resolver = SymbolResolver(global_symbols)

    # Build (path, name) -> symbol index for O(1) lookups in typed method
    # resolution. Replaces O(n) scans of global_symbols.items() that check
    # sym.path == target_path and sym_name == target_name.
    _sym_by_path_name: dict[tuple[str, str], Symbol] = {}
    for (_mod, sym_name), sym in global_symbols.items():
        key = (sym.path, sym_name)
        # First entry wins (same as the break in the old linear scan)
        if key not in _sym_by_path_name:
            _sym_by_path_name[key] = sym

    # Second pass: extract edges with cross-file resolution
    all_symbols: list[Symbol] = []
    all_edges: list[Edge] = []
    all_usage_contexts: list[UsageContext] = []
    # Load python.yaml dataflow config once for library_patterns fallback
    # in annotate_dataflow_ast (per-file is wasteful — it's a static config).
    py_dataflow_config = get_dataflow_config("python")
    for py_file, analysis in file_analyses.items():
        module_name = _module_name_from_path(py_file, repo_root, source_roots)

        # Set origin on symbols
        for symbol in analysis.symbols:
            symbol.origin = PASS_ID
            symbol.origin_run_id = run.execution_id
        all_symbols.extend(analysis.symbols)

        # Extract call edges
        call_edges = _extract_edges(
            analysis.tree, analysis.symbol_by_name, analysis.imports, global_symbols,
            analysis.module_imports, resolver, _sym_by_path_name,
        )
        for edge in call_edges:
            edge.origin = PASS_ID
            edge.origin_run_id = run.execution_id
        # ADR-0015: annotate edges with access_mode from Python AST context.
        # Pass source + python.yaml config so library_patterns (e.g. .append,
        # .write, .send → write) can fall back when the AST positional walk
        # leaves a call edge unclassified.  Without this, PR #2733's
        # library_patterns wiring is dead code for Python.
        call_edges = annotate_dataflow_ast(
            call_edges, analysis.tree,
            source=analysis.source,
            config=py_dataflow_config,
        )
        all_edges.extend(call_edges)

        # Extract import edges
        import_edges = _extract_import_edges(
            analysis.tree, str(py_file), module_name, global_symbols, resolver
        )
        for edge in import_edges:
            edge.origin = PASS_ID
            edge.origin_run_id = run.execution_id
        all_edges.extend(import_edges)

        # Collect usage contexts (v1.1.x)
        all_usage_contexts.extend(analysis.usage_contexts)

    # Extract inheritance edges (META-001: base_classes metadata -> extends edges)
    # Build multi-value class lookup: name -> list of candidates
    # (single-value dict had last-writer-wins bug: 238 Django 'Model' classes
    # all resolved to a single test stub instead of django.db.models.base.Model)
    class_by_name: dict[str, list[Symbol]] = {}
    for sym in all_symbols:
        if sym.kind == "class":
            class_by_name.setdefault(sym.name, []).append(sym)

    # Build symbol ID -> file-level imports mapping for disambiguation
    sym_file_imports: dict[str, dict[str, tuple[str, str]]] = {}
    for _py_file, analysis in file_analyses.items():
        for sym in analysis.symbols:
            sym_file_imports[sym.id] = analysis.imports

    # Create extends edges with import-aware disambiguation
    inheritance_edges = _extract_inheritance_edges(
        all_symbols, class_by_name, sym_file_imports, run
    )
    all_edges.extend(inheritance_edges)

    # Update run metadata
    run.files_analyzed = len(file_analyses)
    run.files_skipped = files_skipped
    run.duration_ms = int((time.time() - start_time) * 1000)

    # Parse pyproject.toml deps for tier-2 classification of boundary
    # nodes (WI-nunuj). Empty manifest → no entries → boundary nodes
    # stay tier 3 (no regression vs. previous behaviour).
    from hypergumbo_lang_mainstream.py_deps import parse_python_dependencies
    py_manifest = parse_python_dependencies(repo_root)

    return AnalysisResult(
        symbols=all_symbols,
        edges=all_edges,
        usage_contexts=all_usage_contexts,
        run=run,
        dependency_manifest=py_manifest if py_manifest.entries else None,
    )
