from __future__ import annotations

import os
import json
import subprocess
import sys
from pathlib import Path
from types import SimpleNamespace

import pytest

from ovp_pipeline import auto_github_processor as github_module
from ovp_pipeline import auto_article_processor as article_module
from ovp_pipeline import auto_paper_processor as paper_module
from ovp_pipeline.auto_article_processor import (
    AutoArticleProcessor,
    PipelineLogger as ArticleLogger,
    TransactionManager as ArticleTxn,
)
from ovp_pipeline.auto_evergreen_extractor import LiteLLMClient as EvergreenLiteLLMClient
# BL-066 (2026-05-05): auto_github_processor no longer calls any LLM —
# github intake is now a deterministic DeepWiki/GitIngest/README chain.
# parse_github_url moved to github_enrichment but is re-exported.
from ovp_pipeline.github_enrichment import EnrichedSource
from ovp_pipeline.auto_github_processor import parse_github_url
from ovp_pipeline.auto_paper_processor import LiteLLMClient as PaperLiteLLMClient, process_single_paper
from ovp_pipeline.lint_checker import KnowledgeLinter
from ovp_pipeline.markdown_generation import sanitize_generated_markdown
from ovp_pipeline.unified_pipeline_enhanced import (
    EnhancedPipeline,
    PipelineLogger,
    TransactionManager,
)


def test_pinboard_process_routes_paper_like_website_to_paper_processor(temp_vault, monkeypatch):
    pinboard_file = temp_vault / "50-Inbox" / "02-Pinboard" / "2026-04-07_arxiv.org.md"
    pinboard_file.parent.mkdir(parents=True, exist_ok=True)
    pinboard_file.write_text(
        """---
title: "[2505.22954] Darwin Godel Machine"
source: https://arxiv.org/abs/2505.22954
date: 2026-04-07
type: pinboard-website
tags: [paper]
---

[2505.22954] Darwin Godel Machine
""",
        encoding="utf-8",
    )

    logger = PipelineLogger(temp_vault / "60-Logs" / "pipeline.jsonl")
    txn = TransactionManager(temp_vault / "60-Logs" / "transactions")
    pipeline = EnhancedPipeline(temp_vault, logger, txn)

    captured: list[list[str]] = []

    def fake_run_command(cmd, step_name, timeout=None):
        assert step_name == "pinboard_process"
        captured.append(cmd)
        return {"success": True, "stdout": "", "stderr": ""}

    monkeypatch.setattr(pipeline, "run_command", fake_run_command)

    result = pipeline.step_pinboard_process(dry_run=False)

    assert result["files_processed"] == 1
    assert "ovp_pipeline.auto_paper_processor" in " ".join(captured[0])
    assert captured[0]


def test_parse_github_url_accepts_blob_tree_and_release_urls():
    assert parse_github_url("https://github.com/andelf/picc/blob/master/src/bin/voice_correct.rs") == ("andelf", "picc")
    assert parse_github_url("https://github.com/Yeachan-Heo/oh-my-codex/tree/main") == ("Yeachan-Heo", "oh-my-codex")
    assert parse_github_url("https://github.com/hyperspaceai/agi/releases/tag/architect-v1") == ("hyperspaceai", "agi")


def test_pinboard_process_uses_extended_subprocess_timeout_for_slow_github_repos(temp_vault, monkeypatch):
    pinboard_file = temp_vault / "50-Inbox" / "02-Pinboard" / "2026-04-07_example_github.md"
    pinboard_file.parent.mkdir(parents=True, exist_ok=True)
    pinboard_file.write_text(
        """---
title: "example/repo"
source: https://github.com/example/repo
date: 2026-04-07
type: pinboard-github
tags: [tool]
---

example/repo
""",
        encoding="utf-8",
    )

    logger = PipelineLogger(temp_vault / "60-Logs" / "pipeline.jsonl")
    txn = TransactionManager(temp_vault / "60-Logs" / "transactions")
    pipeline = EnhancedPipeline(temp_vault, logger, txn)

    captured: list[int | None] = []

    def fake_run_command(cmd, step_name, timeout=None):
        assert step_name == "pinboard_process"
        captured.append(timeout)
        return {"success": True, "stdout": "", "stderr": ""}

    monkeypatch.setattr(pipeline, "run_command", fake_run_command)

    result = pipeline.step_pinboard_process(dry_run=False)

    assert result["files_processed"] == 1
    assert captured == [600]


def test_pipeline_subprocesses_include_project_src_on_pythonpath(temp_vault, monkeypatch):
    pinboard_file = temp_vault / "50-Inbox" / "02-Pinboard" / "2026-04-07_example.md"
    pinboard_file.parent.mkdir(parents=True, exist_ok=True)
    pinboard_file.write_text(
        """---
title: "example/repo"
source: https://github.com/example/repo
date: 2026-04-07
type: pinboard-github
tags: [tool]
---

example/repo
""",
        encoding="utf-8",
    )

    logger = PipelineLogger(temp_vault / "60-Logs" / "pipeline.jsonl")
    txn = TransactionManager(temp_vault / "60-Logs" / "transactions")
    pipeline = EnhancedPipeline(temp_vault, logger, txn)

    env = pipeline._subprocess_env()

    assert str((Path(__file__).resolve().parents[1] / "src")) in env["PYTHONPATH"]


def test_sanitize_generated_markdown_unwraps_fenced_frontmatter():
    raw = """```yaml
---
title: Example
source: https://example.com
---

# Body
```"""

    cleaned = sanitize_generated_markdown(raw)

    assert cleaned.startswith("---\n")
    assert "```yaml" not in cleaned
    assert cleaned.rstrip().endswith("# Body")


def test_pinboard_processor_rejects_cross_day_cli_range(tmp_path):
    script = Path(__file__).resolve().parents[1] / "pinboard-processor.py"
    env = os.environ.copy()
    env["PINBOARD_TOKEN"] = "user:token"
    env["WIGS_VAULT_DIR"] = str(tmp_path)

    result = subprocess.run(
        [
            sys.executable,
            str(script),
            "--start-date",
            "2026-04-01",
            "--end-date",
            "2026-04-02",
        ],
        capture_output=True,
        text=True,
        env=env,
    )

    assert result.returncode != 0
    assert "不支持跨天范围查询" in result.stderr


def test_process_inbox_moves_completed_sources_to_monthly_processed(temp_vault, monkeypatch):
    raw_file = temp_vault / "50-Inbox" / "01-Raw" / "2026-04-07_example.md"
    raw_file.parent.mkdir(parents=True, exist_ok=True)
    raw_file.write_text(
        """---
title: "Example SDK"
source: https://example.com
author: unknown
date: 2026-04-07
type: article
tags: [sdk]
---

Example SDK body
""",
        encoding="utf-8",
    )

    logger = ArticleLogger(temp_vault / "60-Logs" / "pipeline.jsonl")
    txn = ArticleTxn(temp_vault / "60-Logs" / "transactions")
    processor = AutoArticleProcessor(temp_vault, logger, txn)

    monkeypatch.setattr(
        "ovp_pipeline.image_downloader.ImageDownloader.process_file",
        lambda self, file_path, backup=True: [],
    )

    results = processor.process_inbox(dry_run=False, batch_size=1)

    processed_file = temp_vault / "50-Inbox" / "03-Processed" / "2026-04" / raw_file.name
    processing_file = temp_vault / "50-Inbox" / "02-Processing" / raw_file.name

    # Post-BL-029: ``intake_only`` is the only success status —
    # rolls up under ``completed`` in the result counts.
    assert results["completed"] == 1
    assert not raw_file.exists()
    assert not processing_file.exists()
    assert processed_file.exists()


def test_process_single_source_moves_clipping_through_lifecycle(temp_vault, monkeypatch):
    clipping = temp_vault / "Clippings" / "Raw Clip.md"
    clipping.parent.mkdir(parents=True, exist_ok=True)
    clipping.write_text(
        """---
title: "Raw Clip"
source: https://example.com/raw-clip
author: unknown
date: 2026-04-07
type: article
tags: [sdk]
---

Raw clip body
""",
        encoding="utf-8",
    )

    logger = ArticleLogger(temp_vault / "60-Logs" / "pipeline.jsonl")
    txn = ArticleTxn(temp_vault / "60-Logs" / "transactions")
    processor = AutoArticleProcessor(temp_vault, logger, txn)

    monkeypatch.setattr(
        "ovp_pipeline.image_downloader.ImageDownloader.process_file",
        lambda self, file_path, backup=True: [],
    )

    def fake_obsidian_move(self, source, dest_dir, new_name=None):
        dest_dir.mkdir(parents=True, exist_ok=True)
        source.rename(dest_dir / (new_name or source.name))
        return True

    monkeypatch.setattr("ovp_pipeline.clippings_processor.ClippingsProcessor.obsidian_move", fake_obsidian_move)

    result = processor.process_single_source(clipping, dry_run=False)

    processed_files = list((temp_vault / "50-Inbox" / "03-Processed").glob("*/*Raw_Clip.md"))

    assert result["status"] == "intake_only"
    assert not clipping.exists()
    assert not list((temp_vault / "50-Inbox" / "01-Raw").glob("*Raw_Clip.md"))
    assert not list((temp_vault / "50-Inbox" / "02-Processing").glob("*Raw_Clip.md"))
    assert len(processed_files) == 1


def test_article_cli_process_single_uses_source_lifecycle(temp_vault, monkeypatch):
    clipping = temp_vault / "Clippings" / "Raw Clip.md"
    clipping.parent.mkdir(parents=True, exist_ok=True)
    clipping.write_text("# Raw Clip\n", encoding="utf-8")

    called: dict[str, object] = {}

    def stub_process_single_source(self, file_path, dry_run=False):
        called["file_path"] = Path(file_path)
        called["dry_run"] = dry_run
        return {"status": "intake_only", "tokens_used": 0, "output_path": None}

    monkeypatch.setattr(article_module.AutoArticleProcessor, "process_single_source", stub_process_single_source)
    monkeypatch.setattr(
        sys,
        "argv",
        [
            "auto_article_processor.py",
            "--process-single",
            str(clipping),
            "--vault-dir",
            str(temp_vault),
        ],
    )

    assert article_module.main() == 0
    assert called == {"file_path": clipping, "dry_run": False}


def test_process_single_source_archives_pinboard_after_success(temp_vault, monkeypatch):
    pinboard_file = temp_vault / "50-Inbox" / "02-Pinboard" / "2026-04-07_example.md"
    pinboard_file.parent.mkdir(parents=True, exist_ok=True)
    pinboard_file.write_text(
        """---
title: "Example SDK"
source: https://example.com
author: unknown
date: 2026-04-07
type: article
tags: [sdk]
---

Example body
""",
        encoding="utf-8",
    )

    logger = ArticleLogger(temp_vault / "60-Logs" / "pipeline.jsonl")
    txn = ArticleTxn(temp_vault / "60-Logs" / "transactions")
    processor = AutoArticleProcessor(temp_vault, logger, txn)

    monkeypatch.setattr(
        "ovp_pipeline.image_downloader.ImageDownloader.process_file",
        lambda self, file_path, backup=True: [],
    )

    result = processor.process_single_source(pinboard_file, dry_run=False)
    archived_files = list((temp_vault / "70-Archive" / "Pinboard").glob("*/2026-04-07_example.md"))

    assert result["status"] == "intake_only"
    assert not pinboard_file.exists()
    assert len(archived_files) == 1


def test_process_inbox_restores_failed_sources_back_to_raw(temp_vault, monkeypatch):
    raw_file = temp_vault / "50-Inbox" / "01-Raw" / "2026-04-07_failure.md"
    raw_file.parent.mkdir(parents=True, exist_ok=True)
    raw_file.write_text(
        """---
title: "Broken Example"
source: https://example.com
author: unknown
date: 2026-04-07
type: article
tags: [sdk]
---

Broken body
""",
        encoding="utf-8",
    )

    logger = ArticleLogger(temp_vault / "60-Logs" / "pipeline.jsonl")
    txn = ArticleTxn(temp_vault / "60-Logs" / "transactions")
    processor = AutoArticleProcessor(temp_vault, logger, txn)

    # Force the processor to fail by making image download throw —
    # post-BL-029 this is the realistic failure surface.
    def raising_process_file(self, file_path, backup=True):
        raise RuntimeError("boom")

    monkeypatch.setattr(
        "ovp_pipeline.auto_article_processor.AutoArticleProcessor.parse_raw_file",
        lambda self, file_path: (_ for _ in ()).throw(RuntimeError("boom")),
    )
    monkeypatch.setattr(
        "ovp_pipeline.image_downloader.ImageDownloader.process_file",
        lambda self, file_path, backup=True: [],
    )

    results = processor.process_inbox(dry_run=False, batch_size=1)

    processed_file = temp_vault / "50-Inbox" / "03-Processed" / "2026-04" / raw_file.name
    processing_file = temp_vault / "50-Inbox" / "02-Processing" / raw_file.name

    assert results["failed"] == 1
    assert raw_file.exists()
    assert not processing_file.exists()
    assert not processed_file.exists()


def test_process_inbox_resumes_files_left_in_processing_first(temp_vault, monkeypatch):
    raw_file = temp_vault / "50-Inbox" / "01-Raw" / "2026-04-07_raw.md"
    processing_file = temp_vault / "50-Inbox" / "02-Processing" / "2026-04-07_stuck.md"
    raw_file.parent.mkdir(parents=True, exist_ok=True)
    processing_file.parent.mkdir(parents=True, exist_ok=True)

    template = """---
title: "{title}"
source: https://example.com
author: unknown
date: 2026-04-07
type: article
tags: [sdk]
---

Body
"""
    raw_file.write_text(template.format(title="Raw First"), encoding="utf-8")
    processing_file.write_text(template.format(title="Processing First"), encoding="utf-8")

    logger = ArticleLogger(temp_vault / "60-Logs" / "pipeline.jsonl")
    txn = ArticleTxn(temp_vault / "60-Logs" / "transactions")
    processor = AutoArticleProcessor(temp_vault, logger, txn)

    monkeypatch.setattr(
        "ovp_pipeline.image_downloader.ImageDownloader.process_file",
        lambda self, file_path, backup=True: [],
    )

    seen: list[str] = []
    original = processor.process_single_file

    def wrapped(file_path, dry_run=False):
        seen.append(Path(file_path).name)
        return original(file_path, dry_run=dry_run)

    monkeypatch.setattr(processor, "process_single_file", wrapped)

    results = processor.process_inbox(dry_run=False, batch_size=1)

    assert results["completed"] == 1
    assert seen == ["2026-04-07_stuck.md"]


def test_process_inbox_batch_progress_uses_selected_batch_total(temp_vault, monkeypatch):
    raw_dir = temp_vault / "50-Inbox" / "01-Raw"
    raw_dir.mkdir(parents=True, exist_ok=True)
    for idx in range(3):
        (raw_dir / f"2026-04-07_article_{idx}.md").write_text(
            f"""---
title: "Article {idx}"
source: https://example.com/{idx}
author: unknown
date: 2026-04-07
type: article
tags: [sdk]
---

Body
""",
            encoding="utf-8",
        )

    logger = ArticleLogger(temp_vault / "60-Logs" / "pipeline.jsonl")
    txn = ArticleTxn(temp_vault / "60-Logs" / "transactions")
    processor = AutoArticleProcessor(temp_vault, logger, txn)
    txn_id = txn.start("article-processing", "Batch progress")

    monkeypatch.setattr(
        processor,
        "process_single_file",
        lambda file_path, dry_run=False: {"status": "intake_only", "tokens_used": 0},
    )

    results = processor.process_inbox(dry_run=True, batch_size=1, txn_id=txn_id)

    payload = json.loads((temp_vault / "60-Logs" / "transactions" / f"{txn_id}.json").read_text(encoding="utf-8"))
    current = payload["run_ledger"]["current_step"]
    assert results["queued_total"] == 3
    assert results["total"] == 1
    assert results["completed"] == 1
    assert current["work_units_total"] == 1
    assert current["work_units_done"] == 1
    assert current["progress_summary"] == "1/1 articles processed"


def test_linter_resolve_link_handles_dot_relative_target_without_crashing(temp_vault):
    note = temp_vault / "20-Areas" / "AI-Research" / "Topics" / "2026-04-07_Test.md"
    note.parent.mkdir(parents=True, exist_ok=True)
    note.write_text(
        """---
title: Test
date: 2026-04-07
type: note
---

[Broken](./.md)
""",
        encoding="utf-8",
    )

    linter = KnowledgeLinter(temp_vault)
    linter.scan()

    assert linter._resolve_link(".") is None


def test_github_main_runs_enrichment_on_process_single(temp_vault, monkeypatch):
    """BL-066 replaces the old --model / LiteLLMClient path with a
    deterministic enrichment chain.  This test pins the new shape:
    main() reads the pinboard stub, calls enrich_github_source,
    writes to 50-Inbox/03-Processed, and archives the stub.
    """
    pinboard_file = temp_vault / "50-Inbox" / "02-Pinboard" / "2026-04-07_example.md"
    pinboard_file.parent.mkdir(parents=True, exist_ok=True)
    pinboard_file.write_text(
        """---
title: "example/repo"
source: https://github.com/example/repo
date: 2026-04-07
tags: [tool]
---
""",
        encoding="utf-8",
    )

    enrich_calls: list[tuple[str, str]] = []

    def fake_enrich(owner: str, repo: str) -> EnrichedSource:
        enrich_calls.append((owner, repo))
        return EnrichedSource(
            owner=owner, repo=repo, tier="readme",
            body="# stub README body for test\n",
            metadata={"tier": "readme", "github_stars": 0},
        )

    monkeypatch.setattr(github_module, "enrich_github_source", fake_enrich)
    monkeypatch.setattr(
        sys, "argv",
        [
            "auto_github_processor.py",
            "--process-single",
            str(pinboard_file),
            "--vault-dir",
            str(temp_vault),
        ],
    )

    assert github_module.main() == 0
    # Enrichment was invoked once for the right repo
    assert enrich_calls == [("example", "repo")]
    # Pinboard stub was archived (lifecycle handler still runs)
    assert not pinboard_file.exists()
    assert len(list((temp_vault / "70-Archive" / "Pinboard").glob("*/2026-04-07_example.md"))) == 1
    # Output landed in 03-Processed, not 20-Areas/Tools/Topics
    processed_files = list(
        (temp_vault / "50-Inbox" / "03-Processed").rglob("2026-04-07_example_repo.md")
    )
    assert len(processed_files) == 1
    body = processed_files[0].read_text(encoding="utf-8")
    assert "source_type: github-project" in body
    assert "source_tier: readme" in body
    # No deep-dive file was created
    assert not list((temp_vault / "20-Areas").rglob("*example*_深度解读.md"))


def test_github_intake_skips_url_already_in_active_staging(temp_vault, monkeypatch):
    """Cross-date URL dedup gate.

    Pre-fix the GitHub intake's collision guard only checked the
    same-day output filename, so a Pinboard re-clip on a later date
    silently produced a duplicate processed source.  Wire-in the
    BL-058 active-URL index gate: when ``https://github.com/o/r`` is
    already claimed in the staging chain (Clippings + four
    50-Inbox/ stages), the next run reports ``skipped_dedup`` and
    archives the new pinboard stub instead of re-running enrichment.
    """
    # An older processed copy of the same URL — a previous April run.
    older_processed = (
        temp_vault / "50-Inbox" / "03-Processed" / "2026-04"
        / "2026-04-28_o_r.md"
    )
    older_processed.parent.mkdir(parents=True, exist_ok=True)
    older_processed.write_text(
        "---\n"
        "title: \"o/r\"\n"
        "source: https://github.com/o/r\n"
        "date: 2026-04-28\n"
        "---\n",
        encoding="utf-8",
    )

    # New pinboard re-clip on a later date for the same repo.
    pinboard_file = temp_vault / "50-Inbox" / "02-Pinboard" / "2026-05-07_o_r.md"
    pinboard_file.parent.mkdir(parents=True, exist_ok=True)
    pinboard_file.write_text(
        "---\n"
        "title: \"o/r\"\n"
        "source: https://github.com/o/r\n"
        "date: 2026-05-07\n"
        "tags: [github]\n"
        "---\n",
        encoding="utf-8",
    )

    enrich_calls: list[tuple[str, str]] = []

    def fake_enrich(owner: str, repo: str) -> EnrichedSource:
        enrich_calls.append((owner, repo))
        return EnrichedSource(
            owner=owner, repo=repo, tier="readme", body="# body\n", metadata={},
        )

    monkeypatch.setattr(github_module, "enrich_github_source", fake_enrich)
    monkeypatch.setattr(
        sys, "argv",
        [
            "auto_github_processor.py",
            "--process-single", str(pinboard_file),
            "--vault-dir", str(temp_vault),
        ],
    )

    assert github_module.main() == 0
    # Enrichment should NOT have run — we caught the URL upstream.
    assert enrich_calls == []
    # No new processed file for the May date.
    may_processed = list(
        (temp_vault / "50-Inbox" / "03-Processed").rglob("2026-05-07_o_r.md")
    )
    assert may_processed == []
    # The pinboard stub was archived (its job is done; the URL is
    # already claimed in 03-Processed) — pre-fix the stub stayed in
    # the active queue and the next sweep would re-trigger the gate.
    assert not pinboard_file.exists()
    archived = list(
        (temp_vault / "70-Archive" / "Pinboard").rglob("2026-05-07_o_r.md")
    )
    assert len(archived) == 1


def test_paper_cli_does_not_override_auto_vault_model_when_flag_is_omitted(temp_vault, monkeypatch):
    pinboard_file = temp_vault / "50-Inbox" / "02-Pinboard" / "2026-04-07_paper.md"
    pinboard_file.parent.mkdir(parents=True, exist_ok=True)
    pinboard_file.write_text(
        """---
title: "[2505.22954] Example Paper"
source: https://arxiv.org/abs/2505.22954
date: 2026-04-07
tags: [paper]
---
""",
        encoding="utf-8",
    )

    captured: dict[str, object] = {}

    class StubLLM:
        def __init__(self, *, model=None, api_type="anthropic", api_key=None, api_base=None):
            captured["model"] = model
            self.model = "stub-model"
            self.total_calls = 0

    monkeypatch.setattr(paper_module, "LiteLLMClient", StubLLM)
    monkeypatch.setattr(
        paper_module,
        "process_single_paper",
        lambda **kwargs: {"status": "completed", "tokens_used": 0},
    )
    monkeypatch.setattr(
        sys,
        "argv",
        [
            "auto_paper_processor.py",
            "--process-single",
            str(pinboard_file),
            "--vault-dir",
            str(temp_vault),
        ],
    )

    assert paper_module.main() == 0
    assert captured["model"] is None
    assert not pinboard_file.exists()
    assert len(list((temp_vault / "70-Archive" / "Pinboard").glob("*/2026-04-07_paper.md"))) == 1


@pytest.mark.parametrize(("client_class", "patch_mode"), [
    (PaperLiteLLMClient, "module"),
    # BL-066: github processor has no LiteLLMClient; covered by other tests.
])
def test_litellm_clients_retry_transient_failures(monkeypatch, client_class, patch_mode):
    monkeypatch.setenv("AUTO_VAULT_API_KEY", "test-key")
    monkeypatch.setenv("AUTO_VAULT_MODEL", "minimax/MiniMax-M2.7-highspeed")

    attempts = {"count": 0}

    class FakeUsage:
        total_tokens = 42

    class FakeMessage:
        content = "ok"

    class FakeChoice:
        message = FakeMessage()
        finish_reason = "stop"

    class FakeResponse:
        choices = [FakeChoice()]
        usage = FakeUsage()

    def fake_completion(**kwargs):
        attempts["count"] += 1
        if attempts["count"] == 1:
            raise RuntimeError("transient upstream 404")
        return FakeResponse()

    monkeypatch.setitem(sys.modules, "litellm", SimpleNamespace(completion=fake_completion))
    monkeypatch.setattr("time.sleep", lambda *_args, **_kwargs: None)

    client = client_class()
    content, metadata = client.generate("system", "user")

    assert content == "ok"
    assert metadata["tokens"] == 42
    assert attempts["count"] == 2


@pytest.mark.parametrize(("client_class", "patch_mode"), [
    (PaperLiteLLMClient, "module"),
    # BL-066: github processor has no LiteLLMClient; covered by other tests.
])
def test_litellm_clients_pass_explicit_completion_timeout(monkeypatch, client_class, patch_mode):
    monkeypatch.setenv("AUTO_VAULT_API_KEY", "test-key")
    monkeypatch.setenv("AUTO_VAULT_MODEL", "minimax/MiniMax-M2.7-highspeed")

    captured: dict[str, object] = {}

    class FakeUsage:
        total_tokens = 7

    class FakeMessage:
        content = "ok"

    class FakeChoice:
        message = FakeMessage()
        finish_reason = "stop"

    class FakeResponse:
        choices = [FakeChoice()]
        usage = FakeUsage()

    def fake_completion(**kwargs):
        captured.update(kwargs)
        return FakeResponse()

    monkeypatch.setitem(sys.modules, "litellm", SimpleNamespace(completion=fake_completion))

    client = client_class()
    content, metadata = client.generate("system", "user")

    assert content == "ok"
    assert metadata["tokens"] == 7
    assert captured["timeout"] == 180


def test_evergreen_litellm_client_retries_transient_failures(monkeypatch):
    monkeypatch.setenv("AUTO_VAULT_API_KEY", "test-key")
    monkeypatch.setenv("AUTO_VAULT_MODEL", "minimax/MiniMax-M2.7-highspeed")

    attempts = {"count": 0}

    class FakeMessage:
        content = "ok"

    class FakeChoice:
        message = FakeMessage()

    class FakeResponse:
        def __init__(self):
            self.choices = [FakeChoice()]

    def fake_completion(**kwargs):
        attempts["count"] += 1
        if attempts["count"] == 1:
            raise RuntimeError("transient server disconnected")
        return FakeResponse()

    monkeypatch.setattr("ovp_pipeline.auto_evergreen_extractor.litellm.completion", fake_completion)

    client = EvergreenLiteLLMClient()

    assert client.generate("system", "user") == "ok"
    assert attempts["count"] == 2


def test_evergreen_litellm_client_bypasses_proxy_env_during_completion(monkeypatch):
    monkeypatch.setenv("AUTO_VAULT_API_KEY", "test-key")
    proxy_vars = ("HTTPS_PROXY", "HTTP_PROXY", "ALL_PROXY", "https_proxy", "http_proxy", "all_proxy")
    for key in proxy_vars:
        monkeypatch.setenv(key, f"http://external-proxy.example/{key}")

    observed: dict[str, str | None] = {}

    class FakeMessage:
        content = "ok"

    class FakeChoice:
        message = FakeMessage()

    class FakeResponse:
        def __init__(self):
            self.choices = [FakeChoice()]

    def fake_completion(**kwargs):
        for key in proxy_vars:
            observed[key] = os.environ.get(key)
        return FakeResponse()

    monkeypatch.setattr("ovp_pipeline.auto_evergreen_extractor.litellm.completion", fake_completion)

    client = EvergreenLiteLLMClient()

    assert client.generate("system", "user") == "ok"
    assert observed == {key: None for key in proxy_vars}
    for key in proxy_vars:
        assert os.environ[key] == f"http://external-proxy.example/{key}"


def test_litellm_proxy_policy_supports_unified_custom_proxy():
    from ovp_pipeline.llm_defaults import env_for_litellm

    env = env_for_litellm(
        {
            "HTTPS_PROXY": "http://ambient.example:1",
            "http_proxy": "http://ambient.example:1",
            "OVP_LLM_PROXY_MODE": "custom",
            "OVP_LLM_PROXY_URL": "http://127.0.0.1:7897",
            "LITELLM_PROXY_BYPASS": "1",
        }
    )

    for key in ("HTTP_PROXY", "HTTPS_PROXY", "ALL_PROXY", "http_proxy", "https_proxy", "all_proxy"):
        assert env[key] == "http://127.0.0.1:7897"
    assert "LITELLM_PROXY_BYPASS" not in env


def test_litellm_proxy_policy_can_use_ambient_proxy():
    from ovp_pipeline.llm_defaults import env_for_litellm

    env = env_for_litellm(
        {
            "HTTPS_PROXY": "http://ambient.example:1",
            "OVP_LLM_PROXY_MODE": "ambient",
            "LITELLM_PROXY_BYPASS": "1",
        }
    )

    assert env["HTTPS_PROXY"] == "http://ambient.example:1"
    assert "LITELLM_PROXY_BYPASS" not in env


def test_litellm_proxy_policy_requires_url_for_custom_mode():
    from ovp_pipeline.llm_defaults import env_for_litellm

    with pytest.raises(ValueError, match="OVP_LLM_PROXY_URL"):
        env_for_litellm({"OVP_LLM_PROXY_MODE": "custom"})


def test_process_single_paper_downloads_remote_pdf_before_analysis(tmp_path, monkeypatch):
    class FakeResponse:
        def __init__(self, content: bytes):
            self.status_code = 200
            self.content = content
            self.headers = {"Content-Type": "application/pdf"}

    monkeypatch.setattr(
        "ovp_pipeline.auto_paper_processor.requests.get",
        lambda url, timeout=30: FakeResponse(b"%PDF-1.4 fake"),
    )

    extracted_paths: list[str] = []

    def fake_extract_pdf_text(pdf_path: str, max_chars: int = 10000) -> str:
        extracted_paths.append(pdf_path)
        return "Remote paper body " * 200

    monkeypatch.setattr("ovp_pipeline.auto_paper_processor.extract_pdf_text", fake_extract_pdf_text)

    class StubLLM:
        def generate(self, system_prompt: str, user_prompt: str, max_tokens: int = 8000):
            assert "Remote paper body" in user_prompt
            return ("---\ntitle: Paper\nsource: x\nauthor: y\ndate: 2026-04-07\ntype: paper\ntags: []\n---\n\n# Paper", {"tokens": 1})

    output_dir = tmp_path / "papers"
    result = process_single_paper(
        source="https://example.com/paper.pdf",
        title="Remote PDF Paper",
        authors=[],
        date="2026-04-07",
        llm_client=StubLLM(),
        output_dir=output_dir,
        dry_run=False,
    )

    assert result["status"] == "completed"
    assert extracted_paths
    assert output_dir.exists()
