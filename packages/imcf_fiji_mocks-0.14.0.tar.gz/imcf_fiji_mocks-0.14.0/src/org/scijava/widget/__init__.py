WidgetStyle = None
TextWidget = None
