getProperty = None
