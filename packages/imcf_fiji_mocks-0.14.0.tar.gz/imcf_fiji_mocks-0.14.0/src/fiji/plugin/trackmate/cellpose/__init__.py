CellposeDetectorFactory = None
