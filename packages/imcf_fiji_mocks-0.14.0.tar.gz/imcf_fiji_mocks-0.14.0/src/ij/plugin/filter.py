ThresholdToSelection = None
ImageProcessor = None
