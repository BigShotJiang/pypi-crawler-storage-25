from functools import lru_cache
import json

from pydantic import Field, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    app_name: str = "{{project_name}}"
    app_env: str = "development"
    app_debug: bool = True
    log_level: str = "INFO"
    api_v1_prefix: str = "/api/v1"
    database_url: str = Field(default="sqlite:///./poleposition.db")
    cors_enabled: bool = True
    cors_allow_origins: list[str] = [
        "http://localhost:3000",
        "http://127.0.0.1:3000",
        "http://localhost:5173",
        "http://127.0.0.1:5173",
    ]
    cors_allow_origin_regex: str | None = None
    cors_allow_credentials: bool = True
    cors_allow_methods: list[str] = ["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"]
    cors_allow_headers: list[str] = ["Authorization", "Content-Type", "X-Request-ID"]
    cors_expose_headers: list[str] = ["X-Request-ID"]
    cors_max_age: int = 600
    app_host: str = "127.0.0.1"
    app_port: int = 8000
    app_reload: bool = True
    uvicorn_workers: int = 1
    uvicorn_access_log: bool = True
    uvicorn_proxy_headers: bool = True
    uvicorn_forwarded_allow_ips: str = "127.0.0.1"
    uvicorn_server_header: bool = True
    uvicorn_date_header: bool = True
    uvicorn_use_colors: bool | None = None
    uvicorn_timeout_keep_alive: int = 5
    uvicorn_timeout_graceful_shutdown: int | None = None
    uvicorn_timeout_worker_healthcheck: int = 5
    uvicorn_limit_concurrency: int | None = None
    uvicorn_limit_max_requests: int | None = None
    uvicorn_limit_max_requests_jitter: int = 0
    uvicorn_backlog: int = 2048

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore",
    )

    @field_validator(
        "cors_allow_origin_regex",
        "uvicorn_use_colors",
        "uvicorn_timeout_graceful_shutdown",
        "uvicorn_limit_concurrency",
        "uvicorn_limit_max_requests",
        mode="before",
    )
    @classmethod
    def empty_string_to_none(cls, value: object) -> object:
        if isinstance(value, str) and not value.strip():
            return None
        return value

    @field_validator(
        "cors_allow_origins",
        "cors_allow_methods",
        "cors_allow_headers",
        "cors_expose_headers",
        mode="before",
    )
    @classmethod
    def parse_list_env(cls, value: object) -> object:
        if not isinstance(value, str):
            return value

        stripped = value.strip()
        if not stripped:
            return []

        if stripped.startswith("["):
            return json.loads(stripped)

        return [item.strip() for item in stripped.split(",") if item.strip()]


@lru_cache
def get_settings() -> Settings:
    return Settings()
