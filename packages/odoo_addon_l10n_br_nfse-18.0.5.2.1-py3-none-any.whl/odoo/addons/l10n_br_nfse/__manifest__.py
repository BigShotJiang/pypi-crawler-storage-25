# Copyright 2019 KMEE INFORMATICA LTDA
# License AGPL-3.0 or later (http://www.gnu.org/licenses/agpl).

{
    "name": "NFS-e",
    "summary": "Root electronic invoice for service / NFS-e module",
    "version": "18.0.5.2.1",
    "license": "AGPL-3",
    "author": "KMEE, Odoo Community Association (OCA)",
    "maintainers": ["mileo", "marcelsavegnago"],
    "website": "https://github.com/OCA/l10n-brazil",
    "external_dependencies": {
        "python": [
            "erpbrasil.edoc",
            "erpbrasil.transmissao",
            "erpbrasil.base",
        ],
    },
    "depends": [
        "l10n_br_fiscal_edi",
        "l10n_br_fiscal_certificate",
    ],
    "data": [
        "security/ir.model.access.csv",
        "views/document_view.xml",
        "views/product_template_view.xml",
        "views/product_product_view.xml",
        "views/document_line_view.xml",
        "views/res_company_view.xml",
        "report/danfse.xml",
    ],
    "demo": [
        "demo/product_demo.xml",
        "demo/fiscal_document_demo.xml",
    ],
}
