class MissingContextValue(Exception):
    pass
