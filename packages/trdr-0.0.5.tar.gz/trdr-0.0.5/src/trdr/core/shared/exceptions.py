class TradingDateException(Exception):
    pass
