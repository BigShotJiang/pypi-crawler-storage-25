"""Python entry point wrapper for Qorx."""

__version__ = "1.0.2"
