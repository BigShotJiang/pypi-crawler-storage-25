"""Meta-installer that runs every install-* skill in dependency order.

Strategy:
- Tools are grouped into tiers. Each tier installs in parallel-friendly groups
  but the meta-installer runs sequentially for clear log output.
- A tool can be REQUIRED (failure aborts), OPTIONAL (failure logged, continue),
  or SKIP_ON_MISSING_ENV (silently skipped when its env vars are absent).
- Each tool exposes a `get_state()` function that says whether work is needed.
  We call it first; if `needs_install` is false the tool is reported `skipped`.
"""

import importlib
import json
import os
from collections.abc import Callable
from dataclasses import dataclass, field
from enum import StrEnum
from typing import Annotated, Any

import typer


class Mode(StrEnum):
    REQUIRED = "required"
    OPTIONAL = "optional"
    SKIP_ON_MISSING_ENV = "skip_on_missing_env"


@dataclass(frozen=True)
class Tool:
    """One install-* skill to orchestrate."""

    name: str
    module: str  # import path, e.g. "pysae_ai_tools.install.glab"
    mode: Mode = Mode.OPTIONAL
    env_required: tuple[str, ...] = ()  # env vars needed for SKIP_ON_MISSING_ENV mode
    env_help: dict[str, str] = field(default_factory=dict)  # var → how to get it

    def env_present(self) -> bool:
        return all(os.environ.get(k) for k in self.env_required)


# Order matters: foundational tools first, dependents next.
TOOLS: tuple[Tool, ...] = (
    # Tier 1 — auth foundations (REQUIRED: many downstream tools need these)
    # aws-cli must run first: kubectl/EKS, mongodb-atlas-mcp (Secrets Manager), aws-secret-env all depend on it.
    Tool("aws-cli", "pysae_ai_tools.install.aws_cli", Mode.REQUIRED),
    Tool("glab", "pysae_ai_tools.install.glab", Mode.REQUIRED),
    Tool("gh", "pysae_ai_tools.install.gh", Mode.OPTIONAL),
    # Tier 2 — Kubernetes stack (depends on aws-cli for EKS)
    Tool("kubectl", "pysae_ai_tools.install.kubectl", Mode.OPTIONAL),
    Tool("helm", "pysae_ai_tools.install.helm", Mode.OPTIONAL),
    Tool("argocd", "pysae_ai_tools.install.argocd", Mode.OPTIONAL),
    # Tier 3 — generic tools
    Tool("docker", "pysae_ai_tools.install.docker", Mode.OPTIONAL),
    Tool("terraform", "pysae_ai_tools.install.terraform", Mode.OPTIONAL),
    Tool("prefect", "pysae_ai_tools.install.prefect", Mode.OPTIONAL),
    Tool("mongo-tools", "pysae_ai_tools.install.mongo_tools", Mode.OPTIONAL),
    Tool("postman", "pysae_ai_tools.install.postman", Mode.OPTIONAL),
    # Tier 4 — MCP servers (no env vars needed)
    Tool("chrome-mcp", "pysae_ai_tools.install.chrome_mcp", Mode.OPTIONAL),
    # Tier 5 — MCP servers requiring secrets
    Tool(
        "datadog-mcp",
        "pysae_ai_tools.install.datadog_mcp",
        Mode.SKIP_ON_MISSING_ENV,
        env_required=("DD_API_KEY", "DD_APP_KEY"),
        env_help={
            "DD_API_KEY": "Datadog → Organization Settings → API Keys → New Key",
            "DD_APP_KEY": "Datadog → Organization Settings → Application Keys → New Key",
        },
    ),
    Tool(
        "postman-mcp",
        "pysae_ai_tools.install.postman_mcp",
        Mode.SKIP_ON_MISSING_ENV,
        env_required=("POSTMAN_API_KEY",),
        env_help={
            "POSTMAN_API_KEY": "Postman → Settings → API Keys → Generate API Key",
        },
    ),
    Tool(
        "mongo-mcp",
        "pysae_ai_tools.install.mongo_mcp",
        Mode.SKIP_ON_MISSING_ENV,
        env_required=("MDB_DEV_URI", "MDB_PROD_URI"),
        env_help={
            "MDB_DEV_URI": "pysae-ai-tools aws secret-env MONGO_URI dev",
            "MDB_PROD_URI": "pysae-ai-tools aws secret-env MONGO_URI prod",
        },
    ),
    Tool(
        "mongodb-atlas-mcp",
        "pysae_ai_tools.install.mongodb_atlas_mcp",
        Mode.OPTIONAL,
        # Pulls keys from AWS Secrets Manager at install time — no env required.
    ),
)


@dataclass
class Result:
    name: str
    status: str  # "installed" | "up-to-date" | "skipped" | "failed"
    detail: dict[str, Any] = field(default_factory=dict)
    error: str = ""

    def to_dict(self) -> dict[str, object]:
        out: dict[str, object] = {"name": self.name, "status": self.status}
        if self.detail:
            out["detail"] = self.detail
        if self.error:
            out["error"] = self.error
        return out


def _resolve_callables(module_path: str) -> tuple[Callable[[], Any] | None, Callable[[], Any] | None]:
    """Return (get_state, do_install) callables from the tool module, if present."""
    mod = importlib.import_module(module_path)
    get_state = getattr(mod, "get_state", None)
    do_install = getattr(mod, "do_install", None)
    return get_state, do_install


def _state_needs_work(state_obj: Any) -> bool:
    """Check whether a get_state() return value indicates any work is needed (install or update)."""
    if state_obj is None:
        return True
    to_dict = getattr(state_obj, "to_dict", None)
    if not callable(to_dict):
        return True
    payload = to_dict()
    if not isinstance(payload, dict):
        return True
    for k, v in payload.items():
        if isinstance(k, str) and (k.startswith("needs_install") or k.startswith("needs_update")) and v:
            return True
    return False


def _state_is_installed(state_obj: Any) -> bool:
    """Check whether a get_state() return value indicates the tool is installed (ignoring updates)."""
    if state_obj is None:
        return False
    to_dict = getattr(state_obj, "to_dict", None)
    if not callable(to_dict):
        return False
    payload = to_dict()
    if not isinstance(payload, dict):
        return False
    # If any needs_install* key is True, it's not fully installed
    for k, v in payload.items():
        if isinstance(k, str) and k.startswith("needs_install") and v:
            return False
    # If we got state data, it means the tool is at least partially detectable
    # Check for explicit installed indicators
    if "binary" in payload and isinstance(payload["binary"], dict):
        return bool(payload["binary"].get("installed"))
    # If no needs_install is True and we have state data, consider it installed
    return True


def _install_one(tool: Tool, *, dry_run: bool) -> Result:
    # Skip when env required but missing
    if tool.mode is Mode.SKIP_ON_MISSING_ENV and not tool.env_present():
        return Result(
            name=tool.name,
            status="skipped",
            detail={"reason": f"missing env vars: {', '.join(tool.env_required)}"},
        )

    try:
        get_state, do_install = _resolve_callables(tool.module)
    except Exception as exc:  # noqa: BLE001
        return Result(name=tool.name, status="failed", error=f"import: {exc}")

    state_payload: dict[str, Any] = {}
    if get_state is not None:
        try:
            state_obj = get_state()
            state_payload = state_obj.to_dict() if hasattr(state_obj, "to_dict") else {}
        except Exception:  # noqa: BLE001
            state_obj = None
            state_payload = {}
        if not _state_needs_work(state_obj):
            return Result(name=tool.name, status="up-to-date", detail=state_payload)

    if dry_run:
        return Result(name=tool.name, status="installed", detail={"dry_run": True, **state_payload})

    if do_install is None:
        return Result(name=tool.name, status="failed", error="module has no do_install()")

    try:
        report = do_install()
    except Exception as exc:  # noqa: BLE001
        return Result(name=tool.name, status="failed", error=str(exc))

    payload = report.to_dict() if hasattr(report, "to_dict") else {}
    if isinstance(payload, dict) and payload.get("error"):
        return Result(name=tool.name, status="failed", error=str(payload["error"]), detail=payload)
    return Result(name=tool.name, status="installed", detail=payload if isinstance(payload, dict) else {})


def install_all(
    *,
    dry_run: bool = False,
    only: tuple[str, ...] = (),
    skip: tuple[str, ...] = (),
) -> list[Result]:
    results: list[Result] = []
    for tool in TOOLS:
        if only and tool.name not in only:
            continue
        if tool.name in skip:
            results.append(Result(name=tool.name, status="skipped", detail={"reason": "user-skipped"}))
            continue
        result = _install_one(tool, dry_run=dry_run)
        results.append(result)
        # On REQUIRED failure, abort the chain
        if tool.mode is Mode.REQUIRED and result.status == "failed":
            results.append(
                Result(name="__abort__", status="failed", error=f"{tool.name} is REQUIRED — aborting remaining tools")
            )
            break
    return results


cli = typer.Typer(no_args_is_help=True, help="Install or update every Pysae CLI/MCP at once")


@cli.command()
def status() -> None:
    """Show installed/missing tools and required environment variables."""
    import shutil

    typer.echo("")
    typer.echo("  Tools")
    typer.echo("  " + "─" * 60)

    for tool in TOOLS:
        found = False
        state_payload: dict[str, Any] = {}

        # Use get_state() as the source of truth
        try:
            get_state, _ = _resolve_callables(tool.module)
            if get_state is not None:
                state_obj = get_state()
                state_payload = state_obj.to_dict() if hasattr(state_obj, "to_dict") else {}
                found = _state_is_installed(state_obj)
        except Exception:  # noqa: BLE001
            pass

        # Fallback: check binary on PATH
        if not found and not state_payload:
            found = shutil.which(tool.name) is not None

        needs_update = found and any(
            isinstance(k, str) and k.startswith("needs_update") and v for k, v in state_payload.items()
        )
        if not found:
            icon = "✗"
            color = typer.colors.RED
        elif needs_update:
            icon = "⬆"
            color = typer.colors.YELLOW
        else:
            icon = "✓"
            color = typer.colors.GREEN
        mode_tag = f" ({tool.mode.value})" if tool.mode != Mode.OPTIONAL else ""

        # Env vars status
        env_parts: list[str] = []
        for var in tool.env_required:
            if os.environ.get(var):
                env_parts.append(f"  ✓ ${var}")
            else:
                env_parts.append(f"  ✗ ${var}")

        update_hint = ""
        if needs_update:
            current = state_payload.get("binary", {}).get("version", "")
            latest = state_payload.get("latest", "")
            if current and latest:
                update_hint = f" ({current} → {latest})"
            elif latest:
                update_hint = f" (→ {latest})"
        typer.secho(f"  {icon} {tool.name:<20}{mode_tag}{update_hint}", fg=color, nl=not env_parts)
        if env_parts:
            typer.echo("")
        for part in env_parts:
            var_set = part.startswith("  ✓")
            typer.secho(f"    {part}", fg=typer.colors.GREEN if var_set else typer.colors.YELLOW)

    # Environment variables grouped by tool
    tools_with_env = [t for t in TOOLS if t.env_required]
    if tools_with_env:
        typer.echo("")
        typer.echo("  Environment variables")
        typer.echo("  " + "─" * 60)

        for tool in tools_with_env:
            typer.echo(f"  {tool.name}:")
            for var in tool.env_required:
                present = bool(os.environ.get(var))
                icon = "✓" if present else "✗"
                color = typer.colors.GREEN if present else typer.colors.YELLOW
                typer.secho(f"    {icon} ${var}", fg=color)
                if not present and var in tool.env_help:
                    typer.secho(f"      → {tool.env_help[var]}", fg=typer.colors.BRIGHT_BLACK)
            typer.echo("")


@cli.command()
def install(
    only: Annotated[
        list[str] | None,
        typer.Option("--only", help="Only install these tools (repeatable). Default: all."),
    ] = None,
    skip: Annotated[
        list[str] | None,
        typer.Option("--skip", help="Skip these tools (repeatable)."),
    ] = None,
    json_output: Annotated[bool, typer.Option("--json")] = True,
) -> None:
    """Install or update every applicable tool."""
    results = install_all(only=tuple(only or ()), skip=tuple(skip or ()))
    counts = {"installed": 0, "up-to-date": 0, "skipped": 0, "failed": 0}
    for r in results:
        counts[r.status] = counts.get(r.status, 0) + 1
    payload = {"results": [r.to_dict() for r in results], "summary": counts}
    if json_output:
        typer.echo(json.dumps(payload))
    else:
        for r in results:
            typer.echo(f"  {r.name:<22} {r.status}{f': {r.error}' if r.error else ''}")
        typer.echo("")
        typer.echo(f"Summary: {counts}")
    if counts["failed"]:
        raise typer.Exit(code=1)


if __name__ == "__main__":
    cli()
