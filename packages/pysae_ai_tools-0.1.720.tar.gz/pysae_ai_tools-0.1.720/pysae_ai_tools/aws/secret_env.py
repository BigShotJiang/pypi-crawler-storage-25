#!/usr/bin/env python3
"""Update keys in an AWS Secrets Manager secret.

Usage:
    pysae-ai-tools aws secret-env <secret-id> <key1>=<value1> [key2=$ENV_VAR] ...

Values prefixed with $ are resolved from environment variables.
Prints only "OK" or "FAILED: <reason>" — never prints secret values.
"""

import json
import os
import subprocess
import sys
from typing import Annotated

import typer


def main(
    secret_id: Annotated[str, typer.Argument(help="AWS Secrets Manager secret ID")],
    pairs: Annotated[list[str], typer.Argument(help="key=value (or key=$ENV_VAR) pairs")],
) -> None:
    """Read or write env-var secrets in AWS Secrets Manager."""
    if not pairs:
        print("FAILED: at least one key=value pair is required")
        sys.exit(1)

    updates: dict[str, str] = {}
    for pair in pairs:
        if "=" not in pair:
            print(f"FAILED: invalid pair '{pair}', expected key=value")
            sys.exit(1)
        key, value = pair.split("=", 1)
        if value.startswith("$"):
            env_var = value[1:]
            resolved = os.environ.get(env_var, "")
            if not resolved:
                print(f"FAILED: env var {env_var} is not set or empty")
                sys.exit(1)
            updates[key] = resolved
        else:
            updates[key] = value

    tmp = "/tmp/aws_secret_payload.json"
    try:
        result = subprocess.run(
            [
                "aws",
                "secretsmanager",
                "get-secret-value",
                "--secret-id",
                secret_id,
                "--query",
                "SecretString",
                "--output",
                "text",
            ],
            capture_output=True,
            text=True,
            check=True,
        )
        secrets = json.loads(result.stdout)
        secrets.update(updates)

        fd = os.open(tmp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
        with os.fdopen(fd, "w") as f:
            json.dump(secrets, f)

        subprocess.run(
            [
                "aws",
                "secretsmanager",
                "update-secret",
                "--secret-id",
                secret_id,
                "--secret-string",
                f"file://{tmp}",
            ],
            capture_output=True,
            text=True,
            check=True,
        )
        print("OK")
    except subprocess.CalledProcessError as e:
        print(f"FAILED: aws cli error ({e.returncode})")
        sys.exit(1)
    except json.JSONDecodeError:
        print("FAILED: could not parse current secret as JSON")
        sys.exit(1)
    except Exception as e:
        print(f"FAILED: {type(e).__name__}")
        sys.exit(1)
    finally:
        try:
            os.remove(tmp)
        except FileNotFoundError:
            pass


if __name__ == "__main__":
    typer.run(main)
