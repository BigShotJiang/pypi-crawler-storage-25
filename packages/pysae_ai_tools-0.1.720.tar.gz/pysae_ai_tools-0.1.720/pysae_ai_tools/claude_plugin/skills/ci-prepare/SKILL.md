---
name: ci-prepare
description: >
  Install project dependencies in CI mode: Node.js via nvm (.nvmrc),
  Python via poetry (pyproject.toml). Runs automatically in CI pipelines
  before other skills. Use when the user says /ci-prepare, 'install dependencies',
  'prepare CI', or when delegated from CI-mode skills.
allowed-tools:
  - Bash
  - Read
  - Glob
---

Install the project's runtime dependencies based on files present in the working directory. This skill runs in CI and must be non-interactive — no prompts, no browser auth.

## Process

Run the bundled script:
```bash
pysae-ai-tools ci prepare --json --deep [--dir /path/to/project]
```

The script:
1. **Detects** project type from marker files (`.nvmrc`, `pyproject.toml`). With `--deep`, scans subdirectories up to 3 levels deep for monorepo packages (skips `node_modules`, `.venv`, `.git`, etc.). Stops descending once a marker is found (no nested detection).
2. **Detects** the package manager from lock files (`yarn.lock` → yarn, `pnpm-lock.yaml` → pnpm, `package-lock.json` → npm, `[tool.poetry]` → poetry, `[project]` → pip)
3. **Installs** Node.js via nvm if `.nvmrc` is present
4. **Installs** packages via the detected Node.js package manager
5. **Installs** Python dependencies via poetry or pip
6. **Reports** each step as a JSON line and exits with code 1 if any install failed

Output example:
```json
{"action": "detect", "node": true, "python": true, "node_pm": "yarn", "python_pm": "poetry", "nvmrc_version": "20.11.0"}
{"action": "install", "tool": "nvm", "status": "ok", "version": "v20.11.0"}
{"action": "install", "tool": "yarn", "status": "ok"}
{"action": "install", "tool": "poetry", "status": "ok", "version": "Python 3.14.2"}
{"action": "done", "installed": ["nvm", "yarn", "poetry"], "failed": []}
```

If the script reports failures, read the `error` field in the failed install results and diagnose. Common issues:
- **nvm not found**: `NVM_DIR` not set or `nvm.sh` missing — install nvm first
- **poetry not found**: install it with `uv tool install poetry` (or `pipx install poetry`, or `python3 -m pip install --user poetry`)
- **lock file mismatch**: delete the lock file and regenerate, or run the install without `--frozen-lockfile`

## Gotchas

- **nvm is a shell function**, not a binary — the script sources `$NVM_DIR/nvm.sh` internally. If nvm is installed in a non-standard location, set `NVM_DIR` before running.
- **poetry may not be on PATH** — the script installs it via pip if missing.
- **CI environments are ephemeral** — do not cache or persist anything. Each run starts clean.
- **No interactive prompts** — the script uses `--no-interaction`, `--frozen-lockfile`, or equivalent flags for all commands.
- **yarn.lock takes priority** — if both `yarn.lock` and `package-lock.json` exist, yarn is used (most common in Pysae projects).

$ARGUMENTS
