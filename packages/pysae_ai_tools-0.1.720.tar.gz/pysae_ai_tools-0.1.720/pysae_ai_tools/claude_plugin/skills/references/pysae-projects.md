# Pysae Projects Reference

Central reference mapping Pysae repositories to their associated resources.

## Projects

### Application repositories

| Repository | K8s deployment | Description |
|-----------|----------------|-------------|
| `pysae/api` | `pysae-api` | Backend API (Python/FastAPI) |
| `pysae/op` | `op-dashboard` | Operator dashboard (Vue.js) |
| `pysae/driver` | `driver-app` | Driver mobile app (Vue.js) |
| `pysae/info` | `info-app` | Passenger info display (Vue.js) |
| `pysae/editor` | `editor` | Network editor (Vue.js) |
| `pysae/screen` | `screen` | On-board screen (Vue.js) |
| `pysae/gtfs-validator` | `gtfs-validator` | GTFS feed validation |
| `pysae/gtfsrt-to-siri` | `gtfsrt-to-siri` | GTFS-RT to SIRI converter |
| `pysae/prefect` | `prefect-worker` | Prefect flow workers |
| `pysae/nav-data-processor-api` | `nav-data-processor` | Nav data processor API |
| `pysae/shift/app` | `shift-app`, `shift-api` | Shift platform — monorepo (web Vue.js + API Node.js) |

To resolve the GitLab project ID for API calls on a different repo: `glab api "projects/pysae%2F<repo>/..."` (URL-encode the path). For subgroup repos: `pysae%2Fshift%2Fapp`.

### Platform & infra repositories

| Repository                   | Description                                                                         |
|------------------------------|-------------------------------------------------------------------------------------|
| `pysae/shift/specs`          | Shift API specifications (OpenAPI, design docs)                                     |
| `pysae/platform-tools`       | Developer tooling: Claude Code skills, CI scripts, GitLab webhook relay             |
| `pysae/argo-apps`            | ArgoCD app-of-apps definitions for all application deployments (dev, prod, review)  |
| `pysae/infra/argo-infra`     | ArgoCD definitions for infrastructure services (ingress, cert-manager, datadog...) |
| `pysae/infra/auth-proxy`     | Authentication proxy for internal services                                          |
| `pysae/infra/infra-common`   | Shared Terraform modules and infrastructure config (VPC, IAM, security)             |
| `pysae/infra/infra-cluster`  | EKS cluster Terraform configuration (dev and prod)                                  |
| `pysae/infra/pysae-perf`     | Performance testing suite (k6 load tests)                                           |

## Slack Channels

| Repository / keyword                          | Channel          | Channel ID    |
|-----------------------------------------------|------------------|---------------|
| `api`                                         | `#tech-api`      | `C05SWB6MXE3` |
| `driver`                                      | `#tech-driver`   | `C057538V93N` |
| `op`, `info`, `screen`, `shift`, or other frontend app | `#tech-frontend` | `C04ASKNPJES` |
| *(anything else)*                             | `#tech-global`   | `C098LM0192B` |

## OpenAPI Specifications

The Pysae API exposes OpenAPI 3.1.0 specs for each API version and visibility level. Specs are available in both dev and prod environments.

Base URLs:
- **Dev**: `https://dev.api.pysae.com` (offline nights and weekends)
- **Prod**: `https://api.pysae.com`

Spec URL pattern: `<base>/api/docs/<version>/<visibility>/openapi.json`

Swagger UI pattern: `<base>/docs/<version>/<visibility>` (redirects to latest version, public visibility by default)

| Version | Visibility | Prod spec URL | Title |
|---------|------------|---------------|-------|
| `v3` | `public` | `https://api.pysae.com/api/docs/v3/public/openapi.json` | Pysae Public API v3 |
| `v3` | `internal` | `https://api.pysae.com/api/docs/v3/internal/openapi.json` | Pysae Internal API v3 |
| `v4` | `public` | `https://api.pysae.com/api/docs/v4/public/openapi.json` | Pysae Public API v4 |
| `v4` | `internal` | `https://api.pysae.com/api/docs/v4/internal/openapi.json` | Pysae Internal API v4 |
| `v5` | `public` | `https://api.pysae.com/api/docs/v5/public/openapi.json` | Pysae Public API v5 |
| `v5` | `internal` | `https://api.pysae.com/api/docs/v5/internal/openapi.json` | Pysae Internal API v5 |
| `all` | `public` | `https://api.pysae.com/api/docs/all/public/openapi.json` | Pysae Public API (all versions merged) |
| `all` | `internal` | `https://api.pysae.com/api/docs/all/internal/openapi.json` | Pysae Internal API (all versions merged) |

Notes:
- `public` specs contain endpoints accessible with standard API keys
- `internal` specs include all endpoints (public + internal/admin) — prefer `internal` when importing a spec
- `all` merges endpoints from v3, v4, and v5 into a single spec
- v5 public is currently empty (no public endpoints yet)
- Dev URLs follow the same pattern with `dev.api.pysae.com` as base
- When importing into Postman, prefer importing **each version separately** (v3, v4, v5) rather than `all` — this gives one collection per version, making navigation and testing easier

## Kubernetes Deployments

### API flavors

The API is deployed as multiple specialized deployments ("flavors"), all sharing the same image but serving different workloads.

| Deployment suffix | Role                                                       |
|-------------------|------------------------------------------------------------|
| `api`             | Legacy tornado API                                         |
| `api-fast`        | High-throughput read endpoints (vehicle positions, SSE)    |
| `api-ndp`         | NDP (Numerical Data Platform) — bulk data ingestion/export |
| `api-gtfsrt`      | GTFS-RT feed generation                                    |
| `api-evt`         | Event processing (webhooks, async tasks)                   |
| `api-stats`       | Statistics and analytics endpoints                         |
| `api-simu`        | Simulation engine                                          |
| `api-docs`        | API documentation (Swagger/ReDoc)                          |

Deployment names follow the pattern `<env>-<suffix>` (e.g. `dev-api-fast`, `prod-api-ndp`).

### Deployment naming conventions

| Context      | Pattern                          | Namespace | kubectl context |
|--------------|----------------------------------|-----------|-----------------|
| Dev          | `dev-<service>`                  | `dev`     | `dev`           |
| Prod         | `prod-<service>`                 | `prod`    | `prod`          |
| Review       | `review-<slug>-<service>`        | `mr`      | `dev`           |
| Infra        | `<app-name>`                     | per-app   | both            |

### Container registry

All app images are stored in AWS ECR: `596368530845.dkr.ecr.eu-west-3.amazonaws.com/apps/<service>:<tag>`

Image tag formats:
- Dev: `main-<short-sha>` (or `main-<short-sha>-dev` for driver/info)
- Prod: `v<major>-<minor>-<patch>-<short-sha>` (semver)
- Review: `<branch-slug>-<short-sha>`

## ArgoCD Deployments

### Application services

Apps that map to a GitLab repository and are deployed per environment.

| Repository            | Dev app                | Prod app                | Review app pattern                    | Namespace (dev/prod/review) |
|-----------------------|------------------------|-------------------------|---------------------------------------|-----------------------------|
| `pysae/api`           | `dev-api`              | `prod-api`              | `review-<slug>-api`                   | `dev` / `prod` / `mr`      |
| `pysae/driver`        | `dev-driver`           | `prod-driver`           | `review-<slug>-driver`                | `dev` / `prod` / `mr`      |
| `pysae/op`            | `dev-op`               | `prod-op`               | `review-<slug>-op`                    | `dev` / `prod` / `mr`      |
| `pysae/editor`        | `dev-editor`           | `prod-editor`           | `review-<slug>-editor`               | `dev` / `prod` / `mr`      |
| `pysae/info`          | `dev-info`             | `prod-info`             | `review-<slug>-info`                  | `dev` / `prod` / `mr`      |
| `pysae/screen`        | `dev-screen`           | `prod-screen`           | `review-<slug>-screen`               | `dev` / `prod` / `mr`      |
| `pysae/gtfs-validator`| `dev-gtfs-validator`   | `prod-gtfs-validator`   | `review-<slug>-gtfs-validator`        | `dev` / `prod` / `mr`      |
| `pysae/gtfsrt-to-siri`| `dev-gtfsrt-to-siri`  | `prod-gtfsrt-to-siri`   | `review-<slug>-gtfsrt-to-siri`       | `dev` / `prod` / `mr`      |
| `pysae/shift/app`     | `dev-shift-app`, `dev-shift-api` | `prod-shift-app`, `prod-shift-api` | `review-<slug>-shift-app`, `review-<slug>-shift-api` | `dev` / `prod` / `mr` |
| `pysae/platform-tools`| `dev-gitlab-webhook-relay` | —                    | `review-<slug>-gitlab-webhook-relay`  | `gitlab`                    |

Review environments deploy all apps together under namespace `mr`, with app names following the pattern `review-<slug>-<service>`. The orchestrator app is `review-<slug>-main`.

### Prefect workers

| Environment | App                  | Source                                    | Namespace |
|-------------|----------------------|-------------------------------------------|-----------|
| Dev         | `dev-prefect-worker` | `prefecthq.github.io/prefect-helm`        | `dev`     |
| Prod        | `prod-prefect-worker`| `prefecthq.github.io/prefect-helm`        | `prod`    |

### Infrastructure services

Managed via `pysae/infra/argo-infra` and `pysae/infra/auth-proxy`. Deployed on both clusters.

| App                              | Namespace                        | Source repo                        |
|----------------------------------|----------------------------------|------------------------------------|
| `nginx-ingress-controller`       | `ingress`                        | `pysae/infra/argo-infra`           |
| `cert-manager`                   | `cert-manager`                   | `pysae/infra/argo-infra`           |
| `cert-manager-issuers`           | `cert-manager`                   | `pysae/infra/argo-infra`           |
| `datadog`                        | `datadog`                        | `pysae/infra/argo-infra`           |
| `external-dns`                   | `external-dns`                   | `pysae/infra/argo-infra`           |
| `external-secrets`               | `dev`                            | `pysae/infra/argo-infra`           |
| `keda`                           | `keda`                           | `pysae/infra/argo-infra`           |
| `kyverno`                        | `kyverno`                        | `pysae/infra/argo-infra`           |
| `autoscaler`                     | `autoscaler`                     | `pysae/infra/argo-infra`           |
| `aws-node-termination-handler`   | `aws-node-termination-handler`   | `pysae/infra/argo-infra`           |
| `descheduler`                    | `descheduler`                    | `pysae/infra/argo-infra`           |
| `oauth2-proxy`                   | `oauth2-proxy`                   | `pysae/infra/argo-infra`           |
| `auth-proxy`                     | `auth-proxy`                     | `pysae/infra/auth-proxy`           |
| `metabase`                       | `metabase`                       | `pysae/infra/argo-infra`           |
| `n8n`                            | `n8n`                            | `pysae/infra/argo-infra`           |
| `uptime-kuma`                    | `uptime-kuma`                    | `pysae/infra/argo-infra`           |

### Root apps (App-of-Apps)

| App            | Cluster | Source repo                |
|----------------|---------|----------------------------|
| `apps-root`    | both    | `pysae/argo-apps`          |
| `infra-root`   | both    | `pysae/infra/argo-infra`   |
| `dev-main`     | dev     | `pysae/argo-apps`          |
| `prod-main`    | prod    | `pysae/argo-apps`          |

## Datadog

### Environment tags (`env`)

| Value | Description |
|-------|-------------|
| `prod` | Production |
| `dev` | Development (main branch deployed) |
| `review-<slug>` | Review environment (one per MR, slug = branch name) |
| `local` | Local development |
| `global` | Cross-environment (used for finops/cost monitors) |

### Service names (`service`)

Service names in Datadog map to deployment flavors, not repositories.

| Service | Repository | Notes |
|---------|------------|-------|
| `api` | `pysae/api` | Main REST API (FastAPI) |
| `api-nav-data-processor` | `pysae/api` | NDP flavor (`api-ndp` deployment) |
| `api-gtfs-rt` | `pysae/api` | GTFS-RT flavor (`api-gtfsrt` deployment) |
| `api-stats` | `pysae/api` | Statistics flavor |
| `api-simulation` | `pysae/api` | Simulation flavor (`api-simu` deployment) |
| `events-handler` | `pysae/api` | Event processing flavor (`api-evt` deployment) |
| `docs` | `pysae/api` | API documentation (`api-docs` deployment) |
| `driver` | `pysae/driver` | Driver app (browser RUM) |
| `op` | `pysae/op` | Operator dashboard (browser RUM) |
| `editor` | `pysae/editor` | Network editor (browser RUM) |
| `info` | `pysae/info` | Passenger info display (browser RUM) |
| `screen` | `pysae/screen` | On-board screen (browser RUM) |
| `gtfsrt-to-siri` | `pysae/gtfsrt-to-siri` | GTFS-RT to SIRI converter |
| `gtfs-validator` | `pysae/gtfs-validator` | GTFS validator |
| `shift-app` | `pysae/shift/app` | Shift web frontend (browser RUM) |
| `shift-api` | `pysae/shift/app` | Shift API backend |
| `gitlab-webhook-relay` | `pysae/platform-tools` | GitLab webhook relay |
| `prefect` / `pysae-prefect` | — | Prefect workers |
| `redis` | — | Redis instances |

### Monitors

Monitors are tagged with `env` and `service`. Finops monitors use `team:finops` and `type:budget`.

## Prefect

### Work Pools

| Name | Type | Environment | Concurrency |
|------|------|-------------|-------------|
| `dev-k8s` | kubernetes | Dev | 10 |
| `prod-k8s` | kubernetes | Prod | 10 |
| `dev-process-k8s` | process | Dev | None |
| `prod-process-k8s` | process | Prod | None |
| `default-agent-pool` | prefect-agent | — | None |

### Flows

| Flow | Description |
|------|-------------|
| `Publish GTFS` | Publish static GTFS feeds for transit agencies |
| `Synchronize external transit data` | Sync transit data from external sources |
| `Launch notification on long trip` | Alert on abnormally long driver trips |
| `Delete device stale trip` | Clean up stale trips from devices |
| `Cleanup repos` | Clean up old/unused repositories |
| `remove old review environments` | Remove expired review environments from ArgoCD |
| `Migrate groups and repos` | Data migration for groups and repositories |
| `Delete deprecated collections` | Remove deprecated MongoDB collections |

### Deployments

Deployments follow the pattern `<flow>/<flow> (<env>)` and run on `<env>-k8s` work pools.

| Flow | Dev deployment | Prod deployment |
|------|---------------|-----------------|
| Publish GTFS | `dev-k8s` | `prod-k8s` |
| Synchronize external transit data | `dev-k8s` | `prod-k8s` |
| Launch notification on long trip | `dev-k8s` | `prod-k8s` |
| Cleanup repos | `dev-k8s` | `prod-k8s` |
| remove old review environments | `dev-k8s` | `prod-k8s` |
| Migrate groups and repos | — | `prod-k8s` |

## AWS

Account: `596368530845` | Region: `eu-west-3` (Paris)

### EKS Clusters

| Cluster | Purpose |
|---------|---------|
| `dev` | Development + review environments |
| `prod` | Production |
| `pysae-perf` | Performance/load testing |

### Secrets Manager

Application secrets follow the pattern `pysae/<env>/secrets`. Each secret is a JSON object containing key-value pairs.

| Secret | Description |
|--------|-------------|
| `pysae/prod/secrets` | Production application secrets |
| `pysae/dev/secrets` | Development application secrets |
| `pysae/review/secrets` | Review environment secrets (shared across all review envs) |
| `pysae/testing/secrets` | Testing/CI secrets |
| `pysae/local-dev/secrets` | Local development (mongo-uri only) |
| `pysae/local-prod/secrets` | Local prod-like development (mongo-uri only) |
| `prod/sftp-bastion/ssh-private-key` | SSH key for EKS pods to SCP files to SFTP bastion (prod) |
| `DdApiKeySecret-Cr3SbiBZUGvq` | Datadog API key (used by Datadog agent on EKS) |

#### Secret keys detail

Keys present in each environment secret (`pysae/<env>/secrets`):

| Key | Env var | Description | Flavors | prod | dev | review | testing |
|-----|---------|-------------|---------|:----:|:---:|:------:|:-------:|
| `api-mongo-uri` | `MONGO_URI` | MongoDB connection string | all | x | x | x | x |
| `api-auth0-mgmt-client-id` | `AUTH0_MGMT_CLIENT_ID` | Auth0 Management API client ID | fast, stats | x | x | x | |
| `api-auth0-mgmt-client-secret` | `AUTH0_MGMT_CLIENT_SECRET` | Auth0 Management API client secret | fast, stats | x | x | x | |
| `api-firebase-json` | *(mounted as file)* | Firebase service account JSON (push notifications) | fast, ndp, gtfsrt, stats, simu | x | x | | |
| `api-prefect-api-key` | `PREFECT_API_KEY` | Prefect Cloud API key (flow triggers) | all | x | x | x | x |
| `api-recaptcha-secret` | `RECAPTCHA_SECRET` | Google reCAPTCHA secret key | fast | x | x | x | x |
| `api-twilio-auth-token` | `TWILIO_AUTH_TOKEN` | Twilio auth token (SMS notifications) | fast, ndp, stats | x | x | x | x |
| `gtfsrt-to-siri-auth0-client-secret` | — | Auth0 client secret for SIRI auth | *(gtfsrt-to-siri)* | x | x | x | |
| `gitlab-webhook-relay-trigger-token` | — | GitLab pipeline trigger token | *(webhook-relay)* | x | x | | |
| `gitlab-webhook-relay-webhook-secret` | — | GitLab webhook signature secret | *(webhook-relay)* | x | x | | |
| `prefect-worker-api-key` | — | Prefect Cloud API key (worker auth) | *(prefect-worker)* | x | x | x | x |

### ECR (Container Registry)

Base URI: `596368530845.dkr.ecr.eu-west-3.amazonaws.com`

| Repository | Description |
|------------|-------------|
| `apps/api` | API image (all flavors share this image) |
| `apps/api-fast` | API fast image (legacy, may still be referenced) |
| `apps/api-static` | API static assets |
| `apps/nav-data-processor-api` | NDP (Nav Data Processor) API image |
| `apps/driver` | Driver app |
| `apps/op` | Operator dashboard |
| `apps/editor` | Network editor |
| `apps/info` | Passenger info display |
| `apps/screen` | On-board screen |
| `apps/gtfs-validator` | GTFS validator |
| `apps/gtfsrt-to-siri` | GTFS-RT to SIRI converter |
| `apps/shift-app` | Shift web frontend |
| `apps/shift-api` | Shift API backend |
| `apps/gitlab-webhook-relay` | GitLab webhook relay |
| `infra/pysae-prefect` | Prefect worker image |
| `infra/auth-proxy` | Authentication proxy |
| `infra/ci-deployer` | CI deployment helper image |
| `infra/backup-restore` | Database backup/restore image |

### S3 Buckets

| Bucket | Purpose |
|--------|---------|
| `pysae-prefect` | Prefect storage (shared) |
| `pysae-prefect-dev` | Prefect storage (dev) |
| `pysae-prefect-prod` | Prefect storage (prod) |
| `pysae-db-dump` | Database dumps |
| `pysae-billing` | Billing data |
| `pysae-public-files` | Public files (accessible without auth) |
| `pysae-public-tools` | Public tools/scripts |
| `pysae-tf-states` | Terraform remote state |
| `pysae-orchestration-test` | Orchestration testing |
| `gtfs2netex-bucket` | GTFS to NeTEx conversion data |
| `datadogintegration-forwarderstack--forwarderbucket-*` | Datadog log forwarder (managed by CloudFormation) |

## Operational

### Dev environment wake-up / sleep

The dev environment has a cost-saving mechanism:
- **Sleep**: scales down dev deployments to 0 replicas (nightly or manual)
- **Wake-up**: scales back up (morning or manual trigger via CI job in `infra-cluster`)

### Cross-repo deploy dependencies

Some deploys require coordination across repositories:

| Change in | May require deploy of |
|-----------|----------------------|
| `pysae/api` (new endpoint) | op, driver, info (API consumers) |
| `pysae/api` (OpenAPI spec change) | op (Orval codegen) |
| `pysae/infra/gitlab-templates` | All repos (CI template consumers) |
| `pysae/argo-apps` (values change) | Target service (ArgoCD sync) |
| `pysae/gtfsrt-to-siri` (new feature) | op (UI for SIRI config) |
