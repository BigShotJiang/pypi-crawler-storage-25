"""Route registration for the igrep Management API.

NOTE: This file intentionally does NOT use `from __future__ import annotations`
      because FastAPI needs runtime type annotations for parameter detection.
"""

from pathlib import Path
from typing import Any

from fastapi import FastAPI, HTTPException


def _require_running_build_coordinator(
    detail: str = "This endpoint requires a running serve coordinator",
) -> Any:
    """Return the current build coordinator or raise 409."""
    from igrep.build_coordinator import get_current_build_coordinator

    coordinator = get_current_build_coordinator()
    if coordinator is None:
        raise HTTPException(status_code=409, detail=detail)
    return coordinator


def _build_runtime_status(path: str) -> dict[str, Any] | None:
    """Get runtime build status for a path from the coordinator."""
    from igrep.build_coordinator import get_current_build_coordinator

    coordinator = get_current_build_coordinator()
    if coordinator is not None:
        return coordinator.get_status(path)
    return None


def _watch_runtime_status(path: str) -> dict[str, Any] | None:
    """Get watcher status for a path from the active WatchManager."""
    from igrep.watch import get_current_watch_manager

    manager = get_current_watch_manager()
    if manager is None:
        return None
    return manager.get_status(path)


def _attach_runtime_status(d: dict[str, Any], path: str) -> None:
    """Attach build + watch runtime status to a response dict."""
    build = _build_runtime_status(path)
    if build is not None:
        d["build"] = build
    watch = _watch_runtime_status(path)
    if watch is not None:
        d["watch"] = watch


def _index_stats_to_dict(stats: dict[str, Any]) -> dict[str, Any]:
    """Extract standard index stats fields from raw stats dict."""
    return {
        "files": stats["files"],
        "chunks": stats["chunks"],
        "mode": stats["mode"],
        "db_size_bytes": stats["db_size_bytes"],
        "last_indexed": stats.get("last_indexed"),
        "index_generation": stats.get("index_generation", 0),
    }


def _registered_mode_for_path(path: str) -> str | None:
    """Return the nearest registered project mode for *path* when available."""
    from igrep.index_registry import lookup_longest_prefix_for_watch

    try:
        entry = lookup_longest_prefix_for_watch(path)
    except Exception:
        return None
    return entry.index_mode if entry is not None else None


def _validate_policy_or_raise(
    capabilities: dict[str, dict[str, str]],
    *,
    user_config_dir: Path,
) -> None:
    """Validate backend policy or raise HTTP 400."""
    from igrep.backend_config import validate_backend_policy

    try:
        validate_backend_policy(capabilities, user_config_dir=user_config_dir)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e)) from e


def register_routes(api: FastAPI) -> None:
    """Register all route modules on the API app."""
    from igrep.serve.routes import (
        backends,
        chat_draft,
        config,
        files,
        projects,
        search,
        watcher,
    )

    projects.register(api)
    search.register(api)
    chat_draft.register(api)
    files.register(api)
    config.register(api)
    backends.register(api)
    watcher.register(api)
