import logging
import re

from django.http import HttpResponseRedirect, StreamingHttpResponse

from . import bundler, storage
from .collector import Collector, get_collector, set_collector
from .conf import get_comments, get_enabled, get_query_param

logger = logging.getLogger(__name__)

PLACEHOLDER_RE = re.compile(r"<!-- __SUPPRESSOR:([\w]+):(css|js)__ -->")
SESSION_KEY = "suppressor_toggle"


class SuppressorMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response

    def _is_enabled(self, request):
        enabled = get_enabled()
        if get_query_param() and SESSION_KEY in request.session:
            enabled = not enabled
        return enabled

    _TRUTHY = frozenset(("1", "on", "yes", "true"))
    _FALSY = frozenset(("0", "off", "no", "false"))

    def _parse_toggle_value(self, raw):
        """Parse query param value. Returns True/False for explicit values, None for bare key."""
        if not raw:
            return None
        lower = raw.lower()
        if lower in self._TRUTHY:
            return True
        if lower in self._FALSY:
            return False
        return None

    def __call__(self, request):
        param = get_query_param()
        if param and param in request.GET:
            desired = self._parse_toggle_value(request.GET[param])
            if desired is None:
                # Bare key — toggle
                if SESSION_KEY in request.session:
                    del request.session[SESSION_KEY]
                else:
                    request.session[SESSION_KEY] = True
            else:
                # Explicit value — set or clear session to match
                default = get_enabled()
                if desired != default:
                    request.session[SESSION_KEY] = True
                elif SESSION_KEY in request.session:
                    del request.session[SESSION_KEY]
            query = request.GET.copy()
            del query[param]
            redirect_url = request.path
            if query:
                redirect_url += "?" + query.urlencode()
            return HttpResponseRedirect(redirect_url)

        if not self._is_enabled(request):
            return self.get_response(request)

        collector = Collector()
        set_collector(collector)
        try:
            response = self.get_response(request)
        finally:
            set_collector(None)

        if isinstance(response, StreamingHttpResponse):
            return response

        content_type = response.get("Content-Type", "")
        if "text/html" not in content_type:
            return response

        self._warn_orphaned(collector)

        content = response.content.decode(response.charset)
        if PLACEHOLDER_RE.search(content) is None:
            return response

        content = self._replace_placeholders(content, collector)
        response.content = content.encode(response.charset)
        return response

    def _warn_orphaned(self, collector):
        for region, asset_type in collector.get_orphaned_keys():
            logger.warning(
                "Suppressor: region %r captured %s assets but no "
                "suppressor_emit_%s tag was found. Those assets are lost.",
                region,
                asset_type,
                asset_type,
            )

    def _replace_placeholders(self, content, collector):
        def replacer(match):
            region = match.group(1)
            asset_type = match.group(2)
            assets = collector.get_assets(region, asset_type)

            if not assets:
                return ""

            bundle = bundler.build_bundle(
                assets, asset_type, comments=get_comments()
            )
            if bundle is None:
                # Total failure — restore all original tags
                return "\n".join(asset.tag_html for asset in assets)

            storage.store_bundle(bundle)

            parts = []
            # Re-inject failed assets' original tags
            for failed in bundle.failed_assets:
                parts.append(failed.tag_html)

            # Add bundle tag
            url = f"/_suppressor/{asset_type}/{bundle.hash_hex}.{asset_type}"
            if asset_type == "js":
                parts.append(f'<script src="{url}"></script>')
            else:
                parts.append(f'<link rel="stylesheet" href="{url}">')

            return "\n".join(parts)

        return PLACEHOLDER_RE.sub(replacer, content)
