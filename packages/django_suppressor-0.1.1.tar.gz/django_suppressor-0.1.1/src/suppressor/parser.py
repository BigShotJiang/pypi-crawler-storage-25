import logging
from html.parser import HTMLParser

from django.conf import settings

from .collector import AssetEntry

logger = logging.getLogger(__name__)


def is_same_origin(url):
    if url.startswith("/"):
        return True
    if "://" in url or url.startswith("//"):
        return False
    # Relative path without scheme — same-origin
    return True


def is_eligible_script(attrs):
    if "src" not in attrs:
        return False
    if "async" in attrs or "defer" in attrs:
        return False
    tag_type = attrs.get("type", "")
    if tag_type == "module":
        return False
    if "nomodule" in attrs:
        return False
    if "integrity" in attrs:
        return False
    if not is_same_origin(attrs["src"]):
        return False
    return True


def is_eligible_inline_script(attrs):
    if "src" in attrs:
        return False
    tag_type = attrs.get("type", "")
    if tag_type and tag_type not in ("text/javascript", "application/javascript"):
        return False
    if "nomodule" in attrs:
        return False
    return True


def is_eligible_link(attrs):
    rel = attrs.get("rel", "")
    if rel != "stylesheet":
        return False
    if "href" not in attrs:
        return False
    if "integrity" in attrs:
        return False
    if not is_same_origin(attrs["href"]):
        return False
    return True


def _attrs_dict(attrs_list):
    """Convert HTMLParser's attrs list to a dict.

    HTMLParser returns attrs as [(name, value), ...] where value is None
    for boolean attributes like ``async`` or ``nomodule``.
    """
    result = {}
    for name, value in attrs_list:
        result[name] = value if value is not None else ""
    return result


class _AssetExtractor(HTMLParser):
    def __init__(self, source, capture_types, comments=False):
        super().__init__(convert_charrefs=False)
        self._source = source
        self._capture_types = capture_types or {"js", "css"}
        self._comments = comments
        self._extracted = []
        self._replacements = []  # (start, end, replacement_string)
        # Pre-compute line start offsets for getpos() → offset conversion
        self._line_offsets = [0]
        for idx, char in enumerate(source):
            if char == "\n":
                self._line_offsets.append(idx + 1)
        # State for tracking external <script src="..."> open/close
        self._in_eligible_script = False
        self._script_start_offset = 0
        self._script_entry = None
        # State for tracking inline <script>...</script> open/close
        self._in_inline_script = False
        self._inline_script_start_offset = 0
        self._inline_script_content_start = 0
        # State for tracking <style> open/close
        self._in_eligible_style = False
        self._style_start_offset = 0
        self._style_content_start = 0

    def _offset(self):
        line, col = self.getpos()
        return self._line_offsets[line - 1] + col

    def handle_starttag(self, tag, attrs_list):
        attrs = _attrs_dict(attrs_list)
        offset = self._offset()

        if tag == "link" and "css" in self._capture_types and is_eligible_link(attrs):
            raw = self.get_starttag_text()
            end = offset + len(raw)
            self._replacements.append((offset, end, self._comment_for(raw)))
            self._extracted.append(
                AssetEntry(
                    url=attrs["href"],
                    tag_html=raw,
                    asset_type="css",
                )
            )
            return

        if (
            tag == "script"
            and "js" in self._capture_types
            and is_eligible_script(attrs)
        ):
            self._in_eligible_script = True
            self._script_start_offset = offset
            self._script_entry = AssetEntry(
                url=attrs["src"],
                tag_html="",  # filled in handle_endtag
                asset_type="js",
            )
            return

        if (
            tag == "script"
            and "js" in self._capture_types
            and is_eligible_inline_script(attrs)
        ):
            raw = self.get_starttag_text()
            self._in_inline_script = True
            self._inline_script_start_offset = offset
            self._inline_script_content_start = offset + len(raw)
            return

        if tag == "style" and "css" in self._capture_types:
            raw = self.get_starttag_text()
            self._in_eligible_style = True
            self._style_start_offset = offset
            self._style_content_start = offset + len(raw)
            return

    def handle_startendtag(self, tag, attrs_list):
        # Handles self-closing <link ... /> syntax
        attrs = _attrs_dict(attrs_list)
        offset = self._offset()

        if tag == "link" and "css" in self._capture_types and is_eligible_link(attrs):
            raw = self.get_starttag_text()
            end = offset + len(raw)
            self._replacements.append((offset, end, self._comment_for(raw)))
            self._extracted.append(
                AssetEntry(
                    url=attrs["href"],
                    tag_html=raw,
                    asset_type="css",
                )
            )

    def handle_endtag(self, tag):
        if tag == "script" and self._in_eligible_script:
            offset = self._offset()
            end = self._source.index(">", offset) + 1
            full_tag = self._source[self._script_start_offset : end]
            self._script_entry.tag_html = full_tag
            self._replacements.append(
                (self._script_start_offset, end, self._comment_for(full_tag))
            )
            self._extracted.append(self._script_entry)
            self._in_eligible_script = False
            self._script_entry = None

        elif tag == "script" and self._in_inline_script:
            offset = self._offset()
            end = self._source.index(">", offset) + 1
            full_tag = self._source[self._inline_script_start_offset : end]
            js_content = self._source[self._inline_script_content_start : offset]
            self._replacements.append(
                (
                    self._inline_script_start_offset,
                    end,
                    self._comment_for_inline("script"),
                )
            )
            self._extracted.append(
                AssetEntry(
                    url="",
                    tag_html=full_tag,
                    asset_type="js",
                    inline_content=js_content,
                )
            )
            self._in_inline_script = False

        if tag == "style" and self._in_eligible_style:
            offset = self._offset()
            end = self._source.index(">", offset) + 1
            full_tag = self._source[self._style_start_offset : end]
            css_content = self._source[self._style_content_start : offset]
            self._replacements.append(
                (self._style_start_offset, end, self._comment_for_inline("style"))
            )
            self._extracted.append(
                AssetEntry(
                    url="",
                    tag_html=full_tag,
                    asset_type="css",
                    inline_content=css_content,
                )
            )
            self._in_eligible_style = False

    def _comment_for(self, tag_html):
        if self._comments:
            return f"<!-- {tag_html} -->"
        return ""

    def _comment_for_inline(self, tag_name):
        if self._comments:
            return f"<!-- suppressor: <{tag_name}> (inline) -->"
        return ""

    def error(self, message):
        logger.debug("HTML parser error in suppressor: %s", message)


def extract_assets(fragment, capture_types=None, comments=False):
    parser = _AssetExtractor(fragment, capture_types, comments=comments)
    try:
        parser.feed(fragment)
    except Exception:
        logger.warning("Suppressor: fragment parsing failed, returning original")
        return fragment, []

    if not parser._replacements:
        return fragment, parser._extracted

    # Build modified fragment by replacing matched ranges
    # Sort by start offset (should already be in order, but be safe)
    replacements = sorted(parser._replacements)
    parts = []
    pos = 0
    for start, end, replacement in replacements:
        parts.append(fragment[pos:start])
        parts.append(replacement)
        pos = end
    parts.append(fragment[pos:])

    modified = "".join(parts)
    return modified, parser._extracted
