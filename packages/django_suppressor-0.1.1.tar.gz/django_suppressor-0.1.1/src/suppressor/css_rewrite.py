import logging
import re
from urllib.parse import urljoin

logger = logging.getLogger(__name__)

_URL_RE = re.compile(r"""url\(\s*(['"]?)(.*?)\1\s*\)""")
_SOURCE_MAP_RE = re.compile(rb"/\*#\s*sourceMappingURL=.*?\*/", re.DOTALL)

_SKIP_PREFIXES = ("/", "data:", "http://", "https://", "//", "#")


def rewrite_css_urls(css_content, asset_url):
    try:
        text = css_content.decode("utf-8")
    except (UnicodeDecodeError, ValueError):
        logger.warning("Suppressor: non-UTF-8 CSS in %s, skipping url() rewrite", asset_url)
        return css_content

    def replace_url(match):
        quote = match.group(1)
        ref = match.group(2).strip()

        if not ref or ref.startswith(_SKIP_PREFIXES):
            return match.group(0)

        resolved = urljoin(asset_url, ref)
        return f"url({quote}{resolved}{quote})"

    rewritten = _URL_RE.sub(replace_url, text)
    return rewritten.encode("utf-8")


def strip_source_map_comments(css_content):
    return _SOURCE_MAP_RE.sub(b"", css_content)
