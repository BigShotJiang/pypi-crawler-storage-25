# CSS `url()` Rewriting Plan

## Context

When CSS files are bundled, relative `url(...)` references break. A file at `/static/admin/css/base.css` with `url(../img/icon.svg)` resolves correctly to `/static/admin/img/icon.svg`. But once bundled into `/_suppressor/css/{hash}.css`, the browser resolves that same relative reference to `/_suppressor/img/icon.svg` (404).

This is the documented v0.1.1 item from the SPEC. Django admin CSS alone has 30+ such references across base.css, widgets.css, dark_mode.css, forms.css, and rtl.css.

## Approach

Rewrite relative `url()` values to absolute paths **per-chunk, before concatenation** in the bundler.

### What gets rewritten vs skipped

| Input | Action |
|-------|--------|
| `url(../img/icon.svg)` | Rewrite to `/static/admin/img/icon.svg` |
| `url(widgets.css)` | Rewrite to `/static/admin/css/widgets.css` |
| `url(/static/img/icon.svg)` | Skip (already absolute) |
| `url(data:image/svg+xml,...)` | Skip |
| `url(https://cdn.example.com/...)` | Skip |
| `url(//cdn.example.com/...)` | Skip |
| `url(#gradient)` | Skip |
| `url()` (empty) | Skip |
| Inline `<style>` content | Skip entirely (no base URL to resolve against) |

### Resolution method

`urllib.parse.urljoin(asset_url, relative_ref)` handles `../` traversal correctly and is battle-tested stdlib.

### Regex

```
url\(\s*(['"]?)(.*?)\1\s*\)
```

Handles unquoted, single-quoted, double-quoted, with whitespace. Applied via `re.sub` with callback.

### Source map comments

Strip `/*# sourceMappingURL=... */` since they point to wrong locations in bundled context and can't be meaningfully fixed without generating new source maps.

### `@import "file.css"` (bare, without `url()`)

Not handled. Rare in practice. Only `@import url(...)` form gets rewritten via the same regex.

## File Changes

### 1. NEW: `src/suppressor/css_rewrite.py`

Two functions:

- `rewrite_css_urls(css_content: bytes, asset_url: str) -> bytes` - regex-based url() rewriting
- `strip_source_map_comments(css_content: bytes) -> bytes` - remove sourceMappingURL comments

UTF-8 decode with fallback (return unchanged + log warning on decode failure).

### 2. MODIFY: `src/suppressor/bundler.py`

In `build_bundle()`, after `content = resolve_asset(asset.url)` succeeds and before appending to `resolved_chunks`, for CSS assets:

```python
if asset_type == "css":
    content = rewrite_css_urls(content, asset.url)
    content = strip_source_map_comments(content)
```

Only for external assets (not inline). Rewriting happens before comment headers are added (correct ordering).

### 3. MODIFY: `src/suppressor/conf.py`

Bump `FORMAT_VERSION` from `"s1"` to `"s2"` to invalidate all cached bundles.

### 4. MODIFY: `README.md`

Remove/update the CSS `url(...)` limitation note.

## Verification

1. Run the demo app with Django admin CSS
2. Check the bundled CSS output at `/_suppressor/css/{hash}.css` - relative paths should be absolute
3. Verify admin icons render (no 404s in network tab)
4. Test with `SUPPRESSOR_COMMENTS = True` to verify comment headers still work correctly
