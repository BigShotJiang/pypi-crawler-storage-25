# Session-Persistent Query Param Toggle

## Context

The `SUPPRESSOR_QUERY_PARAM` currently acts as a per-request toggle: visiting `?suppress` flips `SUPPRESSOR_ENABLED` for that single request only. The user wants this to be **sticky via Django sessions** so you toggle once and it persists across navigation, and the query param is stripped from the URL via a redirect.

## Behavior

1. **Query param present in request** (`?suppress`):
   - If session key exists: **clear it** (toggle off)
   - If session key absent: **set it** (toggle on)
   - **Redirect** to the same URL with the query param removed
2. **Query param absent** (normal request):
   - If session key is set: flip the default `enabled` value
   - If session key is absent: use default `enabled` value

This means the query param is a **toggle switch for the session override**. One visit with `?suppress` turns it on, another visit with `?suppress` turns it off.

## File Changes

### `src/suppressor/middleware.py`

1. Add import: `HttpResponseRedirect` from `django.http`
2. Add constant: `SESSION_KEY = "suppressor_toggle"`
3. In `__call__`, **before** the enabled check and response processing:
   - Check if query param is configured and present in `request.GET`
   - If so: toggle the session key, build redirect URL (same path + remaining query params), return `HttpResponseRedirect`
4. In `_is_enabled`: replace the `request.GET` check with a session check — if `SESSION_KEY` in `request.session`, flip `enabled`

```python
def __call__(self, request):
    # Handle toggle redirect first
    param = get_query_param()
    if param and param in request.GET:
        if SESSION_KEY in request.session:
            del request.session[SESSION_KEY]
        else:
            request.session[SESSION_KEY] = True
        # Build URL without the toggle param
        query = request.GET.copy()
        del query[param]
        redirect_url = request.path
        if query:
            redirect_url += "?" + query.urlencode()
        return HttpResponseRedirect(redirect_url)

    if not self._is_enabled(request):
        return self.get_response(request)
    # ... rest unchanged
```

```python
def _is_enabled(self, request):
    enabled = get_enabled()
    if get_query_param() and SESSION_KEY in request.session:
        enabled = not enabled
    return enabled
```

No other files need changes.

## Verification

1. Start demo app with `SUPPRESSOR_QUERY_PARAM = "suppress"` and `SUPPRESSOR_ENABLED = True`
2. Visit `/` — suppressor active (bundled assets)
3. Visit `/?suppress` — redirects to `/`, session now has toggle, suppressor disabled (unbundled)
4. Visit `/` again — still disabled (session persists)
5. Visit `/?suppress` — redirects to `/`, session cleared, suppressor re-enabled
6. Visit `/?suppress&other=1` — redirects to `/?other=1`, toggle works, extra params preserved
