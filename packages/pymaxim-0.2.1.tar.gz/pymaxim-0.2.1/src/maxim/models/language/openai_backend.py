"""OpenAI backend for cloud LLM inference (optional dependency)."""

from __future__ import annotations

import ipaddress
import logging
import os
import socket
import time
from typing import Any
from urllib.parse import urlparse

from maxim.utils.logging import warn

log = logging.getLogger(__name__)
from maxim.models.language.config import LLMConfig
from maxim.models.language.types import LLMResponse


def _is_auth_error(err: Exception) -> bool:
    msg = str(err).lower()
    return "401" in msg or "403" in msg or "unauthorized" in msg or "forbidden" in msg


def _is_rate_limit_error(err: Exception) -> bool:
    msg = str(err).lower()
    return "429" in msg or "rate" in msg


def _http_status_of(err: Exception | None) -> int | None:
    """Best-effort extraction of HTTP status code from an openai client error."""
    if err is None:
        return None
    code = getattr(err, "status_code", None)
    if isinstance(code, int):
        return code
    response = getattr(err, "response", None)
    if response is not None:
        code = getattr(response, "status_code", None)
        if isinstance(code, int):
            return code
    # Last-resort string scan
    msg = str(err)
    for candidate in ("401", "403", "404", "429", "500", "502", "503", "504"):
        if candidate in msg:
            return int(candidate)
    return None


def _is_bad_gateway_error(err: Exception) -> bool:
    """Detect 502/503/504 — transient upstream errors (server restarting)."""
    status = _http_status_of(err)
    return status in (502, 503, 504)


def _parse_processing_ms(headers: Any) -> float | None:
    """Extract server-side processing time from openai-processing-ms header."""
    val = None
    if hasattr(headers, "get"):
        val = headers.get("openai-processing-ms")
    if val is None:
        return None
    try:
        return float(val)
    except (ValueError, TypeError):
        return None


def _is_private_ip(ip: str) -> bool:
    try:
        addr = ipaddress.ip_address(ip)
    except Exception:
        return True
    return addr.is_private or addr.is_loopback or addr.is_link_local or addr.is_reserved or addr.is_multicast


def _validate_base_url(base_url: str, allow_local: bool) -> str | None:
    try:
        parsed = urlparse(base_url)
    except Exception:
        return None
    # https required for public endpoints; http acceptable for self-hosted LAN
    # servers (llama-cpp-server, Ollama) running on private IPs.
    if parsed.scheme == "https":
        pass
    elif parsed.scheme == "http" and allow_local:
        pass
    else:
        return None
    host = parsed.hostname
    if not host:
        return None
    default_port = 443 if parsed.scheme == "https" else 80
    try:
        addrinfos = socket.getaddrinfo(host, parsed.port or default_port, proto=socket.IPPROTO_TCP)
    except Exception:
        return None
    for info in addrinfos:
        ip = info[4][0]
        if _is_private_ip(ip) and not allow_local:
            return None
        # http scheme is only allowed for private IPs, even when allow_local
        if parsed.scheme == "http" and not _is_private_ip(ip):
            return None
    return base_url


class _OpenAIBackend:
    """OpenAI backend using the official SDK."""

    def __init__(self, cfg: LLMConfig, provider_key: str = "openai") -> None:
        self.cfg = cfg
        self._provider_key = provider_key
        self._client: Any | None = None
        self.requires_prompt_formatting = False
        self.supports_model_override = True
        self.supports_streaming = True

    def _provider_cfg(self) -> dict[str, Any]:
        providers = getattr(self.cfg, "providers", {}) or {}
        raw = providers.get(self._provider_key, {})
        return raw if isinstance(raw, dict) else {}

    def _get_api_key(self) -> str:
        cfg = self._provider_cfg()
        env_key = str(cfg.get("api_key_env") or "OPENAI_API_KEY")
        return str(os.getenv(env_key, "")).strip()

    def _get_base_url(self) -> str | None:
        cfg = self._provider_cfg()
        base_url = cfg.get("base_url")
        if not base_url:
            return None
        allow_local = bool(cfg.get("allow_local_endpoints", False))
        validated = _validate_base_url(str(base_url).strip(), allow_local)
        if not validated:
            warn("Blocked base_url for provider %s (SSRF protection)", self._provider_key)
            return None
        return validated

    def _get_timeout(self) -> float:
        cfg = self._provider_cfg()
        try:
            return float(cfg.get("timeout_s", 60.0))
        except Exception:
            return 60.0

    def _get_max_retries(self) -> int:
        cfg = self._provider_cfg()
        try:
            return int(cfg.get("max_retries", 2))
        except Exception:
            return 2

    def _ensure_client(self) -> Any | None:
        if self._client is not None:
            return self._client
        try:
            from openai import OpenAI  # type: ignore
        except Exception as e:
            warn("OpenAI backend unavailable (install `openai`): %s", e)
            return None
        api_key = self._get_api_key()
        if not api_key:
            warn("OpenAI API key missing")
            return None
        try:
            base_url = self._get_base_url()
            if self._provider_key in ("openai_compatible", "openai_compat") and not base_url:
                warn("OpenAI-compatible provider requires a valid base_url")
                return None
            self._client = OpenAI(
                api_key=api_key,
                base_url=base_url,
                timeout=self._get_timeout(),
            )
            return self._client
        except Exception as e:
            warn("Failed to init OpenAI client: %s", e)
            return None

    def warmup(self) -> bool:
        """Validate API key presence (no billable call)."""
        return bool(self._get_api_key())

    def unload(self) -> None:
        self._client = None

    def complete(
        self,
        prompt: str,
        *,
        max_tokens: int,
        temperature: float,
        stop: tuple[str, ...],
        system: str | None = None,
    ) -> str:
        resp = self.complete_with_usage(
            system=system or "",
            user=prompt,
            max_tokens=max_tokens,
            temperature=temperature,
            stop=stop,
        )
        return resp.content

    def complete_with_usage(
        self,
        *,
        system: str,
        user: str,
        max_tokens: int,
        temperature: float,
        stop: tuple[str, ...] = (),
        model_override: str | None = None,
        stream: bool = False,
    ) -> LLMResponse:
        start = time.time()
        client = self._ensure_client()
        if client is None:
            return LLMResponse(content="")

        model = str(model_override or self._provider_cfg().get("model") or getattr(self.cfg, "model", "") or "").strip()

        messages = [
            {"role": "system", "content": system},
            {"role": "user", "content": user},
        ]

        # Stage A observability: generate a request-id for cross-machine
        # correlation. Attached as X-Maxim-Request-Id header on every call;
        # also logged via maxim.mesh.trace when MAXIM_LANE_TRACE or
        # MAXIM_PEER_LOG_REQUESTS is set.
        from maxim.models.language.mesh_trace import (
            REQUEST_ID_HEADER,
            TraceRecord,
            emit_trace,
            enrich_trace_with_leader_status,
            generate_request_id,
        )

        request_id = generate_request_id()
        base_url = self._get_base_url() or ""
        extra_headers = {REQUEST_ID_HEADER: request_id}

        last_err: Exception | None = None
        # Extra retries for transient upstream errors (502/503/504 during
        # leader restart).  Normal retries: 2.  Gateway retries: up to 4
        # additional attempts with longer backoff, giving the LLM server
        # time to finish loading the model.
        max_retries = self._get_max_retries()
        max_gateway_retries = 4
        gateway_retries_used = 0

        attempt = 0
        while attempt <= max_retries:
            try:
                if stream:
                    return self._stream_response(client, model, messages, temperature, max_tokens, stop, start)

                # Use with_raw_response to capture server-side timing headers
                raw_resp = client.chat.completions.with_raw_response.create(
                    model=model,
                    messages=messages,
                    temperature=temperature,
                    max_tokens=max_tokens,
                    stop=list(stop) if stop else None,
                    extra_headers=extra_headers,
                )
                resp = raw_resp.parse()
                server_ms = _parse_processing_ms(raw_resp.headers)

                parsed = self._parse_response(resp, model, start)
                trace = TraceRecord(
                    request_id=request_id,
                    provider=self._provider_key,
                    base_url=base_url,
                    model=model,
                    status="ok",
                    http_status=200,
                    latency_ms=parsed.latency_ms,
                    input_tokens=parsed.input_tokens,
                    output_tokens=parsed.output_tokens,
                    server_processing_ms=server_ms,
                )
                enrich_trace_with_leader_status(
                    trace,
                    base_url,
                    self._get_api_key(),
                    response_headers=raw_resp.headers,
                )
                emit_trace(trace)
                return parsed
            except Exception as e:
                last_err = e
                if _is_auth_error(e):
                    self._client = None

                # 502/503/504: upstream server restarting — use longer backoff
                # and grant extra retries beyond the normal limit.
                if _is_bad_gateway_error(e) and gateway_retries_used < max_gateway_retries:
                    gateway_retries_used += 1
                    backoff = min(5.0 * gateway_retries_used, 20.0)
                    log.warning(
                        "Upstream unavailable (502/503/504), retry %d/%d in %.0fs [req=%s]",
                        gateway_retries_used,
                        max_gateway_retries,
                        backoff,
                        request_id,
                    )
                    time.sleep(backoff)
                    # Don't consume a normal retry for gateway errors
                    continue

                if attempt < max_retries:
                    backoff = 0.5 * (attempt + 1)
                    if _is_rate_limit_error(e):
                        backoff = min(backoff * 4, 30.0)
                    time.sleep(backoff)
                    attempt += 1
                    continue
                break
            attempt += 1

        # Final failure — emit a trace record with error details before returning
        emit_trace(
            TraceRecord(
                request_id=request_id,
                provider=self._provider_key,
                base_url=base_url,
                model=model,
                status="error",
                http_status=_http_status_of(last_err),
                latency_ms=(time.time() - start) * 1000,
                error=str(last_err)[:200] if last_err else None,
            )
        )
        warn("OpenAI call failed [req=%s]: %s", request_id[:8], last_err)
        return LLMResponse(content="")

    def _parse_response(self, resp: Any, model: str, start: float) -> LLMResponse:
        """Parse an OpenAI chat completion response."""
        choice = resp.choices[0] if getattr(resp, "choices", None) else None
        content = ""
        if choice and getattr(choice, "message", None) is not None:
            content = str(getattr(choice.message, "content", "") or "").strip()

        usage = getattr(resp, "usage", None)
        input_tokens = getattr(usage, "prompt_tokens", 0) if usage is not None else 0
        output_tokens = getattr(usage, "completion_tokens", 0) if usage is not None else 0
        cached = 0
        details = getattr(usage, "prompt_tokens_details", None) if usage is not None else None
        if details is not None:
            cached = getattr(details, "cached_tokens", 0) or 0
        uncached = max(0, input_tokens - cached) if input_tokens else 0

        return LLMResponse(
            content=content,
            input_tokens=int(input_tokens or 0),
            output_tokens=int(output_tokens or 0),
            model=model,
            latency_ms=(time.time() - start) * 1000,
            provider=self._provider_key,
            stop_reason=str(getattr(choice, "finish_reason", "")) if choice else "",
            cached_input_tokens=int(cached or 0),
            uncached_input_tokens=int(uncached or 0),
        )

    def _stream_response(
        self,
        client: Any,
        model: str,
        messages: list[dict[str, str]],
        temperature: float,
        max_tokens: int,
        stop: tuple[str, ...],
        start: float,
    ) -> LLMResponse:
        """Stream a response, collecting text incrementally."""
        text_parts: list[str] = []
        stop_reason = ""

        stream = client.chat.completions.create(
            model=model,
            messages=messages,
            temperature=temperature,
            max_tokens=max_tokens,
            stop=list(stop) if stop else None,
            stream=True,
            stream_options={"include_usage": True},
        )

        input_tokens = 0
        output_tokens = 0

        for chunk in stream:
            if getattr(chunk, "usage", None):
                usage = chunk.usage
                input_tokens = getattr(usage, "prompt_tokens", 0) or 0
                output_tokens = getattr(usage, "completion_tokens", 0) or 0

            choices = getattr(chunk, "choices", None)
            if not choices:
                continue
            delta = getattr(choices[0], "delta", None)
            if delta:
                text = getattr(delta, "content", None)
                if text:
                    text_parts.append(str(text))
            finish = getattr(choices[0], "finish_reason", None)
            if finish:
                stop_reason = str(finish)

        content = "".join(text_parts).strip()

        return LLMResponse(
            content=content,
            input_tokens=int(input_tokens or 0),
            output_tokens=int(output_tokens or 0),
            model=model,
            latency_ms=(time.time() - start) * 1000,
            provider=self._provider_key,
            stop_reason=stop_reason,
            cached_input_tokens=0,
            uncached_input_tokens=int(input_tokens or 0),
        )
