import random
import time
import requests

class MealError(Exception):
    """Raised when the Munchy API returns a non-200 status code."""
    def __init__(self, message):
        # Pass the message to the base Exception class
        super().__init__(message)

def fetch():
	"""
	Fetches the static dataset from the raw GitHub endpoint.
	Appends a dynamic Unix timestamp parameter to force cache clearing.
	"""
	timestamp = round(time.time())
	
	# FIXED: Added '/main/' branch path and removed trailing slash before '?'
	url = f"https://raw.githubusercontent.com/Gabyface910/munchy-api/main/meals.json?t={timestamp}"
	
	try:
		response = requests.get(url)
		response.raise_for_status() 
		data = response.json()
		
		# Adapt to root structure whether it's a wrapper dict or direct list
		if isinstance(data, dict):
			return data.get('meals', [])
		elif isinstance(data, list):
			return data
		return []
		
	except requests.exceptions.RequestException as e:
		print(f"[X] Error fetching from munchy-api: {e}")
		return []

def filter_meals(meals, fil, query):
	errormsg=f"Category '{fil}' does not exist."
	"""Replicates JavaScript: meals.filter(m => m.strCategory === category_name)"""
	if fil == "meal":
		return [
			meal for meal in meals if str(meal.get('strMeal', '')).strip().lower() == query.strip().lower()
		]
	elif fil == "id":
		return [
			meal for meal in meals if str(meal.get('idMeal', '')).strip().lower() == query.strip().lower()
		]
	elif fil == "category":
		return [
			meal for meal in meals if str(meal.get('strCategory', '')).strip().lower() == query.strip().lower()
		]
	elif fil == "area":
		return [
			meal for meal in meals if str(meal.get('strArea', '')).strip().lower() == query.strip().lower()
		]
	elif fil == "country":
		return [
			meal for meal in meals if str(meal.get('strCountry', '')).strip().lower() == query.strip().lower()
		]
	else:
		raise MealError(errormsg)
