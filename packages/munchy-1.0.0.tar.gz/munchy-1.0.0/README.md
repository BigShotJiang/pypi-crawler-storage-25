This is the official Python library for the Munchy API.
For the Munchy repository, see [Gabyface910/Munchy](https://github.com/Gabyface910/munchy)
For the Munchy website, see [Munchy](https://gabyface910.github.io/munchy)
For the Munchy API repository, see [Gabyface910/munchy-api](https://github.com/Gabyface910/munchy-api)

## Munchy is finally in Python!

Gabyface910 is proud to present a new use for the Munchy API: Coding in Python!
Let `munchy` do all the hard filtering work for you and kick back and plan your snack.
Using `munchy` is simple! Here's some syntax:
```python3
import munchy
food = munchy.fetch()
print(munchy.filter_meals(food, "category", "chicken"))
```
That's all it takes!
These meals will require further JSON processing. Here's an example of what one looks like.
```json
  {
    "idMeal": "67681",
    "strMeal": "Homemade Vanilla Ice Cream",
    "strMealAlternate": null,
    "strCategory": "Dessert",
    "strArea": "United States",
    "strCountry": "United States",
    "strInstructions": "PREPARE:\r\nAt least 12 hours before making your ice cream, freeze your ice cream maker's bowl.\r\n\r\nCombine the cream, milk, sugar, vanilla, and salt in a medium saucepan over medium-low heat. Warm for 5 minutes, whisking often, until the sugar is fully dissolved and the mixture is warmed through.\r\n\r\nThen, chill the ice cream base. Transfer it to a heatproof bowl, cover, and chill for 2 hours or overnight.\r\n\r\nWhen you’re ready to make ice cream, churn the ice cream mixture for 20-30 minutes in your ice cream maker according the manufacturer’s instructions.\r\n\r\nYou can eat it right away for soft-serve, but freeze it for harder ice cream.",
    "strMealThumb": "https://cdn.loveandlemons.com/wp-content/uploads/2023/06/homemade-vanilla-ice-cream.jpg",
    "strTags": null,
    "strYoutube": "#",
    "strIngredient1": "heavy cream",
    "strIngredient2": "whole milk",
    "strIngredient3": "sugar",
    "strIngredient4": "vanilla extract",
    "strIngredient5": "salt",
    "strIngredient6": "",
    "strIngredient7": "",
    "strIngredient8": "",
    "strIngredient9": "",
    "strIngredient10": "",
    "strIngredient11": "",
    "strIngredient12": "",
    "strIngredient13": "",
    "strIngredient14": "",
    "strIngredient15": "",
    "strIngredient16": "",
    "strIngredient17": "",
    "strIngredient18": "",
    "strIngredient19": "",
    "strIngredient20": "",
    "strMeasure1": "2 ¼ cups",
    "strMeasure2": "2⁄3 cup",
    "strMeasure3": "1 tsp",
    "strMeasure4": "1 tsp",
    "strMeasure5": "",
    "strMeasure6": "",
    "strMeasure7": "",
    "strMeasure8": "",
    "strMeasure9": "",
    "strMeasure10": "",
    "strMeasure11": "",
    "strMeasure12": "",
    "strMeasure13": "",
    "strMeasure14": "",
    "strMeasure15": "",
    "strMeasure16": "",
    "strMeasure17": "",
    "strMeasure18": "",
    "strMeasure19": "",
    "strMeasure20": "",
    "strSource": null,
    "strImageSource": null,
    "strCreativeCommonsConfirmed": null,
    "dateModified": null
  }
`
If you want to integrate these further, use this as a reference sheet for the API structure.

The current filters available are:

id
meal
category
area
country

Have fun!



