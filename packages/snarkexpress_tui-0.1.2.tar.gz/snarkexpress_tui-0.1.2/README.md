# Snark Express TUI

Terminal UI for [Snark Express](https://news.snark.express) — browse cryptography papers from the command line.

Black & orange themed, vim-style navigation, post-quantum authentication.

## Install

```bash
pip install snarkexpress-tui
snarkexpress
```

Or run directly without installing:

```bash
uvx --from snarkexpress-tui snarkexpress
```

Node.js 18+ is optional, only needed for post-quantum crypto (login/register):

```bash
npm install -g @noble/post-quantum
```

## From Source

```bash
git clone https://github.com/kurtpan666/SnarkExpress-TUI.git
cd SnarkExpress-TUI
./start.sh
```

`start.sh` checks the environment, installs all dependencies, and launches the TUI.

## Configuration

The TUI connects to `https://snarkexpress.up.railway.app/api` by default. Override with:

```bash
SNARKEXPRESS_API_URL=https://your-api.example.com/api snarkexpress
```

## Keyboard Shortcuts

### Global

| Key     | Action        |
|---------|---------------|
| `q`     | Quit          |
| `h` / `l` | Prev / Next tab |
| `←` / `→` | Prev / Next tab |
| `Escape` / `Backspace` | Go back |

### Paper List (Home)

| Key     | Action              |
|---------|---------------------|
| `j` / `k` | Move down / up   |
| `g` / `G` | Jump to top / bottom |
| `Enter` | Open paper detail   |
| `o`     | Open paper URL in browser |
| `u` / `d` | Upvote / Downvote |
| `r`     | Refresh             |

### Search

| Key     | Action           |
|---------|------------------|
| `n` / `p` | Next / Prev page |
| `Enter` | Submit search    |

### Paper Detail

| Key     | Action           |
|---------|------------------|
| `u`     | Upvote           |
| `o`     | Open URL in browser |
| `r`     | Refresh          |

## Features

- **Browse papers** with Hot / New / Top sorting and infinite scroll
- **Search** with quick and advanced filters (title, author, tag, sort by relevance/date/votes)
- **Paper details** with abstract, BibTeX, voting, comments, related papers
- **Submit papers** with URL auto-extraction (ePrint, arXiv, CiC, DOI)
- **Comments** — nested threads with reply/delete
- **Vote** on papers (upvote / downvote with toggle)
- **User profiles** with submissions, comments, votes, and badges
- **Tags** — clickable tag cloud sorted by popularity, wrapping to fill terminal width
- **PQ Auth** — ML-DSA + ML-KEM challenge-response login
- **Key management** — import/export encrypted key bundles with PIN encryption

## Architecture

Standalone API client for the [Snark Express](https://news.snark.express) backend. All communication happens via REST API. Post-quantum cryptography (ML-DSA-65 + ML-KEM-768) is handled by a bundled Node.js helper (`crypto_helper.mjs`) using `@noble/post-quantum`.
