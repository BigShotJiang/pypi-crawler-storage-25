"""Main Snark Express TUI application."""

from __future__ import annotations

from textual.app import App, ComposeResult

from .api import ApiClient
from .auth import AuthState
from .screens.home import HomeScreen
from .screens.login import LoginScreen
from .screens.profile import ProfileScreen
from .screens.search import SearchScreen
from .screens.submit import SubmitScreen
from .screens.tags import TagsScreen
from .widgets.header import AppHeader, Navigate, TAB_ITEMS


class SnarkExpressApp(App):
    TITLE = "Snark Express"

    CSS = """
    Screen {
        background: #111111;
    }
    * {
        scrollbar-background: #111111;
        scrollbar-color: #333333;
        scrollbar-color-hover: #ff6600;
        scrollbar-color-active: #ff8800;
        scrollbar-corner-color: #111111;
        scrollbar-size-vertical: 1;
    }
    Input {
        border: tall #333333;
        background: #1a1a1a;
    }
    Input:focus {
        border: tall #ff6600;
    }
    Button {
        background: #222222;
        color: #cccccc;
        border: tall #333333;
    }
    Button:hover {
        background: #333333;
        color: #ffffff;
    }
    Button.-primary {
        background: #ff6600;
        color: #111111;
        text-style: bold;
        border: tall #ff8800;
    }
    Button.-primary:hover {
        background: #ff8800;
    }
    Select {
        border: tall #333333;
        background: #1a1a1a;
    }
    Select:focus {
        border: tall #ff6600;
    }
    SelectOverlay {
        background: #1a1a1a;
        border: tall #ff6600;
    }
    SelectOverlay > .option-list--option-highlighted {
        background: #ff6600;
        color: #111111;
    }
    Footer {
        background: #1a1a1a;
    }
    Footer > .footer--key {
        background: #ff6600;
        color: #111111;
    }
    * {
        link-color: #ff6600;
        link-background: #111111;
        link-style: none;
    }
    """

    BINDINGS = [
        ("q", "quit", "Quit"),
        ("h", "prev_tab", "◀"),
        ("l", "next_tab", "▶"),
        ("left", "prev_tab"),
        ("right", "next_tab"),
    ]

    def __init__(self, **kwargs) -> None:
        super().__init__(**kwargs)
        self.api_client = ApiClient()
        self.auth_state = AuthState()
        self._current_tab_index = -1

    async def on_mount(self) -> None:
        if self.auth_state.is_logged_in:
            self.api_client.set_token(self.auth_state.token)
        self.push_screen(HomeScreen(sort="new"))

    def update_header_username(self) -> None:
        try:
            header = self.screen.query_one(AppHeader)
            header.username = self.auth_state.username or ""
        except Exception:
            pass

    def _set_header_active_tab(self, target: str) -> None:
        try:
            header = self.screen.query_one(AppHeader)
            header.active_tab = target
        except Exception:
            pass

    def _tab_cycle(self) -> list[tuple[str, dict]]:
        """Full tab cycle: home, [submit], search, tags."""
        cycle: list[tuple[str, dict]] = [("home", {"sort": "new"})]
        if self.auth_state.is_logged_in:
            cycle.append(("submit", {}))
        cycle.append(("search", {}))
        cycle.append(("tags", {}))
        return cycle

    def action_next_tab(self) -> None:
        cycle = self._tab_cycle()
        self._current_tab_index = (self._current_tab_index + 1) % len(cycle)
        target, kwargs = cycle[self._current_tab_index]
        self.post_message(Navigate(target, **kwargs))

    def action_prev_tab(self) -> None:
        cycle = self._tab_cycle()
        self._current_tab_index = (self._current_tab_index - 1) % len(cycle)
        target, kwargs = cycle[self._current_tab_index]
        self.post_message(Navigate(target, **kwargs))

    def _sync_tab_index(self, target: str) -> None:
        cycle = self._tab_cycle()
        for i, (t, _) in enumerate(cycle):
            if t == target:
                self._current_tab_index = i
                return

    async def on_navigate(self, event: Navigate) -> None:
        target = event.target
        if target == "home":
            sort = event.kwargs.get("sort", "hot")
            self._sync_tab_index("home")
            self.switch_screen(HomeScreen(sort=sort))
        elif target == "search":
            self._sync_tab_index("search")
            self.switch_screen(SearchScreen())
        elif target == "submit":
            self._sync_tab_index("submit")
            self.switch_screen(SubmitScreen())
        elif target == "tags":
            self._sync_tab_index("tags")
            self.switch_screen(TagsScreen())
        elif target == "login":
            self.push_screen(LoginScreen())
        elif target == "logout":
            self.auth_state.logout()
            self.api_client.set_token(None)
            self.update_header_username()
            self.notify("Logged out.")
        elif target == "profile":
            username = event.kwargs.get("username", "")
            if username:
                self.push_screen(ProfileScreen(username))

    async def action_quit(self) -> None:
        await self.api_client.close()
        self.exit()
