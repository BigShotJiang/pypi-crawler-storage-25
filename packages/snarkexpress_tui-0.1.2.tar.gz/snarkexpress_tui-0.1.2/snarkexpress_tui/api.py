"""HTTP client for the Snark Express backend API."""

from __future__ import annotations

from typing import Any

import httpx

from .config import API_BASE_URL


class ApiClient:
    """Async HTTP client wrapping the backend REST API."""

    def __init__(self) -> None:
        self._token: str | None = None
        self._client = httpx.AsyncClient(base_url=API_BASE_URL, timeout=30.0)

    def set_token(self, token: str | None) -> None:
        self._token = token

    @property
    def headers(self) -> dict[str, str]:
        h: dict[str, str] = {}
        if self._token:
            h["Authorization"] = f"Bearer {self._token}"
        return h

    # ── Auth ──────────────────────────────────────────────────────────

    async def get_challenge(self, mldsa_public_key: str) -> dict[str, Any]:
        r = await self._client.post(
            "/auth/challenge",
            json={"mldsaPublicKey": mldsa_public_key},
            headers=self.headers,
        )
        r.raise_for_status()
        return r.json()

    async def register(
        self,
        username: str,
        mldsa_public_key: str,
        mlkem_public_key: str,
        invitation_code: str,
    ) -> dict[str, Any]:
        r = await self._client.post(
            "/auth/register",
            json={
                "username": username,
                "mldsaPublicKey": mldsa_public_key,
                "mlkemPublicKey": mlkem_public_key,
                "invitationCode": invitation_code,
            },
            headers=self.headers,
        )
        r.raise_for_status()
        return r.json()

    async def login(
        self,
        mldsa_public_key: str,
        signature: str,
        kem_mac: str,
        challenge_id: str,
    ) -> dict[str, Any]:
        r = await self._client.post(
            "/auth/login",
            json={
                "mldsaPublicKey": mldsa_public_key,
                "signature": signature,
                "kemMac": kem_mac,
                "challengeId": challenge_id,
            },
            headers=self.headers,
        )
        r.raise_for_status()
        return r.json()

    # ── Papers ────────────────────────────────────────────────────────

    async def get_papers(
        self,
        sort: str = "hot",
        tag: str | None = None,
        limit: int = 30,
        offset: int = 0,
    ) -> dict[str, Any]:
        params: dict[str, Any] = {"sort": sort, "limit": limit, "offset": offset}
        if tag:
            params["tag"] = tag
        r = await self._client.get("/papers", params=params, headers=self.headers)
        r.raise_for_status()
        return r.json()

    async def get_paper(self, paper_id: int) -> dict[str, Any]:
        r = await self._client.get(f"/papers/{paper_id}", headers=self.headers)
        r.raise_for_status()
        return r.json()

    async def submit_paper(
        self,
        url: str,
        tags: list[str],
        title: str | None = None,
        authors: str | None = None,
        conference: str | None = None,
    ) -> dict[str, Any]:
        body: dict[str, Any] = {"url": url, "tags": tags}
        if title:
            body["title"] = title
        if authors:
            body["authors"] = authors
        if conference:
            body["conference"] = conference
        r = await self._client.post("/papers", json=body, headers=self.headers)
        r.raise_for_status()
        return r.json()

    async def edit_paper(self, paper_id: int, data: dict[str, Any]) -> dict[str, Any]:
        r = await self._client.put(
            f"/papers/{paper_id}", json=data, headers=self.headers
        )
        r.raise_for_status()
        return r.json()

    async def delete_paper(self, paper_id: int) -> None:
        r = await self._client.delete(f"/papers/{paper_id}", headers=self.headers)
        r.raise_for_status()

    async def vote(self, paper_id: int, vote: int) -> dict[str, Any]:
        r = await self._client.post(
            f"/papers/{paper_id}/vote",
            json={"vote": vote},
            headers=self.headers,
        )
        r.raise_for_status()
        return r.json()

    async def extract_metadata(self, url: str) -> dict[str, Any]:
        r = await self._client.get(
            "/papers/extract-metadata",
            params={"url": url},
            headers=self.headers,
        )
        r.raise_for_status()
        return r.json()

    async def get_tags(self) -> list[dict[str, Any]]:
        r = await self._client.get("/papers/tags", headers=self.headers)
        r.raise_for_status()
        return r.json()

    async def get_conferences(self) -> list[str]:
        r = await self._client.get("/papers/conferences", headers=self.headers)
        r.raise_for_status()
        return r.json()

    # ── Search ────────────────────────────────────────────────────────

    async def search(
        self,
        q: str | None = None,
        title: str | None = None,
        author: str | None = None,
        abstract: str | None = None,
        tag: str | None = None,
        sort: str = "relevance",
        limit: int = 30,
        offset: int = 0,
    ) -> dict[str, Any]:
        params: dict[str, Any] = {"sort": sort, "limit": limit, "offset": offset}
        if q:
            params["q"] = q
        if title:
            params["title"] = title
        if author:
            params["author"] = author
        if abstract:
            params["abstract"] = abstract
        if tag:
            params["tag"] = tag
        r = await self._client.get("/search", params=params, headers=self.headers)
        r.raise_for_status()
        return r.json()

    # ── Comments ──────────────────────────────────────────────────────

    async def get_comments(self, paper_id: int) -> list[dict[str, Any]]:
        r = await self._client.get(
            f"/comments/papers/{paper_id}/comments", headers=self.headers
        )
        r.raise_for_status()
        return r.json()

    async def post_comment(
        self, paper_id: int, content: str, parent_id: int | None = None
    ) -> dict[str, Any]:
        body: dict[str, Any] = {"content": content}
        if parent_id is not None:
            body["parent_id"] = parent_id
        r = await self._client.post(
            f"/comments/papers/{paper_id}/comments",
            json=body,
            headers=self.headers,
        )
        r.raise_for_status()
        return r.json()

    async def delete_comment(self, paper_id: int, comment_id: int) -> None:
        r = await self._client.delete(
            f"/comments/papers/{paper_id}/comments/{comment_id}",
            headers=self.headers,
        )
        r.raise_for_status()

    async def edit_comment(
        self, paper_id: int, comment_id: int, content: str
    ) -> dict[str, Any]:
        r = await self._client.patch(
            f"/comments/papers/{paper_id}/comments/{comment_id}",
            json={"content": content},
            headers=self.headers,
        )
        r.raise_for_status()
        return r.json()

    # ── Users ─────────────────────────────────────────────────────────

    async def get_user(self, username: str) -> dict[str, Any]:
        r = await self._client.get(f"/users/{username}", headers=self.headers)
        r.raise_for_status()
        return r.json()

    async def get_user_submissions(
        self, username: str, limit: int = 30, offset: int = 0
    ) -> list[dict[str, Any]]:
        r = await self._client.get(
            f"/users/{username}/submissions",
            params={"limit": limit, "offset": offset},
            headers=self.headers,
        )
        r.raise_for_status()
        return r.json()

    async def get_user_comments(
        self, username: str, limit: int = 30, offset: int = 0
    ) -> list[dict[str, Any]]:
        r = await self._client.get(
            f"/users/{username}/comments",
            params={"limit": limit, "offset": offset},
            headers=self.headers,
        )
        r.raise_for_status()
        return r.json()

    async def get_user_votes(
        self, username: str, limit: int = 30, offset: int = 0
    ) -> list[dict[str, Any]]:
        r = await self._client.get(
            f"/users/{username}/votes",
            params={"limit": limit, "offset": offset},
            headers=self.headers,
        )
        r.raise_for_status()
        return r.json()

    # ── Recommendations ───────────────────────────────────────────────

    async def get_related(self, paper_id: int) -> list[dict[str, Any]]:
        r = await self._client.get(
            f"/recommendations/related/{paper_id}", headers=self.headers
        )
        r.raise_for_status()
        return r.json()

    # ── Lifecycle ─────────────────────────────────────────────────────

    async def close(self) -> None:
        await self._client.aclose()
