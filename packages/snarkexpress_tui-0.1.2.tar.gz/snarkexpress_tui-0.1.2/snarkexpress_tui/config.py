"""Configuration for the Snark Express TUI."""

from __future__ import annotations

import os
from pathlib import Path

API_BASE_URL = os.environ.get("SNARKEXPRESS_API_URL", "https://snarkexpress.up.railway.app/api")

# Local key storage directory
DATA_DIR = Path.home() / ".snarkexpress"
KEY_FILE = DATA_DIR / "keys.json"
SESSION_FILE = DATA_DIR / "session.json"

# Path to the Node.js crypto helper (bundled inside this package)
CRYPTO_HELPER = Path(__file__).resolve().parent / "crypto_helper.mjs"

def ensure_data_dir() -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
