#!/usr/bin/env node
/**
 * Node.js helper for post-quantum crypto operations.
 * Called by the Python TUI via subprocess.
 *
 * Usage:
 *   node crypto_helper.mjs keygen
 *   node crypto_helper.mjs decapsulate <kemCipherTextB64> <mlkemSecretKeyB64>
 *   node crypto_helper.mjs sign <messageHex> <mldsaSecretKeyB64>
 *   node crypto_helper.mjs encrypt <plaintext> <password>
 *   node crypto_helper.mjs decrypt <encryptedJson> <password>
 */

import { ml_dsa65 } from '@noble/post-quantum/ml-dsa.js';
import { ml_kem768 } from '@noble/post-quantum/ml-kem.js';
import { createHash, createHmac, randomBytes, createCipheriv, createDecipheriv, pbkdf2Sync } from 'node:crypto';

function b64encode(buf) {
  return Buffer.from(buf).toString('base64');
}

function b64decode(str) {
  return new Uint8Array(Buffer.from(str, 'base64'));
}

function hexToBytes(hex) {
  const bytes = new Uint8Array(hex.length / 2);
  for (let i = 0; i < hex.length; i += 2) {
    bytes[i / 2] = parseInt(hex.substring(i, i + 2), 16);
  }
  return bytes;
}

function bytesToHex(bytes) {
  return Array.from(bytes).map(b => b.toString(16).padStart(2, '0')).join('');
}

function deriveKeyFromPassword(password, salt) {
  return pbkdf2Sync(password, salt, 100000, 32, 'sha256');
}

function deriveSessionKey(sharedSecret) {
  return createHash('sha256').update(sharedSecret).digest();
}

async function main() {
  const [,, command, ...args] = process.argv;

  switch (command) {
    case 'keygen': {
      const dsaKeys = ml_dsa65.keygen();
      const kemKeys = ml_kem768.keygen();
      console.log(JSON.stringify({
        mldsaPublicKey: b64encode(dsaKeys.publicKey),
        mldsaSecretKey: b64encode(dsaKeys.secretKey),
        mlkemPublicKey: b64encode(kemKeys.publicKey),
        mlkemSecretKey: b64encode(kemKeys.secretKey),
      }));
      break;
    }

    case 'prove-challenge': {
      // args: challengeJson (contains encryptedChallenge, iv, kemCipherText, mldsaSecretKeyB64, mlkemSecretKeyB64)
      const payload = JSON.parse(args[0]);
      const mlkemSecretKey = b64decode(payload.mlkemSecretKey);
      const mldsaSecretKey = b64decode(payload.mldsaSecretKey);
      const kemCipherText = b64decode(payload.kemCipherText);

      // Decapsulate
      const sharedSecret = ml_kem768.decapsulate(kemCipherText, mlkemSecretKey);
      const sessionKey = deriveSessionKey(sharedSecret);

      // Decrypt challenge
      const encChallenge = b64decode(payload.encryptedChallenge);
      const iv = b64decode(payload.iv);
      const decipher = createDecipheriv('aes-256-gcm', sessionKey, iv);
      const authTagLen = 16;
      const ciphertext = encChallenge.slice(0, encChallenge.length - authTagLen);
      const authTag = encChallenge.slice(encChallenge.length - authTagLen);
      decipher.setAuthTag(authTag);
      const challenge = Buffer.concat([decipher.update(ciphertext), decipher.final()]);

      // Sign challenge
      const signature = ml_dsa65.sign(new Uint8Array(challenge), mldsaSecretKey);

      // KEM MAC
      const kemMac = createHmac('sha256', sessionKey).update(challenge).digest();

      console.log(JSON.stringify({
        challengeHex: bytesToHex(challenge),
        signatureB64: b64encode(signature),
        kemMac: b64encode(kemMac),
      }));
      break;
    }

    case 'encrypt-keys': {
      // Encrypt key bundle for local storage
      // args: keysJson, password
      const keys = JSON.parse(args[0]);
      const password = args[1];

      const salt = randomBytes(16);
      const iv = randomBytes(12);
      const aesKey = deriveKeyFromPassword(password, salt);

      const secretPayload = JSON.stringify({
        mldsaSecretKey: keys.mldsaSecretKey,
        mlkemSecretKey: keys.mlkemSecretKey,
      });

      const cipher = createCipheriv('aes-256-gcm', aesKey, iv);
      const encrypted = Buffer.concat([cipher.update(secretPayload, 'utf8'), cipher.final(), cipher.getAuthTag()]);

      console.log(JSON.stringify({
        encryptedSecrets: b64encode(encrypted),
        mldsaPublicKey: keys.mldsaPublicKey,
        mlkemPublicKey: keys.mlkemPublicKey,
        salt: b64encode(salt),
        iv: b64encode(iv),
        version: 2,
      }));
      break;
    }

    case 'decrypt-keys': {
      // Decrypt stored key bundle
      // args: encryptedJson, password
      const data = JSON.parse(args[0]);
      const password = args[1];

      if (data.version !== 2) {
        console.log(JSON.stringify({ error: 'Incompatible key version' }));
        process.exit(1);
      }

      const salt = b64decode(data.salt);
      const iv = b64decode(data.iv);
      const encrypted = b64decode(data.encryptedSecrets);
      const aesKey = deriveKeyFromPassword(password, salt);

      try {
        const decipher = createDecipheriv('aes-256-gcm', aesKey, iv);
        const authTagLen = 16;
        const ciphertext = encrypted.slice(0, encrypted.length - authTagLen);
        const authTag = encrypted.slice(encrypted.length - authTagLen);
        decipher.setAuthTag(authTag);
        const decrypted = Buffer.concat([decipher.update(ciphertext), decipher.final()]);
        const parsed = JSON.parse(decrypted.toString('utf8'));

        console.log(JSON.stringify({
          mldsaSecretKey: parsed.mldsaSecretKey,
          mlkemSecretKey: parsed.mlkemSecretKey,
          mldsaPublicKey: data.mldsaPublicKey,
          mlkemPublicKey: data.mlkemPublicKey,
        }));
      } catch (e) {
        console.log(JSON.stringify({ error: 'Incorrect PIN or corrupted data' }));
        process.exit(1);
      }
      break;
    }

    default:
      console.error(`Unknown command: ${command}`);
      process.exit(1);
  }
}

main().catch(err => {
  console.error(err.message);
  process.exit(1);
});
