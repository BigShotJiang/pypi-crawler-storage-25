"""Post-quantum crypto operations via Node.js subprocess."""

from __future__ import annotations

import json
import os
import subprocess
from pathlib import Path
from typing import Any

from .config import CRYPTO_HELPER


def _run_crypto(command: str, *args: str) -> dict[str, Any]:
    """Run the Node.js crypto helper and return parsed JSON output."""
    cmd = ["node", str(CRYPTO_HELPER), command, *args]
    env = {**os.environ}
    # Help Node.js find @noble/post-quantum from multiple possible locations:
    # 1. node_modules next to crypto_helper.mjs (pip install + npm install in package dir)
    # 2. node_modules in the current working directory (dev / start.sh scenario)
    node_paths = [
        str(CRYPTO_HELPER.parent / "node_modules"),
        str(Path.cwd() / "node_modules"),
    ]
    existing = env.get("NODE_PATH", "")
    if existing:
        node_paths.append(existing)
    env["NODE_PATH"] = os.pathsep.join(node_paths)
    result = subprocess.run(cmd, capture_output=True, text=True, timeout=60, env=env)
    if result.returncode != 0:
        stderr = result.stderr.strip()
        stdout = result.stdout.strip()
        # Some errors are returned as JSON on stdout
        if stdout:
            try:
                data = json.loads(stdout)
                if "error" in data:
                    raise RuntimeError(data["error"])
            except json.JSONDecodeError:
                pass
        raise RuntimeError(stderr or f"crypto_helper exited with code {result.returncode}")
    return json.loads(result.stdout)


def generate_keys() -> dict[str, str]:
    """Generate ML-DSA + ML-KEM key pairs.

    Returns dict with mldsaPublicKey, mldsaSecretKey, mlkemPublicKey, mlkemSecretKey (all base64).
    """
    return _run_crypto("keygen")


def prove_challenge(
    encrypted_challenge: str,
    iv: str,
    kem_cipher_text: str,
    mldsa_secret_key: str,
    mlkem_secret_key: str,
) -> dict[str, str]:
    """Decrypt challenge, sign it, and produce KEM MAC.

    Returns dict with challengeHex, signatureB64, kemMac.
    """
    payload = json.dumps({
        "encryptedChallenge": encrypted_challenge,
        "iv": iv,
        "kemCipherText": kem_cipher_text,
        "mldsaSecretKey": mldsa_secret_key,
        "mlkemSecretKey": mlkem_secret_key,
    })
    return _run_crypto("prove-challenge", payload)


def encrypt_keys(keys: dict[str, str], password: str) -> dict[str, Any]:
    """Encrypt a key bundle with a PIN/password for local storage."""
    return _run_crypto("encrypt-keys", json.dumps(keys), password)


def decrypt_keys(encrypted_data: dict[str, Any], password: str) -> dict[str, str]:
    """Decrypt a stored key bundle. Returns the four keys as base64 strings."""
    return _run_crypto("decrypt-keys", json.dumps(encrypted_data), password)
