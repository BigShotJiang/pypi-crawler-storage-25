"""Register screen - create a new account with PQ keys."""

from __future__ import annotations

from textual.app import ComposeResult
from textual.containers import Horizontal, Vertical, VerticalScroll
from textual.screen import Screen
from textual.widgets import Button, Footer, Input, Label, Static

from .. import crypto
from ..widgets.header import AppHeader


class RegisterScreen(Screen):
    BINDINGS = [
        ("escape", "app.pop_screen", "Back"),
        ("backspace", "app.pop_screen"),
    ]

    DEFAULT_CSS = """
    RegisterScreen {
        layout: vertical;
        align: center middle;
    }
    RegisterScreen .reg-header {
        dock: top;
        height: 1;
        padding: 0 2;
        background: $surface;
        color: $warning;
        text-style: bold;
    }
    RegisterScreen .reg-box {
        width: 70;
        height: auto;
        padding: 2 4;
        border: solid $primary;
        margin: 2;
    }
    RegisterScreen .reg-title {
        text-style: bold;
        text-align: center;
        color: $accent;
        margin-bottom: 2;
    }
    RegisterScreen .form-row {
        height: auto;
        margin-bottom: 1;
        layout: horizontal;
    }
    RegisterScreen .form-label {
        width: 20;
        padding-top: 1;
    }
    RegisterScreen .form-input {
        width: 1fr;
    }
    RegisterScreen .btn-row {
        height: 3;
        layout: horizontal;
        align: center middle;
        margin-top: 1;
    }
    RegisterScreen .reg-btn {
        margin-right: 2;
    }
    RegisterScreen .status-area {
        height: auto;
        margin-top: 1;
    }
    RegisterScreen .status-msg {
        text-align: center;
        padding: 1;
        color: $text-muted;
    }
    RegisterScreen .error-msg {
        color: $error;
        text-align: center;
        padding: 1;
    }
    RegisterScreen .success-msg {
        color: $success;
        text-align: center;
        padding: 1;
    }
    RegisterScreen .hint {
        color: $text-muted;
        text-style: italic;
        text-align: center;
        margin-bottom: 1;
    }
    """

    def compose(self) -> ComposeResult:
        yield AppHeader()
        yield VerticalScroll(
            Vertical(
                Label("Create New Account", classes="reg-title"),
                Label(
                    "Post-quantum keys (ML-DSA + ML-KEM) will be generated locally.",
                    classes="hint",
                ),
                Horizontal(
                    Label("Username:", classes="form-label"),
                    Input(placeholder="Choose a username", id="reg-username", classes="form-input"),
                    classes="form-row",
                ),
                Horizontal(
                    Label("Invitation Code:", classes="form-label"),
                    Input(placeholder="Required for registration", id="reg-invite", classes="form-input"),
                    classes="form-row",
                ),
                Horizontal(
                    Label("4-digit PIN:", classes="form-label"),
                    Input(placeholder="PIN to encrypt your keys", id="reg-pin", password=True, classes="form-input"),
                    classes="form-row",
                ),
                Horizontal(
                    Label("Confirm PIN:", classes="form-label"),
                    Input(placeholder="Confirm your PIN", id="reg-pin2", password=True, classes="form-input"),
                    classes="form-row",
                ),
                Horizontal(
                    Button("Register", id="do-register", variant="primary", classes="reg-btn"),
                    Button("Cancel", id="go-back", classes="reg-btn"),
                    classes="btn-row",
                ),
                Vertical(id="reg-status", classes="status-area"),
                classes="reg-box",
            ),
        )
        yield Footer()

    async def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "do-register":
            await self._do_register()
        elif event.button.id == "go-back":
            self.app.pop_screen()

    async def _do_register(self) -> None:
        status = self.query_one("#reg-status", Vertical)
        await status.remove_children()

        username = self.query_one("#reg-username", Input).value.strip()
        invite = self.query_one("#reg-invite", Input).value.strip()
        pin = self.query_one("#reg-pin", Input).value.strip()
        pin2 = self.query_one("#reg-pin2", Input).value.strip()

        if not username:
            await status.mount(Label("Username is required.", classes="error-msg"))
            return
        if not invite:
            await status.mount(Label("Invitation code is required.", classes="error-msg"))
            return
        if len(pin) < 4:
            await status.mount(Label("PIN must be at least 4 digits.", classes="error-msg"))
            return
        if pin != pin2:
            await status.mount(Label("PINs do not match.", classes="error-msg"))
            return

        await status.mount(Label("Generating post-quantum keys (this may take a moment)...", classes="status-msg"))

        try:
            keys = crypto.generate_keys()
        except Exception as e:
            await status.remove_children()
            await status.mount(Label(f"Key generation failed: {e}", classes="error-msg"))
            return

        await status.remove_children()
        await status.mount(Label("Registering with server...", classes="status-msg"))

        auth = self.app.auth_state  # type: ignore[attr-defined]
        api = self.app.api_client  # type: ignore[attr-defined]

        try:
            result = await api.register(
                username=username,
                mldsa_public_key=keys["mldsaPublicKey"],
                mlkem_public_key=keys["mlkemPublicKey"],
                invitation_code=invite,
            )
        except Exception as e:
            await status.remove_children()
            await status.mount(Label(f"Registration failed: {e}", classes="error-msg"))
            return

        await status.remove_children()
        await status.mount(Label("Encrypting and storing keys...", classes="status-msg"))

        try:
            auth.store_encrypted_keys(keys, pin)
        except Exception as e:
            await status.remove_children()
            await status.mount(Label(f"Key storage failed: {e}", classes="error-msg"))
            return

        token = result.get("token", "")
        user = result.get("user", {})
        uname = user.get("username", username)

        auth.set_session(token, uname)
        api.set_token(token)

        await status.remove_children()
        await status.mount(Label(f"Registered and logged in as {uname}!", classes="success-msg"))
        self.notify(f"Welcome, {uname}!")

        self.app.update_header_username()  # type: ignore[attr-defined]
        self.set_timer(1.5, lambda: (self.app.pop_screen(), self.app.pop_screen()))
