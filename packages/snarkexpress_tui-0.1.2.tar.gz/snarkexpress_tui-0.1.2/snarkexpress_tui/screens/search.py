"""Search screen with quick and advanced search."""

from __future__ import annotations

from textual.app import ComposeResult
from textual.containers import Horizontal, Vertical, VerticalScroll
from textual.screen import Screen
from textual.widgets import Button, Footer, Input, Label, Select, Static

from ..widgets.header import AppHeader
from ..widgets.paper_item import PaperClicked, PaperItem, TagClicked, VoteClicked


class SearchScreen(Screen):
    BINDINGS = [
        ("escape", "go_back", "Back"),
        ("backspace", "go_back"),
        ("enter", "focus_search", "Search"),
        ("tab", "toggle_advanced", "Advanced"),
        ("n", "next_page", "Next"),
        ("p", "prev_page", "Prev"),
        ("h", "prev_tab", "◀"),
        ("l", "next_tab", "▶"),
        ("left", "prev_tab"),
        ("right", "next_tab"),
    ]

    DEFAULT_CSS = """
    SearchScreen {
        layout: vertical;
    }
    SearchScreen .search-form {
        height: auto;
        padding: 1 2;
    }
    SearchScreen .form-row {
        height: auto;
        margin-bottom: 1;
        layout: horizontal;
    }
    SearchScreen .form-label {
        width: 12;
        padding-top: 1;
        color: #888888;
    }
    SearchScreen .form-input {
        width: 1fr;
    }
    SearchScreen .search-buttons {
        height: 3;
        layout: horizontal;
        align: center middle;
        margin-top: 1;
    }
    SearchScreen .search-btn {
        margin-right: 2;
    }
    SearchScreen .advanced-section {
        height: auto;
    }
    SearchScreen .hint-label {
        color: #666666;
        text-style: italic;
        padding: 0 2;
        height: 1;
    }
    SearchScreen #results {
        height: 1fr;
    }
    SearchScreen .page-info {
        dock: bottom;
        height: 1;
        padding: 0 2;
        background: #1a1a1a;
        color: #888888;
        text-align: center;
    }
    SearchScreen .loading {
        text-align: center;
        padding: 3;
        color: #888888;
    }
    SearchScreen .error-msg {
        text-align: center;
        padding: 3;
        color: #ff4444;
    }
    """

    def __init__(self, initial_query: str = "", initial_tag: str = "", **kwargs) -> None:
        super().__init__(**kwargs)
        self.initial_query = initial_query
        self.initial_tag = initial_tag
        self.papers: list[dict] = []
        self.page_offset = 0
        self.page_limit = 30
        self.total = 0
        self._advanced_visible = False

    def compose(self) -> ComposeResult:
        yield AppHeader()
        with Vertical(classes="search-form"):
            with Horizontal(classes="form-row"):
                yield Label("Query:", classes="form-label")
                yield Input(
                    placeholder="Search papers...",
                    id="search-q",
                    classes="form-input",
                    value=self.initial_query,
                )
            yield Vertical(
                Horizontal(
                    Label("Title:", classes="form-label"),
                    Input(placeholder="Title filter...", id="search-title", classes="form-input"),
                    classes="form-row",
                ),
                Horizontal(
                    Label("Author:", classes="form-label"),
                    Input(placeholder="Author filter...", id="search-author", classes="form-input"),
                    classes="form-row",
                ),
                Horizontal(
                    Label("Tag:", classes="form-label"),
                    Input(
                        placeholder="Tag filter...",
                        id="search-tag",
                        classes="form-input",
                        value=self.initial_tag,
                    ),
                    classes="form-row",
                ),
                Horizontal(
                    Label("Sort:", classes="form-label"),
                    Select(
                        [
                            ("Relevance", "relevance"),
                            ("Date", "date"),
                            ("Votes", "votes"),
                        ],
                        value="relevance",
                        id="search-sort",
                    ),
                    classes="form-row",
                ),
                id="advanced-section",
                classes="advanced-section",
            )
            with Horizontal(classes="search-buttons"):
                yield Button("Search", id="do-search", variant="primary", classes="search-btn")
                yield Button("Advanced", id="toggle-advanced", classes="search-btn")
                yield Button("Clear", id="do-clear", classes="search-btn")

        yield Label("Enter to search  |  Tab to toggle advanced filters", classes="hint-label")
        yield VerticalScroll(id="results")
        yield Label("", id="page-info", classes="page-info")
        yield Footer()

    async def on_mount(self) -> None:
        self.set_focus(None)
        # Hide advanced section by default
        self.query_one("#advanced-section").display = False
        try:
            self.query_one(AppHeader).active_tab = "search"
        except Exception:
            pass
        if self.initial_query or self.initial_tag:
            self._advanced_visible = bool(self.initial_tag)
            self.query_one("#advanced-section").display = self._advanced_visible
            await self.do_search()

    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "do-search":
            self.run_worker(self.do_search())
        elif event.button.id == "do-clear":
            for field in ("search-q", "search-title", "search-author", "search-tag"):
                self.query_one(f"#{field}", Input).value = ""
        elif event.button.id == "toggle-advanced":
            self._toggle_advanced()

    async def on_input_submitted(self, event: Input.Submitted) -> None:
        await self.do_search()

    def _toggle_advanced(self) -> None:
        self._advanced_visible = not self._advanced_visible
        self.query_one("#advanced-section").display = self._advanced_visible

    async def do_search(self) -> None:
        container = self.query_one("#results", VerticalScroll)
        await container.remove_children()
        container.mount(Label("Searching...", classes="loading"))

        q = self.query_one("#search-q", Input).value.strip()
        title = self.query_one("#search-title", Input).value.strip()
        author = self.query_one("#search-author", Input).value.strip()
        tag = self.query_one("#search-tag", Input).value.strip()
        sort_select = self.query_one("#search-sort", Select)
        sort = str(sort_select.value) if sort_select.value != Select.BLANK else "relevance"

        if not any([q, title, author, tag]):
            await container.remove_children()
            container.mount(Label("Enter a search query.", classes="loading"))
            return

        try:
            api = self.app.api_client  # type: ignore[attr-defined]
            result = await api.search(
                q=q or None,
                title=title or None,
                author=author or None,
                tag=tag or None,
                sort=sort,
                limit=self.page_limit,
                offset=self.page_offset,
            )
            self.papers = result.get("papers", [])
            pagination = result.get("pagination", {})
            self.total = pagination.get("total", len(self.papers))

            await container.remove_children()
            if not self.papers:
                container.mount(Label("No results found.", classes="loading"))
            else:
                for i, paper in enumerate(self.papers):
                    container.mount(PaperItem(paper, rank=self.page_offset + i + 1))

            page = self.page_offset // self.page_limit + 1
            total_pages = max(1, (self.total + self.page_limit - 1) // self.page_limit)
            self.query_one("#page-info", Label).update(
                f"Page {page}/{total_pages} ({self.total} results)"
            )
        except Exception as e:
            await container.remove_children()
            container.mount(Label(f"Error: {e}", classes="error-msg"))

    async def on_paper_clicked(self, event: PaperClicked) -> None:
        from .paper_detail import PaperDetailScreen
        self.app.push_screen(PaperDetailScreen(event.paper_id))

    async def on_vote_clicked(self, event: VoteClicked) -> None:
        try:
            api = self.app.api_client  # type: ignore[attr-defined]
            await api.vote(event.paper_id, event.vote)
            await self.do_search()
        except Exception as e:
            self.notify(f"Vote failed: {e}", severity="error")

    async def on_tag_clicked(self, event: TagClicked) -> None:
        self.query_one("#search-tag", Input).value = event.tag
        if not self._advanced_visible:
            self._toggle_advanced()
        await self.do_search()

    async def action_next_page(self) -> None:
        if self.page_offset + self.page_limit < self.total:
            self.page_offset += self.page_limit
            await self.do_search()

    async def action_prev_page(self) -> None:
        if self.page_offset > 0:
            self.page_offset = max(0, self.page_offset - self.page_limit)
            await self.do_search()

    def action_prev_tab(self) -> None:
        if not isinstance(self.focused, (Input, Select)):
            self.app.action_prev_tab()

    def action_next_tab(self) -> None:
        if not isinstance(self.focused, (Input, Select)):
            self.app.action_next_tab()

    def action_toggle_advanced(self) -> None:
        if not isinstance(self.focused, (Input, Select)):
            self._toggle_advanced()

    def action_focus_search(self) -> None:
        if not isinstance(self.focused, (Input, Select)):
            self.query_one("#search-q", Input).focus()

    def action_go_back(self) -> None:
        if isinstance(self.focused, (Input, Select)):
            self.set_focus(None)
        else:
            from ..widgets.header import Navigate
            self.post_message(Navigate("home", sort="new"))
