"""Home screen - infinite-scroll paper list with hot/new/top sorting."""

from __future__ import annotations

import webbrowser

from textual.app import ComposeResult
from textual.containers import VerticalScroll
from textual.screen import Screen
from textual.widgets import Footer, Label, Static

from ..widgets.header import AppHeader
from ..widgets.paper_item import PaperClicked, PaperItem, TagClicked, VoteClicked

BATCH_SIZE = 50


class HomeScreen(Screen):
    BINDINGS = [
        ("r", "refresh", "Refresh"),
        ("j", "cursor_down", "Down"),
        ("k", "cursor_up", "Up"),
        ("down", "cursor_down"),
        ("up", "cursor_up"),
        ("g", "cursor_top", "Top"),
        ("G", "cursor_bottom", "Bottom"),
        ("enter", "open_selected", "Open"),
        ("o", "open_url", "URL"),
        ("escape", "go_back", "Back"),
        ("backspace", "go_back"),
        ("q", "quit", "Quit"),
    ]

    DEFAULT_CSS = """
    HomeScreen {
        layout: vertical;
    }
    HomeScreen #paper-list {
        height: 1fr;
    }
    HomeScreen .paper-sep {
        height: 1;
        background: #222222;
    }
    HomeScreen .status-bar {
        dock: bottom;
        height: 1;
        padding: 0 2;
        background: #1a1a1a;
        color: #888888;
        text-align: center;
    }
    HomeScreen .loading {
        text-align: center;
        padding: 2;
        color: #888888;
    }
    HomeScreen .error-msg {
        text-align: center;
        padding: 2;
        color: #ff4444;
    }
    """

    def __init__(
        self,
        sort: str = "hot",
        tag: str | None = None,
        **kwargs,
    ) -> None:
        super().__init__(**kwargs)
        self.sort = sort
        self.tag = tag
        self.papers: list[dict] = []
        self.current_offset = 0
        self.total = 0
        self.has_more = True
        self.loading_more = False

    def compose(self) -> ComposeResult:
        yield AppHeader()
        yield VerticalScroll(id="paper-list")
        yield Label("", id="status-bar", classes="status-bar")
        yield Footer()

    async def on_mount(self) -> None:
        auth = self.app.auth_state  # type: ignore[attr-defined]
        try:
            header = self.query_one(AppHeader)
            header.active_tab = "home"
            if auth.is_logged_in:
                header.username = auth.username or ""
        except Exception:
            pass
        await self._load_initial()

    async def _load_initial(self) -> None:
        """Load first batch, replacing all content."""
        container = self.query_one("#paper-list", VerticalScroll)
        await container.remove_children()
        await container.mount(Label("Loading...", classes="loading"))

        self.papers = []
        self.current_offset = 0
        self.has_more = True

        try:
            api = self.app.api_client  # type: ignore[attr-defined]
            result = await api.get_papers(
                sort=self.sort,
                tag=self.tag,
                limit=BATCH_SIZE,
                offset=0,
            )
            new_papers = result.get("papers", [])
            pagination = result.get("pagination", {})
            self.total = pagination.get("total", 0)
            # Re-sort by created_at descending to fix backend ordering issues
            if self.sort == "new":
                new_papers.sort(key=lambda p: p.get("created_at", ""), reverse=True)
            self.papers = new_papers
            self.current_offset = BATCH_SIZE
            self.has_more = len(new_papers) < self.total

            await container.remove_children()

            if not new_papers:
                await container.mount(Label("No papers found.", classes="loading"))
            else:
                for i, paper in enumerate(new_papers):
                    if i > 0:
                        await container.mount(Static("", classes="paper-sep"))
                    await container.mount(PaperItem(paper, rank=i + 1))
                items = self.query(PaperItem)
                if items:
                    items.first().focus()

            self._update_status()
        except Exception as e:
            await container.remove_children()
            await container.mount(Label(f"Error: {e}", classes="error-msg"))

    async def _load_more(self) -> None:
        """Append next batch of papers."""
        if self.loading_more or not self.has_more:
            return
        self.loading_more = True
        self._update_status("Loading more...")

        try:
            api = self.app.api_client  # type: ignore[attr-defined]
            result = await api.get_papers(
                sort=self.sort,
                tag=self.tag,
                limit=BATCH_SIZE,
                offset=self.current_offset,
            )
            new_papers = result.get("papers", [])
            pagination = result.get("pagination", {})
            self.total = pagination.get("total", 0)
            if self.sort == "new":
                new_papers.sort(key=lambda p: p.get("created_at", ""), reverse=True)
            self.papers.extend(new_papers)
            self.current_offset += BATCH_SIZE
            self.has_more = self.current_offset < self.total

            container = self.query_one("#paper-list", VerticalScroll)
            for paper in new_papers:
                await container.mount(Static("", classes="paper-sep"))
                rank = len(list(self.query(PaperItem))) + 1
                await container.mount(PaperItem(paper, rank=rank))

            self._update_status()
        except Exception as e:
            self.notify(f"Load failed: {e}", severity="error")
        finally:
            self.loading_more = False

    def _update_status(self, msg: str | None = None) -> None:
        tag_text = f" [tag: {self.tag}]" if self.tag else ""
        loaded = len(self.papers)
        if msg:
            text = msg
        elif self.has_more:
            text = f" {self.sort.upper()}{tag_text}  |  {loaded}/{self.total} papers loaded"
        else:
            text = f" {self.sort.upper()}{tag_text}  |  All {self.total} papers loaded"
        try:
            self.query_one("#status-bar", Label).update(text)
        except Exception:
            pass

    def _focus_adjacent(self, direction: int) -> None:
        items = list(self.query(PaperItem))
        if not items:
            return
        focused = self.focused
        if focused in items:
            idx = items.index(focused)
            new_idx = idx + direction
            if 0 <= new_idx < len(items):
                items[new_idx].focus()
                items[new_idx].scroll_visible()
                # Trigger load more when near the end
                if direction > 0 and new_idx >= len(items) - 5:
                    self.call_later(self._load_more)
        else:
            items[0].focus()

    def action_cursor_down(self) -> None:
        self._focus_adjacent(1)

    def action_cursor_up(self) -> None:
        self._focus_adjacent(-1)

    def action_cursor_top(self) -> None:
        items = list(self.query(PaperItem))
        if items:
            items[0].focus()
            items[0].scroll_visible()

    def action_cursor_bottom(self) -> None:
        items = list(self.query(PaperItem))
        if items:
            items[-1].focus()
            items[-1].scroll_visible()
            if self.has_more:
                self.call_later(self._load_more)

    def action_open_selected(self) -> None:
        focused = self.focused
        if isinstance(focused, PaperItem):
            self._open_paper(focused.paper["id"])

    def action_open_url(self) -> None:
        focused = self.focused
        if isinstance(focused, PaperItem):
            url = focused.paper.get("url", "")
            if url:
                webbrowser.open(url)
            else:
                self.notify("No URL for this paper.", severity="warning")

    def _open_paper(self, paper_id: int) -> None:
        from .paper_detail import PaperDetailScreen
        self.app.push_screen(PaperDetailScreen(paper_id))

    async def on_paper_clicked(self, event: PaperClicked) -> None:
        self._open_paper(event.paper_id)

    async def on_vote_clicked(self, event: VoteClicked) -> None:
        try:
            api = self.app.api_client  # type: ignore[attr-defined]
            result = await api.vote(event.paper_id, event.vote)
            # Update in-memory data and the widget
            for item in self.query(PaperItem):
                if item.paper["id"] == event.paper_id:
                    item.paper["vote_count"] = result.get("vote_count", item.paper["vote_count"])
                    item.paper["user_vote"] = result.get("user_vote", 0)
                    # Re-render the single item
                    await item.remove_children()
                    await item.mount_all(list(item.compose()))
                    break
        except Exception as e:
            self.notify(f"Vote failed: {e}", severity="error")

    async def on_tag_clicked(self, event: TagClicked) -> None:
        self.app.switch_screen(HomeScreen(sort=self.sort, tag=event.tag))

    def action_go_back(self) -> None:
        # Only pop if this is a pushed sub-screen (e.g. from tags filter)
        if len(self.app.screen_stack) > 2:
            self.app.pop_screen()

    async def action_refresh(self) -> None:
        await self._load_initial()

    async def action_quit(self) -> None:
        await self.app.api_client.close()  # type: ignore[attr-defined]
        self.app.exit()
