"""Submit paper screen."""

from __future__ import annotations

from textual.app import ComposeResult
from textual.containers import Horizontal, Vertical, VerticalScroll
from textual.screen import Screen
from textual.widgets import Button, Footer, Input, Label, Static

from ..widgets.header import AppHeader


class SubmitScreen(Screen):
    BINDINGS = [
        ("escape", "go_home", "Back"),
        ("backspace", "go_home"),
        ("h", "prev_tab", "◀"),
        ("l", "next_tab", "▶"),
        ("left", "prev_tab"),
        ("right", "next_tab"),
    ]

    DEFAULT_CSS = """
    SubmitScreen {
        layout: vertical;
    }
    SubmitScreen .submit-header {
        dock: top;
        height: 1;
        padding: 0 2;
        background: $surface;
        color: $warning;
        text-style: bold;
    }
    SubmitScreen .submit-form {
        padding: 1 2;
        height: auto;
    }
    SubmitScreen .form-row {
        height: auto;
        margin-bottom: 1;
        layout: horizontal;
    }
    SubmitScreen .form-label {
        width: 14;
        padding-top: 1;
    }
    SubmitScreen .form-input {
        width: 1fr;
    }
    SubmitScreen .submit-buttons {
        height: 3;
        layout: horizontal;
        align: center middle;
        margin-top: 1;
    }
    SubmitScreen .submit-btn {
        margin-right: 2;
    }
    SubmitScreen .preview-section {
        padding: 1 2;
        height: auto;
        background: $surface;
        margin: 1 0;
    }
    SubmitScreen .preview-title {
        text-style: bold;
        color: $accent;
    }
    SubmitScreen .preview-field {
        margin-top: 1;
    }
    SubmitScreen .field-label {
        text-style: bold;
        color: $text-muted;
    }
    SubmitScreen .loading {
        text-align: center;
        padding: 3;
        color: $text-muted;
    }
    SubmitScreen .error-msg {
        text-align: center;
        padding: 3;
        color: $error;
    }
    SubmitScreen .success-msg {
        text-align: center;
        padding: 3;
        color: $success;
    }
    SubmitScreen .hint {
        color: $text-muted;
        text-style: italic;
        padding: 0 0 1 0;
    }
    """

    def compose(self) -> ComposeResult:
        yield AppHeader()
        yield VerticalScroll(
            Vertical(
                Label(
                    "Paste a URL from ePrint, arXiv, CiC, or any DOI link. "
                    "Metadata will be auto-extracted.",
                    classes="hint",
                ),
                Horizontal(
                    Label("URL:", classes="form-label"),
                    Input(placeholder="https://eprint.iacr.org/...", id="submit-url", classes="form-input"),
                    classes="form-row",
                ),
                Horizontal(
                    Label("Tags:", classes="form-label"),
                    Input(placeholder="tag1, tag2, tag3", id="submit-tags", classes="form-input"),
                    classes="form-row",
                ),
                Horizontal(
                    Label("Title:", classes="form-label"),
                    Input(placeholder="(auto-extracted or manual)", id="submit-title", classes="form-input"),
                    classes="form-row",
                ),
                Horizontal(
                    Label("Authors:", classes="form-label"),
                    Input(placeholder="(auto-extracted or manual)", id="submit-authors", classes="form-input"),
                    classes="form-row",
                ),
                Horizontal(
                    Label("Conference:", classes="form-label"),
                    Input(placeholder="(optional)", id="submit-conference", classes="form-input"),
                    classes="form-row",
                ),
                Horizontal(
                    Button("Extract Metadata", id="extract-btn", variant="default", classes="submit-btn"),
                    Button("Submit", id="submit-btn", variant="primary", classes="submit-btn"),
                    classes="submit-buttons",
                ),
                Vertical(id="preview-area"),
                classes="submit-form",
            ),
        )
        yield Footer()

    async def on_mount(self) -> None:
        try:
            self.query_one(AppHeader).active_tab = "submit"
        except Exception:
            pass
        auth = self.app.auth_state  # type: ignore[attr-defined]
        if not auth.is_logged_in:
            self.notify("You must be logged in to submit papers.", severity="warning")

    def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "extract-btn":
            self.run_worker(self._extract_metadata())
        elif event.button.id == "submit-btn":
            self.run_worker(self._submit_paper())

    async def _extract_metadata(self) -> None:
        url = self.query_one("#submit-url", Input).value.strip()
        if not url:
            self.notify("Please enter a URL first.", severity="warning")
            return

        preview = self.query_one("#preview-area", Vertical)
        await preview.remove_children()
        await preview.mount(Label("Extracting metadata...", classes="loading"))

        try:
            api = self.app.api_client  # type: ignore[attr-defined]
            meta = await api.extract_metadata(url)

            await preview.remove_children()

            title = meta.get("title", "")
            authors = meta.get("authors", "")
            conference = meta.get("conference", "")
            keywords = meta.get("keywords", [])

            if title:
                self.query_one("#submit-title", Input).value = title
            if authors:
                self.query_one("#submit-authors", Input).value = authors
            if conference:
                self.query_one("#submit-conference", Input).value = conference
            if keywords and not self.query_one("#submit-tags", Input).value.strip():
                self.query_one("#submit-tags", Input).value = ", ".join(keywords[:5])

            info_parts = []
            if title:
                info_parts.append(f"Title: {title}")
            if authors:
                info_parts.append(f"Authors: {authors}")
            if conference:
                info_parts.append(f"Conference: {conference}")
            if keywords:
                info_parts.append(f"Keywords: {', '.join(keywords)}")

            if info_parts:
                await preview.mount(Label("Extracted metadata:", classes="field-label"))
                for part in info_parts:
                    await preview.mount(Label(f"  {part}", classes="preview-field"))
            else:
                await preview.mount(Label("No metadata could be extracted.", classes="loading"))

        except Exception as e:
            await preview.remove_children()
            await preview.mount(Label(f"Extraction failed: {e}", classes="error-msg"))

    async def _submit_paper(self) -> None:
        auth = self.app.auth_state  # type: ignore[attr-defined]
        if not auth.is_logged_in:
            self.notify("Please login first.", severity="error")
            return

        url = self.query_one("#submit-url", Input).value.strip()
        tags_str = self.query_one("#submit-tags", Input).value.strip()
        title = self.query_one("#submit-title", Input).value.strip()
        authors = self.query_one("#submit-authors", Input).value.strip()
        conference = self.query_one("#submit-conference", Input).value.strip()

        if not url:
            self.notify("URL is required.", severity="warning")
            return

        tags = [t.strip() for t in tags_str.split(",") if t.strip()] if tags_str else []

        preview = self.query_one("#preview-area", Vertical)
        await preview.remove_children()
        await preview.mount(Label("Submitting...", classes="loading"))

        try:
            api = self.app.api_client  # type: ignore[attr-defined]
            result = await api.submit_paper(
                url=url,
                tags=tags,
                title=title or None,
                authors=authors or None,
                conference=conference or None,
            )
            await preview.remove_children()
            paper_id = result.get("id", "?")
            await preview.mount(
                Label(f"Paper submitted successfully! (ID: {paper_id})", classes="success-msg")
            )
            self.notify("Paper submitted!")
        except Exception as e:
            await preview.remove_children()
            err_msg = str(e)
            if "409" in err_msg or "duplicate" in err_msg.lower():
                await preview.mount(Label("This paper has already been submitted.", classes="error-msg"))
            elif "422" in err_msg:
                await preview.mount(
                    Label(
                        "Could not extract metadata. Please fill in title and authors manually.",
                        classes="error-msg",
                    )
                )
            else:
                await preview.mount(Label(f"Submit failed: {e}", classes="error-msg"))

    def action_prev_tab(self) -> None:
        from textual.widgets import Input
        if not isinstance(self.focused, Input):
            self.app.action_prev_tab()

    def action_next_tab(self) -> None:
        from textual.widgets import Input
        if not isinstance(self.focused, Input):
            self.app.action_next_tab()

    def action_go_home(self) -> None:
        from textual.widgets import Input
        if isinstance(self.focused, Input):
            self.set_focus(None)
        else:
            from ..widgets.header import Navigate
            self.post_message(Navigate("home", sort="new"))
