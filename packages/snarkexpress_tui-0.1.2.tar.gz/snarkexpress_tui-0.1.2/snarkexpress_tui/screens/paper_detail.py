"""Paper detail screen with comments, voting, and related papers."""

from __future__ import annotations

from typing import Any

from textual.app import ComposeResult
from textual.containers import Horizontal, Vertical, VerticalScroll
from textual.screen import Screen
from textual.widgets import Button, Footer, Input, Label, Static, TextArea

from ..latex import render_latex
from ..widgets.header import AppHeader
from ..widgets.comment_tree import (
    CommentTree,
    DeleteCommentClicked,
    ReplyClicked,
)


class PaperDetailScreen(Screen):
    BINDINGS = [
        ("escape", "go_back", "Back"),
        ("backspace", "go_back"),
        ("r", "refresh", "Refresh"),
        ("o", "open_url", "Open URL"),
        ("u", "upvote", "Upvote"),
    ]

    DEFAULT_CSS = """
    PaperDetailScreen {
        layout: vertical;
    }
    PaperDetailScreen #detail-scroll {
        height: 1fr;
    }
    PaperDetailScreen .detail-body {
        padding: 1 2;
        height: auto;
    }
    PaperDetailScreen .paper-title-detail {
        text-style: bold;
        color: #ff8800;
        width: 1fr;
        margin-bottom: 1;
    }
    PaperDetailScreen .paper-url {
        color: #ff6600;
        width: 1fr;
        margin-bottom: 1;
    }
    PaperDetailScreen .paper-field {
        color: #cccccc;
        width: 1fr;
        margin-bottom: 1;
    }
    PaperDetailScreen .field-label {
        text-style: bold;
        color: #888888;
    }
    PaperDetailScreen .abstract-text {
        padding: 1;
        background: #1a1a1a;
        color: #cccccc;
        width: 1fr;
        margin-bottom: 1;
    }
    PaperDetailScreen .meta-line {
        color: #888888;
        width: 1fr;
        margin-bottom: 1;
    }
    PaperDetailScreen .tag-line {
        color: #ff8800;
        margin-bottom: 1;
    }
    PaperDetailScreen .section-title {
        text-style: bold;
        color: #ff6600;
        margin: 1 0;
        border-bottom: solid #333333;
    }
    PaperDetailScreen .comment-form {
        height: auto;
        padding: 1 0;
    }
    PaperDetailScreen .related-line {
        color: #ff8800;
        height: 1;
    }
    PaperDetailScreen .related-line:hover {
        color: #ffffff;
        text-style: underline;
    }
    PaperDetailScreen .loading {
        text-align: center;
        padding: 3;
        color: #888888;
    }
    PaperDetailScreen .error-msg {
        text-align: center;
        padding: 3;
        color: #ff4444;
    }
    PaperDetailScreen .owner-actions {
        layout: horizontal;
        height: 1;
        margin-bottom: 1;
    }
    PaperDetailScreen .danger-btn {
        margin-right: 1;
    }
    """

    def __init__(self, paper_id: int, **kwargs) -> None:
        super().__init__(**kwargs)
        self.paper_id = paper_id
        self.paper: dict[str, Any] = {}
        self.comments: list[dict[str, Any]] = []
        self.related: list[dict[str, Any]] = []
        self.reply_to: int | None = None

    def compose(self) -> ComposeResult:
        yield AppHeader()
        yield VerticalScroll(
            Vertical(id="detail-content", classes="detail-body"),
            id="detail-scroll",
        )
        yield Footer()

    async def on_mount(self) -> None:
        await self.load_paper()

    async def load_paper(self) -> None:
        content = self.query_one("#detail-content", Vertical)
        await content.remove_children()
        content.mount(Label("Loading...", classes="loading"))

        try:
            api = self.app.api_client  # type: ignore[attr-defined]
            self.paper = await api.get_paper(self.paper_id)

            try:
                self.comments = await api.get_comments(self.paper_id)
            except Exception:
                self.comments = []

            try:
                self.related = await api.get_related(self.paper_id)
            except Exception:
                self.related = []

            await self.render_detail()
        except Exception as e:
            await content.remove_children()
            content.mount(Label(f"Error: {e}", classes="error-msg"))

    async def render_detail(self) -> None:
        content = self.query_one("#detail-content", Vertical)
        await content.remove_children()
        p = self.paper
        tags = p.get("tags", [])
        if isinstance(tags, str):
            tags = [t.strip() for t in tags.split(",") if t.strip()]

        # Title
        await content.mount(Label(render_latex(p.get("title", "Untitled")), classes="paper-title-detail"))

        # URL
        url = p.get("url", "")
        if url:
            await content.mount(Label(f"URL: {url}", classes="paper-url"))

        # Metadata row: vote | authors | conference | date | submitter
        authors = p.get("authors", "")
        conference = p.get("conference", "")
        pub_date = p.get("published_date", "")
        submitter = p.get("submitter_username", "")
        user_vote = p.get("user_vote", 0) or 0
        vote_count = p.get("vote_count", 0) or 0

        # Vote + meta on one line
        vote_sym = "▲" if user_vote != 1 else "★"
        meta_parts = [f"{vote_sym} {vote_count}"]
        if authors:
            meta_parts.append(f"by {authors}")
        if conference:
            meta_parts.append(conference)
        if pub_date:
            meta_parts.append(pub_date[:10])
        if submitter:
            meta_parts.append(f"via {submitter}")
        await content.mount(Label("  |  ".join(meta_parts), classes="meta-line"))

        # Tags
        if tags:
            tag_names = []
            for tag in tags:
                tag_names.append(tag if isinstance(tag, str) else tag.get("name", str(tag)))
            await content.mount(Label("Tags: " + "  ".join(f"[{t}]" for t in tag_names), classes="tag-line"))

        # Abstract
        abstract = p.get("abstract", "")
        if abstract:
            await content.mount(Label("Abstract:", classes="field-label"))
            await content.mount(Static(render_latex(abstract), classes="abstract-text"))

        # BibTeX
        bib = p.get("bib_entry", "")
        if bib:
            await content.mount(Label("BibTeX:", classes="field-label"))
            await content.mount(Static(bib, classes="abstract-text"))

        # Owner actions
        auth = self.app.auth_state  # type: ignore[attr-defined]
        if auth.is_logged_in and auth.username == submitter:
            actions = Horizontal(classes="owner-actions")
            await content.mount(actions)
            await actions.mount(Button("Delete Paper", id="delete-paper", variant="error", classes="danger-btn"))

        # Comments section
        await content.mount(Label(f"Comments ({len(self._flatten_comments(self.comments))})", classes="section-title"))

        current_user = getattr(self.app, "auth_state", None)
        username = current_user.username if current_user else None
        await content.mount(CommentTree(self.comments, current_user=username))

        # Comment form
        if auth.is_logged_in:
            form = Vertical(classes="comment-form")
            await content.mount(form)
            reply_text = f" (replying to #{self.reply_to})" if self.reply_to else ""
            await form.mount(Label(f"Add comment{reply_text}:", classes="field-label"))
            await form.mount(Input(placeholder="Write a comment...", id="comment-input"))
            btn_row = Horizontal()
            await form.mount(btn_row)
            await btn_row.mount(Button("Post Comment", id="post-comment", variant="primary"))
            if self.reply_to:
                await btn_row.mount(Button("Cancel Reply", id="cancel-reply"))

        # Related papers
        if self.related:
            await content.mount(Label(f"Related Papers ({len(self.related)})", classes="section-title"))
            for rp in self.related[:5]:
                await content.mount(Label(f"  > {rp.get('title', 'Untitled')}", classes="related-line", id=f"related-{rp['id']}"))

    def _flatten_comments(self, comments: list[dict]) -> list[dict]:
        result = []
        for c in comments:
            result.append(c)
            result.extend(self._flatten_comments(c.get("replies", [])))
        return result

    async def on_button_pressed(self, event: Button.Pressed) -> None:
        btn_id = event.button.id or ""
        if btn_id == "post-comment":
            await self._post_comment()
        elif btn_id == "cancel-reply":
            self.reply_to = None
            await self.render_detail()
        elif btn_id == "delete-paper":
            await self._delete_paper()

    def on_label_clicked(self, event) -> None:
        """Handle clicks on related paper labels."""
        widget = getattr(event, "label", None) or getattr(event, "widget", None)
        if widget is None:
            return
        wid = getattr(widget, "id", "") or ""
        if wid.startswith("related-"):
            pid = int(wid.split("-", 1)[1])
            self.app.push_screen(PaperDetailScreen(pid))

    def on_click(self, event) -> None:
        """Handle clicks on related paper labels via bubbling."""
        target = event.widget if hasattr(event, "widget") else None
        if target:
            wid = getattr(target, "id", "") or ""
            if wid.startswith("related-"):
                pid = int(wid.split("-", 1)[1])
                self.app.push_screen(PaperDetailScreen(pid))

    async def on_reply_clicked(self, event: ReplyClicked) -> None:
        self.reply_to = event.comment_id
        await self.render_detail()

    async def on_delete_comment_clicked(self, event: DeleteCommentClicked) -> None:
        try:
            api = self.app.api_client  # type: ignore[attr-defined]
            await api.delete_comment(self.paper_id, event.comment_id)
            self.notify("Comment deleted.")
            self.comments = await api.get_comments(self.paper_id)
            await self.render_detail()
        except Exception as e:
            self.notify(f"Delete failed: {e}", severity="error")

    async def _do_vote(self, direction: int) -> None:
        try:
            api = self.app.api_client  # type: ignore[attr-defined]
            current = self.paper.get("user_vote", 0)
            vote = 0 if current == direction else direction
            result = await api.vote(self.paper_id, vote)
            self.paper["vote_count"] = result.get("vote_count", self.paper.get("vote_count", 0))
            self.paper["user_vote"] = result.get("user_vote", 0)
            await self.render_detail()
        except Exception as e:
            self.notify(f"Vote failed: {e}", severity="error")

    async def _post_comment(self) -> None:
        inp = self.query_one("#comment-input", Input)
        text = inp.value.strip()
        if not text:
            self.notify("Comment cannot be empty.", severity="warning")
            return
        try:
            api = self.app.api_client  # type: ignore[attr-defined]
            await api.post_comment(self.paper_id, text, parent_id=self.reply_to)
            self.reply_to = None
            self.notify("Comment posted!")
            self.comments = await api.get_comments(self.paper_id)
            await self.render_detail()
        except Exception as e:
            self.notify(f"Post failed: {e}", severity="error")

    async def _delete_paper(self) -> None:
        try:
            api = self.app.api_client  # type: ignore[attr-defined]
            await api.delete_paper(self.paper_id)
            self.notify("Paper deleted.")
            self.app.pop_screen()
        except Exception as e:
            self.notify(f"Delete failed: {e}", severity="error")

    async def action_go_back(self) -> None:
        self.app.pop_screen()

    async def action_refresh(self) -> None:
        await self.load_paper()

    def action_open_url(self) -> None:
        url = self.paper.get("url", "")
        if url:
            import webbrowser

            webbrowser.open(url)
            self.notify(f"Opening: {url}")

    async def action_upvote(self) -> None:
        await self._do_vote(1)
