"""User profile screen with submissions, comments, votes tabs."""

from __future__ import annotations

from typing import Any

from textual.app import ComposeResult
from textual.containers import Horizontal, Vertical, VerticalScroll
from textual.screen import Screen
from textual.widgets import Button, Footer, Label, Static, TabbedContent, TabPane

from ..widgets.header import AppHeader
from ..widgets.paper_item import PaperClicked, PaperItem


class ProfileScreen(Screen):
    BINDINGS = [
        ("escape", "app.pop_screen", "Back"),
        ("backspace", "app.pop_screen"),
        ("r", "refresh", "Refresh"),
    ]

    DEFAULT_CSS = """
    ProfileScreen {
        layout: vertical;
    }
    ProfileScreen .profile-header {
        dock: top;
        height: 1;
        padding: 0 2;
        background: $surface;
        color: $warning;
        text-style: bold;
    }
    ProfileScreen .profile-info {
        height: auto;
        padding: 1 2;
        border-bottom: solid $surface-lighten-2;
    }
    ProfileScreen .username-display {
        text-style: bold;
        color: $accent;
        margin-bottom: 1;
    }
    ProfileScreen .stats-row {
        layout: horizontal;
        height: auto;
        margin-bottom: 1;
    }
    ProfileScreen .stat-box {
        width: 1fr;
        height: auto;
        padding: 1;
        text-align: center;
        border: solid $surface-lighten-2;
        margin-right: 1;
    }
    ProfileScreen .stat-value {
        text-style: bold;
        color: $warning;
    }
    ProfileScreen .stat-label {
        color: $text-muted;
    }
    ProfileScreen .badges-row {
        layout: horizontal;
        height: auto;
        margin-bottom: 1;
    }
    ProfileScreen .badge {
        padding: 0 1;
        margin-right: 1;
        background: $primary;
        color: $text;
        height: 1;
    }
    ProfileScreen .tab-content {
        height: 1fr;
    }
    ProfileScreen .loading {
        text-align: center;
        padding: 3;
        color: $text-muted;
    }
    ProfileScreen .error-msg {
        text-align: center;
        padding: 3;
        color: $error;
    }
    ProfileScreen .comment-item {
        padding: 1;
        border-bottom: solid $surface-lighten-1;
        height: auto;
    }
    ProfileScreen .comment-paper {
        color: $accent;
        text-style: italic;
    }
    ProfileScreen .comment-content {
        margin-top: 1;
    }
    ProfileScreen .comment-date {
        color: $text-muted;
    }
    ProfileScreen .vote-item {
        padding: 1;
        border-bottom: solid $surface-lighten-1;
        height: auto;
        layout: horizontal;
    }
    ProfileScreen .vote-type {
        width: 6;
        text-style: bold;
    }
    ProfileScreen .vote-up {
        color: $success;
    }
    ProfileScreen .vote-down {
        color: $error;
    }
    ProfileScreen .vote-paper-title {
        width: 1fr;
        color: $accent;
    }
    """

    def __init__(self, username: str, **kwargs) -> None:
        super().__init__(**kwargs)
        self.username = username
        self.profile: dict[str, Any] = {}
        self.submissions: list[dict] = []
        self.user_comments: list[dict] = []
        self.user_votes: list[dict] = []

    def compose(self) -> ComposeResult:
        yield AppHeader()
        yield Vertical(id="profile-info", classes="profile-info")
        with TabbedContent():
            with TabPane("Submissions", id="tab-submissions"):
                yield VerticalScroll(id="submissions-list")
            with TabPane("Comments", id="tab-comments"):
                yield VerticalScroll(id="comments-list")
            with TabPane("Votes", id="tab-votes"):
                yield VerticalScroll(id="votes-list")
        yield Footer()

    async def on_mount(self) -> None:
        await self.load_profile()

    async def load_profile(self) -> None:
        info = self.query_one("#profile-info", Vertical)
        await info.remove_children()
        await info.mount(Label("Loading profile...", classes="loading"))

        api = self.app.api_client  # type: ignore[attr-defined]

        try:
            self.profile = await api.get_user(self.username)
            await self._render_profile_info()
        except Exception as e:
            await info.remove_children()
            await info.mount(Label(f"Error: {e}", classes="error-msg"))
            return

        try:
            self.submissions = await api.get_user_submissions(self.username)
            await self._render_submissions()
        except Exception:
            pass

        try:
            self.user_comments = await api.get_user_comments(self.username)
            await self._render_comments()
        except Exception:
            pass

        try:
            self.user_votes = await api.get_user_votes(self.username)
            await self._render_votes()
        except Exception:
            pass

    async def _render_profile_info(self) -> None:
        info = self.query_one("#profile-info", Vertical)
        await info.remove_children()

        user = self.profile.get("user", {})
        stats = self.profile.get("stats", {})
        badges = self.profile.get("badges", [])

        await info.mount(Label(f"@{user.get('username', self.username)}", classes="username-display"))
        await info.mount(Label(f"Member since: {user.get('created_at', '?')[:10]}"))

        stats_row = Horizontal(classes="stats-row")
        await info.mount(stats_row)

        for label, key in [
            ("Papers", "submission_count"),
            ("Comments", "comment_count"),
            ("Votes Given", "vote_count"),
            ("Votes Received", "total_votes_received"),
        ]:
            box = Vertical(classes="stat-box")
            await stats_row.mount(box)
            await box.mount(Label(str(stats.get(key, 0)), classes="stat-value"))
            await box.mount(Label(label, classes="stat-label"))

        if badges:
            badges_row = Horizontal(classes="badges-row")
            await info.mount(badges_row)
            for badge in badges:
                badge_name = badge.get("badge_type", str(badge)) if isinstance(badge, dict) else str(badge)
                await badges_row.mount(Label(badge_name, classes="badge"))

    async def _render_submissions(self) -> None:
        container = self.query_one("#submissions-list", VerticalScroll)
        await container.remove_children()
        if not self.submissions:
            await container.mount(Label("No submissions yet.", classes="loading"))
            return
        for i, paper in enumerate(self.submissions):
            await container.mount(PaperItem(paper, rank=i + 1))

    async def _render_comments(self) -> None:
        container = self.query_one("#comments-list", VerticalScroll)
        await container.remove_children()
        if not self.user_comments:
            await container.mount(Label("No comments yet.", classes="loading"))
            return
        for c in self.user_comments:
            item = Vertical(classes="comment-item")
            await container.mount(item)
            paper_title = c.get("paper_title", "Unknown paper")
            await item.mount(Label(f"on: {paper_title}", classes="comment-paper"))
            await item.mount(Label(c.get("content", ""), classes="comment-content"))
            await item.mount(Label(c.get("created_at", "")[:16], classes="comment-date"))

    async def _render_votes(self) -> None:
        container = self.query_one("#votes-list", VerticalScroll)
        await container.remove_children()
        if not self.user_votes:
            await container.mount(Label("No votes yet.", classes="loading"))
            return
        for v in self.user_votes:
            row = Horizontal(classes="vote-item")
            await container.mount(row)
            vote_type = v.get("vote_type", 0)
            cls = "vote-type vote-up" if vote_type == 1 else "vote-type vote-down"
            symbol = "▲" if vote_type == 1 else "▼"
            await row.mount(Label(symbol, classes=cls))
            await row.mount(Label(v.get("paper_title", "Unknown"), classes="vote-paper-title"))

    async def on_paper_clicked(self, event: PaperClicked) -> None:
        from .paper_detail import PaperDetailScreen
        self.app.push_screen(PaperDetailScreen(event.paper_id))

    async def action_refresh(self) -> None:
        await self.load_profile()
