"""Tags screen - browse all tags."""

from __future__ import annotations

from textual.app import ComposeResult
from textual.containers import VerticalScroll
from textual.screen import Screen
from textual.widgets import Footer, Label, Static

from ..widgets.header import AppHeader


class TagsScreen(Screen):
    BINDINGS = [
        ("escape", "go_home", "Back"),
        ("backspace", "go_home"),
        ("r", "refresh", "Refresh"),
        ("j", "cursor_down", "Down"),
        ("k", "cursor_up", "Up"),
        ("down", "cursor_down"),
        ("up", "cursor_up"),
        ("enter", "select_current", "Select"),
        ("h", "prev_tab", "◀"),
        ("l", "next_tab", "▶"),
        ("left", "prev_tab"),
        ("right", "next_tab"),
    ]

    DEFAULT_CSS = """
    TagsScreen {
        layout: vertical;
    }
    TagsScreen #tags-scroll {
        height: 1fr;
        padding: 1 2;
    }
    TagsScreen .tags-text {
        width: 100%;
        height: auto;
        link-color: #ff6600;
        link-background: #111111;
        link-style: none;
    }
    TagsScreen .loading {
        text-align: center;
        padding: 3;
        color: #888888;
    }
    TagsScreen .error-msg {
        text-align: center;
        padding: 3;
        color: #ff4444;
    }
    """

    def __init__(self, **kwargs) -> None:
        super().__init__(**kwargs)
        self.tags_list: list[dict] = []
        self.cursor = -1  # -1 = no highlight until keyboard used

    def compose(self) -> ComposeResult:
        yield AppHeader()
        yield VerticalScroll(id="tags-scroll")
        yield Footer()

    async def on_mount(self) -> None:
        self.set_focus(None)
        try:
            self.query_one(AppHeader).active_tab = "tags"
        except Exception:
            pass
        await self.load_tags()

    async def load_tags(self) -> None:
        container = self.query_one("#tags-scroll", VerticalScroll)
        await container.remove_children()
        await container.mount(Label("Loading tags...", classes="loading"))

        try:
            api = self.app.api_client  # type: ignore[attr-defined]
            tags = await api.get_tags()

            if not tags:
                await container.remove_children()
                await container.mount(Label("No tags found.", classes="loading"))
                return

            tags.sort(key=lambda t: t.get("count", 0), reverse=True)
            self.tags_list = tags
            self.cursor = -1
            await self._render_tags()

        except Exception as e:
            await container.remove_children()
            await container.mount(Label(f"Error: {e}", classes="error-msg"))

    async def _render_tags(self) -> None:
        container = self.query_one("#tags-scroll", VerticalScroll)
        await container.remove_children()

        parts = []
        for i, tag in enumerate(self.tags_list):
            name = tag.get("name", "?")
            count = tag.get("count", 0)
            safe_name = name.replace("'", "\\'")
            if i == self.cursor:
                parts.append(
                    f"[bold #000000 on #ff6600] {name} ({count}) [/bold #000000 on #ff6600]"
                )
            else:
                parts.append(
                    f"[@click=screen.click_tag('{safe_name}')]"
                    f"[#ff6600]\\[{name}][/#ff6600]"
                    f" [#666666]({count})[/#666666]"
                    f"[/]"
                )
        text = "   ".join(parts)
        await container.mount(Static(text, classes="tags-text"))

    def action_cursor_down(self) -> None:
        if not self.tags_list:
            return
        if self.cursor < 0:
            self.cursor = 0
        elif self.cursor < len(self.tags_list) - 1:
            self.cursor += 1
        self.run_worker(self._render_tags())

    def action_cursor_up(self) -> None:
        if not self.tags_list:
            return
        if self.cursor < 0:
            self.cursor = len(self.tags_list) - 1
        elif self.cursor > 0:
            self.cursor -= 1
        self.run_worker(self._render_tags())

    def action_select_current(self) -> None:
        if self.tags_list and self.cursor >= 0:
            name = self.tags_list[self.cursor].get("name", "")
            self._open_tag(name)

    def action_click_tag(self, tag_name: str) -> None:
        self._open_tag(tag_name)

    def _open_tag(self, tag_name: str) -> None:
        from .home import HomeScreen
        self.app.push_screen(HomeScreen(sort="hot", tag=tag_name))

    def action_prev_tab(self) -> None:
        self.app.action_prev_tab()

    def action_next_tab(self) -> None:
        self.app.action_next_tab()

    def action_go_home(self) -> None:
        from ..widgets.header import Navigate
        self.post_message(Navigate("home", sort="new"))

    async def action_refresh(self) -> None:
        await self.load_tags()
