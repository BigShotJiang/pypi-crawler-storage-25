"""Import keys screen."""

from __future__ import annotations

from pathlib import Path

from textual.app import ComposeResult
from textual.containers import Horizontal, Vertical, VerticalScroll
from textual.screen import Screen
from textual.widgets import Button, Footer, Input, Label

from ..widgets.header import AppHeader


class ImportKeysScreen(Screen):
    BINDINGS = [
        ("escape", "app.pop_screen", "Back"),
        ("backspace", "app.pop_screen"),
    ]

    DEFAULT_CSS = """
    ImportKeysScreen {
        layout: vertical;
        align: center middle;
    }
    ImportKeysScreen .import-header {
        dock: top;
        height: 1;
        padding: 0 2;
        background: $surface;
        color: $warning;
        text-style: bold;
    }
    ImportKeysScreen .import-box {
        width: 70;
        height: auto;
        padding: 2 4;
        border: solid $primary;
        margin: 2;
    }
    ImportKeysScreen .import-title {
        text-style: bold;
        text-align: center;
        color: $accent;
        margin-bottom: 2;
    }
    ImportKeysScreen .form-row {
        height: auto;
        margin-bottom: 1;
        layout: horizontal;
    }
    ImportKeysScreen .form-label {
        width: 12;
        padding-top: 1;
    }
    ImportKeysScreen .form-input {
        width: 1fr;
    }
    ImportKeysScreen .btn-row {
        height: 3;
        layout: horizontal;
        align: center middle;
        margin-top: 1;
    }
    ImportKeysScreen .import-btn {
        margin-right: 2;
    }
    ImportKeysScreen .status-area {
        height: auto;
        margin-top: 1;
    }
    ImportKeysScreen .error-msg {
        color: $error;
        text-align: center;
        padding: 1;
    }
    ImportKeysScreen .success-msg {
        color: $success;
        text-align: center;
        padding: 1;
    }
    ImportKeysScreen .hint {
        color: $text-muted;
        text-style: italic;
        text-align: center;
        margin-bottom: 1;
    }
    """

    def compose(self) -> ComposeResult:
        default_path = str(Path.home() / "snarkexpress-keys.json")
        yield AppHeader()
        yield VerticalScroll(
            Vertical(
                Label("Import Account Keys", classes="import-title"),
                Label(
                    "Import a previously exported key file to restore your account on this device.",
                    classes="hint",
                ),
                Horizontal(
                    Label("File path:", classes="form-label"),
                    Input(
                        placeholder=default_path,
                        id="import-path",
                        value=default_path,
                        classes="form-input",
                    ),
                    classes="form-row",
                ),
                Horizontal(
                    Button("Import", id="do-import", variant="primary", classes="import-btn"),
                    Button("Cancel", id="go-back", classes="import-btn"),
                    classes="btn-row",
                ),
                Vertical(id="import-status", classes="status-area"),
                classes="import-box",
            ),
        )
        yield Footer()

    async def on_button_pressed(self, event: Button.Pressed) -> None:
        if event.button.id == "do-import":
            await self._do_import()
        elif event.button.id == "go-back":
            self.app.pop_screen()

    async def _do_import(self) -> None:
        status = self.query_one("#import-status", Vertical)
        await status.remove_children()

        file_path = self.query_one("#import-path", Input).value.strip()
        if not file_path:
            await status.mount(Label("Please enter a file path.", classes="error-msg"))
            return

        path = Path(file_path).expanduser()
        if not path.exists():
            await status.mount(Label(f"File not found: {path}", classes="error-msg"))
            return

        try:
            json_str = path.read_text()
            auth = self.app.auth_state  # type: ignore[attr-defined]
            result = auth.import_keys(json_str)
            username = result.get("username", "")
            msg = "Keys imported successfully!"
            if username:
                msg += f" (account: {username})"
            await status.mount(Label(msg, classes="success-msg"))
            self.notify(msg)
            self.set_timer(1.5, lambda: self.app.pop_screen())
        except Exception as e:
            await status.mount(Label(f"Import failed: {e}", classes="error-msg"))
