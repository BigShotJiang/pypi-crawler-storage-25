"""Login screen with PQ challenge-response auth."""

from __future__ import annotations

from textual.app import ComposeResult
from textual.containers import Horizontal, Vertical, VerticalScroll
from textual.screen import Screen
from textual.widgets import Button, Footer, Input, Label, Static

from .. import crypto
from ..widgets.header import AppHeader


class LoginScreen(Screen):
    BINDINGS = [
        ("escape", "app.pop_screen", "Back"),
        ("backspace", "app.pop_screen"),
    ]

    DEFAULT_CSS = """
    LoginScreen {
        layout: vertical;
        align: center middle;
    }
    LoginScreen .login-header {
        dock: top;
        height: 1;
        padding: 0 2;
        background: $surface;
        color: $warning;
        text-style: bold;
    }
    LoginScreen .login-box {
        width: 70;
        height: auto;
        padding: 2 4;
        border: solid $primary;
        margin: 2;
    }
    LoginScreen .login-title {
        text-style: bold;
        text-align: center;
        color: $accent;
        margin-bottom: 2;
    }
    LoginScreen .form-row {
        height: auto;
        margin-bottom: 1;
        layout: horizontal;
    }
    LoginScreen .form-label {
        width: 16;
        padding-top: 1;
    }
    LoginScreen .form-input {
        width: 1fr;
    }
    LoginScreen .btn-row {
        height: 3;
        layout: horizontal;
        align: center middle;
        margin-top: 1;
    }
    LoginScreen .login-btn {
        margin-right: 2;
    }
    LoginScreen .status-area {
        height: auto;
        margin-top: 1;
    }
    LoginScreen .status-msg {
        text-align: center;
        padding: 1;
    }
    LoginScreen .error-msg {
        color: $error;
        text-align: center;
        padding: 1;
    }
    LoginScreen .success-msg {
        color: $success;
        text-align: center;
        padding: 1;
    }
    LoginScreen .hint {
        color: $text-muted;
        text-style: italic;
        text-align: center;
        margin-bottom: 1;
    }
    LoginScreen .section-divider {
        text-align: center;
        color: $text-muted;
        margin: 2 0 1 0;
        border-top: solid $surface-lighten-2;
        padding-top: 1;
    }
    """

    def compose(self) -> ComposeResult:
        yield AppHeader()
        auth = self.app.auth_state  # type: ignore[attr-defined]
        has_keys = auth.has_stored_keys()

        yield VerticalScroll(
            Vertical(
                Label("Sign In to Snark Express", classes="login-title"),
                Label(
                    "Enter your 4-digit PIN to unlock your stored keys and authenticate.",
                    classes="hint",
                ) if has_keys else Label(
                    "No stored keys found. Register a new account or import keys.",
                    classes="hint",
                ),
                Horizontal(
                    Label("PIN:", classes="form-label"),
                    Input(
                        placeholder="4-digit PIN",
                        id="login-pin",
                        password=True,
                        classes="form-input",
                    ),
                    classes="form-row",
                ) if has_keys else Static(""),
                Horizontal(
                    Button("Login", id="do-login", variant="primary", classes="login-btn") if has_keys else Static(""),
                    Button("Register", id="go-register", classes="login-btn"),
                    classes="btn-row",
                ),
                Label("Key Management", classes="section-divider"),
                Horizontal(
                    Button("Import Keys", id="go-import", classes="login-btn"),
                    Button("Export Keys", id="do-export", classes="login-btn") if has_keys else Static(""),
                    classes="btn-row",
                ),
                Vertical(id="status-area", classes="status-area"),
                classes="login-box",
            ),
        )
        yield Footer()

    async def on_input_submitted(self, event: Input.Submitted) -> None:
        if event.input.id == "login-pin":
            await self._do_login()

    async def on_button_pressed(self, event: Button.Pressed) -> None:
        btn_id = event.button.id or ""
        if btn_id == "do-login":
            await self._do_login()
        elif btn_id == "go-register":
            from .register import RegisterScreen
            self.app.push_screen(RegisterScreen())
        elif btn_id == "go-import":
            from .import_keys import ImportKeysScreen
            self.app.push_screen(ImportKeysScreen())
        elif btn_id == "do-export":
            await self._do_export()

    async def _do_login(self) -> None:
        status = self.query_one("#status-area", Vertical)
        await status.remove_children()

        try:
            pin_input = self.query_one("#login-pin", Input)
        except Exception:
            self.notify("No PIN input found.", severity="error")
            return

        pin = pin_input.value.strip()
        if len(pin) < 4:
            await status.mount(Label("PIN must be at least 4 digits.", classes="error-msg"))
            return

        await status.mount(Label("Decrypting keys...", classes="status-msg"))

        auth = self.app.auth_state  # type: ignore[attr-defined]
        api = self.app.api_client  # type: ignore[attr-defined]

        try:
            keys = auth.decrypt_keys(pin)
        except Exception as e:
            await status.remove_children()
            await status.mount(Label(f"Failed to decrypt keys: {e}", classes="error-msg"))
            return

        await status.remove_children()
        await status.mount(Label("Requesting challenge...", classes="status-msg"))

        try:
            challenge = await api.get_challenge(keys["mldsaPublicKey"])
        except Exception as e:
            await status.remove_children()
            await status.mount(Label(f"Challenge request failed: {e}", classes="error-msg"))
            return

        await status.remove_children()
        await status.mount(Label("Proving identity (PQ crypto)...", classes="status-msg"))

        try:
            proof = crypto.prove_challenge(
                encrypted_challenge=challenge["encryptedChallenge"],
                iv=challenge["iv"],
                kem_cipher_text=challenge["kemCipherText"],
                mldsa_secret_key=keys["mldsaSecretKey"],
                mlkem_secret_key=keys["mlkemSecretKey"],
            )
        except Exception as e:
            await status.remove_children()
            await status.mount(Label(f"Crypto proof failed: {e}", classes="error-msg"))
            return

        await status.remove_children()
        await status.mount(Label("Authenticating...", classes="status-msg"))

        try:
            result = await api.login(
                mldsa_public_key=keys["mldsaPublicKey"],
                signature=proof["signatureB64"],
                kem_mac=proof["kemMac"],
                challenge_id=challenge["challengeId"],
            )
        except Exception as e:
            await status.remove_children()
            await status.mount(Label(f"Login failed: {e}", classes="error-msg"))
            return

        token = result.get("token", "")
        user = result.get("user", {})
        username = user.get("username", "")

        auth.set_session(token, username)
        api.set_token(token)

        await status.remove_children()
        await status.mount(Label(f"Logged in as {username}!", classes="success-msg"))
        self.notify(f"Welcome back, {username}!")

        # Update header
        self.app.update_header_username()  # type: ignore[attr-defined]

        # Go back to home after short delay
        self.set_timer(1.0, lambda: self.app.pop_screen())

    async def _do_export(self) -> None:
        status = self.query_one("#status-area", Vertical)
        await status.remove_children()

        auth = self.app.auth_state  # type: ignore[attr-defined]
        exported = auth.export_keys()
        if not exported:
            await status.mount(Label("No keys to export.", classes="error-msg"))
            return

        # Save to file
        from pathlib import Path
        export_path = Path.home() / "snarkexpress-keys.json"
        export_path.write_text(exported)
        await status.mount(
            Label(f"Keys exported to: {export_path}", classes="success-msg")
        )
        self.notify(f"Keys exported to {export_path}")
