"""Entry point for `python -m snarkexpress_tui` or the `snarkexpress` CLI command."""

from __future__ import annotations

import os
import sys

# Avoid stale bytecode issues
sys.dont_write_bytecode = True


def main() -> None:
    from .app import SnarkExpressApp

    app = SnarkExpressApp()
    app.run()


if __name__ == "__main__":
    main()
