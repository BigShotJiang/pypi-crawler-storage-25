"""Paper list item widget — compact single-row style matching the web UI."""

from __future__ import annotations

import re
from typing import Any
from urllib.parse import urlparse

from textual.app import ComposeResult
from textual.containers import Horizontal
from textual.message import Message
from textual.widget import Widget
from textual.widgets import Label

from ..latex import render_latex


class PaperClicked(Message):
    def __init__(self, paper_id: int) -> None:
        super().__init__()
        self.paper_id = paper_id


class VoteClicked(Message):
    def __init__(self, paper_id: int, vote: int) -> None:
        super().__init__()
        self.paper_id = paper_id
        self.vote = vote


class UserClicked(Message):
    def __init__(self, username: str) -> None:
        super().__init__()
        self.username = username


class TagClicked(Message):
    def __init__(self, tag: str) -> None:
        super().__init__()
        self.tag = tag


def _short_source(url: str) -> str:
    """Extract a short source label from URL, e.g. 'ia.cr/2026/630'."""
    if not url:
        return ""
    try:
        parsed = urlparse(url)
        host = parsed.hostname or ""
        path = parsed.path.rstrip("/")
        if "eprint.iacr.org" in host:
            return f"ia.cr{path}"
        if "arxiv.org" in host:
            m = re.search(r"(\d+\.\d+)", path)
            return f"arxiv:{m.group(1)}" if m else f"arxiv{path}"
        if "cic.iacr.org" in host:
            return f"cic{path}"
        if "doi.org" in host:
            return f"doi{path}"
        return host + path
    except Exception:
        return ""


class PaperItem(Widget):
    """Compact single-row paper item matching the web UI."""

    DEFAULT_CSS = """
    PaperItem {
        height: auto;
        padding: 0 1;
        layout: horizontal;
        background: #1a1a1a;
    }
    PaperItem:hover {
        background: #222222;
    }
    PaperItem:focus {
        background: #222222;
    }
    PaperItem:focus .paper-title-text {
        color: #ffffff;
        text-style: bold;
    }
    PaperItem:focus .vote-area {
        color: #ff6600;
    }
    PaperItem .vote-area {
        width: 6;
        color: #888888;
    }
    PaperItem .vote-active {
        color: #ff6600;
        text-style: bold;
    }
    PaperItem .paper-title-text {
        width: 1fr;
        color: #cccccc;
    }
    PaperItem .source-label {
        width: auto;
        color: #666666;
        margin-left: 1;
    }
    """

    can_focus = True

    def __init__(self, paper: dict[str, Any], rank: int = 0, **kwargs: Any) -> None:
        super().__init__(**kwargs)
        self.paper = paper
        self.rank = rank

    def compose(self) -> ComposeResult:
        p = self.paper
        vote_count = p.get("vote_count", 0) or 0
        user_vote = p.get("user_vote", 0) or 0
        title = render_latex(p.get("title", "Untitled"))
        url = p.get("url", "")
        source = _short_source(url)

        vote_cls = "vote-area vote-active" if user_vote == 1 else "vote-area"
        yield Label(f"▲ {vote_count}", classes=vote_cls)
        yield Label(title, classes="paper-title-text")
        if source:
            yield Label(f"({source})", classes="source-label")

    def on_click(self) -> None:
        self.post_message(PaperClicked(self.paper["id"]))

    def key_u(self) -> None:
        current = self.paper.get("user_vote", 0) or 0
        self.post_message(VoteClicked(self.paper["id"], 0 if current == 1 else 1))

    def key_d(self) -> None:
        current = self.paper.get("user_vote", 0) or 0
        self.post_message(VoteClicked(self.paper["id"], 0 if current == -1 else -1))
