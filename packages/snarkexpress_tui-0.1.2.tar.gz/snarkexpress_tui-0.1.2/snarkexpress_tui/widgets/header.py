"""App header bar — brand + keyboard-navigable tabs."""

from __future__ import annotations

from textual.app import ComposeResult
from textual.message import Message
from textual.reactive import reactive
from textual.widget import Widget
from textual.widgets import Label, Static


class Navigate(Message):
    def __init__(self, target: str, **kwargs: str) -> None:
        super().__init__()
        self.target = target
        self.kwargs = kwargs


# Ordered tabs for h/l cycling (brand click = home, no separate Home tab)
TAB_ITEMS = [
    ("Submit", "submit", {}),
    ("Search", "search", {}),
    ("Tags", "tags", {}),
]


class _TabItem(Static):
    """A single tab in the header."""

    DEFAULT_CSS = """
    _TabItem {
        width: auto;
        height: 1;
        padding: 0 3;
        color: #888888;
        text-style: bold;
    }
    _TabItem:hover {
        color: #ffffff;
        background: #222222;
    }
    _TabItem.active {
        color: #ff6600;
    }
    """

    def __init__(self, label: str, nav_target: str, nav_kwargs: dict, **kwargs) -> None:
        super().__init__(label, **kwargs)
        self.nav_target = nav_target
        self.nav_kwargs = nav_kwargs

    def on_click(self) -> None:
        self.post_message(Navigate(self.nav_target, **self.nav_kwargs))


class _BrandLink(Static):
    """Clickable brand name -> navigate home."""

    def on_click(self) -> None:
        self.post_message(Navigate("home", sort="hot"))


class AppHeader(Widget):
    DEFAULT_CSS = """
    AppHeader {
        dock: top;
        height: 2;
        background: #1a1a1a;
        border-bottom: solid #ff6600;
        layout: horizontal;
    }
    AppHeader .brand {
        width: auto;
        height: 1;
        padding: 0 2;
        text-style: bold;
        color: #ff6600;
    }
    AppHeader .brand:hover {
        color: #ff8800;
    }
    AppHeader .sep {
        width: auto;
        color: #333333;
    }
    AppHeader .spacer {
        width: 1fr;
    }
    AppHeader .user-label {
        padding: 0 2;
        color: #ff8800;
        text-style: bold;
    }
    """

    username: reactive[str] = reactive("")
    active_tab: reactive[str] = reactive("home")

    def compose(self) -> ComposeResult:
        yield _BrandLink("Snark Express", classes="brand", id="brand")
        yield Static("│", classes="sep")
        for label, target, kwargs in TAB_ITEMS:
            tab = _TabItem(label, target, kwargs, id=f"tab-{target}")
            if target == "submit":
                tab.display = False
            yield tab
        yield Static("", classes="spacer")
        yield Label("", id="user-label", classes="user-label")
        yield _TabItem("login", "_auth", {}, id="auth-link")

    def on_click_brand(self) -> None:
        self.post_message(Navigate("home", sort="hot"))

    def watch_active_tab(self, value: str) -> None:
        for _, target, _ in TAB_ITEMS:
            try:
                tab = self.query_one(f"#tab-{target}", _TabItem)
                if target == value:
                    tab.add_class("active")
                else:
                    tab.remove_class("active")
            except Exception:
                pass

    def watch_username(self, value: str) -> None:
        try:
            label = self.query_one("#user-label", Label)
            auth = self.query_one("#auth-link", _TabItem)
            submit_tab = self.query_one("#tab-submit", _TabItem)
            if value:
                label.update(value)
                auth.update("logout")
                auth.nav_target = "logout"
                auth.nav_kwargs = {}
                submit_tab.display = True
            else:
                label.update("")
                auth.update("login")
                auth.nav_target = "login"
                auth.nav_kwargs = {}
                submit_tab.display = False
        except Exception:
            pass
