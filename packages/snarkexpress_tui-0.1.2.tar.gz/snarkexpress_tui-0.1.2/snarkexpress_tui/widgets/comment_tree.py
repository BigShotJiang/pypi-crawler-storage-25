"""Comment tree widget for paper detail view."""

from __future__ import annotations

from typing import Any

from textual.app import ComposeResult
from textual.containers import Vertical
from textual.message import Message
from textual.widget import Widget
from textual.widgets import Button, Label, Static


class ReplyClicked(Message):
    def __init__(self, comment_id: int) -> None:
        super().__init__()
        self.comment_id = comment_id


class DeleteCommentClicked(Message):
    def __init__(self, comment_id: int) -> None:
        super().__init__()
        self.comment_id = comment_id


class CommentNode(Widget):
    """A single comment with possible nested replies."""

    DEFAULT_CSS = """
    CommentNode {
        height: auto;
        margin: 0 0 0 0;
        padding: 0 0 0 2;
        border-left: solid $surface-lighten-2;
    }
    CommentNode .comment-header {
        color: $text-muted;
    }
    CommentNode .comment-user {
        text-style: bold;
        color: $accent;
    }
    CommentNode .comment-body {
        margin: 0 0 1 0;
    }
    CommentNode .comment-actions {
        height: 1;
        layout: horizontal;
    }
    CommentNode .comment-act-btn {
        min-width: 0;
        height: 1;
        border: none;
        background: transparent;
        color: $text-muted;
        margin-right: 2;
    }
    CommentNode .comment-act-btn:hover {
        color: $accent;
    }
    CommentNode .deleted-body {
        color: $text-muted;
        text-style: italic;
    }
    """

    def __init__(
        self,
        comment: dict[str, Any],
        current_user: str | None = None,
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)
        self.comment = comment
        self.current_user = current_user

    def compose(self) -> ComposeResult:
        c = self.comment
        username = c.get("username", "?")
        created = c.get("created_at", "")[:16]
        deleted = c.get("deleted", False)

        yield Label(f"{username} · {created}", classes="comment-header")
        if deleted:
            yield Label("[deleted]", classes="deleted-body")
        else:
            yield Static(c.get("content", ""), classes="comment-body")
            from textual.containers import Horizontal

            with Horizontal(classes="comment-actions"):
                yield Button(
                    "reply",
                    id=f"reply-{c['id']}",
                    classes="comment-act-btn",
                )
                if self.current_user and self.current_user == username:
                    yield Button(
                        "delete",
                        id=f"delcomment-{c['id']}",
                        classes="comment-act-btn",
                    )

        for reply in c.get("replies", []):
            yield CommentNode(reply, current_user=self.current_user)

    def on_button_pressed(self, event: Button.Pressed) -> None:
        btn_id = event.button.id or ""
        if btn_id.startswith("reply-"):
            cid = int(btn_id.split("-", 1)[1])
            self.post_message(ReplyClicked(cid))
            event.stop()
        elif btn_id.startswith("delcomment-"):
            cid = int(btn_id.split("-", 1)[1])
            self.post_message(DeleteCommentClicked(cid))
            event.stop()


class CommentTree(Widget):
    """Renders a tree of comments."""

    DEFAULT_CSS = """
    CommentTree {
        height: auto;
        padding: 1;
    }
    CommentTree .no-comments {
        color: $text-muted;
        text-style: italic;
        padding: 1;
    }
    """

    def __init__(
        self,
        comments: list[dict[str, Any]],
        current_user: str | None = None,
        **kwargs: Any,
    ) -> None:
        super().__init__(**kwargs)
        self.comments = comments
        self.current_user = current_user

    def compose(self) -> ComposeResult:
        if not self.comments:
            yield Label("No comments yet.", classes="no-comments")
            return
        for comment in self.comments:
            yield CommentNode(comment, current_user=self.current_user)
