"""Auth state management for the TUI."""

from __future__ import annotations

import json
from typing import Any

from .config import KEY_FILE, SESSION_FILE, ensure_data_dir
from . import crypto


class AuthState:
    """Manages authentication state: token, username, and stored keys."""

    def __init__(self) -> None:
        self.token: str | None = None
        self.username: str | None = None
        self._load_session()

    def _load_session(self) -> None:
        ensure_data_dir()
        if SESSION_FILE.exists():
            try:
                data = json.loads(SESSION_FILE.read_text())
                self.token = data.get("token")
                self.username = data.get("username")
            except (json.JSONDecodeError, OSError):
                pass

    def _save_session(self) -> None:
        ensure_data_dir()
        SESSION_FILE.write_text(
            json.dumps({"token": self.token, "username": self.username})
        )

    @property
    def is_logged_in(self) -> bool:
        return self.token is not None and self.username is not None

    def set_session(self, token: str, username: str) -> None:
        self.token = token
        self.username = username
        self._save_session()

    def logout(self) -> None:
        self.token = None
        self.username = None
        if SESSION_FILE.exists():
            SESSION_FILE.unlink()

    # ── Key storage ───────────────────────────────────────────────────

    def has_stored_keys(self) -> bool:
        return KEY_FILE.exists()

    def get_stored_public_keys(self) -> dict[str, str] | None:
        if not KEY_FILE.exists():
            return None
        try:
            data = json.loads(KEY_FILE.read_text())
            if data.get("version") != 2:
                return None
            return {
                "mldsaPublicKey": data["mldsaPublicKey"],
                "mlkemPublicKey": data["mlkemPublicKey"],
            }
        except (json.JSONDecodeError, KeyError, OSError):
            return None

    def store_encrypted_keys(self, keys: dict[str, str], password: str) -> None:
        encrypted = crypto.encrypt_keys(keys, password)
        ensure_data_dir()
        KEY_FILE.write_text(json.dumps(encrypted, indent=2))

    def decrypt_keys(self, password: str) -> dict[str, str]:
        if not KEY_FILE.exists():
            raise RuntimeError("No stored keys found")
        data = json.loads(KEY_FILE.read_text())
        return crypto.decrypt_keys(data, password)

    def export_keys(self) -> str | None:
        if not KEY_FILE.exists():
            return None
        data = json.loads(KEY_FILE.read_text())
        export_data = {
            "_format": "snarkexpress-account",
            "_exportedAt": __import__("datetime").datetime.now().isoformat(),
            "_username": self.username,
            **data,
        }
        return json.dumps(export_data, indent=2)

    def import_keys(self, json_str: str) -> dict[str, str]:
        parsed = json.loads(json_str)
        if parsed.get("_format") and parsed["_format"] != "snarkexpress-account":
            raise ValueError("Unrecognized file format")
        if parsed.get("version") != 2:
            raise ValueError("Incompatible key file version")
        for field in ("encryptedSecrets", "mldsaPublicKey", "mlkemPublicKey", "salt", "iv"):
            if field not in parsed:
                raise ValueError(f"Missing required field: {field}")

        key_data = {
            "encryptedSecrets": parsed["encryptedSecrets"],
            "mldsaPublicKey": parsed["mldsaPublicKey"],
            "mlkemPublicKey": parsed["mlkemPublicKey"],
            "salt": parsed["salt"],
            "iv": parsed["iv"],
            "version": parsed["version"],
        }
        ensure_data_dir()
        KEY_FILE.write_text(json.dumps(key_data, indent=2))

        if parsed.get("_username"):
            self.username = parsed["_username"]

        return {
            "mldsaPublicKey": key_data["mldsaPublicKey"],
            "mlkemPublicKey": key_data["mlkemPublicKey"],
        }

    def clear_keys(self) -> None:
        if KEY_FILE.exists():
            KEY_FILE.unlink()
