"""Convert inline LaTeX math ($...$) to Unicode for terminal display."""

from __future__ import annotations

import re

try:
    from flatlatex import converter as _make_converter

    _conv = _make_converter()

    def _convert_math(match: re.Match) -> str:
        latex = match.group(1)
        try:
            return _conv.convert(latex)
        except Exception:
            return match.group(0)  # return original on failure

except ImportError:
    def _convert_math(match: re.Match) -> str:
        return match.group(1)  # strip $ delimiters as fallback


_INLINE_MATH = re.compile(r"\$([^$]+)\$")


def render_latex(text: str) -> str:
    """Replace all $...$ spans with Unicode equivalents."""
    if not text or "$" not in text:
        return text
    return _INLINE_MATH.sub(_convert_math, text)
