"""Snark Express TUI - Terminal interface for Snark Express."""
