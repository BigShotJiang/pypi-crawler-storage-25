import argparse
import tomllib
from collections.abc import Iterable
from typing import Any, Optional

__all__ = ["main", "run"]


def get_from_file(
    *inlines: str,
    keys: Any,
    default: object,
) -> Any:
    intext: str
    intext = ""
    for inline in inlines:
        intext += inline + "\n"
    try:
        data = tomllib.loads(intext)
        for x in keys:
            y = str(x) if isinstance(data, dict) else int(x)
            data = data[y]
    except Exception as exc:
        return default
    else:
        return data


def main(args: Optional[Iterable[str]] = None) -> None:
    parser: argparse.ArgumentParser
    space: argparse.Namespace
    parser = argparse.ArgumentParser(fromfile_prefix_chars="@")
    parser.add_argument(
        "--key",
        action="append",
        default=[],
        dest="keys",
    )
    parser.add_argument("--default")
    parser.add_argument("--outfile", default="-")
    parser.add_argument("--outstring", default="%s\n")
    parser.add_argument("inlines", nargs="*")
    space = parser.parse_args(args)
    run(
        *space.inlines,
        keys=space.keys,
        default=space.default,
        outfile=space.outfile,
        outstring=space.outstring,
    )


def run(
    *inlines: str,
    keys: Iterable[Any] = (),
    default: object = None,
    outfile: str = "-",
    outstring: str = "%s\n",
) -> None:
    ans = get_from_file(
        *inlines,
        keys=keys,
        default=default,
    )
    try:
        ans = outstring % ans
    except Exception:
        ans = default
    if ans is None:
        return
    if outfile == "-":
        print(ans, end="")
        return
    with open(outfile, "w") as stream:
        print(ans, end="", file=stream)
