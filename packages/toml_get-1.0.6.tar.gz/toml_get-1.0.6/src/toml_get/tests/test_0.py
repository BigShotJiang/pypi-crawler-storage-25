import unittest
from typing import *

from toml_get import core

__all__ = ["Test_0"]


class Test_0(unittest.TestCase):
    def test_0(self: Self) -> None:
        self.assertEqual(
            core.get_from_file("[foo]", "bar = 42", keys=("foo", "bar"), default=9000),
            42,
        )
        self.assertEqual(
            core.get_from_file("[foo]", "bar = 42", keys=("foo", "baz"), default=9000),
            9000,
        )


if __name__ == "__main__":
    unittest.main()
