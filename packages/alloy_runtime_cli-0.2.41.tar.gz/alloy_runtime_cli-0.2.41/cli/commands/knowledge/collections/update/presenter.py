"""Presenter for collection update output."""

from cli.infrastructure.formatting.fields import (
    format_datetime,
    format_optional,
    format_uuid,
)
from cli.infrastructure.output import OutputService
from cli.infrastructure.renderers.entity_renderer import FieldConfig
from alloy_runtime_types.dtos.knowledge import UpdateCollectionResponse


def present_collection_update_success(response: UpdateCollectionResponse) -> None:
    """Present successful collection update.

    Args:
        response: Collection update response from server
    """
    output = OutputService.get()
    output.result(
        action="update",
        resource="knowledge_collection",
        identifier=str(response.id),
        name=response.name,
    )
    output.entity(
        response,
        f"Collection: {response.name}",
        [
            FieldConfig("id", "ID", lambda v: format_uuid(v, short=False)),
            FieldConfig("name", "Name"),
            FieldConfig("description", "Description", format_optional),
            FieldConfig("embedding_model", "Embedding Model"),
            FieldConfig("chunk_size_tokens", "Chunk Size", lambda v: f"{v} tokens"),
            FieldConfig(
                "chunk_overlap_tokens", "Chunk Overlap", lambda v: f"{v} tokens"
            ),
            FieldConfig("section_strategy", "Section Strategy"),
            FieldConfig("rerank_instruction", "Rerank Instruction", format_optional),
            FieldConfig("created_at", "Created", format_datetime),
            FieldConfig("updated_at", "Updated", format_datetime),
        ],
        raw_payload=response,
    )
