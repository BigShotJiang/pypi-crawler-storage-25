############################### GLOBAL IMPORTS ###############################

import numpy as np 
from matplotlib import pyplot as plt ; import matplotlib as mpl
from astropy.io import fits ; from astropy import units as u

import poppy
from poppy import radial_profile

import logging
_log = logging.getLogger('psfcraft')

import warnings
warnings.filterwarnings('ignore', category=UserWarning, module='pysynphot')
warnings.filterwarnings('ignore', message='.*pkg_resources is deprecated.*')

from multiprocessing import Pool, cpu_count
from concurrent.futures import ProcessPoolExecutor,ThreadPoolExecutor

from psfcraft.constants import FILTER_Y_CUTS,FILTER_J_CUTS,FILTER_H_CUTS

import os
# Environment variable pointing where the datasets and models are stored.

import subprocess
try:
    subprocess.check_output('nvidia-smi')
    on_gpu = True
except Exception:
    on_gpu = False

global_path = os.environ.get('PSFCRAFT_DATA_DIR', os.path.join(os.path.expanduser('~'), 'psfcraft_data'))

get_path_data = lambda optics_name,optics_version : os.path.join(global_path,"PSFCraft",optics_name,'v'+optics_version)
get_path_model = lambda optics_name,optics_version : os.path.join(global_path,"PSFZerNet",optics_name,'v'+optics_version)

def get_opticsname_version(dataset_name):
    optics_name = dataset_name.split("_")[0]
    subversion = 'N' in dataset_name.split("_")[3]
    optics_version = dataset_name.split("_")[1]+'_'+dataset_name.split("_")[2] if subversion else dataset_name.split("_")[1]
    return optics_name, optics_version[1:] # from 2nd element for version to remove the 'v'

from tqdm import tqdm

import h5py

def get_filter_bounds(filter_name):
    if filter_name == 'Y':
        return FILTER_Y_CUTS
    elif filter_name == 'J':
        return FILTER_J_CUTS
    elif filter_name == 'H':
        return FILTER_H_CUTS
    else : 
        raise ValueError(f"Unknown filter name: {filter_name}. Please use 'Y', 'J', or 'H'.")
    # else:
    #     try :
    #         if type(filter_bounds) is list : 
    #             return filter_bounds
    #     except NameError:
    #         raise ValueError(f"Unknown filter name: {filter_name} / filter_bounds not defined. Please use 'Y', 'J', or 'H' or provide a list of bounds.")

def build_wfe_budget(radial_budget: list = [0, 100, 50, 36, 18, 9, 5]) -> list:
    """Build a flat WFE budget list from a per-radial-order specification.

    Each entry ``radial_budget[i]`` is repeated ``i + 1`` times to account for
    the increasing number of Zernike modes per radial order (order 0 has 1
    mode, order 1 has 2 modes, etc.).

    Args:
        radial_budget (list[int]): WFE amplitude in nm RMS for each radial
            order, starting from order 0 (piston).  The default
            ``[0, 100, 50, 36, 18, 9, 5]`` covers orders 0–6.

    Returns:
        list[int]: Flat budget list whose total length equals the number of
            Zernike modes covered by the specification.

    Example:
        >>> build_wfe_budget([0, 100, 50])
        [0, 100, 100, 50, 50, 50]
    """
    WFE_BUDGET = []
    for i, budget in enumerate(radial_budget):
        WFE_BUDGET.extend([budget] * (i + 1))
    return WFE_BUDGET

def _planck_law(wavelength_m: np.ndarray, temperature_K: float) -> np.ndarray:
    """Spectral radiance of a black body (Planck's law, W sr⁻¹ m⁻² m⁻¹)."""
    from astropy.constants import c, h, k_B
    c_, h_, k_ = c.value, h.value, k_B.value
    return 2 * h_ * c_**2 / (wavelength_m**5 * (np.exp(h_ * c_ / (wavelength_m * k_ * temperature_K)) - 1))


def build_polychromatic_star(temperature: float, filter_name: str, sampling: int) -> dict:
    """
    Builds a polychromatic star model using a black body spectrum.

    Uses Planck's law directly (via astropy constants) — no pysynphot required.

    Args:
        temperature (float): The temperature of the star in Kelvin.
        filter_name (str): Name of the photometric filter used to determine wavelength bounds.
        sampling (int): Number of wavelength samples within the filter bandpass.

    Returns:
        dict: Dictionary with keys ``wavelengths`` (array, metres) and ``weights``
            (array, spectral flux density from a black-body at *temperature*).
    """
    bounds = get_filter_bounds(filter_name)
    # bounds are in nm → convert to metres
    wavelengths_m = np.linspace(bounds[0], bounds[1], sampling) * 1e-9
    weights = _planck_law(wavelengths_m, temperature)
    return {'wavelengths': wavelengths_m, 'weights': weights}

############################### DICTIONNARIES ###############################

# Optical aberrations names given following the Noll indexation
Optical_aberration_names = [ name.title() for name in [
    'piston', 'tip', 'tilt', 'defocus', 'oblique astigmatism', 'vertical astigmatism', 'vertical coma', 'horizontal coma',
    'vertical trefoil', 'oblique trefoil', 'primary spherical', 'vertical secondary astigmatism','oblique secondary astigmatism', 
    'vertical quadrafoil', 'oblique quadrafoil', 

    'horizontal secondary coma','vertical secondary coma', 'horizontal secondary trefoil', 'vertical secondary trefoil', 
    'horizontal pentafoil','vertical pentafoil',
]]+30*[""]
Aberrations_abbreviations = [('Vertical','V.'),('Horizontal','H.'),('Oblique','Ob.'),
                         ('Primary','1st'),('Secondary','2nd'),('Tertiary','3rd'),('Quaternary','4th'),
                         ('Astigmatism','Astig.'),('Coma','Coma'),
                         ('Trefoil','Trefoil'),('Spherical','Sph.'),('Quadrafoil','Quadrafoil')]

Optical_aberration_names_short = Optical_aberration_names
for old,new in Aberrations_abbreviations:
    Optical_aberration_names_short = [abb.replace(old,new) for abb in Optical_aberration_names_short]

Symmetrical_orders_indexes = [4, 5, 6, 11, 12, 13, 14, 15, 22, 23, 24, 25, 26, 27, 28, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, \
                        80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120]
# Given in Noll index, the defocus is the first symmetric order at 3 (in Python its index is 2), then :

############################### ZERNIKE UTILS ###############################

def generate_coefficients(wfe_budget, sec_factor: float = 1.0) -> np.ndarray:
    """Draw a random realisation of Zernike coefficients from a uniform distribution.

    Each coefficient is drawn independently from a uniform distribution
    over ``[-budget_i * sec_factor, +budget_i * sec_factor]``
    (converted from nm to metres internally).

    Args:
        wfe_budget (list[float]): WFE amplitude in nm RMS for each Zernike
            coefficient.  Typically the output of :func:`build_wfe_budget`.
        sec_factor (float): Global scaling factor applied to every budget
            entry before sampling.  Useful to reduce the amplitude of
            secondary-mirror-sensitive modes.  Defaults to ``1.0``.

    Returns:
        numpy.ndarray: Array of random Zernike coefficients in **metres**,
            with the same length as ``wfe_budget``.

    Example:
        >>> import numpy as np
        >>> np.random.seed(0)
        >>> budget = build_wfe_budget([0, 50, 30])   # 6 coefficients
        >>> coefs = generate_coefficients(budget)
        >>> coefs.shape
        (6,)
    """
    return np.random.uniform(
        low=-1e-9 * np.array(wfe_budget) * sec_factor,
        high=1e-9 * np.array(wfe_budget) * sec_factor
    )

############################### MAIN HANDLERS ###############################

def psf_computation(object, wfe_coefs):
    """
    Computes the Point Spread Function (PSF) of an optical system.

    Parameters
    ----------
    object : object
        Optical system object.
    wfe_coefs : array
        List of the WFE coefficients for each Zernike Polynomial.
        Each coefficient should be given in meters.

    Returns
    -------
    tuple
        Tuple containing the WFE budget, PSF for the source and PSF for the background.
    """
    object.wfe_coefficients = wfe_coefs
    if type(object.source) != float: 
        # Then polychromatic case
        psfs = [psf_sup,psf_sub] = object.calc_psf(source=object.source,oversample=object.detector_oversample)
        pass
    else : 
        psfs = [psf_sup,psf_sub] = object.calc_psf(monochromatic=object.source,oversample=object.detector_oversample)
    
    return wfe_coefs,psf_sup.data,psf_sub.data

def psf_computation_parallel(args):
    """
    Wrapper for psf_computation to be used with multiprocessing.Pool.imap() for parallel processing.

    Parameters
    ----------
    args : tuple
        Tuple of arguments for psf_computation.

    Returns
    -------
    tuple
        Result of psf_computation.
    """
    return psf_computation(*args)

class PSF_Generator:
    """
    This class generates a database of Point Spread Functions (PSFs) for optical systems.

    Parameters
    ----------
    optics_name : str, optional
        Name of the optical system. Defaults to 'NewtonianTelescope'. Options: 'Euclid'.
    optics_version : str, optional
        Version of the optical system. Defaults to '0', indicating no struts.
    size_psf : int, optional
        Size of the PSFs in pixels. Defaults to 32.
    N_psfs : int, optional
        Total number of PSFs to generate for the dataset. Defaults to 1000.
    wfe_budget : list, optional
        List of the Wavefront Error (WFE) budget for each Zernike coefficient.
    source : float or list, optional
        Wavelength of the monochromatic source in nanometers or a list specifying the type of random spectral source.

    Attributes
    ----------
    OPTICS_NAME_DEFAULT : str
        Default name of the optical system.
    OPTICS_VERSION_DEFAULT : str
        Default version of the optical system.
    ...

    Methods
    -------
    __init__(optics_name, optics_version, size_psf, N_psfs, wfe_budget, source, )
        Initializes the PSF_Generator with specified parameters.
    optical_system_initiator()
        Initiates the optical system using psfcraft_core.
    simulate_single_psf(wfe_budget, source)
        Simulates a single PSF.
    simulate_worst_psf()
        Returns the PSF with maximum coefficients.
    write_database_hdf5()
        Writes the generated PSFs to an HDF5 file.
    """


    OPTICS_NAME_DEFAULT = 'NewtonianTelescope'
    OPTICS_VERSION_DEFAULT = '0'

    OPTICS_PRIMARY_RADIUS = 0.5 # Meters
    OPTICS_SECONDARY_RADIUS = 0.1 # Meters

    SIZE_PSF = 32
    N_PSFS = int(1e3)
    WFE_BUDGET = [0, 100,100, 50,50,50]
    # WFE_BUDGET = [0, 100,100, 50,50,50, 35,35,35,35]

    SOURCE_DEFAULT = 1e-6
    
    FILTER_DEFAULT = None
    SAMPLING_WL_DEFAULT = None

    DETECTOR_OVERSAMPLING = 4 # Oversampling factor for the PSFs, default is 4
    FOV_ARCSEC = None  # Add this parameter

    def __init__(self, 
                optics_name = OPTICS_NAME_DEFAULT,
                optics_version = OPTICS_VERSION_DEFAULT,
                optics_primary_radius = OPTICS_PRIMARY_RADIUS,
                optics_secondary_radius = OPTICS_SECONDARY_RADIUS,

                size_psf = SIZE_PSF,
                N_psfs = N_PSFS,
                wfe_budget = WFE_BUDGET,
                
                source = SOURCE_DEFAULT, 
                
                detector_oversampling = DETECTOR_OVERSAMPLING, # Oversampling factor for the PSFs, default is 6
                fov_arcsec = FOV_ARCSEC,
                ):


        self.optics_name = optics_name
        self.optics_version = optics_version
        self.optics_primary_radius = float(optics_primary_radius)
        self.optics_secondary_radius = float(optics_secondary_radius)

        self.size_psf = int(size_psf)
        self.N_psfs = int(N_psfs)
        self.wfe_budget = wfe_budget # Should be given in nanometers
        self.N_orders = len(wfe_budget) # Number of Zernike coefficients but also the maximum order of Zernike polynomials in Noll's indexation.

        self.source = source

        self.detector_oversampling = detector_oversampling
        self.fov_arcsec = fov_arcsec 
        
        self.chromatism = 'mono' if type(self.source) == float else 'poly' # If the source is a float, then it is monochromatic, otherwise it is polychromatic.
        if self.chromatism == 'poly':
            try : # Only works with a dictionary source that contains 'temperature', 'filter' and 'sampling'
                self.temperature_star = self.source['temperature']
                self.filter_name = self.source['filter']
                self.sampling_wl = self.source['sampling']
            except KeyError as e:
                raise ValueError(f"Missing key in source dictionary: {e}")
        else : 
            self.source = float(self.source)

        self.path = get_path_data(self.optics_name, self.optics_version)

        self.obj = None
        self.optical_system_initiator()


    def get_custom_fov(self):
        """Pickle-safe method to return custom FOV"""
        return self.fov_arcsec if self.fov_arcsec is not None else self.obj._get_default_fov()

    def optical_system_initiator(self):
        # import importlib
        from psfcraft import psfcraft_core
        func_obj = getattr(psfcraft_core, self.optics_name)
        self.obj = func_obj(name=self.optics_name, version=self.optics_version, 
                primary_radius=self.optics_primary_radius,secondary_radius=self.optics_secondary_radius,
                wfe_coefficients=[0.],
                detector_oversample=self.detector_oversampling
        )

        # Handle polychromatic source properly
        if self.chromatism == 'poly':
            if not hasattr(self, 'temperature_star') or not hasattr(self, 'filter_name') or not hasattr(self, 'sampling_wl'):
                raise ValueError("Missing polychromatic source parameters.")
            else :
                self.obj.source = build_polychromatic_star(
                    self.temperature_star, 
                    self.filter_name, 
                    self.sampling_wl
                )
        else:
            self.obj.source = self.source

        # Use the class method instead of lambda
        if self.fov_arcsec is not None:
            self.obj._get_default_fov = self.get_custom_fov


    # def filename_builder(self,extension):
    #     """
    #     Builds the filename of the PSFs, containing all the parameters AND the extension.
    #     Should be called inside each method that writes a file.
    #     """
    #     # Name of the file containing the PSFs
    #     filename_psfs = None
    #     filename_psfs = self.optics_name + "_v" + self.optics_version # Name of the optical version and the optical system
    #     filename_psfs += "_N" + str(self.size_psf) # Size of the PSFs, by default 32x32 so N32
    #     filename_psfs += "_P"+format(self.N_psfs, '.0e').replace('+0','').replace('+','') # The number of PSFs is in a format "1e7" or "1e23" for example.
    #     filename_psfs += "_J" + str(self.N_orders) # Number of Zernike coefficients
    #     filename_psfs += "_ChP" if self.chromatism == 'poly' else '_ChM' # Chromatism of the source, either polychromatic or monochromatic
        
    #     if self.chromatism == 'poly':
    #         # filename_psfs += "_Dw" + str(int(self.sampling_wl)) + "nm" # Sampling wavelength for spectra (in nm)
    #         pass
    #     else : 
    #         wavelength_format = str(int(round(self.source * 1e9)))
    #         # wavelength_format = str(int(self.source*1e9))
    #         # wavelength_format = format(float(self.source)*1e9, '.0e').replace('+0','').replace('+','')
    #         filename_psfs += "_W" + wavelength_format + "nm" # Wavelength of the monochromatic source (in nm)

    #     # Now we add the extension
    #     filename_psfs += extension
    #     self.filename_psfs = filename_psfs

    def filename_builder(self, extension):
        """
        Builds the filename of the PSFs, containing all the parameters AND the extension.
        Should be called inside each method that writes a file.
        """
        # Name of the file containing the PSFs
        filename_psfs = self.optics_name + "_v" + self.optics_version # Name of the optical version and the optical system
        filename_psfs += "_N" + str(self.size_psf) # Size of the PSFs, by default 32x32 so N32
        filename_psfs += "_P"+format(self.N_psfs, '.0e').replace('+0','').replace('+','') # The number of PSFs is in a format "1e7" or "1e23" for example.
        filename_psfs += "_J" + str(self.N_orders) # Number of Zernike coefficients
        filename_psfs += "_ChP" if self.chromatism == 'poly' else '_ChM' # Chromatism of the source, either polychromatic or monochromatic
        
        if self.chromatism == 'poly':
            # Add photometric band information
            filename_psfs += "_Phot" + self.filter_name  # e.g., _PhotY, _PhotJ, _PhotH
            # Add wavelength sampling information
            filename_psfs += "_Dw" + str(int(self.sampling_wl))  # e.g., _Dw10
            # Add blackbody temperature information
            filename_psfs += "_BB" + str(int(self.temperature_star)) + "K"  # e.g., _BB6600K
            
        else : 
            wavelength_format = str(int(round(self.source * 1e9)))
            filename_psfs += "_W" + wavelength_format + "nm" # Wavelength of the monochromatic source (in nm)

        # Now we add the extension
        filename_psfs += extension
        self.filename_psfs = filename_psfs
    
    
    def existing_file(self):
        print("\n\n")
        self.filepath = os.path.join(self.path, self.filename_psfs)
        # If the file already exists, ask the user if they want to replace it
        if os.path.exists(self.filepath):
            print("File already exists.")
            # remove = input("Do you want to remove it? (y/n) ").lower()
            remove = 'y'  # Auto-remove existing file without prompt
            while remove not in ["y","n"]:
                remove = input("Do you want to remove it? (y/n) ").lower()
            if remove == "y":
                os.remove(self.filepath)
                print("File removed.")
                return False
            else:
                print("File not removed.")
                return True
        return False


    def simulate_single_psf(self,
                            wfe_coefs=[0],
                            ):
        wfe_coefs,psf_sup,psf_sub = psf_computation(self.obj,
                                                    wfe_coefs,
                                                    )
        
        return wfe_coefs,psf_sup,psf_sub

    def simulate_worst_psf(self):
        """
        Returns the PSF with all maximum coefficients.
        """
        return self.simulate_single_psf(wfe_coefs=np.array(self.wfe_budget)*1e-9,
                                 )[1:]

    def write_database_hdf5(self):
        self.file_extension = ".hdf5"
        self.filename_builder(self.file_extension)

        print("\nComputation started !")
        print('Path data : ',self.path)
        print('Filename data : ',self.filename_psfs)

        # Check if the directory exists, if not, create it
        if not os.path.exists(self.path):
            os.makedirs(self.path)
            print(f"Directory {self.path} created.")

        if not(self.existing_file()):

            psf_wo_aberration = psf_computation(self.obj,[0])[1] # second argument is the psf and first one is the weights
            psf_wo_aberration = psf_wo_aberration.astype(np.float32)
    
            # Initialize arrays to store all PSFs and weights
            all_psfs = np.zeros([self.N_psfs, self.size_psf, self.size_psf])
            all_psfs_oversamp = np.zeros([self.N_psfs, int(self.detector_oversampling*self.size_psf), int(self.detector_oversampling*self.size_psf)])
            all_weights = np.zeros([self.N_psfs,self.N_orders])

            # items = [(self.size_psf,generate_coefficients(self.wfe_budget, sec_factor=1.0),self.source) for _ in range(self.N_psfs)]
            items = [(self.obj,generate_coefficients(self.wfe_budget, sec_factor=1.0)) for _ in range(self.N_psfs)]

            if self.chromatism == "poly":
                with ThreadPoolExecutor(max_workers=cpu_count()-1) as executor:
                    futures = [executor.submit(psf_computation_parallel, item) for item in items]
                    results = [future.result() for future in tqdm(futures, total=self.N_psfs)]
                
                for i, result in enumerate(results):
                    all_weights[i], all_psfs_oversamp[i], all_psfs[i] = result
            else:
                # Your existing Pool code
                with Pool(cpu_count()-1) as pool:
                    results = list(tqdm(pool.imap(psf_computation_parallel, items), total=self.N_psfs))
                
                for i, result in enumerate(results):
                    all_weights[i], all_psfs_oversamp[i], all_psfs[i] = result

            self.spectral_types = None # To implement
            
            print("\nComputation finished !")
            print("Saving the PSFs in ",self.filepath)

            with h5py.File(self.filepath, 'w') as hf:
                # Creating metadata group
                metadata_group = hf.create_group("METADATA")

                # Instrument parameters
                for key,unit in zip(['optics_name', 'optics_version', 'optics_primary_radius', 'optics_secondary_radius'],2*['str']+2*['m']):
                    metadata_group.create_dataset(key, data=getattr(self, key))
                    metadata_group[key].attrs['unit'] = unit
    
                metadata_group.create_dataset('PSF_wo_aberration', data=psf_wo_aberration)

                metadata_group.create_dataset('size_psf', data=self.size_psf)
                metadata_group['size_psf'].attrs['unit'] = 'pixels'

                metadata_group.create_dataset('n_orders', data=self.N_orders)
                metadata_group['n_orders'].attrs['unit'] = 'Noll index'

                metadata_group.create_dataset('n_psfs', data=self.N_psfs)

                metadata_group.create_dataset('max_J', data=self.N_orders)
                metadata_group['max_J'].attrs['unit'] = 'Noll index'

                metadata_group.create_dataset('wfe_budget', data=self.wfe_budget)
                metadata_group['wfe_budget'].attrs['unit'] = 'nanometers'

                metadata_group.create_dataset('chromatism', data=self.chromatism)

                if self.chromatism == 'poly':
                    metadata_group.create_dataset('sampling_wl', data=self.sampling_wl)
                    metadata_group['sampling_wl'].attrs['unit'] = 'nanometers'

                    metadata_group.create_dataset('filter_name', data=self.filter_name)
                    metadata_group['filter_name'].attrs['unit'] = 'str'

                    metadata_group.create_dataset('temperature_star', data=self.temperature_star)
                    metadata_group['temperature_star'].attrs['unit'] = 'Kelvin'

                else:
                    # Monochromatic source case
                    metadata_group.create_dataset('wavelength', data=self.source)
                    metadata_group['wavelength'].attrs['unit'] = 'nanometers'

                # Creating data group
                data_group = hf.create_group("DATA")
                data_group.create_dataset('all_psfs_oversamp', data=all_psfs_oversamp)
                data_group.create_dataset('all_psfs', data=all_psfs)
                data_group.create_dataset('all_weights', data=all_weights)

                # if self.chromatism == 'poly':
                #     # Creating unitary group
                #     unitary_group = hf.create_group("UNITARY")
                #     unitary_group.create_dataset('sampling_wl', data=self.sampling_wl)
                #     unitary_group.create_dataset('spectral_types', data=self.spectral_types)

            print("\nDataset successfully saved !\n")
        else : 
            print("Can't write in the BDD, it already exists.")
            # exit()

# def single_noise_add(img,SNR):
#     """
#     Adds random noise to a single image resulting in a required SNR.
#     """
#     # Calculate the signal power
#     signal_power = np.sqrt(np.sum(img**2))
#     # Calculate the noise power
#     noise_power = signal_power/SNR
#     # Generate Gaussian noise
#     noise = np.random.normal(
#         scale=noise_power, size=img.shape)
#     # Add the noise to the image
#     noisy_img = img + noise

#     return(noisy_img)

# def get_noisy_psfs(psfs,SNR):
#     """
#     Adds random noise to each image resulting in a required SNR.
#     """
#     noisy_psfs = np.zeros(psfs.shape)
#     for i in range(psfs.shape[0]):
#         noisy_psfs[i] = single_noise_add(psfs[i],SNR)
#     return(noisy_psfs)
            
def get_noisy_psfs(psfs, SNR):
    """
    Adds random noise to each image to achieve a required Signal-to-Noise Ratio (SNR).

    Parameters
    ----------
    psfs : numpy.ndarray
        Array containing the Point Spread Function (PSF) images.
    SNR : float
        Desired Signal-to-Noise Ratio (SNR) for the noisy PSFs.

    Returns
    -------
    numpy.ndarray
        Array containing the noisy PSFs.
    """
    # Calculate the signal power for all images
    signal_power = np.sqrt(np.sum(psfs**2, axis=(1, 2), keepdims=True))
    # Calculate the noise power for all images
    noise_power = signal_power / SNR
    # Generate Gaussian noise for all images
    noise = np.random.normal(scale=noise_power, size=psfs.shape)
    # Add the noise to the images
    noisy_psfs = psfs + noise

    return noisy_psfs


def sym_to_abs(weights, minJ=1):
    """
    Converts even radial order coefficients to positive when negative.

    Parameters
    ----------
    weights : numpy.ndarray
        Array containing the Zernike coefficients.
    minJ : int, optional
        Minimum radial order. Defaults to 1.

    Returns
    -------
    numpy.ndarray
        Array containing the Zernike coefficients with positive even radial orders.
    """
    weights_abs = np.copy(weights)
    for i in range(weights.shape[0]):
        for j in range(weights.shape[1]):  
            if j+minJ in Symmetrical_orders_indexes : 
                weights_abs[i,j] = np.abs(weights[i,j])
    return weights_abs

class PSF_Reader:
    """
    Class for reading PSFs from a file.

    Attributes
    ----------
    filename_psfs : str
        Name of the file containing PSFs.
    oversampled : bool
        Whether the PSFs are oversampled.
    scale : float
        Scale factor for the PSFs.
    """
    def __init__(self, filename_psfs, oversampled=False, scale=1):
        """
        Initializes a PSF_Reader object.

        Parameters
        ----------
        filename_psfs : str
            Name of the file containing PSFs.
        oversampled : bool, optional
            Whether the PSFs are oversampled. Defaults to False.
        scale : float, optional
            Scale factor for the PSFs. Defaults to 1.
        """
        self.filename_psfs = filename_psfs
        self.optics_name, self.optics_version = get_opticsname_version(filename_psfs)
        self.filepath = os.path.join(get_path_data(self.optics_name, self.optics_version), filename_psfs)

        self.oversampled = oversampled
        self.scale = scale

        if not os.path.exists(self.filepath):
            raise FileNotFoundError(f"File not found: {self.filepath}")

        self.load_metadata()

    def load_metadata(self):
        """
        Loads metadata from the file.
        """
        self.min_J = 1
        with h5py.File(self.filepath, 'r') as file:
            metadata_group = file['METADATA']
            for key in metadata_group.keys():
                setattr(self, key, metadata_group[key][()])
            if self.chromatism == 'poly':
                self.sampling_wl = metadata_group['sampling_wl'][()]
            else:
                self.source = metadata_group['wavelength'][()]

    def get_psfs_weights(self):
        """
        Retrieves PSFs and weights from the file.

        Returns
        -------
        tuple
            Tuple containing PSFs and weights.
        """
        print('Retrieving the psfs and weights.')
        file = h5py.File(self.filepath, 'r')
        step = int(1/self.scale) # To extract only a part of the database respecting the scale.
        if self.oversampled : 
            psfs_dataset,weights_dataset = file['DATA']['all_psfs_oversamp'][()],file['DATA']['all_weights'][()]
        else : 
            psfs_dataset,weights_dataset = file['DATA']['all_psfs'][()],file['DATA']['all_weights'][()]
        psfs = psfs_dataset[::step]
        weights = weights_dataset[::step]

        if file.__bool__():
            file.close()
        return psfs,weights

    def normalization(self, X, X_noisy, Y, Y_abs, norm_psf='min_max', norm_weights='max'):
        """
        Normalize the data with different methods and return normalized PSFs and weights.
        By default it is min-max normalization for psfs and max for weights.
        The normalization is saved in a dictionary for later use.

        Parameters
        ----------
        X : numpy.ndarray
            Original PSFs.
        X_noisy : numpy.ndarray
            Noisy PSFs.
        Y : numpy.ndarray
            Original weights.
        Y_abs : numpy.ndarray
            Absolute weights.
        norm_psf : str, optional
            Normalization method for PSFs. Defaults to 'min_max'.
        norm_weights : str, optional
            Normalization method for weights. Defaults to 'max'.

        Returns
        -------
        list
            List containing normalized PSFs and weights.
        """
        self.norm_psf = norm_psf ; self.norm_weights = norm_weights
        output = [] ; self.dict_min_max_mean_std = {}
        for count,type,data,label in zip(range(4),[norm_psf,norm_psf,norm_weights,norm_weights],[X,X_noisy,Y,Y_abs],['X','X_noisy','Y','Y_abs']):
            normalized_data = np.zeros(data.shape)
            if type == 'none':
                normalized_data = data
            elif type == 'max':
                normalized_data = data/data.max() if count == 0 else data*1e9/max(self.wfe_budget)
            elif type == 'min_max':
                normalized_data = (data - data.min()) / (data.max() - data.min())
            elif type == 'mean':
                normalized_data = data - data.mean()
            elif type == 'z_score':
                normalized_data = (data - data.mean()) / data.std()
            # Create a dictionnary containing a dictionnary for each array to save min max mean and std for each array to use later to denormalize the data.
            self.dict_min_max_mean_std[label] = {'min':data.min(),'max':data.max(),'mean':data.mean(),'std':data.std()}
            output.append(normalized_data)
        # self.modif_psfs, self.modif_weights = output
        return(output)
    
    def preprocess(self, noise=None):
        """
        Preprocesses the data by resizing the images and normalizing them.

        Parameters
        ----------
        noise : int, optional
            SNR value for the noisy data.

        Returns
        -------
        tuple
            Tuple containing preprocessed PSFs and weights.
        """
        print("\n\nBeginning preprocessing...")
        psfs, weights = self.get_psfs_weights()
        weights = weights[:, 1:]  # We remove the first column which is the piston

        if noise is not None:
            print(f"Adding noise with SNR = {noise} dB to the PSFs.")
            psfs_noisy = self.noisy_data(psfs, SNR=noise)
        else:
            psfs_noisy = np.zeros(psfs.shape)

        # Convert to absolute values the coefficients of Zernike Polynomials with ambiguous orders
        weights_abs = sym_to_abs(weights)

        X_N, X_noisy_N, Y_N, Y_abs_N = self.normalization(psfs, psfs_noisy, weights, weights_abs,
                                                           norm_psf='min_max', norm_weights='max')

        print('Preprocessing done !')
        return X_N, X_noisy_N, Y_N, Y_abs_N


    def noisy_data(self, X, SNR=5):
        """
        Adds random noise to the PSFs.

        Parameters
        ----------
        X : numpy.ndarray
            Array containing the PSFs.
        SNR : float, optional
            Signal-to-Noise Ratio (SNR) for the noisy PSFs. Defaults to 5.

        Returns
        -------
        numpy.ndarray
            Array containing the noisy PSFs.
        """
        X_noisy = get_noisy_psfs(X,SNR)
        return X_noisy
    
    def get_psf(self, index):
        """
        Returns the PSF at the given index.

        Parameters
        ----------
        index : int
            Index of the PSF.

        Returns
        -------
        numpy.ndarray
            PSF at the given index.
        """
        return self.all_psfs[index]

    def get_weight(self, index):
        """
        Returns the weight at the given index.

        Parameters
        ----------
        index : int
            Index of the weight.

        Returns
        -------
        numpy.ndarray
            Weight at the given index.
        """
        return self.all_weights[index]

############################### DISPLAY_UTILS ###############################

from poppy.utils import imshow_with_mouseover, measure_centroid
from matplotlib import colors
def plot_psf(image):
    """
    Plots a Point Spread Function (PSF) image.

    Parameters
    ----------
    image : numpy.ndarray
        Array containing the PSF image.
    """
    plt.figure(figsize=(10,10))
    plt.imshow(image, norm=colors.LogNorm(), cmap='jet')
    plt.colorbar(fraction=0.046, pad=0.04)
    plt.show()

def imshow_comparison(X, *kwargs, titles=[], n=6, random=False):
    """
    Compares multiple datasets of Point Spread Functions (PSFs) by plotting images.

    Parameters
    ----------
    X : numpy.ndarray
        Original PSFs.
    *kwargs : list of numpy.ndarray
        Additional datasets of PSFs to compare.
    titles : list of str
        List of titles for each dataset.
    n : int, optional
        Number of PSFs to compare per dataset. Defaults to 6.
    random : bool, optional
        Whether to select PSFs randomly. Defaults to False.
    """
    list_kwargs = [X] + [e for e in kwargs]
    if len(titles)!=len(list_kwargs) and len(list_kwargs)!=0:
        raise ValueError('The number of titles must be equal to the number of datasets')
    n_rows , n_cols = 1+len(kwargs) , n
    fig,axes = plt.subplots(n_rows,n_cols,figsize=(n*4,2*(1+len(kwargs))))
    # n_rows , n_cols = ( 1, axes.shape[1]) if len(kwargs) == 0 else (axes.shape[1] , axes.shape[0])
    
    for col in range(n_cols):
        for row in range(n_rows):
            try : 
                ax = axes[row,col]
            except :
                ax = axes[col]
            np.random.seed(0)
            list_indexes = [np.random.randint(0,X.shape[0]-1) for i in range(n)]
            im = ax.imshow(list_kwargs[row][list_indexes[col]] if random else list_kwargs[row][col],cmap = 'jet')
            ax.set_ylabel(titles[row] if col==0 else '')
            plt.colorbar(im,ax=ax,fraction=0.046, pad=0.04
                         )
            # ax.set_title(f'PSF {list_indexes[col]}' if random else f'PSF {col}')
    plt.suptitle('Image samples from dataset(s)')
    plt.show()

def display_psf(hdulist_or_filename, ext=0, vmin=1e-7, vmax=1e-1,
                scale='log', cmap=None, title=None, imagecrop=None,
                adjust_for_oversampling=False, normalize='None',
                crosshairs=False, markcentroid=False, colorbar=True,
                colorbar_orientation='vertical', pixelscale='PIXELSCL',
                ax=None, return_ax=False, interpolation=None, cube_slice=None,
                angular_coordinate_unit=u.arcsec) -> None:
    """Display a PSF image stored in a FITS HDUList or file.

    Renders a 2-D PSF on a linear or logarithmic colour scale with optional
    crosshairs, centroid marker, and colour bar.  Axes are labelled in angular
    units (default: arcseconds).

    Args:
        hdulist_or_filename (fits.HDUList | str): FITS object or path to a
            FITS file containing the PSF image.
        ext (int): HDU extension index to read. Defaults to ``0``.
        vmin (float): Lower colour-scale limit. Defaults to ``1e-7``.
        vmax (float): Upper colour-scale limit. Defaults to ``1e-1``.
        scale (str): Intensity scale — ``'log'`` or ``'linear'``.
            Defaults to ``'log'``.
        cmap (matplotlib.colors.Colormap | None): Colormap instance.
            ``None`` uses the library default. Defaults to ``None``.
        title (str | None): Axes title.  Defaults to ``None``.
        imagecrop (float | None): Half-width of the displayed region in
            arcseconds.  ``None`` shows the full image. Defaults to ``None``.
        adjust_for_oversampling (bool): Rescale pixel values to account for
            detector oversampling. Defaults to ``False``.
        normalize (str): Normalisation applied before display
            (``'None'``, ``'peak'``, or ``'total'``). Defaults to
            ``'None'``.
        crosshairs (bool): Draw crosshairs at the optical axis.
            Defaults to ``False``.
        markcentroid (bool): Compute and mark the PSF centroid.
            Defaults to ``False``.
        colorbar (bool): Draw a colour bar. Defaults to ``True``.
        colorbar_orientation (str): ``'vertical'`` or ``'horizontal'``.
            Defaults to ``'vertical'``.
        pixelscale (str | float): FITS header keyword or numeric value
            (arcsec/pixel) used to set axis scale. Defaults to
            ``'PIXELSCL'``.
        ax (matplotlib.axes.Axes | None): Target axes.  Creates a new
            figure when ``None``. Defaults to ``None``.
        return_ax (bool): Return the axes object after plotting.
            Defaults to ``False``.
        interpolation (str | None): Matplotlib interpolation method for
            ``imshow``. Defaults to ``None``.
        cube_slice (int | None): For PSF datacubes, the wavelength slice
            index to display. Defaults to ``None``.
        angular_coordinate_unit (astropy.units.Unit): Angular unit for the
            axis labels. Defaults to ``astropy.units.arcsec``.

    Returns:
        matplotlib.axes.Axes | None: The axes object when
            ``return_ax=True``, otherwise ``None``.

    Example:
        >>> psf = tel.calc_psf(fov_arcsec=2.0)
        >>> display_psf(psf, scale='log', title='My PSF')
    """
    if isinstance(hdulist_or_filename, str):
        hdulist = fits.open(hdulist_or_filename)
    elif isinstance(hdulist_or_filename, fits.HDUList):
        hdulist = hdulist_or_filename
    elif isinstance(hdulist_or_filename, (np.ndarray)):
        hdulist = None
    else : 
        raise ValueError("input must be a filename or FITS HDUList object")

    if hdulist is not None:
        # Get a handle on the input image
        if hdulist[ext].data.ndim == 2:
            im0 = hdulist[ext].data
            psf_array_shape = im0.shape
        elif hdulist[ext].data.ndim == 3:
            if cube_slice is None:
                raise ValueError("To display a PSF datacube, you must set cube_slice=<#>.")
            else:
                im0 = hdulist[ext].data[cube_slice]
                psf_array_shape = hdulist[ext].data.shape[1:]
        else:
            raise RuntimeError("Unsupported image dimensionality.")
        
    else : 
        im0 = hdulist_or_filename
        psf_array_shape = im0.shape

    # Normalization
    if adjust_for_oversampling:
        try:
            scalefactor = hdulist[ext].header['OVERSAMP'] ** 2
        except KeyError:
            _log.error("Could not determine oversampling scale factor; "
                       "therefore NOT rescaling fluxes.")
            scalefactor = 1
        im = im0 * scalefactor
    else:
        # don't change normalization of actual input array, work with a copy!
        im = im0.copy()

    if normalize.lower() == 'peak':
        _log.debug("Displaying image normalized to peak = 1")
        im /= im.max()
    elif normalize.lower() == 'total':
        _log.debug("Displaying image normalized to PSF total = 1")
        im /= im.sum()

    if scale == 'linear':
        norm = mpl.colors.Normalize(vmin=vmin, vmax=vmax)
    else:
        norm = mpl.colors.LogNorm(vmin=vmin, vmax=vmax)

    if hdulist is not None:
        if isinstance(pixelscale, str):
            pixelscale = hdulist[ext].header[pixelscale]
        else:
            pixelscale = float(pixelscale)
    else:
        pixelscale = 0.298 # Euclid NISP resolution by default (in arcsec/pixel)

    if angular_coordinate_unit != u.arcsec:
        coordinate_rescale = (1 * u.arcsec).to_value(angular_coordinate_unit)
        pixelscale *= coordinate_rescale
    else:
        coordinate_rescale = 1
    halffov_x = pixelscale * psf_array_shape[1] / 2.0
    halffov_y = pixelscale * psf_array_shape[0] / 2.0

    unit_label = str(angular_coordinate_unit)
    extent = [-halffov_x, halffov_x, -halffov_y, halffov_y]

    if cmap is None:
        cmap = getattr(mpl.cm, poppy.conf.cmap_sequential)
    # update and get (or create) image axes
    ax = imshow_with_mouseover(
        im,
        extent=extent,
        cmap=cmap,
        norm=norm,
        ax=ax,
        interpolation=interpolation,
        origin='lower'
    )
    ax.set_xlabel(unit_label)

    if markcentroid:
        _log.info("measuring centroid to mark on plot...")
        # ceny, cenx = measure_centroid(hdulist, ext=ext, units='arcsec', relativeto='center', boxsize=20, threshold=0.1)
        if hdulist is not None:
            pixelscale_measure,cent_of_mass = measure_centroid(hdulist, ext=ext, units='arcsec', relativeto='center', boxsize=20, threshold=0.1)
        else : 
            pixelscale_measure,cent_of_mass = measure_centroid(im, units='arcsec', relativeto='center', boxsize=20, threshold=0.1)
            
        if (pixelscale_measure == None) and (hdulist == None) :
            pass
        else : 
            cent_of_mass = tuple(np.array(cent_of_mass) * pixelscale)

        ceny, cenx = cent_of_mass

        ceny *= coordinate_rescale  # if display coordinate unit isn't arcseconds, rescale the centroid accordingly
        cenx *= coordinate_rescale
        ax.plot(cenx, ceny, 'k+', markersize=15, markeredgewidth=1)
        _log.info("centroid: (%f, %f) " % (cenx, ceny))

    if imagecrop is not None:
        halffov_x = min((imagecrop / 2.0, halffov_x))
        halffov_y = min((imagecrop / 2.0, halffov_y))
    ax.set_xbound(-halffov_x, halffov_x)
    ax.set_ybound(-halffov_y, halffov_y)
    if crosshairs:
        ax.axhline(0, ls=':', color='k')
        ax.axvline(0, ls=':', color='k')
    if title is None:
        if hdulist is not None:
            try:
                fspec = "%s, %s" % (hdulist[ext].header['INSTRUME'], hdulist[ext].header['FILTER'])
            except KeyError:
                fspec = str(hdulist_or_filename)
            title = "PSF sim for " + fspec
        else : 
            title = "PSF"
    ax.set_title(title)

    if colorbar:
        if ax.images[0].colorbar is not None:
            # Reuse existing colorbar axes (Issue #21)
            colorbar_axes = ax.images[0].colorbar.ax
            cb = plt.colorbar(
                ax.images[0],
                ax=ax,
                cax=colorbar_axes,
                orientation=colorbar_orientation,
                fraction=0.046,
                pad=0.04,
            )
        else:
            cb = plt.colorbar(
                ax.images[0],
                ax=ax,
                orientation=colorbar_orientation,
                fraction=0.046,
                pad=0.04,
            )
        if scale.lower() == 'log':
            ticks = np.logspace(np.log10(vmin), np.log10(vmax), int(np.round(np.log10(vmax / vmin) + 1)))
            if colorbar_orientation == 'horizontal' and vmax == 1e-1 and vmin == 1e-8:
                ticks = [1e-8, 1e-6, 1e-4, 1e-2, 1e-1]  # looks better
            cb.set_ticks(ticks)
            cb.set_ticklabels(ticks)
        if normalize.lower() == 'peak':
            cb.set_label('Intensity relative to peak pixel')
        else:
            cb.set_label('Fractional intensity per pixel')

    if return_ax:
        if colorbar:
            return ax, cb
        else:
            return ax
        

def display_ee(hdulist_or_filename=None, ext: int = 0, overplot: bool = False, ax=None, mark_levels: bool = True, **kwargs: object) -> None:
    """Plot the azimuthally averaged Encircled Energy (EE) curve for a PSF.

    The EE is computed via :func:`radial_profile` and plotted as a function
    of angular radius in arcseconds.  Reference lines are optionally drawn
    at EE = 50 %, 80 %, and 95 %.

    Args:
        hdulist_or_filename (fits.HDUList | str): FITS object or path to a
            FITS file containing the PSF image.
        ext (int): HDU extension index. Defaults to ``0``.
        overplot (bool): If ``True``, add the curve to the current axes
            without clearing them.  Defaults to ``False``.
        ax (matplotlib.axes.Axes | None): Target axes.  When ``None`` and
            ``overplot=False`` a new axes is created.  Defaults to ``None``.
        mark_levels (bool): Annotate the EE = 50 %, 80 %, and 95 % radii on
            the plot.  Defaults to ``True``.
        **kwargs: Extra keyword arguments forwarded to :func:`radial_profile`
            (e.g. ``center``, ``stddev``).

    Raises:
        ValueError: If ``hdulist_or_filename`` is neither a string nor an
            ``fits.HDUList``.

    Example:
        >>> psf = tel.calc_psf(fov_arcsec=3.0)
        >>> fig, ax = plt.subplots()
        >>> display_ee(psf, ax=ax, mark_levels=True)
    """
    if isinstance(hdulist_or_filename, str):
        hdu_list = fits.open(hdulist_or_filename)
    elif isinstance(hdulist_or_filename, fits.HDUList):
        hdu_list = hdulist_or_filename
    else:
        raise ValueError("input must be a filename or HDUlist")

    radius, profile, ee = radial_profile(hdu_list, ee=True, ext=ext, **kwargs)

    if not overplot:
        if ax is None:
            plt.clf()
            ax = plt.subplot(111)

    ax.plot(radius, ee)  # , nonposy='clip')
    if not overplot:
        ax.set_xlabel("Radius [arcsec]")
        ax.set_ylabel("Encircled Energy")

    if mark_levels:
        for level in [0.5, 0.8, 0.95]:
            try : # Here is the modified part, that allows to plot EE when the PSF is such that the EE90 isn't on the graph (thus np.where(ee > level) is empty)
                ee_lev = radius[np.where(ee > level)[0][0]]
                yoffset = 0 if level < 0.9 else -0.05
                ax.text(ee_lev + 0.1, level + yoffset, 'EE=%2d%% at r=%.3f"' % (level * 100, ee_lev))
            except :
                pass