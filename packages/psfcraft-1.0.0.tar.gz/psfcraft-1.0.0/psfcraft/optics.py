import poppy

import numpy as np


## Useful functions : 

def draw_circular_mask(npix, x0, y0, radius):
    """
    Draw a circle on a 2D array.

    Parameters:
    - npix (int): The size of the 2D array.
    - x0 (float): X-coordinate of the circle's center.
    - y0 (float): Y-coordinate of the circle's center.
    - radius (float): Radius of the circle.

    Returns:
    - numpy.ndarray: The 2D array with the circle drawn.
    """
    # array = np.zeros((npix, npix))  # Create a 2D array filled with zeros
    y, x = np.ogrid[:npix, :npix]
    mask = (x - x0)**2 + (y - y0)**2 <= radius**2
    return mask


class NewtonianTelescopeAperture(poppy.CompoundAnalyticOptic):
    """
    NewtonianTelescopeAperture class, representing the primary and secondary mirrors geometry of Telescopes such as Newtonian. 
    The aperture features a primary circular mirror and a secondary mirror supported by three branches. 

    This class exclusively describes the pupil geometry and the support struts for the secondary mirror. 

    Warning: High sampling factors may significantly slow down PSF calculations. 

    The default configuration assigns values 0 and 1 for transmission. 
    Setting the parameter label_segments=True generates a map indicating the segment numbers and their respective locations.
    """

    def __init__(self, optical_system_version='1',
                 primary_radius=0.5,secondary_radius=0.1,
                 *args, **kwargs):
        """
        Initialize the NewtonianTelescopeAperture.

        Parameters:
        - optical_system_version (str): The version of the optical system.
        - primary_radius (float): Radius of the primary mirror.
        - secondary_radius (float): Radius of the secondary mirror.
        """
        self.primary_radius = primary_radius
        self.secondary_radius = secondary_radius
        self.primary_diameter = 2*primary_radius  # Diameter of the primary mirror
        self.secondary_diameter = 2*secondary_radius # Diameter of the secondary mirror

        poppy.CompoundAnalyticOptic.__init__(self, self.get_optical_system(optical_system_version=optical_system_version,*args,**kwargs),
                                            name='NewtonianTelescopeAperture V'+optical_system_version)

        # Work in progress here to make the version 2 work.
        # if optical_system_version != "2" : # Thus the supplied optics list to CompoundAnalyticOptic contains AnalyticOptics only
        #     poppy.CompoundAnalyticOptic.__init__(self, self.get_optical_system(optical_system_version=optical_system_version,*args,**kwargs),
        #                                     name='NewtonianTelescopeAperture V'+optical_system_version)  
        # else : # In the version 3, we use poppy.ArrayOpticalElement which is not an AnalyticOptic
        #     self.get_optical_system(optical_system_version=optical_system_version,*args,**kwargs)
        #     self.name = 'NewtonianTelescopeAperture V'+optical_system_version

        
    def get_optical_system(self,optical_system_version = '1',*args,**kwargs):
        """
        Wrapper to return the optical system for a given version of a Newtonian Telescope aperture.

        Parameters:
        - optical_system_version (str): The version of the optical system.

        Returns:
        - list: The optical system components.
        """
        if "1_" in optical_system_version: #Thus the number after the version 
            version , N_branches = optical_system_version.split('_')
            return getattr(self, f'optical_compounds_v{version}')(int(N_branches),*args,**kwargs)
        else : 
            return getattr(self, f'optical_compounds_v{optical_system_version}')(*args,**kwargs)
    
    def optical_compounds_v0(self):
        '''
        Only circular aperture with no secondary mirror.
        '''
        first = poppy.CircularAperture(name='PrimaryMirror',radius=self.primary_radius)
        return [first]
    
    
    def optical_compounds_v1(self,N_branches = 3,branches_thickness=0.02):
        '''
        Secondary held by N_branches rectilinear supports evenly spaced.

        Parameters:
        - N_branches (int): Number of secondary mirror supports.
        - branches_thickness (float): Thickness of the supports.

        Returns:
        - list: The optical system components.
        '''
        
        first = poppy.CircularAperture(name='PrimaryMirror',radius=self.primary_radius)
        if N_branches == 0 : 
            second = poppy.SecondaryObscuration(name='SecondaryMirror',secondary_radius=self.secondary_radius,
                                                        n_supports=N_branches,
                                                        )
            return [first,second]
        else :
            second = poppy.AsymmetricSecondaryObscuration(name='SecondaryMirror',secondary_radius=self.secondary_radius,
                                                        support_angle=list(range(0,360,360//N_branches)), # counterclockwise starting from top 
                                                        support_width=N_branches*[branches_thickness],
                                                        )
            return [first,second]

    def optical_compounds_v2(self):
        '''
        Closest model, using that secondary area is 30% of primary area.
        Taking primary radius as 0.6m, then secondary radius is 0.199 m
        There is a doubt about the orientation of the secondary mirror. By default stars diffraction spikes are directed to the right with the angles attribute.
        '''
        orientation = 'right' # Used to flip the secondary mirror orientation
        angles = (15,135,255) if orientation=='left' else (360-15,360-135,360-255)
        first = poppy.CircularAperture(radius=self.primary_radius,
                                # *args, **kwargs
                                )
        second = poppy.AsymmetricSecondaryObscuration(secondary_radius=self.secondary_radius,
                                                    support_angle=(15, 255, 135), # clockwise starting from top 
                                                    support_width=3*[0.012],
                                                    # support_offset_x=[0.009, 0.042, -0.012],
                                                    support_offset_x=[0.15, 0., 0.],
                                                    support_offset_y=[0., -0.15, 0.19],
                                                    )
        return [first,second]
        # return [first, second]

    # def optical_compounds_v2(self):
    #     # Need to add a parameter 'branches_thickness'
    #     '''
    #     Secondary held by a circular support on one side.
    #     '''
    #     from astropy import units as u
    #     # Define arrays
    #     npix = 512
    #     trans = np.zeros((npix, npix))
    #     opd = np.zeros((npix, npix))

    #     pix_scale = (1.8/npix) # m/pixel and 1.8 is the default diameter of the display

    #     # from .utils import draw_circular_mask

    #     def m2pix(m):
    #         return int(m/pix_scale)

    #     x_center = y_center = npix // 2
    #     width_support = 0.05
    #     r3 = (self.primary_radius - self.secondary_radius)/2

    #     mask1 = draw_circular_mask(npix, x0= x_center, y0= y_center, radius=m2pix(self.primary_radius))
    #     mask2 = draw_circular_mask(npix, x0= x_center, y0= y_center - m2pix(self.secondary_radius)-m2pix(r3), radius=m2pix(r3))
    #     mask3 = draw_circular_mask(npix, x0= x_center, y0= y_center - m2pix(self.secondary_radius)-m2pix(r3), radius=m2pix(r3)-m2pix(width_support))
    #     mask4 = draw_circular_mask(npix, x0= x_center, y0= y_center, radius=m2pix(self.secondary_radius))

    #     trans = np.zeros((npix, npix))

    #     final_mask = (~mask2 & mask1 | mask3) & ~mask4
    #     trans[final_mask] = 1  # Set annulus pixels to 1 or any desired value

    #     # Create an optic using those arrays
    #     complex_optic = poppy.ArrayOpticalElement(transmission=trans,
    #                                             opd=opd,
    #                                             name='Circular Curved Spider',
    #                                             pixelscale = pix_scale*u.m/u.pixel
    #                                             )
    #     return complex_optic
    
    def optical_compounds_v3(self,branches_thickness=0.02):
        '''
        4 branches spider.

        Parameters:
        - branches_thickness (float): Thickness of the supports.

        Returns:
        - list: The optical system components.
        '''
        N_branches = 4
        first = poppy.CircularAperture(name='PrimaryMirror',radius=self.primary_radius)
        second = poppy.AsymmetricSecondaryObscuration(name='SecondaryMirror',secondary_radius=self.secondary_radius,
                                                    support_angle=list(range(0,360,360//N_branches)), # counterclockwise starting from top 
                                                    support_width=N_branches*[branches_thickness],
                                                    )
        return [first,second]

    
    # def optical_compounds_v4(self):
    #     '''
    #     4 branches spider with secondary held by curved supports.
    #     '''
    #     first = poppy.CircularAperture(name='PrimaryMirror',radius=self.primary_radius)
    #     second = poppy.AsymmetricSecondaryObscuration(name='SecondaryMirror',secondary_radius=self.secondary_radius,
    #                                                 support_angle=[0,90,180,270], # counterclockwise starting from top 
    #                                                 support_width=[0.018, 0.018, 0.018, 0.018],
    #                                                 support_offset_x=[0.009, 0.042, -0.012, 0],
    #                                                 )
    #     return [first,second]
    
    def optical_compounds_v5(self,branches_thickness=0.02):
        '''
        4 branches spider with shifted branches tangent to secondary mirror.

        Parameters:
        - branches_thickness (float): Thickness of the supports.

        Returns:
        - list: The optical system components.
        '''
        first = poppy.CircularAperture(name='PrimaryMirror',radius=self.primary_radius)
        second = poppy.AsymmetricSecondaryObscuration(name='SecondaryMirror',secondary_radius=self.secondary_radius,
                                                    support_angle=[0,90,180,270], # counterclockwise starting from top
                                                    support_width=4*[branches_thickness],
                                                    support_offset_x=[self.secondary_radius, 0, -self.secondary_radius, 0],
                                                    support_offset_y=[0, self.secondary_radius, 0, -self.secondary_radius],
                                                    # Considering the thickness of the branches, the offset is not exactly the radius
                                                    # support_offset_x=[self.secondary_radius-branches_thickness/2, 0, -self.secondary_radius+branches_thickness/2, 0],
                                                    # support_offset_y=[0, self.secondary_radius-branches_thickness/2, 0, -self.secondary_radius+branches_thickness/2],
                                                    )
        return [first,second]
    
    
    def optical_compounds_v6(self,branches_thickness=0.02):
        '''
        8 branches spider with shifted branches joining the secondary mirror in 4 distincts and equally spaced points (star shape).

        Parameters:
        - branches_thickness (float): Thickness of the supports.

        Returns:
        - list: The optical system components.
        '''
        first = poppy.CircularAperture(name='PrimaryMirror',radius=self.primary_radius)
        alpha = np.rad2deg(np.arctan(1/(np.sqrt(2)*self.primary_radius/self.secondary_radius-1)))
        delta = self.secondary_radius/np.sqrt(2)
        angles = [90*(i//2)+alpha if i%2==0 else 90*(i//2)-alpha for i in range(8)]
        offsets_x = [delta,-delta,-delta,-delta,-delta, delta, delta, delta]
        offsets_y = [delta, delta, delta,-delta,-delta,-delta,-delta, delta]
        second = poppy.AsymmetricSecondaryObscuration(name='SecondaryMirror',secondary_radius=self.secondary_radius,
                                                    support_angle=angles, # clockwise starting from top 
                                                    support_width=8*[branches_thickness],
                                                    support_offset_x=offsets_x,
                                                    support_offset_y=offsets_y,
                                                    )
        return [first,second]