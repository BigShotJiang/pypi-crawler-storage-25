
from astropy import units as u
import matplotlib.pyplot as plt

# General parameters
# Could fill this with a config file or with another python package 

############################## TELESCOPE AND INSTRUMENTS PARAMETERS ##############################################
# Telescope parameters
TELESCOPE_FOCAL_LENGTH = 24.5 # meters
DIAMETER_PRIMARY_MIRROR = 1.2 # meters
# Based on the following information :
# Secondary mirror area is 11% of primary mirror area, 
# which means that  
# A2 = 0.11*A1 = pi*(D1/2)^2 = 0.11*pi*(1.2/2)^2 = 0.11*0.18^2 = 0.0031 m^2
# Thus D2 = 2*sqrt(A2/pi) = 0.398 m
DIAMETER_SECONDARY_MIRROR = 0.398 # meters
f_number = TELESCOPE_FOCAL_LENGTH/DIAMETER_PRIMARY_MIRROR

# NISP optical parameters
FILTER_Y_CUTS = [950, 1212] #nm
FILTER_J_CUTS = [1168, 1567] #nm
FILTER_H_CUTS = [1522, 2021] #nm

GRISM_BGS_CUTS_WO = [880,1366] #nm, FWHM without dichroic
GRISM_BGS_CUTS = [926,1366] #nm, FWHM with dichroic
GRISM_RGS_CUTS = [1206,1892] #nm

# Detector parameters : 
DETECTOR_SIZE = 2048 # pixels
# subject to temperature on flight
DETECTOR_PIXEL_SIZE = 17.98 # microns
DETECTOR_PIXEL_SCALE = 0.298 # arcsec/pixel

############################## STELLAR TYPES PARAMETERS ##############################################
STELLAR_SPECTRAL_TYPES = ['O','B','A','F','G','K','M']
STELLAR_TEMPERATURES_MEAN = [40000,15000,8200,6600,5800,4300,3300] # In Kelvin
STELLAR_TEMPERATURES_STD = [i/20 for i in STELLAR_TEMPERATURES_MEAN] # In Kelvin
STELLAR_TEMPERATURES_BOUNDS = [[30000,50000],[10000,30000],[7500,10000],[6000,7500],[5200,6000],[3700,5200],[2400,3700]] # In Kelvin
STELLAR_EMISSION_LINES = ['Weak','Medium','Strong','Medium','Weak','Very Weak','Very Weak'] # Emission lines are defined as 'Strong', 'Medium', 'Weak' or Vey weak
STELLAR_AVERAGE_RADII = [16,7,3.5,2.1,1.2,0.8,0.4]
STELLAR_FRACTION_MAIN_SEQUENCE = [0.00003,0.13,0.6,3.,7.6,12.1,76.5] # From wikipedia (picture)
STELLAR_PARAMETERS_SIGMA = [] # Objective here would be to make the temperature and fraction vary by a term sigma (to be defined)
# Colors for plotting purposes
# STELLAR_COLORS = ['blue','cyan','green','yellow','orange','red','purple']
STELLAR_COLORS = plt.cm.get_cmap('RdYlBu_r', 7)([0,1,2,3,4,5,6])

STELLAR_PARAMETERS = {
    'spectral_types': STELLAR_SPECTRAL_TYPES,
    'average_temperatures': STELLAR_TEMPERATURES_MEAN,
    'standarddeviation_temperatures': STELLAR_TEMPERATURES_STD,
    'temperature_bounds': STELLAR_TEMPERATURES_BOUNDS,
    'emission_lines': STELLAR_EMISSION_LINES,
    'average_radii': STELLAR_AVERAGE_RADII,
    'fraction_main_sequence': STELLAR_FRACTION_MAIN_SEQUENCE
}


# PSF parameters
PSF_FWHM = 0.3 # arcsec
import numpy as np
PSF_SIGMA = PSF_FWHM/(2*np.sqrt(2*np.log(2))) # arcsec
PSF_SIGMA_PIXELS = PSF_SIGMA/DETECTOR_PIXEL_SCALE # pixels