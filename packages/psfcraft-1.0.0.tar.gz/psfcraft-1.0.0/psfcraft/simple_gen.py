
from psfcraft.utils import PSF_Generator

# # Allows to compute simulations on a single thread per CPU
# import os
# os.environ['OMP_NUM_THREADS'] = '1'

OPTICS_NAME_DEFAULT = 'NewtonianTelescope'
OPTICS_VERSION_DEFAULT = '1_5'
OPTICS_PRIMARY_RADIUS = 0.5
OPTICS_SECONDARY_RADIUS = 0.1

SIZE_PSF = 32
N_PSFS = int(1e4)
WFE_BUDGET = [0, 100,100, 50,50,50, 36,36,36,36, 18,18,18,18,18, 9,9,9,9,9,9, 5,5,5,5,5,5,5]

SOURCE_DEFAULT = 2e-7
CHROMATISM = 'mono'

FILTER_DEFAULT = None
SAMPLING_WL_DEFAULT = None

if __name__=="__main__":

    psf_gen = PSF_Generator(optics_name = OPTICS_NAME_DEFAULT,
                optics_version = OPTICS_VERSION_DEFAULT,
                optics_primary_radius = OPTICS_PRIMARY_RADIUS,
                optics_secondary_radius = OPTICS_SECONDARY_RADIUS,

                size_psf = SIZE_PSF,
                N_psfs = N_PSFS,
                wfe_budget = WFE_BUDGET,
                
                source = SOURCE_DEFAULT, 
                chromatism = CHROMATISM,

                filter = FILTER_DEFAULT, 
                sampling_wl = SAMPLING_WL_DEFAULT 
                )
    
    psf_gen.optical_system_initiator()
    psf_gen.write_database_hdf5()