
import poppy

import numpy as np

from collections import OrderedDict

import logging
_log = logging.getLogger('psfcraft')

poppy.conf.use_multiprocessing = True
poppy.conf.use_fftw = False

try:
    import synphot
    _HAS_SYNPHOT = True
except ImportError:
    synphot = None
    _HAS_SYNPHOT = False


class GenericTelescope(poppy.instrument.Instrument):
    name = "GenericTelescope"
    version = None

    pupil = None
    pupilopd = None

    options = {}
    filter_list = None
    pixelscale = 0.298

    wfe_coefficients = None


    def __init__(self, name=name, version=version,
                 primary_radius=None,secondary_radius=None,
                 detector_oversample=None,
                 *args, **kwargs,
                 ):
        # super().__init__(name=name, version=version,  
        #                  primary_radius=primary_radius,secondary_radius=secondary_radius,
        #                  *args, **kwargs) 

        self.name = name
        self.version = version

        self.primary_radius = primary_radius
        self.secondary_radius = secondary_radius

        self._image_mask = None
        self._pupil_mask = None

        self.pupil = None
        self.pupilopd = None  # This can optionally be set to a tuple indicating (filename, slice in datacube)

        self.pupil_radius = None  # Set when loading FITS file in _get_optical_system

        self.options = {}  # dict for storing other arbitrary options.

        # filter_list   available filter names in order by wavelength for public api
        # _filters      a dict of named tuples with name, filename, & default_nlambda with the filter name as the key
        # self.filter_list, self._filters = self._get_filter_list()
        self.filter_list, self._filters = self._get_filter_list()
        
        # choose a default filter, in case the user doesn't specify one
        self.filter = self.filter_list[0]

        self._rotation = None

        self._image_mask = None
        self.image_mask_list = []
        "List of available image_masks"

        self._pupil_mask = None
        self.pupil_mask_list = []
        "List of available pupil_masks"

        self.wfe_coefficients = None
        "List of WFE coefficients"

        self.pixelscale = None
        "Detector pixel scale, in arcsec/pixel"
        self._spectra_cache = {}  # for caching synphot results.

        # n.b. subclasses must set these
        self._detectors = {}
        self._detector = None
        # self._detector_npixels = 2048

        self.detector_oversample = detector_oversample

        ###############

    def __str__(self):
        return "<{name}: V{version}>".format(name=self.name, version=self.version)
    
    def _get_telescope_pupil(self):
        """ Return the telescope pupil, as an OpticalElement """
        return self.pupil
    
    def _get_telescope_aberrations(self):
        """ return OpticalElement modeling wavefront aberrations for a given instrument,
        based on Zernike Polynomials description of the WF.
        """
        if self.wfe_coefficients is not None and sum(self.wfe_coefficients )!=0: 
            return poppy.ZernikeWFE(radius=self.primary_radius, coefficients=self.wfe_coefficients)
        else : 
            return None
            # raise ValueError("No WFE coefficients provided for this instrument.")
        

    def _get_optical_system(self, fft_oversample=2, detector_oversample=None,
                            fov_arcsec=None, fov_pixels=None, options=None):
        """ Return an OpticalSystem instance corresponding to the instrument as currently configured.

        When creating such an OpticalSystem, you must specify the parameters needed to define the
        desired sampling, specifically the oversampling and field of view.

        Parameters
        ----------

        fft_oversample : int
            Oversampling factor for intermediate plane calculations. Default is 2
        detector_oversample: int, optional
            By default the detector oversampling is equal to the intermediate calculation oversampling.
            If you wish to use a different value for the detector, set this parameter.
            Note that if you just want images at detector pixel resolution you will achieve higher fidelity
            by still using some oversampling (i.e. *not* setting `oversample_detector=1`) and instead rebinning
            down the oversampled data.
        fov_pixels : float
            Field of view in pixels. Overrides fov_arcsec if both set.
        fov_arcsec : float
            Field of view, in arcseconds. Default is 2


        Returns
        -------
        osys : poppy.OpticalSystem
            an optical system instance representing the desired configuration.

        """

        _log.info("Creating optical system model:")

        self._extra_keywords = OrderedDict()  # Place to save info we later want to put
                                              # into the FITS header for each PSF.

        if options is None: options = self.options
        # print(detector_oversample)
        # detector_oversample = self.detector_oversample
        if detector_oversample is None: detector_oversample = fft_oversample

        _log.debug("Oversample: %d  %d " % (fft_oversample, detector_oversample))
        optsys = poppy.OpticalSystem(
            name='{telescope}+{version}'.format(telescope=self.name, version=self.version),
            oversample=fft_oversample
        )
        # For convenience offsets can be given in cartesian or radial coords
        if 'source_offset_x' in options or 'source_offset_y' in options:
            offx = options.get('source_offset_x', 0)
            offy = options.get('source_offset_y', 0)
            optsys.source_offset_r = np.sqrt(offx ** 2 + offy ** 2)
            optsys.source_offset_theta = np.rad2deg(np.arctan2(-offx, offy))
            _log.debug("Source offset from X,Y = ({}, {}) is (r,theta) = {},{}".format(
                offx, offy, optsys.source_offset_r, optsys.source_offset_theta))
        if 'source_offset_r' in options:
            optsys.source_offset_r = options['source_offset_r']
        if 'source_offset_theta' in options:
            optsys.source_offset_theta = options['source_offset_theta']

        # ---- Add the telescope pupil
        _log.debug("Adding the telescope pupil.")
        pupil_optic = self._get_telescope_pupil()
        optsys.add_pupil(pupil_optic)

        # ---- Add the telescope aberrations
        if self.wfe_coefficients is not None and sum(self.wfe_coefficients )!=0:
            _log.debug("Adding the telescope aberrations.")
            tel_abberations = self._get_telescope_aberrations()
            optsys.add_pupil(tel_abberations)

        if hasattr(pupil_optic, 'header_keywords'):
            self._extra_keywords.update(pupil_optic.header_keywords())

        # add coord transform from entrance pupil to exit pupil
        optsys.add_inversion(axis='y', name='OTE exit pupil', hide=True)

        # add rotation at this point, if present - needs to be after the exit pupil inversion.
        # Sign convention: Here we are rotating the *wavefront* so the sign is opposite the _rotation attribute,
        # print(self._rotation)
        if self._rotation is not None:
            optsys.add_rotation(-self._rotation, hide=True)
            optsys.planes[-1].wavefront_display_hint = 'intensity'

        # --- add the detector element.
        if fov_pixels is None:
            if not np.isscalar(fov_arcsec): fov_arcsec = np.asarray(fov_arcsec)  # cast to ndarray if 2D
            fov_pixels = np.round(fov_arcsec / self.pixelscale)
            if 'parity' in options:
                if options['parity'].lower() == 'odd' and np.remainder(fov_pixels, 2) == 0: fov_pixels += 1
                if options['parity'].lower() == 'even' and np.remainder(fov_pixels, 2) == 1: fov_pixels += 1
        else:
            pass

        optsys.add_detector(self.pixelscale, fov_pixels=fov_pixels,
                            oversample=detector_oversample,
                            name=self.name + " detector")

        return optsys
    
    # def _get_synphot_bandpass(self, filtername):
    #     """ Return a synphot.spectrum.SpectralElement object for the given desired band.

    #     By subclassing this, you can define whatever custom bandpasses are appropriate for your instrument

    #     Parameters
    #     ----------
    #     filtername : str
    #         String name of the filter that you are interested in

    #     Returns
    #     --------
    #     a synphot.spectrum.ObservationSpectralElement object for that filter.

    #     """
    #     if not _HAS_SYNPHOT:
    #         raise RuntimeError("synphot not found")

    #     bpname = self._synphot_bandpasses[filtername]

    #     try:
    #         band = synphot.spectrum.SpectralElement.from_filter(bpname)
    #     except Exception:
    #         raise LookupError("Don't know how to compute bandpass for a filter named " + bpname)

    #     return band
    
    def _addAdditionalOptics(self, optsys, oversample=2):
        """Add instrument-internal optics to an optical system, typically photographic or
        spectrographic in nature. This method must be provided by derived instrument classes.
        """
        raise NotImplementedError("needs to be subclassed.")

class NewtonianTelescope(GenericTelescope):
    name = "NewtonianTelescope"
    version = "1"

    primary_radius = 0.5
    # primary_radius = 1
    secondary_radius = primary_radius / 5
    # secondary_radius = 11e-2

    wfe_coefficients = [0.]

    detector_oversample = 6

    def __init__(self, 
                 name=name, version=version, 
                 primary_radius=primary_radius,secondary_radius=secondary_radius,
                 detector_oversample = detector_oversample,
                 wfe_coefficients=wfe_coefficients,
                 *args, **kwargs
                 ):
        
        super().__init__(name=name, version=version,  
                         primary_radius=primary_radius,secondary_radius=secondary_radius,
                         detector_oversample = detector_oversample,
                        #  fov_arcsec = 12,
                         *args, **kwargs) 
        
        self.name = name 
        self.version = version

        self.primary_radius = primary_radius
        self.secondary_radius = secondary_radius

        # self.pixelscale = 0.05 # arcsec/pixel
        self.pixelscale = 0.298 # arcsec/pixel
        # self.pixelscale = 2/32 # arcsec/pixel for a 2 arcsec fov

        self.wfe_coefficients = wfe_coefficients

        from .optics import NewtonianTelescopeAperture
        self.pupil = NewtonianTelescopeAperture(optical_system_version=version,
                                                primary_radius=primary_radius,secondary_radius=secondary_radius
                                                )
        self.pupil_radius = self.pupil.primary_radius # or primary_radius

        self.options['pupil_shift_x'] = 0.
        self.options['pupil_shift_y'] = 0.

        # self._detector_npixels = detector_npixels
        # self.detector_position = (int(self._detector_npixels//2), int(self._detector_npixels//2))

    def _get_default_fov(self):
        """ Return default FOV in arcseconds """
        # return self.pixelscale*16 # default for all versions
        return self.pixelscale*32 # default for all versions
        # return self.pixelscale*128 # default for all versions

    def _validate_config(self, **kwargs):
        """
        Validate instrument config for NIP
        """
        return super(NewtonianTelescope, self)._validate_config(**kwargs)
    

    def _get_optical_system(self, fft_oversample=2, detector_oversample=None,
                            fov_arcsec=None, fov_pixels=None, options=None, **kwargs):
        """
        Override to force detector oversampling
        """
        # Force detector_oversample to our stored value
        if detector_oversample is None:
            detector_oversample = self.detector_oversample
            
        # Force fov_arcsec if not provided
        if fov_arcsec is None:
            fov_arcsec = self._get_default_fov()
            
        return super()._get_optical_system(
            fft_oversample=fft_oversample,
            detector_oversample=detector_oversample,
            fov_arcsec=fov_arcsec,
            fov_pixels=fov_pixels,
            options=options,
            **kwargs
        )