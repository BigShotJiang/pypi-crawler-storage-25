"""Tests for psfcraft.optics — aperture geometry and mask utilities.

Covers:
- draw_circular_mask     pure NumPy geometry, fully deterministic
- NewtonianTelescopeAperture  instantiation + version dispatch (no FFT)
"""
import numpy as np
import pytest

from psfcraft.optics import draw_circular_mask, NewtonianTelescopeAperture


# ── draw_circular_mask ────────────────────────────────────────────────────────

def test_circular_mask_shape():
    mask = draw_circular_mask(64, x0=32, y0=32, radius=10)
    assert mask.shape == (64, 64)


def test_circular_mask_dtype_bool():
    mask = draw_circular_mask(32, x0=16, y0=16, radius=5)
    assert mask.dtype == bool


def test_circular_mask_center_included():
    mask = draw_circular_mask(32, x0=16, y0=16, radius=5)
    assert mask[16, 16], "Center pixel should be inside the mask"


def test_circular_mask_corner_excluded():
    mask = draw_circular_mask(32, x0=16, y0=16, radius=5)
    assert not mask[0, 0], "Corner pixel should be outside the mask"


def test_circular_mask_area_approximates_pi_r2():
    """For a circle of radius r in an n×n grid, area ≈ π r²."""
    r = 20
    n = 128
    mask = draw_circular_mask(n, x0=n // 2, y0=n // 2, radius=r)
    area = mask.sum()
    expected = np.pi * r ** 2
    assert abs(area - expected) / expected < 0.02, (
        f"Mask area {area} deviates > 2% from π r² = {expected:.1f}"
    )


def test_circular_mask_zero_radius_is_single_pixel():
    """Radius = 0 should include only the center pixel."""
    mask = draw_circular_mask(32, x0=16, y0=16, radius=0)
    assert mask.sum() == 1


def test_circular_mask_off_center():
    """Moving center should shift the mask accordingly."""
    mask_c = draw_circular_mask(64, x0=32, y0=32, radius=8)
    mask_s = draw_circular_mask(64, x0=48, y0=48, radius=8)
    # Overlapping region should not be identical
    assert not np.array_equal(mask_c, mask_s)


# ── NewtonianTelescopeAperture ────────────────────────────────────────────────

@pytest.mark.parametrize("version", ["0", "1", "2", "3"])
def test_aperture_instantiates_without_error(version):
    """All standard aperture versions must instantiate without raising."""
    nt = NewtonianTelescopeAperture(
        optical_system_version=version,
        primary_radius=0.5,
        secondary_radius=0.1,
    )
    assert nt is not None


def test_aperture_stores_radii():
    nt = NewtonianTelescopeAperture(
        optical_system_version="1",
        primary_radius=0.6,
        secondary_radius=0.15,
    )
    assert nt.primary_radius == 0.6
    assert nt.secondary_radius == 0.15


def test_aperture_diameter_is_twice_radius():
    nt = NewtonianTelescopeAperture(
        optical_system_version="1",
        primary_radius=0.5,
        secondary_radius=0.1,
    )
    assert nt.primary_diameter == pytest.approx(2 * nt.primary_radius)
    assert nt.secondary_diameter == pytest.approx(2 * nt.secondary_radius)


def test_aperture_name_contains_version():
    nt = NewtonianTelescopeAperture(
        optical_system_version="2",
        primary_radius=0.5,
        secondary_radius=0.1,
    )
    assert "2" in nt.name


def test_aperture_v0_has_no_secondary_obstruction():
    """Version 0 is a plain circular aperture — optical_compounds_v0 returns 1 element."""
    nt = NewtonianTelescopeAperture(
        optical_system_version="0",
        primary_radius=0.5,
        secondary_radius=0.1,
    )
    components = nt.optical_compounds_v0()
    assert len(components) == 1


def test_aperture_v1_returns_two_components():
    """Version 1 has primary + secondary obstruction → 2 elements."""
    nt = NewtonianTelescopeAperture(
        optical_system_version="1",
        primary_radius=0.5,
        secondary_radius=0.1,
    )
    components = nt.optical_compounds_v1()
    assert len(components) == 2


def test_aperture_v1_with_branch_suffix_instantiates():
    """Version '1_3' means 3-branch spider — dispatch must work."""
    nt = NewtonianTelescopeAperture(
        optical_system_version="1_3",
        primary_radius=0.5,
        secondary_radius=0.1,
    )
    assert nt is not None


def test_aperture_v6_spider_angles_count():
    """Version 6 has 8-branch spider — internal angle list must have 8 entries."""
    nt = NewtonianTelescopeAperture(
        optical_system_version="1",  # instantiate cheaply
        primary_radius=0.5,
        secondary_radius=0.1,
    )
    components_v6 = nt.optical_compounds_v6()
    secondary = components_v6[1]
    assert len(secondary.support_angle) == 8
