"""Tests for pure utility functions in psfcraft.utils.

Covers:
- build_wfe_budget          pure, well-defined math
- get_filter_bounds         simple dispatch
- _planck_law               physics law, exact values
- build_polychromatic_star  dict contract + physical validity
- generate_coefficients     shape, dtype, bounds
- get_path_data / get_path_model  path composition
- get_opticsname_version    string parsing
- PSF_Generator.filename_builder  filename contract
"""
import os

import numpy as np
import pytest

from psfcraft.utils import (
    build_wfe_budget,
    build_polychromatic_star,
    generate_coefficients,
    get_filter_bounds,
    get_opticsname_version,
    get_path_data,
    get_path_model,
    _planck_law,
)


# ── build_wfe_budget ──────────────────────────────────────────────────────────

def test_build_wfe_budget_length():
    # [0, a, b, c] covers orders 0–3 → 1+2+3+4 = 10 modes
    result = build_wfe_budget([0, 100, 50, 36])
    assert len(result) == 10


def test_build_wfe_budget_single_order():
    # Order 0 only → piston repeated once
    result = build_wfe_budget([0])
    assert result == [0]


def test_build_wfe_budget_two_orders():
    # [a, b] → [a, b, b]
    result = build_wfe_budget([5, 10])
    assert result == [5, 10, 10]


def test_build_wfe_budget_docstring_example():
    # Example from the docstring
    assert build_wfe_budget([0, 100, 50]) == [0, 100, 100, 50, 50, 50]


def test_build_wfe_budget_returns_list():
    assert isinstance(build_wfe_budget([0, 10]), list)


def test_build_wfe_budget_tip_tilt_zero():
    """When first two orders are 0, first three entries are zero (piston, tip, tilt)."""
    result = build_wfe_budget([0, 0, 50])
    assert result[:3] == [0, 0, 0]


# ── get_filter_bounds ─────────────────────────────────────────────────────────

@pytest.mark.parametrize("fname", ["Y", "J", "H"])
def test_get_filter_bounds_valid_names(fname):
    lo, hi = get_filter_bounds(fname)
    assert lo < hi


def test_get_filter_bounds_y_band_range():
    lo, hi = get_filter_bounds("Y")
    # Y band is in the NIR; bounds should be in nm, roughly 950–1212
    assert 900 <= lo <= 1000
    assert 1100 <= hi <= 1300


def test_get_filter_bounds_invalid_raises():
    with pytest.raises(ValueError, match="Unknown filter"):
        get_filter_bounds("Z")


# ── _planck_law ───────────────────────────────────────────────────────────────

def test_planck_law_positive():
    wl = np.array([1.0e-6])  # 1 µm
    flux = _planck_law(wl, temperature_K=5778.0)
    assert np.all(flux > 0)


def test_planck_law_hotter_star_brighter_at_peak():
    """Hotter blackbody has higher peak spectral radiance."""
    wl = np.array([0.5e-6])  # near peak of 6000 K BB
    assert _planck_law(wl, 6000.0) > _planck_law(wl, 4000.0)


def test_planck_law_array_input():
    wl = np.linspace(0.8e-6, 2.0e-6, 10)
    flux = _planck_law(wl, 5778.0)
    assert flux.shape == (10,)
    assert np.all(flux > 0)


def test_planck_law_monotone_in_temperature_at_fixed_wavelength():
    wl = np.array([1.0e-6])
    temps = [3000.0, 6000.0, 10000.0, 30000.0]
    fluxes = [_planck_law(wl, T)[0] for T in temps]
    assert fluxes == sorted(fluxes), "Planck radiance should increase with temperature"


# ── build_polychromatic_star ──────────────────────────────────────────────────

def test_poly_star_returns_dict_with_correct_keys():
    result = build_polychromatic_star(temperature=6000.0, filter_name="Y", sampling=5)
    assert "wavelengths" in result
    assert "weights" in result


def test_poly_star_wavelengths_shape_matches_sampling():
    for s in [3, 7, 11]:
        res = build_polychromatic_star(temperature=6000.0, filter_name="Y", sampling=s)
        assert len(res["wavelengths"]) == s
        assert len(res["weights"]) == s


def test_poly_star_wavelengths_in_metres():
    res = build_polychromatic_star(temperature=6000.0, filter_name="Y", sampling=5)
    wl = res["wavelengths"]
    # Y band: 950–1212 nm → 0.95e-6 to 1.212e-6 m
    assert np.all(wl > 5e-7), "Wavelengths should be in metres (> 500 nm = 5e-7 m)"
    assert np.all(wl < 3e-6), "Wavelengths should be in metres (< 3 µm)"


def test_poly_star_weights_positive():
    res = build_polychromatic_star(temperature=6000.0, filter_name="Y", sampling=5)
    assert np.all(res["weights"] > 0)


def test_poly_star_hotter_brighter_in_y_band():
    cool = build_polychromatic_star(temperature=3000.0, filter_name="Y", sampling=5)
    hot  = build_polychromatic_star(temperature=10000.0, filter_name="Y", sampling=5)
    assert np.mean(hot["weights"]) > np.mean(cool["weights"])


def test_poly_star_invalid_filter_raises():
    with pytest.raises(ValueError):
        build_polychromatic_star(temperature=6000.0, filter_name="Z", sampling=5)


# ── generate_coefficients ─────────────────────────────────────────────────────

def test_generate_coefficients_shape():
    budget = build_wfe_budget([0, 100, 50])  # 6 coefficients
    coefs = generate_coefficients(budget)
    assert coefs.shape == (6,)


def test_generate_coefficients_dtype_float():
    budget = [0, 100, 50]
    coefs = generate_coefficients(budget)
    assert np.issubdtype(coefs.dtype, np.floating)


def test_generate_coefficients_within_bounds():
    budget = [0, 100, 50, 36]
    flat = build_wfe_budget(budget)
    coefs = generate_coefficients(flat)
    bounds_m = np.array(flat) * 1e-9
    assert np.all(np.abs(coefs) <= bounds_m + 1e-18), "Coefficients exceed budget"


def test_generate_coefficients_piston_zero():
    """When piston budget is 0, the first coefficient must always be 0."""
    budget = build_wfe_budget([0, 100])
    for _ in range(20):
        coefs = generate_coefficients(budget)
        assert coefs[0] == 0.0, "Piston coefficient should be zero when budget is 0"


def test_generate_coefficients_sec_factor_scales_range():
    """With sec_factor=0.5 the maximum absolute value must halve."""
    budget = [0, 200, 200]
    np.random.seed(0)
    coefs_full = np.array([generate_coefficients(budget, sec_factor=1.0) for _ in range(100)])
    np.random.seed(0)
    coefs_half = np.array([generate_coefficients(budget, sec_factor=0.5) for _ in range(100)])
    assert np.max(np.abs(coefs_half)) <= np.max(np.abs(coefs_full)) + 1e-20


# ── get_path_data / get_path_model ────────────────────────────────────────────

def test_get_path_data_contains_psfcraft():
    path = get_path_data("NewtonianTelescope", "2")
    assert "PSFCraft" in path


def test_get_path_data_contains_optics_name():
    path = get_path_data("NewtonianTelescope", "2")
    assert "NewtonianTelescope" in path


def test_get_path_data_contains_version_prefix():
    path = get_path_data("NewtonianTelescope", "2")
    assert "v2" in path


def test_get_path_model_contains_psfzernet():
    path = get_path_model("NewtonianTelescope", "2")
    assert "PSFZerNet" in path


def test_get_path_data_respects_env_var(monkeypatch, tmp_path):
    """global_path is captured at import time; patch the module attribute directly."""
    import psfcraft.utils as u
    monkeypatch.setattr(u, "global_path", str(tmp_path))
    # Rebuild the lambdas so they pick up the patched global_path
    monkeypatch.setattr(u, "get_path_data",
                        lambda name, ver: os.path.join(str(tmp_path), "PSFCraft", name, "v" + ver))
    path = os.path.join(str(tmp_path), "PSFCraft", "NewtonianTelescope", "v2")
    assert u.get_path_data("NewtonianTelescope", "2") == path


# ── get_opticsname_version ────────────────────────────────────────────────────

def test_get_opticsname_version_simple():
    # Standard dataset name pattern: OpticName_vVERSION_N<size>_<rest>
    name, ver = get_opticsname_version("NewtonianTelescope_v2_N16_P1e4_J6_ChM_W1000nm")
    assert name == "NewtonianTelescope"
    assert ver == "2"


def test_get_opticsname_version_strips_v_prefix():
    name, ver = get_opticsname_version("NewtonianTelescope_v1_N32_P1e4_J6_ChM_W1000nm")
    assert not ver.startswith("v")
