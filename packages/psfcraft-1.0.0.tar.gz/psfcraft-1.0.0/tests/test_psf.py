"""Tests for PSF_Generator init, state inference, and filename logic.

These tests deliberately avoid calling optical_system_initiator() or
write_database_hdf5() — both are expensive and I/O-bound.  Instead we
test the lightweight __init__ wiring and the pure filename_builder method.

Covers:
- Chromatism inference from source type
- Polychromatic source dict validation
- Attribute assignment after __init__
- filename_builder format (monochromatic & polychromatic)
- Edge-case: invalid poly source key raises ValueError
"""
import pytest

from psfcraft.utils import PSF_Generator, build_wfe_budget


# ── Helpers ───────────────────────────────────────────────────────────────────

SMALL_BUDGET = [0, 100, 50, 36]          # → 10 Zernike coefficients
MONO_WL      = 1.0e-6                     # 1 µm (float → monochromatic)
POLY_SOURCE  = {"temperature": 6000.0, "filter": "Y", "sampling": 5}


def _make_generator(source=MONO_WL, budget=None):
    """Construct a PSF_Generator with minimal, cheap parameters."""
    return PSF_Generator(
        optics_name="NewtonianTelescope",
        optics_version="1",
        optics_primary_radius=0.5,
        optics_secondary_radius=0.1,
        size_psf=8,
        N_psfs=2,
        wfe_budget=budget or build_wfe_budget(SMALL_BUDGET),
        source=source,
        detector_oversampling=2,
    )


# ── Chromatism inference ──────────────────────────────────────────────────────

def test_float_source_sets_mono_chromatism():
    gen = _make_generator(source=1.0e-6)
    assert gen.chromatism == "mono"


def test_dict_source_sets_poly_chromatism():
    gen = _make_generator(source=POLY_SOURCE)
    assert gen.chromatism == "poly"


def test_mono_source_stored_as_float():
    gen = _make_generator(source=1.5e-6)
    assert isinstance(gen.source, float)


# ── Attribute assignment ──────────────────────────────────────────────────────

def test_size_psf_stored_as_int():
    gen = _make_generator()
    assert isinstance(gen.size_psf, int)
    assert gen.size_psf == 8


def test_n_psfs_stored_as_int():
    gen = _make_generator()
    assert isinstance(gen.N_psfs, int)
    assert gen.N_psfs == 2


def test_n_orders_equals_budget_length():
    budget = build_wfe_budget(SMALL_BUDGET)
    gen = _make_generator(budget=budget)
    assert gen.N_orders == len(budget)


def test_primary_radius_stored_as_float():
    gen = _make_generator()
    assert isinstance(gen.optics_primary_radius, float)


def test_poly_source_temperature_stored():
    gen = _make_generator(source=POLY_SOURCE)
    assert gen.temperature_star == POLY_SOURCE["temperature"]


def test_poly_source_filter_stored():
    gen = _make_generator(source=POLY_SOURCE)
    assert gen.filter_name == POLY_SOURCE["filter"]


def test_poly_source_sampling_stored():
    gen = _make_generator(source=POLY_SOURCE)
    assert gen.sampling_wl == POLY_SOURCE["sampling"]


# ── Invalid poly source ───────────────────────────────────────────────────────

def test_poly_source_missing_key_raises():
    bad_source = {"temperature": 6000.0, "filter": "Y"}  # 'sampling' missing
    with pytest.raises((ValueError, KeyError)):
        _make_generator(source=bad_source)


def test_poly_source_missing_temperature_raises():
    bad_source = {"filter": "Y", "sampling": 5}
    with pytest.raises((ValueError, KeyError)):
        _make_generator(source=bad_source)


# ── filename_builder — monochromatic ─────────────────────────────────────────

def _build_filename(gen, ext=".hdf5"):
    gen.filename_builder(ext)
    return gen.filename_psfs


def test_mono_filename_contains_optics_name():
    gen = _make_generator(source=1.0e-6)
    fn = _build_filename(gen)
    assert "NewtonianTelescope" in fn


def test_mono_filename_contains_version():
    gen = _make_generator(source=1.0e-6)
    fn = _build_filename(gen)
    assert "_v1" in fn


def test_mono_filename_contains_wavelength_in_nm():
    gen = _make_generator(source=1.0e-6)       # 1000 nm
    fn = _build_filename(gen)
    assert "W1000nm" in fn, f"Expected 'W1000nm' in '{fn}'"


def test_mono_filename_contains_psf_size():
    gen = _make_generator(source=1.0e-6)
    fn = _build_filename(gen)
    assert "_N8" in fn


def test_mono_filename_chromatism_tag_is_ChM():
    gen = _make_generator(source=1.0e-6)
    fn = _build_filename(gen)
    assert "_ChM" in fn


def test_mono_filename_has_correct_extension():
    gen = _make_generator(source=1.0e-6)
    fn = _build_filename(gen, ".hdf5")
    assert fn.endswith(".hdf5")


def test_mono_filename_wavelength_rounded_to_int():
    gen = _make_generator(source=1.234e-6)     # 1234 nm
    fn = _build_filename(gen)
    assert "W1234nm" in fn, f"Expected 'W1234nm' in '{fn}'"


# ── filename_builder — polychromatic ─────────────────────────────────────────

def test_poly_filename_chromatism_tag_is_ChP():
    gen = _make_generator(source=POLY_SOURCE)
    fn = _build_filename(gen)
    assert "_ChP" in fn


def test_poly_filename_contains_filter():
    gen = _make_generator(source=POLY_SOURCE)
    fn = _build_filename(gen)
    assert "_PhotY" in fn


def test_poly_filename_contains_temperature():
    gen = _make_generator(source=POLY_SOURCE)
    fn = _build_filename(gen)
    assert "_BB6000K" in fn


def test_poly_filename_contains_sampling():
    gen = _make_generator(source=POLY_SOURCE)
    fn = _build_filename(gen)
    assert "_Dw5" in fn


def test_poly_filename_no_wavelength_tag():
    """Polychromatic filenames must NOT contain a monochromatic wavelength tag."""
    gen = _make_generator(source=POLY_SOURCE)
    fn = _build_filename(gen)
    assert "_W" not in fn, f"Unexpected monochromatic tag in '{fn}'"


# ── Determinism ───────────────────────────────────────────────────────────────

def test_filename_is_deterministic():
    """Same inputs must always produce the same filename."""
    gen1 = _make_generator(source=1.0e-6)
    gen2 = _make_generator(source=1.0e-6)
    assert _build_filename(gen1) == _build_filename(gen2)
