"""Tests for psfcraft.constants — physical values and data-structure consistency."""
import math
import numpy as np
import pytest

from psfcraft import constants as C


# ── Telescope geometry ────────────────────────────────────────────────────────

def test_primary_mirror_diameter_is_positive():
    assert C.DIAMETER_PRIMARY_MIRROR > 0


def test_secondary_mirror_smaller_than_primary():
    assert C.DIAMETER_SECONDARY_MIRROR < C.DIAMETER_PRIMARY_MIRROR


def test_secondary_obstruction_fraction_physically_plausible():
    """Secondary area should be 5–30 % of primary area (Euclid-like telescopes)."""
    ratio = (C.DIAMETER_SECONDARY_MIRROR / C.DIAMETER_PRIMARY_MIRROR) ** 2
    assert 0.05 < ratio < 0.30, f"Obstruction ratio {ratio:.3f} out of plausible range"


def test_focal_length_positive_and_plausible():
    assert C.TELESCOPE_FOCAL_LENGTH > 0
    # f-number must be > 1 for real telescopes
    assert C.TELESCOPE_FOCAL_LENGTH / C.DIAMETER_PRIMARY_MIRROR > 1


# ── Detector parameters ───────────────────────────────────────────────────────

def test_pixel_scale_positive():
    assert C.DETECTOR_PIXEL_SCALE > 0


def test_pixel_scale_arcsec_range():
    """Euclid pixel scale should be ~0.3 arcsec/pixel."""
    assert 0.1 < C.DETECTOR_PIXEL_SCALE < 1.0


def test_detector_size_power_of_two():
    size = C.DETECTOR_SIZE
    assert size > 0 and (size & (size - 1)) == 0, f"{size} is not a power of two"


# ── Filter cut-offs ───────────────────────────────────────────────────────────

@pytest.mark.parametrize("cuts,label", [
    (C.FILTER_Y_CUTS, "Y"),
    (C.FILTER_J_CUTS, "J"),
    (C.FILTER_H_CUTS, "H"),
])
def test_filter_cuts_ordered(cuts, label):
    lo, hi = cuts
    assert lo < hi, f"Filter {label}: lower bound {lo} >= upper bound {hi}"


def test_filter_bands_do_not_overlap_badly():
    """Y and J should overlap at most partially; H starts after J lower edge."""
    assert C.FILTER_J_CUTS[0] < C.FILTER_H_CUTS[0]
    assert C.FILTER_Y_CUTS[0] < C.FILTER_J_CUTS[0]


# ── Stellar types ─────────────────────────────────────────────────────────────

def test_stellar_lists_have_same_length():
    n = len(C.STELLAR_SPECTRAL_TYPES)
    assert len(C.STELLAR_TEMPERATURES_MEAN) == n
    assert len(C.STELLAR_TEMPERATURES_STD) == n
    assert len(C.STELLAR_TEMPERATURES_BOUNDS) == n


def test_stellar_temperatures_decrease_O_to_M():
    """Temperatures must go from hot (O) to cool (M)."""
    temps = C.STELLAR_TEMPERATURES_MEAN
    assert all(temps[i] > temps[i + 1] for i in range(len(temps) - 1))


def test_stellar_temperature_stds_positive():
    for std in C.STELLAR_TEMPERATURES_STD:
        assert std > 0


def test_stellar_temperature_bounds_enclose_mean():
    for mean, (lo, hi) in zip(C.STELLAR_TEMPERATURES_MEAN, C.STELLAR_TEMPERATURES_BOUNDS):
        assert lo <= mean <= hi, f"Mean {mean} K not in [{lo}, {hi}]"


def test_stellar_fraction_sums_to_100():
    total = sum(C.STELLAR_FRACTION_MAIN_SEQUENCE)
    assert math.isclose(total, 100.0, rel_tol=0.01), f"Fractions sum to {total}"


# ── PSF derived constants ─────────────────────────────────────────────────────

def test_psf_sigma_pixels_consistent():
    """PSF_SIGMA_PIXELS must equal PSF_SIGMA / DETECTOR_PIXEL_SCALE."""
    expected = C.PSF_SIGMA / C.DETECTOR_PIXEL_SCALE
    assert math.isclose(C.PSF_SIGMA_PIXELS, expected, rel_tol=1e-9)
