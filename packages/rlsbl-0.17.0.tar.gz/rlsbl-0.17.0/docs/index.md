# rlsbl

Release orchestration and project scaffolding CLI for npm, PyPI, Go, Cargo, Hex, Deno, Maven, Swift, Docker, and more.

Handles version bumping, changelog validation, tagging, GitHub Releases, CI scaffolding, and CI monitoring. Supports both single-target and multi-target projects, as well as monorepo workspaces.

## Pages

- [Command reference](commands.md) -- all CLI commands and options
- [Release targets](targets.md) -- the 12 supported ecosystems
- [Monorepo guide](monorepo.md) -- workspace management and subtree publishing
- [Configuration reference](configuration.md) -- config file formats
