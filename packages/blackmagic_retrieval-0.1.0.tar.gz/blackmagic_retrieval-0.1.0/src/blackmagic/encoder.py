"""Encoder: SPLADE sparse expansion + AnchorProjector.

Default model is the multilingual fine-tune
`cp500/opensearch-neural-sparse-en-jp-ko` (160M params, ~670MB). The
AnchorProjector's self-encoding mode resolves anchor activations for
EN / JA / KO input against an English-authored schema.

    sentence → SPLADE → 105k sparse → AnchorProjector → N anchor activations

For English-only use with a smaller model, pass a different HF model name
and `multilingual=False` (e.g. splade-tiny at `prithivida/Splade_PP_en_v1`).
"""

from __future__ import annotations

import json
import re
import warnings
from pathlib import Path

import numpy as np
import torch
from transformers import AutoTokenizer, AutoModelForMaskedLM

# Default model: the multilingual fine-tune shipped alongside this package.
# Downloaded from HuggingFace on first use and cached by `transformers`.
_DEFAULT_MODEL = "cp500/opensearch-neural-sparse-en-jp-ko"


class SpladeEncoder:
    """SPLADE sparse encoder: text → 30,522-dim sparse vocabulary vector.

    Uses BertForMaskedLM with log(1 + ReLU(logits)) activation and
    max-pooling across token positions.
    """

    def __init__(self, model_name: str = _DEFAULT_MODEL,
                 max_length: int = 256, device: str | None = None):
        self.model_name = model_name or _DEFAULT_MODEL
        self.max_length = max_length
        self.device = device or (
            "cuda" if torch.cuda.is_available() else
            "mps" if torch.backends.mps.is_available() else "cpu"
        )

        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            self.tokenizer = AutoTokenizer.from_pretrained(self.model_name)
            self.model = AutoModelForMaskedLM.from_pretrained(self.model_name)
        self.model.eval()
        self.model.to(self.device)
        self.vocab_size = self.model.config.vocab_size

    @torch.no_grad()
    def encode_sparse(self, texts: list[str],
                      batch_size: int = 32) -> np.ndarray:
        """Encode texts → (n_texts, vocab_size) sparse activation matrix."""
        all_vecs = []
        for i in range(0, len(texts), batch_size):
            batch = texts[i:i + batch_size]
            enc = self.tokenizer(
                batch, max_length=self.max_length, padding=True,
                truncation=True, return_tensors="pt",
            )
            input_ids = enc["input_ids"].to(self.device)
            attention_mask = enc["attention_mask"].to(self.device)

            logits = self.model(
                input_ids=input_ids,
                attention_mask=attention_mask,
            ).logits  # (batch, seq_len, vocab_size)

            # SPLADE activation: log(1 + ReLU(logits))
            activated = torch.log1p(torch.relu(logits))

            # Max-pool across token positions, masked
            activated = activated * attention_mask.unsqueeze(-1)
            sparse_vecs = activated.max(dim=1).values  # (batch, vocab_size)

            all_vecs.append(sparse_vecs.cpu().numpy())

        return np.concatenate(all_vecs, axis=0)


class AnchorProjector:
    """Project SPLADE sparse vectors onto typed anchor activations.

    Two resolution strategies:

    1. **Vocab-ID mode** (`splade=None`): Each anchor token is looked up as a
       literal vocab entry, plus WordPiece `##<token>` continuation, plus
       subword fallback via `tokenizer.encode`. Works for splade-tiny and any
       model where anchor surface forms appear in the vocab.

    2. **Self-encoding mode** (`splade=<SpladeEncoder>`): Each anchor token is
       itself run through SPLADE, and its top-K activated vocab positions
       become the anchor's ID set. Required for multilingual SPLADE models
       that expand English into a cross-script soup (CJK + Latin + Cyrillic).
       A JA sentence fires the same expansion positions → anchor activates.

    Projection is max-pooling: anchor score = max(sparse_vec[token_ids]).
    """

    def __init__(self, schema, tokenizer, splade=None, top_k: int = 24,
                 expansion_threshold: float = 0.05):
        self.schema = schema
        self.tokenizer = tokenizer
        self.splade = splade
        self.top_k = top_k
        self.expansion_threshold = expansion_threshold
        self.anchor_token_ids: dict[str, list[int]] = {}

        if splade is not None:
            self._build_via_self_encoding()
        else:
            self._build_via_vocab_lookup()

    def _build_via_vocab_lookup(self):
        missing = []
        unk = self.tokenizer.unk_token_id
        for name, info in self.schema.anchors.items():
            ids = set()
            for token in info.get("tokens", []):
                tid = self.tokenizer.convert_tokens_to_ids(token)
                if tid != unk:
                    ids.add(tid)
                sub_tid = self.tokenizer.convert_tokens_to_ids(f"##{token}")
                if sub_tid != unk:
                    ids.add(sub_tid)
                if not ids:
                    sub_ids = self.tokenizer.encode(token, add_special_tokens=False)
                    for sid in sub_ids:
                        if sid != unk:
                            ids.add(sid)
            self.anchor_token_ids[name] = list(ids)
            if not ids:
                missing.append(name)

        if missing and len(missing) <= 10:
            print(f"  AnchorProjector: no vocab tokens for {missing}")
        elif missing:
            print(f"  AnchorProjector: no vocab tokens for {len(missing)} anchors")

    def _build_via_self_encoding(self):
        """Encode each anchor token through SPLADE and take its top-K expansion.

        After collecting each anchor's raw expansion, subtract vocab positions
        that also strongly activate for another anchor *of the same type* — that
        suppresses cross-brand / cross-relation leakage like honda firing on
        toyota sentences because both share the brand-semantic neighbourhood.
        """
        # Batch-encode every surface form
        all_tokens = []
        by_anchor = []
        for name, info in self.schema.anchors.items():
            toks = list(info.get("tokens", [])) or [name]
            by_anchor.append((name, list(range(len(all_tokens),
                                                len(all_tokens) + len(toks)))))
            all_tokens.extend(toks)

        if not all_tokens:
            return

        sparse = self.splade.encode_sparse(all_tokens)  # (n_tokens, vocab_size)

        # Raw per-anchor {tid: score} expansion (union across its surface forms)
        raw: dict[str, dict[int, float]] = {}
        for name, idxs in by_anchor:
            id_scores: dict[int, float] = {}
            for idx in idxs:
                vec = sparse[idx]
                top = np.argsort(-vec)[:self.top_k]
                for tid in top:
                    v = float(vec[tid])
                    if v > self.expansion_threshold:
                        tid_i = int(tid)
                        if v > id_scores.get(tid_i, 0.0):
                            id_scores[tid_i] = v
            raw[name] = id_scores

        # Exclusivity filter: drop any position that activates at ≥0.5× strength
        # in another same-type anchor. Same-type is key — a brand and a feature
        # sharing a vocab position is fine (they play different roles), but two
        # brands sharing one is crosstalk.
        for name, scores in raw.items():
            my_type = self.schema.types.get(name, "")
            same_type_peers = [p for p, info in self.schema.anchors.items()
                               if p != name and info.get("type") == my_type]
            kept: list[int] = []
            for tid, v in scores.items():
                suppressed = False
                for peer in same_type_peers:
                    peer_v = raw.get(peer, {}).get(tid, 0.0)
                    if peer_v >= 0.5 * v:
                        suppressed = True
                        break
                if not suppressed:
                    kept.append(tid)
            # Fallback: if exclusivity left us empty, keep the single strongest ID.
            if not kept and scores:
                kept = [max(scores.items(), key=lambda t: t[1])[0]]
            self.anchor_token_ids[name] = kept

    def project(self, sparse_vec: np.ndarray) -> dict[str, float]:
        """Project one SPLADE vector → {anchor_name: score}."""
        activations = {}
        for name, token_ids in self.anchor_token_ids.items():
            if token_ids:
                score = max(sparse_vec[tid] for tid in token_ids)
                if score > 0:
                    activations[name] = float(score)
        return activations

    def project_batch(self, sparse_matrix: np.ndarray) -> list[dict[str, float]]:
        """Project a batch of SPLADE vectors."""
        return [self.project(sparse_matrix[i])
                for i in range(sparse_matrix.shape[0])]

    def project_to_matrix(self, sparse_matrix: np.ndarray,
                          anchor_names: list[str]) -> np.ndarray:
        """Project SPLADE matrix → (n_texts, n_anchors) dense matrix."""
        n = sparse_matrix.shape[0]
        out = np.zeros((n, len(anchor_names)), dtype=np.float32)

        for i in range(n):
            vec = sparse_matrix[i]
            for j, name in enumerate(anchor_names):
                token_ids = self.anchor_token_ids.get(name, [])
                if token_ids:
                    out[i, j] = max(vec[tid] for tid in token_ids)
        return out


class Encoder:
    """Encode sentences into anchor activation vectors.

    Default is the multilingual SPLADE fine-tune
    `cp500/opensearch-neural-sparse-en-jp-ko`. Authors its schema in English;
    EN / JA / KO inputs all activate English anchor positions via the
    self-encoding AnchorProjector.

    Quick start (multilingual):
        encoder = Encoder(schema=my_schema)              # multilingual=True
        activations = encoder.encode([
            "Toyota invests in batteries.",
            "トヨタは電池に投資している。",
            "토요타는 배터리에 투자하고 있다.",
        ])

    English-only, smaller model:
        encoder = Encoder(schema=my_schema,
                          model_name="prithivida/Splade_PP_en_v1",
                          multilingual=False)
    """

    def __init__(self, schema=None,
                 model_name: str = _DEFAULT_MODEL,
                 anchor_names: list[str] | None = None,
                 anchor_types: dict[str, str] | None = None,
                 max_length: int = 256,
                 device: str | None = None,
                 multilingual: bool = True,
                 expansion_top_k: int = 24,
                 expansion_threshold: float = 0.05):
        self.model_name = model_name or _DEFAULT_MODEL
        self.max_length = max_length
        self.multilingual = multilingual

        # SPLADE encoder
        self.splade = SpladeEncoder(self.model_name, max_length, device)
        self.device = self.splade.device

        # Schema and projector
        self.anchor_names = anchor_names or (list(schema.names) if schema else [])
        self.anchor_types = anchor_types or (schema.types if schema else {})
        self.n_anchors = len(self.anchor_names)

        self._projector = None
        if schema:
            # Multilingual SPLADE encoders (e.g. the EN/JA/KO fine-tune) expand
            # English anchor tokens into a cross-script soup. Self-encode the
            # anchor strings so their token IDs match what the model actually
            # fires on for EN/JA/KO input.
            self._projector = AnchorProjector(
                schema, self.splade.tokenizer,
                splade=self.splade if multilingual else None,
                top_k=expansion_top_k,
                expansion_threshold=expansion_threshold,
            )

    @property
    def tokenizer(self):
        return self.splade.tokenizer

    @property
    def model(self):
        return self.splade.model

    def encode(self, texts: list[str],
               batch_size: int = 32) -> np.ndarray:
        """Encode sentences → (n_texts, n_anchors) anchor activation matrix."""
        sparse = self.splade.encode_sparse(texts, batch_size=batch_size)

        if self._projector is None:
            raise RuntimeError(
                "No schema/projector configured. Pass schema= to __init__."
            )

        return self._projector.project_to_matrix(sparse, self.anchor_names)

    def encode_sparse(self, texts: list[str],
                      batch_size: int = 32) -> np.ndarray:
        """Encode sentences → raw (n_texts, vocab_size) SPLADE vectors."""
        return self.splade.encode_sparse(texts, batch_size=batch_size)

    def encode_single(self, text: str) -> dict[str, float]:
        """Encode one sentence → {anchor_name: score}."""
        sparse = self.splade.encode_sparse([text])
        return self._projector.project(sparse[0])

    def find_spans(self, text: str, anchor_name: str,
                   anchor_defs: dict) -> list[dict]:
        """Find character spans where an anchor's tokens appear in text.

        English / ASCII only — uses \\b word boundaries. If you need CJK
        support, use the cognition package.
        """
        info = anchor_defs.get(anchor_name, {})
        tokens = info.get("tokens", [])
        if not tokens:
            return []

        sorted_tokens = sorted(tokens, key=len, reverse=True)
        pattern = re.compile(
            r'\b(' + '|'.join(re.escape(t) for t in sorted_tokens) + r')\b',
            re.IGNORECASE,
        )
        return [
            {"text": m.group(), "start": m.start(), "end": m.end()}
            for m in pattern.finditer(text)
        ]
