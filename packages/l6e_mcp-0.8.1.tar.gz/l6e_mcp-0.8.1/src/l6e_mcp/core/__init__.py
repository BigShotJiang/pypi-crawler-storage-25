"""Core budgeting domain services."""
