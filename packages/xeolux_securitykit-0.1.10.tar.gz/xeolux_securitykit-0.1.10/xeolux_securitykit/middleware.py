"""
Middleware principal XeoluxSecurityMiddleware.

Ordre de traitement (chaque étape respecte is_module_enabled()) :
 1. Vérification activation globale
 2. Chemins exempts (statiques, media)
 3. Bypass route de déverrouillage (strict_unlock — toujours libre)
 4. method_guard        — méthodes HTTP interdites
 5. securitykit_self_protection — protection de /securitykit/
 6. header_guard        — headers entrants suspects
 7. anti_ddos           — flood HTTP et rate global
 8. rate_limit          — rate limit par IP
 9. ip_blacklist        — bans temporaires + blacklist globale
10. strict_mode         — mode strict / lockdown
11. suspicious_paths    — chemins suspects (.env, wp-admin…)
12. file_access_guard   — fichiers sensibles (.sql, .pem…)
13. user_agent_blocker  — bots et scanners connus
14. bot_filter          — comportements bots heuristiques
15. payload_guard       — payload trop gros / extensions interdites
16. querystring_guard   — injections et paramètres suspects
17. redirect_guard      — open redirect via paramètre
18. stealth_admin       — masquage de /admin/
19. bruteforce_protection — détection brute force (passif)
20. rules_engine        — règles par route (fake 404, block…)
Response: security_headers + csp_manager + cookie_guard
"""

import logging
from django.http import HttpRequest, HttpResponse
from django.utils.deprecation import MiddlewareMixin

logger = logging.getLogger("xeolux_securitykit")


def _mod(name: str) -> bool:
    """Raccourci : True si le module est actif (ou DB non disponible)."""
    try:
        from .services.module_registry import is_module_enabled
        return is_module_enabled(name)
    except Exception:
        return True


def _get_current_unlock_token() -> str:
    """
    Retourne le token de déverrouillage courant.
    Utilise le cache (performance). Fallback vers DB si absent.
    Retourne "" si le strict mode est inactif ou aucun token généré.
    """
    from django.core.cache import cache
    token = cache.get("xeolux_sk_unlock_token")
    if token is not None:
        return token
    # Fallback DB
    try:
        from .models import StrictModeState
        state = StrictModeState.objects.filter(pk=1).values_list("unlock_token", flat=True).first()
        if state:
            # Ré-initialiser le cache
            cache.set("xeolux_sk_unlock_token", state, timeout=None)
            return state
    except Exception:
        pass
    return ""


def _is_unlock_path(path: str, conf) -> bool:
    """
    Retourne True si le path correspond à l'URL de déverrouillage dynamique.
    Format attendu : <STRICT_UNLOCK_PATH><token>/
    Exemple : /xk-unlock/abc123XYZ.../
    """
    token = _get_current_unlock_token()
    if not token:
        return False
    base = conf.STRICT_UNLOCK_PATH.rstrip("/")
    expected = f"{base}/{token}/"
    return path == expected or path == expected.rstrip("/")


class XeoluxSecurityMiddleware(MiddlewareMixin):
    """
    Middleware central de sécurité.
    Doit être placé en tête de MIDDLEWARE dans settings.py.
    """

    def __init__(self, get_response):
        self.get_response = get_response
        super().__init__(get_response)

    def process_request(self, request: HttpRequest):
        try:
            return self._process(request)
        except Exception as exc:
            if self._is_migration_error(exc):
                logger.debug("xeolux_securitykit: DB non migrée, skip middleware.")
                return None
            logger.exception("xeolux_securitykit: erreur dans le middleware : %s", exc)
            return None

    def process_response(self, request: HttpRequest, response: HttpResponse) -> HttpResponse:
        try:
            from .conf import conf
            if not conf.ENABLED:
                return response

            # security_headers
            if _mod("security_headers") and conf.SECURITY_HEADERS_ENABLED:
                from .modules.security_headers import apply_security_headers
                response = apply_security_headers(response)

            # csp_manager
            if _mod("csp_manager"):
                from .modules.csp_manager import get_default_csp
                csp = get_default_csp()
                response = csp.apply(response)

            # cookie_guard (hardening des cookies session)
            if _mod("cookie_guard"):
                from .modules.cookie_guard import harden_session_cookie
                response = harden_session_cookie(response)

        except Exception:
            pass
        return response

    # ------------------------------------------------------------------
    # Logique interne
    # ------------------------------------------------------------------

    def _process(self, request: HttpRequest):
        from .conf import conf
        from .services.fake_response import build_response

        # 1. Package désactivé globalement
        if not conf.ENABLED:
            return None

        path = request.path_info

        # 2. Chemins exempts (statiques, media, etc.)
        for exempt in conf.EXEMPT_PATHS:
            if path.startswith(exempt):
                return None

        # 3. strict_unlock — bypass si le path correspond au token dynamique courant
        #    Le token est lu depuis le cache (perf), fallback DB si cache vide.
        if _is_unlock_path(path, conf):
            return None

        client_ip = self._get_client_ip(request)
        user_agent = request.META.get("HTTP_USER_AGENT", "")

        # 4. method_guard — méthodes HTTP interdites
        if _mod("method_guard"):
            from .modules.method_guard import is_method_blocked
            if is_method_blocked(request):
                return build_response(request, "fake_404")

        # 5. securitykit_self_protection
        if path.startswith(conf.SECURITYKIT_PATH) and conf.SELF_PROTECTION_ENABLED:
            if _mod("securitykit_self_protection"):
                resp = self._protect_securitykit(request, client_ip)
                if resp:
                    return resp

        # 6. header_guard — headers entrants suspects
        if _mod("header_guard"):
            from .modules.header_guard import check_headers
            safe, _ = check_headers(request)
            if not safe:
                return build_response(request, "fake_404")

        # 7. anti_ddos — flood et rate global
        if _mod("anti_ddos") and conf.ANTI_DDOS_ENABLED:
            from .services.anti_ddos import AntiDDOS
            resp = AntiDDOS.check(request, client_ip)
            if resp:
                return resp

        # 8. rate_limit — limite par IP
        if _mod("rate_limit"):
            from .modules.rate_limit import rate_limit_by_ip
            allowed, _ = rate_limit_by_ip(client_ip)
            if not allowed:
                from .responses import too_many_requests_response
                return too_many_requests_response()

        # 9. ip_blacklist — bans temporaires puis blacklist globale
        if _mod("ip_blacklist"):
            from .modules.ip_blacklist import is_temporarily_banned, is_ip_blacklisted
            if is_temporarily_banned(client_ip) or is_ip_blacklisted(client_ip):
                return build_response(request, "fake_404")

        # 10. strict_mode / lockdown
        if _mod("strict_mode") and conf.STRICT_MODE_ENABLED:
            from .services.strict_mode import StrictModeGuard
            resp = StrictModeGuard.check(request, client_ip)
            if resp:
                return resp

        # 11. suspicious_paths
        if _mod("suspicious_paths"):
            from .modules.suspicious_paths import is_suspicious_path
            if is_suspicious_path(path):
                return build_response(request, "fake_404")

        # 12. file_access_guard
        if _mod("file_access_guard"):
            from .modules.file_access_guard import is_sensitive_file_path
            if is_sensitive_file_path(path):
                return build_response(request, "fake_404")

        # 13. user_agent_blocker
        if _mod("user_agent_blocker"):
            from .modules.user_agent_blocker import is_blocked_user_agent
            if is_blocked_user_agent(user_agent):
                return build_response(request, "fake_404")

        # 14. bot_filter — heuristique comportementale
        if _mod("bot_filter"):
            from .modules.bot_filter import is_likely_bot
            if is_likely_bot(client_ip, request):
                if _mod("slow_down"):
                    from .modules.slow_down import slow_down_response
                    slow_down_response(2.0)
                return build_response(request, "fake_404")

        # 15. payload_guard — payload trop gros / upload interdit
        if _mod("payload_guard") and request.method in ("POST", "PUT", "PATCH"):
            from .modules.payload_guard import check_payload
            safe, _ = check_payload(request)
            if not safe:
                return build_response(request, "fake_404")

        # 16. querystring_guard — injections et paramètres suspects
        if _mod("querystring_guard") and request.GET:
            from .modules.querystring_guard import check_querystring
            safe, _ = check_querystring(request)
            if not safe:
                return build_response(request, "fake_404")

        # 17. redirect_guard — open redirect via paramètre
        if _mod("redirect_guard"):
            from .modules.redirect_guard import check_redirect_params
            safe, _ = check_redirect_params(request)
            if not safe:
                return build_response(request, "fake_404")

        # 18. stealth_admin — masquage de /admin/
        if _mod("stealth_admin"):
            from .modules.stealth_admin import is_admin_path, should_hide_admin
            if is_admin_path(path) and should_hide_admin(request):
                return build_response(request, "fake_404")

        # 19. bruteforce_protection — détection passif (enregistrement via signal)
        #     L'action est prise par ban_ip_temporarily() déclenché depuis la vue login.
        #     Ici : bloquer si déjà marqué comme brute-force actif.
        if _mod("bruteforce_protection"):
            from .modules.bruteforce_protection import is_brute_forced
            if is_brute_forced(client_ip):
                return build_response(request, "fake_404")

        # 20. rules_engine — règles personnalisées par route
        if _mod("rules_engine"):
            from .services.rules_engine import RulesEngine
            resp = RulesEngine.evaluate(request, path, client_ip)
            if resp:
                return resp

        return None

    def _protect_securitykit(self, request: HttpRequest, client_ip: str):
        """Protège l'interface /securitykit/ contre les accès non autorisés.
        
        Si SecurityKit est placé avant AuthenticationMiddleware (recommandé pour la sécurité),
        request.user n'est pas encore défini ici. Dans ce cas, on laisse passer :
        le décorateur @securitykit_access_required s'en charge après tous les middlewares.
        """
        # AuthenticationMiddleware n'a pas encore tourné → pas de user → déléguer au décorateur
        if not hasattr(request, "user"):
            return None

        from .services.fake_response import build_response
        from .decorators import _check_securitykit_access

        if not _check_securitykit_access(request):
            return build_response(request, "fake_404")

        return None

    @staticmethod
    def _get_client_ip(request: HttpRequest) -> str:
        x_forwarded = request.META.get("HTTP_X_FORWARDED_FOR")
        if x_forwarded:
            return x_forwarded.split(",")[0].strip()
        return request.META.get("REMOTE_ADDR", "")

    @staticmethod
    def _is_migration_error(exc: Exception) -> bool:
        err = str(exc).lower()
        return any(kw in err for kw in ("no such table", "relation", "does not exist", "operational"))
