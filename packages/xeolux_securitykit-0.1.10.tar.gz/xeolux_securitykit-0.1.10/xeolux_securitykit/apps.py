from django.apps import AppConfig


class XeoluxSecurityKitConfig(AppConfig):
    name = "xeolux_securitykit"
    verbose_name = "Xeolux SecurityKit"
    default_auto_field = "django.db.models.BigAutoField"

    def ready(self):
        # Enregistrement des checks système Django
        from . import checks  # noqa: F401
        # Initialisation du registre des modules
        from .services.module_registry import initialize_registry
        initialize_registry()
        # Vérification de configuration au démarrage
        self._startup_checks()

    def _startup_checks(self):
        """Vérifie la configuration critique au démarrage et affiche des avertissements."""
        import sys
        try:
            from django.conf import settings
            middleware = list(getattr(settings, "MIDDLEWARE", []))
            target = "xeolux_securitykit.middleware.XeoluxSecurityMiddleware"
            auth_mw = "django.contrib.auth.middleware.AuthenticationMiddleware"

            if target not in middleware:
                print(
                    "\033[93m[xeolux_securitykit] AVERTISSEMENT : XeoluxSecurityMiddleware "
                    "absent de MIDDLEWARE. Ajoutez-le en début de liste.\033[0m",
                    file=sys.stderr,
                )
            elif auth_mw not in middleware:
                print(
                    "\033[93m[xeolux_securitykit] AVERTISSEMENT : AuthenticationMiddleware absent. "
                    "Les vérifications de permission ne fonctionneront pas.\033[0m",
                    file=sys.stderr,
                )
        except Exception:
            pass
