"""
Tags de template pour xeolux_securitykit.
"""

from collections import OrderedDict
from django import template

register = template.Library()

CATEGORY_LABELS = {
    "interface": "Interface",
    "engine": "Moteur",
    "routes": "Routes",
    "access": "Accès IP",
    "config": "Configuration",
    "admin": "Admin furtif",
    "rate": "Rate Limit",
    "detection": "Détection",
    "forms": "Formulaires",
    "api": "API",
    "headers": "Headers",
    "requests": "Requêtes",
    "strict": "Strict Mode",
    "diagnostics": "Diagnostics",
}


@register.simple_tag
def get_modules_by_category():
    """Retourne tous les modules groupés par catégorie avec leur état DB."""
    try:
        from xeolux_securitykit.services.module_registry import get_all_modules
        modules = get_all_modules()
    except Exception:
        return []

    by_cat: OrderedDict[str, list] = OrderedDict()
    for m in modules:
        cat = m["category"]
        if cat not in by_cat:
            by_cat[cat] = []
        by_cat[cat].append(m)

    return [
        {
            "label": CATEGORY_LABELS.get(cat, cat.title()),
            "key": cat,
            "modules": mods,
        }
        for cat, mods in by_cat.items()
    ]
