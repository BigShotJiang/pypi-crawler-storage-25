"""
xeolux_securitykit — Package de sécurité Django configurable.
"""

default_app_config = "xeolux_securitykit.apps.XeoluxSecurityKitConfig"

__version__ = "0.1.10"
__author__ = "Xeolux"
