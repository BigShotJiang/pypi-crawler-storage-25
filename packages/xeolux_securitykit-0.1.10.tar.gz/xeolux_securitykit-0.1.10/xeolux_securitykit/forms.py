"""
Formulaires pour l'interface SecurityKit.
"""

from django import forms
from django.core.validators import validate_ipv46_address

from .models import (
    ProtectedRoute, RouteRule,
    IPWhitelistEntry, IPBlacklistEntry, APIKey,
)


class ProtectedRouteForm(forms.ModelForm):
    class Meta:
        model = ProtectedRoute
        fields = ["path", "match_type", "description", "enabled"]
        widgets = {
            "path": forms.TextInput(attrs={"placeholder": "/admin/ ou ^/api/"}),
            "description": forms.TextInput(attrs={"placeholder": "Description optionnelle"}),
        }


class RouteRuleForm(forms.ModelForm):
    """
    Formulaire de règle de route.
    Les conditions sont décomposées en champs visuels clairs
    et recomposées en JSON pour le modèle.
    """

    # -- Conditions visuelles --
    cond_authenticated = forms.BooleanField(
        required=False,
        label="Utilisateur connecté requis",
        help_text="La règle s'applique uniquement aux visiteurs non connectés.",
    )
    cond_staff = forms.BooleanField(
        required=False,
        label="Compte staff requis",
        help_text="Seuls les comptes marqués 'Staff' dans Django admin peuvent passer.",
    )
    cond_whitelist_ip = forms.BooleanField(
        required=False,
        label="IP en whitelist requise",
        help_text="Seules les IPs de la whitelist globale peuvent accéder à cette route.",
    )
    cond_blacklist_deny = forms.BooleanField(
        required=False,
        label="Bloquer les IPs blacklistées",
        help_text="Les IPs présentes dans la blacklist sont bloquées sur cette route.",
    )
    cond_api_key = forms.BooleanField(
        required=False,
        label="Clé API requise",
        help_text="Un header X-API-Key valide doit être présent dans la requête.",
    )
    cond_methods = forms.MultipleChoiceField(
        required=False,
        label="Méthodes HTTP autorisées",
        help_text="Laissez vide pour autoriser toutes les méthodes.",
        choices=[
            ("GET", "GET — lecture"),
            ("POST", "POST — envoi de données"),
            ("PUT", "PUT — mise à jour complète"),
            ("PATCH", "PATCH — mise à jour partielle"),
            ("DELETE", "DELETE — suppression"),
            ("HEAD", "HEAD"),
            ("OPTIONS", "OPTIONS"),
        ],
        widget=forms.CheckboxSelectMultiple,
    )
    cond_user_agent_block = forms.CharField(
        required=False,
        label="Bloquer si User-Agent correspond (regex)",
        help_text="Ex : bot|crawler|python-requests — laissez vide pour ne pas filtrer.",
        widget=forms.TextInput(attrs={"placeholder": "ex: bot|crawler|scrapy"}),
    )

    class Meta:
        model = RouteRule
        fields = ["action", "redirect_to", "priority", "enabled", "description"]

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # Pré-remplir les champs visuels depuis les conditions JSON existantes
        if self.instance and self.instance.pk:
            conds = self.instance.conditions or {}
            self.fields["cond_authenticated"].initial = conds.get("require_authenticated", False)
            self.fields["cond_staff"].initial = conds.get("require_staff", False)
            self.fields["cond_whitelist_ip"].initial = conds.get("require_whitelist_ip", False)
            self.fields["cond_blacklist_deny"].initial = conds.get("deny_blacklist_ip", False)
            self.fields["cond_api_key"].initial = conds.get("require_api_key", False)
            self.fields["cond_methods"].initial = conds.get("allowed_methods", [])
            self.fields["cond_user_agent_block"].initial = conds.get("deny_user_agent_pattern", "")

    def save(self, commit=True):
        instance = super().save(commit=False)
        conds = {}
        if self.cleaned_data.get("cond_authenticated"):
            conds["require_authenticated"] = True
        if self.cleaned_data.get("cond_staff"):
            conds["require_staff"] = True
        if self.cleaned_data.get("cond_whitelist_ip"):
            conds["require_whitelist_ip"] = True
        if self.cleaned_data.get("cond_blacklist_deny"):
            conds["deny_blacklist_ip"] = True
        if self.cleaned_data.get("cond_api_key"):
            conds["require_api_key"] = True
        methods = self.cleaned_data.get("cond_methods")
        if methods:
            conds["allowed_methods"] = list(methods)
        ua_pattern = self.cleaned_data.get("cond_user_agent_block", "").strip()
        if ua_pattern:
            conds["deny_user_agent_pattern"] = ua_pattern
        instance.conditions = conds
        if commit:
            instance.save()
        return instance


class IPWhitelistEntryForm(forms.ModelForm):
    class Meta:
        model = IPWhitelistEntry
        fields = ["ip_or_cidr", "label", "route", "is_securitykit_access", "is_strict_whitelist", "enabled"]
        widgets = {
            "ip_or_cidr": forms.TextInput(attrs={"placeholder": "192.168.1.1 ou 192.168.1.0/24"}),
        }

    def clean_ip_or_cidr(self):
        value = self.cleaned_data["ip_or_cidr"].strip()
        _validate_ip_or_cidr(value)
        return value


class IPBlacklistEntryForm(forms.ModelForm):
    class Meta:
        model = IPBlacklistEntry
        fields = ["ip_or_cidr", "label", "reason", "route", "enabled", "expires_at"]
        widgets = {
            "ip_or_cidr": forms.TextInput(attrs={"placeholder": "192.168.1.1 ou 192.168.1.0/24"}),
            "expires_at": forms.DateTimeInput(attrs={"type": "datetime-local"}, format="%Y-%m-%dT%H:%M"),
        }

    def clean_ip_or_cidr(self):
        value = self.cleaned_data["ip_or_cidr"].strip()
        _validate_ip_or_cidr(value)
        return value


class APIKeyCreateForm(forms.Form):
    name = forms.CharField(max_length=100, label="Nom de la clé")
    allowed_routes = forms.CharField(
        required=False,
        label="Routes autorisées",
        help_text="Séparées par des virgules. Vide = toutes.",
        widget=forms.TextInput(attrs={"placeholder": "/api/v1/, /api/v2/"}),
    )
    allowed_ips = forms.CharField(
        required=False,
        label="IPs autorisées",
        help_text="Séparées par des virgules. Vide = toutes.",
    )
    expires_at = forms.DateTimeField(
        required=False,
        label="Expiration",
        widget=forms.DateTimeInput(attrs={"type": "datetime-local"}, format="%Y-%m-%dT%H:%M"),
    )


class StrictModeActivateForm(forms.Form):
    MODE_CHOICES = [
        ("strict", "Strict"),
        ("lockdown", "Lockdown"),
    ]
    mode = forms.ChoiceField(choices=MODE_CHOICES, label="Mode")
    reason = forms.CharField(
        required=False,
        max_length=500,
        label="Raison",
        widget=forms.Textarea(attrs={"rows": 2}),
    )


class UnlockCodeForm(forms.Form):
    code = forms.CharField(
        max_length=200,
        label="Code de déverrouillage",
        widget=forms.PasswordInput(attrs={"placeholder": "Code reçu par email", "autocomplete": "off"}),
    )

    def clean_code(self):
        value = self.cleaned_data.get("code", "").strip()
        if len(value) < 10:
            raise forms.ValidationError("Code invalide.")
        return value


class RuleTesterForm(forms.Form):
    path = forms.CharField(
        max_length=500,
        label="Chemin à tester",
        widget=forms.TextInput(attrs={"placeholder": "/admin/"}),
    )
    simulated_ip = forms.CharField(
        max_length=50,
        label="IP simulée",
        initial="127.0.0.1",
    )
    is_authenticated = forms.BooleanField(required=False, label="Utilisateur connecté")
    is_staff = forms.BooleanField(required=False, label="Staff")
    is_superuser = forms.BooleanField(required=False, label="Superuser")
    user_agent = forms.CharField(
        required=False,
        max_length=300,
        label="User-Agent simulé",
        initial="Mozilla/5.0",
    )
    http_method = forms.ChoiceField(
        choices=[("GET", "GET"), ("POST", "POST"), ("PUT", "PUT"), ("DELETE", "DELETE")],
        initial="GET",
        label="Méthode HTTP",
    )


class ConfigImportForm(forms.Form):
    config_file = forms.FileField(
        label="Fichier JSON de configuration",
        help_text="Fichier exporté depuis une autre instance SecurityKit.",
    )

    def clean_config_file(self):
        import json
        f = self.cleaned_data["config_file"]
        if not f.name.endswith(".json"):
            raise forms.ValidationError("Le fichier doit être un .json")
        try:
            content = f.read()
            json.loads(content)
            f.seek(0)
        except Exception:
            raise forms.ValidationError("Fichier JSON invalide.")
        return f


# ---------------------------------------------------------------------------
# Helpers de validation
# ---------------------------------------------------------------------------

def _validate_ip_or_cidr(value: str):
    """Valide une IP simple ou une notation CIDR."""
    import ipaddress
    try:
        ipaddress.ip_network(value, strict=False)
    except ValueError:
        raise forms.ValidationError(f"'{value}' n'est pas une IP ou un CIDR valide.")
