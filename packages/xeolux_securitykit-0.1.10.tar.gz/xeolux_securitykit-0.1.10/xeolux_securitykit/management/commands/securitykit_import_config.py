"""
Commande : securitykit_import_config
Importe une configuration SecurityKit depuis un fichier JSON.
"""

import json
from django.core.management.base import BaseCommand, CommandError


class Command(BaseCommand):
    help = "Importe une configuration SecurityKit depuis un fichier JSON"

    def add_arguments(self, parser):
        parser.add_argument(
            "--input",
            required=True,
            help="Fichier JSON source",
        )
        parser.add_argument(
            "--dry-run",
            action="store_true",
            help="Simule l'import sans modifier la base",
        )

    def handle(self, *args, **options):
        input_file = options["input"]
        dry_run = options["dry_run"]

        try:
            with open(input_file, "r", encoding="utf-8") as f:
                data = json.load(f)
        except FileNotFoundError:
            raise CommandError(f"Fichier introuvable : {input_file}")
        except json.JSONDecodeError as e:
            raise CommandError(f"JSON invalide : {e}")

        if dry_run:
            self.stdout.write(f"[DRY RUN] Fichier valide.")
            self.stdout.write(f"Routes à importer : {len(data.get('protected_routes', []))}")
            self.stdout.write(f"Whitelist : {len(data.get('whitelist', []))}")
            self.stdout.write(f"Blacklist : {len(data.get('blacklist', []))}")
            return

        confirm = input(f"Importer depuis '{input_file}' ? [oui/non] : ")
        if confirm.strip().lower() not in ("oui", "o", "yes", "y"):
            self.stdout.write("Import annulé.")
            return

        from xeolux_securitykit.services.config_storage import import_config
        import_config(data)

        self.stdout.write(f"Configuration importée depuis : {input_file}")
