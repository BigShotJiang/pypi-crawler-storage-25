"""
Commande : securitykit_check
Lance les diagnostics de configuration et affiche un rapport.
"""

from django.core.management.base import BaseCommand
from django.utils.termcolors import colorize


class Command(BaseCommand):
    help = "Vérifie la configuration Django et SecurityKit"

    def handle(self, *args, **options):
        self.stdout.write("\n=== Xeolux SecurityKit — Diagnostics ===\n")

        from xeolux_securitykit.modules.settings_checker import run_diagnostics
        results = run_diagnostics()

        ok_count = 0
        warn_count = 0
        critical_count = 0

        for result in results:
            category = result.get("category", "?")
            check = result.get("check", "?")
            ok = result.get("ok", False)
            severity = result.get("severity", "ok")
            message = result.get("message", "")

            if ok:
                status = colorize("  ✓", fg="green")
                ok_count += 1
            elif severity == "critical":
                status = colorize("  ✗ CRITIQUE", fg="red")
                critical_count += 1
            else:
                status = colorize("  ⚠ AVERTISSEMENT", fg="yellow")
                warn_count += 1

            line = f"[{category}] {check}{status}"
            if message:
                line += f"\n    → {message}"
            self.stdout.write(line)

        self.stdout.write(f"\nRésumé : {ok_count} OK — {warn_count} avertissements — {critical_count} critiques\n")

        # Vérification strict mode
        try:
            from xeolux_securitykit.models import StrictModeState
            state = StrictModeState.get_current()
            mode_color = "red" if state.is_active else "green"
            self.stdout.write(f"Mode strict actuel : {colorize(state.mode.upper(), fg=mode_color)}")
        except Exception as e:
            self.stdout.write(f"Impossible de lire le strict mode : {e}")

        # Vérifications SecurityKit spécifiques
        from xeolux_securitykit.conf import conf
        self.stdout.write(f"\nSecurityKit activé : {colorize('OUI', fg='green') if conf.ENABLED else colorize('NON', fg='red')}")
        self.stdout.write(f"Réponse par défaut : {conf.DEFAULT_RESPONSE}")
        self.stdout.write(f"Chemin interface  : {conf.SECURITYKIT_PATH}")
        self.stdout.write(f"Chemin unlock     : {conf.STRICT_UNLOCK_PATH}\n")
