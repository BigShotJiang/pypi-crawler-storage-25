"""
Commande de secours : securitykit_unlock
Désactive le strict mode et le lockdown depuis le terminal.
"""

from django.core.management.base import BaseCommand


class Command(BaseCommand):
    help = "Désactive le mode strict ou lockdown (commande de secours terminal)"

    def add_arguments(self, parser):
        parser.add_argument(
            "--force",
            action="store_true",
            help="Forcer la désactivation sans confirmation",
        )

    def handle(self, *args, **options):
        from xeolux_securitykit.models import StrictModeState

        try:
            state = StrictModeState.get_current()
        except Exception as e:
            self.stderr.write(f"Erreur lecture DB : {e}")
            return

        current_mode = state.mode

        if current_mode == StrictModeState.MODE_NORMAL:
            self.stdout.write("Le strict mode est déjà désactivé (mode normal).")
            return

        if not options["force"]:
            confirm = input(f"Mode actuel : {current_mode.upper()}. Désactiver ? [oui/non] : ")
            if confirm.strip().lower() not in ("oui", "o", "yes", "y"):
                self.stdout.write("Annulé.")
                return

        state.deactivate()
        self.stdout.write(f"Strict mode désactivé. Mode normal rétabli.")
        self.stdout.write(f"Ancien mode : {current_mode}")
