"""
Commande : securitykit_strict_on
Active le mode strict ou lockdown manuellement depuis le terminal.
"""

from django.core.management.base import BaseCommand


class Command(BaseCommand):
    help = "Active le mode strict ou lockdown manuellement"

    def add_arguments(self, parser):
        parser.add_argument(
            "--mode",
            default="strict",
            choices=["strict", "lockdown"],
            help="Mode à activer : strict (défaut) ou lockdown",
        )
        parser.add_argument(
            "--reason",
            default="Activation manuelle depuis le terminal",
            help="Raison de l'activation",
        )
        parser.add_argument(
            "--no-email",
            action="store_true",
            help="Ne pas envoyer d'email aux super-admins",
        )

    def handle(self, *args, **options):
        mode = options["mode"]
        reason = options["reason"]
        send_email = not options["no_email"]

        from xeolux_securitykit.services.strict_mode import activate_strict_mode
        from xeolux_securitykit.models import StrictModeState

        activate_strict_mode(mode, reason=reason, by="terminal")

        self.stdout.write(f"Mode {mode.upper()} activé.")
        self.stdout.write(f"Raison : {reason}")

        if send_email:
            from xeolux_securitykit.services.unlock_code import generate_and_store_unlock_code
            from xeolux_securitykit.services.super_admin_alert import notify_unlock_code
            raw_code = generate_and_store_unlock_code()
            notify_unlock_code(raw_code)
            self.stdout.write("Email envoyé aux super-admins avec le code de déverrouillage.")
        else:
            self.stdout.write("Email désactivé (--no-email).")

        self.stdout.write("\nPour désactiver depuis le terminal :")
        self.stdout.write("  python manage.py securitykit_unlock --force")
