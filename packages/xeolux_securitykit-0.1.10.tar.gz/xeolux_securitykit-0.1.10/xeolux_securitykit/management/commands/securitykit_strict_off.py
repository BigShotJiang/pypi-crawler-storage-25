"""
Commande : securitykit_strict_off
Désactive le mode strict ou lockdown depuis le terminal.
"""

from django.core.management.base import BaseCommand


class Command(BaseCommand):
    help = "Désactive le mode strict ou lockdown"

    def handle(self, *args, **options):
        from xeolux_securitykit.services.strict_mode import deactivate_strict_mode
        from xeolux_securitykit.models import StrictModeState

        state = StrictModeState.get_current()
        if not state.is_active:
            self.stdout.write("Le strict mode n'est pas actif.")
            return

        deactivate_strict_mode()
        self.stdout.write("Mode strict désactivé. Retour en mode normal.")
