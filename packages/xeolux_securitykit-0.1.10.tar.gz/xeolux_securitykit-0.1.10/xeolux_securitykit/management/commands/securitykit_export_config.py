"""
Commande : securitykit_export_config
Exporte la configuration SecurityKit en JSON.
"""

import json
from django.core.management.base import BaseCommand


class Command(BaseCommand):
    help = "Exporte la configuration SecurityKit en JSON"

    def add_arguments(self, parser):
        parser.add_argument(
            "--output",
            default="securitykit_config.json",
            help="Fichier de sortie (défaut : securitykit_config.json)",
        )
        parser.add_argument(
            "--indent",
            type=int,
            default=2,
            help="Indentation JSON (défaut : 2)",
        )

    def handle(self, *args, **options):
        from xeolux_securitykit.services.config_storage import export_config

        output_file = options["output"]
        indent = options["indent"]

        data = export_config()

        with open(output_file, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=indent, ensure_ascii=False, default=str)

        self.stdout.write(f"Configuration exportée dans : {output_file}")
        self.stdout.write(f"Routes : {len(data.get('protected_routes', []))}")
        self.stdout.write(f"Whitelist : {len(data.get('whitelist', []))}")
        self.stdout.write(f"Blacklist : {len(data.get('blacklist', []))}")
