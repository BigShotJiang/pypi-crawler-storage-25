"""
rules_engine — Moteur central d'évaluation des règles par route.
"""

import re
from django.http import HttpRequest, HttpResponse
from typing import Optional


class RulesEngine:
    """
    Évalue les règles applicables à une requête et produit la réponse si nécessaire.
    Retourne None si aucune règle ne correspond (accès libre).
    """

    @classmethod
    def evaluate(cls, request: HttpRequest, path: str, client_ip: str) -> Optional[HttpResponse]:
        from ..models import ProtectedRoute, RouteRule
        from .condition_engine import ConditionEngine
        from .response_engine import ResponseEngine

        try:
            routes = ProtectedRoute.objects.filter(enabled=True).prefetch_related("rules")
        except Exception:
            return None

        matching_rules = []

        for route in routes:
            if cls._matches_route(path, route):
                for rule in route.rules.filter(enabled=True).order_by("-priority"):
                    matching_rules.append((rule, route))

        if not matching_rules:
            return None

        # Évalue les règles par priorité décroissante
        for rule, route in sorted(matching_rules, key=lambda x: -x[0].priority):
            conditions_met = ConditionEngine.evaluate(rule.conditions, request, client_ip)

            if rule.action == "allow" and conditions_met:
                # Règle d'autorisation explicite satisfaite : laisser passer
                return None

            if rule.action != "allow" and not conditions_met:
                # Conditions non remplies → appliquer l'action de blocage
                return ResponseEngine.produce(request, rule.action, rule.redirect_to)

        return None

    @staticmethod
    def _matches_route(path: str, route) -> bool:
        if route.match_type == "exact":
            return path == route.path
        elif route.match_type == "prefix":
            return path.startswith(route.path)
        elif route.match_type == "regex":
            try:
                return bool(re.match(route.path, path))
            except re.error:
                return False
        return False
