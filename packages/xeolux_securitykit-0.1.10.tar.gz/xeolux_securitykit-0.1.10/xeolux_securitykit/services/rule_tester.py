"""
rule_tester — Interface haut niveau pour tester des règles depuis /securitykit/.
Délègue à DryRunService.
"""

from .dry_run import DryRunService

# Re-export pour cohérence avec l'architecture des 50 modules
__all__ = ["DryRunService"]
