"""
dry_run — Simulation de règles sans application réelle.
"""

from django.http import HttpRequest


class DryRunService:
    """Simule l'évaluation des règles sur un contexte artificiel."""

    @classmethod
    def simulate(cls, form_data: dict, real_request: HttpRequest) -> dict:
        """
        Simule une requête avec les paramètres donnés et retourne le résultat.
        """
        path = form_data.get("path", "/")
        simulated_ip = form_data.get("simulated_ip", "127.0.0.1")
        is_authenticated = form_data.get("is_authenticated", False)
        is_staff = form_data.get("is_staff", False)
        is_superuser = form_data.get("is_superuser", False)
        user_agent = form_data.get("user_agent", "Mozilla/5.0")
        http_method = form_data.get("http_method", "GET")

        # Construction d'un objet requête simulé
        fake_request = _FakeRequest(
            path=path,
            method=http_method,
            user_agent=user_agent,
            is_authenticated=is_authenticated,
            is_staff=is_staff,
            is_superuser=is_superuser,
        )

        # Vérification chemins suspects
        from ..modules.suspicious_paths import is_suspicious_path
        from ..modules.file_access_guard import is_sensitive_file_path
        from ..modules.user_agent_blocker import is_blocked_user_agent
        from ..modules.ip_blacklist import is_ip_blacklisted
        from ..modules.ip_whitelist import is_ip_in_global_whitelist
        from .rules_engine import RulesEngine

        checks = []

        if is_suspicious_path(path):
            checks.append({"check": "suspicious_paths", "result": "BLOQUÉ", "action": "fake_404"})
        else:
            checks.append({"check": "suspicious_paths", "result": "OK"})

        if is_sensitive_file_path(path):
            checks.append({"check": "file_access_guard", "result": "BLOQUÉ", "action": "fake_404"})
        else:
            checks.append({"check": "file_access_guard", "result": "OK"})

        if is_blocked_user_agent(user_agent):
            checks.append({"check": "user_agent_blocker", "result": "BLOQUÉ", "action": "fake_404"})
        else:
            checks.append({"check": "user_agent_blocker", "result": "OK"})

        if is_ip_blacklisted(simulated_ip):
            checks.append({"check": "ip_blacklist", "result": "BLOQUÉ", "action": "fake_404"})
        else:
            checks.append({"check": "ip_blacklist", "result": "OK"})

        response = RulesEngine.evaluate(fake_request, path, simulated_ip)
        if response:
            checks.append({
                "check": "rules_engine",
                "result": f"RÈGLE ACTIVE — statut {response.status_code}",
                "action": f"HTTP {response.status_code}",
            })
        else:
            checks.append({"check": "rules_engine", "result": "Aucune règle → accès libre"})

        final_blocked = any(c.get("result", "").startswith("BLOQUÉ") or "RÈGLE" in c.get("result", "") for c in checks)

        return {
            "path": path,
            "simulated_ip": simulated_ip,
            "checks": checks,
            "final_verdict": "BLOQUÉ" if final_blocked else "AUTORISÉ",
        }


class _FakeRequest:
    """Objet requête minimal pour la simulation."""

    def __init__(self, path, method, user_agent, is_authenticated, is_staff, is_superuser):
        self.path = path
        self.path_info = path
        self.method = method
        self.META = {
            "HTTP_USER_AGENT": user_agent,
            "REMOTE_ADDR": "127.0.0.1",
        }
        self.user = _FakeUser(is_authenticated, is_staff, is_superuser)
        self.COOKIES = {}
        self.GET = {}
        self.POST = {}


class _FakeUser:
    def __init__(self, is_authenticated, is_staff, is_superuser):
        self.is_authenticated = is_authenticated
        self.is_staff = is_staff
        self.is_superuser = is_superuser
        self.username = "simulated"
