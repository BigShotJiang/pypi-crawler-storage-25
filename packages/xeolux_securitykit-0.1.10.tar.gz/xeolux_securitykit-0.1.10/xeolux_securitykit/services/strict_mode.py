"""
strict_mode — Gestion du mode strict et lockdown.

Modes disponibles :
  - STRICT ("whitelist") :
      Seules les IPs présentes dans la whitelist stricte ont accès.
      Cas d'usage : app interne accessible uniquement depuis le bureau/VPN.
      Les permissions Django n'accordent AUCUN passe-droit.

  - LOCKDOWN :
      Personne ne peut accéder au site. Aucune exception.
      La seule porte de sortie est l'URL de déverrouillage dynamique
      (vérifiée en amont dans le middleware, avant ce guard).
"""

from django.http import HttpRequest, HttpResponse
from typing import Optional


class StrictModeGuard:

    @classmethod
    def check(cls, request: HttpRequest, client_ip: str) -> Optional[HttpResponse]:
        from ..models import StrictModeState

        try:
            state = StrictModeState.get_current()
        except Exception:
            return None

        # Lockdown a la priorité absolue — même si whitelist est aussi actif
        if state.lockdown_active:
            return cls._handle_lockdown(request, client_ip, state)

        if state.mode == StrictModeState.MODE_STRICT:
            return cls._handle_strict(request, client_ip, state)

        return None

    @classmethod
    def _maintenance_response(cls, request) -> HttpResponse:
        """Retourne la page de maintenance (503 Service Unavailable)."""
        from django.shortcuts import render
        try:
            return render(request, "xeolux_securitykit/maintenance.html", status=503)
        except Exception:
            return HttpResponse(
                "<html><body style='font-family:system-ui;text-align:center;padding:80px'>"
                "<h1>Maintenance en cours</h1><p>Le site sera de retour très bientôt.</p></body></html>",
                status=503,
            )

    @classmethod
    def _handle_strict(cls, request, client_ip, state) -> Optional[HttpResponse]:
        """
        Mode Whitelist : seules les IPs whitelistées ont accès.
        Les permissions Django (même access_securitykit) ne donnent aucun passe-droit.
        C'est le mode "app interne uniquement".
        """
        from ..modules.ip_whitelist import is_ip_in_strict_whitelist
        if is_ip_in_strict_whitelist(client_ip):
            return None
        return cls._maintenance_response(request)

    @classmethod
    def _handle_lockdown(cls, request, client_ip, state) -> Optional[HttpResponse]:
        """
        Mode Lockdown absolu : personne ne passe.
        La seule exception est l'URL de déverrouillage dynamique,
        vérifiée dans _is_unlock_path() AVANT ce guard dans le middleware.
        """
        return cls._maintenance_response(request)


def activate_strict_mode(mode: str, reason: str = "", by: str = "system"):
    """Active le strict mode (whitelist), génère une URL de déverrouillage unique et envoie un email."""
    from ..models import StrictModeState
    state = StrictModeState.get_current()
    state.activate(mode, reason=reason, by=by)

    # Génère un token URL aléatoire unique pour cette session
    token = state.generate_unlock_token()

    from .super_admin_alert import notify_strict_mode_activated
    notify_strict_mode_activated(mode, reason, unlock_token=token)

    from .unlock_code import generate_and_store_unlock_code
    generate_and_store_unlock_code()


def activate_lockdown_mode(reason: str = "", by: str = "system"):
    """
    Active le lockdown (priorité absolue).
    Peut être activé en plus du mode whitelist — lockdown > whitelist.
    Si aucun token d'unlock n'existe encore, en génère un.
    """
    from ..models import StrictModeState
    state = StrictModeState.get_current()
    state.activate_lockdown(reason=reason, by=by)

    # Générer un token si pas encore présent
    if not state.unlock_token:
        token = state.generate_unlock_token()
    else:
        token = state.unlock_token

    from .super_admin_alert import notify_strict_mode_activated
    notify_strict_mode_activated(StrictModeState.MODE_LOCKDOWN, reason, unlock_token=token)

    from .unlock_code import generate_and_store_unlock_code
    generate_and_store_unlock_code()


def deactivate_lockdown_mode():
    """Désactive uniquement le lockdown. Le mode whitelist reste actif s'il était en cours."""
    from ..models import StrictModeState
    state = StrictModeState.get_current()
    state.deactivate_lockdown()
    # Invalider le token seulement si plus aucun mode actif
    if not state.is_active:
        state.clear_unlock_token()


def deactivate_strict_mode():
    """Désactive le mode whitelist ET le lockdown. Invalide l'URL de déverrouillage."""
    from ..models import StrictModeState
    state = StrictModeState.get_current()
    state.clear_unlock_token()
    state.deactivate()


def get_current_mode() -> str:
    from ..models import StrictModeState
    try:
        return StrictModeState.get_current().effective_mode
    except Exception:
        return StrictModeState.MODE_NORMAL
