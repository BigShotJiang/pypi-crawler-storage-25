"""
module_registry — Registre central des modules SecurityKit disponibles.
"""

from typing import Optional

# Registre en mémoire, initialisé au démarrage de l'app
_REGISTRY: dict[str, dict] = {}


KNOWN_MODULES = [
    # Interface (3)
    {"name": "securitykit_dashboard", "label": "Dashboard", "category": "interface"},
    {"name": "securitykit_ui", "label": "Interface UI", "category": "interface"},
    {"name": "securitykit_self_protection", "label": "Auto-protection /securitykit/", "category": "interface"},
    # Moteur (10)
    {"name": "module_registry", "label": "Registre des modules", "category": "engine"},
    {"name": "rules_engine", "label": "Moteur de règles", "category": "engine"},
    {"name": "condition_engine", "label": "Moteur de conditions", "category": "engine"},
    {"name": "response_engine", "label": "Moteur de réponses", "category": "engine"},
    {"name": "fake_404", "label": "Fake 404", "category": "engine"},
    {"name": "fake_response", "label": "Réponses trompeuses", "category": "engine"},
    {"name": "lockout_safety", "label": "Anti-lockout admin", "category": "engine"},
    {"name": "dry_run", "label": "Dry run / simulation", "category": "engine"},
    {"name": "rule_tester", "label": "Testeur de règles", "category": "engine"},
    # Routes & accès (6)
    {"name": "route_discovery", "label": "Découverte des routes", "category": "routes"},
    {"name": "route_rules", "label": "Règles par route", "category": "routes"},
    {"name": "access_policies", "label": "Politiques d'accès", "category": "access"},
    {"name": "ip_whitelist", "label": "Whitelist IP", "category": "access"},
    {"name": "ip_blacklist", "label": "Blacklist IP", "category": "access"},
    {"name": "permission_guard", "label": "Contrôle des permissions", "category": "access"},
    # Config (3)
    {"name": "config_storage", "label": "Stockage de configuration", "category": "config"},
    {"name": "config_import_export", "label": "Import/Export config", "category": "config"},
    {"name": "security_profiles", "label": "Profils de sécurité", "category": "config"},
    # Protection admin (2)
    {"name": "stealth_admin", "label": "Admin furtif", "category": "admin"},
    {"name": "admin_secret_url", "label": "URL secrète admin", "category": "admin"},
    # Rate limit & anti-abus (4)
    {"name": "rate_limit", "label": "Rate limiting", "category": "rate"},
    {"name": "bruteforce_protection", "label": "Anti brute force", "category": "rate"},
    {"name": "slow_down", "label": "Ralentissement volontaire", "category": "rate"},
    {"name": "anti_ddos", "label": "Anti-DDoS applicatif", "category": "rate"},
    # Détection (4)
    {"name": "suspicious_paths", "label": "Chemins suspects", "category": "detection"},
    {"name": "file_access_guard", "label": "Fichiers sensibles", "category": "detection"},
    {"name": "user_agent_blocker", "label": "Blocage User-Agent", "category": "detection"},
    {"name": "bot_filter", "label": "Filtre bots", "category": "detection"},
    # Formulaires (3)
    {"name": "honeypot", "label": "Honeypot formulaires", "category": "forms"},
    {"name": "form_guard", "label": "Protection formulaires", "category": "forms"},
    {"name": "csrf_guard", "label": "CSRF renforcé", "category": "forms"},
    # API (3)
    {"name": "api_guard", "label": "Protection API", "category": "api"},
    {"name": "api_key_manager", "label": "Gestion clés API", "category": "api"},
    {"name": "webhook_guard", "label": "Protection webhooks", "category": "api"},
    # Headers & réponses (3)
    {"name": "security_headers", "label": "Headers de sécurité", "category": "headers"},
    {"name": "csp_manager", "label": "Content Security Policy", "category": "headers"},
    {"name": "cookie_guard", "label": "Sécurité cookies", "category": "headers"},
    # Requêtes (6)
    {"name": "method_guard", "label": "Méthodes HTTP", "category": "requests"},
    {"name": "header_guard", "label": "Headers entrants", "category": "requests"},
    {"name": "payload_guard", "label": "Contrôle payload", "category": "requests"},
    {"name": "querystring_guard", "label": "QueryString", "category": "requests"},
    {"name": "redirect_guard", "label": "Anti open redirect", "category": "requests"},
    {"name": "cors_guard", "label": "CORS", "category": "requests"},
    # Strict mode (2)
    {"name": "strict_mode", "label": "Strict mode", "category": "strict"},
    {"name": "strict_unlock", "label": "Unlock strict mode", "category": "strict"},
    # Diagnostics (2)
    {"name": "settings_checker", "label": "Diagnostics Django", "category": "diagnostics"},
    {"name": "safe_defaults", "label": "Paramètres sûrs par défaut", "category": "diagnostics"},
]

assert len(KNOWN_MODULES) == 50, f"Attendu 50 modules, trouvé {len(KNOWN_MODULES)}"


def initialize_registry():
    """Initialise le registre à partir des modules connus."""
    global _REGISTRY
    _REGISTRY = {m["name"]: dict(m) for m in KNOWN_MODULES}


def get_all_modules() -> list[dict]:
    """Retourne tous les modules avec leur état activé/désactivé depuis la DB."""
    from ..models import SecurityModuleState

    try:
        states = {s.module_name: s.enabled for s in SecurityModuleState.objects.all()}
    except Exception:
        states = {}

    result = []
    for module in KNOWN_MODULES:
        entry = dict(module)
        entry["enabled"] = states.get(module["name"], True)
        result.append(entry)
    return result


def is_module_enabled(module_name: str) -> bool:
    """Retourne True si le module est actif."""
    from ..models import SecurityModuleState
    try:
        state = SecurityModuleState.objects.get(module_name=module_name)
        return state.enabled
    except SecurityModuleState.DoesNotExist:
        return True  # Par défaut, les modules sont actifs
    except Exception:
        return True


def get_module_info(module_name: str) -> Optional[dict]:
    return _REGISTRY.get(module_name)


# ── Paramètres configurables par module ─────────────────────────────────────
# Chaque clé correspond à un module KNOWN_MODULES.
# Les valeurs sont des listes de tuples (clé_default, label, aide).

MODULE_SETTINGS_KEYS: dict[str, list[tuple[str, str, str]]] = {
    "rate_limit": [
        ("RATE_LIMIT_WINDOW", "Fenêtre de temps (secondes)", "Durée de la fenêtre pour le comptage des requêtes par IP."),
        ("RATE_LIMIT_MAX_REQUESTS", "Requêtes max par fenêtre", "Nombre maximum de requêtes autorisées par IP sur cette fenêtre."),
    ],
    "anti_ddos": [
        ("AUTO_STRICT_THRESHOLD", "Seuil strict mode automatique", "Niveau de menace (0-100) à partir duquel le strict mode s'active automatiquement."),
        ("AUTO_LOCKDOWN_THRESHOLD", "Seuil lockdown automatique", "Niveau de menace (0-100) à partir duquel le lockdown s'active automatiquement."),
    ],
    "bruteforce_protection": [
        ("TEMP_BAN_DURATION", "Durée de bannissement temporaire (secondes)", "Durée pendant laquelle une IP est bannie après trop de tentatives échouées."),
        ("UNLOCK_MAX_ATTEMPTS", "Tentatives max avant ralentissement", "Nombre de tentatives d'unlock échouées avant le slow-down."),
    ],
    "honeypot": [
        ("HONEYPOT_ENABLED", "Activer le honeypot", "Ajoute un champ piège invisible dans les formulaires pour détecter les bots."),
    ],
    "security_headers": [
        ("SECURITY_HEADERS_ENABLED", "Activer les headers de sécurité", "Ajoute automatiquement X-Frame-Options, X-Content-Type-Options, etc. aux réponses."),
    ],
    "stealth_admin": [
        ("STEALTH_ADMIN_ENABLED", "Activer l'admin furtif", "Cache l'URL /admin/ standard et retourne une fake 404."),
        ("ADMIN_SECRET_URL", "URL secrète de l'admin", "URL alternative pour accéder à l'admin Django (laissez vide pour désactiver)."),
    ],
    "strict_mode": [
        ("STRICT_MODE_ENABLED", "Strict mode activable", "Autorise l'activation du strict/lockdown mode depuis l'interface."),
        ("EMAIL_SUPER_ADMINS", "Envoyer un email aux admins", "Envoie un email de notification aux super-admins lors de l'activation du strict mode."),
    ],
    "strict_unlock": [
        ("STRICT_UNLOCK_PATH", "Préfixe URL de déverrouillage", "Préfixe de l'URL de déverrouillage. L'URL complète ajoute un token aléatoire."),
        ("UNLOCK_CODE_TTL", "Durée de vie du code d'unlock (secondes)", "Durée de validité du code à usage unique envoyé par email."),
        ("UNLOCK_CODE_LENGTH", "Longueur du code d'unlock", "Nombre de caractères du code généré aléatoirement."),
        ("UNLOCK_MAX_ATTEMPTS", "Tentatives max avant ralentissement", "Nombre de tentatives d'unlock échouées avant le slow-down."),
    ],
    "securitykit_self_protection": [
        ("SELF_PROTECTION_ENABLED", "Protection de l'interface SecurityKit", "Protège /securitykit/ contre les accès non autorisés."),
    ],
    "lockout_safety": [
        ("LOCKOUT_SAFETY_ENABLED", "Protection anti-lockout", "Empêche de créer des règles qui bloqueraient l'administrateur lui-même."),
    ],
    "fake_404": [
        ("DEFAULT_RESPONSE", "Type de réponse par défaut", "fake_404 = indiscernable d'une vraie 404 | 403 = accès refusé | empty = réponse vide | json = erreur JSON."),
    ],
    "fake_response": [
        ("DEFAULT_RESPONSE", "Type de réponse par défaut", "fake_404 = indiscernable d'une vraie 404 | 403 = accès refusé | empty = réponse vide | json = erreur JSON."),
    ],
    "config_storage": [
        ("CACHE_PREFIX", "Préfixe des clés de cache", "Préfixe utilisé pour toutes les clés de cache du package."),
        ("CACHE_BACKEND", "Backend de cache Django", "Alias du backend cache à utiliser (laissez vide pour le cache par défaut)."),
    ],
    "module_registry": [
        ("ENABLED", "Package activé", "Active ou désactive globalement le package SecurityKit."),
    ],
    "api_guard": [],
    "api_key_manager": [],
    "ip_whitelist": [],
    "ip_blacklist": [],
    "route_rules": [],
    "route_discovery": [],
    "rules_engine": [],
    "condition_engine": [],
    "response_engine": [],
    "dry_run": [],
    "rule_tester": [],
    "bot_filter": [],
    "user_agent_blocker": [],
    "file_access_guard": [],
    "suspicious_paths": [],
    "payload_guard": [],
    "querystring_guard": [],
    "redirect_guard": [],
    "header_guard": [],
    "method_guard": [],
    "cors_guard": [],
    "csp_manager": [],
    "cookie_guard": [],
    "webhook_guard": [],
    "form_guard": [],
    "csrf_guard": [],
    "slow_down": [],
    "admin_secret_url": [
        ("ADMIN_SECRET_URL", "URL secrète de l'admin", "URL alternative pour accéder à l'admin Django (laissez vide pour désactiver)."),
    ],
    "settings_checker": [],
    "safe_defaults": [],
    "access_policies": [],
    "permission_guard": [],
    "config_import_export": [],
    "security_profiles": [],
    "securitykit_dashboard": [],
    "securitykit_ui": [],
}


def get_module_settings_keys(module_name: str) -> list[tuple[str, str, str]]:
    """Retourne la liste des paramètres configurables pour un module donné."""
    return MODULE_SETTINGS_KEYS.get(module_name, [])
