"""
attack_signature — Signatures de comportements d'attaque connus.
"""

ATTACK_SIGNATURES = [
    {
        "name": "wp_scan",
        "description": "Scan WordPress",
        "path_patterns": [
            "wp-admin", "wp-login", "wp-content", "wp-includes", "xmlrpc.php",
        ],
    },
    {
        "name": "env_leak",
        "description": "Tentative de lecture .env",
        "path_patterns": [".env", ".env.local", ".env.production"],
    },
    {
        "name": "git_exposure",
        "description": "Tentative d'accès .git",
        "path_patterns": [".git/", ".git/config", ".git/HEAD"],
    },
    {
        "name": "db_dump",
        "description": "Tentative de téléchargement dump DB",
        "path_patterns": ["dump.sql", "backup.sql", "database.sql", "db.sql"],
    },
    {
        "name": "phpmyadmin",
        "description": "Scan phpMyAdmin",
        "path_patterns": ["phpmyadmin", "pma", "phpMyAdmin"],
    },
    {
        "name": "path_traversal",
        "description": "Tentative de traversal de répertoire",
        "path_patterns": ["../", "..\\", "%2e%2e", "%2F.."],
    },
]


def matches_signature(path: str) -> str | None:
    """Retourne le nom de la signature si le chemin correspond, None sinon."""
    path_lower = path.lower()
    for sig in ATTACK_SIGNATURES:
        for pattern in sig["path_patterns"]:
            if pattern.lower() in path_lower:
                return sig["name"]
    return None
