"""
unlock_code — Génération et vérification des codes de déverrouillage strict mode.
"""

import logging

logger = logging.getLogger("xeolux_securitykit")


def generate_and_store_unlock_code() -> str:
    """
    Génère un code de déverrouillage, le stocke hashé en DB,
    et retourne le code brut pour l'envoyer par email.
    """
    from ..models import UnlockCode
    from ..conf import conf

    ttl = conf.UNLOCK_CODE_TTL
    instance, raw_code = UnlockCode.generate(ttl_seconds=ttl)
    logger.info("xeolux_securitykit: code d'unlock généré (pk=%s)", instance.pk)
    return raw_code


def verify_and_consume_unlock_code(raw_code: str):
    """
    Vérifie un code de déverrouillage.
    Retourne (True, "") si valide, (False, raison) sinon.
    Invalide le code après usage réussi.
    """
    from ..models import UnlockCode

    try:
        # Cherche parmi les codes non utilisés et non expirés
        from django.utils import timezone
        candidates = UnlockCode.objects.filter(used=False)

        for candidate in candidates:
            if candidate.verify(raw_code):
                if not candidate.is_valid():
                    return False, "Code expiré."
                candidate.consume()
                return True, ""

        return False, "Code invalide."

    except Exception as e:
        logger.exception("xeolux_securitykit: erreur vérification code unlock : %s", e)
        return False, "Erreur interne."
