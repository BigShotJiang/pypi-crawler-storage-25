"""
attack_detector — Détection de comportements d'attaque applicative.
"""

import logging
from django.core.cache import cache

logger = logging.getLogger("xeolux_securitykit")

_SCAN_PREFIX = "xeolux_sk_scan_"


class AttackDetector:
    """
    Détecte les comportements typiques d'attaque :
    - Scan de routes (accumulation de 404)
    - Bruteforce (tentatives répétées sur une route auth)
    - Comportement bot (trop de routes trop vite)
    """

    @classmethod
    def record_suspicious_request(cls, client_ip: str, path: str, reason: str):
        """Enregistre un événement suspect et retourne le score courant."""
        from .threat_level import ThreatLevel

        score_map = {
            "404_scan": 2,
            "suspicious_path": 5,
            "blocked_ua": 3,
            "bruteforce": 10,
            "flood": 15,
            "sensitive_file": 5,
        }
        score = score_map.get(reason, 1)
        total = ThreatLevel.add_score(client_ip, score)
        logger.info(
            "xeolux_securitykit: événement suspect — ip=%s path=%s raison=%s score_total=%d",
            client_ip, path, reason, total,
        )
        return total

    @classmethod
    def record_404(cls, client_ip: str, path: str) -> int:
        """Enregistre un 404 et retourne le nombre de 404 récents."""
        from .anti_ddos import AntiDDOS
        count = AntiDDOS.record_404(client_ip)
        if count >= 20:
            cls.record_suspicious_request(client_ip, path, "404_scan")
        return count
