"""
anti_ddos — Protection applicative contre le flood HTTP et les comportements anormaux.
"""

import logging
from django.core.cache import cache
from django.http import HttpRequest, HttpResponse
from typing import Optional

logger = logging.getLogger("xeolux_securitykit")

_RATE_PREFIX = "xeolux_sk_rate_"
_FLOOD_PREFIX = "xeolux_sk_flood_"
_404_PREFIX = "xeolux_sk_404count_"


class AntiDDOS:
    """
    Protection applicative contre :
    - Flood HTTP par IP
    - Accumulation de 404 (scan de routes)
    - Requêtes répétées sur routes sensibles
    """

    @classmethod
    def check(cls, request: HttpRequest, client_ip: str) -> Optional[HttpResponse]:
        from ..conf import conf
        from .fake_response import build_response

        # Rate limit global par IP
        if not cls._check_rate_limit(client_ip, conf.RATE_LIMIT_WINDOW, conf.RATE_LIMIT_MAX_REQUESTS):
            logger.warning("xeolux_securitykit: rate limit dépassé pour %s", client_ip)
            cls._record_threat(client_ip, score=10)
            return build_response(request, "429")

        # Détection du flood (beaucoup de requêtes très rapides)
        if cls._is_flooding(client_ip):
            logger.warning("xeolux_securitykit: flood détecté depuis %s", client_ip)
            cls._record_threat(client_ip, score=30)
            return build_response(request, "fake_404")

        return None

    @classmethod
    def _check_rate_limit(cls, client_ip: str, window: int, max_req: int) -> bool:
        """Retourne True si la limite n'est pas dépassée."""
        key = _RATE_PREFIX + client_ip
        count = cache.get(key, 0)
        if count >= max_req:
            return False
        cache.set(key, count + 1, timeout=window)
        return True

    @classmethod
    def _is_flooding(cls, client_ip: str) -> bool:
        """Détecte un comportement de flood dans une fenêtre de 5 secondes."""
        key = _FLOOD_PREFIX + client_ip
        count = cache.get(key, 0)
        if count >= 50:  # Plus de 50 requêtes en 5 secondes
            return True
        cache.set(key, count + 1, timeout=5)
        return False

    @classmethod
    def record_404(cls, client_ip: str) -> int:
        """Incrémente le compteur de 404 pour une IP. Retourne le total."""
        key = _404_PREFIX + client_ip
        count = cache.get(key, 0) + 1
        cache.set(key, count, timeout=300)  # Fenêtre de 5 minutes
        return count

    @classmethod
    def _record_threat(cls, client_ip: str, score: int):
        """Enregistre un score de menace et déclenche le strict mode si nécessaire."""
        from ..services.threat_level import ThreatLevel
        ThreatLevel.add_score(client_ip, score)
