"""
route_discovery — Découverte automatique des routes Django du projet.
"""

from django.urls import get_resolver


def discover_routes() -> list[dict]:
    """
    Parcourt les URLconf du projet et retourne une liste de routes.
    Retourne : [{"pattern": "...", "name": "...", "view": "..."}, ...]
    """
    resolver = get_resolver()
    routes = []
    _collect(resolver, prefix="", routes=routes)
    return sorted(routes, key=lambda r: r["pattern"])


def _collect(resolver, prefix: str, routes: list):
    from django.urls import URLPattern, URLResolver

    for pattern in resolver.url_patterns:
        current_prefix = prefix + _pattern_to_str(pattern.pattern)
        if isinstance(pattern, URLResolver):
            _collect(pattern, current_prefix, routes)
        elif isinstance(pattern, URLPattern):
            view_name = getattr(pattern.callback, "__name__", str(pattern.callback))
            module = getattr(pattern.callback, "__module__", "")
            routes.append({
                "pattern": current_prefix or "/",
                "name": pattern.name or "",
                "view": f"{module}.{view_name}",
            })


def _pattern_to_str(pattern) -> str:
    try:
        return pattern._route
    except AttributeError:
        try:
            return pattern.regex.pattern
        except AttributeError:
            return str(pattern)
