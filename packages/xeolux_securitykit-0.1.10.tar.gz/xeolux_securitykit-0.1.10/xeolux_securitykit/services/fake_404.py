"""
fake_404 — Service central du module Fake 404.
Fournit une interface simple pour retourner une vraie 404 HTTP.
"""

from django.http import HttpRequest, HttpResponse


def send_fake_404(request: HttpRequest) -> HttpResponse:
    """Retourne une vraie réponse HTTP 404, indépendamment de la route réelle."""
    from ..responses import fake_404_response
    return fake_404_response(request)


def should_apply_fake_404(request: HttpRequest, path: str, client_ip: str) -> bool:
    """
    Détermine si la fake 404 doit s'appliquer sur ce chemin
    selon les règles définies en base de données.
    """
    from ..services.rules_engine import RulesEngine
    response = RulesEngine.evaluate(request, path, client_ip)
    return response is not None and response.status_code == 404
