"""
email_templates — Construction des corps d'emails de sécurité.
"""

from django.utils import timezone


def render_strict_mode_email(mode: str, reason: str, unlock_url: str = "") -> tuple[str, str]:
    subject = f"[SecurityKit] Mode {mode.upper()} activé sur votre site"
    body = f"""Bonjour,

Le mode de sécurité renforcé "{mode.upper()}" a été activé sur votre site Django.

Heure : {timezone.now().strftime('%Y-%m-%d %H:%M:%S UTC')}
Raison : {reason or 'Non spécifiée'}

En mode {mode}, seules les IP whitelistées {'et les superusers ' if mode == 'strict' else ''}peuvent accéder au site.

URL de déverrouillage (unique, valable une seule session) :
{unlock_url}

Cette URL est confidentielle et change à chaque activation.
Ne la partagez pas.

Un code de déverrouillage vous sera envoyé séparément dans un second email.

Pour désactiver via terminal : python manage.py securitykit_unlock

-- Xeolux SecurityKit
"""
    return subject, body


def render_lockdown_email(reason: str, unlock_url: str = "") -> tuple[str, str]:
    subject = "[SecurityKit] LOCKDOWN activé sur votre site"
    body = f"""ALERTE DE SÉCURITÉ

Le mode LOCKDOWN a été activé sur votre site Django.

Heure : {timezone.now().strftime('%Y-%m-%d %H:%M:%S UTC')}
Raison : {reason or 'Activité suspecte détectée'}

En mode lockdown, AUCUNE requête n'est autorisée sauf les IP en whitelist stricte.

URL de déverrouillage (unique, valable une seule session) :
{unlock_url}

Cette URL est confidentielle et change à chaque activation.

Actions requises :
1. Vérifiez les accès récents à votre serveur.
2. Ajoutez votre IP à la whitelist stricte si nécessaire.
3. Désactivez le lockdown depuis l'URL ci-dessus ou via :
   python manage.py securitykit_unlock

-- Xeolux SecurityKit (URGENT)
"""
    return subject, body


def render_unlock_code_email(raw_code: str, unlock_url: str = "") -> tuple[str, str]:
    from ..conf import conf
    ttl_minutes = conf.UNLOCK_CODE_TTL // 60

    subject = "[SecurityKit] Code de déverrouillage strict mode"
    body = f"""Bonjour,

Voici votre code de déverrouillage pour désactiver le mode strict/lockdown.

Code : {raw_code}

Ce code est valable {ttl_minutes} minutes.
Il ne peut être utilisé qu'une seule fois.

Rendez-vous sur cette URL pour entrer le code :
{unlock_url or '(URL disponible dans l\'email d\'activation du strict mode)'}

Si vous n'avez pas demandé ce code, votre site est peut-être sous attaque.
Connectez-vous en SSH et exécutez :
    python manage.py securitykit_unlock

-- Xeolux SecurityKit
"""
    return subject, body
