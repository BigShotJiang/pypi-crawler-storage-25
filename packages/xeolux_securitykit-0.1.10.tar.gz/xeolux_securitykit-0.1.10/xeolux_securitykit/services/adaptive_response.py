"""
adaptive_response — Réponse adaptative en fonction du niveau de menace.
"""

from django.http import HttpRequest, HttpResponse
from typing import Optional


class AdaptiveResponse:
    """Choisit la réponse en fonction du niveau de menace courant."""

    @classmethod
    def get_response(cls, request: HttpRequest, client_ip: str, base_action: str) -> Optional[HttpResponse]:
        from .threat_level import ThreatLevel
        from .fake_response import build_response

        score = ThreatLevel.get_score(client_ip)

        if score >= 50:
            # Menace élevée : fake 404 systématique
            return build_response(request, "fake_404")
        elif score >= 20:
            # Menace modérée : ralentissement
            return cls._slow_response(request)
        else:
            return build_response(request, base_action)

    @staticmethod
    def _slow_response(request: HttpRequest) -> HttpResponse:
        """Délai volontaire de 1 à 3 secondes selon le score."""
        import time
        time.sleep(1.5)
        from ..responses import fake_404_response
        return fake_404_response(request)
