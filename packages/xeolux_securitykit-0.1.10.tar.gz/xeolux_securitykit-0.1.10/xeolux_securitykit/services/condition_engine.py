"""
condition_engine — Évalue les conditions d'une règle face à une requête.
"""

import ipaddress
from django.http import HttpRequest


class ConditionEngine:
    """
    Évalue un dictionnaire de conditions et retourne True si toutes sont remplies.

    Conditions supportées :
        require_authenticated: bool
        require_staff: bool
        require_superuser: bool
        require_whitelist_ip: bool
        deny_blacklist_ip: bool
        deny_user_agent_pattern: str (regex)
        allowed_methods: list[str]
        require_api_key: bool
        allowed_hours: list[int]  (heures UTC 0-23)
        strict_mode_active: bool
    """

    @classmethod
    def evaluate(cls, conditions: dict, request: HttpRequest, client_ip: str) -> bool:
        """
        Retourne True si toutes les conditions sont remplies (accès autorisé).
        Retourne False si une condition échoue (accès refusé).
        """
        for condition, value in conditions.items():
            if not cls._check(condition, value, request, client_ip):
                return False
        return True

    @classmethod
    def _check(cls, condition: str, value, request: HttpRequest, client_ip: str) -> bool:
        user = request.user

        if condition == "require_authenticated":
            if value and not user.is_authenticated:
                return False

        elif condition == "require_staff":
            if value and not (user.is_authenticated and user.is_staff):
                return False

        elif condition == "require_superuser":
            if value and not (user.is_authenticated and user.is_superuser):
                return False

        elif condition == "deny_blacklist_ip":
            if value:
                from ..modules.ip_blacklist import is_ip_blacklisted
                if is_ip_blacklisted(client_ip):
                    return False

        elif condition == "require_whitelist_ip":
            if value:
                from ..modules.ip_whitelist import is_ip_in_global_whitelist
                if not is_ip_in_global_whitelist(client_ip):
                    return False

        elif condition == "deny_user_agent_pattern":
            if value:
                import re
                ua = request.META.get("HTTP_USER_AGENT", "")
                if re.search(value, ua, re.IGNORECASE):
                    return False

        elif condition == "allowed_methods":
            if value and request.method not in value:
                return False

        elif condition == "require_api_key":
            if value:
                from ..modules.api_guard import has_valid_api_key
                if not has_valid_api_key(request):
                    return False

        elif condition == "allowed_hours":
            if value:
                from django.utils import timezone
                current_hour = timezone.now().hour
                if current_hour not in value:
                    return False

        elif condition == "strict_mode_active":
            from ..models import StrictModeState
            state = StrictModeState.get_current()
            is_active = state.is_active
            if value and not is_active:
                return False
            if not value and is_active:
                return False

        return True
