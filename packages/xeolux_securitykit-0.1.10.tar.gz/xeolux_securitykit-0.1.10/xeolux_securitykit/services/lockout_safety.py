"""
lockout_safety — Empêche l'administrateur de se bloquer lui-même hors de l'interface.
"""

from django.http import HttpRequest


def check_rule_safety(request: HttpRequest, rule) -> tuple[bool, str]:
    """
    Vérifie qu'une règle ne bloquera pas le superuser courant.
    Retourne (True, "") si sûr, (False, raison) si dangereux.
    """
    from ..conf import conf
    if not conf.LOCKOUT_SAFETY_ENABLED:
        return True, ""

    path = rule.route.path if hasattr(rule, "route") and rule.route else ""

    # Si la règle cible /securitykit/ et que l'action est un blocage
    sk_path = conf.SECURITYKIT_PATH
    if path and path.startswith(sk_path):
        if rule.action in ("fake_404", "403", "empty"):
            conditions = rule.conditions or {}
            # Si la règle exclut les superusers
            if not conditions.get("require_superuser", False):
                return (
                    False,
                    f"Cette règle bloquerait /securitykit/ sans exception superuser. "
                    f"Ajoutez 'require_superuser: true' aux conditions.",
                )

    # Si la règle bloque l'IP courante sur /securitykit/
    if path and path.startswith(sk_path):
        client_ip = _get_client_ip(request)
        conditions = rule.conditions or {}
        if conditions.get("require_whitelist_ip"):
            from ..modules.ip_whitelist import is_ip_in_global_whitelist
            if not is_ip_in_global_whitelist(client_ip):
                return (
                    False,
                    f"Votre IP ({client_ip}) n'est pas dans la whitelist. "
                    f"Cette règle vous bloquerait hors de l'interface.",
                )

    return True, ""


def check_route_delete_safety(request: HttpRequest, route) -> tuple[bool, str]:
    """Vérifie que la suppression d'une route ne compromet pas l'accès admin."""
    # Pas de restriction particulière sur la suppression de routes
    return True, ""


def check_whitelist_delete_safety(request: HttpRequest, entry) -> tuple[bool, str]:
    """
    Vérifie que supprimer une entrée whitelist ne bloque pas le superuser courant
    hors de /securitykit/.
    """
    from ..conf import conf
    if not conf.LOCKOUT_SAFETY_ENABLED:
        return True, ""

    if entry.is_securitykit_access:
        client_ip = _get_client_ip(request)
        import ipaddress
        try:
            network = ipaddress.ip_network(entry.ip_or_cidr, strict=False)
            addr = ipaddress.ip_address(client_ip)
            if addr in network:
                return (
                    False,
                    f"Vous ne pouvez pas supprimer votre propre IP ({client_ip}) "
                    f"de la whitelist /securitykit/.",
                )
        except ValueError:
            pass

    return True, ""


def _get_client_ip(request: HttpRequest) -> str:
    x_forwarded = request.META.get("HTTP_X_FORWARDED_FOR")
    if x_forwarded:
        return x_forwarded.split(",")[0].strip()
    return request.META.get("REMOTE_ADDR", "")
