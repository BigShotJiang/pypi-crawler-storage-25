"""
fake_response — Centralise la construction des réponses de blocage.
"""

from django.http import HttpRequest, HttpResponse


def build_response(request: HttpRequest, action: str, redirect_to: str = "") -> HttpResponse:
    """
    Construit la réponse adaptée selon l'action demandée.
    Ne révèle jamais la vraie raison du blocage.
    """
    from ..responses import (
        fake_404_response,
        forbidden_response,
        empty_response,
        json_neutral_response,
        redirect_neutral_response,
        too_many_requests_response,
    )

    if action == "fake_404":
        return fake_404_response(request)
    elif action == "403":
        return forbidden_response(request)
    elif action == "empty":
        return empty_response()
    elif action == "json":
        return json_neutral_response()
    elif action == "redirect" and redirect_to:
        return redirect_neutral_response(redirect_to)
    elif action == "429":
        return too_many_requests_response(request)
    else:
        # Par défaut : fake 404
        return fake_404_response(request)
