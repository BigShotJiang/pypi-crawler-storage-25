"""
config_storage — Accès unifié à la configuration en base et depuis settings.py.

La priorité est : DB > settings.py > DEFAULTS
La DB est la source de vérité ; settings.py sert de bootstrap/override ponctuel.
"""

from typing import Any
from ..conf import conf
from ..defaults import DEFAULTS


def get_config(key: str, default=None) -> Any:
    """Retourne la valeur de configuration (DB > settings > defaults)."""
    return conf.get(key, default if default is not None else DEFAULTS.get(key))


def set_db_config(key: str, value, description: str = ""):
    """
    Stocke une valeur de configuration en base de données.
    La valeur est convertie en string pour le stockage.
    """
    from ..models import SecurityKitConfig
    import json
    if isinstance(value, (list, dict)):
        str_value = json.dumps(value)
    else:
        str_value = str(value)
    obj, _ = SecurityKitConfig.objects.update_or_create(
        key=key,
        defaults={"value": str_value, "description": description},
    )
    return obj


def get_db_config(key: str, default: str = "") -> str:
    """Lit une valeur brute (string) depuis la base de données."""
    from ..models import SecurityKitConfig
    try:
        return SecurityKitConfig.objects.get(key=key).value
    except Exception:
        return default


def delete_db_config(key: str) -> bool:
    """Supprime une entrée de config DB (le default reprendra effet)."""
    from ..models import SecurityKitConfig
    deleted, _ = SecurityKitConfig.objects.filter(key=key).delete()
    return deleted > 0


def export_config() -> dict:
    """Exporte toute la configuration en dictionnaire JSON-serializable."""
    from ..models import (
        SecurityKitConfig, SecurityModuleState,
        ProtectedRoute, RouteRule,
        IPWhitelistEntry, IPBlacklistEntry,
        APIKey, SecurityProfile,
    )
    return {
        "version": "1",
        "db_configs": list(
            SecurityKitConfig.objects.values("key", "value", "description")
        ),
        "module_states": list(
            SecurityModuleState.objects.values("module_name", "enabled")
        ),
        "protected_routes": [
            {
                "path": r.path,
                "match_type": r.match_type,
                "description": r.description,
                "enabled": r.enabled,
                "rules": list(r.rules.values(
                    "action", "conditions", "redirect_to", "priority", "enabled", "description"
                )),
            }
            for r in ProtectedRoute.objects.prefetch_related("rules").all()
        ],
        "whitelist": list(
            IPWhitelistEntry.objects.values(
                "ip_or_cidr", "label", "is_securitykit_access", "enabled"
            )
        ),
        "blacklist": list(
            IPBlacklistEntry.objects.values(
                "ip_or_cidr", "label", "reason", "enabled"
            )
        ),
    }


def import_config(data: dict):
    """Importe une configuration depuis un dictionnaire."""
    from ..models import (
        SecurityKitConfig, SecurityModuleState,
        ProtectedRoute, RouteRule,
        IPWhitelistEntry, IPBlacklistEntry,
    )

    for item in data.get("db_configs", []):
        set_db_config(item["key"], item["value"], item.get("description", ""))

    for item in data.get("module_states", []):
        SecurityModuleState.objects.update_or_create(
            module_name=item["module_name"],
            defaults={"enabled": item["enabled"]},
        )

    for route_data in data.get("protected_routes", []):
        route, _ = ProtectedRoute.objects.update_or_create(
            path=route_data["path"],
            defaults={
                "match_type": route_data.get("match_type", "exact"),
                "description": route_data.get("description", ""),
                "enabled": route_data.get("enabled", True),
            },
        )
        for rule_data in route_data.get("rules", []):
            RouteRule.objects.create(
                route=route,
                action=rule_data["action"],
                conditions=rule_data.get("conditions", {}),
                redirect_to=rule_data.get("redirect_to", ""),
                priority=rule_data.get("priority", 10),
                enabled=rule_data.get("enabled", True),
                description=rule_data.get("description", ""),
            )

    for item in data.get("whitelist", []):
        IPWhitelistEntry.objects.get_or_create(
            ip_or_cidr=item["ip_or_cidr"],
            defaults={
                "label": item.get("label", ""),
                "is_securitykit_access": item.get("is_securitykit_access", False),
                "enabled": item.get("enabled", True),
            },
        )

    for item in data.get("blacklist", []):
        IPBlacklistEntry.objects.get_or_create(
            ip_or_cidr=item["ip_or_cidr"],
            defaults={
                "label": item.get("label", ""),
                "reason": item.get("reason", ""),
                "enabled": item.get("enabled", True),
            },
        )


def get_builtin_profiles() -> list:
    """Retourne les profils de sécurité prédéfinis."""
    return [
        {
            "name": "dev",
            "label": "Développement",
            "description": "Protections minimales, pour le développement local.",
        },
        {
            "name": "standard",
            "label": "Standard",
            "description": "Protections équilibrées pour la plupart des projets.",
        },
        {
            "name": "strict",
            "label": "Strict",
            "description": "Protections renforcées, bloque agressivement.",
        },
        {
            "name": "stealth",
            "label": "Furtif",
            "description": "Masque l'admin, retourne des fake 404 sur routes sensibles.",
        },
        {
            "name": "api_only",
            "label": "API uniquement",
            "description": "Optimisé pour les projets Django API sans interface web.",
        },
        {
            "name": "admin_hardened",
            "label": "Admin renforcé",
            "description": "Protège spécifiquement l'administration Django.",
        },
    ]


def apply_security_profile(profile_name: str) -> tuple[bool, str]:
    """Applique un profil de sécurité prédéfini."""
    from ..models import SecurityModuleState

    profiles_config = {
        "dev": {
            "rate_limit": False,
            "suspicious_paths": True,
            "security_headers": False,
            "anti_ddos": False,
        },
        "standard": {
            "rate_limit": True,
            "suspicious_paths": True,
            "security_headers": True,
            "anti_ddos": True,
            "user_agent_blocker": True,
        },
        "strict": {
            "rate_limit": True,
            "suspicious_paths": True,
            "security_headers": True,
            "anti_ddos": True,
            "user_agent_blocker": True,
            "bot_filter": True,
            "bruteforce_protection": True,
            "file_access_guard": True,
        },
        "stealth": {
            "stealth_admin": True,
            "suspicious_paths": True,
            "security_headers": True,
            "user_agent_blocker": True,
        },
        "api_only": {
            "api_guard": True,
            "rate_limit": True,
            "method_guard": True,
            "cors_guard": True,
        },
        "admin_hardened": {
            "stealth_admin": True,
            "bruteforce_protection": True,
            "ip_whitelist": True,
            "security_headers": True,
        },
    }

    config = profiles_config.get(profile_name)
    if not config:
        return False, f"Profil '{profile_name}' inconnu."

    for module_name, enabled in config.items():
        SecurityModuleState.objects.update_or_create(
            module_name=module_name,
            defaults={"enabled": enabled},
        )
    return True, "OK"
