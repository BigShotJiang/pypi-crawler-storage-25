"""
super_admin_alert — Envoi d'emails aux super-admins lors d'incidents de sécurité.
"""

import logging
from django.conf import settings
from django.core.mail import send_mail
from django.utils import timezone

logger = logging.getLogger("xeolux_securitykit")


def _get_super_admin_emails() -> list[str]:
    """Retourne la liste des emails des super-admins."""
    from django.contrib.auth import get_user_model
    User = get_user_model()
    return list(
        User.objects.filter(is_superuser=True, is_active=True)
        .exclude(email="")
        .values_list("email", flat=True)
    )


def notify_strict_mode_activated(mode: str, reason: str = "", unlock_token: str = ""):
    """Envoie un email aux super-admins quand le strict mode est activé."""
    from ..conf import conf
    if not conf.EMAIL_SUPER_ADMINS:
        return

    recipients = _get_super_admin_emails()
    if not recipients:
        logger.warning("xeolux_securitykit: aucun email super-admin trouvé pour notification.")
        return

    from .email_templates import render_strict_mode_email
    # Construire l'URL de déverrouillage complète avec le token dynamique
    unlock_url = _build_unlock_url(unlock_token, conf)
    subject, body = render_strict_mode_email(mode, reason, unlock_url=unlock_url)

    _send(subject, body, recipients)


def notify_lockdown_activated(reason: str = "", unlock_token: str = ""):
    """Envoie un email quand le lockdown est activé."""
    from ..conf import conf
    if not conf.EMAIL_SUPER_ADMINS:
        return

    recipients = _get_super_admin_emails()
    if not recipients:
        return

    unlock_url = _build_unlock_url(unlock_token, conf)
    from .email_templates import render_lockdown_email
    subject, body = render_lockdown_email(reason, unlock_url=unlock_url)
    _send(subject, body, recipients)


def notify_unlock_code(raw_code: str):
    """Envoie le code de déverrouillage aux super-admins."""
    from ..conf import conf
    if not conf.EMAIL_SUPER_ADMINS:
        return

    recipients = _get_super_admin_emails()
    if not recipients:
        logger.error("xeolux_securitykit: impossible d'envoyer le code unlock, aucun email.")
        return

    # Récupérer l'URL dynamique courante pour l'inclure dans le mail
    unlock_token = ""
    try:
        from ..models import StrictModeState
        unlock_token = StrictModeState.objects.filter(pk=1).values_list("unlock_token", flat=True).first() or ""
    except Exception:
        pass
    unlock_url = _build_unlock_url(unlock_token, conf)

    from .email_templates import render_unlock_code_email
    subject, body = render_unlock_code_email(raw_code, unlock_url=unlock_url)
    _send(subject, body, recipients)


def _build_unlock_url(token: str, conf) -> str:
    """Construit l'URL absolue de déverrouillage avec le token dynamique."""
    if not token:
        return "(URL indisponible — token non généré)"
    base_path = conf.STRICT_UNLOCK_PATH.rstrip("/")
    # Utilise SITE_URL si défini, sinon chemin relatif
    site_url = getattr(settings, "SITE_URL", "").rstrip("/")
    if site_url:
        return f"{site_url}{base_path}/{token}/"
    return f"{base_path}/{token}/"


def _send(subject: str, body: str, recipients: list[str]):
    from_email = getattr(settings, "DEFAULT_FROM_EMAIL", "noreply@localhost")
    try:
        send_mail(
            subject=subject,
            message=body,
            from_email=from_email,
            recipient_list=recipients,
            fail_silently=False,
        )
        logger.info("xeolux_securitykit: email envoyé à %d destinataire(s).", len(recipients))
    except Exception as e:
        logger.error("xeolux_securitykit: échec envoi email : %s", e)
