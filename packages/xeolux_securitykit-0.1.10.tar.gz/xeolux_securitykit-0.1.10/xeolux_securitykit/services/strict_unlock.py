"""
strict_unlock — Service de déverrouillage du strict mode depuis la page web.
"""

import logging
from django.core.cache import cache

logger = logging.getLogger("xeolux_securitykit")

_THROTTLE_PREFIX = "xeolux_sk_unlock_throttle_"
_ATTEMPT_PREFIX = "xeolux_sk_unlock_attempts_"


class UnlockService:
    """Gère les tentatives de déverrouillage strict mode."""

    @classmethod
    def attempt_unlock(cls, raw_code: str, client_ip: str) -> tuple[bool, str]:
        """Tente de déverrouiller le strict mode avec le code fourni."""
        from .unlock_code import verify_and_consume_unlock_code
        from .strict_mode import deactivate_strict_mode

        ok, msg = verify_and_consume_unlock_code(raw_code)
        if ok:
            deactivate_strict_mode()
            cls._clear_throttle(client_ip)
            logger.info("xeolux_securitykit: strict mode déverrouillé depuis %s", client_ip)
            return True, ""
        return False, msg

    @classmethod
    def is_throttled(cls, client_ip: str) -> bool:
        """Retourne True si l'IP a trop tenté de déverrouiller."""
        from ..conf import conf
        key = _THROTTLE_PREFIX + client_ip
        count = cache.get(key, 0)
        return count >= conf.UNLOCK_MAX_ATTEMPTS

    @classmethod
    def record_failed_attempt(cls, client_ip: str):
        """Enregistre une tentative échouée et applique le throttling."""
        from ..conf import conf
        key = _THROTTLE_PREFIX + client_ip
        current = cache.get(key, 0)
        # Bloque l'IP pour 15 minutes après dépassement du seuil
        cache.set(key, current + 1, timeout=900)

    @classmethod
    def _clear_throttle(cls, client_ip: str):
        key = _THROTTLE_PREFIX + client_ip
        cache.delete(key)
