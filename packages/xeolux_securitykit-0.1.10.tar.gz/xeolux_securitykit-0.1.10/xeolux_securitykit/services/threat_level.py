"""
threat_level — Calcul et gestion du niveau de menace global et par IP.
"""

import logging
from django.core.cache import cache

logger = logging.getLogger("xeolux_securitykit")

_THREAT_PREFIX = "xeolux_sk_threat_"
_GLOBAL_THREAT_KEY = "xeolux_sk_global_threat"


class ThreatLevel:
    """Gère les scores de menace par IP et le niveau global."""

    @classmethod
    def add_score(cls, client_ip: str, score: int) -> int:
        """Ajoute un score de menace pour une IP et vérifie les seuils."""
        key = _THREAT_PREFIX + client_ip
        current = cache.get(key, 0) + score
        cache.set(key, current, timeout=3600)

        global_current = cache.get(_GLOBAL_THREAT_KEY, 0) + score
        cache.set(_GLOBAL_THREAT_KEY, global_current, timeout=3600)

        cls._check_thresholds(client_ip, current)
        return current

    @classmethod
    def get_score(cls, client_ip: str) -> int:
        key = _THREAT_PREFIX + client_ip
        return cache.get(key, 0)

    @classmethod
    def get_global_score(cls) -> int:
        return cache.get(_GLOBAL_THREAT_KEY, 0)

    @classmethod
    def reset(cls, client_ip: str):
        key = _THREAT_PREFIX + client_ip
        cache.delete(key)

    @classmethod
    def _check_thresholds(cls, client_ip: str, score: int):
        from ..conf import conf

        lockdown_threshold = conf.AUTO_LOCKDOWN_THRESHOLD
        strict_threshold = conf.AUTO_STRICT_THRESHOLD

        from ..models import StrictModeState
        try:
            state = StrictModeState.get_current()
        except Exception:
            return

        if score >= lockdown_threshold and state.mode != StrictModeState.MODE_LOCKDOWN:
            logger.warning(
                "xeolux_securitykit: score menace %d >= %d → activation LOCKDOWN",
                score, lockdown_threshold,
            )
            from .strict_mode import activate_strict_mode
            activate_strict_mode(
                StrictModeState.MODE_LOCKDOWN,
                reason=f"Score de menace critique : {score} (IP: {client_ip})",
                by="auto_lockdown",
            )
        elif score >= strict_threshold and state.mode not in (
            StrictModeState.MODE_STRICT, StrictModeState.MODE_LOCKDOWN
        ):
            logger.warning(
                "xeolux_securitykit: score menace %d >= %d → activation STRICT",
                score, strict_threshold,
            )
            from .strict_mode import activate_strict_mode
            activate_strict_mode(
                StrictModeState.MODE_STRICT,
                reason=f"Score de menace élevé : {score} (IP: {client_ip})",
                by="auto_strict",
            )
