"""
response_engine — Produit la réponse HTTP finale selon l'action décidée.
"""

from django.http import HttpRequest, HttpResponse


class ResponseEngine:
    """Produit la réponse appropriée à partir d'une action string."""

    @staticmethod
    def produce(request: HttpRequest, action: str, redirect_to: str = "") -> HttpResponse:
        from .fake_response import build_response
        return build_response(request, action, redirect_to)
