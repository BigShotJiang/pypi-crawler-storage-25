"""
Accès centralisé à la configuration du package.

Priorité :
  1. Base de données (SecurityKitConfig) — géré depuis /securitykit/settings/
  2. settings.py XEOLUX_SECURITYKIT — bootstrap / surcharge ponctuelle
  3. DEFAULTS — valeurs par défaut internes

Le package fonctionne même si la base n'est pas encore migrée.
"""

from django.conf import settings
from .defaults import DEFAULTS


def _coerce(str_value: str, reference):
    """Convertit une valeur stockée (str) vers le type du défaut correspondant."""
    if isinstance(reference, bool):
        return str_value.lower() in ("true", "1", "yes", "on")
    if isinstance(reference, int):
        try:
            return int(str_value)
        except (ValueError, TypeError):
            return reference
    if isinstance(reference, float):
        try:
            return float(str_value)
        except (ValueError, TypeError):
            return reference
    if isinstance(reference, list):
        try:
            import json
            return json.loads(str_value)
        except Exception:
            return reference
    return str_value


class SecurityKitConf:
    """
    Proxy vers la configuration du package.
    Usage : from xeolux_securitykit.conf import conf; conf.ENABLED
    """

    def __getattr__(self, name: str):
        if name.startswith("_") or name not in DEFAULTS:
            raise AttributeError(f"xeolux_securitykit: paramètre inconnu '{name}'")

        # 1. Base de données (priorité maximale — configurable depuis /securitykit/)
        try:
            from .models import SecurityKitConfig
            obj = SecurityKitConfig.objects.get(key=name)
            return _coerce(obj.value, DEFAULTS[name])
        except Exception:
            # DB non migrée, entrée absente, ou n'importe quelle erreur → on continue
            pass

        # 2. settings.py (bootstrap / surcharge ponctuelle)
        user_conf = getattr(settings, "XEOLUX_SECURITYKIT", {})
        if name in user_conf:
            return user_conf[name]

        # 3. Valeur par défaut interne
        return DEFAULTS[name]

    def get(self, name: str, default=None):
        try:
            return getattr(self, name)
        except AttributeError:
            return default

    def as_dict(self) -> dict:
        """Retourne la configuration fusionnée complète (DB > settings > defaults)."""
        result = {}
        for key in DEFAULTS:
            result[key] = self.get(key, DEFAULTS[key])
        return result

    def as_settings_dict(self) -> dict:
        """Retourne uniquement les valeurs issues de settings.py."""
        return dict(getattr(settings, "XEOLUX_SECURITYKIT", {}))


conf = SecurityKitConf()
