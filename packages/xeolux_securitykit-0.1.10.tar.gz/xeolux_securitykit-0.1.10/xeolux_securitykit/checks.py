"""
Checks système Django pour xeolux_securitykit.
Signalés lors de `python manage.py check`.
"""

from django.core.checks import Error, Warning, register, Tags


@register(Tags.security)
def check_middleware_position(app_configs, **kwargs):
    issues = []
    from django.conf import settings

    middleware = list(getattr(settings, "MIDDLEWARE", []))
    target = "xeolux_securitykit.middleware.XeoluxSecurityMiddleware"
    auth_mw = "django.contrib.auth.middleware.AuthenticationMiddleware"

    if target not in middleware:
        issues.append(
            Warning(
                "XeoluxSecurityMiddleware n'est pas dans MIDDLEWARE.",
                hint="Ajoutez 'xeolux_securitykit.middleware.XeoluxSecurityMiddleware' "
                     "en début de MIDDLEWARE pour intercepter toutes les requêtes.",
                id="xeolux_securitykit.W001",
            )
        )
    else:
        sk_idx = middleware.index(target)
        auth_idx = middleware.index(auth_mw) if auth_mw in middleware else -1

        # Idéal : SecurityKit en tête (avant tout)
        # Le middleware gère correctement l'absence de request.user
        if sk_idx > 3:
            issues.append(
                Warning(
                    "XeoluxSecurityMiddleware devrait être placé en début de MIDDLEWARE.",
                    hint="Placez-le avant les autres middlewares pour intercepter "
                         "toutes les requêtes dès le départ.",
                    id="xeolux_securitykit.W002",
                )
            )

        # Avertir si AuthenticationMiddleware est absent
        if auth_idx == -1:
            issues.append(
                Warning(
                    "AuthenticationMiddleware est absent de MIDDLEWARE.",
                    hint="Ajoutez 'django.contrib.auth.middleware.AuthenticationMiddleware' "
                         "pour que les vérifications de permission fonctionnent.",
                    id="xeolux_securitykit.W004",
                )
            )
    return issues


@register(Tags.security)
def check_securitykit_config(app_configs, **kwargs):
    issues = []
    from django.conf import settings

    if not hasattr(settings, "XEOLUX_SECURITYKIT"):
        issues.append(
            Warning(
                "XEOLUX_SECURITYKIT n'est pas défini dans settings.py.",
                hint="Le package fonctionne avec les valeurs par défaut. "
                     "Ajoutez XEOLUX_SECURITYKIT = {...} pour personnaliser.",
                id="xeolux_securitykit.W003",
            )
        )

    if getattr(settings, "DEBUG", False):
        issues.append(
            Warning(
                "DEBUG=True : certaines protections peuvent être moins efficaces.",
                hint="Désactivez DEBUG en production.",
                id="xeolux_securitykit.W004",
            )
        )
    return issues
