"""
Décorateurs utilitaires pour xeolux_securitykit.
"""

from functools import wraps


def _check_securitykit_access(request) -> bool:
    """
    Vérifie si l'utilisateur peut accéder à l'interface SecurityKit.
    Règles :
    - Non authentifié → refus
    - Superuser actif → accès automatique (Django natif + explicite ici)
    - Sinon → permission Django `xeolux_securitykit.access_securitykit` requise
    """
    user = getattr(request, "user", None)
    if user is None or not user.is_authenticated:
        return False
    if getattr(user, "is_superuser", False) and getattr(user, "is_active", False):
        return True
    return user.has_perm("xeolux_securitykit.access_securitykit")


def superuser_required(view_func):
    """Alias conservé pour compatibilité — délègue à securitykit_access_required."""
    return securitykit_access_required(view_func)


def securitykit_access_required(view_func):
    """
    Protège les vues de l'interface SecurityKit.
    Accès accordé si :
      - Superuser actif (bypass natif Django, rendu explicite ici)
      - OU permission Django `xeolux_securitykit.access_securitykit` accordée
    Gérez l'accès des non-superusers via Django admin > Utilisateurs/Groupes > Permissions.
    """
    @wraps(view_func)
    def wrapper(request, *args, **kwargs):
        if not _check_securitykit_access(request):
            from .responses import fake_404_response
            return fake_404_response(request)
        return view_func(request, *args, **kwargs)
    return wrapper


def _get_client_ip(request) -> str:
    x_forwarded = request.META.get("HTTP_X_FORWARDED_FOR")
    if x_forwarded:
        return x_forwarded.split(",")[0].strip()
    return request.META.get("REMOTE_ADDR", "")
