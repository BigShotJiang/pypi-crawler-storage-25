"""
Réponses HTTP utilitaires pour le package.

Principe : on utilise les handlers natifs Django (page_not_found, permission_denied)
afin que le visiteur bloqué voie exactement la même 404/403 que le reste du site.
Cela évite d'avoir deux pages 404 différentes, ce qui trahirait la présence d'un filtre.
"""

from django.http import HttpResponse, JsonResponse


def fake_404_response(request) -> HttpResponse:
    """
    Retourne la 404 native de Django.
    Utilise votre 404.html si présent, sinon la page Django par défaut.
    Indiscernable d'une vraie 404 du site.
    """
    try:
        from django.views.defaults import page_not_found
        from django.http import Http404
        return page_not_found(request, Http404())
    except Exception:
        return HttpResponse("<html><body><h1>404 Not Found</h1></body></html>", status=404)


def forbidden_response(request) -> HttpResponse:
    """
    Retourne la 403 native de Django.
    Utilise votre 403.html si présent, sinon la page Django par défaut.
    """
    try:
        from django.views.defaults import permission_denied
        from django.core.exceptions import PermissionDenied
        return permission_denied(request, PermissionDenied())
    except Exception:
        return HttpResponse("<html><body><h1>403 Forbidden</h1></body></html>", status=403)


def empty_response() -> HttpResponse:
    """Retourne une réponse 200 vide (silencieuse)."""
    return HttpResponse("", status=200)


def json_neutral_response() -> JsonResponse:
    """Retourne un JSON 404 standard (pour les endpoints API)."""
    return JsonResponse({"detail": "Not found."}, status=404)


def redirect_neutral_response(url: str):
    """Redirection vers une autre URL."""
    from django.http import HttpResponseRedirect
    return HttpResponseRedirect(url)


def too_many_requests_response(request) -> HttpResponse:
    """Retourne une 429 native si handler défini, sinon réponse minimale."""
    try:
        # Django n'a pas de handler 429 natif, on utilise le template si existant
        from django.template.loader import render_to_string
        try:
            html = render_to_string("429.html", request=request)
        except Exception:
            html = "<html><body><h1>429 Too Many Requests</h1><p>Veuillez réessayer plus tard.</p></body></html>"
        return HttpResponse(html, status=429, content_type="text/html")
    except Exception:
        return HttpResponse("<h1>429 Too Many Requests</h1>", status=429)


def slow_response(request, delay: float = 2.0) -> HttpResponse:
    """
    Retourne une 404 native après un délai volontaire.
    À utiliser uniquement contre le bruteforce.
    """
    import time
    time.sleep(min(delay, 10.0))
    return fake_404_response(request)
