"""
Vues de l'interface SecurityKit.
Toutes les vues sont protégées par @securitykit_access_required.
"""

import json
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from django.http import JsonResponse, HttpResponse
from django.views.decorators.http import require_POST, require_http_methods

from .decorators import securitykit_access_required
from .models import (
    SecurityModuleState, ProtectedRoute, RouteRule,
    IPWhitelistEntry, IPBlacklistEntry, APIKey,
    StrictModeState, SecurityProfile,
)
from .forms import (
    ProtectedRouteForm, RouteRuleForm,
    IPWhitelistEntryForm, IPBlacklistEntryForm,
    APIKeyCreateForm, StrictModeActivateForm, ConfigImportForm,
)


# ---------------------------------------------------------------------------
# Dashboard
# ---------------------------------------------------------------------------

@securitykit_access_required
def dashboard(request):
    from .services.config_storage import get_config
    from .services.module_registry import get_all_modules

    strict_state = StrictModeState.get_current()
    modules = get_all_modules()
    route_count = ProtectedRoute.objects.filter(enabled=True).count()
    wl_count = IPWhitelistEntry.objects.filter(enabled=True).count()
    bl_count = IPBlacklistEntry.objects.filter(enabled=True).count()
    api_key_count = APIKey.objects.filter(enabled=True).count()

    ctx = {
        "strict_state": strict_state,
        "modules": modules,
        "route_count": route_count,
        "wl_count": wl_count,
        "bl_count": bl_count,
        "api_key_count": api_key_count,
    }
    return render(request, "xeolux_securitykit/dashboard.html", ctx)


# ---------------------------------------------------------------------------
# Modules
# ---------------------------------------------------------------------------

@securitykit_access_required
def modules_list(request):
    from .services.module_registry import get_all_modules, get_module_settings_keys
    from collections import defaultdict
    modules = get_all_modules()
    # Ajouter le flag has_settings pour le bouton "Réglages"
    for m in modules:
        m["has_settings"] = bool(get_module_settings_keys(m["name"]))
    # Regroupement par catégorie côté Python (pas de filtre Jinja2)
    groups_dict = defaultdict(list)
    for m in modules:
        groups_dict[m["category"]].append(m)
    grouped = [{"category": cat, "modules": mods} for cat, mods in groups_dict.items()]
    return render(request, "xeolux_securitykit/modules.html", {"grouped": grouped, "modules": modules})


@securitykit_access_required
@require_POST
def module_toggle(request, module_name: str):
    state, _ = SecurityModuleState.objects.get_or_create(
        module_name=module_name,
        defaults={"enabled": True},
    )
    state.enabled = not state.enabled
    state.save()
    status = "activé" if state.enabled else "désactivé"
    messages.success(request, f"Module '{module_name}' {status}.")
    # Rediriger vers la page de config du module si elle existe, sinon vers la liste
    from .services.module_registry import get_module_settings_keys
    if get_module_settings_keys(module_name):
        return redirect("xeolux_securitykit:module_settings", module_name=module_name)
    return redirect("xeolux_securitykit:modules")


@securitykit_access_required
def module_settings_view(request, module_name: str):
    """
    Page de configuration d'un module individuel.
    Affiche le toggle on/off + tous les paramètres configurables du module.
    """
    from .services.module_registry import get_module_settings_keys, get_module_info, KNOWN_MODULES
    from .defaults import DEFAULTS
    from .models import SecurityKitConfig, SecurityModuleState
    from .conf import conf

    # Trouver le module
    module_info = next((m for m in KNOWN_MODULES if m["name"] == module_name), None)
    if module_info is None:
        from .responses import fake_404_response
        return fake_404_response(request)

    settings_keys = get_module_settings_keys(module_name)

    # État actuel du module (activé/désactivé)
    try:
        mod_state = SecurityModuleState.objects.get(module_name=module_name)
        enabled = mod_state.enabled
    except SecurityModuleState.DoesNotExist:
        enabled = True

    if request.method == "POST":
        from .services.config_storage import set_db_config, delete_db_config

        for key, label, help_text in settings_keys:
            if key not in DEFAULTS:
                continue
            raw = request.POST.get(key)
            if raw is None:
                # Checkbox non cochée = False
                if isinstance(DEFAULTS[key], bool):
                    set_db_config(key, "false")
                continue
            raw = raw.strip()
            if isinstance(DEFAULTS[key], bool):
                raw = "true" if raw == "on" else "false"
            if raw == "":
                delete_db_config(key)
            else:
                set_db_config(key, raw)

        # Gérer les bool absents du POST (décochés)
        for key, label, help_text in settings_keys:
            if key not in DEFAULTS:
                continue
            if isinstance(DEFAULTS[key], bool) and key not in request.POST:
                set_db_config(key, "false")

        messages.success(request, f"Réglages du module « {module_info['label']} » sauvegardés.")
        return redirect("xeolux_securitykit:module_settings", module_name=module_name)

    # Construire les paramètres avec valeurs actuelles
    db_keys = set(SecurityKitConfig.objects.values_list("key", flat=True))
    params = []
    for key, label, help_text in settings_keys:
        if key not in DEFAULTS:
            continue
        default_val = DEFAULTS[key]
        current = conf.get(key, default_val)
        if key in db_keys:
            source = "db"
        else:
            source = "default"
        params.append({
            "key": key,
            "label": label,
            "help_text": help_text,
            "value": current,
            "value_json": json.dumps(current) if isinstance(current, list) else "",
            "default": default_val,
            "source": source,
            "type": type(default_val).__name__,
        })

    return render(request, "xeolux_securitykit/module_settings.html", {
        "module": module_info,
        "enabled": enabled,
        "params": params,
        "has_settings": bool(params),
    })


# ---------------------------------------------------------------------------
# Routes protégées
# ---------------------------------------------------------------------------

@securitykit_access_required
def routes_list(request):
    routes = ProtectedRoute.objects.prefetch_related("rules").all()
    return render(request, "xeolux_securitykit/routes.html", {"routes": routes})


@securitykit_access_required
def route_add(request):
    form = ProtectedRouteForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        form.save()
        messages.success(request, "Route protégée ajoutée.")
        return redirect("xeolux_securitykit:routes")
    return render(request, "xeolux_securitykit/route_rule_form.html", {
        "form": form, "title": "Ajouter une route protégée"
    })


@securitykit_access_required
def route_edit(request, pk: int):
    route = get_object_or_404(ProtectedRoute, pk=pk)
    form = ProtectedRouteForm(request.POST or None, instance=route)
    if request.method == "POST" and form.is_valid():
        form.save()
        messages.success(request, "Route mise à jour.")
        return redirect("xeolux_securitykit:routes")
    return render(request, "xeolux_securitykit/route_rule_form.html", {
        "form": form, "title": f"Modifier la route : {route.path}"
    })


@securitykit_access_required
@require_POST
def route_delete(request, pk: int):
    from .services.lockout_safety import check_route_delete_safety
    route = get_object_or_404(ProtectedRoute, pk=pk)
    safe, reason = check_route_delete_safety(request, route)
    if not safe:
        messages.error(request, f"Suppression refusée : {reason}")
        return redirect("xeolux_securitykit:routes")
    route.delete()
    messages.success(request, f"Route '{route.path}' supprimée.")
    return redirect("xeolux_securitykit:routes")


# ---------------------------------------------------------------------------
# Règles par route
# ---------------------------------------------------------------------------

@securitykit_access_required
def rule_add(request, route_pk: int):
    route = get_object_or_404(ProtectedRoute, pk=route_pk)
    form = RouteRuleForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        rule = form.save(commit=False)
        rule.route = route
        from .services.lockout_safety import check_rule_safety
        safe, reason = check_rule_safety(request, rule)
        if not safe:
            messages.error(request, f"Règle refusée pour sécurité anti-lockout : {reason}")
        else:
            rule.save()
            messages.success(request, "Règle ajoutée.")
            return redirect("xeolux_securitykit:routes")
    return render(request, "xeolux_securitykit/route_rule_form.html", {
        "form": form,
        "title": f"Ajouter une règle pour : {route.path}",
        "route": route,
    })


@securitykit_access_required
def rule_edit(request, pk: int):
    rule = get_object_or_404(RouteRule, pk=pk)
    form = RouteRuleForm(request.POST or None, instance=rule)
    if request.method == "POST" and form.is_valid():
        updated = form.save(commit=False)
        from .services.lockout_safety import check_rule_safety
        safe, reason = check_rule_safety(request, updated)
        if not safe:
            messages.error(request, f"Règle refusée : {reason}")
        else:
            updated.save()
            messages.success(request, "Règle mise à jour.")
            return redirect("xeolux_securitykit:routes")
    return render(request, "xeolux_securitykit/route_rule_form.html", {
        "form": form, "title": "Modifier la règle"
    })


@securitykit_access_required
@require_POST
def rule_delete(request, pk: int):
    rule = get_object_or_404(RouteRule, pk=pk)
    rule.delete()
    messages.success(request, "Règle supprimée.")
    return redirect("xeolux_securitykit:routes")


# ---------------------------------------------------------------------------
# Whitelist IP
# ---------------------------------------------------------------------------

@securitykit_access_required
def whitelist(request):
    entries = IPWhitelistEntry.objects.all().order_by("-created_at")
    form = IPWhitelistEntryForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        form.save()
        messages.success(request, "IP ajoutée à la whitelist.")
        return redirect("xeolux_securitykit:whitelist")
    return render(request, "xeolux_securitykit/whitelist.html", {"entries": entries, "form": form})


@securitykit_access_required
def whitelist_add(request):
    return redirect("xeolux_securitykit:whitelist")


@securitykit_access_required
@require_POST
def whitelist_delete(request, pk: int):
    entry = get_object_or_404(IPWhitelistEntry, pk=pk)
    from .services.lockout_safety import check_whitelist_delete_safety
    safe, reason = check_whitelist_delete_safety(request, entry)
    if not safe:
        messages.error(request, f"Suppression refusée : {reason}")
    else:
        entry.delete()
        messages.success(request, "IP retirée de la whitelist.")
    return redirect("xeolux_securitykit:whitelist")


# ---------------------------------------------------------------------------
# Blacklist IP
# ---------------------------------------------------------------------------

@securitykit_access_required
def blacklist(request):
    entries = IPBlacklistEntry.objects.all().order_by("-created_at")
    form = IPBlacklistEntryForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        form.save()
        messages.success(request, "IP ajoutée à la blacklist.")
        return redirect("xeolux_securitykit:blacklist")
    return render(request, "xeolux_securitykit/blacklist.html", {"entries": entries, "form": form})


@securitykit_access_required
def blacklist_add(request):
    return redirect("xeolux_securitykit:blacklist")


@securitykit_access_required
@require_POST
def blacklist_delete(request, pk: int):
    entry = get_object_or_404(IPBlacklistEntry, pk=pk)
    entry.delete()
    messages.success(request, "IP retirée de la blacklist.")
    return redirect("xeolux_securitykit:blacklist")


# ---------------------------------------------------------------------------
# Clés API
# ---------------------------------------------------------------------------

@securitykit_access_required
def api_keys(request):
    keys = APIKey.objects.all().order_by("-created_at")
    return render(request, "xeolux_securitykit/api_keys.html", {"keys": keys})


@securitykit_access_required
def api_key_create(request):
    form = APIKeyCreateForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        name = form.cleaned_data["name"]
        allowed_routes = form.cleaned_data.get("allowed_routes", "")
        allowed_ips = form.cleaned_data.get("allowed_ips", "")
        expires_at = form.cleaned_data.get("expires_at")
        instance, raw_key = APIKey.create_key(
            name=name,
            allowed_routes=allowed_routes,
            allowed_ips=allowed_ips,
            expires_at=expires_at,
        )
        # Afficher la clé brute une seule fois
        messages.success(request, f"Clé créée. Copiez-la maintenant, elle ne sera plus visible : {raw_key}")
        return redirect("xeolux_securitykit:api_keys")
    return render(request, "xeolux_securitykit/route_rule_form.html", {
        "form": form, "title": "Créer une clé API"
    })


@securitykit_access_required
@require_POST
def api_key_revoke(request, pk: int):
    key = get_object_or_404(APIKey, pk=pk)
    key.enabled = False
    key.save(update_fields=["enabled"])
    messages.success(request, f"Clé '{key.name}' révoquée.")
    return redirect("xeolux_securitykit:api_keys")


# ---------------------------------------------------------------------------
# Strict mode
# ---------------------------------------------------------------------------

@securitykit_access_required
def strict_mode_view(request):
    from .modules.ip_whitelist import is_ip_in_strict_whitelist
    state = StrictModeState.get_current()
    client_ip = _get_client_ip(request)
    return render(request, "xeolux_securitykit/strict_mode.html", {
        "state": state,
        "client_ip": client_ip,
        "client_ip_whitelisted": is_ip_in_strict_whitelist(client_ip),
    })


@securitykit_access_required
@require_POST
def strict_mode_activate(request):
    form = StrictModeActivateForm(request.POST)
    if form.is_valid():
        mode = form.cleaned_data["mode"]
        reason = form.cleaned_data.get("reason", "")
        from .services.strict_mode import activate_strict_mode
        activate_strict_mode(mode, reason=reason, by=request.user.username)
        messages.success(request, f"Mode Whitelist activé.")
    return redirect("xeolux_securitykit:strict_mode")


@securitykit_access_required
@require_POST
def strict_mode_deactivate(request):
    from .services.strict_mode import deactivate_strict_mode
    deactivate_strict_mode()
    messages.success(request, "Tous les modes d'urgence désactivés, retour en mode normal.")
    return redirect("xeolux_securitykit:strict_mode")


@securitykit_access_required
@require_POST
def lockdown_activate(request):
    """Active le lockdown (priorité absolue, indépendant du mode whitelist)."""
    reason = request.POST.get("reason", "")
    from .services.strict_mode import activate_lockdown_mode
    activate_lockdown_mode(reason=reason, by=request.user.username)
    messages.error(request, "Lockdown activé. Personne ne peut accéder au site.")
    return redirect("xeolux_securitykit:strict_mode")


@securitykit_access_required
@require_POST
def lockdown_deactivate(request):
    """Désactive uniquement le lockdown. Le mode whitelist reste actif s'il était en cours."""
    from .services.strict_mode import deactivate_lockdown_mode
    deactivate_lockdown_mode()
    state = StrictModeState.get_current()
    if state.mode == StrictModeState.MODE_STRICT:
        messages.success(request, "Lockdown désactivé. Mode Whitelist toujours actif.")
    else:
        messages.success(request, "Lockdown désactivé, retour en mode normal.")
    return redirect("xeolux_securitykit:strict_mode")


# ---------------------------------------------------------------------------
# Page d'unlock strict mode (accessible sans être connecté)
# ---------------------------------------------------------------------------

def unlock_strict_mode(request, token: str):
    """
    Page de déverrouillage strict mode.
    L'URL contient un token aléatoire unique généré à chaque activation.
    Si le token ne correspond pas au token courant en DB → fake 404.
    """
    from .services.strict_unlock import UnlockService
    from .forms import UnlockCodeForm
    from .models import StrictModeState

    # Vérifier que le token dans l'URL correspond au token courant
    try:
        state = StrictModeState.get_current()
        if not state.unlock_token or state.unlock_token != token:
            from .services.fake_response import build_response
            return build_response(request, "fake_404")
    except Exception:
        from .services.fake_response import build_response
        return build_response(request, "fake_404")

    client_ip = _get_client_ip(request)

    # Vérifier si l'IP est throttlée pour les tentatives
    if UnlockService.is_throttled(client_ip):
        return render(request, "xeolux_securitykit/unlock_strict_mode.html", {
            "throttled": True,
        }, status=429)

    form = UnlockCodeForm(request.POST or None)
    success = False
    error = None

    if request.method == "POST" and form.is_valid():
        raw_code = form.cleaned_data["code"]
        ok, msg = UnlockService.attempt_unlock(raw_code, client_ip)
        if ok:
            success = True
            messages.success(request, "Strict mode désactivé avec succès.")
        else:
            error = msg
            UnlockService.record_failed_attempt(client_ip)

    return render(request, "xeolux_securitykit/unlock_strict_mode.html", {
        "form": form,
        "success": success,
        "error": error,
    })


# ---------------------------------------------------------------------------
# Diagnostics
# ---------------------------------------------------------------------------

@securitykit_access_required
def diagnostics(request):
    from .modules.settings_checker import run_diagnostics
    results = run_diagnostics()
    return render(request, "xeolux_securitykit/diagnostics.html", {"results": results})


# ---------------------------------------------------------------------------
# Testeur de règles (dry run)
# ---------------------------------------------------------------------------

@securitykit_access_required
def rule_tester(request):
    from .services.dry_run import DryRunService
    from .forms import RuleTesterForm

    result = None
    form = RuleTesterForm(request.POST or None)

    if request.method == "POST" and form.is_valid():
        result = DryRunService.simulate(form.cleaned_data, request)

    return render(request, "xeolux_securitykit/rule_tester.html", {
        "form": form,
        "dry_run_result": result,
    })


# ---------------------------------------------------------------------------
# Import / Export config
# ---------------------------------------------------------------------------

@securitykit_access_required
def config_export(request):
    from .services.config_storage import export_config
    data = export_config()
    response = HttpResponse(
        json.dumps(data, indent=2, ensure_ascii=False),
        content_type="application/json",
    )
    response["Content-Disposition"] = 'attachment; filename="securitykit_config.json"'
    return response


@securitykit_access_required
def config_import(request):
    form = ConfigImportForm(request.POST or None, request.FILES or None)
    if request.method == "POST" and form.is_valid():
        from .services.config_storage import import_config
        try:
            data = json.loads(form.cleaned_data["config_file"].read())
            import_config(data)
            messages.success(request, "Configuration importée avec succès.")
        except Exception as e:
            messages.error(request, f"Erreur d'import : {e}")
        return redirect("xeolux_securitykit:dashboard")
    return render(request, "xeolux_securitykit/config_import.html", {
        "form": form,
    })


# ---------------------------------------------------------------------------
# Profils de sécurité
# ---------------------------------------------------------------------------

@securitykit_access_required
def security_profiles(request):
    from .services.config_storage import get_builtin_profiles
    profiles = get_builtin_profiles()
    active = SecurityProfile.objects.filter(is_active=True).first()
    return render(request, "xeolux_securitykit/security_profiles.html", {
        "profiles": profiles,
        "active_profile": active,
    })


@securitykit_access_required
@require_POST
def profile_apply(request, profile_name: str):
    from .services.config_storage import apply_security_profile
    ok, msg = apply_security_profile(profile_name)
    if ok:
        messages.success(request, f"Profil '{profile_name}' appliqué.")
    else:
        messages.error(request, msg)
    return redirect("xeolux_securitykit:dashboard")


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _get_client_ip(request) -> str:
    x_forwarded = request.META.get("HTTP_X_FORWARDED_FOR")
    if x_forwarded:
        return x_forwarded.split(",")[0].strip()
    return request.META.get("REMOTE_ADDR", "")


# ---------------------------------------------------------------------------
# Configuration avancée (DB-driven)
# ---------------------------------------------------------------------------

@securitykit_access_required
def settings_view(request):
    """
    Interface de configuration complète.
    Toutes les valeurs sont stockées en DB — settings.py n'a besoin que de ENABLED: True.
    """
    from .defaults import DEFAULTS
    from .models import SecurityKitConfig
    from .conf import conf

    # Catégories d'affichage
    CATEGORIES = {
        "Activation": ["ENABLED"],
        "Réponse par défaut": ["DEFAULT_RESPONSE"],
        "Accès interface": ["SECURITYKIT_PATH", "SELF_PROTECTION_ENABLED", "SUPERUSER_ONLY"],
        "Sécurité": ["LOCKOUT_SAFETY_ENABLED", "STRICT_MODE_ENABLED", "ANTI_DDOS_ENABLED"],
        "Emails": ["EMAIL_SUPER_ADMINS"],
        "Rate limiting": ["RATE_LIMIT_WINDOW", "RATE_LIMIT_MAX_REQUESTS"],
        "Headers": ["SECURITY_HEADERS_ENABLED"],
        "Formulaires": ["HONEYPOT_ENABLED"],
        "Admin Django": ["STEALTH_ADMIN_ENABLED", "ADMIN_SECRET_URL"],
        "Strict mode — unlock": ["UNLOCK_CODE_TTL", "UNLOCK_CODE_LENGTH", "UNLOCK_MAX_ATTEMPTS"],
        "Cache": ["CACHE_PREFIX", "CACHE_BACKEND"],
        "Chemins exclus": ["EXEMPT_PATHS"],
        "Seuils automatiques": ["AUTO_STRICT_THRESHOLD", "AUTO_LOCKDOWN_THRESHOLD"],
    }

    if request.method == "POST":
        from .services.config_storage import set_db_config, delete_db_config
        for key in DEFAULTS:
            raw = request.POST.get(key)
            if raw is None:
                continue
            raw = raw.strip()
            # Checkbox non cochée = absent du POST → traiter séparément
            if isinstance(DEFAULTS[key], bool):
                raw = "true" if request.POST.get(key) == "on" else "false"
            if raw == "":
                # Vider = revenir au défaut (settings.py ou DEFAULTS)
                delete_db_config(key)
            else:
                set_db_config(key, raw)
        # Traiter les bool (checkbox) non présents dans POST (= décochés)
        for key, default_val in DEFAULTS.items():
            if isinstance(default_val, bool) and key not in request.POST:
                from .services.config_storage import set_db_config
                set_db_config(key, "false")
        messages.success(request, "Configuration sauvegardée en base de données.")
        return redirect("xeolux_securitykit:settings")

    # Construire la liste des paramètres avec valeur actuelle + source
    db_keys = set(SecurityKitConfig.objects.values_list("key", flat=True))
    settings_keys = set(getattr(request, "_sk_settings_keys", None) or
                        getattr(__import__("django.conf", fromlist=["settings"]).settings,
                                "XEOLUX_SECURITYKIT", {}).keys())
    params = {}
    for key, default_val in DEFAULTS.items():
        current = conf.get(key, default_val)
        if key in db_keys:
            source = "db"
        elif key in settings_keys:
            source = "settings"
        else:
            source = "default"
        params[key] = {
            "value": current,
            "value_json": json.dumps(current) if isinstance(current, list) else "",
            "default": default_val,
            "source": source,
            "type": type(default_val).__name__,
        }

    # Grouper par catégorie
    grouped = []
    seen = set()
    for cat, keys in CATEGORIES.items():
        items = [(k, params[k]) for k in keys if k in params]
        if items:
            grouped.append({"category": cat, "items": items})
            seen.update(k for k, _ in items)
    # Paramètres non catégorisés
    others = [(k, v) for k, v in params.items() if k not in seen]
    if others:
        grouped.append({"category": "Autres", "items": others})

    return render(request, "xeolux_securitykit/settings.html", {
        "grouped": grouped,
        "params": params,
    })
