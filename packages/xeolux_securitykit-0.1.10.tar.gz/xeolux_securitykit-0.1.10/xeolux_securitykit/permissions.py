"""
Permissions pour les vues SecurityKit.
Règles d'accès :
  - Superuser actif → accès automatique (Django natif, rendu explicite ici)
  - Sinon → permission `xeolux_securitykit.access_securitykit` requise
Accordez l'accès aux non-superusers via Django admin > Utilisateurs/Groupes > Permissions.
Note : exécutez `python manage.py migrate` pour créer la permission en base de données.
"""

PERM = "xeolux_securitykit.access_securitykit"


def has_securitykit_access(user) -> bool:
    """
    Retourne True si l'utilisateur peut accéder à SecurityKit.
    Les superusers actifs passent automatiquement.
    """
    if not getattr(user, "is_authenticated", False):
        return False
    if getattr(user, "is_superuser", False) and getattr(user, "is_active", False):
        return True
    return user.has_perm(PERM)


def can_manage_securitykit(user) -> bool:
    return has_securitykit_access(user)


def can_view_diagnostics(user) -> bool:
    return has_securitykit_access(user)


def can_manage_rules(user) -> bool:
    return has_securitykit_access(user)


def can_manage_api_keys(user) -> bool:
    return has_securitykit_access(user)


def can_toggle_strict_mode(user) -> bool:
    return has_securitykit_access(user)
