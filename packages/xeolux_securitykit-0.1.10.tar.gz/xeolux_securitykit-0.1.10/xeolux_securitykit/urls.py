"""
URLs du package xeolux_securitykit.

Configuration minimale dans urls.py du projet :

    from django.urls import path, include

    urlpatterns = [
        path("", include("xeolux_securitykit.urls")),
        # ... vos autres routes
    ]

Le package gère lui-même les préfixes :
  /securitykit/        → interface d'administration
  /xk-unlock/<token>/  → page de déverrouillage dynamique (strict mode)
"""

from django.urls import path, include
from . import views

app_name = "xeolux_securitykit"

# ── Routes de l'interface d'administration (/securitykit/*) ──────────────
_admin_patterns = [
    path("", views.dashboard, name="dashboard"),

    path("modules/", views.modules_list, name="modules"),
    path("modules/<str:module_name>/toggle/", views.module_toggle, name="module_toggle"),
    path("modules/<str:module_name>/settings/", views.module_settings_view, name="module_settings"),

    path("routes/", views.routes_list, name="routes"),
    path("routes/add/", views.route_add, name="route_add"),
    path("routes/<int:pk>/edit/", views.route_edit, name="route_edit"),
    path("routes/<int:pk>/delete/", views.route_delete, name="route_delete"),

    path("routes/<int:route_pk>/rules/add/", views.rule_add, name="rule_add"),
    path("rules/<int:pk>/edit/", views.rule_edit, name="rule_edit"),
    path("rules/<int:pk>/delete/", views.rule_delete, name="rule_delete"),

    path("whitelist/", views.whitelist, name="whitelist"),
    path("whitelist/add/", views.whitelist_add, name="whitelist_add"),
    path("whitelist/<int:pk>/delete/", views.whitelist_delete, name="whitelist_delete"),

    path("blacklist/", views.blacklist, name="blacklist"),
    path("blacklist/add/", views.blacklist_add, name="blacklist_add"),
    path("blacklist/<int:pk>/delete/", views.blacklist_delete, name="blacklist_delete"),

    path("api-keys/", views.api_keys, name="api_keys"),
    path("api-keys/create/", views.api_key_create, name="api_key_create"),
    path("api-keys/<int:pk>/revoke/", views.api_key_revoke, name="api_key_revoke"),

    path("strict-mode/", views.strict_mode_view, name="strict_mode"),
    path("strict-mode/activate/", views.strict_mode_activate, name="strict_mode_activate"),
    path("strict-mode/deactivate/", views.strict_mode_deactivate, name="strict_mode_deactivate"),
    path("strict-mode/lockdown/activate/", views.lockdown_activate, name="lockdown_activate"),
    path("strict-mode/lockdown/deactivate/", views.lockdown_deactivate, name="lockdown_deactivate"),

    path("diagnostics/", views.diagnostics, name="diagnostics"),
    path("rule-tester/", views.rule_tester, name="rule_tester"),

    path("config/export/", views.config_export, name="config_export"),
    path("config/import/", views.config_import, name="config_import"),

    path("profiles/", views.security_profiles, name="security_profiles"),
    path("profiles/<str:profile_name>/apply/", views.profile_apply, name="profile_apply"),

    # Configuration avancée DB-driven
    path("settings/", views.settings_view, name="settings"),
]

# ── Route de déverrouillage dynamique (/xk-unlock/<token>/) ─────────────
_unlock_patterns = [
    path("<str:token>/", views.unlock_strict_mode, name="unlock_strict_mode"),
]

# ── urlpatterns principal (inclure avec path("", include(...))) ───────────
urlpatterns = [
    path("securitykit/", include(_admin_patterns)),
    path("xk-unlock/", include(_unlock_patterns)),
]

# Compatibilité : ces variables restent disponibles pour les projets
# qui les incluent séparément
unlock_urlpatterns = _unlock_patterns
