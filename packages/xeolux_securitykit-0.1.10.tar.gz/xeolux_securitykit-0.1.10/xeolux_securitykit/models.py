"""
Modèles Django pour xeolux_securitykit.
"""

import hashlib
import secrets
from django.db import models
from django.utils import timezone


# ---------------------------------------------------------------------------
# 1. Configuration globale
# ---------------------------------------------------------------------------

class SecurityKitConfig(models.Model):
    """Paramètres globaux du package, stockés en base."""

    key = models.CharField(max_length=100, unique=True)
    value = models.TextField(blank=True, default="")
    description = models.CharField(max_length=255, blank=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = "Configuration SecurityKit"
        verbose_name_plural = "Configurations SecurityKit"
        permissions = [
            ("access_securitykit", "Peut accéder à l'interface SecurityKit"),
        ]

    def __str__(self):
        return f"{self.key} = {self.value[:60]}"


# ---------------------------------------------------------------------------
# 2. État des modules
# ---------------------------------------------------------------------------

class SecurityModuleState(models.Model):
    """Indique si un module est activé ou non."""

    module_name = models.CharField(max_length=100, unique=True)
    enabled = models.BooleanField(default=True)
    updated_at = models.DateTimeField(auto_now=True)
    notes = models.TextField(blank=True)

    class Meta:
        verbose_name = "État du module"
        verbose_name_plural = "États des modules"

    def __str__(self):
        status = "ON" if self.enabled else "OFF"
        return f"{self.module_name} [{status}]"


# ---------------------------------------------------------------------------
# 3. Routes protégées
# ---------------------------------------------------------------------------

class ProtectedRoute(models.Model):
    """Route ou pattern d'URL soumis à des règles de sécurité."""

    MATCH_EXACT = "exact"
    MATCH_PREFIX = "prefix"
    MATCH_REGEX = "regex"
    MATCH_CHOICES = [
        (MATCH_EXACT, "Exact"),
        (MATCH_PREFIX, "Préfixe"),
        (MATCH_REGEX, "Regex"),
    ]

    path = models.CharField(
        max_length=500,
        help_text="Chemin URL ou pattern, ex: /admin/ ou ^/api/",
    )
    match_type = models.CharField(
        max_length=10, choices=MATCH_CHOICES, default=MATCH_EXACT
    )
    description = models.CharField(max_length=255, blank=True)
    enabled = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = "Route protégée"
        verbose_name_plural = "Routes protégées"
        ordering = ["path"]

    def __str__(self):
        return f"{self.path} ({self.match_type})"


# ---------------------------------------------------------------------------
# 4. Règles par route
# ---------------------------------------------------------------------------

class RouteRule(models.Model):
    """Règle appliquée à une route protégée."""

    ACTION_FAKE_404 = "fake_404"
    ACTION_BLOCK_403 = "403"
    ACTION_ALLOW = "allow"
    ACTION_REDIRECT = "redirect"
    ACTION_SLOW_DOWN = "slow_down"
    ACTION_EMPTY = "empty"
    ACTION_CHOICES = [
        (ACTION_FAKE_404, "Fake 404"),
        (ACTION_BLOCK_403, "Bloquer (403)"),
        (ACTION_ALLOW, "Autoriser"),
        (ACTION_REDIRECT, "Rediriger"),
        (ACTION_SLOW_DOWN, "Ralentir"),
        (ACTION_EMPTY, "Réponse vide"),
    ]

    route = models.ForeignKey(
        ProtectedRoute, on_delete=models.CASCADE, related_name="rules"
    )
    action = models.CharField(
        max_length=20, choices=ACTION_CHOICES, default=ACTION_FAKE_404
    )
    # Conditions JSON : {"require_superuser": true, "require_whitelist_ip": false, ...}
    conditions = models.JSONField(default=dict, blank=True)
    redirect_to = models.CharField(max_length=500, blank=True)
    priority = models.PositiveIntegerField(default=10)
    enabled = models.BooleanField(default=True)
    description = models.CharField(max_length=255, blank=True)

    class Meta:
        verbose_name = "Règle de route"
        verbose_name_plural = "Règles de routes"
        ordering = ["-priority"]

    def __str__(self):
        return f"{self.route.path} → {self.action}"


# ---------------------------------------------------------------------------
# 5. Politiques d'accès
# ---------------------------------------------------------------------------

class AccessPolicy(models.Model):
    """Politique d'accès réutilisable, applicable à plusieurs routes."""

    name = models.CharField(max_length=100, unique=True)
    description = models.CharField(max_length=255, blank=True)
    # Conditions JSON
    conditions = models.JSONField(default=dict)
    # Action si conditions non remplies
    deny_action = models.CharField(
        max_length=20,
        choices=RouteRule.ACTION_CHOICES,
        default=RouteRule.ACTION_FAKE_404,
    )
    enabled = models.BooleanField(default=True)

    class Meta:
        verbose_name = "Politique d'accès"
        verbose_name_plural = "Politiques d'accès"

    def __str__(self):
        return self.name


# ---------------------------------------------------------------------------
# 6. Whitelist IP
# ---------------------------------------------------------------------------

class IPWhitelistEntry(models.Model):
    """IP ou plage CIDR autorisée."""

    ip_or_cidr = models.CharField(
        max_length=50,
        help_text="IP (192.168.1.1) ou CIDR (192.168.1.0/24)",
    )
    label = models.CharField(max_length=100, blank=True)
    # None = globale, sinon limitée à une route
    route = models.ForeignKey(
        ProtectedRoute,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="whitelist_entries",
    )
    # True = whitelist globale pour /securitykit/
    is_securitykit_access = models.BooleanField(default=False)
    # True = autorisé en mode Strict/Whitelist (ne s'applique PAS au mode Lockdown)
    is_strict_whitelist = models.BooleanField(
        default=False,
        help_text="Cette IP peut accéder au site en mode Strict/Whitelist. Sans effet en mode Lockdown.",
    )
    enabled = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = "IP Whitelist"
        verbose_name_plural = "IP Whitelist"

    def __str__(self):
        return f"[WL] {self.ip_or_cidr} — {self.label}"


# ---------------------------------------------------------------------------
# 7. Blacklist IP
# ---------------------------------------------------------------------------

class IPBlacklistEntry(models.Model):
    """IP ou plage CIDR bloquée."""

    ip_or_cidr = models.CharField(max_length=50)
    label = models.CharField(max_length=100, blank=True)
    reason = models.CharField(max_length=255, blank=True)
    route = models.ForeignKey(
        ProtectedRoute,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="blacklist_entries",
    )
    enabled = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    expires_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        verbose_name = "IP Blacklist"
        verbose_name_plural = "IP Blacklist"

    def __str__(self):
        return f"[BL] {self.ip_or_cidr} — {self.reason}"

    def is_expired(self) -> bool:
        if self.expires_at is None:
            return False
        return timezone.now() > self.expires_at


# ---------------------------------------------------------------------------
# 8. Clés API
# ---------------------------------------------------------------------------

class APIKey(models.Model):
    """Clé API gérée par SecurityKit."""

    name = models.CharField(max_length=100)
    key_prefix = models.CharField(max_length=10, editable=False)
    key_hash = models.CharField(max_length=128, editable=False)
    allowed_routes = models.TextField(
        blank=True,
        help_text="Chemins autorisés séparés par des virgules. Vide = tous.",
    )
    allowed_ips = models.TextField(
        blank=True,
        help_text="IPs autorisées séparées par des virgules. Vide = toutes.",
    )
    enabled = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    expires_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        verbose_name = "Clé API"
        verbose_name_plural = "Clés API"

    def __str__(self):
        return f"{self.name} ({self.key_prefix}...)"

    @classmethod
    def create_key(cls, name: str, **kwargs) -> tuple["APIKey", str]:
        """Crée une clé API et retourne (instance, raw_key)."""
        raw_key = secrets.token_urlsafe(48)
        prefix = raw_key[:8]
        key_hash = hashlib.sha256(raw_key.encode()).hexdigest()
        instance = cls.objects.create(
            name=name,
            key_prefix=prefix,
            key_hash=key_hash,
            **kwargs,
        )
        return instance, raw_key

    def verify_key(self, raw_key: str) -> bool:
        return hashlib.sha256(raw_key.encode()).hexdigest() == self.key_hash

    def is_expired(self) -> bool:
        if self.expires_at is None:
            return False
        return timezone.now() > self.expires_at


# ---------------------------------------------------------------------------
# 9. État du strict mode
# ---------------------------------------------------------------------------

class StrictModeState(models.Model):
    """État courant du mode strict / lockdown."""

    MODE_OFF = "off"
    MODE_NORMAL = "normal"
    MODE_STRICT = "strict"
    MODE_LOCKDOWN = "lockdown"
    MODE_CHOICES = [
        (MODE_OFF, "Désactivé"),
        (MODE_NORMAL, "Normal"),
        (MODE_STRICT, "Strict"),
        (MODE_LOCKDOWN, "Lockdown"),
    ]

    # Une seule ligne active en base (singleton via pk=1)
    mode = models.CharField(
        max_length=10, choices=MODE_CHOICES, default=MODE_NORMAL
    )
    activated_at = models.DateTimeField(null=True, blank=True)
    activated_by = models.CharField(max_length=200, blank=True)
    reason = models.TextField(blank=True)
    threat_score = models.PositiveIntegerField(default=0)
    # Token aléatoire unique généré à chaque activation — constitue l'URL de déverrouillage
    unlock_token = models.CharField(max_length=128, blank=True, default="")
    # Lockdown actif en parallèle du whitelist mode (priorité absolue)
    lockdown_active = models.BooleanField(
        default=False,
        help_text="Lockdown actif indépendamment du mode principal. Lockdown > Whitelist > Normal.",
    )

    class Meta:
        verbose_name = "État du strict mode"

    def __str__(self):
        return f"Strict mode : {self.mode}"

    @classmethod
    def get_current(cls) -> "StrictModeState":
        state, _ = cls.objects.get_or_create(pk=1, defaults={"mode": cls.MODE_NORMAL})
        return state

    def activate(self, mode: str, reason: str = "", by: str = "system"):
        self.mode = mode
        self.activated_at = timezone.now()
        self.activated_by = by
        self.reason = reason
        self.save(update_fields=["mode", "activated_at", "activated_by", "reason"])

    def generate_unlock_token(self) -> str:
        """Génère un token URL aléatoire unique pour cette session de strict mode."""
        from django.core.cache import cache
        self.unlock_token = secrets.token_urlsafe(32)  # 43 caractères URL-safe
        self.save(update_fields=["unlock_token"])
        # Mise en cache pour performance (pas de requête DB à chaque requête)
        cache.set("xeolux_sk_unlock_token", self.unlock_token, timeout=None)
        return self.unlock_token

    def clear_unlock_token(self):
        """Invalide le token lors de la désactivation du strict mode."""
        from django.core.cache import cache
        self.unlock_token = ""
        self.save(update_fields=["unlock_token"])
        cache.delete("xeolux_sk_unlock_token")

    def deactivate(self):
        self.mode = self.MODE_NORMAL
        self.activated_at = None
        self.reason = ""
        self.threat_score = 0
        self.lockdown_active = False
        self.save(update_fields=["mode", "activated_at", "reason", "threat_score", "lockdown_active"])

    def activate_lockdown(self, reason: str = "", by: str = "system"):
        """Active le lockdown (priorité absolue) sans toucher au mode whitelist."""
        self.lockdown_active = True
        if not self.activated_at:
            self.activated_at = timezone.now()
        if by and not self.activated_by:
            self.activated_by = by
        if reason and not self.reason:
            self.reason = reason
        self.save(update_fields=["lockdown_active", "activated_at", "activated_by", "reason"])

    def deactivate_lockdown(self):
        """Désactive le lockdown. Le mode whitelist reste actif s'il était en cours."""
        self.lockdown_active = False
        # Si whitelist n'est plus actif non plus, réinitialiser
        if self.mode == self.MODE_NORMAL:
            self.activated_at = None
            self.reason = ""
            self.save(update_fields=["lockdown_active", "activated_at", "reason"])
        else:
            self.save(update_fields=["lockdown_active"])

    @property
    def effective_mode(self) -> str:
        """Mode effectif en tenant compte de la priorité lockdown > whitelist > normal."""
        if self.lockdown_active:
            return self.MODE_LOCKDOWN
        return self.mode

    @property
    def is_active(self) -> bool:
        return self.lockdown_active or self.mode in (self.MODE_STRICT, self.MODE_LOCKDOWN)


# ---------------------------------------------------------------------------
# 10. Codes de déverrouillage
# ---------------------------------------------------------------------------

class UnlockCode(models.Model):
    """Code temporaire pour sortir du strict mode."""

    code_hash = models.CharField(max_length=128, unique=True, editable=False)
    created_at = models.DateTimeField(auto_now_add=True)
    expires_at = models.DateTimeField()
    used = models.BooleanField(default=False)
    used_at = models.DateTimeField(null=True, blank=True)
    created_by = models.CharField(max_length=200, blank=True, default="system")
    attempt_count = models.PositiveIntegerField(default=0)

    class Meta:
        verbose_name = "Code de déverrouillage"
        verbose_name_plural = "Codes de déverrouillage"

    def __str__(self):
        return f"UnlockCode {'[utilisé]' if self.used else '[actif]'} exp={self.expires_at}"

    @classmethod
    def generate(cls, ttl_seconds: int = 3600) -> tuple["UnlockCode", str]:
        """Génère un code, retourne (instance, raw_code)."""
        from django.conf import settings
        length = getattr(settings, "XEOLUX_SECURITYKIT", {}).get("UNLOCK_CODE_LENGTH", 64)
        raw_code = secrets.token_urlsafe(length)
        code_hash = hashlib.sha256(raw_code.encode()).hexdigest()
        expires_at = timezone.now() + timezone.timedelta(seconds=ttl_seconds)
        # Invalider les anciens codes non utilisés
        cls.objects.filter(used=False).update(used=True)
        instance = cls.objects.create(
            code_hash=code_hash,
            expires_at=expires_at,
        )
        return instance, raw_code

    def verify(self, raw_code: str) -> bool:
        return hashlib.sha256(raw_code.encode()).hexdigest() == self.code_hash

    def is_valid(self) -> bool:
        return not self.used and timezone.now() < self.expires_at

    def consume(self):
        self.used = True
        self.used_at = timezone.now()
        self.save(update_fields=["used", "used_at"])


# ---------------------------------------------------------------------------
# 11. Bannissements temporaires
# ---------------------------------------------------------------------------

class TemporaryBan(models.Model):
    """Bannissement temporaire d'une IP."""

    REASON_BRUTEFORCE = "bruteforce"
    REASON_SCAN = "scan"
    REASON_FLOOD = "flood"
    REASON_MANUAL = "manual"
    REASON_CHOICES = [
        (REASON_BRUTEFORCE, "Brute force"),
        (REASON_SCAN, "Scan de routes"),
        (REASON_FLOOD, "Flood HTTP"),
        (REASON_MANUAL, "Manuel"),
    ]

    ip_address = models.CharField(max_length=50)
    reason = models.CharField(max_length=20, choices=REASON_CHOICES, default=REASON_MANUAL)
    details = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    expires_at = models.DateTimeField()
    lifted = models.BooleanField(default=False)

    class Meta:
        verbose_name = "Bannissement temporaire"
        verbose_name_plural = "Bannissements temporaires"
        indexes = [models.Index(fields=["ip_address", "expires_at"])]

    def __str__(self):
        return f"Ban {self.ip_address} jusqu'au {self.expires_at}"

    def is_active(self) -> bool:
        return not self.lifted and timezone.now() < self.expires_at


# ---------------------------------------------------------------------------
# 12. Profils de sécurité
# ---------------------------------------------------------------------------

class SecurityProfile(models.Model):
    """Profil de sécurité prédéfini ou personnalisé."""

    PROFILE_DEV = "dev"
    PROFILE_STANDARD = "standard"
    PROFILE_STRICT = "strict"
    PROFILE_STEALTH = "stealth"
    PROFILE_API_ONLY = "api_only"
    PROFILE_ADMIN_HARDENED = "admin_hardened"
    PROFILE_CUSTOM = "custom"
    PROFILE_CHOICES = [
        (PROFILE_DEV, "Développement"),
        (PROFILE_STANDARD, "Standard"),
        (PROFILE_STRICT, "Strict"),
        (PROFILE_STEALTH, "Furtif"),
        (PROFILE_API_ONLY, "API uniquement"),
        (PROFILE_ADMIN_HARDENED, "Admin renforcé"),
        (PROFILE_CUSTOM, "Personnalisé"),
    ]

    name = models.CharField(max_length=50, choices=PROFILE_CHOICES, unique=True)
    label = models.CharField(max_length=100)
    description = models.TextField(blank=True)
    # Configuration JSON des modules activés
    modules_config = models.JSONField(default=dict)
    is_active = models.BooleanField(default=False)

    class Meta:
        verbose_name = "Profil de sécurité"
        verbose_name_plural = "Profils de sécurité"

    def __str__(self):
        return f"{self.label} {'[actif]' if self.is_active else ''}"
