from django.db import migrations


class Migration(migrations.Migration):

    dependencies = [
        ("xeolux_securitykit", "0002_strictmodestate_unlock_token"),
    ]

    operations = [
        migrations.AlterModelOptions(
            name="securitykitconfig",
            options={
                "verbose_name": "Configuration SecurityKit",
                "verbose_name_plural": "Configurations SecurityKit",
                "permissions": [
                    ("access_securitykit", "Peut accéder à l'interface SecurityKit"),
                ],
            },
        ),
    ]
