from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ("xeolux_securitykit", "0003_securitykitconfig_access_permission"),
    ]

    operations = [
        # IPWhitelistEntry : flag strict whitelist dédié
        migrations.AddField(
            model_name="ipwhitelistentry",
            name="is_strict_whitelist",
            field=models.BooleanField(
                default=False,
                help_text="Cette IP peut accéder au site en mode Strict/Whitelist. Sans effet en mode Lockdown.",
            ),
        ),
        # StrictModeState : lockdown indépendant du mode whitelist
        migrations.AddField(
            model_name="strictmodestate",
            name="lockdown_active",
            field=models.BooleanField(
                default=False,
                help_text="Lockdown actif indépendamment du mode principal. Lockdown > Whitelist > Normal.",
            ),
        ),
    ]
