"""
Migration initiale pour xeolux_securitykit.
"""
