"""
Migration initiale : création de tous les modèles xeolux_securitykit.
"""

import django.db.models.deletion
import django.utils.timezone
from django.db import migrations, models


class Migration(migrations.Migration):

    initial = True

    dependencies = []

    operations = [
        migrations.CreateModel(
            name="SecurityKitConfig",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False)),
                ("key", models.CharField(max_length=100, unique=True)),
                ("value", models.TextField(blank=True, default="")),
                ("description", models.CharField(blank=True, max_length=255)),
                ("updated_at", models.DateTimeField(auto_now=True)),
            ],
            options={"verbose_name": "Configuration SecurityKit", "verbose_name_plural": "Configurations SecurityKit"},
        ),
        migrations.CreateModel(
            name="SecurityModuleState",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False)),
                ("module_name", models.CharField(max_length=100, unique=True)),
                ("enabled", models.BooleanField(default=True)),
                ("updated_at", models.DateTimeField(auto_now=True)),
                ("notes", models.TextField(blank=True)),
            ],
            options={"verbose_name": "État du module", "verbose_name_plural": "États des modules"},
        ),
        migrations.CreateModel(
            name="ProtectedRoute",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False)),
                ("path", models.CharField(max_length=500)),
                ("match_type", models.CharField(
                    choices=[("exact", "Exact"), ("prefix", "Préfixe"), ("regex", "Regex")],
                    default="exact", max_length=10,
                )),
                ("description", models.CharField(blank=True, max_length=255)),
                ("enabled", models.BooleanField(default=True)),
                ("created_at", models.DateTimeField(auto_now_add=True)),
            ],
            options={"verbose_name": "Route protégée", "verbose_name_plural": "Routes protégées", "ordering": ["path"]},
        ),
        migrations.CreateModel(
            name="RouteRule",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False)),
                ("route", models.ForeignKey(
                    on_delete=django.db.models.deletion.CASCADE,
                    related_name="rules",
                    to="xeolux_securitykit.protectedroute",
                )),
                ("action", models.CharField(
                    choices=[
                        ("fake_404", "Fake 404"), ("403", "Bloquer (403)"),
                        ("allow", "Autoriser"), ("redirect", "Rediriger"),
                        ("slow_down", "Ralentir"), ("empty", "Réponse vide"),
                    ],
                    default="fake_404", max_length=20,
                )),
                ("conditions", models.JSONField(blank=True, default=dict)),
                ("redirect_to", models.CharField(blank=True, max_length=500)),
                ("priority", models.PositiveIntegerField(default=10)),
                ("enabled", models.BooleanField(default=True)),
                ("description", models.CharField(blank=True, max_length=255)),
            ],
            options={"verbose_name": "Règle de route", "verbose_name_plural": "Règles de routes", "ordering": ["-priority"]},
        ),
        migrations.CreateModel(
            name="AccessPolicy",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False)),
                ("name", models.CharField(max_length=100, unique=True)),
                ("description", models.CharField(blank=True, max_length=255)),
                ("conditions", models.JSONField(default=dict)),
                ("deny_action", models.CharField(
                    choices=[
                        ("fake_404", "Fake 404"), ("403", "Bloquer (403)"),
                        ("allow", "Autoriser"), ("redirect", "Rediriger"),
                        ("slow_down", "Ralentir"), ("empty", "Réponse vide"),
                    ],
                    default="fake_404", max_length=20,
                )),
                ("enabled", models.BooleanField(default=True)),
            ],
            options={"verbose_name": "Politique d'accès", "verbose_name_plural": "Politiques d'accès"},
        ),
        migrations.CreateModel(
            name="IPWhitelistEntry",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False)),
                ("ip_or_cidr", models.CharField(max_length=50)),
                ("label", models.CharField(blank=True, max_length=100)),
                ("route", models.ForeignKey(
                    blank=True, null=True,
                    on_delete=django.db.models.deletion.SET_NULL,
                    related_name="whitelist_entries",
                    to="xeolux_securitykit.protectedroute",
                )),
                ("is_securitykit_access", models.BooleanField(default=False)),
                ("enabled", models.BooleanField(default=True)),
                ("created_at", models.DateTimeField(auto_now_add=True)),
            ],
            options={"verbose_name": "IP Whitelist", "verbose_name_plural": "IP Whitelist"},
        ),
        migrations.CreateModel(
            name="IPBlacklistEntry",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False)),
                ("ip_or_cidr", models.CharField(max_length=50)),
                ("label", models.CharField(blank=True, max_length=100)),
                ("reason", models.CharField(blank=True, max_length=255)),
                ("route", models.ForeignKey(
                    blank=True, null=True,
                    on_delete=django.db.models.deletion.SET_NULL,
                    related_name="blacklist_entries",
                    to="xeolux_securitykit.protectedroute",
                )),
                ("enabled", models.BooleanField(default=True)),
                ("created_at", models.DateTimeField(auto_now_add=True)),
                ("expires_at", models.DateTimeField(blank=True, null=True)),
            ],
            options={"verbose_name": "IP Blacklist", "verbose_name_plural": "IP Blacklist"},
        ),
        migrations.CreateModel(
            name="APIKey",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False)),
                ("name", models.CharField(max_length=100)),
                ("key_prefix", models.CharField(editable=False, max_length=10)),
                ("key_hash", models.CharField(editable=False, max_length=128)),
                ("allowed_routes", models.TextField(blank=True)),
                ("allowed_ips", models.TextField(blank=True)),
                ("enabled", models.BooleanField(default=True)),
                ("created_at", models.DateTimeField(auto_now_add=True)),
                ("expires_at", models.DateTimeField(blank=True, null=True)),
            ],
            options={"verbose_name": "Clé API", "verbose_name_plural": "Clés API"},
        ),
        migrations.CreateModel(
            name="StrictModeState",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False)),
                ("mode", models.CharField(
                    choices=[
                        ("off", "Désactivé"), ("normal", "Normal"),
                        ("strict", "Strict"), ("lockdown", "Lockdown"),
                    ],
                    default="normal", max_length=10,
                )),
                ("activated_at", models.DateTimeField(blank=True, null=True)),
                ("activated_by", models.CharField(blank=True, max_length=200)),
                ("reason", models.TextField(blank=True)),
                ("threat_score", models.PositiveIntegerField(default=0)),
            ],
            options={"verbose_name": "État du strict mode"},
        ),
        migrations.CreateModel(
            name="UnlockCode",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False)),
                ("code_hash", models.CharField(editable=False, max_length=128, unique=True)),
                ("created_at", models.DateTimeField(auto_now_add=True)),
                ("expires_at", models.DateTimeField()),
                ("used", models.BooleanField(default=False)),
                ("used_at", models.DateTimeField(blank=True, null=True)),
                ("created_by", models.CharField(blank=True, default="system", max_length=200)),
                ("attempt_count", models.PositiveIntegerField(default=0)),
            ],
            options={"verbose_name": "Code de déverrouillage", "verbose_name_plural": "Codes de déverrouillage"},
        ),
        migrations.CreateModel(
            name="TemporaryBan",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False)),
                ("ip_address", models.CharField(max_length=50)),
                ("reason", models.CharField(
                    choices=[
                        ("bruteforce", "Brute force"), ("scan", "Scan de routes"),
                        ("flood", "Flood HTTP"), ("manual", "Manuel"),
                    ],
                    default="manual", max_length=20,
                )),
                ("details", models.TextField(blank=True)),
                ("created_at", models.DateTimeField(auto_now_add=True)),
                ("expires_at", models.DateTimeField()),
                ("lifted", models.BooleanField(default=False)),
            ],
            options={"verbose_name": "Bannissement temporaire", "verbose_name_plural": "Bannissements temporaires"},
        ),
        migrations.AddIndex(
            model_name="temporaryban",
            index=models.Index(fields=["ip_address", "expires_at"], name="xeolux_temp_ban_idx"),
        ),
        migrations.CreateModel(
            name="SecurityProfile",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False)),
                ("name", models.CharField(
                    choices=[
                        ("dev", "Développement"), ("standard", "Standard"),
                        ("strict", "Strict"), ("stealth", "Furtif"),
                        ("api_only", "API uniquement"), ("admin_hardened", "Admin renforcé"),
                        ("custom", "Personnalisé"),
                    ],
                    max_length=50, unique=True,
                )),
                ("label", models.CharField(max_length=100)),
                ("description", models.TextField(blank=True)),
                ("modules_config", models.JSONField(default=dict)),
                ("is_active", models.BooleanField(default=False)),
            ],
            options={"verbose_name": "Profil de sécurité", "verbose_name_plural": "Profils de sécurité"},
        ),
    ]
