from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ("xeolux_securitykit", "0001_initial"),
    ]

    operations = [
        migrations.AddField(
            model_name="strictmodestate",
            name="unlock_token",
            field=models.CharField(
                blank=True,
                default="",
                max_length=128,
                help_text="Token URL aléatoire généré à chaque activation du strict mode.",
            ),
        ),
    ]
