"""
ip_whitelist — Gestion des IP et plages CIDR autorisées.
"""

import ipaddress
import logging
from functools import lru_cache

logger = logging.getLogger("xeolux_securitykit")


def _parse_network(ip_or_cidr: str):
    try:
        return ipaddress.ip_network(ip_or_cidr, strict=False)
    except ValueError:
        return None


def is_ip_in_global_whitelist(client_ip: str) -> bool:
    """Vérifie si une IP est dans la whitelist globale (sans route associée)."""
    from ..models import IPWhitelistEntry
    try:
        entries = IPWhitelistEntry.objects.filter(enabled=True, route__isnull=True)
        if not entries.exists():
            return True  # Aucune whitelist globale = tout autorisé
        return _ip_in_entries(client_ip, entries)
    except Exception:
        return True


def is_ip_whitelisted_for_securitykit(client_ip: str) -> bool:
    """
    Vérifie si une IP est autorisée pour l'interface /securitykit/.
    Si aucune entrée is_securitykit_access, retourne True (pas de restriction).
    """
    from ..models import IPWhitelistEntry
    try:
        entries = IPWhitelistEntry.objects.filter(enabled=True, is_securitykit_access=True)
        if not entries.exists():
            return True  # Pas de restriction whitelist pour securitykit
        return _ip_in_entries(client_ip, entries)
    except Exception:
        return True


def is_ip_in_strict_whitelist(client_ip: str) -> bool:
    """
    Vérifie si une IP est autorisée en mode Strict/Whitelist.
    UNIQUEMENT les entrées avec is_strict_whitelist=True sont vérifiées.
    Si aucune entrée de ce type n'existe → personne ne passe (blocage total en mode strict).
    """
    from ..models import IPWhitelistEntry
    try:
        entries = IPWhitelistEntry.objects.filter(
            enabled=True, is_strict_whitelist=True, route__isnull=True
        )
        return _ip_in_entries(client_ip, entries)
    except Exception:
        return False


def is_ip_whitelisted_for_route(client_ip: str, route_id: int) -> bool:
    """Vérifie si une IP est whitelistée pour une route spécifique."""
    from ..models import IPWhitelistEntry
    try:
        entries = IPWhitelistEntry.objects.filter(enabled=True, route_id=route_id)
        if not entries.exists():
            return True  # Aucune restriction par route
        return _ip_in_entries(client_ip, entries)
    except Exception:
        return True


def _ip_in_entries(client_ip: str, entries) -> bool:
    try:
        addr = ipaddress.ip_address(client_ip)
    except ValueError:
        return False

    for entry in entries:
        network = _parse_network(entry.ip_or_cidr)
        if network and addr in network:
            return True
    return False
