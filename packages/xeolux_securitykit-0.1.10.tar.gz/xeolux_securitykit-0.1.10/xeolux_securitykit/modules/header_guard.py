"""
header_guard — Analyse et validation des headers HTTP entrants.
"""

from django.http import HttpRequest


def check_headers(request: HttpRequest) -> tuple[bool, str]:
    """
    Vérifie les headers entrants pour détecter des anomalies.
    Retourne (is_safe: bool, reason: str).
    """
    # Host absent ou incohérent
    host = request.META.get("HTTP_HOST", "")
    if not host:
        return False, "missing_host"

    # Vérification ALLOWED_HOSTS
    from django.conf import settings
    allowed_hosts = getattr(settings, "ALLOWED_HOSTS", [])
    if "*" not in allowed_hosts and allowed_hosts:
        hostname = host.split(":")[0]
        if hostname not in allowed_hosts and not hostname.startswith("."):
            pass  # Django gère déjà cela via ALLOWED_HOSTS

    # Content-Type inattendu sur POST
    if request.method == "POST":
        content_type = request.META.get("CONTENT_TYPE", "")
        if content_type and _is_suspicious_content_type(content_type):
            return False, f"suspicious_content_type:{content_type}"

    return True, ""


def _is_suspicious_content_type(ct: str) -> bool:
    ct_lower = ct.lower()
    # On accepte les types courants
    allowed = [
        "application/json", "application/x-www-form-urlencoded",
        "multipart/form-data", "text/plain", "text/html",
    ]
    return not any(ct_lower.startswith(a) for a in allowed)
