"""
api_key_manager — Gestion des clés API depuis l'interface SecurityKit.
Délègue à APIKey.create_key() du modèle.
"""

from ..models import APIKey


def list_active_keys():
    return APIKey.objects.filter(enabled=True).order_by("-created_at")


def revoke_key(pk: int) -> bool:
    try:
        key = APIKey.objects.get(pk=pk)
        key.enabled = False
        key.save(update_fields=["enabled"])
        return True
    except APIKey.DoesNotExist:
        return False


def create_key(name: str, **kwargs) -> tuple[APIKey, str]:
    return APIKey.create_key(name=name, **kwargs)
