"""
bruteforce_protection — Protection des pages de connexion contre le brute force.
"""

import logging
from django.core.cache import cache

logger = logging.getLogger("xeolux_securitykit")

_BF_PREFIX = "xeolux_sk_bf_"


def record_failed_login(client_ip: str, username: str = "") -> int:
    """Enregistre une tentative de connexion échouée. Retourne le total."""
    ip_key = _BF_PREFIX + f"ip_{client_ip}"
    count_ip = cache.get(ip_key, 0) + 1
    cache.set(ip_key, count_ip, timeout=900)  # 15 minutes

    if username:
        user_key = _BF_PREFIX + f"user_{username}"
        cache.set(user_key, cache.get(user_key, 0) + 1, timeout=900)

    if count_ip >= 10:
        logger.warning(
            "xeolux_securitykit: brute force détecté depuis %s (%d tentatives)",
            client_ip, count_ip,
        )
        from ..modules.ip_blacklist import ban_ip_temporarily
        ban_ip_temporarily(client_ip, reason="bruteforce", duration_seconds=3600)

    return count_ip


def is_brute_forced(client_ip: str, username: str = "") -> bool:
    """Vérifie si l'IP ou l'utilisateur a dépassé le seuil de brute force."""
    ip_key = _BF_PREFIX + f"ip_{client_ip}"
    if cache.get(ip_key, 0) >= 10:
        return True
    if username:
        user_key = _BF_PREFIX + f"user_{username}"
        if cache.get(user_key, 0) >= 15:
            return True
    return False


def reset_failed_logins(client_ip: str, username: str = ""):
    """Réinitialise les compteurs après une connexion réussie."""
    cache.delete(_BF_PREFIX + f"ip_{client_ip}")
    if username:
        cache.delete(_BF_PREFIX + f"user_{username}")
