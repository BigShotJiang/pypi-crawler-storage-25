"""
bot_filter — Détection des comportements typiques de bots agressifs.
"""

import logging
from django.core.cache import cache

logger = logging.getLogger("xeolux_securitykit")

_BOT_SCORE_PREFIX = "xeolux_sk_bot_"


def analyze_request(client_ip: str, request) -> int:
    """
    Analyse la requête et retourne un score bot (0 = humain, 100 = bot certain).
    """
    score = 0
    ua = request.META.get("HTTP_USER_AGENT", "")

    # Pas de User-Agent
    if not ua:
        score += 30

    # Accept-Language absent (courant chez les bots)
    if not request.META.get("HTTP_ACCEPT_LANGUAGE"):
        score += 15

    # Pas de cookies de session (bots sans état)
    if not request.COOKIES:
        score += 10

    # Vitesse de navigation : trop de requêtes par seconde
    speed_key = _BOT_SCORE_PREFIX + f"speed_{client_ip}"
    req_count = cache.get(speed_key, 0) + 1
    cache.set(speed_key, req_count, timeout=2)
    if req_count > 10:
        score += 25

    return min(score, 100)


def is_likely_bot(client_ip: str, request) -> bool:
    """Retourne True si le comportement ressemble à un bot agressif."""
    score = analyze_request(client_ip, request)
    return score >= 60
