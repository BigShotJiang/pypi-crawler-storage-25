"""
user_agent_blocker — Blocage des User-Agents suspects ou malveillants.
"""

import re

# Patterns de User-Agents bloqués par défaut
BLOCKED_UA_PATTERNS = [
    # Scanners de vulnérabilités
    r"nikto",
    r"sqlmap",
    r"nmap",
    r"masscan",
    r"zgrab",
    r"dirbuster",
    r"gobuster",
    r"wfuzz",
    r"nuclei",
    r"openvas",
    r"acunetix",
    r"nessus",
    r"w3af",
    r"burpsuite",
    r"owasp",
    # Scrapers agressifs
    r"scrapy",
    r"wget(?!/.*bot)",  # wget sauf wget/bot légitimes
    r"libwww-perl",
    r"python-requests(?!/.*legit)",
    # Bots connus malveillants
    r"ahrefsbot",
    r"semrushbot",
    r"dotbot",
    r"rogerbot",
    r"mj12bot",
    r"blexbot",
    r"serpstatbot",
    r"petalbot",
    r"bytespider",
    # Bots de hacking
    r"zgrab",
    r"gocolly",
    r"go-http-client/1\.",
    r"curl(?!/.*legit)",
]

# User-Agents toujours autorisés (même si un pattern correspond)
ALLOWED_UA_PATTERNS = [
    r"googlebot",
    r"bingbot",
    r"facebookexternalhit",
    r"twitterbot",
    r"linkedinbot",
]


def is_blocked_user_agent(user_agent: str) -> bool:
    """Retourne True si le User-Agent doit être bloqué."""
    if not user_agent:
        # User-Agent vide est suspect mais pas nécessairement à bloquer par défaut
        return False

    ua_lower = user_agent.lower()

    # Vérifier si l'UA est dans la liste des toujours autorisés
    for pattern in ALLOWED_UA_PATTERNS:
        if re.search(pattern, ua_lower, re.IGNORECASE):
            return False

    # Vérifier si l'UA correspond à un pattern bloqué
    for pattern in BLOCKED_UA_PATTERNS:
        if re.search(pattern, ua_lower, re.IGNORECASE):
            return True

    return False


def is_empty_user_agent(user_agent: str) -> bool:
    return not user_agent or user_agent.strip() == ""
