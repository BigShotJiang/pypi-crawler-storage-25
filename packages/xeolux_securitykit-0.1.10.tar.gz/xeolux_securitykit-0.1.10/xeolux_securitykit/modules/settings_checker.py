"""
settings_checker — Diagnostic de la configuration Django de sécurité.
"""

from django.conf import settings


def run_diagnostics() -> list[dict]:
    """Lance tous les diagnostics et retourne une liste de résultats."""
    results = []
    results.extend(_check_debug())
    results.extend(_check_secret_key())
    results.extend(_check_allowed_hosts())
    results.extend(_check_https_settings())
    results.extend(_check_cookie_settings())
    results.extend(_check_middleware())
    results.extend(_check_installed_apps())
    return results


def _check_debug() -> list[dict]:
    ok = not getattr(settings, "DEBUG", True)
    return [{
        "category": "Django",
        "check": "DEBUG désactivé",
        "ok": ok,
        "severity": "critical" if not ok else "ok",
        "message": "DEBUG=True est dangereux en production." if not ok else "",
    }]


def _check_secret_key() -> list[dict]:
    key = getattr(settings, "SECRET_KEY", "")
    is_default = "django-insecure" in key or len(key) < 40
    return [{
        "category": "Django",
        "check": "SECRET_KEY robuste",
        "ok": not is_default,
        "severity": "critical" if is_default else "ok",
        "message": "SECRET_KEY trop courte ou par défaut." if is_default else "",
    }]


def _check_allowed_hosts() -> list[dict]:
    hosts = getattr(settings, "ALLOWED_HOSTS", [])
    wildcard = "*" in hosts
    return [{
        "category": "Django",
        "check": "ALLOWED_HOSTS sans wildcard",
        "ok": not wildcard,
        "severity": "warning" if wildcard else "ok",
        "message": "ALLOWED_HOSTS contient '*', risqué en production." if wildcard else "",
    }]


def _check_https_settings() -> list[dict]:
    results = []
    checks = [
        ("SECURE_SSL_REDIRECT", True, "HTTPS"),
        ("SECURE_HSTS_SECONDS", 31536000, "HSTS"),
        ("SECURE_CONTENT_TYPE_NOSNIFF", True, "Content-Type nosniff"),
    ]
    for setting, expected, label in checks:
        value = getattr(settings, setting, None)
        ok = value == expected or (isinstance(expected, int) and isinstance(value, int) and value > 0)
        results.append({
            "category": "HTTPS",
            "check": label,
            "ok": ok,
            "severity": "warning" if not ok else "ok",
            "message": f"{setting} non configuré." if not ok else "",
        })
    return results


def _check_cookie_settings() -> list[dict]:
    results = []
    cookie_settings = [
        ("SESSION_COOKIE_SECURE", True),
        ("SESSION_COOKIE_HTTPONLY", True),
        ("CSRF_COOKIE_SECURE", True),
    ]
    for setting, expected in cookie_settings:
        value = getattr(settings, setting, None)
        ok = value == expected
        results.append({
            "category": "Cookies",
            "check": setting,
            "ok": ok,
            "severity": "warning" if not ok else "ok",
            "message": f"{setting} devrait être True." if not ok else "",
        })
    return results


def _check_middleware() -> list[dict]:
    middleware = list(getattr(settings, "MIDDLEWARE", []))
    results = []

    important = [
        "django.middleware.security.SecurityMiddleware",
        "django.middleware.csrf.CsrfViewMiddleware",
        "django.contrib.auth.middleware.AuthenticationMiddleware",
    ]
    for mw in important:
        ok = mw in middleware
        results.append({
            "category": "Middleware",
            "check": mw.split(".")[-1],
            "ok": ok,
            "severity": "warning" if not ok else "ok",
            "message": f"{mw} manquant dans MIDDLEWARE." if not ok else "",
        })
    return results


def _check_installed_apps() -> list[dict]:
    apps = list(getattr(settings, "INSTALLED_APPS", []))
    results = []
    important = [
        "django.contrib.auth",
        "django.contrib.contenttypes",
    ]
    for app in important:
        ok = app in apps
        results.append({
            "category": "Apps",
            "check": app,
            "ok": ok,
            "severity": "warning" if not ok else "ok",
            "message": f"{app} manquant dans INSTALLED_APPS." if not ok else "",
        })
    return results
