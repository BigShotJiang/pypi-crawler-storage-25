"""
rate_limit — Limitation des requêtes par IP, utilisateur ou route.
"""

from django.core.cache import cache
from django.http import HttpRequest
from typing import Optional


def check_rate_limit(
    key: str,
    max_requests: int = 60,
    window_seconds: int = 60,
) -> tuple[bool, int]:
    """
    Vérifie si la limite de requêtes est dépassée.
    Retourne (allowed: bool, remaining: int).
    """
    cache_key = f"xeolux_sk_rl_{key}"
    current = cache.get(cache_key, 0)
    if current >= max_requests:
        return False, 0
    cache.set(cache_key, current + 1, timeout=window_seconds)
    return True, max_requests - current - 1


def rate_limit_by_ip(
    client_ip: str,
    max_requests: int = 120,
    window_seconds: int = 60,
) -> tuple[bool, int]:
    """Rate limit par IP."""
    return check_rate_limit(f"ip_{client_ip}", max_requests, window_seconds)


def rate_limit_by_user(
    user_id: int,
    max_requests: int = 200,
    window_seconds: int = 60,
) -> tuple[bool, int]:
    """Rate limit par utilisateur authentifié."""
    return check_rate_limit(f"user_{user_id}", max_requests, window_seconds)


def rate_limit_by_route(
    client_ip: str,
    path: str,
    max_requests: int = 30,
    window_seconds: int = 60,
) -> tuple[bool, int]:
    """Rate limit par IP + route."""
    import hashlib
    route_hash = hashlib.md5(path.encode()).hexdigest()[:8]
    return check_rate_limit(f"route_{client_ip}_{route_hash}", max_requests, window_seconds)
