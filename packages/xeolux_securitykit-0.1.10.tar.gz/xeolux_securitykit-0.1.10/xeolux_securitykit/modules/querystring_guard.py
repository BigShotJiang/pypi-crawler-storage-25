"""
querystring_guard — Détection d'injections et anomalies dans les query strings.
"""

import re
from django.http import HttpRequest

MAX_PARAM_LENGTH = 2000

# Patterns d'injection simples (non exhaustifs, ne remplace pas un WAF)
INJECTION_PATTERNS = [
    r"(\bSELECT\b|\bINSERT\b|\bDROP\b|\bUNION\b)",  # SQL
    r"(<script|javascript:|onerror=|onload=)",          # XSS basique
    r"\.\./|\.\.\\",                                     # Traversal
    r"(\bexec\b|\beval\b|\bsystem\b)",                   # Code injection
]


def check_querystring(request: HttpRequest) -> tuple[bool, str]:
    """Analyse les paramètres GET pour détecter des anomalies."""
    for key, value in request.GET.items():
        # Paramètre trop long
        if len(value) > MAX_PARAM_LENGTH:
            return False, f"param_too_long:{key}"

        # Patterns d'injection
        for pattern in INJECTION_PATTERNS:
            if re.search(pattern, value, re.IGNORECASE):
                return False, f"injection_pattern:{key}"

    return True, ""


def check_redirect_param(request: HttpRequest, param_names: list[str] | None = None) -> tuple[bool, str]:
    """Vérifie les paramètres de redirection pour éviter les open redirects."""
    if param_names is None:
        param_names = ["next", "redirect", "return_url", "callback", "continue", "url", "goto"]

    for param in param_names:
        value = request.GET.get(param, "")
        if value and _is_unsafe_redirect(value):
            return False, f"unsafe_redirect:{param}={value}"

    return True, ""


def _is_unsafe_redirect(url: str) -> bool:
    """Retourne True si l'URL est une redirection vers un domaine externe."""
    return url.startswith("//") or url.lower().startswith("http")
