"""
honeypot — Protection honeypot pour les formulaires publics.
"""


HONEYPOT_FIELD_NAME = "website_url"  # Champ invisible dans les formulaires


def is_honeypot_triggered(post_data: dict) -> bool:
    """
    Retourne True si le champ honeypot a été rempli.
    Un humain ne remplit pas un champ caché en CSS/JS.
    """
    value = post_data.get(HONEYPOT_FIELD_NAME, "")
    return bool(value and value.strip())


def get_honeypot_field_name() -> str:
    return HONEYPOT_FIELD_NAME
