"""
suspicious_paths — Détection et blocage des chemins URL suspects.
"""

SUSPICIOUS_PATTERNS = [
    # Fichiers d'environnement
    ".env", ".env.local", ".env.production", ".env.staging",
    # Git
    ".git/", ".git", ".gitignore", ".gitconfig",
    # CMS vulnérables
    "wp-admin", "wp-login", "wp-content", "wp-includes", "xmlrpc.php",
    "wp-config.php", "wp-json",
    # Admin communs
    "phpmyadmin", "pma", "phpMyAdmin", "adminer", "myadmin",
    # Fichiers de config
    "web.config", "htaccess", ".htaccess", ".htpasswd",
    # Scripts connus exploités
    "eval-stdin.php", "cgi-bin", "shell.php", "cmd.php",
    "webshell", "c99.php", "r57.php",
    # Répertoires sensibles
    "/etc/passwd", "/etc/shadow", "/proc/self",
    # Traversal
    "../", "..\\", "%2e%2e%2f", "%2e%2e/", "%252e%252e",
    # AWS metadata
    "169.254.169.254", "metadata.internal",
    # Autres
    "backup.zip", "backup.tar", "site.tar.gz",
    "credentials", "secret.txt",
]


def is_suspicious_path(path: str) -> bool:
    """Retourne True si le chemin contient un pattern suspect."""
    path_lower = path.lower()
    for pattern in SUSPICIOUS_PATTERNS:
        if pattern.lower() in path_lower:
            return True
    return False


def get_matched_pattern(path: str) -> str | None:
    """Retourne le pattern correspondant ou None."""
    path_lower = path.lower()
    for pattern in SUSPICIOUS_PATTERNS:
        if pattern.lower() in path_lower:
            return pattern
    return None
