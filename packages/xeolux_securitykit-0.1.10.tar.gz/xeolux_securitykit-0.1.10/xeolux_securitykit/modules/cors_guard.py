"""
cors_guard — Contrôle des origines pour les requêtes cross-origin.
"""

from django.http import HttpRequest, HttpResponse


def is_origin_allowed(origin: str, allowed_origins: list[str]) -> bool:
    """Vérifie si une origine est dans la liste autorisée."""
    if not allowed_origins:
        return True
    return origin in allowed_origins or "*" in allowed_origins


def check_cors(request: HttpRequest, allowed_origins: list[str] | None = None) -> bool:
    """Vérifie si la requête CORS est autorisée."""
    origin = request.META.get("HTTP_ORIGIN", "")
    if not origin:
        return True  # Pas une requête CORS

    if allowed_origins is None:
        from django.conf import settings
        allowed_origins = getattr(settings, "CORS_ALLOWED_ORIGINS", [])

    return is_origin_allowed(origin, allowed_origins)


def add_cors_headers(response: HttpResponse, origin: str, allowed_origins: list[str]) -> HttpResponse:
    """Ajoute les headers CORS à la réponse si l'origine est autorisée."""
    if is_origin_allowed(origin, allowed_origins):
        response["Access-Control-Allow-Origin"] = origin
        response["Vary"] = "Origin"
    return response
