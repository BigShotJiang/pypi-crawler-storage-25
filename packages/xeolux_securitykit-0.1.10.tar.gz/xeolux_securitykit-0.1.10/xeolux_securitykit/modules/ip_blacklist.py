"""
ip_blacklist — Gestion des IP et plages CIDR bloquées.
"""

import ipaddress
import logging
from django.utils import timezone

logger = logging.getLogger("xeolux_securitykit")


def is_ip_blacklisted(client_ip: str) -> bool:
    """Vérifie si une IP est dans la blacklist globale active."""
    from ..models import IPBlacklistEntry
    try:
        now = timezone.now()
        entries = IPBlacklistEntry.objects.filter(enabled=True, route__isnull=True)
        return _ip_in_entries(client_ip, entries, now)
    except Exception:
        return False


def is_ip_blacklisted_for_route(client_ip: str, route_id: int) -> bool:
    """Vérifie si une IP est blacklistée pour une route spécifique."""
    from ..models import IPBlacklistEntry
    try:
        now = timezone.now()
        entries = IPBlacklistEntry.objects.filter(enabled=True, route_id=route_id)
        return _ip_in_entries(client_ip, entries, now)
    except Exception:
        return False


def is_temporarily_banned(client_ip: str) -> bool:
    """Vérifie si une IP est sous bannissement temporaire actif."""
    from ..models import TemporaryBan
    try:
        now = timezone.now()
        return TemporaryBan.objects.filter(
            ip_address=client_ip,
            lifted=False,
            expires_at__gt=now,
        ).exists()
    except Exception:
        return False


def ban_ip_temporarily(client_ip: str, reason: str, duration_seconds: int = 3600, details: str = ""):
    """Crée un bannissement temporaire pour une IP."""
    from ..models import TemporaryBan
    expires_at = timezone.now() + timezone.timedelta(seconds=duration_seconds)
    TemporaryBan.objects.create(
        ip_address=client_ip,
        reason=reason,
        details=details,
        expires_at=expires_at,
    )
    logger.info("xeolux_securitykit: IP %s bannie temporairement pour %ds (raison: %s)", client_ip, duration_seconds, reason)


def _ip_in_entries(client_ip: str, entries, now=None) -> bool:
    try:
        addr = ipaddress.ip_address(client_ip)
    except ValueError:
        return False

    for entry in entries:
        # Vérifier expiration
        if now and entry.expires_at and entry.expires_at < now:
            continue
        try:
            network = ipaddress.ip_network(entry.ip_or_cidr, strict=False)
            if addr in network:
                return True
        except ValueError:
            continue
    return False
