"""
cookie_guard — Vérification et renforcement des cookies de sécurité.
"""

from django.http import HttpResponse


def audit_cookies(response: HttpResponse) -> list[dict]:
    """Audit des cookies présents dans la réponse."""
    results = []
    for cookie_name, morsel in response.cookies.items():
        results.append({
            "name": cookie_name,
            "secure": bool(morsel["secure"]),
            "httponly": bool(morsel["httponly"]),
            "samesite": morsel.get("samesite", ""),
        })
    return results


def harden_session_cookie(response: HttpResponse) -> HttpResponse:
    """Renforce le cookie de session si présent dans la réponse."""
    from django.conf import settings
    session_cookie_name = getattr(settings, "SESSION_COOKIE_NAME", "sessionid")

    if session_cookie_name in response.cookies:
        cookie = response.cookies[session_cookie_name]
        if not getattr(settings, "DEBUG", True):
            cookie["secure"] = True
        cookie["httponly"] = True
        if not cookie.get("samesite"):
            cookie["samesite"] = "Lax"

    return response


def check_session_cookie_settings() -> list[dict]:
    """Vérifie la configuration des cookies depuis settings.py."""
    from django.conf import settings
    issues = []

    checks = [
        ("SESSION_COOKIE_SECURE", True, "SESSION_COOKIE_SECURE devrait être True en production"),
        ("SESSION_COOKIE_HTTPONLY", True, "SESSION_COOKIE_HTTPONLY devrait être True"),
        ("CSRF_COOKIE_SECURE", True, "CSRF_COOKIE_SECURE devrait être True en production"),
        ("CSRF_COOKIE_HTTPONLY", False, None),  # Pas une obligation
    ]

    for setting_name, expected, message in checks:
        value = getattr(settings, setting_name, None)
        issues.append({
            "setting": setting_name,
            "value": value,
            "ok": value == expected or value is None,
            "message": message or "",
        })

    return issues
