"""
security_headers — Ajout et vérification des headers HTTP de sécurité.
"""

from django.http import HttpResponse


DEFAULT_HEADERS = {
    "X-Content-Type-Options": "nosniff",
    "X-Frame-Options": "DENY",
    "X-XSS-Protection": "1; mode=block",
    "Referrer-Policy": "strict-origin-when-cross-origin",
    "Permissions-Policy": "geolocation=(), camera=(), microphone=()",
    "X-Permitted-Cross-Domain-Policies": "none",
}

HSTS_HEADER = "Strict-Transport-Security"
HSTS_VALUE = "max-age=31536000; includeSubDomains"


def apply_security_headers(response: HttpResponse) -> HttpResponse:
    """Applique les headers de sécurité par défaut à une réponse."""
    for header, value in DEFAULT_HEADERS.items():
        if header not in response:
            response[header] = value

    # HSTS uniquement en production (HTTPS)
    from django.conf import settings
    if not getattr(settings, "DEBUG", True):
        if HSTS_HEADER not in response:
            response[HSTS_HEADER] = HSTS_VALUE

    return response


def audit_headers(response: HttpResponse) -> list[dict]:
    """Retourne une liste des headers de sécurité présents/absents."""
    results = []
    all_headers = list(DEFAULT_HEADERS.keys()) + [HSTS_HEADER]
    for header in all_headers:
        results.append({
            "header": header,
            "present": header in response,
            "value": response.get(header, ""),
        })
    return results
