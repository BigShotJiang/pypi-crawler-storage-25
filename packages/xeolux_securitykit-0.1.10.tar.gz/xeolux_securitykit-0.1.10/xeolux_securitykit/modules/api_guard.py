"""
api_guard — Protection des routes API sensibles.
"""

from django.http import HttpRequest
from typing import Optional


def has_valid_api_key(request: HttpRequest) -> bool:
    """
    Vérifie si la requête contient une clé API valide.
    La clé peut être dans le header 'X-API-Key' ou en query param 'api_key'.
    """
    raw_key = (
        request.META.get("HTTP_X_API_KEY")
        or request.GET.get("api_key")
        or ""
    )
    if not raw_key:
        return False

    return _verify_api_key(raw_key, request)


def _verify_api_key(raw_key: str, request: HttpRequest) -> bool:
    from ..models import APIKey
    from django.utils import timezone
    import hashlib

    key_hash = hashlib.sha256(raw_key.encode()).hexdigest()

    try:
        key = APIKey.objects.filter(key_hash=key_hash, enabled=True).first()
    except Exception:
        return False

    if not key:
        return False

    if key.is_expired():
        return False

    # Vérification IP si restreinte
    if key.allowed_ips:
        import ipaddress
        client_ip = _get_client_ip(request)
        allowed = [ip.strip() for ip in key.allowed_ips.split(",") if ip.strip()]
        try:
            addr = ipaddress.ip_address(client_ip)
            matched = any(
                addr in ipaddress.ip_network(net, strict=False)
                for net in allowed
            )
            if not matched:
                return False
        except ValueError:
            return False

    # Vérification route si restreinte
    if key.allowed_routes:
        path = request.path_info
        routes = [r.strip() for r in key.allowed_routes.split(",") if r.strip()]
        if not any(path.startswith(r) for r in routes):
            return False

    return True


def _get_client_ip(request: HttpRequest) -> str:
    x_forwarded = request.META.get("HTTP_X_FORWARDED_FOR")
    if x_forwarded:
        return x_forwarded.split(",")[0].strip()
    return request.META.get("REMOTE_ADDR", "")
