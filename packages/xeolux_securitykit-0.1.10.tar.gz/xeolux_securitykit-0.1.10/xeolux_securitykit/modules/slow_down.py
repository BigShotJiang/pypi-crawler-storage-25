"""
slow_down — Ralentissement volontaire de certaines réponses suspectes.
"""

import time
import logging

logger = logging.getLogger("xeolux_securitykit")


def slow_down_response(delay: float = 2.0):
    """Introduit un délai volontaire dans le traitement."""
    safe_delay = min(max(delay, 0.1), 10.0)  # entre 0.1s et 10s
    logger.debug("xeolux_securitykit: slow_down — délai %.1fs appliqué", safe_delay)
    time.sleep(safe_delay)


def get_delay_for_score(threat_score: int) -> float:
    """Retourne un délai proportionnel au score de menace."""
    if threat_score >= 80:
        return 5.0
    elif threat_score >= 50:
        return 3.0
    elif threat_score >= 20:
        return 1.5
    return 0.5
