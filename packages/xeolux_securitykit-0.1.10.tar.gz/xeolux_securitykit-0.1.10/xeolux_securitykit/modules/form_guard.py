"""
form_guard — Protection des formulaires publics contre les abus.
"""

import re
from django.core.cache import cache

_FORM_PREFIX = "xeolux_sk_form_"

SUSPICIOUS_KEYWORDS = [
    "viagra", "casino", "loan", "credit", "bitcoin", "crypto",
    "click here", "free money", "earn $",
]

SUSPICIOUS_LINK_PATTERNS = [
    r"https?://[^\s]+\.(ru|cn|tk|ml|ga|cf)/",
]


def check_form_submission(client_ip: str, post_data: dict) -> tuple[bool, str]:
    """
    Vérifie si une soumission de formulaire est légitime.
    Retourne (is_safe: bool, reason: str).
    """
    # Honeypot
    from .honeypot import is_honeypot_triggered
    if is_honeypot_triggered(post_data):
        return False, "honeypot"

    # Délai minimal (anti-spam automatisé)
    if not _check_min_delay(client_ip):
        return False, "too_fast"

    # Mots-clés suspects dans les valeurs
    all_text = " ".join(str(v) for v in post_data.values()).lower()
    for kw in SUSPICIOUS_KEYWORDS:
        if kw in all_text:
            return False, f"suspicious_keyword:{kw}"

    # Liens suspects
    for pattern in SUSPICIOUS_LINK_PATTERNS:
        if re.search(pattern, all_text, re.IGNORECASE):
            return False, "suspicious_link"

    return True, ""


def _check_min_delay(client_ip: str, min_seconds: int = 3) -> bool:
    """Vérifie qu'un délai minimum s'est écoulé depuis la dernière soumission."""
    key = _FORM_PREFIX + f"last_submit_{client_ip}"
    if cache.get(key):
        return False
    cache.set(key, 1, timeout=min_seconds)
    return True
