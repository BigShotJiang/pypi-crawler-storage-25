"""
payload_guard — Contrôle du contenu et de la taille des requêtes.
"""

from django.http import HttpRequest

MAX_PAYLOAD_SIZE = 10 * 1024 * 1024  # 10 MB par défaut
MAX_JSON_DEPTH = 20

BLOCKED_UPLOAD_EXTENSIONS = [
    ".php", ".php3", ".php4", ".php5", ".phtml",
    ".asp", ".aspx", ".exe", ".bat", ".sh", ".py",
    ".pl", ".cgi", ".htaccess",
]


def check_payload(request: HttpRequest) -> tuple[bool, str]:
    """Vérifie le payload d'une requête POST/PUT."""
    if request.method not in ("POST", "PUT", "PATCH"):
        return True, ""

    # Taille du payload
    content_length = request.META.get("CONTENT_LENGTH")
    if content_length:
        try:
            size = int(content_length)
            if size > MAX_PAYLOAD_SIZE:
                return False, f"payload_too_large:{size}"
        except ValueError:
            pass

    return True, ""


def check_file_upload(filename: str) -> tuple[bool, str]:
    """Vérifie qu'un fichier uploadé n'a pas une extension dangereuse."""
    lower = filename.lower()
    for ext in BLOCKED_UPLOAD_EXTENSIONS:
        if lower.endswith(ext):
            return False, f"blocked_extension:{ext}"
    return True, ""
