"""
stealth_admin — Masquage de l'interface admin Django.
"""

from django.http import HttpRequest
from typing import Optional


ADMIN_PATH = "/admin/"


def is_admin_path(path: str) -> bool:
    return path.startswith(ADMIN_PATH)


def should_hide_admin(request: HttpRequest) -> bool:
    """
    Retourne True si l'admin doit être masqué pour cette requête.
    L'admin reste accessible aux superusers connectés.
    """
    from ..services.module_registry import is_module_enabled
    if not is_module_enabled("stealth_admin"):
        return False

    user = request.user
    if user.is_authenticated and user.is_superuser:
        return False  # Superuser → accès normal

    return True
