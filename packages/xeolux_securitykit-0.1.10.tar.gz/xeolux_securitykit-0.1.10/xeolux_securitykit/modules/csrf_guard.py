"""
csrf_guard — Vérification et renforcement de la protection CSRF.
"""

from django.http import HttpRequest


def check_csrf_exempt_views() -> list[dict]:
    """
    Retourne la liste des vues qui ont @csrf_exempt appliqué.
    Utile pour l'audit de sécurité depuis les diagnostics.
    """
    from django.urls import get_resolver
    from django.views.decorators.csrf import csrf_exempt

    results = []
    resolver = get_resolver()
    _scan_patterns(resolver.url_patterns, "", results)
    return results


def _scan_patterns(patterns, prefix, results):
    from django.urls import URLPattern, URLResolver
    for pattern in patterns:
        path = prefix + str(pattern.pattern)
        if isinstance(pattern, URLResolver):
            _scan_patterns(pattern.url_patterns, path, results)
        elif isinstance(pattern, URLPattern):
            callback = pattern.callback
            # Détecter csrf_exempt : Django marque la vue avec csrf_exempt=True
            if getattr(callback, "csrf_exempt", False):
                results.append({
                    "path": path,
                    "view": getattr(callback, "__name__", str(callback)),
                    "module": getattr(callback, "__module__", ""),
                })
