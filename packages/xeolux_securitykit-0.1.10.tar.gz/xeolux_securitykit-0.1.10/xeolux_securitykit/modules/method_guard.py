"""
method_guard — Contrôle des méthodes HTTP autorisées.
"""

from django.http import HttpRequest

# Méthodes généralement dangereuses ou inutiles
DEFAULT_BLOCKED_METHODS = {"TRACE", "TRACK", "CONNECT"}


def is_method_blocked(request: HttpRequest, extra_blocked: set | None = None) -> bool:
    """Retourne True si la méthode HTTP doit être bloquée."""
    blocked = DEFAULT_BLOCKED_METHODS.copy()
    if extra_blocked:
        blocked.update(extra_blocked)
    return request.method.upper() in blocked


def is_method_allowed_for_route(method: str, allowed_methods: list[str]) -> bool:
    """Vérifie si la méthode est dans la liste autorisée pour une route."""
    if not allowed_methods:
        return True
    return method.upper() in [m.upper() for m in allowed_methods]
