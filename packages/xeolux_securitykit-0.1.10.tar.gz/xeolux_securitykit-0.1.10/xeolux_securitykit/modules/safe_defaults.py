"""
safe_defaults — Configuration sûre par défaut recommandée pour Django.
"""


SAFE_SETTINGS_RECOMMENDATIONS = {
    "DEBUG": False,
    "SECURE_SSL_REDIRECT": True,
    "SECURE_HSTS_SECONDS": 31536000,
    "SECURE_HSTS_INCLUDE_SUBDOMAINS": True,
    "SECURE_HSTS_PRELOAD": True,
    "SECURE_CONTENT_TYPE_NOSNIFF": True,
    "SECURE_BROWSER_XSS_FILTER": True,
    "SESSION_COOKIE_SECURE": True,
    "SESSION_COOKIE_HTTPONLY": True,
    "SESSION_COOKIE_SAMESITE": "Lax",
    "CSRF_COOKIE_SECURE": True,
    "CSRF_COOKIE_HTTPONLY": True,
    "X_FRAME_OPTIONS": "DENY",
}


def get_recommendations() -> list[dict]:
    """Retourne la liste des recommandations avec l'état actuel."""
    from django.conf import settings
    results = []
    for key, recommended_value in SAFE_SETTINGS_RECOMMENDATIONS.items():
        current = getattr(settings, key, None)
        results.append({
            "setting": key,
            "current": current,
            "recommended": recommended_value,
            "ok": current == recommended_value,
        })
    return results
