"""
file_access_guard — Blocage des tentatives d'accès à des fichiers sensibles.
"""

SENSITIVE_EXTENSIONS = [
    ".env", ".sql", ".sqlite3", ".sqlite", ".db",
    ".bak", ".backup", ".zip", ".tar", ".tar.gz", ".tgz",
    ".log", ".ini", ".conf", ".config",
    ".pem", ".key", ".crt", ".p12", ".pfx",
    ".htpasswd", ".htaccess",
    ".DS_Store",
]

SENSITIVE_FILENAMES = [
    "web.config", "phpinfo.php", "info.php", "test.php",
    "credentials.json", "secrets.json", "config.yml", "config.yaml",
]


def is_sensitive_file_path(path: str) -> bool:
    """Retourne True si le chemin vise un fichier potentiellement sensible."""
    path_lower = path.lower().rstrip("/")

    # Vérification des extensions
    for ext in SENSITIVE_EXTENSIONS:
        if path_lower.endswith(ext.lower()):
            return True

    # Vérification des noms de fichiers
    filename = path_lower.split("/")[-1]
    for sensitive in SENSITIVE_FILENAMES:
        if filename == sensitive.lower():
            return True

    return False
