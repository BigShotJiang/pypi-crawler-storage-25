"""
redirect_guard — Protection contre les open redirects.
"""

from django.http import HttpRequest


REDIRECT_PARAMS = ["next", "redirect", "return_url", "callback", "continue", "url", "goto", "return"]


def is_safe_redirect_url(url: str, allowed_hosts: list[str] | None = None) -> bool:
    """
    Vérifie qu'une URL de redirection est sûre (relative ou vers un domaine autorisé).
    """
    if not url:
        return True

    # Les URLs relatives sont généralement sûres
    if url.startswith("/") and not url.startswith("//"):
        return True

    # Les URLs vers d'autres domaines sont potentiellement dangereuses
    if url.startswith("//") or url.lower().startswith("http"):
        if allowed_hosts:
            from urllib.parse import urlparse
            parsed = urlparse(url)
            return parsed.hostname in allowed_hosts
        return False

    return True


def sanitize_redirect_url(url: str, fallback: str = "/") -> str:
    """Retourne l'URL si sûre, sinon le fallback."""
    from django.conf import settings
    allowed = getattr(settings, "ALLOWED_HOSTS", [])
    if is_safe_redirect_url(url, allowed):
        return url
    return fallback


def check_redirect_params(request: HttpRequest) -> tuple[bool, str]:
    """Vérifie les paramètres de redirection dans la requête GET."""
    from django.conf import settings
    allowed = getattr(settings, "ALLOWED_HOSTS", [])

    for param in REDIRECT_PARAMS:
        value = request.GET.get(param, "")
        if value and not is_safe_redirect_url(value, allowed):
            return False, f"open_redirect:{param}={value}"

    return True, ""
