"""
webhook_guard — Protection des webhooks entrants.
"""

import hashlib
import hmac
from django.http import HttpRequest


def verify_webhook_signature(
    request: HttpRequest,
    secret: str,
    header_name: str = "HTTP_X_HUB_SIGNATURE_256",
    algorithm: str = "sha256",
) -> bool:
    """
    Vérifie la signature HMAC d'un webhook.
    Compatible avec GitHub, Stripe, et la plupart des fournisseurs.
    """
    signature_header = request.META.get(header_name, "")
    if not signature_header:
        return False

    # Format attendu : "sha256=<hex_digest>"
    try:
        prefix, received_sig = signature_header.split("=", 1)
    except ValueError:
        return False

    body = request.body
    expected_sig = hmac.new(
        secret.encode("utf-8"),
        body,
        getattr(hashlib, algorithm, hashlib.sha256),
    ).hexdigest()

    return hmac.compare_digest(expected_sig, received_sig)


def is_valid_webhook_method(request: HttpRequest, allowed_method: str = "POST") -> bool:
    return request.method == allowed_method


# Alias plus explicite
def hmac_verify(secret: str, payload: bytes, signature: str, algorithm: str = "sha256") -> bool:
    expected = hmac.new(secret.encode(), payload, getattr(hashlib, algorithm, hashlib.sha256)).hexdigest()
    return hmac.compare_digest(expected, signature)
