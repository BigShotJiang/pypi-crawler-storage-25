"""
csp_manager — Gestion de la Content Security Policy.
"""

from django.http import HttpResponse


class CSPManager:
    """Construit et applique une politique CSP."""

    def __init__(self):
        self.directives = {
            "default-src": ["'self'"],
            "script-src": ["'self'"],
            "style-src": ["'self'", "'unsafe-inline'"],
            "img-src": ["'self'", "data:"],
            "font-src": ["'self'"],
            "connect-src": ["'self'"],
            "frame-ancestors": ["'none'"],
            "base-uri": ["'self'"],
            "form-action": ["'self'"],
        }
        self.report_only = False

    def allow_script(self, *sources):
        self.directives["script-src"].extend(sources)
        return self

    def allow_style(self, *sources):
        self.directives["style-src"].extend(sources)
        return self

    def allow_img(self, *sources):
        self.directives["img-src"].extend(sources)
        return self

    def set_report_only(self, enabled: bool = True):
        self.report_only = enabled
        return self

    def build_header(self) -> str:
        parts = []
        for directive, values in self.directives.items():
            unique_values = list(dict.fromkeys(values))
            parts.append(f"{directive} {' '.join(unique_values)}")
        return "; ".join(parts)

    def apply(self, response: HttpResponse) -> HttpResponse:
        header = "Content-Security-Policy-Report-Only" if self.report_only else "Content-Security-Policy"
        response[header] = self.build_header()
        return response


def get_default_csp() -> CSPManager:
    return CSPManager()
