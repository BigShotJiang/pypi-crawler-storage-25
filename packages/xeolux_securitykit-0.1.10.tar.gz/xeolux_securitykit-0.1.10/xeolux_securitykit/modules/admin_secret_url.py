"""
admin_secret_url — Remplacement de /admin/ par une URL secrète configurable.
"""


def get_admin_secret_url() -> str | None:
    """Retourne l'URL secrète de l'admin si configurée, None sinon."""
    from ..conf import conf
    return conf.ADMIN_SECRET_URL


def is_secret_admin_url(path: str) -> bool:
    """Vérifie si le chemin est l'URL secrète de l'admin."""
    secret = get_admin_secret_url()
    if not secret:
        return False
    return path.startswith(secret)
