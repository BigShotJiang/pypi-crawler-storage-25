"""
Valeurs par défaut de la configuration XEOLUX_SECURITYKIT.
Ces valeurs sont utilisées si la clé correspondante est absente de settings.py.
"""

DEFAULTS = {
    # Activation globale du package
    "ENABLED": True,

    # Réponse par défaut quand une règle bloque : "fake_404", "403", "empty", "json"
    # "fake_404" = handler natif Django → utilise votre 404.html (indiscernable d'une vraie 404)
    "DEFAULT_RESPONSE": "fake_404",

    # Chemin de l'interface SecurityKit
    "SECURITYKIT_PATH": "/securitykit/",

    # Préfixe de base de la page de déverrouillage strict mode.
    # L'URL complète est : <STRICT_UNLOCK_PATH>/<token_aleatoire>/
    # Elle change à chaque activation du strict mode et est envoyée par email.
    "STRICT_UNLOCK_PATH": "/xk-unlock/",

    # Protection de l'interface /securitykit/ elle-même
    # Accès basé uniquement sur la permission Django : xeolux_securitykit.access_securitykit
    "SELF_PROTECTION_ENABLED": True,

    # Empêcher l'admin de se bloquer lui-même
    "LOCKOUT_SAFETY_ENABLED": True,

    # Strict mode activable
    "STRICT_MODE_ENABLED": True,

    # Protection anti-abus applicatif
    "ANTI_DDOS_ENABLED": True,

    # Envoi d'emails aux super-admins en cas d'incident
    "EMAIL_SUPER_ADMINS": True,

    # Durée de vie des codes d'unlock (en secondes)
    "UNLOCK_CODE_TTL": 3600,

    # Longueur du code d'unlock
    "UNLOCK_CODE_LENGTH": 64,

    # Nombre max de tentatives d'unlock avant slow-down
    "UNLOCK_MAX_ATTEMPTS": 5,

    # Durée d'un bannissement temporaire (secondes)
    "TEMP_BAN_DURATION": 3600,

    # Fenêtre de rate limit globale (secondes)
    "RATE_LIMIT_WINDOW": 60,

    # Nombre max de requêtes par IP dans la fenêtre
    "RATE_LIMIT_MAX_REQUESTS": 120,

    # Activer la protection des headers HTTP
    "SECURITY_HEADERS_ENABLED": True,

    # Activer le honeypot sur les formulaires
    "HONEYPOT_ENABLED": True,

    # Préfixe des clés de cache utilisées par le package
    "CACHE_PREFIX": "xeolux_sk_",

    # Backend de cache Django à utiliser (None = cache par défaut)
    "CACHE_BACKEND": None,

    # Liste des User-Agents toujours autorisés (ex : monitoring interne)
    "TRUSTED_USER_AGENTS": [],

    # Chemins exclus du middleware (ex : fichiers statiques)
    "EXEMPT_PATHS": ["/static/", "/media/", "/favicon.ico"],

    # URL secrète de remplacement pour l'admin (None = désactivé)
    "ADMIN_SECRET_URL": None,

    # Activer la protection de l'admin Django
    "STEALTH_ADMIN_ENABLED": False,

    # Niveau de menace à partir duquel activer le strict mode automatiquement
    "AUTO_STRICT_THRESHOLD": 80,

    # Niveau de menace à partir duquel activer le lockdown automatiquement
    "AUTO_LOCKDOWN_THRESHOLD": 95,
}
