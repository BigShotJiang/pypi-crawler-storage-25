"""
Enregistrement des modèles dans l'admin Django.
"""

from django.contrib import admin
from .models import (
    SecurityKitConfig,
    SecurityModuleState,
    ProtectedRoute,
    RouteRule,
    AccessPolicy,
    IPWhitelistEntry,
    IPBlacklistEntry,
    APIKey,
    StrictModeState,
    UnlockCode,
    TemporaryBan,
    SecurityProfile,
)


@admin.register(SecurityKitConfig)
class SecurityKitConfigAdmin(admin.ModelAdmin):
    list_display = ("key", "value", "updated_at")
    search_fields = ("key",)


@admin.register(SecurityModuleState)
class SecurityModuleStateAdmin(admin.ModelAdmin):
    list_display = ("module_name", "enabled", "updated_at")
    list_filter = ("enabled",)


class RouteRuleInline(admin.TabularInline):
    model = RouteRule
    extra = 0


@admin.register(ProtectedRoute)
class ProtectedRouteAdmin(admin.ModelAdmin):
    list_display = ("path", "match_type", "enabled", "created_at")
    list_filter = ("enabled", "match_type")
    search_fields = ("path",)
    inlines = [RouteRuleInline]


@admin.register(AccessPolicy)
class AccessPolicyAdmin(admin.ModelAdmin):
    list_display = ("name", "deny_action", "enabled")


@admin.register(IPWhitelistEntry)
class IPWhitelistEntryAdmin(admin.ModelAdmin):
    list_display = ("ip_or_cidr", "label", "is_securitykit_access", "enabled")
    list_filter = ("enabled", "is_securitykit_access")


@admin.register(IPBlacklistEntry)
class IPBlacklistEntryAdmin(admin.ModelAdmin):
    list_display = ("ip_or_cidr", "label", "reason", "enabled", "expires_at")
    list_filter = ("enabled",)


@admin.register(APIKey)
class APIKeyAdmin(admin.ModelAdmin):
    list_display = ("name", "key_prefix", "enabled", "created_at", "expires_at")
    list_filter = ("enabled",)
    readonly_fields = ("key_prefix", "key_hash", "created_at")


@admin.register(StrictModeState)
class StrictModeStateAdmin(admin.ModelAdmin):
    list_display = ("mode", "activated_at", "activated_by", "threat_score")


@admin.register(UnlockCode)
class UnlockCodeAdmin(admin.ModelAdmin):
    list_display = ("created_at", "expires_at", "used", "used_at", "attempt_count")
    list_filter = ("used",)
    readonly_fields = ("code_hash", "created_at", "used_at")


@admin.register(TemporaryBan)
class TemporaryBanAdmin(admin.ModelAdmin):
    list_display = ("ip_address", "reason", "created_at", "expires_at", "lifted")
    list_filter = ("reason", "lifted")
    search_fields = ("ip_address",)


@admin.register(SecurityProfile)
class SecurityProfileAdmin(admin.ModelAdmin):
    list_display = ("name", "label", "is_active")
    list_filter = ("is_active",)
