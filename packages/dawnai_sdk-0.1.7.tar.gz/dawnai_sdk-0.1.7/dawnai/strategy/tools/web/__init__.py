"""Web search and content extraction functions."""

from .extract import extract_structured_data_from_url, extract_text_from_urls
from .search import browser_search
from .types import (
    BrowserSearchResponse,
    BrowserSearchResult,
    ExtractStructuredDataResponse,
    ExtractTextContent,
    ExtractTextResponse,
)

__all__ = [
    # Types
    "BrowserSearchResponse",
    "BrowserSearchResult",
    "ExtractStructuredDataResponse",
    "ExtractTextContent",
    "ExtractTextResponse",
    # Functions
    "browser_search",
    "extract_structured_data_from_url",
    "extract_text_from_urls",
]
