"""Portfolio and strategy management types."""

from decimal import Decimal
from typing import Literal

from .._base_types import DecimalModel


class StrategyTransaction(DecimalModel):
    """Strategy transaction record."""

    token_id: str
    market_id: str | None = None
    amount: Decimal
    price: Decimal
    type: Literal["BUY", "SELL", "DEPOSIT", "WITHDRAW"]
    fee: Decimal
    transaction_hash: str | None = None
    created_at: str


class WalletPosition(DecimalModel):
    """Individual wallet position information."""

    token_id: str
    market_id: str | None = None
    amount: Decimal
    cost_basis: Decimal
    current_value: Decimal
    pnl: Decimal
    pnl_percent: Decimal
    redeemable: bool = False


class StrategyData(DecimalModel):
    """Strategy-specific portfolio data."""

    total_pnl: Decimal
    total_pnl_percent: Decimal
    realized_pnl: Decimal
    realized_pnl_percent: Decimal
    unrealized_pnl: Decimal
    unrealized_pnl_percent: Decimal
    current_value: Decimal
    cost_basis: Decimal
    transactions: list[StrategyTransaction]


class WalletData(DecimalModel):
    """Wallet-specific portfolio data."""

    current_balance: Decimal
    total_pnl: Decimal
    total_pnl_percentage: Decimal
    realized_pnl: Decimal
    realized_pnl_percent: Decimal
    unrealized_pnl: Decimal
    unrealized_pnl_percent: Decimal
    current_value: Decimal
    cost_basis: Decimal
    positions: list[WalletPosition]


class PortfolioResponse(DecimalModel):
    """Response from read_portfolio function."""

    strategy: StrategyData
    wallet: WalletData


class LivePnlSummary(DecimalModel):
    """Overall PnL summary from live Polymarket positions."""

    current_positions: Decimal
    closed_positions: Decimal
    all_time: Decimal


class LivePosition(DecimalModel):
    """An open Polymarket position from a live wallet."""

    token_id: str
    title: str
    outcome: str
    size: Decimal
    avg_price: Decimal
    current_price: Decimal
    current_value: Decimal
    initial_value: Decimal
    cash_pnl: Decimal
    percent_pnl: Decimal
    redeemable: bool
    end_date: str


class LiveClosedPosition(DecimalModel):
    """A closed Polymarket position from a live wallet."""

    token_id: str
    title: str
    outcome: str
    avg_price: Decimal
    total_bought: Decimal
    realized_pnl: Decimal
    timestamp: int
    end_date: str


class LiveTrade(DecimalModel):
    """A single trade executed via the live wallet."""

    side: Literal["BUY", "SELL"]
    token_id: str
    title: str
    outcome: str
    size: Decimal
    price: Decimal
    timestamp: int
    transaction_hash: str


class LivePortfolioResponse(DecimalModel):
    """Response from read_live_portfolio."""

    pnl: LivePnlSummary
    positions: list[LivePosition]
    closed_positions: list[LiveClosedPosition]
    trades: list[LiveTrade]


class LiquidatedPosition(DecimalModel):
    """Structure for a liquidated position during strategy termination."""

    market_id: str
    token_type: Literal["YES", "NO"]
    amount: Decimal
    expected_proceeds: Decimal


class TerminateStrategyResult(DecimalModel):
    """Result from terminate_strategy function."""

    success: bool
    liquidated_positions: list[LiquidatedPosition] | None = None
    final_usdc_balance: Decimal | None = None
