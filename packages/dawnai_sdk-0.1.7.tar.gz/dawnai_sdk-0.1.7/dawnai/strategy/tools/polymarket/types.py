"""Polymarket-specific types and data structures."""

from __future__ import annotations

from decimal import Decimal

from pydantic import BaseModel, ConfigDict, Field

from .._base_types import DecimalModel

# Trading and Execution Types
# -----------------------------------------------------------------------------


class MarketPriceData(BaseModel):
    """Market price data for buy/sell sides."""

    BUY: str
    SELL: str


class GetPolymarketPricesResponse(BaseModel):
    """Response from get_polymarket_prices function."""

    prices: dict[str, MarketPriceData]
    error: str | None = None


class OrderResult(DecimalModel):
    """Result of executing a Polymarket buy/sell trade."""

    success: bool
    order_id: str
    transaction_hash: str | None = None
    executed_price: Decimal
    executed_amount: Decimal


class BuyTokenResult(BaseModel):
    """Response from polymarket_buy_token function."""

    result: OrderResult
    error: str | None = None


class SellTokenResult(BaseModel):
    """Response from polymarket_sell_token function."""

    result: OrderResult
    error: str | None = None


class Order(DecimalModel):
    """Single order entry for order book."""

    price: Decimal
    size: Decimal


class SimulateTradeResult(DecimalModel):
    """Response from simulate_trade function."""

    average_price: Decimal
    tokens_traded: Decimal
    usd_amount: Decimal
    market_price_after: Decimal | None = None
    consumed_orders: list[Order] = Field(default_factory=list)
    price_impact_percent: Decimal | None = None
    error: str | None = None


class OrderBookData(BaseModel):
    """Order book data matching Polymarket CLOB API response."""

    market: str
    asset_id: str
    hash: str
    timestamp: str  # ISO timestamp string from API
    bids: list[Order]
    asks: list[Order]
    min_order_size: str
    tick_size: str
    neg_risk: bool


class OrderBookResponse(BaseModel):
    """Response from get_polymarket_order_book function."""

    order_book: OrderBookData | None = None
    error: str | None = None


class TimeseriesPoint(DecimalModel):
    """Time series data point for market price history."""

    t: int
    p: Decimal


# Market and Event Data Types
# -----------------------------------------------------------------------------


class TokenInfo(BaseModel):
    """Token information with id and outcome."""

    id: str
    outcome: str


class PolymarketMarket(BaseModel):
    """Polymarket market details from event markets (matches SimpleMarket from API)."""

    model_config = ConfigDict(extra="allow")

    # Core identifiers
    id: str
    question: str
    slug: str
    description: str | None = None

    # Market state
    active: bool
    closed: bool

    # Dates
    start_date: str | None = None
    end_date: str | None = None

    # Volume and liquidity
    volume: str | None = None
    volume24hr: float | None = None
    liquidity: str | None = None
    price: str | None = None
    spread: float | None = None

    # Token information
    tokens: list[TokenInfo] | None = None


class Tag(BaseModel):
    """Polymarket tag information."""

    id: str
    label: str
    slug: str


class PolymarketEvent(BaseModel):
    """Polymarket event details from event search (matches SimpleEvent from API)."""

    model_config = ConfigDict(extra="allow")

    # Core identifiers
    id: str
    ticker: str | None = None
    slug: str
    title: str
    description: str | None = None

    # Financial data
    volume: float | None = None
    volume24hr: float | None = None
    liquidity: float | None = None

    # Event state
    active: bool
    closed: bool

    # Dates
    start_date: str | None = None
    end_date: str | None = None

    # Tags
    tags: list[Tag] = Field(default_factory=list)

    # Market count (not full market details)
    market_count: int


class EventInfo(BaseModel):
    """Event information for event markets API response."""

    id: str
    title: str
    description: str | None = None
    slug: str


# API Response Types
# -----------------------------------------------------------------------------


class PolymarketEventSearchResponse(BaseModel):
    """Response from polymarket_event_search function."""

    events: list[PolymarketEvent]
    tags: list[Tag]
    count: int
    error: str | None = None


class PolymarketListEventsResponse(BaseModel):
    """Response from polymarket_list_events function."""

    events: list[PolymarketEvent]
    count: int
    error: str | None = None


class PolymarketEventMarketsResponse(BaseModel):
    """Response from polymarket_event_markets function."""

    markets: list[PolymarketMarket]
    count: int
    total_markets: int
    event_info: EventInfo
    error: str | None = None
