"""Agent execution utilities."""

from .._internal import _call_tool


def run_agent(
    prompt: str,
    informational_tools: bool = True,
    execution_tools: bool = False,
    additional_tools: list[str] | None = None,
) -> str:
    """Run a temporary agent with custom prompts and tools.

    Args:
        prompt: The prompt for the new agent session
        informational_tools: Whether to include informational tools
        execution_tools: Whether to include execution tools
        additional_tools: List of additional tool names to include

    Returns:
        The agent's response
    """
    tool_names = additional_tools or []
    if informational_tools:
        tool_names.extend(
            [
                "browser_search",
                "polymarket_event_search",
                "get_polymarket_market_details",
                "get_polymarket_order_book",
                "get_polymarket_prices",
                "get_polymarket_timeseries",
                "get_tweet_info",
                "get_user_tweets",
                "search_tweets",
                "polymarket_event_markets",
            ]
        )
    if execution_tools:
        tool_names.extend(["polymarket_buy_token", "polymarket_sell_token"])
    tool_names = list(dict.fromkeys(tool_names))

    params = {
        "userPrompt": prompt,
        "toolNames": tool_names,
    }

    result = _call_tool("run_agent", params)
    return str(result.get("response", ""))
