"""Text classification utilities."""

from .._internal import _call_tool
from .types import ClassifyTextResponse


def classify_text(text: str, categories: list[str], question: str) -> ClassifyTextResponse:
    """Classify text into one of the provided categories using AI.

    Uses a small language model to classify arbitrary text into predefined categories.
    The question parameter provides context for how the categories relate to the text,
    enabling more accurate classification. Useful for sentiment analysis, outcome
    determination, and pattern matching that would be difficult with naive string matching.

    Args:
        text: The text to classify
        categories: List of possible categories to classify the text into
        question: The question or context that relates the text to the categories
                 (e.g., "What is the sentiment?" or "Did the event occur?")

    Returns:
        ClassifyTextResponse containing:
        - category: The selected category from the provided list

    Example:
        >>> text = "The stock price jumped 15% after strong earnings"
        >>> categories = ["positive", "negative", "neutral"]
        >>> question = "What is the sentiment of this text?"
        >>> result = classify_text(text, categories, question)
        >>> print(result.category)
        "positive"

        >>> text = "The event has been postponed indefinitely"
        >>> categories = ["yes", "no", "uncertain"]
        >>> question = "Did the event happen?"
        >>> result = classify_text(text, categories, question)
        >>> print(result.category)
        "no"
    """
    params = {
        "text": text,
        "categories": categories,
        "question": question,
    }

    result = _call_tool("classify_text", params)

    return ClassifyTextResponse(
        category=result.get("category", ""),
    )
