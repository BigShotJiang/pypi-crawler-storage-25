"""Cryptocurrency OHLCV (price/volume) data functions."""

from typing import Any, Literal

from .._internal import _call_tool
from .types import CryptocurrencyOhlcv, CryptocurrencyOhlcvResponse


def get_cryptocurrency_ohlcv(
    symbol_id: str,
    period_id: Literal[
        "1SEC", "1MIN", "5MIN", "15MIN", "30MIN", "1HRS", "4HRS", "8HRS", "1DAY", "7DAY", "1MTH"
    ],
    limit: int | None = None,
    time_start: str | None = None,
    time_end: str | None = None,
    endpoint: Literal["history", "latest"] | None = None,
) -> CryptocurrencyOhlcvResponse:
    """Get OHLCV (Open, High, Low, Close, Volume) candlestick data for cryptocurrency trading.

    Args:
        symbol_id: Symbol identifier (e.g., 'COINBASE_SPOT_BTC_USD', 'BINANCE_SPOT_BTC_USDT')
        period_id: Time period for candlestick data ('1SEC', '1MIN', '5MIN', '15MIN', '30MIN',
                  '1HRS', '4HRS', '8HRS', '1DAY', '7DAY', '1MTH')
        limit: Number of candlestick records to return (1-10000, default: 100)
        time_start: Start time in ISO 8601 format (e.g., '2023-01-01T00:00:00Z')
        time_end: End time in ISO 8601 format (e.g., '2023-12-31T23:59:59Z')
        endpoint: Data type ('history' for historical data, 'latest' for most recent data)

    Returns:
        CryptocurrencyOhlcvResponse containing:
        - success: Boolean indicating if the request was successful
        - data: List of CryptocurrencyOhlcv objects with candlestick price and volume data,
            ordered from most recent to oldest
        - error: Optional error message if the request failed
        - metadata: Additional metadata including symbol_id, period_id, endpoint, and count

    Example:
        >>> ohlcv = get_cryptocurrency_ohlcv("COINBASE_SPOT_BTC_USD", "1DAY", limit=30)
        >>> if ohlcv.success:
        ...     for candle in ohlcv.data:
        ...         print(f"Open: {candle.price_open}")
        ...         print(f"High: {candle.price_high}")
        ...         print(f"Low: {candle.price_low}")
        ...         print(f"Close: {candle.price_close}")
        ...         print(f"Volume: {candle.volume_traded}")
    """
    params: dict[str, Any] = {
        "symbol_id": symbol_id,
        "period_id": period_id,
    }

    if limit is not None:
        params["limit"] = limit
    if time_start is not None:
        params["time_start"] = time_start
    if time_end is not None:
        params["time_end"] = time_end
    if endpoint is not None:
        params["endpoint"] = endpoint

    result = _call_tool("get_cryptocurrency_ohlcv", params)

    if not isinstance(result, dict):
        return CryptocurrencyOhlcvResponse(
            success=False,
            data=[],
            error="Invalid response format",
            metadata={
                "symbol_id": symbol_id,
                "period_id": period_id,
                "endpoint": endpoint or "history",
                "count": 0,
            },
        )

    # Parse OHLCV data from API response
    data = result.get("data", [])
    ohlcv_data = []
    for ohlcv_item in data:
        if isinstance(ohlcv_item, dict):
            try:
                ohlcv_data.append(CryptocurrencyOhlcv(**ohlcv_item))
            except Exception:  # noqa: S112
                # Skip invalid OHLCV data
                continue

    return CryptocurrencyOhlcvResponse(
        success=result.get("success", False),
        data=ohlcv_data,
        error=result.get("error"),
        metadata=result.get(
            "metadata",
            {
                "symbol_id": symbol_id,
                "period_id": period_id,
                "endpoint": endpoint or "history",
                "count": len(ohlcv_data),
            },
        ),
    )
