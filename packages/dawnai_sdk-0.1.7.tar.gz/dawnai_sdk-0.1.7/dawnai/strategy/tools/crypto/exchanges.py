"""Cryptocurrency exchange and symbol data functions."""

from typing import Any

from .._internal import _call_tool
from .types import (
    CryptocurrencyExchange,
    CryptocurrencySymbol,
    ExchangesResponse,
    ExchangeSymbolsResponse,
)


def get_exchanges() -> ExchangesResponse:
    """Get a list of all available cryptocurrency exchanges.

    Returns:
        ExchangesResponse containing:
        - success: Boolean indicating if the request was successful
        - data: List of CryptocurrencyExchange objects with exchange_id, name, and optional website
        - error: Optional error message if the request failed
        - metadata: Additional metadata including count of exchanges

    Example:
        >>> exchanges = get_exchanges()
        >>> if exchanges.success:
        ...     for exchange in exchanges.data:
        ...         print(f"{exchange.name}: {exchange.exchange_id}")
    """
    result = _call_tool("get_cryptocurrency_exchanges", {})

    if not isinstance(result, dict):
        return ExchangesResponse(
            success=False,
            data=[],
            error="Invalid response format",
            metadata={"count": 0},
        )

    # Convert camelCase data to snake_case for Python SDK
    data = result.get("data", [])
    exchanges = []
    for exchange_data in data:
        if isinstance(exchange_data, dict):
            # Convert camelCase fields to snake_case
            exchange_dict: dict[str, Any] = {
                "exchange_id": exchange_data.get("exchangeId"),
                "name": exchange_data.get("name"),
                "website": exchange_data.get("website"),
            }
            try:
                exchanges.append(CryptocurrencyExchange(**exchange_dict))
            except Exception:  # noqa: S112
                # Skip invalid exchanges
                continue

    return ExchangesResponse(
        success=result.get("success", False),
        data=exchanges,
        error=result.get("error"),
        metadata=result.get("metadata", {"count": len(exchanges)}),
    )


def get_exchange_symbols(exchange_id: str) -> ExchangeSymbolsResponse:
    """Get active trading symbols for a specific cryptocurrency exchange.

    Args:
        exchange_id: Exchange identifier (e.g., 'BINANCE', 'COINBASE')

    Returns:
        ExchangeSymbolsResponse containing:
        - success: Boolean indicating if the request was successful
        - data: List of CryptocurrencySymbol objects with symbol_id, asset_id_base, asset_id_quote
        - error: Optional error message if the request failed
        - metadata: Additional metadata including exchange_id and count of symbols

    Example:
        >>> symbols = get_exchange_symbols("COINBASE")
        >>> if symbols.success:
        ...     for symbol in symbols.data:
        ...         print(f"{symbol.asset_id_base}/{symbol.asset_id_quote}: {symbol.symbol_id}")
    """
    params = {"exchange_id": exchange_id}
    result = _call_tool("get_cryptocurrency_exchange_symbols", params)

    if not isinstance(result, dict):
        return ExchangeSymbolsResponse(
            success=False,
            data=[],
            error="Invalid response format",
            metadata={"exchange_id": exchange_id, "count": 0},
        )

    # Convert camelCase data to snake_case for Python SDK
    data = result.get("data", [])
    symbols = []
    for symbol_data in data:
        if isinstance(symbol_data, dict):
            # Convert camelCase fields to snake_case
            symbol_dict: dict[str, Any] = {
                "symbol_id": symbol_data.get("symbolId"),
                "asset_id_base": symbol_data.get("assetIdBase"),
                "asset_id_quote": symbol_data.get("assetIdQuote"),
            }
            try:
                symbols.append(CryptocurrencySymbol(**symbol_dict))
            except Exception:  # noqa: S112
                # Skip invalid symbols
                continue

    return ExchangeSymbolsResponse(
        success=result.get("success", False),
        data=symbols,
        error=result.get("error"),
        metadata=result.get("metadata", {"exchange_id": exchange_id, "count": len(symbols)}),
    )
