"""Cryptocurrency data types."""

from typing import Any

from pydantic import BaseModel


class CryptocurrencySymbol(BaseModel):
    """Active trading symbol data for cryptocurrency exchanges."""

    symbol_id: str
    asset_id_base: str
    asset_id_quote: str


class ExchangeSymbolsResponse(BaseModel):
    """Response from get_exchange_symbols function."""

    success: bool
    data: list[CryptocurrencySymbol]
    error: str | None
    metadata: dict[str, Any]


class CryptocurrencyExchange(BaseModel):
    """Cryptocurrency exchange information."""

    exchange_id: str
    name: str
    website: str | None = None


class ExchangesResponse(BaseModel):
    """Response from get_exchanges function."""

    success: bool
    data: list[CryptocurrencyExchange]
    error: str | None
    metadata: dict[str, Any]


class CryptocurrencyOhlcv(BaseModel):
    """OHLCV (Open, High, Low, Close, Volume) candlestick data for cryptocurrency trading."""

    time_period_start: str
    time_period_end: str
    time_open: str | None = None
    time_close: str | None = None
    price_open: float
    price_high: float
    price_low: float
    price_close: float
    volume_traded: float
    trades_count: int | None = None


class CryptocurrencyOhlcvResponse(BaseModel):
    """Response from get_cryptocurrency_ohlcv function."""

    success: bool
    data: list[CryptocurrencyOhlcv]
    error: str | None
    metadata: dict[str, Any]
