"""Sports data and betting odds from The Odds API.

This module provides access to sports data including available sports,
upcoming events, live odds from multiple bookmakers, and real-time scores.
"""

from .data import get_events, get_odds_as_probabilities, get_scores, get_sports
from .types import (
    Bookmaker,
    Event,
    EventMetadata,
    GetEventsResponse,
    GetOddsAsProbabilitiesResponse,
    GetScoresResponse,
    GetSportsResponse,
    Market,
    OddsEvent,
    OddsMetadata,
    Outcome,
    Score,
    ScoreEvent,
    ScoresMetadata,
    Sport,
    SportMetadata,
)

__all__ = [
    # Types - Core Data Models
    "Bookmaker",
    # Types - Core Data Models
    "Event",
    "EventMetadata",
    # Types - Responses
    "GetEventsResponse",
    "GetOddsAsProbabilitiesResponse",
    "GetScoresResponse",
    "GetSportsResponse",
    # Types - Core Data Models
    "Market",
    "OddsEvent",
    "OddsMetadata",
    "Outcome",
    "Score",
    "ScoreEvent",
    "ScoresMetadata",
    "Sport",
    "SportMetadata",
    # Functions
    "get_events",
    "get_odds_as_probabilities",
    "get_scores",
    "get_sports",
]
