"""Sports data and betting odds functions.

This module provides functions to access sports data including available sports,
upcoming events, betting odds, and live/historical scores.
"""

from __future__ import annotations

from typing import Literal

from .._internal import _call_tool
from .types import (
    Event,
    EventMetadata,
    GetEventsResponse,
    GetOddsAsProbabilitiesResponse,
    GetScoresResponse,
    GetSportsResponse,
    OddsEvent,
    OddsMetadata,
    ScoreEvent,
    ScoresMetadata,
    Sport,
    SportMetadata,
)


def get_sports(all: bool = False) -> GetSportsResponse:
    """Get a list of available sports.

    By default, returns only sports that are currently in season. Use the 'all'
    parameter to get both in-season and out-of-season sports.

    Args:
        all: If True, returns both in-season and out-of-season sports.
            If False (default), returns only in-season sports.

    Returns:
        GetSportsResponse containing:
            - success: Whether the request was successful
            - data: List of Sport objects with information about each sport
            - error: Error message if the request failed
            - metadata: Contains total count and active count of sports

    Example:
        >>> # Get only in-season sports
        >>> response = get_sports()
        >>> if response.success:
        ...     for sport in response.data:
        ...         if sport.active:
        ...             print(f"{sport.title} ({sport.key})")
        ...
        >>> # Get all sports including out-of-season
        >>> all_sports = get_sports(all=True)
        >>> print(f"Total sports: {all_sports.metadata.count}")
        >>> print(f"Active sports: {all_sports.metadata.active_count}")
    """
    params = {}
    if all:
        params["all"] = True

    result = _call_tool("get_sports", params)

    # Parse sports data
    sports_data = result.get("data", [])
    validated_sports: list[Sport] = []
    for sport_data in sports_data:
        if isinstance(sport_data, dict):
            sport = Sport(**sport_data)
            validated_sports.append(sport)

    # Parse metadata
    metadata_data = result.get("metadata", {"count": 0, "activeCount": 0})
    metadata = SportMetadata(**metadata_data)

    return GetSportsResponse(
        success=result.get("success", False),
        data=validated_sports,
        error=result.get("error"),
        metadata=metadata,
    )


def get_events(
    sport: str,
    date_format: Literal["iso", "unix"] | None = None,
    event_ids: str | None = None,
    commence_time_from: str | None = None,
    commence_time_to: str | None = None,
) -> GetEventsResponse:
    """Get upcoming and in-play events for a sport.

    Retrieves a list of upcoming and live sporting events without odds information.
    Use this when you only need event schedules and don't need betting odds.

    Args:
        sport: Sport key from get_sports() (e.g., 'americanfootball_nfl', 'basketball_nba')
        date_format: Format for timestamps - 'iso' for ISO 8601 strings (default)
            or 'unix' for Unix timestamps
        event_ids: Comma-separated list of event IDs to filter results.
            Only events with matching IDs will be returned.
        commence_time_from: Filter to show games that commence on/after this time.
            Must be in ISO 8601 format (e.g., '2023-09-09T00:00:00Z')
        commence_time_to: Filter to show games that commence on/before this time.
            Must be in ISO 8601 format (e.g., '2023-09-10T23:59:59Z')

    Returns:
        GetEventsResponse containing:
            - success: Whether the request was successful
            - data: List of Event objects with information about each event
            - error: Error message if the request failed
            - metadata: Contains the sport key and event count

    Example:
        >>> # Get upcoming NFL games
        >>> response = get_events('americanfootball_nfl')
        >>> if response.success:
        ...     for event in response.data:
        ...         print(f"{event.away_team} @ {event.home_team}")
        ...         print(f"Starts: {event.commence_time}")
        ...
        >>> # Get events for a specific time range
        >>> response = get_events(
        ...     'basketball_nba',
        ...     commence_time_from='2023-10-01T00:00:00Z',
        ...     commence_time_to='2023-10-07T23:59:59Z'
        ... )
        >>> print(f"Found {response.metadata.count} games this week")
    """
    params = {"sport": sport}

    if date_format is not None:
        params["date_format"] = date_format
    if event_ids is not None:
        params["event_ids"] = event_ids
    if commence_time_from is not None:
        params["commence_time_from"] = commence_time_from
    if commence_time_to is not None:
        params["commence_time_to"] = commence_time_to

    result = _call_tool("get_sports_events", params)

    # Parse events data
    events_data = result.get("data", [])
    validated_events: list[Event] = []
    for event_data in events_data:
        if isinstance(event_data, dict):
            event = Event(**event_data)
            validated_events.append(event)

    # Parse metadata
    metadata_data = result.get("metadata", {"sport": sport, "count": 0})
    metadata = EventMetadata(**metadata_data)

    return GetEventsResponse(
        success=result.get("success", False),
        data=validated_events,
        error=result.get("error"),
        metadata=metadata,
    )


def get_odds_as_probabilities(
    sport: str,
    regions: str,
    markets: str | None = None,
    date_format: Literal["iso", "unix"] | None = None,
    event_ids: str | None = None,
    bookmakers: str | None = None,
) -> GetOddsAsProbabilitiesResponse:
    """Get betting odds for upcoming and live games as implied probabilities.

    Odds are automatically converted from American format to implied probabilities (0-1).
    For example:
    - American odds +150 → 0.40 (40% implied probability)
    - American odds -110 → 0.524 (52.4% implied probability)

    Args:
        sport: Sport key from get_sports() (e.g., 'americanfootball_nfl', 'basketball_nba').
            Use 'upcoming' to get odds for upcoming games across all sports.
        regions: Comma-separated list of regions (e.g., 'us', 'uk', 'eu', 'au').
            Determines which bookmakers are returned. Required.
        markets: Comma-separated list of markets to include:
            - 'h2h': Head to head / Moneyline (default if not specified)
            - 'spreads': Point spreads
            - 'totals': Over/Under totals
            - 'outrights': Championship and tournament winner markets
        date_format: Format for timestamps - 'iso' for ISO 8601 (default) or 'unix'
        event_ids: Comma-separated list of event IDs to filter results
        bookmakers: Comma-separated list of specific bookmaker keys to include.
            Takes priority over regions parameter.

    Returns:
        GetOddsAsProbabilitiesResponse containing:
            - success: Whether the request was successful
            - data: List of OddsEvent objects with implied probabilities from bookmakers
            - error: Error message if the request failed
            - metadata: Contains sport, regions, markets, and count

    Example:
        >>> # Get moneyline probabilities for NFL from US bookmakers
        >>> response = get_odds_as_probabilities('americanfootball_nfl', regions='us')
        >>> if response.success:
        ...     for event in response.data:
        ...         print(f"{event.away_team} @ {event.home_team}")
        ...         for bookmaker in event.bookmakers:
        ...             print(f"  {bookmaker.title}:")
        ...             for market in bookmaker.markets:
        ...                 for outcome in market.outcomes:
        ...                     # probability is the implied probability (0-1)
        ...                     prob_pct = outcome.probability * 100
        ...                     print(
        ...                         f"    {outcome.name}: "
        ...                         f"{outcome.probability:.3f} ({prob_pct:.1f}%)"
        ...                     )
        ...
        >>> # Get spreads and totals probabilities
        >>> response = get_odds_as_probabilities(
        ...     'basketball_nba',
        ...     regions='us',
        ...     markets='spreads,totals'
        ... )
    """
    params = {
        "sport": sport,
        "regions": regions,
    }

    if markets is not None:
        params["markets"] = markets
    if date_format is not None:
        params["date_format"] = date_format
    if event_ids is not None:
        params["event_ids"] = event_ids
    if bookmakers is not None:
        params["bookmakers"] = bookmakers

    result = _call_tool("get_sports_odds", params)

    # Parse odds events data
    events_data = result.get("data", [])
    validated_events: list[OddsEvent] = []
    for event_data in events_data:
        if isinstance(event_data, dict):
            event = OddsEvent(**event_data)
            validated_events.append(event)

    # Parse metadata
    metadata_data = result.get(
        "metadata",
        {"sport": sport, "regions": regions, "count": 0},
    )
    metadata = OddsMetadata(**metadata_data)

    return GetOddsAsProbabilitiesResponse(
        success=result.get("success", False),
        data=validated_events,
        error=result.get("error"),
        metadata=metadata,
    )


def get_scores(
    sport: str,
    days_from: int | None = None,
    date_format: Literal["iso", "unix"] | None = None,
    event_ids: str | None = None,
) -> GetScoresResponse:
    """Get scores for live, upcoming, and recently completed games.

    Args:
        sport: Sport key from get_sports() (e.g., 'basketball_nba', 'americanfootball_nfl')
        days_from: Number of days in the past to return completed games (1-3).
            If not specified, only live and upcoming games are returned.
        date_format: Format for timestamps - 'iso' for ISO 8601 (default) or 'unix'
        event_ids: Comma-separated list of event IDs to filter results

    Returns:
        GetScoresResponse containing:
            - success: Whether the request was successful
            - data: List of ScoreEvent objects with score information
            - error: Error message if the request failed
            - metadata: Contains sport, days_from, and counts by status

    Example:
        >>> # Get live and upcoming NBA games
        >>> response = get_scores('basketball_nba')
        >>> if response.success:
        ...     print(f"Live games: {response.metadata.live_count}")
        ...     print(f"Upcoming: {response.metadata.upcoming_count}")
        ...     for event in response.data:
        ...         if event.scores:  # Game is live or completed
        ...             for score in event.scores:
        ...                 print(f"{score.name}: {score.score}")
        ...
        >>> # Get games from the last 2 days including completed games
        >>> response = get_scores('americanfootball_nfl', days_from=2)
        >>> print(f"Completed: {response.metadata.completed_count}")
    """
    params: dict[str, str | int] = {"sport": sport}

    if days_from is not None:
        params["days_from"] = days_from
    if date_format is not None:
        params["date_format"] = date_format
    if event_ids is not None:
        params["event_ids"] = event_ids

    result = _call_tool("get_sports_scores", params)

    # Parse score events data
    events_data = result.get("data", [])
    validated_events: list[ScoreEvent] = []
    for event_data in events_data:
        if isinstance(event_data, dict):
            event = ScoreEvent(**event_data)
            validated_events.append(event)

    # Parse metadata
    metadata_data = result.get(
        "metadata",
        {
            "sport": sport,
            "count": 0,
            "completedCount": 0,
            "liveCount": 0,
            "upcomingCount": 0,
        },
    )
    metadata = ScoresMetadata(**metadata_data)

    return GetScoresResponse(
        success=result.get("success", False),
        data=validated_events,
        error=result.get("error"),
        metadata=metadata,
    )
