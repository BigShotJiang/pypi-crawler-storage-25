"""Twitter/X social media data functions."""

from __future__ import annotations

from .._internal import _call_tool
from .types import (
    SearchTweetsResponse,
    Tweet,
    TweetInfoResponse,
    UserTweetsResponse,
)


def search_tweets(
    query: str, query_type: str = "Latest", cursor: str | None = None
) -> SearchTweetsResponse:
    """Search for tweets based on a query string.

    Args:
        query: Search query for finding tweets
        query_type: Type of query to search for
        cursor: Optional pagination cursor for next page

    Returns:
        SearchTweetsResponse containing tweets, count, optional pagination cursor and error
    """
    params = {"query": query, "query_type": query_type}
    if cursor:
        params["cursor"] = cursor

    result = _call_tool("search_tweets", params)

    tweets = [Tweet(**tweet) for tweet in result.get("tweets", [])]

    return SearchTweetsResponse(
        success=result.get("success", False),
        tweets=tweets,
        count=result.get("count", 0),
        next_cursor=result.get("next_cursor"),
        error=result.get("error"),
    )


def get_user_tweets(handle: str, cursor: str | None = None) -> UserTweetsResponse:
    """Get recent tweets from a specific Twitter user.

    Args:
        handle: Twitter handle (without @ symbol)
        cursor: Optional pagination cursor for next page

    Returns:
        UserTweetsResponse containing tweets,  optional pagination cursor and error
    """
    params = {"handle": handle.replace("@", "")}
    if cursor:
        params["cursor"] = cursor

    result = _call_tool("user_tweets", params)

    tweets = [Tweet(**tweet) for tweet in result.get("tweets", [])]

    return UserTweetsResponse(
        success=result.get("success", False),
        tweets=tweets,
        has_next_page=result.get("has_next_page", False),
        next_cursor=result.get("next_cursor"),
        error=result.get("error"),
    )


def get_tweet_info(tweet_ids: list[str]) -> TweetInfoResponse:
    """Get detailed information about specific tweets.

    Args:
        tweet_ids: List of tweet IDs to get information about

    Returns:
        TweetInfoResponse containing detailed tweet info and optional error
    """
    result = _call_tool("tweet_info", {"tweet_ids": tweet_ids})

    tweets = [Tweet(**tweet) for tweet in result.get("tweets", [])]

    return TweetInfoResponse(
        success=result.get("success", False),
        tweets=tweets,
        error=result.get("error"),
    )
