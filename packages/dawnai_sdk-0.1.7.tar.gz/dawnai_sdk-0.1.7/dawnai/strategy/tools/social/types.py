"""Social media and Twitter/X specific types in Python snake_case convention."""

from typing import Optional

from pydantic import BaseModel


class TwitterUser(BaseModel):
    """Twitter user information."""

    user_name: str
    url: str
    name: str
    description: str
    followers: int
    following: int
    is_verified: bool
    is_automated: bool
    tweets_count: int


class Tweet(BaseModel):
    """Twitter tweet information."""

    id: str
    text: str
    created_at: str | None
    author: TwitterUser
    like_count: int
    quote_count: int
    view_count: int
    reply_count: int
    retweet_count: int
    quoted_tweet: Optional["Tweet"] = None
    retweeted_tweet: Optional["Tweet"] = None


class SearchTweetsResponse(BaseModel):
    """Response from search_tweets function."""

    success: bool
    tweets: list[Tweet]
    count: int
    next_cursor: str | None
    error: str | None


class UserTweetsResponse(BaseModel):
    """Response from get_user_tweets function."""

    success: bool
    tweets: list[Tweet]
    has_next_page: bool
    next_cursor: str | None
    error: str | None


class TweetInfoResponse(BaseModel):
    """Response from get_tweet_info function."""

    success: bool
    tweets: list[Tweet]
    error: str | None
