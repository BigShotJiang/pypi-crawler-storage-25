"""Social media integration functions."""

from .twitter import get_tweet_info, get_user_tweets, search_tweets
from .types import (
    SearchTweetsResponse,
    Tweet,
    TweetInfoResponse,
    TwitterUser,
    UserTweetsResponse,
)

__all__ = [
    # Types
    "SearchTweetsResponse",
    "Tweet",
    "TweetInfoResponse",
    "TwitterUser",
    "UserTweetsResponse",
    "get_tweet_info",
    "get_user_tweets",
    "search_tweets",
]
