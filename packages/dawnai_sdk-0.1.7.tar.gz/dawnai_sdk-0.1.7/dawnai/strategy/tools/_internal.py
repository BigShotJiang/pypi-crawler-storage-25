"""Internal utilities shared across function modules."""

from typing import Any

import httpx

from ...config import get_config


def _call_tool(tool_name: str, params: dict[str, Any]) -> Any:
    """Internal function to call a tool via the API (sandbox JWT path)."""
    config = get_config()

    # API key is required for authentication
    if not config.api_key:
        raise ValueError(
            "DAWNAI_API_KEY is required. "
            "Set it via environment variable or call configure(api_key='your-token')"
        )

    url = f"{config.base_url}/code-runner/execute"
    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {config.api_key}",
    }

    # Add ngrok skip browser warning header if using ngrok
    if "ngrok" in config.base_url or "ngrok-free.app" in config.base_url:
        headers["ngrok-skip-browser-warning"] = "true"

    # Context is mostly extracted from JWT on the server side
    # We send currentDate for backtesting and strategyId for MCP testing (when JWT doesn't have one)
    context = {}
    if config.current_date:
        context["currentDate"] = config.current_date
    if config.strategy_id:
        context["strategyId"] = config.strategy_id

    payload = {"toolName": tool_name, "args": params, "context": context or None}

    with httpx.Client() as client:
        response = client.post(url, json=payload, headers=headers, timeout=120.0)

        # Check if response is HTML (error)
        if response.headers.get("content-type", "").startswith("text/html"):
            error_msg = response.text
            # Try to extract meaningful error from HTML
            if "Error executing tool" in error_msg:
                raise ValueError(f"Tool execution error: {error_msg}")
            raise ValueError(f"Unexpected HTML response: {error_msg[:200]}")

        response.raise_for_status()

        # Parse JSON response
        try:
            return response.json()
        except Exception:
            # If JSON parsing fails, return empty dict for tools that don't return data
            return {}


def _confirm_local_trade(
    tx_id: str,
    tx_hash: str,
    token_id: str,
    side: str,
    executed_price: str,
    executed_amount: str,
    usd_amount: str,
    local_eoa_address: str,
    strategy_id: str | None,
) -> None:
    """Notify the API that a live-local trade was successfully broadcast on-chain.

    Called after a successful ows sign + eth_sendRawTransaction so the API can
    write the confirmed trade to the DB with the real tx hash.
    Errors are logged but not re-raised — the trade already succeeded on-chain.
    """
    config = get_config()
    if not config.api_key:
        return  # no-op if not authenticated (shouldn't happen in live mode)

    url = f"{config.base_url}/code-runner/confirm-local-trade"
    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {config.api_key}",
    }
    if "ngrok" in config.base_url or "ngrok-free.app" in config.base_url:
        headers["ngrok-skip-browser-warning"] = "true"

    payload: dict[str, Any] = {
        "tx_id": tx_id,
        "tx_hash": tx_hash,
        "token_id": token_id,
        "side": side,
        "executed_price": executed_price,
        "executed_amount": executed_amount,
        "usd_amount": usd_amount,
        "local_eoa_address": local_eoa_address,
    }
    if strategy_id:
        payload["strategy_id"] = strategy_id

    try:
        with httpx.Client() as client:
            response = client.post(url, json=payload, headers=headers, timeout=30.0)
            response.raise_for_status()
    except Exception as exc:
        # Log but do not raise — the on-chain trade already succeeded
        print(f"Warning: could not confirm trade in DB (tx_id={tx_id}): {exc}")  # noqa: T201


def _call_tool_local(
    tool_name: str,
    params: dict[str, Any],
    strategy_id: str | None = None,
    *,
    is_local: bool = True,
    local_eoa_address: str | None = None,
) -> Any:
    """Call a tool via the execute-local endpoint using the user's Dawn JWT.

    Used by local dawn-cli — no sandbox token required.
    Context fields (strategyId, isLocal, localEoaAddress) are sent in the request body.
    """
    config = get_config()

    if not config.api_key:
        raise ValueError(
            "DAWNAI_API_KEY is required. "
            "Set it via environment variable or call configure(api_key='your-token')"
        )

    url = f"{config.base_url}/code-runner/execute-local"
    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {config.api_key}",
    }

    if "ngrok" in config.base_url or "ngrok-free.app" in config.base_url:
        headers["ngrok-skip-browser-warning"] = "true"

    payload: dict[str, Any] = {
        "toolName": tool_name,
        "args": params,
        "isLocal": is_local,
    }
    if strategy_id:
        payload["strategyId"] = strategy_id
    if local_eoa_address:
        payload["localEoaAddress"] = local_eoa_address
    if config.current_date:
        payload["currentDate"] = config.current_date

    with httpx.Client() as client:
        response = client.post(url, json=payload, headers=headers, timeout=120.0)

        if response.headers.get("content-type", "").startswith("text/html"):
            error_msg = response.text
            if "Error executing tool" in error_msg:
                raise ValueError(f"Tool execution error: {error_msg}")
            raise ValueError(f"Unexpected HTML response: {error_msg[:200]}")

        response.raise_for_status()

        try:
            return response.json()
        except Exception:
            return {}
