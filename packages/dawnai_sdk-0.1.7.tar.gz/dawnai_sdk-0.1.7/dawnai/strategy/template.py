from dawnai.strategy import Strategy


class MyStrategy(Strategy):
    def __init__(self) -> None:
        super().__init__()

    # TODO: Implement strategy rules here
