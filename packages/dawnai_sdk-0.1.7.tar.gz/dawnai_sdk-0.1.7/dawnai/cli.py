"""CLI entrypoint for the DawnAI SDK executable."""

from __future__ import annotations

import argparse
import json
import sys
import traceback

from dawnai import __version__
from dawnai.config import get_config


def _cmd_doctor() -> int:
    """Run a quick local SDK health check."""
    config = get_config()
    has_api_key = bool(config.api_key)
    sys.stdout.write("DawnAI SDK doctor\n")
    sys.stdout.write("-----------------\n")
    sys.stdout.write(f"version: {__version__}\n")
    sys.stdout.write(f"base_url: {config.base_url}\n")
    sys.stdout.write(f"api_key_set: {'yes' if has_api_key else 'no'}\n")
    if not has_api_key:
        sys.stdout.write(
            "note: set DAWNAI_API_KEY to call authenticated Dawn APIs.\n",
        )
    return 0


def _serialize(obj: object) -> object:
    """Recursively serialize Pydantic models and lists to plain dicts/values."""
    if hasattr(obj, "model_dump"):
        return obj.model_dump()
    if isinstance(obj, list):
        return [_serialize(item) for item in obj]
    return obj


def _cmd_tool(tool_name: str, input_json: str) -> int:
    """Call an SDK tool by name and print the JSON result."""
    import dawnai.strategy.tools as tools_module  # noqa: PLC0415

    try:
        inputs = json.loads(input_json)
    except json.JSONDecodeError as exc:
        result = {"success": False, "error": f"Invalid JSON input: {exc}"}
        sys.stdout.write(json.dumps(result, indent=2) + "\n")
        return 1

    if not hasattr(tools_module, tool_name):
        available = sorted(
            t
            for t in dir(tools_module)
            if not t.startswith("_") and callable(getattr(tools_module, t))
        )
        result = {
            "success": False,
            "error": f"Tool '{tool_name}' not found.",
            "available_tools": available,
        }
        sys.stdout.write(json.dumps(result, indent=2) + "\n")
        return 1

    try:
        tool_fn = getattr(tools_module, tool_name)
        raw = tool_fn(**inputs)
        out = _serialize(raw)
        sys.stdout.write(json.dumps({"success": True, "result": out}, default=str, indent=2) + "\n")
    except Exception as exc:
        result = {
            "success": False,
            "error": str(exc),
            "traceback": traceback.format_exc(),
        }
        sys.stdout.write(json.dumps(result, indent=2) + "\n")
        return 1
    else:
        return 0


def _cmd_docs(module_name: str | None) -> int:
    """Print bundled SDK documentation markdown."""
    from importlib import resources  # noqa: PLC0415

    docs_pkg = resources.files("dawnai") / "docs"

    if module_name is None:
        # List available docs
        sys.stdout.write("Available docs:\n")
        sys.stdout.write("  overview    — SDK module overview\n")
        sys.stdout.write("  directive   — Strategy coding guidelines\n")
        try:
            for entry in sorted((docs_pkg / "modules").iterdir(), key=lambda e: e.name):
                name = entry.name
                if name.endswith(".md"):
                    sys.stdout.write(f"  {name[:-3]:<12} — {name[:-3]} module reference\n")
        except Exception:  # noqa: S110
            pass
        sys.stdout.write("\nUsage: dawnsdk docs <name>\n")
        return 0

    # Resolve to a file path
    if module_name in ("overview", "directive"):
        doc_file = docs_pkg / f"{module_name}.md"
    else:
        doc_file = docs_pkg / "modules" / f"{module_name}.md"

    try:
        content = doc_file.read_text(encoding="utf-8")
        sys.stdout.write(content)
    except FileNotFoundError:
        sys.stderr.write(
            f"No docs found for '{module_name}'. Run `dawnsdk docs` to list available docs.\n"
        )
        return 1
    else:
        return 0


def build_parser() -> argparse.ArgumentParser:
    """Build CLI argument parser."""
    parser = argparse.ArgumentParser(
        prog="dawnsdk",
        description="DawnAI SDK command line interface.",
    )
    parser.add_argument(
        "--version",
        action="store_true",
        help="Show SDK executable version.",
    )
    subparsers = parser.add_subparsers(dest="command")
    subparsers.add_parser("doctor", help="Run local SDK health checks.")

    tool_parser = subparsers.add_parser(
        "tool",
        help="Call an SDK tool by name and print the JSON result.",
    )
    tool_parser.add_argument("tool_name", help="Name of the SDK tool to call.")
    tool_parser.add_argument(
        "--input",
        default="{}",
        help="JSON-encoded keyword arguments for the tool (default: {}).",
    )

    docs_parser = subparsers.add_parser(
        "docs",
        help="Print bundled SDK documentation (overview, directive, or a module name).",
    )
    docs_parser.add_argument(
        "module",
        nargs="?",
        default=None,
        help=(
            "Doc to show: overview, directive, polymarket, web, "
            "social, sports, crypto, utils, portfolio."
        ),
    )
    return parser


def main() -> int:
    """CLI main function used by console script entrypoint."""
    parser = build_parser()
    args = parser.parse_args()

    if args.version:
        sys.stdout.write(f"dawnsdk {__version__}\n")
        return 0

    if args.command == "doctor":
        return _cmd_doctor()

    if args.command == "tool":
        return _cmd_tool(args.tool_name, args.input)

    if args.command == "docs":
        return _cmd_docs(args.module)

    parser.print_help()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
