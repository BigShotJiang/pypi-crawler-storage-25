"""Strategy config management — load and save the per-run .config.json file.

At launch the dawn CLI copies the strategy's sidecar .config.json to a
per-run path and sets DAWNAI_CONFIG_PATH pointing to it. This means every
run has isolated state and concurrent runs of the same strategy don't
interfere with each other.

If DAWNAI_CONFIG_PATH is not set (e.g. running the script directly outside
the dawn CLI), load_config falls back to the .config.json sibling of the
calling script.
"""

import json
import os
import sys
import tempfile
from pathlib import Path
from typing import Any


def _resolve_config_path() -> Path:
    """Return the path to the active config file for this run."""
    env_path = os.environ.get("DAWNAI_CONFIG_PATH")
    if env_path:
        return Path(env_path)

    # Fall back to sibling .config.json next to the script being run
    script = Path(sys.argv[0]).resolve()
    return script.with_suffix(".config.json")


def load_config() -> dict[str, Any]:
    """Load strategy config from the per-run config file.

    Validates that budget_usd is present — strategies cannot run without a
    spending cap.
    """
    config_path = _resolve_config_path()
    with config_path.open() as f:
        config: dict[str, Any] = json.load(f)
    if "budget_usd" not in config:
        raise ValueError(
            f"budget_usd is required in {config_path} — strategy cannot run without a spending cap"
        )
    if "total_invested" not in config:
        raise ValueError(
            f"total_invested is required in {config_path} — initialize to 0 for a new strategy"
        )
    return config


def save_config(updates: dict[str, Any]) -> None:
    """Persist updates back to the per-run config file.

    Uses an atomic write (temp file + rename) so a crash during the write
    never corrupts the config.
    """
    config_path = _resolve_config_path()

    # Read current state
    try:
        with config_path.open() as f:
            config: dict[str, Any] = json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        config = {}

    config.update(updates)

    # Atomic write: write to a temp file in the same directory, then rename
    dir_path = config_path.parent
    with tempfile.NamedTemporaryFile(
        mode="w",
        dir=dir_path,
        suffix=".tmp",
        delete=False,
    ) as tmp:
        json.dump(config, tmp, indent=2)
        tmp_path = tmp.name

    Path(tmp_path).replace(config_path)
