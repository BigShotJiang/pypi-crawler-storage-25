"""DawnAI Strategy SDK for efficient strategy development."""

__version__ = "0.1.6"

from dawnai.strategy_config import load_config, save_config

__all__ = ["load_config", "save_config"]
