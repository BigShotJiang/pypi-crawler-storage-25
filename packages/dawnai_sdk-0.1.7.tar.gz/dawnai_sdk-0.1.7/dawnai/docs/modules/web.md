# Web Module

**Path**: `dawnai.strategy.tools.web`

## Module Description

Web search and content extraction functions.

## Available Functions

### `browser_search(query: str, limit: int = 10, category: str | None = None, start_published_date: str | None = None, end_published_date: str | None = None, include_domains: list[str] | None = None, exclude_domains: list[str] | None = None) -> BrowserSearchResponse`

Search the web for information.

Args:
    query: Search query
    limit: Number of results to return (max 100)
    category: Optional category filter ('company', 'research paper', 'news',
    'linkedin profile', 'github', 'tweet', 'personal site', 'pdf')
    start_published_date: Start date for filtering results (YYYY-MM-DD)
    end_published_date: End date for filtering results (YYYY-MM-DD)
    include_domains: List of domains to include
    exclude_domains: List of domains to exclude

Returns:
    BrowserSearchResponse containing:
    - success: Boolean indicating if the search was successful
    - results: List of search results, each containing:
    - title: The title of the result
    - url: The URL of the result
    - published_date: (optional) The published date
    - error: (optional) Error message if the search failed

### `extract_structured_data_from_url(url: str, data_description: str, json_schema: dict[str, Any]) -> ExtractStructuredDataResponse`

Extract structured data from websites using powerful visual browser automation.

Args:
    url: The URL to extract data from (must be a valid HTTP/HTTPS URL)
    data_description: Natural language description of the data to extract
Example: "The product name and price in USD"
    json_schema: JSON Schema object to structure the extracted data.
    The extracted data will conform to this schema.
Example: {
    "type": "object",
    "properties": {
    "name": {"type": "string"},
    "price": {"type": "number"}
    },
    "required": ["name", "price"]
    }

Returns:
    ExtractStructuredDataResponse containing:
    - success: Whether the extraction succeeded
    - data: The extracted data (in format defined by json_schema)
    - error: Error message if extraction failed
    - url: The URL that was processed

Examples:
    result = extract_structured_data_from_url(
    url="https://example.com/product",
    data_description="Product details: name, price, and whether it's in stock",
    json_schema={
    "type": "object",
    "properties": {
    "name": {"type": "string"},
    "price": {"type": "number"},
    "in_stock": {"type": "boolean"}
    },
    "required": ["name", "price"]
    }
    )
    print(f"Product: {result.data['name']}, Price: ${result.data['price']}")

### `extract_text_from_urls(urls: list[str]) -> ExtractTextResponse`

Fetch plain text content from one or more URLs. May not be reliable for all websites.

    This is a simple text extraction tool that retrieves the main text content
    from web pages. For reliable, structured data extraction with schema validation,
    use extract_structured_data_from_url instead.

Args:
    urls: List of URLs to fetch (1-10 URLs)
Example: ["https://example.com", "https://example.org"]

Returns:
    ExtractTextResponse containing:
    - success: Whether the fetch succeeded
    - contents: List of content objects with url, title, and text
    - error: Error message if fetch failed

Examples:
    # Fetch text from a single URL
    result = extract_text_from_urls(["https://example.com"])
    if result.success:
    print(f"Title: {result.contents[0].title}")
    print(f"Text: {result.contents[0].text}")

    # Fetch text from multiple URLs
    result = extract_text_from_urls([
    "https://example.com",
    "https://example.org"
    ])
    for content in result.contents:
    print(f"{content.url}: {len(content.text)} characters")

Note:
    This tool may not be reliable for all URLs. For complex extractions
    or structured data, use extract_structured_data_from_url instead.

## Available Types

### `BrowserSearchResponse`

Response from browser_search function.

Fields:
    success: bool
    results: list[BrowserSearchResult]
    error: str | None = None

### `BrowserSearchResult`

Individual search result from browser_search.

Fields:
    title: str
    url: str
    published_date: str | None = None

### `ExtractStructuredDataResponse`

Response from extract_structured_data_from_url function.

Fields:
    success: bool
    data: Any | None = None
    error: str | None = None
    url: str

### `ExtractTextContent`

Individual content result from extract_text_from_urls.

Fields:
    url: str
    title: str | None
    text: str

### `ExtractTextResponse`

Response from extract_text_from_urls function.

Fields:
    success: bool
    contents: list[ExtractTextContent]
    error: str | None = None
