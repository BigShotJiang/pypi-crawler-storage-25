# Sports Module

**Path**: `dawnai.strategy.tools.sports`

## Module Description

Sports data and betting odds from The Odds API.

This module provides access to sports data including available sports,
upcoming events, live odds from multiple bookmakers, and real-time scores.

## Available Functions

### `get_events(sport: str, date_format: Literal['iso', 'unix'] | None = None, event_ids: str | None = None, commence_time_from: str | None = None, commence_time_to: str | None = None) -> GetEventsResponse`

Get upcoming and in-play events for a sport.

    Retrieves a list of upcoming and live sporting events without odds information.
    Use this when you only need event schedules and don't need betting odds.

Args:
    sport: Sport key from get_sports() (e.g., 'americanfootball_nfl', 'basketball_nba')
    date_format: Format for timestamps - 'iso' for ISO 8601 strings (default)
    or 'unix' for Unix timestamps
    event_ids: Comma-separated list of event IDs to filter results.
    Only events with matching IDs will be returned.
    commence_time_from: Filter to show games that commence on/after this time.
    Must be in ISO 8601 format (e.g., '2023-09-09T00:00:00Z')
    commence_time_to: Filter to show games that commence on/before this time.
    Must be in ISO 8601 format (e.g., '2023-09-10T23:59:59Z')

Returns:
    GetEventsResponse containing:
    - success: Whether the request was successful
    - data: List of Event objects with information about each event
    - error: Error message if the request failed
    - metadata: Contains the sport key and event count

Example:
    >>> # Get upcoming NFL games
    >>> response = get_events('americanfootball_nfl')
    >>> if response.success:
    ...     for event in response.data:
    ...         print(f"{event.away_team} @ {event.home_team}")
    ...         print(f"Starts: {event.commence_time}")
    ...
    >>> # Get events for a specific time range
    >>> response = get_events(
    ...     'basketball_nba',
    ...     commence_time_from='2023-10-01T00:00:00Z',
    ...     commence_time_to='2023-10-07T23:59:59Z'
    ... )
    >>> print(f"Found {response.metadata.count} games this week")

### `get_odds_as_probabilities(sport: str, regions: str, markets: str | None = None, date_format: Literal['iso', 'unix'] | None = None, event_ids: str | None = None, bookmakers: str | None = None) -> GetOddsAsProbabilitiesResponse`

Get betting odds for upcoming and live games as implied probabilities.

    Odds are automatically converted from American format to implied probabilities (0-1).
    For example:
    - American odds +150 → 0.40 (40% implied probability)
    - American odds -110 → 0.524 (52.4% implied probability)

Args:
    sport: Sport key from get_sports() (e.g., 'americanfootball_nfl', 'basketball_nba').
    Use 'upcoming' to get odds for upcoming games across all sports.
    regions: Comma-separated list of regions (e.g., 'us', 'uk', 'eu', 'au').
    Determines which bookmakers are returned. Required.
    markets: Comma-separated list of markets to include:
    - 'h2h': Head to head / Moneyline (default if not specified)
    - 'spreads': Point spreads
    - 'totals': Over/Under totals
    - 'outrights': Championship and tournament winner markets
    date_format: Format for timestamps - 'iso' for ISO 8601 (default) or 'unix'
    event_ids: Comma-separated list of event IDs to filter results
    bookmakers: Comma-separated list of specific bookmaker keys to include.
    Takes priority over regions parameter.

Returns:
    GetOddsAsProbabilitiesResponse containing:
    - success: Whether the request was successful
    - data: List of OddsEvent objects with implied probabilities from bookmakers
    - error: Error message if the request failed
    - metadata: Contains sport, regions, markets, and count

Example:
    >>> # Get moneyline probabilities for NFL from US bookmakers
    >>> response = get_odds_as_probabilities('americanfootball_nfl', regions='us')
    >>> if response.success:
    ...     for event in response.data:
    ...         print(f"{event.away_team} @ {event.home_team}")
    ...         for bookmaker in event.bookmakers:
    ...             print(f"  {bookmaker.title}:")
    ...             for market in bookmaker.markets:
    ...                 for outcome in market.outcomes:
    ...                     # probability is the implied probability (0-1)
    ...                     prob_pct = outcome.probability * 100
    ...                     print(
    ...                         f"    {outcome.name}: "
    ...                         f"{outcome.probability:.3f} ({prob_pct:.1f}%)"
    ...                     )
    ...
    >>> # Get spreads and totals probabilities
    >>> response = get_odds_as_probabilities(
    ...     'basketball_nba',
    ...     regions='us',
    ...     markets='spreads,totals'
    ... )

### `get_scores(sport: str, days_from: int | None = None, date_format: Literal['iso', 'unix'] | None = None, event_ids: str | None = None) -> GetScoresResponse`

Get scores for live, upcoming, and recently completed games.

Args:
    sport: Sport key from get_sports() (e.g., 'basketball_nba', 'americanfootball_nfl')
    days_from: Number of days in the past to return completed games (1-3).
    If not specified, only live and upcoming games are returned.
    date_format: Format for timestamps - 'iso' for ISO 8601 (default) or 'unix'
    event_ids: Comma-separated list of event IDs to filter results

Returns:
    GetScoresResponse containing:
    - success: Whether the request was successful
    - data: List of ScoreEvent objects with score information
    - error: Error message if the request failed
    - metadata: Contains sport, days_from, and counts by status

Example:
    >>> # Get live and upcoming NBA games
    >>> response = get_scores('basketball_nba')
    >>> if response.success:
    ...     print(f"Live games: {response.metadata.live_count}")
    ...     print(f"Upcoming: {response.metadata.upcoming_count}")
    ...     for event in response.data:
    ...         if event.scores:  # Game is live or completed
    ...             for score in event.scores:
    ...                 print(f"{score.name}: {score.score}")
    ...
    >>> # Get games from the last 2 days including completed games
    >>> response = get_scores('americanfootball_nfl', days_from=2)
    >>> print(f"Completed: {response.metadata.completed_count}")

### `get_sports(all: bool = False) -> GetSportsResponse`

Get a list of available sports.

    By default, returns only sports that are currently in season. Use the 'all'
    parameter to get both in-season and out-of-season sports.

Args:
    all: If True, returns both in-season and out-of-season sports.
    If False (default), returns only in-season sports.

Returns:
    GetSportsResponse containing:
    - success: Whether the request was successful
    - data: List of Sport objects with information about each sport
    - error: Error message if the request failed
    - metadata: Contains total count and active count of sports

Example:
    >>> # Get only in-season sports
    >>> response = get_sports()
    >>> if response.success:
    ...     for sport in response.data:
    ...         if sport.active:
    ...             print(f"{sport.title} ({sport.key})")
    ...
    >>> # Get all sports including out-of-season
    >>> all_sports = get_sports(all=True)
    >>> print(f"Total sports: {all_sports.metadata.count}")
    >>> print(f"Active sports: {all_sports.metadata.active_count}")

## Available Types

### `Bookmaker`

Bookmaker with their markets and odds.

    Attributes:
    key: Bookmaker identifier
    title: Human-readable bookmaker name
    last_update: ISO 8601 timestamp of last odds update
    markets: List of markets offered by this bookmaker

Fields:
    key: str
    title: str
    last_update: str
    markets: list[Market]

### `Event`

Sports event information.

    Attributes:
    id: Unique event identifier
    sport_key: Sport identifier this event belongs to
    sport_title: Human-readable sport name
    commence_time: ISO 8601 timestamp when the event starts
    home_team: Name of the home team
    away_team: Name of the away team

Fields:
    id: str
    sport_key: str
    sport_title: str
    commence_time: str
    home_team: str
    away_team: str

### `EventMetadata`

Metadata about events listing.

    Attributes:
    sport: Sport key the events belong to
    count: Number of events returned

Fields:
    sport: str
    count: int

### `GetEventsResponse`

Response from get_events function.

    Attributes:
    success: Whether the request was successful
    data: List of events
    error: Error message if request failed
    metadata: Additional metadata about the response

Fields:
    success: bool
    data: list[Event]
    error: str | None = None
    metadata: EventMetadata

### `GetOddsAsProbabilitiesResponse`

Response from get_odds_as_probabilities function.

    Attributes:
    success: Whether the request was successful
    data: List of events with odds information
    error: Error message if request failed
    metadata: Additional metadata about the response

Fields:
    success: bool
    data: list[OddsEvent]
    error: str | None = None
    metadata: OddsMetadata

### `GetScoresResponse`

Response from get_scores function.

    Attributes:
    success: Whether the request was successful
    data: List of events with scores
    error: Error message if request failed
    metadata: Additional metadata about the response

Fields:
    success: bool
    data: list[ScoreEvent]
    error: str | None = None
    metadata: ScoresMetadata

### `GetSportsResponse`

Response from get_sports function.

    Attributes:
    success: Whether the request was successful
    data: List of sports information
    error: Error message if request failed
    metadata: Additional metadata about the response

Fields:
    success: bool
    data: list[Sport]
    error: str | None = None
    metadata: SportMetadata

### `Market`

Betting market with outcomes.

    Attributes:
    key: Market type identifier (e.g., 'h2h', 'spreads', 'totals')
    outcomes: List of betting outcomes in this market

Fields:
    key: str
    outcomes: list[Outcome]

### `OddsEvent`

Event with odds information.

    Attributes:
    id: Unique event identifier
    sport_key: Sport identifier this event belongs to
    sport_title: Human-readable sport name
    commence_time: ISO 8601 timestamp when the event starts
    home_team: Name of the home team
    away_team: Name of the away team
    bookmakers: List of bookmakers offering odds for this event

Fields:
    id: str
    sport_key: str
    sport_title: str
    commence_time: str
    home_team: str
    away_team: str
    bookmakers: list[Bookmaker]

### `OddsMetadata`

Metadata about odds response.

    Attributes:
    sport: Sport key the odds belong to
    regions: Regions requested
    markets: Markets requested
    count: Number of events with odds returned

Fields:
    sport: str
    regions: str
    markets: str | None = None
    count: int

### `Outcome`

Betting outcome within a market.

    Attributes:
    name: Name of the outcome (e.g., team name or 'Over'/'Under')
    probability: Implied probability for this outcome (0-1, converted from American odds)
    point: Point spread or total points (for spreads/totals markets)

Fields:
    name: str
    probability: float
    point: float | None = None

### `Score`

Team score information.

    Attributes:
    name: Team name
    score: Current or final score as string

Fields:
    name: str
    score: str

### `ScoreEvent`

Event with score information.

    Attributes:
    id: Unique event identifier
    sport_key: Sport identifier this event belongs to
    sport_title: Human-readable sport name
    commence_time: ISO 8601 timestamp when the event starts
    completed: Whether the event has finished
    home_team: Name of the home team
    away_team: Name of the away team
    scores: List of team scores (None if event hasn't started)
    last_update: ISO 8601 timestamp of last score update (None if no scores)

Fields:
    id: str
    sport_key: str
    sport_title: str
    commence_time: str
    completed: bool
    home_team: str
    away_team: str
    scores: list[Score] | None = None
    last_update: str | None = None

### `ScoresMetadata`

Metadata about scores response.

    Attributes:
    sport: Sport key the scores belong to
    days_from: Number of days in the past requested
    count: Total number of events returned
    completed_count: Number of completed events
    live_count: Number of live events
    upcoming_count: Number of upcoming events

Fields:
    sport: str
    days_from: int | None = None
    count: int
    completed_count: int
    live_count: int
    upcoming_count: int

### `Sport`

Sport information from The Odds API.

    Attributes:
    key: Unique identifier for the sport (e.g., 'americanfootball_nfl')
    group: Sport category group (e.g., 'American Football')
    title: Human-readable sport name (e.g., 'NFL')
    description: Full description of the sport
    active: Whether the sport is currently in season
    has_outrights: Whether the sport supports outright betting markets

Fields:
    key: str
    group: str
    title: str
    description: str
    active: bool
    has_outrights: bool

### `SportMetadata`

Metadata about sports listing.

    Attributes:
    count: Total number of sports returned
    active_count: Number of sports currently in season

Fields:
    count: int
    active_count: int
