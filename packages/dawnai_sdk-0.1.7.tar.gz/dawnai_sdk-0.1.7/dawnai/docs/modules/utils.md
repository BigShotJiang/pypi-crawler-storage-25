# Utils Module

**Path**: `dawnai.strategy.tools.utils`

## Module Description

Utility functions for strategy development.

## Available Functions

### `classify_text(text: str, categories: list[str], question: str) -> ClassifyTextResponse`

Classify text into one of the provided categories using AI.

    Uses a small language model to classify arbitrary text into predefined categories.
    The question parameter provides context for how the categories relate to the text,
    enabling more accurate classification. Useful for sentiment analysis, outcome
    determination, and pattern matching that would be difficult with naive string matching.

Args:
    text: The text to classify
    categories: List of possible categories to classify the text into
    question: The question or context that relates the text to the categories
    (e.g., "What is the sentiment?" or "Did the event occur?")

Returns:
    ClassifyTextResponse containing:
    - category: The selected category from the provided list

Example:
    >>> text = "The stock price jumped 15% after strong earnings"
    >>> categories = ["positive", "negative", "neutral"]
    >>> question = "What is the sentiment of this text?"
    >>> result = classify_text(text, categories, question)
    >>> print(result.category)
    "positive"

    >>> text = "The event has been postponed indefinitely"
    >>> categories = ["yes", "no", "uncertain"]
    >>> question = "Did the event happen?"
    >>> result = classify_text(text, categories, question)
    >>> print(result.category)
    "no"

### `run_agent(prompt: str, informational_tools: bool = True, execution_tools: bool = False, additional_tools: list[str] | None = None) -> str`

Run a temporary agent with custom prompts and tools.

Args:
    prompt: The prompt for the new agent session
    informational_tools: Whether to include informational tools
    execution_tools: Whether to include execution tools
    additional_tools: List of additional tool names to include

Returns:
    The agent's response

## Available Types

### `ClassifyTextResponse`

Response from classify_text function.

Fields:
    category: str
