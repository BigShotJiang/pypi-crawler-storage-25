# Dawn SDK Documentation - Overview

This overview provides a quick reference to all available SDK modules and functions.
For detailed documentation on each module, see `sdk_docs/{module_name}.md`.

## Modules & Available Tools

The Dawn SDK is organized into modules that provide different types of functionality for trading strategies.
Below is a complete overview of all modules and their available tools:

### Crypto

Cryptocurrency data and exchange functions.

**Tools**:
- `get_cryptocurrency_ohlcv(symbol_id: str, period_id: Literal['1SEC', '1MIN', '5MIN', '15MIN', '30MIN', '1HRS', '4HRS', '8HRS', '1DAY', '7DAY', '1MTH'], limit: int | None = None, time_start: str | None = None, time_end: str | None = None, endpoint: Literal['history', 'latest'] | None = None) -> CryptocurrencyOhlcvResponse`
- `get_exchange_symbols(exchange_id: str) -> ExchangeSymbolsResponse`
- `get_exchanges() -> ExchangesResponse`


### Polymarket

Polymarket prediction market trading and data functions.

**Tools**:
- `get_polymarket_market_details(market_id: str) -> PolymarketMarket | None`
- `get_polymarket_order_book(market_id: str, side: str) -> OrderBookResponse`
- `get_polymarket_prices(market_id: str) -> GetPolymarketPricesResponse`
- `get_polymarket_timeseries(market_id: str, side: str, interval: Literal['1m', '1h', '6h', '1d', '1w', 'max'] = '1h', fidelity: int = 60) -> list[TimeseriesPoint]`
- `polymarket_buy_token(token_id: str, amount: Decimal) -> BuyTokenResult`
- `polymarket_event_markets(event_id: int, limit: int = 10, offset: int = 0, order: Literal['volume24hr', 'volume', 'liquidity', 'startDate', 'endDate'] | None = None, ascending: bool = False, active: bool | None = None, closed: bool | None = None) -> PolymarketEventMarketsResponse`
- `polymarket_event_search(query: str, limit: int = 10, events_status: str = 'active', sort: str | None = None, ascending: bool = False, page: int = 1) -> PolymarketEventSearchResponse`
- `polymarket_list_events(limit: int = 10, offset: int = 0, order: str | None = None, ascending: bool = False, id: list[int] | None = None, slug: list[str] | None = None, tag_id: int | None = None, exclude_tag_id: list[int] | None = None, related_tags: bool | None = None, featured: bool | None = None, cyom: bool | None = None, include_chat: bool | None = None, include_template: bool | None = None, recurrence: str | None = None, closed: bool | None = None, start_date_min: str | None = None, start_date_max: str | None = None, end_date_min: str | None = None, end_date_max: str | None = None) -> PolymarketListEventsResponse`
- `polymarket_sell_token(token_id: str, amount: Decimal) -> SellTokenResult`
- `polymarket_simulate_buy(token_id: str, usd_amount: Decimal) -> SimulateTradeResult`
- `polymarket_simulate_sell(token_id: str, token_amount: Decimal) -> SimulateTradeResult`


### Portfolio

Portfolio management and strategy control functions.

**Tools**:
- `read_portfolio() -> PortfolioResponse`
- `terminate_strategy(should_liquidate: bool = False) -> TerminateStrategyResult`


### Social

Social media integration functions.

**Tools**:
- `get_tweet_info(tweet_ids: list[str]) -> TweetInfoResponse`
- `get_user_tweets(handle: str, cursor: str | None = None) -> UserTweetsResponse`
- `search_tweets(query: str, query_type: str = 'Latest', cursor: str | None = None) -> SearchTweetsResponse`


### Sports

Sports data and betting odds from The Odds API.

**Tools**:
- `get_events(sport: str, date_format: Literal['iso', 'unix'] | None = None, event_ids: str | None = None, commence_time_from: str | None = None, commence_time_to: str | None = None) -> GetEventsResponse`
- `get_odds_as_probabilities(sport: str, regions: str, markets: str | None = None, date_format: Literal['iso', 'unix'] | None = None, event_ids: str | None = None, bookmakers: str | None = None) -> GetOddsAsProbabilitiesResponse`
- `get_scores(sport: str, days_from: int | None = None, date_format: Literal['iso', 'unix'] | None = None, event_ids: str | None = None) -> GetScoresResponse`
- `get_sports(all: bool = False) -> GetSportsResponse`


### Utils

Utility functions for strategy development.

**Tools**:
- `classify_text(text: str, categories: list[str], question: str) -> ClassifyTextResponse`
- `run_agent(prompt: str, informational_tools: bool = True, execution_tools: bool = False, additional_tools: list[str] | None = None) -> str`


### Web

Web search and content extraction functions.

**Tools**:
- `browser_search(query: str, limit: int = 10, category: str | None = None, start_published_date: str | None = None, end_published_date: str | None = None, include_domains: list[str] | None = None, exclude_domains: list[str] | None = None) -> BrowserSearchResponse`
- `extract_structured_data_from_url(url: str, data_description: str, json_schema: dict[str, Any]) -> ExtractStructuredDataResponse`
- `extract_text_from_urls(urls: list[str]) -> ExtractTextResponse`


## Core Tools Module

The main tools module provides the primary interface for accessing SDK functionality.

### Module Description

Tool functions for strategy development with strong typing.

This module provides access to all trading, data, and utility functions
for developing algorithmic trading strategies.

## Usage Notes for AI Agents

1. **Import Pattern**: Trading/data tools via `from dawnai.strategy.tools import function_name`. Config state via `from dawnai import load_config, save_config`.
2. **Module Organization**: Functions are organized by domain (polymarket, crypto, social, etc.)
3. **Type Safety**: All functions include type annotations for better integration
4. **Documentation**: Each function includes docstrings with parameter and return value descriptions
5. **Error Handling**: Functions may raise exceptions - check docstrings for details

## Accessing Detailed Documentation

For detailed documentation on specific modules including all function docstrings, examples, and type definitions, see:

- **Crypto**: `sdk_docs/crypto.md`
- **Polymarket**: `sdk_docs/polymarket.md`
- **Portfolio**: `sdk_docs/portfolio.md`
- **Social**: `sdk_docs/social.md`
- **Sports**: `sdk_docs/sports.md`
- **Utils**: `sdk_docs/utils.md`
- **Web**: `sdk_docs/web.md`
