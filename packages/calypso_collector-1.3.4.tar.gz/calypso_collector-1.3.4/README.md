# Calypso Collector

Oracle database data collector for migration and infrastructure assessment. Developed by [RheoData](https://rheodata.com).

Calypso Collector connects to an Oracle database, executes 333 SQL queries against system views, and exports the results as JSON and Parquet files. The output is consumed by RheoData's assessment tooling to produce migration readiness reports, sizing recommendations, and compatibility analysis across cloud targets.

## What It Collects

| Category | Queries | Description |
|---|---|---|
| Database summary & instance info | 10 | Version, platform, SGA/PGA, PDB status, patch inventory |
| Schema objects & metadata | 10 | Object counts, names, source code line counts, DB links |
| Tables, indexes & constraints | 9 | Table/index types, partitioning, indexes per table, PKs |
| Data types & columns | 1 | Column type distribution across schemas |
| Storage & segments | 6 | Space usage by owner/type, compression, LOB sizing |
| PL/SQL source analysis | 3 | Code metrics, DBMS/UTL package usage, Oracle-specific syntax |
| Features, licensing & HWM | 5 | Feature usage stats, CPU core history, Data Guard config |
| Application detection | 2 | EBS, Siebel, PeopleSoft, SAP, APEX, RDS, OCI flags |
| Backup & recovery | 15 | RMAN summary, backup sets, FRA, flashback, corruption |
| AWR historical performance | 20 | System stats, time model, OS stats, I/O, SQL stats, metrics |
| Statspack performance | 10 | Same as AWR but using STATS$ tables (no Diagnostics Pack) |
| Live session & wait stats | 8 | Wait classes, time model, long ops |
| I/O statistics | 12 | Datafile, tempfile, function, segment, calibration |
| Session concurrency | 12 | Blocking chains, logon storms, parallel execution |
| Transaction metrics | 12 | Volume, redo, locks, trending, peak rates |
| Growth trends | 8 | Tablespace, segment, database size, redo generation |
| Peak utilization | 10 | CPU, memory, sessions, I/O, redo, temp, transactions |
| Network statistics | 12 | Throughput, latency, DB links, connection pools |
| Security & audit | 11 | Privileges, roles, audit policies, VPD, encryption |
| Compatibility checks | 18 | Unsupported types/objects, restricted packages, parameters |
| Character set & timezone | 11 | NLS settings, multibyte data, timezone usage |
| Migration scoring | 5 | DataPump/GoldenGate suitability, method recommendations |
| Snowflake migration | 19 | Datatype mapping, PL/SQL conversion, workload sizing |
| PostgreSQL migration | 10 | Aurora, Azure, GCP, AlloyDB compatibility |
| Azure SQL & Synapse | 15 | Datatype checks, feature gaps, distribution analysis |
| BigQuery migration | 5 | SQL conversion, feature assessment |
| Oracle Cloud targets | 12 | OCI, Azure, AWS, GCP validation |

## Requirements

- Python >= 3.12
- Network access to the target Oracle database (port 1521 by default)
- A database user with DBA privileges (e.g., `SYSTEM`) or `SYS` with `--sysdba` for full coverage

## Installation

```bash
pip install calypso-collector
```

Or from source:

```bash
git clone <repo-url>
cd Calypso-collector
pip install .
```

## Usage

### Basic collection

```bash
calypso --host 10.0.1.50 --service-name ORCLCDB --user system
```

You will be prompted for the password. The collector runs all 333 queries, exports JSON and Parquet files, and prints a summary.

### Password options

```bash
# Interactive prompt (most secure -- no process list exposure)
calypso --host <HOST> --service-name <SVC> --user <USER>

# Environment variable
export CALYPSO_PASSWORD='mypassword'
calypso --host <HOST> --service-name <SVC> --user <USER>

# Command line flag (visible in ps output)
calypso --host <HOST> --service-name <SVC> --user <USER> --password 'mypassword'
```

### Connect as SYSDBA

Required for `SYS` user and access to `x$` kernel tables:

```bash
calypso --host <HOST> --service-name <SVC> --user sys --sysdba
```

### Pluggable Database (PDB)

Connect to a CDB then switch to a specific PDB:

```bash
calypso --host <HOST> --service-name ORCLCDB --user system --pdb orclpdb1
```

### Native Network Encryption (thick mode)

Requires Oracle Instant Client installed locally:

```bash
calypso --host <HOST> --service-name <SVC> --user <USER> --thick
calypso --host <HOST> --service-name <SVC> --user <USER> --thick --oracle-lib /opt/oracle/instantclient
```

### Output options

```bash
# Custom output directory
calypso --host <HOST> --service-name <SVC> --user <USER> --output-dir ~/reports

# Keep the DuckDB file after export (deleted by default)
calypso --host <HOST> --service-name <SVC> --user <USER> --save-cache

# Only produce the DuckDB file, skip JSON/Parquet export
calypso --host <HOST> --service-name <SVC> --user <USER> --skip-export

# Debug logging (shows skipped queries and connection details)
calypso --host <HOST> --service-name <SVC> --user <USER> -v
```

## Output

The collector writes to the output directory (default `./calypso_output/`):

```
calypso_output/
├── json/                          # One .json file per successful query
│   ├── get_system_info_query.json
│   ├── get_instance_info_query.json
│   └── ...
└── parquet/                       # One .parquet file per successful query
    ├── get_system_info_query.parquet
    ├── get_instance_info_query.parquet
    └── ...
```

With `--save-cache`, the intermediate DuckDB file is also kept:

```
calypso_output/
├── calypso_collection.duckdb      # All tables + _metadata, _manifest, _errors
├── json/
└── parquet/
```

### Delivering results to RheoData

Zip the output directory and send it to RheoData for analysis:

```bash
cd ~/reports
zip -r calypso_output.zip calypso_output/
```

## Error Handling

The collector is designed to run to completion even when individual queries fail:

- **ORA-942** (table or view does not exist): Silently skipped. Expected for optional components like Statspack tables, `x$` kernel views, or features not installed. Visible with `-v`.
- **ORA-904** (invalid identifier): Logged as a warning. Usually indicates a column that doesn't exist in the target Oracle version.
- All errors are recorded in the `_errors` table inside the DuckDB file and printed in the final summary.

## CLI Reference

```
calypso [options]

Required:
  --host HOST              Database hostname or IP address
  --service-name SVC       Database service name
  --user USER              Database username

Password:
  --password PW            Database password (or set CALYPSO_PASSWORD; prompted if neither)

Connection:
  --port PORT              Database port (default: 1521)
  --sysdba                 Connect with SYSDBA privilege
  --pdb PDB                PDB name to switch to after connecting
  --thick                  Enable thick mode (Oracle Instant Client)
  --oracle-lib PATH        Path to Oracle Instant Client libraries

Output:
  --output-dir DIR         Output directory (default: ./calypso_output)
  --skip-export            Only produce .duckdb file, skip JSON/Parquet
  --save-cache             Keep the .duckdb file after export

Other:
  -v, --verbose            Enable debug logging
  -V, --version            Show version and exit
```

## Development

```bash
# Install in editable mode with dev dependencies
pip install -e ".[dev]"

# Run tests
pytest

# Lint
ruff check calypso/
```

## License

Copyright RheoData. All rights reserved.
