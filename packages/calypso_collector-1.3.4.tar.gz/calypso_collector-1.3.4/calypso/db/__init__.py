# calypso.db - Database connectivity and query definitions
