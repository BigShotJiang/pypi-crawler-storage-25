"""Query registry and DuckDB collection engine for Calypso."""

import base64
import inspect
import logging
from dataclasses import dataclass, field
from datetime import datetime, date
from decimal import Decimal
from pathlib import Path

import duckdb
import oracledb

from calypso.db import queries

try:
    import pyarrow
    _PYARROW_AVAILABLE = True
except ImportError:
    pyarrow = None
    _PYARROW_AVAILABLE = False

logger = logging.getLogger(__name__)

# Dedicated per-table log: one line per query with the row count, written to
# whatever FileHandler calypso.py attaches. propagate=False is set there.
queries_logger = logging.getLogger("calypso.queries")

# Oracle prefetch / DuckDB insert batch size. The full query's inserts run in
# a single DuckDB transaction, so this only controls Python/Oracle roundtrip
# granularity, not WAL commit frequency. 10000 reduces per-batch overhead on
# multi-million-row data-dictionary queries (dba_tab_columns etc.).
FETCH_CHUNK_SIZE = 10000

# Oracle types whose DuckDB CAST(value AS VARCHAR) produces output equivalent
# to the row-path _sanitize_value(). Excludes DATE/TIMESTAMP (Python isoformat
# uses 'T' separator vs DuckDB cast using a space), BLOB/RAW (base64 vs hex),
# CLOB/NCLOB (need .read() through the LOB locator), and complex types.
_ARROW_SAFE_TYPES = frozenset(
    t for t in (
        getattr(oracledb, name, None)
        for name in (
            "DB_TYPE_NUMBER",
            "DB_TYPE_BINARY_FLOAT",
            "DB_TYPE_BINARY_DOUBLE",
            "DB_TYPE_BINARY_INTEGER",
            "DB_TYPE_VARCHAR",
            "DB_TYPE_NVARCHAR",
            "DB_TYPE_CHAR",
            "DB_TYPE_NCHAR",
            "DB_TYPE_LONG",
            "DB_TYPE_ROWID",
            "DB_TYPE_UROWID",
        )
    )
    if t is not None
)

# Connection.fetch_df_batches() was added in python-oracledb 3.0 (and lives on
# Connection, not Cursor). Older 2.x installs satisfy our previous loose
# dependency floor but crash the Arrow path with AttributeError. Probe the
# method's presence so we degrade to the row path instead.
_ORACLEDB_HAS_DF_BATCHES = hasattr(oracledb.Connection, "fetch_df_batches")

# Disabled at runtime if the first attempt to convert an oracledb DataFrame
# via pyarrow raises (e.g. pyarrow too old for the __arrow_c_stream__ PyCapsule
# protocol). Lets the collector continue on the row path instead of aborting.
_arrow_path_enabled = _PYARROW_AVAILABLE and _ORACLEDB_HAS_DF_BATCHES

if not _PYARROW_AVAILABLE:
    logger.info("pyarrow not installed; Arrow fast-path disabled. "
                "Install pyarrow>=14 to speed up large queries (e.g. dba_tab_columns).")
elif not _ORACLEDB_HAS_DF_BATCHES:
    logger.info("oracledb < 3.0 detected; Arrow fast-path disabled. "
                "Upgrade to oracledb>=3.0 to speed up large queries (e.g. dba_tab_columns).")


@dataclass
class CollectionResult:
    duckdb_path: Path
    tables_collected: int = 0
    tables_failed: int = 0
    errors: list[dict] = field(default_factory=list)


def build_query_registry() -> dict[str, callable]:
    """Auto-discover all query functions in queries.py.

    Returns a dict of {table_name: callable} where table_name is the
    full function name (e.g. 'get_system_info_query', 'archive_log_info').
    """
    registry = {}
    for name, func in inspect.getmembers(queries, inspect.isfunction):
        if func.__module__ == queries.__name__:
            registry[name] = func
    # Safety check
    assert len(registry) == len(set(registry.keys())), "Duplicate table names in query registry"
    return registry


def _sanitize_value(val):
    """Convert Oracle-specific types to DuckDB-safe values."""
    if val is None:
        return None
    if isinstance(val, Decimal):
        return str(val)
    if isinstance(val, (datetime, date)):
        return val.isoformat()
    if isinstance(val, bytes):
        return base64.b64encode(val).decode("ascii")
    if hasattr(val, "read"):  # LOB objects
        data = val.read()
        if isinstance(data, bytes):
            return base64.b64encode(data).decode("ascii")
        return str(data)
    return str(val)


def _format_bytes(n: int) -> str:
    """Render a byte count as KB/MB/GB for human-readable progress output."""
    n = float(n or 0)
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if n < 1024 or unit == "TB":
            return f"{n:.0f} {unit}" if unit in ("B", "KB") else f"{n:.1f} {unit}"
        n /= 1024
    return f"{n:.1f} TB"


def _duckdb_memory_bytes(duckdb_conn) -> tuple[int, int]:
    """Return (resident_bytes, temp_spill_bytes) summed across DuckDB memory pools.

    Uses duckdb_memory(); returns (0, 0) if the function isn't available so
    progress reporting never fails the collection.
    """
    try:
        row = duckdb_conn.execute(
            "SELECT COALESCE(SUM(memory_usage_bytes), 0), "
            "COALESCE(SUM(temporary_storage_bytes), 0) "
            "FROM duckdb_memory()"
        ).fetchone()
        return int(row[0]), int(row[1])
    except Exception:
        return 0, 0


def _arrow_safe(cursor_desc) -> bool:
    """True if every column's Oracle type can be cast to VARCHAR by DuckDB
    while preserving the row-path string representation."""
    return all(col[1] in _ARROW_SAFE_TYPES for col in cursor_desc)


def _emit_progress(progress_callback, table_name, table_index, total_tables,
                   total_rows, duckdb_conn):
    if not progress_callback:
        return
    resident, spilled = _duckdb_memory_bytes(duckdb_conn)
    detail = f"{total_rows:,} rows · DuckDB {_format_bytes(resident)}"
    if spilled:
        detail += f" (+{_format_bytes(spilled)} temp)"
    progress_callback(table_name, table_index, total_tables, detail=detail)


def _insert_via_rows(cursor, duckdb_conn, table_name, columns,
                     progress_callback, table_index, total_tables):
    """Row-mode insert: fetchmany -> _sanitize_value -> executemany.

    Used when result columns include types whose VARCHAR representation
    differs between Python and DuckDB (DATE/TIMESTAMP/BLOB/CLOB/...), or
    when pyarrow is unavailable.
    """
    placeholders = ", ".join(["?"] * len(columns))
    insert_sql = f'INSERT INTO "{table_name}" VALUES ({placeholders})'
    total_rows = 0
    try:
        while True:
            batch = cursor.fetchmany(FETCH_CHUNK_SIZE)
            if not batch:
                break
            sanitized = [[_sanitize_value(v) for v in row] for row in batch]
            duckdb_conn.executemany(insert_sql, sanitized)
            total_rows += len(batch)
            _emit_progress(progress_callback, table_name, table_index,
                           total_tables, total_rows, duckdb_conn)
    except oracledb.Error as e:
        error_obj = e.args[0] if e.args else e
        error_code = str(getattr(error_obj, "code", "N/A"))
        return total_rows, {"table_name": table_name, "error_code": error_code, "error_message": str(e)}
    return total_rows, None


def _insert_via_arrow(oracle_conn, sql, duckdb_conn, table_name, columns,
                      progress_callback, table_index, total_tables):
    """Arrow fast-path: stream pyarrow record batches from oracledb and let
    DuckDB cast each column to VARCHAR in-engine. Avoids per-cell Python
    conversion (~30 cols x 9M rows = 270M sanitize() calls eliminated).

    Note: fetch_df_batches lives on Connection (not Cursor) in oracledb 3.0+,
    so this re-executes `sql` through the connection. The caller should close
    the cursor used for type discovery before invoking this function.
    """
    global _arrow_path_enabled
    cast_cols = ", ".join(f'CAST("{c}" AS VARCHAR) AS "{c}"' for c in columns)
    view = "__calypso_arrow_batch"
    insert_sql = f'INSERT INTO "{table_name}" SELECT {cast_cols} FROM {view}'

    total_rows = 0
    try:
        try:
            batches = oracle_conn.fetch_df_batches(sql, size=FETCH_CHUNK_SIZE)
        except AttributeError as exc:
            # oracledb < 3.0 lacks Connection.fetch_df_batches. The startup
            # probe should have caught this, but stay defensive: disable and
            # fall back.
            _arrow_path_enabled = False
            logger.warning("Arrow fast-path disabled (oracledb missing fetch_df_batches: %s). "
                           "Falling back to row-mode inserts.", exc)
            raise _ArrowPathUnavailable() from exc
        for odf in batches:
            try:
                tbl = pyarrow.table(odf)
            except Exception as exc:
                # Older pyarrow may not understand oracledb's __arrow_c_stream__.
                # Disable for the rest of the run and fall back to row mode for
                # this query. Re-raise so _collect_one can retry on row path.
                _arrow_path_enabled = False
                logger.warning("Arrow fast-path disabled (pyarrow conversion failed: %s). "
                               "Falling back to row-mode inserts.", exc)
                raise _ArrowPathUnavailable() from exc
            # Oracle may return duplicate column names from joins; align with
            # the deduplicated DuckDB schema by replacing names positionally.
            if list(tbl.column_names) != columns:
                tbl = tbl.rename_columns(columns)
            duckdb_conn.register(view, tbl)
            try:
                duckdb_conn.execute(insert_sql)
            finally:
                try:
                    duckdb_conn.unregister(view)
                except Exception:
                    pass
            total_rows += tbl.num_rows
            _emit_progress(progress_callback, table_name, table_index,
                           total_tables, total_rows, duckdb_conn)
    except oracledb.Error as e:
        error_obj = e.args[0] if e.args else e
        error_code = str(getattr(error_obj, "code", "N/A"))
        return total_rows, {"table_name": table_name, "error_code": error_code, "error_message": str(e)}
    return total_rows, None


class _ArrowPathUnavailable(Exception):
    """Raised by the Arrow path when pyarrow can't ingest oracledb's DataFrame,
    signalling _collect_one to redo the query on the row path."""


def _collect_one(
    oracle_conn,
    duckdb_conn,
    table_name,
    query_func,
    progress_callback=None,
    table_index=0,
    total_tables=0,
):
    """Execute one query against Oracle and stream results into DuckDB.

    All inserts run inside a single DuckDB transaction so the WAL isn't
    fsynced per batch (the main bottleneck on million-row data-dictionary
    queries). Uses an Arrow fast-path when result columns are all simple
    numeric/string types; falls back to the row-mode path otherwise.

    Returns (row_count, error_or_none). If a mid-stream Oracle error occurs,
    rows already inserted are kept (transaction committed) and the error is
    reported in the manifest's _errors table.
    """
    sql = query_func()

    def _open_cursor():
        c = oracle_conn.cursor()
        c.arraysize = FETCH_CHUNK_SIZE
        c.execute(sql)
        return c

    try:
        cursor = _open_cursor()
        raw_columns = [col[0].lower() for col in cursor.description]
        cursor_desc = list(cursor.description)
    except oracledb.Error as e:
        error_obj = e.args[0] if e.args else e
        error_code = str(getattr(error_obj, "code", "N/A"))
        return 0, {"table_name": table_name, "error_code": error_code, "error_message": str(e)}

    # Deduplicate column names (e.g. two 'username' columns from a join)
    columns = []
    seen = {}
    for c in raw_columns:
        if c in seen:
            seen[c] += 1
            columns.append(f"{c}_{seen[c]}")
        else:
            seen[c] = 0
            columns.append(c)

    if not columns:
        duckdb_conn.execute(f'CREATE TABLE "{table_name}" (empty_result VARCHAR)')
        cursor.close()
        return 0, None

    col_defs = ", ".join(f'"{c}" VARCHAR' for c in columns)
    duckdb_conn.execute(f'CREATE TABLE "{table_name}" ({col_defs})')

    use_arrow = _arrow_path_enabled and _arrow_safe(cursor_desc)

    duckdb_conn.execute("BEGIN TRANSACTION")
    try:
        if use_arrow:
            # Arrow path streams via Connection.fetch_df_batches(sql), which
            # re-executes the SELECT. Close the discovery cursor first so we
            # don't tie up an extra Oracle cursor handle while it runs.
            try:
                cursor.close()
            except Exception:
                pass
            cursor = None
            try:
                total_rows, error = _insert_via_arrow(
                    oracle_conn, sql, duckdb_conn, table_name, columns,
                    progress_callback, table_index, total_tables,
                )
            except _ArrowPathUnavailable:
                # pyarrow couldn't ingest; restart the query on the row path.
                # ROLLBACK so we don't leave a half-populated table, then
                # re-execute the SELECT and start a new transaction.
                duckdb_conn.execute("ROLLBACK")
                try:
                    cursor = _open_cursor()
                except oracledb.Error as e:
                    error_obj = e.args[0] if e.args else e
                    error_code = str(getattr(error_obj, "code", "N/A"))
                    return 0, {"table_name": table_name, "error_code": error_code, "error_message": str(e)}
                duckdb_conn.execute("BEGIN TRANSACTION")
                total_rows, error = _insert_via_rows(
                    cursor, duckdb_conn, table_name, columns,
                    progress_callback, table_index, total_tables,
                )
        else:
            total_rows, error = _insert_via_rows(
                cursor, duckdb_conn, table_name, columns,
                progress_callback, table_index, total_tables,
            )
        # Commit even when error is set, so partial rows from a mid-stream
        # Oracle failure are preserved (matches pre-1.3.3 behaviour).
        duckdb_conn.execute("COMMIT")
    except Exception:
        try:
            duckdb_conn.execute("ROLLBACK")
        except Exception:
            pass
        try:
            cursor.close()
        except Exception:
            pass
        raise
    finally:
        try:
            cursor.close()
        except Exception:
            pass

    return total_rows, error


def run_collection(oracle_conn, output_dir, metadata=None, progress_callback=None, skip_queries=None):
    """Run all queries and store results in a DuckDB file.

    Args:
        oracle_conn: Active oracledb connection.
        output_dir: Directory for the .duckdb file.
        metadata: Dict of key/value pairs to store (host, port, etc.).
        progress_callback: Callable(table_name, current, total, detail=None) for progress updates.
            `detail` is an optional string describing in-query progress (e.g. row counts).
        skip_queries: Optional iterable of query function names to exclude from the run.

    Returns:
        CollectionResult with summary of the collection.
    """
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    duckdb_path = output_dir / "calypso_collection.duckdb"

    # Remove existing file to start fresh
    if duckdb_path.exists():
        duckdb_path.unlink()

    registry = build_query_registry()
    skipped = []
    if skip_queries:
        skip_set = {s for s in skip_queries if s}
        unknown = sorted(skip_set - registry.keys())
        if unknown:
            logger.warning("Unknown queries in skip list (ignored): %s", ", ".join(unknown))
        skipped = sorted(skip_set & registry.keys())
        if skipped:
            logger.info("Skipping %d queries by request: %s", len(skipped), ", ".join(skipped))
        registry = {k: v for k, v in registry.items() if k not in skip_set}
    result = CollectionResult(duckdb_path=duckdb_path)
    total = len(registry)

    con = duckdb.connect(str(duckdb_path))
    try:
        # Create metadata table
        con.execute("CREATE TABLE _metadata (key VARCHAR, value VARCHAR)")
        meta = {
            "calypso_collected_at": datetime.now().isoformat(),
            "query_count": str(total),
        }
        if skipped:
            meta["skipped_queries"] = ",".join(skipped)
        if metadata:
            meta.update(metadata)
        for k, v in meta.items():
            con.execute("INSERT INTO _metadata VALUES (?, ?)", [k, str(v)])

        # Create manifest and errors tables
        con.execute(
            "CREATE TABLE _manifest (table_name VARCHAR, row_count INTEGER, column_count INTEGER, collected_at TIMESTAMP)"
        )
        con.execute(
            "CREATE TABLE _errors (table_name VARCHAR, error_code VARCHAR, error_message VARCHAR)"
        )

        # Collect each query
        for i, (table_name, query_func) in enumerate(registry.items()):
            if progress_callback:
                progress_callback(table_name, i, total)

            row_count, error = _collect_one(
                oracle_conn,
                con,
                table_name,
                query_func,
                progress_callback=progress_callback,
                table_index=i,
                total_tables=total,
            )

            if error:
                result.tables_failed += 1
                result.errors.append(error)
                con.execute(
                    "INSERT INTO _errors VALUES (?, ?, ?)",
                    [error["table_name"], error["error_code"], error["error_message"]],
                )
                queries_logger.info("%s: FAILED (ORA-%s)", table_name, error["error_code"])
                # ORA-942 (table/view does not exist) is expected for optional
                # components like Statspack, x$ internal tables, and features
                # not installed on the target database.
                if error["error_code"] == "942":
                    logger.debug("Query '%s' skipped (ORA-942): table or view does not exist", table_name)
                else:
                    logger.warning("Query '%s' failed (ORA-%s): %s", table_name, error["error_code"], error["error_message"])
            else:
                result.tables_collected += 1
                # Get column count from the table we just created
                col_info = con.execute(f"SELECT * FROM \"{table_name}\" LIMIT 0").description
                col_count = len(col_info) if col_info else 0
                con.execute(
                    "INSERT INTO _manifest VALUES (?, ?, ?, ?)",
                    [table_name, row_count, col_count, datetime.now()],
                )
                queries_logger.info("%s: %d rows", table_name, row_count)
    finally:
        con.close()

    return result
