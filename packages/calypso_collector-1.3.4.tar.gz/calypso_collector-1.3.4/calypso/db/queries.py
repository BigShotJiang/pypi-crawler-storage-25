# db/queries.py

# This file stores the SQL queries used to collect data for the DB360 assessment.
# Using f-strings allows us to dynamically insert parameters from the config file.

def get_system_info_query():
    return """
    select dbid, name, created, log_mode, open_mode, protection_mode, protection_level, database_role, force_logging, current_scn, flashback_on, platform_name
    from gv$database
    """

def get_system_info_host_query():
    return """
    select dbms_utility.port_string
    from dual
    """

def get_banner_full_query():
    return """
    select i.inst_id, i.instance_name, v.banner_full 
    from gv$version v, gv$instance i
    where i.inst_id = v.inst_id
    order by inst_id
    """

def get_license_info_query():
    return """
    select i.inst_id, i.instance_name, l.cpu_count_current, l.cpu_core_count_current, l.cpu_socket_count_current, l.cpu_count_highwater, l.cpu_core_count_highwater, l.cpu_socket_count_highwater
    from gv$license l, gv$instance i
    where i.inst_id = l.inst_id
    order by inst_id
    """

def get_license_session_info_query():
    return """
    select i.inst_id, i.instance_name, l.sessions_max, l.sessions_warning, l.sessions_current, l.sessions_highwater, l.users_max
    from gv$license l, gv$instance i
    where i.inst_id = l.inst_id
    order by inst_id
    """

def get_system_cpu_query():
    return """
         SELECT                                                                                                                                                                                                                                                                                                                                             
              i.inst_id,                                                                                                                                                                                                                                                                                                                                     
              i.instance_name,                                                                                                                                                                                                                                                                                                                               
              i.host_name,                                                                                                                                                                                                                                                                                                                                   
              p.name AS parameter_name,                                                                                                                                                                                                                                                                                                                      
              p.value AS cpu_count,                                                                                                                                                                                                                                                                                                                          
              p.value / 2 AS cores,                                                                                                                                                                                                                                                                                                                          
              p.value * 2 AS ocpu,                                                                                                                                                                                                                                                                                                                           
              p.value * 8 AS ecpu                                                                                                                                                                                                                                                                                                                            
          FROM gv$parameter p                                                                                                                                                                                                                                                                                                                                
          JOIN gv$instance i ON p.inst_id = i.inst_id                                                                                                                                                                                                                                                                                                        
          WHERE p.name IN ('cpu_count', 'cpu_min_count')                                                                                                                                                                                                                                                                                                     
          ORDER BY i.inst_id, p.name
           """

def get_osstat_cpu_memory_query():
    """OS-level CPU and memory statistics for license validation.

    Returns physical hardware metrics that Oracle auditors use for licensing:
    - NUM_CPUS: Number of CPUs visible to the OS
    - NUM_CPU_CORES: Number of CPU cores (what you license)
    - NUM_CPU_SOCKETS: Number of CPU sockets
    - PHYSICAL_MEMORY_BYTES: Total physical memory
    """
    return """
    SELECT
        i.inst_id,
        i.instance_name,
        i.host_name,
        o.stat_name,
        CASE
            WHEN o.stat_name = 'PHYSICAL_MEMORY_BYTES'
            THEN TO_CHAR(ROUND(o.value/1024/1024/1024, 2))
            ELSE TO_CHAR(o.value)
        END AS value,
        CASE
            WHEN o.stat_name = 'PHYSICAL_MEMORY_BYTES' THEN 'GB'
            ELSE 'count'
        END AS unit,
        o.comments
    FROM gv$osstat o
    JOIN gv$instance i ON o.inst_id = i.inst_id
    WHERE o.stat_name IN ('NUM_CPUS', 'NUM_CPU_CORES', 'NUM_CPU_SOCKETS', 'PHYSICAL_MEMORY_BYTES')
    ORDER BY i.inst_id,
        CASE o.stat_name
            WHEN 'NUM_CPU_SOCKETS' THEN 1
            WHEN 'NUM_CPU_CORES' THEN 2
            WHEN 'NUM_CPUS' THEN 3
            WHEN 'PHYSICAL_MEMORY_BYTES' THEN 4
        END
    """

def get_pdb_info_query():
    """Get PDB information for Multitenant licensing determination.

    Returns list of PDBs (excluding PDB$SEED) to determine if Multitenant license is required:
    - Oracle 19c+: 3 PDBs free without license, 4+ requires license
    - Oracle 12c-18c: 1 PDB free without license, 2+ requires license
    """
    return """
    SELECT pdb_id, pdb_name
    FROM cdb_pdbs
    WHERE pdb_name != 'PDB$SEED'
    ORDER BY pdb_id
    """

def get_instance_info_query():
    return """
    SELECT
        INST_ID,
        INSTANCE_NAME,
        HOST_NAME,
        VERSION,
        STARTUP_TIME,
        STATUS
    FROM
        gv$instance
    """

def get_sga_info():
    return """
    select name, round(value/(1024*1024),2) as total_size_mb 
    from gv$sga
           """

def get_database_details_query():
    return """
    select 
        name, log_mode, supplemental_log_data_min, supplemental_log_data_pk, supplemental_log_data_ui, force_logging, supplemental_log_data_fk, 
supplemental_log_data_all, created
    from gv$database
           """

def get_table_details_cols_query():
    return """
    select owner, data_type, count(*) total
    from all_tab_columns
    where owner not in ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
    group by owner, data_type
    order by owner
           """

def get_object_details_query():
    return """
    select owner, object_type, count(*) total
    from all_objects
    where owner not in ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
    group by owner, object_type
    order by owner
           """

def get_table_details_query():
    return """
    select owner, table_name, tablespace_name, logging, num_rows, last_analyzed, partitioned, compression, global_stats, user_stats 
    from dba_tables
    where owner not in ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
    order by owner
           """

def get_all_size_details_query():
    return """
    select owner, segment_name, partition_name, segment_type, bytes/(1024*1024) as SizeMB
    from dba_segments
    where owner not in ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
    order by owner
           """

def get_index_size_details_query():
    return """
    select owner, segment_name, partition_name, segment_type, sum(bytes/(1024*1024)) as SizeMB
    from dba_segments
    where segment_type = 'INDEX'
    and owner not in ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
    group by owner, segment_name, partition_name, segment_type
           """

def get_table_size_details_query():
    return """
    select owner, segment_name, partition_name, segment_type, sum(bytes/(1024*1024)) as SizeMB 
    from dba_segments
    where segment_type in ('TABLE', 'TABLE PARTITION')
    and owner not in ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
    group by owner, segment_name, partition_name, segment_type
    order by segment_name, segment_type, sizemb desc
           """

def get_contstraint_counts_query():
    return """
    select owner, constraint_type, count(constraint_type)
    from dba_constraints
    where owner not in ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
    group by owner, constraint_type
           """

def get_contstraint_p_counts_query():
    return """
    select owner, constraint_name, status, validated, last_change, delete_rule, generated
    from dba_constraints
    where owner not in ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
    and constraint_type = 'P'
           """

def get_contstraint_c_counts_query():
    return """
    select owner, constraint_name, status, validated, last_change, delete_rule, generated
    from dba_constraints
    where owner not in ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
    and constraint_type = 'C'
           """

def get_contstraint_r_counts_query():
    return """
    select owner, constraint_name, status, validated, last_change, delete_rule, generated
    from dba_constraints
    where owner not in ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
    and constraint_type = 'R'
           """

#Log Info
def get_sup_log_group_info_query():
    return """
    select owner, log_group_name, table_name, log_group_type, always, generated 
    from dba_log_groups
    where owner not in ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
           """

def get_system_sup_log_group_info_query():
    return """
    select owner, log_group_name, table_name, log_group_type, always, generated 
    from dba_log_groups
    where owner not in ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
    and log_group_name like 'SYS%'
           """

def get_trandata_log_group_info_query():
    return """
    select owner, log_group_name, table_name, log_group_type, always, generated 
    from dba_log_groups
    where owner not in ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
    and log_group_name like 'GGS%'
           """

def get_schema_trandata_log_group_info_query():
    return """ 
    select * from LOGMNR$SCHEMA_ALLKEY_SUPLOG
    where allkey_suplog = 'YES'
"""

def get_schema_log_group_table_info_query():
    return """
    SELECT
      st.schema_name,
      st.table_name,
      COUNT(*) AS suplog_columns_count
  FROM
      (SELECT s.schema_name, s.allkey_suplog, t.table_name
       FROM LOGMNR$SCHEMA_ALLKEY_SUPLOG s
       JOIN dba_tables t ON t.owner = s.schema_name
       WHERE s.allkey_suplog = 'YES') st,
      TABLE(logmnr$always_suplog_columns(st.schema_name, st.table_name)) tc
  GROUP BY
      st.schema_name,
      st.table_name
  ORDER BY
      st.schema_name,
      st.table_name
"""

def get_schema_log_group_table_details_query():
    return """
     SELECT 
          --s.schema_name,
          --t.table_name,
          tc.*
      FROM 
          LOGMNR$SCHEMA_ALLKEY_SUPLOG s
          CROSS JOIN dba_tables t
          CROSS JOIN TABLE(logmnr$always_suplog_columns(s.schema_name, t.table_name)) tc
      WHERE 
          s.allkey_suplog = 'YES'
          AND t.owner = s.schema_name
          AND t.table_name NOT LIKE 'BIN$%'
      ORDER BY 
          s.schema_name,
          t.table_name
    """

def get_archive_log_info_query():
    return """
    SELECT SUBSTR(TO_CHAR(FIRST_TIME, 'MM-DD-YY HH24:MI:SS'),1,5) DAY, 
         TO_CHAR(SUM(DECODE(SUBSTR(TO_CHAR(FIRST_TIME, 'MM-DD-YY HH24:MI:SS'),10,2),'00',1,0)),'99') "00", 
         TO_CHAR(SUM(DECODE(SUBSTR(TO_CHAR(FIRST_TIME, 'MM-DD-YY HH24:MI:SS'),10,2),'01',1,0)),'99') "01", 
         TO_CHAR(SUM(DECODE(SUBSTR(TO_CHAR(FIRST_TIME, 'MM-DD-YY HH24:MI:SS'),10,2),'02',1,0)),'99') "02", 
         TO_CHAR(SUM(DECODE(SUBSTR(TO_CHAR(FIRST_TIME, 'MM-DD-YY HH24:MI:SS'),10,2),'03',1,0)),'99') "03", 
         TO_CHAR(SUM(DECODE(SUBSTR(TO_CHAR(FIRST_TIME, 'MM-DD-YY HH24:MI:SS'),10,2),'04',1,0)),'99') "04", 
         TO_CHAR(SUM(DECODE(SUBSTR(TO_CHAR(FIRST_TIME, 'MM-DD-YY HH24:MI:SS'),10,2),'05',1,0)),'99') "05", 
         TO_CHAR(SUM(DECODE(SUBSTR(TO_CHAR(FIRST_TIME, 'MM-DD-YY HH24:MI:SS'),10,2),'06',1,0)),'99') "06", 
         TO_CHAR(SUM(DECODE(SUBSTR(TO_CHAR(FIRST_TIME, 'MM-DD-YY HH24:MI:SS'),10,2),'07',1,0)),'99') "07", 
         TO_CHAR(SUM(DECODE(SUBSTR(TO_CHAR(FIRST_TIME, 'MM-DD-YY HH24:MI:SS'),10,2),'08',1,0)),'99') "08", 
         TO_CHAR(SUM(DECODE(SUBSTR(TO_CHAR(FIRST_TIME, 'MM-DD-YY HH24:MI:SS'),10,2),'09',1,0)),'99') "09", 
         TO_CHAR(SUM(DECODE(SUBSTR(TO_CHAR(FIRST_TIME, 'MM-DD-YY HH24:MI:SS'),10,2),'10',1,0)),'99') "10", 
         TO_CHAR(SUM(DECODE(SUBSTR(TO_CHAR(FIRST_TIME, 'MM-DD-YY HH24:MI:SS'),10,2),'11',1,0)),'99') "11", 
         TO_CHAR(SUM(DECODE(SUBSTR(TO_CHAR(FIRST_TIME, 'MM-DD-YY HH24:MI:SS'),10,2),'12',1,0)),'99') "12", 
         TO_CHAR(SUM(DECODE(SUBSTR(TO_CHAR(FIRST_TIME, 'MM-DD-YY HH24:MI:SS'),10,2),'13',1,0)),'99') "13", 
         TO_CHAR(SUM(DECODE(SUBSTR(TO_CHAR(FIRST_TIME, 'MM-DD-YY HH24:MI:SS'),10,2),'14',1,0)),'99') "14", 
         TO_CHAR(SUM(DECODE(SUBSTR(TO_CHAR(FIRST_TIME, 'MM-DD-YY HH24:MI:SS'),10,2),'15',1,0)),'99') "15", 
         TO_CHAR(SUM(DECODE(SUBSTR(TO_CHAR(FIRST_TIME, 'MM-DD-YY HH24:MI:SS'),10,2),'16',1,0)),'99') "16", 
         TO_CHAR(SUM(DECODE(SUBSTR(TO_CHAR(FIRST_TIME, 'MM-DD-YY HH24:MI:SS'),10,2),'17',1,0)),'99') "17", 
         TO_CHAR(SUM(DECODE(SUBSTR(TO_CHAR(FIRST_TIME, 'MM-DD-YY HH24:MI:SS'),10,2),'18',1,0)),'99') "18", 
         TO_CHAR(SUM(DECODE(SUBSTR(TO_CHAR(FIRST_TIME, 'MM-DD-YY HH24:MI:SS'),10,2),'19',1,0)),'99') "19", 
         TO_CHAR(SUM(DECODE(SUBSTR(TO_CHAR(FIRST_TIME, 'MM-DD-YY HH24:MI:SS'),10,2),'20',1,0)),'99') "20", 
         TO_CHAR(SUM(DECODE(SUBSTR(TO_CHAR(FIRST_TIME, 'MM-DD-YY HH24:MI:SS'),10,2),'21',1,0)),'99') "21", 
         TO_CHAR(SUM(DECODE(SUBSTR(TO_CHAR(FIRST_TIME, 'MM-DD-YY HH24:MI:SS'),10,2),'22',1,0)),'99') "22", 
         TO_CHAR(SUM(DECODE(SUBSTR(TO_CHAR(FIRST_TIME, 'MM-DD-YY HH24:MI:SS'),10,2),'23',1,0)),'99') "23" 
    FROM 	 V$LOG_HISTORY
    WHERE FIRST_TIME >= SYSDATE - 30
    GROUP  BY SUBSTR(TO_CHAR(FIRST_TIME, 'MM-DD-YY HH24:MI:SS'),1,5) 
    order by 1
           """

#Sequence & Trigger Info
def get_sequence_info_query():
    return """
    select sequence_owner, sequence_name, min_value, max_value, increment_by, cycle_flag, order_flag, cache_size, last_number, session_flag, keep_value
    from dba_sequences
    where sequence_owner not in ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
           """

def get_trigger_info_query():
    return """
    select owner, trigger_name, trigger_type, triggering_event, table_owner, table_name, base_object_type 
    from dba_triggers
    where owner not in ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
     """

#Sizing Info
def get_db_size_info():
    return """ 
    select round(sum(bytes/(1024*1024))) as Database_SizeMB, round(sum(bytes/(1024*1024*1024))) as Database_SizeGB, round(sum(bytes/(1024*1024*1024*1024))) as Database_SizeTB
    from dba_segments
           """

def get_schema_object_info():
    return """
    select owner, 
           count(distinct segment_name) as object_count,
           round(sum(bytes/(1024*1024)),2) as total_size_mb
    from dba_segments
    where /* segment_type in ('INDEX','TABLE')
    and */ owner not in ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
    group by owner
    order by
        total_size_mb desc
           """

def get_table_size_info():
    return """
    select owner, 
           count(distinct segment_name) as table_count,
           round(sum(bytes/(1024*1024)),2) as total_size_mb
    from dba_segments
    where segment_type = 'TABLE'
    and owner not in ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
    group by owner
        order by total_size_mb desc
           """

def get_index_size_info():
    return """
    select owner, 
           count(distinct segment_name) as index_count,
           round(sum(bytes/(1024*1024)),2) as total_size_mb
    from dba_segments
    where segment_type = 'INDEX'
    and owner not in ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
    group by owner
        order by total_size_mb desc
           """

def get_tablespace_size_info():
    return """
    SELECT
        df.tablespace_name,
        ROUND(df.total_space_mb, 2) AS allocated_mb,
        ROUND(NVL(fs.free_space_mb, 0), 2) AS free_mb,
        ROUND(df.total_space_mb - NVL(fs.free_space_mb, 0), 2) AS used_mb,
        ROUND((NVL(fs.free_space_mb, 0) / df.total_space_mb) * 100, 2) AS pct_free,
        ROUND(df.max_space_mb, 2) AS max_size_mb
    FROM
        (
            SELECT
                tablespace_name,
                SUM(bytes) / (1024*1024) AS total_space_mb,
                SUM(CASE WHEN autoextensible = 'YES' THEN maxbytes ELSE bytes END) / (1024*1024) AS max_space_mb
            FROM
                dba_data_files
            GROUP BY
                tablespace_name
        ) df
    LEFT JOIN
        (
            SELECT
                tablespace_name,
                SUM(bytes) / (1024*1024) AS free_space_mb
            FROM
                dba_free_space
            GROUP BY
                tablespace_name
        ) fs
    ON
        df.tablespace_name = fs.tablespace_name
    ORDER BY
        df.tablespace_name
"""


def get_temp_files_size_info():
    return """
    SELECT
        tablespace_name,
        ROUND(SUM(bytes) / (1024*1024), 2) AS allocated_mb,
        ROUND(SUM(CASE WHEN autoextensible = 'YES' THEN maxbytes ELSE bytes END) / (1024*1024), 2) AS max_size_mb
    FROM
        dba_temp_files
    GROUP BY
        tablespace_name
    ORDER BY
        tablespace_name
"""


def get_segment_types_size_info():
    return """
    SELECT 
        segment_type,
        COUNT(*) AS segment_count,
        ROUND(SUM(bytes) / (1024*1024), 2) AS total_size_mb,
        ROUND(100 * COUNT(*) / SUM(COUNT(*)) OVER (), 2) || '%' AS pct_of_segments,
        ROUND(100 * SUM(bytes) / SUM(SUM(bytes)) OVER (), 2) || '%' AS pct_of_size
    FROM 
        dba_segments
    GROUP BY 
        segment_type
    ORDER BY 
        total_size_mb DESC
"""
def get_segment_types_info_tablespace_distribution():
    return """
        WITH segment_stats AS (
        SELECT 
            segment_type,
            COUNT(*) AS segment_count,
            SUM(bytes) AS total_bytes,
            COUNT(DISTINCT tablespace_name) AS tablespace_count
        FROM 
            dba_segments
        GROUP BY 
            segment_type
    ),
    totals AS (
        SELECT 
            SUM(segment_count) AS total_segments,
            SUM(total_bytes) AS total_bytes
        FROM 
            segment_stats
    )
    SELECT 
        s.segment_type,
        s.segment_count,
        s.tablespace_count,
        ROUND(s.total_bytes / (1024*1024), 2) AS size_mb,
        ROUND(s.total_bytes / (1024*1024*1024), 2) AS size_gb,
        -- Percentage columns
        ROUND(100 * s.segment_count / t.total_segments, 2) AS pct_of_segments,
        ROUND(100 * s.total_bytes / t.total_bytes, 2) AS pct_of_size,
        -- Formatted percentage strings
        LPAD(TO_CHAR(ROUND(100 * s.segment_count / t.total_segments, 2), '990.99'), 7) || '%' AS segment_pct_formatted,
        LPAD(TO_CHAR(ROUND(100 * s.total_bytes / t.total_bytes, 2), '990.99'), 7) || '%' AS size_pct_formatted,
        -- Visual bar chart (optional)
        RPAD('*', ROUND(50 * s.total_bytes / t.total_bytes), '*') AS size_bar
    FROM 
        segment_stats s
        CROSS JOIN totals t
    ORDER BY 
        s.total_bytes DESC
    """

def get_parameters_info():
    return """
    select con_id, name, value, default_value, description 
    from gv$parameter
    where value is not null
    order by name asc
           """

def oracle_feature_audit_true():
    return """
    select 
    name, version, detected_usages, currently_used, first_usage_date, last_usage_date, description 
    from DBA_FEATURE_USAGE_STATISTICS
    where detected_usages > 0 and currently_used = 'TRUE'
    order by name, FIRST_USAGE_DATE
    """

def oracle_feature_audit_false():
    return """
    select 
    name, version, detected_usages, currently_used, first_usage_date, last_usage_date, description 
    from DBA_FEATURE_USAGE_STATISTICS
    where detected_usages > 0 and currently_used = 'FALSE'
    order by name, FIRST_USAGE_DATE
    """

def oracle_feature_options():
    return """
     -- Comprehensive Oracle Options & Features Report                                                                                                                                                                                                                     
  SELECT                                                                                                                                                                                                                                                                
      'OPTION' AS source,                                                                                                                                                                                                                                               
      parameter AS name,                                                                                                                                                                                                                                                
      value AS status,                                                                                                                                                                                                                                                  
      NULL AS detected_usages,                                                                                                                                                                                                                                          
      NULL AS first_usage_date,                                                                                                                                                                                                                                         
      NULL AS last_usage_date                                                                                                                                                                                                                                           
  FROM v$option                                                                                                                                                                                                                                                         
  WHERE value = 'TRUE'                                                                                                                                                                                                                                                  
  UNION ALL                                                                                                                                                                                                                                                             
  SELECT                                                                                                                                                                                                                                                                
      'FEATURE' AS source,                                                                                                                                                                                                                                              
      name,                                                                                                                                                                                                                                                             
      currently_used AS status,                                                                                                                                                                                                                                         
      detected_usages,                                                                                                                                                                                                                                                  
      first_usage_date,                                                                                                                                                                                                                                                 
      last_usage_date                                                                                                                                                                                                                                                   
  FROM dba_feature_usage_statistics                                                                                                                                                                                                                                     
  WHERE detected_usages > 0                                                                                                                                                                                                                                             
  ORDER BY source, name    
    """
def oracle_licesable_features_options_mapped():
    return """                                                                                                                                                                                                                                                               
WITH MAP AS (
  SELECT 'Active Data Guard' PRODUCT, 'Active Data Guard - Real-Time Query on Physical Standby' FEATURE FROM dual UNION ALL
  SELECT 'Active Data Guard', 'Global Data Services' FROM dual UNION ALL
  SELECT 'Active Data Guard or RAC', 'Application Continuity' FROM dual UNION ALL
  SELECT 'Advanced Analytics', 'Data Mining' FROM dual UNION ALL
  SELECT 'Advanced Compression', 'Advanced Index Compression' FROM dual UNION ALL
  SELECT 'Advanced Compression', 'Backup HIGH Compression' FROM dual UNION ALL
  SELECT 'Advanced Compression', 'Backup LOW Compression' FROM dual UNION ALL
  SELECT 'Advanced Compression', 'Backup MEDIUM Compression' FROM dual UNION ALL
  SELECT 'Advanced Compression', 'Backup ZLIB Compression' FROM dual UNION ALL
  SELECT 'Advanced Compression', 'HeapCompression' FROM dual UNION ALL
  SELECT 'Advanced Compression', 'Heat Map' FROM dual UNION ALL
  SELECT 'Advanced Compression', 'Hybrid Columnar Compression Row Level Locking' FROM dual UNION ALL
  SELECT 'Advanced Compression', 'Information Lifecycle Management' FROM dual UNION ALL
  SELECT 'Advanced Compression', 'Oracle Advanced Network Compression Service' FROM dual UNION ALL
  SELECT 'Advanced Compression', 'SecureFile Compression (user)' FROM dual UNION ALL
  SELECT 'Advanced Compression', 'SecureFile Deduplication (user)' FROM dual UNION ALL
  SELECT 'Advanced Security', 'Data Redaction' FROM dual UNION ALL
  SELECT 'Advanced Security', 'Encrypted Tablespaces' FROM dual UNION ALL
  SELECT 'Advanced Security', 'SecureFile Encryption (user)' FROM dual UNION ALL
  SELECT 'Advanced Security', 'Transparent Data Encryption' FROM dual UNION ALL
  SELECT 'Database Gateway', 'Gateways' FROM dual UNION ALL
  SELECT 'Database Gateway', 'Transparent Gateway' FROM dual UNION ALL
  SELECT 'Database In-Memory', 'In-Memory ADO Policies' FROM dual UNION ALL
  SELECT 'Database In-Memory', 'In-Memory Aggregation' FROM dual UNION ALL
  SELECT 'Database In-Memory', 'In-Memory Column Store' FROM dual UNION ALL
  SELECT 'Database In-Memory', 'In-Memory Distribute For Service (User Defined)' FROM dual UNION ALL
  SELECT 'Database In-Memory', 'In-Memory Expressions' FROM dual UNION ALL
  SELECT 'Database In-Memory', 'In-Memory FastStart' FROM dual UNION ALL
  SELECT 'Database In-Memory', 'In-Memory Join Groups' FROM dual UNION ALL
  SELECT 'Database Vault', 'Oracle Database Vault' FROM dual UNION ALL
  SELECT 'Database Vault', 'Privilege Capture' FROM dual UNION ALL
  SELECT 'Diagnostics Pack', 'ADDM' FROM dual UNION ALL
  SELECT 'Diagnostics Pack', 'AWR Baseline' FROM dual UNION ALL
  SELECT 'Diagnostics Pack', 'AWR Baseline Template' FROM dual UNION ALL
  SELECT 'Diagnostics Pack', 'AWR Report' FROM dual UNION ALL
  SELECT 'Diagnostics Pack', 'Automatic Workload Repository' FROM dual UNION ALL
  SELECT 'Diagnostics Pack', 'Baseline Adaptive Thresholds' FROM dual UNION ALL
  SELECT 'Diagnostics Pack', 'Baseline Static Computations' FROM dual UNION ALL
  SELECT 'Diagnostics Pack', 'EM Performance Page' FROM dual UNION ALL
  SELECT 'Exadata', 'Cloud DB with EHCC' FROM dual UNION ALL
  SELECT 'Exadata', 'Exadata' FROM dual UNION ALL
  SELECT 'GoldenGate', 'GoldenGate' FROM dual UNION ALL
  SELECT 'HW (Storage)', 'Hybrid Columnar Compression' FROM dual UNION ALL
  SELECT 'HW (Storage)', 'Hybrid Columnar Compression Conventional Load' FROM dual UNION ALL
  SELECT 'HW (Storage)', 'ODA Infrastructure' FROM dual UNION ALL
  SELECT 'HW (Storage)', 'Sun ZFS with EHCC' FROM dual UNION ALL
  SELECT 'HW (Storage)', 'ZFS Storage' FROM dual UNION ALL
  SELECT 'HW (Storage)', 'Zone maps' FROM dual UNION ALL
  SELECT 'Label Security', 'Label Security' FROM dual UNION ALL
  SELECT 'Multitenant', 'Oracle Multitenant' FROM dual UNION ALL
  SELECT 'Multitenant', 'Oracle Pluggable Databases' FROM dual UNION ALL
  SELECT 'OLAP', 'OLAP - Analytic Workspaces' FROM dual UNION ALL
  SELECT 'OLAP', 'OLAP - Cubes' FROM dual UNION ALL
  SELECT 'Partitioning', 'Partitioning (user)' FROM dual UNION ALL
  SELECT 'Partitioning', 'Zone maps' FROM dual UNION ALL
  SELECT 'RAC or RAC One Node', 'Quality of Service Management' FROM dual UNION ALL
  SELECT 'Real Application Clusters', 'Real Application Clusters (RAC)' FROM dual UNION ALL
  SELECT 'Real Application Clusters One Node', 'Real Application Cluster One Node' FROM dual UNION ALL
  SELECT 'Real Application Testing', 'Database Replay: Workload Capture' FROM dual UNION ALL
  SELECT 'Real Application Testing', 'Database Replay: Workload Replay' FROM dual UNION ALL
  SELECT 'Real Application Testing', 'SQL Performance Analyzer' FROM dual UNION ALL
  SELECT 'Spatial and Graph', 'Spatial' FROM dual UNION ALL
  SELECT 'Tuning Pack', 'SQL Access Advisor' FROM dual UNION ALL
  SELECT 'Tuning Pack', 'SQL Monitoring and Tuning pages' FROM dual UNION ALL
  SELECT 'Tuning Pack', 'SQL Profile' FROM dual UNION ALL
  SELECT 'Tuning Pack', 'SQL Tuning Advisor' FROM dual
)
SELECT 
  m.PRODUCT,
  CASE 
    WHEN MAX(CASE WHEN f.currently_used = 'TRUE' THEN 1 ELSE 0 END) = 1 THEN 'CURRENT_USAGE'
    WHEN MAX(f.detected_usages) > 0 THEN 'PAST_USAGE'
    ELSE 'NO_USAGE'
  END AS USAGE,
  CASE 
    WHEN MAX(CASE WHEN f.currently_used = 'TRUE' THEN 1 ELSE 0 END) = 1 THEN 'TRUE'
    ELSE 'FALSE'
  END AS CURRENTLY_USED,
  SUM(f.detected_usages) AS DETECTED_USAGES,
  TO_CHAR(MIN(f.first_usage_date), 'YYYY-MM-DD') AS FIRST_USAGE,
  TO_CHAR(MAX(f.last_usage_date), 'YYYY-MM-DD') AS LAST_USAGE
FROM MAP m
LEFT JOIN dba_feature_usage_statistics f ON m.FEATURE = f.name
GROUP BY m.PRODUCT
HAVING MAX(f.detected_usages) > 0
ORDER BY 
  CASE WHEN MAX(CASE WHEN f.currently_used = 'TRUE' THEN 1 ELSE 0 END) = 1 THEN 1
       WHEN MAX(f.detected_usages) > 0 THEN 2
       ELSE 3 END,
  m.PRODUCT
    """

def database_lob_objects():
    return """
    select owner, table_name, column_name, in_row, format, segment_name, index_name, chunk, logging, encrypt, compression
    from dba_lobs
    where owner not in ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
    order by owner, table_name
           """

def database_lob_objects_by_owner():
    return """
    SELECT
    owner,
    SUM(chunk/(1024*1024)) AS total_chunk_size_mb
    FROM
        dba_lobs
    WHERE
        owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
    GROUP BY
        owner
    ORDER BY
        owner
           """

def database_lob_total():
    return """
    SELECT
    SUM(chunk/(1024*1024)) AS total_chunk_size_mb
    FROM
        dba_lobs
    WHERE
        owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
           """

def archive_log_info():
    return """
    select recid, name as archivelog_name, round(blocks * block_size/(1024*1024),2) as size_mb, status, compressed
    from v$archived_log
        order by status asc
           """

def redo_log_info():
    return """
    SELECT
     a.GROUP#,
     a.THREAD#,
     a.SEQUENCE#,
     a.ARCHIVED,
     a.STATUS,
     b.MEMBER AS REDOLOG_FILE_NAME,
     (a.BYTES/1024/1024) AS SIZE_MB
    FROM v$log a
    JOIN v$logfile b ON a.Group#=b.Group#
    ORDER BY a.GROUP#
           """

#Time Model Stats
def sys_time_model_query():
    return """
    select inst_id, stat_name, round(value/1000000, 2) as "Seconds", round((value/1000000)/60, 2) as "Minutess", round(((value/1000000)/60)/60, 2) as "Hours"
    from GV$SYS_TIME_MODEL
"""

def session_time_model_query():
    return """
    SELECT 
        s.inst_id,
        s.sid,
        s.serial#,
        s.username,
        s.status,
        s.program,
        s.machine,
        stm.stat_name,
        round((stm.value/1000000)/60, 2) as "Minutess"
    FROM 
        gv$session s
        INNER JOIN gv$sess_time_model stm 
            ON s.inst_id = stm.inst_id 
            AND s.sid = stm.sid
    WHERE 
        s.username NOT IN (
            'S$NULL', 'LBACSYS', 'OUTLN', 'DBSNMP', 'APPQOSSYS', 'VECSYS', 'DBSFWUSER', 'GGSYS',
            'ANONYMOUS', 'CTXSYS', 'DVF', 'DVSYS', 'AUDSYS', 'GSMADMIN_INTERNAL', 'GGSHAREDCAP',
            'OLAPSYS', 'MDSYS', 'XDB', 'WMSYS', 'GSMCATUSER', 'MDDATA',
            'REMOTE_SCHEDULER_AGENT', 'SYSBACKUP', 'GSMUSER', 'OJVMSYS', 'DIP', 'DGPDB_INT',
            'SYSKM', 'SYS$UMF', 'SYSDG', 'SYS', 'SYSTEM', 'SYSRAC'
        )
    ORDER BY 
        s.inst_id, 
        s.sid, 
        stm.stat_name
"""

def session_time_model_io_query():
    return """
    SELECT 
        s.inst_id,
        s.sid,
        s.serial#,
        s.username,
        s.status,
        s.program,
        s.machine,
        -- Time model stats (pivoted)
        MAX(CASE WHEN stm.stat_name = 'DB time' THEN round((stm.value/1000000)/60, 2) END) AS db_time_mins,
        MAX(CASE WHEN stm.stat_name = 'DB CPU' THEN round((stm.value/1000000)/60, 2) END) AS db_cpu_mins,
        MAX(CASE WHEN stm.stat_name = 'sql execute elapsed time' THEN round((stm.value/1000000)/60, 2) END) AS sql_exec_time_mins,
        MAX(CASE WHEN stm.stat_name = 'parse time elapsed' THEN round((stm.value/1000000)/60, 2) END) AS parse_time_mins,
        -- I/O stats
        sio.block_gets,
        sio.consistent_gets,
        sio.physical_reads,
        sio.block_changes,
        sio.consistent_changes,
        sio.optimized_physical_reads
    FROM 
        gv$session s
        INNER JOIN gv$sess_time_model stm 
            ON s.inst_id = stm.inst_id 
            AND s.sid = stm.sid
        INNER JOIN gv$sess_io sio
            ON s.inst_id = sio.inst_id
            AND s.sid = sio.sid
    WHERE 
        s.username IS NOT NULL  -- Optional: filters out background processes
    GROUP BY 
        s.inst_id,
        s.sid,
        s.serial#,
        s.username,
        s.status,
        s.program,
        s.machine,
        sio.block_gets,
        sio.consistent_gets,
        sio.physical_reads,
        sio.block_changes,
        sio.consistent_changes,
        sio.optimized_physical_reads
    ORDER BY 
        s.inst_id, 
        s.sid
    """

def session_longops():
    return """
SELECT 
    s.inst_id,
    s.sid,
    s.serial#,
    s.username,
    s.status,
    s.program,
    s.machine,
    stm.opname,
    stm.sofar,
    stm.totalwork,
    stm.units,
    stm.message,
    stm.start_time,
    stm.last_update_time,
    stm.time_remaining,
    stm.elapsed_seconds,
    stm.username AS longops_username
FROM
    gv$session s
    INNER JOIN gv$session_longops stm 
        ON s.inst_id = stm.inst_id 
        AND s.sid = stm.sid
WHERE 
    s.username IS NOT NULL  -- Optional: filters out background processes
GROUP BY
    s.inst_id,
    s.sid,
    s.serial#,
    s.username,
    s.status,
    s.program,
    s.machine,
    stm.opname,
    stm.sofar,
    stm.totalwork,
    stm.units,
    stm.message,
    stm.start_time,
    stm.last_update_time,
    stm.time_remaining,
    stm.elapsed_seconds,
    stm.username
ORDER BY
    s.inst_id,
    s.sid
    """

def session_wait_by_class():
    return """
SELECT 
    s.inst_id,
    s.sid,
    s.serial#,
    s.username,
    s.status,
    s.program,
    s.machine,
    -- Wait class times in seconds
    ROUND(MAX(CASE WHEN swc.wait_class = 'Application' THEN swc.time_waited END)/100, 2) AS application_wait_sec,
    ROUND(MAX(CASE WHEN swc.wait_class = 'Commit' THEN swc.time_waited END)/100, 2) AS commit_wait_sec,
    ROUND(MAX(CASE WHEN swc.wait_class = 'Concurrency' THEN swc.time_waited END)/100, 2) AS concurrency_wait_sec,
    ROUND(MAX(CASE WHEN swc.wait_class = 'Configuration' THEN swc.time_waited END)/100, 2) AS configuration_wait_sec,
    ROUND(MAX(CASE WHEN swc.wait_class = 'Network' THEN swc.time_waited END)/100, 2) AS network_wait_sec,
    ROUND(MAX(CASE WHEN swc.wait_class = 'User I/O' THEN swc.time_waited END)/100, 2) AS user_io_wait_sec,
    ROUND(MAX(CASE WHEN swc.wait_class = 'System I/O' THEN swc.time_waited END)/100, 2) AS system_io_wait_sec,
    ROUND(MAX(CASE WHEN swc.wait_class = 'Other' THEN swc.time_waited END)/100, 2) AS other_wait_sec,
    ROUND(MAX(CASE WHEN swc.wait_class = 'Idle' THEN swc.time_waited END)/100, 2) AS idle_wait_sec
FROM 
    gv$session s
    INNER JOIN gv$session_wait_class swc
        ON s.inst_id = swc.inst_id 
        AND s.sid = swc.sid
WHERE 
    s.username IS NOT NULL  -- Optional: filters out background processes
GROUP BY 
    s.inst_id,
    s.sid,
    s.serial#,
    s.username,
    s.status,
    s.program,
    s.machine
ORDER BY 
    s.inst_id, 
    s.sid
"""

def session_stats():
    return """
    SELECT 
        s.inst_id,
        s.sid,
        s.serial#,
        s.username,
        s.status,
        s.program,
        s.machine,
        -- Key performance statistics
        MAX(CASE WHEN n.name = 'session logical reads' THEN ss.value END) AS logical_reads,
        MAX(CASE WHEN n.name = 'physical reads' THEN ss.value END) AS physical_reads,
        MAX(CASE WHEN n.name = 'physical writes' THEN ss.value END) AS physical_writes,
        MAX(CASE WHEN n.name = 'session pga memory' THEN ss.value END) AS pga_memory,
        MAX(CASE WHEN n.name = 'session uga memory' THEN ss.value END) AS uga_memory,
        MAX(CASE WHEN n.name = 'parse count (total)' THEN ss.value END) AS parse_count_total,
        MAX(CASE WHEN n.name = 'parse count (hard)' THEN ss.value END) AS parse_count_hard,
        MAX(CASE WHEN n.name = 'execute count' THEN ss.value END) AS execute_count,
        MAX(CASE WHEN n.name = 'user commits' THEN ss.value END) AS user_commits,
        MAX(CASE WHEN n.name = 'user rollbacks' THEN ss.value END) AS user_rollbacks,
        MAX(CASE WHEN n.name = 'sorts (memory)' THEN ss.value END) AS sorts_memory,
        MAX(CASE WHEN n.name = 'sorts (disk)' THEN ss.value END) AS sorts_disk,
        MAX(CASE WHEN n.name = 'CPU used by this session' THEN ss.value END) AS cpu_used_centiseconds,
        MAX(CASE WHEN n.name = 'DB time' THEN ss.value END) AS db_time_centiseconds
    FROM 
        gv$session s
        INNER JOIN gv$sesstat ss
            ON s.inst_id = ss.inst_id 
            AND s.sid = ss.sid
        INNER JOIN v$statname n
            ON ss.statistic# = n.statistic#
    WHERE 
        s.username IS NOT NULL  -- Optional: filters out background processes
    GROUP BY 
        s.inst_id,
        s.sid,
        s.serial#,
        s.username,
        s.status,
        s.program,
        s.machine
    ORDER BY 
        s.inst_id, 
        s.sid
"""

def detailed_wait_stats_min_max():
    return """
     SELECT 
        se.wait_class,
        COUNT(*) AS event_count,
        SUM(se.total_waits) AS total_waits,
        SUM(se.time_waited) AS time_waited_centisecs,
        ROUND(SUM(se.time_waited)/100, 2) AS time_waited_seconds,
        -- Min/Max statistics
        MIN(se.average_wait) AS min_avg_wait_centisecs,
        MAX(se.average_wait) AS max_avg_wait_centisecs,
        ROUND(AVG(se.average_wait), 4) AS avg_wait_centisecs,
        -- Timeout analysis
        SUM(se.total_timeouts) AS total_timeouts,
        MAX(se.total_timeouts) AS max_timeouts_single_event,
        -- Events with highest waits
        MAX(se.total_waits) AS max_waits_single_event,
        MAX(se.time_waited) AS max_time_single_event
    FROM 
        gv$system_event se
    GROUP BY 
        se.wait_class
    HAVING 
        SUM(se.total_waits) > 0  -- Only show wait classes with actual waits
    ORDER BY 
        time_waited_seconds DESC
    """

def percentage_wait_stats():
    return """
    WITH wait_totals AS (
        SELECT 
            SUM(CASE WHEN wait_class != 'Idle' THEN time_waited ELSE 0 END) AS total_non_idle_time,
            SUM(time_waited) AS total_time
        FROM 
            gv$system_event
    )
    SELECT 
        se.wait_class,
        COUNT(*) AS event_count,
        SUM(se.total_waits) AS total_waits,
        ROUND(SUM(se.time_waited)/100, 2) AS time_waited_seconds,
        ROUND(100 * SUM(se.time_waited) / wt.total_time, 2) AS pct_of_total_time,
        ROUND(100 * SUM(se.time_waited) / wt.total_non_idle_time, 2) AS pct_of_non_idle_time,
        -- Top events in this wait class
        LISTAGG(
            CASE 
                WHEN ROWNUM <= 3 THEN se.event 
            END, ', '
        ) WITHIN GROUP (ORDER BY se.time_waited DESC) AS top_3_events
    FROM 
        gv$system_event se
        CROSS JOIN wait_totals wt
    GROUP BY 
        se.wait_class,
        wt.total_time,
        wt.total_non_idle_time
    ORDER BY 
        CASE WHEN se.wait_class = 'Idle' THEN 1 ELSE 0 END,  -- Put Idle last
        time_waited_seconds DESC
"""

def instance_level_wait_stats():
    return """
    SELECT 
        se.inst_id,
        se.wait_class,
        COUNT(*) AS event_count,
        SUM(se.total_waits) AS total_waits,
        SUM(se.total_timeouts) AS total_timeouts,
        SUM(se.time_waited) AS time_waited_centisecs,
        ROUND(SUM(se.time_waited)/100, 2) AS time_waited_seconds,
        ROUND(SUM(se.time_waited_micro)/1000000, 2) AS time_waited_seconds_micro,
        ROUND(SUM(se.time_waited_fg)/100, 2) AS foreground_time_waited_seconds,
        ROUND(AVG(se.average_wait), 4) AS avg_wait_centisecs,
        ROUND(100 * SUM(se.total_timeouts) / NULLIF(SUM(se.total_waits), 0), 2) AS timeout_percentage
    FROM 
        gv$system_event se
    WHERE 
        se.wait_class != 'Idle'  -- Optional: exclude idle events
    GROUP BY 
        se.inst_id,
        se.wait_class
    ORDER BY 
        se.inst_id,
        time_waited_seconds DESC
    """

#CPU & Memory over time
def get_historical_cpu_memory_awr():
    return """
    -- Historical CPU and memory from DBA_HIST_SYSMETRIC_SUMMARY
    SELECT
        m.instance_number,
        TO_CHAR(m.begin_time, 'YYYY-MM-DD HH24:MI') AS snapshot_time,
        ROUND(AVG(CASE WHEN m.metric_name = 'Host CPU Utilization (%)' THEN m.average END), 2) AS avg_host_cpu_pct,
        ROUND(MAX(CASE WHEN m.metric_name = 'Host CPU Utilization (%)' THEN m.maxval END), 2) AS max_host_cpu_pct,
        ROUND(AVG(CASE WHEN m.metric_name = 'Database CPU Time Ratio' THEN m.average END), 2) AS avg_db_cpu_ratio,
        ROUND(AVG(CASE WHEN m.metric_name = 'Physical Memory (MB)' THEN m.average END), 2) AS avg_physical_memory_mb,
        ROUND(AVG(CASE WHEN m.metric_name = 'Free Memory (MB)' THEN m.average END), 2) AS avg_free_memory_mb,
        ROUND(AVG(CASE WHEN m.metric_name = 'Total PGA Allocated (MB)' THEN m.average END), 2) AS avg_pga_mb,
        ROUND(AVG(CASE WHEN m.metric_name = 'Total SGA Allocated (MB)' THEN m.average END), 2) AS avg_sga_mb
    FROM 
        dba_hist_sysmetric_summary m
    WHERE 
        m.begin_time >= SYSDATE - 7
        AND m.metric_name IN (
            'Host CPU Utilization (%)',
            'Database CPU Time Ratio',
            'Physical Memory (MB)',
            'Free Memory (MB)',
            'Total PGA Allocated (MB)',
            'Total SGA Allocated (MB)'
        )
    GROUP BY 
        m.instance_number,
        m.begin_time
    ORDER BY 
        m.instance_number,
        m.begin_time DESC
    """

def get_cpu_time_model_analysis():
    return """
    -- CPU consumption by time model over time
    WITH time_model_data AS (
        SELECT 
            s.instance_number,
            s.begin_interval_time,
            s.end_interval_time,
            tm.stat_name,
            (tm.value - LAG(tm.value) OVER (PARTITION BY s.instance_number, tm.stat_name ORDER BY s.snap_id)) AS delta_value
        FROM 
            dba_hist_sys_time_model tm
            JOIN dba_hist_snapshot s ON tm.snap_id = s.snap_id AND tm.dbid = s.dbid AND tm.instance_number = s.instance_number
        WHERE 
            s.begin_interval_time >= SYSDATE - 1
            AND tm.stat_name IN ('DB time', 'DB CPU', 'background cpu time', 'sql execute elapsed time', 'parse time elapsed')
    )
    SELECT 
        instance_number,
        TO_CHAR(begin_interval_time, 'YYYY-MM-DD HH24:MI') AS snapshot_time,
        ROUND(SUM(CASE WHEN stat_name = 'DB time' THEN delta_value END) / 1000000, 2) AS db_time_sec,
        ROUND(SUM(CASE WHEN stat_name = 'DB CPU' THEN delta_value END) / 1000000, 2) AS db_cpu_sec,
        ROUND(SUM(CASE WHEN stat_name = 'background cpu time' THEN delta_value END) / 1000000, 2) AS bg_cpu_sec,
        ROUND(100 * SUM(CASE WHEN stat_name = 'DB CPU' THEN delta_value END) / 
            NULLIF(SUM(CASE WHEN stat_name = 'DB time' THEN delta_value END), 0), 2) AS cpu_pct_of_db_time
    FROM 
        time_model_data
    WHERE 
        delta_value >= 0  -- Filter out negative deltas from restarts
    GROUP BY 
        instance_number,
        begin_interval_time
    ORDER BY 
        instance_number,
        begin_interval_time DESC
    """

def get_pga_sga_memory_trending():
    return """
    -- Memory utilization trending from AWR
    SELECT 
        s.instance_number,
        TO_CHAR(s.begin_interval_time, 'YYYY-MM-DD HH24:MI') AS snapshot_time,
        -- SGA Components
        ROUND(sga.sga_size / (1024*1024*1024), 2) AS sga_total_gb,
        ROUND(sga.buffer_cache / (1024*1024*1024), 2) AS buffer_cache_gb,
        ROUND(sga.shared_pool / (1024*1024*1024), 2) AS shared_pool_gb,
        -- PGA Statistics
        ROUND(pga.pga_target / (1024*1024*1024), 2) AS pga_target_gb,
        ROUND(pga.pga_allocated / (1024*1024*1024), 2) AS pga_allocated_gb,
        ROUND(pga.pga_in_use / (1024*1024*1024), 2) AS pga_in_use_gb,
        -- Memory Utilization Percentages
        ROUND(100 * pga.pga_in_use / NULLIF(pga.pga_target, 0), 2) AS pga_usage_pct
    FROM 
        dba_hist_snapshot s
        LEFT JOIN (
            SELECT 
                snap_id,
                dbid,
                instance_number,
                SUM(bytes) AS sga_size,
                SUM(CASE WHEN pool = 'buffer_cache' THEN bytes END) AS buffer_cache,
                SUM(CASE WHEN pool = 'shared pool' THEN bytes END) AS shared_pool
            FROM 
                dba_hist_sgastat
            GROUP BY 
                snap_id, dbid, instance_number
        ) sga ON s.snap_id = sga.snap_id AND s.dbid = sga.dbid AND s.instance_number = sga.instance_number
        LEFT JOIN (
            SELECT 
                snap_id,
                dbid,
                instance_number,
                MAX(CASE WHEN name = 'aggregate PGA target parameter' THEN value END) AS pga_target,
                MAX(CASE WHEN name = 'total PGA allocated' THEN value END) AS pga_allocated,
                MAX(CASE WHEN name = 'total PGA inuse' THEN value END) AS pga_in_use
            FROM 
                dba_hist_pgastat
            GROUP BY 
                snap_id, dbid, instance_number
        ) pga ON s.snap_id = pga.snap_id AND s.dbid = pga.dbid AND s.instance_number = pga.instance_number
    WHERE 
        s.begin_interval_time >= SYSDATE - 7
    ORDER BY 
        s.instance_number,
        s.begin_interval_time DESC
    """

def get_resource_pressure_alerts():
    return """
    -- Identify periods of high CPU or memory pressure
    WITH resource_metrics AS (
        SELECT
            m.instance_number,
            TO_CHAR(m.begin_time, 'YYYY-MM-DD HH24') AS hour_period,
            AVG(CASE WHEN m.metric_name = 'Host CPU Utilization (%)' THEN m.average END) AS avg_cpu_pct,
            MAX(CASE WHEN m.metric_name = 'Host CPU Utilization (%)' THEN m.maxval END) AS max_cpu_pct,
            AVG(CASE WHEN m.metric_name = 'Database CPU Time Ratio' THEN m.average END) AS avg_db_cpu_ratio
        FROM
            dba_hist_sysmetric_summary m
        WHERE
            m.begin_time >= SYSDATE - 7
            AND m.metric_name IN ('Host CPU Utilization (%)', 'Database CPU Time Ratio')
        GROUP BY
            m.instance_number,
            TO_CHAR(m.begin_time, 'YYYY-MM-DD HH24')
    )
    SELECT 
        instance_number,
        hour_period,
        avg_cpu_pct,
        max_cpu_pct,
        avg_db_cpu_ratio,
        CASE 
            WHEN max_cpu_pct >= 90 THEN 'CRITICAL'
            WHEN max_cpu_pct >= 75 THEN 'WARNING'
            WHEN max_cpu_pct >= 60 THEN 'ELEVATED'
            ELSE 'NORMAL'
        END AS cpu_status
    FROM
        resource_metrics
    WHERE
        max_cpu_pct IS NOT NULL
    ORDER BY
        hour_period DESC
    """

#IO Review
def get_current_io_stats():
    return """
    -- Current I/O statistics from V$SYSSTAT
    SELECT 
        inst_id,
        stat_name,
        value,
        CASE 
            WHEN stat_name LIKE '%bytes%' THEN ROUND(value / (1024*1024*1024), 2) || ' GB'
            WHEN stat_name LIKE '%time%' THEN ROUND(value / 100, 2) || ' sec'
            ELSE TO_CHAR(value)
        END AS formatted_value
    FROM (
        SELECT 
            inst_id,
            name AS stat_name,
            value
        FROM 
            gv$sysstat
        WHERE 
            name IN (
                'physical reads',
                'physical reads direct',
                'physical read IO requests',
                'physical read bytes',
                'physical writes',
                'physical writes direct',
                'physical write IO requests',
                'physical write bytes',
                'physical read total IO requests',
                'physical write total IO requests',
                'physical read total bytes',
                'physical write total bytes',
                'db block gets',
                'consistent gets',
                'physical reads cache',
                'physical writes from cache'
            )
    )
    ORDER BY 
        inst_id,
        stat_name
    """

def get_datafile_io_stats():
    return """
    -- Datafile I/O statistics from V$FILESTAT
    SELECT 
        f.inst_id,
        d.tablespace_name,
        d.file_name,
        f.phyrds AS physical_reads,
        f.phywrts AS physical_writes,
        f.phyblkrd AS blocks_read,
        f.phyblkwrt AS blocks_written,
        ROUND(f.readtim * 10, 2) AS read_time_ms,
        ROUND(f.writetim * 10, 2) AS write_time_ms,
        ROUND(f.avgiotim * 10, 2) AS avg_io_time_ms,
        ROUND(f.maxiortm * 10, 2) AS max_read_time_ms,
        ROUND(f.maxiowtm * 10, 2) AS max_write_time_ms,
        ROUND(CASE WHEN f.phyrds > 0 THEN (f.readtim * 10) / f.phyrds ELSE 0 END, 2) AS avg_read_ms,
        ROUND(CASE WHEN f.phywrts > 0 THEN (f.writetim * 10) / f.phywrts ELSE 0 END, 2) AS avg_write_ms,
        f.lstiotim AS last_io_time
    FROM 
        gv$filestat f
        JOIN dba_data_files d ON f.file# = d.file_id
    WHERE 
        f.phyrds + f.phywrts > 0  -- Only files with I/O activity
    ORDER BY 
        f.phyrds + f.phywrts DESC
    """

def get_tempfile_io_stats():
    return """
    -- Tempfile I/O statistics from V$TEMPSTAT
    SELECT 
        t.inst_id,
        tf.tablespace_name,
        tf.file_name,
        t.phyrds AS physical_reads,
        t.phywrts AS physical_writes,
        t.phyblkrd AS blocks_read,
        t.phyblkwrt AS blocks_written,
        ROUND(t.readtim * 10, 2) AS read_time_ms,
        ROUND(t.writetim * 10, 2) AS write_time_ms,
        ROUND(t.avgiotim * 10, 2) AS avg_io_time_ms,
        ROUND(CASE WHEN t.phyrds > 0 THEN (t.readtim * 10) / t.phyrds ELSE 0 END, 2) AS avg_read_ms,
        ROUND(CASE WHEN t.phywrts > 0 THEN (t.writetim * 10) / t.phywrts ELSE 0 END, 2) AS avg_write_ms
    FROM 
        gv$tempstat t
        JOIN dba_temp_files tf ON t.file# = tf.file_id
    WHERE 
        t.phyrds + t.phywrts > 0  -- Only files with I/O activity
    ORDER BY 
        t.phyrds + t.phywrts DESC
    """

def get_io_function_metrics():
    return """
    -- I/O metrics by function from V$IOSTAT_FUNCTION
    SELECT 
        inst_id,
        function_name,
        -- Read metrics
        small_read_reqs,
        small_read_megabytes AS small_read_mb,
        large_read_reqs,
        large_read_megabytes AS large_read_mb,
        -- Write metrics
        small_write_reqs,
        small_write_megabytes AS small_write_mb,
        large_write_reqs,
        large_write_megabytes AS large_write_mb,
        -- Total metrics
        number_of_waits,
        wait_time AS wait_time_ms,
        -- Calculate averages
        ROUND(CASE 
            WHEN (small_read_reqs + large_read_reqs) > 0 
            THEN wait_time / (small_read_reqs + large_read_reqs) 
            ELSE 0 
        END, 2) AS avg_wait_per_read_ms,
        ROUND(CASE 
            WHEN (small_write_reqs + large_write_reqs) > 0 
            THEN wait_time / (small_write_reqs + large_write_reqs) 
            ELSE 0 
        END, 2) AS avg_wait_per_write_ms
    FROM 
        gv$iostat_function
    WHERE 
        small_read_reqs + large_read_reqs + small_write_reqs + large_write_reqs > 0
    ORDER BY 
        wait_time DESC
    """

def get_io_file_metrics():
    return """
    -- File-level I/O metrics from V$IOSTAT_FILE
    SELECT 
        i.inst_id,
        i.filetype_name,
        d.tablespace_name,
        d.file_name,
        -- Read metrics
        i.small_read_reqs,
        i.small_read_megabytes AS small_read_mb,
        i.large_read_reqs,
        i.large_read_megabytes AS large_read_mb,
        i.small_read_servicetime AS small_read_time_ms,
        i.large_read_servicetime AS large_read_time_ms,
        -- Write metrics
        i.small_write_reqs,
        i.small_write_megabytes AS small_write_mb,
        i.large_write_reqs,
        i.large_write_megabytes AS large_write_mb,
        i.small_write_servicetime AS small_write_time_ms,
        i.large_write_servicetime AS large_write_time_ms,
        -- Calculate latencies
        ROUND(CASE 
            WHEN i.small_read_reqs > 0 
            THEN i.small_read_servicetime / i.small_read_reqs 
            ELSE 0 
        END, 2) AS avg_small_read_latency_ms,
        ROUND(CASE 
            WHEN i.large_read_reqs > 0 
            THEN i.large_read_servicetime / i.large_read_reqs 
            ELSE 0 
        END, 2) AS avg_large_read_latency_ms,
        ROUND(CASE 
            WHEN i.small_write_reqs > 0 
            THEN i.small_write_servicetime / i.small_write_reqs 
            ELSE 0 
        END, 2) AS avg_small_write_latency_ms,
        ROUND(CASE 
            WHEN i.large_write_reqs > 0 
            THEN i.large_write_servicetime / i.large_write_reqs 
            ELSE 0 
        END, 2) AS avg_large_write_latency_ms
    FROM 
        gv$iostat_file i
        LEFT JOIN dba_data_files d ON i.file_no = d.file_id
    WHERE 
        i.small_read_reqs + i.large_read_reqs + i.small_write_reqs + i.large_write_reqs > 0
    ORDER BY 
        (i.small_read_reqs + i.large_read_reqs + i.small_write_reqs + i.large_write_reqs) DESC
    """

def get_segment_io_stats():
    return """
    -- Segment-level I/O statistics (top segments by I/O)
        SELECT * FROM (
        SELECT 
            owner,
            object_name,
            object_type,
            tablespace_name,
            SUM(CASE WHEN statistic_name = 'logical reads' THEN value ELSE 0 END) AS logical_reads,
            SUM(CASE WHEN statistic_name = 'physical reads' THEN value ELSE 0 END) AS physical_reads,
            SUM(CASE WHEN statistic_name = 'physical writes' THEN value ELSE 0 END) AS physical_writes,
            SUM(CASE WHEN statistic_name = 'physical reads direct' THEN value ELSE 0 END) AS physical_reads_direct,
            SUM(CASE WHEN statistic_name = 'physical writes direct' THEN value ELSE 0 END) AS physical_writes_direct,
            SUM(CASE WHEN statistic_name = 'buffer busy waits' THEN value ELSE 0 END) AS buffer_busy_waits,
            SUM(CASE WHEN statistic_name = 'row lock waits' THEN value ELSE 0 END) AS row_lock_waits,
            SUM(CASE WHEN statistic_name = 'gc buffer busy' THEN value ELSE 0 END) AS gc_buffer_busy,
            ROUND(100 * SUM(CASE WHEN statistic_name = 'physical reads' THEN value ELSE 0 END) / 
                NULLIF(SUM(CASE WHEN statistic_name = 'logical reads' THEN value ELSE 0 END), 0), 2) AS cache_miss_ratio
        FROM 
            gv$segment_statistics
        WHERE 
            owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
            AND statistic_name IN (
                'logical reads',
                'physical reads',
                'physical writes',
                'physical reads direct',
                'physical writes direct',
                'buffer busy waits',
                'row lock waits',
                'gc buffer busy'
            )
        GROUP BY 
            owner,
            object_name,
            object_type,
            tablespace_name
        HAVING 
            SUM(CASE WHEN statistic_name IN ('logical reads', 'physical reads', 'physical writes') THEN value ELSE 0 END) > 0
        ORDER BY 
            SUM(CASE WHEN statistic_name IN ('physical reads', 'physical writes') THEN value ELSE 0 END) DESC
    )
    WHERE ROWNUM <= 50  -- Top 50 segments by I/O
    """

def get_system_io_events():
    return """
    -- System I/O wait events and latencies
    SELECT 
        inst_id,
        event,
        total_waits,
        total_timeouts,
        time_waited AS time_waited_centisecs,
        ROUND(time_waited / 100, 2) AS time_waited_secs,
        average_wait AS avg_wait_centisecs,
        ROUND(average_wait * 10, 2) AS avg_wait_ms,
        ROUND(time_waited_micro / total_waits / 1000, 2) AS avg_wait_micro_ms,
        wait_class
    FROM 
        gv$system_event
    WHERE 
        wait_class IN ('User I/O', 'System I/O', 'Commit')
        AND total_waits > 0
    ORDER BY 
        time_waited DESC
    """

def get_historical_io_stats():
    return """
    -- Historical I/O statistics from AWR
    WITH io_stats AS (
        SELECT 
            s.instance_number,
            s.snap_id,
            s.begin_interval_time,
            s.end_interval_time,
            -- Calculate deltas
            st.value - LAG(st.value) OVER (
                PARTITION BY s.instance_number, st.stat_name 
                ORDER BY s.snap_id
            ) AS delta_value,
            st.stat_name
        FROM 
            dba_hist_sysstat st
            JOIN dba_hist_snapshot s ON st.snap_id = s.snap_id 
                AND st.dbid = s.dbid 
                AND st.instance_number = s.instance_number
        WHERE 
            s.begin_interval_time >= SYSDATE - 7
            AND st.stat_name IN (
                'physical reads',
                'physical writes',
                'physical read IO requests',
                'physical write IO requests',
                'physical read bytes',
                'physical write bytes',
                'db block gets',
                'consistent gets'
            )
    )
    SELECT 
        instance_number,
        TO_CHAR(begin_interval_time, 'YYYY-MM-DD HH24:MI') AS snapshot_time,
        TO_CHAR(end_interval_time, 'YYYY-MM-DD HH24:MI') AS snapshot_end_time,
        ROUND(EXTRACT(DAY FROM (end_interval_time - begin_interval_time)) * 24 * 60 + 
              EXTRACT(HOUR FROM (end_interval_time - begin_interval_time)) * 60 + 
              EXTRACT(MINUTE FROM (end_interval_time - begin_interval_time)) + 
              EXTRACT(SECOND FROM (end_interval_time - begin_interval_time)) / 60, 2) AS interval_mins,
        -- I/O counts
        SUM(CASE WHEN stat_name = 'physical reads' THEN delta_value END) AS physical_reads,
        SUM(CASE WHEN stat_name = 'physical writes' THEN delta_value END) AS physical_writes,
        SUM(CASE WHEN stat_name = 'physical read IO requests' THEN delta_value END) AS read_io_requests,
        SUM(CASE WHEN stat_name = 'physical write IO requests' THEN delta_value END) AS write_io_requests,
        -- I/O volume
        ROUND(SUM(CASE WHEN stat_name = 'physical read bytes' THEN delta_value END) / (1024*1024*1024), 2) AS read_gb,
        ROUND(SUM(CASE WHEN stat_name = 'physical write bytes' THEN delta_value END) / (1024*1024*1024), 2) AS write_gb,
        -- Buffer cache statistics
        SUM(CASE WHEN stat_name = 'db block gets' THEN delta_value END) AS db_block_gets,
        SUM(CASE WHEN stat_name = 'consistent gets' THEN delta_value END) AS consistent_gets,
        -- Calculate IOPS (using EXTRACT to get total seconds)
        ROUND(SUM(CASE WHEN stat_name = 'physical read IO requests' THEN delta_value END) / 
            NULLIF(EXTRACT(DAY FROM (end_interval_time - begin_interval_time)) * 86400 + 
                   EXTRACT(HOUR FROM (end_interval_time - begin_interval_time)) * 3600 + 
                   EXTRACT(MINUTE FROM (end_interval_time - begin_interval_time)) * 60 + 
                   EXTRACT(SECOND FROM (end_interval_time - begin_interval_time)), 0), 2) AS read_iops,
        ROUND(SUM(CASE WHEN stat_name = 'physical write IO requests' THEN delta_value END) / 
            NULLIF(EXTRACT(DAY FROM (end_interval_time - begin_interval_time)) * 86400 + 
                   EXTRACT(HOUR FROM (end_interval_time - begin_interval_time)) * 3600 + 
                   EXTRACT(MINUTE FROM (end_interval_time - begin_interval_time)) * 60 + 
                   EXTRACT(SECOND FROM (end_interval_time - begin_interval_time)), 0), 2) AS write_iops
    FROM 
        io_stats
    WHERE 
        delta_value >= 0  -- Filter out negative deltas from restarts
    GROUP BY 
        instance_number,
        begin_interval_time,
        end_interval_time
    ORDER BY 
        instance_number,
        begin_interval_time DESC
    """

def get_io_calibration_stats():
    return """
    -- I/O calibration statistics (if available)
    SELECT 
        inst_id,
        status,
        calibration_time,
        con_id
    FROM 
        gv$io_calibration_status
    """

def get_realtime_io_metrics():
    return """
    -- Real-time I/O metrics from V$SYSMETRIC
    SELECT 
        inst_id,
        metric_name,
        ROUND(value, 2) AS current_value,
        metric_unit,
        begin_time,
        end_time
    FROM 
        gv$sysmetric
    WHERE 
        metric_name IN (
            'Physical Read Total IO Requests Per Sec',
            'Physical Write Total IO Requests Per Sec',
            'Physical Read Total Bytes Per Sec',
            'Physical Write Total Bytes Per Sec',
            'Physical Read IO Requests Per Sec',
            'Physical Write IO Requests Per Sec',
            'Physical Read Bytes Per Sec',
            'Physical Write Bytes Per Sec',
            'Average Synchronous Single-Block Read Latency',
            'I/O Megabytes per Second',
            'I/O Requests per Second',
            'Average Active Sessions',
            'Database Wait Time Ratio'
        )
        AND group_id = 2  -- 60-second interval
    ORDER BY 
        inst_id,
        metric_name
    """

def get_io_wait_histogram():
    return """
    -- I/O wait time histogram
    SELECT 
        inst_id,
        wait_time_milli,
        wait_count,
        SUM(wait_count) OVER (
            PARTITION BY inst_id 
            ORDER BY wait_time_milli
        ) AS cumulative_count,
        ROUND(100 * RATIO_TO_REPORT(wait_count) OVER (PARTITION BY inst_id), 2) AS pct_of_waits,
        ROUND(100 * SUM(wait_count) OVER (
            PARTITION BY inst_id 
            ORDER BY wait_time_milli
        ) / SUM(wait_count) OVER (PARTITION BY inst_id), 2) AS cumulative_pct
    FROM 
        gv$event_histogram
    WHERE 
        event = 'db file sequential read'  -- Single block reads
    ORDER BY 
        inst_id,
        wait_time_milli
    """

def get_tablespace_io_stats():
    return """
    -- Tablespace I/O statistics
    SELECT 
        s.inst_id,
        f.tablespace_name,
        COUNT(DISTINCT f.file_id) AS file_count,
        SUM(s.phyrds) AS total_reads,
        SUM(s.phywrts) AS total_writes,
        SUM(s.phyblkrd) AS blocks_read,
        SUM(s.phyblkwrt) AS blocks_written,
        ROUND(SUM(s.readtim) * 10, 2) AS total_read_time_ms,
        ROUND(SUM(s.writetim) * 10, 2) AS total_write_time_ms,
        ROUND(AVG(CASE WHEN s.phyrds > 0 THEN (s.readtim * 10) / s.phyrds END), 2) AS avg_read_ms,
        ROUND(AVG(CASE WHEN s.phywrts > 0 THEN (s.writetim * 10) / s.phywrts END), 2) AS avg_write_ms,
        ROUND(SUM(f.bytes) / (1024*1024*1024), 2) AS tablespace_size_gb
    FROM 
        dba_data_files f
        JOIN gv$filestat s ON f.file_id = s.file#
    GROUP BY 
        s.inst_id,
        f.tablespace_name
    ORDER BY 
        SUM(s.phyrds + s.phywrts) DESC
    """

#Session Concurrency patterns
def get_current_session_summary():
    return """
    -- Current session summary by status and type
    SELECT 
        inst_id,
        status,
        type AS session_type,
        server,
        COUNT(*) AS session_count,
        COUNT(DISTINCT username) AS distinct_users,
        COUNT(DISTINCT machine) AS distinct_machines,
        COUNT(DISTINCT program) AS distinct_programs,
        COUNT(CASE WHEN blocking_session IS NOT NULL THEN 1 END) AS blocked_sessions,
        COUNT(DISTINCT sql_id) AS distinct_sql_ids,
        ROUND(AVG(last_call_et)/60, 2) AS avg_idle_time_mins,
        MAX(last_call_et)/60 AS max_idle_time_mins
    FROM 
        gv$session
    WHERE 
        type = 'USER'  -- Focus on user sessions
    GROUP BY 
        inst_id,
        status,
        type,
        server
    ORDER BY 
        inst_id,
        session_count DESC
    """

def get_session_concurrency_by_time():
    return """
    -- Session concurrency patterns over time from AWR
    SELECT
        m.instance_number,
        TO_CHAR(m.begin_time, 'YYYY-MM-DD HH24:MI') AS snapshot_time,
        TO_CHAR(m.begin_time, 'DY') AS day_of_week,
        TO_CHAR(m.begin_time, 'HH24') AS hour_of_day,
        m.average AS avg_active_sessions,
        m.maxval AS max_active_sessions,
        m.minval AS min_active_sessions,
        m.standard_deviation AS stddev_active_sessions,
        ROUND(m.maxval - m.average, 2) AS peak_above_avg
    FROM
        dba_hist_sysmetric_summary m
    WHERE
        m.begin_time >= SYSDATE - 7
        AND m.metric_name = 'Average Active Sessions'
    ORDER BY
        m.instance_number,
        m.begin_time DESC
    """

def get_concurrent_session_statistics():
    return """
    -- Concurrent session statistics by wait class
    SELECT 
        inst_id,
        wait_class,
        state,
        COUNT(*) AS session_count,
        COUNT(DISTINCT username) AS distinct_users,
        COUNT(DISTINCT sql_id) AS distinct_sql,
        COUNT(DISTINCT event) AS distinct_events,
        ROUND(AVG(wait_time_micro/1000000), 2) AS avg_wait_secs,
        ROUND(MAX(wait_time_micro/1000000), 2) AS max_wait_secs,
        ROUND(AVG(time_since_last_wait_micro/1000000), 2) AS avg_time_since_wait_secs
    FROM 
        gv$session
    WHERE 
        type = 'USER'
        AND username IS NOT NULL
    GROUP BY 
        inst_id,
        wait_class,
        state
    ORDER BY 
        inst_id,
        session_count DESC
    """

def get_blocking_session_chains():
    return """
    -- Blocking session chains and concurrency issues
    WITH blocking_tree AS (
        SELECT 
            LEVEL AS blocking_level,
            inst_id,
            sid,
            serial#,
            username,
            blocking_session,
            blocking_instance,
            blocking_session_status,
            status,
            event,
            wait_class,
            seconds_in_wait,
            sql_id,
            prev_sql_id,
            machine,
            program,
            CONNECT_BY_ROOT sid AS root_blocker_sid,
            CONNECT_BY_ROOT inst_id AS root_blocker_inst,
            SYS_CONNECT_BY_PATH(sid || '@' || inst_id, ' <- ') AS blocking_chain
        FROM 
            gv$session
        WHERE 
            blocking_session IS NOT NULL OR sid IN (
                SELECT DISTINCT blocking_session 
                FROM gv$session 
                WHERE blocking_session IS NOT NULL
            )
        START WITH 
            blocking_session IS NULL 
            AND sid IN (
                SELECT DISTINCT blocking_session 
                FROM gv$session 
                WHERE blocking_session IS NOT NULL
            )
        CONNECT BY 
            PRIOR sid = blocking_session 
            AND PRIOR inst_id = blocking_instance
    )
    SELECT 
        blocking_level,
        inst_id,
        sid,
        serial#,
        username,
        status,
        event,
        wait_class,
        seconds_in_wait,
        sql_id,
        machine,
        program,
        blocking_chain,
        root_blocker_sid || '@' || root_blocker_inst AS root_blocker
    FROM 
        blocking_tree
    ORDER BY 
        root_blocker_inst,
        root_blocker_sid,
        blocking_level
    """

def get_session_concurrency_by_module():
    return """
    -- Session concurrency patterns by module/action
    SELECT 
        inst_id,
        module,
        action,
        COUNT(*) AS session_count,
        COUNT(DISTINCT username) AS distinct_users,
        COUNT(CASE WHEN status = 'ACTIVE' THEN 1 END) AS active_sessions,
        COUNT(CASE WHEN status = 'INACTIVE' THEN 1 END) AS inactive_sessions,
        COUNT(CASE WHEN blocking_session IS NOT NULL THEN 1 END) AS blocked_sessions,
        COUNT(DISTINCT sql_id) AS distinct_sql_ids,
        COUNT(DISTINCT wait_class) AS distinct_wait_classes,
        ROUND(AVG(CASE WHEN status = 'ACTIVE' THEN last_call_et END), 2) AS avg_active_time_secs
        --LISTAGG(DISTINCT wait_class, ', ') WITHIN GROUP (ORDER BY wait_class) AS wait_classes
    FROM 
        gv$session
    WHERE 
        type = 'USER'
        AND module IS NOT NULL
    GROUP BY 
        inst_id,
        module,
        action
    HAVING 
        COUNT(*) > 1  -- Only show modules with concurrent sessions
    ORDER BY 
        session_count DESC
    """

def get_session_concurrency_by_service():
    return """
    -- Session concurrency patterns by service name
    SELECT 
        inst_id,
        service_name,
        COUNT(*) AS total_sessions,
        COUNT(CASE WHEN status = 'ACTIVE' THEN 1 END) AS active_sessions,
        COUNT(CASE WHEN status = 'INACTIVE' THEN 1 END) AS inactive_sessions,
        COUNT(DISTINCT username) AS distinct_users,
        COUNT(DISTINCT machine) AS distinct_machines,
        COUNT(DISTINCT program) AS distinct_programs,
        COUNT(CASE WHEN blocking_session IS NOT NULL THEN 1 END) AS blocked_sessions,
        COUNT(DISTINCT sql_id) AS unique_sql_statements,
        ROUND(AVG(CASE WHEN status = 'ACTIVE' THEN last_call_et END), 2) AS avg_active_duration_secs,
        MAX(CASE WHEN status = 'ACTIVE' THEN last_call_et END) AS max_active_duration_secs
    FROM 
        gv$session
    WHERE 
        type = 'USER'
        AND service_name IS NOT NULL
    GROUP BY 
        inst_id,
        service_name
    ORDER BY 
        total_sessions DESC
    """

def get_historical_concurrency_peaks():
    return """
    -- Historical concurrency peaks and patterns
    WITH concurrency_stats AS (
        SELECT 
            ash.instance_number,
            TO_CHAR(ash.sample_time, 'YYYY-MM-DD HH24') AS sample_hour,
            TO_CHAR(ash.sample_time, 'DY') AS day_of_week,
            TO_CHAR(ash.sample_time, 'HH24') AS hour_of_day,
            COUNT(DISTINCT ash.session_id || '-' || ash.session_serial#) AS concurrent_sessions,
            COUNT(DISTINCT CASE WHEN ash.session_state = 'ON CPU' THEN 
                ash.session_id || '-' || ash.session_serial# END) AS sessions_on_cpu,
            COUNT(DISTINCT CASE WHEN ash.session_state = 'WAITING' THEN 
                ash.session_id || '-' || ash.session_serial# END) AS sessions_waiting,
            COUNT(DISTINCT ash.sql_id) AS distinct_sql,
            COUNT(DISTINCT ash.blocking_session) AS blocking_sessions,
            COUNT(DISTINCT ash.event) AS distinct_wait_events
        FROM 
            dba_hist_active_sess_history ash
        WHERE 
            ash.sample_time >= SYSDATE - 7
            AND ash.user_id > 0  -- Exclude SYS operations
        GROUP BY 
            ash.instance_number,
            TO_CHAR(ash.sample_time, 'YYYY-MM-DD HH24'),
            TO_CHAR(ash.sample_time, 'DY'),
            TO_CHAR(ash.sample_time, 'HH24')
    )
    SELECT 
        instance_number,
        sample_hour,
        day_of_week,
        hour_of_day,
        concurrent_sessions,
        sessions_on_cpu,
        sessions_waiting,
        distinct_sql,
        blocking_sessions,
        distinct_wait_events,
        ROUND(100 * sessions_on_cpu / NULLIF(concurrent_sessions, 0), 2) AS pct_on_cpu,
        ROUND(100 * sessions_waiting / NULLIF(concurrent_sessions, 0), 2) AS pct_waiting
    FROM 
        concurrency_stats
    ORDER BY 
        concurrent_sessions DESC
    FETCH FIRST 100 ROWS ONLY
    """

def get_parallel_execution_concurrency():
    return """
    -- Parallel execution concurrency patterns
    SELECT 
        px.inst_id,
        px.qcsid AS coordinator_sid,
        px.qcinst_id AS coordinator_inst,
        px.server_group,
        px.server_set,
        px.server# AS server_number,
        px.degree,
        px.req_degree AS requested_degree,
        COUNT(*) AS parallel_servers,
        COUNT(DISTINCT px.sid) AS distinct_sessions,
        COUNT(CASE WHEN s.wait_class != 'Idle' THEN 1 END) AS active_servers,
        COUNT(CASE WHEN s.status = 'ACTIVE' THEN 1 END) AS active_sessions,
        --LISTAGG(DISTINCT s.wait_class, ', ') WITHIN GROUP (ORDER BY s.wait_class) AS wait_classes,
        --LISTAGG(DISTINCT s.event, ', ') WITHIN GROUP (ORDER BY s.event) AS wait_events,
        MIN(px.sid) AS min_slave_sid,
        MAX(px.sid) AS max_slave_sid
    FROM 
        gv$px_session px
        LEFT JOIN gv$session s ON px.inst_id = s.inst_id AND px.sid = s.sid
    WHERE 
        px.qcsid IS NOT NULL
    GROUP BY 
        px.inst_id,
        px.qcsid,
        px.qcinst_id,
        px.server_group,
        px.server_set,
        px.server#,
        px.degree,
        px.req_degree
    ORDER BY 
        parallel_servers DESC
    """

def get_resource_limit_concurrency():
    return """
    -- Resource limit and concurrency constraints
SELECT 
    inst_id,
    resource_name,
    current_utilization,
    max_utilization,
    initial_allocation,
    limit_value,
    CASE 
        WHEN TO_NUMBER(limit_value DEFAULT NULL ON CONVERSION ERROR) IS NULL THEN NULL
        ELSE ROUND(100 * current_utilization / TO_NUMBER(limit_value DEFAULT NULL ON CONVERSION ERROR), 2)
    END AS current_pct_of_limit,
    CASE 
        WHEN TO_NUMBER(limit_value DEFAULT NULL ON CONVERSION ERROR) IS NULL THEN NULL
        ELSE ROUND(100 * max_utilization / TO_NUMBER(limit_value DEFAULT NULL ON CONVERSION ERROR), 2)
    END AS max_pct_of_limit,
    CASE 
        WHEN TO_NUMBER(limit_value DEFAULT NULL ON CONVERSION ERROR) IS NULL THEN 'UNLIMITED'
        WHEN current_utilization / TO_NUMBER(limit_value DEFAULT 1 ON CONVERSION ERROR) > 0.9 THEN 'CRITICAL'
        WHEN current_utilization / TO_NUMBER(limit_value DEFAULT 1 ON CONVERSION ERROR) > 0.75 THEN 'WARNING'
        WHEN current_utilization / TO_NUMBER(limit_value DEFAULT 1 ON CONVERSION ERROR) > 0.5 THEN 'MODERATE'
        ELSE 'NORMAL'
    END AS utilization_status
FROM 
    gv$resource_limit
WHERE 
    resource_name IN (
        'processes',
        'sessions',
        'parallel_max_servers',
        'transactions',
        'dml_locks',
        'enqueue_locks',
        'enqueue_resources'
    )
ORDER BY 
    inst_id,
    current_pct_of_limit DESC NULLS LAST
    """

def get_session_wait_concurrency():
    return """
    -- Session wait concurrency analysis
    SELECT 
        inst_id,
        event,
        wait_class,
        COUNT(*) AS waiting_sessions,
        COUNT(DISTINCT username) AS distinct_users,
        COUNT(DISTINCT sql_id) AS distinct_sql,
        ROUND(AVG(seconds_in_wait), 2) AS avg_wait_time_secs,
        ROUND(MAX(seconds_in_wait), 2) AS max_wait_time_secs,
        ROUND(PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY seconds_in_wait), 2) AS median_wait_secs,
        ROUND(PERCENTILE_CONT(0.95) WITHIN GROUP (ORDER BY seconds_in_wait), 2) AS p95_wait_secs
        --LISTAGG(DISTINCT state, ', ') WITHIN GROUP (ORDER BY state) AS session_states
    FROM 
        gv$session
    WHERE 
        wait_class != 'Idle'
        AND event IS NOT NULL
        AND type = 'USER'
    GROUP BY 
        inst_id,
        event,
        wait_class
    HAVING 
        COUNT(*) > 1  -- Only show events with concurrent waiters
    ORDER BY 
        waiting_sessions DESC
    """

def get_logon_storm_detection():
    return """
    -- Detect logon storms and connection spikes
    WITH logon_stats AS (
        SELECT 
            inst_id,
            username,
            machine,
            program,
            TO_CHAR(logon_time, 'YYYY-MM-DD HH24:MI') AS logon_minute,
            COUNT(*) AS logon_count,
            COUNT(DISTINCT osuser) AS distinct_os_users,
            MIN(logon_time) AS first_logon,
            MAX(logon_time) AS last_logon,
            ROUND((MAX(logon_time) - MIN(logon_time)) * 24 * 60 * 60, 2) AS logon_spread_secs
        FROM 
            gv$session
        WHERE 
            logon_time >= SYSDATE - INTERVAL '1' HOUR
            AND type = 'USER'
        GROUP BY 
            inst_id,
            username,
            machine,
            program,
            TO_CHAR(logon_time, 'YYYY-MM-DD HH24:MI')
        HAVING 
            COUNT(*) > 5  -- More than 5 logons in the same minute
    )
    SELECT 
        inst_id,
        logon_minute,
        username,
        machine,
        program,
        logon_count,
        distinct_os_users,
        logon_spread_secs,
        CASE 
            WHEN logon_count > 50 THEN 'SEVERE STORM'
            WHEN logon_count > 20 THEN 'MODERATE STORM'
            WHEN logon_count > 10 THEN 'MINOR SPIKE'
            ELSE 'ELEVATED'
        END AS logon_pattern
    FROM 
        logon_stats
    ORDER BY 
        logon_count DESC,
        logon_minute DESC
    """

def get_session_concurrency_heatmap():
    return """
    -- Session concurrency heatmap by hour and day
    WITH hourly_stats AS (
        SELECT
            m.instance_number,
            TO_CHAR(m.begin_time, 'DY') AS day_of_week,
            TO_NUMBER(TO_CHAR(m.begin_time, 'D')) AS day_number,
            TO_NUMBER(TO_CHAR(m.begin_time, 'HH24')) AS hour_of_day,
            AVG(m.average) AS avg_active_sessions,
            MAX(m.maxval) AS max_active_sessions
        FROM
            dba_hist_sysmetric_summary m
        WHERE
            m.begin_time >= SYSDATE - 30
            AND m.metric_name = 'Average Active Sessions'
        GROUP BY
            m.instance_number,
            TO_CHAR(m.begin_time, 'DY'),
            TO_NUMBER(TO_CHAR(m.begin_time, 'D')),
            TO_NUMBER(TO_CHAR(m.begin_time, 'HH24'))
    )
    SELECT 
        instance_number,
        day_of_week,
        hour_of_day,
        ROUND(avg_active_sessions, 2) AS avg_sessions,
        ROUND(max_active_sessions, 2) AS peak_sessions,
        LPAD(RPAD('█', ROUND(avg_active_sessions), '█'), 20, ' ') AS activity_bar,
        CASE 
            WHEN avg_active_sessions >= 10 THEN 'HIGH'
            WHEN avg_active_sessions >= 5 THEN 'MEDIUM'
            WHEN avg_active_sessions >= 2 THEN 'LOW'
            ELSE 'MINIMAL'
        END AS activity_level
    FROM 
        hourly_stats
    ORDER BY 
        instance_number,
        day_number,
        hour_of_day
    """

#Transaction Volumn Analysis
def get_current_transaction_metrics():
    return """
    -- Current transaction metrics from V$SYSMETRIC
    SELECT 
        inst_id,
        metric_name,
        ROUND(value, 2) AS current_value,
        metric_unit,
        begin_time,
        end_time
    FROM 
        gv$sysmetric
    WHERE 
        metric_name IN (
            'User Transaction Per Sec',
            'User Commits Per Sec',
            'User Rollbacks Per Sec',
            'User Calls Per Sec',
            'Recursive Calls Per Sec',
            'Execute Count Per Sec',
            'Parse Count (Total) Per Sec',
            'Parse Count (Hard) Per Sec',
            'Logical Reads Per Sec',
            'Physical Reads Per Sec',
            'Physical Writes Per Sec',
            'Redo Generated Per Sec',
            'DB Block Changes Per Sec'
        )
        AND group_id = 2  -- 60-second interval
    ORDER BY 
        inst_id,
        metric_name
    """

def get_transaction_summary_stats():
    return """
    -- Transaction summary statistics
    SELECT 
        inst_id,
        SUM(CASE WHEN name = 'user commits' THEN value END) AS total_commits,
        SUM(CASE WHEN name = 'user rollbacks' THEN value END) AS total_rollbacks,
        SUM(CASE WHEN name = 'transaction rollbacks' THEN value END) AS transaction_rollbacks,
        SUM(CASE WHEN name = 'execute count' THEN value END) AS total_executions,
        SUM(CASE WHEN name = 'parse count (total)' THEN value END) AS total_parses,
        SUM(CASE WHEN name = 'parse count (hard)' THEN value END) AS hard_parses,
        SUM(CASE WHEN name = 'user calls' THEN value END) AS user_calls,
        SUM(CASE WHEN name = 'recursive calls' THEN value END) AS recursive_calls,
        ROUND(100 * SUM(CASE WHEN name = 'user rollbacks' THEN value END) / 
            NULLIF(SUM(CASE WHEN name IN ('user commits', 'user rollbacks') THEN value END), 0), 2) AS rollback_ratio,
        ROUND(100 * SUM(CASE WHEN name = 'parse count (hard)' THEN value END) / 
            NULLIF(SUM(CASE WHEN name = 'parse count (total)' THEN value END), 0), 2) AS hard_parse_ratio
    FROM 
        gv$sysstat
    WHERE 
        name IN (
            'user commits',
            'user rollbacks',
            'transaction rollbacks',
            'execute count',
            'parse count (total)',
            'parse count (hard)',
            'user calls',
            'recursive calls'
        )
    GROUP BY 
        inst_id
    ORDER BY 
        inst_id
    """

def get_active_transaction_details():
    return """
    -- Active transaction details
    SELECT 
        t.inst_id,
        t.addr AS transaction_address,
        t.xidusn AS undo_segment_number,
        t.xidslot AS undo_slot,
        t.xidsqn AS sequence_number,
        t.status AS transaction_status,
        t.start_time,
        t.start_scn,
        s.sid,
        s.serial#,
        s.username,
        s.program,
        s.machine,
        s.sql_id,
        t.used_ublk AS undo_blocks_used,
        t.used_urec AS undo_records,
        t.log_io AS redo_entries,
        t.phy_io AS physical_io,
        t.cr_get AS consistent_gets,
        t.cr_change AS consistent_changes,
        ROUND((SYSDATE - TO_DATE(t.start_time, 'MM/DD/YY HH24:MI:SS')) * 24 * 60, 2) AS duration_minutes,
        t.recursive AS is_recursive,
        t.space AS space_transactions,
        t.flag
    FROM 
        gv$transaction t
        JOIN gv$session s ON t.inst_id = s.inst_id 
            AND t.ses_addr = s.saddr
    ORDER BY 
        t.start_scn
    """

def get_transaction_volume_by_hour():
    return """
    -- Historical transaction volume by hour from AWR
    WITH trans_stats AS (
        SELECT 
            s.instance_number,
            s.snap_id,
            s.begin_interval_time,
            s.end_interval_time,
            st.stat_name,
            st.value - LAG(st.value) OVER (
                PARTITION BY s.instance_number, st.stat_name 
                ORDER BY s.snap_id
            ) AS delta_value
        FROM 
            dba_hist_sysstat st
            JOIN dba_hist_snapshot s ON st.snap_id = s.snap_id 
                AND st.dbid = s.dbid 
                AND st.instance_number = s.instance_number
        WHERE 
            s.begin_interval_time >= SYSDATE - 7
            AND st.stat_name IN (
                'user commits',
                'user rollbacks',
                'execute count',
                'user calls',
                'parse count (total)',
                'parse count (hard)',
                'redo entries',
                'db block changes'
            )
    )
    SELECT 
        instance_number,
        TO_CHAR(begin_interval_time, 'YYYY-MM-DD HH24') AS hour_period,
        TO_CHAR(begin_interval_time, 'DY') AS day_of_week,
        SUM(CASE WHEN stat_name = 'user commits' THEN delta_value END) AS commits,
        SUM(CASE WHEN stat_name = 'user rollbacks' THEN delta_value END) AS rollbacks,
        SUM(CASE WHEN stat_name = 'execute count' THEN delta_value END) AS executions,
        SUM(CASE WHEN stat_name = 'user calls' THEN delta_value END) AS user_calls,
        SUM(CASE WHEN stat_name = 'parse count (total)' THEN delta_value END) AS total_parses,
        SUM(CASE WHEN stat_name = 'parse count (hard)' THEN delta_value END) AS hard_parses,
        SUM(CASE WHEN stat_name = 'redo entries' THEN delta_value END) AS redo_entries,
        SUM(CASE WHEN stat_name = 'db block changes' THEN delta_value END) AS block_changes,
        -- Calculate rates per second
        ROUND(SUM(CASE WHEN stat_name = 'user commits' THEN delta_value END) / 
            NULLIF(EXTRACT(DAY FROM (end_interval_time - begin_interval_time)) * 86400 + 
                   EXTRACT(HOUR FROM (end_interval_time - begin_interval_time)) * 3600 + 
                   EXTRACT(MINUTE FROM (end_interval_time - begin_interval_time)) * 60 + 
                   EXTRACT(SECOND FROM (end_interval_time - begin_interval_time)), 0), 2) AS commits_per_sec,
        ROUND(SUM(CASE WHEN stat_name = 'execute count' THEN delta_value END) / 
            NULLIF(EXTRACT(DAY FROM (end_interval_time - begin_interval_time)) * 86400 + 
                   EXTRACT(HOUR FROM (end_interval_time - begin_interval_time)) * 3600 + 
                   EXTRACT(MINUTE FROM (end_interval_time - begin_interval_time)) * 60 + 
                   EXTRACT(SECOND FROM (end_interval_time - begin_interval_time)), 0), 2) AS executions_per_sec
    FROM 
        trans_stats
    WHERE 
        delta_value >= 0  -- Filter out negative deltas from restarts
    GROUP BY 
        instance_number,
        begin_interval_time,
        end_interval_time
    ORDER BY 
        instance_number,
        begin_interval_time DESC
    """

def get_transaction_volume_by_service():
    return """
    -- Transaction volume by service name
    SELECT 
        serv.inst_id,
        serv.service_name,
        serv.stat_name,
        serv.value AS total_value,
        ROUND(serv.value / NULLIF(
            (SELECT MAX(value) FROM gv$sys_time_model 
             WHERE stat_name = 'DB time' AND inst_id = serv.inst_id) / 1000000, 0), 2) AS per_db_second,
        ROUND(100 * serv.value / NULLIF(
            SUM(serv.value) OVER (PARTITION BY serv.inst_id, serv.stat_name), 0), 2) AS pct_of_total
    FROM 
        gv$service_stats serv
    WHERE 
        serv.stat_name IN (
            'user commits',
            'user rollbacks',
            'execute count',
            'parse count (total)',
            'user calls',
            'db block changes',
            'physical reads',
            'physical writes'
        )
        AND serv.service_name NOT IN ('SYS$BACKGROUND', 'SYS$USERS')
    ORDER BY 
        serv.inst_id,
        serv.service_name,
        serv.stat_name
    """

def get_transaction_redo_analysis():
    return """
    -- Transaction redo generation analysis
    SELECT 
        inst_id,
        -- Redo statistics
        SUM(CASE WHEN name = 'redo entries' THEN value END) AS redo_entries,
        SUM(CASE WHEN name = 'redo size' THEN value END) AS redo_size_bytes,
        ROUND(SUM(CASE WHEN name = 'redo size' THEN value END) / (1024*1024), 2) AS redo_size_mb,
        ROUND(SUM(CASE WHEN name = 'redo size' THEN value END) / (1024*1024*1024), 2) AS redo_size_gb,
        -- Redo write statistics
        SUM(CASE WHEN name = 'redo writes' THEN value END) AS redo_writes,
        SUM(CASE WHEN name = 'redo write time' THEN value END) AS redo_write_time_cs,
        ROUND(SUM(CASE WHEN name = 'redo write time' THEN value END) / 100, 2) AS redo_write_time_sec,
        -- Redo efficiency
        SUM(CASE WHEN name = 'redo log space requests' THEN value END) AS log_space_requests,
        SUM(CASE WHEN name = 'redo log space wait time' THEN value END) AS log_space_wait_time_cs,
        SUM(CASE WHEN name = 'redo buffer allocation retries' THEN value END) AS buffer_allocation_retries,
        -- Average calculations
        ROUND(SUM(CASE WHEN name = 'redo size' THEN value END) / 
            NULLIF(SUM(CASE WHEN name = 'user commits' THEN value END), 0), 2) AS avg_redo_per_commit,
        ROUND(SUM(CASE WHEN name = 'redo size' THEN value END) / 
            NULLIF(SUM(CASE WHEN name = 'redo entries' THEN value END), 0), 2) AS avg_bytes_per_entry
    FROM 
        gv$sysstat
    WHERE 
        name IN (
            'redo entries',
            'redo size',
            'redo writes',
            'redo write time',
            'redo log space requests',
            'redo log space wait time',
            'redo buffer allocation retries',
            'user commits'
        )
    GROUP BY 
        inst_id
    ORDER BY 
        inst_id
    """

def get_transaction_lock_statistics():
    return """
    -- Transaction lock and contention statistics
    SELECT 
        l.inst_id,
        l.type AS lock_type,
        DECODE(l.type,
            'TM', 'DML (Table)',
            'TX', 'Transaction',
            'UL', 'User Lock',
            'CF', 'Control File',
            'CI', 'Cross-Instance',
            'CU', 'Cursor Bind',
            'DL', 'Direct Loader',
            'DF', 'Data File',
            'IN', 'Instance Number',
            'IR', 'Instance Recovery',
            'IS', 'Instance State',
            'IV', 'Library Cache Invalidation',
            'LS', 'Log Start or Switch',
            'RW', 'Row Wait',
            'SQ', 'Sequence Number',
            'TE', 'Extend Table',
            'TT', 'Temp Table',
            l.type
        ) AS lock_description,
        COUNT(*) AS lock_count,
        COUNT(DISTINCT l.id1 || '-' || l.id2) AS distinct_objects,
        COUNT(CASE WHEN l.lmode = 0 THEN 1 END) AS none_mode,
        COUNT(CASE WHEN l.lmode = 1 THEN 1 END) AS null_mode,
        COUNT(CASE WHEN l.lmode = 2 THEN 1 END) AS row_share,
        COUNT(CASE WHEN l.lmode = 3 THEN 1 END) AS row_exclusive,
        COUNT(CASE WHEN l.lmode = 4 THEN 1 END) AS share_mode,
        COUNT(CASE WHEN l.lmode = 5 THEN 1 END) AS share_row_exclusive,
        COUNT(CASE WHEN l.lmode = 6 THEN 1 END) AS exclusive_mode,
        COUNT(CASE WHEN l.request > 0 THEN 1 END) AS waiting_locks,
        COUNT(CASE WHEN l.block = 1 THEN 1 END) AS blocking_locks
    FROM 
        gv$lock l
    GROUP BY 
        l.inst_id,
        l.type
    ORDER BY 
        lock_count DESC
    """

def get_transaction_performance_by_program():
    return """
    -- Transaction performance by application/program
    WITH session_stats AS (
        SELECT 
            s.inst_id,
            s.program,
            s.module,
            COUNT(DISTINCT s.sid) AS session_count,
            SUM(st.value) AS stat_value,
            n.name AS stat_name
        FROM 
            gv$session s
            JOIN gv$sesstat st ON s.inst_id = st.inst_id AND s.sid = st.sid
            JOIN v$statname n ON st.statistic# = n.statistic#
        WHERE 
            s.type = 'USER'
            AND s.username IS NOT NULL
            AND n.name IN (
                'user commits',
                'user rollbacks',
                'execute count',
                'parse count (total)',
                'session logical reads',
                'physical reads',
                'redo entries'
            )
        GROUP BY 
            s.inst_id,
            s.program,
            s.module,
            n.name
    )
    SELECT 
        inst_id,
        program,
        module,
        MAX(session_count) AS active_sessions,
        SUM(CASE WHEN stat_name = 'user commits' THEN stat_value END) AS total_commits,
        SUM(CASE WHEN stat_name = 'user rollbacks' THEN stat_value END) AS total_rollbacks,
        SUM(CASE WHEN stat_name = 'execute count' THEN stat_value END) AS total_executions,
        SUM(CASE WHEN stat_name = 'parse count (total)' THEN stat_value END) AS total_parses,
        SUM(CASE WHEN stat_name = 'session logical reads' THEN stat_value END) AS logical_reads,
        SUM(CASE WHEN stat_name = 'physical reads' THEN stat_value END) AS physical_reads,
        SUM(CASE WHEN stat_name = 'redo entries' THEN stat_value END) AS redo_entries
    FROM 
        session_stats
    GROUP BY 
        inst_id,
        program,
        module
    HAVING 
        SUM(CASE WHEN stat_name = 'user commits' THEN stat_value END) > 0
    ORDER BY 
        total_commits DESC
    """

def get_transaction_trending_daily():
    return """
    -- Daily transaction trending and patterns
    WITH delta_stats AS (
        SELECT 
            s.instance_number,
            s.snap_id,
            s.begin_interval_time,
            TRUNC(s.begin_interval_time) AS day_date,
            TO_CHAR(s.begin_interval_time, 'DY') AS day_name,
            st.stat_name,
            st.value,
            st.value - LAG(st.value, 1, st.value) OVER (
                PARTITION BY s.instance_number, st.stat_name 
                ORDER BY s.snap_id
            ) AS delta_value
        FROM 
            dba_hist_sysstat st
            JOIN dba_hist_snapshot s ON st.snap_id = s.snap_id 
                AND st.dbid = s.dbid 
                AND st.instance_number = s.instance_number
        WHERE 
            s.begin_interval_time >= SYSDATE - 30
            AND st.stat_name IN (
                'user commits',
                'user rollbacks',
                'execute count',
                'user calls',
                'redo size'
            )
    ),
    daily_stats AS (
        SELECT 
            instance_number,
            day_date,
            day_name,
            stat_name,
            SUM(CASE WHEN delta_value >= 0 THEN delta_value ELSE 0 END) AS total_value
        FROM 
            delta_stats
        GROUP BY 
            instance_number,
            day_date,
            day_name,
            stat_name
    )
    SELECT 
        instance_number,
        day_date,
        day_name,
        SUM(CASE WHEN stat_name = 'user commits' THEN total_value END) AS daily_commits,
        SUM(CASE WHEN stat_name = 'user rollbacks' THEN total_value END) AS daily_rollbacks,
        SUM(CASE WHEN stat_name = 'execute count' THEN total_value END) AS daily_executions,
        SUM(CASE WHEN stat_name = 'user calls' THEN total_value END) AS daily_calls,
        ROUND(SUM(CASE WHEN stat_name = 'redo size' THEN total_value END) / (1024*1024*1024), 2) AS daily_redo_gb,
        ROUND(100 * SUM(CASE WHEN stat_name = 'user rollbacks' THEN total_value END) / 
            NULLIF(SUM(CASE WHEN stat_name IN ('user commits', 'user rollbacks') THEN total_value END), 0), 2) AS rollback_pct
    FROM 
        daily_stats
    GROUP BY 
        instance_number,
        day_date,
        day_name
    ORDER BY 
        instance_number,
        day_date DESC
    """

def get_long_running_transactions():
    return """
    -- Long-running transactions analysis
    SELECT 
        t.inst_id,
        t.start_time,
        t.xid AS transaction_id,
        s.sid,
        s.serial#,
        s.username,
        s.program,
        s.machine,
        s.status AS session_status,
        s.sql_id AS current_sql_id,
        s.prev_sql_id,
        t.used_ublk AS undo_blocks,
        t.used_urec AS undo_records,
        ROUND(t.used_ublk * 8 / 1024, 2) AS undo_mb,
        t.log_io AS redo_entries,
        t.phy_io AS physical_ios,
        t.cr_get AS consistent_gets,
        ROUND((SYSDATE - TO_DATE(t.start_time, 'MM/DD/YY HH24:MI:SS')) * 24 * 60, 2) AS duration_minutes,
        ROUND((SYSDATE - TO_DATE(t.start_time, 'MM/DD/YY HH24:MI:SS')) * 24, 2) AS duration_hours,
        CASE 
            WHEN (SYSDATE - TO_DATE(t.start_time, 'MM/DD/YY HH24:MI:SS')) * 24 * 60 > 60 THEN 'VERY LONG'
            WHEN (SYSDATE - TO_DATE(t.start_time, 'MM/DD/YY HH24:MI:SS')) * 24 * 60 > 30 THEN 'LONG'
            WHEN (SYSDATE - TO_DATE(t.start_time, 'MM/DD/YY HH24:MI:SS')) * 24 * 60 > 10 THEN 'MODERATE'
            ELSE 'NORMAL'
        END AS transaction_category
    FROM 
        gv$transaction t
        JOIN gv$session s ON t.inst_id = s.inst_id AND t.ses_addr = s.saddr
    WHERE 
        (SYSDATE - TO_DATE(t.start_time, 'MM/DD/YY HH24:MI:SS')) * 24 * 60 > 5  -- Running for more than 5 minutes
    ORDER BY 
        duration_minutes DESC
    """

def get_transaction_workload_profile():
    return """
    -- Transaction workload profile
    SELECT 
        inst_id,
        metric_name,
        ROUND(value, 2) AS metric_value,
        metric_unit
    FROM 
        gv$sysmetric
    WHERE 
        metric_name IN (
            'User Transaction Per Sec',
            'User Commits Per Sec',
            'User Rollbacks Per Sec',
            'Response Time Per Txn',
            'SQL Service Response Time',
            'User Calls Per Txn',
            'Recursive Calls Per Txn',
            'Logical Reads Per Txn',
            'Physical Reads Per Txn',
            'Physical Writes Per Txn',
            'Redo Generated Per Txn',
            'DB Block Changes Per Txn',
            'User Rollback Undo Records Applied Per Txn',
            'Executions Per Txn',
            'Total Parse Count Per Txn'
        )
        AND group_id = 2
    ORDER BY 
        inst_id,
        metric_name
    """

def get_transaction_peak_analysis():
    return """
    -- Peak transaction analysis from AWR
    WITH hourly_peaks AS (
        SELECT 
            s.instance_number,
            TO_CHAR(s.begin_interval_time, 'YYYY-MM-DD HH24') AS hour_period,
            MAX(CASE WHEN m.metric_name = 'User Transaction Per Sec' THEN m.maxval END) AS peak_tps,
            AVG(CASE WHEN m.metric_name = 'User Transaction Per Sec' THEN m.average END) AS avg_tps,
            MAX(CASE WHEN m.metric_name = 'User Commits Per Sec' THEN m.maxval END) AS peak_commits_ps,
            MAX(CASE WHEN m.metric_name = 'Executions Per Sec' THEN m.maxval END) AS peak_exec_ps,
            MAX(CASE WHEN m.metric_name = 'Redo Generated Per Sec' THEN m.maxval END) AS peak_redo_ps
        FROM 
            dba_hist_sysmetric_summary m
        WHERE 
            m.begin_time >= SYSDATE - 7
            AND m.metric_name IN (
                'User Transaction Per Sec',
                'User Commits Per Sec',
                'Executions Per Sec',
                'Redo Generated Per Sec'
            )
        GROUP BY 
            s.instance_number,
            TO_CHAR(s.begin_interval_time, 'YYYY-MM-DD HH24')
    )
    SELECT 
        instance_number,
        hour_period,
        ROUND(peak_tps, 2) AS peak_tps,
        ROUND(avg_tps, 2) AS avg_tps,
        ROUND(peak_tps - avg_tps, 2) AS tps_spike,
        ROUND(peak_commits_ps, 2) AS peak_commits_per_sec,
        ROUND(peak_exec_ps, 2) AS peak_exec_per_sec,
        ROUND(peak_redo_ps / (1024*1024), 2) AS peak_redo_mb_per_sec,
        CASE 
            WHEN peak_tps > 1000 THEN 'EXTREME'
            WHEN peak_tps > 500 THEN 'VERY HIGH'
            WHEN peak_tps > 100 THEN 'HIGH'
            WHEN peak_tps > 50 THEN 'MODERATE'
            ELSE 'NORMAL'
        END AS load_classification
    FROM 
        hourly_peaks
    WHERE 
        peak_tps > 0
    ORDER BY 
        peak_tps DESC
    FETCH FIRST 100 ROWS ONLY
    """

#Capacity growth trends
def get_tablespace_growth_trend():
    return """
    -- Tablespace growth trend from AWR history
    WITH tablespace_history AS (
        SELECT 
            ts.tsname AS tablespace_name,
            s.snap_id,
            s.begin_interval_time,
            SUM(tsu.tablespace_size * ts.block_size) / (1024*1024*1024) AS size_gb,
            SUM(tsu.tablespace_usedsize * ts.block_size) / (1024*1024*1024) AS used_gb,
            SUM(tsu.tablespace_maxsize * ts.block_size) / (1024*1024*1024) AS max_size_gb
        FROM 
            dba_hist_tbspc_space_usage tsu
            JOIN dba_hist_tablespace ts ON tsu.tablespace_id = ts.ts#
                AND tsu.dbid = ts.dbid
            JOIN dba_hist_snapshot s ON tsu.snap_id = s.snap_id
                AND tsu.dbid = s.dbid
        WHERE 
            s.begin_interval_time >= SYSDATE - 30  -- Last 30 days
        GROUP BY 
            ts.tsname,
            s.snap_id,
            s.begin_interval_time
    ),
    growth_calc AS (
        SELECT 
            tablespace_name,
            snap_id,
            begin_interval_time,
            size_gb,
            used_gb,
            max_size_gb,
            ROUND(100 * used_gb / NULLIF(size_gb, 0), 2) AS pct_used,
            used_gb - LAG(used_gb) OVER (PARTITION BY tablespace_name ORDER BY snap_id) AS growth_gb,
            begin_interval_time - LAG(begin_interval_time) OVER (PARTITION BY tablespace_name ORDER BY snap_id) AS time_diff
        FROM 
            tablespace_history
    )
    SELECT 
        tablespace_name,
        TO_CHAR(begin_interval_time, 'YYYY-MM-DD HH24:MI') AS snapshot_time,
        ROUND(size_gb, 2) AS allocated_gb,
        ROUND(used_gb, 2) AS used_gb,
        ROUND(max_size_gb, 2) AS max_size_gb,
        pct_used,
        ROUND(growth_gb, 3) AS growth_gb,
        ROUND(EXTRACT(DAY FROM time_diff) + EXTRACT(HOUR FROM time_diff)/24 + EXTRACT(MINUTE FROM time_diff)/(24*60), 2) AS days_between,
        CASE 
            WHEN growth_gb > 0 AND time_diff IS NOT NULL THEN 
                ROUND(growth_gb / (EXTRACT(DAY FROM time_diff) + EXTRACT(HOUR FROM time_diff)/24 + EXTRACT(MINUTE FROM time_diff)/(24*60)), 3)
            ELSE 0
        END AS daily_growth_rate_gb
    FROM 
        growth_calc
    WHERE 
        begin_interval_time >= SYSDATE - 30  -- Show last 30 days
    ORDER BY 
        tablespace_name,
        begin_interval_time DESC
    """

def get_segment_growth_trend():
    return """
    -- Segment growth trend from AWR
        WITH segment_history AS (
        SELECT 
            obj.owner,
            obj.object_name,
            obj.subobject_name,
            obj.object_type,
            obj.tablespace_name,
            s.snap_id,
            s.begin_interval_time,
            seg.space_used_total / (1024*1024) AS used_mb,
            seg.space_allocated_total / (1024*1024) AS allocated_mb
        FROM 
            dba_hist_seg_stat seg
            JOIN dba_hist_seg_stat_obj obj ON seg.obj# = obj.obj#
                AND seg.dataobj# = obj.dataobj#
                AND seg.ts# = obj.ts#
                AND seg.dbid = obj.dbid
            JOIN dba_hist_snapshot s ON seg.snap_id = s.snap_id
                AND seg.dbid = s.dbid
                AND seg.instance_number = s.instance_number
        WHERE 
            s.begin_interval_time >= SYSDATE - 30  -- Last 30 days
            AND obj.owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
            AND seg.space_used_total > 0
    ),
    growth_calc AS (
        SELECT 
            owner,
            object_name,
            subobject_name,
            object_type,
            tablespace_name,
            snap_id,
            begin_interval_time,
            used_mb,
            allocated_mb,
            used_mb - LAG(used_mb) OVER (PARTITION BY owner, object_name, subobject_name ORDER BY snap_id) AS growth_mb,
            begin_interval_time - LAG(begin_interval_time) OVER (PARTITION BY owner, object_name, subobject_name ORDER BY snap_id) AS time_diff
        FROM 
            segment_history
    ),
    ranked_segments AS (
        SELECT 
            owner,
            object_name,
            subobject_name,
            object_type,
            tablespace_name,
            MAX(used_mb) AS current_size_mb,
            SUM(CASE WHEN growth_mb > 0 THEN growth_mb ELSE 0 END) AS total_growth_mb,
            COUNT(CASE WHEN growth_mb > 0 THEN 1 END) AS growth_periods,
            AVG(CASE WHEN growth_mb > 0 THEN growth_mb END) AS avg_growth_mb
        FROM 
            growth_calc
        GROUP BY 
            owner,
            object_name,
            subobject_name,
            object_type,
            tablespace_name
        HAVING 
            SUM(CASE WHEN growth_mb > 0 THEN growth_mb ELSE 0 END) > 0
    )
    SELECT * FROM (
        SELECT 
            owner,
            object_name,
            subobject_name,
            object_type,
            tablespace_name,
            ROUND(current_size_mb, 2) AS current_size_mb,
            ROUND(current_size_mb / 1024, 2) AS current_size_gb,
            ROUND(total_growth_mb, 2) AS total_growth_mb,
            growth_periods,
            ROUND(avg_growth_mb, 2) AS avg_growth_mb_per_period,
            ROUND(100 * total_growth_mb / NULLIF(current_size_mb - total_growth_mb, 0), 2) AS growth_pct
        FROM 
            ranked_segments
        ORDER BY 
            total_growth_mb DESC
    )
    WHERE ROWNUM <= 50  -- Top 50 growing segments
    """

def get_database_size_history():
    return """
    -- Database size history and growth trend
    WITH db_size_history AS (
        SELECT 
            s.snap_id,
            s.begin_interval_time,
            SUM(tsu.tablespace_size * ts.block_size) / (1024*1024*1024) AS total_allocated_gb,
            SUM(tsu.tablespace_usedsize * ts.block_size) / (1024*1024*1024) AS total_used_gb
        FROM 
            dba_hist_tbspc_space_usage tsu
            JOIN dba_hist_tablespace ts ON tsu.tablespace_id = ts.ts#
                AND tsu.dbid = ts.dbid
            JOIN dba_hist_snapshot s ON tsu.snap_id = s.snap_id
                AND tsu.dbid = s.dbid
        WHERE 
            s.begin_interval_time >= SYSDATE - 365  -- Last year
        GROUP BY 
            s.snap_id,
            s.begin_interval_time
    ),
    weekly_summary AS (
        SELECT 
            TRUNC(begin_interval_time, 'IW') AS week_start,
            MAX(total_allocated_gb) AS max_allocated_gb,
            MAX(total_used_gb) AS max_used_gb,
            MIN(total_used_gb) AS min_used_gb,
            AVG(total_used_gb) AS avg_used_gb
        FROM 
            db_size_history
        GROUP BY 
            TRUNC(begin_interval_time, 'IW')
    ),
    growth_trend AS (
        SELECT 
            week_start,
            max_allocated_gb,
            max_used_gb,
            min_used_gb,
            avg_used_gb,
            max_used_gb - LAG(max_used_gb) OVER (ORDER BY week_start) AS weekly_growth_gb,
            ROUND(100 * max_used_gb / NULLIF(max_allocated_gb, 0), 2) AS pct_used
        FROM 
            weekly_summary
    )
    SELECT 
        TO_CHAR(week_start, 'YYYY-MM-DD') AS week_starting,
        ROUND(max_allocated_gb, 2) AS allocated_gb,
        ROUND(max_used_gb, 2) AS used_gb,
        ROUND(avg_used_gb, 2) AS avg_used_gb,
        ROUND(weekly_growth_gb, 2) AS weekly_growth_gb,
        pct_used,
        ROUND(AVG(weekly_growth_gb) OVER (ORDER BY week_start ROWS BETWEEN 3 PRECEDING AND CURRENT ROW), 2) AS avg_4week_growth_gb,
        CASE 
            WHEN weekly_growth_gb > 0 THEN 
                ROUND((max_allocated_gb - max_used_gb) / NULLIF(weekly_growth_gb, 0), 1)
            ELSE NULL
        END AS weeks_until_full
    FROM 
        growth_trend
    ORDER BY 
        week_start DESC
    """

#Needs to fix - BLC - 9/30/2025
#An error occurred during data collection: ORA-00904: "F"."SNAP_ID": invalid identifier
def get_datafile_growth_history():
    return """
    -- Datafile growth history using dba_data_files snapshots via tablespace space usage
    WITH file_history AS (
        SELECT
            ts.tablespace_id,
            s.snap_id,
            s.begin_interval_time,
            ROUND(ts.tablespace_size * t.block_size / (1024*1024*1024), 2) AS allocated_gb,
            ROUND(ts.tablespace_usedsize * t.block_size / (1024*1024*1024), 2) AS used_gb
        FROM
            dba_hist_tbspc_space_usage ts
            JOIN dba_hist_snapshot s ON ts.snap_id = s.snap_id AND ts.dbid = s.dbid
            JOIN v$tablespace vt ON ts.tablespace_id = vt.ts#
            JOIN dba_tablespaces t ON vt.name = t.tablespace_name
        WHERE
            s.begin_interval_time >= SYSDATE - 30
    ),
    growth_calc AS (
        SELECT
            tablespace_id,
            snap_id,
            begin_interval_time,
            allocated_gb,
            used_gb,
            allocated_gb - LAG(allocated_gb) OVER (PARTITION BY tablespace_id ORDER BY snap_id) AS growth_gb
        FROM
            file_history
    )
    SELECT
        tablespace_id,
        TO_CHAR(MIN(begin_interval_time), 'YYYY-MM-DD') AS first_seen,
        TO_CHAR(MAX(begin_interval_time), 'YYYY-MM-DD') AS last_seen,
        ROUND(MIN(allocated_gb), 2) AS min_allocated_gb,
        ROUND(MAX(allocated_gb), 2) AS max_allocated_gb,
        ROUND(MAX(allocated_gb) - MIN(allocated_gb), 2) AS total_growth_gb,
        COUNT(CASE WHEN growth_gb > 0 THEN 1 END) AS resize_count,
        ROUND(AVG(CASE WHEN growth_gb > 0 THEN growth_gb END), 3) AS avg_growth_per_resize_gb
    FROM
        growth_calc
    GROUP BY
        tablespace_id
    HAVING
        MAX(allocated_gb) - MIN(allocated_gb) > 0
    ORDER BY
        total_growth_gb DESC
    """

def get_object_count_growth():
    return """
    -- Object count growth trend
    WITH object_counts AS (
        SELECT 
            TRUNC(created) AS creation_date,
            owner,
            object_type,
            COUNT(*) AS objects_created
        FROM 
            dba_objects
        WHERE 
            created >= SYSDATE - 365  -- Last year
            AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
        GROUP BY 
            TRUNC(created),
            owner,
            object_type
    ),
    monthly_summary AS (
        SELECT 
            TRUNC(creation_date, 'MM') AS month_start,
            owner,
            object_type,
            SUM(objects_created) AS monthly_created
        FROM 
            object_counts
        GROUP BY 
            TRUNC(creation_date, 'MM'),
            owner,
            object_type
    ),
    cumulative AS (
        SELECT 
            month_start,
            owner,
            object_type,
            monthly_created,
            SUM(monthly_created) OVER (PARTITION BY owner, object_type ORDER BY month_start) AS cumulative_objects
        FROM 
            monthly_summary
    )
    SELECT 
        TO_CHAR(month_start, 'YYYY-MM') AS month,
        owner,
        object_type,
        monthly_created,
        cumulative_objects,
        ROUND(100 * monthly_created / NULLIF(LAG(cumulative_objects) OVER (PARTITION BY owner, object_type ORDER BY month_start), 0), 2) AS monthly_growth_pct
    FROM 
        cumulative
    WHERE 
        monthly_created > 0
    ORDER BY 
        month_start DESC,
        monthly_created DESC
    """

def get_redo_generation_trend():
    return """
    -- Redo generation trend
    WITH redo_history AS (
        SELECT 
            s.instance_number,
            s.snap_id,
            s.begin_interval_time,
            s.end_interval_time,
            st.value AS redo_size,
            st.value - LAG(st.value) OVER (PARTITION BY s.instance_number ORDER BY s.snap_id) AS redo_generated
        FROM 
            dba_hist_sysstat st
            JOIN dba_hist_snapshot s ON st.snap_id = s.snap_id
                AND st.dbid = s.dbid
                AND st.instance_number = s.instance_number
        WHERE 
            s.begin_interval_time >= SYSDATE - 30  -- Last 30 days
            AND st.stat_name = 'redo size'
    ),
    daily_redo AS (
        SELECT 
            instance_number,
            TRUNC(begin_interval_time) AS redo_date,
            SUM(CASE WHEN redo_generated > 0 THEN redo_generated ELSE 0 END) / (1024*1024*1024) AS daily_redo_gb
        FROM 
            redo_history
        GROUP BY 
            instance_number,
            TRUNC(begin_interval_time)
    )
    SELECT 
        instance_number,
        TO_CHAR(redo_date, 'YYYY-MM-DD') AS date_str,
        TO_CHAR(redo_date, 'DY') AS day_of_week,
        ROUND(daily_redo_gb, 2) AS daily_redo_gb,
        ROUND(AVG(daily_redo_gb) OVER (
            PARTITION BY instance_number 
            ORDER BY redo_date 
            ROWS BETWEEN 6 PRECEDING AND CURRENT ROW
        ), 2) AS rolling_7day_avg_gb,
        ROUND(daily_redo_gb - LAG(daily_redo_gb) OVER (PARTITION BY instance_number ORDER BY redo_date), 2) AS daily_change_gb,
        ROUND(100 * (daily_redo_gb - LAG(daily_redo_gb) OVER (PARTITION BY instance_number ORDER BY redo_date)) / 
            NULLIF(LAG(daily_redo_gb) OVER (PARTITION BY instance_number ORDER BY redo_date), 0), 2) AS daily_change_pct
    FROM 
        daily_redo
    ORDER BY 
        instance_number,
        redo_date DESC
    """

def get_session_history_trend():
    return """
    -- Session count historical trend
    WITH session_history AS (
        SELECT 
            s.instance_number,
            s.begin_interval_time,
            m.average AS avg_sessions,
            m.maxval AS max_sessions,
            m.minval AS min_sessions
        FROM 
            dba_hist_sysmetric_summary m
            WHERE 
            s.begin_interval_time >= SYSDATE - 30  -- Last 30 days
            AND m.metric_name = 'Session Count'
    ),
    daily_peaks AS (
        SELECT 
            instance_number,
            TRUNC(begin_interval_time) AS session_date,
            MAX(max_sessions) AS daily_peak_sessions,
            AVG(avg_sessions) AS daily_avg_sessions,
            MIN(min_sessions) AS daily_min_sessions
        FROM 
            session_history
        GROUP BY 
            instance_number,
            TRUNC(begin_interval_time)
    )
    SELECT 
        instance_number,
        TO_CHAR(session_date, 'YYYY-MM-DD') AS date_str,
        TO_CHAR(session_date, 'DY') AS day_of_week,
        daily_peak_sessions,
        ROUND(daily_avg_sessions, 1) AS daily_avg_sessions,
        daily_min_sessions,
        ROUND(AVG(daily_peak_sessions) OVER (
            PARTITION BY instance_number 
            ORDER BY session_date 
            ROWS BETWEEN 29 PRECEDING AND CURRENT ROW
        ), 1) AS rolling_30day_avg_peak,
        daily_peak_sessions - LAG(daily_peak_sessions) OVER (PARTITION BY instance_number ORDER BY session_date) AS daily_peak_change
    FROM 
        daily_peaks
    ORDER BY 
        instance_number,
        session_date DESC
    """

def get_storage_prediction():
    return """
    -- Storage growth prediction based on historical trends
    WITH tablespace_history AS (
        SELECT 
            ts.tsname AS tablespace_name,
            s.begin_interval_time AS sample_time,
            SUM(tsu.tablespace_usedsize * ts.block_size) / (1024*1024*1024) AS used_gb,
            SUM(tsu.tablespace_size * ts.block_size) / (1024*1024*1024) AS allocated_gb,
            SUM(tsu.tablespace_maxsize * ts.block_size) / (1024*1024*1024) AS max_size_gb
        FROM 
            dba_hist_tbspc_space_usage tsu
            JOIN dba_hist_tablespace ts ON tsu.tablespace_id = ts.ts#
                AND tsu.dbid = ts.dbid
            JOIN dba_hist_snapshot s ON tsu.snap_id = s.snap_id
                AND tsu.dbid = s.dbid
        WHERE 
            s.begin_interval_time >= SYSDATE - 30  -- Last 30 days for trend
        GROUP BY 
            ts.tsname,
            s.begin_interval_time
    ),
    growth_calc AS (
        SELECT 
            tablespace_name,
            MIN(sample_time) AS first_sample,
            MAX(sample_time) AS last_sample,
            MIN(used_gb) AS starting_size_gb,
            MAX(used_gb) AS current_size_gb,
            MAX(allocated_gb) AS current_allocated_gb,
            MAX(max_size_gb) AS max_size_gb,
            (MAX(used_gb) - MIN(used_gb)) AS total_growth_gb,
            EXTRACT(DAY FROM (MAX(sample_time) - MIN(sample_time))) AS days_observed
        FROM 
            tablespace_history
        GROUP BY 
            tablespace_name
        HAVING 
            MAX(used_gb) - MIN(used_gb) > 0  -- Only show tablespaces with growth
    )
    SELECT 
        tablespace_name,
        ROUND(current_size_gb, 2) AS current_used_gb,
        ROUND(current_allocated_gb, 2) AS current_allocated_gb,
        ROUND(max_size_gb, 2) AS max_size_gb,
        ROUND(total_growth_gb, 2) AS growth_last_90days_gb,
        ROUND(total_growth_gb / NULLIF(days_observed, 0), 3) AS daily_growth_rate_gb,
        ROUND(total_growth_gb / NULLIF(days_observed, 0) * 30, 2) AS projected_30day_growth_gb,
        ROUND(current_size_gb + (total_growth_gb / NULLIF(days_observed, 0) * 30), 2) AS projected_size_30days_gb,
        CASE 
            WHEN total_growth_gb / NULLIF(days_observed, 0) > 0 THEN
                ROUND((current_allocated_gb - current_size_gb) / (total_growth_gb / NULLIF(days_observed, 0)), 0)
            ELSE NULL
        END AS days_until_allocated_full,
        CASE 
            WHEN total_growth_gb / NULLIF(days_observed, 0) > 0 AND max_size_gb > 0 THEN
                ROUND((max_size_gb - current_size_gb) / (total_growth_gb / NULLIF(days_observed, 0)), 0)
            ELSE NULL
        END AS days_until_max_size
    FROM 
        growth_calc
    ORDER BY 
        daily_growth_rate_gb DESC NULLS LAST
    """

def get_goldengate_storage_estimate():
    return """
      -- GoldenGate storage estimation
      -- Formula: ((transaction log size * 0.33) * log switches per day) * retention days
WITH log_metrics AS (
          SELECT
              -- Average redo log size in MB
              ROUND(AVG(bytes) / (1024*1024), 2) AS avg_log_size_mb
          FROM
              v$log
      ),
      log_switches AS (
          SELECT
              ROUND(COUNT(*) / 7, 2) AS log_switches_per_day
          FROM
              v$log_history
          WHERE
              first_time >= SYSDATE - 7
      )
      SELECT
          lm.avg_log_size_mb,
          ls.log_switches_per_day,
          ROUND((lm.avg_log_size_mb * 0.33) * ls.log_switches_per_day, 2) AS daily_trail_size_mb,
          -- Storage estimates for different retention periods
          ROUND((lm.avg_log_size_mb * 0.33) * ls.log_switches_per_day * 7, 2) AS trail_7days_mb,
          ROUND((lm.avg_log_size_mb * 0.33) * ls.log_switches_per_day * 14, 2) AS trail_14days_mb,
          ROUND((lm.avg_log_size_mb * 0.33) * ls.log_switches_per_day * 30, 2) AS trail_30days_mb,
          ROUND((lm.avg_log_size_mb * 0.33) * ls.log_switches_per_day * 60, 2) AS trail_60days_mb,
          ROUND((lm.avg_log_size_mb * 0.33) * ls.log_switches_per_day * 90, 2) AS trail_90days_mb,
          -- Convert to GB for larger retention periods
          ROUND((lm.avg_log_size_mb * 0.33) * ls.log_switches_per_day * 30 / 1024, 2) AS trail_30days_gb,
          ROUND((lm.avg_log_size_mb * 0.33) * ls.log_switches_per_day * 90 / 1024, 2) AS trail_90days_gb
      FROM
          log_metrics lm,
          log_switches ls
      """

#def get_goldengate_support_mode():
#    return """
#           SELECT
#                  owner,
#                  object_name,
#                  support_mode,
#                   explanation,
#                   logical_replication,
#                   auto_capture,
#                   all_keys
#           FROM dba_goldengate_support_mode
#           WHERE owner NOT IN
#                 ('AUTHORIZE', 'S$NULL', 'LBACSYS', 'OUTLN', 'DBSNMP', 'APPQOSSYS', 'VECSYS', 'DBSFWUSER', 'GGSYS',
#                  'ANONYMOUS', 'CTXSYS', 'DVF', 'DVSYS', 'AUDSYS', 'GSMADMIN_INTERNAL', 'GGSHAREDCAP', 'OLAPSYS',
#                  'MDSYS', 'XDB', 'WMSYS', 'GSMCATUSER', 'MDDATA', 'REMOTE_SCHEDUL
#  ER_AGENT', 'SYSBACKUP', 'GSMUSER', 'OJVMSYS', 'DIP', 'DGPDB_INT', 'SYSKM', 'SYS$UMF', 'SYSDG', 'SYS', 'SYSTEM',
#                  'SYSRAC')
#           ORDER BY owner, object_name
#"""


#Peak Resource Utlization
def get_peak_cpu_utilization():
    return """
    -- Peak CPU utilization from AWR
    WITH cpu_peaks AS (
        SELECT
            m.instance_number,
            m.begin_time AS begin_interval_time,
            m.end_time AS end_interval_time,
            m.metric_name,
            m.maxval AS peak_value,
            m.average AS avg_value,
            m.minval AS min_value,
            m.standard_deviation
        FROM
            dba_hist_sysmetric_summary m
        WHERE
            m.begin_time >= SYSDATE - 30
            AND m.metric_name IN (
                'Host CPU Utilization (%)',
                'Database CPU Time Ratio',
                'CPU Usage Per Sec',
                'CPU Usage Per Txn'
            )
    )
    SELECT 
        instance_number,
        TO_CHAR(begin_interval_time, 'YYYY-MM-DD HH24:MI') AS snapshot_time,
        metric_name,
        ROUND(peak_value, 2) AS peak_value,
        ROUND(avg_value, 2) AS avg_value,
        ROUND(peak_value - avg_value, 2) AS peak_above_avg,
        ROUND(standard_deviation, 2) AS std_dev,
        CASE 
            WHEN metric_name = 'Host CPU Utilization (%)' AND peak_value >= 95 THEN 'CRITICAL'
            WHEN metric_name = 'Host CPU Utilization (%)' AND peak_value >= 85 THEN 'HIGH'
            WHEN metric_name = 'Host CPU Utilization (%)' AND peak_value >= 70 THEN 'MODERATE'
            WHEN metric_name = 'Database CPU Time Ratio' AND peak_value >= 95 THEN 'HIGH DB CPU'
            ELSE 'NORMAL'
        END AS severity
    FROM
        cpu_peaks
    ORDER BY
        begin_interval_time DESC,
        metric_name
    """

def get_peak_memory_utilization():
    return """
    -- Peak memory utilization from AWR
    WITH memory_stats AS (
        SELECT 
            s.snap_id,
            s.instance_number,
            s.begin_interval_time,
            -- PGA stats
            pga.name AS stat_name,
            pga.value / (1024*1024*1024) AS value_gb
        FROM 
            dba_hist_pgastat pga
            JOIN dba_hist_snapshot s ON pga.snap_id = s.snap_id
                AND pga.dbid = s.dbid
                AND pga.instance_number = s.instance_number
        WHERE 
            s.begin_interval_time >= SYSDATE - 30
            AND pga.name IN (
                'total PGA allocated',
                'total PGA inuse',
                'maximum PGA allocated',
                'aggregate PGA target parameter',
                'aggregate PGA auto target'
            )
        UNION ALL
        SELECT 
            s.snap_id,
            s.instance_number,
            s.begin_interval_time,
            'SGA Total' AS stat_name,
            SUM(sga.bytes) / (1024*1024*1024) AS value_gb
        FROM 
            dba_hist_sgastat sga
            JOIN dba_hist_snapshot s ON sga.snap_id = s.snap_id
                AND sga.dbid = s.dbid
                AND sga.instance_number = s.instance_number
        WHERE 
            s.begin_interval_time >= SYSDATE - 30
        GROUP BY 
            s.snap_id,
            s.instance_number,
            s.begin_interval_time
    ),
    memory_peaks AS (
        SELECT 
            instance_number,
            TRUNC(begin_interval_time) AS peak_date,
            stat_name,
            MAX(value_gb) AS peak_value_gb,
            AVG(value_gb) AS avg_value_gb,
            MIN(value_gb) AS min_value_gb
        FROM 
            memory_stats
        GROUP BY 
            instance_number,
            TRUNC(begin_interval_time),
            stat_name
    )
    SELECT 
        instance_number,
        TO_CHAR(peak_date, 'YYYY-MM-DD') AS date_str,
        MAX(CASE WHEN stat_name = 'total PGA allocated' THEN peak_value_gb END) AS peak_pga_allocated_gb,
        MAX(CASE WHEN stat_name = 'total PGA inuse' THEN peak_value_gb END) AS peak_pga_inuse_gb,
        MAX(CASE WHEN stat_name = 'maximum PGA allocated' THEN peak_value_gb END) AS max_pga_allocated_gb,
        MAX(CASE WHEN stat_name = 'aggregate PGA target parameter' THEN peak_value_gb END) AS pga_target_gb,
        MAX(CASE WHEN stat_name = 'SGA Total' THEN peak_value_gb END) AS sga_total_gb,
        ROUND(100 * MAX(CASE WHEN stat_name = 'total PGA inuse' THEN peak_value_gb END) / 
            NULLIF(MAX(CASE WHEN stat_name = 'aggregate PGA target parameter' THEN peak_value_gb END), 0), 2) AS pga_usage_pct
    FROM 
        memory_peaks
    GROUP BY 
        instance_number,
        peak_date
    ORDER BY 
        instance_number,
        peak_date DESC
    """

def get_peak_session_utilization():
    return """
    -- Peak session and process utilization
    WITH session_peaks AS (
        SELECT 
            s.instance_number,
            s.begin_interval_time,
            m.metric_name,
            m.maxval AS peak_value,
            m.average AS avg_value,
            m.minval AS min_value
        FROM 
            dba_hist_sysmetric_summary m
            WHERE 
            m.begin_time >= SYSDATE - 30
            AND m.metric_name IN (
                'Session Count',
                'Average Active Sessions',
                'Active Parallel Sessions',
                'Active Serial Sessions'
            )
    ),
    resource_limits AS (
        SELECT 
            r.instance_number,
            r.snap_id,
            s.begin_interval_time,
            r.resource_name,
            r.current_utilization,
            r.max_utilization,
            r.initial_allocation,
            r.limit_value
        FROM 
            dba_hist_resource_limit r
            JOIN dba_hist_snapshot s ON r.snap_id = s.snap_id
                AND r.dbid = s.dbid
                AND r.instance_number = s.instance_number
        WHERE 
            s.begin_interval_time >= SYSDATE - 30
            AND r.resource_name IN ('sessions', 'processes')
    )
    SELECT 
        sp.instance_number,
        TO_CHAR(sp.begin_interval_time, 'YYYY-MM-DD HH24:MI') AS snapshot_time,
        sp.metric_name,
        ROUND(sp.peak_value, 1) AS peak_value,
        ROUND(sp.avg_value, 1) AS avg_value,
        rl.resource_name,
        rl.max_utilization AS resource_peak,
        rl.limit_value AS resource_limit,
        CASE 
            WHEN rl.limit_value != 'UNLIMITED' AND rl.max_utilization > 0 THEN
                ROUND(100 * rl.max_utilization / TO_NUMBER(rl.limit_value), 2)
            ELSE NULL
        END AS peak_pct_of_limit
    FROM 
        session_peaks sp
        LEFT JOIN resource_limits rl ON sp.instance_number = rl.instance_number
            AND TRUNC(sp.begin_interval_time) = TRUNC(rl.begin_interval_time)
            AND sp.metric_name = 'Session Count'
            AND rl.resource_name = 'sessions'
    WHERE 
        sp.metric_name IN ('Session Count', 'Average Active Sessions', 'Active Parallel Sessions', 'Active Serial Sessions')
    ORDER BY 
        sp.instance_number,
        sp.begin_interval_time DESC
    """

def get_peak_io_utilization():
    return """
    -- Peak I/O utilization and throughput
    WITH io_metrics AS (
        SELECT 
            s.instance_number,
            s.begin_interval_time,
            m.metric_name,
            m.maxval AS peak_value,
            m.average AS avg_value,
            m.standard_deviation
        FROM 
            dba_hist_sysmetric_summary m
            WHERE 
            m.begin_time >= SYSDATE - 30
            AND m.metric_name IN (
                'Physical Read Total IO Requests Per Sec',
                'Physical Write Total IO Requests Per Sec',
                'Physical Read Total Bytes Per Sec',
                'Physical Write Total Bytes Per Sec',
                'I/O Megabytes per Second',
                'I/O Requests per Second',
                'Average Synchronous Single-Block Read Latency'
            )
    )
    SELECT 
        instance_number,
        TO_CHAR(begin_interval_time, 'YYYY-MM-DD HH24:MI') AS snapshot_time,
        MAX(CASE WHEN metric_name = 'Physical Read Total IO Requests Per Sec' THEN peak_value END) AS peak_read_iops,
        MAX(CASE WHEN metric_name = 'Physical Write Total IO Requests Per Sec' THEN peak_value END) AS peak_write_iops,
        MAX(CASE WHEN metric_name = 'I/O Requests per Second' THEN peak_value END) AS peak_total_iops,
        ROUND(MAX(CASE WHEN metric_name = 'Physical Read Total Bytes Per Sec' THEN peak_value END) / (1024*1024), 2) AS peak_read_mbps,
        ROUND(MAX(CASE WHEN metric_name = 'Physical Write Total Bytes Per Sec' THEN peak_value END) / (1024*1024), 2) AS peak_write_mbps,
        MAX(CASE WHEN metric_name = 'I/O Megabytes per Second' THEN peak_value END) AS peak_total_mbps,
        ROUND(MAX(CASE WHEN metric_name = 'Average Synchronous Single-Block Read Latency' THEN peak_value END), 2) AS peak_read_latency_ms
    FROM 
        io_metrics
    GROUP BY 
        instance_number,
        begin_interval_time
    HAVING 
        MAX(CASE WHEN metric_name = 'I/O Requests per Second' THEN peak_value END) > 100
        OR MAX(CASE WHEN metric_name = 'I/O Megabytes per Second' THEN peak_value END) > 50
    ORDER BY 
        peak_total_iops DESC NULLS LAST
    """

def get_peak_wait_events():
    return """
    -- Peak wait event times
    WITH wait_stats AS (
        SELECT 
            s.instance_number,
            s.begin_interval_time,
            s.snap_id,
            e.event_name,
            e.wait_class,
            e.total_waits - LAG(e.total_waits) OVER (
                PARTITION BY s.instance_number, e.event_id 
                ORDER BY s.snap_id
            ) AS delta_waits,
            (e.time_waited_micro - LAG(e.time_waited_micro) OVER (
                PARTITION BY s.instance_number, e.event_id 
                ORDER BY s.snap_id
            )) / 1000000 AS delta_time_seconds
        FROM 
            dba_hist_system_event e
            JOIN dba_hist_snapshot s ON e.snap_id = s.snap_id
                AND e.dbid = s.dbid
                AND e.instance_number = s.instance_number
        WHERE 
            s.begin_interval_time >= SYSDATE - 7  -- Last 7 days
            AND e.wait_class NOT IN ('Idle', 'Other')
    ),
    wait_peaks AS (
        SELECT 
            instance_number,
            TRUNC(begin_interval_time) AS peak_date,
            event_name,
            wait_class,
            MAX(delta_waits) AS peak_wait_count,
            MAX(delta_time_seconds) AS peak_wait_time_sec,
            MAX(CASE 
                WHEN delta_waits > 0 THEN delta_time_seconds * 1000 / delta_waits 
                ELSE 0 
            END) AS peak_avg_wait_ms
        FROM 
            wait_stats
        WHERE 
            delta_waits > 0
            AND delta_time_seconds > 0
        GROUP BY 
            instance_number,
            TRUNC(begin_interval_time),
            event_name,
            wait_class
    )
    SELECT * FROM (
        SELECT 
            instance_number,
            TO_CHAR(peak_date, 'YYYY-MM-DD') AS date_str,
            peak_date,  -- Include the actual date for ordering
            event_name,
            wait_class,
            peak_wait_count,
            ROUND(peak_wait_time_sec, 2) AS peak_wait_time_sec,
            ROUND(peak_avg_wait_ms, 2) AS peak_avg_wait_ms,
            DENSE_RANK() OVER (
                PARTITION BY instance_number, peak_date 
                ORDER BY peak_wait_time_sec DESC
            ) AS daily_rank
        FROM 
            wait_peaks
        WHERE 
            peak_wait_time_sec > 1  -- Only significant waits
    )
    WHERE 
        daily_rank <= 10  -- Top 10 wait events per day
    ORDER BY 
        instance_number,
        peak_date DESC,
        peak_wait_time_sec DESC
    """

def get_peak_redo_generation():
    return """
    -- Peak redo generation rates
    WITH redo_stats AS (
        SELECT 
            s.instance_number,
            s.snap_id,
            s.begin_interval_time,
            s.end_interval_time,
            st.value AS redo_size,
            st.value - LAG(st.value) OVER (
                PARTITION BY s.instance_number 
                ORDER BY s.snap_id
            ) AS redo_generated
        FROM 
            dba_hist_sysstat st
            JOIN dba_hist_snapshot s ON st.snap_id = s.snap_id
                AND st.dbid = s.dbid
                AND st.instance_number = s.instance_number
        WHERE 
            s.begin_interval_time >= SYSDATE - 30
            AND st.stat_name = 'redo size'
    ),
    redo_rates AS (
        SELECT 
            instance_number,
            begin_interval_time,
            end_interval_time,
            redo_generated / (1024*1024) AS redo_mb,
            EXTRACT(DAY FROM (end_interval_time - begin_interval_time)) * 86400 + 
            EXTRACT(HOUR FROM (end_interval_time - begin_interval_time)) * 3600 + 
            EXTRACT(MINUTE FROM (end_interval_time - begin_interval_time)) * 60 + 
            EXTRACT(SECOND FROM (end_interval_time - begin_interval_time)) AS interval_seconds
        FROM 
            redo_stats
        WHERE 
            redo_generated > 0
    )
    SELECT 
        instance_number,
        TO_CHAR(begin_interval_time, 'YYYY-MM-DD HH24:MI') AS snapshot_time,
        ROUND(redo_mb, 2) AS redo_generated_mb,
        ROUND(interval_seconds / 60, 2) AS interval_minutes,
        ROUND(redo_mb / NULLIF(interval_seconds, 0), 2) AS redo_rate_mb_per_sec,
        ROUND(redo_mb * 60 / NULLIF(interval_seconds, 0), 2) AS redo_rate_mb_per_min
    FROM 
        redo_rates
    WHERE 
        redo_mb / NULLIF(interval_seconds, 0) > 1  -- More than 1 MB/sec
    ORDER BY 
        redo_rate_mb_per_sec DESC
    FETCH FIRST 100 ROWS ONLY
    """


# Need to fix - BLC - 9/30/2025
# ORA-00942: table or view "SYSTEM"."DBA_HIST_PX_PROCESS_SYSSTAT" does not exist
def get_peak_parallel_execution():
    return """
    -- Peak parallel execution utilization
    WITH px_stats AS (
        SELECT 
            s.instance_number,
            s.begin_interval_time,
            ps.statistic,
            ps.value - LAG(ps.value) OVER (
                PARTITION BY s.instance_number, ps.statistic 
                ORDER BY s.snap_id
            ) AS delta_value
        FROM 
            dba_hist_px_process_sysstat ps
            JOIN dba_hist_snapshot s ON ps.snap_id = s.snap_id
                AND ps.dbid = s.dbid
                AND ps.instance_number = s.instance_number
        WHERE 
            s.begin_interval_time >= SYSDATE - 30
            AND ps.statistic IN (
                'Servers In Use',
                'Servers Available',
                'Servers Started',
                'Servers Shutdown',
                'Servers Highwater',
                'Server Sessions',
                'Servers Cleaned Up'
            )
    ),
    px_peaks AS (
        SELECT 
            instance_number,
            TRUNC(begin_interval_time) AS peak_date,
            statistic,
            MAX(delta_value) AS peak_value
        FROM 
            px_stats
        WHERE 
            delta_value >= 0
        GROUP BY 
            instance_number,
            TRUNC(begin_interval_time),
            statistic
    )
    SELECT 
        instance_number,
        TO_CHAR(peak_date, 'YYYY-MM-DD') AS date_str,
        MAX(CASE WHEN statistic = 'Servers In Use' THEN peak_value END) AS peak_servers_in_use,
        MAX(CASE WHEN statistic = 'Servers Available' THEN peak_value END) AS servers_available,
        MAX(CASE WHEN statistic = 'Servers Started' THEN peak_value END) AS servers_started,
        MAX(CASE WHEN statistic = 'Servers Highwater' THEN peak_value END) AS servers_highwater,
        MAX(CASE WHEN statistic = 'Server Sessions' THEN peak_value END) AS server_sessions
    FROM 
        px_peaks
    GROUP BY 
        instance_number,
        peak_date
    HAVING 
        MAX(CASE WHEN statistic = 'Servers In Use' THEN peak_value END) > 0
    ORDER BY 
        instance_number,
        peak_date DESC
    """

def get_peak_temp_usage():
    return """
    -- Peak temporary tablespace usage
   WITH temp_usage AS (
        SELECT 
            su.inst_id,
            su.tablespace,
            su.username,
            su.session_addr,
            su.sql_id,
            SUM(su.blocks * ts.block_size) / (1024*1024*1024) AS used_gb,
            COUNT(DISTINCT su.session_num) AS session_count,
            COUNT(*) AS segment_count
        FROM 
            gv$sort_usage su
            JOIN dba_tablespaces ts ON su.tablespace = ts.tablespace_name
        WHERE 
            ts.contents = 'TEMPORARY'
        GROUP BY 
            su.inst_id,
            su.tablespace,
            su.username,
            su.session_addr,
            su.sql_id
    )
    SELECT 
        inst_id AS instance_number,
        tablespace,
        COUNT(DISTINCT username) AS active_users,
        COUNT(DISTINCT session_addr) AS active_sessions,
        COUNT(DISTINCT sql_id) AS distinct_sql_ids,
        ROUND(SUM(used_gb), 2) AS total_used_gb,
        ROUND(MAX(used_gb), 2) AS max_single_session_gb,
        ROUND(AVG(used_gb), 2) AS avg_per_session_gb
    FROM 
        temp_usage
    GROUP BY 
        inst_id,
        tablespace
    ORDER BY 
        total_used_gb DESC
    """

def get_peak_transaction_rate():
    return """
    -- Peak transaction rates
    SELECT
        m.instance_number,
        TO_CHAR(m.begin_time, 'YYYY-MM-DD HH24:MI') AS snapshot_time,
        TO_CHAR(m.begin_time, 'DY') AS day_of_week,
        EXTRACT(HOUR FROM m.begin_time) AS hour_of_day,
        MAX(CASE WHEN m.metric_name = 'User Transaction Per Sec' THEN m.maxval END) AS peak_tps,
        MAX(CASE WHEN m.metric_name = 'User Commits Per Sec' THEN m.maxval END) AS peak_commits_per_sec,
        MAX(CASE WHEN m.metric_name = 'User Rollbacks Per Sec' THEN m.maxval END) AS peak_rollbacks_per_sec,
        MAX(CASE WHEN m.metric_name = 'Executions Per Sec' THEN m.maxval END) AS peak_exec_per_sec,
        MAX(CASE WHEN m.metric_name = 'User Calls Per Sec' THEN m.maxval END) AS peak_calls_per_sec,
        MAX(CASE WHEN m.metric_name = 'Logons Per Sec' THEN m.maxval END) AS peak_logons_per_sec
    FROM
        dba_hist_sysmetric_summary m
    WHERE
        m.begin_time >= SYSDATE - 30
        AND m.metric_name IN (
            'User Transaction Per Sec',
            'User Commits Per Sec',
            'User Rollbacks Per Sec',
            'Executions Per Sec',
            'User Calls Per Sec',
            'Logons Per Sec'
        )
    GROUP BY
        m.instance_number,
        m.begin_time
    ORDER BY
        peak_tps DESC NULLS LAST
    FETCH FIRST 100 ROWS ONLY
    """

#Backup Information
def get_rman_backup_summary():
    return """
    -- RMAN backup summary and performance
    SELECT 
        session_key,
        session_recid,
        session_stamp,
        TO_CHAR(start_time, 'YYYY-MM-DD HH24:MI:SS') AS start_time,
        TO_CHAR(end_time, 'YYYY-MM-DD HH24:MI:SS') AS end_time,
        ROUND((end_time - start_time) * 24 * 60, 2) AS duration_minutes,
        input_type,
        status,
        --operation,
        --object_type,
        ROUND(input_bytes / (1024*1024*1024), 2) AS input_gb,
        ROUND(output_bytes / (1024*1024*1024), 2) AS output_gb,
        output_device_type,
        ROUND(compression_ratio, 2) AS compression_ratio,
        ROUND(input_bytes_per_sec / (1024*1024), 2) AS input_rate_mb_per_sec,
        ROUND(output_bytes_per_sec / (1024*1024), 2) AS output_rate_mb_per_sec,
        time_taken_display
    FROM 
        v$rman_backup_job_details
    WHERE 
        start_time >= SYSDATE - 30  -- Last 30 days
    ORDER BY 
        start_time DESC
    """

def get_rman_backup_set_details():
    return """
    -- RMAN backup set details and performance
    SELECT 
        bs.inst_id,
        bs.recid,
        bs.stamp,
        TO_CHAR(bs.start_time, 'YYYY-MM-DD HH24:MI:SS') AS start_time,
        TO_CHAR(bs.completion_time, 'YYYY-MM-DD HH24:MI:SS') AS completion_time,
        ROUND((bs.completion_time - bs.start_time) * 24 * 60, 2) AS duration_minutes,
        bs.backup_type,
        bs.incremental_level,
        bs.pieces,
        bs.elapsed_seconds
    FROM 
        gv$backup_set bs
    WHERE 
        bs.start_time >= SYSDATE - 30
    ORDER BY 
        bs.start_time DESC
    """

def get_rman_backup_piece_details():
    return """
    -- RMAN backup piece details
    SELECT 
        bp.recid,
        bp.stamp,
        bp.set_stamp,
        bp.set_count,
        bp.piece#,
        TO_CHAR(bp.start_time, 'YYYY-MM-DD HH24:MI:SS') AS start_time,
        TO_CHAR(bp.completion_time, 'YYYY-MM-DD HH24:MI:SS') AS completion_time,
        ROUND((bp.completion_time - bp.start_time) * 24 * 60, 2) AS duration_minutes,
        bp.handle,
        bp.device_type,
        ROUND(bp.bytes / (1024*1024*1024), 2) AS piece_size_gb,
        bp.compressed,
        bp.encrypted,
        bp.status,
        bp.media,
        bp.tag
    FROM 
        v$backup_piece bp
    WHERE 
        bp.start_time >= SYSDATE - 7  -- Last 7 days
        AND bp.status = 'A'  -- Available pieces
    ORDER BY 
        bp.start_time DESC
    """

def get_archive_log_backup_history():
    return """
    -- Archive log backup history
    SELECT 
        al.recid,
        al.stamp,
        TO_CHAR(al.first_time, 'YYYY-MM-DD HH24:MI:SS') AS first_time,
        TO_CHAR(al.completion_time, 'YYYY-MM-DD HH24:MI:SS') AS completion_time,
        al.thread#,
        al.sequence#,
        al.resetlogs_change#,
        al.first_change#,
        al.next_change#,
        ROUND(al.blocks * al.block_size / (1024*1024), 2) AS size_mb,
        al.archived,
        al.applied,
        al.deleted,
        al.status,
        al.backup_count,
        al.is_recovery_dest_file,
        al.compressed
    FROM 
        v$archived_log al
    WHERE 
        al.first_time >= SYSDATE - 7
        AND al.backup_count > 0  -- Only backed up logs
    ORDER BY 
        al.first_time DESC
    """

def get_recovery_file_dest_usage():
    return """
    -- Fast Recovery Area (FRA) usage
    SELECT 
        name,
        ROUND(space_limit / (1024*1024*1024), 2) AS space_limit_gb,
        ROUND(space_used / (1024*1024*1024), 2) AS space_used_gb,
        ROUND(space_reclaimable / (1024*1024*1024), 2) AS space_reclaimable_gb,
        ROUND((space_used - space_reclaimable) / (1024*1024*1024), 2) AS actual_used_gb,
        number_of_files,
        ROUND(100 * space_used / NULLIF(space_limit, 0), 2) AS used_pct,
        ROUND(100 * (space_used - space_reclaimable) / NULLIF(space_limit, 0), 2) AS actual_used_pct
    FROM 
        v$recovery_file_dest
    """

def get_fra_usage_by_file_type():
    return """
    -- FRA usage breakdown by file type
    SELECT 
        file_type,
        percent_space_used,
        percent_space_reclaimable,
        number_of_files,
        con_id
    FROM 
        v$recovery_area_usage
    WHERE 
        percent_space_used > 0
    ORDER BY 
        percent_space_used DESC
    """

def get_datafile_recovery_status():
    return """
    -- Datafile recovery status and metrics
    SELECT 
        d.file#,
        d.name,
        d.status,
        d.enabled,
        TO_CHAR(d.creation_time, 'YYYY-MM-DD HH24:MI:SS') AS creation_time,
        TO_CHAR(d.checkpoint_time, 'YYYY-MM-DD HH24:MI:SS') AS checkpoint_time,
        d.checkpoint_change#,
        TO_CHAR(d.last_time, 'YYYY-MM-DD HH24:MI:SS') AS last_time,
        d.last_change#,
        --TO_CHAR(d.offline_time, 'YYYY-MM-DD HH24:MI:SS') AS offline_time,
        d.offline_change#,
        TO_CHAR(d.online_time, 'YYYY-MM-DD HH24:MI:SS') AS online_time,
        d.online_change#,
        ROUND(d.bytes / (1024*1024*1024), 2) AS size_gb,
        d.blocks,
        d.block_size,
        r.error,
        TO_CHAR(r.time, 'YYYY-MM-DD HH24:MI:SS') AS recovery_time,
        r.change#
    FROM 
        gv$datafile d
        LEFT JOIN gv$recover_file r ON d.file# = r.file#
    ORDER BY 
        d.file#
    """

def get_restore_point_info():
    return """
    -- Restore points information
    SELECT 
        inst_id,
        name,
        scn,
        TO_CHAR(time, 'YYYY-MM-DD HH24:MI:SS') AS time,
        database_incarnation#,
        guarantee_flashback_database,
        storage_size / (1024*1024*1024) AS storage_size_gb,
        preserved,
        --replicated,
        con_id
    FROM 
        gv$restore_point
    ORDER BY 
        scn DESC
    """

def get_flashback_database_log():
    return """
    -- Flashback database log information
    SELECT 
        inst_id,
        oldest_flashback_scn,
        TO_CHAR(oldest_flashback_time, 'YYYY-MM-DD HH24:MI:SS') AS oldest_flashback_time,
        retention_target,
        flashback_size / (1024*1024*1024) AS flashback_size_gb,
        estimated_flashback_size / (1024*1024*1024) AS estimated_flashback_size_gb,
        con_id
    FROM 
        gv$flashback_database_log
    """

def get_backup_corruption():
    return """
    -- Check for backup corruption
    SELECT 
        inst_id,
        recid,
        stamp,
        set_stamp,
        set_count,
        piece#,
        file#,
        block#,
        blocks,
        corruption_change#,
        marked_corrupt,
        corruption_type
    FROM 
        gv$backup_corruption
    ORDER BY 
        stamp DESC
    """

def get_rman_configuration():
    return """
    -- RMAN configuration settings
    SELECT 
        conf#,
        name,
        value
    FROM 
        v$rman_configuration
    ORDER BY 
        conf#
    """

def get_rman_backup_performance_history():
    return """
    -- RMAN backup performance trending
    WITH backup_stats AS (
        SELECT 
            TRUNC(start_time) AS backup_date,
            COUNT(*) AS backup_count,
            AVG(elapsed_seconds) AS avg_duration_seconds,
            MAX(elapsed_seconds) AS max_duration_seconds,
            MIN(elapsed_seconds) AS min_duration_seconds,
            SUM(input_bytes) / (1024*1024*1024) AS total_input_gb,
            SUM(output_bytes) / (1024*1024*1024) AS total_output_gb,
            AVG(compression_ratio) AS avg_compression_ratio,
            AVG(input_bytes_per_sec) / (1024*1024) AS avg_input_mb_per_sec,
            AVG(output_bytes_per_sec) / (1024*1024) AS avg_output_mb_per_sec
        FROM 
            v$rman_backup_job_details
        WHERE 
            start_time >= SYSDATE - 30  -- Last 30 days
            AND status = 'COMPLETED'
        GROUP BY 
            TRUNC(start_time)
    )
    SELECT 
        TO_CHAR(backup_date, 'YYYY-MM-DD') AS date_str,
        TO_CHAR(backup_date, 'DY') AS day_of_week,
        backup_count,
        ROUND(avg_duration_seconds / 60, 2) AS avg_duration_minutes,
        ROUND(max_duration_seconds / 60, 2) AS max_duration_minutes,
        ROUND(total_input_gb, 2) AS total_input_gb,
        ROUND(total_output_gb, 2) AS total_output_gb,
        ROUND(avg_compression_ratio, 2) AS avg_compression_ratio,
        ROUND(avg_input_mb_per_sec, 2) AS avg_input_mb_per_sec,
        ROUND(avg_output_mb_per_sec, 2) AS avg_output_mb_per_sec
    FROM 
        backup_stats
    ORDER BY 
        backup_date DESC
    """

def get_recovery_progress():
    return """
    -- Media recovery progress (if recovery is running)
    SELECT 
        TO_CHAR(start_time, 'YYYY-MM-DD HH24:MI:SS') AS start_time,
        type,
        item,
        units,
        sofar,
        total,
        TO_CHAR(timestamp, 'YYYY-MM-DD HH24:MI:SS') AS timestamp,
        ROUND(100 * sofar / NULLIF(total, 0), 2) AS percent_complete,
        comments
    FROM 
        v$recovery_progress
    ORDER BY 
        start_time DESC,
        item
    """

def get_block_change_tracking():
    return """
    -- Block change tracking status (for incremental backups)
    SELECT 
        status,
        filename,
        ROUND(bytes / (1024*1024), 2) AS size_mb,
        con_id
    FROM 
        v$block_change_tracking
    """

def get_database_incarnation():
    return """
    -- Database incarnation history
    SELECT 
        incarnation#,
        resetlogs_change#,
        TO_CHAR(resetlogs_time, 'YYYY-MM-DD HH24:MI:SS') AS resetlogs_time,
        prior_resetlogs_change#,
        TO_CHAR(prior_resetlogs_time, 'YYYY-MM-DD HH24:MI:SS') AS prior_resetlogs_time,
        status,
        resetlogs_id,
        prior_incarnation#,
        flashback_database_allowed
    FROM 
        v$database_incarnation
    ORDER BY 
        incarnation# DESC
    """

#Network I/O patterns
def get_network_service_stats():
    return """
    -- Network service statistics
    SELECT 
        inst_id,
        service_name,
        stat_name,
        value,
        CASE 
            WHEN stat_name LIKE '%bytes%' THEN ROUND(value / (1024*1024), 2) || ' MB'
            WHEN stat_name LIKE '%time%' THEN ROUND(value / 1000000, 2) || ' sec'
            ELSE TO_CHAR(value)
        END AS formatted_value
    FROM 
        gv$service_stats
    WHERE 
        stat_name IN (
            'sql*net bytes received from client',
            'sql*net bytes sent to client',
            'sql*net bytes received from dblink',
            'sql*net bytes sent to dblink',
            'sql*net roundtrips to/from client',
            'sql*net roundtrips to/from dblink'
        )
        AND service_name NOT IN ('SYS$BACKGROUND', 'SYS$USERS')
    ORDER BY 
        inst_id,
        service_name,
        stat_name
    """

def get_sqlnet_client_stats():
    return """
    -- SQL*Net client connection statistics
    SELECT 
        inst_id,
        sid,
        username,
        program,
        machine,
        osuser,
        -- Network statistics from v$sesstat
        SUM(CASE WHEN stat_name = 'bytes sent via SQL*Net to client' THEN value END) AS bytes_sent,
        SUM(CASE WHEN stat_name = 'bytes received via SQL*Net from client' THEN value END) AS bytes_received,
        SUM(CASE WHEN stat_name = 'SQL*Net roundtrips to/from client' THEN value END) AS roundtrips,
        SUM(CASE WHEN stat_name = 'bytes sent via SQL*Net to dblink' THEN value END) AS dblink_bytes_sent,
        SUM(CASE WHEN stat_name = 'bytes received via SQL*Net from dblink' THEN value END) AS dblink_bytes_received,
        SUM(CASE WHEN stat_name = 'SQL*Net roundtrips to/from dblink' THEN value END) AS dblink_roundtrips,
        -- Calculate totals and rates
        ROUND((SUM(CASE WHEN stat_name = 'bytes sent via SQL*Net to client' THEN value END) + 
               SUM(CASE WHEN stat_name = 'bytes received via SQL*Net from client' THEN value END)) / (1024*1024), 2) AS total_mb,
        ROUND(SUM(CASE WHEN stat_name = 'bytes sent via SQL*Net to client' THEN value END) / 
              NULLIF(SUM(CASE WHEN stat_name = 'SQL*Net roundtrips to/from client' THEN value END), 0), 2) AS avg_bytes_per_roundtrip
    FROM (
        SELECT 
            s.inst_id,
            s.sid,
            s.username,
            s.program,
            s.machine,
            s.osuser,
            n.name AS stat_name,
            ss.value
        FROM 
            gv$session s
            JOIN gv$sesstat ss ON s.inst_id = ss.inst_id AND s.sid = ss.sid
            JOIN v$statname n ON ss.statistic# = n.statistic#
        WHERE 
            s.type = 'USER'
            AND s.username IS NOT NULL
            AND n.name IN (
                'bytes sent via SQL*Net to client',
                'bytes received via SQL*Net from client',
                'SQL*Net roundtrips to/from client',
                'bytes sent via SQL*Net to dblink',
                'bytes received via SQL*Net from dblink',
                'SQL*Net roundtrips to/from dblink'
            )
    )
    GROUP BY 
        inst_id,
        sid,
        username,
        program,
        machine,
        osuser
    HAVING 
        SUM(CASE WHEN stat_name IN ('bytes sent via SQL*Net to client', 
                                    'bytes received via SQL*Net from client') THEN value END) > 0
    ORDER BY 
        total_mb DESC
    """

def get_network_wait_events():
    return """
    -- Network-related wait events
    SELECT 
        inst_id,
        event,
        total_waits,
        total_timeouts,
        time_waited AS time_waited_cs,
        ROUND(time_waited / 100, 2) AS time_waited_sec,
        average_wait AS avg_wait_cs,
        ROUND(average_wait * 10, 2) AS avg_wait_ms,
        wait_class
    FROM 
        gv$system_event
    WHERE 
        event IN (
            'SQL*Net message to client',
            'SQL*Net message from client',
            'SQL*Net more data to client',
            'SQL*Net more data from client',
            'SQL*Net message to dblink',
            'SQL*Net message from dblink',
            'SQL*Net more data to dblink',
            'SQL*Net more data from dblink',
            'SQL*Net break/reset to client',
            'SQL*Net break/reset to dblink'
        )
        AND total_waits > 0
    ORDER BY 
        inst_id,
        time_waited DESC
    """

def get_network_throughput_history():
    return """
    -- Network throughput history from AWR
    WITH network_stats AS (
        SELECT 
            s.instance_number,
            s.snap_id,
            s.begin_interval_time,
            s.end_interval_time,
            st.stat_name,
            st.value - LAG(st.value) OVER (
                PARTITION BY s.instance_number, st.stat_name 
                ORDER BY s.snap_id
            ) AS delta_value
        FROM 
            dba_hist_sysstat st
            JOIN dba_hist_snapshot s ON st.snap_id = s.snap_id
                AND st.dbid = s.dbid
                AND st.instance_number = s.instance_number
        WHERE 
            s.begin_interval_time >= SYSDATE - 7  -- Last 7 days
            AND st.stat_name IN (
                'bytes sent via SQL*Net to client',
                'bytes received via SQL*Net from client',
                'SQL*Net roundtrips to/from client',
                'bytes sent via SQL*Net to dblink',
                'bytes received via SQL*Net from dblink',
                'SQL*Net roundtrips to/from dblink'
            )
    )
    SELECT 
        instance_number,
        TO_CHAR(begin_interval_time, 'YYYY-MM-DD HH24:MI') AS snapshot_time,
        ROUND(EXTRACT(DAY FROM (end_interval_time - begin_interval_time)) * 86400 + 
              EXTRACT(HOUR FROM (end_interval_time - begin_interval_time)) * 3600 + 
              EXTRACT(MINUTE FROM (end_interval_time - begin_interval_time)) * 60 + 
              EXTRACT(SECOND FROM (end_interval_time - begin_interval_time)), 0) AS interval_seconds,
        -- Client network stats
        ROUND(SUM(CASE WHEN stat_name = 'bytes sent via SQL*Net to client' THEN delta_value END) / (1024*1024), 2) AS client_sent_mb,
        ROUND(SUM(CASE WHEN stat_name = 'bytes received via SQL*Net from client' THEN delta_value END) / (1024*1024), 2) AS client_received_mb,
        SUM(CASE WHEN stat_name = 'SQL*Net roundtrips to/from client' THEN delta_value END) AS client_roundtrips,
        -- DBLink network stats
        ROUND(SUM(CASE WHEN stat_name = 'bytes sent via SQL*Net to dblink' THEN delta_value END) / (1024*1024), 2) AS dblink_sent_mb,
        ROUND(SUM(CASE WHEN stat_name = 'bytes received via SQL*Net from dblink' THEN delta_value END) / (1024*1024), 2) AS dblink_received_mb,
        SUM(CASE WHEN stat_name = 'SQL*Net roundtrips to/from dblink' THEN delta_value END) AS dblink_roundtrips,
        -- Calculate rates
        ROUND(SUM(CASE WHEN stat_name IN ('bytes sent via SQL*Net to client', 'bytes received via SQL*Net from client') 
                  THEN delta_value END) / (1024*1024) / 
              NULLIF(EXTRACT(DAY FROM (end_interval_time - begin_interval_time)) * 86400 + 
                     EXTRACT(HOUR FROM (end_interval_time - begin_interval_time)) * 3600 + 
                     EXTRACT(MINUTE FROM (end_interval_time - begin_interval_time)) * 60 + 
                     EXTRACT(SECOND FROM (end_interval_time - begin_interval_time)), 0), 2) AS mb_per_sec
    FROM 
        network_stats
    WHERE 
        delta_value >= 0  -- Filter out negative deltas from restarts
    GROUP BY 
        instance_number,
        begin_interval_time,
        end_interval_time
    ORDER BY 
        instance_number,
        begin_interval_time DESC
    """

#Needs to be relooked - BLC - 09/30/2025
def get_distributed_transaction_stats():
    return """
    -- Distributed transaction statistics
    SELECT
        inst_id,
        globalid,
        state,
        formatid,
        branchid
    FROM
        gv$global_transaction
    ORDER BY
        inst_id
    """

def get_dblink_usage():
    return """
    -- Database link usage and performance
    WITH dblink_stats AS (
        SELECT 
            s.inst_id,
            s.sid,
            s.username,
            s.program,
            s.machine,
            n.name AS stat_name,
            ss.value
        FROM 
            gv$session s
            JOIN gv$sesstat ss ON s.inst_id = ss.inst_id AND s.sid = ss.sid
            JOIN v$statname n ON ss.statistic# = n.statistic#
        WHERE 
            s.type = 'USER'
            AND n.name IN (
                'bytes sent via SQL*Net to dblink',
                'bytes received via SQL*Net from dblink',
                'SQL*Net roundtrips to/from dblink',
                'DBLINK network round trips',
                'calls to kcmgas',
                'calls to kcmgrs'
            )
            AND ss.value > 0
    )
    SELECT 
        inst_id,
        username,
        program,
        machine,
        SUM(CASE WHEN stat_name = 'bytes sent via SQL*Net to dblink' THEN value END) AS dblink_bytes_sent,
        SUM(CASE WHEN stat_name = 'bytes received via SQL*Net from dblink' THEN value END) AS dblink_bytes_received,
        SUM(CASE WHEN stat_name = 'SQL*Net roundtrips to/from dblink' THEN value END) AS dblink_roundtrips,
        SUM(CASE WHEN stat_name = 'DBLINK network round trips' THEN value END) AS dblink_network_trips,
        ROUND((SUM(CASE WHEN stat_name = 'bytes sent via SQL*Net to dblink' THEN value END) + 
               SUM(CASE WHEN stat_name = 'bytes received via SQL*Net from dblink' THEN value END)) / (1024*1024), 2) AS total_dblink_mb
    FROM 
        dblink_stats
    GROUP BY 
        inst_id,
        username,
        program,
        machine
    HAVING 
        SUM(CASE WHEN stat_name LIKE '%dblink%' THEN value END) > 0
    ORDER BY 
        total_dblink_mb DESC NULLS LAST
    """

def get_parallel_query_network():
    return """
    -- Parallel query network statistics
    SELECT 
        qc.inst_id AS qc_inst_id,
        qc.sid AS qc_sid,
        qc.username,
        qc.sql_id,
        px.inst_id AS px_inst_id,
        COUNT(DISTINCT px.sid) AS parallel_servers,
        SUM(stat.value) AS total_bytes_exchanged,
        ROUND(SUM(stat.value) / (1024*1024), 2) AS total_mb_exchanged
    FROM 
        gv$px_session px
        JOIN gv$session qc ON px.qcinst_id = qc.inst_id AND px.qcsid = qc.sid
        LEFT JOIN gv$sesstat stat ON px.inst_id = stat.inst_id AND px.sid = stat.sid
        LEFT JOIN v$statname n ON stat.statistic# = n.statistic#
    WHERE 
        n.name IN ('bytes sent via SQL*Net to client', 'bytes received via SQL*Net from client')
        AND qc.username IS NOT NULL
    GROUP BY 
        qc.inst_id,
        qc.sid,
        qc.username,
        qc.sql_id,
        px.inst_id
    HAVING 
        COUNT(px.sid) > 0
    ORDER BY 
        total_mb_exchanged DESC
    """

def get_network_latency_histogram():
    return """
    -- Network wait event latency histogram
    SELECT 
        inst_id,
        event,
        wait_time_milli,
        wait_count,
        SUM(wait_count) OVER (
            PARTITION BY inst_id, event 
            ORDER BY wait_time_milli
        ) AS cumulative_count,
        ROUND(100 * RATIO_TO_REPORT(wait_count) OVER (
            PARTITION BY inst_id, event
        ), 2) AS pct_of_waits
    FROM 
        gv$event_histogram
    WHERE 
        event IN (
            'SQL*Net message from client',
            'SQL*Net message to client',
            'SQL*Net more data from client',
            'SQL*Net more data to client'
        )
    ORDER BY 
        inst_id,
        event,
        wait_time_milli
    """

def get_active_network_sessions():
    return """
    -- Currently active sessions with network I/O
    SELECT 
        s.inst_id,
        s.sid,
        s.serial#,
        s.username,
        s.program,
        s.machine,
        s.osuser,
        s.event,
        s.wait_class,
        s.seconds_in_wait,
        s.state,
        sq.sql_text,
        ROUND(io.block_gets * 8 / 1024, 2) AS block_gets_mb,
        ROUND(io.consistent_gets * 8 / 1024, 2) AS consistent_gets_mb,
        ROUND(io.physical_reads * 8 / 1024, 2) AS physical_reads_mb
    FROM 
        gv$session s
        LEFT JOIN gv$sql sq ON s.inst_id = sq.inst_id AND s.sql_id = sq.sql_id 
            AND s.sql_child_number = sq.child_number
        LEFT JOIN gv$sess_io io ON s.inst_id = io.inst_id AND s.sid = io.sid
    WHERE 
        s.event LIKE 'SQL*Net%'
        AND s.type = 'USER'
        AND s.username IS NOT NULL
    ORDER BY 
        s.seconds_in_wait DESC
    """

def get_network_metrics_summary():
    return """
    -- Network metrics summary from system metrics
    SELECT 
        inst_id,
        metric_name,
        ROUND(value, 2) AS current_value,
        metric_unit
    FROM 
        gv$sysmetric
    WHERE 
        metric_name IN (
            'Network Traffic Volume Per Sec',
            'Network Bytes Per Sec',
            'Average Synchronous Single-Block Read Latency'
        )
        AND group_id = 2  -- 60-second interval
    ORDER BY 
        inst_id,
        metric_name
    """


# Needs to be reviewed - BLC - 09/30/2025
def get_connection_pool_stats():
    return """
    -- Connection pool statistics (if using connection pooling)
    SELECT
        pool_name,
        num_open_servers,
        num_busy_servers,
        num_auth_servers,
        num_requests,
        num_hits,
        num_misses,
        num_waits,
        --wait_count,
        client_req_timeouts,
        wait_time
    FROM
        v$cpool_stats
    ORDER BY
        pool_name
    """

def get_peak_network_usage():
    return """
    -- Peak network usage periods from AWR
    WITH network_deltas AS (
        SELECT 
            s.instance_number,
            s.snap_id,
            s.begin_interval_time,
            st.stat_name,
            st.value,
            st.value - LAG(st.value) OVER (
                PARTITION BY s.instance_number, st.stat_name 
                ORDER BY s.snap_id
            ) AS delta_value
        FROM 
            dba_hist_sysstat st
            JOIN dba_hist_snapshot s ON st.snap_id = s.snap_id
                AND st.dbid = s.dbid
                AND st.instance_number = s.instance_number
        WHERE 
            s.begin_interval_time >= SYSDATE - 30
            AND st.stat_name IN (
                'bytes sent via SQL*Net to client',
                'bytes received via SQL*Net from client'
            )
    ),
    network_peaks AS (
        SELECT 
            instance_number,
            TRUNC(begin_interval_time, 'HH24') AS hour_period,
            SUM(CASE 
                WHEN delta_value > 0 THEN delta_value 
                ELSE 0 
            END) / (1024*1024*1024) AS network_gb
        FROM 
            network_deltas
        GROUP BY 
            instance_number,
            TRUNC(begin_interval_time, 'HH24')
    )
    SELECT 
        instance_number,
        TO_CHAR(hour_period, 'YYYY-MM-DD HH24') AS hour,
        ROUND(network_gb, 2) AS network_gb,
        DENSE_RANK() OVER (ORDER BY network_gb DESC) AS rank
    FROM 
        network_peaks
    WHERE 
        network_gb > 0
    ORDER BY 
        network_gb DESC
    FETCH FIRST 50 ROWS ONLY
    """

def get_table_statistics():
    return """
    SELECT 
    owner,
    table_name,
    COALESCE(num_rows, 0) as num_rows,
    COALESCE(TO_CHAR(last_analyzed, 'YYYY-MM-DD HH24:MI:SS'), 'Never Analyzed') as last_analyzed,
    COALESCE(ROUND(SYSDATE - last_analyzed), 999999) as days_since_analyzed,
    COALESCE(stale_stats, 'UNKNOWN') as stale_stats,
    con_id
FROM cdb_tab_statistics
WHERE owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
  AND partition_name IS NULL
ORDER BY owner, 
         CASE WHEN last_analyzed IS NULL THEN 0 ELSE 1 END,
         last_analyzed
"""

def get_index_statistics():
    return """
    SELECT 
    table_owner,
    table_name,
    index_name,
    COALESCE(num_rows, 0) as num_rows,
    COALESCE(TO_CHAR(last_analyzed, 'YYYY-MM-DD HH24:MI:SS'), 'Never Analyzed') as last_analyzed,
    COALESCE(ROUND(SYSDATE - last_analyzed), 999999) as days_since_analyzed,
    COALESCE(stale_stats, 'UNKNOWN') as stale_stats
FROM DBA_IND_STATISTICS
WHERE owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
  AND partition_name IS NULL
ORDER BY owner, 
         CASE WHEN last_analyzed IS NULL THEN 0 ELSE 1 END,
         last_analyzed
"""

def get_table_modifications():
    return """
    select * from cdb_tab_modifications
        WHERE table_owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
        and timestamp >= sysdate - 30
    """


# ============================================================
# SCHEMA COMPATIBILITY CHECKS
# These queries identify potential migration compatibility issues
# ============================================================

def get_compatibility_summary():
    """Generate overall compatibility summary with counts by category."""
    return """
    SELECT
        'Unsupported Data Types' AS check_category,
        COUNT(*) AS issue_count,
        CASE WHEN COUNT(*) > 0 THEN 'ACTION REQUIRED' ELSE 'PASSING' END AS status
    FROM dba_tab_columns
    WHERE owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
    AND data_type IN ('SDO_GEOMETRY','SDO_TOPO_GEOMETRY','SDO_GEORASTER','XMLTYPE','SYS.XMLTYPE','BFILE','LONG','LONG RAW','ROWID','UROWID','ANYDATA','ANYTYPE','ANYDATASET','ORDAUDIO','ORDVIDEO','ORDDOC','ORDIMAGE','ORDDICOM')
    UNION ALL
    SELECT
        'Clustered Tables' AS check_category,
        COUNT(*) AS issue_count,
        CASE WHEN COUNT(*) > 0 THEN 'ACTION REQUIRED' ELSE 'PASSING' END AS status
    FROM dba_tables
    WHERE cluster_name IS NOT NULL
    AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
    UNION ALL
    SELECT
        'Index Organized Tables' AS check_category,
        COUNT(*) AS issue_count,
        CASE WHEN COUNT(*) > 0 THEN 'REVIEW SUGGESTED' ELSE 'PASSING' END AS status
    FROM dba_tables
    WHERE iot_type IS NOT NULL
    AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
    UNION ALL
    SELECT
        'Java Objects' AS check_category,
        COUNT(*) AS issue_count,
        CASE WHEN COUNT(*) > 0 THEN 'REVIEW REQUIRED' ELSE 'PASSING' END AS status
    FROM dba_objects
    WHERE object_type LIKE 'JAVA%'
    AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
    UNION ALL
    SELECT
        'External Tables' AS check_category,
        COUNT(*) AS issue_count,
        CASE WHEN COUNT(*) > 0 THEN 'REVIEW REQUIRED' ELSE 'PASSING' END AS status
    FROM dba_external_tables
    WHERE owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
    UNION ALL
    SELECT
        'Database Links' AS check_category,
        COUNT(*) AS issue_count,
        CASE WHEN COUNT(*) > 0 THEN 'REVIEW REQUIRED' ELSE 'PASSING' END AS status
    FROM dba_db_links
    WHERE owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
    UNION ALL
    SELECT
        'BASICFILE LOBs' AS check_category,
        COUNT(*) AS issue_count,
        CASE WHEN COUNT(*) > 0 THEN 'REVIEW SUGGESTED' ELSE 'PASSING' END AS status
    FROM dba_lobs
    WHERE securefile = 'NO'
    AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
    UNION ALL
    SELECT
        'Tables Without Primary Key' AS check_category,
        COUNT(*) AS issue_count,
        CASE WHEN COUNT(*) > 0 THEN 'REVIEW SUGGESTED' ELSE 'PASSING' END AS status
    FROM dba_tables t
    WHERE NOT EXISTS (
        SELECT 1 FROM dba_constraints c
        WHERE c.owner = t.owner
        AND c.table_name = t.table_name
        AND c.constraint_type = 'P'
    )
    AND t.owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
    AND t.num_rows > 0
    UNION ALL
    SELECT
        'Directory Objects' AS check_category,
        COUNT(*) AS issue_count,
        CASE WHEN COUNT(*) > 0 THEN 'REVIEW REQUIRED' ELSE 'PASSING' END AS status
    FROM dba_directories
    WHERE owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
    UNION ALL
    SELECT
        'Libraries (External Procedures)' AS check_category,
        COUNT(*) AS issue_count,
        CASE WHEN COUNT(*) > 0 THEN 'ACTION REQUIRED' ELSE 'PASSING' END AS status
    FROM dba_objects
    WHERE object_type = 'LIBRARY'
    AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
    ORDER BY 3, 1
    """


def get_unsupported_datatypes_check():
    """Identify columns with potentially unsupported data types for migration."""
    return """
    SELECT
        owner,
        table_name,
        column_name,
        data_type,
        data_length,
        data_precision,
        data_scale,
        CASE
            WHEN data_type IN ('SDO_GEOMETRY', 'SDO_TOPO_GEOMETRY', 'SDO_GEORASTER') THEN 'SPATIAL'
            WHEN data_type LIKE '%XMLTYPE%' THEN 'XML'
            WHEN data_type = 'BFILE' THEN 'EXTERNAL_FILE'
            WHEN data_type IN ('LONG', 'LONG RAW') THEN 'LEGACY_LONG'
            WHEN data_type IN ('ROWID', 'UROWID') THEN 'ROWID'
            WHEN data_type LIKE 'INTERVAL%' THEN 'INTERVAL'
            WHEN data_type IN ('ANYDATA', 'ANYTYPE', 'ANYDATASET') THEN 'ANYTYPE'
            WHEN data_type LIKE '%TIMESTAMP%LOCAL%' THEN 'LOCAL_TIMEZONE'
            WHEN data_type IN ('ORDAUDIO', 'ORDVIDEO', 'ORDDOC', 'ORDIMAGE', 'ORDDICOM') THEN 'MULTIMEDIA'
            ELSE 'REVIEW'
        END AS compatibility_category,
        CASE
            WHEN data_type IN ('SDO_GEOMETRY', 'SDO_TOPO_GEOMETRY', 'SDO_GEORASTER') THEN 'Spatial types require target platform support verification'
            WHEN data_type LIKE '%XMLTYPE%' THEN 'XMLType requires BINARY storage in ADB; CLOB/Object-Relational storage not supported'
            WHEN data_type = 'BFILE' THEN 'BFILE references external files - not supported in cloud'
            WHEN data_type IN ('LONG', 'LONG RAW') THEN 'LONG/LONG RAW deprecated - convert to LOB'
            WHEN data_type IN ('ROWID', 'UROWID') THEN 'ROWID values will change after migration'
            WHEN data_type IN ('ANYDATA', 'ANYTYPE', 'ANYDATASET') THEN 'Generic types may have limited support'
            WHEN data_type IN ('ORDAUDIO', 'ORDVIDEO', 'ORDDOC', 'ORDIMAGE', 'ORDDICOM') THEN 'Oracle Multimedia desupported - convert to SecureFiles LOB'
            ELSE 'Review data type compatibility with target platform'
        END AS recommendation
    FROM dba_tab_columns
    WHERE owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
    AND data_type IN (
        'SDO_GEOMETRY', 'SDO_TOPO_GEOMETRY', 'SDO_GEORASTER',
        'XMLTYPE', 'SYS.XMLTYPE',
        'BFILE',
        'LONG', 'LONG RAW',
        'ROWID', 'UROWID',
        'ANYDATA', 'ANYTYPE', 'ANYDATASET',
        'ORDAUDIO', 'ORDVIDEO', 'ORDDOC', 'ORDIMAGE', 'ORDDICOM',
        'TIMESTAMP WITH LOCAL TIME ZONE'
    )
    ORDER BY
        CASE compatibility_category
            WHEN 'LEGACY_LONG' THEN 1
            WHEN 'MULTIMEDIA' THEN 2
            WHEN 'EXTERNAL_FILE' THEN 3
            WHEN 'XML' THEN 4
            WHEN 'SPATIAL' THEN 5
            ELSE 6
        END,
        owner, table_name, column_name
    """


def get_unsupported_objects_check():
    """Identify object types that may not be supported in target environment."""
    return """
    SELECT
        owner,
        object_type,
        object_name,
        status,
        TO_CHAR(created, 'YYYY-MM-DD') AS created,
        TO_CHAR(last_ddl_time, 'YYYY-MM-DD') AS last_ddl_time,
        CASE object_type
            WHEN 'CLUSTER' THEN 'Table clusters not supported - must convert to regular heap tables'
            WHEN 'JAVA SOURCE' THEN 'Java objects require JAVAVM - verify target platform support'
            WHEN 'JAVA CLASS' THEN 'Java objects require JAVAVM - verify target platform support'
            WHEN 'JAVA RESOURCE' THEN 'Java objects require JAVAVM - verify target platform support'
            WHEN 'LIBRARY' THEN 'External libraries (C/C++) not supported in cloud environments'
            WHEN 'INDEXTYPE' THEN 'Custom index types may require recreation or alternative'
            WHEN 'OPERATOR' THEN 'Custom operators may not be supported in target'
            WHEN 'DIRECTORY' THEN 'Directory objects must be recreated with valid paths in target'
            WHEN 'DATABASE LINK' THEN 'Database links require reconfiguration for target environment'
            WHEN 'RULE' THEN 'Rules engine objects may not be supported'
            WHEN 'RULE SET' THEN 'Rules engine objects may not be supported'
            WHEN 'EVALUATION CONTEXT' THEN 'Rules engine objects may not be supported'
            ELSE 'Review object compatibility with target platform'
        END AS recommendation
    FROM dba_objects
    WHERE owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
    AND object_type IN (
        'CLUSTER',
        'JAVA SOURCE', 'JAVA CLASS', 'JAVA RESOURCE',
        'LIBRARY',
        'INDEXTYPE', 'OPERATOR',
        'DIRECTORY',
        'DATABASE LINK',
        'RULE', 'RULE SET', 'EVALUATION CONTEXT'
    )
    ORDER BY
        CASE object_type
            WHEN 'LIBRARY' THEN 1
            WHEN 'CLUSTER' THEN 2
            ELSE 3
        END,
        owner, object_type, object_name
    """


def get_index_organized_tables_check():
    """Identify Index Organized Tables (IOTs) that may need conversion."""
    return """
    SELECT
        t.owner,
        t.table_name,
        t.tablespace_name,
        t.iot_type,
        t.iot_name,
        t.num_rows,
        ROUND(s.bytes / (1024*1024), 2) AS size_mb,
        t.logging,
        t.compression,
        'IOT may be converted to heap table during migration - verify performance requirements' AS recommendation
    FROM dba_tables t
    LEFT JOIN dba_segments s ON t.owner = s.owner AND t.table_name = s.segment_name
    WHERE t.iot_type IS NOT NULL
    AND t.owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
    ORDER BY s.bytes DESC NULLS LAST, t.owner, t.table_name
    """


def get_clustered_tables_check():
    """Identify tables in clusters - not supported in most cloud targets."""
    return """
    SELECT
        t.owner,
        t.table_name,
        t.cluster_name,
        c.tablespace_name,
        t.num_rows,
        ROUND(s.bytes / (1024*1024), 2) AS cluster_size_mb,
        'Clustered tables not supported in cloud - must extract and convert to regular heap tables' AS recommendation
    FROM dba_tables t
    JOIN dba_clusters c ON t.cluster_name = c.cluster_name AND t.owner = c.owner
    LEFT JOIN dba_segments s ON c.owner = s.owner AND c.cluster_name = s.segment_name AND s.segment_type = 'CLUSTER'
    WHERE t.cluster_name IS NOT NULL
    AND t.owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
    ORDER BY s.bytes DESC NULLS LAST, t.owner, t.cluster_name, t.table_name
    """


def get_basicfile_lobs_check():
    """Identify BASICFILE LOBs that will be converted to SECUREFILE during import."""
    return """
    SELECT
        l.owner,
        l.table_name,
        l.column_name,
        l.segment_name,
        l.tablespace_name,
        ROUND(s.bytes / (1024*1024), 2) AS size_mb,
        l.securefile,
        l.compression,
        l.encrypt,
        l.in_row,
        'BASICFILE LOBs will be auto-converted to SECUREFILE during Data Pump import' AS recommendation
    FROM dba_lobs l
    LEFT JOIN dba_segments s ON l.segment_name = s.segment_name AND l.owner = s.owner
    WHERE l.securefile = 'NO'
    AND l.owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
    ORDER BY s.bytes DESC NULLS LAST, l.owner, l.table_name
    """


def get_external_tables_check():
    """Identify external tables - directory paths need adjustment for target."""
    return """
    SELECT
        et.owner,
        et.table_name,
        et.type_name AS access_driver,
        et.default_directory_name,
        d.directory_path,
        et.access_type,
        et.property,
        'External table directory must exist and be accessible in target environment' AS recommendation
    FROM dba_external_tables et
    LEFT JOIN dba_directories d ON et.default_directory_name = d.directory_name
    WHERE et.owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
    ORDER BY et.owner, et.table_name
    """


def get_tables_without_pk_check():
    """Identify tables without primary keys - impacts GoldenGate replication efficiency."""
    return """
    SELECT
        t.owner,
        t.table_name,
        t.num_rows,
        ROUND(s.bytes / (1024*1024), 2) AS size_mb,
        t.partitioned,
        t.logging,
        CASE
            WHEN EXISTS (
                SELECT 1 FROM dba_indexes i
                WHERE i.table_owner = t.owner
                AND i.table_name = t.table_name
                AND i.uniqueness = 'UNIQUE'
            ) THEN 'Has unique index - can use as supplemental log key'
            ELSE 'No unique key - GoldenGate will use full row comparison'
        END AS gg_impact,
        'Consider adding primary key for efficient replication and better performance' AS recommendation
    FROM dba_tables t
    LEFT JOIN dba_segments s ON t.owner = s.owner AND t.table_name = s.segment_name AND s.segment_type = 'TABLE'
    WHERE NOT EXISTS (
        SELECT 1 FROM dba_constraints c
        WHERE c.owner = t.owner
        AND c.table_name = t.table_name
        AND c.constraint_type = 'P'
    )
    AND t.owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
    AND t.num_rows > 0
    AND t.temporary = 'N'
    ORDER BY s.bytes DESC NULLS LAST, t.owner, t.table_name
    """


def get_restricted_package_usage():
    """Identify usage of packages that may be restricted in cloud targets."""
    return """
    SELECT
        d.owner,
        d.name AS object_name,
        d.type AS object_type,
        d.referenced_owner,
        d.referenced_name AS package_name,
        o.status AS object_status,
        CASE d.referenced_name
            WHEN 'UTL_FILE' THEN 'File I/O - not available in ADB Serverless, restricted in Dedicated'
            WHEN 'UTL_TCP' THEN 'TCP sockets - requires ACL configuration, restricted in cloud'
            WHEN 'UTL_HTTP' THEN 'HTTP calls - requires ACL configuration in cloud'
            WHEN 'UTL_SMTP' THEN 'SMTP email - requires ACL configuration in cloud'
            WHEN 'UTL_INADDR' THEN 'Network address resolution - requires ACL in cloud'
            WHEN 'DBMS_PIPE' THEN 'Inter-session pipes - not available in ADB'
            WHEN 'DBMS_ALERT' THEN 'Database alerts - not available in ADB'
            WHEN 'DBMS_DEBUG' THEN 'PL/SQL debugging - not available in cloud'
            WHEN 'DBMS_JAVA' THEN 'Java integration - requires JAVAVM enabled'
            WHEN 'DBMS_AQ' THEN 'Advanced Queuing - verify target support'
            WHEN 'DBMS_AQADM' THEN 'Advanced Queuing Admin - verify target support'
            WHEN 'DBMS_SCHEDULER' THEN 'Job scheduler - verify scheduler configuration in target'
            WHEN 'DBMS_JOB' THEN 'Legacy job scheduler - consider migrating to DBMS_SCHEDULER'
            WHEN 'DBMS_XMLGEN' THEN 'XML generation - verify XMLType support in target'
            WHEN 'DBMS_XMLQUERY' THEN 'XML queries - verify XMLType support in target'
            ELSE 'Review package availability and restrictions in target'
        END AS impact
    FROM dba_dependencies d
    JOIN dba_objects o ON d.owner = o.owner AND d.name = o.object_name AND d.type = o.object_type
    WHERE d.referenced_owner = 'SYS'
    AND d.referenced_type = 'PACKAGE'
    AND d.referenced_name IN (
        'UTL_FILE', 'UTL_TCP', 'UTL_HTTP', 'UTL_SMTP', 'UTL_INADDR',
        'DBMS_PIPE', 'DBMS_ALERT', 'DBMS_DEBUG', 'DBMS_JAVA',
        'DBMS_AQ', 'DBMS_AQADM', 'DBMS_SCHEDULER', 'DBMS_JOB',
        'DBMS_XMLGEN', 'DBMS_XMLQUERY', 'DBMS_LOCK'
    )
    AND d.owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
    ORDER BY
        CASE d.referenced_name
            WHEN 'UTL_FILE' THEN 1
            WHEN 'DBMS_PIPE' THEN 2
            WHEN 'DBMS_ALERT' THEN 3
            ELSE 4
        END,
        d.owner, d.name, d.referenced_name
    """


def get_db_links_check():
    """Identify database links that need reconfiguration for target environment."""
    return """
    SELECT
        owner,
        db_link,
        username,
        host,
        TO_CHAR(created, 'YYYY-MM-DD') AS created,
        CASE
            WHEN host LIKE '%.%' THEN 'Uses hostname/IP - will need reconfiguration'
            WHEN host IS NULL THEN 'Uses TNS alias - ensure tnsnames.ora updated in target'
            ELSE 'Review connection string for target environment'
        END AS recommendation
    FROM dba_db_links
    WHERE owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
    ORDER BY owner, db_link
    """


def get_directory_objects_check():
    """Identify directory objects that need recreation in target."""
    return """
    SELECT
        owner,
        directory_name,
        directory_path,
        'Directory must be recreated with valid path accessible from target database server' AS recommendation
    FROM dba_directories
    WHERE owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
    ORDER BY owner, directory_name
    """


def get_encrypted_columns_check():
    """Identify encrypted columns - TDE configuration needed in target."""
    return """
    SELECT
        owner,
        table_name,
        column_name,
        encryption_alg,
        salt,
        integrity_alg,
        'Transparent Data Encryption must be configured in target before migration' AS recommendation
    FROM dba_encrypted_columns
    WHERE owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
    ORDER BY owner, table_name, column_name
    """


def get_virtual_columns_check():
    """Identify virtual columns - verify expression compatibility."""
    return """
    SELECT
        owner,
        table_name,
        column_name,
        data_type,
        data_default AS expression,
        'Virtual column expressions should be tested for compatibility in target' AS recommendation
    FROM dba_tab_cols
    WHERE virtual_column = 'YES'
    AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
    ORDER BY owner, table_name, column_name
    """


def get_identity_columns_check():
    """Identify identity columns - verify sequence migration."""
    return """
    SELECT
        owner,
        table_name,
        column_name,
        generation_type,
        identity_options,
        'Identity column sequences are automatically created during import' AS recommendation
    FROM dba_tab_identity_cols
    WHERE owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
    ORDER BY owner, table_name, column_name
    """


def get_invisible_columns_check():
    """Identify invisible columns - supported in most targets."""
    return """
    SELECT
        owner,
        table_name,
        column_name,
        data_type,
        hidden_column,
        virtual_column,
        'Invisible columns are preserved during migration' AS recommendation
    FROM dba_tab_cols
    WHERE hidden_column = 'YES'
    AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
    ORDER BY owner, table_name, column_name
    """


def get_materialized_views_check():
    """Identify materialized views - refresh configuration needed in target."""
    return """
    SELECT
        owner,
        mview_name,
        container_name,
        refresh_mode,
        refresh_method,
        build_mode,
        fast_refreshable,
        staleness,
        'Materialized view refresh configuration and source access must be verified in target' AS recommendation
    FROM dba_mviews
    WHERE owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
    ORDER BY owner, mview_name
    """


def get_scheduler_jobs_check():
    """Identify scheduler jobs that may need reconfiguration."""
    return """
    SELECT
        owner,
        job_name,
        job_type,
        job_action,
        state,
        enabled,
        auto_drop,
        TO_CHAR(next_run_date, 'YYYY-MM-DD HH24:MI:SS') AS next_run_date,
        CASE
            WHEN job_type = 'EXECUTABLE' THEN 'External executables not supported in cloud - must convert to PL/SQL'
            WHEN job_type = 'CHAIN' THEN 'Job chains supported - verify all chain steps migrate correctly'
            ELSE 'Review job configuration for target environment'
        END AS recommendation
    FROM dba_scheduler_jobs
    WHERE owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
    AND job_name NOT LIKE 'AQ$%'
    AND job_name NOT LIKE 'PURGE%'
    ORDER BY owner, job_name
    """


# ============================================================
# CHARACTER SET ANALYSIS
# These queries analyze character set configuration and
# potential conversion issues for migration
# ============================================================

def get_database_character_set():
    """Get database character set configuration and NLS settings."""
    return """
    SELECT
        property_name,
        property_value,
        CASE property_name
            WHEN 'NLS_CHARACTERSET' THEN
                CASE
                    WHEN property_value = 'AL32UTF8' THEN 'Optimal - Unicode UTF-8, no conversion needed for most targets'
                    WHEN property_value LIKE 'UTF%' THEN 'Unicode - Generally compatible with cloud targets'
                    WHEN property_value LIKE 'WE8%' THEN 'Western European - May require conversion to AL32UTF8'
                    WHEN property_value LIKE 'US7ASCII' THEN 'ASCII only - Simple conversion to AL32UTF8'
                    ELSE 'Review - May require character set conversion'
                END
            WHEN 'NLS_NCHAR_CHARACTERSET' THEN
                CASE
                    WHEN property_value = 'AL16UTF16' THEN 'Standard Unicode for NCHAR/NVARCHAR2'
                    WHEN property_value = 'UTF8' THEN 'UTF8 for national character set'
                    ELSE 'Review national character set compatibility'
                END
            ELSE 'Database NLS configuration parameter'
        END AS recommendation
    FROM database_properties
    WHERE property_name IN (
        'NLS_CHARACTERSET',
        'NLS_NCHAR_CHARACTERSET',
        'NLS_LANGUAGE',
        'NLS_TERRITORY',
        'NLS_CURRENCY',
        'NLS_ISO_CURRENCY',
        'NLS_NUMERIC_CHARACTERS',
        'NLS_DATE_FORMAT',
        'NLS_DATE_LANGUAGE',
        'NLS_SORT',
        'NLS_COMP',
        'NLS_LENGTH_SEMANTICS',
        'NLS_RDBMS_VERSION'
    )
    ORDER BY
        CASE property_name
            WHEN 'NLS_CHARACTERSET' THEN 1
            WHEN 'NLS_NCHAR_CHARACTERSET' THEN 2
            ELSE 3
        END,
        property_name
    """


def get_character_set_conversion_check():
    """Check if character set conversion will be required and assess risk."""
    return """
    SELECT
        'Database Character Set' AS check_item,
        (SELECT property_value FROM database_properties WHERE property_name = 'NLS_CHARACTERSET') AS current_value,
        'AL32UTF8' AS target_value,
        CASE
            WHEN (SELECT property_value FROM database_properties WHERE property_name = 'NLS_CHARACTERSET') = 'AL32UTF8'
            THEN 'PASSING'
            WHEN (SELECT property_value FROM database_properties WHERE property_name = 'NLS_CHARACTERSET') LIKE 'UTF%'
            THEN 'REVIEW SUGGESTED'
            ELSE 'ACTION REQUIRED'
        END AS status,
        CASE
            WHEN (SELECT property_value FROM database_properties WHERE property_name = 'NLS_CHARACTERSET') = 'AL32UTF8'
            THEN 'No character set conversion required'
            WHEN (SELECT property_value FROM database_properties WHERE property_name = 'NLS_CHARACTERSET') LIKE 'UTF%'
            THEN 'Minor conversion may be needed - test data integrity'
            ELSE 'Character set conversion required - data scan recommended'
        END AS recommendation
    FROM dual
    UNION ALL
    SELECT
        'National Character Set',
        (SELECT property_value FROM database_properties WHERE property_name = 'NLS_NCHAR_CHARACTERSET'),
        'AL16UTF16',
        CASE
            WHEN (SELECT property_value FROM database_properties WHERE property_name = 'NLS_NCHAR_CHARACTERSET') = 'AL16UTF16'
            THEN 'PASSING'
            ELSE 'REVIEW SUGGESTED'
        END,
        CASE
            WHEN (SELECT property_value FROM database_properties WHERE property_name = 'NLS_NCHAR_CHARACTERSET') = 'AL16UTF16'
            THEN 'Standard national character set - compatible'
            ELSE 'Review NCHAR/NVARCHAR2 data for compatibility'
        END
    FROM dual
    UNION ALL
    SELECT
        'Length Semantics',
        (SELECT property_value FROM database_properties WHERE property_name = 'NLS_LENGTH_SEMANTICS'),
        'BYTE or CHAR',
        CASE
            WHEN (SELECT property_value FROM database_properties WHERE property_name = 'NLS_LENGTH_SEMANTICS') = 'CHAR'
            THEN 'PASSING'
            ELSE 'REVIEW SUGGESTED'
        END,
        CASE
            WHEN (SELECT property_value FROM database_properties WHERE property_name = 'NLS_LENGTH_SEMANTICS') = 'CHAR'
            THEN 'Character semantics - multi-byte safe'
            ELSE 'Byte semantics - verify column sizes for multi-byte data after conversion'
        END
    FROM dual
    """


def get_nchar_nvarchar_columns():
    """Identify columns using national character set data types."""
    return """
    SELECT
        owner,
        table_name,
        column_name,
        data_type,
        char_length,
        data_length,
        char_used,
        CASE
            WHEN data_type = 'NCHAR' THEN 'Fixed-length national character - verify length after migration'
            WHEN data_type = 'NVARCHAR2' THEN 'Variable national character - check max length compatibility'
            WHEN data_type = 'NCLOB' THEN 'National character LOB - verify NCLOB support in target'
            ELSE 'Review national character type'
        END AS recommendation
    FROM dba_tab_columns
    WHERE data_type IN ('NCHAR', 'NVARCHAR2', 'NCLOB')
    AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
    ORDER BY owner, table_name, column_name
    """


def get_char_column_length_check():
    """Check for CHAR/VARCHAR2 columns that may truncate after character set conversion."""
    return """
    SELECT
        owner,
        table_name,
        column_name,
        data_type,
        data_length,
        char_length,
        char_used,
        CASE
            WHEN char_used = 'B' AND data_length < 4000 THEN
                'BYTE semantics - may need size increase for multi-byte characters'
            WHEN char_used = 'C' THEN
                'CHAR semantics - length is character-based, should be safe'
            WHEN data_length >= 4000 THEN
                'Max or near-max length - verify no truncation after conversion'
            ELSE 'Review column length for multi-byte compatibility'
        END AS recommendation,
        CASE
            WHEN char_used = 'B' THEN ROUND(data_length / 4, 0)
            ELSE char_length
        END AS safe_char_capacity
    FROM dba_tab_columns
    WHERE data_type IN ('CHAR', 'VARCHAR2')
    AND char_used = 'B'
    AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
    ORDER BY data_length DESC, owner, table_name
    """


def get_multibyte_data_check():
    """Summary of potential multi-byte character impact by schema."""
    return """
    SELECT
        owner,
        COUNT(DISTINCT table_name) AS tables_with_char_cols,
        SUM(CASE WHEN data_type IN ('CHAR', 'VARCHAR2') AND char_used = 'B' THEN 1 ELSE 0 END) AS byte_semantic_cols,
        SUM(CASE WHEN data_type IN ('CHAR', 'VARCHAR2') AND char_used = 'C' THEN 1 ELSE 0 END) AS char_semantic_cols,
        SUM(CASE WHEN data_type IN ('NCHAR', 'NVARCHAR2', 'NCLOB') THEN 1 ELSE 0 END) AS national_char_cols,
        SUM(CASE WHEN data_type IN ('CLOB', 'LONG') THEN 1 ELSE 0 END) AS lob_text_cols,
        CASE
            WHEN SUM(CASE WHEN data_type IN ('CHAR', 'VARCHAR2') AND char_used = 'B' THEN 1 ELSE 0 END) > 0
            THEN 'Review byte-semantic columns for multi-byte data'
            ELSE 'No byte-semantic columns - lower conversion risk'
        END AS recommendation
    FROM dba_tab_columns
    WHERE data_type IN ('CHAR', 'VARCHAR2', 'NCHAR', 'NVARCHAR2', 'CLOB', 'NCLOB', 'LONG')
    AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
    GROUP BY owner
    ORDER BY byte_semantic_cols DESC, owner
    """


def get_character_set_scan_summary():
    """Provide summary statistics for character set conversion planning."""
    return """
    SELECT
        'Total Character Columns' AS metric,
        TO_CHAR(COUNT(*)) AS value,
        'Columns that may be affected by character set conversion' AS description
    FROM dba_tab_columns
    WHERE data_type IN ('CHAR', 'VARCHAR2', 'NCHAR', 'NVARCHAR2', 'CLOB', 'NCLOB', 'LONG')
    AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
    UNION ALL
    SELECT
        'Byte-Semantic Columns',
        TO_CHAR(COUNT(*)),
        'CHAR/VARCHAR2 columns using BYTE length - higher conversion risk'
    FROM dba_tab_columns
    WHERE data_type IN ('CHAR', 'VARCHAR2')
    AND char_used = 'B'
    AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
    UNION ALL
    SELECT
        'Character-Semantic Columns',
        TO_CHAR(COUNT(*)),
        'CHAR/VARCHAR2 columns using CHAR length - lower conversion risk'
    FROM dba_tab_columns
    WHERE data_type IN ('CHAR', 'VARCHAR2')
    AND char_used = 'C'
    AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
    UNION ALL
    SELECT
        'National Character Columns',
        TO_CHAR(COUNT(*)),
        'NCHAR/NVARCHAR2/NCLOB columns using national character set'
    FROM dba_tab_columns
    WHERE data_type IN ('NCHAR', 'NVARCHAR2', 'NCLOB')
    AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
    UNION ALL
    SELECT
        'Text LOB Columns',
        TO_CHAR(COUNT(*)),
        'CLOB/NCLOB columns that may contain character data'
    FROM dba_tab_columns
    WHERE data_type IN ('CLOB', 'NCLOB')
    AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
    UNION ALL
    SELECT
        'Database Character Set',
        (SELECT property_value FROM database_properties WHERE property_name = 'NLS_CHARACTERSET'),
        CASE
            WHEN (SELECT property_value FROM database_properties WHERE property_name = 'NLS_CHARACTERSET') = 'AL32UTF8'
            THEN 'Already Unicode - no conversion needed'
            ELSE 'Conversion to AL32UTF8 may be required for cloud migration'
        END
    FROM dual
    UNION ALL
    SELECT
        'Target Character Set',
        'AL32UTF8',
        'Oracle Cloud/Azure standard character set'
    FROM dual
    """


def get_nls_session_parameters():
    """Get current NLS session parameters for comparison."""
    return """
    SELECT
        parameter,
        value,
        CASE parameter
            WHEN 'NLS_LANGUAGE' THEN 'Session language setting'
            WHEN 'NLS_TERRITORY' THEN 'Session territory/region setting'
            WHEN 'NLS_CURRENCY' THEN 'Local currency symbol'
            WHEN 'NLS_ISO_CURRENCY' THEN 'ISO currency code'
            WHEN 'NLS_NUMERIC_CHARACTERS' THEN 'Decimal and group separators'
            WHEN 'NLS_DATE_FORMAT' THEN 'Default date display format'
            WHEN 'NLS_DATE_LANGUAGE' THEN 'Language for day/month names'
            WHEN 'NLS_SORT' THEN 'Linguistic sort order'
            WHEN 'NLS_COMP' THEN 'Comparison method (BINARY or LINGUISTIC)'
            WHEN 'NLS_CHARACTERSET' THEN 'Database character set'
            WHEN 'NLS_NCHAR_CHARACTERSET' THEN 'National character set'
            WHEN 'NLS_LENGTH_SEMANTICS' THEN 'Default length semantics (BYTE or CHAR)'
            ELSE 'NLS configuration parameter'
        END AS description
    FROM nls_session_parameters
    WHERE parameter IN (
        'NLS_LANGUAGE', 'NLS_TERRITORY', 'NLS_CURRENCY', 'NLS_ISO_CURRENCY',
        'NLS_NUMERIC_CHARACTERS', 'NLS_DATE_FORMAT', 'NLS_DATE_LANGUAGE',
        'NLS_SORT', 'NLS_COMP', 'NLS_CHARACTERSET', 'NLS_NCHAR_CHARACTERSET',
        'NLS_LENGTH_SEMANTICS', 'NLS_CALENDAR', 'NLS_TIMESTAMP_FORMAT'
    )
    ORDER BY parameter
    """


def get_invalid_character_risk():
    """Identify schemas with highest risk for character conversion issues."""
    return """
    WITH char_stats AS (
        SELECT
            owner,
            COUNT(*) AS total_char_cols,
            SUM(CASE WHEN char_used = 'B' AND data_length >= 100 THEN 1 ELSE 0 END) AS large_byte_cols,
            SUM(CASE WHEN data_type IN ('NCHAR', 'NVARCHAR2') THEN 1 ELSE 0 END) AS nchar_cols,
            MAX(data_length) AS max_col_length
        FROM dba_tab_columns
        WHERE data_type IN ('CHAR', 'VARCHAR2', 'NCHAR', 'NVARCHAR2')
        AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
        GROUP BY owner
    )
    SELECT
        owner,
        total_char_cols,
        large_byte_cols,
        nchar_cols,
        max_col_length,
        CASE
            WHEN large_byte_cols > 10 THEN 'HIGH'
            WHEN large_byte_cols > 0 OR nchar_cols > 0 THEN 'MEDIUM'
            ELSE 'LOW'
        END AS conversion_risk,
        CASE
            WHEN large_byte_cols > 10 THEN 'Scan recommended - many large byte-semantic columns'
            WHEN large_byte_cols > 0 THEN 'Review large columns for multi-byte data'
            WHEN nchar_cols > 0 THEN 'Verify NCHAR data compatibility'
            ELSE 'Low risk - minimal character set conversion impact'
        END AS recommendation
    FROM char_stats
    ORDER BY
        CASE
            WHEN large_byte_cols > 10 THEN 1
            WHEN large_byte_cols > 0 OR nchar_cols > 0 THEN 2
            ELSE 3
        END,
        large_byte_cols DESC,
        owner
    """


# ============================================================
# PARAMETER VALIDATION
# These queries check for initialization parameters that may be
# restricted or incompatible with cloud targets
# ============================================================

def get_restricted_parameters_check():
    """Check for parameters that are restricted or not modifiable in cloud targets."""
    return """
    SELECT
        name AS parameter_name,
        value,
        isdefault,
        ismodified,
        CASE name
            -- Parameters not allowed in ADB Serverless
            WHEN 'remote_login_passwordfile' THEN 'Cannot be modified in ADB - managed by service'
            WHEN 'audit_trail' THEN 'Must use Unified Auditing in ADB'
            WHEN 'db_block_size' THEN 'Fixed at 8K in ADB Serverless'
            WHEN 'db_create_file_dest' THEN 'Managed by ADB - cannot specify'
            WHEN 'db_recovery_file_dest' THEN 'Managed by ADB - cannot specify'
            WHEN 'log_archive_dest_1' THEN 'Archive destinations managed by ADB'
            WHEN 'control_files' THEN 'Control file location managed by ADB'
            WHEN 'diagnostic_dest' THEN 'Diagnostic destination managed by ADB'
            WHEN 'dispatchers' THEN 'Shared server not configurable in ADB Serverless'
            WHEN 'shared_servers' THEN 'Shared server not configurable in ADB Serverless'
            WHEN 'max_shared_servers' THEN 'Shared server not configurable in ADB Serverless'
            WHEN 'local_listener' THEN 'Listener managed by ADB'
            WHEN 'remote_listener' THEN 'Listener managed by ADB'
            WHEN 'dg_broker_start' THEN 'Data Guard managed differently in ADB'
            WHEN 'fal_server' THEN 'Data Guard managed differently in ADB'
            WHEN 'log_archive_config' THEN 'Data Guard managed differently in ADB'
            WHEN 'standby_file_management' THEN 'Data Guard managed differently in ADB'
            WHEN 'db_file_name_convert' THEN 'File naming managed by ADB'
            WHEN 'log_file_name_convert' THEN 'File naming managed by ADB'
            WHEN 'encrypt_new_tablespaces' THEN 'TDE always enabled in ADB'
            WHEN 'wallet_root' THEN 'Wallet managed by ADB'
            WHEN 'tde_configuration' THEN 'TDE managed by ADB'
            WHEN 'compatible' THEN 'Compatibility level managed by ADB'
            WHEN 'cluster_database' THEN 'RAC configuration managed by ADB'
            WHEN 'instance_number' THEN 'Instance configuration managed by ADB'
            WHEN 'thread' THEN 'Thread configuration managed by ADB'
            WHEN 'undo_tablespace' THEN 'May need adjustment - ADB uses specific undo tablespace'
            WHEN 'db_domain' THEN 'Domain managed by cloud infrastructure'
            WHEN 'service_names' THEN 'Services managed by ADB'
            ELSE 'Review parameter compatibility with target'
        END AS cloud_impact,
        CASE
            WHEN name IN ('remote_login_passwordfile', 'audit_trail', 'db_block_size',
                         'control_files', 'diagnostic_dest', 'encrypt_new_tablespaces',
                         'wallet_root', 'tde_configuration', 'compatible', 'cluster_database')
            THEN 'ACTION REQUIRED'
            WHEN name IN ('db_create_file_dest', 'db_recovery_file_dest', 'log_archive_dest_1',
                         'dispatchers', 'shared_servers', 'local_listener', 'remote_listener',
                         'dg_broker_start', 'fal_server', 'log_archive_config')
            THEN 'REVIEW REQUIRED'
            ELSE 'REVIEW SUGGESTED'
        END AS status
    FROM v$parameter
    WHERE name IN (
        'remote_login_passwordfile', 'audit_trail', 'db_block_size',
        'db_create_file_dest', 'db_recovery_file_dest', 'log_archive_dest_1',
        'control_files', 'diagnostic_dest', 'dispatchers', 'shared_servers',
        'max_shared_servers', 'local_listener', 'remote_listener',
        'dg_broker_start', 'fal_server', 'log_archive_config', 'standby_file_management',
        'db_file_name_convert', 'log_file_name_convert', 'encrypt_new_tablespaces',
        'wallet_root', 'tde_configuration', 'compatible', 'cluster_database',
        'instance_number', 'thread', 'undo_tablespace', 'db_domain', 'service_names'
    )
    AND (isdefault = 'FALSE' OR value IS NOT NULL)
    ORDER BY
        CASE
            WHEN name IN ('remote_login_passwordfile', 'audit_trail', 'db_block_size',
                         'control_files', 'encrypt_new_tablespaces', 'compatible') THEN 1
            WHEN name IN ('db_create_file_dest', 'db_recovery_file_dest', 'dispatchers') THEN 2
            ELSE 3
        END,
        name
    """


def get_hidden_parameters_check():
    """Check for hidden/underscore parameters that may cause issues.
    Uses v$system_parameter which is accessible to DBA roles (unlike x$ tables
    which require SYS)."""
    return r"""
    SELECT
        name AS parameter_name,
        value,
        isdefault AS is_default,
        description,
        'Hidden parameters may not be supported in cloud - review necessity' AS recommendation,
        CASE
            WHEN name LIKE '%optim%' THEN 'REVIEW REQUIRED - Optimizer parameter'
            WHEN name LIKE '%parallel%' THEN 'REVIEW SUGGESTED - Parallel execution parameter'
            WHEN name LIKE '%buffer%' THEN 'REVIEW SUGGESTED - Buffer/memory parameter'
            ELSE 'REVIEW SUGGESTED'
        END AS status
    FROM v$system_parameter
    WHERE name LIKE '\_%' ESCAPE '\'
      AND isdefault = 'FALSE'
      AND value IS NOT NULL
    ORDER BY name
    """


def get_parameter_validation_summary():
    """Summary of parameter validation for migration planning."""
    return """
    SELECT
        'Non-Default Parameters' AS check_category,
        COUNT(*) AS count,
        'Parameters modified from default that need review' AS description
    FROM v$parameter
    WHERE isdefault = 'FALSE'
    AND name NOT LIKE '\\_%' ESCAPE '\\'
    UNION ALL
    SELECT
        'Deprecated Parameters',
        COUNT(*),
        'Parameters marked as deprecated - may not work in newer versions'
    FROM v$parameter
    WHERE isdeprecated = 'TRUE'
    AND isdefault = 'FALSE'
    UNION ALL
    SELECT
        'Memory Parameters (Non-Default)',
        COUNT(*),
        'Memory allocation parameters that may need adjustment for cloud'
    FROM v$parameter
    WHERE isdefault = 'FALSE'
    AND name IN ('sga_target', 'sga_max_size', 'pga_aggregate_target',
                 'pga_aggregate_limit', 'memory_target', 'memory_max_target',
                 'db_cache_size', 'shared_pool_size', 'large_pool_size',
                 'java_pool_size', 'streams_pool_size')
    UNION ALL
    SELECT
        'Security Parameters (Non-Default)',
        COUNT(*),
        'Security-related parameters that affect cloud migration'
    FROM v$parameter
    WHERE isdefault = 'FALSE'
    AND name IN ('sec_case_sensitive_logon', 'sec_max_failed_login_attempts',
                 'sec_protocol_error_trace_action', 'remote_os_authent',
                 'os_authent_prefix', 'remote_login_passwordfile')
    UNION ALL
    SELECT
        'Optimizer Parameters (Non-Default)',
        COUNT(*),
        'Optimizer parameters that may affect query performance in target'
    FROM v$parameter
    WHERE isdefault = 'FALSE'
    AND name LIKE 'optimizer%'
    """


def get_critical_parameters_check():
    """Check critical parameters for cloud compatibility."""
    return """
    SELECT
        name AS parameter_name,
        value AS current_value,
        CASE name
            WHEN 'db_block_size' THEN '8192'
            WHEN 'compatible' THEN '19.0.0 or higher'
            WHEN 'nls_length_semantics' THEN 'CHAR (recommended)'
            WHEN 'audit_trail' THEN 'NONE (use Unified Auditing)'
            WHEN 'sec_case_sensitive_logon' THEN 'TRUE'
            WHEN 'deferred_segment_creation' THEN 'TRUE'
            WHEN 'recyclebin' THEN 'ON'
            WHEN 'result_cache_mode' THEN 'MANUAL'
            WHEN 'cursor_sharing' THEN 'EXACT or FORCE'
            ELSE 'Review target requirements'
        END AS recommended_value,
        CASE
            WHEN name = 'db_block_size' AND value != '8192' THEN 'ACTION REQUIRED - ADB requires 8K block size'
            WHEN name = 'compatible' AND value < '19.0.0' THEN 'ACTION REQUIRED - Upgrade compatibility before migration'
            WHEN name = 'audit_trail' AND value NOT IN ('NONE', 'DB') THEN 'REVIEW REQUIRED - Unified Auditing preferred'
            WHEN name = 'sec_case_sensitive_logon' AND value = 'FALSE' THEN 'REVIEW REQUIRED - Case-sensitive passwords recommended'
            WHEN name = 'nls_length_semantics' AND value = 'BYTE' THEN 'REVIEW SUGGESTED - CHAR semantics safer for Unicode'
            ELSE 'PASSING'
        END AS status,
        description
    FROM v$parameter
    WHERE name IN (
        'db_block_size', 'compatible', 'nls_length_semantics', 'audit_trail',
        'sec_case_sensitive_logon', 'deferred_segment_creation', 'recyclebin',
        'result_cache_mode', 'cursor_sharing', 'optimizer_mode',
        'query_rewrite_enabled', 'star_transformation_enabled'
    )
    ORDER BY
        CASE
            WHEN name = 'db_block_size' THEN 1
            WHEN name = 'compatible' THEN 2
            WHEN name = 'audit_trail' THEN 3
            ELSE 4
        END
    """


def get_deprecated_parameters():
    """Identify deprecated parameters still in use."""
    return """
    SELECT
        name AS parameter_name,
        value,
        description,
        'Deprecated parameter - will not work in future versions' AS recommendation,
        'REVIEW REQUIRED' AS status
    FROM v$parameter
    WHERE isdeprecated = 'TRUE'
    AND isdefault = 'FALSE'
    ORDER BY name
    """


# ============================================================
# TIMEZONE VERSION CHECK
# These queries check timezone file version compatibility
# ============================================================

def get_timezone_version_check():
    """Check database timezone file version for compatibility."""
    return """
    SELECT
        'Database Timezone Version' AS check_item,
        version AS current_version,
        CASE
            WHEN version >= 32 THEN 'Current - Compatible with latest cloud targets'
            WHEN version >= 26 THEN 'Acceptable - May need upgrade for some targets'
            WHEN version >= 18 THEN 'Outdated - Timezone upgrade recommended before migration'
            ELSE 'Very Old - Timezone upgrade required before migration'
        END AS status,
        CASE
            WHEN version >= 32 THEN 'PASSING'
            WHEN version >= 26 THEN 'REVIEW SUGGESTED'
            ELSE 'ACTION REQUIRED'
        END AS migration_status,
        'Target cloud databases typically use timezone version 32+' AS recommendation
    FROM v$timezone_file
    """


def get_timezone_data_check():
    """Check for tables with TIMESTAMP WITH TIME ZONE that may be affected."""
    return """
    SELECT
        owner,
        table_name,
        column_name,
        data_type,
        (SELECT version FROM v$timezone_file) AS current_tz_version,
        CASE
            WHEN data_type = 'TIMESTAMP WITH TIME ZONE'
            THEN 'TSTZ data may need validation after timezone upgrade'
            WHEN data_type = 'TIMESTAMP WITH LOCAL TIME ZONE'
            THEN 'TSLTZ data depends on session timezone - verify behavior'
            ELSE 'Review timestamp handling'
        END AS recommendation
    FROM dba_tab_columns
    WHERE data_type IN ('TIMESTAMP WITH TIME ZONE', 'TIMESTAMP WITH LOCAL TIME ZONE')
    AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
    ORDER BY owner, table_name, column_name
    """


def get_timezone_usage_summary():
    """Summary of timezone-sensitive data in the database."""
    return """
    SELECT
        'TIMESTAMP WITH TIME ZONE Columns' AS metric,
        TO_CHAR(COUNT(*)) AS value,
        CASE
            WHEN COUNT(*) = 0 THEN 'No TSTZ columns - timezone upgrade is straightforward'
            WHEN COUNT(*) < 50 THEN 'Few TSTZ columns - validate data after timezone upgrade'
            ELSE 'Many TSTZ columns - thorough testing recommended after upgrade'
        END AS recommendation
    FROM dba_tab_columns
    WHERE data_type = 'TIMESTAMP WITH TIME ZONE'
    AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
    UNION ALL
    SELECT
        'TIMESTAMP WITH LOCAL TIME ZONE Columns',
        TO_CHAR(COUNT(*)),
        CASE
            WHEN COUNT(*) = 0 THEN 'No TSLTZ columns'
            ELSE 'TSLTZ columns present - verify session timezone handling'
        END
    FROM dba_tab_columns
    WHERE data_type = 'TIMESTAMP WITH LOCAL TIME ZONE'
    AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
    UNION ALL
    SELECT
        'Current Timezone Version',
        TO_CHAR(version),
        CASE
            WHEN version >= 32 THEN 'Current version - no upgrade needed'
            WHEN version >= 26 THEN 'Consider upgrade to version 32+'
            ELSE 'Timezone upgrade required before cloud migration'
        END
    FROM v$timezone_file
    UNION ALL
    SELECT
        'Database Timezone',
        dbtimezone,
        'Database default timezone setting'
    FROM dual
    UNION ALL
    SELECT
        'Session Timezone',
        sessiontimezone,
        'Current session timezone setting'
    FROM dual
    """


def get_dst_transition_check():
    """Check for potential DST transition issues in timestamp data."""
    return """
    SELECT
        (SELECT version FROM v$timezone_file) AS current_tz_version,
        CASE
            WHEN (SELECT version FROM v$timezone_file) < 32 THEN
                'Timezone file may have outdated DST rules - upgrade recommended'
            ELSE
                'Timezone file is current with DST rules'
        END AS dst_status,
        CASE
            WHEN (SELECT COUNT(*) FROM dba_tab_columns
                  WHERE data_type = 'TIMESTAMP WITH TIME ZONE'
                  AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')) > 0 THEN
                'TSTZ columns exist - DST transitions may affect historical data'
            ELSE
                'No TSTZ columns - minimal DST impact'
        END AS data_impact,
        CASE
            WHEN (SELECT version FROM v$timezone_file) >= 32 THEN 'PASSING'
            WHEN (SELECT version FROM v$timezone_file) >= 26 THEN 'REVIEW SUGGESTED'
            ELSE 'ACTION REQUIRED'
        END AS status,
        'Run DBMS_DST package to upgrade timezone if needed before migration' AS recommendation
    FROM dual
    """


# ============================================================
# MIGRATION METHOD SELECTION
# These queries analyze the database to recommend Data Pump
# vs GoldenGate migration approach
# ============================================================

def get_migration_method_recommendation():
    """Generate overall migration method recommendation based on database characteristics."""
    return """
    WITH db_metrics AS (
        SELECT
            (SELECT SUM(bytes)/(1024*1024*1024) FROM dba_segments) AS total_size_gb,
            (SELECT COUNT(*) FROM dba_tables
             WHERE owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')) AS table_count,
            (SELECT COUNT(*) FROM dba_tables t
             WHERE NOT EXISTS (SELECT 1 FROM dba_constraints c
                              WHERE c.owner = t.owner AND c.table_name = t.table_name
                              AND c.constraint_type = 'P')
             AND t.owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')) AS tables_without_pk,
            (SELECT COUNT(*) FROM dba_lobs
             WHERE owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')) AS lob_count,
            (SELECT ROUND(AVG(value),2) FROM v$sysmetric
             WHERE metric_name = 'Redo Generated Per Sec'
             AND group_id = 2) AS redo_per_sec,
            (SELECT COUNT(*) FROM gv$session
             WHERE type = 'USER' AND status = 'ACTIVE') AS active_sessions,
            (SELECT value FROM v$parameter WHERE name = 'log_mode') AS log_mode,
            (SELECT COUNT(*) FROM dba_tab_columns
             WHERE data_type IN ('LONG','LONG RAW','BFILE')
             AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')) AS unsupported_for_gg
        FROM dual
    ),
    scoring AS (
        SELECT
            total_size_gb,
            table_count,
            tables_without_pk,
            lob_count,
            redo_per_sec,
            active_sessions,
            log_mode,
            unsupported_for_gg,
            -- Data Pump Score (higher = better fit for Data Pump)
            CASE WHEN total_size_gb < 100 THEN 30
                 WHEN total_size_gb < 500 THEN 20
                 WHEN total_size_gb < 1000 THEN 10
                 ELSE 0 END +
            CASE WHEN table_count < 500 THEN 20
                 WHEN table_count < 2000 THEN 10
                 ELSE 0 END +
            CASE WHEN lob_count < 50 THEN 15
                 WHEN lob_count < 200 THEN 10
                 ELSE 5 END +
            CASE WHEN active_sessions < 50 THEN 15
                 ELSE 5 END +
            CASE WHEN unsupported_for_gg > 0 THEN 20
                 ELSE 0 END AS datapump_score,
            -- GoldenGate Score (higher = better fit for GoldenGate)
            CASE WHEN total_size_gb >= 500 THEN 30
                 WHEN total_size_gb >= 100 THEN 20
                 ELSE 10 END +
            CASE WHEN redo_per_sec > 10 THEN 25
                 WHEN redo_per_sec > 5 THEN 15
                 ELSE 5 END +
            CASE WHEN active_sessions >= 100 THEN 20
                 WHEN active_sessions >= 50 THEN 15
                 ELSE 5 END +
            CASE WHEN tables_without_pk < table_count * 0.1 THEN 15
                 WHEN tables_without_pk < table_count * 0.3 THEN 10
                 ELSE 0 END +
            CASE WHEN log_mode = 'ARCHIVELOG' THEN 10
                 ELSE 0 END AS goldengate_score
        FROM db_metrics
    )
    SELECT
        'Migration Method Recommendation' AS category,
        CASE
            WHEN datapump_score > goldengate_score + 20 THEN 'DATA PUMP'
            WHEN goldengate_score > datapump_score + 20 THEN 'GOLDENGATE'
            ELSE 'EITHER (Review factors below)'
        END AS recommended_method,
        datapump_score AS data_pump_score,
        goldengate_score AS goldengate_score,
        ROUND(total_size_gb, 2) AS database_size_gb,
        table_count,
        tables_without_pk,
        active_sessions,
        ROUND(redo_per_sec, 2) AS redo_mb_per_sec,
        CASE
            WHEN datapump_score > goldengate_score + 20 THEN
                'Small/medium DB with acceptable downtime window'
            WHEN goldengate_score > datapump_score + 20 THEN
                'Large DB or zero-downtime requirement'
            ELSE
                'Consider downtime tolerance and replication needs'
        END AS recommendation_reason
    FROM scoring
    """


def get_datapump_suitability_check():
    """Analyze database suitability for Data Pump migration."""
    return """
    SELECT
        'Database Size' AS factor,
        TO_CHAR(ROUND(SUM(bytes)/(1024*1024*1024), 2)) || ' GB' AS current_value,
        CASE
            WHEN SUM(bytes)/(1024*1024*1024) < 100 THEN 'EXCELLENT'
            WHEN SUM(bytes)/(1024*1024*1024) < 500 THEN 'GOOD'
            WHEN SUM(bytes)/(1024*1024*1024) < 1000 THEN 'ACCEPTABLE'
            ELSE 'CHALLENGING'
        END AS suitability,
        CASE
            WHEN SUM(bytes)/(1024*1024*1024) < 100 THEN 'Fast export/import, minimal downtime'
            WHEN SUM(bytes)/(1024*1024*1024) < 500 THEN 'Moderate export/import time'
            WHEN SUM(bytes)/(1024*1024*1024) < 1000 THEN 'Extended downtime required'
            ELSE 'Very long downtime - consider parallel or GoldenGate'
        END AS notes
    FROM dba_segments
    UNION ALL
    SELECT
        'Parallel Export Potential',
        TO_CHAR((SELECT COUNT(DISTINCT tablespace_name) FROM dba_segments
                 WHERE owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB'))) || ' tablespaces',
        CASE
            WHEN (SELECT COUNT(DISTINCT tablespace_name) FROM dba_segments
                  WHERE owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')) >= 4 THEN 'EXCELLENT'
            ELSE 'GOOD'
        END,
        'Multiple tablespaces enable parallel Data Pump workers'
    FROM dual
    UNION ALL
    SELECT
        'LONG/LONG RAW Columns',
        TO_CHAR(COUNT(*)),
        CASE WHEN COUNT(*) = 0 THEN 'EXCELLENT'
             WHEN COUNT(*) < 10 THEN 'GOOD'
             ELSE 'REVIEW REQUIRED' END,
        CASE WHEN COUNT(*) = 0 THEN 'No legacy LONG types'
             ELSE 'LONG types supported but slower - consider conversion to LOB' END
    FROM dba_tab_columns
    WHERE data_type IN ('LONG', 'LONG RAW')
    AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
    UNION ALL
    SELECT
        'External Tables',
        TO_CHAR(COUNT(*)),
        CASE WHEN COUNT(*) = 0 THEN 'EXCELLENT' ELSE 'REVIEW REQUIRED' END,
        CASE WHEN COUNT(*) = 0 THEN 'No external tables to handle separately'
             ELSE 'External tables excluded from Data Pump - migrate separately' END
    FROM dba_external_tables
    WHERE owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
    UNION ALL
    SELECT
        'Network Link Option',
        CASE WHEN (SELECT COUNT(*) FROM dba_db_links) > 0 THEN 'Available' ELSE 'Not configured' END,
        'INFORMATIONAL',
        'NETWORK_LINK parameter enables direct import without dump files'
    FROM dual
    UNION ALL
    SELECT
        'Estimated Export Time',
        CASE
            WHEN (SELECT SUM(bytes)/(1024*1024*1024) FROM dba_segments) < 100
            THEN '< 1 hour'
            WHEN (SELECT SUM(bytes)/(1024*1024*1024) FROM dba_segments) < 500
            THEN '1-4 hours'
            WHEN (SELECT SUM(bytes)/(1024*1024*1024) FROM dba_segments) < 1000
            THEN '4-8 hours'
            ELSE '8+ hours'
        END,
        'ESTIMATE',
        'Approximate time with parallel=4 on modern storage (actual varies by I/O)'
    FROM dual
    """


def get_goldengate_suitability_check():
    """Analyze database suitability for GoldenGate migration."""
    return """
    SELECT
        'Archive Log Mode' AS factor,
        (SELECT value FROM v$parameter WHERE name = 'log_mode') AS current_value,
        CASE
            WHEN (SELECT value FROM v$parameter WHERE name = 'log_mode') = 'ARCHIVELOG'
            THEN 'EXCELLENT'
            ELSE 'ACTION REQUIRED'
        END AS suitability,
        CASE
            WHEN (SELECT value FROM v$parameter WHERE name = 'log_mode') = 'ARCHIVELOG'
            THEN 'Required for GoldenGate - already enabled'
            ELSE 'Must enable ARCHIVELOG mode before GoldenGate setup'
        END AS notes
    FROM dual
    UNION ALL
    SELECT
        'Supplemental Logging',
        CASE
            WHEN (SELECT supplemental_log_data_min FROM v$database) = 'YES' THEN 'Enabled'
            ELSE 'Not Enabled'
        END,
        CASE
            WHEN (SELECT supplemental_log_data_min FROM v$database) = 'YES' THEN 'GOOD'
            ELSE 'ACTION REQUIRED'
        END,
        CASE
            WHEN (SELECT supplemental_log_data_min FROM v$database) = 'YES'
            THEN 'Minimal supplemental logging enabled'
            ELSE 'Must enable: ALTER DATABASE ADD SUPPLEMENTAL LOG DATA'
        END
    FROM dual
    UNION ALL
    SELECT
        'Tables Without Primary Key',
        TO_CHAR(COUNT(*)) || ' tables',
        CASE
            WHEN COUNT(*) = 0 THEN 'EXCELLENT'
            WHEN COUNT(*) < 50 THEN 'GOOD'
            WHEN COUNT(*) < 200 THEN 'ACCEPTABLE'
            ELSE 'CHALLENGING'
        END,
        CASE
            WHEN COUNT(*) = 0 THEN 'All tables have PKs - optimal for GoldenGate'
            ELSE 'Tables without PK need KEYCOLS or full row logging'
        END
    FROM dba_tables t
    WHERE NOT EXISTS (
        SELECT 1 FROM dba_constraints c
        WHERE c.owner = t.owner AND c.table_name = t.table_name
        AND c.constraint_type = 'P'
    )
    AND t.owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
    AND t.num_rows > 0
    UNION ALL
    SELECT
        'Unsupported Data Types',
        TO_CHAR(COUNT(*)) || ' columns',
        CASE WHEN COUNT(*) = 0 THEN 'EXCELLENT' ELSE 'REVIEW REQUIRED' END,
        CASE WHEN COUNT(*) = 0 THEN 'No unsupported types for GoldenGate'
             ELSE 'BFILE, LONG over DBLINK not supported - special handling needed' END
    FROM dba_tab_columns
    WHERE data_type IN ('BFILE', 'LONG', 'LONG RAW')
    AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
    UNION ALL
    SELECT
        'Redo Generation Rate',
        TO_CHAR(ROUND(AVG(value)/(1024*1024), 2)) || ' MB/sec',
        CASE
            WHEN AVG(value)/(1024*1024) < 5 THEN 'LOW'
            WHEN AVG(value)/(1024*1024) < 20 THEN 'MODERATE'
            ELSE 'HIGH'
        END,
        'Affects trail file sizing and extract lag'
    FROM v$sysmetric
    WHERE metric_name = 'Redo Generated Per Sec' AND group_id = 2
    UNION ALL
    SELECT
        'Estimated Initial Load Time',
        CASE
            WHEN (SELECT SUM(bytes)/(1024*1024*1024) FROM dba_segments) < 100
            THEN '< 2 hours'
            WHEN (SELECT SUM(bytes)/(1024*1024*1024) FROM dba_segments) < 500
            THEN '2-8 hours'
            WHEN (SELECT SUM(bytes)/(1024*1024*1024) FROM dba_segments) < 1000
            THEN '8-24 hours'
            ELSE '24+ hours'
        END,
        'ESTIMATE',
        'Initial load time - change capture runs concurrently'
    FROM dual
    UNION ALL
    SELECT
        'Compressed Tables',
        TO_CHAR(COUNT(*)) || ' tables',
        CASE WHEN COUNT(*) < 100 THEN 'GOOD' ELSE 'REVIEW SUGGESTED' END,
        'Compressed tables supported but may impact extract performance'
    FROM dba_tables
    WHERE compression = 'ENABLED'
    AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
    """


def get_migration_factors_comparison():
    """Side-by-side comparison of factors for each migration method."""
    return """
    SELECT
        'Downtime Requirement' AS factor,
        'Extended window required' AS data_pump_impact,
        'Near-zero downtime possible' AS goldengate_impact,
        CASE
            WHEN (SELECT SUM(bytes)/(1024*1024*1024) FROM dba_segments) > 500
            THEN 'Favors GoldenGate'
            ELSE 'Either method acceptable'
        END AS recommendation
    FROM dual
    UNION ALL
    SELECT
        'Database Size',
        CASE
            WHEN (SELECT SUM(bytes)/(1024*1024*1024) FROM dba_segments) < 500
            THEN 'Good fit (< 500GB)'
            ELSE 'Challenging (' ||
                 TO_CHAR(ROUND((SELECT SUM(bytes)/(1024*1024*1024) FROM dba_segments))) || 'GB)'
        END,
        'Handles any size with initial load',
        CASE
            WHEN (SELECT SUM(bytes)/(1024*1024*1024) FROM dba_segments) > 500
            THEN 'Favors GoldenGate'
            ELSE 'Favors Data Pump'
        END
    FROM dual
    UNION ALL
    SELECT
        'Complexity',
        'Simple - single export/import',
        'Complex - requires Extract/Replicat setup',
        'Favors Data Pump for simplicity'
    FROM dual
    UNION ALL
    SELECT
        'Ongoing Sync',
        'Not supported - one-time migration',
        'Supports ongoing replication',
        CASE
            WHEN (SELECT COUNT(*) FROM gv$session WHERE type='USER' AND status='ACTIVE') > 50
            THEN 'Favors GoldenGate (high activity)'
            ELSE 'Data Pump if no ongoing sync needed'
        END
    FROM dual
    UNION ALL
    SELECT
        'Tables Without PK',
        'No impact',
        TO_CHAR((SELECT COUNT(*) FROM dba_tables t
                 WHERE NOT EXISTS (SELECT 1 FROM dba_constraints c
                                  WHERE c.owner=t.owner AND c.table_name=t.table_name
                                  AND c.constraint_type='P')
                 AND t.owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
                 AND t.num_rows > 0)) || ' tables need KEYCOLS',
        CASE
            WHEN (SELECT COUNT(*) FROM dba_tables t
                  WHERE NOT EXISTS (SELECT 1 FROM dba_constraints c
                                   WHERE c.owner=t.owner AND c.table_name=t.table_name
                                   AND c.constraint_type='P')
                  AND t.owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
                  AND t.num_rows > 0) > 100
            THEN 'Favors Data Pump'
            ELSE 'Minor GoldenGate consideration'
        END
    FROM dual
    UNION ALL
    SELECT
        'LOB Data',
        'Full support with BLOB/CLOB',
        'Supported - inline LOBs replicate automatically',
        'No strong preference'
    FROM dual
    UNION ALL
    SELECT
        'Cost',
        'Included with Oracle DB license',
        'Separate GoldenGate license required',
        'Favors Data Pump if license not owned'
    FROM dual
    """


def get_migration_method_summary():
    """Executive summary for migration method selection."""
    return """
    WITH metrics AS (
        SELECT
            (SELECT ROUND(SUM(bytes)/(1024*1024*1024), 2) FROM dba_segments) AS size_gb,
            (SELECT COUNT(*) FROM dba_tables
             WHERE owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')) AS tables,
            (SELECT COUNT(*) FROM gv$session
             WHERE type = 'USER' AND status = 'ACTIVE') AS active_sessions,
            (SELECT value FROM v$parameter WHERE name = 'log_mode') AS log_mode,
            (SELECT supplemental_log_data_min FROM v$database) AS supp_log
        FROM dual
    )
    SELECT
        'Database Size' AS metric,
        TO_CHAR(size_gb) || ' GB' AS value,
        CASE WHEN size_gb < 500 THEN 'Data Pump friendly'
             ELSE 'Consider GoldenGate' END AS assessment
    FROM metrics
    UNION ALL
    SELECT 'Table Count', TO_CHAR(tables),
           CASE WHEN tables < 1000 THEN 'Manageable' ELSE 'Complex schema' END
    FROM metrics
    UNION ALL
    SELECT 'Active Sessions', TO_CHAR(active_sessions),
           CASE WHEN active_sessions > 100 THEN 'High activity - GoldenGate preferred'
                ELSE 'Moderate activity' END
    FROM metrics
    UNION ALL
    SELECT 'Archive Log Mode', log_mode,
           CASE WHEN log_mode = 'ARCHIVELOG' THEN 'GoldenGate ready'
                ELSE 'Enable for GoldenGate' END
    FROM metrics
    UNION ALL
    SELECT 'Supplemental Logging',
           CASE WHEN supp_log = 'YES' THEN 'Enabled' ELSE 'Not enabled' END,
           CASE WHEN supp_log = 'YES' THEN 'GoldenGate ready'
                ELSE 'Required for GoldenGate' END
    FROM metrics
    UNION ALL
    SELECT
        'RECOMMENDATION',
        CASE
            WHEN size_gb < 200 AND active_sessions < 50 THEN 'DATA PUMP'
            WHEN size_gb > 1000 OR active_sessions > 200 THEN 'GOLDENGATE'
            ELSE 'EVALUATE DOWNTIME TOLERANCE'
        END,
        CASE
            WHEN size_gb < 200 AND active_sessions < 50
            THEN 'Small DB with low activity - Data Pump is simpler'
            WHEN size_gb > 1000 OR active_sessions > 200
            THEN 'Large DB or high activity - GoldenGate minimizes downtime'
            ELSE 'Medium DB - choice depends on acceptable downtime window'
        END
    FROM metrics
    """


# =============================================================================
# Role/Privilege Compatibility Checks
# =============================================================================

def get_privileged_roles_check():
    """Check for roles with elevated privileges that may be restricted in cloud targets."""
    return """
    SELECT
        grantee,
        granted_role,
        admin_option,
        CASE
            WHEN granted_role IN ('DBA', 'SYSDBA', 'SYSOPER', 'SYSBACKUP', 'SYSDG', 'SYSKM', 'SYSRAC')
                THEN 'CRITICAL - Not available in ADB'
            WHEN granted_role IN ('IMP_FULL_DATABASE', 'EXP_FULL_DATABASE', 'DATAPUMP_IMP_FULL_DATABASE', 'DATAPUMP_EXP_FULL_DATABASE')
                THEN 'WARNING - Limited in ADB'
            WHEN granted_role = 'RESOURCE' AND admin_option = 'YES'
                THEN 'WARNING - Admin option will be revoked'
            ELSE 'OK'
        END AS compatibility_status,
        CASE
            WHEN granted_role IN ('DBA', 'SYSDBA', 'SYSOPER')
                THEN 'Use PDB_DBA or DWROLE instead'
            WHEN granted_role IN ('IMP_FULL_DATABASE', 'EXP_FULL_DATABASE')
                THEN 'Use Data Pump with ADMIN user'
            ELSE 'No action required'
        END AS recommendation
    FROM dba_role_privs
    WHERE grantee NOT IN ('SYS', 'SYSTEM', 'AUDSYS', 'DBSNMP')
      AND grantee NOT LIKE 'APEX_%'
      AND grantee NOT LIKE 'ORDS_%'
      AND granted_role IN (
          'DBA', 'SYSDBA', 'SYSOPER', 'SYSBACKUP', 'SYSDG', 'SYSKM', 'SYSRAC',
          'IMP_FULL_DATABASE', 'EXP_FULL_DATABASE',
          'DATAPUMP_IMP_FULL_DATABASE', 'DATAPUMP_EXP_FULL_DATABASE',
          'DELETE_CATALOG_ROLE', 'EXECUTE_CATALOG_ROLE', 'SELECT_CATALOG_ROLE'
      )
    ORDER BY
        CASE WHEN granted_role IN ('DBA', 'SYSDBA', 'SYSOPER') THEN 1 ELSE 2 END,
        grantee
    """

def get_system_privileges_check():
    """Check for system privileges that are restricted or unavailable in cloud targets."""
    return """
    SELECT
        grantee,
        privilege,
        admin_option,
        CASE
            WHEN privilege IN ('ALTER SYSTEM', 'ALTER DATABASE', 'CREATE LIBRARY',
                              'CREATE ANY DIRECTORY', 'DROP ANY DIRECTORY')
                THEN 'CRITICAL - Blocked in ADB'
            WHEN privilege LIKE '%ANY%' AND privilege NOT IN ('SELECT ANY TABLE', 'INSERT ANY TABLE',
                              'UPDATE ANY TABLE', 'DELETE ANY TABLE', 'EXECUTE ANY PROCEDURE')
                THEN 'WARNING - May be restricted'
            WHEN privilege IN ('EXEMPT ACCESS POLICY', 'EXEMPT IDENTITY POLICY',
                              'EXEMPT REDACTION POLICY', 'BECOME USER', 'SYSDBA', 'SYSOPER')
                THEN 'CRITICAL - Not available in ADB'
            ELSE 'OK'
        END AS compatibility_status,
        CASE
            WHEN privilege = 'ALTER SYSTEM' THEN 'Use DBMS_CLOUD_ADMIN procedures'
            WHEN privilege = 'CREATE LIBRARY' THEN 'External libraries not supported'
            WHEN privilege LIKE '%DIRECTORY%' THEN 'Use DBMS_CLOUD for object storage'
            ELSE 'Review privilege necessity'
        END AS recommendation
    FROM dba_sys_privs
    WHERE grantee NOT IN ('SYS', 'SYSTEM', 'AUDSYS', 'DBSNMP', 'LBACSYS', 'MDSYS', 'OLAPSYS', 'ORDDATA', 'XDB')
      AND grantee NOT LIKE 'APEX_%'
      AND grantee NOT LIKE 'ORDS_%'
      AND grantee NOT LIKE 'FLOWS_%'
      AND privilege IN (
          'ALTER SYSTEM', 'ALTER DATABASE', 'CREATE LIBRARY', 'DROP LIBRARY',
          'CREATE ANY DIRECTORY', 'DROP ANY DIRECTORY',
          'EXEMPT ACCESS POLICY', 'EXEMPT IDENTITY POLICY', 'EXEMPT REDACTION POLICY',
          'BECOME USER', 'SYSDBA', 'SYSOPER', 'SYSBACKUP', 'SYSDG', 'SYSKM',
          'CREATE EXTERNAL JOB', 'CREATE ANY JOB', 'EXECUTE ANY PROGRAM',
          'MANAGE SCHEDULER', 'DEQUEUE ANY QUEUE', 'ENQUEUE ANY QUEUE',
          'MANAGE ANY QUEUE', 'ADMINISTER DATABASE TRIGGER'
      )
    ORDER BY
        CASE WHEN privilege IN ('ALTER SYSTEM', 'ALTER DATABASE', 'SYSDBA', 'SYSOPER') THEN 1 ELSE 2 END,
        grantee
    """

def get_os_authentication_check():
    """Check for OS-authenticated users that won't work in cloud environments."""
    return """
    SELECT
        username,
        authentication_type,
        external_name,
        created,
        'CRITICAL' AS compatibility_status,
        'Convert to password authentication or use Oracle Identity Cloud Service' AS recommendation
    FROM dba_users
    WHERE authentication_type IN ('EXTERNAL', 'GLOBAL')
       OR username LIKE 'OPS$%'
       OR external_name IS NOT NULL
    ORDER BY username
    """

def get_proxy_user_check():
    """Check for proxy user configurations that may need adjustment."""
    return """
    SELECT
        proxy,
        client,
        authentication,
        CASE
            WHEN authentication = 'YES' THEN 'OK - Password required'
            ELSE 'WARNING - Review proxy authentication'
        END AS compatibility_status,
        'Verify proxy configuration works with connection pooling' AS recommendation
    FROM dba_proxies
    WHERE client NOT IN ('SYS', 'SYSTEM')
    ORDER BY proxy, client
    """

def get_privilege_compatibility_summary():
    """Summary of role and privilege compatibility issues for cloud migration."""
    return """
    SELECT * FROM (
        SELECT 'Restricted Roles' AS category,
               COUNT(*) AS issue_count,
               SUM(CASE WHEN granted_role IN ('DBA', 'SYSDBA', 'SYSOPER', 'SYSBACKUP', 'SYSDG', 'SYSKM')
                        THEN 1 ELSE 0 END) AS critical_count,
               'Roles not available in Autonomous Database' AS description
        FROM dba_role_privs
        WHERE grantee NOT IN ('SYS', 'SYSTEM', 'AUDSYS', 'DBSNMP')
          AND grantee NOT LIKE 'APEX_%'
          AND granted_role IN ('DBA', 'SYSDBA', 'SYSOPER', 'SYSBACKUP', 'SYSDG', 'SYSKM', 'SYSRAC',
                              'IMP_FULL_DATABASE', 'EXP_FULL_DATABASE')
        UNION ALL
        SELECT 'Restricted System Privileges' AS category,
               COUNT(*) AS issue_count,
               SUM(CASE WHEN privilege IN ('ALTER SYSTEM', 'ALTER DATABASE', 'SYSDBA', 'SYSOPER')
                        THEN 1 ELSE 0 END) AS critical_count,
               'System privileges blocked or restricted in ADB' AS description
        FROM dba_sys_privs
        WHERE grantee NOT IN ('SYS', 'SYSTEM', 'AUDSYS', 'DBSNMP')
          AND privilege IN ('ALTER SYSTEM', 'ALTER DATABASE', 'CREATE LIBRARY',
                           'CREATE ANY DIRECTORY', 'EXEMPT ACCESS POLICY', 'BECOME USER',
                           'SYSDBA', 'SYSOPER', 'CREATE EXTERNAL JOB')
        UNION ALL
        SELECT 'OS-Authenticated Users' AS category,
               COUNT(*) AS issue_count,
               COUNT(*) AS critical_count,
               'External/OS authentication not supported in cloud' AS description
        FROM dba_users
        WHERE authentication_type IN ('EXTERNAL', 'GLOBAL')
           OR username LIKE 'OPS$%'
        UNION ALL
        SELECT 'Proxy Users' AS category,
               COUNT(*) AS issue_count,
               0 AS critical_count,
               'Proxy configurations to review for cloud compatibility' AS description
        FROM dba_proxies
        WHERE client NOT IN ('SYS', 'SYSTEM')
    )
    WHERE issue_count > 0
    ORDER BY critical_count DESC, issue_count DESC
    """


# =============================================================================
# Traditional Audit Detection
# =============================================================================

def get_traditional_audit_check():
    """Check if traditional auditing is enabled and in use."""
    return """
    SELECT
        name AS parameter,
        value,
        CASE
            WHEN name = 'audit_trail' AND UPPER(value) IN ('DB', 'DB,EXTENDED', 'XML', 'XML,EXTENDED', 'OS')
                THEN 'WARNING - Traditional auditing enabled'
            WHEN name = 'audit_trail' AND UPPER(value) = 'NONE'
                THEN 'OK - No traditional auditing'
            WHEN name = 'unified_auditing' AND value = 'FALSE'
                THEN 'WARNING - Unified Auditing not enabled'
            WHEN name = 'unified_auditing' AND value = 'TRUE'
                THEN 'OK - Unified Auditing enabled'
            ELSE 'INFO'
        END AS status,
        CASE
            WHEN name = 'audit_trail' AND UPPER(value) != 'NONE'
                THEN 'Migrate to Unified Auditing before moving to ADB'
            WHEN name = 'unified_auditing' AND value = 'FALSE'
                THEN 'Enable Unified Auditing with DBMS_AUDIT_MGMT'
            ELSE 'No action required'
        END AS recommendation
    FROM v$parameter
    WHERE name IN ('audit_trail', 'unified_auditing')
    ORDER BY name
    """

def get_traditional_audit_policies():
    """List traditional audit options currently configured."""
    return """
    SELECT
        user_name,
        audit_option,
        success,
        failure,
        'Traditional statement auditing - migrate to Unified Audit policy' AS recommendation
    FROM dba_stmt_audit_opts
    WHERE user_name IS NOT NULL OR audit_option IS NOT NULL
    UNION ALL
    SELECT
        user_name,
        privilege AS audit_option,
        success,
        failure,
        'Traditional privilege auditing - migrate to Unified Audit policy' AS recommendation
    FROM dba_priv_audit_opts
    ORDER BY user_name NULLS LAST, audit_option
    """

def get_object_audit_options():
    """List object-level audit options that need migration."""
    return """
    SELECT
        owner,
        object_name,
        object_type,
        alt AS alter_audit,
        aud AS audit_audit,
        com AS comment_audit,
        del AS delete_audit,
        gra AS grant_audit,
        ind AS index_audit,
        ins AS insert_audit,
        loc AS lock_audit,
        ren AS rename_audit,
        sel AS select_audit,
        upd AS update_audit,
        'Convert to Unified Audit policy with object actions' AS recommendation
    FROM dba_obj_audit_opts
    WHERE owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
      AND (alt != '-/-' OR aud != '-/-' OR com != '-/-' OR del != '-/-' OR
           gra != '-/-' OR ind != '-/-' OR ins != '-/-' OR loc != '-/-' OR
           ren != '-/-' OR sel != '-/-' OR upd != '-/-')
    ORDER BY owner, object_name
    """

def get_audit_trail_size():
    """Check the size of traditional audit trail data."""
    return """
    SELECT
        segment_name AS table_name,
        ROUND(bytes / 1024 / 1024, 2) AS size_mb,
        CASE
            WHEN segment_name = 'AUD$' THEN 'Traditional audit trail - archive and purge before migration'
            WHEN segment_name = 'FGA_LOG$' THEN 'Fine-grained audit log - archive and purge before migration'
            ELSE 'Audit-related table'
        END AS recommendation
    FROM dba_segments
    WHERE owner = 'SYS'
      AND segment_name IN ('AUD$', 'FGA_LOG$')
    ORDER BY bytes DESC
    """

def get_unified_audit_policies():
    """List existing Unified Audit policies for reference."""
    return """
    SELECT
        policy_name,
        enabled_option,
        entity_name,
        entity_type,
        success,
        failure,
        'Existing Unified Audit policy - verify compatibility with target' AS status
    FROM audit_unified_enabled_policies
    ORDER BY policy_name, entity_name
    """

def get_audit_migration_summary():
    """Summary of audit configuration and migration requirements."""
    return """
    WITH audit_params AS (
        SELECT name, value FROM v$parameter WHERE name IN ('audit_trail', 'unified_auditing')
    ),
    trad_audit_counts AS (
        SELECT 'Statement Audit Options' AS category, COUNT(*) AS cnt FROM dba_stmt_audit_opts
        UNION ALL
        SELECT 'Privilege Audit Options', COUNT(*) FROM dba_priv_audit_opts
        UNION ALL
        SELECT 'Object Audit Options', COUNT(*) FROM dba_obj_audit_opts
        WHERE owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
    )
    SELECT
        'Audit Trail Setting' AS check_item,
        (SELECT value FROM audit_params WHERE name = 'audit_trail') AS current_value,
        CASE WHEN (SELECT UPPER(value) FROM audit_params WHERE name = 'audit_trail') IN ('NONE', 'DB')
             THEN 'LOW' ELSE 'MEDIUM' END AS migration_effort,
        CASE WHEN (SELECT UPPER(value) FROM audit_params WHERE name = 'audit_trail') != 'NONE'
             THEN 'Set AUDIT_TRAIL=NONE after migrating to Unified Auditing'
             ELSE 'No action needed' END AS recommendation
    FROM dual
    UNION ALL
    SELECT
        'Unified Auditing Status' AS check_item,
        (SELECT value FROM audit_params WHERE name = 'unified_auditing') AS current_value,
        CASE WHEN (SELECT value FROM audit_params WHERE name = 'unified_auditing') = 'TRUE'
             THEN 'NONE' ELSE 'MEDIUM' END AS migration_effort,
        CASE WHEN (SELECT value FROM audit_params WHERE name = 'unified_auditing') = 'FALSE'
             THEN 'Relink Oracle binary with Unified Auditing enabled'
             ELSE 'Already enabled' END AS recommendation
    FROM dual
    UNION ALL
    SELECT
        category AS check_item,
        TO_CHAR(cnt) AS current_value,
        CASE WHEN cnt > 0 THEN 'MEDIUM' ELSE 'NONE' END AS migration_effort,
        CASE WHEN cnt > 0 THEN 'Convert to Unified Audit policies' ELSE 'No conversion needed' END AS recommendation
    FROM trad_audit_counts
    WHERE cnt > 0
    ORDER BY migration_effort DESC
    """


# =============================================================================
# Target Cloud Validation
# =============================================================================

def get_target_compatibility_matrix():
    """Generate a compatibility matrix showing Pass/Fail for each cloud target."""
    return """
    WITH db_checks AS (
        SELECT
            (SELECT value FROM v$parameter WHERE name = 'db_block_size') AS block_size,
            (SELECT value FROM v$nls_parameters WHERE parameter = 'NLS_CHARACTERSET') AS charset,
            (SELECT COUNT(*) FROM dba_users WHERE authentication_type IN ('EXTERNAL', 'GLOBAL')) AS os_auth_cnt,
            (SELECT COUNT(*) FROM dba_external_tables) AS ext_tbl_cnt,
            (SELECT COUNT(*) FROM dba_objects WHERE object_type LIKE 'JAVA%' AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')) AS java_cnt,
            (SELECT COUNT(*) FROM dba_source WHERE UPPER(text) LIKE '%UTL_FILE%' AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')) AS utl_file_cnt,
            (SELECT ROUND(SUM(bytes)/1024/1024/1024/1024, 2) FROM dba_segments) AS size_tb,
            (SELECT value FROM v$parameter WHERE name = 'compatible') AS compatible_ver
        FROM dual
    ),
    scores AS (
        SELECT
            -- ADB-S Score
            CASE WHEN block_size = '8192' THEN 0 ELSE 1 END +
            CASE WHEN charset = 'AL32UTF8' THEN 0 ELSE 1 END +
            CASE WHEN os_auth_cnt = 0 THEN 0 ELSE 1 END +
            CASE WHEN ext_tbl_cnt = 0 THEN 0 ELSE 1 END +
            CASE WHEN java_cnt = 0 THEN 0 ELSE 1 END +
            CASE WHEN utl_file_cnt = 0 THEN 0 ELSE 1 END AS adb_s_fails,
            -- ADB-D Score
            CASE WHEN block_size IN ('8192','16384','32768') THEN 0 ELSE 1 END +
            CASE WHEN charset = 'AL32UTF8' THEN 0 ELSE 1 END +
            CASE WHEN os_auth_cnt = 0 THEN 0 ELSE 1 END AS adb_d_fails,
            -- ExaCS Score
            CASE WHEN block_size IN ('8192','16384','32768') THEN 0 ELSE 1 END AS exacs_fails,
            -- BaseDB Score
            CASE WHEN block_size IN ('8192','16384','32768') THEN 0 ELSE 1 END +
            CASE WHEN size_tb <= 40 THEN 0 ELSE 1 END AS basedb_fails
        FROM db_checks
    )
    SELECT
        'ADB-S (Serverless)' AS target,
        CASE WHEN adb_s_fails = 0 THEN 'PASS' ELSE 'FAIL (' || adb_s_fails || ' issues)' END AS status,
        CASE WHEN adb_s_fails = 0 THEN 'Ready for migration'
             WHEN adb_s_fails <= 2 THEN 'Minor remediation needed'
             ELSE 'Significant changes required' END AS recommendation
    FROM scores
    UNION ALL
    SELECT
        'ADB-D (Dedicated)' AS target,
        CASE WHEN adb_d_fails = 0 THEN 'PASS' ELSE 'FAIL (' || adb_d_fails || ' issues)' END AS status,
        CASE WHEN adb_d_fails = 0 THEN 'Ready for migration'
             WHEN adb_d_fails <= 2 THEN 'Minor remediation needed'
             ELSE 'Significant changes required' END AS recommendation
    FROM scores
    UNION ALL
    SELECT
        'ExaCS' AS target,
        CASE WHEN exacs_fails = 0 THEN 'PASS' ELSE 'FAIL (' || exacs_fails || ' issues)' END AS status,
        CASE WHEN exacs_fails = 0 THEN 'Ready for migration'
             ELSE 'Check block size compatibility' END AS recommendation
    FROM scores
    UNION ALL
    SELECT
        'BaseDB' AS target,
        CASE WHEN basedb_fails = 0 THEN 'PASS'
             WHEN basedb_fails = 1 THEN 'WARNING'
             ELSE 'FAIL (' || basedb_fails || ' issues)' END AS status,
        CASE WHEN basedb_fails = 0 THEN 'Ready for migration'
             ELSE 'Review size and block size' END AS recommendation
    FROM scores
    """


def get_target_validation_summary():
    """Generate validation summary for all cloud targets."""
    return """
    WITH db_info AS (
        SELECT
            (SELECT value FROM v$parameter WHERE name = 'db_block_size') AS block_size,
            (SELECT value FROM v$parameter WHERE name = 'compatible') AS compatible,
            (SELECT value FROM v$nls_parameters WHERE parameter = 'NLS_CHARACTERSET') AS charset,
            (SELECT ROUND(SUM(bytes)/1024/1024/1024/1024, 2) FROM dba_segments) AS size_tb,
            (SELECT value FROM v$parameter WHERE name = 'audit_trail') AS audit_trail,
            (SELECT COUNT(*) FROM dba_users WHERE authentication_type IN ('EXTERNAL', 'GLOBAL')) AS os_auth_users,
            (SELECT COUNT(*) FROM dba_external_tables) AS external_tables,
            (SELECT COUNT(*) FROM dba_directories WHERE directory_name NOT LIKE 'ORACLE%') AS custom_directories,
            (SELECT COUNT(*) FROM dba_source WHERE UPPER(text) LIKE '%UTL_FILE%' AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')) AS utl_file_usage,
            (SELECT COUNT(*) FROM dba_objects WHERE object_type LIKE 'JAVA%' AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')) AS java_objects
        FROM dual
    )
    SELECT
        'ADB-S' AS target,
        CASE
            WHEN block_size != '8192' THEN 'FAIL'
            WHEN charset != 'AL32UTF8' THEN 'FAIL'
            WHEN os_auth_users > 0 THEN 'FAIL'
            WHEN external_tables > 0 THEN 'FAIL'
            WHEN utl_file_usage > 0 THEN 'FAIL'
            WHEN java_objects > 0 THEN 'FAIL'
            WHEN audit_trail NOT IN ('NONE', 'DB') THEN 'WARNING'
            ELSE 'PASS'
        END AS status,
        CASE
            WHEN block_size != '8192' THEN 'Block size must be 8K'
            WHEN charset != 'AL32UTF8' THEN 'Character set must be AL32UTF8'
            WHEN os_auth_users > 0 THEN os_auth_users || ' OS-authenticated users found'
            WHEN external_tables > 0 THEN external_tables || ' external tables not supported'
            WHEN utl_file_usage > 0 THEN 'UTL_FILE usage detected in ' || utl_file_usage || ' objects'
            WHEN java_objects > 0 THEN java_objects || ' Java objects not supported'
            WHEN audit_trail NOT IN ('NONE', 'DB') THEN 'Migrate to Unified Auditing'
            ELSE 'All checks passed'
        END AS details
    FROM db_info
    UNION ALL
    SELECT
        'ADB-D' AS target,
        CASE
            WHEN block_size NOT IN ('8192', '16384', '32768') THEN 'FAIL'
            WHEN charset != 'AL32UTF8' THEN 'FAIL'
            WHEN os_auth_users > 0 THEN 'FAIL'
            WHEN external_tables > 0 THEN 'WARNING'
            WHEN utl_file_usage > 0 THEN 'WARNING'
            WHEN audit_trail NOT IN ('NONE', 'DB') THEN 'WARNING'
            ELSE 'PASS'
        END AS status,
        CASE
            WHEN block_size NOT IN ('8192', '16384', '32768') THEN 'Block size must be 8K, 16K, or 32K'
            WHEN charset != 'AL32UTF8' THEN 'Character set must be AL32UTF8'
            WHEN os_auth_users > 0 THEN os_auth_users || ' OS-authenticated users found'
            WHEN external_tables > 0 THEN external_tables || ' external tables need conversion'
            WHEN utl_file_usage > 0 THEN 'UTL_FILE needs DBMS_CLOUD conversion'
            WHEN audit_trail NOT IN ('NONE', 'DB') THEN 'Migrate to Unified Auditing'
            ELSE 'All checks passed'
        END AS details
    FROM db_info
    UNION ALL
    SELECT
        'ExaCS' AS target,
        CASE
            WHEN block_size NOT IN ('8192', '16384', '32768') THEN 'FAIL'
            WHEN TO_NUMBER(REGEXP_SUBSTR(compatible, '[0-9]+')) < 11 THEN 'FAIL'
            ELSE 'PASS'
        END AS status,
        CASE
            WHEN block_size NOT IN ('8192', '16384', '32768') THEN 'Block size must be 8K, 16K, or 32K'
            WHEN TO_NUMBER(REGEXP_SUBSTR(compatible, '[0-9]+')) < 11 THEN 'Compatible must be 11.2.0.4 or higher'
            ELSE 'All checks passed'
        END AS details
    FROM db_info
    UNION ALL
    SELECT
        'BaseDB' AS target,
        CASE
            WHEN block_size NOT IN ('8192', '16384', '32768') THEN 'FAIL'
            WHEN size_tb > 40 THEN 'WARNING'
            WHEN TO_NUMBER(REGEXP_SUBSTR(compatible, '[0-9]+')) < 11 THEN 'FAIL'
            ELSE 'PASS'
        END AS status,
        CASE
            WHEN block_size NOT IN ('8192', '16384', '32768') THEN 'Block size must be 8K, 16K, or 32K'
            WHEN size_tb > 40 THEN 'Database size ' || size_tb || 'TB exceeds single node limit'
            WHEN TO_NUMBER(REGEXP_SUBSTR(compatible, '[0-9]+')) < 11 THEN 'Compatible must be 11.2.0.4 or higher'
            ELSE 'All checks passed'
        END AS details
    FROM db_info
    ORDER BY 1
    """


def get_adb_serverless_validation():
    """Detailed validation for Autonomous Database Serverless target."""
    return """
    WITH checks AS (
        SELECT 'Block Size' AS check_name,
               (SELECT value FROM v$parameter WHERE name = 'db_block_size') AS current_value,
               '8192' AS required_value,
               CASE WHEN (SELECT value FROM v$parameter WHERE name = 'db_block_size') = '8192'
                    THEN 'PASS' ELSE 'FAIL' END AS status,
               'Database must use 8K block size for ADB-S' AS notes
        FROM dual
        UNION ALL
        SELECT 'Character Set',
               (SELECT value FROM v$nls_parameters WHERE parameter = 'NLS_CHARACTERSET'),
               'AL32UTF8',
               CASE WHEN (SELECT value FROM v$nls_parameters WHERE parameter = 'NLS_CHARACTERSET') = 'AL32UTF8'
                    THEN 'PASS' ELSE 'FAIL' END,
               'ADB-S only supports AL32UTF8 character set'
        FROM dual
        UNION ALL
        SELECT 'OS Authentication',
               TO_CHAR((SELECT COUNT(*) FROM dba_users WHERE authentication_type IN ('EXTERNAL','GLOBAL'))),
               '0',
               CASE WHEN (SELECT COUNT(*) FROM dba_users WHERE authentication_type IN ('EXTERNAL','GLOBAL')) = 0
                    THEN 'PASS' ELSE 'FAIL' END,
               'OS/External authentication not supported'
        FROM dual
        UNION ALL
        SELECT 'External Tables',
               TO_CHAR((SELECT COUNT(*) FROM dba_external_tables)),
               '0',
               CASE WHEN (SELECT COUNT(*) FROM dba_external_tables) = 0
                    THEN 'PASS' ELSE 'FAIL' END,
               'External tables not supported - use DBMS_CLOUD'
        FROM dual
        UNION ALL
        SELECT 'Java Objects',
               TO_CHAR((SELECT COUNT(*) FROM dba_objects WHERE object_type LIKE 'JAVA%' AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB'))),
               '0',
               CASE WHEN (SELECT COUNT(*) FROM dba_objects WHERE object_type LIKE 'JAVA%' AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')) = 0
                    THEN 'PASS' ELSE 'FAIL' END,
               'Java not supported in ADB-S'
        FROM dual
        UNION ALL
        SELECT 'Directory Objects',
               TO_CHAR((SELECT COUNT(*) FROM dba_directories WHERE directory_name NOT LIKE 'ORACLE%')),
               '0',
               CASE WHEN (SELECT COUNT(*) FROM dba_directories WHERE directory_name NOT LIKE 'ORACLE%') = 0
                    THEN 'PASS' ELSE 'WARNING' END,
               'Custom directories need DBMS_CLOUD conversion'
        FROM dual
        UNION ALL
        SELECT 'UTL_FILE Usage',
               TO_CHAR((SELECT COUNT(DISTINCT owner||'.'||name) FROM dba_source
                        WHERE UPPER(text) LIKE '%UTL_FILE%' AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB'))),
               '0',
               CASE WHEN (SELECT COUNT(*) FROM dba_source
                          WHERE UPPER(text) LIKE '%UTL_FILE%' AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')) = 0
                    THEN 'PASS' ELSE 'FAIL' END,
               'UTL_FILE not available - use DBMS_CLOUD'
        FROM dual
        UNION ALL
        SELECT 'Database Links',
               TO_CHAR((SELECT COUNT(*) FROM dba_db_links WHERE owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB'))),
               'N/A',
               CASE WHEN (SELECT COUNT(*) FROM dba_db_links WHERE owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')) = 0
                    THEN 'PASS' ELSE 'WARNING' END,
               'DB links supported but require wallet configuration'
        FROM dual
        UNION ALL
        SELECT 'Unified Auditing',
               (SELECT value FROM v$parameter WHERE name = 'unified_auditing'),
               'TRUE',
               CASE WHEN (SELECT value FROM v$parameter WHERE name = 'unified_auditing') = 'TRUE'
                    THEN 'PASS' ELSE 'WARNING' END,
               'ADB uses Unified Auditing - migration recommended'
        FROM dual
        UNION ALL
        SELECT 'DBA Role Grants',
               TO_CHAR((SELECT COUNT(*) FROM dba_role_privs
                        WHERE granted_role = 'DBA' AND grantee NOT IN ('SYS','SYSTEM'))),
               '0',
               CASE WHEN (SELECT COUNT(*) FROM dba_role_privs
                          WHERE granted_role = 'DBA' AND grantee NOT IN ('SYS','SYSTEM')) = 0
                    THEN 'PASS' ELSE 'FAIL' END,
               'DBA role not available - use PDB_DBA instead'
        FROM dual
    )
    SELECT
        check_name,
        current_value,
        required_value,
        status,
        notes
    FROM checks
    ORDER BY
        CASE status WHEN 'FAIL' THEN 1 WHEN 'WARNING' THEN 2 ELSE 3 END,
        check_name
    """


def get_exacs_validation():
    """Detailed validation for Exadata Cloud Service target."""
    return """
    WITH checks AS (
        SELECT 'Block Size' AS check_name,
               (SELECT value FROM v$parameter WHERE name = 'db_block_size') AS current_value,
               '8192/16384/32768' AS required_value,
               CASE WHEN (SELECT value FROM v$parameter WHERE name = 'db_block_size') IN ('8192','16384','32768')
                    THEN 'PASS' ELSE 'FAIL' END AS status,
               'Standard block sizes supported' AS notes
        FROM dual
        UNION ALL
        SELECT 'Compatible Version',
               (SELECT value FROM v$parameter WHERE name = 'compatible'),
               '11.2.0.4+',
               CASE WHEN TO_NUMBER(REGEXP_SUBSTR((SELECT value FROM v$parameter WHERE name = 'compatible'), '[0-9]+')) >= 11
                    THEN 'PASS' ELSE 'FAIL' END,
               'Minimum compatible version is 11.2.0.4'
        FROM dual
        UNION ALL
        SELECT 'Database Size (TB)',
               TO_CHAR(ROUND((SELECT SUM(bytes)/1024/1024/1024/1024 FROM dba_segments), 2)),
               'No limit',
               'PASS',
               'ExaCS supports very large databases'
        FROM dual
        UNION ALL
        SELECT 'RAC Configuration',
               (SELECT value FROM v$parameter WHERE name = 'cluster_database'),
               'TRUE/FALSE',
               'PASS',
               'RAC fully supported on ExaCS'
        FROM dual
        UNION ALL
        SELECT 'Data Guard',
               CASE WHEN (SELECT COUNT(*) FROM v$archive_dest WHERE status = 'VALID' AND target = 'STANDBY') > 0
                    THEN 'Configured' ELSE 'Not configured' END,
               'Supported',
               'PASS',
               'Data Guard fully supported on ExaCS'
        FROM dual
        UNION ALL
        SELECT 'TDE Encryption',
               CASE WHEN (SELECT COUNT(*) FROM v$encryption_wallet WHERE status = 'OPEN') > 0
                    THEN 'Enabled' ELSE 'Not enabled' END,
               'Recommended',
               CASE WHEN (SELECT COUNT(*) FROM v$encryption_wallet WHERE status = 'OPEN') > 0
                    THEN 'PASS' ELSE 'WARNING' END,
               'TDE recommended for ExaCS'
        FROM dual
    )
    SELECT check_name, current_value, required_value, status, notes
    FROM checks
    ORDER BY CASE status WHEN 'FAIL' THEN 1 WHEN 'WARNING' THEN 2 ELSE 3 END
    """


def get_basedb_validation():
    """Detailed validation for Base Database Service target."""
    return """
    WITH checks AS (
        SELECT 'Block Size' AS check_name,
               (SELECT value FROM v$parameter WHERE name = 'db_block_size') AS current_value,
               '8192/16384/32768' AS required_value,
               CASE WHEN (SELECT value FROM v$parameter WHERE name = 'db_block_size') IN ('8192','16384','32768')
                    THEN 'PASS' ELSE 'FAIL' END AS status,
               'Standard block sizes supported' AS notes
        FROM dual
        UNION ALL
        SELECT 'Database Size (TB)',
               TO_CHAR(ROUND((SELECT SUM(bytes)/1024/1024/1024/1024 FROM dba_segments), 2)),
               '< 40 TB per node',
               CASE WHEN (SELECT SUM(bytes)/1024/1024/1024/1024 FROM dba_segments) <= 40
                    THEN 'PASS' ELSE 'WARNING' END,
               'Max 40TB per VM shape - may need RAC'
        FROM dual
        UNION ALL
        SELECT 'Compatible Version',
               (SELECT value FROM v$parameter WHERE name = 'compatible'),
               '11.2.0.4+',
               CASE WHEN TO_NUMBER(REGEXP_SUBSTR((SELECT value FROM v$parameter WHERE name = 'compatible'), '[0-9]+')) >= 11
                    THEN 'PASS' ELSE 'FAIL' END,
               'Minimum compatible version is 11.2.0.4'
        FROM dual
        UNION ALL
        SELECT 'Edition',
               (SELECT BANNER FROM v$version WHERE ROWNUM = 1),
               'SE/EE/EE-HP/EE-EP',
               'PASS',
               'All editions available'
        FROM dual
    )
    SELECT check_name, current_value, required_value, status, notes
    FROM checks
    ORDER BY CASE status WHEN 'FAIL' THEN 1 WHEN 'WARNING' THEN 2 ELSE 3 END
    """


# =============================================================================
# Snowflake Target Validation
# =============================================================================

def get_snowflake_compatibility_summary():
    """Generate overall Snowflake migration compatibility summary."""
    return """
    WITH metrics AS (
        SELECT
            -- Unsupported data types
            (SELECT COUNT(*) FROM dba_tab_columns
             WHERE data_type IN ('LONG', 'LONG RAW', 'BFILE', 'ROWID', 'UROWID')
               AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')) AS unsupported_types,
            -- Spatial data
            (SELECT COUNT(*) FROM dba_tab_columns
             WHERE data_type LIKE 'SDO_%' OR data_type = 'MDSYS.SDO_GEOMETRY'
               AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')) AS spatial_columns,
            -- XMLType columns
            (SELECT COUNT(*) FROM dba_tab_columns
             WHERE data_type = 'XMLTYPE'
               AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')) AS xml_columns,
            -- PL/SQL packages (not supported)
            (SELECT COUNT(*) FROM dba_objects
             WHERE object_type = 'PACKAGE'
               AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')) AS package_count,
            -- Triggers (not supported - need Streams/Tasks)
            (SELECT COUNT(*) FROM dba_triggers
             WHERE owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')) AS trigger_count,
            -- Database links (not supported)
            (SELECT COUNT(*) FROM dba_db_links
             WHERE owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')) AS dblink_count,
            -- User-defined types
            (SELECT COUNT(*) FROM dba_types
             WHERE owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')) AS udt_count,
            -- Large CLOBs > 16MB
            (SELECT COUNT(DISTINCT owner||'.'||table_name||'.'||column_name)
             FROM dba_tab_columns WHERE data_type IN ('CLOB','NCLOB')
               AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')) AS clob_columns,
            -- Large BLOBs
            (SELECT COUNT(DISTINCT owner||'.'||table_name||'.'||column_name)
             FROM dba_tab_columns WHERE data_type = 'BLOB'
               AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')) AS blob_columns
        FROM dual
    )
    SELECT
        'Snowflake' AS target,
        CASE
            WHEN unsupported_types > 0 OR spatial_columns > 0 THEN 'FAIL'
            WHEN package_count > 10 OR trigger_count > 10 OR udt_count > 5 THEN 'FAIL'
            WHEN dblink_count > 0 OR xml_columns > 5 THEN 'WARNING'
            WHEN package_count > 0 OR trigger_count > 0 THEN 'WARNING'
            ELSE 'PASS'
        END AS status,
        CASE
            WHEN unsupported_types > 0 THEN unsupported_types || ' columns with unsupported data types (LONG, BFILE, ROWID)'
            WHEN spatial_columns > 0 THEN spatial_columns || ' spatial columns require conversion to GEOGRAPHY/GEOMETRY'
            WHEN package_count > 10 THEN package_count || ' PL/SQL packages must be decomposed'
            WHEN trigger_count > 10 THEN trigger_count || ' triggers must be converted to Streams/Tasks'
            WHEN udt_count > 5 THEN udt_count || ' user-defined types must be converted to VARIANT'
            WHEN dblink_count > 0 THEN dblink_count || ' database links not supported'
            WHEN xml_columns > 5 THEN xml_columns || ' XMLType columns need VARIANT conversion'
            WHEN package_count > 0 THEN package_count || ' packages need conversion (minor)'
            WHEN trigger_count > 0 THEN trigger_count || ' triggers need conversion (minor)'
            ELSE 'Database is compatible with Snowflake migration'
        END AS details,
        CASE
            WHEN unsupported_types > 0 OR spatial_columns > 0 OR package_count > 10 THEN 'Significant re-engineering required'
            WHEN package_count > 0 OR trigger_count > 0 OR dblink_count > 0 THEN 'Moderate code conversion needed'
            ELSE 'Ready for migration with minimal changes'
        END AS recommendation
    FROM metrics
    """


def get_snowflake_unsupported_datatypes():
    """Check for Oracle data types not supported in Snowflake."""
    return """
    SELECT
        owner,
        table_name,
        column_name,
        data_type,
        CASE
            WHEN data_type IN ('LONG', 'LONG RAW') THEN 'CRITICAL - Convert to CLOB/BLOB first, then VARCHAR/BINARY'
            WHEN data_type = 'BFILE' THEN 'CRITICAL - External files not supported, redesign required'
            WHEN data_type IN ('ROWID', 'UROWID') THEN 'CRITICAL - No equivalent, re-engineer row identification'
            WHEN data_type LIKE 'INTERVAL%' THEN 'WARNING - Convert to VARCHAR or separate columns'
            WHEN data_type LIKE 'SDO_%' OR data_type = 'MDSYS.SDO_GEOMETRY'
                THEN 'WARNING - Convert to Snowflake GEOGRAPHY/GEOMETRY'
            WHEN data_type = 'XMLTYPE' THEN 'WARNING - Convert to VARIANT semi-structured type'
            WHEN data_type = 'ANYDATA' THEN 'CRITICAL - No equivalent, redesign required'
            ELSE 'Review required'
        END AS migration_impact,
        CASE
            WHEN data_type IN ('LONG', 'LONG RAW') THEN 'ALTER TABLE MODIFY to CLOB/BLOB before migration'
            WHEN data_type = 'BFILE' THEN 'Load file contents into BLOB or use external stage'
            WHEN data_type IN ('ROWID', 'UROWID') THEN 'Add surrogate key column for row identification'
            WHEN data_type LIKE 'SDO_%' THEN 'Use ST_AsGeoJSON() to convert, load as GEOGRAPHY'
            WHEN data_type = 'XMLTYPE' THEN 'Convert to CLOB, load as VARIANT in Snowflake'
            ELSE 'Manual conversion required'
        END AS recommendation
    FROM dba_tab_columns
    WHERE data_type IN ('LONG', 'LONG RAW', 'BFILE', 'ROWID', 'UROWID', 'ANYDATA', 'ANYTYPE',
                        'XMLTYPE', 'URITYPE', 'HTTPURITYPE', 'XDBURITYPE', 'DBURITYPE')
       OR data_type LIKE 'SDO_%'
       OR data_type LIKE 'INTERVAL%'
       OR data_type = 'MDSYS.SDO_GEOMETRY'
    AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
    ORDER BY
        CASE
            WHEN data_type IN ('LONG', 'LONG RAW', 'BFILE', 'ROWID', 'UROWID', 'ANYDATA') THEN 1
            ELSE 2
        END,
        owner, table_name, column_name
    """


def get_snowflake_plsql_analysis():
    """Analyze PL/SQL code that requires conversion for Snowflake."""
    return """
    SELECT
        object_type,
        COUNT(*) AS object_count,
        CASE object_type
            WHEN 'PACKAGE' THEN 'CRITICAL - Must decompose into standalone procedures/functions'
            WHEN 'PACKAGE BODY' THEN 'CRITICAL - Package bodies must be converted'
            WHEN 'TRIGGER' THEN 'CRITICAL - Convert to Snowflake Streams + Tasks'
            WHEN 'PROCEDURE' THEN 'WARNING - Convert to Snowflake Scripting or JavaScript'
            WHEN 'FUNCTION' THEN 'WARNING - Convert to Snowflake UDF (SQL/JavaScript/Python)'
            WHEN 'TYPE' THEN 'WARNING - Convert to VARIANT/OBJECT semi-structured type'
            WHEN 'TYPE BODY' THEN 'WARNING - Type methods must be converted to UDFs'
            ELSE 'Review required'
        END AS migration_impact,
        CASE object_type
            WHEN 'PACKAGE' THEN 'Extract procedures/functions, handle global variables via table or session'
            WHEN 'TRIGGER' THEN 'Create Stream on table, Task to process changes'
            WHEN 'PROCEDURE' THEN 'Rewrite using Snowflake Scripting (SQL) or JavaScript'
            WHEN 'FUNCTION' THEN 'Rewrite as Snowflake UDF - consider Python for complex logic'
            WHEN 'TYPE' THEN 'Define equivalent OBJECT structure or use VARIANT'
            ELSE 'Manual analysis required'
        END AS recommendation
    FROM dba_objects
    WHERE object_type IN ('PACKAGE', 'PACKAGE BODY', 'TRIGGER', 'PROCEDURE', 'FUNCTION', 'TYPE', 'TYPE BODY')
      AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
    GROUP BY object_type
    ORDER BY
        CASE object_type
            WHEN 'PACKAGE' THEN 1
            WHEN 'PACKAGE BODY' THEN 2
            WHEN 'TRIGGER' THEN 3
            ELSE 4
        END
    """


def get_snowflake_large_objects_check():
    """Check for LOB columns that may exceed Snowflake limits (VARCHAR 16MB, BINARY 8MB)."""
    return """
    WITH lob_stats AS (
        SELECT
            c.owner,
            c.table_name,
            c.column_name,
            c.data_type,
            t.num_rows,
            ls.securefile,
            ROUND(ls.segment_bytes / 1024 / 1024, 2) AS lob_size_mb
        FROM dba_tab_columns c
        LEFT JOIN dba_tables t ON c.owner = t.owner AND c.table_name = t.table_name
        LEFT JOIN (
            SELECT lb.owner, lb.table_name, lb.column_name, lb.securefile,
                   SUM(sg.bytes) AS segment_bytes
            FROM dba_lobs lb
            JOIN dba_segments sg ON lb.segment_name = sg.segment_name AND lb.owner = sg.owner
            GROUP BY lb.owner, lb.table_name, lb.column_name, lb.securefile
        ) ls ON c.owner = ls.owner AND c.table_name = ls.table_name AND c.column_name = ls.column_name
        WHERE c.data_type IN ('CLOB', 'NCLOB', 'BLOB')
          AND c.owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
    )
    SELECT
        owner,
        table_name,
        column_name,
        data_type,
        num_rows,
        lob_size_mb,
        CASE
            WHEN data_type IN ('CLOB', 'NCLOB') AND lob_size_mb > 16000
                THEN 'CRITICAL - Total LOB data exceeds 16MB VARCHAR limit'
            WHEN data_type = 'BLOB' AND lob_size_mb > 8000
                THEN 'CRITICAL - Total LOB data exceeds 8MB BINARY limit'
            WHEN data_type IN ('CLOB', 'NCLOB')
                THEN 'WARNING - Individual values > 16MB will fail (check max length)'
            WHEN data_type = 'BLOB'
                THEN 'WARNING - Individual values > 8MB will fail (check max length)'
            ELSE 'OK'
        END AS migration_impact,
        CASE
            WHEN data_type IN ('CLOB', 'NCLOB') THEN 'Snowflake VARCHAR limit is 16MB per value'
            WHEN data_type = 'BLOB' THEN 'Snowflake BINARY limit is 8MB per value'
            ELSE 'Review individual value sizes'
        END AS snowflake_limit,
        'Store large objects in external stage (S3/Azure/GCS) if exceeding limits' AS recommendation
    FROM lob_stats
    WHERE lob_size_mb IS NOT NULL OR data_type IS NOT NULL
    ORDER BY lob_size_mb DESC NULLS LAST
    """


def get_snowflake_constraint_analysis():
    """Analyze constraints - Snowflake only enforces NOT NULL."""
    return """
    SELECT
        constraint_type,
        COUNT(*) AS constraint_count,
        CASE constraint_type
            WHEN 'P' THEN 'INFO - Primary keys defined but NOT ENFORCED in Snowflake'
            WHEN 'U' THEN 'INFO - Unique constraints defined but NOT ENFORCED in Snowflake'
            WHEN 'R' THEN 'WARNING - Foreign keys NOT SUPPORTED - move validation to ETL'
            WHEN 'C' THEN 'WARNING - Check constraints NOT ENFORCED - move validation to ETL'
            ELSE 'Review required'
        END AS migration_impact,
        CASE constraint_type
            WHEN 'P' THEN 'Primary Key'
            WHEN 'U' THEN 'Unique'
            WHEN 'R' THEN 'Foreign Key'
            WHEN 'C' THEN 'Check'
            ELSE constraint_type
        END AS constraint_name,
        CASE constraint_type
            WHEN 'P' THEN 'Can define for documentation/BI tools but won''t prevent duplicates'
            WHEN 'U' THEN 'Can define for documentation but won''t prevent duplicates'
            WHEN 'R' THEN 'Implement referential integrity checks in ETL/ELT pipelines'
            WHEN 'C' THEN 'Implement validation logic in stored procedures or ETL'
            ELSE 'Manual review required'
        END AS recommendation
    FROM dba_constraints
    WHERE owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
      AND constraint_type IN ('P', 'U', 'R', 'C')
    GROUP BY constraint_type
    ORDER BY
        CASE constraint_type WHEN 'R' THEN 1 WHEN 'C' THEN 2 ELSE 3 END
    """


def get_snowflake_syntax_issues():
    """Check for Oracle-specific SQL syntax that needs conversion."""
    return """
    WITH syntax_checks AS (
        -- Check for (+) outer join syntax
        SELECT 'Outer Join (+) Syntax' AS check_name,
               COUNT(*) AS occurrence_count,
               'WARNING' AS severity,
               'Convert to ANSI LEFT/RIGHT/FULL OUTER JOIN syntax' AS recommendation
        FROM dba_source
        WHERE REGEXP_LIKE(text, '\\(\\+\\)')
          AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
        UNION ALL
        -- Check for CONNECT BY hierarchical queries
        SELECT 'CONNECT BY Hierarchical Queries' AS check_name,
               COUNT(*) AS occurrence_count,
               'WARNING' AS severity,
               'Convert to recursive CTE (WITH RECURSIVE) syntax' AS recommendation
        FROM dba_source
        WHERE UPPER(text) LIKE '%CONNECT BY%'
          AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
        UNION ALL
        -- Check for Oracle hints
        SELECT 'Oracle Optimizer Hints' AS check_name,
               COUNT(*) AS occurrence_count,
               'INFO' AS severity,
               'Remove hints - Snowflake does not support query hints' AS recommendation
        FROM dba_source
        WHERE REGEXP_LIKE(text, '/\\*\\+.*\\*/')
          AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
        UNION ALL
        -- Check for ROWNUM usage
        SELECT 'ROWNUM Pseudo-column' AS check_name,
               COUNT(*) AS occurrence_count,
               'WARNING' AS severity,
               'Convert to ROW_NUMBER() window function or LIMIT clause' AS recommendation
        FROM dba_source
        WHERE UPPER(text) LIKE '%ROWNUM%'
          AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
        UNION ALL
        -- Check for ROWID usage
        SELECT 'ROWID Pseudo-column' AS check_name,
               COUNT(*) AS occurrence_count,
               'CRITICAL' AS severity,
               'No Snowflake equivalent - add surrogate key or unique identifier' AS recommendation
        FROM dba_source
        WHERE UPPER(text) LIKE '%ROWID%'
          AND UPPER(text) NOT LIKE '%UROWID%'
          AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
        UNION ALL
        -- Check for DECODE usage (supported but CASE preferred)
        SELECT 'DECODE Function' AS check_name,
               COUNT(*) AS occurrence_count,
               'INFO' AS severity,
               'Snowflake supports DECODE, but CASE WHEN is more portable' AS recommendation
        FROM dba_source
        WHERE UPPER(text) LIKE '%DECODE(%'
          AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
    )
    SELECT check_name, occurrence_count, severity, recommendation
    FROM syntax_checks
    WHERE occurrence_count > 0
    ORDER BY
        CASE severity WHEN 'CRITICAL' THEN 1 WHEN 'WARNING' THEN 2 ELSE 3 END,
        occurrence_count DESC
    """


def get_snowflake_dblinks_synonyms():
    """Check for database links and synonyms not supported in Snowflake."""
    return """
    SELECT
        'Database Link' AS object_type,
        owner,
        db_link AS object_name,
        host AS target,
        'CRITICAL - Database links not supported in Snowflake' AS migration_impact,
        'Options: 1) Replicate data via ETL, 2) Use Snowflake Data Sharing, 3) Use External Tables' AS recommendation
    FROM dba_db_links
    WHERE owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
    UNION ALL
    SELECT
        'Synonym' AS object_type,
        owner,
        synonym_name AS object_name,
        table_owner || '.' || table_name AS target,
        'WARNING - Synonyms not supported, references will use original object name' AS migration_impact,
        'Update application code to use fully qualified object names' AS recommendation
    FROM dba_synonyms
    WHERE owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
      AND table_owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
    ORDER BY object_type, owner, object_name
    """


def get_snowflake_sequence_analysis():
    """Analyze sequences for Snowflake compatibility."""
    return """
    SELECT
        sequence_owner AS owner,
        sequence_name,
        min_value,
        max_value,
        increment_by,
        cycle_flag,
        cache_size,
        CASE
            WHEN max_value > 9223372036854775807
                THEN 'CRITICAL - Max value exceeds Snowflake limit (2^63-1)'
            WHEN min_value < -9223372036854775808
                THEN 'CRITICAL - Min value below Snowflake limit (-2^63)'
            WHEN cycle_flag = 'Y'
                THEN 'WARNING - CYCLE option supported but verify behavior'
            ELSE 'OK'
        END AS migration_impact,
        'Note: Snowflake does not support CURRVAL - only NEXTVAL' AS currval_note,
        CASE
            WHEN max_value > 9223372036854775807 THEN 'Reduce max_value to 9223372036854775807'
            WHEN cache_size > 1 THEN 'Cache is handled differently in Snowflake'
            ELSE 'Direct migration possible'
        END AS recommendation
    FROM dba_sequences
    WHERE sequence_owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
    ORDER BY sequence_owner, sequence_name
    """


def get_snowflake_index_analysis():
    """Analyze indexes - Snowflake doesn't use traditional indexes."""
    return """
    SELECT
        index_type,
        COUNT(*) AS index_count,
        SUM(CASE WHEN uniqueness = 'UNIQUE' THEN 1 ELSE 0 END) AS unique_indexes,
        'INFO - Snowflake does not use traditional indexes' AS migration_impact,
        CASE index_type
            WHEN 'NORMAL' THEN 'Snowflake uses automatic micro-partitioning and pruning'
            WHEN 'BITMAP' THEN 'Not needed - Snowflake optimizes low-cardinality columns automatically'
            WHEN 'FUNCTION-BASED NORMAL' THEN 'Create computed columns or use expressions in queries'
            WHEN 'IOT - TOP' THEN 'Index-organized tables become regular tables'
            WHEN 'CLUSTER' THEN 'Consider Snowflake clustering keys for large tables'
            ELSE 'Automatic optimization in Snowflake'
        END AS recommendation
    FROM dba_indexes
    WHERE owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
    GROUP BY index_type
    ORDER BY index_count DESC
    """


def get_snowflake_validation_detail():
    """Detailed validation checklist for Snowflake migration."""
    return """
    WITH checks AS (
        -- Data type check
        SELECT 'Unsupported Data Types' AS check_name,
               TO_CHAR((SELECT COUNT(*) FROM dba_tab_columns
                        WHERE data_type IN ('LONG','LONG RAW','BFILE','ROWID','UROWID','ANYDATA')
                          AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB'))) AS current_value,
               '0' AS required_value,
               CASE WHEN (SELECT COUNT(*) FROM dba_tab_columns
                          WHERE data_type IN ('LONG','LONG RAW','BFILE','ROWID','UROWID','ANYDATA')
                            AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')) = 0
                    THEN 'PASS' ELSE 'FAIL' END AS status,
               'LONG, BFILE, ROWID types have no Snowflake equivalent' AS notes
        FROM dual
        UNION ALL
        -- Spatial data check
        SELECT 'Spatial Data (SDO_GEOMETRY)' AS check_name,
               TO_CHAR((SELECT COUNT(*) FROM dba_tab_columns
                        WHERE (data_type LIKE 'SDO_%' OR data_type = 'MDSYS.SDO_GEOMETRY')
                          AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB'))) AS current_value,
               '0 (or converted)' AS required_value,
               CASE WHEN (SELECT COUNT(*) FROM dba_tab_columns
                          WHERE (data_type LIKE 'SDO_%' OR data_type = 'MDSYS.SDO_GEOMETRY')
                            AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')) = 0
                    THEN 'PASS' ELSE 'WARNING' END AS status,
               'Convert to Snowflake GEOGRAPHY or GEOMETRY type' AS notes
        FROM dual
        UNION ALL
        -- PL/SQL Packages check
        SELECT 'PL/SQL Packages' AS check_name,
               TO_CHAR((SELECT COUNT(*) FROM dba_objects
                        WHERE object_type = 'PACKAGE'
                          AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB'))) AS current_value,
               '0' AS required_value,
               CASE WHEN (SELECT COUNT(*) FROM dba_objects
                          WHERE object_type = 'PACKAGE'
                            AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')) = 0
                    THEN 'PASS' ELSE 'FAIL' END AS status,
               'Packages must be decomposed into standalone procedures/functions' AS notes
        FROM dual
        UNION ALL
        -- Triggers check
        SELECT 'Database Triggers' AS check_name,
               TO_CHAR((SELECT COUNT(*) FROM dba_triggers
                        WHERE owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB'))) AS current_value,
               '0' AS required_value,
               CASE WHEN (SELECT COUNT(*) FROM dba_triggers
                          WHERE owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')) = 0
                    THEN 'PASS' ELSE 'WARNING' END AS status,
               'Convert triggers to Snowflake Streams + Tasks' AS notes
        FROM dual
        UNION ALL
        -- Database links check
        SELECT 'Database Links' AS check_name,
               TO_CHAR((SELECT COUNT(*) FROM dba_db_links
                        WHERE owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB'))) AS current_value,
               '0' AS required_value,
               CASE WHEN (SELECT COUNT(*) FROM dba_db_links
                          WHERE owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')) = 0
                    THEN 'PASS' ELSE 'FAIL' END AS status,
               'Database links not supported - use ETL or Data Sharing' AS notes
        FROM dual
        UNION ALL
        -- User-defined types check
        SELECT 'User-Defined Types' AS check_name,
               TO_CHAR((SELECT COUNT(*) FROM dba_types
                        WHERE owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB'))) AS current_value,
               '0' AS required_value,
               CASE WHEN (SELECT COUNT(*) FROM dba_types
                          WHERE owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')) = 0
                    THEN 'PASS' ELSE 'WARNING' END AS status,
               'Convert UDTs to VARIANT or OBJECT semi-structured types' AS notes
        FROM dual
        UNION ALL
        -- Foreign keys check
        SELECT 'Foreign Key Constraints' AS check_name,
               TO_CHAR((SELECT COUNT(*) FROM dba_constraints
                        WHERE constraint_type = 'R'
                          AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB'))) AS current_value,
               'N/A' AS required_value,
               'INFO' AS status,
               'Foreign keys not enforced in Snowflake - document for ETL validation' AS notes
        FROM dual
    )
    SELECT check_name, current_value, required_value, status, notes
    FROM checks
    ORDER BY
        CASE status WHEN 'FAIL' THEN 1 WHEN 'WARNING' THEN 2 WHEN 'INFO' THEN 3 ELSE 4 END
    """


def get_snowflake_storage_clause_detection():
    """Detect Oracle-specific DDL storage clauses that must be removed for Snowflake."""
    return """
    WITH storage_analysis AS (
        -- Tables with explicit tablespace assignments
        SELECT 'TABLESPACE' AS clause_type,
               COUNT(*) AS object_count,
               'INFO' AS severity,
               'Remove TABLESPACE clause - Snowflake manages storage automatically' AS recommendation
        FROM dba_tables
        WHERE tablespace_name IS NOT NULL
          AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
        UNION ALL
        -- Tables with compression settings
        SELECT 'COMPRESSION' AS clause_type,
               COUNT(*) AS object_count,
               'INFO' AS severity,
               'Remove COMPRESS/NOCOMPRESS - Snowflake auto-compresses all data' AS recommendation
        FROM dba_tables
        WHERE compression != 'DISABLED'
          AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
        UNION ALL
        -- Partitioned tables
        SELECT 'PARTITIONING' AS clause_type,
               COUNT(*) AS object_count,
               'WARNING' AS severity,
               'Remove PARTITION BY - Snowflake uses automatic micro-partitioning; consider CLUSTER BY for large tables' AS recommendation
        FROM dba_part_tables
        WHERE owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
        UNION ALL
        -- Sub-partitioned tables
        SELECT 'SUBPARTITIONING' AS clause_type,
               COUNT(*) AS object_count,
               'WARNING' AS severity,
               'Remove SUBPARTITION BY - not applicable in Snowflake' AS recommendation
        FROM dba_part_tables
        WHERE subpartitioning_type != 'NONE'
          AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
        UNION ALL
        -- Index-organized tables (IOT)
        SELECT 'INDEX-ORGANIZED TABLE (IOT)' AS clause_type,
               COUNT(*) AS object_count,
               'WARNING' AS severity,
               'Convert to regular table - Snowflake has no IOT concept; consider CLUSTER BY on primary key columns' AS recommendation
        FROM dba_tables
        WHERE iot_type IS NOT NULL
          AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
        UNION ALL
        -- All indexes (to be removed)
        SELECT 'INDEXES (all types)' AS clause_type,
               COUNT(*) AS object_count,
               'INFO' AS severity,
               'Remove all CREATE INDEX statements - Snowflake uses automatic micro-partitioning and pruning' AS recommendation
        FROM dba_indexes
        WHERE owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
        UNION ALL
        -- Parallel settings
        SELECT 'PARALLEL DEGREE' AS clause_type,
               COUNT(*) AS object_count,
               'INFO' AS severity,
               'Remove PARALLEL clause - Snowflake parallelism is managed by warehouse sizing' AS recommendation
        FROM dba_tables
        WHERE degree IS NOT NULL AND TRIM(degree) NOT IN ('1', '0', 'DEFAULT')
          AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
        UNION ALL
        -- Clustered tables
        SELECT 'TABLE CLUSTERS' AS clause_type,
               COUNT(*) AS object_count,
               'WARNING' AS severity,
               'Remove CLUSTER clause - Snowflake does not support table clusters; use CLUSTER BY instead' AS recommendation
        FROM dba_clusters
        WHERE owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
    )
    SELECT clause_type, object_count, severity, recommendation
    FROM storage_analysis
    WHERE object_count > 0
    ORDER BY
        CASE severity WHEN 'CRITICAL' THEN 1 WHEN 'WARNING' THEN 2 ELSE 3 END,
        object_count DESC
    """


def get_snowflake_materialized_view_analysis():
    """Analyze materialized views for Snowflake compatibility (significant limitations)."""
    return """
    SELECT
        mv.owner,
        mv.mview_name,
        mv.container_name AS base_table,
        mv.refresh_mode,
        mv.refresh_method,
        mv.build_mode,
        mv.fast_refreshable,
        mv.staleness,
        mv.compile_state,
        mv.last_refresh_date,
        CASE
            WHEN mv.refresh_method = 'FAST'
                THEN 'WARNING - Snowflake MVs auto-refresh only (no fast/incremental refresh)'
            WHEN mv.refresh_method = 'FORCE'
                THEN 'WARNING - Snowflake MVs auto-refresh only (no FORCE option)'
            WHEN mv.refresh_mode = 'DEMAND'
                THEN 'INFO - Snowflake MVs are auto-refreshed (no on-demand refresh)'
            ELSE 'INFO - Review refresh strategy'
        END AS migration_impact,
        CASE
            WHEN mv.compile_state != 'VALID'
                THEN 'CRITICAL - MV is invalid, fix before migration'
            ELSE 'OK'
        END AS health_status,
        'Snowflake MV limits: Enterprise Edition required, 1 MV per base table, limited aggregates, no MV-to-MV refs, auto-refresh only' AS snowflake_limitations,
        CASE
            WHEN mv.refresh_method = 'FAST'
                THEN 'Consider Snowflake Streams + Tasks for incremental refresh pattern'
            WHEN mv.refresh_method = 'COMPLETE'
                THEN 'Snowflake auto-refresh is closest equivalent; or use scheduled Task with CREATE TABLE AS'
            ELSE 'Evaluate if MV can be replaced with a view or Snowflake auto-refresh MV'
        END AS recommendation
    FROM dba_mviews mv
    WHERE mv.owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
    ORDER BY mv.owner, mv.mview_name
    """


def get_snowflake_temporary_table_analysis():
    """Analyze Oracle global temporary tables for Snowflake migration."""
    return """
    SELECT
        t.owner,
        t.table_name,
        t.duration AS oracle_scope,
        t.num_rows,
        (SELECT COUNT(*) FROM dba_tab_columns c
         WHERE c.owner = t.owner AND c.table_name = t.table_name) AS column_count,
        CASE t.duration
            WHEN 'SYS$TRANSACTION'
                THEN 'Transaction-scoped GTT - data deleted on COMMIT'
            WHEN 'SYS$SESSION'
                THEN 'Session-scoped GTT - data persists until session end'
            ELSE 'Unknown duration'
        END AS oracle_behavior,
        CASE t.duration
            WHEN 'SYS$TRANSACTION'
                THEN 'WARNING - Snowflake temporary tables are session-scoped only (no transaction-scope)'
            WHEN 'SYS$SESSION'
                THEN 'INFO - Snowflake temporary tables are session-scoped (similar behavior)'
            ELSE 'Review required'
        END AS migration_impact,
        CASE t.duration
            WHEN 'SYS$TRANSACTION'
                THEN 'Use CREATE TEMPORARY TABLE + explicit TRUNCATE/DELETE after commit, or redesign logic'
            WHEN 'SYS$SESSION'
                THEN 'Use CREATE TEMPORARY TABLE (auto-dropped at session end)'
            ELSE 'Manual review required'
        END AS recommendation,
        'Alternatives: TEMPORARY TABLE (session-scoped, auto-dropped), TRANSIENT TABLE (persists but no Fail-safe)' AS snowflake_options
    FROM dba_tables t
    WHERE t.temporary = 'Y'
      AND t.owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
    ORDER BY t.owner, t.table_name
    """


def get_snowflake_identity_column_analysis():
    """Analyze identity columns and sequence-based auto-increment patterns for Snowflake."""
    return """
    WITH identity_cols AS (
        SELECT
            owner,
            table_name,
            column_name,
            generation_type,
            identity_options,
            'Identity Column' AS source_type
        FROM dba_tab_identity_cols
        WHERE owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
    ),
    seq_defaults AS (
        SELECT DISTINCT
            d.owner,
            d.name AS table_name,
            'N/A (via trigger)' AS column_name,
            NULL AS generation_type,
            'Sequence: ' || d.referenced_owner || '.' || d.referenced_name AS identity_options,
            'Sequence Default' AS source_type
        FROM all_dependencies d
        WHERE d.type = 'TRIGGER'
          AND d.referenced_type = 'SEQUENCE'
          AND d.owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
    )
    SELECT
        owner,
        table_name,
        column_name,
        source_type,
        generation_type,
        identity_options,
        CASE source_type
            WHEN 'Identity Column'
                THEN 'INFO - Snowflake supports AUTOINCREMENT / IDENTITY columns'
            WHEN 'Sequence Default'
                THEN 'WARNING - Convert sequence default to AUTOINCREMENT or Snowflake sequence'
            ELSE 'Review required'
        END AS migration_impact,
        CASE source_type
            WHEN 'Identity Column'
                THEN 'Use AUTOINCREMENT or IDENTITY(start, increment) in Snowflake column definition'
            WHEN 'Sequence Default'
                THEN 'Option 1: Use AUTOINCREMENT column. Option 2: Create Snowflake sequence + DEFAULT seq.NEXTVAL'
            ELSE 'Manual review required'
        END AS recommendation
    FROM (
        SELECT * FROM identity_cols
        UNION ALL
        SELECT * FROM seq_defaults
    )
    ORDER BY owner, table_name, column_name
    """


def get_snowflake_function_usage_detection():
    """Detect Oracle-specific function and syntax usage in PL/SQL code requiring Snowflake conversion."""
    return r"""
    WITH function_checks AS (
        -- SYSDATE usage
        SELECT 'SYSDATE' AS function_name,
               COUNT(*) AS occurrence_count,
               'INFO' AS severity,
               'CURRENT_TIMESTAMP()' AS snowflake_equivalent,
               'Snowflake supports SYSDATE() as alias but CURRENT_TIMESTAMP() preferred' AS recommendation
        FROM dba_source
        WHERE UPPER(text) LIKE '%SYSDATE%'
          AND UPPER(text) NOT LIKE '%SYSTIMESTAMP%'
          AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
        UNION ALL
        -- SYSTIMESTAMP usage
        SELECT 'SYSTIMESTAMP' AS function_name,
               COUNT(*) AS occurrence_count,
               'INFO' AS severity,
               'CURRENT_TIMESTAMP()' AS snowflake_equivalent,
               'Direct replacement available' AS recommendation
        FROM dba_source
        WHERE UPPER(text) LIKE '%SYSTIMESTAMP%'
          AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
        UNION ALL
        -- FROM DUAL usage
        SELECT 'FROM DUAL' AS function_name,
               COUNT(*) AS occurrence_count,
               'INFO' AS severity,
               'Not needed (remove FROM DUAL)' AS snowflake_equivalent,
               'Snowflake allows SELECT without FROM clause' AS recommendation
        FROM dba_source
        WHERE UPPER(text) LIKE '%FROM DUAL%'
          AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
        UNION ALL
        -- NVL usage
        SELECT 'NVL()' AS function_name,
               COUNT(*) AS occurrence_count,
               'INFO' AS severity,
               'NVL() (supported), IFNULL(), or COALESCE()' AS snowflake_equivalent,
               'Snowflake supports NVL natively - no change required' AS recommendation
        FROM dba_source
        WHERE REGEXP_LIKE(UPPER(text), 'NVL\s*\(')
          AND NOT REGEXP_LIKE(UPPER(text), 'NVL2\s*\(')
          AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
        UNION ALL
        -- NVL2 usage
        SELECT 'NVL2()' AS function_name,
               COUNT(*) AS occurrence_count,
               'INFO' AS severity,
               'NVL2() (supported) or CASE WHEN' AS snowflake_equivalent,
               'Snowflake supports NVL2 natively - no change required' AS recommendation
        FROM dba_source
        WHERE REGEXP_LIKE(UPPER(text), 'NVL2\s*\(')
          AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
        UNION ALL
        -- TO_DATE usage
        SELECT 'TO_DATE()' AS function_name,
               COUNT(*) AS occurrence_count,
               'WARNING' AS severity,
               'TO_DATE() or TO_TIMESTAMP()' AS snowflake_equivalent,
               'Snowflake TO_DATE returns DATE (no time); use TO_TIMESTAMP if time component needed' AS recommendation
        FROM dba_source
        WHERE REGEXP_LIKE(UPPER(text), 'TO_DATE\s*\(')
          AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
        UNION ALL
        -- TO_CHAR with date format
        SELECT 'TO_CHAR()' AS function_name,
               COUNT(*) AS occurrence_count,
               'INFO' AS severity,
               'TO_CHAR() or TO_VARCHAR()' AS snowflake_equivalent,
               'Snowflake supports TO_CHAR but format strings may differ (e.g., MM vs mm)' AS recommendation
        FROM dba_source
        WHERE REGEXP_LIKE(UPPER(text), 'TO_CHAR\s*\(')
          AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
        UNION ALL
        -- Date arithmetic (date + number pattern)
        SELECT 'Date Arithmetic (date +/- number)' AS function_name,
               COUNT(*) AS occurrence_count,
               'WARNING' AS severity,
               'DATEADD() function' AS snowflake_equivalent,
               'Oracle date +/- N (days) must use DATEADD(''DAY'', N, date) in Snowflake' AS recommendation
        FROM dba_source
        WHERE REGEXP_LIKE(text, '(SYSDATE|DATE)\s*[\+\-]\s*[0-9]')
          AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
        UNION ALL
        -- MONTHS_BETWEEN
        SELECT 'MONTHS_BETWEEN()' AS function_name,
               COUNT(*) AS occurrence_count,
               'INFO' AS severity,
               'MONTHS_BETWEEN() (supported)' AS snowflake_equivalent,
               'Snowflake supports MONTHS_BETWEEN natively' AS recommendation
        FROM dba_source
        WHERE UPPER(text) LIKE '%MONTHS_BETWEEN%'
          AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
        UNION ALL
        -- ADD_MONTHS
        SELECT 'ADD_MONTHS()' AS function_name,
               COUNT(*) AS occurrence_count,
               'WARNING' AS severity,
               'DATEADD(''MONTH'', n, date)' AS snowflake_equivalent,
               'Replace ADD_MONTHS(date, n) with DATEADD(''MONTH'', n, date)' AS recommendation
        FROM dba_source
        WHERE UPPER(text) LIKE '%ADD_MONTHS%'
          AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
        UNION ALL
        -- TRUNC(date)
        SELECT 'TRUNC(date)' AS function_name,
               COUNT(*) AS occurrence_count,
               'WARNING' AS severity,
               'DATE_TRUNC(''DAY'', date)' AS snowflake_equivalent,
               'Replace TRUNC(date) with DATE_TRUNC; note different argument order' AS recommendation
        FROM dba_source
        WHERE REGEXP_LIKE(UPPER(text), 'TRUNC\s*\(')
          AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
        UNION ALL
        -- Sequence CURRVAL usage
        SELECT 'Sequence CURRVAL' AS function_name,
               COUNT(*) AS occurrence_count,
               'CRITICAL' AS severity,
               'Not supported' AS snowflake_equivalent,
               'CURRVAL not available in Snowflake - redesign to use NEXTVAL or store generated value' AS recommendation
        FROM dba_source
        WHERE UPPER(text) LIKE '%.CURRVAL%'
          AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
        UNION ALL
        -- DBMS_* package calls
        SELECT 'DBMS_* Package Calls' AS function_name,
               COUNT(*) AS occurrence_count,
               'WARNING' AS severity,
               'Various - see DBMS package mapping' AS snowflake_equivalent,
               'DBMS_OUTPUT, DBMS_LOB, DBMS_SQL, DBMS_SCHEDULER etc. require Snowflake alternatives' AS recommendation
        FROM dba_source
        WHERE REGEXP_LIKE(UPPER(text), 'DBMS_[A-Z]+\.')
          AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
        UNION ALL
        -- UTL_* package calls
        SELECT 'UTL_* Package Calls' AS function_name,
               COUNT(*) AS occurrence_count,
               'WARNING' AS severity,
               'External functions or cloud services' AS snowflake_equivalent,
               'UTL_FILE, UTL_HTTP, UTL_SMTP etc. require external stages or external functions' AS recommendation
        FROM dba_source
        WHERE REGEXP_LIKE(UPPER(text), 'UTL_[A-Z]+\.')
          AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
        UNION ALL
        -- BULK COLLECT
        SELECT 'BULK COLLECT' AS function_name,
               COUNT(*) AS occurrence_count,
               'WARNING' AS severity,
               'Snowflake Scripting RESULTSET or cursor' AS snowflake_equivalent,
               'Rewrite BULK COLLECT logic using Snowflake Scripting cursors or set-based SQL' AS recommendation
        FROM dba_source
        WHERE UPPER(text) LIKE '%BULK COLLECT%'
          AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
        UNION ALL
        -- FORALL
        SELECT 'FORALL (bulk DML)' AS function_name,
               COUNT(*) AS occurrence_count,
               'WARNING' AS severity,
               'Set-based SQL or Snowflake Scripting loop' AS snowflake_equivalent,
               'Rewrite FORALL as set-based INSERT/UPDATE/DELETE or Snowflake Scripting loop' AS recommendation
        FROM dba_source
        WHERE REGEXP_LIKE(UPPER(text), '(^|\s)FORALL\s')
          AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
        UNION ALL
        -- %TYPE / %ROWTYPE
        SELECT '%TYPE / %ROWTYPE' AS function_name,
               COUNT(*) AS occurrence_count,
               'WARNING' AS severity,
               'Explicit type declarations' AS snowflake_equivalent,
               'Snowflake Scripting does not support %TYPE/%ROWTYPE - declare types explicitly' AS recommendation
        FROM dba_source
        WHERE REGEXP_LIKE(UPPER(text), '%\s*(TYPE|ROWTYPE)')
          AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
        UNION ALL
        -- AUTONOMOUS_TRANSACTION
        SELECT 'PRAGMA AUTONOMOUS_TRANSACTION' AS function_name,
               COUNT(*) AS occurrence_count,
               'CRITICAL' AS severity,
               'Not supported' AS snowflake_equivalent,
               'No autonomous transactions in Snowflake - redesign as separate procedure calls or Tasks' AS recommendation
        FROM dba_source
        WHERE UPPER(text) LIKE '%AUTONOMOUS_TRANSACTION%'
          AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
    )
    SELECT function_name, occurrence_count, severity, snowflake_equivalent, recommendation
    FROM function_checks
    WHERE occurrence_count > 0
    ORDER BY
        CASE severity WHEN 'CRITICAL' THEN 1 WHEN 'WARNING' THEN 2 ELSE 3 END,
        occurrence_count DESC
    """


def get_snowflake_workload_sizing():
    """Analyze Oracle workload patterns to recommend Snowflake virtual warehouse sizing."""
    return """
    WITH db_size AS (
        SELECT
            ROUND(SUM(bytes) / 1024 / 1024 / 1024, 2) AS total_db_size_gb
        FROM dba_segments
        WHERE owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
    ),
    cpu_info AS (
        SELECT VALUE AS cpu_count
        FROM v$parameter
        WHERE name = 'cpu_count'
    ),
    sga_info AS (
        SELECT ROUND(SUM(value) / 1024 / 1024 / 1024, 2) AS sga_size_gb
        FROM v$sga
    ),
    session_info AS (
        SELECT
            COUNT(*) AS current_sessions,
            SUM(CASE WHEN status = 'ACTIVE' THEN 1 ELSE 0 END) AS active_sessions
        FROM v$session
        WHERE type = 'USER'
    ),
    sql_profile AS (
        SELECT
            COUNT(*) AS total_sql_statements,
            ROUND(AVG(elapsed_time / GREATEST(executions, 1)) / 1000000, 2) AS avg_elapsed_sec,
            ROUND(MAX(elapsed_time / GREATEST(executions, 1)) / 1000000, 2) AS max_elapsed_sec,
            ROUND(SUM(elapsed_time) / 1000000 / 3600, 2) AS total_db_hours,
            SUM(CASE WHEN elapsed_time / GREATEST(executions, 1) > 60000000 THEN 1 ELSE 0 END) AS long_running_queries,
            SUM(CASE WHEN executions > 1000 THEN 1 ELSE 0 END) AS high_frequency_queries
        FROM v$sql
        WHERE parsing_schema_name NOT IN ('SYS','SYSTEM','DBSNMP','AUDSYS')
          AND executions > 0
    ),
    io_profile AS (
        SELECT
            ROUND(SUM(disk_reads) * 8 / 1024 / 1024, 2) AS total_physical_reads_gb,
            ROUND(SUM(direct_writes) * 8 / 1024 / 1024, 2) AS total_physical_writes_gb,
            ROUND(AVG(disk_reads / GREATEST(executions, 1)), 2) AS avg_reads_per_exec
        FROM v$sql
        WHERE parsing_schema_name NOT IN ('SYS','SYSTEM','DBSNMP','AUDSYS')
          AND executions > 0
    ),
    dml_profile AS (
        SELECT
            SUM(CASE WHEN command_type = 2 THEN executions ELSE 0 END) AS insert_count,
            SUM(CASE WHEN command_type = 6 THEN executions ELSE 0 END) AS update_count,
            SUM(CASE WHEN command_type = 7 THEN executions ELSE 0 END) AS delete_count,
            SUM(CASE WHEN command_type = 3 THEN executions ELSE 0 END) AS select_count
        FROM v$sql
        WHERE parsing_schema_name NOT IN ('SYS','SYSTEM','DBSNMP','AUDSYS')
          AND executions > 0
    )
    SELECT
        'Database Size' AS metric,
        TO_CHAR(ds.total_db_size_gb) || ' GB' AS current_value,
        CASE
            WHEN ds.total_db_size_gb < 100 THEN 'Small - Snowflake Standard Edition sufficient'
            WHEN ds.total_db_size_gb < 1000 THEN 'Medium - Consider Enterprise Edition for Time Travel'
            WHEN ds.total_db_size_gb < 10000 THEN 'Large - Enterprise Edition recommended, plan staged migration'
            ELSE 'Very Large - Business Critical, plan phased migration with Snowpipe'
        END AS snowflake_recommendation
    FROM db_size ds
    UNION ALL
    SELECT
        'Oracle CPU Count' AS metric,
        ci.cpu_count || ' CPUs' AS current_value,
        CASE
            WHEN TO_NUMBER(ci.cpu_count) <= 4 THEN 'Start with X-Small warehouse (1 server = 8 vCPU equivalent)'
            WHEN TO_NUMBER(ci.cpu_count) <= 8 THEN 'Start with Small warehouse (2 servers)'
            WHEN TO_NUMBER(ci.cpu_count) <= 16 THEN 'Start with Medium warehouse (4 servers)'
            WHEN TO_NUMBER(ci.cpu_count) <= 32 THEN 'Start with Large warehouse (8 servers)'
            WHEN TO_NUMBER(ci.cpu_count) <= 64 THEN 'Start with X-Large warehouse (16 servers)'
            ELSE 'Start with 2X-Large or larger; consider multi-cluster warehouse'
        END AS snowflake_recommendation
    FROM cpu_info ci
    UNION ALL
    SELECT
        'SGA Size' AS metric,
        TO_CHAR(si.sga_size_gb) || ' GB' AS current_value,
        'Snowflake manages caching automatically - SGA has no direct equivalent' AS snowflake_recommendation
    FROM sga_info si
    UNION ALL
    SELECT
        'Active Sessions' AS metric,
        se.active_sessions || ' active / ' || se.current_sessions || ' total' AS current_value,
        CASE
            WHEN se.active_sessions <= 5 THEN 'Single warehouse likely sufficient'
            WHEN se.active_sessions <= 20 THEN 'Consider multi-cluster warehouse (min 1, max 3)'
            WHEN se.active_sessions <= 50 THEN 'Multi-cluster warehouse recommended (min 1, max 5)'
            ELSE 'Multi-cluster warehouse with auto-scaling (min 1, max 10+)'
        END AS snowflake_recommendation
    FROM session_info se
    UNION ALL
    SELECT
        'Query Profile' AS metric,
        sp.total_sql_statements || ' stmts, avg ' || sp.avg_elapsed_sec || 's, '
            || sp.long_running_queries || ' long-running (>60s)' AS current_value,
        CASE
            WHEN sp.long_running_queries > 50 THEN 'Separate warehouses for long-running analytics vs short queries'
            WHEN sp.avg_elapsed_sec > 10 THEN 'Medium+ warehouse for complex queries; review query optimization'
            ELSE 'Standard warehouse sizing should suffice'
        END AS snowflake_recommendation
    FROM sql_profile sp
    UNION ALL
    SELECT
        'I/O Profile' AS metric,
        'Reads: ' || ip.total_physical_reads_gb || ' GB, Writes: ' || ip.total_physical_writes_gb
            || ' GB, Avg reads/exec: ' || ip.avg_reads_per_exec AS current_value,
        CASE
            WHEN ip.avg_reads_per_exec > 10000 THEN 'Heavy I/O - larger warehouse and CLUSTER BY on frequently filtered columns'
            WHEN ip.avg_reads_per_exec > 1000 THEN 'Moderate I/O - review partition pruning, use CLUSTER BY on key columns'
            ELSE 'Light I/O - standard warehouse sizing'
        END AS snowflake_recommendation
    FROM io_profile ip
    UNION ALL
    SELECT
        'Workload Type' AS metric,
        'SELECTs: ' || dp.select_count || ', INSERTs: ' || dp.insert_count
            || ', UPDATEs: ' || dp.update_count || ', DELETEs: ' || dp.delete_count AS current_value,
        CASE
            WHEN (dp.update_count + dp.delete_count) > dp.select_count
                THEN 'CRITICAL - Write-heavy OLTP workload, Snowflake is optimized for analytics/reads'
            WHEN (dp.update_count + dp.delete_count) > dp.select_count * 0.3
                THEN 'WARNING - Significant DML activity, consider separating OLTP from analytics'
            WHEN dp.select_count > (dp.insert_count + dp.update_count + dp.delete_count) * 10
                THEN 'IDEAL - Read-heavy/analytical workload, well suited for Snowflake'
            ELSE 'Mixed workload - may need separate warehouses for different workload types'
        END AS snowflake_recommendation
    FROM dml_profile dp
    UNION ALL
    SELECT
        'High-Frequency Queries' AS metric,
        sp.high_frequency_queries || ' queries with > 1000 executions' AS current_value,
        CASE
            WHEN sp.high_frequency_queries > 100
                THEN 'High concurrency - multi-cluster warehouse with auto-scaling recommended'
            WHEN sp.high_frequency_queries > 20
                THEN 'Moderate concurrency - consider multi-cluster warehouse'
            ELSE 'Low concurrency - single warehouse likely sufficient'
        END AS snowflake_recommendation
    FROM sql_profile sp
    """


def get_snowflake_data_volume_assessment():
    """Assess data volume for Snowflake migration planning (extraction, staging, loading)."""
    return """
    WITH schema_sizes AS (
        SELECT
            owner,
            COUNT(DISTINCT segment_name) AS table_count,
            ROUND(SUM(bytes) / 1024 / 1024 / 1024, 2) AS size_gb
        FROM dba_segments
        WHERE segment_type IN ('TABLE', 'TABLE PARTITION', 'TABLE SUBPARTITION')
          AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
        GROUP BY owner
    ),
    index_sizes AS (
        SELECT
            owner,
            ROUND(SUM(bytes) / 1024 / 1024 / 1024, 2) AS index_size_gb
        FROM dba_segments
        WHERE segment_type IN ('INDEX', 'INDEX PARTITION', 'INDEX SUBPARTITION')
          AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
        GROUP BY owner
    ),
    lob_sizes AS (
        SELECT
            owner,
            ROUND(SUM(bytes) / 1024 / 1024 / 1024, 2) AS lob_size_gb
        FROM dba_segments
        WHERE segment_type IN ('LOBSEGMENT', 'LOB PARTITION')
          AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
        GROUP BY owner
    ),
    total_summary AS (
        SELECT
            ROUND(SUM(CASE WHEN segment_type IN ('TABLE','TABLE PARTITION','TABLE SUBPARTITION')
                           THEN bytes ELSE 0 END) / 1024 / 1024 / 1024, 2) AS total_table_gb,
            ROUND(SUM(CASE WHEN segment_type IN ('INDEX','INDEX PARTITION','INDEX SUBPARTITION')
                           THEN bytes ELSE 0 END) / 1024 / 1024 / 1024, 2) AS total_index_gb,
            ROUND(SUM(CASE WHEN segment_type IN ('LOBSEGMENT','LOB PARTITION')
                           THEN bytes ELSE 0 END) / 1024 / 1024 / 1024, 2) AS total_lob_gb,
            ROUND(SUM(bytes) / 1024 / 1024 / 1024, 2) AS total_all_gb
        FROM dba_segments
        WHERE owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
    ),
    large_tables AS (
        SELECT COUNT(*) AS large_table_count
        FROM (
            SELECT owner, segment_name
            FROM dba_segments
            WHERE segment_type IN ('TABLE', 'TABLE PARTITION', 'TABLE SUBPARTITION')
              AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
            GROUP BY owner, segment_name
            HAVING SUM(bytes) / 1024 / 1024 / 1024 > 10
        )
    ),
    row_counts AS (
        SELECT
            SUM(num_rows) AS total_rows,
            MAX(num_rows) AS max_table_rows,
            COUNT(CASE WHEN num_rows > 100000000 THEN 1 END) AS tables_over_100m_rows
        FROM dba_tables
        WHERE owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
    )
    SELECT
        'Total Data Volume (tables only)' AS metric,
        TO_CHAR(ts.total_table_gb) || ' GB' AS value,
        CASE
            WHEN ts.total_table_gb < 10 THEN 'Small - Extract via Oracle Data Pump, load in single batch'
            WHEN ts.total_table_gb < 100 THEN 'Medium - Data Pump export, stage in cloud storage, COPY INTO'
            WHEN ts.total_table_gb < 1000 THEN 'Large - Parallel Data Pump export, multi-file staging, parallel COPY INTO'
            ELSE 'Very Large - Consider incremental migration strategy with Snowpipe'
        END AS migration_recommendation,
        CASE
            WHEN ts.total_table_gb < 100 THEN 'Estimated Snowflake storage: ~' || TO_CHAR(ROUND(ts.total_table_gb * 0.25, 1)) || ' GB (compressed)'
            ELSE 'Estimated Snowflake storage: ~' || TO_CHAR(ROUND(ts.total_table_gb * 0.25, 1)) || ' GB (3-4x compression typical)'
        END AS storage_estimate
    FROM total_summary ts
    UNION ALL
    SELECT
        'Index Storage (not migrated)' AS metric,
        TO_CHAR(ts.total_index_gb) || ' GB' AS value,
        'Indexes are NOT migrated - this storage is recovered in Snowflake' AS migration_recommendation,
        'Savings: ' || TO_CHAR(ts.total_index_gb) || ' GB of index storage eliminated' AS storage_estimate
    FROM total_summary ts
    UNION ALL
    SELECT
        'LOB Storage' AS metric,
        TO_CHAR(ts.total_lob_gb) || ' GB' AS value,
        CASE
            WHEN ts.total_lob_gb > 100 THEN 'Large LOB volume - evaluate external stage storage for oversized objects'
            WHEN ts.total_lob_gb > 0 THEN 'Export LOBs as part of table data; check individual values < 16MB (CLOB) / 8MB (BLOB)'
            ELSE 'No LOB storage'
        END AS migration_recommendation,
        CASE
            WHEN ts.total_lob_gb > 0 THEN 'LOB data included in table storage estimate'
            ELSE 'N/A'
        END AS storage_estimate
    FROM total_summary ts
    UNION ALL
    SELECT
        'Total Row Count' AS metric,
        TO_CHAR(rc.total_rows, '999,999,999,999') || ' rows (' || rc.tables_over_100m_rows || ' tables > 100M rows)' AS value,
        CASE
            WHEN rc.tables_over_100m_rows > 10 THEN 'Many large tables - use CLUSTER BY on frequently filtered columns'
            WHEN rc.tables_over_100m_rows > 0 THEN 'Large tables present - consider CLUSTER BY for query performance'
            ELSE 'Standard table sizes - no special clustering needed'
        END AS migration_recommendation,
        'Max table: ' || TO_CHAR(rc.max_table_rows, '999,999,999,999') || ' rows' AS storage_estimate
    FROM row_counts rc
    UNION ALL
    SELECT
        'Large Tables (>10GB)' AS metric,
        TO_CHAR(lt.large_table_count) || ' tables' AS value,
        CASE
            WHEN lt.large_table_count > 20 THEN 'Prioritize largest tables for parallel extraction and CLUSTER BY'
            WHEN lt.large_table_count > 0 THEN 'Use parallel COPY INTO for large tables; consider CLUSTER BY'
            ELSE 'No very large tables - straightforward bulk load'
        END AS migration_recommendation,
        'Tables > 10GB benefit most from Snowflake clustering keys' AS storage_estimate
    FROM large_tables lt
    UNION ALL
    SELECT
        'Recommended File Format' AS metric,
        'Parquet (preferred) or compressed CSV' AS value,
        'Export to Parquet for best performance: columnar format, schema preservation, compression' AS migration_recommendation,
        'Parquet typically 3-5x smaller than uncompressed CSV' AS storage_estimate
    FROM dual
    UNION ALL
    SELECT
        'Staging Recommendation' AS metric,
        CASE
            WHEN ts.total_table_gb < 100 THEN 'Single cloud storage bucket'
            ELSE 'Partitioned cloud storage with parallel upload'
        END AS value,
        'Stage data in S3, Azure Blob, or GCS. Use Snowflake external stage for COPY INTO.' AS migration_recommendation,
        'Estimated staging storage needed: ~' || TO_CHAR(ROUND(ts.total_table_gb * 0.3, 1)) || ' GB (Parquet compressed)' AS storage_estimate
    FROM total_summary ts
    """


def get_snowflake_upstream_sources():
    """Map upstream data sources feeding into Oracle that must be redirected for Snowflake migration.

    Consolidates scheduler jobs, database links, external tables, directory objects,
    and PL/SQL code referencing external integrations (UTL_HTTP, UTL_FILE, DBMS_AQ, etc.).
    Each source is labeled with its Snowflake replacement strategy.
    """
    return """
    WITH upstream_sources AS (
        -- Scheduler jobs (ETL/ELT loading data into Oracle)
        SELECT
            'Scheduler Job' AS source_type,
            j.owner,
            j.job_name AS object_name,
            j.job_type || ': ' || SUBSTR(NVL(TO_CHAR(j.job_action), 'N/A'), 1, 200) AS details,
            j.state AS status,
            CASE j.job_type
                WHEN 'PLSQL_BLOCK' THEN 'WARNING - PL/SQL job must be rewritten'
                WHEN 'STORED_PROCEDURE' THEN 'WARNING - Procedure must be converted'
                WHEN 'EXECUTABLE' THEN 'CRITICAL - External OS executable, requires redesign'
                WHEN 'CHAIN' THEN 'WARNING - Job chain must be decomposed and rebuilt'
                ELSE 'WARNING - Review job type: ' || j.job_type
            END AS migration_impact,
            CASE j.job_type
                WHEN 'PLSQL_BLOCK' THEN 'Convert to Snowflake Task with Snowflake Scripting, or orchestrate via Airflow/dbt'
                WHEN 'STORED_PROCEDURE' THEN 'Convert procedure to Snowflake Scripting, schedule via Snowflake Task'
                WHEN 'EXECUTABLE' THEN 'Replace with cloud-native orchestration (Airflow, AWS Step Functions, Azure Data Factory)'
                WHEN 'CHAIN' THEN 'Rebuild as Snowflake Task tree (task dependencies) or Airflow DAG'
                ELSE 'Evaluate and convert to Snowflake Task or external orchestrator'
            END AS snowflake_replacement
        FROM dba_scheduler_jobs j
        WHERE j.owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
          AND j.state != 'DISABLED'
        UNION ALL
        -- Database links (pulling data from remote Oracle databases)
        SELECT
            'Database Link' AS source_type,
            dl.owner,
            dl.db_link AS object_name,
            'Host: ' || dl.host || CASE WHEN dl.username IS NOT NULL THEN ', User: ' || dl.username ELSE '' END AS details,
            'ACTIVE' AS status,
            'CRITICAL - Database links not supported in Snowflake' AS migration_impact,
            'Options: 1) Replicate remote data via ETL into Snowflake, 2) Use Snowflake Data Sharing if source migrates too, 3) Use external tables on cloud storage' AS snowflake_replacement
        FROM dba_db_links dl
        WHERE dl.owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
        UNION ALL
        -- External tables (file-based data feeds)
        SELECT
            'External Table' AS source_type,
            et.owner,
            et.table_name AS object_name,
            'Type: ' || et.type_name || ', Dir: ' || et.default_directory_name
                || ', Access: ' || SUBSTR(NVL(TO_CHAR(et.access_parameters), 'N/A'), 1, 150) AS details,
            'ACTIVE' AS status,
            'WARNING - External tables require Snowflake external stage redesign' AS migration_impact,
            'Create Snowflake external stage (S3/Azure Blob/GCS) + external table or COPY INTO with file format' AS snowflake_replacement
        FROM dba_external_tables et
        WHERE et.owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
        UNION ALL
        -- Directory objects (file system paths for UTL_FILE and external tables)
        SELECT
            'Directory Object' AS source_type,
            d.owner,
            d.directory_name AS object_name,
            'Path: ' || d.directory_path AS details,
            'ACTIVE' AS status,
            'INFO - File system directories have no Snowflake equivalent' AS migration_impact,
            'Replace with Snowflake named external stage pointing to cloud storage (S3/Azure Blob/GCS)' AS snowflake_replacement
        FROM dba_directories d
        WHERE d.directory_name NOT IN ('ORACLE_HOME','ORACLE_BASE','DATA_PUMP_DIR',
                                        'OPATCH_LOG_DIR','OPATCH_INST_DIR','OPATCH_SCRIPT_DIR',
                                        'DBMS_OPTIM_ADMINDIR','DBMS_OPTIM_LOGDIR',
                                        'SDO_DIR_ADMIN','XMLDIR')
        UNION ALL
        -- PL/SQL code with UTL_HTTP calls (inbound HTTP data feeds)
        SELECT
            'HTTP Integration (UTL_HTTP)' AS source_type,
            s.owner,
            s.name || ' (' || s.type || ')' AS object_name,
            'Line ' || s.line || ': ' || SUBSTR(TRIM(s.text), 1, 200) AS details,
            'ACTIVE' AS status,
            'CRITICAL - UTL_HTTP not available in Snowflake' AS migration_impact,
            'Use Snowflake External Network Access + external functions, or move HTTP calls to orchestration layer (Airflow, Lambda)' AS snowflake_replacement
        FROM dba_source s
        WHERE UPPER(s.text) LIKE '%UTL_HTTP%'
          AND s.owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
        UNION ALL
        -- PL/SQL code with UTL_FILE reads (file-based inbound data)
        SELECT
            'File Integration (UTL_FILE)' AS source_type,
            s.owner,
            s.name || ' (' || s.type || ')' AS object_name,
            'Line ' || s.line || ': ' || SUBSTR(TRIM(s.text), 1, 200) AS details,
            'ACTIVE' AS status,
            'WARNING - UTL_FILE not available in Snowflake' AS migration_impact,
            'Replace with Snowflake external stage + COPY INTO, or Snowpipe for continuous ingestion' AS snowflake_replacement
        FROM dba_source s
        WHERE UPPER(s.text) LIKE '%UTL_FILE%'
          AND s.owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
        UNION ALL
        -- PL/SQL code with Advanced Queuing (message-based data feeds)
        SELECT
            'Message Queue (DBMS_AQ)' AS source_type,
            s.owner,
            s.name || ' (' || s.type || ')' AS object_name,
            'Line ' || s.line || ': ' || SUBSTR(TRIM(s.text), 1, 200) AS details,
            'ACTIVE' AS status,
            'CRITICAL - Oracle AQ not available in Snowflake' AS migration_impact,
            'Replace with Kafka + Snowflake Kafka Connector, or AWS SQS/SNS, or Snowpipe with notification' AS snowflake_replacement
        FROM dba_source s
        WHERE (UPPER(s.text) LIKE '%DBMS_AQ.%' OR UPPER(s.text) LIKE '%DBMS_AQADM.%')
          AND s.owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
        UNION ALL
        -- PL/SQL code referencing remote databases via @dblink syntax
        SELECT
            'Remote Query via DB Link' AS source_type,
            s.owner,
            s.name || ' (' || s.type || ')' AS object_name,
            'Line ' || s.line || ': ' || SUBSTR(TRIM(s.text), 1, 200) AS details,
            'ACTIVE' AS status,
            'CRITICAL - Remote table access via @dblink not supported' AS migration_impact,
            'Replicate remote data into Snowflake via ETL, or use Snowflake Data Sharing' AS snowflake_replacement
        FROM dba_source s
        WHERE REGEXP_LIKE(s.text, '@[A-Za-z_][A-Za-z0-9_]*')
          AND s.type IN ('PROCEDURE','FUNCTION','PACKAGE BODY','TRIGGER')
          AND UPPER(s.text) NOT LIKE '--%'
          AND UPPER(s.text) NOT LIKE '%EMAIL%@%'
          AND s.owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
    )
    SELECT source_type, owner, object_name, details, status, migration_impact, snowflake_replacement
    FROM upstream_sources
    ORDER BY
        CASE
            WHEN migration_impact LIKE 'CRITICAL%' THEN 1
            WHEN migration_impact LIKE 'WARNING%' THEN 2
            ELSE 3
        END,
        source_type, owner, object_name
    """


def get_snowflake_downstream_consumers():
    """Map downstream consumers of Oracle data that must be redirected for Snowflake migration.

    Catalogs active application connections (from v$session), outbound data flows
    (UTL_SMTP, UTL_FILE writes, DBMS_OUTPUT), and scheduled export/notification jobs.
    Each consumer is labeled with its Snowflake reconnection strategy.

    CAVEAT: v$session is a point-in-time snapshot. Applications not connected at
    assessment time will not appear. Supplement with application team interviews
    and network traffic analysis for completeness.
    """
    return """
    WITH downstream_consumers AS (
        -- Active application connections (point-in-time snapshot from v$session)
        SELECT
            'Application Connection' AS consumer_type,
            s.schemaname AS owner,
            NVL(s.program, 'Unknown Program') AS object_name,
            'Machine: ' || NVL(s.machine, 'N/A')
                || ', Module: ' || NVL(s.module, 'N/A')
                || ', Service: ' || NVL(s.service_name, 'N/A')
                || ', Sessions: ' || TO_CHAR(COUNT(*))
                || ' (Active: ' || TO_CHAR(SUM(CASE WHEN s.status = 'ACTIVE' THEN 1 ELSE 0 END)) || ')' AS details,
            CASE
                WHEN s.program LIKE '%jdbc%' OR s.program LIKE '%JDBC%' THEN 'Java/JDBC Application'
                WHEN s.program LIKE '%python%' OR s.program LIKE '%Python%' THEN 'Python Application'
                WHEN s.program LIKE 'Tableau%' OR s.module LIKE 'Tableau%' THEN 'Tableau BI Tool'
                WHEN s.program LIKE '%Power BI%' OR s.module LIKE '%Power BI%' THEN 'Power BI'
                WHEN s.program LIKE '%sqlplus%' OR s.program LIKE '%SQL*Plus%' THEN 'SQL*Plus / Ad-hoc'
                WHEN s.program LIKE '%SQL Developer%' OR s.program LIKE '%sqldeveloper%' THEN 'SQL Developer'
                WHEN s.program LIKE '%Toad%' OR s.program LIKE '%TOAD%' THEN 'Toad IDE'
                WHEN s.program LIKE '%DBeaver%' THEN 'DBeaver IDE'
                WHEN s.program LIKE '%OBI%' OR s.program LIKE '%nqsserver%' THEN 'Oracle BI/OBIEE'
                WHEN s.program LIKE '%w3wp%' OR s.program LIKE '%dotnet%' THEN '.NET Application'
                WHEN s.program LIKE '%httpd%' OR s.program LIKE '%apache%' THEN 'Web Server (Apache)'
                WHEN s.program LIKE '%oracle%' THEN 'Oracle Internal/Job'
                ELSE 'Custom Application'
            END AS app_category,
            'INFO - Application must reconnect to Snowflake' AS migration_impact,
            CASE
                WHEN s.program LIKE '%jdbc%' OR s.program LIKE '%JDBC%'
                    THEN 'Update JDBC driver to Snowflake JDBC (net.snowflake.client.jdbc), change connection string'
                WHEN s.program LIKE '%python%' OR s.program LIKE '%Python%'
                    THEN 'Install snowflake-connector-python, update connection parameters'
                WHEN s.program LIKE 'Tableau%' OR s.module LIKE 'Tableau%'
                    THEN 'Install Snowflake Tableau connector, rebuild data sources, test dashboards'
                WHEN s.program LIKE '%Power BI%' OR s.module LIKE '%Power BI%'
                    THEN 'Use Snowflake Power BI connector, redirect data gateway, test reports'
                WHEN s.program LIKE '%OBI%' OR s.program LIKE '%nqsserver%'
                    THEN 'Reconfigure OBIEE connection pool to Snowflake JDBC/ODBC, review Oracle-specific SQL in RPD'
                WHEN s.program LIKE '%sqlplus%' OR s.program LIKE '%SQL Developer%'
                    THEN 'Use Snowflake Worksheets (Snowsight) or SnowSQL CLI for ad-hoc queries'
                WHEN s.program LIKE '%w3wp%' OR s.program LIKE '%dotnet%'
                    THEN 'Install Snowflake .NET driver (Snowflake.Data), update connection strings'
                ELSE 'Update application to use Snowflake JDBC/ODBC/native connector and revise any Oracle-specific SQL'
            END AS snowflake_replacement
        FROM v$session s
        WHERE s.type = 'USER'
          AND s.schemaname NOT IN ('SYS','SYSTEM','DBSNMP','AUDSYS','OUTLN','MDSYS','XDB',
                                    'CTXSYS','WMSYS','ORDSYS','ORDDATA','GSMADMIN_INTERNAL',
                                    'APPQOSSYS','DVSYS','DBSFWUSER')
          AND s.program IS NOT NULL
        GROUP BY s.schemaname, s.program, s.machine, s.module, s.service_name
        UNION ALL
        -- PL/SQL code with outbound email (UTL_SMTP/UTL_MAIL)
        SELECT
            'Outbound Email' AS consumer_type,
            s.owner,
            s.name || ' (' || s.type || ')' AS object_name,
            'Line ' || s.line || ': ' || SUBSTR(TRIM(s.text), 1, 200) AS details,
            'Email Notification' AS app_category,
            'WARNING - UTL_SMTP/UTL_MAIL not available in Snowflake' AS migration_impact,
            'Use Snowflake notification integrations (email), or external functions calling SendGrid/SES/cloud email service' AS snowflake_replacement
        FROM dba_source s
        WHERE (UPPER(s.text) LIKE '%UTL_SMTP%' OR UPPER(s.text) LIKE '%UTL_MAIL%')
          AND s.owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
        UNION ALL
        -- PL/SQL code with outbound file writes (UTL_FILE for exports/reports)
        SELECT
            'File Export (UTL_FILE write)' AS consumer_type,
            s.owner,
            s.name || ' (' || s.type || ')' AS object_name,
            'Line ' || s.line || ': ' || SUBSTR(TRIM(s.text), 1, 200) AS details,
            'File Export' AS app_category,
            'WARNING - UTL_FILE not available in Snowflake' AS migration_impact,
            'Use Snowflake COPY INTO with external stage to export data to S3/Azure Blob/GCS' AS snowflake_replacement
        FROM dba_source s
        WHERE UPPER(s.text) LIKE '%UTL_FILE.PUT%'
          AND s.owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
        UNION ALL
        -- PL/SQL code with outbound HTTP calls (pushing data out)
        SELECT
            'Outbound HTTP' AS consumer_type,
            s.owner,
            s.name || ' (' || s.type || ')' AS object_name,
            'Line ' || s.line || ': ' || SUBSTR(TRIM(s.text), 1, 200) AS details,
            'API/Webhook' AS app_category,
            'CRITICAL - UTL_HTTP not available in Snowflake' AS migration_impact,
            'Use Snowflake External Network Access + external functions, or move to orchestration layer' AS snowflake_replacement
        FROM dba_source s
        WHERE UPPER(s.text) LIKE '%UTL_HTTP%'
          AND (UPPER(s.text) LIKE '%POST%' OR UPPER(s.text) LIKE '%PUT%' OR UPPER(s.text) LIKE '%REQUEST%')
          AND s.owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
        UNION ALL
        -- PL/SQL code with DBMS_PIPE (inter-process communication)
        SELECT
            'Inter-process Comm (DBMS_PIPE)' AS consumer_type,
            s.owner,
            s.name || ' (' || s.type || ')' AS object_name,
            'Line ' || s.line || ': ' || SUBSTR(TRIM(s.text), 1, 200) AS details,
            'IPC' AS app_category,
            'CRITICAL - DBMS_PIPE not available in Snowflake' AS migration_impact,
            'Redesign using Snowflake Streams + Tasks, or external message queue (Kafka, SQS, Pub/Sub)' AS snowflake_replacement
        FROM dba_source s
        WHERE UPPER(s.text) LIKE '%DBMS_PIPE%'
          AND s.owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
        UNION ALL
        -- PL/SQL code with DBMS_ALERT (notification to waiting sessions)
        SELECT
            'Alert Notification (DBMS_ALERT)' AS consumer_type,
            s.owner,
            s.name || ' (' || s.type || ')' AS object_name,
            'Line ' || s.line || ': ' || SUBSTR(TRIM(s.text), 1, 200) AS details,
            'Notification' AS app_category,
            'WARNING - DBMS_ALERT not available in Snowflake' AS migration_impact,
            'Use Snowflake Alerts for condition-based notifications, or Snowflake Streams for change detection' AS snowflake_replacement
        FROM dba_source s
        WHERE UPPER(s.text) LIKE '%DBMS_ALERT%'
          AND s.owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
        UNION ALL
        -- Scheduled export/notification jobs (downstream data pushes)
        SELECT
            'Scheduled Export Job' AS consumer_type,
            j.owner,
            j.job_name AS object_name,
            j.job_type || ': ' || SUBSTR(NVL(TO_CHAR(j.job_action), 'N/A'), 1, 200) AS details,
            'Scheduled Export' AS app_category,
            'WARNING - Scheduler job pushing data downstream must be redesigned' AS migration_impact,
            'Convert to Snowflake Task with COPY INTO for exports, or Snowflake notification integration for alerts' AS snowflake_replacement
        FROM dba_scheduler_jobs j
        WHERE j.owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
          AND j.state != 'DISABLED'
          AND (UPPER(TO_CHAR(j.job_action)) LIKE '%UTL_FILE%'
               OR UPPER(TO_CHAR(j.job_action)) LIKE '%UTL_SMTP%'
               OR UPPER(TO_CHAR(j.job_action)) LIKE '%UTL_MAIL%'
               OR UPPER(TO_CHAR(j.job_action)) LIKE '%UTL_HTTP%'
               OR UPPER(TO_CHAR(j.job_action)) LIKE '%DBMS_PIPE%')
    )
    SELECT consumer_type, owner, object_name, details,
           app_category, migration_impact, snowflake_replacement
    FROM downstream_consumers
    ORDER BY
        CASE
            WHEN migration_impact LIKE 'CRITICAL%' THEN 1
            WHEN migration_impact LIKE 'WARNING%' THEN 2
            ELSE 3
        END,
        consumer_type, owner, object_name
    """


# =============================================================================
# Oracle Database@Azure Validation
# =============================================================================

def get_oracle_at_azure_compatibility_summary():
    """Generate Oracle Database@Azure compatibility summary - Exadata in Azure datacenter."""
    return """
    WITH db_checks AS (
        SELECT
            (SELECT value FROM v$parameter WHERE name = 'db_block_size') AS block_size,
            (SELECT value FROM v$parameter WHERE name = 'compatible') AS compatible_ver,
            (SELECT ROUND(SUM(bytes)/1024/1024/1024/1024, 2) FROM dba_segments) AS size_tb,
            (SELECT value FROM v$parameter WHERE name = 'cluster_database') AS is_rac,
            (SELECT COUNT(*) FROM v$encryption_wallet WHERE status = 'OPEN') AS tde_enabled,
            (SELECT COUNT(*) FROM dba_users WHERE authentication_type IN ('EXTERNAL', 'GLOBAL')) AS os_auth_users
        FROM dual
    )
    SELECT
        'Oracle Database@Azure' AS target,
        CASE
            WHEN block_size NOT IN ('8192', '16384', '32768') THEN 'FAIL'
            WHEN TO_NUMBER(REGEXP_SUBSTR(compatible_ver, '[0-9]+')) < 19 THEN 'WARNING'
            WHEN os_auth_users > 0 THEN 'WARNING'
            ELSE 'PASS'
        END AS status,
        CASE
            WHEN block_size NOT IN ('8192', '16384', '32768') THEN 'Block size must be 8K, 16K, or 32K'
            WHEN TO_NUMBER(REGEXP_SUBSTR(compatible_ver, '[0-9]+')) < 19 THEN 'Oracle 19c+ recommended for Oracle@Azure'
            WHEN os_auth_users > 0 THEN os_auth_users || ' OS-authenticated users - use Azure AD integration'
            ELSE 'Compatible with Oracle Database@Azure'
        END AS details,
        CASE
            WHEN block_size NOT IN ('8192', '16384', '32768') THEN 'Recreate database with supported block size'
            WHEN TO_NUMBER(REGEXP_SUBSTR(compatible_ver, '[0-9]+')) < 19 THEN 'Upgrade to Oracle 19c or later'
            ELSE 'Ready for migration'
        END AS recommendation
    FROM db_checks
    """


def get_oracle_at_azure_validation():
    """Detailed validation for Oracle Database@Azure (Exadata in Azure)."""
    return """
    WITH checks AS (
        SELECT 'Block Size' AS check_name,
               (SELECT value FROM v$parameter WHERE name = 'db_block_size') AS current_value,
               '8192/16384/32768' AS required_value,
               CASE WHEN (SELECT value FROM v$parameter WHERE name = 'db_block_size') IN ('8192','16384','32768')
                    THEN 'PASS' ELSE 'FAIL' END AS status,
               'Standard block sizes supported on Exadata' AS notes
        FROM dual
        UNION ALL
        SELECT 'Oracle Version',
               (SELECT version_full FROM v$instance),
               '19c+ recommended',
               CASE WHEN TO_NUMBER(REGEXP_SUBSTR((SELECT version FROM v$instance), '[0-9]+')) >= 19
                    THEN 'PASS' ELSE 'WARNING' END,
               'Oracle 19c or later recommended for Oracle@Azure'
        FROM dual
        UNION ALL
        SELECT 'Database Size (TB)',
               TO_CHAR(ROUND((SELECT SUM(bytes)/1024/1024/1024/1024 FROM dba_segments), 2)),
               'No practical limit',
               'PASS',
               'Oracle@Azure supports large databases on Exadata'
        FROM dual
        UNION ALL
        SELECT 'RAC Configuration',
               NVL((SELECT value FROM v$parameter WHERE name = 'cluster_database'), 'FALSE'),
               'TRUE/FALSE',
               'PASS',
               'RAC fully supported on Oracle@Azure Exadata'
        FROM dual
        UNION ALL
        SELECT 'Data Guard',
               CASE WHEN (SELECT COUNT(*) FROM v$archive_dest WHERE status = 'VALID' AND target = 'STANDBY') > 0
                    THEN 'Configured' ELSE 'Not configured' END,
               'Supported',
               'PASS',
               'Data Guard supported - can use Azure regions for DR'
        FROM dual
        UNION ALL
        SELECT 'TDE Encryption',
               CASE WHEN (SELECT COUNT(*) FROM v$encryption_wallet WHERE status = 'OPEN') > 0
                    THEN 'Enabled' ELSE 'Not enabled' END,
               'Recommended',
               CASE WHEN (SELECT COUNT(*) FROM v$encryption_wallet WHERE status = 'OPEN') > 0
                    THEN 'PASS' ELSE 'WARNING' END,
               'TDE recommended - integrates with Azure Key Vault'
        FROM dual
        UNION ALL
        SELECT 'OS Authentication',
               TO_CHAR((SELECT COUNT(*) FROM dba_users WHERE authentication_type IN ('EXTERNAL', 'GLOBAL'))),
               '0 recommended',
               CASE WHEN (SELECT COUNT(*) FROM dba_users WHERE authentication_type IN ('EXTERNAL', 'GLOBAL')) = 0
                    THEN 'PASS' ELSE 'WARNING' END,
               'Consider Azure AD integration for cloud authentication'
        FROM dual
        UNION ALL
        SELECT 'Database Links',
               TO_CHAR((SELECT COUNT(*) FROM dba_db_links WHERE owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB'))),
               'Review needed',
               CASE WHEN (SELECT COUNT(*) FROM dba_db_links WHERE owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')) = 0
                    THEN 'PASS' ELSE 'WARNING' END,
               'DB links work but verify network connectivity to targets'
        FROM dual
        UNION ALL
        SELECT 'Interconnect to Azure',
               'N/A',
               'Configure',
               'INFO',
               'Configure OCI-Azure Interconnect or ExpressRoute for hybrid'
        FROM dual
    )
    SELECT check_name, current_value, required_value, status, notes
    FROM checks
    ORDER BY CASE status WHEN 'FAIL' THEN 1 WHEN 'WARNING' THEN 2 WHEN 'INFO' THEN 3 ELSE 4 END
    """


# =============================================================================
# Azure SQL Database/Managed Instance Validation
# =============================================================================

def get_azure_sql_compatibility_summary():
    """Generate Azure SQL Database/Managed Instance compatibility summary."""
    return """
    WITH metrics AS (
        SELECT
            -- Unsupported data types for SQL Server
            (SELECT COUNT(*) FROM dba_tab_columns
             WHERE data_type IN ('LONG', 'LONG RAW', 'BFILE', 'ROWID', 'UROWID', 'ANYDATA')
               AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')) AS unsupported_types,
            -- Spatial data (needs conversion)
            (SELECT COUNT(*) FROM dba_tab_columns
             WHERE data_type LIKE 'SDO_%' OR data_type = 'MDSYS.SDO_GEOMETRY'
               AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')) AS spatial_columns,
            -- XMLType (SQL Server has XML type)
            (SELECT COUNT(*) FROM dba_tab_columns
             WHERE data_type = 'XMLTYPE'
               AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')) AS xml_columns,
            -- PL/SQL packages
            (SELECT COUNT(*) FROM dba_objects
             WHERE object_type = 'PACKAGE'
               AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')) AS package_count,
            -- Triggers
            (SELECT COUNT(*) FROM dba_triggers
             WHERE owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')) AS trigger_count,
            -- Database links
            (SELECT COUNT(*) FROM dba_db_links
             WHERE owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')) AS dblink_count,
            -- Procedures and functions
            (SELECT COUNT(*) FROM dba_objects
             WHERE object_type IN ('PROCEDURE', 'FUNCTION')
               AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')) AS proc_count,
            -- Materialized views
            (SELECT COUNT(*) FROM dba_mviews
             WHERE owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')) AS mview_count
        FROM dual
    )
    SELECT
        'Azure SQL' AS target,
        CASE
            WHEN unsupported_types > 0 THEN 'FAIL'
            WHEN package_count > 20 OR proc_count > 100 THEN 'FAIL'
            WHEN spatial_columns > 0 OR mview_count > 10 THEN 'WARNING'
            WHEN package_count > 0 OR trigger_count > 20 THEN 'WARNING'
            ELSE 'PASS'
        END AS status,
        CASE
            WHEN unsupported_types > 0 THEN unsupported_types || ' columns with unsupported types (LONG, BFILE, ROWID)'
            WHEN package_count > 20 THEN package_count || ' PL/SQL packages require T-SQL conversion'
            WHEN proc_count > 100 THEN proc_count || ' procedures/functions need T-SQL rewrite'
            WHEN spatial_columns > 0 THEN spatial_columns || ' spatial columns need SQL Server geometry/geography'
            WHEN mview_count > 10 THEN mview_count || ' materialized views - limited support as indexed views'
            WHEN package_count > 0 THEN package_count || ' packages need conversion (moderate effort)'
            WHEN trigger_count > 20 THEN trigger_count || ' triggers need T-SQL conversion'
            ELSE 'Database structure compatible with Azure SQL migration'
        END AS details,
        CASE
            WHEN unsupported_types > 0 OR package_count > 20 THEN 'Significant conversion effort - use SSMA for assessment'
            WHEN package_count > 0 OR proc_count > 50 THEN 'Moderate PL/SQL to T-SQL conversion needed'
            ELSE 'Ready for migration with SQL Server Migration Assistant (SSMA)'
        END AS recommendation
    FROM metrics
    """


def get_azure_sql_datatype_check():
    """Check Oracle data types and their Azure SQL equivalents."""
    return """
    SELECT
        owner,
        table_name,
        column_name,
        data_type,
        data_length,
        data_precision,
        data_scale,
        CASE
            WHEN data_type = 'VARCHAR2' THEN 'VARCHAR/NVARCHAR'
            WHEN data_type = 'NVARCHAR2' THEN 'NVARCHAR'
            WHEN data_type = 'CHAR' THEN 'CHAR/NCHAR'
            WHEN data_type = 'NCHAR' THEN 'NCHAR'
            WHEN data_type = 'NUMBER' AND data_scale = 0 AND data_precision <= 9 THEN 'INT'
            WHEN data_type = 'NUMBER' AND data_scale = 0 AND data_precision <= 18 THEN 'BIGINT'
            WHEN data_type = 'NUMBER' THEN 'DECIMAL/NUMERIC'
            WHEN data_type = 'FLOAT' THEN 'FLOAT'
            WHEN data_type = 'BINARY_FLOAT' THEN 'REAL'
            WHEN data_type = 'BINARY_DOUBLE' THEN 'FLOAT'
            WHEN data_type = 'DATE' THEN 'DATETIME2 (Oracle DATE has time component)'
            WHEN data_type LIKE 'TIMESTAMP%' THEN 'DATETIME2/DATETIMEOFFSET'
            WHEN data_type = 'CLOB' THEN 'VARCHAR(MAX) or NVARCHAR(MAX)'
            WHEN data_type = 'NCLOB' THEN 'NVARCHAR(MAX)'
            WHEN data_type = 'BLOB' THEN 'VARBINARY(MAX)'
            WHEN data_type = 'RAW' THEN 'VARBINARY'
            WHEN data_type = 'LONG' THEN 'CRITICAL - Convert to CLOB first, then VARCHAR(MAX)'
            WHEN data_type = 'LONG RAW' THEN 'CRITICAL - Convert to BLOB first, then VARBINARY(MAX)'
            WHEN data_type = 'BFILE' THEN 'CRITICAL - No equivalent, use Azure Blob Storage'
            WHEN data_type IN ('ROWID', 'UROWID') THEN 'CRITICAL - No equivalent, add identity/uniqueidentifier'
            WHEN data_type = 'XMLTYPE' THEN 'XML (native support)'
            WHEN data_type LIKE 'SDO_%' THEN 'GEOMETRY/GEOGRAPHY (SQL Server spatial)'
            WHEN data_type LIKE 'INTERVAL%' THEN 'No direct equivalent - store as string or separate columns'
            ELSE 'Review required'
        END AS azure_sql_type,
        CASE
            WHEN data_type IN ('LONG', 'LONG RAW', 'BFILE', 'ROWID', 'UROWID') THEN 'CRITICAL'
            WHEN data_type LIKE 'INTERVAL%' THEN 'WARNING'
            WHEN data_type LIKE 'SDO_%' THEN 'WARNING'
            WHEN data_type = 'DATE' THEN 'INFO - Oracle DATE includes time, use DATETIME2'
            ELSE 'OK'
        END AS migration_status
    FROM dba_tab_columns
    WHERE owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
      AND data_type IN ('LONG', 'LONG RAW', 'BFILE', 'ROWID', 'UROWID', 'XMLTYPE',
                        'ANYDATA', 'ANYTYPE', 'SDO_GEOMETRY', 'MDSYS.SDO_GEOMETRY')
       OR data_type LIKE 'SDO_%'
       OR data_type LIKE 'INTERVAL%'
    ORDER BY
        CASE
            WHEN data_type IN ('LONG', 'LONG RAW', 'BFILE', 'ROWID', 'UROWID') THEN 1
            ELSE 2
        END,
        owner, table_name, column_name
    """


def get_azure_sql_plsql_analysis():
    """Analyze PL/SQL code requiring T-SQL conversion for Azure SQL."""
    return """
    SELECT
        object_type,
        COUNT(*) AS object_count,
        CASE object_type
            WHEN 'PACKAGE' THEN 'CRITICAL - No equivalent in SQL Server, decompose to schemas + procedures'
            WHEN 'PACKAGE BODY' THEN 'CRITICAL - Convert package body logic to T-SQL procedures'
            WHEN 'TRIGGER' THEN 'WARNING - Rewrite in T-SQL (different syntax, INSERTED/DELETED tables)'
            WHEN 'PROCEDURE' THEN 'WARNING - Convert PL/SQL to T-SQL stored procedure'
            WHEN 'FUNCTION' THEN 'WARNING - Convert to T-SQL function (scalar/table-valued)'
            WHEN 'TYPE' THEN 'WARNING - Use table types or user-defined types in SQL Server'
            WHEN 'TYPE BODY' THEN 'WARNING - Convert type methods to functions'
            ELSE 'Review required'
        END AS migration_impact,
        CASE object_type
            WHEN 'PACKAGE' THEN 'Create schema per package, convert procs/funcs individually'
            WHEN 'TRIGGER' THEN 'Use AFTER triggers with INSERTED/DELETED pseudo-tables'
            WHEN 'PROCEDURE' THEN 'Use SSMA or manual conversion to T-SQL'
            WHEN 'FUNCTION' THEN 'Convert to T-SQL scalar or table-valued function'
            WHEN 'TYPE' THEN 'Use TABLE TYPE for collections, UDT for objects'
            ELSE 'Use SQL Server Migration Assistant (SSMA)'
        END AS recommendation,
        'SQL Server Migration Assistant (SSMA) can automate conversion' AS tool_hint
    FROM dba_objects
    WHERE object_type IN ('PACKAGE', 'PACKAGE BODY', 'TRIGGER', 'PROCEDURE', 'FUNCTION', 'TYPE', 'TYPE BODY')
      AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
    GROUP BY object_type
    ORDER BY
        CASE object_type WHEN 'PACKAGE' THEN 1 WHEN 'PACKAGE BODY' THEN 2 WHEN 'TRIGGER' THEN 3 ELSE 4 END
    """


def get_azure_sql_syntax_conversion():
    """Check Oracle-specific syntax requiring conversion for Azure SQL."""
    return """
    WITH syntax_checks AS (
        -- Oracle outer join syntax
        SELECT 'Oracle (+) Outer Join' AS check_name,
               COUNT(*) AS occurrence_count,
               'WARNING' AS severity,
               'Convert to ANSI JOIN (LEFT/RIGHT/FULL OUTER JOIN)' AS tsql_equivalent,
               'SSMA handles automatically' AS tool_support
        FROM dba_source
        WHERE REGEXP_LIKE(text, '\\(\\+\\)')
          AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
        UNION ALL
        -- CONNECT BY hierarchical
        SELECT 'CONNECT BY Hierarchical Query',
               COUNT(*),
               'WARNING',
               'Convert to recursive CTE (WITH...AS)',
               'SSMA converts to CTE'
        FROM dba_source
        WHERE UPPER(text) LIKE '%CONNECT BY%'
          AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
        UNION ALL
        -- ROWNUM
        SELECT 'ROWNUM Pseudo-column',
               COUNT(*),
               'WARNING',
               'Use ROW_NUMBER() OVER() or TOP/OFFSET-FETCH',
               'SSMA converts to ROW_NUMBER()'
        FROM dba_source
        WHERE UPPER(text) LIKE '%ROWNUM%'
          AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
        UNION ALL
        -- NVL function
        SELECT 'NVL Function',
               COUNT(*),
               'INFO',
               'Use ISNULL() or COALESCE()',
               'SSMA converts to ISNULL'
        FROM dba_source
        WHERE UPPER(text) LIKE '%NVL(%'
          AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
        UNION ALL
        -- NVL2 function
        SELECT 'NVL2 Function',
               COUNT(*),
               'WARNING',
               'Use CASE WHEN expr IS NULL THEN... or IIF()',
               'Manual conversion may be needed'
        FROM dba_source
        WHERE UPPER(text) LIKE '%NVL2(%'
          AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
        UNION ALL
        -- DECODE function
        SELECT 'DECODE Function',
               COUNT(*),
               'INFO',
               'Convert to CASE WHEN or IIF()',
               'SSMA converts to CASE'
        FROM dba_source
        WHERE UPPER(text) LIKE '%DECODE(%'
          AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
        UNION ALL
        -- SYSDATE
        SELECT 'SYSDATE',
               COUNT(*),
               'INFO',
               'Use GETDATE() or SYSDATETIME()',
               'SSMA converts automatically'
        FROM dba_source
        WHERE UPPER(text) LIKE '%SYSDATE%'
          AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
        UNION ALL
        -- DUAL table
        SELECT 'DUAL Table Reference',
               COUNT(*),
               'INFO',
               'Remove FROM DUAL (not needed in T-SQL)',
               'SSMA handles automatically'
        FROM dba_source
        WHERE UPPER(text) LIKE '%FROM DUAL%'
          AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
        UNION ALL
        -- Sequences CURRVAL/NEXTVAL
        SELECT 'Sequence CURRVAL',
               COUNT(*),
               'WARNING',
               'Use SCOPE_IDENTITY() or OUTPUT clause instead',
               'Redesign sequence usage'
        FROM dba_source
        WHERE UPPER(text) LIKE '%.CURRVAL%'
          AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
        UNION ALL
        -- Oracle hints
        SELECT 'Oracle Optimizer Hints',
               COUNT(*),
               'INFO',
               'Remove or convert to SQL Server hints (WITH, OPTION)',
               'Remove hints - Azure SQL optimizer differs'
        FROM dba_source
        WHERE REGEXP_LIKE(text, '/\\*\\+.*\\*/')
          AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
        UNION ALL
        -- ROWID
        SELECT 'ROWID Usage',
               COUNT(*),
               'CRITICAL',
               'Add IDENTITY column or use %%physloc%% (not recommended)',
               'Redesign to use primary key'
        FROM dba_source
        WHERE UPPER(text) LIKE '%ROWID%'
          AND UPPER(text) NOT LIKE '%UROWID%'
          AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
    )
    SELECT check_name, occurrence_count, severity, tsql_equivalent, tool_support
    FROM syntax_checks
    WHERE occurrence_count > 0
    ORDER BY
        CASE severity WHEN 'CRITICAL' THEN 1 WHEN 'WARNING' THEN 2 ELSE 3 END,
        occurrence_count DESC
    """


def get_azure_sql_feature_gaps():
    """Check Oracle features with limited or no Azure SQL equivalent."""
    return """
    WITH feature_checks AS (
        -- Materialized Views
        SELECT 'Materialized Views' AS feature,
               (SELECT COUNT(*) FROM dba_mviews WHERE owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')) AS object_count,
               'LIMITED' AS azure_sql_support,
               'Indexed Views (more restrictive than Oracle MVs)' AS azure_equivalent,
               'Indexed views cannot use outer joins, subqueries, or non-deterministic functions' AS limitation
        FROM dual
        UNION ALL
        -- Database Links
        SELECT 'Database Links',
               (SELECT COUNT(*) FROM dba_db_links WHERE owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')),
               'DIFFERENT',
               'Linked Servers or Azure SQL Managed Instance linking',
               'Linked servers work differently - elastic queries available'
        FROM dual
        UNION ALL
        -- Bitmap Indexes
        SELECT 'Bitmap Indexes',
               (SELECT COUNT(*) FROM dba_indexes WHERE index_type = 'BITMAP' AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')),
               'NOT SUPPORTED',
               'Columnstore indexes for analytics workloads',
               'Use columnstore for similar OLAP optimization'
        FROM dual
        UNION ALL
        -- Global Temporary Tables
        SELECT 'Global Temporary Tables',
               (SELECT COUNT(*) FROM dba_tables WHERE temporary = 'Y' AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')),
               'DIFFERENT',
               'Local temp tables (#) or global temp tables (##)',
               'SQL Server temp tables have different scoping rules'
        FROM dual
        UNION ALL
        -- Partitioning
        SELECT 'Partitioned Tables',
               (SELECT COUNT(DISTINCT table_name) FROM dba_tab_partitions WHERE table_owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')),
               'SUPPORTED',
               'Table partitioning (requires proper edition)',
               'Azure SQL supports partitioning - verify edition requirements'
        FROM dual
        UNION ALL
        -- Synonyms
        SELECT 'Synonyms',
               (SELECT COUNT(*) FROM dba_synonyms WHERE owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')),
               'SUPPORTED',
               'CREATE SYNONYM supported in T-SQL',
               'Synonyms work similarly in SQL Server'
        FROM dual
        UNION ALL
        -- Sequences
        SELECT 'Sequences',
               (SELECT COUNT(*) FROM dba_sequences WHERE sequence_owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')),
               'SUPPORTED',
               'CREATE SEQUENCE (SQL Server 2012+)',
               'Sequences supported but CURRVAL not available'
        FROM dual
        UNION ALL
        -- VPD (Virtual Private Database)
        SELECT 'Virtual Private Database (VPD)',
               (SELECT COUNT(*) FROM dba_policies WHERE object_owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')),
               'DIFFERENT',
               'Row-Level Security (RLS)',
               'Azure SQL has RLS with security predicates'
        FROM dual
        UNION ALL
        -- Advanced Queuing
        SELECT 'Advanced Queuing (AQ)',
               (SELECT COUNT(*) FROM dba_queues WHERE owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')),
               'NOT SUPPORTED',
               'Service Broker or Azure Service Bus',
               'Redesign using Service Broker or external messaging'
        FROM dual
    )
    SELECT feature, object_count, azure_sql_support, azure_equivalent, limitation
    FROM feature_checks
    WHERE object_count > 0
    ORDER BY
        CASE azure_sql_support
            WHEN 'NOT SUPPORTED' THEN 1
            WHEN 'LIMITED' THEN 2
            WHEN 'DIFFERENT' THEN 3
            ELSE 4
        END,
        object_count DESC
    """


def get_azure_sql_validation_detail():
    """Detailed validation checklist for Azure SQL migration."""
    return """
    WITH checks AS (
        SELECT 'Unsupported Data Types' AS check_name,
               TO_CHAR((SELECT COUNT(*) FROM dba_tab_columns
                        WHERE data_type IN ('LONG','LONG RAW','BFILE','ROWID','UROWID','ANYDATA')
                          AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB'))) AS current_value,
               '0' AS required_value,
               CASE WHEN (SELECT COUNT(*) FROM dba_tab_columns
                          WHERE data_type IN ('LONG','LONG RAW','BFILE','ROWID','UROWID','ANYDATA')
                            AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')) = 0
                    THEN 'PASS' ELSE 'FAIL' END AS status,
               'LONG, BFILE, ROWID have no SQL Server equivalent' AS notes
        FROM dual
        UNION ALL
        SELECT 'PL/SQL Packages',
               TO_CHAR((SELECT COUNT(*) FROM dba_objects WHERE object_type = 'PACKAGE'
                          AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB'))),
               '0',
               CASE WHEN (SELECT COUNT(*) FROM dba_objects WHERE object_type = 'PACKAGE'
                            AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')) = 0
                    THEN 'PASS' ELSE 'FAIL' END,
               'Packages must be converted to schemas + standalone procedures'
        FROM dual
        UNION ALL
        SELECT 'Database Triggers',
               TO_CHAR((SELECT COUNT(*) FROM dba_triggers WHERE owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB'))),
               'Review needed',
               CASE WHEN (SELECT COUNT(*) FROM dba_triggers WHERE owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')) = 0
                    THEN 'PASS'
                    WHEN (SELECT COUNT(*) FROM dba_triggers WHERE owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')) <= 20
                    THEN 'WARNING' ELSE 'FAIL' END,
               'Triggers need T-SQL conversion (INSERTED/DELETED tables)'
        FROM dual
        UNION ALL
        SELECT 'Procedures/Functions',
               TO_CHAR((SELECT COUNT(*) FROM dba_objects
                        WHERE object_type IN ('PROCEDURE','FUNCTION')
                          AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB'))),
               'Convert to T-SQL',
               CASE WHEN (SELECT COUNT(*) FROM dba_objects
                          WHERE object_type IN ('PROCEDURE','FUNCTION')
                            AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')) <= 50
                    THEN 'WARNING' ELSE 'FAIL' END,
               'Use SSMA for automated PL/SQL to T-SQL conversion'
        FROM dual
        UNION ALL
        SELECT 'Materialized Views',
               TO_CHAR((SELECT COUNT(*) FROM dba_mviews WHERE owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB'))),
               '0 (or convert)',
               CASE WHEN (SELECT COUNT(*) FROM dba_mviews WHERE owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')) = 0
                    THEN 'PASS'
                    WHEN (SELECT COUNT(*) FROM dba_mviews WHERE owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')) <= 10
                    THEN 'WARNING' ELSE 'FAIL' END,
               'Convert to Indexed Views (significant restrictions apply)'
        FROM dual
        UNION ALL
        SELECT 'Database Links',
               TO_CHAR((SELECT COUNT(*) FROM dba_db_links WHERE owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB'))),
               '0 (or convert)',
               CASE WHEN (SELECT COUNT(*) FROM dba_db_links WHERE owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')) = 0
                    THEN 'PASS' ELSE 'WARNING' END,
               'Convert to Linked Servers or redesign for Azure'
        FROM dual
        UNION ALL
        SELECT 'Advanced Queues',
               TO_CHAR((SELECT COUNT(*) FROM dba_queues WHERE owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB'))),
               '0',
               CASE WHEN (SELECT COUNT(*) FROM dba_queues WHERE owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')) = 0
                    THEN 'PASS' ELSE 'FAIL' END,
               'No AQ equivalent - use Service Broker or Azure Service Bus'
        FROM dual
        UNION ALL
        SELECT 'Database Size (GB)',
               TO_CHAR(ROUND((SELECT SUM(bytes)/1024/1024/1024 FROM dba_segments), 0)),
               '< 16TB (Managed Instance)',
               CASE WHEN (SELECT SUM(bytes)/1024/1024/1024/1024 FROM dba_segments) <= 16
                    THEN 'PASS' ELSE 'WARNING' END,
               'Azure SQL MI supports up to 16TB, SQL DB up to 4TB'
        FROM dual
    )
    SELECT check_name, current_value, required_value, status, notes
    FROM checks
    ORDER BY
        CASE status WHEN 'FAIL' THEN 1 WHEN 'WARNING' THEN 2 ELSE 3 END
    """


def get_azure_sql_size_assessment():
    """Assess database size for Azure SQL tier selection."""
    return """
    WITH size_info AS (
        SELECT
            ROUND(SUM(bytes)/1024/1024/1024, 2) AS total_gb,
            ROUND(SUM(CASE WHEN segment_type IN ('TABLE', 'TABLE PARTITION') THEN bytes ELSE 0 END)/1024/1024/1024, 2) AS table_gb,
            ROUND(SUM(CASE WHEN segment_type IN ('INDEX', 'INDEX PARTITION') THEN bytes ELSE 0 END)/1024/1024/1024, 2) AS index_gb,
            ROUND(SUM(CASE WHEN segment_type IN ('LOBSEGMENT', 'LOB PARTITION') THEN bytes ELSE 0 END)/1024/1024/1024, 2) AS lob_gb
        FROM dba_segments
        WHERE owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
    )
    SELECT
        'Total Database Size' AS metric,
        TO_CHAR(total_gb) || ' GB' AS value,
        CASE
            WHEN total_gb <= 250 THEN 'Azure SQL Database (General Purpose)'
            WHEN total_gb <= 1000 THEN 'Azure SQL Database (Business Critical) or Managed Instance'
            WHEN total_gb <= 4000 THEN 'Azure SQL Managed Instance'
            WHEN total_gb <= 16000 THEN 'Azure SQL Managed Instance (16TB max)'
            ELSE 'Consider Oracle@Azure or sharding strategy'
        END AS recommended_tier
    FROM size_info
    UNION ALL
    SELECT
        'Table Data',
        TO_CHAR(table_gb) || ' GB',
        'Primary storage requirement'
    FROM size_info
    UNION ALL
    SELECT
        'Index Data',
        TO_CHAR(index_gb) || ' GB',
        'SQL Server may use different indexing - size may vary'
    FROM size_info
    UNION ALL
    SELECT
        'LOB Data',
        TO_CHAR(lob_gb) || ' GB',
        CASE WHEN lob_gb > 100 THEN 'Consider Azure Blob Storage for large objects' ELSE 'VARCHAR(MAX)/VARBINARY(MAX)' END
    FROM size_info
    UNION ALL
    SELECT
        'Estimated Azure Cost Tier',
        CASE
            WHEN (SELECT SUM(bytes)/1024/1024/1024 FROM dba_segments) <= 100 THEN 'General Purpose 8 vCores'
            WHEN (SELECT SUM(bytes)/1024/1024/1024 FROM dba_segments) <= 500 THEN 'General Purpose 16 vCores'
            WHEN (SELECT SUM(bytes)/1024/1024/1024 FROM dba_segments) <= 2000 THEN 'Business Critical 32 vCores'
            ELSE 'Managed Instance 64+ vCores'
        END,
        'Estimate only - use Azure Pricing Calculator for accurate costs'
    FROM dual
    """


# =============================================================================
# Oracle Database@AWS Validation Queries
# =============================================================================

def get_oracle_at_aws_compatibility_summary():
    """Generate Oracle Database@AWS compatibility summary - RDS for Oracle and EC2 options."""
    return r"""
    WITH feature_checks AS (
        SELECT 'Database Version' AS check_item,
               (SELECT version FROM v$instance) AS current_value,
               CASE
                   WHEN (SELECT TO_NUMBER(REGEXP_SUBSTR(version, '^\d+')) FROM v$instance) >= 19 THEN 'PASS'
                   WHEN (SELECT TO_NUMBER(REGEXP_SUBSTR(version, '^\d+')) FROM v$instance) >= 12 THEN 'PASS'
                   ELSE 'REVIEW'
               END AS rds_status,
               CASE WHEN 1=1 THEN 'PASS' END AS ec2_status,
               'RDS supports 19c, 21c; EC2 supports all versions' AS notes
        FROM dual
        UNION ALL
        SELECT 'Database Edition',
               (SELECT CASE WHEN banner LIKE '%Enterprise%' THEN 'Enterprise'
                           WHEN banner LIKE '%Standard%' THEN 'Standard'
                           ELSE 'Unknown' END FROM v$version WHERE ROWNUM = 1),
               CASE
                   WHEN (SELECT banner FROM v$version WHERE ROWNUM = 1) LIKE '%Enterprise%' THEN 'PASS'
                   WHEN (SELECT banner FROM v$version WHERE ROWNUM = 1) LIKE '%Standard%' THEN 'PASS'
                   ELSE 'REVIEW'
               END,
               'PASS',
               'RDS supports SE2 and EE; EC2 supports all editions'
        FROM dual
        UNION ALL
        SELECT 'RAC Configuration',
               (SELECT CASE WHEN value = 'TRUE' THEN 'Enabled' ELSE 'Disabled' END
                FROM v$parameter WHERE name = 'cluster_database'),
               CASE
                   WHEN (SELECT value FROM v$parameter WHERE name = 'cluster_database') = 'TRUE' THEN 'FAIL'
                   ELSE 'PASS'
               END,
               'PASS',
               'RDS does not support RAC; EC2 requires manual RAC setup'
        FROM dual
        UNION ALL
        SELECT 'Data Guard',
               (SELECT CASE WHEN database_role != 'PRIMARY' OR protection_mode != 'MAXIMUM PERFORMANCE'
                           THEN 'Active' ELSE 'Not Active' END FROM v$database),
               'PASS',
               'PASS',
               'RDS supports Multi-AZ; EC2 supports full Data Guard'
        FROM dual
        UNION ALL
        SELECT 'Database Size (GB)',
               (SELECT TO_CHAR(ROUND(SUM(bytes)/1024/1024/1024, 2)) FROM dba_segments),
               CASE
                   WHEN (SELECT SUM(bytes)/1024/1024/1024 FROM dba_segments) <= 65536 THEN 'PASS'
                   ELSE 'REVIEW'
               END,
               'PASS',
               'RDS max 64TB; EC2 depends on EBS/instance storage'
        FROM dual
        UNION ALL
        SELECT 'Character Set',
               (SELECT value FROM nls_database_parameters WHERE parameter = 'NLS_CHARACTERSET'),
               'PASS',
               'PASS',
               'All character sets supported on both platforms'
        FROM dual
        UNION ALL
        SELECT 'Encryption (TDE)',
               (SELECT CASE WHEN COUNT(*) > 0 THEN 'Enabled' ELSE 'Disabled' END
                FROM v$encrypted_tablespaces WHERE encryptionalg IS NOT NULL),
               'PASS',
               'PASS',
               'TDE supported via AWS KMS on RDS; full TDE on EC2'
        FROM dual
        UNION ALL
        SELECT 'Database Links',
               (SELECT TO_CHAR(COUNT(*)) FROM dba_db_links),
               CASE
                   WHEN (SELECT COUNT(*) FROM dba_db_links) > 0 THEN 'REVIEW'
                   ELSE 'PASS'
               END,
               'PASS',
               'RDS has network restrictions for DB links; EC2 full support'
        FROM dual
        UNION ALL
        SELECT 'External Tables',
               (SELECT TO_CHAR(COUNT(*)) FROM dba_external_tables),
               CASE
                   WHEN (SELECT COUNT(*) FROM dba_external_tables) > 0 THEN 'REVIEW'
                   ELSE 'PASS'
               END,
               'PASS',
               'RDS uses S3 integration; EC2 uses local/EFS storage'
        FROM dual
        UNION ALL
        SELECT 'BFILE Usage',
               (SELECT TO_CHAR(COUNT(*)) FROM dba_tab_columns WHERE data_type = 'BFILE'),
               CASE
                   WHEN (SELECT COUNT(*) FROM dba_tab_columns WHERE data_type = 'BFILE') > 0 THEN 'FAIL'
                   ELSE 'PASS'
               END,
               'PASS',
               'RDS does not support BFILE; EC2 supports with local storage'
        FROM dual
    )
    SELECT check_item,
           current_value,
           rds_status AS "RDS for Oracle",
           ec2_status AS "Oracle on EC2",
           notes
    FROM feature_checks
    ORDER BY CASE rds_status
        WHEN 'FAIL' THEN 1
        WHEN 'REVIEW' THEN 2
        ELSE 3
    END
    """


def get_oracle_at_aws_rds_validation():
    """Detailed validation for AWS RDS for Oracle target."""
    return """
    WITH validation_checks AS (
        SELECT 1 AS seq, 'Instance Class Sizing' AS category, 'CPU Requirements' AS check_item,
               (SELECT TO_CHAR(value) FROM v$parameter WHERE name = 'cpu_count') AS current_value,
               'PASS' AS status,
               'RDS supports up to 128 vCPUs (db.r5.24xlarge)' AS recommendation
        FROM dual
        UNION ALL
        SELECT 2, 'Instance Class Sizing', 'Memory Requirements',
               (SELECT TO_CHAR(ROUND(value/1024/1024/1024, 2)) || ' GB' FROM v$parameter WHERE name = 'sga_target'),
               CASE
                   WHEN (SELECT value/1024/1024/1024 FROM v$parameter WHERE name = 'sga_target') <= 768 THEN 'PASS'
                   ELSE 'REVIEW'
               END,
               'RDS max memory ~768GB on largest instance'
        FROM dual
        UNION ALL
        SELECT 3, 'Storage', 'Total Size',
               (SELECT TO_CHAR(ROUND(SUM(bytes)/1024/1024/1024, 2)) || ' GB' FROM dba_data_files),
               CASE
                   WHEN (SELECT SUM(bytes)/1024/1024/1024 FROM dba_data_files) <= 65536 THEN 'PASS'
                   ELSE 'FAIL'
               END,
               'RDS max storage 64TB'
        FROM dual
        UNION ALL
        SELECT 4, 'Storage', 'Storage Type Recommendation',
               (SELECT CASE
                   WHEN SUM(bytes)/1024/1024/1024 > 10000 THEN 'io1/io2 Provisioned IOPS'
                   WHEN SUM(bytes)/1024/1024/1024 > 1000 THEN 'gp3 General Purpose'
                   ELSE 'gp2/gp3 General Purpose'
               END FROM dba_data_files),
               'PASS',
               'Choose storage type based on IOPS requirements'
        FROM dual
        UNION ALL
        SELECT 5, 'High Availability', 'Multi-AZ Recommendation',
               (SELECT database_role FROM v$database),
               'PASS',
               'Enable Multi-AZ for production workloads'
        FROM dual
        UNION ALL
        SELECT 6, 'Licensing', 'License Model',
               (SELECT CASE WHEN banner LIKE '%Enterprise%' THEN 'Enterprise Edition'
                           ELSE 'Standard Edition' END FROM v$version WHERE ROWNUM = 1),
               'PASS',
               'License Included or BYOL available'
        FROM dual
        UNION ALL
        SELECT 7, 'Features', 'Option Groups Required',
               (SELECT LISTAGG(comp_name, ', ') WITHIN GROUP (ORDER BY comp_name)
                FROM dba_registry WHERE status = 'VALID'
                AND comp_name IN ('Oracle Text', 'Oracle Spatial', 'Oracle Label Security',
                                  'Oracle OLAP', 'Oracle Multimedia')),
               CASE
                   WHEN (SELECT COUNT(*) FROM dba_registry WHERE status = 'VALID'
                         AND comp_name IN ('Oracle Text', 'Oracle Spatial', 'Oracle Label Security')) > 0 THEN 'REVIEW'
                   ELSE 'PASS'
               END,
               'Some options require specific RDS option groups'
        FROM dual
        UNION ALL
        SELECT 8, 'Network', 'VPC Configuration',
               'Required',
               'PASS',
               'RDS must be deployed in VPC with proper security groups'
        FROM dual
        UNION ALL
        SELECT 9, 'Security', 'SSL/TLS',
               (SELECT CASE WHEN COUNT(*) > 0 THEN 'In Use' ELSE 'Not Configured' END
                FROM v$session WHERE program LIKE '%TCPS%'),
               'PASS',
               'RDS supports SSL connections (rds-ca certificates)'
        FROM dual
        UNION ALL
        SELECT 10, 'Backup', 'Automated Backups',
               (SELECT TO_CHAR(ROUND(SUM(bytes)/1024/1024/1024, 2)) || ' GB backup size estimate'
                FROM dba_data_files),
               'PASS',
               'RDS automated backups with point-in-time recovery'
        FROM dual
    )
    SELECT category, check_item, current_value, status, recommendation
    FROM validation_checks
    ORDER BY seq
    """


def get_oracle_at_aws_ec2_validation():
    """Detailed validation for Oracle on EC2 target."""
    return """
    WITH validation_checks AS (
        SELECT 1 AS seq, 'Compute' AS category, 'Instance Type Recommendation' AS check_item,
               (SELECT TO_CHAR(value) || ' CPUs' FROM v$parameter WHERE name = 'cpu_count') AS current_value,
               'PASS' AS status,
               CASE
                   WHEN (SELECT value FROM v$parameter WHERE name = 'cpu_count') <= 8 THEN 'r6i.2xlarge or r6i.4xlarge'
                   WHEN (SELECT value FROM v$parameter WHERE name = 'cpu_count') <= 16 THEN 'r6i.4xlarge or r6i.8xlarge'
                   WHEN (SELECT value FROM v$parameter WHERE name = 'cpu_count') <= 32 THEN 'r6i.8xlarge or r6i.12xlarge'
                   WHEN (SELECT value FROM v$parameter WHERE name = 'cpu_count') <= 64 THEN 'r6i.16xlarge or r6i.24xlarge'
                   ELSE 'r6i.metal or x2idn instances'
               END AS recommendation
        FROM dual
        UNION ALL
        SELECT 2, 'Compute', 'Memory Sizing',
               (SELECT TO_CHAR(ROUND(value/1024/1024/1024, 2)) || ' GB SGA' FROM v$parameter WHERE name = 'sga_target'),
               'PASS',
               'Memory-optimized instances (r6i, x2idn) recommended for databases'
        FROM dual
        UNION ALL
        SELECT 3, 'Storage', 'EBS Volume Type',
               (SELECT TO_CHAR(ROUND(SUM(bytes)/1024/1024/1024, 2)) || ' GB' FROM dba_data_files),
               'PASS',
               CASE
                   WHEN (SELECT SUM(bytes)/1024/1024/1024 FROM dba_data_files) > 5000 THEN 'io2 Block Express for large DBs'
                   WHEN (SELECT SUM(bytes)/1024/1024/1024 FROM dba_data_files) > 1000 THEN 'io1/io2 for high IOPS'
                   ELSE 'gp3 for balanced performance'
               END
        FROM dual
        UNION ALL
        SELECT 4, 'Storage', 'IOPS Estimate',
               'Based on workload',
               'REVIEW',
               'Analyze AWR for actual IOPS requirements; provision accordingly'
        FROM dual
        UNION ALL
        SELECT 5, 'High Availability', 'HA Architecture',
               (SELECT CASE WHEN value = 'TRUE' THEN 'RAC Enabled' ELSE 'Single Instance' END
                FROM v$parameter WHERE name = 'cluster_database'),
               'PASS',
               CASE
                   WHEN (SELECT value FROM v$parameter WHERE name = 'cluster_database') = 'TRUE'
                   THEN 'Consider RAC on EC2 with shared storage or migrate to single instance with Data Guard'
                   ELSE 'Use Data Guard for HA/DR on EC2'
               END
        FROM dual
        UNION ALL
        SELECT 6, 'Licensing', 'License Type',
               (SELECT CASE WHEN banner LIKE '%Enterprise%' THEN 'Enterprise' ELSE 'Standard' END
                FROM v$version WHERE ROWNUM = 1),
               'PASS',
               'BYOL required for EC2; ensure compliance with Oracle licensing'
        FROM dual
        UNION ALL
        SELECT 7, 'Networking', 'Placement Group',
               'Recommended for RAC',
               'PASS',
               'Use cluster placement group for RAC; spread placement for single instance HA'
        FROM dual
        UNION ALL
        SELECT 8, 'Backup', 'Backup Strategy',
               (SELECT TO_CHAR(ROUND(SUM(bytes)/1024/1024/1024, 2)) || ' GB' FROM dba_data_files),
               'PASS',
               'Use RMAN with S3 (via OSB Cloud Module) or EBS snapshots'
        FROM dual
        UNION ALL
        SELECT 9, 'Security', 'Encryption Options',
               (SELECT CASE WHEN COUNT(*) > 0 THEN 'TDE Enabled' ELSE 'TDE Not Enabled' END
                FROM v$encrypted_tablespaces WHERE encryptionalg IS NOT NULL),
               'PASS',
               'Use TDE with AWS CloudHSM or software keystore; EBS encryption for at-rest'
        FROM dual
        UNION ALL
        SELECT 10, 'Management', 'Automation',
               'Self-managed',
               'REVIEW',
               'Consider AWS Systems Manager, CloudWatch for monitoring; manual patching required'
        FROM dual
    )
    SELECT category, check_item, current_value, status, recommendation
    FROM validation_checks
    ORDER BY seq
    """


# =============================================================================
# Oracle Database@GCP Validation Queries
# =============================================================================

def get_oracle_at_gcp_compatibility_summary():
    """Generate Oracle Database@GCP compatibility summary - Bare Metal and Compute Engine options."""
    return """
    WITH feature_checks AS (
        SELECT 'Database Version' AS check_item,
               (SELECT version FROM v$instance) AS current_value,
               CASE WHEN 1=1 THEN 'PASS' END AS bare_metal_status,
               CASE WHEN 1=1 THEN 'PASS' END AS compute_engine_status,
               'All Oracle versions supported on both platforms' AS notes
        FROM dual
        UNION ALL
        SELECT 'Database Edition',
               (SELECT CASE WHEN banner LIKE '%Enterprise%' THEN 'Enterprise'
                           WHEN banner LIKE '%Standard%' THEN 'Standard'
                           ELSE 'Unknown' END FROM v$version WHERE ROWNUM = 1),
               'PASS',
               'PASS',
               'All editions supported; BYOL required'
        FROM dual
        UNION ALL
        SELECT 'RAC Configuration',
               (SELECT CASE WHEN value = 'TRUE' THEN 'Enabled' ELSE 'Disabled' END
                FROM v$parameter WHERE name = 'cluster_database'),
               'PASS',
               CASE
                   WHEN (SELECT value FROM v$parameter WHERE name = 'cluster_database') = 'TRUE' THEN 'REVIEW'
                   ELSE 'PASS'
               END,
               'RAC fully supported on Bare Metal; requires setup on Compute Engine'
        FROM dual
        UNION ALL
        SELECT 'Data Guard',
               (SELECT CASE WHEN database_role != 'PRIMARY' THEN 'Active' ELSE 'Available' END FROM v$database),
               'PASS',
               'PASS',
               'Full Data Guard support on both platforms'
        FROM dual
        UNION ALL
        SELECT 'Database Size (GB)',
               (SELECT TO_CHAR(ROUND(SUM(bytes)/1024/1024/1024, 2)) FROM dba_segments),
               'PASS',
               CASE
                   WHEN (SELECT SUM(bytes)/1024/1024/1024 FROM dba_segments) <= 64000 THEN 'PASS'
                   ELSE 'REVIEW'
               END,
               'Bare Metal supports very large DBs; Compute Engine limited by disk'
        FROM dual
        UNION ALL
        SELECT 'Character Set',
               (SELECT value FROM nls_database_parameters WHERE parameter = 'NLS_CHARACTERSET'),
               'PASS',
               'PASS',
               'All character sets supported'
        FROM dual
        UNION ALL
        SELECT 'Encryption (TDE)',
               (SELECT CASE WHEN COUNT(*) > 0 THEN 'Enabled' ELSE 'Disabled' END
                FROM v$encrypted_tablespaces WHERE encryptionalg IS NOT NULL),
               'PASS',
               'PASS',
               'TDE fully supported; can integrate with Google Cloud KMS'
        FROM dual
        UNION ALL
        SELECT 'Exadata Features',
               (SELECT CASE WHEN COUNT(*) > 0 THEN 'In Use' ELSE 'Not Used' END
                FROM v$cell_state WHERE ROWNUM = 1),
               CASE
                   WHEN (SELECT COUNT(*) FROM v$cell_state WHERE ROWNUM = 1) > 0 THEN 'PASS'
                   ELSE 'N/A'
               END,
               'N/A',
               'Bare Metal Solution includes Exadata; not available on Compute Engine'
        FROM dual
        UNION ALL
        SELECT 'Database Links',
               (SELECT TO_CHAR(COUNT(*)) FROM dba_db_links),
               'PASS',
               'PASS',
               'Full database link support on both platforms'
        FROM dual
        UNION ALL
        SELECT 'External Tables',
               (SELECT TO_CHAR(COUNT(*)) FROM dba_external_tables),
               'PASS',
               'PASS',
               'External tables supported; can use Cloud Storage with appropriate setup'
        FROM dual
    )
    SELECT check_item,
           current_value,
           bare_metal_status AS "Bare Metal Solution",
           compute_engine_status AS "Compute Engine",
           notes
    FROM feature_checks
    ORDER BY CASE bare_metal_status
        WHEN 'FAIL' THEN 1
        WHEN 'REVIEW' THEN 2
        ELSE 3
    END
    """


def get_oracle_at_gcp_bare_metal_validation():
    """Detailed validation for Google Cloud Bare Metal Solution for Oracle."""
    return """
    WITH validation_checks AS (
        SELECT 1 AS seq, 'Infrastructure' AS category, 'Server Configuration' AS check_item,
               (SELECT TO_CHAR(value) || ' CPUs' FROM v$parameter WHERE name = 'cpu_count') AS current_value,
               'PASS' AS status,
               'Bare Metal offers pre-configured Exadata and non-Exadata servers' AS recommendation
        FROM dual
        UNION ALL
        SELECT 2, 'Infrastructure', 'Memory Requirements',
               (SELECT TO_CHAR(ROUND(value/1024/1024/1024, 2)) || ' GB SGA' FROM v$parameter WHERE name = 'sga_target'),
               'PASS',
               'Bare Metal servers range from 384GB to 3TB+ RAM'
        FROM dual
        UNION ALL
        SELECT 3, 'Storage', 'Database Size',
               (SELECT TO_CHAR(ROUND(SUM(bytes)/1024/1024/1024, 2)) || ' GB' FROM dba_data_files),
               'PASS',
               'High-performance NVMe and SAN storage available'
        FROM dual
        UNION ALL
        SELECT 4, 'Storage', 'Exadata Storage',
               (SELECT CASE WHEN COUNT(*) > 0 THEN 'Currently on Exadata' ELSE 'Standard Storage' END
                FROM v$cell_state WHERE ROWNUM = 1),
               'PASS',
               'Exadata configurations available for Bare Metal Solution'
        FROM dual
        UNION ALL
        SELECT 5, 'High Availability', 'RAC Support',
               (SELECT CASE WHEN value = 'TRUE' THEN 'RAC Enabled' ELSE 'Single Instance' END
                FROM v$parameter WHERE name = 'cluster_database'),
               'PASS',
               'Full RAC support on Bare Metal Solution'
        FROM dual
        UNION ALL
        SELECT 6, 'High Availability', 'Data Guard',
               (SELECT database_role FROM v$database),
               'PASS',
               'Full Data Guard support for DR across regions'
        FROM dual
        UNION ALL
        SELECT 7, 'Licensing', 'License Requirements',
               (SELECT CASE WHEN banner LIKE '%Enterprise%' THEN 'Enterprise Edition'
                           ELSE 'Standard Edition' END FROM v$version WHERE ROWNUM = 1),
               'REVIEW',
               'BYOL required; Oracle ULA or separate licenses needed'
        FROM dual
        UNION ALL
        SELECT 8, 'Network', 'Connectivity',
               'Private Service Connect',
               'PASS',
               'Low-latency connection to GCP services via Partner Interconnect'
        FROM dual
        UNION ALL
        SELECT 9, 'Management', 'Administration',
               'Full DBA Access',
               'PASS',
               'Full OS and database administrative access'
        FROM dual
        UNION ALL
        SELECT 10, 'Integration', 'GCP Services',
               'Available',
               'PASS',
               'Integrate with BigQuery, Cloud Storage, Dataflow via GoldenGate or APIs'
        FROM dual
    )
    SELECT category, check_item, current_value, status, recommendation
    FROM validation_checks
    ORDER BY seq
    """


def get_oracle_at_gcp_compute_validation():
    """Detailed validation for Oracle on Google Compute Engine."""
    return """
    WITH validation_checks AS (
        SELECT 1 AS seq, 'Compute' AS category, 'Machine Type Recommendation' AS check_item,
               (SELECT TO_CHAR(value) || ' CPUs' FROM v$parameter WHERE name = 'cpu_count') AS current_value,
               'PASS' AS status,
               CASE
                   WHEN (SELECT value FROM v$parameter WHERE name = 'cpu_count') <= 8 THEN 'n2-highmem-8 or m2-ultramem-*'
                   WHEN (SELECT value FROM v$parameter WHERE name = 'cpu_count') <= 16 THEN 'n2-highmem-16 or m2-ultramem-*'
                   WHEN (SELECT value FROM v$parameter WHERE name = 'cpu_count') <= 32 THEN 'n2-highmem-32 or m2-ultramem-*'
                   WHEN (SELECT value FROM v$parameter WHERE name = 'cpu_count') <= 64 THEN 'n2-highmem-64 or m2-megamem-*'
                   ELSE 'm2-megamem-416 or custom machine type'
               END AS recommendation
        FROM dual
        UNION ALL
        SELECT 2, 'Compute', 'Memory Sizing',
               (SELECT TO_CHAR(ROUND(value/1024/1024/1024, 2)) || ' GB SGA' FROM v$parameter WHERE name = 'sga_target'),
               'PASS',
               'Use memory-optimized machine types (m2-ultramem, m2-megamem) for large SGA'
        FROM dual
        UNION ALL
        SELECT 3, 'Storage', 'Persistent Disk Type',
               (SELECT TO_CHAR(ROUND(SUM(bytes)/1024/1024/1024, 2)) || ' GB' FROM dba_data_files),
               'PASS',
               CASE
                   WHEN (SELECT SUM(bytes)/1024/1024/1024 FROM dba_data_files) > 5000 THEN 'pd-extreme for highest IOPS'
                   WHEN (SELECT SUM(bytes)/1024/1024/1024 FROM dba_data_files) > 1000 THEN 'pd-ssd for balanced performance'
                   ELSE 'pd-ssd or pd-balanced'
               END
        FROM dual
        UNION ALL
        SELECT 4, 'Storage', 'Local SSD Option',
               'For temp/redo',
               'PASS',
               'Consider Local SSD for redo logs and temp tablespace (non-persistent)'
        FROM dual
        UNION ALL
        SELECT 5, 'High Availability', 'HA Strategy',
               (SELECT CASE WHEN value = 'TRUE' THEN 'RAC Enabled' ELSE 'Single Instance' END
                FROM v$parameter WHERE name = 'cluster_database'),
               CASE
                   WHEN (SELECT value FROM v$parameter WHERE name = 'cluster_database') = 'TRUE' THEN 'REVIEW'
                   ELSE 'PASS'
               END,
               CASE
                   WHEN (SELECT value FROM v$parameter WHERE name = 'cluster_database') = 'TRUE'
                   THEN 'RAC on GCE requires shared storage setup; consider Data Guard instead'
                   ELSE 'Use Data Guard across zones for HA'
               END
        FROM dual
        UNION ALL
        SELECT 6, 'Licensing', 'License Model',
               (SELECT CASE WHEN banner LIKE '%Enterprise%' THEN 'Enterprise' ELSE 'Standard' END
                FROM v$version WHERE ROWNUM = 1),
               'REVIEW',
               'BYOL required; ensure Oracle licensing compliance for cloud'
        FROM dual
        UNION ALL
        SELECT 7, 'Networking', 'VPC Configuration',
               'Required',
               'PASS',
               'Deploy in VPC with proper firewall rules and Cloud NAT'
        FROM dual
        UNION ALL
        SELECT 8, 'Backup', 'Backup Strategy',
               (SELECT TO_CHAR(ROUND(SUM(bytes)/1024/1024/1024, 2)) || ' GB' FROM dba_data_files),
               'PASS',
               'Use RMAN with Cloud Storage or persistent disk snapshots'
        FROM dual
        UNION ALL
        SELECT 9, 'Security', 'Encryption',
               (SELECT CASE WHEN COUNT(*) > 0 THEN 'TDE Enabled' ELSE 'TDE Not Enabled' END
                FROM v$encrypted_tablespaces WHERE encryptionalg IS NOT NULL),
               'PASS',
               'Use TDE with Cloud KMS or software keystore; disk encryption automatic'
        FROM dual
        UNION ALL
        SELECT 10, 'Management', 'Operations',
               'Self-managed',
               'REVIEW',
               'Use Cloud Monitoring, Ops Agent; consider Oracle Enterprise Manager'
        FROM dual
    )
    SELECT category, check_item, current_value, status, recommendation
    FROM validation_checks
    ORDER BY seq
    """


# =============================================================================
# PostgreSQL Target Validation Queries (Common functions used by all PostgreSQL targets)
# =============================================================================

def get_postgresql_datatype_check():
    """Check Oracle data types and their PostgreSQL equivalents."""
    return """
    WITH datatype_mapping AS (
        SELECT 'VARCHAR2' AS oracle_type, 'VARCHAR or TEXT' AS pg_type, 'Direct mapping' AS conversion_notes FROM dual
        UNION ALL SELECT 'NVARCHAR2', 'VARCHAR or TEXT', 'UTF-8 native in PostgreSQL' FROM dual
        UNION ALL SELECT 'CHAR', 'CHAR', 'Direct mapping' FROM dual
        UNION ALL SELECT 'NCHAR', 'CHAR', 'UTF-8 native in PostgreSQL' FROM dual
        UNION ALL SELECT 'NUMBER', 'NUMERIC/INTEGER/BIGINT', 'Map based on precision/scale' FROM dual
        UNION ALL SELECT 'NUMBER(p,0)', 'INTEGER/BIGINT/NUMERIC', 'Use INTEGER for p<=9, BIGINT for p<=18' FROM dual
        UNION ALL SELECT 'FLOAT', 'DOUBLE PRECISION', 'Direct mapping' FROM dual
        UNION ALL SELECT 'BINARY_FLOAT', 'REAL', 'Direct mapping' FROM dual
        UNION ALL SELECT 'BINARY_DOUBLE', 'DOUBLE PRECISION', 'Direct mapping' FROM dual
        UNION ALL SELECT 'DATE', 'TIMESTAMP', 'Oracle DATE includes time component' FROM dual
        UNION ALL SELECT 'TIMESTAMP', 'TIMESTAMP', 'Direct mapping' FROM dual
        UNION ALL SELECT 'TIMESTAMP WITH TIME ZONE', 'TIMESTAMPTZ', 'Direct mapping' FROM dual
        UNION ALL SELECT 'TIMESTAMP WITH LOCAL TIME ZONE', 'TIMESTAMPTZ', 'Convert to TIMESTAMPTZ' FROM dual
        UNION ALL SELECT 'INTERVAL YEAR TO MONTH', 'INTERVAL', 'Direct mapping' FROM dual
        UNION ALL SELECT 'INTERVAL DAY TO SECOND', 'INTERVAL', 'Direct mapping' FROM dual
        UNION ALL SELECT 'CLOB', 'TEXT', 'Direct mapping (no size limit)' FROM dual
        UNION ALL SELECT 'NCLOB', 'TEXT', 'Direct mapping' FROM dual
        UNION ALL SELECT 'BLOB', 'BYTEA', 'Direct mapping (1GB limit in PG)' FROM dual
        UNION ALL SELECT 'RAW', 'BYTEA', 'Direct mapping' FROM dual
        UNION ALL SELECT 'LONG', 'TEXT', 'Deprecated in Oracle; use TEXT' FROM dual
        UNION ALL SELECT 'LONG RAW', 'BYTEA', 'Deprecated in Oracle; use BYTEA' FROM dual
        UNION ALL SELECT 'BFILE', 'TEXT (path) + external storage', 'No direct equivalent; store path reference' FROM dual
        UNION ALL SELECT 'ROWID', 'OID or CTID', 'Different implementation; avoid relying on ROWID' FROM dual
        UNION ALL SELECT 'UROWID', 'OID or CTID', 'Different implementation' FROM dual
        UNION ALL SELECT 'XMLTYPE', 'XML', 'Direct mapping' FROM dual
        UNION ALL SELECT 'SDO_GEOMETRY', 'GEOMETRY (PostGIS)', 'Requires PostGIS extension' FROM dual
        UNION ALL SELECT 'JSON', 'JSON or JSONB', 'Use JSONB for indexed queries' FROM dual
    ),
    used_types AS (
        SELECT DISTINCT
            CASE
                WHEN data_type = 'NUMBER' AND data_scale = 0 THEN 'NUMBER(p,0)'
                ELSE data_type
            END AS oracle_type,
            COUNT(*) AS column_count
        FROM dba_tab_columns
        WHERE owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
        GROUP BY
            CASE
                WHEN data_type = 'NUMBER' AND data_scale = 0 THEN 'NUMBER(p,0)'
                ELSE data_type
            END
    )
    SELECT
        u.oracle_type,
        u.column_count,
        NVL(m.pg_type, 'REVIEW REQUIRED') AS postgresql_type,
        NVL(m.conversion_notes, 'Manual conversion may be needed') AS notes
    FROM used_types u
    LEFT JOIN datatype_mapping m ON u.oracle_type = m.oracle_type
    ORDER BY u.column_count DESC
    """


def get_postgresql_plsql_analysis():
    """Analyze PL/SQL code requiring PL/pgSQL conversion for PostgreSQL."""
    return """
    WITH plsql_objects AS (
        SELECT
            object_type,
            COUNT(*) AS object_count,
            SUM(NVL((SELECT SUM(LENGTH(text)) FROM dba_source s
                     WHERE s.owner = o.owner AND s.name = o.object_name AND s.type = o.object_type), 0)) AS total_lines
        FROM dba_objects o
        WHERE object_type IN ('PROCEDURE', 'FUNCTION', 'PACKAGE', 'PACKAGE BODY', 'TRIGGER', 'TYPE', 'TYPE BODY')
        AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
        AND status = 'VALID'
        GROUP BY object_type
    )
    SELECT
        object_type AS "Object Type",
        object_count AS "Count",
        CASE object_type
            WHEN 'PROCEDURE' THEN 'Convert to PL/pgSQL CREATE FUNCTION with RETURNS VOID'
            WHEN 'FUNCTION' THEN 'Convert to PL/pgSQL CREATE FUNCTION'
            WHEN 'PACKAGE' THEN 'Convert to schema + functions or use pg_package extension'
            WHEN 'PACKAGE BODY' THEN 'Convert package procedures/functions individually'
            WHEN 'TRIGGER' THEN 'Convert to PL/pgSQL trigger function + CREATE TRIGGER'
            WHEN 'TYPE' THEN 'Convert to PostgreSQL composite type or domain'
            WHEN 'TYPE BODY' THEN 'Convert methods to standalone functions'
        END AS "Conversion Approach",
        CASE
            WHEN object_type = 'PACKAGE' THEN 'HIGH'
            WHEN object_type = 'PACKAGE BODY' THEN 'HIGH'
            WHEN object_type IN ('TYPE', 'TYPE BODY') THEN 'MEDIUM'
            ELSE 'LOW'
        END AS "Complexity"
    FROM plsql_objects
    ORDER BY object_count DESC
    """


def get_postgresql_syntax_conversion():
    """Check Oracle-specific syntax requiring conversion for PostgreSQL."""
    return """
    SELECT
        syntax_pattern AS "Oracle Syntax",
        postgresql_equivalent AS "PostgreSQL Equivalent",
        conversion_complexity AS "Complexity",
        notes AS "Notes"
    FROM (
        SELECT 'NVL(x, y)' AS syntax_pattern, 'COALESCE(x, y)' AS postgresql_equivalent,
               'LOW' AS conversion_complexity, 'Direct replacement' AS notes FROM dual
        UNION ALL
        SELECT 'NVL2(x, y, z)', 'CASE WHEN x IS NOT NULL THEN y ELSE z END', 'LOW', 'Use CASE expression' FROM dual
        UNION ALL
        SELECT 'DECODE(x, a, b, c, d, e)', 'CASE x WHEN a THEN b WHEN c THEN d ELSE e END', 'LOW', 'Use CASE expression' FROM dual
        UNION ALL
        SELECT 'SYSDATE', 'CURRENT_TIMESTAMP or NOW()', 'LOW', 'Direct replacement' FROM dual
        UNION ALL
        SELECT 'SYSTIMESTAMP', 'CURRENT_TIMESTAMP', 'LOW', 'Direct replacement' FROM dual
        UNION ALL
        SELECT 'ADD_MONTHS(date, n)', 'date + INTERVAL ''n months''', 'LOW', 'Use interval arithmetic' FROM dual
        UNION ALL
        SELECT 'MONTHS_BETWEEN(d1, d2)', 'EXTRACT(YEAR FROM age(d1,d2))*12 + EXTRACT(MONTH FROM age(d1,d2))', 'MEDIUM', 'Custom calculation needed' FROM dual
        UNION ALL
        SELECT 'TRUNC(date)', 'DATE_TRUNC(''day'', timestamp)', 'LOW', 'Function name differs' FROM dual
        UNION ALL
        SELECT 'TO_DATE(str, fmt)', 'TO_TIMESTAMP(str, fmt)::DATE', 'MEDIUM', 'Format codes differ slightly' FROM dual
        UNION ALL
        SELECT 'TO_CHAR(date, fmt)', 'TO_CHAR(timestamp, fmt)', 'MEDIUM', 'Some format codes differ' FROM dual
        UNION ALL
        SELECT 'SUBSTR(str, start, len)', 'SUBSTRING(str FROM start FOR len)', 'LOW', 'Different syntax' FROM dual
        UNION ALL
        SELECT 'INSTR(str, substr)', 'POSITION(substr IN str) or STRPOS(str, substr)', 'LOW', 'Function name differs' FROM dual
        UNION ALL
        SELECT 'CONCAT(a, b) or a || b', 'a || b or CONCAT(a, b)', 'LOW', 'Direct mapping' FROM dual
        UNION ALL
        SELECT 'ROWNUM', 'ROW_NUMBER() OVER() or LIMIT', 'MEDIUM', 'Use window function or LIMIT' FROM dual
        UNION ALL
        SELECT 'CONNECT BY / START WITH', 'WITH RECURSIVE CTE', 'HIGH', 'Rewrite as recursive CTE' FROM dual
        UNION ALL
        SELECT 'SYS_CONNECT_BY_PATH', 'Custom recursive CTE with path', 'HIGH', 'Manual implementation' FROM dual
        UNION ALL
        SELECT 'LEVEL (hierarchical)', 'Depth counter in recursive CTE', 'HIGH', 'Part of CTE rewrite' FROM dual
        UNION ALL
        SELECT 'MINUS', 'EXCEPT', 'LOW', 'Direct replacement' FROM dual
        UNION ALL
        SELECT 'sequences.NEXTVAL', 'NEXTVAL(''sequence_name'')', 'LOW', 'Different syntax' FROM dual
        UNION ALL
        SELECT 'sequences.CURRVAL', 'CURRVAL(''sequence_name'')', 'LOW', 'Different syntax' FROM dual
        UNION ALL
        SELECT 'MERGE statement', 'INSERT ... ON CONFLICT (upsert)', 'MEDIUM', 'Different syntax for upsert' FROM dual
        UNION ALL
        SELECT 'LISTAGG()', 'STRING_AGG()', 'LOW', 'Direct replacement' FROM dual
        UNION ALL
        SELECT 'WM_CONCAT()', 'STRING_AGG()', 'LOW', 'Direct replacement' FROM dual
        UNION ALL
        SELECT 'REGEXP_LIKE()', '~ operator or SIMILAR TO', 'MEDIUM', 'Use PostgreSQL regex operators' FROM dual
        UNION ALL
        SELECT 'REGEXP_SUBSTR()', 'SUBSTRING(str FROM pattern)', 'MEDIUM', 'Different syntax' FROM dual
        UNION ALL
        SELECT '(+) outer join syntax', 'LEFT/RIGHT OUTER JOIN', 'MEDIUM', 'Use ANSI join syntax' FROM dual
    )
    ORDER BY conversion_complexity, syntax_pattern
    """


def get_postgresql_feature_gaps():
    """Check Oracle features with limited or no PostgreSQL equivalent."""
    return """
    WITH feature_usage AS (
        SELECT 'Materialized Views' AS feature,
               (SELECT COUNT(*) FROM dba_mviews WHERE owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')) AS usage_count,
               'Supported' AS pg_support,
               'PostgreSQL supports MVs; refresh syntax differs' AS notes
        FROM dual
        UNION ALL
        SELECT 'Database Links',
               (SELECT COUNT(*) FROM dba_db_links),
               'Partial (postgres_fdw)',
               'Use Foreign Data Wrappers for cross-database queries'
        FROM dual
        UNION ALL
        SELECT 'Synonyms',
               (SELECT COUNT(*) FROM dba_synonyms WHERE owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')),
               'Not Supported',
               'Use schema search_path or views instead'
        FROM dual
        UNION ALL
        SELECT 'Global Temporary Tables',
               (SELECT COUNT(*) FROM dba_tables WHERE temporary = 'Y' AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')),
               'Different Implementation',
               'PostgreSQL temp tables are session-specific by default'
        FROM dual
        UNION ALL
        SELECT 'Bitmap Indexes',
               (SELECT COUNT(*) FROM dba_indexes WHERE index_type = 'BITMAP' AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')),
               'Not Supported',
               'Use GIN/GIST indexes or partial indexes'
        FROM dual
        UNION ALL
        SELECT 'Function-Based Indexes',
               (SELECT COUNT(*) FROM dba_indexes WHERE index_type = 'FUNCTION-BASED NORMAL' AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')),
               'Supported',
               'PostgreSQL supports expression indexes'
        FROM dual
        UNION ALL
        SELECT 'Virtual Columns',
               (SELECT COUNT(*) FROM dba_tab_cols WHERE virtual_column = 'YES' AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')),
               'Supported (PG 12+)',
               'Use GENERATED ALWAYS AS (expression) STORED'
        FROM dual
        UNION ALL
        SELECT 'Advanced Queuing (AQ)',
               (SELECT COUNT(*) FROM dba_queues WHERE owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')),
               'Not Supported',
               'Use pgq extension or external message queue (RabbitMQ, etc.)'
        FROM dual
        UNION ALL
        SELECT 'Oracle Text (Full-Text)',
               (SELECT COUNT(*) FROM dba_indexes WHERE index_type LIKE '%TEXT%' AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')),
               'Supported',
               'PostgreSQL has native full-text search with tsvector/tsquery'
        FROM dual
        UNION ALL
        SELECT 'Spatial (SDO_GEOMETRY)',
               (SELECT COUNT(*) FROM dba_tab_columns WHERE data_type = 'SDO_GEOMETRY'),
               'Supported (PostGIS)',
               'Requires PostGIS extension; excellent spatial support'
        FROM dual
        UNION ALL
        SELECT 'XMLType',
               (SELECT COUNT(*) FROM dba_tab_columns WHERE data_type LIKE '%XML%'),
               'Supported',
               'PostgreSQL has native XML type and functions'
        FROM dual
        UNION ALL
        SELECT 'Partitioning',
               (SELECT COUNT(DISTINCT table_name) FROM dba_tab_partitions WHERE table_owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')),
               'Supported (PG 10+)',
               'PostgreSQL supports range, list, hash partitioning'
        FROM dual
        UNION ALL
        SELECT 'Flashback Query',
               (SELECT CASE WHEN value = 'TRUE' THEN 1 ELSE 0 END FROM v$parameter WHERE name = 'undo_management'),
               'Not Supported',
               'No direct equivalent; consider temporal tables or audit logging'
        FROM dual
        UNION ALL
        SELECT 'Edition-Based Redefinition',
               (SELECT COUNT(*) FROM dba_editions WHERE edition_name != 'ORA$BASE'),
               'Not Supported',
               'Use blue-green deployment or schema versioning'
        FROM dual
        UNION ALL
        SELECT 'Result Cache',
               (SELECT CASE WHEN value != '0' THEN 1 ELSE 0 END FROM v$parameter WHERE name = 'result_cache_max_size'),
               'Not Supported',
               'Use application-level caching (Redis, Memcached)'
        FROM dual
    )
    SELECT feature, usage_count AS "Usage Count", pg_support AS "PostgreSQL Support", notes AS "Migration Notes"
    FROM feature_usage
    WHERE usage_count > 0
    ORDER BY
        CASE pg_support
            WHEN 'Not Supported' THEN 1
            WHEN 'Partial (postgres_fdw)' THEN 2
            WHEN 'Different Implementation' THEN 3
            ELSE 4
        END,
        usage_count DESC
    """


# =============================================================================
# AWS Aurora PostgreSQL Validation Queries
# =============================================================================

def get_aurora_postgresql_compatibility_summary():
    """Generate AWS Aurora PostgreSQL compatibility summary."""
    return """
    WITH compatibility_checks AS (
        SELECT 'Database Size' AS check_item,
               (SELECT TO_CHAR(ROUND(SUM(bytes)/1024/1024/1024, 2)) || ' GB' FROM dba_segments) AS current_value,
               CASE
                   WHEN (SELECT SUM(bytes)/1024/1024/1024 FROM dba_segments) <= 128000 THEN 'PASS'
                   ELSE 'REVIEW'
               END AS status,
               'Aurora supports up to 128TB per cluster' AS notes
        FROM dual
        UNION ALL
        SELECT 'Character Set',
               (SELECT value FROM nls_database_parameters WHERE parameter = 'NLS_CHARACTERSET'),
               CASE
                   WHEN (SELECT value FROM nls_database_parameters WHERE parameter = 'NLS_CHARACTERSET') IN ('AL32UTF8', 'UTF8') THEN 'PASS'
                   ELSE 'REVIEW'
               END,
               'Aurora PostgreSQL uses UTF-8; conversion may be needed'
        FROM dual
        UNION ALL
        SELECT 'PL/SQL Objects',
               (SELECT TO_CHAR(COUNT(*)) FROM dba_objects
                WHERE object_type IN ('PROCEDURE','FUNCTION','PACKAGE','TRIGGER')
                AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')),
               CASE
                   WHEN (SELECT COUNT(*) FROM dba_objects WHERE object_type IN ('PROCEDURE','FUNCTION','PACKAGE','TRIGGER')
                         AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')) > 0 THEN 'REVIEW'
                   ELSE 'PASS'
               END,
               'Requires conversion to PL/pgSQL; use AWS SCT for assistance'
        FROM dual
        UNION ALL
        SELECT 'Tables',
               (SELECT TO_CHAR(COUNT(*)) FROM dba_tables WHERE owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')),
               'PASS',
               'Table structures migrate with schema conversion'
        FROM dual
        UNION ALL
        SELECT 'Sequences',
               (SELECT TO_CHAR(COUNT(*)) FROM dba_sequences WHERE sequence_owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')),
               'PASS',
               'PostgreSQL supports sequences natively'
        FROM dual
        UNION ALL
        SELECT 'Indexes',
               (SELECT TO_CHAR(COUNT(*)) FROM dba_indexes WHERE owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')),
               'REVIEW',
               'Index types may need adjustment (bitmap->GIN, etc.)'
        FROM dual
        UNION ALL
        SELECT 'Database Links',
               (SELECT TO_CHAR(COUNT(*)) FROM dba_db_links),
               CASE WHEN (SELECT COUNT(*) FROM dba_db_links) > 0 THEN 'REVIEW' ELSE 'PASS' END,
               'Use postgres_fdw extension for remote access'
        FROM dual
        UNION ALL
        SELECT 'Synonyms',
               (SELECT TO_CHAR(COUNT(*)) FROM dba_synonyms WHERE owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')),
               CASE WHEN (SELECT COUNT(*) FROM dba_synonyms WHERE owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')) > 0 THEN 'REVIEW' ELSE 'PASS' END,
               'No synonyms in PostgreSQL; use views or search_path'
        FROM dual
        UNION ALL
        SELECT 'Packages',
               (SELECT TO_CHAR(COUNT(*)) FROM dba_objects WHERE object_type = 'PACKAGE' AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')),
               CASE WHEN (SELECT COUNT(*) FROM dba_objects WHERE object_type = 'PACKAGE' AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')) > 0 THEN 'REVIEW' ELSE 'PASS' END,
               'Packages must be decomposed into schemas/functions'
        FROM dual
        UNION ALL
        SELECT 'Hierarchical Queries',
               (SELECT CASE WHEN COUNT(*) > 0 THEN 'Detected' ELSE 'None' END
                FROM dba_source WHERE UPPER(text) LIKE '%CONNECT BY%' AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')),
               CASE WHEN (SELECT COUNT(*) FROM dba_source WHERE UPPER(text) LIKE '%CONNECT BY%' AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')) > 0 THEN 'REVIEW' ELSE 'PASS' END,
               'Rewrite as recursive CTEs'
        FROM dual
    )
    SELECT check_item, current_value, status, notes
    FROM compatibility_checks
    ORDER BY CASE status WHEN 'REVIEW' THEN 1 ELSE 2 END
    """


def get_aurora_postgresql_validation():
    """Detailed validation for AWS Aurora PostgreSQL target."""
    return """
    WITH validation_checks AS (
        SELECT 1 AS seq, 'Compute' AS category, 'Instance Sizing' AS check_item,
               (SELECT TO_CHAR(value) || ' CPUs' FROM v$parameter WHERE name = 'cpu_count') AS current_value,
               'PASS' AS status,
               'Aurora supports up to 96 vCPUs (db.r6g.16xlarge)' AS recommendation
        FROM dual
        UNION ALL
        SELECT 2, 'Compute', 'Memory Requirements',
               (SELECT TO_CHAR(ROUND(value/1024/1024/1024, 2)) || ' GB' FROM v$parameter WHERE name = 'sga_target'),
               CASE WHEN (SELECT value/1024/1024/1024 FROM v$parameter WHERE name = 'sga_target') <= 768 THEN 'PASS' ELSE 'REVIEW' END,
               'Aurora max ~768GB RAM; use serverless for variable workloads'
        FROM dual
        UNION ALL
        SELECT 3, 'Storage', 'Database Size',
               (SELECT TO_CHAR(ROUND(SUM(bytes)/1024/1024/1024, 2)) || ' GB' FROM dba_segments),
               CASE WHEN (SELECT SUM(bytes)/1024/1024/1024 FROM dba_segments) <= 128000 THEN 'PASS' ELSE 'FAIL' END,
               'Aurora max 128TB; storage auto-scales'
        FROM dual
        UNION ALL
        SELECT 4, 'High Availability', 'Multi-AZ',
               'Recommended',
               'PASS',
               'Aurora provides automatic Multi-AZ with up to 15 read replicas'
        FROM dual
        UNION ALL
        SELECT 5, 'Migration Tool', 'AWS SCT',
               'Recommended',
               'PASS',
               'Use AWS Schema Conversion Tool for schema/code conversion'
        FROM dual
        UNION ALL
        SELECT 6, 'Migration Tool', 'AWS DMS',
               'Recommended',
               'PASS',
               'Use AWS Database Migration Service for data migration'
        FROM dual
        UNION ALL
        SELECT 7, 'Extensions', 'PostGIS',
               (SELECT TO_CHAR(COUNT(*)) FROM dba_tab_columns WHERE data_type = 'SDO_GEOMETRY'),
               CASE WHEN (SELECT COUNT(*) FROM dba_tab_columns WHERE data_type = 'SDO_GEOMETRY') > 0 THEN 'REVIEW' ELSE 'PASS' END,
               'Aurora supports PostGIS for spatial data'
        FROM dual
        UNION ALL
        SELECT 8, 'Extensions', 'pg_cron',
               (SELECT TO_CHAR(COUNT(*)) FROM dba_scheduler_jobs WHERE owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')),
               CASE WHEN (SELECT COUNT(*) FROM dba_scheduler_jobs WHERE owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')) > 0 THEN 'REVIEW' ELSE 'PASS' END,
               'Use pg_cron extension for scheduled jobs'
        FROM dual
        UNION ALL
        SELECT 9, 'Performance', 'Query Plan Management',
               'Available',
               'PASS',
               'Aurora supports query plan management similar to SQL profiles'
        FROM dual
        UNION ALL
        SELECT 10, 'Compatibility', 'Babelfish Option',
               'Available',
               'PASS',
               'Consider Babelfish if also migrating SQL Server applications'
        FROM dual
    )
    SELECT category, check_item, current_value, status, recommendation
    FROM validation_checks
    ORDER BY seq
    """


# =============================================================================
# Azure Database for PostgreSQL Validation Queries
# =============================================================================

def get_azure_postgresql_compatibility_summary():
    """Generate Azure Database for PostgreSQL compatibility summary."""
    return """
    WITH compatibility_checks AS (
        SELECT 'Database Size' AS check_item,
               (SELECT TO_CHAR(ROUND(SUM(bytes)/1024/1024/1024, 2)) || ' GB' FROM dba_segments) AS current_value,
               CASE
                   WHEN (SELECT SUM(bytes)/1024/1024/1024 FROM dba_segments) <= 16000 THEN 'PASS'
                   ELSE 'REVIEW'
               END AS status,
               'Flexible Server supports up to 16TB storage' AS notes
        FROM dual
        UNION ALL
        SELECT 'Character Set',
               (SELECT value FROM nls_database_parameters WHERE parameter = 'NLS_CHARACTERSET'),
               CASE
                   WHEN (SELECT value FROM nls_database_parameters WHERE parameter = 'NLS_CHARACTERSET') IN ('AL32UTF8', 'UTF8') THEN 'PASS'
                   ELSE 'REVIEW'
               END,
               'Azure PostgreSQL uses UTF-8 encoding'
        FROM dual
        UNION ALL
        SELECT 'PL/SQL Objects',
               (SELECT TO_CHAR(COUNT(*)) FROM dba_objects
                WHERE object_type IN ('PROCEDURE','FUNCTION','PACKAGE','TRIGGER')
                AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')),
               CASE
                   WHEN (SELECT COUNT(*) FROM dba_objects WHERE object_type IN ('PROCEDURE','FUNCTION','PACKAGE','TRIGGER')
                         AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')) > 0 THEN 'REVIEW'
                   ELSE 'PASS'
               END,
               'Requires PL/pgSQL conversion; use Azure DMS or ora2pg'
        FROM dual
        UNION ALL
        SELECT 'Tables',
               (SELECT TO_CHAR(COUNT(*)) FROM dba_tables WHERE owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')),
               'PASS',
               'Tables migrate with schema conversion tools'
        FROM dual
        UNION ALL
        SELECT 'Sequences',
               (SELECT TO_CHAR(COUNT(*)) FROM dba_sequences WHERE sequence_owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')),
               'PASS',
               'Sequences supported natively'
        FROM dual
        UNION ALL
        SELECT 'Partitioned Tables',
               (SELECT TO_CHAR(COUNT(DISTINCT table_name)) FROM dba_tab_partitions WHERE table_owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')),
               'PASS',
               'PostgreSQL 10+ supports declarative partitioning'
        FROM dual
        UNION ALL
        SELECT 'Materialized Views',
               (SELECT TO_CHAR(COUNT(*)) FROM dba_mviews WHERE owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')),
               'PASS',
               'PostgreSQL supports materialized views'
        FROM dual
        UNION ALL
        SELECT 'Database Links',
               (SELECT TO_CHAR(COUNT(*)) FROM dba_db_links),
               CASE WHEN (SELECT COUNT(*) FROM dba_db_links) > 0 THEN 'REVIEW' ELSE 'PASS' END,
               'Use postgres_fdw or Azure connection options'
        FROM dual
        UNION ALL
        SELECT 'Synonyms',
               (SELECT TO_CHAR(COUNT(*)) FROM dba_synonyms WHERE owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')),
               CASE WHEN (SELECT COUNT(*) FROM dba_synonyms WHERE owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')) > 0 THEN 'REVIEW' ELSE 'PASS' END,
               'Replace with views or schema search_path'
        FROM dual
        UNION ALL
        SELECT 'Advanced Queuing',
               (SELECT TO_CHAR(COUNT(*)) FROM dba_queues WHERE owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')),
               CASE WHEN (SELECT COUNT(*) FROM dba_queues WHERE owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')) > 0 THEN 'REVIEW' ELSE 'PASS' END,
               'Consider Azure Service Bus or pgq extension'
        FROM dual
    )
    SELECT check_item, current_value, status, notes
    FROM compatibility_checks
    ORDER BY CASE status WHEN 'REVIEW' THEN 1 ELSE 2 END
    """


def get_azure_postgresql_validation():
    """Detailed validation for Azure Database for PostgreSQL Flexible Server."""
    return """
    WITH validation_checks AS (
        SELECT 1 AS seq, 'Compute' AS category, 'Compute Tier' AS check_item,
               (SELECT TO_CHAR(value) || ' CPUs' FROM v$parameter WHERE name = 'cpu_count') AS current_value,
               'PASS' AS status,
               CASE
                   WHEN (SELECT value FROM v$parameter WHERE name = 'cpu_count') <= 2 THEN 'Burstable (B-series)'
                   WHEN (SELECT value FROM v$parameter WHERE name = 'cpu_count') <= 16 THEN 'General Purpose (D-series)'
                   ELSE 'Memory Optimized (E-series)'
               END AS recommendation
        FROM dual
        UNION ALL
        SELECT 2, 'Compute', 'Memory Requirements',
               (SELECT TO_CHAR(ROUND(value/1024/1024/1024, 2)) || ' GB' FROM v$parameter WHERE name = 'sga_target'),
               CASE WHEN (SELECT value/1024/1024/1024 FROM v$parameter WHERE name = 'sga_target') <= 672 THEN 'PASS' ELSE 'REVIEW' END,
               'Memory Optimized tier supports up to 672GB RAM'
        FROM dual
        UNION ALL
        SELECT 3, 'Storage', 'Database Size',
               (SELECT TO_CHAR(ROUND(SUM(bytes)/1024/1024/1024, 2)) || ' GB' FROM dba_segments),
               CASE WHEN (SELECT SUM(bytes)/1024/1024/1024 FROM dba_segments) <= 16000 THEN 'PASS' ELSE 'FAIL' END,
               'Flexible Server max 16TB storage'
        FROM dual
        UNION ALL
        SELECT 4, 'Storage', 'IOPS Requirements',
               'Based on workload',
               'REVIEW',
               'Premium SSD supports up to 20,000 IOPS; analyze AWR for requirements'
        FROM dual
        UNION ALL
        SELECT 5, 'High Availability', 'Zone Redundant HA',
               'Recommended',
               'PASS',
               'Enable zone-redundant HA for production workloads'
        FROM dual
        UNION ALL
        SELECT 6, 'Migration Tool', 'Azure DMS',
               'Recommended',
               'PASS',
               'Use Azure Database Migration Service for online migration'
        FROM dual
        UNION ALL
        SELECT 7, 'Migration Tool', 'ora2pg',
               'Recommended',
               'PASS',
               'Use ora2pg for schema conversion and assessment'
        FROM dual
        UNION ALL
        SELECT 8, 'Extensions', 'Available Extensions',
               'PostGIS, pg_stat_statements, etc.',
               'PASS',
               'Azure PostgreSQL supports many extensions including PostGIS'
        FROM dual
        UNION ALL
        SELECT 9, 'Networking', 'Private Link',
               'Recommended',
               'PASS',
               'Use Private Link for secure connectivity from Azure VNet'
        FROM dual
        UNION ALL
        SELECT 10, 'Backup', 'Point-in-Time Recovery',
               (SELECT TO_CHAR(ROUND(SUM(bytes)/1024/1024/1024, 2)) || ' GB' FROM dba_data_files),
               'PASS',
               'Automated backups with up to 35 days retention'
        FROM dual
    )
    SELECT category, check_item, current_value, status, recommendation
    FROM validation_checks
    ORDER BY seq
    """


# =============================================================================
# GCP AlloyDB / Cloud SQL PostgreSQL Validation Queries
# =============================================================================

def get_gcp_postgresql_compatibility_summary():
    """Generate GCP PostgreSQL (AlloyDB and Cloud SQL) compatibility summary."""
    return """
    WITH compatibility_checks AS (
        SELECT 'Database Size' AS check_item,
               (SELECT TO_CHAR(ROUND(SUM(bytes)/1024/1024/1024, 2)) || ' GB' FROM dba_segments) AS current_value,
               CASE
                   WHEN (SELECT SUM(bytes)/1024/1024/1024 FROM dba_segments) <= 64000 THEN 'PASS'
                   ELSE 'REVIEW'
               END AS alloydb_status,
               CASE
                   WHEN (SELECT SUM(bytes)/1024/1024/1024 FROM dba_segments) <= 64000 THEN 'PASS'
                   ELSE 'REVIEW'
               END AS cloudsql_status,
               'AlloyDB: 64TB max; Cloud SQL: 64TB max' AS notes
        FROM dual
        UNION ALL
        SELECT 'Character Set',
               (SELECT value FROM nls_database_parameters WHERE parameter = 'NLS_CHARACTERSET'),
               CASE WHEN (SELECT value FROM nls_database_parameters WHERE parameter = 'NLS_CHARACTERSET') IN ('AL32UTF8','UTF8') THEN 'PASS' ELSE 'REVIEW' END,
               CASE WHEN (SELECT value FROM nls_database_parameters WHERE parameter = 'NLS_CHARACTERSET') IN ('AL32UTF8','UTF8') THEN 'PASS' ELSE 'REVIEW' END,
               'Both use UTF-8 encoding'
        FROM dual
        UNION ALL
        SELECT 'PL/SQL Objects',
               (SELECT TO_CHAR(COUNT(*)) FROM dba_objects
                WHERE object_type IN ('PROCEDURE','FUNCTION','PACKAGE','TRIGGER')
                AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')),
               CASE WHEN (SELECT COUNT(*) FROM dba_objects WHERE object_type IN ('PROCEDURE','FUNCTION','PACKAGE','TRIGGER') AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')) > 0 THEN 'REVIEW' ELSE 'PASS' END,
               CASE WHEN (SELECT COUNT(*) FROM dba_objects WHERE object_type IN ('PROCEDURE','FUNCTION','PACKAGE','TRIGGER') AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')) > 0 THEN 'REVIEW' ELSE 'PASS' END,
               'Requires PL/pgSQL conversion; use ora2pg or Google DMS'
        FROM dual
        UNION ALL
        SELECT 'Tables',
               (SELECT TO_CHAR(COUNT(*)) FROM dba_tables WHERE owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')),
               'PASS',
               'PASS',
               'Table structures migrate with conversion tools'
        FROM dual
        UNION ALL
        SELECT 'Sequences',
               (SELECT TO_CHAR(COUNT(*)) FROM dba_sequences WHERE sequence_owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')),
               'PASS',
               'PASS',
               'Sequences supported natively'
        FROM dual
        UNION ALL
        SELECT 'Materialized Views',
               (SELECT TO_CHAR(COUNT(*)) FROM dba_mviews WHERE owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')),
               'PASS',
               'PASS',
               'PostgreSQL supports materialized views'
        FROM dual
        UNION ALL
        SELECT 'Partitioned Tables',
               (SELECT TO_CHAR(COUNT(DISTINCT table_name)) FROM dba_tab_partitions WHERE table_owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')),
               'PASS',
               'PASS',
               'Both support declarative partitioning'
        FROM dual
        UNION ALL
        SELECT 'Database Links',
               (SELECT TO_CHAR(COUNT(*)) FROM dba_db_links),
               CASE WHEN (SELECT COUNT(*) FROM dba_db_links) > 0 THEN 'REVIEW' ELSE 'PASS' END,
               CASE WHEN (SELECT COUNT(*) FROM dba_db_links) > 0 THEN 'REVIEW' ELSE 'PASS' END,
               'Use postgres_fdw for cross-database queries'
        FROM dual
        UNION ALL
        SELECT 'Synonyms',
               (SELECT TO_CHAR(COUNT(*)) FROM dba_synonyms WHERE owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')),
               CASE WHEN (SELECT COUNT(*) FROM dba_synonyms WHERE owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')) > 0 THEN 'REVIEW' ELSE 'PASS' END,
               CASE WHEN (SELECT COUNT(*) FROM dba_synonyms WHERE owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')) > 0 THEN 'REVIEW' ELSE 'PASS' END,
               'Replace with views or schema search_path'
        FROM dual
        UNION ALL
        SELECT 'OLTP Performance',
               (SELECT TO_CHAR(value) FROM v$parameter WHERE name = 'cpu_count'),
               'PASS',
               'PASS',
               'AlloyDB optimized for OLTP; Cloud SQL for general purpose'
        FROM dual
    )
    SELECT check_item, current_value, alloydb_status AS "AlloyDB", cloudsql_status AS "Cloud SQL", notes
    FROM compatibility_checks
    ORDER BY CASE alloydb_status WHEN 'REVIEW' THEN 1 ELSE 2 END
    """


def get_gcp_alloydb_validation():
    """Detailed validation for Google Cloud AlloyDB for PostgreSQL."""
    return """
    WITH validation_checks AS (
        SELECT 1 AS seq, 'Compute' AS category, 'Instance Sizing' AS check_item,
               (SELECT TO_CHAR(value) || ' CPUs' FROM v$parameter WHERE name = 'cpu_count') AS current_value,
               'PASS' AS status,
               'AlloyDB supports up to 64 vCPUs per instance' AS recommendation
        FROM dual
        UNION ALL
        SELECT 2, 'Compute', 'Memory Requirements',
               (SELECT TO_CHAR(ROUND(value/1024/1024/1024, 2)) || ' GB' FROM v$parameter WHERE name = 'sga_target'),
               CASE WHEN (SELECT value/1024/1024/1024 FROM v$parameter WHERE name = 'sga_target') <= 512 THEN 'PASS' ELSE 'REVIEW' END,
               'AlloyDB supports up to 512GB RAM per instance'
        FROM dual
        UNION ALL
        SELECT 3, 'Storage', 'Database Size',
               (SELECT TO_CHAR(ROUND(SUM(bytes)/1024/1024/1024, 2)) || ' GB' FROM dba_segments),
               CASE WHEN (SELECT SUM(bytes)/1024/1024/1024 FROM dba_segments) <= 64000 THEN 'PASS' ELSE 'REVIEW' END,
               'AlloyDB max 64TB; uses columnar engine for analytics'
        FROM dual
        UNION ALL
        SELECT 4, 'Performance', 'OLTP Workload',
               'Optimized',
               'PASS',
               'AlloyDB provides 4x throughput vs standard PostgreSQL'
        FROM dual
        UNION ALL
        SELECT 5, 'Performance', 'Analytics',
               'Columnar Engine',
               'PASS',
               'Built-in columnar engine for analytical queries (100x faster)'
        FROM dual
        UNION ALL
        SELECT 6, 'High Availability', 'Regional HA',
               'Automatic',
               'PASS',
               'Automatic failover with zero data loss'
        FROM dual
        UNION ALL
        SELECT 7, 'Read Scaling', 'Read Replicas',
               'Up to 20',
               'PASS',
               'Cross-region read replicas available'
        FROM dual
        UNION ALL
        SELECT 8, 'Migration', 'Google DMS',
               'Recommended',
               'PASS',
               'Use Database Migration Service for Oracle to AlloyDB'
        FROM dual
        UNION ALL
        SELECT 9, 'Compatibility', 'PostgreSQL Version',
               '14+',
               'PASS',
               'AlloyDB is PostgreSQL 14+ compatible'
        FROM dual
        UNION ALL
        SELECT 10, 'AI/ML', 'Vertex AI Integration',
               'Available',
               'PASS',
               'Native integration with Vertex AI for ML workloads'
        FROM dual
    )
    SELECT category, check_item, current_value, status, recommendation
    FROM validation_checks
    ORDER BY seq
    """


def get_gcp_cloudsql_postgresql_validation():
    """Detailed validation for Google Cloud SQL for PostgreSQL."""
    return """
    WITH validation_checks AS (
        SELECT 1 AS seq, 'Compute' AS category, 'Machine Type' AS check_item,
               (SELECT TO_CHAR(value) || ' CPUs' FROM v$parameter WHERE name = 'cpu_count') AS current_value,
               'PASS' AS status,
               CASE
                   WHEN (SELECT value FROM v$parameter WHERE name = 'cpu_count') <= 4 THEN 'db-custom-4-15360 or smaller'
                   WHEN (SELECT value FROM v$parameter WHERE name = 'cpu_count') <= 16 THEN 'db-custom-16-61440'
                   WHEN (SELECT value FROM v$parameter WHERE name = 'cpu_count') <= 32 THEN 'db-custom-32-122880'
                   ELSE 'db-custom-96-393216 (max)'
               END AS recommendation
        FROM dual
        UNION ALL
        SELECT 2, 'Compute', 'Memory Requirements',
               (SELECT TO_CHAR(ROUND(value/1024/1024/1024, 2)) || ' GB' FROM v$parameter WHERE name = 'sga_target'),
               CASE WHEN (SELECT value/1024/1024/1024 FROM v$parameter WHERE name = 'sga_target') <= 384 THEN 'PASS' ELSE 'REVIEW' END,
               'Cloud SQL max ~384GB RAM on largest instance'
        FROM dual
        UNION ALL
        SELECT 3, 'Storage', 'Database Size',
               (SELECT TO_CHAR(ROUND(SUM(bytes)/1024/1024/1024, 2)) || ' GB' FROM dba_segments),
               CASE WHEN (SELECT SUM(bytes)/1024/1024/1024 FROM dba_segments) <= 64000 THEN 'PASS' ELSE 'FAIL' END,
               'Cloud SQL max 64TB storage'
        FROM dual
        UNION ALL
        SELECT 4, 'Storage', 'Storage Type',
               (SELECT CASE WHEN SUM(bytes)/1024/1024/1024 > 1000 THEN 'SSD Recommended' ELSE 'SSD or HDD' END FROM dba_segments),
               'PASS',
               'SSD for production; HDD for dev/test'
        FROM dual
        UNION ALL
        SELECT 5, 'High Availability', 'Regional HA',
               'Recommended',
               'PASS',
               'Enable High Availability configuration for production'
        FROM dual
        UNION ALL
        SELECT 6, 'Read Scaling', 'Read Replicas',
               'Available',
               'PASS',
               'Cross-region read replicas supported'
        FROM dual
        UNION ALL
        SELECT 7, 'Migration', 'Google DMS',
               'Recommended',
               'PASS',
               'Use Database Migration Service for migration'
        FROM dual
        UNION ALL
        SELECT 8, 'Extensions', 'PostGIS',
               (SELECT TO_CHAR(COUNT(*)) FROM dba_tab_columns WHERE data_type = 'SDO_GEOMETRY'),
               CASE WHEN (SELECT COUNT(*) FROM dba_tab_columns WHERE data_type = 'SDO_GEOMETRY') > 0 THEN 'REVIEW' ELSE 'PASS' END,
               'PostGIS extension available for spatial data'
        FROM dual
        UNION ALL
        SELECT 9, 'Networking', 'Private IP',
               'Recommended',
               'PASS',
               'Use Private IP for secure VPC connectivity'
        FROM dual
        UNION ALL
        SELECT 10, 'Backup', 'Automated Backups',
               (SELECT TO_CHAR(ROUND(SUM(bytes)/1024/1024/1024, 2)) || ' GB' FROM dba_data_files),
               'PASS',
               'Automated backups with point-in-time recovery'
        FROM dual
    )
    SELECT category, check_item, current_value, status, recommendation
    FROM validation_checks
    ORDER BY seq
    """


# =============================================================================
# Google BigQuery Validation Queries
# =============================================================================

def get_bigquery_compatibility_summary():
    """Generate Google BigQuery compatibility summary for analytics migration."""
    return """
    WITH compatibility_checks AS (
        SELECT 'Database Size' AS check_item,
               (SELECT TO_CHAR(ROUND(SUM(bytes)/1024/1024/1024, 2)) || ' GB' FROM dba_segments) AS current_value,
               'PASS' AS status,
               'BigQuery scales to petabytes; no size limits' AS notes
        FROM dual
        UNION ALL
        SELECT 'Table Count',
               (SELECT TO_CHAR(COUNT(*)) FROM dba_tables WHERE owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')),
               'PASS',
               'Tables migrate as BigQuery tables or views'
        FROM dual
        UNION ALL
        SELECT 'PL/SQL Code',
               (SELECT TO_CHAR(COUNT(*)) FROM dba_objects
                WHERE object_type IN ('PROCEDURE','FUNCTION','PACKAGE','TRIGGER')
                AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')),
               CASE
                   WHEN (SELECT COUNT(*) FROM dba_objects WHERE object_type IN ('PROCEDURE','FUNCTION','PACKAGE','TRIGGER')
                         AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')) > 0 THEN 'REVIEW'
                   ELSE 'PASS'
               END,
               'Convert to BigQuery scripting, UDFs, or external processing'
        FROM dual
        UNION ALL
        SELECT 'Analytical Queries',
               'Ideal Target',
               'PASS',
               'BigQuery excels at large-scale analytical workloads'
        FROM dual
        UNION ALL
        SELECT 'OLTP Transactions',
               (SELECT CASE WHEN COUNT(*) > 100 THEN 'High Volume' ELSE 'Low Volume' END
                FROM v$transaction),
               'REVIEW',
               'BigQuery is not designed for OLTP; consider hybrid approach'
        FROM dual
        UNION ALL
        SELECT 'Sequences',
               (SELECT TO_CHAR(COUNT(*)) FROM dba_sequences WHERE sequence_owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')),
               CASE WHEN (SELECT COUNT(*) FROM dba_sequences WHERE sequence_owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')) > 0 THEN 'REVIEW' ELSE 'PASS' END,
               'BigQuery has no sequences; use GENERATE_UUID() or row numbering'
        FROM dual
        UNION ALL
        SELECT 'Primary Keys',
               (SELECT TO_CHAR(COUNT(*)) FROM dba_constraints WHERE constraint_type = 'P' AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')),
               'REVIEW',
               'BigQuery PKs are for optimization only (not enforced)'
        FROM dual
        UNION ALL
        SELECT 'Foreign Keys',
               (SELECT TO_CHAR(COUNT(*)) FROM dba_constraints WHERE constraint_type = 'R' AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')),
               'REVIEW',
               'BigQuery FKs are informational only (not enforced)'
        FROM dual
        UNION ALL
        SELECT 'Indexes',
               (SELECT TO_CHAR(COUNT(*)) FROM dba_indexes WHERE owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')),
               'N/A',
               'BigQuery auto-optimizes; no traditional indexes needed'
        FROM dual
        UNION ALL
        SELECT 'Partitioning',
               (SELECT TO_CHAR(COUNT(DISTINCT table_name)) FROM dba_tab_partitions WHERE table_owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')),
               'PASS',
               'BigQuery supports time-based and integer range partitioning'
        FROM dual
    )
    SELECT check_item, current_value, status, notes
    FROM compatibility_checks
    ORDER BY CASE status WHEN 'REVIEW' THEN 1 WHEN 'N/A' THEN 3 ELSE 2 END
    """


def get_bigquery_datatype_check():
    """Check Oracle data types and their BigQuery equivalents."""
    return """
    WITH datatype_mapping AS (
        SELECT 'VARCHAR2' AS oracle_type, 'STRING' AS bq_type, 'Direct mapping' AS conversion_notes FROM dual
        UNION ALL SELECT 'NVARCHAR2', 'STRING', 'Direct mapping (UTF-8)' FROM dual
        UNION ALL SELECT 'CHAR', 'STRING', 'Direct mapping' FROM dual
        UNION ALL SELECT 'NCHAR', 'STRING', 'Direct mapping' FROM dual
        UNION ALL SELECT 'NUMBER', 'NUMERIC/INT64/FLOAT64', 'Map based on precision/scale' FROM dual
        UNION ALL SELECT 'NUMBER(p,0)', 'INT64 or NUMERIC', 'Use INT64 for integers up to 64-bit' FROM dual
        UNION ALL SELECT 'FLOAT', 'FLOAT64', 'Direct mapping' FROM dual
        UNION ALL SELECT 'BINARY_FLOAT', 'FLOAT64', 'Direct mapping' FROM dual
        UNION ALL SELECT 'BINARY_DOUBLE', 'FLOAT64', 'Direct mapping' FROM dual
        UNION ALL SELECT 'DATE', 'DATE or DATETIME', 'DATE for date-only; DATETIME if time needed' FROM dual
        UNION ALL SELECT 'TIMESTAMP', 'TIMESTAMP', 'Direct mapping' FROM dual
        UNION ALL SELECT 'TIMESTAMP WITH TIME ZONE', 'TIMESTAMP', 'BigQuery TIMESTAMP is always UTC' FROM dual
        UNION ALL SELECT 'TIMESTAMP WITH LOCAL TIME ZONE', 'TIMESTAMP', 'Convert to UTC' FROM dual
        UNION ALL SELECT 'INTERVAL YEAR TO MONTH', 'INT64 (months)', 'Store as integer months' FROM dual
        UNION ALL SELECT 'INTERVAL DAY TO SECOND', 'INT64 (microseconds)', 'Store as microseconds' FROM dual
        UNION ALL SELECT 'CLOB', 'STRING', 'Direct mapping (10MB limit per cell)' FROM dual
        UNION ALL SELECT 'NCLOB', 'STRING', 'Direct mapping' FROM dual
        UNION ALL SELECT 'BLOB', 'BYTES', 'Direct mapping (10MB limit per cell)' FROM dual
        UNION ALL SELECT 'RAW', 'BYTES', 'Direct mapping' FROM dual
        UNION ALL SELECT 'LONG', 'STRING', 'Direct mapping' FROM dual
        UNION ALL SELECT 'LONG RAW', 'BYTES', 'Direct mapping' FROM dual
        UNION ALL SELECT 'BFILE', 'STRING (GCS path)', 'Store as Cloud Storage URI' FROM dual
        UNION ALL SELECT 'ROWID', 'STRING', 'Store as string if needed' FROM dual
        UNION ALL SELECT 'XMLTYPE', 'STRING', 'Store as string; parse with XPath functions' FROM dual
        UNION ALL SELECT 'SDO_GEOMETRY', 'GEOGRAPHY', 'Use BigQuery GIS functions' FROM dual
        UNION ALL SELECT 'JSON', 'JSON', 'Native JSON type (preview) or STRING' FROM dual
        UNION ALL SELECT 'BOOLEAN', 'BOOL', 'Direct mapping' FROM dual
    ),
    used_types AS (
        SELECT DISTINCT
            CASE
                WHEN data_type = 'NUMBER' AND data_scale = 0 THEN 'NUMBER(p,0)'
                ELSE data_type
            END AS oracle_type,
            COUNT(*) AS column_count
        FROM dba_tab_columns
        WHERE owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
        GROUP BY
            CASE
                WHEN data_type = 'NUMBER' AND data_scale = 0 THEN 'NUMBER(p,0)'
                ELSE data_type
            END
    )
    SELECT
        u.oracle_type,
        u.column_count,
        NVL(m.bq_type, 'STRING (review)') AS bigquery_type,
        NVL(m.conversion_notes, 'Manual review required') AS notes
    FROM used_types u
    LEFT JOIN datatype_mapping m ON u.oracle_type = m.oracle_type
    ORDER BY u.column_count DESC
    """


def get_bigquery_sql_conversion():
    """Check Oracle SQL patterns requiring conversion for BigQuery."""
    return """
    SELECT
        oracle_syntax AS "Oracle Syntax",
        bigquery_equivalent AS "BigQuery Equivalent",
        complexity AS "Complexity",
        notes AS "Notes"
    FROM (
        SELECT 'NVL(x, y)' AS oracle_syntax, 'IFNULL(x, y) or COALESCE(x, y)' AS bigquery_equivalent,
               'LOW' AS complexity, 'Direct replacement' AS notes FROM dual
        UNION ALL
        SELECT 'NVL2(x, y, z)', 'IF(x IS NOT NULL, y, z)', 'LOW', 'Use IF function' FROM dual
        UNION ALL
        SELECT 'DECODE(x, a, b, c, d, e)', 'CASE x WHEN a THEN b WHEN c THEN d ELSE e END', 'LOW', 'Use CASE expression' FROM dual
        UNION ALL
        SELECT 'SYSDATE', 'CURRENT_DATE() or CURRENT_TIMESTAMP()', 'LOW', 'Direct replacement' FROM dual
        UNION ALL
        SELECT 'SYSTIMESTAMP', 'CURRENT_TIMESTAMP()', 'LOW', 'Direct replacement' FROM dual
        UNION ALL
        SELECT 'ADD_MONTHS(date, n)', 'DATE_ADD(date, INTERVAL n MONTH)', 'LOW', 'Use DATE_ADD' FROM dual
        UNION ALL
        SELECT 'MONTHS_BETWEEN(d1, d2)', 'DATE_DIFF(d1, d2, MONTH)', 'LOW', 'Use DATE_DIFF' FROM dual
        UNION ALL
        SELECT 'TRUNC(date)', 'DATE_TRUNC(date, DAY)', 'LOW', 'Use DATE_TRUNC' FROM dual
        UNION ALL
        SELECT 'TO_DATE(str, fmt)', 'PARSE_DATE(fmt, str)', 'MEDIUM', 'Format codes differ' FROM dual
        UNION ALL
        SELECT 'TO_CHAR(date, fmt)', 'FORMAT_DATE(fmt, date)', 'MEDIUM', 'Format codes differ' FROM dual
        UNION ALL
        SELECT 'SUBSTR(str, start, len)', 'SUBSTR(str, start, len)', 'LOW', 'Same syntax' FROM dual
        UNION ALL
        SELECT 'INSTR(str, substr)', 'STRPOS(str, substr)', 'LOW', 'Function name differs' FROM dual
        UNION ALL
        SELECT 'ROWNUM', 'ROW_NUMBER() OVER()', 'MEDIUM', 'Use window function' FROM dual
        UNION ALL
        SELECT 'CONNECT BY / START WITH', 'WITH RECURSIVE (limited)', 'HIGH', 'BigQuery has limited recursive CTE support' FROM dual
        UNION ALL
        SELECT 'MINUS', 'EXCEPT DISTINCT', 'LOW', 'Direct replacement' FROM dual
        UNION ALL
        SELECT 'sequences.NEXTVAL', 'GENERATE_UUID() or ROW_NUMBER()', 'MEDIUM', 'No sequences; use alternatives' FROM dual
        UNION ALL
        SELECT 'MERGE statement', 'MERGE statement', 'LOW', 'BigQuery supports MERGE' FROM dual
        UNION ALL
        SELECT 'LISTAGG()', 'STRING_AGG()', 'LOW', 'Direct replacement' FROM dual
        UNION ALL
        SELECT 'REGEXP_LIKE()', 'REGEXP_CONTAINS()', 'LOW', 'Function name differs' FROM dual
        UNION ALL
        SELECT 'REGEXP_SUBSTR()', 'REGEXP_EXTRACT()', 'LOW', 'Function name differs' FROM dual
        UNION ALL
        SELECT '(+) outer join', 'LEFT/RIGHT OUTER JOIN', 'MEDIUM', 'Use ANSI join syntax' FROM dual
        UNION ALL
        SELECT 'UPDATE with subquery', 'UPDATE with FROM clause or MERGE', 'MEDIUM', 'Different syntax for complex updates' FROM dual
        UNION ALL
        SELECT 'DELETE with subquery', 'DELETE with WHERE EXISTS', 'MEDIUM', 'Standard SQL syntax' FROM dual
        UNION ALL
        SELECT 'PIVOT/UNPIVOT', 'PIVOT/UNPIVOT', 'LOW', 'BigQuery supports PIVOT/UNPIVOT' FROM dual
    )
    ORDER BY complexity, oracle_syntax
    """


def get_bigquery_feature_assessment():
    """Assess Oracle features and their BigQuery alternatives."""
    return """
    WITH feature_assessment AS (
        SELECT 'Stored Procedures' AS feature,
               TO_CHAR((SELECT COUNT(*) FROM dba_procedures WHERE object_type = 'PROCEDURE' AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB'))) AS usage_count,
               'Supported' AS bq_support,
               'BigQuery supports scripting and stored procedures' AS notes
        FROM dual
        UNION ALL
        SELECT 'User-Defined Functions',
               TO_CHAR((SELECT COUNT(*) FROM dba_procedures WHERE object_type = 'FUNCTION' AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB'))),
               'Supported',
               'BigQuery supports JavaScript, SQL, and remote UDFs'
        FROM dual
        UNION ALL
        SELECT 'Triggers',
               TO_CHAR((SELECT COUNT(*) FROM dba_triggers WHERE owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB'))),
               'Not Supported',
               'Use Cloud Functions with BigQuery event triggers instead'
        FROM dual
        UNION ALL
        SELECT 'Materialized Views',
               TO_CHAR((SELECT COUNT(*) FROM dba_mviews WHERE owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB'))),
               'Supported',
               'BigQuery supports materialized views with auto-refresh'
        FROM dual
        UNION ALL
        SELECT 'Partitioning',
               TO_CHAR((SELECT COUNT(DISTINCT table_name) FROM dba_tab_partitions WHERE table_owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB'))),
               'Supported',
               'Time-based, integer range, and ingestion-time partitioning'
        FROM dual
        UNION ALL
        SELECT 'Clustering',
               TO_CHAR((SELECT COUNT(*) FROM dba_indexes WHERE index_type = 'CLUSTER' AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB'))),
               'Supported',
               'BigQuery clustering replaces some index use cases'
        FROM dual
        UNION ALL
        SELECT 'Window Functions',
               'Common',
               'Supported',
               'Full support for analytical/window functions'
        FROM dual
        UNION ALL
        SELECT 'Transactions (DML)',
               'OLTP Pattern',
               'Limited',
               'BigQuery supports multi-statement transactions but not OLTP'
        FROM dual
        UNION ALL
        SELECT 'Row-Level Security',
               TO_CHAR((SELECT COUNT(*) FROM dba_policies WHERE object_owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB'))),
               'Supported',
               'BigQuery supports row-level security policies'
        FROM dual
        UNION ALL
        SELECT 'Column-Level Security',
               'VPD/Masking',
               'Supported',
               'Use policy tags for column-level access control'
        FROM dual
        UNION ALL
        SELECT 'Geospatial (SDO_GEOMETRY)',
               TO_CHAR((SELECT COUNT(*) FROM dba_tab_columns WHERE data_type = 'SDO_GEOMETRY')),
               'Supported',
               'BigQuery GIS with GEOGRAPHY type and spatial functions'
        FROM dual
        UNION ALL
        SELECT 'JSON Processing',
               TO_CHAR((SELECT COUNT(*) FROM dba_tab_columns WHERE data_type LIKE '%JSON%')),
               'Supported',
               'Native JSON type and JSON functions'
        FROM dual
        UNION ALL
        SELECT 'Machine Learning',
               'External',
               'Native (BQML)',
               'BigQuery ML enables ML directly in SQL'
        FROM dual
        UNION ALL
        SELECT 'Data Sharing',
               'DB Links',
               'Native',
               'Analytics Hub for secure data sharing'
        FROM dual
    )
    SELECT feature, usage_count AS "Oracle Usage", bq_support AS "BigQuery Support", notes AS "Migration Notes"
    FROM feature_assessment
    ORDER BY
        CASE bq_support
            WHEN 'Not Supported' THEN 1
            WHEN 'Limited' THEN 2
            ELSE 3
        END,
        feature
    """


def get_bigquery_validation():
    """Detailed validation for Google BigQuery migration."""
    return """
    WITH validation_checks AS (
        SELECT 1 AS seq, 'Data Volume' AS category, 'Total Size' AS check_item,
               (SELECT TO_CHAR(ROUND(SUM(bytes)/1024/1024/1024, 2)) || ' GB' FROM dba_segments) AS current_value,
               'PASS' AS status,
               'BigQuery handles petabyte-scale data' AS recommendation
        FROM dual
        UNION ALL
        SELECT 2, 'Data Volume', 'Daily Growth Estimate',
               'Requires AWR analysis',
               'REVIEW',
               'BigQuery pricing based on storage and queries'
        FROM dual
        UNION ALL
        SELECT 3, 'Workload Type', 'Analytics Suitability',
               'Assess workload',
               'REVIEW',
               'BigQuery ideal for analytics; not for OLTP'
        FROM dual
        UNION ALL
        SELECT 4, 'Migration', 'BigQuery Data Transfer Service',
               'Available',
               'PASS',
               'Use BQDTS for scheduled data loads'
        FROM dual
        UNION ALL
        SELECT 5, 'Migration', 'Dataflow',
               'Available',
               'PASS',
               'Use Dataflow for complex ETL transformations'
        FROM dual
        UNION ALL
        SELECT 6, 'Migration', 'Federation Option',
               'Available',
               'PASS',
               'BigQuery can query Cloud SQL directly via federation'
        FROM dual
        UNION ALL
        SELECT 7, 'Cost Model', 'Storage Pricing',
               (SELECT TO_CHAR(ROUND(SUM(bytes)/1024/1024/1024/1024, 4)) || ' TB' FROM dba_segments),
               'PASS',
               '$0.02/GB/month active; $0.01/GB/month long-term'
        FROM dual
        UNION ALL
        SELECT 8, 'Cost Model', 'Query Pricing',
               'On-demand or Capacity',
               'REVIEW',
               'On-demand: $5/TB scanned; Slots: flat-rate capacity'
        FROM dual
        UNION ALL
        SELECT 9, 'Security', 'Encryption',
               'Default',
               'PASS',
               'Data encrypted at rest and in transit by default'
        FROM dual
        UNION ALL
        SELECT 10, 'Integration', 'BI Tools',
               'Looker, Data Studio, etc.',
               'PASS',
               'Native integration with Google BI tools; ODBC/JDBC available'
        FROM dual
    )
    SELECT category, check_item, current_value, status, recommendation
    FROM validation_checks
    ORDER BY seq
    """


# =============================================================================
# Microsoft Synapse Analytics Validation Queries
# =============================================================================

def get_synapse_compatibility_summary():
    """Generate Microsoft Synapse Analytics compatibility summary."""
    return """
    WITH compatibility_checks AS (
        SELECT 'Database Size' AS check_item,
               (SELECT TO_CHAR(ROUND(SUM(bytes)/1024/1024/1024, 2)) || ' GB' FROM dba_segments) AS current_value,
               CASE
                   WHEN (SELECT SUM(bytes)/1024/1024/1024/1024 FROM dba_segments) <= 240 THEN 'PASS'
                   ELSE 'REVIEW'
               END AS status,
               'Synapse dedicated SQL pool max 240TB compressed' AS notes
        FROM dual
        UNION ALL
        SELECT 'Character Set',
               (SELECT value FROM nls_database_parameters WHERE parameter = 'NLS_CHARACTERSET'),
               CASE WHEN (SELECT value FROM nls_database_parameters WHERE parameter = 'NLS_CHARACTERSET')
                    IN ('AL32UTF8', 'UTF8', 'WE8MSWIN1252', 'WE8ISO8859P1') THEN 'PASS'
                    ELSE 'REVIEW'
               END,
               'Synapse uses UTF-8 or Windows collations'
        FROM dual
        UNION ALL
        SELECT 'Table Count',
               (SELECT TO_CHAR(COUNT(*)) FROM dba_tables WHERE owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')),
               CASE
                   WHEN (SELECT COUNT(*) FROM dba_tables WHERE owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')) <= 60000 THEN 'PASS'
                   ELSE 'REVIEW'
               END,
               'Synapse supports up to 60,000 tables per database'
        FROM dual
        UNION ALL
        SELECT 'PL/SQL Objects',
               (SELECT TO_CHAR(COUNT(*)) FROM dba_objects
                WHERE object_type IN ('PROCEDURE','FUNCTION','PACKAGE','PACKAGE BODY','TRIGGER')
                AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')),
               CASE WHEN (SELECT COUNT(*) FROM dba_objects
                          WHERE object_type IN ('PROCEDURE','FUNCTION','PACKAGE','PACKAGE BODY','TRIGGER')
                          AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')) > 0 THEN 'REVIEW'
                    ELSE 'PASS'
               END,
               'Requires T-SQL conversion; limited stored procedure support in Synapse'
        FROM dual
        UNION ALL
        SELECT 'Materialized Views',
               (SELECT TO_CHAR(COUNT(*)) FROM dba_mviews WHERE owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')),
               CASE WHEN (SELECT COUNT(*) FROM dba_mviews WHERE owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')) > 0 THEN 'PASS'
                    ELSE 'PASS'
               END,
               'Synapse supports materialized views with automatic refresh'
        FROM dual
        UNION ALL
        SELECT 'Database Links',
               (SELECT TO_CHAR(COUNT(*)) FROM dba_db_links),
               CASE WHEN (SELECT COUNT(*) FROM dba_db_links) > 0 THEN 'REVIEW'
                    ELSE 'PASS'
               END,
               'Use external tables or PolyBase for cross-database queries'
        FROM dual
        UNION ALL
        SELECT 'Partitioned Tables',
               (SELECT TO_CHAR(COUNT(DISTINCT table_name)) FROM dba_tab_partitions
                WHERE table_owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')),
               'PASS',
               'Synapse supports table partitioning up to 15,000 partitions'
        FROM dual
        UNION ALL
        SELECT 'LOB Columns',
               (SELECT TO_CHAR(COUNT(*)) FROM dba_tab_columns
                WHERE data_type IN ('CLOB','BLOB','NCLOB','LONG','LONG RAW','BFILE')
                AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')),
               CASE WHEN (SELECT COUNT(*) FROM dba_tab_columns
                          WHERE data_type IN ('CLOB','BLOB','NCLOB','LONG','LONG RAW','BFILE')
                          AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')) > 0 THEN 'WARNING'
                    ELSE 'PASS'
               END,
               'VARCHAR(MAX)/VARBINARY(MAX) limited in clustered columnstore; consider separate row store'
        FROM dual
    )
    SELECT check_item, current_value, status, notes
    FROM compatibility_checks
    ORDER BY CASE status WHEN 'REVIEW' THEN 1 WHEN 'WARNING' THEN 2 ELSE 3 END
    """


def get_synapse_datatype_check():
    """Check Oracle data types for Synapse compatibility and mapping."""
    return """
    WITH datatype_mapping AS (
        SELECT owner, table_name, column_name, data_type,
               CASE data_type
                   WHEN 'VARCHAR2' THEN 'VARCHAR/NVARCHAR (max 8000)'
                   WHEN 'NVARCHAR2' THEN 'NVARCHAR (max 4000)'
                   WHEN 'CHAR' THEN 'CHAR (max 8000)'
                   WHEN 'NCHAR' THEN 'NCHAR (max 4000)'
                   WHEN 'NUMBER' THEN 'DECIMAL/NUMERIC/BIGINT/INT/SMALLINT'
                   WHEN 'FLOAT' THEN 'FLOAT'
                   WHEN 'BINARY_FLOAT' THEN 'REAL'
                   WHEN 'BINARY_DOUBLE' THEN 'FLOAT'
                   WHEN 'DATE' THEN 'DATETIME2'
                   WHEN 'TIMESTAMP' THEN 'DATETIME2'
                   WHEN 'TIMESTAMP WITH TIME ZONE' THEN 'DATETIMEOFFSET'
                   WHEN 'TIMESTAMP WITH LOCAL TIME ZONE' THEN 'DATETIME2'
                   WHEN 'INTERVAL YEAR TO MONTH' THEN 'VARCHAR (manual handling)'
                   WHEN 'INTERVAL DAY TO SECOND' THEN 'VARCHAR (manual handling)'
                   WHEN 'CLOB' THEN 'VARCHAR(MAX) - review for columnstore'
                   WHEN 'NCLOB' THEN 'NVARCHAR(MAX) - review for columnstore'
                   WHEN 'BLOB' THEN 'VARBINARY(MAX) - review for columnstore'
                   WHEN 'LONG' THEN 'VARCHAR(MAX) - CRITICAL: deprecated'
                   WHEN 'LONG RAW' THEN 'VARBINARY(MAX) - CRITICAL: deprecated'
                   WHEN 'RAW' THEN 'VARBINARY'
                   WHEN 'BFILE' THEN 'NOT SUPPORTED - use Azure Blob Storage'
                   WHEN 'ROWID' THEN 'NOT SUPPORTED - use surrogate key'
                   WHEN 'UROWID' THEN 'NOT SUPPORTED - use surrogate key'
                   WHEN 'XMLTYPE' THEN 'NVARCHAR(MAX) - limited XML support'
                   WHEN 'SDO_GEOMETRY' THEN 'GEOGRAPHY/GEOMETRY - limited support'
                   ELSE 'REVIEW: ' || data_type
               END AS synapse_type,
               CASE
                   WHEN data_type IN ('BFILE','ROWID','UROWID') THEN 'CRITICAL'
                   WHEN data_type IN ('LONG','LONG RAW') THEN 'CRITICAL'
                   WHEN data_type IN ('CLOB','NCLOB','BLOB') THEN 'WARNING'
                   WHEN data_type IN ('XMLTYPE','SDO_GEOMETRY') THEN 'WARNING'
                   WHEN data_type LIKE 'INTERVAL%' THEN 'WARNING'
                   ELSE 'OK'
               END AS migration_status
        FROM dba_tab_columns
        WHERE owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
    )
    SELECT owner AS schema_name,
           data_type AS oracle_type,
           synapse_type,
           migration_status,
           COUNT(*) AS column_count
    FROM datatype_mapping
    GROUP BY owner, data_type, synapse_type, migration_status
    ORDER BY CASE migration_status WHEN 'CRITICAL' THEN 1 WHEN 'WARNING' THEN 2 ELSE 3 END, column_count DESC
    """


def get_synapse_plsql_analysis():
    """Analyze PL/SQL objects requiring T-SQL conversion for Synapse."""
    return """
    WITH plsql_objects AS (
        SELECT owner, object_type, object_name, status,
               CASE object_type
                   WHEN 'PACKAGE' THEN 'CRITICAL - No package support; convert to individual procedures'
                   WHEN 'PACKAGE BODY' THEN 'CRITICAL - No package support; convert to individual procedures'
                   WHEN 'PROCEDURE' THEN 'WARNING - Limited procedure support; consider ADF/Synapse Pipelines'
                   WHEN 'FUNCTION' THEN 'WARNING - Limited function support; consider inline T-SQL'
                   WHEN 'TRIGGER' THEN 'CRITICAL - No trigger support in Synapse dedicated pools'
                   WHEN 'TYPE' THEN 'CRITICAL - No user-defined types; convert to tables'
                   WHEN 'TYPE BODY' THEN 'CRITICAL - No user-defined types; convert to tables'
                   ELSE 'REVIEW'
               END AS conversion_notes,
               CASE object_type
                   WHEN 'PACKAGE' THEN 1
                   WHEN 'PACKAGE BODY' THEN 1
                   WHEN 'TRIGGER' THEN 1
                   WHEN 'TYPE' THEN 1
                   WHEN 'TYPE BODY' THEN 1
                   WHEN 'PROCEDURE' THEN 2
                   WHEN 'FUNCTION' THEN 2
                   ELSE 3
               END AS severity
        FROM dba_objects
        WHERE object_type IN ('PROCEDURE','FUNCTION','PACKAGE','PACKAGE BODY','TRIGGER','TYPE','TYPE BODY')
        AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
    )
    SELECT owner AS schema_name,
           object_type,
           COUNT(*) AS object_count,
           MAX(conversion_notes) AS conversion_notes,
           SUM(CASE WHEN status = 'INVALID' THEN 1 ELSE 0 END) AS invalid_count
    FROM plsql_objects
    GROUP BY owner, object_type, severity
    ORDER BY severity, object_count DESC
    """


def get_synapse_syntax_conversion():
    """Identify Oracle-specific SQL syntax requiring conversion for Synapse."""
    return """
    WITH syntax_patterns AS (
        SELECT 'Outer Join (+)' AS pattern_name,
               (SELECT COUNT(*) FROM dba_source
                WHERE REGEXP_LIKE(text, '\\(\\+\\)')
                AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')) AS occurrence_count,
               'Convert to ANSI JOIN syntax (LEFT/RIGHT JOIN)' AS conversion_action,
               'WARNING' AS severity
        FROM dual
        UNION ALL
        SELECT 'CONNECT BY (Hierarchical)',
               (SELECT COUNT(*) FROM dba_source
                WHERE UPPER(text) LIKE '%CONNECT BY%'
                AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')),
               'Convert to recursive CTE (WITH RECURSIVE)',
               'CRITICAL'
        FROM dual
        UNION ALL
        SELECT 'ROWNUM Pseudo-column',
               (SELECT COUNT(*) FROM dba_source
                WHERE UPPER(text) LIKE '%ROWNUM%'
                AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')),
               'Convert to ROW_NUMBER() OVER() or TOP',
               'WARNING'
        FROM dual
        UNION ALL
        SELECT 'NVL Function',
               (SELECT COUNT(*) FROM dba_source
                WHERE UPPER(text) LIKE '%NVL(%'
                AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')),
               'Convert to ISNULL() or COALESCE()',
               'INFO'
        FROM dual
        UNION ALL
        SELECT 'NVL2 Function',
               (SELECT COUNT(*) FROM dba_source
                WHERE UPPER(text) LIKE '%NVL2(%'
                AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')),
               'Convert to CASE expression or IIF()',
               'INFO'
        FROM dual
        UNION ALL
        SELECT 'DECODE Function',
               (SELECT COUNT(*) FROM dba_source
                WHERE UPPER(text) LIKE '%DECODE(%'
                AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')),
               'Convert to CASE expression',
               'INFO'
        FROM dual
        UNION ALL
        SELECT 'SYSDATE',
               (SELECT COUNT(*) FROM dba_source
                WHERE UPPER(text) LIKE '%SYSDATE%'
                AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')),
               'Convert to GETDATE() or SYSDATETIME()',
               'INFO'
        FROM dual
        UNION ALL
        SELECT 'DUAL Table',
               (SELECT COUNT(*) FROM dba_source
                WHERE UPPER(text) LIKE '%FROM DUAL%'
                AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')),
               'Remove FROM DUAL (not needed in T-SQL)',
               'INFO'
        FROM dual
        UNION ALL
        SELECT 'Sequences (NEXTVAL/CURRVAL)',
               (SELECT COUNT(*) FROM dba_source
                WHERE REGEXP_LIKE(UPPER(text), '\\.(NEXTVAL|CURRVAL)')
                AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')),
               'Convert to NEXT VALUE FOR sequence_name',
               'WARNING'
        FROM dual
        UNION ALL
        SELECT 'Oracle Hints',
               (SELECT COUNT(*) FROM dba_source
                WHERE REGEXP_LIKE(text, '/\\*\\+.*\\*/')
                AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')),
               'Remove or convert to Synapse-specific hints (OPTION)',
               'WARNING'
        FROM dual
        UNION ALL
        SELECT 'MERGE Statement',
               (SELECT COUNT(*) FROM dba_source
                WHERE UPPER(text) LIKE '%MERGE INTO%'
                AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')),
               'Synapse supports MERGE but no OUTPUT clause',
               'INFO'
        FROM dual
        UNION ALL
        SELECT 'BULK COLLECT',
               (SELECT COUNT(*) FROM dba_source
                WHERE UPPER(text) LIKE '%BULK COLLECT%'
                AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')),
               'Not supported - use set-based operations',
               'CRITICAL'
        FROM dual
        UNION ALL
        SELECT 'FORALL Statement',
               (SELECT COUNT(*) FROM dba_source
                WHERE UPPER(text) LIKE '%FORALL%'
                AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')),
               'Not supported - use set-based operations',
               'CRITICAL'
        FROM dual
    )
    SELECT pattern_name, occurrence_count, conversion_action, severity
    FROM syntax_patterns
    WHERE occurrence_count > 0
    ORDER BY CASE severity WHEN 'CRITICAL' THEN 1 WHEN 'WARNING' THEN 2 ELSE 3 END, occurrence_count DESC
    """


def get_synapse_feature_gaps():
    """Identify Oracle features with limited or no Synapse equivalent."""
    return """
    WITH feature_checks AS (
        SELECT 'Foreign Keys' AS feature,
               (SELECT COUNT(*) FROM dba_constraints
                WHERE constraint_type = 'R'
                AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')) AS usage_count,
               'WARNING' AS status,
               'Synapse: Informational only, not enforced; ensure application handles referential integrity' AS notes
        FROM dual
        UNION ALL
        SELECT 'Unique Constraints',
               (SELECT COUNT(*) FROM dba_constraints
                WHERE constraint_type = 'U'
                AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')),
               'WARNING',
               'Synapse: Not enforced on columnstore indexes; consider primary key or application logic'
        FROM dual
        UNION ALL
        SELECT 'Check Constraints',
               (SELECT COUNT(*) FROM dba_constraints
                WHERE constraint_type = 'C'
                AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')),
               'WARNING',
               'Synapse: Not enforced; move validation to ETL pipeline or application'
        FROM dual
        UNION ALL
        SELECT 'Bitmap Indexes',
               (SELECT COUNT(*) FROM dba_indexes
                WHERE index_type = 'BITMAP'
                AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')),
               CASE WHEN (SELECT COUNT(*) FROM dba_indexes WHERE index_type = 'BITMAP' AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')) > 0
                    THEN 'INFO' ELSE 'PASS' END,
               'Synapse uses columnstore compression; bitmap indexes not needed'
        FROM dual
        UNION ALL
        SELECT 'Function-Based Indexes',
               (SELECT COUNT(*) FROM dba_indexes
                WHERE index_type = 'FUNCTION-BASED NORMAL'
                AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')),
               CASE WHEN (SELECT COUNT(*) FROM dba_indexes WHERE index_type = 'FUNCTION-BASED NORMAL' AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')) > 0
                    THEN 'WARNING' ELSE 'PASS' END,
               'Not supported in Synapse; consider computed columns or materialized views'
        FROM dual
        UNION ALL
        SELECT 'Global Temporary Tables',
               (SELECT COUNT(*) FROM dba_tables
                WHERE temporary = 'Y'
                AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')),
               CASE WHEN (SELECT COUNT(*) FROM dba_tables WHERE temporary = 'Y' AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')) > 0
                    THEN 'WARNING' ELSE 'PASS' END,
               'Synapse supports local temp tables (#table); global temp tables behave differently'
        FROM dual
        UNION ALL
        SELECT 'Database Links',
               (SELECT COUNT(*) FROM dba_db_links),
               CASE WHEN (SELECT COUNT(*) FROM dba_db_links) > 0 THEN 'WARNING' ELSE 'PASS' END,
               'Use external tables, PolyBase, or Azure Data Factory for cross-database access'
        FROM dual
        UNION ALL
        SELECT 'Synonyms',
               (SELECT COUNT(*) FROM dba_synonyms
                WHERE owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')),
               CASE WHEN (SELECT COUNT(*) FROM dba_synonyms WHERE owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')) > 0
                    THEN 'WARNING' ELSE 'PASS' END,
               'Synapse supports synonyms in dedicated SQL pools'
        FROM dual
        UNION ALL
        SELECT 'Virtual Private Database (VPD)',
               (SELECT COUNT(*) FROM dba_policies),
               CASE WHEN (SELECT COUNT(*) FROM dba_policies) > 0 THEN 'CRITICAL' ELSE 'PASS' END,
               'Not supported; implement row-level security using Synapse RLS or views'
        FROM dual
        UNION ALL
        SELECT 'Advanced Queuing (AQ)',
               (SELECT COUNT(*) FROM dba_queues WHERE owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')),
               CASE WHEN (SELECT COUNT(*) FROM dba_queues WHERE owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')) > 0
                    THEN 'CRITICAL' ELSE 'PASS' END,
               'Not supported; use Azure Service Bus or Event Hubs'
        FROM dual
        UNION ALL
        SELECT 'Oracle Text Indexes',
               (SELECT COUNT(*) FROM dba_indexes
                WHERE index_type LIKE '%TEXT%' OR ityp_name LIKE '%TEXT%'),
               CASE WHEN (SELECT COUNT(*) FROM dba_indexes WHERE index_type LIKE '%TEXT%') > 0
                    THEN 'WARNING' ELSE 'PASS' END,
               'Not supported; use Azure Cognitive Search or full-text in Azure SQL'
        FROM dual
        UNION ALL
        SELECT 'XML Indexes',
               (SELECT COUNT(*) FROM dba_indexes
                WHERE index_type = 'XMLINDEX'),
               CASE WHEN (SELECT COUNT(*) FROM dba_indexes WHERE index_type = 'XMLINDEX') > 0
                    THEN 'WARNING' ELSE 'PASS' END,
               'Limited XML support in Synapse; consider shredding XML to relational'
        FROM dual
    )
    SELECT feature, usage_count, status, notes
    FROM feature_checks
    WHERE usage_count > 0 OR status != 'PASS'
    ORDER BY CASE status WHEN 'CRITICAL' THEN 1 WHEN 'WARNING' THEN 2 ELSE 3 END, usage_count DESC
    """


def get_synapse_distribution_analysis():
    """Analyze tables for Synapse distribution strategy recommendations."""
    return """
    WITH table_stats AS (
        SELECT t.owner,
               t.table_name,
               t.num_rows,
               s.bytes/1024/1024 AS size_mb,
               (SELECT COUNT(*) FROM dba_constraints c
                WHERE c.owner = t.owner AND c.table_name = t.table_name
                AND c.constraint_type = 'R') AS fk_count,
               (SELECT COUNT(*) FROM dba_constraints c
                WHERE c.owner = t.owner AND c.table_name = t.table_name
                AND c.constraint_type = 'P') AS pk_count,
               (SELECT COUNT(DISTINCT table_name) FROM dba_constraints c
                WHERE c.r_owner = t.owner
                AND c.r_constraint_name IN (SELECT constraint_name FROM dba_constraints
                                            WHERE owner = t.owner AND table_name = t.table_name
                                            AND constraint_type = 'P')) AS referenced_by_count
        FROM dba_tables t
        LEFT JOIN dba_segments s ON t.owner = s.owner AND t.table_name = s.segment_name
        WHERE t.owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
        AND t.table_name NOT LIKE 'BIN$%'
    )
    SELECT owner AS schema_name,
           table_name,
           NVL(num_rows, 0) AS row_count,
           ROUND(NVL(size_mb, 0), 2) AS size_mb,
           CASE
               WHEN NVL(size_mb, 0) < 60 AND referenced_by_count > 2 THEN 'REPLICATE'
               WHEN NVL(size_mb, 0) < 60 AND NVL(num_rows, 0) < 60000 THEN 'REPLICATE'
               WHEN NVL(num_rows, 0) > 60000000 THEN 'HASH'
               WHEN NVL(size_mb, 0) > 1000 THEN 'HASH'
               WHEN fk_count = 0 AND referenced_by_count = 0 THEN 'ROUND_ROBIN'
               ELSE 'HASH'
           END AS recommended_distribution,
           CASE
               WHEN NVL(size_mb, 0) < 60 AND referenced_by_count > 2 THEN 'Small dimension table referenced by multiple facts'
               WHEN NVL(size_mb, 0) < 60 AND NVL(num_rows, 0) < 60000 THEN 'Small table - replicate for join performance'
               WHEN NVL(num_rows, 0) > 60000000 THEN 'Large fact table - hash for parallel processing'
               WHEN NVL(size_mb, 0) > 1000 THEN 'Large table - hash distribution recommended'
               WHEN fk_count = 0 AND referenced_by_count = 0 THEN 'Staging/isolated table - round robin for load speed'
               ELSE 'Standard table - hash on frequently joined column'
           END AS recommendation_reason,
           CASE
               WHEN pk_count > 0 THEN 'Primary key column'
               ELSE 'Identify high-cardinality column for distribution'
           END AS distribution_key_suggestion
    FROM table_stats
    WHERE NVL(size_mb, 0) > 0
    ORDER BY size_mb DESC NULLS LAST
    FETCH FIRST 100 ROWS ONLY
    """


def get_synapse_validation_detail():
    """Detailed validation checklist for Synapse migration readiness."""
    return """
    WITH validation_checks AS (
        SELECT 1 AS seq, 'Compute' AS category, 'Estimated DWU Requirement' AS check_item,
               (SELECT
                   CASE
                       WHEN SUM(bytes)/1024/1024/1024/1024 < 1 THEN 'DW100c-DW500c'
                       WHEN SUM(bytes)/1024/1024/1024/1024 < 10 THEN 'DW500c-DW1000c'
                       WHEN SUM(bytes)/1024/1024/1024/1024 < 50 THEN 'DW1000c-DW3000c'
                       WHEN SUM(bytes)/1024/1024/1024/1024 < 100 THEN 'DW3000c-DW6000c'
                       ELSE 'DW6000c-DW30000c'
                   END
                FROM dba_segments) AS current_value,
               'PASS' AS status,
               'Start small and scale based on actual workload' AS recommendation
        FROM dual
        UNION ALL
        SELECT 2, 'Storage', 'Columnstore Compatibility',
               (SELECT TO_CHAR(COUNT(*)) || ' LOB columns'
                FROM dba_tab_columns
                WHERE data_type IN ('CLOB','BLOB','NCLOB','LONG','LONG RAW')
                AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')),
               CASE WHEN (SELECT COUNT(*) FROM dba_tab_columns
                          WHERE data_type IN ('CLOB','BLOB','NCLOB','LONG','LONG RAW')
                          AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')) > 0 THEN 'WARNING' ELSE 'PASS' END,
               'LOB columns require heap or row store tables instead of columnstore'
        FROM dual
        UNION ALL
        SELECT 3, 'Schema', 'Table Partitioning Review',
               (SELECT TO_CHAR(COUNT(DISTINCT table_name)) || ' partitioned tables'
                FROM dba_tab_partitions WHERE table_owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')),
               'PASS',
               'Synapse supports up to 15,000 partitions per table'
        FROM dual
        UNION ALL
        SELECT 4, 'Schema', 'Statistics Requirements',
               (SELECT TO_CHAR(COUNT(*)) || ' tables'
                FROM dba_tables WHERE owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')),
               'INFO',
               'Create statistics on all columns used in WHERE, JOIN, GROUP BY, ORDER BY'
        FROM dual
        UNION ALL
        SELECT 5, 'Security', 'Row-Level Security Candidates',
               (SELECT TO_CHAR(COUNT(*)) || ' VPD policies'
                FROM dba_policies),
               CASE WHEN (SELECT COUNT(*) FROM dba_policies) > 0 THEN 'WARNING' ELSE 'PASS' END,
               'Convert Oracle VPD to Synapse Row-Level Security (RLS)'
        FROM dual
        UNION ALL
        SELECT 6, 'Migration', 'Data Movement Method',
               (SELECT TO_CHAR(ROUND(SUM(bytes)/1024/1024/1024, 2)) || ' GB' FROM dba_segments),
               'PASS',
               'Use Azure Data Factory, PolyBase, or COPY INTO for data loading'
        FROM dual
        UNION ALL
        SELECT 7, 'Migration', 'Schema Conversion Tool',
               'SQL Server Migration Assistant (SSMA)',
               'PASS',
               'Use SSMA for Oracle to convert schema and assess compatibility'
        FROM dual
        UNION ALL
        SELECT 8, 'Connectivity', 'Network Configuration',
               'Private Endpoint recommended',
               'PASS',
               'Use Private Link for secure connectivity from Azure VNet'
        FROM dual
        UNION ALL
        SELECT 9, 'Performance', 'Result Set Caching',
               'Available',
               'PASS',
               'Enable result set caching for repeated queries'
        FROM dual
        UNION ALL
        SELECT 10, 'Performance', 'Workload Management',
               'Resource classes',
               'INFO',
               'Configure workload groups and classifiers for query prioritization'
        FROM dual
    )
    SELECT category, check_item, current_value, status, recommendation
    FROM validation_checks
    ORDER BY seq
    """


def get_synapse_sizing_assessment():
    """Assess database sizing for Synapse DWU and storage tier recommendations."""
    return """
    WITH sizing_data AS (
        SELECT
            (SELECT ROUND(SUM(bytes)/1024/1024/1024, 2) FROM dba_segments) AS total_size_gb,
            (SELECT ROUND(SUM(bytes)/1024/1024/1024/1024, 4) FROM dba_segments) AS total_size_tb,
            (SELECT COUNT(*) FROM dba_tables WHERE owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')) AS table_count,
            (SELECT COUNT(*) FROM dba_tab_columns WHERE owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')) AS column_count,
            (SELECT SUM(NVL(num_rows,0)) FROM dba_tables WHERE owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')) AS total_rows,
            (SELECT COUNT(*) FROM dba_tab_columns
             WHERE data_type IN ('CLOB','BLOB','NCLOB','LONG','LONG RAW')
             AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')) AS lob_column_count
        FROM dual
    )
    SELECT 'Current Database Size' AS metric,
           TO_CHAR(total_size_gb) || ' GB (' || TO_CHAR(total_size_tb) || ' TB)' AS value,
           CASE
               WHEN total_size_tb <= 240 THEN 'PASS'
               ELSE 'REVIEW - exceeds Synapse 240TB limit'
           END AS status,
           'Synapse dedicated SQL pool supports up to 240TB compressed' AS notes
    FROM sizing_data
    UNION ALL
    SELECT 'Estimated Compressed Size',
           TO_CHAR(ROUND(total_size_gb * 0.25, 2)) || ' GB (estimated 4:1 compression)',
           'INFO',
           'Columnstore typically achieves 4-10x compression'
    FROM sizing_data
    UNION ALL
    SELECT 'Recommended DWU Tier',
           CASE
               WHEN total_size_tb < 0.5 THEN 'DW100c - DW500c (Entry)'
               WHEN total_size_tb < 2 THEN 'DW500c - DW1000c (Small)'
               WHEN total_size_tb < 10 THEN 'DW1000c - DW3000c (Medium)'
               WHEN total_size_tb < 50 THEN 'DW3000c - DW6000c (Large)'
               WHEN total_size_tb < 100 THEN 'DW6000c - DW15000c (XLarge)'
               ELSE 'DW15000c - DW30000c (Enterprise)'
           END,
           'PASS',
           'Scale based on concurrent query requirements and SLA'
    FROM sizing_data
    UNION ALL
    SELECT 'Table Count',
           TO_CHAR(table_count) || ' tables',
           CASE WHEN table_count <= 60000 THEN 'PASS' ELSE 'WARNING - exceeds 60K limit' END,
           'Synapse supports up to 60,000 tables per database'
    FROM sizing_data
    UNION ALL
    SELECT 'Total Row Estimate',
           TO_CHAR(total_rows, '999,999,999,999') || ' rows',
           'INFO',
           'Synapse handles billions of rows efficiently with columnstore'
    FROM sizing_data
    UNION ALL
    SELECT 'LOB Column Impact',
           TO_CHAR(lob_column_count) || ' LOB columns',
           CASE WHEN lob_column_count > 0 THEN 'WARNING' ELSE 'PASS' END,
           'Tables with LOB columns may need heap/row store instead of columnstore'
    FROM sizing_data
    UNION ALL
    SELECT 'Estimated Monthly Cost',
           CASE
               WHEN (SELECT ROUND(SUM(bytes)/1024/1024/1024/1024, 4) FROM dba_segments) < 1 THEN '$1,200 - $6,000/month'
               WHEN (SELECT ROUND(SUM(bytes)/1024/1024/1024/1024, 4) FROM dba_segments) < 10 THEN '$6,000 - $18,000/month'
               WHEN (SELECT ROUND(SUM(bytes)/1024/1024/1024/1024, 4) FROM dba_segments) < 50 THEN '$18,000 - $36,000/month'
               ELSE '$36,000+/month'
           END,
           'INFO',
           'Rough estimate - use Azure Pricing Calculator for accurate costs'
    FROM dual
    """


# =============================================================================
# PLATFORM MIGRATION QUERIES - For --platform migration compatibility analysis
# =============================================================================

def get_schema_objects_summary():
    """Get summary of all schema objects by type and owner (PDB-aware using all_objects)."""
    return """
    SELECT
        owner,
        object_type,
        COUNT(*) as object_count,
        COUNT(CASE WHEN status = 'VALID' THEN 1 END) as valid_count,
        COUNT(CASE WHEN status = 'INVALID' THEN 1 END) as invalid_count
    FROM all_objects
    WHERE owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
      AND object_type NOT IN ('INDEX PARTITION', 'TABLE PARTITION', 'LOB PARTITION',
                              'TABLE SUBPARTITION', 'INDEX SUBPARTITION', 'LOB SUBPARTITION')
    GROUP BY owner, object_type
    ORDER BY owner, object_type
    """


def get_table_details():
    """Get detailed table information including size and row counts (PDB-aware using all_tables)."""
    return """
    SELECT
        t.owner,
        t.table_name,
        t.num_rows,
        t.avg_row_len,
        t.partitioned,
        t.temporary,
        t.iot_type,
        t.compression,
        t.compress_for,
        (SELECT COUNT(*) FROM all_tab_columns c WHERE c.owner = t.owner AND c.table_name = t.table_name) as column_count,
        (SELECT COUNT(*) FROM all_indexes i WHERE i.owner = t.owner AND i.table_name = t.table_name) as index_count,
        (SELECT COUNT(*) FROM all_constraints c WHERE c.owner = t.owner AND c.table_name = t.table_name AND c.constraint_type = 'R') as fk_count
    FROM all_tables t
    WHERE t.owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
    ORDER BY t.owner, t.table_name
    """


def get_data_types_usage():
    """Get all data types used across the database with counts (PDB-aware)."""
    return """
    SELECT
        data_type,
        COUNT(*) as column_count,
        COUNT(DISTINCT owner || '.' || table_name) as table_count,
        CASE
            WHEN data_type IN ('VARCHAR2', 'CHAR', 'NVARCHAR2', 'NCHAR') THEN 'String'
            WHEN data_type IN ('NUMBER', 'FLOAT', 'BINARY_FLOAT', 'BINARY_DOUBLE') THEN 'Numeric'
            WHEN data_type IN ('DATE', 'TIMESTAMP', 'TIMESTAMP WITH TIME ZONE', 'TIMESTAMP WITH LOCAL TIME ZONE', 'INTERVAL YEAR TO MONTH', 'INTERVAL DAY TO SECOND') THEN 'DateTime'
            WHEN data_type IN ('CLOB', 'NCLOB', 'BLOB', 'BFILE', 'LONG', 'LONG RAW') THEN 'LOB'
            WHEN data_type IN ('RAW') THEN 'Binary'
            WHEN data_type IN ('XMLTYPE') THEN 'XML'
            WHEN data_type IN ('SDO_GEOMETRY', 'ST_GEOMETRY') THEN 'Spatial'
            WHEN data_type IN ('JSON') THEN 'JSON'
            WHEN data_type LIKE '%OBJECT%' OR data_type LIKE '%REF%' THEN 'Object'
            WHEN data_type LIKE '%VARRAY%' OR data_type LIKE '%TABLE%' THEN 'Collection'
            ELSE 'Other'
        END as type_category,
        CASE
            WHEN data_type IN ('VARCHAR2', 'CHAR', 'NVARCHAR2', 'NCHAR', 'NUMBER', 'DATE', 'TIMESTAMP', 'RAW', 'FLOAT') THEN 'Standard'
            WHEN data_type IN ('CLOB', 'NCLOB', 'BLOB', 'LONG', 'LONG RAW') THEN 'LOB - Needs Review'
            WHEN data_type IN ('BFILE') THEN 'External File - Manual Migration'
            WHEN data_type IN ('XMLTYPE') THEN 'XML - Platform Dependent'
            WHEN data_type IN ('SDO_GEOMETRY', 'ST_GEOMETRY') THEN 'Spatial - Needs Extension'
            WHEN data_type LIKE '%OBJECT%' OR data_type LIKE '%REF%' OR data_type LIKE '%VARRAY%' THEN 'Oracle-Specific - Redesign Needed'
            ELSE 'Review Required'
        END as migration_complexity
    FROM all_tab_columns
    WHERE owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
    GROUP BY data_type
    ORDER BY column_count DESC
    """


def get_lob_columns():
    """Get details of LOB columns that may need special migration handling (PDB-aware)."""
    return """
    SELECT
        c.owner,
        c.table_name,
        c.column_name,
        c.data_type,
        l.segment_name as lob_segment,
        l.securefile,
        l.compression,
        l.deduplication,
        l.in_row
    FROM all_tab_columns c
    JOIN all_lobs l ON c.owner = l.owner AND c.table_name = l.table_name AND c.column_name = l.column_name
    WHERE c.owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
    ORDER BY c.owner, c.table_name
    """


def get_xmltype_usage():
    """Get XMLType column usage details (PDB-aware)."""
    return """
    SELECT
        c.owner,
        c.table_name,
        c.column_name,
        c.data_type
    FROM all_tab_columns c
    WHERE c.data_type = 'XMLTYPE'
      AND c.owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
    ORDER BY c.owner, c.table_name
    """


def get_spatial_columns():
    """Get spatial/geometry column usage (PDB-aware)."""
    return """
    SELECT
        owner,
        table_name,
        column_name,
        'SDO_GEOMETRY' as data_type,
        'Requires PostGIS or equivalent spatial extension' as migration_notes
    FROM all_tab_columns
    WHERE data_type = 'SDO_GEOMETRY'
      AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
    ORDER BY owner, table_name
    """


def get_plsql_objects_summary():
    """Get summary of PL/SQL objects by type (PDB-aware)."""
    return """
    SELECT
        owner,
        type as object_type,
        COUNT(DISTINCT name) as object_count,
        COUNT(*) as total_lines
    FROM all_source
    WHERE owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
    GROUP BY owner, type
    ORDER BY owner, type
    """


def get_plsql_code_metrics():
    """Get PL/SQL code metrics including line counts (PDB-aware)."""
    return """
    SELECT
        s.owner,
        s.type as object_type,
        s.name as object_name,
        COUNT(*) as line_count,
        MAX(s.line) as max_line,
        MAX(o.status) as status
    FROM all_source s
    LEFT JOIN all_objects o ON o.owner = s.owner
                            AND o.object_name = s.name
                            AND o.object_type = s.type
    WHERE s.owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
    GROUP BY s.owner, s.type, s.name
    ORDER BY COUNT(*) DESC
    FETCH FIRST 500 ROWS ONLY
    """


def get_oracle_specific_syntax():
    """Detect Oracle-specific SQL syntax in PL/SQL code that needs conversion (PDB-aware)."""
    return """
    SELECT
        owner,
        name,
        type,
        'CONNECT BY' as syntax_pattern,
        COUNT(*) as occurrence_count
    FROM all_source
    WHERE UPPER(text) LIKE '%CONNECT BY%'
      AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
    GROUP BY owner, name, type
    UNION ALL
    SELECT
        owner,
        name,
        type,
        'ROWNUM' as syntax_pattern,
        COUNT(*) as occurrence_count
    FROM all_source
    WHERE UPPER(text) LIKE '%ROWNUM%'
      AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
    GROUP BY owner, name, type
    UNION ALL
    SELECT
        owner,
        name,
        type,
        'DECODE' as syntax_pattern,
        COUNT(*) as occurrence_count
    FROM all_source
    WHERE UPPER(text) LIKE '%DECODE(%'
      AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
    GROUP BY owner, name, type
    UNION ALL
    SELECT
        owner,
        name,
        type,
        'NVL' as syntax_pattern,
        COUNT(*) as occurrence_count
    FROM all_source
    WHERE UPPER(text) LIKE '%NVL(%'
      AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
    GROUP BY owner, name, type
    UNION ALL
    SELECT
        owner,
        name,
        type,
        'OUTER JOIN (+)' as syntax_pattern,
        COUNT(*) as occurrence_count
    FROM all_source
    WHERE text LIKE '%(+)%'
      AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
    GROUP BY owner, name, type
    UNION ALL
    SELECT
        owner,
        name,
        type,
        'SYSDATE' as syntax_pattern,
        COUNT(*) as occurrence_count
    FROM all_source
    WHERE UPPER(text) LIKE '%SYSDATE%'
      AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
    GROUP BY owner, name, type
    UNION ALL
    SELECT
        owner,
        name,
        type,
        'DUAL' as syntax_pattern,
        COUNT(*) as occurrence_count
    FROM all_source
    WHERE UPPER(text) LIKE '%FROM DUAL%'
      AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
    GROUP BY owner, name, type
    UNION ALL
    SELECT
        owner,
        name,
        type,
        'DBMS_' as syntax_pattern,
        COUNT(*) as occurrence_count
    FROM all_source
    WHERE UPPER(text) LIKE '%DBMS_%'
      AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
    GROUP BY owner, name, type
    UNION ALL
    SELECT
        owner,
        name,
        type,
        'UTL_' as syntax_pattern,
        COUNT(*) as occurrence_count
    FROM all_source
    WHERE UPPER(text) LIKE '%UTL_%'
      AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
    GROUP BY owner, name, type
    ORDER BY owner, name, type, syntax_pattern
    """


def get_oracle_syntax_summary():
    """Summary of Oracle-specific syntax patterns found."""
    return """
    WITH syntax_counts AS (
        SELECT 'CONNECT BY (Hierarchical)' as pattern,
               COUNT(DISTINCT owner || '.' || name) as object_count,
               'Recursive CTE' as alternative,
               'HIGH' as conversion_effort
        FROM dba_source
        WHERE UPPER(text) LIKE '%CONNECT BY%'
          AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
        UNION ALL
        SELECT 'ROWNUM',
               COUNT(DISTINCT owner || '.' || name),
               'ROW_NUMBER() / LIMIT / TOP',
               'MEDIUM'
        FROM dba_source
        WHERE UPPER(text) LIKE '%ROWNUM%'
          AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
        UNION ALL
        SELECT 'DECODE()',
               COUNT(DISTINCT owner || '.' || name),
               'CASE expression',
               'LOW'
        FROM dba_source
        WHERE UPPER(text) LIKE '%DECODE(%'
          AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
        UNION ALL
        SELECT 'NVL()',
               COUNT(DISTINCT owner || '.' || name),
               'COALESCE() / ISNULL()',
               'LOW'
        FROM dba_source
        WHERE UPPER(text) LIKE '%NVL(%'
          AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
        UNION ALL
        SELECT 'Oracle Outer Join (+)',
               COUNT(DISTINCT owner || '.' || name),
               'ANSI LEFT/RIGHT JOIN',
               'MEDIUM'
        FROM dba_source
        WHERE text LIKE '%(+)%'
          AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
        UNION ALL
        SELECT 'SYSDATE',
               COUNT(DISTINCT owner || '.' || name),
               'CURRENT_TIMESTAMP / GETDATE()',
               'LOW'
        FROM dba_source
        WHERE UPPER(text) LIKE '%SYSDATE%'
          AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
        UNION ALL
        SELECT 'DBMS_* Packages',
               COUNT(DISTINCT owner || '.' || name),
               'Platform-specific alternatives',
               'HIGH'
        FROM dba_source
        WHERE UPPER(text) LIKE '%DBMS_%'
          AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
        UNION ALL
        SELECT 'UTL_* Packages',
               COUNT(DISTINCT owner || '.' || name),
               'Platform-specific alternatives',
               'HIGH'
        FROM dba_source
        WHERE UPPER(text) LIKE '%UTL_%'
          AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
        UNION ALL
        SELECT 'Sequences (CURRVAL/NEXTVAL)',
               COUNT(DISTINCT owner || '.' || name),
               'IDENTITY / SERIAL / SEQUENCE',
               'MEDIUM'
        FROM dba_source
        WHERE (UPPER(text) LIKE '%.NEXTVAL%' OR UPPER(text) LIKE '%.CURRVAL%')
          AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
        UNION ALL
        SELECT 'MERGE Statement',
               COUNT(DISTINCT owner || '.' || name),
               'MERGE (MSSQL) / INSERT ON CONFLICT (PG)',
               'MEDIUM'
        FROM dba_source
        WHERE UPPER(text) LIKE '%MERGE INTO%'
          AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
    )
    SELECT pattern, object_count, alternative, conversion_effort
    FROM syntax_counts
    WHERE object_count > 0
    ORDER BY
        CASE conversion_effort WHEN 'HIGH' THEN 1 WHEN 'MEDIUM' THEN 2 ELSE 3 END,
        object_count DESC
    """


def get_triggers_summary():
    """Get trigger details for migration analysis (PDB-aware)."""
    return """
    SELECT
        owner,
        trigger_name,
        table_owner,
        table_name,
        trigger_type,
        triggering_event,
        status,
        (SELECT COUNT(*) FROM all_source s
         WHERE s.owner = t.owner AND s.name = t.trigger_name AND s.type = 'TRIGGER') as line_count
    FROM all_triggers t
    WHERE owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
    ORDER BY owner, table_name, trigger_name
    """


def get_partitioned_tables():
    """Get partitioning details for tables (PDB-aware)."""
    return """
    SELECT
        owner,
        table_name,
        partitioning_type,
        subpartitioning_type,
        partition_count,
        def_subpartition_count,
        partitioning_key_count,
        subpartitioning_key_count,
        status,
        interval,
        CASE partitioning_type
            WHEN 'RANGE' THEN 'Supported in most platforms'
            WHEN 'LIST' THEN 'Supported in most platforms'
            WHEN 'HASH' THEN 'Limited support - may need redesign'
            WHEN 'COMPOSITE' THEN 'Complex - needs analysis'
            WHEN 'REFERENCE' THEN 'Oracle-specific - needs redesign'
            WHEN 'SYSTEM' THEN 'Oracle-specific - needs redesign'
            ELSE 'Review required'
        END as migration_notes
    FROM all_part_tables
    WHERE owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
    ORDER BY owner, table_name
    """


def get_partitioning_keys():
    """Get partitioning key columns."""
    return """
    SELECT
        owner,
        name as table_name,
        object_type,
        column_name,
        column_position
    FROM dba_part_key_columns
    WHERE owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
    ORDER BY owner, name, column_position
    """


def get_materialized_views():
    """Get materialized view details (PDB-aware)."""
    return """
    SELECT
        owner,
        mview_name,
        container_name,
        query_len,
        refresh_mode,
        refresh_method,
        build_mode,
        fast_refreshable,
        last_refresh_type,
        last_refresh_date,
        staleness,
        compile_state,
        CASE refresh_method
            WHEN 'COMPLETE' THEN 'Supported'
            WHEN 'FAST' THEN 'Limited support - platform dependent'
            WHEN 'FORCE' THEN 'Partial support'
            ELSE 'Review required'
        END as migration_notes
    FROM all_mviews
    WHERE owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
    ORDER BY owner, mview_name
    """


def get_db_links():
    """Get database link information (PDB-aware)."""
    return """
    SELECT
        owner,
        db_link,
        username,
        host,
        created,
        'Requires platform-specific solution (Linked Server, Foreign Data Wrapper, etc.)' as migration_notes
    FROM all_db_links
    WHERE owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
    ORDER BY owner, db_link
    """


def get_sequences():
    """Get sequence details (PDB-aware)."""
    return """
    SELECT
        sequence_owner,
        sequence_name,
        min_value,
        max_value,
        increment_by,
        cycle_flag,
        order_flag,
        cache_size,
        last_number,
        CASE
            WHEN cycle_flag = 'Y' THEN 'CYCLE option - verify platform support'
            WHEN order_flag = 'Y' THEN 'ORDER option - verify platform support'
            ELSE 'Standard sequence'
        END as migration_notes
    FROM all_sequences
    WHERE sequence_owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
    ORDER BY sequence_owner, sequence_name
    """


def get_synonyms():
    """Get synonym information (PDB-aware)."""
    return """
    SELECT
        owner,
        synonym_name,
        table_owner,
        table_name,
        db_link,
        CASE owner
            WHEN 'PUBLIC' THEN 'Public synonym - use schema search path or views'
            ELSE 'Private synonym - consider schema qualification'
        END as migration_notes
    FROM all_synonyms
    WHERE owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
      AND table_owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
    ORDER BY owner, synonym_name
    """


def get_directories():
    """Get directory objects (PDB-aware)."""
    return """
    SELECT
        owner,
        directory_name,
        directory_path,
        'External paths need OS-level configuration on target' as migration_notes
    FROM all_directories
    ORDER BY directory_name
    """


def get_scheduler_jobs():
    """Get DBMS_SCHEDULER job information (PDB-aware)."""
    return """
    SELECT
        owner,
        job_name,
        job_type,
        job_action,
        schedule_type,
        repeat_interval,
        enabled,
        state,
        last_start_date,
        next_run_date,
        'Needs platform scheduler equivalent (pg_cron, SQL Agent, etc.)' as migration_notes
    FROM all_scheduler_jobs
    WHERE owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
    ORDER BY owner, job_name
    """


def get_advanced_queuing():
    """Get Advanced Queuing (AQ) configuration (PDB-aware)."""
    return """
    SELECT
        owner,
        name as queue_name,
        queue_table,
        queue_type,
        enqueue_enabled,
        dequeue_enabled,
        retention,
        'Requires message broker migration (RabbitMQ, Azure Service Bus, etc.)' as migration_notes
    FROM all_queues
    WHERE owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
    ORDER BY owner, name
    """


def get_java_objects():
    """Get Java stored procedures/classes (PDB-aware)."""
    return """
    SELECT
        owner,
        object_name,
        object_type,
        status,
        'Java in database - likely requires application refactoring' as migration_notes
    FROM all_objects
    WHERE object_type IN ('JAVA CLASS', 'JAVA SOURCE', 'JAVA RESOURCE')
      AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
    ORDER BY owner, object_type, object_name
    """


def get_external_tables():
    """Get external table definitions (PDB-aware)."""
    return """
    SELECT
        owner,
        table_name,
        type_owner,
        type_name,
        default_directory_owner,
        default_directory_name,
        access_type,
        'External tables need platform-specific solution (FOREIGN TABLE, BULK INSERT, etc.)' as migration_notes
    FROM all_external_tables
    WHERE owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
    ORDER BY owner, table_name
    """


def get_index_types():
    """Get index type summary for migration analysis (PDB-aware)."""
    return """
    SELECT
        owner,
        index_type,
        COUNT(*) as index_count,
        CASE index_type
            WHEN 'NORMAL' THEN 'B-tree - Supported everywhere'
            WHEN 'NORMAL/REV' THEN 'Reverse key - May need redesign'
            WHEN 'BITMAP' THEN 'Bitmap - Limited platform support'
            WHEN 'FUNCTION-BASED NORMAL' THEN 'Function-based - Check platform support'
            WHEN 'FUNCTION-BASED BITMAP' THEN 'Function-based bitmap - Limited support'
            WHEN 'CLUSTER' THEN 'Cluster index - Oracle-specific'
            WHEN 'IOT - TOP' THEN 'IOT - Use clustered index or redesign'
            WHEN 'DOMAIN' THEN 'Domain index - Needs alternative (Full-text, Spatial)'
            WHEN 'LOB' THEN 'LOB index - Platform managed'
            ELSE 'Review required'
        END as migration_notes
    FROM all_indexes
    WHERE owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
    GROUP BY owner, index_type
    ORDER BY owner, index_count DESC
    """


def get_constraints_summary():
    """Get constraint summary for migration analysis."""
    return """
    SELECT
        owner,
        constraint_type,
        COUNT(*) as constraint_count,
        CASE constraint_type
            WHEN 'P' THEN 'Primary Key - Supported everywhere'
            WHEN 'U' THEN 'Unique - Supported everywhere'
            WHEN 'R' THEN 'Foreign Key - Supported everywhere'
            WHEN 'C' THEN 'Check - Supported (may need syntax adjustment)'
            WHEN 'V' THEN 'With Check Option - View constraint'
            WHEN 'O' THEN 'With Read Only - View constraint'
            ELSE 'Review required'
        END as migration_notes
    FROM dba_constraints
    WHERE owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
    GROUP BY owner, constraint_type
    ORDER BY owner, constraint_count DESC
    """


def get_views_with_complexity():
    """Get views with complexity indicators.
    Note: dba_views.text is LONG type -- cannot use LENGTH() or UPPER() on it.
    Use text_length (NUMBER) column instead and dependency count as proxy for complexity."""
    return """
    SELECT
        v.owner,
        v.view_name,
        v.text_length,
        v.read_only,
        (SELECT COUNT(*) FROM dba_dependencies d
         WHERE d.owner = v.owner AND d.name = v.view_name AND d.type = 'VIEW') as dependency_count,
        CASE
            WHEN v.text_length > 10000 THEN 'Very complex - Long definition'
            WHEN v.text_length > 4000 THEN 'Complex - Long definition'
            ELSE 'Standard'
        END as complexity_indicator
    FROM dba_views v
    WHERE v.owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
    ORDER BY v.text_length DESC NULLS LAST
    FETCH FIRST 200 ROWS ONLY
    """


def get_user_defined_types():
    """Get user-defined types that need migration attention."""
    return """
    SELECT
        owner,
        type_name,
        typecode,
        attributes,
        methods,
        predefined,
        incomplete,
        'User-defined types - May need redesign as tables or application logic' as migration_notes
    FROM dba_types
    WHERE owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
      AND predefined = 'NO'
    ORDER BY owner, type_name
    """


def get_object_privileges():
    """Get object privileges for security migration."""
    return """
    SELECT
        grantee,
        owner,
        table_name,
        privilege,
        grantable,
        grantor
    FROM dba_tab_privs
    WHERE grantee NOT IN ('SYS', 'SYSTEM', 'XDB', 'MDSYS', 'CTXSYS', 'WMSYS', 'ORDSYS',
                          'PUBLIC', 'DBA', 'RESOURCE', 'CONNECT')
      AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
    ORDER BY grantee, owner, table_name
    FETCH FIRST 500 ROWS ONLY
    """


def get_roles_summary():
    """Get roles for security migration."""
    return """
    SELECT
        role,
        password_required,
        authentication_type,
        'Map to target platform roles/groups' as migration_notes
    FROM dba_roles
    WHERE role NOT IN ('DBA', 'RESOURCE', 'CONNECT', 'PUBLIC', 'SELECT_CATALOG_ROLE',
                       'EXECUTE_CATALOG_ROLE', 'DELETE_CATALOG_ROLE', 'EXP_FULL_DATABASE',
                       'IMP_FULL_DATABASE', 'RECOVERY_CATALOG_OWNER', 'AQ_ADMINISTRATOR_ROLE',
                       'AQ_USER_ROLE', 'SCHEDULER_ADMIN', 'HS_ADMIN_SELECT_ROLE',
                       'HS_ADMIN_EXECUTE_ROLE', 'HS_ADMIN_ROLE', 'GLOBAL_AQ_USER_ROLE',
                       'OEM_ADVISOR', 'OEM_MONITOR', 'XDBADMIN', 'XDB_SET_INVOKER',
                       'AUTHENTICATEDUSER', 'XDB_WEBSERVICES', 'XDB_WEBSERVICES_WITH_PUBLIC',
                       'XDB_WEBSERVICES_OVER_HTTP', 'DATAPUMP_EXP_FULL_DATABASE',
                       'DATAPUMP_IMP_FULL_DATABASE', 'GATHER_SYSTEM_STATISTICS',
                       'LOGSTDBY_ADMINISTRATOR', 'DBFS_ROLE')
    ORDER BY role
    """


def get_vdp_policies():
    """Get Virtual Private Database policies."""
    return """
    SELECT
        object_owner,
        object_name,
        policy_group,
        policy_name,
        pf_owner,
        function as policy_function,
        sel,
        ins,
        upd,
        del,
        enable,
        'VPD requires Row-Level Security equivalent (RLS in PostgreSQL, Security Policies in MSSQL)' as migration_notes
    FROM dba_policies
    WHERE object_owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
    ORDER BY object_owner, object_name, policy_name
    """


def get_audit_policies():
    """Get audit configuration."""
    return """
    SELECT
        policy_name,
        audit_option,
        audit_option_type,
        object_schema,
        object_name,
        object_type,
        'Unified Auditing - needs platform-specific audit configuration' as migration_notes
    FROM audit_unified_policies
    WHERE policy_name NOT LIKE 'ORA%'
    ORDER BY policy_name
    """


def get_edition_based_redefinition():
    """Check for Edition-Based Redefinition usage."""
    return """
    SELECT
        owner,
        object_name,
        object_type,
        edition_name,
        'EBR is Oracle-specific - requires application deployment strategy change' as migration_notes
    FROM dba_objects_ae
    WHERE owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
      AND edition_name IS NOT NULL
    ORDER BY owner, object_name
    """


def get_flashback_usage():
    """Check for Flashback technology usage."""
    return """
    SELECT
        fat.table_name,
        fat.owner_name as owner,
        fat.flashback_archive_name,
        fat.archive_table_name,
        fat.status,
        'Flashback Data Archive - needs temporal table solution on target' as migration_notes
    FROM dba_flashback_archive_tables fat
    WHERE fat.owner_name NOT IN ('SYS', 'SYSTEM')
    ORDER BY fat.owner_name, fat.table_name
    """


def get_compression_usage():
    """Get compression settings that may affect migration."""
    return """
    SELECT
        owner,
        table_name,
        compression,
        compress_for,
        CASE compress_for
            WHEN 'BASIC' THEN 'Basic compression - target may have equivalent'
            WHEN 'ADVANCED' THEN 'Advanced compression - verify target support'
            WHEN 'QUERY LOW' THEN 'HCC Query Low - columnar storage on target'
            WHEN 'QUERY HIGH' THEN 'HCC Query High - columnar storage on target'
            WHEN 'ARCHIVE LOW' THEN 'HCC Archive Low - columnar storage on target'
            WHEN 'ARCHIVE HIGH' THEN 'HCC Archive High - columnar storage on target'
            ELSE 'Review compression strategy'
        END as migration_notes
    FROM dba_tables
    WHERE compression = 'ENABLED'
      AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
    ORDER BY owner, table_name
    """


def get_inmemory_usage():
    """Check for In-Memory column store usage."""
    return """
    SELECT
        owner,
        table_name,
        inmemory,
        inmemory_priority,
        inmemory_distribute,
        inmemory_compression,
        inmemory_duplicate,
        'In-Memory requires equivalent technology on target (e.g., columnstore indexes)' as migration_notes
    FROM dba_tables
    WHERE inmemory = 'ENABLED'
      AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
    ORDER BY owner, table_name
    """


def get_encryption_usage():
    """Check for Transparent Data Encryption usage."""
    return """
    SELECT
        owner,
        table_name,
        column_name,
        encryption_alg,
        salt,
        'TDE column encryption - target platform TDE or application-level encryption needed' as migration_notes
    FROM dba_encrypted_columns
    WHERE owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
    ORDER BY owner, table_name, column_name
    """


def get_migration_complexity_summary():
    """Overall migration complexity summary."""
    return """
    WITH complexity_factors AS (
        -- Count Oracle-specific features
        SELECT 'Partitioned Tables' as factor, COUNT(*) as count, 'MEDIUM' as impact
        FROM dba_part_tables WHERE owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
        UNION ALL
        SELECT 'Materialized Views', COUNT(*), 'MEDIUM'
        FROM dba_mviews WHERE owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
        UNION ALL
        SELECT 'Database Links', COUNT(*), 'HIGH'
        FROM dba_db_links WHERE owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
        UNION ALL
        SELECT 'PL/SQL Packages', COUNT(*), 'HIGH'
        FROM dba_objects WHERE object_type = 'PACKAGE'
          AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
        UNION ALL
        SELECT 'Triggers', COUNT(*), 'MEDIUM'
        FROM dba_triggers WHERE owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
        UNION ALL
        SELECT 'User-Defined Types', COUNT(*), 'HIGH'
        FROM dba_types WHERE owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
          AND predefined = 'NO'
        UNION ALL
        SELECT 'Java Objects', COUNT(*), 'HIGH'
        FROM dba_objects WHERE object_type IN ('JAVA CLASS', 'JAVA SOURCE')
          AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
        UNION ALL
        SELECT 'External Tables', COUNT(*), 'MEDIUM'
        FROM dba_external_tables WHERE owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
        UNION ALL
        SELECT 'Scheduler Jobs', COUNT(*), 'MEDIUM'
        FROM dba_scheduler_jobs WHERE owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
        UNION ALL
        SELECT 'Advanced Queues', COUNT(*), 'HIGH'
        FROM dba_queues WHERE owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
        UNION ALL
        SELECT 'LOB Columns', COUNT(*), 'LOW'
        FROM dba_lobs WHERE owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
        UNION ALL
        SELECT 'XMLType Columns', COUNT(*), 'MEDIUM'
        FROM dba_tab_columns WHERE data_type = 'XMLTYPE'
          AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
        UNION ALL
        SELECT 'Spatial Columns', COUNT(*), 'HIGH'
        FROM dba_tab_columns WHERE data_type = 'SDO_GEOMETRY'
          AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
        UNION ALL
        SELECT 'VPD Policies', COUNT(*), 'HIGH'
        FROM dba_policies WHERE object_owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
        UNION ALL
        SELECT 'Bitmap Indexes', COUNT(*), 'MEDIUM'
        FROM dba_indexes WHERE index_type = 'BITMAP'
          AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
    )
    SELECT factor, count, impact,
           CASE
               WHEN count = 0 THEN 'None'
               WHEN count < 10 THEN 'Low'
               WHEN count < 50 THEN 'Medium'
               ELSE 'High'
           END as complexity_contribution
    FROM complexity_factors
    WHERE count > 0
    ORDER BY
        CASE impact WHEN 'HIGH' THEN 1 WHEN 'MEDIUM' THEN 2 ELSE 3 END,
        count DESC
    """


def get_index_summary():
    """Summary of indexes by type for migration analysis (PDB-aware)."""
    return """
    SELECT
        owner,
        index_type,
        COUNT(*) as index_count,
        SUM(CASE WHEN uniqueness = 'UNIQUE' THEN 1 ELSE 0 END) as unique_indexes,
        SUM(CASE WHEN uniqueness = 'NONUNIQUE' THEN 1 ELSE 0 END) as non_unique_indexes,
        SUM(CASE WHEN compression = 'ENABLED' THEN 1 ELSE 0 END) as compressed_indexes,
        SUM(CASE WHEN funcidx_status IS NOT NULL THEN 1 ELSE 0 END) as function_based
    FROM all_indexes
    WHERE owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
    GROUP BY owner, index_type
    ORDER BY owner, index_count DESC
    """


def get_constraint_summary():
    """Summary of constraints by type for migration analysis (PDB-aware)."""
    return """
    SELECT
        owner,
        constraint_type,
        COUNT(*) as constraint_count,
        SUM(CASE WHEN status = 'ENABLED' THEN 1 ELSE 0 END) as enabled_count,
        SUM(CASE WHEN status = 'DISABLED' THEN 1 ELSE 0 END) as disabled_count,
        SUM(CASE WHEN deferrable = 'DEFERRABLE' THEN 1 ELSE 0 END) as deferrable_count,
        SUM(CASE WHEN validated = 'VALIDATED' THEN 1 ELSE 0 END) as validated_count
    FROM all_constraints
    WHERE owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
      AND constraint_type IN ('P', 'U', 'R', 'C', 'O', 'V')
    GROUP BY owner, constraint_type
    ORDER BY owner, constraint_count DESC
    """


def get_external_dependencies():
    """External dependencies like database links, external tables, directories (PDB-aware)."""
    return """
    SELECT 'DATABASE_LINK' as dependency_type,
           db_link as name,
           owner,
           host as target,
           NULL as notes
    FROM all_db_links
    WHERE owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
    UNION ALL
    SELECT 'EXTERNAL_TABLE' as dependency_type,
           table_name as name,
           owner,
           default_directory_name as target,
           type_name as notes
    FROM all_external_tables
    WHERE owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
    UNION ALL
    SELECT 'DIRECTORY' as dependency_type,
           directory_name as name,
           owner,
           directory_path as target,
           NULL as notes
    FROM all_directories
    WHERE directory_name NOT LIKE 'ORACLE%'
      AND directory_name NOT IN ('DATA_PUMP_DIR', 'XMLDIR')
    ORDER BY dependency_type, owner, name
    """


def get_dbms_package_usage():
    """DBMS and UTL package usage in PL/SQL code."""
    return r"""
    SELECT
        package_name,
        COUNT(*) as usage_count,
        COUNT(DISTINCT owner || '.' || name) as object_count
    FROM (
        SELECT
            REGEXP_SUBSTR(UPPER(text), '(DBMS_[A-Z_]+|UTL_[A-Z_]+)', 1, 1) as package_name,
            owner,
            name
        FROM dba_source
        WHERE owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
          AND type IN ('PROCEDURE', 'FUNCTION', 'PACKAGE BODY', 'TRIGGER')
          AND REGEXP_LIKE(UPPER(text), '(DBMS_[A-Z_]+|UTL_[A-Z_]+)')
    )
    WHERE package_name IS NOT NULL
    GROUP BY package_name
    ORDER BY usage_count DESC
    """


def get_advanced_queuing_usage():
    """Advanced Queuing (AQ) usage details."""
    return """
    SELECT
        q.owner,
        q.name as queue_name,
        q.queue_table,
        q.queue_type,
        qt.type as payload_type,
        qt.recipients,
        qt.message_grouping,
        CASE WHEN q.enqueue_enabled = 'YES' THEN 'Y' ELSE 'N' END as enqueue_enabled,
        CASE WHEN q.dequeue_enabled = 'YES' THEN 'Y' ELSE 'N' END as dequeue_enabled
    FROM dba_queues q
    JOIN dba_queue_tables qt ON q.queue_table = qt.queue_table AND q.owner = qt.owner
    WHERE q.owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
    ORDER BY q.owner, q.name
    """


def get_ebr_usage():
    """Edition-Based Redefinition usage."""
    return """
    SELECT
        e.edition_name,
        e.parent_edition_name,
        e.usable,
        (SELECT COUNT(*) FROM dba_objects_ae WHERE edition_name = e.edition_name) as object_count
    FROM dba_editions e
    WHERE e.edition_name != 'ORA$BASE'
    ORDER BY e.edition_name
    """


def get_views_with_complex_queries():
    """Views with Oracle-specific syntax that may need migration attention.
    Note: dba_views.text is LONG type, so we use text_vc (VARCHAR2) which only
    contains the first 4000 chars, or count by view characteristics."""
    return """
    SELECT
        owner,
        view_name,
        text_length,
        CASE
            WHEN text_length > 4000 THEN 'LARGE_VIEW'
            ELSE 'STANDARD'
        END as complexity_reason,
        'Review for Oracle-specific syntax' as migration_notes
    FROM dba_views
    WHERE owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
    ORDER BY text_length DESC NULLS LAST
    FETCH FIRST 100 ROWS ONLY
    """


# ---------------------------------------------------------------------------
# DMA-equivalent queries
# The following functions correspond to SQL extracts from the Google Cloud
# Database Migration Assessment (DMA) collector that were not previously
# covered by Calypso.  Each function is named to make the lineage clear.
# ---------------------------------------------------------------------------

def get_app_cloud_detection_query():
    """Detect well-known enterprise applications and cloud platforms.
    Mirrors DMA app_cloud.sql / app_schemas.sql."""
    return """
    SELECT
        (SELECT owner
         FROM dba_tab_columns
         WHERE table_name = 'FND_PRODUCT_GROUPS'
           AND column_name = 'RELEASE_NAME'
           AND data_type = 'VARCHAR2'
           AND ROWNUM = 1) AS ebs_owner,
        (SELECT owner
         FROM dba_tab_columns
         WHERE table_name = 'S_REPOSITORY'
           AND column_name = 'ROW_ID'
           AND data_type = 'VARCHAR2'
           AND ROWNUM = 1) AS siebel_owner,
        (SELECT owner
         FROM dba_tab_columns
         WHERE table_name = 'PSSTATUS'
           AND column_name = 'TOOLSREL'
           AND data_type = 'VARCHAR2'
           AND ROWNUM = 1) AS psft_owner,
        (SELECT 'Y'
         FROM dba_objects
         WHERE owner = 'RDSADMIN'
           AND object_name = 'RDAADMIN_UTIL'
           AND ROWNUM = 1) AS rds_flag,
        (SELECT 'Y'
         FROM dba_views
         WHERE view_name = 'OCI_AUTONOMOUS_DATABASES'
           AND ROWNUM = 1) AS oci_autonomous_flag,
        (SELECT 'Y'
         FROM dba_objects
         WHERE object_name = 'DBMS_CLOUD'
           AND ROWNUM = 1) AS dbms_cloud_pkg_installed,
        (SELECT 'Y'
         FROM dba_objects
         WHERE object_name = 'WWV_FLOW'
           AND object_type = 'PACKAGE'
           AND ROWNUM = 1
           AND EXISTS (SELECT 1 FROM dba_users WHERE username = 'APEX_PUBLIC_USER')) AS apex_installed,
        (SELECT owner
         FROM dba_tab_columns
         WHERE table_name = 'DD02T'
           AND column_name = 'DDLANGUAGE'
           AND data_type = 'VARCHAR2'
           AND ROWNUM = 1) AS sap_owner
    FROM dual
    """


def get_cpu_cores_usage_history_query():
    """Historical CPU core, count and socket usage from DBA_CPU_USAGE_STATISTICS.
    Mirrors DMA cpucoresusage.sql."""
    return """
    SELECT
        TO_CHAR(timestamp, 'YYYY-MM-DD HH24:MI') AS dt,
        cpu_count,
        cpu_core_count,
        cpu_socket_count
    FROM dba_cpu_usage_statistics
    ORDER BY timestamp
    """


def get_dataguard_config_query():
    """Data Guard archive destination configuration.
    Mirrors DMA dataguard.sql."""
    return """
    SELECT
        inst_id,
        dest_id,
        dest_name,
        REPLACE(destination, '|', ' ') AS destination,
        status,
        REPLACE(target, '|', ' ') AS target,
        schedule,
        register,
        REPLACE(alternate, '|', ' ') AS alternate,
        transmit_mode,
        affirm,
        valid_role,
        verify
    FROM gv$archive_dest
    WHERE destination IS NOT NULL
    ORDER BY inst_id, dest_id
    """


def get_high_water_mark_statistics_query():
    """Database high water mark statistics.
    Mirrors DMA dbhwmarkstatistics.sql."""
    return """
    SELECT
        description,
        highwater,
        last_value
    FROM dba_high_water_mark_statistics
    ORDER BY description
    """


def get_db_object_names_query():
    """Individual database object names with source code line counts and status.
    Mirrors DMA dbobjectnames.sql."""
    return """
    WITH vdbobji AS (
        SELECT
            owner,
            object_type,
            object_name,
            status
        FROM dba_objects
        WHERE owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
        AND object_name NOT LIKE 'BIN$%'
    ),
    vdbobjx AS (
        SELECT owner, synonym_name, table_owner
        FROM dba_synonyms
        WHERE owner = 'PUBLIC'
          AND table_owner IN (
            'SYS','SYSTEM','CTXSYS','DBSNMP','LBACSYS','MDSYS','OLAPSYS','ORDSYS','OUTLN',
            'XDB','WMSYS','APPQOSSYS','DBSFWUSER','GGSYS','ANONYMOUS','APEX_PUBLIC_USER',
            'FLOWS_FILES','DIP','ORACLE_OCM','GSMADMIN_INTERNAL','DVSYS','DVF','AUDSYS'
          )
    ),
    vsrc AS (
        SELECT
            owner,
            name,
            type,
            MAX(line) AS lines
        FROM dba_source
        WHERE owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
        GROUP BY owner, name, type
    )
    SELECT /*+ USE_HASH(i x s) */
        i.owner,
        i.object_name,
        i.object_type,
        s.lines,
        i.status
    FROM vdbobji i
    LEFT OUTER JOIN vdbobjx x
        ON i.object_type = 'SYNONYM' AND i.owner = x.owner AND i.object_name = x.synonym_name
    LEFT OUTER JOIN vsrc s
        ON i.object_type = s.type AND i.owner = s.owner AND i.object_name = s.name
    WHERE NOT (i.object_type = 'SYNONYM' AND i.owner = 'PUBLIC'
               AND (i.object_name LIKE '/%' OR x.table_owner IS NOT NULL))
    ORDER BY i.owner, i.object_type, i.object_name
    """


def get_indexes_per_table_query():
    """Distribution of indexes per table -- how many tables have N indexes.
    Mirrors DMA idxpertable.sql."""
    return """
    WITH vrawidx AS (
        SELECT table_owner, table_name, COUNT(1) AS idx_cnt
        FROM dba_indexes
        WHERE owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
        GROUP BY table_owner, table_name
    )
    SELECT
        COUNT(table_name) AS tab_count,
        idx_cnt,
        ROUND(100 * RATIO_TO_REPORT(COUNT(table_name)) OVER (), 2) AS idx_perc
    FROM vrawidx
    GROUP BY idx_cnt
    ORDER BY idx_cnt
    """


def get_opatch_info_query():
    """Oracle patch inventory from DBA_REGISTRY_SQLPATCH (12c+) or registry$history.
    Mirrors DMA opatch.sql intent but avoids DBMS_QOPATCH which requires SYS privileges."""
    return """
    SELECT
        patch_id,
        patch_uid,
        description AS patch_descr,
        action,
        status,
        TO_CHAR(action_time, 'YYYY-MM-DD HH24:MI:SS') AS applied_date,
        source_version,
        target_version
    FROM dba_registry_sqlpatch
    ORDER BY action_time DESC
    """


def get_pdb_open_mode_query():
    """Pluggable database open mode and total size.
    Mirrors DMA pdbsopenmode.sql."""
    return """
    SELECT
        con_id,
        name,
        open_mode,
        ROUND(total_size / 1024 / 1024 / 1024, 2) AS total_gb,
        con_uid
    FROM v$pdbs
    ORDER BY con_id
    """


def get_all_users_query():
    """All database usernames.
    Mirrors DMA users.sql."""
    return """
    SELECT username
    FROM dba_users
    ORDER BY username
    """


def get_user_segments_in_system_ts_query():
    """User segments stored in SYSAUX or SYSTEM tablespaces.
    Mirrors DMA usrsegatt.sql."""
    return """
    SELECT
        owner,
        segment_name,
        segment_type,
        tablespace_name
    FROM dba_segments
    WHERE tablespace_name IN ('SYSAUX', 'SYSTEM')
      AND owner NOT IN ('ANONYMOUS','APEX_200200','APEX_210200','APEX_220200','APEX_230200','APEX_PUBLIC_USER','APPQOSSYS','AQADM','AUDSYS','AUTHORIZE','CTXSYS','DBSFWUSER','DBSNMP','DGPDB_INT','DIP','DVF','DVSYS','EXFSYS','GGSHAREDCAP','GGSYS','GSMADMIN_INTERNAL','GSMCATUSER','GSMUSER','LBACSYS','MDDATA','MDSYS','OJVMSYS','OLAPSYS','ORACLE_OCM','ORDDATA','ORDSYS','OUTLN','PUBLIC','REMOTE_SCHEDULER_AGENT','S$NULL','SYS','SYS$UMF','SYSBACKUP','SYSDG','SYSKM','SYSRAC','SYSTEM','VECSYS','WMSYS','XDB')
    ORDER BY owner, segment_type, segment_name
    """


# ---------------------------------------------------------------------------
# DMA AWR-equivalent queries
# These mirror the AWR extracts from the DMA collector.  They use
# SYSDATE - 30 as the default lookback consistent with the existing
# AWR queries in this file.
# ---------------------------------------------------------------------------

def get_awr_hist_cmd_types_query():
    """Historical SQL command type distribution by hour from AWR.
    Mirrors DMA awr/awrhistcmdtypes.sql."""
    return """
    SELECT
        TO_CHAR(c.begin_interval_time, 'HH24') AS hh,
        b.command_type,
        aa.name AS command_name,
        COUNT(1) AS cnt,
        ROUND(AVG(a.buffer_gets_delta)) AS avg_buffer_gets,
        ROUND(AVG(a.elapsed_time_delta)) AS avg_elapsed_time,
        ROUND(AVG(a.rows_processed_delta)) AS avg_rows_processed,
        ROUND(AVG(a.executions_delta)) AS avg_executions,
        ROUND(AVG(a.cpu_time_delta)) AS avg_cpu_time,
        ROUND(AVG(a.iowait_delta)) AS avg_iowait,
        ROUND(AVG(a.clwait_delta)) AS avg_clwait,
        ROUND(AVG(a.apwait_delta)) AS avg_apwait,
        ROUND(AVG(a.ccwait_delta)) AS avg_ccwait,
        ROUND(AVG(a.plsexec_time_delta)) AS avg_plsexec_time
    FROM dba_hist_sqlstat a
    INNER JOIN dba_hist_sqltext b
        ON a.sql_id = b.sql_id AND a.dbid = b.dbid
    INNER JOIN dba_hist_snapshot c
        ON a.snap_id = c.snap_id AND a.dbid = c.dbid AND a.instance_number = c.instance_number
    LEFT OUTER JOIN audit_actions aa
        ON b.command_type = aa.action
    WHERE c.begin_interval_time >= SYSDATE - 30
    GROUP BY
        TO_CHAR(c.begin_interval_time, 'HH24'),
        b.command_type,
        aa.name
    ORDER BY hh, avg_elapsed_time DESC
    """


def get_awr_hist_osstat_query():
    """Historical OS-level statistics (CPU, IO, VM) from AWR with percentiles.
    Mirrors DMA awr/awrhistosstat.sql."""
    return """
    WITH v_osstat_all AS (
        SELECT
            os.dbid,
            os.instance_number,
            TO_CHAR(snap.begin_interval_time, 'HH24') AS hh24,
            os.stat_name,
            os.value AS cumulative_value,
            CASE
                WHEN os.stat_name IN ('IDLE_TIME','BUSY_TIME','USER_TIME','SYS_TIME',
                                      'IOWAIT_TIME','NICE_TIME','RSRC_MGR_CPU_WAIT_TIME',
                                      'VM_IN_BYTES','VM_OUT_BYTES')
                THEN NVL(DECODE(GREATEST(os.value, NVL(LAG(os.value)
                        OVER (PARTITION BY os.dbid, os.instance_number, os.stat_name ORDER BY os.snap_id), 0)),
                    os.value, os.value - LAG(os.value)
                        OVER (PARTITION BY os.dbid, os.instance_number, os.stat_name ORDER BY os.snap_id),
                    0), 0)
                ELSE os.value
            END AS delta_value,
            (CAST(snap.end_interval_time AS DATE) - CAST(snap.begin_interval_time AS DATE)) * 86400 AS snap_total_secs
        FROM dba_hist_osstat os
        INNER JOIN dba_hist_snapshot snap
            ON os.snap_id = snap.snap_id AND os.instance_number = snap.instance_number AND os.dbid = snap.dbid
        WHERE snap.begin_interval_time >= SYSDATE - 30
    )
    SELECT
        dbid,
        instance_number,
        hh24,
        stat_name,
        ROUND(SUM(snap_total_secs)) AS hh24_total_secs,
        ROUND(AVG(cumulative_value)) AS cumulative_value,
        ROUND(AVG(delta_value)) AS avg_value,
        ROUND(STATS_MODE(delta_value)) AS mode_value,
        ROUND(MEDIAN(delta_value)) AS median_value,
        ROUND(PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY delta_value)) AS perc50,
        ROUND(PERCENTILE_CONT(0.75) WITHIN GROUP (ORDER BY delta_value)) AS perc75,
        ROUND(PERCENTILE_CONT(0.90) WITHIN GROUP (ORDER BY delta_value)) AS perc90,
        ROUND(PERCENTILE_CONT(0.95) WITHIN GROUP (ORDER BY delta_value)) AS perc95,
        ROUND(MAX(delta_value)) AS perc100,
        ROUND(MIN(delta_value)) AS min_value,
        ROUND(MAX(delta_value)) AS max_value,
        ROUND(SUM(delta_value)) AS sum_value,
        COUNT(1) AS cnt
    FROM v_osstat_all
    GROUP BY dbid, instance_number, hh24, stat_name
    ORDER BY dbid, instance_number, stat_name, hh24
    """


def get_awr_hist_sysmetric_history_query():
    """Detailed system metric history from AWR with percentile distributions.
    Mirrors DMA awr/awrhistsysmetrichist.sql.
    Uses group_id=2 for 60-second granularity and filters on metric view timestamps."""
    return """
    SELECT
        hsm.dbid,
        hsm.instance_number,
        TO_CHAR(hsm.begin_time, 'HH24') AS hour,
        hsm.metric_name,
        hsm.metric_unit,
        ROUND(AVG(hsm.value)) AS avg_value,
        ROUND(STATS_MODE(hsm.value)) AS mode_value,
        ROUND(MEDIAN(hsm.value)) AS median_value,
        ROUND(MIN(hsm.value)) AS min_value,
        ROUND(MAX(hsm.value)) AS max_value,
        ROUND(SUM(hsm.value)) AS sum_value,
        ROUND(PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY hsm.value)) AS perc50,
        ROUND(PERCENTILE_CONT(0.75) WITHIN GROUP (ORDER BY hsm.value)) AS perc75,
        ROUND(PERCENTILE_CONT(0.90) WITHIN GROUP (ORDER BY hsm.value)) AS perc90,
        ROUND(PERCENTILE_CONT(0.95) WITHIN GROUP (ORDER BY hsm.value)) AS perc95,
        ROUND(MAX(hsm.value)) AS perc100
    FROM dba_hist_sysmetric_history hsm
    WHERE hsm.begin_time >= SYSDATE - 30
      AND hsm.group_id = 2
    GROUP BY
        hsm.dbid, hsm.instance_number,
        TO_CHAR(hsm.begin_time, 'HH24'),
        hsm.metric_name, hsm.metric_unit
    ORDER BY hsm.dbid, hsm.instance_number, hsm.metric_name, hour
    """


def get_awr_hist_sysmetric_summary_query():
    """System metric summary from AWR with P95 estimation.
    Mirrors DMA awr/awrhistsysmetricsumm.sql.
    Includes workaround for Oracle bug where STANDARD_DEVIATION is near-1.
    Filters directly on metric view timestamps instead of snapshot join."""
    return """
    WITH vsysmetricsumm AS (
        SELECT
            hsm.dbid,
            hsm.instance_number,
            TO_CHAR(hsm.begin_time, 'HH24') AS hour,
            hsm.metric_name,
            hsm.metric_unit,
            hsm.average + (2 * CASE
                WHEN standard_deviation > 0.999999999999999999999999999
                 AND standard_deviation < 1
                 AND minval = 0 AND average = maxval
                THEN 0
                ELSE standard_deviation
            END) AS perc95
        FROM dba_hist_sysmetric_summary hsm
        WHERE hsm.begin_time >= SYSDATE - 30
    )
    SELECT
        dbid,
        instance_number,
        hour,
        metric_name,
        metric_unit,
        ROUND(AVG(perc95)) AS avg_value,
        ROUND(STATS_MODE(perc95)) AS mode_value,
        ROUND(MEDIAN(perc95)) AS median_value,
        ROUND(MIN(perc95)) AS min_value,
        ROUND(MAX(perc95)) AS max_value,
        ROUND(SUM(perc95)) AS sum_value,
        ROUND(PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY perc95)) AS perc50,
        ROUND(PERCENTILE_CONT(0.75) WITHIN GROUP (ORDER BY perc95)) AS perc75,
        ROUND(PERCENTILE_CONT(0.90) WITHIN GROUP (ORDER BY perc95)) AS perc90,
        ROUND(PERCENTILE_CONT(0.95) WITHIN GROUP (ORDER BY perc95)) AS perc95,
        ROUND(MAX(perc95)) AS perc100
    FROM vsysmetricsumm
    GROUP BY dbid, instance_number, hour, metric_name, metric_unit
    ORDER BY dbid, instance_number, metric_name, hour
    """


def get_awr_snap_details_query():
    """AWR snapshot interval metadata and timing analysis.
    Mirrors DMA awr/awrsnapdetails.sql."""
    return """
    WITH vsnaps AS (
        SELECT
            s.snap_id,
            s.dbid,
            s.instance_number,
            s.begin_interval_time,
            s.end_interval_time,
            TO_CHAR(s.begin_interval_time, 'HH24') AS hour,
            (CAST(s.end_interval_time AS DATE) - CAST(s.begin_interval_time AS DATE)) * 86400 AS snaps_diff_secs,
            s.startup_time,
            LAG(s.startup_time, 1) OVER (PARTITION BY s.dbid, s.instance_number ORDER BY s.snap_id) AS lag_startup_time
        FROM dba_hist_snapshot s
        WHERE s.begin_interval_time >= SYSDATE - 30
    )
    SELECT
        dbid,
        instance_number,
        hour,
        MIN(snap_id) AS min_snap_id,
        MAX(snap_id) AS max_snap_id,
        TO_CHAR(MIN(begin_interval_time), 'YYYY-MM-DD HH24:MI:SS') AS min_begin_interval_time,
        TO_CHAR(MAX(begin_interval_time), 'YYYY-MM-DD HH24:MI:SS') AS max_begin_interval_time,
        COUNT(1) AS cnt,
        ROUND(SUM(snaps_diff_secs)) AS sum_snaps_diff_secs,
        ROUND(AVG(snaps_diff_secs)) AS avg_snaps_diff_secs,
        ROUND(MEDIAN(snaps_diff_secs)) AS median_snaps_diff_secs,
        ROUND(STATS_MODE(snaps_diff_secs)) AS mode_snaps_diff_secs,
        ROUND(MIN(snaps_diff_secs)) AS min_snaps_diff_secs,
        ROUND(MAX(snaps_diff_secs)) AS max_snaps_diff_secs
    FROM vsnaps
    WHERE startup_time = lag_startup_time
    GROUP BY dbid, instance_number, hour
    ORDER BY dbid, instance_number, hour
    """


def get_awr_hist_sysstat_query():
    """Historical system statistics from AWR with percentile distributions.
    Mirrors DMA awr/dbahistsysstat.sql.
    Uses simple LAG delta calculation instead of complex DECODE pattern."""
    return """
    WITH vraw AS (
        SELECT
            s.dbid,
            s.instance_number,
            TO_CHAR(s.begin_interval_time, 'HH24') AS hour,
            g.stat_name,
            GREATEST(0, g.value - LAG(g.value)
                OVER (PARTITION BY s.dbid, s.instance_number, g.stat_name ORDER BY s.snap_id)) AS value
        FROM dba_hist_snapshot s
        JOIN dba_hist_sysstat g
            ON s.snap_id = g.snap_id AND s.instance_number = g.instance_number AND s.dbid = g.dbid
        WHERE s.begin_interval_time >= SYSDATE - 30
          AND g.stat_name IN (
                'DB time', 'DB CPU', 'redo size', 'redo entries',
                'parse time elapsed', 'parse count (total)', 'parse count (hard)',
                'physical reads', 'physical writes', 'physical read total IO requests',
                'physical write total IO requests', 'physical read total bytes',
                'physical write total bytes', 'db block gets', 'consistent gets',
                'db block changes', 'execute count', 'user calls',
                'user commits', 'user rollbacks', 'table scan rows gotten',
                'table fetch by rowid', 'sorts (memory)', 'sorts (disk)')
    ),
    vdelta AS (
        SELECT * FROM vraw
        WHERE value IS NOT NULL AND value > 0
    )
    SELECT
        dbid,
        instance_number,
        hour,
        stat_name,
        COUNT(1) AS cnt,
        ROUND(AVG(value)) AS avg_value,
        ROUND(STATS_MODE(value)) AS mode_value,
        ROUND(MEDIAN(value)) AS median_value,
        ROUND(MIN(value)) AS min_value,
        ROUND(MAX(value)) AS max_value,
        ROUND(SUM(value)) AS sum_value,
        ROUND(PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY value)) AS perc50,
        ROUND(PERCENTILE_CONT(0.75) WITHIN GROUP (ORDER BY value)) AS perc75,
        ROUND(PERCENTILE_CONT(0.90) WITHIN GROUP (ORDER BY value)) AS perc90,
        ROUND(PERCENTILE_CONT(0.95) WITHIN GROUP (ORDER BY value)) AS perc95,
        ROUND(MAX(value)) AS perc100
    FROM vdelta
    GROUP BY dbid, instance_number, hour, stat_name
    ORDER BY dbid, instance_number, stat_name, hour
    """


def get_awr_hist_sys_time_model_query():
    """Historical system time model data from AWR with percentile distributions.
    Mirrors DMA awr/dbahistsystimemodel.sql.
    Uses simple LAG delta calculation."""
    return """
    WITH vraw AS (
        SELECT
            s.dbid,
            s.instance_number,
            TO_CHAR(s.begin_interval_time, 'HH24') AS hour,
            g.stat_name,
            GREATEST(0, g.value - LAG(g.value)
                OVER (PARTITION BY s.dbid, s.instance_number, g.stat_name ORDER BY s.snap_id)) AS value
        FROM dba_hist_snapshot s
        JOIN dba_hist_sys_time_model g
            ON s.snap_id = g.snap_id AND s.instance_number = g.instance_number AND s.dbid = g.dbid
        WHERE s.begin_interval_time >= SYSDATE - 30
    ),
    vdelta AS (
        SELECT * FROM vraw WHERE value IS NOT NULL AND value > 0
    )
    SELECT
        dbid,
        instance_number,
        hour,
        stat_name,
        COUNT(1) AS cnt,
        ROUND(AVG(value)) AS avg_value,
        ROUND(STATS_MODE(value)) AS mode_value,
        ROUND(MEDIAN(value)) AS median_value,
        ROUND(MIN(value)) AS min_value,
        ROUND(MAX(value)) AS max_value,
        ROUND(SUM(value)) AS sum_value,
        ROUND(PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY value)) AS perc50,
        ROUND(PERCENTILE_CONT(0.75) WITHIN GROUP (ORDER BY value)) AS perc75,
        ROUND(PERCENTILE_CONT(0.90) WITHIN GROUP (ORDER BY value)) AS perc90,
        ROUND(PERCENTILE_CONT(0.95) WITHIN GROUP (ORDER BY value)) AS perc95,
        ROUND(MAX(value)) AS perc100
    FROM vdelta
    GROUP BY dbid, instance_number, hour, stat_name
    ORDER BY dbid, instance_number, stat_name, hour
    """


def get_awr_io_events_query():
    """Historical I/O wait event statistics from AWR with P95/P100 percentiles.
    Mirrors DMA awr/ioevents.sql.
    Uses simple LAG delta calculation."""
    return """
    WITH vrawev AS (
        SELECT
            sev.dbid,
            sev.instance_number,
            TO_CHAR(dhsnap.begin_interval_time, 'HH24') AS hour,
            sev.wait_class,
            sev.event_name,
            GREATEST(0, sev.total_waits - LAG(sev.total_waits)
                OVER (PARTITION BY sev.dbid, sev.instance_number, sev.event_name ORDER BY sev.snap_id)) AS tot_waits_delta,
            GREATEST(0, sev.total_timeouts - LAG(sev.total_timeouts)
                OVER (PARTITION BY sev.dbid, sev.instance_number, sev.event_name ORDER BY sev.snap_id)) AS tot_tout_delta,
            GREATEST(0, sev.time_waited_micro - LAG(sev.time_waited_micro)
                OVER (PARTITION BY sev.dbid, sev.instance_number, sev.event_name ORDER BY sev.snap_id)) AS time_wa_us_delta
        FROM dba_hist_system_event sev
        INNER JOIN dba_hist_snapshot dhsnap
            ON sev.snap_id = dhsnap.snap_id
            AND sev.instance_number = dhsnap.instance_number
            AND sev.dbid = dhsnap.dbid
        WHERE dhsnap.begin_interval_time >= SYSDATE - 30
          AND sev.wait_class IN ('User I/O', 'System I/O', 'Commit')
    ),
    vdelta AS (
        SELECT * FROM vrawev WHERE tot_waits_delta IS NOT NULL
    )
    SELECT
        dbid,
        instance_number,
        hour,
        wait_class,
        event_name,
        ROUND(PERCENTILE_CONT(0.95) WITHIN GROUP (ORDER BY tot_waits_delta)) AS tot_waits_p95,
        ROUND(PERCENTILE_CONT(0.95) WITHIN GROUP (ORDER BY tot_tout_delta)) AS tot_tout_p95,
        ROUND(PERCENTILE_CONT(0.95) WITHIN GROUP (ORDER BY time_wa_us_delta)) AS time_wa_us_p95,
        ROUND(MAX(tot_waits_delta)) AS tot_waits_p100,
        ROUND(MAX(tot_tout_delta)) AS tot_tout_p100,
        ROUND(MAX(time_wa_us_delta)) AS time_wa_us_p100
    FROM vdelta
    GROUP BY dbid, instance_number, hour, wait_class, event_name
    ORDER BY dbid, instance_number, hour, wait_class, event_name
    """


def get_awr_io_function_query():
    """Historical I/O statistics by database function (DBWR, LGWR, etc.) from AWR.
    Mirrors DMA awr/iofunction.sql.
    Reports small/large read/write MB and requests with P95/P100 percentiles."""
    return """
    WITH vrawiof AS (
        SELECT
            TO_CHAR(snap.begin_interval_time, 'HH24') AS hour,
            iof.dbid,
            iof.instance_number,
            iof.function_name,
            NVL(DECODE(GREATEST(iof.small_read_megabytes, NVL(LAG(iof.small_read_megabytes)
                OVER (PARTITION BY iof.dbid, iof.instance_number, iof.function_name ORDER BY iof.snap_id), 0)),
                iof.small_read_megabytes, iof.small_read_megabytes - LAG(iof.small_read_megabytes)
                    OVER (PARTITION BY iof.dbid, iof.instance_number, iof.function_name ORDER BY iof.snap_id), 0), 0) AS sm_read_mb,
            NVL(DECODE(GREATEST(iof.small_write_megabytes, NVL(LAG(iof.small_write_megabytes)
                OVER (PARTITION BY iof.dbid, iof.instance_number, iof.function_name ORDER BY iof.snap_id), 0)),
                iof.small_write_megabytes, iof.small_write_megabytes - LAG(iof.small_write_megabytes)
                    OVER (PARTITION BY iof.dbid, iof.instance_number, iof.function_name ORDER BY iof.snap_id), 0), 0) AS sm_write_mb,
            NVL(DECODE(GREATEST(iof.small_read_reqs, NVL(LAG(iof.small_read_reqs)
                OVER (PARTITION BY iof.dbid, iof.instance_number, iof.function_name ORDER BY iof.snap_id), 0)),
                iof.small_read_reqs, iof.small_read_reqs - LAG(iof.small_read_reqs)
                    OVER (PARTITION BY iof.dbid, iof.instance_number, iof.function_name ORDER BY iof.snap_id), 0), 0) AS sm_read_rq,
            NVL(DECODE(GREATEST(iof.small_write_reqs, NVL(LAG(iof.small_write_reqs)
                OVER (PARTITION BY iof.dbid, iof.instance_number, iof.function_name ORDER BY iof.snap_id), 0)),
                iof.small_write_reqs, iof.small_write_reqs - LAG(iof.small_write_reqs)
                    OVER (PARTITION BY iof.dbid, iof.instance_number, iof.function_name ORDER BY iof.snap_id), 0), 0) AS sm_write_rq,
            NVL(DECODE(GREATEST(iof.large_read_megabytes, NVL(LAG(iof.large_read_megabytes)
                OVER (PARTITION BY iof.dbid, iof.instance_number, iof.function_name ORDER BY iof.snap_id), 0)),
                iof.large_read_megabytes, iof.large_read_megabytes - LAG(iof.large_read_megabytes)
                    OVER (PARTITION BY iof.dbid, iof.instance_number, iof.function_name ORDER BY iof.snap_id), 0), 0) AS lg_read_mb,
            NVL(DECODE(GREATEST(iof.large_write_megabytes, NVL(LAG(iof.large_write_megabytes)
                OVER (PARTITION BY iof.dbid, iof.instance_number, iof.function_name ORDER BY iof.snap_id), 0)),
                iof.large_write_megabytes, iof.large_write_megabytes - LAG(iof.large_write_megabytes)
                    OVER (PARTITION BY iof.dbid, iof.instance_number, iof.function_name ORDER BY iof.snap_id), 0), 0) AS lg_write_mb,
            NVL(DECODE(GREATEST(iof.large_read_reqs, NVL(LAG(iof.large_read_reqs)
                OVER (PARTITION BY iof.dbid, iof.instance_number, iof.function_name ORDER BY iof.snap_id), 0)),
                iof.large_read_reqs, iof.large_read_reqs - LAG(iof.large_read_reqs)
                    OVER (PARTITION BY iof.dbid, iof.instance_number, iof.function_name ORDER BY iof.snap_id), 0), 0) AS lg_read_rq,
            NVL(DECODE(GREATEST(iof.large_write_reqs, NVL(LAG(iof.large_write_reqs)
                OVER (PARTITION BY iof.dbid, iof.instance_number, iof.function_name ORDER BY iof.snap_id), 0)),
                iof.large_write_reqs, iof.large_write_reqs - LAG(iof.large_write_reqs)
                    OVER (PARTITION BY iof.dbid, iof.instance_number, iof.function_name ORDER BY iof.snap_id), 0), 0) AS lg_write_rq,
            NVL(DECODE(GREATEST(iof.number_of_waits, NVL(LAG(iof.number_of_waits)
                OVER (PARTITION BY iof.dbid, iof.instance_number, iof.function_name ORDER BY iof.snap_id), 0)),
                iof.number_of_waits, iof.number_of_waits - LAG(iof.number_of_waits)
                    OVER (PARTITION BY iof.dbid, iof.instance_number, iof.function_name ORDER BY iof.snap_id), 0), 0) AS no_iowait,
            NVL(DECODE(GREATEST(iof.wait_time, NVL(LAG(iof.wait_time)
                OVER (PARTITION BY iof.dbid, iof.instance_number, iof.function_name ORDER BY iof.snap_id), 0)),
                iof.wait_time, iof.wait_time - LAG(iof.wait_time)
                    OVER (PARTITION BY iof.dbid, iof.instance_number, iof.function_name ORDER BY iof.snap_id), 0), 0) AS tot_watime
        FROM dba_hist_iostat_function iof
        INNER JOIN dba_hist_snapshot snap
            ON iof.snap_id = snap.snap_id AND iof.instance_number = snap.instance_number AND iof.dbid = snap.dbid
        WHERE snap.begin_interval_time >= SYSDATE - 30
    )
    SELECT
        dbid,
        instance_number,
        hour,
        function_name,
        ROUND(PERCENTILE_CONT(0.95) WITHIN GROUP (ORDER BY sm_read_mb)) AS sm_read_mb_p95,
        ROUND(PERCENTILE_CONT(0.95) WITHIN GROUP (ORDER BY sm_write_mb)) AS sm_write_mb_p95,
        ROUND(PERCENTILE_CONT(0.95) WITHIN GROUP (ORDER BY sm_read_rq)) AS sm_read_rq_p95,
        ROUND(PERCENTILE_CONT(0.95) WITHIN GROUP (ORDER BY sm_write_rq)) AS sm_write_rq_p95,
        ROUND(PERCENTILE_CONT(0.95) WITHIN GROUP (ORDER BY lg_read_mb)) AS lg_read_mb_p95,
        ROUND(PERCENTILE_CONT(0.95) WITHIN GROUP (ORDER BY lg_write_mb)) AS lg_write_mb_p95,
        ROUND(PERCENTILE_CONT(0.95) WITHIN GROUP (ORDER BY lg_read_rq)) AS lg_read_rq_p95,
        ROUND(PERCENTILE_CONT(0.95) WITHIN GROUP (ORDER BY lg_write_rq)) AS lg_write_rq_p95,
        ROUND(PERCENTILE_CONT(0.95) WITHIN GROUP (ORDER BY no_iowait)) AS no_iowait_p95,
        ROUND(PERCENTILE_CONT(0.95) WITHIN GROUP (ORDER BY tot_watime)) AS tot_watime_p95,
        ROUND(MAX(sm_read_mb)) AS sm_read_mb_p100,
        ROUND(MAX(sm_write_mb)) AS sm_write_mb_p100,
        ROUND(MAX(sm_read_rq)) AS sm_read_rq_p100,
        ROUND(MAX(sm_write_rq)) AS sm_write_rq_p100,
        ROUND(MAX(lg_read_mb)) AS lg_read_mb_p100,
        ROUND(MAX(lg_write_mb)) AS lg_write_mb_p100,
        ROUND(MAX(lg_read_rq)) AS lg_read_rq_p100,
        ROUND(MAX(lg_write_rq)) AS lg_write_rq_p100,
        ROUND(MAX(no_iowait)) AS no_iowait_p100,
        ROUND(MAX(tot_watime)) AS tot_watime_p100
    FROM vrawiof
    GROUP BY dbid, instance_number, hour, function_name
    ORDER BY dbid, instance_number, function_name, hour
    """


def get_awr_source_connections_query():
    """Source connection/session workload profile from AWR active session history.
    Mirrors DMA awr/sourceconn.sql.
    Profiles workload by program, module, machine and SQL command type."""
    return """
    SELECT
        has.dbid,
        has.instance_number,
        TO_CHAR(dhsnap.begin_interval_time, 'HH24') AS hour,
        REPLACE(has.program, '|', '_') AS program,
        REPLACE(has.module, '|', '_') AS module,
        REPLACE(has.machine, '|', '_') AS machine,
        scmd.command_name,
        COUNT(1) AS cnt
    FROM dba_hist_active_sess_history has
    INNER JOIN dba_hist_snapshot dhsnap
        ON has.snap_id = dhsnap.snap_id
        AND has.instance_number = dhsnap.instance_number
        AND has.dbid = dhsnap.dbid
    INNER JOIN v$sqlcommand scmd
        ON has.sql_opcode = scmd.command_type
    WHERE dhsnap.begin_interval_time >= SYSDATE - 30
      AND has.session_type = 'FOREGROUND'
    GROUP BY
        has.dbid, has.instance_number,
        TO_CHAR(dhsnap.begin_interval_time, 'HH24'),
        has.program, has.module, has.machine, scmd.command_name
    ORDER BY hour, cnt DESC
    """


def get_awr_sql_stats_query():
    """Top SQL statements by elapsed time from AWR.
    Mirrors DMA awr/sqlstats.sql.
    Returns top 300 SQL by total elapsed time with per-execution averages."""
    return """
    SELECT
        b.dbid,
        b.instance_number,
        TO_CHAR(a.force_matching_signature) AS force_matching_signature,
        MIN(a.sql_id) AS sql_id,
        ROUND(SUM(a.executions_delta)) AS total_executions,
        ROUND(SUM(a.px_servers_execs_delta)) AS total_px_servers_execs,
        ROUND(SUM(a.elapsed_time_total)) AS elapsed_time_total,
        ROUND(SUM(a.disk_reads_delta)) AS disk_reads_total,
        ROUND(SUM(a.physical_read_bytes_delta)) AS physical_read_bytes_total,
        ROUND(SUM(a.physical_write_bytes_delta)) AS physical_write_bytes_total,
        ROUND(SUM(a.io_offload_elig_bytes_delta)) AS io_offload_elig_bytes_total,
        ROUND(SUM(a.io_interconnect_bytes_delta)) AS io_interconnect_bytes_total,
        ROUND(SUM(a.optimized_physical_reads_delta)) AS optimized_physical_reads_total,
        ROUND(SUM(a.cell_uncompressed_bytes_delta)) AS cell_uncompressed_bytes_total,
        ROUND(SUM(a.io_offload_return_bytes_delta)) AS io_offload_return_bytes_total,
        ROUND(SUM(a.direct_writes_delta)) AS direct_writes_total,
        TRUNC(DECODE(SUM(a.executions_delta), 0, 0,
            (SUM(a.end_of_fetch_count_delta) * 100) / SUM(a.executions_delta))) AS perc_exec_finished,
        TRUNC(DECODE(SUM(a.executions_delta), 0, 0,
            SUM(a.rows_processed_delta) / SUM(a.executions_delta))) AS avg_rows,
        TRUNC(DECODE(SUM(a.executions_delta), 0, 0,
            SUM(a.disk_reads_delta) / SUM(a.executions_delta))) AS avg_disk_reads,
        TRUNC(DECODE(SUM(a.executions_delta), 0, 0,
            SUM(a.buffer_gets_delta) / SUM(a.executions_delta))) AS avg_buffer_gets,
        TRUNC(DECODE(SUM(a.executions_delta), 0, 0,
            SUM(a.cpu_time_delta) / SUM(a.executions_delta))) AS avg_cpu_time_us,
        TRUNC(DECODE(SUM(a.executions_delta), 0, 0,
            SUM(a.elapsed_time_delta) / SUM(a.executions_delta))) AS avg_elapsed_us,
        TRUNC(DECODE(SUM(a.executions_delta), 0, 0,
            SUM(a.iowait_delta) / SUM(a.executions_delta))) AS avg_iowait_us,
        TRUNC(DECODE(SUM(a.executions_delta), 0, 0,
            SUM(a.clwait_delta) / SUM(a.executions_delta))) AS avg_clwait_us,
        TRUNC(DECODE(SUM(a.executions_delta), 0, 0,
            SUM(a.apwait_delta) / SUM(a.executions_delta))) AS avg_apwait_us,
        TRUNC(DECODE(SUM(a.executions_delta), 0, 0,
            SUM(a.ccwait_delta) / SUM(a.executions_delta))) AS avg_ccwait_us,
        TRUNC(DECODE(SUM(a.executions_delta), 0, 0,
            SUM(a.plsexec_time_delta) / SUM(a.executions_delta))) AS avg_plsexec_us,
        TRUNC(DECODE(SUM(a.executions_delta), 0, 0,
            SUM(a.javexec_time_delta) / SUM(a.executions_delta))) AS avg_javexec_us
    FROM dba_hist_sqlstat a
    JOIN dba_hist_snapshot b
        ON a.snap_id = b.snap_id AND a.instance_number = b.instance_number AND a.dbid = b.dbid
    WHERE b.begin_interval_time >= SYSDATE - 30
    GROUP BY b.dbid, b.instance_number, a.force_matching_signature
    ORDER BY elapsed_time_total DESC
    FETCH FIRST 300 ROWS ONLY
    """


def get_awr_sql_stats_11g_query():
    """Top SQL statements by elapsed time from AWR for Oracle 11.1.
    Mirrors DMA awr/sqlstats111.sql.
    Columns not available in 11.1 are returned as -1."""
    return """
    SELECT
        b.dbid,
        b.instance_number,
        TO_CHAR(a.force_matching_signature) AS force_matching_signature,
        MIN(a.sql_id) AS sql_id,
        ROUND(SUM(a.executions_delta)) AS total_executions,
        ROUND(SUM(a.px_servers_execs_delta)) AS total_px_servers_execs,
        ROUND(SUM(a.elapsed_time_total)) AS elapsed_time_total,
        ROUND(SUM(a.disk_reads_delta)) AS disk_reads_total,
        -1 AS physical_read_bytes_total,
        -1 AS physical_write_bytes_total,
        -1 AS io_offload_elig_bytes_total,
        -1 AS io_interconnect_bytes_total,
        -1 AS optimized_physical_reads_total,
        -1 AS cell_uncompressed_bytes_total,
        -1 AS io_offload_return_bytes_total,
        ROUND(SUM(a.direct_writes_delta)) AS direct_writes_total,
        TRUNC(DECODE(SUM(a.executions_delta), 0, 0,
            (SUM(a.end_of_fetch_count_delta) * 100) / SUM(a.executions_delta))) AS perc_exec_finished,
        TRUNC(DECODE(SUM(a.executions_delta), 0, 0,
            SUM(a.rows_processed_delta) / SUM(a.executions_delta))) AS avg_rows,
        TRUNC(DECODE(SUM(a.executions_delta), 0, 0,
            SUM(a.disk_reads_delta) / SUM(a.executions_delta))) AS avg_disk_reads,
        TRUNC(DECODE(SUM(a.executions_delta), 0, 0,
            SUM(a.buffer_gets_delta) / SUM(a.executions_delta))) AS avg_buffer_gets,
        TRUNC(DECODE(SUM(a.executions_delta), 0, 0,
            SUM(a.cpu_time_delta) / SUM(a.executions_delta))) AS avg_cpu_time_us,
        TRUNC(DECODE(SUM(a.executions_delta), 0, 0,
            SUM(a.elapsed_time_delta) / SUM(a.executions_delta))) AS avg_elapsed_us,
        TRUNC(DECODE(SUM(a.executions_delta), 0, 0,
            SUM(a.iowait_delta) / SUM(a.executions_delta))) AS avg_iowait_us,
        TRUNC(DECODE(SUM(a.executions_delta), 0, 0,
            SUM(a.clwait_delta) / SUM(a.executions_delta))) AS avg_clwait_us,
        TRUNC(DECODE(SUM(a.executions_delta), 0, 0,
            SUM(a.apwait_delta) / SUM(a.executions_delta))) AS avg_apwait_us,
        TRUNC(DECODE(SUM(a.executions_delta), 0, 0,
            SUM(a.ccwait_delta) / SUM(a.executions_delta))) AS avg_ccwait_us,
        TRUNC(DECODE(SUM(a.executions_delta), 0, 0,
            SUM(a.plsexec_time_delta) / SUM(a.executions_delta))) AS avg_plsexec_us,
        TRUNC(DECODE(SUM(a.executions_delta), 0, 0,
            SUM(a.javexec_time_delta) / SUM(a.executions_delta))) AS avg_javexec_us
    FROM dba_hist_sqlstat a
    JOIN dba_hist_snapshot b
        ON a.snap_id = b.snap_id AND a.instance_number = b.instance_number AND a.dbid = b.dbid
    WHERE b.begin_interval_time >= SYSDATE - 30
    GROUP BY b.dbid, b.instance_number, a.force_matching_signature
    ORDER BY elapsed_time_total DESC
    FETCH FIRST 300 ROWS ONLY
    """


def get_app_cloud_detection_pdb_query():
    """Detect well-known enterprise applications per PDB using CDB-prefixed views.
    Mirrors DMA app_cloud_pdb.sql / app_schemas.sql with cdbjoin on con_id."""
    return """
    SELECT
        p.con_id,
        p.name AS pdb_name,
        (SELECT owner
         FROM cdb_tab_columns
         WHERE table_name = 'FND_PRODUCT_GROUPS'
           AND column_name = 'RELEASE_NAME'
           AND data_type = 'VARCHAR2'
           AND con_id = p.con_id
           AND ROWNUM = 1) AS ebs_owner,
        (SELECT owner
         FROM cdb_tab_columns
         WHERE table_name = 'S_REPOSITORY'
           AND column_name = 'ROW_ID'
           AND data_type = 'VARCHAR2'
           AND con_id = p.con_id
           AND ROWNUM = 1) AS siebel_owner,
        (SELECT owner
         FROM cdb_tab_columns
         WHERE table_name = 'PSSTATUS'
           AND column_name = 'TOOLSREL'
           AND data_type = 'VARCHAR2'
           AND con_id = p.con_id
           AND ROWNUM = 1) AS psft_owner,
        (SELECT 'Y'
         FROM cdb_objects
         WHERE owner = 'RDSADMIN'
           AND object_name = 'RDAADMIN_UTIL'
           AND con_id = p.con_id
           AND ROWNUM = 1) AS rds_flag,
        (SELECT 'Y'
         FROM cdb_views
         WHERE view_name = 'OCI_AUTONOMOUS_DATABASES'
           AND con_id = p.con_id
           AND ROWNUM = 1) AS oci_autonomous_flag,
        (SELECT 'Y'
         FROM cdb_objects
         WHERE object_name = 'DBMS_CLOUD'
           AND con_id = p.con_id
           AND ROWNUM = 1) AS dbms_cloud_pkg_installed,
        (SELECT 'Y'
         FROM cdb_objects
         WHERE object_name = 'WWV_FLOW'
           AND object_type = 'PACKAGE'
           AND con_id = p.con_id
           AND ROWNUM = 1
           AND EXISTS (SELECT 1 FROM cdb_users WHERE username = 'APEX_PUBLIC_USER' AND con_id = p.con_id)) AS apex_installed,
        (SELECT owner
         FROM cdb_tab_columns
         WHERE table_name = 'DD02T'
           AND column_name = 'DDLANGUAGE'
           AND data_type = 'VARCHAR2'
           AND con_id = p.con_id
           AND ROWNUM = 1) AS sap_owner
    FROM v$pdbs p
    ORDER BY p.con_id
    """


# ---------------------------------------------------------------------------
# Statspack-equivalent queries
# These mirror the AWR extracts but use STATS$* tables for databases without
# the Diagnostics Pack license.  All cumulative counters use LAG-based delta
# computation since Statspack does not provide pre-computed deltas.
# ---------------------------------------------------------------------------

def get_statspack_cmd_types_query():
    """Historical SQL command type distribution from Statspack.
    Mirrors DMA statspack/awrhistcmdtypes.sql."""
    return """
    WITH vdeltas AS (
        SELECT
            s.snap_id, s.dbid, s.instance_number,
            s.text_subset, s.old_hash_value, s.command_type,
            s.force_matching_signature, s.sql_id,
            NVL(DECODE(GREATEST(s.executions, NVL(LAG(s.executions)
                OVER (PARTITION BY s.dbid, s.instance_number, s.text_subset, s.old_hash_value, s.command_type, s.force_matching_signature ORDER BY s.snap_id), 0)),
                s.executions, s.executions - LAG(s.executions)
                    OVER (PARTITION BY s.dbid, s.instance_number, s.text_subset, s.old_hash_value, s.command_type, s.force_matching_signature ORDER BY s.snap_id), 0), 0) AS delta_executions,
            NVL(DECODE(GREATEST(s.elapsed_time, NVL(LAG(s.elapsed_time)
                OVER (PARTITION BY s.dbid, s.instance_number, s.text_subset, s.old_hash_value, s.command_type, s.force_matching_signature ORDER BY s.snap_id), 0)),
                s.elapsed_time, s.elapsed_time - LAG(s.elapsed_time)
                    OVER (PARTITION BY s.dbid, s.instance_number, s.text_subset, s.old_hash_value, s.command_type, s.force_matching_signature ORDER BY s.snap_id), 0), 0) AS delta_elapsed_time,
            NVL(DECODE(GREATEST(s.buffer_gets, NVL(LAG(s.buffer_gets)
                OVER (PARTITION BY s.dbid, s.instance_number, s.text_subset, s.old_hash_value, s.command_type, s.force_matching_signature ORDER BY s.snap_id), 0)),
                s.buffer_gets, s.buffer_gets - LAG(s.buffer_gets)
                    OVER (PARTITION BY s.dbid, s.instance_number, s.text_subset, s.old_hash_value, s.command_type, s.force_matching_signature ORDER BY s.snap_id), 0), 0) AS delta_buffer_gets,
            NVL(DECODE(GREATEST(s.rows_processed, NVL(LAG(s.rows_processed)
                OVER (PARTITION BY s.dbid, s.instance_number, s.text_subset, s.old_hash_value, s.command_type, s.force_matching_signature ORDER BY s.snap_id), 0)),
                s.rows_processed, s.rows_processed - LAG(s.rows_processed)
                    OVER (PARTITION BY s.dbid, s.instance_number, s.text_subset, s.old_hash_value, s.command_type, s.force_matching_signature ORDER BY s.snap_id), 0), 0) AS delta_rows_processed,
            NVL(DECODE(GREATEST(s.cpu_time, NVL(LAG(s.cpu_time)
                OVER (PARTITION BY s.dbid, s.instance_number, s.text_subset, s.old_hash_value, s.command_type, s.force_matching_signature ORDER BY s.snap_id), 0)),
                s.cpu_time, s.cpu_time - LAG(s.cpu_time)
                    OVER (PARTITION BY s.dbid, s.instance_number, s.text_subset, s.old_hash_value, s.command_type, s.force_matching_signature ORDER BY s.snap_id), 0), 0) AS delta_cpu_time,
            NVL(DECODE(GREATEST(s.user_io_wait_time, NVL(LAG(s.user_io_wait_time)
                OVER (PARTITION BY s.dbid, s.instance_number, s.text_subset, s.old_hash_value, s.command_type, s.force_matching_signature ORDER BY s.snap_id), 0)),
                s.user_io_wait_time, s.user_io_wait_time - LAG(s.user_io_wait_time)
                    OVER (PARTITION BY s.dbid, s.instance_number, s.text_subset, s.old_hash_value, s.command_type, s.force_matching_signature ORDER BY s.snap_id), 0), 0) AS delta_iowait,
            NVL(DECODE(GREATEST(s.cluster_wait_time, NVL(LAG(s.cluster_wait_time)
                OVER (PARTITION BY s.dbid, s.instance_number, s.text_subset, s.old_hash_value, s.command_type, s.force_matching_signature ORDER BY s.snap_id), 0)),
                s.cluster_wait_time, s.cluster_wait_time - LAG(s.cluster_wait_time)
                    OVER (PARTITION BY s.dbid, s.instance_number, s.text_subset, s.old_hash_value, s.command_type, s.force_matching_signature ORDER BY s.snap_id), 0), 0) AS delta_clwait,
            NVL(DECODE(GREATEST(s.application_wait_time, NVL(LAG(s.application_wait_time)
                OVER (PARTITION BY s.dbid, s.instance_number, s.text_subset, s.old_hash_value, s.command_type, s.force_matching_signature ORDER BY s.snap_id), 0)),
                s.application_wait_time, s.application_wait_time - LAG(s.application_wait_time)
                    OVER (PARTITION BY s.dbid, s.instance_number, s.text_subset, s.old_hash_value, s.command_type, s.force_matching_signature ORDER BY s.snap_id), 0), 0) AS delta_apwait,
            NVL(DECODE(GREATEST(s.concurrency_wait_time, NVL(LAG(s.concurrency_wait_time)
                OVER (PARTITION BY s.dbid, s.instance_number, s.text_subset, s.old_hash_value, s.command_type, s.force_matching_signature ORDER BY s.snap_id), 0)),
                s.concurrency_wait_time, s.concurrency_wait_time - LAG(s.concurrency_wait_time)
                    OVER (PARTITION BY s.dbid, s.instance_number, s.text_subset, s.old_hash_value, s.command_type, s.force_matching_signature ORDER BY s.snap_id), 0), 0) AS delta_ccwait,
            NVL(DECODE(GREATEST(s.plsql_exec_time, NVL(LAG(s.plsql_exec_time)
                OVER (PARTITION BY s.dbid, s.instance_number, s.text_subset, s.old_hash_value, s.command_type, s.force_matching_signature ORDER BY s.snap_id), 0)),
                s.plsql_exec_time, s.plsql_exec_time - LAG(s.plsql_exec_time)
                    OVER (PARTITION BY s.dbid, s.instance_number, s.text_subset, s.old_hash_value, s.command_type, s.force_matching_signature ORDER BY s.snap_id), 0), 0) AS delta_plsexec_time
        FROM stats$sql_summary s
    )
    SELECT
        TO_CHAR(sn.snap_time, 'HH24') AS hh,
        ss.command_type,
        aa.name AS command_name,
        COUNT(1) AS cnt,
        ROUND(AVG(ss.delta_buffer_gets)) AS avg_buffer_gets,
        ROUND(AVG(ss.delta_elapsed_time)) AS avg_elapsed_time,
        ROUND(AVG(ss.delta_rows_processed)) AS avg_rows_processed,
        ROUND(AVG(ss.delta_executions)) AS avg_executions,
        ROUND(AVG(ss.delta_cpu_time)) AS avg_cpu_time,
        ROUND(AVG(ss.delta_iowait)) AS avg_iowait,
        ROUND(AVG(ss.delta_clwait)) AS avg_clwait,
        ROUND(AVG(ss.delta_apwait)) AS avg_apwait,
        ROUND(AVG(ss.delta_ccwait)) AS avg_ccwait,
        ROUND(AVG(ss.delta_plsexec_time)) AS avg_plsexec_time
    FROM vdeltas ss
    JOIN stats$snapshot sn
        ON ss.dbid = sn.dbid AND ss.snap_id = sn.snap_id AND ss.instance_number = sn.instance_number
    LEFT OUTER JOIN audit_actions aa ON ss.command_type = aa.action
    WHERE sn.snap_time >= SYSDATE - 30
    GROUP BY TO_CHAR(sn.snap_time, 'HH24'), ss.command_type, aa.name
    ORDER BY hh, avg_elapsed_time DESC
    """


def get_statspack_osstat_query():
    """Historical OS-level statistics from Statspack with percentiles.
    Mirrors DMA statspack/awrhistosstat.sql."""
    return """
    WITH v_osstat_all AS (
        SELECT
            os.dbid,
            os.instance_number,
            TO_CHAR(snap.snap_time, 'HH24') AS hh24,
            osname.stat_name,
            os.value AS cumulative_value,
            NVL(DECODE(GREATEST(os.value, NVL(LAG(os.value)
                OVER (PARTITION BY os.dbid, os.instance_number, osname.stat_name ORDER BY os.snap_id), 0)),
                os.value, os.value - LAG(os.value)
                    OVER (PARTITION BY os.dbid, os.instance_number, osname.stat_name ORDER BY os.snap_id),
                0), 0) AS delta_value,
            (snap.snap_time - LAG(snap.snap_time) OVER (PARTITION BY os.dbid, os.instance_number, osname.stat_name ORDER BY os.snap_id)) * 86400 AS snap_total_secs
        FROM stats$osstat os
        INNER JOIN stats$snapshot snap
            ON os.snap_id = snap.snap_id AND os.instance_number = snap.instance_number AND os.dbid = snap.dbid
        INNER JOIN stats$osstatname osname
            ON os.osstat_id = osname.osstat_id
        WHERE snap.snap_time >= SYSDATE - 30
    )
    SELECT
        dbid, instance_number, hh24, stat_name,
        ROUND(SUM(snap_total_secs)) AS hh24_total_secs,
        ROUND(AVG(cumulative_value)) AS cumulative_value,
        ROUND(AVG(delta_value)) AS avg_value,
        ROUND(STATS_MODE(delta_value)) AS mode_value,
        ROUND(MEDIAN(delta_value)) AS median_value,
        ROUND(PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY delta_value)) AS perc50,
        ROUND(PERCENTILE_CONT(0.75) WITHIN GROUP (ORDER BY delta_value)) AS perc75,
        ROUND(PERCENTILE_CONT(0.90) WITHIN GROUP (ORDER BY delta_value)) AS perc90,
        ROUND(PERCENTILE_CONT(0.95) WITHIN GROUP (ORDER BY delta_value)) AS perc95,
        ROUND(MAX(delta_value)) AS perc100,
        ROUND(MIN(delta_value)) AS min_value,
        ROUND(MAX(delta_value)) AS max_value,
        ROUND(SUM(delta_value)) AS sum_value,
        COUNT(1) AS cnt
    FROM v_osstat_all
    GROUP BY dbid, instance_number, hh24, stat_name
    ORDER BY dbid, instance_number, stat_name, hh24
    """


def get_statspack_sysmetric_history_query():
    """Historical system metric history from Statspack.
    Mirrors DMA statspack/awrhistsysmetrichist.sql.
    Uses STATS$SYSSTAT as Statspack lacks a dedicated metric history table."""
    return """
    WITH vraw AS (
        SELECT
            s.snap_id, s.dbid, s.instance_number, s.name,
            NVL(DECODE(GREATEST(s.value, NVL(LAG(s.value)
                OVER (PARTITION BY s.dbid, s.instance_number, s.name ORDER BY s.snap_id), 0)),
                s.value, s.value - LAG(s.value)
                    OVER (PARTITION BY s.dbid, s.instance_number, s.name ORDER BY s.snap_id),
                0), 0) AS delta_value
        FROM perfstat.stats$sysstat s
    )
    SELECT
        hsm.dbid,
        hsm.instance_number,
        TO_CHAR(dhsnap.snap_time, 'HH24') AS hour,
        hsm.name AS metric_name,
        NULL AS metric_unit,
        ROUND(AVG(hsm.delta_value)) AS avg_value,
        ROUND(STATS_MODE(hsm.delta_value)) AS mode_value,
        ROUND(MEDIAN(hsm.delta_value)) AS median_value,
        ROUND(MIN(hsm.delta_value)) AS min_value,
        ROUND(MAX(hsm.delta_value)) AS max_value,
        ROUND(SUM(hsm.delta_value)) AS sum_value,
        ROUND(PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY hsm.delta_value)) AS perc50,
        ROUND(PERCENTILE_CONT(0.75) WITHIN GROUP (ORDER BY hsm.delta_value)) AS perc75,
        ROUND(PERCENTILE_CONT(0.90) WITHIN GROUP (ORDER BY hsm.delta_value)) AS perc90,
        ROUND(PERCENTILE_CONT(0.95) WITHIN GROUP (ORDER BY hsm.delta_value)) AS perc95,
        ROUND(MAX(hsm.delta_value)) AS perc100
    FROM vraw hsm
    INNER JOIN stats$snapshot dhsnap
        ON hsm.snap_id = dhsnap.snap_id AND hsm.instance_number = dhsnap.instance_number AND hsm.dbid = dhsnap.dbid
    WHERE dhsnap.snap_time >= SYSDATE - 30
    GROUP BY hsm.dbid, hsm.instance_number, TO_CHAR(dhsnap.snap_time, 'HH24'), hsm.name
    ORDER BY hsm.dbid, hsm.instance_number, hsm.name, hour
    """


def get_statspack_sysmetric_summary_query():
    """System metric summary from Statspack with P95 estimation.
    Mirrors DMA statspack/awrhistsysmetricsumm.sql.
    Computes P95 as AVG + 2*STDDEV since Statspack lacks pre-summarized metrics."""
    return """
    WITH vraw AS (
        SELECT
            s.snap_id, s.dbid, s.instance_number, s.name,
            NVL(DECODE(GREATEST(s.value, NVL(LAG(s.value)
                OVER (PARTITION BY s.dbid, s.instance_number, s.name ORDER BY s.snap_id), 0)),
                s.value, s.value - LAG(s.value)
                    OVER (PARTITION BY s.dbid, s.instance_number, s.name ORDER BY s.snap_id),
                0), 0) AS delta_value
        FROM perfstat.stats$sysstat s
    ),
    vsysmetricsumm AS (
        SELECT
            hsm.dbid,
            hsm.instance_number,
            TO_CHAR(dhsnap.snap_time, 'HH24') AS hour,
            hsm.name AS metric_name,
            NULL AS metric_unit,
            AVG(hsm.delta_value) OVER (PARTITION BY hsm.dbid, hsm.instance_number, TO_CHAR(dhsnap.snap_time, 'HH24'), hsm.name)
                + (2 * STDDEV(hsm.delta_value) OVER (PARTITION BY hsm.dbid, hsm.instance_number, TO_CHAR(dhsnap.snap_time, 'HH24'), hsm.name)) AS perc95
        FROM vraw hsm
        INNER JOIN stats$snapshot dhsnap
            ON hsm.snap_id = dhsnap.snap_id AND hsm.instance_number = dhsnap.instance_number AND hsm.dbid = dhsnap.dbid
        WHERE dhsnap.snap_time >= SYSDATE - 30
    )
    SELECT
        dbid, instance_number, hour, metric_name, metric_unit,
        ROUND(AVG(perc95)) AS avg_value,
        ROUND(STATS_MODE(perc95)) AS mode_value,
        ROUND(MEDIAN(perc95)) AS median_value,
        ROUND(MIN(perc95)) AS min_value,
        ROUND(MAX(perc95)) AS max_value,
        ROUND(SUM(perc95)) AS sum_value,
        ROUND(PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY perc95)) AS perc50,
        ROUND(PERCENTILE_CONT(0.75) WITHIN GROUP (ORDER BY perc95)) AS perc75,
        ROUND(PERCENTILE_CONT(0.90) WITHIN GROUP (ORDER BY perc95)) AS perc90,
        ROUND(PERCENTILE_CONT(0.95) WITHIN GROUP (ORDER BY perc95)) AS perc95,
        ROUND(MAX(perc95)) AS perc100
    FROM vsysmetricsumm
    GROUP BY dbid, instance_number, hour, metric_name, metric_unit
    ORDER BY dbid, instance_number, metric_name, hour
    """


def get_statspack_snap_details_query():
    """Statspack snapshot interval metadata and timing analysis.
    Mirrors DMA statspack/awrsnapdetails.sql."""
    return """
    WITH vsnaps AS (
        SELECT
            s.snap_id,
            s.dbid,
            s.instance_number,
            s.snap_time,
            TO_CHAR(s.snap_time, 'HH24') AS hour,
            NVL(DECODE(GREATEST(s.snap_time, NVL(LAG(s.snap_time)
                OVER (PARTITION BY s.dbid, s.instance_number ORDER BY s.snap_id), SYSDATE)),
                s.snap_time, s.snap_time - LAG(s.snap_time)
                    OVER (PARTITION BY s.dbid, s.instance_number ORDER BY s.snap_id),
                0), 0) * 86400 AS snaps_diff_secs,
            s.startup_time,
            LAG(s.startup_time, 1) OVER (PARTITION BY s.dbid, s.instance_number ORDER BY s.snap_id) AS lag_startup_time
        FROM stats$snapshot s
        WHERE s.snap_time >= SYSDATE - 30
    )
    SELECT
        dbid, instance_number, hour,
        MIN(snap_id) AS min_snap_id,
        MAX(snap_id) AS max_snap_id,
        TO_CHAR(MIN(snap_time), 'YYYY-MM-DD HH24:MI:SS') AS min_begin_interval_time,
        TO_CHAR(MAX(snap_time), 'YYYY-MM-DD HH24:MI:SS') AS max_begin_interval_time,
        COUNT(1) AS cnt,
        ROUND(SUM(snaps_diff_secs)) AS sum_snaps_diff_secs,
        ROUND(AVG(snaps_diff_secs)) AS avg_snaps_diff_secs,
        ROUND(MEDIAN(snaps_diff_secs)) AS median_snaps_diff_secs,
        ROUND(STATS_MODE(snaps_diff_secs)) AS mode_snaps_diff_secs,
        ROUND(MIN(snaps_diff_secs)) AS min_snaps_diff_secs,
        ROUND(MAX(snaps_diff_secs)) AS max_snaps_diff_secs
    FROM vsnaps
    WHERE startup_time = lag_startup_time
    GROUP BY dbid, instance_number, hour
    ORDER BY dbid, instance_number, hour
    """


def get_statspack_sysstat_query():
    """Historical system statistics from Statspack with percentile distributions.
    Mirrors DMA statspack/dbahistsysstat.sql."""
    return """
    WITH vraw AS (
        SELECT
            s.dbid,
            s.instance_number,
            TO_CHAR(s.snap_time, 'HH24') AS hour,
            g.name AS stat_name,
            NVL(DECODE(GREATEST(g.value, NVL(LAG(g.value)
                OVER (PARTITION BY s.dbid, s.instance_number, g.name ORDER BY s.snap_id), 0)),
                g.value, g.value - LAG(g.value)
                    OVER (PARTITION BY s.dbid, s.instance_number, g.name ORDER BY s.snap_id),
                0), 0) AS value
        FROM stats$snapshot s
        JOIN stats$sysstat g
            ON s.snap_id = g.snap_id AND s.instance_number = g.instance_number AND s.dbid = g.dbid
        WHERE s.snap_time >= SYSDATE - 30
          AND (LOWER(g.name) LIKE '%db%time%'
            OR LOWER(g.name) LIKE '%redo%time%'
            OR LOWER(g.name) LIKE '%parse%time%'
            OR LOWER(g.name) LIKE 'phy%'
            OR LOWER(g.name) LIKE '%cpu%'
            OR LOWER(g.name) LIKE 'cell%phy%'
            OR LOWER(g.name) LIKE 'cell%smart%'
            OR LOWER(g.name) LIKE 'cell%mem%'
            OR LOWER(g.name) LIKE 'cell%flash%'
            OR LOWER(g.name) LIKE 'cell%uncompressed%'
            OR LOWER(g.name) LIKE '%db%block%'
            OR LOWER(g.name) LIKE '%execute%'
            OR LOWER(g.name) LIKE 'user%')
    )
    SELECT
        dbid, instance_number, hour, stat_name,
        COUNT(1) AS cnt,
        ROUND(AVG(value)) AS avg_value,
        ROUND(STATS_MODE(value)) AS mode_value,
        ROUND(MEDIAN(value)) AS median_value,
        ROUND(MIN(value)) AS min_value,
        ROUND(MAX(value)) AS max_value,
        ROUND(SUM(value)) AS sum_value,
        ROUND(PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY value)) AS perc50,
        ROUND(PERCENTILE_CONT(0.75) WITHIN GROUP (ORDER BY value)) AS perc75,
        ROUND(PERCENTILE_CONT(0.90) WITHIN GROUP (ORDER BY value)) AS perc90,
        ROUND(PERCENTILE_CONT(0.95) WITHIN GROUP (ORDER BY value)) AS perc95,
        ROUND(MAX(value)) AS perc100
    FROM vraw
    GROUP BY dbid, instance_number, hour, stat_name
    ORDER BY dbid, instance_number, stat_name, hour
    """


def get_statspack_sys_time_model_query():
    """Historical system time model data from Statspack with percentile distributions.
    Mirrors DMA statspack/dbahistsystimemodel.sql."""
    return """
    WITH vraw AS (
        SELECT
            s.dbid,
            s.instance_number,
            TO_CHAR(s.snap_time, 'HH24') AS hour,
            n.stat_name,
            NVL(DECODE(GREATEST(g.value, NVL(LAG(g.value)
                OVER (PARTITION BY s.dbid, s.instance_number, n.stat_name ORDER BY s.snap_id), 0)),
                g.value, g.value - LAG(g.value)
                    OVER (PARTITION BY s.dbid, s.instance_number, n.stat_name ORDER BY s.snap_id),
                0), 0) AS value
        FROM stats$snapshot s
        JOIN stats$sys_time_model g
            ON s.snap_id = g.snap_id AND s.instance_number = g.instance_number AND s.dbid = g.dbid
        JOIN stats$time_model_statname n
            ON g.stat_id = n.stat_id
        WHERE s.snap_time >= SYSDATE - 30
    )
    SELECT
        dbid, instance_number, hour, stat_name,
        COUNT(1) AS cnt,
        ROUND(AVG(value)) AS avg_value,
        ROUND(STATS_MODE(value)) AS mode_value,
        ROUND(MEDIAN(value)) AS median_value,
        ROUND(MIN(value)) AS min_value,
        ROUND(MAX(value)) AS max_value,
        ROUND(SUM(value)) AS sum_value,
        ROUND(PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY value)) AS perc50,
        ROUND(PERCENTILE_CONT(0.75) WITHIN GROUP (ORDER BY value)) AS perc75,
        ROUND(PERCENTILE_CONT(0.90) WITHIN GROUP (ORDER BY value)) AS perc90,
        ROUND(PERCENTILE_CONT(0.95) WITHIN GROUP (ORDER BY value)) AS perc95,
        ROUND(MAX(value)) AS perc100
    FROM vraw
    GROUP BY dbid, instance_number, hour, stat_name
    ORDER BY dbid, instance_number, stat_name, hour
    """


def get_statspack_io_events_query():
    """Historical I/O wait event statistics from Statspack with P95/P100.
    Mirrors DMA statspack/ioevents.sql.
    Joins V$EVENT_NAME for wait_class since STATS$SYSTEM_EVENT lacks it."""
    return """
    WITH vrawev AS (
        SELECT
            sev.dbid,
            sev.instance_number,
            TO_CHAR(dhsnap.snap_time, 'HH24') AS hour,
            en.wait_class,
            sev.event AS event_name,
            NVL(DECODE(GREATEST(sev.total_waits, NVL(LAG(sev.total_waits)
                OVER (PARTITION BY sev.dbid, sev.instance_number, sev.event ORDER BY sev.snap_id), 0)),
                sev.total_waits, sev.total_waits - LAG(sev.total_waits)
                    OVER (PARTITION BY sev.dbid, sev.instance_number, sev.event ORDER BY sev.snap_id), 0), 0) AS tot_waits_delta,
            NVL(DECODE(GREATEST(sev.total_timeouts, NVL(LAG(sev.total_timeouts)
                OVER (PARTITION BY sev.dbid, sev.instance_number, sev.event ORDER BY sev.snap_id), 0)),
                sev.total_timeouts, sev.total_timeouts - LAG(sev.total_timeouts)
                    OVER (PARTITION BY sev.dbid, sev.instance_number, sev.event ORDER BY sev.snap_id), 0), 0) AS tot_tout_delta,
            NVL(DECODE(GREATEST(sev.time_waited_micro, NVL(LAG(sev.time_waited_micro)
                OVER (PARTITION BY sev.dbid, sev.instance_number, sev.event ORDER BY sev.snap_id), 0)),
                sev.time_waited_micro, sev.time_waited_micro - LAG(sev.time_waited_micro)
                    OVER (PARTITION BY sev.dbid, sev.instance_number, sev.event ORDER BY sev.snap_id), 0), 0) AS time_wa_us_delta
        FROM stats$system_event sev
        INNER JOIN stats$snapshot dhsnap
            ON sev.snap_id = dhsnap.snap_id AND sev.instance_number = dhsnap.instance_number AND sev.dbid = dhsnap.dbid
        INNER JOIN v$event_name en ON en.name = sev.event
        WHERE dhsnap.snap_time >= SYSDATE - 30
          AND en.wait_class IN ('User I/O', 'System I/O', 'Commit')
    )
    SELECT
        dbid, instance_number, hour, wait_class, event_name,
        ROUND(PERCENTILE_CONT(0.95) WITHIN GROUP (ORDER BY tot_waits_delta)) AS tot_waits_p95,
        ROUND(PERCENTILE_CONT(0.95) WITHIN GROUP (ORDER BY tot_tout_delta)) AS tot_tout_p95,
        ROUND(PERCENTILE_CONT(0.95) WITHIN GROUP (ORDER BY time_wa_us_delta)) AS time_wa_us_p95,
        ROUND(MAX(tot_waits_delta)) AS tot_waits_p100,
        ROUND(MAX(tot_tout_delta)) AS tot_tout_p100,
        ROUND(MAX(time_wa_us_delta)) AS time_wa_us_p100
    FROM vrawev
    GROUP BY dbid, instance_number, hour, wait_class, event_name
    ORDER BY dbid, instance_number, hour, wait_class, event_name
    """


def get_statspack_io_function_query():
    """Historical I/O statistics by database function from Statspack.
    Mirrors DMA statspack/iofunction.sql.
    Joins STATS$IOSTAT_FUNCTION_NAME to resolve function_id to function_name."""
    return """
    WITH vrawiof AS (
        SELECT
            TO_CHAR(snap.snap_time, 'HH24') AS hour,
            iof.dbid, iof.instance_number, fn.function_name,
            NVL(DECODE(GREATEST(iof.small_read_megabytes, NVL(LAG(iof.small_read_megabytes)
                OVER (PARTITION BY iof.dbid, iof.instance_number, fn.function_name ORDER BY iof.snap_id), 0)),
                iof.small_read_megabytes, iof.small_read_megabytes - LAG(iof.small_read_megabytes)
                    OVER (PARTITION BY iof.dbid, iof.instance_number, fn.function_name ORDER BY iof.snap_id), 0), 0) AS sm_read_mb,
            NVL(DECODE(GREATEST(iof.small_write_megabytes, NVL(LAG(iof.small_write_megabytes)
                OVER (PARTITION BY iof.dbid, iof.instance_number, fn.function_name ORDER BY iof.snap_id), 0)),
                iof.small_write_megabytes, iof.small_write_megabytes - LAG(iof.small_write_megabytes)
                    OVER (PARTITION BY iof.dbid, iof.instance_number, fn.function_name ORDER BY iof.snap_id), 0), 0) AS sm_write_mb,
            NVL(DECODE(GREATEST(iof.small_read_reqs, NVL(LAG(iof.small_read_reqs)
                OVER (PARTITION BY iof.dbid, iof.instance_number, fn.function_name ORDER BY iof.snap_id), 0)),
                iof.small_read_reqs, iof.small_read_reqs - LAG(iof.small_read_reqs)
                    OVER (PARTITION BY iof.dbid, iof.instance_number, fn.function_name ORDER BY iof.snap_id), 0), 0) AS sm_read_rq,
            NVL(DECODE(GREATEST(iof.small_write_reqs, NVL(LAG(iof.small_write_reqs)
                OVER (PARTITION BY iof.dbid, iof.instance_number, fn.function_name ORDER BY iof.snap_id), 0)),
                iof.small_write_reqs, iof.small_write_reqs - LAG(iof.small_write_reqs)
                    OVER (PARTITION BY iof.dbid, iof.instance_number, fn.function_name ORDER BY iof.snap_id), 0), 0) AS sm_write_rq,
            NVL(DECODE(GREATEST(iof.large_read_megabytes, NVL(LAG(iof.large_read_megabytes)
                OVER (PARTITION BY iof.dbid, iof.instance_number, fn.function_name ORDER BY iof.snap_id), 0)),
                iof.large_read_megabytes, iof.large_read_megabytes - LAG(iof.large_read_megabytes)
                    OVER (PARTITION BY iof.dbid, iof.instance_number, fn.function_name ORDER BY iof.snap_id), 0), 0) AS lg_read_mb,
            NVL(DECODE(GREATEST(iof.large_write_megabytes, NVL(LAG(iof.large_write_megabytes)
                OVER (PARTITION BY iof.dbid, iof.instance_number, fn.function_name ORDER BY iof.snap_id), 0)),
                iof.large_write_megabytes, iof.large_write_megabytes - LAG(iof.large_write_megabytes)
                    OVER (PARTITION BY iof.dbid, iof.instance_number, fn.function_name ORDER BY iof.snap_id), 0), 0) AS lg_write_mb,
            NVL(DECODE(GREATEST(iof.large_read_reqs, NVL(LAG(iof.large_read_reqs)
                OVER (PARTITION BY iof.dbid, iof.instance_number, fn.function_name ORDER BY iof.snap_id), 0)),
                iof.large_read_reqs, iof.large_read_reqs - LAG(iof.large_read_reqs)
                    OVER (PARTITION BY iof.dbid, iof.instance_number, fn.function_name ORDER BY iof.snap_id), 0), 0) AS lg_read_rq,
            NVL(DECODE(GREATEST(iof.large_write_reqs, NVL(LAG(iof.large_write_reqs)
                OVER (PARTITION BY iof.dbid, iof.instance_number, fn.function_name ORDER BY iof.snap_id), 0)),
                iof.large_write_reqs, iof.large_write_reqs - LAG(iof.large_write_reqs)
                    OVER (PARTITION BY iof.dbid, iof.instance_number, fn.function_name ORDER BY iof.snap_id), 0), 0) AS lg_write_rq,
            NVL(DECODE(GREATEST(iof.number_of_waits, NVL(LAG(iof.number_of_waits)
                OVER (PARTITION BY iof.dbid, iof.instance_number, fn.function_name ORDER BY iof.snap_id), 0)),
                iof.number_of_waits, iof.number_of_waits - LAG(iof.number_of_waits)
                    OVER (PARTITION BY iof.dbid, iof.instance_number, fn.function_name ORDER BY iof.snap_id), 0), 0) AS no_iowait,
            NVL(DECODE(GREATEST(iof.wait_time, NVL(LAG(iof.wait_time)
                OVER (PARTITION BY iof.dbid, iof.instance_number, fn.function_name ORDER BY iof.snap_id), 0)),
                iof.wait_time, iof.wait_time - LAG(iof.wait_time)
                    OVER (PARTITION BY iof.dbid, iof.instance_number, fn.function_name ORDER BY iof.snap_id), 0), 0) AS tot_watime
        FROM stats$iostat_function iof
        INNER JOIN stats$snapshot snap
            ON iof.snap_id = snap.snap_id AND iof.instance_number = snap.instance_number AND iof.dbid = snap.dbid
        INNER JOIN stats$iostat_function_name fn
            ON fn.function_id = iof.function_id
        WHERE snap.snap_time >= SYSDATE - 30
    )
    SELECT
        dbid, instance_number, hour, function_name,
        ROUND(PERCENTILE_CONT(0.95) WITHIN GROUP (ORDER BY sm_read_mb)) AS sm_read_mb_p95,
        ROUND(PERCENTILE_CONT(0.95) WITHIN GROUP (ORDER BY sm_write_mb)) AS sm_write_mb_p95,
        ROUND(PERCENTILE_CONT(0.95) WITHIN GROUP (ORDER BY sm_read_rq)) AS sm_read_rq_p95,
        ROUND(PERCENTILE_CONT(0.95) WITHIN GROUP (ORDER BY sm_write_rq)) AS sm_write_rq_p95,
        ROUND(PERCENTILE_CONT(0.95) WITHIN GROUP (ORDER BY lg_read_mb)) AS lg_read_mb_p95,
        ROUND(PERCENTILE_CONT(0.95) WITHIN GROUP (ORDER BY lg_write_mb)) AS lg_write_mb_p95,
        ROUND(PERCENTILE_CONT(0.95) WITHIN GROUP (ORDER BY lg_read_rq)) AS lg_read_rq_p95,
        ROUND(PERCENTILE_CONT(0.95) WITHIN GROUP (ORDER BY lg_write_rq)) AS lg_write_rq_p95,
        ROUND(PERCENTILE_CONT(0.95) WITHIN GROUP (ORDER BY no_iowait)) AS no_iowait_p95,
        ROUND(PERCENTILE_CONT(0.95) WITHIN GROUP (ORDER BY tot_watime)) AS tot_watime_p95,
        ROUND(MAX(sm_read_mb)) AS sm_read_mb_p100,
        ROUND(MAX(sm_write_mb)) AS sm_write_mb_p100,
        ROUND(MAX(sm_read_rq)) AS sm_read_rq_p100,
        ROUND(MAX(sm_write_rq)) AS sm_write_rq_p100,
        ROUND(MAX(lg_read_mb)) AS lg_read_mb_p100,
        ROUND(MAX(lg_write_mb)) AS lg_write_mb_p100,
        ROUND(MAX(lg_read_rq)) AS lg_read_rq_p100,
        ROUND(MAX(lg_write_rq)) AS lg_write_rq_p100,
        ROUND(MAX(no_iowait)) AS no_iowait_p100,
        ROUND(MAX(tot_watime)) AS tot_watime_p100
    FROM vrawiof
    GROUP BY dbid, instance_number, hour, function_name
    ORDER BY dbid, instance_number, function_name, hour
    """


def get_statspack_sql_stats_query():
    """Top SQL statements by elapsed time from Statspack.
    Mirrors DMA statspack/sqlstats.sql.
    Computes deltas via LAG since STATS$SQL_SUMMARY stores cumulative counters.
    Exadata-specific columns are NULL (not available in Statspack)."""
    return """
    WITH vdeltas AS (
        SELECT
            s.snap_id, s.dbid, s.instance_number,
            s.text_subset, s.old_hash_value, s.command_type,
            s.force_matching_signature, s.sql_id,
            NVL(DECODE(GREATEST(s.executions, NVL(LAG(s.executions)
                OVER (PARTITION BY s.dbid, s.instance_number, s.text_subset, s.old_hash_value, s.command_type, s.force_matching_signature ORDER BY s.snap_id), 0)),
                s.executions, s.executions - LAG(s.executions)
                    OVER (PARTITION BY s.dbid, s.instance_number, s.text_subset, s.old_hash_value, s.command_type, s.force_matching_signature ORDER BY s.snap_id), 0), 0) AS delta_executions,
            NVL(DECODE(GREATEST(s.elapsed_time, NVL(LAG(s.elapsed_time)
                OVER (PARTITION BY s.dbid, s.instance_number, s.text_subset, s.old_hash_value, s.command_type, s.force_matching_signature ORDER BY s.snap_id), 0)),
                s.elapsed_time, s.elapsed_time - LAG(s.elapsed_time)
                    OVER (PARTITION BY s.dbid, s.instance_number, s.text_subset, s.old_hash_value, s.command_type, s.force_matching_signature ORDER BY s.snap_id), 0), 0) AS delta_elapsed_time,
            NVL(DECODE(GREATEST(s.disk_reads, NVL(LAG(s.disk_reads)
                OVER (PARTITION BY s.dbid, s.instance_number, s.text_subset, s.old_hash_value, s.command_type, s.force_matching_signature ORDER BY s.snap_id), 0)),
                s.disk_reads, s.disk_reads - LAG(s.disk_reads)
                    OVER (PARTITION BY s.dbid, s.instance_number, s.text_subset, s.old_hash_value, s.command_type, s.force_matching_signature ORDER BY s.snap_id), 0), 0) AS delta_disk_reads,
            NVL(DECODE(GREATEST(s.direct_writes, NVL(LAG(s.direct_writes)
                OVER (PARTITION BY s.dbid, s.instance_number, s.text_subset, s.old_hash_value, s.command_type, s.force_matching_signature ORDER BY s.snap_id), 0)),
                s.direct_writes, s.direct_writes - LAG(s.direct_writes)
                    OVER (PARTITION BY s.dbid, s.instance_number, s.text_subset, s.old_hash_value, s.command_type, s.force_matching_signature ORDER BY s.snap_id), 0), 0) AS delta_direct_writes,
            NVL(DECODE(GREATEST(s.end_of_fetch_count, NVL(LAG(s.end_of_fetch_count)
                OVER (PARTITION BY s.dbid, s.instance_number, s.text_subset, s.old_hash_value, s.command_type, s.force_matching_signature ORDER BY s.snap_id), 0)),
                s.end_of_fetch_count, s.end_of_fetch_count - LAG(s.end_of_fetch_count)
                    OVER (PARTITION BY s.dbid, s.instance_number, s.text_subset, s.old_hash_value, s.command_type, s.force_matching_signature ORDER BY s.snap_id), 0), 0) AS delta_end_of_fetch_count,
            NVL(DECODE(GREATEST(s.rows_processed, NVL(LAG(s.rows_processed)
                OVER (PARTITION BY s.dbid, s.instance_number, s.text_subset, s.old_hash_value, s.command_type, s.force_matching_signature ORDER BY s.snap_id), 0)),
                s.rows_processed, s.rows_processed - LAG(s.rows_processed)
                    OVER (PARTITION BY s.dbid, s.instance_number, s.text_subset, s.old_hash_value, s.command_type, s.force_matching_signature ORDER BY s.snap_id), 0), 0) AS delta_rows_processed,
            NVL(DECODE(GREATEST(s.buffer_gets, NVL(LAG(s.buffer_gets)
                OVER (PARTITION BY s.dbid, s.instance_number, s.text_subset, s.old_hash_value, s.command_type, s.force_matching_signature ORDER BY s.snap_id), 0)),
                s.buffer_gets, s.buffer_gets - LAG(s.buffer_gets)
                    OVER (PARTITION BY s.dbid, s.instance_number, s.text_subset, s.old_hash_value, s.command_type, s.force_matching_signature ORDER BY s.snap_id), 0), 0) AS delta_buffer_gets,
            NVL(DECODE(GREATEST(s.cpu_time, NVL(LAG(s.cpu_time)
                OVER (PARTITION BY s.dbid, s.instance_number, s.text_subset, s.old_hash_value, s.command_type, s.force_matching_signature ORDER BY s.snap_id), 0)),
                s.cpu_time, s.cpu_time - LAG(s.cpu_time)
                    OVER (PARTITION BY s.dbid, s.instance_number, s.text_subset, s.old_hash_value, s.command_type, s.force_matching_signature ORDER BY s.snap_id), 0), 0) AS delta_cpu_time,
            NVL(DECODE(GREATEST(s.user_io_wait_time, NVL(LAG(s.user_io_wait_time)
                OVER (PARTITION BY s.dbid, s.instance_number, s.text_subset, s.old_hash_value, s.command_type, s.force_matching_signature ORDER BY s.snap_id), 0)),
                s.user_io_wait_time, s.user_io_wait_time - LAG(s.user_io_wait_time)
                    OVER (PARTITION BY s.dbid, s.instance_number, s.text_subset, s.old_hash_value, s.command_type, s.force_matching_signature ORDER BY s.snap_id), 0), 0) AS delta_iowait,
            NVL(DECODE(GREATEST(s.cluster_wait_time, NVL(LAG(s.cluster_wait_time)
                OVER (PARTITION BY s.dbid, s.instance_number, s.text_subset, s.old_hash_value, s.command_type, s.force_matching_signature ORDER BY s.snap_id), 0)),
                s.cluster_wait_time, s.cluster_wait_time - LAG(s.cluster_wait_time)
                    OVER (PARTITION BY s.dbid, s.instance_number, s.text_subset, s.old_hash_value, s.command_type, s.force_matching_signature ORDER BY s.snap_id), 0), 0) AS delta_clwait,
            NVL(DECODE(GREATEST(s.application_wait_time, NVL(LAG(s.application_wait_time)
                OVER (PARTITION BY s.dbid, s.instance_number, s.text_subset, s.old_hash_value, s.command_type, s.force_matching_signature ORDER BY s.snap_id), 0)),
                s.application_wait_time, s.application_wait_time - LAG(s.application_wait_time)
                    OVER (PARTITION BY s.dbid, s.instance_number, s.text_subset, s.old_hash_value, s.command_type, s.force_matching_signature ORDER BY s.snap_id), 0), 0) AS delta_apwait,
            NVL(DECODE(GREATEST(s.concurrency_wait_time, NVL(LAG(s.concurrency_wait_time)
                OVER (PARTITION BY s.dbid, s.instance_number, s.text_subset, s.old_hash_value, s.command_type, s.force_matching_signature ORDER BY s.snap_id), 0)),
                s.concurrency_wait_time, s.concurrency_wait_time - LAG(s.concurrency_wait_time)
                    OVER (PARTITION BY s.dbid, s.instance_number, s.text_subset, s.old_hash_value, s.command_type, s.force_matching_signature ORDER BY s.snap_id), 0), 0) AS delta_ccwait,
            NVL(DECODE(GREATEST(s.plsql_exec_time, NVL(LAG(s.plsql_exec_time)
                OVER (PARTITION BY s.dbid, s.instance_number, s.text_subset, s.old_hash_value, s.command_type, s.force_matching_signature ORDER BY s.snap_id), 0)),
                s.plsql_exec_time, s.plsql_exec_time - LAG(s.plsql_exec_time)
                    OVER (PARTITION BY s.dbid, s.instance_number, s.text_subset, s.old_hash_value, s.command_type, s.force_matching_signature ORDER BY s.snap_id), 0), 0) AS delta_plsexec_time,
            NVL(DECODE(GREATEST(s.java_exec_time, NVL(LAG(s.java_exec_time)
                OVER (PARTITION BY s.dbid, s.instance_number, s.text_subset, s.old_hash_value, s.command_type, s.force_matching_signature ORDER BY s.snap_id), 0)),
                s.java_exec_time, s.java_exec_time - LAG(s.java_exec_time)
                    OVER (PARTITION BY s.dbid, s.instance_number, s.text_subset, s.old_hash_value, s.command_type, s.force_matching_signature ORDER BY s.snap_id), 0), 0) AS delta_javexec_time
        FROM stats$sql_summary s
    )
    SELECT
        b.dbid,
        b.instance_number,
        TO_CHAR(d.force_matching_signature) AS force_matching_signature,
        MIN(d.sql_id) AS sql_id,
        ROUND(SUM(d.delta_executions)) AS total_executions,
        ROUND(SUM(d.delta_elapsed_time)) AS elapsed_time_total,
        ROUND(SUM(d.delta_disk_reads)) AS disk_reads_total,
        NULL AS physical_read_bytes_total,
        NULL AS physical_write_bytes_total,
        NULL AS io_offload_elig_bytes_total,
        NULL AS io_interconnect_bytes_total,
        NULL AS optimized_physical_reads_total,
        NULL AS cell_uncompressed_bytes_total,
        NULL AS io_offload_return_bytes_total,
        ROUND(SUM(d.delta_direct_writes)) AS direct_writes_total,
        TRUNC(DECODE(SUM(d.delta_executions), 0, 0,
            (SUM(d.delta_end_of_fetch_count) * 100) / SUM(d.delta_executions))) AS perc_exec_finished,
        TRUNC(DECODE(SUM(d.delta_executions), 0, 0,
            SUM(d.delta_rows_processed) / SUM(d.delta_executions))) AS avg_rows,
        TRUNC(DECODE(SUM(d.delta_executions), 0, 0,
            SUM(d.delta_disk_reads) / SUM(d.delta_executions))) AS avg_disk_reads,
        TRUNC(DECODE(SUM(d.delta_executions), 0, 0,
            SUM(d.delta_buffer_gets) / SUM(d.delta_executions))) AS avg_buffer_gets,
        TRUNC(DECODE(SUM(d.delta_executions), 0, 0,
            SUM(d.delta_cpu_time) / SUM(d.delta_executions))) AS avg_cpu_time_us,
        TRUNC(DECODE(SUM(d.delta_executions), 0, 0,
            SUM(d.delta_elapsed_time) / SUM(d.delta_executions))) AS avg_elapsed_us,
        TRUNC(DECODE(SUM(d.delta_executions), 0, 0,
            SUM(d.delta_iowait) / SUM(d.delta_executions))) AS avg_iowait_us,
        TRUNC(DECODE(SUM(d.delta_executions), 0, 0,
            SUM(d.delta_clwait) / SUM(d.delta_executions))) AS avg_clwait_us,
        TRUNC(DECODE(SUM(d.delta_executions), 0, 0,
            SUM(d.delta_apwait) / SUM(d.delta_executions))) AS avg_apwait_us,
        TRUNC(DECODE(SUM(d.delta_executions), 0, 0,
            SUM(d.delta_ccwait) / SUM(d.delta_executions))) AS avg_ccwait_us,
        TRUNC(DECODE(SUM(d.delta_executions), 0, 0,
            SUM(d.delta_plsexec_time) / SUM(d.delta_executions))) AS avg_plsexec_us,
        TRUNC(DECODE(SUM(d.delta_executions), 0, 0,
            SUM(d.delta_javexec_time) / SUM(d.delta_executions))) AS avg_javexec_us
    FROM vdeltas d
    JOIN stats$snapshot b
        ON d.snap_id = b.snap_id AND d.instance_number = b.instance_number AND d.dbid = b.dbid
    WHERE b.snap_time >= SYSDATE - 30
    GROUP BY b.dbid, b.instance_number, d.force_matching_signature
    ORDER BY elapsed_time_total DESC
    FETCH FIRST 300 ROWS ONLY
    """
