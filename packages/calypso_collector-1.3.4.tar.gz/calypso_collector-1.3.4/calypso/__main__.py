"""Entry point for `python -m calypso`."""

import sys
from calypso.calypso import main

if __name__ == "__main__":
    sys.exit(main())
