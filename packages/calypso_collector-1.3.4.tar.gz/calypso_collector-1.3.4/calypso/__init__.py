"""Calypso Collector - Oracle database data collector for assessment."""

__version__ = "1.3.4"
__version_info__ = (1, 3, 4)
