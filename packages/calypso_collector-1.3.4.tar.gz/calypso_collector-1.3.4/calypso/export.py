"""Export DuckDB tables to JSON and Parquet files."""

import json
import logging
from pathlib import Path

import duckdb

logger = logging.getLogger(__name__)


def _get_table_names(con):
    """Get all non-internal table names from a DuckDB connection."""
    rows = con.execute("SHOW TABLES").fetchall()
    return [row[0] for row in rows]


def export_json(duckdb_path, output_dir, progress_callback=None):
    """Export all DuckDB tables as JSON files."""
    output_dir = Path(output_dir) / "json"
    output_dir.mkdir(parents=True, exist_ok=True)

    con = duckdb.connect(str(duckdb_path), read_only=True)
    try:
        tables = _get_table_names(con)
        for i, table_name in enumerate(tables):
            if progress_callback:
                progress_callback(table_name, i, len(tables))

            out_path = output_dir / f"{table_name}.json"
            con.execute(f"COPY \"{table_name}\" TO '{out_path}' (FORMAT JSON, ARRAY true)")
    finally:
        con.close()

    return len(tables)


def export_parquet(duckdb_path, output_dir, progress_callback=None):
    """Export all DuckDB tables as Parquet files."""
    output_dir = Path(output_dir) / "parquet"
    output_dir.mkdir(parents=True, exist_ok=True)

    con = duckdb.connect(str(duckdb_path), read_only=True)
    try:
        tables = _get_table_names(con)
        for i, table_name in enumerate(tables):
            if progress_callback:
                progress_callback(table_name, i, len(tables))

            out_path = output_dir / f"{table_name}.parquet"
            con.execute(f"COPY \"{table_name}\" TO '{out_path}' (FORMAT PARQUET)")
    finally:
        con.close()

    return len(tables)


def export_all(duckdb_path, output_dir, progress_callback=None):
    """Export all tables to both JSON and Parquet."""
    json_count = export_json(duckdb_path, output_dir, progress_callback)
    parquet_count = export_parquet(duckdb_path, output_dir, progress_callback)
    return json_count, parquet_count
