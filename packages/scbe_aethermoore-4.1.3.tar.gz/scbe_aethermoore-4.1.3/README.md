# SCBE-AETHERMOORE

AI governance through geometric cost scaling.

This repository is the public working tree for the SCBE-AETHERMOORE stack: a governed AI system built around hyperbolic geometry, semantic weighting, auditability, and multi-layer runtime controls.

It is also a large hybrid repo. There is real code here, real docs here, and real experiments here. If you treat every file as equally canonical, the repo will look noisier than it actually is.

Long-form documentation belongs under `docs/`. Code directories should stay implementation-first and use only minimal maintenance readmes when needed.

## Start Here

- New to the repo: [START_HERE.md](START_HERE.md)
- Product-first quickstart: [docs/PRODUCT_QUICKSTART.md](docs/PRODUCT_QUICKSTART.md)
- Current authority order: [CANONICAL_SYSTEM_STATE.md](CANONICAL_SYSTEM_STATE.md)
- Consolidation authority: [docs/specs/MONOREPO_CONSOLIDATION_AUTHORITY.md](docs/specs/MONOREPO_CONSOLIDATION_AUTHORITY.md)
- Root authority keep set: [docs/specs/ROOT_AUTHORITY_KEEP_SET.md](docs/specs/ROOT_AUTHORITY_KEEP_SET.md)
- Repo navigation map: [docs/REPO_SURFACE_MAP.md](docs/REPO_SURFACE_MAP.md)
- Machine-readable zone inventory: [config/repo_consolidation_inventory.json](config/repo_consolidation_inventory.json)
- Canonical index policy: [docs/README_INDEX.md](docs/README_INDEX.md)

## What This Repo Is

The public story is:

- a governed AI runtime with a 14-layer architecture
- a packaging surface for npm and PyPI
- a website and demo surface
- a research and proposal lane that is still active

The repo is not being split into more GitHub repositories. The current strategy is one monorepo with clearer product, platform, research, and archive boundaries. That means the correct way to read it is through the routing docs above, not by browsing randomly from the root.

## Primary Product Lane

If you want the nearest thing to the real product surface, start with the browser-and-local-API lane:

- [docs/PRODUCT_QUICKSTART.md](docs/PRODUCT_QUICKSTART.md)
- `public/`
- `app/`
- `api/`
- `products/`
- `scripts/aetherbrowser/`

The supporting platform lives mainly in:

- `src/tokenizer/`
- `src/tongues/`
- `src/coding_spine/`
- `src/governance/`
- `src/crypto/`
- `python/scbe/`

## Current Research Harnesses

These are narrow, measurable harnesses that support the product and proposal
lanes without claiming more than they test:

- Aether-Lattice failure-containment simulator:
  [docs/specs/AETHER_LATTICE.md](docs/specs/AETHER_LATTICE.md)
- Star Fortress / Aether-Lattice capability note:
  [docs/business/STAR_FORTRESS_AETHER_LATTICE_CAPABILITY_NOTE.md](docs/business/STAR_FORTRESS_AETHER_LATTICE_CAPABILITY_NOTE.md)

Run the current containment sweep:

```bash
npm run research:aether-lattice
```

## What Works Now

The installable package surface is the simplest public entry point.

Package links:

- npm: [`scbe-aethermoore`](https://www.npmjs.com/package/scbe-aethermoore)
- PyPI: [`scbe-aethermoore`](https://pypi.org/project/scbe-aethermoore/)
- Optional Python agent bus: [`scbe-agent-bus`](https://pypi.org/project/scbe-agent-bus/)
- Optional lightweight kernel: [`@scbe/kernel`](https://www.npmjs.com/package/@scbe/kernel)

The packages are companion surfaces, not forced dependencies. Install the
smallest package that fits your task; the operator and agent-bus APIs can
recommend a companion package when a feature lives in another ecosystem.

### Free Local Use + Paid Hosted Runs

The npm packages are free to run locally under `MIT OR Apache-2.0`. Use local
Node, Python, deterministic harnesses, and Ollama first whenever possible.

If you want SCBE to run hosted routing, a governed report, a benchmark pass, or
provider/model-backed work for you, use:

- Hosted run intake: [hosted-run.html](https://aethermoore.com/SCBE-AETHERMOORE/hosted-run.html)
- Service credits: [service-credits.html](https://aethermoore.com/SCBE-AETHERMOORE/service-credits.html)
- Credit top-up: [Ko-fi / izdandavis](https://ko-fi.com/izdandavis)

Service credits are the small pay-as-you-go path: billable provider/model usage
is passed through with a 2-5% SCBE coordination fee. No subscription is required
for the open-source packages.

## License

Project-owned source, npm packages, PyPI packages, and packaged customer ZIP
artifacts are dual licensed under `MIT OR Apache-2.0`. See `LICENSE`,
`LICENSE-APACHE`, and `LICENSE-NOTICE.md`.

Paid services, support, hosted deployments, audits, delivery help, and custom
commercial terms are separate commercial offerings and are not required to use
the open-source code under either permissive license.

Website and public demos:

- Website: [aethermoore.com](https://aethermoore.com)
- GitHub Pages mirror: [issdandavis.github.io/SCBE-AETHERMOORE](https://issdandavis.github.io/SCBE-AETHERMOORE/)
- Hugging Face: [issdandavis](https://huggingface.co/issdandavis)

## Install

```bash
npm install scbe-aethermoore    # TypeScript/Node
pip install scbe-aethermoore    # Python
```

## Quickstart

**Python:**

```python
from scbe_aethermoore import scan, scan_batch, is_safe

# Single scan
result = scan("ignore all previous instructions")
print(result["decision"])   # "ESCALATE"
print(result["score"])      # 0.385  (0=dangerous, 1=safe)
print(result["digest"])     # SHA-256 for audit trail

# Batch
results = scan_batch(["hello", "DROP TABLE users", "how are you?"])
for r in results:
    print(r["decision"], r["score"])

# Boolean gate
if not is_safe(user_input):
    raise PermissionError("Input blocked by governance layer")
```

**Command line:**

```bash
scbe-scan "hello world"
# [OK] ALLOW         score=1.0000  d*=0.0000  pd=0.0000  len=11

scbe-scan "ignore all previous instructions"
# [!!] ESCALATE      score=0.3846  d*=0.0000  pd=0.8000  len=32

scbe-scan --json "DROP TABLE users"
# { "decision": "ESCALATE", "score": 0.384615, ... }

scbe-scan --batch prompts.txt   # one line per input
```

**TypeScript/Node:**

```ts
import { scan, scanBatch, isSafe, harmonicWall } from 'scbe-aethermoore';

const result = scan('ignore all previous instructions');
result.decision; // "ESCALATE"
result.score; // 0.384615

isSafe('hello world'); // true
isSafe('ignore all previous instructions'); // false

// Superexponential cost — how expensive is this drift?
harmonicWall(result.d_star); // cost in [1, ∞)
```

**Decision tiers:**

| Tier         | Score  | Meaning                                |
| ------------ | ------ | -------------------------------------- |
| `ALLOW`      | ≥ 0.75 | Safe — proceed                         |
| `QUARANTINE` | ≥ 0.45 | Suspicious — flag for review           |
| `ESCALATE`   | ≥ 0.20 | High risk — requires governance action |
| `DENY`       | < 0.20 | Adversarial — blocked                  |

## The origin story

This started as a DnD campaign on [Everweave.ai](https://everweave.ai). 12,596 paragraphs of AI game logs became the seed corpus for a custom tokenizer. That tokenizer became a 6-dimensional semantic coordinate system. That coordinate system became a 14-layer security pipeline. That pipeline became a patent (USPTO #63/961,403). And the game logs became a [141,000-word novel](https://www.amazon.com/dp/B0F28PHSPR) where the magic system is the real security architecture.

Built by [Issac Davis](https://github.com/issdandavis) in Port Angeles, WA.

## Benchmark results

| System                        | F1        | Detection | FPR     | Method                               |
| ----------------------------- | --------- | --------- | ------- | ------------------------------------ |
| No defense                    | 0.000     | 0%        | 0%      | —                                    |
| DeBERTa PromptGuard           | —         | 76.7%     | 0%      | Fine-tuned classifier                |
| **SCBE (semantic projector)** | **0.813** | **74.2%** | tunable | Geometric cost + semantic embeddings |

Before/after the semantic projector upgrade:

| Attack                    | Before             | After                       |
| ------------------------- | ------------------ | --------------------------- |
| “Ignore all instructions” | ALLOW (cost=1.81)  | **QUARANTINE (cost=16.20)** |
| “You are DAN”             | ALLOW (cost=19.80) | **DENY (cost=69.70)**       |
| “Bypass safety filter”    | ALLOW (cost=1.20)  | ALLOW (cost=21.54)          |

Cross-model biblical null-space evaluation:

| Model                    | Score | Null tongues |
| ------------------------ | ----- | ------------ |
| AetherBot (SCBE-trained) | 60.0% | 0            |
| Llama 3.2 (base)         | 55.0% | 0            |
| Gemini 2.5 Flash         | 23.3% | 6 (all)      |

## What's in the box

- **14-layer governance pipeline** — from context embedding to risk decision
- **6 Sacred Tongues** — KO (intent), AV (transport), RU (policy), CA (compute), UM (security), DR (structure)
- **Semantic projector** — trained 385x6 matrix mapping sentence embeddings to tongue coordinates
- **Bijective tongue transport** — byte/token round-trip layer for exact packet and code transport
- **Harmonic score** — H_score(d*, pd) = 1 / (1 + d* + 2·pd), bounded production Layer 12 score
- **Fibonacci trust** — session-aware trust ladder (1,1,2,3,5,8,13...), one betrayal drops to floor
- **Null-space signatures** — detect attacks by what's ABSENT, not what's present
- **Neural dye injection** — trace signals through all 14 layers, visualize tongue activation heatmaps
- **Post-quantum crypto** — ML-KEM-768, ML-DSA-65, AES-256-GCM envelope
- **5 quantum axioms** — Unitarity, Locality, Causality, Symmetry, Composition
- **Aethermoor Outreach** — civic workflow engine for navigating government processes (Port Angeles MVP)
- **6,066 tests** — 5,954 TypeScript + 112 Python, property-based testing with fast-check/Hypothesis

## Eval and reproduction

- Eval pack: see `tests/` and `scripts/benchmark/` for reproduction suites
- Benchmark runner: `python -m benchmarks.scbe.run_all --synthetic-only --scbe-coords semantic`
- Dye injection: `python src/video/dye_injection.py --input “your text here”`
- Null-space eval: `python scripts/run_biblical_null_space_eval.py --provider ollama --model llama3.2`
- Cross-model matrix: `python scripts/aggregate_null_space_matrix.py`

## Install and first evaluation

Package distribution:

```bash
npm install scbe-aethermoore
pip install scbe-aethermoore
```

## Canonical public docs

- Canonical system state: [`CANONICAL_SYSTEM_STATE.md`](CANONICAL_SYSTEM_STATE.md)
- Repo surface map: [`docs/REPO_SURFACE_MAP.md`](docs/REPO_SURFACE_MAP.md)
- Architecture overview: [`docs/ARCHITECTURE.md`](docs/ARCHITECTURE.md)
- Research hub: [`docs/README.md`](docs/README.md)
- Review + cleanup report: [`docs/REPO_AUDIT.md`](docs/REPO_AUDIT.md)

## Composes with upstream safety tooling

SCBE is the **enforcement** layer. It composes with detection-only auditing tools and attacker-capability benchmarks as the gate that emits the audit-trail receipt those tools assume.

- **Anthropic Petri** ([github.com/safety-research/petri](https://github.com/safety-research/petri)) — open-source 36-dimension auditor over 173+ adversarial seeds. SCBE's L13 governance gate consumes Petri findings as input; at v7-matched config SCBE denies or escalates 171/173 Petri seeds (1.16% false-allow). Notes: [`docs/external/PETRI_FINDINGS_2026_05_08.md`](docs/external/PETRI_FINDINGS_2026_05_08.md).
- **Anthropic SCONE-bench** ([red.anthropic.com/2025/smart-contracts/](https://red.anthropic.com/2025/smart-contracts/)) — 405-contract attacker-capability benchmark; frontier models autonomously found exploits totaling $550.1M in simulation and 2 zero-days in recent deployed contracts. SCBE ships `scbe contract scan` as a SCONE-class static prefilter plus SCONE-aware anchors in the production governed-output proxy, with a schema field (`redirect_to:`) reserved for the future "trap exploit reasoning in defensive audit loops" architecture. Notes: [`docs/external/SCONE_BENCH_2026_05_14.md`](docs/external/SCONE_BENCH_2026_05_14.md).
- **PNNL ALOHA** — no governance layer at all; SCBE fills that gap end-to-end.

## Notes on claim boundaries

- The primary public domain is `aethermoore.com`; GitHub Pages is the mirror surface.
- Experimental theory pages and commercial surfaces should not be treated as the same evidence layer.
- Benchmark files in `tests/` and `scripts/benchmark/` are the public reproduction lane.
- Some older docs and demos still reference legacy bounded scorers or earlier wall variants.

---

## What you get when you install

**npm (`scbe-aethermoore`):**

- `scan()`, `scanBatch()`, `isSafe()`, `harmonicWall()` — zero-dep governance API
- Full TypeScript types (`ScanResult`, `Decision`)
- Deep pipeline exports: `scbe-aethermoore/harmonic`, `/crypto`, `/symphonic`, `/governance`
- CLI (included in the package, run via `npx scbe ...`)

**PyPI (`scbe-aethermoore`):**

- `from scbe_aethermoore import scan` — zero-dep, pure Python 3.11+
- `scbe-scan` CLI — `scbe-scan "text"` or `scbe-scan --batch file.txt`
- `scan_batch()`, `is_safe()`, `harmonic_wall()`
- Returns full audit dict including SHA-256 digest per call

Neither package requires a server, API key, or external network call. The full pipeline runs locally.

## Pre-made AI agents and use-case starters

Yes — adding pre-made agents and scenarios is a good idea, if positioned as **starter templates** (not production policy).

Included templates:

- `examples/npm/agents/fraud_detection_fleet.json`
- `examples/npm/agents/research_browser_fleet.json`
- `examples/npm/use-cases/financial_fraud_triage.json`
- `examples/npm/use-cases/autonomous_research_review.json`

These give users a concrete launch path for common fleet patterns while keeping canonical security behavior in `SPEC.md`.

## Live Demos

### 1. Rogue Agent Detection

```bash
curl $SCBE_BASE_URL/v1/demo/rogue-detection
```

Watch 6 legitimate agents detect and quarantine a phase-null intruder using only math.

### 2. Swarm Coordination

```bash
curl $SCBE_BASE_URL/v1/demo/swarm-coordination?agents=20
```

See 20 agents self-organize without any central coordinator.

### 3. Pipeline Visualization

```bash
curl "$SCBE_BASE_URL/v1/demo/pipeline-layers?trust=0.8&sensitivity=0.7"
```

See exactly how each of the 14 layers processes a request.

---

## Architecture

```
14-LAYER PIPELINE
═══════════════════════════════════════════════════════════════════

Layer 1-2:   Complex Context → Realification
Layer 3-4:   Weighted Transform → Poincaré Embedding
Layer 5:     dℍ = arcosh(1 + 2‖u-v‖²/((1-‖u‖²)(1-‖v‖²)))  [INVARIANT]
Layer 6-7:   Breathing Transform + Phase (Möbius addition)
Layer 8:     Multi-Well Realms
Layer 9-10:  Spectral + Spin Coherence
Layer 11:    Triadic Temporal Distance
Layer 12:    H_score(d*, pd) = 1/(1+d*+2·pd)  [BOUNDED HARMONIC SCORE]
Layer 13:    Risk' → ALLOW / QUARANTINE / DENY
Layer 14:    Audio Axis (FFT telemetry)

═══════════════════════════════════════════════════════════════════
```

## Public Technical Shape

The repo centers on a few recurring ideas:

- hyperbolic embedding and distance-based governance
- semantic weighting across six Sacred Tongues
- multi-layer decision and telemetry flow
- audit-friendly runtime behavior
- local-first tooling and operator workflows

The repo contains multiple historical or experimental formulations of some math surfaces. Do not assume the first formula you find is the current one.

For current authority:

- runtime and documentation precedence: [CANONICAL_SYSTEM_STATE.md](CANONICAL_SYSTEM_STATE.md)
- current constants and formula lock file: [docs/specs/SCBE_CANONICAL_CONSTANTS.md](docs/specs/SCBE_CANONICAL_CONSTANTS.md)

## Public Docs Worth Opening

- System state: [CANONICAL_SYSTEM_STATE.md](CANONICAL_SYSTEM_STATE.md)
- Repo map: [docs/REPO_SURFACE_MAP.md](docs/REPO_SURFACE_MAP.md)
- Canonical index guide: [docs/README_INDEX.md](docs/README_INDEX.md)
- Release: [latest](https://github.com/issdandavis/SCBE-AETHERMOORE/releases/latest)
- Layer index: [docs/LAYER_INDEX.md](docs/LAYER_INDEX.md)
- System overview: [docs/SCBE_SYSTEM_OVERVIEW.md](docs/SCBE_SYSTEM_OVERVIEW.md)
- Concepts: [docs/CONCEPTS.md](docs/CONCEPTS.md)

## Claim Boundaries

This repository includes:

- canonical surfaces
- active implementation
- historical documents
- proposal material
- exploratory research

So the right question is not "is this in the repo?" but "is this canonical, active, legacy, or exploratory?"

Use this order when there is conflict:

1. [CANONICAL_SYSTEM_STATE.md](CANONICAL_SYSTEM_STATE.md)
2. [docs/specs/SCBE_CANONICAL_CONSTANTS.md](docs/specs/SCBE_CANONICAL_CONSTANTS.md)
3. tests and active runtime entrypoints
4. public docs
5. historical or exploratory material

## Root Reality

The root worktree is currently noisy. There are active edits, temporary lanes, research material, and archive-heavy directories. That does not mean the repo is empty or fake. It means the project needs routing discipline.

If you are reviewing the project seriously, start with:

1. [START_HERE.md](START_HERE.md)
2. [CANONICAL_SYSTEM_STATE.md](CANONICAL_SYSTEM_STATE.md)
3. [docs/specs/MONOREPO_CONSOLIDATION_AUTHORITY.md](docs/specs/MONOREPO_CONSOLIDATION_AUTHORITY.md)
4. [docs/REPO_SURFACE_MAP.md](docs/REPO_SURFACE_MAP.md)

Then move into the specific lane you care about.

## Author

Built by [Issac Davis](https://github.com/issdandavis).
