"""
SCBE-AETHERMOORE REST API
=========================

Production-ready API for AI Agent Governance.

Endpoints:
- POST /v1/authorize     - Main governance decision
- POST /v1/agents        - Register new agent
- GET  /v1/agents/{id}   - Get agent info
- POST /v1/consensus     - Multi-signature approval
- GET  /v1/audit/{id}    - Retrieve decision audit
- GET  /v1/health        - Health check

Run: uvicorn api.main:app --host 0.0.0.0 --port 8080
"""

import hashlib
import json
import logging
import math
import os
import sys
import secrets
import time
import uuid

# Add examples/ to path for spiralverse_core/spiralverse_sdk imports
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "examples"))
from datetime import datetime, timedelta
from enum import Enum
from typing import Any, Dict, List, Optional

from fastapi import FastAPI, HTTPException, Header, Depends, Query, Security
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import APIKeyHeader
from pydantic import BaseModel, Field
from api.metering import (
    AUDIT_REPORT_GENERATIONS,
    GOVERNANCE_EVALUATIONS,
    WORKFLOW_EXECUTIONS,
    export_monthly_billable_usage,
    metering_store,
)
from api.audit_export import build_signed_bundle, canonical_json, filter_records_by_range, sha256_hex
from api.validation import run_nextgen_action_validation

try:
    from src.api.mesh_routes import mesh_router
except Exception:
    mesh_router = None

try:
    from api.billing.routes import router as billing_router
    from api.billing.database import init_db as init_billing_db
except Exception:
    billing_router = None
    init_billing_db = None

try:
    from api.github_app.routes import router as github_app_router
except Exception:
    github_app_router = None

try:
    from api.darpa_prep.routes import router as darpa_prep_router
except Exception:
    darpa_prep_router = None

try:
    from spiralverse_core import EnvelopeCore
except Exception:
    EnvelopeCore = None

try:
    from spiralverse_sdk import HarmonicVerifier
except Exception:
    HarmonicVerifier = None

try:
    from src.cloud.multi_cloud_agents import (
        CloudConfig,
        CloudProvider,
        MultiCloudOrchestratorAgent,
        CloudRunSessionManager,
    )
except Exception:
    CloudConfig = None
    CloudProvider = None
    MultiCloudOrchestratorAgent = None
    CloudRunSessionManager = None

# Import persistence layer
try:
    from api.persistence import get_persistence, SCBEPersistence
except ImportError:
    from persistence import get_persistence, SCBEPersistence

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='{"timestamp":"%(asctime)s","level":"%(levelname)s","message":"%(message)s"}'
)
logger = logging.getLogger("scbe-api")

# =============================================================================
# App Configuration
# =============================================================================

app = FastAPI(
    title="SCBE-AETHERMOORE API",
    description="Quantum-Resistant AI Agent Governance System",
    version="1.0.0",
    docs_url="/docs",
    redoc_url="/redoc",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Configure for production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include Semantic Mesh router (embryonic intake + tongue-space KG)
if mesh_router is not None:
    app.include_router(mesh_router)

# Include billing router for checkout + subscription lifecycle
if billing_router is not None:
    app.include_router(billing_router)

# Include GitHub App webhook router for local/hosted app automation
if github_app_router is not None:
    app.include_router(github_app_router)

# Include DARPA Prep router for federal opportunity normalization and search
if darpa_prep_router is not None:
    app.include_router(darpa_prep_router)

# API Key authentication
API_KEY_HEADER = APIKeyHeader(name="SCBE_api_key", auto_error=False)
API_KEY_HEADER_LEGACY = APIKeyHeader(name="X-API-Key", auto_error=False)

def _load_api_keys() -> dict:
    """
    Load API keys from environment. No hardcoded defaults.

    Set SCBE_API_KEY environment variable before starting.
    For multiple keys: SCBE_API_KEY=key1,key2,key3
    """
    api_key_env = os.getenv("SCBE_API_KEY")
    if not api_key_env:
        logger.warning("SCBE_API_KEY not set - API will reject all requests")
        return {}

    keys = {}
    for i, key in enumerate(api_key_env.split(",")):
        key = key.strip()
        if key:
            keys[key] = f"tenant_{i}"
    return keys

VALID_API_KEYS = _load_api_keys()

# In-memory stores (replace with database in production)
AGENTS_STORE: Dict[str, dict] = {}
DECISIONS_STORE: Dict[str, dict] = {}
CONSENSUS_STORE: Dict[str, dict] = {}
TENANT_CHAIN_HEAD: Dict[str, str] = {}
POLICY_VERSION = os.getenv("SCBE_POLICY_VERSION", "scbe-policy-v1")
ORCHESTRATOR: Optional[Any] = None
SESSION_MANAGER: Optional[Any] = None

# =============================================================================
# Models
# =============================================================================

class Decision(str, Enum):
    ALLOW = "ALLOW"
    DENY = "DENY"
    QUARANTINE = "QUARANTINE"


class AuthorizeRequest(BaseModel):
    agent_id: str = Field(..., description="Unique agent identifier")
    action: str = Field(..., description="Action being requested (READ, WRITE, EXECUTE, etc.)")
    target: str = Field(..., description="Target resource")
    context: Optional[Dict[str, Any]] = Field(default={}, description="Additional context")

    class Config:
        json_schema_extra = {
            "example": {
                "agent_id": "fraud-detector-001",
                "action": "READ",
                "target": "transaction_stream",
                "context": {"sensitivity": 0.3}
            }
        }


class AuthorizeResponse(BaseModel):
    decision: Decision
    decision_id: str
    score: float
    explanation: Dict[str, Any]
    token: Optional[str] = None
    expires_at: Optional[str] = None


class AgentRegisterRequest(BaseModel):
    agent_id: str
    name: str
    role: str
    initial_trust: float = Field(default=0.5, ge=0.0, le=1.0)
    metadata: Optional[Dict[str, Any]] = {}


class AgentResponse(BaseModel):
    agent_id: str
    name: str
    role: str
    trust_score: float
    created_at: str
    last_activity: Optional[str] = None
    decision_count: int = 0


class ConsensusRequest(BaseModel):
    action: str
    target: str
    required_approvals: int = Field(default=3, ge=1, le=10)
    validator_ids: List[str]
    timeout_seconds: int = Field(default=60, ge=10, le=300)


class ConsensusResponse(BaseModel):
    consensus_id: str
    status: str  # PENDING, APPROVED, REJECTED, TIMEOUT
    approvals: int
    rejections: int
    required: int
    votes: List[Dict[str, Any]]


class HealthResponse(BaseModel):
    status: str
    version: str
    timestamp: str
    checks: Dict[str, str]


class AuditExportResponse(BaseModel):
    bundle: Dict[str, Any]
    manifest: Dict[str, Any]


class SpiralverseMeshRequest(BaseModel):
    tongue: str = Field(default="KO", description="Sacred Tongue route")
    origin: str = Field(default="api", description="Origin service identifier")
    payload: Dict[str, Any] = Field(default_factory=dict, description="Mesh payload")
    trust_score: float = Field(default=0.7, ge=0.0, le=1.0)
    action: str = Field(default="mesh_sync")
    metadata: Dict[str, Any] = Field(default_factory=dict)


class FailoverRequest(BaseModel):
    from_cloud: str = Field(default="aws")
    to_cloud: str = Field(default="gcp")
    agent_types: List[str] = Field(default_factory=list)


class SessionStartRequest(BaseModel):
    agent_id: str
    cloud: str = Field(default="gcp")
    ttl_seconds: int = Field(default=1800, ge=60, le=86400)
    context: Dict[str, Any] = Field(default_factory=dict)


# =============================================================================
# Authentication
# =============================================================================

async def verify_api_key(
    api_key: str = Security(API_KEY_HEADER),
    api_key_legacy: str = Security(API_KEY_HEADER_LEGACY),
) -> str:
    key = api_key or api_key_legacy
    if key is None:
        raise HTTPException(status_code=401, detail="Missing API key")
    if key not in VALID_API_KEYS:
        raise HTTPException(status_code=403, detail="Invalid API key")
    return VALID_API_KEYS[key]


def _get_orchestrator() -> Optional[Any]:
    global ORCHESTRATOR
    if ORCHESTRATOR is not None:
        return ORCHESTRATOR
    if MultiCloudOrchestratorAgent is None or CloudConfig is None or CloudProvider is None:
        return None
    cfg = CloudConfig(provider=CloudProvider.LOCAL, region="local-dev")
    ORCHESTRATOR = MultiCloudOrchestratorAgent(cloud_config=cfg)
    return ORCHESTRATOR


def _get_session_manager() -> Optional[Any]:
    global SESSION_MANAGER
    if SESSION_MANAGER is not None:
        return SESSION_MANAGER
    if CloudRunSessionManager is None:
        return None
    SESSION_MANAGER = CloudRunSessionManager()
    return SESSION_MANAGER


# =============================================================================
# SCBE Core Logic (14-Layer Pipeline)
# =============================================================================

def hyperbolic_distance(p1: tuple, p2: tuple) -> float:
    """Poincaré ball distance calculation."""
    norm1_sq = sum(x**2 for x in p1)
    norm2_sq = sum(x**2 for x in p2)
    diff_sq = sum((a - b)**2 for a, b in zip(p1, p2))

    norm1_sq = min(norm1_sq, 0.9999)
    norm2_sq = min(norm2_sq, 0.9999)

    numerator = 2 * diff_sq
    denominator = (1 - norm1_sq) * (1 - norm2_sq)

    if denominator <= 0:
        return float('inf')

    delta = numerator / denominator
    return math.acosh(1 + delta) if delta >= 0 else 0.0


def agent_to_6d_position(agent_id: str, action: str, target: str, trust: float) -> tuple:
    """Map agent+action to 6D hyperbolic position."""
    seed = hashlib.sha256(f"{agent_id}:{action}:{target}".encode()).digest()
    coords = []
    for i in range(6):
        val = seed[i] / 255.0
        radius = (1 - trust) * 0.8 + 0.1
        coords.append(val * radius - radius/2)
    return tuple(coords)


def scbe_14_layer_pipeline(
    agent_id: str,
    action: str,
    target: str,
    trust_score: float,
    sensitivity: float = 0.5
) -> tuple:
    """
    Full 14-layer SCBE governance pipeline.
    Returns (decision, score, explanation).
    """
    explanation = {"layers": {}}

    # Layer 1-4: Context Embedding
    position = agent_to_6d_position(agent_id, action, target, trust_score)
    explanation["layers"]["L1-4"] = f"6D position computed"

    # Layer 5-7: Hyperbolic Geometry Check
    safe_center = (0.0, 0.0, 0.0, 0.0, 0.0, 0.0)
    distance = hyperbolic_distance(position, safe_center)
    explanation["layers"]["L5-7"] = f"Distance: {distance:.3f}"

    # Layer 8: Realm Trust
    realm_trust = trust_score * (1 - sensitivity * 0.5)
    explanation["layers"]["L8"] = f"Realm trust: {realm_trust:.2f}"

    # Layer 9-10: Spectral/Spin Coherence
    coherence = 1.0 - abs(math.sin(distance * math.pi))
    explanation["layers"]["L9-10"] = f"Coherence: {coherence:.2f}"

    # Layer 11: Temporal Pattern
    temporal_score = trust_score * 0.9 + 0.1
    explanation["layers"]["L11"] = f"Temporal: {temporal_score:.2f}"

    # Layer 12: Harmonic Scaling
    R = 2
    d = int(sensitivity * 3) + 1
    H = R ** d
    risk_factor = (1 - realm_trust) * sensitivity * 0.5
    explanation["layers"]["L12"] = f"H(d={d},R={R})={H}, risk: {risk_factor:.2f}"

    # Layer 13: Final Decision
    final_score = (realm_trust * 0.6 + coherence * 0.2 + temporal_score * 0.2) - risk_factor
    explanation["layers"]["L13"] = f"Score: {final_score:.3f}"

    # Layer 14: Telemetry
    explanation["layers"]["L14"] = f"Logged at {time.time():.0f}"

    # Decision thresholds
    if final_score > 0.6:
        decision = Decision.ALLOW
    elif final_score > 0.3:
        decision = Decision.QUARANTINE
    else:
        decision = Decision.DENY

    explanation["trust_score"] = trust_score
    explanation["distance"] = round(distance, 3)
    explanation["risk_factor"] = round(risk_factor, 3)

    return decision, final_score, explanation


def generate_token(decision_id: str, agent_id: str, action: str, expires_minutes: int = 5) -> str:
    """Generate a simple authorization token (replace with JWT in production)."""
    payload = f"{decision_id}:{agent_id}:{action}:{time.time() + expires_minutes * 60}"
    signature = hashlib.sha256(payload.encode()).hexdigest()[:16]
    return f"scbe_{signature}_{decision_id[:8]}"


def generate_noise() -> str:
    """Generate cryptographic noise for DENY responses."""
    return hashlib.sha256(secrets.token_bytes(32)).hexdigest()


# =============================================================================
# API Endpoints
# =============================================================================

@app.post("/v1/authorize", response_model=AuthorizeResponse, tags=["Governance"])
async def authorize(
    request: AuthorizeRequest,
    tenant: str = Depends(verify_api_key)
):
    """
    Main governance decision endpoint.

    Evaluates an agent's request through the 14-layer SCBE pipeline
    and returns ALLOW, DENY, or QUARANTINE.
    """
    start_time = time.time()

    # Get or create agent (tenant-scoped)
    store_key = f"{tenant}:{request.agent_id}"
    if store_key not in AGENTS_STORE:
        AGENTS_STORE[store_key] = {
            "agent_id": request.agent_id,
            "name": request.agent_id,
            "role": "unknown",
            "trust_score": 0.5,
            "created_at": datetime.utcnow().isoformat(),
            "decision_count": 0,
            "tenant": tenant
        }

    agent = AGENTS_STORE[store_key]
    trust_score = agent["trust_score"]
    sensitivity = request.context.get("sensitivity", 0.5) if request.context else 0.5

    # Run unified validator (14-layer hyperbolic + Symphonic hallucination gate).
    decision_str, score, explanation = run_nextgen_action_validation(
        agent_id=request.agent_id,
        action=request.action,
        target=request.target,
        trust_score=trust_score,
        sensitivity=sensitivity,
        context=request.context or {},
    )
    decision = Decision(decision_str)

    # Generate decision ID and store
    decision_id = f"dec_{uuid.uuid4().hex[:12]}"

    # Generate token for ALLOW, noise for DENY
    token = None
    if decision == Decision.ALLOW:
        token = generate_token(decision_id, request.agent_id, request.action)
    elif decision == Decision.DENY:
        explanation["noise"] = generate_noise()

    expires_at = None
    if token:
        expires_at = (datetime.utcnow() + timedelta(minutes=5)).isoformat() + "Z"

    # Build audit chain fields
    input_material = {
        "tenant": tenant,
        "agent_id": request.agent_id,
        "action": request.action,
        "target": request.target,
        "context": request.context or {},
    }
    decision_input_digest = sha256_hex(canonical_json(input_material))

    layer_score_summary = {
        "layer_01_context_integrity": round(float(trust_score), 3),
        "layer_04_hyperbolic_embedding": round(float(explanation.get("distance", 0.0)), 3),
        "layer_12_harmonic_score": round(float(score), 3),
        "layer_13_risk_factor": round(float(explanation.get("risk_factor", 0.0)), 3),
    }
    reason_codes = [
        f"DECISION_{decision.value}",
        f"RISK_{'LOW' if score > 0.6 else ('MEDIUM' if score > 0.3 else 'HIGH')}",
        f"ACTION_{request.action.upper()}",
    ]

    previous_chain_hash = TENANT_CHAIN_HEAD.get(tenant, "GENESIS")
    record_timestamp = datetime.utcnow().isoformat()
    chain_payload = {
        "decision_id": decision_id,
        "tenant": tenant,
        "timestamp": record_timestamp,
        "decision_input_digest": decision_input_digest,
        "final_decision": decision.value,
        "reason_codes": reason_codes,
        "previous_chain_hash": previous_chain_hash,
    }
    chain_hash = sha256_hex(canonical_json(chain_payload))
    TENANT_CHAIN_HEAD[tenant] = chain_hash

    # Store decision for audit
    DECISIONS_STORE[decision_id] = {
        "decision_id": decision_id,
        "tenant": tenant,
        "agent_id": request.agent_id,
        "action": request.action,
        "target": request.target,
        "decision": decision.value,
        "score": round(score, 3),
        "explanation": explanation,
        "timestamp": record_timestamp,
        "latency_ms": round((time.time() - start_time) * 1000, 2),
        "decision_input_digest": decision_input_digest,
        "policy_version": POLICY_VERSION,
        "layer_score_summary": layer_score_summary,
        "final_decision": decision.value,
        "reason_codes": reason_codes,
        "previous_chain_hash": previous_chain_hash,
        "chain_hash": chain_hash,
    }

    # Update agent stats
    agent["decision_count"] += 1
    agent["last_activity"] = datetime.utcnow().isoformat()

    # Log decision
    logger.info(json.dumps({
        "event": "governance_decision",
        "decision_id": decision_id,
        "agent_id": request.agent_id,
        "action": request.action,
        "decision": decision.value,
        "score": round(score, 3),
        "latency_ms": DECISIONS_STORE[decision_id]["latency_ms"]
    }))

    metering_store.increment_metric(tenant_id=tenant, metric_name=GOVERNANCE_EVALUATIONS)

    # Persist to Firebase
    try:
        persistence = get_persistence()
        risk_level = "LOW" if score > 0.6 else ("MEDIUM" if score > 0.3 else "HIGH")
        audit_id = persistence.log_decision(
            agent_id=request.agent_id,
            action=request.action,
            decision=decision.value,
            trust_score=trust_score,
            risk_level=risk_level,
            context=request.context or {},
            consensus_result={"single_decision": True}
        )
        persistence.record_trust(
            agent_id=request.agent_id,
            trust_score=trust_score,
            factors={"score": score, "sensitivity": sensitivity},
            decision=decision.value
        )
    except Exception as e:
        logger.warning(f"Persistence error (non-fatal): {e}")

    return AuthorizeResponse(
        decision=decision,
        decision_id=decision_id,
        score=round(score, 3),
        explanation=explanation,
        token=token,
        expires_at=expires_at
    )


@app.post("/v1/agents", response_model=AgentResponse, tags=["Agents"])
async def register_agent(
    request: AgentRegisterRequest,
    tenant: str = Depends(verify_api_key)
):
    """Register a new agent with initial trust score."""
    # Use composite key for tenant isolation
    store_key = f"{tenant}:{request.agent_id}"
    if store_key in AGENTS_STORE:
        raise HTTPException(status_code=409, detail="Agent already exists")

    agent = {
        "agent_id": request.agent_id,
        "name": request.name,
        "role": request.role,
        "trust_score": request.initial_trust,
        "created_at": datetime.utcnow().isoformat(),
        "last_activity": None,
        "decision_count": 0,
        "metadata": request.metadata,
        "tenant": tenant  # Store tenant for ownership verification
    }
    AGENTS_STORE[store_key] = agent

    logger.info(json.dumps({
        "event": "agent_registered",
        "agent_id": request.agent_id,
        "tenant": tenant,
        "role": request.role,
        "initial_trust": request.initial_trust
    }))

    return AgentResponse(**agent)


@app.get("/v1/agents/{agent_id}", response_model=AgentResponse, tags=["Agents"])
async def get_agent(
    agent_id: str,
    tenant: str = Depends(verify_api_key)
):
    """Get agent information and current trust score."""
    # Use composite key for tenant-scoped lookup
    store_key = f"{tenant}:{agent_id}"
    if store_key not in AGENTS_STORE:
        raise HTTPException(status_code=404, detail="Agent not found")

    return AgentResponse(**AGENTS_STORE[store_key])


@app.post("/v1/consensus", response_model=ConsensusResponse, tags=["Governance"])
async def request_consensus(
    request: ConsensusRequest,
    tenant: str = Depends(verify_api_key)
):
    """
    Request multi-signature consensus for sensitive operations.

    Collects votes from specified validators and returns
    approval status based on threshold.
    """
    consensus_id = f"con_{uuid.uuid4().hex[:12]}"

    votes = []
    approvals = 0
    rejections = 0

    for validator_id in request.validator_ids:
        # Get validator trust score (tenant-scoped lookup)
        validator_key = f"{tenant}:{validator_id}"
        if validator_key in AGENTS_STORE:
            trust = AGENTS_STORE[validator_key]["trust_score"]
        else:
            trust = 0.5  # Default for unknown validators

        # Run pipeline for each validator
        decision, score, _ = scbe_14_layer_pipeline(
            agent_id=validator_id,
            action=request.action,
            target=request.target,
            trust_score=trust,
            sensitivity=0.5
        )

        # ALLOW and QUARANTINE count as approval
        is_approve = decision in (Decision.ALLOW, Decision.QUARANTINE)

        if is_approve:
            approvals += 1
        else:
            rejections += 1

        votes.append({
            "validator_id": validator_id,
            "decision": decision.value,
            "score": round(score, 3),
            "approved": is_approve
        })

    # Determine consensus status
    if approvals >= request.required_approvals:
        status = "APPROVED"
    else:
        status = "REJECTED"

    # Store consensus
    CONSENSUS_STORE[consensus_id] = {
        "consensus_id": consensus_id,
        "status": status,
        "approvals": approvals,
        "rejections": rejections,
        "required": request.required_approvals,
        "votes": votes,
        "timestamp": datetime.utcnow().isoformat()
    }

    logger.info(json.dumps({
        "event": "consensus_decision",
        "consensus_id": consensus_id,
        "status": status,
        "approvals": approvals,
        "required": request.required_approvals
    }))

    return ConsensusResponse(
        consensus_id=consensus_id,
        status=status,
        approvals=approvals,
        rejections=rejections,
        required=request.required_approvals,
        votes=votes
    )


@app.get("/v1/audit/{decision_id}", tags=["Audit"])
async def get_audit(
    decision_id: str,
    tenant: str = Depends(verify_api_key)
):
    """Retrieve full audit trail for a governance decision."""
    if decision_id not in DECISIONS_STORE:
        raise HTTPException(status_code=404, detail="Decision not found")

    return DECISIONS_STORE[decision_id]


@app.get("/v1/health", response_model=HealthResponse, tags=["System"])
async def health_check():
    """Health check endpoint (no auth required)."""
    persistence = get_persistence()
    return HealthResponse(
        status="healthy",
        version="1.0.0",
        timestamp=datetime.utcnow().isoformat() + "Z",
        checks={
            "api": "ok",
            "pipeline": "ok",
            "storage": "ok" if len(AGENTS_STORE) >= 0 else "degraded",
            "firebase": "connected" if persistence.is_connected else "disconnected"
        }
    )


# =============================================================================
# Mesh / Multi-Cloud Endpoints
# =============================================================================

@app.post("/v1/spiralverse/mesh", tags=["Spiralverse"])
async def spiralverse_mesh(
    request: SpiralverseMeshRequest,
    tenant: str = Depends(verify_api_key),
):
    """
    Spiralverse mesh packet seal/verify endpoint.

    Uses EnvelopeCore for packet integrity and (optionally) HarmonicVerifier for
    resonant gate scoring.
    """
    if EnvelopeCore is None:
        raise HTTPException(status_code=503, detail="Spiralverse envelope runtime unavailable")

    secret_key = hashlib.sha256(f"{tenant}:{request.origin}".encode("utf-8")).digest()
    envelope = EnvelopeCore.seal(
        tongue=request.tongue,
        origin=request.origin,
        payload=request.payload,
        secret_key=secret_key,
    )
    opened = EnvelopeCore.verify_and_open(envelope, secret_key)
    envelope_ok = not (isinstance(opened, dict) and opened.get("error") == "NOISE")

    harmonic = {"available": False, "resonant": True, "score": 0.0}
    if HarmonicVerifier is not None:
        verifier = HarmonicVerifier(
            kyber_shared_secret=hashlib.sha256(tenant.encode("utf-8")).digest(),
            dilithium_public_key=hashlib.sha256(request.origin.encode("utf-8")).digest(),
        )
        resonant, score = verifier.play_chord(
            source_id=request.origin.encode("utf-8"),
            action=request.action,
            auth_level=2 if request.trust_score >= 0.6 else 4,
            state_history=["mesh_init", request.action, "mesh_verify"],
            metadata=request.metadata,
            message=json.dumps(request.payload, sort_keys=True).encode("utf-8"),
            signature=b"mesh-signature",
        )
        harmonic = {"available": True, "resonant": bool(resonant), "score": round(float(score), 4)}

    return {
        "mesh_id": f"mesh_{uuid.uuid4().hex[:12]}",
        "tenant": tenant,
        "envelope_ok": envelope_ok,
        "harmonic": harmonic,
        "envelope": envelope,
        "opened_payload": opened if envelope_ok else None,
        "timestamp": datetime.utcnow().isoformat() + "Z",
    }


@app.post("/v1/internal/failover", tags=["Multi-Cloud"])
async def trigger_failover(
    request: FailoverRequest,
    tenant: str = Depends(verify_api_key),
):
    """Trigger cross-cloud routing failover for orchestrated agent types."""
    orchestrator = _get_orchestrator()
    if orchestrator is None:
        raise HTTPException(status_code=503, detail="Multi-cloud orchestrator runtime unavailable")
    result = await orchestrator.process(
        {
            "type": "failover",
            "from_cloud": request.from_cloud,
            "to_cloud": request.to_cloud,
            "agent_types": request.agent_types,
            "requested_by": tenant,
        },
        {},
    )
    return result


@app.post("/v1/sessions/start", tags=["Multi-Cloud"])
async def start_cloud_session(
    request: SessionStartRequest,
    tenant: str = Depends(verify_api_key),
):
    """Start a Cloud Run-style stateful session."""
    manager = _get_session_manager()
    if manager is None:
        raise HTTPException(status_code=503, detail="Session manager runtime unavailable")
    return manager.start_session(
        agent_id=request.agent_id,
        cloud=request.cloud,
        ttl_seconds=request.ttl_seconds,
        context={"tenant": tenant, **request.context},
    )


@app.get("/v1/sessions/{session_id}", tags=["Multi-Cloud"])
async def get_cloud_session(
    session_id: str,
    tenant: str = Depends(verify_api_key),
):
    """Get session state."""
    manager = _get_session_manager()
    if manager is None:
        raise HTTPException(status_code=503, detail="Session manager runtime unavailable")
    record = manager.get_session(session_id)
    if record is None:
        raise HTTPException(status_code=404, detail="Session not found")
    if record.get("context", {}).get("tenant") != tenant:
        raise HTTPException(status_code=403, detail="Not authorized")
    return record


@app.post("/v1/sessions/{session_id}/touch", tags=["Multi-Cloud"])
async def touch_cloud_session(
    session_id: str,
    tenant: str = Depends(verify_api_key),
):
    """Extend session heartbeat."""
    manager = _get_session_manager()
    if manager is None:
        raise HTTPException(status_code=503, detail="Session manager runtime unavailable")
    record = manager.touch_session(session_id)
    if record is None:
        raise HTTPException(status_code=404, detail="Session not found")
    if record.get("context", {}).get("tenant") != tenant:
        raise HTTPException(status_code=403, detail="Not authorized")
    return record


@app.delete("/v1/sessions/{session_id}", tags=["Multi-Cloud"])
async def end_cloud_session(
    session_id: str,
    tenant: str = Depends(verify_api_key),
):
    """Terminate session."""
    manager = _get_session_manager()
    if manager is None:
        raise HTTPException(status_code=503, detail="Session manager runtime unavailable")
    record = manager.get_session(session_id)
    if record is None:
        raise HTTPException(status_code=404, detail="Session not found")
    if record.get("context", {}).get("tenant") != tenant:
        raise HTTPException(status_code=403, detail="Not authorized")
    manager.end_session(session_id)
    return {"status": "ended", "session_id": session_id}


# =============================================================================
# Metrics & Monitoring Endpoints
# =============================================================================

class MetricsResponse(BaseModel):
    total_decisions: int
    allow_count: int
    quarantine_count: int
    deny_count: int
    allow_rate: float
    quarantine_rate: float
    deny_rate: float
    avg_trust_score: float
    firebase_connected: bool


@app.get("/v1/metrics", response_model=MetricsResponse, tags=["Monitoring"])
async def get_metrics(tenant: str = Depends(verify_api_key)):
    """Get decision metrics for monitoring dashboards."""
    persistence = get_persistence()
    metrics = persistence.get_metrics()
    metrics["firebase_connected"] = persistence.is_connected
    return MetricsResponse(**metrics)


# =============================================================================
# Webhook/Zapier Integration Endpoints
# =============================================================================

class WebhookConfig(BaseModel):
    webhook_url: str
    events: List[str] = ["decision_deny", "decision_quarantine", "trust_decline"]
    min_severity: str = "medium"


class AlertResponse(BaseModel):
    alert_id: str
    timestamp: str
    severity: str
    alert_type: str
    message: str
    agent_id: Optional[str]
    audit_id: Optional[str]
    data: dict


# Store webhooks in memory (would be persisted in production)
WEBHOOK_STORE: Dict[str, dict] = {}


@app.post("/v1/webhooks", tags=["Webhooks"])
async def register_webhook(
    config: WebhookConfig,
    tenant: str = Depends(verify_api_key)
):
    """
    Register a webhook URL for alert notifications.

    Use this to connect SCBE alerts to Zapier, Slack, or other services.
    """
    webhook_id = f"webhook_{uuid.uuid4().hex[:8]}"
    WEBHOOK_STORE[webhook_id] = {
        "webhook_id": webhook_id,
        "tenant": tenant,
        "url": config.webhook_url,
        "events": config.events,
        "min_severity": config.min_severity,
        "created_at": datetime.utcnow().isoformat()
    }

    logger.info(json.dumps({
        "event": "webhook_registered",
        "webhook_id": webhook_id,
        "url": config.webhook_url[:50] + "..."
    }))

    return {"webhook_id": webhook_id, "status": "registered"}


@app.get("/v1/webhooks", tags=["Webhooks"])
async def list_webhooks(tenant: str = Depends(verify_api_key)):
    """List registered webhooks for this tenant."""
    return [w for w in WEBHOOK_STORE.values() if w["tenant"] == tenant]


@app.delete("/v1/webhooks/{webhook_id}", tags=["Webhooks"])
async def delete_webhook(
    webhook_id: str,
    tenant: str = Depends(verify_api_key)
):
    """Remove a registered webhook."""
    if webhook_id not in WEBHOOK_STORE:
        raise HTTPException(status_code=404, detail="Webhook not found")
    if WEBHOOK_STORE[webhook_id]["tenant"] != tenant:
        raise HTTPException(status_code=403, detail="Not authorized")

    del WEBHOOK_STORE[webhook_id]
    return {"status": "deleted"}


@app.get("/v1/alerts", response_model=List[AlertResponse], tags=["Alerts"])
async def get_alerts(
    tenant: str = Depends(verify_api_key),
    limit: int = 50,
    pending_only: bool = True
):
    """
    Get alerts for webhook delivery.

    Zapier can poll this endpoint to get new alerts.
    """
    persistence = get_persistence()

    if pending_only:
        alerts = persistence.get_pending_alerts(limit=limit)
    else:
        # Get recent alerts from audit logs
        alerts = []
        logs = persistence.get_audit_logs(limit=limit)
        for log in logs:
            if log["decision"] in ["DENY", "QUARANTINE"]:
                alerts.append({
                    "alert_id": f"alert-{log['audit_id']}",
                    "timestamp": log["timestamp"],
                    "severity": "high" if log["decision"] == "DENY" else "medium",
                    "alert_type": f"decision_{log['decision'].lower()}",
                    "message": f"Agent {log['agent_id']} request was {log['decision']}",
                    "agent_id": log["agent_id"],
                    "audit_id": log["audit_id"],
                    "data": {"trust_score": log["trust_score"]}
                })

    return alerts


@app.post("/v1/alerts/{alert_id}/ack", tags=["Alerts"])
async def acknowledge_alert(
    alert_id: str,
    tenant: str = Depends(verify_api_key)
):
    """
    Acknowledge an alert (mark as sent/processed).

    Call this after successfully processing an alert via webhook.
    """
    persistence = get_persistence()
    success = persistence.mark_alert_sent(alert_id)

    if not success:
        raise HTTPException(status_code=404, detail="Alert not found")

    return {"status": "acknowledged", "alert_id": alert_id}


# =============================================================================
# AetherNet Game Bridge (n8n <-> Aethermoor Game)
# =============================================================================

class GameActionRequest(BaseModel):
    action_type: str = Field(
        ...,
        description="Action: spawn_enemy, give_item, trigger_scene, send_dialogue, modify_stat, tv_show, training_result, world_event",
    )
    data: Dict[str, Any] = Field(default_factory=dict, description="Action payload")

    class Config:
        json_schema_extra = {
            "example": {
                "action_type": "send_dialogue",
                "data": {"speaker": "POLLY", "text": "The AetherNet stirs..."},
            }
        }


@app.post("/v1/game/action", tags=["AetherNet"])
async def push_game_action(
    request: GameActionRequest,
    tenant: str = Depends(verify_api_key),
):
    """
    Push an action into the running Aethermoor game via AetherNet.

    n8n workflows call this to trigger in-game effects:
    - spawn_enemy: {name, tongue, hp, attack}
    - give_item: {item, amount}
    - trigger_scene: {scene_id}
    - send_dialogue: {speaker, text}
    - modify_stat: {stat, delta}
    - tv_show: {show, content, channel}
    - training_result: {metrics: {loss, accuracy, ...}}
    """
    try:
        from demo.n8n_bridge import GameAction, get_shared_bus
    except ImportError:
        raise HTTPException(status_code=503, detail="AetherNet bridge not available")

    bus = get_shared_bus()
    if bus is None:
        raise HTTPException(status_code=503, detail="Game not running")

    action_id = f"act_{uuid.uuid4().hex[:8]}"
    action = GameAction(
        action_type=request.action_type,
        action_id=action_id,
        data=request.data,
    )
    queued = bus.put_action(action)

    if not queued:
        raise HTTPException(status_code=429, detail="Action queue full")

    logger.info(json.dumps({
        "event": "aethernet_action_queued",
        "action_id": action_id,
        "action_type": request.action_type,
        "tenant": tenant,
    }))

    return {"action_id": action_id, "status": "queued"}


@app.get("/v1/game/status", tags=["AetherNet"])
async def game_bridge_status(tenant: str = Depends(verify_api_key)):
    """Get AetherNet bridge status (game event bus stats)."""
    try:
        from demo.n8n_bridge import get_shared_bus
    except ImportError:
        return {"online": False, "message": "AetherNet bridge not installed"}

    bus = get_shared_bus()
    if bus is None:
        return {"online": False, "message": "Game not running"}
    return bus.status()


# =============================================================================
# Trust History Endpoints
# =============================================================================

@app.get("/v1/agents/{agent_id}/trust-history", tags=["Agents"])
async def get_trust_history(
    agent_id: str,
    tenant: str = Depends(verify_api_key),
    limit: int = 30
):
    """Get trust score history for an agent."""
    persistence = get_persistence()
    history = persistence.get_trust_history(agent_id, limit=limit)
    trend = persistence.get_trust_trend(agent_id)

    return {
        "agent_id": agent_id,
        "trend": trend,
        "history": history
    }


@app.get("/v1/audit", tags=["Audit"])
async def list_audit_logs(
    tenant: str = Depends(verify_api_key),
    agent_id: Optional[str] = None,
    decision: Optional[str] = None,
    limit: int = 100
):
    """Query audit logs with optional filters."""
    persistence = get_persistence()
    logs = persistence.get_audit_logs(
        agent_id=agent_id,
        decision=decision,
        limit=limit
    )
    return {"count": len(logs), "logs": logs}


# =============================================================================
# Fleet Scenario Endpoint (Pilot Demo)
# =============================================================================

class FleetAgent(BaseModel):
    agent_id: str
    name: str
    role: str = "worker"
    initial_trust: float = Field(default=0.5, ge=0.0, le=1.0)


class FleetAction(BaseModel):
    agent_id: str
    action: str
    target: str
    sensitivity: float = Field(default=0.5, ge=0.0, le=1.0)


class FleetScenario(BaseModel):
    scenario_name: str = "default"
    agents: List[FleetAgent]
    actions: List[FleetAction]
    require_consensus: bool = False
    consensus_threshold: int = 3

    class Config:
        json_schema_extra = {
            "example": {
                "scenario_name": "fraud-detection-fleet",
                "agents": [
                    {"agent_id": "fraud-detector-001", "name": "Fraud Detector", "role": "analyzer", "initial_trust": 0.8},
                    {"agent_id": "risk-scorer-002", "name": "Risk Scorer", "role": "scorer", "initial_trust": 0.7},
                    {"agent_id": "alert-bot-003", "name": "Alert Bot", "role": "notifier", "initial_trust": 0.6}
                ],
                "actions": [
                    {"agent_id": "fraud-detector-001", "action": "READ", "target": "transaction_stream", "sensitivity": 0.3},
                    {"agent_id": "risk-scorer-002", "action": "WRITE", "target": "risk_scores_db", "sensitivity": 0.6},
                    {"agent_id": "alert-bot-003", "action": "EXECUTE", "target": "send_alert", "sensitivity": 0.4}
                ]
            }
        }


class FleetDecision(BaseModel):
    agent_id: str
    action: str
    target: str
    decision: str
    score: float
    trust_score: float
    risk_factor: float


class FleetScenarioResponse(BaseModel):
    scenario_id: str
    scenario_name: str
    timestamp: str
    summary: Dict[str, int]
    decisions: List[FleetDecision]
    metrics: Dict[str, float]


class AuditReportResponse(BaseModel):
    generated_at: str
    tenant_id: str
    total_decisions: int
    decisions_by_outcome: Dict[str, int]


class MonthlyUsageExportResponse(BaseModel):
    month: str
    tenant_id: Optional[str]
    generated_at: str
    rows: List[Dict[str, Any]]
    totals: Dict[str, int]


@app.post("/v1/fleet/run-scenario", response_model=FleetScenarioResponse, tags=["Fleet"])
async def run_fleet_scenario(
    scenario: FleetScenario,
    tenant: str = Depends(verify_api_key)
):
    """
    Run a complete fleet scenario through SCBE.

    This endpoint:
    1. Registers all agents in the scenario
    2. Runs each action through the 14-layer SCBE pipeline
    3. Aggregates results and returns a summary

    Use this for demos, testing, and UI integration.
    """
    scenario_id = f"scenario_{uuid.uuid4().hex[:12]}"
    start_time = time.time()

    # Register all agents (tenant-scoped)
    for agent in scenario.agents:
        agent_key = f"{tenant}:{agent.agent_id}"
        if agent_key not in AGENTS_STORE:
            AGENTS_STORE[agent_key] = {
                "agent_id": agent.agent_id,
                "name": agent.name,
                "role": agent.role,
                "trust_score": agent.initial_trust,
                "created_at": datetime.utcnow().isoformat(),
                "last_activity": None,
                "decision_count": 0,
                "tenant": tenant
            }

    # Process all actions
    decisions = []
    allow_count = 0
    deny_count = 0
    quarantine_count = 0
    total_score = 0.0

    for action in scenario.actions:
        agent_key = f"{tenant}:{action.agent_id}"
        agent = AGENTS_STORE.get(agent_key)
        if not agent:
            continue

        trust_score = agent["trust_score"]

        # Run 14-layer pipeline
        decision, score, explanation = scbe_14_layer_pipeline(
            agent_id=action.agent_id,
            action=action.action,
            target=action.target,
            trust_score=trust_score,
            sensitivity=action.sensitivity
        )

        # Track metrics
        if decision == Decision.ALLOW:
            allow_count += 1
        elif decision == Decision.DENY:
            deny_count += 1
        else:
            quarantine_count += 1

        total_score += score

        decisions.append(FleetDecision(
            agent_id=action.agent_id,
            action=action.action,
            target=action.target,
            decision=decision.value,
            score=round(score, 3),
            trust_score=trust_score,
            risk_factor=explanation.get("risk_factor", 0)
        ))

        # Update agent stats
        agent["decision_count"] += 1
        agent["last_activity"] = datetime.utcnow().isoformat()

    elapsed_ms = (time.time() - start_time) * 1000

    logger.info(json.dumps({
        "event": "fleet_scenario_completed",
        "scenario_id": scenario_id,
        "scenario_name": scenario.scenario_name,
        "agents": len(scenario.agents),
        "actions": len(scenario.actions),
        "allow": allow_count,
        "deny": deny_count,
        "quarantine": quarantine_count,
        "elapsed_ms": round(elapsed_ms, 2)
    }))

    metering_store.increment_metric(tenant_id=tenant, metric_name=WORKFLOW_EXECUTIONS)

    return FleetScenarioResponse(
        scenario_id=scenario_id,
        scenario_name=scenario.scenario_name,
        timestamp=datetime.utcnow().isoformat() + "Z",
        summary={
            "total_actions": len(scenario.actions),
            "allowed": allow_count,
            "denied": deny_count,
            "quarantined": quarantine_count
        },
        decisions=decisions,
        metrics={
            "avg_score": round(total_score / max(len(decisions), 1), 3),
            "allow_rate": round(allow_count / max(len(decisions), 1), 3),
            "elapsed_ms": round(elapsed_ms, 2)
        }
    )


# =============================================================================
# Demo Endpoints (For Promotion & Sales)
# =============================================================================

class RogueDetectionResponse(BaseModel):
    simulation_id: str
    steps: int
    result: str
    rogue_detected: bool
    detection_step: int
    consensus_votes: int
    false_positives: int
    final_positions: List[Dict[str, Any]]
    metrics: Dict[str, float]


class SwarmCoordinationResponse(BaseModel):
    simulation_id: str
    agents: int
    initial_avg_distance: float
    final_avg_distance: float
    collisions: int
    boundary_breaches: int
    coordination_score: float




@app.get("/v1/audit/report", response_model=AuditReportResponse, tags=["Audit"])
async def generate_audit_report(
    tenant: str = Depends(verify_api_key)
):
    """Generate an audit summary report for the current tenant."""
    decisions = [
        d for d in DECISIONS_STORE.values()
        if d.get("tenant") == tenant
    ]
    by_outcome = {
        "ALLOW": sum(1 for d in decisions if d.get("decision") == "ALLOW"),
        "DENY": sum(1 for d in decisions if d.get("decision") == "DENY"),
        "QUARANTINE": sum(1 for d in decisions if d.get("decision") == "QUARANTINE"),
    }

    metering_store.increment_metric(tenant_id=tenant, metric_name=AUDIT_REPORT_GENERATIONS)

    return AuditReportResponse(
        generated_at=datetime.utcnow().isoformat() + "Z",
        tenant_id=tenant,
        total_decisions=len(decisions),
        decisions_by_outcome=by_outcome,
    )


@app.get("/audit/export", response_model=AuditExportResponse, tags=["Audit"])
async def export_audit_bundle(
    from_: str = Query(..., alias="from"),
    to: str = Query(...),
    tenant: str = Depends(verify_api_key),
):
    """Export a signed audit bundle for a tenant and UTC time range."""
    signing_key = os.getenv("SCBE_AUDIT_EXPORT_SIGNING_KEY")
    if not signing_key:
        raise HTTPException(
            status_code=503,
            detail="SCBE_AUDIT_EXPORT_SIGNING_KEY is not configured",
        )

    tenant_records = [
        record for record in DECISIONS_STORE.values() if record.get("tenant") == tenant
    ]
    filtered_records = filter_records_by_range(tenant_records, from_ts=from_, to_ts=to)

    bundle, manifest = build_signed_bundle(
        tenant_id=tenant,
        from_ts=from_,
        to_ts=to,
        records=filtered_records,
        signing_key=signing_key,
    )
    return AuditExportResponse(bundle=bundle, manifest=manifest)


@app.get("/v1/internal/billing/monthly-usage", response_model=MonthlyUsageExportResponse, tags=["Billing"])
async def export_monthly_usage(
    year: int,
    month: int,
    tenant: str = Depends(verify_api_key),
    include_all_tenants: bool = False,
):
    """Export monthly billable usage aggregates for finance/reporting pipelines."""
    target_tenant = None if include_all_tenants else tenant
    return MonthlyUsageExportResponse(**export_monthly_billable_usage(year=year, month=month, tenant_id=target_tenant))

@app.get("/v1/demo/rogue-detection", response_model=RogueDetectionResponse, tags=["Demo"])
async def demo_rogue_detection(steps: int = 25):
    """
    **LIVE DEMO: Rogue Agent Detection**

    Watch the SCBE swarm detect and quarantine a phase-null intruder
    using only hyperbolic geometry - no explicit messaging required.

    The swarm "smells" the intruder through mathematical anomaly detection.
    """
    import numpy as np
    np.random.seed(int(time.time()) % 10000)

    TONGUES = {'KO': 0, 'AV': np.pi/3, 'RU': 2*np.pi/3,
               'CA': np.pi, 'UM': 4*np.pi/3, 'DR': 5*np.pi/3}

    class Agent:
        def __init__(self, id, tongue, pos, is_rogue=False):
            self.id = id
            self.tongue = tongue
            self.phase = None if is_rogue else TONGUES.get(tongue)
            self.position = np.array(pos)
            self.is_rogue = is_rogue
            self.flagged_by = set()

        @property
        def norm(self):
            return float(np.linalg.norm(self.position))

        @property
        def is_quarantined(self):
            return len(self.flagged_by) >= 4

    def hyperbolic_dist(u, v):
        nu, nv = np.linalg.norm(u), np.linalg.norm(v)
        diff_sq = np.linalg.norm(u - v) ** 2
        denom = (1 - nu**2) * (1 - nv**2)
        if denom <= 1e-10:
            return float('inf')
        return float(np.arccosh(max(1 + 2 * diff_sq / denom, 1.0)))

    def project(pos, max_n=0.95):
        n = np.linalg.norm(pos)
        return pos * (max_n / n) if n > max_n else pos

    # Create agents
    agents = []
    for i, t in enumerate(['KO', 'AV', 'RU', 'CA', 'UM', 'DR']):
        pos = np.array([0.02 + i*0.01] * 3)
        agents.append(Agent(i, t, pos))

    # Add rogue
    rogue = Agent(6, None, np.array([0.04, 0.04, 0.04]), is_rogue=True)
    agents.append(rogue)

    detection_step = -1

    # Simulation loop
    for step in range(steps):
        # Detection phase
        for ai in agents:
            for aj in agents:
                if ai.id == aj.id:
                    continue
                d = hyperbolic_dist(ai.position, aj.position)
                if d < 1.5 and aj.phase is None and ai.phase is not None:
                    aj.flagged_by.add(ai.id)

        if rogue.is_quarantined and detection_step < 0:
            detection_step = step

        # Movement phase
        forces = {a.id: np.zeros(3) for a in agents}
        for i, ai in enumerate(agents):
            for j, aj in enumerate(agents):
                if i >= j:
                    continue
                d = hyperbolic_dist(ai.position, aj.position)
                if d < 0.01 or d > 2.0:
                    continue

                direction = ai.position - aj.position
                direction = direction / (np.linalg.norm(direction) + 1e-10)

                repel = max(0, 0.4 - d) * 0.5
                if aj.is_quarantined or len(aj.flagged_by) >= 2:
                    repel *= 3.0

                forces[ai.id] += repel * direction
                forces[aj.id] -= repel * direction

        for agent in agents:
            agent.position = agent.position + forces[agent.id]
            drift_std = 0.05 if agent.is_rogue else 0.03
            agent.position = agent.position + np.random.normal(0, drift_std, 3)
            agent.position = project(agent.position)

    # Calculate final metrics
    rogue_distances = [hyperbolic_dist(a.position, rogue.position)
                       for a in agents if not a.is_rogue]
    avg_rogue_dist = float(np.mean(rogue_distances))

    false_positives = sum(1 for a in agents if not a.is_rogue and len(a.flagged_by) > 0)

    final_positions = []
    for a in agents:
        final_positions.append({
            "id": a.id,
            "tongue": a.tongue or "NULL",
            "position": [round(float(x), 4) for x in a.position],
            "norm": round(a.norm, 4),
            "is_rogue": a.is_rogue,
            "flagged_by": len(a.flagged_by),
            "quarantined": a.is_quarantined
        })

    return RogueDetectionResponse(
        simulation_id=f"demo_{uuid.uuid4().hex[:8]}",
        steps=steps,
        result="QUARANTINED" if rogue.is_quarantined else "DETECTED" if len(rogue.flagged_by) > 0 else "EVADED",
        rogue_detected=rogue.is_quarantined,
        detection_step=detection_step if detection_step >= 0 else steps,
        consensus_votes=len(rogue.flagged_by),
        false_positives=false_positives,
        final_positions=final_positions,
        metrics={
            "avg_isolation_distance": round(avg_rogue_dist, 3),
            "rogue_final_norm": round(rogue.norm, 3),
            "detection_rate": 1.0 if rogue.is_quarantined else len(rogue.flagged_by) / 6
        }
    )


@app.get("/v1/demo/swarm-coordination", response_model=SwarmCoordinationResponse, tags=["Demo"])
async def demo_swarm_coordination(agents: int = 12, steps: int = 30):
    """
    **LIVE DEMO: Swarm Coordination**

    Watch agents self-organize in hyperbolic space using only local
    repulsion rules - no central coordinator required.

    Demonstrates jam-resistant, decentralized coordination.
    """
    import numpy as np
    np.random.seed(int(time.time()) % 10000)

    # Initialize agents in tight cluster
    positions = []
    for i in range(agents):
        pos = np.random.normal(0, 0.05, 3)
        pos = pos / (np.linalg.norm(pos) + 0.1) * 0.1
        positions.append(pos)

    def hyperbolic_dist(u, v):
        nu, nv = np.linalg.norm(u), np.linalg.norm(v)
        diff_sq = np.linalg.norm(u - v) ** 2
        denom = (1 - nu**2) * (1 - nv**2)
        if denom <= 1e-10:
            return float('inf')
        return float(np.arccosh(max(1 + 2 * diff_sq / denom, 1.0)))

    def project(pos, max_n=0.95):
        n = np.linalg.norm(pos)
        return pos * (max_n / n) if n > max_n else pos

    # Calculate initial distances
    initial_distances = []
    for i in range(agents):
        for j in range(i+1, agents):
            initial_distances.append(hyperbolic_dist(positions[i], positions[j]))
    initial_avg = float(np.mean(initial_distances))

    collisions = 0
    boundary_breaches = 0

    # Simulation
    for step in range(steps):
        forces = [np.zeros(3) for _ in range(agents)]

        for i in range(agents):
            for j in range(i+1, agents):
                d = hyperbolic_dist(positions[i], positions[j])

                if d < 0.1:
                    collisions += 1

                if d < 0.5 and d > 0.01:
                    direction = positions[i] - positions[j]
                    direction = direction / (np.linalg.norm(direction) + 1e-10)
                    force = (0.5 - d) * 0.3
                    forces[i] += force * direction
                    forces[j] -= force * direction

        for i in range(agents):
            positions[i] = positions[i] + forces[i]
            positions[i] = positions[i] + np.random.normal(0, 0.02, 3)
            old_norm = np.linalg.norm(positions[i])
            positions[i] = project(positions[i])
            if old_norm > 0.95:
                boundary_breaches += 1

    # Calculate final distances
    final_distances = []
    for i in range(agents):
        for j in range(i+1, agents):
            final_distances.append(hyperbolic_dist(positions[i], positions[j]))
    final_avg = float(np.mean(final_distances))

    # Coordination score: how well did they spread without collisions
    coord_score = min(1.0, (final_avg / max(initial_avg, 0.01)) * 0.5) * (1 - collisions / (agents * steps))

    return SwarmCoordinationResponse(
        simulation_id=f"swarm_{uuid.uuid4().hex[:8]}",
        agents=agents,
        initial_avg_distance=round(initial_avg, 4),
        final_avg_distance=round(final_avg, 4),
        collisions=collisions,
        boundary_breaches=boundary_breaches,
        coordination_score=round(max(0, coord_score), 3)
    )


@app.get("/v1/demo/pipeline-layers", tags=["Demo"])
async def demo_pipeline_layers(
    action: str = "READ",
    trust: float = 0.7,
    sensitivity: float = 0.5
):
    """
    **LIVE DEMO: 14-Layer Pipeline Visualization**

    See exactly how each layer of the SCBE pipeline processes a request.
    Understand the math behind AI governance decisions.
    """
    agent_id = f"demo-agent-{uuid.uuid4().hex[:6]}"
    target = "demo_resource"

    # Detailed pipeline execution
    layers = {}

    # Layer 1: Complex Context Embedding
    seed = hashlib.sha256(f"{agent_id}:{action}:{target}".encode()).digest()
    complex_coords = [(seed[i] - 128) / 128.0 for i in range(6)]
    layers["L1_complex_context"] = {
        "description": "Embed request as complex numbers",
        "output": [round(c, 4) for c in complex_coords]
    }

    # Layer 2-4: Realification & Weighting
    radius = (1 - trust) * 0.8 + 0.1
    position = tuple(c * radius for c in complex_coords)
    layers["L2-4_realification"] = {
        "description": "Map to real manifold with trust weighting",
        "trust_radius": round(radius, 4),
        "position": [round(p, 4) for p in position]
    }

    # Layer 5-7: Hyperbolic Geometry
    safe_center = (0.0, 0.0, 0.0, 0.0, 0.0, 0.0)
    norm1_sq = sum(x**2 for x in position)
    diff_sq = sum((a - b)**2 for a, b in zip(position, safe_center))
    denom = (1 - min(norm1_sq, 0.9999)) * 1.0
    delta = 2 * diff_sq / denom if denom > 0 else 0
    distance = math.acosh(1 + delta) if delta >= 0 else 0.0

    layers["L5-7_hyperbolic"] = {
        "description": "Calculate Poincaré ball distance from safe center",
        "position_norm": round(math.sqrt(norm1_sq), 4),
        "hyperbolic_distance": round(distance, 4),
        "interpretation": "closer to 0 = safer, higher = riskier"
    }

    # Layer 8: Realm Trust
    realm_trust = trust * (1 - sensitivity * 0.5)
    layers["L8_realm_trust"] = {
        "description": "Compute realm-adjusted trust",
        "base_trust": trust,
        "sensitivity_penalty": round(sensitivity * 0.5, 4),
        "realm_trust": round(realm_trust, 4)
    }

    # Layer 9-10: Spectral/Spin Coherence
    coherence = 1.0 - abs(math.sin(distance * math.pi))
    layers["L9-10_coherence"] = {
        "description": "Spectral and spin coherence analysis",
        "coherence_score": round(coherence, 4),
        "interpretation": "measures stability of request pattern"
    }

    # Layer 11: Temporal Pattern
    temporal_score = trust * 0.9 + 0.1
    layers["L11_temporal"] = {
        "description": "Temporal pattern analysis",
        "temporal_score": round(temporal_score, 4)
    }

    # Layer 12: Harmonic Scaling
    R = 2
    d = int(sensitivity * 3) + 1
    H = R ** d
    risk_factor = (1 - realm_trust) * sensitivity * 0.5
    layers["L12_harmonic"] = {
        "description": "Harmonic scaling and risk computation",
        "dimension": d,
        "harmonic_value": H,
        "risk_factor": round(risk_factor, 4)
    }

    # Layer 13: Final Score
    final_score = (realm_trust * 0.6 + coherence * 0.2 + temporal_score * 0.2) - risk_factor
    if final_score > 0.6:
        decision = "ALLOW"
    elif final_score > 0.3:
        decision = "QUARANTINE"
    else:
        decision = "DENY"

    layers["L13_decision"] = {
        "description": "Aggregate scores and make decision",
        "weights": {"realm_trust": 0.6, "coherence": 0.2, "temporal": 0.2},
        "risk_penalty": round(risk_factor, 4),
        "final_score": round(final_score, 4),
        "decision": decision,
        "thresholds": {"ALLOW": "> 0.6", "QUARANTINE": "0.3 - 0.6", "DENY": "< 0.3"}
    }

    # Layer 14: Telemetry
    layers["L14_telemetry"] = {
        "description": "Audit logging and telemetry",
        "timestamp": datetime.utcnow().isoformat() + "Z",
        "logged": True
    }

    return {
        "demo_id": f"pipeline_{uuid.uuid4().hex[:8]}",
        "input": {
            "agent_id": agent_id,
            "action": action,
            "target": target,
            "trust": trust,
            "sensitivity": sensitivity
        },
        "layers": layers,
        "final_decision": decision,
        "final_score": round(final_score, 4)
    }


# =============================================================================
# Startup
# =============================================================================

@app.on_event("startup")
async def startup():
    if init_billing_db is not None:
        try:
            init_billing_db()
        except Exception as exc:
            logger.warning(json.dumps({"event": "billing_db_init_failed", "error": str(exc)}))
    persistence = get_persistence()
    logger.info(json.dumps({
        "event": "api_startup",
        "version": "1.0.0",
        "endpoints": 14,
        "firebase_connected": persistence.is_connected
    }))


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8080)
