# Copyright 2026 Vijil, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

# AUTO-GENERATED from specs/service_agent_environment.json — do not edit manually.
# Re-generate with: make generate-cli

import click

from vijil_cli.client import api
from vijil_cli.output import print_detail, print_json, print_table


@click.group()
def genome():
    """Manage agent genomes."""


@genome.command("list")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
def genome_list(as_json):
    """GET /v1/genomes/"""
    resp = api().get("/v1/genomes/")
    data = resp.json()
    if as_json:
        print_json(data)
    else:
        rows = data if isinstance(data, list) else next((v for v in data.values() if isinstance(v, list)), [data])
        print_table(rows if isinstance(rows, list) else [rows], columns=["id", "agent_id", "created_at"])

@genome.command("get")
@click.argument("genome_id")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
def genome_get(genome_id, as_json):
    """GET /v1/genomes/{genome_id}"""
    resp = api().get(f"/v1/genomes/{genome_id}")
    data = resp.json()
    if as_json:
        print_json(data)
    else:
        print_detail(data)

@genome.command("create")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
def genome_create(as_json):
    """POST /v1/genomes/"""
    resp = api().post("/v1/genomes/", json={})
    data = resp.json()
    if as_json:
        print_json(data)
    else:
        print_detail(data)

@genome.command("update")
@click.argument("genome_id")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
def genome_update(genome_id, as_json):
    """PUT /v1/genomes/{genome_id}"""
    resp = api().put(f"/v1/genomes/{genome_id}", json={})
    data = resp.json()
    if as_json:
        print_json(data)
    else:
        print_detail(data)

@genome.command("extract")
@click.argument("agent_id")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
def genome_extract(agent_id, as_json):
    """GET /v1/genomes/{agent_id}/extract"""
    resp = api().get(f"/v1/genomes/{agent_id}/extract")
    data = resp.json()
    if as_json:
        print_json(data)
    else:
        print_detail(data)
