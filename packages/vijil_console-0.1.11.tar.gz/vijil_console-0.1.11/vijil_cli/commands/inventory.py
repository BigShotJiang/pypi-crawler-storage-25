# Copyright 2026 Vijil, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

# AUTO-GENERATED from specs/service_agent_environment.json — do not edit manually.
# Re-generate with: make generate-cli

import click

from vijil_cli.client import api
from vijil_cli.output import print_detail, print_json, print_table


@click.group()
def inventory():
    """Discover and manage AI resources."""


@inventory.command("scan")
@click.option("--regions", help="Regions (JSON array)")
@click.option("--permission-tier", type=click.Choice(["minimal", "elevated"]), help="IAM permission level requested of the vijil-discover role.  Mirrors the ``permission_tie...")
@click.option("--scan-tier", type=click.Choice(["passive", "active"]), help="Network scan aggressiveness for vijil-discover.  Mirrors the ``network.scan_tier`` key accepted ...")
@click.option("--all-regions", is_flag=True, help="All Regions")
@click.option("--provider", type=click.Choice(["aws", "mock"]), help="Cloud provider (or mock) for vijil-discover.  ``mock`` uses vijil-discover's built-in mock provider — n...")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
def inventory_scan(regions, permission_tier, scan_tier, all_regions, provider, as_json):
    """Create Scan"""
    import json as _json
    body = {}
    if regions is not None:
        body["regions"] = _json.loads(regions)
    if permission_tier is not None:
        body["permission_tier"] = permission_tier
    if scan_tier is not None:
        body["scan_tier"] = scan_tier
    if all_regions:
        body["all_regions"] = all_regions
    if provider is not None:
        body["provider"] = provider
    resp = api().post("/v1/inventory/scans", json=body)
    data = resp.json()
    if as_json:
        print_json(data)
    else:
        print_detail(data)

@inventory.command("scan-list")
@click.option("--limit", type=int)
@click.option("--offset", type=int)
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
def inventory_scan_list(limit, offset, as_json):
    """List Scans"""
    params = {}
    if limit is not None:
        params["limit"] = limit
    if offset is not None:
        params["offset"] = offset
    resp = api().get("/v1/inventory/scans", params=params)
    data = resp.json()
    if as_json:
        print_json(data)
    else:
        rows = data if isinstance(data, list) else next((v for v in data.values() if isinstance(v, list)), [data])
        print_table(rows if isinstance(rows, list) else [rows], columns=["id", "status", "new_resource_count", "total_resource_count", "created_at"])

@inventory.command("scan-get")
@click.argument("scan_id")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
def inventory_scan_get(scan_id, as_json):
    """Get Scan"""
    resp = api().get(f"/v1/inventory/scans/{scan_id}")
    data = resp.json()
    if as_json:
        print_json(data)
    else:
        print_detail(data)

@inventory.command("scan-resources")
@click.argument("scan_id")
@click.option("--limit", type=int)
@click.option("--offset", type=int)
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
def inventory_scan_resources(scan_id, limit, offset, as_json):
    """List Scan Resources"""
    params = {}
    if limit is not None:
        params["limit"] = limit
    if offset is not None:
        params["offset"] = offset
    resp = api().get(f"/v1/inventory/scans/{scan_id}/resources", params=params)
    data = resp.json()
    if as_json:
        print_json(data)
    else:
        rows = data if isinstance(data, list) else next((v for v in data.values() if isinstance(v, list)), [data])
        print_table(rows if isinstance(rows, list) else [rows], columns=["resource_id", "classification", "confidence", "shadow_ai"])

@inventory.command("schedule")
@click.option("--enabled", is_flag=True, help="Enabled")
@click.option("--regions", help="Regions (JSON array)")
@click.option("--permission-tier", type=click.Choice(["minimal", "elevated"]), help="IAM permission level requested of the vijil-discover role.  Mirrors the ``permission_tie...")
@click.option("--scan-tier", type=click.Choice(["passive", "active"]), help="Network scan aggressiveness for vijil-discover.  Mirrors the ``network.scan_tier`` key accepted ...")
@click.option("--all-regions", is_flag=True, help="All Regions")
@click.option("--provider", type=click.Choice(["aws", "mock"]), help="Cloud provider (or mock) for vijil-discover.  ``mock`` uses vijil-discover's built-in mock provider — n...")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
def inventory_schedule(enabled, regions, permission_tier, scan_tier, all_regions, provider, as_json):
    """Upsert Schedule"""
    import json as _json
    body = {}
    if enabled:
        body["enabled"] = enabled
    if regions is not None:
        body["regions"] = _json.loads(regions)
    if permission_tier is not None:
        body["permission_tier"] = permission_tier
    if scan_tier is not None:
        body["scan_tier"] = scan_tier
    if all_regions:
        body["all_regions"] = all_regions
    if provider is not None:
        body["provider"] = provider
    resp = api().put("/v1/inventory/scans/schedule", json=body)
    data = resp.json()
    if as_json:
        print_json(data)
    else:
        print_detail(data)

@inventory.command("resources")
@click.option("--status", help="Filter by resource status (default: candidate).")
@click.option("--limit", type=int)
@click.option("--offset", type=int)
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
def inventory_resources(status, limit, offset, as_json):
    """List Resources"""
    params = {}
    if status is not None:
        params["status"] = status
    if limit is not None:
        params["limit"] = limit
    if offset is not None:
        params["offset"] = offset
    resp = api().get("/v1/inventory/resources", params=params)
    data = resp.json()
    if as_json:
        print_json(data)
    else:
        rows = data if isinstance(data, list) else next((v for v in data.values() if isinstance(v, list)), [data])
        print_table(rows if isinstance(rows, list) else [rows], columns=["id", "name", "provider", "service", "resource_type", "status", "classification"])

@inventory.command("resource-get")
@click.argument("resource_id")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
def inventory_resource_get(resource_id, as_json):
    """Get Resource"""
    resp = api().get(f"/v1/inventory/resources/{resource_id}")
    data = resp.json()
    if as_json:
        print_json(data)
    else:
        print_detail(data)

@inventory.command("flag")
@click.argument("resource_id")
@click.option("--name", help="Optional display name for the pending agent.")
@click.option("--notes", help="Freeform notes recorded on the agent metadata.")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
def inventory_flag(resource_id, name, notes, as_json):
    """Flag Resource"""
    body = {}
    if name is not None:
        body["name"] = name
    if notes is not None:
        body["notes"] = notes
    resp = api().post(f"/v1/inventory/resources/{resource_id}/flag", json=body)
    data = resp.json()
    if as_json:
        print_json(data)
    else:
        print_detail(data)

@inventory.command("wave")
@click.argument("resource_id")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
def inventory_wave(resource_id, as_json):
    """Wave Resource"""
    resp = api().post(f"/v1/inventory/resources/{resource_id}/wave", json={})
    data = resp.json()
    if as_json:
        print_json(data)
    else:
        print_detail(data)

@inventory.command("bulk-flag")
@click.option("--resource-ids", required=True, help="Resource Ids (JSON array)")
@click.option("--notes", help="Notes")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
def inventory_bulk_flag(resource_ids, notes, as_json):
    """Bulk Flag"""
    import json as _json
    body = {}
    if resource_ids is not None:
        body["resource_ids"] = _json.loads(resource_ids)
    if notes is not None:
        body["notes"] = notes
    resp = api().post("/v1/inventory/resources/bulk-flag", json=body)
    data = resp.json()
    if as_json:
        print_json(data)
    else:
        print_detail(data)

@inventory.command("bulk-wave")
@click.option("--resource-ids", required=True, help="Resource Ids (JSON array)")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
def inventory_bulk_wave(resource_ids, as_json):
    """Bulk Wave"""
    import json as _json
    body = {}
    if resource_ids is not None:
        body["resource_ids"] = _json.loads(resource_ids)
    resp = api().post("/v1/inventory/resources/bulk-wave", json=body)
    data = resp.json()
    if as_json:
        print_json(data)
    else:
        print_detail(data)
