# Copyright 2026 Vijil, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

# AUTO-GENERATED from specs/service_agent_environment.json — do not edit manually.
# Re-generate with: make generate-cli

import click

from vijil_cli.client import api
from vijil_cli.config import require_team_id
from vijil_cli.output import print_detail, print_json, print_table


@click.group()
def agent():
    """Manage AI agents."""


@agent.command("list")
@click.option("--statuses", help="Filter by status(es). If not provided, defaults to non-archived statuses.")
@click.option("--limit", type=int, help="Maximum number of results")
@click.option("--offset", type=int, help="Number of results to skip")
@click.option("--include-scores", is_flag=True, help="When true, sideloads the latest completed evaluation scores onto each agent.")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
def agent_list(statuses, limit, offset, include_scores, as_json):
    """Get Agent Configurations"""
    params = {}
    if statuses is not None:
        params["statuses"] = statuses
    if limit is not None:
        params["limit"] = limit
    if offset is not None:
        params["offset"] = offset
    if include_scores:
        params["include_scores"] = include_scores
    resp = api().get("/v1/agent-configurations/", params=params)
    data = resp.json()
    if as_json:
        print_json(data)
    else:
        rows = data if isinstance(data, list) else next((v for v in data.values() if isinstance(v, list)), [data])
        print_table(rows if isinstance(rows, list) else [rows], columns=["id", "agent_name", "model_name", "created_at"])

@agent.command("create")
@click.option("--id", help="Id")
@click.option("--hub", help="Hub")
@click.option("--model-name", help="Model Name")
@click.option("--agent-name", help="Agent Name")
@click.option("--agent-url", help="Agent Url")
@click.option("--hub-config", help="Hub Config (JSON object)")
@click.option("--status", help="Status")
@click.option("--api-key-id", help="Api Key Id")
@click.option("--api-key", help="Api Key")
@click.option("--agent-system-prompt", help="Agent System Prompt")
@click.option("--agent-policy-files", help="Agent Policy Files (JSON array)")
@click.option("--rag-params", help="Rag Params (JSON object)")
@click.option("--function-route-params", help="Function Route Params (JSON object)")
@click.option("--mcp-config", help="MCP (Model Context Protocol) proxy configuration. (JSON object)")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
def agent_create(
    id,
    hub,
    model_name,
    agent_name,
    agent_url,
    hub_config,
    status,
    api_key_id,
    api_key,
    agent_system_prompt,
    agent_policy_files,
    rag_params,
    function_route_params,
    mcp_config,
    as_json,
):
    """Create Agent Configuration"""
    import json as _json
    body = {}
    if id is not None:
        body["id"] = id
    if hub is not None:
        body["hub"] = hub
    if model_name is not None:
        body["model_name"] = model_name
    if agent_name is not None:
        body["agent_name"] = agent_name
    if agent_url is not None:
        body["agent_url"] = agent_url
    if hub_config is not None:
        body["hub_config"] = _json.loads(hub_config)
    if status is not None:
        body["status"] = status
    if api_key_id is not None:
        body["api_key_id"] = api_key_id
    if api_key is not None:
        body["api_key"] = api_key
    if agent_system_prompt is not None:
        body["agent_system_prompt"] = agent_system_prompt
    if agent_policy_files is not None:
        body["agent_policy_files"] = _json.loads(agent_policy_files)
    if rag_params is not None:
        body["rag_params"] = _json.loads(rag_params)
    if function_route_params is not None:
        body["function_route_params"] = _json.loads(function_route_params)
    if mcp_config is not None:
        body["mcp_config"] = _json.loads(mcp_config)
    resp = api().post("/v1/agent-configurations/", json=body)
    data = resp.json()
    if as_json:
        print_json(data)
    else:
        print_detail(data)

@agent.command("get")
@click.argument("agent_id")
@click.option("--include-scores", is_flag=True, help="When true, sideloads the latest completed evaluation scores onto the agent.")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
def agent_get(agent_id, include_scores, as_json):
    """Get Agent Configuration By Id"""
    params = {}
    if include_scores:
        params["include_scores"] = include_scores
    resp = api().get(f"/v1/agent-configurations/{agent_id}", params=params)
    data = resp.json()
    if as_json:
        print_json(data)
    else:
        print_detail(data)

@agent.command("update")
@click.argument("agent_id")
@click.option("--status", type=click.Choice(["draft", "creating", "active", "under_review", "deprecated", "archived", "pending", "rejected"]), help="Agent status values.")
@click.option("--agent-name", help="Agent Name")
@click.option("--agent-url", help="Agent Url")
@click.option("--model-name", help="Model Name")
@click.option("--api-key", help="API key value. Stored directly in the agent configuration.")
@click.option("--agent-system-prompt", help="Agent System Prompt")
@click.option("--hub", help="Hub")
@click.option("--rate-limit-requests-per-minute", type=int, help="Rate limit for API requests per minute")
@click.option("--access-level", type=click.Choice(["black_box", "grey_box", "white_box"]), help="Access level for agent analysis.  Black Box: URL only - behavioral testing o...")
@click.option("--agent-params", help="Model parameters for agent configuration. (JSON object)")
@click.option("--mcp-config", help="MCP (Model Context Protocol) proxy configuration. (JSON object)")
@click.option("--delegated-agents", help="Delegated Agents (JSON array)")
@click.option("--white-box-config", help="Source code access configuration for white box analysis. (JSON object)")
@click.option("--agent-metadata", help="Agent metadata for display and organization. (JSON object)")
@click.option("--purpose", help="Purpose")
@click.option("--protocol", type=click.Choice(["chat_completions", "a2a"]), help="Communication protocol for agent endpoints.")
@click.option("--test-score", type=float, help="Test Score")
@click.option("--last-tested-by", help="Last Tested By")
@click.option("--evaluated-harnesses", help="Evaluated Harnesses (JSON array)")
@click.option("--last-evaluated-at", type=int, help="Last Evaluated At")
@click.option("--protection-status", type=click.Choice(["unprotected", "configured", "domed"]), help="Dome protection lifecycle state.")
@click.option("--dome-config-id", help="Dome Config Id")
@click.option("--dome-manually-configured", is_flag=True, help="Dome Manually Configured")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
def agent_update(
    agent_id,
    status,
    agent_name,
    agent_url,
    model_name,
    api_key,
    agent_system_prompt,
    hub,
    rate_limit_requests_per_minute,
    access_level,
    agent_params,
    mcp_config,
    delegated_agents,
    white_box_config,
    agent_metadata,
    purpose,
    protocol,
    test_score,
    last_tested_by,
    evaluated_harnesses,
    last_evaluated_at,
    protection_status,
    dome_config_id,
    dome_manually_configured,
    as_json,
):
    """Update Agent Configuration"""
    import json as _json
    body = {}
    if status is not None:
        body["status"] = status
    if agent_name is not None:
        body["agent_name"] = agent_name
    if agent_url is not None:
        body["agent_url"] = agent_url
    if model_name is not None:
        body["model_name"] = model_name
    if api_key is not None:
        body["api_key"] = api_key
    if agent_system_prompt is not None:
        body["agent_system_prompt"] = agent_system_prompt
    if hub is not None:
        body["hub"] = hub
    if rate_limit_requests_per_minute is not None:
        body["rate_limit_requests_per_minute"] = rate_limit_requests_per_minute
    if access_level is not None:
        body["access_level"] = access_level
    if agent_params is not None:
        body["agent_params"] = _json.loads(agent_params)
    if mcp_config is not None:
        body["mcp_config"] = _json.loads(mcp_config)
    if delegated_agents is not None:
        body["delegated_agents"] = _json.loads(delegated_agents)
    if white_box_config is not None:
        body["white_box_config"] = _json.loads(white_box_config)
    if agent_metadata is not None:
        body["agent_metadata"] = _json.loads(agent_metadata)
    if purpose is not None:
        body["purpose"] = purpose
    if protocol is not None:
        body["protocol"] = protocol
    if test_score is not None:
        body["test_score"] = test_score
    if last_tested_by is not None:
        body["last_tested_by"] = last_tested_by
    if evaluated_harnesses is not None:
        body["evaluated_harnesses"] = _json.loads(evaluated_harnesses)
    if last_evaluated_at is not None:
        body["last_evaluated_at"] = last_evaluated_at
    if protection_status is not None:
        body["protection_status"] = protection_status
    if dome_config_id is not None:
        body["dome_config_id"] = dome_config_id
    if dome_manually_configured:
        body["dome_manually_configured"] = dome_manually_configured
    resp = api().put(f"/v1/agent-configurations/{agent_id}", json=body)
    data = resp.json()
    if as_json:
        print_json(data)
    else:
        print_detail(data)

@agent.command("import")
@click.option("--agent-url", help="Remote black_box: Agent endpoint URL to call (e.g., https://api.example.com/agent)")
@click.option("--agent-card", help="Local grey_box: Upload agent configuration/card JSON directly (JSON object)")
@click.option("--source-code", help="Local white_box: Upload agent source code files directly (JSON object)")
@click.option("--framework", help="Framework identifier (for informational purposes only)")
@click.option("--entry-point", help="For white box: path to main file")
@click.option("--override-name", help="Override agent name")
@click.option("--rate-limit-requests-per-minute", type=int, help="Rate Limit Requests Per Minute")
@click.option("--api-key", help="API key for the agent")
@click.option("--external-id", help="External identity ID")
@click.option("--identity-provider", help="Identity provider name")
@click.option("--idp-metadata", help="IdP-specific metadata (JSON object)")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
def agent_import(
    agent_url,
    agent_card,
    source_code,
    framework,
    entry_point,
    override_name,
    rate_limit_requests_per_minute,
    api_key,
    external_id,
    identity_provider,
    idp_metadata,
    as_json,
):
    """Import Agent Unified"""
    import json as _json
    body = {}
    if agent_url is not None:
        body["agent_url"] = agent_url
    if agent_card is not None:
        body["agent_card"] = _json.loads(agent_card)
    if source_code is not None:
        body["source_code"] = _json.loads(source_code)
    if framework is not None:
        body["framework"] = framework
    if entry_point is not None:
        body["entry_point"] = entry_point
    if override_name is not None:
        body["override_name"] = override_name
    if rate_limit_requests_per_minute is not None:
        body["rate_limit_requests_per_minute"] = rate_limit_requests_per_minute
    if api_key is not None:
        body["api_key"] = api_key
    if external_id is not None:
        body["external_id"] = external_id
    if identity_provider is not None:
        body["identity_provider"] = identity_provider
    if idp_metadata is not None:
        body["idp_metadata"] = _json.loads(idp_metadata)
    resp = api().post("/v1/agent-configurations/import", json=body)
    data = resp.json()
    if as_json:
        print_json(data)
    else:
        print_detail(data)

@agent.command("validate-import")
@click.option("--agent-url", help="Remote black_box: Agent endpoint URL to call (e.g., https://api.example.com/agent)")
@click.option("--agent-card", help="Local grey_box: Upload agent configuration/card JSON directly (JSON object)")
@click.option("--source-code", help="Local white_box: Upload agent source code files directly (JSON object)")
@click.option("--framework", help="Framework identifier (for informational purposes only)")
@click.option("--entry-point", help="For white box: path to main file")
@click.option("--override-name", help="Override agent name")
@click.option("--rate-limit-requests-per-minute", type=int, help="Rate Limit Requests Per Minute")
@click.option("--api-key", help="API key for the agent")
@click.option("--external-id", help="External identity ID")
@click.option("--identity-provider", help="Identity provider name")
@click.option("--idp-metadata", help="IdP-specific metadata (JSON object)")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
def agent_validate_import(
    agent_url,
    agent_card,
    source_code,
    framework,
    entry_point,
    override_name,
    rate_limit_requests_per_minute,
    api_key,
    external_id,
    identity_provider,
    idp_metadata,
    as_json,
):
    """Validate Agent Import"""
    import json as _json
    body = {}
    if agent_url is not None:
        body["agent_url"] = agent_url
    if agent_card is not None:
        body["agent_card"] = _json.loads(agent_card)
    if source_code is not None:
        body["source_code"] = _json.loads(source_code)
    if framework is not None:
        body["framework"] = framework
    if entry_point is not None:
        body["entry_point"] = entry_point
    if override_name is not None:
        body["override_name"] = override_name
    if rate_limit_requests_per_minute is not None:
        body["rate_limit_requests_per_minute"] = rate_limit_requests_per_minute
    if api_key is not None:
        body["api_key"] = api_key
    if external_id is not None:
        body["external_id"] = external_id
    if identity_provider is not None:
        body["identity_provider"] = identity_provider
    if idp_metadata is not None:
        body["idp_metadata"] = _json.loads(idp_metadata)
    resp = api().post("/v1/agent-configurations/import/validate", json=body)
    data = resp.json()
    if as_json:
        print_json(data)
    else:
        print_detail(data)

@agent.command("archive")
@click.argument("id")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
def agent_archive(id, as_json):
    """Archive Agent Configuration"""
    resp = api().put(f"/v1/agent-configurations/{id}/archive", json={})
    data = resp.json()
    if as_json:
        print_json(data)
    else:
        print_detail(data)

@agent.command("lifecycle")
@click.argument("id")
@click.option("--trust-stage", type=click.Choice(["registered", "tested", "hardened", "trusted", "optimized", "adapted"]), required=True, help="Trust maturity lifecycle stag...")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
def agent_lifecycle(id, trust_stage, as_json):
    """Update Agent Lifecycle"""
    body = {}
    if trust_stage is not None:
        body["trust_stage"] = trust_stage
    resp = api().put(f"/v1/agent-configurations/{id}/lifecycle", json=body)
    data = resp.json()
    if as_json:
        print_json(data)
    else:
        print_detail(data)

@agent.command("dome-configs")
@click.argument("agent_id")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
def agent_dome_configs(agent_id, as_json):
    """Get Agent Dome Config"""
    params = {}
    params["team_id"] = require_team_id()
    resp = api().get(f"/v1/agent-configurations/{agent_id}/dome-configs", params=params)
    data = resp.json()
    if as_json:
        print_json(data)
    else:
        print_detail(data)

@agent.command("eval-config")
@click.argument("id")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON.")
def agent_eval_config(id, as_json):
    """Get Evaluation Config"""
    resp = api().get(f"/v1/agent-configurations/{id}/evaluation-config")
    data = resp.json()
    if as_json:
        print_json(data)
    else:
        print_detail(data)
