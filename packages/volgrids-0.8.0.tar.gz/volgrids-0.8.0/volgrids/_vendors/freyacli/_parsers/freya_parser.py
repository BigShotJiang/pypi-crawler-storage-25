from pathlib import Path

import volgrids._vendors.freyacli as fy

# //////////////////////////////////////////////////////////////////////////////
class FreyaParser:
    def __init__(self, raw_rules: str, raw_help: str):
        rules = self._preprocess_macros(raw_rules)
        helps = self._preprocess_macros(raw_help)

        self.tree = fy.Subcommand('', None)
        self.node = self.tree
        self._tree_build_rules(rules)
        self._tree_add_helps(helps)


    # --------------------------------------------------------------------------
    @classmethod
    def from_files(cls, path_fyr: str|Path, path_fyh: str|Path) -> "FreyaParser":
        return cls(
            raw_rules = Path(path_fyr).read_text(),
            raw_help = Path(path_fyh).read_text(),
        )


    # --------------------------------------------------------------------------
    def _tree_build_rules(self, rules: str):
        node: fy.Subcommand = self.tree
        for token in rules.split():
            if token.startswith('@'):
                name = token[1:]
                if not name: raise fy.FreyaSyntaxError("Branch names can't be empty.")
                node = node.add_child(name)
                continue

            if token == "!@":
                if node.depth == 0: raise fy.FreyaSyntaxError("Unexpected '!@' token found outside of any branch.")
                node = node.parent
                continue

            node.add_rule(fy.ArgumentRule(token))

        if not node.is_root():
            raise fy.FreyaSyntaxError(f"Unterminated branch (missing !@ keyword {node.depth} times)")


    # --------------------------------------------------------------------------
    def _tree_add_helps(self, helps: str):
        def find_first_space(s: str) -> int:
            idx = s.find(' ')
            return len(s) if idx == -1 else idx

        node: fy.Subcommand = self.tree
        help_str: fy.HelpStr = self.tree.help_str

        for row in helps.split('\n'):
            row = row.strip()

            if row.startswith('@'):
                first_space = find_first_space(row)
                name = row[1:first_space]
                if not name: raise fy.FreyaSyntaxError("Branch names can't be empty.")

                node = node.get_child(name)
                row = row[first_space+1:].lstrip()

            elif row.startswith("!@"):
                if node.depth == 0: raise fy.FreyaSyntaxError("Unexpected '!@' token found outside of any branch.")
                first_space = find_first_space(row)

                node = node.parent
                row = row[first_space+1:].lstrip()

            fyh_start = row.find("!fyh:")
            if fyh_start != -1:
                first_space = find_first_space(row)
                key = row[5:first_space]
                row = row[first_space+1:].lstrip()

                if key == '_':
                    help_str = node.help_str
                elif key in node.rules:
                    help_str = node.rules[key].help_str
                else:
                    raise fy.FreyaSyntaxError(f"Help specified for non-existent rule '{key}'.")

            if not row: continue
            help_str.concat(row)


    # --------------------------------------------------------------------------
    @classmethod
    def _preprocess_macros(cls, rules: str):
        # -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -
        def get_next_macro_idxs(s: str) -> tuple[int, int]|None:
            i0 = s.find("!def")
            if i0 == -1: return

            i1 = s.find("!fed")
            if i1 == -1: raise fy.FreyaSyntaxError("!def macro is missing the '!fed' closure.")

            return i0,i1

        # -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -
        def get_text_around_macro(s: str, idxs: tuple[int, int]) -> str:
            return s[:idxs[0]] + s[idxs[1]+4:]

        # -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -
        def get_text_inside_macro(s: str, idxs: tuple[int, int]) -> str:
            return s[idxs[0]+4:idxs[1]]

        # -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -
        def get_macros(s: str) -> dict[str, str]:
            macros = {}
            s_lower = s.lower()
            while s_lower:
                idxs = get_next_macro_idxs(s_lower)
                if idxs is None: break
                macro_split = get_text_inside_macro(s, idxs).split()
                s = get_text_around_macro(s, idxs)
                s_lower = get_text_around_macro(s_lower, idxs)

                if not macro_split:
                    raise fy.FreyaSyntaxError("A !def macro is missing its name.")

                macro_key = macro_split[0]
                macro_val = "" if len(macro_split) == 1 \
                    else '\n'.join(macro_split[1:])

                if "!def" in macro_val:
                    raise fy.FreyaSyntaxError("Nested !def macros are not allowed")

                if macro_key in macros:
                    raise fy.FreyaSyntaxError(f"Duplicate definition of '{macro_key}' macro")

                macros[macro_key] = macro_val
            return macros

        # -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -
        def apply_macros(s: str):
            macros = get_macros(s)
            for macro_key, macro_val in macros.items():
                s = s.replace(f"!use:{macro_key}", macro_val)

            while s:
                idxs = get_next_macro_idxs(s)
                if idxs is None: break
                s = get_text_around_macro(s, idxs)

            return s

        # -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -  -
        without_comments = (
            row.split('#')[0].strip() for row in rules.split('\n')
        )
        return apply_macros(
            '\n'.join(filter(None, without_comments))
        )


# //////////////////////////////////////////////////////////////////////////////
