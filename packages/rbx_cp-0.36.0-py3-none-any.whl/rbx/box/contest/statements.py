from typing import Annotated, List, Optional

import syncer
import typer

from rbx import annotations, console
from rbx.box import cd, environment, limits_info, package_utils
from rbx.box.contest.build_contest_statements import (
    StatementBuildIssue,
    build_statement,
)
from rbx.box.contest.contest_package import (
    find_contest_package_or_die,
    within_contest,
)
from rbx.box.contest.schema import ContestProblem, ContestStatement
from rbx.box.formatting import href
from rbx.box.sanitizers import issue_stack
from rbx.box.schema import expand_any_vars
from rbx.box.statements.schema import StatementType

app = typer.Typer(no_args_is_help=True, cls=annotations.AliasGroup)


@app.command('build, b', help='Build statements.')
@within_contest
@syncer.sync
async def build(
    verification: environment.VerificationParam,
    names: Annotated[
        Optional[List[str]],
        typer.Argument(
            help='Names of statements to build.',
        ),
    ] = None,
    languages: Annotated[
        Optional[List[str]],
        typer.Option(
            help='Languages to build statements for. If not specified, build statements for all available languages.',
        ),
    ] = None,
    validate: Annotated[
        bool,
        typer.Option(help='Whether to validate outputs for testcases or not.'),
    ] = True,
    output: Annotated[
        StatementType,
        typer.Option(
            case_sensitive=False,
            help='Output type to be generated.',
        ),
    ] = StatementType.PDF,
    samples: Annotated[
        bool,
        typer.Option(help='Whether to build the statement with samples or not.'),
    ] = True,
    vars: Annotated[
        Optional[List[str]],
        typer.Option(
            '--vars',
            help='Variables to be used in the statements.',
        ),
    ] = None,
    install_tex: Annotated[
        bool,
        typer.Option(help='Whether to install missing LaTeX packages.'),
    ] = False,
    profile: Annotated[
        Optional[str],
        typer.Option(
            '-p',
            '--profile',
            help='Timing profile to render statements against. Problems missing this profile are skipped with a warning.',
        ),
    ] = None,
):
    contest = find_contest_package_or_die()

    eligible_problems: List[ContestProblem] = list(contest.problems)
    if profile is not None:
        eligible_problems = []
        for problem in contest.problems:
            saved = limits_info.get_saved_limits_profile(
                profile, root=problem.get_path()
            )
            if saved is None:
                console.console.print(
                    f'[warning]Skipping problem [item]{problem.short_name}[/item]: timing profile [item]{profile}[/item] is not defined for it.[/warning]'
                )
                continue
            eligible_problems.append(problem)
        if not eligible_problems:
            console.console.print(
                f'[error]No problems in this contest define the timing profile [item]{profile}[/item].[/error]'
            )
            raise typer.Exit(1)

    candidate_languages = set(languages or [])
    candidate_names = set(names or [])

    def should_process(st: ContestStatement) -> bool:
        if candidate_languages and st.language not in candidate_languages:
            return False
        if candidate_names and st.name not in candidate_names:
            return False
        return True

    valid_statements = [st for st in contest.expanded_statements if should_process(st)]

    if not valid_statements:
        console.console.print(
            '[error]No statement found according to the specified criteria.[/error]',
        )
        raise typer.Exit(1)

    # TODO: possibly check the problem configuration for samples too
    samples = samples and any(st.samples for st in valid_statements)

    # At most run the validators, only in samples.
    problems_of_interest: Optional[List[ContestProblem]] = None
    if samples:
        from rbx.box.testcase_sample_utils import build_samples

        problems_of_interest = []
        for problem in eligible_problems:
            console.console.print(
                f'Processing problem [item]{problem.short_name}[/item]...'
            )
            with cd.new_package_cd(problem.get_path()):
                package_utils.clear_package_cache()

                try:
                    if not await build_samples(verification, validate):
                        issue_stack.add_issue(StatementBuildIssue(problem))
                    else:
                        problems_of_interest.append(problem)
                except Exception:
                    issue_stack.add_issue(StatementBuildIssue(problem))

    if profile is not None and problems_of_interest is None:
        problems_of_interest = eligible_problems

    built_statements = []

    with limits_info.use_profile(profile, when=lambda: profile is not None):
        for statement in valid_statements:
            built_statements.append(
                await build_statement(
                    statement,
                    contest,
                    problems_of_interest=problems_of_interest,
                    output_type=output,
                    use_samples=samples,
                    install_tex=install_tex,
                    custom_vars=expand_any_vars(
                        annotations.parse_dictionary_items(vars)
                    ),
                )
            )

    console.console.rule(title='Built statements')
    for statement, built_path in zip(valid_statements, built_statements):
        console.console.print(
            f'[item]{statement.name} {statement.language}[/item] -> {href(built_path)}'
        )


@app.callback()
def callback():
    pass
