import pathlib
from typing import Annotated, Dict, List, Optional, Set

import pydantic
from pydantic import (
    AfterValidator,
    BaseModel,
    ConfigDict,
    Field,
    TypeAdapter,
    model_validator,
)

from rbx.box.fields import (
    FNameField,
    NameField,
    Primitive,
    RecVars,
    Vars,
    expand_vars,
)
from rbx.box.statements.expander import expand_statements
from rbx.box.statements.schema import (
    ConversionStep,
    Joiner,
    StatementLanguage,
    StatementType,
)

Alias = Annotated[str, NameField()]


def ShortNameField(**kwargs):
    return Field(pattern=r'^[A-Z]+[0-9]*$', min_length=1, max_length=4, **kwargs)


def is_unique_by_name(statements: List['ContestStatement']) -> List['ContestStatement']:
    names = {st.name for st in statements}
    if len(names) != len(statements):
        raise ValueError('Statement names must be unique.')
    return statements


class ProblemStatementOverride(BaseModel):
    model_config = ConfigDict(extra='forbid')

    configure: List[Annotated[ConversionStep, Field(discriminator='type')]] = Field(
        default=[],
        description="""
Configure how certain conversion steps should happen when applied to the statement file.

Different from the `steps` field, this does not force the steps to happen, but rather only
configure them in case they are applied.
""",
    )

    vars: Dict[str, Primitive] = Field(
        default={},
        description='Variables to be merged into the problem statement vars.',
    )


class ContestStatement(BaseModel):
    model_config = ConfigDict(extra='forbid')

    name: str = FNameField(description='Name of this statement.')

    extends: Optional[str] = FNameField(
        default=None, description='Name of the statement to inherit from.'
    )

    language: StatementLanguage = Field(
        default='en', description='Language code for this statement (ISO 639-1).'
    )

    title: str = Field(
        default='',
        description='Title of the contest in this language.'
        'Will override the `titles` field of the contest.',
    )

    location: Optional[str] = Field(
        default=None, description='Location of the contest in this language.'
    )

    date: Optional[str] = Field(
        default=None, description='Date of the contest in this language.'
    )

    path: pathlib.Path = Field(
        default_factory=pathlib.Path,
        description='Path to the input statement file.',
    )

    type: StatementType = Field(
        default=StatementType.rbxTeX, description='Type of the input statement file.'
    )

    joiner: Optional[Joiner] = Field(
        default=None,
        description="""
Joiner to be used to build the statement.

This determines how problem statements will be joined into a single contest statement.""",
    )

    steps: List[Annotated[ConversionStep, Field(discriminator='type')]] = Field(
        default=[],
        description="""
Describes a sequence of conversion steps that should be applied to the statement file
of this contest.

Usually, it is not necessary to specify these, as they can be inferred from the
input statement type and the output statement type, but you can use this to force
certain conversion steps to happen.
""",
    )

    configure: List[Annotated[ConversionStep, Field(discriminator='type')]] = Field(
        default=[],
        description="""
Configure how certain conversion steps should happen when applied to the statement file of
this contest.

Different from the `steps` field, this does not force the steps to happen, but rather only
configure them in case they are applied.
""",
    )

    assets: List[str] = Field(
        default=[],
        description="""
Assets relative to the contest directory that should be included while building
the statement. Files will be included in the same folder as the statement file.
Can be glob pattern as well, such as `imgs/*.png`.
""",
    )

    override: Optional[ProblemStatementOverride] = Field(
        default=None,
        description='Override configuration for problem statements that are joined into this contest statement.',
    )

    inheritOverride: Optional[ProblemStatementOverride] = Field(
        default=None,
        description='Override configuration for problem statements that inherit from this contest statement.',
    )

    match: Optional[str] = FNameField(
        default=None,
        description="""
        Name of the problem-level statement to match this statement against.

        If not specified, will match against the first statement of the same language.
        """,
    )

    # Vars to be re-used in the statement.
    #   - It will be available as \VAR{vars} variable in the contest-level box statement.
    vars: RecVars = Field(
        default={}, description='Variables to be re-used across the package.'
    )

    samples: bool = Field(
        default=True,
        description='Whether to build the statement with samples.',
    )

    @property
    def expanded_vars(self) -> Vars:
        return expand_vars(self.vars)


class ContestProblem(BaseModel):
    short_name: str = ShortNameField(
        description="""
Short name of the problem. Usually, just an uppercase letter,
but can be a sequence of uppercase letters followed by a number."""
    )

    aliases: List[Alias] = Field(
        default_factory=list,
        description="""
Optional list of aliases for this problem. You can refer to the problem by its
short_name or by any of these aliases in commands such as [item]rbx on <name> run[/item].
Aliases must be unique across all problems (case-insensitive).""",
    )

    path: Optional[pathlib.Path] = Field(
        default=None,
        description="""
Path to the problem relative to the contest package directory.
If not specified, will expect the problem to be in ./{short_name}/ folder.""",
    )

    color: Optional[str] = Field(
        default=None,
        description="""
Color that represents this problem in the contest.

Can be a hex color (#abcdef or #abc format), or a color name among available X11 colors.

See https://en.wikipedia.org/wiki/X11_color_names for the list of supported color names.
""",
    )

    colorName: Optional[str] = Field(
        default=None,
        description="""
A custom color name for the color provided by this problem.

If not provided, will try to infer a color name from the color provided.
""",
        pattern=r'^[a-zA-Z]+$',
    )

    @model_validator(mode='after')
    def check_color(self):
        from colour import Color

        if self.color is None:
            return self

        Color(self.color)
        return self

    @property
    def hex_color(self) -> Optional[str]:
        from colour import Color

        if self.color is None:
            return None

        return Color(self.color).hex_l

    @property
    def color_name(self) -> Optional[str]:
        if self.colorName is not None:
            return self.colorName

        if self.color is None:
            return None

        from colour import Color

        color = Color(self.color)
        web_color = color.web
        if web_color.startswith('#'):
            return 'unknown'
        return web_color

    def get_path(self) -> pathlib.Path:
        return self.path or pathlib.Path(self.short_name)

    def all_identifiers(self) -> Set[str]:
        """All names that can be used to refer to this problem (short_name + aliases), lowercased."""
        return {self.short_name.lower()} | {a.lower() for a in self.aliases}


_CONTEST_NAME_VALIDATOR = TypeAdapter(Annotated[str, NameField()])


class Contest(BaseModel):
    model_config = ConfigDict(extra='forbid')

    use_variants: bool = Field(
        default=False,
        description=(
            'When true, this file is a sentinel marking the directory as a '
            'multi-contest dispatcher. The actual contests live in sibling '
            'files matching contest.<id>.rbx.yml. When set, no other Contest '
            'fields may be specified.'
        ),
    )

    name: str = Field(
        default='',
        description='Name of this contest.',
    )

    titles: Dict[str, str] = Field(
        default={},
        description='Titles for the contest in each language. '
        'Languages should be specified as lowercase ISO 639-1 codes.',
    )

    problems: List[ContestProblem] = Field(
        default=[], description='List of problems in this contest.'
    )

    @model_validator(mode='after')
    def _validate_dispatcher_or_real(self):
        # Maintenance contract: keep this tuple in sync with Contest's non-dispatcher
        # fields. `use_variants` is the only field allowed alongside dispatcher mode.
        if self.use_variants:
            for field in ('name', 'titles', 'problems', 'statements', 'vars'):
                value = getattr(self, field)
                if value:
                    raise ValueError(
                        f'Field {field!r} cannot be set when use_variants is true.'
                    )
            return self
        try:
            _CONTEST_NAME_VALIDATOR.validate_python(self.name)
        except pydantic.ValidationError as exc:
            raise ValueError(f'Invalid contest name: {exc}') from exc
        return self

    @property
    def is_dispatcher(self) -> bool:
        return self.use_variants

    @model_validator(mode='after')
    def check_problem_identifiers_unique(self):
        seen: Dict[str, str] = {}
        for problem in self.problems:
            identifiers = [problem.short_name.lower()] + [
                a.lower() for a in problem.aliases
            ]
            for ident in identifiers:
                if ident in seen:
                    raise ValueError(
                        f'Problem identifier {ident!r} is used by more than one problem '
                        f'(short_name or alias in problem {seen[ident]!r} and in {problem.short_name!r}).'
                    )
                seen[ident] = problem.short_name
        return self

    statements: Annotated[
        List[ContestStatement],
        AfterValidator(is_unique_by_name),
    ] = Field(
        default=[],
        description='Configure statements in this contest, per language.',
    )

    # Vars to be re-used in the statements.
    #   - It will be available as \VAR{vars} variable in the contest-level box statement.
    vars: RecVars = Field(
        default={}, description='Variables to be re-used across the package.'
    )

    @property
    def expanded_statements(self) -> List[ContestStatement]:
        return expand_statements(self.statements)

    @property
    def expanded_vars(self) -> Vars:
        return expand_vars(self.vars)
