import collections
import dataclasses
import pathlib
import shutil
import tempfile
from abc import ABC, abstractmethod
from typing import Dict, List, Optional, Type

import typer

from rbx import console
from rbx.box import environment, header, limits_info, naming, package
from rbx.box.contest import contest_package
from rbx.box.contest.schema import ContestProblem, ContestStatement
from rbx.box.formatting import href
from rbx.box.generation_schema import GenerationTestcaseEntry
from rbx.box.schema import Package, TaskType, Testcase
from rbx.box.statements.build_statements import (
    execute_build_on_statements,
)
from rbx.box.statements.schema import (
    ConversionStep,
    ConversionType,
    Statement,
    StatementType,
    TexToPDF,
    rbxToTeX,
)
from rbx.box.testcase_extractors import (
    extract_generation_testcases_from_groups,
    find_built_testcases,
)


@dataclasses.dataclass
class BuiltStatement:
    statement: Statement
    path: pathlib.Path
    output_type: StatementType


@dataclasses.dataclass
class BuiltContestStatement:
    statement: ContestStatement
    path: pathlib.Path
    output_type: StatementType


@dataclasses.dataclass
class BuiltProblemPackage:
    path: pathlib.Path
    package: Package
    problem: ContestProblem


class BasePackager(ABC):
    testcase_entries: List[GenerationTestcaseEntry]

    def __init__(self, testcase_entries: List[GenerationTestcaseEntry]):
        self.testcase_entries = testcase_entries

    @classmethod
    @abstractmethod
    def name(cls) -> str:
        pass

    @classmethod
    def task_types(cls) -> List[TaskType]:
        return [TaskType.BATCH]

    def languages(self):
        pkg = package.find_problem_package_or_die()

        res = set()
        for statement in pkg.expanded_statements:
            res.add(statement.language)
        return list(res)

    def package_basename(self):
        pkg = package.find_problem_package_or_die()
        shortname = naming.get_problem_shortname_or_require()
        if shortname is not None:
            return f'{shortname}-{pkg.name}'
        return pkg.name

    def statement_types(self) -> List[StatementType]:
        return [StatementType.PDF]

    @abstractmethod
    def package(
        self,
        build_path: pathlib.Path,
        into_path: pathlib.Path,
        built_statements: List[BuiltStatement],
    ) -> pathlib.Path:
        pass

    def get_built_testcase_entries(self) -> List[GenerationTestcaseEntry]:
        return find_built_testcases(self.testcase_entries)

    # Helper methods.
    def get_built_testcases_per_group(
        self,
    ) -> Dict[str, List[Testcase]]:
        entries = self.get_built_testcase_entries()
        res = collections.defaultdict(list)
        for entry in entries:
            res[entry.group_entry.group].append(entry.metadata.copied_to)
        return dict(res)

    def get_flattened_built_testcases(self) -> List[Testcase]:
        entries = self.get_built_testcase_entries()
        return [entry.metadata.copied_to for entry in entries]

    def get_statement_for_language_or_null(self, lang: str) -> Optional[Statement]:
        pkg = package.find_problem_package_or_die()
        for statement in pkg.expanded_statements:
            if statement.language == lang:
                return statement
        return None

    def get_statement_for_language_or_die(self, lang: str) -> Statement:
        statement = self.get_statement_for_language_or_null(lang)
        if statement is None:
            raise ValueError(f'No statement for language {lang} found.')
        return statement


class BaseContestPackager(ABC):
    @classmethod
    @abstractmethod
    def name(cls) -> str:
        pass

    @abstractmethod
    def package(
        self,
        built_packages: List[BuiltProblemPackage],
        build_path: pathlib.Path,
        into_path: pathlib.Path,
        built_statements: List[BuiltContestStatement],
    ) -> pathlib.Path:
        pass

    def languages(self):
        pkg = contest_package.find_contest_package_or_die()

        res = set()
        for statement in pkg.expanded_statements:
            res.add(statement.language)
        return list(res)

    def statement_types(self) -> List[StatementType]:
        return [StatementType.PDF]

    def get_statement_for_language(self, lang: str) -> ContestStatement:
        contest = contest_package.find_contest_package_or_die()
        for statement in contest.expanded_statements:
            if statement.language == lang:
                return statement
        raise


class ContestZipper(BaseContestPackager):
    def __init__(
        self, filename: str, zip_inner: bool = False, prefer_shortname: bool = True
    ):
        super().__init__()
        self.zip_inner = zip_inner
        self.filename = filename
        self.prefer_shortname = prefer_shortname

    def package(
        self,
        built_packages: List[BuiltProblemPackage],
        build_path: pathlib.Path,
        into_path: pathlib.Path,
        built_statements: List[BuiltContestStatement],
    ) -> pathlib.Path:
        for built_package in built_packages:
            if self.prefer_shortname:
                pkg_path = into_path / 'problems' / built_package.problem.short_name
            else:
                pkg_path = into_path / 'problems' / built_package.package.name

            if self.zip_inner:
                pkg_path.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy(built_package.path, pkg_path.with_suffix('.zip'))
            else:
                pkg_path.mkdir(parents=True, exist_ok=True)
                shutil.unpack_archive(built_package.path, pkg_path, format='zip')

        # Zip all.
        shutil.make_archive(str(build_path / self.filename), 'zip', into_path)

        return build_path / pathlib.Path(self.filename).with_suffix('.zip')


def get_packager_extra_mergeable_params(
    packager_cls: Type[BasePackager],
) -> List[ConversionStep]:
    res = []
    if packager_cls.name() == 'polygon':
        # TODO: migrate this into the packager class
        res.append(rbxToTeX(type=ConversionType.rbxToTex, externalize=True))
        res.append(
            TexToPDF(type=ConversionType.TexToPDF, externalize=True, demacro=True)
        )
    return res


async def run_packager(
    packager_cls: Type[BasePackager],
    verification: environment.VerificationParam,
    samples_only: bool = False,
    skip_packaging: bool = False,
    **kwargs,
) -> Optional[pathlib.Path]:
    from rbx.box import builder

    header.generate_header()
    built_groups = set(['samples']) if samples_only else None

    if limits_info.get_saved_limits_profile(packager_cls.name()) is not None:
        console.console.print(
            f'[warning]Using saved limits profile for [item]{packager_cls.name()}[/item].[/warning]'
        )

    with limits_info.use_profile(packager_cls.name()):
        if not await builder.verify(verification=verification, groups=built_groups):
            console.console.print(
                '[error]Build or verification failed, check the report.[/error]'
            )
            raise typer.Exit(1)

    testcase_entries = await extract_generation_testcases_from_groups(built_groups)
    pkg = package.find_problem_package_or_die()

    if pkg.type not in packager_cls.task_types():
        console.console.print(
            f'[error]Packager [item]{packager_cls.name()}[/item] does not support task type [item]{pkg.type}[/item].[/error]'
        )
        raise typer.Exit(1)

    packager = packager_cls(testcase_entries=testcase_entries, **kwargs)

    statement_types = packager.statement_types()
    built_statements = []

    with limits_info.use_profile(packager_cls.name()):
        for statement_type in statement_types:
            tracked_statements: List[Statement] = []
            languages = packager.languages()
            for language in languages:
                tracked_statements.append(
                    packager.get_statement_for_language_or_die(language)
                )

            built_paths = await execute_build_on_statements(
                tracked_statements,
                verification,
                output=statement_type,
                extra_mergeable_params=get_packager_extra_mergeable_params(
                    packager_cls
                ),
                # Skip building samples since they were already
                # built by the packager.
                skip_building=True,
            )
            built_statements.extend(
                [
                    BuiltStatement(statement, statement_path, statement_type)
                    for statement, statement_path in zip(
                        tracked_statements, built_paths, strict=True
                    )
                ]
            )

    if skip_packaging:
        return None
    console.console.print(f'Packaging problem for [item]{packager.name()}[/item]...')
    with (
        tempfile.TemporaryDirectory() as td,
        limits_info.use_profile(packager_cls.name()),
    ):
        result_path = packager.package(
            package.get_build_path(), pathlib.Path(td), built_statements
        )

    console.console.print(
        f'[success]Problem packaged for [item]{packager.name()}[/item]![/success]'
    )
    from rbx.utils import format_size

    package_size = result_path.stat().st_size
    console.console.print(
        f'Package was saved at {href(result_path)} ([item]{format_size(package_size)}[/item])'
    )
    return result_path
