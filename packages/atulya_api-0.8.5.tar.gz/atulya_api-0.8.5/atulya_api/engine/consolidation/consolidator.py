"""Consolidation engine for automatic observation creation from memories.

The consolidation engine runs as a background job after retain operations complete.
It processes new memories and either:
- Creates new observations from novel facts
- Updates existing observations when new evidence supports/contradicts/refines them

Observations are stored in memory_units with fact_type='observation' and include:
- proof_count: Number of supporting memories
- source_memory_ids: Array of memory UUIDs that contribute to this observation
- history: JSONB tracking changes over time

NOTE: Observations are distinct from mental models (pinned reflections).
- Observations: auto-generated bottom-up by this engine from raw facts (memory_units table, fact_type='observation')
- Mental models: user-defined queries stored in the mental_models table, refreshed on demand via reflect
"""

import json
import logging
import math
import time
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from itertools import combinations
from typing import TYPE_CHECKING, Any

from pydantic import BaseModel, field_validator

from ...config import get_config
from ..embedding_similarity import cosine_similarity, parse_embedding_text
from ..llm_wrapper import sanitize_llm_output
from ..memory_engine import fq_table
from ..retain import embedding_utils
from ..temporal import classify_fact_temporal_metadata
from .prompts import build_batch_consolidation_prompt

if TYPE_CHECKING:
    from asyncpg import Connection

    from ...api.http import RequestContext
    from ..memory_engine import MemoryEngine
    from ..response_models import MemoryFact, RecallResult

logger = logging.getLogger(__name__)


async def _filter_live_source_memories(
    conn: "Connection",
    bank_id: str,
    source_memory_ids: list[uuid.UUID],
) -> list[uuid.UUID]:
    """Return only the source memory ids that still exist in the bank.

    Uses ``SELECT ... FOR SHARE`` to block concurrent deletes from removing a
    row between this check and the subsequent insert/update. Combined with the
    delete paths in ``MemoryEngine`` running their stale-observation sweep
    *after* deleting the source row, this closes the race window where
    consolidation would otherwise commit an observation referencing a memory
    that was hard-deleted during the (multi-second) LLM call.

    ``source_memory_ids`` is a ``uuid[]`` column on ``memory_units``, so
    Postgres cannot FK-cascade through it; this manual liveness check is the
    invariant that prevents orphan observations.
    """
    if not source_memory_ids:
        return []
    rows = await conn.fetch(
        f"""
        SELECT id
        FROM {fq_table("memory_units")}
        WHERE id = ANY($1::uuid[]) AND bank_id = $2
        FOR SHARE
        """,
        source_memory_ids,
        bank_id,
    )
    live = {row["id"] for row in rows}
    return [mid for mid in source_memory_ids if mid in live]


class _CreateAction(BaseModel):
    text: str
    source_fact_ids: list[str]  # memory UUIDs from the NEW FACTS list

    @field_validator("text", mode="before")
    @classmethod
    def sanitize_text(cls, v: str) -> str:
        return sanitize_llm_output(v) or ""


class _UpdateAction(BaseModel):
    text: str
    observation_id: str  # UUID of the existing observation to update
    source_fact_ids: list[str]  # memory UUIDs from the NEW FACTS list

    @field_validator("text", mode="before")
    @classmethod
    def sanitize_text(cls, v: str) -> str:
        return sanitize_llm_output(v) or ""


class _DeleteAction(BaseModel):
    observation_id: str  # UUID of the observation to remove


class _ConsolidationBatchResponse(BaseModel):
    creates: list[_CreateAction] = []
    updates: list[_UpdateAction] = []
    deletes: list[_DeleteAction] = []


def _build_response_model(max_creates: int | None) -> type[BaseModel]:
    """Return a Pydantic response model for the consolidation LLM call.

    When ``max_creates`` is None, the unconstrained
    :class:`_ConsolidationBatchResponse` is returned. When it is an integer
    (including ``0``), a fresh subclass is built whose ``creates`` field is
    capped via ``Field(max_length=max_creates)`` so that JSON-schema-aware LLM
    drivers refuse to emit more than the remaining slots — fully enforcing the
    bank-level ``max_observations_per_scope`` cap.
    """
    if max_creates is None:
        return _ConsolidationBatchResponse

    from pydantic import Field, create_model

    capped_create_field = (list[_CreateAction], Field(default_factory=list, max_length=max_creates))
    return create_model(
        f"_ConsolidationBatchResponseCap{max_creates}",
        __base__=_ConsolidationBatchResponse,
        creates=capped_create_field,
    )


def _parse_observation_scopes(raw: Any, bank_id: str | None = None) -> Any:
    """Decode the JSONB ``observation_scopes`` column from an asyncpg row.

    asyncpg returns JSONB columns as raw JSON strings — unless the column was
    inserted as a Python string (legacy data, manual ``\\copy``, etc.) in
    which case it may be malformed. A malformed value MUST NOT crash the
    consolidation job: we log and fall back to ``None`` (single combined
    pass), matching pre-cap behaviour.

    Returns the parsed value (``"per_tag"`` / ``"combined"`` / ``"all_combinations"``
    / ``list[list[str]]`` / ``None``) or ``None`` on parse failure.
    """
    if not isinstance(raw, str):
        return raw
    try:
        return json.loads(raw)
    except json.JSONDecodeError as exc:
        logger.warning(
            "[CONSOLIDATION] Failed to parse observation_scopes JSONB "
            f"({raw!r}) for bank {bank_id!r}: {exc}; "
            "falling back to single combined pass"
        )
        return None


async def _count_observations_for_scope(
    conn: "Connection",
    bank_id: str,
    scope_tags: list[str] | None,
) -> int:
    """Count current observations whose tag set matches the given scope.

    Untagged scopes (``scope_tags`` is ``None`` or empty) are treated as
    *exempt* from the cap and always return ``0`` so the cap never bites for
    untagged consolidation passes.

    For tagged scopes we count observations whose ``tags`` array exactly
    contains the same set of tags (order-insensitive) — that is the same
    grouping used by per-pass consolidation: every pass writes observations
    tagged with exactly ``scope_tags``.
    """
    if not scope_tags:
        return 0

    row = await conn.fetchrow(
        f"""
        SELECT COUNT(*) AS n
        FROM {fq_table("memory_units")}
        WHERE bank_id = $1
          AND fact_type = 'observation'
          AND tags @> $2::varchar[]
          AND $2::varchar[] @> tags
        """,
        bank_id,
        list(scope_tags),
    )
    return int(row["n"]) if row else 0


@dataclass
class _BatchLLMResult:
    creates: list[_CreateAction] = field(default_factory=list)
    updates: list[_UpdateAction] = field(default_factory=list)
    deletes: list[_DeleteAction] = field(default_factory=list)
    obs_count: int = 0
    prompt_chars: int = 0


@dataclass
class _SourceAggregation:
    """Fields inherited by an observation from its source memories."""

    event_date: datetime | None
    occurred_start: datetime | None
    occurred_end: datetime | None
    mentioned_at: datetime | None
    tags: list[str]


@dataclass
class _DuplicateTelemetry:
    cosine_candidates: int = 0
    ce_scored: int = 0
    ce_confirmed: int = 0


@dataclass
class _ProcessMemoryBatchResult:
    results: list[dict[str, Any]] = field(default_factory=list)
    deleted_count: int = 0
    duplicate_telemetry: _DuplicateTelemetry = field(default_factory=_DuplicateTelemetry)


def _aggregate_source_fields(source_mems: list[dict[str, Any]], tags: list[str] | None = None) -> _SourceAggregation:
    """Compute the observation fields inherited from a set of source memories.

    Temporal aggregation rules:
    - ``event_date``    — earliest across sources (min)
    - ``occurred_start`` — earliest across sources (min)
    - ``occurred_end``   — latest across sources (max)
    - ``mentioned_at``   — latest across sources (max)

    Fields remain ``None`` when no source memory carries that information, so
    observations are never stamped with an artificial timestamp.

    ``tags`` defaults to those of the first source memory when not explicitly
    provided (all memories in a consolidation batch share the same tag set).
    """
    effective_tags = tags if tags is not None else (source_mems[0].get("tags") or [] if source_mems else [])
    return _SourceAggregation(
        event_date=_min_date(m.get("event_date") for m in source_mems),
        occurred_start=_min_date(m.get("occurred_start") for m in source_mems),
        occurred_end=_max_date(m.get("occurred_end") for m in source_mems),
        mentioned_at=_max_date(m.get("mentioned_at") for m in source_mems),
        tags=effective_tags,
    )


class ConsolidationPerfLog:
    """Performance logging for consolidation operations."""

    def __init__(self, bank_id: str):
        self.bank_id = bank_id
        self.start_time = time.time()
        self.lines: list[str] = []
        self.timings: dict[str, float] = {}
        self.llm_calls: int = 0
        self.total_obs_in_context: int = 0
        self.total_prompt_chars: int = 0

    def log(self, message: str) -> None:
        """Add a log line."""
        self.lines.append(message)

    def record_timing(self, key: str, duration: float) -> None:
        """Record a timing measurement."""
        if key in self.timings:
            self.timings[key] += duration
        else:
            self.timings[key] = duration

    def record_llm_call(self, obs_count: int, prompt_chars: int) -> None:
        """Record stats for a single LLM call."""
        self.llm_calls += 1
        self.total_obs_in_context += obs_count
        self.total_prompt_chars += prompt_chars

    def flush(self) -> None:
        """Flush all log lines to the logger."""
        total_time = time.time() - self.start_time
        header = f"\n{'=' * 60}\nCONSOLIDATION for bank {self.bank_id}"
        footer = f"{'=' * 60}\nCONSOLIDATION COMPLETE: {total_time:.3f}s total\n{'=' * 60}"

        log_output = header + "\n" + "\n".join(self.lines) + "\n" + footer
        logger.info(log_output)


async def run_consolidation_job(
    memory_engine: "MemoryEngine",
    bank_id: str,
    request_context: "RequestContext",
) -> dict[str, Any]:
    """
    Run consolidation job for a bank.

    This is called after retain operations to consolidate new memories into mental models.

    Args:
        memory_engine: MemoryEngine instance
        bank_id: Bank identifier
        request_context: Request context for authentication

    Returns:
        Dict with consolidation results
    """
    # Resolve bank-specific config with hierarchical overrides
    config = await memory_engine._config_resolver.resolve_full_config(bank_id, request_context)

    # Build a configured LLM wrapper that applies per-bank settings (e.g. safety settings)
    # to every call without leaking across operations.
    llm_config = memory_engine._consolidation_llm_config.with_config(config)

    perf = ConsolidationPerfLog(bank_id)
    max_memories_per_batch = config.consolidation_batch_size
    llm_batch_size = max(1, config.consolidation_llm_batch_size)

    # Check if consolidation is enabled
    if not config.enable_observations:
        logger.debug(f"Consolidation disabled for bank {bank_id}")
        return {"status": "disabled", "bank_id": bank_id}

    pool = memory_engine._pool

    # Get bank profile
    async with pool.acquire() as conn:
        t0 = time.time()
        bank_row = await conn.fetchrow(
            f"""
            SELECT bank_id, name
            FROM {fq_table("banks")}
            WHERE bank_id = $1
            """,
            bank_id,
        )

        if not bank_row:
            logger.warning(f"Bank {bank_id} not found for consolidation")
            return {"status": "bank_not_found", "bank_id": bank_id}

        perf.record_timing("fetch_bank", time.time() - t0)

        # Count total unconsolidated memories for progress logging
        total_count = await conn.fetchval(
            f"""
            SELECT COUNT(*)
            FROM {fq_table("memory_units")}
            WHERE bank_id = $1
              AND consolidated_at IS NULL
              AND fact_type IN ('experience', 'world')
            """,
            bank_id,
        )

    if total_count == 0:
        logger.debug(f"No new memories to consolidate for bank {bank_id}")
        return {"status": "no_new_memories", "bank_id": bank_id, "memories_processed": 0}

    logger.info(f"[CONSOLIDATION] bank={bank_id} total_unconsolidated={total_count}")
    perf.log(f"[1] Found {total_count} pending memories to consolidate")

    # Process each memory with individual commits for crash recovery
    stats: dict[str, int] = {
        "memories_processed": 0,
        "observations_created": 0,
        "observations_updated": 0,
        "observations_merged": 0,
        "observations_deleted": 0,
        "actions_executed": 0,
        "skipped": 0,
        "duplicate_cosine_candidates": 0,
        "duplicate_ce_scored": 0,
        "duplicate_ce_confirmed": 0,
    }

    # Track all unique tags from consolidated memories for mental model refresh filtering
    consolidated_tags: set[str] = set()

    llm_batch_num = 0
    while True:
        # Fetch next batch of unconsolidated memories
        async with pool.acquire() as conn:
            t0 = time.time()
            memories = await conn.fetch(
                f"""
                SELECT id, text, fact_type, occurred_start, occurred_end, event_date, tags, mentioned_at,
                       observation_scopes, embedding::text AS embedding_text
                FROM {fq_table("memory_units")}
                WHERE bank_id = $1
                  AND consolidated_at IS NULL
                  AND fact_type IN ('experience', 'world')
                ORDER BY created_at ASC
                LIMIT $2
                """,
                bank_id,
                max_memories_per_batch,
            )
            perf.record_timing("fetch_memories", time.time() - t0)

        if not memories:
            break  # No more unconsolidated memories

        # Group memories by exact tag set before batching — security requirement:
        # memories with different tags must never share an LLM call.
        tag_groups: dict[tuple[str, ...], list[dict[str, Any]]] = {}
        for m in memories:
            tag_key = tuple(sorted(m.get("tags") or []))
            tag_groups.setdefault(tag_key, []).append(dict(m))

        # Flatten into LLM batches respecting both tag groups and llm_batch_size
        llm_batches: list[list[dict[str, Any]]] = []
        for group in tag_groups.values():
            for i in range(0, len(group), llm_batch_size):
                llm_batches.append(group[i : i + llm_batch_size])

        for llm_batch in llm_batches:
            llm_batch_num += 1
            llm_batch_start = time.time()

            # Snapshot perf and stats before this LLM batch
            snap_timings = perf.timings.copy()
            snap_llm_calls = perf.llm_calls
            snap_total_chars = perf.total_prompt_chars
            snap_stats = stats.copy()

            # Track tags for mental model refresh filtering
            for memory in llm_batch:
                memory_tags = memory.get("tags") or []
                if memory_tags:
                    consolidated_tags.update(memory_tags)

            async with pool.acquire() as conn:
                # Determine observation_scopes for this batch. All memories in a batch share
                # the same tags (enforced by tag_groups), so we only check the first memory.
                # ``_parse_observation_scopes`` decodes the JSONB column safely — a
                # malformed value falls back to ``None`` (single combined pass).
                _obs_raw = llm_batch[0].get("observation_scopes") if llm_batch else None
                _obs_parsed = _parse_observation_scopes(_obs_raw, bank_id=bank_id)

                # Resolve the scope spec into a concrete list[list[str]] (or None for combined).
                if _obs_parsed == "per_tag":
                    _memory_tags = llm_batch[0].get("tags") or []
                    obs_tags_list = [[tag] for tag in _memory_tags] if _memory_tags else None
                elif _obs_parsed == "all_combinations":
                    _memory_tags = llm_batch[0].get("tags") or []
                    obs_tags_list = (
                        [
                            list(combo)
                            for r in range(1, len(_memory_tags) + 1)
                            for combo in combinations(_memory_tags, r)
                        ]
                        if _memory_tags
                        else None
                    )
                elif _obs_parsed == "combined" or _obs_parsed is None:
                    obs_tags_list = None  # single combined pass (default behaviour)
                else:
                    # explicit list[list[str]]
                    obs_tags_list = _obs_parsed

                batch_deleted: int = 0
                batch_duplicate_telemetry = _DuplicateTelemetry()
                if obs_tags_list:
                    # Multi-pass: run one observation consolidation pass per tag set
                    results = []
                    for obs_tags in obs_tags_list:
                        pass_result = await _process_memory_batch(
                            conn=conn,
                            memory_engine=memory_engine,
                            llm_config=llm_config,
                            bank_id=bank_id,
                            memories=llm_batch,
                            request_context=request_context,
                            perf=perf,
                            config=config,
                            obs_tags_override=obs_tags,
                        )
                        batch_deleted += pass_result.deleted_count
                        batch_duplicate_telemetry.cosine_candidates += pass_result.duplicate_telemetry.cosine_candidates
                        batch_duplicate_telemetry.ce_scored += pass_result.duplicate_telemetry.ce_scored
                        batch_duplicate_telemetry.ce_confirmed += pass_result.duplicate_telemetry.ce_confirmed
                        # Merge results: prefer non-skipped actions
                        if not results:
                            results = pass_result.results
                        else:
                            for i, (existing, new) in enumerate(zip(results, pass_result.results)):
                                if existing.get("action") == "skipped" and new.get("action") != "skipped":
                                    results[i] = new
                                elif existing.get("action") != "skipped" and new.get("action") != "skipped":
                                    # Both did something — combine into "multiple"
                                    existing_created = existing.get(
                                        "created", 1 if existing.get("action") == "created" else 0
                                    )
                                    existing_updated = existing.get(
                                        "updated", 1 if existing.get("action") == "updated" else 0
                                    )
                                    new_created = new.get("created", 1 if new.get("action") == "created" else 0)
                                    new_updated = new.get("updated", 1 if new.get("action") == "updated" else 0)
                                    total = existing_created + existing_updated + new_created + new_updated
                                    results[i] = {
                                        "action": "multiple",
                                        "created": existing_created + new_created,
                                        "updated": existing_updated + new_updated,
                                        "merged": 0,
                                        "total_actions": total,
                                    }
                else:
                    # Normal single pass using the memory's own tags
                    batch_result = await _process_memory_batch(
                        conn=conn,
                        memory_engine=memory_engine,
                        llm_config=llm_config,
                        bank_id=bank_id,
                        memories=llm_batch,
                        request_context=request_context,
                        perf=perf,
                        config=config,
                    )
                    results = batch_result.results
                    batch_deleted = batch_result.deleted_count
                    batch_duplicate_telemetry = batch_result.duplicate_telemetry
                stats["observations_deleted"] += batch_deleted
                stats["duplicate_cosine_candidates"] += batch_duplicate_telemetry.cosine_candidates
                stats["duplicate_ce_scored"] += batch_duplicate_telemetry.ce_scored
                stats["duplicate_ce_confirmed"] += batch_duplicate_telemetry.ce_confirmed

                await conn.executemany(
                    f"UPDATE {fq_table('memory_units')} SET consolidated_at = NOW() WHERE id = $1",
                    [(m["id"],) for m in llm_batch],
                )

            for result in results:
                stats["memories_processed"] += 1
                action = result.get("action")
                if action == "created":
                    stats["observations_created"] += 1
                    stats["actions_executed"] += 1
                elif action == "updated":
                    stats["observations_updated"] += 1
                    stats["actions_executed"] += 1
                elif action == "merged":
                    stats["observations_merged"] += 1
                    stats["actions_executed"] += 1
                elif action == "multiple":
                    stats["observations_created"] += result.get("created", 0)
                    stats["observations_updated"] += result.get("updated", 0)
                    stats["observations_merged"] += result.get("merged", 0)
                    stats["actions_executed"] += result.get("total_actions", 0)
                elif action == "skipped":
                    stats["skipped"] += 1

            # Per-LLM-batch log
            llm_batch_time = time.time() - llm_batch_start
            timing_parts = []
            for key in ["recall", "llm", "embedding", "db_write"]:
                if key in perf.timings:
                    delta = perf.timings[key] - snap_timings.get(key, 0)
                    timing_parts.append(f"{key}={delta:.3f}s")
            input_tokens = int((perf.total_prompt_chars - snap_total_chars) / 4)
            batch_created = stats["observations_created"] - snap_stats["observations_created"]
            batch_updated = stats["observations_updated"] - snap_stats["observations_updated"]
            batch_skipped = stats["skipped"] - snap_stats["skipped"]
            batch_duplicate_candidates = (
                stats["duplicate_cosine_candidates"] - snap_stats["duplicate_cosine_candidates"]
            )
            batch_duplicate_confirmed = stats["duplicate_ce_confirmed"] - snap_stats["duplicate_ce_confirmed"]
            llm_calls_made = perf.llm_calls - snap_llm_calls
            logger.info(
                f"[CONSOLIDATION] bank={bank_id} llm_batch #{llm_batch_num}"
                f" ({len(llm_batch)} memories, {llm_calls_made} llm calls)"
                f" | {stats['memories_processed']}/{total_count} processed"
                f" | {', '.join(timing_parts)}"
                f" | created={batch_created} updated={batch_updated} skipped={batch_skipped}"
                f" | dup_candidates={batch_duplicate_candidates} dup_confirmed={batch_duplicate_confirmed}"
                f" | input_tokens=~{input_tokens}"
                f" | avg={llm_batch_time / len(llm_batch):.3f}s/memory"
            )

    # Build summary
    perf.log(
        f"[3] Results: {stats['memories_processed']} memories -> "
        f"{stats['actions_executed']} actions "
        f"({stats['observations_created']} created, "
        f"{stats['observations_updated']} updated, "
        f"{stats['observations_merged']} merged, "
        f"{stats['skipped']} skipped)"
    )

    # Add timing breakdown
    timing_parts = []
    if "recall" in perf.timings:
        timing_parts.append(f"recall={perf.timings['recall']:.3f}s")
    if "llm" in perf.timings:
        timing_parts.append(f"llm={perf.timings['llm']:.3f}s")
    if "embedding" in perf.timings:
        timing_parts.append(f"embedding={perf.timings['embedding']:.3f}s")
    if "db_write" in perf.timings:
        timing_parts.append(f"db_write={perf.timings['db_write']:.3f}s")

    if perf.llm_calls > 0:
        timing_parts.append(f"avg_obs={perf.total_obs_in_context / perf.llm_calls:.1f}")
        timing_parts.append(f"avg_prompt_tokens=~{perf.total_prompt_chars / perf.llm_calls / 4:.0f}")

    if timing_parts:
        perf.log(f"[4] Timing breakdown: {', '.join(timing_parts)}")
    if stats["duplicate_cosine_candidates"] > 0:
        precision = (
            stats["duplicate_ce_confirmed"] / stats["duplicate_ce_scored"] if stats["duplicate_ce_scored"] > 0 else 0.0
        )
        perf.log(
            "[4b] Duplicate telemetry: "
            f"cosine_candidates={stats['duplicate_cosine_candidates']}, "
            f"ce_scored={stats['duplicate_ce_scored']}, "
            f"ce_confirmed={stats['duplicate_ce_confirmed']}, "
            f"precision={precision:.3f}"
        )

    # Trigger mental model refreshes for models with refresh_after_consolidation=true
    # SECURITY: Only refresh mental models with matching tags (or all if no tags were consolidated)
    mental_models_refreshed = await _trigger_mental_model_refreshes(
        memory_engine=memory_engine,
        bank_id=bank_id,
        request_context=request_context,
        consolidated_tags=list(consolidated_tags) if consolidated_tags else None,
        perf=perf,
    )
    stats["mental_models_refreshed"] = mental_models_refreshed

    perf.flush()

    return {"status": "completed", "bank_id": bank_id, **stats}


async def _trigger_mental_model_refreshes(
    memory_engine: "MemoryEngine",
    bank_id: str,
    request_context: "RequestContext",
    consolidated_tags: list[str] | None = None,
    perf: ConsolidationPerfLog | None = None,
) -> int:
    """
    Trigger refreshes for mental models with refresh_after_consolidation=true.

    SECURITY: Only triggers refresh for mental models whose tags overlap with the
    consolidated memory tags, preventing unnecessary refreshes across security boundaries.

    Args:
        memory_engine: MemoryEngine instance
        bank_id: Bank identifier
        request_context: Request context for authentication
        consolidated_tags: Tags from memories that were consolidated (None = refresh all)
        perf: Performance logging

    Returns:
        Number of mental models scheduled for refresh
    """
    pool = memory_engine._pool

    # Find mental models with refresh_after_consolidation=true
    # SECURITY: Control which mental models get refreshed based on tags
    async with pool.acquire() as conn:
        if consolidated_tags:
            # Tagged memories were consolidated - refresh:
            # 1. Mental models with overlapping tags (security boundary)
            # 2. Untagged mental models (they're "global" and available to all contexts)
            # DO NOT refresh mental models with different tags
            rows = await conn.fetch(
                f"""
                SELECT id, name, tags
                FROM {fq_table("mental_models")}
                WHERE bank_id = $1
                  AND (trigger->>'refresh_after_consolidation')::boolean = true
                  AND (
                    (tags IS NOT NULL AND tags != '{{}}' AND tags && $2::varchar[])
                    OR (tags IS NULL OR tags = '{{}}')
                  )
                """,
                bank_id,
                consolidated_tags,
            )
        else:
            # Untagged memories were consolidated - only refresh untagged mental models
            # SECURITY: Tagged mental models are NOT refreshed when untagged memories are consolidated
            rows = await conn.fetch(
                f"""
                SELECT id, name, tags
                FROM {fq_table("mental_models")}
                WHERE bank_id = $1
                  AND (trigger->>'refresh_after_consolidation')::boolean = true
                  AND (tags IS NULL OR tags = '{{}}')
                """,
                bank_id,
            )

    if not rows:
        return 0

    if perf:
        if consolidated_tags:
            perf.log(
                f"[5] Triggering refresh for {len(rows)} mental models with refresh_after_consolidation=true "
                f"(filtered by tags: {consolidated_tags})"
            )
        else:
            perf.log(f"[5] Triggering refresh for {len(rows)} mental models with refresh_after_consolidation=true")

    # Submit refresh tasks for each mental model
    refreshed_count = 0
    for row in rows:
        mental_model_id = row["id"]
        try:
            await memory_engine.submit_async_refresh_mental_model(
                bank_id=bank_id,
                mental_model_id=mental_model_id,
                request_context=request_context,
            )
            refreshed_count += 1
            logger.info(
                f"[CONSOLIDATION] Triggered refresh for mental model {mental_model_id} "
                f"(name: {row['name']}) in bank {bank_id}"
            )
        except Exception as e:
            logger.warning(f"[CONSOLIDATION] Failed to trigger refresh for mental model {mental_model_id}: {e}")

    return refreshed_count


async def _process_memory_batch(
    conn: "Connection",
    memory_engine: "MemoryEngine",
    llm_config: Any,
    bank_id: str,
    memories: list[dict[str, Any]],
    request_context: "RequestContext",
    perf: ConsolidationPerfLog | None = None,
    config: Any = None,
    obs_tags_override: list[str] | None = None,
) -> _ProcessMemoryBatchResult:
    """
    Process a batch of memories in a single LLM call.

    Steps:
    1. Parallel recalls — one per fact (read-only; safe to parallelise)
    2. Union of retrieved observations across the batch (deduped by id)
    3. Single LLM call with all N facts + unioned observations
    4. Sequential action execution (writes remain serial for consistency)
    5. Returns one result dict per memory, in the same order as `memories`

    Per-fact security: action execution validates each learning_id against the
    observations that were recalled specifically for that fact, so cross-tag
    updates cannot occur.

    Args:
        obs_tags_override: When set, use these tags for observation recall and
            create/update instead of the memory's own tags. This enables multi-pass
            consolidation where a single memory can contribute to observations
            scoped at different tag levels (e.g., user-level vs session-level).
    """
    import asyncio

    # 1. Parallel recalls — one per fact
    # When obs_tags_override is set, use it as the observation scope for all facts.
    t0 = time.time()
    observation_scope_tags = obs_tags_override if obs_tags_override is not None else None
    recall_tasks = [
        _find_related_observations(
            memory_engine=memory_engine,
            bank_id=bank_id,
            query=m["text"],
            request_context=request_context,
            tags=observation_scope_tags if observation_scope_tags is not None else (m.get("tags") or []),
        )
        for m in memories
    ]
    per_fact_recalls = await asyncio.gather(*recall_tasks)
    if perf:
        perf.record_timing("recall", time.time() - t0)

    # 2. Build per-fact observation sets (keyed by memory ID string) for secure action validation
    per_fact_obs_ids: dict[str, set[str]] = {
        str(memories[i]["id"]): {str(obs.id) for obs in r.results} for i, r in enumerate(per_fact_recalls)
    }

    # Union all observations (deduped by id)
    seen_ids: set[str] = set()
    union_observations: list["MemoryFact"] = []
    union_source_facts: dict[str, "MemoryFact"] = {}
    for recall_result in per_fact_recalls:
        for obs in recall_result.results:
            obs_id = str(obs.id)
            if obs_id not in seen_ids:
                seen_ids.add(obs_id)
                union_observations.append(obs)
        if recall_result.source_facts:
            union_source_facts.update(recall_result.source_facts)

    duplicate_telemetry = await _collect_duplicate_telemetry(
        conn=conn,
        memory_engine=memory_engine,
        bank_id=bank_id,
        memories=memories,
        observations=union_observations,
        config=config,
    )

    # Compute the effective scope tags up-front so we can both enforce the
    # max_observations_per_scope cap during the LLM call AND tag any new
    # creations with the same scope further down (delete → update → create).
    if obs_tags_override is not None:
        scope_tags: list[str] = obs_tags_override
    else:
        scope_tags = (memories[0].get("tags") or []) if memories else []

    # Resolve the per-scope observation cap. None → unlimited. Untagged
    # scopes are exempt from the cap (helper returns 0 / cap is ignored).
    max_per_scope = getattr(config, "max_observations_per_scope", None) if config is not None else None
    remaining_slots: int | None
    if max_per_scope is None or not scope_tags:
        remaining_slots = None
    else:
        current_count = await _count_observations_for_scope(
            conn=conn,
            bank_id=bank_id,
            scope_tags=scope_tags,
        )
        remaining_slots = max(0, max_per_scope - current_count)

    # 3. Single LLM call
    t0 = time.time()
    llm_result = await _consolidate_batch_with_llm(
        llm_config=llm_config,
        memories=memories,
        union_observations=union_observations,
        union_source_facts=union_source_facts,
        config=config,
        remaining_slots=remaining_slots,
    )
    if perf:
        perf.record_timing("llm", time.time() - t0)
        perf.record_llm_call(llm_result.obs_count, llm_result.prompt_chars)

    # 4. Sequential execution of deletes → updates → creates.
    # Order matters when ``max_observations_per_scope`` is enforced: deletes
    # free up slots and updates do not consume any, so processing them first
    # gives the LLM-suggested creates the maximum chance to land within cap.
    # Untagged scopes are exempt from the cap so the ordering also keeps
    # legacy behaviour stable.
    per_memory_created: set[str] = set()
    per_memory_updated: set[str] = set()

    # All memories in the batch share the same tag set (enforced by batching);
    # ``scope_tags`` was already resolved above to honour ``obs_tags_override``.
    fact_tags = scope_tags

    mem_by_id = {str(m["id"]): m for m in memories}

    deleted_count = 0
    for delete in llm_result.deletes:
        # Security: the observation must be present in the unioned recall
        if not any(str(obs.id) == delete.observation_id for obs in union_observations):
            logger.debug(
                f"Batch consolidation: rejected delete — observation {delete.observation_id} not in unioned recall"
            )
            continue
        await _execute_delete_action(conn=conn, bank_id=bank_id, observation_id=delete.observation_id)
        deleted_count += 1

    for update in llm_result.updates:
        source_mems = [mem_by_id[fid] for fid in update.source_fact_ids if fid in mem_by_id]
        if not source_mems:
            continue
        # Security: the observation must have been recalled for at least one of the source facts
        if not any(update.observation_id in per_fact_obs_ids.get(str(m["id"]), set()) for m in source_mems):
            logger.debug(
                f"Batch consolidation: rejected update — observation {update.observation_id} "
                f"not in any source fact's recall"
            )
            continue
        agg = _aggregate_source_fields(source_mems, tags=fact_tags)
        await _execute_update_action(
            conn=conn,
            memory_engine=memory_engine,
            bank_id=bank_id,
            source_memory_ids=[m["id"] for m in source_mems],
            observation_id=update.observation_id,
            new_text=update.text,
            observations=union_observations,
            source_fact_tags=agg.tags,
            source_occurred_start=agg.occurred_start,
            source_occurred_end=agg.occurred_end,
            source_mentioned_at=agg.mentioned_at,
            perf=perf,
        )
        for m in source_mems:
            per_memory_updated.add(str(m["id"]))

    # Final defensive cap: even if the LLM ignores the constrained schema and
    # over-emits creates, never exceed the per-scope cap. Recompute the slot
    # budget after deletes so freed capacity is honoured. Untagged scopes
    # remain uncapped (``remaining_slots`` is None).
    if max_per_scope is not None and scope_tags:
        post_delete_count = await _count_observations_for_scope(
            conn=conn,
            bank_id=bank_id,
            scope_tags=scope_tags,
        )
        creates_budget: int | None = max(0, max_per_scope - post_delete_count)
    else:
        creates_budget = None

    creates_processed = 0
    for create in llm_result.creates:
        if creates_budget is not None and creates_processed >= creates_budget:
            logger.debug(
                f"Batch consolidation: dropped create — scope {scope_tags!r} at "
                f"max_observations_per_scope={max_per_scope}"
            )
            continue
        source_mems = [mem_by_id[fid] for fid in create.source_fact_ids if fid in mem_by_id]
        if not source_mems:
            continue
        agg = _aggregate_source_fields(source_mems, tags=fact_tags)
        await _execute_create_action(
            conn=conn,
            memory_engine=memory_engine,
            bank_id=bank_id,
            source_memory_ids=[m["id"] for m in source_mems],
            text=create.text,
            source_fact_tags=agg.tags,
            event_date=agg.event_date,
            occurred_start=agg.occurred_start,
            occurred_end=agg.occurred_end,
            mentioned_at=agg.mentioned_at,
            perf=perf,
        )
        creates_processed += 1
        for m in source_mems:
            per_memory_created.add(str(m["id"]))

    # Build per-memory result dicts for the stats tracker in the outer loop
    results: list[dict[str, Any]] = []
    for m in memories:
        mid = str(m["id"])
        created = mid in per_memory_created
        updated = mid in per_memory_updated
        if created and updated:
            results.append({"action": "multiple", "created": 1, "updated": 1, "merged": 0, "total_actions": 2})
        elif created:
            results.append({"action": "created"})
        elif updated:
            results.append({"action": "updated"})
        else:
            results.append({"action": "skipped", "reason": "no_durable_knowledge"})

    return _ProcessMemoryBatchResult(
        results=results,
        deleted_count=deleted_count,
        duplicate_telemetry=duplicate_telemetry,
    )


async def _collect_duplicate_telemetry(
    conn: "Connection",
    memory_engine: "MemoryEngine",
    bank_id: str,
    memories: list[dict[str, Any]],
    observations: list["MemoryFact"],
    config: Any,
) -> _DuplicateTelemetry:
    if not config or not config.consolidation_duplicate_detection_enabled or not observations:
        return _DuplicateTelemetry()

    observation_embeddings = await _load_observation_embedding_map(
        conn=conn,
        bank_id=bank_id,
        observation_ids=[str(observation.id) for observation in observations],
    )

    candidate_pairs: list[tuple[dict[str, Any], "MemoryFact"]] = []
    for memory in memories:
        memory_embedding = parse_embedding_text(memory.get("embedding_text"))
        if memory_embedding is None:
            continue
        for observation in observations:
            observation_embedding = observation_embeddings.get(str(observation.id))
            similarity = cosine_similarity(memory_embedding, observation_embedding)
            if similarity is None or similarity < config.consolidation_duplicate_cosine_threshold:
                continue
            candidate_pairs.append((memory, observation))

    telemetry = _DuplicateTelemetry(cosine_candidates=len(candidate_pairs))
    if not config.consolidation_duplicate_ce_enabled or not candidate_pairs:
        return telemetry

    reranker = memory_engine._cross_encoder_reranker
    try:
        await reranker.ensure_initialized()
        scores = await reranker.cross_encoder.predict(
            [
                (_duplicate_memory_text(memory), _duplicate_observation_text(observation))
                for memory, observation in candidate_pairs
            ]
        )
    except Exception as exc:
        logger.warning(f"[CONSOLIDATION] Duplicate CE telemetry skipped after reranker failure: {exc}")
        return telemetry

    telemetry.ce_scored = len(scores)
    telemetry.ce_confirmed = sum(
        1 for score in scores if _sigmoid(score) >= config.consolidation_duplicate_ce_threshold
    )
    return telemetry


async def _load_observation_embedding_map(
    conn: "Connection",
    bank_id: str,
    observation_ids: list[str],
) -> dict[str, list[float]]:
    if not observation_ids:
        return {}

    observation_uuids = [uuid.UUID(observation_id) for observation_id in observation_ids]

    rows = await conn.fetch(
        f"""
        SELECT id, embedding::text AS embedding_text
        FROM {fq_table("memory_units")}
        WHERE bank_id = $1
          AND fact_type = 'observation'
          AND id = ANY($2::uuid[])
        """,
        bank_id,
        observation_uuids,
    )
    return {
        str(row["id"]): embedding
        for row in rows
        if (embedding := parse_embedding_text(row["embedding_text"])) is not None
    }


def _duplicate_memory_text(memory: dict[str, Any]) -> str:
    return memory["text"]


def _duplicate_observation_text(observation: "MemoryFact") -> str:
    if observation.context:
        return f"{observation.context}: {observation.text}"
    return observation.text


def _sigmoid(value: float) -> float:
    return 1.0 / (1.0 + math.exp(-value))


def _min_date(dates: "Any") -> "datetime | None":
    """Return the minimum non-None datetime from an iterable."""
    return min((d for d in dates if d is not None), default=None)


def _max_date(dates: "Any") -> "datetime | None":
    """Return the maximum non-None datetime from an iterable."""
    return max((d for d in dates if d is not None), default=None)


async def _execute_update_action(
    conn: "Connection",
    memory_engine: "MemoryEngine",
    bank_id: str,
    source_memory_ids: list[uuid.UUID],
    observation_id: str,
    new_text: str,
    observations: list["MemoryFact"],
    source_fact_tags: list[str] | None = None,
    source_occurred_start: datetime | None = None,
    source_occurred_end: datetime | None = None,
    source_mentioned_at: datetime | None = None,
    perf: ConsolidationPerfLog | None = None,
) -> None:
    """
    Update an existing observation.

    Extends source_memory_ids with all contributing memories, updates temporal fields
    (LEAST for occurred_start, GREATEST for occurred_end / mentioned_at), and merges tags.
    """
    model = next((m for m in observations if str(m.id) == observation_id), None)
    if not model:
        logger.debug(f"Update skipped: observation {observation_id} not found in recall results")
        return

    live_source_memory_ids = await _filter_live_source_memories(conn, bank_id, source_memory_ids)
    if not live_source_memory_ids:
        logger.info(
            f"consolidation: skipped update for obs={observation_id} bank={bank_id}, "
            f"all {len(source_memory_ids)} source memories were deleted concurrently"
        )
        return
    source_memory_ids = live_source_memory_ids

    from ...config import get_config

    history_entry = {
        "previous_text": model.text,
        "previous_tags": list(model.tags or []),
        "previous_occurred_start": model.occurred_start,
        "previous_occurred_end": model.occurred_end,
        "previous_mentioned_at": model.mentioned_at,
        "changed_at": datetime.now(timezone.utc).isoformat(),
        "new_source_memory_ids": [str(mid) for mid in source_memory_ids],
    }

    source_ids = list(model.source_fact_ids or []) + source_memory_ids

    # SECURITY: Merge source fact's tags into existing observation tags so all contributors can see it
    existing_tags = set(model.tags or [])
    source_tags = set(source_fact_tags or [])
    merged_tags = list(existing_tags | source_tags)

    t0 = time.time()
    embeddings = await embedding_utils.generate_embeddings_batch(memory_engine.embeddings, [new_text])
    embedding_str = str(embeddings[0]) if embeddings else None
    if perf:
        perf.record_timing("embedding", time.time() - t0)

    config = get_config()
    if config.timeline_v2:
        temporal = classify_fact_temporal_metadata(
            fact_text=new_text,
            occurred_start=source_occurred_start,
            mentioned_at=source_mentioned_at,
            explicit_temporal=source_occurred_start is not None,
            fact_kind="event" if source_occurred_start is not None else "conversation",
        )
    else:
        temporal = None
    history_clause = (
        "history = COALESCE(history, '[]'::jsonb) || $3::jsonb," if config.enable_observation_history else ""
    )

    t0 = time.time()
    await conn.execute(
        f"""
        UPDATE {fq_table("memory_units")}
        SET text = $1,
            embedding = $2::vector,
            {history_clause}
            source_memory_ids = $4,
            proof_count = $5,
            tags = $10,
            updated_at = now(),
            occurred_start = LEAST(occurred_start, COALESCE($7, occurred_start)),
            occurred_end = GREATEST(occurred_end, COALESCE($8, occurred_end)),
            mentioned_at = GREATEST(mentioned_at, COALESCE($9, mentioned_at)),
            timeline_anchor_at = COALESCE($11, timeline_anchor_at),
            timeline_anchor_kind = $12,
            temporal_direction = $13,
            temporal_confidence = $14,
            temporal_reference_text = $15
        WHERE id = $6
        """,
        new_text,
        embedding_str,
        json.dumps([history_entry]),
        source_ids,
        len(source_ids),
        uuid.UUID(observation_id),
        source_occurred_start,
        source_occurred_end,
        source_mentioned_at,
        merged_tags,
        temporal.anchor_at if temporal else None,
        temporal.anchor_kind if temporal else "recorded_only",
        temporal.direction if temporal else "atemporal",
        temporal.confidence if temporal else None,
        temporal.reference_text if temporal else None,
    )
    if perf:
        perf.record_timing("db_write", time.time() - t0)

    logger.debug(f"Updated observation {observation_id} from {len(source_memory_ids)} source memories")


async def _execute_create_action(
    conn: "Connection",
    memory_engine: "MemoryEngine",
    bank_id: str,
    source_memory_ids: list[uuid.UUID],
    text: str,
    source_fact_tags: list[str] | None = None,
    event_date: datetime | None = None,
    occurred_start: datetime | None = None,
    occurred_end: datetime | None = None,
    mentioned_at: datetime | None = None,
    perf: ConsolidationPerfLog | None = None,
) -> None:
    """
    Create a new observation from one or more source memories.

    Tags are inherited from the source facts (determined algorithmically, not by LLM)
    to maintain visibility scope.
    """
    await _create_observation_directly(
        conn=conn,
        memory_engine=memory_engine,
        bank_id=bank_id,
        source_memory_ids=source_memory_ids,
        observation_text=text,
        tags=source_fact_tags or [],
        event_date=event_date,
        occurred_start=occurred_start,
        occurred_end=occurred_end,
        mentioned_at=mentioned_at,
        perf=perf,
    )
    logger.debug(f"Created observation from {len(source_memory_ids)} source memories")


async def _execute_delete_action(
    conn: "Connection",
    bank_id: str,
    observation_id: str,
) -> None:
    """Delete a superseded or contradicted observation."""
    await conn.execute(
        f"DELETE FROM {fq_table('memory_units')} WHERE id = $1 AND bank_id = $2 AND fact_type = 'observation'",
        uuid.UUID(observation_id),
        bank_id,
    )
    logger.debug(f"Deleted observation {observation_id}")


async def _create_memory_links(
    conn: "Connection",
    memory_id: uuid.UUID,
    observation_id: uuid.UUID,
) -> None:
    """
    Placeholder for observation link creation.

    Observations do NOT get any memory_links copied from their source facts.
    Instead, retrieval uses source_memory_ids to traverse:
    - Entity connections: observation → source_memory_ids → unit_entities
    - Semantic similarity: observations have their own embeddings
    - Temporal proximity: observations have their own temporal fields

    This avoids data duplication and ensures observations are always
    connected via their source facts' relationships.

    The memory_id and observation_id parameters are kept for interface
    compatibility but no links are created.
    """
    # No links are created - observations rely on source_memory_ids for traversal
    pass


async def _find_related_observations(
    memory_engine: "MemoryEngine",
    bank_id: str,
    query: str,
    request_context: "RequestContext",
    tags: list[str] | None = None,
) -> "RecallResult":
    """
    Find observations related to the given query using optimized recall.

    SECURITY: Filters by tags using all_strict matching to prevent cross-tenant/cross-user
    information leakage. Observations are only consolidated within the same tag scope.

    Uses max_tokens to naturally limit observations (no artificial count limit).
    Includes source memories with dates for LLM context.

    Args:
        tags: Optional tags to filter observations (uses all_strict matching for security)

    Returns:
        List of related observations with their tags, source memories, and dates
    """
    # Use recall to find related observations with token budget
    # max_tokens naturally limits how many observations are returned
    from ...tracing import get_tracer, is_tracing_enabled

    config = await memory_engine._config_resolver.resolve_full_config(bank_id, request_context)

    # SECURITY: Use all_strict matching if tags provided to prevent cross-scope consolidation
    tags_match = "all_strict" if tags else "any"

    # Create span for recall operation within consolidation
    tracer = get_tracer()
    if is_tracing_enabled():
        recall_span = tracer.start_span("atulya.consolidation_recall")
        recall_span.set_attribute("atulya.bank_id", bank_id)
        recall_span.set_attribute("atulya.query", query[:100])  # Truncate for brevity
        recall_span.set_attribute("atulya.fact_type", "observation")
    else:
        recall_span = None

    try:
        recall_result = await memory_engine.recall_async(
            bank_id=bank_id,
            query=query,
            max_tokens=config.consolidation_max_tokens,  # Token budget for observations (configurable)
            fact_type=["observation"],  # Only retrieve observations
            request_context=request_context,
            tags=tags,  # Filter by source memory's tags
            tags_match=tags_match,  # Use strict matching for security
            include_source_facts=True,  # Embed source facts so we avoid a separate DB fetch
            max_source_facts_tokens=config.consolidation_source_facts_max_tokens,
            max_source_facts_tokens_per_observation=config.consolidation_source_facts_max_tokens_per_observation,
            _quiet=True,  # Suppress logging
        )
    finally:
        if recall_span:
            recall_span.end()

    return recall_result


def _build_observations_for_llm(
    observations: "list[MemoryFact]",
    source_facts: "dict[str, MemoryFact]",
) -> list[dict[str, Any]]:
    """Serialize MemoryFact observations into dicts for the consolidation LLM prompt."""
    obs_list = []
    for obs in observations:
        obs_data: dict[str, Any] = {
            "id": obs.id,
            "text": obs.text,
            "proof_count": len(obs.source_fact_ids or []) or 1,
        }
        if obs.occurred_start:
            obs_data["occurred_start"] = obs.occurred_start
        if obs.occurred_end:
            obs_data["occurred_end"] = obs.occurred_end
        if obs.mentioned_at:
            obs_data["mentioned_at"] = obs.mentioned_at
        source_memories = []
        for sid in obs.source_fact_ids or []:
            sf = source_facts.get(sid)
            if sf is None:
                continue
            sf_data: dict[str, Any] = {"text": sf.text}
            if sf.context:
                sf_data["context"] = sf.context
            if sf.occurred_start:
                sf_data["occurred_start"] = sf.occurred_start
            if sf.occurred_end:
                sf_data["occurred_end"] = sf.occurred_end
            if sf.mentioned_at:
                sf_data["mentioned_at"] = sf.mentioned_at
            source_memories.append(sf_data)
        if source_memories:
            obs_data["source_memories"] = source_memories
        obs_list.append(obs_data)
    return obs_list


async def _consolidate_batch_with_llm(
    llm_config: Any,
    memories: list[dict[str, Any]],
    union_observations: "list[MemoryFact]",
    union_source_facts: "dict[str, MemoryFact]",
    config: Any = None,
    remaining_slots: int | None = None,
) -> _BatchLLMResult:
    """Single LLM call for a batch of facts against a pooled set of observations.

    Args:
        remaining_slots: When set, caps how many ``creates`` the LLM is allowed
            to emit. ``0`` means the bank-level
            ``max_observations_per_scope`` cap has been hit for this scope and
            the constrained response model will reject any new creations.
            ``None`` disables the cap entirely.
    """
    if union_observations:
        obs_list = _build_observations_for_llm(union_observations, union_source_facts)
        observations_text = json.dumps(obs_list, indent=2)
    else:
        observations_text = "[]"

    def _fact_line(m: dict[str, Any]) -> str:
        text = f"[{m['id']}] {m['text']}"
        temporal_parts = []
        if m.get("occurred_start"):
            temporal_parts.append(f"occurred_start={m['occurred_start']}")
        if m.get("occurred_end"):
            temporal_parts.append(f"occurred_end={m['occurred_end']}")
        if m.get("mentioned_at"):
            temporal_parts.append(f"mentioned_at={m['mentioned_at']}")
        if temporal_parts:
            text += f" ({', '.join(temporal_parts)})"
        return text

    facts_lines = "\n".join(_fact_line(m) for m in memories)

    observations_mission = config.observations_mission if config is not None else None
    if remaining_slots is None:
        capacity_note: str | None = None
    elif remaining_slots == 0:
        capacity_note = (
            "This scope has reached its observation cap. Do NOT emit any new entries "
            "in `creates` — only `updates` (to refine existing observations) and "
            "`deletes` (to retire superseded observations) are permitted this pass. "
            "Returning a non-empty `creates` list will be rejected."
        )
    else:
        capacity_note = (
            f"This scope has only {remaining_slots} observation slot(s) remaining. "
            f"Emit at most {remaining_slots} entries in `creates`; prefer `updates` to "
            "merge new facts into existing observations whenever possible."
        )
    prompt_template = build_batch_consolidation_prompt(
        observations_mission,
        capacity_note=capacity_note,
    )
    prompt = prompt_template.format(
        facts_text=facts_lines,
        observations_text=observations_text,
    )

    response_model = _build_response_model(remaining_slots)

    max_attempts = (
        config.consolidation_max_attempts
        if config is not None and getattr(config, "consolidation_max_attempts", None)
        else 3
    )
    call_kwargs: dict[str, Any] = {
        "messages": [{"role": "user", "content": prompt}],
        "response_format": response_model,
        "scope": "consolidation",
    }
    if config is not None and getattr(config, "consolidation_llm_max_retries", None) is not None:
        call_kwargs["max_retries"] = config.consolidation_llm_max_retries

    # Build a compact label of the memory IDs in this batch so per-attempt
    # warnings (json_validate_failed, schema rejections, etc.) can be traced
    # back to specific facts without bisecting the batch by hand.
    memory_ids = [str(m.get("id")) for m in memories]
    if len(memory_ids) <= 5:
        ids_label = ", ".join(memory_ids)
    else:
        ids_label = f"{', '.join(memory_ids[:3])}, ... +{len(memory_ids) - 3} more"
    batch_label = f"{len(memory_ids)} memories [{ids_label}]"

    last_exc: Exception | None = None
    for attempt in range(1, max_attempts + 1):
        try:
            response: _ConsolidationBatchResponse = await llm_config.call(**call_kwargs)
            return _BatchLLMResult(
                creates=response.creates,
                updates=response.updates,
                deletes=response.deletes,
                obs_count=len(union_observations),
                prompt_chars=len(prompt),
            )
        except Exception as exc:
            last_exc = exc
            logger.warning(
                f"[CONSOLIDATION] LLM batch call failed (attempt {attempt}/{max_attempts}) for {batch_label}: {exc}"
            )

    logger.error(
        f"[CONSOLIDATION] LLM batch call failed after {max_attempts} attempts for {batch_label}, "
        f"skipping batch. Last error: {last_exc}"
    )
    return _BatchLLMResult(obs_count=len(union_observations), prompt_chars=len(prompt))


async def _create_observation_directly(
    conn: "Connection",
    memory_engine: "MemoryEngine",
    bank_id: str,
    source_memory_ids: list[uuid.UUID],
    observation_text: str,
    tags: list[str] | None = None,
    event_date: datetime | None = None,
    occurred_start: datetime | None = None,
    occurred_end: datetime | None = None,
    mentioned_at: datetime | None = None,
    perf: ConsolidationPerfLog | None = None,
) -> dict[str, Any]:
    """Create an observation from one or more source memories with pre-processed text."""
    live_source_memory_ids = await _filter_live_source_memories(conn, bank_id, source_memory_ids)
    if not live_source_memory_ids:
        logger.info(
            f"consolidation: skipped create for bank={bank_id}, "
            f"all {len(source_memory_ids)} source memories were deleted concurrently"
        )
        return {"action": "skipped", "reason": "sources_deleted"}
    source_memory_ids = live_source_memory_ids

    t0 = time.time()
    embeddings = await embedding_utils.generate_embeddings_batch(memory_engine.embeddings, [observation_text])
    embedding_str = str(embeddings[0]) if embeddings else None
    if perf:
        perf.record_timing("embedding", time.time() - t0)

    # Create the observation as a memory_unit
    now = datetime.now(timezone.utc)
    obs_event_date = event_date or now
    obs_occurred_start = occurred_start
    obs_occurred_end = occurred_end
    obs_mentioned_at = mentioned_at or now
    obs_tags = tags or []

    t0 = time.time()
    observation_id = uuid.uuid4()

    # Query varies based on text search backend
    config = get_config()
    if config.timeline_v2:
        temporal = classify_fact_temporal_metadata(
            fact_text=observation_text,
            occurred_start=obs_occurred_start,
            mentioned_at=obs_mentioned_at,
            explicit_temporal=obs_occurred_start is not None,
            fact_kind="event" if obs_occurred_start is not None else "conversation",
        )
    else:
        temporal = None
    if config.text_search_extension == "vchord":
        # VectorChord: manually tokenize and insert search_vector
        query = f"""
            INSERT INTO {fq_table("memory_units")} (
                id, bank_id, text, fact_type, embedding, proof_count, source_memory_ids, history,
                tags, event_date, occurred_start, occurred_end, mentioned_at, timeline_anchor_at,
                timeline_anchor_kind, temporal_direction, temporal_confidence, temporal_reference_text, search_vector
            )
            VALUES ($1, $2, $3, 'observation', $4::vector, 1, $5, '[]'::jsonb, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15,
                    tokenize($3, 'llmlingua2')::bm25_catalog.bm25vector)
            RETURNING id
        """
    else:  # native or pg_textsearch
        # Native PostgreSQL: search_vector is GENERATED ALWAYS, don't include it
        # pg_textsearch: indexes operate on base columns directly, don't populate search_vector
        query = f"""
            INSERT INTO {fq_table("memory_units")} (
                id, bank_id, text, fact_type, embedding, proof_count, source_memory_ids, history,
                tags, event_date, occurred_start, occurred_end, mentioned_at, timeline_anchor_at,
                timeline_anchor_kind, temporal_direction, temporal_confidence, temporal_reference_text
            )
            VALUES ($1, $2, $3, 'observation', $4::vector, 1, $5, '[]'::jsonb, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15)
            RETURNING id
        """

    row = await conn.fetchrow(
        query,
        observation_id,
        bank_id,
        observation_text,
        embedding_str,
        source_memory_ids,
        obs_tags,
        obs_event_date,
        obs_occurred_start,
        obs_occurred_end,
        obs_mentioned_at,
        temporal.anchor_at if temporal else None,
        temporal.anchor_kind if temporal else "recorded_only",
        temporal.direction if temporal else "atemporal",
        temporal.confidence if temporal else None,
        temporal.reference_text if temporal else None,
    )

    if perf:
        perf.record_timing("db_write", time.time() - t0)

    logger.debug(f"Created observation {observation_id} from {len(source_memory_ids)} memories (tags: {obs_tags})")

    return {"action": "created", "observation_id": str(row["id"]), "tags": obs_tags}
