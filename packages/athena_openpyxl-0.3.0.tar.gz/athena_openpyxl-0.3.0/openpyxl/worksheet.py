"""
Worksheet proxy class.

Provides openpyxl-compatible Worksheet abstraction that operates
on remote workbooks via the XLSX Studio API.
"""

from __future__ import annotations

from collections.abc import Iterator
from typing import TYPE_CHECKING, Any

from .cell import Cell
from .commands import (
    DeleteColumns,
    DeleteRows,
    InsertColumns,
    InsertRows,
    RenameSheet,
    SetAutoFilter,
    SetColumnWidth,
    SetRowHeight,
    SetSheetProperties,
)
from .commands import (
    MergeCells as MergeCellsCmd,
)
from .commands import (
    UnmergeCells as UnmergeCellsCmd,
)
from .typing import SheetSnapshot
from .utils import (
    cell_reference,
    column_index_from_string,
    coordinate_from_string,
    parse_range,
)

if TYPE_CHECKING:
    from .batching import CommandBuffer
    from .workbook import Workbook


class Worksheet:
    """
    Proxy for a worksheet in a workbook.

    Provides openpyxl-compatible Worksheet API that reads from snapshots
    and writes via commands to the XLSX Studio API.

    Example:
        ws = wb.active
        ws['A1'] = "Hello"
        ws['B1'] = 42
        ws.column_dimensions['A'].width = 20
    """

    def __init__(
        self,
        workbook: Workbook,
        index: int,
        snapshot: SheetSnapshot,
        buffer: CommandBuffer,
    ):
        self._workbook = workbook
        self._index = index
        self._snapshot = snapshot
        self._buffer = buffer
        self._cells: dict[str, Cell] = {}

        # Pre-populate cells from snapshot
        for cell_key, cell_snap in snapshot.cells.items():
            cell = Cell(self, cell_snap.row, cell_snap.col, cell_snap)
            self._cells[cell_key] = cell

    @property
    def title(self) -> str:
        """Get or set the sheet name."""
        return self._snapshot.name

    @title.setter
    def title(self, value: str) -> None:
        """Rename the sheet."""
        self._snapshot.name = value
        self._buffer.add(
            RenameSheet(
                sheet_index=self._index,
                name=value,
            )
        )

    @property
    def sheet_state(self) -> str:
        """Sheet visibility state."""
        return "hidden" if self._snapshot.hidden else "visible"

    @property
    def merged_cells(self) -> MergedCellRanges:
        """Access merged cell ranges."""
        return MergedCellRanges(self)

    @property
    def column_dimensions(self) -> ColumnDimensions:
        """Access column dimension settings."""
        return ColumnDimensions(self)

    @property
    def row_dimensions(self) -> RowDimensions:
        """Access row dimension settings."""
        return RowDimensions(self)

    @property
    def freeze_panes(self) -> str | None:
        """Get or set the freeze pane location."""
        if self._snapshot.frozen_rows == 0 and self._snapshot.frozen_cols == 0:
            return None
        return cell_reference(
            self._snapshot.frozen_rows + 1,
            self._snapshot.frozen_cols + 1,
        )

    @freeze_panes.setter
    def freeze_panes(self, value: str | None) -> None:
        """Set the freeze pane location (e.g., 'B2' freezes row 1 and column A)."""
        if value is None:
            frozen_rows = 0
            frozen_cols = 0
        else:
            col_str, row = coordinate_from_string(value)
            frozen_rows = row - 1
            frozen_cols = column_index_from_string(col_str) - 1

        self._snapshot.frozen_rows = frozen_rows
        self._snapshot.frozen_cols = frozen_cols
        self._buffer.add(
            SetSheetProperties(
                sheet_index=self._index,
                frozen_rows=frozen_rows,
                frozen_cols=frozen_cols,
            )
        )

    @property
    def auto_filter(self) -> AutoFilter:
        """Access auto-filter settings."""
        return AutoFilter(self)

    @property
    def max_row(self) -> int:
        """The maximum row number containing data."""
        if not self._snapshot.cells:
            return 0
        return max(c.row for c in self._snapshot.cells.values())

    @property
    def max_column(self) -> int:
        """The maximum column number containing data."""
        if not self._snapshot.cells:
            return 0
        return max(c.col for c in self._snapshot.cells.values())

    @property
    def min_row(self) -> int:
        """The minimum row number containing data."""
        if not self._snapshot.cells:
            return 1
        return min(c.row for c in self._snapshot.cells.values())

    @property
    def min_column(self) -> int:
        """The minimum column number containing data."""
        if not self._snapshot.cells:
            return 1
        return min(c.col for c in self._snapshot.cells.values())

    # -------------------------------------------------------------------------
    # Cell access
    # -------------------------------------------------------------------------

    def cell(self, row: int, column: int, value: Any = None) -> Cell:
        """
        Get or create a cell by row and column numbers.

        Args:
            row: 1-based row number
            column: 1-based column number
            value: Optional value to set

        Returns:
            Cell object
        """
        key = cell_reference(row, column)
        if key not in self._cells:
            snap = self._snapshot.cells.get(key)
            self._cells[key] = Cell(self, row, column, snap)

        cell = self._cells[key]
        if value is not None:
            cell.value = value
        return cell

    def __getitem__(
        self, key: str | int | tuple[Any, ...]
    ) -> Cell | tuple[Cell, ...] | tuple[tuple[Cell, ...], ...]:
        """
        Access cells by coordinate string, row number, or slice.

        Examples:
            ws['A1']         # single cell
            ws['A1:C3']     # range (returns tuple of tuples of cells)
            ws['A']         # column (returns tuple of cells)
            ws[1]           # row (returns tuple of cells)
        """
        if isinstance(key, int):
            # Row access
            return self._get_row(key)

        if isinstance(key, str):
            if ":" in key:
                # Range access
                return self._get_range(key)

            # Check if it's a column letter or cell reference
            if key.isalpha():
                # Column access
                return self._get_column(key)

            # Single cell
            col_str, row = coordinate_from_string(key)
            col = column_index_from_string(col_str)
            return self.cell(row, col)

        raise TypeError(f"Unsupported key type: {type(key)}")

    def __setitem__(self, key: str, value: Any) -> None:
        """Set a cell value by coordinate string (e.g., ws['A1'] = 'Hello')."""
        if isinstance(key, str) and ":" not in key and not key.isalpha():
            col_str, row = coordinate_from_string(key)
            col = column_index_from_string(col_str)
            self.cell(row, col, value)
        else:
            raise TypeError(f"Can only set value on single cell coordinates, got: {key}")

    def _get_row(self, row: int) -> tuple[Cell, ...]:
        """Get all cells in a row."""
        max_col = self.max_column or 1
        return tuple(self.cell(row, col) for col in range(1, max_col + 1))

    def _get_column(self, col_letter: str) -> tuple[Cell, ...]:
        """Get all cells in a column."""
        col = column_index_from_string(col_letter)
        max_row = self.max_row or 1
        return tuple(self.cell(row, col) for row in range(1, max_row + 1))

    def _get_range(self, range_str: str) -> tuple[tuple[Cell, ...], ...]:
        """Get a rectangular range of cells."""
        start_row, start_col, end_row, end_col = parse_range(range_str)
        rows = []
        for row in range(start_row, end_row + 1):
            rows.append(tuple(self.cell(row, col) for col in range(start_col, end_col + 1)))
        return tuple(rows)

    def iter_rows(
        self,
        min_row: int | None = None,
        max_row: int | None = None,
        min_col: int | None = None,
        max_col: int | None = None,
        values_only: bool = False,
    ) -> Iterator[tuple[Any, ...]]:
        """
        Iterate over rows of cells.

        Matches openpyxl.worksheet.Worksheet.iter_rows behavior.
        """
        min_row = min_row or self.min_row
        max_row = max_row or self.max_row
        min_col = min_col or self.min_column
        max_col = max_col or self.max_column

        for row in range(min_row, max_row + 1):
            if values_only:
                yield tuple(self.cell(row, col).value for col in range(min_col, max_col + 1))
            else:
                yield tuple(self.cell(row, col) for col in range(min_col, max_col + 1))

    def iter_cols(
        self,
        min_row: int | None = None,
        max_row: int | None = None,
        min_col: int | None = None,
        max_col: int | None = None,
        values_only: bool = False,
    ) -> Iterator[tuple[Any, ...]]:
        """
        Iterate over columns of cells.

        Matches openpyxl.worksheet.Worksheet.iter_cols behavior.
        """
        min_row = min_row or self.min_row
        max_row = max_row or self.max_row
        min_col = min_col or self.min_column
        max_col = max_col or self.max_column

        for col in range(min_col, max_col + 1):
            if values_only:
                yield tuple(self.cell(row, col).value for row in range(min_row, max_row + 1))
            else:
                yield tuple(self.cell(row, col) for row in range(min_row, max_row + 1))

    def append(self, row_data: list[Any]) -> None:
        """
        Append a row of data to the bottom of the sheet.

        Args:
            row_data: List of values for the new row
        """
        next_row = self.max_row + 1
        for col_idx, value in enumerate(row_data, start=1):
            self.cell(next_row, col_idx, value)

    # -------------------------------------------------------------------------
    # Row/Column operations
    # -------------------------------------------------------------------------

    def insert_rows(self, idx: int, amount: int = 1) -> None:
        """Insert rows before row idx."""
        self._buffer.add(
            InsertRows(
                sheet_index=self._index,
                row=idx,
                count=amount,
            )
        )

    def insert_cols(self, idx: int, amount: int = 1) -> None:
        """Insert columns before column idx."""
        self._buffer.add(
            InsertColumns(
                sheet_index=self._index,
                col=idx,
                count=amount,
            )
        )

    def delete_rows(self, idx: int, amount: int = 1) -> None:
        """Delete rows starting at row idx."""
        self._buffer.add(
            DeleteRows(
                sheet_index=self._index,
                row=idx,
                count=amount,
            )
        )

    def delete_cols(self, idx: int, amount: int = 1) -> None:
        """Delete columns starting at column idx."""
        self._buffer.add(
            DeleteColumns(
                sheet_index=self._index,
                col=idx,
                count=amount,
            )
        )

    # -------------------------------------------------------------------------
    # Merge operations
    # -------------------------------------------------------------------------

    def merge_cells(
        self,
        range_string: str | None = None,
        start_row: int | None = None,
        start_column: int | None = None,
        end_row: int | None = None,
        end_column: int | None = None,
    ) -> None:
        """
        Merge cells in a range.

        Can use either range_string ('A1:C3') or explicit row/col params.
        """
        if range_string:
            start_row, start_column, end_row, end_column = parse_range(range_string)

        if None in (start_row, start_column, end_row, end_column):
            raise ValueError(
                "Must provide range_string or all of start_row, start_column, end_row, end_column"
            )

        # At this point, None values have been validated above
        assert start_row is not None
        assert start_column is not None
        assert end_row is not None
        assert end_column is not None

        self._buffer.add(
            MergeCellsCmd(
                sheet_index=self._index,
                start_row=start_row,
                start_col=start_column,
                end_row=end_row,
                end_col=end_column,
            )
        )

    def unmerge_cells(
        self,
        range_string: str | None = None,
        start_row: int | None = None,
        start_column: int | None = None,
        end_row: int | None = None,
        end_column: int | None = None,
    ) -> None:
        """Unmerge a previously merged range."""
        if range_string:
            start_row, start_column, end_row, end_column = parse_range(range_string)

        if None in (start_row, start_column, end_row, end_column):
            raise ValueError(
                "Must provide range_string or all of start_row, start_column, end_row, end_column"
            )

        # At this point, None values have been validated above
        assert start_row is not None
        assert start_column is not None
        assert end_row is not None
        assert end_column is not None

        self._buffer.add(
            UnmergeCellsCmd(
                sheet_index=self._index,
                start_row=start_row,
                start_col=start_column,
                end_row=end_row,
                end_col=end_column,
            )
        )

    def __repr__(self) -> str:
        return f'<Worksheet "{self.title}">'


# -------------------------------------------------------------------------
# Helper classes
# -------------------------------------------------------------------------


class MergedCellRanges:
    """Access merged cell ranges in a worksheet."""

    def __init__(self, worksheet: Worksheet):
        self._worksheet = worksheet

    @property
    def ranges(self) -> list[str]:
        """List of merged range strings."""
        from .utils import range_reference

        return [
            range_reference(mr.start_row, mr.start_col, mr.end_row, mr.end_col)
            for mr in self._worksheet._snapshot.merged_ranges
        ]

    def __iter__(self) -> Iterator[str]:
        return iter(self.ranges)

    def __len__(self) -> int:
        return len(self._worksheet._snapshot.merged_ranges)


class ColumnDimension:
    """Column dimension settings."""

    def __init__(self, worksheet: Worksheet, col: int):
        self._worksheet = worksheet
        self._col = col

    @property
    def width(self) -> float:
        """Column width in character units."""
        return self._worksheet._snapshot.column_widths.get(self._col, 8.43)

    @width.setter
    def width(self, value: float) -> None:
        self._worksheet._snapshot.column_widths[self._col] = value
        self._worksheet._buffer.add(
            SetColumnWidth(
                sheet_index=self._worksheet._index,
                col=self._col,
                width=value,
            )
        )


class ColumnDimensions:
    """Dictionary-like access to column dimensions."""

    def __init__(self, worksheet: Worksheet):
        self._worksheet = worksheet

    def __getitem__(self, key: str) -> ColumnDimension:
        col = column_index_from_string(key)
        return ColumnDimension(self._worksheet, col)


class RowDimension:
    """Row dimension settings."""

    def __init__(self, worksheet: Worksheet, row: int):
        self._worksheet = worksheet
        self._row = row

    @property
    def height(self) -> float:
        """Row height in points."""
        return self._worksheet._snapshot.row_heights.get(self._row, 15.0)

    @height.setter
    def height(self, value: float) -> None:
        self._worksheet._snapshot.row_heights[self._row] = value
        self._worksheet._buffer.add(
            SetRowHeight(
                sheet_index=self._worksheet._index,
                row=self._row,
                height=value,
            )
        )


class RowDimensions:
    """Dictionary-like access to row dimensions."""

    def __init__(self, worksheet: Worksheet):
        self._worksheet = worksheet

    def __getitem__(self, key: int) -> RowDimension:
        return RowDimension(self._worksheet, key)


class AutoFilter:
    """Auto-filter settings for a worksheet."""

    def __init__(self, worksheet: Worksheet):
        self._worksheet = worksheet
        self._ref: str | None = None

    @property
    def ref(self) -> str | None:
        """Get the auto-filter range reference."""
        return self._ref

    @ref.setter
    def ref(self, value: str | None) -> None:
        """Set the auto-filter range (e.g., 'A1:D10')."""
        self._ref = value
        if value:
            start_row, start_col, end_row, end_col = parse_range(value)
            self._worksheet._buffer.add(
                SetAutoFilter(
                    sheet_index=self._worksheet._index,
                    start_row=start_row,
                    start_col=start_col,
                    end_row=end_row,
                    end_col=end_col,
                )
            )
