"""
HTTP client for communicating with the XLSX Studio API.
"""

from __future__ import annotations

import os
import time
import uuid
from typing import Any
from urllib.parse import urljoin

import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

from .commands import AnyCommand
from .errors import (
    AuthenticationError,
    ConflictError,
    ConnectionError,
    ExportError,
    RemoteError,
    RenderError,
    UploadError,
)
from .typing import (
    CommandsResponse,
    ExportStatus,
    WorkbookSnapshot,
)

SDK_VERSION = "0.3.0"
SDK_CLIENT_TYPE = "python-sdk"

DEFAULT_TIMEOUT = 30  # seconds
DEFAULT_POLL_INTERVAL = 0.5  # seconds
DEFAULT_MAX_POLL_ATTEMPTS = 30  # 30 * 0.5 = 15 seconds max wait


class Client:
    """
    HTTP client for the XLSX Studio API.

    Handles authentication, retries, and all API communication.
    """

    def __init__(
        self,
        base_url: str | None = None,
        api_key: str | None = None,
        timeout: int = DEFAULT_TIMEOUT,
    ):
        """
        Initialize the client.

        Args:
            base_url: Base URL of the API (e.g., "https://api.xlsx-studio.com").
                     If not provided, uses ATHENA_XLSX_BASE_URL environment variable.
            api_key: Optional API key for authentication.
                    If not provided, uses ATHENA_XLSX_API_KEY environment variable.
            timeout: Request timeout in seconds

        Raises:
            ValueError: If base_url is not provided and ATHENA_XLSX_BASE_URL is not set.
        """
        if base_url is None:
            base_url = os.environ.get("ATHENA_XLSX_BASE_URL")
            if base_url is None:
                raise ValueError(
                    "base_url must be provided or ATHENA_XLSX_BASE_URL environment variable must be set"
                )

        if api_key is None:
            api_key = os.environ.get("ATHENA_XLSX_API_KEY")

        self.base_url = base_url.rstrip("/")
        self.api_key = api_key
        self.timeout = timeout
        self._session = self._create_session()

    def _create_session(self) -> requests.Session:
        """Create a requests session with retry configuration."""
        session = requests.Session()

        retry_strategy = Retry(
            total=3,
            backoff_factor=0.5,
            status_forcelist=[429, 500, 502, 503, 504],
            allowed_methods=["HEAD", "GET", "POST", "DELETE"],
        )
        adapter = HTTPAdapter(max_retries=retry_strategy)
        session.mount("http://", adapter)
        session.mount("https://", adapter)

        return session

    def _get_headers(self) -> dict[str, str]:
        """Get request headers including auth if configured."""
        headers = {
            "Content-Type": "application/json",
            "Accept": "application/json",
            "X-Client-Type": SDK_CLIENT_TYPE,
            "X-Client-Version": SDK_VERSION,
        }
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"
        return headers

    def _handle_response(self, response: requests.Response) -> Any:
        """Handle API response, raising appropriate errors."""
        if response.status_code == 401:
            raise AuthenticationError("Invalid or expired API key")

        if response.status_code == 409:
            data = response.json() if response.text else {}
            raise ConflictError(
                data.get("message", "Conflict: resource was modified"),
                stale_ids=data.get("staleIds", []),
            )

        if not response.ok:
            try:
                data = response.json()
                msg = data.get("message")
                error_obj = data.get("error")
                if not msg and isinstance(error_obj, dict):
                    msg = error_obj.get("message")
                    details = error_obj.get("details")
                    if details:
                        msg = f"{msg}: {details}"
                elif not msg and isinstance(error_obj, str):
                    msg = error_obj
                raise RemoteError(
                    message=msg or f"API error: {response.status_code}",
                    status_code=response.status_code,
                    error_code=data.get("code")
                    or (error_obj.get("code") if isinstance(error_obj, dict) else None),
                    server_message=msg,
                )
            except ValueError:
                raise RemoteError(
                    message=f"API error: {response.status_code}",
                    status_code=response.status_code,
                ) from None

        if response.status_code == 204 or not response.text:
            return None

        return response.json()

    def _request(
        self,
        method: str,
        path: str,
        json: dict[str, Any] | None = None,
        params: dict[str, Any] | None = None,
    ) -> Any:
        """Make an HTTP request."""
        url = urljoin(self.base_url + "/", path.lstrip("/"))

        headers = self._get_headers()
        if json is None:
            headers.pop("Content-Type", None)

        try:
            response = self._session.request(
                method=method,
                url=url,
                json=json,
                params=params,
                headers=headers,
                timeout=self.timeout,
            )
            return self._handle_response(response)
        except requests.ConnectionError as e:
            raise ConnectionError(f"Failed to connect to {url}: {e}", url=url) from e
        except requests.Timeout as e:
            raise ConnectionError(f"Request timed out: {url}", url=url) from e

    def _download(self, url: str) -> bytes:
        """Download binary content from a URL."""
        try:
            response = self._session.get(url, timeout=self.timeout)
            response.raise_for_status()
            return bytes(response.content)
        except requests.RequestException as e:
            raise ConnectionError(f"Failed to download from {url}: {e}", url=url) from e

    # -------------------------------------------------------------------------
    # Workbook operations
    # -------------------------------------------------------------------------

    def get_workbook(self, workbook_id: str) -> dict[str, Any]:
        """Get workbook metadata."""
        result: dict[str, Any] = self._request("GET", f"/workbooks/{workbook_id}")
        return result

    def list_workbooks(self, limit: int = 20, offset: int = 0) -> list[dict[str, Any]]:
        """List all workbooks."""
        result: list[dict[str, Any]] = self._request(
            "GET", "/workbooks", params={"limit": limit, "offset": offset}
        )
        return result

    def create_workbook(self, name: str | None = None) -> dict[str, Any]:
        """
        Create a new workbook, returns upload URL and workbook ID.

        Args:
            name: Optional name for the workbook

        Returns:
            Dictionary with id, name, status, uploadUrl, createdAt
        """
        payload = {"name": name} if name else None
        result: dict[str, Any] = self._request("POST", "/workbooks", json=payload)
        return result

    def create_empty_workbook(self, name: str | None = None) -> dict[str, Any]:
        """
        Create a new empty workbook that's immediately ready.

        Unlike create_workbook(), this creates a workbook without requiring an upload.
        The workbook is immediately usable with one empty sheet.

        Args:
            name: Optional name for the workbook

        Returns:
            Dictionary with id, name, status, sheetCount, createdAt
        """
        payload = {"name": name} if name else None
        result: dict[str, Any] = self._request("POST", "/workbooks/empty", json=payload)
        return result

    def delete_workbook(self, workbook_id: str) -> None:
        """Delete a workbook."""
        self._request("DELETE", f"/workbooks/{workbook_id}")

    def upload_file(
        self,
        file_path: str,
        name: str | None = None,
        poll_interval: float = DEFAULT_POLL_INTERVAL,
        max_attempts: int = DEFAULT_MAX_POLL_ATTEMPTS,
    ) -> str:
        """
        Upload an XLSX file and wait for processing to complete.

        Args:
            file_path: Path to the XLSX file to upload
            name: Optional name for the workbook (defaults to filename)
            poll_interval: Seconds between status polls
            max_attempts: Maximum number of poll attempts

        Returns:
            The workbook ID of the uploaded workbook

        Raises:
            UploadError: If upload or processing fails
            FileNotFoundError: If the file doesn't exist
        """
        import os

        if not os.path.exists(file_path):
            raise FileNotFoundError(f"File not found: {file_path}")

        if name is None:
            name = os.path.basename(file_path)
            if name.endswith(".xlsx") or name.endswith(".xltx"):
                name = name[:-5]

        # Step 1: Create workbook to get presigned URL
        wb_info = self.create_workbook(name)
        workbook_id = wb_info["id"]
        upload_url = wb_info.get("uploadUrl")

        if not upload_url:
            raise UploadError("Server did not return upload URL", workbook_id)

        # Step 2: Upload file to presigned URL
        try:
            with open(file_path, "rb") as f:
                file_data = f.read()

            response = self._session.put(
                upload_url,
                data=file_data,
                headers={
                    "Content-Type": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
                },
                timeout=120,
            )
            response.raise_for_status()
        except Exception as e:
            raise UploadError(f"Failed to upload file: {e}", workbook_id) from e

        # Step 3: Notify server that upload is complete
        try:
            self._request("POST", f"/workbooks/{workbook_id}/upload-complete")
        except Exception as e:
            raise UploadError(f"Failed to notify upload complete: {e}", workbook_id) from e

        # Step 4: Poll for processing to complete
        for _ in range(max_attempts):
            wb = self.get_workbook(workbook_id)
            status = wb.get("status")

            if status == "ready":
                return str(workbook_id)

            if status == "error":
                raise UploadError("Processing failed", workbook_id)

            time.sleep(poll_interval)

        raise UploadError("Processing timed out", workbook_id)

    # -------------------------------------------------------------------------
    # Commands
    # -------------------------------------------------------------------------

    def post_commands(
        self,
        workbook_id: str,
        commands: list[AnyCommand],
        return_snapshot: bool = True,
        org_id: str | None = None,
    ) -> CommandsResponse:
        """
        Send commands to apply to a workbook.

        Args:
            workbook_id: ID of the workbook to modify
            commands: List of commands to apply
            return_snapshot: Whether to return updated snapshot
            org_id: Optional organization/workspace ID for Athena assets

        Returns:
            Response with applied status, created IDs, and optional snapshot
        """
        for cmd in commands:
            cmd.validate()

        payload = {
            "client": {"type": SDK_CLIENT_TYPE, "version": SDK_VERSION},
            "txn": {"id": str(uuid.uuid4()), "mode": "atomic"},
            "commands": [cmd.to_dict() for cmd in commands],
            "return": {"snapshot": return_snapshot},
        }

        params = {"orgId": org_id} if org_id else None
        result: CommandsResponse = self._request(
            "POST", f"/workbooks/{workbook_id}/commands", json=payload, params=params
        )
        return result

    # -------------------------------------------------------------------------
    # Snapshot
    # -------------------------------------------------------------------------

    def get_snapshot(self, workbook_id: str, org_id: str | None = None) -> WorkbookSnapshot:
        """Get the current state snapshot of a workbook.

        Args:
            workbook_id: ID of the workbook
            org_id: Optional organization/workspace ID for Athena assets
        """
        params = {"orgId": org_id} if org_id else None
        data = self._request("GET", f"/workbooks/{workbook_id}/snapshot", params=params)
        return self._parse_snapshot(data)

    def _parse_snapshot(self, data: dict[str, Any]) -> WorkbookSnapshot:
        """Parse raw snapshot data into typed objects."""
        from .typing import CellSnapshot, MergedRange, SheetSnapshot, WorkbookSnapshot

        sheets = []
        for sheet_data in data.get("sheets", []):
            cells: dict[str, CellSnapshot] = {}
            for cell_key, cell_data in sheet_data.get("cells", {}).items():
                cells[cell_key] = CellSnapshot(
                    row=cell_data["row"],
                    col=cell_data["col"],
                    value=cell_data.get("value"),
                    cell_type=cell_data.get("cellType", "empty"),
                    formula=cell_data.get("formula"),
                    style=cell_data.get("style"),
                    comment=cell_data.get("comment"),
                )

            merged_ranges = []
            for mr_data in sheet_data.get("mergedRanges", []):
                merged_ranges.append(
                    MergedRange(
                        start_row=mr_data["startRow"],
                        start_col=mr_data["startCol"],
                        end_row=mr_data["endRow"],
                        end_col=mr_data["endCol"],
                    )
                )

            sheets.append(
                SheetSnapshot(
                    id=sheet_data["id"],
                    index=sheet_data["index"],
                    name=sheet_data["name"],
                    cells=cells,
                    merged_ranges=merged_ranges,
                    column_widths=sheet_data.get("columnWidths", {}),
                    row_heights=sheet_data.get("rowHeights", {}),
                    frozen_rows=sheet_data.get("frozenRows", 0),
                    frozen_cols=sheet_data.get("frozenCols", 0),
                    hidden=sheet_data.get("hidden", False),
                    tab_color=sheet_data.get("tabColor"),
                )
            )

        return WorkbookSnapshot(
            workbook_id=data["workbookId"],
            name=data.get("name", "Untitled"),
            sheet_count=data.get("sheetCount", len(sheets)),
            sheets=sheets,
            active_sheet_index=data.get("activeSheetIndex", 0),
        )

    # -------------------------------------------------------------------------
    # Export
    # -------------------------------------------------------------------------

    def start_export(self, workbook_id: str) -> str:
        """Start an export job. Returns job ID."""
        result = self._request("POST", f"/workbooks/{workbook_id}/export")
        return str(result["jobId"])

    def get_export_status(self, workbook_id: str, job_id: str) -> ExportStatus:
        """Get the status of an export job."""
        result: ExportStatus = self._request("GET", f"/workbooks/{workbook_id}/export/{job_id}")
        return result

    def export_and_download(
        self,
        workbook_id: str,
        poll_interval: float = DEFAULT_POLL_INTERVAL,
        max_attempts: int = DEFAULT_MAX_POLL_ATTEMPTS,
    ) -> bytes:
        """
        Start export, poll for completion, and download the file.

        Returns:
            XLSX file bytes
        """
        job_id = self.start_export(workbook_id)

        for _ in range(max_attempts):
            status = self.get_export_status(workbook_id, job_id)

            if status["status"] == "completed":
                download_url = status.get("downloadUrl")
                if not download_url:
                    raise ExportError("Export completed but no download URL", job_id)
                return self._download(str(download_url))

            if status["status"] in ("failed", "error"):
                raise ExportError(str(status.get("error", "Export failed")), job_id)

            time.sleep(poll_interval)

        raise ExportError("Export timed out", job_id)

    # -------------------------------------------------------------------------
    # Render
    # -------------------------------------------------------------------------

    def render_sheet_sync(
        self,
        workbook_id: str,
        sheet_index: int,
    ) -> bytes:
        """
        Synchronously render a sheet as PNG.

        Args:
            workbook_id: ID of the workbook
            sheet_index: Zero-based sheet index

        Returns:
            PNG image bytes
        """
        sheet_number = sheet_index + 1
        url = f"{self.base_url}/workbooks/{workbook_id}/sheets/{sheet_number}/png"
        try:
            response = self._session.get(
                url,
                headers=self._get_headers(),
                timeout=self.timeout,
            )
            response.raise_for_status()
            return bytes(response.content)
        except requests.RequestException as e:
            raise RenderError(f"Sync render failed: {e}") from e

    # -------------------------------------------------------------------------
    # Connection info
    # -------------------------------------------------------------------------

    def get_connection_info(self, workbook_id: str) -> dict[str, str]:
        """
        Get yhub WebSocket connection info for real-time collaboration.

        Returns:
            Dictionary with wsUrl and authToken
        """
        result: dict[str, str] = self._request("GET", f"/workbooks/{workbook_id}/connection")
        return result
