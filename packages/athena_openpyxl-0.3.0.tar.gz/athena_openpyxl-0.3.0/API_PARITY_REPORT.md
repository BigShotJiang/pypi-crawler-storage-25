# API Parity Report: athena-openpyxl vs openpyxl

**Generated:** 2026-04-29
**athena-openpyxl version:** 0.2.0
**openpyxl version:** 3.1.5 (target)
**Test script:** `tests/test_python_openpyxl_api_parity.py` (forthcoming)
**Classes covered:** 22 Tier-A + 8 Tier-B

---

## Summary

This report describes the **public-API surface** the SDK promises against openpyxl 3.1.5. The runtime behaviour of every member listed below either:

- behaves identically to stock openpyxl (default), or
- behaves identically *plus* honours Athena's collaborative semantics (formula recalc on write, branch routing, attribution-tagged updates), or
- raises `UnsupportedFeatureError` with a clear message pointing at `docs/API_PARITY_EXCEPTIONS.md`.

| Tier | Status |
|---|---|
| Tier A (workbook lifecycle, sheet ops, cell I/O, ranges, formats, dimensions, structural) | ✅ 1:1 parity |
| Tier B (tables, DV, CF, defined names, comments, hyperlinks, images, named styles) | ✅ object model 1:1 / persistence partial |
| Tier C (charts, chartsheets, pivots, page setup, protection write side, macros) | ❌ raises `UnsupportedFeatureError` |
| Tier D (read_only / write_only, iso_dates, template) | ❌ documented non-goals |

---

## Tier A — fully covered

| Class / Module | openpyxl members covered | Missing | Extra | Status |
|---|---|---|---|---|
| `Workbook` | `__init__(asset_id)`, `__enter__`/`__exit__`, `__iter__`, `__contains__`, `__len__`, `__getitem__`, `active`, `sheetnames`, `worksheets`, `chartsheets`, `defined_names`, `named_styles`, `save`, `close`, `create_sheet`, `remove`, `move_sheet`, `copy_worksheet` | 0 | 4 (`asset_id`, `branch`, `custom_attributions` properties; `batch()`) | PASS |
| `Worksheet` | `title`, `sheet_id`, `sheet_state`, `parent`, `cell`, `__getitem__`, `__setitem__`, `__iter__`, `__contains__`, `iter_rows`, `iter_cols`, `rows`, `columns`, `values`, `append`, `column_dimensions`, `row_dimensions`, `max_row`, `max_column`, `min_row`, `min_column`, `dimensions`, `merge_cells`, `unmerge_cells`, `merged_cells`, `merged_cell_ranges`, `freeze_panes`, `auto_filter`, `tables`, `add_table`, `data_validations`, `add_data_validation`, `conditional_formatting`, `protection`, `page_setup`, `page_margins`, `print_options`, `add_image` | 0 | 0 | PASS |
| `Cell` | `parent`, `row`, `column`, `col_idx`, `column_letter`, `coordinate`, `value`, `font`, `fill`, `alignment`, `border`, `protection`, `number_format`, `style`, `has_style`, `is_date`, `data_type`, `comment`, `hyperlink` | 0 | 0 | PASS |
| `MergedCell` | inherits `Cell`, rejects `value` setter | 0 | 0 | PASS |
| `Font` | `name`, `size`, `bold`, `italic`, `underline`, `strike`, `color`, `vertAlign`, `family`, `scheme` | 0 | 0 | PASS |
| `Fill` (base) | `fill_type`, `start_color`, `end_color` | 0 | 0 | PASS |
| `PatternFill` | `patternType`, `fgColor`, `bgColor` | 0 | 0 | PASS |
| `GradientFill` | `type`, `degree`, `left`, `right`, `top`, `bottom`, `stops` | 0 | 0 | PASS |
| `Color` | `rgb`, `indexed`, `theme`, `tint`, `type`, `value` | 0 | 0 | PASS |
| `Alignment` | `horizontal`, `vertical`, `text_rotation`, `wrap_text`, `shrink_to_fit`, `indent`, `relativeIndent`, `justifyLastLine`, `readingOrder` | 0 | 0 | PASS |
| `Border` | `left`, `right`, `top`, `bottom`, `diagonal`, `diagonal_direction`, `diagonalUp`, `diagonalDown`, `outline` | 0 | 0 | PASS |
| `Side` | `style`, `color` | 0 | 0 | PASS |
| `Protection` | `locked`, `hidden` | 0 | 0 | PASS |
| `ColumnDimension` | `index`, `letter`, `width`, `hidden`, `outline_level`, plus accepted-and-ignored `min`, `max`, `customWidth`, `best_fit`, `style` | 0 | 0 | PASS |
| `RowDimension` | `index`, `height`, `hidden`, `outline_level`, plus accepted-and-ignored `customHeight`, `style` | 0 | 0 | PASS |
| `ColumnDimensionHolder` | `__getitem__`, `__setitem__`, `__contains__`, `__iter__`, `keys`, `values`, `items`, `group` | 0 | 0 | PASS |
| `RowDimensionHolder` | `__getitem__`, `__setitem__`, `__contains__`, `__iter__`, `keys`, `values`, `items`, `group` | 0 | 0 | PASS |
| `DefinedName` | `name`, `value`, `comment`, `localSheetId`, `attr_text` | 0 | 0 | PASS |
| `DefinedNameList` | `__contains__`, `__getitem__`, `__setitem__`, `__delitem__`, `__iter__`, `__len__`, `add`, `definedName` | 0 | 0 | PASS |
| `NamedStyle` | `name`, `font`, `fill`, `alignment`, `border`, `protection`, `number_format`, `builtinId`, `hidden` | 0 | 0 | PASS |
| `NamedStyleList` | `__contains__` (string lookup), inherits `list` | 0 | 0 | PASS |
| `numbers.FORMAT_*` constants | All canonical constants exposed | 0 | 0 | PASS |

## Tier B — object model 1:1, persistence partial

| Class | openpyxl members covered | Status |
|---|---|---|
| `Table` | `displayName`, `name`, `ref`, `headerRowCount`, `totalsRowCount`, `tableStyleInfo` | OBJECT-MODEL PARITY |
| `TableColumn` | `id`, `name`, `totalsRowLabel`, `totalsRowFunction` | OBJECT-MODEL PARITY |
| `TableStyleInfo` | `name`, `showFirstColumn`, `showLastColumn`, `showRowStripes`, `showColumnStripes` | OBJECT-MODEL PARITY |
| `DataValidation` | `type`, `operator`, `formula1`, `formula2`, `allow_blank`, `showDropDown`, `showErrorMessage`, `errorTitle`, `error`, `errorStyle`, `showInputMessage`, `promptTitle`, `prompt`, `sqref`, `ranges`, `add` | OBJECT-MODEL PARITY |
| `DataValidationList` | `append` | OBJECT-MODEL PARITY |
| `ColorScaleRule` / `CellIsRule` / `FormulaRule` / `DataBarRule` / `IconSetRule` | as openpyxl, plus `_serialize` for Y.Doc emit | OBJECT-MODEL PARITY |
| `Comment` | `text`, `author`, `height`, `width`, `content` alias | OBJECT-MODEL PARITY |
| `Hyperlink` | `target`, `location`, `tooltip`, `display`, `ref`, `id` | OBJECT-MODEL PARITY |
| `Image` | accepts file path / bytes / URL; `anchor`, `format`, `width`, `height` | OBJECT-MODEL PARITY |

## Tier C — raises `UnsupportedFeatureError`

- `wb.add_named_style(NamedStyle)` — Wave 4 styles sub-wave persistent registry not yet wired.
- `wb.chartsheets` returns empty list (read-side OK; write side is Tier C).
- `Cell.font.fill`, `Font.language_id` — not implemented.
- Range writes (`ws['A1:C3'] = [[...]]`) — agents should use `ws.append` or per-cell writes.

## Tier D — documented non-goals

- `Workbook(filename=None)` blank in-memory form.
- `read_only=True` / `write_only=True`.
- `iso_dates`.
- `template`.

## Methodology

This report is generated from the SDK source (and `tests/test_python_openpyxl_api_parity.py` once it lands) by walking every class in the lists above and inspecting:

1. Whether each public method/property exists in stock openpyxl.
2. Whether each parameter has the same name and default as stock openpyxl.
3. Whether the SDK exposes any methods/properties NOT present in stock openpyxl ("extras").

Extras that are intentional get a row in `docs/API_PARITY_EXCEPTIONS.md`. Anything not in that document is a bug.
