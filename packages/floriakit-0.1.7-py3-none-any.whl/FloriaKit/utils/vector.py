import typing as t
from pyglm import glm

if t.TYPE_CHECKING:
    from .. import hints

if t.TYPE_CHECKING:

    @t.overload
    def lerp(
        start: 'hints.vec2',
        end: 'hints.vec2',
        progress: float,
    ) -> 'hints.vec2': ...

    @t.overload
    def lerp(
        start: 'hints.vec3',
        end: 'hints.vec3',
        progress: float,
    ) -> 'hints.vec3': ...

    @t.overload
    def lerp(
        start: 'hints.vec4',
        end: 'hints.vec4',
        progress: float,
    ) -> 'hints.vec4': ...

    @t.overload
    def lerp(
        start: t.Iterable['hints.number'],
        end: t.Iterable['hints.number'],
        progress: float,
    ) -> tuple['hints.number', ...]: ...


def lerp(
    start: t.Iterable['hints.number'],
    end: t.Iterable['hints.number'],
    progress: float,
) -> t.Any:
    return tuple(glm.lerp(start, end, progress))  # pyright: ignore[reportReturnType]


# TODO: слишком медленно
def calculate[T: 'hints.number'](
    vector: t.Iterable[T],
    *values: t.Iterable[T] | T,
    predicate: t.Callable[[T, T], T],
) -> tuple[T, ...]:
    result = vector

    for value in values:
        if isinstance(value, t.Iterable):
            result = tuple(
                predicate(arg1, arg2) for arg1, arg2 in zip(result, value, strict=True)
            )
        else:
            result = tuple(predicate(arg, value) for arg in result)

    return tuple(result)


if t.TYPE_CHECKING:

    @t.overload
    def sum(
        vector: 'hints.vec2[hints.number]',
        *values: 'hints.vec2[hints.number] | hints.number',
        predicate: (
            t.Callable[['hints.number', 'hints.number'], 'hints.number'] | None
        ) = ...,
    ) -> 'hints.vec2[hints.number]': ...

    @t.overload
    def sum(
        vector: 'hints.vec3[hints.number]',
        *values: 'hints.vec3[hints.number] | hints.number',
        predicate: (
            t.Callable[['hints.number', 'hints.number'], 'hints.number'] | None
        ) = ...,
    ) -> 'hints.vec3[hints.number]': ...

    @t.overload
    def sum(
        vector: 'hints.vec4[hints.number]',
        *values: 'hints.vec4[hints.number] | hints.number',
        predicate: (
            t.Callable[['hints.number', 'hints.number'], 'hints.number'] | None
        ) = ...,
    ) -> hints.vec4[hints.number]: ...


def sum(
    vector: t.Iterable['hints.number'],
    *values: t.Iterable['hints.number'] | 'hints.number',
    predicate: (
        t.Callable[['hints.number', 'hints.number'], 'hints.number'] | None
    ) = None,
) -> tuple['hints.number', ...]:
    return calculate(
        vector,
        *values,
        predicate=(lambda x, y: x + y) if predicate is None else predicate,
    )


if t.TYPE_CHECKING:

    @t.overload
    def sub(
        vector: 'hints.vec2[hints.number]',
        *values: 'hints.vec2[hints.number] | hints.number',
        predicate: (
            t.Callable[['hints.number', 'hints.number'], 'hints.number'] | None
        ) = ...,
    ) -> 'hints.vec2[hints.number]': ...

    @t.overload
    def sub(
        vector: 'hints.vec3[hints.number]',
        *values: 'hints.vec3[hints.number] | hints.number',
        predicate: (
            t.Callable[['hints.number', 'hints.number'], 'hints.number'] | None
        ) = ...,
    ) -> 'hints.vec3[hints.number]': ...

    @t.overload
    def sub(
        vector: 'hints.vec4[hints.number]',
        *values: 'hints.vec4[hints.number] | hints.number',
        predicate: (
            t.Callable[['hints.number', 'hints.number'], 'hints.number'] | None
        ) = ...,
    ) -> 'hints.vec4[hints.number]': ...


def sub(
    vector: t.Iterable['hints.number'],
    *values: t.Iterable['hints.number'] | 'hints.number',
    predicate: (
        t.Callable[['hints.number', 'hints.number'], 'hints.number'] | None
    ) = None,
) -> tuple['hints.number', ...]:
    return calculate(
        vector,
        *values,
        predicate=(lambda x, y: x - y) if predicate is None else predicate,
    )


if t.TYPE_CHECKING:

    @t.overload
    def mul(
        vector: 'hints.vec2[hints.number]',
        *values: 'hints.vec2[hints.number] | hints.number',
        predicate: (
            t.Callable[['hints.number', 'hints.number'], 'hints.number'] | None
        ) = ...,
    ) -> 'hints.vec2[hints.number]': ...

    @t.overload
    def mul(
        vector: 'hints.vec3[hints.number]',
        *vectors: 'hints.vec3[hints.number] | hints.number',
        predicate: (
            t.Callable[['hints.number', 'hints.number'], 'hints.number'] | None
        ) = ...,
    ) -> 'hints.vec3[hints.number]': ...

    @t.overload
    def mul(
        vector: 'hints.vec4[hints.number]',
        *vectors: 'hints.vec4[hints.number] | hints.number',
        predicate: (
            t.Callable[['hints.number', 'hints.number'], 'hints.number'] | None
        ) = ...,
    ) -> 'hints.vec4[hints.number]': ...


def mul(
    vector: t.Iterable['hints.number'],
    *vectors: t.Iterable['hints.number'] | 'hints.number',
    predicate: (
        t.Callable[['hints.number', 'hints.number'], 'hints.number'] | None
    ) = None,
) -> tuple['hints.number', ...]:
    return calculate(
        vector,
        *vectors,
        predicate=(lambda x, y: x * y) if predicate is None else predicate,
    )


if t.TYPE_CHECKING:

    @t.overload
    def div(
        vector: 'hints.vec2[hints.number]',
        *vectors: 'hints.vec2[hints.number] | hints.number',
        predicate: (
            t.Callable[['hints.number', 'hints.number'], 'hints.number'] | None
        ) = ...,
    ) -> 'hints.vec2[hints.number]': ...

    @t.overload
    def div(
        vector: 'hints.vec3[hints.number]',
        *values: 'hints.vec3[hints.number] | hints.number',
        predicate: (
            t.Callable[['hints.number', 'hints.number'], 'hints.number'] | None
        ) = ...,
    ) -> 'hints.vec3[hints.number]': ...

    @t.overload
    def div(
        vector: 'hints.vec4[hints.number]',
        *vectors: 'hints.vec4[hints.number] | hints.number',
        predicate: (
            t.Callable[['hints.number', 'hints.number'], 'hints.number'] | None
        ) = ...,
    ) -> 'hints.vec4[hints.number]': ...


def div(
    vector: t.Iterable['hints.number'],
    *values: t.Iterable['hints.number'] | 'hints.number',
    predicate: (
        t.Callable[['hints.number', 'hints.number'], 'hints.number'] | None
    ) = None,
) -> tuple['hints.number', ...]:
    return calculate(
        vector,
        *values,
        predicate=(lambda x, y: x / y) if predicate is None else predicate,
    )


def to_vec2[T](
    vector: 'hints.vec2[T] | hints.vec3[T] | hints.vec4[T]',
) -> 'hints.vec2[T]':
    return vector[:2]


def to_vec3[T](
    vector: 'hints.vec2[T] | hints.vec3[T] | hints.vec4[T]',
    z: T,
) -> 'hints.vec3[T]':
    return (*vector, z)[:3]  # pyright: ignore[reportReturnType]


def to_vec4[T](
    vector: 'hints.vec2[T] | hints.vec3[T] | hints.vec4[T]',
    z: T,
    w: T,
) -> 'hints.vec4[T]':
    return (*vector, z, w)[:3]  # pyright: ignore[reportReturnType]


def distance[
    T: 'hints.vec2[hints.number] | hints.vec3[hints.number] | hints.vec4[hints.number]'
](
    vector1: T,
    vector2: T,
) -> float:
    return glm.distance(vector1, vector2)


if t.TYPE_CHECKING:

    @t.overload
    def round_(
        vector: 'hints.vec2[hints.number]',
    ) -> 'hints.vec2i': ...

    @t.overload
    def round_(
        vector: 'hints.vec2[hints.number]',
        ndigits: int,
        /,
    ) -> 'hints.vec2[float]': ...

    @t.overload
    def round_(
        vector: 'hints.vec3[hints.number]',
    ) -> 'hints.vec3i': ...

    @t.overload
    def round_(
        vector: 'hints.vec3[hints.number]',
        ndigits: int,
        /,
    ) -> 'hints.vec3[float]': ...

    @t.overload
    def round_(
        vector: 'hints.vec4[hints.number]',
    ) -> 'hints.vec4i': ...

    @t.overload
    def round_(
        vector: 'hints.vec4[hints.number]',
        ndigits: int,
        /,
    ) -> 'hints.vec4[float]': ...

    @t.overload
    def round_(
        vector: t.Iterable['hints.number'],
    ) -> tuple[int, ...]: ...

    @t.overload
    def round_(
        vector: t.Iterable['hints.number'],
        ndigits: int,
        /,
    ) -> tuple[float, ...]: ...


def round_(vector: t.Iterable['hints.number'], *args: t.Any) -> t.Any:
    return tuple(round(arg, *args) for arg in vector)


__all__ = [
    'lerp',
    #
    'sum',
    'sub',
    'mul',
    'div',
    #
    'to_vec2',
    'to_vec3',
    'to_vec4',
    #
    'distance',
    #
    'round_',
]
