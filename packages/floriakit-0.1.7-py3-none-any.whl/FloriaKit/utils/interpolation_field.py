import typing as t
import time

from .calculated_value import CalculatedValue, gcv


class InterpolationField[T = t.Any]:
    __slots__ = (
        '_interpolation_func',
        '_delay',
        '_value',
        '_next',
        '__weakref__',
    )

    def __init__(
        self,
        interpolation_func: t.Callable[[T, T, float], T],
        delay: CalculatedValue[float] | float,
        default: T = None,
    ):
        self._interpolation_func = interpolation_func
        self._delay = delay

        self._value: T = default
        self._next: tuple[T, float] | None = None
        '''next_value, next_time'''

    def get_value(self) -> T:
        if self._next is None:
            return self._value

        next_value, next_time = self._next

        if time.perf_counter() >= next_time:
            self._value = next_value
            self._next = None

            return self._value

        value = self._interpolation_func(
            self._value,
            next_value,
            self.progress,
        )

        return value

    def set_value(self, value: T, flash: bool = False) -> t.Self:
        if flash:
            self._next = None
            self._value = value

        else:
            if self._next is not None:
                self._value = self._next[0]

            self._next = (
                value,
                time.perf_counter() + self.delay,
            )

        return self

    @property
    def progress(self) -> float:
        if self._next is None:
            return 1

        _, next_time = self._next

        if (cur_time := time.perf_counter()) >= next_time:
            return 1

        return min(
            1,
            max(
                0,
                1 - (next_time - cur_time) / self.delay,
            ),
        )

    @property
    def delay(self):
        return gcv(self._delay)

    @property
    def is_interpolated(self):
        return self._next is not None

    @property
    def next_value(self):
        return None if self._next is None else self._next[0]


__all__ = ['InterpolationField']
