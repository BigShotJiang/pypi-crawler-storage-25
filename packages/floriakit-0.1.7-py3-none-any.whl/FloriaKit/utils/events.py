import typing as t
from abc import ABC, abstractmethod
from uuid import UUID
import weakref
import asyncio

from . import function
from .. import protocols as proto
from .flag import Flag


class EventHandlerInfo(t.NamedTuple):
    weak_func: (
        weakref.ReferenceType[proto.functions.AnyFunction[..., t.Any]]
        | proto.functions.AnyFunction[..., t.Any]
    )
    once: bool = False
    wait: bool = True

    def get_func(self) -> proto.functions.AnyFunction[..., t.Any] | None:
        return (
            func()
            if isinstance(func := self.weak_func, weakref.ReferenceType)
            else func
        )


class BaseEvent[**P = [], R = t.Any](ABC):
    __slots__ = (
        '__weakref__',
        '_handlers',
        '_async_support',
        '_is_invoked',
    )

    def __init__(self, async_support: bool):
        self._handlers: dict[
            str,
            EventHandlerInfo,
        ] = {}
        self._async_support: bool = async_support
        self._is_invoked = Flag()

    def _invoke(
        self,
        *args: P.args,
        **kwargs: P.kwargs,
    ) -> list[asyncio.Task[t.Any]]:
        to_remove: set[str] = set()
        tasks: list[asyncio.Task[t.Any]] = []

        with self._is_invoked:
            for key, info in self._handlers.items():
                if (func := info.get_func()) is None or info.once:
                    to_remove.add(key)

                    if func is None:
                        continue

                if asyncio.iscoroutine(result := func(*args, **kwargs)):
                    if not self.async_support:
                        raise

                    task = asyncio.create_task(result)
                    if info.wait:
                        tasks.append(task)
                    else:
                        task.add_done_callback(self._task_done_callback)

        if len(to_remove) > 0:
            for key in to_remove:
                self._handlers.pop(key, None)

        return tasks

    @staticmethod
    def _task_done_callback(task: asyncio.Task[t.Any]) -> None:
        try:
            task.result()

        except asyncio.CancelledError:
            pass

    if t.TYPE_CHECKING:

        @t.overload
        def register(
            self,
            func: proto.functions.AnyFunction[P, R],
            /,
        ) -> proto.functions.AnyFunction[P, R]: ...

        @t.overload
        def register(
            self,
            *,
            once: bool = False,
            wait: bool = True,
        ) -> t.Callable[
            [proto.functions.AnyFunction[P, R]],
            proto.functions.AnyFunction[P, R],
        ]: ...

    def register(
        self,
        func: proto.functions.AnyFunction[P, R] | None = None,
        *,
        once: bool = False,
        wait: bool = True,
    ) -> t.Any:
        def decorator(func: proto.functions.AnyFunction[P, R]):
            if (key := function.get_key(func)) not in self._handlers:
                if self.is_invoking:
                    raise

                self._handlers[key] = EventHandlerInfo(
                    weak_func=(
                        weakref.WeakMethod(func) if hasattr(func, '__self__') else func
                    ),
                    once=once,
                    wait=wait,
                )

            return func

        if func is None:
            return decorator
        return decorator(func)

    def unregister[T: proto.functions.AnyFunction[..., t.Any]](
        self,
        func: T | None = None,
    ) -> T | None:
        if func is not None:
            if (key := function.get_key(func)) in self._handlers:
                if self.is_invoking:
                    raise
                self._handlers.pop(key)

        return func

    def __call__(
        self,
        func: proto.functions.AnyFunction[P, R],
    ):
        return self.register(func)

    def has(
        self,
        func: proto.functions.AnyFunction[P, R] | None,
    ) -> bool:
        if func is not None:
            return any(
                handler.get_func() == func for handler in self._handlers.values()
            )
        return False

    def has_id(self, id: UUID | None) -> bool:
        return id is not None and id in self._handlers

    def clear(self):
        self._handlers.clear()

    @property
    def async_support(self):
        return self._async_support

    @property
    def is_invoking(self):
        return self._is_invoked.value


class Event[**P = [], R = t.Any](BaseEvent[P, R]):
    def __init__(self):
        super().__init__(False)

    def invoke(self, *args: P.args, **kwargs: P.kwargs):
        if len(self._invoke(*args, **kwargs)) > 0:
            raise RuntimeError(
                'Event has async handlers, use EventAsync or handle tasks manually'
            )


class EventAsync[**P = [], R = t.Any](BaseEvent[P, R]):
    def __init__(self):
        super().__init__(True)

    async def invoke(self, *args: P.args, **kwargs: P.kwargs):
        if len(tasks := self._invoke(*args, **kwargs)) > 0:
            await asyncio.gather(*tasks, return_exceptions=True)


class EventAny[**P = [], R = t.Any](BaseEvent[P, R]):
    async def invoke_async(self, *args: P.args, **kwargs: P.kwargs):
        if len(tasks := self._invoke(*args, **kwargs)) > 0:
            await asyncio.gather(*tasks)

    def invoke_sync(self, *args: P.args, **kwargs: P.kwargs):
        self._invoke(*args, **kwargs)


__all__ = [
    'BaseEvent',
    'Event',
    'EventAsync',
    'EventAny',
]
