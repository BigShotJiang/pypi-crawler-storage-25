"""CodeTrust Integrations — webhook, OpenTelemetry, and third-party connectors.

Makes CodeTrust plug-and-play with enterprise monitoring stacks:
- Webhooks (Slack, Teams, PagerDuty, custom)
- OpenTelemetry metrics export (Grafana, Prometheus, Datadog)
- Jira/Linear ticket creation on critical findings
- SARIF upload to GitHub Code Scanning

Standards:
- OpenTelemetry Metrics SDK (OTLP)
- Webhook signature verification (HMAC-SHA256)
- OAuth 2.0 bearer token forwarding
"""

from __future__ import annotations

import hashlib
import hmac
import json
import os
import time
import urllib.request
import urllib.error
from dataclasses import dataclass, field, asdict
from typing import Any

from .types import TrustResult, TrustIssue, Severity


# ---------------------------------------------------------------------------
# Webhook System
# ---------------------------------------------------------------------------

@dataclass
class WebhookConfig:
    """Configuration for an outbound webhook."""
    url: str
    events: list[str] = field(default_factory=lambda: ["scan.completed", "scan.critical"])
    secret: str = ""  # HMAC-SHA256 signing secret
    headers: dict[str, str] = field(default_factory=dict)
    enabled: bool = True
    # Filters
    min_severity: str = "high"  # only fire for findings >= this severity
    min_score_drop: int = 0  # fire if score drops by this much


def _sign_payload(payload: bytes, secret: str) -> str:
    """Generate HMAC-SHA256 signature for webhook payload."""
    return hmac.new(secret.encode(), payload, hashlib.sha256).hexdigest()


def send_webhook(config: WebhookConfig, event: str, data: dict[str, Any]) -> bool:
    """Send a webhook notification. Returns True on success."""
    if not config.enabled:
        return False

    if event not in config.events:
        return False

    payload = json.dumps({
        "event": event,
        "timestamp": time.time(),
        "data": data,
        "source": "codetrust",
        "version": "0.5.0",
    }).encode("utf-8")

    headers = {
        "Content-Type": "application/json",
        "User-Agent": "CodeTrust-Webhook/0.5.0",
        **config.headers,
    }

    if config.secret:
        headers["X-CodeTrust-Signature"] = f"sha256={_sign_payload(payload, config.secret)}"

    req = urllib.request.Request(config.url, data=payload, headers=headers, method="POST")

    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            return resp.getcode() in (200, 201, 202, 204)
    except (urllib.error.URLError, urllib.error.HTTPError, TimeoutError):
        return False


def format_slack_message(result: TrustResult) -> dict[str, Any]:
    """Format scan result as a Slack Block Kit message."""
    score = result.score
    emoji = ":white_check_mark:" if score >= 90 else ":warning:" if score >= 50 else ":x:"
    color = "#22c55e" if score >= 90 else "#eab308" if score >= 50 else "#ef4444"

    critical = sum(1 for i in result.issues if i.severity == Severity.CRITICAL)
    high = sum(1 for i in result.issues if i.severity == Severity.HIGH)

    blocks = [
        {
            "type": "header",
            "text": {"type": "plain_text", "text": f"{emoji} CodeTrust Scan: {result.target}"}
        },
        {
            "type": "section",
            "fields": [
                {"type": "mrkdwn", "text": f"*Trust Score:* {score}/100"},
                {"type": "mrkdwn", "text": f"*Category:* {result.trust_category}"},
                {"type": "mrkdwn", "text": f"*Critical:* {critical}"},
                {"type": "mrkdwn", "text": f"*High:* {high}"},
                {"type": "mrkdwn", "text": f"*Total Issues:* {len(result.issues)}"},
                {"type": "mrkdwn", "text": f"*AI Tool:* {result.ai_tool}"},
            ],
        },
    ]

    # Add top 3 critical/high issues
    top_issues = [i for i in result.issues if i.severity in (Severity.CRITICAL, Severity.HIGH)][:3]
    if top_issues:
        issue_text = "\n".join(
            f"• *[{i.severity.value.upper()}]* {i.title}"
            + (f" ({i.cwe_id})" if i.cwe_id else "")
            for i in top_issues
        )
        blocks.append({
            "type": "section",
            "text": {"type": "mrkdwn", "text": f"*Top Issues:*\n{issue_text}"}
        })

    return {"blocks": blocks, "attachments": [{"color": color, "text": ""}]}


def format_teams_message(result: TrustResult) -> dict[str, Any]:
    """Format scan result as a Microsoft Teams Adaptive Card."""
    score = result.score
    color = "Good" if score >= 90 else "Warning" if score >= 50 else "Attention"

    return {
        "type": "message",
        "attachments": [{
            "contentType": "application/vnd.microsoft.card.adaptive",
            "content": {
                "$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
                "type": "AdaptiveCard",
                "version": "1.4",
                "body": [
                    {"type": "TextBlock", "text": f"CodeTrust Scan: {result.target}", "weight": "Bolder", "size": "Medium"},
                    {"type": "ColumnSet", "columns": [
                        {"type": "Column", "items": [{"type": "TextBlock", "text": f"**Score:** {score}/100"}]},
                        {"type": "Column", "items": [{"type": "TextBlock", "text": f"**Issues:** {len(result.issues)}"}]},
                        {"type": "Column", "items": [{"type": "TextBlock", "text": f"**Category:** {result.trust_category}"}]},
                    ]},
                ],
            },
        }],
    }


# ---------------------------------------------------------------------------
# OpenTelemetry Metrics Export
# ---------------------------------------------------------------------------

def to_otel_metrics(result: TrustResult) -> dict[str, Any]:
    """Convert scan result to OpenTelemetry-compatible metrics format.

    These metrics can be scraped by Prometheus, pushed to Grafana Cloud,
    or sent to any OTLP-compatible collector.
    """
    timestamp_ns = int(time.time() * 1e9)

    metrics = [
        {
            "name": "codetrust.trust_score",
            "description": "Trust score for scanned code (0-100)",
            "unit": "1",
            "gauge": {"dataPoints": [{"asDouble": result.score, "timeUnixNano": timestamp_ns, "attributes": [
                {"key": "target", "value": {"stringValue": result.target}},
                {"key": "ai_tool", "value": {"stringValue": result.ai_tool}},
                {"key": "category", "value": {"stringValue": result.trust_category}},
            ]}]},
        },
        {
            "name": "codetrust.issues_total",
            "description": "Total number of issues found",
            "unit": "1",
            "gauge": {"dataPoints": [{"asInt": str(len(result.issues)), "timeUnixNano": timestamp_ns}]},
        },
        {
            "name": "codetrust.issues_critical",
            "description": "Number of critical issues",
            "unit": "1",
            "gauge": {"dataPoints": [{"asInt": str(sum(1 for i in result.issues if i.severity == Severity.CRITICAL)), "timeUnixNano": timestamp_ns}]},
        },
    ]

    # Per-category scores
    for cat_name in ("correctness", "safety", "test_coverage", "dependency", "consistency", "hallucination"):
        score_val = getattr(result, f"{cat_name}_score", 100.0)
        metrics.append({
            "name": f"codetrust.category.{cat_name}",
            "description": f"Trust score for {cat_name} category",
            "unit": "1",
            "gauge": {"dataPoints": [{"asDouble": score_val, "timeUnixNano": timestamp_ns}]},
        })

    return {
        "resourceMetrics": [{
            "resource": {
                "attributes": [
                    {"key": "service.name", "value": {"stringValue": "codetrust"}},
                    {"key": "service.version", "value": {"stringValue": "0.5.0"}},
                ],
            },
            "scopeMetrics": [{
                "scope": {"name": "codetrust.scanner", "version": "0.5.0"},
                "metrics": metrics,
            }],
        }],
    }


def to_prometheus_metrics(result: TrustResult) -> str:
    """Export scan result as Prometheus text format.

    Can be scraped directly by Prometheus or Grafana Agent.
    Expose via GET /metrics endpoint.
    """
    lines = [
        "# HELP codetrust_trust_score Trust score for scanned code (0-100)",
        "# TYPE codetrust_trust_score gauge",
        f'codetrust_trust_score{{target="{result.target}",ai_tool="{result.ai_tool}",category="{result.trust_category}"}} {result.score}',
        "",
        "# HELP codetrust_issues_total Total number of issues found",
        "# TYPE codetrust_issues_total gauge",
        f"codetrust_issues_total {len(result.issues)}",
        "",
        "# HELP codetrust_issues_by_severity Issues grouped by severity",
        "# TYPE codetrust_issues_by_severity gauge",
    ]

    for sev in ("critical", "high", "medium", "low", "info"):
        count = sum(1 for i in result.issues if i.severity.value == sev)
        lines.append(f'codetrust_issues_by_severity{{severity="{sev}"}} {count}')

    lines.extend([
        "",
        "# HELP codetrust_category_score Per-category trust scores",
        "# TYPE codetrust_category_score gauge",
    ])

    for cat_name in ("correctness", "safety", "test_coverage", "dependency", "consistency", "hallucination"):
        score_val = getattr(result, f"{cat_name}_score", 100.0)
        lines.append(f'codetrust_category_score{{category="{cat_name}"}} {score_val}')

    return "\n".join(lines) + "\n"
