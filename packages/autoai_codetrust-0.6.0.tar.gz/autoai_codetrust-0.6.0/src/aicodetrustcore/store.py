"""SQLite persistence for trust scores, issues, and trend analysis."""

from __future__ import annotations

import json
import sqlite3
import uuid
import datetime
from pathlib import Path
from typing import Any

from .types import TrustIssue, TrustResult, IssueCategory, Severity


_SCHEMA = """
CREATE TABLE IF NOT EXISTS trust_scores (
    id TEXT PRIMARY KEY,
    target TEXT NOT NULL,
    score REAL NOT NULL,
    category TEXT NOT NULL,
    correctness_score REAL,
    safety_score REAL,
    test_coverage_score REAL,
    dependency_score REAL,
    consistency_score REAL,
    hallucination_score REAL,
    issues_json TEXT,
    ai_tool TEXT DEFAULT '',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_trust_target ON trust_scores(target);
CREATE INDEX IF NOT EXISTS idx_trust_created ON trust_scores(created_at);
CREATE INDEX IF NOT EXISTS idx_trust_ai_tool ON trust_scores(ai_tool);
"""


class TrustStore:
    """SQLite-backed store for trust score data."""

    def __init__(self, db_path: str | Path | None = None) -> None:
        if db_path is None:
            db_path = Path.home() / ".aicodetrustcore" / "trust_scores.db"
        self.db_path = Path(db_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._conn: sqlite3.Connection | None = None

    @property
    def conn(self) -> sqlite3.Connection:
        if self._conn is None:
            self._conn = sqlite3.connect(str(self.db_path), check_same_thread=False)
            self._conn.row_factory = sqlite3.Row
            self._conn.executescript(_SCHEMA)
        return self._conn

    def close(self) -> None:
        if self._conn:
            self._conn.close()
            self._conn = None

    def save_result(self, result: TrustResult) -> str:
        """Persist a trust result. Returns score ID."""
        score_id = f"ts-{uuid.uuid4().hex[:12]}"

        self.conn.execute(
            "INSERT INTO trust_scores (id, target, score, category, "
            "correctness_score, safety_score, test_coverage_score, "
            "dependency_score, consistency_score, hallucination_score, "
            "issues_json, ai_tool, created_at) "
            "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)",
            (
                score_id,
                result.target,
                result.score,
                result.trust_category,
                result.correctness_score,
                result.safety_score,
                result.test_coverage_score,
                result.dependency_score,
                result.consistency_score,
                result.hallucination_score,
                json.dumps([i.to_dict() for i in result.issues]),
                result.ai_tool,
                result.created_at,
            ),
        )
        self.conn.commit()
        return score_id

    def get_score(self, score_id: str) -> dict[str, Any] | None:
        """Get a trust score by ID."""
        row = self.conn.execute(
            "SELECT * FROM trust_scores WHERE id = ?", (score_id,)
        ).fetchone()
        if not row:
            return None
        return dict(row)

    def get_scores_for_target(
        self, target: str, limit: int = 20
    ) -> list[dict[str, Any]]:
        """Get trust score history for a target path."""
        rows = self.conn.execute(
            "SELECT * FROM trust_scores WHERE target = ? ORDER BY created_at DESC LIMIT ?",
            (target, limit),
        ).fetchall()
        return [dict(r) for r in rows]

    def get_recent_scores(self, limit: int = 20) -> list[dict[str, Any]]:
        """Get most recent trust scores across all targets."""
        rows = self.conn.execute(
            "SELECT * FROM trust_scores ORDER BY created_at DESC LIMIT ?", (limit,)
        ).fetchall()
        return [dict(r) for r in rows]

    def get_trend(self, target: str, limit: int = 10) -> dict[str, Any]:
        """Analyse trust score trend for a target."""
        rows = self.conn.execute(
            "SELECT score, category, correctness_score, safety_score, "
            "test_coverage_score, dependency_score, consistency_score, "
            "hallucination_score, ai_tool, created_at "
            "FROM trust_scores WHERE target = ? ORDER BY created_at DESC LIMIT ?",
            (target, limit),
        ).fetchall()

        if not rows:
            return {"target": target, "reviews": 0, "trend": "no_data", "data_points": []}

        data_points = [dict(r) for r in rows]
        scores = [r["score"] for r in data_points]

        if len(scores) < 2:
            trend = "insufficient_data"
        elif scores[0] > scores[-1]:
            trend = "improving"
        elif scores[0] < scores[-1]:
            trend = "degrading"
        else:
            trend = "stable"

        return {
            "target": target,
            "reviews": len(data_points),
            "trend": trend,
            "latest_score": scores[0],
            "oldest_score": scores[-1],
            "avg_score": round(sum(scores) / len(scores), 1),
            "data_points": data_points,
        }

    def get_benchmark_by_tool(self, limit: int = 100) -> dict[str, Any]:
        """Compare trust scores across different AI tools."""
        rows = self.conn.execute(
            "SELECT ai_tool, score, correctness_score, safety_score, "
            "test_coverage_score, dependency_score, consistency_score, "
            "hallucination_score FROM trust_scores "
            "WHERE ai_tool != '' ORDER BY created_at DESC LIMIT ?",
            (limit,),
        ).fetchall()

        if not rows:
            return {"benchmarks": {}, "total_scores": 0}

        by_tool: dict[str, list[dict]] = {}
        for r in rows:
            d = dict(r)
            by_tool.setdefault(d["ai_tool"], []).append(d)

        benchmarks: dict[str, Any] = {}
        for tool, entries in by_tool.items():
            scores = [e["score"] for e in entries]
            benchmarks[tool] = {
                "count": len(entries),
                "avg_score": round(sum(scores) / len(scores), 1),
                "min_score": min(scores),
                "max_score": max(scores),
                "avg_correctness": round(sum(e["correctness_score"] for e in entries) / len(entries), 1),
                "avg_safety": round(sum(e["safety_score"] for e in entries) / len(entries), 1),
                "avg_hallucination": round(sum(e["hallucination_score"] for e in entries) / len(entries), 1),
            }

        return {"benchmarks": benchmarks, "total_scores": len(rows)}
