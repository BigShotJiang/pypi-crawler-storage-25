"""AICodeTrustScore MCP Server -- exposes trust scoring tools via Model Context Protocol.

Tools:
- trust_score: Score a file or code snippet (0-100 trust)
- trust_diff: Score a git diff against codebase patterns
- trust_report: Full trust report for a directory
- trust_history: Show trust score trend over time
- trust_hallucination_check: Specifically check for AI hallucination patterns
- trust_benchmark: Compare trust scores across different AI tools
"""

from __future__ import annotations

import json
import uuid
from pathlib import Path
from typing import Any

from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import Tool, TextContent

from .analyzers import ALL_ANALYZERS
from .analyzers.hallucination import HallucinationAnalyzer
from .store import TrustStore
from .types import (
    TrustIssue,
    TrustResult,
    IssueCategory,
    score_to_trust_category,
    TRUST_CATEGORY_LABELS,
)


# File extensions we can analyse
_CODE_EXTENSIONS = {
    ".py", ".ts", ".tsx", ".js", ".jsx", ".go",
}


def _detect_ai_tool(content: str) -> str:
    """Try to detect which AI tool generated the code from comments/markers."""
    content_lower = content.lower()
    if "copilot" in content_lower or "github copilot" in content_lower:
        return "copilot"
    if "cursor" in content_lower:
        return "cursor"
    if "claude" in content_lower or "anthropic" in content_lower:
        return "claude"
    if "chatgpt" in content_lower or "openai" in content_lower:
        return "chatgpt"
    if "gemini" in content_lower or "google ai" in content_lower:
        return "gemini"
    if "codewhisperer" in content_lower:
        return "codewhisperer"
    return "unknown"


def _run_trust_score(
    target: str, store: TrustStore, ai_tool: str = ""
) -> dict[str, Any]:
    """Score a single file with all analyzers."""
    target_path = Path(target).resolve()
    if not target_path.exists():
        return {"error": f"File does not exist: {target}"}
    if not target_path.is_file():
        return {"error": f"Not a file: {target}"}
    if target_path.suffix not in _CODE_EXTENSIONS:
        return {"error": f"Unsupported file type: {target_path.suffix}. Supported: {', '.join(sorted(_CODE_EXTENSIONS))}"}

    try:
        content = target_path.read_text(encoding="utf-8", errors="replace")
    except OSError as e:
        return {"error": f"Cannot read file: {e}"}

    all_issues: list[TrustIssue] = []
    for analyzer_cls in ALL_ANALYZERS:
        all_issues.extend(analyzer_cls.analyze_file(target_path, content))

    detected_tool = ai_tool or _detect_ai_tool(content)

    result = TrustResult(
        target=str(target_path),
        issues=all_issues,
        ai_tool=detected_tool,
    )
    result.compute_score()
    store.save_result(result)
    return result.to_dict()


def _run_trust_score_snippet(
    code: str, language: str, store: TrustStore, ai_tool: str = ""
) -> dict[str, Any]:
    """Score a code snippet."""
    ext_map = {"python": ".py", "typescript": ".ts", "javascript": ".js", "go": ".go"}
    ext = ext_map.get(language.lower(), ".py")
    fake_path = Path(f"snippet{ext}")

    all_issues: list[TrustIssue] = []
    for analyzer_cls in ALL_ANALYZERS:
        all_issues.extend(analyzer_cls.analyze_file(fake_path, code))

    detected_tool = ai_tool or _detect_ai_tool(code)

    result = TrustResult(
        target=f"<snippet:{language}>",
        issues=all_issues,
        ai_tool=detected_tool,
    )
    result.compute_score()
    store.save_result(result)
    return result.to_dict()


def _run_trust_diff(
    diff_text: str, store: TrustStore, ai_tool: str = ""
) -> dict[str, Any]:
    """Score a git diff."""
    if not diff_text.strip():
        return {"error": "Empty diff provided"}

    all_issues: list[TrustIssue] = []
    current_file: str | None = None
    added_lines: list[str] = []

    for line in diff_text.splitlines():
        if line.startswith("+++ b/"):
            # Process previous file's added lines
            if current_file and added_lines:
                file_path = Path(current_file)
                if file_path.suffix in _CODE_EXTENSIONS:
                    added_content = "\n".join(added_lines)
                    for analyzer_cls in ALL_ANALYZERS:
                        issues = analyzer_cls.analyze_file(file_path, added_content)
                        for issue in issues:
                            issue.description = f"[IN DIFF] {issue.description}"
                        all_issues.extend(issues)
            current_file = line[6:]
            added_lines = []
        elif line.startswith("+") and not line.startswith("+++"):
            added_lines.append(line[1:])

    # Process last file
    if current_file and added_lines:
        file_path = Path(current_file)
        if file_path.suffix in _CODE_EXTENSIONS:
            added_content = "\n".join(added_lines)
            for analyzer_cls in ALL_ANALYZERS:
                issues = analyzer_cls.analyze_file(file_path, added_content)
                for issue in issues:
                    issue.description = f"[IN DIFF] {issue.description}"
                all_issues.extend(issues)

    result = TrustResult(
        target="git diff",
        issues=all_issues,
        ai_tool=ai_tool or "unknown",
    )
    result.compute_score()
    store.save_result(result)
    return result.to_dict()


def _run_trust_report(
    target: str, store: TrustStore
) -> dict[str, Any]:
    """Generate a full trust report for a directory."""
    target_path = Path(target).resolve()
    if not target_path.exists():
        return {"error": f"Path does not exist: {target}"}
    if not target_path.is_dir():
        return {"error": f"Not a directory: {target}"}

    all_issues: list[TrustIssue] = []
    file_scores: list[dict[str, Any]] = []

    for ext in _CODE_EXTENSIONS:
        for fp in target_path.rglob(f"*{ext}"):
            try:
                content = fp.read_text(encoding="utf-8", errors="replace")
            except (OSError, UnicodeDecodeError):
                continue

            file_issues: list[TrustIssue] = []
            for analyzer_cls in ALL_ANALYZERS:
                file_issues.extend(analyzer_cls.analyze_file(fp, content))

            file_result = TrustResult(target=str(fp), issues=file_issues)
            file_result.compute_score()
            file_scores.append({
                "file": str(fp.relative_to(target_path)),
                "score": file_result.score,
                "category": file_result.trust_category,
                "issues": len(file_issues),
            })
            all_issues.extend(file_issues)

    # Deduplicate
    seen: set[str] = set()
    unique: list[TrustIssue] = []
    for issue in all_issues:
        key = f"{issue.title}|{issue.file_path}|{issue.line_start}"
        if key not in seen:
            seen.add(key)
            unique.append(issue)

    result = TrustResult(target=str(target_path), issues=unique)
    result.compute_score()
    store.save_result(result)

    report = result.to_dict()

    # Sort by score ascending (worst offenders first)
    file_scores.sort(key=lambda x: x["score"])

    report["files_analyzed"] = len(file_scores)
    report["worst_offenders"] = file_scores[:10]
    report["avg_file_score"] = (
        round(sum(f["score"] for f in file_scores) / len(file_scores), 1)
        if file_scores else 100.0
    )

    # By category breakdown
    by_category: dict[str, int] = {}
    for issue in unique:
        by_category[issue.category.value] = by_category.get(issue.category.value, 0) + 1
    report["by_category"] = by_category

    return report


def _get_trust_history(
    target: str, store: TrustStore
) -> dict[str, Any]:
    """Get trust score history and trend."""
    target_path = str(Path(target).resolve())
    trend = store.get_trend(target_path)
    scores = store.get_scores_for_target(target_path, limit=20)

    return {
        "target": target_path,
        "trend": trend,
        "scores": [
            {
                "id": s["id"],
                "score": s["score"],
                "category": s["category"],
                "ai_tool": s["ai_tool"],
                "created_at": s["created_at"],
            }
            for s in scores
        ],
    }


def _run_hallucination_check(
    target: str, store: TrustStore
) -> dict[str, Any]:
    """Specifically check for AI hallucination patterns."""
    target_path = Path(target).resolve()

    if not target_path.exists():
        return {"error": f"Path does not exist: {target}"}

    all_issues: list[TrustIssue] = []

    if target_path.is_file():
        if target_path.suffix not in _CODE_EXTENSIONS:
            return {"error": f"Unsupported file type: {target_path.suffix}"}
        try:
            content = target_path.read_text(encoding="utf-8", errors="replace")
            all_issues.extend(HallucinationAnalyzer.analyze_file(target_path, content))
        except OSError as e:
            return {"error": f"Cannot read file: {e}"}
    else:
        for ext in _CODE_EXTENSIONS:
            for fp in target_path.rglob(f"*{ext}"):
                try:
                    content = fp.read_text(encoding="utf-8", errors="replace")
                    all_issues.extend(HallucinationAnalyzer.analyze_file(fp, content))
                except (OSError, UnicodeDecodeError):
                    continue

    result = TrustResult(target=str(target_path), issues=all_issues)
    result.compute_score()

    return {
        "target": str(target_path),
        "hallucination_score": result.hallucination_score,
        "total_hallucinations": len(all_issues),
        "hallucinations": [i.to_dict() for i in all_issues],
    }


def _get_benchmark(store: TrustStore) -> dict[str, Any]:
    """Compare trust scores across different AI tools."""
    return store.get_benchmark_by_tool()


def create_server(db_path: str | None = None) -> Server:
    """Create and configure the MCP server."""
    server = Server("aicodetrustcore")
    store = TrustStore(db_path)

    @server.list_tools()
    async def list_tools() -> list[Tool]:
        return [
            Tool(
                name="trust_score",
                description=(
                    "Score a file or code snippet for AI-generated code trust (0-100). "
                    "Analyses correctness, safety, test coverage, dependency risks, "
                    "consistency, and hallucination patterns. Returns breakdown by category."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "file_path": {
                            "type": "string",
                            "description": "Path to the file to score (use this OR code+language)",
                        },
                        "code": {
                            "type": "string",
                            "description": "Code snippet to score (use with language parameter)",
                        },
                        "language": {
                            "type": "string",
                            "description": "Language of the code snippet: python, typescript, javascript, go",
                            "enum": ["python", "typescript", "javascript", "go"],
                        },
                        "ai_tool": {
                            "type": "string",
                            "description": "Which AI tool generated this code (cursor, copilot, claude, chatgpt, unknown)",
                        },
                    },
                },
            ),
            Tool(
                name="trust_diff",
                description=(
                    "Score a git diff for trust. Analyses AI-generated changes against "
                    "correctness, safety, and hallucination patterns. Flags regressions."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "diff": {
                            "type": "string",
                            "description": "Git diff text (output of 'git diff')",
                        },
                        "ai_tool": {
                            "type": "string",
                            "description": "Which AI tool generated this code",
                        },
                    },
                    "required": ["diff"],
                },
            ),
            Tool(
                name="trust_report",
                description=(
                    "Full trust report for a directory. Analyses every code file, "
                    "returns average score, worst offenders, and breakdown by category."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "directory": {
                            "type": "string",
                            "description": "Path to the project directory to report on",
                        },
                    },
                    "required": ["directory"],
                },
            ),
            Tool(
                name="trust_history",
                description=(
                    "Show trust score trend over time. Answers: is AI output "
                    "getting better or worse for this target?"
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "target": {
                            "type": "string",
                            "description": "Path to the file or directory to check history for",
                        },
                    },
                    "required": ["target"],
                },
            ),
            Tool(
                name="trust_hallucination_check",
                description=(
                    "Specifically check for AI hallucination patterns: made-up APIs, "
                    "non-existent methods, phantom imports, fictional error codes, "
                    "and invented library features. The hallucination detector is "
                    "what makes AICodeTrustScore unique."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "target": {
                            "type": "string",
                            "description": "Path to file or directory to check for hallucinations",
                        },
                    },
                    "required": ["target"],
                },
            ),
            Tool(
                name="trust_benchmark",
                description=(
                    "Compare trust scores across different AI tools (Cursor, Copilot, "
                    "Claude, ChatGPT). Shows which tools produce the most trustworthy code "
                    "based on historical scores."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {},
                },
            ),
        ]

    @server.call_tool()
    async def call_tool(name: str, arguments: dict[str, Any]) -> list[TextContent]:
        if name == "trust_score":
            ai_tool = arguments.get("ai_tool", "")
            if "file_path" in arguments and arguments["file_path"]:
                result = _run_trust_score(arguments["file_path"], store, ai_tool)
            elif "code" in arguments and arguments["code"]:
                language = arguments.get("language", "python")
                result = _run_trust_score_snippet(arguments["code"], language, store, ai_tool)
            else:
                result = {"error": "Provide either file_path or code+language"}
            return [TextContent(type="text", text=json.dumps(result, indent=2))]

        elif name == "trust_diff":
            ai_tool = arguments.get("ai_tool", "")
            result = _run_trust_diff(arguments["diff"], store, ai_tool)
            return [TextContent(type="text", text=json.dumps(result, indent=2))]

        elif name == "trust_report":
            result = _run_trust_report(arguments["directory"], store)
            return [TextContent(type="text", text=json.dumps(result, indent=2))]

        elif name == "trust_history":
            result = _get_trust_history(arguments["target"], store)
            return [TextContent(type="text", text=json.dumps(result, indent=2))]

        elif name == "trust_hallucination_check":
            result = _run_hallucination_check(arguments["target"], store)
            return [TextContent(type="text", text=json.dumps(result, indent=2))]

        elif name == "trust_benchmark":
            result = _get_benchmark(store)
            return [TextContent(type="text", text=json.dumps(result, indent=2))]

        return [TextContent(type="text", text=f"Unknown tool: {name}")]

    return server


async def _run() -> None:
    """Run the MCP server over stdio."""
    server = create_server()
    async with stdio_server() as (read_stream, write_stream):
        await server.run(read_stream, write_stream, server.create_initialization_options())


def main() -> None:
    """Entry point for MCP server."""
    import asyncio
    asyncio.run(_run())
