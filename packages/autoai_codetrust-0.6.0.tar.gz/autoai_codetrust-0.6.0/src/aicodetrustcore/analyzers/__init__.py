"""AICodeTrustScore analyzers -- each module detects a specific class of trust issue."""

from __future__ import annotations

from .correctness import CorrectnessAnalyzer
from .safety import SafetyAnalyzer
from .test_coverage import TestCoverageAnalyzer
from .dependency import DependencyAnalyzer
from .consistency import ConsistencyAnalyzer
from .hallucination import HallucinationAnalyzer
from .sca import SCAAnalyzer

# Analyzers that run on every code file
ALL_ANALYZERS = [
    CorrectnessAnalyzer,
    SafetyAnalyzer,
    TestCoverageAnalyzer,
    DependencyAnalyzer,
    ConsistencyAnalyzer,
    HallucinationAnalyzer,
]

# SCA runs on manifest files only (requirements.txt, package.json, go.mod)
# Use SCAAnalyzer.scan_project(dir) for dependency vulnerability scanning

__all__ = [
    "CorrectnessAnalyzer",
    "SafetyAnalyzer",
    "TestCoverageAnalyzer",
    "DependencyAnalyzer",
    "ConsistencyAnalyzer",
    "HallucinationAnalyzer",
    "SCAAnalyzer",
    "ALL_ANALYZERS",
]
