"""Test coverage analyzer -- identifies untested code paths in AI-generated code.

Checks:
- Functions without corresponding tests
- Edge cases not covered (null, empty, boundary values)
- Error paths not tested
- Missing integration tests for API endpoints
- Mocked dependencies that should be tested for real
"""

from __future__ import annotations

import re
from pathlib import Path

from ..types import TrustIssue, IssueCategory, Severity


_CODE_EXTENSIONS = {".py", ".ts", ".tsx", ".js", ".jsx", ".go"}


class TestCoverageAnalyzer:
    """Detects test coverage gaps in AI-generated code."""

    name = "test_coverage"

    @classmethod
    def analyze_file(cls, file_path: Path, content: str) -> list[TrustIssue]:
        """Analyse a file for test coverage gaps."""
        findings: list[TrustIssue] = []

        if file_path.suffix not in _CODE_EXTENSIONS:
            return findings

        # Skip if this IS a test file
        path_str = str(file_path).lower()
        if any(x in path_str for x in ["test_", "_test.", ".test.", ".spec.", "tests/"]):
            return findings

        lines = content.splitlines()
        rel_path = str(file_path)

        # Extract function/method definitions
        functions = cls._extract_functions(file_path, content, lines)

        # Check for corresponding test file
        test_content = cls._find_test_content(file_path)

        for func_name, func_line, func_body in functions:
            # Check if function has a corresponding test
            if test_content is not None:
                if f"test_{func_name}" not in test_content and func_name not in test_content:
                    findings.append(TrustIssue(
                        analyzer=cls.name,
                        category=IssueCategory.TEST_COVERAGE,
                        severity=Severity.MEDIUM,
                        title=f"Function '{func_name}' has no test",
                        description=f"No test found for function '{func_name}'. AI-generated functions should have tests.",
                        file_path=rel_path,
                        line_start=func_line,
                        suggestion=f"Add a test_  function covering the happy path and edge cases.",
                    ))
            elif test_content is None and len(functions) > 0:
                # No test file at all -- report once
                pass  # We'll report this at the end

            # Check for error handling without test coverage
            if re.search(r'(?:try|except|raise|throw|catch)', func_body):
                if test_content and f"test_{func_name}" in test_content:
                    # Test exists but check if error paths are tested
                    test_section = cls._extract_test_section(test_content, func_name)
                    if test_section and not re.search(
                        r'(?:raises|pytest\.raises|assertRaises|expect.*throw|expect.*reject|toThrow)',
                        test_section,
                    ):
                        findings.append(TrustIssue(
                            analyzer=cls.name,
                            category=IssueCategory.TEST_COVERAGE,
                            severity=Severity.LOW,
                            title=f"Error paths not tested for '{func_name}'",
                            description=f"Function '{func_name}' has error handling but tests don't cover error paths.",
                            file_path=rel_path,
                            line_start=func_line,
                            suggestion="Add tests using pytest.raises() or expect().toThrow() for error scenarios.",
                        ))

        # Check for API endpoints without integration tests
        findings.extend(cls._check_api_endpoints(file_path, content, lines, test_content))

        # No test file at all
        if test_content is None and len(functions) >= 3:
            findings.append(TrustIssue(
                analyzer=cls.name,
                category=IssueCategory.TEST_COVERAGE,
                severity=Severity.HIGH,
                title=f"No test file found for {file_path.name}",
                description=f"File has {len(functions)} functions but no corresponding test file.",
                file_path=rel_path,
                line_start=1,
                suggestion=f"Create a test file (test_{file_path.name} or {file_path.stem}.test{file_path.suffix}).",
            ))

        return findings

    @classmethod
    def _extract_functions(
        cls, file_path: Path, content: str, lines: list[str]
    ) -> list[tuple[str, int, str]]:
        """Extract (name, line_number, body) for each function/method."""
        functions: list[tuple[str, int, str]] = []

        if file_path.suffix == ".py":
            pattern = re.compile(r'^(\s*)def\s+(\w+)\s*\(')
        elif file_path.suffix in {".ts", ".tsx", ".js", ".jsx"}:
            pattern = re.compile(r'(?:function\s+(\w+)|(?:const|let|var)\s+(\w+)\s*=\s*(?:async\s+)?(?:function|\())')
        elif file_path.suffix == ".go":
            pattern = re.compile(r'^func\s+(?:\(\w+\s+\*?\w+\)\s+)?(\w+)\s*\(')
        else:
            return functions

        func_starts: list[tuple[str, int]] = []
        for i, line in enumerate(lines, 1):
            m = pattern.match(line) if file_path.suffix in {".py", ".go"} else pattern.search(line)
            if m:
                name = next((g for g in m.groups() if g), None)
                if name and not name.startswith("_"):
                    func_starts.append((name, i))

        # Extract bodies (approximate: from func start to next func start)
        for idx, (name, start_line) in enumerate(func_starts):
            if idx + 1 < len(func_starts):
                end_line = func_starts[idx + 1][1] - 1
            else:
                end_line = len(lines)
            body = "\n".join(lines[start_line - 1:end_line])
            functions.append((name, start_line, body))

        return functions

    @classmethod
    def _find_test_content(cls, file_path: Path) -> str | None:
        """Try to find and read the corresponding test file."""
        stem = file_path.stem
        parent = file_path.parent

        # Common test file locations
        candidates = [
            parent / f"test_{file_path.name}",
            parent / "tests" / f"test_{file_path.name}",
            parent.parent / "tests" / f"test_{file_path.name}",
            parent / f"{stem}.test{file_path.suffix}",
            parent / f"{stem}.spec{file_path.suffix}",
            parent / "__tests__" / file_path.name,
        ]

        for candidate in candidates:
            if candidate.exists() and candidate.is_file():
                try:
                    return candidate.read_text(encoding="utf-8", errors="replace")
                except OSError:
                    continue

        return None

    @classmethod
    def _extract_test_section(cls, test_content: str, func_name: str) -> str | None:
        """Extract the test section related to a specific function."""
        pattern = re.compile(
            rf'(?:def\s+test_{func_name}|test\s*\(\s*["\'].*{func_name})',
            re.IGNORECASE,
        )
        match = pattern.search(test_content)
        if not match:
            return None
        # Return ~50 lines after the match
        start = match.start()
        return test_content[start:start + 2000]

    @classmethod
    def _check_api_endpoints(
        cls,
        file_path: Path,
        content: str,
        lines: list[str],
        test_content: str | None,
    ) -> list[TrustIssue]:
        """Detect API endpoints without integration tests."""
        findings: list[TrustIssue] = []
        rel_path = str(file_path)

        route_patterns = [
            re.compile(r'@(?:app|router|api)\.(?:get|post|put|delete|patch)\s*\('),
            re.compile(r'@(?:app|blueprint)\.route\s*\('),
            re.compile(r'app\.(?:get|post|put|delete|patch)\s*\('),
        ]

        endpoint_count = 0
        for i, line in enumerate(lines, 1):
            for rp in route_patterns:
                if rp.search(line):
                    endpoint_count += 1
                    break

        if endpoint_count > 0 and test_content:
            # Check for integration test patterns
            has_integration_tests = any(kw in test_content for kw in [
                "TestClient", "client.get", "client.post",
                "request(app)", "supertest", "httptest",
            ])
            if not has_integration_tests:
                findings.append(TrustIssue(
                    analyzer=cls.name,
                    category=IssueCategory.TEST_COVERAGE,
                    severity=Severity.MEDIUM,
                    title=f"{endpoint_count} API endpoints without integration tests",
                    description=f"File has {endpoint_count} API endpoints but tests don't use HTTP client testing.",
                    file_path=rel_path,
                    line_start=1,
                    suggestion="Use TestClient (FastAPI), pytest-flask, or supertest for integration tests.",
                ))

        return findings
