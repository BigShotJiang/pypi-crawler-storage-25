"""Software Composition Analysis (SCA) — scans dependencies for known CVEs.

Uses the OSV.dev API (free, open-source vulnerability database by Google)
to check if project dependencies have known security vulnerabilities.

Supports:
- Python (requirements.txt, pyproject.toml, Pipfile)
- JavaScript/TypeScript (package.json)
- Go (go.mod)

Standards:
- CVE IDs from NVD (National Vulnerability Database)
- GHSA IDs from GitHub Security Advisories
- OSV format (https://osv.dev/docs/)
"""

from __future__ import annotations

import json
import re
import urllib.request
import urllib.error
from pathlib import Path
from typing import Any

from ..types import TrustIssue, IssueCategory, Severity

# OSV.dev API endpoint (free, no auth required)
_OSV_API = "https://api.osv.dev/v1/query"

# Severity mapping from CVSS to our severity
_CVSS_TO_SEVERITY = {
    "CRITICAL": Severity.CRITICAL,
    "HIGH": Severity.HIGH,
    "MODERATE": Severity.MEDIUM,
    "MEDIUM": Severity.MEDIUM,
    "LOW": Severity.LOW,
}


def _parse_requirements_txt(content: str) -> list[dict[str, str]]:
    """Parse requirements.txt into package/version pairs."""
    deps = []
    for line in content.splitlines():
        line = line.strip()
        if not line or line.startswith("#") or line.startswith("-"):
            continue
        # Handle: package==1.2.3, package>=1.2.3, package~=1.2.3
        match = re.match(r'^([a-zA-Z0-9_\-\.]+)\s*[=~><]=?\s*([0-9][0-9a-zA-Z\.\-\*]*)', line)
        if match:
            deps.append({"name": match.group(1).lower(), "version": match.group(2), "ecosystem": "PyPI"})
    return deps


def _parse_pyproject_toml(content: str) -> list[dict[str, str]]:
    """Parse pyproject.toml dependencies (basic parser, no TOML lib required)."""
    deps = []
    in_deps = False
    for line in content.splitlines():
        stripped = line.strip()
        if stripped in ("dependencies = [", "[project.dependencies]"):
            in_deps = True
            continue
        if in_deps:
            if stripped.startswith("]") or (stripped.startswith("[") and not stripped.startswith('"')):
                in_deps = False
                continue
            # Match: "package>=1.2.3" or "package==1.2.3"
            match = re.search(r'"([a-zA-Z0-9_\-\.]+)\s*[><=~!]*\s*([0-9][0-9a-zA-Z\.\-\*]*)', stripped)
            if match:
                deps.append({"name": match.group(1).lower(), "version": match.group(2), "ecosystem": "PyPI"})
    return deps


def _parse_package_json(content: str) -> list[dict[str, str]]:
    """Parse package.json dependencies."""
    deps = []
    try:
        data = json.loads(content)
    except json.JSONDecodeError:
        return deps

    for section in ("dependencies", "devDependencies"):
        for name, version in data.get(section, {}).items():
            # Strip ^, ~, >=, etc.
            clean = re.sub(r'^[\^~>=<]+', '', version)
            if clean and clean[0].isdigit():
                deps.append({"name": name, "version": clean, "ecosystem": "npm"})
    return deps


def _parse_go_mod(content: str) -> list[dict[str, str]]:
    """Parse go.mod require section."""
    deps = []
    in_require = False
    for line in content.splitlines():
        stripped = line.strip()
        if stripped == "require (":
            in_require = True
            continue
        if in_require:
            if stripped == ")":
                in_require = False
                continue
            parts = stripped.split()
            if len(parts) >= 2:
                deps.append({"name": parts[0], "version": parts[1].lstrip("v"), "ecosystem": "Go"})
    return deps


def _query_osv(package: str, version: str, ecosystem: str) -> list[dict[str, Any]]:
    """Query OSV.dev for vulnerabilities affecting a specific package version."""
    payload = json.dumps({
        "version": version,
        "package": {
            "name": package,
            "ecosystem": ecosystem,
        },
    }).encode("utf-8")

    req = urllib.request.Request(
        _OSV_API,
        data=payload,
        headers={"Content-Type": "application/json"},
        method="POST",
    )

    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            data = json.loads(resp.read().decode())
            return data.get("vulns", [])
    except (urllib.error.URLError, urllib.error.HTTPError, TimeoutError, json.JSONDecodeError):
        return []


def _vuln_to_issue(
    vuln: dict[str, Any],
    package: str,
    version: str,
    ecosystem: str,
    manifest_path: str,
) -> TrustIssue:
    """Convert an OSV vulnerability to a TrustIssue."""
    vuln_id = vuln.get("id", "UNKNOWN")
    summary = vuln.get("summary", "No description available")
    aliases = vuln.get("aliases", [])

    # Get CVE ID if available
    cve_id = ""
    for alias in aliases:
        if alias.startswith("CVE-"):
            cve_id = alias
            break

    # Determine severity from database_specific or severity field
    severity = Severity.MEDIUM  # default
    for sev_entry in vuln.get("severity", []):
        score_str = sev_entry.get("score", "")
        if score_str:
            try:
                score = float(score_str)
                if score >= 9.0:
                    severity = Severity.CRITICAL
                elif score >= 7.0:
                    severity = Severity.HIGH
                elif score >= 4.0:
                    severity = Severity.MEDIUM
                else:
                    severity = Severity.LOW
            except ValueError:
                pass

    # Check database_specific for GitHub severity
    db_specific = vuln.get("database_specific", {})
    gh_severity = db_specific.get("severity", "").upper()
    if gh_severity in _CVSS_TO_SEVERITY:
        severity = _CVSS_TO_SEVERITY[gh_severity]

    # Get fixed version if available
    fix_version = ""
    for affected in vuln.get("affected", []):
        for range_entry in affected.get("ranges", []):
            for event in range_entry.get("events", []):
                if "fixed" in event:
                    fix_version = event["fixed"]

    suggestion = f"Upgrade {package} to >={fix_version}" if fix_version else f"Check {vuln_id} for remediation guidance"

    return TrustIssue(
        analyzer="sca",
        category=IssueCategory.DEPENDENCY,
        severity=severity,
        title=f"Known vulnerability in {package}=={version} ({vuln_id})",
        description=f"{summary}. Affects {package} {version} ({ecosystem}).",
        file_path=manifest_path,
        line_start=1,
        suggestion=suggestion,
        cwe_id=cve_id,
        confidence=1.0,  # CVE database match = 100% confidence
        standard=f"NVD {cve_id}" if cve_id else f"OSV {vuln_id}",
    )


class SCAAnalyzer:
    """Software Composition Analysis — checks dependencies for known CVEs."""

    name = "sca"

    # Manifest files we know how to parse
    _MANIFEST_PARSERS = {
        "requirements.txt": _parse_requirements_txt,
        "pyproject.toml": _parse_pyproject_toml,
        "package.json": _parse_package_json,
        "go.mod": _parse_go_mod,
    }

    @classmethod
    def analyze_file(cls, file_path: Path, content: str) -> list[TrustIssue]:
        """Analyze a manifest file for vulnerable dependencies."""
        findings: list[TrustIssue] = []

        filename = file_path.name
        parser = cls._MANIFEST_PARSERS.get(filename)
        if not parser:
            return findings

        deps = parser(content)
        if not deps:
            return findings

        # Query OSV for each dependency (batch would be better but keep it simple)
        for dep in deps:
            vulns = _query_osv(dep["name"], dep["version"], dep["ecosystem"])
            for vuln in vulns:
                findings.append(_vuln_to_issue(
                    vuln, dep["name"], dep["version"], dep["ecosystem"], str(file_path),
                ))

        return findings

    @classmethod
    def scan_project(cls, project_dir: Path) -> list[TrustIssue]:
        """Scan a project directory for all manifest files."""
        findings: list[TrustIssue] = []

        for manifest_name in cls._MANIFEST_PARSERS:
            manifest_path = project_dir / manifest_name
            if manifest_path.exists():
                try:
                    content = manifest_path.read_text(encoding="utf-8", errors="replace")
                    findings.extend(cls.analyze_file(manifest_path, content))
                except OSError:
                    continue

        return findings
