"""SARIF (Static Analysis Results Interchange Format) output for CodeTrust.

Generates SARIF v2.1.0 output compatible with:
- GitHub Code Scanning
- VS Code SARIF Viewer
- Azure DevOps
- Any SARIF-compatible tool

Spec: https://docs.oasis-open.org/sarif/sarif/v2.1.0/sarif-v2.1.0.html
"""

from __future__ import annotations

import json
from typing import Any

from .types import TrustResult, TrustIssue, Severity

# Map our severity to SARIF level
_SARIF_LEVEL = {
    Severity.CRITICAL: "error",
    Severity.HIGH: "error",
    Severity.MEDIUM: "warning",
    Severity.LOW: "note",
    Severity.INFO: "note",
}

# Map our severity to SARIF security-severity (for GitHub Code Scanning)
_SECURITY_SEVERITY = {
    Severity.CRITICAL: "9.5",
    Severity.HIGH: "8.0",
    Severity.MEDIUM: "5.5",
    Severity.LOW: "3.0",
    Severity.INFO: "1.0",
}


def result_to_sarif(result: TrustResult) -> dict[str, Any]:
    """Convert a TrustResult to SARIF v2.1.0 format.

    Returns a complete SARIF log object ready for json.dumps().
    """
    rules: list[dict[str, Any]] = []
    rule_ids_seen: set[str] = set()
    results: list[dict[str, Any]] = []

    for issue in result.issues:
        rule_id = _make_rule_id(issue)

        # Add rule definition (deduplicated)
        if rule_id not in rule_ids_seen:
            rule_ids_seen.add(rule_id)
            rule_def: dict[str, Any] = {
                "id": rule_id,
                "name": _pascal_case(issue.title),
                "shortDescription": {"text": issue.title},
                "fullDescription": {"text": issue.description},
                "defaultConfiguration": {
                    "level": _SARIF_LEVEL.get(issue.severity, "warning"),
                },
                "properties": {
                    "tags": [issue.category.value, issue.analyzer],
                    "security-severity": _SECURITY_SEVERITY.get(issue.severity, "5.0"),
                },
            }
            if issue.cwe_id:
                rule_def["properties"]["tags"].append(issue.cwe_id)
            if issue.standard:
                rule_def["helpUri"] = f"https://cwe.mitre.org/data/definitions/{issue.cwe_id.replace('CWE-', '')}.html" if issue.cwe_id else ""
                rule_def["help"] = {
                    "text": f"{issue.standard}. {issue.suggestion}" if issue.suggestion else issue.standard,
                    "markdown": f"**{issue.standard}**\n\n{issue.suggestion}" if issue.suggestion else issue.standard,
                }
            rules.append(rule_def)

        # Add result
        sarif_result: dict[str, Any] = {
            "ruleId": rule_id,
            "ruleIndex": _get_rule_index(rules, rule_id),
            "level": _SARIF_LEVEL.get(issue.severity, "warning"),
            "message": {
                "text": issue.description,
            },
            "locations": [
                {
                    "physicalLocation": {
                        "artifactLocation": {
                            "uri": _normalize_path(issue.file_path),
                            "uriBaseId": "%SRCROOT%",
                        },
                        "region": {
                            "startLine": max(1, issue.line_start),
                            "endLine": max(1, issue.line_end or issue.line_start),
                        },
                    },
                },
            ],
        }

        if issue.suggestion:
            sarif_result["fixes"] = [
                {
                    "description": {"text": issue.suggestion},
                },
            ]

        if issue.confidence < 1.0:
            sarif_result["properties"] = {
                "confidence": issue.confidence,
            }

        results.append(sarif_result)

    sarif_log = {
        "$schema": "https://raw.githubusercontent.com/oasis-tcs/sarif-spec/main/sarif-2.1/schema/sarif-schema-2.1.0.json",
        "version": "2.1.0",
        "runs": [
            {
                "tool": {
                    "driver": {
                        "name": "CodeTrust",
                        "organization": "AutoAI Labs",
                        "version": "0.3.0",
                        "informationUri": "https://pypi.org/project/autoai-codetrust/",
                        "rules": rules,
                        "properties": {
                            "trustScore": result.score,
                            "trustCategory": result.trust_category,
                        },
                    },
                },
                "results": results,
                "columnKind": "utf16CodeUnits",
            },
        ],
    }

    return sarif_log


def to_sarif_json(result: TrustResult, indent: int = 2) -> str:
    """Convert TrustResult to SARIF JSON string."""
    return json.dumps(result_to_sarif(result), indent=indent)


def _make_rule_id(issue: TrustIssue) -> str:
    """Generate a stable rule ID from the issue."""
    base = issue.title.lower().replace(" ", "-").replace("/", "-")
    # Remove non-alphanumeric except dashes
    base = "".join(c for c in base if c.isalnum() or c == "-")
    if issue.cwe_id:
        return f"CT/{issue.cwe_id}/{base}"
    return f"CT/{issue.category.value}/{base}"


def _pascal_case(text: str) -> str:
    """Convert to PascalCase for SARIF rule names."""
    return "".join(word.capitalize() for word in text.split())


def _normalize_path(path: str) -> str:
    """Normalize file path for SARIF (forward slashes, relative)."""
    path = path.replace("\\", "/")
    # Remove absolute path prefixes
    for prefix in ("C:/", "/home/", "/Users/"):
        if prefix in path:
            # Take the path after the last known project marker
            for marker in ("/src/", "/core/", "/products/"):
                if marker in path:
                    path = path[path.index(marker) + 1:]
                    break
    return path


def _get_rule_index(rules: list[dict], rule_id: str) -> int:
    """Find the index of a rule by ID."""
    for i, r in enumerate(rules):
        if r["id"] == rule_id:
            return i
    return 0
