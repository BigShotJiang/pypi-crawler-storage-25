"""Import of tasks is directly from package by convention"""

from dkist_processing_ops.tasks.read_memory_leak import *
from dkist_processing_ops.tasks.smoke import *
from dkist_processing_ops.tasks.wait import *

# Not used directly, but ensures that the common_configurations are logged early in a task run
from dkist_processing_ops.config import dkist_processing_ops_configurations  # isort: skip
