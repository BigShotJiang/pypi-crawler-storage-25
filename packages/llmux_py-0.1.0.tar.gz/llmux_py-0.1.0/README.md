# llmux

llmux is a lightweight, unified Python library for interacting with multiple LLM providers using a consistent and simple interface.

## Installation

```bash
pip install llmux-py
```

For providers with specific SDK requirements, install the optional dependencies:

```bash
pip install "llmux-py[gemini]"   # For Google Gemini
pip install "llmux-py[bedrock]"  # For AWS Bedrock
pip install "llmux-py[all]"      # For all supported SDKs
```

## Supported Providers & Environment Variables

| Provider | `provider` name | Environment Variable | Default Model |
| :--- | :--- | :--- | :--- |
| **Google Gemini** | `gemini` | `GEMINI_API_KEY` | `gemini-2.0-pro-exp-02-05` |
| **OpenAI** | `openai` | `OPENAI_API_KEY` | `gpt-4o` |
| **Anthropic** | `anthropic` | `ANTHROPIC_API_KEY` | `claude-3-7-sonnet-latest` |
| **Groq** | `groq` | `GROQ_API_KEY` | `llama-3.3-70b-versatile` |
| **Mistral** | `mistral` | `MISTRAL_API_KEY` | `mistral-large-latest` |
| **DeepSeek** | `deepseek` | `DEEPSEEK_API_KEY` | `deepseek-chat` |
| **Together AI** | `together` | `TOGETHER_API_KEY` | `meta-llama/Llama-3.3-70B-Instruct-Turbo` |
| **OpenRouter** | `openrouter` | `OPENROUTER_API_KEY` | `meta-llama/llama-3.1-70b-instruct` |
| **Fireworks AI** | `fireworks` | `FIREWORKS_API_KEY` | `accounts/fireworks/models/llama-v3p1-70b-instruct` |
| **Perplexity** | `perplexity` | `PERPLEXITY_API_KEY` | `llama-3.1-sonar-large-128k-online` |
| **Ollama** | `ollama` | N/A | `llama3` |
| **AWS Bedrock** | `bedrock` | `AWS_REGION` | `amazon.titan-text-premier-v1:0` |

## Usage

### Basic Example

```python
import llmux

# Initialize using specific parameters
provider = llmux.init(
    provider="openai", 
    model="gpt-4o", 
    api_key="sk-..."
)

# Generate text
response = provider.generate_text(llmux.LLMRequest(prompt="Write a 10-line poem about rain."))
print(response)
```

### Using Environment Variables

You can configure `llmux` globally using `LLMUX_PROVIDER` and `LLMUX_MODEL`.

```bash
export LLMUX_PROVIDER="groq"
export GROQ_API_KEY="gsk_..."
```

```python
import llmux

# Automatically uses environment variables
provider = llmux.init()
response = provider.generate_text(llmux.LLMRequest(prompt="Explain quantum physics in one sentence."))
```

### Local Models with Ollama

```python
import llmux

provider = llmux.init(
    provider="ollama", 
    model="llama3.2", 
    base_url="http://localhost:11434"
)
response = provider.generate_text(llmux.LLMRequest(prompt="Who are you?"))
```

### Advanced Configuration

```python
request = llmux.LLMRequest(
    prompt="Generate a JSON list of 5 fruits.",
    temperature=0.7,
    max_retries=5
)
```

## Error Handling

```python
from llmux import init, LLMProviderError

try:
    provider = init(provider="openai")
    response = provider.generate_text(...)
except LLMProviderError as e:
    print(f"Provider error: {e}")
```
