import os
from typing import Optional
from llmux.base import BaseLLMProvider, LLMProviderError
from llmux.providers.gemini import GeminiLLMProvider
from llmux.providers.openai import OpenAILLMProvider
from llmux.providers.anthropic import AnthropicLLMProvider
from llmux.providers.bedrock import BedrockLLMProvider
from llmux.providers.groq import GroqLLMProvider
from llmux.providers.mistral import MistralLLMProvider
from llmux.providers.deepseek import DeepSeekLLMProvider
from llmux.providers.together import TogetherLLMProvider
from llmux.providers.ollama import OllamaLLMProvider
from llmux.providers.openai_compatible import OpenAICompatibleProvider

def init(
    provider: Optional[str] = None,
    model: Optional[str] = None,
    api_key: Optional[str] = None,
    base_url: Optional[str] = None,
) -> BaseLLMProvider:
    """
    Initializes an LLM provider.
    
    Args:
        provider: The name of the provider (e.g., 'gemini', 'openai', 'anthropic', 'bedrock', 'groq', 'mistral', 'deepseek', 'together', 'ollama', 'openrouter', 'fireworks', 'perplexity').
        model: The name of the model to use.
        api_key: The API key for the provider. If not provided, it will look for environment variables.
        base_url: Optional base URL for the provider (used by Ollama and custom providers).
        
    Returns:
        An instance of a BaseLLMProvider subclass.
    """
    normalized_provider = (provider or os.environ.get("LLMUX_PROVIDER") or "gemini").strip().lower()
    configured_model_name = model or os.environ.get("LLMUX_MODEL")

    if normalized_provider == "gemini":
        return GeminiLLMProvider(configured_model_name or "gemini-2.0-pro-exp-02-05", api_key)
    if normalized_provider == "openai":
        return OpenAILLMProvider(configured_model_name or "gpt-4o", api_key)
    if normalized_provider in {"anthropic", "claude"}:
        return AnthropicLLMProvider(configured_model_name or "claude-3-7-sonnet-latest", api_key)
    if normalized_provider == "bedrock":
        return BedrockLLMProvider(configured_model_name or "amazon.titan-text-premier-v1:0", api_key=api_key)
    if normalized_provider == "groq":
        return GroqLLMProvider(configured_model_name or "llama-3.3-70b-versatile", api_key)
    if normalized_provider == "mistral":
        return MistralLLMProvider(configured_model_name or "mistral-large-latest", api_key)
    if normalized_provider == "deepseek":
        return DeepSeekLLMProvider(configured_model_name or "deepseek-chat", api_key)
    if normalized_provider == "together":
        return TogetherLLMProvider(configured_model_name or "meta-llama/Llama-3.3-70B-Instruct-Turbo", api_key)
    if normalized_provider == "ollama":
        return OllamaLLMProvider(configured_model_name or "llama3", base_url or "http://localhost:11434")
    if normalized_provider == "openrouter":
        return OpenAICompatibleProvider(
            model_name=configured_model_name or "meta-llama/llama-3.1-70b-instruct",
            api_key=api_key or os.environ.get("OPENROUTER_API_KEY"),
            base_url="https://openrouter.ai/api/v1",
            provider_name="openrouter"
        )
    if normalized_provider == "fireworks":
        return OpenAICompatibleProvider(
            model_name=configured_model_name or "accounts/fireworks/models/llama-v3p1-70b-instruct",
            api_key=api_key or os.environ.get("FIREWORKS_API_KEY"),
            base_url="https://api.fireworks.ai/inference/v1",
            provider_name="fireworks"
        )
    if normalized_provider == "perplexity":
        return OpenAICompatibleProvider(
            model_name=configured_model_name or "llama-3.1-sonar-large-128k-online",
            api_key=api_key or os.environ.get("PERPLEXITY_API_KEY"),
            base_url="https://api.perplexity.ai",
            provider_name="perplexity"
        )

    raise LLMProviderError(f"Unsupported LLM provider: {normalized_provider}")
