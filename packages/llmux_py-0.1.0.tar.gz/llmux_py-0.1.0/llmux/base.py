from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Optional

class LLMProviderError(RuntimeError):
    pass

@dataclass(frozen=True)
class LLMRequest:
    prompt: str
    temperature: float = 0.2
    max_retries: int = 3

class BaseLLMProvider(ABC):
    def __init__(self, model_name: str, api_key: Optional[str] = None):
        self.model_name = model_name
        self.api_key = api_key

    @property
    @abstractmethod
    def provider_name(self) -> str:
        raise NotImplementedError

    @abstractmethod
    def is_available(self) -> bool:
        raise NotImplementedError

    @abstractmethod
    def generate_text(self, request: LLMRequest) -> str:
        raise NotImplementedError

    def _retry_delay(self, attempt: int) -> float:
        return float(2 ** attempt)
