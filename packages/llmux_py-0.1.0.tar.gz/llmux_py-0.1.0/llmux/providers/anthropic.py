import os
import time
from typing import Optional
from llmux.base import BaseLLMProvider, LLMRequest, LLMProviderError

class AnthropicLLMProvider(BaseLLMProvider):
    def __init__(self, model_name: str, api_key: Optional[str] = None):
        super().__init__(model_name, api_key or os.environ.get("ANTHROPIC_API_KEY"))

    @property
    def provider_name(self) -> str:
        return "anthropic"

    def is_available(self) -> bool:
        return bool(self.api_key)

    def generate_text(self, request: LLMRequest) -> str:
        if not self.api_key:
            raise LLMProviderError("ANTHROPIC_API_KEY is not configured.")

        try:
            import httpx
        except ImportError as exc:
            raise LLMProviderError("httpx is required for the Anthropic provider.") from exc

        payload = {
            "model": self.model_name,
            "max_tokens": 4096,
            "messages": [{"role": "user", "content": request.prompt}],
            "temperature": request.temperature,
        }
        headers = {
            "x-api-key": self.api_key,
            "anthropic-version": "2023-06-01",
            "Content-Type": "application/json",
        }

        last_error: Optional[Exception] = None
        for attempt in range(request.max_retries):
            try:
                response = httpx.post(
                    "https://api.anthropic.com/v1/messages",
                    headers=headers,
                    json=payload,
                    timeout=60.0,
                )
                response.raise_for_status()
                body = response.json()
                parts = []
                for item in body.get("content", []):
                    if item.get("type") == "text" and item.get("text"):
                        parts.append(item["text"])
                return "\n".join(parts).strip()
            except Exception as exc:
                last_error = exc
                if attempt < request.max_retries - 1:
                    time.sleep(self._retry_delay(attempt))
                    continue
                break

        raise LLMProviderError(f"Anthropic generation failed: {last_error}")
