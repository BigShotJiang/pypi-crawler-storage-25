import os
import json
import time
from typing import Optional, Any, Dict
from llmux.base import BaseLLMProvider, LLMRequest, LLMProviderError

class BedrockLLMProvider(BaseLLMProvider):
    def __init__(
        self,
        model_name: str,
        region_name: Optional[str] = None,
        profile_name: Optional[str] = None,
        api_key: Optional[str] = None, # Not strictly used by Bedrock but kept for consistency
    ):
        super().__init__(model_name, api_key)
        self.region_name = region_name or os.environ.get("AWS_REGION") or os.environ.get("AWS_DEFAULT_REGION")
        self.profile_name = profile_name or os.environ.get("AWS_PROFILE")

    @property
    def provider_name(self) -> str:
        return "bedrock"

    def is_available(self) -> bool:
        return bool(self.region_name)

    def generate_text(self, request: LLMRequest) -> str:
        if not self.region_name:
            raise LLMProviderError("AWS region is not configured for Bedrock.")

        try:
            import boto3
        except ImportError as exc:
            raise LLMProviderError("boto3 is required for the Bedrock provider.") from exc

        session_kwargs: Dict[str, Any] = {"region_name": self.region_name}
        if self.profile_name:
            session_kwargs["profile_name"] = self.profile_name

        session = boto3.Session(**session_kwargs)
        client = session.client("bedrock-runtime")

        # Basic Titan payload, might need adjustment for Claude or other models on Bedrock
        payload = {
            "inputText": request.prompt,
            "textGenerationConfig": {
                "temperature": request.temperature,
            },
        }

        last_error: Optional[Exception] = None
        for attempt in range(request.max_retries):
            try:
                response = client.invoke_model(
                    modelId=self.model_name,
                    body=json.dumps(payload),
                    contentType="application/json",
                    accept="application/json",
                )
                body = json.loads(response["body"].read())
                if "results" in body and body["results"]:
                    return body["results"][0].get("outputText", "")
                if "outputText" in body:
                    return body["outputText"]
                raise LLMProviderError("Unsupported Bedrock response format for the configured model.")
            except Exception as exc:
                last_error = exc
                if attempt < request.max_retries - 1:
                    time.sleep(self._retry_delay(attempt))
                    continue
                break

        raise LLMProviderError(f"Bedrock generation failed: {last_error}")
