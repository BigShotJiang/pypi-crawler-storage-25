import time
from typing import Optional
from llmux.base import BaseLLMProvider, LLMRequest, LLMProviderError

class OllamaLLMProvider(BaseLLMProvider):
    def __init__(self, model_name: str, base_url: str = "http://localhost:11434"):
        super().__init__(model_name)
        self.base_url = base_url

    @property
    def provider_name(self) -> str:
        return "ollama"

    def is_available(self) -> bool:
        # We could do a health check here, but for now we'll assume true
        return True

    def generate_text(self, request: LLMRequest) -> str:
        try:
            import httpx
        except ImportError as exc:
            raise LLMProviderError("httpx is required for the Ollama provider.") from exc

        payload = {
            "model": self.model_name,
            "prompt": request.prompt,
            "stream": False,
            "options": {
                "temperature": request.temperature,
            }
        }

        last_error: Optional[Exception] = None
        for attempt in range(request.max_retries):
            try:
                response = httpx.post(
                    f"{self.base_url}/api/generate",
                    json=payload,
                    timeout=120.0,
                )
                response.raise_for_status()
                body = response.json()
                return body.get("response", "")
            except Exception as exc:
                last_error = exc
                if attempt < request.max_retries - 1:
                    time.sleep(self._retry_delay(attempt))
                    continue
                break

        raise LLMProviderError(f"Ollama generation failed: {last_error}")
