import os
import time
from typing import Optional
from llmux.base import BaseLLMProvider, LLMRequest, LLMProviderError

class GeminiLLMProvider(BaseLLMProvider):
    def __init__(self, model_name: str, api_key: Optional[str] = None):
        super().__init__(model_name, api_key or os.environ.get("GEMINI_API_KEY"))

    @property
    def provider_name(self) -> str:
        return "gemini"

    def is_available(self) -> bool:
        return bool(self.api_key)

    def generate_text(self, request: LLMRequest) -> str:
        if not self.api_key:
            raise LLMProviderError("GEMINI_API_KEY is not configured.")

        try:
            from google import genai
        except ImportError as exc:
            raise LLMProviderError("google-genai is not installed.") from exc

        client = genai.Client(api_key=self.api_key)

        last_error: Optional[Exception] = None
        for attempt in range(request.max_retries):
            try:
                response = client.models.generate_content(
                    model=self.model_name,
                    contents=request.prompt,
                    config={
                        "temperature": request.temperature,
                    }
                )
                return response.text or ""
            except Exception as exc:
                last_error = exc
                if ("ResourceExhausted" in str(exc) or "429" in str(exc)) and attempt < request.max_retries - 1:
                    time.sleep(self._retry_delay(attempt))
                    continue
                break

        raise LLMProviderError(f"Gemini generation failed: {last_error}")
