import os
import time
from typing import Optional
from llmux.base import BaseLLMProvider, LLMRequest, LLMProviderError

class OpenAICompatibleProvider(BaseLLMProvider):
    def __init__(
        self,
        model_name: str,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
        provider_name: str = "custom",
    ):
        super().__init__(model_name, api_key)
        self.base_url = base_url
        self._provider_name = provider_name

    @property
    def provider_name(self) -> str:
        return self._provider_name

    def is_available(self) -> bool:
        return bool(self.api_key)

    def generate_text(self, request: LLMRequest) -> str:
        if not self.api_key:
            raise LLMProviderError(f"API key for {self.provider_name} is not configured.")
        if not self.base_url:
            raise LLMProviderError(f"Base URL for {self.provider_name} is not configured.")

        try:
            import httpx
        except ImportError as exc:
            raise LLMProviderError("httpx is required for this provider.") from exc

        payload = {
            "model": self.model_name,
            "messages": [{"role": "user", "content": request.prompt}],
            "temperature": request.temperature,
        }
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
        }

        last_error: Optional[Exception] = None
        for attempt in range(request.max_retries):
            try:
                response = httpx.post(
                    f"{self.base_url.rstrip('/')}/chat/completions",
                    headers=headers,
                    json=payload,
                    timeout=60.0,
                )
                response.raise_for_status()
                body = response.json()
                
                if "choices" in body and len(body["choices"]) > 0:
                    return body["choices"][0]["message"]["content"]
                
                raise LLMProviderError(f"Unexpected {self.provider_name} response format: {body}")
            except Exception as exc:
                last_error = exc
                if attempt < request.max_retries - 1:
                    time.sleep(self._retry_delay(attempt))
                    continue
                break

        raise LLMProviderError(f"{self.provider_name} generation failed: {last_error}")
