"""Tests for GMICloudVideoProvider (mocked — no real API calls)."""

from __future__ import annotations

import json
from unittest.mock import MagicMock

import pytest
from genblaze_core.exceptions import ProviderError
from genblaze_core.models.enums import ProviderErrorCode, StepStatus
from genblaze_core.models.step import Step
from genblaze_core.providers.base import SubmitResult
from genblaze_core.testing import ProviderComplianceTests

from .conftest import make_mock_http_client


@pytest.fixture
def provider():
    from genblaze_gmicloud import GMICloudVideoProvider

    p = GMICloudVideoProvider(api_key="test-api-key-123")
    p._http_client = make_mock_http_client(
        outcome_key="video_url",
        outcome_url="https://gmicloud-output.com/video.mp4",
    )
    return p


# --- Submit ---


def test_submit_returns_submit_result(provider):
    step = Step(provider="gmicloud", model="Kling-Text2Video-V1.6-Pro", prompt="a sunset")
    result = provider.submit(step)
    assert isinstance(result, SubmitResult)
    assert result.prediction_id == "req-abc123"


def test_submit_forwards_params(provider):
    step = Step(
        provider="gmicloud",
        model="Kling-Text2Video-V1.6-Pro",
        prompt="test",
        params={"duration": 10, "cfg_scale": 0.5},
    )
    provider.submit(step)
    body = provider._http_client.post.call_args.kwargs.get("json")
    assert body["payload"]["duration"] == 10
    assert body["payload"]["cfg_scale"] == 0.5


def test_submit_forwards_negative_prompt_from_step_field(provider):
    """Pipeline hoists negative_prompt out of params onto the Step field."""
    step = Step(
        provider="gmicloud",
        model="Kling-Text2Video-V1.6-Pro",
        prompt="a sunset",
        negative_prompt="blurry, low-res",
    )
    provider.submit(step)
    body = provider._http_client.post.call_args.kwargs.get("json")
    assert body["payload"]["negative_prompt"] == "blurry, low-res"


def test_submit_image_to_video(provider):
    from genblaze_core.models.asset import Asset

    step = Step(
        provider="gmicloud",
        model="Kling-Image2Video-V1.6-Pro",
        prompt="animate this",
        inputs=[Asset(url="https://example.com/image.png", media_type="image/png")],
    )
    provider.submit(step)
    body = provider._http_client.post.call_args.kwargs.get("json")
    assert body["payload"]["image"] == "https://example.com/image.png"


# --- Poll ---


def test_poll_returns_true_on_success(provider):
    assert provider.poll("req-abc123") is True


def test_poll_returns_false_on_processing(provider):
    resp = MagicMock()
    resp.status_code = 200
    resp.json.return_value = {"request_id": "req-abc123", "status": "processing"}
    provider._http_client.get.return_value = resp
    assert provider.poll("req-abc123") is False


def test_poll_returns_true_on_failed(provider):
    resp = MagicMock()
    resp.status_code = 200
    resp.json.return_value = {"status": "failed", "error": "Content policy violation"}
    provider._http_client.get.return_value = resp
    assert provider.poll("req-abc123") is True


# --- Fetch output ---


def test_fetch_output_attaches_asset(provider):
    provider.poll("req-abc123")
    step = Step(provider="gmicloud", model="Kling-Text2Video-V1.6-Pro", prompt="a sunset")
    result = provider.fetch_output("req-abc123", step)
    assert len(result.assets) == 1
    assert result.assets[0].media_type == "video/mp4"
    assert "gmicloud-output.com" in result.assets[0].url


def test_poll_then_fetch_failed(provider):
    failed_resp = MagicMock()
    failed_resp.status_code = 200
    failed_resp.json.return_value = {"status": "failed", "error": "Content policy violation"}
    provider._http_client.get.return_value = failed_resp
    provider.poll("req-abc123")
    step = Step(provider="gmicloud", model="Kling-Text2Video-V1.6-Pro", prompt="bad")
    with pytest.raises(ProviderError, match="Content policy violation"):
        provider.fetch_output("req-abc123", step)


def test_fetch_output_cancelled_raises(provider):
    resp = MagicMock()
    resp.status_code = 200
    resp.json.return_value = {"status": "cancelled"}
    provider._http_client.get.return_value = resp
    provider.poll("req-abc123")
    step = Step(provider="gmicloud", model="Kling-Text2Video-V1.6-Pro", prompt="test")
    with pytest.raises(ProviderError, match="cancelled"):
        provider.fetch_output("req-abc123", step)


def test_invoke_full_lifecycle(provider):
    step = Step(provider="gmicloud", model="Kling-Text2Video-V1.6-Pro", prompt="a sunset")
    result = provider.invoke(step)
    assert result.status == StepStatus.SUCCEEDED
    assert len(result.assets) == 1


# --- Cost ---


def test_cost_tracked(provider):
    provider.poll("req-abc123")
    step = Step(provider="gmicloud", model="Kling-Text2Video-V1.6-Pro", prompt="a sunset")
    result = provider.fetch_output("req-abc123", step)
    assert result.cost_usd == pytest.approx(0.098)


def test_cost_none_unknown_model(provider):
    provider.poll("req-abc123")
    step = Step(provider="gmicloud", model="unknown-model", prompt="a sunset")
    result = provider.fetch_output("req-abc123", step)
    assert result.cost_usd is None


def test_cost_per_second_pricing_seedance_2(provider):
    """Seedance 2.0 is priced per-second ($0.052/sec) — cost must multiply
    by the duration from step.params, not a flat per-generation rate."""
    provider.poll("req-abc123")
    step = Step(
        provider="gmicloud",
        model="seedance-2-0-260128",
        prompt="a sunset",
        params={"duration": 10},
    )
    result = provider.fetch_output("req-abc123", step)
    assert result.cost_usd == pytest.approx(0.052 * 10)


def test_cost_per_second_pricing_missing_duration_is_none(provider):
    """Without a duration we can't compute per-second cost — leave it None
    rather than guess. Users who need cost tracking must pass duration."""
    provider.poll("req-abc123")
    step = Step(
        provider="gmicloud",
        model="seedance-2-0-260128",
        prompt="a sunset",
        # no duration in params
    )
    result = provider.fetch_output("req-abc123", step)
    assert result.cost_usd is None


# --- Video metadata ---


def test_video_metadata_no_audio(provider):
    provider.poll("req-abc123")
    step = Step(provider="gmicloud", model="Kling-Text2Video-V1.6-Pro", prompt="test")
    result = provider.fetch_output("req-abc123", step)
    assert result.assets[0].video is not None
    assert result.assets[0].video.has_audio is False


def test_veo3_model_has_audio_metadata(provider):
    provider.poll("req-abc123")
    step = Step(provider="gmicloud", model="Veo3", prompt="test")
    result = provider.fetch_output("req-abc123", step)
    asset = result.assets[0]
    assert asset.video.has_audio is True
    assert asset.audio is not None
    assert asset.audio.codec == "aac"
    assert len(asset.tracks) == 2


# --- Provider payload ---


def test_provider_payload_populated(provider):
    provider.poll("req-abc123")
    step = Step(provider="gmicloud", model="Kling-Text2Video-V1.6-Pro", prompt="test")
    result = provider.fetch_output("req-abc123", step)
    assert result.provider_payload["gmicloud"]["request_id"] == "req-abc123"
    assert result.provider_payload["gmicloud"]["status"] == "success"


def test_credentials_not_in_provider_payload(provider):
    provider.poll("req-abc123")
    step = Step(provider="gmicloud", model="Kling-Text2Video-V1.6-Pro", prompt="test")
    result = provider.fetch_output("req-abc123", step)
    assert "test-api-key-123" not in json.dumps(result.provider_payload)


# --- SSRF ---


def test_asset_url_rejects_non_https(provider):
    resp = MagicMock()
    resp.status_code = 200
    resp.json.return_value = {"status": "success", "outcome": {"video_url": "file:///etc/passwd"}}
    provider._http_client.get.return_value = resp
    provider.poll("req-abc123")
    step = Step(provider="gmicloud", model="Kling-Text2Video-V1.6-Pro", prompt="test")
    with pytest.raises(ProviderError, match="Unsafe asset URL"):
        provider.fetch_output("req-abc123", step)


def test_asset_url_rejects_http(provider):
    resp = MagicMock()
    resp.status_code = 200
    resp.json.return_value = {
        "status": "success",
        "outcome": {"video_url": "http://169.254.169.254/latest/meta-data/"},
    }
    provider._http_client.get.return_value = resp
    provider.poll("req-abc123")
    step = Step(provider="gmicloud", model="Kling-Text2Video-V1.6-Pro", prompt="test")
    with pytest.raises(ProviderError, match="Unsafe asset URL"):
        provider.fetch_output("req-abc123", step)


def test_chain_input_rejects_http_url(provider):
    from genblaze_core.models.asset import Asset

    step = Step(
        provider="gmicloud",
        model="Kling-Image2Video-V1.6-Pro",
        prompt="animate",
        inputs=[Asset(url="http://evil.com/payload.bin", media_type="image/png")],
    )
    with pytest.raises(ProviderError, match="[Uu]nsafe"):
        provider.submit(step)


# --- Error mapping ---


def test_error_mapping_auth():
    from genblaze_gmicloud._errors import map_gmicloud_error

    assert (
        map_gmicloud_error(Exception("unauthorized: invalid credentials"))
        == ProviderErrorCode.AUTH_FAILURE
    )


def test_error_mapping_forbidden():
    from genblaze_gmicloud._errors import map_gmicloud_error

    assert map_gmicloud_error(Exception("forbidden")) == ProviderErrorCode.AUTH_FAILURE


def test_error_mapping_rate_limit():
    from genblaze_gmicloud._errors import map_gmicloud_error

    result = map_gmicloud_error(Exception("too many"), status_code=429)
    assert result == ProviderErrorCode.RATE_LIMIT


def test_error_mapping_server_error():
    from genblaze_gmicloud._errors import map_gmicloud_error

    assert map_gmicloud_error(Exception("fail"), status_code=502) == ProviderErrorCode.SERVER_ERROR


def test_error_mapping_invalid_input():
    from genblaze_gmicloud._errors import map_gmicloud_error

    assert map_gmicloud_error(Exception("bad"), status_code=400) == ProviderErrorCode.INVALID_INPUT


def test_error_mapping_status_code_priority():
    from genblaze_gmicloud._errors import map_gmicloud_error

    result = map_gmicloud_error(Exception("unauthorized"), status_code=429)
    assert result == ProviderErrorCode.RATE_LIMIT


# --- Parameter pipeline (spec-driven via prepare_payload) ---


def test_duration_coerced_to_int(provider):
    step = Step(
        provider="gmicloud",
        model="Kling-Text2Video-V1.6-Pro",
        prompt="t",
        params={"duration": "10"},
    )
    assert provider.prepare_payload(step)["duration"] == 10


def test_guidance_scale_aliased_to_cfg_scale(provider):
    step = Step(
        provider="gmicloud",
        model="Kling-Text2Video-V1.6-Pro",
        prompt="t",
        params={"guidance_scale": 0.7},
    )
    result = provider.prepare_payload(step)
    assert result["cfg_scale"] == 0.7
    assert "guidance_scale" not in result


def test_prepare_payload_is_idempotent_for_normalized_params(provider):
    step = Step(
        provider="gmicloud",
        model="Kling-Text2Video-V1.6-Pro",
        prompt="t",
        params={"duration": 10, "cfg_scale": 0.7},
    )
    once = provider.prepare_payload(step)
    # Re-running against already-normalized params produces the same dict.
    step2 = Step(provider="gmicloud", model=step.model, prompt="t", params=once)
    assert provider.prepare_payload(step2) == once


# --- Passthrough ---


def test_unknown_model_passthrough(provider):
    step = Step(provider="gmicloud", model="SomeNewModel-v99", prompt="test")
    result = provider.submit(step)
    assert isinstance(result, SubmitResult)


# --- Compliance ---


class TestGMICloudCompliance(ProviderComplianceTests):
    def make_provider(self):
        from genblaze_gmicloud import GMICloudVideoProvider

        p = GMICloudVideoProvider(api_key="test-compliance-key")
        p._http_client = make_mock_http_client(
            outcome_key="video_url",
            outcome_url="https://gmicloud-output.com/video.mp4",
        )
        p.poll_interval = 0.0

        # Suppress initial_delay sleep in _attempt_once
        original_submit = p.submit

        def fast_submit(step, config=None):
            r = original_submit(step, config)
            r.estimated_seconds = None
            return r

        p.submit = fast_submit
        return p

    def make_step(self):
        return Step(provider="gmicloud", model="Kling-Text2Video-V1.6-Pro", prompt="test prompt")
