from .component import AudioDashboardComponent
