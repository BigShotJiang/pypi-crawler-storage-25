from typing import *
from .common import Confirmation, SoundConfirmation, SoundCommand, IMessage, message_handler, CommandConfirmationQueue, AvatarService
from abc import ABC, abstractmethod
from .brainbox_service import BrainBoxService
from brainbox import BrainBox
from dataclasses import dataclass

@dataclass
class TTSSettings:
    character: str
    language: str


class TTSTaskFactory(ABC):
    @abstractmethod
    def create_task(self, s: str, info: TTSSettings) -> BrainBox.Task:
        pass


@dataclass
class TTSCommand(IMessage):
    Settings = TTSSettings
    text: tuple[str,...]
    settings: TTSSettings


@dataclass
class PlayingElement:
    source_message_id: str
    sound_message_id: str



class TTSService(AvatarService):
    Command = TTSCommand
    TaskFactory = TTSTaskFactory

    def __init__(self, task_factory: TTSTaskFactory):
        self.task_factory = task_factory
        self.queue = CommandConfirmationQueue[BrainBoxService.Command, BrainBoxService.Confirmation[str]]()
        self.playing: PlayingElement|None = None

    def requires_brainbox(self):
        return True

    @message_handler
    def start_voiceover(self, input: TTSCommand) -> Tuple[BrainBoxService.Command,...]:
        output = []
        for line in input.text:
            task = self.task_factory.create_task(line, input.settings)
            message = BrainBoxService.Command(task, metadata=dict(source_message_id=input.envelop.id, text = line)).as_reply_to(input)
            output.append(message)
        self.queue.start_tracking(output)
        return tuple(output)

    def start_playing(self) -> Tuple[SoundCommand,...]:
        while self.queue.get_processed_head_length() > 0:
            element = self.queue.deque()
            if element.confirmation.result is None:
                continue
            message_id = element.command.metadata['source_message_id']
            text = element.command.metadata['text']
            output = SoundCommand(element.confirmation.result, text).as_reply_to(message_id)
            self.playing = PlayingElement(message_id, output.envelop.id)
            return (output,)
        return ()

    @message_handler
    def brainbox_finished(self, message: BrainBoxService.Confirmation[str]) -> Tuple[SoundCommand,...]:
        if not isinstance(message.result, str):
            return ()
        self.queue.track(message)
        if self.playing is None:
            return self.start_playing()
        else:
            return ()

    @message_handler
    def play_finished(self, message: SoundConfirmation) -> tuple[SoundCommand|Confirmation,...]:
        if self.playing is None or not message.is_confirmation_of(self.playing.sound_message_id):
            return ()
        is_last = True
        for element in self.queue.queue:
            if element.command.metadata['source_message_id'] == self.playing.source_message_id:
                is_last = False
                break

        result = []
        if is_last:
            result.append(Confirmation().as_confirmation_for(self.playing.source_message_id))

        self.playing = None
        result.extend(self.start_playing())
        return tuple(result)






