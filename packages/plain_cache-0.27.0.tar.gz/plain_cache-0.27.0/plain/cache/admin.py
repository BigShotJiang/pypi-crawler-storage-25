from __future__ import annotations

from plain.admin.views import (
    AdminModelDetailView,
    AdminModelListView,
    AdminViewset,
    register_viewset,
)
from plain.cache.models import CachedItem
from plain.postgres import QuerySet


@register_viewset
class CachedItemViewset(AdminViewset):
    class ListView(AdminModelListView):
        nav_section = "Cache"
        nav_icon = "database"
        model = CachedItem
        title = "Cached items"
        description = "Database cache entries with expiration times."
        fields = [
            "key",
            "created_at",
            "expires_at",
            "updated_at",
        ]
        queryset_order = ["-id"]

        def get_initial_queryset(self) -> QuerySet[CachedItem]:
            return (
                super()
                .get_initial_queryset()
                .only("key", "created_at", "expires_at", "updated_at")
            )

    class DetailView(AdminModelDetailView):
        model = CachedItem
        title = "Cached item"
