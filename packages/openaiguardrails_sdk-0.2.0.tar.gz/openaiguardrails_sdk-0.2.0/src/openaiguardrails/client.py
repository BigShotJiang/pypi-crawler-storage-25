"""Dependency-free client for the Open AI Guardrails API."""

from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Any, Mapping
from urllib.error import HTTPError
from urllib.parse import quote, urljoin
from urllib.request import Request, urlopen


DEFAULT_BASE_URL = "https://openaiguardrails.org"


@dataclass
class OpenAIGuardrailsError(Exception):
    """Raised when the Open AI Guardrails API returns an unsuccessful response."""

    message: str
    status: int | None = None
    body: Any | None = None

    def __str__(self) -> str:
        if self.status is None:
            return self.message
        return f"{self.message} ({self.status})"


class OpenAIGuardrailsClient:
    """Client for policy distribution, audit export, OPA control-plane, and platform catalog APIs."""

    def __init__(self, base_url: str = DEFAULT_BASE_URL, token: str | None = None, timeout: float = 30.0) -> None:
        self.base_url = base_url.rstrip("/") + "/"
        self.token = token
        self.timeout = timeout

    def health(self) -> Any:
        return self.request("/health")

    def get_openapi(self) -> Any:
        return self.request("/openapi.json")

    def list_entries(self) -> Any:
        return self.request("/api/entries")

    def list_discussions(self) -> Any:
        return self.request("/api/discussions")

    def list_policies(self) -> Any:
        return self.request("/api/policies")

    def get_policy(self, policy_id: str = "prod-safety-alpha") -> Any:
        return self.request(f"/v1/policy/{quote(policy_id, safe='')}")

    def toggle_policy_control(self, policy_id: str, key: str, value: bool) -> Any:
        return self.request(
            f"/api/policies/{quote(policy_id, safe='')}/toggles",
            method="POST",
            body={"key": key, "value": value},
        )

    def run_policy_action(self, policy_id: str, action: str, **payload: Any) -> Any:
        return self.request(
            f"/api/policies/{quote(policy_id, safe='')}/actions",
            method="POST",
            body={"action": action, **payload},
        )

    def export_audit(self, policy_id: str = "prod-safety-alpha") -> Any:
        return self.request(f"/api/policies/{quote(policy_id, safe='')}/audit-export")

    def list_opa_imports(self) -> Any:
        return self.request("/api/opa/imports")

    def import_opa_policy(self, payload: Mapping[str, Any]) -> Any:
        return self.request("/api/opa/imports", method="POST", body=dict(payload))

    def simulate_opa_import(self, import_id: str, input: Mapping[str, Any] | None = None) -> Any:
        body = None if input is None else {"input": dict(input)}
        return self.request(f"/api/opa/imports/{quote(import_id, safe='')}/simulate", method="POST", body=body)

    def export_opa_import(self, import_id: str, target: str) -> Any:
        return self.request(f"/api/opa/imports/{quote(import_id, safe='')}/export/{quote(target, safe='')}")

    def publish_opa_import(self, import_id: str, payload: Mapping[str, Any] | None = None) -> Any:
        return self.request(
            f"/api/opa/imports/{quote(import_id, safe='')}/publish",
            method="POST",
            body=dict(payload or {}),
        )

    def list_skills(self) -> Any:
        return self.request("/api/skills")

    def get_skill(self, skill_id: str) -> Any:
        return self.request(f"/api/skills/{quote(skill_id, safe='')}")

    def list_professions(self) -> Any:
        return self.request("/api/professions")

    def get_profession(self, profession_id: str) -> Any:
        return self.request(f"/api/professions/{quote(profession_id, safe='')}")

    def get_mcp_registry(self) -> Any:
        return self.request("/api/mcp/registry")

    def get_mcp_tool(self, skill_id: str) -> Any:
        return self.request(f"/api/mcp/tools/{quote(skill_id, safe='')}")

    def list_blog_pending_posts(self) -> Any:
        return self.request("/api/blog/pending-posts")

    def submit_blog_post(self, payload: Mapping[str, Any]) -> Any:
        return self.request("/api/blog/pending-posts", method="POST", body=dict(payload))

    def get_blog_review(self, review_id: str | int) -> Any:
        return self.request(f"/api/blog/reviews/{quote(str(review_id), safe='')}")

    def approve_blog_review(self, review_id: str | int, payload: Mapping[str, Any] | None = None) -> Any:
        return self.request(
            f"/api/blog/reviews/{quote(str(review_id), safe='')}/approve",
            method="POST",
            body=dict(payload or {}),
        )

    def reject_blog_review(self, review_id: str | int, payload: Mapping[str, Any]) -> Any:
        return self.request(
            f"/api/blog/reviews/{quote(str(review_id), safe='')}/reject",
            method="POST",
            body=dict(payload),
        )

    def publish_blog_review(self, review_id: str | int, payload: Mapping[str, Any] | None = None) -> Any:
        return self.request(
            f"/api/blog/reviews/{quote(str(review_id), safe='')}/publish",
            method="POST",
            body=dict(payload or {}),
        )

    def publish_blog_post(self, payload: Mapping[str, Any]) -> Any:
        return self.request("/api/blog/publish", method="POST", body=dict(payload))

    def get_smtp_status(self) -> Any:
        return self.request("/api/ops/smtp-status")

    def request(
        self,
        path: str,
        method: str = "GET",
        body: Mapping[str, Any] | None = None,
        headers: Mapping[str, str] | None = None,
    ) -> Any:
        request_headers = {"Accept": "application/json", **dict(headers or {})}
        data = None

        if self.token and "Authorization" not in request_headers:
            request_headers["Authorization"] = f"Bearer {self.token}"

        if body is not None:
            data = json.dumps(body).encode("utf-8")
            request_headers["Content-Type"] = "application/json"

        request = Request(
            urljoin(self.base_url, path.lstrip("/")),
            data=data,
            headers=request_headers,
            method=method,
        )

        try:
            with urlopen(request, timeout=self.timeout) as response:
                return _decode_response(response.read(), response.headers.get("Content-Type", ""))
        except HTTPError as exc:
            error_body = _decode_response(exc.read(), exc.headers.get("Content-Type", ""))
            raise OpenAIGuardrailsError("Open AI Guardrails request failed", status=exc.code, body=error_body) from exc


def _decode_response(raw: bytes, content_type: str) -> Any:
    text = raw.decode("utf-8")
    if "application/json" in content_type:
        return json.loads(text)
    return text


NoirGuardrailsClient = OpenAIGuardrailsClient
NoirGuardrailsError = OpenAIGuardrailsError
