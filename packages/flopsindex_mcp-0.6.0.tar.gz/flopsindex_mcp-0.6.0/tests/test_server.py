"""Tests for the flopsindex_mcp server.

We exercise the tool implementations directly (not through stdio) so
the tests stay fast and offline. httpx is monkeypatched per-test.
"""
from __future__ import annotations

import json
import sys
import types
from pathlib import Path
from typing import Any

import pytest

# Make `flopsindex_mcp` importable from `mcp/` parent dir.
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from flopsindex_mcp import server as srv  # noqa: E402


class _MockAsyncClient:
    """Stand-in for httpx.AsyncClient with a tiny route table."""

    def __init__(self, routes, **_kw):
        self._routes = routes
        self.last_url = None
        self.last_params = None

    async def __aenter__(self):
        return self

    async def __aexit__(self, *_a):
        return False

    async def get(self, url, params=None):
        self.last_url = url
        self.last_params = params or {}
        for prefix, payload in self._routes.items():
            if prefix in url:
                if callable(payload):
                    body = payload(url, params)
                else:
                    body = payload
                # Pre-built _MockResp payload — pass through so callers
                # can stake non-200 status codes (used by defensive-envelope
                # tests for /v1/verify 500, /v1/forecasts 401, etc).
                if isinstance(body, _MockResp):
                    return body
                return _MockResp(200, body)
        return _MockResp(404, {"error": "no route"})


class _MockResp:
    def __init__(self, status_code, body):
        self.status_code = status_code
        self._body = body
        self.text = json.dumps(body) if not isinstance(body, str) else body

    def json(self):
        return self._body

    def raise_for_status(self):
        if self.status_code >= 400:
            import httpx
            raise httpx.HTTPStatusError(
                "boom",
                request=types.SimpleNamespace(url=self._body),
                response=self,
            )


def _install_mock(monkeypatch, routes):
    def factory(**kw):
        return _MockAsyncClient(routes, **kw)
    monkeypatch.setattr(srv.httpx, "AsyncClient", factory)


# ---------------------------------------------------------------------
# list_methodologies
# ---------------------------------------------------------------------

@pytest.mark.asyncio
async def test_list_methodologies(monkeypatch):
    _install_mock(monkeypatch, {"/v1/methodology": {
        "count": 3,
        "methodologies": [
            {"slug": "flci-h100", "version": "v0.9", "status": "active"},
            {"slug": "itpi-canonical", "version": "v0.9", "status": "active"},
            {"slug": "flops-h100-od", "version": "v0.9", "status": "active"},
        ],
    }})
    out = await srv._tool_list_methodologies({})
    data = json.loads(out)
    assert data["count"] == 3
    assert any(m["slug"] == "flci-h100" for m in data["methodologies"])


# ---------------------------------------------------------------------
# get_methodology
# ---------------------------------------------------------------------

@pytest.mark.asyncio
async def test_get_methodology_versions(monkeypatch):
    """No version pinned → fall through to /versions listing."""
    captured = {}
    def handler(url, params):
        captured["url"] = url
        return {"slug": "flci-h100", "versions": ["v0.9"]}
    _install_mock(monkeypatch, {"/versions": handler})
    out = await srv._tool_get_methodology({"slug": "flci-h100"})
    data = json.loads(out)
    assert "versions" in captured["url"]
    assert data["versions"] == ["v0.9"]


@pytest.mark.asyncio
async def test_get_methodology_json(monkeypatch):
    """as_json=True → fetch the .json frontmatter envelope."""
    _install_mock(monkeypatch, {"v0.9.json": {
        "slug": "flci-h100",
        "version": "v0.9",
        "frontmatter": {"name": "FLCI-H100", "change_class": "initial"},
    }})
    out = await srv._tool_get_methodology({
        "slug": "flci-h100", "version": "v0.9", "as_json": True,
    })
    data = json.loads(out)
    assert data["frontmatter"]["change_class"] == "initial"


@pytest.mark.asyncio
async def test_get_methodology_markdown(monkeypatch):
    """No as_json → wrap raw markdown in JSON envelope."""
    _install_mock(monkeypatch, {"v0.9": "# FLCI-H100 v0.9\nmarkdown body"})
    out = await srv._tool_get_methodology({
        "slug": "flci-h100", "version": "v0.9",
    })
    data = json.loads(out)
    assert data["format"] == "markdown"
    assert "FLCI-H100 v0.9" in data["content"]
    assert data["version"] == "v0.9"


@pytest.mark.asyncio
async def test_get_methodology_requires_slug():
    out = await srv._tool_get_methodology({})
    assert json.loads(out)["error"] == "slug is required"


# ---------------------------------------------------------------------
# compute_margin
# ---------------------------------------------------------------------

@pytest.mark.asyncio
async def test_compute_margin_happy_path(monkeypatch):
    captured = {}
    def handler(url, params):
        captured["params"] = params
        return {"price": 6.16, "power_cost": 0.07, "rack_cost": 0.40,
                "margin": 5.69, "margin_pct": 0.924}
    _install_mock(monkeypatch, {"/v1/derived/compute-margin": handler})
    out = await srv._tool_compute_margin({
        "sku": "h100_sxm5", "region": "us_west",
        "pue": 1.4, "kwh_source": "live_lmp",
    })
    data = json.loads(out)
    assert data["margin"] == 5.69
    assert captured["params"]["sku"] == "h100_sxm5"
    assert captured["params"]["pue"] == 1.4
    assert captured["params"]["kwh_source"] == "live_lmp"


@pytest.mark.asyncio
async def test_compute_margin_omits_optional(monkeypatch):
    captured = {}
    def handler(url, params):
        captured["params"] = params
        return {"margin": 4.20}
    _install_mock(monkeypatch, {"/v1/derived/compute-margin": handler})
    await srv._tool_compute_margin({"sku": "a100_sxm4", "region": "us_east"})
    p = captured["params"]
    assert "pue" not in p
    assert "kwh_source" not in p


@pytest.mark.asyncio
async def test_compute_margin_requires_sku_and_region():
    a = await srv._tool_compute_margin({"region": "us_west"})
    assert "sku" in json.loads(a)["error"]
    b = await srv._tool_compute_margin({"sku": "h100_sxm5"})
    assert "region" in json.loads(b)["error"]


# ---------------------------------------------------------------------
# recompute_audit
# ---------------------------------------------------------------------

@pytest.mark.asyncio
async def test_recompute_audit_happy_path(monkeypatch):
    _install_mock(monkeypatch, {"/v1/audit/recompute": {
        "run_id": "run-123",
        "status": "green",
        "variance_bps": 0.3,
        "methodology_version": "flci-h100@v0.9",
        "inputs_hash": "sha256:abcdef",
        "replay_value": 6.155,
        "published_value": 6.155,
    }})
    out = await srv._tool_recompute_audit({"index_id": "FLCI-H100-OD"})
    data = json.loads(out)
    assert data["status"] == "green"
    assert data["variance_bps"] == 0.3


@pytest.mark.asyncio
async def test_recompute_audit_passes_as_of(monkeypatch):
    captured = {}
    def handler(url, params):
        captured["params"] = params
        return {"status": "green"}
    _install_mock(monkeypatch, {"/v1/audit/recompute": handler})
    await srv._tool_recompute_audit({
        "index_id": "FLCI-H100-OD",
        "as_of": "2026-05-17T00:00:00Z",
    })
    assert captured["params"]["as_of"] == "2026-05-17T00:00:00Z"


@pytest.mark.asyncio
async def test_recompute_audit_requires_index_id():
    out = await srv._tool_recompute_audit({})
    assert "index_id" in json.loads(out)["error"]


# ---------------------------------------------------------------------
# Tool registration smoke test — every tool name is reachable
# ---------------------------------------------------------------------

@pytest.mark.asyncio
async def test_tool_list_has_new_tools():
    tools = await srv.list_tools()
    names = {t.name for t in tools}
    # Old tools still present
    assert names.issuperset({"list_indices", "verify", "get_price",
                              "get_timeseries", "search_indices"})
    # New tools registered
    assert names.issuperset({"list_methodologies", "get_methodology",
                              "compute_margin", "recompute_audit",
                              "spread", "gpu_capex"})


def test_version_bumped():
    # Tracks USER_AGENT pin; update when the package version moves.
    # Catches the "forgot to bump UA after pyproject.toml bump" footgun.
    assert "0.5.2" in srv.USER_AGENT


# ---------------------------------------------------------------------
# get_lmp_history — Lane 1 R7 PE (pending route wrapper)
# ---------------------------------------------------------------------


@pytest.mark.asyncio
async def test_get_lmp_history_happy_path(monkeypatch):
    captured = {}
    def handler(url, params):
        captured["params"] = params
        return {"iso": "caiso", "hub": "SP15", "range": "7d",
                "points": [{"ts": "2026-05-19T00:00:00Z", "value": 38.5}]}
    _install_mock(monkeypatch, {"/v1/forecasts/lmp-history": handler})
    out = await srv._tool_get_lmp_history({"iso": "caiso", "hub": "SP15", "range": "7d"})
    data = json.loads(out)
    assert data["iso"] == "caiso"
    assert captured["params"]["hub"] == "SP15"
    assert captured["params"]["range"] == "7d"


@pytest.mark.asyncio
async def test_get_lmp_history_returns_endpoint_pending_on_404(monkeypatch):
    _install_mock(monkeypatch, {"/v1/forecasts/lmp-history":
                                 _MockResp(404, {"detail": "no route"})})
    out = await srv._tool_get_lmp_history({"iso": "caiso"})
    data = json.loads(out)
    assert data["ok"] is False
    assert data["reason"] == "endpoint_pending"


@pytest.mark.asyncio
async def test_get_lmp_history_requires_iso():
    out = await srv._tool_get_lmp_history({})
    data = json.loads(out)
    assert data["reason"] == "missing_arg"


# ---------------------------------------------------------------------
# get_arbitrage_windows — Lane 3 R7 PC (pending route wrapper)
# ---------------------------------------------------------------------


@pytest.mark.asyncio
async def test_get_arbitrage_windows_happy_path(monkeypatch):
    captured = {}
    def handler(url, params):
        captured["params"] = params
        return {"sku": "h100_sxm5", "region": "us_west",
                "windows": [{"window_start": "02:00", "window_end": "06:00",
                              "expected_savings_pct": 0.32, "confidence": "HIGH"}]}
    _install_mock(monkeypatch, {"/v1/forensics/arbitrage/windows": handler})
    out = await srv._tool_get_arbitrage_windows({
        "sku": "h100_sxm5", "region": "us_west", "min_savings_pct": 0.20,
    })
    data = json.loads(out)
    assert data["windows"][0]["expected_savings_pct"] == 0.32
    assert captured["params"]["min_savings_pct"] == 0.20


@pytest.mark.asyncio
async def test_get_arbitrage_windows_returns_endpoint_pending_on_404(monkeypatch):
    _install_mock(monkeypatch, {"/v1/forensics/arbitrage/windows":
                                 _MockResp(404, {"detail": "no route"})})
    out = await srv._tool_get_arbitrage_windows({"sku": "h100_sxm5", "region": "us_west"})
    data = json.loads(out)
    assert data["ok"] is False
    assert data["reason"] == "endpoint_pending"


@pytest.mark.asyncio
async def test_get_arbitrage_windows_requires_sku_and_region():
    a = await srv._tool_get_arbitrage_windows({"region": "us_west"})
    assert json.loads(a)["reason"] == "missing_arg"
    b = await srv._tool_get_arbitrage_windows({"sku": "h100_sxm5"})
    assert json.loads(b)["reason"] == "missing_arg"


# ---------------------------------------------------------------------
# get_forecast_accuracy — Lane 1 R7 helper
# ---------------------------------------------------------------------


@pytest.mark.asyncio
async def test_get_forecast_accuracy_happy_path(monkeypatch):
    captured = {}
    def handler(url, params):
        captured["params"] = params
        return {"iso": "caiso", "window_days": 30, "mae": 2.4,
                "rmse": 3.1, "mape": 0.082, "n_samples": 720}
    _install_mock(monkeypatch, {"/v1/forecasts/accuracy": handler})
    out = await srv._tool_get_forecast_accuracy({"iso": "caiso", "window_days": 30})
    data = json.loads(out)
    assert data["mae"] == 2.4
    assert captured["params"]["window_days"] == 30


@pytest.mark.asyncio
async def test_get_forecast_accuracy_clamps_window(monkeypatch):
    captured = {}
    def handler(url, params):
        captured["params"] = params
        return {"iso": "caiso", "window_days": 30}
    _install_mock(monkeypatch, {"/v1/forecasts/accuracy": handler})
    await srv._tool_get_forecast_accuracy({"iso": "caiso", "window_days": 9999})
    assert captured["params"]["window_days"] == 365  # clamped to ceiling
    await srv._tool_get_forecast_accuracy({"iso": "caiso", "window_days": 0})
    assert captured["params"]["window_days"] == 1  # clamped to floor


@pytest.mark.asyncio
async def test_get_forecast_accuracy_requires_iso():
    out = await srv._tool_get_forecast_accuracy({})
    data = json.loads(out)
    assert data["reason"] == "missing_arg"


# ---------------------------------------------------------------------
# AST-walk wiring catcher — bidirectional registration check
# Pattern: [[swarm-wiring-catcher-pattern]]
#
# Every Tool() declared in list_tools() MUST have a dispatch branch in
# call_tool(). Every dispatch branch in call_tool() MUST have a
# corresponding Tool() declaration AND an _tool_<name> implementation.
# Three-way bijection across the registration surface.
# ---------------------------------------------------------------------


def _extract_wiring_sets():
    """Parse server.py and return (declared_tools, dispatched_tools,
    implemented_tools) sets — used by the bidirectional catcher."""
    import ast as _ast
    src = Path(srv.__file__).read_text(encoding="utf-8")
    tree = _ast.parse(src)

    declared: set[str] = set()
    dispatched: set[str] = set()
    implemented: set[str] = set()

    for node in _ast.walk(tree):
        # Tool(name="...") declarations
        if isinstance(node, _ast.Call):
            func = node.func
            is_tool = (
                (isinstance(func, _ast.Name) and func.id == "Tool")
                or (isinstance(func, _ast.Attribute) and func.attr == "Tool")
            )
            if is_tool:
                for kw in node.keywords:
                    if kw.arg == "name" and isinstance(kw.value, _ast.Constant):
                        declared.add(kw.value.value)
        # `_tool_<name>` async function implementations
        if isinstance(node, _ast.AsyncFunctionDef) and node.name.startswith("_tool_"):
            implemented.add(node.name[len("_tool_"):])
        # `elif name == "..."` dispatch branches inside call_tool
        if isinstance(node, _ast.Compare):
            if (
                isinstance(node.left, _ast.Name)
                and node.left.id == "name"
                and len(node.ops) == 1
                and isinstance(node.ops[0], _ast.Eq)
                and len(node.comparators) == 1
                and isinstance(node.comparators[0], _ast.Constant)
            ):
                dispatched.add(node.comparators[0].value)

    return declared, dispatched, implemented


def test_wiring_catcher_declared_matches_dispatched():
    """Every Tool() in list_tools has a dispatch branch in call_tool."""
    declared, dispatched, _ = _extract_wiring_sets()
    missing_dispatch = declared - dispatched
    assert not missing_dispatch, (
        f"Tools declared but not dispatched: {sorted(missing_dispatch)} — "
        "add an `elif name == '<tool>':` branch in call_tool()."
    )


def test_wiring_catcher_dispatched_matches_declared():
    """Every dispatch branch in call_tool has a Tool() declaration."""
    declared, dispatched, _ = _extract_wiring_sets()
    missing_declared = dispatched - declared
    assert not missing_declared, (
        f"Tools dispatched but not declared: {sorted(missing_declared)} — "
        "add a Tool(name='<tool>', ...) entry in list_tools()."
    )


def test_wiring_catcher_declared_matches_implemented():
    """Every Tool() declaration has a matching _tool_<name> coroutine."""
    declared, _, implemented = _extract_wiring_sets()
    missing_impl = declared - implemented
    assert not missing_impl, (
        f"Tools declared but not implemented: {sorted(missing_impl)} — "
        "add an `async def _tool_<name>(args):` function."
    )


def test_wiring_catcher_implemented_matches_declared():
    """Every _tool_<name> coroutine has a matching Tool() declaration."""
    declared, _, implemented = _extract_wiring_sets()
    orphan_impl = implemented - declared
    assert not orphan_impl, (
        f"Implementations without a Tool() declaration: {sorted(orphan_impl)} — "
        "either declare the Tool or remove the dead _tool_<name> coroutine."
    )


# ---------------------------------------------------------------------
# get_forecast — Lane 4 /v1/forecasts (wrapper pending _ALLOW_PREFIXES)
# ---------------------------------------------------------------------


@pytest.mark.asyncio
async def test_get_forecast_happy_path(monkeypatch):
    _install_mock(monkeypatch, {"/v1/forecasts": {
        "generated_at": "2026-05-19T22:00:00+00:00",
        "snapshots": {"caiso": {"iso": "caiso", "source": "OASIS",
                                 "hubs": [{"hub": "SP15", "value": 38.50}]}},
        "errors": {},
        "unconfigured": {},
        "summary": {"forecast_count": 1, "adapter_count": 14},
    }})
    out = await srv._tool_get_forecast({})
    data = json.loads(out)
    assert data["snapshots"]["caiso"]["hubs"][0]["value"] == 38.50
    assert data["summary"]["forecast_count"] == 1


@pytest.mark.asyncio
async def test_get_forecast_defensive_on_401(monkeypatch):
    """Lane 4's _ALLOW_PREFIXES not yet wired — must NOT raise."""
    _install_mock(monkeypatch, {"/v1/forecasts": _MockResp(401, {"detail": "auth"})})
    out = await srv._tool_get_forecast({})
    data = json.loads(out)
    assert data["ok"] is False
    assert data["reason"] == "auth_required"
    assert data["upstream_status"] == 401


# ---------------------------------------------------------------------
# get_iso_health_events — Lane 1 ring buffer
# ---------------------------------------------------------------------


@pytest.mark.asyncio
async def test_get_iso_health_events_happy_path(monkeypatch):
    captured = {}
    def handler(url, params):
        captured["url"] = url
        captured["params"] = params
        return {"adapter": "caiso", "events": [
            {"ts": "2026-05-19T22:00:00Z", "outcome": "ok",
             "latency_ms": 220},
        ]}
    _install_mock(monkeypatch, {"/v1/admin/iso-health/caiso/events": handler})
    out = await srv._tool_get_iso_health_events({"name": "caiso", "limit": 25})
    data = json.loads(out)
    assert data["adapter"] == "caiso"
    assert captured["params"]["limit"] == 25


@pytest.mark.asyncio
async def test_get_iso_health_events_clamps_limit(monkeypatch):
    captured = {}
    def handler(url, params):
        captured["params"] = params
        return {"adapter": "caiso", "events": []}
    _install_mock(monkeypatch, {"/v1/admin/iso-health/caiso/events": handler})
    await srv._tool_get_iso_health_events({"name": "caiso", "limit": 9999})
    assert captured["params"]["limit"] == 200  # clamped to ring-buffer ceiling
    await srv._tool_get_iso_health_events({"name": "caiso", "limit": 0})
    assert captured["params"]["limit"] == 1  # clamped to floor


@pytest.mark.asyncio
async def test_get_iso_health_events_sends_admin_key(monkeypatch):
    """When FLOPSINDEX_ADMIN_API_KEY is set, it goes out on the request."""
    captured = {"headers": None}

    class _CaptureClient:
        def __init__(self, **kw):
            captured["headers"] = kw.get("headers", {})
        async def __aenter__(self): return self
        async def __aexit__(self, *_a): return False
        async def get(self, url, params=None):
            return _MockResp(200, {"events": []})

    monkeypatch.setenv("FLOPSINDEX_ADMIN_API_KEY", "test-admin-key")
    monkeypatch.setattr(srv.httpx, "AsyncClient", _CaptureClient)
    await srv._tool_get_iso_health_events({"name": "caiso"})
    assert captured["headers"].get("X-FLOPS-Api-Key") == "test-admin-key"


@pytest.mark.asyncio
async def test_get_iso_health_events_requires_name():
    out = await srv._tool_get_iso_health_events({})
    data = json.loads(out)
    assert data["ok"] is False
    assert data["reason"] == "missing_arg"


# ---------------------------------------------------------------------
# get_basis — pending Lane 4 route wrapper
# ---------------------------------------------------------------------


@pytest.mark.asyncio
async def test_get_basis_returns_endpoint_pending_on_404(monkeypatch):
    """Route wrapper not yet shipped — agents should NOT see an exception."""
    _install_mock(monkeypatch, {"/v1/forecasts/basis/caiso":
                                 _MockResp(404, {"detail": "no route"})})
    out = await srv._tool_get_basis({"iso": "caiso"})
    data = json.loads(out)
    assert data["ok"] is False
    assert data["reason"] == "endpoint_pending"
    assert data["upstream_status"] == 404


@pytest.mark.asyncio
async def test_get_basis_happy_path_when_route_lands(monkeypatch):
    """Stake the success shape for when Lane 4 ships the route."""
    _install_mock(monkeypatch, {"/v1/forecasts/basis/caiso": {
        "iso": "caiso", "hub": "SP15",
        "forecast_value": 38.50, "actual_value": 41.20,
        "basis": -2.70, "as_of": "2026-05-19T22:00:00+00:00",
    }})
    out = await srv._tool_get_basis({"iso": "caiso"})
    data = json.loads(out)
    assert data["basis"] == -2.70
    assert data["iso"] == "caiso"


@pytest.mark.asyncio
async def test_get_basis_requires_iso():
    out = await srv._tool_get_basis({})
    data = json.loads(out)
    assert data["reason"] == "missing_arg"


# ---------------------------------------------------------------------
# get_sla_delta — pending Lane 4 route wrapper
# ---------------------------------------------------------------------


@pytest.mark.asyncio
async def test_get_sla_delta_returns_endpoint_pending_on_404(monkeypatch):
    _install_mock(monkeypatch, {"/v1/forensics/sla/rankings":
                                 _MockResp(404, {"detail": "no route"})})
    out = await srv._tool_get_sla_delta({"provider": "akash"})
    data = json.loads(out)
    assert data["ok"] is False
    assert data["reason"] == "endpoint_pending"


@pytest.mark.asyncio
async def test_get_sla_delta_happy_path(monkeypatch):
    captured = {}
    def handler(url, params):
        captured["params"] = params
        return {"provider": "akash", "sla_pct": 0.995,
                "observed_pct": 0.987, "delta_pp": -0.008,
                "window_days": 30}
    _install_mock(monkeypatch, {"/v1/forensics/sla/rankings": handler})
    out = await srv._tool_get_sla_delta({"provider": "akash"})
    data = json.loads(out)
    assert data["delta_pp"] == -0.008
    assert captured["params"]["provider"] == "akash"


@pytest.mark.asyncio
async def test_get_sla_delta_requires_provider():
    out = await srv._tool_get_sla_delta({})
    data = json.loads(out)
    assert data["reason"] == "missing_arg"


# ---------------------------------------------------------------------
# verify — upgraded to defensive envelope (Lane 4 fixing upstream 500)
# ---------------------------------------------------------------------


@pytest.mark.asyncio
async def test_verify_returns_ok_envelope_on_upstream_500(monkeypatch):
    """Per 2026-05-19 grounding /v1/verify returns 500; the verify
    handshake is the Track-D protocol-position move — it must never
    raise back to agents while Lane 4 fixes upstream."""
    _install_mock(monkeypatch, {"/v1/verify":
                                 _MockResp(500, {"detail": "boom"})})
    out = await srv._tool_verify({"index_id": "FLCI-H100"})
    data = json.loads(out)
    assert data["ok"] is False
    assert data["reason"] == "upstream_http_error"
    assert data["upstream_status"] == 500


@pytest.mark.asyncio
async def test_verify_happy_path_when_upstream_recovers(monkeypatch):
    _install_mock(monkeypatch, {"/v1/verify": {
        "verified": True, "index_id": "FLCI-H100", "actual_value": 2.45,
        "delta_pct": 0.0, "source_url": "https://app.flopsindex.com/i/FLCI-H100",
    }})
    out = await srv._tool_verify({"index_id": "FLCI-H100"})
    data = json.loads(out)
    assert data["verified"] is True
    assert data["actual_value"] == 2.45


@pytest.mark.asyncio
async def test_verify_requires_index_id():
    out = await srv._tool_verify({})
    data = json.loads(out)
    assert data["reason"] == "missing_arg"


# ---------------------------------------------------------------------
# gpu_capex
# ---------------------------------------------------------------------

@pytest.mark.asyncio
async def test_gpu_capex_single_sku(monkeypatch):
    captured = {}
    def handler(url, params):
        captured["url"] = url
        return {"sku": "h100_sxm5", "price_usd": 28500, "tier": "T1-new",
                "source": "GRVCI v0_benchmark", "effective": "2026-Q2"}
    _install_mock(monkeypatch, {"/v1/refdata/gpu-capex/h100_sxm5": handler})
    out = await srv._tool_gpu_capex({"sku": "h100_sxm5"})
    data = json.loads(out)
    assert data["price_usd"] == 28500
    assert data["effective"] == "2026-Q2"
    assert "h100_sxm5" in captured["url"]


@pytest.mark.asyncio
async def test_gpu_capex_full_map_when_no_sku(monkeypatch):
    captured = {}
    def handler(url, params):
        captured["url"] = url
        return {"meta": {"effective": "2026-Q2"}, "skus": {}, "count": 23}
    # Match the prefix that does NOT have a trailing path segment.
    # _MockAsyncClient matches by `in url`, so we register both — the
    # /{sku} prefix would also match here. Use a distinct sentinel.
    _install_mock(monkeypatch, {"/v1/refdata/gpu-capex": handler})
    out = await srv._tool_gpu_capex({})
    data = json.loads(out)
    assert data["count"] == 23
    assert captured["url"].endswith("/v1/refdata/gpu-capex")


@pytest.mark.asyncio
async def test_gpu_capex_treats_blank_sku_as_full_map(monkeypatch):
    """Whitespace-only sku must NOT be sent as a path segment."""
    captured = {}
    def handler(url, params):
        captured["url"] = url
        return {"count": 23}
    _install_mock(monkeypatch, {"/v1/refdata/gpu-capex": handler})
    await srv._tool_gpu_capex({"sku": "   "})
    assert captured["url"].endswith("/v1/refdata/gpu-capex")
