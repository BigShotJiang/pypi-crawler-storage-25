# flopsindex-mcp

<!-- mcp-name: io.github.zeroatflops/flopsindex-mcp -->

[![PyPI version](https://img.shields.io/pypi/v/flopsindex-mcp.svg)](https://pypi.org/project/flopsindex-mcp/)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/flopsindex-mcp.svg)](https://pypi.org/project/flopsindex-mcp/)
[![PyPI Downloads](https://img.shields.io/pypi/dm/flopsindex-mcp.svg)](https://pypi.org/project/flopsindex-mcp/)
[![Live API](https://img.shields.io/website?label=app.flopsindex.com&url=https%3A%2F%2Fapp.flopsindex.com%2Fv2%2Fcatalog%2Fpublic)](https://app.flopsindex.com/v2/catalog/public)
[![Spec](https://img.shields.io/badge/JSON--LD-v0.1-blue)](https://schema.flopsindex.com/compute-index-spec/v0.1/)
[![Test matrix](https://img.shields.io/badge/test--matrix-post--R7.5-success)](https://github.com/zeroatflops/Flops_Unicron/blob/main/Flops_Unicron/docs/mcp/post-r7.5-test-matrix.md)
[![Docs](https://img.shields.io/badge/docs-docs.flopsindex.com-blue)](https://docs.flopsindex.com/)
[![MCP Registry](https://img.shields.io/badge/MCP%20Registry-mcp--publisher%20ready-success)](https://registry.modelcontextprotocol.io/)

**See also** — full docs [docs.flopsindex.com/sdk/mcp](https://docs.flopsindex.com/sdk/mcp) · agent citation guide [docs.flopsindex.com/integrations/llm-agent-citation-guide](https://docs.flopsindex.com/integrations/llm-agent-citation-guide) · public read SDK [`flopsindex`](https://pypi.org/project/flopsindex/) · partner write SDK [`flopsindex-partner`](https://pypi.org/project/flopsindex-partner/) · spec [schema.flopsindex.com](https://schema.flopsindex.com/) · adopters [schema.flopsindex.com/adopters](https://schema.flopsindex.com/adopters)

Model Context Protocol server for the **FLOPS Compute Intelligence Platform**.

Gives AI agents (Claude Code, Cursor, Windsurf, ChatGPT desktop, any MCP host) direct access to live FLOPS GPU-compute price indices with verifiable provenance.

## Tools

| Tool | Description |
|---|---|
| `list_indices` | Enumerate all public FLOPS indices. Optional `family_filter` substring (e.g. `FLOPS-H100`). |
| `get_price` | Latest published price + tier + confidence for one index. |
| `get_timeseries` | Decimated history (≤200 points) for one index. Range: 24h / 7d / 30d / 90d / 1y. |
| `search_indices` | Free-text search across the public catalog. |
| `verify` | Fetch the latest published value + audit receipt for a given `index_id`. |
| `list_methodologies` | List every published methodology version (FLCI / ITPI / FLOPS-*). |
| `get_methodology` | Fetch a single methodology document — markdown or frontmatter JSON. Citeable. |
| `compute_margin` | Hydrahost spark-spread: `margin = price − chip_power × PUE × $/kWh − rack_amortization`. |
| `recompute_audit` | Receipt for a published value — IOSCO Principle 9+17 substrate. Variance bands green / yellow / red. |

`get_forward_curve` and `get_settlement` are still tracked in the Track D roadmap (CLRI-FWD / CLRI-SETTLED families).

## Install

```bash
uv tool install flopsindex-mcp
# or
pip install flopsindex-mcp
```

## Wire into Claude Code

```bash
claude mcp add flopsindex -- flopsindex-mcp
```

## Wire into Cursor / Windsurf

Add to your MCP config (`~/.cursor/mcp.json` or equivalent):

```json
{
  "mcpServers": {
    "flopsindex": {
      "command": "flopsindex-mcp"
    }
  }
}
```

## Environment

| Var | Default | Purpose |
|---|---|---|
| `FLOPS_API_URL` | `https://app.flopsindex.com` | Override for staging / self-host |

## Example agent prompts

> "Use the flopsindex MCP server to list all H100 on-demand indices and report their latest values."

> "Verify FLOPS-B300-OD-T1 and cite the receipt."

## Status

**v0.4.1** — `gpu_capex` tool added (per-SKU reference street price for a single GPU module — chip + carrier, quarterly-refreshed from GRVCI v0_benchmark + OEM channel reporting). 11 tools total. Backed by the public `/v1/refdata/gpu-capex` endpoint; no auth.

**v0.4.0** — `spread` tool added (time-aligned spread between two index legs with z-score / percentile-rank stats). 10 tools total. Registry listings expanded to 5 channels (added mcp.so + wong2/awesome-mcp-servers) in `LISTINGS.md`. PyPI publish still gated on operator.

**v0.3.0** — `list_methodologies` / `get_methodology` / `compute_margin` / `recompute_audit` added on top of the 5-tool v0.2.0 surface. Registry listings (smithery.ai, glama.ai, modelcontextprotocol/servers) tracked in `LISTINGS.md`. PyPI publish gated on operator (token in keyring).

**v0.1.0** — Published to PyPI 2026-05-13.

## License

Proprietary. © 2026 FLOPS Index.
