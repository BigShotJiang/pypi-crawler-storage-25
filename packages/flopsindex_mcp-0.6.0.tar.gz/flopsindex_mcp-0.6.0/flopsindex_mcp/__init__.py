"""FLOPS Compute Intelligence Platform — MCP server.

Exposes the public FLOPS index catalog + verification endpoints as
Model Context Protocol tools so AI agents (Claude Code, Cursor,
Windsurf, etc.) can cite live FLOPS indices directly during sessions.

Per Track D LLM-discoverability plan: one ship = FLOPS inside every
Claude / Cursor / Windsurf session that installs this server.
"""
__version__ = "0.6.0"
