"""FLOPS MCP server.

Tools (MVP):
  list_indices   — Enumerate all public FLOPS indices (id, family, cadence)
  get_index      — Fetch a single index's current value + methodology pointer
  verify         — Cryptographic / receipt verification for a published value
  get_catalog    — Full reference catalog (paginated)

Backed by the dashboard's auth-free endpoints:
  GET /v2/catalog/public
  GET /v1/verify?index_id=...
  GET /demo/all-indices  (requires basic auth; not exposed via MCP yet)

Run locally:
  uv tool install flopsindex-mcp
  flopsindex-mcp

Or wire into Claude Code:
  claude mcp add flopsindex -- flopsindex-mcp
"""
from __future__ import annotations

import json
import os
from typing import Any

import httpx
from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import TextContent, Tool

DEFAULT_BASE_URL = "https://app.flopsindex.com"
BASE_URL = os.environ.get("FLOPS_API_URL", DEFAULT_BASE_URL).rstrip("/")
HTTP_TIMEOUT_S = 15.0
USER_AGENT = "flopsindex-mcp/0.5.2"

server: Server = Server("flopsindex")


# ---------------------------------------------------------------------------
# Tool declarations (MCP `list_tools`)
# ---------------------------------------------------------------------------

@server.list_tools()
async def list_tools() -> list[Tool]:
    return [
        Tool(
            name="list_indices",
            description=(
                "List all public FLOPS compute-price indices. "
                "Returns a JSON array of {index_id, family, cadence, unit}. "
                "Use this to discover available indices before calling "
                "get_index or verify. No auth required."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "family_filter": {
                        "type": "string",
                        "description": (
                            "Optional family prefix to filter by "
                            "(e.g. 'FLOPS-H100' or 'FLOPS-B300'). "
                            "Case-sensitive substring match."
                        ),
                    },
                },
            },
        ),
        Tool(
            name="verify",
            description=(
                "Verify a FLOPS index value: returns the latest published "
                "value, methodology pointer, source-count, and audit "
                "receipt for the given index_id. Use to cite a FLOPS "
                "index with provenance."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "index_id": {
                        "type": "string",
                        "description": (
                            "FLOPS index identifier "
                            "(e.g. 'FLOPS-H100-OD-T1', 'FLOPS-B300-SPOT')."
                        ),
                    },
                },
                "required": ["index_id"],
            },
        ),
        Tool(
            name="get_price",
            description=(
                "Fetch the current published value for a FLOPS compute "
                "or inference price index. Returns {value, unit, ts, "
                "tier, confidence, verify_url, citation_url}. Cheapest "
                "way to answer 'what does X trade at right now?' "
                "Confidence is HIGH/MED/LOW; tier is LIVE/SETTLED/SEED. "
                "Carries no methodology or source attribution by design."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "slug": {
                        "type": "string",
                        "description": (
                            "FLOPS index slug. Accepts FLOPS-<MODEL>-OD, "
                            "FLOPS-<MODEL>-SPOT, FLOPS-<MODEL>-OD-T1, "
                            "FLOPS-B300-OD-NORDICS, or a bare gpu_model."
                        ),
                    },
                },
                "required": ["slug"],
            },
        ),
        Tool(
            name="get_timeseries",
            description=(
                "Fetch a decimated timeseries (≤200 points) for a FLOPS "
                "index. Use for plotting recent price history or "
                "computing simple trends. Returns ordered [ts, value] "
                "tuples. Range is one of 24h / 7d / 30d / 90d / 1y."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "slug": {"type": "string"},
                    "range": {
                        "type": "string",
                        "enum": ["24h", "7d", "30d", "90d", "1y"],
                        "default": "7d",
                    },
                },
                "required": ["slug"],
            },
        ),
        Tool(
            name="search_indices",
            description=(
                "Resolve a free-text query to canonical FLOPS index slugs. "
                "Use when you don't know the exact slug — e.g. 'H100 spot' "
                "returns the matching SPOT family entries. Best paired "
                "with get_price to look up + quote a value in one turn."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "q": {
                        "type": "string",
                        "description": "Free-text query (e.g. 'b300 nordics on-demand').",
                    },
                    "limit": {
                        "type": "integer",
                        "default": 10,
                        "minimum": 1,
                        "maximum": 50,
                    },
                },
                "required": ["q"],
            },
        ),
        Tool(
            name="list_methodologies",
            description=(
                "List every published methodology version. Methodologies "
                "are the canonical specification documents behind each "
                "index family (FLCI, ITPI, FLOPS-*). Returns {slug, "
                "version, change_class, status, last_updated}. Use to "
                "answer 'what's the latest FLCI-H100 methodology?' or "
                "to discover version history before citing."
            ),
            inputSchema={"type": "object", "properties": {}},
        ),
        Tool(
            name="get_methodology",
            description=(
                "Fetch a single methodology document. Returns frontmatter "
                "(if .json variant requested) or raw markdown. Use to cite "
                "or extract the exact formula behind a FLOPS index. "
                "Always pair an index reference with a methodology version "
                "so the citation is reproducible."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "slug": {
                        "type": "string",
                        "description": (
                            "Methodology slug, e.g. 'flci-h100', "
                            "'flops-h100-od', 'itpi-canonical'."
                        ),
                    },
                    "version": {
                        "type": "string",
                        "description": (
                            "Semver-like version, e.g. 'v0.9'. Omit to "
                            "fetch the listing endpoint and let the agent "
                            "pick the latest."
                        ),
                    },
                    "as_json": {
                        "type": "boolean",
                        "default": False,
                        "description": (
                            "If true, return the frontmatter-parsed JSON "
                            "envelope; if false, return raw markdown."
                        ),
                    },
                },
                "required": ["slug"],
            },
        ),
        Tool(
            name="compute_margin",
            description=(
                "Compute the per-GPU-hour margin for a SKU+region pair. "
                "Formula: margin = price - chip_power × PUE × $/kWh - "
                "rack_amortization. The Hydrahost spark-spread metric. "
                "Returns {price, power_cost, rack_cost, margin, "
                "margin_pct, kwh_source}. kwh_source picks between live "
                "ISO LMP, tariff seed table, and basis-adjusted blends."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "sku": {
                        "type": "string",
                        "description": (
                            "Canonical SKU, e.g. 'h100_sxm5', 'a100_sxm4', "
                            "'b300_sxm7', 'l40s_pcie'."
                        ),
                    },
                    "region": {
                        "type": "string",
                        "description": (
                            "Region code, e.g. 'us_west', 'us_east', "
                            "'eu_north', 'nordics'."
                        ),
                    },
                    "pue": {
                        "type": "number",
                        "description": (
                            "Power Usage Effectiveness override. Default "
                            "uses the regional PUE seed (typically 1.2-1.6)."
                        ),
                    },
                    "kwh_source": {
                        "type": "string",
                        "enum": ["live_lmp", "tariff_seed", "basis_adjusted"],
                        "description": (
                            "Where to pull the $/kWh from. live_lmp "
                            "auto-falls-back to tariff_seed when the ISO "
                            "is dark."
                        ),
                    },
                },
                "required": ["sku", "region"],
            },
        ),
        Tool(
            name="recompute_audit",
            description=(
                "Fetch a recompute-audit receipt for an index value. "
                "Each receipt proves a published price can be regenerated "
                "from the same canonical inputs under the same methodology "
                "version. Status bands: green (≤5bps), yellow (≤50bps), "
                "red (>50bps). IOSCO Principle 9+17 substrate. Returns "
                "{run_id, status, variance_bps, methodology_version, "
                "inputs_hash, replay_value, published_value}."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "index_id": {
                        "type": "string",
                        "description": "Index ID to audit.",
                    },
                    "as_of": {
                        "type": "string",
                        "description": (
                            "Optional ISO 8601 timestamp; defaults to most "
                            "recent receipt. Used to retrieve a specific "
                            "tick's audit trail."
                        ),
                    },
                },
                "required": ["index_id"],
            },
        ),
        Tool(
            name="spread",
            description=(
                "Time-aligned spread between two index legs. Picks two "
                "(gpu_model, index_type) legs, inner-joins them on hourly "
                "buckets with k-anon>=3 floor, and returns the spread "
                "series plus summary statistics (mean, stdev, p25/p50/p75, "
                "z-score-now, percentile-rank-now). Use to ask 'is the "
                "current H100 OD vs SPOT premium rich or cheap vs history?'. "
                "mode=absolute returns A-B; mode=ratio returns A/B."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "a_gpu_model": {
                        "type": "string",
                        "description": (
                            "Leg A gpu_model / model id (e.g. 'H100', "
                            "'B200', 'claude-sonnet-4', 'llama-3.1-70b')."
                        ),
                    },
                    "a_index_type": {
                        "type": "string",
                        "description": (
                            "Leg A index_type — 'on_demand', 'spot', "
                            "'depin', 'clri_fwd_7d', 'clri_fwd_30d', "
                            "'clri_fwd_90d', 'inference_output', "
                            "'inference_input'."
                        ),
                    },
                    "b_gpu_model": {
                        "type": "string",
                        "description": "Leg B gpu_model / model id.",
                    },
                    "b_index_type": {
                        "type": "string",
                        "description": "Leg B index_type.",
                    },
                    "range": {
                        "type": "string",
                        "description": (
                            "Window: '24h', '7d', '30d' (default), '90d', "
                            "or '180d'."
                        ),
                    },
                    "mode": {
                        "type": "string",
                        "description": (
                            "'absolute' (A-B, default) or 'ratio' (A/B). "
                            "Use ratio for inference-token comparisons "
                            "where the units make absolute differences "
                            "harder to read."
                        ),
                    },
                },
                "required": [
                    "a_gpu_model", "a_index_type",
                    "b_gpu_model", "b_index_type",
                ],
            },
        ),
        Tool(
            name="gpu_capex",
            description=(
                "Reference street price for a single GPU module (chip + "
                "carrier, not full DGX/HGX system). Returns a 3-tier "
                "cascade per SKU; router selects the highest-authority "
                "tier that meets its threshold:\n"
                "  T2 LIVE_USASPENDING — median of last 180d US federal "
                "procurement contract awards (USAspending). REAL new-"
                "purchase prices, no markup. Threshold: >=3 awards. "
                "PREFERRED over T1 when both meet threshold.\n"
                "  T1 LIVE_EBAY_X1.15 — trimmed-median of last 30d eBay "
                "completed-listings x 1.15 secondary->new markup. "
                "Threshold: >=5 observations.\n"
                "  T3 SEED — quarterly-refreshed reference (GRVCI "
                "v0_benchmark + OEM channel reporting), always available "
                "as fallback.\n"
                "Response always carries {sku, price_usd, tier, source, "
                "effective, secondary_market_range_usd?}. When LIVE, "
                "ALSO returns live_observations envelope (n_observations, "
                "window_days, source-specific median + markup_applied + "
                "agency_sample for federal / trim_fraction for ebay) + "
                "also_seed audit fallback {price_usd, tier, source, "
                "effective}. Cite also_seed alongside the LIVE primary "
                "in contracts. Without sku arg, returns the full seed "
                "map plus meta.live_api_status documenting which tiers "
                "are wired. No auth required. NOTE: no public LIVE MSRP "
                "API exists for datacenter GPUs — channel-priced through "
                "OEMs. T2 is the closest thing to authoritative new; "
                "T1 is secondary-market x markup; methodology at "
                "https://app.flopsindex.com/methodology/GPU_CAPEX_LIVE_METHODOLOGY.md"
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "sku": {
                        "type": "string",
                        "description": (
                            "FLOPS SKU id (e.g. 'h100_sxm5', 'b200_sxm6', "
                            "'b300_sxm7', 'a100_80gb', 'mi300x'). Omit to "
                            "return the full 23-SKU seed map."
                        ),
                    },
                },
            },
        ),
        Tool(
            name="get_forecast",
            description=(
                "Day-ahead LMP forecast snapshots across every forecast-"
                "capable ISO adapter (CAISO / MISO / PJM / ENTSO-E / JEPX). "
                "Returns {generated_at, snapshots: {iso: {...hubs[]}}, "
                "errors, unconfigured, summary}. Auth-free public Track-D "
                "surface; pair with get_basis for forecast-vs-actual "
                "uncertainty signals in compute-margin sensitivities. If "
                "the public wire-up is still pending, returns {ok: false, "
                "reason: 'endpoint_pending' | 'auth_required'} instead of "
                "raising."
            ),
            inputSchema={"type": "object", "properties": {}},
        ),
        Tool(
            name="get_iso_health_events",
            description=(
                "Last N fetch attempts for a single ISO adapter from the "
                "AdapterCache 200-entry ring buffer. Use to diagnose "
                "whether a feed is currently healthy or has been silently "
                "4xx-ing. Admin-gated — set FLOPSINDEX_ADMIN_API_KEY env "
                "var to authenticate; without it the tool returns "
                "{ok: false, reason: 'auth_required'}."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "name": {
                        "type": "string",
                        "description": (
                            "ISO adapter name (e.g. 'caiso', 'miso', "
                            "'pjm', 'ercot', 'isone', 'nyiso', 'entso_e', "
                            "'jepx')."
                        ),
                    },
                    "limit": {
                        "type": "integer",
                        "default": 50,
                        "minimum": 1,
                        "maximum": 200,
                    },
                },
                "required": ["name"],
            },
        ),
        Tool(
            name="get_basis",
            description=(
                "Forecast-vs-actual basis for one ISO hub. Returns the "
                "signed spread between day-ahead forecast LMP and the "
                "latest RTM settle. Use as a power-cost-uncertainty proxy "
                "in compute-margin sensitivities and CLRI forward-curve "
                "construction. NOTE: the public route wrapper is staked "
                "by Lane 1's forecast_vs_actual_basis helper but pending "
                "a Lane 4 route — returns {ok: false, reason: "
                "'endpoint_pending'} until the surface lands."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "iso": {
                        "type": "string",
                        "description": (
                            "ISO code (caiso, miso, pjm, ercot, isone, "
                            "nyiso, entso_e, jepx)."
                        ),
                    },
                },
                "required": ["iso"],
            },
        ),
        Tool(
            name="get_sla_delta",
            description=(
                "Published-vs-observed provisioning latency for a DePIN "
                "provider (Akash / Render / io.net / Aleph.im / Phala / "
                "Spheron). Underpins FLOPS-SLA-DELTA + the CLRI-DePIN "
                "quality-of-service weighting (methodology slug "
                "'flops-sla-delta@v0.9'). NOTE: the public route wrapper "
                "is staked by Lane 3's SLA-DELTA pipeline but pending a "
                "Lane 4 route — returns {ok: false, reason: "
                "'endpoint_pending'} until the surface lands."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "provider": {
                        "type": "string",
                        "description": (
                            "DePIN provider id (e.g. 'akash', 'render', "
                            "'io_net', 'aleph_im', 'phala', 'spheron')."
                        ),
                    },
                },
                "required": ["provider"],
            },
        ),
        Tool(
            name="get_lmp_history",
            description=(
                "Historical LMP timeseries for one ISO hub. Returns "
                "decimated points (≤500) across the requested window. "
                "Use for basis backtests, forecast-error analyses, and "
                "compute-margin sensitivity studies. Wraps Lane 1's "
                "iso_lmp_history surface (R7 PE). Returns {ok: false, "
                "reason: 'endpoint_pending'} until the public route "
                "lands."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "iso": {
                        "type": "string",
                        "description": (
                            "ISO code (caiso, miso, pjm, ercot, isone, "
                            "nyiso, entso_e, jepx)."
                        ),
                    },
                    "hub": {
                        "type": "string",
                        "description": (
                            "Optional hub identifier (e.g. 'SP15' for "
                            "CAISO, 'INDIANA.HUB' for MISO). Omit to "
                            "default to the ISO's primary settlement hub."
                        ),
                    },
                    "range": {
                        "type": "string",
                        "enum": ["24h", "7d", "30d", "90d", "1y"],
                        "default": "7d",
                    },
                },
                "required": ["iso"],
            },
        ),
        Tool(
            name="get_arbitrage_windows",
            description=(
                "Compute-arbitrage windows: time-of-day periods when "
                "spot vs on-demand spread exceeds a threshold, signaling "
                "an interruptible-workload migration opportunity. Wraps "
                "Lane 3's analyze_arbitrage_windows pipeline (R7 PC). "
                "Returns ranked {window_start, window_end, expected_savings_pct, "
                "confidence} entries. Returns {ok: false, reason: "
                "'endpoint_pending'} until the public route lands."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "sku": {
                        "type": "string",
                        "description": (
                            "GPU SKU (e.g. 'h100_sxm5', 'a100_sxm4', "
                            "'b300_sxm7')."
                        ),
                    },
                    "region": {
                        "type": "string",
                        "description": "Region code (e.g. 'us_west', 'eu_north').",
                    },
                    "min_savings_pct": {
                        "type": "number",
                        "default": 0.15,
                        "description": (
                            "Minimum savings threshold (0-1). Default 0.15 "
                            "= 15%. Lower thresholds return more windows."
                        ),
                    },
                },
                "required": ["sku", "region"],
            },
        ),
        Tool(
            name="get_forecast_accuracy",
            description=(
                "Backtest accuracy for forecast values vs realized "
                "settles. Returns {iso, hub, window_days, mae, rmse, "
                "mape, n_samples, sample_basis: [...]} per hub. "
                "Optional `region` kwarg (L1 R10 Part E) restricts to a "
                "canonical region tag (us-west|us-east|us-central|"
                "us-northeast|ercot|ca-west|ca-east|apac|eu-west)."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "iso": {
                        "type": "string",
                        "description": "ISO code.",
                    },
                    "window_days": {
                        "type": "integer",
                        "default": 30,
                        "minimum": 1,
                        "maximum": 365,
                    },
                    "region": {
                        "type": "string",
                        "description": (
                            "Optional canonical region tag (us-west, "
                            "us-east, ..., eu-west). See "
                            "_region_lookup.CANONICAL_REGIONS."
                        ),
                    },
                },
                "required": ["iso"],
            },
        ),
    ]


# ---------------------------------------------------------------------------
# Tool implementations (MCP `call_tool`)
# ---------------------------------------------------------------------------

async def _get_json(path: str, params: dict[str, Any] | None = None) -> Any:
    async with httpx.AsyncClient(
        timeout=HTTP_TIMEOUT_S,
        headers={"User-Agent": USER_AGENT, "Accept": "application/json"},
    ) as c:
        r = await c.get(f"{BASE_URL}{path}", params=params)
        r.raise_for_status()
        return r.json()


async def _defensive_get(
    path: str,
    params: dict[str, Any] | None = None,
    *,
    headers: dict[str, str] | None = None,
) -> Any:
    """Fetch JSON with a defensive ok:false envelope on failure.

    Used by tools that wrap Lane-staked endpoints whose routes may be
    pending wire-up (Lane 4 _ALLOW_PREFIXES), admin-gated, or currently
    upstream-broken (see /v1/verify 500 at 2026-05-19 grounding). Agents
    receive a structured error envelope instead of an MCP tool exception
    — the verify-handshake protocol position depends on this never
    blowing up downstream.
    """
    full = f"{BASE_URL}{path}"
    merged_headers = {
        "User-Agent": USER_AGENT,
        "Accept": "application/json",
        **(headers or {}),
    }
    try:
        async with httpx.AsyncClient(
            timeout=HTTP_TIMEOUT_S,
            headers=merged_headers,
        ) as c:
            r = await c.get(full, params=params)
            code = r.status_code
            if 200 <= code < 300:
                try:
                    return r.json()
                except ValueError:
                    return {"ok": False, "reason": "invalid_json",
                            "upstream_status": code, "url": full}
            if code == 401 or code == 403:
                return {"ok": False, "reason": "auth_required",
                        "upstream_status": code, "url": full,
                        "hint": ("endpoint pending public wire-up OR "
                                 "admin api-key required")}
            if code == 404:
                return {"ok": False, "reason": "endpoint_pending",
                        "upstream_status": code, "url": full,
                        "hint": ("Lane 4 route wrapper not yet shipped "
                                 "— retry after the next rollup deploy")}
            if code >= 500:
                return {"ok": False, "reason": "upstream_http_error",
                        "upstream_status": code, "url": full}
            return {"ok": False, "reason": "client_error",
                    "upstream_status": code, "url": full,
                    "detail": r.text[:500]}
    except Exception as exc:  # noqa: BLE001
        return {"ok": False, "reason": "network_error",
                "url": full, "detail": str(exc)[:300]}


async def _tool_list_indices(args: dict[str, Any]) -> str:
    family = (args.get("family_filter") or "").strip() or None
    data = await _get_json("/v2/catalog/public")
    indices = data.get("indices") if isinstance(data, dict) else data
    if not isinstance(indices, list):
        indices = []
    if family:
        indices = [i for i in indices if family in (i.get("index_id") or "")]
    return json.dumps({
        "count": len(indices),
        "family_filter": family,
        "indices": indices,
        "source": f"{BASE_URL}/v2/catalog/public",
    }, indent=2)


async def _tool_verify(args: dict[str, Any]) -> str:
    index_id = (args.get("index_id") or "").strip()
    if not index_id:
        return json.dumps({"ok": False, "reason": "missing_arg",
                           "detail": "index_id is required"})
    data = await _defensive_get("/v1/verify", params={"index_id": index_id})
    return json.dumps(data, indent=2)


async def _tool_get_price(args: dict[str, Any]) -> str:
    slug = (args.get("slug") or "").strip()
    if not slug:
        return json.dumps({"error": "slug is required"})
    data = await _get_json(f"/v1/price/{slug}")
    return json.dumps(data, indent=2)


async def _tool_get_timeseries(args: dict[str, Any]) -> str:
    slug = (args.get("slug") or "").strip()
    if not slug:
        return json.dumps({"error": "slug is required"})
    rng = (args.get("range") or "7d").strip()
    data = await _get_json(f"/v1/ts/{slug}", params={"range": rng})
    return json.dumps(data, indent=2)


async def _tool_search_indices(args: dict[str, Any]) -> str:
    q = (args.get("q") or "").strip()
    if not q:
        return json.dumps({"error": "q is required"})
    limit = int(args.get("limit") or 10)
    data = await _get_json("/v1/search", params={"q": q, "limit": limit})
    return json.dumps(data, indent=2)


async def _tool_list_methodologies(_args: dict[str, Any]) -> str:
    data = await _get_json("/v1/methodology")
    return json.dumps(data, indent=2)


async def _tool_get_methodology(args: dict[str, Any]) -> str:
    slug = (args.get("slug") or "").strip()
    if not slug:
        return json.dumps({"error": "slug is required"})
    version = (args.get("version") or "").strip()
    as_json = bool(args.get("as_json", False))
    if not version:
        # No version pinned — fall through to the listing endpoint so
        # the agent can choose the latest available.
        data = await _get_json(f"/v1/methodology/{slug}/versions")
        return json.dumps(data, indent=2)
    suffix = ".json" if as_json else ""
    if as_json:
        data = await _get_json(f"/v1/methodology/{slug}/{version}.json")
        return json.dumps(data, indent=2)
    # Raw markdown — return as a string envelope so MCP TextContent
    # downstream renders correctly.
    async with httpx.AsyncClient(
        timeout=HTTP_TIMEOUT_S,
        headers={"User-Agent": USER_AGENT, "Accept": "text/markdown"},
    ) as c:
        r = await c.get(f"{BASE_URL}/v1/methodology/{slug}/{version}{suffix}")
        r.raise_for_status()
        return json.dumps({
            "slug": slug,
            "version": version,
            "format": "markdown",
            "content": r.text,
        }, indent=2)


async def _tool_compute_margin(args: dict[str, Any]) -> str:
    sku = (args.get("sku") or "").strip()
    region = (args.get("region") or "").strip()
    if not sku:
        return json.dumps({"error": "sku is required"})
    if not region:
        return json.dumps({"error": "region is required"})
    params: dict[str, Any] = {"sku": sku, "region": region}
    if args.get("pue") is not None:
        params["pue"] = args["pue"]
    if args.get("kwh_source"):
        params["kwh_source"] = args["kwh_source"]
    data = await _get_json("/v1/derived/compute-margin", params=params)
    return json.dumps(data, indent=2)


async def _tool_recompute_audit(args: dict[str, Any]) -> str:
    index_id = (args.get("index_id") or "").strip()
    if not index_id:
        return json.dumps({"error": "index_id is required"})
    params: dict[str, Any] = {"index_id": index_id}
    if args.get("as_of"):
        params["as_of"] = args["as_of"]
    data = await _get_json("/v1/audit/recompute", params=params)
    return json.dumps(data, indent=2)


async def _tool_gpu_capex(args: dict[str, Any]) -> str:
    """Per-SKU GPU module reference street price.

    Backed by /v1/refdata/gpu-capex[/{sku}]. Public surface — no auth.
    Quarterly-refreshed reference, not a settlement value; agents should
    cite the `effective` field when quoting.
    """
    sku = (args.get("sku") or "").strip()
    if sku:
        data = await _get_json(f"/v1/refdata/gpu-capex/{sku}")
    else:
        data = await _get_json("/v1/refdata/gpu-capex")
    return json.dumps(data, indent=2)


async def _tool_spread(args: dict[str, Any]) -> str:
    """Time-aligned spread between two index legs."""
    required = ("a_gpu_model", "a_index_type", "b_gpu_model", "b_index_type")
    missing = [k for k in required if not (args.get(k) or "").strip()]
    if missing:
        return json.dumps({"error": "missing required fields",
                           "missing": missing})
    params: dict[str, Any] = {
        "a_gpu_model": args["a_gpu_model"].strip(),
        "a_index_type": args["a_index_type"].strip(),
        "b_gpu_model": args["b_gpu_model"].strip(),
        "b_index_type": args["b_index_type"].strip(),
    }
    if args.get("range"):
        params["range"] = args["range"]
    if args.get("mode"):
        params["mode"] = args["mode"]
    data = await _get_json("/v1/derived/spread", params=params)
    # Truncate the points array — agents care about stats + first/last
    # points, not 720 hourly rows in one reply.
    if isinstance(data, dict) and isinstance(data.get("points"), list):
        pts = data["points"]
        if len(pts) > 24:
            data["points"] = pts[:12] + [{"_truncated":
                f"{len(pts) - 24} middle points omitted; "
                "use /v1/derived/spread directly for full series"}] + pts[-12:]
    return json.dumps(data, indent=2)


async def _tool_get_forecast(_args: dict[str, Any]) -> str:
    """Cross-adapter day-ahead forecast snapshot. Defensive envelope on
    failure — the public `/v1/forecasts` route's `_ALLOW_PREFIXES`
    wire-up is pending Lane 4 at R5 grounding time, so callers may see
    `{ok: false, reason: 'auth_required'}` until that ships.
    """
    data = await _defensive_get("/v1/forecasts")
    return json.dumps(data, indent=2)


async def _tool_get_iso_health_events(args: dict[str, Any]) -> str:
    name = (args.get("name") or "").strip()
    if not name:
        return json.dumps({"ok": False, "reason": "missing_arg",
                           "detail": "name is required"})
    raw = args.get("limit")
    try:
        limit = 50 if raw is None else int(raw)
    except (TypeError, ValueError):
        limit = 50
    limit = max(1, min(200, limit))
    headers: dict[str, str] = {}
    admin_key = os.environ.get("FLOPSINDEX_ADMIN_API_KEY")
    if admin_key:
        headers["X-FLOPS-Api-Key"] = admin_key
    data = await _defensive_get(
        f"/v1/admin/iso-health/{name}/events",
        params={"limit": limit},
        headers=headers,
    )
    return json.dumps(data, indent=2)


async def _tool_get_basis(args: dict[str, Any]) -> str:
    iso = (args.get("iso") or "").strip()
    if not iso:
        return json.dumps({"ok": False, "reason": "missing_arg",
                           "detail": "iso is required"})
    data = await _defensive_get(f"/v1/forecasts/basis/{iso}")
    return json.dumps(data, indent=2)


async def _tool_get_sla_delta(args: dict[str, Any]) -> str:
    provider = (args.get("provider") or "").strip()
    if not provider:
        return json.dumps({"ok": False, "reason": "missing_arg",
                           "detail": "provider is required"})
    data = await _defensive_get(
        "/v1/forensics/sla/rankings",
        params={"provider": provider},
    )
    return json.dumps(data, indent=2)


async def _tool_get_lmp_history(args: dict[str, Any]) -> str:
    """Historical LMP timeseries for one ISO hub. Wraps Lane 1 R7 PE
    surface; defensive envelope until the public route lands."""
    iso = (args.get("iso") or "").strip()
    if not iso:
        return json.dumps({"ok": False, "reason": "missing_arg",
                           "detail": "iso is required"})
    params: dict[str, Any] = {"iso": iso}
    if args.get("hub"):
        params["hub"] = args["hub"]
    if args.get("range"):
        params["range"] = args["range"]
    data = await _defensive_get("/v1/forecasts/lmp-history", params=params)
    return json.dumps(data, indent=2)


async def _tool_get_arbitrage_windows(args: dict[str, Any]) -> str:
    """Time-of-day arbitrage windows for compute migration. Wraps Lane 3
    R7 PC; defensive envelope until public route lands."""
    sku = (args.get("sku") or "").strip()
    region = (args.get("region") or "").strip()
    if not sku or not region:
        return json.dumps({"ok": False, "reason": "missing_arg",
                           "detail": "sku and region are required"})
    params: dict[str, Any] = {"sku": sku, "region": region}
    if args.get("min_savings_pct") is not None:
        params["min_savings_pct"] = args["min_savings_pct"]
    data = await _defensive_get("/v1/forensics/arbitrage/windows", params=params)
    return json.dumps(data, indent=2)


async def _tool_get_forecast_accuracy(args: dict[str, Any]) -> str:
    """Backtest accuracy for forecast values vs realized settles.
    Defensive envelope — Lane 1 helper landing this round.

    Optional `region` kwarg threads through to /v1/forecasts/accuracy?region=
    (L1 R10 Part E)."""
    iso = (args.get("iso") or "").strip()
    if not iso:
        return json.dumps({"ok": False, "reason": "missing_arg",
                           "detail": "iso is required"})
    params: dict[str, Any] = {"iso": iso}
    if args.get("window_days") is not None:
        try:
            window = int(args["window_days"])
        except (TypeError, ValueError):
            window = 30
        params["window_days"] = max(1, min(365, window))
    region = (args.get("region") or "").strip()
    if region:
        params["region"] = region
    data = await _defensive_get("/v1/forecasts/accuracy", params=params)
    return json.dumps(data, indent=2)


@server.call_tool()
async def call_tool(name: str, args: dict[str, Any]) -> list[TextContent]:
    try:
        if name == "list_indices":
            out = await _tool_list_indices(args)
        elif name == "verify":
            out = await _tool_verify(args)
        elif name == "get_price":
            out = await _tool_get_price(args)
        elif name == "get_timeseries":
            out = await _tool_get_timeseries(args)
        elif name == "search_indices":
            out = await _tool_search_indices(args)
        elif name == "list_methodologies":
            out = await _tool_list_methodologies(args)
        elif name == "get_methodology":
            out = await _tool_get_methodology(args)
        elif name == "compute_margin":
            out = await _tool_compute_margin(args)
        elif name == "recompute_audit":
            out = await _tool_recompute_audit(args)
        elif name == "spread":
            out = await _tool_spread(args)
        elif name == "gpu_capex":
            out = await _tool_gpu_capex(args)
        elif name == "get_forecast":
            out = await _tool_get_forecast(args)
        elif name == "get_iso_health_events":
            out = await _tool_get_iso_health_events(args)
        elif name == "get_basis":
            out = await _tool_get_basis(args)
        elif name == "get_sla_delta":
            out = await _tool_get_sla_delta(args)
        elif name == "get_lmp_history":
            out = await _tool_get_lmp_history(args)
        elif name == "get_arbitrage_windows":
            out = await _tool_get_arbitrage_windows(args)
        elif name == "get_forecast_accuracy":
            out = await _tool_get_forecast_accuracy(args)
        else:
            out = json.dumps({"error": f"unknown tool: {name}"})
    except httpx.HTTPStatusError as exc:
        out = json.dumps({
            "error": "upstream_http_error",
            "status": exc.response.status_code,
            "url": str(exc.request.url),
        })
    except Exception as exc:  # noqa: BLE001
        out = json.dumps({"error": "tool_failed", "detail": str(exc)})
    return [TextContent(type="text", text=out)]


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

async def _run() -> None:
    async with stdio_server() as (read_stream, write_stream):
        await server.run(
            read_stream,
            write_stream,
            server.create_initialization_options(),
        )


def main() -> None:
    import asyncio
    asyncio.run(_run())


if __name__ == "__main__":
    main()
