"""Tests for AppleScript integration module.

These tests only run on macOS where AppleScript is available.
They test the actual Music app integration.
"""

import os
import pytest
import sys
import time

# Skip all tests if not on macOS. Most tests in this file shell out to
# osascript and exercise live Music.app state — they're necessarily slow
# and macOS-only. Specific test classes that DON'T require live state
# (TestUISearchParsing, TestUIPrimitives, TestClassifyAsError, TestGetSearchField,
# TestCheckUiAccessible, etc.) override this with their own faster marker.
pytestmark = pytest.mark.skipif(
    sys.platform != "darwin", reason="AppleScript tests only run on macOS"
)

from applemusic_mcp import applescript as asc


class TestAppleScriptAvailability:
    """Test AppleScript availability detection."""

    def test_is_available_on_macos(self):
        """Should return True on macOS."""
        assert asc.is_available() is True

    def test_run_applescript_simple(self):
        """Should run simple AppleScript."""
        success, output = asc.run_applescript('return "hello"')
        assert success is True
        assert output == "hello"

    def test_run_applescript_math(self):
        """Should handle AppleScript expressions."""
        success, output = asc.run_applescript("return 2 + 2")
        assert success is True
        assert output == "4"

    def test_run_applescript_error(self):
        """Should handle AppleScript errors gracefully."""
        success, output = asc.run_applescript("this is not valid applescript")
        assert success is False
        assert len(output) > 0  # Should have error message


class TestPlaybackControl:
    """Test playback control functions."""

    def test_get_player_state(self):
        """Should get player state."""
        success, state = asc.get_player_state()
        assert success is True
        assert state in ("stopped", "playing", "paused")

    def test_get_volume(self):
        """Should get volume level."""
        success, volume = asc.get_volume()
        assert success is True
        assert isinstance(volume, int)
        assert 0 <= volume <= 100

    def test_get_shuffle(self):
        """Should get shuffle state."""
        success, shuffle = asc.get_shuffle()
        assert success is True
        assert isinstance(shuffle, bool)

    def test_get_repeat(self):
        """Should get repeat mode."""
        success, repeat = asc.get_repeat()
        assert success is True
        assert repeat in ("off", "one", "all")

    def test_get_current_track_when_stopped(self):
        """Should handle stopped state gracefully."""
        success, info = asc.get_current_track()
        assert success is True
        # Either has track info or shows stopped
        assert isinstance(info, dict)


class TestPlaylistOperations:
    """Test playlist operations."""
    pytestmark = pytest.mark.slow


    def test_get_playlists(self):
        """Should get list of playlists."""
        success, playlists = asc.get_playlists()
        assert success is True
        assert isinstance(playlists, list)
        assert len(playlists) > 0

        # Check playlist structure
        p = playlists[0]
        assert "name" in p
        assert "id" in p
        assert "smart" in p
        assert "track_count" in p

    def test_get_playlist_tracks(self):
        """Should get tracks from a known playlist."""
        # First get a playlist name
        success, playlists = asc.get_playlists()
        assert success is True
        assert len(playlists) > 0

        # Skip special/smart playlists that could be huge (Music, Music Videos, etc)
        special_names = {"Music", "Music Videos", "Library", "Favorite Songs"}

        # Get tracks from first non-empty, non-special playlist
        for p in playlists:
            if p["track_count"] > 0 and p["track_count"] < 1000 and p["name"] not in special_names:
                success, tracks = asc.get_playlist_tracks(p["name"])
                assert success is True
                assert isinstance(tracks, list)
                if tracks:
                    t = tracks[0]
                    assert "name" in t
                    assert "artist" in t
                    assert "album" in t
                    assert "id" in t
                break

    def test_get_playlist_tracks_not_found(self):
        """Should handle missing playlist gracefully."""
        success, result = asc.get_playlist_tracks("__NONEXISTENT_PLAYLIST_12345__")
        assert success is False
        assert "not found" in result.lower()

    def test_create_and_delete_playlist(self):
        """Should create and delete a playlist."""
        test_name = "_TEST_PLAYLIST_DELETE_ME_"

        # Music.app cheerfully allows duplicate playlist names. If a prior
        # test run failed before its delete step (or was interrupted), a
        # leftover instance will still be there — and create_playlist will
        # add ANOTHER one alongside it. Drain any leftovers first so this
        # test is hermetic regardless of prior state.
        ok, playlists = asc.get_playlists()
        if ok:
            for _ in range(sum(1 for p in playlists if p.get("name") == test_name)):
                asc.delete_playlist(test_name)

        # Create
        success, playlist_id = asc.create_playlist(test_name, "Test description")
        assert success is True
        assert len(playlist_id) > 0

        # Verify it exists (and is the only one — confirms the pre-clean worked)
        success, playlists = asc.get_playlists()
        assert success is True
        names = [p["name"] for p in playlists]
        assert test_name in names
        assert names.count(test_name) == 1

        # Delete
        success, msg = asc.delete_playlist(test_name)
        assert success is True

        # Verify deleted
        success, playlists = asc.get_playlists()
        names = [p["name"] for p in playlists]
        assert test_name not in names


class TestFolderOperations:
    """Test folder operations."""
    pytestmark = pytest.mark.slow


    def test_create_and_delete_folder(self):
        """Should create and delete a folder playlist."""
        test_name = "_TEST_FOLDER_DELETE_ME_"

        # Create
        success, folder_id = asc.create_folder(test_name)
        assert success is True
        assert len(folder_id) > 0

        # Delete
        success, msg = asc.delete_folder(test_name)
        assert success is True

    def test_rename_folder(self):
        """Should rename a folder via the generic rename_playlist function."""
        test_name = "_TEST_RENAME_FOLDER_"
        new_name = "_TEST_RENAME_FOLDER_NEW_"

        success, _ = asc.create_folder(test_name)
        assert success is True

        # Rename using the generic function (should find folder playlists)
        success, msg = asc.rename_playlist(test_name, new_name)
        assert success is True
        assert new_name in msg

        # Cleanup
        asc.delete_folder(new_name)

    def test_delete_folder_via_generic_delete(self):
        """Should delete a folder via the generic delete_playlist function."""
        test_name = "_TEST_DEL_FOLDER_GENERIC_"

        success, _ = asc.create_folder(test_name)
        assert success is True

        # Delete using the generic function (should find folder playlists)
        success, msg = asc.delete_playlist(test_name)
        assert success is True

    def test_move_playlist_to_folder(self):
        """Should move a playlist into a folder."""
        folder_name = "_TEST_MOVE_FOLDER_"
        playlist_name = "_TEST_MOVE_PL_"

        success, _ = asc.create_folder(folder_name)
        assert success is True
        success, _ = asc.create_playlist(playlist_name)
        assert success is True

        # Move
        success, msg = asc.move_to_folder(playlist_name, folder_name)
        assert success is True

        # Verify path — should be "folder/playlist"
        success, path = asc.get_playlist_path(playlist_name)
        assert success is True
        assert path == f"{folder_name}/{playlist_name}"

        # Cleanup
        asc.delete_playlist(playlist_name)
        asc.delete_folder(folder_name)

    def test_create_nested_folder_path(self):
        """Should create nested folders via slash-separated path."""
        # Pre-clean all stale instances (multiple may accumulate from failed runs)
        for _ in range(5):
            asc.delete_folder("_TEST_OUTER_/_TEST_INNER_")
            asc.delete_folder("_TEST_OUTER_")
            asc.delete_folder("_TEST_INNER_")

        path = "_TEST_OUTER_/_TEST_INNER_"

        success, folder_id = asc.create_folder_path(path)
        assert success is True
        assert len(folder_id) > 0

        # Verify inner folder exists and is nested
        success, resolved_path = asc.get_playlist_path("_TEST_INNER_")
        assert success is True
        assert "_TEST_OUTER_" in resolved_path

        # Cleanup (inner first, then outer)
        asc.delete_folder("_TEST_OUTER_/_TEST_INNER_")
        asc.delete_folder("_TEST_OUTER_")

    def test_move_to_root(self):
        """Should move a playlist out of a folder to root."""
        folder_name = "_TEST_ROOT_FOLDER_"
        playlist_name = "_TEST_ROOT_PL_"

        success, _ = asc.create_folder(folder_name)
        assert success is True
        success, _ = asc.create_playlist(playlist_name)
        assert success is True

        # Move into folder
        success, _ = asc.move_to_folder(playlist_name, folder_name)
        assert success is True

        # Move back to root
        success, msg = asc.move_to_root(playlist_name)
        assert success is True

        # Verify it's at root (path should just be the playlist name)
        success, path = asc.get_playlist_path(playlist_name)
        assert success is True
        assert "/" not in path  # No folder prefix = at root

        # Cleanup
        asc.delete_playlist(playlist_name)
        asc.delete_folder(folder_name)

    def test_get_playlist_path(self):
        """Should return full path for nested playlist."""
        folder_name = "_TEST_PATH_FOLDER_"
        playlist_name = "_TEST_PATH_PL_"

        success, _ = asc.create_folder(folder_name)
        assert success is True
        success, _ = asc.create_playlist(playlist_name)
        assert success is True
        success, _ = asc.move_to_folder(playlist_name, folder_name)
        assert success is True

        success, path = asc.get_playlist_path(playlist_name)
        assert success is True
        assert path == f"{folder_name}/{playlist_name}"

        # Cleanup
        asc.delete_playlist(playlist_name)
        asc.delete_folder(folder_name)

    def test_get_folder_tree(self):
        """Should return folder hierarchy text."""
        folder_name = "_TEST_TREE_FOLDER_"

        # Pre-clean in case a prior run failed before cleanup
        asc.delete_folder(folder_name)

        success, _ = asc.create_folder(folder_name)
        assert success is True

        success, tree = asc.get_folder_tree()
        assert success is True
        assert folder_name in tree

        # Cleanup
        asc.delete_folder(folder_name)


class TestLibrarySearch:
    """Test library search functions."""
    pytestmark = pytest.mark.slow


    def test_search_library_all(self):
        """Should search entire library."""
        success, results = asc.search_library("love")
        assert success is True
        assert isinstance(results, list)
        # Should find something with "love" in a reasonable library
        assert len(results) >= 0

    def test_search_library_artists(self):
        """Should search by artist."""
        success, results = asc.search_library("Beatles", "artists")
        assert success is True
        assert isinstance(results, list)

    def test_search_library_structure(self):
        """Should return properly structured results."""
        success, results = asc.search_library("the")
        assert success is True
        if results:
            t = results[0]
            assert "name" in t
            assert "artist" in t
            assert "album" in t
            assert "duration" in t
            assert "id" in t


class TestGetLibrarySongsPage:
    """Integration tests for get_library_songs_page (O(limit) range access)."""

    def test_returns_correct_shape(self):
        success, tracks, total, error = asc.get_library_songs_page(offset=0, limit=5)
        assert success is True
        assert isinstance(tracks, list)
        assert isinstance(total, int)
        assert error == ""

    def test_total_reflects_full_library(self):
        _, _, total_page, _ = asc.get_library_songs_page(offset=0, limit=5)
        _, _, total_all, _ = asc.get_library_songs_page(offset=0, limit=1)
        assert total_page == total_all

    def test_offset_returns_different_tracks(self):
        _, page0, _, _ = asc.get_library_songs_page(offset=0, limit=5)
        _, page1, _, _ = asc.get_library_songs_page(offset=5, limit=5)
        if page0 and page1:
            assert page0[0]["id"] != page1[0]["id"]

    def test_offset_beyond_total_returns_empty(self):
        success, tracks, total, error = asc.get_library_songs_page(offset=999999, limit=10)
        assert success is True
        assert tracks == []
        assert total >= 0
        assert error == ""

    def test_track_fields_present(self):
        success, tracks, _, _ = asc.get_library_songs_page(offset=0, limit=3)
        assert success is True
        if tracks:
            t = tracks[0]
            for field in ("name", "artist", "album", "duration", "id"):
                assert field in t


class TestLibraryStats:
    """Test library statistics."""
    pytestmark = pytest.mark.slow


    def test_get_library_stats(self):
        """Should get library statistics."""
        success, stats = asc.get_library_stats()
        assert success is True
        assert isinstance(stats, dict)
        assert "track_count" in stats
        assert "playlist_count" in stats
        assert "player_state" in stats
        assert "shuffle" in stats
        assert "repeat" in stats
        assert "volume" in stats

        assert isinstance(stats["track_count"], int)
        assert stats["track_count"] >= 0
        assert isinstance(stats["shuffle"], bool)


class TestAirPlay:
    """Test AirPlay functions."""

    def test_get_airplay_devices(self):
        """Should get AirPlay devices list."""
        success, devices = asc.get_airplay_devices()
        assert success is True
        assert isinstance(devices, list)
        # At minimum, the local computer should be available


class TestTrackMetadata:
    """Test track metadata operations."""

    def test_set_repeat_invalid(self):
        """Should reject invalid repeat mode."""
        success, msg = asc.set_repeat("invalid_mode")
        assert success is False
        assert "invalid" in msg.lower()


class TestInputSanitization:
    """Test that user input is properly sanitized to prevent injection."""

    def test_quote_escaping_in_playlist_name(self):
        """Should properly escape quotes in playlist names."""
        # Attempt to create a playlist with quotes in the name
        # This would break the AppleScript if not properly escaped
        test_name = '_TEST_QUOTES_"escape"_test_'

        # Create should not crash (quotes are escaped)
        success, result = asc.create_playlist(test_name)

        # Cleanup if it worked
        if success:
            asc.delete_playlist(test_name)

        # The main test is that we didn't crash/error on quote handling
        # Success depends on whether the playlist was actually created
        assert isinstance(success, bool)
        assert isinstance(result, str)

    def test_special_characters_in_search(self):
        """Should handle special characters in search queries."""
        # These characters should not cause AppleScript errors
        special_queries = [
            "test'quote",
            "test&ampersand",
            "test<angle>",
            "test\\backslash",
        ]
        for query in special_queries:
            # Should not raise an exception
            success, result = asc.search_library(query)
            assert isinstance(success, bool)


class TestRemoveFromLibrary:
    """Test remove_from_library function."""
    pytestmark = pytest.mark.slow


    def test_remove_nonexistent_track(self):
        """Should return error for track not in library."""
        success, result = asc.remove_from_library("__NONEXISTENT_TRACK_12345__")
        assert success is False
        assert "not found" in result.lower()

    def test_remove_from_library_returns_tuple(self):
        """Should return (success, message) tuple."""
        success, result = asc.remove_from_library("test")
        assert isinstance(success, bool)
        assert isinstance(result, str)


class TestOpenCatalogSong:
    """Test open_catalog_song function."""
    pytestmark = pytest.mark.slow


    def test_open_catalog_song_returns_tuple(self, monkeypatch):
        """Should return (success, message) tuple for valid Apple Music URL."""
        # Mock subprocess to avoid launching Music
        import subprocess

        monkeypatch.setattr(subprocess, "run", lambda *args, **kwargs: None)

        success, result = asc.open_catalog_song("https://music.apple.com/us/song/1234567890")
        assert isinstance(success, bool)
        assert isinstance(result, str)

    def test_open_catalog_song_rejects_empty_url(self):
        """Should reject empty URL."""
        success, result = asc.open_catalog_song("")
        assert success is False
        assert "empty" in result.lower() or "invalid" in result.lower()

    def test_open_catalog_song_rejects_non_apple_url(self):
        """Should reject URLs that aren't from Apple Music."""
        success, result = asc.open_catalog_song("https://spotify.com/track/123")
        assert success is False
        assert "not an apple music url" in result.lower()

    def test_open_catalog_song_rejects_invalid_format(self):
        """Should reject strings that aren't valid URLs."""
        success, result = asc.open_catalog_song("just-a-random-string")
        assert success is False
        assert "invalid url format" in result.lower()

    def test_open_catalog_song_accepts_music_scheme(self, monkeypatch):
        """Should accept music:// scheme URLs."""
        # Mock subprocess to avoid launching Music
        import subprocess

        monkeypatch.setattr(subprocess, "run", lambda *args, **kwargs: None)

        success, result = asc.open_catalog_song("music://music.apple.com/us/song/1234567890")
        assert isinstance(success, bool)
        assert isinstance(result, str)
        # If it fails, should not be a format rejection
        if not success:
            assert "invalid url format" not in result.lower()
            assert "not an apple music url" not in result.lower()


class TestAddTrackDisambiguation:
    """Test artist exact match and album disambiguation in add_track_to_playlist.

    These tests require specific tracks in the library:
    - Hot Potato by The Wiggles (Ready, Steady, Wiggle!)
    - Hot Potato by Dorothy the Dinosaur & The Wiggles (Dorothy The Dinosaur's Travelling Show)
    """
    pytestmark = pytest.mark.slow


    TEST_PLAYLIST = "🧪 Integration Test Playlist"

    def setup_method(self):
        """Auto-create the test playlist if missing (e.g. iCloud sync deleted it).
        Without this, all tests in this class fail with cryptic 'add failed'
        errors when the playlist isn't present."""
        ok, _ = asc.run_applescript(f"""
tell application "Music"
    set found to false
    try
        set p to first user playlist whose name is "{self.TEST_PLAYLIST}"
        set found to true
    end try
    if not found then
        make new playlist with properties {{name:"{self.TEST_PLAYLIST}"}}
    end if
end tell""")

    @classmethod
    def teardown_class(cls):
        """Delete the test playlist after the whole class finishes so we
        don't leave debris in the user's Music library. Best-effort."""
        try:
            asc.run_applescript(f"""
tell application "Music"
    try
        delete (first user playlist whose name is "{cls.TEST_PLAYLIST}")
    end try
end tell""")
        except Exception:
            pass

    def test_artist_exact_match_preferred_over_contains(self):
        """Should prefer exact artist match over partial contains match.

        'artist is "The Wiggles"' should match solo Wiggles,
        not 'Dorothy the Dinosaur & The Wiggles'.
        """
        success, result = asc.add_track_to_playlist(self.TEST_PLAYLIST, "Hot Potato", "The Wiggles")
        assert success is True
        # Should be the solo Wiggles version, not Dorothy collab
        assert "Dorothy" not in result
        assert "Ready, Steady, Wiggle!" in result

        # Cleanup
        asc.remove_track_from_playlist(self.TEST_PLAYLIST, "Hot Potato")

    def test_album_disambiguation_selects_correct_version(self):
        """Should use album param to disambiguate between track versions."""
        success, result = asc.add_track_to_playlist(
            self.TEST_PLAYLIST, "Hot Potato", "The Wiggles", "Ready, Steady"
        )
        assert success is True
        assert "Ready, Steady, Wiggle!" in result

        # Cleanup
        asc.remove_track_from_playlist(self.TEST_PLAYLIST, "Hot Potato")

    def test_album_param_accepted_without_artist(self):
        """Should accept album param even without artist for disambiguation."""
        success, result = asc.add_track_to_playlist(
            self.TEST_PLAYLIST, "Hot Potato", album="Ready, Steady"
        )
        assert success is True
        assert "Ready, Steady, Wiggle!" in result

        # Cleanup
        asc.remove_track_from_playlist(self.TEST_PLAYLIST, "Hot Potato")

    def test_fallback_to_contains_when_exact_fails(self):
        """Should fall back to contains if exact artist match finds nothing."""
        # "Dorothy the Dinosaur & The Wiggles" - only matches via contains
        success, result = asc.add_track_to_playlist(
            self.TEST_PLAYLIST, "Hot Potato", "Dorothy the Dinosaur"
        )
        assert success is True
        assert "Dorothy" in result

        # Cleanup
        asc.remove_track_from_playlist(self.TEST_PLAYLIST, "Hot Potato")


class TestOpenCatalogAndPlay:
    """Test open_catalog_and_play function."""
    pytestmark = pytest.mark.slow


    def _mock_subprocess(self, monkeypatch):
        """Mock subprocess.run for open_catalog_song."""
        import subprocess

        monkeypatch.setattr(
            subprocess,
            "run",
            lambda *args, **kwargs: type("R", (), {"returncode": 0, "stdout": "", "stderr": ""})(),
        )

    def _mock_time(self, monkeypatch):
        """Mock time.sleep to avoid delays."""
        import time

        monkeypatch.setattr(time, "sleep", lambda _: None)

    def test_returns_tuple(self, monkeypatch):
        """Should return (success, message) tuple for album URL."""
        self._mock_subprocess(monkeypatch)
        self._mock_time(monkeypatch)
        monkeypatch.setattr(asc, "run_applescript", lambda script: (True, "playing"))
        success, result = asc.open_catalog_and_play("https://music.apple.com/us/album/1234567890")
        assert isinstance(success, bool)
        assert isinstance(result, str)

    def test_rejects_empty_url(self):
        """Should reject empty URL."""
        success, result = asc.open_catalog_and_play("")
        assert success is False

    def test_rejects_non_apple_url(self):
        """Should reject non-Apple Music URLs."""
        success, result = asc.open_catalog_and_play("https://spotify.com/track/123")
        assert success is False

    def test_rejects_song_url(self):
        """Should reject /song/ URLs with helpful message."""
        success, result = asc.open_catalog_and_play(
            "https://music.apple.com/us/song/track-name/1234567890"
        )
        assert success is False
        assert "not supported" in result.lower()
        assert "?i=" in result

    def test_accepts_music_scheme(self, monkeypatch):
        """Should accept music:// scheme URLs."""
        self._mock_subprocess(monkeypatch)
        self._mock_time(monkeypatch)
        monkeypatch.setattr(asc, "run_applescript", lambda script: (True, "playing"))
        success, result = asc.open_catalog_and_play("music://music.apple.com/us/album/1234567890")
        assert isinstance(success, bool)

    def test_skips_click_if_already_playing(self, monkeypatch):
        """Should return immediately if Music auto-starts playing."""
        self._mock_subprocess(monkeypatch)
        self._mock_time(monkeypatch)
        monkeypatch.setattr(asc, "run_applescript", lambda script: (True, "playing"))
        success, result = asc.open_catalog_and_play("https://music.apple.com/us/album/1234567890")
        assert success is True
        assert "auto-started" in result.lower()

    def test_clicks_play_button(self, monkeypatch):
        """Should find and click Play button when auto-play doesn't start."""
        self._mock_subprocess(monkeypatch)
        self._mock_time(monkeypatch)
        call_count = [0]

        def mock_run(script):
            call_count[0] += 1
            if call_count[0] == 1:
                return (True, "stopped")
            if call_count[0] == 2:
                return (True, "")
            return (True, "playing")

        monkeypatch.setattr(asc, "run_applescript", mock_run)
        success, result = asc.open_catalog_and_play("https://music.apple.com/us/album/1234567890")
        assert success is True
        assert "playing" in result.lower()

    def test_shuffle(self, monkeypatch):
        """Should click Shuffle button when shuffle=True."""
        self._mock_subprocess(monkeypatch)
        self._mock_time(monkeypatch)
        scripts_called = []
        call_count = [0]

        def mock_run(script):
            scripts_called.append(script)
            call_count[0] += 1
            if call_count[0] == 1:
                return (True, "stopped")
            if call_count[0] == 2:
                return (True, "")
            return (True, "playing")

        monkeypatch.setattr(asc, "run_applescript", mock_run)
        success, result = asc.open_catalog_and_play(
            "https://music.apple.com/us/album/1234567890", shuffle=True
        )
        assert success is True
        assert any("Shuffle" in s for s in scripts_called)

    def test_retry_exhaustion(self, monkeypatch):
        """Should return graceful message after timeout."""
        self._mock_subprocess(monkeypatch)
        self._mock_time(monkeypatch)
        monkeypatch.setattr(asc, "run_applescript", lambda script: (True, "stopped"))
        success, result = asc.open_catalog_and_play(
            "https://music.apple.com/us/album/1234567890", timeout=0.1
        )
        assert success is True
        assert "could not confirm" in result.lower()

    def test_song_with_i_param(self, monkeypatch):
        """Should attempt track-specific playback for ?i= URLs."""
        self._mock_subprocess(monkeypatch)
        self._mock_time(monkeypatch)
        call_count = [0]

        def mock_run(script):
            call_count[0] += 1
            if "player state" in script and call_count[0] <= 2:
                return (True, "stopped")
            if "activate" in script:
                return (True, "")
            if "Favorite" in script and "position" in script:
                return (True, "500.0,400.0,Test Track")
            if "size of window" in script:
                return (True, "1000")
            if "click checkbox" in script:
                return (True, "Test Track")
            if "player state" in script:
                return (True, "playing")
            return (True, "")

        monkeypatch.setattr(asc, "run_applescript", mock_run)
        monkeypatch.setattr(asc, "_jxa_mouse_move", lambda x, y: True)
        success, result = asc.open_catalog_and_play(
            "https://music.apple.com/us/album/name/123?i=456"
        )
        assert success is True
        assert "test track" in result.lower()


class TestLibrarySnapshot:
    """Test library_snapshot and library_diff functions."""
    pytestmark = pytest.mark.slow


    def _make_snapshot(self, track_count=100, playlists=None, playback=None):
        """Build a snapshot dict for testing."""
        if playlists is None:
            playlists = {
                "Chill": [
                    {"name": "Song A", "artist": "Artist 1", "album": "Album 1"},
                    {"name": "Song B", "artist": "Artist 2", "album": "Album 2"},
                ],
                "Workout": [
                    {"name": "Song C", "artist": "Artist 3", "album": "Album 3"},
                ],
            }
        if playback is None:
            playback = {
                "player_state": "stopped",
                "volume": 50,
                "shuffle": False,
                "repeat": "off",
                "current_track": None,
                "current_artist": None,
                "current_album": None,
            }
        return {
            "track_count": track_count,
            "playback": playback,
            "playlists": playlists,
        }

    def test_snapshot_structure(self):
        """Snapshot dict should have track_count, playback, and playlists keys."""
        snap = self._make_snapshot()
        assert "track_count" in snap
        assert "playback" in snap
        assert "playlists" in snap
        assert isinstance(snap["track_count"], int)
        assert isinstance(snap["playlists"], dict)
        assert isinstance(snap["playback"], dict)

    def test_clean_diff(self):
        """Identical snapshots should produce a clean diff."""
        snap = self._make_snapshot()
        diff = asc.library_diff(snap, snap)
        assert diff["is_clean"] is True
        assert diff["track_count_change"] == 0
        assert diff["playlists_added"] == []
        assert diff["playlists_removed"] == []
        assert diff["playlists_changed"] == {}

    def test_detects_playlist_added(self):
        """Diff should detect a new playlist."""
        before = self._make_snapshot()
        after_playlists = dict(before["playlists"])
        after_playlists["New Playlist"] = [
            {"name": "Song D", "artist": "Artist 4", "album": "Album 4"},
        ]
        after = self._make_snapshot(playlists=after_playlists)
        diff = asc.library_diff(before, after)
        assert diff["is_clean"] is False
        assert "New Playlist" in diff["playlists_added"]

    def test_detects_playlist_removed(self):
        """Diff should detect a removed playlist."""
        before = self._make_snapshot()
        after_playlists = {"Chill": before["playlists"]["Chill"]}
        after = self._make_snapshot(playlists=after_playlists)
        diff = asc.library_diff(before, after)
        assert diff["is_clean"] is False
        assert "Workout" in diff["playlists_removed"]

    def test_detects_playlist_track_changes(self):
        """Diff should detect tracks added/removed within a playlist."""
        before = self._make_snapshot()
        after_playlists = dict(before["playlists"])
        # Remove Song A, add Song D
        after_playlists["Chill"] = [
            {"name": "Song B", "artist": "Artist 2", "album": "Album 2"},
            {"name": "Song D", "artist": "Artist 4", "album": "Album 4"},
        ]
        after = self._make_snapshot(playlists=after_playlists)
        diff = asc.library_diff(before, after)
        assert diff["is_clean"] is False
        assert "Chill" in diff["playlists_changed"]
        changes = diff["playlists_changed"]["Chill"]
        assert len(changes["added"]) == 1
        assert len(changes["removed"]) == 1

    def test_detects_track_count_change(self):
        """Diff should detect library track count changes."""
        before = self._make_snapshot(track_count=100)
        after = self._make_snapshot(track_count=105)
        diff = asc.library_diff(before, after)
        assert diff["is_clean"] is False
        assert diff["track_count_change"] == 5

    def test_playback_changes_tracked_separately(self):
        """Playback state changes should not make is_clean False."""
        before = self._make_snapshot()
        after_playback = dict(before["playback"])
        after_playback["player_state"] = "playing"
        after_playback["current_track"] = "Some Track"
        after = self._make_snapshot(playback=after_playback)
        diff = asc.library_diff(before, after)
        # Library is unchanged — is_clean should be True
        assert diff["is_clean"] is True
        # But playback changes should still be recorded
        assert "player_state" in diff["playback_changes"]
        assert diff["playback_changes"]["player_state"]["after"] == "playing"


class TestUISearchParsing:
    """Unit tests for UI search result parsing logic (no Music.app needed)."""

    def test_parse_search_results_with_separator(self):
        """Should parse type and artist from the Unicode middle-dot separator."""
        # Simulate the raw output from AppleScript
        raw = "1|||Creep|||Song\u2004\u00b7\u2004Radiohead\n2|||Radiohead|||Artist\n3|||OK Computer|||Album\u2004\u00b7\u2004Radiohead"

        results = []
        for line in raw.strip().split("\n"):
            line = line.strip()
            if not line or "|||" not in line:
                continue
            parts = line.split("|||")
            if len(parts) >= 3:
                name = parts[1].strip()
                type_line = parts[2].strip()
                result_type = ""
                artist = ""
                for sep in ["\u2004\u00b7\u2004", " \u00b7 ", " \u00b7 "]:
                    if sep in type_line:
                        result_type, artist = type_line.split(sep, 1)
                        break
                else:
                    result_type = type_line
                results.append({"name": name, "type": result_type, "artist": artist})

        assert len(results) == 3
        assert results[0]["name"] == "Creep"
        assert results[0]["type"] == "Song"
        assert results[0]["artist"] == "Radiohead"
        assert results[1]["name"] == "Radiohead"
        assert results[1]["type"] == "Artist"
        assert results[1]["artist"] == ""
        assert results[2]["name"] == "OK Computer"
        assert results[2]["type"] == "Album"
        assert results[2]["artist"] == "Radiohead"

    def test_parse_empty_results(self):
        """Should handle empty or NO_RESULTS gracefully."""
        for raw in ["", "NO_RESULTS", "\n\n"]:
            results = []
            if raw and raw.strip() != "NO_RESULTS":
                for line in raw.strip().split("\n"):
                    if "|||" in line:
                        results.append(line)
            assert results == []

    def test_parse_position_string(self):
        """Should correctly parse position coordinates from AppleScript.

        The actual AppleScript returns "x,y" format (two float values).
        The code unpacks via: cx, cy = [float(v) for v in pos_str.strip().split(",")]
        """
        pos_str = "1883.0,686.0"
        parts = [float(v) for v in pos_str.strip().split(",")]
        assert len(parts) == 2
        assert parts[0] == 1883.0
        assert parts[1] == 686.0

    def test_parse_position_rejects_extra_fields(self):
        """Position string with extra commas should raise ValueError on unpack."""
        pos_str = "500.0,400.0,extra"
        with pytest.raises(ValueError):
            cx, cy = [float(v) for v in pos_str.strip().split(",")]


class TestClassifyAsError:
    """Unit tests for _classify_as_error()."""

    def test_accessibility_not_granted(self):
        import applemusic_mcp.applescript as asc

        msg = asc._classify_as_error("execution error: (-1743)")
        assert "Accessibility" in msg
        assert "System Settings" in msg

    def test_element_not_found(self):
        import applemusic_mcp.applescript as asc

        msg = asc._classify_as_error("Can't get window 1. (-1728)")
        assert "element not found" in msg.lower() or "layout" in msg.lower()
        assert asc._GITHUB_ISSUES in msg

    def test_unknown_error_includes_issue_link(self):
        import applemusic_mcp.applescript as asc

        msg = asc._classify_as_error("something totally unexpected")
        assert asc._GITHUB_ISSUES in msg

    def test_unknown_error_truncates_long_text(self):
        import applemusic_mcp.applescript as asc

        long_err = "x" * 200
        msg = asc._classify_as_error(long_err)
        assert len(msg) < 300


class TestCheckUiAccessible:
    """Unit tests for check_ui_accessible()."""

    def test_returns_ok_when_windows_visible(self, monkeypatch):
        import applemusic_mcp.applescript as asc

        monkeypatch.setattr(asc, "run_applescript", lambda _: (True, "1\n"))
        ok, reason = asc.check_ui_accessible()
        assert ok is True
        assert reason == ""

    def test_returns_classified_error_on_applescript_failure(self, monkeypatch):
        import applemusic_mcp.applescript as asc

        monkeypatch.setattr(asc, "run_applescript", lambda _: (False, "(-1743)"))
        ok, reason = asc.check_ui_accessible()
        assert ok is False
        assert "Accessibility" in reason

    def test_detects_locked_screen(self, monkeypatch):
        import applemusic_mcp.applescript as asc

        calls = {"n": 0}

        def mock_run(script):
            calls["n"] += 1
            if calls["n"] == 1:
                return (True, "0")  # Music has 0 windows
            return (True, "true")  # loginwindow has windows → locked

        monkeypatch.setattr(asc, "run_applescript", mock_run)
        ok, reason = asc.check_ui_accessible()
        assert ok is False
        assert "locked" in reason.lower()

    def test_no_window_not_locked(self, monkeypatch):
        import applemusic_mcp.applescript as asc

        calls = {"n": 0}

        def mock_run(script):
            calls["n"] += 1
            if calls["n"] == 1:
                return (True, "0")  # Music has 0 windows
            return (True, "false")  # loginwindow also 0 → not locked, just minimized

        monkeypatch.setattr(asc, "run_applescript", mock_run)
        ok, reason = asc.check_ui_accessible()
        assert ok is False
        assert "no visible windows" in reason.lower() or "minimize" in reason.lower()


class TestGetSearchField:
    """Unit tests for the _get_search_field() dual-path probe."""

    def setup_method(self):
        """Reset the module-level cache before each test."""
        import applemusic_mcp.applescript as asc

        asc._search_field_cache = None

    def test_toolbar_grouped_path_when_probe_returns_grouped(self, monkeypatch):
        import applemusic_mcp.applescript as asc

        monkeypatch.setattr(asc, "run_applescript", lambda _: (True, "grouped\n"))
        result = asc._get_search_field()
        assert result == asc._SEARCH_FIELD_TOOLBAR

    def test_toolbar_flat_path_when_probe_returns_flat(self, monkeypatch):
        """macOS 26 build variant: text field is directly under toolbar with
        no wrapping `group 1`. Probe should return the flat path."""
        import applemusic_mcp.applescript as asc

        monkeypatch.setattr(asc, "run_applescript", lambda _: (True, "flat\n"))
        result = asc._get_search_field()
        assert result == asc._SEARCH_FIELD_TOOLBAR_FLAT

    def test_sidebar_path_when_no_toolbar_variant_found(self, monkeypatch):
        """If neither toolbar variant exists even after Cmd+F, fall back to
        the macOS 15 sidebar path."""
        import applemusic_mcp.applescript as asc

        monkeypatch.setattr(asc, "run_applescript", lambda _: (True, "none\n"))
        result = asc._get_search_field()
        assert result == asc._SEARCH_FIELD_SIDEBAR

    def test_sidebar_path_on_applescript_failure_does_not_cache(self, monkeypatch):
        """Transient probe failure (e.g., Music.app still launching) returns
        sidebar as a safe default, but does NOT cache — next call should retry
        so we don't pin a macOS 26 user to the wrong path."""
        import applemusic_mcp.applescript as asc

        monkeypatch.setattr(asc, "run_applescript", lambda _: (False, "error"))
        result = asc._get_search_field()
        assert result == asc._SEARCH_FIELD_SIDEBAR
        assert asc._search_field_cache is None  # not cached on failure

    def test_result_is_cached(self, monkeypatch):
        import applemusic_mcp.applescript as asc

        call_count = {"n": 0}

        def counting_run(script):
            call_count["n"] += 1
            return (True, "grouped")

        monkeypatch.setattr(asc, "run_applescript", counting_run)
        asc._get_search_field()
        asc._get_search_field()
        assert call_count["n"] == 1  # probe ran once; second call hit cache


class TestUIPrimitives:
    """Unit tests for the unified UI automation primitives.

    These verify the contract of each primitive (return shapes, error
    classifications, polling behavior) without touching Music.app. Live
    integration is covered by TestUISearchIntegration below.
    """

    def setup_method(self):
        """Reset the search-field cache before each test so monkeypatched
        run_applescript can deterministically influence the path."""
        import applemusic_mcp.applescript as asc

        asc._search_field_cache = None

    # --- _focus_search_field -------------------------------------------------

    def test_focus_search_field_rejects_empty_query(self):
        import applemusic_mcp.applescript as asc

        ok, err = asc._focus_search_field("")
        assert ok is False
        assert err == "Empty query"

        ok, err = asc._focus_search_field("   ")
        assert ok is False
        assert err == "Empty query"

    def test_focus_search_field_success_path(self, monkeypatch):
        """On AppleScript success, returns (True, ""). The query is escaped
        and embedded in the consolidated AppleScript that the helper emits."""
        import applemusic_mcp.applescript as asc

        captured_scripts: list[str] = []

        def fake_run(script: str):
            captured_scripts.append(script)
            return (True, "")

        monkeypatch.setattr(asc, "run_applescript", fake_run)
        monkeypatch.setattr(asc, "_ensure_music_frontmost", lambda: None)
        monkeypatch.setattr(asc, "_get_search_field", lambda: asc._SEARCH_FIELD_TOOLBAR)

        ok, err = asc._focus_search_field("Radiohead")
        assert ok is True
        assert err == ""
        # The injected script contains the resolved field path AND the query
        emitted = captured_scripts[-1]
        assert asc._SEARCH_FIELD_TOOLBAR in emitted
        assert "Radiohead" in emitted

    def test_focus_search_field_classifies_environmental_failure(self, monkeypatch):
        """When AppleScript fails AND check_ui_accessible reports a problem,
        the user-facing reason should be the access reason, not the raw
        AppleScript error — same behavior the original ui_search_catalog had."""
        import applemusic_mcp.applescript as asc

        monkeypatch.setattr(asc, "run_applescript", lambda _: (False, "execution error"))
        monkeypatch.setattr(asc, "_ensure_music_frontmost", lambda: None)
        monkeypatch.setattr(asc, "_get_search_field", lambda: asc._SEARCH_FIELD_TOOLBAR)
        monkeypatch.setattr(
            asc, "check_ui_accessible", lambda: (False, "Music.app not running")
        )

        ok, err = asc._focus_search_field("anything")
        assert ok is False
        assert err == "Music.app not running"

    # --- _wait_for_top_results ----------------------------------------------

    def test_wait_for_top_results_returns_immediately_on_success(self, monkeypatch):
        import applemusic_mcp.applescript as asc

        monkeypatch.setattr(asc, "run_applescript", lambda _: (True, "1|||Track|||Song"))
        ok, raw = asc._wait_for_top_results(timeout=2.0)
        assert ok is True
        assert "1|||Track" in raw

    def test_wait_for_top_results_empty_on_clean_timeout(self, monkeypatch):
        """If results never appear but AppleScript itself succeeds with
        NO_RESULTS, returns (True, "") to signal empty results — not error."""
        import applemusic_mcp.applescript as asc

        monkeypatch.setattr(asc, "run_applescript", lambda _: (True, "NO_RESULTS"))
        ok, raw = asc._wait_for_top_results(timeout=0.5)
        assert ok is True
        assert raw == ""

    # --- _parse_top_results -------------------------------------------------

    def test_parse_top_results_handles_unicode_separators(self):
        import applemusic_mcp.applescript as asc

        raw = (
            "1|||Creep|||Song · Radiohead\n"
            "2|||OK Computer|||Album · Radiohead\n"
            "3|||Radiohead|||Artist\n"
        )
        results = asc._parse_top_results(raw)
        assert len(results) == 3
        assert results[0] == {"name": "Creep", "type": "Song", "artist": "Radiohead", "index": 1}
        assert results[1] == {
            "name": "OK Computer",
            "type": "Album",
            "artist": "Radiohead",
            "index": 2,
        }
        assert results[2] == {"name": "Radiohead", "type": "Artist", "artist": "", "index": 3}

    def test_parse_top_results_skips_malformed_lines(self):
        import applemusic_mcp.applescript as asc

        raw = "1|||Good|||Song · A\n||\nbroken_line_no_separator\n2|||Also Good|||Song · B"
        results = asc._parse_top_results(raw)
        assert len(results) == 2
        assert results[0]["name"] == "Good"
        assert results[1]["name"] == "Also Good"

    # --- _find_top_result_position ------------------------------------------

    def test_find_top_result_position_parses_csv(self, monkeypatch):
        import applemusic_mcp.applescript as asc

        monkeypatch.setattr(asc, "run_applescript", lambda _: (True, "1883.0,686.0"))
        pos = asc._find_top_result_position("Some Track")
        assert pos == (1883.0, 686.0)

    def test_find_top_result_position_returns_none_on_not_found(self, monkeypatch):
        import applemusic_mcp.applescript as asc

        monkeypatch.setattr(asc, "run_applescript", lambda _: (True, "NOT_FOUND"))
        assert asc._find_top_result_position("Missing") is None

    # --- _hover_then_click_subelement ---------------------------------------

    def test_hover_then_click_succeeds(self, monkeypatch):
        """Full success path: row found, hover succeeds, sub-element appears
        on first poll, CoreGraphics click succeeds."""
        import applemusic_mcp.applescript as asc

        click_calls: list[tuple[float, float]] = []

        # AppleScript is called twice in this path:
        # 1. _find_top_result_position → returns row pos
        # 2. inner sub-element poll → returns inner pos
        responses = iter([(True, "100.0,200.0"), (True, "55.0,77.0")])

        monkeypatch.setattr(asc, "run_applescript", lambda _: next(responses))
        monkeypatch.setattr(asc, "_ensure_music_frontmost", lambda: None)
        monkeypatch.setattr(asc, "_hover_with_nudge", lambda cx, cy: True)
        monkeypatch.setattr(
            asc,
            "_jxa_mouse_click",
            lambda x, y: (click_calls.append((x, y)), True)[1],
        )

        ok, err = asc._hover_then_click_subelement("Track", "set inner to checkbox 1 of e")
        assert ok is True
        assert err == ""
        # Click landed at the inner element's center, not the row's center
        assert click_calls == [(55.0, 77.0)]

    def test_hover_then_click_returns_not_visible_marker(self, monkeypatch):
        """When the inner sub-element never becomes queryable within max_wait,
        the helper returns the reserved 'sub-element not visible after hover'
        string so wrappers can map it to a domain-specific message
        (e.g. ui_play_result → 'Play checkbox not visible after hover')."""
        import applemusic_mcp.applescript as asc

        # Row found, but sub-element poll always returns NOT_FOUND
        responses = [(True, "100.0,200.0")] + [(True, "NOT_FOUND")] * 50

        idx = {"i": 0}

        def fake_run(_):
            r = responses[min(idx["i"], len(responses) - 1)]
            idx["i"] += 1
            return r

        monkeypatch.setattr(asc, "run_applescript", fake_run)
        monkeypatch.setattr(asc, "_ensure_music_frontmost", lambda: None)
        monkeypatch.setattr(asc, "_hover_with_nudge", lambda cx, cy: True)
        monkeypatch.setattr(asc, "_jxa_mouse_click", lambda x, y: True)

        ok, err = asc._hover_then_click_subelement(
            "Track", "set inner to checkbox 1 of e", max_wait=0.3
        )
        assert ok is False
        assert err == "sub-element not visible after hover"

    # --- _verify_track_playing ----------------------------------------------

    def test_verify_track_playing_match_on_first_poll(self, monkeypatch):
        import applemusic_mcp.applescript as asc

        monkeypatch.setattr(asc, "run_applescript", lambda _: (True, "Sweet Baby James (Remastered)"))
        ok, name = asc._verify_track_playing("Sweet Baby James", timeout=1.0)
        assert ok is True
        assert "Sweet Baby James" in name

    def test_verify_track_playing_returns_false_on_mismatch(self, monkeypatch):
        """When the current track never matches within timeout, returns
        (False, last_known_track) so the caller can distinguish 'wrong
        track playing' from 'nothing playing'."""
        import applemusic_mcp.applescript as asc

        monkeypatch.setattr(asc, "run_applescript", lambda _: (True, "Different Song"))
        ok, name = asc._verify_track_playing("Sweet Baby James", timeout=0.4)
        assert ok is False
        assert name == "Different Song"


class TestPopoverSongRowScoring:
    """Unit tests for `_find_popover_song_row` score-and-pick scoring.

    Mocks `run_applescript` to return fixture pop-over rows and asserts
    the matcher picks the row with the highest tier score (with row-index
    as the tiebreaker). Each fixture mirrors the `idx|||title|||type · artist`
    format the actual AppleScript probe produces.
    """

    @staticmethod
    def _fixture(rows: list[tuple[int, str, str]]) -> str:
        """Build a |||-delimited fixture matching the AppleScript probe output."""
        return "\n".join(f"{idx}|||{title}|||{type_artist}" for idx, title, type_artist in rows)

    def _patch_applescript(self, monkeypatch, fixture: str):
        import applemusic_mcp.applescript as asc

        monkeypatch.setattr(asc, "run_applescript", lambda *_a, **_k: (True, fixture))

    def test_song_exact_beats_album_exact(self, monkeypatch):
        """Tier 1 (Song EXACT) beats Tier 3 (Album EXACT)."""
        import applemusic_mcp.applescript as asc

        self._patch_applescript(monkeypatch, self._fixture([
            (5, "Brown Sugar", "Album · D'Angelo"),
            (7, "Brown Sugar", "Song · D'Angelo"),
        ]))
        result = asc._find_popover_song_row("Brown Sugar", "D'Angelo")
        assert result == (7, "D'Angelo")

    def test_canonical_marker_paren_beats_album_exact(self, monkeypatch):
        """Tier 2 (canonical-marker parenthetical Song) beats Tier 3 (Album EXACT)."""
        import applemusic_mcp.applescript as asc

        self._patch_applescript(monkeypatch, self._fixture([
            (3, "Brown Sugar (2014 Remaster)", "Song · D'Angelo"),
            (5, "Brown Sugar", "Album · D'Angelo"),
        ]))
        result = asc._find_popover_song_row("Brown Sugar", "D'Angelo")
        assert result == (3, "D'Angelo")

    def test_album_now_rejected_returns_none_with_only_album(self, monkeypatch):
        """Album rows are rejected entirely under the 'no album-dive' policy.
        If only an album row exists, return None — caller fails loudly."""
        import applemusic_mcp.applescript as asc

        self._patch_applescript(monkeypatch, self._fixture([
            (5, "Brown Sugar", "Album · D'Angelo"),
        ]))
        result = asc._find_popover_song_row("Brown Sugar", "D'Angelo")
        assert result is None

    def test_brown_sugar_dangelo_real_popover_returns_remix_row(self, monkeypatch):
        """The Brown Sugar / D'Angelo case: pop-over has no Song-EXACT row,
        only Album + Song-with-non-canonical-paren. With album-dive removed,
        the only navigable Song row is the 808 Mix variant (tier 4) — that's
        what the matcher returns. Caller can decide whether to surface that
        to the user or fail with 'no canonical match'."""
        import applemusic_mcp.applescript as asc

        # Mirrors the actual pop-over output we observed live.
        self._patch_applescript(monkeypatch, self._fixture([
            (5, "Brown Sugar ￼", "Album · D'Angelo"),  # has U+FFFC artifact
            (7, "Brown Sugar (Soul Inside 808 Mix)", "Song · D'Angelo"),
            (11, "Brown Sugar (Verzuz Live)", "Music Video · D'Angelo"),
        ]))
        result = asc._find_popover_song_row("Brown Sugar", "D'Angelo")
        # Album rejected; Music Video rejected; only the 808 Mix Song
        # remains and it scores tier 4 (non-canonical paren).
        assert result == (7, "D'Angelo")

    def test_lower_idx_wins_within_same_tier(self, monkeypatch):
        """Two Song-EXACT matches by same artist — Apple's earlier row
        (lower idx) should win as the relevance signal."""
        import applemusic_mcp.applescript as asc

        self._patch_applescript(monkeypatch, self._fixture([
            (3, "Heaven", "Song · Talking Heads"),
            (8, "Heaven", "Song · Talking Heads"),  # duplicate (rare but possible)
        ]))
        result = asc._find_popover_song_row("Heaven", "Talking Heads")
        assert result == (3, "Talking Heads")

    def test_artist_filter_rejects_wrong_artist(self, monkeypatch):
        """Same title by a different artist must NOT match when the caller
        supplied an artist constraint."""
        import applemusic_mcp.applescript as asc

        self._patch_applescript(monkeypatch, self._fixture([
            (3, "Heaven", "Song · The Walkmen"),
            (5, "Heaven", "Song · Beyoncé"),
        ]))
        result = asc._find_popover_song_row("Heaven", "Talking Heads")
        assert result is None

    def test_artist_filter_picks_correct_artist(self, monkeypatch):
        """Multiple artists with same title — picks the one matching artist."""
        import applemusic_mcp.applescript as asc

        self._patch_applescript(monkeypatch, self._fixture([
            (3, "Heaven", "Song · The Walkmen"),
            (5, "Heaven", "Song · Talking Heads"),
            (7, "Heaven", "Song · Beyoncé"),
        ]))
        result = asc._find_popover_song_row("Heaven", "Talking Heads")
        assert result == (5, "Talking Heads")

    def test_artist_optional_picks_first_song_exact(self, monkeypatch):
        """Without artist filter — pick highest-tier match regardless,
        using row index as tiebreaker."""
        import applemusic_mcp.applescript as asc

        self._patch_applescript(monkeypatch, self._fixture([
            (3, "Heaven", "Song · The Walkmen"),
            (5, "Heaven", "Song · Talking Heads"),
        ]))
        result = asc._find_popover_song_row("Heaven")
        assert result == (3, "The Walkmen")  # lower idx wins on tier-tie

    def test_non_song_rows_all_rejected(self, monkeypatch):
        """Album, Artist, MusicVideo, Playlist all rejected — only Song scored."""
        import applemusic_mcp.applescript as asc

        self._patch_applescript(monkeypatch, self._fixture([
            (3, "Heaven", "Album · Talking Heads"),
            (5, "Talking Heads", "Artist"),
            (7, "Heaven", "Music Video · Talking Heads"),
            (9, "Heaven Mix", "Playlist · Apple Music"),
        ]))
        result = asc._find_popover_song_row("Heaven", "Talking Heads")
        assert result is None

    def test_no_results_in_popover_returns_none(self, monkeypatch):
        """No-match-anywhere → None."""
        import applemusic_mcp.applescript as asc

        self._patch_applescript(monkeypatch, self._fixture([
            (3, "Something Else", "Song · Other Artist"),
        ]))
        result = asc._find_popover_song_row("Heaven", "Talking Heads")
        assert result is None

    def test_no_popover_returns_none(self, monkeypatch):
        """If pop-over isn't visible, AppleScript probe returns NO_POPOVER."""
        import applemusic_mcp.applescript as asc

        monkeypatch.setattr(asc, "run_applescript", lambda *_a, **_k: (True, "NO_POPOVER"))
        result = asc._find_popover_song_row("Heaven", "Talking Heads")
        assert result is None

    def test_canonical_paren_markers_are_recognized(self, monkeypatch):
        """Each canonical-marker word should score in tier 2 (1700), so
        a parenthetical-canonical Song should beat any non-canonical paren."""
        import applemusic_mcp.applescript as asc

        for marker in ["Original Mix", "Album Version", "2014 Remaster",
                       "Stereo Version", "Mono Version", "Single Version",
                       "Radio Edit", "Studio Version"]:
            self._patch_applescript(monkeypatch, self._fixture([
                (3, f"Test ({marker})", "Song · X"),
                (5, "Test (Live at Madison)", "Song · X"),  # non-canonical paren
            ]))
            result = asc._find_popover_song_row("Test", "X")
            assert result == (3, "X"), f"marker {marker!r} should win tier 2"


@pytest.mark.skipif(
    not os.environ.get("TEST_UI"), reason="UI tests require Music.app visible. Run with TEST_UI=1"
)
class TestUISearchIntegration:
    """Integration tests for UI search.

    These require Music.app to be visible and active with Accessibility
    permissions. They will fail in CI or if Music.app is minimized.
    Run manually: pytest tests/test_applescript.py::TestUISearchIntegration -v
    """

    def test_search_returns_results(self):
        """Should find results for a well-known artist."""
        asc.run_applescript('tell application "Music" to activate')
        import time

        time.sleep(2)
        ok, results, why = asc.ui_search_catalog("Beatles")
        asc.ui_clear_search()
        assert ok is True
        assert len(results) > 0
        assert "name" in results[0]
        assert "type" in results[0]
        assert why == ""

    def test_search_clears_properly(self):
        """Should clear search without errors."""
        asc.run_applescript('tell application "Music" to activate')
        import time

        time.sleep(1)
        asc.ui_search_catalog("test query")
        asc.ui_clear_search()

    def test_search_empty_query(self):
        """Should reject empty queries."""
        ok, results, why = asc.ui_search_catalog("")
        assert ok is False
        assert results == []
        assert why == "Empty query"


def _probe_row_is_fresh(name: str, artist: str) -> bool:
    """Probe Music.app's song-page row for a track to detect "stale in-library
    cache" — the situation where AppleScript-level remove_from_library has
    completed but Music.app's per-row cloud-state cache still shows
    "Download button" (=in library) for several minutes after iCloud removal.

    Such a row would cause ui_add_to_library to fail at the hover-find step
    even though search_library returns 0 hits — we want setup_class to skip
    these stale candidates and try the next one.

    Returns True if row's initial buttons (no hover) DON'T include
    "Download button" — i.e., the row is genuinely fresh and a Music.app
    "Add to Library" button is reachable.

    Side-effect: leaves search popover state unchanged (clears it on exit).
    """
    ok, _err = asc._open_search_popover(f"{name} {artist}".strip())
    if not ok:
        asc.ui_clear_search()
        return False
    match = asc._find_popover_song_row(name, artist)
    if match is None:
        asc.ui_clear_search()
        return False
    idx, _resolved = match
    ok, _err = asc._click_popover_row(idx)
    if not ok:
        asc.ui_clear_search()
        return False
    group_path = asc._wait_for_song_page(name)
    if group_path is None:
        asc.ui_clear_search()
        return False
    # Hover the row first — Music.app only reveals the in-library indicator
    # ("Download button") OR the not-in-library button ("Add to Library")
    # AFTER hover. A no-hover probe shows only Favorite|More for any state.
    ok, pos = asc.run_applescript(f"""
tell application "System Events"
    tell process "Music"
        try
            set g to {group_path}
            set gp to position of g
            set gs to size of g
            return ((item 1 of gp) + (item 1 of gs) / 2 as text) & "," & ((item 2 of gp) + (item 2 of gs) / 2 as text)
        on error
            return "ERR"
        end try
    end tell
end tell""")
    if not ok or pos.strip() == "ERR":
        asc.ui_clear_search()
        return False
    try:
        hcx, hcy = [float(v) for v in pos.strip().split(",")]
    except ValueError:
        asc.ui_clear_search()
        return False
    asc._hover_with_nudge(hcx, hcy)
    time.sleep(0.6)
    ok, descs = asc.run_applescript(f"""
tell application "System Events"
    tell process "Music"
        try
            set g to {group_path}
            set out to ""
            repeat with b in (every button of g)
                try
                    set out to out & (description of b) & "|"
                end try
            end repeat
            return out
        on error
            return "PROBE_FAIL"
        end try
    end tell
end tell""")
    asc.ui_clear_search()
    if not ok or descs.strip() == "PROBE_FAIL":
        return False
    return "Download button" not in descs


@pytest.mark.ui
@pytest.mark.skipif(
    not os.environ.get("TEST_UI"),
    reason="UI flows require Music.app visible + Accessibility. Run with TEST_UI=1.",
)
class TestUIFlowsLive:
    """End-to-end UI flow tests.

    Exercises the full ``ui_search_catalog`` → ``ui_add_to_library`` →
    ``ui_add_to_playlist`` chain on the user's actual Music.app. Skipped by
    default (CI / headless / API-only users); run locally with::

        TEST_UI=1 uv run pytest tests/test_applescript.py::TestUIFlowsLive -v

    **Cleanup is non-negotiable**: every test removes the track it added
    from the library + playlist in teardown, and ``teardown_class`` deletes
    the test playlist. The session-end conftest sweep is a final safety net.

    Track selection: the class picks the first candidate from the fallback
    list that ISN'T already in the user's library. If all candidates are
    already in library, the whole class is skipped (very unlikely — the
    candidates are deliberately obscure tracks).
    """

    TEST_PLAYLIST = "_UI_TEST_PLAYLIST_"

    # Test track candidates. Selection criteria checked in setup_class:
    #   1. NOT already in the user's library (so add operations are testable)
    #   2. Surfaces as a Song-type row in Music.app's Top Results for the
    #      "{name} {artist}" search query (so the UI flow can find + click it)
    #
    # The third "has Add to Library button after hover" check is left to the
    # test itself because, on macOS 26, that button may be hidden in the
    # [More] context menu rather than directly on the row — a real Apple
    # UX shift, not a code bug. The full-flow test handles this with a soft
    # skip when the button isn't directly present.
    CANDIDATES = [
        ("Such Great Heights", "Iron and Wine"),       # Garden State soundtrack
        ("The Night We Met", "Lord Huron"),            # 13 Reasons Why use, well-indexed
        ("Holocene", "Bon Iver"),                      # For Emma, well-indexed
        ("Skinny Love", "Bon Iver"),                   # Same artist fallback
        ("Re: Stacks", "Bon Iver"),                    # Same artist fallback
        ("Wandering", "Crooked Still"),
        ("Bee Pee Tee", "Hot 8 Brass Band"),
        ("Rainwater", "Penguin Cafe Orchestra"),
        # More obscure-but-indexed fallbacks for when rapid-rerun pollution
        # exhausts the primary list (each test run leaves a "stale" cache
        # entry for ~minutes-to-hours of iCloud propagation lag).
        ("Pyramid Song", "Radiohead"),
        ("Hyperballad", "Björk"),
        ("Casimir Pulaski Day", "Sufjan Stevens"),
        ("Mykonos", "Fleet Foxes"),
        ("Emmylou", "First Aid Kit"),
        ("Sea of Love", "Cat Power"),
        ("Hounds of Love", "Kate Bush"),
        ("Sleeping Lessons", "The Shins"),
    ]

    track_name: str = ""
    track_artist: str = ""

    @classmethod
    def setup_class(cls):
        """Pick the first candidate that is BOTH not in library AND surfaces
        as a Song-type Top Result. Then create a fresh test playlist.

        Pre-validating Top Results visibility (vs. just library absence) is
        what makes these tests deterministic — without it, candidates picked
        only on library absence would silently skip the add tests when
        Apple's UI search ranks the Song row below an Album/Artist row."""
        asc.run_applescript('tell application "Music" to activate')
        time.sleep(1.5)

        skipped_reasons = []
        for name, artist in cls.CANDIDATES:
            # Criterion 1: not in library
            ok, hits = asc.search_library(name, "songs")
            if not ok:
                skipped_reasons.append(f"{name}: search_library failed")
                continue
            owns = any(
                t.get("name", "").lower() == name.lower()
                and artist.lower() in t.get("artist", "").lower()
                for t in (hits or [])
            )
            if owns:
                skipped_reasons.append(f"{name}: already in library")
                continue

            # Criterion 2: surfaces as Song-type Top Result for "{name} {artist}"
            ok, results, _why = asc.ui_search_catalog(f"{name} {artist}")
            if not ok or not results:
                asc.ui_clear_search()
                skipped_reasons.append(f"{name}: UI search returned no results")
                continue
            has_song = any(
                r.get("type") == "Song"
                and name.lower() in r.get("name", "").lower()
                and artist.lower() in r.get("artist", "").lower()
                for r in results
            )
            asc.ui_clear_search()
            if not has_song:
                skipped_reasons.append(
                    f"{name}: not surfaced as Song row in Top Results today"
                )
                continue

            # Criterion 3: Music.app's song-page row must show this as
            # not-in-library. A previous test run that added+removed the
            # track via AppleScript can leave Music.app's per-row cloud-
            # state cache showing "Download button" (=in library) for
            # minutes-to-hours after iCloud-side removal. If we picked a
            # candidate in that state, ui_add_to_library would fail at
            # the hover-find step with "Download button" in the row's
            # children rather than "Add to Library".
            if not _probe_row_is_fresh(name, artist):
                skipped_reasons.append(
                    f"{name}: Music.app song-page shows Download button "
                    f"(stale in-library cache from prior run); skipping"
                )
                continue

            cls.track_name = name
            cls.track_artist = artist
            break
        else:
            pytest.skip(
                "No candidate satisfied all three criteria (not in library + "
                "surfaces as Song in Top Results + Music.app row shows fresh "
                "Add to Library button):\n  - "
                + "\n  - ".join(skipped_reasons)
            )

        # Always start the playlist fresh — prior failed runs may have left a
        # stale one with stuck tracks.
        asc.run_applescript(f"""
tell application "Music"
    try
        delete (every user playlist whose name is "{cls.TEST_PLAYLIST}")
    end try
    make new playlist with properties {{name:"{cls.TEST_PLAYLIST}"}}
end tell""")

    @classmethod
    def teardown_class(cls):
        """Delete the test playlist AND remove the selected candidate from
        library (defensive — per-test teardown also handles this).

        We do NOT iterate cls.CANDIDATES here because a user running these
        tests may legitimately have one of the candidate tracks in their
        library (Bon Iver / Radiohead / Sufjan are mainstream); removing
        them would be destructive. Only the selected candidate (track_name)
        could possibly have been added by ui_add_to_library, and only if
        criterion 1 confirmed it wasn't there before the test started.
        """
        try:
            asc.run_applescript(f"""
tell application "Music"
    try
        delete (every user playlist whose name is "{cls.TEST_PLAYLIST}")
    end try
end tell""")
        except Exception:
            pass
        # Defensive UNCONDITIONAL removal of the SELECTED candidate only —
        # setup_class confirmed it wasn't in library before the test started,
        # so removing it cleans up any add this run made. We don't precheck
        # via search_library because that races with iCloud sync (see
        # teardown_method comment for the failure mode).
        if not cls.track_name:
            return
        try:
            asc.remove_from_library(
                track_name=cls.track_name, artist=cls.track_artist
            )
        except Exception:
            pass

    def teardown_method(self, method):
        """Per-test cleanup: remove the test track from playlist + library if
        it landed there. Idempotent — safe to call when the test never added.

        We do this after EVERY test (not just the ones that explicitly add)
        so a mid-test failure that left state behind still gets cleaned up.
        Eric explicitly asked for strict cleanup: "anything the tests make
        should get removed at end of testing."
        """
        if not self.track_name:
            return
        # Remove from playlist (silent if not there).
        try:
            asc.remove_track_from_playlist(
                self.TEST_PLAYLIST,
                track_name=self.track_name,
                artist=self.track_artist or None,
            )
        except Exception:
            pass
        # Remove from library — UNCONDITIONALLY (idempotent — silent on miss).
        # The earlier search_library precheck raced with iCloud sync: if
        # ui_add_to_playlist returned success but iCloud hadn't propagated
        # the library entry to local AppleScript queries within the ~1s
        # between the test ending and teardown running, the precheck would
        # return 0 hits and skip removal, but the track would land in
        # library seconds later — pollution. remove_from_library tolerates
        # "not found" silently, so just call it and let it no-op on miss.
        try:
            asc.remove_from_library(
                track_name=self.track_name,
                artist=self.track_artist or None,
            )
        except Exception:
            pass

    # ------------------------------------------------------------------
    # Tests
    # ------------------------------------------------------------------

    def test_full_ui_flow(self):
        """One deep flow exercising the entire tokenless-macOS chain in a
        single Music.app session — replaces the prior 3 tests that each
        re-ran ui_search_catalog as setup. Halves the live-test runtime
        and asserts the realistic end-user path:

        1. ui_search_catalog returns parsed Top Results
        2. Top Results dicts have the expected shape
        3. ui_add_to_playlist (popover-canonical flow) drives
           search → library-add → playlist-add → verify
        4. The EXACT track we asked for landed in the playlist
           (no wrong-track substitution — v0.10.2 regression guard)

        Soft-skips on the known macOS 26 limitation where Apple's Top
        Results UI sometimes omits the per-row Add to Library button —
        a real Apple UX shift, not a code bug.
        """
        query = f"{self.track_name} {self.track_artist}"

        # Step 1+2: search + parse
        ok, results, why = asc.ui_search_catalog(query)
        try:
            assert ok is True, f"search failed: {why}"
            assert len(results) > 0, "expected at least one Top Result"
            for r in results:
                assert "name" in r and isinstance(r["name"], str)
                assert "type" in r and isinstance(r["type"], str)
                assert "artist" in r and isinstance(r["artist"], str)
                assert "index" in r and isinstance(r["index"], int)
                assert r["index"] >= 1
        finally:
            asc.ui_clear_search()

        # Step 3: full composite add-to-playlist (the path that powers
        # playlist(action='add', auto_search=True) for tokenless users)
        ok, msg = asc.ui_add_to_playlist(self.TEST_PLAYLIST, query, self.track_artist)
        if not ok:
            soft_failures = (
                "No Song-type Top Result",
                "No Song result for",
                "No 'Add to Library' button found",
                "row has no Add to Library button",
            )
            if any(s in (msg or "") for s in soft_failures):
                pytest.skip(
                    f"macOS 26 Music.app UI surface limitation, not a code "
                    f"bug: {msg}. See test docstring for context."
                )
        assert ok, f"ui_add_to_playlist failed: {msg}"

        # Step 4: verify EXACT track landed (not a wrong-track substitution)
        ok_check, exists = asc.track_exists_in_playlist(
            self.TEST_PLAYLIST, self.track_name, self.track_artist
        )
        assert ok_check and exists, (
            f"ui_add_to_playlist returned success ({msg!r}) but the track "
            f"{self.track_name!r} by {self.track_artist!r} is NOT in "
            f"{self.TEST_PLAYLIST!r}. The wrong track may have been added."
        )


@pytest.mark.ui
@pytest.mark.skipif(
    not os.environ.get("TEST_UI"),
    reason="UI flows require Music.app visible + Accessibility. Run with TEST_UI=1.",
)
class TestUIPlayLive:
    """Live test for ``ui_play_result_by_query`` — the tokenless-catalog
    play path (used when a user wants to play a catalog track without
    adding it to library). Distinct from add-to-library because no track
    state mutation happens; safe to run repeatedly without polluting
    Music.app's per-row UI cache.

    Cleanup: pauses playback after each test.
    """

    @classmethod
    def setup_class(cls):
        asc.run_applescript('tell application "Music" to activate')
        time.sleep(1.0)

    def teardown_method(self, method):
        # Stop playback so the test doesn't leave music playing in the
        # background after the suite finishes.
        try:
            asc.run_applescript('tell application "Music" to pause')
        except Exception:
            pass

    def test_play_result_by_query_starts_correct_track(self):
        """ui_play_result_by_query should start playback of a track whose
        name matches the query. Uses a well-indexed catalog track that
        Music.app can find quickly via Top Results."""
        # Use a track unlikely to require library presence — Apple Music
        # plays catalog tracks even if not in library.
        query = "Bohemian Rhapsody Queen"
        ok, msg = asc.ui_play_result_by_query(query)
        if not ok:
            pytest.skip(
                f"ui_play_result_by_query failed (likely Top Results UI "
                f"surface limitation, same family as the deep-flow soft-skip): "
                f"{msg}"
            )
        # Confirm Music.app actually started playing
        time.sleep(1.5)
        playing_ok, current_track = asc.get_current_track()
        assert playing_ok, f"get_current_track failed: {current_track}"
        # current_track is dict {state, name, artist, ...}; check name loosely
        # because catalog can return live versions, remasters, etc.
        track_name = current_track.get("name", "") if isinstance(current_track, dict) else ""
        assert "bohemian" in track_name.lower(), (
            f"Expected Bohemian Rhapsody to be playing, got: {current_track}"
        )


@pytest.mark.ui
@pytest.mark.skipif(
    not os.environ.get("TEST_UI"),
    reason="UI flows require Music.app visible + Accessibility. Run with TEST_UI=1.",
)
class TestUIEdgeCasesLive:
    """Live tests for UI-flow edge cases that don't fit the happy-path
    deep-flow test: empty/junk queries, search-state cleanup, and
    popover-canonical artist disambiguation. None of these mutate the
    library or playlist state.
    """

    @classmethod
    def setup_class(cls):
        asc.run_applescript('tell application "Music" to activate')
        time.sleep(1.0)

    def teardown_method(self, method):
        try:
            asc.ui_clear_search()
        except Exception:
            pass

    def test_search_returns_empty_for_junk_query(self):
        """A query that can't possibly match anything should produce no
        Top Results without raising — caller's job is to handle gracefully."""
        ok, results, why = asc.ui_search_catalog("qqxqzznotarealquery9999")
        # Either ok=True with empty results, OR ok=False with a why.
        # Both are acceptable; what's NOT acceptable is a crash or stale
        # results from a previous query leaking through.
        assert (ok and not results) or (not ok), (
            f"junk query unexpectedly returned results: ok={ok}, "
            f"len(results)={len(results)}, why={why!r}"
        )

    def test_clear_search_resets_field(self):
        """After ui_search_catalog + ui_clear_search, the search field
        value should be empty — confirms cleanup actually clears state
        and doesn't just leave the field with stale text."""
        ok, results, why = asc.ui_search_catalog("Bon Iver")
        assert ok, f"setup search failed: {why}"
        asc.ui_clear_search()
        time.sleep(0.5)
        # Use the production search-field probe so this test rides whatever
        # toolbar variant Music.app exposes today (toolbar/flat/sidebar).
        field_path = asc._get_search_field()
        if not field_path:
            pytest.skip(
                "Could not resolve search field path — Music.app build may "
                "have shifted the toolbar layout. Not a code bug."
            )
        ok, value = asc.run_applescript(f"""
tell application "System Events"
    tell process "Music"
        try
            return value of ({field_path}) as text
        on error
            return "FIELD_NOT_FOUND"
        end try
    end tell
end tell""")
        if not ok or value.strip() == "FIELD_NOT_FOUND":
            pytest.skip(
                "Could not probe search field via resolved path — Music.app "
                "may have navigated away from Search view after clear."
            )
        assert value.strip() == "", (
            f"ui_clear_search did not empty the search field — value is "
            f"still {value.strip()!r}"
        )

    def test_popover_disambiguates_by_artist(self):
        """The popover-canonical-match flow's `_find_popover_song_row`
        must pick the row whose artist matches the caller's `artist` arg
        — not just the first row whose Title matches. Same-title tracks
        by different artists is a real common case (e.g. "Heaven" by
        many artists).

        Probe-only: opens popover, calls the matcher, asserts the
        resolved_artist matches what we asked for. No click, no add,
        no playlist mutation.
        """
        ok, _err = asc._open_search_popover("Heaven Talking Heads")
        if not ok:
            pytest.skip("popover did not appear — likely a transient UI flake")
        match = asc._find_popover_song_row("Heaven", "Talking Heads")
        if match is None:
            pytest.skip(
                "Popover did not surface a Song row matching 'Heaven' by "
                "'Talking Heads' — Apple's autocomplete ranking can omit "
                "this candidate; not a code bug."
            )
        idx, resolved_artist = match
        assert idx >= 1, f"matched popover row index should be >= 1, got {idx}"
        # Resolved artist should contain "Talking Heads" — case-insensitive
        # because Music.app sometimes returns "talking heads" lower-cased.
        assert "talking heads" in resolved_artist.lower(), (
            f"popover-canonical-match returned wrong artist: expected "
            f"'Talking Heads', got {resolved_artist!r}. Disambiguation "
            f"may have picked a different artist's 'Heaven'."
        )
