import traceback
import asyncio
from copy import deepcopy
from multiprocessing import Process
from PyQt5.QtCore import QThread, pyqtSignal
from utils import conf, get_loop, QueuesManager, code_env, Queues
from utils.website.info import InfoMinix, BookInfo, Episode
from utils.processed_class import GuiQueuesManger, QueueHandler
from assets import res
from deploy.update import Proj
from GUI.core.font import font_color
from utils.middleware.timeline import Event, EventSource, TimelineStage, stage_from_process_name

from .ags import AggrSearchThread


class ClipTasksThread(QThread):
    info_signal = pyqtSignal(InfoMinix)
    total_signal = pyqtSignal(dict)

    def __init__(self, gui, tasks):
        super(ClipTasksThread, self).__init__(gui)  # 设置GUI为parent，确保正确的线程上下文
        self.gui = gui
        self.tasks = tasks

    def run(self):
        self.msleep(500)  # 延时，否则子线程太快导致主界面没跟上
        loop = get_loop()
        total = loop.run_until_complete(self._async_run())
        self.handle_total(total)

    async def _async_run(self):
        async with self.gui.spiderUtils.get_cli(conf, is_async=True) as cli:
            total = {}
            async def fetch_single(idx, url):
                _idx = idx + 1
                try:
                    resp = await cli.get(url, follow_redirects=True, timeout=6)
                    book = self.gui.spiderUtils.parse_book(resp.text)
                    self.msleep(30)
                    book.idx = _idx
                    book.preview_url = book.url = url
                    self.info_signal.emit(book)
                    return _idx, book
                except Exception as e:
                    err_msg = rf"{res.GUI.Clip.get_info_error}({url}): [{type(e).__name__}] {str(e)}"
                    self.gui.log.exception(e)
                    self.gui.say(font_color(err_msg + '<br>', cls='theme-err'), ignore_http=True)
                    return _idx, None
            # 并发执行所有任务
            tasks = [fetch_single(idx, url) for idx, url in enumerate(self.tasks)]
            results = await asyncio.gather(*tasks, return_exceptions=True)
            for result in results:
                if isinstance(result, Exception):
                    continue
                if result[1] is not None:
                    total[result[0]] = result[1]
            return total

    def check_condition_and_run_js(self):
        if self.iterations >= self.max_iterations:
            print("[clip tasks loop]❌over max_iterations, fail.")
            self.total_signal.emit(self.total)
            return
        self.iterations += 1
        self.gui.BrowserWindow.js_execute("checkDoneTasks();", self.handle_js_result)

    def handle_js_result(self, num):
        if num and num >= len(self.total):
            print("[clip tasks loop]✅finsh.")
            self.total_signal.emit(self.total)
            return
        self.msleep(250)
        self.check_condition_and_run_js()

    def handle_total(self, total):
        self.max_iterations = 7 * len(self.tasks)
        self.iterations = 0
        self.total = total
        if not total:
            self.total_signal.emit({})
            self.gui.say(font_color(res.GUI.Clip.all_fail, cls='theme-err'), ignore_http=True)
            self.gui.say(font_color(rf"<br>{res.GUI.Clip.view_log} [{conf.log_path}\GUI.log]", cls='theme-err', size=3))
        else:
            self.msleep(1200 if len(self.total) == 1 else 350)
            self.check_condition_and_run_js()


class QueueInitThread(QThread):
    init_completed = pyqtSignal(object, object, int)

    def __init__(self, gui):
        super().__init__(gui)
        self.gui = gui

    def run(self):
        guiQueuesManger = GuiQueuesManger()
        queue_port = guiQueuesManger.find_free_port()
        p_qm = Process(target=guiQueuesManger.create_server_manager)
        p_qm.daemon = False
        p_qm.start()
        manager = QueuesManager.create_manager(
            'InputFieldQueue', 'TextBrowserQueue', 'ProcessQueue', 'BarQueue', 'TasksQueue',
            address=('127.0.0.1', queue_port), authkey=b'abracadabra'
        )
        manager.connect()
        Q = QueueHandler(manager)
        self.gui.p_qm = p_qm
        self.gui.guiQueuesManger = guiQueuesManger
        self.init_completed.emit(manager, Q, queue_port)


class WorkThread(QThread):
    """only for monitor signals"""
    item_count_signal = pyqtSignal(int)
    print_signal = pyqtSignal(str)
    tasks_signal = pyqtSignal(object)
    mid_event_signal = pyqtSignal(object)
    # FR-3 signals
    books_ready_signal = pyqtSignal(object)
    eps_ready_signal = pyqtSignal(object)
    show_max_signal = pyqtSignal()
    preview_signal = pyqtSignal(str)
    keep_books_signal = pyqtSignal()
    process_state_signal = pyqtSignal(object)
    worker_finished_signal = pyqtSignal(str)

    def __init__(self, gui):
        super(WorkThread, self).__init__(gui)
        self.gui = gui
        self.active = True
        self._mid_last_stage = None

    def run(self):
        manager = self.gui.manager
        TextBrowser = manager.TextBrowserQueue()
        Bar = manager.BarQueue()
        _Tasks = manager.TasksQueue()
        ProcessQueue = manager.ProcessQueue()
        last_process_state = None
        _finish_flag = res.GUI.WorkThread_finish_flag
        _empty_flag = res.GUI.WorkThread_empty_flag
        _draining = False

        def emit_mid_event(stage: TimelineStage, payload: dict, source: EventSource):
            mgr = getattr(self.gui, "mid_mgr", None)
            if not mgr or not getattr(mgr, "enabled", False):
                return
            evt = Event(source=source, stage=stage, payload=payload or {})
            self.mid_event_signal.emit(evt)

        def emit_collection_ready(raw, item_type, ready_signal, ready_stage, wait_stage, payload_key):
            if not (isinstance(raw, dict) and all(isinstance(v, item_type) for v in raw.values())):
                return False
            data = deepcopy(raw)
            ready_signal.emit(data)
            emit_mid_event(ready_stage, {payload_key: deepcopy(data)}, EventSource.TEXTBROWSER_QUEUE)
            emit_mid_event(wait_stage, {}, EventSource.TEXTBROWSER_QUEUE)
            return True

        while self.active:
            self.msleep(5)
            try:
                if not TextBrowser.empty():
                    _ = TextBrowser.get().text
                    if emit_collection_ready(
                        _,
                        BookInfo,
                        self.books_ready_signal,
                        TimelineStage.BOOKS_READY,
                        TimelineStage.WAIT_BOOK_DECISION,
                        "books",
                    ):
                        pass
                    elif emit_collection_ready(
                        _,
                        Episode,
                        self.eps_ready_signal,
                        TimelineStage.EPS_READY,
                        TimelineStage.WAIT_EP_DECISION,
                        "eps",
                    ):
                        pass
                    elif "PreviewBookInfoEnd" in _:
                        self.preview_signal.emit(_)
                    elif "[ShowKeepBooks]" == _:
                        self.keep_books_signal.emit()
                    elif '[httpok]' in _:
                        self.print_signal.emit('[httpok]' + _.replace('[httpok]', ''))
                    elif _.endswith(f"{res.SPIDER.SayToGui.frame_section_print_extra}</font></p>"):
                        self.print_signal.emit(_)
                        self.show_max_signal.emit()
                    else:
                        self.print_signal.emit(_)
                    if isinstance(_, str) and (_finish_flag in _ or _empty_flag in _):
                        _draining = True
                    self.msleep(2)
                if not Bar.empty():
                    self.item_count_signal.emit(Bar.get())
                if not _Tasks.empty():
                    self.tasks_signal.emit(_Tasks.get())
                if _draining and TextBrowser.empty() and Bar.empty() and _Tasks.empty():
                    self.item_count_signal.emit(100)
                    break
                _process_state = Queues.recv(ProcessQueue)
                if _process_state and _process_state != last_process_state:
                    last_process_state = deepcopy(_process_state)
                    self.process_state_signal.emit(deepcopy(_process_state))
                    stage = stage_from_process_name(getattr(_process_state, "process", ""))
                    if stage is not None and stage != self._mid_last_stage:
                        self._mid_last_stage = stage
                        emit_mid_event(
                            stage,
                            {"process_state": deepcopy(_process_state)},
                            EventSource.PROCESS_QUEUE,
                        )
            except ConnectionResetError:
                self.active = False
        if self.active:
            self.worker_finished_signal.emit(str(conf.sv_path))

    def stop(self):
        self.active = False


class ProjUpdateThread(QThread):
    checked_signal = pyqtSignal(object)
    update_signal = pyqtSignal()
    toupdate_signal = pyqtSignal(object)
    debug_signal = pyqtSignal(str)

    def __init__(self, conf_dia):
        self.proj = None
        super(ProjUpdateThread, self).__init__(conf_dia)
        self.conf_dia = conf_dia
        self.is_update_requested = False
        self.log = conf.cLog(name="GUI")
        self.debug_signal.connect(self.conf_dia.gui.say)

    def run(self):
        try:
            self.proj = Proj(debug_signal=self.debug_signal)
            self.proj.check()
            self.checked_signal.emit(self.proj)
            while not self.is_update_requested and not self.isInterruptionRequested():
                self.msleep(100)  # 休眠100毫秒，减少CPU使用
            if self.is_update_requested and not self.isInterruptionRequested():
                self.run_update()
        except Exception as e:
            self.log.exception(f"ProjCheckError: {e}")
            self.checked_signal.emit(traceback.format_exc())

    def request_update(self):
        self.is_update_requested = True

    def run_update(self):
        self.toupdate_signal.emit(self.proj)


class RvThread(QThread):
    scan_completed = pyqtSignal(int)
    scan_progress = pyqtSignal(str)
    
    def __init__(self, gui, show_progress: bool = False):
        super().__init__(gui)
        self.gui = gui
        self.show_progress = show_progress
        
    def run(self):
        try:
            if self.show_progress:
                self.scan_progress.emit("backend scaning local...")
            self.gui.log.info(f"RvThread started, show_progress={self.show_progress}")
            total = self.gui.rv_tools.scan(conf, init=False)
            self.gui.log.info(f"RvThread completed: scanned {total} books/episodes")
            if self.show_progress:
                self.scan_completed.emit(total)
        except Exception as e:
            self.gui.log.exception(f"RvThread error: {e}")
            self.gui.say(f"scan err: {str(e)}")
