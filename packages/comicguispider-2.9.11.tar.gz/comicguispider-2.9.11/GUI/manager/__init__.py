import os
import contextlib
import subprocess

from GUI.core.timer import safe_single_shot
from qfluentwidgets import (
    InfoBarPosition, StateToolTip
)

from assets import res
from variables import PYPI_SOURCE, CGS_DOC
from datetime import date
from deploy.update import Proj, UpdateState
from utils import conf, env, uv_exc, exc_p
from GUI.uic.qfluent.components import (
    CustomInfoBar, UpdaterMessageBox, CustomBadge
)
from GUI.manager.async_task import AsyncTaskManager, TaskConfig
from GUI.manager.clip import ClipGUIManager
from GUI.manager.ags import AggrSearchManager
from GUI.manager.rv import RVManager
from GUI.manager.mid import CGSMidManagerGUI
from GUI.manager.preview import MangaPreviewManager
from GUI.manager.task_progress import TaskProgressManager
from GUI.manager.publish import PublishDomainManager

__all__ = [
    'Updater', 'UpdateNotifier', 'TaskConfig',
    'RVManager', 'TaskProgressManager','AsyncTaskManager',
    'ClipGUIManager', 'AggrSearchManager', 'CGSMidManagerGUI',
    'MangaPreviewManager', 'PublishDomainManager'
]


class UpdateNotifier:
    def __init__(self, gui):
        self.gui = gui
        self.state = UpdateState()
        self._badges = []

    def check_on_startup(self):
        self.refresh_badges()
        if not self.state.needs_check_today():
            return
        self.gui.preprocess_mgr.task_manager.execute_simple_task(
            task_func=self._do_check,
            success_callback=self.on_check_done,
            error_callback=lambda _: None,
            show_tooltip=False,
            show_success_info=False,
            show_error_info=False,
            task_id="update_check_startup",
        )

    @staticmethod
    def _do_check():
        proj = Proj()
        proj.check()
        return proj

    def on_check_done(self, proj):
        self.state.last_check_date = date.today().isoformat()
        self.state.update_flag = proj.update_flag
        info = proj.update_info or {}
        self.state.update_info = {
            "tag_name": info.get("tag_name", ""),
            "body": info.get("body", ""),
            "html_url": info.get("html_url", ""),
        }
        self.state.save()
        self.refresh_badges()

    def refresh_badges(self):
        flag = self.state.update_flag
        info = self.state.update_info or {}
        tag_name = info.get("tag_name", "")

        if flag == "dev" and conf.skipDev:
            flag = "local"
        if flag != "local" and tag_name and tag_name == conf.skipped_version:
            flag = "local"

        self._clear_badges()
        if flag in ("stable", "dev"):
            self._show_badges()

    def _show_badges(self):
        badge = CustomBadge.make_ani_dot(self.gui.funcGroupBox, target=self.gui.confBtn)
        badge.show()
        self._badges.append(badge)
        badge2 = CustomBadge.make_ani_dot(self.gui.conf_dia, target=self.gui.conf_dia.updateBtn)
        badge2.show()
        self._badges.append(badge2)

    def _clear_badges(self):
        for badge in self._badges:
            with contextlib.suppress(RuntimeError):
                badge.hide()
                badge.deleteLater()
        self._badges.clear()

    def on_version_skipped(self, tag_name: str):
        conf.update(skipped_version=tag_name)
        self.refresh_badges()

    def on_updated_or_dismissed(self):
        self._clear_badges()


class Updater:
    res = res.Updater
    proj = None
    version = None
    stateTooltip = None
    changelog_url = f'{CGS_DOC}/changelog/history'

    def __init__(self, gui):
        self.gui = gui
        self.conf_dia = self.gui.conf_dia

    def run(self):
        def _close_thread():
            if self.conf_dia.puThread:
                self.conf_dia.puThread.quit()
                self.conf_dia.puThread.wait()

        def to_update(recv):
            with contextlib.suppress(Exception):
                self.gui.updaterStateTooltip.setContent("Finish..")
                self.gui.updaterStateTooltip.setState(True)
                self.gui.updaterStateTooltip = None
            ver = recv.update_info.get("tag_name")
            CustomInfoBar.show("", self.res.to_update,
                self.gui.showArea, self.proj.update_info.get("html_url"),
                f"""<{ver}>""", _type="SUCCESS")
            _close_thread()
            self.gui.update_notifier.on_updated_or_dismissed()
            safe_single_shot(4000, lambda: self.to_update(ver))

        def checked(recv):
            with contextlib.suppress(RuntimeError):
                self.stateTooltip.setState(True)
                self.stateTooltip = None
            if isinstance(recv, str):
                self.gui.textBrowser.append(recv)
                CustomInfoBar.show("", self.res.ver_check_fail, self.gui.showArea,
                                   f"{Proj.url}/releases", "access releases", _type="ERROR")
                _close_thread()
                return
            self.proj = recv
            print(f"checked: {recv.update_flag}")
            if recv.update_flag == "local":
                CustomInfoBar.show("", self.res.ver_local_latest,
                self.conf_dia, f"https://github.com/jasoneri/ComicGUISpider/releases/tag/{recv.local_ver}",
                f"""updateInfo-<{recv.local_ver}> """, _type="SUCCESS",
                duration=7000, position=InfoBarPosition.BOTTOM_LEFT)
            else:
                match recv.update_flag:
                    case "stable":
                        title = f"📫{res.GUI.Uic.confDia_updateDialog_stable} ⭐️{recv.update_info.get('tag_name')}"
                    case "dev":
                        title = f"📫{res.GUI.Uic.confDia_updateDialog_dev} 🧪{recv.update_info.get('tag_name')}"
                    case _:
                        title = ""
                self.gui.update_dialog = UpdaterMessageBox(title, self.gui, tag_name=recv.update_info.get("tag_name", ""))
                self.gui.update_dialog.show_release_note(recv.update_info.get("body", ""))
            self.gui.update_notifier.on_check_done(recv)
        self.stateTooltip = StateToolTip("Checking..", "", self.conf_dia.cookiesEdit)
        self.stateTooltip.show()
        self.conf_dia.puThread.checked_signal.connect(checked)
        self.conf_dia.puThread.update_signal.connect(self.conf_dia.puThread.request_update)
        self.conf_dia.puThread.toupdate_signal.connect(to_update)
        self.conf_dia.puThread.start()

    def rerun(self):
        cmd = ["cgs"]
        subprocess.Popen(cmd, cwd=exc_p, env=env)
        safe_single_shot(1000, self.gui.close)

    def to_update(self, ver):
        _UpdateLauncher(ver).run()
        self.gui.close()


class _UpdateLauncher:
    def __init__(self, ver: str, script: bool = False):
        self.ver = ver
        self.script = script
        pkg = "ComicGUISpider[script]" if script else "ComicGUISpider"
        self.install_spec = f"{pkg}=={ver}"
        self.index_url = PYPI_SOURCE[conf.pypi_source]
        self.log_path = exc_p / "cgs_update.log"
        self.installer_exe = exc_p / "runtime" / "installer.exe"

    def run(self):
        if os.name == "nt" and self.installer_exe.exists():
            self._run_installer()
            return
        if os.name == "nt":
            self._run_windows_fallback()
            return
        self._run_posix_fallback()

    def _run_installer(self):
        args = [
            str(self.installer_exe),
            "--version", self.ver,
            "--uv-exc", uv_exc,
            "--index-url", self.index_url,
            "--parent-pid", str(os.getpid()),
        ]
        if self.script:
            args.append("--script")
        for key in ("UV_TOOL_DIR", "UV_TOOL_BIN_DIR"):
            value = os.environ.get(key)
            if value:
                args.extend([f"--{key.lower().replace('_', '-')}", value])
        subprocess.Popen(args, creationflags=subprocess.CREATE_NEW_CONSOLE, env=env)

    def _run_windows_fallback(self):
        ps1_path = exc_p / "updater.ps1"
        script = r"""param(
    [Parameter(Mandatory = $true)][string]$UvExe,
    [Parameter(Mandatory = $true)][string]$InstallSpec,
    [Parameter(Mandatory = $true)][string]$IndexUrl,
    [Parameter(Mandatory = $true)][string]$LogPath,
    [string]$UvToolDir = "",
    [string]$UvToolBinDir = ""
)

if ($UvToolDir) { $env:UV_TOOL_DIR = $UvToolDir }
if ($UvToolBinDir) { $env:UV_TOOL_BIN_DIR = $UvToolBinDir }

& $UvExe tool install $InstallSpec --force --index-url $IndexUrl 2>&1 |
    Tee-Object -FilePath $LogPath

if ($LASTEXITCODE -ne 0) {
    Write-Host "`nUpdate failed (exit code: $LASTEXITCODE)" -ForegroundColor Red
}

Read-Host "Press Enter to close"
"""
        self._write(ps1_path, script)
        subprocess.Popen(
            [
                "powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-NoExit",
                "-File", str(ps1_path),
                "-UvExe", uv_exc,
                "-InstallSpec", self.install_spec,
                "-IndexUrl", self.index_url,
                "-LogPath", str(self.log_path),
                "-UvToolDir", os.environ.get("UV_TOOL_DIR", ""),
                "-UvToolBinDir", os.environ.get("UV_TOOL_BIN_DIR", ""),
            ],
            creationflags=subprocess.CREATE_NEW_CONSOLE,
            env=env,
        )

    def _run_posix_fallback(self):
        sh_path = exc_p / "updater.sh"
        script = """#!/bin/sh
uv_exe="$1"
install_spec="$2"
index_url="$3"
log_path="$4"

"$uv_exe" tool install "$install_spec" --force --index-url "$index_url" 2>&1 | tee -a "$log_path"
echo "done"
printf "Press any key to close..."
stty -icanon -echo
dd bs=1 count=1 >/dev/null 2>&1
stty icanon echo
"""
        self._write(sh_path, script)
        os.chmod(sh_path, 0o755)
        subprocess.Popen(
            ["setsid", "sh", str(sh_path), uv_exc, self.install_spec, self.index_url, str(self.log_path)],
            start_new_session=True,
            env=env,
        )

    @staticmethod
    def _write(path, content: str):
        path.write_text(content, encoding="utf-8")
