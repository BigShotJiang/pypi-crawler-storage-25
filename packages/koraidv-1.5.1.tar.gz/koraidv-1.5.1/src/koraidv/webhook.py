"""Webhook signature verification and payload parsing.

Uses ``hmac`` and ``hashlib`` from the standard library for HMAC-SHA256
signature verification with constant-time comparison.
"""

from __future__ import annotations

import hashlib
import hmac
import json
import time as _time
from typing import Callable, Optional, Union

from .types import WebhookPayload


# Default replay-protection window: 5 minutes (300 seconds).
# Webhooks with a timestamp older than this are rejected even if the
# signature is otherwise valid. Matches the Stripe / GitHub default.
DEFAULT_TOLERANCE_SECONDS = 300


def verify_webhook_signature(
    payload: bytes,
    signature: str,
    timestamp: Union[str, int],
    secret: str,
    *,
    tolerance_seconds: int = DEFAULT_TOLERANCE_SECONDS,
    now: Optional[Callable[[], float]] = None,
) -> bool:
    """Verify a Kora IDV webhook's HMAC-SHA256 signature.

    Reads the ``X-Signature`` and ``X-Timestamp`` headers from the incoming
    request. The signature is the hex-encoded HMAC-SHA256 of
    ``"{timestamp}.{body}"`` — the timestamp prefix prevents replay attacks.

    Args:
        payload:           Raw request body bytes.
        signature:         The ``X-Signature`` header value (hex-encoded).
        timestamp:         The ``X-Timestamp`` header value (Unix seconds).
        secret:            The webhook signing secret.
        tolerance_seconds: Maximum age of the webhook before it's rejected
                           as a replay. Defaults to 300 (5 minutes). Set
                           to 0 to disable the check (not recommended).
        now:               Override for the current time (Unix seconds).
                           Use only for deterministic testing.

    Returns:
        ``True`` if the signature is valid and the timestamp is recent.

    Example::

        from koraidv import verify_webhook_signature

        @app.post("/webhooks/koraidv")
        async def handle(request):
            body = await request.body()
            if not verify_webhook_signature(
                body,
                request.headers["x-signature"],
                request.headers["x-timestamp"],
                os.environ["KORAIDV_WEBHOOK_SECRET"],
            ):
                return Response(status_code=401)
            ...
    """
    if not signature or timestamp is None:
        return False

    try:
        ts = int(timestamp)
    except (TypeError, ValueError):
        return False

    if ts <= 0:
        return False

    if tolerance_seconds > 0:
        current = (now or _time.time)()
        if abs(current - ts) > tolerance_seconds:
            return False

    expected = hmac.new(
        secret.encode("utf-8"),
        f"{ts}.".encode("utf-8") + payload,
        hashlib.sha256,
    ).hexdigest()

    return hmac.compare_digest(expected, signature)


def parse_webhook_payload(body: Union[str, bytes]) -> WebhookPayload:
    """Parse a webhook request body into a :class:`WebhookPayload`.

    Args:
        body: The raw request body as ``str`` or ``bytes``.

    Returns:
        A :class:`WebhookPayload` dataclass instance.

    Raises:
        ValueError: If *body* is not valid JSON.
    """
    if isinstance(body, bytes):
        body = body.decode("utf-8")

    try:
        data = json.loads(body)
    except json.JSONDecodeError as exc:
        raise ValueError(f"Invalid webhook payload JSON: {exc}") from exc

    return WebhookPayload.from_dict(data)
