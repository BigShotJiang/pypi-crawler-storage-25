"""Data types for the Kora IDV Python SDK.

All types use snake_case field names. The ``from_dict`` classmethods accept
dicts keyed with the camelCase names used in the JSON API and convert them
to Pythonic snake_case attributes.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Optional


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _get(data: dict[str, Any], *keys: str, default: Any = None) -> Any:
    """Return the first matching key from *data*, or *default*."""
    for key in keys:
        if key in data:
            return data[key]
    return default


# ---------------------------------------------------------------------------
# Score types
# ---------------------------------------------------------------------------

@dataclass
class DocAuthScores:
    """Document authenticity analysis scores."""

    template_score: float = 0.0
    font_score: float = 0.0
    photo_integrity: float = 0.0
    compression_score: float = 0.0
    edge_score: float = 0.0
    tamper_detected: bool = False
    tamper_type: Optional[str] = None
    tamper_confidence: float = 0.0

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> DocAuthScores:
        return cls(
            template_score=float(_get(data, "templateScore", "template_score", default=0)),
            font_score=float(_get(data, "fontScore", "font_score", default=0)),
            photo_integrity=float(_get(data, "photoIntegrity", "photo_integrity", default=0)),
            compression_score=float(_get(data, "compressionScore", "compression_score", default=0)),
            edge_score=float(_get(data, "edgeScore", "edge_score", default=0)),
            tamper_detected=bool(_get(data, "tamperDetected", "tamper_detected", default=False)),
            tamper_type=_get(data, "tamperType", "tamper_type"),
            tamper_confidence=float(_get(data, "tamperConfidence", "tamper_confidence", default=0)),
        )


@dataclass
class AntiSpoofScores:
    """Anti-spoofing analysis scores."""

    texture_score: float = 0.0
    frequency_score: float = 0.0
    challenge_score: float = 0.0
    temporal_score: float = 0.0
    quality_score: float = 0.0
    spoof_detected: bool = False
    spoof_type: Optional[str] = None
    spoof_confidence: float = 0.0

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> AntiSpoofScores:
        return cls(
            texture_score=float(_get(data, "textureScore", "texture_score", default=0)),
            frequency_score=float(_get(data, "frequencyScore", "frequency_score", default=0)),
            challenge_score=float(_get(data, "challengeScore", "challenge_score", default=0)),
            temporal_score=float(_get(data, "temporalScore", "temporal_score", default=0)),
            quality_score=float(_get(data, "qualityScore", "quality_score", default=0)),
            spoof_detected=bool(_get(data, "spoofDetected", "spoof_detected", default=False)),
            spoof_type=_get(data, "spoofType", "spoof_type"),
            spoof_confidence=float(_get(data, "spoofConfidence", "spoof_confidence", default=0)),
        )


@dataclass
class VerificationScores:
    """Composite verification scores."""

    document_quality: float = 0.0
    document_auth: float = 0.0
    face_match: float = 0.0
    face_embedding_similarity: float = 0.0
    face_match_confidence: float = 0.0
    liveness: float = 0.0
    data_consistency: float = 0.0
    mrz_validity: Optional[float] = None
    overall: float = 0.0
    anti_spoof_scores: Optional[AntiSpoofScores] = None
    doc_auth_scores: Optional[DocAuthScores] = None

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> VerificationScores:
        anti_spoof_raw = _get(data, "antiSpoofScores", "anti_spoof_scores")
        doc_auth_raw = _get(data, "docAuthScores", "doc_auth_scores")
        return cls(
            document_quality=float(_get(data, "documentQuality", "document_quality", default=0)),
            document_auth=float(_get(data, "documentAuth", "document_auth", default=0)),
            face_match=float(_get(data, "faceMatch", "face_match", default=0)),
            face_embedding_similarity=float(_get(data, "faceEmbeddingSimilarity", "face_embedding_similarity", default=0)),
            face_match_confidence=float(_get(data, "faceMatchConfidence", "face_match_confidence", default=0)),
            liveness=float(_get(data, "liveness", default=0)),
            data_consistency=float(_get(data, "dataConsistency", "data_consistency", default=0)),
            mrz_validity=_get(data, "mrzValidity", "mrz_validity"),
            overall=float(_get(data, "overall", default=0)),
            anti_spoof_scores=AntiSpoofScores.from_dict(anti_spoof_raw) if anti_spoof_raw else None,
            doc_auth_scores=DocAuthScores.from_dict(doc_auth_raw) if doc_auth_raw else None,
        )


# ---------------------------------------------------------------------------
# Verification
# ---------------------------------------------------------------------------

@dataclass
class Verification:
    """A verification session."""

    id: str = ""
    tenant_id: str = ""
    external_id: str = ""
    status: str = ""
    decision: Optional[str] = None
    tier: str = ""
    document_id: Optional[str] = None
    liveness_session_id: Optional[str] = None
    scores: Optional[VerificationScores] = None
    decision_reason: Optional[str] = None
    reviewed_by: Optional[str] = None
    review_notes: Optional[str] = None
    submitted_at: Optional[str] = None
    verified_at: Optional[str] = None
    expires_at: Optional[str] = None
    attempt_count: int = 0
    metadata: Optional[dict[str, Any]] = None
    created_at: str = ""
    updated_at: str = ""

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> Verification:
        scores_raw = _get(data, "scores")
        return cls(
            id=_get(data, "id", default=""),
            tenant_id=_get(data, "tenantId", "tenant_id", default=""),
            external_id=_get(data, "externalId", "external_id", default=""),
            status=_get(data, "status", default=""),
            decision=_get(data, "decision"),
            tier=_get(data, "tier", default=""),
            document_id=_get(data, "documentId", "document_id"),
            liveness_session_id=_get(data, "livenessSessionId", "liveness_session_id"),
            scores=VerificationScores.from_dict(scores_raw) if scores_raw else None,
            decision_reason=_get(data, "decisionReason", "decision_reason"),
            reviewed_by=_get(data, "reviewedBy", "reviewed_by"),
            review_notes=_get(data, "reviewNotes", "review_notes"),
            submitted_at=_get(data, "submittedAt", "submitted_at"),
            verified_at=_get(data, "verifiedAt", "verified_at"),
            expires_at=_get(data, "expiresAt", "expires_at"),
            attempt_count=int(_get(data, "attemptCount", "attempt_count", default=0)),
            metadata=_get(data, "metadata"),
            created_at=_get(data, "createdAt", "created_at", default=""),
            updated_at=_get(data, "updatedAt", "updated_at", default=""),
        )


# ---------------------------------------------------------------------------
# Document
# ---------------------------------------------------------------------------

@dataclass
class OCRResult:
    """OCR extraction result from a document image."""

    full_text: str = ""
    text_blocks: list[str] = field(default_factory=list)
    language: str = ""
    confidence: float = 0.0
    mrz_detected: bool = False
    face_count: int = 0

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> OCRResult:
        return cls(
            full_text=_get(data, "fullText", "full_text", default=""),
            text_blocks=_get(data, "textBlocks", "text_blocks", default=[]),
            language=_get(data, "language", default=""),
            confidence=float(_get(data, "confidence", default=0)),
            mrz_detected=bool(_get(data, "mrzDetected", "mrz_detected", default=False)),
            face_count=int(_get(data, "faceCount", "face_count", default=0)),
        )


@dataclass
class DocumentUploadResponse:
    """Response from uploading a document image."""

    document_id: str = ""
    document_type: str = ""
    quality_score: float = 0.0
    ocr_result: Optional[OCRResult] = None
    extracted_data: Optional[dict[str, Any]] = None

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> DocumentUploadResponse:
        ocr_raw = _get(data, "ocrResult", "ocr_result")
        return cls(
            document_id=_get(data, "documentId", "document_id", default=""),
            document_type=_get(data, "documentType", "document_type", default=""),
            quality_score=float(_get(data, "qualityScore", "quality_score", default=0)),
            ocr_result=OCRResult.from_dict(ocr_raw) if ocr_raw else None,
            extracted_data=_get(data, "extractedData", "extracted_data"),
        )


# ---------------------------------------------------------------------------
# Selfie
# ---------------------------------------------------------------------------

@dataclass
class SelfieUploadResponse:
    """Response from uploading a selfie image."""

    face_detected: bool = False
    face_count: int = 0
    quality_score: float = 0.0
    warnings: list[str] = field(default_factory=list)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> SelfieUploadResponse:
        return cls(
            face_detected=bool(_get(data, "faceDetected", "face_detected", default=False)),
            face_count=int(_get(data, "faceCount", "face_count", default=0)),
            quality_score=float(_get(data, "qualityScore", "quality_score", default=0)),
            warnings=_get(data, "warnings", default=[]),
        )


# ---------------------------------------------------------------------------
# Liveness
# ---------------------------------------------------------------------------

@dataclass
class LivenessChallenge:
    """A single liveness challenge within a session."""

    type: str = ""
    completed: bool = False
    score: float = 0.0
    attempted_at: Optional[str] = None

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> LivenessChallenge:
        return cls(
            type=_get(data, "type", default=""),
            completed=bool(_get(data, "completed", default=False)),
            score=float(_get(data, "score", default=0)),
            attempted_at=_get(data, "attemptedAt", "attempted_at"),
        )


@dataclass
class LivenessSession:
    """A liveness verification session."""

    id: str = ""
    verification_id: str = ""
    challenges: list[LivenessChallenge] = field(default_factory=list)
    overall_score: float = 0.0
    passed: bool = False
    anti_spoof_result: Optional[AntiSpoofScores] = None
    created_at: str = ""

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> LivenessSession:
        challenges_raw = _get(data, "challenges", default=[])
        anti_spoof_raw = _get(data, "antiSpoofResult", "anti_spoof_result")
        return cls(
            id=_get(data, "id", default=""),
            verification_id=_get(data, "verificationId", "verification_id", default=""),
            challenges=[LivenessChallenge.from_dict(c) for c in challenges_raw],
            overall_score=float(_get(data, "overallScore", "overall_score", default=0)),
            passed=bool(_get(data, "passed", default=False)),
            anti_spoof_result=AntiSpoofScores.from_dict(anti_spoof_raw) if anti_spoof_raw else None,
            created_at=_get(data, "createdAt", "created_at", default=""),
        )


@dataclass
class LivenessChallengeResponse:
    """Response from submitting a liveness challenge."""

    challenge_type: str = ""
    completed: bool = False
    score: float = 0.0
    all_completed: bool = False

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> LivenessChallengeResponse:
        return cls(
            challenge_type=_get(data, "challengeType", "challenge_type", default=""),
            completed=bool(_get(data, "completed", default=False)),
            score=float(_get(data, "score", default=0)),
            all_completed=bool(_get(data, "allCompleted", "all_completed", default=False)),
        )


# ---------------------------------------------------------------------------
# Document types / countries
#
# Note: This is a convenience subset. The full list of supported document types
# (270+) is available via client.get_document_types(). New types are added on
# the backend without requiring SDK updates.
# ---------------------------------------------------------------------------

@dataclass
class DocumentTypeInfo:
    """Metadata about a supported document type."""

    type: str = ""
    name: str = ""
    country: str = ""
    has_mrz: bool = False
    requires_back: bool = False
    supported_ocr: bool = False

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> DocumentTypeInfo:
        return cls(
            type=_get(data, "type", default=""),
            name=_get(data, "name", default=""),
            country=_get(data, "country", default=""),
            has_mrz=bool(_get(data, "hasMrz", "has_mrz", default=False)),
            requires_back=bool(_get(data, "requiresBack", "requires_back", default=False)),
            supported_ocr=bool(_get(data, "supportedOcr", "supported_ocr", default=False)),
        )


@dataclass
class CountryInfo:
    """A supported country."""

    code: str = ""
    name: str = ""

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> CountryInfo:
        return cls(
            code=_get(data, "code", default=""),
            name=_get(data, "name", default=""),
        )


@dataclass
class DocumentTypesResult:
    """Result from querying supported document types."""

    success: bool = False
    document_types: list[DocumentTypeInfo] = field(default_factory=list)
    countries: list[CountryInfo] = field(default_factory=list)
    total: int = 0

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> DocumentTypesResult:
        doc_types_raw = _get(data, "documentTypes", "document_types", default=[])
        countries_raw = _get(data, "countries", default=[])
        return cls(
            success=bool(_get(data, "success", default=False)),
            document_types=[DocumentTypeInfo.from_dict(d) for d in doc_types_raw],
            countries=[CountryInfo.from_dict(c) for c in countries_raw],
            total=int(_get(data, "total", default=0)),
        )


# ---------------------------------------------------------------------------
# Fraud alerts
# ---------------------------------------------------------------------------

@dataclass
class FraudAlert:
    """A fraud alert."""

    id: str = ""
    tenant_id: str = ""
    verification_id: str = ""
    external_id: str = ""
    alert_type: str = ""
    severity: str = ""
    description: str = ""
    status: str = ""
    created_at: str = ""

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> FraudAlert:
        return cls(
            id=_get(data, "id", default=""),
            tenant_id=_get(data, "tenantId", "tenant_id", default=""),
            verification_id=_get(data, "verificationId", "verification_id", default=""),
            external_id=_get(data, "externalId", "external_id", default=""),
            alert_type=_get(data, "alertType", "alert_type", default=""),
            severity=_get(data, "severity", default=""),
            description=_get(data, "description", default=""),
            status=_get(data, "status", default=""),
            created_at=_get(data, "createdAt", "created_at", default=""),
        )


# ---------------------------------------------------------------------------
# Webhook payload
# ---------------------------------------------------------------------------

@dataclass
class WebhookPayload:
    """Incoming webhook payload from Kora IDV."""

    id: str = ""
    event_type: str = ""
    resource_type: str = ""
    resource_id: str = ""
    tenant_id: str = ""
    timestamp: str = ""
    data: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> WebhookPayload:
        return cls(
            id=_get(data, "id", default=""),
            event_type=_get(data, "eventType", "event_type", default=""),
            resource_type=_get(data, "resourceType", "resource_type", default=""),
            resource_id=_get(data, "resourceId", "resource_id", default=""),
            tenant_id=_get(data, "tenantId", "tenant_id", default=""),
            timestamp=_get(data, "timestamp", default=""),
            data=_get(data, "data", default={}),
        )
