"""Kora IDV API client.

Uses only the Python standard library (``urllib.request``, ``json``) so the
package has **zero** runtime dependencies.
"""

from __future__ import annotations

import json
import urllib.error
import urllib.request
from typing import Any, Optional

from .errors import KoraIDVError
from .types import (
    DocumentTypesResult,
    DocumentUploadResponse,
    FraudAlert,
    LivenessChallengeResponse,
    LivenessSession,
    SelfieUploadResponse,
    Verification,
)

_SANDBOX_URL = "https://api.korastratum.com/api/v1/idv"
_PRODUCTION_URL = "https://api.korastratum.com/api/v1/idv"
_DEFAULT_TIMEOUT = 30  # seconds


class KoraIDVClient:
    """Synchronous client for the Kora IDV REST API.

    Parameters:
        api_key:  Tenant API key.  Keys prefixed with ``test_`` automatically
                  target the sandbox environment.
        tenant_id: Tenant identifier sent via the ``X-Tenant-ID`` header.
        base_url:  Override the auto-detected base URL.
        timeout:   HTTP request timeout in seconds (default 30).
    """

    def __init__(
        self,
        api_key: str,
        tenant_id: str,
        *,
        base_url: str | None = None,
        timeout: int = _DEFAULT_TIMEOUT,
    ) -> None:
        if base_url is not None:
            self._base_url = base_url.rstrip("/").removesuffix("/api/v1")
        elif api_key.startswith("test_"):
            self._base_url = _SANDBOX_URL
        else:
            self._base_url = _PRODUCTION_URL

        self._api_key = api_key
        self._tenant_id = tenant_id
        self._timeout = timeout

    # -- properties ---------------------------------------------------------

    @property
    def base_url(self) -> str:
        """The resolved base URL used for API requests."""
        return self._base_url

    # -- internal helpers ---------------------------------------------------

    def _request(
        self,
        method: str,
        path: str,
        body: dict[str, Any] | None = None,
        *,
        extra_headers: dict[str, str] | None = None,
    ) -> bytes:
        """Perform an authenticated HTTP request and return the raw body.

        Raises :class:`KoraIDVError` (or a subclass) on HTTP >= 400.
        """
        url = self._base_url + path
        data: bytes | None = None
        if body is not None:
            data = json.dumps(body).encode("utf-8")

        req = urllib.request.Request(url, data=data, method=method)
        req.add_header("Content-Type", "application/json")
        req.add_header("X-Tenant-ID", self._tenant_id)
        if self._api_key:
            req.add_header("Authorization", f"Bearer {self._api_key}")
        if extra_headers:
            for key, value in extra_headers.items():
                req.add_header(key, value)

        try:
            with urllib.request.urlopen(req, timeout=self._timeout) as resp:
                return resp.read()
        except urllib.error.HTTPError as exc:
            resp_body = exc.read()
            try:
                error_data = json.loads(resp_body)
            except (json.JSONDecodeError, ValueError):
                error_data = {"error": resp_body.decode("utf-8", errors="replace")}
            raise KoraIDVError.from_dict(exc.code, error_data) from None

    # -- API methods --------------------------------------------------------

    def health(self) -> None:
        """Check that the API is healthy (``GET /health``)."""
        self._request("GET", "/health")

    def get_document_types(
        self,
        country: str | None = None,
    ) -> DocumentTypesResult:
        """Retrieve supported document types.

        Args:
            country: Optional ISO country code to filter by.

        Returns:
            A :class:`DocumentTypesResult` with the available document types.
        """
        path = "/api/v1/document-types"
        if country:
            path = f"{path}?country={country}"
        data = json.loads(self._request("GET", path))
        return DocumentTypesResult.from_dict(data)

    def create_verification(
        self,
        external_id: str,
        *,
        tier: str = "standard",
        callback_url: str | None = None,
        document_type: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> Verification:
        """Create a new verification session.

        Args:
            external_id:   Your own user/subject identifier.
            tier:          Verification tier (``basic``, ``standard``, etc.).
            callback_url:  Optional URL for status callbacks.
            document_type: Optional document type hint.
            metadata:      Optional free-form metadata dict.

        Returns:
            The newly created :class:`Verification`.
        """
        body: dict[str, Any] = {
            "externalId": external_id,
            "tier": tier,
        }
        if callback_url is not None:
            body["callbackUrl"] = callback_url
        if document_type is not None:
            body["documentType"] = document_type
        if metadata is not None:
            body["metadata"] = metadata

        data = json.loads(self._request("POST", "/api/v1/verifications", body))
        return Verification.from_dict(data)

    def get_verification(self, verification_id: str) -> Verification:
        """Retrieve a verification by ID.

        Args:
            verification_id: The verification UUID.

        Returns:
            The :class:`Verification` object.
        """
        data = json.loads(
            self._request("GET", f"/api/v1/verifications/{verification_id}")
        )
        return Verification.from_dict(data)

    def list_verifications(self, external_id: str) -> list[Verification]:
        """List all verifications for a subject.

        Args:
            external_id: The subject's external identifier.

        Returns:
            A list of :class:`Verification` objects.
        """
        data = json.loads(
            self._request("GET", f"/api/v1/subjects/{external_id}/verifications")
        )
        return [Verification.from_dict(v) for v in data.get("verifications", [])]

    def generate_compliance_report(self, verification_id: str) -> bytes:
        """Return the regulator-ready compliance report PDF bytes for a
        completed verification (REQ-001). Rate-limited to 100 requests per
        minute per tenant.
        """
        return self._request(
            "GET", f"/api/v1/verifications/{verification_id}/report"
        )

    def generate_compliance_reports_bulk(
        self, verification_ids: list[str]
    ) -> bytes:
        """Return a ZIP archive of PDFs for the given verifications.

        Args:
            verification_ids: Up to 100 verification IDs to include.
        """
        return self._request(
            "POST",
            "/api/v1/reports/bulk",
            body={"verificationIds": verification_ids},
        )

    def upload_document(
        self,
        verification_id: str,
        document_type: str,
        image_base64: str,
    ) -> DocumentUploadResponse:
        """Upload the front side of a document.

        Args:
            verification_id: The verification UUID.
            document_type:   Document type string (e.g. ``"passport"``).
            image_base64:    Base64-encoded document image.

        Returns:
            A :class:`DocumentUploadResponse` with quality and OCR data.
        """
        body = {"documentType": document_type, "imageBase64": image_base64}
        data = json.loads(
            self._request(
                "POST", f"/api/v1/verifications/{verification_id}/document", body
            )
        )
        return DocumentUploadResponse.from_dict(data)

    def upload_document_back(
        self,
        verification_id: str,
        image_base64: str,
    ) -> DocumentUploadResponse:
        """Upload the back side of a document.

        Args:
            verification_id: The verification UUID.
            image_base64:    Base64-encoded image of the document back.

        Returns:
            A :class:`DocumentUploadResponse`.
        """
        body = {"imageBase64": image_base64}
        data = json.loads(
            self._request(
                "POST",
                f"/api/v1/verifications/{verification_id}/document/back",
                body,
            )
        )
        return DocumentUploadResponse.from_dict(data)

    def upload_selfie(
        self,
        verification_id: str,
        image_base64: str,
    ) -> SelfieUploadResponse:
        """Upload a selfie image for face matching.

        Args:
            verification_id: The verification UUID.
            image_base64:    Base64-encoded selfie image.

        Returns:
            A :class:`SelfieUploadResponse`.
        """
        body = {"imageBase64": image_base64}
        data = json.loads(
            self._request(
                "POST", f"/api/v1/verifications/{verification_id}/selfie", body
            )
        )
        return SelfieUploadResponse.from_dict(data)

    def create_liveness_session(
        self,
        verification_id: str,
    ) -> LivenessSession:
        """Create a new liveness verification session.

        Args:
            verification_id: The verification UUID.

        Returns:
            A :class:`LivenessSession` containing the challenges to complete.
        """
        data = json.loads(
            self._request(
                "POST",
                f"/api/v1/verifications/{verification_id}/liveness/session",
            )
        )
        return LivenessSession.from_dict(data)

    def submit_liveness_challenge(
        self,
        verification_id: str,
        challenge_type: str,
        image_base64: str,
    ) -> LivenessChallengeResponse:
        """Submit a response to a liveness challenge.

        Args:
            verification_id: The verification UUID.
            challenge_type:  Challenge type (e.g. ``"blink"``, ``"turn_left"``).
            image_base64:    Base64-encoded image frame.

        Returns:
            A :class:`LivenessChallengeResponse`.
        """
        body = {"challengeType": challenge_type, "imageBase64": image_base64}
        data = json.loads(
            self._request(
                "POST",
                f"/api/v1/verifications/{verification_id}/liveness/challenge",
                body,
            )
        )
        return LivenessChallengeResponse.from_dict(data)

    def get_liveness_result(
        self,
        verification_id: str,
    ) -> LivenessSession:
        """Retrieve the liveness session result.

        Args:
            verification_id: The verification UUID.

        Returns:
            A :class:`LivenessSession` with the final scores.
        """
        data = json.loads(
            self._request(
                "GET", f"/api/v1/verifications/{verification_id}/liveness"
            )
        )
        return LivenessSession.from_dict(data)

    def complete_verification(self, verification_id: str) -> Verification:
        """Mark a verification as complete and request the final decision.

        Args:
            verification_id: The verification UUID.

        Returns:
            The completed :class:`Verification` with scores and decision.
        """
        data = json.loads(
            self._request(
                "POST", f"/api/v1/verifications/{verification_id}/complete"
            )
        )
        return Verification.from_dict(data)

    def review_verification(
        self,
        verification_id: str,
        reviewer_id: str,
        decision: str,
        *,
        notes: str | None = None,
        override_reason: str | None = None,
    ) -> Verification:
        """Submit a manual review decision for a verification.

        Args:
            verification_id: The verification UUID.
            reviewer_id:     Identifier for the human reviewer.
            decision:        Review decision (``"approve"`` or ``"reject"``).
            notes:           Optional review notes.
            override_reason: Optional reason when overriding the automated decision.

        Returns:
            The updated :class:`Verification`.
        """
        body: dict[str, Any] = {"decision": decision}
        if notes is not None:
            body["notes"] = notes
        if override_reason is not None:
            body["overrideReason"] = override_reason

        data = json.loads(
            self._request(
                "POST",
                f"/api/v1/verifications/{verification_id}/review",
                body,
                extra_headers={"X-Reviewer-ID": reviewer_id},
            )
        )
        return Verification.from_dict(data)

    def list_fraud_alerts(
        self,
        status: str | None = None,
    ) -> list[FraudAlert]:
        """List fraud alerts, optionally filtered by status.

        Args:
            status: Optional status filter (e.g. ``"open"``).

        Returns:
            A list of :class:`FraudAlert` objects.
        """
        path = "/api/v1/alerts"
        if status:
            path = f"{path}?status={status}"
        data = json.loads(self._request("GET", path))
        return [FraudAlert.from_dict(a) for a in data.get("alerts", [])]

    def resolve_fraud_alert(
        self,
        alert_id: str,
        reviewer_id: str,
        status: str,
        *,
        notes: str | None = None,
    ) -> None:
        """Resolve a fraud alert.

        Args:
            alert_id:    The alert UUID.
            reviewer_id: Identifier for the reviewer resolving the alert.
            status:      Resolution status (e.g. ``"dismissed"``, ``"confirmed"``).
            notes:       Optional resolution notes.
        """
        body: dict[str, Any] = {"status": status}
        if notes is not None:
            body["notes"] = notes

        self._request(
            "POST",
            f"/api/v1/alerts/{alert_id}/resolve",
            body,
            extra_headers={"X-Reviewer-ID": reviewer_id},
        )
