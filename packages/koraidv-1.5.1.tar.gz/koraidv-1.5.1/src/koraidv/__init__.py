"""Kora IDV Python SDK -- zero-dependency client for identity verification.

Usage::

    from koraidv import KoraIDVClient

    client = KoraIDVClient(api_key="test_abc123", tenant_id="tenant-1")
    verification = client.create_verification("user-42", tier="standard")
"""

__version__ = "1.5.1"

from .client import KoraIDVClient
from .errors import (
    KoraIDVError,
    NotFoundError,
    RateLimitedError,
    UnauthorizedError,
)
from .types import (
    AntiSpoofScores,
    CountryInfo,
    DocAuthScores,
    DocumentTypeInfo,
    DocumentTypesResult,
    DocumentUploadResponse,
    FraudAlert,
    LivenessChallenge,
    LivenessChallengeResponse,
    LivenessSession,
    OCRResult,
    SelfieUploadResponse,
    Verification,
    VerificationScores,
    WebhookPayload,
)
from .webhook import parse_webhook_payload, verify_webhook_signature

__all__ = [
    # Client
    "KoraIDVClient",
    # Errors
    "KoraIDVError",
    "NotFoundError",
    "RateLimitedError",
    "UnauthorizedError",
    # Types
    "AntiSpoofScores",
    "CountryInfo",
    "DocAuthScores",
    "DocumentTypeInfo",
    "DocumentTypesResult",
    "DocumentUploadResponse",
    "FraudAlert",
    "LivenessChallenge",
    "LivenessChallengeResponse",
    "LivenessSession",
    "OCRResult",
    "SelfieUploadResponse",
    "Verification",
    "VerificationScores",
    "WebhookPayload",
    # Webhook helpers
    "parse_webhook_payload",
    "verify_webhook_signature",
]
