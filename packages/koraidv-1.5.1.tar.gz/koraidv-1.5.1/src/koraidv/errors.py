"""Error types for the Kora IDV Python SDK."""

from __future__ import annotations

from typing import Any, Optional


class KoraIDVError(Exception):
    """Base error for all Kora IDV API errors.

    Attributes:
        status_code: HTTP status code returned by the API.
        code:        Machine-readable error code (e.g. ``"INVALID_REQUEST"``).
        message:     Human-readable error description.
        details:     Optional additional details from the API response.
    """

    def __init__(
        self,
        message: str,
        *,
        status_code: int = 0,
        code: str = "",
        details: Any = None,
    ) -> None:
        self.status_code = status_code
        self.code = code
        self.message = message
        self.details = details
        super().__init__(self._format())

    def _format(self) -> str:
        if self.code:
            return f"koraidv: API error {self.status_code} ({self.code}): {self.message}"
        return f"koraidv: API error {self.status_code}: {self.message}"

    @classmethod
    def from_dict(cls, status_code: int, data: dict[str, Any]) -> KoraIDVError:
        """Build the most specific error subclass for *status_code*."""
        message = data.get("error", data.get("message", ""))
        code = data.get("code", "")
        details = data.get("details")

        error_cls: type[KoraIDVError]
        if status_code in (401, 403):
            error_cls = UnauthorizedError
        elif status_code == 404:
            error_cls = NotFoundError
        elif status_code == 429:
            error_cls = RateLimitedError
        else:
            error_cls = cls

        return error_cls(
            message,
            status_code=status_code,
            code=code,
            details=details,
        )


class NotFoundError(KoraIDVError):
    """Raised when the requested resource does not exist (HTTP 404)."""


class UnauthorizedError(KoraIDVError):
    """Raised when the API key is missing or invalid (HTTP 401/403)."""


class RateLimitedError(KoraIDVError):
    """Raised when the request is rate-limited (HTTP 429)."""
