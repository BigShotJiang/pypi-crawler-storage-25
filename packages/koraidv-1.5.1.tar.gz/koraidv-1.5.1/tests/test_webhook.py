"""Tests for webhook signature verification and payload parsing."""

from __future__ import annotations

import hashlib
import hmac
import json

from koraidv import WebhookPayload, parse_webhook_payload, verify_webhook_signature


# ---------------------------------------------------------------------------
# verify_webhook_signature
# ---------------------------------------------------------------------------


class TestVerifyWebhookSignature:
    def _sign(self, payload: bytes, secret: str) -> str:
        return hmac.new(
            secret.encode("utf-8"),
            payload,
            hashlib.sha256,
        ).hexdigest()

    def test_valid_signature(self) -> None:
        secret = "my-webhook-secret"
        payload = b'{"eventType":"verification.verified","resourceId":"ver-123"}'
        signature = self._sign(payload, secret)

        assert verify_webhook_signature(payload, signature, secret) is True

    def test_invalid_signature(self) -> None:
        secret = "my-webhook-secret"
        payload = b'{"eventType":"verification.verified"}'

        assert verify_webhook_signature(payload, "bad-signature", secret) is False

    def test_wrong_secret(self) -> None:
        payload = b'{"eventType":"verification.verified"}'
        sig = self._sign(payload, "correct-secret")

        assert verify_webhook_signature(payload, sig, "wrong-secret") is False

    def test_tampered_payload(self) -> None:
        secret = "my-webhook-secret"
        original = b'{"amount":100}'
        sig = self._sign(original, secret)
        tampered = b'{"amount":999}'

        assert verify_webhook_signature(tampered, sig, secret) is False

    def test_empty_payload(self) -> None:
        secret = "my-secret"
        payload = b""
        sig = self._sign(payload, secret)

        assert verify_webhook_signature(payload, sig, secret) is True

    def test_constant_time_comparison(self) -> None:
        """Verify that hmac.compare_digest is used (no short-circuit)."""
        # We can't directly test timing, but we verify the function
        # returns False for a signature that differs only in the last char.
        secret = "test-secret"
        payload = b'{"test":"data"}'
        correct = self._sign(payload, secret)
        almost = correct[:-1] + ("0" if correct[-1] != "0" else "1")

        assert verify_webhook_signature(payload, almost, secret) is False


# ---------------------------------------------------------------------------
# parse_webhook_payload
# ---------------------------------------------------------------------------


class TestParseWebhookPayload:
    def test_from_bytes(self) -> None:
        raw = json.dumps(
            {
                "id": "evt-001",
                "eventType": "verification.verified",
                "resourceType": "verification",
                "resourceId": "ver-123",
                "tenantId": "tenant-1",
                "timestamp": "2025-01-15T10:05:00Z",
                "data": {
                    "verificationId": "ver-123",
                    "status": "verified",
                    "decision": "approve",
                },
            }
        ).encode("utf-8")

        payload = parse_webhook_payload(raw)

        assert isinstance(payload, WebhookPayload)
        assert payload.id == "evt-001"
        assert payload.event_type == "verification.verified"
        assert payload.resource_type == "verification"
        assert payload.resource_id == "ver-123"
        assert payload.tenant_id == "tenant-1"
        assert payload.data["decision"] == "approve"

    def test_from_string(self) -> None:
        raw = json.dumps(
            {
                "id": "evt-002",
                "eventType": "fraud_alert.created",
                "resourceType": "fraud_alert",
                "resourceId": "alert-456",
                "tenantId": "tenant-2",
                "timestamp": "2025-01-15T11:00:00Z",
                "data": {
                    "alertType": "document_tampering",
                    "severity": "high",
                },
            }
        )

        payload = parse_webhook_payload(raw)
        assert payload.event_type == "fraud_alert.created"
        assert payload.data["alertType"] == "document_tampering"

    def test_invalid_json_raises(self) -> None:
        import pytest

        with pytest.raises(ValueError, match="Invalid webhook payload JSON"):
            parse_webhook_payload("not valid json{{{")

    def test_round_trip_with_signature(self) -> None:
        """End-to-end: sign, verify, parse."""
        secret = "production-secret-key"
        payload_dict = {
            "id": "evt-rt-1",
            "eventType": "verification.completed",
            "resourceType": "verification",
            "resourceId": "ver-rt-1",
            "tenantId": "tenant-rt",
            "timestamp": "2025-06-01T12:00:00Z",
            "data": {"status": "verified"},
        }
        raw = json.dumps(payload_dict).encode("utf-8")
        sig = hmac.new(secret.encode("utf-8"), raw, hashlib.sha256).hexdigest()

        # Verify signature first
        assert verify_webhook_signature(raw, sig, secret) is True

        # Then parse
        parsed = parse_webhook_payload(raw)
        assert parsed.id == "evt-rt-1"
        assert parsed.event_type == "verification.completed"
        assert parsed.data["status"] == "verified"
