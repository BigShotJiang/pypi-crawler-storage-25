"""Tests for the Kora IDV Python SDK client.

Each test spins up a real ``http.server.HTTPServer`` on a random port in a
background thread so we exercise the full ``urllib.request`` path without
any monkey-patching.
"""

from __future__ import annotations

import json
import threading
from http.server import BaseHTTPRequestHandler, HTTPServer
from typing import Any

import pytest

from koraidv import (
    KoraIDVClient,
    KoraIDVError,
    NotFoundError,
    UnauthorizedError,
    Verification,
)


# ---------------------------------------------------------------------------
# Test-server helpers
# ---------------------------------------------------------------------------


class _Handler(BaseHTTPRequestHandler):
    """A configurable request handler that records the last request and
    responds with a pre-set JSON body/status.
    """

    # Class-level state shared via factory
    response_code: int = 200
    response_body: dict[str, Any] | str = "{}"
    last_method: str = ""
    last_path: str = ""
    last_headers: dict[str, str] = {}
    last_body: bytes = b""

    def _handle(self) -> None:
        _Handler.last_method = self.command
        _Handler.last_path = self.path
        _Handler.last_headers = {k: v for k, v in self.headers.items()}

        content_length = int(self.headers.get("Content-Length", 0))
        _Handler.last_body = self.rfile.read(content_length) if content_length else b""

        self.send_response(_Handler.response_code)
        self.send_header("Content-Type", "application/json")
        self.end_headers()

        body = _Handler.response_body
        if isinstance(body, dict):
            body = json.dumps(body)
        self.wfile.write(body.encode("utf-8") if isinstance(body, str) else body)

    # Map all HTTP verbs to the same handler
    do_GET = _handle
    do_POST = _handle
    do_PUT = _handle
    do_DELETE = _handle
    do_PATCH = _handle

    def log_message(self, format: str, *args: Any) -> None:  # noqa: A002
        # Silence server logs during tests
        pass


def _set_response(code: int = 200, body: dict[str, Any] | str = "{}") -> None:
    _Handler.response_code = code
    _Handler.response_body = body


@pytest.fixture()
def server():
    """Start an HTTP server on a random port and return (base_url, server)."""
    srv = HTTPServer(("127.0.0.1", 0), _Handler)
    port = srv.server_address[1]
    thread = threading.Thread(target=srv.serve_forever, daemon=True)
    thread.start()
    yield f"http://127.0.0.1:{port}"
    srv.shutdown()


def _client(base_url: str, api_key: str = "test_key") -> KoraIDVClient:
    return KoraIDVClient(
        api_key=api_key,
        tenant_id="test-tenant",
        base_url=base_url,
        timeout=5,
    )


# ---------------------------------------------------------------------------
# Constructor / sandbox detection
# ---------------------------------------------------------------------------


class TestClientConstructor:
    def test_sandbox_auto_detection(self) -> None:
        client = KoraIDVClient(api_key="test_abc", tenant_id="t")
        assert client.base_url == "https://sandbox.koraidv.com"

    def test_production_auto_detection(self) -> None:
        client = KoraIDVClient(api_key="live_abc", tenant_id="t")
        assert client.base_url == "https://api.koraidv.com"

    def test_base_url_override(self) -> None:
        client = KoraIDVClient(
            api_key="test_abc",
            tenant_id="t",
            base_url="https://custom.example.com",
        )
        assert client.base_url == "https://custom.example.com"

    def test_strips_trailing_api_v1(self) -> None:
        client = KoraIDVClient(
            api_key="test_abc",
            tenant_id="t",
            base_url="https://api.koraidv.com/api/v1",
        )
        assert client.base_url == "https://api.koraidv.com"

    def test_strips_trailing_slash(self) -> None:
        client = KoraIDVClient(
            api_key="test_abc",
            tenant_id="t",
            base_url="https://api.koraidv.com/",
        )
        assert client.base_url == "https://api.koraidv.com"


# ---------------------------------------------------------------------------
# Health
# ---------------------------------------------------------------------------


class TestHealth:
    def test_health_ok(self, server: str) -> None:
        _set_response(200, {"status": "healthy"})
        client = _client(server)
        client.health()  # should not raise
        assert _Handler.last_path == "/health"
        assert _Handler.last_method == "GET"

    def test_health_error(self, server: str) -> None:
        _set_response(503, {"error": "service unavailable"})
        client = _client(server)
        with pytest.raises(KoraIDVError):
            client.health()


# ---------------------------------------------------------------------------
# Create verification
# ---------------------------------------------------------------------------


class TestCreateVerification:
    def test_basic(self, server: str) -> None:
        _set_response(
            200,
            {
                "id": "ver-abc-123",
                "tenantId": "test-tenant",
                "externalId": "user-123",
                "status": "pending",
                "tier": "standard",
                "createdAt": "2025-01-15T10:00:00Z",
                "updatedAt": "2025-01-15T10:00:00Z",
            },
        )
        client = _client(server)
        v = client.create_verification(
            "user-123",
            tier="standard",
            metadata={"source": "mobile_app"},
        )

        assert isinstance(v, Verification)
        assert v.id == "ver-abc-123"
        assert v.status == "pending"
        assert v.external_id == "user-123"

        # Verify the request itself
        assert _Handler.last_method == "POST"
        assert _Handler.last_path == "/api/v1/verifications"
        assert _Handler.last_headers.get("x-tenant-id") == "test-tenant"
        assert _Handler.last_headers.get("authorization") == "Bearer test_key"

        sent = json.loads(_Handler.last_body)
        assert sent["externalId"] == "user-123"
        assert sent["tier"] == "standard"
        assert sent["metadata"] == {"source": "mobile_app"}


# ---------------------------------------------------------------------------
# Get verification
# ---------------------------------------------------------------------------


class TestGetVerification:
    def test_basic(self, server: str) -> None:
        _set_response(
            200,
            {
                "id": "ver-get-456",
                "tenantId": "test-tenant",
                "externalId": "user-123",
                "status": "verified",
                "decision": "approve",
                "tier": "standard",
                "scores": {
                    "documentQuality": 0.92,
                    "documentAuth": 0.95,
                    "faceMatch": 0.97,
                    "liveness": 0.98,
                    "dataConsistency": 0.94,
                    "overall": 0.95,
                },
                "verifiedAt": "2025-01-15T10:05:00Z",
                "createdAt": "2025-01-15T10:00:00Z",
                "updatedAt": "2025-01-15T10:05:00Z",
            },
        )
        client = _client(server)
        v = client.get_verification("ver-get-456")

        assert v.status == "verified"
        assert v.decision == "approve"
        assert v.scores is not None
        assert v.scores.overall == 0.95
        assert v.scores.face_match == 0.97
        assert _Handler.last_path == "/api/v1/verifications/ver-get-456"


# ---------------------------------------------------------------------------
# Complete verification
# ---------------------------------------------------------------------------


class TestCompleteVerification:
    def test_basic(self, server: str) -> None:
        _set_response(
            200,
            {
                "id": "ver-complete-401",
                "status": "verified",
                "decision": "approve",
                "tier": "standard",
                "scores": {"overall": 0.95},
                "verifiedAt": "2025-01-15T10:05:00Z",
            },
        )
        client = _client(server)
        v = client.complete_verification("ver-complete-401")

        assert v.status == "verified"
        assert v.decision == "approve"
        assert _Handler.last_method == "POST"
        assert _Handler.last_path == "/api/v1/verifications/ver-complete-401/complete"


# ---------------------------------------------------------------------------
# List verifications
# ---------------------------------------------------------------------------


class TestListVerifications:
    def test_basic(self, server: str) -> None:
        _set_response(
            200,
            {
                "verifications": [
                    {"id": "v1", "status": "verified", "tier": "standard"},
                    {"id": "v2", "status": "rejected", "tier": "basic"},
                ],
                "total": 2,
            },
        )
        client = _client(server)
        verifications = client.list_verifications("user-123")
        assert len(verifications) == 2
        assert verifications[0].id == "v1"
        assert verifications[1].status == "rejected"
        assert "/api/v1/subjects/user-123/verifications" in _Handler.last_path


# ---------------------------------------------------------------------------
# Upload document
# ---------------------------------------------------------------------------


class TestUploadDocument:
    def test_basic(self, server: str) -> None:
        _set_response(
            200,
            {
                "documentId": "doc-001",
                "documentType": "passport",
                "qualityScore": 0.92,
                "ocrResult": {
                    "fullText": "P<USASMITH<<JOHN...",
                    "language": "en",
                    "confidence": 0.95,
                    "mrzDetected": True,
                    "faceCount": 1,
                },
                "extractedData": {
                    "firstName": "JOHN",
                    "lastName": "SMITH",
                },
            },
        )
        client = _client(server)
        resp = client.upload_document("ver-1", "passport", "base64data...")
        assert resp.document_type == "passport"
        assert resp.quality_score == 0.92
        assert resp.ocr_result is not None
        assert resp.ocr_result.mrz_detected is True
        assert resp.ocr_result.face_count == 1


# ---------------------------------------------------------------------------
# Upload document back
# ---------------------------------------------------------------------------


class TestUploadDocumentBack:
    def test_basic(self, server: str) -> None:
        _set_response(
            200,
            {
                "documentId": "doc-002",
                "documentType": "drivers_license_back",
                "qualityScore": 0.88,
            },
        )
        client = _client(server)
        resp = client.upload_document_back("ver-back-1", "base64data...")
        assert resp.quality_score == 0.88
        assert _Handler.last_path == "/api/v1/verifications/ver-back-1/document/back"


# ---------------------------------------------------------------------------
# Upload selfie
# ---------------------------------------------------------------------------


class TestUploadSelfie:
    def test_basic(self, server: str) -> None:
        _set_response(
            200,
            {
                "faceDetected": True,
                "faceCount": 1,
                "qualityScore": 0.94,
                "warnings": [],
            },
        )
        client = _client(server)
        resp = client.upload_selfie("ver-selfie-1", "base64selfie...")
        assert resp.face_detected is True
        assert resp.face_count == 1

    def test_with_warnings(self, server: str) -> None:
        _set_response(
            200,
            {
                "faceDetected": True,
                "faceCount": 1,
                "qualityScore": 0.65,
                "warnings": ["low_contrast", "slight_blur"],
            },
        )
        client = _client(server)
        resp = client.upload_selfie("ver-selfie-2", "...")
        assert len(resp.warnings) == 2
        assert "low_contrast" in resp.warnings


# ---------------------------------------------------------------------------
# Liveness
# ---------------------------------------------------------------------------


class TestLiveness:
    def test_create_session(self, server: str) -> None:
        _set_response(
            200,
            {
                "id": "ls-001",
                "verificationId": "ver-live-1",
                "challenges": [
                    {"type": "blink", "completed": False, "score": 0},
                    {"type": "turn_left", "completed": False, "score": 0},
                    {"type": "turn_right", "completed": False, "score": 0},
                ],
                "overallScore": 0,
                "passed": False,
                "createdAt": "2025-01-15T10:00:00Z",
            },
        )
        client = _client(server)
        session = client.create_liveness_session("ver-live-1")
        assert len(session.challenges) == 3
        assert session.passed is False
        assert session.challenges[0].type == "blink"

    def test_submit_challenge(self, server: str) -> None:
        _set_response(
            200,
            {
                "challengeType": "blink",
                "completed": True,
                "score": 0.95,
                "allCompleted": False,
            },
        )
        client = _client(server)
        resp = client.submit_liveness_challenge("ver-live-1", "blink", "base64frame...")
        assert resp.completed is True
        assert resp.score == 0.95
        assert resp.all_completed is False

    def test_get_result(self, server: str) -> None:
        _set_response(
            200,
            {
                "id": "ls-002",
                "verificationId": "ver-live-1",
                "challenges": [
                    {"type": "blink", "completed": True, "score": 0.95},
                    {"type": "turn_left", "completed": True, "score": 0.92},
                ],
                "overallScore": 0.94,
                "passed": True,
                "antiSpoofResult": {
                    "textureScore": 0.91,
                    "frequencyScore": 0.88,
                    "challengeScore": 0.95,
                    "temporalScore": 0.90,
                    "qualityScore": 0.87,
                    "spoofDetected": False,
                },
                "createdAt": "2025-01-15T10:00:00Z",
            },
        )
        client = _client(server)
        session = client.get_liveness_result("ver-live-1")
        assert session.passed is True
        assert session.anti_spoof_result is not None
        assert session.anti_spoof_result.spoof_detected is False
        assert session.anti_spoof_result.texture_score == 0.91


# ---------------------------------------------------------------------------
# Review verification
# ---------------------------------------------------------------------------


class TestReviewVerification:
    def test_basic(self, server: str) -> None:
        _set_response(
            200,
            {
                "id": "ver-review-501",
                "status": "verified",
                "decision": "approve",
                "reviewedBy": "reviewer-001",
                "reviewNotes": "Manual verification completed",
            },
        )
        client = _client(server)
        v = client.review_verification(
            "ver-review-501",
            reviewer_id="reviewer-001",
            decision="approve",
            notes="Manual verification completed",
        )
        assert v.decision == "approve"
        assert v.reviewed_by == "reviewer-001"
        assert _Handler.last_headers.get("x-reviewer-id") == "reviewer-001"


# ---------------------------------------------------------------------------
# Fraud alerts
# ---------------------------------------------------------------------------


class TestFraudAlerts:
    def test_list(self, server: str) -> None:
        _set_response(
            200,
            {
                "alerts": [
                    {
                        "id": "a1",
                        "verificationId": "v1",
                        "alertType": "document_tampering",
                        "severity": "high",
                        "status": "open",
                    },
                    {
                        "id": "a2",
                        "verificationId": "v2",
                        "alertType": "face_mismatch",
                        "severity": "medium",
                        "status": "open",
                    },
                ],
                "total": 2,
            },
        )
        client = _client(server)
        alerts = client.list_fraud_alerts(status="open")
        assert len(alerts) == 2
        assert alerts[0].alert_type == "document_tampering"
        assert "status=open" in _Handler.last_path

    def test_resolve(self, server: str) -> None:
        _set_response(200, {})
        client = _client(server)
        client.resolve_fraud_alert(
            "alert-123",
            reviewer_id="reviewer-002",
            status="dismissed",
            notes="False positive",
        )
        assert _Handler.last_path == "/api/v1/alerts/alert-123/resolve"
        assert _Handler.last_headers.get("x-reviewer-id") == "reviewer-002"
        sent = json.loads(_Handler.last_body)
        assert sent["status"] == "dismissed"
        assert sent["notes"] == "False positive"


# ---------------------------------------------------------------------------
# Document types
# ---------------------------------------------------------------------------


class TestGetDocumentTypes:
    def test_no_filter(self, server: str) -> None:
        _set_response(
            200,
            {
                "success": True,
                "documentTypes": [
                    {
                        "type": "passport",
                        "name": "Passport",
                        "country": "all",
                        "hasMrz": True,
                        "requiresBack": False,
                        "supportedOcr": True,
                    },
                ],
                "countries": [{"code": "NG", "name": "Nigeria"}],
                "total": 1,
            },
        )
        client = _client(server)
        result = client.get_document_types()
        assert len(result.document_types) == 1
        assert result.document_types[0].has_mrz is True
        assert result.countries[0].code == "NG"
        assert _Handler.last_path == "/api/v1/document-types"

    def test_with_country(self, server: str) -> None:
        _set_response(200, {"documentTypes": [], "countries": [], "total": 0})
        client = _client(server)
        client.get_document_types(country="NG")
        assert "country=NG" in _Handler.last_path


# ---------------------------------------------------------------------------
# Error handling
# ---------------------------------------------------------------------------


class TestErrorHandling:
    def test_400_bad_request(self, server: str) -> None:
        _set_response(
            400,
            {
                "error": "Invalid request",
                "code": "INVALID_REQUEST",
                "details": {"field": "externalId"},
            },
        )
        client = _client(server)
        with pytest.raises(KoraIDVError) as exc_info:
            client.create_verification("bad")
        err = exc_info.value
        assert err.status_code == 400
        assert err.code == "INVALID_REQUEST"
        assert err.message == "Invalid request"

    def test_401_unauthorized(self, server: str) -> None:
        _set_response(401, {"error": "invalid API key"})
        client = _client(server)
        with pytest.raises(UnauthorizedError) as exc_info:
            client.get_verification("v1")
        assert exc_info.value.status_code == 401

    def test_404_not_found(self, server: str) -> None:
        _set_response(404, {"error": "verification not found"})
        client = _client(server)
        with pytest.raises(NotFoundError) as exc_info:
            client.get_verification("nonexistent")
        assert exc_info.value.status_code == 404

    def test_error_hierarchy(self) -> None:
        """Subclass errors are also catchable as KoraIDVError."""
        err = NotFoundError("not found", status_code=404)
        assert isinstance(err, KoraIDVError)
        assert isinstance(err, NotFoundError)
