from __future__ import annotations

from collections import namedtuple as _namedtuple
from typing import TYPE_CHECKING, Any

import pytest

if TYPE_CHECKING:
    from collections.abc import Callable, Collection

    Marks = pytest.MarkDecorator | Collection[pytest.MarkDecorator | pytest.Mark]

__all__ = ["Parametrization", "p"]


class Parametrization:
    def __init__(self, test_function: Callable[..., Any]) -> None:
        self.test_function = test_function
        self._name_factory: Callable[..., str] | None = None
        self.cases: list[tuple[str | None, tuple[Any, ...], dict[str, Any], Marks | None]] = []
        self.defaults: dict[str, Any] = {}

    def get_decorated(self, parameters: list[str] | None = None) -> Any:  # noqa: ANN401
        if parameters is None:
            all_keys: set[str] = set()
            for _name, args, kwargs, _marks in self.cases:
                if args:
                    raise Exception("args are forbidden with auto-detection, please use kwargs")
                all_keys.update(kwargs.keys())
            all_keys.update(self.defaults.keys())
            parameters = list(all_keys)

        arguments_names = list(parameters)
        arguments_values = []
        case_cls = _namedtuple("Case", arguments_names)

        for name, args, kwargs, marks in reversed(self.cases):
            for argument_name in arguments_names[len(args) :]:
                if argument_name not in kwargs and argument_name in self.defaults:
                    kwargs[argument_name] = self.defaults[argument_name]

            if name is None:
                assert self._name_factory, "Name factory must be given with @Parametrization.name_factory"
                name = self._name_factory(**kwargs)

            values = tuple(case_cls(*args, **kwargs))
            if marks is not None:
                arguments_values.append(pytest.param(*values, id=name, marks=marks))
            else:
                arguments_values.append(pytest.param(*values, id=name))

        return pytest.mark.parametrize(argnames=arguments_names, argvalues=arguments_values)(self.test_function)

    def add_case(self, name: str | None, *args: Any, marks: Marks | None = None, **kwargs: Any) -> None:  # noqa: ANN401
        self.cases.append((name, args, kwargs, marks))

    def add_legacy_cases(self, base_name: str, fields: list[str], values: list[tuple[Any, ...]]) -> None:
        fields_with_values = [dict(zip(fields, value)) for value in values]
        for case in fields_with_values:
            name = "{} -> {}".format(
                base_name, ", ".join(["=".join([str(v) for v in case_values]) for case_values in case])
            )
            self.add_case(name, **case)

    @classmethod
    def parameters(cls, *parameters: str) -> Callable[[Any], Any]:
        def decorator(f: Any) -> Any:  # noqa: ANN401
            if not isinstance(f, Parametrization):
                return Parametrization(f).get_decorated(list(parameters))
            return f.get_decorated(list(parameters))

        return decorator

    @classmethod
    def autodetect_parameters(cls) -> Callable[[Any], Any]:
        def decorator(f: Any) -> Any:  # noqa: ANN401
            if not isinstance(f, Parametrization):
                return Parametrization(f).get_decorated()
            return f.get_decorated()

        return decorator

    @classmethod
    def name_factory(cls, create_name: Callable[..., str]) -> Callable[[Any], Parametrization]:
        def decorator(f: Any) -> Parametrization:  # noqa: ANN401
            if not isinstance(f, Parametrization):
                parametrization = Parametrization(f)
            else:
                parametrization = f
            parametrization._name_factory = create_name
            return parametrization

        return decorator

    @classmethod
    def case(
        cls,
        name: str | None = None,
        *args: Any,  # noqa: ANN401
        marks: Marks | None = None,
        **kwargs: Any,  # noqa: ANN401
    ) -> Callable[[Any], Parametrization]:
        def decorator(f: Any) -> Parametrization:  # noqa: ANN401
            if not isinstance(f, Parametrization):
                parametrization = Parametrization(f)
            else:
                parametrization = f
            parametrization.add_case(name, *args, marks=marks, **kwargs)
            return parametrization

        return decorator

    @classmethod
    def default_parameters(cls, **kwargs: Any) -> Callable[[Any], Parametrization]:  # noqa: ANN401
        def decorator(f: Any) -> Parametrization:  # noqa: ANN401
            if not isinstance(f, Parametrization):
                parametrization = Parametrization(f)
            else:
                parametrization = f
            for key, value in kwargs.items():
                parametrization.defaults[key] = value
            return parametrization

        return decorator

    @classmethod
    def legacy_cases(
        cls, base_name: str, fields: list[str], values: list[tuple[Any, ...]]
    ) -> Callable[[Any], Parametrization]:
        def decorator(f: Any) -> Parametrization:  # noqa: ANN401
            if not isinstance(f, Parametrization):
                parametrization = Parametrization(f)
            else:
                parametrization = f
            parametrization.add_legacy_cases(base_name, fields, values)
            return parametrization

        return decorator


p = Parametrization
