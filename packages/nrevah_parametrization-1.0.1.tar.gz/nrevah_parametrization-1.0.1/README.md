# nrevah-parametrization
Simpler PyTest parametrization

## How to install
```bash
pip install nrevah-parametrization
```


## How to use

`Parametrization` (or the short alias `p`) provides a decorator-based API for parametrizing pytest tests.

### Explicit parameters
```python
from parametrization import p

@p.parameters("actual", "expected")
@p.case(name="some_case_0", actual=1, expected=2)
@p.case("some_case_1", actual=1, expected=2)
@p.case("some_case_2", 1, expected=1)
@p.case("some_case_3", 2, 2)
@p.case("some_case_4", 3, 3)
def test_somthing(actual, expected):
    assert actual == expected
```
### Auto-detect parameters
```python
from parametrization import p

@p.autodetect_parameters()
@p.case(name="some_case_0", actual=1, expected=2)
@p.case("some_case_1", actual=1, expected=2)
@p.case("some_case_2", actual=1, expected=1)
def test_somthing(actual, expected):
    assert actual == expected
```
### Auto-detect parameters with default parameter
```python
from parametrization import p

@p.autodetect_parameters()
@p.default_parameters(expected=None)
@p.case(name="some_case_0", actual=1, expected=2)
@p.case("some_case_1", actual=1, expected=2)
@p.case("some_case_2", actual=1, expected=1)
@p.case("some_case_2", actual=1)
def test_somthing(actual, expected):
    assert actual == expected
```
### Generate name based on arguments
```python
from parametrization import p

@p.name_factory(lambda actual, expected: f"{actual}=={expected}")
@p.case(actual=1, expected=1)
@p.case(actual=2, expected=2)
@p.case("special-name", actual=3, expected=3)
def test_somthing(actual, expected):
    assert actual == expected
```

As can be seen from the example, you can also give explicit name for a case
even if you are using name factory.

The long form `Parametrization` is also available for those who prefer it:
```python
from parametrization import Parametrization

@Parametrization.autodetect_parameters()
@Parametrization.case(name="some_case_0", actual=1, expected=2)
def test_somthing(actual, expected):
    assert actual == expected
```