"""
Formatter unit tests: classifier + non-streaming format_content.

Mirrors Go formatter/formatter_test.go.
"""

import pytest

from markdown_flow.formatter.classifier import Classifier
from markdown_flow.formatter.format import format_content
from markdown_flow.formatter.types import ElementType


# =====================================================================
# Classifier unit tests
# =====================================================================


class TestClassifierBasic:
    def test_plain_text(self):
        c = Classifier()
        cr = c.classify_line("Hello world")
        assert cr.type == ElementType.TEXT

    def test_empty_line(self):
        c = Classifier()
        cr = c.classify_line("")
        assert cr.type == ElementType.TEXT

    def test_heading(self):
        c = Classifier()
        for h in ["# Title", "## Subtitle", "### H3", "###### H6"]:
            cr = c.classify_line(h)
            assert cr.type == ElementType.TITLE, f"Expected TITLE for {h!r}"

    def test_code_block(self):
        c = Classifier()

        cr = c.classify_line("```go")
        assert cr.type == ElementType.CODE

        cr = c.classify_line("fmt.Println()")
        assert cr.type == ElementType.CODE

        cr = c.classify_line("```")
        assert cr.type == ElementType.CODE

        cr = c.classify_line("Normal text")
        assert cr.type == ElementType.TEXT

    def test_mermaid_block(self):
        c = Classifier()

        cr = c.classify_line("```mermaid")
        assert cr.type == ElementType.MERMAID

        cr = c.classify_line("graph TD")
        assert cr.type == ElementType.MERMAID

        cr = c.classify_line("```")
        assert cr.type == ElementType.MERMAID

    def test_diff_block(self):
        c = Classifier()

        cr = c.classify_line("!+++")
        assert cr.type == ElementType.DIFF

        cr = c.classify_line("+ added line")
        assert cr.type == ElementType.DIFF

        cr = c.classify_line("!+++")
        assert cr.type == ElementType.DIFF

        cr = c.classify_line("Normal text")
        assert cr.type == ElementType.TEXT

    def test_latex_display_math(self):
        c = Classifier()

        cr = c.classify_line("$$")
        assert cr.type == ElementType.LATEX

        cr = c.classify_line("E = mc^2")
        assert cr.type == ElementType.LATEX

        cr = c.classify_line("$$")
        assert cr.type == ElementType.LATEX

        cr = c.classify_line("Normal text")
        assert cr.type == ElementType.TEXT

    def test_inline_latex(self):
        c = Classifier()
        cr = c.classify_line("$x^2 + y^2 = z^2$")
        assert cr.type == ElementType.LATEX

    def test_svg(self):
        c = Classifier()

        cr = c.classify_line("<svg width='100'>")
        assert cr.type == ElementType.SVG

        cr = c.classify_line("<circle r='50'/>")
        assert cr.type == ElementType.SVG

        cr = c.classify_line("</svg>")
        assert cr.type == ElementType.SVG

        cr = c.classify_line("Normal text")
        assert cr.type == ElementType.TEXT

    def test_inline_svg(self):
        c = Classifier()
        cr = c.classify_line("<svg width='100'><circle/></svg>")
        assert cr.type == ElementType.SVG

        cr = c.classify_line("text after")
        assert cr.type == ElementType.TEXT

    def test_html_div(self):
        c = Classifier()

        cr = c.classify_line("<div class='test'>")
        assert cr.type == ElementType.HTML
        assert not cr.is_append

        cr = c.classify_line("content")
        assert cr.type == ElementType.HTML

        cr = c.classify_line("</div>")
        assert cr.type == ElementType.HTML

    def test_script_is_append(self):
        c = Classifier()

        cr = c.classify_line("<script>")
        assert cr.type == ElementType.HTML
        assert cr.is_append

        cr = c.classify_line("console.log('hi')")
        assert cr.type == ElementType.HTML

        cr = c.classify_line("</script>")
        assert cr.type == ElementType.HTML

    def test_style_is_append(self):
        c = Classifier()
        cr = c.classify_line("<style>")
        assert cr.is_append

    def test_html_img(self):
        c = Classifier()
        cr = c.classify_line('<img src="photo.jpg" />')
        assert cr.type == ElementType.IMG

    def test_markdown_image(self):
        c = Classifier()
        cr = c.classify_line("![alt text](https://example.com/img.png)")
        assert cr.type == ElementType.IMG

    def test_table(self):
        c = Classifier()

        cr = c.classify_line("| Name | Age |")
        assert cr.type == ElementType.TABLES

        cr = c.classify_line("| --- | --- |")
        assert cr.type == ElementType.TABLES

        cr = c.classify_line("| John | 30 |")
        assert cr.type == ElementType.TABLES

        cr = c.classify_line("Normal text")
        assert cr.type == ElementType.TEXT

    def test_doctype(self):
        c = Classifier()

        cr = c.classify_line("<!DOCTYPE html>")
        assert cr.type == ElementType.HTML

        cr = c.classify_line("<html>")
        assert cr.type == ElementType.HTML

        cr = c.classify_line("</html>")
        assert cr.type == ElementType.HTML

        cr = c.classify_line("Normal text")
        assert cr.type == ElementType.TEXT


# =====================================================================
# FormatContent non-streaming tests
# =====================================================================


class TestFormatContent:
    def test_empty(self):
        result = format_content("")
        assert result == []

    def test_pure_text(self):
        result = format_content("Hello world\nThis is a test")
        assert len(result) > 0
        for elem in result:
            assert elem.type == ElementType.TEXT
            assert elem.number == 0

    def test_title_and_text(self):
        result = format_content("# Title\nSome text\nMore text")
        assert len(result) == 3
        assert result[0].type == ElementType.TITLE
        assert result[1].type == ElementType.TEXT
        # title -> text family: no increment
        for elem in result:
            assert elem.number == 0

    def test_number_sequence(self):
        content = (
            "# \u6807\u9898\n"
            "\u6b63\u6587\u5185\u5bb9\n"
            "<div>html1</div>\n"
            "<script>var x=1;</script>\n"
            "<div>html2</div>\n"
            "\u666e\u901a\u6587\u5b57"
        )
        result = format_content(content)

        wants = [
            (ElementType.TITLE, 0),   # # title
            (ElementType.TEXT, 0),     # body (title->text no increment)
            (ElementType.HTML, 1),     # <div>html1</div>
            (ElementType.HTML, 1),     # <script> (IsAppend)
            (ElementType.HTML, 2),     # <div>html2</div>
            (ElementType.TEXT, 3),     # plain text (html->text increment)
        ]

        assert len(result) == len(wants), f"Expected {len(wants)} elements, got {len(result)}"
        for i, (want_type, want_num) in enumerate(wants):
            assert result[i].type == want_type, (
                f"[{i}] Expected type {want_type}, got {result[i].type} "
                f"(content: {result[i].content.strip()!r})"
            )
            assert result[i].number == want_num, (
                f"[{i}] Expected number {want_num}, got {result[i].number} "
                f"(content: {result[i].content.strip()!r})"
            )

    def test_mixed_types(self):
        content = (
            "# Title\n"
            "Some text\n"
            "```python\nprint('hello')\n```\n"
            "| A | B |\n| - | - |\n| 1 | 2 |\n"
            "$$\nE = mc^2\n$$\n"
            "Normal text"
        )
        result = format_content(content)
        assert len(result) > 0

        type_set = {elem.type for elem in result}
        for expected in [ElementType.TITLE, ElementType.TEXT, ElementType.CODE, ElementType.TABLES, ElementType.LATEX]:
            assert expected in type_set, f"Missing type {expected}"

    def test_default_fields(self):
        result = format_content("Hello")
        assert len(result) > 0
        elem = result[0]
        assert not elem.is_show
        assert not elem.is_read
        assert elem.operation == ""
        assert not elem.is_checkpoint
        assert elem.audio_url == ""
        assert elem.audio_segments == []

    def test_diff_block(self):
        content = "!+++\n+ added\n- removed\n!+++"
        result = format_content(content)
        for elem in result:
            assert elem.type == ElementType.DIFF

    def test_multi_line_html_block(self):
        content = (
            '<div class="container">\n'
            "  <h1>Title</h1>\n"
            "  <p>Content</p>\n"
            '  <div class="inner">\n'
            "    <span>Nested</span>\n"
            "  </div>\n"
            "</div>\n"
            "Normal text after"
        )
        result = format_content(content)
        assert len(result) > 0

        html_number = result[0].number
        for elem in result:
            if elem.type == ElementType.HTML:
                assert elem.number == html_number

        last_elem = result[-1]
        assert last_elem.type == ElementType.TEXT
        assert last_elem.number != html_number

    def test_two_multi_line_divs_get_different_numbers(self):
        content = (
            '<div class="first">\n'
            "  <p>First block</p>\n"
            "</div>\n"
            '<div class="second">\n'
            "  <p>Second block</p>\n"
            "</div>"
        )
        result = format_content(content)

        numbers = []
        seen = set()
        for elem in result:
            if elem.type == ElementType.HTML and elem.number not in seen:
                numbers.append(elem.number)
                seen.add(elem.number)

        assert len(numbers) >= 2, f"Expected at least 2 HTML block numbers, got {numbers}"
        assert numbers[0] != numbers[1]

    def test_consecutive_divs_get_different_numbers(self):
        content = "<div>first</div>\n<div>second</div>"
        result = format_content(content)
        assert len(result) == 2
        assert result[0].number != result[1].number

    def test_empty_lines_preserved_not_standalone(self):
        """Empty lines don't generate standalone elements but their \\n is preserved."""
        content = "\ntext line\n\n<div>html</div>\n\nmore text\n"
        result = format_content(content)

        # Still 3 elements (no standalone empty-line elements)
        assert len(result) == 3  # text, html, text

        # Leading \n is prepended to first element
        assert result[0].content.startswith("\n")
        assert "text line" in result[0].content

        # \n between text and html is appended to text element
        assert result[0].content.endswith("\n\n")

        # \n between html and more text is appended to html element
        assert result[1].content.endswith("\n\n")

    def test_multiple_consecutive_empty_lines(self):
        """Multiple consecutive empty lines are all preserved."""
        content = "first\n\n\nsecond\n"
        result = format_content(content)
        assert len(result) == 2
        # Two empty lines → two extra \n appended to first element
        assert result[0].content == "first\n\n\n"

    def test_trailing_empty_lines(self):
        """Trailing empty lines are appended to last element."""
        content = "hello\n\n\n"
        result = format_content(content)
        assert len(result) == 1
        assert result[0].content == "hello\n\n\n"

    def test_leading_empty_lines_prepend(self):
        """Leading empty lines are prepended to first element."""
        content = "\n\nhello\n"
        result = format_content(content)
        assert len(result) == 1
        # "hello" is the last line after trailing \n stripping, so no trailing \n
        assert result[0].content == "\n\nhello"
