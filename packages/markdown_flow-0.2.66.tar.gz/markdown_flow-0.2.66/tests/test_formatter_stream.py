"""
Streaming formatter tests.

Mirrors Go formatter/stream_test.go.
"""

import random

import pytest

from markdown_flow.formatter.format import format_content
from markdown_flow.formatter.stream import StreamFormatter
from markdown_flow.formatter.types import ElementType, FormattedElement


# =====================================================================
# Basic streaming tests
# =====================================================================


class TestStreamFormatterBasic:
    def test_empty_chunk(self):
        f = StreamFormatter()
        assert f.process("") == []

    def test_single_line_text(self):
        f = StreamFormatter()
        result = f.process("Hello world\n")
        assert len(result) == 1
        assert result[0].type == ElementType.TEXT
        assert result[0].content == "Hello world\n"

    def test_line_buffering(self):
        f = StreamFormatter()

        result1 = f.process("Hello wo")
        assert len(result1) == 0

        result2 = f.process("rld\n")
        assert len(result2) == 1
        assert result2[0].content == "Hello world\n"

    def test_flush(self):
        f = StreamFormatter()
        f.process("incomplete line")

        result = f.flush()
        assert len(result) == 1
        assert result[0].content == "incomplete line"
        assert result[0].type == ElementType.TEXT

    def test_flush_empty(self):
        f = StreamFormatter()
        assert f.flush() == []


# =====================================================================
# Cross-chunk boundary tests
# =====================================================================


class TestStreamFormatterCrossChunk:
    def test_svg_across_chunks(self):
        f = StreamFormatter()
        all_elements: list[FormattedElement] = []

        chunks = ["<svg wid", "th='100'>\n<circ", "le r='50'/>\n</svg>\n"]
        for chunk in chunks:
            all_elements.extend(f.process(chunk))
        all_elements.extend(f.flush())

        for elem in all_elements:
            assert elem.type == ElementType.SVG

    def test_code_block_across_chunks(self):
        f = StreamFormatter()
        all_elements: list[FormattedElement] = []

        chunks = ["```py", "thon\nprint", "('hello')\n``", "`\nAfter code\n"]
        for chunk in chunks:
            all_elements.extend(f.process(chunk))
        all_elements.extend(f.flush())

        last_elem = all_elements[-1]
        assert last_elem.type == ElementType.TEXT

        for elem in all_elements[:-1]:
            assert elem.type == ElementType.CODE


# =====================================================================
# Number sequence tests
# =====================================================================


class TestStreamFormatterNumbers:
    def test_number_sequence(self):
        f = StreamFormatter()
        content = "# \u6807\u9898\n\u6b63\u6587\u5185\u5bb9\n<div>html1</div>\n<script>var x=1;</script>\n<div>html2</div>\n\u666e\u901a\u6587\u5b57\n"

        all_elements: list[FormattedElement] = []
        all_elements.extend(f.process(content))
        all_elements.extend(f.flush())

        wants = [
            (ElementType.TITLE, 0),
            (ElementType.TEXT, 0),
            (ElementType.HTML, 1),
            (ElementType.HTML, 1),  # script IsAppend
            (ElementType.HTML, 2),
            (ElementType.TEXT, 3),
        ]

        assert len(all_elements) == len(wants)
        for i, (want_type, want_num) in enumerate(wants):
            assert all_elements[i].type == want_type, (
                f"[{i}] Expected {want_type}, got {all_elements[i].type}"
            )
            assert all_elements[i].number == want_num, (
                f"[{i}] Expected number {want_num}, got {all_elements[i].number}"
            )

    def test_next_number(self):
        f = StreamFormatter()
        f.process("Hello\n")
        assert f.next_number() == 1


# =====================================================================
# Consistency: streaming vs non-streaming
# =====================================================================


def _type_sequence(elements: list[FormattedElement]) -> str:
    return ",".join(e.type for e in elements)


def _number_sequence(elements: list[FormattedElement]) -> str:
    return ",".join("." * (e.number + 1) for e in elements)


class TestStreamFormatterConsistency:
    @pytest.mark.parametrize(
        "name,content",
        [
            ("PureText", "Hello world\nThis is a test\nThird line"),
            ("Heading", "# Title\nContent\n## Subtitle"),
            ("CodeBlock", "```go\nfmt.Println()\n```\nAfter"),
            ("MermaidBlock", "```mermaid\ngraph TD\nA-->B\n```"),
            ("DiffBlock", "!+++\n+ added\n- removed\n!+++"),
            ("LatexBlock", "$$\nE = mc^2\n$$"),
            ("InlineLatex", "$x^2$"),
            ("SVG", "<svg width='100'>\n<circle/>\n</svg>"),
            ("HTMLDiv", "<div>\ncontent\n</div>"),
            ("Table", "| A | B |\n| - | - |\n| 1 | 2 |"),
            ("Image", "![alt](url)"),
            ("HTMLImg", "<img src='photo.jpg' />"),
            (
                "Mixed",
                "# Title\nText\n```python\ncode\n```\n| A | B |\n| - | - |\n$$\nmath\n$$\nMore text",
            ),
        ],
    )
    def test_consistency(self, name: str, content: str):
        non_stream = format_content(content)

        f = StreamFormatter()
        stream_result: list[FormattedElement] = []
        stream_result.extend(f.process(content + "\n"))
        stream_result.extend(f.flush())

        assert _type_sequence(non_stream) == _type_sequence(stream_result), (
            f"Type mismatch for {name}"
        )
        assert _number_sequence(non_stream) == _number_sequence(stream_result), (
            f"Number mismatch for {name}"
        )


# =====================================================================
# Random chunk size consistency test
# =====================================================================


class TestStreamFormatterRandomChunk:
    @pytest.mark.parametrize(
        "idx,content",
        [
            (0, "# Title\nSome text\n```go\ncode\n```\nMore text\n<div>html</div>\nEnd"),
            (1, "<svg width='100'>\n<circle/>\n</svg>\n| A | B |\n| - | - |\n| 1 | 2 |"),
            (2, "!+++\n+ added\n!+++\n$$\nmath\n$$\n# End"),
        ],
    )
    def test_random_chunk_consistency(self, idx: int, content: str):
        non_stream = format_content(content)
        ref_types = _type_sequence(non_stream)
        ref_nums = _number_sequence(non_stream)

        for trial in range(10):
            f = StreamFormatter()
            stream_result: list[FormattedElement] = []

            remaining = content
            while remaining:
                size = random.randint(1, 15)
                chunk = remaining[:size]
                remaining = remaining[size:]
                stream_result.extend(f.process(chunk))
            stream_result.extend(f.flush())

            assert _type_sequence(stream_result) == ref_types, (
                f"[content {idx}, trial {trial}] Type mismatch"
            )
            assert _number_sequence(stream_result) == ref_nums, (
                f"[content {idx}, trial {trial}] Number mismatch"
            )


# =====================================================================
# Empty line filtering tests
# =====================================================================


class TestStreamFormatterEmptyLineFiltering:
    def test_empty_lines_preserved_not_standalone(self):
        """Empty lines don't generate standalone elements but \\n is preserved."""
        f = StreamFormatter()
        content = "text line\n\n<div>html</div>\n\n"
        all_elements = f.process(content) + f.flush()

        assert len(all_elements) == 2  # text + html, no standalone empty elements
        # \n between text and html appended to text element
        assert all_elements[0].content == "text line\n\n"

    def test_leading_empty_lines(self):
        """Leading empty lines are prepended to first element."""
        f = StreamFormatter()
        content = "\n\nHello\n"
        all_elements = f.process(content) + f.flush()

        assert len(all_elements) == 1
        assert all_elements[0].content == "\n\nHello\n"

    def test_empty_lines_between_html_and_text(self):
        """Empty lines between elements are preserved on previous element."""
        f = StreamFormatter()
        content = "<div>slide1</div>\n\n\nNarration text\n\n<div>slide2</div>\n"
        all_elements = f.process(content) + f.flush()

        assert len(all_elements) == 3  # html1, text, html2
        # Two empty lines appended to html1
        assert all_elements[0].content == "<div>slide1</div>\n\n\n"
        # One empty line appended to narration text
        assert all_elements[1].content == "Narration text\n\n"

    def test_cross_chunk_empty_lines(self):
        """Empty lines spanning chunk boundaries are preserved."""
        f = StreamFormatter()

        elems1 = f.process("Hello\n")
        assert len(elems1) == 1

        elems2 = f.process("\n")  # empty line in separate chunk
        assert len(elems2) == 0  # no standalone element

        elems3 = f.process("World\n")
        assert len(elems3) == 1
        # Pending \n prepended to next element (can't modify already-returned element)
        assert elems3[0].content == "\nWorld\n"

    def test_multiple_consecutive_empty_lines(self):
        """Multiple consecutive empty lines are all preserved."""
        f = StreamFormatter()
        content = "first\n\n\nsecond\n"
        all_elements = f.process(content) + f.flush()
        assert len(all_elements) == 2
        assert all_elements[0].content == "first\n\n\n"
