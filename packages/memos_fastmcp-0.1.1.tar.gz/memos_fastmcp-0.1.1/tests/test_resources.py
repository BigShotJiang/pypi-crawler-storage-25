"""Tests for MCP Resources."""

import pytest
from datetime import datetime

from memos_mcp.models import Memo, MemoState, MemoVisibility


@pytest.fixture
def sample_memo() -> Memo:
    """Create a sample memo for testing."""
    return Memo(
        name="memos/1",
        state=MemoState.NORMAL,
        creator="users/1",
        content="# Test Memo\n\nThis is test content with #test tag.",
        visibility=MemoVisibility.PRIVATE,
        pinned=False,
        tags=["test", "sample"],
        create_time=datetime(2026, 4, 11, 10, 0),
        update_time=datetime(2026, 4, 11, 10, 0),
        display_time=datetime(2026, 4, 11, 10, 0),
    )


@pytest.fixture
def sample_memos() -> list[Memo]:
    """Create a list of sample memos for testing."""
    return [
        Memo(
            name="memos/1",
            state=MemoState.NORMAL,
            creator="users/1",
            content="# First Memo\nContent here.",
            visibility=MemoVisibility.PRIVATE,
            pinned=True,
            tags=["work"],
            create_time=datetime(2026, 4, 10, 10, 0),
            update_time=datetime(2026, 4, 10, 10, 0),
            display_time=datetime(2026, 4, 10, 10, 0),
        ),
        Memo(
            name="memos/2",
            state=MemoState.NORMAL,
            creator="users/1",
            content="# Second Memo\nAnother content.",
            visibility=MemoVisibility.PUBLIC,
            pinned=False,
            tags=["personal", "work"],
            create_time=datetime(2026, 4, 11, 10, 0),
            update_time=datetime(2026, 4, 11, 10, 0),
            display_time=datetime(2026, 4, 11, 10, 0),
        ),
        Memo(
            name="memos/3",
            state=MemoState.ARCHIVED,
            creator="users/1",
            content="Archived memo",
            visibility=MemoVisibility.PRIVATE,
            pinned=False,
            tags=["archived"],
            create_time=datetime(2026, 4, 9, 10, 0),
            update_time=datetime(2026, 4, 9, 10, 0),
            display_time=datetime(2026, 4, 9, 10, 0),
        ),
    ]


class TestFormatMemoList:
    """Tests for memo list formatting."""

    def test_format_empty_list(self) -> None:
        """Test formatting empty memo list."""
        from memos_mcp.utils import format_memo_list
        result = format_memo_list([])
        assert result == "No memos found."

    def test_format_memo_list(self, sample_memos: list[Memo]) -> None:
        """Test formatting memo list."""
        from memos_mcp.utils import format_memo_list
        result = format_memo_list(sample_memos)
        assert "| ID | Title | Tags | Created | Visibility |" in result
        assert "1" in result
        assert "2" in result
        assert "work" in result


class TestFormatMemoDetail:
    """Tests for memo detail formatting."""

    def test_format_memo_detail(self, sample_memo: Memo) -> None:
        """Test formatting single memo detail."""
        from memos_mcp.utils import format_memo_detail
        result = format_memo_detail(sample_memo)
        assert "# Memo 1" in result
        assert "Test Memo" in result
        assert "PRIVATE" in result
        assert "test" in result


class TestFormatTagsStats:
    """Tests for tags stats formatting."""

    def test_format_empty_tags(self) -> None:
        """Test formatting empty tags."""
        from memos_mcp.utils import format_tags_stats
        result = format_tags_stats({})
        assert result == "No tags found."

    def test_format_tags_stats(self) -> None:
        """Test formatting tags statistics."""
        from memos_mcp.utils import format_tags_stats
        tags = {"work": 5, "personal": 3, "test": 10}
        result = format_tags_stats(tags)
        assert "| Tag | Count |" in result
        assert "test" in result
        assert "10" in result


class TestFormatStats:
    """Tests for stats formatting."""

    def test_format_stats(self) -> None:
        """Test formatting statistics."""
        from memos_mcp.utils import format_stats
        stats = {
            "total": 100,
            "by_visibility": {"PRIVATE": 60, "PUBLIC": 40},
            "by_state": {"NORMAL": 90, "ARCHIVED": 10},
            "total_tags": 25,
            "pinned": 5,
        }
        result = format_stats(stats)
        assert "# Memos Statistics" in result
        assert "Total Memos" in result
        assert "100" in result
        assert "By Visibility" in result