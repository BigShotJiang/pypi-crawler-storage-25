"""Tests for MCP Prompts."""

from memos_mcp.prompts import (
    search_by_tag,
    create_quick_note,
    find_recent_notes,
    organize_by_visibility,
)


class TestSearchByTag:
    """Tests for search_by_tag prompt."""

    def test_search_by_tag_basic(self) -> None:
        """Test basic tag search prompt."""
        result = search_by_tag("work")
        assert "work" in result
        assert "search_memos" in result
        assert "tag" in result.lower()

    def test_search_by_tag_with_special_chars(self) -> None:
        """Test tag with special characters."""
        result = search_by_tag("project-2026")
        assert "project-2026" in result


class TestCreateQuickNote:
    """Tests for create_quick_note prompt."""

    def test_create_quick_note_basic(self) -> None:
        """Test basic quick note prompt."""
        result = create_quick_note("Remember to buy groceries")
        assert "Remember to buy groceries" in result
        assert "create_memo" in result

    def test_create_quick_note_with_tag(self) -> None:
        """Test quick note with tag."""
        result = create_quick_note("Meeting notes", "work")
        assert "Meeting notes" in result
        assert "work" in result
        assert "tag" in result.lower()

    def test_create_quick_note_empty_tag(self) -> None:
        """Test quick note with empty tag."""
        result = create_quick_note("Simple note", "")
        assert "Simple note" in result
        # Should not mention tag when empty


class TestFindRecentNotes:
    """Tests for find_recent_notes prompt."""

    def test_find_recent_notes_default(self) -> None:
        """Test default recent notes prompt."""
        result = find_recent_notes()
        assert "7" in result
        assert "list_memos" in result

    def test_find_recent_notes_custom_days(self) -> None:
        """Test custom days parameter."""
        result = find_recent_notes(14)
        assert "14" in result
        assert "days" in result


class TestOrganizeByVisibility:
    """Tests for organize_by_visibility prompt."""

    def test_organize_all_visibility(self) -> None:
        """Test organizing all visibility levels."""
        result = organize_by_visibility()
        assert "visibility" in result.lower()
        assert "private" in result.lower()
        assert "public" in result.lower()

    def test_organize_specific_visibility(self) -> None:
        """Test organizing specific visibility."""
        result = organize_by_visibility("PRIVATE")
        assert "PRIVATE" in result
        assert "list_private_memos" in result


class TestPromptReturnTypes:
    """Tests for prompt return types."""

    def test_all_prompts_return_string(self) -> None:
        """Verify all prompts return string."""
        assert isinstance(search_by_tag("test"), str)
        assert isinstance(create_quick_note("test"), str)
        assert isinstance(find_recent_notes(), str)
        assert isinstance(organize_by_visibility(), str)