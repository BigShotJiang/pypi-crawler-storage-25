"""Tests for MemosClient async HTTP client."""

import httpx
import pytest
import respx

from memos_mcp.client import MemosClient
from memos_mcp.config import Settings
from memos_mcp.exceptions import AuthenticationError, MemosAPIError, MemosNotFoundError
from memos_mcp.models import Memo, MemoState, MemoVisibility


@pytest.fixture
def settings():
    """Test settings fixture."""
    return Settings(
        memos_url="https://memos.example.com",
        memos_token="test-token",
        api_version="v1",
        request_timeout=30.0,
    )


@pytest.fixture
def client(settings):
    """Client fixture."""
    return MemosClient(settings)


@pytest.fixture
def sample_memo_response():
    """Sample memo response from API."""
    return {
        "name": "memos/1",
        "state": "NORMAL",
        "creator": "users/1",
        "content": "Test memo content",
        "visibility": "PRIVATE",
        "pinned": False,
        "tags": ["tag1", "tag2"],
        "createTime": "2024-01-01T12:00:00Z",
        "updateTime": "2024-01-01T12:30:00Z",
        "displayTime": "2024-01-01T12:00:00Z",
        "attachments": [],
    }


class TestMemosClientInit:
    """Tests for MemosClient initialization."""

    def test_init_with_settings(self, settings):
        """Test client initialization with settings."""
        client = MemosClient(settings)
        assert client.settings == settings
        assert client._client is None

    def test_init_without_settings_uses_get_settings(self, monkeypatch):
        """Test client initialization without settings uses get_settings."""
        test_settings = Settings(
            memos_url="https://test.example.com",
            memos_token="test-token",
        )
        monkeypatch.setattr(
            "memos_mcp.client.get_settings",
            lambda: test_settings,
        )
        client = MemosClient()
        assert client.settings == test_settings


class TestMemosClientClose:
    """Tests for MemosClient close method."""

    @pytest.mark.asyncio
    async def test_close_with_no_client(self, client):
        """Test close when client is not initialized."""
        await client.close()
        assert client._client is None

    @pytest.mark.asyncio
    async def test_close_with_initialized_client(self, client):
        """Test close when client is initialized."""
        client._get_client()
        assert client._client is not None
        await client.close()
        assert client._client is None


class TestListMemos:
    """Tests for list_memos method."""

    @pytest.mark.asyncio
    async def test_list_memos_success(self, client, sample_memo_response):
        """Test successful list_memos call."""
        with respx.mock:
            respx.get("https://memos.example.com/api/v1/memos").mock(
                return_value=httpx.Response(200, json={"memos": [sample_memo_response]})
            )
            memos = await client.list_memos()

        assert len(memos) == 1
        assert isinstance(memos[0], Memo)
        assert memos[0].name == "memos/1"
        assert memos[0].content == "Test memo content"

    @pytest.mark.asyncio
    async def test_list_memos_with_limit(self, client, sample_memo_response):
        """Test list_memos with limit parameter."""
        with respx.mock:
            route = respx.get("https://memos.example.com/api/v1/memos").mock(
                return_value=httpx.Response(200, json={"memos": [sample_memo_response]})
            )
            await client.list_memos(limit=10)

        request = route.calls[0].request
        assert "pageSize=10" in str(request.url)

    @pytest.mark.asyncio
    async def test_list_memos_with_state_filter(self, client, sample_memo_response):
        """Test list_memos with state filter."""
        with respx.mock:
            route = respx.get("https://memos.example.com/api/v1/memos").mock(
                return_value=httpx.Response(200, json={"memos": [sample_memo_response]})
            )
            await client.list_memos(state=MemoState.NORMAL)

        request = route.calls[0].request
        assert "state=NORMAL" in str(request.url)

    @pytest.mark.asyncio
    async def test_list_memos_with_filter(self, client, sample_memo_response):
        """Test list_memos with filter parameter."""
        with respx.mock:
            route = respx.get("https://memos.example.com/api/v1/memos").mock(
                return_value=httpx.Response(200, json={"memos": [sample_memo_response]})
            )
            await client.list_memos(filter="creator == 'users/1'")

        request = route.calls[0].request
        assert "filter" in str(request.url)

    @pytest.mark.asyncio
    async def test_list_memos_with_order_by(self, client, sample_memo_response):
        """Test list_memos with order_by parameter."""
        with respx.mock:
            route = respx.get("https://memos.example.com/api/v1/memos").mock(
                return_value=httpx.Response(200, json={"memos": [sample_memo_response]})
            )
            await client.list_memos(order_by="display_time desc")

        request = route.calls[0].request
        assert "orderBy" in str(request.url)

    @pytest.mark.asyncio
    async def test_list_memos_empty_result(self, client):
        """Test list_memos with empty result."""
        with respx.mock:
            respx.get("https://memos.example.com/api/v1/memos").mock(
                return_value=httpx.Response(200, json={"memos": []})
            )
            memos = await client.list_memos()

        assert memos == []

    @pytest.mark.asyncio
    async def test_list_memos_authentication_error(self, client):
        """Test list_memos with authentication error (401)."""
        with respx.mock:
            respx.get("https://memos.example.com/api/v1/memos").mock(
                return_value=httpx.Response(401, json={"message": "Unauthorized"})
            )
            with pytest.raises(AuthenticationError):
                await client.list_memos()

    @pytest.mark.asyncio
    async def test_list_memos_api_error(self, client):
        """Test list_memos with generic API error."""
        with respx.mock:
            respx.get("https://memos.example.com/api/v1/memos").mock(
                return_value=httpx.Response(500, json={"message": "Internal Server Error"})
            )
            with pytest.raises(MemosAPIError) as exc_info:
                await client.list_memos()

        assert exc_info.value.status_code == 500

    @pytest.mark.asyncio
    async def test_list_memos_api_error_without_json(self, client):
        """Test list_memos with API error that doesn't return JSON."""
        with respx.mock:
            respx.get("https://memos.example.com/api/v1/memos").mock(
                return_value=httpx.Response(503, text="Service Unavailable")
            )
            with pytest.raises(MemosAPIError) as exc_info:
                await client.list_memos()

        assert exc_info.value.status_code == 503
        assert "Service Unavailable" in str(exc_info.value)


class TestGetMemo:
    """Tests for get_memo method."""

    @pytest.mark.asyncio
    async def test_get_memo_success(self, client, sample_memo_response):
        """Test successful get_memo call."""
        with respx.mock:
            respx.get("https://memos.example.com/api/v1/memos/1").mock(
                return_value=httpx.Response(200, json=sample_memo_response)
            )
            memo = await client.get_memo("1")

        assert isinstance(memo, Memo)
        assert memo.name == "memos/1"
        assert memo.content == "Test memo content"

    @pytest.mark.asyncio
    async def test_get_memo_not_found(self, client):
        """Test get_memo with 404 not found."""
        with respx.mock:
            respx.get("https://memos.example.com/api/v1/memos/999").mock(
                return_value=httpx.Response(404, json={"message": "Memo not found"})
            )
            with pytest.raises(MemosNotFoundError) as exc_info:
                await client.get_memo("999")

        assert exc_info.value.resource_type == "Memo"
        assert exc_info.value.resource_id == "999"

    @pytest.mark.asyncio
    async def test_get_memo_authentication_error(self, client):
        """Test get_memo with authentication error."""
        with respx.mock:
            respx.get("https://memos.example.com/api/v1/memos/1").mock(
                return_value=httpx.Response(401, json={"message": "Unauthorized"})
            )
            with pytest.raises(AuthenticationError):
                await client.get_memo("1")

    @pytest.mark.asyncio
    async def test_get_memo_api_error(self, client):
        """Test get_memo with API error."""
        with respx.mock:
            respx.get("https://memos.example.com/api/v1/memos/1").mock(
                return_value=httpx.Response(500, json={"message": "Internal Error"})
            )
            with pytest.raises(MemosAPIError) as exc_info:
                await client.get_memo("1")

        assert exc_info.value.status_code == 500


class TestCreateMemo:
    """Tests for create_memo method."""

    @pytest.mark.asyncio
    async def test_create_memo_success(self, client, sample_memo_response):
        """Test successful create_memo call."""
        sample_memo_response["content"] = "New memo content"
        sample_memo_response["tags"] = ["new-tag"]

        with respx.mock:
            respx.post("https://memos.example.com/api/v1/memos").mock(
                return_value=httpx.Response(200, json=sample_memo_response)
            )
            memo = await client.create_memo(
                content="New memo content",
                visibility=MemoVisibility.PRIVATE,
                tags=["new-tag"],
            )

        assert isinstance(memo, Memo)
        assert memo.content == "New memo content"
        assert memo.tags == ["new-tag"]

    @pytest.mark.asyncio
    async def test_create_memo_minimal(self, client, sample_memo_response):
        """Test create_memo with minimal parameters."""
        sample_memo_response["content"] = "Minimal memo"

        with respx.mock:
            respx.post("https://memos.example.com/api/v1/memos").mock(
                return_value=httpx.Response(200, json=sample_memo_response)
            )
            memo = await client.create_memo(content="Minimal memo")

        assert memo.content == "Minimal memo"

    @pytest.mark.asyncio
    async def test_create_memo_with_visibility(self, client, sample_memo_response):
        """Test create_memo with visibility."""
        sample_memo_response["visibility"] = "PUBLIC"

        with respx.mock:
            route = respx.post("https://memos.example.com/api/v1/memos").mock(
                return_value=httpx.Response(200, json=sample_memo_response)
            )
            await client.create_memo(content="Public memo", visibility=MemoVisibility.PUBLIC)

        request = route.calls[0].request
        body = request.content.decode()
        assert '"visibility":"PUBLIC"' in body

    @pytest.mark.asyncio
    async def test_create_memo_authentication_error(self, client):
        """Test create_memo with authentication error."""
        with respx.mock:
            respx.post("https://memos.example.com/api/v1/memos").mock(
                return_value=httpx.Response(401, json={"message": "Unauthorized"})
            )
            with pytest.raises(AuthenticationError):
                await client.create_memo(content="Test memo")

    @pytest.mark.asyncio
    async def test_create_memo_api_error(self, client):
        """Test create_memo with API error."""
        with respx.mock:
            respx.post("https://memos.example.com/api/v1/memos").mock(
                return_value=httpx.Response(400, json={"message": "Invalid request"})
            )
            with pytest.raises(MemosAPIError) as exc_info:
                await client.create_memo(content="Test memo")

        assert exc_info.value.status_code == 400


class TestUpdateMemo:
    """Tests for update_memo method."""

    @pytest.mark.asyncio
    async def test_update_memo_content(self, client, sample_memo_response):
        """Test update_memo with content update."""
        sample_memo_response["content"] = "Updated content"

        with respx.mock:
            route = respx.patch("https://memos.example.com/api/v1/memos/1").mock(
                return_value=httpx.Response(200, json=sample_memo_response)
            )
            memo = await client.update_memo("1", content="Updated content")

        assert memo.content == "Updated content"
        request = route.calls[0].request
        body = request.content.decode()
        assert '"content":"Updated content"' in body

    @pytest.mark.asyncio
    async def test_update_memo_visibility(self, client, sample_memo_response):
        """Test update_memo with visibility update."""
        sample_memo_response["visibility"] = "PUBLIC"

        with respx.mock:
            route = respx.patch("https://memos.example.com/api/v1/memos/1").mock(
                return_value=httpx.Response(200, json=sample_memo_response)
            )
            memo = await client.update_memo("1", visibility=MemoVisibility.PUBLIC)

        assert memo.visibility == MemoVisibility.PUBLIC
        request = route.calls[0].request
        body = request.content.decode()
        assert '"visibility":"PUBLIC"' in body

    @pytest.mark.asyncio
    async def test_update_memo_pinned(self, client, sample_memo_response):
        """Test update_memo with pinned update."""
        sample_memo_response["pinned"] = True

        with respx.mock:
            route = respx.patch("https://memos.example.com/api/v1/memos/1").mock(
                return_value=httpx.Response(200, json=sample_memo_response)
            )
            memo = await client.update_memo("1", pinned=True)

        assert memo.pinned is True
        request = route.calls[0].request
        body = request.content.decode()
        assert '"pinned":true' in body

    @pytest.mark.asyncio
    async def test_update_memo_multiple_fields(self, client, sample_memo_response):
        """Test update_memo with multiple field updates."""
        sample_memo_response["content"] = "Updated"
        sample_memo_response["visibility"] = "PUBLIC"
        sample_memo_response["pinned"] = True

        with respx.mock:
            respx.patch("https://memos.example.com/api/v1/memos/1").mock(
                return_value=httpx.Response(200, json=sample_memo_response)
            )
            memo = await client.update_memo(
                "1",
                content="Updated",
                visibility=MemoVisibility.PUBLIC,
                pinned=True,
            )

        assert memo.content == "Updated"
        assert memo.visibility == MemoVisibility.PUBLIC
        assert memo.pinned is True

    @pytest.mark.asyncio
    async def test_update_memo_not_found(self, client):
        """Test update_memo with 404 not found."""
        with respx.mock:
            respx.patch("https://memos.example.com/api/v1/memos/999").mock(
                return_value=httpx.Response(404, json={"message": "Memo not found"})
            )
            with pytest.raises(MemosNotFoundError):
                await client.update_memo("999", content="Updated")

    @pytest.mark.asyncio
    async def test_update_memo_authentication_error(self, client):
        """Test update_memo with authentication error."""
        with respx.mock:
            respx.patch("https://memos.example.com/api/v1/memos/1").mock(
                return_value=httpx.Response(401, json={"message": "Unauthorized"})
            )
            with pytest.raises(AuthenticationError):
                await client.update_memo("1", content="Updated")

    @pytest.mark.asyncio
    async def test_update_memo_api_error(self, client):
        """Test update_memo with API error."""
        with respx.mock:
            respx.patch("https://memos.example.com/api/v1/memos/1").mock(
                return_value=httpx.Response(500, json={"message": "Server error"})
            )
            with pytest.raises(MemosAPIError) as exc_info:
                await client.update_memo("1", content="Updated")

        assert exc_info.value.status_code == 500


class TestDeleteMemo:
    """Tests for delete_memo method."""

    @pytest.mark.asyncio
    async def test_delete_memo_success(self, client):
        """Test successful delete_memo call."""
        with respx.mock:
            respx.delete("https://memos.example.com/api/v1/memos/1").mock(
                return_value=httpx.Response(200, json={})
            )
            result = await client.delete_memo("1")

        assert result is True

    @pytest.mark.asyncio
    async def test_delete_memo_not_found(self, client):
        """Test delete_memo with 404 not found."""
        with respx.mock:
            respx.delete("https://memos.example.com/api/v1/memos/999").mock(
                return_value=httpx.Response(404, json={"message": "Memo not found"})
            )
            with pytest.raises(MemosNotFoundError):
                await client.delete_memo("999")

    @pytest.mark.asyncio
    async def test_delete_memo_authentication_error(self, client):
        """Test delete_memo with authentication error."""
        with respx.mock:
            respx.delete("https://memos.example.com/api/v1/memos/1").mock(
                return_value=httpx.Response(401, json={"message": "Unauthorized"})
            )
            with pytest.raises(AuthenticationError):
                await client.delete_memo("1")

    @pytest.mark.asyncio
    async def test_delete_memo_api_error(self, client):
        """Test delete_memo with API error."""
        with respx.mock:
            respx.delete("https://memos.example.com/api/v1/memos/1").mock(
                return_value=httpx.Response(500, json={"message": "Server error"})
            )
            with pytest.raises(MemosAPIError) as exc_info:
                await client.delete_memo("1")

        assert exc_info.value.status_code == 500


class TestClientHeaders:
    """Tests for client headers and authentication."""

    @pytest.mark.asyncio
    async def test_authorization_header(self, client, sample_memo_response):
        """Test that Authorization header is set correctly."""
        with respx.mock:
            route = respx.get("https://memos.example.com/api/v1/memos").mock(
                return_value=httpx.Response(200, json={"memos": [sample_memo_response]})
            )
            await client.list_memos()

        request = route.calls[0].request
        assert "Authorization" in request.headers
        assert request.headers["Authorization"] == "Bearer test-token"

    @pytest.mark.asyncio
    async def test_content_type_header(self, client, sample_memo_response):
        """Test that Content-Type header is set correctly."""
        with respx.mock:
            route = respx.post("https://memos.example.com/api/v1/memos").mock(
                return_value=httpx.Response(200, json=sample_memo_response)
            )
            await client.create_memo(content="Test")

        request = route.calls[0].request
        assert "Content-Type" in request.headers
        assert request.headers["Content-Type"] == "application/json"