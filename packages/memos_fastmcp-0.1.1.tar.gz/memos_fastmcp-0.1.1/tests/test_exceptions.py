"""Tests for exceptions module."""

import pytest
from memos_mcp.exceptions import (
    MemosMCPError,
    ConfigurationError,
    AuthenticationError,
    MemosNotFoundError,
    MemosAPIError,
    ValidationError,
)


def test_base_exception():
    """Test base exception can be raised."""
    with pytest.raises(MemosMCPError):
        raise MemosMCPError("test error")


def test_configuration_error():
    """Test ConfigurationError with missing vars."""
    error = ConfigurationError(["MEMOS_URL", "MEMOS_TOKEN"])
    assert "MEMOS_URL" in str(error)
    assert "MEMOS_TOKEN" in str(error)
    assert error.missing_vars == ["MEMOS_URL", "MEMOS_TOKEN"]


def test_authentication_error():
    """Test AuthenticationError message."""
    error = AuthenticationError()
    assert "MEMOS_TOKEN" in str(error)


def test_memos_not_found_error():
    """Test MemosNotFoundError with resource info."""
    error = MemosNotFoundError("Memo", "123")
    assert "Memo" in str(error)
    assert "123" in str(error)


def test_memos_api_error():
    """Test MemosAPIError with status code."""
    error = MemosAPIError(404, "Not found")
    assert error.status_code == 404
    assert "404" in str(error)
    assert "Not found" in str(error)


def test_validation_error():
    """Test ValidationError with field and reason."""
    error = ValidationError("content", "must not be empty")
    assert "content" in str(error)
    assert "must not be empty" in str(error)


def test_memos_not_found_error_attributes():
    """Test MemosNotFoundError stores attributes."""
    error = MemosNotFoundError("Memo", "123")
    assert error.resource_type == "Memo"
    assert error.resource_id == "123"


def test_validation_error_attributes():
    """Test ValidationError stores attributes."""
    error = ValidationError("content", "must not be empty")
    assert error.field == "content"
    assert error.reason == "must not be empty"