"""Test configuration and fixtures."""

from datetime import datetime
from unittest.mock import AsyncMock

import pytest
import respx

from memos_mcp.client import MemosClient
from memos_mcp.config import Settings, get_settings
from memos_mcp.models import Memo, MemoState, MemoVisibility


@pytest.fixture(autouse=True)
def mock_env(monkeypatch):
    """Automatically mock environment variables for all tests."""
    monkeypatch.setenv("MEMOS_URL", "https://test.memos.example.com")
    monkeypatch.setenv("MEMOS_TOKEN", "test-token-for-testing")
    # Clear the settings cache so new settings are loaded
    get_settings.cache_clear()


@pytest.fixture
def test_settings():
    """Provide test settings."""
    return Settings(
        memos_url="https://test.memos.example.com",
        memos_token="test-token-for-testing",
        api_version="v1",
        request_timeout=30.0,
    )


@pytest.fixture
def test_client(test_settings):
    """Provide a MemosClient instance for testing."""
    return MemosClient(test_settings)


@pytest.fixture
async def async_client(test_settings):
    """Provide an async MemosClient instance that is properly closed."""
    client = MemosClient(test_settings)
    yield client
    await client.close()


@pytest.fixture
def sample_memo():
    """Provide a sample Memo object for testing."""
    return Memo(
        name="memos/1",
        state=MemoState.NORMAL,
        creator="users/1",
        content="# Test Memo\n\nThis is test content with #test tag.",
        visibility=MemoVisibility.PRIVATE,
        pinned=False,
        tags=["test", "sample"],
        create_time=datetime(2026, 4, 11, 10, 0),
        update_time=datetime(2026, 4, 11, 10, 0),
        display_time=datetime(2026, 4, 11, 10, 0),
    )


@pytest.fixture
def sample_memos():
    """Provide a list of sample Memo objects for testing."""
    return [
        Memo(
            name="memos/1",
            state=MemoState.NORMAL,
            creator="users/1",
            content="# First Memo\nContent here.",
            visibility=MemoVisibility.PRIVATE,
            pinned=True,
            tags=["work"],
            create_time=datetime(2026, 4, 10, 10, 0),
            update_time=datetime(2026, 4, 10, 10, 0),
            display_time=datetime(2026, 4, 10, 10, 0),
        ),
        Memo(
            name="memos/2",
            state=MemoState.NORMAL,
            creator="users/1",
            content="# Second Memo\nAnother content.",
            visibility=MemoVisibility.PUBLIC,
            pinned=False,
            tags=["personal", "work"],
            create_time=datetime(2026, 4, 11, 10, 0),
            update_time=datetime(2026, 4, 11, 10, 0),
            display_time=datetime(2026, 4, 11, 10, 0),
        ),
        Memo(
            name="memos/3",
            state=MemoState.ARCHIVED,
            creator="users/1",
            content="Archived memo",
            visibility=MemoVisibility.PRIVATE,
            pinned=False,
            tags=["archived"],
            create_time=datetime(2026, 4, 9, 10, 0),
            update_time=datetime(2026, 4, 9, 10, 0),
            display_time=datetime(2026, 4, 9, 10, 0),
        ),
    ]


@pytest.fixture
def sample_memo_response():
    """Provide a sample memo API response."""
    return {
        "name": "memos/1",
        "state": "NORMAL",
        "creator": "users/1",
        "content": "Test memo content",
        "visibility": "PRIVATE",
        "pinned": False,
        "tags": ["tag1", "tag2"],
        "createTime": "2024-01-01T12:00:00Z",
        "updateTime": "2024-01-01T12:30:00Z",
        "displayTime": "2024-01-01T12:00:00Z",
        "attachments": [],
    }


@pytest.fixture
def mock_api(test_settings):
    """Provide a mocked API with respx."""
    with respx.mock as mock:
        yield mock


@pytest.fixture
def mock_client_instance():
    """Provide a mocked MemosClient for tools testing."""
    mock_client = AsyncMock(spec=MemosClient)
    return mock_client


@pytest.fixture
def mock_settings_singleton(monkeypatch):
    """Override get_settings to return test settings."""
    test_settings = Settings(
        memos_url="https://test.memos.example.com",
        memos_token="test-token-for-testing",
    )
    monkeypatch.setattr("memos_mcp.config.get_settings", lambda: test_settings)
    return test_settings