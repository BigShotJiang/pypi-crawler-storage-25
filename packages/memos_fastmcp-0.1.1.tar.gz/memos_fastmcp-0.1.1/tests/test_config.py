"""Tests for configuration module."""

import pytest

from memos_mcp.config import Settings, get_settings
from memos_mcp.exceptions import ConfigurationError


class TestSettings:
    """Tests for Settings class."""

    def test_settings_from_env_vars(self, monkeypatch):
        """Test Settings loads from environment variables."""
        monkeypatch.setenv("MEMOS_URL", "https://memos.example.com")
        monkeypatch.setenv("MEMOS_TOKEN", "test-token-123")

        settings = Settings()

        assert settings.memos_url == "https://memos.example.com"
        assert settings.memos_token == "test-token-123"
        assert settings.api_version == "v1"
        assert settings.request_timeout == 30.0

    def test_api_base_url_property(self, monkeypatch):
        """Test api_base_url property constructs full URL."""
        monkeypatch.setenv("MEMOS_URL", "https://memos.example.com/")
        monkeypatch.setenv("MEMOS_TOKEN", "test-token")

        settings = Settings()

        assert settings.api_base_url == "https://memos.example.com/api/v1"

    def test_api_base_url_strips_trailing_slash(self, monkeypatch):
        """Test api_base_url strips trailing slash from memos_url."""
        monkeypatch.setenv("MEMOS_URL", "https://memos.example.com///")
        monkeypatch.setenv("MEMOS_TOKEN", "test-token")

        settings = Settings()

        assert settings.api_base_url == "https://memos.example.com/api/v1"

    def test_custom_api_version(self, monkeypatch):
        """Test custom API version."""
        monkeypatch.setenv("MEMOS_URL", "https://memos.example.com")
        monkeypatch.setenv("MEMOS_TOKEN", "test-token")
        monkeypatch.setenv("API_VERSION", "v2")

        settings = Settings()

        assert settings.api_version == "v2"
        assert settings.api_base_url == "https://memos.example.com/api/v2"

    def test_custom_timeout(self, monkeypatch):
        """Test custom request timeout."""
        monkeypatch.setenv("MEMOS_URL", "https://memos.example.com")
        monkeypatch.setenv("MEMOS_TOKEN", "test-token")
        monkeypatch.setenv("REQUEST_TIMEOUT", "60.0")

        settings = Settings()

        assert settings.request_timeout == 60.0

    def test_missing_url_raises_validation_error(self, monkeypatch):
        """Test missing MEMOS_URL raises validation error."""
        monkeypatch.delenv("MEMOS_URL", raising=False)
        monkeypatch.setenv("MEMOS_TOKEN", "test-token")

        with pytest.raises(Exception) as exc_info:
            Settings()

        # pydantic raises ValidationError for missing required fields
        assert "memos_url" in str(exc_info.value).lower()

    def test_missing_token_raises_validation_error(self, monkeypatch):
        """Test missing MEMOS_TOKEN raises validation error."""
        monkeypatch.setenv("MEMOS_URL", "https://memos.example.com")
        monkeypatch.delenv("MEMOS_TOKEN", raising=False)

        with pytest.raises(Exception) as exc_info:
            Settings()

        assert "memos_token" in str(exc_info.value).lower()


class TestGetSettings:
    """Tests for get_settings function."""

    def test_get_settings_returns_settings(self, monkeypatch):
        """Test get_settings returns Settings instance."""
        monkeypatch.setenv("MEMOS_URL", "https://memos.example.com")
        monkeypatch.setenv("MEMOS_TOKEN", "test-token")

        settings = get_settings()

        assert isinstance(settings, Settings)
        assert settings.memos_url == "https://memos.example.com"

    def test_cache_returns_same_instance(self, monkeypatch):
        """Test get_settings returns cached same instance."""
        # Clear the cache first
        get_settings.cache_clear()

        monkeypatch.setenv("MEMOS_URL", "https://memos.example.com")
        monkeypatch.setenv("MEMOS_TOKEN", "test-token")

        settings1 = get_settings()
        settings2 = get_settings()

        assert settings1 is settings2

    def test_missing_url_raises_configuration_error(self, monkeypatch):
        """Test missing MEMOS_URL raises ConfigurationError."""
        # Clear the cache first
        get_settings.cache_clear()

        monkeypatch.delenv("MEMOS_URL", raising=False)
        monkeypatch.setenv("MEMOS_TOKEN", "test-token")

        with pytest.raises(ConfigurationError) as exc_info:
            get_settings()

        assert "MEMOS_URL" in exc_info.value.missing_vars

    def test_missing_token_raises_configuration_error(self, monkeypatch):
        """Test missing MEMOS_TOKEN raises ConfigurationError."""
        # Clear the cache first
        get_settings.cache_clear()

        monkeypatch.setenv("MEMOS_URL", "https://memos.example.com")
        monkeypatch.delenv("MEMOS_TOKEN", raising=False)

        with pytest.raises(ConfigurationError) as exc_info:
            get_settings()

        assert "MEMOS_TOKEN" in exc_info.value.missing_vars

    def test_missing_both_raises_configuration_error(self, monkeypatch):
        """Test missing both vars raises ConfigurationError with both."""
        # Clear the cache first
        get_settings.cache_clear()

        monkeypatch.delenv("MEMOS_URL", raising=False)
        monkeypatch.delenv("MEMOS_TOKEN", raising=False)

        with pytest.raises(ConfigurationError) as exc_info:
            get_settings()

        assert "MEMOS_URL" in exc_info.value.missing_vars
        assert "MEMOS_TOKEN" in exc_info.value.missing_vars