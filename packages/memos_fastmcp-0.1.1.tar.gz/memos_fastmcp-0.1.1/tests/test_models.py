"""Tests for Pydantic models."""

from datetime import datetime

import pytest
from pydantic import ValidationError

from memos_mcp.models import (
    Attachment,
    CreateMemoRequest,
    Memo,
    MemoProperty,
    MemoState,
    MemoVisibility,
    UpdateMemoRequest,
)


class TestMemoState:
    """Tests for MemoState enum."""

    def test_state_values(self):
        """Test MemoState enum values."""
        assert MemoState.STATE_UNSPECIFIED == "STATE_UNSPECIFIED"
        assert MemoState.NORMAL == "NORMAL"
        assert MemoState.ARCHIVED == "ARCHIVED"

    def test_state_is_string_enum(self):
        """Test MemoState is a string enum."""
        assert MemoState.NORMAL.value == "NORMAL"
        assert isinstance(MemoState.NORMAL, str)


class TestMemoVisibility:
    """Tests for MemoVisibility enum."""

    def test_visibility_values(self):
        """Test MemoVisibility enum values."""
        assert MemoVisibility.VISIBILITY_UNSPECIFIED == "VISIBILITY_UNSPECIFIED"
        assert MemoVisibility.PRIVATE == "PRIVATE"
        assert MemoVisibility.PROTECTED == "PROTECTED"
        assert MemoVisibility.PUBLIC == "PUBLIC"

    def test_visibility_is_string_enum(self):
        """Test MemoVisibility is a string enum."""
        assert MemoVisibility.PRIVATE.value == "PRIVATE"
        assert isinstance(MemoVisibility.PRIVATE, str)


class TestMemoProperty:
    """Tests for MemoProperty model."""

    def test_default_values(self):
        """Test default values for MemoProperty."""
        prop = MemoProperty()
        assert prop.has_link is False
        assert prop.has_task_list is False
        assert prop.has_code is False
        assert prop.has_incomplete_tasks is False
        assert prop.title is None

    def test_with_values(self):
        """Test MemoProperty with custom values."""
        prop = MemoProperty(
            has_link=True,
            has_task_list=True,
            has_code=True,
            has_incomplete_tasks=True,
            title="Test Title",
        )
        assert prop.has_link is True
        assert prop.has_task_list is True
        assert prop.has_code is True
        assert prop.has_incomplete_tasks is True
        assert prop.title == "Test Title"


class TestAttachment:
    """Tests for Attachment model."""

    def test_required_fields(self):
        """Test required fields for Attachment."""
        attachment = Attachment(
            name="test-attachment",
            filename="test.txt",
            type="text/plain",
            size="1024",
        )
        assert attachment.name == "test-attachment"
        assert attachment.filename == "test.txt"
        assert attachment.type == "text/plain"
        assert attachment.size == "1024"
        assert attachment.external_link is None

    def test_with_external_link(self):
        """Test Attachment with external link."""
        attachment = Attachment(
            name="test-attachment",
            filename="test.txt",
            type="text/plain",
            size="1024",
            external_link="https://example.com/file",
        )
        assert attachment.external_link == "https://example.com/file"


class TestMemo:
    """Tests for Memo model."""

    @pytest.fixture
    def sample_memo_data(self):
        """Sample memo data for testing."""
        return {
            "name": "memos/1",
            "creator": "users/1",
            "content": "Test memo content",
            "createTime": "2024-01-01T12:00:00Z",
            "updateTime": "2024-01-01T12:30:00Z",
            "displayTime": "2024-01-01T12:00:00Z",
        }

    def test_required_fields(self, sample_memo_data):
        """Test required fields for Memo."""
        memo = Memo(**sample_memo_data)
        assert memo.name == "memos/1"
        assert memo.creator == "users/1"
        assert memo.content == "Test memo content"

    def test_default_values(self, sample_memo_data):
        """Test default values for Memo."""
        memo = Memo(**sample_memo_data)
        assert memo.state == MemoState.NORMAL
        assert memo.visibility == MemoVisibility.PRIVATE
        assert memo.pinned is False
        assert memo.tags == []
        assert memo.attachments == []
        assert memo.property is None

    def test_alias_field_mapping(self, sample_memo_data):
        """Test alias field mapping for datetime fields."""
        memo = Memo(**sample_memo_data)
        assert isinstance(memo.create_time, datetime)
        assert isinstance(memo.update_time, datetime)
        assert isinstance(memo.display_time, datetime)

    def test_with_all_fields(self, sample_memo_data):
        """Test Memo with all fields populated."""
        memo = Memo(
            **sample_memo_data,
            state=MemoState.ARCHIVED,
            visibility=MemoVisibility.PUBLIC,
            pinned=True,
            tags=["tag1", "tag2"],
            attachments=[
                Attachment(
                    name="att1",
                    filename="file.txt",
                    type="text/plain",
                    size="100",
                )
            ],
            property=MemoProperty(has_link=True),
        )
        assert memo.state == MemoState.ARCHIVED
        assert memo.visibility == MemoVisibility.PUBLIC
        assert memo.pinned is True
        assert memo.tags == ["tag1", "tag2"]
        assert len(memo.attachments) == 1
        assert memo.attachments[0].name == "att1"
        assert memo.property.has_link is True

    def test_nested_attachments(self, sample_memo_data):
        """Test Memo with nested Attachment objects."""
        memo = Memo(
            **sample_memo_data,
            attachments=[
                {
                    "name": "att1",
                    "filename": "file1.txt",
                    "type": "text/plain",
                    "size": "100",
                },
                {
                    "name": "att2",
                    "filename": "file2.png",
                    "type": "image/png",
                    "size": "200",
                    "external_link": "https://example.com/image.png",
                },
            ],
        )
        assert len(memo.attachments) == 2
        assert memo.attachments[0].filename == "file1.txt"
        assert memo.attachments[1].external_link == "https://example.com/image.png"


class TestCreateMemoRequest:
    """Tests for CreateMemoRequest model."""

    def test_required_content(self):
        """Test content is required for CreateMemoRequest."""
        with pytest.raises(ValidationError) as exc_info:
            CreateMemoRequest()
        assert "content" in str(exc_info.value)

    def test_content_min_length(self):
        """Test content cannot be empty."""
        with pytest.raises(ValidationError) as exc_info:
            CreateMemoRequest(content="")
        assert "at least 1 character" in str(exc_info.value).lower() or "min_length" in str(exc_info.value).lower()

    def test_default_values(self):
        """Test default values for CreateMemoRequest."""
        request = CreateMemoRequest(content="Test content")
        assert request.content == "Test content"
        assert request.visibility == MemoVisibility.PRIVATE
        assert request.tags == []

    def test_with_all_fields(self):
        """Test CreateMemoRequest with all fields."""
        request = CreateMemoRequest(
            content="Test content",
            visibility=MemoVisibility.PUBLIC,
            tags=["tag1", "tag2"],
        )
        assert request.content == "Test content"
        assert request.visibility == MemoVisibility.PUBLIC
        assert request.tags == ["tag1", "tag2"]


class TestUpdateMemoRequest:
    """Tests for UpdateMemoRequest model."""

    def test_all_fields_optional(self):
        """Test all fields are optional for UpdateMemoRequest."""
        request = UpdateMemoRequest()
        assert request.content is None
        assert request.visibility is None
        assert request.pinned is None

    def test_with_fields(self):
        """Test UpdateMemoRequest with fields."""
        request = UpdateMemoRequest(
            content="Updated content",
            visibility=MemoVisibility.PROTECTED,
            pinned=True,
        )
        assert request.content == "Updated content"
        assert request.visibility == MemoVisibility.PROTECTED
        assert request.pinned is True

    def test_partial_update(self):
        """Test partial update with only some fields."""
        request = UpdateMemoRequest(pinned=False)
        assert request.content is None
        assert request.visibility is None
        assert request.pinned is False