"""Memo CRUD tools."""

from typing import Literal

from fastmcp import FastMCP

from memos_mcp.client import MemosClient
from memos_mcp.config import get_settings
from memos_mcp.models import MemoState, MemoVisibility

_client: MemosClient | None = None


def get_client() -> MemosClient:
    """Get or create the singleton MemosClient instance."""
    global _client
    if _client is None:
        _client = MemosClient(get_settings())
    return _client


async def create_memo(
    content: str,
    visibility: Literal["PRIVATE", "PROTECTED", "PUBLIC"] = "PRIVATE",
    tags: list[str] | None = None,
) -> dict:
    """Create a new memo.

    Args:
        content: The memo content (markdown supported).
        visibility: Memo visibility level (PRIVATE, PROTECTED, PUBLIC).
        tags: List of tags to apply to the memo.

    Returns:
        The created memo as a dictionary.
    """
    client = get_client()
    visibility_enum = MemoVisibility(visibility)
    memo = await client.create_memo(
        content=content,
        visibility=visibility_enum,
        tags=tags or [],
    )
    return memo.model_dump()


async def get_memo(memo_id: str) -> dict:
    """Get a memo by ID.

    Args:
        memo_id: The memo ID (e.g., "1" or "memos/1").

    Returns:
        The memo as a dictionary.
    """
    client = get_client()
    memo = await client.get_memo(memo_id)
    return memo.model_dump()


async def update_memo(
    memo_id: str,
    content: str | None = None,
    visibility: Literal["PRIVATE", "PROTECTED", "PUBLIC"] | None = None,
    pinned: bool | None = None,
) -> dict:
    """Update an existing memo.

    Args:
        memo_id: The memo ID to update.
        content: New content for the memo (optional).
        visibility: New visibility level (optional).
        pinned: New pinned status (optional).

    Returns:
        The updated memo as a dictionary.
    """
    client = get_client()
    visibility_enum = None
    if visibility is not None:
        visibility_enum = MemoVisibility(visibility)
    memo = await client.update_memo(
        memo_id=memo_id,
        content=content,
        visibility=visibility_enum,
        pinned=pinned,
    )
    return memo.model_dump()


async def delete_memo(memo_id: str) -> bool:
    """Delete a memo.

    Args:
        memo_id: The memo ID to delete.

    Returns:
        True if deletion was successful.
    """
    client = get_client()
    return await client.delete_memo(memo_id)


async def list_memos(
    limit: int = 20,
    state: Literal["NORMAL", "ARCHIVED"] = "NORMAL",
    filter: str | None = None,
) -> list[dict]:
    """List memos with optional filters.

    Args:
        limit: Maximum number of memos to return.
        state: Filter by memo state (NORMAL or ARCHIVED).
        filter: Custom filter expression.

    Returns:
        List of memos as dictionaries.
    """
    client = get_client()
    state_enum = MemoState(state)
    memos = await client.list_memos(
        limit=limit,
        state=state_enum,
        filter=filter,
    )
    return [memo.model_dump() for memo in memos]


async def search_memos(
    query: str | None = None,
    tags: list[str] | None = None,
    limit: int = 20,
) -> list[dict]:
    """Search memos by content or tags.

    Args:
        query: Search query for memo content.
        tags: List of tags to filter by.
        limit: Maximum number of results.

    Returns:
        List of matching memos as dictionaries.
    """
    client = get_client()

    # Build filter expression
    filter_parts = []

    if query:
        # Escape single quotes in query for filter syntax
        escaped_query = query.replace("'", "\\'")
        filter_parts.append(f"content.contains('{escaped_query}')")

    if tags:
        # Filter by tags - each tag should be in the memo's tags
        for tag in tags:
            escaped_tag = tag.replace("'", "\\'")
            filter_parts.append(f"tags.contains('{escaped_tag}')")

    # Combine filters with AND
    filter_expr = None
    if filter_parts:
        filter_expr = " && ".join(filter_parts)

    memos = await client.list_memos(
        limit=limit,
        state=MemoState.NORMAL,
        filter=filter_expr,
    )
    return [memo.model_dump() for memo in memos]


def register_tools(mcp: FastMCP) -> None:
    """Register all memo tools with the FastMCP instance."""
    mcp.tool(create_memo)
    mcp.tool(get_memo)
    mcp.tool(update_memo)
    mcp.tool(delete_memo)
    mcp.tool(list_memos)
    mcp.tool(search_memos)