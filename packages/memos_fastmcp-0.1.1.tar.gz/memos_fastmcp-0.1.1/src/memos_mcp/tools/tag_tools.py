"""Tag management tools."""

from fastmcp import FastMCP

from memos_mcp.client import MemosClient
from memos_mcp.config import get_settings
from memos_mcp.utils import format_tags_stats

_client: MemosClient | None = None


def get_client() -> MemosClient:
    """Get or create the singleton MemosClient instance."""
    global _client
    if _client is None:
        _client = MemosClient(get_settings())
    return _client


async def list_tags(limit: int = 100) -> str:
    """List all tags with their usage counts.

    Args:
        limit: Maximum number of tags to return.

    Returns:
        Markdown table showing tags and their usage counts.
    """
    client = get_client()
    tags = await client.list_tags(limit=limit)
    return format_tags_stats(tags)


async def rename_tag(old_name: str, new_name: str) -> str:
    """Rename a tag across all memos.

    Args:
        old_name: Current tag name to rename.
        new_name: New tag name.

    Returns:
        Summary of the rename operation.
    """
    client = get_client()
    updated_memos = await client.rename_tag(old_name, new_name)

    count = len(updated_memos)
    return f"Successfully renamed tag '{old_name}' to '{new_name}' in {count} memo(s)."


async def delete_tag(tag_name: str) -> str:
    """Delete a tag from all memos.

    Args:
        tag_name: Tag name to delete.

    Returns:
        Summary of the delete operation.
    """
    client = get_client()
    updated_memos = await client.delete_tag(tag_name)

    count = len(updated_memos)
    return f"Successfully deleted tag '{tag_name}' from {count} memo(s)."


def register_tools(mcp: FastMCP) -> None:
    """Register all tag tools with the FastMCP instance."""
    mcp.tool(list_tags)
    mcp.tool(rename_tag)
    mcp.tool(delete_tag)