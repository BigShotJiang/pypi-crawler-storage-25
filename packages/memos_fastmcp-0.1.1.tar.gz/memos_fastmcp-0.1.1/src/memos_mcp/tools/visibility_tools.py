"""Visibility control tools."""

from typing import Literal

from fastmcp import FastMCP

from memos_mcp.client import MemosClient
from memos_mcp.config import get_settings
from memos_mcp.models import MemoVisibility
from memos_mcp.utils import format_memo_list

_client: MemosClient | None = None


def get_client() -> MemosClient:
    """Get or create the singleton MemosClient instance."""
    global _client
    if _client is None:
        _client = MemosClient(get_settings())
    return _client


async def set_visibility(
    memo_id: str,
    visibility: Literal["PRIVATE", "PROTECTED", "PUBLIC"],
) -> str:
    """Set the visibility of a memo.

    Args:
        memo_id: The memo ID to update.
        visibility: New visibility level (PRIVATE, PROTECTED, PUBLIC).

    Returns:
        Summary of the visibility change.
    """
    client = get_client()
    visibility_enum = MemoVisibility(visibility)
    memo = await client.update_memo(memo_id, visibility=visibility_enum)

    memo_id_short = memo.name.split("/")[-1] if "/" in memo.name else memo.name
    return f"Successfully set memo {memo_id_short} visibility to {visibility}."


async def list_public_memos(limit: int = 20) -> str:
    """List all public memos.

    Args:
        limit: Maximum number of memos to return.

    Returns:
        Markdown table of public memos.
    """
    client = get_client()
    memos = await client.list_memos(limit=limit, state=None)
    public_memos = [m for m in memos if m.visibility == MemoVisibility.PUBLIC]
    return format_memo_list(public_memos)


async def list_private_memos(limit: int = 20) -> str:
    """List all private memos.

    Args:
        limit: Maximum number of memos to return.

    Returns:
        Markdown table of private memos.
    """
    client = get_client()
    memos = await client.list_memos(limit=limit, state=None)
    private_memos = [m for m in memos if m.visibility == MemoVisibility.PRIVATE]
    return format_memo_list(private_memos)


def register_tools(mcp: FastMCP) -> None:
    """Register all visibility tools with the FastMCP instance."""
    mcp.tool(set_visibility)
    mcp.tool(list_public_memos)
    mcp.tool(list_private_memos)