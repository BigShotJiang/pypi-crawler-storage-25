"""MCP tools for Memos."""

from memos_mcp.tools.memo_tools import register_tools as register_memo_tools
from memos_mcp.tools.tag_tools import register_tools as register_tag_tools
from memos_mcp.tools.visibility_tools import register_tools as register_visibility_tools

__all__ = [
    "register_memo_tools",
    "register_tag_tools",
    "register_visibility_tools",
]