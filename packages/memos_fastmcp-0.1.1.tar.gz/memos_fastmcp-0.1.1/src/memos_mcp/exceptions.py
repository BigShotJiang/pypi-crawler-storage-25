"""Custom exceptions for Memos MCP Server."""


class MemosMCPError(Exception):
    """Base exception for Memos MCP errors."""

    pass


class ConfigurationError(MemosMCPError):
    """Configuration error - missing required environment variables."""

    def __init__(self, missing_vars: list[str]):
        self.missing_vars = missing_vars
        message = f"Missing required environment variables: {', '.join(missing_vars)}. "
        message += "Please set MEMOS_URL and MEMOS_TOKEN."
        super().__init__(message)


class AuthenticationError(MemosMCPError):
    """Authentication error - invalid or expired token."""

    def __init__(self):
        super().__init__("Authentication failed. Please check if MEMOS_TOKEN is valid.")


class MemosNotFoundError(MemosMCPError):
    """Resource not found - memo, tag, etc."""

    def __init__(self, resource_type: str, resource_id: str):
        self.resource_type = resource_type
        self.resource_id = resource_id
        super().__init__(f"{resource_type} not found: {resource_id}")


class MemosAPIError(MemosMCPError):
    """API error - Memos server returned error."""

    def __init__(self, status_code: int, message: str):
        self.status_code = status_code
        super().__init__(f"API error ({status_code}): {message}")


class ValidationError(MemosMCPError):
    """Validation error - parameter does not meet requirements."""

    def __init__(self, field: str, reason: str):
        self.field = field
        self.reason = reason
        super().__init__(f"Validation failed: {field} - {reason}")