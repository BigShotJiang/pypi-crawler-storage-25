"""MCP Prompts for Memos."""

from fastmcp import FastMCP


def search_by_tag(tag: str) -> str:
    """Search for memos with a specific tag.

    Use this prompt to quickly find all memos containing a specific tag.

    Args:
        tag: The tag name to search for.

    Returns:
        A prompt template for searching memos by tag.
    """
    return f"""Please help me search for all memos containing the tag "#{tag}".

Use the search_memos tool with the following parameters:
- tags: ["{tag}"]
- limit: 50

Then summarize the found memos, listing their main topics and key information."""


def create_quick_note(content: str, tag: str = "") -> str:
    """Quickly create a simple note.

    Use this prompt to create a memo with minimal effort.

    Args:
        content: The note content.
        tag: Optional tag to apply.

    Returns:
        A prompt template for creating a quick note.
    """
    tag_instruction = ""
    if tag:
        tag_instruction = f" and add the tag '{tag}'"

    return f"""Please help me create a memo with the following content{tag_instruction}:

{content}

Use the create_memo tool to complete the creation, then tell me the result."""


def find_recent_notes(days: int = 7) -> str:
    """Find memos from the past few days.

    Use this prompt to discover recently created or updated memos.

    Args:
        days: Number of days to look back (default: 7).

    Returns:
        A prompt template for finding recent memos.
    """
    return f"""Please help me find memos from the past {days} days.

Use the list_memos tool with appropriate filters to get recent memos.
Then provide a summary organized by:
1. Most important topics
2. Tags used
3. Any pinned items

Highlight any memos that might need follow-up action."""


def organize_by_visibility(target_visibility: str = "") -> str:
    """Organize memos by visibility level.

    Use this prompt to review and organize memos based on their visibility settings.

    Args:
        target_visibility: Optional target visibility to filter (PRIVATE, PROTECTED, PUBLIC).

    Returns:
        A prompt template for organizing memos by visibility.
    """
    if target_visibility:
        filter_instruction = f"""Focus only on memos with visibility '{target_visibility}'.
Use the appropriate list tool (list_private_memos or list_public_memos)."""
    else:
        filter_instruction = """Review all memos across all visibility levels:
- Private memos (use list_private_memos)
- Public memos (use list_public_memos)"""

    return f"""Please help me organize my memos by visibility level.

{filter_instruction}

Provide a summary including:
1. Number of memos at each visibility level
2. Suggestions for visibility changes (e.g., which private memos could be made public)
3. Any sensitive content that should remain private"""


def register_prompts(mcp: FastMCP) -> None:
    """Register all prompts with the FastMCP instance."""
    mcp.prompt(search_by_tag)
    mcp.prompt(create_quick_note)
    mcp.prompt(find_recent_notes)
    mcp.prompt(organize_by_visibility)