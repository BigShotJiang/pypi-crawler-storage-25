"""MCP Server entry point for Memos."""

from fastmcp import FastMCP

from memos_mcp import __version__
from memos_mcp.resources import register_resources
from memos_mcp.prompts import register_prompts
from memos_mcp.tools import (
    register_memo_tools,
    register_tag_tools,
    register_visibility_tools,
)

# Create the FastMCP server instance
mcp = FastMCP(
    "memos-mcp",
    version=__version__,
)

# Register all components
register_memo_tools(mcp)
register_tag_tools(mcp)
register_visibility_tools(mcp)
register_resources(mcp)
register_prompts(mcp)


def main() -> None:
    """Run the MCP server."""
    mcp.run()


if __name__ == "__main__":
    main()