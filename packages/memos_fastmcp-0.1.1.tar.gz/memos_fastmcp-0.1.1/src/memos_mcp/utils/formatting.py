"""Formatting utilities for Markdown output."""

from datetime import datetime

from memos_mcp.models import Memo


def format_memo_list(memos: list[Memo]) -> str:
    """Format memo list as Markdown table.

    Args:
        memos: List of Memo objects.

    Returns:
        Markdown table string with columns: ID, Title, Tags, Created, Visibility.
    """
    if not memos:
        return "No memos found."

    lines = [
        "| ID | Title | Tags | Created | Visibility |",
        "|----|-------|------|---------|------------|",
    ]

    for memo in memos:
        # Extract ID from name (e.g., "memos/123" -> "123")
        memo_id = memo.name.split("/")[-1] if "/" in memo.name else memo.name
        title = extract_title(memo.content)
        tags = ", ".join(memo.tags) if memo.tags else "-"
        created = format_datetime(memo.create_time)
        visibility = memo.visibility.value if memo.visibility else "-"

        lines.append(f"| {memo_id} | {title} | {tags} | {created} | {visibility} |")

    return "\n".join(lines)


def format_memo_detail(memo: Memo) -> str:
    """Format single memo as Markdown document.

    Args:
        memo: Memo object.

    Returns:
        Markdown document string.
    """
    # Extract ID from name
    memo_id = memo.name.split("/")[-1] if "/" in memo.name else memo.name

    lines = [
        f"# Memo {memo_id}",
        "",
        f"**Created:** {format_datetime(memo.create_time)}",
        f"**Updated:** {format_datetime(memo.update_time)}",
        f"**Visibility:** {memo.visibility.value if memo.visibility else '-'}",
        f"**State:** {memo.state.value if memo.state else '-'}",
        f"**Pinned:** {'Yes' if memo.pinned else 'No'}",
    ]

    if memo.tags:
        lines.append(f"**Tags:** {', '.join(memo.tags)}")

    lines.append("")
    lines.append("## Content")
    lines.append("")
    lines.append(memo.content)

    if memo.attachments:
        lines.append("")
        lines.append("## Attachments")
        lines.append("")
        for att in memo.attachments:
            lines.append(f"- **{att.filename}** ({att.type}, {att.size})")
            if att.external_link:
                lines.append(f"  - Link: {att.external_link}")

    return "\n".join(lines)


def format_tags_stats(tags: dict[str, int]) -> str:
    """Format tags statistics as Markdown table.

    Args:
        tags: Dictionary mapping tag names to usage counts.

    Returns:
        Markdown table string with columns: Tag, Count.
    """
    if not tags:
        return "No tags found."

    lines = [
        "| Tag | Count |",
        "|-----|-------|",
    ]

    # Sort by count descending, then alphabetically
    sorted_tags = sorted(tags.items(), key=lambda x: (-x[1], x[0]))

    for tag, count in sorted_tags:
        lines.append(f"| {tag} | {count} |")

    return "\n".join(lines)


def format_stats(stats: dict) -> str:
    """Format statistics as Markdown.

    Args:
        stats: Dictionary with statistics data.

    Returns:
        Markdown formatted statistics.
    """
    lines = ["# Memos Statistics", ""]

    # Total memos
    if "total" in stats:
        lines.append(f"- **Total Memos:** {stats['total']}")

    # By visibility
    if "by_visibility" in stats:
        lines.append("")
        lines.append("## By Visibility")
        for vis, count in stats["by_visibility"].items():
            lines.append(f"- **{vis}:** {count}")

    # By state
    if "by_state" in stats:
        lines.append("")
        lines.append("## By State")
        for state, count in stats["by_state"].items():
            lines.append(f"- **{state}:** {count}")

    # Tags info
    if "total_tags" in stats:
        lines.append("")
        lines.append(f"- **Unique Tags:** {stats['total_tags']}")

    if "pinned" in stats:
        lines.append(f"- **Pinned Memos:** {stats['pinned']}")

    return "\n".join(lines)


def extract_title(content: str) -> str:
    """Extract title from memo content.

    Uses the first line of content, truncated to 50 characters.

    Args:
        content: Memo content string.

    Returns:
        Extracted title (first line, max 50 chars).
    """
    if not content:
        return "(Untitled)"

    # Get first non-empty line
    lines = content.strip().split("\n")
    first_line = next((line.strip() for line in lines if line.strip()), "")

    if not first_line:
        return "(Untitled)"

    # Remove markdown heading markers
    title = first_line.lstrip("#").strip()

    # Truncate to 50 characters
    if len(title) > 50:
        title = title[:47] + "..."

    return title if title else "(Untitled)"


def format_datetime(dt: datetime | str | None) -> str:
    """Format datetime for display.

    Args:
        dt: datetime object, ISO string, or None.

    Returns:
        Formatted string in YYYY-MM-DD HH:MM format.
    """
    if dt is None:
        return "-"

    # Parse string if needed
    if isinstance(dt, str):
        try:
            dt = datetime.fromisoformat(dt.replace("Z", "+00:00"))
        except ValueError:
            return dt  # Return as-is if parsing fails

    return dt.strftime("%Y-%m-%d %H:%M")