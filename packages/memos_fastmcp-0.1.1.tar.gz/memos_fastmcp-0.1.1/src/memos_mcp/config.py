"""Configuration management using pydantic-settings."""

from functools import lru_cache

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict

from memos_mcp.exceptions import ConfigurationError


class Settings(BaseSettings):
    """Application settings from environment variables."""

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        env_prefix="",
    )

    memos_url: str = Field(
        ...,
        description="Memos server URL"
    )
    memos_token: str = Field(
        ...,
        description="Memos API access token"
    )
    api_version: str = Field(
        default="v1",
        description="API version path"
    )
    request_timeout: float = Field(
        default=30.0,
        description="Request timeout in seconds"
    )

    @property
    def api_base_url(self) -> str:
        """Full API base URL."""
        base = self.memos_url.rstrip("/")
        return f"{base}/api/{self.api_version}"


@lru_cache
def get_settings() -> Settings:
    """Get settings instance (cached singleton)."""
    try:
        return Settings()
    except Exception as e:
        missing = []
        error_str = str(e)
        if "memos_url" in error_str.lower():
            missing.append("MEMOS_URL")
        if "memos_token" in error_str.lower():
            missing.append("MEMOS_TOKEN")
        raise ConfigurationError(missing)