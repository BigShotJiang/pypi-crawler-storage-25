"""Pydantic models for Memos API."""

from datetime import datetime
from enum import Enum

from pydantic import BaseModel, Field


class MemoState(str, Enum):
    """Memo state."""
    STATE_UNSPECIFIED = "STATE_UNSPECIFIED"
    NORMAL = "NORMAL"
    ARCHIVED = "ARCHIVED"


class MemoVisibility(str, Enum):
    """Memo visibility."""
    VISIBILITY_UNSPECIFIED = "VISIBILITY_UNSPECIFIED"
    PRIVATE = "PRIVATE"
    PROTECTED = "PROTECTED"
    PUBLIC = "PUBLIC"


class MemoProperty(BaseModel):
    """Memo properties."""
    has_link: bool = False
    has_task_list: bool = False
    has_code: bool = False
    has_incomplete_tasks: bool = False
    title: str | None = None


class Attachment(BaseModel):
    """Attachment."""
    name: str
    filename: str
    type: str
    size: str
    external_link: str | None = None


class Memo(BaseModel):
    """Memo."""
    name: str
    state: MemoState = MemoState.NORMAL
    creator: str
    content: str
    visibility: MemoVisibility = MemoVisibility.PRIVATE
    pinned: bool = False
    tags: list[str] = []
    create_time: datetime = Field(alias="createTime")
    update_time: datetime = Field(alias="updateTime")
    display_time: datetime = Field(alias="displayTime")
    attachments: list[Attachment] = []
    property: MemoProperty | None = None

    model_config = {"populate_by_name": True}


class CreateMemoRequest(BaseModel):
    """Request to create a memo."""
    content: str = Field(..., min_length=1)
    visibility: MemoVisibility = MemoVisibility.PRIVATE
    tags: list[str] = []


class UpdateMemoRequest(BaseModel):
    """Request to update a memo."""
    content: str | None = None
    visibility: MemoVisibility | None = None
    pinned: bool | None = None