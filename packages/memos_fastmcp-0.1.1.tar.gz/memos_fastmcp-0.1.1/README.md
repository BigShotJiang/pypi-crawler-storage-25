# Memos MCP Server

MCP server for [Memos](https://github.com/usememos/memos) - the open-source, self-hosted note-taking tool.

## Features

- **Tools**: Create, read, update, delete, search memos
- **Resources**: Access memo lists, tags, and statistics
- **Prompts**: Quick templates for common operations

## Installation

```bash
pip install memos-mcp
```

## Configuration

Set environment variables:

```bash
export MEMOS_URL="https://your-memos-instance.com"
export MEMOS_TOKEN="your-api-token"
```

## Usage with Claude Desktop

Add to your Claude Desktop config:

```json
{
  "mcpServers": {
    "memos": {
      "command": "uvx",
      "args": ["memos-mcp"],
      "env": {
        "MEMOS_URL": "https://your-memos-instance.com",
        "MEMOS_TOKEN": "your-api-token"
      }
    }
  }
}
```

## License

MIT