# Usage Guide

## Available Tools

### Memo Management

| Tool | Description |
|------|-------------|
| `create_memo` | Create a new memo |
| `get_memo` | Get a memo by ID |
| `update_memo` | Update memo content, visibility, or pinned status |
| `delete_memo` | Delete a memo |
| `list_memos` | List memos with filters |
| `search_memos` | Search memos by content or tags |

### Tag Management

| Tool | Description |
|------|-------------|
| `list_tags` | List all tags with usage counts |
| `rename_tag` | Rename a tag across all memos |
| `delete_tag` | Remove a tag from all memos |

### Visibility Control

| Tool | Description |
|------|-------------|
| `set_visibility` | Set memo visibility (PRIVATE/PROTECTED/PUBLIC) |
| `list_public_memos` | List all public memos |
| `list_private_memos` | List all private memos |

## Resources

Access data through MCP resources:

| URI | Description |
|-----|-------------|
| `memos://list` | Recent 20 memos summary |
| `memos://{memo_id}` | Full memo content and metadata |
| `memos://tags` | All tags with usage counts |
| `memos://stats` | Statistics overview |

## Prompts

Pre-defined workflows available:

| Prompt | Description |
|--------|-------------|
| `search_by_tag` | Find memos with specific tag |
| `create_quick_note` | Create a simple note quickly |
| `find_recent_notes` | Find memos from past days |
| `organize_by_visibility` | Review memos by visibility |

## Examples

### Creating a Memo

```
Create a memo with:
- Content: "Meeting notes from today's review"
- Visibility: PRIVATE
- Tags: ["work", "meeting"]
```

### Searching Memos

```
Search for memos containing "project" with tag "work"
```

### Managing Tags

```
Rename tag "old-project" to "completed-project"
Delete tag "temp" from all memos
```

### Visibility Management

```
Set memo 123 to PUBLIC visibility
List all public memos
```

## Best Practices

1. **Use tags consistently** - They help organize and search memos
2. **Set appropriate visibility** - Keep sensitive notes private
3. **Use prompts for workflows** - They streamline common operations
4. **Leverage resources** - Get quick overviews without calling tools

## Error Handling

The server handles errors gracefully:

- **ConfigurationError**: Missing environment variables
- **AuthenticationError**: Invalid or expired token
- **MemosNotFoundError**: Memo or resource not found
- **MemosAPIError**: API returned an error
- **ValidationError**: Invalid parameter provided