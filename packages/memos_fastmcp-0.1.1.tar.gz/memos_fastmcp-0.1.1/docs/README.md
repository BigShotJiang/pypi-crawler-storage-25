# Memos MCP Server

MCP server for [Memos](https://usememos.com/) - a self-hosted note-taking application. This server enables Claude Code and other MCP clients to interact with your Memos instance.

## Features

- **Full Memo Management**: Create, read, update, delete, search memos
- **Tag Management**: List, rename, and delete tags
- **Visibility Control**: Set visibility, list public/private memos
- **MCP Resources**: Access memo lists, individual memos, tags, and stats
- **MCP Prompts**: Pre-defined workflows for common operations

## Quick Start

### Installation

```bash
pip install memos-mcp
```

Or use `uvx` for direct execution:

```bash
uvx memos-mcp
```

### Configuration

Set environment variables:

```bash
export MEMOS_URL="https://your-memos-instance.com"
export MEMOS_TOKEN="your-api-token"
```

Or create a `.env` file:

```
MEMOS_URL=https://your-memos-instance.com
MEMOS_TOKEN=your-api-token
```

### Claude Desktop Integration

Add to your Claude Desktop config (`~/Library/Application Support/Claude/claude_desktop_config.json` on macOS):

```json
{
  "mcpServers": {
    "memos": {
      "command": "uvx",
      "args": ["memos-mcp"],
      "env": {
        "MEMOS_URL": "https://your-memos-instance.com",
        "MEMOS_TOKEN": "your-api-token"
      }
    }
  }
}
```

### Claude Code Integration

Add to `.claude/settings.json`:

```json
{
  "mcpServers": {
    "memos": {
      "type": "stdio",
      "command": "uvx",
      "args": ["memos-mcp"],
      "env": {
        "MEMOS_URL": "https://your-memos-instance.com",
        "MEMOS_TOKEN": "your-api-token"
      }
    }
  }
}
```

## Documentation

- [Installation Guide](installation.md)
- [Configuration](configuration.md)
- [Usage Examples](usage.md)

## License

MIT License - see [LICENSE](../LICENSE) for details.