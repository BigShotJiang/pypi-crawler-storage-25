# Installation Guide

## Prerequisites

- Python 3.10 or higher
- A running Memos instance with API access
- An API token from your Memos instance

## Installation Methods

### Method 1: pip

```bash
pip install memos-mcp
```

### Method 2: uvx (recommended for MCP integration)

`uvx` is the recommended method for MCP clients as it handles dependencies automatically:

```bash
uvx memos-mcp
```

### Method 3: Development Installation

For development or local testing:

```bash
git clone https://github.com/your-org/memos-mcp.git
cd memos-mcp
pip install -e ".[dev]"
```

## Getting Your API Token

1. Open your Memos instance
2. Go to Settings -> Access Tokens
3. Create a new access token
4. Copy the token for configuration

## Verifying Installation

Run the server directly to verify:

```bash
python -m memos_mcp.server
```

Or use FastMCP dev mode:

```bash
fastmcp dev src/memos_mcp/server.py
```

## Next Steps

- [Configuration Guide](configuration.md)
- [Usage Examples](usage.md)