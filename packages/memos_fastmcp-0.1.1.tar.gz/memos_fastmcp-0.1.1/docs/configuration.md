# Configuration

## Environment Variables

The Memos MCP Server requires two environment variables:

| Variable | Required | Description |
|----------|----------|-------------|
| `MEMOS_URL` | Yes | URL of your Memos instance (e.g., `https://memos.example.com`) |
| `MEMOS_TOKEN` | Yes | API access token from your Memos instance |

## Optional Configuration

| Variable | Default | Description |
|----------|---------|-------------|
| `API_VERSION` | `v1` | API version path |
| `REQUEST_TIMEOUT` | `30.0` | Request timeout in seconds |

## Configuration Methods

### Method 1: Environment Variables

```bash
export MEMOS_URL="https://your-memos-instance.com"
export MEMOS_TOKEN="your-api-token"
export REQUEST_TIMEOUT="60.0"  # optional
```

### Method 2: .env File

Create a `.env` file in your working directory:

```
MEMOS_URL=https://your-memos-instance.com
MEMOS_TOKEN=your-api-token
API_VERSION=v1
REQUEST_TIMEOUT=30.0
```

### Method 3: MCP Client Configuration

Pass environment variables through MCP client config:

**Claude Desktop:**
```json
{
  "mcpServers": {
    "memos": {
      "command": "uvx",
      "args": ["memos-mcp"],
      "env": {
        "MEMOS_URL": "https://your-memos-instance.com",
        "MEMOS_TOKEN": "your-api-token"
      }
    }
  }
}
```

**Claude Code:**
```json
{
  "mcpServers": {
    "memos": {
      "type": "stdio",
      "command": "uvx",
      "args": ["memos-mcp"],
      "env": {
        "MEMOS_URL": "https://your-memos-instance.com",
        "MEMOS_TOKEN": "your-api-token"
      }
    }
  }
}
```

## Security Notes

- Keep your API token secure - it provides full access to your Memos instance
- Never commit `.env` files to version control
- Use environment variable injection through MCP client config for production use

## Troubleshooting

### Configuration Error

If you see "Missing required environment variables", ensure:
- Both `MEMOS_URL` and `MEMOS_TOKEN` are set
- The URL is a valid Memos instance URL
- The token is a valid API token from your instance

### Authentication Error

If you see "Authentication failed":
- Verify your token is still valid
- Check if the token was revoked in Memos settings
- Ensure the token has necessary permissions

### Connection Timeout

If requests timeout:
- Check your Memos instance is accessible
- Increase `REQUEST_TIMEOUT` for slow connections
- Verify network connectivity