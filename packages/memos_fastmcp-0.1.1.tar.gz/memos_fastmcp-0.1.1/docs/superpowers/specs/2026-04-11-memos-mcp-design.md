---
title: Memos MCP Server 设计文档
date: 2026-04-11
type: design-spec
---

# Memos MCP Server 设计文档

## 概述

本文档描述 Memos MCP Server 的完整设计。该 MCP 服务允许 Claude Code 与 Memos（开源自托管笔记工具）进行交互，支持个人笔记管理。

## 需求摘要

| 项目 | 选择 |
|------|------|
| 用途 | 个人笔记管理 |
| 功能 | Memo CRUD、标签管理、可见性控制 |
| 配置方式 | 环境变量（MEMOS_URL、MEMOS_TOKEN） |
| MCP 能力 | Tools、Resources、Prompts |
| 项目结构 | 完整项目结构（测试、文档、配置文件） |
| 发布方式 | PyPI 发布 |

---

## 第一部分：架构概览

```
┌─────────────────────────────────────────────────────────────┐
│                    Claude Code / MCP Client                  │
└─────────────────────────────────────────────────────────────┘
                              │
                              │ MCP Protocol
                              ▼
┌─────────────────────────────────────────────────────────────┐
│                     memos-mcp Server                         │
│  ┌─────────────┬─────────────┬─────────────┬─────────────  │
│  │   Tools     │  Resources  │   Prompts   │   Config    │  │
│  │             │             │             │             │  │
│  │ • memo_crud │ • memo_list │ • search_   │ • MEMOS_URL │  │
│  │ • tags      │ • memo_get  │   by_tag    │ • MEMOS_TOKEN│ │
│  │ • visibility│ • tags      │ • create_   │             │  │
│  │             │             │   quick     │             │  │
│  └─────────────┴─────────────┴─────────────┴─────────────  │
│                              │                              │
│                              ▼                              │
│  ┌─────────────────────────────────────────────────────   │
│  │              MemosClient (httpx async)               │   │
│  │                                                     │   │
│  │  • GET    /api/v1/memos                             │   │
│  │  • POST   /api/v1/memos                             │   │
│  │  • GET    /api/v1/memos/{id}                        │   │
│  │  • PATCH  /api/v1/memos/{id}                        │   │
│  │  • DELETE /api/v1/memos/{id}                        │   │
│  └─────────────────────────────────────────────────────   │
└─────────────────────────────────────────────────────────────┘
                              │
                              │ HTTP + Bearer Token
                              ▼
┌─────────────────────────────────────────────────────────────┐
│                    Memos Server Instance                     │
│                    (your self-hosted Memos)                  │
└─────────────────────────────────────────────────────────────┘
```

**核心组件说明：**

| 组件 | 职责 | 技术 |
|------|------|------|
| `server.py` | MCP 服务入口，注册所有工具/资源/提示 | FastMCP |
| `client.py` | 与 Memos API 通信的异步客户端 | httpx + Pydantic |
| `models.py` | 数据模型定义（Memo、Attachment 等） | Pydantic v2 |
| `tools/` | MCP 工具实现，按功能模块化组织 | FastMCP @mcp.tool |
| `resources.py` | MCP 资源实现，提供可读取的数据源 | FastMCP @mcp.resource |
| `prompts.py` | MCP 提示模板，预定义常用操作 | FastMCP @mcp.prompt |
| `config.py` | 环境变量配置管理，验证必需参数 | pydantic-settings |
| `exceptions.py` | 自定义异常，统一错误处理 | Python exceptions |

---

## 第二部分：Tools（工具）设计

MCP 工具是 Claude 可以调用的操作。以下是计划实现的工具列表：

### Memo CRUD 工具

| 工具名称 | 功能描述 | 参数 |
|---------|---------|------|
| `create_memo` | 创建新笔记 | content（必需）、visibility、tags |
| `get_memo` | 获取单个笔记详情 | memo_id（必需） |
| `update_memo` | 更新笔记内容/属性 | memo_id（必需）、content、visibility、pinned |
| `delete_memo` | 删除笔记 | memo_id（必需） |
| `search_memos` | 搜索笔记 | query、tags、visibility、limit、state |
| `list_memos` | 列出笔记（分页） | pageSize、pageToken、filter、orderBy |

### 标签管理工具

| 工具名称 | 功能描述 | 参数 |
|---------|---------|------|
| `list_tags` | 列出所有标签 | limit（可选） |
| `rename_tag` | 重命名标签 | old_name（必需）、new_name（必需） |
| `delete_tag` | 删除标签（从所有笔记移除） | tag_name（必需） |

### 可见性控制工具

| 工具名称 | 功能描述 | 参数 |
|---------|---------|------|
| `set_visibility` | 设置笔记可见性 | memo_id（必需）、visibility（必需：PRIVATE/PROTECTED/PUBLIC） |

### 工具设计示例（create_memo）

```python
@mcp.tool
async def create_memo(
    content: str,
    visibility: str = "PRIVATE",
    tags: list[str] = None
) -> dict:
    """创建一个新的 Memos 笔记
    
    Args:
        content: 笔记内容，支持 Markdown 格式
        visibility: 可见性设置，可选值：PRIVATE、PROTECTED、PUBLIC
        tags: 标签列表，如 ["工作", "重要"]
    
    Returns:
        创建的笔记对象，包含 id、name、createTime 等信息
    """
    ...
```

---

## 第三部分：Resources（资源）设计

MCP 资源是 Claude 可以读取的数据源，不执行操作，只提供信息。

### 资源列表

| 资源 URI | 功能描述 | 返回内容 |
|---------|---------|---------|
| `memos://list` | 笔记列表概览 | 最近 20 条笔记的摘要（id、标题、标签、时间） |
| `memos://{memo_id}` | 单个笔记详情 | 笔记完整内容、元数据、附件信息 |
| `memos://tags` | 所有标签统计 | 标签名称及每个标签下的笔记数量 |
| `memos://stats` | 统计信息 | 总笔记数、各可见性的笔记数、最近活动时间 |

### 资源设计示例

```python
@mcp.resource("memos://list")
async def get_memo_list() -> str:
    """获取笔记列表概览
    
    返回最近 20 条笔记的摘要信息，包括：
    - 笔记 ID
    - 标题（从内容提取）
    - 标签
    - 创建时间
    - 可见性
    """
    memos = await client.list_memos(limit=20)
    # 格式化为 Markdown 表格返回
    return format_memo_list(memos)


@mcp.resource("memos://{memo_id}")
async def get_memo_detail(memo_id: str) -> str:
    """获取单个笔记的完整内容
    
    Args:
        memo_id: 笔记 ID
    
    返回笔记的完整 Markdown 内容和元数据
    """
    memo = await client.get_memo(memo_id)
    return format_memo_detail(memo)
```

**资源特点：**
- 返回格式为 Markdown 文本，便于 Claude 理解
- 支持动态 URI 参数（如 `{memo_id}`）
- 不修改数据，只读取

---

## 第四部分：Prompts（提示）设计

MCP 提示是预定义的模板，帮助用户快速执行常见操作。

### 提示列表

| 提示名称 | 功能描述 | 参数 |
|---------|---------|------|
| `search_by_tag` | 搜索指定标签的笔记 | tag（必需） |
| `create_quick_note` | 快速创建简单笔记 | content（必需）、tag（可选） |
| `find_recent_notes` | 查找最近的笔记 | days（可选，默认 7） |
| `organize_by_visibility` | 按可见性整理笔记 | target_visibility（可选） |

### 提示设计示例

```python
@mcp.prompt
def search_by_tag(tag: str) -> str:
    """搜索包含特定标签的笔记
    
    使用此提示快速查找所有带有指定标签的笔记
    
    Args:
        tag: 要搜索的标签名称
    """
    return f"""请帮我搜索所有包含标签 "#{tag}" 的笔记。
    
使用 search_memos 工具，传入以下参数：
- tags: ["{tag}"]
- limit: 50

然后总结找到的笔记内容，列出主要主题和关键信息。"""


@mcp.prompt
def create_quick_note(content: str, tag: str = None) -> str:
    """快速创建一条简单笔记
    
    Args:
        content: 笔记内容
        tag: 可选标签
    """
    tag_part = f"，并添加标签 "{tag}"" if tag else ""
    return f"""请帮我创建一条笔记：{content}{tag_part}

使用 create_memo 工具完成创建，然后告诉我创建结果。"""
```

**提示特点：**
- 返回文本模板，指导 Claude 如何执行操作
- 用户可以直接调用，简化交互流程
- 参数可选，灵活适应不同场景

---

## 第五部分：数据模型设计

使用 Pydantic v2 定义类型安全的数据模型，确保 API 响应自动验证和类型转换。

### 核心数据模型

```python
from pydantic import BaseModel, Field
from datetime import datetime
from enum import Enum


class MemoState(str, Enum):
    """笔记状态"""
    STATE_UNSPECIFIED = "STATE_UNSPECIFIED"
    NORMAL = "NORMAL"
    ARCHIVED = "ARCHIVED"


class MemoVisibility(str, Enum):
    """笔记可见性"""
    VISIBILITY_UNSPECIFIED = "VISIBILITY_UNSPECIFIED"
    PRIVATE = "PRIVATE"
    PROTECTED = "PROTECTED"
    PUBLIC = "PUBLIC"


class MemoProperty(BaseModel):
    """笔记属性"""
    has_link: bool = False
    has_task_list: bool = False
    has_code: bool = False
    has_incomplete_tasks: bool = False
    title: str | None = None


class Attachment(BaseModel):
    """附件"""
    name: str
    filename: str
    type: str
    size: str
    external_link: str | None = None


class Memo(BaseModel):
    """笔记"""
    name: str  # 格式: memos/{id}
    state: MemoState = MemoState.NORMAL
    creator: str
    content: str
    visibility: MemoVisibility = MemoVisibility.PRIVATE
    pinned: bool = False
    tags: list[str] = []
    create_time: datetime
    update_time: datetime
    display_time: datetime
    attachments: list[Attachment] = []
    property: MemoProperty | None = None


class CreateMemoRequest(BaseModel):
    """创建笔记请求"""
    content: str = Field(..., min_length=1)
    visibility: MemoVisibility = MemoVisibility.PRIVATE
    tags: list[str] = []


class UpdateMemoRequest(BaseModel):
    """更新笔记请求"""
    content: str | None = None
    visibility: MemoVisibility | None = None
    pinned: bool | None = None
```

### 数据模型用途

| 模型 | 用途 |
|------|------|
| `Memo` | API 响应解析，自动类型转换 |
| `MemoVisibility` | 可见性参数验证，防止无效值 |
| `MemoState` | 状态参数验证 |
| `CreateMemoRequest` | 创建请求参数验证 |
| `UpdateMemoRequest` | 更新请求参数验证 |

**模型特点：**
- 使用 Enum 确保枚举值安全
- 时间字段自动转换为 datetime 类型
- Field 约束确保参数有效（如 content 最小长度为 1）

---

## 第六部分：错误处理与配置管理设计

### 错误处理

```python
class MemosMCPError(Exception):
    """基础异常"""
    pass


class ConfigurationError(MemosMCPError):
    """配置错误 - 缺少必需的环境变量"""
    def __init__(self, missing_vars: list[str]):
        self.missing_vars = missing_vars
        super().__init__(
            f"缺少必需的环境变量: {', '.join(missing_vars)}。"
            f"请设置 MEMOS_URL 和 MEMOS_TOKEN"
        )


class AuthenticationError(MemosMCPError):
    """认证错误 - Token 无效或过期"""
    def __init__(self):
        super().__init__("认证失败，请检查 MEMOS_TOKEN 是否有效")


class MemosNotFoundError(MemosMCPError):
    """资源不存在 - 笔记、标签等找不到"""
    def __init__(self, resource_type: str, resource_id: str):
        super().__init__(f"{resource_type} 不存在: {resource_id}")


class MemosAPIError(MemosMCPError):
    """API 错误 - Memos 服务端返回错误"""
    def __init__(self, status_code: int, message: str):
        self.status_code = status_code
        super().__init__(f"API 错误 ({status_code}): {message}")


class ValidationError(MemosMCPError):
    """验证错误 - 参数不符合要求"""
    def __init__(self, field: str, reason: str):
        super().__init__(f"参数验证失败: {field} - {reason}")
```

### 配置管理

```python
from pydantic_settings import BaseSettings
from functools import lru_cache


class Settings(BaseSettings):
    """应用配置"""
    
    # Memos 服务器 URL（必需）
    memos_url: str = Field(
        ...,
        description="Memos 服务器地址，如 https://memos.example.com"
    )
    
    # API Token（必需）
    memos_token: str = Field(
        ...,
        description="Memos API 访问令牌"
    )
    
    # API 版本路径
    api_version: str = "v1"
    
    # 请求超时时间（秒）
    request_timeout: float = 30.0
    
    @property
    def api_base_url(self) -> str:
        """完整的 API 基础 URL"""
        base = self.memos_url.rstrip("/")
        return f"{base}/api/{self.api_version}"
    
    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"


@lru_cache
def get_settings() -> Settings:
    """获取配置实例（单例）"""
    try:
        return Settings()
    except Exception as e:
        missing = []
        if "memos_url" in str(e):
            missing.append("MEMOS_URL")
        if "memos_token" in str(e):
            missing.append("MEMOS_TOKEN")
        raise ConfigurationError(missing)
```

**配置使用方式：**

```bash
# 环境变量设置
export MEMOS_URL="https://your-memos-instance.com"
export MEMOS_TOKEN="your-api-token"

# 或使用 .env 文件
MEMOS_URL=https://your-memos-instance.com
MEMOS_TOKEN=your-api-token
```

---

## 第七部分：项目结构与文件组织

```
memos-mcp/
├── pyproject.toml              # 项目配置、依赖、PyPI 发布信息
├── README.md                   # 项目介绍、快速开始
├── LICENSE                     # MIT 许可证
├── .env.example                # 环境变量示例文件
├── .gitignore                  # Git 忽略文件
│
├── src/
│   └── memos_mcp/
│       ├── __init__.py         # 包入口，版本信息
│       ├── server.py           # MCP 服务主入口
│       ├── client.py           # Memos API 异步客户端
│       ├── models.py           # Pydantic 数据模型
│       ├── config.py           # 配置管理
│       ├── exceptions.py       # 自定义异常
│       │
│       ├── tools/
│       │   ├── __init__.py     # 工具模块入口
│       │   ├── memo_tools.py   # Memo CRUD 工具
│       │   ├── tag_tools.py    # 标签管理工具
│       │   └── visibility_tools.py  # 可见性控制工具
│       │
│       ├── resources.py        # MCP Resources 实现
│       ├── prompts.py          # MCP Prompts 实现
│       │
│       └── utils/
│           ├── __init__.py
│           └── formatting.py   # 格式化工具（Markdown 表格等）
│
├── tests/
│   ├── __init__.py
│   ├── conftest.py             # 测试配置、fixtures
│   ├── test_client.py          # API 客户端测试
│   ├── test_tools.py           # 工具测试
│   ├── test_resources.py       # 资源测试
│   ├── test_prompts.py         # 提示测试
│   └── test_config.py          # 配置测试
│
├── docs/
│   ├── README.md               # 文档首页
│   ├── installation.md         # 安装指南
│   ├── configuration.md        # 配置说明
│   ├── usage.md                # 使用示例
│   ├── tools.md                # 工具文档
│   ├── api-reference.md        # API 参考
│
└── examples/
    └── claude_desktop_config.json  # Claude Desktop 配置示例
```

### pyproject.toml 关键配置

```toml
[project]
name = "memos-mcp"
version = "0.1.0"
description = "MCP server for Memos - self-hosted note-taking"
readme = "README.md"
license = {text = "MIT"}
requires-python = ">=3.10"
authors = [
    {name = "Your Name", email = "your@email.com"}
]
keywords = ["mcp", "memos", "note-taking", "claude"]
classifiers = [
    "Development Status :: 4 - Beta",
    "Intended Audience :: Developers",
    "License :: OSI Approved :: MIT License",
    "Programming Language :: Python :: 3.10",
    "Programming Language :: Python :: 3.11",
    "Programming Language :: Python :: 3.12",
]

dependencies = [
    "fastmcp>=0.1.0",
    "httpx>=0.25.0",
    "pydantic>=2.0.0",
    "pydantic-settings>=2.0.0",
]

[project.optional-dependencies]
dev = [
    "pytest>=7.0.0",
    "pytest-asyncio>=0.21.0",
    "pytest-cov>=4.0.0",
    "ruff>=0.1.0",
    "mypy>=1.0.0",
]

[project.scripts]
memos-mcp = "memos_mcp.server:main"

[build-system]
requires = ["hatchling"]
build-backend = "hatchling.build"
```

---

## 第八部分：测试策略与部署说明

### 测试策略

**测试工具：**
- `pytest` + `pytest-asyncio`：异步测试支持
- `pytest-cov`：覆盖率报告
- `respx`：httpx 的 mock 库，模拟 API 响应

**测试层次：**

| 测试类型 | 测试内容 | 工具 |
|---------|---------|------|
| 单元测试 | 单个函数、模型的逻辑验证 | pytest + respx |
| 集成测试 | 工具与客户端的协作测试 | pytest + httpx mock |
| 配置测试 | 环境变量加载、验证逻辑 | pytest |
| 类型检查 | 静态类型验证 | mypy |

**测试示例结构：**

```python
# tests/conftest.py
import pytest
from unittest.mock import AsyncMock
from memos_mcp.client import MemosClient
from memos_mcp.config import Settings

@pytest.fixture
def mock_settings():
    return Settings(
        memos_url="https://test.memos.com",
        memos_token="test-token"
    )

@pytest.fixture
async def mock_client(mock_settings):
    client = MemosClient(mock_settings)
    # 使用 respx 模拟 API
    yield client
    await client.close()

# tests/test_memo_tools.py
import pytest
from memos_mcp.tools.memo_tools import create_memo, get_memo

@pytest.mark.asyncio
async def test_create_memo(mock_client):
    # 模拟 API 响应
    result = await create_memo("测试内容", "PRIVATE", [])
    assert result["content"] == "测试内容"
```

**覆盖率目标：**
- 核心代码覆盖率 ≥ 80%
- 关键路径（CRUD 操作）覆盖率 ≥ 95%

### 部署与使用说明

**安装方式：**

```bash
# PyPI 安装
pip install memos-mcp

# 或使用 uv
uv pip install memos-mcp
```

**配置 Claude Desktop：**

```json
// Claude Desktop 配置文件
{
  "mcpServers": {
    "memos": {
      "command": "uvx",
      "args": ["memos-mcp"],
      "env": {
        "MEMOS_URL": "https://your-memos-instance.com",
        "MEMOS_TOKEN": "your-api-token"
      }
    }
  }
}
```

**配置 Claude Code：**

```json
// .claude/settings.json
{
  "mcpServers": {
    "memos": {
      "type": "stdio",
      "command": "uvx",
      "args": ["memos-mcp"],
      "env": {
        "MEMOS_URL": "https://your-memos-instance.com",
        "MEMOS_TOKEN": "your-api-token"
      }
    }
  }
}
```

**开发运行：**

```bash
# 本地开发运行
cd memos-mcp
export MEMOS_URL="https://your-memos-instance.com"
export MEMOS_TOKEN="your-api-token"
python -m memos_mcp.server

# 或使用 fastmcp dev
fastmcp dev src/memos_mcp/server.py
```

---

## 技术依赖

| 依赖 | 版本 | 用途 |
|------|------|------|
| fastmcp | ≥0.1.0 | MCP 框架 |
| httpx | ≥0.25.0 | 异步 HTTP 客户端 |
| pydantic | ≥2.0.0 | 数据验证与模型 |
| pydantic-settings | ≥2.0.0 | 环境变量配置 |

## 开发依赖

| 依赖 | 版本 | 用途 |
|------|------|------|
| pytest | ≥7.0.0 | 测试框架 |
| pytest-asyncio | ≥0.21.0 | 异步测试 |
| pytest-cov | ≥4.0.0 | 覆盖率报告 |
| ruff | ≥0.1.0 | 代码格式化与 lint |
| mypy | ≥1.0.0 | 类型检查 |