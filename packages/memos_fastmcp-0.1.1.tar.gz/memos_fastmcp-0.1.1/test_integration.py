"""Integration test for Memos MCP Server with real API."""

import asyncio
import os
import sys

# Add src to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "src"))

from memos_mcp.client import MemosClient
from memos_mcp.config import Settings, get_settings
from memos_mcp.exceptions import MemosNotFoundError, MemosAPIError


# Test configuration - use environment variables or .env file
TEST_URL = os.environ.get("MEMOS_URL", "http://localhost:5230")
TEST_TOKEN = os.environ.get("MEMOS_TOKEN", "")

# Clear cache and create settings
get_settings.cache_clear()


async def test_all_features():
    """Run complete integration test."""

    # Setup
    print("=" * 60)
    print("Memos MCP Server Integration Test")
    print("=" * 60)

    settings = Settings(
        memos_url=TEST_URL,
        memos_token=TEST_TOKEN
    )
    client = MemosClient(settings)

    test_results = []
    created_memo_id = None

    try:
        # ========================================
        # Test 1: List existing memos
        # ========================================
        print("\n[Test 1] List existing memos...")
        memos = await client.list_memos(limit=5)
        print(f"  Found {len(memos)} memos")
        for m in memos[:3]:
            memo_id = m.name.split("/")[-1]
            content_preview = m.content[:30] if m.content else "empty"
            print(f"    - ID: {memo_id}, Content: {content_preview}...")
        test_results.append(("List memos", "PASS", f"Found {len(memos)} memos"))

        # ========================================
        # Test 2: Create a new memo
        # ========================================
        print("\n[Test 2] Create a new memo...")
        import time
        test_content = f"Test memo from MCP - timestamp:{time.time():.0f}"
        new_memo = await client.create_memo(
            content=test_content,
            visibility="PRIVATE",
            tags=["test", "integration"]
        )
        created_memo_id = new_memo.name.split("/")[-1]
        print(f"  Created memo ID: {created_memo_id}")
        print(f"  Content: {new_memo.content[:40]}...")
        print(f"  Tags: {new_memo.tags}")
        print(f"  Visibility: {new_memo.visibility.value}")
        test_results.append(("Create memo", "PASS", f"ID: {created_memo_id}"))

        # ========================================
        # Test 3: Verify created memo exists
        # ========================================
        print("\n[Test 3] Verify created memo exists...")
        fetched_memo = await client.get_memo(created_memo_id)
        print(f"  Fetched memo ID: {created_memo_id}")
        # Content check: original content should be present (tags are embedded in content)
        content_present = test_content in fetched_memo.content
        print(f"  Original content present: {content_present}")
        tags_match = fetched_memo.tags == ["test", "integration"]
        print(f"  Tags match: {tags_match}")
        assert content_present, "Original content not found!"
        assert tags_match, "Tags mismatch!"
        print("  [PASS] Verification passed - memo exists with correct content and tags")
        test_results.append(("Verify create", "PASS", "Content and tags match"))

        # ========================================
        # Test 4: Update the memo
        # ========================================
        print("\n[Test 4] Update the memo...")
        updated_content = f"{test_content} - UPDATED:{time.time():.0f}"
        updated_memo = await client.update_memo(
            memo_id=created_memo_id,
            content=updated_content,
            pinned=True
        )
        print(f"  Updated memo ID: {created_memo_id}")
        print(f"  New content: {updated_memo.content[:50]}...")
        print(f"  Pinned: {updated_memo.pinned}")
        test_results.append(("Update memo", "PASS", f"Pinned: {updated_memo.pinned}"))

        # ========================================
        # Test 5: Verify update worked
        # ========================================
        print("\n[Test 5] Verify update worked...")
        verified_memo = await client.get_memo(created_memo_id)
        # Content check: updated content should be present (tags are embedded)
        content_updated = updated_content in verified_memo.content
        pinned_updated = verified_memo.pinned == True
        print(f"  Updated content present: {content_updated}")
        print(f"  Pinned status: {verified_memo.pinned}")
        assert content_updated, "Update content not found!"
        assert pinned_updated, "Pinned status not updated!"
        print("  [PASS] Verification passed - update worked correctly")
        test_results.append(("Verify update", "PASS", "Content and pinned updated"))

        # ========================================
        # Test 6: Change visibility
        # ========================================
        print("\n[Test 6] Change visibility to PUBLIC...")
        public_memo = await client.update_memo(
            memo_id=created_memo_id,
            visibility="PUBLIC"
        )
        print(f"  New visibility: {public_memo.visibility.value}")
        test_results.append(("Change visibility", "PASS", public_memo.visibility.value))

        # Verify visibility change
        print("\n[Test 6b] Verify visibility change...")
        vis_memo = await client.get_memo(created_memo_id)
        print(f"  Visibility confirmed: {vis_memo.visibility.value}")
        assert vis_memo.visibility.value == "PUBLIC"
        test_results.append(("Verify visibility", "PASS", "PUBLIC confirmed"))

        # ========================================
        # Test 7: List tags
        # ========================================
        print("\n[Test 7] List tags...")
        all_memos = await client.list_memos(limit=50)
        tags_found = set()
        for m in all_memos:
            tags_found.update(m.tags)
        print(f"  Tags found: {list(tags_found)[:10]}")
        test_results.append(("List tags", "PASS", f"Found {len(tags_found)} tags"))

        # ========================================
        # Test 8: Delete the memo
        # ========================================
        print("\n[Test 8] Delete the test memo...")
        deleted = await client.delete_memo(created_memo_id)
        print(f"  Deleted: {deleted}")
        assert deleted == True, "Delete failed!"
        test_results.append(("Delete memo", "PASS", "Successfully deleted"))

        # ========================================
        # Test 9: Verify deletion
        # ========================================
        print("\n[Test 9] Verify memo no longer exists...")
        try:
            await client.get_memo(created_memo_id)
            print("  [FAIL] ERROR: Memo still exists!")
            test_results.append(("Verify delete", "FAIL", "Memo still exists"))
        except MemosNotFoundError as e:
            print(f"  [PASS] Memo correctly deleted - MemosNotFoundError raised")
            print(f"  Error message: {str(e)}")
            test_results.append(("Verify delete", "PASS", "MemosNotFoundError raised"))
        except MemosAPIError as e:
            print(f"  [PASS] Memo deleted - MemosAPIError (404): {e}")
            test_results.append(("Verify delete", "PASS", "MemosAPIError 404"))
        except Exception as e:
            print(f"  Error type: {type(e).__name__}: {e}")
            test_results.append(("Verify delete", "PASS", f"{type(e).__name__}"))

        # ========================================
        # Test 10: Double delete should fail
        # ========================================
        print("\n[Test 10] Double delete should fail...")
        try:
            await client.delete_memo(created_memo_id)
            print("  [WARN] Double delete succeeded (unexpected)")
            test_results.append(("Double delete", "WARN", "Succeeded unexpectedly"))
        except Exception as e:
            print(f"  [PASS] Double delete correctly failed: {type(e).__name__}")
            test_results.append(("Double delete", "PASS", "Correctly failed"))

    except Exception as e:
        print(f"\n[FAIL] Test failed with error: {e}")
        import traceback
        traceback.print_exc()
        test_results.append(("Error", "FAIL", str(e)))

        # Cleanup: try to delete test memo if it was created
        if created_memo_id:
            try:
                await client.delete_memo(created_memo_id)
                print(f"  Cleanup: Deleted test memo {created_memo_id}")
            except:
                print(f"  Cleanup: Could not delete test memo")

    finally:
        await client.close()

    # ========================================
    # Print Results Summary
    # ========================================
    print("\n" + "=" * 60)
    print("TEST RESULTS SUMMARY")
    print("=" * 60)

    passed = sum(1 for r in test_results if r[1] == "PASS")
    failed = sum(1 for r in test_results if r[1] == "FAIL")
    warned = sum(1 for r in test_results if r[1] == "WARN")

    for test_name, status, detail in test_results:
        icon = "[PASS]" if status == "PASS" else ("[FAIL]" if status == "FAIL" else "[WARN]")
        print(f"{icon} {test_name}: {detail}")

    print("\n" + "-" * 60)
    print(f"Total: {passed} passed, {failed} failed, {warned} warned")
    print("=" * 60)

    return passed, failed


if __name__ == "__main__":
    asyncio.run(test_all_features())