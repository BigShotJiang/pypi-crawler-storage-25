from __future__ import annotations

import typer
from typing import Annotated

from modules import apt as apt_module
from modules import brew as brew_module
from modules import matrix as matrix_module
from modules import npm as npm_module
from modules import docker as docker_module
from modules import fire as fire_module
from modules import rain as rain_module

from rich.console import Console

app = typer.Typer(
    context_settings={"help_option_names": ["-h", "--help"]}
)
console = Console()

@app.command(name="brew")
def brew_cmd(
    action: Annotated[str | None, typer.Argument()] = None,
    packages: Annotated[list[str] | None, typer.Argument()] = None,
    debug: Annotated[bool, typer.Option("--debug")] = False,
) -> None:
    if action not in ["install", "upgrade", "update"] or action is None:
        console.print("[yellow]Usage: workzen brew <install|upgrade|update> [packages][/yellow]")
        return
    brew_module.run(action=action, packages=packages, debug=debug)

@app.command(name="apt")
def apt_cmd(
    action: Annotated[str | None, typer.Argument()] = None,
    packages: Annotated[list[str] | None, typer.Argument()] = None,
    yes: Annotated[bool, typer.Option("--yes", "-y")] = False,
) -> None:
    if action not in ["install", "upgrade", "update"] or action is None:
        console.print("[yellow]Usage: workzen apt <install|upgrade|update> [packages][/yellow]")
        return
    apt_module.run(action=action, packages=packages, yes=yes)

@app.command(name="npm")
def npm_cmd(
    action: Annotated[str | None, typer.Argument()] = None,
    packages: Annotated[list[str] | None, typer.Argument()] = None,
    verbose: Annotated[bool, typer.Option("--verbose")] = False,
) -> None:
    if action not in ["install", "ci", "run"] or action is None:
        console.print("[yellow]Usage: workzen npm <install|ci|run> [packages][/yellow]")
        return
    if action == "run" and not packages:
        console.print("[yellow]Usage: workzen npm run <script>[/yellow]")
        return
    npm_module.run(action=action, packages=packages, verbose=verbose)

@app.command(name="matrix")
def matrix_cmd(
    color: Annotated[str, typer.Option("--color")] = "green",
    speed: Annotated[str, typer.Option("--speed")] = "normal",
) -> None:
    matrix_module.run(color=color, speed=speed)

@app.command(name="docker")
def docker_cmd(
    action: Annotated[str | None, typer.Argument()] = None,
    image: Annotated[str | None, typer.Argument()] = None,
) -> None:
    if action != "pull" or image is None:
        console.print("[yellow]Usage: workzen docker pull <image>[/yellow]")
        return
    docker_module.run(action=action, image=image)

@app.command(name="fire")
def fire_cmd(
    size: Annotated[int, typer.Argument()] = 12,
    height: Annotated[float, typer.Option("--height")] = 1.0,
    intensity: Annotated[float, typer.Option("--intensity")] = 1.0,
) -> None:
    fire_module.run(size=size, height_factor=height, intensity=intensity)

@app.command(name="rain")
def rain_cmd(
    density: Annotated[int, typer.Argument()] = 12,
) -> None:
    rain_module.run(density=density)

if __name__ == "__main__":
    app()