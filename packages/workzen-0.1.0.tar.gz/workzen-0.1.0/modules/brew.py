from __future__ import annotations

import random
import shutil
import time
from dataclasses import dataclass

from rich.console import Console
from rich.console import Group
from rich.live import Live
from rich.progress import Progress, ProgressColumn, Task, TextColumn
from rich.text import Text

console = Console()
USAGE_TEXT = "Usage: workzen brew <install|upgrade|update> [packages]"

TAPS = [
    "homebrew/core",
    "homebrew/cask",
    "homebrew/services",
]

TRANSITION_LOGS = [
    "Resolving next dependency tree...",
    "Checking for outdated formulae...",
    "Refreshing bottle metadata...",
]

BAR_STYLE = "default"
MAX_ACTIVE_DOWNLOADS = 5


@dataclass(frozen=True)
class Formula:
    name: str
    version: str
    bottle_mb: float
    files: int
    steps: list[str]
    cellar_path: str


BASE_FORMULAE = [
    "openssl@3",
    "python@3.12",
    "sqlite",
    "wget",
    "node",
    "git",
    "tmux",
    "neovim",
    "ripgrep",
    "fd",
]


class HashBarColumn(ProgressColumn):
    def __init__(self, console_ref: Console, min_width: int = 12) -> None:
        self.console_ref = console_ref
        self.min_width = min_width
        super().__init__()

    def render(self, task: Task) -> Text:
        total = task.total or 100
        ratio = min(1.0, task.completed / total) if total else 1.0
        percent = f"{ratio * 100:>5.1f}%"
        term_width = shutil.get_terminal_size((120, 30)).columns
        width = max(self.min_width, term_width - len(task.description) - len(percent) - 10)
        filled = min(width, int(ratio * width))
        bar = "#" * filled + " " * (width - filled)
        text = Text(bar, style=BAR_STYLE)
        text.append(f" {percent}", style=BAR_STYLE)
        return text


@dataclass
class DownloadState:
    formula: Formula
    total: float
    completed: float = 0.0
    phase: str = "Fetching"
    stalled_until: float = 0.0
    burst_ticks: int = 0


def _sleep(min_seconds: float = 0.08, max_seconds: float = 0.28) -> None:
    time.sleep(random.uniform(min_seconds, max_seconds))


def _random_version() -> str:
    return (
        f"{random.randint(1, 25)}."
        f"{random.randint(0, 12)}."
        f"{random.randint(0, 9)}"
    )


def _build_formula(name: str) -> Formula:
    version = _random_version()
    digest = f"{random.randint(10**11, 10**12 - 1):x}"
    return Formula(
        name=name,
        version=version,
        bottle_mb=round(random.uniform(4.2, 48.8), 1),
        files=random.randint(12, 64),
        steps=[
            f"Downloading https://ghcr.io/v2/homebrew/core/{name}/manifests/{version}",
            f"Fetching dependency for {name}",
            f"Downloading https://ghcr.io/v2/homebrew/core/{name}/blobs/sha256:{digest}",
        ],
        cellar_path=f"/opt/homebrew/Cellar/{name}/{version}",
    )


def _resolve_formulae(packages: list[str] | None) -> list[Formula]:
    names = packages or random.sample(BASE_FORMULAE, k=random.randint(2, 4))
    return [_build_formula(name) for name in names]


def _print_header() -> None:
    console.print("[bold green]==>[/bold green] Auto-updating Homebrew...")
    _sleep(0.35, 0.55)
    console.print(
        "Adjust how often this is run with "
        "[bold]$HOMEBREW_AUTO_UPDATE_SECS[/bold]."
    )
    console.print(
        "Hide these hints with [bold]$HOMEBREW_NO_ENV_HINTS=1[/bold] "
        "(see [cyan]man brew[/cyan])."
    )
    _sleep()


def _update_taps() -> None:
    for tap in TAPS:
        console.print(f"[bold green]==>[/bold green] Updating {tap}...")
        with console.status(
            f"[green]Fetching objects for {tap}[/green]", spinner="dots"
        ):
            _sleep(0.7, 1.2)
        console.print("Already up-to-date.")
        _sleep()


def _show_outdated() -> None:
    formula_count = random.randint(8, 19)
    cask_count = random.randint(2, 6)
    console.print(
        f"Updated {formula_count} taps ({formula_count * 83} files, "
        f"{random.randint(2, 8)}MB)."
    )
    console.print(
        f"[bold yellow]Warning:[/bold yellow] {formula_count} outdated formulae and "
        f"{cask_count} outdated casks installed."
    )
    _sleep(0.3, 0.5)


def _debug_log(formula: Formula, action: str) -> None:
    debug_lines = [
        f"/opt/homebrew/Library/Homebrew/brew.rb (Formulary::FormulaNamespace{formula.name.title().replace('@', '')})",
        "HOMEBREW_CACHE=/Users/demo/Library/Caches/Homebrew",
        f"ARGV: --debug {action} {formula.name}",
        f"Formula fully qualified name: homebrew/core/{formula.name}",
    ]
    for line in debug_lines:
        console.print(f"[dim]{line}[/dim]")
        _sleep(0.04, 0.09)


def _run_update_cycle() -> None:
    console.print("[bold green]==>[/bold green] Updating Homebrew...")
    _sleep(0.3, 0.55)
    taps = random.sample(
        [
            "homebrew/core",
            "homebrew/cask",
            "homebrew/services",
            "azure/azd",
            "mongodb/brew",
            "hashicorp/tap",
        ],
        k=random.randint(3, 4),
    )
    if len(taps) == 3:
        tap_text = f"{taps[0]}, {taps[1]} and {taps[2]}"
    else:
        tap_text = ", ".join(taps[:-1]) + f" and {taps[-1]}"
    console.print(f"Updated {len(taps)} taps ({tap_text}).")

    console.print("[bold green]==>[/bold green] New Formulae")
    new_formulae = random.sample(
        [
            ("copilot-language-server", "Language Server Protocol server for GitHub Copilot"),
            ("uvx", "Instant Python tool execution wrapper"),
            ("zoxide", "Smarter cd command"),
            ("gitmux", "tmux statusline Git integration"),
        ],
        k=random.randint(1, 2),
    )
    for name, desc in new_formulae:
        console.print(f"{name}: {desc}")
        _sleep(0.05, 0.12)

    console.print("[bold green]==>[/bold green] Outdated Formulae")
    outdated = random.sample(
        ["deno", "neovim", "fd", "ripgrep", "node", "git", "wget"],
        k=random.randint(1, 3),
    )
    for formula in outdated:
        console.print(formula)
        _sleep(0.05, 0.12)

    console.print()
    if len(outdated) == 1:
        console.print("You have 1 outdated formula installed.")
    else:
        console.print(f"You have {len(outdated)} outdated formulae installed.")
    console.print("You can upgrade them with [bold]brew upgrade[/bold]")
    console.print("or list them with [bold]brew outdated[/bold].")


def _render_brew_line(label: str, completed: float, total: float) -> Text:
    ratio = min(1.0, completed / total) if total else 1.0
    percent = f"{ratio * 100:>5.1f}%"
    terminal_width = shutil.get_terminal_size((120, 30)).columns
    label_width = 24
    bar_width = max(16, terminal_width - label_width - len(percent) - 3)
    trimmed = label[: label_width - 1] + "…" if len(label) > label_width else label
    filled = min(bar_width, int(ratio * bar_width))
    text = Text(f"{trimmed:<{label_width}}", style="default")
    text.append(" ")
    text.append("#" * filled + " " * (bar_width - filled), style=BAR_STYLE)
    text.append(" ")
    text.append(percent, style=BAR_STYLE)
    return text


def _advance_download(state: DownloadState) -> None:
    now = time.time()
    ratio = state.completed / state.total if state.total else 1.0
    if state.stalled_until > now:
        return

    if state.burst_ticks > 0:
        advance = random.uniform(4.2, 8.6)
        state.burst_ticks -= 1
    else:
        advance = random.uniform(0.9, 2.8)
        if 0.2 <= ratio <= 0.45 or 0.55 <= ratio <= 0.75:
            if random.random() < 0.10:
                state.stalled_until = now + random.uniform(0.35, 0.9)
                state.burst_ticks = random.randint(1, 3)
                return

    state.completed = min(state.total, state.completed + advance)
    if state.completed >= state.total * 0.35:
        state.phase = "Downloading"


def _parallel_fetch(formulae: list[Formula]) -> None:
    pending = [DownloadState(formula=formula, total=float(random.randint(90, 150))) for formula in formulae]
    active: list[DownloadState] = []

    with Live(console=console, refresh_per_second=18, transient=True) as live:
        while pending or active:
            while pending and len(active) < MAX_ACTIVE_DOWNLOADS:
                active.append(pending.pop(0))

            rendered_lines = []
            for state in list(active):
                _advance_download(state)
                label = f"{state.phase} {state.formula.name} bottle"
                rendered_lines.append(_render_brew_line(label, state.completed, state.total))
                if state.completed >= state.total:
                    active.remove(state)

            if rendered_lines:
                live.update(Group(*rendered_lines), refresh=True)
            time.sleep(random.uniform(0.07, 0.13))


def _pour_formula(formula: Formula, action: str, debug: bool) -> None:
    bottle_size = f"{formula.bottle_mb:.1f}MB"
    verb = "Installing" if action == "install" else "Upgrading"

    console.print(f"[bold green]==>[/bold green] {verb} [bold]{formula.name}[/bold]")
    console.print(
        f"  {random.randint(1, 9)}.{random.randint(0, 9)}.{random.randint(0, 9)} "
        f"-> {formula.version}"
    )
    _sleep()

    if debug:
        _debug_log(formula, action)

    with Progress(
        TextColumn("[progress.description]{task.description}"),
        HashBarColumn(console),
        console=console,
        transient=True,
    ) as progress:
        for step in formula.steps:
            task = progress.add_task(step, total=100)
            while not progress.finished:
                progress.advance(task, random.uniform(1.0, 4.0))
                time.sleep(random.uniform(0.05, 0.11))
            progress.remove_task(task)

        task = progress.add_task(f"Pouring {formula.name}--{formula.version}", total=100)
        while not progress.finished:
            progress.advance(task, random.uniform(0.9, 3.5))
            time.sleep(random.uniform(0.05, 0.11))

    console.print(
        f"[bold green]==>[/bold green] Pouring [cyan]{formula.name}--{formula.version}.arm64_sequoia.bottle.tar.gz[/cyan]"
    )
    console.print(
        f"[bold green]==>[/bold green] Caveats\n"
        f"{formula.name} installed to [bold]{formula.cellar_path}[/bold]"
    )
    console.print(
        f"[bold green]==>[/bold green] Summary\n"
        f"🍺  {formula.cellar_path}: {formula.files} files, {bottle_size}"
    )
    _sleep(0.25, 0.45)


def _cleanup() -> None:
    with console.status("[green]Running brew cleanup...[/green]", spinner="line"):
        _sleep(0.8, 1.4)
    console.print("Removing: /Users/demo/Library/Caches/Homebrew/downloads/... (4 files)")
    console.print("Pruned 2 symbolic links and 3 directories from /opt/homebrew")
    _sleep(0.20, 0.35)


def _transition_to_next_cycle() -> None:
    delay = random.uniform(0.8, 1.8)
    messages = random.sample(TRANSITION_LOGS, k=random.randint(1, min(2, len(TRANSITION_LOGS))))
    pause = delay / len(messages)
    for message in messages:
        console.print(message)
        time.sleep(pause)


def run(action: str, packages: list[str] | None = None, debug: bool = False) -> None:
    """Execute an endless fake Homebrew session."""
    if action not in {"install", "upgrade", "update"}:
        console.print(USAGE_TEXT, style="yellow", markup=False)
        return
    if action == "install" and not packages:
        console.print("Usage: workzen brew install <packages...>", style="yellow", markup=False)
        return

    random.seed()
    first_cycle = True
    initial_packages = packages

    try:
        if action == "update":
            _run_update_cycle()
            return

        while True:

            formulae = _resolve_formulae(initial_packages if first_cycle else None)
            if first_cycle:
                _print_header()
                _update_taps()
                _show_outdated()

            _parallel_fetch(formulae)
            for formula in formulae:
                _pour_formula(formula, action=action, debug=debug)

            _cleanup()
            if action == "install":
                return
            _transition_to_next_cycle()
            first_cycle = False
            initial_packages = None
    except KeyboardInterrupt:
        console.print("\n[yellow]Aborted.[/yellow]")
