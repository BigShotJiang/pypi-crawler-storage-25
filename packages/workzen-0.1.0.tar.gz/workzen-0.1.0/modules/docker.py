from __future__ import annotations

import random
import time
from dataclasses import dataclass

from rich.console import Console
from rich.progress import (
    BarColumn,
    DownloadColumn,
    Progress,
    TaskProgressColumn,
    TextColumn,
    TimeRemainingColumn,
    TransferSpeedColumn,
)

console = Console()
USAGE_TEXT = "Usage: workzen docker pull <image>"
IMAGE_POOL = [
    "nginx",
    "redis",
    "postgres:15-alpine",
    "node:20-slim",
    "python:3.12-bullseye",
    "mariadb",
    "rabbitmq",
    "memcached",
    "alpine",
    "debian:bookworm-slim",
    "ubuntu",
    "golang:1.23",
]


@dataclass
class Layer:
    digest: str
    download_total: int
    extract_total: int
    downloaded: float = 0.0
    extracted: float = 0.0
    status: str = "Waiting"
    download_speed: float = 0.0
    extract_speed: float = 0.0
    task_id: int | None = None


def _random_hex(length: int) -> str:
    return "".join(random.choice("0123456789abcdef") for _ in range(length))


def _normalize_image_name(image: str) -> tuple[str, str]:
    if ":" in image:
        display_image = image
        tag = image.rsplit(":", 1)[1]
    else:
        display_image = f"{image}:latest"
        tag = "latest"

    if "/" not in image:
        source_name = f"library/{image.split(':', 1)[0]}"
    else:
        source_name = image.split(":", 1)[0]

    return display_image, f"{tag}: Pulling from {source_name}"


def _build_layers() -> list[Layer]:
    layers: list[Layer] = []
    for _ in range(random.randint(5, 12)):
        layers.append(
            Layer(
                digest=_random_hex(12),
                download_total=random.randint(2_000_000, 18_000_000),
                extract_total=random.randint(1_500_000, 12_000_000),
                download_speed=random.uniform(2.5, 9.5) * 1024 * 1024,
                extract_speed=random.uniform(4.0, 14.0) * 1024 * 1024,
            )
        )
    return layers


def _activate_waiting_layers(
    layers: list[Layer],
    max_downloads: int,
    max_extracts: int,
    progress: Progress,
) -> None:
    active_downloads = sum(layer.status == "Downloading" for layer in layers)
    active_extracts = sum(layer.status == "Extracting" for layer in layers)

    for layer in layers:
        if active_downloads >= max_downloads:
            break
        if layer.status == "Waiting":
            layer.status = "Downloading"
            progress.update(
                layer.task_id,
                description=f"{layer.digest}: Downloading",
                total=layer.download_total,
                completed=layer.downloaded,
            )
            active_downloads += 1

    for layer in layers:
        if active_extracts >= max_extracts:
            break
        if layer.status == "Ready to extract":
            layer.status = "Extracting"
            progress.update(
                layer.task_id,
                description=f"{layer.digest}: Extracting",
                total=layer.extract_total,
                completed=layer.extracted,
            )
            active_extracts += 1


def _update_layer_states(layers: list[Layer], progress: Progress) -> None:
    for layer in layers:
        if layer.status == "Downloading":
            speed = layer.download_speed * random.uniform(0.75, 1.18)
            advance = speed * random.uniform(0.04, 0.10)
            layer.downloaded = min(layer.download_total, layer.downloaded + advance)
            progress.update(layer.task_id, completed=layer.downloaded)
            if layer.downloaded >= layer.download_total:
                layer.status = "Ready to extract"
                progress.update(
                    layer.task_id,
                    description=f"{layer.digest}: Download complete",
                    completed=layer.download_total,
                    total=layer.download_total,
                )

        elif layer.status == "Extracting":
            speed = layer.extract_speed * random.uniform(0.82, 1.20)
            advance = speed * random.uniform(0.05, 0.11)
            layer.extracted = min(layer.extract_total, layer.extracted + advance)
            progress.update(layer.task_id, completed=layer.extracted)
            if layer.extracted >= layer.extract_total:
                layer.status = "Pull complete"
                progress.update(
                    layer.task_id,
                    description=f"{layer.digest}: Pull complete",
                    total=1,
                    completed=1,
                )


def _run_pull_cycle(image: str) -> str:
    display_image, pull_line = _normalize_image_name(image)
    layers = _build_layers()
    max_downloads = random.randint(3, 4)
    max_extracts = random.randint(2, 3)

    if ":" not in image:
        console.print("Using default tag: latest")
    console.print(pull_line)

    with Progress(
        TextColumn("[progress.description]{task.description}"),
        BarColumn(bar_width=24, complete_style="cyan"),
        TaskProgressColumn(),
        DownloadColumn(binary_units=True),
        TransferSpeedColumn(),
        TimeRemainingColumn(),
        console=console,
        transient=True,
    ) as progress:
        for layer in layers:
            layer.task_id = progress.add_task(
                f"{layer.digest}: Waiting",
                total=1,
                completed=0,
            )

        while any(layer.status != "Pull complete" for layer in layers):
            _activate_waiting_layers(
                layers,
                max_downloads=max_downloads,
                max_extracts=max_extracts,
                progress=progress,
            )
            _update_layer_states(layers, progress)
            time.sleep(random.uniform(0.05, 0.10))

    for layer in layers:
        console.print(f"{layer.digest}: Pull complete")
    console.print(f"Digest: sha256:{_random_hex(64)}")
    console.print(f"Status: Downloaded newer image for {display_image}")
    return display_image


def _transition_to_next_cycle() -> None:
    delay = random.uniform(2.0, 4.0)
    messages = [
        "Verifying layer checksums...",
        "Registering image to local daemon...",
        "Pulling next base image...",
    ]
    pause = delay / len(messages)
    for message in messages:
        console.print(message)
        time.sleep(pause)


def run(action: str, image: str) -> None:
    """Execute an endless fake docker pull session."""
    if action != "pull" or not image:
        console.print(USAGE_TEXT, style="yellow", markup=False)
        return

    random.seed()
    first_cycle = True
    current_image = image

    try:
        while True:
            _run_pull_cycle(current_image)
            _transition_to_next_cycle()
            first_cycle = False
            current_image = random.choice(IMAGE_POOL) if not first_cycle else current_image
    except KeyboardInterrupt:
        console.print("\n[yellow]Aborted.[/yellow]")
