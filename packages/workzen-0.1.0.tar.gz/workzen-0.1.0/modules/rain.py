from __future__ import annotations

import random
import shutil
import time
from dataclasses import dataclass

from rich.console import Console, Group
from rich.live import Live
from rich.text import Text

console = Console()

DROP_STYLES = {
    "far": ("'", "#5a708a"),
    "mid": ("╎", "#78a7d8"),
    "near": ("│", "#b8d8ff"),
}
SPLASH_STYLES = {
    1: "#6f95bf",
    2: "#9dc8ff",
    3: "#d7ecff",
}


@dataclass
class Drop:
    x: float
    y: float
    speed: float
    length: int
    depth: str
    target_y: float


@dataclass
class Splash:
    x: float
    y: float
    vx: float
    vy: float
    ttl: int
    char: str
    brightness: int


def _spawn_drops(
    drops: list[Drop],
    width: int,
    height: int,
    floor_top: int,
    density: int,
) -> None:
    spawn_count = max(1, density // 2)
    if density > 120:
        spawn_count += (density - 120) // 8

    for _ in range(spawn_count):
        if random.random() > min(0.98, density / 50):
            continue
        depth = random.choices(["far", "mid", "near"], weights=[3, 4, 2])[0]
        speed = {"far": 0.55, "mid": 0.95, "near": 1.35}[depth] + random.uniform(-0.08, 0.18)
        length = {"far": 1, "mid": 2, "near": 3}[depth]
        floor_depth = max(1.0, (height - 1) - floor_top)
        impact_bias = 1.0 - (random.random() ** 2.4)
        target_y = floor_top + floor_depth * impact_bias

        drops.append(
            Drop(
                x=random.uniform(0, max(1, width - 1)),
                y=random.uniform(-height * 0.5, -2),
                speed=speed,
                length=length,
                depth=depth,
                target_y=target_y,
            )
        )


def _update_drops(
    drops: list[Drop],
    splashes: list[Splash],
    width: int,
    density: int,
) -> None:
    survivors: list[Drop] = []
    for drop in drops:
        drift = 0.12 if drop.depth == "near" else 0.06 if drop.depth == "mid" else 0.03
        previous_y = drop.y
        drop.x += drift
        drop.y += drop.speed

        if previous_y < drop.target_y <= drop.y:
            base_splash = 2 if drop.depth == "far" else 3 if drop.depth == "mid" else 4
            splash_count = min(6, base_splash + (1 if density >= 80 else 0))
            brightness = 3 if drop.depth == "near" else 2 if drop.depth == "mid" else 1

            for _ in range(splash_count):
                splashes.append(
                    Splash(
                        x=drop.x + random.uniform(-1.2, 1.2),
                        y=drop.target_y,
                        vx=random.uniform(-0.8, 0.8),
                        vy=random.uniform(-0.8, -0.2),
                        ttl=random.randint(4, 8),
                        char=random.choice(["·", "'", "`", "."]),
                        brightness=brightness,
                    )
                )
        elif drop.y < drop.target_y and -2 <= drop.x < width + 2:
            survivors.append(drop)
    drops[:] = survivors


def _update_splashes(splashes: list[Splash], width: int, height: int) -> None:
    survivors: list[Splash] = []
    for splash in splashes:
        splash.x += splash.vx
        if splash.ttl < 8:
            splash.y += splash.vy
            splash.vy += 0.20
        splash.ttl -= 1
        if splash.ttl > 0 and 0 <= splash.x < width and splash.y < height:
            survivors.append(splash)
    splashes[:] = survivors


def _render_frame(
    drops: list[Drop],
    splashes: list[Splash],
    width: int,
    height: int,
    floor_top: int,
) -> Group:
    drop_cells: dict[tuple[int, int], tuple[str, str]] = {}
    for drop in drops:
        char, color = DROP_STYLES[drop.depth]
        for tail in range(drop.length):
            row = int(drop.y) - tail
            column = int(drop.x)
            if 0 <= row < height and 0 <= column < width:
                drop_cells[(column, row)] = (char, color)

    splash_cells: dict[tuple[int, int], tuple[str, int]] = {}
    for splash in splashes:
        column = int(round(splash.x))
        row = int(round(splash.y))
        if 0 <= row < height and 0 <= column < width:
            existing = splash_cells.get((column, row))
            if existing is None or splash.brightness >= existing[1]:
                splash_cells[(column, row)] = (splash.char, splash.brightness)

    lines: list[Text] = []
    for row in range(height):
        line = Text()
        for column in range(width):
            splash = splash_cells.get((column, row))
            if splash:
                splash_char, brightness = splash
                line.append(splash_char, style=SPLASH_STYLES[brightness])
                continue

            drop_cell = drop_cells.get((column, row))
            if drop_cell:
                char, color = drop_cell
                line.append(char, style=color)
                continue

            line.append(" ")
        lines.append(line)

    return Group(*lines)


def run(density: int = 30) -> None:
    density = max(1, min(300, density))
    random.seed()
    drops: list[Drop] = []
    splashes: list[Splash] = []

    try:
        with Live(console=console, screen=True, auto_refresh=False) as live:
            while True:
                frame_start = time.perf_counter()
                size = shutil.get_terminal_size((80, 24))
                width = max(24, size.columns)
                height = max(16, size.lines - 1)
                floor_top = int(height * 0.75)

                _spawn_drops(drops, width, height, floor_top, density)
                _update_drops(drops, splashes, width, density)
                _update_splashes(splashes, width, height)

                live.update(
                    _render_frame(drops, splashes, width, height, floor_top),
                    refresh=True,
                )

                elapsed = time.perf_counter() - frame_start
                time.sleep(max(0, (1 / 28) - elapsed))
    except KeyboardInterrupt:
        console.print("[yellow]Aborted.[/yellow]")