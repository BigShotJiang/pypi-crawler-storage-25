from __future__ import annotations

import getpass
import random
import shutil
import time
from dataclasses import dataclass

from rich.console import Console, Group
from rich.live import Live
from rich.progress import (
    BarColumn,
    Progress,
    SpinnerColumn,
    TaskProgressColumn,
    TextColumn,
)
from rich.text import Text

console = Console()
DISTRO = "noble"
USAGE_TEXT = "Usage: workzen apt <install|upgrade|update> [packages]"


@dataclass(frozen=True)
class Package:
    name: str
    old_version: str
    new_version: str
    archive_kb: int
    installed_kb: int
    repository: str
    section: str = "main"
    is_new: bool = False


PACKAGES = [
    Package(
        name="ubuntu-keyring",
        old_version="2023.11.28.1",
        new_version="2025.03.18",
        archive_kb=48,
        installed_kb=192,
        repository="http://archive.ubuntu.com/ubuntu",
        is_new=True,
    ),
    Package(
        name="libssl3t64",
        old_version="3.0.13-0ubuntu3.4",
        new_version="3.0.13-0ubuntu3.6",
        archive_kb=1930,
        installed_kb=214,
        repository="http://security.ubuntu.com/ubuntu",
    ),
    Package(
        name="openssl",
        old_version="3.0.13-0ubuntu3.4",
        new_version="3.0.13-0ubuntu3.6",
        archive_kb=1292,
        installed_kb=88,
        repository="http://security.ubuntu.com/ubuntu",
    ),
    Package(
        name="curl",
        old_version="8.5.0-2ubuntu10.4",
        new_version="8.5.0-2ubuntu10.6",
        archive_kb=316,
        installed_kb=24,
        repository="http://archive.ubuntu.com/ubuntu",
    ),
    Package(
        name="git",
        old_version="1:2.43.0-1ubuntu7.1",
        new_version="1:2.43.0-1ubuntu7.3",
        archive_kb=3478,
        installed_kb=1152,
        repository="http://archive.ubuntu.com/ubuntu",
        section="main",
    ),
    Package(
        name="openssh-client",
        old_version="1:9.6p1-3ubuntu13.5",
        new_version="1:9.6p1-3ubuntu13.8",
        archive_kb=904,
        installed_kb=112,
        repository="http://security.ubuntu.com/ubuntu",
    ),
    Package(
        name="python3.12",
        old_version="3.12.3-1ubuntu0.5",
        new_version="3.12.3-1ubuntu0.7",
        archive_kb=682,
        installed_kb=45,
        repository="http://archive.ubuntu.com/ubuntu",
    ),
    Package(
        name="python3.12-minimal",
        old_version="3.12.3-1ubuntu0.5",
        new_version="3.12.3-1ubuntu0.7",
        archive_kb=2314,
        installed_kb=170,
        repository="http://archive.ubuntu.com/ubuntu",
    ),
]

TRIGGERS = [
    "man-db (2.12.0-4build2)",
    "libc-bin (2.39-0ubuntu8.6)",
    "install-info (7.1-3build2)",
]

DEFAULT_INSTALL_TARGETS = [
    "neovim",
    "tmux",
    "ripgrep",
    "fd",
    "htop",
    "jq",
    "mosh",
]

TRANSITION_LOGS = [
    "Scanning additional repositories...",
    "Reading extended state information...",
    "Checking mirror freshness...",
]


def _sleep(min_seconds: float = 0.03, max_seconds: float = 0.10) -> None:
    time.sleep(random.uniform(min_seconds, max_seconds))


def _random_version() -> str:
    return (
        f"{random.randint(1, 9)}:"
        f"{random.randint(0, 4)}.{random.randint(0, 99)}."
        f"{random.randint(0, 9)}-0ubuntu{random.randint(1, 9)}.{random.randint(1, 9)}"
    )


def _build_user_package(name: str) -> Package:
    repository = random.choice(
        ["http://archive.ubuntu.com/ubuntu", "http://security.ubuntu.com/ubuntu"]
    )
    return Package(
        name=name,
        old_version=f"0.{random.randint(8, 9)}.{random.randint(0, 9)}-0ubuntu1",
        new_version=_random_version(),
        archive_kb=random.randint(120, 4200),
        installed_kb=random.randint(40, 1600),
        repository=repository,
        section=random.choice(["main", "universe"]),
        is_new=random.choice([True, False]),
    )


def _resolve_packages(action: str, packages: list[str] | None) -> list[Package]:
    if action == "install":
        package_names = packages if packages else random.sample(DEFAULT_INSTALL_TARGETS, k=2)
        return [_build_user_package(name) for name in package_names]
    return PACKAGES


def _sudo_prompt() -> None:
    getpass.getpass(prompt=f"[sudo] password for {getpass.getuser()}: ")
    _sleep(0.12, 0.20)


def _confirm_continue() -> bool:
    response = input("Do you want to continue? [Y/n] ").strip().lower()
    return response in {"", "y", "yes"}


def _print_repo_activity() -> None:
    lines = [
        "Hit:1 http://archive.ubuntu.com/ubuntu noble InRelease",
        "Get:2 http://archive.ubuntu.com/ubuntu noble-updates InRelease [126 kB]",
        "Get:3 http://archive.ubuntu.com/ubuntu noble-backports InRelease [126 kB]",
        "Get:4 http://security.ubuntu.com/ubuntu noble-security InRelease [129 kB]",
        "Get:5 http://archive.ubuntu.com/ubuntu noble-updates/main arm64 Packages [1,284 kB]",
        "Get:6 http://archive.ubuntu.com/ubuntu noble-updates/main Translation-en [284 kB]",
        "Get:7 http://archive.ubuntu.com/ubuntu noble-updates/universe arm64 Packages [1,009 kB]",
        "Get:8 http://archive.ubuntu.com/ubuntu noble-backports/main arm64 Packages [6,844 B]",
        "Fetched 2,964 kB in 1s (2,871 kB/s)",
    ]
    for line in lines:
        console.print(line)
        _sleep(0.05, 0.18)


def _animate_percent_line(label: str, step_range: tuple[int, int]) -> None:
    progress_value = 0
    while progress_value < 100:
        console.print(f"{label}... {progress_value:>3}%", end="\r")
        progress_value = min(100, progress_value + random.randint(*step_range))
        _sleep(0.04, 0.10)
    console.print(f"{label}... Done{' ' * 8}")


def _print_upgrade_summary(packages: list[Package], action: str, should_prompt: bool) -> None:
    new_packages = [pkg for pkg in packages if pkg.is_new]
    upgrades = [pkg for pkg in packages if not pkg.is_new]
    total_archive_kb = sum(pkg.archive_kb for pkg in packages)
    extra_disk_kb = sum(pkg.installed_kb for pkg in packages)

    console.print("Reading package lists... Done")
    console.print("Building dependency tree... Done")
    console.print("Reading state information... Done")
    console.print("Calculating upgrade... Done")
    console.print("The following packages were automatically installed and are no longer required:")
    console.print("  linux-modules-6.8.0-52-generic linux-tools-6.8.0-52")
    console.print("Use 'sudo apt autoremove' to remove them.")

    if new_packages:
        console.print("The following NEW packages will be installed:")
        console.print(f"  {' '.join(pkg.name for pkg in new_packages)}")

    header = "The following packages will be installed or upgraded:"
    label = "requested"
    if action == "upgrade":
        header = "The following packages will be upgraded:"
        label = "upgraded"
    console.print(header)
    console.print(f"  {' '.join(pkg.name for pkg in upgrades or packages)}")
    console.print(
        f"{len(upgrades)} {label}, {len(new_packages)} newly installed, "
        "0 to remove and 0 not upgraded."
    )
    console.print(f"Need to get {total_archive_kb / 1024:.1f} MB of archives.")
    console.print(
        "After this operation, "
        f"{extra_disk_kb:,} kB of additional disk space will be used."
    )
    _sleep(0.20, 0.35)

    if should_prompt and not _confirm_continue():
        raise KeyboardInterrupt


def _render_download_view(logs: list[str], total_bytes: int, downloaded_bytes: float) -> Group:
    size = shutil.get_terminal_size((90, 24))
    height = max(8, size.lines - 5)
    visible_logs = logs[-height:]
    log_render = [Text(line) for line in visible_logs]

    if total_bytes == 0:
        percent = 100
        bar_fill = 40
    else:
        percent = int((downloaded_bytes / total_bytes) * 100)
        bar_fill = int((downloaded_bytes / total_bytes) * 40)
    bar = f"[{'#' * bar_fill}{'.' * (40 - bar_fill)}]"
    summary = Text(
        f"Progress: [{percent:>3}%] {bar} "
        f"{downloaded_bytes / 1024 / 1024:>5.1f}/{total_bytes / 1024 / 1024:>5.1f} MiB"
    )
    return Group(*log_render, Text(""), summary)


def _download_packages(packages: list[Package], action: str) -> None:
    total_bytes = sum(pkg.archive_kb * 1024 for pkg in packages)
    speeds = {pkg.name: random.uniform(4.5, 22.0) * 1024 * 1024 for pkg in packages}
    downloaded = {pkg.name: 0.0 for pkg in packages}
    completed: set[str] = set()
    logs = ["Waiting for package indexes..."]

    with Live(
        _render_download_view(logs, total_bytes, 0),
        console=console,
        refresh_per_second=20,
        transient=True,
    ) as live:
        while len(completed) < len(packages):
            for index, package in enumerate(packages, start=1):
                if package.name in completed:
                    continue

                total_package_bytes = package.archive_kb * 1024
                advance = speeds[package.name] * random.uniform(0.045, 0.10)
                downloaded[package.name] = min(
                    total_package_bytes,
                    downloaded[package.name] + advance,
                )

                if downloaded[package.name] >= total_package_bytes:
                    completed.add(package.name)
                    suite = f"{DISTRO}-updates" if action != "install" else DISTRO
                    logs.append(
                        f"Get:{index} {package.repository} {suite}/{package.section} "
                        f"arm64 {package.name} {package.new_version} "
                        f"[{package.archive_kb:,} kB]"
                    )
                    logs.append(
                        f"Fetched {package.archive_kb:,} kB for {package.name} at "
                        f"{speeds[package.name] / 1024 / 1024:.1f} MB/s"
                    )

            total_downloaded = sum(downloaded.values())
            live.update(_render_download_view(logs, total_bytes, total_downloaded), refresh=True)
            time.sleep(random.uniform(0.05, 0.10))

    for line in logs[-(len(packages) * 2) :]:
        if line != "Waiting for package indexes...":
            console.print(line)


def _run_package_step(label: str) -> None:
    with Progress(
        SpinnerColumn(style="green"),
        TextColumn("[progress.description]{task.description}"),
        BarColumn(bar_width=24, complete_style="green"),
        TaskProgressColumn(),
        console=console,
        transient=True,
    ) as progress:
        task = progress.add_task(label, total=100)
        completed = 0
        while completed < 100:
            completed = min(100, completed + random.randint(9, 22))
            progress.update(task, completed=completed)
            time.sleep(random.uniform(0.04, 0.10))


def _install_packages(packages: list[Package]) -> None:
    console.print("debconf: delaying package configuration, since apt-utils is not installed")
    for package in packages:
        if package.is_new:
            console.print(f"Selecting previously unselected package {package.name}.")

        console.print(
            f"Preparing to unpack .../{package.name}_{package.new_version}_arm64.deb ..."
        )
        _run_package_step(f"Unpacking {package.name}")
        if package.is_new:
            console.print(f"Unpacking {package.name} ({package.new_version}) ...")
        else:
            console.print(
                f"Unpacking {package.name} ({package.new_version}) "
                f"over ({package.old_version}) ..."
            )

        _run_package_step(f"Setting up {package.name}")
        console.print(f"Setting up {package.name} ({package.new_version}) ...")
        _sleep(0.04, 0.09)


def _finalize() -> None:
    for trigger in TRIGGERS:
        console.print(f"Processing triggers for {trigger} ...")
        _sleep(0.08, 0.16)

    _animate_percent_line("Scanning processes", (14, 24))
    _animate_percent_line("Scanning linux images", (18, 28))
    console.print("No services need to be restarted.")
    console.print("No containers need to be restarted.")
    console.print("No user sessions are running outdated binaries.")


def _transition_to_next_cycle() -> None:
    delay = random.uniform(0.8, 2.0)
    messages = random.sample(TRANSITION_LOGS, k=random.randint(1, min(2, len(TRANSITION_LOGS))))
    pause = delay / len(messages)
    for message in messages:
        console.print(message)
        time.sleep(pause)


def _run_update_cycle() -> None:
    _print_repo_activity()
    _animate_percent_line("Reading package lists", (7, 15))
    _animate_percent_line("Building dependency tree", (11, 21))
    _animate_percent_line("Reading state information", (10, 19))


def run(
    action: str,
    packages: list[str] | None = None,
    yes: bool = False,
) -> None:
    """Execute an endless fake apt session."""
    if action not in {"install", "upgrade", "update"}:
        console.print(USAGE_TEXT, style="yellow", markup=False)
        return
    if action == "install" and not packages:
        console.print("Usage: workzen apt install <packages...>", style="yellow", markup=False)
        return

    random.seed()
    first_cycle = True
    current_packages = packages

    try:
        _sudo_prompt()

        while True:
            if action == "update":
                _run_update_cycle()
                _transition_to_next_cycle()
                first_cycle = False
                continue

            selected_packages = _resolve_packages(action, current_packages if first_cycle else None)
            _print_repo_activity()
            _animate_percent_line("Reading package lists", (7, 15))
            _animate_percent_line("Building dependency tree", (11, 21))
            _animate_percent_line("Reading state information", (10, 19))
            _print_upgrade_summary(
                selected_packages,
                action=action,
                should_prompt=(first_cycle and not yes),
            )
            _download_packages(selected_packages, action=action)
            _install_packages(selected_packages)
            _finalize()
            if action == "install":
                return
            _transition_to_next_cycle()

            first_cycle = False
            current_packages = None
    except (KeyboardInterrupt, EOFError):
        console.print("\n[yellow]Aborted.[/yellow]")
