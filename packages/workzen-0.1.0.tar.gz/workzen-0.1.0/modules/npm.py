from __future__ import annotations

import random
import time
from dataclasses import dataclass

from rich.console import Console
from rich.progress import (
    BarColumn,
    Progress,
    SpinnerColumn,
    TaskProgressColumn,
    TextColumn,
    TimeElapsedColumn,
)

console = Console()
USAGE_TEXT = "Usage: workzen npm <install|ci|run> [packages]"
RUN_USAGE_TEXT = "Usage: workzen npm run <script>"


@dataclass(frozen=True)
class NpmPackage:
    name: str
    version: str
    dependency_count: int


DEFAULT_PACKAGES = [
    "react",
    "vite",
    "typescript",
    "eslint",
    "prettier",
    "tsx",
    "zod",
    "tailwindcss",
    "vitest",
]

RUN_SCRIPTS = ["build", "dev", "lint", "test", "typecheck"]

DEPRECATED_WARNINGS = [
    "npm WARN deprecated inflight@1.0.6: This module is not supported, and leaks memory.",
    "npm WARN deprecated glob@7.2.3: Glob versions prior to v9 are no longer supported.",
    "npm WARN deprecated rimraf@3.0.2: Rimraf versions prior to v4 are no longer supported.",
]


def _sleep(min_seconds: float = 0.03, max_seconds: float = 0.10) -> None:
    time.sleep(random.uniform(min_seconds, max_seconds))


def _random_version() -> str:
    return f"{random.randint(0, 9)}.{random.randint(0, 12)}.{random.randint(0, 9)}"


def _resolve_packages(packages: list[str] | None) -> list[NpmPackage]:
    names = packages or random.sample(DEFAULT_PACKAGES, k=random.randint(3, 5))
    return [
        NpmPackage(
            name=name,
            version=_random_version(),
            dependency_count=random.randint(18, 90),
        )
        for name in names
    ]


def _emit_verbose_log(topic: str) -> None:
    verbose_lines = [
        f"npm http fetch GET 200 https://registry.npmjs.org/{topic} 243ms (cache miss)",
        f"npm sill idealTree buildDeps {topic}",
        f"npm timing idealTree:node_modules/{topic} Completed in {random.randint(40, 280)}ms",
        f"npm timing reifyNode:node_modules/{topic} Completed in {random.randint(25, 180)}ms",
    ]
    for line in verbose_lines:
        console.print(line)
        _sleep(0.02, 0.05)


def _maybe_warn() -> None:
    if random.random() < 0.32:
        console.print(f"[yellow]{random.choice(DEPRECATED_WARNINGS)}[/yellow]")
        _sleep(0.04, 0.08)


def _run_install_like_cycle(selected: list[NpmPackage], verbose: bool, action: str) -> None:
    top_level_count = len(selected)
    added_packages = sum(pkg.dependency_count for pkg in selected) + top_level_count
    audited_packages = added_packages + random.randint(0, 4)
    reify_label = "reify:node_modules: timing reify:loadTrees"
    if action == "ci":
        reify_label = "reify:node_modules: timing arborist:ctor"

    with Progress(
        SpinnerColumn(style="green"),
        TextColumn("[progress.description]{task.description}"),
        BarColumn(bar_width=32, complete_style="green"),
        TaskProgressColumn(),
        TimeElapsedColumn(),
        console=console,
        transient=True,
    ) as progress:
        ideal_tree = progress.add_task(
            "idealTree:lib: sill idealTree buildDeps",
            total=100,
        )
        reify = progress.add_task(reify_label, total=100)
        audit = progress.add_task("audit:registry: sill audit bulk request", total=100)

        while not all(progress.tasks[task_id].finished for task_id in [ideal_tree, reify, audit]):
            progress.advance(ideal_tree, random.randint(5, 14))
            if progress.tasks[ideal_tree].completed > 28:
                progress.advance(reify, random.randint(4, 10))
            if progress.tasks[reify].completed > 42:
                progress.advance(audit, random.randint(4, 11))

            if random.random() < 0.18:
                pkg = random.choice(selected)
                console.print(
                    f"idealTree:{pkg.name}: sill fetch manifest {pkg.name}@^{pkg.version}"
                )
                _maybe_warn()
                if verbose:
                    _emit_verbose_log(pkg.name)

            time.sleep(random.uniform(0.06, 0.14))

    for pkg in selected:
        console.print(f"+ {pkg.name}@{pkg.version}")
        if verbose:
            _emit_verbose_log(pkg.name)
        _maybe_warn()

    elapsed = random.randint(4, 8)
    funding_count = random.randint(max(2, top_level_count), max(8, top_level_count * 4))
    console.print("")
    console.print(
        f"added {added_packages} packages, and audited {audited_packages} packages in {elapsed}s"
    )
    console.print("")
    console.print(f"{funding_count} packages are looking for funding")
    console.print("  run `npm fund` for details")
    console.print("")
    console.print("found 0 vulnerabilities")


def _run_script_cycle(script: str, verbose: bool) -> None:
    console.print(f"> app@0.0.0 {script}")
    console.print(f"> {script} --color")

    with Progress(
        SpinnerColumn(style="cyan"),
        TextColumn("[progress.description]{task.description}"),
        BarColumn(bar_width=32, complete_style="cyan"),
        TaskProgressColumn(),
        TimeElapsedColumn(),
        console=console,
        transient=True,
    ) as progress:
        resolve = progress.add_task(f"npm run {script}: resolving workspace", total=100)
        execute = progress.add_task(f"npm run {script}: executing hooks", total=100)

        while not all(progress.tasks[task_id].finished for task_id in [resolve, execute]):
            progress.advance(resolve, random.randint(5, 14))
            if progress.tasks[resolve].completed > 35:
                progress.advance(execute, random.randint(4, 12))

            if random.random() < 0.22:
                console.print(f"npm timing lifecycle:{script} Completed in {random.randint(90, 640)}ms")
                if verbose:
                    _emit_verbose_log(script)
            time.sleep(random.uniform(0.06, 0.14))

    console.print(f"{script} completed successfully")


def _transition_to_next_cycle() -> None:
    delay = random.uniform(0.8, 1.8)
    console.print("Looking for fundings...")
    time.sleep(delay * 0.4)
    console.print("Resolving peer dependencies...")
    time.sleep(delay * 0.6)


def run(action: str, packages: list[str] | None = None, verbose: bool = False) -> None:
    """Execute an endless fake npm session."""
    if action not in {"install", "ci", "run"}:
        console.print(USAGE_TEXT, style="yellow", markup=False)
        return
    if action == "install" and not packages:
        console.print("Usage: workzen npm install <packages...>", style="yellow", markup=False)
        return
    if action == "run" and not packages:
        console.print(RUN_USAGE_TEXT, style="yellow", markup=False)
        return

    random.seed()
    first_cycle = True
    current_packages = packages

    try:
        console.print("npm info using npm@10.8.2")
        console.print("npm info using node@22.14.0")
        console.print("")

        while True:
            if action == "run":
                script = current_packages[0] if first_cycle and current_packages else random.choice(RUN_SCRIPTS)
                _run_script_cycle(script, verbose=verbose)
            else:
                selected = _resolve_packages(current_packages if first_cycle else None)
                _run_install_like_cycle(selected, verbose=verbose, action=action)
                if action == "install":
                    return

            _transition_to_next_cycle()
            first_cycle = False
            current_packages = None
    except KeyboardInterrupt:
        console.print("\n[yellow]Aborted.[/yellow]")
