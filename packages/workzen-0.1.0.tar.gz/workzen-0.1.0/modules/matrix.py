from __future__ import annotations

import random
import shutil
import time
from dataclasses import dataclass

from rich.console import Console, Group
from rich.live import Live
from rich.text import Text

console = Console()

HALFWIDTH_KATAKANA = "".join(chr(i) for i in range(0xFF66, 0xFF9E))
GLYPHS = f"0123456789abcdefghijklmnopqrstuvwxyz<>[]{{}}#@$%&*{HALFWIDTH_KATAKANA}"
COLOR_PALETTES = {
    "green": ("#d8ffd8", "#00ff41", "#00a000", "#003b00"),
    "red": ("#ffd8d8", "#ff4b4b", "#b00000", "#3b0000"),
    "blue": ("#d8ecff", "#52a8ff", "#0066cc", "#001f4d"),
    "yellow": ("#fff7d6", "#ffd84d", "#b38f00", "#4d3b00"),
    "magenta": ("#ffd8ff", "#ff5cff", "#a000a0", "#3d003d"),
    "cyan": ("#d8ffff", "#4dffff", "#0099a8", "#00363b"),
    "white": ("#ffffff", "#d9d9d9", "#8c8c8c", "#3d3d3d"),
}
SPEED_PRESETS = {
    "slow": {"fps": 12, "speed_range": (0.18, 0.55), "cooldown": (7, 22)},
    "normal": {"fps": 20, "speed_range": (0.45, 1.35), "cooldown": (3, 18)},
    "fast": {"fps": 32, "speed_range": (0.95, 2.40), "cooldown": (1, 10)},
}


@dataclass
class Stream:
    head: float
    speed: float
    length: int
    cooldown: int
    density: float


def _new_stream(height: int, speed: str) -> Stream:
    preset = SPEED_PRESETS[speed]
    min_length = max(8, height // 3)
    max_length = max(min_length + 4, height - 2)
    return Stream(
        head=random.uniform(-height, height),
        speed=random.uniform(*preset["speed_range"]),
        length=random.randint(min_length, max_length),
        cooldown=random.randint(0, preset["cooldown"][1]),
        density=random.uniform(0.82, 0.98),
    )


def _sync_streams(streams: list[Stream], width: int, height: int, speed: str) -> list[Stream]:
    if width <= 0:
        return []
    if len(streams) < width:
        streams.extend(_new_stream(height, speed) for _ in range(width - len(streams)))
    elif len(streams) > width:
        streams = streams[:width]
    return streams


def _advance_streams(streams: list[Stream], height: int, speed: str) -> None:
    preset = SPEED_PRESETS[speed]
    for stream in streams:
        if stream.cooldown > 0:
            stream.cooldown -= 1
            continue

        stream.head += stream.speed

        if stream.head - stream.length > height + random.uniform(0, 6):
            replacement = _new_stream(height, speed)
            stream.head = replacement.head
            stream.speed = replacement.speed
            stream.length = replacement.length
            stream.cooldown = random.randint(*preset["cooldown"])
            stream.density = replacement.density


def _style_for_distance(distance: float, length: int, palette: tuple[str, str, str, str]) -> str:
    head, bright, mid, dark = palette
    if distance < 0.9:
        return head
    if distance < 2.2:
        return bright
    if distance < max(4, length * 0.45):
        return mid
    return dark


def _render_frame(
    streams: list[Stream],
    width: int,
    height: int,
    palette: tuple[str, str, str, str],
) -> Group:
    lines: list[Text] = []
    for row in range(height):
        line = Text()
        for column in range(width):
            stream = streams[column]
            distance = stream.head - row
            if 0 <= distance < stream.length and random.random() <= stream.density:
                line.append(
                    random.choice(GLYPHS),
                    style=_style_for_distance(distance, stream.length, palette),
                )
            else:
                line.append(" ")
        lines.append(line)
    return Group(*lines)


def run(color: str = "green", speed: str = "normal") -> None:
    """Render a Matrix-style digital rain effect until interrupted."""
    random.seed()
    streams: list[Stream] = []
    palette = COLOR_PALETTES.get(color, COLOR_PALETTES["green"])
    preset = SPEED_PRESETS.get(speed, SPEED_PRESETS["normal"])

    try:
        with Live(console=console, screen=True, auto_refresh=False) as live:
            while True:
                frame_start = time.perf_counter()
                size = shutil.get_terminal_size((80, 24))
                width = max(12, size.columns)
                height = max(8, size.lines - 1)

                streams = _sync_streams(streams, width, height, speed)
                _advance_streams(streams, height, speed)
                live.update(_render_frame(streams, width, height, palette), refresh=True)

                elapsed = time.perf_counter() - frame_start
                time.sleep(max(0, (1 / preset["fps"]) - elapsed))
    except KeyboardInterrupt:
        console.print(f"[{color}]Aborted.[/{color}]")
