from __future__ import annotations

import random
import shutil
import time
from dataclasses import dataclass

from rich.console import Console, Group
from rich.live import Live
from rich.text import Text

console = Console()

# Colors for the fire (from dark to light)
FIRE_PALETTE = [
    "#000000", "#1a0500", "#330a00", "#4d0f00", "#661400", "#801a00", 
    "#992400", "#b33300", "#cc4400", "#e65c00", "#ff7300", "#ff8c00", 
    "#ffa600", "#ffbf00", "#ffd900", "#fff200", "#ffffff"
]
MAX_HEAT = len(FIRE_PALETTE) - 1

# Colors for the wooden logs
LOG_PALETTE = ["#2b1608", "#4a2810", "#6a3b17", "#8f5524"]

# Return a block character based on heat level
def get_fire_char(heat: int) -> str:
    if heat <= 0: return " "
    if heat < 3: return "·"
    if heat < 6: return "░"
    if heat < 10: return "▒"
    if heat < 14: return "▓"
    return "█"

# Represents a flying spark
@dataclass
class Ember:
    x: float
    y: float
    vx: float
    vy: float
    ttl: int
    color: str

# Create an empty 2D grid
def _make_buffer(width: int, height: int) -> list[list[int]]:
    return [[0 for _ in range(width)] for _ in range(height)]

# Ignite the bottom of the fire
def _seed_fire(buffer: list[list[int]], width: int, height: int, flame_floor: int, size: int, intensity_factor: float) -> None:
    base_row = height - flame_floor - 1
    center = width // 2
    
    for col in range(width):
        dist = abs(col - center)
        if dist <= size:
            # Calculate base heat based on distance from center and apply intensity factor
            intensity = (1.0 - (dist / max(1, size)) ** 1.5) * intensity_factor
            heat = int(MAX_HEAT * intensity)
            heat = max(0, min(MAX_HEAT, heat))
            
            # Add random flickering
            if random.random() < 0.5:
                heat = max(0, heat - random.randint(0, 3))
            buffer[base_row][col] = heat
        else:
            buffer[base_row][col] = 0

# Move the fire upwards and let it cool down
def _propagate_fire(buffer: list[list[int]], width: int, height: int, flame_floor: int, height_factor: float) -> None:
    base_row = height - flame_floor - 1
    center = width // 2
    
    for col in range(width):
        for row in range(base_row, 0, -1):
            src_heat = buffer[row][col]
            if src_heat == 0:
                buffer[row - 1][col] = 0
            else:
                drift = random.randint(-1, 1)
                
                # Make the fire shape look like a cone
                if col < center and random.random() < 0.25: drift = 1
                if col > center and random.random() < 0.25: drift = -1
                
                dst_col = max(0, min(width - 1, col + drift))
                
                # Cool down the fire as it goes up
                decay = random.randint(0, 1)
                
                # Adjust cooling threshold based on height_factor (higher factor = taller flames)
                cooling_threshold = base_row * max(0.0, (0.6 - (0.3 * height_factor)))
                
                if row < cooling_threshold:
                    decay += 1
                    
                buffer[row - 1][dst_col] = max(0, src_heat - decay)

# Create and move flying sparks
def _update_embers(embers: list[Ember], width: int, height: int, flame_floor: int, size: int) -> None:
    base_row = height - flame_floor - 1
    center = width // 2
    spawn_spread = max(2, size // 2)
    
    # Randomly spawn new sparks within the fire's width
    if random.random() < 0.4: 
        embers.append(
            Ember(
                x=random.uniform(center - spawn_spread, center + spawn_spread),
                y=float(base_row),
                vx=random.uniform(-0.4, 0.4),
                vy=random.uniform(-0.6, -0.2),
                ttl=random.randint(15, 25),
                color=random.choice(["#ffaa00", "#ffcc00", "#ffffff"]),
            )
        )

    survivors: list[Ember] = []
    for ember in embers:
        ember.x += ember.vx
        ember.y += ember.vy
        ember.vy -= 0.02
        
        # Add random left/right movement
        if random.random() < 0.2:
            ember.vx += random.uniform(-0.2, 0.2)
            
        ember.ttl -= 1
        
        # Keep sparks that are still alive and inside the screen
        if ember.ttl > 0 and 0 <= ember.x < width and 0 <= ember.y < height:
            survivors.append(ember)
    embers[:] = survivors

# Draw the wooden logs at the bottom
def _render_logs(width: int, flame_floor: int, size: int) -> list[Text]:
    lines = [Text(" " * width) for _ in range(flame_floor)]
    center = width // 2
    base_row = flame_floor - 1
    
    layouts = [
        (-8, base_row, "/", LOG_PALETTE[2]),
        (-5, base_row - 1, "/", LOG_PALETTE[1]),
        (-2, base_row - 2, "/", LOG_PALETTE[0]),
        (0, base_row, "X", LOG_PALETTE[3]),
        (2, base_row - 2, "\\", LOG_PALETTE[0]),
        (5, base_row - 1, "\\", LOG_PALETTE[1]),
        (8, base_row, "\\", LOG_PALETTE[2]),
    ]
    
    filler_map = {
        "/": ["=", "-", "/", "_", "="],
        "\\": ["=", "_", "\\", "-", "="],
        "X": ["=", "x", "X", "-", "="],
    }

    # Dynamically filter logs so they don't stick out if the fire size is very small
    valid_layouts = [l for l in layouts if abs(l[0]) <= max(2, size)]

    # Draw log shapes
    for offset, row, glyph, color in valid_layouts:
        actual_row = max(0, min(flame_floor - 1, row))
        actual_col = center + offset
        for spread in range(-2, 3):
            col = actual_col + spread
            if 0 <= col < width:
                char = filler_map[glyph][spread + 2]
                lines[actual_row] = lines[actual_row].copy()
                lines[actual_row].plain = (
                    lines[actual_row].plain[:col] + char + lines[actual_row].plain[col + 1 :]
                )
                lines[actual_row].stylize(color, col, min(width, col + 1))

    # Add glowing red embers under the logs
    glow_row = max(0, flame_floor - 1)
    glow_spread = max(2, size - 2)
    for col in range(max(0, center - glow_spread), min(width, center + glow_spread + 1)):
        if random.random() < 0.4 and lines[glow_row].plain[col] in " _-=":
            lines[glow_row] = lines[glow_row].copy()
            lines[glow_row].plain = (
                lines[glow_row].plain[:col] + "·" + lines[glow_row].plain[col + 1 :]
            )
            lines[glow_row].stylize(random.choice(["#ff3300", "#ff6600", "#ff9d1c"]), col, min(width, col + 1))

    return lines

# Combine fire, sparks, and logs into one screen frame
def _render_frame(buffer: list[list[int]], embers: list[Ember], logs: list[Text], width: int, height: int, flame_floor: int) -> Group:
    lines: list[Text] = []
    flame_height = height - flame_floor
    ember_lookup = {(int(round(e.x)), int(round(e.y))): e.color for e in embers}

    for row in range(flame_height):
        line = Text()
        for col in range(width):
            heat = buffer[row][col]
            ember_color = ember_lookup.get((col, row))
            
            # Draw sparks
            if ember_color and heat < 10:
                line.append("*", style=ember_color)
            # Draw fire
            elif heat > 0:
                char = get_fire_char(heat)
                color = FIRE_PALETTE[min(heat, MAX_HEAT)]
                line.append(char, style=color)
            # Draw empty space
            else:
                line.append(" ")
        lines.append(line)
        
    lines.extend(logs)
    return Group(*lines)

def run(size: int = 12, height_factor: float = 1.0, intensity: float = 1.0) -> None:
    """
    Render a cozy, thick campfire for terminal meditation.
    
    Args:
        size: Width/radius of the fire base (default: 12)
        height_factor: Multiplier for how high the flames reach (default: 1.0)
        intensity: Heat multiplier to make the fire brighter or dimmer (default: 1.0)
    """
    random.seed()
    embers: list[Ember] = []

    try:
        # Start the live terminal rendering
        with Live(console=console, screen=True, auto_refresh=False) as live:
            buffer: list[list[int]] = []
            logs: list[Text] = []
            previous_size = (0, 0)

            # Main animation loop
            while True:
                frame_start = time.perf_counter()
                
                # Get current terminal size
                term_size = shutil.get_terminal_size((80, 24))
                width = max(24, term_size.columns)
                height = max(16, term_size.lines - 1)
                flame_floor = max(3, min(4, height // 6))

                # Recreate grid if terminal was resized
                if previous_size != (width, height):
                    buffer = _make_buffer(width, height)
                    logs = _render_logs(width, flame_floor, size)
                    previous_size = (width, height)

                # Update all fire components using the provided parameters
                _seed_fire(buffer, width, height, flame_floor, size, intensity)
                _propagate_fire(buffer, width, height, flame_floor, height_factor)
                _update_embers(embers, width, height, flame_floor, size)
                
                # Draw the frame
                live.update(_render_frame(buffer, embers, logs, width, height, flame_floor), refresh=True)

                # Control the frame rate (fps)
                elapsed = time.perf_counter() - frame_start
                time.sleep(max(0, (1 / 28) - elapsed))
                
    except KeyboardInterrupt:
        # Stop smoothly when user presses Ctrl+C
        console.print("[yellow]Aborted.[/yellow]")