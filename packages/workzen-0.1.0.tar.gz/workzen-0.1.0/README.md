# workzen

*Do nothing. Look incredible.*

`workzen` simulates the kind of terminal activity that makes people walk past your desk and think "wow, they must be handling something critical right now."

They are not. You are not. And yet, here you both are.

## Install

```bash
pip install workzen
```

## Usage

```bash
workzen -h
```

That's it. The tool explains itself. You've got this.

## How to stop

`Ctrl+C`

No judgment.

## Disclaimer

`workzen` does not install anything, fix anything, or make you better at your job.

Results may vary. Promotions not guaranteed. Probably.
