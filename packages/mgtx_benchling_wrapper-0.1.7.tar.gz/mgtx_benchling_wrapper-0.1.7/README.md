# mgtx-benchling-wrapper
A wrapper of the Benchling API SDK with common functions and workflows used at MGTX DSC.

## Installation 🚀
You can install this package using:
```
pip install mgtx-benchling-wrapper
```

## Quickstart 🚩
After creating an app on your Benchling tenant, create a config.yaml file in your repo.
The following is an example of the contents of a config.yaml

Note: You might want to keep the app client secret separated from your main code.
```
BenchlingCredentials:
  benchling_url: 'https://mytenant.benchling.com'
  benchling_access_token: 'https://mytenant.benchling.com/api/v2/token'
  app_client_id: 'your-app-client-id'
  app_client_secret: 'your-app-client-secret'
AssaySchema:
  schema_id: "schema_api_id"
Project:
  project_id: "project_api_id"
```
The following is an example of the use of the assay_results_ingestion workflow.
```
import yaml
from mgtx_benchling_wrapper import BenchlingContext
from mgtx_benchling_wrapper import BenchlingWrapperFacade
from mgtx_benchling_wrapper import AssayResultIngestionWorkflow
from mgtx_benchling_wrapper.utils.logger import get_logger

logger = get_logger(__name__,
                        file_log_level='DEBUG',
                        console_log_level='INFO', )

def config():
    with open("tests/config/test_config.yml") as f:
        return yaml.safe_load(f)

#create the benchling context        
ctx = BenchlingContext(
        base_url=config()['BenchlingCredentials']['benchling_url'],
        client_id=config()['BenchlingCredentials']['app_client_id'],
        client_secret=config()['BenchlingCredentials']['app_client_secret'],
        token_url=config()['BenchlingCredentials']['benchling_access_token'],
    )    

#initialize the wrapper
wrapper = BenchlingWrapperFacade(ctx.benchling())

#retrieve assay_schema_id
schema_id = config()['AssaySchema']['schema_id']

#retrieve project_id
project_id = config()['Project']['project_id']

#initiate results ingestion workflow
results_ingestion = AssayResultIngestionWorkflow(wrapper)

#ingest results on benchling
list_missing_entities = results_ingestion.assay_results_ingestion(
        [dataframe_to_ingest],
        schema_id,
        project_id,
        unique_identifiers =['assay_run_id', 'sample_id']
        )       
```
Another example is accessing a Benchling assay results schema metadata.
```
#run the following after initializing the wrapper

from mgtx_benchling_wrapper import SchemaHandler

schema_handler = SchemaHandler(wrapper)

schema_definition = schema_handler.build_schema_definition(schema_id, 'assay_results_schema')
```
Another example is using a method from the wrapper directly to build your own workflow.
```
#run the following after initializing the wrapper

list_custom_entities = wrapper.custom_entities.get_by_names(['your-entity-1', 'your-entity-2'])

for custom_entity in list_custom_entities:
    name = wrapper.custom_entities.name()
    print(f"the name of the custom entity {custom_entity} is {name}.")
```
To release and publish run the following on gitBash to initialize the GitHub Action for
publishing the package.
```
git tag v0.1.#
git push origin v0.1.#
```
Logs are by default enabled for developer use on the console. To save logs, an environment variable is needed.
Create the environment variable on your repo in a .env file as such, and then make sure to load it.
```
APP_DEBUG_LOGS=1
```
