from typing import Callable

from benchling_sdk.benchling import Benchling
from benchling_api_client.benchling_client import BenchlingApiClient
from benchling_sdk.helpers.retry_helpers import RetryStrategy


# -----------------------------
# Configuration defaults
# -----------------------------

DEFAULT_TIMEOUT_SECONDS = 180
MAX_RETRIES = 10
BACKOFF_FACTOR = 2.0

# -----------------------------
# Client decorators
# -----------------------------

def with_default_timeout(client: BenchlingApiClient) -> BenchlingApiClient:
    """
    Apply default timeout to all Benchling API calls.
    """
    return client.with_timeout(DEFAULT_TIMEOUT_SECONDS)


# -----------------------------
# Factory
# -----------------------------

def with_backoff_timeout():
    return RetryStrategy(
        max_tries=MAX_RETRIES,
        backoff_factor=BACKOFF_FACTOR
    )

def create_benchling_client(
    *,
    url: str,
    auth,
    client_decorator: Callable[[BenchlingApiClient], BenchlingApiClient] = with_default_timeout,
) -> Benchling:
    """
    Factory for creating a Benchling SDK client.

    Args:
        url (str):
            Benchling tenant base URL (e.g. https://acme.benchling.com)

        auth:
            Authentication method compatible with Benchling SDK
            (e.g. ClientCredentialsOAuth2)

        client_decorator (callable):
            Optional decorator to customize the underlying API client
            (timeouts, retries, logging, etc.)

    Returns:
        Benchling:
            Configured Benchling SDK client
    """
    return Benchling(
        url=url,
        auth_method=auth,
        client_decorator=client_decorator,
        retry_strategy=with_backoff_timeout(),
    )
