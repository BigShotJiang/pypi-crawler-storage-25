from .wrapper.facade import BenchlingWrapperFacade
from .context.benchling_context import BenchlingContext
from .workflows.assays_result_ingestion import AssayResultIngestionWorkflow
from .workflows.handlers.schema_handler import SchemaHandler

__all__ = [
    "BenchlingWrapperFacade",
    "BenchlingContext",
    "AssayResultIngestionWorkflow",
    "SchemaHandler",
]

from importlib.metadata import version, PackageNotFoundError

try:
    __version__ = version("mgtx_benchling_wrapper")
except PackageNotFoundError:
    __version__ = "0.0.0"