from benchling_sdk.errors import BenchlingError
from mgtx_benchling_wrapper.wrapper.facade import BenchlingWrapperFacade
from mgtx_benchling_wrapper.workflows.models.types import ValidationResult
from .exceptions import (
    ValidationError,
    InvalidSchemaId,
    InvalidProjectId,
    InvalidEntryName,
    TooManyEntriesWithSameName,
    TableIdNotFound,
    InvalidResultsIngestionSettings,
)
from benchling_sdk.models import (
    Entry
)
from typing import Optional, Tuple, List
from mgtx_benchling_wrapper.utils.logger import get_logger

logger = get_logger(__name__,
                    file_log_level='DEBUG',
                    console_log_level='DEBUG',)

class ApiParametersValidation:
    """
    Validates input parameters to the workflow definition.

    Does NOT:
    - Does not validate DataFrame inputs
    - Mutate input DataFrames
    - Perform entity resolution
    - Transform data
    """

    def __init__(self, wrapper: BenchlingWrapperFacade):
        self._wrapper = wrapper

    def validation(
            self,
            schema_id: str,
            project_id: str,
            entry_name: str = None,
            commit_in_transaction: bool = True,
            strict : bool = True
    ) -> Tuple[ValidationResult, Optional[str]]:

        errors: List[ValidationError] = []
        warnings: List[str] = []

        #validate schema_id
        try:
            schema_type = self._validate_schema_id(schema_id)
            warnings.append(f"{schema_id} is of type {schema_type}")
        except ValidationError as e:
            if strict:
                raise
            errors.append(e)

        #validate project_id
        try:
            self._validate_project_id(project_id)
        except ValidationError as e:
            if strict:
                raise
            errors.append(e)

        #validate commit transaction
        try:
            self._validate_commit_in_transaction(entry_name, commit_in_transaction)
        except ValidationError as e:
            if strict:
                raise
            errors.append(e)

        #validate entry_name
        if entry_name is not None:
            try:
                list_entries = self._get_list_entry_name(entry_name)
                self._validate_entry_name(entry_name, list_entries)
            except ValidationError as e:
                if strict:
                    raise
                errors.append(e)

            #get table id
            table_id = self._get_table_id(entry_name, list_entries, schema_id)
        else:
            table_id = None

        is_valid = len(errors) == 0
        return ValidationResult(is_valid=is_valid, errors=errors, warnings=warnings), table_id


    def _validate_schema_id(self, schema_id) -> str:
        try:
            self._wrapper.schemas.get_assay_result_schema_by_id(schema_id)
            return 'assay schema'
        except BenchlingError:
            raise InvalidSchemaId(schema_id)

    def _validate_project_id(self, project_id: str) -> None:
        try:
            self._wrapper.projects.get_project_by_id(project_id)
        except BenchlingError:
            raise InvalidProjectId(project_id)

    def _validate_entry_name(self, entry_name: str, list_entries: list[Entry]) -> None:
        if len(list_entries)==0:
            raise InvalidEntryName(entry_name)
        elif len(list_entries)>1:
            raise TooManyEntriesWithSameName(entry_name, list_entries)

    def _get_list_entry_name(self, entry_name: str) -> List[Entry]:
        pageiter = self._wrapper.entry.get_by_name(entry_name)
        list_entries = self._wrapper.entry.list_entries(pageiter)
        return list_entries

    def _get_table_id(self, entry_name: str, list_entries: list[Entry], schema_id: str) -> str:
        dict_entry_to_results_table_id = self._wrapper.entry.get_dict_results_table_id(list_entries)

        if len(dict_entry_to_results_table_id) > 0:
            for entry in dict_entry_to_results_table_id:
                for table in dict_entry_to_results_table_id[entry]:
                    if dict_entry_to_results_table_id[entry][table] == schema_id:
                        table_id = table
                        return table_id
        else:
            raise TableIdNotFound(entry_name, schema_id)

    def _validate_commit_in_transaction(self, entry_name: str, commit_in_transaction:bool) -> None:
        if entry_name is not None and commit_in_transaction:
            raise InvalidResultsIngestionSettings(commit_in_transaction, entry_name)
        elif entry_name is None and not commit_in_transaction:
            raise InvalidResultsIngestionSettings(commit_in_transaction, entry_name)




