from typing import List, Dict, Any

class ValidationError(Exception):
    """Base exception for validation errors"""
    def __init__(self, message: str, context: Dict[str, Any] = None):
        super().__init__(message)
        self.context = context or {}
        self.message = message


class SchemaValidationError(ValidationError):
    """Raised when DataFrame doesn't match schema requirements"""
    pass

class ProjectValidationError(ValidationError):
    """Raised when project id does not match requirements"""
    pass

class EntryValidationError(ValidationError):
    """Raised when entry name does not match requirements"""
    pass

class ArchiveSettingsValidationError(ValidationError):
    """Raised when entry name does not match requirements"""
    pass

class BlobSettingsValidationError(ValidationError):
    """Raised when blob id does not match requirements"""
    pass

class IngestionResultsValidation(ValidationError):
    """Raised when details for ingestion do not pass requirements"""
    pass

class ColumnValidationError(ValidationError):
    """Raised when column validation fails"""
    def __init__(self, column: str, message: str, invalid_values: List[Any] = None):
        super().__init__(message, {"column": column, "invalid_values": invalid_values})
        self.column = column
        self.invalid_values = invalid_values or []


class RequiredColumnMissingError(SchemaValidationError):
    """Raised when required column is missing"""
    def __init__(self, column: str):
        super().__init__(
            f"Required column '{column}' is missing from DataFrame",
            {"column": column, "error_type": "missing_required"}
        )


class EmptyRequiredColumnError(SchemaValidationError):
    """Raised when required column is empty"""
    def __init__(self, column: str):
        super().__init__(
            f"Required column '{column}' is empty",
            {"column": column, "error_type": "empty_required"}
        )


class InvalidDataTypeError(ColumnValidationError):
    """Raised when value doesn't match expected type"""
    def __init__(self, column: str, expected_type: str, invalid_values: List[Any]):
        super().__init__(
            column,
            f"Column '{column}' contains values that don't match expected type '{expected_type}'",
            invalid_values
        )
        self.expected_type = expected_type

class InvalidColumnError(ColumnValidationError):
    """Raised when specified column is not a column in the schema"""
    def __init__(self, column: str, invalid_values: List[Any] = None):
        super().__init__(
            column,
            f"column '{column}' is not a valid name.",
            invalid_values
        )

class NotAnyEntityColumn(ColumnValidationError):
    """Raised when specified column is not a column in the schema"""
    def __init__(self, column: str, invalid_values: List[Any] = None):
        super().__init__(
            column,
            f"Column {column} is not of type AnyEntity and is associated to schema {invalid_values}. Do not include in dict_variable_to_entity_type.",
            invalid_values
        )

class EmptyCompareOnList(ArchiveSettingsValidationError):
    """Raised when compare_on is provided but is empty"""
    def __init__(self):
        super().__init__(
            f"compare_on list is provided but is empty. Set to None",
        )
class InvalidSchemaName(SchemaValidationError):
    def __init__(self, column: str, schema: str):
        super().__init__(
            f"Invalid schema: '{schema}' for column '{column}'",
            {"column": column, "error_type": "invalid_column"}
        )

class InvalidEntityType(SchemaValidationError):
    """Raised when restricted entity type is invalid"""
    def __init__(self, value_name: str, column: str, list_allowed_entities: list[str]):
        super().__init__(
            f"Entity {value_name} in {column} is not of type {list_allowed_entities}'",
            {"column": column, "error_type": "invalid_entity_type"}
        )

class InvalidIdentifier(SchemaValidationError):
    """Raised when specified identifier column does not exist in schema or is not a link"""
    def __init__(self, column: str, schema_id: str):
        super().__init__(
            f"Column {column} is not a valid identifier for schema id {schema_id}'",
            {"column": column, "error_type": "invalid_identifier"}
        )

class NoUniqueIdentifiersProvided(SchemaValidationError):
    """Raised when specified identifier column does not exist in schema or is not a link"""
    def __init__(self, schema_id: str):
        super().__init__(
            f"No unique identifiers provided.",
            {"schema": schema_id, "error_type": "invalid_identifier"}
        )

class InvalidSchemaId(SchemaValidationError):
    """Raised when schema id can't be found on benchling or there are incorrect permissions"""
    def __init__(self, schema_id: str):
        super().__init__(
            f"Could not find {schema_id}. Check the assay schema id and your permissions.'",
            {"schema": schema_id, "error_type": "invalid_schema_id"}
        )

class InvalidProjectId(ProjectValidationError):
    """Raised when project id can't be found on benchling or there are incorrect permissions"""
    def __init__(self, project_id: str):
        super().__init__(
            f"Could not find {project_id}. Check the project id and your permissions.'",
            {"project": project_id, "error_type": "invalid_project_id"}
        )

class InvalidEntryName(EntryValidationError):
    """Raised when entry name can't be found on benchling"""
    def __init__(self, entry_name: str):
        super().__init__(
            f"Could not find {entry_name}.'",
            {"entry_name": entry_name, "error_type": "invalid_entry_name"}
        )

class TooManyEntriesWithSameName(EntryValidationError):
    """Raised when more than one entry is found with the same name"""
    def __init__(self, entry_name: str, invalid_values: List[Any] = None):
        super().__init__(
            f"{len(invalid_values)} entries found with name {entry_name}.",
            invalid_values
        )

class TableIdNotFound(EntryValidationError):
    """Raised when table does not match schema id"""
    def __init__(self, entry_name: str, schema_id: str):
        super().__init__(
            f"No table of schema id '{schema_id}' found in '{entry_name}'.",
            {"entry_name": entry_name, "schema_id": schema_id, "error_type": "invalid_table_id"}
        )

class InvalidArchiveSettings(ArchiveSettingsValidationError):
    """Raised when archive settings are invalid"""
    def __init__(self, archive: bool, compare_on: list[str]):
        super().__init__(
            f"archive is set to {archive} and compare_on is set to '{compare_on}'. compare_on can't be provided when"
            f"archive is set to True. Exiting code.",
            {"archive": archive, 'compare_on': compare_on, "error_type": "invalid_archive_settings"}
        )

class InvalidBlobType(BlobSettingsValidationError):
    """Raised when blob type is not supported"""
    def __init__(self, blob_type: str):
        super().__init__(
            f"blob type {blob_type} not supported.",
            {"blob_type": blob_type, "error_type": "invalid_blob_type"}
        )

class InvalidResultsIngestionSettings(IngestionResultsValidation):
    """Raised when commit transction is true and entry name is provided"""
    def __init__(self, commit_transaction: bool, entry_name: str):
        super().__init__(
            f"Cannot commit results in transaction when sending results to tables. "
            f"Set commit transaction to False when entry name is provided.",
            {"commit_transaction": commit_transaction, 'entry_name': entry_name, "error_type": "invalid_ingestion_settings"}
        )