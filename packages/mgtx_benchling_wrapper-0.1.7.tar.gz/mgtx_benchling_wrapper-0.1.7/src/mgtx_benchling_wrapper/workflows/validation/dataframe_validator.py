import pandas as pd
import numpy as np
from typing import List
import datetime
from mgtx_benchling_wrapper.utils.datetime_parser import parse_datetime
from mgtx_benchling_wrapper.workflows.models.types import FieldType, SchemaDefinition, ValidationResult
from .exceptions import (
    ValidationError,
    RequiredColumnMissingError,
    EmptyRequiredColumnError,
    InvalidDataTypeError,
    InvalidColumnError
)
from mgtx_benchling_wrapper.utils.logger import get_logger

logger = get_logger(__name__,
                    file_log_level='DEBUG',
                    console_log_level='DEBUG',)

class DataFrameValidator:
    """
    Validates DataFrames against Benchling schema definitions.

    Responsibilities:
    - Schema compliance validation
    - Data type validation
    - Required field validation
    - Value range validation

    Does NOT:
    - Mutate input DataFrames
    - Perform entity resolution
    - Transform data
    """

    def __init__(self, schema: SchemaDefinition):
        self.schema = schema
        self._link_types = {FieldType.ENTITY_LINK, FieldType.MIXTURE_LINK, FieldType.STORAGE_LINK}

    def validate(self, df: pd.DataFrame, strict: bool = True) -> ValidationResult:
        """
        Validate DataFrame against schema.

        Args:
            df: DataFrame to validate (not modified)
            strict: If True, raise on first error. If False, collect all errors.

        Returns:
            ValidationResult with errors and warnings

        Raises:
            ValidationError: If strict=True and validation fails
        """
        errors: List[ValidationError] = []
        warnings: List[str] = []

        # validate columns in dict_list_entity_schemas are valid columns in schema
        try:
            self._validate_column_schema(df)
        except ValidationError as e:
            if strict:
                raise
            errors.append(e)

        # Validate column presence and content
        try:
            self._validate_columns(df)
        except ValidationError as e:
            if strict:
                raise
            errors.append(e)

        # Validate data types
        try:
            self._validate_column_type(df)
        except ValidationError as e:
            if strict:
                raise
            errors.append(e)

        is_valid = len(errors) == 0
        return ValidationResult(is_valid=is_valid, errors=errors, warnings=warnings)

    def _validate_column_schema(self, df: pd.DataFrame) -> None:
        for column in df.columns:
            if column not in self.schema['variable_to_type'].keys():
                raise InvalidColumnError(column)
            return

    def _validate_columns(self, df: pd.DataFrame) -> None:
        """Validate individual column presence and emptiness."""
        for column, is_required in self.schema['variable_to_required'].items():
            if column not in df.columns:
                if is_required:
                    raise RequiredColumnMissingError(column)
                return

            # Check if column is entirely null
            if df[column].isnull().all():
                if is_required:
                    raise EmptyRequiredColumnError(column)
                else:
                    logger.debug(f"Optional column '{column}' is empty")

    def _validate_column_type(self, df: pd.DataFrame) -> None:
        """
        Validate column values match expected type.

        Skips validation for link types (entity_link, etc.) as they're validated
        during entity resolution.
        """
        for column, field_type in self.schema['variable_to_type'].items():
            if column not in df.columns:
                continue  # Already caught in schema validation
            # Skip link types - they're validated separately
            if field_type in self._link_types or field_type == FieldType.DROPDOWN:
                continue

            # Get legal text options if available
            legal_text = self.schema['variable_to_legal_text'].get(column, [])

            # Get non-null values
            values = df[column].dropna()

            if len(values) == 0:
                continue  # All null is OK if not required

            # Validate based on type
            invalid_values = []

            if field_type == FieldType.TEXT:
                invalid_values = self._validate_text_values(values, legal_text)
            elif field_type == FieldType.INTEGER:
                invalid_values = self._validate_integer_values(values, legal_text)
            elif field_type == FieldType.FLOAT:
                invalid_values = self._validate_float_values(values, legal_text)
            elif field_type == FieldType.DATETIME:
                invalid_values = self._validate_date_values(values, legal_text)

            if invalid_values:
                raise InvalidDataTypeError(
                    column=column,
                    expected_type=field_type.value,
                    invalid_values=invalid_values[:10]  # Limit to first 10 for readability
                )

    def _validate_text_values(self, values: pd.Series, legal_text: List[str]) -> List[any]:
        """Validate text field values."""
        invalid = []

        for val in values:
            # Allow legal text values
            if legal_text and val in legal_text:
                continue

            # Check if convertible to string
            if not isinstance(val, str):
                invalid.append(val)

        return invalid

    def _validate_integer_values(self, values: pd.Series, legal_text: List[str]) -> List[any]:
        """Validate integer field values."""
        invalid = []

        for val in values:
            if legal_text and val in legal_text:
                continue

            if not isinstance(val, (int, np.integer)):
                invalid.append(val)

        return invalid

    def _validate_float_values(self, values: pd.Series, legal_text: List[str]) -> List[any]:
        """Validate float field values."""
        invalid = []

        for val in values:
            if legal_text and val in legal_text:
                continue

            if not isinstance(val, (int, float, np.integer, np.floating)):
                invalid.append(val)

        return invalid

    def _validate_date_values(self, values: pd.Series, legal_text: List[str]) -> List[any]:
        """Validate date field values."""
        invalid = []

        for val in values:
            if legal_text and val in legal_text:
                continue

            if not isinstance(val, (pd.Timestamp, datetime.date)):
                # Try to parse as date
                try:
                    parse_datetime(val)
                except (TypeError, ValueError):
                    invalid.append(val)

        return invalid