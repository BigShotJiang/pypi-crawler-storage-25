from typing import List
from mgtx_benchling_wrapper.wrapper.facade import BenchlingWrapperFacade
from mgtx_benchling_wrapper.workflows.models.types import FieldType, SchemaDefinition, ValidationResult, BlobType
from .exceptions import (
    ValidationError,
    InvalidIdentifier,
    InvalidArchiveSettings,
    InvalidColumnError,
    InvalidBlobType,
    NoUniqueIdentifiersProvided,
    EmptyCompareOnList,
    InvalidSchemaName,
    NotAnyEntityColumn
)
from mgtx_benchling_wrapper.utils.logger import get_logger

logger = get_logger(__name__,
                    file_log_level='DEBUG',
                    console_log_level='DEBUG',)

class InputParamValidator:

    def __init__(self, schema: SchemaDefinition, wrapper: BenchlingWrapperFacade):
        self._wrapper = wrapper
        self.schema = schema
        self._blob_types = {BlobType.PNG, BlobType.JPEG}
        self._link_types = {FieldType.ENTITY_LINK, FieldType.MIXTURE_LINK, FieldType.STORAGE_LINK}

    def validate(self,
                   unique_identifiers: list[str],
                   compare_on: list[str] = None,
                   archive: bool = False,
                   blob_type: BlobType = "image/png",
                   dict_variable_to_entity_type: dict[str, list[str]] = None,
                   strict: bool = True
                   ) -> ValidationResult:

        errors: List[ValidationError] = []
        warnings: List[str] = []

        try:
            self._validate_unique_identifiers(unique_identifiers)
        except ValidationError as e:
            if strict:
                raise
            errors.append(e)

        #validate compare on variables if exists
        try:
            self._validate_compare_on_variables(compare_on)
        except ValidationError as e:
            if strict:
                raise
            errors.append(e)

        #validate archive settings
        try:
            self._validate_archive_settings(archive, compare_on)
        except ValidationError as e:
            if strict:
                raise
            errors.append(e)

        #validate blob type
        try:
            self._validate_blob_type(blob_type)
        except ValidationError as e:
            if strict:
                raise
            errors.append(e)

        # validate dict_variable_to_entity_type
        if dict_variable_to_entity_type is not None:
            try:
                list_schemas = self._get_list_schemas()
                self._validate_dict_variable_to_entity_type(list_schemas, dict_variable_to_entity_type)
            except ValidationError as e:
                if strict:
                    raise
                errors.append(e)

        is_valid = len(errors) == 0
        return ValidationResult(is_valid=is_valid, errors=errors, warnings=warnings)

    def _validate_unique_identifiers(self, unique_identifiers: list[str]) -> None:
        if len(unique_identifiers) == 0:
            raise NoUniqueIdentifiersProvided(self.schema['id'])
        for variable in unique_identifiers:
            if variable in self.schema['variable_to_type'].keys() and self.schema['variable_to_type'][
                variable] in self._link_types:
                pass
            else:
                raise InvalidIdentifier(variable, self.schema['id'])

    def _validate_archive_settings(self, archive: bool, compare_on: list[str]) -> None:
        if not archive and compare_on is None:
            logger.info("archive is set to False, and compare_on is set to None. If pre-existing "
                            "exist for unique_identifiers, data is subset to not be ingested.")

        elif archive is True and compare_on is None:
            logger.info("archive is set to true and compare_on is set to None. Pre-existing"
                            "results will be retrieved based on unique_identifiers. Pre-existing data will be archived.")

        elif not archive and compare_on is not None:
            logger.info("archive is set to false and compare_on is provided. Pre-existing"
                            "results will be retrieved based on unique_identifiers, and compared based on"
                            "columns provided in compare_on. Any new results will be ingested.")

        elif archive and compare_on is not None:
            raise InvalidArchiveSettings(archive, compare_on)
        return

    def _validate_compare_on_variables(self, compare_on: list[str]) -> None:
        if compare_on is None:
            pass
        elif len(compare_on) == 0:
            raise EmptyCompareOnList()
        else:
            for variable in compare_on:
                if variable in self.schema['variable_to_type'].keys():
                    pass
                else:
                    raise InvalidColumnError(variable)

    def _validate_blob_type(self, blob_type: BlobType) -> None:
        if blob_type not in self._blob_types:
            raise InvalidBlobType(blob_type)
        return

    def _get_list_schemas(self) -> list[str]:
        list_entity_schemas = self._wrapper.schemas.get_entity_schemas()
        list_container_schemas = self._wrapper.schemas.get_container_schemas()
        list_schemas = self._wrapper.schemas.list_schema_names(list_entity_schemas) + self._wrapper.schemas.list_schema_names(list_container_schemas)
        return list_schemas

    def _validate_dict_variable_to_entity_type(
            self,
            list_schemas: list[str],
            dict_variable_to_entity_type:dict[str,list[str]]
    ) -> None:

        for column in dict_variable_to_entity_type.keys():
            if column not in self.schema['variable_to_schema_id'].keys():
                raise InvalidColumnError(column)
            elif self.schema['variable_to_schema_id'][column] is not None:
                    raise NotAnyEntityColumn(column, [self.schema['variable_to_schema_id'][column]])
            else:
                for expected_schema in dict_variable_to_entity_type[column]:
                    if expected_schema not in list_schemas:
                        raise InvalidSchemaName(column, expected_schema)
        return
