from mgtx_benchling_wrapper.workflows.transformation.exceptions import TransformationError, RepeatedBlobName
from mgtx_benchling_wrapper.wrapper.facade import BenchlingWrapperFacade
from mgtx_benchling_wrapper.workflows.models.types import FieldType, SchemaDefinition, BlobType
from mgtx_benchling_wrapper.utils.list_unique_values_col import list_unique_values_in_column
from mgtx_benchling_wrapper.utils.substitute_df_col_dict import substitute_with_dict
from mgtx_benchling_wrapper.utils.create_blob_payload import create_image_blob_payload
import pandas as pd
from typing import Any
from mgtx_benchling_wrapper.utils.logger import get_logger

logger = get_logger(__name__,
                    file_log_level='DEBUG',
                    console_log_level='DEBUG',)

class BlobTransformer:
    """ transformers dataframes

    Responsabilities:
    - validates blob names (flags repeated names)
    - Substitutes blob paths with blob names
    - creates a dict of blob names to blob paylods

    """
    def __init__(self, schema: SchemaDefinition, wrapper: BenchlingWrapperFacade):
        self._wrapper = wrapper
        self.schema = schema
        self._link_types = {FieldType.ENTITY_LINK, FieldType.MIXTURE_LINK, FieldType.STORAGE_LINK}
        self._blob_types = {BlobType.PNG, BlobType.JPEG}

    def transform(self, df: pd.DataFrame, blob_type: BlobType) -> (pd.DataFrame, dict[str, Any]):
        new_df = df.copy()
        dict_name_to_payload = {}

        if FieldType.BLOB_LINK not in self.schema['variable_to_type'].values():
            pass
            logger.info(f"No blob columns to transform.")
        else:
            for variable in df.columns:
                if self.schema['variable_to_type'][variable] == FieldType.BLOB_LINK:
                    list_blobs = list_unique_values_in_column(df, variable, drop_na=True)

                    dict_path_to_name, dict_name_to_payload = self._substitute_blob_with_name(
                        list_blobs,
                        blob_type
                    )

                    dict_name_to_payload.update(dict_name_to_payload)

                    new_df = substitute_with_dict(
                        new_df,
                        variable,
                        dict_path_to_name)

                    logger.info(f"Blob transformation completed for {variable}.")

        return new_df, dict_name_to_payload

    def _substitute_blob_with_name(
            self,
            list_blob_paths: list[str],
            blob_type: BlobType
    ) -> (dict[str,str], dict[str,Any]):

        dict_path_to_name = {}
        dict_path_to_payload = {}
        dict_name_to_payload = {}

        for blob_path in list_blob_paths:
            if blob_path not in dict_path_to_name:
                blob_payload, blob_name = create_image_blob_payload(blob_path, blob_type)
                dict_path_to_payload[blob_path] = blob_payload
                dict_path_to_name[blob_path] = blob_name
                dict_name_to_payload[blob_name] = blob_payload

        try:
            self._validate_blob_name(dict_path_to_name)
        except TransformationError:
            raise
        return dict_path_to_name, dict_name_to_payload

    @staticmethod
    def _validate_blob_name(dict_path_to_name: dict[str, str]) -> None:
        dict_repeated_blobs = {}

        for blob in dict_path_to_name:
            if blob in dict_repeated_blobs.keys():
                pass
            elif list(dict_path_to_name.values()).count(dict_path_to_name[blob]) > 1:
                dict_repeated_blobs[blob] = dict_path_to_name[blob]

        if len(dict_repeated_blobs) >0:
            raise RepeatedBlobName(list(dict_repeated_blobs.keys()))
        else:
            logger.info(f"Blob payload validated for repeated names.")
        return
