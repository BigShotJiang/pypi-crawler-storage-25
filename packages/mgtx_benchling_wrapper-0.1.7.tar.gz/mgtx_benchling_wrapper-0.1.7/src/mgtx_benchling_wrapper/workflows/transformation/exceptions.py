from typing import List, Dict, Any

class TransformationError(Exception):
    """Base exception for transformation errors"""
    def __init__(self, message: str, context: Dict[str, Any] = None):
        super().__init__(message)
        self.context = context or {}
        self.message = message

class BlobTransformationError(TransformationError):
    """Raised when errors arise for blob transformation"""
    pass

class ContainerTransformationError(TransformationError):
    """Raised when errors arise for the creation of container id column"""
    pass

class TooManyContainerIdColumns(ContainerTransformationError):
    """Raised when more than one column is found to have containers"""
    def __init__(self, invalid_values: List[Any] = None):
        super().__init__(
            f"Too many container id columns were found {invalid_values}.",
            invalid_values
        )

class ContainerIdAlreadyInColumns(ContainerTransformationError):
    """Raised when a container id column is already present in a dataframe"""
    def __init__(self, column: str):
        super().__init__(
            f"column of storage type '{column}' already in dataframe."
        )

class ContainersInMoreThanOneEntityColumn(ContainerTransformationError):
    """Raised when containers are present in more than one entity column"""
    def __init__(self, invalid_values: List[Any] = None):
        super().__init__(
            f"Too many entity columns {invalid_values} with containers."
        )

class RepeatedBlobName(BlobTransformationError):
    """ Raised when more than one blob is found to have repeated names"""
    def __init__(self, invalid_values: List[Any] = None):
        super().__init__(
            f"Blobs with repeated names and distinct paths were found: {invalid_values}.",
            invalid_values
        )
class DropdownDoesNotExist(TransformationError):
    """ Raised when dropdown does not exist"""
    def __init__(self, dropdown_id: str):
        super().__init__(
            f"Dropdown id '{dropdown_id}' does not exist."
        )

class InvalidDropdownOptions(TransformationError):
    """Raised when dropdown options are invalid"""
    def __init__(self, dropdown_id: str, invalid_values: List[Any] = None):
        super().__init__(
            f"Dropdown options {invalid_values} are invalid for {dropdown_id}.",
            invalid_values
        )

class InvalidContainerType(TransformationError):
    """Raised when restricted container type is invalid"""
    def __init__(self, value_name: str, column: str, list_allowed_entities: list[str]):
        super().__init__(
            f"Entity {value_name} in {column} is not of type {list_allowed_entities}'",
            {"column": column, "error_type": "invalid_entity_type"}
        )

class InvalidEntityType(TransformationError):
    """Raised when restricted entity type is invalid"""
    def __init__(self, value_name: str, column: str, list_allowed_entities: list[str]):
        super().__init__(
            f"Entity {value_name} in {column} is not of type {list_allowed_entities}'",
            {"column": column, "error_type": "invalid_entity_type"}
        )

class NoEntityFound(TransformationError):
    """Raised when restricted entity type is invalid"""
    def __init__(self, column: str, list_entities: list[str]):
        super().__init__(
            f"None of the entities {list_entities} in column '{column}' where found on Benchling.",
            {"column": column, "error_type": "no_entity_found"}
        )