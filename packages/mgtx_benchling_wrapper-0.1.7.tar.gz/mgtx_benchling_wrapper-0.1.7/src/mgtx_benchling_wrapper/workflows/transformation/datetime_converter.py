import pandas as pd
from mgtx_benchling_wrapper.utils.datetime_parser import parse_datetime
from mgtx_benchling_wrapper.workflows.models.types import FieldType, SchemaDefinition
from mgtx_benchling_wrapper.utils.logger import get_logger

logger = get_logger(__name__,
                    file_log_level='DEBUG',
                    console_log_level='DEBUG',)

class DateTimeConverter:

    """
    Converts any date column into ISO 8601 format (format used by benchling)

    Responsabilities:
    - Convert date columns into ISO 8601 format matching the _parse_datetime logic

    Does not:
    -

    """

    def __init__(self, schema: SchemaDefinition):
        self.schema = schema

    def transform(
            self,
            df: pd.DataFrame
    ) -> pd.DataFrame:

        for variable in df.columns:
            if self.schema['variable_to_type'][variable]==FieldType.DATETIME:
                df[variable] = df[variable].apply(
                    lambda x: (
                        parse_datetime(x).isoformat()
                        if pd.notna(x)
                        else None
                    )
                )

                logger.info(f"{variable} as been converted to ISO 8601 format.")

        return df