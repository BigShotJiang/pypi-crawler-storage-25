from mgtx_benchling_wrapper.wrapper.facade import BenchlingWrapperFacade
from mgtx_benchling_wrapper.workflows.models.types import FieldType, SchemaDefinition
from mgtx_benchling_wrapper.workflows.transformation.exceptions import (
    TransformationError,
    DropdownDoesNotExist,
    InvalidDropdownOptions
)
from mgtx_benchling_wrapper.utils.list_unique_values_col import list_unique_values_in_column
from mgtx_benchling_wrapper.utils.substitute_df_col_dict import substitute_with_dict
import pandas as pd
from mgtx_benchling_wrapper.utils.logger import get_logger

logger = get_logger(__name__,
                    file_log_level='DEBUG',
                    console_log_level='DEBUG',)

class DropdownTransformer:
    """ transformers dataframes

    Responsabilities:
    - validates dropdowns options given in the dataframe
    - substitutes dropdowns with correct ids

    """
    def __init__(self, schema: SchemaDefinition, wrapper: BenchlingWrapperFacade):
        self._wrapper = wrapper
        self.schema = schema
        self._link_types = {FieldType.ENTITY_LINK, FieldType.MIXTURE_LINK, FieldType.STORAGE_LINK}

    def transform(self, df: pd.DataFrame) -> pd.DataFrame:

        new_df = df.copy()

        if FieldType.DROPDOWN not in self.schema['variable_to_type'].values():
            pass
            logger.info(f"No columns containing dropdowns to transform.")
        else:
            for variable in df.columns:
                if self.schema['variable_to_type'][variable] == FieldType.DROPDOWN:
                    try:
                        dropdown_options = self._get_dropdown_options(variable)
                    except TransformationError:
                        raise

                    try:
                        self._check_for_missing_options(dropdown_options, new_df, variable)
                    except TransformationError:
                        raise

                    new_df = substitute_with_dict(new_df,variable, dropdown_options)

        return new_df

    def _get_dropdown_options(self, column:str) -> dict[str, str]:
        dropdown_id = self.schema['variable_to_dropdown_id'][column]
        dropdown = self._wrapper.dropdowns.get_from_api_id(dropdown_id)

        if dropdown:
            return self._wrapper.dropdowns.dict_option_api_id(dropdown)
        else:
            raise DropdownDoesNotExist(dropdown_id)

    def _check_for_missing_options(self, dropdown_options: dict[str, str], df: pd.DataFrame, column: str):
        list_missing_values: list[str] = []
        list_options = dropdown_options.keys()
        list_values = list_unique_values_in_column(df, column, drop_na=True)

        for value in list_values:
            if value not in list_options:
                list_missing_values.append(value)

        if len(list_missing_values) > 0:
            raise InvalidDropdownOptions(self.schema['variable_to_dropdown_id'][column], list_missing_values)
        return