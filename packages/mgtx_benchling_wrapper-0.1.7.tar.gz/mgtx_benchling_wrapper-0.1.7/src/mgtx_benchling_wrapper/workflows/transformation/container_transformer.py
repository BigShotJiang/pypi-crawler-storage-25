from benchling_sdk.models import (
    Container
)
from benchling_sdk.helpers.pagination_helpers import Optional, List
from mgtx_benchling_wrapper.wrapper.facade import BenchlingWrapperFacade
from mgtx_benchling_wrapper.utils.list_unique_values_col import list_unique_values_in_column
from mgtx_benchling_wrapper.utils.substitute_df_col_dict import substitute_with_dict
import pandas as pd
from mgtx_benchling_wrapper.workflows.models.types import FieldType, SchemaDefinition
from .exceptions import (
    TransformationError,
    TooManyContainerIdColumns,
    ContainerIdAlreadyInColumns,
    ContainersInMoreThanOneEntityColumn,
    InvalidContainerType
)
from benchling_sdk.errors import BenchlingError

from mgtx_benchling_wrapper.utils.logger import get_logger

logger = get_logger(__name__,
                    file_log_level='DEBUG',
                    console_log_level='DEBUG',)

class ContainersTransformer:
    """
        Creates a column for containers when the column is present on the schema

        Responsibilities:
        - Validates one container column exists per schema
        - creates a container id column
        - substitutes containers in entity columns by the container content

        Does NOT:
        - Perform entity resolution

        Returns:
            ValidationResult with errors and warnings

        Raises:
            TransformationError: If strict=True
    """

    def __init__(self, schema: SchemaDefinition, wrapper: BenchlingWrapperFacade):
        self._wrapper = wrapper
        self.schema = schema
        self._link_types = {FieldType.ENTITY_LINK, FieldType.MIXTURE_LINK, FieldType.STORAGE_LINK}

    def transform(
            self,
            df:pd.DataFrame,
            dict_variable_to_entity_type: dict[str, list[str]],
    ) -> pd.DataFrame:

        try:
            #get container id column if it exists in the schema
            container_id_column = self._get_container_column_name()
        except TransformationError:
            raise

        if container_id_column is not None:
            try:
                #check if container_id column already in df
                self._validate_pre_existing_df_cols(container_id_column, df)
            except TransformationError:
                raise

            try:
                #make sure not more than one entity column has containers
                dict_column_to_list_containers = self._create_container_id_dict(df)
            except TransformationError:
                raise

            if dict_column_to_list_containers:

                if dict_variable_to_entity_type is not None:
                    try:
                        self._validate_allowed_container_types(
                            dict_column_to_list_containers,
                            dict_variable_to_entity_type,
                            container_id_column
                        )
                    except TransformationError:
                        raise
                try:
                    #update dataframe with container id column
                    df = self._update_df(df, dict_column_to_list_containers, container_id_column)
                except TransformationError:
                    raise

            logger.info(f"Container id column {container_id_column} has been created.")

        return df

    def _create_container_id_dict(
            self,
            df: pd.DataFrame,
    ) -> dict[str, list[Container]]:

        dict_column_to_list_containers: dict[str, Optional[List[Container]]] = {}

        for column in df.columns:
            if (self.schema['variable_to_type'][column] == FieldType.ENTITY_LINK or
                    self.schema['variable_to_type'][column] == FieldType.MIXTURE_LINK):
                list_containers = self._create_list_containers(df, column)

                if list_containers:
                    dict_column_to_list_containers[column] = list_containers

                if len(dict_column_to_list_containers) >1:
                    raise ContainersInMoreThanOneEntityColumn

        return dict_column_to_list_containers

    def _get_container_column_name(self) -> str | None:
        list_container_id_cols = []

        for column in self.schema['variable_to_type']:
            if self.schema['variable_to_type'][column] == FieldType.STORAGE_LINK:
               list_container_id_cols.append(column)

        if len(list_container_id_cols) > 1:
            raise TooManyContainerIdColumns(list_container_id_cols)
        elif list_container_id_cols:
            return list_container_id_cols[0]
        else:
            return None

    def _validate_pre_existing_df_cols(self, container_id_column: str, df: pd.DataFrame) -> None:
        if container_id_column in df.columns:
            raise ContainerIdAlreadyInColumns(container_id_column)
        return

    def _validate_allowed_container_types(
            self,
            dict_column_to_list_containers: dict[str, Optional[List[Container]]],
            dict_variable_to_entity_type: dict[str, list[str]],
            column_container: str,
    ) -> None:

        column_entity = list(dict_column_to_list_containers.keys())[0]
        list_containers = dict_column_to_list_containers[column_entity]
        dict_name_to_schema, _ = self._get_dict_to_name_to_schema_name(list_containers)
        self._validate_against_allowed_entities(column_container, dict_name_to_schema, dict_variable_to_entity_type[column_container])
        return

    def _update_df(
            self,
            df:pd.DataFrame,
            dict_column_to_list_containers: dict[str, Optional[List[Container]]],
            column_container: str,
    ) -> pd.DataFrame:

        column_entity = list(dict_column_to_list_containers.keys())[0]
        list_containers = dict_column_to_list_containers[column_entity]
        dict_name_to_api_id, dict_reg_to_api_id = self._get_dicts_for_containers(list_containers)
        dict_barcode_to_content_reg = self._get_dict_barcode_to_content(list_containers)
        df = self._update_container_id_col(df, column_entity, column_container, dict_name_to_api_id, dict_reg_to_api_id)
        df = self._update_entity_col(df, column_entity, dict_barcode_to_content_reg)

        return df

    def _create_list_containers(
            self,
            df: pd.DataFrame,
            column_entity: str,
    ) -> (list[Container] | None):

        list_entities = list_unique_values_in_column(df, column_entity)
        try:
            list_containers = self._get_list_container(list_entities)
        except BenchlingError as error_message:
            updated_entity_list = self._subset_invalid_barcodes(list_entities, error_message)
            if len(updated_entity_list) == 0:
                return
            else:
                list_containers = self._get_list_container(updated_entity_list)
        return list_containers

    def _subset_invalid_barcodes(
            self,
            list_entities: list[str],
            benchling_error_message: BenchlingError
    ) -> list:

        list_invalid_barcodes = benchling_error_message.json['error']['invalidBarcodes']
        updated_entity_list = [element for element in list_entities if element not in list_invalid_barcodes]
        return updated_entity_list

    def _update_container_id_col(
            self,
            df:pd.DataFrame,
            column_entity: str,
            column_container: str,
            dict_name_to_api_id: dict[str,str],
            dict_reg_to_api_id: dict[str,str],
    ) -> pd.DataFrame:

        new_list_containers = self._get_list_containers(df, column_entity, dict_name_to_api_id, dict_reg_to_api_id)
        df[column_container] = new_list_containers

        return df

    def _update_entity_col(
            self,
            df:pd.DataFrame,
            column_entity: str,
            dict_barcode_to_content_reg: dict[str,str]
    ) -> pd.DataFrame:
        df = substitute_with_dict(df, column_entity, dict_barcode_to_content_reg)
        return df

    def _get_list_container(self, list_entities:list[str]) -> Optional[List[Container]]:
        list_containers = self._wrapper.containers.get_by_names(list_entities)
        return list_containers

    def _get_dicts_for_containers(self, list_containers:Optional[List[Container]]) -> (dict[str,str], dict[str,str]):
        dict_name_to_api_id, dict_reg_to_api_id = self._wrapper.containers.dict_name_to_api_id(list_containers)
        return dict_name_to_api_id, dict_reg_to_api_id

    def _get_dict_barcode_to_content(self, list_containers: Optional[List[Container]]) -> dict[str,str]:
        dict_barcode_to_content = self._wrapper.containers.dict_name_to_content(list_containers)
        dict_barcode_to_content_reg = self.dict_container_to_content(dict_barcode_to_content)
        return dict_barcode_to_content_reg

    def dict_container_to_content(
            self,
            dict_barcode_to_content: dict
    ) -> dict:

        dict_barcode_to_content_reg = {}

        for barcode in dict_barcode_to_content:

            entity = self._wrapper.custom_entities.registry_id(dict_barcode_to_content[barcode])
            mixture = self._wrapper.mixtures.registry_id(dict_barcode_to_content[barcode])

            if entity:
                dict_barcode_to_content_reg[barcode] = entity
            elif mixture:
                dict_barcode_to_content_reg[barcode] = mixture

        return dict_barcode_to_content_reg

    def _get_list_containers(
            self,
            df:pd.DataFrame,
            column_entities: str,
            dict_name_to_api_id: dict[str,str],
            dict_reg_to_api_id: dict[str,str]
    ) -> list[str]:
        new_list_containers = []
        if dict_name_to_api_id or dict_reg_to_api_id:
            list_for_container = df[column_entities]
            for container in list_for_container:
                if container in dict_name_to_api_id.keys() or container in dict_reg_to_api_id.keys():
                    new_list_containers.append(dict_name_to_api_id[container])
                elif container in dict_reg_to_api_id.keys():
                    new_list_containers.append(dict_reg_to_api_id[container])
                else:
                    new_list_containers.append(None)

        return new_list_containers

    def _get_dict_to_name_to_schema_name(
            self,
            list_containers: Optional[List[Container]]
    ) -> (dict[str, list[str]], dict[str, list[str]]):

        name_to_schema: dict[str, str] = {}
        reg_to_schema: dict[str, str] = {}

        names, regs = self._wrapper.containers.dict_name_to_schema_name(list_containers)
        name_to_schema.update(names)
        reg_to_schema.update(regs)

        return name_to_schema, reg_to_schema

    def _validate_against_allowed_entities(
            self,
            column: str,
            dict_name_to_schema: dict[str, str],
            list_allowed_entities: list[str]
    ) -> None:

        for value_name in dict_name_to_schema:
            if dict_name_to_schema[value_name] not in list_allowed_entities:
                raise InvalidContainerType(value_name, column, list_allowed_entities)


