from benchling_sdk.models import (
    CustomEntity,
    Mixture
)
from mgtx_benchling_wrapper.workflows.resolution.links_resolver import LinkResolver
from mgtx_benchling_wrapper.wrapper.facade import BenchlingWrapperFacade
from mgtx_benchling_wrapper.workflows.models.types import FieldType, SchemaDefinition
from mgtx_benchling_wrapper.utils.list_unique_values_col import list_unique_values_in_column
from mgtx_benchling_wrapper.utils.substitute_df_col_dict import substitute_with_dict
from mgtx_benchling_wrapper.utils.compare_dataframe_cols import compare_dataframe_columns
from .exceptions import (
    TransformationError,
    InvalidEntityType,
    NoEntityFound
)
import pandas as pd
from mgtx_benchling_wrapper.utils.logger import get_logger

logger = get_logger(__name__,
                    file_log_level='DEBUG',
                    console_log_level='DEBUG',)

class LinkTransformer:
    """
        Transforms dataframe

    Responsabilities:
    - Substitutes entity names or registry ids with api ids
    - Lists missing entities not found on Benchling
    - Pops missing entities from dataframe
    """

    def __init__(self, schema: SchemaDefinition, wrapper: BenchlingWrapperFacade):
        self._wrapper = wrapper
        self.schema = schema
        self._link_types = {FieldType.ENTITY_LINK, FieldType.MIXTURE_LINK}
        self._link_resolver: LinkResolver = LinkResolver(self._wrapper)

    def transform(
            self,
            df: pd.DataFrame,
            dict_variable_to_entity_type: dict[str, list[str]] = None
    ) -> (pd.DataFrame, list[str]):

        new_df = df.copy()

        try:
            dict_column_to_entities = self._create_dict_of_entities(new_df)
        except TransformationError:
            raise

        if dict_variable_to_entity_type is not None:
            try:
                self._validate_entity_type_against_allowed_entities(dict_column_to_entities, dict_variable_to_entity_type)
                logger.info(f"Restricted entity validation passed for {dict_column_to_entities.keys()} columns")
            except TransformationError:
                raise

        new_df = self._substitute_api_ids(new_df, dict_column_to_entities)
        list_missing_entities = self._list_missing_entities(df, new_df)
        new_df = self._pop_missing_entities(new_df, list_missing_entities)

        if len(list_missing_entities) == 0:
            logger.info(f"All entities were found on benchling")
        else:
            logger.warning(f"The following entities were not found on benchling: {list_missing_entities}.")

        return new_df, list_missing_entities

    def _create_dict_of_entities(
            self,
            df: pd.DataFrame,
    ) -> dict[str, list[CustomEntity | Mixture]]:

        dict_column_to_entities = {}

        for variable in df.columns:
            if self.schema['variable_to_type'][variable] in self._link_types:
                list_entities = list_unique_values_in_column(df, variable)
                list_obj_entities = self._link_resolver.build_list_resolver(list_entities)

                if len(list_obj_entities) == 0:
                    raise NoEntityFound(variable, list_entities)
                else:
                    dict_column_to_entities[variable] = list_obj_entities

        return dict_column_to_entities

    def _validate_entity_type_against_allowed_entities(
            self,
            dict_column_to_entities: dict[str, list[CustomEntity | Mixture]],
            dict_variable_to_entity_type: dict[str, list[str]]
    ) -> None:
        for variable in dict_column_to_entities:
            if variable in dict_variable_to_entity_type.keys():
                list_entities = dict_column_to_entities[variable]
                dict_name_to_schema, _ = self._link_resolver.build_dict_to_schema_resolver(list_entities)
                self._validate_against_allowed_entities(variable, dict_name_to_schema,
                                                        dict_variable_to_entity_type[variable])
                return

    def _validate_against_allowed_entities(
            self,
            column: str,
            dict_name_to_schema: dict[str, str],
            list_allowed_entities: list[str]
    ) -> None:

        for value_name in dict_name_to_schema:
            if dict_name_to_schema[value_name] not in list_allowed_entities:
                raise InvalidEntityType(value_name, column, list_allowed_entities)
        return

    def _substitute_api_ids(
            self,
            df: pd.DataFrame,
            dict_column_to_entities: dict[str, list[CustomEntity | Mixture]]
    ) -> pd.DataFrame:

        for column in df.columns:
            if self.schema['variable_to_type'][column] in self._link_types:
                name_to_api, reg_to_api = self._link_resolver.build_dict_resolver(dict_column_to_entities[column])
                list_dict = [name_to_api, reg_to_api]

                for dictionary in list_dict:
                    df = substitute_with_dict(df, column, dictionary)
        return df

    def _list_missing_entities(
            self,
            df: pd.DataFrame,
            new_df: pd.DataFrame,
    ) -> list[str]:
        list_missing_values = []

        for column in df.columns:
            if self.schema['variable_to_type'][column] in self._link_types:
                list_missing_values = compare_dataframe_columns(
                    df,
                    new_df,
                    column
                )
                list_missing_values.extend(list_missing_values)

        return list_missing_values

    def _pop_missing_entities(
            self,
            df: pd.DataFrame,
            list_missing_entities: list[str],
    ) -> pd.DataFrame:
        for column in df.columns:
            if self.schema['variable_to_type'][column] in self._link_types:
                df = df.loc[~df[column].isin(list_missing_entities)]
        return df