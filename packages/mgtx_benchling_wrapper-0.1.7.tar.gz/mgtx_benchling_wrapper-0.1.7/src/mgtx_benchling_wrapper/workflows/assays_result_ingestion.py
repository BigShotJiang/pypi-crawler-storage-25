from mgtx_benchling_wrapper.wrapper.facade import BenchlingWrapperFacade
from mgtx_benchling_wrapper.utils.logger import get_logger
from mgtx_benchling_wrapper.workflows.models.types import BlobType
from .transformation.container_transformer import ContainersTransformer
from .transformation.link_transformer import LinkTransformer
from .transformation.blob_transformer import BlobTransformer
from .transformation.dropdown_transformer import DropdownTransformer
from .transformation.datetime_converter import DateTimeConverter
from .transformation.exceptions import TransformationError
from .handlers.result_archiver import ResultArchiver
from .handlers.blob_handler import BlobHandler
from .handlers.result_ingestion import ResultIngestion
from .handlers.exceptions import HandlerError
from .handlers.schema_handler import SchemaHandler
from .validation.api_variable_validation import ApiParametersValidation
from .validation.dataframe_validator import DataFrameValidator
from .validation.input_param_validator import InputParamValidator
from .validation.exceptions import ValidationError
import pandas as pd
from typing import Optional

logger = get_logger(__name__,
                    file_log_level='DEBUG',
                    console_log_level='DEBUG',)

class AssayResultIngestionWorkflow:
    """ """
    def __init__(self, wrapper: BenchlingWrapperFacade):
        self._wrapper = wrapper
        self._api_param_validator : ApiParametersValidation
        self._schema_handler = SchemaHandler
        self._input_param_validator : Optional[InputParamValidator] = None
        self._df_validator : Optional[DataFrameValidator] = None
        self._container_transformer : Optional[ContainersTransformer] = None
        self._link_transformer : Optional[LinkTransformer] = None
        self._blob_transformer : Optional[BlobTransformer] = None
        self._dropdown_transformer : Optional[DropdownTransformer] = None
        self._datetime_converter : Optional[DateTimeConverter] = None
        self._result_archiver : Optional[ResultArchiver] = None
        self._blob_handler: Optional[BlobHandler] = None
        self._result_ingestion: Optional[ResultIngestion] = None

    def assay_results_ingestion(
            self,
            list_dataframes: list[pd.DataFrame],
            schema_id: str,
            project_id: str,
            unique_identifiers: list[str],
            dict_variable_to_entity_type: dict[str, list[str]] = None,
            archive: bool = False,
            compare_on: list[str] = None,
            entry_name: str = None,
            commit_in_transaction: bool = True,
            blob_type: BlobType = "image/png"
    ) -> (list[list[str]]):
        """
        A function to ingest assay results on Benchling following the logic at MeiraGTx DSC.

        Ingests a lists of results dataframes.

        Data parser requires datetime formats to be in the form of DD/MM/YYYY formats.
        Empty values for non-required columns to be set to None.

        Parameters
        ----------
        list_dataframes: list[pd.DataFrame] :
            A list of dataframes to ingest. Columns need to be named with the warehouse name of the target assay
            results schema.
            
        schema_id: str :
            assay results schema api id.
            
        project_id: str :
            project api id.

        unique_identifiers: list[str] :
            a list of unique identifiers of the assay results schema. To be provided as the warehouse name.

        dict_variable_to_entity_type: dict[str:list[str]] :
             (Default value = None)
             To be specified for assay result schema variables set to AnyEntity. Allows to restrict the entity or
             container types to be ingested to an AnyEntity or AnyInventory variable.
             The entity type should refer the front end name of the entity schema or container schema.

        archive: bool :
             (Default value = False)
             Defines whether pre-existing results should be archived.

        compare_on: list[str] :
             (Default value = None)
             A list of variables in the assay results schema to build a dataframe of pre-existing results on Benchling.
             Variable names need to be provided as the warehouse name.

             When archive is False and compare_on is None : Pre-existing results are searched for unique_identifiers.
             If pre-existing results are found for an identifier, new results are not ingested for that identifier.

             When archive is False and compare_on is provided : Pre-existing results retrieved based on
             unique_identifiers and compare_on list, and a pre-existing results dataframe is created. Any rows matching
             pre-existing values will not be ingested.

             When archive is True and compare_on is None : Pre-existing results are retrieved based on variables in
             unique_identifiers. Retrieved data is archived and new results are ingested.

             When archive is True, compare_on cannot be provided.

        entry_name: str :
             (Default value = None)
             Name of the entry to visualized ingested data. Can't be provided in commit_in_transaction is True

        commit_in_transaction: bool :
             (Default value = True)
            When commit_in_transaction is True : Data is ingested to the back-end. entry_name needs to be set to None.
            When commit_in_transaction is False : Data is ingested to a table in an entry mentioned in entry_name.
            entry_name needs to be provided.

        blob_type: BlobType :
             (Default value = "image/png")
              Defines the expected blob type. Allowed values are "image/png" and "image/jpeg".

        Returns
        -------
        list_missing_variables_per_df: a list of lists. Each list will contain missing entities or containers not found
        on Benchling.

        """
        #validate api inputs
        self._api_param_validator = ApiParametersValidation(wrapper=self._wrapper)

        try:
            api_param_validation, table_id = self._api_param_validator.validation(
                schema_id=schema_id,
                project_id=project_id,
                entry_name=entry_name,
                commit_in_transaction = commit_in_transaction,

            )
            logger.info(f"Api input parameters passed validation.")
        except ValidationError as e:
            logger.info(f"Api Input validation failed: {e.message}", extra=e.context)
            raise

        #create schema after validation
        self._schema_handler = SchemaHandler(wrapper=self._wrapper)

        schema = self._schema_handler.build_schema_definition(schema_id, 'assay_results_schema')

        logger.error(f"Schema definition created for {schema['name']}")

        #validation of input parameters
        self._input_param_validator = InputParamValidator(schema=schema, wrapper=self._wrapper)
        try:
            input_param_result = self._input_param_validator.validate(
                unique_identifiers = unique_identifiers,
                compare_on = compare_on,
                archive = archive,
                blob_type = blob_type,
                dict_variable_to_entity_type = dict_variable_to_entity_type)
            logger.info(f"Input parameters passed validation.")
        except ValidationError as e:
            logger.error(f"Input validation failed: {e.message}", extra=e.context)
            raise

        list_missing_variables_per_df = []
        for dataframe in list_dataframes:
            # create dataframe validator
            self._df_validator = DataFrameValidator(schema)

            # validate dataframe Before continuing
            try:
                df_validation_result = self._df_validator.validate(dataframe, strict=True)
                logger.info(f"Schema validation passed for {len(dataframe)} rows")
            except ValidationError as e:
                logger.error(f"Schema validation failed: {e.message}", extra=e.context)
                raise

            # create container_id column if needed
            self._container_transformer = ContainersTransformer(schema, wrapper=self._wrapper)
            try:
                dataframe = self._container_transformer.transform(dataframe, dict_variable_to_entity_type)
            except TransformationError as e:
                logger.error(f"Container column transformation failed: {e.message}", extra=e.context)
                raise

            # create dataframe transformer
            self._link_transformer = LinkTransformer(schema, wrapper=self._wrapper)

            # transform dataframe
            dataframe, list_missing_variables = self._link_transformer.transform(dataframe, dict_variable_to_entity_type)
            list_missing_variables_per_df.append(list_missing_variables)

            if len(dataframe) == 0: #go to the next dataframe if all entities are missing
                logger.warning(f"No entities were found on benchling: {list_missing_variables}.")
                continue

            # create blobs transformer
            self._blob_transformer = BlobTransformer(schema, wrapper=self._wrapper)

            # transform blobs in dataframe if they exist
            try:
                dataframe, dict_name_to_payload = self._blob_transformer.transform(dataframe, blob_type=blob_type)
            except TransformationError as e:
                logger.error(f"Blob transformation failed: {e.message}", extra=e.context)
                raise

            # create dropdown transformer
            self._dropdown_transformer = DropdownTransformer(schema, wrapper=self._wrapper)

            #transform dropdown columns if they exist
            try:
                dataframe = self._dropdown_transformer.transform(dataframe)
            except TransformationError as e:
                logger.error(f"Dropdown transformation failed: {e.message}", extra=e.context)
                raise

            #create datetime converter
            self._datetime_converter = DateTimeConverter(schema)

            #convert date time if they exist
            try:
                dataframe = self._datetime_converter.transform(dataframe)
            except TransformationError as e:
                logger.error(f"Datetime transformation has failed: {e.message}", extra=e.context)
                raise

            # create result archiver
            self._result_archiver = ResultArchiver(schema, wrapper=self._wrapper)

            # archive results
            dataframe = self._result_archiver.transform(dataframe, unique_identifiers, archive, compare_on)
            if dataframe is None: #when all results have been ingested for this dataframe
                logger.info(f"All results were already ingested for this dataframe, "
                            f"the code will proceed to the next dataframe or exit.")
                continue

            #create blob handler
            self._blob_handler = BlobHandler(schema, wrapper=self._wrapper)

            #transform blobs if they exist
            try:
                dataframe = self._blob_handler.ingest(dataframe, dict_name_to_payload)
            except HandlerError as e:
                logger.error(f"Blob transformation: {e.message}", extra=e.context)
                raise

            #create results ingestor
            self._result_ingestion = ResultIngestion(schema, wrapper=self._wrapper)

            #ingest df
            try:
                self._result_ingestion.ingest(dataframe, project_id, table_id, commit_in_transaction)
            except HandlerError as e:
                logger.error(f"Ingestion has failed: {e.message}", extra=e.context)
                raise

        return list_missing_variables_per_df



