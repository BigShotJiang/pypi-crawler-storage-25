from typing import TypedDict, List
from enum import Enum
from mgtx_benchling_wrapper.workflows.validation.exceptions import ValidationError

class FieldType(str, Enum):
    """Benchling field types"""
    TEXT = 'text'
    INTEGER = 'integer'
    FLOAT = 'float'
    DATETIME = 'datetime'
    ENTITY_LINK = 'entity_link'
    MIXTURE_LINK = 'mixture_link'
    STORAGE_LINK = 'storage_link'
    BLOB_LINK = 'blob_link'
    DROPDOWN = 'dropdown'

class BlobType(str, Enum):
    """ Blob types"""
    PNG = 'image/png'
    JPEG = 'image/jpeg'

class SchemaDefinition(TypedDict):
    """Schema metadata"""
    id: str
    name: str
    system_name: str
    variable_to_type: dict[str, FieldType]
    variable_to_name: dict[str, str]
    variable_to_schema_id: dict[str, str]
    variable_to_required: dict[str, bool]
    variable_to_legal_text: dict[str, List[str]]
    variable_to_dropdown_id: dict[str, str]



class ValidationResult:
    """Immutable validation result"""
    def __init__(self, is_valid: bool, errors: List[ValidationError] = None, warnings: List[str] = None):
        self.is_valid = is_valid
        self.errors = errors or []
        self.warnings = warnings or []

    def __bool__(self):
        return self.is_valid

    def __repr__(self):
        if self.is_valid:
            return f"ValidationResult(valid=True, warnings={len(self.warnings)})"
        return f"ValidationResult(valid=False, errors={len(self.errors)})"