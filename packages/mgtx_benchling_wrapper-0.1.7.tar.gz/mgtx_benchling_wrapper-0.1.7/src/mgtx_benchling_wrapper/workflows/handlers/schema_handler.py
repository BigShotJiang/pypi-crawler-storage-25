from mgtx_benchling_wrapper.wrapper.facade import BenchlingWrapperFacade
from mgtx_benchling_wrapper.workflows.models.types import SchemaDefinition, FieldType
from mgtx_benchling_wrapper.utils.logger import get_logger
from .exceptions import HandlerSchemaError

logger = get_logger(__name__,
                    file_log_level='DEBUG',
                    console_log_level='DEBUG',)

class SchemaHandler:
    def __init__(self, wrapper: BenchlingWrapperFacade):
        self._wrapper = wrapper

    def build_schema_definition(self, schema_id: str, schema_type: str = 'assay_results_schema') -> SchemaDefinition:
        """Build schema definition from Benchling schema.

        Parameters
        ----------
        schema_id: str : The api id of the schema.

        schema_type: str : Can be 'assay_results_schema' or 'entity_schema'

        Returns
        -------
        SchemaDefinition object which contains several dicts that describe the schema.
        """
        if schema_type != 'assay_results_schema' and schema_type != 'entity_schema':
            raise HandlerSchemaError('Invalid schema type {schema_type}'.format(schema_type=schema_type))

        (schema_name, schema_system_name, dict_variable_to_type, dict_variable_to_name, dict_entity_to_schema_id, dict_variable_to_dropdown_id,
         dict_variable_to_legal_text, dict_variable_to_required) = self._dicts_variables(schema_id, schema_type)

        return {
            'id': schema_id,
            'name': schema_name,
            'system_name': schema_system_name,
            'variable_to_type': {k: FieldType(v) for k, v in dict_variable_to_type.items()},
            'variable_to_name': dict_variable_to_name,
            'variable_to_schema_id': dict_entity_to_schema_id,
            'variable_to_required': dict_variable_to_required,
            'variable_to_legal_text': dict_variable_to_legal_text,
            'variable_to_dropdown_id': dict_variable_to_dropdown_id,
        }


    def _dicts_variables(self, schema_id: str, schema_type: str = 'assay_results_schema') -> (str, str, dict, dict, dict, dict, dict, dict):
        """

        Parameters
        ----------
        schema_id: str) -> (dict :

        dict :


        Returns
        -------

        """
        if schema_type == 'assay_results_schema':
            schema = self._wrapper.schemas.get_assay_result_schema_by_id(schema_id)
        else:
            schema = self._wrapper.schemas.get_entity_schema_by_id(schema_id)

        schema_name = self._wrapper.schemas.name(schema)
        schema_system_name = self._wrapper.schemas.system_name(schema)
        dict_variable_to_type = self._wrapper.schemas.dict_field_to_type(schema)
        dict_variable_to_name = self._wrapper.schemas.dict_field_to_display_name(schema)
        dict_entity_to_schema_id = self._wrapper.schemas.dict_field_to_entity_schema_id(schema)
        dict_variable_to_dropdown_id = self._wrapper.schemas.dict_field_to_dropdown_id(schema)
        dict_variable_to_legal_text = self._get_list_legal_options(schema)
        dict_variable_to_isrequired = self._wrapper.schemas.dict_field_to_required(schema)

        return (schema_name, schema_system_name, dict_variable_to_type, dict_variable_to_name, dict_entity_to_schema_id, dict_variable_to_dropdown_id,
                dict_variable_to_legal_text, dict_variable_to_isrequired)


    def _get_list_legal_options(self, schema: SchemaDefinition) -> dict[str]:
        """

        Parameters
        ----------
        schema: SchemaDefinition :


        Returns
        -------

        """
        dict_variable_to_legal_text = self._wrapper.schemas.dict_field_to_legal_text(schema)
        for variable in dict_variable_to_legal_text:
            if dict_variable_to_legal_text[variable] is not None:
                dropdown_id = dict_variable_to_legal_text[variable]
                dropdown = self._wrapper.dropdowns.get_from_api_id(dropdown_id)
                list_api_options = self._wrapper.dropdowns.options(dropdown)
                dict_variable_to_legal_text[variable] = [self._wrapper.dropdowns.name(dropdown_option) for dropdown_option
                                                         in list_api_options]
        return dict_variable_to_legal_text
