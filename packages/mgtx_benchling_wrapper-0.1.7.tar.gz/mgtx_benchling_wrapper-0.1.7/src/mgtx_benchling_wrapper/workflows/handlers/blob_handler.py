from benchling_sdk.errors import BenchlingError
from mgtx_benchling_wrapper.wrapper.facade import BenchlingWrapperFacade
from mgtx_benchling_wrapper.workflows.models.types import FieldType, SchemaDefinition
from mgtx_benchling_wrapper.utils.substitute_df_col_dict import substitute_with_dict
import pandas as pd
from mgtx_benchling_wrapper.utils.logger import get_logger
from .exceptions import HandlerBlobError

logger = get_logger(__name__,
                    file_log_level='DEBUG',
                    console_log_level='DEBUG',)

class BlobHandler:
    """
    Creates blobs on benchling

    """
    def __init__(self, schema: SchemaDefinition, wrapper: BenchlingWrapperFacade):
        self._wrapper = wrapper
        self.schema = schema

    def ingest(self, df: pd.DataFrame, dict_name_to_payload) -> pd.DataFrame:

        if FieldType.BLOB_LINK not in self.schema['variable_to_type'].values():
            pass
            logger.info(f"No columns containing blobs to transform.")

        else:

            try:
                dict_name_to_blob_id = self._blob_create(dict_name_to_payload)
            except HandlerBlobError:
                raise

            for variable in df.columns:
                if self.schema['variable_to_type'][variable] == FieldType.BLOB_LINK:
                    df = substitute_with_dict(
                        df,
                        variable,
                        dict_name_to_blob_id)

                    logger.info(
                        f"Blob payload has been updated for {variable}.")

        return df

    def _blob_create(self, dict_name_to_payload) -> dict[str, str]:
        dict_name_to_blob_id: dict[str, str] = {}
        for blob in dict_name_to_payload:
            try:
                blob_create = self._wrapper.blobs.object_image_png_create(dict_name_to_payload[blob])
                blob_id = self._wrapper.blobs.create_and_get_id(blob_create)
                dict_name_to_blob_id[blob] = blob_id
                logger.info(f"Blob image has been created for {blob} with {blob_id}.")
            except BenchlingError as e:
                raise HandlerBlobError(message=f"Benchling blob ingestion failed: {e.content}",
                                       context={'blob':blob}) from e
        return dict_name_to_blob_id




