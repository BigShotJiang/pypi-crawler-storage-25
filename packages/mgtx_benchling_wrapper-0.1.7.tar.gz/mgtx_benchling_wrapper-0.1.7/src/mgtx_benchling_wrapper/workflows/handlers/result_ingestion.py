from mgtx_benchling_wrapper.wrapper.facade import BenchlingWrapperFacade
from benchling_api_client.v2.alpha.models.assay_result_create import AssayResultCreate
from benchling_sdk.errors import BenchlingError
import pandas as pd
from mgtx_benchling_wrapper.workflows.models.types import SchemaDefinition
from mgtx_benchling_wrapper.utils.logger import get_logger
from .exceptions import HandlerResultIngestionError

logger = get_logger(__name__,
                    file_log_level='DEBUG',
                    console_log_level='DEBUG',)

class ResultIngestion:

    def __init__(self, schema: SchemaDefinition, wrapper: BenchlingWrapperFacade):
        self._wrapper = wrapper
        self.schema = schema

    def ingest(
            self,
            df: pd.DataFrame,
            project_id : str,
            table_id: str = None,
            commit_in_transaction: bool = True
    ) -> None:

        list_assay_results_create = self._create_assay_results(df, project_id)

        if commit_in_transaction:
            try:
                self._wrapper.assay_results.bulk_create_commit_results_transaction(
                    list_assay_results_create
                )
                logger.info(
                    f"All results were ingested through a transaction.")
            except BenchlingError as e:
                raise HandlerResultIngestionError(message=f"Benchling result ingestion failed: {e.content}",
                                       context={'list_results': list_assay_results_create,
                                                'commit_in_transaction': commit_in_transaction}) from e

        else:
            try:
                self._wrapper.assay_results.create_bulk(
                    list_assay_results_create,
                    table_id
                )
                logger.info(
                    f"All results have been ingested to the front end for table {table_id}.")
            except BenchlingError as e:
                raise HandlerResultIngestionError(message=f"Benchling result ingestion failed: {e.content}",
                                       context={'list_results': list_assay_results_create,
                                                'commit_in_transaction': commit_in_transaction,
                                                'table_id': table_id}) from e

        return

    def _create_assay_results(
            self,
            dataframe: pd.DataFrame,
            project_id: str,
    ) -> list[AssayResultCreate]:
        list_field_names = dataframe.columns
        list_assay_result_create = []

        for index in range(len(dataframe)):
            list_results = dataframe.iloc[index].tolist()
            result_to_create = self._wrapper.assay_results.object_create(
                list_field_names,
                list_results,
                self.schema['id'],
                project_id
            )
            list_assay_result_create.append(result_to_create)

        return list_assay_result_create