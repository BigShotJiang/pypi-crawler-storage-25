from mgtx_benchling_wrapper.wrapper.facade import BenchlingWrapperFacade
from mgtx_benchling_wrapper.workflows.models.types import FieldType, SchemaDefinition
from mgtx_benchling_wrapper.utils.list_unique_values_col import list_unique_values_in_column
import pandas as pd
from mgtx_benchling_wrapper.utils.logger import get_logger

logger = get_logger(__name__,
                    file_log_level='DEBUG',
                    console_log_level='DEBUG',)

class ResultArchiver:

    def __init__(self, schema: SchemaDefinition, wrapper: BenchlingWrapperFacade):
        self._wrapper = wrapper
        self.schema = schema
        self._link_types = {FieldType.ENTITY_LINK, FieldType.MIXTURE_LINK, FieldType.STORAGE_LINK}

    def transform(self,
            dataframe: pd.DataFrame,
            unique_identifiers: list[str],
            archive: bool = False,
            compare_on: list[str] = None,
    ) -> pd.DataFrame:

        new_df = dataframe.copy()

        if not archive and compare_on is None: #for example in the case of upstream runs
            new_df = self.pop_ingested_entities(new_df, unique_identifiers)

            logger.info(
                f"Results for unique_identifiers already on Benchling have been excluded for ingestion.")

        elif archive and compare_on is None: #for assay results
            _ , list_results = self.get_existing_results(dataframe, unique_identifiers, compare_on)

            if len(list_results)>0:

                logger.info(f"{len(list_results)} will be archived.")
                self._wrapper.assay_results.archive(list_results)

        elif not archive and compare_on is not None: #for assay results
            results_df, list_results = self.get_existing_results(dataframe, unique_identifiers, compare_on)

            new_df = self._compare_dataframe_results(new_df, results_df, compare_on)

            logger.info(f"Results have been compared and excluded for ingestion according to unique_identifiers and compare_on.")

        if len(new_df) == 0:
            logger.info(f"All results have been previously ingested for this dataframe. The next dataframe will be processed.")
            return

        return new_df

    def pop_ingested_entities(
            self,
            dataframe: pd.DataFrame,
            unique_identifiers: list[str],
    ) -> pd.DataFrame:

        new_df = dataframe.copy()

        list_entities = self._list_all_identifiers(dataframe, unique_identifiers)
        list_entities_in_result_schema = self._entities_on_result_schema(list_entities)

        for identifier in unique_identifiers:
            new_df = new_df.loc[~new_df[identifier].isin(list_entities_in_result_schema)]

        return new_df

    def get_existing_results(
            self,
            dataframe: pd.DataFrame,
            unique_identifiers: list[str],
            compare_on: list[str] = None,
    ) -> (pd.DataFrame, list[str]):

        list_entities = self._list_all_identifiers(dataframe, unique_identifiers)
        list_columns_to_build_results = self._list_variables_to_build_results_df(unique_identifiers, compare_on)
        results_df, list_results_id = self._build_results_df(list_entities, list_columns_to_build_results)

        return results_df, list_results_id

    def _list_all_identifiers(self, df: pd.DataFrame, unique_identifiers: list[str]) -> list[str]:

        list_entities: list[str] = []

        for variable in unique_identifiers:
            list_values = list_unique_values_in_column(df, variable)
            list_entities.extend(list_values)

        return list_entities

    def _list_variables_to_build_results_df(self, unique_identifiers: list[str], compare_on: list[str]) -> list[str]:
        list_variables = unique_identifiers
        if compare_on:
            for variable in compare_on:
                if variable not in list_variables:
                    list_variables.append(variable)
        return list_variables

    def _build_results_df(self, list_entities: list[str], list_variables: list[str]) -> (pd.DataFrame, list[str]):
        # get assays results
        list_pageiter_results = self._wrapper.assay_results.get_by_api_ids(
            list_entities,
            self.schema['id']
        )

        # build existing results dataframe and get list_assay_result_id
        if list_pageiter_results:

            list_result_id = self._wrapper.assay_results.list_assay_result_api_id(list_pageiter_results)

            dict_results = self._wrapper.assay_results.dict_variable_to_list_results(
                list_variables,
                list_pageiter_results
            )

            # create dataframe
            results_df = pd.DataFrame.from_dict(dict_results)

            if FieldType.BLOB_LINK not in self.schema['variable_to_type'].values():
                pass
                logger.info(f"No columns containing blobs to transform.")
            else:
                results_df = self._transform_blob_into_name(results_df)
        else:
            list_result_id = []
            results_df = pd.DataFrame()

        return results_df, list_result_id

    def _transform_blob_into_name(self, df: pd.DataFrame) -> pd.DataFrame:

        list_blobs = []
        for column in df.columns:
            if self.schema['variable_to_type'][column] == FieldType.BLOB_LINK:
                list_blobs.extend(list_unique_values_in_column(df, column, drop_na=True))

        if len(list_blobs) > 0:
            list_entity_blobs = self._wrapper.blobs.get_blobs_by_id(list_blobs)
            dict_blob_id_to_name = self._wrapper.blobs.dict_blob_id_to_name(list_entity_blobs)

            df = df.replace(dict_blob_id_to_name)

        return df


    def _entities_on_result_schema(self, list_entities: list[str]) -> list[str]:
        list_entities_in_result_schema: list[str] = []

        for entity in list_entities:
            list_page_iter = self._wrapper.assay_results.get_by_api_ids([entity], self.schema['id'])
            if len(list_page_iter[0]) > 0:
                list_entities_in_result_schema.append(entity)
        return list_entities_in_result_schema

    def _compare_dataframe_results(
            self,
            dataframe: pd.DataFrame,
            results_dataframe: pd.DataFrame,
            compare_on: list[str]
    ) -> pd.DataFrame:

        dataframe.reset_index(drop=True, inplace=True)

        results_dataframe.reset_index(drop=True, inplace=True)

        if len(results_dataframe) > 0:
            dfall = results_dataframe.merge(
                dataframe,
                on=compare_on,
                how='right',
                indicator=True
            )

            dfall = dfall.loc[dfall['_merge'] != 'both']

            dfall.drop(columns='_merge', inplace=True)
            return dfall

        else:
            return dataframe

