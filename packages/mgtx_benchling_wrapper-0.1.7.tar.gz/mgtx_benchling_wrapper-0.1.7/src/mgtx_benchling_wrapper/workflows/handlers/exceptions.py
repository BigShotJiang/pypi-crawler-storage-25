from typing import Dict, Any

class HandlerError(Exception):
    """Base exception for handler errors"""
    def __init__(self, message: str, context: Dict[str, Any] = None):
        super().__init__(message)
        self.context = context or {}
        self.message = message

class HandlerResultIngestionError(HandlerError):
    """Exception raised when ingestion fails"""
    pass

class HandlerBlobError(HandlerError):
    pass

class HandlerSchemaError(HandlerError):
    """Exception raised when schema validation fails"""
    pass