from typing import Dict, Any

class ResolutionError(Exception):
    """Base exception for resolution errors"""
    def __init__(self, message: str, context: Dict[str, Any] = None):
        super().__init__(message)
        self.context = context or {}
        self.message = message

class SchemaResolverError(ResolutionError):
    """Raised when errors arise for blob transformation"""
    pass

class InvalidInputForSchemaResolver(SchemaResolverError):
    """ Raised when the list of entities is a mix of custom entities, mixture preps and containers"""

    def __init__(self, list_entities: list[str]):
        super().__init__(
            f"The entities provided in {list_entities} is a mix of custom entities, mixture preps and or containers. "
            f"Only one type the mentioned types can be provided"
        )