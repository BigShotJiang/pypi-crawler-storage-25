from benchling_sdk.errors import BenchlingError
from mgtx_benchling_wrapper.wrapper.facade import BenchlingWrapperFacade

class SchemaResolver:
    def __init__(self, wrapper: BenchlingWrapperFacade):
        self._wrapper = wrapper

    def build_dict_resolver(self, list_entities: list[str]) -> (dict[str, list[str]], dict[str, list[str]]):

        name_to_schema: dict[str, str] = {}
        reg_to_schema: dict[str, str] = {}

        resolvers = (
            self._wrapper.custom_entities,
            self._wrapper.mixtures,
        )

        for resolver in resolvers:
            try:
                list_iter = resolver.get_by_names(list_entities)
                names, regs = resolver.dict_name_to_schema_name(list_iter)
                name_to_schema.update(names)
                reg_to_schema.update(regs)
            except BenchlingError:
                pass

        return name_to_schema, reg_to_schema