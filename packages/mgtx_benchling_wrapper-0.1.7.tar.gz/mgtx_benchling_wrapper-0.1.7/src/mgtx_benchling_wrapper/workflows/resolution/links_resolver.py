from benchling_sdk.models import (
    CustomEntity,
    Mixture
)
from mgtx_benchling_wrapper.wrapper.facade import BenchlingWrapperFacade
from benchling_sdk.errors import BenchlingError
from benchling_sdk.helpers.pagination_helpers import Optional, List

class LinkResolver:
    def __init__(self, wrapper: BenchlingWrapperFacade):
        self._wrapper = wrapper

    def build_list_resolver(self, list_entities: list[str]) -> Optional[List[CustomEntity | Mixture]]:

        list_entity_objects: Optional[List[CustomEntity | Mixture]] = []

        resolvers = (
            self._wrapper.custom_entities,
            self._wrapper.mixtures
        )

        for resolver in resolvers:
            try:
                list_objs = resolver.get_by_names(list_entities)
                if len(list_objs) > 0:
                    list_entity_objects.extend(list_objs)
            except BenchlingError:
                pass

        return list_entity_objects

    def build_dict_resolver(self, list_entities: Optional[List[CustomEntity | Mixture]]) -> (dict[str, list[str]], dict[str, list[str]]):

        name_to_api_id: dict[str, str] = {}
        reg_to_api_id: dict[str, str] = {}

        resolvers = (
            self._wrapper.custom_entities,
            self._wrapper.mixtures
        )

        for resolver in resolvers:
            try:
                names, regs = resolver.dict_name_to_api_id(list_entities)
                name_to_api_id.update(names)
                reg_to_api_id.update(regs)
            except BenchlingError:
                pass

        return name_to_api_id, reg_to_api_id

    def build_dict_to_schema_resolver(self, list_entities: Optional[List[CustomEntity | Mixture]]) -> (dict[str, list[str]], dict[str, list[str]]):

        name_to_schema: dict[str, str] = {}
        reg_to_schema: dict[str, str] = {}

        resolvers = (
            self._wrapper.custom_entities,
            self._wrapper.mixtures,
        )

        for resolver in resolvers:
            try:
                names, regs = resolver.dict_name_to_schema_name(list_entities)
                name_to_schema.update(names)
                reg_to_schema.update(regs)
            except BenchlingError:
                pass

        return name_to_schema, reg_to_schema
