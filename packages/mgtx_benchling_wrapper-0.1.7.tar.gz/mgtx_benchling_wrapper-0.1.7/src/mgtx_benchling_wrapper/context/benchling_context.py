from functools import cache
from typing import Optional

from benchling_sdk.benchling import Benchling
from benchling_sdk.apps.framework import App
from benchling_sdk.auth.client_credentials_oauth2 import ClientCredentialsOAuth2
from benchling_sdk.models.webhooks.v0 import WebhookEnvelopeV0

from mgtx_benchling_wrapper.client.benchling_client import create_benchling_client


class BenchlingContext:
    """
    Unified authentication + tenant context.
    """

    def __init__(
        self,
        *,
        client_id: str,
        client_secret: str,
        base_url: str,
        token_url: Optional[str] = None,
        app_id: Optional[str] = None,
    ):
        self._client_id = client_id
        self._client_secret = client_secret
        self._base_url = base_url
        self._token_url = token_url
        self._app_id = app_id

    @cache
    def _auth(self):
        return ClientCredentialsOAuth2(self._client_id, self._client_secret, self._token_url)

    @cache
    def benchling(self) -> Benchling:
        return create_benchling_client(
            url=self._base_url,
            auth=self._auth(),
        )

    @cache
    def app(self) -> App:
        if self._app_id is None:
            raise RuntimeError("App requested but no app_id provided")
        return App(self._app_id, self.benchling())

    @classmethod
    def from_webhook(cls, webhook: WebhookEnvelopeV0, *, client_id, client_secret):
        return cls(
            client_id=client_id,
            client_secret=client_secret,
            base_url=webhook.base_url,
            app_id=webhook.app.id,
        )
