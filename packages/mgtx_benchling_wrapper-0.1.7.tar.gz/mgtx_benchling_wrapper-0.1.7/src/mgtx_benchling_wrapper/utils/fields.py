def create_fields_dict(
        list_field_names: list,
        list_field_values: list
) -> dict:
    """ Creates a dictionary with the format {field_name:'value':{field_value}}
    Args:
        list_field_names (list): list containing the field names (usually the column names of dataframe)
        list_field_values (list): values of the fields (usually a row in a dataframe)
    Return:
        final_dict (dict): a dictionary of the format to input in fields.
    """
    list_word_value = ['value'] * len(list_field_names)
    final_dict = {u: {v: w} for (u, v, w) in zip(list_field_names, list_word_value, list_field_values)}

    return final_dict