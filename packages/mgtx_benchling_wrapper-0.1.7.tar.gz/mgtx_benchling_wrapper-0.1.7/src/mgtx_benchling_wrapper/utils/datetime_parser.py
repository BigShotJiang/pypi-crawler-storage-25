import warnings
import pandas as pd
import re
import datetime

def parse_datetime(value):
    if pd.isna(value):
        return None

    if isinstance(value, (pd.Timestamp, datetime.date)):
        return pd.Timestamp(value)

    if _is_ambiguous_date(value):
        warnings.warn(
            f"Ambiguous date format detected '{value}'. "
            f"Assuming day-first format (DD/MM/YYYY).",
            UserWarning
        )
        return pd.to_datetime(value, errors="raise", dayfirst=True, format='mixed')

    return pd.to_datetime(
        value,
        errors="raise",
        dayfirst=True
    )


def _is_ambiguous_date(value: str) -> bool:
    """
    Detect ambiguous numeric date formats like 01/02/2024
    where both day and month <= 12.
    """
    if not isinstance(value, str):
        return False

    pattern = r"^\d{1,2}[/-]\d{1,2}[/-]\d{4}$"
    if not re.match(pattern, value.strip()):
        return False

    parts = re.split(r"[/-]", value)
    day, month, _ = map(int, parts)

    return day <= 12 and month <= 12