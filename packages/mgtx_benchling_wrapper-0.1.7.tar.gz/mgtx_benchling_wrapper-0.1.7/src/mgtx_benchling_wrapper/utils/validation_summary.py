from mgtx_benchling_wrapper.workflows.models.types import ValidationResult

def get_validation_summary(result: ValidationResult) -> str:
    """Generate human-readable validation summary."""
    if result.is_valid:
        summary = "✓ Validation passed"
        if result.warnings:
            summary += f" with {len(result.warnings)} warning(s)"
        return summary

    summary = f"✗ Validation failed with {len(result.errors)} error(s):\n"

    for i, error in enumerate(result.errors, 1):
        summary += f"\n{i}. {error.message}"
        if hasattr(error, 'context') and error.context:
            summary += f"\n   Context: {error.context}"

    if result.warnings:
        summary += f"\n\nWarnings ({len(result.warnings)}):\n"
        for warning in result.warnings:
            summary += f"  - {warning}\n"

    return summary