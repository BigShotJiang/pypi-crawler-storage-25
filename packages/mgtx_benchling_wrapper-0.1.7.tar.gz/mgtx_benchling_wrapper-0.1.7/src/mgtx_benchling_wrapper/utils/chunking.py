def chunk_list(lst: list, chunk_n: int):
    """
    Chunking the list into chunks of chunk_n elements.
    """
    for i in range(0, len(lst), chunk_n):
        yield lst[i:i + chunk_n]
