import base64
import hashlib
import os.path

def create_image_blob_payload(
        image_path: str,
        mime_type="image/png",
        blob_type="VISUALIZATION"):
    """
    Create a payload for uploading an image blob through the API.
    """
    try:
        with open(image_path, "rb") as image_file:
            image_data = image_file.read()
    except FileNotFoundError:
        raise Exception(f"Blob file not found: {image_path}")

    #get name of the image
    _,tail = os.path.split(image_path)

    name = tail.split(".")[0]

    # Encode the binary data to base64
    data64 = base64.b64encode(image_data).decode('utf-8')

    # Calculate the MD5 hash of the image data
    md5_hash = hashlib.md5(image_data).hexdigest()

    # Create the payload
    payload = {
        "data64": data64,
        "md5": md5_hash,
        "mimeType": mime_type,
        "name": name,
        "type": blob_type
    }

    return payload, name