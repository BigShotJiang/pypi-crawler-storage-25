import pandas as pd

def compare_dataframe_columns(
        dataframe: pd.DataFrame,
        new_dataframe: pd.DataFrame,
        column_name: str
) -> list[str]:

    list_missing_values = []
    org_column = list(dataframe[column_name])
    new_column = list(new_dataframe[column_name])

    for value in org_column:
        if value in new_column:
            if value not in list_missing_values:
                if value is not None:
                    list_missing_values.append(value)

    return list_missing_values