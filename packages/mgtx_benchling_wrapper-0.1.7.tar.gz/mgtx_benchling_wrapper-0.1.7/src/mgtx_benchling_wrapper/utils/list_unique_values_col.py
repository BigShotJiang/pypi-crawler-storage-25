import pandas as pd

def list_unique_values_in_column(
        dataframe: pd.DataFrame,
        column_name: str,
        drop_na: bool = False
) -> list[str]:
    if drop_na:
        return dataframe[column_name].dropna().unique().tolist()
    else:
        return dataframe[column_name].unique().tolist()