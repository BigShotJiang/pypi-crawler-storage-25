import pandas as pd

def substitute_with_dict(
        dataframe: pd.DataFrame,
        column_name: str,
        dict_orig_to_api: dict
) -> pd.DataFrame:
    dataframe[column_name] = dataframe[column_name].replace(dict_orig_to_api)

    return dataframe