import logging
import os
from logging.handlers import RotatingFileHandler

def get_logger(name: str, file_log_level: str | int, console_log_level: str | int, console_filter: str | None = None) -> logging.Logger:
    logger = logging.getLogger(name)

    # Prevent duplicate handlers
    if logger.handlers:
        return logger

    logger.setLevel(logging.DEBUG)

    # Factory function for creating level filters
    def level_filter(level_name: str):
        def filter_func(record):
            return record.levelname == level_name
        return filter_func

    # Create formatters
    console_format = logging.Formatter('%(asctime)s | %(name)s | %(levelname)s | line:%(lineno)d | %(message)s')
    file_format = logging.Formatter('%(asctime)s | %(name)s | %(levelname)s | %(message)s')


    # initiating a console handler
    console_handler = logging.StreamHandler()
    console_handler.setLevel(console_log_level)
    console_handler.setFormatter(console_format)
    # Add filter if specified
    if console_filter:
        console_handler.addFilter(level_filter(console_filter))

    logger.addHandler(console_handler)

    # Environment-variable-controlled file logging
    enable_file_logging = os.getenv("APP_DEBUG_LOGS") == "1"

    if enable_file_logging:
        file_handler = RotatingFileHandler(
            "app.log",
            maxBytes=5_000_000,
            backupCount=3,
            encoding="utf-8"
        )

        file_handler.setLevel(file_log_level)
        file_handler.setFormatter(file_format)

        logger.addHandler(file_handler)

    return logger