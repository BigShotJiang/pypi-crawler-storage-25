from benchling_sdk.benchling import Benchling
from ._customentities import CustomEntityService
from ._assayresults import AssayResultsService
from ._blobs import BlobsService
from ._containers import ContainersService
from ._dropdowns import DropdownsService
from ._entry import EntryService
from ._mixtures import MixturesService
from ._task import TaskService
from ._schemas import SchemasService
from ._projects import ProjectsService


class BenchlingWrapperFacade:
    """
    Public API facade.
    """

    def __init__(self, benchling: Benchling):
        self.custom_entities = CustomEntityService(benchling=benchling)
        self.assay_results = AssayResultsService(benchling=benchling)
        self.blobs = BlobsService(benchling=benchling)
        self.containers = ContainersService(benchling=benchling)
        self.dropdowns = DropdownsService(benchling=benchling)
        self.entry = EntryService(benchling=benchling)
        self.mixtures = MixturesService(benchling=benchling)
        self.task = TaskService(benchling=benchling)
        self.schemas = SchemasService(benchling=benchling)
        self.projects = ProjectsService(benchling=benchling)




