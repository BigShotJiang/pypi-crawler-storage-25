from benchling_sdk.benchling import Benchling
from benchling_sdk.models import (
    BulkCreateCustomEntitiesAsyncTaskResponse,
    CustomEntity,
    CustomEntityUpdate,
    CustomEntityCreate,
    CustomEntityBulkCreate,
)
from benchling_sdk.helpers.task_helpers import TaskHelper
from benchling_api_client.models.naming_strategy import NamingStrategy
from benchling_sdk.helpers.serialization_helpers import fields
from benchling_sdk.helpers.pagination_helpers import List, Optional
from mgtx_benchling_wrapper.utils.chunking import chunk_list
from mgtx_benchling_wrapper.utils.fields import create_fields_dict

PAGE_SIZE = 100
CHUNK_N = 100

class CustomEntityService:

    def __init__(self, benchling: Benchling):

        self._benchling = benchling


    def get_by_name(
            self,
            entity: str=None,
            name_includes: str=None,
            schema_id: str=None
    ) -> CustomEntity:
        """returns the entity response for the given entity name.
            """
        return self._benchling.custom_entities.list(name=entity, name_includes=name_includes,
                                                   schema_id=schema_id, page_size=PAGE_SIZE).first()


    def get_by_api_id(self, entity: str) -> CustomEntity:
        """returns the entity response for the given entity name.
            """
        return self._benchling.custom_entities.get_by_id(name=entity)


    def get_by_names(
            self,
            entity_names: list,
            chunk_n=CHUNK_N
    ) -> Optional[List[CustomEntity]]:
        """
        Get the entities for the given list of entity names.
        """
        result = []
        for chunk in chunk_list(entity_names, chunk_n):
            result.extend(self._benchling.custom_entities.list(names_any_of=chunk, page_size=PAGE_SIZE))
        return result


    def update(
            self,
            list_field_names:list,
            list_field_values:list,
            entity: CustomEntity
    ) -> None:
        """Updates fields of a custom entity.
        """
        entity_to_update = CustomEntityUpdate(fields=fields(create_fields_dict(list_field_names,list_field_values)))
        self._benchling.custom_entities.update(entity_id=entity.id, entity=entity_to_update)


    def create(
            self,
            custom_entity_to_create: CustomEntityCreate
    ) -> None:
        """Creates an assay run.
        """
        self._benchling.custom_entities.create(custom_entity_to_create)


    def create_bulk(
            self,
            list_custom_entities_bulk:list[CustomEntityBulkCreate]
    ) -> TaskHelper[BulkCreateCustomEntitiesAsyncTaskResponse]:
        '''
        Registers custom entities in Bulk.
        Returns async task
        '''
        return self._benchling.custom_entities.bulk_create(entities=list_custom_entities_bulk)


    @staticmethod
    def name(entity: CustomEntity) -> str:
        """
        Get the name of the entity.
        """
        try:
            return entity.name
        except IndexError:
            raise ValueError("Can not get entity name")


    @staticmethod
    def weburl(entity: CustomEntity) -> str:
        """
        Get the weburl of the entity.
        """
        try:
            return entity.web_url
        except IndexError:
            raise ValueError("Can not get entity URL")


    @staticmethod
    def id(entity: CustomEntity) -> str:
        """
        Get the api ID of the entity.
        """
        try:
            return entity.id
        except IndexError:
            raise ValueError("Can not get entity api id")


    @staticmethod
    def registry_id(entity: CustomEntity) -> str:
        """
        Get Registry ID of a CustomEntity object.
        """
        try:
            return entity.entity_registry_id
        except IndexError:
            raise ValueError("Can not get entity registry id")


    @staticmethod
    def field_value(
            entity: CustomEntity,
            field_name: str
    ) -> str:
        """
        Get the value of a field.
        """
        try:
            return entity.fields[field_name].value
        except IndexError:
            raise ValueError(f"Can not get field value for {field_name}")


    @staticmethod
    def schema_name(
            entity: CustomEntity,
    ) -> str:
        try:
            return entity.schema.name
        except IndexError:
            raise ValueError(f"Can not get schema name")


    @staticmethod
    def display_field_value(
            entity: CustomEntity,
            field_name: str
    ) -> str:
        """
        Get the displayed value for a field.
        """
        try:
            return entity.fields[field_name].display_value
        except IndexError:
            raise ValueError(f"Can not get field display value for {field_name}")

    #this is equivelant to the original build_custom_entity_assay
    @staticmethod
    def object_create(
            assay_name: str,
            list_field_names: list,
            list_field_values: list,
            schema_id: str,
            registry_id: str,
            naming_strategy: NamingStrategy
    ) -> CustomEntityCreate:
        """
        Builds a custom entity object.
        """
        return CustomEntityCreate(fields=fields(create_fields_dict(list_field_names, list_field_values)),
                                  name=assay_name,
                                  naming_strategy=naming_strategy,
                                  schema_id=schema_id,
                                  registry_id=registry_id
                                  )

    @staticmethod
    def object_create_bulk(
            entity_name: str,
            list_field_names: list,
            list_field_values: list,
            registry_id: str,
            schema_id: str,
            naming_strategy: NamingStrategy
    ) -> CustomEntityBulkCreate:
        """
        Builds a bulk custom entity object.
        """
        return CustomEntityBulkCreate(fields=fields(create_fields_dict(list_field_names,list_field_values)),
                                      name= entity_name,
                                      naming_strategy=naming_strategy,
                                      schema_id=schema_id,
                                      registry_id=registry_id
                                      )

    @staticmethod
    def dict_name_to_api_id(
            list_pageit: Optional[List[CustomEntity]]
    ) -> (dict[str, str],dict[str, str]):

        dict_name_to_id: dict[str, str] = {}
        dict_reg_to_id: dict[str, str] = {}

        for page in list_pageit:
            for custom_entity in page:
                registry_id = CustomEntityService.registry_id(custom_entity)
                name = CustomEntityService.name(custom_entity)
                api_id = CustomEntityService.id(custom_entity)
                dict_name_to_id[name] = api_id
                dict_reg_to_id[registry_id] = api_id
        return dict_name_to_id, dict_reg_to_id

    @staticmethod
    def dict_name_to_schema_name(
            list_pageit:Optional[List[CustomEntity]],
    ) -> (dict[str, str], dict[str, str]):

        dict_name_to_schema: dict[str, str] = {}
        dict_reg_to_schema: dict[str, str] = {}

        for page in list_pageit:
            for custom_entity in page:
                registry_id = CustomEntityService.registry_id(custom_entity)
                name = CustomEntityService.name(custom_entity)
                schema_name = CustomEntityService.schema_name(custom_entity)
                dict_name_to_schema[name] = schema_name
                dict_reg_to_schema[registry_id] = schema_name
        return dict_name_to_schema, dict_reg_to_schema