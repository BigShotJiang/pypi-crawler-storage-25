from benchling_api_client.v2.beta.models.registration_table_note_part import RegistrationTableNotePart
from benchling_sdk.benchling import Benchling
from benchling_sdk.models import (
    Entry,
    EntryDay,
    SimpleNotePart,
    RegistrationTableNotePart,
    ResultsTableNotePart
)
from benchling_sdk.helpers.pagination_helpers import PageIterator

PAGE_SIZE = 100

class EntryService:

    def __init__(self, benchling: Benchling):

        self._benchling = benchling

    def get_by_name(self, entry_name:str)->PageIterator[Entry]:
        """
        Get Entry object from entry name.
        """
        return self._benchling.entries.list_entries(name=entry_name, page_size=PAGE_SIZE)

    @staticmethod
    def id(entry: Entry) -> str:
        """
        Get the entry id.
        """
        try:
            return entry.id
        except IndexError:
            raise ValueError(f"Can not get entry id.")

    @staticmethod
    def name(entry: Entry) -> str:
        """
        Get the entry id.
        """
        try:
            return entry.name
        except IndexError:
            raise ValueError(f"Can not get entry id.")

    @staticmethod
    def notes(day:EntryDay) -> list[SimpleNotePart | RegistrationTableNotePart | ResultsTableNotePart]:
        return day.notes

    @staticmethod
    def note_api_id(note: SimpleNotePart | RegistrationTableNotePart | ResultsTableNotePart) -> str:
        return note.api_id

    @staticmethod
    def result_note_table_id(note:ResultsTableNotePart) -> str:
        return note.assay_result_schema_id

    @staticmethod
    def registration_note_table_id(note:RegistrationTableNotePart) -> str:
        return note.entity_schema_id

    @staticmethod
    def days(entry:Entry) -> list[EntryDay]:
        return entry.days

    @staticmethod
    def dict_id_to_name(list_entries: list[Entry]) -> dict[str, str]:

        dict_id_to_name = {}

        for entry in list_entries:
            dict_id_to_name[EntryService.id(entry)] = EntryService.name(entry)

        return dict_id_to_name

    @staticmethod
    def dict_entry_to_days(list_entries: list[Entry]) -> dict[str, list[EntryDay]]:

        dict_entry_to_days = {}

        for entry in list_entries:
            list_days = EntryService.days(entry)
            dict_entry_to_days[EntryService.id(entry)] = list_days

        return dict_entry_to_days

    @staticmethod
    def dict_entry_to_notes(
            dict_entry_to_days:dict
    ) -> dict[str, list[SimpleNotePart | RegistrationTableNotePart | ResultsTableNotePart]]:

        dict_entry_to_notes = {}

        for entry in dict_entry_to_days:
            list_notes = []
            for day in dict_entry_to_days[entry]:
                list_notes.extend(EntryService.notes(day))
            dict_entry_to_notes[entry] = list_notes

        return dict_entry_to_notes

    @staticmethod
    def dict_entry_to_registrationtableid(
            dict_entry_to_notes:dict[str, list[SimpleNotePart | RegistrationTableNotePart | ResultsTableNotePart]]
    ) -> dict[str, dict[str, str]]:

        dict_entry_to_registrationtableid = {}

        for entry in dict_entry_to_notes:
            dict_notes = {}
            for note in dict_entry_to_notes[entry]:
                if isinstance(note, RegistrationTableNotePart):
                    dict_notes[EntryService.note_api_id(note)] = EntryService.registration_note_table_id(note)
            if  dict_notes:
                dict_entry_to_registrationtableid[entry] =  dict_notes

        return dict_entry_to_registrationtableid

    @staticmethod
    def dict_entry_to_resultstableid(
            dict_entry_to_notes: dict[str, list[SimpleNotePart | RegistrationTableNotePart | ResultsTableNotePart]]
    ) -> dict[str, dict[str, str]]:

        dict_entry_to_resultstableid = {}

        for entry in dict_entry_to_notes:
            dict_notes = {}
            for note in dict_entry_to_notes[entry]:
                if isinstance(note, ResultsTableNotePart):
                    dict_notes[EntryService.note_api_id(note)] = EntryService.result_note_table_id(note)
            if dict_notes:
                dict_entry_to_resultstableid[entry] = dict_notes

        return dict_entry_to_resultstableid

    @staticmethod
    def list_entries(pageiterator:PageIterator[Entry]) -> list[Entry]:

        list_entries = []

        for page in pageiterator:
            for entry in page:
                list_entries.append(entry)

        return list_entries

    @staticmethod
    def get_dict_results_table_id(
            list_entries: list[Entry],
    ) -> dict[str, dict[str, str]]:

        dict_entry_to_days = EntryService.dict_entry_to_days(list_entries)

        dict_entry_to_notes = EntryService.dict_entry_to_notes(dict_entry_to_days)

        dict_entry_to_resultstableid = EntryService.dict_entry_to_resultstableid(dict_entry_to_notes)

        return dict_entry_to_resultstableid