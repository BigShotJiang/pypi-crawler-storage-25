from benchling_sdk.benchling import Benchling
from benchling_sdk.models import (
    Project
)

PAGE_SIZE = 100

class ProjectsService:

    def __init__(self, benchling: Benchling):

        self._benchling = benchling

    def get_project_by_id(
            self,
            project_id: str
    ) -> Project:
        return self._benchling.projects.get_by_id(project_id)