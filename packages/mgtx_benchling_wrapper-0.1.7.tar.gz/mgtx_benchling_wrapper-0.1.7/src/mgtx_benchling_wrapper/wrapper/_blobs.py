from benchling_sdk.benchling import Benchling
from benchling_sdk.models import (
    Blob,
    BlobCreate,
    BlobCreateType
)
from typing import List

PAGE_SIZE = 100
CHUNK_N = 100

class BlobsService:

    def __init__(self, benchling: Benchling):

        self._benchling = benchling


    def get_blobs_by_id(self, list_blob_ids: list[str]) -> List[Blob]:
        return self._benchling.blobs.bulk_get(list_blob_ids)


    def create_and_get_id(self, blob: BlobCreate) -> str:
        """
        Creates a blob object on Benchling and returns ID.
        """
        return self._benchling.blobs.create(blob).id


    @staticmethod
    def object_image_png_create(payload, mime_type='image/png'):
        """Build a blob object from an image payload.
        Args:
            payload: a payload created from an image file.
        """

        return BlobCreate(data64=payload['data64'],
                          md5=payload['md5'],
                          name=payload['name'],
                          type=BlobCreateType.VISUALIZATION,
                          mime_type=mime_type)

    @staticmethod
    def name(blob: Blob) -> str:
        """
        Get the api ID of the container.
        """
        try:
            return blob.name
        except IndexError:
            raise ValueError("Can not get container barcode")

    @staticmethod
    def id(blob: Blob) -> str:
        """
        Get the api ID of the container.
        """
        try:
            return blob.id
        except IndexError:
            raise ValueError("Can not get container barcode")

    @staticmethod
    def dict_blob_id_to_name(list_blob: list[Blob]) -> dict[str, str]:
        dict_blob_id_to_name: dict[str, str] = {}
        for blob in list_blob:
            dict_blob_id_to_name[blob._id] = blob._name
        return dict_blob_id_to_name