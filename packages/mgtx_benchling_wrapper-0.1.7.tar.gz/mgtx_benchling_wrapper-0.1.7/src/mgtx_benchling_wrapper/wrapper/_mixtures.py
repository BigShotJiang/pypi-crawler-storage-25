from benchling_sdk.benchling import Benchling
from benchling_sdk.models import (
    Mixture
)
from benchling_sdk.helpers.pagination_helpers import Optional, List
from mgtx_benchling_wrapper.utils.chunking import chunk_list

PAGE_SIZE = 100
CHUNK_N = 100

class MixturesService:

    def __init__(self, benchling: Benchling):

        self._benchling = benchling


    def get_by_name(
            self,
            mixture: str=None,
            name_includes: str=None,
            schema_id: str=None
    ) -> Mixture:
        """returns the entity response for the given entity name.
            """
        return self._benchling.mixtures.list(name=mixture, name_includes=name_includes,
                                                   schema_id=schema_id, page_size=PAGE_SIZE).first()

    def get_by_names(
            self,
            mixture_names: list,
            chunk_n=CHUNK_N
    ) -> Optional[List[Mixture]]:
        """
        Get the entities for the given list of entity names.
        """
        result = []
        for chunk in chunk_list(mixture_names, chunk_n):
            result.extend(self._benchling.mixtures.list(names_any_of=chunk, page_size=PAGE_SIZE))
        return result


    @staticmethod
    def name(mixture: Mixture) -> str:
        """
        Get the mixture name for the given mixture.
        """
        try:
            return mixture.name
        except IndexError:
            raise ValueError("Can not get mixture name")

    @staticmethod
    def schema_name(mixture: Mixture) -> str:
        """
        Get the mixture name for the given mixture.
        """
        try:
            return mixture.schema.name
        except IndexError:
            raise ValueError("Can not get mixture schema name")


    @staticmethod
    def id(mixture: Mixture) -> str:
        """
        Get the mixture api id for the given mixture.
        """
        try:
            return mixture.id
        except IndexError:
            raise ValueError("Can not get mixture id")


    @staticmethod
    def registry_id(mixture: Mixture) -> str:
        """
        Get the mixture registry id for the given mixture.
        """
        try:
            return mixture.entity_registry_id
        except IndexError:
            raise ValueError("Can not get mixture entity registry id")

    @staticmethod
    def dict_name_to_api_id(
            list_pageit: Optional[List[Mixture]]
    ) -> (dict[str, str], dict[str, str]):

        dict_name_to_id: dict[str, str] = {}
        dict_reg_to_id: dict[str, str] = {}

        for page in list_pageit:
            for mixture in page:
                registry_id = MixturesService.registry_id(mixture)
                name = MixturesService.name(mixture)
                api_id = MixturesService.id(mixture)
                dict_name_to_id[name] = api_id
                dict_name_to_id[registry_id] = api_id
        return dict_name_to_id, dict_reg_to_id

    @staticmethod
    def dict_name_to_schema_name(
            list_pageit: Optional[List[Mixture]],
    ) -> (dict[str, str], dict[str, str]):

        dict_name_to_schema: dict[str, str] = {}
        dict_reg_to_schema: dict[str, str] = {}

        for page in list_pageit:
            for mixture in page:
                registry_id = MixturesService.registry_id(mixture)
                name = MixturesService.name(mixture)
                schema_name = MixturesService.schema_name(mixture)
                dict_name_to_schema[name] = schema_name
                dict_reg_to_schema[registry_id] = schema_name
        return dict_name_to_schema, dict_reg_to_schema
