from benchling_sdk.benchling import Benchling
from benchling_sdk.models import (
    Container
)
from mgtx_benchling_wrapper.utils.chunking import chunk_list

PAGE_SIZE = 100
CHUNK_N = 100

class ContainersService:

    def __init__(self, benchling: Benchling):

        self._benchling = benchling

    def get_by_name(
            self,
            entity: str=None,
            name_includes: str=None
    ) -> Container:
        """returns the container response for the given container name.
           """
        return self._benchling.containers.list(name=entity, name_includes=name_includes, page_size=PAGE_SIZE).first()


    def get_by_names(
            self,
            container_barcodes:list,
            chunk_n=CHUNK_N
    ) -> list[Container]:
        """
        Returns a list of containers in a format of a list. Retrieves containers as chunk_n.
        """
        result = []
        for chunk in chunk_list(container_barcodes, chunk_n):
            result.extend(*self._benchling.containers.list(barcodes=chunk, page_size=PAGE_SIZE))
        return result

    @staticmethod
    def content(container: Container) -> str:
        try:
            return container.contents[0].entity
        except IndexError:
            raise ValueError("Can not get container content name")


    @staticmethod
    def id(container: Container) -> str:
        """
        Get the api ID of the container.
        """
        try:
            return container.id
        except IndexError:
            raise ValueError("Can not get container api id")

    @staticmethod
    def barcode(container: Container) -> str:
        """
        Get the api ID of the container.
        """
        try:
            return container.barcode
        except IndexError:
            raise ValueError("Can not get container barcode")

    @staticmethod
    def name(container: Container) -> str:
        """
        Get the api ID of the container.
        """
        try:
            return container.name
        except IndexError:
            raise ValueError("Can not get container barcode")

    @staticmethod
    def schema_name(container: Container) -> str:
        try:
            return container.schema.name
        except IndexError:
            raise ValueError("Can not get container schema name")

    @staticmethod
    def dict_name_to_api_id(
            list_container: list[Container]
    ) -> (dict[str, str], dict[str, str]):
        dict_name_to_id = {}
        dict_reg_to_id = {}

        for result in list_container:
            barcode = ContainersService.barcode(result)
            name = ContainersService.name(result)
            api_id = ContainersService.id(result)
            dict_name_to_id[name] = api_id
            dict_reg_to_id[barcode] = api_id
        return dict_name_to_id, dict_reg_to_id

    @staticmethod
    def dict_name_to_schema_name(
            list_container: list[Container],
    ) -> (dict[str, str], dict[str, str]):

        dict_name_to_schema = {}
        dict_reg_to_schema = {}

        for result in list_container:
            barcode = ContainersService.barcode(result)
            name = ContainersService.name(result)
            schema_name = ContainersService.schema_name(result)
            dict_name_to_schema[name] = schema_name
            dict_reg_to_schema[barcode] = schema_name
        return dict_name_to_schema, dict_reg_to_schema

    @staticmethod
    def dict_name_to_content(
            list_container: list[Container],
    ) -> (dict[str, str]):

        dict_barcode_to_content = {}

        for result in list_container:
            barcode = ContainersService.barcode(result)
            content = ContainersService.content(result)
            dict_barcode_to_content[barcode] = content
        return dict_barcode_to_content


