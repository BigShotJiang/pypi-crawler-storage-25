from benchling_sdk.benchling import Benchling
from benchling_sdk.models import (
    Dropdown,
    DropdownOption
)

class DropdownsService:

    def __init__(self, benchling: Benchling):

        self._benchling = benchling


    def get_from_api_id(self, dropdown_id: str) -> Dropdown:
        """Get dropdown variants by dropdown id.
        """
        return self._benchling.dropdowns.get_by_id(dropdown_id)

    @staticmethod
    def options(dropdown: Dropdown) -> list:
        """
        Get the api ID of the dropdown option.
        """
        try:
            return dropdown.options
        except IndexError:
            raise ValueError("Can not get dropdown option")

    @staticmethod
    def name(dropdown_option: DropdownOption) -> str:
        """
        Get the api ID of the dropdown option.
        """
        try:
            return dropdown_option.name
        except IndexError:
            raise ValueError("Can not get dropdown option name")

    @staticmethod
    def id(dropdown_option: DropdownOption) -> str:
        """
        Get the api ID of the container.
        """
        try:
            return dropdown_option.id
        except IndexError:
            raise ValueError("Can not get container api id")


    @staticmethod
    def dict_option_api_id(dropdown: Dropdown) -> dict:
        """ Maps the dropdown options to it's API ID
        """
        options = DropdownsService.options(dropdown)
        dict_options = {DropdownsService.name(option): DropdownsService.id(option) for option in options}
        return dict_options