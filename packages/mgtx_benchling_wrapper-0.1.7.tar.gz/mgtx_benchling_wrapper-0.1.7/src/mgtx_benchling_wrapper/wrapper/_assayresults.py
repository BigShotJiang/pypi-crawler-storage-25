from benchling_sdk.benchling import Benchling
from benchling_sdk.models import (
    AssayResult,
    AssayResultCreate,
    AssayResultsCreateResponse,
    AssayResultTransactionCreateResponse
)
from benchling_sdk.helpers.task_helpers import TaskHelper
from benchling_sdk.helpers.serialization_helpers import fields
from benchling_sdk.helpers.pagination_helpers import Optional, List
from benchling_sdk.errors import BenchlingError
from mgtx_benchling_wrapper.utils.chunking import chunk_list
from mgtx_benchling_wrapper.utils.fields import create_fields_dict


PAGE_SIZE = 100
CHUNK_RETRIEVE = 20
CHUNK_CREATE = 100
CHUNK_BULK_NO_FRONT = 4000
CHUNK_BULK_FRONT = 500

class AssayResultsService:

    def __init__(self, benchling: Benchling):

        self._benchling = benchling


    def get_by_api_ids(
            self,
            list_entitiy_ap_id: list,
            schema_id: str
    ) -> Optional[List[AssayResult]]:
        """Gets assay results for a given list of entity api ids.
        """
        result =[]
        for chunk in chunk_list(list_entitiy_ap_id, CHUNK_RETRIEVE):
            result.extend(self._benchling.assay_results.list(entity_ids=chunk, schema_id=schema_id, page_size=PAGE_SIZE))
        return result


    def create(
            self,
            list_result_to_create: list[AssayResultCreate],
    ) -> None:
        """Creates several assay results.
        """
        for chunk in chunk_list(list_result_to_create, CHUNK_CREATE):
            self._benchling.assay_results.create(assay_results=chunk)


    def create_bulk(
            self,
            list_assay_results: list,
            table_id: str = None
    ) -> TaskHelper[AssayResultsCreateResponse]:
        """
        Creates assays results. When table is provided, the results are posted to the front end.
        """
        if table_id is None:
            CHUNK_CREATE = CHUNK_BULK_NO_FRONT
        else:
            CHUNK_CREATE = CHUNK_BULK_FRONT

        for chunk in chunk_list(list_assay_results, CHUNK_CREATE):
            return self._benchling.assay_results.bulk_create(
                assay_results=chunk,
                table_id=table_id
            )


    def archive(
            self,
            assay_api_id_list : list
    ) -> None:
        """
        Archive assay results specified in assay_api_id_list
        """
        return self._benchling.assay_results.archive(assay_result_ids=assay_api_id_list)


    def create_transaction_and_get_id(self):
        """Creates a transaction and returns the transaction ID.
        """
        return self._benchling.assay_results.create_transaction().id


    def create_results_in_transaction(
            self,
            assay_transaction_id: str,
            list_results_to_upload: list[AssayResultCreate]
    ) -> AssayResultsCreateResponse:
        """Creates results in a transaction.
        """
        return self._benchling.assay_results.create_results_in_transaction(
            transaction_id=assay_transaction_id,
            assay_results=list_results_to_upload
        )


    def commit_transaction(
            self,
            assay_transaction_id: str
    ) -> AssayResultTransactionCreateResponse:
        """Commits a transaction.
        """
        return self._benchling.assay_results.commit_transaction(transaction_id=assay_transaction_id)

    def bulk_create_commit_results_transaction(
            self,
            list_results_to_upload: list[AssayResultCreate]
    ):

            transaction_id = self.create_transaction_and_get_id()

            try:
                self.create_results_in_transaction(transaction_id, list_results_to_upload)
            except BenchlingError as e:
                print(f"Exception occurred: {e} when creating results in transaction {transaction_id}.")

            try:
                self.commit_transaction(transaction_id)
            except BenchlingError as e:
                print(f"Exception occurred: {e} when committing transaction {transaction_id}.")


    @staticmethod
    def object_create(
            list_field_names: list,
            list_field_values: list,
            schema_id: str,
            project_id: str
    ) -> AssayResultCreate:
        """Builds an assay result
        """
        return AssayResultCreate(schema_id=schema_id,
                                 project_id=project_id,
                                 fields=fields(
                                     create_fields_dict(
                                         list_field_names,
                                         list_field_values
                                     )
                                 )
                                 )

    @staticmethod
    def id(assay_result: AssayResult) -> str:
        """
        Get the api ID of the container.
        """
        try:
            return assay_result.id
        except IndexError:
            raise ValueError("Can not get assay result api id")


    @staticmethod
    def field_value(
            assay_result: AssayResult,
            field_name: str
    ) -> str:
        """
        Get the value of a field.
        """
        try:
            return assay_result.fields[field_name].value
        except IndexError:
            raise ValueError(f"Can not get field value for {field_name}.")


    @staticmethod
    def list_assay_result_api_id(
            list_pageit:Optional[List[AssayResult]]
    ) -> list[str]:
        """Gets the API ID of the entities in the PageIterator
        """
        list_api_ids = []
        for page in list_pageit:
            for result in page:
                list_api_ids.append(AssayResultsService.id(result))
        return list_api_ids


    @staticmethod
    def dict_variable_to_list_results(
            list_fields: list[str],
            list_pageit:Optional[List[AssayResult]],
    ) -> dict[str,list[str]]:

        dict_results = {field : [] for field in list_fields}

        for page in list_pageit:
            for result in page:
                for field in list_fields:
                    dict_results[field].append(AssayResultsService.field_value(result, field))
        return dict_results
