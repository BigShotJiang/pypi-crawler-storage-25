from benchling_sdk.benchling import Benchling
from benchling_sdk.models import (
    AsyncTask
)

class TaskService:

    def __init__(self, benchling: Benchling):

        self._benchling = benchling


    def get(self, task_id:str) -> AsyncTask:
        """
        Get a task object which is being used to perform an action through the API. It can be used to understand it's
        status.
        """
        return self._benchling.tasks.get_by_id(task_id=task_id)