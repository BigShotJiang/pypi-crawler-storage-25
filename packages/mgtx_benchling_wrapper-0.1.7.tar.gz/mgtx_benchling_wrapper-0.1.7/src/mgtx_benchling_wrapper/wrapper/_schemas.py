from benchling_sdk.benchling import Benchling
from benchling_sdk.helpers.pagination_helpers import PageIterator
from benchling_sdk.models import (
    AssayResultSchema,
    EntitySchema,
    ContainerSchema,
    SimpleFieldDefinitionType,
    SimpleFieldDefinition,
    FieldType
)
PAGE_SIZE = 100

class SchemasService:

    def __init__(self, benchling: Benchling):

        self._benchling = benchling

    def get_assay_result_schema_by_id(
            self,
            schema_id: str
    ) -> AssayResultSchema:
        return self._benchling.schemas.get_assay_result_schema_by_id(schema_id)

    def get_entity_schema_by_id(
            self,
            schema_id: str
    ) -> EntitySchema:
        return self._benchling.schemas.get_entity_schema_by_id(schema_id)

    def get_entity_schemas(
            self,
    ) -> PageIterator[EntitySchema]:
        return self._benchling.schemas.list_entity_schemas(page_size=PAGE_SIZE)

    def get_container_schemas(
            self,
    ) -> PageIterator[ContainerSchema]:
        return self._benchling.schemas.list_container_schemas(page_size=PAGE_SIZE)

    @staticmethod
    def name(schema: EntitySchema | AssayResultSchema) -> str:
        return schema.name

    @staticmethod
    def system_name(schema: EntitySchema | AssayResultSchema) -> str:
        return schema.system_name

    @staticmethod
    def list_schema_names(pageiter: PageIterator[EntitySchema] | PageIterator[ContainerSchema] | PageIterator[AssayResultSchema]) -> list[str]:
        list_schema_names = []
        for page in pageiter:
            for schema in page:
                list_schema_names.append(SchemasService.name(schema))
        return list_schema_names

    @staticmethod
    def dict_field_to_required(schema: EntitySchema | AssayResultSchema) -> dict[str, bool]:
        dict_name_to_required = {}
        if isinstance(schema, EntitySchema) or isinstance(schema, AssayResultSchema):
            fields = schema.field_definitions
            for field in fields:
                if field.archive_record is None:
                    dict_name_to_required[field.name] = SchemasService.field_def_required(field)
            return dict_name_to_required
        else:
            raise AttributeError

    @staticmethod
    def field_def_required(field_def: SimpleFieldDefinition) -> str:
        return field_def.is_required

    @staticmethod
    def dict_field_to_type(schema: EntitySchema | AssayResultSchema) -> dict[str, str]:
        dict_name_to_type = {}
        if isinstance(schema, EntitySchema) or isinstance(schema, AssayResultSchema):
            fields = schema.field_definitions
            for field in fields:
                if field.archive_record is None:
                    dict_name_to_type[field.name] = SchemasService.field_def_type_name(field)
            return dict_name_to_type
        else:
            raise AttributeError

    @staticmethod
    def field_def_type_name(field_def: SimpleFieldDefinitionType) -> str:
        return field_def.type.value

    @staticmethod
    def dict_field_to_dropdown_id(schema: EntitySchema | AssayResultSchema) -> dict[str, str]:
        dict_name_to_dropdown_id = {}
        if isinstance(schema, EntitySchema) or isinstance(schema, AssayResultSchema):
            fields = schema.field_definitions
            for field in fields:
                if field.archive_record is None:
                    if SchemasService.field_def_type_name(field) == 'dropdown':
                        dict_name_to_dropdown_id[field.name] = SchemasService.field_def_dropdown_id(field)
                    else:
                        dict_name_to_dropdown_id[field.name] = None
            return dict_name_to_dropdown_id
        else:
            raise AttributeError

    @staticmethod
    def dict_field_to_entity_schema_id(schema: EntitySchema | AssayResultSchema | ContainerSchema) -> dict[str, str]:
        dict_name_to_entity_schema_id = {}
        if isinstance(schema, EntitySchema) or isinstance(schema, AssayResultSchema) or isinstance(schema, ContainerSchema):
            fields = schema.field_definitions
            for field in fields:
                if field.archive_record is None:
                    if SchemasService.field_def_type_name(field) == FieldType.ENTITY_LINK or SchemasService.field_def_type_name(field) == FieldType.STORAGE_LINK:
                        if 'schemaId' in SchemasService.additional_keys(field):
                            dict_name_to_entity_schema_id[field.name] = SchemasService.field_def_schema_id(field)
                        else:
                            dict_name_to_entity_schema_id[field.name] = None
            return dict_name_to_entity_schema_id
        else:
            raise AttributeError

    @staticmethod
    def field_def_dropdown_id(field_def: SimpleFieldDefinition) -> str:
        return field_def.additional_properties['dropdownId']

    @staticmethod
    def field_def_schema_id(field_def: SimpleFieldDefinition) -> str:
        return field_def.additional_properties['schemaId']

    @staticmethod
    def field_def_display_name(field_def: SimpleFieldDefinition) -> str:
        return field_def.additional_properties['displayName']

    @staticmethod
    def dict_field_to_legal_text(schema: EntitySchema | AssayResultSchema) -> dict[str, str]:
        dict_name_to_legal_text_dropdown_id = {}
        if isinstance(schema, EntitySchema) or isinstance(schema, AssayResultSchema):
            fields = schema.field_definitions
            for field in fields:
                if field.archive_record is None:
                    if 'legalTextDropdownId' in SchemasService.additional_keys(field):
                        dict_name_to_legal_text_dropdown_id[field.name] = SchemasService.field_def_legal_text_dropdown_id(
                            field)
                    else:
                        dict_name_to_legal_text_dropdown_id[field.name] = None
            return dict_name_to_legal_text_dropdown_id
        else:
            raise AttributeError

    @staticmethod
    def dict_field_to_display_name(schema: EntitySchema | AssayResultSchema | ContainerSchema) -> dict[str, str]:
        dict_variable_display_name = {}
        if isinstance(schema, EntitySchema) or isinstance(schema, AssayResultSchema) or isinstance(schema, ContainerSchema):
            fields = schema.field_definitions
            for field in fields:
                if field.archive_record is None:
                    dict_variable_display_name[field.name] = SchemasService.field_def_display_name(field)
            return dict_variable_display_name
        else:
            raise AttributeError

    @staticmethod
    def additional_keys(field_def: SimpleFieldDefinition) -> list:
        return field_def.additional_keys

    @staticmethod
    def field_def_legal_text_dropdown_id(field_def: SimpleFieldDefinition) -> str:
        return field_def.additional_properties['legalTextDropdownId']




