from pathlib import Path

from click.testing import CliRunner

from python_dependency_linter.cli import main

FIXTURES = Path(__file__).parent / "fixtures"


def test_cli_check_with_violations(tmp_path, monkeypatch):
    config_content = """\
rules:
  - name: domain-isolation
    modules: contexts.*.domain
    allow:
      standard_library: [dataclasses, typing]
      third_party: [pydantic]
      local: [contexts.*.domain]
"""
    config_file = tmp_path / ".python-dependency-linter.yaml"
    config_file.write_text(config_content)

    # Copy sample project to tmp_path
    import shutil

    src = FIXTURES / "sample_project" / "contexts"
    dst = tmp_path / "contexts"
    shutil.copytree(src, dst)

    monkeypatch.chdir(tmp_path)
    runner = CliRunner()
    result = runner.invoke(main, ["check"])
    assert result.exit_code == 1
    assert "[domain-isolation]" in result.output
    assert "Found" in result.output


def test_cli_check_no_violations(tmp_path, monkeypatch):
    config_content = """\
rules:
  - name: allow-all
    modules: contexts.*.domain
    allow:
      standard_library: ["*"]
      third_party: ["*"]
      local: ["*"]
"""
    config_file = tmp_path / ".python-dependency-linter.yaml"
    config_file.write_text(config_content)

    import shutil

    src = FIXTURES / "sample_project" / "contexts"
    dst = tmp_path / "contexts"
    shutil.copytree(src, dst)

    monkeypatch.chdir(tmp_path)
    runner = CliRunner()
    result = runner.invoke(main, ["check"])
    assert result.exit_code == 0
    assert "No violations found." in result.output


def test_cli_check_with_include(tmp_path, monkeypatch):
    """Files outside include paths should be skipped."""
    config_content = """\
include:
  - src
rules:
  - name: domain-isolation
    modules: "**"
    deny:
      third_party: [pydantic]
"""
    config_file = tmp_path / ".python-dependency-linter.yaml"
    config_file.write_text(config_content)

    # Create files inside and outside include path
    src = tmp_path / "src"
    src.mkdir()
    (src / "__init__.py").write_text("")
    (src / "app.py").write_text("import pydantic\n")

    other = tmp_path / "other"
    other.mkdir()
    (other / "__init__.py").write_text("")
    (other / "app.py").write_text("import pydantic\n")

    monkeypatch.chdir(tmp_path)
    runner = CliRunner()
    result = runner.invoke(main, ["check"])
    assert result.exit_code == 1
    assert "src/app.py" in result.output
    assert "other/app.py" not in result.output


def test_cli_check_with_include_nested(tmp_path, monkeypatch):
    """Include should match files in deeply nested subdirectories."""
    config_content = """\
include:
  - src
rules:
  - name: domain-isolation
    modules: "**"
    deny:
      third_party: [pydantic]
"""
    config_file = tmp_path / ".python-dependency-linter.yaml"
    config_file.write_text(config_content)

    # Create deeply nested files inside include path
    nested = tmp_path / "src" / "contexts" / "analytics" / "domain"
    nested.mkdir(parents=True)
    (tmp_path / "src" / "__init__.py").write_text("")
    (tmp_path / "src" / "contexts" / "__init__.py").write_text("")
    (tmp_path / "src" / "contexts" / "analytics" / "__init__.py").write_text("")
    (nested / "__init__.py").write_text("")
    (nested / "models.py").write_text("import pydantic\n")

    # Create files outside include path
    other = tmp_path / "other"
    other.mkdir()
    (other / "__init__.py").write_text("")
    (other / "app.py").write_text("import pydantic\n")

    monkeypatch.chdir(tmp_path)
    runner = CliRunner()
    result = runner.invoke(main, ["check"])
    assert result.exit_code == 1
    assert "src/contexts/analytics/domain/models.py" in result.output
    assert "other/app.py" not in result.output


def test_cli_check_with_exclude(tmp_path, monkeypatch):
    """Files matching exclude patterns should be skipped."""
    config_content = """\
exclude:
  - generated/**
rules:
  - name: domain-isolation
    modules: "**"
    deny:
      third_party: [pydantic]
"""
    config_file = tmp_path / ".python-dependency-linter.yaml"
    config_file.write_text(config_content)

    src = tmp_path / "src"
    src.mkdir()
    (src / "__init__.py").write_text("")
    (src / "app.py").write_text("import pydantic\n")

    generated = tmp_path / "generated"
    generated.mkdir()
    (generated / "__init__.py").write_text("")
    (generated / "models.py").write_text("import pydantic\n")

    monkeypatch.chdir(tmp_path)
    runner = CliRunner()
    result = runner.invoke(main, ["check"])
    assert result.exit_code == 1
    assert "src/app.py" in result.output
    assert "generated/" not in result.output


def test_cli_check_with_include_and_exclude(tmp_path, monkeypatch):
    """Exclude should filter within included paths."""
    config_content = """\
include:
  - src
exclude:
  - src/generated
rules:
  - name: domain-isolation
    modules: "**"
    deny:
      third_party: [pydantic]
"""
    config_file = tmp_path / ".python-dependency-linter.yaml"
    config_file.write_text(config_content)

    app = tmp_path / "src"
    app.mkdir()
    (app / "__init__.py").write_text("")
    (app / "app.py").write_text("import pydantic\n")

    generated = tmp_path / "src" / "generated"
    generated.mkdir()
    (generated / "__init__.py").write_text("")
    (generated / "models.py").write_text("import pydantic\n")

    monkeypatch.chdir(tmp_path)
    runner = CliRunner()
    result = runner.invoke(main, ["check"])
    assert result.exit_code == 1
    assert "src/app.py" in result.output
    assert "generated/" not in result.output


def test_cli_check_config_not_found(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    runner = CliRunner()
    result = runner.invoke(main, ["check"])
    assert result.exit_code == 2


def test_cli_check_explicit_config_not_found():
    runner = CliRunner()
    result = runner.invoke(main, ["check", "--config", "nonexistent.yaml"])
    assert result.exit_code == 2
    assert "not found" in result.output.lower()


def test_cli_check_with_explicit_config(tmp_path, monkeypatch):
    """--config should use the config file's parent as project root."""
    project_dir = tmp_path / "project"
    project_dir.mkdir()

    config_content = """\
rules:
  - name: domain-isolation
    modules: "**"
    deny:
      third_party: [pydantic]
"""
    config_file = project_dir / "custom-config.yaml"
    config_file.write_text(config_content)

    src = project_dir / "src"
    src.mkdir()
    (src / "__init__.py").write_text("")
    (src / "app.py").write_text("import pydantic\n")

    # Run from a different directory, but point --config to project_dir
    monkeypatch.chdir(tmp_path)
    runner = CliRunner()
    result = runner.invoke(main, ["check", "--config", str(config_file)])
    assert result.exit_code == 1
    assert "src/app.py" in result.output


def test_cli_check_ignore_blanket(tmp_path, monkeypatch):
    """``# pdl: ignore`` suppresses all violations on that line."""
    config_content = """\
rules:
  - name: domain-isolation
    modules: "**"
    deny:
      third_party: [pydantic]
"""
    config_file = tmp_path / ".python-dependency-linter.yaml"
    config_file.write_text(config_content)

    src = tmp_path / "src"
    src.mkdir()
    (src / "__init__.py").write_text("")
    (src / "app.py").write_text("import pydantic  # pdl: ignore\n")

    monkeypatch.chdir(tmp_path)
    runner = CliRunner()
    result = runner.invoke(main, ["check"])
    assert result.exit_code == 0
    assert "No violations found." in result.output


def test_cli_check_ignore_specific_rule(tmp_path, monkeypatch):
    """``# pdl: ignore[rule-name]`` suppresses only the matching rule."""
    config_content = """\
rules:
  - name: deny-pydantic
    modules: src.*
    deny:
      third_party: [pydantic]
  - name: deny-requests
    modules: lib.*
    deny:
      third_party: [requests]
"""
    config_file = tmp_path / ".python-dependency-linter.yaml"
    config_file.write_text(config_content)

    src = tmp_path / "src"
    src.mkdir()
    (src / "__init__.py").write_text("")
    (src / "app.py").write_text("import pydantic  # pdl: ignore[deny-pydantic]\n")

    lib = tmp_path / "lib"
    lib.mkdir()
    (lib / "__init__.py").write_text("")
    (lib / "client.py").write_text("import requests  # pdl: ignore[deny-requests]\n")

    monkeypatch.chdir(tmp_path)
    runner = CliRunner()
    result = runner.invoke(main, ["check"])
    assert result.exit_code == 0
    assert "No violations found." in result.output


def test_cli_check_ignore_specific_rule_no_match(tmp_path, monkeypatch):
    """``# pdl: ignore[wrong-name]`` does not suppress a different rule."""
    config_content = """\
rules:
  - name: deny-pydantic
    modules: "**"
    deny:
      third_party: [pydantic]
"""
    config_file = tmp_path / ".python-dependency-linter.yaml"
    config_file.write_text(config_content)

    src = tmp_path / "src"
    src.mkdir()
    (src / "__init__.py").write_text("")
    (src / "app.py").write_text("import pydantic  # pdl: ignore[wrong-name]\n")

    monkeypatch.chdir(tmp_path)
    runner = CliRunner()
    result = runner.invoke(main, ["check"])
    assert result.exit_code == 1
    assert "[deny-pydantic]" in result.output


def test_cli_check_ignore_multiple_rules(tmp_path, monkeypatch):
    """``# pdl: ignore[rule1, rule2]`` suppresses listed rules."""
    config_content = """\
rules:
  - name: deny-pydantic
    modules: src.*
    deny:
      third_party: [pydantic]
"""
    config_file = tmp_path / ".python-dependency-linter.yaml"
    config_file.write_text(config_content)

    src = tmp_path / "src"
    src.mkdir()
    (src / "__init__.py").write_text("")
    (src / "app.py").write_text(
        "import pydantic  # pdl: ignore[deny-pydantic, other-rule]\n"
    )

    monkeypatch.chdir(tmp_path)
    runner = CliRunner()
    result = runner.invoke(main, ["check"])
    assert result.exit_code == 0
    assert "No violations found." in result.output
