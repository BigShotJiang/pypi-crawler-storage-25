"""
promptpay_qr - Generate PromptPay QR code payloads and images.

Based on EMV QRCPS Merchant Presented Mode specification.
Reference: https://www.blognone.com/node/95133

Usage:
    from promptpay_qr import generate_payload, generate_qr_image

    payload = generate_payload('091xxxxxxx')
    payload = generate_payload('091xxxxxxx', amount=67.67)

    generate_qr_image('091xxxxxxx', filename='qr.png')
    img = generate_qr_image('091xxxxxxx', amount=100.0)  # returns PIL.Image
"""

_ID_PAYLOAD_FORMAT = '00'
_ID_POI_METHOD = '01'
_ID_MERCHANT_INFORMATION_BOT = '29'
_ID_TRANSACTION_CURRENCY = '53'
_ID_TRANSACTION_AMOUNT = '54'
_ID_COUNTRY_CODE = '58'
_ID_CRC = '63'

_PAYLOAD_FORMAT_EMV = '01'
_POI_METHOD_STATIC = '11'
_POI_METHOD_DYNAMIC = '12'
_TEMPLATE_ID_GUID = '00'
_BOT_ID_PHONE = '01'
_BOT_ID_TAX_ID = '02'
_BOT_ID_EWALLET = '03'
_GUID_PROMPTPAY = 'A000000677010111'
_CURRENCY_THB = '764'
_COUNTRY_TH = 'TH'


def _f(id_, value):
    return f"{id_}{len(value):02d}{value}"


def _serialize(fields):
    return ''.join(x for x in fields if x)


def _sanitize(target):
    return ''.join(c for c in target if c.isdigit())


def _format_target(digits):
    if len(digits) >= 13:
        return digits
    normalized = '66' + digits[1:] if digits.startswith('0') else digits
    return normalized.zfill(13)


def _crc16_xmodem(data: str) -> int:
    crc = 0xFFFF
    for byte in data.encode('ascii'):
        crc ^= byte << 8
        for _ in range(8):
            crc = ((crc << 1) ^ 0x1021) if crc & 0x8000 else (crc << 1)
            crc &= 0xFFFF
    return crc


def generate_payload(target: str, amount: float = None) -> str:
    """
    Generate a PromptPay QR payload string.

    Args:
        target: Phone number (10 digits), national/tax ID (13 digits),
                or e-Wallet ID (15+ digits). Dashes and spaces are ignored.
        amount: Optional transfer amount in THB. When set, banking apps
                will pre-fill the amount field.

    Returns:
        Payload string to be encoded as a QR code.
    """
    digits = _sanitize(target)

    if len(digits) >= 15:
        target_type = _BOT_ID_EWALLET
    elif len(digits) >= 13:
        target_type = _BOT_ID_TAX_ID
    else:
        target_type = _BOT_ID_PHONE

    fields = [
        _f(_ID_PAYLOAD_FORMAT, _PAYLOAD_FORMAT_EMV),
        _f(_ID_POI_METHOD, _POI_METHOD_DYNAMIC if amount is not None else _POI_METHOD_STATIC),
        _f(_ID_MERCHANT_INFORMATION_BOT, _serialize([
            _f(_TEMPLATE_ID_GUID, _GUID_PROMPTPAY),
            _f(target_type, _format_target(digits)),
        ])),
        _f(_ID_COUNTRY_CODE, _COUNTRY_TH),
        _f(_ID_TRANSACTION_CURRENCY, _CURRENCY_THB),
        _f(_ID_TRANSACTION_AMOUNT, f"{amount:.2f}") if amount is not None else None,
    ]

    data_to_crc = _serialize(fields) + _ID_CRC + '04'
    crc = _crc16_xmodem(data_to_crc)
    fields.append(_f(_ID_CRC, f"{crc:04X}"))

    return _serialize(fields)


def generate_qr_image(target: str, amount: float = None, filename: str = None, size: int = 300):
    """
    Generate a PromptPay QR code image.

    Requires: pip install qrcode[pil]

    Args:
        target: PromptPay ID (phone, national ID, or e-Wallet).
        amount: Optional amount in THB.
        filename: If given, saves the image to this path (PNG recommended).
                  If None, returns a PIL.Image object.
        size: Output image size in pixels (default 300).

    Returns:
        PIL.Image if filename is None, else None.
    """
    try:
        import qrcode
    except ImportError:
        raise ImportError("Install qrcode with: pip install qrcode[pil]")

    payload = generate_payload(target, amount)
    img = qrcode.make(payload)
    img = img.resize((size, size))

    if filename:
        img.save(filename)
        return None
    return img
