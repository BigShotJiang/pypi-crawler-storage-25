# promptpay-qr

A minimal Python library for generating **PromptPay QR code** payloads and images, compliant with the EMV QRCPS Merchant Presented Mode specification.

## Features

- Generate PromptPay QR payload strings from a phone number, national/tax ID, or e-Wallet ID
- Optionally embed a pre-filled transfer amount
- Render the payload as a PNG image (requires `qrcode[pil]`)
- Zero required dependencies for payload-only generation

## Installation

```bash
pip install promptpay-qr
```

To also generate QR images:

```bash
pip install "promptpay-qr[image]"
# or manually:
pip install qrcode[pil]
```

## Quick start

```python
from promptpay_qr import generate_payload, generate_qr_image

# Payload only
payload = generate_payload('091xxxxxxx')
payload = generate_payload('091xxxxxxx', amount=67.67)

# Save QR image to file
generate_qr_image('091xxxxxxx', filename='qr.png')
generate_qr_image('091xxxxxxx', amount=67.67, filename='qr_100.png')

# Get a PIL.Image object (e.g. to display in a notebook)
img = generate_qr_image('091xxxxxxx', amount=67.67)
img.show()
```

## API

### `generate_payload(target, amount=None) -> str`

Generates the raw PromptPay QR payload string.

| Parameter | Type | Description |
|-----------|------|-------------|
| `target` | `str` | PromptPay ID — phone number (10 digits), national/tax ID (13 digits), or e-Wallet ID (15+ digits). Dashes and spaces are stripped automatically. |
| `amount` | `float` \| `None` | Transfer amount in THB. When provided, banking apps pre-fill the amount field. |

Returns a `str` that can be encoded as any standard QR code.

---

### `generate_qr_image(target, amount=None, filename=None, size=300)`

Generates a PromptPay QR code image.

| Parameter | Type | Description |
|-----------|------|-------------|
| `target` | `str` | PromptPay ID (same rules as above). |
| `amount` | `float` \| `None` | Optional amount in THB. |
| `filename` | `str` \| `None` | Path to save the image (PNG recommended). If `None`, returns a `PIL.Image` instead. |
| `size` | `int` | Output image size in pixels (default `300`). |

Returns `PIL.Image` when `filename` is `None`, otherwise saves the file and returns `None`.

Requires `qrcode[pil]` — raises `ImportError` with installation instructions if missing.

## Supported PromptPay ID types

| Type | Digits | Example |
|------|--------|---------|
| Phone number | 10 | `091xxxxxxx` |
| National / tax ID | 13 | `1234567890123` |
| e-Wallet ID | 15+ | `004999000288505` |

Leading `0` in phone numbers is automatically converted to the `+66` country prefix per the PromptPay spec.

## Specification

Built on the [EMV QRCPS Merchant Presented Mode](https://www.blognone.com/node/95133) specification and the Bank of Thailand PromptPay standard.

## License

MIT
