# HarnessLayer API Reference

Use this memory source when you need to call or reason about the HarnessLayer API from this OpenClaw app.

## Base API

- Production API root: `https://api.harnesslayer.ai/v1`.
- Local or non-production hosts can be selected with `HARNESSLAYER_API_BASE_URL`; include `/v1` if calling the endpoint paths below directly.
- Authenticate every `/v1/*` request with `Authorization: Bearer <api_key>`.
- HarnessLayer API keys start with `dk-`.
- Successful API responses are shaped like `{"success": true, "data": {...}}`.
- Error responses are shaped like `{"success": false, "error": "message"}`.
- Common pagination query params are `page` and `pageSize`.

## Management Agent Profile Contract

This OpenClaw configuration is intended to be submitted as the base version for
a HarnessLayer management agent. In normal operation, the runtime environment
provides the managed app id and API key:

- `HARNESSLAYER_APP_ID`: default `appId` for API calls.
- `HARNESSLAYER_API_KEY`: API key for HarnessLayer authentication.

The agent should read these values from the environment and should not ask the
user for them during normal operation. If either value is missing, report a
deployment misconfiguration rather than asking the user to paste secrets. The
agent may inspect and modify the managed app when the user asks. It should not
modify a different app unless the user explicitly provides a different app id
for the current task.

Every ambiguous user reference is about `HARNESSLAYER_APP_ID` by default:
"the app", "this app", "my app", "the bot", "the agent", "the workspace",
"the config", "the files", "users", "profiles", "channels", "sessions",
"versions", "state", "syncs", "history", and similar phrases all mean the
managed app unless the user explicitly names a different app id for that task.

Use the HarnessLayer SDK/API to satisfy app-related requests. Inspect current
API state before answering app-specific questions, and perform requested
creates, updates, downloads, clones, deletions, runs, or sync inspections
through the API. Do not stop at explaining API calls or telling the user what
to edit unless they explicitly ask for advice only.

When the user talks about files, folders, workspace contents, config files, or
file edits, treat it as a request to update the managed app defaults. Download
the current app head if needed, make the requested file change in that version
folder, then create a new app version. Do not stop at advice unless the user
explicitly asks for advice only.

For multi-step app changes, work progressively: inspect first, report the
result, make the requested change, report the result, then create a version if
needed. Do not combine inspection, mutation, version creation, and sync into
one silent action. Sync still requires explicit user approval.

If the user asks for a cron, schedule, recurring run, periodic task, reminder,
follow-up, or automation that is supposed to run from the managed app, do not
create a local OpenClaw cron or heartbeat for the management agent. Treat the
schedule as app-owned configuration/state and inspect or update it through the
HarnessLayer API or SDK. Local heartbeat/cron is only for the management
agent's own out-of-band reminders or follow-ups.

Keep user-facing status and completion messages minimal, like text messages:
usually 1-3 short sentences with no headings, tables, long explanations, or
bullets unless they are clearly helpful.

Typical flow:

```python
from harnesslayer import Harnesslayer
import os

managed_app_id = os.environ["HARNESSLAYER_APP_ID"]
api_key = os.environ["HARNESSLAYER_API_KEY"]

with Harnesslayer(api_key=api_key) as client:
    app = client.app.retrieve(app_id=managed_app_id)
```

When applying a version transform, target the managed `appId` through the
retrieved app object:

```python
app.version.clone(
    transform={
        "workspace/HEARTBEAT.md": "Updated heartbeat instructions",
    }
)
```

## Python SDK

```python
from harnesslayer import Harnesslayer
import os

client = Harnesslayer(api_key=os.environ["HARNESSLAYER_API_KEY"])
```

Prefer the SDK when it is available. It sets the base URL, auth header, timeout, and user agent for you. Close the client when done, or use it as a context manager.

```python
from harnesslayer import Harnesslayer
import os

with Harnesslayer(api_key=os.environ["HARNESSLAYER_API_KEY"]) as client:
    app = client.app.init(
        "my-openclaw-app",
        type="openclaw",
        version_path=".openclaw",
    )
```

## OpenClaw App Setup

Create or update an OpenClaw app by uploading a `.openclaw` folder as a HarnessLayer version.

```python
from harnesslayer import Harnesslayer
import os

client = Harnesslayer(api_key=os.environ["HARNESSLAYER_API_KEY"])

app = client.app.init(
    "my-openclaw-app",
    type="openclaw",
    version_path=".openclaw",
    auto_update_version=True,
)
```

For larger OpenClaw uploads, create a temporary OpenClaw version first and then initialize the app from that version.

```python
version_id = client.version.init(".openclaw", preset="openclaw")

app = client.app.init(
    "my-openclaw-app",
    type="openclaw",
    version_id=version_id,
    auto_update_version=False,
)
```

Slug rules: non-empty, URL-safe, only letters, numbers, hyphens, and underscores; it cannot start or end with `-` or `_`.

## App Endpoints

- `POST /app/create`: body `slug`, `type`; optional `name`, `limit`, `credentials`, `returnIfExist`.
- `POST /app/init`: body `slug`, `type`, plus `base64` or `tempVersionId`; optional `name`, `limit`, `credentials`, `autoUpdateVersion`.
- `GET /app/{app_id}`: accepts an app display id or slug.
- `GET /app/list`: requires `appId`, optional `page`, `pageSize`.
- `PATCH /app/{app_id}`: optional `slug`, `name`.
- `DELETE /app/{app_id}`: deletes the app and related data.

App types are `claude` and `openclaw`.

SDK:

```python
app = client.app.init("my-openclaw-app", type="openclaw", version_path=".openclaw")
app = client.app.retrieve(slug="my-openclaw-app")
client.app.delete("app-...")
```

## Version Endpoints

- `POST /version/temp`: body `sourceSha256`; optional `type`, `extensionId`, `versionId`, `status`. Creates, reuses, or updates a temporary version source. `status` can be `ready` or `failed`; status updates require `versionId`.
- `GET /version/diff`: query `appId` or `profileId`, plus `baseCommit` and `headCommit`; optional `contextLines` defaults to `3`. Returns the unified diff between two commits or refs in the app backing repo. Ref aliases accepted: `baseCommitHash`/`fromCommit`/`fromRef`/`base`, `headCommitHash`/`toCommit`/`toRef`/`head`.
- `POST /version/create`: body `appId` and exactly one of `storageUrl` or `base64`.
- `POST /version/clone`: body `appId`; optional `versionId`; optional transforms via `files`, `transform`, or top-level file keys for `.json` patches and full `.md` replacement.
- `POST /version/sync`: body `appId`; optional `strategy` of `ours` or `theirs`. `ours` keeps the state's implementation during conflicts; `theirs` keeps the main branch's implementation. Without a strategy, merge conflicts are reported for manual resolution. Returns `syncId`.
- `GET /version/download/{version_id}`: returns a short-lived signed download URL in `data.url`.
- `GET /version/latest`: query `appId`.
- `GET /version/{version_id}`: fetch one version.
- `GET /version/list`: query `appId`, optional `page`, `pageSize`.

SDK:

```python
version_id = client.version.init(".openclaw", preset="openclaw")
app = client.app.init("my-openclaw-app", type="openclaw", version_id=version_id)
app.version.create(".openclaw")
app.version.clone(transform={"workspace/HEARTBEAT.md": "New heartbeat instructions"})
app.version.sync(strategy="ours")
app.version.download(r"C:\temp\openclaw-state")
```

Version diff example:

```python
import os
import requests

api_base_url = os.environ.get("HARNESSLAYER_API_BASE_URL", "https://api.harnesslayer.ai")
response = requests.get(
    f"{api_base_url}/v1/version/diff",
    headers={"Authorization": f"Bearer {api_key}"},
    params={
        "appId": managed_app_id,
        "baseCommit": "main~1",
        "headCommit": "main",
        "contextLines": 3,
    },
)
```

User-facing follow-up: whenever a create or clone call creates a new app
version, suggest syncing that version into existing profile states and ask for
approval plus an `ours` or `theirs` sync strategy before starting the sync. If
the user approves syncing without choosing a strategy, ask which strategy to use
before starting. After the user approves and sync is started with the chosen
strategy, suggest monitoring the sync and checking conflicts.

Clone transforms:

- `.json` targets receive a deep object patch.
- `.md` targets receive full Markdown file content.
- Use `{"$by": "<field>", "$patch": {"<value>": {...}}}` to patch matching objects in arrays.
- Use `{"$all": {...}}` to patch every object in an existing array or object map.

## Channels and Runs

Create an API channel, then run it with user input.

```python
channel = app.channel.init(
    "my-api",
    type="api",
    webhook={
        "name": "Inbound",
        "url": "https://example.com/inbound",
    },
)

stream = channel.run(
    session_id="session-123",
    user_id="user@example.com",
    input="hello",
)

for event in stream:
    if event.done:
        break
    print(event)
```

Channel endpoints:

- `POST /channel/create`: body `appId`, `slug`, `type`; optional `name`, `returnIfExist`, `webhook`, `data`.
- `GET /channel/{channel_id}`: fetch one channel.
- `GET /channel/list`: query `appId`, optional `page`, `pageSize`.
- `PATCH /channel/{channel_id}`: optional `slug`, `name`; current implementation applies `name`.
- `DELETE /channel/{channel_id}`: delete a channel.

Channel body rules:

- `type = "api"`: omit `data`; optional `webhook` is `{name, url, headers?}`.
- `type = "imessage"`: omit `webhook`; `data` requires `sendBlueAPIKey`, `sendBlueSecretKey`, and `fromNumber`.

Response run endpoints:

- `POST /response/run`: body `appId`, `channelId`, `userId`, `input`; optional `sessionId`; returns `instanceId`.
- `GET /response/poll/{instance_id}`: optional query `after` and `timeoutMs`; long-polls stream events and status.

## Sessions, Profiles, and State

Sessions:

- `POST /session/create`: body `appId`, `type`; Claude apps require `type = "single"`.
- `GET /session/{session_id}`.
- `GET /session/list`: query `appId`, optional `page`, `pageSize`.
- `DELETE /session/{session_id}`.

Profiles:

- `POST /profile/create`: body `appId`, `identifier`; optional `accessGroupId`, `metadata`, `returnIfExist`.
- `POST /profile/init`: body `appId`, `identifier`; optional `accessGroupId`, `metadata`, `base64`, `autoUpdateState`.
- `GET /profile/{profile_id}`.
- `GET /profile/list`: query `appId`, optional `page`, `pageSize`.
- `PATCH /profile/{profile_id}`: optional `identifier`, `accessGroupId`, `metadata`.
- `DELETE /profile/{profile_id}`.

State:

- `POST /state/create`: body `profileId` and exactly one of `storageUrl` or `base64`.
- `POST /state/clone`: body `profileId`; optional `stateId` or `versionId`, not both; optional transforms via `files`, `transform`, or top-level file keys for `.json` patches and full `.md` replacement.
- `POST /state/download/{state_id}`: returns a short-lived signed URL in `data.url`.
- `GET /state/latest`: query `profileId`.
- `GET /state/{state_id}`.
- `GET /state/list`: query `profileId`, optional `page`, `pageSize`.

## Access Groups

- `POST /access_group/create`: body `appId`, `name`, `limit`, `limitReset`; optional `limitMessage`.
- `GET /access_group/{access_group_id}`.
- `PATCH /access_group/{access_group_id}`: optional `name`, `limit`, `limitReset`, `limitMessage`.
- `DELETE /access_group/{access_group_id}`: cannot delete the app default access group.
- `GET /access_group/list`: query `appId`, optional `page`, `pageSize`.

`limitReset` values: `daily`, `monthly`, `yearly`.

## Sync, Conflicts, History, Instances

- `GET /sync/{sync_id}`.
- `GET /sync/list`: query `appId`, optional `page`, `pageSize`.
- `GET /conflict/{conflict_id}`.
- `GET /conflict/list`: query `appId`, optional `page`, `pageSize`.
- `GET /history/{history_id}`: returns one history entry with `messages[]`.
- `GET /history/list`: query at least one of `appId`, `profileId`, `sessionId`, `userId`, or `historyId`; optional `page`, `pageSize`; each item includes `messages[]`.
- `GET /instance/{instance_id}`.
- `GET /instance/list`: query `appId`, optional `page`, `pageSize`.

## Utilities, Webhooks, and Ops

- `POST /utils/upload`: body `appId`, `paths[]` items with `path` and `contentType`; returns short-lived signed upload URLs.
- `POST /webhook/sendblue/{channel_id}`: Sendblue webhook payload; dispatches a run and returns `instanceId`.
- `GET /healthz`: unauthenticated service health.
- `GET /ops` and `/ops/`: HarnessLayer ops HTML dashboard.
- `GET /ops/data`, `/ops/diagnostics`, `/ops/apps/{app_id}`: require `x-harnesslayer-ops-token` or `?token=` when `HARNESSLAYER_OPS_TOKEN` is configured.

## Raw HTTP Example

```bash
curl -X POST "$HARNESSLAYER_API_BASE_URL/v1/app/create" \
  -H "Authorization: Bearer $HARNESSLAYER_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{"slug":"demo-app","type":"openclaw","name":"Demo App"}'
```

## Operational Notes

- Never expose or commit real HarnessLayer API keys.
- Prefer SDK methods for normal use, because they validate paths, slugs, app types, clone transforms, and OpenClaw archive shape.
- A valid OpenClaw version path must end in `.openclaw` and contain `openclaw.json`.
- HarnessLayer OpenClaw archives intentionally ignore local runtime/cache directories such as `backups`, `browser`, `credentials`, `mail-bridge`, `scripts`, `subagents`, `tasks`, `logs`, and `plugin-runtime-deps`.
