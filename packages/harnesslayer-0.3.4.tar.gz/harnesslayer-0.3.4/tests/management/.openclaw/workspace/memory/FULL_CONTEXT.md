# HarnessLayer API Full Context

This document is for an agent that needs to use HarnessLayer correctly. It intentionally avoids repository/codebase layout. Treat it as an API and system-behavior map: resources, endpoints, data flow, runtime flow, and the mental model behind versions and states.

## Core Mental Model

HarnessLayer turns an agent bundle into a hosted, stateful app.

- An `App` is the product/container.
- A `Version` is the app-wide base configuration. Think: initial config, default image, or `main`.
- A `Profile` is one user/person/customer identity inside an app.
- A `State` is that profile's mutable branch of the app. Think: the user's working branch.
- A `Channel` is how input enters the app.
- A `Session` is the conversation thread.
- An `Instance` is one run.
- `History`/`Message` persist conversation records.
- `Sync` merges a new app version into existing profile states.
- `Conflict` records profile branches that could not be merged.

For management agents, user requests about files, folders, workspace contents,
config files, or file edits should be treated as requests to update the managed
app's default version. Start from the current app head by downloading it if
needed, make the requested file change there, then create a new app version.
Do not only explain the edit unless the user explicitly asks for advice only.

Management agents should perform multi-step app changes progressively. Inspect
first, report the result, make the requested change, report the result, then
create a version if needed. Do not combine inspection, mutation, version
creation, and sync into one silent action. Sync requires explicit user approval.
User-facing status and completion messages should be minimal, like text
messages: usually 1-3 short sentences with no headings, tables, long
explanations, or bullets unless they are clearly helpful.

The most important idea:

```text
Version = app base config, like main
State   = per-profile config/data, like a branch from main
```

When you create a new app version, HarnessLayer updates the app's base line. When a profile is initialized, HarnessLayer creates a per-profile state line from the app version. When you sync, HarnessLayer merges the app version line into all profile state lines.

## API Basics

Production base URL:

```text
https://api.harnesslayer.ai/v1
```

Authentication:

```text
Authorization: Bearer dk-...
Content-Type: application/json
Accept: application/json
```

API keys are expected to start with `dk-`.

Success response:

```json
{ "success": true, "data": {} }
```

Error response:

```json
{ "success": false, "error": "message" }
```

The public API returns `id` fields, but internally those are display ids such as `app-...`, `ver-...`, `profile-...`, `state-...`, `ch-...`, `session-...`, `inst-...`.

## SDK Basics

Typical Python usage:

```python
from harnesslayer import Harnesslayer

client = Harnesslayer(api_key="dk-...")

app = client.app.init(
    "my-agent",
    type="openclaw",
    version_path=".openclaw",
)

channel = app.channel.init("api", type="api")
profile = app.profile.init("user@example.com")

for event in channel.run(
    channel_id=channel.id,
    user_id="user@example.com",
    session_id="conversation-123",
    input="hello",
):
    print(event.index, event.data)
```

SDK client behavior:

- `Harnesslayer(api_key="dk-...")` validates non-empty key with `dk-` prefix.
- Default API version is `v1`.
- Default timeout is `600` seconds.
- The client can be used as a context manager.
- `client.app` manages apps.
- `client.version` has client-level temp-version helpers.
- An app model has bound resource helpers: `app.version`, `app.channel`, `app.session`, `app.access_group`, `app.profile`, `app.instance`, `app.conflict`.

## Resource Model

### App

An app represents the deployed agent product.

Key fields:

- `id`: app id, usually `app-...`
- `orgId`: owning organization
- `type`: `claude` or `openclaw`
- `slug`: URL-safe unique app slug within an org
- `name`
- `vaultId`
- `defaultAccessGroupId`
- `headVersionId`: latest app `Version`
- `metadata`
- `createdAt`, `updatedAt`

Creating an app also creates:

- default access group
- default vault
- app-type-specific backing resources where needed

For Claude apps, HarnessLayer creates Anthropic-side app/vault resources and stores external ids in metadata.

### Version

A version is the app's canonical base config at a point in time.

Key fields:

- `id`: version id, usually `ver-...`
- `appId`
- `version`: integer sequence, starting at `1`
- `commitHash`: backing Git commit
- `sha256`: content hash
- `gitOrigin`
- `gitBranch`: normally `main`
- `storageUrl`: archive URL
- `map`: provider resource map, mostly for Claude
- `metadata`: provider/app metadata
- `createdAt`, `updatedAt`

Semantics:

- New versions become the app head via `App.headVersionId`.
- Version content is stored as a zip archive and committed to the app's backing `main` branch.
- A version should be treated as immutable once created, though new versions can be cloned from old ones.
- After creating or cloning a version, user-facing guidance should suggest syncing the new app version into existing profile states and ask for approval plus an `ours` or `theirs` sync strategy before starting the sync. `ours` keeps the state's implementation during conflicts; `theirs` keeps the main branch's implementation.

Management agents must not create their own OpenClaw cron/heartbeat when the
requested cron, schedule, recurring run, periodic task, reminder, follow-up, or
automation belongs to the app they manage. App-owned schedules are app
configuration/state and should be inspected or updated through HarnessLayer.
Local OpenClaw cron/heartbeat is only for the management agent's own
out-of-band reminders or follow-ups.

### Profile

A profile is a user identity inside an app.

Key fields:

- `id`: profile id, usually `profile-...`
- `appId`
- `identifier`: usually the same value passed as `userId` to runs
- `currentSpending`, `totalSpending`
- `headStateId`: latest state for this profile
- `initialChannelId`
- `accessGroupId`
- `metadata`
- `lastResetAt`
- `createdAt`, `updatedAt`

Semantics:

- Profiles are unique by `appId + identifier`.
- A run for a missing profile can auto-create the profile.
- Auto-created profiles during run do not necessarily get initialized state; runtime falls back to the app version when no state exists.
- Use `profile.init(...)` when you want a real per-profile state branch prepared.

### State

A state is the profile's current mutable copy of the app config/data.

Key fields:

- `id`: state id, usually `state-...`
- `appId`
- `profileId`
- `version`: per-profile integer sequence, starting at `1`
- `commitHash`
- `sha256`
- `gitOrigin`
- `gitBranch`: normally the profile id
- `storageUrl`
- `map`
- `metadata`
- `createdAt`, `updatedAt`

Semantics:

- A profile can have many state records.
- `Profile.headStateId` points at the current one.
- New states are commits on the profile's branch.
- State can be created from uploaded content, cloned from another state, cloned from a version, or initialized from latest app version.

### Channel

A channel is an input surface.

Types:

- `api`: SDK/API runs
- `imessage`: Sendblue-backed iMessage inbound/outbound flow

Common fields:

- `id`: channel id, usually `ch-...`
- `appId`
- `type`
- `slug`
- `name`
- `webhook`: for API channels
- `data`: for iMessage channels

API channel rules:

- `data` must be omitted.
- Optional `webhook` shape is `{ "name": "...", "url": "...", "headers": { ... } }`.

iMessage channel rules:

- `webhook` must be omitted.
- `data` must include `sendBlueAPIKey`, `sendBlueSecretKey`, `fromNumber`.
- HarnessLayer verifies the number supports iMessage.
- HarnessLayer registers a Sendblue receive webhook.
- Sendblue credentials are encrypted before storage.

### Session

A session groups conversation state and history.

Fields:

- `id`: session id, usually `session-...`
- `appId`
- `type`: usually `single`; Claude apps require `single`
- `userIds`
- `profileIds`
- `metadata`
- `externalId`

Runtime behavior:

- If `sessionId` is provided, HarnessLayer looks for a session by `displayId` or app-scoped `externalId`.
- If no matching session exists, it creates a new one.
- Claude sessions store Anthropic session id in `metadata.externalId`.
- OpenClaw sessions can store `metadata.latestResponseId` so later runs continue the previous response chain.

### Instance

An instance is one execution.

Fields:

- `id`: instance id, usually `inst-...`
- `appId`
- `versionId`
- `channelId`
- `sessionId`
- `profileId`
- `accessGroupId`
- `stateId`
- `identifier`
- `timeout`
- `totalCost`
- `costBreakdown`
- `tokenBreakdown`
- `status`: `running` or `terminated`
- `error`
- `metadata`

Instances are created by runtime workers and updated on shutdown.

### Access Group

Access groups enforce usage limits.

Fields:

- `id`: access group id, usually `ag-...`
- `appId`
- `name`
- `limit`
- `limitReset`: `daily`, `monthly`, or `yearly`
- `limitMessage`

Runtime checks:

- A profile uses its own `accessGroupId` if set, otherwise the app default.
- Spending resets by interval.
- If current spending is at or above limit, the run fails with `limitMessage`.

### History and Message

HarnessLayer upserts one history record per `sessionId + profileId`.

Messages store user and assistant parts. History list/get responses include related messages.

### Sync and Conflict

A sync job merges the app head version into profile states.

Sync statuses:

- `in_progress`
- `complete`
- `failed`
- `conflict`

Conflict reasons:

- `missing_head_state`
- `missing_state_branch`
- `merge_conflict`

## Bundle Types

HarnessLayer accepts version/state bundles for two app types.

### Claude Bundle

A Claude bundle path normally ends with `.claude`.

Required logical files:

- `agent.json`
- `environment.json`

Optional:

- `skills/<skill-name>/SKILL.md`

Validation semantics:

- Root is limited to `agent.json`, `environment.json`, and `skills`.
- If `agent.json` has `skills`, each listed skill must be an object with `type == "anthropic"`.
- Custom local skills should be represented as directories under `skills`.

Provider behavior:

- `agent.json` and `environment.json` become Anthropic managed-agent resources.
- Skills become Anthropic skill resources.
- Version/state `map` records provider ids and content hashes.

### OpenClaw Bundle

An OpenClaw bundle path normally ends with `.openclaw`.

Required logical file:

- `openclaw.json`

Archive behavior:

- Runtime-heavy folders are ignored during version archiving.
- Workspace Git data is ignored.
- Agent session summaries and relevant non-trajectory JSONL session logs may be included.

OpenClaw metadata extracted from `openclaw.json`:

- default model
- default agent id
- enabled plugin list

Default OpenClaw model if none is configured:

```text
openrouter/gpt-4.1-mini
```

Default OpenClaw agent id if none is configured:

```text
main
```

## App API

### `POST /app/create`

Creates app metadata only.

Body:

```json
{
  "slug": "my-app",
  "type": "openclaw",
  "name": "My App",
  "limit": {
    "amount": 100,
    "interval": "monthly",
    "message": "You've run out of credits!"
  },
  "credentials": [],
  "returnIfExist": false
}
```

Behavior:

- Validates URL-safe slug.
- Creates default access group.
- Creates default vault.
- For Claude, initializes provider-side app/vault data.
- Does not necessarily create a version.

### `POST /app/init`

Create or retrieve an app and optionally initialize/update its head version.

Body:

```json
{
  "slug": "my-app",
  "type": "openclaw",
  "name": "My App",
  "base64": "<zip-base64>",
  "tempVersionId": "ver-...",
  "limit": {
    "amount": 100,
    "interval": "monthly"
  },
  "credentials": [],
  "autoUpdateVersion": true
}
```

Rules:

- `slug` and `type` are required.
- New app requires one of `base64` or `tempVersionId`.
- Existing app with no source payload returns existing app.
- `base64` and `tempVersionId` are mutually exclusive.
- `autoUpdateVersion` defaults to `true`.

Inner flow:

1. Validate org/app/slug/type.
2. If new app, create app, vault, and default access group.
3. Decode or load source archive.
4. Compute source content hash.
5. Compare against latest version hash.
6. If this is a new app, missing head, or changed source with auto-update enabled, create next version.
7. Store version archive.
8. Commit the version to the app's backing `main` line.
9. Insert `Version`.
10. Update `App.headVersionId`.

### `GET /app/{app_id_or_slug}`

Fetches an app by id or slug.

### `GET /app/list?appId=...`

Lists apps for the org. The current API expects `appId` even though listing is org-scoped.

### `PATCH /app/{app_id}`

Updates `slug` and/or `name`.

### `DELETE /app/{app_id_or_slug}`

Marks deletion and starts background cleanup.

Cleanup removes:

- app
- versions
- states
- profiles
- channels
- sessions
- instances
- history/messages
- access groups
- vault
- sync/conflict/cron records
- provider-side resources where applicable
- stored archives and backing repo data

## Version API

### `GET /version/diff`

Returns a unified diff between two commits or refs in the Driftstone repo
backing an app. Use this to inspect what changed between version commits before
explaining, syncing, or troubleshooting an app update.

Query:

```text
appId=app-...        # required unless profileId is provided
profileId=profile-... # required unless appId is provided
baseCommit=main~1
headCommit=main
contextLines=3      # optional; defaults to 3
```

Accepted aliases:

- base ref: `baseCommitHash`, `fromCommit`, `fromRef`, `base`
- head ref: `headCommitHash`, `toCommit`, `toRef`, `head`

Behavior:

- `appId` may be the app id or slug.
- `profileId` resolves to that profile's app backing repo.
- The endpoint delegates to Driftstone's repo diff endpoint with path
  `{appId}/{appType}`.
- `contextLines` must be a non-negative integer.
- Response `data` includes `appId`, `type`, `repo`, `baseRef`, `headRef`,
  `baseCommitHash`, `headCommitHash`, `diff`, `files`, `stats`,
  `storagePath`, and `gitOrigin`.

### `POST /version/create`

Creates the next app version.

Body:

```json
{
  "appId": "app-...",
  "base64": "<zip-base64>"
}
```

or:

```json
{
  "appId": "app-...",
  "storageUrl": "https://storage.googleapis.com/..."
}
```

Rules:

- Exactly one of `base64` or `storageUrl`.
- `base64` may be raw base64 or `data:*;base64,...`.

Inner flow:

1. Validate app ownership.
2. Load and extract archive safely.
3. Flatten a single archive root directory if present.
4. Reject empty archives.
5. Compute content hash.
6. Create provider metadata:
   - Claude: create/update Anthropic resource map.
   - OpenClaw: extract model/agent/plugin metadata.
7. Commit archive as next app version on `main`.
8. Insert `Version`.
9. Update `App.headVersionId`.

### `POST /version/clone`

Clones a version, optionally transforms files, and writes it as the next app version.

Body:

```json
{
  "appId": "app-...",
  "versionId": "ver-optional",
  "transform": {
    "openclaw.json": {
      "model": {
        "primary": "openrouter/gpt-4.1"
      }
    },
    "README.md": "# replacement markdown\n"
  }
}
```

Behavior:

- If `versionId` is omitted, latest version is cloned.
- Source archive is loaded from `storageUrl`.
- Transforms are applied.
- If resulting hash matches latest version hash, request fails with no-change behavior.
- New version becomes app head.
- User-facing follow-up should suggest syncing the new version into existing profile states and ask for approval plus an `ours` or `theirs` sync strategy before starting the sync.

### `POST /version/sync`

Starts background sync of app head version into profile state branches.

Body:

```json
{
  "appId": "app-...",
  "strategy": "ours"
}
```

`strategy` is optional and can be:

- `ours`: keep the state's implementation during conflicts
- `theirs`: keep the main branch's implementation during conflicts

Without strategy, merge conflicts become conflict records.

Returns:

```json
{
  "success": true,
  "data": {
    "syncId": "sync-..."
  }
}
```

### `GET /version/latest?appId=...`

Returns latest version or `null`.

### `GET /version/{version_id}`

Returns one version.

### `GET /version/list?appId=...`

Lists versions for an app.

### `GET /version/download/{version_id}`

Returns a short-lived signed download URL:

```json
{
  "url": "https://..."
}
```

### `POST /version/temp`

Used by the SDK's OpenClaw temp-version initializer.

It supports:

- creating/reusing a temp version by source hash
- marking temp version `ready` or `failed`
- incorporating extension id and extension prompt hash into the cache key

Normal API users usually do not need this unless implementing the advanced OpenClaw preset upload flow.

## Profile API

### `POST /profile/create`

Creates profile metadata without necessarily creating state.

Body:

```json
{
  "appId": "app-...",
  "identifier": "user@example.com",
  "accessGroupId": "ag-...",
  "metadata": {
    "PLAN": "pro"
  },
  "returnIfExist": true
}
```

### `POST /profile/init`

Creates/retrieves a profile and initializes state if needed.

Body:

```json
{
  "appId": "app-...",
  "identifier": "user@example.com",
  "accessGroupId": "ag-...",
  "metadata": {
    "PLAN": "pro"
  },
  "base64": "<optional-state-zip-base64>",
  "autoUpdateState": true
}
```

Inner flow:

1. Validate app ownership.
2. Find profile by `appId + identifier`.
3. Create profile if missing.
4. If `metadata` is present for an existing profile, update it.
5. Determine source state:
   - explicit `base64`, if provided
   - otherwise latest app head version, but only when profile has no head state
6. Create state if profile is new, missing head state, or explicit state payload differs and auto-update allows it.
7. Commit the state to the profile's branch.
8. Insert `State`.
9. Update `Profile.headStateId`.

Important:

- If no explicit state payload is provided, `autoUpdateState` is effectively disabled.
- This avoids repeatedly overwriting existing profile states just because the app version changed.
- App-wide updates should be propagated with version sync, not repeated profile init.

### `GET /profile/{profile_id}`

Returns one profile.

### `GET /profile/list?appId=...`

Lists profiles for an app.

### `PATCH /profile/{profile_id}`

Updates `identifier`, `accessGroupId`, and/or `metadata`.

### `DELETE /profile/{profile_id}`

Marks deletion and starts background cleanup for that profile.

Cleanup removes:

- profile states and state archives
- profile conflicts
- profile cron jobs
- profile history/instances/messages
- some session links
- Sendblue dedupe entries for that identifier

## State API

### `POST /state/create`

Creates next state for a profile from archive content.

Body:

```json
{
  "profileId": "profile-...",
  "base64": "<zip-base64>"
}
```

or:

```json
{
  "profileId": "profile-...",
  "storageUrl": "https://storage.googleapis.com/..."
}
```

Rules:

- Exactly one of `base64` or `storageUrl`.
- New state is committed to the profile branch.
- `Profile.headStateId` is updated to the new state.

### `POST /state/clone`

Clones a source into the next profile state.

Body:

```json
{
  "profileId": "profile-...",
  "stateId": "state-optional",
  "versionId": "ver-optional",
  "transform": {
    "memory/user.json": {
      "tier": "pro"
    }
  }
}
```

Source selection:

1. If `versionId` is provided, clone that app version.
2. Else if `stateId` is provided, clone that profile state.
3. Else if latest state exists, clone latest state.
4. Else clone latest app version.

`stateId` and `versionId` are mutually exclusive.

Behavior:

- Applies transforms if provided.
- If resulting hash equals latest state hash, request fails with no-change behavior.
- Commits the result as next state on profile branch.
- Updates `Profile.headStateId`.

### `POST /state/download/{state_id}`

Returns a short-lived signed download URL.

### `GET /state/latest?profileId=...`

Returns latest state or `null`.

### `GET /state/{state_id}`

Returns one state.

### `GET /state/list?profileId=...`

Lists states for a profile.

## Channel API

### `POST /channel/create`

Create a channel.

API channel:

```json
{
  "appId": "app-...",
  "slug": "api",
  "type": "api",
  "name": "API",
  "webhook": {
    "name": "result-webhook",
    "url": "https://example.com/webhook",
    "headers": {
      "Authorization": "Bearer ..."
    }
  },
  "returnIfExist": true
}
```

iMessage channel:

```json
{
  "appId": "app-...",
  "slug": "sms",
  "type": "imessage",
  "name": "iMessage",
  "data": {
    "sendBlueAPIKey": "...",
    "sendBlueSecretKey": "...",
    "fromNumber": "+15555555555"
  },
  "returnIfExist": true
}
```

### `GET /channel/{channel_id}`

Returns one channel.

### `GET /channel/list?appId=...`

Lists channels.

### `PATCH /channel/{channel_id}`

Updates channel name. Slug is validated in the API, but current behavior only applies name updates.

### `DELETE /channel/{channel_id}`

Deletes channel metadata.

## Session API

### `POST /session/create`

Body:

```json
{
  "appId": "app-...",
  "type": "single"
}
```

Claude apps only support `single`.

### `GET /session/{session_id}`

Returns one session.

### `GET /session/list?appId=...`

Lists sessions.

### `DELETE /session/{session_id}`

Deletes session metadata and, for Claude sessions with external metadata, attempts to delete the provider session.

## Response Streaming API

### `POST /response/run`

Starts a run.

Body:

```json
{
  "appId": "app-...",
  "channelId": "ch-...",
  "sessionId": "optional-session-or-external-id",
  "userId": "user@example.com",
  "input": "hello"
}
```

Rules:

- App must exist in org.
- Channel must exist and belong to app.
- Channel must be `api`; iMessage channels are triggered through webhook/text flow.
- `input` must be a non-empty string.

Response:

```json
{
  "success": true,
  "data": {
    "instanceId": "inst-..."
  }
}
```

Inner flow:

1. Validate input.
2. Create an `instanceId`.
3. Spawn app-type runtime worker.
4. Return immediately with `instanceId`.
5. Worker streams events asynchronously.

### `GET /response/poll/{instance_id}?after=0&timeoutMs=25000`

Long-polls stream output.

Response:

```json
{
  "success": true,
  "data": {
    "instanceId": "inst-...",
    "events": [
      {
        "index": 0,
        "data": "{\"type\":\"...\"}"
      }
    ],
    "status": "running"
  }
}
```

Polling behavior:

- `after` is the next event index the client wants.
- `timeoutMs` is capped at `25000`.
- If events exist, returns them immediately.
- If no events arrive before timeout, returns empty `events`.
- If worker stored an error event, polling returns an API error.
- `status` is read from the instance record; if absent, it defaults to `running`.

SDK streaming behavior:

- `channel.run(...)` calls `/response/run`.
- It then repeatedly calls `/response/poll/{instanceId}`.
- It parses event `data` as JSON where possible.
- It yields `ResponseRunStreamEvent`.
- It stops when polled status is not `running`.

## Instance, History, Sync, Conflict APIs

### Instance

- `GET /instance/{instance_id}`
- `GET /instance/list?appId=...`

### History

- `GET /history/{history_id}`
- `GET /history/list`

History list can filter by at least one of:

- `appId`
- `profileId`
- `sessionId`
- `userId`
- `historyId`

### Sync

- `GET /sync/{sync_id}`
- `GET /sync/list?appId=...`

### Conflict

- `GET /conflict/{conflict_id}`
- `GET /conflict/list?appId=...`

## Webhook API

### `POST /webhook/sendblue/{channel_id}`

Used by Sendblue receive webhooks for iMessage channels.

The request is authenticated using `sb-signing-secret`, which is treated as bearer auth.

Behavior:

- Deduplicates inbound Sendblue events.
- Extracts sender number and content.
- Dispatches a normal run through the channel/profile/session machinery.
- Returns `instanceId`.

## Clone Transform Semantics

Version and state clone endpoints can patch files.

Accepted transform locations:

- `transform`
- `files`
- top-level file keys, after reserved id fields are ignored

File rules:

- `.json` target: value must be an object patch.
- `.md` target: value must be replacement string content.
- Other file extensions are rejected by HarnessLayer clone APIs.
- Existing JSON target must parse as an object.
- Missing JSON target starts as `{}`.
- Markdown targets are written as full replacement content.

Object merge:

- Nested objects merge recursively.
- Primitive values replace.
- Arrays are replaced unless using collection operators.

Patch array item by key:

```json
{
  "openclaw.json": {
    "agents": {
      "list": {
        "$by": "id",
        "$patch": {
          "main": {
            "name": "Main Agent"
          }
        }
      }
    }
  }
}
```

Patch every object in an array or object map:

```json
{
  "config.json": {
    "tools": {
      "$all": {
        "enabled": true
      }
    }
  }
}
```

Operator rules:

- `$by` must be a non-empty string.
- `$patch` must be a non-empty object.
- `$patch` keys must match existing item values for the `$by` field.
- `$all` requires an existing array or object field.
- List/object items must be objects.

No-change behavior:

- If a clone produces the same hash as the latest target, the API raises a no-change error.
- SDK clone methods return `False` for the no-change error and `True` when a new version/state was created.

## Version/State Storage Flow

HarnessLayer uses an internal Git-backed repository service plus object storage.

Conceptual storage:

```text
App version line:
  branch main
  commits Version 1, Version 2, Version 3...

Profile state line:
  branch profile-...
  commits State 1, State 2, State 3...
```

For each version/state creation:

1. Archive is decoded or downloaded.
2. Archive is extracted safely.
3. Single root directory is flattened.
4. Content hash is computed from file paths and bytes.
5. Provider metadata/map is generated.
6. Archive is stored.
7. Branch content is replaced/committed.
8. API record is inserted.
9. App/profile head pointer is updated.

Important records:

- `Version.commitHash` points at the app base commit.
- `State.commitHash` points at the profile branch commit.
- `Version.sha256` and `State.sha256` detect content equality.
- `storageUrl` points at the zip archive.

## Sync Inner Flow

`POST /version/sync` is the bulk merge operation.

Detailed flow:

1. Validate app ownership.
2. Require `App.headVersionId`.
3. Prevent concurrent in-progress sync for the same app.
4. Create `Sync` record.
5. Clear prior conflicts for the app.
6. Load head version commit/hash.
7. Find profiles with non-empty `headStateId`.
8. Chunk profiles.
9. For each chunk, load each profile's head state.
10. Skip profiles whose state hash already equals version hash.
11. Merge version commit into each target profile branch.
12. If branch merge succeeds, write new state archive and state record.
13. If branch missing or merge conflict occurs, write conflict record.
14. Aggregate counts on the sync record.
15. Final sync status becomes:
    - `complete` if all processed without failures/conflicts
    - `conflict` if any profile conflicted
    - `failed` if chunk processing failed

Sync counters include:

- `profilesExpected`
- `profilesTotal`
- `profilesMerged`
- `profilesSkipped`
- `profilesConflicted`
- `totalChunks`
- `pendingChunks`
- `failedChunks`

Strategies:

- No strategy: conflicts are surfaced.
- `ours`: Git merge strategy option favoring the profile state's side for conflicts.
- `theirs`: Git merge strategy option favoring the app main branch side for conflicts.

## Run Inner Flow

`POST /response/run` only starts work. The actual run happens asynchronously.

Runtime setup flow:

1. Load app.
2. Require app has `headVersionId`.
3. Load head version.
4. Load vault.
5. Load channel.
6. Find profile by `appId + userId`.
7. Create profile if missing.
8. Resolve access group.
9. Reset spending if interval elapsed.
10. Enforce spending limit.
11. Load profile head state if present.
12. Find session by `sessionId` as display id or app-scoped external id.
13. Create session if missing.
14. For Claude, create provider session if needed.
15. Create instance.
16. Dispatch to app-type runtime.
17. Push stream events to poll cache.
18. On completion/error, terminate instance.
19. Upsert history.
20. Insert user/assistant messages.

If profile has no state:

- Claude uses the app version's provider map.
- OpenClaw hydrates sandbox initial data from app version.

If profile has state:

- Runtime uses profile state instead of base version as current data/config.

## Claude Runtime Flow

Claude apps run through Anthropic managed agents.

Preparation:

- Version/state `map` contains ids/hashes for `agent.json`, `environment.json`, and skills.
- Vault metadata contains Anthropic vault id.
- Session metadata contains Anthropic session id.

Run flow:

1. Create HarnessLayer instance record.
2. Open Anthropic managed session event stream.
3. Send user message event.
4. Push raw provider events to HarnessLayer stream.
5. Track model token usage from model request end events.
6. Yield agent text messages for iMessage splitting/sending.
7. On idle/end, push a HarnessLayer session-end event.
8. Calculate cost using pricing data.
9. Increment profile spending.
10. Terminate instance.
11. Persist history/messages.

Special stream events:

- HarnessLayer emits `driftstone.session_start`.
- HarnessLayer emits `driftstone.session_end` with usage.

## OpenClaw Runtime Flow

OpenClaw apps run in sandboxed runtime workers.

Preparation:

- One cached sandbox is usually reused per `appId + userId`.
- A session lock prevents concurrent runs for the same app/profile/session.
- A temporary OpenRouter API key is provisioned for the sandbox.
- Initial data is downloaded from profile state if present, otherwise app version.
- Initial data is hydrated into the sandbox's OpenClaw home.
- Profile metadata keys that are valid environment variable names are injected into sandbox environment.

Model/agent/plugin config:

- Default model comes from OpenClaw metadata if present.
- Default agent comes from OpenClaw metadata if present.
- Browser plugin env is enabled if metadata includes a browser plugin.

Run flow:

1. Acquire session lock.
2. Create instance record.
3. Reuse cached sandbox or create a new one.
4. Hydrate env and initial data.
5. Wait for gateway tunnel.
6. Send request to sandbox gateway `/v1/responses`.
7. Stream response events.
8. Push events to HarnessLayer stream.
9. Accumulate output text.
10. Store latest response id in session metadata.
11. Send webhook for cron-triggered API channel responses when configured.
12. Persist sandbox current data back as state.
13. Persist discovered cron jobs.
14. Calculate usage/cost from OpenRouter key.
15. Update profile spending.
16. Terminate instance.
17. Persist history/messages.
18. Release session lock.

OpenClaw sandbox cache:

```text
sb:<appId>_<userId>
```

This means sandbox reuse is tied to app and user identifier.

## iMessage Flow

Channel creation:

1. Validate Sendblue credentials and from number.
2. Ensure number supports iMessage.
3. Register receive webhook.
4. Encrypt credentials.
5. Store channel.

Inbound message:

1. Sendblue calls HarnessLayer webhook.
2. HarnessLayer authenticates via signing secret.
3. HarnessLayer deduplicates inbound event.
4. HarnessLayer creates run submission for channel/app/user.
5. Runtime streams response text.
6. Runtime sends typing indicator and outbound Sendblue messages.

Response splitting:

- Messages can be separated by blank lines or `---` separator lines.
- Media URLs can be sent if formatted as supported image/media URL, markdown image, or JSON-like media payload.

## Webhook Behavior for API Channels

API channels may define a webhook.

For OpenClaw cron-triggered runs, HarnessLayer can send:

```json
{
  "type": "openclaw.response",
  "appId": "app-...",
  "channelId": "ch-...",
  "sessionId": "session-...",
  "userId": "user@example.com",
  "instanceId": "inst-...",
  "input": "...",
  "result": "...",
  "metadata": {
    "externalSessionId": "..."
  },
  "sentAt": "..."
}
```

Configured webhook headers are merged into default JSON headers.

## Download APIs

Version and state download APIs do not return archive bytes directly. They return short-lived signed URLs.

Version:

```text
GET /version/download/{version_id}
```

State:

```text
POST /state/download/{state_id}
```

The SDK downloads the signed URL and extracts the zip locally.

## Recommended API Workflows

### Create App and Run

1. `POST /app/init` with base version archive.
2. `POST /channel/create` with `type=api`.
3. `POST /profile/init` for each user you want pre-initialized.
4. `POST /response/run`.
5. Poll `/response/poll/{instanceId}` until status is not `running`.

### Update App Defaults

1. Inspect the current app defaults and explain what will change.
2. `POST /version/clone` with transforms, or `POST /version/create` with a new archive.
3. Report that the new version was created.
4. Suggest syncing the new version into existing profile states and ask for approval.
5. Only after approval, `POST /version/sync` to merge new defaults into existing profile states.
6. Monitor `/sync/{syncId}`.
7. Inspect `/conflict/list?appId=...` if sync status is `conflict`.

### Update One User

1. Find profile.
2. `POST /state/clone` with that `profileId` and transforms.
3. Run using same `userId`; runtime now uses the updated profile state.

### Reset One User to App Version

Use `POST /state/clone` with:

```json
{
  "profileId": "profile-...",
  "versionId": "ver-..."
}
```

This creates a new state from the app version and moves the profile head.

### Read Current App Config

1. `GET /version/latest?appId=...`.
2. `GET /version/download/{versionId}`.
3. Download/extract signed URL.

### Read Current User State

1. `GET /state/latest?profileId=...`.
2. `POST /state/download/{stateId}`.
3. Download/extract signed URL.

## Gotchas for API Users

- Version is app-wide. State is per-profile. Do not write user memory into versions.
- `profile.create` does not initialize state; `profile.init` does.
- Runtime may auto-create a profile, but it may run from app version if no state exists.
- App version sync is the intended way to propagate app-wide changes to profile states.
- After an app version is created, always suggest syncing it to existing profile states, but ask for approval and the `ours`/`theirs` sync strategy before starting the sync.
- Sync can create conflicts. Always check sync status.
- Clone transforms only support `.json` and `.md` files.
- Clone transform no-op can fail at API level; SDK clone returns `False`.
- iMessage channels cannot be run through `/response/run`; text the configured number instead.
- `/response/run` rejects blank input.
- Polling may end without a final event that has `done=True`; use poll status to detect termination.
- Download endpoints return signed URLs, not direct content.
- Some list routes may be affected by route ordering in the current API implementation. If `/list` behaves like an id lookup, this is likely why.
- `PATCH /channel/{id}` currently only applies `name` updates.
- `GET /app/list` currently expects an `appId` query parameter even though listing is org-scoped.

## Quick Reference

App:

- `POST /app/create`
- `POST /app/init`
- `GET /app/{app_id_or_slug}`
- `GET /app/list?appId=...`
- `PATCH /app/{app_id}`
- `DELETE /app/{app_id_or_slug}`

Version:

- `POST /version/create`
- `POST /version/clone`
- `POST /version/sync`
- `GET /version/diff?appId=...&baseCommit=...&headCommit=...`
- `GET /version/latest?appId=...`
- `GET /version/{version_id}`
- `GET /version/list?appId=...`
- `GET /version/download/{version_id}`
- `POST /version/temp`

Profile:

- `POST /profile/create`
- `POST /profile/init`
- `GET /profile/{profile_id}`
- `GET /profile/list?appId=...`
- `PATCH /profile/{profile_id}`
- `DELETE /profile/{profile_id}`

State:

- `POST /state/create`
- `POST /state/clone`
- `POST /state/download/{state_id}`
- `GET /state/latest?profileId=...`
- `GET /state/{state_id}`
- `GET /state/list?profileId=...`

Channel:

- `POST /channel/create`
- `GET /channel/{channel_id}`
- `GET /channel/list?appId=...`
- `PATCH /channel/{channel_id}`
- `DELETE /channel/{channel_id}`

Run:

- `POST /response/run`
- `GET /response/poll/{instance_id}`

Other:

- `POST /session/create`
- `GET /session/{session_id}`
- `GET /session/list?appId=...`
- `DELETE /session/{session_id}`
- `GET /instance/{instance_id}`
- `GET /instance/list?appId=...`
- `GET /history/{history_id}`
- `GET /history/list?...`
- `GET /sync/{sync_id}`
- `GET /sync/list?appId=...`
- `GET /conflict/{conflict_id}`
- `GET /conflict/list?appId=...`
- `POST /webhook/sendblue/{channel_id}`

## Final Operating Principle

Before making any API call, decide which layer you are changing:

- App defaults: create or clone a `Version`.
- One user's memory/config: create or clone a `State`.
- App defaults into user branches: run `Version.sync`.
- Conversation/run: use `Channel` + `Session` + `Response`.
- Billing/access: use `AccessGroup` and profile spending.

That distinction keeps HarnessLayer predictable: version is the initial app config, state is the user's branch, and runtime chooses state first when it exists.
