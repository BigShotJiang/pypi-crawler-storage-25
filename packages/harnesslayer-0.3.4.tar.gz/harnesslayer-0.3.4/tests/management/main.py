from pathlib import Path
from harnesslayer import Harnesslayer

USER_IDENTIFIER = "16044401225"
USER_IDENTIFIER_2 = "15109183162"
USER_IDENTIFIER_3 = "17742751688"
HOLLY_APP_ID = "app-cc6e9f73-a8a9-4731-996d-4a63808061bd"
PICKAXE_APP_ID = "app-918b5455-dcbd-401f-a372-e18750976eac"

client = Harnesslayer(api_key="dk-bf941a1e-2d8e-44f1-b5c2-25ef9b78a80c")

config_folder = str(Path(__file__).resolve().parent / ".openclaw")

# client.app.delete("app-bfed48cb-876b-460e-9578-2f343cf338a9")

app = client.app.init("management-agent", 
    type="openclaw",
    version_path=config_folder,
    auto_update_version=False,
)

app.version.sync(strategy="theirs")

# app.profile.delete("profile-70b57efc-3502-4040-bd74-3c5f54583086")

# channel = app.channel.init("management-imessage", 
#     type="imessage",
#     data={
#         "sendBlueAPIKey": "8b93f24cff36b3ba1248402c6a2856bb",
#         "sendBlueSecretKey": "996d24e34c9ed0092c4eeebbbabfe3f9",
#         "fromNumber": "+13632189094",
#     },
# )

# app.profile.init(
#     identifier="16044401225",
#     metadata={
#         "HARNESSLAYER_APP_ID": "app-918b5455-dcbd-401f-a372-e18750976eac",
#         "HARNESSLAYER_API_KEY": "dk-bf941a1e-2d8e-44f1-b5c2-25ef9b78a80c",
#     },
#     auto_update_state=False,
# )

# stream = channel.run( 
#     session_id="test-session-1", 
#     user_id=USER_IDENTIFIER,
#     input="Can you change the name of the app to Typedef Claw but keep slug the same"
# )

# for event in stream:
#     if event.data["type"] == "driftstone.session_end":
#         break

#     print(event)
