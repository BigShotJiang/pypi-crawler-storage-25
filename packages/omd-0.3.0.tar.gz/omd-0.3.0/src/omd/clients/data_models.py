"""omd/clients/data_models.py.

Pydantic models used by OMD clients.
"""

from __future__ import annotations

import os

from pydantic import BaseModel, Field


class Model(BaseModel):
    """Model configuration for a client instance."""

    name: str
    url: str
    api_token: str | None = Field(default=None, exclude=True)

    @classmethod
    def from_env(cls) -> Model:
        """Build a :class:`Model` from required environment variables.

        Reads ``MODEL_NAME``, ``MODEL_URL``, and ``MODEL_API_TOKEN``. Each is
        required: missing variables raise :class:`KeyError`, matching the
        OMD environment-variable conventions.

        :returns: A :class:`Model` populated from the environment.
        :raises KeyError: If any of the required variables is unset.
        """
        return cls(
            name=os.environ["MODEL_NAME"],
            url=os.environ["MODEL_URL"],
            api_token=os.environ["MODEL_API_TOKEN"],
        )
