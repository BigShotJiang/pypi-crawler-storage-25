"""omd/clients/__init__.py.

Client implementations for OMD.
"""

from .apibar import ApiBarClient
from .data_models import Model

# Optional OpenAI SDK client (requires 'openai' extra)
try:
    from .openai_sdk import OpenAISDKClient
except ImportError:
    OpenAISDKClient = None  # type: ignore[misc, assignment]

__all__ = ["ApiBarClient", "Model", "OpenAISDKClient"]
