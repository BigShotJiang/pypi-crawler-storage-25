"""omd/clients/apibar.py.

ApiBar client implementation.
"""

from __future__ import annotations

import logging
from typing import Any

import requests

from omd.clients.base import BaseClient

LOGGER = logging.getLogger(__name__)


class ApiBarClient(BaseClient):
    """Client for ApiBar-compatible chat/completions endpoints."""

    @property
    def headers(self) -> dict[str, str]:
        """Return default authorization headers."""
        return {
            "Authorization": f"Bearer {self.model.api_token}",
        }

    def call_model(
        self,
        messages: list[dict[str, Any]],
        tools: list[dict[str, Any]] | None = None,
        tool_choice: str | dict[str, Any] | None = None,
        parallel_tool_calls: bool | None = None,
        timeout_s: float | None = None,
    ) -> Any:
        """Call ApiBar model endpoint.

        :param messages: Chat messages to send to the model.
        :param tools: OpenAI-style tool specs (function calling),
            e.g. ``[{"type": "function", ...}]``.
        :param tool_choice: OpenAI-style tool choice control.
        :param parallel_tool_calls: Whether the model may emit multiple
            tool calls in a single turn.
        :param timeout_s: Optional request timeout in seconds.
        :returns: Decoded JSON response from the provider.
        :raises ValueError: If ``tool_choice`` requires tools but ``tools``
            was not provided.
        """
        if tools is None and tool_choice not in (None, "auto", "none"):
            raise ValueError("tool_choice requires tools to be provided")

        payload = {
            "model": self.model.name,
            "messages": messages,
        }
        if tools is not None:
            payload["tools"] = tools
        if tool_choice is not None:
            payload["tool_choice"] = tool_choice
        if parallel_tool_calls is not None:
            payload["parallel_tool_calls"] = parallel_tool_calls
        response = requests.post(
            self.model.url, json=payload, headers=self.headers, timeout=timeout_s,
        )
        if not response.ok:
            LOGGER.error(
                "ApiBar request failed. status=%s body=%s",
                response.status_code,
                response.text,
            )
            response.raise_for_status()
        try:
            return response.json()
        except ValueError:
            LOGGER.error(
                "ApiBar response is not JSON. status=%s body=%s",
                response.status_code,
                response.text,
            )
            raise
