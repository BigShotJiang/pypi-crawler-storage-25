"""omd/clients/openai_sdk.py.

OpenAI-SDK-backed client for :class:`omd.agents.BaseAgent`.

``omd.clients.ApiBarClient`` performs raw HTTP calls via ``requests``.
Many endpoints (Perplexity, OpenAI itself, OpenAI-compatible gateways
such as Together/Fireworks/Groq/Azure) are easier to consume through
the official ``openai`` Python SDK with a custom ``base_url``.  This
module bridges that to ``omd``'s :class:`omd.clients.base.BaseClient`
interface and returns responses as plain ``dict`` objects matching the
JSON shape that :class:`omd.agents.BaseAgent` expects.
"""

from __future__ import annotations

import logging
from typing import Any

try:
    from openai import OpenAI
    from openai.types.chat import ChatCompletion
except ImportError as exc:
    raise ImportError(
        "The 'openai' package is required to use OpenAISDKClient. "
        "Install it with: pip install omd[openai] or pip install openai"
    ) from exc

from omd.clients.base import BaseClient
from omd.clients.data_models import Model

logger = logging.getLogger(__name__)


class OpenAISDKClient(BaseClient):
    """omd-compatible client backed by the official ``openai`` Python SDK.

    The client uses ``model.url`` as the OpenAI SDK ``base_url`` (so it
    must NOT include the ``/chat/completions`` suffix — strip it
    beforehand) and ``model.api_token`` as the API key.

    :param model: ``omd`` :class:`Model` with ``name`` (sent as
        ``model``), ``url`` (sent as ``base_url``), and ``api_token``.
    :param temperature: Default sampling temperature.
    :param client: Pre-built ``openai.OpenAI`` instance to reuse.
        When omitted, a new client is constructed from ``model``.
    """

    def __init__(
        self,
        model: Model,
        *,
        temperature: float = 0.1,
        client: OpenAI | None = None,
    ) -> None:
        super().__init__(model)
        self.temperature = temperature
        self._client = client or OpenAI(
            api_key=model.api_token,
            base_url=model.url,
        )

    def call_model(
        self,
        messages: list[dict[str, Any]],
        tools: list[dict[str, Any]] | None = None,
        tool_choice: str | dict[str, Any] | None = None,
        parallel_tool_calls: bool | None = None,
        headers: dict[str, str] | None = None,
        timeout_s: float | None = None,
    ) -> dict[str, Any]:
        """Call ``chat.completions.create`` and return a JSON-shaped dict.

        :param messages: Chat messages in OpenAI format.
        :param tools: OpenAI-style tool specs (function-calling).
        :param tool_choice: OpenAI-style tool-choice control.
        :param parallel_tool_calls: Whether the model may emit multiple
            tool calls in a single turn.
        :param headers: Optional HTTP headers (ignored for SDK client;
            pass custom client to constructor if needed).
        :param timeout_s: Optional per-request timeout in seconds.
        :returns: Raw provider response as a ``dict`` (output of
            ``ChatCompletion.model_dump(mode="json")``).
        """
        kwargs: dict[str, Any] = {
            "model": self.model.name,
            "messages": messages,
            "temperature": self.temperature,
        }
        if tools is not None:
            kwargs["tools"] = tools
        if tool_choice is not None:
            kwargs["tool_choice"] = tool_choice
        if parallel_tool_calls is not None:
            kwargs["parallel_tool_calls"] = parallel_tool_calls
        if timeout_s is not None:
            kwargs["timeout"] = timeout_s

        logger.debug(
            "Calling OpenAI SDK: model=%s, tools=%s, tool_choice=%s",
            self.model.name,
            len(tools) if tools else 0,
            tool_choice,
        )

        response: ChatCompletion = self._client.chat.completions.create(**kwargs)

        tool_calls_count = 0
        if response.choices and response.choices[0].message.tool_calls:
            tool_calls_count = len(response.choices[0].message.tool_calls)
        logger.debug(
            "OpenAI SDK response: finish_reason=%s, tool_calls=%s",
            response.choices[0].finish_reason if response.choices else None,
            tool_calls_count,
        )

        return response.model_dump(mode="json")

    def stream_model(
        self,
        messages: list[dict[str, Any]],
        tools: list[dict[str, Any]] | None = None,
        tool_choice: str | dict[str, Any] | None = None,
        parallel_tool_calls: bool | None = None,
        timeout_s: float | None = None,
    ) -> Any:
        """Call ``chat.completions.create`` with streaming enabled.

        This method returns a streaming response that yields chunks
        incrementally. Useful for streaming agents.

        :param messages: Chat messages in OpenAI format.
        :param tools: OpenAI-style tool specs (function-calling).
        :param tool_choice: OpenAI-style tool-choice control.
        :param parallel_tool_calls: Whether the model may emit multiple
            tool calls in a single turn.
        :param timeout_s: Optional per-request timeout in seconds.
        :returns: Streaming response iterator yielding ChatCompletionChunk.
        """
        kwargs: dict[str, Any] = {
            "model": self.model.name,
            "messages": messages,
            "temperature": self.temperature,
            "stream": True,
        }
        if tools is not None:
            kwargs["tools"] = tools
        if tool_choice is not None:
            kwargs["tool_choice"] = tool_choice
        if parallel_tool_calls is not None:
            kwargs["parallel_tool_calls"] = parallel_tool_calls
        if timeout_s is not None:
            kwargs["timeout"] = timeout_s

        logger.debug(
            "Calling OpenAI SDK (streaming): model=%s, tools=%s",
            self.model.name,
            len(tools) if tools else 0,
        )

        return self._client.chat.completions.create(**kwargs)
