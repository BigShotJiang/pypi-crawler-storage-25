"""omd/clients/base.py.

Base interfaces for OMD model clients.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any

from omd.clients.data_models import Model


class BaseClient(ABC):
    """Abstract base class for model clients."""

    def __init__(self, model: Model):
        self.model = model

    @abstractmethod
    def call_model(
        self,
        messages: list[dict[str, Any]],
        tools: list[dict[str, Any]] | None = None,
        tool_choice: str | dict[str, Any] | None = None,
        parallel_tool_calls: bool | None = None,
        headers: dict[str, str] | None = None,
        timeout_s: float | None = None,
    ) -> Any:
        """Call the underlying model endpoint.

        :param messages: Chat messages in the provider-compatible format.
        :param tools: OpenAI-style tool specs (function calling),
            e.g. ``[{"type": "function", ...}]``.
        :param tool_choice: OpenAI-style tool choice control. Common values are
            ``"auto"`` and ``"none"``, or a dict like
            ``{"type": "function", "function": {"name": "my_tool"}}``.
        :param parallel_tool_calls: Whether the model is allowed to emit
            multiple tool calls in a single turn.
        :param headers: Optional HTTP headers (e.g. ``Authorization``).
        :param timeout_s: Optional request timeout in seconds.
        :returns: Provider response payload (decoded JSON).
        """
        raise NotImplementedError
