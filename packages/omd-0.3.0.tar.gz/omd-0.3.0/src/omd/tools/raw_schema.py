"""omd/tools/raw_schema.py.

Build :class:`omd.tools.Tool` instances directly from raw JSON schemas.

``omd.tools.Tool.from_callable`` infers a JSON schema from a callable's
type hints and Sphinx docstring.  The auto-generated schema only
supports flat scalar parameter types (``str``/``int``/``float``/
``bool``/``list``/``dict``); it cannot express OpenAI features such as
``enum``, nullable types (``["string", "null"]``), ``items`` schemas,
or nested object properties.

This module lets you keep authoring tool schemas as raw ``dict``
objects in the exact shape OpenAI's function-calling API expects,
while still benefiting from ``omd``'s tool dispatch / validation /
error handling.
"""

from __future__ import annotations

from collections.abc import Callable
from typing import Any

from omd.tools.data_models import (
    Function,
    Parameters,
    Tool,
    ToolArgumentsValidator,
)


class RawSchemaTool(Tool):
    """:class:`omd.tools.Tool` subclass that emits a user-supplied schema.

    The strict :class:`omd.tools.data_models.Function` /
    :class:`Parameters` / :class:`Property` validators reject features
    such as ``enum``, ``["string", "null"]`` types, ``items``, and
    nested object properties.  This subclass stores the original raw
    OpenAI tool spec and returns it verbatim from :meth:`model_dump`.

    :param raw_schema: Original tool spec dict (root keys ``type`` and
        ``function`` matching the OpenAI function-calling format).
    """

    raw_schema: dict[str, Any] | None = None

    def model_dump(self, **kwargs: Any) -> dict[str, Any]:
        """Return the original raw schema (or fall back to the parent).

        :param kwargs: Forwarded to :meth:`Tool.model_dump` if no raw
            schema was attached.
        :returns: Dict suitable for the OpenAI ``tools`` parameter.
        """
        if self.raw_schema is not None:
            return self.raw_schema
        return super().model_dump(**kwargs)


def tool_from_schema(
    schema: dict[str, Any],
    func: Callable[..., Any],
    *,
    validator: ToolArgumentsValidator | None = None,
) -> Tool:
    """Build an :class:`omd.tools.Tool` from a raw OpenAI tool schema.

    :param schema: Full tool spec, e.g.
        ``{"type": "function", "function": {"name": ..., "parameters": ...}}``.
    :param func: Python callable implementing the tool.  Must accept
        keyword arguments matching the property names in ``schema``.
    :param validator: Optional arguments validator/normalizer (see
        :class:`~omd.tools.data_models.ToolArgumentsValidator`).
    :returns: :class:`RawSchemaTool` whose ``model_dump`` yields
        ``schema`` and whose ``invoke`` calls ``func``.
    :raises KeyError: If ``schema`` does not contain ``function.name``.

    Example usage::

        TOOL_SCHEMA = {
            "type": "function",
            "function": {
                "name": "search_items",
                "description": "Search items by query.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "query": {"type": "string"},
                        "category": {
                            "type": "string",
                            "enum": ["electronics", "books", "clothing"],
                        },
                        "limit": {
                            "type": ["integer", "null"],
                            "default": 10,
                        },
                    },
                    "required": ["query"],
                },
            },
        }

        def search_items(query: str, category: str | None = None, limit: int = 10) -> str:
            results = db.search(query, category=category, limit=limit)
            return json.dumps(results)

        tool = tool_from_schema(TOOL_SCHEMA, search_items)
    """
    function_spec = schema["function"]
    name = function_spec["name"]
    description = function_spec.get("description", "")

    function = Function(
        name=name,
        description=description,
        parameters=Parameters(properties={}, required=[]),
    )
    return RawSchemaTool(
        function=function,
        callable=func,
        validator=validator,
        raw_schema=schema,
    )
