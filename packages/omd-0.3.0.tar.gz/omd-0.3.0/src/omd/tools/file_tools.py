"""omd/tools/file_tools.py.

Line-precise file manipulation tools suitable for agent tool-calling.

All functions accept a string ``path`` for OpenAI-compatible JSON schema
generation via :meth:`omd.tools.data_models.Tool.from_callable`. They use
1-indexed inclusive line numbers, matching common editor conventions.
"""

from __future__ import annotations

import logging
from pathlib import Path

from omd.tools.data_models import Tool, ToolValidationError

LOGGER = logging.getLogger(__name__)

_DEFAULT_READ_LIMIT = 200
_MAX_READ_LIMIT = 5000


def _resolve_within_workspace(path: str, workspace_root: Path | None) -> Path:
    """Resolve ``path`` and ensure it stays inside ``workspace_root``.

    :param path: Path to resolve.
    :param workspace_root: Already-resolved workspace root, or ``None`` to
        skip the containment check.
    :returns: The resolved absolute :class:`Path`.
    :raises ToolValidationError: If the resolved path is outside the
        workspace root.
    """
    candidate = Path(path).expanduser()
    try:
        resolved = candidate.resolve()
    except OSError as exc:
        raise ToolValidationError(
            tool_name="<file-tool>",
            message=f"Failed to resolve path {path!r}: {exc}",
            tool_arguments={"path": path},
        ) from exc

    if workspace_root is not None:
        try:
            resolved.relative_to(workspace_root)
        except ValueError as exc:
            raise ToolValidationError(
                tool_name="<file-tool>",
                message=(
                    f"Path {resolved} is outside the configured workspace root "
                    f"{workspace_root}"
                ),
                tool_arguments={"path": path},
            ) from exc

    return resolved


def _require_existing_file(resolved: Path) -> Path:
    """Return ``resolved`` after asserting it points to an existing regular file.

    :param resolved: Resolved absolute path.
    :returns: Same path, for chaining.
    :raises ToolValidationError: If the file does not exist or is a directory.
    """
    if not resolved.exists():
        raise ToolValidationError(
            tool_name="<file-tool>",
            message=f"File not found: {resolved}",
            tool_arguments={"path": str(resolved)},
        )
    if resolved.is_dir():
        raise ToolValidationError(
            tool_name="<file-tool>",
            message=f"Path is a directory, expected file: {resolved}",
            tool_arguments={"path": str(resolved)},
        )
    return resolved


def _read_text(resolved: Path) -> list[str]:
    """Read file as a list of lines preserving line endings."""
    return resolved.read_text(encoding="utf-8").splitlines(keepends=True)


def _format_lines(lines: list[str], start_line: int) -> str:
    """Render lines with 1-indexed ``LINE|content`` prefixes for readability."""
    width = max(4, len(str(start_line + len(lines) - 1)))
    out: list[str] = []
    for offset, raw in enumerate(lines):
        line_no = start_line + offset
        text = raw.rstrip("\n").rstrip("\r")
        out.append(f"{str(line_no).rjust(width)}|{text}")
    return "\n".join(out)


def _read_fragment_impl(
    path: str,
    offset: int,
    limit: int,
    workspace_root: Path | None,
) -> str:
    """Shared implementation for reading a slice of a file."""
    if offset < 1:
        raise ToolValidationError(
            tool_name="read_fragment",
            message=f"offset must be >= 1, got {offset}",
            tool_arguments={"path": path, "offset": offset, "limit": limit},
        )
    if limit < 1 or limit > _MAX_READ_LIMIT:
        raise ToolValidationError(
            tool_name="read_fragment",
            message=f"limit must be in [1, {_MAX_READ_LIMIT}], got {limit}",
            tool_arguments={"path": path, "offset": offset, "limit": limit},
        )

    resolved = _require_existing_file(_resolve_within_workspace(path, workspace_root))
    lines = _read_text(resolved)
    if offset > len(lines):
        return f"<empty: file has {len(lines)} line(s), offset {offset}>"
    end = min(len(lines), offset - 1 + limit)
    fragment = lines[offset - 1 : end]
    return _format_lines(fragment, offset)


def _read_lines_impl(
    path: str,
    start: int,
    end: int,
    workspace_root: Path | None,
) -> str:
    """Shared implementation for reading an inclusive line range."""
    if start < 1 or end < start:
        raise ToolValidationError(
            tool_name="read_lines",
            message=f"invalid range [start={start}, end={end}]",
            tool_arguments={"path": path, "start": start, "end": end},
        )
    if end - start + 1 > _MAX_READ_LIMIT:
        raise ToolValidationError(
            tool_name="read_lines",
            message=(
                f"requested range size {end - start + 1} exceeds max {_MAX_READ_LIMIT}"
            ),
            tool_arguments={"path": path, "start": start, "end": end},
        )

    resolved = _require_existing_file(_resolve_within_workspace(path, workspace_root))
    lines = _read_text(resolved)
    if start > len(lines):
        return f"<empty: file has {len(lines)} line(s), start {start}>"
    capped_end = min(len(lines), end)
    return _format_lines(lines[start - 1 : capped_end], start)


def _insert_lines_impl(
    path: str,
    line: int,
    content: str,
    workspace_root: Path | None,
) -> str:
    """Shared implementation for inserting a block before ``line``."""
    if line < 1:
        raise ToolValidationError(
            tool_name="insert_lines",
            message=f"line must be >= 1, got {line}",
            tool_arguments={"path": path, "line": line},
        )
    if not isinstance(content, str) or content == "":
        raise ToolValidationError(
            tool_name="insert_lines",
            message="content must be a non-empty string",
            tool_arguments={"path": path, "line": line},
        )

    resolved = _require_existing_file(_resolve_within_workspace(path, workspace_root))
    original = _read_text(resolved)
    if line > len(original) + 1:
        raise ToolValidationError(
            tool_name="insert_lines",
            message=f"line {line} out of range [1, {len(original) + 1}]",
            tool_arguments={"path": path, "line": line},
        )

    new_lines = content.splitlines(keepends=True)
    if new_lines and not new_lines[-1].endswith(("\n", "\r")):
        new_lines[-1] += "\n"

    insert_at = line - 1
    updated = original[:insert_at] + new_lines + original[insert_at:]
    resolved.write_text("".join(updated), encoding="utf-8")
    LOGGER.debug("Inserted %d line(s) at %d in %s", len(new_lines), line, resolved)
    return (
        f"Inserted {len(new_lines)} line(s) at line {line}. "
        f"File now has {len(updated)} line(s)."
    )


def _delete_lines_impl(
    path: str,
    start: int,
    end: int,
    workspace_root: Path | None,
) -> str:
    """Shared implementation for deleting an inclusive line range."""
    if start < 1 or end < start:
        raise ToolValidationError(
            tool_name="delete_lines",
            message=f"invalid range [start={start}, end={end}]",
            tool_arguments={"path": path, "start": start, "end": end},
        )

    resolved = _require_existing_file(_resolve_within_workspace(path, workspace_root))
    original = _read_text(resolved)
    if end > len(original):
        raise ToolValidationError(
            tool_name="delete_lines",
            message=(
                f"range [{start}, {end}] out of bounds for file with "
                f"{len(original)} line(s)"
            ),
            tool_arguments={"path": path, "start": start, "end": end},
        )

    updated = original[: start - 1] + original[end:]
    resolved.write_text("".join(updated), encoding="utf-8")
    deleted = end - start + 1
    LOGGER.debug("Deleted lines %d-%d (%d) from %s", start, end, deleted, resolved)
    return (
        f"Deleted {deleted} line(s) ({start}-{end}). "
        f"File now has {len(updated)} line(s)."
    )


def read_fragment(path: str, offset: int = 1, limit: int = _DEFAULT_READ_LIMIT) -> str:
    """Read a slice of a text file starting at ``offset``.

    :param path: Path to the file.
    :param offset: 1-indexed starting line. Must be ``>= 1``.
    :param limit: Maximum number of lines to return. Capped at 5000.
    :returns: ``LINE|content`` formatted text with each requested line.
    """
    return _read_fragment_impl(path, offset, limit, workspace_root=None)


def read_lines(path: str, start: int, end: int) -> str:
    """Read an inclusive line range from a text file.

    :param path: Path to the file.
    :param start: 1-indexed first line to read (inclusive).
    :param end: 1-indexed last line to read (inclusive).
    :returns: ``LINE|content`` formatted text for the requested range.
    """
    return _read_lines_impl(path, start, end, workspace_root=None)


def insert_lines(path: str, line: int, content: str) -> str:
    """Insert ``content`` into the file before the given 1-indexed line.

    Use ``line = file_length + 1`` to append at the end. The inserted block
    keeps its own trailing newline; existing lines are not rewritten.

    :param path: Path to the file.
    :param line: 1-indexed line number; new content is inserted *before* it.
    :param content: Text to insert (a single string; may contain newlines).
    :returns: A short status message describing what was changed.
    """
    return _insert_lines_impl(path, line, content, workspace_root=None)


def delete_lines(path: str, start: int, end: int) -> str:
    """Delete the inclusive 1-indexed line range ``[start, end]``.

    :param path: Path to the file.
    :param start: 1-indexed first line to delete.
    :param end: 1-indexed last line to delete (inclusive).
    :returns: A short status message describing how many lines were deleted.
    """
    return _delete_lines_impl(path, start, end, workspace_root=None)


def make_file_tools(
    *,
    workspace_root: str | Path | None = None,
) -> list[Tool]:
    """Build agent-ready file manipulation tools, optionally sandboxed.

    When ``workspace_root`` is provided, every tool call validates that
    the resolved target path lies under that root (symlinks are followed
    before the check). Pass ``None`` for an unrestricted set of tools.

    :param workspace_root: Optional directory that bounds all file accesses.
    :returns: List of :class:`Tool` instances:
        ``[read_fragment, read_lines, insert_lines, delete_lines]``.
    :raises ToolValidationError: At call time, if the requested path falls
        outside ``workspace_root``.
    """
    root: Path | None = None
    if workspace_root is not None:
        root_path = Path(workspace_root).expanduser().resolve()
        if not root_path.is_dir():
            raise ValueError(
                f"workspace_root must point to an existing directory, got {workspace_root!r}"
            )
        root = root_path

    def _read_fragment(
        path: str, offset: int = 1, limit: int = _DEFAULT_READ_LIMIT
    ) -> str:
        """Read a slice of a text file starting at ``offset``.

        :param path: Path to the file.
        :param offset: 1-indexed starting line. Must be ``>= 1``.
        :param limit: Maximum number of lines to return. Capped at 5000.
        :returns: ``LINE|content`` formatted text with each requested line.
        """
        return _read_fragment_impl(path, offset, limit, workspace_root=root)

    _read_fragment.__name__ = "read_fragment"

    def _read_lines(path: str, start: int, end: int) -> str:
        """Read an inclusive line range from a text file.

        :param path: Path to the file.
        :param start: 1-indexed first line to read (inclusive).
        :param end: 1-indexed last line to read (inclusive).
        :returns: ``LINE|content`` formatted text for the requested range.
        """
        return _read_lines_impl(path, start, end, workspace_root=root)

    _read_lines.__name__ = "read_lines"

    def _insert_lines(path: str, line: int, content: str) -> str:
        """Insert ``content`` into the file before the given 1-indexed line.

        Use ``line = file_length + 1`` to append at the end.

        :param path: Path to the file.
        :param line: 1-indexed line number; new content is inserted *before* it.
        :param content: Text to insert (a single string; may contain newlines).
        :returns: A short status message describing what was changed.
        """
        return _insert_lines_impl(path, line, content, workspace_root=root)

    _insert_lines.__name__ = "insert_lines"

    def _delete_lines(path: str, start: int, end: int) -> str:
        """Delete the inclusive 1-indexed line range ``[start, end]``.

        :param path: Path to the file.
        :param start: 1-indexed first line to delete.
        :param end: 1-indexed last line to delete (inclusive).
        :returns: A short status message describing how many lines were deleted.
        """
        return _delete_lines_impl(path, start, end, workspace_root=root)

    _delete_lines.__name__ = "delete_lines"

    return [
        Tool.from_callable(_read_fragment),
        Tool.from_callable(_read_lines),
        Tool.from_callable(_insert_lines),
        Tool.from_callable(_delete_lines),
    ]
