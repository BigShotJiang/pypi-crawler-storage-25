"""omd/tools/data_models.py.

Pydantic models for tool definitions (OpenAI-compatible function calling schema).
"""

from __future__ import annotations

import inspect
import json
import logging
import re
from collections.abc import Callable
from typing import Any, Literal, get_type_hints

from pydantic import BaseModel, ConfigDict

logger = logging.getLogger(__name__)

TYPE_MAP: dict[type, Literal["string", "number", "boolean", "array", "object"]] = {
    str: "string",
    int: "number",
    float: "number",
    bool: "boolean",
    list: "array",
    dict: "object",
}


class NotNoneBaseModel(BaseModel):
    """Base model with exclude_none serialization."""

    def model_dump(self, **kwargs: Any) -> dict[str, Any]:
        """Dump model excluding None values by default."""
        kwargs.setdefault("exclude_none", True)
        return super().model_dump(**kwargs)

    def model_dump_json(self, **kwargs: Any) -> str:
        """Dump model to JSON excluding None values by default."""
        kwargs.setdefault("exclude_none", True)
        return super().model_dump_json(**kwargs)


class Property(NotNoneBaseModel):
    """JSON Schema property definition for a function parameter."""

    type: Literal["string", "number", "boolean", "array", "object"]
    description: str
    minimum: int | None = None
    maximum: int | None = None
    default: Any | None = None


class Parameters(NotNoneBaseModel):
    """JSON Schema object type for function parameters."""

    type: Literal["object"] = "object"
    properties: dict[str, Property]
    required: list[str]


class Function(NotNoneBaseModel):
    """OpenAI-compatible function schema."""

    name: str
    description: str
    parameters: Parameters


def _parse_param_descriptions(docstring: str | None) -> dict[str, str]:
    """Extract parameter descriptions from Sphinx docstring.

    :param docstring: Function docstring.
    :returns: Dictionary ``{param_name: description}``.
    """
    if not docstring:
        return {}
    pattern = r":param\s+(\w+):\s*(.+?)(?=:param|:return|:raises|:rtype|\Z)"
    matches = re.findall(pattern, docstring, re.DOTALL)
    return {name: " ".join(desc.split()) for name, desc in matches}


def _build_parameters(func: Callable[..., Any]) -> Parameters:
    """Build Parameters from function signature and docstring.

    :param func: Callable to analyze.
    :returns: Pydantic Parameters model.
    """
    sig = inspect.signature(func)
    type_hints = get_type_hints(func)
    param_descriptions = _parse_param_descriptions(func.__doc__)

    properties: dict[str, Property] = {}
    required: list[str] = []

    for name, param in sig.parameters.items():
        if name in ("self", "cls"):
            continue

        py_type = type_hints.get(name)
        json_type = TYPE_MAP.get(py_type, "string")
        description = param_descriptions.get(name, "")

        prop = Property(type=json_type, description=description)

        if param.default is not inspect.Parameter.empty:
            prop.default = param.default
        else:
            required.append(name)

        properties[name] = prop

    return Parameters(properties=properties, required=required)


class ToolValidationError(ValueError):
    """Raised when tool arguments fail validation.

    This exception is intended to be surfaced back to the LLM as a tool result so the
    model can correct the tool arguments and retry the call.

    :param tool_name: Tool name that failed validation.
    :param message: Human-readable validation error message.
    :param tool_arguments: Original tool arguments as provided by the model.
    """

    def __init__(self, *, tool_name: str, message: str, tool_arguments: object) -> None:
        super().__init__(message)
        self.tool_name = tool_name
        self.message = message
        self.tool_arguments = tool_arguments

    def __str__(self) -> str:
        return f"ToolValidationError(tool={self.tool_name}): {self.message}"


ToolArgumentsValidator = Callable[[dict[str, Any]], dict[str, Any]]


class Tool(NotNoneBaseModel):
    """Tool definition for OpenAI-compatible function calling.

    Wraps a callable with its JSON schema for use with LLM tool-calling APIs.
    The callable is stored internally and can be invoked via :meth:`invoke`.
    """

    model_config = ConfigDict(arbitrary_types_allowed=True)

    type: Literal["function"] = "function"
    function: Function
    callable: Callable[..., Any]
    validator: ToolArgumentsValidator | None = None

    @property
    def name(self) -> str:
        """Return the tool/function name."""
        return self.function.name

    def model_dump(self, **kwargs: Any) -> dict[str, Any]:
        """Dump model excluding internal callables.

        The OpenAI tool schema should only contain function metadata. Runtime
        callables like ``callable`` and ``validator`` are excluded.
        """
        kwargs.setdefault("exclude_none", True)
        data = super().model_dump(**kwargs)
        data.pop("callable", None)
        data.pop("validator", None)
        return data

    def validate(self, tool_arguments: object) -> dict[str, Any]:
        """Validate and normalize tool arguments using an optional validator.

        The validator may:
        - raise :class:`~omd.tools.data_models.ToolValidationError` if arguments
          are invalid
        - return (possibly normalized) tool arguments if valid

        :param tool_arguments: Parsed tool arguments (typically a dict).
        :returns: Validated/normalized tool arguments.
        :raises ToolValidationError: If arguments are invalid or have wrong type.
        """
        if self.validator is None:
            if isinstance(tool_arguments, dict):
                return tool_arguments
            raise ToolValidationError(
                tool_name=self.name,
                message=(
                    "Tool arguments must be an object/dict, "
                    f"got {type(tool_arguments).__name__}."
                ),
                tool_arguments=tool_arguments,
            )

        if not isinstance(tool_arguments, dict):
            raise ToolValidationError(
                tool_name=self.name,
                message=(
                    "Tool arguments must be an object/dict, "
                    f"got {type(tool_arguments).__name__}."
                ),
                tool_arguments=tool_arguments,
            )

        try:
            validated = self.validator(tool_arguments)
        except ToolValidationError:
            raise
        except Exception as exc:
            raise ToolValidationError(
                tool_name=self.name,
                message=f"Validator raised an unexpected error: {exc}",
                tool_arguments=tool_arguments,
            ) from exc

        if not isinstance(validated, dict):
            raise ToolValidationError(
                tool_name=self.name,
                message=(
                    "Validator must return a dict of tool arguments, "
                    f"got {type(validated).__name__}."
                ),
                tool_arguments=tool_arguments,
            )
        return validated

    def invoke(self, arguments: str | dict[str, Any]) -> str:
        """Invoke the underlying callable with the given arguments.

        :param arguments: Either a JSON string or a dict of keyword arguments.
        :returns: String result from the callable (JSON-serialized if not a string).
        :raises ValueError: If no callable is associated with this tool.
        :raises TypeError: If arguments cannot be parsed.
        """
        if self.callable is None:
            raise ValueError(f"Tool '{self.name}' has no callable")

        if isinstance(arguments, str):
            try:
                parsed_args = json.loads(arguments)
            except json.JSONDecodeError as e:
                raise TypeError(f"Failed to parse arguments JSON: {e}") from e
        else:
            parsed_args = arguments

        logger.debug("Invoking tool '%s' with args: %s", self.name, parsed_args)
        result = self.callable(**parsed_args)

        if isinstance(result, str):
            return result
        return json.dumps(result, ensure_ascii=False, default=str)

    @classmethod
    def from_callable(
        cls,
        func: Callable[..., Any],
        *,
        validator: ToolArgumentsValidator | None = None,
        description: str | None = None,
    ) -> Tool:
        """Create Tool from a callable.

        Extracts the function name, docstring, and parameter schema from the
        callable and stores a reference to invoke it later.

        :param func: Callable with type hints and Sphinx docstring.
        :param validator: Optional arguments validator/normalizer callable.
        :param description: Optional explicit function description for the tool
            schema. If omitted, function docstring is used.
        :returns: Tool instance with the callable attached.
        """
        func_doc = inspect.getdoc(func) or ""
        explicit_description = description.strip() if isinstance(description, str) else ""
        if explicit_description and func_doc and explicit_description != func_doc:
            combined_description = f"{explicit_description}\n\n{func_doc}"
        else:
            combined_description = explicit_description or func_doc

        function = Function(
            name=func.__name__,
            description=combined_description,
            parameters=_build_parameters(func),
        )
        return cls(function=function, callable=func, validator=validator)
