"""omd/tools/async_bridge.py.

Bridge synchronous tool callables into async callables.

This module provides :class:`AsyncToolBridge` which wraps blocking
tool functions (e.g., database queries, FAISS searches) to be
compatible with async agent loops without blocking the event loop.
"""

from __future__ import annotations

import asyncio
import functools
from collections.abc import Callable, Coroutine
from typing import Any, TypeVar

T = TypeVar("T")


class AsyncToolBridge:
    """Wraps synchronous callables into async ones using thread pool.

    Each wrapped callable runs in the default asyncio executor
    (typically a thread pool), allowing the event loop to continue
    processing other tasks during tool execution.

    Usage::

        bridge = AsyncToolBridge()
        async_fn = bridge.wrap("search", sync_search_function)
        result = await async_fn(query="example")
    """

    def __init__(self) -> None:
        """Initialize the bridge (no state required)."""
        pass

    def wrap(
        self,
        name: str,
        sync_fn: Callable[..., T],
    ) -> Callable[..., Coroutine[Any, Any, T]]:
        """Wrap a synchronous callable into an async one.

        :param name: Tool name (used for logging/debugging).
        :param sync_fn: Synchronous function to wrap.
        :returns: Async wrapper that accepts the same arguments.
        """

        async def async_wrapper(**kwargs: Any) -> T:
            loop = asyncio.get_event_loop()
            return await loop.run_in_executor(
                None,
                functools.partial(sync_fn, **kwargs),
            )

        # Preserve name for introspection
        async_wrapper.__name__ = f"async_{name}"
        async_wrapper.__doc__ = sync_fn.__doc__
        return async_wrapper

    def wrap_many(
        self,
        tools: dict[str, Callable[..., Any]],
    ) -> dict[str, Callable[..., Coroutine[Any, Any, Any]]]:
        """Wrap multiple synchronous tools at once.

        :param tools: Mapping from tool name to synchronous callable.
        :returns: Mapping from tool name to async wrapper.
        """
        return {name: self.wrap(name, fn) for name, fn in tools.items()}
