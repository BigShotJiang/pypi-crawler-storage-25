"""omd/utils/logging_utils.py.

Helpers for safe and compact logging of potentially large values.
"""

from __future__ import annotations

import json


def truncate_text(value: str, *, limit: int) -> str:
    """Truncate text to a bounded size for logs and tool errors.

    :param value: Original text value.
    :param limit: Maximum allowed length.
    :returns: Original text when short enough, otherwise a truncated version.
    """
    if len(value) <= limit:
        return value
    return value[:limit] + "...<truncated>"


def serialize_for_log(value: object, *, limit: int, sort_keys: bool = False) -> str:
    """Serialize a value for compact logging or error propagation.

    Tries JSON first so structured payloads remain machine-readable. Falls back
    to ``repr`` when the value cannot be serialized as JSON.

    :param value: Value to serialize.
    :param limit: Maximum allowed length of the returned string.
    :param sort_keys: Whether to sort keys when serializing dictionaries.
    :returns: Truncated serialized representation safe for logs.
    """
    try:
        serialized = json.dumps(
            value, ensure_ascii=False, default=str, sort_keys=sort_keys,
        )
    except TypeError:
        serialized = repr(value)
    return truncate_text(serialized, limit=limit)
