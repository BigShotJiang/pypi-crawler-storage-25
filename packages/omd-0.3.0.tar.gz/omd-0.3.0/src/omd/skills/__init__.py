"""omd/skills/__init__.py.

Public API for the OMD skill system.

Skills are markdown files (``SKILL.md``) describing how a particular role
uses available tools. :class:`SkillRegistry` discovers them on disk,
:class:`SkillRouter` picks the relevant ones via an LLM call, and
:func:`make_skill_tools` exposes them to an agent as on-demand tools.
"""

from omd.skills.data_models import Skill
from omd.skills.parser import SkillParseError, parse_skill_file
from omd.skills.registry import SkillRegistry
from omd.skills.router import SkillRouter
from omd.skills.tools import make_skill_tools

__all__ = [
    "Skill",
    "SkillParseError",
    "SkillRegistry",
    "SkillRouter",
    "make_skill_tools",
    "parse_skill_file",
]
