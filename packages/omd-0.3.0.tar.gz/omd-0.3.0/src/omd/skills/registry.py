"""omd/skills/registry.py.

Discovery and storage of :class:`~omd.skills.data_models.Skill` instances.
"""

from __future__ import annotations

import logging
import os
from collections.abc import Iterable
from pathlib import Path

from omd.skills.data_models import Skill
from omd.skills.parser import SkillParseError, parse_skill_file

LOGGER = logging.getLogger(__name__)

_BUILTIN_DIR = Path(__file__).resolve().parent / "builtin"
_ENV_VAR = "OMD_SKILLS_PATH"
_SKILL_FILE = "SKILL.md"


class SkillRegistry:
    """Catalog of discovered skills.

    The registry collects skills from three sources, in order:

    1. Built-in skills shipped with the package (``omd/skills/builtin``),
       unless ``include_builtin=False``.
    2. Directories listed in the ``OMD_SKILLS_PATH`` environment variable
       (``os.pathsep``-separated), unless ``read_env=False``.
    3. Directories passed via the ``dirs`` constructor argument.

    Each source directory is scanned one level deep: every immediate
    subdirectory containing a ``SKILL.md`` becomes a single skill. When the
    same skill name appears in multiple sources, later sources override
    earlier ones (so user-supplied skills win over built-ins).

    :param dirs: Additional directories to scan.
    :param include_builtin: Whether to load skills shipped with the package.
    :param read_env: Whether to honor the ``OMD_SKILLS_PATH`` environment variable.
    :param skills: Pre-built :class:`Skill` instances to register directly.
    """

    def __init__(
        self,
        dirs: Iterable[str | Path] | None = None,
        *,
        include_builtin: bool = True,
        read_env: bool = True,
        skills: Iterable[Skill] | None = None,
    ) -> None:
        self._skills: dict[str, Skill] = {}

        if include_builtin and _BUILTIN_DIR.is_dir():
            self._load_dir(_BUILTIN_DIR)

        if read_env:
            env_value = os.environ.get(_ENV_VAR, "").strip()
            if env_value:
                for raw in env_value.split(os.pathsep):
                    candidate = raw.strip()
                    if candidate:
                        self._load_dir(Path(candidate))

        for directory in dirs or ():
            self._load_dir(Path(directory))

        for skill in skills or ():
            self._skills[skill.name] = skill

    def _load_dir(self, directory: Path) -> None:
        """Scan ``directory`` for ``*/SKILL.md`` files and register them.

        :param directory: Directory to scan one level deep.
        """
        if not directory.is_dir():
            LOGGER.debug("Skill directory does not exist or is not a dir: %s", directory)
            return
        for skill_file in sorted(directory.glob(f"*/{_SKILL_FILE}")):
            try:
                parsed = parse_skill_file(skill_file)
            except (SkillParseError, OSError) as exc:
                LOGGER.warning("Skipping invalid skill at %s: %s", skill_file, exc)
                continue
            skill = Skill(
                name=parsed.name,
                description=parsed.description,
                body=parsed.body,
                source_path=skill_file,
                recommended_tools=parsed.recommended_tools,
                version=parsed.version,
            )
            if skill.name in self._skills:
                LOGGER.debug(
                    "Overriding existing skill %r from %s with %s",
                    skill.name,
                    self._skills[skill.name].source_path,
                    skill_file,
                )
            self._skills[skill.name] = skill

    def add(self, skill: Skill) -> None:
        """Register a pre-built skill (overrides any existing entry).

        :param skill: Skill instance to register.
        """
        self._skills[skill.name] = skill

    def names(self) -> list[str]:
        """Return all known skill names sorted alphabetically.

        :returns: Sorted list of skill names.
        """
        return sorted(self._skills)

    def get(self, name: str) -> Skill:
        """Return the skill registered under ``name``.

        :param name: Skill name.
        :returns: The :class:`Skill` instance.
        :raises KeyError: If no skill with this name is registered.
        """
        if name not in self._skills:
            raise KeyError(f"Unknown skill: {name!r}")
        return self._skills[name]

    def all(self) -> list[Skill]:
        """Return all registered skills sorted by name.

        :returns: Sorted list of :class:`Skill` instances.
        """
        return [self._skills[name] for name in self.names()]

    def catalog(self) -> list[dict[str, str]]:
        """Return ``{name, description}`` pairs for routing/listing.

        :returns: List of dictionaries suitable for JSON serialization.
        """
        return [
            {"name": skill.name, "description": skill.description}
            for skill in self.all()
        ]

    def __contains__(self, name: object) -> bool:
        return isinstance(name, str) and name in self._skills

    def __len__(self) -> int:
        return len(self._skills)

    def __iter__(self):
        return iter(self.all())
