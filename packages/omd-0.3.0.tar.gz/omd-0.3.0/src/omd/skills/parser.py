"""omd/skills/parser.py.

Parser for ``SKILL.md`` files with a minimal YAML-like front-matter.

The format is intentionally a small subset of YAML so the core package does
not need a YAML dependency:

- A document optionally starts with a ``---`` line, contains ``key: value``
  pairs (one per line), and ends with another ``---`` line.
- Values are strings by default; flow-style lists ``[a, b, c]`` are supported
  for keys that expect a list (currently ``recommended_tools``).
- Quotes around scalar values are stripped.

Anything after the closing ``---`` (or the entire file if no front-matter is
present) is treated as the Markdown body.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

_FRONT_MATTER_DELIM = "---"
_LIST_KEYS = frozenset({"recommended_tools"})


class SkillParseError(ValueError):
    """Raised when a ``SKILL.md`` file cannot be parsed."""


@dataclass
class ParsedSkill:
    """Container for raw fields parsed from a ``SKILL.md`` file.

    :param name: Value of the ``name`` front-matter field.
    :param description: Value of the ``description`` front-matter field.
    :param body: Markdown body following the front-matter.
    :param recommended_tools: Optional list of tool names.
    :param version: Optional version string.
    """

    name: str
    description: str
    body: str
    recommended_tools: list[str] = field(default_factory=list)
    version: str | None = None


def _split_front_matter(text: str) -> tuple[str, str]:
    """Split text into a front-matter block and a body.

    :param text: Full file contents.
    :returns: ``(front_matter, body)``. ``front_matter`` is empty when the
        file does not start with a ``---`` delimiter.
    """
    lines = text.splitlines()
    if not lines or lines[0].strip() != _FRONT_MATTER_DELIM:
        return "", text

    for index in range(1, len(lines)):
        if lines[index].strip() == _FRONT_MATTER_DELIM:
            front = "\n".join(lines[1:index])
            body = "\n".join(lines[index + 1 :])
            return front, body

    raise SkillParseError("Front-matter started with '---' but no closing '---' found")


def _strip_quotes(value: str) -> str:
    """Strip a single pair of matching surrounding quotes from a value."""
    if len(value) >= 2 and value[0] == value[-1] and value[0] in {'"', "'"}:
        return value[1:-1]
    return value


def _parse_flow_list(value: str) -> list[str]:
    """Parse a YAML flow-style list ``[a, b, "c d"]`` into a list of strings."""
    inner = value.strip()
    if not (inner.startswith("[") and inner.endswith("]")):
        raise SkillParseError(f"Expected flow list, got: {value!r}")
    inner = inner[1:-1].strip()
    if not inner:
        return []
    parts = [part.strip() for part in inner.split(",")]
    return [_strip_quotes(part) for part in parts if part]


def _parse_front_matter(front: str) -> dict[str, object]:
    """Parse the front-matter block into a dictionary.

    :param front: Raw front-matter text (without delimiters).
    :returns: Dictionary of fields. Lists are returned for keys in
        :data:`_LIST_KEYS`; everything else is a string.
    :raises SkillParseError: If a line cannot be parsed.
    """
    fields: dict[str, object] = {}
    for raw_line in front.splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue
        if ":" not in line:
            raise SkillParseError(f"Invalid front-matter line (no ':'): {raw_line!r}")
        key, _, value = line.partition(":")
        key = key.strip()
        value = value.strip()
        if key in _LIST_KEYS:
            fields[key] = _parse_flow_list(value)
        else:
            fields[key] = _strip_quotes(value)
    return fields


def parse_skill_file(path: Path) -> ParsedSkill:
    """Parse a ``SKILL.md`` file from disk.

    :param path: Path to the ``SKILL.md`` file.
    :returns: A :class:`ParsedSkill` with normalized fields.
    :raises SkillParseError: If the file is malformed or required fields
        (``name``, ``description``) are missing.
    :raises FileNotFoundError: If the path does not exist.
    """
    text = path.read_text(encoding="utf-8")
    front, body = _split_front_matter(text)
    fields = _parse_front_matter(front) if front else {}

    name = fields.get("name")
    description = fields.get("description")
    if not isinstance(name, str) or not name.strip():
        raise SkillParseError(f"{path}: missing required front-matter field 'name'")
    if not isinstance(description, str) or not description.strip():
        raise SkillParseError(f"{path}: missing required front-matter field 'description'")

    recommended_tools_raw = fields.get("recommended_tools", [])
    if not isinstance(recommended_tools_raw, list):
        raise SkillParseError(f"{path}: 'recommended_tools' must be a list")
    recommended_tools = [str(item) for item in recommended_tools_raw]

    version_raw = fields.get("version")
    version = str(version_raw) if isinstance(version_raw, str) and version_raw else None

    return ParsedSkill(
        name=name.strip(),
        description=description.strip(),
        body=body.strip("\n"),
        recommended_tools=recommended_tools,
        version=version,
    )
