"""omd/skills/tools.py.

Tool factory exposing a :class:`SkillRegistry` to the agent.
"""

from __future__ import annotations

import json

from omd.skills.registry import SkillRegistry
from omd.tools.data_models import Tool


def make_skill_tools(registry: SkillRegistry) -> list[Tool]:
    """Build ``list_skills`` and ``load_skill`` tools backed by ``registry``.

    The agent can use these to discover and pull skill instructions on demand
    when the auto-router did not pre-select them.

    :param registry: Registry to expose. Tools capture it by reference, so
        skills added to the registry later are immediately visible.
    :returns: List of :class:`~omd.tools.data_models.Tool` instances ready
        to be passed to :class:`~omd.agents.base.BaseAgent`.
    """

    def list_skills() -> str:
        """List available skills with their short descriptions.

        :returns: JSON array of objects with ``name`` and ``description``
            fields. Use ``load_skill`` to fetch the full instructions.
        """
        return json.dumps(registry.catalog(), ensure_ascii=False)

    def load_skill(name: str) -> str:
        """Load the full instructions of a skill by its name.

        :param name: Skill name as listed by ``list_skills``.
        :returns: Markdown body of the skill, or a JSON error payload when
            the skill is unknown.
        """
        try:
            skill = registry.get(name)
        except KeyError:
            return json.dumps(
                {
                    "error": "unknown_skill",
                    "name": name,
                    "available": registry.names(),
                },
                ensure_ascii=False,
            )
        return skill.render_for_prompt()

    return [
        Tool.from_callable(list_skills),
        Tool.from_callable(load_skill),
    ]
