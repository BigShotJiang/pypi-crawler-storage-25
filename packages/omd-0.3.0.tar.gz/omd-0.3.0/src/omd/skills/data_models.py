"""omd/skills/data_models.py.

Pydantic data models for skill definitions.
"""

from __future__ import annotations

from pathlib import Path

from pydantic import BaseModel, ConfigDict, Field


class Skill(BaseModel):
    """A reusable instruction set describing how a role uses available tools.

    A skill is loaded from a directory containing ``SKILL.md`` with a YAML-like
    front-matter (``name``, ``description``, optional ``recommended_tools``,
    optional ``version``) and a free-form Markdown body.

    :param name: Unique skill name.
    :param description: Short, one-paragraph description used by the router
        and by humans browsing the catalog.
    :param body: Markdown body of ``SKILL.md`` (without front-matter).
    :param source_path: Filesystem path of the source ``SKILL.md`` file.
    :param recommended_tools: Optional list of tool names the skill expects
        to be available.
    :param version: Optional semver-like version string.
    """

    model_config = ConfigDict(frozen=True)

    name: str
    description: str
    body: str
    source_path: Path | None = None
    recommended_tools: list[str] = Field(default_factory=list)
    version: str | None = None

    def render_for_prompt(self) -> str:
        """Render the skill as an XML-like block for the system prompt.

        :returns: Skill content wrapped into ``<skill name="..."> ... </skill>``.
        """
        return f'<skill name="{self.name}">\n{self.body.strip()}\n</skill>'
