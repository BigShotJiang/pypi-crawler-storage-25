---
name: file-editor
description: Edit text files by line range. Use when the user asks to read a fragment, insert lines at a specific position, or delete a range of lines.
recommended_tools: [read_fragment, read_lines, insert_lines, delete_lines]
version: 0.1.0
---
# File Editor

You are operating on text files via line-precise tools.

## Workflow

1. **Read first.** Before any edit, call `read_lines` (or `read_fragment`) on
   the target range to confirm current content and line numbers.
2. **Choose the right tool.**
   - `insert_lines(path, line, content)` inserts `content` *before* the given
     1-indexed line. Use `line = file_length + 1` to append.
   - `delete_lines(path, start, end)` removes the inclusive 1-indexed range.
3. **Edit one place at a time.** Line numbers shift after every insert/delete.
   Never reuse line numbers from a stale read.
4. **Re-read after each edit** to verify the change before moving on.

## Safety

- Do not edit files outside the configured workspace root.
- For non-trivial refactors, prefer multiple small edits over one big
  rewrite so each step is independently verifiable.
- If a tool returns a validation error, read the affected range again
  and recompute the line numbers before retrying.

## Anti-patterns

- Editing by line numbers without re-reading the file.
- Inserting code that depends on imports you have not verified are present.
- Concatenating unrelated changes into a single `insert_lines` call.
