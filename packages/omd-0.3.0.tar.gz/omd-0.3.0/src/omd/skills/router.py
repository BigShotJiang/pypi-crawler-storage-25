"""omd/skills/router.py.

LLM-driven router that picks relevant skills for a user query.
"""

from __future__ import annotations

import json
import logging
import re
from typing import Any

from omd.clients.base import BaseClient
from omd.skills.data_models import Skill
from omd.skills.registry import SkillRegistry

LOGGER = logging.getLogger(__name__)

_DEFAULT_SYSTEM_PROMPT = (
    "You are a skill router. You receive a list of available skills "
    "(each with a name and a short description) and a user request. "
    "Your job is to pick the skills that would meaningfully help an agent "
    "answer this request.\n\n"
    "Respond with a single JSON object of the form "
    '{"skills": ["name1", "name2"]}. '
    "Use an empty list when no skill is clearly relevant. "
    "Never invent skill names that are not in the catalog."
)

_JSON_BLOCK_RE = re.compile(r"\{.*\}", re.DOTALL)


class SkillRouter:
    """Pick relevant skills for a conversation via a single LLM call.

    :param client: LLM client used to perform the routing call.
    :param max_skills: Maximum number of skills to keep from the LLM answer.
    :param system_prompt: Optional override for the routing system prompt.
    :param timeout_s: Optional request timeout for the routing call.
    """

    def __init__(
        self,
        client: BaseClient,
        *,
        max_skills: int = 3,
        system_prompt: str | None = None,
        timeout_s: float | None = None,
    ) -> None:
        if max_skills < 0:
            raise ValueError("max_skills must be non-negative")
        self.client = client
        self.max_skills = max_skills
        self.system_prompt = system_prompt or _DEFAULT_SYSTEM_PROMPT
        self.timeout_s = timeout_s

    def select(
        self,
        registry: SkillRegistry,
        messages: list[dict[str, Any]],
    ) -> list[Skill]:
        """Select skills relevant to the conversation.

        :param registry: Registry to choose from.
        :param messages: Current conversation messages (the latest user turn
            is used as the routing query; system messages are ignored).
        :returns: Ordered list of selected :class:`Skill` instances. May be
            empty if no skill is relevant or the routing call fails.
        """
        if len(registry) == 0 or self.max_skills == 0:
            return []

        catalog = registry.catalog()
        query = self._extract_query(messages)
        if not query:
            return []

        routing_messages = [
            {"role": "system", "content": self.system_prompt},
            {
                "role": "user",
                "content": (
                    "Available skills:\n"
                    f"{json.dumps(catalog, ensure_ascii=False)}\n\n"
                    "User request:\n"
                    f"{query}"
                ),
            },
        ]

        try:
            response = self.client.call_model(
                messages=routing_messages,
                tools=None,
                tool_choice=None,
                timeout_s=self.timeout_s,
            )
        except Exception as exc:
            LOGGER.warning("Skill router LLM call failed: %s", exc)
            return []

        names = self._extract_skill_names(response)
        selected: list[Skill] = []
        for name in names:
            if name in registry and name not in {s.name for s in selected}:
                selected.append(registry.get(name))
            if len(selected) >= self.max_skills:
                break
        LOGGER.debug("SkillRouter selected: %s", [s.name for s in selected])
        return selected

    @staticmethod
    def _extract_query(messages: list[dict[str, Any]]) -> str:
        """Return the most recent user message content as a plain string."""
        for message in reversed(messages):
            if message.get("role") != "user":
                continue
            content = message.get("content")
            if isinstance(content, str):
                return content.strip()
            if isinstance(content, list):
                parts: list[str] = []
                for item in content:
                    if isinstance(item, dict) and item.get("type") == "text":
                        text = item.get("text")
                        if isinstance(text, str):
                            parts.append(text)
                if parts:
                    return "\n".join(parts).strip()
        return ""

    @staticmethod
    def _extract_skill_names(response: object) -> list[str]:
        """Pull the list of skill names out of an LLM chat completion payload."""
        try:
            content = response["choices"][0]["message"]["content"]  # type: ignore[index]
        except (KeyError, TypeError, IndexError):
            return []
        if not isinstance(content, str):
            return []

        text = content.strip()
        match = _JSON_BLOCK_RE.search(text)
        if match is None:
            return []
        try:
            payload = json.loads(match.group(0))
        except json.JSONDecodeError:
            return []

        if not isinstance(payload, dict):
            return []
        raw = payload.get("skills")
        if not isinstance(raw, list):
            return []
        return [str(item).strip() for item in raw if isinstance(item, str) and item.strip()]
