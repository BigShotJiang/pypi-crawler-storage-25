"""omd/agents/terminating.py.

Agent that exits the loop as soon as a designated "submit" tool fires.

:class:`omd.agents.BaseAgent` terminates only when the model returns a
plain message without ``tool_calls``.  Workflows that always end with a
single, structured tool call (e.g. ``submit_classification``,
``return_answer``) need a different stop condition.

Usage:

* Bind the submit tool's callable to raise :class:`SubmittedSignal`
  with the parsed arguments.
* Run :meth:`TerminatingAgent.run` and read ``agent.submission`` to
  obtain the captured arguments.  When the agent exits without ever
  calling submit, ``submission`` stays ``None``.
"""

from __future__ import annotations

import logging
from typing import Any

from omd.agents.base import BaseAgent

logger = logging.getLogger(__name__)


class SubmittedSignal(Exception):
    """Raised by the submit tool callable to stop the agent loop early.

    :param arguments: Parsed tool-call arguments to surface to the
        caller via :attr:`TerminatingAgent.submission`.
    """

    def __init__(self, arguments: dict[str, Any]) -> None:
        super().__init__("Agent submitted final result.")
        self.arguments = arguments


class TerminatingAgent(BaseAgent):
    """:class:`BaseAgent` that stops on a designated submit tool.

    The submit tool's callable must raise :class:`SubmittedSignal` with
    the parsed arguments.  After :meth:`run` returns, :attr:`submission`
    holds those arguments (or ``None`` if the agent stopped without
    submitting — e.g. it ran out of attempts or the model produced a
    plain message).
    """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)
        self.submission: dict[str, Any] | None = None

    def run(
        self,
        messages: list[dict[str, Any]],
        attempts_limit: int = 10,
        init_messages_count: int | None = None,
    ) -> list[dict[str, Any]]:
        """Run the loop, catching :class:`SubmittedSignal` for early exit.

        :param messages: Conversation messages (modified in-place).
        :param attempts_limit: Maximum number of LLM calls.
        :param init_messages_count: Internal recursion bookkeeping —
            do not pass on the first call.
        :returns: Messages produced during this run.
        """
        start = (
            init_messages_count
            if init_messages_count is not None
            else len(messages)
        )
        try:
            return super().run(messages, attempts_limit, init_messages_count)
        except SubmittedSignal as sig:
            self.submission = sig.arguments
            logger.info("Agent submitted final result.")
            return messages[start:]
