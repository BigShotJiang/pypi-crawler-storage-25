"""omd/agents/streaming.py.

Streaming agent implementations with fine-grained event emission.

This module provides :class:`AsyncStreamingAgent` and :class:`StreamingAgent`
which run iterative tool-calling loops and yield events incrementally,
allowing real-time streaming to clients even when the LLM provider does
not natively support streaming.
"""

from __future__ import annotations

import json
import logging
from abc import ABC, abstractmethod
from collections.abc import AsyncIterator, Callable, Coroutine, Iterator
from dataclasses import dataclass, field
from typing import Any

from omd.streaming.events import (
    ContentDeltaEvent,
    DoneEvent,
    ErrorEvent,
    StreamEvent,
    ToolCallStartEvent,
    ToolResultEvent,
)

logger = logging.getLogger(__name__)

# Type alias for async tool callable
AsyncToolCallable = Callable[..., Coroutine[Any, Any, Any]]
SyncToolCallable = Callable[..., Any]


@dataclass
class StreamingConfig:
    """Configuration for streaming agents.

    :param max_iterations: Safety cap on tool-calling iterations.
    :param finalize_prompt: Prompt to use when max_iterations reached.
        Set to empty string to disable finalization.
    """

    max_iterations: int = 10
    finalize_prompt: str = (
        "You have used your entire tool budget. Stop searching now. "
        "Produce your best final answer for the user as plain text. "
        "If you have a domain-specific submission tool (e.g. "
        "submit_classification), call it exactly once with your best "
        "guess and a clear explanation of any remaining uncertainty. "
        "Do not call any other tools."
    )


class BaseStreamingAgent(ABC):
    """Abstract base for streaming agents.

    Provides common logic for streaming agent loops while allowing
    sync and async implementations to define their own execution model.
    """

    def __init__(
        self,
        tools: dict[str, AsyncToolCallable] | dict[str, SyncToolCallable],
        tool_schemas: list[dict[str, Any]],
        system_prompt: str,
        model: str = "gpt-4o",
        config: StreamingConfig | None = None,
    ):
        self.tools = tools
        self.tool_schemas = tool_schemas
        self.system_prompt = system_prompt
        self.model = model
        self.config = config or StreamingConfig()
        self._iteration: int = 0

    def _prepare_messages(
        self,
        messages: list[dict[str, Any]],
    ) -> list[dict[str, Any]]:
        """Prepend system prompt if not already present."""
        if not any(m.get("role") == "system" for m in messages):
            messages.insert(0, {"role": "system", "content": self.system_prompt})
        return messages

    def _accumulate_tool_calls(
        self,
        tool_calls_acc: dict[int, dict[str, Any]],
        delta_tool_calls: list[Any],
    ) -> None:
        """Accumulate tool call fragments from streaming chunks."""
        for tc_delta in delta_tool_calls:
            idx = getattr(tc_delta, "index", 0) or 0
            entry = tool_calls_acc.setdefault(
                idx, {"id": "", "name": "", "arguments": ""},
            )
            if tc_delta.id:
                entry["id"] = tc_delta.id
            fn = tc_delta.function
            if fn is not None:
                if fn.name:
                    entry["name"] = fn.name
                if fn.arguments:
                    entry["arguments"] += fn.arguments

    def _build_tool_call_messages(
        self,
        content_buffer: str,
        tool_calls_acc: dict[int, dict[str, Any]],
    ) -> dict[str, Any]:
        """Build the assistant message with tool calls."""
        ordered_calls = [
            tool_calls_acc[k] for k in sorted(tool_calls_acc.keys())
        ]
        return {
            "role": "assistant",
            "content": content_buffer or None,
            "tool_calls": [
                {
                    "id": call["id"],
                    "type": "function",
                    "function": {
                        "name": call["name"],
                        "arguments": call["arguments"],
                    },
                }
                for call in ordered_calls
            ],
        }

    async def _execute_tool_async(
        self,
        tool_call: dict[str, Any],
    ) -> dict[str, Any]:
        """Execute a single tool call (async version)."""
        name = tool_call["name"]
        arguments_str = tool_call["arguments"]

        tool_fn = self.tools.get(name)
        if not tool_fn:
            return {
                "result": json.dumps({"error": f"Unknown tool: {name}"}),
                "error": True,
            }

        try:
            args = json.loads(arguments_str) if arguments_str else {}
            result = await tool_fn(**args)
            if not isinstance(result, str):
                result = json.dumps(result, ensure_ascii=False)
            return {"result": result, "error": False}
        except json.JSONDecodeError as exc:
            logger.error("Invalid JSON arguments for tool %s: %s", name, exc)
            return {
                "result": json.dumps({"error": f"Invalid JSON arguments: {exc}"}),
                "error": True,
            }
        except Exception as exc:
            logger.exception("Tool %s execution failed", name)
            return {
                "result": json.dumps({"error": f"Tool execution failed: {exc}"}),
                "error": True,
            }

    def _execute_tool_sync(
        self,
        tool_call: dict[str, Any],
    ) -> dict[str, Any]:
        """Execute a single tool call (sync version)."""
        name = tool_call["name"]
        arguments_str = tool_call["arguments"]

        tool_fn = self.tools.get(name)
        if not tool_fn:
            return {
                "result": json.dumps({"error": f"Unknown tool: {name}"}),
                "error": True,
            }

        try:
            args = json.loads(arguments_str) if arguments_str else {}
            result = tool_fn(**args)
            if not isinstance(result, str):
                result = json.dumps(result, ensure_ascii=False)
            return {"result": result, "error": False}
        except json.JSONDecodeError as exc:
            logger.error("Invalid JSON arguments for tool %s: %s", name, exc)
            return {
                "result": json.dumps({"error": f"Invalid JSON arguments: {exc}"}),
                "error": True,
            }
        except Exception as exc:
            logger.exception("Tool %s execution failed", name)
            return {
                "result": json.dumps({"error": f"Tool execution failed: {exc}"}),
                "error": True,
            }

    @abstractmethod
    def _call_llm(
        self,
        messages: list[dict[str, Any]],
    ) -> Any:
        """Call the LLM - to be implemented by subclasses."""
        raise NotImplementedError

    @abstractmethod
    def _process_stream_chunk(
        self,
        chunk: Any,
        tool_calls_acc: dict[int, dict[str, Any]],
        content_buffer: str,
        reasoning_buffer: str,
    ) -> tuple[str, str, str | None]:
        """Process a single stream chunk - to be implemented by subclasses."""
        raise NotImplementedError


@dataclass
class AsyncStreamingAgent:
    """Async agent that emits streaming events during tool-calling loops.

    Unlike :class:`omd.agents.BaseAgent` which buffers and returns
    final results, this agent yields events incrementally allowing
    real-time streaming to clients.

    :param client: AsyncOpenAI client for LLM calls.
    :param tools: Mapping from tool name to async callable.
    :param tool_schemas: OpenAI function-calling tool definitions.
    :param system_prompt: System prompt for the agent.
    :param model: Model identifier for chat completions.
    :param max_iterations: Safety cap on tool-calling iterations.
    :param finalize_prompt: Prompt to use when max_iterations reached.
    """

    client: Any
    tools: dict[str, AsyncToolCallable]
    tool_schemas: list[dict[str, Any]]
    system_prompt: str
    model: str = "gpt-4o"
    max_iterations: int = 10
    finalize_prompt: str = (
        "You have used your entire tool budget. Stop searching now. "
        "Produce your best final answer for the user as plain text. "
        "If you have a domain-specific submission tool (e.g. "
        "submit_classification), call it exactly once with your best "
        "guess and a clear explanation of any remaining uncertainty. "
        "Do not call any other tools."
    )

    # Internal state
    _iteration: int = field(default=0, init=False)

    async def run_stream(
        self,
        messages: list[dict[str, Any]],
    ) -> AsyncIterator[StreamEvent]:
        """Run the agent loop, yielding streaming events.

        The loop continues until:
        - LLM returns finish_reason="stop" (content response)
        - max_iterations reached
        - An error occurs

        :param messages: Initial conversation messages (modified in-place).
        :yields: StreamEvent objects for each step (tokens, tool calls, results).
        """
        # Prepend system prompt if not already present
        if not any(m.get("role") == "system" for m in messages):
            messages.insert(0, {"role": "system", "content": self.system_prompt})

        for iteration in range(self.max_iterations):
            self._iteration = iteration
            logger.debug("Agent iteration %d", iteration + 1)

            try:
                # Per-iteration streaming state
                tool_calls_acc: dict[int, dict[str, Any]] = {}
                content_buffer = ""
                reasoning_buffer = ""
                stream_finish_reason: str | None = None

                stream = await self._call_llm_stream(messages)

                async for chunk in stream:
                    content_buffer, reasoning_buffer, finish = self._process_chunk(
                        chunk, tool_calls_acc, content_buffer, reasoning_buffer
                    )
                    if finish:
                        stream_finish_reason = finish

                    # Yield content deltas immediately for real-time streaming
                    delta = self._extract_content_delta(chunk)
                    if delta:
                        yield ContentDeltaEvent(
                            text=delta["content"],
                            reasoning=delta.get("reasoning", False),
                        )

                # Stream of this iteration finished — act on the result
                if stream_finish_reason == "tool_calls" and tool_calls_acc:
                    ordered_calls = [
                        tool_calls_acc[k] for k in sorted(tool_calls_acc.keys())
                    ]

                    messages.append({
                        "role": "assistant",
                        "content": content_buffer or None,
                        "tool_calls": [
                            {
                                "id": call["id"],
                                "type": "function",
                                "function": {
                                    "name": call["name"],
                                    "arguments": call["arguments"],
                                },
                            }
                            for call in ordered_calls
                        ],
                    })

                    for call in ordered_calls:
                        yield ToolCallStartEvent(
                            tool_id=call["id"],
                            name=call["name"],
                            arguments=call["arguments"],
                        )

                        result = await self._execute_tool(call)

                        yield ToolResultEvent(
                            tool_id=call["id"],
                            result=result["result"],
                            error=result["error"],
                        )

                        messages.append({
                            "role": "tool",
                            "tool_call_id": call["id"],
                            "content": result["result"],
                        })

                    continue  # next agent iteration

                if stream_finish_reason == "stop":
                    yield DoneEvent(finish_reason="stop")
                    return

                if stream_finish_reason in ("length", "content_filter"):
                    yield DoneEvent(finish_reason=stream_finish_reason)
                    return

                # No finish reason and no tool calls — protect against tight loop
                if not stream_finish_reason and not tool_calls_acc:
                    logger.warning(
                        "Stream ended without finish_reason on iteration %d", iteration + 1,
                    )
                    yield DoneEvent(finish_reason="stop")
                    return

            except Exception as exc:
                logger.exception("Error in agent iteration %d", iteration + 1)
                yield ErrorEvent(
                    message=f"Agent error: {exc}",
                    code="agent_error",
                )
                yield DoneEvent(finish_reason="error")
                return

        # Max iterations reached without completion: try to give the
        # user a clean final answer instead of bailing with an error.
        logger.warning(
            "Agent reached max_iterations (%d); running finalization step",
            self.max_iterations,
        )

        if not self.finalize_prompt:
            yield ErrorEvent(
                message=(
                    f"Maximum iterations ({self.max_iterations}) reached "
                    "without completion"
                ),
                code="max_iterations",
            )
            yield DoneEvent(finish_reason="length")
            return

        async for event in self._run_finalization(messages):
            yield event

    async def _call_llm_stream(self, messages: list[dict[str, Any]]) -> Any:
        """Call LLM with streaming enabled. Must be implemented by subclasses."""
        raise NotImplementedError("Subclasses must implement _call_llm_stream")

    def _process_chunk(
        self,
        chunk: Any,
        tool_calls_acc: dict[int, dict[str, Any]],
        content_buffer: str,
        reasoning_buffer: str,
    ) -> tuple[str, str, str | None]:
        """Process a single stream chunk and update buffers."""
        if not chunk.choices:
            return content_buffer, reasoning_buffer, None

        choice = chunk.choices[0]
        delta = choice.delta
        finish_reason = choice.finish_reason

        if not delta:
            return content_buffer, reasoning_buffer, finish_reason

        if delta.content:
            content_buffer += delta.content

        reasoning_chunk = getattr(delta, "reasoning_content", None)
        if reasoning_chunk:
            reasoning_buffer += reasoning_chunk

        if delta.tool_calls:
            for tc_delta in delta.tool_calls:
                idx = getattr(tc_delta, "index", 0) or 0
                entry = tool_calls_acc.setdefault(
                    idx, {"id": "", "name": "", "arguments": ""},
                )
                if tc_delta.id:
                    entry["id"] = tc_delta.id
                fn = tc_delta.function
                if fn is not None:
                    if fn.name:
                        entry["name"] = fn.name
                    if fn.arguments:
                        entry["arguments"] += fn.arguments

        return content_buffer, reasoning_buffer, finish_reason

    def _extract_content_delta(self, chunk: Any) -> dict[str, Any] | None:
        """Extract content delta from chunk for immediate yielding."""
        if not chunk.choices:
            return None
        delta = chunk.choices[0].delta
        if not delta:
            return None

        if delta.content:
            return {"content": delta.content, "reasoning": False}

        reasoning = getattr(delta, "reasoning_content", None)
        if reasoning:
            return {"content": reasoning, "reasoning": True}

        return None

    async def _execute_tool(
        self,
        tool_call: dict[str, Any],
    ) -> dict[str, Any]:
        """Execute a single tool call."""
        name = tool_call["name"]
        arguments_str = tool_call["arguments"]

        tool_fn = self.tools.get(name)
        if not tool_fn:
            return {
                "result": json.dumps({"error": f"Unknown tool: {name}"}),
                "error": True,
            }

        try:
            args = json.loads(arguments_str) if arguments_str else {}
            result = await tool_fn(**args)
            if not isinstance(result, str):
                result = json.dumps(result, ensure_ascii=False)
            return {"result": result, "error": False}
        except json.JSONDecodeError as exc:
            logger.error("Invalid JSON arguments for tool %s: %s", name, exc)
            return {
                "result": json.dumps({"error": f"Invalid JSON arguments: {exc}"}),
                "error": True,
            }
        except Exception as exc:
            logger.exception("Tool %s execution failed", name)
            return {
                "result": json.dumps({"error": f"Tool execution failed: {exc}"}),
                "error": True,
            }

    async def _run_finalization(
        self,
        messages: list[dict[str, Any]],
    ) -> AsyncIterator[StreamEvent]:
        """Run a single closing turn after the iteration cap is hit."""
        messages.append({"role": "system", "content": self.finalize_prompt})

        try:
            stream = await self._call_llm_stream(messages)

            tool_calls_acc: dict[int, dict[str, Any]] = {}
            content_buffer = ""

            async for chunk in stream:
                if not chunk.choices:
                    continue
                choice = chunk.choices[0]
                delta = choice.delta
                if not delta:
                    continue

                if delta.content:
                    content_buffer += delta.content
                    yield ContentDeltaEvent(text=delta.content, reasoning=False)

                if delta.tool_calls:
                    for tc_delta in delta.tool_calls:
                        idx = getattr(tc_delta, "index", 0) or 0
                        entry = tool_calls_acc.setdefault(
                            idx, {"id": "", "name": "", "arguments": ""},
                        )
                        if tc_delta.id:
                            entry["id"] = tc_delta.id
                        fn = tc_delta.function
                        if fn is not None:
                            if fn.name:
                                entry["name"] = fn.name
                            if fn.arguments:
                                entry["arguments"] += fn.arguments

            if tool_calls_acc:
                ordered_calls = [
                    tool_calls_acc[k] for k in sorted(tool_calls_acc.keys())
                ]
                for call in ordered_calls:
                    yield ToolCallStartEvent(
                        tool_id=call["id"],
                        name=call["name"],
                        arguments=call["arguments"],
                    )
                    result = await self._execute_tool(call)
                    yield ToolResultEvent(
                        tool_id=call["id"],
                        result=result["result"],
                        error=result["error"],
                    )

            if not content_buffer and not tool_calls_acc:
                yield ContentDeltaEvent(
                    text=(
                        "I've reached my tool budget without producing a "
                        "definitive answer. Please refine the request or "
                        "increase max_iterations and try again."
                    ),
                    reasoning=False,
                )

            yield DoneEvent(finish_reason="stop")
        except Exception as exc:
            logger.exception("Finalization step failed")
            yield ErrorEvent(
                message=f"Finalization failed: {exc}",
                code="finalize_error",
            )
            yield DoneEvent(finish_reason="error")


@dataclass
class StreamingAgent:
    """Synchronous streaming agent that yields events during tool-calling loops.

    This is the synchronous counterpart to :class:`AsyncStreamingAgent`.
    It uses the same event model but works with synchronous clients and tools.

    :param client: Synchronous OpenAI client for LLM calls.
    :param tools: Mapping from tool name to synchronous callable.
    :param tool_schemas: OpenAI function-calling tool definitions.
    :param system_prompt: System prompt for the agent.
    :param model: Model identifier for chat completions.
    :param max_iterations: Safety cap on tool-calling iterations.
    :param finalize_prompt: Prompt to use when max_iterations reached.
    """

    client: Any
    tools: dict[str, SyncToolCallable]
    tool_schemas: list[dict[str, Any]]
    system_prompt: str
    model: str = "gpt-4o"
    max_iterations: int = 10
    finalize_prompt: str = (
        "You have used your entire tool budget. Stop searching now. "
        "Produce your best final answer for the user as plain text. "
        "If you have a domain-specific submission tool (e.g. "
        "submit_classification), call it exactly once with your best "
        "guess and a clear explanation of any remaining uncertainty. "
        "Do not call any other tools."
    )

    # Internal state
    _iteration: int = field(default=0, init=False)

    def run_stream(
        self,
        messages: list[dict[str, Any]],
    ) -> Iterator[StreamEvent]:
        """Run the agent loop, yielding streaming events.

        :param messages: Initial conversation messages (modified in-place).
        :yields: StreamEvent objects for each step (tokens, tool calls, results).
        """
        # Prepend system prompt if not already present
        if not any(m.get("role") == "system" for m in messages):
            messages.insert(0, {"role": "system", "content": self.system_prompt})

        for iteration in range(self.max_iterations):
            self._iteration = iteration
            logger.debug("Agent iteration %d", iteration + 1)

            try:
                # Per-iteration streaming state
                tool_calls_acc: dict[int, dict[str, Any]] = {}
                content_buffer = ""
                reasoning_buffer = ""
                stream_finish_reason: str | None = None

                stream = self._call_llm_stream(messages)

                for chunk in stream:
                    content_buffer, reasoning_buffer, finish = self._process_chunk(
                        chunk, tool_calls_acc, content_buffer, reasoning_buffer
                    )
                    if finish:
                        stream_finish_reason = finish

                    # Yield content deltas immediately for real-time streaming
                    delta = self._extract_content_delta(chunk)
                    if delta:
                        yield ContentDeltaEvent(
                            text=delta["content"],
                            reasoning=delta.get("reasoning", False),
                        )

                # Stream of this iteration finished — act on the result
                if stream_finish_reason == "tool_calls" and tool_calls_acc:
                    ordered_calls = [
                        tool_calls_acc[k] for k in sorted(tool_calls_acc.keys())
                    ]

                    messages.append({
                        "role": "assistant",
                        "content": content_buffer or None,
                        "tool_calls": [
                            {
                                "id": call["id"],
                                "type": "function",
                                "function": {
                                    "name": call["name"],
                                    "arguments": call["arguments"],
                                },
                            }
                            for call in ordered_calls
                        ],
                    })

                    for call in ordered_calls:
                        yield ToolCallStartEvent(
                            tool_id=call["id"],
                            name=call["name"],
                            arguments=call["arguments"],
                        )

                        result = self._execute_tool(call)

                        yield ToolResultEvent(
                            tool_id=call["id"],
                            result=result["result"],
                            error=result["error"],
                        )

                        messages.append({
                            "role": "tool",
                            "tool_call_id": call["id"],
                            "content": result["result"],
                        })

                    continue  # next agent iteration

                if stream_finish_reason == "stop":
                    yield DoneEvent(finish_reason="stop")
                    return

                if stream_finish_reason in ("length", "content_filter"):
                    yield DoneEvent(finish_reason=stream_finish_reason)
                    return

                # No finish reason and no tool calls — protect against tight loop
                if not stream_finish_reason and not tool_calls_acc:
                    logger.warning(
                        "Stream ended without finish_reason on iteration %d", iteration + 1,
                    )
                    yield DoneEvent(finish_reason="stop")
                    return

            except Exception as exc:
                logger.exception("Error in agent iteration %d", iteration + 1)
                yield ErrorEvent(
                    message=f"Agent error: {exc}",
                    code="agent_error",
                )
                yield DoneEvent(finish_reason="error")
                return

        # Max iterations reached without completion
        logger.warning(
            "Agent reached max_iterations (%d); running finalization step",
            self.max_iterations,
        )

        if not self.finalize_prompt:
            yield ErrorEvent(
                message=(
                    f"Maximum iterations ({self.max_iterations}) reached "
                    "without completion"
                ),
                code="max_iterations",
            )
            yield DoneEvent(finish_reason="length")
            return

        yield from self._run_finalization(messages)

    def _call_llm_stream(self, messages: list[dict[str, Any]]) -> Iterator[Any]:
        """Call LLM with streaming enabled. Must be implemented by subclasses."""
        raise NotImplementedError("Subclasses must implement _call_llm_stream")

    def _process_chunk(
        self,
        chunk: Any,
        tool_calls_acc: dict[int, dict[str, Any]],
        content_buffer: str,
        reasoning_buffer: str,
    ) -> tuple[str, str, str | None]:
        """Process a single stream chunk and update buffers."""
        if not chunk.choices:
            return content_buffer, reasoning_buffer, None

        choice = chunk.choices[0]
        delta = choice.delta
        finish_reason = choice.finish_reason

        if not delta:
            return content_buffer, reasoning_buffer, finish_reason

        if delta.content:
            content_buffer += delta.content

        reasoning_chunk = getattr(delta, "reasoning_content", None)
        if reasoning_chunk:
            reasoning_buffer += reasoning_chunk

        if delta.tool_calls:
            for tc_delta in delta.tool_calls:
                idx = getattr(tc_delta, "index", 0) or 0
                entry = tool_calls_acc.setdefault(
                    idx, {"id": "", "name": "", "arguments": ""},
                )
                if tc_delta.id:
                    entry["id"] = tc_delta.id
                fn = tc_delta.function
                if fn is not None:
                    if fn.name:
                        entry["name"] = fn.name
                    if fn.arguments:
                        entry["arguments"] += fn.arguments

        return content_buffer, reasoning_buffer, finish_reason

    def _extract_content_delta(self, chunk: Any) -> dict[str, Any] | None:
        """Extract content delta from chunk for immediate yielding."""
        if not chunk.choices:
            return None
        delta = chunk.choices[0].delta
        if not delta:
            return None

        if delta.content:
            return {"content": delta.content, "reasoning": False}

        reasoning = getattr(delta, "reasoning_content", None)
        if reasoning:
            return {"content": reasoning, "reasoning": True}

        return None

    def _execute_tool(
        self,
        tool_call: dict[str, Any],
    ) -> dict[str, Any]:
        """Execute a single tool call."""
        name = tool_call["name"]
        arguments_str = tool_call["arguments"]

        tool_fn = self.tools.get(name)
        if not tool_fn:
            return {
                "result": json.dumps({"error": f"Unknown tool: {name}"}),
                "error": True,
            }

        try:
            args = json.loads(arguments_str) if arguments_str else {}
            result = tool_fn(**args)
            if not isinstance(result, str):
                result = json.dumps(result, ensure_ascii=False)
            return {"result": result, "error": False}
        except json.JSONDecodeError as exc:
            logger.error("Invalid JSON arguments for tool %s: %s", name, exc)
            return {
                "result": json.dumps({"error": f"Invalid JSON arguments: {exc}"}),
                "error": True,
            }
        except Exception as exc:
            logger.exception("Tool %s execution failed", name)
            return {
                "result": json.dumps({"error": f"Tool execution failed: {exc}"}),
                "error": True,
            }

    def _run_finalization(
        self,
        messages: list[dict[str, Any]],
    ) -> Iterator[StreamEvent]:
        """Run a single closing turn after the iteration cap is hit."""
        messages.append({"role": "system", "content": self.finalize_prompt})

        try:
            stream = self._call_llm_stream(messages)

            tool_calls_acc: dict[int, dict[str, Any]] = {}
            content_buffer = ""

            for chunk in stream:
                if not chunk.choices:
                    continue
                choice = chunk.choices[0]
                delta = choice.delta
                if not delta:
                    continue

                if delta.content:
                    content_buffer += delta.content
                    yield ContentDeltaEvent(text=delta.content, reasoning=False)

                if delta.tool_calls:
                    for tc_delta in delta.tool_calls:
                        idx = getattr(tc_delta, "index", 0) or 0
                        entry = tool_calls_acc.setdefault(
                            idx, {"id": "", "name": "", "arguments": ""},
                        )
                        if tc_delta.id:
                            entry["id"] = tc_delta.id
                        fn = tc_delta.function
                        if fn is not None:
                            if fn.name:
                                entry["name"] = fn.name
                            if fn.arguments:
                                entry["arguments"] += fn.arguments

            if tool_calls_acc:
                ordered_calls = [
                    tool_calls_acc[k] for k in sorted(tool_calls_acc.keys())
                ]
                for call in ordered_calls:
                    yield ToolCallStartEvent(
                        tool_id=call["id"],
                        name=call["name"],
                        arguments=call["arguments"],
                    )
                    result = self._execute_tool(call)
                    yield ToolResultEvent(
                        tool_id=call["id"],
                        result=result["result"],
                        error=result["error"],
                    )

            if not content_buffer and not tool_calls_acc:
                yield ContentDeltaEvent(
                    text=(
                        "I've reached my tool budget without producing a "
                        "definitive answer. Please refine the request or "
                        "increase max_iterations and try again."
                    ),
                    reasoning=False,
                )

            yield DoneEvent(finish_reason="stop")
        except Exception as exc:
            logger.exception("Finalization step failed")
            yield ErrorEvent(
                message=f"Finalization failed: {exc}",
                code="finalize_error",
            )
            yield DoneEvent(finish_reason="error")
