"""omd/agents/base.py.

Base agent implementation with ReAct-style tool-calling loop.
"""

from __future__ import annotations

import json
import logging
import re
from collections.abc import Iterable
from pathlib import Path
from typing import Any

import requests

from omd.clients.base import BaseClient
from omd.prompts.base import PromptBase
from omd.skills.data_models import Skill
from omd.skills.registry import SkillRegistry
from omd.skills.router import SkillRouter
from omd.skills.tools import make_skill_tools
from omd.tools.data_models import Tool, ToolValidationError

LOGGER = logging.getLogger(__name__)

_INLINE_PART_REF_RE = re.compile(r"^\[(?P<part_type>[A-Z_]+):(?P<part_id>\d+)\]$")
_INLINE_PART_REF_BARE_RE = re.compile(r"^(?P<part_type>[A-Z_]+):(?P<part_id>\d+)$")
_DATA_URL_PREFIX = "data:"


class BaseAgent:
    """ReAct-style agent that iteratively calls tools until a final response.

    The agent implements an agentic loop:

    1. Send messages to the LLM with available tools.
    2. If the LLM returns tool calls, execute each tool and append results.
    3. Repeat until the LLM returns a plain message (no tool calls) or
       the attempt limit is reached.

    :param client: Model client implementing :class:`BaseClient`.
    :param tools: List of tools available to the agent.
    :param tool_choice: OpenAI-style tool choice control (``"auto"``, ``"none"``,
        or a dict specifying a particular tool).
    :param system_prompt: Optional system prompt prepended to every call.
    :param skills: Either a :class:`SkillRegistry` or an iterable of
        pre-built :class:`Skill` instances. When provided, enables the skill
        machinery (auto-routing and/or on-demand load via tools).
    :param skill_router: Optional :class:`SkillRouter` used for automatic
        skill selection on the first :meth:`run` call. Required for
        ``auto_skill_routing`` to actually do anything.
    :param auto_skill_routing: When ``True`` and both ``skills`` and
        ``skill_router`` are provided, the agent runs the router once on
        the first call and prepends the matched skills to ``intro_messages``.
    :param expose_skill_tools: When ``True`` and ``skills`` is provided,
        ``list_skills`` and ``load_skill`` tools are added to ``raw_tools``
        so the agent can pull skill instructions on demand.
    """

    def __init__(
        self,
        client: BaseClient,
        tools: list[Tool] | None = None,
        tool_choice: str | dict[str, Any] | None = None,
        system_prompt: str | PromptBase | None = None,
        *,
        skills: SkillRegistry | Iterable[Skill] | None = None,
        skill_router: SkillRouter | None = None,
        auto_skill_routing: bool = True,
        expose_skill_tools: bool = True,
    ):
        self.client = client
        self.tool_choice = tool_choice
        self.system_prompt = system_prompt

        self.skill_registry: SkillRegistry | None = self._coerce_skills(skills)
        self.skill_router = skill_router
        self.auto_skill_routing = auto_skill_routing
        self.expose_skill_tools = expose_skill_tools

        combined_tools: list[Tool] = list(tools) if tools else []
        if self.skill_registry is not None and expose_skill_tools:
            combined_tools.extend(make_skill_tools(self.skill_registry))
        self.raw_tools = combined_tools

        self._intro_messages: list[dict[str, Any]] | None = None
        self._tools: list[dict[str, Any]] | None = None
        self._tool_map: dict[str, Tool] | None = None
        self._selected_skills: list[Skill] | None = None

    @staticmethod
    def _coerce_skills(
        skills: SkillRegistry | Iterable[Skill] | None,
    ) -> SkillRegistry | None:
        """Normalize the ``skills`` constructor argument to a registry.

        :param skills: Registry, iterable of :class:`Skill`, or ``None``.
        :returns: Registry or ``None`` when no skills were provided.
        """
        if skills is None:
            return None
        if isinstance(skills, SkillRegistry):
            return skills
        return SkillRegistry(
            include_builtin=False,
            read_env=False,
            skills=list(skills),
        )

    @property
    def intro_messages(self) -> list[dict[str, Any]]:
        """Return the intro/system messages prepended to each model call.

        Combines the user-supplied ``system_prompt`` with any skills selected
        by the auto-router (if it has run already). The result is cached and
        invalidated when new skills are selected.

        :returns: List of messages to prepend (may be empty).
        :rtype: list[dict[str, Any]]
        """
        if self._intro_messages is None:
            messages: list[dict[str, Any]] = []
            if self.system_prompt is not None:
                messages.append(
                    {"role": "system", "content": str(self.system_prompt)}
                )
            if self._selected_skills:
                skill_block = "\n\n".join(
                    skill.render_for_prompt() for skill in self._selected_skills
                )
                messages.append({"role": "system", "content": skill_block})
            self._intro_messages = messages

        return self._intro_messages

    def _maybe_route_skills(self, messages: list[dict[str, Any]]) -> None:
        """Run the skill router once on the first :meth:`run` invocation.

        Sets ``self._selected_skills`` and invalidates the cached
        ``intro_messages``. Routing failures are logged and treated as
        "no skills selected" so the agent loop is never blocked.

        :param messages: Conversation messages used as the routing query.
        """
        if self._selected_skills is not None:
            return
        if not self.auto_skill_routing:
            return
        if self.skill_router is None or self.skill_registry is None:
            return
        if len(self.skill_registry) == 0:
            self._selected_skills = []
            return

        try:
            selected = self.skill_router.select(self.skill_registry, messages)
        except Exception as exc:
            LOGGER.warning("Skill routing raised %s; continuing with no skills", exc)
            selected = []

        self._selected_skills = selected
        self._intro_messages = None
        if selected:
            LOGGER.debug(
                "Skill router selected: %s",
                [skill.name for skill in selected],
            )

    @property
    def tools(self) -> list[dict[str, Any]] | None:
        """Return JSON-serialized tool schemas for the API call."""
        if self._tools is None and self.raw_tools is not None:
            self._tools = [tool.model_dump() for tool in self.raw_tools]
        return self._tools

    @property
    def tool_map(self) -> dict[str, Tool] | None:
        """Return a mapping from tool name to Tool instance."""
        if self._tool_map is None and self.raw_tools is not None:
            self._tool_map = {tool.name: tool for tool in self.raw_tools}
        return self._tool_map

    def run(
        self,
        messages: list[dict[str, Any]],
        attempts_limit: int = 10,
        init_messages_count: int | None = None,
    ) -> list[dict[str, Any]]:
        """Execute the agentic loop.

        :param messages: Conversation messages (modified in-place).
        :param attempts_limit: Maximum number of LLM calls. On the last attempt,
            tools are disabled to force a final response.
        :param init_messages_count: Number of initial messages (used internally
            for recursion). If ``None``, set to ``len(messages)``.
        :returns: New messages generated during the run (from ``init_messages_count``
            to the end of the list).
        :raises KeyError: If the LLM requests a tool that is not registered.
        """
        if init_messages_count is None:
            init_messages_count = len(messages)
            self._maybe_route_skills(messages)

        tools = None if attempts_limit <= 1 else self.tools

        LOGGER.debug(
            "Agent run: attempt=%d, messages=%d, tools_enabled=%s",
            attempts_limit,
            len(messages),
            tools is not None,
        )

        response = self.client.call_model(
            messages=self.intro_messages + messages,
            tools=tools,
            tool_choice=self.tool_choice if tools else None,
        )
        new_message = response["choices"][0]["message"]
        LOGGER.debug(
            "LLM response: role=%s tool_calls=%s content_len=%d",
            new_message.get("role"),
            new_message.get("tool_calls") is not None,
            len(str(new_message.get("content", ""))),
        )
        messages.append(new_message)

        tool_calls = new_message.get("tool_calls")
        if tool_calls is not None:
            for tool_call in tool_calls:
                tool_name = tool_call["function"]["name"]
                tool_arguments = json.loads(tool_call["function"]["arguments"])
                tool_call_id = tool_call.get("id", "")

                cur_tool = self.tool_map.get(tool_name) if self.tool_map else None
                if cur_tool is None:
                    raise KeyError(f"Unknown tool requested by LLM: {tool_name}")

                tool_arguments = self._resolve_inline_part_refs_in_tool_arguments(
                    tool_arguments=tool_arguments,
                    messages=messages,
                )
                try:
                    validated_args = cur_tool.validate(tool_arguments)
                    tool_result = cur_tool.invoke(validated_args)
                except ToolValidationError as exc:
                    LOGGER.warning(
                        "Tool arguments validation failed. tool=%s error=%s",
                        tool_name, exc,
                    )
                    tool_result = json.dumps(
                        {
                            "error": "tool_validation_error",
                            "tool": tool_name,
                            "message": exc.message,
                            "arguments": exc.tool_arguments,
                        },
                        ensure_ascii=False,
                        default=str,
                    )
                except (TypeError, ValueError, FileNotFoundError, IsADirectoryError) as exc:
                    tool_result = self._handle_tool_execution_error(
                        cur_tool=cur_tool,
                        tool_name=tool_name,
                        exc=exc,
                        validated_args=(
                            validated_args if "validated_args" in locals() else tool_arguments
                        ),
                    )
                except requests.exceptions.RequestException as exc:
                    tool_result = self._build_tool_http_error_result(
                        tool_name=tool_name,
                        exc=exc,
                        arguments=(
                            validated_args if "validated_args" in locals() else tool_arguments
                        ),
                    )

                messages.append({
                    "role": "tool",
                    "tool_call_id": tool_call_id,
                    "name": tool_name,
                    "content": tool_result,
                })

            return self.run(
                messages=messages,
                attempts_limit=attempts_limit - 1,
                init_messages_count=init_messages_count,
            )

        return messages[init_messages_count:]

    def _handle_tool_execution_error(
        self,
        *,
        cur_tool: Tool,
        tool_name: str,
        exc: TypeError | ValueError | FileNotFoundError | IsADirectoryError,
        validated_args: object,
    ) -> str:
        """Handle tool execution errors and perform Gemini-specific recovery.

        :param cur_tool: Tool instance being executed.
        :param tool_name: Tool name requested by the model.
        :param exc: Execution error raised by the tool.
        :param validated_args: Validated arguments used for the tool call.
        :returns: Tool result payload that should be appended to the conversation.
        """
        details = self._extract_tool_error_details(exc)

        if (
            tool_name == "generate_image_gemini"
            and isinstance(validated_args, dict)
            and isinstance(details, dict)
            and details.get("should_retry_with_include_text") is True
            and validated_args.get("include_text") is not True
        ):
            retry_args = dict(validated_args)
            retry_args["include_text"] = True
            LOGGER.info(
                "Retrying Gemini image generation with include_text enabled. reason=%s",
                details.get("failure_kind"),
            )
            try:
                retry_validated_args = cur_tool.validate(retry_args)
                return cur_tool.invoke(retry_validated_args)
            except ToolValidationError as retry_exc:
                return self._build_tool_execution_error_result(
                    tool_name=tool_name,
                    exc=retry_exc,
                    arguments=retry_args,
                    extra={
                        "details": self._extract_tool_error_details(retry_exc),
                        "auto_retry_attempted": True,
                        "auto_retry_args": retry_args,
                        "original_details": details,
                        "suggested_agent_action": "explain_problem_to_user",
                    },
                )
            except (TypeError, ValueError, FileNotFoundError, IsADirectoryError) as retry_exc:
                retry_details = self._extract_tool_error_details(retry_exc)
                return self._build_tool_execution_error_result(
                    tool_name=tool_name,
                    exc=retry_exc,
                    arguments=retry_args,
                    extra={
                        "details": retry_details,
                        "auto_retry_attempted": True,
                        "auto_retry_args": retry_args,
                        "original_details": details,
                        "suggested_agent_action": "explain_problem_to_user",
                        "user_message": (
                            retry_details.get("user_message")
                            if isinstance(retry_details, dict)
                            else None
                        ),
                    },
                )
            except requests.exceptions.RequestException as retry_exc:
                return self._build_tool_http_error_result(
                    tool_name=tool_name,
                    exc=retry_exc,
                    arguments=retry_args,
                    extra={
                        "auto_retry_attempted": True,
                        "auto_retry_args": retry_args,
                        "original_details": details,
                        "suggested_agent_action": "explain_problem_to_user",
                    },
                )

        extra: dict[str, Any] = {}
        if isinstance(details, dict):
            extra = {
                "details": details,
                "retry_with_include_text_recommended": details.get(
                    "should_retry_with_include_text",
                    False,
                ),
                "suggested_agent_action": (
                    "retry_with_include_text"
                    if details.get("should_retry_with_include_text") is True
                    else "explain_problem_to_user"
                ),
                "user_message": details.get("user_message"),
            }

        return self._build_tool_execution_error_result(
            tool_name=tool_name,
            exc=exc,
            arguments=validated_args,
            extra=extra or None,
        )

    @staticmethod
    def _extract_tool_error_details(exc: BaseException) -> dict[str, Any] | None:
        """Return structured error details when the exception provides them.

        :param exc: Caught exception from a tool call.
        :returns: Structured details dict or ``None``.
        """
        details = getattr(exc, "details", None)
        return details if isinstance(details, dict) else None

    @staticmethod
    def _build_tool_execution_error_result(
        *,
        tool_name: str,
        exc: BaseException,
        arguments: object,
        extra: dict[str, Any] | None = None,
    ) -> str:
        """Build a structured tool execution error payload for the model.

        :param tool_name: Tool name requested by the model.
        :param exc: Exception raised by the tool.
        :param arguments: Tool arguments used for the call.
        :param extra: Optional additional fields to include.
        :returns: JSON-serialized tool result.
        """
        details = getattr(exc, "details", None)
        failure_kind = details.get("failure_kind") if isinstance(details, dict) else None
        LOGGER.warning(
            "Tool execution failed. tool=%s error_type=%s failure_kind=%s",
            tool_name,
            type(exc).__name__,
            failure_kind,
        )
        payload: dict[str, Any] = {
            "error": "tool_execution_error",
            "tool": tool_name,
            "message": f"{type(exc).__name__}: {exc}",
            "arguments": arguments,
        }
        if extra:
            payload.update(extra)
        return json.dumps(payload, ensure_ascii=False, default=str)

    @staticmethod
    def _build_tool_http_error_result(
        *,
        tool_name: str,
        exc: requests.exceptions.RequestException,
        arguments: object,
        extra: dict[str, Any] | None = None,
    ) -> str:
        """Build a structured HTTP/network error payload for the model.

        :param tool_name: Tool name requested by the model.
        :param exc: HTTP/network exception raised by the tool.
        :param arguments: Tool arguments used for the call.
        :param extra: Optional additional fields to include.
        :returns: JSON-serialized tool result.
        """
        response = getattr(exc, "response", None)
        status_code = getattr(response, "status_code", None)
        url = getattr(response, "url", None)
        content_type = (
            getattr(response, "headers", {}).get("Content-Type") if response else None
        )

        errors: list[str] | None = None
        response_body: str | None = None
        if response is not None:
            try:
                payload = response.json()
            except ValueError:
                payload = None

            if isinstance(payload, dict):
                raw_errors = payload.get("errors")
                if isinstance(raw_errors, list):
                    errors = [str(e) for e in raw_errors if str(e).strip()]
                response_body = json.dumps(payload, ensure_ascii=False, default=str)
            else:
                try:
                    response_body = response.text
                except UnicodeDecodeError:
                    response_body = (
                        f"<non-text body len={len(getattr(response, 'content', b''))}>"
                    )

        if response_body is not None:
            response_body = response_body.strip()
            if len(response_body) > 4000:
                response_body = response_body[:4000] + "...<truncated>"

        LOGGER.warning(
            "Tool HTTP/network error. tool=%s status=%s url=%s error_type=%s",
            tool_name,
            status_code,
            url,
            type(exc).__name__,
        )

        payload = {
            "error": "tool_http_error",
            "tool": tool_name,
            "message": f"{type(exc).__name__}: {exc}",
            "status_code": status_code,
            "url": url,
            "content_type": content_type,
            "errors": errors,
            "response_body": response_body,
            "arguments": arguments,
        }
        if extra:
            payload.update(extra)
        return json.dumps(payload, ensure_ascii=False, default=str)

    @classmethod
    def _resolve_inline_part_refs_in_tool_arguments(
        cls,
        *,
        tool_arguments: object,
        messages: list[dict[str, Any]],
    ) -> object:
        """Resolve image-part tokens in tool arguments to the corresponding image_url.

        The message conversion layer may inject identifier tokens like ``[IMAGE:42]`` (or
        occasionally ``IMAGE:42``) next to
        ``{"type": "image_url", "image_url": {"url": ...}}`` items so the model can reference
        attachments. Some models may incorrectly pass the identifier token as a tool argument.

        This resolver maps such tokens back to the nearest ``image_url`` in the provided
        conversation payload, so tools can operate on actual image content/URLs.

        :param tool_arguments: Parsed tool arguments (dict/list/scalars).
        :param messages: Current conversation messages passed to the model.
        :returns: Tool arguments with inline part refs replaced when possible.
        """

        def _parse_image_ref_token(token: str) -> str | None:
            stripped = token.strip()
            match = _INLINE_PART_REF_RE.match(stripped)
            if match is None:
                match = _INLINE_PART_REF_BARE_RE.match(stripped)
            if match is None:
                return None
            if match.group("part_type") != "IMAGE":
                return None
            return match.group("part_id")

        def find_latest_image_url() -> str | None:
            for msg in reversed(messages):
                content = msg.get("content")
                if not isinstance(content, list):
                    continue
                for item in content:
                    if not isinstance(item, dict):
                        continue
                    if item.get("type") != "image_url":
                        continue
                    image_url = item.get("image_url")
                    url = image_url.get("url") if isinstance(image_url, dict) else None
                    if isinstance(url, str) and url.strip():
                        return url
            return None

        latest_image_url = find_latest_image_url()

        def resolve_token_to_image_url(token: str) -> str | None:
            part_id = _parse_image_ref_token(token)
            if part_id is None:
                return None

            for msg in reversed(messages):
                content = msg.get("content")
                if not isinstance(content, list):
                    continue
                for i, item in enumerate(content):
                    if not isinstance(item, dict):
                        continue
                    if (
                        item.get("type") != "text"
                        or str(item.get("text", "")).strip() != f"[IMAGE:{part_id}]"
                    ):
                        continue
                    for j in range(i + 1, len(content)):
                        next_item = content[j]
                        if not isinstance(next_item, dict):
                            continue
                        if next_item.get("type") != "image_url":
                            continue
                        image_url = next_item.get("image_url")
                        url = (
                            image_url.get("url") if isinstance(image_url, dict) else None
                        )
                        if isinstance(url, str) and url.strip():
                            return url
            return None

        def walk(value: object, *, parent_key: str | None = None) -> object:
            if isinstance(value, str):
                resolved = resolve_token_to_image_url(value)
                if resolved is not None:
                    return resolved

                key = (parent_key or "").lower()
                if latest_image_url is not None and (
                    key.endswith("_image_path")
                    or key in {
                        "subject_image_path",
                        "background_reference_path",
                        "light_reference_path",
                        "image_path",
                        "style_reference_image",
                        "reference_image",
                    }
                ):
                    candidate = value.strip()
                    if (
                        candidate
                        and not candidate.startswith(_DATA_URL_PREFIX)
                        and "://" not in candidate
                        and not Path(candidate).exists()
                    ):
                        return latest_image_url

                return value
            if isinstance(value, list):
                return [walk(v, parent_key=parent_key) for v in value]
            if isinstance(value, dict):
                return {k: walk(v, parent_key=str(k)) for k, v in value.items()}
            return value

        return walk(tool_arguments)
