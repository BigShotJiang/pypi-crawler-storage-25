"""omd/streaming/events.py.

Stream event dataclasses for async agent streaming.

These events are emitted by :class:`omd.agents.streaming.AsyncStreamingAgent`
and consumed by formatters (e.g., :class:`omd.streaming.sse_formatter.OwuiSseFormatter`)
to produce server-sent events for chat clients.
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass
class ContentDeltaEvent:
    """Incremental text content from the LLM.

    :param text: Text fragment to append to the current content block.
    :param reasoning: If True, this content is part of reasoning/thinking,
        not the final answer. Formatters may wrap such content in special
        tags (e.g., <thinking> or <details>).
    """

    text: str
    reasoning: bool = False


@dataclass
class ToolCallStartEvent:
    """A tool call has been initiated by the LLM.

    :param tool_id: Unique identifier for this tool call (from LLM).
    :param name: Tool name being called.
    :param arguments: JSON-serialized arguments string.
    """

    tool_id: str
    name: str
    arguments: str


@dataclass
class ToolResultEvent:
    """Result of a completed tool execution.

    :param tool_id: Identifier matching the corresponding ToolCallStartEvent.
    :param result: Tool output (typically JSON string).
    :param error: If True, the result is an error message.
    """

    tool_id: str
    result: str
    error: bool = False


@dataclass
class DoneEvent:
    """Stream completion event.

    :param finish_reason: Why the stream ended ("stop", "length", "error").
    :param usage: Optional token usage statistics.
    """

    finish_reason: str = "stop"
    usage: dict[str, int] | None = None


@dataclass
class ErrorEvent:
    """Error occurred during streaming.

    :param message: Human-readable error description.
    :param code: Optional error code for programmatic handling.
    """

    message: str
    code: str | None = None


# Union type for all stream events
StreamEvent = ContentDeltaEvent | ToolCallStartEvent | ToolResultEvent | DoneEvent | ErrorEvent
