"""omd/streaming/sse_formatter.py.

SSE formatter for Open WebUI-compatible streaming.

Formats :class:`StreamEvent` objects into server-sent event chunks
using OpenAI-compatible format with OWUI-specific extensions:
- Reasoning blocks wrapped in <thinking>...</thinking>
- Tool calls wrapped in `<details type="tool_calls">...</details>`
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Any

from omd.streaming.events import (
    ContentDeltaEvent,
    DoneEvent,
    ErrorEvent,
    StreamEvent,
    ToolCallStartEvent,
    ToolResultEvent,
)


@dataclass
class OwuiSseFormatter:
    """Formats stream events into SSE chunks for Open WebUI.

    The formatter is stateful: ``ToolCallStartEvent`` is buffered and
    combined with the matching ``ToolResultEvent`` into a single
    ``<details type="tool_calls" done="true">`` block which Open WebUI
    renders as a single collapsible "tool call" plate. This avoids the
    fragile "open then patch" two-chunk approach which produced raw
    HTML in the chat when blocks could not be matched up.

    :param max_tool_result_chars: Maximum characters to include for
        tool result display (truncated if longer). Full result still
        sent to LLM via the tool message.
    """

    max_tool_result_chars: int = 2000

    # Internal state: tool_id -> (name, arguments)
    _pending_tool_calls: dict[str, tuple[str, str]] = field(default_factory=dict)

    def format(self, event: StreamEvent) -> str | None:
        """Convert a stream event to an SSE data line.

        :param event: The stream event to format.
        :returns: SSE data line (without "data: " prefix) or None to skip.
        """
        match event:
            case ContentDeltaEvent(text=text, reasoning=reasoning):
                return self._format_content_delta(text, reasoning)
            case ToolCallStartEvent(tool_id=id, name=name, arguments=args):
                return self._format_tool_call_start(id, name, args)
            case ToolResultEvent(tool_id=id, result=result, error=error):
                return self._format_tool_result(id, result, error)
            case DoneEvent(finish_reason=reason, usage=usage):
                return self._format_done(reason, usage)
            case ErrorEvent(message=msg, code=code):
                return self._format_error(msg, code)
            case _:
                return None

    def _format_content_delta(self, text: str, reasoning: bool) -> str | None:
        """Format content delta as SSE chunk."""
        content = text
        if reasoning:
            content = f"<thinking>{content}</thinking>"

        chunk = {
            "choices": [
                {
                    "index": 0,
                    "delta": {"role": "assistant", "content": content},
                    "finish_reason": None,
                }
            ]
        }
        return json.dumps(chunk, ensure_ascii=False)

    def _format_tool_call_start(
        self,
        tool_id: str,
        name: str,
        arguments: str,
    ) -> str | None:
        """Buffer tool-call metadata until the result arrives.

        We intentionally emit nothing here: Open WebUI cannot patch a
        previously-streamed ``<details done="false">`` block reliably,
        which produces raw HTML in the chat. Live progress should be
        signalled separately via ``__event_emitter__`` on the proxy.
        """
        self._pending_tool_calls[tool_id] = (name, arguments)
        return None

    def _format_tool_result(
        self,
        tool_id: str,
        result: str,
        error: bool,
    ) -> str | None:
        """Emit one collapsible details block summarising the tool call."""
        name, arguments = self._pending_tool_calls.pop(
            tool_id, ("(unknown)", ""),
        )

        display_result = self._truncate_result(result)

        escaped_args = self._escape_attr(arguments)
        escaped_result = self._escape_attr(display_result)
        body_result = self._escape_html(display_result)

        if error:
            summary = "⚠️ {name} failed"
            body = f'<pre style="color:#b00"><code>{body_result}</code></pre>'
        else:
            summary = f"✓ Executed {name}"
            body = f"<pre><code>{body_result}</code></pre>"

        content = (
            f'<details type="tool_calls" done="true" '
            f'id="{tool_id}" name="{name}" '
            f'arguments="{escaped_args}" result="{escaped_result}">\n'
            f"<summary>{summary}</summary>\n"
            f"{body}\n"
            f"</details>\n"
        )

        chunk = {
            "choices": [
                {
                    "index": 0,
                    "delta": {"role": "assistant", "content": content},
                    "finish_reason": None,
                }
            ]
        }
        return json.dumps(chunk, ensure_ascii=False)

    @staticmethod
    def _escape_attr(value: str) -> str:
        """Escape a string so it is safe inside an HTML attribute value."""
        return (
            value.replace("&", "&amp;")
            .replace('"', "&quot;")
            .replace("<", "&lt;")
            .replace(">", "&gt;")
            .replace("\n", "&#10;")
        )

    @staticmethod
    def _escape_html(value: str) -> str:
        """Escape a string so it is safe inside HTML element text."""
        return (
            value.replace("&", "&amp;")
            .replace("<", "&lt;")
            .replace(">", "&gt;")
        )

    def _format_done(
        self,
        finish_reason: str,
        usage: dict[str, int] | None,
    ) -> str | None:
        """Format stream completion."""
        chunk: dict[str, Any] = {
            "choices": [
                {
                    "index": 0,
                    "delta": {},
                    "finish_reason": finish_reason,
                }
            ]
        }
        if usage:
            chunk["usage"] = usage
        return json.dumps(chunk, ensure_ascii=False)

    def _format_error(self, message: str, code: str | None) -> str | None:
        """Format error as SSE chunk."""
        chunk = {
            "choices": [
                {
                    "index": 0,
                    "delta": {"role": "assistant", "content": f"Error: {message}"},
                    "finish_reason": "error",
                }
            ]
        }
        if code:
            chunk["error"] = {"code": code, "message": message}
        return json.dumps(chunk, ensure_ascii=False)

    def _truncate_result(self, result: str) -> str:
        """Truncate tool result for display purposes.

        Full result is preserved for LLM context; only the display
        representation is truncated.
        """
        if len(result) <= self.max_tool_result_chars:
            return result

        truncated = result[: self.max_tool_result_chars]
        remaining = len(result) - self.max_tool_result_chars
        return f"{truncated}... [truncated, {remaining} more chars]"

    def finalize(self) -> str:
        """Return the final SSE terminator."""
        return "[DONE]"
