"""omd/machinery/veo.py.

Veo video generation functions via api-bar gateway.

Implements the full lifecycle for Veo video generation through the api-bar
proxy: submit a long-running prediction, poll until completion, download the
generated video, upload it to MinIO, and return a presigned URL.

The REST API flow follows the Gemini ``predictLongRunning`` pattern::

    POST /models/{model}:predictLongRunning  ->  operation name
    GET  /{operation_name}  (poll until done)
    GET  {video_uri}  ->  video bytes
"""

from __future__ import annotations

import json
import logging
import os
import time
from base64 import b64encode
from typing import Any

import requests

from omd.machinery.image_utils import (
    _format_http_error_body_for_log,
    _read_image_source,
    _run_coro_sync,
)
from omd.tools.data_models import ToolValidationError

logger = logging.getLogger(__name__)

_API_BAR_GEMINI_BASE = "https://api-bar.ru/route/gemini"

_VEO_DEFAULT_MODEL = "veo-3.0-fast-generate-001"
_VEO_ALLOWED_MODELS: set[str] = {
    "veo-3.0-generate-001",
    "veo-3.0-fast-generate-001",
    "veo-3.1-generate-preview",
    "veo-3.1-fast-generate-preview",
    "veo-3.1-lite-generate-preview",
}
_VEO_ALLOWED_ASPECT_RATIOS: set[str] = {"16:9", "9:16"}
_VEO_ALLOWED_RESOLUTIONS: set[str] = {"720p", "1080p", "4k"}
_VEO_ALLOWED_DURATIONS: set[str] = {"4", "6", "8"}
_VEO_DEFAULT_POLL_INTERVAL_S = 10.0
_VEO_DEFAULT_TIMEOUT_S = 600.0
_DEFAULT_MINIO_PRESIGNED_URL_EXPIRES_IN_S = 3600


def _get_api_key() -> str:
    """Resolve API key from environment.

    :returns: API key string.
    :raises KeyError: If neither ``API_BAR_TOKEN`` nor ``MODEL_API_TOKEN`` is set.
    """
    try:
        return os.environ["API_BAR_TOKEN"]
    except KeyError:
        return os.environ["MODEL_API_TOKEN"]


def _submit_video_generation(
    *,
    prompt: str,
    reference_image: str | None,
    aspect_ratio: str,
    resolution: str,
    duration_seconds: str,
    model: str,
    api_key: str,
    timeout_s: float,
) -> str:
    """Submit a video generation request and return the operation name.

    :param prompt: Text description for the video.
    :param reference_image: Optional image source (path, URL, or data URL).
    :param aspect_ratio: Video aspect ratio (``"16:9"`` or ``"9:16"``).
    :param resolution: Target resolution (``"720p"``, ``"1080p"``, ``"4k"``).
    :param duration_seconds: Duration string (``"4"``, ``"6"``, ``"8"``).
    :param model: Veo model identifier.
    :param api_key: api-bar bearer token.
    :param timeout_s: HTTP request timeout.
    :returns: Operation name for subsequent polling.
    :raises requests.HTTPError: On non-200 response.
    :raises ValueError: If the response lacks an operation name.
    """
    instance: dict[str, Any] = {"prompt": prompt}

    if reference_image is not None:
        _, image_bytes, mime_type = _read_image_source(
            reference_image, timeout_s=timeout_s,
        )
        instance["image"] = {
            "bytesBase64Encoded": b64encode(image_bytes).decode("ascii"),
            "mimeType": mime_type,
        }

    payload: dict[str, Any] = {
        "model": model,
        "instances": [instance],
        "parameters": {
            "aspectRatio": aspect_ratio,
            "resolution": resolution,
            "durationSeconds": int(duration_seconds),
        },
    }

    url = f"{_API_BAR_GEMINI_BASE}/models/predictLongRunning"
    response = requests.post(
        url,
        headers={
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
        },
        json=payload,
        timeout=timeout_s,
    )

    if response.status_code != 200:
        logger.error(
            "Veo predictLongRunning failed: status=%s url=%s body=%s",
            response.status_code,
            response.url,
            _format_http_error_body_for_log(response),
        )
        response.raise_for_status()

    data = response.json()
    operation_name = data.get("name")
    if not isinstance(operation_name, str) or not operation_name.strip():
        raise ValueError(
            "Veo predictLongRunning returned no operation name. "
            f"response={json.dumps(data, ensure_ascii=False, default=str)[:2000]}"
        )

    logger.info(
        "Veo generation submitted. model=%s operation=%s",
        model,
        operation_name,
    )
    return operation_name


def _poll_operation(
    *,
    operation_name: str,
    api_key: str,
    timeout_s: float,
    poll_interval_s: float,
) -> dict[str, Any]:
    """Poll a long-running operation until ``done`` is ``True``.

    :param operation_name: Operation identifier from ``predictLongRunning``.
    :param api_key: api-bar bearer token.
    :param timeout_s: Maximum wall-clock time to wait.
    :param poll_interval_s: Sleep between poll requests.
    :returns: Completed operation payload.
    :raises TimeoutError: If not done within *timeout_s*.
    :raises requests.HTTPError: On poll failure.
    :raises ValueError: If the operation completed with an error.
    """
    url = f"{_API_BAR_GEMINI_BASE}/{operation_name}"
    deadline = time.monotonic() + timeout_s

    while True:
        if time.monotonic() >= deadline:
            raise TimeoutError(
                f"Veo generation timed out after {timeout_s}s. "
                f"operation={operation_name}"
            )

        time.sleep(poll_interval_s)

        response = requests.get(
            url,
            headers={"Authorization": f"Bearer {api_key}"},
            timeout=min(30.0, timeout_s),
        )

        if response.status_code != 200:
            logger.warning(
                "Veo poll failed: status=%s operation=%s body=%s",
                response.status_code,
                operation_name,
                _format_http_error_body_for_log(response),
            )
            response.raise_for_status()

        data = response.json()

        if data.get("done") is True:
            error = data.get("error")
            if isinstance(error, dict):
                raise ValueError(
                    f"Veo generation failed. code={error.get('code')} "
                    f"message={error.get('message')}"
                )
            logger.info(
                "Veo generation completed. operation=%s", operation_name,
            )
            return data

        logger.debug(
            "Veo operation in progress. operation=%s", operation_name,
        )


def _extract_video_uri(operation_response: dict[str, Any]) -> str:
    """Extract the video download URI from a completed operation.

    :param operation_response: Payload with ``done: true``.
    :returns: Video URI string.
    :raises ValueError: If the URI cannot be located.
    """
    try:
        samples = (
            operation_response["response"]
            ["generateVideoResponse"]
            ["generatedSamples"]
        )
        video_uri = samples[0]["video"]["uri"]
    except (KeyError, IndexError, TypeError) as exc:
        summary = json.dumps(
            operation_response, ensure_ascii=False, default=str, sort_keys=True,
        )[:2000]
        raise ValueError(
            f"Could not extract video URI from Veo response. summary={summary}"
        ) from exc

    if not isinstance(video_uri, str) or not video_uri.strip():
        raise ValueError("Veo response contains an empty video URI.")

    return video_uri


def _download_video(
    *,
    video_uri: str,
    api_key: str,
    timeout_s: float,
) -> bytes:
    """Download video bytes from a Veo video URI.

    If *video_uri* points directly at ``generativelanguage.googleapis.com``
    it is rewritten to go through api-bar (the direct endpoint rejects our
    API-key with 401).

    :param video_uri: URI returned by the completed operation.
    :param api_key: api-bar bearer token.
    :param timeout_s: HTTP timeout for the download.
    :returns: Raw MP4 bytes.
    :raises requests.HTTPError: On download failure.
    :raises ValueError: If the downloaded content is empty.
    """
    _GOOGLE_HOST = "https://generativelanguage.googleapis.com/v1beta/"
    if video_uri.startswith(_GOOGLE_HOST):
        video_uri = _API_BAR_GEMINI_BASE + "/" + video_uri[len(_GOOGLE_HOST):]

    response = requests.get(
        video_uri,
        headers={"Authorization": f"Bearer {api_key}"},
        timeout=timeout_s,
        allow_redirects=True,
    )

    if response.status_code != 200:
        logger.error(
            "Veo video download failed: status=%s url=%s body=%s",
            response.status_code,
            video_uri,
            _format_http_error_body_for_log(response),
        )
        response.raise_for_status()

    video_bytes = response.content
    if not video_bytes:
        raise ValueError("Downloaded video is empty.")

    logger.info("Veo video downloaded. size_bytes=%d", len(video_bytes))
    return video_bytes


def _upload_video_and_get_presigned_url(video_bytes: bytes) -> str:
    """Upload MP4 bytes to MinIO and return a presigned URL.

    :param video_bytes: Raw video content.
    :returns: Presigned URL for the uploaded video.
    :raises RuntimeError: If ``minio_client`` is not installed.
    :raises KeyError: If required MinIO environment variables are missing.
    """
    try:
        from minio_client import MinioClient, MinioConfig  # type: ignore[import-untyped]
    except ImportError as exc:
        raise RuntimeError(
            "minio_client package is required to publish generated videos."
        ) from exc

    expires_in_s = int(
        os.environ.get(
            "MINIO_PRESIGNED_URL_EXPIRES_IN",
            str(_DEFAULT_MINIO_PRESIGNED_URL_EXPIRES_IN_S),
        )
    )

    config = MinioConfig.from_env()
    minio = MinioClient(config)

    async def _upload_and_presign() -> str:
        await minio.ensure_bucket_exists()
        internal_url = await minio.upload_file(
            prefix="veo",
            file_bytes=video_bytes,
            file_name="veo_result.mp4",
            content_type="video/mp4",
        )
        object_key = minio.extract_object_key_from_url(internal_url)
        if object_key is None:
            logger.warning(
                "Could not extract object key from MinIO URL. url=%s",
                internal_url,
            )
            return internal_url
        return await minio.generate_presigned_url(
            object_key=object_key,
            expires_in=expires_in_s,
        )

    return str(_run_coro_sync(_upload_and_presign()))


def generate_video_veo_validator(
    tool_arguments: dict[str, Any],
) -> dict[str, Any]:
    """Validate and normalize arguments for :func:`generate_video_veo`.

    :param tool_arguments: Parsed tool arguments from the model.
    :returns: Validated and normalized arguments dictionary.
    :raises ToolValidationError: If any argument is invalid.
    """
    tool_name = "generate_video_veo"
    allowed_keys = {
        "prompt",
        "reference_image",
        "aspect_ratio",
        "resolution",
        "duration_seconds",
        "model",
        "timeout_s",
    }
    unknown_keys = sorted(set(tool_arguments) - allowed_keys)
    if unknown_keys:
        raise ToolValidationError(
            tool_name=tool_name,
            message=(
                f"Unknown argument(s): {unknown_keys}. "
                f"Allowed keys: {sorted(allowed_keys)}"
            ),
            tool_arguments=tool_arguments,
        )

    args: dict[str, Any] = dict(tool_arguments)

    prompt = args.get("prompt")
    if not isinstance(prompt, str) or not prompt.strip():
        raise ToolValidationError(
            tool_name=tool_name,
            message="prompt must be a non-empty string.",
            tool_arguments=tool_arguments,
        )
    args["prompt"] = prompt.strip()

    for key in ("reference_image", "model"):
        if key not in args:
            continue
        value = args[key]
        if value is None:
            continue
        if not isinstance(value, str):
            raise ToolValidationError(
                tool_name=tool_name,
                message=(
                    f"{key} must be a string or null, "
                    f"got {type(value).__name__}."
                ),
                tool_arguments=tool_arguments,
            )
        stripped = value.strip()
        args[key] = stripped if stripped else None

    model_value = args.get("model")
    if model_value is not None and model_value not in _VEO_ALLOWED_MODELS:
        raise ToolValidationError(
            tool_name=tool_name,
            message=(
                f"model must be one of {sorted(_VEO_ALLOWED_MODELS)}, "
                f"got '{model_value}'."
            ),
            tool_arguments=tool_arguments,
        )

    if (
        "aspect_ratio" in args
        and args["aspect_ratio"] is not None
        and args["aspect_ratio"] not in _VEO_ALLOWED_ASPECT_RATIOS
    ):
        raise ToolValidationError(
            tool_name=tool_name,
            message=(
                f"aspect_ratio must be one of "
                f"{sorted(_VEO_ALLOWED_ASPECT_RATIOS)}, "
                f"got '{args['aspect_ratio']}'."
            ),
            tool_arguments=tool_arguments,
        )

    if (
        "resolution" in args
        and args["resolution"] is not None
        and args["resolution"] not in _VEO_ALLOWED_RESOLUTIONS
    ):
        raise ToolValidationError(
            tool_name=tool_name,
            message=(
                f"resolution must be one of "
                f"{sorted(_VEO_ALLOWED_RESOLUTIONS)}, "
                f"got '{args['resolution']}'."
            ),
            tool_arguments=tool_arguments,
            )

    if "duration_seconds" in args and args["duration_seconds"] is not None:
        dur = str(args["duration_seconds"])
        if dur not in _VEO_ALLOWED_DURATIONS:
            raise ToolValidationError(
                tool_name=tool_name,
                message=(
                    f"duration_seconds must be one of "
                    f"{sorted(_VEO_ALLOWED_DURATIONS)}, got '{dur}'."
                ),
                tool_arguments=tool_arguments,
            )
        args["duration_seconds"] = dur

    if "timeout_s" in args and args["timeout_s"] is not None:
        timeout_s = args["timeout_s"]
        if not isinstance(timeout_s, (int, float)):
            raise ToolValidationError(
                tool_name=tool_name,
                message=(
                    f"timeout_s must be a number, "
                    f"got {type(timeout_s).__name__}."
                ),
                tool_arguments=tool_arguments,
            )
        timeout_f = float(timeout_s)
        if timeout_f <= 0.0:
            raise ToolValidationError(
                tool_name=tool_name,
                message="timeout_s must be > 0.",
                tool_arguments=tool_arguments,
            )
        args["timeout_s"] = timeout_f

    return args


def generate_video_veo(
    prompt: str,
    reference_image: str | None = None,
    aspect_ratio: str = "16:9",
    resolution: str = "720p",
    duration_seconds: str = "8",
    model: str = _VEO_DEFAULT_MODEL,
    timeout_s: float = _VEO_DEFAULT_TIMEOUT_S,
) -> str:
    """Generate a short video (4-8 s) with native audio using Google Veo via api-bar.

    Submits a ``predictLongRunning`` request to the Gemini API through
    ``/route/gemini/``, polls until the video is ready, downloads the MP4,
    uploads it to MinIO, and returns a presigned URL.

    :param prompt: Detailed text description of the video.
    :param reference_image: Optional image used as the starting frame.
    :param aspect_ratio: ``"16:9"`` for landscape or ``"9:16"`` for portrait.
    :param resolution: ``"720p"``, ``"1080p"``, or ``"4k"``.
    :param duration_seconds: ``"4"``, ``"6"``, or ``"8"`` (default).
    :param model: Veo model identifier.
    :param timeout_s: Maximum wall-clock time in seconds.
    :returns: JSON string
        ``{"type":"video_url","video_url":{"url":"<presigned_url>"}}``.
    :raises requests.HTTPError: If api-bar returns a non-200 response.
    :raises TimeoutError: If generation does not complete within *timeout_s*.
    :raises ValueError: If the response is missing video data.
    :raises KeyError: If ``API_BAR_TOKEN`` / ``MODEL_API_TOKEN`` is not set.
    """
    api_key = _get_api_key()

    operation_name = _submit_video_generation(
        prompt=prompt,
        reference_image=reference_image,
        aspect_ratio=aspect_ratio,
        resolution=resolution,
        duration_seconds=duration_seconds,
        model=model,
        api_key=api_key,
        timeout_s=timeout_s,
    )

    operation_response = _poll_operation(
        operation_name=operation_name,
        api_key=api_key,
        timeout_s=timeout_s,
        poll_interval_s=_VEO_DEFAULT_POLL_INTERVAL_S,
    )

    video_uri = _extract_video_uri(operation_response)
    video_bytes = _download_video(
        video_uri=video_uri,
        api_key=api_key,
        timeout_s=timeout_s,
    )

    presigned_url = _upload_video_and_get_presigned_url(video_bytes)

    result: dict[str, Any] = {
        "type": "video_url",
        "video_url": {"url": presigned_url},
    }
    return json.dumps(result, ensure_ascii=False)
