"""omd/machinery/gemini.py.

Gemini image generation functions via api-bar gateway.
"""

from __future__ import annotations

import json
import logging
import os
from base64 import b64decode, b64encode
from typing import Any, Literal, TypedDict

import requests

from omd.machinery.image_utils import (
    _format_http_error_body_for_log,
    _read_image_source,
    _upload_image_and_get_presigned_url,
)
from omd.tools.data_models import ToolValidationError
from omd.utils.logging_utils import serialize_for_log, truncate_text

logger = logging.getLogger(__name__)

_GEMINI_DEFAULT_MODEL = "gemini-3-pro-image-preview"
_GEMINI_GENERATE_CONTENT_URL = (
    "https://api-bar.ru/route/gemini/models/generateContent"
)
_GEMINI_ALLOWED_MODALITIES: set[str] = {"TEXT", "IMAGE"}
_GEMINI_RESPONSE_MESSAGE_LIMIT = 4000
_GEMINI_NON_RETRYABLE_FINISH_REASONS: set[str] = {
    "BLOCKLIST",
    "IMAGE_SAFETY",
    "LANGUAGE",
    "MALFORMED_FUNCTION_CALL",
    "OTHER",
    "PROHIBITED_CONTENT",
    "RECITATION",
    "SAFETY",
    "SPII",
}


GeminiFailureKind = Literal[
    "missing_inline_image",
    "text_response_without_image",
    "prompt_blocked",
    "non_retryable_finish_reason",
    "retry_with_text_explanation",
]


class GeminiNonImageResponseSummary(TypedDict, total=False):
    """Compact summary extracted from a Gemini response without image data.

    :ivar payload_type: Name of the raw payload type, e.g. ``"dict"``.
    :ivar payload_keys: Top-level payload keys when the payload is a dictionary.
    :ivar prompt_feedback: Gemini ``promptFeedback`` object when present.
    :ivar candidate_count: Number of candidates returned by Gemini.
    :ivar finish_reasons: Candidate ``finishReason`` values found in the payload.
    :ivar text: Combined model text extracted from candidates.
    """

    payload_type: str
    payload_keys: list[str]
    prompt_feedback: dict[str, Any]
    candidate_count: int
    finish_reasons: list[str]
    text: str


class GeminiNonImageResponseDetails(TypedDict):
    """Structured classification of a successful Gemini response without an image.

    :ivar failure_kind: Machine-readable reason category used by the agent.
    :ivar should_retry_with_include_text: Whether the agent should retry once with
        ``include_text=True`` to obtain a model explanation.
    :ivar user_message: Human-readable explanation suitable for surfacing to the user.
    :ivar summary: Compact payload summary extracted for diagnostics.
    :ivar response_payload: Serialized raw payload truncated for logs and tool errors.
    """

    failure_kind: GeminiFailureKind
    should_retry_with_include_text: bool
    user_message: str
    summary: GeminiNonImageResponseSummary
    response_payload: str


class GeminiNonImageResponseError(ValueError):
    """Gemini returned a successful response without inline image data.

    :param message: Human-readable diagnostic message.
    :param details: Parsed diagnostic details from the Gemini payload.
    :type details: GeminiNonImageResponseDetails
    """

    def __init__(self, message: str, *, details: GeminiNonImageResponseDetails):
        """Initialize the exception with structured details.

        :param message: Human-readable diagnostic message.
        :param details: Parsed diagnostic details from the Gemini payload.
        """
        super().__init__(message)
        self.details = details


def _summarize_gemini_non_image_response(
    payload: object,
) -> GeminiNonImageResponseSummary:
    """Build a compact summary for Gemini responses without inline image data.

    :param payload: Decoded JSON response payload.
    :returns: Summary with the most useful diagnostic fields for the agent.
    """
    summary: GeminiNonImageResponseSummary = {"payload_type": type(payload).__name__}
    if not isinstance(payload, dict):
        return summary

    summary["payload_keys"] = sorted(payload)
    prompt_feedback = payload.get("promptFeedback")
    if isinstance(prompt_feedback, dict) and prompt_feedback:
        summary["prompt_feedback"] = prompt_feedback

    candidates = payload.get("candidates")
    if isinstance(candidates, list):
        summary["candidate_count"] = len(candidates)
        finish_reasons: list[str] = []
        for candidate in candidates:
            if not isinstance(candidate, dict):
                continue
            finish_reason = candidate.get("finishReason")
            if isinstance(finish_reason, str) and finish_reason.strip():
                finish_reasons.append(finish_reason)
        if finish_reasons:
            summary["finish_reasons"] = finish_reasons

    text = _extract_gemini_text(payload)
    if text is not None:
        summary["text"] = truncate_text(text, limit=1000)

    return summary


def _classify_gemini_non_image_response(
    *,
    payload: object,
    response_summary: GeminiNonImageResponseSummary,
    include_text: bool,
) -> GeminiNonImageResponseDetails:
    """Classify whether a non-image Gemini response is retryable.

    :param payload: Raw Gemini payload.
    :param response_summary: Compact summary built from ``payload``.
    :param include_text: Whether the original request already asked for text.
    :returns: Structured classification for agent-side recovery decisions.
    """
    text = response_summary.get("text")
    prompt_feedback = response_summary.get("prompt_feedback")
    finish_reasons = response_summary.get("finish_reasons")

    block_reason = None
    if isinstance(prompt_feedback, dict):
        raw_block_reason = prompt_feedback.get("blockReason")
        if isinstance(raw_block_reason, str) and raw_block_reason.strip():
            block_reason = raw_block_reason.strip()

    normalized_finish_reasons = [
        reason.strip()
        for reason in finish_reasons
        if isinstance(reason, str) and reason.strip()
    ] if isinstance(finish_reasons, list) else []

    user_message = "Gemini did not return an image."
    failure_kind: GeminiFailureKind = "missing_inline_image"
    should_retry_with_include_text = False

    if isinstance(text, str) and text.strip():
        failure_kind = "text_response_without_image"
        user_message = f"Gemini returned text instead of an image: {text.strip()}"
    elif block_reason is not None:
        failure_kind = "prompt_blocked"
        user_message = (
            "Gemini blocked the request before generation. "
            f"blockReason={block_reason}."
        )
    elif any(
        reason in _GEMINI_NON_RETRYABLE_FINISH_REASONS
        for reason in normalized_finish_reasons
    ):
        failure_kind = "non_retryable_finish_reason"
        user_message = (
            "Gemini refused or could not complete image generation. "
            f"finishReasons={normalized_finish_reasons}."
        )
    elif not include_text:
        failure_kind = "retry_with_text_explanation"
        should_retry_with_include_text = True
        user_message = (
            "Gemini did not return an image and did not explain why. "
            "Retry with include_text=true to capture the explanation."
        )

    return {
        "failure_kind": failure_kind,
        "should_retry_with_include_text": should_retry_with_include_text,
        "user_message": user_message,
        "summary": response_summary,
        "response_payload": serialize_for_log(
            payload,
            limit=_GEMINI_RESPONSE_MESSAGE_LIMIT,
            sort_keys=True,
        ),
    }


def _extract_gemini_inline_image_data(payload: object) -> str | None:
    """Extract the first inline image base64 from Gemini ``generateContent`` payload.

    :param payload: Decoded JSON response payload.
    :returns: Base64 image string if found, otherwise ``None``.
    """
    if not isinstance(payload, dict):
        return None

    candidates = payload.get("candidates")
    if not isinstance(candidates, list):
        return None

    for candidate in candidates:
        if not isinstance(candidate, dict):
            continue
        content = candidate.get("content")
        if not isinstance(content, dict):
            continue
        parts = content.get("parts")
        if not isinstance(parts, list):
            continue
        for part in parts:
            if not isinstance(part, dict):
                continue
            inline_data = part.get("inlineData")
            if not isinstance(inline_data, dict):
                continue
            data = inline_data.get("data")
            if isinstance(data, str) and data.strip():
                return data
    return None


def _extract_gemini_text(payload: object) -> str | None:
    """Extract text from Gemini ``generateContent`` payload when present.

    :param payload: Decoded JSON response payload.
    :returns: Combined text from response parts, or ``None`` if absent.
    """
    if not isinstance(payload, dict):
        return None

    candidates = payload.get("candidates")
    if not isinstance(candidates, list):
        return None

    text_parts: list[str] = []
    for candidate in candidates:
        if not isinstance(candidate, dict):
            continue
        content = candidate.get("content")
        if not isinstance(content, dict):
            continue
        parts = content.get("parts")
        if not isinstance(parts, list):
            continue
        for part in parts:
            if not isinstance(part, dict):
                continue
            text = part.get("text")
            if isinstance(text, str) and text.strip():
                text_parts.append(text.strip())

    if not text_parts:
        return None
    return "\n".join(text_parts)


def generate_image_gemini_validator(
    tool_arguments: dict[str, Any],
) -> dict[str, Any]:
    """Validate and normalize arguments for :func:`generate_image_gemini`.

    :param tool_arguments: Parsed tool arguments from the model.
    :returns: Validated and normalized arguments.
    :raises ToolValidationError: If arguments are invalid.
    """
    tool_name = "generate_image_gemini"
    allowed_keys = {
        "prompt",
        "style_reference_image",
        "model",
        "include_text",
        "timeout_s",
    }
    unknown_keys = sorted(set(tool_arguments) - allowed_keys)
    if unknown_keys:
        raise ToolValidationError(
            tool_name=tool_name,
            message=(
                f"Unknown argument(s): {unknown_keys}. "
                f"Allowed keys: {sorted(allowed_keys)}"
            ),
            tool_arguments=tool_arguments,
        )

    args: dict[str, Any] = dict(tool_arguments)

    prompt = args.get("prompt")
    if not isinstance(prompt, str) or not prompt.strip():
        raise ToolValidationError(
            tool_name=tool_name,
            message="prompt must be a non-empty string.",
            tool_arguments=tool_arguments,
        )
    args["prompt"] = prompt.strip()

    for key in ("style_reference_image", "model"):
        if key not in args:
            continue
        value = args[key]
        if value is None:
            continue
        if not isinstance(value, str):
            raise ToolValidationError(
                tool_name=tool_name,
                message=f"{key} must be a string or null, got {type(value).__name__}.",
                tool_arguments=tool_arguments,
            )
        stripped = value.strip()
        args[key] = stripped if stripped else None

    if (
        "include_text" in args
        and args["include_text"] is not None
        and not isinstance(args["include_text"], bool)
    ):
        raise ToolValidationError(
            tool_name=tool_name,
            message=(
                "include_text must be a boolean, "
                f"got {type(args['include_text']).__name__}."
            ),
            tool_arguments=tool_arguments,
            )

    if "timeout_s" in args and args["timeout_s"] is not None:
        timeout_s = args["timeout_s"]
        if not isinstance(timeout_s, (int, float)):
            raise ToolValidationError(
                tool_name=tool_name,
                message=f"timeout_s must be a number, got {type(timeout_s).__name__}.",
                tool_arguments=tool_arguments,
            )
        timeout_f = float(timeout_s)
        if timeout_f <= 0.0:
            raise ToolValidationError(
                tool_name=tool_name,
                message="timeout_s must be > 0.",
                tool_arguments=tool_arguments,
            )
        args["timeout_s"] = timeout_f

    return args


def generate_image_gemini(
    prompt: str,
    style_reference_image: str | None = None,
    model: str = _GEMINI_DEFAULT_MODEL,
    include_text: bool = False,
    timeout_s: float = 120.0,
) -> str:
    """Generate an image with Gemini, optionally guided by a reference image.

    Use this function when generation should be based on an existing image
    (reference-guided generation) plus text instructions. For pure text-to-image
    without any references, use ``omd.machinery.sd.generate_image``.

    The function sends a request to ``/route/gemini/models/generateContent``
    through api-bar, extracts the first inline image from the response, uploads
    it to MinIO, and returns an OpenAI-compatible ``image_url`` JSON payload.

    ``style_reference_image`` accepts one reference source per call:

    - local file path
    - ``http(s)`` URL
    - base64 data URL (``data:<mime>;base64,...``)

    :param prompt: Text instructions for what to generate.
    :param style_reference_image: Optional reference image for style/composition.
    :param model: Gemini model name exposed by api-bar route.
    :param include_text: Whether to request and return text alongside the image.
    :param timeout_s: HTTP timeout in seconds.
    :returns: JSON string ``{"type":"image_url","image_url":{"url":"..."}}``.
    :raises requests.HTTPError: If api-bar returns a non-200 response.
    :raises ValueError: If Gemini returns a successful response without image data.
    :raises KeyError: If neither ``API_BAR_TOKEN`` nor ``MODEL_API_TOKEN`` is set.
    """
    try:
        api_key = os.environ["API_BAR_TOKEN"]
    except KeyError:
        api_key = os.environ["MODEL_API_TOKEN"]

    response_modalities = ["IMAGE", "TEXT"] if include_text else ["IMAGE"]
    if any(
        modality not in _GEMINI_ALLOWED_MODALITIES for modality in response_modalities
    ):
        raise ValueError(
            f"Unsupported response modality. Allowed: {sorted(_GEMINI_ALLOWED_MODALITIES)}"
        )

    user_parts: list[dict[str, Any]] = [{"text": prompt}]
    if style_reference_image is not None:
        _, image_bytes, mime_type = _read_image_source(
            style_reference_image, timeout_s=timeout_s,
        )
        user_parts.append(
            {
                "inlineData": {
                    "mimeType": mime_type,
                    "data": b64encode(image_bytes).decode("ascii"),
                }
            }
        )

    payload: dict[str, Any] = {
        "model": model,
        "contents": [{"role": "user", "parts": user_parts}],
        "generationConfig": {"responseModalities": response_modalities},
    }

    response = requests.post(
        _GEMINI_GENERATE_CONTENT_URL,
        headers={
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
        },
        json=payload,
        timeout=timeout_s,
    )
    if response.status_code != 200:
        logger.error(
            "Gemini generateContent request failed: status=%s url=%s error_body=%s",
            response.status_code,
            response.url,
            _format_http_error_body_for_log(response),
        )
        response.raise_for_status()

    response_payload = response.json()
    image_base64 = _extract_gemini_inline_image_data(response_payload)
    if image_base64 is None:
        response_summary = _summarize_gemini_non_image_response(response_payload)
        error_details_payload = _classify_gemini_non_image_response(
            payload=response_payload,
            response_summary=response_summary,
            include_text=include_text,
        )
        error_details = json.dumps(
            error_details_payload,
            ensure_ascii=False,
            default=str,
            sort_keys=True,
        )
        logger.error(
            "Gemini generateContent returned no inline image data. "
            "model=%s requested_modalities=%s summary=%s",
            model,
            response_modalities,
            json.dumps(
                response_summary, ensure_ascii=False, default=str, sort_keys=True,
            ),
        )
        raise GeminiNonImageResponseError(
            "Gemini returned 200 OK but no inline image data. "
            f"details={error_details}",
            details=error_details_payload,
        )

    image_bytes = b64decode(image_base64)
    presigned_url = _upload_image_and_get_presigned_url(
        image_bytes, output_format="png",
    )

    result: dict[str, Any] = {
        "type": "image_url",
        "image_url": {"url": presigned_url},
    }
    if include_text:
        text = _extract_gemini_text(response_payload)
        if text is not None:
            result["text"] = text
    return json.dumps(result, ensure_ascii=False)
