"""omd/machinery/image_utils.py.

Shared image helpers for machinery tools.
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
import re
from base64 import b64decode
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

import requests

logger = logging.getLogger(__name__)

_ERROR_BODY_MAX_CHARS = 2000
_MIME_TYPES: dict[str, str] = {
    ".png": "image/png",
    ".jpg": "image/jpeg",
    ".jpeg": "image/jpeg",
    ".webp": "image/webp",
}
_DATA_URL_RE = re.compile(r"^data:(?P<mime>[^;,]+);base64,(?P<b64>.+)$", re.DOTALL)
_DEFAULT_MINIO_PRESIGNED_URL_EXPIRES_IN_S = 3600


def _format_http_error_body_for_log(response: requests.Response) -> str:
    """Format response body for logging when an HTTP error occurs.

    :param response: Response object associated with the HTTP error.
    :returns: Short, log-friendly representation of the response body.
    """
    content_type = (response.headers.get("Content-Type") or "").lower()

    body: str
    if "application/json" in content_type:
        try:
            payload = response.json()
        except ValueError:
            body = response.text
        else:
            try:
                body = json.dumps(payload, ensure_ascii=False, sort_keys=True)
            except TypeError:
                body = str(payload)
    else:
        body = response.text

    body = body.strip()
    if len(body) <= _ERROR_BODY_MAX_CHARS:
        return body

    truncated = body[:_ERROR_BODY_MAX_CHARS].rstrip()
    return f"{truncated}… (truncated, {len(body)} chars total)"


def _infer_image_extension(content: bytes) -> str | None:
    """Infer image extension from file signature bytes.

    :param content: Raw file bytes.
    :returns: Inferred extension (e.g. ``".png"``) or ``None``.
    """
    if content.startswith(b"\x89PNG\r\n\x1a\n"):
        return ".png"
    if content.startswith(b"\xff\xd8\xff"):
        return ".jpg"
    if len(content) >= 12 and content[0:4] == b"RIFF" and content[8:12] == b"WEBP":
        return ".webp"
    return None


def _read_image(path: str) -> tuple[str, bytes, str]:
    """Read image file and return a multipart-ready tuple.

    :param path: Path to image file.
    :returns: Tuple of ``(filename, content, mime_type)``.
    :raises ValueError: If file extension/content is unsupported.
    :raises FileNotFoundError: If file does not exist.
    """
    file_path = Path(path)
    content = file_path.read_bytes()
    ext = file_path.suffix.lower()
    if ext in _MIME_TYPES:
        return file_path.name, content, _MIME_TYPES[ext]

    inferred_ext = _infer_image_extension(content)
    if inferred_ext is None:
        raise ValueError(
            f"Unsupported image format: {ext or '(no extension)'}. "
            f"Supported: {list(_MIME_TYPES.keys())}"
        )

    inferred_mime = _MIME_TYPES[inferred_ext]
    filename = f"{file_path.stem}{inferred_ext}" if ext else f"{file_path.name}{inferred_ext}"
    return filename, content, inferred_mime


def _looks_like_url(value: str) -> bool:
    """Return True if ``value`` looks like an ``http(s)`` URL.

    :param value: Value to check.
    :returns: True for ``http://`` and ``https://`` values.
    """
    value = value.strip()
    return value.startswith("http://") or value.startswith("https://")


def _read_image_data_url(data_url: str) -> tuple[str, bytes, str]:
    """Decode base64 ``data:`` URL into multipart-ready tuple.

    :param data_url: URL in form ``data:<mime>;base64,<payload>``.
    :returns: Tuple of ``(filename, content, mime_type)``.
    :raises ValueError: If URL is malformed or payload cannot be decoded.
    """
    match = _DATA_URL_RE.match(data_url.strip())
    if match is None:
        raise ValueError("Invalid data URL (expected data:<mime>;base64,<payload>)")

    mime = match.group("mime").strip().lower()
    payload = match.group("b64").strip()
    try:
        content = b64decode(payload, validate=False)
    except Exception as exc:
        raise ValueError("Failed to decode base64 data URL payload") from exc

    ext_by_mime = {v: k for k, v in _MIME_TYPES.items()}
    ext = ext_by_mime.get(mime)
    if ext is None:
        ext = _infer_image_extension(content) or ".bin"
    return f"inline{ext}", content, mime if mime else "application/octet-stream"


def _read_image_source(source: str, *, timeout_s: float) -> tuple[str, bytes, str]:
    """Read image from local path, ``http(s)`` URL, or base64 data URL.

    :param source: Image source string.
    :param timeout_s: HTTP timeout for URL sources.
    :returns: Tuple of ``(filename, content_bytes, mime_type)``.
    :raises requests.HTTPError: If URL download fails.
    :raises ValueError: If source is empty or unsupported.
    :raises FileNotFoundError: If local file path does not exist.
    """
    src = source.strip()
    if not src:
        raise ValueError("Empty image source")

    if src.startswith("data:"):
        return _read_image_data_url(src)

    if _looks_like_url(src):
        response = requests.get(src, timeout=min(30.0, max(1.0, timeout_s)))
        response.raise_for_status()
        content = response.content
        if not content:
            raise ValueError("Downloaded image is empty")

        content_type = (
            (response.headers.get("Content-Type") or "").split(";", 1)[0].strip().lower()
        )
        ext = _infer_image_extension(content)
        if ext is None:
            raise ValueError("Unsupported image format from URL (could not infer type)")

        mime = (
            content_type
            if content_type.startswith("image/")
            else _MIME_TYPES.get(ext, "application/octet-stream")
        )
        return f"remote{ext}", content, mime

    return _read_image(src)


def _run_coro_sync(coro: object) -> object:
    """Run awaitable from sync context safely.

    :param coro: Awaitable object.
    :returns: Awaited result.
    """
    try:
        asyncio.get_running_loop()
    except RuntimeError:
        return asyncio.run(coro)

    with ThreadPoolExecutor(max_workers=1) as pool:
        future = pool.submit(asyncio.run, coro)
        return future.result()


def _infer_output_mime_type(output_format: str) -> str:
    """Infer MIME type from output format.

    :param output_format: Output format string.
    :returns: MIME type.
    """
    normalized = output_format.strip().lower()
    if normalized == "png":
        return "image/png"
    if normalized == "jpeg":
        return "image/jpeg"
    if normalized == "webp":
        return "image/webp"
    return "application/octet-stream"


def _upload_image_and_get_presigned_url(image_bytes: bytes, *, output_format: str) -> str:
    """Upload image bytes to MinIO and return a presigned URL.

    :param image_bytes: Raw image bytes.
    :param output_format: Output format (``png``, ``jpeg``, ``webp``).
    :returns: Presigned URL to access the image.
    :raises KeyError: If required MinIO env vars are missing.
    :raises RuntimeError: If ``minio_client`` is unavailable.
    """
    try:
        from minio_client import MinioClient, MinioConfig  # type: ignore[import-untyped]
    except ImportError as exc:
        raise RuntimeError(
            "minio_client package is required to publish generated images as URLs."
        ) from exc

    expires_in_s = int(
        os.environ.get(
            "MINIO_PRESIGNED_URL_EXPIRES_IN",
            str(_DEFAULT_MINIO_PRESIGNED_URL_EXPIRES_IN_S),
        )
    )

    config = MinioConfig.from_env()
    minio_client = MinioClient(config)
    mime_type = _infer_output_mime_type(output_format)
    file_name = f"stability_result.{output_format}"

    async def _upload_and_presign() -> str:
        await minio_client.ensure_bucket_exists()
        internal_url = await minio_client.upload_file(
            prefix="stability",
            file_bytes=image_bytes,
            file_name=file_name,
            content_type=mime_type,
        )
        object_key = minio_client.extract_object_key_from_url(internal_url)
        if object_key is None:
            logger.warning(
                "Could not extract object key from MinIO URL. url=%s", internal_url,
            )
            return internal_url
        return await minio_client.generate_presigned_url(
            object_key=object_key,
            expires_in=expires_in_s,
        )

    return str(_run_coro_sync(_upload_and_presign()))
