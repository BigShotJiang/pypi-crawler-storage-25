"""omd/machinery/sd.py.

Stability AI image generation functions.
"""

from __future__ import annotations

import json
import logging
import os
import time
from base64 import b64decode
from typing import Any, Literal
from urllib.parse import urljoin, urlparse

import requests

from omd.machinery.image_utils import (
    _format_http_error_body_for_log,
    _looks_like_url,
    _read_image,
    _read_image_data_url,
    _read_image_source,
    _upload_image_and_get_presigned_url,
)
from omd.tools.data_models import ToolValidationError

logger = logging.getLogger(__name__)

_DEFAULT_IMAGE_TO_IMAGE_STRENGTH = 0.55

_ALLOWED_OUTPUT_FORMATS: set[str] = {"png", "jpeg", "webp"}
_ALLOWED_LIGHT_SOURCE_DIRECTIONS: set[str] = {"above", "below", "left", "right"}


def _stability_base() -> str:
    """Return the Stability AI base URL from environment.

    :returns: Base URL string (no trailing slash).
    :raises KeyError: If ``STABILITY_BASE_URL`` is not set.
    """
    return urlparse(os.environ["STABILITY_BASE_URL"]).geturl().rstrip("/")


def _stability_generate_url() -> str:
    """Return the Stability Ultra generation endpoint URL."""
    return f"{_stability_base()}/stable-image/generate/ultra"


def _stability_replace_bg_url() -> str:
    """Return the Stability background replacement endpoint URL."""
    return f"{_stability_base()}/stable-image/edit/replace-background-and-relight"


def _stability_results_url() -> str:
    """Return the Stability results polling base URL."""
    return f"{_stability_base()}/results"


def _stability_result_url(gen_id: str) -> str:
    """Build Stability results URL for a generation id.

    :param gen_id: Generation identifier returned by Stability async endpoints.
    :returns: Full results URL.
    """
    return urljoin(f"{_stability_results_url().rstrip('/')}/", gen_id)


def _extract_status(payload: object) -> str | None:
    """Extract status string from a Stability results payload.

    :param payload: JSON payload decoded from Stability results endpoint.
    :returns: Status string if present, otherwise ``None``.
    """
    if not isinstance(payload, dict):
        return None
    value = payload.get("status")
    return value if isinstance(value, str) and value.strip() else None


def _poll_stability_async_result(
    gen_id: str,
    output_format: str,
    timeout_s: float,
    poll_interval_s: float = 2.0,
) -> bytes:
    """Poll Stability results endpoint until the image is ready.

    :param gen_id: Generation identifier from Stability async endpoint.
    :param output_format: Expected image format (``"png"``, ``"jpeg"``, ``"webp"``).
    :param timeout_s: Total timeout for polling (seconds).
    :param poll_interval_s: Delay between polling attempts in seconds.
    :returns: Image bytes when ready.
    :raises TimeoutError: If the result is not ready within ``timeout_s``.
    :raises requests.HTTPError: If the API returns an error status.
    :raises RuntimeError: If the result becomes terminal but no image is available.
    """
    api_key = os.environ["STABILITY_API_KEY"]
    result_url = _stability_result_url(gen_id)
    deadline = time.monotonic() + timeout_s

    headers_base = {"Authorization": f"Bearer {api_key}"}
    last_status: str | None = None

    while True:
        remaining_s = deadline - time.monotonic()
        if remaining_s <= 0:
            raise TimeoutError(f"Stability async result timed out. gen_id={gen_id}")

        response = requests.get(
            result_url,
            headers={**headers_base, "Accept": "application/json"},
            timeout=min(30.0, max(1.0, remaining_s)),
        )

        if response.status_code == 202:
            try:
                payload = response.json()
            except ValueError:
                payload = None
            status = payload.get("status")
            if isinstance(status, str) and status != last_status:
                logger.info(
                    "Stability async status changed. gen_id=%s status=%s",
                    gen_id, status,
                )
                last_status = status
            time.sleep(min(poll_interval_s, max(0.0, remaining_s)))
            continue

        if response.status_code == 200:
            content_type = (
                (response.headers.get("Content-Type") or "").split(";", 1)[0].strip().lower()
            )
            if content_type.startswith("image/"):
                return response.content

            payload = response.json()
            status = payload.get("status")
            if isinstance(status, str) and status != last_status:
                logger.info(
                    "Stability async status changed. gen_id=%s status=%s",
                    gen_id, status,
                )
                last_status = status

            base64_image = payload.get("result")
            if isinstance(base64_image, str) and base64_image:
                return b64decode(base64_image)

            response = requests.get(
                result_url,
                headers={**headers_base, "Accept": f"image/{output_format}"},
                timeout=min(30.0, max(1.0, remaining_s)),
            )
            if response.status_code == 200:
                return response.content
            if response.status_code == 202:
                time.sleep(min(poll_interval_s, max(0.0, remaining_s)))
                continue

            response.raise_for_status()

        response.raise_for_status()


def generate_image(
    prompt: str,
    image_path: str | None = None,
    negative_prompt: str | None = None,
    aspect_ratio: (
        Literal["1:1", "16:9", "21:9", "2:3", "3:2", "4:5", "5:4", "9:16", "9:21"] | None
    ) = None,
    seed: int | None = None,
    output_format: Literal["png", "jpeg", "webp"] = "png",
    strength: float | None = None,
    timeout_s: float = 60.0,
) -> str:
    """Generate an image using Stability AI Stable Image Ultra API.

    This tool invokes Stability AI ``stable-image/generate/ultra`` endpoint with a
    ``multipart/form-data`` request. The only required field is ``prompt``.

    The request may also include:

    - ``image``: starting image for image-to-image generation.
    - ``strength``: controls how much *influence* the input image has on the output.
    - ``aspect_ratio``: output aspect ratio (mainly for text-to-image).
    - ``negative_prompt``, ``seed``, ``output_format``.

    The API supports two kinds of responses depending on ``Accept``:

    - ``image/*``: raw image bytes (in the chosen ``output_format``).
    - ``application/json``: base64-encoded image payload and/or an async generation id.

    This implementation accepts ``image/*`` and also handles common JSON/async shapes
    returned by gateways.

    **When to use this function:**

    - User explicitly asks to create, generate, or draw an image from a description.
    - User provides a reference image and asks to modify, transform, or stylize it.
    - User needs visual content: illustrations, concept art, mockups, thumbnails.
    - Task requires photorealistic or artistic image generation (not diagrams or charts).

    **When NOT to use:**

    - User asks to edit specific regions of an image (use inpainting tools instead).
    - User needs to upscale, crop, or resize an existing image (use image editing tools).
    - User asks for structured graphics: charts, diagrams, schemas (use plotting libraries).
    - User wants to extract information from an image (use vision/OCR models).

    **How to form the prompt:**

    - **Prompts must be in English** — the model works best with English text.
    - Be specific and descriptive: include subject, style, lighting, mood, colors.
    - Good: ``"A cozy coffee shop interior, warm lighting, watercolor style, autumn mood"``
    - Acceptable: ``"coffee shop"`` — proceed with a reasonable interpretation.
    - Use ``negative_prompt`` to exclude unwanted elements: ``"blurry, low quality, text"``.
    - **Do NOT ask the user for clarification** unless a required input is missing
      (e.g., image-to-image was requested but no image was provided).

    **Choosing aspect_ratio (text-to-image only):**

    - ``"1:1"`` — square, avatars, icons, social media posts.
    - ``"16:9"`` — landscape, desktop wallpapers, presentations, video thumbnails.
    - ``"9:16"`` — portrait, mobile wallpapers, stories, vertical banners.
    - ``"4:5"`` — Instagram portrait posts.
    - ``"3:2"`` — classic photo aspect ratio.

    **Choosing strength (image-to-image only):**

    ``strength`` controls how much the input image constrains the result:

    - Lower (e.g., ``0.2-0.4``): stronger changes driven by the prompt.
    - Medium (e.g., ``0.45-0.65``): balanced edit (recommended default).
    - Higher (e.g., ``0.7-0.9``): subtle changes, preserve more of the input image.

    :param prompt: Text description of the desired image.
    :param image_path: Optional path to input image for image-to-image mode.
        Supported formats: JPEG, PNG, WEBP. This may also be an http(s) URL
        (e.g., a MinIO presigned URL) or a base64 data URL.
    :param negative_prompt: Text specifying elements to exclude from the image.
    :param aspect_ratio: Desired width-to-height ratio of the output image.
        Only applicable in text-to-image mode (when ``image_path`` is not provided).
    :param seed: Integer seed for reproducibility.
    :param output_format: Format of the output image (``"png"``, ``"jpeg"``, ``"webp"``).
    :param strength: Image-to-image strength in ``[0.0, 1.0]``. Higher values preserve more of
        the input image; lower values allow stronger edits guided by ``prompt``.
    :param timeout_s: Total timeout in seconds for the operation. If the endpoint responds
        asynchronously, this value is also used as the polling timeout.
    :returns: OpenAI-compatible JSON string with ``image_url`` pointing to the generated image.
        The payload has the shape ``{"type":"image_url","image_url":{"url":"..."}}``.
    :raises requests.HTTPError: If the API request fails.
    :raises FileNotFoundError: If ``image_path`` does not exist.
    :raises ValueError: If image format is not supported.

    Example::

        # Text-to-image (tool payload)
        tool_payload_json = generate_image("A serene mountain landscape at sunrise")

        # Image-to-image
        result = generate_image(
            prompt="Transform into a watercolor painting",
            image_path="/path/to/input.png",
            strength=0.5,
        )
    """
    api_key = os.environ["STABILITY_API_KEY"]

    headers = {
        "Authorization": f"Bearer {api_key}",
        "Accept": f"image/{output_format}",
    }

    data: dict[str, str | int | float] = {
        "prompt": prompt,
        "output_format": output_format,
    }

    if image_path is not None:
        data["strength"] = (
            float(strength) if strength is not None else _DEFAULT_IMAGE_TO_IMAGE_STRENGTH
        )
    else:
        if aspect_ratio is not None:
            data["aspect_ratio"] = aspect_ratio

    if negative_prompt is not None:
        data["negative_prompt"] = negative_prompt

    if seed is not None:
        data["seed"] = seed

    logger.debug(
        "Sending request to Stability Ultra endpoint via configured gateway, mode=%s",
        "image-to-image" if image_path else "text-to-image",
    )

    multipart_files: dict[str, tuple[object, ...]] = {
        key: (None, str(value)) for key, value in data.items()
    }
    if image_path is not None:
        multipart_files["image"] = _read_image_source(image_path, timeout_s=timeout_s)

    response = requests.post(
        _stability_generate_url(),
        headers=headers,
        files=multipart_files,
        timeout=timeout_s,
    )
    if response.status_code not in (200, 202):
        logger.error(
            "Stability Ultra request failed: status=%s url=%s error_body=%s",
            response.status_code,
            response.url,
            _format_http_error_body_for_log(response),
        )
        response.raise_for_status()

    content_type = (
        (response.headers.get("Content-Type") or "").split(";", 1)[0].strip().lower()
    )
    image_bytes: bytes | None = None

    if response.status_code == 200 and content_type.startswith("image/"):
        image_bytes = response.content
    else:
        try:
            payload = response.json()
        except ValueError as exc:
            logger.error(
                "Stability Ultra returned non-image response without JSON payload. "
                "status=%s content_type=%s body_len=%d",
                response.status_code,
                content_type,
                len(response.content),
            )
            raise RuntimeError(
                "Stability Ultra response is not an image and not JSON."
            ) from exc

        gen_id = None
        if isinstance(payload, dict):
            gen_id = payload.get("id") or payload.get("generation_id")

        if isinstance(gen_id, str) and gen_id.strip():
            image_bytes = _poll_stability_async_result(
                gen_id=gen_id,
                output_format=output_format,
                timeout_s=timeout_s,
            )
        elif (
            isinstance(payload, dict)
            and isinstance(payload.get("result"), str)
            and payload["result"].strip()
        ):
            image_bytes = b64decode(payload["result"])
        elif (
            isinstance(payload, dict)
            and isinstance(payload.get("image"), str)
            and payload["image"].strip()
        ):
            image_bytes = b64decode(payload["image"])
        elif (
            isinstance(payload, dict)
            and isinstance(payload.get("artifacts"), list)
            and payload["artifacts"]
            and isinstance(payload["artifacts"][0], dict)
            and isinstance(payload["artifacts"][0].get("base64"), str)
        ):
            image_bytes = b64decode(payload["artifacts"][0]["base64"])
        else:
            raise RuntimeError(
                "Stability Ultra response JSON does not contain an image. "
                f"keys={list(payload) if isinstance(payload, dict) else type(payload)}"
            )

    presigned_url = _upload_image_and_get_presigned_url(
        image_bytes, output_format=output_format,
    )
    return json.dumps(
        {"type": "image_url", "image_url": {"url": presigned_url}}, ensure_ascii=False,
    )


def replace_background_validator(tool_arguments: dict[str, Any]) -> dict[str, Any]:
    """Validate and normalize arguments for :func:`replace_background`.

    This validator enforces API constraints for the Stability endpoint
    ``/v2beta/stable-image/edit/replace-background-and-relight``:

    - At least one of ``background_prompt`` or ``background_reference_path``
      must be provided.
    - At least one of ``subject_image_path`` or ``subject_image_url`` must
      be provided.
    - ``output_format`` must be one of: ``png``, ``jpeg``, ``webp``.
    - The range for ``preserve_original_subject``, ``original_background_depth``,
      and ``light_source_strength`` (when used) is 0.0--1.0.
    - ``light_source_strength`` only applies when relighting is configured via
      ``light_reference_path`` or ``light_source_direction``.

    :param tool_arguments: Parsed tool arguments from the model.
    :returns: Validated/normalized arguments.
    :raises ToolValidationError: If arguments are invalid.
    """
    tool_name = "replace_background"

    allowed_keys = {
        "subject_image_path",
        "subject_image_url",
        "background_prompt",
        "background_reference_path",
        "foreground_prompt",
        "preserve_original_subject",
        "original_background_depth",
        "light_source_direction",
        "light_reference_path",
        "light_source_strength",
        "seed",
        "output_format",
        "timeout_s",
    }

    unknown_keys = sorted(set(tool_arguments) - allowed_keys)
    if unknown_keys:
        raise ToolValidationError(
            tool_name=tool_name,
            message=(
                f"Unknown argument(s): {unknown_keys}. "
                f"Allowed keys: {sorted(allowed_keys)}"
            ),
            tool_arguments=tool_arguments,
        )

    args: dict[str, Any] = dict(tool_arguments)

    for key in (
        "subject_image_path",
        "subject_image_url",
        "background_prompt",
        "background_reference_path",
        "foreground_prompt",
        "light_reference_path",
        "light_source_direction",
        "output_format",
    ):
        if key not in args:
            continue
        value = args[key]
        if value is None:
            continue
        if not isinstance(value, str):
            raise ToolValidationError(
                tool_name=tool_name,
                message=f"{key} must be a string or null, got {type(value).__name__}.",
                tool_arguments=tool_arguments,
            )
        stripped = value.strip()
        args[key] = stripped if stripped else None

    subject_image_path = args.get("subject_image_path")
    subject_image_url = args.get("subject_image_url")
    if not subject_image_path and not subject_image_url:
        raise ToolValidationError(
            tool_name=tool_name,
            message="Either subject_image_path or subject_image_url must be provided.",
            tool_arguments=tool_arguments,
        )

    background_prompt = args.get("background_prompt")
    background_reference_path = args.get("background_reference_path")
    if not background_prompt and not background_reference_path:
        raise ToolValidationError(
            tool_name=tool_name,
            message=(
                "Either background_prompt or background_reference_path must be provided."
            ),
            tool_arguments=tool_arguments,
        )

    output_format = args.get("output_format")
    if output_format is not None:
        if not isinstance(output_format, str):
            raise ToolValidationError(
                tool_name=tool_name,
                message=(
                    f"output_format must be a string, got {type(output_format).__name__}."
                ),
                tool_arguments=tool_arguments,
            )
        normalized = output_format.strip().lower()
        if normalized not in _ALLOWED_OUTPUT_FORMATS:
            raise ToolValidationError(
                tool_name=tool_name,
                message=(
                    f"output_format must be one of {sorted(_ALLOWED_OUTPUT_FORMATS)}, "
                    f"got {output_format!r}."
                ),
                tool_arguments=tool_arguments,
            )
        args["output_format"] = normalized

    for key in ("preserve_original_subject", "original_background_depth"):
        if key not in args or args[key] is None:
            continue
        value = args[key]
        if not isinstance(value, (int, float)):
            raise ToolValidationError(
                tool_name=tool_name,
                message=(
                    f"{key} must be a number in range 0.0-1.0, "
                    f"got {type(value).__name__}."
                ),
                tool_arguments=tool_arguments,
            )
        value_f = float(value)
        if not (0.0 <= value_f <= 1.0):
            raise ToolValidationError(
                tool_name=tool_name,
                message=f"{key} must be in range 0.0-1.0, got {value_f}.",
                tool_arguments=tool_arguments,
            )
        args[key] = value_f

    if "seed" in args and args["seed"] is not None:
        seed = args["seed"]
        if not isinstance(seed, int):
            raise ToolValidationError(
                tool_name=tool_name,
                message=f"seed must be an integer, got {type(seed).__name__}.",
                tool_arguments=tool_arguments,
            )
        if seed < 0:
            raise ToolValidationError(
                tool_name=tool_name,
                message="seed must be >= 0.",
                tool_arguments=tool_arguments,
            )

    if "timeout_s" in args and args["timeout_s"] is not None:
        timeout_s = args["timeout_s"]
        if not isinstance(timeout_s, (int, float)):
            raise ToolValidationError(
                tool_name=tool_name,
                message=f"timeout_s must be a number, got {type(timeout_s).__name__}.",
                tool_arguments=tool_arguments,
            )
        timeout_f = float(timeout_s)
        if timeout_f <= 0.0:
            raise ToolValidationError(
                tool_name=tool_name,
                message="timeout_s must be > 0.",
                tool_arguments=tool_arguments,
            )
        args["timeout_s"] = timeout_f

    light_reference_path = args.get("light_reference_path")
    light_source_direction = args.get("light_source_direction")
    if isinstance(light_source_direction, str):
        normalized_dir = light_source_direction.strip().lower()
        if normalized_dir in ("none", ""):
            light_source_direction = None
        elif normalized_dir not in _ALLOWED_LIGHT_SOURCE_DIRECTIONS:
            raise ToolValidationError(
                tool_name=tool_name,
                message=(
                    "light_source_direction must be one of "
                    f"{sorted(_ALLOWED_LIGHT_SOURCE_DIRECTIONS)} or null."
                ),
                tool_arguments=tool_arguments,
            )
        else:
            light_source_direction = normalized_dir
        args["light_source_direction"] = light_source_direction

    if light_reference_path:
        args["light_source_direction"] = None
        light_source_direction = None

    if "light_source_strength" in args and args["light_source_strength"] is not None:
        strength = args["light_source_strength"]
        if not isinstance(strength, (int, float)):
            raise ToolValidationError(
                tool_name=tool_name,
                message=(
                    "light_source_strength must be a number in range 0.0-1.0, "
                    f"got {type(strength).__name__}."
                ),
                tool_arguments=tool_arguments,
            )
        strength_f = float(strength)
        if not (0.0 <= strength_f <= 1.0):
            raise ToolValidationError(
                tool_name=tool_name,
                message=(
                    f"light_source_strength must be in range 0.0-1.0, got {strength_f}."
                ),
                tool_arguments=tool_arguments,
            )
        args["light_source_strength"] = strength_f

        if not light_reference_path and not light_source_direction:
            if abs(strength_f - 0.3) < 1e-9:
                args.pop("light_source_strength", None)
            elif strength_f != 0.0:
                raise ToolValidationError(
                    tool_name=tool_name,
                    message=(
                        "light_source_strength requires `light_reference_path` or "
                        "`light_source_direction` for use."
                    ),
                    tool_arguments=tool_arguments,
                )
            else:
                args.pop("light_source_strength", None)

    return args


def replace_background(
    subject_image_path: str | None = None,
    subject_image_url: str | None = None,
    background_prompt: str | None = None,
    background_reference_path: str | None = None,
    foreground_prompt: str | None = None,
    preserve_original_subject: float = 0.85,
    original_background_depth: float = 0.5,
    light_source_direction: Literal["above", "below", "left", "right"] | None = None,
    light_reference_path: str | None = None,
    light_source_strength: float = 0.3,
    seed: int | None = None,
    output_format: Literal["png", "jpeg", "webp"] = "png",
    timeout_s: float = 60.0,
) -> str:
    """Replace the background of an image while keeping the subject.

    :param subject_image_path: Path to image containing the subject to extract.
    :param subject_image_url: Optional URL to the subject image.
    :param background_prompt: Text description of the desired new background.
    :param background_reference_path: Optional path to image to use as background.
    :param foreground_prompt: Optional text to guide foreground/subject enhancement.
    :param preserve_original_subject: Degree to preserve original subject (0.0--1.0).
    :param original_background_depth: Depth factor of the original background (0.0--1.0).
    :param light_source_direction: Direction of the light source for relighting.
    :param light_reference_path: Optional path to image to use as lighting reference.
    :param light_source_strength: Strength of the light source effect (0.0--1.0).
    :param seed: Integer seed for reproducibility.
    :param output_format: Format of the output image.
    :param timeout_s: Request timeout in seconds.
    :returns: OpenAI-compatible JSON string with ``image_url``.
    :raises requests.HTTPError: If the API request fails.
    :raises FileNotFoundError: If any image path does not exist.
    :raises ValueError: If required arguments are missing.
    """
    if background_prompt is None and background_reference_path is None:
        raise ValueError(
            "Either background_prompt or background_reference_path must be provided"
        )

    if subject_image_path is None and subject_image_url is None:
        raise ValueError("Either subject_image_path or subject_image_url must be provided")

    if subject_image_url is not None and subject_image_url.strip().startswith("data:"):
        subject_image_path = ""

    if (
        subject_image_path is not None
        and subject_image_url is None
        and _looks_like_url(subject_image_path)
    ):
        subject_image_url = subject_image_path
        subject_image_path = ""

    api_key = os.environ["STABILITY_API_KEY"]

    headers = {
        "Authorization": f"Bearer {api_key}",
        "Accept": f"image/{output_format}",
    }

    data: dict[str, str | int | float] = {
        "output_format": output_format,
        "preserve_original_subject": preserve_original_subject,
        "original_background_depth": original_background_depth,
    }

    files: list[tuple[str, tuple[str, bytes, str] | tuple[None, str]]] = []
    if subject_image_path and subject_image_path.strip().startswith("data:"):
        files.append(("subject_image", _read_image_data_url(subject_image_path)))
    elif subject_image_path:
        files.append(("subject_image", _read_image(subject_image_path)))
    elif subject_image_url is not None and subject_image_url.strip().startswith("data:"):
        files.append(("subject_image", _read_image_data_url(subject_image_url)))
    elif subject_image_url is not None:
        files.append(("subject_image_url", (None, subject_image_url)))
    else:
        raise FileNotFoundError(
            "Subject image not found. Provide a valid local file path accessible to the "
            "worker, or pass a public URL via subject_image_url."
        )

    if background_prompt is not None:
        data["background_prompt"] = background_prompt

    if foreground_prompt is not None:
        data["foreground_prompt"] = foreground_prompt

    if seed is not None:
        data["seed"] = seed

    if background_reference_path is not None:
        if background_reference_path.strip().startswith("data:"):
            files.append(
                ("background_reference", _read_image_data_url(background_reference_path))
            )
        else:
            files.append(("background_reference", _read_image(background_reference_path)))

    if light_reference_path is not None:
        if light_reference_path.strip().startswith("data:"):
            files.append(("light_reference", _read_image_data_url(light_reference_path)))
        else:
            files.append(("light_reference", _read_image(light_reference_path)))

    if light_source_direction is not None or light_reference_path is not None:
        data["light_source_strength"] = light_source_strength
        if light_reference_path is None and light_source_direction is not None:
            data["light_source_direction"] = light_source_direction

    logger.debug(
        "Sending request to Stability Replace Background endpoint via configured "
        "gateway, has_bg_ref=%s, has_light_ref=%s",
        background_reference_path is not None,
        light_reference_path is not None,
    )

    response = requests.post(
        _stability_replace_bg_url(),
        headers=headers,
        data=data,
        files=files,
        timeout=timeout_s,
    )
    if response.status_code == 200 and (
        (response.headers.get("Content-Type") or "")
        .split(";", 1)[0]
        .strip()
        .lower()
        .startswith("image/")
    ):
        logger.debug(
            "Background replaced successfully (sync), size=%d bytes",
            len(response.content),
        )
        presigned_url = _upload_image_and_get_presigned_url(
            response.content, output_format=output_format,
        )
        return json.dumps(
            {"type": "image_url", "image_url": {"url": presigned_url}}, ensure_ascii=False,
        )

    if response.status_code not in (200, 202):
        logger.error(
            "Stability Replace Background request failed: status=%s url=%s error_body=%s",
            response.status_code,
            response.url,
            _format_http_error_body_for_log(response),
        )
        response.raise_for_status()

    try:
        payload = response.json()
    except ValueError:
        logger.error(
            "Stability Replace Background returned non-image response without JSON "
            "payload. status=%s content_type=%s body_len=%d",
            response.status_code,
            response.headers.get("Content-Type"),
            len(response.content),
        )
        raise RuntimeError(
            "Stability Replace Background async response is not JSON and not an image."
        ) from None

    gen_id = payload["id"]
    logger.info(
        "Stability Replace Background running async. gen_id=%s status=%s",
        gen_id, payload.get("status"),
    )
    image_bytes = _poll_stability_async_result(
        gen_id=gen_id, output_format=output_format, timeout_s=timeout_s,
    )
    presigned_url = _upload_image_and_get_presigned_url(
        image_bytes, output_format=output_format,
    )
    return json.dumps(
        {"type": "image_url", "image_url": {"url": presigned_url}}, ensure_ascii=False,
    )
