"""omd/prompts/__init__.py.

System prompt builders.
"""

from omd.prompts.base import ListPrompt, PromptBase

__all__ = ["ListPrompt", "PromptBase"]
