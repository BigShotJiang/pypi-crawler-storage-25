"""omd/prompts/base.py.

System prompt builders.
"""

from __future__ import annotations

from abc import ABC, abstractmethod


class PromptBase(ABC):
    """Base class for prompt builders.

    The built prompt is typically used as the content of the ``system`` message.
    Instances are "str-like": ``str(prompt)`` returns the built prompt.
    """

    @abstractmethod
    def build(self) -> str:
        """Build and return the prompt string.

        :returns: Prompt text.
        :rtype: str
        """

    def __str__(self) -> str:
        """Return :meth:`build` result.

        :returns: Prompt text.
        :rtype: str
        """
        return self.build()


class ListPrompt(PromptBase):
    """Prompt builder that concatenates multiple prompt parts."""

    def __init__(self, parts: list[str] | None = None) -> None:
        """Initialize with ordered prompt parts.

        :param parts: Ordered prompt parts to concatenate.
        :type parts: list[str] | None
        """
        self.parts = list(parts or [])

    def build(self) -> str:
        """Build and return the prompt string.

        :returns: Prompt text.
        :rtype: str
        """
        return "\n".join(
            part.strip() for part in self.parts if part and part.strip()
        ).strip()
