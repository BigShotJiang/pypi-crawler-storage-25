"""omd/__init__.py.

OMD — One More Dimension.

Lightweight Python framework for building LLM agents with tool-calling,
streaming support, and skills.
"""

# Version of the package
__version__ = "0.3.0"
