# Changelog

All notable changes to the `omd` project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.3.0] - 2025-04-23

### Added

#### Streaming Support
- **New module `omd.streaming`** with streaming utilities for async agent event emission
  - `StreamEvent` union type: `ContentDeltaEvent`, `ToolCallStartEvent`, `ToolResultEvent`, `DoneEvent`, `ErrorEvent`
  - `OwuiSseFormatter` for formatting events into Open WebUI-compatible SSE chunks
  - Reasoning content support with `<thinking>` tags
  - Tool call visualization with collapsible `<details>` blocks

#### Streaming Agents
- **`AsyncStreamingAgent`** — async agent that yields fine-grained events during tool-calling loops
  - Real-time content deltas (even with non-streaming LLM providers)
  - Tool call start/result events
  - Configurable `max_iterations` with `finalize_prompt` for graceful termination
  - Exception handling with `ErrorEvent` emission

- **`StreamingAgent`** — synchronous counterpart to `AsyncStreamingAgent`
  - Same event model for sync-based workflows
  - Compatible with synchronous OpenAI clients

#### OpenAI SDK Client
- **`OpenAISDKClient`** in `omd.clients.openai_sdk`
  - Official `openai` Python SDK integration
  - `base_url` support for OpenAI-compatible endpoints (Perplexity, Together, Azure, etc.)
  - Streaming support via `stream_model()` method
  - Available with `pip install omd[openai]`

#### Terminating Agent
- **`TerminatingAgent`** in `omd.agents.terminating`
  - Agent that exits the loop on a designated "submit" tool call
  - `SubmittedSignal` exception for signaling early termination
  - `submission` attribute for accessing captured results
  - Useful for structured output workflows

#### Advanced Tool Features
- **`tool_from_schema()`** in `omd.tools.raw_schema`
  - Create `Tool` instances from raw OpenAI function-calling schemas
  - Support for `enum`, nullable types (`["string", "null"]`), nested objects
  - `RawSchemaTool` subclass that preserves the original schema verbatim

- **`AsyncToolBridge`** in `omd.tools.async_bridge`
  - Wrap synchronous tools for async streaming agents
  - Thread pool execution to prevent event loop blocking
  - `wrap()` for single tools, `wrap_many()` for batch wrapping

### Changed

- **Development Status**: Updated from "Alpha" to "Beta" in package classifiers
- **Project description**: Extended to mention streaming support
- **README**: Added comprehensive documentation for all new features
  - Streaming agents section with SSE formatting examples
  - OpenAI SDK client usage guide
  - Terminating agent patterns
  - Advanced tools documentation

### Technical Details

#### New Files
- `src/omd/streaming/__init__.py`
- `src/omd/streaming/events.py`
- `src/omd/streaming/sse_formatter.py`
- `src/omd/agents/streaming.py`
- `src/omd/agents/terminating.py`
- `src/omd/clients/openai_sdk.py`
- `src/omd/tools/raw_schema.py`
- `src/omd/tools/async_bridge.py`

#### Updated Files
- `pyproject.toml`: Version 0.3.0, added `openai` optional dependency
- `src/omd/__init__.py`: Added `__version__`
- `src/omd/agents/__init__.py`: Exports for new agent classes
- `src/omd/clients/__init__.py`: Conditional export for `OpenAISDKClient`
- `src/omd/tools/__init__.py`: Exports for new tool utilities

## [0.2.0] - Previous Release

### Features
- `BaseClient` abstraction for OpenAI-compatible HTTP APIs
- `ApiBarClient` implementation for raw HTTP calls
- `BaseAgent` with ReAct-style tool-calling loop
- `Tool.from_callable()` with automatic JSON schema generation
- `ToolValidationError` for argument validation
- Skills system with `SkillRegistry`, `SkillRouter`, `Skill`
- File manipulation tools: `read_fragment`, `read_lines`, `insert_lines`, `delete_lines`
- Optional machinery integrations: Stability AI, Gemini, Veo
- Pydantic v2 models throughout
