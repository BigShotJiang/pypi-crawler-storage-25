"""syntok segmenter"""

__version__ = "1.6.39"
