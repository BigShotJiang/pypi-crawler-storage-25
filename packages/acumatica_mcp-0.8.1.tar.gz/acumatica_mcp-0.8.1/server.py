"""
Acumatica MCP Server v9
Two-layer architecture: this file defines MCP tools as thin orchestration
over AcumaticaClient (acumatica_client.py).

Tools:
  DISCOVERY:   list_available_entities, describe_entity, list_endpoints,
               describe_endpoint, refresh_schema_cache, list_companies,
               switch_company, get_acumatica_version
  QUERIES:     list_generic_inquiries, query_generic_inquiry, get_records,
               get_record_by_keys, search_records
  MUTATIONS:   create_record, update_record, patch_record, invoke_action,
               delete_record
  FILES:       get_file, put_file
  SPECIALISED: check_inventory, track_shipment, get_customer_balance, run_report
"""

import json
import logging
import os
import re
import sys
from pathlib import Path

import httpx
from dotenv import load_dotenv
from mcp.server.fastmcp import FastMCP
from acumatica_client import AcumaticaClient, AcumaticaConfigError

# ---------------------------------------------------------------------------
# Logging — stderr always; optional file log for development
# ---------------------------------------------------------------------------
_log_level = getattr(logging, os.environ.get("LOG_LEVEL", "INFO").upper(), logging.INFO)
_log_fmt = "%(asctime)s %(name)s %(levelname)s  %(message)s"

# stderr handler (stdout is reserved for MCP protocol messages)
logging.basicConfig(level=_log_level, stream=sys.stderr, format=_log_fmt)

# Optional file handler — set ACUMATICA_MCP_LOG to a path to enable
_log_file = os.environ.get("ACUMATICA_MCP_LOG")
if _log_file:
    _fh = logging.FileHandler(_log_file)
    _fh.setLevel(logging.DEBUG)          # file always captures everything
    _fh.setFormatter(logging.Formatter(_log_fmt))
    logging.getLogger().addHandler(_fh)

logger = logging.getLogger("acumatica-mcp")

# ---------------------------------------------------------------------------
# Load .env file if present (before reading env vars)
# ---------------------------------------------------------------------------
_env_path = Path(__file__).parent / ".env"
if _env_path.exists():
    load_dotenv(_env_path, override=True)
    logger.info(f"Loaded config from {_env_path}")

# ---------------------------------------------------------------------------
# Initialise the API client from environment variables
# ---------------------------------------------------------------------------
api: AcumaticaClient | None = None
_config_error: str | None = None

try:
    api = AcumaticaClient()
    logger.info(f"Connected to {api.url} (auth: {api.auth_mode})")
except AcumaticaConfigError as e:
    _config_error = str(e)
    logger.warning(f"Not configured: {_config_error}")

# ---------------------------------------------------------------------------
# MCP Server
# ---------------------------------------------------------------------------
_instructions_configured = (
    f"This server connects to an Acumatica ERP instance at {api.url}. "
    f"API version: {api.api_version}.\n"
    "\n"
    "DISCOVERY:\n"
    "- 'list_available_entities' — flat list of all queryable entities (cheap). "
    "Start here to find entity names.\n"
    "- 'describe_entity' — compact field list for a specific entity. "
    "Use this before querying an unfamiliar entity.\n"
    "- 'list_endpoints' — full endpoint listing (heavier, includes field details).\n"
    "- 'describe_endpoint' — detailed field info including types and nested entities.\n"
    "- 'refresh_schema_cache' — force a fresh metadata fetch (use if schema seems stale).\n"
    "- 'list_companies' — list available companies in this Acumatica tenant.\n"
    "- 'switch_company' — switch the active company (re-authenticates).\n"
    "- 'get_acumatica_version' — get ERP version and all available endpoints.\n"
    "\n"
    "QUERIES:\n"
    "- 'list_generic_inquiries' — discover available GIs before querying. "
    "Always call this first — do NOT guess GI names.\n"
    "- 'query_generic_inquiry' — run a saved GI by exact name.\n"
    "- 'get_records' — query with OData filters (IDs, statuses, dates, ranges).\n"
    "- 'get_record_by_keys' — fetch a single record by its key fields "
    "(e.g. SalesOrder by OrderType + OrderNbr).\n"
    "- 'search_records' — keyword search across text fields. "
    "Use for names, descriptions, partial text.\n"
    "\n"
    "MUTATIONS:\n"
    "- 'create_record' — create a new entity record (insert only).\n"
    "- 'update_record' — update an existing entity record (update only).\n"
    "- 'patch_record' — partially update a record (only specified fields change).\n"
    "- 'delete_record' — delete a record by key fields.\n"
    "- 'invoke_action' — trigger an Acumatica action on a record, "
    "with automatic polling for long-running operations.\n"
    "\n"
    "FILES:\n"
    "- 'get_file' — download a file attachment by ID.\n"
    "- 'put_file' — upload a file attachment to a record.\n"
    "\n"
    "SPECIALISED:\n"
    "- 'check_inventory' — check stock availability for an item across warehouses.\n"
    "- 'track_shipment' — look up shipment details and tracking info.\n"
    "- 'get_customer_balance' — get AR balance, credit limit, and open invoices "
    "for a customer.\n"
    "- 'run_report' — execute an Acumatica report by Screen ID and return PDF.\n"
) if api else ""

_instructions_not_configured = (
    "This Acumatica ERP connector is NOT YET CONFIGURED. "
    "The user needs to provide their Acumatica credentials before any tools will work.\n\n"
    "AVAILABLE TOOLS:\n"
    "- 'connection_status' — shows what's missing and how to fix it.\n\n"
    "When ANY Acumatica-related tool is called, call 'connection_status' first "
    "and walk the user through the setup."
)

mcp = FastMCP(
    "Acumatica",
    instructions=_instructions_configured if api else _instructions_not_configured,
)


# ---------------------------------------------------------------------------
# Guard — returns an error string if the client isn't configured, else None
# ---------------------------------------------------------------------------
def _require_connection() -> str | None:
    """Return an error result if the API client is not configured, else None."""
    if api is not None:
        return None
    return _json_result({
        "error": True,
        "not_configured": True,
        "message": (
            "Acumatica connection is not configured. "
            "Run the 'connection_status' tool to see what's needed."
        ),
    })


def _json_result(data: dict) -> str:
    """Standard JSON serialisation for tool results."""
    return json.dumps(data, indent=2, default=str)


def _shape(data, compact: bool = True):
    """
    Apply compacting to Acumatica response data if requested.

    Compact mode (the default) strips the verbose ``{"value": X}`` envelope,
    drops protocol noise (``rowNumber``, ``_links``, ``custom``, empty ``note``),
    and removes null-equivalent empty dicts. Cuts token cost ~3x on reads.

    Callers that need the raw envelope (auditing, debugging, full round-trip)
    should pass ``compact=False``.
    """
    if not compact:
        return data
    return AcumaticaClient.compact_record(data)


def _infer_columns(rows: list[dict]) -> list[dict]:
    """Infer column metadata from GI result rows.

    Scans the first few rows to collect column names and guess types from
    the Python values (after compaction). Returns a list of
    ``{"name": ..., "type": ...}`` dicts — cheap context for the LLM to
    understand what each column means.
    """
    if not rows:
        return []
    # Scan up to 5 rows to catch columns that are null in the first row
    seen: dict[str, str] = {}
    for row in rows[:5]:
        if not isinstance(row, dict):
            continue
        for key, val in row.items():
            if key in seen and seen[key] != "unknown":
                continue
            if val is None:
                seen.setdefault(key, "unknown")
            elif isinstance(val, bool):
                seen[key] = "boolean"
            elif isinstance(val, int):
                seen[key] = "integer"
            elif isinstance(val, float):
                seen[key] = "decimal"
            elif isinstance(val, str):
                # Sniff dates: ISO-style strings
                if len(val) >= 10 and val[4:5] == "-" and val[7:8] == "-":
                    seen[key] = "datetime"
                else:
                    seen[key] = "string"
            elif isinstance(val, list):
                seen[key] = "array"
            elif isinstance(val, dict):
                seen[key] = "object"
            else:
                seen[key] = "unknown"
    # Preserve insertion order from the first row
    ordered_keys = list(rows[0].keys()) if rows else []
    # Add any keys found in subsequent rows that weren't in the first
    for key in seen:
        if key not in ordered_keys:
            ordered_keys.append(key)
    return [{"name": k, "type": seen.get(k, "unknown")} for k in ordered_keys]


def _client_side_sort(rows: list[dict], order_by: str) -> list[dict]:
    """Sort rows client-side to guarantee ordering.

    Parses an OData-style ``$orderby`` expression like ``'Date desc'`` or
    ``'Status asc, Date desc'`` and applies a stable Python sort.  Missing
    or non-comparable values sort last.
    """
    parts = [p.strip() for p in order_by.split(",") if p.strip()]
    # Build sort keys in reverse order (last key applied first for stable sort)
    for part in reversed(parts):
        tokens = part.split()
        field = tokens[0]
        descending = len(tokens) > 1 and tokens[1].lower() == "desc"

        def sort_key(row, _field=field):
            val = row.get(_field)
            if val is None:
                return (1, "")  # nulls last
            return (0, val)

        try:
            rows = sorted(rows, key=sort_key, reverse=descending)
        except TypeError:
            # Mixed types that can't compare — skip this sort key
            logger.debug(f"Client-side sort skipped for '{field}': incomparable types")
    return rows


def _error_result(message: str, status_code: int | None = None, detail: str = "") -> str:
    """Standard error response format."""
    result = {"error": True, "message": message}
    if status_code:
        result["status_code"] = status_code
    if detail:
        result["detail"] = detail[:500]
    return _json_result(result)


def _error_from_response(prefix: str, resp) -> str:
    """Parse a failed Acumatica response into a structured error result."""
    # api is guaranteed non-None here — only called from guarded tools
    parsed = api.parse_error_response(resp)  # type: ignore[union-attr]
    message = f"{prefix}: {parsed['message']}" if parsed["message"] else prefix
    result = {"error": True, "message": message, "status_code": resp.status_code}
    if parsed["field_errors"]:
        result["field_errors"] = parsed["field_errors"]
    if parsed["detail_errors"]:
        result["detail_errors"] = parsed["detail_errors"]
    return _json_result(result)


def _get_with_fallback(
    path: str,
    params: dict,
    error_prefix: str,
) -> tuple[httpx.Response | None, str | None]:
    """GET with automatic fallback on 500 — strips $select then $expand.

    Returns (response, None) on success, or (None, error_json) if all
    attempts fail.  Fallback steps are logged at WARNING so they show
    up in development but never surface to the end user.
    """
    resp = api.get(path, params)
    if resp.status_code != 500:
        return resp, None

    # --- Attempt 1: drop $select (most common 500 culprit) ----------------
    if "$select" in params:
        trimmed = {k: v for k, v in params.items() if k != "$select"}
        logger.warning(
            "500 from %s with $select — retrying without $select  "
            "[original params: %s]",
            path, params,
        )
        resp = api.get(path, trimmed)
        if resp.status_code != 500:
            return resp, None
        params = trimmed          # carry the reduced set forward

    # --- Attempt 2: drop $expand ------------------------------------------
    if "$expand" in params:
        trimmed = {k: v for k, v in params.items() if k != "$expand"}
        logger.warning(
            "500 persists after dropping $select — retrying without $expand  "
            "[params now: %s]",
            path, params,
        )
        resp = api.get(path, trimmed)
        if resp.status_code != 500:
            return resp, None

    # --- All fallbacks exhausted ------------------------------------------
    logger.error(
        "All fallback attempts failed for %s  [final status: %s]",
        path, resp.status_code,
    )
    return None, _error_from_response(error_prefix, resp)


def _get_discovery() -> dict:
    """Lazy accessor for the tenant discovery cache. Returns {} if unavailable."""
    if api is None:
        return {}
    try:
        return api.discover()
    except Exception as e:
        logger.warning(f"Discovery failed: {e}")
        return {}


# ---------------------------------------------------------------------------
# Input validation
# ---------------------------------------------------------------------------
_SAFE_NAME_RE = re.compile(r"^[A-Za-z][A-Za-z0-9_]*$")
_MAX_STRING_PARAM_LEN = 500
_VALID_REPORT_FORMATS = {"pdf", "xlsx", "csv", "docx"}


def _validate_endpoint_name(name: str) -> str | None:
    """Return an error string if *name* is not a valid entity name, else None.

    Prevents path-traversal attacks (e.g. ``../../admin``) in URL-interpolated
    endpoint parameters.
    """
    if not name or len(name) > 100:
        return _error_result(
            f"Invalid endpoint name: must be 1-100 characters, got {len(name or '')}."
        )
    if not _SAFE_NAME_RE.match(name):
        return _error_result(
            f"Invalid endpoint name '{name}'. "
            "Must start with a letter and contain only letters, digits, or underscores."
        )
    return None


def _validate_string_param(value: str | None, param_name: str) -> str | None:
    """Return an error string if *value* exceeds the max length, else None."""
    if value is not None and len(value) > _MAX_STRING_PARAM_LEN:
        return _error_result(
            f"Parameter '{param_name}' exceeds maximum length "
            f"({len(value)} > {_MAX_STRING_PARAM_LEN})."
        )
    return None


def _guard_and_validate_endpoint(endpoint: str) -> str | None:
    """Combined connection guard + endpoint name validation.

    Returns an error JSON string if something is wrong, None if OK.
    """
    guard = _require_connection()
    if guard:
        return guard
    return _validate_endpoint_name(endpoint)


# ========================== CONNECTION / SETUP TOOLS ==========================

@mcp.tool()
def connection_status() -> str:
    """
    Check whether the Acumatica connection is configured and working.

    If not configured, returns exactly what's missing and step-by-step
    instructions to fix it. Always safe to call — works whether connected
    or not.

    Returns:
        JSON with connection status, auth mode, and setup instructions if needed.
    """
    env_path = Path(__file__).parent / ".env"

    if api is not None:
        status = {
            "connected": True,
            "url": api.url,
            "company": api.company,
            "auth_mode": api.auth_mode,
            "api_version": api.api_version,
            "branch": api.branch or "(default)",
            "env_file": str(env_path) if env_path.exists() else None,
        }
        # Include discovery summary if available
        disco = _get_discovery()
        if disco:
            status["discovery"] = {
                "endpoints_found": len(disco.get("endpoints", {})),
                "report_endpoint_version": disco.get("report_endpoint_version"),
                "ar_invoice_entity": disco.get("ar_invoice_entity"),
                "inventory_entities": disco.get("inventory_entities", []),
            }
        return _json_result(status)

    # --- Not configured — build helpful diagnostics ---
    has_url = bool(os.environ.get("ACUMATICA_URL", ""))
    has_company = bool(os.environ.get("ACUMATICA_COMPANY", ""))
    has_basic = bool(os.environ.get("ACUMATICA_USER", "")) and bool(os.environ.get("ACUMATICA_PASS", ""))
    has_oauth = bool(os.environ.get("ACUMATICA_CLIENT_ID", "")) and bool(os.environ.get("ACUMATICA_CLIENT_SECRET", ""))

    missing = []
    if not has_url:
        missing.append("ACUMATICA_URL — your Acumatica instance URL (e.g. https://mycompany.acumatica.com)")
    if not has_company:
        missing.append("ACUMATICA_COMPANY — your company/tenant name")
    if not has_basic and not has_oauth:
        missing.append(
            "Authentication credentials — either: "
            "ACUMATICA_USER + ACUMATICA_PASS (username/password) "
            "or ACUMATICA_CLIENT_ID + ACUMATICA_CLIENT_SECRET (OAuth 2.0, recommended)"
        )

    setup_instructions = [
        "Create a file called .env in the servers/ directory of this plugin with your credentials.",
        "",
        "Option A — Username/Password (simplest):",
        "  ACUMATICA_URL=https://your-instance.acumatica.com",
        "  ACUMATICA_COMPANY=MyCompany",
        "  ACUMATICA_USER=api_user",
        "  ACUMATICA_PASS=your_password",
        "",
        "Option B — OAuth 2.0 (recommended for production):",
        "  ACUMATICA_URL=https://your-instance.acumatica.com",
        "  ACUMATICA_COMPANY=MyCompany",
        "  ACUMATICA_CLIENT_ID=your_client_id",
        "  ACUMATICA_CLIENT_SECRET=your_client_secret",
        "",
        "To get OAuth credentials: in Acumatica, go to Connected Applications (SM303010),",
        "create a new app with flow type 'Authorization Code', add http://localhost:8742/callback",
        "as a redirect URI, and copy the Client ID and Client Secret.",
        "",
        f"Alternatively, run: python {Path(__file__).parent / 'setup.py'}",
        "This walks you through the setup interactively and writes the .env file for you.",
    ]

    return _json_result({
        "connected": False,
        "error": _config_error,
        "env_file_exists": env_path.exists(),
        "env_file_path": str(env_path),
        "missing": missing,
        "setup_instructions": "\n".join(setup_instructions),
    })


# ========================== DISCOVERY TOOLS ==========================

@mcp.tool()
def list_endpoints(
    search: str | None = None,
    top: int | None = None,
    detailed: bool = False,
) -> str:
    """
    List available Contract-Based API entity endpoints.

    Without a search term, returns a compact summary (name + field count only)
    to keep token usage low.  Use ``search`` to narrow results, or
    ``detailed=True`` to include detail-entity names in the listing.

    Args:
        search: Optional text to filter endpoint names (case-insensitive).
                E.g. 'sales' will show SalesOrder, SalesPerson, etc.
        top: Max endpoints to return. Defaults to 50 when unfiltered, unlimited
             when a search term is provided.
        detailed: If True, include detail-entity names in each entry.
                  Defaults to True when a search term is provided, False otherwise.

    Returns:
        JSON list of available endpoint names with field counts.
    """
    guard = _require_connection()
    if guard:
        return guard
    entities = api.get_metadata()

    # When searching, default to detailed + unlimited; otherwise compact + capped
    show_details = detailed or bool(search)
    limit = top if top is not None else (None if search else 50)

    results = []
    for name, info in sorted(entities.items()):
        if search and search.lower() not in name.lower():
            continue
        entry: dict = {
            "endpoint": name,
            "field_count": len(info["fields"]),
        }
        if show_details:
            entry["detail_entities"] = [d["name"] for d in info["detail_entities"]]
        results.append(entry)

    total = len(results)
    truncated = False
    if limit and total > limit:
        results = results[:limit]
        truncated = True

    response: dict = {"total": total, "endpoints": results}
    if truncated:
        response["truncated"] = True
        response["hint"] = (
            f"Showing {limit} of {total} endpoints. "
            "Use 'search' to filter, or 'top' to see more."
        )
    return _json_result(response)


@mcp.tool()
def describe_endpoint(endpoint: str) -> str:
    """
    Get the full schema for a Contract-Based API endpoint — field names,
    types, and expandable detail entities.

    Always call this before querying an endpoint for the first time.

    Args:
        endpoint: The entity name, e.g. 'SalesOrder', 'Customer', 'StockItem'.

    Returns:
        JSON with field definitions and detail entities.
    """
    guard = _require_connection()
    if guard:
        return guard
    entities = api.get_metadata()

    info = entities.get(endpoint)
    if not info:
        for name, data in entities.items():
            if name.lower() == endpoint.lower():
                info = data
                endpoint = name
                break

    if not info:
        suggestions = [
            name for name in entities
            if endpoint.lower() in name.lower()
        ]
        return _error_result(
            f"Endpoint '{endpoint}' not found.",
            detail=f"Suggestions: {', '.join(suggestions[:10])}" if suggestions else "",
        )

    return _json_result({
        "endpoint": endpoint,
        "fields": info["fields"],
        "detail_entities": info["detail_entities"],
        "field_count": len(info["fields"]),
    })


@mcp.tool()
def list_available_entities(search: str | None = None) -> str:
    """
    Flat list of all queryable entities — much cheaper than list_endpoints.

    Returns entity names only (no field details), with a flag indicating
    whether each entity has detail sub-entities (expandable). Use
    describe_entity() to get field-level detail for a specific entity.

    Args:
        search: Optional text to filter entity names (case-insensitive).

    Returns:
        JSON list of entity names with basic metadata.
    """
    guard = _require_connection()
    if guard:
        return guard
    entities = api.get_metadata()

    results = []
    for name, info in sorted(entities.items()):
        if search and search.lower() not in name.lower():
            continue
        results.append({
            "name": name,
            "field_count": len(info["fields"]),
            "has_details": bool(info["detail_entities"]),
        })

    return _json_result({"total": len(results), "entities": results})


@mcp.tool()
def describe_entity(entity: str) -> str:
    """
    Compact schema for a specific entity — field names, types, and detail entities.

    More LLM-friendly than describe_endpoint: returns a flat list of
    {name, type} pairs and flags key/required fields where detectable.

    Args:
        entity: Entity name, e.g. 'SalesOrder', 'Customer', 'StockItem'.

    Returns:
        JSON with fields (name + type) and detail entities.
    """
    guard = _require_connection()
    if guard:
        return guard
    entities = api.get_metadata()

    info = entities.get(entity)
    if not info:
        # Case-insensitive fallback
        for name, data in entities.items():
            if name.lower() == entity.lower():
                info = data
                entity = name
                break

    if not info:
        suggestions = [
            name for name in entities
            if entity.lower() in name.lower()
        ]
        return _error_result(
            f"Entity '{entity}' not found.",
            detail=f"Did you mean: {', '.join(suggestions[:10])}" if suggestions else "",
        )

    # Build compact field list
    fields = [{"name": f["name"], "type": f["type"]} for f in info["fields"]]
    details = [{"name": d["name"], "type": d["type"]} for d in info["detail_entities"]]

    return _json_result({
        "entity": entity,
        "field_count": len(fields),
        "fields": fields,
        "detail_entities": details,
    })


@mcp.tool()
def refresh_schema_cache() -> str:
    """
    Clear the schema and tenant discovery caches, forcing a fresh fetch.

    Use this if entity schemas seem stale — e.g. after a customisation package
    deployment, an Acumatica upgrade, or if describe_endpoint is returning
    unexpected fields. Also re-discovers tenant capabilities (available
    endpoints, Report version, AR entity name, inventory entities).

    Returns:
        JSON confirming the caches were cleared.
    """
    guard = _require_connection()
    if guard:
        return guard
    api.clear_schema_cache()  # Also clears discovery cache
    return _json_result({
        "success": True,
        "message": "Schema and discovery caches cleared. Both will be re-fetched on next use.",
    })


@mcp.tool()
def list_companies() -> str:
    """
    List the companies (tenants) available in this Acumatica instance.

    Useful for multi-company tenants. Tries the legacy
    `/entity/auth/companylist` endpoint first; falls back to deriving the
    list from the Branch entity (which every tenant exposes). If both
    fail, returns just the currently-configured company with a diagnostic
    list of attempted paths.

    Returns:
        JSON list of available companies plus the currently active one.
    """
    guard = _require_connection()
    if guard:
        return guard
    try:
        companies = api.get_company_list()
        return _json_result({
            "current_company": api.company,
            "count": len(companies),
            "companies": companies,
        })
    except Exception as e:
        return _error_result(f"Could not retrieve company list: {e}")


@mcp.tool()
def switch_company(company_id: str) -> str:
    """
    Switch the active company for all subsequent requests.

    Re-authenticates with the new company context. Also clears the schema
    cache since entity schemas can differ between companies. Use
    list_companies to see available options.

    Args:
        company_id: The Company ID to switch to (e.g. 'MYCOMPANY').

    Returns:
        JSON confirming the switch.
    """
    guard = _require_connection()
    if guard:
        return guard
    try:
        api.switch_company(company_id)
        return _json_result({
            "success": True,
            "active_company": api.company,
            "message": f"Switched to company '{company_id}'. Schema cache cleared.",
        })
    except Exception as e:
        return _error_result(f"Failed to switch to company '{company_id}': {e}")


# ========================== QUERY TOOLS ==========================

@mcp.tool()
def query_generic_inquiry(
    inquiry_name: str,
    parameters: dict | None = None,
    filters: dict | None = None,
    top: int | None = None,
    raw: bool = False,
    contract_endpoint: str | None = None,
    contract_version: str | None = None,
    contract_detail: str = "Result",
) -> str:
    """
    Query an Acumatica Generic Inquiry by its Site Map Title via OData.

    Uses the OData GI endpoint: `/t/{tenant}/api/odata/gi/{SiteMapTitle}`.
    GIs with Selection-area parameters use the `_WithParameters(...)` suffix.

    For parameterised GIs that time out via OData, use `contract_endpoint` to
    query via the Contract-Based API instead. This requires the GI to be added
    as an entity on a Web Service Endpoint in SM207060. The contract-based path
    uses PUT with `$expand=Result` and passes parameters in the request body,
    which handles Selection-area parameters natively and often performs better
    for heavy GIs.

    IMPORTANT: Do not guess GI names. Ask the user if you don't know the
    exact Site Map Title (SM208000 → Site Map Title — NOT the Inquiry Title).

    Args:
        inquiry_name: The exact Site Map Title of the Generic Inquiry.
        parameters: Optional dict of GI Selection-area parameter names → values.
                    For OData mode: these become the `_WithParameters(...)` suffix.
                    For contract mode: these are sent in the PUT request body.
        filters: Optional OData $filter dict (same syntax as get_records).
        top: Max rows to return. Defaults to 50.
        raw: If True, return the full envelope. Default False (compact).
        contract_endpoint: Optional Web Service Endpoint name (e.g. 'Default')
                           to query the GI via the Contract-Based API instead of
                           OData. The GI must be added as an entity on this
                           endpoint in SM207060. When set, uses PUT to
                           `/entity/{endpoint}/{version}/{inquiry_name}?$expand=Result`.
        contract_version: API version for the contract endpoint (e.g. '25.200.001').
                          Only used with contract_endpoint. Defaults to the
                          configured ACUMATICA_API_VERSION if omitted.
        contract_detail: Name of the detail entity that holds the GI result rows.
                         Defaults to 'Result' (the standard convention). Override
                         if the entity was set up with a different detail name
                         in SM207060 (e.g. 'ARAgingDetailDetails').

    Returns:
        JSON with row_count and rows, or an error with diagnostic detail.
    """
    guard = _require_connection()
    if guard:
        return guard

    # ── Contract-Based API path ──────────────────────────────────────
    if contract_endpoint:
        cb_version = contract_version or api.api_version
        cb_path = f"/entity/{contract_endpoint}/{cb_version}/{inquiry_name}"
        q: dict = {"$expand": contract_detail}
        if filters:
            q["$filter"] = api.build_odata_filter(filters)

        # Build body: parameters go as {"ParamName": {"value": x}} format.
        body: dict = {}
        if parameters:
            for k, v in parameters.items():
                body[k] = {"value": v}

        logger.info(
            f"Querying GI '{inquiry_name}' via contract-based endpoint "
            f"'{contract_endpoint}': PUT {cb_path}"
        )
        try:
            resp = api.put(cb_path, body=body, params=q)
        except Exception as e:
            return _error_result(
                f"Contract-based GI query failed for '{inquiry_name}' on "
                f"endpoint '{contract_endpoint}': {type(e).__name__}: {e}"
            )

        if resp.status_code != 200:
            return _error_from_response(
                f"Contract-based GI query failed for '{inquiry_name}' on "
                f"endpoint '{contract_endpoint}'",
                resp,
            )

        try:
            payload = resp.json()
        except Exception as e:
            return _error_result(
                f"GI '{inquiry_name}' (contract-based) returned non-JSON: {e}"
            )

        # Contract-based GI responses nest rows under the detail entity key.
        data = _shape(payload, compact=not raw)
        rows = data.get(contract_detail, data) if isinstance(data, dict) else data
        if isinstance(rows, list):
            total = len(rows)
            if top:
                rows = rows[:top]
            return _json_result({
                "inquiry_name": inquiry_name,
                "source_path": cb_path,
                "mode": "contract-based",
                "total_rows": total,
                "returned_rows": len(rows),
                "columns": _infer_columns(rows),
                "rows": rows,
            })
        return _json_result(data)

    # ── OData path (default) ────────────────────────────────────────
    # Build path. Format parameters as OData function-call syntax.
    gi_path_segment = inquiry_name
    if parameters:
        parts: list[str] = []
        for k, v in parameters.items():
            if isinstance(v, bool):
                parts.append(f"{k}={'true' if v else 'false'}")
            elif isinstance(v, (int, float)):
                parts.append(f"{k}={v}")
            elif v is None:
                parts.append(f"{k}=null")
            else:
                # String — escape single quotes by doubling.
                escaped = str(v).replace("'", "''")
                parts.append(f"{k}='{escaped}'")
        gi_path_segment = f"{inquiry_name}_WithParameters({','.join(parts)})"

    # Query params
    q: dict = {}
    if filters:
        q["$filter"] = api.build_odata_filter(filters)
    q["$top"] = str(top) if top else "50"

    # Try tenant-qualified path first (standard for multi-tenant instances),
    # then the short path (single-tenant / subdomain-based installs).
    tenant = api.company or ""
    attempts: list[str] = []
    candidate_paths = [
        f"/t/{tenant}/api/odata/gi/{gi_path_segment}" if tenant else None,
        f"/api/odata/gi/{gi_path_segment}",
        f"/odata/gi/{gi_path_segment}",
    ]
    resp = None
    used_path = None
    for path in candidate_paths:
        if not path:
            continue
        try:
            resp = api.get(path, q, timeout=15.0)
        except Exception as e:
            attempts.append(f"{path} → {type(e).__name__}: {e}")
            continue
        if resp.status_code == 200:
            used_path = path
            break
        attempts.append(f"{path} → HTTP {resp.status_code}")

    if resp is None or resp.status_code != 200:
        return _error_result(
            f"GI query failed for '{inquiry_name}'. Attempts: "
            + "; ".join(attempts)
            + ". Confirm the Site Map Title in SM208000 and that the GI has "
            "'Expose via OData' enabled. For parameterised GIs that time out, "
            "try using contract_endpoint='Default' (requires GI to be added "
            "to that endpoint in SM207060)."
        )

    try:
        payload = resp.json()
    except Exception as e:
        return _error_result(f"GI '{inquiry_name}' returned non-JSON: {e}")

    # OData responses wrap rows in {"value": [...]}. _shape's compact mode
    # handles the unwrap + per-row clean-up.
    data = _shape(payload, compact=not raw)
    if isinstance(data, list):
        result = {
            "inquiry_name": inquiry_name,
            "source_path": used_path,
            "mode": "odata",
            "row_count": len(data),
            "columns": _infer_columns(data),
            "rows": data,
        }
        return _json_result(result)
    return _json_result(data)


@mcp.tool()
def list_generic_inquiries(search: str | None = None) -> str:
    """
    List Generic Inquiries available for querying.

    Discovers GIs from three sources (in priority order):
    1. The ACUMATICA_AVAILABLE_GIS environment variable (manually configured).
    2. The OData GI service document (auto-discovered from the tenant).
    3. Any GIs registered on known contract-based endpoints (e.g. MCPSuite).

    Use this to find exact GI names before calling query_generic_inquiry.

    Args:
        search: Optional text to filter GI names (case-insensitive).

    Returns:
        JSON list of available GI names with their query mode (odata/contract).
    """
    guard = _require_connection()
    if guard:
        return guard

    results: list[dict] = []
    seen: set[str] = set()

    # --- Source 1: env var ---
    env_gis = os.environ.get("ACUMATICA_AVAILABLE_GIS", "")
    if env_gis:
        for name in (n.strip() for n in env_gis.split(",") if n.strip()):
            if name not in seen:
                results.append({"name": name, "source": "configured", "mode": "unknown"})
                seen.add(name)

    # --- Source 2: OData GI service document ---
    disco = _get_discovery()
    gi_prefix = disco.get("odata_gi_prefix", "")
    if gi_prefix:
        try:
            resp = api.get(gi_prefix, timeout=15)
            if resp.status_code == 200:
                payload = resp.json()
                # OData service doc returns {"value": [{"name": "GIName", "url": "..."}, ...]}
                gi_entries = payload.get("value", [])
                if isinstance(gi_entries, list):
                    for entry in gi_entries:
                        name = entry.get("name", "") if isinstance(entry, dict) else ""
                        if name and name not in seen:
                            results.append({"name": name, "source": "odata", "mode": "odata"})
                            seen.add(name)
        except Exception as e:
            logger.debug(f"OData GI listing failed: {e}")

    # --- Source 3: contract-based endpoints ---
    endpoints = disco.get("endpoints", {})
    for ep_name, ep_info in endpoints.items():
        if ep_name.lower() in ("default", "report"):
            continue  # Skip standard endpoints — only look at custom ones
        entities = ep_info if isinstance(ep_info, list) else []
        for entity in entities:
            ename = entity if isinstance(entity, str) else ""
            if ename and ename not in seen:
                results.append({
                    "name": ename,
                    "source": f"endpoint:{ep_name}",
                    "mode": "contract",
                    "contract_endpoint": ep_name,
                })
                seen.add(ename)

    # --- Filter ---
    if search:
        search_lower = search.lower()
        results = [r for r in results if search_lower in r["name"].lower()]

    if not results:
        hints = [
            "No Generic Inquiries discovered.",
            "Possible causes:",
            "- The OData GI endpoint may not be accessible on this tenant.",
            "- Set ACUMATICA_AVAILABLE_GIS in .env (comma-separated Site Map Titles).",
            "- For contract-based GIs, register them on a Web Service Endpoint in SM207060.",
        ]
        return _error_result(" ".join(hints))

    return _json_result({
        "total": len(results),
        "inquiries": sorted(results, key=lambda r: r["name"]),
        "usage_hint": (
            "Pass the 'name' value to query_generic_inquiry(inquiry_name=...). "
            "For contract-mode GIs, also pass contract_endpoint."
        ),
    })


@mcp.tool()
def get_records(
    endpoint: str,
    filters: dict | None = None,
    select: str | None = None,
    expand: str | None = None,
    top: int | None = None,
    skip: int | None = None,
    order_by: str | None = None,
    raw: bool = False,
    api_endpoint: str | None = None,
) -> str:
    """
    Query records using OData filters.

    Supports exact values, comparisons, and date ranges. Filter values
    are auto-typed: strings are quoted, numbers and booleans are not.

    For partial text matching, use search_records instead.

    Args:
        endpoint: Entity name, e.g. 'StockItem', 'SalesOrder', 'Customer'.
        filters: Dict of field names and values. Values can be:
                 - Simple: {"Status": "Open"} → Status eq 'Open'
                 - Numeric: {"Qty": 5} → Qty eq 5
                 - Boolean: {"Active": true} → Active eq true
                 - Expression: {"OrderDate": "ge 2024-01-01"} → OrderDate ge 2024-01-01
        select: Comma-separated fields to return.
        expand: Comma-separated detail entities to include.
        top: Max rows. Defaults to 50.
        skip: Number of rows to skip (for pagination).
        order_by: Sort expression, e.g. 'OrderDate desc', 'Status asc'.
                 Passed as OData $orderby to Acumatica, but many Contract-Based
                 API entities ignore server-side sorting. As a safety net, the
                 returned rows are also sorted client-side to guarantee order.
        raw: If True, return the full Acumatica envelope ({"value": X} wrappers,
             _links, rowNumber, etc). Default False — compact, LLM-friendly.
        api_endpoint: Named endpoint to query against (e.g. 'MCPSuite', 'Manufacturing').
                     Defaults to ACUMATICA_ENDPOINT env var or 'Default'.
    """
    guard = _guard_and_validate_endpoint(endpoint)
    if guard:
        return guard
    params = {}
    if filters:
        params["$filter"] = api.build_odata_filter(filters)
    if select:
        params["$select"] = select
    if expand:
        params["$expand"] = expand
    if order_by:
        params["$orderby"] = order_by
    params["$top"] = str(top) if top else "50"
    if skip:
        params["$skip"] = str(skip)

    base = api.entity_base_for(api_endpoint) if api_endpoint else api.entity_base
    path = f"{base}/{endpoint}"
    logger.info(f"Getting {endpoint} with params: {params}")
    resp, err = _get_with_fallback(path, params, f"Query failed for '{endpoint}'")
    if err:
        return err

    if resp.status_code != 200:
        return _error_from_response(f"Query failed for '{endpoint}'", resp)

    data = _shape(resp.json(), compact=not raw)
    if isinstance(data, list) and order_by:
        data = _client_side_sort(data, order_by)
    if isinstance(data, list):
        return _json_result({"row_count": len(data), "rows": data})
    return _json_result(data)


@mcp.tool()
def get_record_by_keys(
    endpoint: str,
    keys: list[str],
    select: str | None = None,
    expand: str | None = None,
    raw: bool = False,
    api_endpoint: str | None = None,
) -> str:
    """
    Fetch a single record by its key field values using path segments.

    More efficient than get_records with filters for single-record lookups.
    Key values are passed as URL path segments in order.

    Args:
        endpoint: Entity name, e.g. 'SalesOrder', 'Customer', 'StockItem'.
        keys: List of key values in order. E.g.:
              - SalesOrder: ["SO", "SO-001234"] (OrderType, OrderNbr)
              - Customer: ["ABCCORP"] (CustomerID)
              - StockItem: ["WIDGET-01"] (InventoryID)
        select: Comma-separated fields to return.
        expand: Comma-separated detail entities to include.
        api_endpoint: Named endpoint to query against (e.g. 'MCPSuite', 'Manufacturing').
                     Defaults to ACUMATICA_ENDPOINT env var or 'Default'.

    Returns:
        JSON with the single record.
    """
    guard = _guard_and_validate_endpoint(endpoint)
    if guard:
        return guard
    key_path = "/".join(keys)
    params = {}
    if select:
        params["$select"] = select
    if expand:
        params["$expand"] = expand

    base = api.entity_base_for(api_endpoint) if api_endpoint else api.entity_base
    path = f"{base}/{endpoint}/{key_path}"
    logger.info(f"Getting {endpoint} by keys: {keys}")
    resp, err = _get_with_fallback(path, params, f"Lookup failed for {endpoint}/{key_path}")
    if err:
        return err

    if resp.status_code != 200:
        return _error_from_response(f"Lookup failed for {endpoint}/{key_path}", resp)

    return _json_result(_shape(resp.json(), compact=not raw))


@mcp.tool()
def search_records(
    endpoint: str,
    search_text: str,
    search_fields: list[str] | None = None,
    exact_filters: dict | None = None,
    select: str | None = None,
    expand: str | None = None,
    top: int = 20,
    fetch_limit: int = 500,
    raw: bool = False,
) -> str:
    """
    Search records by keyword — fetches from API then filters server-side
    using case-insensitive substring matching.

    Use for names, descriptions, or any partial text.

    Args:
        endpoint: Entity name, e.g. 'Customer', 'StockItem', 'SalesOrder'.
        search_text: Text to search for (case-insensitive).
        search_fields: Optional list of fields to search within.
                       If omitted, searches all string fields.
        exact_filters: Optional exact OData filters to narrow first.
                       E.g. {'Status': 'Open'}.
        select: Comma-separated fields to return.
        expand: Comma-separated detail entities to include.
        top: Max matching results. Default 20.
        fetch_limit: Max records to fetch before filtering. Default 500.
    """
    guard = _guard_and_validate_endpoint(endpoint)
    if guard:
        return guard
    params = {"$top": str(fetch_limit)}
    if exact_filters:
        params["$filter"] = api.build_odata_filter(exact_filters)
    if select:
        params["$select"] = select
    if expand:
        params["$expand"] = expand

    path = f"{api.entity_base}/{endpoint}"
    logger.info(f"Searching {endpoint} for '{search_text}'")
    resp, err = _get_with_fallback(path, params, f"Search failed for '{endpoint}'")
    if err:
        return err

    if resp.status_code != 200:
        return _error_from_response(f"Search failed for '{endpoint}'", resp)

    data = resp.json()
    if not isinstance(data, list):
        data = [data]

    search_lower = search_text.lower()
    matches = []

    for record in data:
        matched_fields = []
        fields_to_check = search_fields or list(record.keys())

        for field in fields_to_check:
            value = api.extract_value(record.get(field))
            if isinstance(value, str) and search_lower in value.lower():
                matched_fields.append(field)

        if matched_fields:
            matches.append({
                "record": _shape(record, compact=not raw),
                "matched_on": matched_fields,
            })

        if len(matches) >= top:
            break

    return _json_result({
        "search_text": search_text,
        "records_scanned": len(data),
        "matches_found": len(matches),
        "results": matches,
    })


# ========================== MUTATION TOOLS ==========================

@mcp.tool()
def create_record(
    endpoint: str,
    data: dict,
    expand: str | None = None,
    business_date: str | None = None,
) -> str:
    """
    Create a new record via the Contract-Based API (insert only).

    Uses If-None-Match header to ensure the record doesn't already exist.
    Field values should use Acumatica's {value: x} format for writable fields.
    Call describe_endpoint first to see available fields.

    Args:
        endpoint: Entity name, e.g. 'SalesOrder', 'Customer', 'StockItem'.
        data: Dict of field names to values. Use {"value": x} format for
              writable fields. E.g.:
              {
                  "OrderType": {"value": "SO"},
                  "CustomerID": {"value": "ABCCORP"},
                  "Description": {"value": "New order from MCP"}
              }
        expand: Comma-separated detail entities to include in the response.
        business_date: Optional business date override (YYYY-MM-DD format).
                       Sets the transaction date for the new record.

    Returns:
        JSON with the created record, including any server-generated fields
        (e.g. OrderNbr, auto-assigned IDs).
    """
    guard = _guard_and_validate_endpoint(endpoint)
    if guard:
        return guard
    params = {}
    if expand:
        params["$expand"] = expand

    headers = {"If-None-Match": "*"}  # Insert only — fail if record exists
    if business_date:
        headers["PX-CbApiBusinessDate"] = business_date

    logger.info(f"Creating {endpoint} record")
    resp = api.put(f"{api.entity_base}/{endpoint}", body=data, params=params, headers=headers)

    if resp.status_code not in (200, 201):
        return _error_from_response(f"Create failed for '{endpoint}'", resp)

    return _json_result(resp.json())


@mcp.tool()
def update_record(
    endpoint: str,
    data: dict,
    expand: str | None = None,
    business_date: str | None = None,
) -> str:
    """
    Update an existing record via the Contract-Based API (update only).

    Uses If-Match header to ensure the record already exists.
    The data dict MUST include the key field(s) that identify the record
    (e.g. OrderType + OrderNbr for SalesOrder, InventoryID for StockItem).
    Only include fields you want to change — omitted fields are left unchanged.

    Args:
        endpoint: Entity name, e.g. 'SalesOrder', 'Customer', 'StockItem'.
        data: Dict with key fields to identify the record, plus fields to update.
              Use {"value": x} format. E.g.:
              {
                  "OrderType": {"value": "SO"},
                  "OrderNbr": {"value": "SO-001234"},
                  "Description": {"value": "Updated description"}
              }
        expand: Comma-separated detail entities to include in the response.
        business_date: Optional business date override (YYYY-MM-DD format).

    Returns:
        JSON with the updated record.
    """
    guard = _guard_and_validate_endpoint(endpoint)
    if guard:
        return guard
    params = {}
    if expand:
        params["$expand"] = expand

    headers = {"If-Match": "*"}  # Update only — fail if record doesn't exist
    if business_date:
        headers["PX-CbApiBusinessDate"] = business_date

    logger.info(f"Updating {endpoint} record")
    resp = api.put(f"{api.entity_base}/{endpoint}", body=data, params=params, headers=headers)

    if resp.status_code != 200:
        return _error_from_response(f"Update failed for '{endpoint}'", resp)

    return _json_result(resp.json())


@mcp.tool()
def invoke_action(
    endpoint: str,
    keys: dict,
    action_name: str,
    parameters: dict | None = None,
    wait: bool = True,
    timeout: int = 300,
) -> str:
    """
    Trigger an Acumatica action on a specific record.

    Supports long-running operations — by default, polls until the action
    completes or times out. Acumatica actions like Release, ConfirmShipment,
    and CreateShipment are asynchronous and require polling.

    Common actions: ReleaseFromHold, Release, Confirm, ConfirmShipment,
    CancelOrder, ReopenOrder, CreateShipment, etc.

    Args:
        endpoint: Entity name, e.g. 'SalesOrder', 'Shipment', 'Invoice'.
        keys: Dict identifying the record. Use {"value": x} format.
              E.g. {"OrderType": {"value": "SO"}, "OrderNbr": {"value": "SO-001234"}}
        action_name: The action to invoke, e.g. 'ReleaseFromHold'.
        parameters: Optional dict of action parameters in {"value": x} format.
        wait: Whether to poll until the action completes (default True).
        timeout: Max seconds to wait for completion (default 300).

    Returns:
        JSON with the action result. If wait=True, returns the final state.
    """
    guard = _guard_and_validate_endpoint(endpoint)
    if guard:
        return guard
    logger.info(f"Invoking {action_name} on {endpoint}")

    resp = api.post(
        f"{api.entity_base}/{endpoint}/action/{action_name}",
        body=keys,
    )

    # Immediate success
    if resp.status_code == 200:
        return _json_result(resp.json())

    if resp.status_code == 204:
        return _json_result({"success": True, "action": action_name, "message": "Action completed."})

    # Long-running: 202 with Location header
    if resp.status_code == 202 and wait:
        location = resp.headers.get("Location", "")
        if location:
            # Location may be a full URL or a path — normalise to path
            if location.startswith("http"):
                from urllib.parse import urlparse as _urlparse
                location = _urlparse(location).path

            logger.info(f"Action is long-running, polling {location}...")
            try:
                final_resp = api.poll_action(location, timeout=timeout)
                if final_resp.status_code == 204:
                    return _json_result({
                        "success": True,
                        "action": action_name,
                        "message": "Action completed successfully.",
                    })
                if final_resp.status_code == 200:
                    return _json_result(final_resp.json())
            except Exception as e:
                return _error_result(
                    f"Action '{action_name}' polling failed: {e}",
                )

    if resp.status_code == 202 and not wait:
        location = resp.headers.get("Location", "")
        return _json_result({
            "action": action_name,
            "status": "accepted",
            "message": "Action started. Use the location to poll for status.",
            "location": location,
        })

    return _error_from_response(f"Action '{action_name}' failed on '{endpoint}'", resp)


# ========================== FILE TOOLS ==========================

@mcp.tool()
def get_file(
    file_id: str,
) -> str:
    """
    Download a file attachment from Acumatica by its file ID.

    File IDs are found in entity records when expanding file-related
    detail entities, or from the 'files' collection on a record.

    Args:
        file_id: The Acumatica file ID (GUID format).

    Returns:
        JSON with file metadata. The binary content is base64-encoded
        if small enough, otherwise a summary is returned.
    """
    guard = _require_connection()
    if guard:
        return guard
    import base64

    logger.info(f"Downloading file {file_id}")
    resp = api.get_binary(f"{api.entity_base}/files/{file_id}")

    if resp.status_code != 200:
        return _error_from_response(f"File download failed for '{file_id}'", resp)

    content_type = resp.headers.get("Content-Type", "application/octet-stream")
    content_disp = resp.headers.get("Content-Disposition", "")
    filename = ""
    if "filename=" in content_disp:
        filename = content_disp.split("filename=")[-1].strip('" ')

    size = len(resp.content)

    # For files under 1MB, include base64 content
    if size <= 1_048_576:
        return _json_result({
            "file_id": file_id,
            "filename": filename,
            "content_type": content_type,
            "size_bytes": size,
            "content_base64": base64.b64encode(resp.content).decode("ascii"),
        })

    return _json_result({
        "file_id": file_id,
        "filename": filename,
        "content_type": content_type,
        "size_bytes": size,
        "message": f"File is {size:,} bytes. Too large to include inline.",
    })


@mcp.tool()
def put_file(
    endpoint: str,
    keys: list[str],
    filename: str,
    content_base64: str,
    comment: str | None = None,
) -> str:
    """
    Upload a file attachment to an Acumatica record.

    Args:
        endpoint: Entity name the file attaches to, e.g. 'SalesOrder'.
        keys: List of key values identifying the record.
              E.g. ["SO", "SO-001234"] for a SalesOrder.
        filename: Name for the uploaded file, e.g. 'packing-slip.pdf'.
        content_base64: Base64-encoded file content.
        comment: Optional file comment (Acumatica 2024R2+).

    Returns:
        JSON confirming the upload.
    """
    guard = _guard_and_validate_endpoint(endpoint)
    if guard:
        return guard
    import base64

    try:
        content = base64.b64decode(content_base64)
    except Exception as e:
        return _error_result(f"Invalid base64 content: {e}")

    key_path = "/".join(keys)
    path = f"{api.entity_base}/{endpoint}/{key_path}/files/{filename}"

    logger.info(f"Uploading {filename} ({len(content):,} bytes) to {endpoint}/{key_path}")

    headers = {"Content-Type": "application/octet-stream"}
    if comment:
        headers["PX-CbFileComment"] = comment

    resp = api.put_binary(path, content=content, filename=filename)

    if resp.status_code not in (200, 204):
        return _error_from_response(f"File upload failed for '{filename}'", resp)

    return _json_result({
        "success": True,
        "filename": filename,
        "size_bytes": len(content),
        "attached_to": f"{endpoint}/{key_path}",
    })


# ========================== INVENTORY TOOL ==========================

@mcp.tool()
def check_inventory(
    inventory_id: str,
    warehouse: str | None = None,
    raw: bool = False,
) -> str:
    """
    Check stock availability for an item across warehouses.

    Queries the InventorySummary endpoint for on-hand, available,
    and allocated quantities broken down by warehouse.

    Args:
        inventory_id: The Inventory ID / SKU to look up.
                      E.g. '59-111', 'AALBORG-T'.
        warehouse: Optional warehouse ID to filter to a single warehouse.
                   If omitted, returns all warehouses that hold this item.

    Returns:
        JSON with availability details per warehouse.
    """
    guard = _require_connection()
    if guard:
        return guard
    params = {
        "$filter": f"InventoryID eq '{inventory_id}'",
        "$top": "100",
    }
    if warehouse:
        params["$filter"] += f" and WarehouseID eq '{warehouse}'"

    # Use discovery cache to decide whether InventorySummary exists on this tenant
    disco = _get_discovery()
    inv_entities = disco.get("inventory_entities", [])
    use_summary = "InventorySummary" in inv_entities if inv_entities else True

    logger.info(f"Checking inventory for {inventory_id} (warehouse: {warehouse or 'all'})")

    if use_summary:
        resp = api.get(f"{api.entity_base}/InventorySummary", params)
    else:
        # Skip InventorySummary — discovery confirmed it doesn't exist
        resp = type("FakeResp", (), {"status_code": 404, "text": "skipped by discovery"})()

    if resp.status_code == 200:
        data = resp.json()
        if isinstance(data, list):
            summary = []
            for row in data:
                summary.append({
                    "warehouse": api.extract_value(row.get("WarehouseID")),
                    "location": api.extract_value(row.get("LocationID")),
                    "on_hand": api.extract_value(row.get("QtyOnHand")),
                    "available": api.extract_value(row.get("QtyAvailable")),
                    "not_available": api.extract_value(row.get("QtyNotAvailable")),
                    "on_purchase_orders": api.extract_value(row.get("QtyOnPurchaseOrders")),
                    "on_sales_orders": api.extract_value(row.get("QtyOnSalesOrders")),
                    "on_production_orders": api.extract_value(row.get("QtyOnProductionOrders")),
                })

            return _json_result({
                "inventory_id": inventory_id,
                "warehouse_filter": warehouse,
                "locations_found": len(summary),
                "availability": summary,
            })

        return _json_result(data)

    # Fallback: try StockItem with WarehouseDetails expansion
    logger.info("InventorySummary not available, falling back to StockItem + WarehouseDetails")
    params2 = {
        "$filter": f"InventoryID eq '{inventory_id}'",
        "$expand": "WarehouseDetails",
    }

    resp2 = api.get(f"{api.entity_base}/StockItem", params2)

    if resp2.status_code != 200:
        return _error_result(
            f"Could not retrieve inventory for {inventory_id}. "
            f"Tried InventorySummary (HTTP {resp.status_code}) and "
            f"StockItem (HTTP {resp2.status_code}).",
            status_code=resp2.status_code,
            detail=resp2.text,
        )

    data2 = resp2.json()
    items = data2 if isinstance(data2, list) else [data2]

    if raw:
        return _json_result({
            "inventory_id": inventory_id,
            "source": "StockItem/WarehouseDetails",
            "data": _shape(data2, compact=False),
        })

    # Shape to the focused availability response
    warehouses_out = []
    description = None
    for item in items:
        description = api.extract_value(item.get("Description")) or description
        for wh in item.get("WarehouseDetails", []) or []:
            wh_id = api.extract_value(wh.get("WarehouseID"))
            if warehouse and wh_id != warehouse:
                continue
            warehouses_out.append({
                "warehouse_id": wh_id,
                "qty_on_hand": api.extract_value(wh.get("QtyOnHand")),
                "qty_available": api.extract_value(wh.get("QtyAvailable")),
                "qty_hard_available": api.extract_value(wh.get("QtyHardAvailable")),
                "preferred_vendor": api.extract_value(wh.get("PreferredVendor")),
                "status": api.extract_value(wh.get("Status")),
            })

    return _json_result({
        "inventory_id": inventory_id,
        "description": description,
        "source": "StockItem/WarehouseDetails",
        "warehouses": warehouses_out,
    })


# ========================== SHIPMENT TRACKING TOOL ==========================

@mcp.tool()
def track_shipment(
    shipment_nbr: str | None = None,
    sales_order: str | None = None,
    tracking_number: str | None = None,
    top: int = 20,
    raw: bool = False,
) -> str:
    """
    Look up shipment details and tracking information.

    Provide at least one of: shipment number, sales order number,
    or tracking number.

    Args:
        shipment_nbr: Acumatica Shipment Number to look up directly.
        sales_order: Sales Order number — finds all shipments for that SO.
        tracking_number: Carrier tracking number to search for.
        top: Max shipments to return. Default 20.

    Returns:
        JSON with shipment details, status, and tracking URLs where available.
    """
    guard = _require_connection()
    if guard:
        return guard
    shipments = []

    # Strategy 1: Direct shipment lookup
    if shipment_nbr:
        params = {
            "$filter": f"ShipmentNbr eq '{shipment_nbr}'",
            "$expand": "Packages",
            "$top": "1",
        }
        resp = api.get(f"{api.entity_base}/Shipment", params)
        if resp.status_code == 200:
            data = resp.json()
            shipments = data if isinstance(data, list) else [data]

    # Strategy 2: Find shipments by sales order
    elif sales_order:
        params = {
            "$filter": f"OrderNbr eq '{sales_order}'",
            "$expand": "Shipments",
            "$top": "1",
        }
        resp = api.get(f"{api.entity_base}/SalesOrder", params)
        if resp.status_code == 200:
            data = resp.json()
            so_list = data if isinstance(data, list) else [data]
            if so_list:
                so = so_list[0]
                linked_shipments = so.get("Shipments", [])
                for link in linked_shipments[:top]:
                    snbr = api.extract_value(link.get("ShipmentNbr"))
                    if snbr:
                        s_resp = api.get(
                            f"{api.entity_base}/Shipment",
                            {"$filter": f"ShipmentNbr eq '{snbr}'", "$expand": "Packages"},
                        )
                        if s_resp.status_code == 200:
                            s_data = s_resp.json()
                            if isinstance(s_data, list):
                                shipments.extend(s_data)
                            else:
                                shipments.append(s_data)

    # Strategy 3: Search by tracking number across packages
    elif tracking_number:
        params = {"$top": "200", "$expand": "Packages"}
        resp = api.get(f"{api.entity_base}/Shipment", params)
        if resp.status_code == 200:
            data = resp.json()
            if not isinstance(data, list):
                data = [data]
            track_lower = tracking_number.lower()
            for shipment in data:
                packages = shipment.get("Packages", [])
                for pkg in packages:
                    tn = api.extract_value(pkg.get("TrackingNbr", ""))
                    if isinstance(tn, str) and track_lower in tn.lower():
                        shipments.append(shipment)
                        break
                if len(shipments) >= top:
                    break
    else:
        return _error_result("Provide at least one of: shipment_nbr, sales_order, or tracking_number.")

    if not shipments:
        return _json_result({"matches_found": 0, "message": "No shipments found matching the criteria."})

    if raw:
        return _json_result({
            "matches_found": len(shipments),
            "shipments": _shape(shipments[:top], compact=False),
        })

    # Build enriched results with tracking URLs
    results = []
    for shipment in shipments[:top]:
        carrier = api.extract_value(shipment.get("ShipVia", "")) or ""
        packages = shipment.get("Packages", [])

        package_info = []
        for pkg in packages:
            tn = api.extract_value(pkg.get("TrackingNbr", ""))
            tracking_url = api.get_tracking_url(carrier, tn) if tn else None

            package_info.append({
                "tracking_number": tn,
                "tracking_url": tracking_url,
                "weight": api.extract_value(pkg.get("Weight")),
                "box_id": api.extract_value(pkg.get("BoxID")),
            })

        # ShipmentDate is the correct Contract-Based API field; fall back to
        # ShipDate on older tenants that still expose it.
        ship_date = (
            api.extract_value(shipment.get("ShipmentDate"))
            or api.extract_value(shipment.get("ShipDate"))
        )

        results.append({
            "shipment_nbr": api.extract_value(shipment.get("ShipmentNbr")),
            "status": api.extract_value(shipment.get("Status")),
            "ship_date": ship_date,
            "ship_via": carrier,
            "customer_id": api.extract_value(shipment.get("CustomerID")),
            "shipped_qty": api.extract_value(shipment.get("ShippedQty")),
            "packages": package_info,
        })

    return _json_result({"matches_found": len(results), "shipments": results})


@mcp.tool()
def patch_record(
    endpoint: str,
    data: dict,
    expand: str | None = None,
) -> str:
    """
    Partially update a record — only the fields specified in data are changed.

    Unlike update_record (which uses PUT), PATCH only modifies the fields
    explicitly included in the request body. All other fields are left exactly
    as they are in Acumatica. Use this when you want to change one or two fields
    without needing to re-specify the whole record.

    The data dict MUST include the key field(s) to identify the record.

    Args:
        endpoint: Entity name, e.g. 'SalesOrder', 'Customer', 'StockItem'.
        data: Dict with key fields + the specific fields to update.
              Use {"value": x} format. E.g.:
              {
                  "OrderType": {"value": "SO"},
                  "OrderNbr": {"value": "SO-001234"},
                  "Hold": {"value": false}
              }
        expand: Comma-separated detail entities to include in the response.

    Returns:
        JSON with the updated record.
    """
    guard = _guard_and_validate_endpoint(endpoint)
    if guard:
        return guard
    params = {}
    if expand:
        params["$expand"] = expand

    logger.info(f"Patching {endpoint} record")
    resp = api.patch(f"{api.entity_base}/{endpoint}", body=data, params=params)

    if resp.status_code != 200:
        return _error_from_response(f"Patch failed for '{endpoint}'", resp)

    return _json_result(resp.json())


@mcp.tool()
def delete_record(
    endpoint: str,
    keys: list[str],
) -> str:
    """
    Delete a record by its key field values.

    Key values are passed as URL path segments in order, matching the same
    pattern as get_record_by_keys.

    WARNING: This is irreversible. Acumatica may also reject deletion if the
    record has dependencies (e.g. a Customer with open invoices).

    Args:
        endpoint: Entity name, e.g. 'StockItem', 'SalesOrder', 'Customer'.
        keys: List of key values in order. E.g.:
              - StockItem: ["WIDGET-01"]
              - SalesOrder: ["SO", "SO-001234"]

    Returns:
        JSON confirming the deletion.
    """
    guard = _guard_and_validate_endpoint(endpoint)
    if guard:
        return guard
    key_path = "/".join(keys)
    path = f"{api.entity_base}/{endpoint}/{key_path}"

    logger.info(f"Deleting {endpoint}/{key_path}")
    resp = api.delete(path)

    if resp.status_code not in (200, 204):
        return _error_from_response(f"Delete failed for {endpoint}/{key_path}", resp)

    return _json_result({
        "success": True,
        "deleted": f"{endpoint}/{key_path}",
    })


@mcp.tool()
def get_acumatica_version() -> str:
    """
    Retrieve the Acumatica ERP version and the list of all available endpoints.

    Uses the tenant discovery cache (fast) with a live fallback to /entity
    (may be slow on some tenants — capped at 15s). Useful for verifying
    connectivity, checking the API version, and discovering non-Default
    endpoints (e.g. custom endpoints, manufacturing, payroll).

    Returns:
        JSON with version information and endpoint list.
    """
    guard = _require_connection()
    if guard:
        return guard

    # Prefer the discovery cache — it already has the endpoint map
    disco = _get_discovery()
    ep_map = disco.get("endpoints", {})
    if ep_map:
        return _json_result({
            "api_version": api.api_version,
            "source": "discovery_cache",
            "endpoints": ep_map,
            "report_endpoint_version": disco.get("report_endpoint_version"),
            "ar_invoice_entity": disco.get("ar_invoice_entity"),
        })

    # Fallback: live call with a timeout cap so we don't hang for 60s
    try:
        resp = api.get("/entity", timeout=15)
    except Exception as e:
        return _error_result(f"Failed to retrieve Acumatica version (timeout): {e}")

    if resp.status_code != 200:
        return _error_from_response("Failed to retrieve Acumatica version", resp)

    return _json_result(resp.json())


@mcp.tool()
def get_customer_balance(
    customer_id: str,
    include_open_documents: bool = True,
) -> str:
    """
    Get the AR balance, credit status, and open invoices for a customer.

    Returns credit limit, current balance, available credit, and optionally
    a breakdown of open AR documents (invoices, credit notes, debit memos).

    Args:
        customer_id: The Customer ID / account code to look up.
        include_open_documents: Include individual open AR documents.
                                Default True.

    Returns:
        JSON with balance summary and, if requested, open document list.
    """
    guard = _require_connection()
    if guard:
        return guard
    # NOTE: No $select. Field availability on the Customer DAC varies across
    # tenants/versions (e.g. some 500 on CreditRule, PrepaymentBalance,
    # UnreleasedBalance, RetainageBalance). Fetching the full record and
    # plucking defensively is more robust than guessing a valid projection.
    resp = api.get(
        f"{api.entity_base}/Customer",
        {
            "$filter": f"CustomerID eq '{customer_id}'",
            "$top": "1",
        },
    )

    if resp.status_code != 200:
        return _error_from_response(f"Customer lookup failed for '{customer_id}'", resp)

    data = resp.json()
    customers = data if isinstance(data, list) else [data]

    if not customers:
        return _error_result(f"Customer '{customer_id}' not found.")

    c = customers[0]

    def _pluck_num(*field_names: str) -> float | None:
        """Return the first non-null numeric value for any of the given fields."""
        for fn in field_names:
            v = api.extract_value(c.get(fn))
            if v is not None:
                try:
                    return float(v)
                except (TypeError, ValueError):
                    return v
        return None

    credit_limit = _pluck_num("CreditLimit", "CreditLimitAmt") or 0
    balance = _pluck_num("Balance", "CurrentBalance", "CuryBalance") or 0

    result = {
        "customer_id": api.extract_value(c.get("CustomerID")),
        "customer_name": api.extract_value(c.get("CustomerName")) or api.extract_value(c.get("AcctName")),
        "credit_limit": credit_limit,
        "credit_rule": api.extract_value(c.get("CreditRule")),
        "current_balance": balance,
        "prepayment_balance": _pluck_num("PrepaymentBalance", "PrepaidBalance"),
        "unreleased_balance": _pluck_num("UnreleasedBalance"),
        "retainage_balance": _pluck_num("RetainageBalance"),
        "overdue_balance": _pluck_num("OverdueBalance"),
    }

    # Drop keys whose values are None so the response doesn't mislead about
    # fields the tenant doesn't expose.
    result = {k: v for k, v in result.items() if v is not None}

    if credit_limit:
        result["available_credit"] = credit_limit - balance
        result["credit_utilisation_pct"] = round((balance / credit_limit) * 100, 1)

    if not include_open_documents:
        return _json_result(result)

    # Fetch open AR documents — again no $select, for the same robustness reason.
    # Entity name varies by tenant/endpoint: ARInvoice (classic Default),
    # Invoice (modern Default), SalesInvoice (Distribution/SalesOrder setups).
    # Use the discovery cache to skip probing when possible.
    disco = _get_discovery()
    discovered_ar = disco.get("ar_invoice_entity")
    ar_candidates = (
        [discovered_ar] if discovered_ar
        else ["ARInvoice", "Invoice", "SalesInvoice"]
    )
    ar_resp = None
    ar_entity_used = None
    ar_attempts: list[str] = []
    for candidate in ar_candidates:
        resp_try = api.get(
            f"{api.entity_base}/{candidate}",
            {
                "$filter": f"CustomerID eq '{customer_id}' and Status eq 'Open'",
                "$orderby": "DueDate asc",
                "$top": "50",
            },
        )
        if resp_try.status_code == 200:
            ar_resp = resp_try
            ar_entity_used = candidate
            break
        ar_attempts.append(f"{candidate} → HTTP {resp_try.status_code}")

    if ar_resp is not None and ar_resp.status_code == 200:
        ar_data = ar_resp.json()
        invoices = ar_data if isinstance(ar_data, list) else [ar_data]

        def _inv_num(inv: dict, *field_names: str) -> float | None:
            for fn in field_names:
                v = api.extract_value(inv.get(fn))
                if v is not None:
                    try:
                        return float(v)
                    except (TypeError, ValueError):
                        return v
            return None

        open_docs = []
        total_open = 0.0

        for inv in invoices:
            doc_balance = _inv_num(inv, "CuryDocBal", "DocBal", "Balance") or 0
            original = _inv_num(inv, "OrigDocAmt", "OrigDocAmount", "Amount")
            total_open += doc_balance
            open_docs.append({
                "ref_nbr": api.extract_value(inv.get("ReferenceNbr")),
                "doc_type": api.extract_value(inv.get("DocType")) or api.extract_value(inv.get("Type")),
                "doc_date": api.extract_value(inv.get("DocDate")) or api.extract_value(inv.get("Date")),
                "due_date": api.extract_value(inv.get("DueDate")),
                "original_amount": original,
                "balance": doc_balance,
            })

        result["open_document_count"] = len(open_docs)
        result["total_open_balance"] = total_open
        result["open_documents"] = open_docs
        result["open_documents_source"] = ar_entity_used
    else:
        # Don't fail the whole tool if AR lookup blows up — surface it as a warning.
        result["open_documents_error"] = (
            "AR document lookup failed across all candidate entities. "
            + "; ".join(ar_attempts)
        )

    return _json_result(result)


@mcp.tool()
def run_report(
    report_name: str,
    parameters: dict | None = None,
    format: str = "pdf",
    endpoint: str = "Report",
    version: str = "auto",
    timeout: int = 120,
) -> str:
    """
    Generate an Acumatica report and return the output as base64-encoded content.

    Uses Acumatica's async report API: POST to start generation (202 + Location
    header), then polls that URL until the report is ready (200 + binary bytes).

    STANDALONE REPORTS (default) — use the Report endpoint:
      endpoint="Report" (default), version="auto" (discovered).
      report_name is the Acumatica report name (not the Screen ID).
      Parameters use {"value": x} format.
      Examples:
        CashAccountSummary:
          report_name="CashAccountSummary",
          parameters={"CompanyBranch": {"value": "MAIN"}}
        AR Aging:
          report_name="ARAgingReport",
          parameters={"AgingBy": {"value": "Due Date"}}

    REQUIRES: the 'Report' endpoint to be deployed on the tenant (added via
    SM207060 → Web Services Endpoints). If it isn't, this tool returns a
    clean 404 listing the endpoints that ARE available, so an admin can see
    what's missing.

    DOCUMENT REPORTS (historical syntax) — not supported on Acumatica 22R1+.
    Modern tenants route document reports through the Screen API, which this
    MCP does not yet expose. Requests for document reports via the Default
    endpoint will return a 500 "NonReportEntityCannotBeUsedAsReportException"
    from the tenant. Use the Acumatica UI or an explicit screen-api call for
    document PDFs until screen-API support is added.

    Args:
        report_name: Report name (standalone) or entity name (document report).
        parameters: Report parameters or document key fields in {"value": x} format.
        format: 'pdf', 'html', or 'excel'. Default 'pdf'.
        endpoint: 'Report' for standalone reports, 'Default' for document reports.
        version: Endpoint version. Default 'auto' — discovers the latest
                 version actually deployed on the tenant. Pass an explicit
                 string (e.g. '24.200.001') only to pin a specific version.
        timeout: Max seconds to wait for generation. Default 120.

    Returns:
        JSON with base64-encoded report content.
    """
    guard = _require_connection()
    if guard:
        return guard

    # Validate format parameter
    fmt_lower = format.lower().strip()
    if fmt_lower not in _VALID_REPORT_FORMATS and fmt_lower not in ("html", "excel"):
        return _error_result(
            f"Invalid report format '{format}'. "
            f"Allowed values: pdf, html, excel, xlsx, csv, docx."
        )

    import base64

    # Version resolution: use discovery cache for Report, api_version for Default.
    if version in ("0001", "auto"):
        if endpoint == "Default":
            resolved_version = api.api_version
        else:
            disco = _get_discovery()
            resolved_version = disco.get("report_endpoint_version") or "auto"
    else:
        resolved_version = version

    logger.info(f"Starting report {endpoint}/{resolved_version}/{report_name}")
    try:
        location = api.start_report(
            report_name=report_name,
            parameters=parameters or {},
            format=format,
            endpoint=endpoint,
            version=resolved_version,
        )
    except Exception as e:
        return _error_result(f"Failed to start report '{report_name}': {e}")

    logger.info(f"Polling report: {location}")
    try:
        content = api.poll_report(location, timeout=float(timeout))
    except Exception as e:
        return _error_result(f"Report generation failed: {e}")

    return _json_result({
        "report_name": report_name,
        "format": format,
        "size_bytes": len(content),
        "content_base64": base64.b64encode(content).decode("ascii"),
    })


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    mcp.run(transport="stdio")
