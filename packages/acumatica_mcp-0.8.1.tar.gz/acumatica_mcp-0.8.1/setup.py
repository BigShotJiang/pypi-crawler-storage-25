#!/usr/bin/env python3
"""
Interactive setup for the Acumatica MCP connector.

Handles two things:
  1. Credentials — walks the user through entering Acumatica connection
     details and writes a .env file the server reads on startup.
  2. Registration — adds (or updates) the MCP server entry in
     claude_desktop_config.json so Claude Desktop / Cowork starts the
     server automatically. No manual JSON editing required.

Usage:
    python setup.py              # interactive mode (credentials + registration + test)
    python setup.py --test       # test the connection (login + discover endpoints)
    python setup.py --check      # verify the current .env is valid (no network call)
    python setup.py --register   # only register in Claude Desktop config (skip credentials)
    python setup.py --unregister # remove from Claude Desktop config

    # Headless mode — supply credentials via CLI args (no prompts):
    python setup.py --url https://my.acumatica.com --company MyTenant \\
                    --user apiuser --pass secret --no-register
    python setup.py --url https://my.acumatica.com --company MyTenant \\
                    --client-id ABC --client-secret XYZ --no-register --no-test
"""

import argparse
import json
import os
import platform
import shutil
import subprocess
import sys
from pathlib import Path

# ---------------------------------------------------------------------------
# Paths
# ---------------------------------------------------------------------------
SERVERS_DIR = Path(__file__).parent.resolve()
ENV_PATH = SERVERS_DIR / ".env"
SERVER_SCRIPT = SERVERS_DIR / "server.py"


def _claude_desktop_config_path() -> Path:
    """Return the platform-specific path to claude_desktop_config.json."""
    system = platform.system()
    if system == "Darwin":
        return Path.home() / "Library" / "Application Support" / "Claude" / "claude_desktop_config.json"
    elif system == "Windows":
        appdata = Path(os.environ.get("APPDATA", Path.home() / "AppData" / "Roaming"))
        return appdata / "Claude" / "claude_desktop_config.json"
    else:
        # Linux / other — XDG_CONFIG_HOME or ~/.config
        xdg = Path(os.environ.get("XDG_CONFIG_HOME", Path.home() / ".config"))
        return xdg / "Claude" / "claude_desktop_config.json"


def _find_uv() -> str:
    """Find the absolute path to the uv binary, or fall back to 'uv'.

    On Windows, GUI apps inherit the system PATH so shutil.which() usually
    works. On macOS, GUI apps don't read shell profiles (.zshrc, .bashrc),
    so we also check common install locations.
    """
    uv_path = shutil.which("uv")
    if uv_path:
        return str(Path(uv_path).resolve())

    # Platform-specific common install locations
    candidates: list[Path] = []
    if platform.system() == "Windows":
        # Standard uv install location on Windows
        local_app = Path(os.environ.get("LOCALAPPDATA", Path.home() / "AppData" / "Local"))
        candidates = [
            local_app / "uv" / "uv.exe",
            Path.home() / ".cargo" / "bin" / "uv.exe",
        ]
    else:
        # macOS / Linux
        candidates = [
            Path.home() / ".local" / "bin" / "uv",
            Path.home() / ".cargo" / "bin" / "uv",
            Path("/usr/local/bin/uv"),
        ]

    for candidate in candidates:
        if candidate.exists():
            return str(candidate)
    return "uv"


# ---------------------------------------------------------------------------
# Credential variables
# ---------------------------------------------------------------------------
COMMON_VARS = [
    ("ACUMATICA_URL", "Acumatica instance URL (e.g. https://mycompany.acumatica.com)", True),
    ("ACUMATICA_COMPANY", "Company / tenant name", True),
    ("ACUMATICA_API_VERSION", "API version (press Enter for default: 24.200.001)", False),
    ("ACUMATICA_BRANCH", "Branch name (press Enter to skip — only needed for multi-branch)", False),
]

BASIC_VARS = [
    ("ACUMATICA_USER", "API username", True),
    ("ACUMATICA_PASS", "API password", True),
]

OAUTH_VARS = [
    ("ACUMATICA_CLIENT_ID", "OAuth Client ID (from SM303010 Connected Applications)", True),
    ("ACUMATICA_CLIENT_SECRET", "OAuth Client Secret", True),
    ("ACUMATICA_OAUTH_SCOPE", "OAuth scopes (press Enter for default: api offline_access)", False),
    ("ACUMATICA_OAUTH_PORT", "Local callback port (press Enter for default: 8742)", False),
]


# ---------------------------------------------------------------------------
# .env handling
# ---------------------------------------------------------------------------
def read_existing_env() -> dict[str, str]:
    """Read current .env file into a dict, if it exists."""
    if not ENV_PATH.exists():
        return {}
    values = {}
    for line in ENV_PATH.read_text().splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        if "=" in line:
            key, _, value = line.partition("=")
            values[key.strip()] = value.strip()
    return values


def prompt_var(name: str, description: str, required: bool, current: str = "") -> str:
    """Prompt for a single variable, showing current value if any."""
    default_hint = f" [{current}]" if current else ""
    required_hint = " (required)" if required else ""

    while True:
        value = input(f"  {description}{required_hint}{default_hint}: ").strip()
        if not value and current:
            return current
        if not value and not required:
            return ""
        if not value and required:
            print("    This field is required.")
            continue
        return value


def write_env(values: dict[str, str]) -> None:
    """Write the .env file."""
    lines = [
        "# Acumatica MCP Connector — generated by setup.py",
        "# Edit this file to change credentials, or re-run: python setup.py",
        "",
    ]

    has_oauth = bool(values.get("ACUMATICA_CLIENT_ID"))

    lines.append("# --- Connection ---")
    for key in ["ACUMATICA_URL", "ACUMATICA_COMPANY", "ACUMATICA_API_VERSION", "ACUMATICA_BRANCH"]:
        if values.get(key):
            lines.append(f"{key}={values[key]}")

    lines.append("")
    if has_oauth:
        lines.append("# --- OAuth 2.0 credentials ---")
        for key in ["ACUMATICA_CLIENT_ID", "ACUMATICA_CLIENT_SECRET", "ACUMATICA_OAUTH_SCOPE", "ACUMATICA_OAUTH_PORT"]:
            if values.get(key):
                lines.append(f"{key}={values[key]}")
    else:
        lines.append("# --- Username / Password credentials ---")
        for key in ["ACUMATICA_USER", "ACUMATICA_PASS"]:
            if values.get(key):
                lines.append(f"{key}={values[key]}")

    lines.append("")
    ENV_PATH.write_text("\n".join(lines))


def check_env() -> bool:
    """Validate the current .env file. Returns True if usable."""
    if not ENV_PATH.exists():
        print(f"No .env file found at {ENV_PATH}")
        print("Run 'python setup.py' to create one.")
        return False

    values = read_existing_env()

    issues = []
    if not values.get("ACUMATICA_URL"):
        issues.append("ACUMATICA_URL is missing")
    if not values.get("ACUMATICA_COMPANY"):
        issues.append("ACUMATICA_COMPANY is missing")

    has_basic = bool(values.get("ACUMATICA_USER")) and bool(values.get("ACUMATICA_PASS"))
    has_oauth = bool(values.get("ACUMATICA_CLIENT_ID")) and bool(values.get("ACUMATICA_CLIENT_SECRET"))

    if not has_basic and not has_oauth:
        issues.append(
            "No auth credentials — need ACUMATICA_USER + ACUMATICA_PASS "
            "or ACUMATICA_CLIENT_ID + ACUMATICA_CLIENT_SECRET"
        )

    if issues:
        print(f".env file at {ENV_PATH} has issues:")
        for issue in issues:
            print(f"  - {issue}")
        return False

    auth_mode = "OAuth 2.0" if has_oauth else "Username/Password"
    print(".env file is valid:")
    print(f"  URL:       {values.get('ACUMATICA_URL')}")
    print(f"  Company:   {values.get('ACUMATICA_COMPANY')}")
    print(f"  Auth mode: {auth_mode}")
    if values.get("ACUMATICA_API_VERSION"):
        print(f"  API ver:   {values.get('ACUMATICA_API_VERSION')}")
    return True


# ---------------------------------------------------------------------------
# Claude Desktop config registration
# ---------------------------------------------------------------------------
MCP_SERVER_KEY = "acumatica"


def _read_claude_config() -> dict:
    """Read claude_desktop_config.json, creating it if it doesn't exist."""
    config_path = _claude_desktop_config_path()
    if config_path.exists():
        return json.loads(config_path.read_text())
    return {}


def _write_claude_config(config: dict) -> None:
    """Write claude_desktop_config.json, creating parent directories if needed."""
    config_path = _claude_desktop_config_path()
    config_path.parent.mkdir(parents=True, exist_ok=True)
    config_path.write_text(json.dumps(config, indent=2) + "\n")


def _build_server_entry() -> dict:
    """Build the MCP server entry for claude_desktop_config.json."""
    uv_path = _find_uv()
    return {
        "command": uv_path,
        "args": [
            "run",
            "--directory",
            str(SERVERS_DIR),
            "python",
            "server.py",
        ],
    }


def register_in_claude_desktop() -> bool:
    """Add or update the Acumatica MCP server in claude_desktop_config.json.

    Returns True if the config was changed, False if already up to date.
    """
    config = _read_claude_config()
    config.setdefault("mcpServers", {})

    new_entry = _build_server_entry()
    existing = config["mcpServers"].get(MCP_SERVER_KEY)

    if existing == new_entry:
        return False  # Already registered with the same config

    config["mcpServers"][MCP_SERVER_KEY] = new_entry
    _write_claude_config(config)
    return True


def unregister_from_claude_desktop() -> bool:
    """Remove the Acumatica MCP server from claude_desktop_config.json.

    Returns True if the entry was removed, False if it wasn't present.
    """
    config = _read_claude_config()
    servers = config.get("mcpServers", {})

    if MCP_SERVER_KEY not in servers:
        return False

    del servers[MCP_SERVER_KEY]
    _write_claude_config(config)
    return True


# ---------------------------------------------------------------------------
# Connection test
# ---------------------------------------------------------------------------
def test_connection() -> bool:
    """Actually connect to Acumatica and report what we find.

    Returns True on success, False on failure.
    """
    values = read_existing_env()
    if not values.get("ACUMATICA_URL"):
        print("  No .env file or missing URL — run setup first.")
        return False

    url = values["ACUMATICA_URL"]
    company = values.get("ACUMATICA_COMPANY", "")
    api_version = values.get("ACUMATICA_API_VERSION", "24.200.001")
    has_oauth = bool(values.get("ACUMATICA_CLIENT_ID"))
    auth_label = "OAuth 2.0" if has_oauth else "Username/Password"

    print(f"  URL:       {url}")
    print(f"  Company:   {company}")
    print(f"  Auth:      {auth_label}")
    print(f"  API ver:   {api_version}")
    print()

    # --- Import the client (only needed for test, not for setup) ---
    sys.path.insert(0, str(SERVERS_DIR))
    try:
        from acumatica_client import AcumaticaClient, AcumaticaConfigError
    except ImportError:
        print("  FAIL: Could not import acumatica_client.py")
        print("        Make sure you're running from the servers/ directory.")
        return False

    # --- Create client and attempt login ---
    print("  Connecting...")
    try:
        client = AcumaticaClient()
    except AcumaticaConfigError as e:
        print(f"  FAIL: Configuration error — {e}")
        _print_config_advice(str(e))
        return False

    try:
        client.login()
    except Exception as e:
        err = str(e)
        print(f"  FAIL: Login failed — {err}")
        _print_login_advice(err, url, auth_label)
        return False

    print("  Login successful.")
    print()

    # --- Discover endpoints ---
    print("  Discovering tenant capabilities...")
    try:
        disco = client.discover()
    except Exception as e:
        print(f"  WARNING: Discovery failed — {e}")
        print("  Login worked, but discovery didn't complete.")
        print("  The connector will still work, but some features may be limited.")
        return True  # login succeeded, so connection is valid

    # --- Report what we found ---
    endpoints = disco.get("endpoints", {})
    if endpoints:
        total_eps = len(endpoints)
        total_versions = sum(len(v) for v in endpoints.values())
        print(f"  Endpoints:  {total_eps} found ({total_versions} versions total)")
        for name, versions in sorted(endpoints.items()):
            print(f"              {name}: {', '.join(sorted(versions))}")
    else:
        print("  Endpoints:  none discovered (check API version)")

    # --- GI access ---
    gi_prefix = disco.get("odata_gi_prefix")
    if gi_prefix:
        print(f"  GI access:  available ({gi_prefix})")
    else:
        print("  GI access:  not detected")

    # --- Entity availability ---
    inv_entities = disco.get("inventory_entities", [])
    if inv_entities:
        print(f"  Inventory:  {', '.join(inv_entities)}")

    ar_entity = disco.get("ar_invoice_entity")
    if ar_entity:
        print(f"  AR entity:  {ar_entity}")

    report_ver = disco.get("report_endpoint_version")
    if report_ver:
        print(f"  Reports:    available (endpoint version {report_ver})")

    print()
    print("  Connection test PASSED.")
    return True


def _print_config_advice(error: str) -> None:
    """Print targeted advice for configuration errors."""
    err_lower = error.lower()
    if "url" in err_lower:
        print()
        print("  Advice: Check ACUMATICA_URL in your .env file.")
        print("          It should be the base URL with no trailing slash,")
        print("          e.g. https://mycompany.acumatica.com")
    elif "company" in err_lower:
        print()
        print("  Advice: Check ACUMATICA_COMPANY in your .env file.")
        print("          This is the tenant/company name shown in Acumatica's login screen.")
    elif "auth" in err_lower or "credential" in err_lower:
        print()
        print("  Advice: Your .env needs either:")
        print("          - ACUMATICA_USER + ACUMATICA_PASS (basic auth)")
        print("          - ACUMATICA_CLIENT_ID + ACUMATICA_CLIENT_SECRET (OAuth)")


def _print_login_advice(error: str, url: str, auth_label: str) -> None:
    """Print targeted advice for common login failures."""
    err_lower = error.lower()

    if "401" in err_lower or "unauthorized" in err_lower:
        print()
        print("  Advice: Credentials were rejected by Acumatica.")
        if "oauth" in auth_label.lower():
            print("          - Check CLIENT_ID and CLIENT_SECRET in .env")
            print("          - Verify the Connected Application is active in SM303010")
            print("          - Check the OAuth scope includes 'api'")
        else:
            print("          - Check username and password in .env")
            print("          - Verify the API user account is active and not locked")
            print("          - Check the user has API access rights")
    elif "ssl" in err_lower or "certificate" in err_lower:
        print()
        print("  Advice: SSL/certificate error.")
        print("          - If using a self-signed cert, you may need to trust it locally")
        print(f"          - Verify {url} is accessible in a browser")
    elif "timeout" in err_lower or "timed out" in err_lower:
        print()
        print("  Advice: Connection timed out.")
        print(f"          - Check {url} is reachable from this machine")
        print("          - Verify there's no VPN or firewall blocking the connection")
        print("          - Check Acumatica isn't in maintenance mode")
    elif "connection" in err_lower or "resolve" in err_lower or "dns" in err_lower:
        print()
        print("  Advice: Could not reach the server.")
        print(f"          - Check the URL is correct: {url}")
        print("          - Verify DNS resolution and network connectivity")
    elif "403" in err_lower or "forbidden" in err_lower:
        print()
        print("  Advice: Access forbidden (403).")
        print("          - The user account may not have API access enabled")
        print("          - Check user roles include 'Web Service' or equivalent")
    else:
        print()
        print("  Advice: Re-run 'python setup.py' to review your settings.")
        print(f"          Verify {url} is accessible in a browser.")


# ---------------------------------------------------------------------------
# Headless (CLI) credential handling
# ---------------------------------------------------------------------------
def _headless_values_from_args(args: argparse.Namespace) -> dict[str, str] | None:
    """Build credential dict from CLI args, or return None if not enough args supplied.

    Returns a dict ready for write_env() when the user has provided at least --url,
    --company, and one complete auth set (--user + --pass or --client-id + --client-secret).
    Returns None otherwise, signalling that interactive prompts are needed.
    """
    url = getattr(args, "url", None)
    company = getattr(args, "company", None)

    if not url or not company:
        return None

    has_basic = bool(getattr(args, "user", None)) and bool(getattr(args, "password", None))
    has_oauth = bool(getattr(args, "client_id", None)) and bool(getattr(args, "client_secret", None))

    if not has_basic and not has_oauth:
        return None

    values: dict[str, str] = {
        "ACUMATICA_URL": url,
        "ACUMATICA_COMPANY": company,
    }

    if getattr(args, "api_version", None):
        values["ACUMATICA_API_VERSION"] = args.api_version
    if getattr(args, "branch", None):
        values["ACUMATICA_BRANCH"] = args.branch

    if has_oauth:
        values["ACUMATICA_CLIENT_ID"] = args.client_id
        values["ACUMATICA_CLIENT_SECRET"] = args.client_secret
        if getattr(args, "scope", None):
            values["ACUMATICA_OAUTH_SCOPE"] = args.scope
        if getattr(args, "port", None):
            values["ACUMATICA_OAUTH_PORT"] = args.port
    else:
        values["ACUMATICA_USER"] = args.user
        values["ACUMATICA_PASS"] = args.password

    return values


# ---------------------------------------------------------------------------
# Interactive setup
# ---------------------------------------------------------------------------
def run_setup(skip_credentials: bool = False, headless_values: dict[str, str] | None = None,
              no_register: bool = False, no_test: bool = False) -> None:
    """Full setup: credentials + Claude Desktop registration.

    Args:
        skip_credentials: Skip credential prompts entirely (--register mode).
        headless_values: Pre-built credential dict from CLI args (headless mode).
        no_register: Skip Claude Desktop config registration.
        no_test: Skip the connection test after saving credentials.
    """
    print()
    print("=" * 60)
    print("  Acumatica MCP Connector — Setup")
    print("=" * 60)
    print()

    # ---- Step 1: Credentials ----
    mode = "1"  # default for "next steps" messaging
    if headless_values:
        # Headless mode — all values supplied via CLI args
        write_env(headless_values)
        has_oauth = bool(headless_values.get("ACUMATICA_CLIENT_ID"))
        mode = "2" if has_oauth else "1"
        auth_label = "OAuth 2.0" if has_oauth else "Username/Password"
        print(f"  Auth mode:  {auth_label}")
        print(f"  Credentials saved to {ENV_PATH}")
        print()
    elif not skip_credentials:
        existing = read_existing_env()
        if existing:
            print(f"Found existing .env at {ENV_PATH}")
            print("Current values will be shown in [brackets] — press Enter to keep them.")
            print()

        values: dict[str, str] = {}

        print("Connection settings:")
        for name, desc, required in COMMON_VARS:
            value = prompt_var(name, desc, required, existing.get(name, ""))
            if value:
                values[name] = value

        print()
        print("Authentication method:")
        print("  1. Username / Password  (simplest — credentials stored in .env)")
        print("  2. OAuth 2.0            (recommended — browser login, no stored password)")
        print()

        default_mode = "2" if existing.get("ACUMATICA_CLIENT_ID") else "1"
        mode = input(f"  Choose [1/2] (default: {default_mode}): ").strip() or default_mode

        print()
        if mode == "2":
            print("OAuth 2.0 credentials:")
            print("  (Get these from Acumatica -> System -> Integration -> Connected Applications (SM303010))")
            print()
            for name, desc, required in OAUTH_VARS:
                value = prompt_var(name, desc, required, existing.get(name, ""))
                if value:
                    values[name] = value
        else:
            print("Username / Password:")
            for name, desc, required in BASIC_VARS:
                value = prompt_var(name, desc, required, existing.get(name, ""))
                if value:
                    values[name] = value

        write_env(values)
        print(f"  Credentials saved to {ENV_PATH}")
        print()

    # ---- Step 2: Register in Claude Desktop ----
    if no_register:
        print("  Skipping Claude Desktop registration (--no-register)")
        print()
    else:
        print("Registering MCP server in Claude Desktop...")

        # Check uv is available
        uv_path = _find_uv()
        if uv_path == "uv":
            print()
            print("  WARNING: 'uv' was not found on your PATH.")
            print("  Install it: https://docs.astral.sh/uv/getting-started/installation/")
            print("  Then re-run this setup.")
            print()
        else:
            print(f"  Found uv at: {uv_path}")

        config_path = _claude_desktop_config_path()
        changed = register_in_claude_desktop()

        if changed:
            print(f"  Registered 'acumatica' server in {config_path}")
        else:
            print(f"  Already registered in {config_path} (no changes needed)")

    # ---- Step 3: Test the connection ----
    test_ok: bool | None = None
    if no_test:
        print("  Skipping connection test (--no-test)")
    elif not skip_credentials or headless_values:
        print()
        print("-" * 60)
        print("  Testing connection...")
        print("-" * 60)
        print()
        test_ok = test_connection()
        print()

    # ---- Done ----
    print("=" * 60)
    if test_ok is False:
        print("  Setup saved, but connection test FAILED.")
        print("=" * 60)
        print()
        print("  Your credentials and registration have been saved.")
        print("  Fix the issue above, then verify with: python setup.py --test")
    else:
        print("  Setup complete!")
        print("=" * 60)
        if not headless_values:
            # Only show "next steps" in interactive mode
            print()
            print("Next steps:")
            if not no_register:
                print("  1. Restart Claude Desktop (quit and reopen — not just a new chat)")
            if not skip_credentials and mode == "2":
                print("  2. On first use, a browser window will open for Acumatica login")
                print("     After that, tokens refresh automatically")
            if not skip_credentials:
                print()
                print("  Try asking: \"What open sales orders do we have?\"")
    print()
    print("Useful commands:")
    print("  python setup.py --test       # test the connection")
    print("  python setup.py --check      # validate .env without connecting")
    print("  python setup.py --unregister # remove from Claude Desktop")
    print()


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------
def main():
    parser = argparse.ArgumentParser(
        description="Set up the Acumatica MCP connector",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=(
            "examples:\n"
            "  python setup.py              # full interactive setup\n"
            "  python setup.py --test       # test the connection (login + discover)\n"
            "  python setup.py --check      # verify .env is valid (no network call)\n"
            "  python setup.py --register   # only register in Claude Desktop config\n"
            "  python setup.py --unregister # remove from Claude Desktop config\n"
            "\n"
            "  # headless / CI mode — supply credentials via CLI args:\n"
            "  python setup.py --url https://my.acumatica.com --company MyTenant \\\n"
            "                  --user apiuser --pass secret --no-register --no-test\n"
        ),
    )

    # Existing mode flags
    parser.add_argument("--test", action="store_true", help="Test the connection (login + discover endpoints)")
    parser.add_argument("--check", action="store_true", help="Verify the current .env file (offline)")
    parser.add_argument("--register", action="store_true", help="Only register in Claude Desktop (skip credentials)")
    parser.add_argument("--unregister", action="store_true", help="Remove from Claude Desktop config")

    # Headless credential args
    cred = parser.add_argument_group("headless credentials", "Supply these to skip interactive prompts")
    cred.add_argument("--url", metavar="URL", help="Acumatica instance URL")
    cred.add_argument("--company", metavar="NAME", help="Company / tenant name")
    cred.add_argument("--user", metavar="USER", help="API username (basic auth)")
    cred.add_argument("--pass", metavar="PASS", dest="password", help="API password (basic auth)")
    cred.add_argument("--client-id", metavar="ID", help="OAuth Client ID (SM303010)")
    cred.add_argument("--client-secret", metavar="SECRET", help="OAuth Client Secret")
    cred.add_argument("--api-version", metavar="VER", help="API version (default: 24.200.001)")
    cred.add_argument("--branch", metavar="BRANCH", help="Branch name (multi-branch only)")
    cred.add_argument("--scope", metavar="SCOPE", help="OAuth scopes (default: api offline_access)")
    cred.add_argument("--port", metavar="PORT", help="OAuth callback port (default: 8742)")

    # Behaviour flags
    parser.add_argument("--no-register", action="store_true", help="Skip Claude Desktop config registration")
    parser.add_argument("--no-test", action="store_true", help="Skip connection test after saving credentials")

    args = parser.parse_args()

    if args.test:
        print()
        print("=" * 60)
        print("  Acumatica MCP Connector — Connection Test")
        print("=" * 60)
        print()
        ok = test_connection()
        sys.exit(0 if ok else 1)

    elif args.check:
        ok = check_env()
        # Also show registration status
        config = _read_claude_config()
        registered = MCP_SERVER_KEY in config.get("mcpServers", {})
        print()
        print(f"  Claude Desktop registration: {'yes' if registered else 'NO — run python setup.py --register'}")
        sys.exit(0 if ok else 1)

    elif args.unregister:
        removed = unregister_from_claude_desktop()
        if removed:
            print(f"Removed 'acumatica' from {_claude_desktop_config_path()}")
            print("Restart Claude Desktop for the change to take effect.")
        else:
            print("'acumatica' was not registered — nothing to remove.")

    elif args.register:
        run_setup(skip_credentials=True, no_test=args.no_test)

    else:
        # Check if headless credentials were provided
        headless = _headless_values_from_args(args)
        run_setup(
            headless_values=headless,
            no_register=args.no_register,
            no_test=args.no_test,
        )


if __name__ == "__main__":
    main()
