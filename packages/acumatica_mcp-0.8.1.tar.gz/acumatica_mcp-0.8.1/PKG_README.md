# Acumatica MCP Server

mcp-name: io.github.nicholsonpeter/acumatica

An [MCP](https://modelcontextprotocol.io/) server that connects AI assistants to Acumatica ERP via the Contract-Based REST API. 25 tools covering queries, mutations, Generic Inquiries, inventory, shipments, reports, and file attachments.

## Quick Start

```bash
git clone https://github.com/nicholsonpeter/acumatica-mcp.git
cd acumatica-mcp/servers
python setup.py       # interactive credential setup
```

Then add to your MCP client configuration (e.g. Claude Desktop):

```json
{
  "mcpServers": {
    "acumatica": {
      "command": "uv",
      "args": ["run", "--directory", "/path/to/acumatica-mcp/servers", "python", "server.py"]
    }
  }
}
```

## Using the Client Library Independently

The API client (`acumatica_client.py`) has no MCP dependency and can be imported directly:

```python
from acumatica_client import AcumaticaClient

client = AcumaticaClient()  # reads config from .env or environment variables
resp = client.get("/entity/Default/24.200.001/SalesOrder", {"$top": "10"})
orders = resp.json()
```

## Features

- **Two-layer architecture** — standalone API client + thin MCP tool layer
- **25 MCP tools** — discovery, queries, mutations, files, inventory, shipments, reports
- **Generic Inquiry support** — OData and Contract-Based API paths
- **OAuth 2.0 with PKCE** or username/password authentication
- **Automatic retry** with exponential backoff on 429/503
- **Response compaction** — strips Acumatica's verbose envelopes, cuts token cost ~3x
- **Tenant discovery** — probes capabilities once, caches 24 hours
- **Input validation** — endpoint name guards, string length caps, format allowlists

## Documentation

Full documentation is in the [GitHub repository](https://github.com/nicholsonpeter/acumatica-mcp):

- [Setup Guide](https://github.com/nicholsonpeter/acumatica-mcp#step-by-step-setup)
- [End User Guide](https://github.com/nicholsonpeter/acumatica-mcp/blob/master/docs/user-guide.md)
- [Tool Reference](https://github.com/nicholsonpeter/acumatica-mcp/blob/master/docs/tool-reference.md)
- [Architecture](https://github.com/nicholsonpeter/acumatica-mcp/blob/master/docs/architecture.md)
- [Authentication](https://github.com/nicholsonpeter/acumatica-mcp/blob/master/docs/authentication.md)

## Licence

MIT
