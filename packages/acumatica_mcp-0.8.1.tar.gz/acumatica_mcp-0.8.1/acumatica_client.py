"""
Acumatica API Client — handles authentication, session management,
request construction, and response parsing.

Supports two auth modes:
  1. Basic (username/password) — session-cookie auth, simplest setup
  2. OAuth 2.0 Authorization Code — browser-based, no stored passwords

No MCP dependency. This is a pure API wrapper that can be consumed
by the MCP server, scripts, CLI tools, or anything else.
"""

import json
import logging
import os
import re
import secrets
import sys
import threading
import time
import webbrowser
import xml.etree.ElementTree as ET
from http.server import HTTPServer, BaseHTTPRequestHandler
from pathlib import Path
from urllib.parse import urlencode, urlparse, parse_qs

import httpx

logger = logging.getLogger("acumatica-client")

# Known carrier tracking URL patterns
CARRIER_TRACKING_URLS = {
    "dhl": "https://www.dhl.com/gb-en/home/tracking.html?tracking-id={tracking}",
    "ups": "https://www.ups.com/track?tracknum={tracking}",
    "fedex": "https://www.fedex.com/fedextrack/?trknbr={tracking}",
    "royal mail": "https://www.royalmail.com/track-your-item#/tracking-results/{tracking}",
    "royalmail": "https://www.royalmail.com/track-your-item#/tracking-results/{tracking}",
    "tnt": "https://www.tnt.com/express/en_gb/site/tracking.html?searchType=con&cons={tracking}",
    "dpd": "https://track.dpd.co.uk/parcels/{tracking}",
    "hermes": "https://www.evri.com/track/parcel/{tracking}",
    "evri": "https://www.evri.com/track/parcel/{tracking}",
    "xpo": "https://track.xpo.com/{tracking}",
    "parcelforce": "https://www.parcelforce.com/track-trace?trackNumber={tracking}",
}

# Default token storage location (next to this file or in plugin root)
_DEFAULT_TOKEN_DIR = Path(__file__).parent / ".tokens"


class AcumaticaConfigError(Exception):
    """Raised when required configuration is missing or invalid."""
    pass


class AcumaticaAPIError(Exception):
    """Raised when an API call fails."""
    def __init__(self, message: str, status_code: int | None = None, response_text: str = ""):
        super().__init__(message)
        self.status_code = status_code
        self.response_text = response_text


class AcumaticaAuthError(Exception):
    """Raised when OAuth authentication fails."""
    pass


# ======================================================================
# OAuth 2.0 Callback Handler
# ======================================================================

class _OAuthCallbackHandler(BaseHTTPRequestHandler):
    """Tiny HTTP handler that captures the OAuth authorization code."""

    auth_code: str | None = None
    auth_state: str | None = None
    error: str | None = None

    def do_GET(self):
        parsed = urlparse(self.path)
        params = parse_qs(parsed.query)

        if "error" in params:
            _OAuthCallbackHandler.error = params["error"][0]
            self._respond("Authentication failed. You can close this tab.")
            return

        _OAuthCallbackHandler.auth_code = params.get("code", [None])[0]
        _OAuthCallbackHandler.auth_state = params.get("state", [None])[0]
        self._respond(
            "Authenticated successfully! You can close this tab and return to Claude."
        )

    def _respond(self, message: str):
        html = f"""<!DOCTYPE html><html><head><title>Acumatica Auth</title>
        <style>body{{font-family:system-ui;display:flex;justify-content:center;
        align-items:center;height:100vh;margin:0;background:#1a1a2e;color:#e0e0e0}}
        .card{{background:#16213e;padding:2rem 3rem;border-radius:12px;
        text-align:center;box-shadow:0 4px 20px rgba(0,0,0,.3)}}
        </style></head><body><div class="card"><h2>{message}</h2></div></body></html>"""
        self.send_response(200)
        self.send_header("Content-Type", "text/html")
        self.end_headers()
        self.wfile.write(html.encode())

    def log_message(self, format, *args):
        """Suppress default HTTP server logging."""
        pass


# ======================================================================
# Token Storage
# ======================================================================

class TokenStore:
    """
    Simple file-based token storage. Stores OAuth tokens as JSON
    in a .tokens directory, keyed by Acumatica instance URL.
    """

    def __init__(self, token_dir: Path | None = None):
        self.token_dir = token_dir or _DEFAULT_TOKEN_DIR

    def _key_for_url(self, url: str) -> str:
        """Generate a safe filename from an Acumatica URL."""
        parsed = urlparse(url)
        return parsed.netloc.replace(".", "_").replace(":", "_")

    def _token_path(self, url: str) -> Path:
        return self.token_dir / f"{self._key_for_url(url)}.json"

    def save(self, url: str, token_data: dict) -> None:
        """Persist token data to disk."""
        self.token_dir.mkdir(parents=True, exist_ok=True)
        token_data["_saved_at"] = time.time()
        self._token_path(url).write_text(json.dumps(token_data, indent=2))

    def load(self, url: str) -> dict | None:
        """Load saved token data, or None if not found."""
        path = self._token_path(url)
        if not path.exists():
            return None
        try:
            return json.loads(path.read_text())
        except (json.JSONDecodeError, OSError):
            return None

    def clear(self, url: str) -> None:
        """Remove stored tokens for a URL."""
        path = self._token_path(url)
        if path.exists():
            path.unlink()


# ======================================================================
# Main Client
# ======================================================================

class AcumaticaClient:
    """
    Stateful client for the Acumatica Contract-Based REST API.

    Auth modes (auto-detected from environment):
      - BASIC: Set ACUMATICA_USER + ACUMATICA_PASS
      - OAUTH: Set ACUMATICA_CLIENT_ID + ACUMATICA_CLIENT_SECRET
      - If both are set, OAuth takes priority.

    Common env vars (both modes):
      - ACUMATICA_URL (required)
      - ACUMATICA_COMPANY (required)
      - ACUMATICA_BRANCH (optional)
      - ACUMATICA_API_VERSION (optional, default 24.200.001)

    Basic-only env vars:
      - ACUMATICA_USER
      - ACUMATICA_PASS

    OAuth-only env vars:
      - ACUMATICA_CLIENT_ID
      - ACUMATICA_CLIENT_SECRET
      - ACUMATICA_OAUTH_SCOPE (optional, default "api offline_access")
      - ACUMATICA_OAUTH_PORT (optional, default 8742)
    """

    def __init__(
        self,
        url: str | None = None,
        user: str | None = None,
        password: str | None = None,
        company: str | None = None,
        branch: str | None = None,
        api_version: str | None = None,
        # OAuth params
        client_id: str | None = None,
        client_secret: str | None = None,
        oauth_scope: str | None = None,
        oauth_port: int | None = None,
        token_dir: Path | None = None,
    ):
        # ---- Common config ----
        self.url = (url or os.environ.get("ACUMATICA_URL", "")).rstrip("/")
        self.company = company or os.environ.get("ACUMATICA_COMPANY", "")
        self.branch = branch or os.environ.get("ACUMATICA_BRANCH", "")
        self.api_version = api_version or os.environ.get("ACUMATICA_API_VERSION", "24.200.001")
        self.endpoint_name = os.environ.get("ACUMATICA_ENDPOINT", "Default")

        # ---- Auth config ----
        self.user = user or os.environ.get("ACUMATICA_USER", "")
        self.password = password or os.environ.get("ACUMATICA_PASS", "")
        self.client_id = client_id or os.environ.get("ACUMATICA_CLIENT_ID", "")
        self.client_secret = client_secret or os.environ.get("ACUMATICA_CLIENT_SECRET", "")
        self.oauth_scope = oauth_scope or os.environ.get("ACUMATICA_OAUTH_SCOPE", "api offline_access")
        self.oauth_port = oauth_port or int(os.environ.get("ACUMATICA_OAUTH_PORT", "8742"))

        # ---- Determine auth mode ----
        if self.client_id and self.client_secret:
            self.auth_mode = "oauth"
        elif self.user and self.password:
            self.auth_mode = "basic"
        else:
            self.auth_mode = None  # Will fail validation below

        # ---- Validate required fields ----
        missing = []
        if not self.url:
            missing.append("ACUMATICA_URL")
        if not self.company:
            missing.append("ACUMATICA_COMPANY")

        if self.auth_mode is None:
            missing.append(
                "ACUMATICA_USER + ACUMATICA_PASS (for basic auth) "
                "or ACUMATICA_CLIENT_ID + ACUMATICA_CLIENT_SECRET (for OAuth)"
            )

        if missing:
            raise AcumaticaConfigError(
                f"Missing required configuration: {'; '.join(missing)}. "
                f"Set these as environment variables in your MCP config."
            )

        # ---- HTTP client & state ----
        _default_timeout = float(os.environ.get("ACUMATICA_TIMEOUT", "120"))
        self._client = httpx.Client(timeout=_default_timeout)
        self._max_retries = int(os.environ.get("ACUMATICA_MAX_RETRIES", "3"))
        self._rate_limit = int(os.environ.get("ACUMATICA_MAX_REQUESTS_PER_MINUTE", "0"))
        self._request_timestamps: list[float] = []  # sliding window for rate limiting
        self._logged_in = False
        self._metadata_cache: dict | None = None
        self._schema_cache_ttl: float = 86400  # 24 hours
        self._discovery_cache: dict | None = None

        # ---- OAuth state ----
        self._token_store = TokenStore(token_dir)
        self._access_token: str | None = None
        self._refresh_token: str | None = None
        self._token_expires_at: float = 0

    # ------------------------------------------------------------------
    # Authentication — Basic (session cookie)
    # ------------------------------------------------------------------

    def _login_basic(self) -> None:
        """Authenticate with username/password via session cookie."""
        login_url = f"{self.url}/entity/auth/login"
        payload = {
            "name": self.user,
            "password": self.password,
            "company": self.company,
        }
        if self.branch:
            payload["branch"] = self.branch

        logger.info(f"Logging in to {self.url} as {self.user} (basic auth)...")

        resp = self._client.post(login_url, json=payload)
        if resp.status_code != 204:
            raise AcumaticaAPIError(
                f"Login failed (HTTP {resp.status_code}): {resp.text[:300]}",
                status_code=resp.status_code,
                response_text=resp.text[:500],
            )

        logger.info("Login successful (basic).")
        self._logged_in = True

    # ------------------------------------------------------------------
    # Authentication — OAuth 2.0 Authorization Code
    # ------------------------------------------------------------------

    def _login_oauth(self) -> None:
        """
        Authenticate via OAuth 2.0. Attempts in order:
          1. Use existing valid access token
          2. Refresh using stored refresh token
          3. Full browser-based authorization code flow
        """
        # Try stored tokens first
        stored = self._token_store.load(self.url)
        if stored:
            self._access_token = stored.get("access_token")
            self._refresh_token = stored.get("refresh_token")
            expires_in = stored.get("expires_in", 3600)
            saved_at = stored.get("_saved_at", 0)
            self._token_expires_at = saved_at + expires_in - 60  # 60s buffer

            # If access token is still valid, use it
            if self._access_token and time.time() < self._token_expires_at:
                logger.info("Using stored OAuth access token.")
                self._logged_in = True
                return

            # Try refresh
            if self._refresh_token:
                try:
                    self._refresh_access_token()
                    logger.info("Refreshed OAuth access token.")
                    self._logged_in = True
                    return
                except Exception as e:
                    logger.warning(f"Token refresh failed: {e}. Starting new auth flow.")

        # Full authorization code flow
        self._do_auth_code_flow()
        self._logged_in = True

    def _do_auth_code_flow(self) -> None:
        """Run the full OAuth authorization code flow with a local callback server."""
        state = secrets.token_urlsafe(32)
        redirect_uri = f"http://localhost:{self.oauth_port}/callback"

        # Build authorization URL
        auth_params = {
            "response_type": "code",
            "client_id": self.client_id,
            "redirect_uri": redirect_uri,
            "scope": self.oauth_scope,
            "state": state,
        }
        auth_url = f"{self.url}/identity/connect/authorize?{urlencode(auth_params)}"

        # Reset handler state
        _OAuthCallbackHandler.auth_code = None
        _OAuthCallbackHandler.auth_state = None
        _OAuthCallbackHandler.error = None

        # Start local callback server
        server = HTTPServer(("localhost", self.oauth_port), _OAuthCallbackHandler)
        server.timeout = 120  # 2 minute timeout for user to complete login

        logger.info("Opening browser for Acumatica login...")
        logger.info(f"If the browser doesn't open, visit: {auth_url}")

        # Open browser in background
        threading.Thread(target=webbrowser.open, args=(auth_url,), daemon=True).start()

        # Wait for callback
        print(
            f"\nWaiting for Acumatica login...\n"
            f"If your browser didn't open, visit:\n{auth_url}\n",
            file=sys.stderr,
        )
        server.handle_request()  # Blocks until one request comes in
        server.server_close()

        # Check result
        if _OAuthCallbackHandler.error:
            raise AcumaticaAuthError(
                f"OAuth authorization failed: {_OAuthCallbackHandler.error}"
            )

        if not _OAuthCallbackHandler.auth_code:
            raise AcumaticaAuthError("No authorization code received. Login may have timed out.")

        if _OAuthCallbackHandler.auth_state != state:
            raise AcumaticaAuthError("OAuth state mismatch — possible CSRF attack.")

        # Exchange code for tokens
        self._exchange_code(
            code=_OAuthCallbackHandler.auth_code,
            redirect_uri=redirect_uri,
        )

    def _exchange_code(self, code: str, redirect_uri: str) -> None:
        """Exchange an authorization code for access + refresh tokens."""
        token_url = f"{self.url}/identity/connect/token"
        payload = {
            "grant_type": "authorization_code",
            "code": code,
            "redirect_uri": redirect_uri,
            "client_id": self.client_id,
            "client_secret": self.client_secret,
        }

        resp = self._client.post(token_url, data=payload)
        if resp.status_code != 200:
            raise AcumaticaAuthError(
                f"Token exchange failed (HTTP {resp.status_code}): {resp.text[:300]}"
            )

        token_data = resp.json()
        self._access_token = token_data["access_token"]
        self._refresh_token = token_data.get("refresh_token")
        self._token_expires_at = time.time() + token_data.get("expires_in", 3600) - 60

        # Persist tokens
        self._token_store.save(self.url, token_data)
        logger.info("OAuth tokens obtained and stored.")

    def _refresh_access_token(self) -> None:
        """Use a refresh token to obtain a new access token."""
        token_url = f"{self.url}/identity/connect/token"
        payload = {
            "grant_type": "refresh_token",
            "refresh_token": self._refresh_token,
            "client_id": self.client_id,
            "client_secret": self.client_secret,
        }

        resp = self._client.post(token_url, data=payload)
        if resp.status_code != 200:
            # Clear stale tokens
            self._token_store.clear(self.url)
            raise AcumaticaAuthError(
                f"Token refresh failed (HTTP {resp.status_code}): {resp.text[:300]}"
            )

        token_data = resp.json()
        self._access_token = token_data["access_token"]
        self._refresh_token = token_data.get("refresh_token", self._refresh_token)
        self._token_expires_at = time.time() + token_data.get("expires_in", 3600) - 60

        self._token_store.save(self.url, token_data)

    # ------------------------------------------------------------------
    # Unified login / logout
    # ------------------------------------------------------------------

    def login(self) -> None:
        """Authenticate using the configured auth mode."""
        if self.auth_mode == "oauth":
            self._login_oauth()
        else:
            self._login_basic()

    def logout(self) -> None:
        """End the session (basic mode only; OAuth tokens persist)."""
        if not self._logged_in:
            return
        if self.auth_mode == "basic":
            try:
                self._client.post(f"{self.url}/entity/auth/logout")
            except Exception:
                pass
        self._logged_in = False

    def _ensure_logged_in(self) -> None:
        """Log in if we haven't already. For OAuth, also check token expiry."""
        if self.auth_mode == "oauth" and self._logged_in:
            # Proactively refresh if token is about to expire
            if time.time() >= self._token_expires_at and self._refresh_token:
                try:
                    self._refresh_access_token()
                    logger.info("Proactively refreshed OAuth token.")
                except Exception:
                    self._logged_in = False  # Will trigger full re-auth below

        if not self._logged_in:
            self.login()

    # ------------------------------------------------------------------
    # HTTP primitives with auto-relogin on 401
    # ------------------------------------------------------------------

    _RETRYABLE_STATUSES = {429, 503}

    def _enforce_rate_limit(self) -> None:
        """Sliding-window rate limiter. Sleeps if the request would exceed the limit."""
        now = time.time()
        window_start = now - 60.0
        # Prune timestamps outside the window
        self._request_timestamps = [
            ts for ts in self._request_timestamps if ts > window_start
        ]
        if len(self._request_timestamps) >= self._rate_limit:
            # Sleep until the oldest request in the window falls outside it
            sleep_until = self._request_timestamps[0] + 60.0
            delay = sleep_until - now
            if delay > 0:
                logger.warning(
                    "Rate limit (%d req/min) reached — sleeping %.1fs",
                    self._rate_limit, delay,
                )
                time.sleep(delay)
        self._request_timestamps.append(time.time())

    def _request(self, method: str, path: str, **kwargs) -> httpx.Response:
        """
        Make an authenticated request.

        Retry behaviour:
        - 401 (session expired): re-authenticates and retries once.
        - 429 (rate limited) / 503 (service unavailable): exponential backoff
          up to ``_max_retries`` attempts. Respects ``Retry-After`` header.
        - Connection/timeout errors: wrapped as ``AcumaticaAPIError`` with a
          human-readable message.
        """
        self._ensure_logged_in()
        url = f"{self.url}{path}"

        def _inject_auth(kw: dict) -> dict:
            """Inject OAuth Bearer header if applicable."""
            if self.auth_mode == "oauth" and self._access_token:
                headers = kw.pop("headers", {}) or {}
                headers["Authorization"] = f"Bearer {self._access_token}"
                kw["headers"] = headers
            return kw

        kwargs = _inject_auth(kwargs)

        # --- Client-side rate limiting (sliding window) ---
        if self._rate_limit > 0:
            self._enforce_rate_limit()

        try:
            resp = self._client.request(method, url, **kwargs)
        except httpx.TimeoutException as e:
            raise AcumaticaAPIError(
                f"Request timed out: {method} {path} — {e}. "
                f"Increase ACUMATICA_TIMEOUT (currently "
                f"{self._client.timeout.connect}s) or check the server."
            ) from e
        except httpx.ConnectError as e:
            raise AcumaticaAPIError(
                f"Connection failed: {method} {path} — {e}. "
                f"Check that ACUMATICA_URL ({self.url}) is correct and reachable."
            ) from e

        # --- 401: re-auth once ---
        if resp.status_code == 401:
            logger.info("Session expired (401). Re-authenticating...")
            self._logged_in = False
            self.login()
            kwargs = _inject_auth(kwargs)
            resp = self._client.request(method, url, **kwargs)

        # --- 429/503: exponential backoff ---
        if resp.status_code in self._RETRYABLE_STATUSES:
            for attempt in range(1, self._max_retries + 1):
                retry_after = resp.headers.get("Retry-After")
                if retry_after and retry_after.isdigit():
                    delay = min(int(retry_after), 60)
                else:
                    delay = min(2 ** attempt, 30)  # 2, 4, 8, ... capped at 30s
                logger.warning(
                    "%s %s returned %s — retry %d/%d in %ds",
                    method, path, resp.status_code, attempt, self._max_retries, delay,
                )
                time.sleep(delay)
                try:
                    kwargs = _inject_auth(kwargs)
                    resp = self._client.request(method, url, **kwargs)
                except (httpx.TimeoutException, httpx.ConnectError) as e:
                    logger.warning("Retry %d failed with %s: %s", attempt, type(e).__name__, e)
                    continue
                if resp.status_code not in self._RETRYABLE_STATUSES:
                    break

        return resp

    def get(
        self, path: str, params: dict | None = None,
        timeout: float | None = None,
    ) -> httpx.Response:
        """Authenticated GET. Optional `timeout` overrides the default client timeout."""
        kwargs: dict = {"params": params or {}}
        if timeout is not None:
            kwargs["timeout"] = timeout
        return self._request("GET", path, **kwargs)

    def put(
        self, path: str, body: dict | None = None,
        params: dict | None = None, headers: dict | None = None,
    ) -> httpx.Response:
        """Authenticated PUT."""
        return self._request("PUT", path, json=body or {}, params=params or {}, headers=headers)

    def post(
        self, path: str, body: dict | None = None,
        params: dict | None = None, headers: dict | None = None,
    ) -> httpx.Response:
        """Authenticated POST."""
        return self._request("POST", path, json=body or {}, params=params or {}, headers=headers)

    def put_binary(
        self, path: str, content: bytes,
        filename: str, params: dict | None = None,
    ) -> httpx.Response:
        """Authenticated PUT with binary (octet-stream) body for file uploads."""
        return self._request(
            "PUT", path,
            content=content,
            params=params or {},
            headers={"Content-Type": "application/octet-stream"},
        )

    def get_binary(self, path: str, params: dict | None = None) -> httpx.Response:
        """Authenticated GET expecting binary response (file downloads)."""
        return self._request(
            "GET", path,
            params=params or {},
            headers={"Accept": "application/octet-stream"},
        )

    def delete(self, path: str, params: dict | None = None) -> httpx.Response:
        """Authenticated DELETE."""
        return self._request("DELETE", path, params=params or {})

    def patch(
        self, path: str, body: dict | None = None,
        params: dict | None = None, headers: dict | None = None,
    ) -> httpx.Response:
        """Authenticated PATCH — partial record update (only specified fields are changed)."""
        return self._request("PATCH", path, json=body or {}, params=params or {}, headers=headers)

    # ------------------------------------------------------------------
    # Entity API path helper
    # ------------------------------------------------------------------

    @property
    def entity_base(self) -> str:
        """Base path for Contract-Based API entity requests."""
        return f"/entity/{self.endpoint_name}/{self.api_version}"

    def entity_base_for(self, endpoint_name: str) -> str:
        """Base path for a specific named endpoint (e.g. 'MCPSuite')."""
        return f"/entity/{endpoint_name}/{self.api_version}"

    # ------------------------------------------------------------------
    # Long-running action polling
    # ------------------------------------------------------------------

    def poll_action(
        self,
        location_url: str,
        poll_interval: float = 1.0,
        timeout: float = 300.0,
    ) -> httpx.Response:
        """
        Poll a long-running Acumatica action until completion.

        After invoking an action, Acumatica returns a Location header.
        Polling that URL returns:
          - 202 Accepted → still processing
          - 204 No Content → completed successfully
          - 200 OK → completed with response body
          - Other → error

        Args:
            location_url: The Location header value from the action POST.
            poll_interval: Seconds between polls (default 1.0).
            timeout: Max seconds to wait (default 300).

        Returns:
            The final response (200 or 204).
        """
        start = time.time()
        while True:
            elapsed = time.time() - start
            if elapsed > timeout:
                raise AcumaticaAPIError(
                    f"Action timed out after {timeout}s",
                    status_code=None,
                )

            resp = self.get(location_url)

            if resp.status_code == 202:
                logger.info(f"Action in progress ({elapsed:.0f}s elapsed)...")
                time.sleep(poll_interval)
                continue
            elif resp.status_code in (200, 204):
                logger.info(f"Action completed ({elapsed:.0f}s).")
                return resp
            elif resp.status_code == 404:
                raise AcumaticaAPIError(
                    "Action process session expired (404).",
                    status_code=404,
                )
            else:
                raise AcumaticaAPIError(
                    f"Action polling failed (HTTP {resp.status_code}): {resp.text[:300]}",
                    status_code=resp.status_code,
                    response_text=resp.text[:500],
                )

    # ------------------------------------------------------------------
    # Structured error extraction
    # ------------------------------------------------------------------

    @staticmethod
    def parse_error_response(resp: httpx.Response) -> dict:
        """
        Parse an Acumatica error response into a structured dict.

        Acumatica returns errors in several formats:
          - {"message": "...", "exceptionMessage": "...", "innerError": {...}}
          - Entity with field-level errors in "Error" properties
          - Plain text / HTML

        Returns a dict with 'message', 'field_errors', and 'detail_errors' keys.
        """
        result = {
            "message": "",
            "field_errors": [],
            "detail_errors": [],
        }

        try:
            data = resp.json()
        except Exception:
            # Not JSON — strip HTML tags and return raw text
            import re as _re
            text = _re.sub(r"<[^>]+>", "", resp.text[:1000]).strip()
            result["message"] = text or f"HTTP {resp.status_code}"
            return result

        # Standard error format: {"message": "...", "exceptionMessage": "..."}
        if isinstance(data, dict):
            if "message" in data:
                result["message"] = data["message"]
                if "exceptionMessage" in data:
                    result["message"] += f" — {data['exceptionMessage']}"
                if "innerError" in data and isinstance(data["innerError"], dict):
                    inner_msg = data["innerError"].get("message", "")
                    if inner_msg:
                        result["detail_errors"].append(inner_msg)
                return result

            # Entity with field-level errors
            for field_name, field_val in data.items():
                if isinstance(field_val, dict):
                    error = field_val.get("error")
                    if error:
                        result["field_errors"].append({
                            "field": field_name,
                            "error": error,
                        })

            # Check for top-level Error property
            if "Error" in data:
                result["message"] = str(data["Error"])

        if not result["message"] and not result["field_errors"]:
            result["message"] = resp.text[:500]

        return result

    # ------------------------------------------------------------------
    # OData metadata
    # ------------------------------------------------------------------

    def _schema_cache_path(self) -> Path:
        """Return the path for the persistent schema cache file."""
        key = self._token_store._key_for_url(self.url)
        return self._token_store.token_dir / f"{key}_schema.json"

    def list_available_endpoints(self) -> list[dict]:
        """
        Discover Contract-Based API endpoints available on the tenant.

        Hits /entity/ which returns a JSON document listing each endpoint's
        name and version. Used as a fallback when $metadata 404s (typically
        because the configured api_version doesn't match what's deployed).

        Returns an empty list on any failure — callers should treat the
        result as best-effort diagnostic data, not a hard dependency.
        """
        try:
            resp = self.get("/entity/")
            if resp.status_code != 200:
                return []
            data = resp.json()
        except (httpx.HTTPError, ValueError, json.JSONDecodeError) as e:
            logger.debug(f"Endpoint discovery failed: {e}")
            return []
        endpoints = data.get("endpoints") if isinstance(data, dict) else None
        return endpoints if isinstance(endpoints, list) else []

    def resolve_endpoint_version(
        self,
        endpoint_name: str,
        fallback: str = "0001",
    ) -> tuple[str, list[str]]:
        """
        Return the latest available version of ``endpoint_name`` on this tenant,
        plus the list of all versions discovered for it. Used to auto-resolve
        hardcoded version strings like "0001" that don't always match the
        tenant's deployment.

        Falls back to ``fallback`` if discovery fails or the endpoint isn't
        listed, so callers never get None. Endpoint-name matching is
        case-insensitive.
        """
        available = self.list_available_endpoints()
        matched = [
            (e.get("version", "") or "").strip()
            for e in available
            if (e.get("name", "") or "").lower() == endpoint_name.lower()
        ]
        matched = [v for v in matched if v]
        if not matched:
            return (fallback, [])
        # Lexicographic sort works because Acumatica versions are zero-padded
        # fixed-width strings (e.g. "0001", "24.200.001").
        latest = sorted(matched, reverse=True)[0]
        return (latest, matched)

    def get_metadata(self) -> dict:
        """
        Fetch and parse the OData $metadata EDMX document.
        Returns a dict of entity_name -> {fields: [...], detail_entities: [...]}.

        Results are cached in-memory for the process lifetime and on disk for
        `_schema_cache_ttl` seconds (default 24 hours) to avoid repeated
        metadata fetches across MCP restarts.
        """
        # 1. In-memory cache
        if self._metadata_cache is not None:
            return self._metadata_cache

        # 2. Disk cache
        cache_path = self._schema_cache_path()
        if cache_path.exists():
            try:
                cached = json.loads(cache_path.read_text())
                cached_at = cached.pop("_cached_at", 0)
                if time.time() - cached_at < self._schema_cache_ttl:
                    logger.info("Using disk-cached API schema.")
                    self._metadata_cache = cached
                    return self._metadata_cache
            except (json.JSONDecodeError, OSError, KeyError):
                pass  # Fall through to API fetch

        # 3. Fetch from API. Acumatica's Contract-Based REST API does NOT
        # serve OData-style /$metadata — it treats "$metadata" as an entity
        # lookup and 404s with {"message":"Entity $metadata not found"}.
        # The actual schema is exposed as OpenAPI 3.0 at /swagger.json.
        url = f"{self.entity_base}/swagger.json"
        logger.info("Fetching API metadata (swagger.json)...")
        resp = self.get(url)

        # 404 usually means the configured api_version doesn't exist on this
        # tenant. Discover what's available and retry with the latest Default.
        if resp.status_code == 404:
            available = self.list_available_endpoints()
            default_versions = sorted(
                (e.get("version", "") for e in available if e.get("name") == "Default"),
                reverse=True,
            )
            for candidate in default_versions:
                if candidate == self.api_version:
                    continue
                candidate_url = f"/entity/Default/{candidate}/swagger.json"
                logger.warning(
                    f"API version {self.api_version!r} not found at {url}. "
                    f"Trying discovered version {candidate!r}."
                )
                retry = self.get(candidate_url)
                if retry.status_code == 200:
                    self.api_version = candidate
                    url = candidate_url
                    resp = retry
                    break

            if resp.status_code == 404:
                hint = ""
                if available:
                    shown = ", ".join(
                        f"{e.get('name')}/{e.get('version')}" for e in available[:10]
                    )
                    hint = f" Available endpoints on this tenant: {shown}"
                raise AcumaticaAPIError(
                    f"swagger.json not found at {url}. "
                    f"Check ACUMATICA_API_VERSION.{hint}",
                    status_code=404,
                )

        if resp.status_code != 200:
            raise AcumaticaAPIError(
                f"Failed to fetch metadata (HTTP {resp.status_code}): {resp.text[:300]}",
                status_code=resp.status_code,
            )

        try:
            spec = resp.json()
        except (ValueError, json.JSONDecodeError) as e:
            raise AcumaticaAPIError(
                f"Metadata at {url} was not valid JSON: {e}",
                status_code=resp.status_code,
            )
        self._metadata_cache = self._parse_openapi(spec)
        logger.info(f"Parsed metadata: {len(self._metadata_cache)} entity types found.")

        # Write disk cache
        try:
            cache_data = dict(self._metadata_cache)
            cache_data["_cached_at"] = time.time()
            cache_path.parent.mkdir(parents=True, exist_ok=True)
            cache_path.write_text(json.dumps(cache_data))
            logger.info(f"Schema cached to {cache_path}.")
        except OSError as e:
            logger.warning(f"Could not write schema cache: {e}")

        return self._metadata_cache

    def clear_schema_cache(self) -> None:
        """Clear both in-memory and disk schema caches. Forces a fresh metadata fetch.
        Also clears the tenant discovery cache so both are refreshed together."""
        self._metadata_cache = None
        cache_path = self._schema_cache_path()
        if cache_path.exists():
            cache_path.unlink()
            logger.info("Disk schema cache cleared.")
        self.clear_discovery_cache()
        logger.info("Schema cache cleared.")

    # ------------------------------------------------------------------
    # Tenant discovery — probe once, cache, replace hardcoded assumptions
    # ------------------------------------------------------------------

    def _discovery_cache_path(self) -> Path:
        """Return the path for the persistent discovery cache file."""
        key = self._token_store._key_for_url(self.url)
        return self._token_store.token_dir / f"{key}_discovery.json"

    def discover(self) -> dict:
        """
        Probe the connected Acumatica tenant once and cache what we learn.

        Returns a dict with:
          - endpoints: {name: [versions]} — all Contract-Based API endpoints
          - report_endpoint_version: str | None — resolved version for Report
          - odata_gi_prefix: str — working OData GI path prefix
          - customer_fields: list[str] — field names on Customer entity
          - inventory_entities: list[str] — which of InventorySummary/StockItem exist
          - shipment_fields: list[str] — field names on Shipment entity
          - ar_invoice_entity: str | None — first working AR entity name
          - discovered_at: float — epoch timestamp

        Results are cached in-memory and on disk (same TTL as schema cache).
        Call clear_discovery_cache() to force a refresh.
        """
        # 1. In-memory cache
        if self._discovery_cache is not None:
            return self._discovery_cache

        # 2. Disk cache
        cache_path = self._discovery_cache_path()
        if cache_path.exists():
            try:
                cached = json.loads(cache_path.read_text())
                cached_at = cached.get("discovered_at", 0)
                if time.time() - cached_at < self._schema_cache_ttl:
                    logger.info("Using disk-cached tenant discovery.")
                    self._discovery_cache = cached
                    return self._discovery_cache
            except (json.JSONDecodeError, OSError):
                pass

        # 3. Probe the tenant
        logger.info("Running tenant discovery...")
        result: dict = {"discovered_at": time.time()}

        # --- Endpoints and versions ---
        try:
            available = self.list_available_endpoints()
            ep_map: dict[str, list[str]] = {}
            for ep in available:
                name = ep.get("name", "")
                ver = ep.get("version", "")
                if name and ver:
                    ep_map.setdefault(name, []).append(ver)
            result["endpoints"] = ep_map
        except Exception as e:
            logger.warning(f"Discovery: endpoint listing failed: {e}")
            result["endpoints"] = {}

        # --- Report endpoint version ---
        try:
            ver, _ = self.resolve_endpoint_version("Report")
            result["report_endpoint_version"] = ver if ver != "0001" else None
        except Exception:
            result["report_endpoint_version"] = None

        # --- OData GI path prefix ---
        # Acumatica tenants vary: some need /t/{company}/api/odata/gi/,
        # others use /api/odata/gi/ (single-tenant). Probe both.
        gi_prefix = None
        for candidate in (
            f"/t/{self.company}/api/odata/gi" if self.company else None,
            "/api/odata/gi",
        ):
            if candidate is None:
                continue
            try:
                resp = self.get(candidate, timeout=10)
                if resp.status_code in (200, 400):
                    # 200 = listing works; 400 = endpoint exists but needs a GI name
                    gi_prefix = candidate
                    break
            except Exception:
                continue
        result["odata_gi_prefix"] = gi_prefix or f"/t/{self.company}/api/odata/gi"

        # --- Customer entity field names ---
        try:
            meta = self.get_metadata()
            cust_meta = meta.get("Customer", {})
            result["customer_fields"] = [
                f["name"] for f in cust_meta.get("fields", [])
            ]
        except Exception:
            result["customer_fields"] = []

        # --- Which inventory entities exist ---
        inv_entities = []
        for entity in ("InventorySummary", "StockItem"):
            try:
                resp = self.get(f"{self.entity_base}/{entity}", {"$top": "1"}, timeout=15)
                if resp.status_code == 200:
                    inv_entities.append(entity)
            except Exception:
                continue
        result["inventory_entities"] = inv_entities

        # --- Shipment field names ---
        try:
            meta = self.get_metadata()
            ship_meta = meta.get("Shipment", {})
            result["shipment_fields"] = [
                f["name"] for f in ship_meta.get("fields", [])
            ]
        except Exception:
            result["shipment_fields"] = []

        # --- AR Invoice entity name ---
        ar_entity = None
        for candidate in ("ARInvoice", "Invoice", "SalesInvoice"):
            try:
                resp = self.get(
                    f"{self.entity_base}/{candidate}",
                    {"$top": "1"},
                    timeout=15,
                )
                if resp.status_code == 200:
                    ar_entity = candidate
                    break
            except Exception:
                continue
        result["ar_invoice_entity"] = ar_entity

        # --- Persist ---
        self._discovery_cache = result
        try:
            cache_path.parent.mkdir(parents=True, exist_ok=True)
            cache_path.write_text(json.dumps(result))
            logger.info(f"Discovery cache written to {cache_path}.")
        except OSError as e:
            logger.warning(f"Could not write discovery cache: {e}")

        logger.info(
            f"Discovery complete: {len(result.get('endpoints', {}))} endpoints, "
            f"report_version={result.get('report_endpoint_version')}, "
            f"ar_entity={result.get('ar_invoice_entity')}, "
            f"inventory={result.get('inventory_entities')}"
        )
        return self._discovery_cache

    def clear_discovery_cache(self) -> None:
        """Clear both in-memory and disk discovery caches."""
        self._discovery_cache = None
        cache_path = self._discovery_cache_path()
        if cache_path.exists():
            cache_path.unlink()
            logger.info("Disk discovery cache cleared.")
        logger.info("Discovery cache cleared.")

    @staticmethod
    def _parse_openapi(spec: dict) -> dict:
        """
        Parse an Acumatica OpenAPI 3.0 schema document (swagger.json) into the
        same {entity_name: {fields, detail_entities}} shape the old EDMX
        parser produced. Acumatica wraps scalar values in typed objects
        (StringValue, DecimalValue, DateTimeValue, etc.) and represents
        detail lines as arrays of nested entity schemas.
        """
        schemas = (spec.get("components") or {}).get("schemas") or {}
        entities: dict = {}

        # Typed value-wrapper schemas we treat as scalar fields (not detail entities).
        VALUE_WRAPPERS = {
            "StringValue", "DecimalValue", "IntValue", "LongValue", "ShortValue",
            "ByteValue", "DoubleValue", "BooleanValue", "DateTimeValue", "GuidValue",
        }
        SKIP_FIELDS = {"id", "rowNumber", "note", "custom", "_links", "files", "error"}

        def _ref_name(ref: str | None) -> str | None:
            if not ref:
                return None
            # "#/components/schemas/SalesOrder" -> "SalesOrder"
            return ref.rsplit("/", 1)[-1] or None

        def _resolve_type(schema: dict) -> tuple[str, bool]:
            """
            Return (type_name, is_detail_array).
            is_detail_array = True if the property is an array of entity objects.
            """
            if not isinstance(schema, dict):
                return ("unknown", False)
            # Array — may be detail lines (array of entity refs) or array of scalars.
            if schema.get("type") == "array":
                items = schema.get("items") or {}
                items_ref = _ref_name(items.get("$ref"))
                if items_ref and items_ref not in VALUE_WRAPPERS:
                    return (items_ref, True)
                return (f"array[{items.get('type', 'unknown')}]", False)
            # Direct $ref to a wrapper or other schema.
            ref = _ref_name(schema.get("$ref"))
            if ref:
                return (ref, False)
            # Inline primitive.
            return (schema.get("type", "unknown"), False)

        def _collect_properties(schema: dict, seen: set) -> dict:
            """
            Recursively merge properties from a schema's direct `properties`
            and any `allOf` members (resolving $ref into `schemas`). Acumatica
            uses allOf composition for main entities (SalesOrder, Customer,
            etc.), inheriting from a base Entity schema.
            """
            merged: dict = {}
            if not isinstance(schema, dict):
                return merged
            for entry in schema.get("allOf") or []:
                if not isinstance(entry, dict):
                    continue
                ref = _ref_name(entry.get("$ref"))
                if ref:
                    if ref in seen:
                        continue
                    seen.add(ref)
                    base = schemas.get(ref)
                    if isinstance(base, dict):
                        merged.update(_collect_properties(base, seen))
                else:
                    merged.update(_collect_properties(entry, seen))
            direct = schema.get("properties")
            if isinstance(direct, dict):
                merged.update(direct)
            return merged

        for name, schema in schemas.items():
            if not isinstance(schema, dict):
                continue
            # Only treat schemas with properties as entities. Skip pure value
            # wrappers, error schemas, etc.
            if name in VALUE_WRAPPERS:
                continue
            props = _collect_properties(schema, {name})
            if not props:
                continue

            fields: list[dict] = []
            detail_entities: list[dict] = []

            for prop_name, prop_schema in props.items():
                if prop_name in SKIP_FIELDS:
                    continue
                type_name, is_detail = _resolve_type(prop_schema or {})
                if is_detail:
                    detail_entities.append({"name": prop_name, "type": type_name})
                else:
                    fields.append({"name": prop_name, "type": type_name})

            entities[name] = {
                "fields": fields,
                "detail_entities": detail_entities,
            }

        return entities

    @staticmethod
    def _parse_edmx(edmx_text: str) -> dict:
        """Parse an EDMX metadata document into a structured dict."""
        # Find the EDM schema namespace. Prefer the default xmlns of the <Schema>
        # element (which uses the EDM namespace) over edmx:* prefixes (which use
        # the EDMX envelope namespace). Scan for xmlns URIs that look like EDM
        # schema namespaces — ending in "/edm" or "/edm/..." but NOT "/edmx".
        schema_ns = None
        candidates = re.findall(r'xmlns(?::[\w]+)?="([^"]+)"', edmx_text[:4000])
        for uri in candidates:
            # Prefer URIs that end in /edm (not /edmx) — these are EDM schema namespaces
            if re.search(r'/edm(?:/[^"]*)?$', uri) and not uri.rstrip("/").endswith("edmx"):
                schema_ns = uri
                break
        if not schema_ns:
            # Fallback: any xmlns containing "edm" but not "edmx"
            for uri in candidates:
                if "edm" in uri.lower() and "edmx" not in uri.lower():
                    schema_ns = uri
                    break
        if not schema_ns:
            schema_ns = "http://schemas.microsoft.com/ado/2009/11/edm"

        root = ET.fromstring(edmx_text)
        entities = {}

        for entity_type in root.iter(f"{{{schema_ns}}}EntityType"):
            name = entity_type.get("Name", "")
            if not name:
                continue

            fields = []
            detail_entities = []

            for prop in entity_type.findall(f"{{{schema_ns}}}Property"):
                prop_name = prop.get("Name", "")
                prop_type = prop.get("Type", "")
                if prop_name and prop_name not in ("id", "rowNumber", "note", "custom"):
                    fields.append({"name": prop_name, "type": prop_type})

            for nav in entity_type.findall(f"{{{schema_ns}}}NavigationProperty"):
                nav_name = nav.get("Name", "")
                nav_type = nav.get("Type", "")
                if nav_name:
                    detail_entities.append({"name": nav_name, "type": nav_type})

            entities[name] = {
                "fields": fields,
                "detail_entities": detail_entities,
            }

        return entities

    # ------------------------------------------------------------------
    # OData filter construction
    # ------------------------------------------------------------------

    # ISO-8601 datetime (with or without time, with or without timezone)
    _ISO_DATETIME_RE = re.compile(
        r"^\d{4}-\d{2}-\d{2}"                       # date
        r"(?:[T ]\d{2}:\d{2}(?::\d{2}(?:\.\d+)?)?)?"  # optional time
        r"(?:Z|[+-]\d{2}:?\d{2})?$"                 # optional tz
    )
    _NUMERIC_RE = re.compile(r"^-?\d+(?:\.\d+)?$")
    _OPERATORS = ("eq", "ne", "gt", "ge", "lt", "le")
    _COMPARISON_OPS = ("gt", "ge", "lt", "le")

    @classmethod
    def _format_literal(cls, value, *, for_comparison: bool = False) -> str:
        """
        Format a Python value as an OData literal.

        Acumatica quirks:
        - Datetimes must be wrapped in datetimeoffset'...' (raw ISO strings fail).
        - Decimal fields reject int literals in gt/ge/lt/le comparisons
          ("Type conversions not supported") — append 'm' suffix for comparisons.
        """
        if value is None:
            return "null"
        if isinstance(value, bool):
            return str(value).lower()
        if isinstance(value, float):
            return f"{value}m"
        if isinstance(value, int):
            return f"{value}m" if for_comparison else str(value)
        if isinstance(value, str):
            stripped = value.strip()
            if cls._ISO_DATETIME_RE.match(stripped):
                # Normalise: date-only → midnight UTC; naive datetime → append Z
                iso = stripped.replace(" ", "T")
                if "T" not in iso:
                    iso = f"{iso}T00:00:00Z"
                elif not (iso.endswith("Z") or re.search(r"[+-]\d{2}:?\d{2}$", iso)):
                    iso = f"{iso}Z"
                return f"datetimeoffset'{iso}'"
            if cls._NUMERIC_RE.match(stripped):
                return f"{stripped}m" if for_comparison else stripped
            escaped = stripped.replace("'", "''")
            return f"'{escaped}'"
        # Unknown type — stringify and quote
        escaped = str(value).replace("'", "''")
        return f"'{escaped}'"

    @classmethod
    def build_odata_filter(cls, filters: dict) -> str:
        """
        Build an OData $filter string with proper type handling.

        Value forms accepted:
        - Simple equality: {"Status": "Open"} → Status eq 'Open'
        - Numeric:         {"Qty": 100} → Qty eq 100
        - Boolean/null:    {"Hold": False} → Hold eq false
        - ISO datetime:    {"Date": "2025-11-01"} → Date eq datetimeoffset'2025-11-01T00:00:00Z'
        - Comparison:      {"Balance": "gt 100"} → Balance gt 100m
        - Raw expression:  {"Date": "gt 2025-11-01"} → Date gt datetimeoffset'2025-11-01T00:00:00Z'
        """
        parts = []

        for key, value in filters.items():
            # String value starting with a comparison operator → parse and reformat rhs
            if isinstance(value, str):
                stripped = value.strip()
                matched_op = None
                for op in cls._OPERATORS:
                    if stripped.startswith(f"{op} "):
                        matched_op = op
                        break
                if matched_op:
                    rhs = stripped[len(matched_op) + 1:].strip()
                    # If rhs is already a formatted OData literal, leave it alone
                    if (
                        rhs.startswith("'")
                        or rhs.startswith("datetimeoffset'")
                        or rhs.lower() in ("true", "false", "null")
                    ):
                        parts.append(f"{key} {matched_op} {rhs}")
                    else:
                        literal = cls._format_literal(
                            rhs,
                            for_comparison=matched_op in cls._COMPARISON_OPS,
                        )
                        parts.append(f"{key} {matched_op} {literal}")
                    continue

            parts.append(f"{key} eq {cls._format_literal(value)}")

        return " and ".join(parts)

    # ------------------------------------------------------------------
    # Value extraction
    # ------------------------------------------------------------------

    @staticmethod
    def extract_value(val):
        """Extract the actual value from Acumatica's nested {'value': x} format."""
        if isinstance(val, dict) and "value" in val:
            return val["value"]
        return val

    # Keys that are pure protocol noise — always drop.
    _COMPACT_DROP_KEYS = frozenset({"rowNumber", "_links", "custom"})
    # Keys that are usually empty and should be dropped when so.
    _COMPACT_DROP_IF_EMPTY = frozenset({"note"})

    @classmethod
    def compact_record(cls, obj):
        """
        Strip Acumatica's verbose response envelope for LLM consumption.

        - Collapses ``{"value": X}`` (with only that key) to ``X``.
        - Drops always-noisy keys: ``rowNumber``, ``_links``, ``custom``.
        - Drops ``note`` when empty (``{}`` or ``{"value": ""}``).
        - Drops keys whose value is ``{}`` (Acumatica's null-equivalent).
        - Recurses into nested dicts and lists.

        The ``id`` GUID is preserved — it's needed for file-attachment paths
        and some follow-up operations.

        Apply this at the tool-output boundary, not inside the client — raw
        envelope data is still useful for code that needs to inspect the
        full response (e.g. for auditing or debugging).
        """
        if isinstance(obj, list):
            return [cls.compact_record(item) for item in obj]

        if not isinstance(obj, dict):
            return obj

        # Single-key {"value": X} → X (only at scalar leaves)
        if len(obj) == 1 and "value" in obj:
            return obj["value"]

        result = {}
        for key, value in obj.items():
            if key in cls._COMPACT_DROP_KEYS:
                continue

            # Recurse first so we can inspect the compacted form
            compacted = cls.compact_record(value)

            # Drop empty dicts (Acumatica's null) and empty-value wrappers
            if compacted == {} or compacted is None:
                continue
            if key in cls._COMPACT_DROP_IF_EMPTY and compacted in ("", {}):
                continue

            result[key] = compacted

        return result

    # ------------------------------------------------------------------
    # Tracking URL resolution
    # ------------------------------------------------------------------

    @staticmethod
    def get_tracking_url(carrier: str, tracking_number: str) -> str | None:
        """Resolve a carrier tracking URL from carrier name and tracking number."""
        carrier_lower = carrier.lower()
        for carrier_key, url_template in CARRIER_TRACKING_URLS.items():
            if carrier_key in carrier_lower:
                return url_template.format(tracking=tracking_number)
        return None

    # ------------------------------------------------------------------
    # Report generation
    # ------------------------------------------------------------------

    # Content-type map for report formats
    _REPORT_ACCEPT = {
        "pdf": "application/pdf",
        "html": "text/html",
        "excel": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    }

    def start_report(
        self,
        report_name: str,
        parameters: dict,
        format: str = "pdf",
        endpoint: str = "Report",
        version: str = "0001",
    ) -> str:
        """
        Start report generation. Returns the Location header URL to poll.

        Two modes:
          - Standalone reports: endpoint="Report", version="0001",
            report_name="CashAccountSummary"
          - Document reports:   endpoint="Default", version=api_version,
            report_name="ARInvoice" with key fields in parameters

        Acumatica returns 202 Accepted + Location header. Poll that URL
        (GET, Accept: application/pdf) until 200 (done) or 202 (in progress).
        """
        accept = self._REPORT_ACCEPT.get(format.lower(), "application/pdf")

        # Auto-resolve the endpoint version. Hardcoded "0001" is historical and
        # frequently wrong on modern tenants — Acumatica ships per-endpoint
        # versioning (e.g. Default=24.200.001, Report=24.200.001, plus legacy
        # "0001" on some installs). Discover what's actually deployed.
        resolved_version = version
        version_attempts: list[str] = []
        if version in (None, "", "auto"):
            discovered, all_versions = self.resolve_endpoint_version(
                endpoint, fallback="0001"
            )
            resolved_version = discovered
            version_attempts = all_versions

        path = f"/entity/{endpoint}/{resolved_version}/{report_name}"

        resp = self._request(
            "POST", path,
            json=parameters,
            headers={"Accept": accept, "Content-Type": "application/json"},
        )

        if resp.status_code == 202:
            location = resp.headers.get("Location", "")
            if location:
                return location
            raise AcumaticaAPIError(
                "Report generation started but no Location header returned.",
                status_code=202,
            )

        # On 404, try any other discovered versions for this endpoint before giving up.
        if resp.status_code == 404 and version_attempts:
            for alt in version_attempts:
                if alt == resolved_version:
                    continue
                alt_path = f"/entity/{endpoint}/{alt}/{report_name}"
                alt_resp = self._request(
                    "POST", alt_path,
                    json=parameters,
                    headers={"Accept": accept, "Content-Type": "application/json"},
                )
                if alt_resp.status_code == 202:
                    loc = alt_resp.headers.get("Location", "")
                    if loc:
                        logger.info(
                            f"Resolved {endpoint} version {alt!r} after initial 404"
                        )
                        return loc

        # Build a helpful diagnostic before raising.
        diag = ""
        if resp.status_code == 404:
            available = self.list_available_endpoints()
            ep_names = sorted({
                (e.get("name", "") or "") for e in available if e.get("name")
            })
            endpoint_versions = [
                (e.get("version", "") or "") for e in available
                if (e.get("name", "") or "").lower() == endpoint.lower()
            ]
            if endpoint_versions:
                diag = (
                    f" Endpoint {endpoint!r} exists with versions "
                    f"{sorted(endpoint_versions)}, but report "
                    f"{report_name!r} wasn't found at {path!r}."
                )
            else:
                diag = (
                    f" Endpoint {endpoint!r} is not deployed on this tenant. "
                    f"Available endpoints: {ep_names[:20]}"
                    + (" …" if len(ep_names) > 20 else "")
                )

        raise AcumaticaAPIError(
            f"Failed to start report '{report_name}' "
            f"(HTTP {resp.status_code}): {resp.text[:300]}.{diag}",
            status_code=resp.status_code,
            response_text=resp.text[:500],
        )

    def poll_report(
        self,
        location: str,
        poll_interval: float = 1.0,
        timeout: float = 120.0,
    ) -> bytes:
        """
        Poll the report generation Location URL until complete.
        Returns the raw bytes of the generated report file.

        Location URL format (parsed by Acumatica):
          /entity/{endpoint}/{version}/{entity}/report/{locale}/{format}/{id}
        """
        if location.startswith("http"):
            from urllib.parse import urlparse as _urlparse
            location = _urlparse(location).path

        start = time.time()
        while True:
            elapsed = time.time() - start
            if elapsed > timeout:
                raise AcumaticaAPIError(f"Report timed out after {timeout}s.")

            resp = self._request("GET", location, headers={"Accept": "application/pdf"})

            if resp.status_code == 200:
                logger.info(f"Report ready ({elapsed:.0f}s).")
                return resp.content
            elif resp.status_code == 202:
                logger.info(f"Report generating ({elapsed:.0f}s)...")
                time.sleep(poll_interval)
            elif resp.status_code == 404:
                raise AcumaticaAPIError(
                    "Report process session expired (404). Try re-running the report.",
                    status_code=404,
                )
            else:
                raise AcumaticaAPIError(
                    f"Report polling failed (HTTP {resp.status_code}): {resp.text[:300]}",
                    status_code=resp.status_code,
                )

    # ------------------------------------------------------------------
    # Multi-company support
    # ------------------------------------------------------------------

    def get_company_list(self) -> list[dict]:
        """
        Return the list of companies (tenants) available to the current user.

        Acumatica does not expose a single canonical "list companies" REST path.
        `/entity/auth/companylist` works on some builds and under basic auth,
        but is frequently unavailable under OAuth or 24R2+. Strategy:

          1. Try `/entity/auth/companylist` (cheap, works on older tenants).
          2. Fall back to the Branch Contract-Based entity, which every
             tenant exposes and which lists branches with their parent
             Company. Distinct Company values = the company list.

        Raises AcumaticaAPIError if every strategy fails, with the full
        list of attempts in the message.
        """
        attempts: list[str] = []

        # Strategy 1: try known auth-level paths. Casing and availability
        # varies across Acumatica builds and auth modes.
        for auth_path in (
            "/entity/auth/companylist",
            "/entity/auth/companyList",
            "/entity/auth/Companies",
            "/entity/auth/tenants",
        ):
            try:
                resp = self.get(auth_path)
                if resp.status_code == 200:
                    ctype = resp.headers.get("content-type", "")
                    if "json" in ctype.lower():
                        data = resp.json()
                        rows = data if isinstance(data, list) else [data]
                        if rows:
                            return rows
                    attempts.append(f"{auth_path} → 200 but non-JSON/empty")
                else:
                    attempts.append(f"{auth_path} → HTTP {resp.status_code}")
            except Exception as e:
                attempts.append(f"{auth_path} → {type(e).__name__}: {e}")

        # Strategy 2: derive from entities on the active endpoint version.
        # Load metadata first so we can check which candidates actually exist.
        try:
            meta = self.get_metadata()
        except Exception:
            meta = {}
        known = {k.lower() for k in (meta or {}).keys()}

        entity_candidates: list[tuple[str, tuple[str, ...]]] = [
            # (entity_name, preferred fields)
            ("Company", ("CompanyID", "CompanyName", "CompanyCD")),
            ("Branch", ("CompanyName", "BranchCD", "BranchID")),
            ("Tenant", ("TenantID", "TenantName")),
            ("Organization", ("OrganizationID", "OrganizationName")),
        ]

        for entity_name, field_names in entity_candidates:
            if known and entity_name.lower() not in known:
                attempts.append(f"{entity_name} → not in endpoint metadata")
                continue
            path = f"{self.entity_base}/{entity_name}"
            try:
                resp = self.get(
                    path,
                    params={"$select": ",".join(field_names)},
                )
                if resp.status_code != 200:
                    attempts.append(f"{path} → HTTP {resp.status_code}")
                    continue
                data = resp.json()
                rows = data if isinstance(data, list) else [data]
                seen: dict[str, dict] = {}
                for row in rows:
                    cname = None
                    for fn in field_names:
                        cname = self.extract_value(row.get(fn))
                        if cname:
                            break
                    if not cname or cname in seen:
                        continue
                    seen[cname] = {
                        "id": cname,
                        "name": cname,
                        "source": f"{entity_name} entity",
                    }
                if seen:
                    return list(seen.values())
                attempts.append(f"{path} → 200 but no rows")
            except Exception as e:
                attempts.append(f"{path} → {type(e).__name__}: {e}")

        # Last-resort: return the currently-configured company so callers
        # always get *something* useful.
        if self.company:
            return [{
                "id": self.company,
                "name": self.company,
                "source": "configured ACUMATICA_COMPANY (fallbacks failed)",
                "attempts": attempts,
            }]

        raise AcumaticaAPIError(
            "Could not retrieve company list. Attempts: " + "; ".join(attempts),
            status_code=0,
        )

    def switch_company(self, company_id: str) -> None:
        """
        Switch the active company and re-authenticate.
        Also clears the schema cache since schemas can differ between companies.
        """
        self.company = company_id
        self._logged_in = False
        self.clear_schema_cache()
        self.login()
        logger.info(f"Switched to company: {company_id}")

    # ------------------------------------------------------------------
    # Cleanup
    # ------------------------------------------------------------------

    def close(self) -> None:
        """Logout and close the HTTP client."""
        self.logout()
        self._client.close()

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()
