# This frame built via script:
# python -m emodpy_workflow.scripts.new_frame

from typing import List

from emodpy_hiv.countries import {country} as country_model # noqa: E999
from emodpy_hiv.demographics.hiv_demographics import HIVDemographics
from emodpy_hiv.parameterized_call import ParameterizedCall


# This function initializes the demographics object at input building time. This is
# registered to the model-attribute object in __init__.py for discovery by core scripts.
# This function must take exactly one argument: manifest
def initialize_demographics(manifest):
    demographics = country_model.initialize_demographics()
    # Add any additional demographics initialization here
    return demographics


# This function generates a list of functions with parameterized values to call at input building time. All
# demographics parameters available for calibration and scenario design must be defined here via ParameterizedCall
# objects. This function is registered to the model-attribute object in __init__.py for discovery by core scripts.
# This function cannot accept any arguments.
def get_demographics_parameterized_calls(demographics: HIVDemographics) -> List[ParameterizedCall]:
    parameterized_calls = country_model.get_demographics_parameterized_calls(demographics=demographics)
    # Add any additional ParameterizedCalls here
    return parameterized_calls
