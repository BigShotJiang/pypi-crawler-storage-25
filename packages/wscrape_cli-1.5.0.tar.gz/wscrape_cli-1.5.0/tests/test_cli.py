"""CLI integration tests for wscrape."""

from __future__ import annotations

import json
import tempfile
from pathlib import Path

import httpx
import pytest
import respx

from wscrape.cli import main

SIMPLE_HTML = '<html><head><title>CLI Test</title></head><body><p>Hello CLI</p></body></html>'


@respx.mock
def test_cli_stdout_json(capsys: pytest.CaptureFixture[str]) -> None:
    """Running without --save should print JSON to stdout."""
    respx.get(url="https://example.com/").mock(
        return_value=httpx.Response(200, text=SIMPLE_HTML)
    )
    main(["https://example.com", "--rate", "0"])
    captured = capsys.readouterr()
    data = json.loads(captured.out)
    assert isinstance(data, list)
    assert len(data) == 1
    assert data[0]["title"] == "CLI Test"


@respx.mock
def test_cli_save_to_file() -> None:
    """Running with --save should write to the specified file."""
    respx.get(url="https://example.com/").mock(
        return_value=httpx.Response(200, text=SIMPLE_HTML)
    )
    with tempfile.TemporaryDirectory() as tmp:
        outfile = str(Path(tmp) / "result.json")
        main(["https://example.com", "--save", "--output", outfile, "--rate", "0"])
        data = json.loads(Path(outfile).read_text())
        assert data[0]["url"].startswith("https://example.com")


@respx.mock
def test_cli_csv_format(capsys: pytest.CaptureFixture[str]) -> None:
    """Running with --format csv should output CSV."""
    respx.get(url="https://example.com/").mock(
        return_value=httpx.Response(200, text=SIMPLE_HTML)
    )
    main(["https://example.com", "--format", "csv", "--rate", "0"])
    captured = capsys.readouterr()
    assert "url" in captured.out  # CSV header
    assert "CLI Test" in captured.out


@respx.mock
def test_cli_deep_flag() -> None:
    """--deep flag should trigger recursive crawling."""
    index = '<html><head><title>Idx</title></head><body><a href="/sub">Sub</a></body></html>'
    sub = '<html><head><title>Sub</title></head><body><p>Subpage</p></body></html>'
    respx.get(url="https://example.com/").mock(return_value=httpx.Response(200, text=index))
    respx.get(url="https://example.com/sub").mock(return_value=httpx.Response(200, text=sub))

    with tempfile.TemporaryDirectory() as tmp:
        outfile = str(Path(tmp) / "deep.json")
        main([
            "https://example.com",
            "--deep",
            "--max-depth", "1",
            "--save",
            "--output", outfile,
            "--rate", "0",
        ])
        data = json.loads(Path(outfile).read_text())
        assert len(data) == 2
        titles = {d["title"] for d in data}
        assert "Idx" in titles
        assert "Sub" in titles
