"""Unit tests for wscrape.core.crawler."""

from __future__ import annotations

import pytest
import httpx
import respx

from wscrape.config import ScrapeConfig
from wscrape.core.crawler import Crawler

INDEX_HTML = """\
<html><head><title>Index</title></head><body>
<a href="/about">About</a>
<a href="/contact">Contact</a>
<a href="https://external.com">External</a>
</body></html>
"""

ABOUT_HTML = """\
<html><head><title>About</title></head><body>
<p>About page</p>
<a href="/team">Team</a>
</body></html>
"""

CONTACT_HTML = """\
<html><head><title>Contact</title></head><body>
<p>Contact page</p>
</body></html>
"""

TEAM_HTML = """\
<html><head><title>Team</title></head><body>
<p>Team page</p>
</body></html>
"""


@pytest.mark.asyncio
class TestCrawler:
    """Tests for the Crawler class."""

    @respx.mock
    async def test_single_page_scrape(self) -> None:
        respx.get(url__regex=r"^https://example\.com/$").mock(
            return_value=httpx.Response(200, text=INDEX_HTML)
        )
        config = ScrapeConfig(url="https://example.com", deep=False, rate_ms=0)
        results = await Crawler(config).run()
        assert len(results) == 1
        assert results[0].title == "Index"
        assert results[0].depth == 0

    @respx.mock
    async def test_deep_crawl_depth_1(self) -> None:
        respx.get(url__regex=r"^https://example\.com/$").mock(
            return_value=httpx.Response(200, text=INDEX_HTML)
        )
        respx.get(url__regex=r"^https://example\.com/about$").mock(
            return_value=httpx.Response(200, text=ABOUT_HTML)
        )
        respx.get(url__regex=r"^https://example\.com/contact$").mock(
            return_value=httpx.Response(200, text=CONTACT_HTML)
        )
        config = ScrapeConfig(
            url="https://example.com", deep=True, max_depth=1, rate_ms=0
        )
        results = await Crawler(config).run()
        urls = {r.url for r in results}
        assert "https://example.com" in urls
        assert "https://example.com/about" in urls
        assert "https://example.com/contact" in urls
        # External link should NOT be followed
        assert "https://external.com" not in urls
        assert len(results) == 3

    @respx.mock
    async def test_deep_crawl_depth_2(self) -> None:
        respx.get(url__regex=r"^https://example\.com/$").mock(
            return_value=httpx.Response(200, text=INDEX_HTML)
        )
        respx.get(url__regex=r"^https://example\.com/about$").mock(
            return_value=httpx.Response(200, text=ABOUT_HTML)
        )
        respx.get(url__regex=r"^https://example\.com/contact$").mock(
            return_value=httpx.Response(200, text=CONTACT_HTML)
        )
        respx.get(url__regex=r"^https://example\.com/team$").mock(
            return_value=httpx.Response(200, text=TEAM_HTML)
        )
        config = ScrapeConfig(
            url="https://example.com", deep=True, max_depth=2, rate_ms=0
        )
        results = await Crawler(config).run()
        urls = {r.url for r in results}
        assert "https://example.com/team" in urls
        assert len(results) == 4

    @respx.mock
    async def test_no_duplicate_visits(self) -> None:
        circular_html = '<html><head><title>A</title></head><body><a href="/">Home</a></body></html>'
        respx.get(url__regex=r"^https://example\.com/$").mock(
            return_value=httpx.Response(200, text=circular_html)
        )
        config = ScrapeConfig(
            url="https://example.com", deep=True, max_depth=3, rate_ms=0
        )
        results = await Crawler(config).run()
        assert len(results) == 1  # Should not re-visit the same URL

    @respx.mock
    async def test_skips_failed_pages(self) -> None:
        respx.get(url__regex=r"^https://example\.com/$").mock(
            return_value=httpx.Response(200, text=INDEX_HTML)
        )
        # Mock a failure that persists through all retries
        respx.get(url__regex=r"^https://example\.com/about$").mock(
            return_value=httpx.Response(500, text="error")
        )
        respx.get(url__regex=r"^https://example\.com/contact$").mock(
            return_value=httpx.Response(200, text=CONTACT_HTML)
        )
        # max_retries=1 means it tries once, fails, and gives up
        config = ScrapeConfig(
            url="https://example.com",
            deep=True,
            max_depth=1,
            rate_ms=0,
            max_retries=1,
        )
        results = await Crawler(config).run()
        urls = {r.url for r in results}
        assert "https://example.com" in urls
        assert "https://example.com/contact" in urls
        # About failed, so it should not be in results
        assert "https://example.com/about" not in urls
