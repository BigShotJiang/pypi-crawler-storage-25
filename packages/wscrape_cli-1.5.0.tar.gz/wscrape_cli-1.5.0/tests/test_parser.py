"""Unit tests for wscrape.core.parser."""

from __future__ import annotations

import pytest

from wscrape.core.parser import PageData, Parser

SAMPLE_HTML = """\
<!DOCTYPE html>
<html>
<head><title>Test Page</title></head>
<body>
  <h1>Hello World</h1>
  <p>This is a test paragraph.</p>
  <script>var x = 1;</script>
  <style>body { color: red; }</style>
  <a href="/about">About</a>
  <a href="https://external.com/page">External</a>
  <a href="#fragment">Fragment</a>
  <a href="mailto:test@example.com">Email</a>
</body>
</html>
"""

BASE_URL = "https://example.com/page"


class TestParser:
    """Tests for Parser.parse()."""

    def test_title_extraction(self) -> None:
        page = Parser.parse(SAMPLE_HTML, BASE_URL)
        assert page.title == "Test Page"

    def test_text_excludes_script_and_style(self) -> None:
        page = Parser.parse(SAMPLE_HTML, BASE_URL)
        assert "var x = 1" not in page.text
        assert "color: red" not in page.text
        assert "Hello World" in page.text
        assert "test paragraph" in page.text

    def test_links_resolved_to_absolute(self) -> None:
        page = Parser.parse(SAMPLE_HTML, BASE_URL)
        assert "https://example.com/about" in page.links

    def test_external_links_included(self) -> None:
        page = Parser.parse(SAMPLE_HTML, BASE_URL)
        assert "https://external.com/page" in page.links

    def test_mailto_links_excluded(self) -> None:
        page = Parser.parse(SAMPLE_HTML, BASE_URL)
        for link in page.links:
            assert not link.startswith("mailto:")

    def test_depth_is_set(self) -> None:
        page = Parser.parse(SAMPLE_HTML, BASE_URL, depth=3)
        assert page.depth == 3

    def test_to_dict(self) -> None:
        page = Parser.parse(SAMPLE_HTML, BASE_URL, depth=1)
        d = page.to_dict()
        assert isinstance(d, dict)
        assert set(d.keys()) == {"url", "title", "text", "links", "depth"}
        assert d["depth"] == 1

    def test_empty_html(self) -> None:
        page = Parser.parse("<html></html>", BASE_URL)
        assert page.title == ""
        assert page.links == []

    def test_no_title_tag(self) -> None:
        page = Parser.parse("<html><body><p>Hi</p></body></html>", BASE_URL)
        assert page.title == ""


class TestParserCSS:
    """Tests for Parser.css()."""

    def test_css_selector(self) -> None:
        results = Parser.css(SAMPLE_HTML, "h1")
        assert results == ["Hello World"]

    def test_css_no_match(self) -> None:
        results = Parser.css(SAMPLE_HTML, "h2")
        assert results == []


class TestParserXPath:
    """Tests for Parser.xpath()."""

    def test_xpath_text(self) -> None:
        results = Parser.xpath(SAMPLE_HTML, "//h1/text()")
        assert results == ["Hello World"]

    def test_xpath_element(self) -> None:
        results = Parser.xpath(SAMPLE_HTML, "//p")
        assert len(results) == 1
        assert "test paragraph" in results[0]
