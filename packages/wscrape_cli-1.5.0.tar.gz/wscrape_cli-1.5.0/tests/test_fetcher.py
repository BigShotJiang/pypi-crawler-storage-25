"""Unit tests for wscrape.core.fetcher."""

from __future__ import annotations

import pytest
import httpx
import respx

from wscrape.config import ScrapeConfig
from wscrape.core.fetcher import Fetcher
from wscrape.exceptions import FetchError

BASE_CONFIG = ScrapeConfig(url="https://example.com", max_retries=3, timeout=5.0, rate_ms=0)


@pytest.mark.asyncio
class TestFetcher:
    """Tests for the Fetcher class."""

    @respx.mock
    async def test_successful_fetch(self) -> None:
        respx.get("https://example.com/page").mock(
            return_value=httpx.Response(200, text="<html>OK</html>")
        )
        async with Fetcher(BASE_CONFIG) as f:
            body = await f.fetch("https://example.com/page")
        assert body == "<html>OK</html>"

    @respx.mock
    async def test_retry_on_500(self) -> None:
        route = respx.get("https://example.com/fail")
        route.side_effect = [
            httpx.Response(500, text="err"),
            httpx.Response(500, text="err"),
            httpx.Response(200, text="<html>OK</html>"),
        ]
        async with Fetcher(BASE_CONFIG) as f:
            body = await f.fetch("https://example.com/fail")
        assert body == "<html>OK</html>"
        assert route.call_count == 3

    @respx.mock
    async def test_raises_fetch_error_after_retries(self) -> None:
        respx.get("https://example.com/bad").mock(
            return_value=httpx.Response(500, text="error")
        )
        async with Fetcher(BASE_CONFIG) as f:
            with pytest.raises(FetchError):
                await f.fetch("https://example.com/bad")

    @respx.mock
    async def test_timeout_triggers_retry(self) -> None:
        route = respx.get("https://example.com/slow")
        route.side_effect = [
            httpx.ConnectTimeout("timeout"),
            httpx.Response(200, text="<html>finally</html>"),
        ]
        cfg = ScrapeConfig(url="https://example.com", max_retries=2, timeout=1.0, rate_ms=0)
        async with Fetcher(cfg) as f:
            body = await f.fetch("https://example.com/slow")
        assert body == "<html>finally</html>"
