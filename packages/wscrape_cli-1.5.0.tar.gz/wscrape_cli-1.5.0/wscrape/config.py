"""Configuration for wscrape."""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(frozen=True)
class ScrapeConfig:
    """Immutable configuration object for a scrape/crawl session."""

    url: str
    deep: bool = False
    max_depth: int = 1
    max_pages: int = 100
    rate_ms: int = 200
    concurrency: int = 1
    save: bool = False
    output: str = "output.json"
    fmt: str = "json"
    max_retries: int = 3
    timeout: float = 30.0
    user_agent: str = (
        "Mozilla/5.0 (compatible; wscrape/1.5; +https://github.com/wscrape/wscrape)"
    )
    headers: dict[str, str] = field(default_factory=dict)
    verify_ssl: bool = True
    allow_external: bool = False
    proxy: str | None = None
    quiet: bool = False

    def __post_init__(self) -> None:
        if self.fmt not in ("json", "csv", "jsonl"):
            raise ValueError(f"Unsupported format: {self.fmt!r}. Use 'json', 'csv', or 'jsonl'.")
        if self.max_depth < 0:
            raise ValueError("max_depth must be >= 0")
        if self.rate_ms < 0:
            raise ValueError("rate_ms must be >= 0")
        if self.max_pages < 1:
            raise ValueError("max_pages must be >= 1")
        if self.concurrency < 1:
            raise ValueError("concurrency must be >= 1")
