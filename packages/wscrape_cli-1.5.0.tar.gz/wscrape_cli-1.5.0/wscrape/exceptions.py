"""Custom exceptions for the wscrape package."""

from __future__ import annotations


class WscrapeError(Exception):
    """Base exception for all wscrape errors."""


class FetchError(WscrapeError):
    """Raised when an HTTP request fails after all retries."""

    def __init__(self, url: str, reason: str | None = None) -> None:
        self.url = url
        self.reason = reason
        msg = f"Failed to fetch {url}"
        if reason:
            msg += f": {reason}"
        super().__init__(msg)


class ParseError(WscrapeError):
    """Raised when HTML parsing fails."""

    def __init__(self, url: str, reason: str | None = None) -> None:
        self.url = url
        self.reason = reason
        msg = f"Failed to parse content from {url}"
        if reason:
            msg += f": {reason}"
        super().__init__(msg)


class CrawlError(WscrapeError):
    """Raised when the crawl process encounters a fatal error."""


class OutputError(WscrapeError):
    """Raised when output serialization or file writing fails."""
