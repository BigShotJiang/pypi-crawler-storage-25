"""Core modules for wscrape: fetcher, parser, crawler, output."""
