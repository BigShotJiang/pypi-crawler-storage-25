"""Output serialization for wscrape results (JSON, CSV, JSONL)."""

from __future__ import annotations

import csv
import io
import json
import logging
from pathlib import Path
from typing import Any

from wscrape.core.parser import PageData
from wscrape.exceptions import OutputError

logger = logging.getLogger("wscrape.output")


def serialise_json(results: list[PageData]) -> str:
    """Serialise results to a pretty-printed JSON string."""
    return json.dumps([r.to_dict() for r in results], indent=2, ensure_ascii=False)


def serialise_jsonl(results: list[PageData]) -> str:
    """Serialise results to newline-delimited JSON (JSONL)."""
    return "\n".join(json.dumps(r.to_dict(), ensure_ascii=False) for r in results)


def serialise_csv(results: list[PageData]) -> str:
    """Serialise results to a CSV string.

    The ``links`` and ``images`` fields are stored as semicolon-separated strings.
    """
    buf = io.StringIO()
    fieldnames = ["url", "title", "text", "meta_description", "meta_author", "links", "images", "depth"]
    writer = csv.DictWriter(buf, fieldnames=fieldnames, quoting=csv.QUOTE_ALL)
    writer.writeheader()
    for r in results:
        row = r.to_dict()
        row["links"] = ";".join(row["links"])
        row["images"] = ";".join(row["images"])
        writer.writerow(row)
    return buf.getvalue()


def serialise(results: list[PageData], fmt: str = "json") -> str:
    """Serialise *results* to the requested format (``json``, ``csv``, or ``jsonl``)."""
    if fmt == "json":
        return serialise_json(results)
    if fmt == "csv":
        return serialise_csv(results)
    if fmt == "jsonl":
        return serialise_jsonl(results)
    raise OutputError(f"Unsupported format: {fmt!r}")


def save(content: str, path: str) -> Path:
    """Write *content* to *path* and return the resolved :class:`Path`."""
    try:
        dest = Path(path).resolve()
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_text(content, encoding="utf-8")
        logger.info("Results saved to %s", dest)
        return dest
    except OSError as exc:
        raise OutputError(f"Cannot write to {path}: {exc}") from exc
