"""BFS web crawler with rate limiting, concurrency, and same-domain restriction."""

from __future__ import annotations

import asyncio
import logging
from collections import deque
from typing import TYPE_CHECKING
from urllib.parse import urldefrag, urlparse

from wscrape.core.fetcher import Fetcher
from wscrape.core.parser import PageData, Parser

if TYPE_CHECKING:
    from wscrape.config import ScrapeConfig

logger = logging.getLogger("wscrape.crawler")


class Crawler:
    """BFS crawler that respects depth limits, rate limits, concurrency, and domain policy."""

    def __init__(self, config: ScrapeConfig) -> None:
        self._config = config
        self._visited: set[str] = set()
        self._results: list[PageData] = []
        self._seen_urls: set[str] = set()

    async def run(self) -> list[PageData]:
        """Execute the crawl and return a list of :class:`PageData` results."""
        start_url = self._normalise(self._config.url)
        allowed_domain = urlparse(start_url).netloc

        queue: deque[tuple[str, int]] = deque()
        queue.append((start_url, 0))
        self._seen_urls.add(start_url)

        async with Fetcher(self._config) as fetcher:
            while queue:
                if len(self._results) >= self._config.max_pages:
                    logger.info("Reached max_pages limit (%d)", self._config.max_pages)
                    break

                batch: list[tuple[str, int]] = []
                while queue and len(batch) < self._config.concurrency:
                    batch.append(queue.popleft())

                tasks = [
                    self._fetch_page(fetcher, url, depth, allowed_domain)
                    for url, depth in batch
                ]
                pages = await asyncio.gather(*tasks, return_exceptions=True)

                for page in pages:
                    if isinstance(page, Exception):
                        continue
                    if page is None:
                        continue
                    self._results.append(page)

                    if self._config.deep and page.depth < self._config.max_depth:
                        for link in page.links:
                            norm_link = self._normalise(link)
                            if norm_link not in self._seen_urls:
                                self._seen_urls.add(norm_link)
                                if self._allow_url(norm_link, allowed_domain):
                                    queue.append((norm_link, page.depth + 1))

                if self._config.rate_ms > 0 and queue:
                    await asyncio.sleep(self._config.rate_ms / 1000.0)

        logger.info("Crawl complete. %d page(s) scraped.", len(self._results))
        return self._results

    async def _fetch_page(
        self,
        fetcher: Fetcher,
        url: str,
        depth: int,
        allowed_domain: str,
    ) -> PageData | None:
        canon = self._normalise(url)
        if canon in self._visited:
            return None
        self._visited.add(canon)

        logger.info("Crawling [depth=%d] %s", depth, canon)

        try:
            html = await fetcher.fetch(canon)
        except Exception as exc:
            logger.error("Skipping %s: %s", canon, exc)
            return None

        return Parser.parse(html, canon, depth=depth)

    @staticmethod
    def _normalise(url: str) -> str:
        """Strip fragment and trailing slash for deduplication."""
        defragged, _ = urldefrag(url)
        return defragged.rstrip("/").lower()

    def _allow_url(self, url: str, allowed_domain: str) -> bool:
        if self._config.allow_external:
            return True
        return urlparse(url).netloc == allowed_domain
