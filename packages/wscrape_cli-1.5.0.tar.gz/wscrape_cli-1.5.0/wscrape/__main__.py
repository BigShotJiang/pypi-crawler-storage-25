"""Allow running scrape as ``python -m scrape``."""

from wscrape.cli import main

if __name__ == "__main__":
    main()
