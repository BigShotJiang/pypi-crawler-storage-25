"""
scrape — fast async web scraper, CLI tool, and AI agent skill.

Usage as a Python library / AI skill::

    from scrape import run_scraper

    results = run_scraper("https://example.com", deep=True, max_depth=2)
    for page in results:
        print(page["url"], page["title"])

Usage as an async function::

    import asyncio
    from scrape import async_run_scraper

    results = asyncio.run(async_run_scraper("https://example.com"))

Batch scraping multiple URLs::

    from scrape import scrape_urls
    results = scrape_urls(["https://example.com", "https://example.org"])
"""

from __future__ import annotations

__version__ = "1.5.0"

import asyncio
from typing import Any

from wscrape.config import ScrapeConfig
from wscrape.core.crawler import Crawler
from wscrape.core.parser import PageData


async def async_run_scraper(
    url: str,
    *,
    deep: bool = False,
    max_depth: int = 1,
    max_pages: int = 100,
    concurrency: int = 1,
    rate: int = 200,
    allow_external: bool = False,
) -> list[dict[str, Any]]:
    """Async entry point for programmatic / AI-agent usage.

    Parameters
    ----------
    url:
        The target URL to scrape.
    deep:
        If ``True``, recursively crawl same-domain links.
    max_depth:
        Maximum crawl depth (only relevant when *deep* is ``True``).
    max_pages:
        Maximum number of pages to scrape.
    concurrency:
        Number of concurrent requests.
    rate:
        Delay between requests in milliseconds.
    allow_external:
        If ``True``, allow crawling external domains.

    Returns
    -------
    list[dict]:
        A list of dicts, each containing ``url``, ``title``, ``text``,
        ``links``, ``images``, ``meta_description``, ``meta_author``,
        and ``depth`` keys — ready for AI consumption.
    """
    config = ScrapeConfig(
        url=url,
        deep=deep,
        max_depth=max_depth,
        max_pages=max_pages,
        concurrency=concurrency,
        rate_ms=rate,
        allow_external=allow_external,
    )
    pages: list[PageData] = await Crawler(config).run()
    return [p.to_dict() for p in pages]


def run_scraper(
    url: str,
    *,
    deep: bool = False,
    max_depth: int = 1,
    max_pages: int = 100,
    concurrency: int = 1,
    rate: int = 200,
    allow_external: bool = False,
) -> list[dict[str, Any]]:
    """Synchronous wrapper around :func:`async_run_scraper`.

    This is the recommended entry point for AI agents (Claude, OpenAI, etc.)
    that call tools synchronously.  It returns structured JSON-serialisable data.

    Example::

        from scrape import run_scraper
        data = run_scraper("https://example.com", deep=True, max_depth=2)
    """
    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:
        loop = None

    if loop and loop.is_running():
        import concurrent.futures

        with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
            future = pool.submit(
                asyncio.run,
                async_run_scraper(
                    url, deep=deep, max_depth=max_depth, max_pages=max_pages,
                    concurrency=concurrency, rate=rate, allow_external=allow_external,
                ),
            )
            return future.result()
    else:
        return asyncio.run(
            async_run_scraper(
                url, deep=deep, max_depth=max_depth, max_pages=max_pages,
                concurrency=concurrency, rate=rate, allow_external=allow_external,
            )
        )


async def async_scrape_urls(
    urls: list[str],
    *,
    deep: bool = False,
    max_depth: int = 1,
    max_pages: int = 100,
    concurrency: int = 1,
    rate: int = 200,
    allow_external: bool = False,
) -> list[dict[str, Any]]:
    """Scrape multiple URLs concurrently.

    Parameters
    ----------
    urls:
        List of URLs to scrape.
    deep:
        If ``True``, recursively crawl same-domain links.
    max_depth:
        Maximum crawl depth per starting URL.
    max_pages:
        Maximum pages per starting URL.
    concurrency:
        Number of concurrent requests per URL.
    rate:
        Delay between requests in milliseconds.
    allow_external:
        If ``True``, allow crawling external domains.

    Returns
    -------
    list[dict]:
        Combined results from all URLs.
    """
    tasks = [
        async_run_scraper(
            url, deep=deep, max_depth=max_depth, max_pages=max_pages,
            concurrency=concurrency, rate=rate, allow_external=allow_external,
        )
        for url in urls
    ]
    results = await asyncio.gather(*tasks)
    return [page for result in results for page in result]


def scrape_urls(
    urls: list[str],
    *,
    deep: bool = False,
    max_depth: int = 1,
    max_pages: int = 100,
    concurrency: int = 1,
    rate: int = 200,
    allow_external: bool = False,
) -> list[dict[str, Any]]:
    """Synchronous wrapper for scraping multiple URLs concurrently.

    Example::

        from scrape import scrape_urls
        results = scrape_urls(["https://example.com", "https://example.org"])
    """
    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:
        loop = None

    if loop and loop.is_running():
        import concurrent.futures

        with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
            future = pool.submit(
                asyncio.run,
                async_scrape_urls(
                    urls, deep=deep, max_depth=max_depth, max_pages=max_pages,
                    concurrency=concurrency, rate=rate, allow_external=allow_external,
                ),
            )
            return future.result()
    else:
        return asyncio.run(
            async_scrape_urls(
                urls, deep=deep, max_depth=max_depth, max_pages=max_pages,
                concurrency=concurrency, rate=rate, allow_external=allow_external,
            )
        )


__all__ = [
    "__version__",
    "async_run_scraper",
    "async_scrape_urls",
    "run_scraper",
    "scrape_urls",
    "ScrapeConfig",
]
