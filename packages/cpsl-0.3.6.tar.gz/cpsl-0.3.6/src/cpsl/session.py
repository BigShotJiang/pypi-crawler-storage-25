from __future__ import annotations

import asyncio
import json
import uuid
from collections.abc import AsyncIterator, Callable
from dataclasses import dataclass
from typing import Any

from .db import ScopedDatabaseProxy
from .integration import IntegrationCredentials, KNOWN_SECRET_INTEGRATIONS
from .msg import Message


@dataclass
class Block:
    """Structured inline message sent over the chat transport.

    `type` picks the renderer on the client side (e.g. ``task_card``,
    ``integration_prompt``). ``payload`` is an arbitrary JSON-serializable
    dict. An ``id`` is auto-generated if not supplied.
    """

    type: str
    payload: dict[str, Any]
    id: str = ""

    def to_envelope(self) -> dict[str, Any]:
        return {
            "id": self.id or f"blk_{uuid.uuid4().hex[:12]}",
            "type": self.type,
            "payload": self.payload,
        }


@dataclass
class SessionChannel:
    """Describes the transport a session message arrived on (chat, telegram, etc.)."""

    type: str


@dataclass
class UserInfo:
    """Identity of the authenticated user.

    ``id`` identifies the individual. ``org_id`` is set when the user
    belongs to an organization — used for ``scope="team"`` partitioning.
    ``scope="user"`` always filters by ``id``.
    """

    id: str
    email: str | None = None
    org_id: str | None = None

    @property
    def is_org_member(self) -> bool:
        """True when this user belongs to an app organization."""
        return bool(self.org_id)

    @property
    def owner_id(self) -> str:
        """Org-aware scoping key: ``org_id`` when present, else ``id``.

        Used for runtime isolation, task ownership, and ``scope="team"``
        collection partitioning.
        """
        return self.org_id or self.id


class ReplyStream:
    """Async context manager for streaming incremental text to the UI.

    Each ``write()`` call sends a chunk immediately so the user sees
    tokens as they arrive. On exit the accumulated text is saved to
    session history.

    Obtain via ``session.stream_reply()``.
    """

    __slots__ = ("_write_cb", "_history", "_channel_type", "_parts", "_full")

    def __init__(
        self,
        write_cb: Callable[[str], None],
        history: list[Message],
        channel_type: str,
    ) -> None:
        self._write_cb = write_cb
        self._history = history
        self._channel_type = channel_type
        self._parts: list[str] = []
        self._full: str = ""

    async def __aenter__(self) -> ReplyStream:
        return self

    async def __aexit__(self, *exc: Any) -> None:
        if self._full:
            self._history.append(
                Message(text=self._full, sender="app", channel_type=self._channel_type)
            )

    @property
    def text(self) -> str:
        """The full accumulated text written so far."""
        return self._full

    def write(self, text: str) -> None:
        """Send a text chunk to the client immediately.

        Handles both delta and cumulative (snapshot) text: if *text*
        starts with everything written so far it is treated as a
        cumulative snapshot and only the new suffix is forwarded.
        """
        if not text:
            return
        if text.startswith(self._full):
            delta = text[len(self._full):]
        else:
            delta = text
        if delta:
            self._parts.append(delta)
            self._write_cb(delta)
        self._full += delta


class RequestContext:
    """Context for data source and endpoint handlers.

    Provides the calling user's identity and connected integrations
    without requiring a chat session. Obtain automatically by declaring
    ``ctx: cpsl.RequestContext`` as the first parameter of an
    ``@app.data()`` or ``@app.endpoint()`` handler.
    """

    __slots__ = ("user", "integrations", "authenticated", "request")

    def __init__(
        self,
        user: UserInfo,
        integrations: dict[str, IntegrationCredentials],
        authenticated: bool = False,
        request: Any = None,
    ) -> None:
        self.user = user
        self.integrations = integrations
        self.authenticated = authenticated
        self.request = request


class Session:
    """Per-user conversation context, persisted across messages.

    Concurrency: handlers for the same session are serialized via an
    ``asyncio.Lock``. Handlers across *different* sessions may run
    concurrently. Avoid mutating shared app-instance state without your
    own synchronization.

    Attributes:
        id:      Unique session identifier.
        user:    Identity of the user — ``UserInfo(id, email)``.
        channel: Channel this session is on (chat, api, etc.).
        history: Recent messages, rehydrated from the backing store.
        data:    Persistent key-value dict, saved automatically after each message.
    """

    __slots__ = (
        "id",
        "user",
        "channel",
        "history",
        "data",
        "integrations",
        "_reply_callback",
        "_stream_callback",
        "_stream_write_callback",
        "_notify_callback",
        "_block_callback",
        "_db_proxy",
    )

    def __init__(
        self,
        id: str,
        user: UserInfo,
        channel: SessionChannel,
        history: list[Message] | None = None,
        data: dict[str, Any] | None = None,
        integrations: dict[str, IntegrationCredentials] | None = None,
    ) -> None:
        self.id = id
        self.user = user
        self.channel = channel
        self.history: list[Message] = history or []
        self.data: dict[str, Any] = data or {}
        self.integrations: dict[str, IntegrationCredentials] = integrations or {}
        self._reply_callback: Any = None
        self._stream_callback: Any = None
        self._stream_write_callback: Any = None
        self._notify_callback: Any = None
        self._block_callback: Any = None
        self._db_proxy: ScopedDatabaseProxy | None = None

    @property
    def db(self) -> ScopedDatabaseProxy:
        """Scoped database proxy — collections auto-filtered by user/team/session identity."""
        if self._db_proxy is None:
            raise RuntimeError("session.db not available (database not configured)")
        return self._db_proxy

    async def reply(self, text: str) -> None:
        """Send a complete message back to the user."""
        msg = Message(text=text, sender="app", channel_type=self.channel.type)
        self.history.append(msg)
        if self._reply_callback:
            await self._reply_callback(msg)

    async def notify(self, text: str) -> None:
        """Send a lightweight status notification to the user."""
        msg = Message(text=text, sender="system", channel_type=self.channel.type)
        if self._notify_callback:
            await self._notify_callback(msg)
        elif self._reply_callback:
            await self._reply_callback(msg)

    async def stream(self, chunks: AsyncIterator[str]) -> None:
        """Stream response chunks to the user in real time."""
        if self._stream_callback:
            await self._stream_callback(chunks)

    def stream_reply(self) -> ReplyStream:
        """Open a streaming reply that sends chunks to the UI in real time.

        Usage::

            async with session.stream_reply() as s:
                s.write("## Report\\n\\n")
                async for token in llm_stream:
                    s.write(token)

        Each ``write`` sends text to the client immediately. The accumulated
        text is appended to session history when the block exits. Multiple
        ``stream_reply`` blocks can be used within a single handler.
        """
        if not self._stream_write_callback:
            raise RuntimeError("stream_reply is only available inside a message handler")
        return ReplyStream(self._stream_write_callback, self.history, self.channel.type)

    def chat_messages(self, current: Message, *, cls: Any = None) -> list:
        """Build a role-merged message list from history plus the current message.

        Maps ``sender="app"`` to ``role="assistant"`` and everything else
        to ``role="user"``.  Consecutive same-role entries are merged so
        the result always alternates roles (required by most LLM APIs).

        Pass ``cls=ChatMessage`` (or any type accepting ``role`` and
        ``content`` keyword arguments) to get back typed objects instead
        of plain dicts.
        """
        merged: list[dict[str, str]] = []
        for m in [*self.history, current]:
            role = "user" if m.sender == "user" else "assistant"
            if merged and merged[-1]["role"] == role:
                merged[-1]["content"] += m.text
            else:
                merged.append({"role": role, "content": m.text})
        if cls is not None:
            return [cls(**m) for m in merged]
        return merged

    async def stream_reply_from(self, stream: Any) -> str:
        """Pipe an async-iterable LLM stream through :meth:`stream_reply`.

        Handles cumulative snapshots (like BAML) and pure deltas equally
        because :class:`ReplyStream.write` auto-detects the format.
        Returns the full accumulated text.

        Usage::

            stream = b.stream.Chat(
                messages=session.chat_messages(msg, cls=ChatMessage),
                system_prompt=SYSTEM_PROMPT,
            )
            full_text = await session.stream_reply_from(stream)
        """
        async with self.stream_reply() as reply:
            async for partial in stream:
                if partial is not None:
                    reply.write(partial)
        return reply.text

    async def show(self, block: Block) -> None:
        """Render a structured block inline in the chat transport.

        The block is delivered as a one-shot chunk on the session's SSE
        stream and persisted in history so it replays on page reload. The
        block itself is stateless — renderers fetch live data (e.g.
        ``task_card`` re-reads ``/tasks/:id``).
        """
        if not self._block_callback:
            return
        envelope = block.to_envelope()
        await self._block_callback(json.dumps(envelope))

    async def show_task(
        self, handle_or_id: Any, *, message: str | None = None
    ) -> None:
        """Render an inline card that tracks the given task's live state.

        Accepts a ``TaskHandle`` or raw task-id string. The card polls
        the task endpoint client-side, so we only have to name the task
        here — no payload snapshot is captured.

        ``message`` sets the card's headline (e.g. "Generating report…").
        When omitted, the card falls back to a humanized task name.
        """
        task_id = getattr(handle_or_id, "task_id", None) or str(handle_or_id)
        if not task_id:
            return
        payload: dict[str, Any] = {"task_id": task_id}
        if message:
            payload["message"] = message
        await self.show(Block(type="task_card", payload=payload))

    async def show_integration(self, integration_type: str, *, reason: str = "") -> None:
        """Render an inline Connect-Integration card without blocking.

        Useful when a handler wants to hint that an integration would
        unlock more functionality but can still proceed without it.
        """
        await self.show(
            Block(
                type="integration_prompt",
                payload={"type": integration_type, "reason": reason, "blocking": False},
            )
        )

    async def prompt_integration(
        self,
        integration_type: str,
        *,
        reason: str = "",
        timeout: float = 300.0,
    ) -> IntegrationCredentials:
        """Block until the user connects an integration, then return credentials.

        For OAuth integrations the user completes a redirect flow. For
        secret-based integrations (``tailscale``, ``aws``, …) the user
        fills in a credential form and the sandbox environment is configured
        automatically before this returns.

        Idempotent — returns immediately if already connected.
        """
        from .clients.capsule import WaitForIntegrationRequest

        existing = self.integrations.get(integration_type)
        if existing:
            return existing

        is_secret = integration_type in KNOWN_SECRET_INTEGRATIONS

        await self.show(
            Block(
                type="integration_prompt",
                payload={
                    "type": integration_type,
                    "reason": reason,
                    "blocking": True,
                    "mode": "secret" if is_secret else "oauth",
                },
            )
        )

        runner = _get_runner_for_session(self)
        if runner is None or runner._session_stub is None:
            raise IntegrationDeclined(
                f"no gateway connection available to prompt for '{integration_type}'"
            )

        app_id = getattr(runner, "_app_id", "") or ""
        req = WaitForIntegrationRequest(
            app_id=app_id,
            user_id=self.user.email or self.user.id or "",
            integration_type=integration_type,
            timeout_seconds=int(timeout),
        )

        def _call():
            return runner._session_stub.wait_for_integration(req)

        resp = await asyncio.get_running_loop().run_in_executor(None, _call)

        if resp.timed_out:
            raise IntegrationTimeout(f"timed out waiting for '{integration_type}' connection")
        if not resp.connected:
            raise IntegrationDeclined(f"user did not connect '{integration_type}'")

        # Secret-based integrations pack field values as JSON in access_token.
        secret_fields: dict[str, str] = {}
        if is_secret and resp.credential.access_token:
            try:
                secret_fields = json.loads(resp.credential.access_token)
            except (json.JSONDecodeError, TypeError):
                pass

        cred = IntegrationCredentials(
            access_token="" if is_secret else resp.credential.access_token,
            token_type=resp.credential.token_type or "Bearer",
            scopes=list(resp.credential.scopes),
            expires_at=resp.credential.expires_at,
            fields=secret_fields,
        )
        self.integrations[integration_type] = cred

        if is_secret and secret_fields:
            await _activate_integration(integration_type, secret_fields)

        return cred


class IntegrationTimeout(TimeoutError):
    """Raised when ``session.prompt_integration`` times out."""


class IntegrationDeclined(RuntimeError):
    """Raised when the user explicitly declines an integration prompt."""


async def _activate_integration(integration_type: str, fields: dict[str, str]) -> None:
    """Configure the sandbox environment for a secret-based integration.

    Called both mid-turn (after ``prompt_integration``) and at boot (for
    already-connected integrations). The caller is responsible for supplying
    the decrypted field values.
    """
    import logging
    import os
    import shutil
    import subprocess as _sp

    log = logging.getLogger("cpsl.integration")

    if integration_type == "tailscale":
        auth_key = fields.get("auth_key", "")
        if not auth_key:
            log.warning("tailscale integration missing auth_key")
            return

        if shutil.which("tailscaled") is None:
            log.error("tailscaled binary not found — is Tailscale installed in the image?")
            return

        log.info("starting tailscaled (userspace networking)")
        _sp.Popen(
            [
                "tailscaled",
                "--tun=userspace-networking",
                "--socks5-server=localhost:1080",
                "--state=mem:",
            ],
            stdout=_sp.DEVNULL,
            stderr=_sp.DEVNULL,
        )

        await asyncio.sleep(1)

        _sp.run(
            ["tailscale", "up", f"--authkey={auth_key}"],
            timeout=30,
            check=True,
            capture_output=True,
        )

        for _ in range(20):
            result = _sp.run(
                ["tailscale", "status", "--json"],
                capture_output=True,
                timeout=5,
            )
            if result.returncode == 0:
                try:
                    status = json.loads(result.stdout)
                    if status.get("BackendState") == "Running":
                        break
                except (json.JSONDecodeError, TypeError):
                    pass
            await asyncio.sleep(0.5)

        os.environ["ALL_PROXY"] = "socks5://localhost:1080"
        os.environ["HTTP_PROXY"] = "socks5://localhost:1080"
        os.environ["HTTPS_PROXY"] = "socks5://localhost:1080"
        log.info("tailscale tunnel ready — SOCKS5 proxy on :1080")

    elif integration_type == "aws":
        if fields.get("access_key_id"):
            os.environ["AWS_ACCESS_KEY_ID"] = fields["access_key_id"]
        if fields.get("secret_access_key"):
            os.environ["AWS_SECRET_ACCESS_KEY"] = fields["secret_access_key"]
        if fields.get("region"):
            os.environ["AWS_DEFAULT_REGION"] = fields["region"]
        log.info("aws credentials injected into environment")

    else:
        log.debug("no activation handler for integration type %r", integration_type)


def _get_runner_for_session(session: "Session"):
    """Return the active ``Runner``, avoiding a circular import."""
    try:
        from .runner import Runner
    except ImportError:
        return None
    return Runner._current_instance()
