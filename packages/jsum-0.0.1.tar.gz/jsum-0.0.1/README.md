### JSUM
Summarize JSON for artificial and natural intelligences
