#!/usr/bin/env python3
"""jsum - summarize JSON/JSONL structure for quick jq exploration."""
import argparse
import json
import sys


def new_schema():
    return {
        "count": 0,
        "scalars": {},
        "object_count": 0,
        "object_fields": {},
        "array_count": 0,
        "array_empty": 0,
        "array_element": None,
        "samples": [],
    }


def observe(schema, value, samples_limit):
    schema["count"] += 1
    if value is None:
        t = "null"
    elif isinstance(value, bool):
        t = "bool"
    elif isinstance(value, int):
        t = "int"
    elif isinstance(value, float):
        t = "float"
    elif isinstance(value, str):
        t = "string"
    elif isinstance(value, dict):
        schema["object_count"] += 1
        for k, v in value.items():
            child = schema["object_fields"].setdefault(k, new_schema())
            observe(child, v, samples_limit)
        return
    elif isinstance(value, list):
        schema["array_count"] += 1
        if not value:
            schema["array_empty"] += 1
        else:
            if schema["array_element"] is None:
                schema["array_element"] = new_schema()
            for item in value:
                observe(schema["array_element"], item, samples_limit)
        return
    else:
        t = type(value).__name__
    schema["scalars"][t] = schema["scalars"].get(t, 0) + 1
    if samples_limit and t != "null" and len(schema["samples"]) < samples_limit:
        try:
            if value not in schema["samples"]:
                schema["samples"].append(value)
        except TypeError:
            pass


def type_summary(schema):
    parts = []
    for name in sorted(schema["scalars"]):
        parts.append(name)
    if schema["object_count"]:
        parts.append("object")
    if schema["array_count"]:
        elem = schema["array_element"]
        if elem is None:
            parts.append("array[]")
        else:
            parts.append(f"array[{type_summary(elem)}]")
    return "|".join(parts) if parts else "unknown"


_IDENT = set("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_")


def fmt_path(parent, name, optional):
    if name and name[0] not in "0123456789" and all(c in _IDENT for c in name):
        base = f".{name}" if parent == "." else f"{parent}.{name}"
    else:
        escaped = json.dumps(name)
        base = f".[{escaped}]" if parent == "." else f"{parent}[{escaped}]"
    return base + ("?" if optional else "")


def collect_paths(schema, path, rows, max_depth, depth):
    rows.append((path, schema))
    if max_depth is not None and depth >= max_depth:
        return
    for name in sorted(schema["object_fields"]):
        child = schema["object_fields"][name]
        optional = child["count"] < schema["object_count"]
        collect_paths(child, fmt_path(path, name, optional), rows, max_depth, depth + 1)
    if schema["array_element"] is not None:
        child_path = ".[]" if path == "." else f"{path}[]"
        collect_paths(schema["array_element"], child_path, rows, max_depth, depth + 1)


def render_paths(schema, samples, counts, max_depth):
    rows = []
    collect_paths(schema, ".", rows, max_depth, 0)
    path_w = max(len(p) for p, _ in rows)
    out = []
    for path, s in rows:
        line = f"{path:<{path_w}}  {type_summary(s)}"
        if counts:
            line += f"  (n={s['count']})"
        if samples and s["samples"]:
            line += "  # " + ", ".join(json.dumps(x) for x in s["samples"][:samples])
        out.append(line)
    return "\n".join(out)


def render_tree(schema, samples, counts, max_depth):
    out = []

    def rec(s, label, indent, depth):
        pad = "  " * indent
        line = f"{pad}{label}{type_summary(s)}"
        if counts:
            line += f"  (n={s['count']})"
        if samples and s["samples"]:
            line += "  # " + ", ".join(json.dumps(x) for x in s["samples"][:samples])
        out.append(line)
        if max_depth is not None and depth >= max_depth:
            return
        for name in sorted(s["object_fields"]):
            child = s["object_fields"][name]
            optional = child["count"] < s["object_count"]
            rec(child, f"{name}{'?' if optional else ''}: ", indent + 1, depth + 1)
        if s["array_element"] is not None:
            rec(s["array_element"], "[]: ", indent + 1, depth + 1)

    rec(schema, "", 0, 0)
    return "\n".join(out)


def schema_to_plain(schema, max_depth, depth=0):
    out = {"count": schema["count"], "types": type_summary(schema)}
    if schema["samples"]:
        out["samples"] = schema["samples"]
    if max_depth is not None and depth >= max_depth:
        return out
    if schema["object_fields"]:
        fields = {}
        for k in sorted(schema["object_fields"]):
            child = schema["object_fields"][k]
            tag = k + ("?" if child["count"] < schema["object_count"] else "")
            fields[tag] = schema_to_plain(child, max_depth, depth + 1)
        out["fields"] = fields
    if schema["array_element"] is not None:
        out["element"] = schema_to_plain(schema["array_element"], max_depth, depth + 1)
    return out


def load_records(source):
    if source == "-":
        text = sys.stdin.read()
    else:
        with open(source, "r", encoding="utf-8") as f:
            text = f.read()
    if not text.strip():
        return
    try:
        yield json.loads(text)
        return
    except json.JSONDecodeError:
        pass
    parsed_any = False
    for i, line in enumerate(text.splitlines(), 1):
        line = line.strip()
        if not line:
            continue
        try:
            yield json.loads(line)
            parsed_any = True
        except json.JSONDecodeError as e:
            print(f"jsum: warning: line {i}: {e}", file=sys.stderr)
    if not parsed_any:
        print("jsum: error: input is neither valid JSON nor JSONL", file=sys.stderr)
        sys.exit(1)


def main():
    ap = argparse.ArgumentParser(
        prog="jsum",
        description="Summarize JSON/JSONL structure (keys, types, optionality).",
    )
    ap.add_argument("files", nargs="*", help="JSON or JSONL files (default: stdin)")
    ap.add_argument("--tree", action="store_true", help="indented tree output")
    ap.add_argument("--json", dest="as_json", action="store_true", help="emit schema as JSON")
    ap.add_argument("--samples", type=int, default=0, metavar="N",
                    help="include up to N example values per leaf")
    ap.add_argument("--max-depth", type=int, default=None, metavar="N",
                    help="truncate nesting past depth N")
    ap.add_argument("--counts", action="store_true", help="show occurrence counts")
    args = ap.parse_args()

    sources = args.files or ["-"]
    schema = new_schema()
    for src in sources:
        for rec in load_records(src):
            observe(schema, rec, args.samples)

    if schema["count"] == 0:
        print("jsum: error: no records parsed", file=sys.stderr)
        sys.exit(1)

    if args.as_json:
        print(json.dumps(schema_to_plain(schema, args.max_depth), indent=2))
    elif args.tree:
        print(render_tree(schema, args.samples, args.counts, args.max_depth))
    else:
        print(render_paths(schema, args.samples, args.counts, args.max_depth))


if __name__ == "__main__":
    main()
