# curerate

**curerate** is a Python library for fitting cure rate models — statistical models
for time-lagged conversions where some fraction of the population will never convert.

It is a modernised fork of [convoys](https://github.com/better/convoys) by Erik Bernhardsson.

## Installation

```bash
pip install curerate
```

## Quickstart

```python
import curerate as cr

# Your DataFrame has timestamp columns — curerate handles the rest
model = cr.ConversionModel(dist="weibull")
model.fit(
    df,
    created="signed_up_at",
    converted="converted_at",
    group="plan",           # optional
)

# Predict conversion rates at specific time points
model.predict(t=[7, 14, 30, 60, 90])

# What fraction will ever convert?
model.predict_final()

# Summary table
model.summary()

# Plot conversion curves
model.plot(t_max=90)
```

## API

### `ConversionModel(dist, mcmc, hierarchical)`

| Parameter | Default | Description |
|---|---|---|
| `dist` | `"weibull"` | Distribution: `"exponential"`, `"weibull"`, `"gamma"`, `"generalized_gamma"`, or `"kaplan_meier"` |
| `mcmc` | `False` | Enable MCMC sampling for confidence intervals |
| `hierarchical` | `True` | Regularise parameters across groups |

### `model.fit(df, *, created, converted, group=None, now=None, t_unit="days")`

Fits the model to a DataFrame. Rows where `converted` is `NaT`/`NaN` are treated as censored (not yet converted).

### `model.predict(t, group=None, ci=None)` → DataFrame

Returns predicted conversion rates at times `t`. Columns: `t`, `group`, `conversion`, and optionally `conversion_low`/`conversion_high` when `ci` is set and `mcmc=True`.

### `model.predict_final(ci=None)` → DataFrame

Returns the asymptotic conversion rate (the fraction that will *ever* convert). Columns: `group`, `conversion`, and optionally `conversion_low`/`conversion_high`.

### `model.summary()`

Prints a summary table with per-group statistics.

### `model.plot(t_max=90, ci=None, ax=None)` → Axes

Plots conversion curves for all groups. Returns a matplotlib `Axes`.

## License

MIT
