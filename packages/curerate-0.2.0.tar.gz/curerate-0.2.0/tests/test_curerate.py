import datetime
import random

import flaky
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import pytest
import scipy.stats

from curerate import ConversionModel


# --- Helpers ---

def sample_weibull(k, lambd):
    return (-np.log(random.random())) ** (1.0 / k) / lambd


def generate_censored_data(N, E, C):
    B = np.array([c and e < n for n, e, c in zip(N, E, C)])
    T = np.array([e if b else n for e, b, n in zip(E, B, N)])
    return B, T


def make_synthetic_df(c=0.3, lambd=0.1, n=1000, k=1.0, n_groups=1,
                      group_cs=None, dist='exponential',
                      observation_scale=None):
    """Generate a synthetic DataFrame for testing."""
    base = pd.Timestamp("2024-01-01")

    if group_cs is not None:
        n_groups = len(group_cs)

    if observation_scale is None:
        observation_scale = 5.0 / lambd

    groups = [f"group_{i % n_groups}" for i in range(n)]
    rows = []
    for i in range(n):
        grp_idx = i % n_groups
        grp_c = group_cs[grp_idx] if group_cs is not None else c

        will_convert = random.random() < grp_c
        observation_window = np.random.uniform(0, observation_scale)

        if dist == 'exponential':
            event_time = np.random.exponential(1.0 / lambd)
        elif dist == 'weibull':
            event_time = sample_weibull(k, lambd)
        elif dist == 'gamma':
            event_time = scipy.stats.gamma.rvs(a=k, scale=1.0 / lambd)
        else:
            event_time = np.random.exponential(1.0 / lambd)

        created = base
        if will_convert and event_time < observation_window:
            converted = base + pd.Timedelta(days=event_time)
        else:
            converted = pd.NaT

        now = base + pd.Timedelta(days=observation_window)
        rows.append({
            "created": created,
            "converted": converted,
            "now": now,
            "group": groups[i],
        })

    return pd.DataFrame(rows)


# --- Tests ---

class TestInit:
    def test_import_version(self):
        import curerate
        assert curerate.__version__ == "0.2.0"

    def test_import_conversion_model(self):
        from curerate import ConversionModel
        assert ConversionModel is not None

    def test_invalid_dist_raises(self):
        with pytest.raises(ValueError, match="dist must be one of"):
            ConversionModel(dist="bad")

    def test_valid_dists(self):
        for dist in ["exponential", "weibull", "gamma",
                      "generalized_gamma", "kaplan_meier"]:
            m = ConversionModel(dist=dist)
            assert m._dist == dist


class TestNotFitted:
    def test_predict_before_fit(self):
        m = ConversionModel()
        with pytest.raises(RuntimeError, match="not been fitted"):
            m.predict(t=[1, 2, 3])

    def test_predict_final_before_fit(self):
        m = ConversionModel()
        with pytest.raises(RuntimeError, match="not been fitted"):
            m.predict_final()

    def test_summary_before_fit(self):
        m = ConversionModel()
        with pytest.raises(RuntimeError, match="not been fitted"):
            m.summary()

    def test_plot_before_fit(self):
        m = ConversionModel()
        with pytest.raises(RuntimeError, match="not been fitted"):
            m.plot()


class TestKaplanMeier:
    def test_km_basic(self):
        """Reproduce the classic 6-row KM test from the old test suite."""
        data = [
            (2, 0), (3, 0), (6, 1), (6, 1), (7, 1), (10, 0)
        ]
        now = pd.Timestamp("2019-01-22")
        created_array = [now - pd.DateOffset(t) for t, e in data]
        converted_array = [
            ts + pd.DateOffset(t) if e == 1 else pd.NaT
            for ts, (t, e) in zip(created_array, data)
        ]
        df = pd.DataFrame({
            "created_at": created_array,
            "converted_at": converted_array,
        })

        m = ConversionModel(dist="kaplan_meier")
        m.fit(df, created="created_at", converted="converted_at", now=now)
        result = m.predict(t=[9])
        assert abs(result["conversion"].iloc[0] - 0.75) < 0.01

    def test_km_groups(self):
        df = make_synthetic_df(n=500, group_cs=[0.2, 0.6], n_groups=2)
        m = ConversionModel(dist="kaplan_meier")
        m.fit(df, created="created", converted="converted",
              group="group", now=pd.Timestamp("2030-01-01"))

        result = m.predict(t=[50])
        assert len(result) == 2  # one row per group
        assert "group" in result.columns

    def test_km_predict_final(self):
        df = make_synthetic_df(n=500, c=0.5)
        m = ConversionModel(dist="kaplan_meier")
        m.fit(df, created="created", converted="converted",
              now=pd.Timestamp("2030-01-01"))
        result = m.predict_final()
        assert "conversion" in result.columns
        assert len(result) == 1

    def test_km_warns_on_mcmc(self):
        df = make_synthetic_df(n=100)
        m = ConversionModel(dist="kaplan_meier", mcmc=True)
        with pytest.warns(UserWarning, match="mcmc is ignored"):
            m.fit(df, created="created", converted="converted",
                  now=pd.Timestamp("2030-01-01"))


class TestPredictDataFrame:
    def test_predict_returns_dataframe(self):
        df = make_synthetic_df(n=500, c=0.3)
        m = ConversionModel(dist="exponential")
        m.fit(df, created="created", converted="converted",
              now=pd.Timestamp("2030-01-01"))
        result = m.predict(t=[7, 14, 30])
        assert isinstance(result, pd.DataFrame)
        assert "t" in result.columns
        assert "conversion" in result.columns
        assert len(result) == 3

    def test_predict_with_groups(self):
        df = make_synthetic_df(n=500, group_cs=[0.3, 0.5], n_groups=2)
        m = ConversionModel(dist="exponential")
        m.fit(df, created="created", converted="converted",
              group="group", now=pd.Timestamp("2030-01-01"))
        result = m.predict(t=[7, 14])
        assert "group" in result.columns
        assert len(result) == 4  # 2 groups * 2 time points

    def test_predict_single_group_filter(self):
        df = make_synthetic_df(n=500, group_cs=[0.3, 0.5], n_groups=2)
        m = ConversionModel(dist="exponential")
        m.fit(df, created="created", converted="converted",
              group="group", now=pd.Timestamp("2030-01-01"))
        result = m.predict(t=[7, 14], group="group_0")
        assert len(result) == 2

    def test_predict_final_returns_dataframe(self):
        df = make_synthetic_df(n=500, group_cs=[0.3, 0.5], n_groups=2)
        m = ConversionModel(dist="exponential")
        m.fit(df, created="created", converted="converted",
              group="group", now=pd.Timestamp("2030-01-01"))
        result = m.predict_final()
        assert isinstance(result, pd.DataFrame)
        assert "group" in result.columns
        assert "conversion" in result.columns
        assert len(result) == 2

    def test_no_group_column_in_single_group(self):
        df = make_synthetic_df(n=500, c=0.3)
        m = ConversionModel(dist="exponential")
        m.fit(df, created="created", converted="converted",
              now=pd.Timestamp("2030-01-01"))
        result = m.predict(t=[7])
        assert "group" not in result.columns
        result_final = m.predict_final()
        assert "group" not in result_final.columns


class TestParametricFit:
    @flaky.flaky
    def test_exponential_fit(self, c=0.3, lambd=0.1, n=5000):
        df = make_synthetic_df(c=c, lambd=lambd, n=n, dist='exponential')
        m = ConversionModel(dist="exponential")
        m.fit(df, created="created", converted="converted",
              now=pd.Timestamp("2030-01-01"))
        result = m.predict_final()
        fitted_c = result["conversion"].iloc[0]
        assert 0.70 * c < fitted_c < 1.30 * c

    @flaky.flaky
    def test_weibull_fit(self, c=0.3, lambd=0.1, k=0.5, n=5000):
        df = make_synthetic_df(c=c, lambd=lambd, n=n, k=k, dist='weibull')
        m = ConversionModel(dist="weibull")
        m.fit(df, created="created", converted="converted",
              now=pd.Timestamp("2030-01-01"))
        result = m.predict_final()
        fitted_c = result["conversion"].iloc[0]
        assert 0.70 * c < fitted_c < 1.30 * c

    @flaky.flaky
    def test_gamma_fit(self, c=0.3, lambd=0.1, k=3.0, n=10000):
        df = make_synthetic_df(c=c, lambd=lambd, n=n, k=k, dist='gamma',
                               observation_scale=20.0 / lambd)
        m = ConversionModel(dist="gamma")
        m.fit(df, created="created", converted="converted",
              now=pd.Timestamp("2030-01-01"))
        result = m.predict_final()
        fitted_c = result["conversion"].iloc[0]
        assert 0.70 * c < fitted_c < 1.30 * c

    @flaky.flaky
    def test_exponential_predict_at_t(self, c=0.3, lambd=0.1, n=5000):
        df = make_synthetic_df(c=c, lambd=lambd, n=n, dist='exponential')
        m = ConversionModel(dist="exponential")
        m.fit(df, created="created", converted="converted",
              now=pd.Timestamp("2030-01-01"))
        for t in [1, 3, 10]:
            result = m.predict(t=[t])
            expected = c * (1 - np.exp(-lambd * t))
            actual = result["conversion"].iloc[0]
            assert 0.70 * expected < actual < 1.30 * expected

    @flaky.flaky
    def test_multi_group_fit(self):
        cs = [0.3, 0.5, 0.7]
        df = make_synthetic_df(n=9000, group_cs=cs, lambd=0.1)
        m = ConversionModel(dist="exponential")
        m.fit(df, created="created", converted="converted",
              group="group", now=pd.Timestamp("2030-01-01"))
        result = m.predict_final()
        for i, c in enumerate(cs):
            row = result[result["group"] == f"group_{i}"]
            fitted_c = row["conversion"].iloc[0]
            assert 0.70 * c < fitted_c < 1.30 * c


class TestMCMC:
    @flaky.flaky
    def test_mcmc_ci_columns(self):
        df = make_synthetic_df(n=1000, c=0.3, lambd=0.1)
        m = ConversionModel(dist="exponential", mcmc=True)
        m.fit(df, created="created", converted="converted",
              now=pd.Timestamp("2030-01-01"))
        result = m.predict(t=[7, 14, 30], ci=0.9)
        assert "conversion_low" in result.columns
        assert "conversion_high" in result.columns
        for _, row in result.iterrows():
            assert row["conversion_low"] <= row["conversion"]
            assert row["conversion"] <= row["conversion_high"]

    @flaky.flaky
    def test_mcmc_predict_final_ci(self):
        df = make_synthetic_df(n=1000, c=0.3, lambd=0.1)
        m = ConversionModel(dist="exponential", mcmc=True)
        m.fit(df, created="created", converted="converted",
              now=pd.Timestamp("2030-01-01"))
        result = m.predict_final(ci=0.9)
        assert "conversion_low" in result.columns
        assert "conversion_high" in result.columns


class TestSummaryAndPlot:
    def test_summary_runs(self, capsys):
        df = make_synthetic_df(n=500, c=0.3)
        m = ConversionModel(dist="exponential")
        m.fit(df, created="created", converted="converted",
              now=pd.Timestamp("2030-01-01"))
        m.summary()
        captured = capsys.readouterr()
        assert "ConversionModel" in captured.out
        assert "exponential" in captured.out

    def test_summary_with_groups(self, capsys):
        df = make_synthetic_df(n=500, group_cs=[0.3, 0.5], n_groups=2)
        m = ConversionModel(dist="exponential")
        m.fit(df, created="created", converted="converted",
              group="group", now=pd.Timestamp("2030-01-01"))
        m.summary()
        captured = capsys.readouterr()
        assert "group_0" in captured.out
        assert "group_1" in captured.out

    def test_plot_returns_axes(self):
        df = make_synthetic_df(n=500, c=0.3)
        m = ConversionModel(dist="exponential")
        m.fit(df, created="created", converted="converted",
              now=pd.Timestamp("2030-01-01"))
        plt.clf()
        ax = m.plot(t_max=50)
        assert isinstance(ax, matplotlib.axes.Axes)
        plt.close()

    def test_plot_with_groups(self):
        df = make_synthetic_df(n=500, group_cs=[0.3, 0.5], n_groups=2)
        m = ConversionModel(dist="exponential")
        m.fit(df, created="created", converted="converted",
              group="group", now=pd.Timestamp("2030-01-01"))
        plt.clf()
        ax = m.plot(t_max=50)
        assert isinstance(ax, matplotlib.axes.Axes)
        plt.close()


class TestTUnit:
    def test_t_unit_hours(self):
        df = make_synthetic_df(n=200, c=0.3)
        m_days = ConversionModel(dist="kaplan_meier")
        m_days.fit(df, created="created", converted="converted",
                   now=pd.Timestamp("2030-01-01"), t_unit="days")

        m_hours = ConversionModel(dist="kaplan_meier")
        m_hours.fit(df, created="created", converted="converted",
                    now=pd.Timestamp("2030-01-01"), t_unit="hours")

        assert m_hours._unit == "hours"
        assert m_days._unit == "days"

    def test_invalid_t_unit(self):
        df = make_synthetic_df(n=100)
        m = ConversionModel(dist="exponential")
        with pytest.raises(ValueError, match="t_unit must be one of"):
            m.fit(df, created="created", converted="converted",
                  now=pd.Timestamp("2030-01-01"), t_unit="fortnights")


class TestFitReturnsSelf:
    def test_chaining(self):
        df = make_synthetic_df(n=200, c=0.3)
        result = ConversionModel(dist="kaplan_meier").fit(
            df, created="created", converted="converted",
            now=pd.Timestamp("2030-01-01")
        ).predict(t=[7])
        assert isinstance(result, pd.DataFrame)
