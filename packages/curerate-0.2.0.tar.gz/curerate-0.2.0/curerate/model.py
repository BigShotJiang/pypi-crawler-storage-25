import warnings

import jax
import jax.numpy as jnp
import numpy as np
import pandas as pd
import scipy.optimize
from scipy.special import expit

from curerate._loss import generalized_gamma_loss, predict_mean
from curerate._utils import dataframe_to_arrays
from curerate._km import _KaplanMeierModel

_DIST_PARAMS = {
    "exponential":        {"fix_k": 1.0, "fix_p": 1.0},
    "weibull":            {"fix_k": 1.0, "fix_p": None},
    "gamma":              {"fix_k": None, "fix_p": 1.0},
    "generalized_gamma":  {"fix_k": None, "fix_p": None},
    "kaplan_meier":       None,
}


class ConversionModel:

    def __init__(self, dist="weibull", mcmc=False, hierarchical=True):
        if dist not in _DIST_PARAMS:
            raise ValueError(
                f"dist must be one of {list(_DIST_PARAMS.keys())}, got '{dist}'"
            )
        self._dist = dist
        self._mcmc = mcmc
        self._hierarchical = hierarchical
        self._fitted = False
        self._params = None
        self._groups = None
        self._unit = None
        self._km = None
        self._n_per_group = None
        self._k_per_group = None
        self._n_features = None

    def _check_fitted(self):
        if not self._fitted:
            raise RuntimeError("Model has not been fitted. Call .fit() first.")

    def fit(self, df, *, created, converted, group=None, now=None, t_unit="days"):
        data = dataframe_to_arrays(
            df, created=created, converted=converted,
            group=group, now=now, t_unit=t_unit,
        )
        B, T = data["B"], data["T"]
        self._unit = data["unit"]
        G = data.get("G")

        if group is not None:
            self._groups = data["groups"]
            n_groups = len(self._groups)
            n = len(B)
            X = np.zeros((n, n_groups))
            X[np.arange(n), G] = 1
        else:
            self._groups = [None]
            X = np.ones((len(B), 1))

        self._n_features = X.shape[1]

        # Store per-group counts for summary()
        self._n_per_group = {}
        self._k_per_group = {}
        for i, grp in enumerate(self._groups):
            if G is not None:
                mask = G == i
            else:
                mask = np.ones(len(B), dtype=bool)
            self._n_per_group[grp] = int(mask.sum())
            self._k_per_group[grp] = int(B[mask].sum())

        # Kaplan-Meier path
        if self._dist == "kaplan_meier":
            if self._mcmc:
                warnings.warn("mcmc is ignored for dist='kaplan_meier'")
            if not self._hierarchical:
                warnings.warn("hierarchical is ignored for dist='kaplan_meier'")
            self._km = _KaplanMeierModel()
            self._km.fit(B, T, G=G, groups=self._groups)
            self._fitted = True
            return self

        # Parametric path
        dist_cfg = _DIST_PARAMS[self._dist]
        fix_k = dist_cfg["fix_k"]
        fix_p = dist_cfg["fix_p"]

        # Filter bad rows
        keep = (T > 0) & (B >= 0) & (B <= 1)
        if keep.sum() < len(B):
            n_removed = len(B) - keep.sum()
            warnings.warn(f"Removed {n_removed}/{len(B)} entries where "
                          "T <= 0 or B not 0/1")
            X, B, T = X[keep], B[keep], T[keep]

        W = np.ones(len(B))
        n_feat = self._n_features

        # Initial parameter vector
        x0 = np.zeros(6 + 2 * n_feat, dtype=np.float64)
        x0[0] = +1.0 if fix_k is None else np.log(fix_k)
        x0[1] = -1.0 if fix_p is None else np.log(fix_p)

        args = (X, B, T, W, fix_k, fix_p, self._hierarchical)

        # Objective (negative log-likelihood) and JAX gradient
        def objective(x):
            return -float(generalized_gamma_loss(x, *args))

        _jax_grad = jax.grad(lambda x: -generalized_gamma_loss(x, *args))

        def jac(x):
            return np.asarray(_jax_grad(x), dtype=np.float64)

        res = scipy.optimize.minimize(
            objective, x0, jac=jac, method='SLSQP',
            options={'maxiter': 9999},
        )
        if not res.success:
            warnings.warn(f"Optimization did not converge: {res.message}")

        raw = res.x
        if fix_k is not None:
            raw[0] = np.log(fix_k)
        if fix_p is not None:
            raw[1] = np.log(fix_p)

        self._params = {
            "map": {
                "k": np.exp(raw[0]) if fix_k is None else fix_k,
                "p": np.exp(raw[1]) if fix_p is None else fix_p,
                "a": raw[4],
                "b": raw[5],
                "alpha": raw[6:6 + n_feat],
                "beta": raw[6 + n_feat:6 + 2 * n_feat],
            }
        }

        # MCMC
        if self._mcmc:
            import emcee

            dim = len(x0)
            n_walkers = 5 * dim

            def log_prob(x):
                return float(generalized_gamma_loss(x, *args))

            sampler = emcee.EnsembleSampler(n_walkers, dim, log_prob)
            p0 = [res.x + 1e-3 * np.random.randn(dim)
                  for _ in range(n_walkers)]
            n_burnin = 100
            n_steps = int(np.ceil(2000 / n_walkers))
            sampler.run_mcmc(p0, n_burnin + n_steps, progress=True)
            chain = sampler.get_chain()  # shape: (n_steps, n_walkers, dim)
            samples = chain[n_burnin:, :, :].reshape(-1, dim).T

            if fix_k is not None:
                samples[0, :] = np.log(fix_k)
            if fix_p is not None:
                samples[1, :] = np.log(fix_p)

            self._params["samples"] = {
                "k": np.exp(samples[0]) if fix_k is None else np.full(samples.shape[1], fix_k),
                "p": np.exp(samples[1]) if fix_p is None else np.full(samples.shape[1], fix_p),
                "a": samples[4],
                "b": samples[5],
                "alpha": samples[6:6 + n_feat].T,
                "beta": samples[6 + n_feat:6 + 2 * n_feat].T,
            }

        self._fitted = True
        return self

    def _get_x(self, group):
        if group is None and self._groups == [None]:
            return np.array([1.0])
        idx = self._groups.index(group)
        x = np.zeros(self._n_features)
        x[idx] = 1.0
        return x

    def predict(self, t, group=None, ci=None):
        self._check_fitted()
        t = np.asarray(t, dtype=float)
        groups = self._groups if group is None else [group]

        rows = []
        for grp in groups:
            if self._dist == "kaplan_meier":
                if ci is not None:
                    result = self._km.predict_ci(t, ci=ci, group=grp)
                    result = np.atleast_2d(result)
                    for i, tv in enumerate(np.atleast_1d(t)):
                        row = {"t": tv, "group": grp, "conversion": result[i, 0],
                               "conversion_low": result[i, 1], "conversion_high": result[i, 2]}
                        rows.append(row)
                else:
                    preds = self._km.predict(t, group=grp)
                    preds = np.atleast_1d(preds)
                    for i, tv in enumerate(np.atleast_1d(t)):
                        rows.append({"t": tv, "group": grp, "conversion": preds[i]})
            else:
                x = self._get_x(grp)
                t_arr = np.atleast_1d(t)

                # MAP prediction
                map_preds = np.array([
                    float(predict_mean(self._params["map"], x, tv))
                    for tv in t_arr
                ])

                if ci is not None and self._mcmc and "samples" in self._params:
                    samples = self._params["samples"]
                    n_samples = len(samples["k"])
                    all_preds = np.zeros((len(t_arr), n_samples))
                    for s in range(n_samples):
                        s_params = {
                            "k": samples["k"][s],
                            "p": samples["p"][s],
                            "a": samples["a"][s],
                            "b": samples["b"][s],
                            "alpha": samples["alpha"][s],
                            "beta": samples["beta"][s],
                        }
                        for i, tv in enumerate(t_arr):
                            all_preds[i, s] = float(predict_mean(s_params, x, tv))

                    y_lo = np.percentile(all_preds, (1 - ci) * 50, axis=1)
                    y_hi = np.percentile(all_preds, (1 + ci) * 50, axis=1)

                    for i, tv in enumerate(t_arr):
                        rows.append({
                            "t": tv, "group": grp, "conversion": map_preds[i],
                            "conversion_low": y_lo[i], "conversion_high": y_hi[i],
                        })
                else:
                    for i, tv in enumerate(t_arr):
                        rows.append({"t": tv, "group": grp, "conversion": map_preds[i]})

        df = pd.DataFrame(rows)
        if self._groups == [None]:
            df = df.drop(columns=["group"])
        return df

    def predict_final(self, ci=None):
        self._check_fitted()
        rows = []
        for grp in self._groups:
            if self._dist == "kaplan_meier":
                conv = self._km.predict_final(group=grp)
                row = {"group": grp, "conversion": conv}
            else:
                x = self._get_x(grp)
                params = self._params["map"]
                conv = float(expit(np.dot(x, params["beta"]) + params["b"]))
                row = {"group": grp, "conversion": conv}

                if ci is not None and self._mcmc and "samples" in self._params:
                    samples = self._params["samples"]
                    c_samples = expit(
                        np.dot(samples["beta"], x) + samples["b"]
                    )
                    row["conversion_low"] = float(np.percentile(c_samples, (1 - ci) * 50))
                    row["conversion_high"] = float(np.percentile(c_samples, (1 + ci) * 50))

            rows.append(row)

        df = pd.DataFrame(rows)
        if self._groups == [None]:
            df = df.drop(columns=["group"])
        return df

    def summary(self):
        self._check_fitted()
        print(f"ConversionModel(dist='{self._dist}', mcmc={self._mcmc}, "
              f"hierarchical={self._hierarchical})")
        print(f"Fitted: {self._fitted} | Groups: {len(self._groups)} | "
              f"Unit: {self._unit}")
        print()

        final_df = self.predict_final()
        if self._groups == [None]:
            final_df["group"] = "All"

        header = f"{'Group':<20} {'n':>8} {'converted':>12} {'final_conv':>12}"
        print(header)
        print("-" * len(header))
        for _, row in final_df.iterrows():
            grp = row["group"]
            grp_key = None if grp == "All" else grp
            n = self._n_per_group[grp_key]
            k = self._k_per_group[grp_key]
            conv = row["conversion"]
            print(f"{str(grp):<20} {n:>8} {k:>12} {conv:>11.1%}")

    def plot(self, t_max=90, ci=None, ax=None):
        self._check_fitted()
        from curerate._plot import _plot_model
        return _plot_model(self, t_max=t_max, ci=ci, ax=ax)
