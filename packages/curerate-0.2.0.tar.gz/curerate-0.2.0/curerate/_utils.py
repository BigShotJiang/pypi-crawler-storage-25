import pandas as pd
import numpy as np
from datetime import datetime

_UNIT_DIVISORS = {
    "seconds": 1,
    "minutes": 60,
    "hours": 3600,
    "days": 86400,
}


def dataframe_to_arrays(df, *, created, converted, group=None, now=None, t_unit="days"):
    if converted not in df.columns:
        raise ValueError(f"Column '{converted}' not found in DataFrame")
    if created not in df.columns:
        raise ValueError(f"Column '{created}' not found in DataFrame")
    if group is not None and group not in df.columns:
        raise ValueError(f"Column '{group}' not found in DataFrame")
    if t_unit not in _UNIT_DIVISORS:
        raise ValueError(f"t_unit must be one of {list(_UNIT_DIVISORS.keys())}, got '{t_unit}'")

    df = df.copy()

    df[converted] = pd.to_datetime(df[converted])
    df[created] = pd.to_datetime(df[created])

    B = np.array((~df[converted].isna()).astype(int))

    if now is not None:
        df[converted] = df[converted].fillna(now)
    else:
        df[converted] = df[converted].fillna(datetime.now())

    T = np.array((df[converted] - df[created]).dt.total_seconds() / _UNIT_DIVISORS[t_unit])

    if group is not None:
        unique_groups = sorted(df[group].unique())
        group2idx = {label: idx for idx, label in enumerate(unique_groups)}
        G = np.array(df[group].map(group2idx))

        return {"B": B, "T": T, "G": G, "groups": unique_groups, "unit": t_unit}

    return {"B": B, "T": T, "unit": t_unit}
