from curerate.model import ConversionModel

__version__ = "0.2.0"
__all__ = ["ConversionModel", "__version__"]
