import numpy as np
from matplotlib import pyplot as plt


def _plot_model(model, t_max, ci, ax):
    if ax is None:
        ax = plt.gca()

    t = np.linspace(0, t_max, 500)

    for grp in model._groups:
        df = model.predict(t, group=grp, ci=ci)

        label = str(grp) if grp is not None else "All"
        n = model._n_per_group[grp]
        k = model._k_per_group[grp]
        label = f"{label} (n={n}, k={k})"

        conversion = df["conversion"].values

        if "conversion_low" in df.columns:
            low = df["conversion_low"].values
            high = df["conversion_high"].values
            p = ax.fill_between(t, 100 * low, 100 * high, alpha=0.2)
            color = p.get_facecolor()[0]
            ax.plot(t, 100 * conversion, label=label, color=color,
                    linewidth=1.5, alpha=0.7)
        else:
            ax.plot(t, 100 * conversion, label=label,
                    linewidth=1.5, alpha=0.7)

    ax.set_xlabel(f"Time ({model._unit})")
    ax.set_ylabel("Conversion rate %")
    ax.legend()
    ax.grid(True)
    return ax
