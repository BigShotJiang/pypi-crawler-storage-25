from jax.numpy import isnan, exp, dot, log, sum
import jax.numpy as jnp
from jax.scipy.special import gammainc, expit, gammaln


def generalized_gamma_loss(x, X, B, T, W, fix_k, fix_p, hierarchical):
    
    k = exp(x[0]) if fix_k is None else fix_k
    p = exp(x[1]) if fix_p is None else fix_p 
    log_sigma_alpha = x[2]
    log_sigma_beta = x[3]
    a = x[4]
    b = x[5]
    n_features = int((len(x)-6)/2)
    alpha = x[6:6+n_features]
    beta = x[6+n_features:6+2*n_features]
    lambd = exp(dot(X, alpha)+a)

    log_pdf = log(p) + (k*p) * log(lambd) - gammaln(k) \
              + (k*p-1) * log(T) - (T*lambd)**p
    cdf = gammainc(k, (T*lambd)**p)

    c = expit(dot(X, beta)+b)
    LL_observed = log(c) + log_pdf
    LL_censored = log((1 - c) + c * (1 - cdf))

    LL_data = sum(
        W * B * LL_observed + 
        W * (1 - B) * LL_censored, 0) 

    if hierarchical:
        LL_prior_a = -4*log_sigma_alpha - 1/exp(log_sigma_alpha)**2 \
                     - dot(alpha, alpha) / (2*exp(log_sigma_alpha)**2) \
                     - n_features*log_sigma_alpha
        LL_prior_b = -4*log_sigma_beta - 1/exp(log_sigma_beta)**2 \
                     - dot(beta, beta) / (2*exp(log_sigma_beta)**2) \
                     - n_features*log_sigma_beta
        LL = LL_prior_a + LL_prior_b + LL_data
    else:
        LL = LL_data

    return jnp.where(jnp.isnan(LL), -jnp.inf, LL)



def predict_mean(params, x, t):
    lambd = exp(dot(x, params['alpha']) + params['a'])
    c = expit(dot(x, params['beta']) + params['b'])
    return c * gammainc(params['k'], (t * lambd) ** params['p'])