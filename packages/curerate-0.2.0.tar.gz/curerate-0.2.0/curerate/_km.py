import numpy
import scipy.stats
import warnings


class _SingleKM:
    """Kaplan-Meier estimator for a single group."""

    def fit(self, B, T):
        BT = [(b, t) for b, t in zip(B, T)
              if t >= 0 and 0 <= float(b) <= 1]
        if len(BT) < len(B):
            n_removed = len(B) - len(BT)
            warnings.warn('Removed %d/%d entries where T < 0 or B not 0/1'
                          % (n_removed, len(B)))
        B, T = ([z[i] for z in BT] for i in range(2))
        n = len(T)
        self._ts = [0.0]
        self._ss = [1.0]
        self._vs = [0.0]
        sum_var_terms = 0.0
        prod_s_terms = 1.0
        for t, b in sorted(zip(T, B)):
            d = float(b)
            self._ts.append(t)
            prod_s_terms *= 1 - d / n
            self._ss.append(prod_s_terms)
            if d == n == 1:
                sum_var_terms = float('inf')
            else:
                sum_var_terms += d / (n * (n - d))
            if sum_var_terms > 0:
                self._vs.append(1 / numpy.log(prod_s_terms) ** 2 * sum_var_terms)
            else:
                self._vs.append(0)
            n -= 1

        eps = 1e-9
        self._ss_clipped = numpy.clip(self._ss, eps, 1.0 - eps)

    def predict(self, t):
        t = numpy.asarray(t, dtype=float)
        scalar = t.ndim == 0
        t = numpy.atleast_1d(t)
        res = numpy.zeros(t.shape)
        for idx, value in numpy.ndenumerate(t):
            j = numpy.searchsorted(self._ts, value, side='right') - 1
            if j >= len(self._ts) - 1:
                res[idx] = float('nan')
            else:
                res[idx] = 1 - self._ss[j]
        return float(res) if scalar else res

    def predict_ci(self, t, ci=0.8):
        t = numpy.asarray(t, dtype=float)
        scalar = t.ndim == 0
        t = numpy.atleast_1d(t)
        res = numpy.zeros(t.shape + (3,))
        z_lo, z_hi = scipy.stats.norm.ppf([(1 - ci) / 2, (1 + ci) / 2])
        for idx, value in numpy.ndenumerate(t):
            j = numpy.searchsorted(self._ts, value, side='right') - 1
            if j >= len(self._ts) - 1:
                res[idx] = [float('nan')] * 3
            else:
                res[idx] = (
                    1 - self._ss[j],
                    1 - numpy.exp(-numpy.exp(
                        numpy.log(-numpy.log(self._ss_clipped[j]))
                        + z_hi * self._vs[j] ** 0.5)),
                    1 - numpy.exp(-numpy.exp(
                        numpy.log(-numpy.log(self._ss_clipped[j]))
                        + z_lo * self._vs[j] ** 0.5)),
                )
        return res[0] if scalar else res

    def predict_final(self):
        # Last event where a conversion occurred (B=1)
        # Walk backwards through _ss to find last non-1.0 survival change
        for i in range(len(self._ss) - 1, 0, -1):
            if self._ss[i] != self._ss[i - 1]:
                return 1 - self._ss[i]
        return 0.0


class _KaplanMeierModel:
    """Multi-group Kaplan-Meier wrapper used by ConversionModel."""

    def fit(self, B, T, G=None, groups=None):
        self._models = {}
        if G is None:
            km = _SingleKM()
            km.fit(B, T)
            self._models[None] = km
        else:
            for i, group in enumerate(groups):
                mask = G == i
                km = _SingleKM()
                km.fit(B[mask], T[mask])
                self._models[group] = km

    def predict(self, t, group=None):
        return self._models[group].predict(t)

    def predict_ci(self, t, ci, group=None):
        return self._models[group].predict_ci(t, ci)

    def predict_final(self, group=None):
        return self._models[group].predict_final()
