"""Parse dbt's manifest.json artifact."""

import json
import logging
from pathlib import Path

from .models import DbtMetric, DbtModel, DbtSemanticModel

logger = logging.getLogger(__name__)


def detect_dbt_metric_format(manifest: dict) -> str:
    """Returns 'legacy' | 'semantic_layer' | 'none'."""
    if "semantic_models" in manifest and manifest["semantic_models"]:
        return "semantic_layer"
    if "metrics" in manifest and manifest["metrics"]:
        return "legacy"
    return "none"


class DbtManifest:
    """
    Reads and parses dbt's manifest.json.

    Key fields extracted:
    - manifest["metrics"]          → dict of metric definitions
    - manifest["nodes"]            → dict of model/source nodes
    - manifest["sources"]          → dict of source definitions
    - manifest["semantic_models"]  → new-style semantic layer (dbt >= 1.6)
    """

    def __init__(self, manifest_path: str) -> None:
        path = Path(manifest_path)
        if not path.exists():
            raise FileNotFoundError(f"manifest.json not found at {manifest_path}")
        with open(path) as f:
            self._manifest = json.load(f)
        self._format = detect_dbt_metric_format(self._manifest)
        logger.debug("Loaded manifest from %s (format=%s)", manifest_path, self._format)

    @property
    def metric_format(self) -> str:
        """Returns 'legacy' | 'semantic_layer' | 'none'."""
        return self._format

    def get_metrics(self) -> list[DbtMetric]:
        """Return all metrics parsed from the manifest."""
        if self._format == "semantic_layer":
            return self._parse_semantic_metrics()
        if self._format == "legacy":
            return self._parse_legacy_metrics()
        logger.warning("No metrics found in manifest (format='none')")
        return []

    def get_models(self) -> list[DbtModel]:
        """Return all model nodes from the manifest."""
        models = []
        for unique_id, node in self._manifest.get("nodes", {}).items():
            if node.get("resource_type") != "model":
                continue
            models.append(
                DbtModel(
                    name=node.get("name", ""),
                    unique_id=unique_id,
                    schema=node.get("schema"),
                    database=node.get("database"),
                    alias=node.get("alias"),
                    description=node.get("description"),
                    columns=node.get("columns", {}),
                    meta=node.get("meta", {}),
                )
            )
        return models

    def get_semantic_models(self) -> list[DbtSemanticModel]:
        """Return semantic models (dbt >= 1.6)."""
        result = []
        for _uid, sm in self._manifest.get("semantic_models", {}).items():
            result.append(
                DbtSemanticModel(
                    name=sm.get("name", ""),
                    model=sm.get("model", ""),
                    description=sm.get("description"),
                    dimensions=sm.get("dimensions", []),
                    measures=sm.get("measures", []),
                    entities=sm.get("entities", []),
                )
            )
        return result

    def get_metric_by_name(self, name: str) -> DbtMetric | None:
        """Return a single metric by name, or None if not found."""
        for metric in self.get_metrics():
            if metric.name == name:
                return metric
        return None

    # ------------------------------------------------------------------
    # Internal parsers
    # ------------------------------------------------------------------

    def _resolve_model_table(self, model_ref: str) -> str | None:
        """Try to resolve a model ref to a fully-qualified table name."""
        for unique_id, node in self._manifest.get("nodes", {}).items():
            if node.get("resource_type") != "model":
                continue
            if node.get("name") == model_ref or unique_id.endswith(f".{model_ref}"):
                db = node.get("database", "")
                schema = node.get("schema", "")
                alias = node.get("alias") or node.get("name", model_ref)
                if db and schema:
                    return f"{db}.{schema}.{alias}"
                elif schema:
                    return f"{schema}.{alias}"
                return alias
        return None

    def _parse_legacy_metrics(self) -> list[DbtMetric]:
        """Parse old-style metrics: blocks (dbt < 1.6)."""
        metrics = []
        for _uid, m in self._manifest.get("metrics", {}).items():
            # Support both "calculation_method" (dbt 1.0-1.5) and "type"
            metric_type = m.get("calculation_method") or m.get("type", "simple")

            # Dimensions: may be list of strings or list of dicts
            raw_dims = m.get("dimensions", [])
            dimensions = []
            for d in raw_dims:
                if isinstance(d, str):
                    dimensions.append(d)
                elif isinstance(d, dict):
                    dimensions.append(d.get("name", str(d)))

            # Model ref
            model_ref = m.get("model")
            if isinstance(model_ref, str):
                # Strip "ref('...')" wrapper if present
                import re as _re
                model_ref = _re.sub(r"^ref\(['\"](.+)['\"]\)$", r"\1", model_ref.strip())

            warehouse_table = None
            if model_ref:
                warehouse_table = self._resolve_model_table(model_ref)

            # Timestamp column
            timestamp_col = m.get("timestamp") or m.get("time_grains", [None])[0]
            if isinstance(timestamp_col, list):
                timestamp_col = timestamp_col[0] if timestamp_col else None

            metrics.append(
                DbtMetric(
                    name=m.get("name", ""),
                    label=m.get("label") or m.get("name", ""),
                    description=m.get("description"),
                    type=metric_type,
                    sql=m.get("sql") or m.get("expression"),
                    measure=None,
                    model=model_ref,
                    dimensions=dimensions,
                    timestamp_column=timestamp_col,
                    filters=m.get("filters", []),
                    meta=m.get("meta", {}),
                    warehouse_table=warehouse_table,
                    format=m.get("meta", {}).get("format"),
                    currency=m.get("meta", {}).get("currency"),
                )
            )
        return metrics

    def _parse_semantic_metrics(self) -> list[DbtMetric]:
        """Parse new semantic layer metrics (dbt >= 1.6)."""
        metrics = []

        # Build measure → semantic_model map for dimension resolution
        measure_to_sm: dict[str, dict] = {}
        measure_exprs: dict[str, str | None] = {}   # measure_name → expr
        for _uid, sm in self._manifest.get("semantic_models", {}).items():
            for measure in sm.get("measures", []):
                mname = measure.get("name", "")
                measure_to_sm[mname] = sm
                measure_exprs[mname] = measure.get("expr")  # None if not set

        for _uid, m in self._manifest.get("metrics", {}).items():
            metric_type = m.get("type", "simple")

            # Measure reference
            type_params = m.get("type_params", {})
            measure_name = type_params.get("measure") or type_params.get("numerator", {}).get(
                "name"
            )
            if isinstance(measure_name, dict):
                measure_name = measure_name.get("name")

            # Resolve dimensions from associated semantic model
            dimensions: list[str] = []
            timestamp_col: str | None = None
            model_ref: str | None = None
            warehouse_table: str | None = None

            sm = measure_to_sm.get(measure_name or "")
            if sm:
                model_ref = sm.get("model", "").replace("ref('", "").rstrip("')")
                for dim in sm.get("dimensions", []):
                    dim_name = dim.get("name", "") if isinstance(dim, dict) else str(dim)
                    if isinstance(dim, dict) and dim.get("type") == "time":
                        timestamp_col = dim_name
                    else:
                        dimensions.append(dim_name)
                if model_ref:
                    warehouse_table = self._resolve_model_table(model_ref)

            metrics.append(
                DbtMetric(
                    name=m.get("name", ""),
                    label=m.get("label") or m.get("name", ""),
                    description=m.get("description"),
                    type=metric_type,
                    sql=None,
                    measure=measure_name,
                    measure_expr=measure_exprs.get(measure_name or ""),
                    model=model_ref,
                    dimensions=dimensions,
                    timestamp_column=timestamp_col,
                    filters=m.get("filter", {}).get("where_filters", [])
                    if isinstance(m.get("filter"), dict)
                    else [],
                    meta=m.get("meta", {}),
                    warehouse_table=warehouse_table,
                    format=m.get("meta", {}).get("format"),
                    currency=m.get("meta", {}).get("currency"),
                )
            )
        return metrics
