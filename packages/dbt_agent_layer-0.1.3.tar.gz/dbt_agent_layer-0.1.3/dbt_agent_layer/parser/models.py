"""Data models for parsed dbt project artifacts."""

from dataclasses import dataclass, field


@dataclass
class DbtMetric:
    """Represents a single dbt metric, handling both legacy and semantic layer formats."""

    name: str
    label: str
    description: str | None
    type: str  # "simple" | "ratio" | "cumulative" | "derived"
    sql: str | None  # raw SQL expression (old format)
    measure: str | None  # measure name (new semantic layer format)
    model: str | None  # ref model name
    dimensions: list[str] = field(default_factory=list)
    timestamp_column: str | None = None
    filters: list[dict] = field(default_factory=list)
    meta: dict = field(default_factory=dict)
    warehouse_table: str | None = None  # resolved fully-qualified table name
    format: str | None = None  # "currency" | "percentage" | "number"
    currency: str | None = None  # "USD" | "EUR" etc.
    measure_expr: str | None = None  # resolved expr for semantic layer measures (e.g. "1", "customer_id")


@dataclass
class DbtModel:
    """Represents a dbt model node."""

    name: str
    unique_id: str
    schema: str | None
    database: str | None
    alias: str | None
    description: str | None
    columns: dict = field(default_factory=dict)
    meta: dict = field(default_factory=dict)

    @property
    def relation_name(self) -> str | None:
        """Returns the fully-qualified table name if available."""
        if self.database and self.schema and (self.alias or self.name):
            return f"{self.database}.{self.schema}.{self.alias or self.name}"
        return None


@dataclass
class DbtSemanticModel:
    """Represents a dbt semantic model (dbt >= 1.6)."""

    name: str
    model: str
    description: str | None
    dimensions: list[dict] = field(default_factory=list)
    measures: list[dict] = field(default_factory=list)
    entities: list[dict] = field(default_factory=list)
