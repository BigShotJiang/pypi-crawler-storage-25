"""
dbt-agent setup — interactive wizard that replaces running init + build + connect separately.
"""

import json
import os
import subprocess
from pathlib import Path

import click
from rich.console import Console
from rich.panel import Panel
from rich.prompt import Confirm, Prompt
from rich.table import Table

console = Console()

# ── MCP client config paths ──────────────────────────────────────────────────

_MCP_CLIENTS = {
    "claude_desktop": {
        "label": "Claude Desktop",
        "paths": [
            Path.home() / "Library/Application Support/Claude/claude_desktop_config.json",
            Path.home() / ".config/claude/claude_desktop_config.json",  # Linux
        ],
    },
    "cursor": {
        "label": "Cursor",
        "paths": [
            Path.home() / ".cursor/mcp.json",
            Path.home() / "Library/Application Support/Cursor/mcp.json",
        ],
    },
    "claude_code": {
        "label": "Claude Code (claude.json)",
        "paths": [
            Path.home() / ".claude.json",
            Path.cwd() / ".claude.json",
        ],
    },
}


def _find_client_config(client_key: str) -> Path | None:
    """Return the first existing config path for a client, or the preferred default."""
    info = _MCP_CLIENTS[client_key]
    for p in info["paths"]:
        if p.exists():
            return p
    # Return the first (preferred) path even if it doesn't exist yet
    return info["paths"][0]


def _read_json(path: Path) -> dict:
    try:
        return json.loads(path.read_text()) if path.exists() else {}
    except json.JSONDecodeError:
        return {}


def _write_json(path: Path, data: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2))


def _inject_mcp_server(
    config_path: Path,
    server_name: str,
    project_dir: str,
    client_key: str,
) -> bool:
    """
    Inject an MCP server entry into the client config file.
    Returns True if the file was modified.
    """
    data = _read_json(config_path)

    entry = {
        "command": "dbt-agent",
        "args": ["serve", "--project-dir", project_dir, "--skip-build"],
        "env": {},
    }

    if client_key == "claude_code":
        # claude.json uses a different schema
        servers = data.setdefault("mcpServers", {})
        if server_name in servers and servers[server_name] == entry:
            return False
        servers[server_name] = entry
    else:
        # Claude Desktop / Cursor both use mcpServers at top level
        servers = data.setdefault("mcpServers", {})
        if server_name in servers and servers[server_name] == entry:
            return False
        servers[server_name] = entry

    _write_json(config_path, data)
    return True


def _generate_skills_file(metrics: list, project_dir: str, server_name: str) -> Path:
    """
    Generate a .claude/skills/<server_name>.md skills file that tells Claude
    about the available metrics and how to call them via MCP.
    """
    skills_dir = Path(project_dir) / ".claude" / "skills"
    skills_dir.mkdir(parents=True, exist_ok=True)
    skills_path = skills_dir / f"{server_name}.md"

    lines = [
        f"# {server_name} metrics",
        "",
        f"This project exposes {len(metrics)} dbt metrics via the `{server_name}` MCP server.",
        "Use the tools below to answer data questions accurately — never guess or hallucinate numbers.",
        "",
        "## Available metrics",
        "",
    ]

    for m in metrics:
        dims = ", ".join(m["dimensions"]) if m.get("dimensions") else "none"
        lines += [
            f"### `get_{m['name']}`",
            f"- **Label:** {m['label']}",
            f"- **Description:** {m.get('description') or 'N/A'}",
            f"- **Type:** {m.get('type', 'simple')}",
            f"- **Dimensions:** {dims}",
            f"- **Example:** `get_{m['name']}(period='current_month')`",
            "",
        ]

    lines += [
        "## Period formats",
        "",
        "- `current_month`, `prior_month`, `current_quarter`, `prior_quarter`",
        "- `current_year`, `last_7_days`, `last_30_days`, `last_90_days`",
        "- `2024-03` (specific month), `2024-Q1` (specific quarter)",
        "- `2024-01-01:2024-03-31` (custom range)",
        "",
        "## Always",
        "",
        "1. Call `list_metrics` first if unsure what metrics exist.",
        "2. Call the specific `get_<metric>` tool rather than `query_metric` when possible.",
        "3. Return the `narrative` field as-is — it is factually accurate.",
        "4. Surface the `anomaly` field if `is_anomaly` is true.",
    ]

    skills_path.write_text("\n".join(lines))
    return skills_path


@click.command()
@click.option(
    "--project-dir",
    default=None,
    help="Path to dbt project directory (default: current directory).",
    type=click.Path(file_okay=False),
)
def setup_cmd(project_dir: str | None) -> None:
    """
    Interactive setup wizard: init → build → connect to MCP clients.

    Replaces running init, build, and serve separately.
    """
    from ..config.settings import load_config, write_default_config, _detect_adapter_from_profiles
    from ..parser.project import DbtProject
    from ..parser.manifest import DbtManifest

    console.print(
        Panel(
            "[bold cyan]dbt-agent setup[/bold cyan]\n"
            "Connects your dbt project to AI agents in ~60 seconds.",
            border_style="cyan",
        )
    )

    # ── Step 1: Find dbt project ─────────────────────────────────────────────
    if project_dir is None:
        project_dir = Prompt.ask(
            "\n[bold]Where is your dbt project?[/bold]",
            default=str(Path.cwd()),
        )

    project_path = Path(project_dir).expanduser().resolve()

    if not (project_path / "dbt_project.yml").exists():
        console.print(f"[red]✗[/red] No dbt_project.yml found in {project_path}")
        raise SystemExit(1)

    try:
        dbt_project = DbtProject(str(project_path))
    except FileNotFoundError as e:
        console.print(f"[red]✗[/red] {e}")
        raise SystemExit(1)

    console.print(f"[green]✓[/green] dbt project: [cyan]{dbt_project.name}[/cyan]")

    # ── Step 2: Detect adapter ────────────────────────────────────────────────
    adapter_type = "duckdb"
    for profiles_dir in [project_path, Path.home() / ".dbt"]:
        profiles_path = profiles_dir / "profiles.yml"
        if profiles_path.exists():
            detected, _ = _detect_adapter_from_profiles(profiles_path, dbt_project.profile)
            if detected:
                adapter_type = detected
            break

    console.print(f"[green]✓[/green] adapter detected: [cyan]{adapter_type}[/cyan]")

    # ── Step 3: Write dbt-agent.yml if missing ───────────────────────────────
    config_path = project_path / "dbt-agent.yml"
    if not config_path.exists():
        write_default_config(str(project_path), adapter_type=adapter_type)
        console.print(f"[green]✓[/green] created [cyan]dbt-agent.yml[/cyan]")
    else:
        console.print(f"[dim]  dbt-agent.yml already exists — skipping[/dim]")

    # ── Step 4: Build (dbt compile + parse metrics) ───────────────────────────
    console.print("\n[bold]Step 1/3 — Compiling dbt project…[/bold]")
    skip_compile = False

    manifest_path = project_path / "target" / "manifest.json"
    if manifest_path.exists():
        skip_compile = not Confirm.ask(
            "  manifest.json found. Re-run dbt compile?", default=False
        )

    if not skip_compile:
        with console.status("  Running dbt compile…"):
            result = subprocess.run(
                ["dbt", "compile", "--project-dir", str(project_path)],
                capture_output=True, text=True,
            )
        if result.returncode != 0:
            console.print("  [yellow]⚠ dbt compile failed — using existing manifest if present[/yellow]")
        else:
            console.print("  [green]✓[/green] dbt compile succeeded")

    if not manifest_path.exists():
        console.print(f"  [red]✗[/red] manifest.json not found at {manifest_path}")
        console.print("  Run [bold]dbt compile[/bold] first, then re-run setup.")
        raise SystemExit(1)

    with console.status("  Parsing metrics…"):
        manifest = DbtManifest(str(manifest_path))
        metrics = manifest.get_metrics()

    config = load_config(str(project_path))
    if config.include_metrics:
        metrics = [m for m in metrics if m.name in config.include_metrics]
    if config.exclude_metrics:
        metrics = [m for m in metrics if m.name not in config.exclude_metrics]

    if not metrics:
        console.print("  [yellow]⚠ No metrics found.[/yellow] Add metrics: blocks to your schema.yml files.")
        raise SystemExit(1)

    # Show metrics table
    table = Table(show_header=True, header_style="bold")
    table.add_column("Metric", style="cyan")
    table.add_column("Label")
    table.add_column("Type", style="dim")
    table.add_column("Dimensions", style="dim")
    for m in metrics:
        table.add_row(m.name, m.label, m.type, ", ".join(m.dimensions) or "—")
    console.print(table)

    # Write cache
    import json as _json, datetime as _dt
    output_dir = project_path / "dbt_agent_tools"
    output_dir.mkdir(exist_ok=True)
    cache = {
        "generated_at": _dt.datetime.now(_dt.timezone.utc).isoformat(),
        "manifest_format": manifest.metric_format,
        "metrics": [
            {k: getattr(m, k) for k in
             ["name","label","description","type","sql","measure","measure_expr",
              "model","dimensions","timestamp_column","filters","meta",
              "warehouse_table","format","currency"]}
            for m in metrics
        ],
    }
    (output_dir / "manifest_cache.json").write_text(_json.dumps(cache, indent=2))
    console.print(f"  [green]✓[/green] {len(metrics)} metric tools built → [cyan]dbt_agent_tools/[/cyan]")

    # ── Step 5: Choose MCP server name ───────────────────────────────────────
    console.print("\n[bold]Step 2/3 — Configure MCP server[/bold]")
    default_name = dbt_project.name.replace("_", "-")
    server_name = Prompt.ask("  MCP server name (shown in your AI client)", default=default_name)

    # ── Step 6: Connect to MCP clients ───────────────────────────────────────
    console.print("\n[bold]Step 3/3 — Connect to AI clients[/bold]")

    available_clients = []
    for key, info in _MCP_CLIENTS.items():
        config_file = _find_client_config(key)
        exists = config_file and config_file.exists()
        status = "[green]found[/green]" if exists else "[dim]not installed[/dim]"
        console.print(f"  {info['label']:<22} {status}")
        if exists:
            available_clients.append(key)

    if not available_clients:
        console.print("  [yellow]No AI clients detected.[/yellow] You can add manually — see below.")
    else:
        console.print()
        for key in available_clients:
            info = _MCP_CLIENTS[key]
            if Confirm.ask(f"  Add to [cyan]{info['label']}[/cyan]?", default=True):
                config_file = _find_client_config(key)
                modified = _inject_mcp_server(config_file, server_name, str(project_path), key)
                if modified:
                    console.print(f"  [green]✓[/green] Injected into {config_file}")
                else:
                    console.print(f"  [dim]  Already configured in {config_file}[/dim]")

    # ── Step 7: Generate skills file ──────────────────────────────────────────
    if Confirm.ask("\n  Generate a Claude Code skills file for your metrics?", default=True):
        metrics_dicts = [
            {"name": m.name, "label": m.label, "description": m.description,
             "type": m.type, "dimensions": m.dimensions}
            for m in metrics
        ]
        skills_path = _generate_skills_file(metrics_dicts, str(project_path), server_name)
        console.print(f"  [green]✓[/green] Skills file → [cyan]{skills_path}[/cyan]")

    # ── Done ──────────────────────────────────────────────────────────────────
    console.print(
        Panel(
            f"[bold green]Setup complete![/bold green]\n\n"
            f"  {len(metrics)} metrics ready as MCP tools\n"
            f"  Server name: [cyan]{server_name}[/cyan]\n\n"
            "[bold]Start the server:[/bold]\n"
            f"  [cyan]dbt-agent serve --project-dir {project_path} --skip-build[/cyan]\n\n"
            "[bold]Or add this to your claude_desktop_config.json manually:[/bold]\n"
            + _json.dumps({
                "mcpServers": {
                    server_name: {
                        "command": "dbt-agent",
                        "args": ["serve", "--project-dir", str(project_path), "--skip-build"],
                    }
                }
            }, indent=2),
            title="✓ dbt-agent setup",
            border_style="green",
        )
    )
