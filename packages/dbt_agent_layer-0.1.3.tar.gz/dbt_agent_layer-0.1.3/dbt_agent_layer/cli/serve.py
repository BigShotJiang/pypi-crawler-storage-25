"""dbt-agent serve command."""

import asyncio
import json
import logging
from pathlib import Path

import click
from rich.console import Console
from rich.panel import Panel

console = Console()
logger = logging.getLogger(__name__)


@click.command()
@click.option(
    "--project-dir",
    default=".",
    show_default=True,
    help="Path to dbt project directory.",
    type=click.Path(file_okay=False),
)
@click.option(
    "--port",
    default=None,
    type=int,
    help="Override port from dbt-agent.yml (default: 8000).",
)
@click.option(
    "--transport",
    default=None,
    type=click.Choice(["stdio", "http"], case_sensitive=False),
    help="MCP transport: stdio (Claude Desktop) or http.",
)
@click.option(
    "--skip-build",
    is_flag=True,
    default=False,
    help="Use existing ./dbt_agent_tools/; skip build step.",
)
@click.option(
    "--reload",
    is_flag=True,
    default=False,
    help="Hot-reload on dbt project changes (dev mode).",
)
@click.option(
    "--connect",
    is_flag=True,
    default=False,
    help="Auto-register this server in Claude Desktop / Cursor / Claude Code before starting.",
)
@click.option(
    "--name",
    default=None,
    help="MCP server name to register in client configs (default: dbt project name).",
)
def serve_cmd(
    project_dir: str,
    port: int | None,
    transport: str | None,
    skip_build: bool,
    reload: bool,
    connect: bool,
    name: str | None,
) -> None:
    """Start the MCP server exposing all dbt metrics as callable tools."""
    from ..config.settings import load_config
    from ..executor.factory import get_executor
    from ..parser.models import DbtMetric

    project_path = Path(project_dir).expanduser().resolve()
    config = load_config(str(project_path))

    # --- Auto-connect to MCP clients if requested ---
    if connect:
        from .setup import _MCP_CLIENTS, _find_client_config, _inject_mcp_server
        server_name = name or project_path.name.replace("_", "-")
        console.print(f"\n[bold]Registering MCP server '[cyan]{server_name}[/cyan]' in AI clients…[/bold]")
        any_found = False
        for key, info in _MCP_CLIENTS.items():
            cfg_path = _find_client_config(key)
            if cfg_path and cfg_path.exists():
                any_found = True
                modified = _inject_mcp_server(cfg_path, server_name, str(project_path), key)
                status = "[green]✓ updated[/green]" if modified else "[dim]already set[/dim]"
                console.print(f"  {info['label']:<22} {status}  ({cfg_path})")
        if not any_found:
            console.print("  [yellow]No AI client config files found.[/yellow] Run [bold]dbt-agent setup[/bold] for guided setup.")
        console.print()

    # Override config from CLI flags
    if port is not None:
        config.port = port
    if transport is not None:
        config.transport = transport

    # --- Build step ---
    metrics = _load_metrics(project_path, skip_build, config)

    if not metrics:
        console.print(
            "[yellow]Warning:[/yellow] No metrics found. "
            "Run [bold]dbt-agent build[/bold] or check your dbt project for metrics: blocks."
        )

    # --- Executor ---
    try:
        executor = get_executor(config)
    except Exception as e:
        console.print(f"[red]Error creating executor:[/red] {e}")
        raise SystemExit(1)

    # --- Test connection ---
    async def _test():
        return await executor.test_connection()

    ok = asyncio.run(_test())
    if not ok:
        console.print(
            f"[yellow]Warning:[/yellow] Could not connect to {config.adapter_type}. "
            "Metric queries will fail until the connection is available."
        )

    # --- Create MCP server ---
    from ..mcp.server import create_server

    server = create_server(metrics, executor, config)

    console.print(
        Panel(
            f"[bold green]dbt-agent-layer MCP server starting[/bold green]\n\n"
            f"  metrics   : [cyan]{len(metrics)}[/cyan]\n"
            f"  adapter   : [cyan]{config.adapter_type}[/cyan]\n"
            f"  transport : [cyan]{config.transport}[/cyan]\n"
            + (f"  port      : [cyan]{config.port}[/cyan]\n" if config.transport == "http" else "")
            + "\n[bold]Connect with Claude Desktop:[/bold]\n"
            '  Add to claude_desktop_config.json → mcpServers → "dbt-metrics"',
            title="dbt-agent serve",
            border_style="blue",
        )
    )

    # --- Start server ---
    if config.transport == "http":
        # FastMCP.run() does not accept host/port; drive uvicorn directly.
        try:
            import uvicorn
        except ImportError:
            raise SystemExit(
                "uvicorn is required for HTTP transport. "
                "Run: pip install uvicorn"
            )
        asgi_app = server.streamable_http_app()
        uvicorn.run(asgi_app, host=config.host, port=config.port)
    else:
        server.run(transport="stdio")


def _load_metrics(
    project_path: Path, skip_build: bool, config: "AgentConfig"  # noqa: F821
) -> list["DbtMetric"]:  # noqa: F821
    """Load metrics from manifest cache or by running the build step."""
    from ..parser.models import DbtMetric

    # Try cached manifest first if skip_build
    cache_path = project_path / "dbt_agent_tools" / "manifest_cache.json"
    if skip_build and cache_path.exists():
        try:
            with open(cache_path) as f:
                cache = json.load(f)
            metrics = []
            for m in cache.get("metrics", []):
                metrics.append(
                    DbtMetric(
                        name=m["name"],
                        label=m["label"],
                        description=m.get("description"),
                        type=m.get("type", "simple"),
                        sql=m.get("sql"),
                        measure=m.get("measure"),
                        model=m.get("model"),
                        dimensions=m.get("dimensions", []),
                        timestamp_column=m.get("timestamp_column"),
                        filters=m.get("filters", []),
                        meta=m.get("meta", {}),
                        warehouse_table=m.get("warehouse_table"),
                        format=m.get("format"),
                        currency=m.get("currency"),
                    )
                )
            console.print(
                f"[dim]Loaded {len(metrics)} metrics from cache ({cache_path})[/dim]"
            )
            return metrics
        except Exception as e:
            console.print(f"[yellow]Cache load failed ({e}), rebuilding...[/yellow]")

    # Build from manifest
    from ..parser.project import DbtProject
    from ..parser.manifest import DbtManifest

    try:
        dbt_project = DbtProject(str(project_path))
        manifest_path = dbt_project.find_manifest()
    except FileNotFoundError:
        # Try schema file parsing as last resort
        console.print(
            "[yellow]manifest.json not found — scanning schema.yml files...[/yellow]"
        )
        from ..parser.semantic_layer import parse_schema_files
        metrics = parse_schema_files(str(project_path))
        return metrics

    with console.status("[bold blue]Parsing metrics from manifest...[/bold blue]"):
        manifest = DbtManifest(str(manifest_path))
        metrics = manifest.get_metrics()

    return metrics
