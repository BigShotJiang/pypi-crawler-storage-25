"""Tests for SQL generation and period resolution."""

from datetime import date

import pytest

from dbt_agent_layer.generator.tool_builder import resolve_period, build_metric_sql
from dbt_agent_layer.parser.models import DbtMetric


@pytest.fixture
def revenue_metric() -> DbtMetric:
    return DbtMetric(
        name="monthly_revenue",
        label="Monthly Revenue",
        description="Total revenue",
        type="sum",
        sql="SUM(revenue)",
        measure=None,
        model="fct_revenue",
        dimensions=["channel"],
        timestamp_column="order_month",
        filters=[],
        meta={},
        warehouse_table="main.main.fct_revenue",
        format="currency",
        currency="USD",
    )


class TestResolvePeriod:
    def test_current_month(self) -> None:
        start, end = resolve_period("current_month")
        today = date.today()
        assert start.month == today.month
        assert start.day == 1
        assert end.month == today.month

    def test_prior_month(self) -> None:
        start, end = resolve_period("prior_month")
        today = date.today()
        expected_month = today.month - 1 if today.month > 1 else 12
        assert start.month == expected_month

    def test_iso_year_month(self) -> None:
        start, end = resolve_period("2024-03")
        assert start == date(2024, 3, 1)
        assert end == date(2024, 3, 31)

    def test_iso_range(self) -> None:
        start, end = resolve_period("2024-01-01:2024-03-31")
        assert start == date(2024, 1, 1)
        assert end == date(2024, 3, 31)

    def test_quarter(self) -> None:
        start, end = resolve_period("2024-Q1")
        assert start == date(2024, 1, 1)
        assert end == date(2024, 3, 31)

    def test_last_30_days(self) -> None:
        start, end = resolve_period("last_30_days")
        assert end == date.today()
        assert (end - start).days == 29

    def test_current_year(self) -> None:
        start, end = resolve_period("current_year")
        assert start.month == 1 and start.day == 1
        assert end.month == 12 and end.day == 31

    def test_invalid_period(self) -> None:
        with pytest.raises(ValueError, match="Cannot parse period"):
            resolve_period("not-a-period")


class TestBuildMetricSql:
    def test_basic_sql(self, revenue_metric: DbtMetric) -> None:
        sql = build_metric_sql(
            metric=revenue_metric,
            start_date=date(2024, 3, 1),
            end_date=date(2024, 3, 31),
            adapter_type="duckdb",
        )
        assert "SUM(revenue)" in sql
        # DuckDB strips the catalog prefix: "main.main.fct_revenue" → "main.fct_revenue"
        assert "main.fct_revenue" in sql
        assert "2024-03-01" in sql
        assert "2024-03-31" in sql

    def test_breakdown_adds_group_by(self, revenue_metric: DbtMetric) -> None:
        sql = build_metric_sql(
            metric=revenue_metric,
            start_date=date(2024, 3, 1),
            end_date=date(2024, 3, 31),
            breakdown_by="channel",
            adapter_type="duckdb",
        )
        assert "GROUP BY channel" in sql
        assert "channel" in sql.split("SELECT")[1].split("FROM")[0]

    def test_breakdown_invalid_dimension(self, revenue_metric: DbtMetric) -> None:
        with pytest.raises(ValueError, match="not available"):
            build_metric_sql(
                metric=revenue_metric,
                start_date=date(2024, 3, 1),
                end_date=date(2024, 3, 31),
                breakdown_by="invalid_dim",
                adapter_type="duckdb",
            )

    def test_runtime_filters(self, revenue_metric: DbtMetric) -> None:
        sql = build_metric_sql(
            metric=revenue_metric,
            start_date=date(2024, 3, 1),
            end_date=date(2024, 3, 31),
            filters={"channel": "web"},
            adapter_type="duckdb",
        )
        assert "channel = 'web'" in sql

    def test_bigquery_date_format(self, revenue_metric: DbtMetric) -> None:
        sql = build_metric_sql(
            metric=revenue_metric,
            start_date=date(2024, 3, 1),
            end_date=date(2024, 3, 31),
            adapter_type="bigquery",
        )
        assert "DATE '2024-03-01'" in sql

    def test_no_timestamp_column(self) -> None:
        metric = DbtMetric(
            name="total_count",
            label="Total Count",
            description=None,
            type="count",
            sql="COUNT(*)",
            measure=None,
            model="fct_revenue",
            dimensions=[],
            timestamp_column=None,
            filters=[],
            meta={},
            warehouse_table="main.main.fct_revenue",
        )
        sql = build_metric_sql(
            metric=metric,
            start_date=date(2024, 3, 1),
            end_date=date(2024, 3, 31),
            adapter_type="duckdb",
        )
        # No WHERE clause when no timestamp column
        assert "WHERE" not in sql or "order_month" not in sql
