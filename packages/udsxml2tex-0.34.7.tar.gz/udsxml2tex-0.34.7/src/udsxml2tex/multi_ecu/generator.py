"""System integration document generator for multi-ECU systems.

Produces a Markdown / LaTeX / HTML document that describes the system as a
whole — the per-ECU details remain in each ECU's individual document
(generated via the existing single-ECU `TexGenerator`). The system document
covers:

  - System name, ECU roster (name, role, description)
  - Topology table and topology diagram (SVG inline for HTML, TikZ figure for LaTeX)
  - Routing matrix (each rule's match criteria, inferred flag)
  - Per-rule sequence diagram (LaTeX only)
  - Cross-ECU coverage tables: SID, DID, RID per ECU
  - Cross-ECU NRC table
  - Validation findings (calls validate_system)

Public API:
    generate_system_markdown(system, *, validate=True) -> str
    generate_system_latex(system, *, validate=True)    -> str
    generate_system_html(system, *, validate=True)     -> str
"""

from __future__ import annotations

from typing import Any, Iterable

from udsxml2tex.multi_ecu.models import EcuSystem, RoutingRule
from udsxml2tex.multi_ecu.validator import validate_system


# ----------------------------------------------------------------------------
# Shared helpers
# ----------------------------------------------------------------------------

def _all_sids(system: EcuSystem) -> list[int]:
    return sorted({s.service_id for ecu in system.ecus.values()
                   if ecu.spec for s in (ecu.spec.services or [])})


def _all_dids(system: EcuSystem) -> list[int]:
    return sorted({d.did_id for ecu in system.ecus.values()
                   if ecu.spec for d in (ecu.spec.dids or [])})


def _all_rids(system: EcuSystem) -> list[int]:
    return sorted({r.routine_id for ecu in system.ecus.values()
                   if ecu.spec for r in (ecu.spec.routines or [])})


def _all_nrcs(system: EcuSystem) -> dict[int, str]:
    out: dict[int, str] = {}
    for ecu in system.ecus.values():
        if not ecu.spec:
            continue
        for svc in (ecu.spec.services or []):
            for nrc in (svc.nrc_list or []):
                out.setdefault(nrc.nrc_code, nrc.nrc_name)
    return dict(sorted(out.items()))


def _has_sid(spec: Any, sid: int) -> bool:
    return any(s.service_id == sid for s in (spec.services or []))


def _has_did(spec: Any, did: int) -> bool:
    return any(d.did_id == did for d in (spec.dids or []))


def _has_rid(spec: Any, rid: int) -> bool:
    return any(r.routine_id == rid for r in (spec.routines or []))


def _has_nrc(spec: Any, nrc_code: int) -> bool:
    for svc in (spec.services or []):
        if any(n.nrc_code == nrc_code for n in (svc.nrc_list or [])):
            return True
    return False


# ----------------------------------------------------------------------------
# Markdown
# ----------------------------------------------------------------------------

def generate_system_markdown(system: EcuSystem, *, validate: bool = True) -> str:
    lines: list[str] = []
    lines.append(f"# System Integration Document: {system.name}")
    if system.description:
        lines.append("")
        lines.append(system.description)
    lines.append("")

    # ECU roster
    lines.append("## ECU Roster")
    lines.append("")
    lines.append("| Name | Role | ARXML | DEM | Description |")
    lines.append("|---|---|---|---|---|")
    for ecu in system.ecus.values():
        arxml = ", ".join(p.name for p in ecu.arxml_files) or "—"
        dem = ecu.dem_arxml.name if ecu.dem_arxml else "—"
        desc = ecu.description or ""
        lines.append(
            f"| **{ecu.name}** | `{ecu.role.value}` | {arxml} | {dem} | {desc} |"
        )
    lines.append("")

    # Topology
    if system.topology.connections:
        lines.append("## Physical Topology")
        lines.append("")
        lines.append("| From | To | Medium | Description |")
        lines.append("|---|---|---|---|")
        for c in system.topology.connections:
            lines.append(
                f"| {c.from_ecu} | {c.to_ecu} | {c.medium} | {c.description or ''} |"
            )
        lines.append("")

    # Routing matrix
    if system.routing_rules:
        lines.append("## Routing Matrix")
        lines.append("")
        lines.append(
            "Diagnostic requests received by the source ECU that match the "
            "criteria below are forwarded to the target ECU. Rules tagged "
            "*inferred* were derived heuristically from ARXML coverage gaps; "
            "review and convert them into explicit rules in the system "
            "config when verified."
        )
        lines.append("")
        lines.append("| # | From | To | Match | Via | Source | Description |")
        lines.append("|---|---|---|---|---|---|---|")
        for i, r in enumerate(system.routing_rules, start=1):
            origin = "inferred" if r.inferred else "explicit"
            via = r.via or "—"
            lines.append(
                f"| {i} | {r.from_ecu} | {r.to_ecu} | "
                f"{r.match.description()} | {via} | {origin} | "
                f"{r.description or ''} |"
            )
        lines.append("")

    # Cross-ECU coverage matrices
    ecu_names = list(system.ecus.keys())

    sids = _all_sids(system)
    if sids:
        lines.append("## SID × ECU Coverage")
        lines.append("")
        header = "| SID |" + "".join(f" {n} |" for n in ecu_names)
        sep = "|---|" + "|".join("---" for _ in ecu_names) + "|"
        lines.append(header)
        lines.append(sep)
        for sid in sids:
            row = f"| `0x{sid:02X}` |"
            for n in ecu_names:
                spec = system.ecus[n].spec
                row += " ✓ |" if spec and _has_sid(spec, sid) else " — |"
            lines.append(row)
        lines.append("")

    dids = _all_dids(system)
    if dids:
        lines.append("## DID × ECU Coverage")
        lines.append("")
        header = "| DID |" + "".join(f" {n} |" for n in ecu_names)
        sep = "|---|" + "|".join("---" for _ in ecu_names) + "|"
        lines.append(header)
        lines.append(sep)
        for did in dids:
            row = f"| `0x{did:04X}` |"
            for n in ecu_names:
                spec = system.ecus[n].spec
                row += " ✓ |" if spec and _has_did(spec, did) else " — |"
            lines.append(row)
        lines.append("")

    rids = _all_rids(system)
    if rids:
        lines.append("## RID × ECU Coverage")
        lines.append("")
        header = "| RID |" + "".join(f" {n} |" for n in ecu_names)
        sep = "|---|" + "|".join("---" for _ in ecu_names) + "|"
        lines.append(header)
        lines.append(sep)
        for rid in rids:
            row = f"| `0x{rid:04X}` |"
            for n in ecu_names:
                spec = system.ecus[n].spec
                row += " ✓ |" if spec and _has_rid(spec, rid) else " — |"
            lines.append(row)
        lines.append("")

    nrcs = _all_nrcs(system)
    if nrcs:
        lines.append("## NRC × ECU Coverage")
        lines.append("")
        header = "| NRC | Description |" + "".join(f" {n} |" for n in ecu_names)
        sep = "|---|---|" + "|".join("---" for _ in ecu_names) + "|"
        lines.append(header)
        lines.append(sep)
        for code, name in nrcs.items():
            row = f"| `0x{code:02X}` | {name} |"
            for n in ecu_names:
                spec = system.ecus[n].spec
                row += " ✓ |" if spec and _has_nrc(spec, code) else " — |"
            lines.append(row)
        lines.append("")

    # Validation
    if validate:
        result = validate_system(system)
        lines.append("## Cross-ECU Validation")
        lines.append("")
        lines.append(f"**Result:** {result.summary()}")
        lines.append("")
        if result.issues:
            lines.append("| Severity | Category | Item | Message |")
            lines.append("|---|---|---|---|")
            for issue in result.issues:
                lines.append(
                    f"| {issue.severity} | {issue.category} | "
                    f"{issue.item_id or '—'} | {issue.message} |"
                )
        else:
            lines.append("✓ No cross-ECU consistency issues detected.")
        lines.append("")

    return "\n".join(lines)


# ----------------------------------------------------------------------------
# LaTeX
# ----------------------------------------------------------------------------

def _tex_escape(s: str) -> str:
    return (
        s.replace("\\", r"\textbackslash{}")
         .replace("&", r"\&")
         .replace("%", r"\%")
         .replace("#", r"\#")
         .replace("_", r"\_")
         .replace("$", r"\$")
         .replace("{", r"\{")
         .replace("}", r"\}")
         .replace("^", r"\^{}")
         .replace("~", r"\~{}")
    )


def generate_system_latex(
    system: EcuSystem,
    *,
    validate: bool = True,
    use_udsspec_cls: bool = True,
) -> str:
    """Standalone LaTeX document for the system integration spec.

    The output mirrors the single-ECU spec presentation: it uses the
    bundled ``udsspec.cls`` (which sets up the title page, fancyhdr
    header table, geometry, fonts, etc.) so single- and multi-ECU PDFs
    share the same visual style. The caller must place ``udsspec.cls``
    (and ``tikz-uml.sty``) next to the produced ``system.tex`` before
    compiling — see :func:`udsxml2tex.webserver._app` ``/system`` route
    or the ``--system-output-dir`` CLI flow.

    Args:
        system: Parsed multi-ECU system.
        validate: When True, append a ``Cross-ECU Validation`` section.
        use_udsspec_cls: When True (default), emit ``\\documentclass{udsspec}``
            so the document inherits the single-ECU style. Set to False
            to fall back to a stand-alone ``article``-class document
            (legacy behaviour, no external .cls dependency).
    """
    from udsxml2tex.multi_ecu.visualizations import generate_topology_tikz

    lines: list[str] = []

    if use_udsspec_cls:
        # Inherit the single-ECU presentation: same title page, header
        # band, fonts, and section styling. The .cls file (default or
        # user-supplied) must be copied next to system.tex by the caller.
        lines.append(r"\documentclass{udsspec}")
        lines.append(r"\ecuname{" + _tex_escape(system.name or "System") + "}")
        lines.append(r"\docfooter{System Integration Document — generated by udsxml2tex}")
        lines.append(r"\usepackage{tikz}")
        lines.append(r"\usetikzlibrary{positioning, arrows.meta, shapes.geometric, calc}")
        lines.append(r"\definecolor{ecugw}{HTML}{334466}")
        lines.append(r"\definecolor{ecuep}{HTML}{2A6E2A}")
        lines.append(r"\definecolor{ecupeer}{HTML}{996600}")
        lines.append(r"\title{%")
        lines.append(r"  \vspace{1em}")
        lines.append(r"  \huge \textbf{UDS Specification}\\")
        lines.append(r"  \Large System Integration Document\\")
        lines.append(r"  \large " + _tex_escape(system.name or "System"))
        lines.append(r"}")
        lines.append(r"\author{Generated by udsxml2tex}")
        lines.append(r"\date{\today}")
        lines.append(r"\begin{document}")
        lines.append(r"\maketitle")
        lines.append(r"\thispagestyle{fancy}")
        if system.description:
            lines.append(r"\begin{abstract}")
            lines.append(_tex_escape(system.description))
            lines.append(r"\end{abstract}")
        lines.append(r"\newpage")
        lines.append(r"\tableofcontents")
        lines.append(r"\newpage")
    else:
        lines.append(r"\documentclass[11pt,a4paper]{article}")
        lines.append(r"\usepackage[margin=2.5cm]{geometry}")
        lines.append(r"\usepackage{tikz}")
        lines.append(r"\usepackage{xcolor}")
        lines.append(r"\usepackage{longtable}")
        lines.append(r"\usepackage{booktabs}")
        lines.append(r"\usepackage{array}")
        lines.append(r"\usepackage{hyperref}")
        lines.append(r"\usetikzlibrary{positioning, arrows.meta, shapes.geometric, calc}")
        lines.append(r"\definecolor{ecugw}{HTML}{334466}")
        lines.append(r"\definecolor{ecuep}{HTML}{2A6E2A}")
        lines.append(r"\definecolor{ecupeer}{HTML}{996600}")
        lines.append(r"\title{System Integration Document\\\large " + _tex_escape(system.name) + "}")
        lines.append(r"\author{Generated by udsxml2tex}")
        lines.append(r"\date{\today}")
        lines.append(r"\begin{document}")
        lines.append(r"\maketitle")
        if system.description:
            lines.append(r"\begin{abstract}")
            lines.append(_tex_escape(system.description))
            lines.append(r"\end{abstract}")

    # ---- §1 Introduction (mirrors single-ECU 0_intro structure) -----------
    lines.append(r"\section{Introduction}")
    lines.append(
        r"This document describes the diagnostic integration of a "
        r"multi-ECU system. It complements the per-ECU UDS specification "
        r"PDFs by capturing the system topology, the routing matrix used "
        r"by gateway ECUs, and the cross-ECU coverage of services, "
        r"identifiers, and negative-response codes."
    )
    lines.append(r"\subsection{Document Scope}")
    lines.append(
        r"For a per-ECU view of sessions, security levels, services, "
        r"DIDs, RIDs, DEM events and DTCs, refer to the corresponding "
        r"\texttt{<ecu>/spec.pdf} bundled alongside this document. "
        r"This document focuses on system-level concerns: topology, "
        r"routing and consistency."
    )
    n_ecus = len(system.ecus)
    lines.append(r"\subsection{System at a Glance}")
    lines.append(r"\begin{itemize}")
    lines.append(r"\item System name: \texttt{" + _tex_escape(system.name or "—") + r"}")
    lines.append(r"\item Number of ECUs: \texttt{" + str(n_ecus) + r"}")
    lines.append(
        r"\item Routing rules: \texttt{"
        + str(len(system.routing_rules))
        + r"} ("
        + str(sum(1 for r in system.routing_rules if r.inferred))
        + r" inferred)"
    )
    lines.append(
        r"\item Physical connections: \texttt{"
        + str(len(system.topology.connections))
        + r"}"
    )
    lines.append(r"\end{itemize}")

    # ---- §2 ECU Roster ---------------------------------------------------
    lines.append(r"\section{ECU Roster}")
    lines.append(r"\begin{longtable}{lll p{6cm}}")
    lines.append(r"\toprule")
    lines.append(r"\textbf{Name} & \textbf{Role} & \textbf{ARXML} & \textbf{Description} \\")
    lines.append(r"\midrule")
    for ecu in system.ecus.values():
        arxml = _tex_escape(", ".join(p.name for p in ecu.arxml_files) or "—")
        desc = _tex_escape(ecu.description or "")
        lines.append(
            f"\\textbf{{{_tex_escape(ecu.name)}}} & "
            f"\\texttt{{{ecu.role.value}}} & {arxml} & {desc} \\\\"
        )
    lines.append(r"\bottomrule")
    lines.append(r"\end{longtable}")

    # ---- §3 System Topology ----------------------------------------------
    lines.append(r"\section{System Topology}")
    topo_full = generate_topology_tikz(system)
    start = topo_full.find(r"\begin{tikzpicture}")
    end = topo_full.find(r"\end{tikzpicture}") + len(r"\end{tikzpicture}")
    if start >= 0 and end > start:
        lines.append(r"\begin{figure}[h!]")
        lines.append(r"\centering")
        lines.append(topo_full[start:end])
        lines.append(r"\caption{System topology: ECUs and routing flows.}")
        lines.append(r"\end{figure}")

    if system.topology.connections:
        lines.append(r"\subsection{Physical Connections}")
        lines.append(r"\begin{longtable}{lllp{5cm}}")
        lines.append(r"\toprule")
        lines.append(r"\textbf{From} & \textbf{To} & \textbf{Medium} & \textbf{Description} \\")
        lines.append(r"\midrule")
        for c in system.topology.connections:
            lines.append(
                f"{_tex_escape(c.from_ecu)} & {_tex_escape(c.to_ecu)} & "
                f"{_tex_escape(c.medium)} & {_tex_escape(c.description or '')} \\\\"
            )
        lines.append(r"\bottomrule")
        lines.append(r"\end{longtable}")

    # ---- §4 Routing Matrix -----------------------------------------------
    if system.routing_rules:
        lines.append(r"\section{Routing Matrix}")
        lines.append(
            r"Diagnostic requests received by the source ECU that match the "
            r"criteria below are forwarded to the target ECU. Rules tagged "
            r"\emph{inferred} were derived heuristically from ARXML coverage "
            r"gaps; verify and convert them into explicit rules when confirmed."
        )
        lines.append(r"\begin{longtable}{lllp{4.5cm}lp{3cm}}")
        lines.append(r"\toprule")
        lines.append(r"\textbf{\#} & \textbf{From} & \textbf{To} & "
                     r"\textbf{Match} & \textbf{Origin} & \textbf{Description} \\")
        lines.append(r"\midrule")
        for i, r in enumerate(system.routing_rules, start=1):
            origin = "inferred" if r.inferred else "explicit"
            lines.append(
                f"{i} & {_tex_escape(r.from_ecu)} & {_tex_escape(r.to_ecu)} & "
                f"{_tex_escape(r.match.description())} & "
                f"\\texttt{{{origin}}} & {_tex_escape(r.description or '')} \\\\"
            )
        lines.append(r"\bottomrule")
        lines.append(r"\end{longtable}")

    # ---- §5 Cross-ECU Coverage -------------------------------------------
    ecu_names = list(system.ecus.keys())
    n = len(ecu_names)

    def _coverage_section(title: str, ids: Iterable[int], fmt: str,
                           predicate, extra_col: bool = False,
                           extra_label: str = "") -> None:
        lst = list(ids)
        if not lst:
            return
        lines.append(r"\subsection{" + title + "}")
        ec = "l" if extra_col else ""
        lines.append(r"\begin{longtable}{l" + ec + "c" * n + "}")
        lines.append(r"\toprule")
        head = r"\textbf{ID}"
        if extra_col:
            head += " & \\textbf{" + extra_label + "}"
        for nm in ecu_names:
            head += " & \\textbf{" + _tex_escape(nm) + "}"
        head += r" \\"
        lines.append(head)
        lines.append(r"\midrule")
        for x in lst:
            row = f"\\texttt{{{fmt.format(x)}}}"
            if extra_col:
                continue
            for nm in ecu_names:
                spec = system.ecus[nm].spec
                row += " & " + ("$\\bullet$" if spec and predicate(spec, x) else "---")
            row += r" \\"
            lines.append(row)
        lines.append(r"\bottomrule")
        lines.append(r"\end{longtable}")

    lines.append(r"\section{Cross-ECU Coverage}")
    _coverage_section("SID Coverage", _all_sids(system), "0x{:02X}", _has_sid)
    _coverage_section("DID Coverage", _all_dids(system), "0x{:04X}", _has_did)
    _coverage_section("RID Coverage", _all_rids(system), "0x{:04X}", _has_rid)

    nrcs = _all_nrcs(system)
    if nrcs:
        lines.append(r"\subsection{NRC Coverage}")
        lines.append(r"\begin{longtable}{lp{6cm}" + "c" * n + "}")
        lines.append(r"\toprule")
        head = r"\textbf{NRC} & \textbf{Description}"
        for nm in ecu_names:
            head += " & \\textbf{" + _tex_escape(nm) + "}"
        head += r" \\"
        lines.append(head)
        lines.append(r"\midrule")
        for code, name in nrcs.items():
            row = f"\\texttt{{0x{code:02X}}} & {_tex_escape(name)}"
            for nm in ecu_names:
                spec = system.ecus[nm].spec
                row += " & " + ("$\\bullet$" if spec and _has_nrc(spec, code) else "---")
            row += r" \\"
            lines.append(row)
        lines.append(r"\bottomrule")
        lines.append(r"\end{longtable}")

    # ---- §6 Cross-ECU Validation -----------------------------------------
    if validate:
        result = validate_system(system)
        lines.append(r"\section{Cross-ECU Validation}")
        lines.append(r"\textbf{Result:} " + _tex_escape(result.summary()) + r"\\")
        if result.issues:
            lines.append(r"\begin{longtable}{llp{3cm}p{6cm}}")
            lines.append(r"\toprule")
            lines.append(r"\textbf{Severity} & \textbf{Category} & "
                         r"\textbf{Item} & \textbf{Message} \\")
            lines.append(r"\midrule")
            for issue in result.issues:
                lines.append(
                    f"\\texttt{{{issue.severity}}} & {_tex_escape(issue.category)} & "
                    f"{_tex_escape(issue.item_id or '—')} & "
                    f"{_tex_escape(issue.message)} \\\\"
                )
            lines.append(r"\bottomrule")
            lines.append(r"\end{longtable}")
        else:
            lines.append(r"No cross-ECU consistency issues detected.")

    # ---- Annex: Change History (mirrors single-ECU change history) -------
    lines.append(r"\section*{Change History}")
    lines.append(r"\addcontentsline{toc}{section}{Change History}")
    lines.append(r"\begin{table}[H]")
    lines.append(r"\centering")
    lines.append(r"\begin{tabular}{|m{1cm}|m{2cm}|m{2cm}|m{8cm}|}")
    lines.append(r"\hline")
    lines.append(r"\rowcolor{gray!20}")
    lines.append(r"\textbf{Ver.} & \textbf{Date} & \textbf{Pages} & \textbf{Description} \\ \hline")
    lines.append(r"1.0 & \today & All & Initial version (generated from system YAML) \\ \hline")
    lines.append(r"\end{tabular}")
    lines.append(r"\end{table}")

    lines.append(r"\end{document}")
    return "\n".join(lines)


# ----------------------------------------------------------------------------
# HTML
# ----------------------------------------------------------------------------

def _html_escape(s: str) -> str:
    return (
        s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
         .replace('"', "&quot;").replace("'", "&#39;")
    )


_HTML_CSS = """
* { box-sizing: border-box; }
body { font-family: Georgia, "Times New Roman", serif; font-size: 14px;
       line-height: 1.6; color: #111; max-width: 1100px;
       margin: 0 auto; padding: 2.5em 3em; background: #fff; }
h1 { font-size: 1.9em; border-bottom: 2px solid #111; padding-bottom: 0.25em; }
h2 { font-size: 1.3em; border-bottom: 1px solid #999; padding-bottom: 0.15em;
     margin-top: 2em; }
h3 { font-size: 1.05em; margin-top: 1.4em; }
table { border-collapse: collapse; margin: 0.8em 0 1.4em; font-size: 0.9em;
        font-family: Arial, Helvetica, sans-serif; }
th { background: #ebebea; color: #111; padding: 6px 10px;
     border: 1px solid #999; text-align: left; }
td { padding: 5px 10px; border: 1px solid #bbb; vertical-align: top; }
tr:nth-child(even) td { background: #f7f7f7; }
code { font-family: "Courier New", Courier, monospace; }
.role-gateway { color: #334466; font-weight: bold; }
.role-endpoint { color: #2A6E2A; font-weight: bold; }
.role-peer { color: #996600; font-weight: bold; }
.tick { color: #2A6E2A; font-weight: bold; }
.miss { color: #aaa; }
.severity-error { color: #aa2222; font-weight: bold; }
.severity-warning { color: #996600; font-weight: bold; }
.severity-info { color: #334466; }
.inferred { font-style: italic; color: #888; }
"""


def generate_system_html(system: EcuSystem, *, validate: bool = True) -> str:
    """Standalone HTML page for the system integration document."""
    from udsxml2tex.multi_ecu.visualizations import generate_topology_html

    parts: list[str] = []
    parts.append("<!DOCTYPE html><html lang='en'><head>")
    parts.append("<meta charset='UTF-8'>")
    parts.append(f"<title>System Integration: {_html_escape(system.name)}</title>")
    parts.append(f"<style>{_HTML_CSS}</style>")
    parts.append("</head><body>")
    parts.append(f"<h1>System Integration Document &mdash; {_html_escape(system.name)}</h1>")
    if system.description:
        parts.append(f"<p>{_html_escape(system.description)}</p>")

    parts.append("<h2>ECU Roster</h2>")
    parts.append("<table><thead><tr><th>Name</th><th>Role</th><th>ARXML</th>"
                 "<th>DEM</th><th>Description</th></tr></thead><tbody>")
    for ecu in system.ecus.values():
        arxml = ", ".join(p.name for p in ecu.arxml_files) or "—"
        dem = ecu.dem_arxml.name if ecu.dem_arxml else "—"
        parts.append(
            f"<tr><td><strong>{_html_escape(ecu.name)}</strong></td>"
            f"<td><span class='role-{ecu.role.value}'>{ecu.role.value}</span></td>"
            f"<td>{_html_escape(arxml)}</td>"
            f"<td>{_html_escape(dem)}</td>"
            f"<td>{_html_escape(ecu.description or '')}</td></tr>"
        )
    parts.append("</tbody></table>")

    parts.append("<h2>System Topology</h2>")
    parts.append(generate_topology_html(system))

    if system.topology.connections:
        parts.append("<h3>Physical Connections</h3>")
        parts.append("<table><thead><tr><th>From</th><th>To</th><th>Medium</th>"
                     "<th>Description</th></tr></thead><tbody>")
        for c in system.topology.connections:
            parts.append(
                f"<tr><td>{_html_escape(c.from_ecu)}</td>"
                f"<td>{_html_escape(c.to_ecu)}</td>"
                f"<td>{_html_escape(c.medium)}</td>"
                f"<td>{_html_escape(c.description or '')}</td></tr>"
            )
        parts.append("</tbody></table>")

    if system.routing_rules:
        parts.append("<h2>Routing Matrix</h2>")
        parts.append("<p>Diagnostic requests received by the source ECU that match "
                     "the criteria below are forwarded to the target. Rules in "
                     "italic are inferred from ARXML coverage gaps and should be "
                     "reviewed.</p>")
        parts.append("<table><thead><tr><th>#</th><th>From</th><th>To</th>"
                     "<th>Match</th><th>Via</th><th>Origin</th>"
                     "<th>Description</th></tr></thead><tbody>")
        for i, r in enumerate(system.routing_rules, start=1):
            origin = "inferred" if r.inferred else "explicit"
            klass = ' class="inferred"' if r.inferred else ""
            parts.append(
                f"<tr{klass}><td>{i}</td>"
                f"<td>{_html_escape(r.from_ecu)}</td>"
                f"<td>{_html_escape(r.to_ecu)}</td>"
                f"<td>{_html_escape(r.match.description())}</td>"
                f"<td>{_html_escape(r.via or '—')}</td>"
                f"<td><code>{origin}</code></td>"
                f"<td>{_html_escape(r.description or '')}</td></tr>"
            )
        parts.append("</tbody></table>")

    # Coverage tables
    ecu_names = list(system.ecus.keys())

    def _coverage_table(title: str, ids: Iterable[int], fmt: str, pred) -> None:
        lst = list(ids)
        if not lst:
            return
        parts.append(f"<h3>{title}</h3>")
        parts.append("<table><thead><tr><th>ID</th>" +
                     "".join(f"<th>{_html_escape(n)}</th>" for n in ecu_names) +
                     "</tr></thead><tbody>")
        for x in lst:
            row = f"<tr><td><code>{fmt.format(x)}</code></td>"
            for n in ecu_names:
                spec = system.ecus[n].spec
                row += ("<td class='tick'>&#x2713;</td>"
                        if spec and pred(spec, x)
                        else "<td class='miss'>&mdash;</td>")
            row += "</tr>"
            parts.append(row)
        parts.append("</tbody></table>")

    parts.append("<h2>Cross-ECU Coverage</h2>")
    _coverage_table("SID Coverage", _all_sids(system), "0x{:02X}", _has_sid)
    _coverage_table("DID Coverage", _all_dids(system), "0x{:04X}", _has_did)
    _coverage_table("RID Coverage", _all_rids(system), "0x{:04X}", _has_rid)

    nrcs = _all_nrcs(system)
    if nrcs:
        parts.append("<h3>NRC Coverage</h3>")
        parts.append("<table><thead><tr><th>NRC</th><th>Description</th>" +
                     "".join(f"<th>{_html_escape(n)}</th>" for n in ecu_names) +
                     "</tr></thead><tbody>")
        for code, name in nrcs.items():
            row = (f"<tr><td><code>0x{code:02X}</code></td>"
                   f"<td>{_html_escape(name)}</td>")
            for n in ecu_names:
                spec = system.ecus[n].spec
                row += ("<td class='tick'>&#x2713;</td>"
                        if spec and _has_nrc(spec, code)
                        else "<td class='miss'>&mdash;</td>")
            row += "</tr>"
            parts.append(row)
        parts.append("</tbody></table>")

    if validate:
        result = validate_system(system)
        parts.append("<h2>Cross-ECU Validation</h2>")
        parts.append(f"<p><strong>Result:</strong> {_html_escape(result.summary())}</p>")
        if result.issues:
            parts.append("<table><thead><tr><th>Severity</th><th>Category</th>"
                         "<th>Item</th><th>Message</th></tr></thead><tbody>")
            for issue in result.issues:
                parts.append(
                    f"<tr><td class='severity-{issue.severity}'>{issue.severity}</td>"
                    f"<td>{_html_escape(issue.category)}</td>"
                    f"<td>{_html_escape(issue.item_id or '—')}</td>"
                    f"<td>{_html_escape(issue.message)}</td></tr>"
                )
            parts.append("</tbody></table>")
        else:
            parts.append("<p>&#x2713; No cross-ECU consistency issues detected.</p>")

    parts.append("</body></html>")
    return "\n".join(parts)


# ----------------------------------------------------------------------------
# Unified multi-ECU HTML / TeX (Option B: per-section ECU interleaving)
# ----------------------------------------------------------------------------
#
# These build ONE document that covers the whole system, reusing the
# single-ECU renderers but invoking them once per ECU per section so each
# section page contains all ECUs side-by-side. The intent is "one UDS
# specification for the system" rather than separate per-ECU specs.

def generate_system_html_zip(
    system: EcuSystem,
    output_path: "str | Path",
    *,
    validate: bool = True,
) -> "Path":
    """Build a single browsable multi-page HTML site covering the whole system.

    Page structure mirrors the single-ECU site, but each per-section page
    contains a sub-section per ECU (in YAML/insertion order):

        index.html                       — system overview, roster, topology,
                                           routing matrix, cross-ECU coverage
        sections/0_intro/index.html      — system intro + per-ECU intro blocks
        sections/1_low_layer/{2_datalink,3_network,4_transport,5_session}/
                                         — per-section pages, each ECU under
                                           its own H2
        sections/2_high_layer/index.html — system-wide cross-ECU SID matrices
        sections/2_high_layer/sid{XX}/   — one page per service (union across
                                           ECUs); each ECU that supports the
                                           SID gets its own H2 sub-section
        sections/A_annex/index.html      — annex (per-ECU)

    Returns the path to the written ZIP.
    """
    from pathlib import Path
    import tempfile, zipfile, logging

    from udsxml2tex.generator import (
        TexGenerator,
        _HTML_CSS,
        _build_nav_html,
        _html_escape,
        _html_page,
        _relpath,
        _render_html_intro,
        _render_html_low_datalink,
        _render_html_low_layer_index,
        _render_html_low_network,
        _render_html_low_session,
        _render_html_low_transport,
        _render_html_high_overview,
        _render_html_service_page,
        _render_html_annex,
    )
    from udsxml2tex.multi_ecu.visualizations import generate_topology_html

    logger = logging.getLogger(__name__)
    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)

    # Per-ECU context (only ECUs whose ARXML actually parsed)
    tex_gen = TexGenerator()
    ecu_items: list[tuple[str, Any, dict]] = []  # (name, spec, ctx)
    for name, ecu in system.ecus.items():
        if not ecu.spec:
            continue
        ecu_items.append((name, ecu.spec, tex_gen._build_context(ecu.spec)))

    if not ecu_items:
        raise ValueError(f"System {system.name!r} has no parsed ECU specs")

    # Union of services across ECUs, keyed by service_id, preserving order
    # of first appearance. Each entry remembers which ECUs supply the service.
    all_services: dict[int, dict] = {}
    for name, spec, _ctx in ecu_items:
        for svc in spec.services or []:
            slot = all_services.setdefault(svc.service_id, {
                "service_id": svc.service_id,
                "service_id_hex": svc.service_id_hex,
                "short_name": svc.short_name,
                "ecus": [],  # list[(ecu_name, svc, ctx)]
            })
            # `ctx` is per-ECU so per-service rendering still has full context
            slot["ecus"].append((name, svc, _ctx))

    # Service nav children — alphabetised by hex SID
    svc_children = []
    for sid in sorted(all_services):
        slot = all_services[sid]
        sid_clean = slot["service_id_hex"].replace("0x", "").lower()
        svc_children.append({
            "path": f"sections/2_high_layer/sid{sid_clean}/index.html",
            "title": slot["short_name"],
            "children": [],
        })

    nav_tree = [
        {"path": "index.html", "title": "System Overview", "children": []},
        {"path": "sections/0_intro/index.html", "title": "Introduction", "children": []},
        {"path": "sections/1_low_layer/index.html", "title": "Network Protocol Layers",
         "children": [
             {"path": "sections/1_low_layer/2_datalink/index.html",  "title": "Data Link",  "children": []},
             {"path": "sections/1_low_layer/3_network/index.html",   "title": "Network",    "children": []},
             {"path": "sections/1_low_layer/4_transport/index.html", "title": "Transport",  "children": []},
             {"path": "sections/1_low_layer/5_session/index.html",   "title": "Session",    "children": []},
         ]},
        {"path": "sections/2_high_layer/index.html", "title": "Application Layers",
         "children": svc_children},
        {"path": "sections/A_annex/index.html", "title": "Annex", "children": []},
    ]

    # ---- Page renderers ----------------------------------------------------

    def _ecu_section_header(ecu_name: str) -> str:
        return f'<h2 style="background:#eef; padding:0.3em 0.6em;">ECU: {_html_escape(ecu_name)}</h2>'

    def _wrap_per_ecu(renderer, current_path: str) -> str:
        """Render `renderer(ctx)` once per ECU and concatenate, each prefixed
        with an ECU section header. The first H1 from each ECU body is
        demoted to H3 so the per-ECU H2 remains the second-level heading."""
        chunks: list[str] = []
        for name, _spec, ctx in ecu_items:
            page_ctx = {**ctx, "_current_path": current_path}
            body = renderer(page_ctx)
            # Demote the body's <h1> to <h3> so the per-ECU H2 is the dominant
            # heading on the combined page.
            body = body.replace("<h1>", "<h3>", 1).replace("</h1>", "</h3>", 1)
            chunks.append(_ecu_section_header(name) + "\n" + body)
        return "\n<hr>\n".join(chunks)

    def render_index(_ctx: dict) -> str:
        out: list[str] = []
        out.append(f"<h1>UDS Specification &mdash; {_html_escape(system.name or 'System')}</h1>")
        if system.description:
            out.append(f'<p class="meta">{_html_escape(system.description)}</p>')
        out.append("<p>This document is a single, unified UDS specification covering "
                   "all ECUs in the system. Each section below interleaves the "
                   "configuration of every ECU side by side.</p>")

        # ECU roster
        out.append("<h2>ECU Roster</h2>")
        out.append("<table><thead><tr><th>Name</th><th>Role</th>"
                   "<th>ARXML</th><th>DEM</th><th>Description</th>"
                   "</tr></thead><tbody>")
        for ecu in system.ecus.values():
            arxml = ", ".join(p.name for p in ecu.arxml_files) or "&mdash;"
            dem = ecu.dem_arxml.name if ecu.dem_arxml else "&mdash;"
            role = ecu.role.value if hasattr(ecu.role, "value") else str(ecu.role)
            out.append(
                f"<tr><td><strong>{_html_escape(ecu.name)}</strong></td>"
                f"<td>{_html_escape(role)}</td>"
                f"<td>{_html_escape(arxml)}</td>"
                f"<td>{_html_escape(dem)}</td>"
                f"<td>{_html_escape(ecu.description or '')}</td></tr>"
            )
        out.append("</tbody></table>")

        # Topology
        out.append("<h2>System Topology</h2>")
        out.append(generate_topology_html(system))

        # Routing matrix
        if system.routing_rules:
            out.append("<h2>Routing Matrix</h2>")
            out.append("<table><thead><tr><th>#</th><th>From</th><th>To</th>"
                       "<th>Match</th><th>Via</th><th>Origin</th>"
                       "<th>Description</th></tr></thead><tbody>")
            for i, r in enumerate(system.routing_rules, start=1):
                origin = "inferred" if r.inferred else "explicit"
                out.append(
                    f"<tr><td>{i}</td>"
                    f"<td>{_html_escape(r.from_ecu)}</td>"
                    f"<td>{_html_escape(r.to_ecu)}</td>"
                    f"<td>{_html_escape(r.match.description())}</td>"
                    f"<td>{_html_escape(r.via or '—')}</td>"
                    f"<td><code>{origin}</code></td>"
                    f"<td>{_html_escape(r.description or '')}</td></tr>"
                )
            out.append("</tbody></table>")

        # Cross-ECU coverage tables
        ecu_names = [n for n, *_ in ecu_items]

        def _coverage(title: str, ids, fmt, pred):
            lst = list(ids)
            if not lst:
                return
            out.append(f"<h3>{title}</h3>")
            out.append("<table><thead><tr><th>ID</th>"
                       + "".join(f"<th>{_html_escape(n)}</th>" for n in ecu_names)
                       + "</tr></thead><tbody>")
            for x in lst:
                row = f"<tr><td><code>{fmt.format(x)}</code></td>"
                for n in ecu_names:
                    spec = system.ecus[n].spec
                    row += ('<td style="text-align:center;color:#2A6E2A;">&#x2713;</td>'
                            if spec and pred(spec, x)
                            else '<td style="text-align:center;color:#999;">&mdash;</td>')
                row += "</tr>"
                out.append(row)
            out.append("</tbody></table>")

        out.append("<h2>Cross-ECU Coverage</h2>")
        _coverage("SID Coverage", _all_sids(system), "0x{:02X}", _has_sid)
        _coverage("DID Coverage", _all_dids(system), "0x{:04X}", _has_did)
        _coverage("RID Coverage", _all_rids(system), "0x{:04X}", _has_rid)

        nrcs = _all_nrcs(system)
        if nrcs:
            out.append("<h3>NRC Coverage</h3>")
            out.append("<table><thead><tr><th>NRC</th><th>Description</th>"
                       + "".join(f"<th>{_html_escape(n)}</th>" for n in ecu_names)
                       + "</tr></thead><tbody>")
            for code, name in nrcs.items():
                row = (f"<tr><td><code>0x{code:02X}</code></td>"
                       f"<td>{_html_escape(name)}</td>")
                for n in ecu_names:
                    spec = system.ecus[n].spec
                    row += ('<td style="text-align:center;color:#2A6E2A;">&#x2713;</td>'
                            if spec and _has_nrc(spec, code)
                            else '<td style="text-align:center;color:#999;">&mdash;</td>')
                row += "</tr>"
                out.append(row)
            out.append("</tbody></table>")

        if validate:
            result = validate_system(system)
            out.append("<h2>Cross-ECU Validation</h2>")
            out.append(f"<p><strong>Result:</strong> {_html_escape(result.summary())}</p>")
            if result.issues:
                out.append("<table><thead><tr><th>Severity</th><th>Category</th>"
                           "<th>Item</th><th>Message</th></tr></thead><tbody>")
                for issue in result.issues:
                    out.append(
                        f"<tr><td>{issue.severity}</td>"
                        f"<td>{_html_escape(issue.category)}</td>"
                        f"<td>{_html_escape(issue.item_id or '—')}</td>"
                        f"<td>{_html_escape(issue.message)}</td></tr>"
                    )
                out.append("</tbody></table>")
            else:
                out.append("<p>&#x2713; No cross-ECU consistency issues detected.</p>")
        return "\n".join(out)

    def render_high_overview(_ctx: dict) -> str:
        # Reuse single-ECU high-overview per ECU + a combined service index up top
        out: list[str] = []
        out.append("<h1>Application Layers</h1>")
        out.append("<p>System-wide application-layer overview. Per-ECU details "
                   "for each service are on the linked sub-pages below.</p>")
        out.append("<h2>Service Index (union across all ECUs)</h2><ul>")
        cur = "sections/2_high_layer/index.html"
        for sid in sorted(all_services):
            slot = all_services[sid]
            sid_clean = slot["service_id_hex"].replace("0x", "").lower()
            href = _relpath(cur, f"sections/2_high_layer/sid{sid_clean}/index.html")
            covered = ", ".join(_html_escape(n) for n, _, _ in slot["ecus"])
            out.append(
                f'<li><a href="{href}">{_html_escape(slot["short_name"])} '
                f'(<code>{slot["service_id_hex"]}</code>)</a> '
                f'<span style="color:#666;">[{covered}]</span></li>'
            )
        out.append("</ul>")
        out.append(_wrap_per_ecu(_render_html_high_overview, cur))
        return "\n".join(out)

    def render_service_page(slot: dict, current_path: str) -> str:
        out: list[str] = []
        out.append(
            f'<h1>{_html_escape(slot["short_name"])} '
            f'(<code>{slot["service_id_hex"]}</code>) service</h1>'
        )
        out.append(f"<p>Configuration of this service across "
                   f"{len(slot['ecus'])} ECU(s) in the system.</p>")
        for ecu_name, svc, ctx in slot["ecus"]:
            page_ctx = {**ctx, "_current_path": current_path}
            body = _render_html_service_page(page_ctx, svc, 0)
            # Demote body's H1 to H3; the H2 is the per-ECU header
            body = body.replace("<h1>", "<h3>", 1).replace("</h1>", "</h3>", 1)
            out.append(_ecu_section_header(ecu_name))
            out.append(body)
            out.append("<hr>")
        return "\n".join(out)

    # ---- Page list ---------------------------------------------------------

    pages: list[tuple[str, str, object]] = [
        ("index.html",                                 "System Overview",         render_index),
        ("sections/0_intro/index.html",                "Introduction",
         lambda c: _wrap_per_ecu(_render_html_intro, "sections/0_intro/index.html")),
        ("sections/1_low_layer/index.html",            "Network Protocol Layers",
         lambda c: _wrap_per_ecu(_render_html_low_layer_index, "sections/1_low_layer/index.html")),
        ("sections/1_low_layer/2_datalink/index.html", "Data Link Layer",
         lambda c: _wrap_per_ecu(_render_html_low_datalink, "sections/1_low_layer/2_datalink/index.html")),
        ("sections/1_low_layer/3_network/index.html",  "Network Layer",
         lambda c: _wrap_per_ecu(_render_html_low_network, "sections/1_low_layer/3_network/index.html")),
        ("sections/1_low_layer/4_transport/index.html","Transport Layer",
         lambda c: _wrap_per_ecu(_render_html_low_transport, "sections/1_low_layer/4_transport/index.html")),
        ("sections/1_low_layer/5_session/index.html",  "Session Layer",
         lambda c: _wrap_per_ecu(_render_html_low_session, "sections/1_low_layer/5_session/index.html")),
        ("sections/2_high_layer/index.html",           "Application Layers", render_high_overview),
    ]
    for sid in sorted(all_services):
        slot = all_services[sid]
        sid_clean = slot["service_id_hex"].replace("0x", "").lower()
        path = f"sections/2_high_layer/sid{sid_clean}/index.html"
        title = slot["short_name"]
        pages.append((path, title, lambda c, s=slot, p=path: render_service_page(s, p)))
    pages.append(("sections/A_annex/index.html", "Annex",
                  lambda c: _wrap_per_ecu(_render_html_annex, "sections/A_annex/index.html")))

    # ---- Materialise the zip ----------------------------------------------

    with tempfile.TemporaryDirectory() as tmpdir:
        tmp = Path(tmpdir)

        # Bundle mermaid for offline diagrams
        assets_dir = tmp / "assets"
        assets_dir.mkdir(parents=True, exist_ok=True)
        try:
            from importlib.resources import files as _ir_files
            mermaid_src = _ir_files("udsxml2tex").joinpath(
                "templates", "assets", "mermaid.min.js"
            )
            (assets_dir / "mermaid.min.js").write_bytes(mermaid_src.read_bytes())
            _has_mermaid = True
        except Exception as exc:  # noqa: BLE001
            logger.warning("mermaid.min.js not bundled: %s", exc)
            _has_mermaid = False

        for page_path, title, renderer in pages:
            nav_html = _build_nav_html(nav_tree, page_path)
            body = renderer({})
            mermaid_rel = (
                _relpath(page_path, "assets/mermaid.min.js")
                if _has_mermaid else None
            )
            page_html = _html_page(
                title, nav_html, body, _HTML_CSS,
                mermaid_rel_path=mermaid_rel,
            )
            out_file = tmp / Path(page_path)
            out_file.parent.mkdir(parents=True, exist_ok=True)
            out_file.write_text(page_html, encoding="utf-8")

        with zipfile.ZipFile(output_path, "w", zipfile.ZIP_DEFLATED) as zf:
            for f in sorted(tmp.rglob("*")):
                if f.is_file():
                    zf.write(f, f.relative_to(tmp))

    logger.info("Generated unified system HTML ZIP: %s", output_path)
    return output_path


# ----------------------------------------------------------------------------
# Unified multi-ECU structured LaTeX (Option B: per-section ECU interleaving)
# ----------------------------------------------------------------------------
#
# Strategy:
#   1. Render each ECU's full structured LaTeX project under
#      tmp/ecus/<ecu_name>/ via the existing TexGenerator.
#   2. Demote every heading level (\section -> \subsection, etc.) and
#      rewrite \input{sections/...} -> \input{ecus/<name>/sections/...}
#      in those per-ECU files, so each ECU's body becomes a single coherent
#      sub-tree that fits *under* a top-level \section we emit ourselves.
#   3. Build one unified root.tex with the system title page, a system
#      overview chapter, and then a single \section{...} per top-level
#      chapter (Introduction, Network Protocol Layers, Application Layers,
#      Annex). Each top-level \section interleaves an
#      \subsection{ECU: <name>} per ECU, followed by \input lines pointing
#      at the (demoted) per-ECU section files.
#   4. Bundle udsspec.cls, tikz-uml.sty, and a placeholder reference.bib so
#      the whole project compiles standalone with xelatex+biber.

_HEADING_DEMOTE: list[tuple[str, str]] = [
    # Order matters: longest first so we don't accidentally double-demote.
    (r"\subparagraph*", r"\subparagraph*"),  # already deepest; leave as-is
    (r"\paragraph*",    r"\subparagraph*"),
    (r"\subsubsection*", r"\paragraph*"),
    (r"\subsection*",    r"\subsubsection*"),
    (r"\section*",       r"\subsection*"),
    (r"\paragraph",     r"\subparagraph"),
    (r"\subsubsection", r"\paragraph"),
    (r"\subsection",    r"\subsubsection"),
    (r"\section",       r"\subsection"),
]


def _demote_tex_headings(text: str) -> str:
    """Lower every LaTeX heading by one level.

    \\section{X}        -> \\subsection{X}
    \\subsection{X}     -> \\subsubsection{X}
    \\subsubsection{X}  -> \\paragraph{X}
    \\paragraph{X}      -> \\subparagraph{X}
    Starred forms handled symmetrically. Anything deeper (\\subparagraph)
    is left unchanged because there's no further built-in level.
    """
    # Work on tokens with explicit boundary so e.g. \\sectionizer is not
    # rewritten. We use a simple two-pass placeholder swap.
    placeholders: list[tuple[str, str]] = []
    out = text
    for i, (src, _dst) in enumerate(_HEADING_DEMOTE):
        token = f"\x00DEMOTE_{i}\x00"
        placeholders.append((token, _HEADING_DEMOTE[i][1]))
        # Match macro followed by '{' or '*' or whitespace (not a letter).
        # Use a simple regex.
        import re
        out = re.sub(re.escape(src) + r"(?=[\s\{\[\*])", token, out)
    for token, dst in placeholders:
        out = out.replace(token, dst)
    return out


def _rewrite_input_paths(text: str, ecu_subdir: str) -> str:
    """Rewrite \\input{sections/...} -> \\input{ecus/<name>/sections/...}.

    Also rewrites \\includegraphics paths that start with 'sections/' or
    bare 'figs/' so any per-ECU graphics resolve from the unified root."""
    import re
    # \input{sections/foo} -> \input{ecus/<name>/sections/foo}
    text = re.sub(
        r"\\input\{sections/",
        r"\\input{ecus/" + ecu_subdir + r"/sections/",
        text,
    )
    text = re.sub(
        r"\\includegraphics(\[[^\]]*\])?\{sections/",
        lambda m: r"\includegraphics" + (m.group(1) or "") +
                  r"{ecus/" + ecu_subdir + r"/sections/",
        text,
    )
    return text


def _ecu_high_layer_sids(ecu_spec: Any) -> list[int]:
    return sorted({s.service_id for s in (ecu_spec.services or [])})


# Map service_id -> structured_tex sub-directory name (matches per-ECU
# template layout under sections/2_high_layer/).
_SID_DIR_MAP: dict[int, str] = {
    0x10: "10-2_sid10",
    0x11: "10-3_sid11",
    0x27: "10-4_sid27",
    0x28: "10-5_sid28",
    0x29: "10-6_sid29",
    0x3E: "10-7_sid3E",
    0x85: "10-8_sid85",
    0x22: "11-2_sid22",
    0x2E: "11-7_sid2E",
    0x14: "12-2_sid14",
    0x19: "12-3_sid19",
    0x31: "14-2_sid31",
    0x34: "15-2_sid34",
    0x36: "15-4_sid36",
    0x37: "15-5_sid37",
}


def generate_system_structured_tex_zip(
    system: EcuSystem,
    output_path: "str | Path",
    *,
    cls_content: "bytes | None" = None,
    validate: bool = True,
) -> "Path":
    """Build ONE structured LaTeX project covering the whole multi-ECU system.

    The output ZIP layout:

        root.tex                     — unified system root (title, TOC,
                                       overview, interleaved chapters)
        sections/section.tex         — system overview only (topology,
                                       roster, routing, coverage, validation)
        ecus/<name>/sections/...     — per-ECU section trees, with all
                                       headings demoted by one level so they
                                       sit under our \\subsection{ECU: name}
        custom.cls / udsspec.cls     — class file (user-supplied or bundled)
        tikz-uml.sty                 — bundled TikZ-UML
        reference.bib                — bibliography placeholder

    Returns the path to the written ZIP.
    """
    from pathlib import Path
    import logging
    import shutil
    import tempfile
    import zipfile

    from udsxml2tex.generator import TexGenerator
    from udsxml2tex.multi_ecu.visualizations import generate_topology_tikz

    logger = logging.getLogger(__name__)
    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)

    ecu_items: list[tuple[str, Any]] = [
        (name, ecu.spec)
        for name, ecu in system.ecus.items()
        if ecu.spec
    ]
    if not ecu_items:
        raise ValueError(f"System {system.name!r} has no parsed ECU specs")

    tex_gen = TexGenerator()

    with tempfile.TemporaryDirectory() as tmpdir:
        tmp = Path(tmpdir)

        # ---- Render & post-process per-ECU structured TeX ----------------
        for name, spec in ecu_items:
            per_ecu_zip = tmp / f"_{name}_structured.zip"
            tex_gen.generate_structured_tex_zip(spec, per_ecu_zip)
            ecu_dir = tmp / "ecus" / name
            ecu_dir.mkdir(parents=True, exist_ok=True)
            with zipfile.ZipFile(per_ecu_zip) as zf:
                zf.extractall(ecu_dir)
            per_ecu_zip.unlink(missing_ok=True)

            # Drop per-ECU root.tex / tikz-uml.sty / custom.cls — the
            # system root and shared assets at the zip root replace them.
            for fname in ("root.tex", "tikz-uml.sty", "custom.cls"):
                (ecu_dir / fname).unlink(missing_ok=True)

            # Demote headings + rewrite \input paths in every .tex file
            # under ecus/<name>/sections/.
            sec_root = ecu_dir / "sections"
            if sec_root.exists():
                for tex_file in sec_root.rglob("*.tex"):
                    src = tex_file.read_text(encoding="utf-8")
                    out = _demote_tex_headings(src)
                    out = _rewrite_input_paths(out, name)
                    tex_file.write_text(out, encoding="utf-8")

        # ---- Shared assets at zip root -----------------------------------
        from importlib.resources import files as _ir_files
        templates_pkg = _ir_files("udsxml2tex.templates")

        # tikz-uml.sty
        try:
            (tmp / "tikz-uml.sty").write_bytes(
                templates_pkg.joinpath("tikz-uml.sty").read_bytes()
            )
        except Exception as exc:  # noqa: BLE001
            logger.warning("tikz-uml.sty not bundled: %s", exc)

        # udsspec.cls (user-supplied custom.cls overrides bundled default)
        if cls_content is not None:
            (tmp / "custom.cls").write_bytes(cls_content)
            (tmp / "udsspec.cls").write_bytes(cls_content)
        else:
            try:
                (tmp / "udsspec.cls").write_bytes(
                    templates_pkg.joinpath("udsspec.cls").read_bytes()
                )
            except Exception as exc:  # noqa: BLE001
                logger.warning("udsspec.cls not bundled: %s", exc)

        # Empty bibliography (root.tex.j2 \addbibresource{reference.bib})
        (tmp / "reference.bib").write_text(
            "% Auto-generated placeholder; add citations here.\n",
            encoding="utf-8",
        )

        # ---- System overview section -------------------------------------
        # Mirrors generate_system_latex content but stripped of the
        # standalone preamble — to be \input from the unified root.
        overview_lines: list[str] = []
        overview_lines.append(r"\section{System Overview}")
        if system.description:
            overview_lines.append(_tex_escape(system.description))
            overview_lines.append("")
        n_ecus = len(system.ecus)
        overview_lines.append(r"\subsection{System at a Glance}")
        overview_lines.append(r"\begin{itemize}")
        overview_lines.append(
            r"\item System name: \texttt{"
            + _tex_escape(system.name or "—") + r"}"
        )
        overview_lines.append(
            r"\item Number of ECUs: \texttt{" + str(n_ecus) + r"}"
        )
        overview_lines.append(
            r"\item Routing rules: \texttt{"
            + str(len(system.routing_rules)) + r"} ("
            + str(sum(1 for r in system.routing_rules if r.inferred))
            + r" inferred)"
        )
        overview_lines.append(
            r"\item Physical connections: \texttt{"
            + str(len(system.topology.connections)) + r"}"
        )
        overview_lines.append(r"\end{itemize}")

        # ECU roster
        overview_lines.append(r"\subsection{ECU Roster}")
        overview_lines.append(r"\begin{table}[H]\centering")
        overview_lines.append(r"\begin{tabular}{|l|l|l|p{6cm}|}\hline")
        overview_lines.append(
            r"\rowcolor{gray!20}\textbf{Name} & \textbf{Role} & "
            r"\textbf{ARXML} & \textbf{Description} \\ \hline"
        )
        for ecu in system.ecus.values():
            arxml = _tex_escape(", ".join(p.name for p in ecu.arxml_files) or "—")
            desc = _tex_escape(ecu.description or "")
            role = ecu.role.value if hasattr(ecu.role, "value") else str(ecu.role)
            overview_lines.append(
                f"\\textbf{{{_tex_escape(ecu.name)}}} & "
                f"\\texttt{{{_tex_escape(role)}}} & {arxml} & {desc} \\\\ \\hline"
            )
        overview_lines.append(r"\end{tabular}\end{table}")

        # Topology figure
        overview_lines.append(r"\subsection{System Topology}")
        topo_full = generate_topology_tikz(system)
        start = topo_full.find(r"\begin{tikzpicture}")
        end = topo_full.find(r"\end{tikzpicture}") + len(r"\end{tikzpicture}")
        if start >= 0 and end > start:
            overview_lines.append(r"\begin{figure}[H]\centering")
            overview_lines.append(topo_full[start:end])
            overview_lines.append(
                r"\caption{System topology of "
                + _tex_escape(system.name or "system") + "}"
            )
            overview_lines.append(r"\end{figure}")

        # Routing matrix
        if system.routing_rules:
            overview_lines.append(r"\subsection{Routing Matrix}")
            overview_lines.append(r"\begin{longtable}{|c|l|l|p{4cm}|l|p{3cm}|}\hline")
            overview_lines.append(
                r"\rowcolor{gray!20}\textbf{\#} & \textbf{From} & \textbf{To} & "
                r"\textbf{Match} & \textbf{Origin} & \textbf{Description} \\ \hline"
            )
            for i, r in enumerate(system.routing_rules, start=1):
                origin = "inferred" if r.inferred else "explicit"
                overview_lines.append(
                    f"{i} & {_tex_escape(r.from_ecu)} & {_tex_escape(r.to_ecu)} & "
                    f"{_tex_escape(r.match.description())} & "
                    f"\\texttt{{{origin}}} & {_tex_escape(r.description or '')} \\\\ \\hline"
                )
            overview_lines.append(r"\end{longtable}")

        # Cross-ECU coverage
        ecu_names = [n for n, _ in ecu_items]

        def _coverage_table(title: str, ids: Iterable, fmt: str, pred) -> None:
            lst = list(ids)
            if not lst:
                return
            overview_lines.append(r"\subsection{" + title + "}")
            cols = "|c|" + "c|" * len(ecu_names)
            overview_lines.append(r"\begin{longtable}{" + cols + r"}\hline")
            head = r"\rowcolor{gray!20}\textbf{ID}"
            for n in ecu_names:
                head += " & \\textbf{" + _tex_escape(n) + "}"
            head += r" \\ \hline"
            overview_lines.append(head)
            for x in lst:
                row = f"\\texttt{{{fmt.format(x)}}}"
                for n in ecu_names:
                    spec = system.ecus[n].spec
                    row += " & " + (r"$\checkmark$" if spec and pred(spec, x) else "—")
                overview_lines.append(row + r" \\ \hline")
            overview_lines.append(r"\end{longtable}")

        overview_lines.append(r"\subsection*{Cross-ECU Coverage}")
        _coverage_table("SID Coverage", _all_sids(system), "0x{:02X}", _has_sid)
        _coverage_table("DID Coverage", _all_dids(system), "0x{:04X}", _has_did)
        _coverage_table("RID Coverage", _all_rids(system), "0x{:04X}", _has_rid)

        # Validation
        if validate:
            result = validate_system(system)
            overview_lines.append(r"\subsection{Cross-ECU Validation}")
            overview_lines.append(
                r"\textbf{Result:} " + _tex_escape(result.summary())
            )
            if result.issues:
                overview_lines.append(r"\begin{longtable}{|l|l|l|p{8cm}|}\hline")
                overview_lines.append(
                    r"\rowcolor{gray!20}\textbf{Severity} & \textbf{Category} & "
                    r"\textbf{Item} & \textbf{Message} \\ \hline"
                )
                for issue in result.issues:
                    overview_lines.append(
                        f"{_tex_escape(issue.severity)} & "
                        f"{_tex_escape(issue.category)} & "
                        f"{_tex_escape(issue.item_id or '—')} & "
                        f"{_tex_escape(issue.message)} \\\\ \\hline"
                    )
                overview_lines.append(r"\end{longtable}")
            else:
                overview_lines.append(
                    r"No cross-ECU consistency issues detected."
                )

        # Write the system overview as sections/system_overview.tex
        sys_sec_dir = tmp / "sections"
        sys_sec_dir.mkdir(parents=True, exist_ok=True)
        (sys_sec_dir / "system_overview.tex").write_text(
            "\n".join(overview_lines) + "\n", encoding="utf-8"
        )

        # ---- Per-section interleaved input lists -------------------------
        # Helper: emit one \subsection{ECU: name} block per ECU plus the
        # \input lines for the children of one top-level chapter.
        def _ecu_block(name: str, inputs: list[str]) -> list[str]:
            block = [
                r"",
                r"\subsection{ECU: " + _tex_escape(name) + r"}",
            ]
            for inp in inputs:
                block.append(r"\input{ecus/" + name + r"/sections/" + inp + r"}")
            return block

        # Map per top section -> list of relative section file paths
        # (without .tex extension) that exist for that ECU.
        def _intro_inputs(_spec: Any) -> list[str]:
            return ["0_intro/intro"]

        def _low_layer_inputs(_spec: Any) -> list[str]:
            return [
                "1_low_layer/2_datalink/datalink",
                "1_low_layer/3_network/network",
                "1_low_layer/4_transport/transport",
                "1_low_layer/5_session/session",
            ]

        def _high_layer_inputs(spec: Any) -> list[str]:
            inputs = ["2_high_layer/09_overview/overview"]
            sids = _ecu_high_layer_sids(spec)
            for sid in sids:
                sub = _SID_DIR_MAP.get(sid)
                if sub is None:
                    continue
                # Filename inside that dir matches `sid<hex>`.
                # Map back via the sub-directory name (strip prefix).
                # Examples: "10-2_sid10" -> "sid10"; "10-7_sid3E" -> "sid3E".
                fname = sub.split("_", 1)[1]
                inputs.append(f"2_high_layer/{sub}/{fname}")
            return inputs

        def _annex_inputs(_spec: Any) -> list[str]:
            return ["A_annex/annex"]

        # Build the unified section.tex aggregator
        section_lines: list[str] = []
        section_lines.append(r"\input{sections/system_overview}")
        section_lines.append(r"")
        section_lines.append(r"\newpage")
        section_lines.append(r"\section{Introduction}")
        for name, spec in ecu_items:
            section_lines += _ecu_block(name, _intro_inputs(spec))
        section_lines.append(r"")
        section_lines.append(r"\newpage")
        section_lines.append(r"\section{Network Protocol Layers}")
        for name, spec in ecu_items:
            section_lines += _ecu_block(name, _low_layer_inputs(spec))
        section_lines.append(r"")
        section_lines.append(r"\newpage")
        section_lines.append(r"\section{Application Layers}")
        for name, spec in ecu_items:
            section_lines += _ecu_block(name, _high_layer_inputs(spec))
        # Annex must follow \appendix to renumber chapters as A, B, ...
        section_lines.append(r"")
        section_lines.append(r"\newpage")
        section_lines.append(r"\appendix")
        section_lines.append(r"\section{Annex}")
        for name, spec in ecu_items:
            section_lines += _ecu_block(name, _annex_inputs(spec))

        (sys_sec_dir / "section.tex").write_text(
            "\n".join(section_lines) + "\n", encoding="utf-8"
        )

        # ---- Render the unified root.tex ---------------------------------
        # Reuse the per-ECU root.tex.j2 template so the system PDF inherits
        # the same preamble (xeCJK, fancyhdr title block, biblatex). Pass
        # the system name as ecu_name. Then patch out the per-ECU services
        # context references — none remain in root.tex.j2 today.
        from jinja2 import Environment, FileSystemLoader
        from pathlib import Path as _P
        templates_dir = _P(__file__).parent.parent / "templates" / "structured_tex"
        tex_env = Environment(
            loader=FileSystemLoader(str(templates_dir)),
            block_start_string=r"\BLOCK{",
            block_end_string="}",
            variable_start_string=r"\VAR{",
            variable_end_string="}",
            comment_start_string=r"\#{",
            comment_end_string="}",
            autoescape=False,
            trim_blocks=True,
            lstrip_blocks=True,
            keep_trailing_newline=True,
        )
        from udsxml2tex.generator import _latex_escape
        tex_env.filters["latex_escape"] = _latex_escape
        tex_env.filters["strip_0x"] = lambda s: str(s).replace("0x", "").replace("0X", "")
        tex_env.filters["bitand"] = lambda v, m: bool(int(v) & int(m))
        root_tmpl = tex_env.get_template("root.tex.j2")
        root_text = root_tmpl.render(
            ecu_name=system.name or "System",
            protocol_name="Multi-ECU Integration",
            services=[],
            sessions=[],
            security_levels=[],
            dids=[],
            routines=[],
            nrcs=[],
            ecu_address="",
        )
        (tmp / "root.tex").write_text(root_text, encoding="utf-8")

        # ---- Pack ZIP ----------------------------------------------------
        with zipfile.ZipFile(output_path, "w", zipfile.ZIP_DEFLATED) as zf:
            for f in sorted(tmp.rglob("*")):
                if f.is_file():
                    zf.write(f, f.relative_to(tmp))

    logger.info("Generated unified system structured TeX ZIP: %s", output_path)
    return output_path
