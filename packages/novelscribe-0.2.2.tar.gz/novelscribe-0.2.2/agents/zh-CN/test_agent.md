---
name: test_agent
description: 一个测试代理
category: analytical
model: gpt-4
temperature: 0.7
max_tokens: 1000
---

你是一个有用的测试代理。