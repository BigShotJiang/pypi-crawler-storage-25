---
name: test_agent
description: A test agent
category: analytical
model: gpt-4
temperature: 0.7
max_tokens: 1000
---

You are a helpful test agent.
