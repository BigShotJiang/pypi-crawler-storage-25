"""
Performance CLI Commands for Novel Generation System

This module provides CLI commands for performance monitoring, profiling,
and optimization of the novel generation pipeline.
"""

import json
import sys
from pathlib import Path
from typing import Optional

import click

# Import performance components
sys.path.insert(0, str(Path(__file__).parent))
from core.file_optimizer import get_file_optimizer
from core.llm_optimizer import get_llm_optimizer
from core.parallel_executor import ParallelExecutor, get_parallel_executor
from core.performance_profiler import ProfileType, ProfilingContext, get_profiler


@click.group(name="perf")
def performance_cli():
    """Performance monitoring and optimization commands"""
    pass


@performance_cli.command()
@click.argument("project_name")
@click.option("--workflow", default="autonomous", help="Workflow to profile")
@click.option(
    "--format",
    "output_format",
    type=click.Choice(["text", "json", "csv"]),
    default="text",
    help="Output format",
)
@click.option("--output", "-o", type=click.Path(), help="Output file path")
def profile(project_name: str, workflow: str, output_format: str, output: Optional[str]):
    """Profile a workflow execution"""
    profiler = get_profiler()

    click.echo(f"Profiling workflow '{workflow}' for project '{project_name}'...")

    # Simulate workflow execution with profiling
    with ProfilingContext(profiler, workflow, ProfileType.WORKFLOW):
        # Simulate agent calls
        with ProfilingContext(profiler, "writer_agent", ProfileType.AGENT):
            import time

            time.sleep(0.5)  # Simulate work

        with ProfilingContext(profiler, "continuity_agent", ProfileType.AGENT):
            time.sleep(0.3)

    # Generate report
    report = profiler.get_report()

    # Output report
    if output_format == "text":
        _display_profile_report(report)
    elif output_format == "json":
        data = report.to_dict()
        if output:
            with open(output, "w") as f:
                json.dump(data, f, indent=2)
            click.echo(f"Report saved to {output}")
        else:
            click.echo(json.dumps(data, indent=2))
    elif output_format == "csv":
        if output:
            profiler.export_data(output, format="csv")
            click.echo(f"CSV report saved to {output}")
        else:
            click.echo("Error: CSV format requires --output")


def _display_profile_report(report):
    """Display profile report in text format"""
    click.echo("\n" + "=" * 60)
    click.echo("PERFORMANCE PROFILE REPORT")
    click.echo("=" * 60)
    click.echo(f"\nTotal Duration: {report.total_duration:.2f}s")
    click.echo("\nSummary:")
    for key, value in report.summary.items():
        if isinstance(value, dict):
            click.echo(f"  {key}:")
            for k, v in value.items():
                click.echo(f"    {k}: {v}")
        else:
            click.echo(f"  {key}: {value}")

    if report.bottlenecks:
        click.echo("\nBottlenecks (>5s):")
        for bottleneck in report.bottlenecks:
            click.echo(f"  - {bottleneck}")
    else:
        click.echo("\nNo bottlenecks identified (all operations <5s)")

    click.echo("\n" + "=" * 60)


@performance_cli.command()
@click.argument("project_name")
@click.option("--threshold", default=5.0, help="Threshold in seconds")
@click.option(
    "--type",
    "profile_type",
    type=click.Choice(["agent", "workflow", "llm", "file_io"]),
    help="Filter by type",
)
def bottlenecks(project_name: str, threshold: float, profile_type: Optional[str]):
    """Identify performance bottlenecks"""
    profiler = get_profiler()

    # Convert string to ProfileType
    ptype = None
    if profile_type:
        ptype = ProfileType[profile_type.upper()]

    bottlenecks = profiler.identify_bottlenecks(threshold=threshold, profile_type=ptype)

    if bottlenecks:
        click.echo(f"\nBottlenecks (>{threshold}s):")
        for bottleneck in bottlenecks:
            click.echo(f"  - {bottleneck}")
    else:
        click.echo(f"\nNo bottlenecks found (all operations <{threshold}s)")


@performance_cli.command()
@click.argument("project_name")
def file_stats(project_name: str):
    """Display file I/O statistics"""
    optimizer = get_file_optimizer()
    stats = optimizer.get_stats()
    cache_info = optimizer.get_cache_info()
    write_cache_info = optimizer.get_write_cache_info()

    click.echo("\n" + "=" * 60)
    click.echo("FILE I/O STATISTICS")
    click.echo("=" * 60)

    click.echo("\nI/O Operations:")
    for key, value in stats.to_dict().items():
        click.echo(f"  {key}: {value}")

    click.echo("\nRead Cache:")
    for key, value in cache_info.items():
        if key == "most_accessed" and value:
            click.echo(f"  {key}:")
            for path, count in value:
                click.echo(f"    - {path}: {count} hits")
        else:
            click.echo(f"  {key}: {value}")

    click.echo("\nWrite Cache:")
    for key, value in write_cache_info.items():
        click.echo(f"  {key}: {value}")

    click.echo("\n" + "=" * 60)


@performance_cli.command()
@click.argument("project_name")
def clear_file_cache(project_name: str):
    """Clear file I/O cache"""
    optimizer = get_file_optimizer()
    optimizer.clear_cache()
    optimizer.clear_write_cache()
    click.echo("File cache cleared")


@performance_cli.command()
@click.argument("project_name")
@click.option("--file-size", default="1M", help="File size for benchmark")
def benchmark_io(project_name: str, file_size: str):
    """Benchmark file I/O performance"""
    optimizer = get_file_optimizer()

    # Parse file size
    size_map = {"K": 1024, "M": 1024 * 1024, "G": 1024 * 1024 * 1024}
    multiplier = size_map.get(file_size[-1].upper(), 1)
    size = int(file_size[:-1]) * multiplier

    click.echo(f"Benchmarking I/O with {file_size} file...")

    import tempfile
    import time

    with tempfile.NamedTemporaryFile(mode="w", delete=False) as f:
        test_path = f.name
        test_content = "x" * size

    # Write benchmark
    start = time.time()
    optimizer.write_file(test_path, test_content, immediate=True)
    write_time = time.time() - start

    # Read benchmark
    start = time.time()
    optimizer.read_file(test_path)
    read_time = time.time() - start

    click.echo("\nResults:")
    click.echo(f"  Write: {write_time:.3f}s ({size / write_time / 1024 / 1024:.1f} MB/s)")
    click.echo(f"  Read:  {read_time:.3f}s ({size / read_time / 1024 / 1024:.1f} MB/s)")

    # Cleanup
    import os

    os.unlink(test_path)
    if os.path.exists(test_path + ".gz"):
        os.unlink(test_path + ".gz")


@performance_cli.command()
@click.argument("project_name")
@click.option("--workflow", default="autonomous", help="Workflow to analyze")
def exec_graph(project_name: str, workflow: str):
    """Display execution graph for workflow"""
    # Create sample workflow steps
    workflow_steps = [
        {"agent": "discuss_agent", "dependencies": []},
        {"agent": "genre_agent", "dependencies": []},
        {"agent": "character_agent", "dependencies": ["discuss_agent"]},
        {"agent": "world_agent", "dependencies": ["discuss_agent"]},
        {
            "agent": "outline_agent",
            "dependencies": ["genre_agent", "character_agent", "world_agent"],
        },
    ]

    executor = get_parallel_executor()
    graph = executor.build_graph_from_workflow(workflow_steps)

    click.echo("\n" + "=" * 60)
    click.echo(f"EXECUTION GRAPH: {workflow}")
    click.echo("=" * 60)

    # Validate graph
    is_valid, errors = graph.validate()
    if not is_valid:
        click.echo("\n❌ Graph validation failed:")
        for error in errors:
            click.echo(f"  - {error}")
        return

    click.echo("\n✅ Graph is valid (no cycles)\n")

    # Display nodes
    click.echo("Nodes:")
    for node_id, node in graph.nodes.items():
        deps = ", ".join(node.dependencies) if node.dependencies else "None"
        click.echo(f"  - {node.agent_name} (deps: {deps})")

    # Display execution order
    click.echo("\nExecution Order:")
    order = graph.topological_sort()
    for i, node_id in enumerate(order, 1):
        node = graph.nodes[node_id]
        click.echo(f"  {i}. {node.agent_name}")

    # Get ready nodes
    ready = graph.get_ready_nodes()
    click.echo(f"\nReady for parallel execution: {len(ready)} agents")
    for node in ready:
        click.echo(f"  - {node.agent_name}")

    click.echo("\n" + "=" * 60)


@performance_cli.command()
@click.argument("project_name")
@click.option("--workflow", default="autonomous", help="Workflow to execute")
@click.option("--max-workers", default=4, help="Maximum parallel workers")
def parallel(project_name: str, workflow: str, max_workers: int):
    """Execute workflow in parallel mode"""
    executor = ParallelExecutor(max_workers=max_workers)

    # Create sample workflow
    workflow_steps = [
        {"agent": "discuss_agent", "dependencies": []},
        {"agent": "genre_agent", "dependencies": []},
        {"agent": "character_agent", "dependencies": ["discuss_agent"]},
        {"agent": "world_agent", "dependencies": ["discuss_agent"]},
    ]

    graph = executor.build_graph_from_workflow(workflow_steps)

    # Define mock agent functions
    def mock_agent(name, duration=0.5):
        def agent():
            import time

            time.sleep(duration)
            return f"{name} completed"

        return agent

    agent_functions = {
        "discuss_agent": mock_agent("discuss_agent", 0.3),
        "genre_agent": mock_agent("genre_agent", 0.2),
        "character_agent": mock_agent("character_agent", 0.5),
        "world_agent": mock_agent("world_agent", 0.4),
    }

    click.echo(f"Executing '{workflow}' in parallel (max {max_workers} workers)...")

    # Execute in parallel
    result = executor.execute_parallel(graph, agent_functions)

    # Display results
    click.echo("\n" + "=" * 60)
    click.echo("PARALLEL EXECUTION RESULTS")
    click.echo("=" * 60)

    click.echo(f"\nSuccess: {result.success}")
    click.echo(f"Completed: {len(result.completed_nodes)} agents")
    click.echo(f"Failed: {len(result.failed_nodes)} agents")
    click.echo(f"Skipped: {len(result.skipped_nodes)} agents")
    click.echo(f"Duration: {result.total_duration:.2f}s")

    if result.completed_nodes:
        click.echo("\nCompleted Agents:")
        for node_id in result.completed_nodes:
            click.echo(f"  ✓ {graph.nodes[node_id].agent_name}")

    if result.failed_nodes:
        click.echo("\nFailed Agents:")
        for node_id, error in result.errors.items():
            click.echo(f"  ✗ {graph.nodes[node_id].agent_name}: {error}")

    click.echo("\n" + "=" * 60)


@performance_cli.command()
@click.argument("project_name")
def llm_stats(project_name: str):
    """Display LLM optimization statistics"""
    optimizer = get_llm_optimizer()
    stats = optimizer.get_stats()
    cache_info = optimizer.get_cache_info()
    rate_info = optimizer.get_rate_limit_info()

    click.echo("\n" + "=" * 60)
    click.echo("LLM OPTIMIZATION STATISTICS")
    click.echo("=" * 60)

    click.echo("\nCall Statistics:")
    for key, value in stats.to_dict().items():
        click.echo(f"  {key}: {value}")

    click.echo("\nCache Information:")
    for key, value in cache_info.items():
        if key == "oldest_entry" or key == "newest_entry":
            if value:
                import time

                click.echo(f"  {key}: {time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(value))}")
        else:
            click.echo(f"  {key}: {value}")

    if rate_info:
        click.echo("\nRate Limits:")
        for provider, info in rate_info.items():
            click.echo(f"  {provider}: {info['available']}/{info['max']} available")

    click.echo("\n" + "=" * 60)


@performance_cli.command()
@click.argument("project_name")
@click.option("--model", help="Clear cache for specific model only")
def llm_cache(project_name: str, model: Optional[str]):
    """Clear LLM response cache"""
    optimizer = get_llm_optimizer()
    count = optimizer.clear_cache(model=model)

    if model:
        click.echo(f"Cleared {count} cached responses for model '{model}'")
    else:
        click.echo(f"Cleared {count} cached responses")


@performance_cli.command()
@click.argument("project_name")
@click.option("--workflow", default="autonomous", help="Workflow to estimate")
def estimate_cost(project_name: str, workflow: str):
    """Estimate LLM API costs for workflow"""
    optimizer = get_llm_optimizer()

    # Rough estimation based on typical workflow
    estimations = {
        "autonomous": {"calls": 50, "avg_tokens": 2000, "model": "gpt-3.5-turbo"},
        "writing_phase": {"calls": 20, "avg_tokens": 3000, "model": "gpt-4"},
    }

    if workflow not in estimations:
        click.echo(f"Unknown workflow: {workflow}")
        return

    est = estimations[workflow]
    total_tokens = est["calls"] * est["avg_tokens"]
    estimated_cost = optimizer._estimate_cost(est["model"], total_tokens, total_tokens // 2)

    click.echo(f"\nCost Estimate for '{workflow}':")
    click.echo(f"  Estimated calls: {est['calls']}")
    click.echo(f"  Average tokens/call: {est['avg_tokens']}")
    click.echo(f"  Total tokens: ~{total_tokens:,}")
    click.echo(f"  Model: {est['model']}")
    click.echo(f"  Estimated cost: ${estimated_cost:.2f}")
    click.echo("\nNote: This is a rough estimate. Actual costs may vary.")


# Register CLI group
def register_performance_cli(cli):
    """Register performance commands with main CLI"""
    cli.add_command(performance_cli)


if __name__ == "__main__":
    performance_cli()
