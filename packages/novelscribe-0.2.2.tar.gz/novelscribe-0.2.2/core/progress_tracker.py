"""Progress tracking system for autonomous execution."""

import json
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import Optional

from pydantic import BaseModel


class ExecutionStatus(str, Enum):
    """Execution status enum."""

    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    PAUSED = "paused"


class ProgressState(BaseModel):
    """Progress state model.

    Attributes:
        project_name: Name of the project
        current_phase: Currently executing phase
        completed_phases: List of completed phase names
        total_steps: Total number of steps in pipeline
        completed_steps: Number of completed steps
        current_step: Optional current step name
        progress_percentage: Progress percentage (0-100)
        start_time: Pipeline start time
        last_update: Last update timestamp
        status: Current execution status
        error: Optional error message if failed
    """

    project_name: str
    current_phase: str
    completed_phases: list[str]
    total_steps: int
    completed_steps: int
    current_step: Optional[str] = None
    progress_percentage: float
    start_time: datetime
    last_update: datetime
    status: ExecutionStatus
    error: Optional[str] = None


class ProgressTracker:
    """Progress tracker for autonomous execution.

    Tracks execution progress across workflows and steps,
    storing state persistently for resume capability.
    """

    def __init__(self, project_name: str, storage_path: Path):
        """Initialize progress tracker.

        Args:
            project_name: Name of the project
            storage_path: Base storage path for progress files
        """
        self.project_name = project_name
        self.storage_path = storage_path
        self.progress_file = storage_path / "PROGRESS.json"

        self._state: Optional[ProgressState] = None

    def initialize(self, total_steps: int, start_phase: str = "new_novel") -> ProgressState:
        """Initialize progress tracking.

        Args:
            total_steps: Total number of steps in pipeline
            start_phase: Starting phase name

        Returns:
            Initial progress state
        """
        now = datetime.now()

        self._state = ProgressState(
            project_name=self.project_name,
            current_phase=start_phase,
            completed_phases=[],
            total_steps=total_steps,
            completed_steps=0,
            current_step=None,
            progress_percentage=0.0,
            start_time=now,
            last_update=now,
            status=ExecutionStatus.RUNNING,
        )

        self._save_state()
        return self._state

    def update_phase(self, phase: str, step: Optional[str] = None) -> None:
        """Update current phase and step.

        Args:
            phase: New phase name
            step: Optional step name within phase
        """
        if self._state is None:
            raise RuntimeError("Progress tracker not initialized")

        self._state.current_phase = phase
        self._state.current_step = step
        self._state.last_update = datetime.now()

        self._save_state()

    def complete_phase(self, phase: str) -> None:
        """Mark a phase as completed.

        Args:
            phase: Phase name to mark as completed
        """
        if self._state is None:
            raise RuntimeError("Progress tracker not initialized")

        if phase not in self._state.completed_phases:
            self._state.completed_phases.append(phase)
            self._state.completed_steps += 1

        self._update_percentage()
        self._state.last_update = datetime.now()

        self._save_state()

    def update_step(self) -> None:
        """Increment completed steps counter."""
        if self._state is None:
            raise RuntimeError("Progress tracker not initialized")

        self._state.completed_steps += 1
        self._update_percentage()
        self._state.last_update = datetime.now()

        self._save_state()

    def _update_percentage(self) -> None:
        """Update progress percentage."""
        if self._state and self._state.total_steps > 0:
            self._state.progress_percentage = (
                self._state.completed_steps / self._state.total_steps
            ) * 100

    def set_status(self, status: ExecutionStatus, error: Optional[str] = None) -> None:
        """Set execution status.

        Args:
            status: New execution status
            error: Optional error message for failed status
        """
        if self._state is None:
            raise RuntimeError("Progress tracker not initialized")

        self._state.status = status
        self._state.error = error
        self._state.last_update = datetime.now()

        self._save_state()

    def get_state(self) -> Optional[ProgressState]:
        """Get current progress state.

        Returns:
            Current progress state or None if not initialized
        """
        return self._state

    def load_state(self) -> Optional[ProgressState]:
        """Load progress state from disk.

        Returns:
            Loaded progress state or None if not found
        """
        if not self.progress_file.exists():
            return None

        try:
            data = json.loads(self.progress_file.read_text())

            data["start_time"] = datetime.fromisoformat(data["start_time"])
            data["last_update"] = datetime.fromisoformat(data["last_update"])
            data["status"] = ExecutionStatus(data["status"])

            self._state = ProgressState(**data)
            return self._state

        except Exception as e:
            raise RuntimeError(f"Failed to load progress state: {e}")

    def _save_state(self) -> None:
        """Save progress state to disk."""
        if self._state is None:
            return

        self.progress_file.parent.mkdir(parents=True, exist_ok=True)

        data = self._state.model_dump(mode="json")

        data["start_time"] = self._state.start_time.isoformat()
        data["last_update"] = self._state.last_update.isoformat()

        self.progress_file.write_text(json.dumps(data, indent=2))

    def get_progress_summary(self) -> dict:
        """Get progress summary for display.

        Returns:
            Dictionary with progress information
        """
        if self._state is None:
            return {
                "project_name": self.project_name,
                "status": "not_initialized",
                "progress": 0.0,
            }

        return {
            "project_name": self._state.project_name,
            "current_phase": self._state.current_phase,
            "completed_phases": self._state.completed_phases,
            "total_steps": self._state.total_steps,
            "completed_steps": self._state.completed_steps,
            "progress": self._state.progress_percentage,
            "status": self._state.status.value,
            "start_time": self._state.start_time.isoformat(),
            "last_update": self._state.last_update.isoformat(),
            "error": self._state.error,
        }
