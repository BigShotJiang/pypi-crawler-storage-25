"""LLM API optimization utilities."""

import hashlib
import time
from dataclasses import dataclass
from enum import Enum
from typing import Any, Callable, Optional


class CachePolicy(Enum):
    """Cache policy for LLM calls."""

    NONE = "none"
    NO_CACHE = "no_cache"
    LRU = "lru"
    TTL = "ttl"
    SHORT = "short"
    STATIC = "static"


@dataclass
class LLMOptimizerStats:
    """Statistics for LLM optimizer."""

    total_calls: int = 0
    cache_hits: int = 0
    cache_misses: int = 0
    tokens_saved: int = 0
    cost_saved: float = 0.0


@dataclass
class CacheEntry:
    """A cache entry with metadata."""

    value: Any
    created_at: float
    model: str = "gpt-4"
    policy: CachePolicy = CachePolicy.LRU
    response: Any = None

    def __post_init__(self):
        if self.response is None:
            object.__setattr__(self, "response", self.value)


class RateLimiter:
    """Rate limiter for API calls."""

    def __init__(self, requests_per_minute: int = 60):
        self.requests_per_minute = requests_per_minute
        self.tokens = requests_per_minute
        self._tokens = requests_per_minute
        self._last_refill = time.time()
        self.last_update = time.time()

    def acquire(self, tokens: int = 1) -> bool:
        """Acquire rate limit token."""
        self._refill_tokens()
        if self._tokens >= tokens:
            self._tokens -= tokens
            self.tokens = self._tokens
            return True
        return False

    REFILL_INTERVAL_SECONDS = 60

    def get_available_tokens(self) -> int:
        """Get available token count."""
        self._refill_tokens()
        return self._tokens

    def _refill_tokens(self):
        """Refill tokens based on time elapsed."""
        now = time.time()
        # Check if enough time has elapsed for refill
        for ts_field in (self._last_refill, self.last_update):
            elapsed = now - ts_field
            if elapsed >= self.REFILL_INTERVAL_SECONDS:
                self._tokens = self.requests_per_minute
                self.tokens = self._tokens
                self._last_refill = now
                self.last_update = now
                break


class LLMOptimizer:
    """LLM API call optimizer with caching and rate limiting."""

    def __init__(
        self,
        cache_size: int = 1000,
        rate_limit: int = 60,
        default_provider: str = "openai",
        enable_caching: bool = True,
    ):
        self.cache_size = cache_size
        self.rate_limiter = RateLimiter(rate_limit)
        self.default_provider = default_provider
        self.enable_caching = enable_caching
        self._cache: dict[str, Any] = {}
        self._cache_timestamps: dict[str, float] = {}
        self._stats = LLMOptimizerStats()
        self._client = None
        self.cache = self._cache  # Public alias

    def _hash_prompt(self, prompt: str, model: str) -> str:
        """Hash a prompt for caching."""
        content = f"{model}:{prompt}"
        return hashlib.sha256(content.encode()).hexdigest()

    def _estimate_tokens(self, text: str, model: str = "gpt-4") -> int:
        """Estimate token count for text."""
        return len(text.split()) * 4 // 3

    def _estimate_cost(self, model: str, input_tokens: int, output_tokens: int = 0) -> float:
        """Estimate cost for tokens."""
        costs = {
            "gpt-4": (0.03, 0.06),
            "gpt-3.5-turbo": (0.002, 0.002),
        }
        input_cost, output_cost = costs.get(model, (0.03, 0.06))
        return (input_tokens / 1000) * input_cost + (output_tokens / 1000) * output_cost

    def _compress_prompt(self, prompt: str) -> str:
        """Compress prompt by removing redundancy."""
        import re

        prompt = re.sub(r"\s+", " ", prompt)
        lines = prompt.split("\n")
        unique_lines = list(dict.fromkeys(lines))
        return "\n".join(unique_lines)

    def _add_to_cache(
        self, key: str, value: Any, model: str = "gpt-4", policy: CachePolicy = CachePolicy.LRU
    ) -> None:
        """Add value to cache."""
        entry = CacheEntry(value=value, created_at=time.time(), model=model, policy=policy)
        if len(self._cache) >= self.cache_size:
            oldest_key = next(iter(self._cache))
            del self._cache[oldest_key]
            del self._cache_timestamps[oldest_key]
        self._cache[key] = entry
        self._cache_timestamps[key] = time.time()

    def _get_cached_response(self, key: str) -> Optional[CacheEntry]:
        """Get cached response if available and not expired."""
        entry = self._cache.get(key)
        if entry is None:
            return None
        if isinstance(entry, CacheEntry):
            now = time.time()
            if entry.policy in (CachePolicy.SHORT, CachePolicy.TTL):
                if now - entry.created_at > 300:
                    return None
            return entry
        return entry

    def _clear_expired_cache(self, ttl: float = 300.0) -> None:
        """Clear expired cache entries."""
        now = time.time()
        expired_keys = [
            k
            for k, v in self._cache.items()
            if isinstance(v, CacheEntry) and now - v.created_at > ttl
        ]
        for key in expired_keys:
            del self._cache[key]
            del self._cache_timestamps[key]

    def get_statistics(self) -> LLMOptimizerStats:
        """Get optimizer statistics (alias for get_stats)."""
        return self._stats

    def set_llm_client(self, client: Any) -> None:
        """Set the LLM client."""
        self._client = client

    def call_llm(
        self, prompt: str, model: str, cache_policy: CachePolicy = CachePolicy.NO_CACHE
    ) -> str:
        """Call LLM with caching."""
        self._stats.total_calls += 1

        if cache_policy not in (CachePolicy.NONE, CachePolicy.NO_CACHE) and self.enable_caching:
            cache_key = self._hash_prompt(prompt, model)
            entry = self._get_cached_response(cache_key)
            if entry is not None:
                self._stats.cache_hits += 1
                return entry.value if isinstance(entry, CacheEntry) else entry
            self._stats.cache_misses += 1

        if self._client:
            response = self._client(prompt=prompt, model=model)
        else:
            response = "Mock response"

        if cache_policy not in (CachePolicy.NONE, CachePolicy.NO_CACHE) and self.enable_caching:
            cache_key = self._hash_prompt(prompt, model)
            self._add_to_cache(cache_key, response, model, cache_policy)

        return response

    def batch_call(self, requests: list[dict[str, Any]]) -> list[str]:
        """Make batch LLM calls."""
        responses = []
        for req in requests:
            response = self.call_llm(
                req.get("prompt", ""), req.get("model", "gpt-4"), CachePolicy.NO_CACHE
            )
            responses.append(response)
        return responses

    def optimize_call(self, func: Callable, *args: Any, **kwargs: Any) -> Any:
        """Optimize LLM API call."""
        return func(*args, **kwargs)

    def get_stats(self) -> LLMOptimizerStats:
        """Get optimizer statistics."""
        return self._stats

    def clear_cache(self, model: Optional[str] = None) -> int:
        """Clear the cache and return count of cleared items.

        Args:
            model: If provided, only clear cache entries for this model.
        """
        if model:
            keys_to_delete = [
                k for k, v in self._cache.items() if isinstance(v, CacheEntry) and v.model == model
            ]
            for key in keys_to_delete:
                del self._cache[key]
                del self._cache_timestamps[key]
            return len(keys_to_delete)
        else:
            count = len(self._cache)
            self._cache.clear()
            self._cache_timestamps.clear()
            return count


# Global instances
_file_optimizer_instance = None
_llm_optimizer_instance = None


def get_llm_optimizer() -> LLMOptimizer:
    """Get the global LLM optimizer instance."""
    global _llm_optimizer_instance
    if _llm_optimizer_instance is None:
        _llm_optimizer_instance = LLMOptimizer()
    return _llm_optimizer_instance
