"""
Quality Gate Enforcement for Novel Generation

This module provides quality gate enforcement with multiple quality levels
(Bronze, Silver, Gold, Platinum) to ensure content meets defined standards.
"""

from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field

from .quality_metrics import QualityMetrics
from .validation_system import ValidationReport


class QualityLevel(str, Enum):
    """Quality gate levels."""

    BRONZE = "bronze"
    SILVER = "silver"
    GOLD = "gold"
    PLATINUM = "platinum"


class FixApproach(BaseModel):
    """Represents a fix approach for quality issues."""

    id: str
    name: str
    description: str
    best_for: List[str]
    intervention_level: str
    speed: str
    risk_level: str
    estimated_effort: str
    examples: List[str] = Field(default_factory=list)


class FixSuggestionResponse(BaseModel):
    """Response containing fix approach suggestions."""

    issue_summary: str
    failed_criteria: List[str]
    fix_approaches: List[FixApproach]
    recommended_approach: Optional[str] = None
    urgency_level: str
    estimated_fix_time: str


class GateResult(BaseModel):
    """Result of quality gate check."""

    gate_level: QualityLevel
    passed: bool
    scores: Dict[str, float]
    failed_criteria: List[str]
    recommendations: List[str]
    timestamp: datetime = Field(default_factory=datetime.now)
    overall_score: float = 0.0

    @property
    def pass_rate(self) -> float:
        """Calculate pass rate for criteria."""
        total_criteria = len(self.scores)
        if total_criteria == 0:
            return 1.0
        passed_criteria = total_criteria - len(self.failed_criteria)
        return passed_criteria / total_criteria


class QualityGateConfig(BaseModel):
    """Configuration for quality gates."""

    min_word_count: int = 1000
    max_passive_voice: float = 0.15
    min_readability_ease: float = 60.0
    min_dialogue_clarity: float = 0.7
    min_character_consistency: float = 0.8
    min_vocabulary_diversity: float = 0.4
    max_adverb_frequency: float = 0.08
    min_quality_score: float = 0.6

    def get_level_config(self, level: QualityLevel) -> "QualityGateConfig":
        """Get configuration for specific quality level."""
        if level == QualityLevel.BRONZE:
            return QualityGateConfig(
                min_word_count=800,
                max_passive_voice=0.20,
                min_readability_ease=50.0,
                min_dialogue_clarity=0.5,
                min_character_consistency=0.6,
                min_vocabulary_diversity=0.3,
                max_adverb_frequency=0.12,
                min_quality_score=0.6,
            )
        elif level == QualityLevel.SILVER:
            return QualityGateConfig(
                min_word_count=1000,
                max_passive_voice=0.15,
                min_readability_ease=60.0,
                min_dialogue_clarity=0.7,
                min_character_consistency=0.8,
                min_vocabulary_diversity=0.4,
                max_adverb_frequency=0.08,
                min_quality_score=0.7,
            )
        elif level == QualityLevel.GOLD:
            return QualityGateConfig(
                min_word_count=1500,
                max_passive_voice=0.10,
                min_readability_ease=70.0,
                min_dialogue_clarity=0.8,
                min_character_consistency=0.9,
                min_vocabulary_diversity=0.5,
                max_adverb_frequency=0.05,
                min_quality_score=0.8,
            )
        elif level == QualityLevel.PLATINUM:
            return QualityGateConfig(
                min_word_count=2000,
                max_passive_voice=0.05,
                min_readability_ease=80.0,
                min_dialogue_clarity=0.9,
                min_character_consistency=0.95,
                min_vocabulary_diversity=0.6,
                max_adverb_frequency=0.03,
                min_quality_score=0.9,
            )
        return self


class QualityGate:
    """
    Quality gate enforcement system.

    Enforces quality standards at different levels (Bronze, Silver, Gold, Platinum)
    and provides actionable recommendations for improvement.
    """

    def __init__(self, project_root: Optional[Path] = None):
        """
        Initialize the quality gate system.

        Args:
            project_root: Path to project directory
        """
        self.project_root = project_root or Path.cwd()
        self.gate_history: Dict[str, List[GateResult]] = {}

        data_dir = self.project_root / "core" / "data" / "suggestions"
        self._fix_suggestions_cache = self._load_fix_suggestions(data_dir)

    def _load_fix_suggestions(self, data_dir: Path) -> Dict[str, List[FixApproach]]:
        """Load fix suggestions from YAML files."""
        import yaml

        fix_suggestions = {}

        try:
            quality_file = data_dir / "quality_suggestions.yaml"
            if quality_file.exists():
                with open(quality_file, "r", encoding="utf-8") as f:
                    data = yaml.safe_load(f)

                if data and "quality_suggestions" in data:
                    for lang in ["en", "zh-CN", "zh-TW"]:
                        if lang in data["quality_suggestions"]:
                            fix_suggestions[lang] = [
                                FixApproach(**suggestion)
                                for suggestion in data["quality_suggestions"][lang]
                            ]
        except Exception as e:
            print(f"Warning: Could not load fix suggestions: {e}")

        return fix_suggestions

    def get_fix_suggestions(
        self,
        failed_criteria: List[str],
        target_level: QualityLevel = QualityLevel.SILVER,
        language: str = "en",
    ) -> FixSuggestionResponse:
        """
        Get fix approach suggestions for failed quality criteria.

        Args:
            failed_criteria: List of failed quality criteria
            target_level: Target quality level
            language: Language code (en, zh-CN, zh-TW)

        Returns:
            FixSuggestionResponse with suggested fix approaches
        """
        if language not in self._fix_suggestions_cache:
            language = "en"

        available_fixes = self._fix_suggestions_cache.get(language, [])

        relevant_fixes = self._select_relevant_fixes(failed_criteria, available_fixes)

        urgency = self._determine_urgency(failed_criteria, target_level)

        recommended = self._recommend_fix_approach(relevant_fixes, failed_criteria)

        return FixSuggestionResponse(
            issue_summary=self._generate_issue_summary(failed_criteria),
            failed_criteria=failed_criteria,
            fix_approaches=relevant_fixes,
            recommended_approach=recommended.id if recommended else None,
            urgency_level=urgency,
            estimated_fix_time=self._estimate_fix_time(failed_criteria, target_level),
        )

    def _select_relevant_fixes(
        self, failed_criteria: List[str], available_fixes: List[FixApproach]
    ) -> List[FixApproach]:
        """Select relevant fix approaches based on failed criteria."""
        relevant = []

        has_critical = any(c in ["validation", "quality_score"] for c in failed_criteria)
        has_style = any(
            c in ["passive_voice", "readability_ease", "adverb_frequency"] for c in failed_criteria
        )
        has_content = any(
            c in ["word_count", "dialogue_clarity", "character_consistency", "vocabulary_diversity"]
            for c in failed_criteria
        )

        for fix in available_fixes:
            if has_critical and "strict" in fix.id:
                relevant.append(fix)
            elif has_critical and "balanced" in fix.id:
                relevant.append(fix)
            elif has_style and ("auto_fix" in fix.id or "review" in fix.id):
                relevant.append(fix)
            elif has_content and ("defer" in fix.id or "manual" in fix.id):
                relevant.append(fix)
            elif "continuity" in fix.id and "character_consistency" in failed_criteria:
                relevant.append(fix)
            elif "style" in fix.id and has_style:
                relevant.append(fix)
            elif "pacing" in fix.id:
                relevant.append(fix)

        if not relevant:
            relevant = available_fixes[:3]

        return relevant[:4]

    def _determine_urgency(self, failed_criteria: List[str], target_level: QualityLevel) -> str:
        """Determine urgency level based on failed criteria and target level."""
        if "validation" in failed_criteria:
            return "critical"

        if target_level in [QualityLevel.GOLD, QualityLevel.PLATINUM]:
            return "high"

        if len(failed_criteria) >= 4:
            return "high"
        elif len(failed_criteria) >= 2:
            return "medium"
        else:
            return "low"

    def _recommend_fix_approach(
        self, relevant_fixes: List[FixApproach], failed_criteria: List[str]
    ) -> Optional[FixApproach]:
        """Recommend the best fix approach based on context."""
        if not relevant_fixes:
            return None

        if "validation" in failed_criteria or "quality_score" in failed_criteria:
            for fix in relevant_fixes:
                if "balanced" in fix.id:
                    return fix

        for fix in relevant_fixes:
            if "review" in fix.id:
                return fix

        return relevant_fixes[0]

    def _generate_issue_summary(self, failed_criteria: List[str]) -> str:
        """Generate a human-readable summary of issues."""
        criterion_names = {
            "word_count": "Word count",
            "passive_voice": "Passive voice usage",
            "readability_ease": "Readability score",
            "dialogue_clarity": "Dialogue clarity",
            "character_consistency": "Character consistency",
            "vocabulary_diversity": "Vocabulary diversity",
            "adverb_frequency": "Adverb frequency",
            "quality_score": "Overall quality score",
            "validation": "Validation errors",
        }

        names = [criterion_names.get(c, c) for c in failed_criteria]

        if len(names) == 1:
            return f"Issue with {names[0]}"
        elif len(names) == 2:
            return f"Issues with {names[0]} and {names[1]}"
        else:
            return f"Issues with {', '.join(names[:-1])}, and {names[-1]}"

    def _estimate_fix_time(self, failed_criteria: List[str], target_level: QualityLevel) -> str:
        """Estimate time required to fix issues."""
        if "validation" in failed_criteria:
            return "15-30 minutes"

        if target_level == QualityLevel.PLATINUM:
            return "1-2 hours"
        elif target_level == QualityLevel.GOLD:
            return "45-90 minutes"
        elif target_level == QualityLevel.SILVER:
            return "30-60 minutes"
        else:
            return "15-30 minutes"

    def check_quality_gate(
        self,
        project_name: str,
        metrics: QualityMetrics,
        validation_report: Optional[ValidationReport] = None,
        target_level: QualityLevel = QualityLevel.SILVER,
    ) -> GateResult:
        """
        Check if content meets quality gate requirements.

        Args:
            project_name: Name of the project
            metrics: Quality metrics to evaluate
            validation_report: Optional validation report to consider
            target_level: Target quality gate level

        Returns:
            GateResult with detailed pass/fail information
        """
        config = QualityGateConfig().get_level_config(target_level)

        scores = {}
        failed_criteria = []
        recommendations = []

        criteria_checks = [
            ("word_count", metrics.word_count, config.min_word_count, ">="),
            ("passive_voice", metrics.passive_voice_ratio, config.max_passive_voice, "<="),
            ("readability_ease", metrics.flesch_kincaid, config.min_readability_ease, ">="),
            ("dialogue_clarity", metrics.speaker_clarity, config.min_dialogue_clarity, ">="),
            (
                "character_consistency",
                metrics.character_consistency,
                config.min_character_consistency,
                ">=",
            ),
            (
                "vocabulary_diversity",
                metrics.vocabulary_diversity,
                config.min_vocabulary_diversity,
                ">=",
            ),
            ("adverb_frequency", metrics.adverb_frequency, config.max_adverb_frequency, "<="),
            ("quality_score", metrics.overall_quality_score, config.min_quality_score, ">="),
        ]

        for criterion_name, value, threshold, operator in criteria_checks:
            passed = self._check_criterion(value, threshold, operator)
            scores[criterion_name] = value

            if not passed:
                failed_criteria.append(criterion_name)
                recommendations.extend(
                    self._generate_recommendations(criterion_name, value, threshold, target_level)
                )

        if validation_report:
            validation_passed = self._check_validation_report(validation_report, target_level)
            scores["validation"] = 1.0 if validation_passed else 0.0

            if not validation_passed:
                failed_criteria.append("validation")
                recommendations.append(
                    "Address validation errors before promoting to next quality level"
                )

        overall_score = self._calculate_overall_score(scores, config)
        passed = len(failed_criteria) == 0

        result = GateResult(
            gate_level=target_level,
            passed=passed,
            scores=scores,
            failed_criteria=failed_criteria,
            recommendations=list(set(recommendations)),
            overall_score=overall_score,
        )

        self._record_gate_result(project_name, result)

        return result

    def _check_criterion(self, value: float, threshold: float, operator: str) -> bool:
        """Check if a criterion meets the threshold."""
        if operator == ">=":
            return value >= threshold
        elif operator == "<=":
            return value <= threshold
        elif operator == ">":
            return value > threshold
        elif operator == "<":
            return value < threshold
        return False

    def _check_validation_report(
        self, report: ValidationReport, target_level: QualityLevel
    ) -> bool:
        """Check if validation report meets quality gate requirements."""
        if target_level == QualityLevel.BRONZE:
            return report.errors == 0
        elif target_level == QualityLevel.SILVER:
            return report.errors == 0 and report.warnings <= 2
        elif target_level == QualityLevel.GOLD:
            return report.errors == 0 and report.warnings == 0
        elif target_level == QualityLevel.PLATINUM:
            return report.errors == 0 and report.warnings == 0 and report.success_rate >= 0.95
        return True

    def _calculate_overall_score(
        self, scores: Dict[str, float], config: QualityGateConfig
    ) -> float:
        """Calculate overall quality score from individual scores."""
        weights = {
            "quality_score": 0.30,
            "readability_ease": 0.15,
            "dialogue_clarity": 0.15,
            "character_consistency": 0.15,
            "vocabulary_diversity": 0.10,
            "passive_voice": 0.05,
            "adverb_frequency": 0.05,
            "word_count": 0.05,
        }

        normalized_scores = {}

        for criterion, value in scores.items():
            if criterion == "validation":
                continue

            if criterion == "passive_voice":
                normalized = 1.0 - (value / 0.3)
            elif criterion == "adverb_frequency":
                normalized = 1.0 - (value / 0.2)
            elif criterion == "word_count":
                normalized = min(value / 2000, 1.0)
            else:
                normalized = min(max(value, 0.0), 1.0)

            normalized_scores[criterion] = normalized

        weighted_sum = sum(
            normalized_scores.get(criterion, 0.0) * weight for criterion, weight in weights.items()
        )

        return min(max(weighted_sum, 0.0), 1.0)

    def _generate_recommendations(
        self, criterion: str, value: float, threshold: float, target_level: QualityLevel
    ) -> List[str]:
        """Generate actionable recommendations for failed criteria."""
        recommendations = {
            "word_count": [
                f"Expand content to meet minimum word count ({int(threshold)} words)",
                "Add more descriptive details, character development, or dialogue",
                "Consider extending scenes or adding subplots",
            ],
            "passive_voice": [
                f"Reduce passive voice from {value:.1%} to {threshold:.1%} or less",
                "Rewrite passive constructions as active voice",
                "Focus on making the subject perform the action",
            ],
            "readability_ease": [
                f"Improve readability score from {value:.1f} to {threshold:.1f} or higher",
                "Use shorter sentences and simpler words",
                "Break up long paragraphs and sentences",
            ],
            "dialogue_clarity": [
                f"Improve dialogue clarity from {value:.1%} to {threshold:.1%} or higher",
                "Add clear speaker attributions to dialogue lines",
                "Use action beats or unique speech patterns to identify speakers",
            ],
            "character_consistency": [
                f"Improve character consistency from {value:.1%} to {threshold:.1%} or higher",
                "Ensure all named characters appear in the chapter",
                "Review character behavior and speech patterns for consistency",
            ],
            "vocabulary_diversity": [
                f"Increase vocabulary diversity from {value:.1%} to {threshold:.1%} or higher",
                "Use a wider variety of words and avoid repetition",
                "Replace common words with more specific or evocative alternatives",
            ],
            "adverb_frequency": [
                f"Reduce adverb frequency from {value:.2%} to {threshold:.2%} or less",
                "Replace adverbs with stronger verbs",
                "Show action and emotion rather than telling with adverbs",
            ],
            "quality_score": [
                f"Improve overall quality from {value:.1%} to {threshold:.1%} or higher",
                "Review all failed criteria and implement recommendations",
                "Consider multiple revision iterations focusing on weakest areas",
            ],
        }

        return recommendations.get(criterion, ["Review and improve this criterion"])

    def _record_gate_result(self, project_name: str, result: GateResult):
        """Record gate result for tracking."""
        if project_name not in self.gate_history:
            self.gate_history[project_name] = []
        self.gate_history[project_name].append(result)

    def get_highest_passing_level(
        self,
        project_name: str,
        metrics: QualityMetrics,
        validation_report: Optional[ValidationReport] = None,
    ) -> QualityLevel:
        """
        Determine the highest quality level that content passes.

        Args:
            project_name: Name of the project
            metrics: Quality metrics to evaluate
            validation_report: Optional validation report

        Returns:
            Highest QualityLevel that content passes
        """
        levels = [
            QualityLevel.PLATINUM,
            QualityLevel.GOLD,
            QualityLevel.SILVER,
            QualityLevel.BRONZE,
        ]

        for level in levels:
            result = self.check_quality_gate(project_name, metrics, validation_report, level)
            if result.passed:
                return level

        return QualityLevel.BRONZE

    def promote_to_level(
        self,
        project_name: str,
        metrics: QualityMetrics,
        validation_report: Optional[ValidationReport] = None,
        target_level: QualityLevel = QualityLevel.SILVER,
        auto_fix: bool = False,
    ) -> Dict[str, Any]:
        """
        Attempt to promote content to target quality level.

        Args:
            project_name: Name of the project
            metrics: Quality metrics to evaluate
            validation_report: Optional validation report
            target_level: Target quality level
            auto_fix: Whether to generate auto-fix suggestions

        Returns:
            Dictionary with promotion results and actions needed
        """
        result = self.check_quality_gate(project_name, metrics, validation_report, target_level)

        promotion_status = {
            "target_level": target_level,
            "current_level": self.get_highest_passing_level(
                project_name, metrics, validation_report
            ),
            "passed": result.passed,
            "overall_score": result.overall_score,
            "pass_rate": result.pass_rate,
            "failed_criteria": result.failed_criteria,
            "recommendations": result.recommendations,
            "can_auto_promote": False,
            "actions_needed": [],
        }

        if result.passed:
            promotion_status["can_auto_promote"] = True
            promotion_status["actions_needed"].append(
                f"Content meets {target_level.value} quality standards"
            )
        else:
            gap_analysis = self._analyze_promotion_gap(metrics, result, target_level)
            promotion_status["gap_analysis"] = gap_analysis

            if auto_fix:
                promotion_status["auto_fix_plan"] = self._generate_auto_fix_plan(
                    result.failed_criteria, gap_analysis
                )

            promotion_status["actions_needed"].extend(
                self._generate_action_plan(result.failed_criteria, result.recommendations)
            )

        return promotion_status

    def _analyze_promotion_gap(
        self, metrics: QualityMetrics, result: GateResult, target_level: QualityLevel
    ) -> Dict[str, Any]:
        """Analyze the gap between current and target quality level."""
        config = QualityGateConfig().get_level_config(target_level)

        gaps = {}
        for criterion in result.failed_criteria:
            if criterion in result.scores:
                current_value = result.scores[criterion]

                if criterion == "word_count":
                    threshold = config.min_word_count
                    gap = threshold - current_value
                    gaps[criterion] = {
                        "current": current_value,
                        "target": threshold,
                        "gap": gap,
                        "percent_improvement": (gap / threshold) * 100,
                    }
                elif criterion.endswith("_ratio") or criterion.endswith("_frequency"):
                    threshold = getattr(config, f"max_{criterion}", current_value)
                    gap = current_value - threshold
                    gaps[criterion] = {
                        "current": current_value,
                        "target": threshold,
                        "gap": gap,
                        "percent_improvement": (gap / current_value) * 100,
                    }
                else:
                    threshold = getattr(config, f"min_{criterion}", 0.0)
                    gap = threshold - current_value
                    gaps[criterion] = {
                        "current": current_value,
                        "target": threshold,
                        "gap": gap,
                        "percent_improvement": (gap / threshold) * 100 if threshold > 0 else 0,
                    }

        return gaps

    def _generate_auto_fix_plan(
        self, failed_criteria: List[str], gap_analysis: Dict[str, Any]
    ) -> List[str]:
        """Generate automatic fix suggestions."""
        auto_fixes = []

        for criterion in failed_criteria:
            if criterion in gap_analysis:
                gap = gap_analysis[criterion]

                if criterion == "word_count":
                    auto_fixes.append(
                        f"Add approximately {int(gap['gap'])} words to meet minimum count"
                    )
                elif criterion == "passive_voice":
                    auto_fixes.append(
                        f"Rewrite {int(gap['gap'] * 100)}% of passive constructions to active voice"
                    )
                elif criterion == "readability_ease":
                    auto_fixes.append(
                        "Simplify sentence structure and vocabulary to improve readability"
                    )
                elif criterion == "dialogue_clarity":
                    auto_fixes.append("Add speaker attributions to unidentified dialogue lines")
                elif criterion == "character_consistency":
                    auto_fixes.append("Incorporate missing character appearances and interactions")
                elif criterion == "vocabulary_diversity":
                    auto_fixes.append("Replace repeated words with varied vocabulary")
                elif criterion == "adverb_frequency":
                    auto_fixes.append(
                        f"Replace {int(gap['gap'] * 100)} adverbs with stronger verbs"
                    )

        return auto_fixes

    def _generate_action_plan(
        self, failed_criteria: List[str], recommendations: List[str]
    ) -> List[str]:
        """Generate prioritized action plan for failed criteria."""
        priority_order = [
            "validation",
            "quality_score",
            "word_count",
            "character_consistency",
            "readability_ease",
            "dialogue_clarity",
            "vocabulary_diversity",
            "passive_voice",
            "adverb_frequency",
        ]

        actions = []
        for criterion in priority_order:
            if criterion in failed_criteria:
                criterion_recommendations = [
                    rec
                    for rec in recommendations
                    if criterion.lower() in rec.lower()
                    or criterion.replace("_", " ") in rec.lower()
                ]
                actions.extend(criterion_recommendations[:2])

        return actions

    def generate_quality_report(
        self,
        project_name: str,
        metrics: QualityMetrics,
        validation_report: Optional[ValidationReport] = None,
    ) -> str:
        """
        Generate comprehensive quality report.

        Args:
            project_name: Name of the project
            metrics: Quality metrics
            validation_report: Optional validation report

        Returns:
            Formatted quality report as string
        """
        current_level = self.get_highest_passing_level(project_name, metrics, validation_report)

        report_lines = [
            "# Quality Gate Report",
            f"Project: {project_name}",
            f"Chapter: {metrics.chapter_number} (Version {metrics.version})",
            f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
            "",
            f"## Current Quality Level: {current_level.value.upper()}",
            "",
            "## Quality Scores",
            f"- Overall Quality: {metrics.overall_quality_score:.1%}",
            f"- Word Count: {metrics.word_count:,}",
            f"- Readability (Flesch-Kincaid): {metrics.flesch_kincaid:.1f}",
            f"- Dialogue Clarity: {metrics.speaker_clarity:.1%}",
            f"- Character Consistency: {metrics.character_consistency:.1%}",
            f"- Vocabulary Diversity: {metrics.vocabulary_diversity:.1%}",
            f"- Passive Voice Ratio: {metrics.passive_voice_ratio:.1%}",
            f"- Adverb Frequency: {metrics.adverb_frequency:.2%}",
            "",
        ]

        if validation_report:
            report_lines.extend(
                [
                    "## Validation Results",
                    f"- Total Rules Checked: {validation_report.total_rules_checked}",
                    f"- Passed: {validation_report.passed_rules}",
                    f"- Failed: {validation_report.failed_rules}",
                    f"- Warnings: {validation_report.warnings}",
                    f"- Errors: {validation_report.errors}",
                    "",
                ]
            )

        promotion_status = self.promote_to_level(
            project_name, metrics, validation_report, QualityLevel.GOLD
        )

        report_lines.extend(
            [
                "## Promotion Path",
                f"- Current Level: {current_level.value}",
                f"- Next Target: {promotion_status['current_level'].value}",
                f"- Can Promote: {promotion_status['can_auto_promote']}",
                "",
            ]
        )

        if promotion_status["recommendations"]:
            report_lines.extend(["## Recommendations for Improvement", ""])
            for i, rec in enumerate(promotion_status["recommendations"], 1):
                report_lines.append(f"{i}. {rec}")

        return "\n".join(report_lines)

    def get_gate_statistics(self, project_name: str) -> Dict[str, Any]:
        """Get statistics for quality gate history."""
        if project_name not in self.gate_history:
            return {"error": "No gate history found for project"}

        history = self.gate_history[project_name]

        level_counts = {level.value: 0 for level in QualityLevel}
        pass_count = sum(1 for result in history if result.passed)
        total_count = len(history)

        for result in history:
            level_counts[result.gate_level.value] += 1

        recent_scores = [r.overall_score for r in history[-10:]]

        return {
            "project_name": project_name,
            "total_checks": total_count,
            "pass_count": pass_count,
            "pass_rate": pass_count / total_count if total_count > 0 else 0,
            "level_distribution": level_counts,
            "recent_average_score": (
                sum(recent_scores) / len(recent_scores) if recent_scores else None
            ),
            "most_common_level": max(level_counts, key=level_counts.get),
        }
