"""Continuity report parser for verification system."""

from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import List, Optional

from pydantic import BaseModel


class IssueType(str, Enum):
    CHARACTER = "character"
    PLOT = "plot"
    WORLD = "world"
    TIMELINE = "timeline"
    INCONSISTENCY = "inconsistency"


class Severity(str, Enum):
    CRITICAL = "critical"
    MAJOR = "major"
    MINOR = "minor"


class ReportStatus(str, Enum):
    PASS = "PASS"
    FAIL = "FAIL"
    WARNING = "WARNING"


class ContinuityIssue(BaseModel):
    issue_type: IssueType
    severity: Severity
    description: str
    location: Optional[str] = None
    suggestion: Optional[str] = None


class ContinuityReport(BaseModel):
    project_name: str
    timestamp: datetime
    total_issues: int
    critical_count: int
    major_count: int
    minor_count: int
    issues: List[ContinuityIssue]
    status: ReportStatus


class ContinuityParser:
    def __init__(self, project_dir: str):
        self.project_dir = Path(project_dir)

    def parse_report(self, report_path: Optional[str] = None) -> ContinuityReport:
        if report_path:
            report_file = Path(report_path)
        else:
            report_file = self.project_dir / "continuity_report.md"

        if not report_file.exists():
            raise FileNotFoundError(f"Continuity report not found: {report_file}")

        content = report_file.read_text()
        return self._parse_markdown_report(content, self.project_dir.name)

    def _parse_markdown_report(self, content: str, project_name: str) -> ContinuityReport:
        issues = []
        critical_count = 0
        major_count = 0
        minor_count = 0

        lines = content.split("\n")
        current_issue = None

        for line in lines:
            line = line.strip()

            if line.startswith("# "):
                continue

            if line.startswith("## ") and "Issue" in line:
                if current_issue:
                    issues.append(current_issue)
                    if current_issue.severity == Severity.CRITICAL:
                        critical_count += 1
                    elif current_issue.severity == Severity.MAJOR:
                        major_count += 1
                    else:
                        minor_count += 1

                current_issue = self._parse_issue_header(line)

            elif line.startswith("- **Type:**"):
                if current_issue:
                    issue_type_str = line.split("**Type:**")[1].strip().lower()
                    current_issue.issue_type = IssueType(issue_type_str)

            elif line.startswith("- **Severity:**"):
                if current_issue:
                    severity_str = line.split("**Severity:**")[1].strip().lower()
                    current_issue.severity = Severity(severity_str)

            elif line.startswith("- **Location:**"):
                if current_issue:
                    location = line.split("**Location:**")[1].strip()
                    current_issue.location = location

            elif line.startswith("**Description:**"):
                if current_issue:
                    desc = line.split("**Description:**")[1].strip()
                    current_issue.description = desc

            elif line.startswith("**Suggestion:**"):
                if current_issue:
                    suggestion = line.split("**Suggestion:**")[1].strip()
                    current_issue.suggestion = suggestion

        if current_issue:
            issues.append(current_issue)
            if current_issue.severity == Severity.CRITICAL:
                critical_count += 1
            elif current_issue.severity == Severity.MAJOR:
                major_count += 1
            else:
                minor_count += 1

        status = self._determine_status(critical_count, major_count, minor_count)

        return ContinuityReport(
            project_name=project_name,
            timestamp=datetime.now(),
            total_issues=len(issues),
            critical_count=critical_count,
            major_count=major_count,
            minor_count=minor_count,
            issues=issues,
            status=status,
        )

    def _parse_issue_header(self, line: str) -> ContinuityIssue:
        return ContinuityIssue(
            issue_type=IssueType.INCONSISTENCY,
            severity=Severity.MINOR,
            description="",
            location=None,
            suggestion=None,
        )

    def _determine_status(
        self, critical_count: int, major_count: int, minor_count: int
    ) -> ReportStatus:
        if critical_count > 0:
            return ReportStatus.FAIL
        elif major_count > 5:
            return ReportStatus.FAIL
        elif major_count > 0:
            return ReportStatus.WARNING
        elif minor_count > 10:
            return ReportStatus.WARNING
        else:
            return ReportStatus.PASS

    def generate_report(self, project_name: str, issues: List[ContinuityIssue]) -> ContinuityReport:
        critical_count = sum(1 for i in issues if i.severity == Severity.CRITICAL)
        major_count = sum(1 for i in issues if i.severity == Severity.MAJOR)
        minor_count = sum(1 for i in issues if i.severity == Severity.MINOR)

        status = self._determine_status(critical_count, major_count, minor_count)

        return ContinuityReport(
            project_name=project_name,
            timestamp=datetime.now(),
            total_issues=len(issues),
            critical_count=critical_count,
            major_count=major_count,
            minor_count=minor_count,
            issues=issues,
            status=status,
        )

    def save_report(self, report: ContinuityReport, output_path: Optional[str] = None) -> str:
        if output_path:
            report_file = Path(output_path)
        else:
            report_file = self.project_dir / "continuity_report.md"

        report_file.parent.mkdir(parents=True, exist_ok=True)

        lines = [
            f"# Continuity Report: {report.project_name}",
            f"**Generated:** {report.timestamp.strftime('%Y-%m-%d %H:%M:%S')}",
            f"**Status:** {report.status.value}",
            "",
            "## Summary",
            f"- Total Issues: {report.total_issues}",
            f"- Critical: {report.critical_count}",
            f"- Major: {report.major_count}",
            f"- Minor: {report.minor_count}",
            "",
        ]

        if report.issues:
            lines.append("## Issues")
            lines.append("")

            for i, issue in enumerate(report.issues, 1):
                lines.append(f"### Issue {i}")
                lines.append(f"- **Type:** {issue.issue_type.value}")
                lines.append(f"- **Severity:** {issue.severity.value}")
                if issue.location:
                    lines.append(f"- **Location:** {issue.location}")
                lines.append(f"**Description:** {issue.description}")
                if issue.suggestion:
                    lines.append(f"**Suggestion:** {issue.suggestion}")
                lines.append("")
        else:
            lines.append("## Issues")
            lines.append("")
            lines.append("No issues found. ✅")

        report_file.write_text("\n".join(lines))
        return str(report_file)

    def filter_issues_by_type(
        self, report: ContinuityReport, issue_type: IssueType
    ) -> List[ContinuityIssue]:
        return [i for i in report.issues if i.issue_type == issue_type]

    def filter_issues_by_severity(
        self, report: ContinuityReport, severity: Severity
    ) -> List[ContinuityIssue]:
        return [i for i in report.issues if i.severity == severity]

    def get_critical_issues(self, report: ContinuityReport) -> List[ContinuityIssue]:
        return self.filter_issues_by_severity(report, Severity.CRITICAL)

    def get_major_issues(self, report: ContinuityReport) -> List[ContinuityIssue]:
        return self.filter_issues_by_severity(report, Severity.MAJOR)

    def get_minor_issues(self, report: ContinuityReport) -> List[ContinuityIssue]:
        return self.filter_issues_by_severity(report, Severity.MINOR)
