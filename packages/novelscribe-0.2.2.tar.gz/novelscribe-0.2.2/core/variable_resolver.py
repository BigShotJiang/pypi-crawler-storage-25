"""Enhanced variable resolver with dot notation support."""

import re
from typing import Any, Dict, List, Optional


class VariableResolver:
    """Resolve variables with ${variable} syntax and dot notation."""

    VARIABLE_PATTERN = re.compile(r"\$\{([^}]+)\}")

    def __init__(self) -> None:
        """Initialize variable resolver."""
        self.variables: Dict[str, Any] = {}
        self.step_outputs: Dict[str, Any] = {}

    def resolve(
        self,
        template: str | Any,
        variables: Optional[Dict[str, Any]] = None,
        step_outputs: Optional[Dict[str, Any]] = None,
    ) -> Any:
        """Resolve variables in template string.

        Args:
            template: Template string or value
            variables: Workflow variables
            step_outputs: Outputs from previous steps

        Returns:
            Resolved value
        """
        if variables:
            self.variables = variables
        if step_outputs:
            self.step_outputs = step_outputs

        if not isinstance(template, str):
            return template

        def replace_var(match: re.Match) -> str:
            var_path = match.group(1)
            value = self._get_variable_value(var_path)

            if value is None:
                return str(match.group(0))

            return str(value)

        result = self.VARIABLE_PATTERN.sub(replace_var, template)

        return result

    def resolve_dict(
        self,
        data: Dict[str, Any],
        variables: Optional[Dict[str, Any]] = None,
        step_outputs: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """Resolve variables in dictionary.

        Args:
            data: Dictionary with variables
            variables: Workflow variables
            step_outputs: Outputs from previous steps

        Returns:
            Dictionary with resolved variables
        """
        resolved = {}

        for key, value in data.items():
            if isinstance(value, str):
                resolved[key] = self.resolve(value, variables, step_outputs)
            elif isinstance(value, dict):
                resolved[key] = self.resolve_dict(value, variables, step_outputs)
            elif isinstance(value, list):
                resolved[key] = self.resolve_list(value, variables, step_outputs)
            else:
                resolved[key] = value

        return resolved

    def resolve_list(
        self,
        data: List[Any],
        variables: Optional[Dict[str, Any]] = None,
        step_outputs: Optional[Dict[str, Any]] = None,
    ) -> List[Any]:
        """Resolve variables in list.

        Args:
            data: List with variables
            variables: Workflow variables
            step_outputs: Outputs from previous steps

        Returns:
            List with resolved variables
        """
        resolved = []

        for item in data:
            if isinstance(item, str):
                resolved.append(self.resolve(item, variables, step_outputs))
            elif isinstance(item, dict):
                resolved.append(self.resolve_dict(item, variables, step_outputs))
            elif isinstance(item, list):
                resolved.append(self.resolve_list(item, variables, step_outputs))
            else:
                resolved.append(item)

        return resolved

    def _get_variable_value(self, var_path: str) -> Optional[Any]:
        """Get variable value by path (supports dot notation).

        Args:
            var_path: Variable path (e.g., "project.meta.genre")

        Returns:
            Variable value or None
        """
        parts = var_path.split(".")

        value = None

        if parts[0] in self.variables:
            value = self.variables[parts[0]]
        elif parts[0] in self.step_outputs:
            value = self.step_outputs[parts[0]]
        else:
            return None

        for part in parts[1:]:
            if isinstance(value, dict):
                value = value.get(part)
            else:
                return None

        return value

    def evaluate_condition(
        self,
        condition: str,
        variables: Optional[Dict[str, Any]] = None,
        step_outputs: Optional[Dict[str, Any]] = None,
    ) -> bool:
        """Evaluate conditional expression.

        Args:
            condition: Condition expression
            variables: Workflow variables
            step_outputs: Outputs from previous steps

        Returns:
            True if condition is true, False otherwise
        """
        if not condition:
            return True

        if variables:
            self.variables.update(variables)
        if step_outputs:
            self.step_outputs.update(step_outputs)

        def replace_var(match):
            var_path = match.group(1)
            value = self._get_variable_value(var_path)
            if value is None:
                return match.group(0)
            if isinstance(value, str):
                return repr(value)
            return str(value)

        resolved = self.VARIABLE_PATTERN.sub(replace_var, condition)

        try:
            return bool(eval(resolved))
        except Exception:
            return False

    def clear(self) -> None:
        """Clear all variables."""
        self.variables.clear()
        self.step_outputs.clear()

    def set_variable(self, name: str, value: Any) -> None:
        """Set a variable value.

        Args:
            name: Variable name
            value: Variable value
        """
        self.variables[name] = value

    def set_step_output(self, step_name: str, output: Any) -> None:
        """Set step output.

        Args:
            step_name: Step name
            output: Step output
        """
        self.step_outputs[step_name] = output

    def get_variable(self, name: str, default: Any = None) -> Any:
        """Get variable value.

        Args:
            name: Variable name
            default: Default value if not found

        Returns:
            Variable value or default
        """
        return self.variables.get(name, default)

    def get_step_output(self, step_name: str, default: Any = None) -> Any:
        """Get step output.

        Args:
            step_name: Step name
            default: Default value if not found

        Returns:
            Step output or default
        """
        return self.step_outputs.get(step_name, default)
