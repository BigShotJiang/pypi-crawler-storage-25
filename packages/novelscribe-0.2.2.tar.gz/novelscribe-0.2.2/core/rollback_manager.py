"""Rollback management for safe version restoration."""

import shutil
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field

from core.draft_manager import DraftManager, DraftMetadata


class RollbackResult(BaseModel):
    success: bool
    chapter_number: int
    from_version: int
    to_version: int
    backup_created: bool
    backup_path: Optional[str] = None
    timestamp: datetime = Field(default_factory=datetime.now)
    warnings: List[str] = Field(default_factory=list)
    error_message: Optional[str] = None


class RollbackValidation(BaseModel):
    can_rollback: bool
    reasons: List[str] = Field(default_factory=list)
    warnings: List[str] = Field(default_factory=list)
    dependency_issues: List[str] = Field(default_factory=list)


class RollbackManager:
    def __init__(self, project_dir: str):
        self.project_dir = Path(project_dir)
        self.draft_manager = DraftManager(str(self.project_dir))

    def validate_rollback(self, chapter_number: int, target_version: int) -> RollbackValidation:
        reasons = []
        warnings = []
        dependency_issues = []

        target_metadata = self.draft_manager.get_version(chapter_number, target_version)

        if not target_metadata:
            return RollbackValidation(
                can_rollback=False,
                reasons=[f"Version {target_version} not found for chapter {chapter_number}"],
            )

        current_metadata = self.draft_manager.get_current_version(chapter_number)

        if not current_metadata:
            return RollbackValidation(
                can_rollback=False,
                reasons=[f"No current version found for chapter {chapter_number}"],
            )

        if target_version == current_metadata.version:
            return RollbackValidation(
                can_rollback=False, reasons=[f"Already at version {target_version}"]
            )

        if target_version > current_metadata.version:
            return RollbackValidation(
                can_rollback=False,
                reasons=[
                    f"Cannot rollback to version {target_version} "
                    f"(newer than current {current_metadata.version})"
                ],
            )

        versions = self.draft_manager.list_versions(chapter_number)
        version_numbers = [v.version for v in versions]

        if target_version not in version_numbers:
            return RollbackValidation(
                can_rollback=False,
                reasons=[f"Version {target_version} not found in version history"],
            )

        warning_checks = self._check_for_warnings(
            chapter_number, target_version, current_metadata.version
        )
        warnings.extend(warning_checks)

        dependency_checks = self._check_dependencies(chapter_number, target_version)
        dependency_issues.extend(dependency_checks)

        can_rollback = len(reasons) == 0

        return RollbackValidation(
            can_rollback=can_rollback,
            reasons=reasons,
            warnings=warnings,
            dependency_issues=dependency_issues,
        )

    def _check_for_warnings(
        self, chapter_number: int, target_version: int, current_version: int
    ) -> List[str]:
        warnings = []

        versions_skipped = current_version - target_version
        if versions_skipped > 1:
            warnings.append(
                f"Rolling back {versions_skipped} versions. Intermediate versions will be skipped."
            )

        target_metadata = self.draft_manager.get_version(chapter_number, target_version)
        current_metadata = self.draft_manager.get_current_version(chapter_number)

        if target_metadata and current_metadata:
            word_diff = target_metadata.word_count - current_metadata.word_count
            if abs(word_diff) > 500:
                warnings.append(f"Significant word count change: {word_diff:+d} words")

            if target_metadata.quality_score and current_metadata.quality_score:
                score_diff = target_metadata.quality_score - current_metadata.quality_score
                if score_diff < -0.2:
                    warnings.append(
                        "Rolling back to lower quality version "
                        f"(score difference: {score_diff:.2f})"
                    )

        return warnings

    def _check_dependencies(self, chapter_number: int, target_version: int) -> List[str]:
        issues = []

        project_summary = self.draft_manager.get_project_summary()

        for chapter_summary in project_summary.get("chapters", []):
            other_chapter = chapter_summary["chapter_number"]

            if other_chapter <= chapter_number:
                continue

            other_metadata = self.draft_manager.get_current_version(other_chapter)

            if other_metadata and other_metadata.parent_version:
                if other_metadata.parent_version > target_version:
                    issues.append(
                        f"Chapter {other_chapter} depends on version "
                        f"{other_metadata.parent_version}, "
                        f"which is newer than target version {target_version}"
                    )

        return issues

    def rollback(
        self,
        chapter_number: int,
        target_version: int,
        create_backup: bool = True,
        force: bool = False,
    ) -> RollbackResult:
        validation = self.validate_rollback(chapter_number, target_version)

        if not validation.can_rollback and not force:
            return RollbackResult(
                success=False,
                chapter_number=chapter_number,
                from_version=(
                    self.draft_manager.get_current_version(chapter_number).version
                    if self.draft_manager.get_current_version(chapter_number)
                    else 0
                ),
                to_version=target_version,
                backup_created=False,
                error_message="; ".join(validation.reasons),
            )

        if not force and validation.dependency_issues:
            return RollbackResult(
                success=False,
                chapter_number=chapter_number,
                from_version=(
                    self.draft_manager.get_current_version(chapter_number).version
                    if self.draft_manager.get_current_version(chapter_number)
                    else 0
                ),
                to_version=target_version,
                backup_created=False,
                warnings=validation.dependency_issues,
                error_message="Dependency issues detected. Use --force to override.",
            )

        try:
            current_metadata = self.draft_manager.get_current_version(chapter_number)
            current_version = current_metadata.version if current_metadata else 0

            backup_path = None
            if create_backup:
                backup_path = self._create_backup(chapter_number, current_version)

            target_content = self.draft_manager.get_version_content(chapter_number, target_version)

            if not target_content:
                return RollbackResult(
                    success=False,
                    chapter_number=chapter_number,
                    from_version=current_version,
                    to_version=target_version,
                    backup_created=bool(backup_path),
                    backup_path=backup_path,
                    error_message=f"Could not retrieve content for version {target_version}",
                )

            self._restore_version(chapter_number, target_version, target_content)

            return RollbackResult(
                success=True,
                chapter_number=chapter_number,
                from_version=current_version,
                to_version=target_version,
                backup_created=bool(backup_path),
                backup_path=backup_path,
                warnings=validation.warnings,
            )

        except Exception as e:
            return RollbackResult(
                success=False,
                chapter_number=chapter_number,
                from_version=(
                    self.draft_manager.get_current_version(chapter_number).version
                    if self.draft_manager.get_current_version(chapter_number)
                    else 0
                ),
                to_version=target_version,
                backup_created=False,
                error_message=str(e),
            )

    def _create_backup(self, chapter_number: int, current_version: int) -> str:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        backup_filename = (
            f"chapter_{chapter_number:03d}_v{current_version:03d}_backup_{timestamp}.md"
        )

        chapter_dir = self.project_dir / "chapters" / f"chapter_{chapter_number:03d}"
        backup_dir = chapter_dir / "backups"
        backup_dir.mkdir(parents=True, exist_ok=True)

        backup_path = backup_dir / backup_filename
        current_file = chapter_dir / "current.md"

        if current_file.exists():
            shutil.copy2(current_file, backup_path)

        return str(backup_path)

    def _restore_version(self, chapter_number: int, target_version: int, content: str) -> None:
        chapter_dir = self.project_dir / "chapters" / f"chapter_{chapter_number:03d}"
        current_file = chapter_dir / "current.md"

        current_file.parent.mkdir(parents=True, exist_ok=True)
        current_file.write_text(content)

        target_metadata = self.draft_manager.get_version(chapter_number, target_version)

        if target_metadata:
            new_metadata = DraftMetadata(
                chapter_number=chapter_number,
                version=target_version,
                timestamp=datetime.now(),
                word_count=len(content.split()),
                regeneration_reason=f"rollback_to_v{target_version}",
                parent_version=target_metadata.parent_version,
                status="active",
                file_path=str(current_file),
                quality_score=target_metadata.quality_score,
            )

            chapter_key = f"chapter_{chapter_number:03d}"

            if not hasattr(self.draft_manager, "_metadata"):
                self.draft_manager._metadata = {}

            if chapter_key not in self.draft_manager._metadata:
                self.draft_manager._metadata[chapter_key] = {
                    "current_version": 0,
                    "total_versions": 0,
                    "versions": {},
                }

            self.draft_manager._metadata[chapter_key]["current_version"] = target_version

            version_key = f"v{target_version:03d}"
            self.draft_manager._metadata[chapter_key]["versions"][version_key] = {
                "timestamp": new_metadata.timestamp.isoformat(),
                "word_count": new_metadata.word_count,
                "status": "active",
                "regeneration_reason": new_metadata.regeneration_reason,
                "parent_version": new_metadata.parent_version,
                "quality_score": new_metadata.quality_score,
                "suffix": "rollback",
            }

            self.draft_manager._save_metadata()

    def batch_rollback(
        self,
        chapter_numbers: List[int],
        target_version: int,
        create_backup: bool = True,
        force: bool = False,
    ) -> List[RollbackResult]:
        results = []

        for chapter_number in chapter_numbers:
            result = self.rollback(chapter_number, target_version, create_backup, force)
            results.append(result)

        return results

    def list_backups(self, chapter_number: int) -> List[Dict[str, Any]]:
        chapter_dir = self.project_dir / "chapters" / f"chapter_{chapter_number:03d}"
        backup_dir = chapter_dir / "backups"

        if not backup_dir.exists():
            return []

        backups = []
        for backup_file in backup_dir.glob("*.md"):
            stat = backup_file.stat()

            backups.append(
                {
                    "filename": backup_file.name,
                    "path": str(backup_file),
                    "size": stat.st_size,
                    "created": datetime.fromtimestamp(stat.st_ctime),
                }
            )

        return sorted(backups, key=lambda x: x["created"], reverse=True)

    def delete_backup(self, chapter_number: int, backup_filename: str) -> bool:
        chapter_dir = self.project_dir / "chapters" / f"chapter_{chapter_number:03d}"
        backup_dir = chapter_dir / "backups"
        backup_file = backup_dir / backup_filename

        if backup_file.exists():
            backup_file.unlink()
            return True

        return False

    def cleanup_old_backups(self, chapter_number: int, keep_recent: int = 5) -> int:
        backups = self.list_backups(chapter_number)

        if len(backups) <= keep_recent:
            return 0

        backups_to_delete = backups[keep_recent:]
        deleted_count = 0

        for backup in backups_to_delete:
            if self.delete_backup(chapter_number, backup["filename"]):
                deleted_count += 1

        return deleted_count
