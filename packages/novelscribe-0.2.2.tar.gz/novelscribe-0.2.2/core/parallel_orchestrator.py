"""
Parallel Orchestrator for Novel Generation

This module integrates parallelism components with the orchestrator
to enable parallel execution of agent phases.
"""

import time
from dataclasses import dataclass
from enum import Enum
from typing import Any, Callable, Dict, List, Optional

from core.agent_queue import AgentQueue, AgentTask, TaskStatus
from core.async_executor import AsyncAgentExecutor
from core.phase_parallelizer import PhaseDependency, PhaseGroup, PhaseParallelizer


class ExecutionMode(str, Enum):
    """Execution mode for orchestrator"""

    SEQUENTIAL = "sequential"
    PARALLEL = "parallel"
    AUTO = "auto"  # Automatically detect parallelizable phases


@dataclass
class ParallelConfig:
    """Configuration for parallel execution"""

    enabled: bool = False
    max_concurrent: int = 3
    execution_mode: ExecutionMode = ExecutionMode.AUTO
    timeout_per_phase: int = 300
    enable_progress: bool = True

    @classmethod
    def from_dict(cls, config: Dict[str, Any]) -> "ParallelConfig":
        """Create config from dictionary"""
        return cls(
            enabled=config.get("enabled", False),
            max_concurrent=config.get("max_concurrent", 3),
            execution_mode=ExecutionMode(config.get("execution_mode", "auto")),
            timeout_per_phase=config.get("timeout_per_phase", 300),
            enable_progress=config.get("enable_progress", True),
        )


@dataclass
class PhaseResult:
    """Result of phase execution"""

    phase_name: str
    agent_name: str
    success: bool
    output: Optional[str] = None
    error: Optional[str] = None
    duration: float = 0.0
    parallel_group: int = 0


@dataclass
class OrchestrationResult:
    """Result of orchestration execution"""

    success: bool
    phase_results: Dict[str, PhaseResult]
    total_duration: float
    parallel_speedup: Optional[float] = None
    phases_executed: int = 0
    phases_failed: int = 0

    @property
    def failed_phases(self) -> List[str]:
        """Get list of failed phase names"""
        return [name for name, result in self.phase_results.items() if not result.success]


class ParallelOrchestrator:
    """
    Orchestrator with parallel execution support

    Features:
    - Seamless integration with existing orchestrator
    - Parallel execution of independent phases
    - Configurable concurrency
    - Progress tracking
    - Performance metrics

    Usage:
        orchestrator = ParallelOrchestrator(config)

        result = await orchestrator.execute_phases(
            phases=["discuss", "genre", "characters", "world"],
            executor_func=my_agent_executor,
            parallel=True
        )
    """

    def __init__(self, config: Optional[ParallelConfig] = None):
        self.config = config or ParallelConfig()
        self.phase_parallelizer = PhaseParallelizer()
        self.agent_executor = AsyncAgentExecutor(max_concurrent=self.config.max_concurrent)

        # Metrics
        self.metrics: Dict[str, Any] = {
            "total_executions": 0,
            "parallel_executions": 0,
            "sequential_executions": 0,
            "total_duration": 0.0,
            "avg_speedup": 0.0,
        }

    def configure(self, config: ParallelConfig) -> None:
        """Update configuration"""
        self.config = config
        self.agent_executor = AsyncAgentExecutor(max_concurrent=config.max_concurrent)

    async def execute_phases(
        self,
        phases: List[PhaseDependency],
        executor_func: Callable,
        parallel: Optional[bool] = None,
        progress_callback: Optional[Callable[[str, float], None]] = None,
    ) -> OrchestrationResult:
        """
        Execute phases with optional parallelization

        Args:
            phases: List of phases to execute
            executor_func: Agent executor function
            parallel: Force parallel/sequential (None = auto)
            progress_callback: Optional progress callback

        Returns:
            OrchestrationResult with all phase results
        """
        start_time = time.time()

        # Determine execution mode
        if parallel is None:
            parallel = self._should_parallelize(phases)

        if parallel:
            result = await self._execute_parallel(phases, executor_func, progress_callback)
            self.metrics["parallel_executions"] += 1
        else:
            result = await self._execute_sequential(phases, executor_func, progress_callback)
            self.metrics["sequential_executions"] += 1

        # Calculate metrics
        result.total_duration = time.time() - start_time
        self._update_metrics(result)

        return result

    def _should_parallelize(self, phases: List[PhaseDependency]) -> bool:
        """Determine if phases should be parallelized"""
        if self.config.execution_mode == ExecutionMode.SEQUENTIAL:
            return False
        if self.config.execution_mode == ExecutionMode.PARALLEL:
            return True

        # AUTO mode: parallelize if there are independent phases
        return self._has_parallelizable_phases(phases)

    def _has_parallelizable_phases(self, phases: List[PhaseDependency]) -> bool:
        """Check if there are phases that can run in parallel"""
        # Add phases to parallelizer
        self.phase_parallelizer.clear_phases()
        self.phase_parallelizer.add_phase_batch(phases)

        # Analyze
        groups = self.phase_parallelizer.analyze_dependencies()

        # Check if any group has multiple phases
        return any(len(g.phases) > 1 for g in groups)

    async def _execute_parallel(
        self,
        phases: List[PhaseDependency],
        executor_func: Callable,
        progress_callback: Optional[Callable[[str, float], None]],
    ) -> OrchestrationResult:
        """Execute phases in parallel"""
        # Setup parallelizer
        self.phase_parallelizer.clear_phases()
        self.phase_parallelizer.add_phase_batch(phases)

        # Analyze dependencies
        groups = self.phase_parallelizer.analyze_dependencies()

        # Execute groups in order
        phase_results = {}
        phases_executed = 0
        phases_failed = 0

        for i, group in enumerate(groups):
            progress = (i / len(groups)) * 100

            if group.can_parallel_execute:
                # Parallel execution within group
                results = await self._execute_parallel_group(group, executor_func)
                phase_results.update(results)
            else:
                # Sequential execution
                result = await self._execute_phase(group.phases[0], executor_func)
                phase_results[result.phase_name] = result

            # Update progress
            if progress_callback:
                progress_callback(f"Group {i + 1}/{len(groups)}", progress)

        # Check for failures
        for name, result in phase_results.items():
            if result.success:
                phases_executed += 1
            else:
                phases_failed += 1

        return OrchestrationResult(
            success=phases_failed == 0,
            phase_results=phase_results,
            total_duration=0.0,  # Will be set by caller
            phases_executed=phases_executed,
            phases_failed=phases_failed,
        )

    async def _execute_parallel_group(
        self, group: PhaseGroup, executor_func: Callable
    ) -> Dict[str, PhaseResult]:
        """Execute a group of phases in parallel"""
        # Create tasks
        tasks = []
        for phase in group.phases:
            task = AgentTask(
                task_id=phase.phase_name,
                agent_name=phase.agent_name,
                prompt=phase.prompt_template,
                priority=phase.priority,
                timeout=self.config.timeout_per_phase,
            )
            tasks.append(task)

        # Execute in parallel
        async def wrapped_executor(name: str, prompt: str, **kwargs):
            return await executor_func(name, prompt)

        queue = AgentQueue(max_concurrent=self.config.max_concurrent)
        task_results = await queue.execute_parallel(tasks, wrapped_executor)

        # Convert to PhaseResult
        results = {}
        for task_id, task_result in task_results.items():
            phase = next(p for p in group.phases if p.phase_name == task_id)

            results[task_id] = PhaseResult(
                phase_name=phase.phase_name,
                agent_name=phase.agent_name,
                success=task_result.status == TaskStatus.COMPLETED,
                output=task_result.result,
                error=task_result.error,
                duration=task_result.duration or 0.0,
                parallel_group=group.group_id,
            )

        return results

    async def _execute_sequential(
        self,
        phases: List[PhaseDependency],
        executor_func: Callable,
        progress_callback: Optional[Callable[[str, float], None]],
    ) -> OrchestrationResult:
        """Execute phases sequentially"""
        phase_results = {}
        phases_executed = 0
        phases_failed = 0

        for i, phase in enumerate(phases):
            result = await self._execute_phase(phase, executor_func)
            phase_results[result.phase_name] = result

            if result.success:
                phases_executed += 1
            else:
                phases_failed += 1

            # Update progress
            if progress_callback:
                progress = ((i + 1) / len(phases)) * 100
                progress_callback(phase.phase_name, progress)

        return OrchestrationResult(
            success=phases_failed == 0,
            phase_results=phase_results,
            total_duration=0.0,
            phases_executed=phases_executed,
            phases_failed=phases_failed,
        )

    async def _execute_phase(self, phase: PhaseDependency, executor_func: Callable) -> PhaseResult:
        """Execute a single phase"""
        start_time = time.time()

        try:
            output = await executor_func(phase.agent_name, phase.prompt_template)
            duration = time.time() - start_time

            return PhaseResult(
                phase_name=phase.phase_name,
                agent_name=phase.agent_name,
                success=True,
                output=output,
                duration=duration,
                parallel_group=phase.parallel_group,
            )
        except Exception as e:
            duration = time.time() - start_time
            return PhaseResult(
                phase_name=phase.phase_name,
                agent_name=phase.agent_name,
                success=False,
                error=str(e),
                duration=duration,
                parallel_group=phase.parallel_group,
            )

    def _update_metrics(self, result: OrchestrationResult) -> None:
        """Update execution metrics"""
        self.metrics["total_executions"] += 1
        self.metrics["total_duration"] += result.total_duration

        # Calculate average speedup
        if self.metrics["parallel_executions"] > 0:
            total = self.metrics["total_duration"]
            parallel = self.metrics["parallel_executions"]
            self.metrics["avg_speedup"] = total / parallel if parallel > 0 else 1.0

    def get_metrics(self) -> Dict[str, Any]:
        """Get execution metrics"""
        return self.metrics.copy()

    def reset_metrics(self) -> None:
        """Reset metrics"""
        self.metrics = {
            "total_executions": 0,
            "parallel_executions": 0,
            "sequential_executions": 0,
            "total_duration": 0.0,
            "avg_speedup": 0.0,
        }

    def get_execution_plan(self, phases: List[PhaseDependency]) -> str:
        """
        Get execution plan for phases

        Args:
            phases: Phases to plan

        Returns:
            Human-readable execution plan
        """
        self.phase_parallelizer.clear_phases()
        self.phase_parallelizer.add_phase_batch(phases)
        return self.phase_parallelizer.get_execution_plan()


# Global orchestrator instance
_orchestrator: Optional[ParallelOrchestrator] = None


def get_parallel_orchestrator(config: Optional[ParallelConfig] = None) -> ParallelOrchestrator:
    """Get or create global parallel orchestrator"""
    global _orchestrator
    if _orchestrator is None:
        _orchestrator = ParallelOrchestrator(config)
    return _orchestrator


def reset_parallel_orchestrator() -> None:
    """Reset global orchestrator"""
    global _orchestrator
    _orchestrator = None
