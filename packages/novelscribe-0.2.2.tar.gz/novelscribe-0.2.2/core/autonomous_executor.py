"""Autonomous workflow executor for end-to-end novel generation."""

import logging
from pathlib import Path
from typing import Optional

from pydantic import BaseModel

from core.checkpoint_manager import CheckpointManager
from core.git_manager import create_git_manager
from core.human_checkpoint import CheckpointType, HumanCheckpoint, HumanCheckpointHandler
from core.llm_client import LLMConfig, OpenAIClient
from core.orchestrator_agent_integration import AgentSystemIntegration
from core.progress_tracker import ExecutionStatus, ProgressTracker
from core.storage import StorageBackend, StorageConfig, StorageFactory
from core.workflow_executor import WorkflowExecutor


class AutonomousConfig(BaseModel):
    """Autonomous executor configuration.

    Attributes:
        project_name: Name of the project
        start_phase: Starting phase name
        end_phase: Ending phase name
        human_in_loop: Enable human-in-the-loop checkpoints
        max_chapters: Maximum number of chapters to write (None for unlimited)
        provider: LLM provider to use
    """

    project_name: str
    start_phase: str = "new_novel"
    end_phase: str = "verification_phase"
    human_in_loop: bool = False
    max_chapters: Optional[int] = None
    provider: str = "openai"


class AutonomousResult(BaseModel):
    """Result of autonomous execution.

    Attributes:
        success: Whether execution completed successfully
        completed_phases: List of completed phase names
        final_status: Final execution status
        error: Optional error message if failed
        checkpoint_id: Optional checkpoint ID if paused
    """

    success: bool
    completed_phases: list[str]
    final_status: ExecutionStatus
    error: Optional[str] = None
    checkpoint_id: Optional[str] = None


class AutonomousExecutor:
    """Autonomous workflow executor.

    Executes complete workflow chain from start to finish with
    progress tracking, checkpointing, and optional human-in-the-loop
    checkpoints.
    """

    WORKFLOW_CHAIN = [
        "new_novel",
        "worldbuilding_phase",
        "character_phase",
        "outline_phase",
        "chapter_plan_phase",
        "writing_phase",
        "continuity_phase",
        "verification_phase",
    ]

    HUMAN_CHECKPOINTS = [
        HumanCheckpoint(
            phase="outline_phase",
            type=CheckpointType.APPROVAL,
            message="Review generated outline. Approve to continue?",
        ),
        HumanCheckpoint(
            phase="character_phase",
            type=CheckpointType.INPUT,
            message="Enter any additional character requirements:",
            required=False,
        ),
        HumanCheckpoint(
            phase="chapter_plan_phase",
            type=CheckpointType.APPROVAL,
            message="Review chapter plan. Approve to continue writing?",
        ),
    ]

    def __init__(
        self,
        config: AutonomousConfig,
        storage_path: Path,
    ):
        """Initialize autonomous executor.

        Args:
            config: Autonomous executor configuration
            storage_path: Base storage path for project files
        """
        self.config = config
        self.storage_path = storage_path
        self.logger = logging.getLogger("scribe")

        project_path = storage_path / config.project_name
        storage_config = StorageConfig(base_path=str(project_path))
        storage: StorageBackend = StorageFactory.create(storage_config)

        self.llm_config = LLMConfig(provider=config.provider)
        llm_client = OpenAIClient(self.llm_config)

        agents_dir = Path("agents")
        self.agent_integration = AgentSystemIntegration(
            agents_dir=str(agents_dir),
            llm_client=llm_client,
            storage=storage,
            work_dir=str(project_path),
        )

        workflows_dir = Path("workflows")
        self.git_manager = create_git_manager(project_path, auto_commit=True)

        self.workflow_executor = WorkflowExecutor(
            workflows_dir=str(workflows_dir),
            agent_integration=self.agent_integration,
            storage=storage,
            git_manager=self.git_manager,
            work_dir=str(project_path),
        )

        self.progress_tracker = ProgressTracker(config.project_name, project_path)
        self.checkpoint_manager = CheckpointManager(config.project_name, project_path)
        self.human_handler = HumanCheckpointHandler(enabled=config.human_in_loop)

    def execute(self, resume: bool = False) -> AutonomousResult:
        """Execute autonomous pipeline.

        Args:
            resume: Whether to resume from latest checkpoint

        Returns:
            Execution result
        """
        try:
            if resume:
                return self._resume_from_checkpoint()

            return self._execute_full_pipeline()

        except Exception as e:
            self.logger.error(f"Autonomous execution failed: {e}")
            self.progress_tracker.set_status(ExecutionStatus.FAILED, str(e))

            state = self.progress_tracker.get_state()
            completed: list[str] = state.completed_phases if state else []

            return AutonomousResult(
                success=False,
                completed_phases=completed,
                final_status=ExecutionStatus.FAILED,
                error=str(e),
            )

    def _execute_full_pipeline(self) -> AutonomousResult:
        """Execute full autonomous pipeline.

        Returns:
            Execution result
        """
        self.logger.info(f"🚀 Starting autonomous pipeline for '{self.config.project_name}'")

        total_steps = len(self.WORKFLOW_CHAIN)
        self.progress_tracker.initialize(total_steps, self.config.start_phase)

        completed_phases: list[str] = []
        execution_context: dict[str, str] = {"project_name": self.config.project_name}

        start_index = self._get_workflow_index(self.config.start_phase)
        end_index = self._get_workflow_index(self.config.end_phase)

        for i in range(start_index, end_index + 1):
            workflow_name = self.WORKFLOW_CHAIN[i]

            if workflow_name == "new_novel" and self.config.start_phase != "new_novel":
                continue

            self.progress_tracker.update_phase(workflow_name)

            self.logger.info(f"→ Executing phase: {workflow_name}")

            if self.human_handler.should_pause_at_phase(workflow_name, self.HUMAN_CHECKPOINTS):
                checkpoint = self.human_handler.get_checkpoint_for_phase(
                    workflow_name, self.HUMAN_CHECKPOINTS
                )

                if checkpoint:
                    decision = self.human_handler.handle_checkpoint(checkpoint)

                    if not decision.approved:
                        self.logger.info("Execution stopped by user")
                        self.progress_tracker.set_status(ExecutionStatus.PAUSED)

                        return AutonomousResult(
                            success=False,
                            completed_phases=completed_phases,
                            final_status=ExecutionStatus.PAUSED,
                            error="Stopped by user at checkpoint",
                        )

                    if decision.input:
                        execution_context["user_input"] = decision.input

                    if decision.modifications:
                        execution_context.update(decision.modifications)

            try:
                result = self.workflow_executor.execute_workflow(
                    workflow_name=workflow_name,
                    project_name=self.config.project_name,
                    variables=execution_context,
                    config=self.llm_config.model_dump(),
                )

                if not result.get("success"):
                    self.logger.warning(f"⚠️  Workflow '{workflow_name}' completed with warnings")

                completed_phases.append(workflow_name)
                self.progress_tracker.complete_phase(workflow_name)

                state = self.progress_tracker.get_state()
                if state is None:
                    raise RuntimeError("Progress state is None after completing phase")

                self.checkpoint_manager.create_checkpoint(
                    completed_workflows=completed_phases,
                    current_workflow=None,
                    execution_context=execution_context,
                    progress_state=state,
                )

                self.git_manager.auto_commit_step(
                    agent="autonomous",
                    description=f"Complete {workflow_name}",
                )

            except Exception as e:
                self.logger.error(f"Failed to execute workflow '{workflow_name}': {e}")
                raise

        self.progress_tracker.set_status(ExecutionStatus.COMPLETED)
        self.logger.info(
            f"✅ Autonomous pipeline completed successfully for '{self.config.project_name}'"
        )

        return AutonomousResult(
            success=True,
            completed_phases=completed_phases,
            final_status=ExecutionStatus.COMPLETED,
        )

    def _resume_from_checkpoint(self) -> AutonomousResult:
        """Resume execution from checkpoint.

        Returns:
            Execution result
        """
        self.logger.info(f"🔄 Resuming autonomous pipeline for '{self.config.project_name}'")

        checkpoint = self.checkpoint_manager.load_checkpoint()

        if not checkpoint:
            self.logger.error("No checkpoint found to resume from")
            return AutonomousResult(
                success=False,
                completed_phases=[],
                final_status=ExecutionStatus.FAILED,
                error="No checkpoint found",
            )

        if not self.checkpoint_manager.validate_checkpoint(checkpoint):
            self.logger.error("Invalid checkpoint")
            return AutonomousResult(
                success=False,
                completed_phases=[],
                final_status=ExecutionStatus.FAILED,
                error="Invalid checkpoint",
            )

        self.progress_tracker._state = checkpoint.progress_state
        self.progress_tracker.set_status(ExecutionStatus.RUNNING)

        completed_phases: list[str] = checkpoint.completed_workflows
        execution_context: dict[str, str] = checkpoint.execution_context

        last_completed = completed_phases[-1] if completed_phases else None
        start_index = self._get_workflow_index(last_completed) + 1 if last_completed else 0
        end_index = self._get_workflow_index(self.config.end_phase)

        for i in range(start_index, end_index + 1):
            workflow_name = self.WORKFLOW_CHAIN[i]

            self.progress_tracker.update_phase(workflow_name)

            self.logger.info(f"→ Executing phase: {workflow_name}")

            result = self.workflow_executor.execute_workflow(
                workflow_name=workflow_name,
                project_name=self.config.project_name,
                variables=execution_context,
                config=self.llm_config.model_dump(),
            )

            if not result.get("success"):
                self.logger.warning(f"⚠️  Workflow '{workflow_name}' completed with warnings")

            completed_phases.append(workflow_name)
            self.progress_tracker.complete_phase(workflow_name)

            state = self.progress_tracker.get_state()
            if state is None:
                raise RuntimeError("Progress state is None after completing phase")

            self.checkpoint_manager.create_checkpoint(
                completed_workflows=completed_phases,
                current_workflow=None,
                execution_context=execution_context,
                progress_state=state,
            )

        self.progress_tracker.set_status(ExecutionStatus.COMPLETED)
        self.logger.info("✅ Resumed pipeline completed successfully")

        return AutonomousResult(
            success=True,
            completed_phases=completed_phases,
            final_status=ExecutionStatus.COMPLETED,
        )

    def _get_workflow_index(self, workflow_name: str) -> int:
        """Get index of workflow in chain.

        Args:
            workflow_name: Workflow name

        Returns:
            Workflow index

        Raises:
            ValueError: If workflow not found in chain
        """
        try:
            return self.WORKFLOW_CHAIN.index(workflow_name)
        except ValueError:
            raise ValueError(f"Unknown workflow: {workflow_name}")
