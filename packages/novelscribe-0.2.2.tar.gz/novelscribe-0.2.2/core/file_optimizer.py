"""File I/O optimization utilities."""

import gzip
from dataclasses import dataclass
from pathlib import Path


@dataclass
class FileOptimizerStats:
    """Statistics for file optimizer."""

    cache_hits: int = 0
    cache_misses: int = 0
    writes_cached: int = 0
    compressed_files: int = 0
    total_bytes_read: int = 0
    total_bytes_written: int = 0
    reads: int = 0
    writes: int = 0
    bytes_read: int = 0
    bytes_written: int = 0


class FileOptimizer:
    """File I/O optimizer with buffering and caching."""

    DEFAULT_WRITE_CACHE_SIZE = 8192

    def __init__(
        self,
        buffer_size: int = 8192,
        write_cache_size: int = DEFAULT_WRITE_CACHE_SIZE,
        enable_compression: bool = True,
        compression_threshold: int = 1024,
    ):
        self.buffer_size = buffer_size
        self.write_cache_size = write_cache_size
        self.enable_compression = enable_compression
        self.compression_threshold = compression_threshold
        self._read_cache: dict[str, str] = {}
        self._write_cache: dict[str, str] = {}
        self._stats = FileOptimizerStats()

    def write_file(self, path: str, content: str, immediate: bool = True) -> None:
        """Write file to disk."""
        file_path = Path(path)
        self._stats.writes += 1

        if immediate:
            file_path.write_text(content)
            if self.enable_compression and len(content) > self.compression_threshold:
                with gzip.open(str(file_path) + ".gz", "wt") as f:
                    f.write(content)
                self._stats.compressed_files += 1
            self._stats.total_bytes_written += len(content)
            self._stats.bytes_written += len(content)
        else:
            self._write_cache[path] = content
            self._stats.writes_cached += 1

    def read_file(self, path: str) -> str:
        """Read file from disk."""
        file_path = Path(path)
        self._stats.reads += 1

        if path in self._read_cache:
            self._stats.cache_hits += 1
            return self._read_cache[path]

        self._stats.cache_misses += 1

        gz_path = Path(str(file_path) + ".gz")
        if gz_path.exists():
            with gzip.open(gz_path, "rt") as f:
                content = f.read()
        else:
            content = file_path.read_text()

        self._read_cache[path] = content
        self._stats.total_bytes_read += len(content)
        self._stats.bytes_read += len(content)
        return content

    def flush_all(self) -> None:
        """Flush all cached writes to disk."""
        for path, content in self._write_cache.items():
            self.write_file(path, content, immediate=True)
        self._write_cache.clear()

    def clear_cache(self) -> None:
        """Clear all caches."""
        self._read_cache.clear()
        self._write_cache.clear()

    def get_stats(self) -> FileOptimizerStats:
        """Get optimizer statistics."""
        from copy import deepcopy

        return deepcopy(self._stats)

    def get_cache_info(self) -> dict[str, int]:
        """Get cache information."""
        return {"cached_files": len(self._read_cache)}

    def delete_file(self, path: str) -> None:
        """Delete a file."""
        file_path = Path(path)
        if file_path.exists():
            file_path.unlink()
        if path in self._read_cache:
            del self._read_cache[path]

        gz_path = Path(str(file_path) + ".gz")
        if gz_path.exists():
            gz_path.unlink()


# Global instance
_file_optimizer_instance = None


def get_file_optimizer() -> FileOptimizer:
    """Get the global file optimizer instance."""
    global _file_optimizer_instance
    if _file_optimizer_instance is None:
        _file_optimizer_instance = FileOptimizer()
    return _file_optimizer_instance
