"""Draft version management system for chapter regeneration."""

import json
import shutil
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field


class DraftStatus(str, Enum):
    DRAFT = "draft"
    ACTIVE = "active"
    ARCHIVED = "archived"


class DraftManagerConfig(BaseModel):
    enable_versioning: bool = Field(
        default=True, description="Enable/disable version history management"
    )
    max_versions_per_chapter: int = Field(
        default=10, description="Maximum versions to keep per chapter"
    )
    auto_archive: bool = Field(default=True, description="Auto-archive old versions")


class DraftMetadata(BaseModel):
    chapter_number: int
    version: int
    timestamp: datetime
    word_count: int
    regeneration_reason: Optional[str] = None
    parent_version: Optional[int] = None
    status: DraftStatus
    file_path: str
    quality_score: Optional[float] = None


class DraftVersion(BaseModel):
    metadata: DraftMetadata
    content: str
    issues_fixed: List[str] = Field(default_factory=list)


class DraftManager:
    def __init__(
        self,
        project_dir: str,
        config: Optional[DraftManagerConfig] = None,
    ):
        self.project_dir = Path(project_dir)
        self.config = config or DraftManagerConfig()
        self.metadata_file = self.project_dir / "draft_metadata.json"
        self._metadata: Dict[str, Dict[str, Any]] = {}
        self._load_metadata()

    def is_versioning_enabled(self) -> bool:
        return self.config.enable_versioning

    def _load_metadata(self) -> None:
        if self.metadata_file.exists():
            with open(self.metadata_file, "r") as f:
                self._metadata = json.load(f)

    def _save_metadata(self) -> None:
        self.metadata_file.parent.mkdir(parents=True, exist_ok=True)
        with open(self.metadata_file, "w") as f:
            json.dump(self._metadata, f, indent=2, default=str)

    def _get_chapter_key(self, chapter_number: int) -> str:
        return f"chapter_{chapter_number:03d}"

    def _get_chapter_dir(self, chapter_number: int) -> Path:
        chapter_key = self._get_chapter_key(chapter_number)
        return self.project_dir / "chapters" / chapter_key

    def _get_drafts_dir(self, chapter_number: int) -> Path:
        chapter_dir = self._get_chapter_dir(chapter_number)
        drafts_dir = chapter_dir / "drafts"
        drafts_dir.mkdir(parents=True, exist_ok=True)
        return drafts_dir

    def _get_current_file(self, chapter_number: int) -> Path:
        chapter_dir = self._get_chapter_dir(chapter_number)
        return chapter_dir / "current.md"

    def _get_draft_file(
        self, chapter_number: int, version: int, suffix: Optional[str] = None
    ) -> Path:
        drafts_dir = self._get_drafts_dir(chapter_number)
        if suffix is None:
            suffix = self._get_version_suffix(chapter_number, version)
        return drafts_dir / f"v{version:03d}_{suffix}.md"

    def _get_version_suffix(self, chapter_number: int, version: int) -> str:
        chapter_key = self._get_chapter_key(chapter_number)
        if chapter_key in self._metadata:
            version_info = (
                self._metadata[chapter_key].get("versions", {}).get(f"v{version:03d}", {})
            )
            return version_info.get("suffix", "draft")
        return "draft"

    def initialize_chapter(
        self, chapter_number: int, initial_content: str, reason: str = "initial"
    ) -> DraftMetadata:
        chapter_key = self._get_chapter_key(chapter_number)

        if not self.config.enable_versioning:
            current_file = self._get_current_file(chapter_number)
            current_file.parent.mkdir(parents=True, exist_ok=True)
            current_file.write_text(initial_content)
            return DraftMetadata(
                chapter_number=chapter_number,
                version=1,
                timestamp=datetime.now(),
                word_count=len(initial_content.split()),
                regeneration_reason=reason,
                parent_version=None,
                status=DraftStatus.ACTIVE,
                file_path=str(current_file),
            )

        if chapter_key not in self._metadata:
            self._metadata[chapter_key] = {
                "current_version": 0,
                "total_versions": 0,
                "versions": {},
            }

        current_version = self._metadata[chapter_key]["current_version"]

        if current_version > 0:
            self._archive_current_version(chapter_number)

        new_version = current_version + 1

        metadata = DraftMetadata(
            chapter_number=chapter_number,
            version=new_version,
            timestamp=datetime.now(),
            word_count=len(initial_content.split()),
            regeneration_reason=reason,
            parent_version=current_version if current_version > 0 else None,
            status=DraftStatus.ACTIVE,
            file_path=str(self._get_current_file(chapter_number)),
        )

        self._save_draft_content(chapter_number, new_version, initial_content, metadata)
        self._set_current_version(chapter_number, new_version, metadata)

        return metadata

    def create_new_version(
        self,
        chapter_number: int,
        content: str,
        reason: str,
        quality_score: Optional[float] = None,
        issues_fixed: List[str] = [],
    ) -> DraftMetadata:
        current_file = self._get_current_file(chapter_number)

        if not self.config.enable_versioning:
            current_file.parent.mkdir(parents=True, exist_ok=True)
            current_file.write_text(content)

            chapter_key = self._get_chapter_key(chapter_number)
            if chapter_key not in self._metadata:
                self._metadata[chapter_key] = {
                    "current_version": 1,
                    "total_versions": 1,
                    "versions": {},
                }
            else:
                current_ver = self._metadata[chapter_key]["current_version"]
                self._metadata[chapter_key]["current_version"] = current_ver + 1

            return DraftMetadata(
                chapter_number=chapter_number,
                version=1,
                timestamp=datetime.now(),
                word_count=len(content.split()),
                regeneration_reason=reason,
                parent_version=None,
                status=DraftStatus.ACTIVE,
                file_path=str(current_file),
                quality_score=quality_score,
            )

        chapter_key = self._get_chapter_key(chapter_number)

        if chapter_key not in self._metadata:
            raise ValueError(f"Chapter {chapter_number} not initialized")

        current_version = self._metadata[chapter_key]["current_version"]

        self._archive_current_version(chapter_number)

        new_version = current_version + 1

        metadata = DraftMetadata(
            chapter_number=chapter_number,
            version=new_version,
            timestamp=datetime.now(),
            word_count=len(content.split()),
            regeneration_reason=reason,
            parent_version=current_version,
            status=DraftStatus.ACTIVE,
            file_path=str(current_file),
            quality_score=quality_score,
        )

        self._save_draft_content(chapter_number, new_version, content, metadata, issues_fixed)
        self._set_current_version(chapter_number, new_version, metadata)

        return metadata

    def _save_draft_content(
        self,
        chapter_number: int,
        version: int,
        content: str,
        metadata: DraftMetadata,
        issues_fixed: List[str] = [],
    ) -> None:
        draft_file = self._get_draft_file(
            chapter_number, version, self._generate_suffix(metadata.regeneration_reason)
        )
        draft_file.write_text(content)

    def _archive_current_version(self, chapter_number: int) -> None:
        current_file = self._get_current_file(chapter_number)

        if not current_file.exists():
            return

        chapter_key = self._get_chapter_key(chapter_number)
        current_version = self._metadata[chapter_key]["current_version"]

        if current_version == 0:
            return

        drafts_dir = self._get_drafts_dir(chapter_number)
        version_suffix = self._get_version_suffix(chapter_number, current_version)
        archive_file = drafts_dir / f"v{current_version:03d}_{version_suffix}.md"

        shutil.copy2(current_file, archive_file)

    def _set_current_version(
        self, chapter_number: int, version: int, metadata: DraftMetadata
    ) -> None:
        chapter_key = self._get_chapter_key(chapter_number)

        self._metadata[chapter_key]["current_version"] = version
        self._metadata[chapter_key]["total_versions"] = max(
            self._metadata[chapter_key]["total_versions"], version
        )

        version_key = f"v{version:03d}"
        self._metadata[chapter_key]["versions"][version_key] = {
            "timestamp": metadata.timestamp.isoformat(),
            "word_count": metadata.word_count,
            "status": metadata.status.value,
            "regeneration_reason": metadata.regeneration_reason,
            "parent_version": metadata.parent_version,
            "quality_score": metadata.quality_score,
            "suffix": self._generate_suffix(metadata.regeneration_reason),
        }

        self._save_metadata()

    def _generate_suffix(self, reason: Optional[str]) -> str:
        if not reason:
            return "draft"

        suffix_map = {
            "initial": "initial",
            "fix_continuity": "continuity_fix",
            "style_improvement": "style_update",
            "regeneration": "regen",
            "manual_edit": "manual",
        }

        return suffix_map.get(reason.lower().replace(" ", "_"), "custom")

    def get_current_version(self, chapter_number: int) -> Optional[DraftMetadata]:
        chapter_key = self._get_chapter_key(chapter_number)

        if chapter_key not in self._metadata:
            return None

        current_version = self._metadata[chapter_key]["current_version"]
        return self.get_version(chapter_number, current_version)

    def get_version(self, chapter_number: int, version: int) -> Optional[DraftMetadata]:
        chapter_key = self._get_chapter_key(chapter_number)

        if chapter_key not in self._metadata:
            return None

        version_key = f"v{version:03d}"
        if version_key not in self._metadata[chapter_key]["versions"]:
            return None

        version_data = self._metadata[chapter_key]["versions"][version_key]

        return DraftMetadata(
            chapter_number=chapter_number,
            version=version,
            timestamp=datetime.fromisoformat(version_data["timestamp"]),
            word_count=version_data["word_count"],
            regeneration_reason=version_data.get("regeneration_reason"),
            parent_version=version_data.get("parent_version"),
            status=DraftStatus(version_data["status"]),
            file_path=str(self._get_draft_file(chapter_number, version)),
            quality_score=version_data.get("quality_score"),
        )

    def list_versions(self, chapter_number: int) -> List[DraftMetadata]:
        chapter_key = self._get_chapter_key(chapter_number)

        if chapter_key not in self._metadata:
            return []

        versions = []
        total_versions = self._metadata[chapter_key]["total_versions"]

        for version in range(1, total_versions + 1):
            metadata = self.get_version(chapter_number, version)
            if metadata:
                versions.append(metadata)

        return sorted(versions, key=lambda x: x.version)

    def get_version_content(self, chapter_number: int, version: int) -> Optional[str]:
        draft_file = self._get_draft_file(chapter_number, version)

        if not draft_file.exists():
            return None

        return draft_file.read_text()

    def delete_version(self, chapter_number: int, version: int) -> bool:
        chapter_key = self._get_chapter_key(chapter_number)

        if chapter_key not in self._metadata:
            return False

        current_version = self._metadata[chapter_key]["current_version"]
        if version == current_version:
            raise ValueError("Cannot delete current version")

        version_key = f"v{version:03d}"
        if version_key not in self._metadata[chapter_key]["versions"]:
            return False

        draft_file = self._get_draft_file(chapter_number, version)
        if draft_file.exists():
            draft_file.unlink()

        del self._metadata[chapter_key]["versions"][version_key]
        self._save_metadata()

        return True

    def archive_old_versions(self, chapter_number: int, keep_recent: int = 5) -> int:
        versions = self.list_versions(chapter_number)

        if len(versions) <= keep_recent:
            return 0

        versions_to_archive = versions[:-keep_recent]
        archived_count = 0

        for version_metadata in versions_to_archive:
            if version_metadata.status == DraftStatus.ACTIVE:
                version_key = f"v{version_metadata.version:03d}"
                chapter_key = self._get_chapter_key(chapter_number)

                self._metadata[chapter_key]["versions"][version_key]["status"] = (
                    DraftStatus.ARCHIVED.value
                )
                archived_count += 1

        if archived_count > 0:
            self._save_metadata()

        return archived_count

    def get_chapter_summary(self, chapter_number: int) -> Dict[str, Any]:
        chapter_key = self._get_chapter_key(chapter_number)

        if chapter_key not in self._metadata:
            return {"chapter_number": chapter_number, "initialized": False}

        versions = self.list_versions(chapter_number)

        return {
            "chapter_number": chapter_number,
            "initialized": True,
            "current_version": self._metadata[chapter_key]["current_version"],
            "total_versions": self._metadata[chapter_key]["total_versions"],
            "word_count": self.get_current_version(chapter_number).word_count if versions else 0,
            "version_count": len(versions),
            "quality_score": versions[-1].quality_score if versions else None,
        }

    def get_project_summary(self) -> Dict[str, Any]:
        summaries = []

        for chapter_key in self._metadata.keys():
            chapter_number = int(chapter_key.split("_")[1])
            summary = self.get_chapter_summary(chapter_number)
            summaries.append(summary)

        return {
            "total_chapters": len(summaries),
            "total_drafts": sum(s["version_count"] for s in summaries),
            "total_words": sum(s["word_count"] for s in summaries),
            "chapters": sorted(summaries, key=lambda x: x["chapter_number"]),
        }

    def get_current_content(self, chapter_number: int) -> Optional[str]:
        """Get current content for a chapter, works regardless of versioning mode."""
        current_file = self._get_current_file(chapter_number)
        if current_file.exists():
            return current_file.read_text()
        return None
