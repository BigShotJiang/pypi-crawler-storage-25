"""Step executor for running workflow steps."""

import logging
from pathlib import Path
from typing import Any, Dict

from .git_manager import GitManager
from .orchestrator_agent_integration import AgentSystemIntegration
from .storage import StorageBackend
from .variable_resolver import VariableResolver
from .workflow_loader import OnFailure, WorkflowStep


class SystemActionHandler:
    """Handle system actions in workflow steps."""

    def __init__(
        self, storage: StorageBackend, git_manager: GitManager, work_dir: str | Path = None
    ):
        """Initialize system action handler.

        Args:
            storage: Storage backend
            git_manager: Git manager
            work_dir: Working directory
        """
        self.storage = storage
        self.git_manager = git_manager
        self.work_dir = Path(work_dir) if work_dir else Path.cwd()
        self.logger = logging.getLogger("system_actions")

    def execute_action(
        self, action: str, input_data: Dict[str, Any], project_name: str
    ) -> Dict[str, Any]:
        """Execute a system action.

        Args:
            action: Action name
            input_data: Action input data
            project_name: Project name

        Returns:
            Action result
        """
        project_dir = self.work_dir / project_name

        handlers = {
            "create_directories": self._create_directories,
            "git_init": self._git_init,
            "git_commit": self._git_commit,
            "git_tag": self._git_tag,
            "load_yaml": self._load_yaml,
            "load_markdown": self._load_markdown,
            "load_previous_chapters": self._load_previous_chapters,
            "load_chapter_range": self._load_chapter_range,
            "load_all_chapters": self._load_all_chapters,
            "check_status": self._check_status,
            "check_issues": self._check_issues,
            "get_chapter_count": self._get_chapter_count,
            "get_target_chapter_count": self._get_target_chapter_count,
            "generate_report": self._generate_report,
            "display_summary": self._display_summary,
        }

        handler = handlers.get(action)

        if not handler:
            self.logger.warning(f"Unknown system action: {action}")
            return {"success": False, "error": f"Unknown action: {action}"}

        try:
            return handler(input_data, project_dir)
        except Exception as e:
            self.logger.error(f"Error executing action {action}: {e}")
            return {"success": False, "error": str(e)}

    def _create_directories(self, input_data: Dict[str, Any], project_dir: Path) -> Dict[str, Any]:
        """Create directories."""
        directories = input_data.get("directories", [])

        for dir_path in directories:
            full_path = project_dir / dir_path
            full_path.mkdir(parents=True, exist_ok=True)

        return {"success": True, "directories_created": True}

    def _git_init(self, input_data: Dict[str, Any], project_dir: Path) -> Dict[str, Any]:
        """Initialize Git repository."""
        self.git_manager.initialize_repository(str(project_dir))
        return {"success": True, "git_initialized": True}

    def _git_commit(self, input_data: Dict[str, Any], project_dir: Path) -> Dict[str, Any]:
        """Create Git commit."""
        message = input_data.get("message", "Workflow step commit")
        self.git_manager.auto_commit_step(str(project_dir), message)
        return {"success": True, "committed": True}

    def _git_tag(self, input_data: Dict[str, Any], project_dir: Path) -> Dict[str, Any]:
        """Create Git tag."""
        tag = input_data.get("tag", "milestone")
        message = input_data.get("message", tag)
        self.git_manager.create_milestone_tag(str(project_dir), tag, message)
        return {"success": True, "tagged": True}

    def _load_yaml(self, input_data: Dict[str, Any], project_dir: Path) -> Dict[str, Any]:
        """Load YAML file."""
        file_path = project_dir / input_data["file"]
        content = self.storage.read_yaml(str(file_path))
        return {"success": True, "meta": content}

    def _load_markdown(self, input_data: Dict[str, Any], project_dir: Path) -> Dict[str, Any]:
        """Load Markdown file."""
        file_path = project_dir / input_data["file"]
        optional = input_data.get("optional", False)

        try:
            content = self.storage.read_markdown(str(file_path))
            return {"success": True, "content": content}
        except Exception:
            if optional:
                return {"success": True, "content": None}
            raise

    def _load_previous_chapters(
        self, input_data: Dict[str, Any], project_dir: Path
    ) -> Dict[str, Any]:
        """Load previous chapters."""
        current_chapter = input_data.get("current_chapter", 1)
        chapters_dir = project_dir / "chapters"

        chapters = []
        for i in range(1, current_chapter):
            chapter_file = chapters_dir / f"chapter_{i}.md"
            if chapter_file.exists():
                content = self.storage.read_markdown(str(chapter_file))
                chapters.append(content)

        return {"success": True, "chapters": "\n\n".join(chapters)}

    def _load_chapter_range(self, input_data: Dict[str, Any], project_dir: Path) -> Dict[str, Any]:
        """Load chapter range."""
        start_chapter = input_data.get("start_chapter", 1)
        end_chapter = input_data.get("end_chapter", 1)
        chapters_dir = project_dir / "chapters"

        chapters = []
        for i in range(start_chapter, end_chapter + 1):
            chapter_file = chapters_dir / f"chapter_{i}.md"
            if chapter_file.exists():
                content = self.storage.read_markdown(str(chapter_file))
                chapters.append(content)

        return {"success": True, "chapters": chapters}

    def _load_all_chapters(self, input_data: Dict[str, Any], project_dir: Path) -> Dict[str, Any]:
        """Load all chapters."""
        count = input_data.get("count", 0)
        return self._load_chapter_range({"start_chapter": 1, "end_chapter": count}, project_dir)

    def _check_status(self, input_data: Dict[str, Any], project_dir: Path) -> Dict[str, Any]:
        """Check status value."""
        status = input_data.get("status", "")
        condition = input_data.get("condition", "")

        result = status == condition if condition else bool(status)

        return {"success": True, "result": result}

    def _check_issues(self, input_data: Dict[str, Any], project_dir: Path) -> Dict[str, Any]:
        """Check for issues."""
        issues = input_data.get("issues", [])
        has_issues = bool(issues)

        return {"success": True, "result": has_issues}

    def _get_chapter_count(self, input_data: Dict[str, Any], project_dir: Path) -> Dict[str, Any]:
        """Get total chapter count."""
        chapters_dir = project_dir / "chapters"

        if not chapters_dir.exists():
            return {"success": True, "count": 0}

        count = len(list(chapters_dir.glob("*.md")))

        return {"success": True, "count": count}

    def _get_target_chapter_count(
        self, input_data: Dict[str, Any], project_dir: Path
    ) -> Dict[str, Any]:
        """Get target chapter count."""
        user_target = input_data.get("user_target")

        if user_target:
            return {"success": True, "count": user_target}

        meta_file = project_dir / "META.yaml"
        if meta_file.exists():
            meta = self.storage.read_yaml(str(meta_file))
            count = meta.get("chapter_count_target", 30)
            return {"success": True, "count": count}

        return {"success": True, "count": 30}

    def _generate_report(self, input_data: Dict[str, Any], project_dir: Path) -> Dict[str, Any]:
        """Generate final report."""
        report = "# Final Report\n\nNovel generation complete.\n"

        report_file = project_dir / "reports" / "final_report.md"
        report_file.parent.mkdir(parents=True, exist_ok=True)

        self.storage.write_markdown(str(report_file), report)

        return {"success": True, "final_report": str(report_file)}

    def _display_summary(self, input_data: Dict[str, Any], project_dir: Path) -> Dict[str, Any]:
        """Display completion summary."""
        print(f"\n✅ Novel generation complete: {project_dir.name}\n")

        return {"success": True, "summary_displayed": True}


class StepExecutor:
    """Execute workflow steps."""

    def __init__(
        self,
        agent_integration: AgentSystemIntegration,
        storage: StorageBackend,
        git_manager: GitManager,
        work_dir: str | Path = None,
    ):
        """Initialize step executor.

        Args:
            agent_integration: Agent system integration
            storage: Storage backend
            git_manager: Git manager
            work_dir: Working directory
        """
        self.agent_integration = agent_integration
        self.storage = storage
        self.git_manager = git_manager
        self.work_dir = Path(work_dir) if work_dir else Path.cwd()
        self.resolver = VariableResolver()
        self.system_handler = SystemActionHandler(storage, git_manager, work_dir)
        self.logger = logging.getLogger("step_executor")

    def execute_step(
        self,
        step: WorkflowStep,
        project_name: str,
        variables: Dict[str, Any],
        step_outputs: Dict[str, Any],
        config: Dict[str, Any],
    ) -> Dict[str, Any]:
        """Execute a workflow step.

        Args:
            step: Step to execute
            project_name: Project name
            variables: Workflow variables
            step_outputs: Outputs from previous steps
            config: LLM configuration

        Returns:
            Step execution result
        """
        try:
            if step.condition:
                condition_met = self.resolver.evaluate_condition(
                    step.condition, variables, step_outputs
                )

                if not condition_met:
                    self.logger.info(f"Skipping step {step.step} ({step.name}): condition not met")
                    return {"step": step.step, "name": step.name, "skipped": True, "success": True}

            resolved_input = self.resolver.resolve_dict(step.input, variables, step_outputs)

            result = {}

            if step.agent:
                result = self._execute_agent_step(step, project_name, resolved_input, config)
            elif step.workflow:
                result = self._execute_workflow_step(
                    step, project_name, resolved_input, variables, config
                )
            elif step.action:
                result = self._execute_system_action(step, project_name, resolved_input)
            else:
                raise ValueError(f"Step must have agent, workflow, or action: {step.name}")

            if not result.get("success") and step.on_failure == OnFailure.STOP:
                raise Exception(f"Step failed and on_failure=stop: {step.name}")

            resolved_output = self.resolver.resolve_dict(
                step.output, variables, {**step_outputs, **result}
            )

            return {
                "step": step.step,
                "name": step.name,
                "success": result.get("success", True),
                "output": resolved_output,
                "skipped": False,
                "error": result.get("error"),
            }

        except Exception as e:
            self.logger.error(f"Error executing step {step.name}: {e}")

            if step.on_failure == OnFailure.STOP:
                raise

            return {
                "step": step.step,
                "name": step.name,
                "success": False,
                "error": str(e),
                "skipped": False,
            }

    def _execute_agent_step(
        self,
        step: WorkflowStep,
        project_name: str,
        input_data: Dict[str, Any],
        config: Dict[str, Any],
    ) -> Dict[str, Any]:
        """Execute agent step.

        Args:
            step: Step to execute
            project_name: Project name
            input_data: Resolved input data
            config: LLM configuration

        Returns:
            Execution result
        """
        return self.agent_integration.execute_agent_step(
            agent_name=step.agent,
            project_name=project_name,
            step_context={"input_data": input_data, "variables": {}, "previous_outputs": {}},
            config=config,
        )

    def _execute_workflow_step(
        self,
        step: WorkflowStep,
        project_name: str,
        input_data: Dict[str, Any],
        variables: Dict[str, Any],
        config: Dict[str, Any],
    ) -> Dict[str, Any]:
        """Execute nested workflow step.

        Args:
            step: Step to execute
            project_name: Project name
            input_data: Resolved input data
            variables: Workflow variables
            config: LLM configuration

        Returns:
            Execution result
        """
        from .workflow_executor import WorkflowExecutor

        executor = WorkflowExecutor(
            workflows_dir=self.work_dir / "workflows",
            agent_integration=self.agent_integration,
            storage=self.storage,
            git_manager=self.git_manager,
            work_dir=self.work_dir,
        )

        merged_variables = {**variables, **input_data}

        result = executor.execute_workflow(
            workflow_name=step.workflow,
            project_name=project_name,
            variables=merged_variables,
            config=config,
        )

        return result

    def _execute_system_action(
        self, step: WorkflowStep, project_name: str, input_data: Dict[str, Any]
    ) -> Dict[str, Any]:
        """Execute system action step.

        Args:
            step: Step to execute
            project_name: Project name
            input_data: Resolved input data

        Returns:
            Execution result
        """
        return self.system_handler.execute_action(
            action=step.action, input_data=input_data, project_name=project_name
        )
