"""
Context Pruner Implementation for Phase 4.3

Provides intelligent context pruning with multiple strategies
to reduce memory usage while maintaining narrative coherence.
"""

import re
from dataclasses import dataclass
from datetime import datetime, timezone
from enum import Enum
from typing import Dict, List, Optional

from pydantic import BaseModel

from core.context_manager import TokenEstimator
from core.llm_client import LLMClient


class PruningStrategy(Enum):
    """Pruning strategy options."""

    CHRONOLOGICAL = "chronological"
    IMPORTANCE = "importance"
    SEMANTIC = "semantic"
    COMPRESSIVE = "compressive"


@dataclass
class KeyElement:
    """A key narrative element extracted from context."""

    element_type: str  # character, location, event, plot_point
    content: str
    importance_score: float
    first_mention: int  # chapter number
    last_mention: int
    mention_count: int = 1

    def touch(self, chapter_number: int):
        """Update last mention and increment count."""
        self.last_mention = chapter_number
        self.mention_count += 1


@dataclass
class PruningResult:
    """Result of pruning operation."""

    pruned_context: str
    original_size_tokens: int
    pruned_size_tokens: int
    reduction_percent: float
    preserved_elements: List[KeyElement]
    removed_summaries: List[str]
    compression_time_seconds: float


class PruningConfig(BaseModel):
    """Configuration for context pruning."""

    strategy: PruningStrategy = PruningStrategy.IMPORTANCE
    target_size_tokens: int = 8000
    preserve_characters: bool = True
    preserve_locations: bool = True
    preserve_plot_points: bool = True
    summary_compression: bool = True
    min_importance_score: float = 0.3
    overlap_tokens: int = 200
    preserve_recent_chapters: int = 3


class ContextPruner:
    """
    Intelligent context pruning system.

    Features:
    - Multiple pruning strategies
    - Key element extraction and preservation
    - Summary compression
    - Importance-based ranking
    - Semantic coherence maintenance
    """

    def __init__(
        self, config: Optional[PruningConfig] = None, llm_client: Optional[LLMClient] = None
    ):
        """
        Initialize context pruner.

        Args:
            config: Pruning configuration
            llm_client: Optional LLM client for semantic pruning
        """
        self.config = config or PruningConfig()
        self.llm_client = llm_client
        self.token_estimator = TokenEstimator()

        self.key_elements: List[KeyElement] = []
        self.chapter_summaries: Dict[int, str] = {}

    def prune_context(self, context: str, max_tokens: Optional[int] = None) -> PruningResult:
        """
        Prune context to target size.

        Args:
            context: Context to prune
            max_tokens: Maximum tokens (uses config if not specified)

        Returns:
            PruningResult with pruned context and metadata
        """
        start_time = datetime.now(timezone.utc)

        target_tokens = max_tokens or self.config.target_size_tokens
        original_tokens = self.token_estimator.estimate_tokens(context)

        if original_tokens <= target_tokens:
            return PruningResult(
                pruned_context=context,
                original_size_tokens=original_tokens,
                pruned_size_tokens=original_tokens,
                reduction_percent=0.0,
                preserved_elements=self.key_elements.copy(),
                removed_summaries=[],
                compression_time_seconds=0.0,
            )

        if self.config.strategy == PruningStrategy.CHRONOLOGICAL:
            pruned = self._prune_chronologically(context, target_tokens)
        elif self.config.strategy == PruningStrategy.IMPORTANCE:
            pruned = self._prune_by_importance(context, target_tokens)
        elif self.config.strategy == PruningStrategy.SEMANTIC:
            pruned = self._prune_semantically(context, target_tokens)
        elif self.config.strategy == PruningStrategy.COMPRESSIVE:
            pruned = self._prune_compressively(context, target_tokens)
        else:
            ratio = target_tokens / original_tokens
            pruned = context[: int(len(context) * ratio)]

        pruned_tokens = self.token_estimator.estimate_tokens(pruned)

        end_time = datetime.now(timezone.utc)
        compression_time = (end_time - start_time).total_seconds()

        return PruningResult(
            pruned_context=pruned,
            original_size_tokens=original_tokens,
            pruned_size_tokens=pruned_tokens,
            reduction_percent=(1 - pruned_tokens / original_tokens) * 100,
            preserved_elements=self.key_elements.copy(),
            removed_summaries=[],
            compression_time_seconds=compression_time,
        )

    def _prune_chronologically(self, context: str, target_tokens: int) -> str:
        """Prune by removing oldest content first."""
        lines = context.split("\n")

        current_tokens = 0
        kept_lines = []

        for line in reversed(lines):
            line_tokens = self.token_estimator.estimate_tokens(line)

            if current_tokens + line_tokens <= target_tokens:
                kept_lines.insert(0, line)
                current_tokens += line_tokens

        return "\n".join(kept_lines)

    def _prune_by_importance(self, context: str, target_tokens: int) -> str:
        """Prune by keeping important elements."""
        key_elements = self.extract_key_elements(context)

        preserved_content = []

        if self.config.preserve_characters:
            char_content = self._get_character_content(key_elements)
            preserved_content.append(char_content)

        if self.config.preserve_locations:
            loc_content = self._get_location_content(key_elements)
            preserved_content.append(loc_content)

        if self.config.preserve_plot_points:
            plot_content = self._get_plot_content(key_elements)
            preserved_content.append(plot_content)

        preserved_text = "\n\n".join(preserved_content)
        preserved_tokens = self.token_estimator.estimate_tokens(preserved_text)

        if preserved_tokens >= target_tokens:
            ratio = target_tokens / preserved_tokens
            return preserved_text[: int(len(preserved_text) * ratio)]

        remaining_tokens = target_tokens - preserved_tokens - self.config.overlap_tokens

        additional_content = self._get_additional_content(
            context, preserved_text, int(remaining_tokens)
        )

        return "\n\n".join([preserved_text, additional_content])

    def _prune_semantically(self, context: str, target_tokens: int) -> str:
        """Prune using semantic analysis."""
        if not self.llm_client:
            return self._prune_by_importance(context, target_tokens)

        prompt = f"""
Please compress the following context to approximately {target_tokens} tokens while maintaining:
1. Character names and relationships
2. Key plot developments
3. Important world details
4. Narrative flow

Context to compress:
{context[:4000]}

Compressed context:
"""

        try:
            response = self.llm_client.generate(
                prompt=prompt, max_tokens=int(target_tokens * 1.5), temperature=0.3
            )

            return response.strip()

        except Exception:
            return self._prune_by_importance(context, target_tokens)

    def _prune_compressively(self, context: str, target_tokens: int) -> str:
        """Prune by compressing summaries."""
        if not self.config.summary_compression:
            return self._prune_by_importance(context, target_tokens)

        summaries = self._extract_summaries(context)

        compressed_summaries = self.compress_summaries(summaries)

        compressed_tokens = self.token_estimator.estimate_tokens(compressed_summaries)

        if compressed_tokens <= target_tokens:
            return compressed_summaries

        ratio = target_tokens / compressed_tokens
        return compressed_summaries[: int(len(compressed_summaries) * ratio)]

    def extract_key_elements(self, context: str) -> List[KeyElement]:
        """
        Extract key narrative elements from context.

        Args:
            context: Context to analyze

        Returns:
            List of key elements
        """
        elements = []

        characters = self._extract_characters(context)
        for char, mentions in characters.items():
            if mentions >= 2:
                elements.append(
                    KeyElement(
                        element_type="character",
                        content=char,
                        importance_score=min(1.0, mentions / 10),
                        first_mention=1,
                        last_mention=1,
                        mention_count=mentions,
                    )
                )

        locations = self._extract_locations(context)
        for loc, mentions in locations.items():
            if mentions >= 2:
                elements.append(
                    KeyElement(
                        element_type="location",
                        content=loc,
                        importance_score=min(1.0, mentions / 8),
                        first_mention=1,
                        last_mention=1,
                        mention_count=mentions,
                    )
                )

        plot_points = self._extract_plot_points(context)
        for plot in plot_points:
            elements.append(
                KeyElement(
                    element_type="plot_point",
                    content=plot,
                    importance_score=0.7,
                    first_mention=1,
                    last_mention=1,
                    mention_count=1,
                )
            )

        self.key_elements = elements
        return elements

    def _extract_characters(self, context: str) -> Dict[str, int]:
        """Extract character names and mention counts."""
        characters = {}

        patterns = [
            r"\b([A-Z][a-z]+)\s+(?:said|asked|replied|thought|felt|saw|heard)",
            r"\b(?:The|the)\s+([A-Z][a-z]+)\b",
            r"\b([A-Z][a-z]+)\b\s+(?:walked|ran|jumped|sat|stood|looked)",
        ]

        for pattern in patterns:
            matches = re.findall(pattern, context)
            for match in matches:
                if len(match) > 2 and match[0].isupper():
                    characters[match] = characters.get(match, 0) + 1

        return characters

    def _extract_locations(self, context: str) -> Dict[str, int]:
        """Extract location names and mention counts."""
        locations = {}

        patterns = [
            r"\bin\s+(?:the|The)\s+([A-Z][a-z]+(?:\s+[A-Z][a-z]+)?)",
            r"\bat\s+(?:the|The)\s+([A-Z][a-z]+(?:\s+[A-Z][a-z]+)?)",
            r"\b([A-Z][a-z]+\s+(?:Room|Hall|Castle|House|Street|Road|City|Town|Forest|Mountain|River))",
        ]

        for pattern in patterns:
            matches = re.findall(pattern, context)
            for match in matches:
                locations[match] = locations.get(match, 0) + 1

        return locations

    def _extract_plot_points(self, context: str) -> List[str]:
        """Extract key plot points."""
        plot_points = []

        sentences = context.split(".")

        keywords = [
            "discovered",
            "realized",
            "learned",
            "found",
            "revealed",
            "decided",
            "chose",
            "escaped",
            "captured",
            "betrayed",
            "confronted",
            "attacked",
            "defended",
        ]

        for sentence in sentences:
            if any(keyword in sentence.lower() for keyword in keywords):
                if len(sentence.strip()) > 20:
                    plot_points.append(sentence.strip())

        return plot_points[:10]

    def compress_summaries(self, summaries: List[str]) -> str:
        """
        Compress multiple summaries into one.

        Args:
            summaries: List of summaries to compress

        Returns:
            Compressed summary text
        """
        if not summaries:
            return ""

        if len(summaries) == 1:
            return summaries[0]

        combined = []

        for summary in summaries:
            sentences = summary.split(".")
            key_sentences = [s.strip() for s in sentences if len(s.strip()) > 15]
            combined.extend(key_sentences[:3])

        return ". ".join(combined[:20]) + "."

    def rank_by_importance(self, elements: List[KeyElement]) -> List[KeyElement]:
        """
        Rank elements by importance score.

        Args:
            elements: Elements to rank

        Returns:
            Sorted list of elements
        """
        return sorted(elements, key=lambda e: e.importance_score, reverse=True)

    def _get_character_content(self, elements: List[KeyElement]) -> str:
        """Get character-related content."""
        chars = [e for e in elements if e.element_type == "character"]
        chars = [c for c in chars if c.importance_score >= self.config.min_importance_score]

        if not chars:
            return ""

        lines = ["**Characters**:"]
        for char in sorted(chars, key=lambda c: c.importance_score, reverse=True):
            lines.append(f"- {char.content}")

        return "\n".join(lines)

    def _get_location_content(self, elements: List[KeyElement]) -> str:
        """Get location-related content."""
        locs = [e for e in elements if e.element_type == "location"]
        locs = [
            location
            for location in locs
            if location.importance_score >= self.config.min_importance_score
        ]

        if not locs:
            return ""

        lines = ["**Locations**:"]
        for loc in sorted(locs, key=lambda location: location.importance_score, reverse=True):
            lines.append(f"- {loc.content}")

        return "\n".join(lines)

    def _get_plot_content(self, elements: List[KeyElement]) -> str:
        """Get plot-related content."""
        plots = [e for e in elements if e.element_type == "plot_point"]
        plots = [p for p in plots if p.importance_score >= self.config.min_importance_score]

        if not plots:
            return ""

        lines = ["**Key Plot Points**:"]
        for plot in sorted(plots, key=lambda p: p.importance_score, reverse=True):
            lines.append(f"- {plot.content}")

        return "\n".join(lines)

    def _get_additional_content(
        self, context: str, preserved_content: str, target_tokens: int
    ) -> str:
        """Get additional content up to target size."""
        lines = context.split("\n")

        current_tokens = self.token_estimator.estimate_tokens(preserved_content)
        additional_lines = []

        for line in lines:
            line_tokens = self.token_estimator.estimate_tokens(line)

            if current_tokens + line_tokens <= target_tokens:
                if line.strip() and line.strip() not in preserved_content:
                    additional_lines.append(line)
                    current_tokens += line_tokens
            else:
                break

        return "\n".join(additional_lines)

    def _extract_summaries(self, context: str) -> List[str]:
        """Extract chapter summaries from context."""
        summaries = []

        summary_pattern = r"\*\*Chapter\s+\d+:\*\*\s*(.*?)(?=\n\n|\Z)"
        matches = re.findall(summary_pattern, context, re.DOTALL)

        summaries.extend(matches)

        if not summaries:
            sections = context.split("\n\n")
            summaries = [s.strip() for s in sections if len(s.strip()) > 100]

        return summaries

    def merge_summaries(self, summaries: List[str]) -> str:
        """
        Merge summaries intelligently.

        Args:
            summaries: Summaries to merge

        Returns:
            Merged summary text
        """
        if not summaries:
            return ""

        if len(summaries) == 1:
            return summaries[0]

        merged_parts = []

        for i, summary in enumerate(summaries):
            if i < len(summaries) - 1:
                merged_parts.append(summary[:200])
            else:
                merged_parts.append(summary)

        return "\n\n".join(merged_parts)

    def add_chapter_summary(self, chapter_number: int, summary: str):
        """
        Add a chapter summary for tracking.

        Args:
            chapter_number: Chapter number
            summary: Chapter summary text
        """
        self.chapter_summaries[chapter_number] = summary

    def clear_cache(self):
        """Clear cached data."""
        self.key_elements.clear()
        self.chapter_summaries.clear()
