"""
Suggestion Knowledge Base

Manages storage and retrieval of suggestions from YAML files,
with support for multilingual static suggestions and learned suggestions.
"""

import json
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional

import yaml

from core.suggestions.models import (
    Suggestion,
    SuggestionCategory,
    SuggestionSource,
)


class SuggestionKnowledgeBase:
    """
    Manages the suggestion knowledge base.

    Loads static suggestions from YAML files and manages learned suggestions.
    Supports multiple languages and tracks suggestion metadata.
    """

    def __init__(self, data_dir: Optional[Path] = None):
        """
        Initialize the knowledge base.

        Args:
            data_dir: Base directory for suggestion YAML files.
                     Defaults to core/data/suggestions/
        """
        if data_dir is None:
            data_dir = Path(__file__).parent.parent / "data" / "suggestions"

        self.data_dir = Path(data_dir)
        self.data_dir.mkdir(parents=True, exist_ok=True)

        self._static_cache: Dict[str, List[Suggestion]] = {}
        self._learned_cache: Dict[str, Suggestion] = {}

        self._load_all_static()
        self._load_learned()

    def _load_all_static(self) -> None:
        """Load all static suggestions from YAML files."""
        for category in SuggestionCategory:
            self._load_category_static(category)

    def _load_category_static(self, category: SuggestionCategory) -> None:
        """Load static suggestions for a specific category."""
        cache_key = f"static_{category.value}"
        self._static_cache[cache_key] = []

        yaml_file = self.data_dir / f"{category.value}_suggestions.yaml"
        if not yaml_file.exists():
            return

        try:
            with open(yaml_file, "r", encoding="utf-8") as f:
                data = yaml.safe_load(f)

            if not data:
                return

            suggestions_data = data.get(f"{category.value}_suggestions", {})

            for lang, suggestions in suggestions_data.items():
                for suggestion_data in suggestions:
                    suggestion = self._dict_to_suggestion(
                        suggestion_data, category, SuggestionSource.STATIC, lang
                    )
                    self._static_cache[cache_key].append(suggestion)

        except Exception as e:
            print(f"Error loading {category.value} suggestions: {e}")

    def _datetime_obj_hook(self, dct):
        """Convert ISO format datetime strings back to datetime objects."""
        for key, value in dct.items():
            if isinstance(value, str) and key in (
                "promoted_at",
                "created_at",
                "updated_at",
                "last_shown_at",
            ):
                try:
                    dct[key] = datetime.fromisoformat(value)
                except (ValueError, TypeError):
                    pass
        return dct

    def _load_learned(self) -> None:
        """Load learned suggestions from JSON file."""
        learned_file = self.data_dir / "learned_suggestions.json"

        if not learned_file.exists():
            return

        try:
            with open(learned_file, "r", encoding="utf-8") as f:
                data = json.load(f, object_hook=self._datetime_obj_hook)

            for suggestion_data in data.get("suggestions", []):
                suggestion = Suggestion.model_validate(suggestion_data)
                self._learned_cache[suggestion.id] = suggestion

        except Exception as e:
            print(f"Error loading learned suggestions: {e}")

    def _dict_to_suggestion(
        self,
        data: Dict,
        category: SuggestionCategory,
        source: SuggestionSource,
        language: str = "en",
    ) -> Suggestion:
        """Convert dictionary to Suggestion object."""
        return Suggestion(
            id=data.get("id", f"{category.value}_{data.get('name', '').lower().replace(' ', '_')}"),
            name=data["name"],
            description=data["description"],
            category=category,
            best_for=data.get("best_for", []),
            examples=data.get("examples", []),
            source=source,
            language=language,
            acceptance_rate=data.get("acceptance_rate", 0.5),
            acceptance_count=data.get("acceptance_count", 0),
            accepted_count=data.get("accepted_count", 0),
            metadata=data.get("metadata", {}),
        )

    def load_suggestions(
        self, category: SuggestionCategory, language: str = "en", include_learned: bool = True
    ) -> List[Suggestion]:
        """
        Load suggestions for a specific category.

        Args:
            category: Category to load
            language: Language code (en, zh-CN, zh-TW)
            include_learned: Whether to include learned suggestions

        Returns:
            List of suggestions
        """
        suggestions = []

        cache_key = f"static_{category.value}"
        if cache_key in self._static_cache:
            suggestions.extend(
                [
                    s
                    for s in self._static_cache[cache_key]
                    if s.language == language or s.language == "en"
                ]
            )

        if include_learned:
            learned = [
                s
                for s in self._learned_cache.values()
                if s.category == category and (s.language == language or s.language == "en")
            ]
            suggestions.extend(learned)

        return suggestions

    def get_suggestion(self, suggestion_id: str) -> Optional[Suggestion]:
        """
        Get a specific suggestion by ID.

        Args:
            suggestion_id: Unique identifier

        Returns:
            Suggestion if found, None otherwise
        """
        for cache_list in self._static_cache.values():
            for suggestion in cache_list:
                if suggestion.id == suggestion_id:
                    return suggestion

        return self._learned_cache.get(suggestion_id)

    def add_suggestion(self, suggestion: Suggestion, project_specific: bool = False) -> bool:
        """
        Add a new suggestion to the knowledge base.

        Args:
            suggestion: Suggestion to add
            project_specific: If True, save to project KB (not implemented yet)

        Returns:
            True if added successfully
        """
        if suggestion.id in self._learned_cache:
            return False

        self._learned_cache[suggestion.id] = suggestion
        self._save_learned()
        return True

    def update_acceptance_rate(self, suggestion_id: str, accepted: bool) -> None:
        """
        Update acceptance rate for a suggestion.

        Args:
            suggestion_id: Suggestion to update
            accepted: Whether user accepted this time
        """
        suggestion = self.get_suggestion(suggestion_id)
        if suggestion:
            suggestion.record_acceptance(accepted)

            if suggestion.source == SuggestionSource.LEARNED:
                self._save_learned()

    def get_top_suggestions(
        self, category: SuggestionCategory, language: str = "en", limit: int = 10
    ) -> List[Suggestion]:
        """
        Get top-performing suggestions by acceptance rate.

        Args:
            category: Category to query
            language: Language code
            limit: Maximum number to return

        Returns:
            Sorted list of suggestions
        """
        suggestions = self.load_suggestions(category, language)

        sorted_suggestions = sorted(
            suggestions, key=lambda s: (s.acceptance_rate, s.acceptance_count), reverse=True
        )

        return sorted_suggestions[:limit]

    def promote_to_global(self, suggestion_id: str) -> bool:
        """
        Promote a learned suggestion to global knowledge base.

        Args:
            suggestion_id: Suggestion to promote

        Returns:
            True if promoted successfully
        """
        suggestion = self._learned_cache.get(suggestion_id)
        if not suggestion:
            return False

        suggestion.promoted_at = datetime.now()
        suggestion.source = SuggestionSource.LEARNED

        self._save_learned()
        return True

    def reload_cache(self) -> None:
        """Reload all static suggestions from disk."""
        self._static_cache.clear()
        self._load_all_static()

    def _save_learned(self) -> None:
        """Save learned suggestions to disk."""
        learned_file = self.data_dir / "learned_suggestions.json"

        class DateTimeEncoder(json.JSONEncoder):
            def default(self, obj):
                if isinstance(obj, datetime):
                    return obj.isoformat()
                return super().default(obj)

        try:
            data = {
                "version": "1.0",
                "updated_at": datetime.now().isoformat(),
                "suggestions": [s.model_dump() for s in self._learned_cache.values()],
            }

            with open(learned_file, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=2, ensure_ascii=False, cls=DateTimeEncoder)

        except Exception as e:
            print(f"Error saving learned suggestions: {e}")

    def get_all_categories(self) -> List[SuggestionCategory]:
        """Get all available suggestion categories."""
        return list(SuggestionCategory)

    def get_supported_languages(self) -> List[str]:
        """Get list of supported language codes."""
        return ["en", "zh-CN", "zh-TW"]

    def get_stats(self) -> Dict:
        """Get statistics about the knowledge base."""
        total_static = sum(len(cache) for cache in self._static_cache.values())
        total_learned = len(self._learned_cache)

        category_counts = {}
        for category in SuggestionCategory:
            cache_key = f"static_{category.value}"
            static_count = len(self._static_cache.get(cache_key, []))
            learned_count = sum(1 for s in self._learned_cache.values() if s.category == category)
            category_counts[category.value] = {
                "static": static_count,
                "learned": learned_count,
                "total": static_count + learned_count,
            }

        return {
            "total_static_suggestions": total_static,
            "total_learned_suggestions": total_learned,
            "total_suggestions": total_static + total_learned,
            "categories": category_counts,
            "supported_languages": self.get_supported_languages(),
        }
