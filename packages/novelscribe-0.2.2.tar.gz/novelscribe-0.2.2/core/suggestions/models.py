"""
Data models for the proactive suggestion system.

Defines Pydantic models for suggestions, events, configuration,
and related enums for categorization and triggering.
"""

from datetime import datetime
from enum import Enum
from typing import Dict, List, Optional

from pydantic import BaseModel, ConfigDict, Field


class SuggestionCategory(str, Enum):
    """Categories of suggestions available in the system."""

    GENRE = "genre"
    TECHNICAL = "technical"
    WORKFLOW = "workflow"
    QUALITY = "quality"


class TriggerType(str, Enum):
    """Triggers that can activate proactive suggestions."""

    DECISION_POINT = "decision_point"
    PHASE_TRANSITION = "phase_transition"
    ISSUE_DETECTED = "issue_detected"
    USER_REQUEST = "user_request"
    CONTINUOUS = "continuous"


class SuggestionSource(str, Enum):
    """Origin of a suggestion."""

    STATIC = "static"
    DYNAMIC = "dynamic"
    LEARNED = "learned"


class Suggestion(BaseModel):
    """A single suggestion with metadata and acceptance tracking."""

    id: str = Field(..., description="Unique identifier for this suggestion")
    name: str = Field(..., description="Human-readable name of the suggestion")
    description: str = Field(..., description="Detailed description of what this suggestion offers")
    category: SuggestionCategory = Field(..., description="Category this suggestion belongs to")
    best_for: List[str] = Field(
        default_factory=list, description="Use cases this suggestion is best suited for"
    )
    examples: List[str] = Field(
        default_factory=list, description="Examples of this suggestion in practice"
    )
    source: SuggestionSource = Field(
        default=SuggestionSource.STATIC, description="Where this suggestion came from"
    )
    language: str = Field(default="en", description="Language code (en, zh-CN, zh-TW)")

    acceptance_rate: float = Field(
        default=0.5, ge=0.0, le=1.0, description="Rate at which users accept this suggestion"
    )
    acceptance_count: int = Field(
        default=0, ge=0, description="Total number of times this suggestion was presented"
    )
    accepted_count: int = Field(
        default=0, ge=0, description="Number of times this suggestion was accepted"
    )

    metadata: Dict = Field(
        default_factory=dict, description="Additional metadata specific to suggestion type"
    )
    created_at: datetime = Field(
        default_factory=datetime.now, description="When this suggestion was created"
    )
    promoted_at: Optional[datetime] = Field(
        None, description="When this suggestion was promoted to global KB"
    )

    model_config = ConfigDict(use_enum_values=False)

    def record_acceptance(self, accepted: bool) -> None:
        """Record an acceptance event for this suggestion."""
        self.acceptance_count += 1
        if accepted:
            self.accepted_count += 1

        if self.acceptance_count > 0:
            self.acceptance_rate = self.accepted_count / self.acceptance_count


class SuggestionEvent(BaseModel):
    """Record of a suggestion being presented to and accepted/rejected by a user."""

    suggestion_id: str = Field(..., description="ID of the suggestion that was presented")
    timestamp: datetime = Field(
        default_factory=datetime.now, description="When this event occurred"
    )
    project_id: str = Field(..., description="Project ID where this event occurred")
    user_choice: str = Field(..., description="Which option the user selected")
    accepted_dynamic: bool = Field(
        default=False, description="Whether the user accepted a dynamic suggestion"
    )
    project_context: Dict = Field(
        default_factory=dict, description="Context about the project at time of event"
    )
    trigger_type: TriggerType = Field(..., description="What triggered this suggestion")
    suggestion_category: SuggestionCategory = Field(
        ..., description="Category of suggestion presented"
    )
    acceptance_prompt_shown: bool = Field(
        default=False, description="Whether user was asked to save to KB"
    )
    acceptance_prompt_response: Optional[bool] = Field(
        None, description="User's response to save prompt"
    )


class ProactiveConfig(BaseModel):
    """Configuration for proactive suggestion behavior."""

    enabled: bool = Field(default=False, description="Whether proactive suggestions are enabled")
    continuous: bool = Field(default=False, description="Whether continuous mode is enabled")
    continuous_interval: int = Field(
        default=300, ge=60, description="Seconds between continuous suggestions"
    )

    suggestions: Dict[SuggestionCategory, bool] = Field(
        default_factory=lambda: {
            SuggestionCategory.GENRE: True,
            SuggestionCategory.TECHNICAL: True,
            SuggestionCategory.WORKFLOW: True,
            SuggestionCategory.QUALITY: True,
        },
        description="Which suggestion categories are enabled",
    )

    learning: Dict = Field(
        default_factory=lambda: {
            "auto_add_accepted": True,
            "prompt_to_save": True,
            "promote_threshold": 5,
        },
        description="Learning system configuration",
    )

    model_config = ConfigDict(use_enum_values=False)

    def is_category_enabled(self, category: SuggestionCategory) -> bool:
        """Check if a specific category is enabled."""
        return self.suggestions.get(category, True)

    def should_prompt_to_save(self) -> bool:
        """Check if user should be prompted to save dynamic suggestions."""
        return self.learning.get("prompt_to_save", True)

    def get_promote_threshold(self) -> int:
        """Get the acceptance count threshold for promotion to global KB."""
        return self.learning.get("promote_threshold", 5)

    def should_auto_add_accepted(self) -> bool:
        """Check if accepted dynamic suggestions should be auto-added to project KB."""
        return self.learning.get("auto_add_accepted", True)


class SuggestionRequest(BaseModel):
    """Request for suggestions from the orchestrator."""

    trigger_type: TriggerType
    project_id: str
    category: Optional[SuggestionCategory] = None
    project_context: Dict = Field(default_factory=dict)
    language: str = Field(default="en")
    max_suggestions: int = Field(default=4, ge=1, le=10)
    include_dynamic: bool = Field(default=True)


class SuggestionResponse(BaseModel):
    """Response containing suggestions for the user."""

    suggestions: List[Suggestion]
    trigger_type: TriggerType
    category: Optional[SuggestionCategory] = None
    formatted_suggestions: str = Field(default="", description="Formatted multi-choice suggestions")
    show_suggestions: bool = Field(
        default=True, description="Whether suggestions should be displayed"
    )
    presented_at: datetime = Field(default_factory=datetime.now)
