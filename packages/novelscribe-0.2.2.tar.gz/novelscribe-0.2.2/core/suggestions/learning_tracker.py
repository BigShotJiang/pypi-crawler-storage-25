"""
Learning Tracker

Tracks suggestion acceptance events and manages the learning cycle
including automatic promotion and usage-based analytics.
"""

import asyncio
import json
from collections import defaultdict
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, List, Optional

from core.suggestions.knowledge_base import SuggestionKnowledgeBase
from core.suggestions.models import (
    Suggestion,
    SuggestionCategory,
    SuggestionEvent,
)


class LearningTracker:
    """
    Tracks suggestion acceptance and manages learning analytics.

    Records events, calculates acceptance rates, identifies top suggestions,
    and manages promotion to global knowledge base.
    """

    def __init__(
        self,
        kb: "SuggestionKnowledgeBase",
        events_dir: Optional[Path] = None,
        promotion_threshold: int = 5,
    ):
        """
        Initialize the learning tracker.

        Args:
            kb: Knowledge base instance
            events_dir: Directory to store event logs
            promotion_threshold: Number of acceptances needed for auto-promotion
        """
        self.kb = kb
        self.promotion_threshold = promotion_threshold

        if events_dir is None:
            events_dir = Path(__file__).parent.parent / "data" / "suggestions"

        self.events_dir = Path(events_dir)
        self.events_dir.mkdir(parents=True, exist_ok=True)

        self._events_file = self.events_dir / "events.jsonl"
        self._pending_promotions: Dict[str, int] = defaultdict(int)

        self._load_pending_promotions()

    def _load_pending_promotions(self) -> None:
        """Load pending promotion counts from disk."""
        pending_file = self.events_dir / "pending_promotions.json"

        if pending_file.exists():
            try:
                with open(pending_file, "r", encoding="utf-8") as f:
                    self._pending_promotions = defaultdict(int, json.load(f))
            except Exception as e:
                print(f"Error loading pending promotions: {e}")

    def _save_pending_promotions(self) -> None:
        """Save pending promotion counts to disk."""
        pending_file = self.events_dir / "pending_promotions.json"

        try:
            with open(pending_file, "w", encoding="utf-8") as f:
                json.dump(dict(self._pending_promotions), f, indent=2)
        except Exception as e:
            print(f"Error saving pending promotions: {e}")

    async def record_acceptance_async(self, event: SuggestionEvent) -> None:
        """
        Record a suggestion acceptance event asynchronously.

        Args:
            event: The suggestion event to record
        """
        await asyncio.to_thread(self.record_acceptance, event)

    def record_acceptance(self, event: SuggestionEvent) -> None:
        """
        Record a suggestion acceptance event.

        Args:
            event: The suggestion event to record
        """
        try:
            event_line = event.model_dump_json()

            with open(self._events_file, "a", encoding="utf-8") as f:
                f.write(event_line + "\n")

            self.kb.update_acceptance_rate(event.suggestion_id, event.accepted_dynamic)

            if event.accepted_dynamic and event.acceptance_prompt_response:
                self._pending_promotions[event.suggestion_id] += 1
                self._save_pending_promotions()

        except Exception as e:
            print(f"Error recording acceptance event: {e}")

    def get_acceptance_rate(self, suggestion_id: str) -> float:
        """
        Get acceptance rate for a specific suggestion.

        Args:
            suggestion_id: Suggestion to query

        Returns:
            Acceptance rate (0.0 to 1.0)
        """
        suggestion = self.kb.get_suggestion(suggestion_id)
        if suggestion:
            return suggestion.acceptance_rate
        return 0.5

    def get_suggestion_events(self, suggestion_id: str, limit: int = 100) -> List[SuggestionEvent]:
        """
        Get recent events for a specific suggestion.

        Args:
            suggestion_id: Suggestion to query
            limit: Maximum events to return

        Returns:
            List of events
        """
        events = []

        if not self._events_file.exists():
            return events

        try:
            with open(self._events_file, "r", encoding="utf-8") as f:
                for line in f:
                    if len(events) >= limit:
                        break

                    try:
                        event_data = json.loads(line.strip())
                        if event_data.get("suggestion_id") == suggestion_id:
                            events.append(SuggestionEvent(**event_data))
                    except Exception:
                        continue

        except Exception as e:
            print(f"Error reading events: {e}")

        return events

    def get_top_suggestions(
        self, category: SuggestionCategory, language: str = "en", limit: int = 10
    ) -> List[Suggestion]:
        """
        Get top-performing suggestions by acceptance rate.

        Args:
            category: Category to query
            language: Language code
            limit: Maximum to return

        Returns:
            Sorted list of suggestions
        """
        return self.kb.get_top_suggestions(category, language, limit)

    def should_promote(self, suggestion_id: str, threshold: int) -> bool:
        """
        Check if a suggestion should be promoted to global KB.

        Args:
            suggestion_id: Suggestion to check
            threshold: Acceptance count threshold

        Returns:
            True if ready for promotion
        """
        if suggestion_id not in self._pending_promotions:
            return False

        return self._pending_promotions[suggestion_id] >= threshold

    def promote_to_knowledge_base(self, suggestion_id: str) -> bool:
        """
        Promote a learned suggestion to global knowledge base.

        Args:
            suggestion_id: Suggestion to promote

        Returns:
            True if promoted successfully
        """
        if not self.kb.promote_to_global(suggestion_id):
            return False

        if suggestion_id in self._pending_promotions:
            del self._pending_promotions[suggestion_id]
            self._save_pending_promotions()

        return True

    def promote_to_learned(self, suggestion_id: str) -> bool:
        """
        Promote a suggestion to the learned knowledge base.

        This is an alias for promote_to_knowledge_base for backward compatibility.

        Args:
            suggestion_id: Suggestion to promote

        Returns:
            True if promoted successfully
        """
        return self.promote_to_knowledge_base(suggestion_id)

    def check_and_auto_promote(self, suggestion_id: str) -> bool:
        """
        Check if suggestion should be auto-promoted and promote if ready.

        Args:
            suggestion_id: Suggestion to check and promote

        Returns:
            True if promoted, False otherwise
        """
        if self.should_promote(suggestion_id, self.promotion_threshold):
            return self.promote_to_learned(suggestion_id)
        return False

    def generate_promotion_report(self, days: int = 7) -> Dict:
        """
        Generate a weekly promotion report with top performers.

        Args:
            days: Number of days to analyze

        Returns:
            Report dictionary with promotion recommendations
        """
        analytics = self.get_usage_analytics(days=days)

        pending = self.get_pending_promotions(threshold=max(1, self.promotion_threshold - 2))

        ready_for_promotion = [p for p in pending if p["ready_for_promotion"]]
        near_threshold = [p for p in pending if not p["ready_for_promotion"]]

        top_performers = []
        for cat in SuggestionCategory:
            suggestions = self.get_top_suggestions(cat, "en", limit=3)
            top_performers.extend(
                [
                    {
                        "id": s.id,
                        "name": s.name,
                        "category": cat.value,
                        "acceptance_rate": s.acceptance_rate,
                        "acceptance_count": s.acceptance_count,
                    }
                    for s in suggestions
                    if s.acceptance_count > 0
                ]
            )

        return {
            "period_days": days,
            "analytics": analytics,
            "ready_for_promotion": len(ready_for_promotion),
            "near_threshold": len(near_threshold),
            "promotion_candidates": ready_for_promotion[:5],
            "near_threshold_candidates": near_threshold[:5],
            "top_performers": sorted(
                top_performers, key=lambda x: x["acceptance_rate"], reverse=True
            )[:10],
        }

    def get_learning_insights(self, days: int = 30) -> Dict:
        """
        Get comprehensive learning insights and patterns.

        Args:
            days: Number of days to analyze

        Returns:
            Insights dictionary with patterns and recommendations
        """
        analytics = self.get_usage_analytics(days=days)

        report = self.generate_promotion_report(days)

        acceptance_by_category = defaultdict(list)
        acceptance_by_trigger = defaultdict(list)

        if self._events_file.exists():
            cutoff_date = datetime.now() - timedelta(days=days)

            try:
                with open(self._events_file, "r", encoding="utf-8") as f:
                    for line in f:
                        try:
                            event_data = json.loads(line.strip())
                            event = SuggestionEvent(**event_data)

                            if datetime.fromisoformat(event.timestamp.isoformat()) < cutoff_date:
                                continue

                            acceptance_by_category[event.suggestion_category.value].append(
                                event.accepted_dynamic
                            )
                            acceptance_by_trigger[event.trigger_type.value].append(
                                event.accepted_dynamic
                            )
                        except Exception:
                            continue
            except Exception as e:
                print(f"Error analyzing patterns: {e}")

        category_performance = {}
        for cat, accepts in acceptance_by_category.items():
            if accepts:
                category_performance[cat] = sum(accepts) / len(accepts)

        trigger_performance = {}
        for trigger, accepts in acceptance_by_trigger.items():
            if accepts:
                trigger_performance[trigger] = sum(accepts) / len(accepts)

        best_categories = sorted(category_performance.items(), key=lambda x: x[1], reverse=True)[:3]

        best_triggers = sorted(trigger_performance.items(), key=lambda x: x[1], reverse=True)[:3]

        return {
            "period_days": days,
            "total_events": analytics["total_events"],
            "overall_acceptance_rate": analytics["dynamic_acceptance_rate"],
            "category_performance": category_performance,
            "trigger_performance": trigger_performance,
            "best_categories": best_categories,
            "best_triggers": best_triggers,
            "promotion_candidates": report["ready_for_promotion"],
            "recommendations": self._generate_recommendations(
                category_performance, trigger_performance, report
            ),
        }

    def _generate_recommendations(
        self,
        category_performance: Dict[str, float],
        trigger_performance: Dict[str, float],
        report: Dict,
    ) -> List[str]:
        """Generate actionable recommendations based on analytics."""
        recommendations = []

        if report["ready_for_promotion"] > 0:
            recommendations.append(
                f"✓ {report['ready_for_promotion']} suggestion(s) ready for promotion"
            )

        low_performing = [
            cat
            for cat, rate in category_performance.items()
            if rate < 0.3 and len(category_performance) > 1
        ]

        if low_performing:
            recommendations.append(
                f"⚠ Consider reviewing low-performing categories: {', '.join(low_performing)}"
            )

        high_performing_triggers = [
            trigger for trigger, rate in trigger_performance.items() if rate > 0.7
        ]

        if high_performing_triggers:
            recommendations.append(
                f"⭐ High-performing triggers: {', '.join(high_performing_triggers)}"
            )

        if not recommendations:
            recommendations.append("✓ System performing well. Continue monitoring.")

        return recommendations

    def get_pending_promotions(self, threshold: int = 5) -> Dict[str, int]:
        """
        Get suggestions pending promotion.

        Args:
            threshold: Minimum acceptance count for promotion

        Returns:
            Dictionary mapping suggestion IDs to acceptance counts
        """
        return dict(self._pending_promotions)

    def get_pending_promotions_detailed(self, threshold: int = 5) -> List[Dict]:
        """
        Get detailed list of suggestions pending promotion.

        Args:
            threshold: Minimum acceptance count

        Returns:
            List of detailed dictionaries with suggestion metadata
        """
        pending = []

        for suggestion_id, count in self._pending_promotions.items():
            if count >= threshold:
                suggestion = self.kb.get_suggestion(suggestion_id)
                if suggestion:
                    pending.append(
                        {
                            "suggestion": suggestion,
                            "acceptance_count": count,
                            "threshold": threshold,
                            "ready_for_promotion": True,
                        }
                    )
            else:
                suggestion = self.kb.get_suggestion(suggestion_id)
                if suggestion:
                    pending.append(
                        {
                            "suggestion": suggestion,
                            "acceptance_count": count,
                            "threshold": threshold,
                            "ready_for_promotion": False,
                            "remaining": threshold - count,
                        }
                    )

        return sorted(pending, key=lambda x: x["acceptance_count"], reverse=True)

    def get_usage_analytics(self, days: int = 7) -> Dict:
        """
        Get usage analytics for the specified time period.

        Args:
            days: Number of days to analyze

        Returns:
            Analytics dictionary
        """
        cutoff_date = datetime.now() - timedelta(days=days)

        category_counts = defaultdict(int)
        trigger_counts = defaultdict(int)
        total_events = 0
        accepted_dynamic = 0

        if not self._events_file.exists():
            return {
                "period_days": days,
                "total_events": 0,
                "category_breakdown": {},
                "trigger_breakdown": {},
                "dynamic_acceptance_rate": 0.0,
            }

        try:
            with open(self._events_file, "r", encoding="utf-8") as f:
                for line in f:
                    try:
                        event_data = json.loads(line.strip())
                        event = SuggestionEvent(**event_data)

                        if datetime.fromisoformat(event.timestamp.isoformat()) < cutoff_date:
                            continue

                        total_events += 1
                        category_counts[event.suggestion_category.value] += 1
                        trigger_counts[event.trigger_type.value] += 1

                        if event.accepted_dynamic:
                            accepted_dynamic += 1

                    except Exception:
                        continue

        except Exception as e:
            print(f"Error analyzing events: {e}")

        return {
            "period_days": days,
            "total_events": total_events,
            "category_breakdown": dict(category_counts),
            "trigger_breakdown": dict(trigger_counts),
            "dynamic_acceptance_rate": (
                accepted_dynamic / total_events if total_events > 0 else 0.0
            ),
        }

    def get_suggestion_history(self, project_id: str, limit: int = 50) -> List[Dict]:
        """
        Get suggestion history for a specific project.

        Args:
            project_id: Project to query
            limit: Maximum events to return

        Returns:
            List of event dictionaries
        """
        history = []

        if not self._events_file.exists():
            return history

        try:
            with open(self._events_file, "r", encoding="utf-8") as f:
                for line in f:
                    if len(history) >= limit:
                        break

                    try:
                        event_data = json.loads(line.strip())
                        if event_data.get("project_id") == project_id:
                            suggestion = self.kb.get_suggestion(event_data.get("suggestion_id"))
                            history.append(
                                {
                                    "event": SuggestionEvent(**event_data),
                                    "suggestion_name": suggestion.name if suggestion else "Unknown",
                                }
                            )
                    except Exception:
                        continue

        except Exception as e:
            print(f"Error reading history: {e}")

        return history
