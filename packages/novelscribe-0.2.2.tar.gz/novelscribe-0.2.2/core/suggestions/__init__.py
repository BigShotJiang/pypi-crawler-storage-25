"""
Proactive Suggestion System

Core components for providing contextual, multi-choice suggestions
throughout the novel creation workflow.

Components:
- SuggestionKnowledgeBase: Store and retrieve suggestions
- SuggestionOrchestrator: Coordinate suggestion delivery
- LearningTracker: Track acceptance and optimize suggestions
"""

from core.suggestions.knowledge_base import SuggestionKnowledgeBase
from core.suggestions.learning_tracker import LearningTracker
from core.suggestions.models import (
    ProactiveConfig,
    Suggestion,
    SuggestionCategory,
    SuggestionEvent,
    SuggestionRequest,
    SuggestionResponse,
    TriggerType,
)
from core.suggestions.orchestrator import SuggestionOrchestrator

__all__ = [
    "Suggestion",
    "SuggestionCategory",
    "SuggestionEvent",
    "TriggerType",
    "ProactiveConfig",
    "SuggestionRequest",
    "SuggestionResponse",
    "SuggestionKnowledgeBase",
    "LearningTracker",
    "SuggestionOrchestrator",
]
