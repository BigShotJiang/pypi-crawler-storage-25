"""
Suggestion Orchestrator

Coordinates proactive suggestions by detecting triggers, aggregating
suggestions from multiple sources, ranking them, and formatting
them as multi-choice menus for users.
"""

from functools import lru_cache
from typing import Dict, List, Optional

from core.suggestions.knowledge_base import SuggestionKnowledgeBase
from core.suggestions.learning_tracker import LearningTracker
from core.suggestions.models import (
    ProactiveConfig,
    Suggestion,
    SuggestionCategory,
    SuggestionRequest,
    SuggestionResponse,
    SuggestionSource,
    TriggerType,
)


class SuggestionOrchestrator:
    """
    Orchestrates proactive suggestion generation and delivery.

    Detects trigger conditions, aggregates suggestions from static
    and dynamic sources, ranks by acceptance rate, and formats
    as multi-choice menus.
    """

    def __init__(self, kb: SuggestionKnowledgeBase, tracker: Optional[LearningTracker] = None):
        """
        Initialize the orchestrator.

        Args:
            kb: Knowledge base instance
            tracker: Optional learning tracker for analytics
        """
        self.kb = kb
        self.tracker = tracker

    def should_suggest(
        self,
        trigger_type: TriggerType,
        config: ProactiveConfig,
        project_context: Optional[Dict] = None,
    ) -> bool:
        """
        Determine if suggestions should be shown based on trigger and config.

        Args:
            trigger_type: Type of trigger that occurred
            config: Project's proactive configuration
            project_context: Optional context about the project

        Returns:
            True if suggestions should be shown
        """
        if not config.enabled:
            return False

        if trigger_type == TriggerType.CONTINUOUS:
            return config.continuous

        if trigger_type == TriggerType.USER_REQUEST:
            return True

        if not project_context:
            project_context = {}

        # Convert dict to tuple for caching (requires hashable args)
        # Handle both dict and tuple inputs
        if isinstance(project_context, dict):
            context_tuple = tuple(sorted(project_context.items())) if project_context else tuple()
        else:
            # Already a tuple
            context_tuple = project_context if project_context else tuple()

        category = self._infer_category_from_trigger(trigger_type, context_tuple)

        return config.is_category_enabled(category)

    def get_suggestions(
        self, request: SuggestionRequest, config: ProactiveConfig
    ) -> SuggestionResponse:
        """
        Get suggestions for a given request.

        Args:
            request: Suggestion request with trigger and context
            config: Project's proactive configuration

        Returns:
            SuggestionResponse with ranked suggestions
        """
        if not self.should_suggest(request.trigger_type, config, request.project_context):
            return SuggestionResponse(
                suggestions=[], trigger_type=request.trigger_type, show_suggestions=False
            )

        category = request.category or self._infer_category_from_trigger(
            request.trigger_type,
            tuple(sorted(request.project_context.items())) if request.project_context else tuple(),
        )

        if not config.is_category_enabled(category):
            return SuggestionResponse(
                suggestions=[], trigger_type=request.trigger_type, show_suggestions=False
            )

        static_suggestions = self._get_static_suggestions(
            category, request.language, request.project_context or {}
        )

        dynamic_suggestions = (
            self._get_dynamic_suggestions(request) if request.include_dynamic else []
        )

        all_suggestions = self._merge_and_deduplicate(static_suggestions, dynamic_suggestions)

        ranked_suggestions = self.rank_suggestions(all_suggestions, request.max_suggestions)

        formatted_output = self.format_suggestions(ranked_suggestions, request.language)

        return SuggestionResponse(
            suggestions=ranked_suggestions,
            trigger_type=request.trigger_type,
            formatted_suggestions=formatted_output,
            show_suggestions=True,
        )

    def rank_suggestions(self, suggestions: List[Suggestion], limit: int = 4) -> List[Suggestion]:
        """
        Rank suggestions by acceptance rate and other factors.

        Args:
            suggestions: List of suggestions to rank
            limit: Maximum number to return

        Returns:
            Ranked list of suggestions
        """

        def rank_key(s: Suggestion) -> tuple:
            static_boost = 1.5 if s.source == SuggestionSource.STATIC else 1.0
            learned_boost = 1.2 if s.source == SuggestionSource.LEARNED else 1.0

            acceptance_score = s.acceptance_rate * static_boost * learned_boost
            count_score = min(s.acceptance_count / 10, 1.0)

            return (acceptance_score, count_score, s.acceptance_count)

        ranked = sorted(suggestions, key=rank_key, reverse=True)

        return ranked[:limit]

    def format_suggestions(self, suggestions: List[Suggestion], language: str = "en") -> str:
        """
        Format suggestions as a multi-choice menu.

        Args:
            suggestions: List of suggestions to format
            language: Language code

        Returns:
            Formatted multi-choice string
        """
        if not suggestions:
            return ""

        lines = []

        for idx, suggestion in enumerate(suggestions, 1):
            prefix = "**Option " if idx == 1 else "Option "
            marker = "⭐ " if idx == 1 else ""
            source_marker = " (Dynamic)" if suggestion.source == SuggestionSource.DYNAMIC else ""

            acceptance_info = ""
            if suggestion.source == SuggestionSource.LEARNED and suggestion.acceptance_count > 0:
                acceptance_info = f" [{suggestion.acceptance_rate:.0%} acceptance]"

            line = f"{prefix}{idx}: {marker}{suggestion.name}{source_marker}{acceptance_info}"
            lines.append(line)

            lines.append(f"  {suggestion.description}")

            if suggestion.best_for:
                best_for_text = " | ".join(suggestion.best_for[:3])
                lines.append(f"  Best for: {best_for_text}")

            if idx < len(suggestions):
                lines.append("")

        return "\n".join(lines)

    @lru_cache(maxsize=128)
    def _infer_category_from_trigger(
        self, trigger_type: TriggerType, context: tuple
    ) -> SuggestionCategory:
        """Infer suggestion category from trigger type and context (cached)."""
        context_dict = dict(context) if context else {}

        if trigger_type == TriggerType.ISSUE_DETECTED:
            return SuggestionCategory.QUALITY

        if trigger_type == TriggerType.PHASE_TRANSITION:
            phase = context_dict.get("phase", "").lower()
            if "outline" in phase or "planning" in phase:
                return SuggestionCategory.GENRE
            if "writing" in phase or "draft" in phase:
                return SuggestionCategory.TECHNICAL
            if "review" in phase or "edit" in phase:
                return SuggestionCategory.WORKFLOW
            return SuggestionCategory.WORKFLOW

        context_category = context_dict.get("category")
        if context_category:
            try:
                return SuggestionCategory(context_category)
            except ValueError:
                pass

        return SuggestionCategory.GENRE

    def _get_static_suggestions(
        self, category: SuggestionCategory, language: str, context: Dict
    ) -> List[Suggestion]:
        """Get static suggestions from knowledge base."""
        suggestions = self.kb.load_suggestions(category, language, include_learned=True)

        if context.get("filter_by_context"):
            suggestions = self._filter_by_context(suggestions, context)

        return suggestions

    def _get_dynamic_suggestions(self, request: SuggestionRequest) -> List[Suggestion]:
        """
        Generate dynamic suggestions based on context.

        In a full implementation, this would call appropriate agents
        to generate suggestions. For now, returns empty list.
        """
        # This would be implemented by integrating with agents
        # For M2.1, we return empty as dynamic generation is M2.2-M2.3
        return []

    def _merge_and_deduplicate(
        self, static: List[Suggestion], dynamic: List[Suggestion]
    ) -> List[Suggestion]:
        """Merge static and dynamic suggestions, removing duplicates."""
        seen_ids = set()
        merged = []

        for suggestion in static + dynamic:
            if suggestion.id not in seen_ids:
                seen_ids.add(suggestion.id)
                merged.append(suggestion)

        return merged

    def _filter_by_context(self, suggestions: List[Suggestion], context: Dict) -> List[Suggestion]:
        """Filter suggestions based on project context."""
        genre = context.get("genre", "").lower()
        target_audience = context.get("target_audience", "").lower()

        filtered = []
        for suggestion in suggestions:
            if genre and any(genre in bf.lower() for bf in suggestion.best_for):
                filtered.append(suggestion)
            elif target_audience and any(
                target_audience in bf.lower() for bf in suggestion.best_for
            ):
                filtered.append(suggestion)
            else:
                filtered.append(suggestion)

        return filtered

    def record_suggestion_outcome(
        self,
        suggestion_id: str,
        accepted: bool,
        project_id: str,
        user_choice: str,
        trigger_type: TriggerType,
        category: SuggestionCategory,
    ) -> None:
        """
        Record the outcome of a suggestion presentation.

        Args:
            suggestion_id: ID of the suggestion
            accepted: Whether user accepted it
            project_id: Project identifier
            user_choice: What the user chose
            trigger_type: What triggered the suggestion
            category: Category of suggestion
        """
        if self.tracker:
            from core.suggestions.models import SuggestionEvent

            event = SuggestionEvent(
                suggestion_id=suggestion_id,
                project_id=project_id,
                user_choice=user_choice,
                accepted_dynamic=accepted,
                trigger_type=trigger_type,
                suggestion_category=category,
            )

            self.tracker.record_acceptance(event)

    def get_usage_analytics(self, days: int = 7) -> Dict:
        """
        Get usage analytics for the orchestrator.

        Args:
            days: Number of days to analyze

        Returns:
            Analytics dictionary
        """
        if self.tracker:
            return self.tracker.get_usage_analytics(days=days)

        return {"period_days": days, "total_events": 0, "dynamic_acceptance_rate": 0.0}
