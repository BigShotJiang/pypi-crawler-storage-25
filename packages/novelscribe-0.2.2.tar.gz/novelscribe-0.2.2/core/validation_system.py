"""
Validation System for Novel Content

This module provides a comprehensive validation framework for novel content,
including content, structure, style, and continuity validation rules.
"""

import re
from datetime import datetime
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional


class Severity(str, Enum):
    """Severity levels for validation issues."""

    ERROR = "error"
    WARNING = "warning"
    INFO = "info"


class RuleCategory(str, Enum):
    """Categories of validation rules."""

    CONTENT = "content"
    STRUCTURE = "structure"
    STYLE = "style"
    CONTINUITY = "continuity"


class ValidationRule:
    """Definition of a validation rule."""

    def __init__(
        self,
        rule_id: str,
        name: str,
        description: str,
        severity: Severity,
        category: RuleCategory,
        enabled: bool = True,
    ):
        self.rule_id = rule_id
        self.name = name
        self.description = description
        self.severity = severity
        self.category = category
        self.enabled = enabled

    def validate_content(
        self, content: str, context: Optional[Dict[str, Any]] = None
    ) -> "ValidationResult":
        """Validate content against this rule. Override in subclasses."""
        raise NotImplementedError

    def __call__(
        self, content: str, context: Optional[Dict[str, Any]] = None
    ) -> "ValidationResult":
        """Allow the rule to be called as a function."""
        return self.validate_content(content, context)


class ValidationResult:
    """Result of a validation check."""

    def __init__(
        self,
        rule: ValidationRule,
        passed: bool,
        message: str,
        location: Optional[str] = None,
        suggestion: Optional[str] = None,
        context: Optional[Dict[str, Any]] = None,
        timestamp: Optional[datetime] = None,
    ):
        self.rule = rule
        self.passed = passed
        self.message = message
        self.location = location
        self.suggestion = suggestion
        self.context = context
        self.timestamp = timestamp or datetime.now()

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "rule_id": self.rule.rule_id,
            "rule_name": self.rule.name,
            "passed": self.passed,
            "message": self.message,
            "location": self.location,
            "suggestion": self.suggestion,
            "context": self.context,
            "timestamp": self.timestamp.isoformat() if self.timestamp else None,
            "severity": self.rule.severity.value if self.rule.severity else None,
            "category": self.rule.category.value if self.rule.category else None,
        }


class ValidationReport:
    """Complete validation report for content."""

    def __init__(
        self,
        content_path: Optional[str] = None,
        timestamp: Optional[datetime] = None,
        total_rules_checked: int = 0,
        passed_rules: int = 0,
        failed_rules: int = 0,
        warnings: int = 0,
        errors: int = 0,
        results: Optional[List[ValidationResult]] = None,
    ):
        self.content_path = content_path
        self.timestamp = timestamp or datetime.now()
        self.total_rules_checked = total_rules_checked
        self.passed_rules = passed_rules
        self.failed_rules = failed_rules
        self.warnings = warnings
        self.errors = errors
        self.results = results or []

    @property
    def success_rate(self) -> float:
        """Calculate success rate of validation."""
        if self.total_rules_checked == 0:
            return 1.0
        return self.passed_rules / self.total_rules_checked

    def get_results_by_severity(self, severity: Severity) -> List[ValidationResult]:
        """Filter results by severity level."""
        return [r for r in self.results if not r.passed and r.rule.severity == severity]

    def get_results_by_category(self, category: RuleCategory) -> List[ValidationResult]:
        """Filter results by category."""
        return [r for r in self.results if r.rule.category == category]


class ValidationSystem:
    """
    Comprehensive validation system for novel content.

    Manages validation rules, executes validation checks, and generates
    detailed validation reports with actionable feedback.
    """

    def __init__(self, project_root: Optional[Path] = None):
        """
        Initialize the validation system.

        Args:
            project_root: Path to project directory for context
        """
        self.project_root = project_root or Path.cwd()
        self.rules: Dict[str, ValidationRule] = {}
        self._register_default_rules()

    def _register_default_rules(self) -> None:
        """Register default validation rules."""
        self.add_rule(MinimumWordCountRule())
        self.add_rule(MaxSentenceLengthRule())
        self.add_rule(DialogueAttributionRule())
        self.add_rule(CharacterConsistencyRule())
        self.add_rule(ChapterOutlineAlignmentRule())
        self.add_rule(TimelineContinuityRule())
        self.add_rule(PassiveVoiceRule())
        self.add_rule(AdverbOveruseRule())
        self.add_rule(DialogueBalanceRule())
        self.add_rule(SceneLengthRule())

    def add_rule(self, rule: ValidationRule) -> None:
        """Add a validation rule to the system."""
        self.rules[rule.rule_id] = rule

    def remove_rule(self, rule_id: str) -> None:
        """Remove a validation rule from the system."""
        if rule_id in self.rules:
            del self.rules[rule_id]

    def enable_rule(self, rule_id: str) -> None:
        """Enable a specific validation rule."""
        if rule_id in self.rules:
            self.rules[rule_id].enabled = True

    def disable_rule(self, rule_id: str) -> None:
        """Disable a specific validation rule."""
        if rule_id in self.rules:
            self.rules[rule_id].enabled = False

    def validate_content(
        self,
        content: str,
        context: Optional[Dict[str, Any]] = None,
        rule_ids: Optional[List[str]] = None,
    ) -> ValidationReport:
        """
        Validate content against all enabled rules.

        Args:
            content: Content to validate
            context: Additional context for validation
            rule_ids: Specific rules to validate (None = all enabled)

        Returns:
            ValidationReport with all validation results
        """
        context = context or {}
        results = []

        rules_to_check = self._get_rules_to_check(rule_ids)

        for rule in rules_to_check.values():
            try:
                result = rule.validate_content(content, context)
                results.append(result)
            except Exception as e:
                results.append(
                    ValidationResult(
                        rule=rule,
                        passed=False,
                        message=f"Validation error: {str(e)}",
                        suggestion="Check rule implementation",
                    )
                )

        return self._generate_report(results, context.get("content_path"))

    def _get_rules_to_check(
        self, rule_ids: Optional[List[str]] = None
    ) -> Dict[str, ValidationRule]:
        """Get the set of rules to validate against."""
        if rule_ids:
            return {rid: self.rules[rid] for rid in rule_ids if rid in self.rules}
        else:
            return {rid: rule for rid, rule in self.rules.items() if rule.enabled}

    def _generate_report(
        self, results: List[ValidationResult], content_path: Optional[str] = None
    ) -> ValidationReport:
        """Generate a validation report from results."""
        passed = sum(1 for r in results if r.passed)
        failed = len(results) - passed
        warnings = sum(1 for r in results if not r.passed and r.rule.severity == Severity.WARNING)
        errors = sum(1 for r in results if not r.passed and r.rule.severity == Severity.ERROR)

        return ValidationReport(
            content_path=content_path,
            timestamp=datetime.now(),
            total_rules_checked=len(results),
            passed_rules=passed,
            failed_rules=failed,
            warnings=warnings,
            errors=errors,
            results=results,
        )

    def get_rules_by_category(self, category: RuleCategory) -> List[ValidationRule]:
        """Get all rules in a specific category."""
        return [rule for rule in self.rules.values() if rule.category == category]

    def get_rules_by_severity(self, severity: Severity) -> List[ValidationRule]:
        """Get all rules with a specific severity level."""
        return [rule for rule in self.rules.values() if rule.severity == severity]

    def generate_report_summary(self, report: ValidationReport) -> str:
        """Generate a human-readable summary of the validation report."""
        summary = [
            "## Validation Report",
            f"Generated: {report.timestamp.strftime('%Y-%m-%d %H:%M:%S')}",
            "",
            "**Overall Results**",
            f"- Rules Checked: {report.total_rules_checked}",
            f"- Passed: {report.passed_rules}",
            f"- Failed: {report.failed_rules}",
            f"- Warnings: {report.warnings}",
            f"- Errors: {report.errors}",
            f"- Success Rate: {report.success_rate:.1%}",
            "",
        ]

        if report.errors > 0:
            summary.append("**Errors**")
            for result in report.get_results_by_severity(Severity.ERROR):
                summary.append(f"- {result.rule.name}: {result.message}")
                if result.suggestion:
                    summary.append(f"  Suggestion: {result.suggestion}")
            summary.append("")

        if report.warnings > 0:
            summary.append("**Warnings**")
            for result in report.get_results_by_severity(Severity.WARNING):
                summary.append(f"- {result.rule.name}: {result.message}")
                if result.suggestion:
                    summary.append(f"  Suggestion: {result.suggestion}")
            summary.append("")

        return "\n".join(summary)


class MinimumWordCountRule(ValidationRule):
    """Rule to enforce minimum word count per chapter."""

    def __init__(self, min_words: int = 1000):
        super().__init__(
            rule_id="min_word_count",
            name="Minimum Word Count",
            description="Ensures chapter meets minimum word count",
            severity=Severity.ERROR,
            category=RuleCategory.CONTENT,
        )
        self.min_words = min_words

    def validate_content(
        self, content: str, context: Optional[Dict[str, Any]] = None
    ) -> ValidationResult:
        words = re.findall(r"\b[a-zA-Z]+\b", content)
        word_count = len(words)

        passed = word_count >= self.min_words

        return ValidationResult(
            rule=self,
            passed=passed,
            message=f"Word count: {word_count} (minimum: {self.min_words})",
            suggestion=f"Add {self.min_words - word_count} more words" if not passed else None,
            context={"word_count": word_count},
        )


class MaxSentenceLengthRule(ValidationRule):
    """Rule to prevent overly long sentences."""

    def __init__(self, max_length: int = 40):
        super().__init__(
            rule_id="max_sentence_length",
            name="Maximum Sentence Length",
            description="Prevents sentences that are too long",
            severity=Severity.WARNING,
            category=RuleCategory.STYLE,
        )
        self.max_length = max_length

    def validate_content(
        self, content: str, context: Optional[Dict[str, Any]] = None
    ) -> ValidationResult:
        sentences = re.split(r"[.!?]+", content)

        long_sentences = []
        for i, sentence in enumerate(sentences):
            words = len(re.findall(r"\b\w+\b", sentence))
            if words > self.max_length:
                long_sentences.append((i, words))

        passed = len(long_sentences) == 0

        message = f"Found {len(long_sentences)} sentences exceeding {self.max_length} words"
        suggestion = "Break long sentences into shorter ones" if not passed else None

        if long_sentences:
            worst_sentence = max(long_sentences, key=lambda x: x[1])
            message += f" (worst: {worst_sentence[1]} words)"

        return ValidationResult(
            rule=self,
            passed=passed,
            message=message,
            suggestion=suggestion,
            context={"long_sentences": len(long_sentences)},
        )


class DialogueAttributionRule(ValidationRule):
    """Rule to ensure dialogue has proper attribution."""

    def __init__(self, min_attribution_ratio: float = 0.6):
        super().__init__(
            rule_id="dialogue_attribution",
            name="Dialogue Attribution",
            description="Ensures dialogue lines have proper speaker attribution",
            severity=Severity.WARNING,
            category=RuleCategory.CONTENT,
        )
        self.min_attribution_ratio = min_attribution_ratio
        self.dialogue_pattern = re.compile(r'"[^"]*"')
        self.attribution_pattern = re.compile(
            r'(?:(?:")\s*[\w\s,]*\s+(?:said|asked|replied|whispered|shouted|murmured|exclaimed|cried|yelled)\s+\w+)'
        )

    def validate_content(
        self, content: str, context: Optional[Dict[str, Any]] = None
    ) -> ValidationResult:
        dialogue_lines = self.dialogue_pattern.findall(content)
        attributed_lines = self.attribution_pattern.findall(content)

        if len(dialogue_lines) == 0:
            return ValidationResult(
                rule=self, passed=True, message="No dialogue found", context={"dialogue_lines": 0}
            )

        attribution_ratio = len(attributed_lines) / len(dialogue_lines)
        passed = attribution_ratio >= self.min_attribution_ratio

        return ValidationResult(
            rule=self,
            passed=passed,
            message=(
                f"Dialogue attribution: {attribution_ratio:.1%} "
                f"(minimum: {self.min_attribution_ratio:.1%})"
            ),
            suggestion="Add speaker attributions to dialogue lines" if not passed else None,
            context={
                "dialogue_lines": len(dialogue_lines),
                "attributed_lines": len(attributed_lines),
            },
        )


class CharacterConsistencyRule(ValidationRule):
    """Rule to check character name consistency."""

    def __init__(self):
        super().__init__(
            rule_id="character_consistency",
            name="Character Consistency",
            description="Checks that character names are used consistently",
            severity=Severity.ERROR,
            category=RuleCategory.CONTINUITY,
        )

    def validate_content(
        self, content: str, context: Optional[Dict[str, Any]] = None
    ) -> ValidationResult:
        if not context or "character_names" not in context:
            return ValidationResult(
                rule=self, passed=True, message="No character names provided for validation"
            )

        character_names = context["character_names"]
        missing_characters = []

        for name in character_names:
            if name not in content:
                missing_characters.append(name)

        passed = len(missing_characters) == 0

        return ValidationResult(
            rule=self,
            passed=passed,
            message=f"Missing {len(missing_characters)} of {len(character_names)} characters",
            suggestion=(
                f"Incorporate characters: {', '.join(missing_characters)}" if not passed else None
            ),
            context={"missing_characters": missing_characters},
        )


class ChapterOutlineAlignmentRule(ValidationRule):
    """Rule to ensure content aligns with chapter outline."""

    def __init__(self):
        super().__init__(
            rule_id="outline_alignment",
            name="Chapter Outline Alignment",
            description="Checks that chapter content aligns with outline",
            severity=Severity.WARNING,
            category=RuleCategory.STRUCTURE,
        )

    def validate_content(
        self, content: str, context: Optional[Dict[str, Any]] = None
    ) -> ValidationResult:
        if not context or "outline_key_points" not in context:
            return ValidationResult(
                rule=self, passed=True, message="No outline provided for validation"
            )

        key_points = context["outline_key_points"]
        missing_points = []

        for point in key_points:
            if point.lower() not in content.lower():
                missing_points.append(point)

        passed = len(missing_points) == 0

        return ValidationResult(
            rule=self,
            passed=passed,
            message=f"Missing {len(missing_points)} of {len(key_points)} key outline points",
            suggestion=(
                f"Include missing plot points: {', '.join(missing_points[:3])}"
                if not passed
                else None
            ),
            context={"missing_points": missing_points},
        )


class TimelineContinuityRule(ValidationRule):
    """Rule to check timeline continuity."""

    def __init__(self):
        super().__init__(
            rule_id="timeline_continuity",
            name="Timeline Continuity",
            description="Checks for timeline continuity issues",
            severity=Severity.ERROR,
            category=RuleCategory.CONTINUITY,
        )
        self.time_pattern = re.compile(
            r"\b(morning|afternoon|evening|night|midnight|noon|dawn|dusk)\b", re.IGNORECASE
        )

    def validate_content(
        self, content: str, context: Optional[Dict[str, Any]] = None
    ) -> ValidationResult:
        if not context or "chapter_order" not in context:
            return ValidationResult(rule=self, passed=True, message="No timeline context provided")

        time_references = self.time_pattern.findall(content)

        passed = True
        message = f"Found {len(time_references)} time references"

        if len(time_references) > 5:
            passed = False
            message += " (excessive time shifts detected)"

        return ValidationResult(
            rule=self,
            passed=passed,
            message=message,
            suggestion="Review timeline consistency" if not passed else None,
            context={"time_references": time_references},
        )


class PassiveVoiceRule(ValidationRule):
    """Rule to limit passive voice usage."""

    def __init__(self, max_ratio: float = 0.15):
        super().__init__(
            rule_id="passive_voice",
            name="Passive Voice Usage",
            description="Limits passive voice construction usage",
            severity=Severity.WARNING,
            category=RuleCategory.STYLE,
        )
        self.max_ratio = max_ratio
        self.passive_patterns = [
            re.compile(r"\b(was|were|been|being)\s+(\w+ed)\b", re.IGNORECASE),
            re.compile(r"\b(was|were)\s+\w+\s+by\b", re.IGNORECASE),
        ]

    def validate_content(
        self, content: str, context: Optional[Dict[str, Any]] = None
    ) -> ValidationResult:
        sentences = re.split(r"[.!?]+", content)
        total_sentences = len([s for s in sentences if s.strip()])

        passive_count = 0
        for pattern in self.passive_patterns:
            passive_count += len(pattern.findall(content))

        passive_ratio = passive_count / max(total_sentences, 1)
        passed = passive_ratio <= self.max_ratio

        return ValidationResult(
            rule=self,
            passed=passed,
            message=f"Passive voice: {passive_ratio:.1%} (maximum: {self.max_ratio:.1%})",
            suggestion="Rewrite passive constructions as active voice" if not passed else None,
            context={"passive_count": passive_count, "total_sentences": total_sentences},
        )


class AdverbOveruseRule(ValidationRule):
    """Rule to limit adverb usage."""

    def __init__(self, max_ratio: float = 0.08):
        super().__init__(
            rule_id="adverb_overuse",
            name="Adverb Overuse",
            description="Limits excessive adverb usage",
            severity=Severity.WARNING,
            category=RuleCategory.STYLE,
        )
        self.max_ratio = max_ratio
        self.adverb_pattern = re.compile(r"\b\w+ly\b", re.IGNORECASE)

    def validate_content(
        self, content: str, context: Optional[Dict[str, Any]] = None
    ) -> ValidationResult:
        words = re.findall(r"\b[a-zA-Z]+\b", content)
        adverbs = self.adverb_pattern.findall(content)

        adverb_ratio = len(adverbs) / max(len(words), 1)
        passed = adverb_ratio <= self.max_ratio

        return ValidationResult(
            rule=self,
            passed=passed,
            message=f"Adverb usage: {adverb_ratio:.1%} (maximum: {self.max_ratio:.1%})",
            suggestion="Replace adverbs with stronger verbs" if not passed else None,
            context={"adverb_count": len(adverbs), "total_words": len(words)},
        )


class DialogueBalanceRule(ValidationRule):
    """Rule to ensure balanced dialogue and narrative."""

    def __init__(self, min_ratio: float = 0.1, max_ratio: float = 0.7):
        super().__init__(
            rule_id="dialogue_balance",
            name="Dialogue Balance",
            description="Ensures balanced mix of dialogue and narrative",
            severity=Severity.INFO,
            category=RuleCategory.CONTENT,
        )
        self.min_ratio = min_ratio
        self.max_ratio = max_ratio
        self.dialogue_pattern = re.compile(r'"[^"]*"')

    def validate_content(
        self, content: str, context: Optional[Dict[str, Any]] = None
    ) -> ValidationResult:
        dialogue_matches = self.dialogue_pattern.findall(content)
        dialogue_words = sum(len(re.findall(r"\b\w+\b", d)) for d in dialogue_matches)
        total_words = len(re.findall(r"\b\w+\b", content))

        dialogue_ratio = dialogue_words / max(total_words, 1)
        passed = self.min_ratio <= dialogue_ratio <= self.max_ratio

        if dialogue_ratio < self.min_ratio:
            message = f"Dialogue ratio: {dialogue_ratio:.1%} (below minimum: {self.min_ratio:.1%})"
            suggestion = "Consider adding dialogue to improve engagement"
        elif dialogue_ratio > self.max_ratio:
            message = f"Dialogue ratio: {dialogue_ratio:.1%} (above maximum: {self.max_ratio:.1%})"
            suggestion = "Consider adding narrative context"
        else:
            message = f"Dialogue ratio: {dialogue_ratio:.1%} (balanced)"
            suggestion = None

        return ValidationResult(
            rule=self,
            passed=passed,
            message=message,
            suggestion=suggestion,
            context={"dialogue_ratio": dialogue_ratio},
        )


class SceneLengthRule(ValidationRule):
    """Rule to check scene length variation."""

    def __init__(self, min_words: int = 200, max_words: int = 2000):
        super().__init__(
            rule_id="scene_length",
            name="Scene Length",
            description="Checks for appropriate scene lengths",
            severity=Severity.INFO,
            category=RuleCategory.STRUCTURE,
        )
        self.min_words = min_words
        self.max_words = max_words
        self.scene_break_pattern = re.compile(r"\n\s*\n\s*[*#-]{3,}\n|\n\s*\n\s*~{3,}\n")

    def validate_content(
        self, content: str, context: Optional[Dict[str, Any]] = None
    ) -> ValidationResult:
        scenes = self.scene_break_pattern.split(content)
        scenes = [s.strip() for s in scenes if s.strip()]

        if len(scenes) <= 1:
            return ValidationResult(
                rule=self, passed=True, message="Single scene detected", context={"scene_count": 1}
            )

        scene_lengths = [len(re.findall(r"\b\w+\b", scene)) for scene in scenes]
        too_short = [sl for sl in scene_lengths if sl < self.min_words]
        too_long = [sl for sl in scene_lengths if sl > self.max_words]

        passed = len(too_short) == 0 and len(too_long) == 0

        message = f"Scene lengths: {min(scene_lengths)} - {max(scene_lengths)} words"
        if too_short or too_long:
            message += f" ({len(too_short)} too short, {len(too_long)} too long)"

        return ValidationResult(
            rule=self,
            passed=passed,
            message=message,
            suggestion="Adjust scene lengths for better pacing" if not passed else None,
            context={
                "scene_count": len(scenes),
                "too_short": len(too_short),
                "too_long": len(too_long),
            },
        )
