"""
Novel Harness - Comprehensive Logging System

Tracks all LLM requests, responses, token usage, costs, latency, errors, and user actions.
Provides complete audit trails for cost optimization, debugging, and performance monitoring.

Features:
- SQLite storage for structured queries
- JSON logs for human readability
- Token usage tracking and aggregation
- Cost calculation for all providers
- Budget alerts
- Query engine for analytics
"""

from __future__ import annotations

import gzip
import json
import sqlite3
import threading
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum
from pathlib import Path
from typing import Any, Dict, Optional

from core.cost_calculator import CostCalculator
from core.token_tracker import TokenUsageTracker


class LogType(str, Enum):
    """Log entry types"""

    LLM_REQUEST = "llm_request"
    USER_ACTION = "user_action"
    SYSTEM_EVENT = "system_event"
    PROJECT_EVENT = "project_event"


class ActionType(str, Enum):
    """User action types"""

    CLI = "CLI"
    API = "API"
    WEB = "WEB"


class RequestStatus(str, Enum):
    """Request status"""

    SUCCESS = "success"
    ERROR = "error"
    TIMEOUT = "timeout"
    CANCELLED = "cancelled"


@dataclass
class LLMRequest:
    """LLM request data"""

    request_id: str
    project_name: Optional[str]
    agent_name: Optional[str]
    provider: str
    model: str
    system_prompt: str
    user_prompt: str
    max_tokens: int
    temperature: float
    input_tokens: int
    output_tokens: int
    total_tokens: int
    cost_usd: float
    latency_ms: int
    status: RequestStatus
    error_message: Optional[str] = None
    cache_hit: bool = False
    metadata: Dict[str, Any] = field(default_factory=dict)
    timestamp: datetime = field(default_factory=datetime.now)


@dataclass
class UserAction:
    """User action data"""

    action_id: str
    action_type: ActionType
    user_command: str
    project_name: Optional[str]
    parameters: Dict[str, Any]
    result: Optional[str]
    execution_time_ms: int
    success: bool
    timestamp: datetime = field(default_factory=datetime.now)


class JSONLogger:
    """JSON file logger for human-readable logs"""

    def __init__(self, log_dir: str = ".logs/json"):
        self.log_dir = Path(log_dir)
        self.log_dir.mkdir(parents=True, exist_ok=True)
        self._lock = threading.Lock()

    def log(self, entry: Dict[str, Any]):
        """Write log entry to JSON file"""
        with self._lock:
            date_str = datetime.now().strftime("%Y-%m-%d")
            log_file = self.log_dir / f"{date_str}.jsonl"

            with open(log_file, "a", encoding="utf-8") as f:
                f.write(json.dumps(entry, default=str) + "\n")

    def rotate_old_logs(self, days: int = 90):
        """Compress log files older than specified days"""
        cutoff = datetime.now() - timedelta(days=days)

        for log_file in self.log_dir.glob("*.jsonl"):
            if log_file.stat().st_mtime < cutoff.timestamp():
                # Compress the file
                compressed = log_file.with_suffix(".jsonl.gz")
                with open(log_file, "rb") as f_in:
                    with gzip.open(compressed, "wb") as f_out:
                        f_out.writelines(f_in)
                log_file.unlink()


class SQLiteLogger:
    """SQLite database logger for structured queries"""

    def __init__(self, db_path: str = ".logs/logs.db"):
        self.db_path = Path(db_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._init_db()
        self._lock = threading.Lock()

    def _init_db(self):
        """Initialize database schema"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()

        # LLM Requests table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS llm_requests (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                request_id TEXT UNIQUE NOT NULL,
                timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                project_name TEXT,
                agent_name TEXT,
                provider TEXT NOT NULL,
                model TEXT NOT NULL,
                system_prompt TEXT,
                user_prompt TEXT,
                max_tokens INTEGER,
                temperature REAL,
                input_tokens INTEGER,
                output_tokens INTEGER,
                total_tokens INTEGER,
                cost_usd REAL,
                latency_ms INTEGER,
                status TEXT NOT NULL,
                error_message TEXT,
                cache_hit INTEGER DEFAULT 0,
                metadata TEXT
            )
        """)

        # User Actions table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS user_actions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                action_id TEXT UNIQUE NOT NULL,
                timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                action_type TEXT NOT NULL,
                user_command TEXT,
                project_name TEXT,
                parameters TEXT,
                result TEXT,
                execution_time_ms INTEGER,
                success INTEGER
            )
        """)

        # Token Usage Summary table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS token_usage (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                date DATE NOT NULL,
                project_name TEXT,
                provider TEXT NOT NULL,
                model TEXT NOT NULL,
                total_input_tokens INTEGER DEFAULT 0,
                total_output_tokens INTEGER DEFAULT 0,
                total_tokens INTEGER DEFAULT 0,
                total_cost_usd REAL DEFAULT 0.0,
                request_count INTEGER DEFAULT 0,
                UNIQUE(date, project_name, provider, model)
            )
        """)

        # Projects table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS projects (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                project_name TEXT NOT NULL,
                action TEXT NOT NULL,
                details TEXT
            )
        """)

        # Create indexes for faster queries
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_llm_timestamp ON llm_requests(timestamp)")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_llm_project ON llm_requests(project_name)")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_llm_provider ON llm_requests(provider)")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_llm_status ON llm_requests(status)")
        cursor.execute(
            "CREATE INDEX IF NOT EXISTS idx_actions_timestamp ON user_actions(timestamp)"
        )
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_token_date ON token_usage(date)")

        conn.commit()
        conn.close()

    def log_llm_request(self, request: LLMRequest):
        """Log LLM request to database"""
        with self._lock:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()

            cursor.execute(
                """
                INSERT INTO llm_requests (
                    request_id, project_name, agent_name, provider, model,
                    system_prompt, user_prompt, max_tokens, temperature,
                    input_tokens, output_tokens, total_tokens, cost_usd,
                    latency_ms, status, error_message, cache_hit, metadata
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
                (
                    request.request_id,
                    request.project_name,
                    request.agent_name,
                    request.provider,
                    request.model,
                    request.system_prompt,
                    request.user_prompt,
                    request.max_tokens,
                    request.temperature,
                    request.input_tokens,
                    request.output_tokens,
                    request.total_tokens,
                    request.cost_usd,
                    request.latency_ms,
                    request.status.value,
                    request.error_message,
                    1 if request.cache_hit else 0,
                    json.dumps(request.metadata),
                ),
            )

            conn.commit()
            conn.close()

    def log_user_action(self, action: UserAction):
        """Log user action to database"""
        with self._lock:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()

            cursor.execute(
                """
                INSERT INTO user_actions (
                    action_id, action_type, user_command, project_name,
                    parameters, result, execution_time_ms, success
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """,
                (
                    action.action_id,
                    action.action_type.value,
                    action.user_command,
                    action.project_name,
                    json.dumps(action.parameters),
                    action.result,
                    action.execution_time_ms,
                    1 if action.success else 0,
                ),
            )

            conn.commit()
            conn.close()

    def log_project_event(self, project_name: str, action: str, details: Dict[str, Any]):
        """Log project event"""
        with self._lock:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()

            cursor.execute(
                """
                INSERT INTO projects (project_name, action, details)
                VALUES (?, ?, ?)
            """,
                (project_name, action, json.dumps(details)),
            )

            conn.commit()
            conn.close()

    def update_token_summary(self, request: LLMRequest):
        """Update daily token usage summary"""
        with self._lock:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()

            date_str = datetime.now().strftime("%Y-%m-%d")

            cursor.execute(
                """
                INSERT INTO token_usage (
                    date, project_name, provider, model,
                    total_input_tokens, total_output_tokens, total_tokens,
                    total_cost_usd, request_count
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(date, project_name, provider, model) DO UPDATE SET
                    total_input_tokens = total_input_tokens + excluded.total_input_tokens,
                    total_output_tokens = total_output_tokens + excluded.total_output_tokens,
                    total_tokens = total_tokens + excluded.total_tokens,
                    total_cost_usd = total_cost_usd + excluded.total_cost_usd,
                    request_count = request_count + excluded.request_count
            """,
                (
                    date_str,
                    request.project_name,
                    request.provider,
                    request.model,
                    request.input_tokens,
                    request.output_tokens,
                    request.total_tokens,
                    request.cost_usd,
                    1,
                ),
            )

            conn.commit()
            conn.close()


class NovelHarnessLogger:
    """
    Central logging system for Novel Harness.

    Tracks:
    - LLM requests and responses
    - Token usage and costs
    - User actions
    - Project events

    Access via:
    - Direct Python API
    - CLI commands
    - API endpoints
    """

    _instance: Optional[NovelHarnessLogger] = None
    _lock = threading.Lock()

    def __init__(
        self,
        storage_path: str = ".logs",
        enable_json_logs: bool = True,
        enable_sqlite_logs: bool = True,
    ):
        """Initialize the logger system"""
        self.storage_path = Path(storage_path)
        self.storage_path.mkdir(parents=True, exist_ok=True)

        self.enable_json_logs = enable_json_logs
        self.enable_sqlite_logs = enable_sqlite_logs

        # Initialize components
        if enable_sqlite_logs:
            self.db_logger = SQLiteLogger(str(self.storage_path / "logs.db"))
        else:
            self.db_logger = None

        if enable_json_logs:
            self.json_logger = JSONLogger(str(self.storage_path / "json"))
        else:
            self.json_logger = None

        # Initialize helpers
        self.cost_calculator = CostCalculator()
        self.token_tracker = TokenUsageTracker(self.db_logger) if self.db_logger else None

    @classmethod
    def get_instance(cls) -> NovelHarnessLogger:
        """Get singleton instance"""
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    cls._instance = cls()
        return cls._instance

    def log_llm_request(
        self,
        provider: str,
        model: str,
        input_tokens: int,
        output_tokens: int,
        latency_ms: int,
        project_name: Optional[str] = None,
        agent_name: Optional[str] = None,
        system_prompt: str = "",
        user_prompt: str = "",
        max_tokens: int = 4000,
        temperature: float = 0.7,
        cache_hit: bool = False,
        error: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> str:
        """
        Log an LLM request.

        Args:
            provider: LLM provider (openai, anthropic, google)
            model: Model name
            input_tokens: Number of input tokens
            output_tokens: Number of output tokens
            latency_ms: Request latency in milliseconds
            project_name: Optional project name
            agent_name: Optional agent name
            system_prompt: System prompt used
            user_prompt: User prompt used
            max_tokens: Max tokens requested
            temperature: Temperature setting
            cache_hit: Whether response was from cache
            error: Optional error message
            metadata: Optional additional metadata

        Returns:
            Request ID for the logged request
        """
        request_id = f"req_{uuid.uuid4().hex[:12]}"
        total_tokens = input_tokens + output_tokens

        # Calculate cost
        cost_usd = self.cost_calculator.calculate(provider, model, input_tokens, output_tokens)

        # Determine status
        if error:
            status = RequestStatus.ERROR
        elif cache_hit:
            status = RequestStatus.SUCCESS
        else:
            status = RequestStatus.SUCCESS

        # Create request object
        request = LLMRequest(
            request_id=request_id,
            project_name=project_name,
            agent_name=agent_name,
            provider=provider,
            model=model,
            system_prompt=system_prompt,
            user_prompt=user_prompt,
            max_tokens=max_tokens,
            temperature=temperature,
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            total_tokens=total_tokens,
            cost_usd=cost_usd,
            latency_ms=latency_ms,
            status=status,
            error_message=error,
            cache_hit=cache_hit,
            metadata=metadata or {},
        )

        # Log to SQLite
        if self.db_logger:
            self.db_logger.log_llm_request(request)
            self.db_logger.update_token_summary(request)

        # Log to JSON
        if self.json_logger:
            self.json_logger.log(self._request_to_json(request))

        return request_id

    def log_user_action(
        self,
        action_type: ActionType,
        user_command: str,
        project_name: Optional[str] = None,
        parameters: Optional[Dict[str, Any]] = None,
        result: Optional[str] = None,
        execution_time_ms: int = 0,
        success: bool = True,
    ) -> str:
        """
        Log a user action.

        Args:
            action_type: Type of action (CLI, API, WEB)
            user_command: Command or request made
            project_name: Optional project name
            parameters: Action parameters
            result: Action result
            execution_time_ms: Execution time in milliseconds
            success: Whether action succeeded

        Returns:
            Action ID for the logged action
        """
        action_id = f"act_{uuid.uuid4().hex[:12]}"

        action = UserAction(
            action_id=action_id,
            action_type=action_type,
            user_command=user_command,
            project_name=project_name,
            parameters=parameters or {},
            result=result,
            execution_time_ms=execution_time_ms,
            success=success,
        )

        # Log to SQLite
        if self.db_logger:
            self.db_logger.log_user_action(action)

        # Log to JSON
        if self.json_logger:
            self.json_logger.log(self._action_to_json(action))

        return action_id

    def log_project_created(self, project_name: str, genre: str, target_words: int):
        """Log project creation"""
        if self.db_logger:
            self.db_logger.log_project_event(
                project_name, "created", {"genre": genre, "target_words": target_words}
            )

    def log_project_deleted(self, project_name: str):
        """Log project deletion"""
        if self.db_logger:
            self.db_logger.log_project_event(project_name, "deleted", {})

    def _request_to_json(self, request: LLMRequest) -> Dict[str, Any]:
        """Convert request to JSON-serializable dict"""
        return {
            "version": "1.0",
            "type": LogType.LLM_REQUEST.value,
            "timestamp": request.timestamp.isoformat(),
            "request_id": request.request_id,
            "project": request.project_name,
            "agent": request.agent_name,
            "provider": request.provider,
            "model": request.model,
            "request": {
                "system_prompt": request.system_prompt[:500] if request.system_prompt else "",
                "user_prompt": request.user_prompt[:500] if request.user_prompt else "",
                "max_tokens": request.max_tokens,
                "temperature": request.temperature,
            },
            "usage": {
                "input_tokens": request.input_tokens,
                "output_tokens": request.output_tokens,
                "total_tokens": request.total_tokens,
                "cost_usd": request.cost_usd,
            },
            "performance": {"latency_ms": request.latency_ms, "cache_hit": request.cache_hit},
            "status": request.status.value,
            "error": request.error_message,
        }

    def _action_to_json(self, action: UserAction) -> Dict[str, Any]:
        """Convert action to JSON-serializable dict"""
        return {
            "version": "1.0",
            "type": LogType.USER_ACTION.value,
            "timestamp": action.timestamp.isoformat(),
            "action_id": action.action_id,
            "action_type": action.action_type.value,
            "user_command": action.user_command,
            "project": action.project_name,
            "parameters": action.parameters,
            "result": action.result,
            "execution_time_ms": action.execution_time_ms,
            "success": action.success,
        }

    def get_stats(self) -> Dict[str, Any]:
        """Get logging statistics"""
        if not self.db_logger:
            return {"error": "SQLite logging disabled"}

        conn = sqlite3.connect(self.db_logger.db_path)
        cursor = conn.cursor()

        # Total requests
        cursor.execute("SELECT COUNT(*) FROM llm_requests")
        total_requests = cursor.fetchone()[0]

        # Total tokens
        cursor.execute("SELECT COALESCE(SUM(total_tokens), 0) FROM llm_requests")
        total_tokens = cursor.fetchone()[0]

        # Total cost
        cursor.execute("SELECT COALESCE(SUM(cost_usd), 0) FROM llm_requests")
        total_cost = cursor.fetchone()[0]

        # Error count
        cursor.execute("SELECT COUNT(*) FROM llm_requests WHERE status = 'error'")
        error_count = cursor.fetchone()[0]

        # User actions
        cursor.execute("SELECT COUNT(*) FROM user_actions")
        total_actions = cursor.fetchone()[0]

        # Recent requests (last 24h)
        cursor.execute("""
            SELECT COUNT(*) FROM llm_requests
            WHERE timestamp > datetime('now', '-1 day')
        """)
        recent_requests = cursor.fetchone()[0]

        conn.close()

        return {
            "total_requests": total_requests,
            "total_tokens": total_tokens,
            "total_cost_usd": round(total_cost, 4),
            "error_count": error_count,
            "error_rate": round(error_count / total_requests * 100, 2) if total_requests > 0 else 0,
            "total_actions": total_actions,
            "recent_requests_24h": recent_requests,
        }


# Global logger instance
_logger: Optional[NovelHarnessLogger] = None


def get_logger() -> NovelHarnessLogger:
    """Get the global logger instance"""
    global _logger
    if _logger is None:
        _logger = NovelHarnessLogger.get_instance()
    return _logger


def log_llm_request(**kwargs) -> str:
    """Convenience function to log LLM request"""
    return get_logger().log_llm_request(**kwargs)


def log_user_action(**kwargs) -> str:
    """Convenience function to log user action"""
    return get_logger().log_user_action(**kwargs)
