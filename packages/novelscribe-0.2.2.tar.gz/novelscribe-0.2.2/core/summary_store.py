"""
Summary Storage Implementation for Phase 4.2

Provides hierarchical storage for chapter summaries, group summaries,
and global summaries with efficient retrieval and management.
"""

import json
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

import yaml
from pydantic import BaseModel


@dataclass
class ChapterSummary:
    """Summary of a single chapter."""

    chapter_number: int
    summary: str
    key_events: List[str]
    characters: Dict[str, str]
    locations: Dict[str, str]
    plot_advancement: str
    next_chapter_setup: str
    created_at: datetime
    word_count: int = 0

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for serialization."""
        return {
            "chapter_number": self.chapter_number,
            "summary": self.summary,
            "key_events": self.key_events,
            "characters": self.characters,
            "locations": self.locations,
            "plot_advancement": self.plot_advancement,
            "next_chapter_setup": self.next_chapter_setup,
            "created_at": self.created_at.isoformat(),
            "word_count": self.word_count,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "ChapterSummary":
        """Create from dictionary."""
        return cls(
            chapter_number=data["chapter_number"],
            summary=data["summary"],
            key_events=data["key_events"],
            characters=data["characters"],
            locations=data["locations"],
            plot_advancement=data["plot_advancement"],
            next_chapter_setup=data["next_chapter_setup"],
            created_at=datetime.fromisoformat(data["created_at"]),
            word_count=data.get("word_count", 0),
        )


@dataclass
class GroupSummary:
    """Summary of a group of chapters (typically 5)."""

    group_id: str
    start_chapter: int
    end_chapter: int
    summary: str
    combined_events: List[str]
    character_arcs: Dict[str, str]
    plot_developments: List[str]
    created_at: datetime
    total_word_count: int = 0

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for serialization."""
        return {
            "group_id": self.group_id,
            "start_chapter": self.start_chapter,
            "end_chapter": self.end_chapter,
            "summary": self.summary,
            "combined_events": self.combined_events,
            "character_arcs": self.character_arcs,
            "plot_developments": self.plot_developments,
            "created_at": self.created_at.isoformat(),
            "total_word_count": self.total_word_count,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "GroupSummary":
        """Create from dictionary."""
        return cls(
            group_id=data["group_id"],
            start_chapter=data["start_chapter"],
            end_chapter=data["end_chapter"],
            summary=data["summary"],
            combined_events=data["combined_events"],
            character_arcs=data["character_arcs"],
            plot_developments=data["plot_developments"],
            created_at=datetime.fromisoformat(data["created_at"]),
            total_word_count=data.get("total_word_count", 0),
        )


@dataclass
class GlobalSummary:
    """Global summary of the entire novel."""

    project_name: str
    summary: str
    main_plot_arc: str
    character_arcs: Dict[str, str]
    world_development: str
    themes: List[str]
    last_updated: datetime
    total_chapters_covered: int
    total_word_count: int = 0

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for serialization."""
        return {
            "project_name": self.project_name,
            "summary": self.summary,
            "main_plot_arc": self.main_plot_arc,
            "character_arcs": self.character_arcs,
            "world_development": self.world_development,
            "themes": self.themes,
            "last_updated": self.last_updated.isoformat(),
            "total_chapters_covered": self.total_chapters_covered,
            "total_word_count": self.total_word_count,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "GlobalSummary":
        """Create from dictionary."""
        return cls(
            project_name=data["project_name"],
            summary=data["summary"],
            main_plot_arc=data["main_plot_arc"],
            character_arcs=data["character_arcs"],
            world_development=data["world_development"],
            themes=data["themes"],
            last_updated=datetime.fromisoformat(data["last_updated"]),
            total_chapters_covered=data["total_chapters_covered"],
            total_word_count=data.get("total_word_count", 0),
        )


class SummaryStoreConfig(BaseModel):
    """Configuration for summary storage."""

    storage_format: str = "yaml"  # yaml or json
    auto_backup: bool = True
    backup_count: int = 3
    compress_old_summaries: bool = False


class SummaryStore:
    """
    Storage layer for hierarchical summaries.

    Manages chapter summaries, group summaries, and global summaries
    with efficient serialization and retrieval.
    """

    def __init__(self, project_root: Path, config: Optional[SummaryStoreConfig] = None):
        """
        Initialize summary store.

        Args:
            project_root: Path to project directory
            config: Storage configuration
        """
        self.project_root = Path(project_root)
        self.config = config or SummaryStoreConfig()

        self.summaries_dir = self.project_root / "summaries"
        self.chapters_dir = self.summaries_dir / "chapters"
        self.groups_dir = self.summaries_dir / "groups"

        self._ensure_directories()

    def _current_timestamp(self) -> str:
        return datetime.now().strftime("%Y%m%d_%H%M%S")

    def _save_data(self, file_path: Path, data: Dict[str, Any]):
        if self.config.storage_format == "yaml":
            self._save_yaml(file_path, data)
            return
        if self.config.storage_format == "json":
            self._save_json(file_path, data)
            return
        raise ValueError(f"Unsupported storage format: {self.config.storage_format}")

    def _load_data(self, file_path: Path) -> Optional[Dict[str, Any]]:
        if self.config.storage_format == "yaml":
            return self._load_yaml(file_path)
        if self.config.storage_format == "json":
            return self._load_json(file_path)
        raise ValueError(f"Unsupported storage format: {self.config.storage_format}")

    def _ensure_directories(self):
        """Create necessary directories if they don't exist."""
        self.chapters_dir.mkdir(parents=True, exist_ok=True)
        self.groups_dir.mkdir(parents=True, exist_ok=True)

    def _get_chapter_summary_path(self, chapter_number: int) -> Path:
        """Get file path for chapter summary."""
        filename = f"chapter_{chapter_number:03d}.{self.config.storage_format}"
        return self.chapters_dir / filename

    def _get_group_summary_path(self, group_id: str) -> Path:
        """Get file path for group summary."""
        filename = f"{group_id}.{self.config.storage_format}"
        return self.groups_dir / filename

    def _get_global_summary_path(self) -> Path:
        """Get file path for global summary."""
        filename = f"global_summary.{self.config.storage_format}"
        return self.summaries_dir / filename

    def _backup_file(self, file_path: Path):
        """Create backup of file before overwriting."""
        if not self.config.auto_backup or not file_path.exists():
            return

        timestamp = self._current_timestamp()
        backup_path = file_path.parent / f"{file_path.stem}.backup_{timestamp}{file_path.suffix}"

        import shutil

        shutil.copy2(file_path, backup_path)

        self._cleanup_old_backups(file_path)

    def _cleanup_old_backups(self, file_path: Path):
        """Remove old backups beyond backup_count."""
        backups = sorted(
            file_path.parent.glob(f"{file_path.stem}.backup_*{file_path.suffix}"),
            key=lambda p: p.stat().st_mtime,
            reverse=True,
        )

        for old_backup in backups[self.config.backup_count :]:
            old_backup.unlink()

    def _save_yaml(self, file_path: Path, data: Dict[str, Any]):
        """Save data as YAML."""
        self._backup_file(file_path)
        with open(file_path, "w", encoding="utf-8") as f:
            yaml.dump(data, f, default_flow_style=False, sort_keys=False)

    def _load_yaml(self, file_path: Path) -> Optional[Dict[str, Any]]:
        """Load YAML data."""
        if not file_path.exists():
            return None
        with open(file_path, "r", encoding="utf-8") as f:
            return yaml.safe_load(f)

    def _save_json(self, file_path: Path, data: Dict[str, Any]):
        """Save data as JSON."""
        self._backup_file(file_path)
        with open(file_path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)

    def _load_json(self, file_path: Path) -> Optional[Dict[str, Any]]:
        """Load JSON data."""
        if not file_path.exists():
            return None
        with open(file_path, "r", encoding="utf-8") as f:
            return json.load(f)

    def save_chapter_summary(self, summary: ChapterSummary):
        """
        Save chapter summary to storage.

        Args:
            summary: Chapter summary to save
        """
        file_path = self._get_chapter_summary_path(summary.chapter_number)
        data = summary.to_dict()
        self._save_data(file_path, data)

    def load_chapter_summary(self, chapter_number: int) -> Optional[ChapterSummary]:
        """
        Load chapter summary from storage.

        Args:
            chapter_number: Chapter number to load

        Returns:
            Chapter summary or None if not found
        """
        file_path = self._get_chapter_summary_path(chapter_number)
        data = self._load_data(file_path)

        if data is None:
            return None

        return ChapterSummary.from_dict(data)

    def save_group_summary(self, summary: GroupSummary):
        """
        Save group summary to storage.

        Args:
            summary: Group summary to save
        """
        file_path = self._get_group_summary_path(summary.group_id)
        data = summary.to_dict()
        self._save_data(file_path, data)

    def load_group_summary(self, group_id: str) -> Optional[GroupSummary]:
        """
        Load group summary from storage.

        Args:
            group_id: Group ID to load

        Returns:
            Group summary or None if not found
        """
        file_path = self._get_group_summary_path(group_id)
        data = self._load_data(file_path)

        if data is None:
            return None

        return GroupSummary.from_dict(data)

    def save_global_summary(self, summary: GlobalSummary):
        """
        Save global summary to storage.

        Args:
            summary: Global summary to save
        """
        file_path = self._get_global_summary_path()
        data = summary.to_dict()
        self._save_data(file_path, data)

    def load_global_summary(self) -> Optional[GlobalSummary]:
        """
        Load global summary from storage.

        Returns:
            Global summary or None if not found
        """
        file_path = self._get_global_summary_path()
        data = self._load_data(file_path)

        if data is None:
            return None

        return GlobalSummary.from_dict(data)

    def list_chapter_summaries(self) -> List[int]:
        """
        List all available chapter summaries.

        Returns:
            List of chapter numbers with summaries
        """
        summaries = []

        for file_path in self.chapters_dir.glob(f"chapter_*.{self.config.storage_format}"):
            try:
                chapter_num = int(file_path.stem.split("_")[1])
                summaries.append(chapter_num)
            except (ValueError, IndexError):
                continue

        return sorted(summaries)

    def list_group_summaries(self) -> List[str]:
        """
        List all available group summaries.

        Returns:
            List of group IDs
        """
        summaries = []

        for file_path in self.groups_dir.glob(f"*.{self.config.storage_format}"):
            if file_path.stem.startswith("chapters_"):
                summaries.append(file_path.stem)

        return sorted(summaries)

    def get_summary_statistics(self) -> Dict[str, Any]:
        """
        Get statistics about stored summaries.

        Returns:
            Dictionary with summary statistics
        """
        chapter_summaries = self.list_chapter_summaries()
        group_summaries = self.list_group_summaries()

        total_chapters = len(chapter_summaries)
        total_groups = len(group_summaries)

        total_words = 0
        for chapter_num in chapter_summaries:
            summary = self.load_chapter_summary(chapter_num)
            if summary:
                total_words += summary.word_count

        has_global_summary = self._get_global_summary_path().exists()

        return {
            "chapter_summaries": total_chapters,
            "group_summaries": total_groups,
            "has_global_summary": has_global_summary,
            "total_words_summarized": total_words,
            "storage_format": self.config.storage_format,
            "summaries_directory": str(self.summaries_dir),
        }

    def delete_chapter_summary(self, chapter_number: int):
        """
        Delete a chapter summary.

        Args:
            chapter_number: Chapter number to delete
        """
        file_path = self._get_chapter_summary_path(chapter_number)
        if file_path.exists():
            file_path.unlink()

    def delete_group_summary(self, group_id: str):
        """
        Delete a group summary.

        Args:
            group_id: Group ID to delete
        """
        file_path = self._get_group_summary_path(group_id)
        if file_path.exists():
            file_path.unlink()

    def export_summaries(self, output_path: Path, format_type: str = "markdown"):
        """
        Export all summaries to a single file.

        Args:
            output_path: Output file path
            format_type: Export format (markdown, json, yaml)
        """
        chapter_summaries = sorted(
            [self.load_chapter_summary(n) for n in self.list_chapter_summaries()],
            key=lambda s: s.chapter_number if s else 0,
        )

        group_summaries = sorted(
            [self.load_group_summary(gid) for gid in self.list_group_summaries()],
            key=lambda s: s.start_chapter if s else 0,
        )

        global_summary = self.load_global_summary()

        if format_type == "markdown":
            self._export_markdown(output_path, chapter_summaries, group_summaries, global_summary)
        elif format_type == "json":
            self._export_json(output_path, chapter_summaries, group_summaries, global_summary)
        elif format_type == "yaml":
            self._export_yaml(output_path, chapter_summaries, group_summaries, global_summary)

    def _export_markdown(
        self,
        output_path: Path,
        chapter_summaries: List[Optional[ChapterSummary]],
        group_summaries: List[Optional[GroupSummary]],
        global_summary: Optional[GlobalSummary],
    ):
        """Export summaries as markdown."""
        with open(output_path, "w", encoding="utf-8") as f:
            f.write("# Novel Summaries\n\n")

            if global_summary:
                f.write("## Global Summary\n\n")
                f.write(f"{global_summary.summary}\n\n")
                f.write(f"**Chapters Covered**: {global_summary.total_chapters_covered}\n\n")

            if group_summaries:
                f.write("## Group Summaries\n\n")
                for group in group_summaries:
                    if group:
                        f.write(f"### Chapters {group.start_chapter}-{group.end_chapter}\n\n")
                        f.write(f"{group.summary}\n\n")

            if chapter_summaries:
                f.write("## Chapter Summaries\n\n")
                for summary in chapter_summaries:
                    if summary:
                        f.write(f"### Chapter {summary.chapter_number}\n\n")
                        f.write(f"{summary.summary}\n\n")
                        if summary.key_events:
                            f.write("**Key Events**:\n")
                            for event in summary.key_events:
                                f.write(f"- {event}\n")
                            f.write("\n")

    def _export_json(
        self,
        output_path: Path,
        chapter_summaries: List[Optional[ChapterSummary]],
        group_summaries: List[Optional[GroupSummary]],
        global_summary: Optional[GlobalSummary],
    ):
        """Export summaries as JSON."""
        data = {
            "global_summary": global_summary.to_dict() if global_summary else None,
            "group_summaries": [g.to_dict() for g in group_summaries if g],
            "chapter_summaries": [s.to_dict() for s in chapter_summaries if s],
        }

        with open(output_path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)

    def _export_yaml(
        self,
        output_path: Path,
        chapter_summaries: List[Optional[ChapterSummary]],
        group_summaries: List[Optional[GroupSummary]],
        global_summary: Optional[GlobalSummary],
    ):
        """Export summaries as YAML."""
        data = {
            "global_summary": global_summary.to_dict() if global_summary else None,
            "group_summaries": [g.to_dict() for g in group_summaries if g],
            "chapter_summaries": [s.to_dict() for s in chapter_summaries if s],
        }

        with open(output_path, "w", encoding="utf-8") as f:
            yaml.dump(data, f, default_flow_style=False, sort_keys=False)
