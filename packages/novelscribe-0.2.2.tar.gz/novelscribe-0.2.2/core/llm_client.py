"""Multi-runtime LLM client for novel harness.

Supports OpenAI, Claude, Gemini, Ollama, and LM Studio providers.
"""

from __future__ import annotations

import os
from abc import ABC, abstractmethod
from enum import Enum

from pydantic import BaseModel

# External library type stubs have compatibility issues
# that don't affect runtime behavior


class LLMProvider(Enum):
    """Supported LLM providers."""

    OPENAI = "openai"
    CLAUDE = "claude"
    GEMINI = "gemini"
    OLLAMA = "ollama"
    LM_STUDIO = "lm_studio"

    def max_context_tokens(self) -> int:
        """Return maximum context tokens for this provider."""
        limits = {
            LLMProvider.OPENAI: 128000,
            LLMProvider.CLAUDE: 200000,
            LLMProvider.GEMINI: 1000000,
            LLMProvider.OLLAMA: 8192,
            LLMProvider.LM_STUDIO: 8192,
        }
        return limits.get(self, 8192)


class LLMError(Exception):
    """Base exception for LLM operations."""


class ProviderNotFoundError(LLMError):
    """Raised when LLM provider is not found."""


class LLMConfig(BaseModel):
    """Configuration for LLM client."""

    provider: str = "openai"
    model: str = "gpt-4o"
    temperature: float = 0.7
    max_tokens: int = 4096
    api_key: str = ""
    base_url: str = ""
    timeout: int = 120
    streaming: bool = False


class LLMResponse(BaseModel):
    """Response from LLM provider."""

    content: str
    model: str
    provider: str
    tokens_used: int | None = None
    finish_reason: str | None = None


class LLMClient(ABC):
    """Abstract base class for LLM clients."""

    def __init__(self, config: LLMConfig):
        self.config = config
        self.provider_name = config.provider

    @abstractmethod
    def generate(self, system_prompt: str, user_prompt: str) -> LLMResponse:
        """Generate response from LLM."""

    @abstractmethod
    def generate_with_history(self, messages: list[dict[str, str]]) -> LLMResponse:
        """Generate response from conversation history."""

    @abstractmethod
    def validate_config(self) -> bool:
        """Validate client configuration."""

    def _format_messages(self, system_prompt: str, user_prompt: str) -> list[dict[str, str]]:
        """Format prompts as message list."""
        messages = []
        if system_prompt:
            messages.append({"role": "system", "content": system_prompt})
        if user_prompt:
            messages.append({"role": "user", "content": user_prompt})
        return messages


class OpenAIClient(LLMClient):
    """OpenAI provider client."""

    def __init__(self, config: LLMConfig):
        super().__init__(config)
        try:
            import openai

            self.openai = openai
            api_key = config.api_key or os.getenv("OPENAI_API_KEY", "")
            base_url = config.base_url or os.getenv("OPENAI_API_BASE", "")

            # Support custom base_url for OpenAI-compatible APIs (GLM, Minimax, etc.)
            client_kwargs = {"api_key": api_key, "timeout": config.timeout}
            if base_url:
                client_kwargs["base_url"] = base_url

            self.client = openai.OpenAI(**client_kwargs)
        except ImportError:
            raise LLMError("OpenAI package not installed. Install with: pip install openai")

    def validate_config(self) -> bool:
        """Validate OpenAI configuration."""
        return bool(self.config.api_key or os.getenv("OPENAI_API_KEY"))

    def generate(self, system_prompt: str, user_prompt: str) -> LLMResponse:
        """Generate response using OpenAI API."""
        if not self.validate_config():
            raise LLMError("OpenAI API key not configured")

        messages = self._format_messages(system_prompt, user_prompt)

        try:
            response = self.client.chat.completions.create(
                model=self.config.model,
                messages=messages,
                temperature=self.config.temperature,
                max_tokens=self.config.max_tokens,
            )

            return LLMResponse(
                content=response.choices[0].message.content,
                model=response.model,
                provider=self.provider_name,
                tokens_used=response.usage.total_tokens if response.usage else None,
                finish_reason=response.choices[0].finish_reason,
            )
        except Exception as e:
            raise LLMError(f"OpenAI API error: {e}") from e

    def generate_with_history(self, messages: list[dict[str, str]]) -> LLMResponse:
        """Generate response using conversation history."""
        if not self.validate_config():
            raise LLMError("OpenAI API key not configured")

        try:
            response = self.client.chat.completions.create(
                model=self.config.model,
                messages=messages,
                temperature=self.config.temperature,
                max_tokens=self.config.max_tokens,
            )

            return LLMResponse(
                content=response.choices[0].message.content,
                model=response.model,
                provider=self.provider_name,
                tokens_used=response.usage.total_tokens if response.usage else None,
                finish_reason=response.choices[0].finish_reason,
            )
        except Exception as e:
            raise LLMError(f"OpenAI API error: {e}") from e


class ClaudeClient(LLMClient):
    """Anthropic Claude provider client."""

    def __init__(self, config: LLMConfig):
        super().__init__(config)
        try:
            import anthropic

            self.client = anthropic.Anthropic(api_key=config.api_key, timeout=config.timeout)
        except ImportError:
            raise LLMError("Anthropic package not installed. Install with: pip install anthropic")

    def validate_config(self) -> bool:
        """Validate Claude configuration."""
        return bool(self.config.api_key or os.getenv("ANTHROPIC_API_KEY"))

    def generate(self, system_prompt: str, user_prompt: str) -> LLMResponse:
        """Generate response using Claude API."""
        if not self.validate_config():
            raise LLMError("Anthropic API key not configured")

        try:
            response = self.client.messages.create(
                model=self.config.model,
                max_tokens=self.config.max_tokens,
                temperature=self.config.temperature,
                system=system_prompt,
                messages=[{"role": "user", "content": user_prompt}],
            )

            return LLMResponse(
                content=response.content[0].text,
                model=response.model,
                provider=self.provider_name,
                tokens_used=response.usage.input_tokens + response.usage.output_tokens,
                finish_reason=response.stop_reason,
            )
        except Exception as e:
            raise LLMError(f"Claude API error: {e}") from e

    def generate_with_history(self, messages: list[dict[str, str]]) -> LLMResponse:
        """Generate response using conversation history."""
        if not self.validate_config():
            raise LLMError("Anthropic API key not configured")

        system_prompt = ""
        formatted_messages = []

        for msg in messages:
            if msg["role"] == "system":
                system_prompt = msg["content"]
            else:
                formatted_messages.append(msg)

        try:
            response = self.client.messages.create(
                model=self.config.model,
                max_tokens=self.config.max_tokens,
                temperature=self.config.temperature,
                system=system_prompt,
                messages=formatted_messages,
            )

            return LLMResponse(
                content=response.content[0].text,
                model=response.model,
                provider=self.provider_name,
                tokens_used=response.usage.input_tokens + response.usage.output_tokens,
                finish_reason=response.stop_reason,
            )
        except Exception as e:
            raise LLMError(f"Claude API error: {e}") from e


class GeminiClient(LLMClient):
    """Google Gemini provider client."""

    def __init__(self, config: LLMConfig):
        super().__init__(config)
        try:
            from google import genai
            from google.genai import types as genai_types

            client = genai.Client(api_key=config.api_key)
            self.client = client
            self.genai_types = genai_types
        except ImportError:
            raise LLMError(
                "Google Gemini package not installed. Install with: pip install google-genai"
            )

    def validate_config(self) -> bool:
        """Validate Gemini configuration."""
        return bool(self.config.api_key or os.getenv("GOOGLE_API_KEY"))

    def generate(self, system_prompt: str, user_prompt: str) -> LLMResponse:
        """Generate response using Gemini API."""
        if not self.validate_config():
            raise LLMError("Google API key not configured")

        try:
            combined_prompt = f"{system_prompt}\n\n{user_prompt}" if system_prompt else user_prompt

            response = self.client.models.generate_content(
                model=self.config.model,
                contents=combined_prompt,
                config=self.genai_types.GenerateContentConfig(
                    temperature=self.config.temperature,
                    max_output_tokens=self.config.max_tokens,
                ),
            )

            return LLMResponse(
                content=response.text,
                model=self.config.model,
                provider=self.provider_name,
                tokens_used=(
                    response.usage_metadata.total_token_count
                    if hasattr(response, "usage_metadata")
                    else None
                ),
                finish_reason=(
                    response.candidates[0].finish_reason.name if response.candidates else None
                ),
            )
        except Exception as e:
            raise LLMError(f"Gemini API error: {e}") from e

    def generate_with_history(self, messages: list[dict[str, str]]) -> LLMResponse:
        """Generate response using conversation history."""
        if not self.validate_config():
            raise LLMError("Google API key not configured")

        try:
            contents = []
            for msg in messages[:-1]:
                if msg["role"] in ["user", "assistant"]:
                    role = "user" if msg["role"] == "user" else "model"
                    contents.append(
                        self.genai_types.Content(
                            role=role, parts=[self.genai_types.Part(text=msg["content"])]
                        )
                    )

            contents.append(
                self.genai_types.Content(
                    role="user", parts=[self.genai_types.Part(text=messages[-1]["content"])]
                )
            )

            response = self.client.models.generate_content(
                model=self.config.model,
                contents=contents,
                config=self.genai_types.GenerateContentConfig(
                    temperature=self.config.temperature,
                    max_output_tokens=self.config.max_tokens,
                ),
            )

            return LLMResponse(
                content=response.text,
                model=self.config.model,
                provider=self.provider_name,
                tokens_used=(
                    response.usage_metadata.total_token_count
                    if hasattr(response, "usage_metadata")
                    else None
                ),
                finish_reason=(
                    response.candidates[0].finish_reason.name if response.candidates else None
                ),
            )
        except Exception as e:
            raise LLMError(f"Gemini API error: {e}") from e


class OllamaClient(LLMClient):
    """Ollama (local) provider client."""

    def __init__(self, config: LLMConfig):
        super().__init__(config)
        try:
            import requests

            self.requests = requests
            self.base_url = config.base_url or os.getenv(
                "OLLAMA_BASE_URL", "http://localhost:11434"
            )
        except ImportError:
            raise LLMError("Requests package not installed. Install with: pip install requests")

    def validate_config(self) -> bool:
        """Validate Ollama configuration."""
        return True

    def generate(self, system_prompt: str, user_prompt: str) -> LLMResponse:
        """Generate response using Ollama API."""
        messages = self._format_messages(system_prompt, user_prompt)

        try:
            response = self.requests.post(
                f"{self.base_url}/api/chat",
                json={"model": self.config.model, "messages": messages, "stream": False},
                timeout=self.config.timeout,
            )

            response.raise_for_status()
            data = response.json()

            return LLMResponse(
                content=data.get("message", {}).get("content", ""),
                model=self.config.model,
                provider=self.provider_name,
                tokens_used=data.get("prompt_eval_count", 0) + data.get("eval_count", 0),
                finish_reason=data.get("done_reason"),
            )
        except Exception as e:
            raise LLMError(f"Ollama API error: {e}") from e

    def generate_with_history(self, messages: list[dict[str, str]]) -> LLMResponse:
        """Generate response using conversation history."""
        try:
            response = self.requests.post(
                f"{self.base_url}/api/chat",
                json={"model": self.config.model, "messages": messages, "stream": False},
                timeout=self.config.timeout,
            )

            response.raise_for_status()
            data = response.json()

            return LLMResponse(
                content=data.get("message", {}).get("content", ""),
                model=self.config.model,
                provider=self.provider_name,
                tokens_used=data.get("prompt_eval_count", 0) + data.get("eval_count", 0),
                finish_reason=data.get("done_reason"),
            )
        except Exception as e:
            raise LLMError(f"Ollama API error: {e}") from e


class LMStudioClient(LLMClient):
    """LM Studio (local) provider client."""

    def __init__(self, config: LLMConfig):
        super().__init__(config)
        try:
            import openai

            self.openai = openai
            self.base_url = config.base_url or os.getenv(
                "LM_STUDIO_BASE_URL", "http://localhost:1234/v1"
            )
            self.client = openai.OpenAI(
                base_url=self.base_url, api_key="not-needed", timeout=config.timeout
            )
        except ImportError:
            raise LLMError("OpenAI package not installed. Install with: pip install openai")

    def validate_config(self) -> bool:
        """Validate LM Studio configuration."""
        return True

    def generate(self, system_prompt: str, user_prompt: str) -> LLMResponse:
        """Generate response using LM Studio API."""
        messages = self._format_messages(system_prompt, user_prompt)

        try:
            response = self.client.chat.completions.create(
                model=self.config.model,
                messages=messages,
                temperature=self.config.temperature,
                max_tokens=self.config.max_tokens,
            )

            return LLMResponse(
                content=response.choices[0].message.content,
                model=self.config.model,
                provider=self.provider_name,
                tokens_used=response.usage.total_tokens if response.usage else None,
                finish_reason=response.choices[0].finish_reason,
            )
        except Exception as e:
            raise LLMError(f"LM Studio API error: {e}") from e

    def generate_with_history(self, messages: list[dict[str, str]]) -> LLMResponse:
        """Generate response using conversation history."""
        try:
            response = self.client.chat.completions.create(
                model=self.config.model,
                messages=messages,
                temperature=self.config.temperature,
                max_tokens=self.config.max_tokens,
            )

            return LLMResponse(
                content=response.choices[0].message.content,
                model=self.config.model,
                provider=self.provider_name,
                tokens_used=response.usage.total_tokens if response.usage else None,
                finish_reason=response.choices[0].finish_reason,
            )
        except Exception as e:
            raise LLMError(f"LM Studio API error: {e}") from e


class LLMClientFactory:
    """Factory for creating LLM clients."""

    _providers: dict[str, type[LLMClient]] = {
        "openai": OpenAIClient,
        "claude": ClaudeClient,
        "gemini": GeminiClient,
        "ollama": OllamaClient,
        "lm_studio": LMStudioClient,
    }

    @classmethod
    def create(cls, config: LLMConfig) -> LLMClient:
        """Create LLM client from configuration."""
        provider_class = cls._providers.get(config.provider)

        if not provider_class:
            raise ProviderNotFoundError(f"Unknown LLM provider: {config.provider}")

        return provider_class(config)

    @classmethod
    def register_provider(cls, name: str, provider_class: type[LLMClient]) -> None:
        """Register a new LLM provider."""
        cls._providers[name] = provider_class

    @classmethod
    def list_providers(cls) -> list[str]:
        """List available providers."""
        return list(cls._providers.keys())


class MultiLLMClient:
    """Multi-runtime LLM client with fallback support."""

    def __init__(
        self,
        primary_config: LLMConfig,
        fallback_config: LLMConfig | None = None,
    ):
        self.primary_config = primary_config
        self.fallback_config = fallback_config
        self.primary_client = LLMClientFactory.create(primary_config)

        if fallback_config:
            self.fallback_client = LLMClientFactory.create(fallback_config)
        else:
            self.fallback_client = None

    def generate(self, system_prompt: str, user_prompt: str) -> LLMResponse:
        """Generate response with fallback support."""
        try:
            return self.primary_client.generate(system_prompt, user_prompt)
        except LLMError as e:
            if self.fallback_client:
                return self.fallback_client.generate(system_prompt, user_prompt)
            raise e

    def generate_with_history(self, messages: list[dict[str, str]]) -> LLMResponse:
        """Generate response with fallback support."""
        try:
            return self.primary_client.generate_with_history(messages)
        except LLMError as e:
            if self.fallback_client:
                return self.fallback_client.generate_with_history(messages)
            raise e


__all__ = [
    "LLMError",
    "ProviderNotFoundError",
    "LLMConfig",
    "LLMResponse",
    "LLMClient",
    "OpenAIClient",
    "ClaudeClient",
    "GeminiClient",
    "OllamaClient",
    "LMStudioClient",
    "LLMClientFactory",
    "MultiLLMClient",
]
