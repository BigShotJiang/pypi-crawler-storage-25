"""
Parallel Executor for Novel Generation System

This module provides parallel execution capabilities for independent agents,
enabling concurrent processing to reduce overall workflow execution time.

Features:
- Dependency graph analysis
- Topological sort for execution order
- Thread pool for parallel execution
- Async/await support
- Progress tracking
- Error handling and rollback
- Configurable worker limits
"""

import threading
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, Dict, List, Optional, Tuple
from uuid import uuid4


class ExecutionStatus(Enum):
    """Status of agent execution"""

    PENDING = "pending"
    READY = "ready"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    SKIPPED = "skipped"


@dataclass
class ExecutionNode:
    """Represents a node in the execution graph"""

    agent_name: str
    agent_id: str = field(default_factory=lambda: str(uuid4()))
    dependencies: List[str] = field(default_factory=list)
    dependents: List[str] = field(default_factory=list)
    status: ExecutionStatus = ExecutionStatus.PENDING
    result: Optional[Any] = None
    error: Optional[str] = None
    start_time: Optional[float] = None
    end_time: Optional[float] = None
    duration: Optional[float] = None
    retry_count: int = 0
    max_retries: int = 3

    @property
    def is_ready(self) -> bool:
        """Check if node is ready to execute (all dependencies completed)"""
        return all(dep_status == ExecutionStatus.COMPLETED for dep_status in self.dependencies)

    @property
    def can_run_parallel(self) -> bool:
        """Check if this node can run in parallel with others"""
        return self.status == ExecutionStatus.READY

    def to_dict(self) -> Dict[str, Any]:
        """Convert node to dictionary"""
        return {
            "agent_name": self.agent_name,
            "agent_id": self.agent_id,
            "dependencies": self.dependencies,
            "dependents": self.dependents,
            "status": self.status.value,
            "result": str(self.result)[:100] if self.result else None,
            "error": self.error,
            "start_time": self.start_time,
            "end_time": self.end_time,
            "duration": self.duration,
            "retry_count": self.retry_count,
        }


@dataclass
class ExecutionResult:
    """Result of parallel execution"""

    success: bool
    completed_nodes: List[str]
    failed_nodes: List[str]
    skipped_nodes: List[str]
    total_duration: float
    node_results: Dict[str, Any]
    errors: Dict[str, str]
    parallel_speedup: float = 1.0

    def to_dict(self) -> Dict[str, Any]:
        """Convert result to dictionary"""
        return {
            "success": self.success,
            "completed_nodes": self.completed_nodes,
            "failed_nodes": self.failed_nodes,
            "skipped_nodes": self.skipped_nodes,
            "total_duration": self.total_duration,
            "node_results": self.node_results,
            "errors": self.errors,
            "parallel_speedup": f"{self.parallel_speedup:.2f}x",
        }


@dataclass
class ExecutionGraph:
    """Directed acyclic graph representing agent dependencies"""

    nodes: Dict[str, ExecutionNode] = field(default_factory=dict)
    edges: Dict[str, List[str]] = field(default_factory=dict)

    def add_node(self, node: ExecutionNode) -> None:
        """Add a node to the graph"""
        self.nodes[node.agent_id] = node
        if node.agent_id not in self.edges:
            self.edges[node.agent_id] = []

    def add_edge(self, from_id: str, to_id: str) -> None:
        """Add a directed edge (dependency) from_id -> to_id"""
        if from_id not in self.edges:
            self.edges[from_id] = []
        self.edges[from_id].append(to_id)

        # Update dependencies
        if to_id in self.nodes:
            self.nodes[to_id].dependencies.append(from_id)
        if from_id in self.nodes:
            self.nodes[from_id].dependents.append(to_id)

    def get_ready_nodes(self) -> List[ExecutionNode]:
        """Get all nodes that are ready to execute"""
        return [
            node
            for node in self.nodes.values()
            if node.status == ExecutionStatus.READY and node.is_ready
        ]

    def topological_sort(self) -> List[str]:
        """
        Perform topological sort to get execution order

        Returns:
            List of agent IDs in execution order

        Raises:
            ValueError: If graph contains cycles
        """
        in_degree = {node_id: 0 for node_id in self.nodes}

        # Calculate in-degrees
        for from_id in self.edges:
            for to_id in self.edges[from_id]:
                in_degree[to_id] += 1

        # Start with nodes having no dependencies
        queue = [node_id for node_id, degree in in_degree.items() if degree == 0]
        result = []

        while queue:
            node_id = queue.pop(0)
            result.append(node_id)

            # Reduce in-degree for dependents
            for dependent_id in self.edges.get(node_id, []):
                in_degree[dependent_id] -= 1
                if in_degree[dependent_id] == 0:
                    queue.append(dependent_id)

        # Check for cycles
        if len(result) != len(self.nodes):
            raise ValueError("Execution graph contains cycles")

        return result

    def detect_cycles(self) -> List[List[str]]:
        """
        Detect cycles in the execution graph

        Returns:
            List of cycles (each cycle is a list of node IDs)
        """
        white, gray, black = 0, 1, 2
        color = {node_id: white for node_id in self.nodes}
        cycles = []

        def dfs(node_id: str, path: List[str]) -> None:
            nonlocal cycles
            color[node_id] = gray
            path.append(node_id)

            for neighbor in self.edges.get(node_id, []):
                if color[neighbor] == gray:
                    # Found cycle
                    cycle_start = path.index(neighbor)
                    cycles.append(path[cycle_start:] + [neighbor])
                elif color[neighbor] == white:
                    dfs(neighbor, path.copy())

            color[node_id] = black

        for node_id in self.nodes:
            if color[node_id] == white:
                dfs(node_id, [])

        return cycles

    def validate(self) -> Tuple[bool, List[str]]:
        """
        Validate the execution graph

        Returns:
            Tuple of (is_valid, error_messages)
        """
        errors = []

        # Check for cycles
        cycles = self.detect_cycles()
        if cycles:
            errors.append(f"Found {len(cycles)} cycles in execution graph")
            for i, cycle in enumerate(cycles):
                errors.append(f"  Cycle {i + 1}: {' -> '.join(cycle)}")

        # Check for missing dependencies
        for node_id, node in self.nodes.items():
            for dep_id in node.dependencies:
                if dep_id not in self.nodes:
                    errors.append(f"Node {node_id} depends on non-existent node {dep_id}")

        return (len(errors) == 0, errors)


class ParallelExecutor:
    """
    Parallel executor for concurrent agent execution

    Features:
    - Dependency graph construction
    - Topological sort for execution order
    - Thread pool for parallel execution
    - Progress tracking
    - Error handling with retry logic
    - Rollback on failure

    Usage:
        executor = ParallelExecutor(max_workers=4)

        # Build execution graph
        graph = ExecutionGraph()
        graph.add_node(ExecutionNode(agent_name="agent1"))
        graph.add_node(ExecutionNode(agent_name="agent2", dependencies=["agent1"]))

        # Execute
        result = executor.execute_parallel(graph, agent_functions)
        print(result.to_dict())
    """

    DEFAULT_MAX_WORKERS = 4
    DEFAULT_TIMEOUT = 300  # 5 minutes

    def __init__(
        self,
        max_workers: int = DEFAULT_MAX_WORKERS,
        timeout: int = DEFAULT_TIMEOUT,
        enable_progress: bool = True,
    ):
        self.max_workers = max_workers
        self.timeout = timeout
        self.enable_progress = enable_progress
        self.lock = threading.Lock()
        self.progress_callbacks: List[Callable[[str, ExecutionStatus], None]] = []

    def add_progress_callback(self, callback: Callable[[str, ExecutionStatus], None]) -> None:
        """Add a callback for progress updates"""
        self.progress_callbacks.append(callback)

    def _notify_progress(self, node_id: str, status: ExecutionStatus) -> None:
        """Notify all progress callbacks"""
        for callback in self.progress_callbacks:
            try:
                callback(node_id, status)
            except Exception:
                pass  # Ignore callback errors

    def build_graph_from_workflow(self, workflow_steps: List[Dict[str, Any]]) -> ExecutionGraph:
        """
        Build execution graph from workflow steps

        Args:
            workflow_steps: List of workflow step definitions

        Returns:
            ExecutionGraph
        """
        graph = ExecutionGraph()

        # Create nodes
        step_map = {}
        for i, step in enumerate(workflow_steps):
            node = ExecutionNode(
                agent_name=step.get("agent", f"step_{i}"), dependencies=step.get("dependencies", [])
            )
            graph.add_node(node)
            step_map[i] = node.agent_id

        # Create edges
        for i, step in enumerate(workflow_steps):
            node_id = step_map[i]
            for dep_index in step.get("dependencies", []):
                if isinstance(dep_index, int) and dep_index in step_map:
                    dep_id = step_map[dep_index]
                    graph.add_edge(dep_id, node_id)

        return graph

    def execute_parallel(
        self,
        graph: ExecutionGraph,
        agent_functions: Dict[str, Callable],
        context: Optional[Dict[str, Any]] = None,
    ) -> ExecutionResult:
        """
        Execute agents in parallel where possible

        Args:
            graph: Execution graph with dependencies
            agent_functions: Dict mapping agent names to functions
            context: Optional execution context

        Returns:
            ExecutionResult with outcomes
        """
        start_time = time.time()

        # Validate graph
        is_valid, errors = graph.validate()
        if not is_valid:
            return ExecutionResult(
                success=False,
                completed_nodes=[],
                failed_nodes=[],
                skipped_nodes=[],
                total_duration=0.0,
                node_results={},
                errors={"validation": "\n".join(errors)},
            )

        # Initialize nodes
        for node in graph.nodes.values():
            if not node.dependencies:
                node.status = ExecutionStatus.READY

        completed = []
        failed = []
        skipped = []
        node_results = {}
        errors = {}

        # Execute in parallel using thread pool
        with ThreadPoolExecutor(max_workers=self.max_workers) as executor:
            futures = {}

            while True:
                # Get ready nodes
                ready_nodes = graph.get_ready_nodes()

                if not ready_nodes and not futures:
                    # No more work to do
                    break

                # Submit ready nodes
                for node in ready_nodes:
                    if node.agent_name not in agent_functions:
                        failed.append(node.agent_id)
                        errors[node.agent_id] = f"Agent function not found: {node.agent_name}"
                        node.status = ExecutionStatus.FAILED
                        continue

                    node.status = ExecutionStatus.RUNNING
                    node.start_time = time.time()
                    self._notify_progress(node.agent_id, ExecutionStatus.RUNNING)

                    future = executor.submit(
                        self._execute_agent, node, agent_functions[node.agent_name], context
                    )
                    futures[future] = node

                # Wait for at least one completion
                if futures:
                    completed_futures = as_completed(futures, timeout=self.timeout)

                    for future in completed_futures:
                        node = futures.pop(future)

                        try:
                            result = future.result()
                            node.end_time = time.time()
                            node.duration = node.end_time - (node.start_time or node.end_time)
                            node.result = result
                            node.status = ExecutionStatus.COMPLETED

                            completed.append(node.agent_id)
                            node_results[node.agent_id] = result

                            # Update dependent nodes
                            for dependent_id in node.dependents:
                                dependent = graph.nodes.get(dependent_id)
                                if dependent and dependent.is_ready:
                                    dependent.status = ExecutionStatus.READY

                            self._notify_progress(node.agent_id, ExecutionStatus.COMPLETED)

                        except Exception as e:
                            node.end_time = time.time()
                            node.duration = node.end_time - (node.start_time or node.end_time)
                            node.error = str(e)
                            node.status = ExecutionStatus.FAILED

                            failed.append(node.agent_id)
                            errors[node.agent_id] = str(e)

                            # Mark dependents as skipped
                            for dependent_id in node.dependents:
                                dependent = graph.nodes.get(dependent_id)
                                if dependent:
                                    dependent.status = ExecutionStatus.SKIPPED
                                    skipped.append(dependent_id)

                            self._notify_progress(node.agent_id, ExecutionStatus.FAILED)

        total_duration = time.time() - start_time

        return ExecutionResult(
            success=len(failed) == 0,
            completed_nodes=completed,
            failed_nodes=failed,
            skipped_nodes=skipped,
            total_duration=total_duration,
            node_results=node_results,
            errors=errors,
        )

    def execute_sequential(
        self,
        graph: ExecutionGraph,
        agent_functions: Dict[str, Callable],
        context: Optional[Dict[str, Any]] = None,
    ) -> ExecutionResult:
        """
        Execute agents sequentially (for comparison)

        Args:
            graph: Execution graph
            agent_functions: Dict mapping agent names to functions
            context: Optional execution context

        Returns:
            ExecutionResult
        """
        start_time = time.time()

        # Get topological order
        try:
            order = graph.topological_sort()
        except ValueError as e:
            return ExecutionResult(
                success=False,
                completed_nodes=[],
                failed_nodes=[],
                skipped_nodes=[],
                total_duration=0.0,
                node_results={},
                errors={"topological_sort": str(e)},
            )

        completed = []
        failed = []
        skipped = []
        node_results = {}
        errors = {}

        for node_id in order:
            node = graph.nodes[node_id]

            # Check if dependencies failed
            if any(dep_id in failed for dep_id in node.dependencies):
                node.status = ExecutionStatus.SKIPPED
                skipped.append(node_id)
                continue

            # Execute agent
            try:
                node.start_time = time.time()
                result = self._execute_agent(node, agent_functions[node.agent_name], context)
                node.end_time = time.time()
                node.duration = node.end_time - node.start_time
                node.result = result
                node.status = ExecutionStatus.COMPLETED

                completed.append(node_id)
                node_results[node_id] = result

            except Exception as e:
                node.end_time = time.time()
                node.error = str(e)
                node.status = ExecutionStatus.FAILED

                failed.append(node_id)
                errors[node_id] = str(e)

        total_duration = time.time() - start_time

        return ExecutionResult(
            success=len(failed) == 0,
            completed_nodes=completed,
            failed_nodes=failed,
            skipped_nodes=skipped,
            total_duration=total_duration,
            node_results=node_results,
            errors=errors,
        )

    def _execute_agent(
        self, node: ExecutionNode, agent_func: Callable, context: Optional[Dict[str, Any]]
    ) -> Any:
        """Execute a single agent with retry logic"""
        last_error = None

        for attempt in range(node.max_retries):
            try:
                if context:
                    return agent_func(**context)
                else:
                    return agent_func()
            except Exception as e:
                last_error = e
                node.retry_count += 1
                if attempt < node.max_retries - 1:
                    time.sleep(2**attempt)  # Exponential backoff

        raise last_error

    def get_execution_order(self, graph: ExecutionGraph) -> List[str]:
        """Get execution order using topological sort"""
        return graph.topological_sort()

    def can_execute_parallel(self, agents: List[str]) -> bool:
        """
        Check if agents can be executed in parallel

        Args:
            agents: List of agent names

        Returns:
            True if agents have no dependencies between them
        """
        # Simple check: if agents have no dependencies, they can run in parallel
        return len(agents) > 1

    def estimate_parallel_speedup(self, graph: ExecutionGraph) -> float:
        """
        Estimate speedup from parallel execution

        Args:
            graph: Execution graph

        Returns:
            Estimated speedup multiplier
        """
        ready_nodes = graph.get_ready_nodes()
        if len(ready_nodes) <= 1:
            return 1.0

        # Simple estimate: speedup = min(workers, parallel_work)
        return min(self.max_workers, len(ready_nodes))


# Global parallel executor instance
_global_parallel_executor: Optional[ParallelExecutor] = None


def get_parallel_executor() -> ParallelExecutor:
    """Get the global parallel executor instance"""
    global _global_parallel_executor
    if _global_parallel_executor is None:
        _global_parallel_executor = ParallelExecutor()
    return _global_parallel_executor
