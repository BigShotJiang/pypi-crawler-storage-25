"""
Agent Execution Queue for Parallel Agent Execution

This module provides a task queue for managing concurrent agent executions
with priority, dependencies, timeout, and retry logic.
"""

import asyncio
import inspect
import time
from collections import defaultdict
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, Dict, List, Optional, Set
from uuid import uuid4


class TaskStatus(str, Enum):
    """Task execution status"""

    PENDING = "pending"
    WAITING = "waiting"  # Waiting for dependencies
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    TIMEOUT = "timeout"
    CANCELLED = "cancelled"


@dataclass
class AgentTask:
    """Represents an agent execution task"""

    task_id: str
    agent_name: str
    prompt: str
    priority: int = 0
    dependencies: List[str] = field(default_factory=list)
    timeout: int = 300  # seconds
    retry_count: int = 0
    max_retries: int = 3
    metadata: Dict[str, Any] = field(default_factory=dict)
    created_at: float = field(default_factory=time.time)

    def __lt__(self, other: "AgentTask") -> bool:
        """Compare tasks by priority for queue ordering"""
        return self.priority < other.priority


@dataclass
class TaskResult:
    """Result of agent execution"""

    task_id: str
    agent_name: str
    status: TaskStatus
    result: Optional[str] = None
    error: Optional[str] = None
    duration: float = 0.0
    started_at: Optional[float] = None
    completed_at: Optional[float] = None
    retry_count: int = 0
    metadata: Dict[str, Any] = field(default_factory=dict)


class AgentQueue:
    """
    Priority queue for managing agent executions

    Features:
    - Priority-based execution
    - Task dependencies
    - Automatic retry
    - Timeout handling
    - Progress tracking

    Usage:
        queue = AgentQueue(max_concurrent=3)

        task = queue.submit(AgentTask(...))
        results = await queue.execute_all()
    """

    def __init__(self, max_concurrent: int = 3):
        self.max_concurrent = max_concurrent
        self.semaphore = asyncio.Semaphore(max_concurrent)

        # Task storage
        self.tasks: Dict[str, AgentTask] = {}
        self.results: Dict[str, TaskResult] = {}
        self.running: Set[str] = set()
        self.waiting: Dict[str, Set[str]] = defaultdict(set)  # task_id -> waiting on tasks

        # Event for new tasks
        self.new_task_event = asyncio.Event()

        # Lock for thread safety
        self.lock = asyncio.Lock()

    def submit(self, task: AgentTask) -> str:
        """
        Submit a task to the queue

        Args:
            task: AgentTask to submit

        Returns:
            Task ID
        """
        if not task.task_id:
            task.task_id = str(uuid4())

        self.tasks[task.task_id] = task

        # Update waiting list for dependencies
        for dep_id in task.dependencies:
            self.waiting[dep_id].add(task.task_id)

        self.new_task_event.set()
        return task.task_id

    def submit_batch(self, tasks: List[AgentTask]) -> List[str]:
        """
        Submit multiple tasks

        Args:
            tasks: List of tasks to submit

        Returns:
            List of task IDs
        """
        task_ids = []
        for task in tasks:
            task_id = self.submit(task)
            task_ids.append(task_id)
        return task_ids

    def get_ready_tasks(self) -> List[AgentTask]:
        """
        Get all tasks that are ready to execute (dependencies met)

        Returns:
            List of ready tasks
        """
        ready = []
        for task_id, task in self.tasks.items():
            if task_id in self.running:
                continue
            if task_id in self.results:
                continue

            # Check dependencies
            deps_completed = all(
                self.results.get(
                    dep_id, TaskResult(task_id=dep_id, agent_name="", status=TaskStatus.COMPLETED)
                ).status
                == TaskStatus.COMPLETED
                for dep_id in task.dependencies
            )

            if deps_completed:
                ready.append(task)

        # Sort by priority
        ready.sort(key=lambda t: t.priority, reverse=True)
        return ready

    def get_waiting_tasks(self) -> Dict[str, List[str]]:
        """Get tasks waiting on dependencies"""
        waiting = {}
        for task_id in self.tasks:
            if task_id in self.results:
                continue
            if task_id in self.running:
                continue

            task = self.tasks[task_id]
            pending_deps = [
                dep_id
                for dep_id in task.dependencies
                if self.results.get(
                    dep_id, TaskResult(task_id=dep_id, agent_name="", status=TaskStatus.PENDING)
                ).status
                != TaskStatus.COMPLETED
            ]

            if pending_deps:
                waiting[task_id] = pending_deps

        return waiting

    async def execute_task(self, task: AgentTask, executor_func: Callable) -> TaskResult:
        """
        Execute a single task with timeout and retry

        Args:
            task: Task to execute
            executor_func: Async function to execute agent

        Returns:
            TaskResult
        """
        result = TaskResult(
            task_id=task.task_id,
            agent_name=task.agent_name,
            status=TaskStatus.RUNNING,
            started_at=time.time(),
        )

        self.results[task.task_id] = result
        self.running.add(task.task_id)

        try:
            async with self.semaphore:
                # Execute with timeout
                if inspect.iscoroutinefunction(executor_func):
                    output = await asyncio.wait_for(
                        executor_func(task.agent_name, task.prompt, **task.metadata),
                        timeout=task.timeout,
                    )
                else:
                    output = await asyncio.wait_for(
                        asyncio.get_event_loop().run_in_executor(
                            None, executor_func, task.agent_name, task.prompt, task.metadata
                        ),
                        timeout=task.timeout,
                    )

                result.result = output
                result.status = TaskStatus.COMPLETED
                result.completed_at = time.time()
                result.duration = result.completed_at - result.started_at

        except asyncio.TimeoutError:
            result.status = TaskStatus.TIMEOUT
            result.error = f"Task timed out after {task.timeout}s"
            result.completed_at = time.time()
            result.duration = result.completed_at - result.started_at

        except Exception as e:
            result.status = TaskStatus.FAILED
            result.error = str(e)
            result.completed_at = time.time()
            result.duration = result.completed_at - result.started_at

            # Retry if allowed
            if task.retry_count < task.max_retries:
                task.retry_count += 1
                task.priority += 1  # Increase priority for retries
                result.status = TaskStatus.PENDING
                result.retry_count = task.retry_count
                del self.results[task.task_id]
                self.running.discard(task.task_id)
                self.submit(task)

        finally:
            self.running.discard(task.task_id)

        return result

    async def execute_all(
        self,
        executor_func: Callable,
        progress_callback: Optional[Callable[[str, TaskStatus], None]] = None,
    ) -> Dict[str, TaskResult]:
        """
        Execute all submitted tasks with dependency resolution

        Args:
            executor_func: Async function to execute agents
            progress_callback: Optional callback for progress updates

        Returns:
            Dictionary of task_id -> TaskResult
        """
        while True:
            # Get ready tasks
            ready_tasks = self.get_ready_tasks()

            # Check if we're done
            if not ready_tasks and not self.running:
                # Check for waiting tasks with unmet dependencies
                waiting = self.get_waiting_tasks()
                if waiting:
                    # There are tasks waiting on failed/pending deps
                    pending_tasks = [self.tasks[tid] for tid in waiting.keys() if tid in self.tasks]
                    if pending_tasks:
                        # Check if any completed successfully
                        completed = [
                            tid
                            for tid in waiting.keys()
                            if self.results.get(
                                tid,
                                TaskResult(task_id=tid, agent_name="", status=TaskStatus.PENDING),
                            ).status
                            == TaskStatus.COMPLETED
                        ]
                        if completed:
                            continue
                        break
                    else:
                        break
                else:
                    break

            # Launch ready tasks
            for task in ready_tasks[: self.max_concurrent - len(self.running)]:
                if progress_callback:
                    progress_callback(task.task_id, TaskStatus.RUNNING)

                asyncio.create_task(self.execute_task(task, executor_func))

            # Wait for new tasks or completion
            await asyncio.sleep(0.1)

        return self.results

    async def execute_parallel(
        self,
        tasks: List[AgentTask],
        executor_func: Callable,
        progress_callback: Optional[Callable[[str, TaskStatus], None]] = None,
    ) -> Dict[str, TaskResult]:
        """
        Execute tasks in parallel with dependency resolution

        Args:
            tasks: Tasks to execute
            executor_func: Async function to execute agents
            progress_callback: Progress callback

        Returns:
            Dictionary of task_id -> TaskResult
        """
        # Submit all tasks
        self.submit_batch(tasks)

        # Execute all
        return await self.execute_all(executor_func, progress_callback)

    def get_progress(self) -> Dict[str, Any]:
        """Get execution progress"""
        total = len(self.tasks)
        completed = sum(1 for r in self.results.values() if r.status == TaskStatus.COMPLETED)
        running = len(self.running)
        waiting = total - completed - running

        return {
            "total": total,
            "completed": completed,
            "running": running,
            "waiting": waiting,
            "progress": (completed / total * 100) if total > 0 else 0,
        }

    def get_result(self, task_id: str) -> Optional[TaskResult]:
        """Get result for specific task"""
        return self.results.get(task_id)

    def get_results_by_agent(self, agent_name: str) -> Dict[str, TaskResult]:
        """Get all results for specific agent"""
        return {
            tid: result for tid, result in self.results.items() if result.agent_name == agent_name
        }

    def cancel_task(self, task_id: str) -> bool:
        """Cancel a specific task"""
        if task_id in self.tasks:
            self.tasks[task_id].status = TaskStatus.CANCELLED
            return True
        return False

    def cancel_all(self) -> None:
        """Cancel all pending tasks"""
        for task_id in self.tasks:
            self.tasks[task_id].status = TaskStatus.CANCELLED
        self.tasks.clear()
        self.results.clear()
        self.running.clear()
        self.waiting.clear()

    def wait_for_completion(self, timeout: Optional[float] = None) -> bool:
        """
        Wait for all tasks to complete

        Args:
            timeout: Optional timeout in seconds

        Returns:
            True if all tasks completed, False if timeout
        """
        start_time = time.time()

        while True:
            if timeout and (time.time() - start_time) > timeout:
                return False

            if not self.running and not self.get_ready_tasks():
                # Check for waiting tasks
                waiting = self.get_waiting_tasks()
                if not waiting or all(
                    self.results.get(
                        tid, TaskResult(task_id=tid, agent_name="", status=TaskStatus.PENDING)
                    ).status
                    == TaskStatus.COMPLETED
                    for tid in waiting.keys()
                ):
                    return True

            time.sleep(0.1)


# Global queue instance
_queue: Optional[AgentQueue] = None


def get_agent_queue() -> AgentQueue:
    """Get or create global agent queue"""
    global _queue
    if _queue is None:
        _queue = AgentQueue()
    return _queue


def reset_agent_queue() -> None:
    """Reset global queue"""
    global _queue
    if _queue:
        _queue.cancel_all()
    _queue = None
