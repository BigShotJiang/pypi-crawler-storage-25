"""Novel Harness Core Components."""

__version__ = "0.1.0"
