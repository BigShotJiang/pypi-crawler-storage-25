"""Verification engine for orchestrating content quality checks."""

from datetime import datetime
from pathlib import Path
from typing import List, Optional

from pydantic import BaseModel

from core.continuity_parser import ContinuityParser, ContinuityReport, ReportStatus
from core.fix_plan_generator import FixPlan, FixPlanGenerator
from core.rewrite_loop import IterationStatus, RewriteConfig, RewriteIteration, RewriteLoopExecutor


class VerificationResult(BaseModel):
    project_name: str
    passed: bool
    total_iterations: int
    final_status: ReportStatus
    issues_remaining: int
    critical_issues: int
    major_issues: int
    minor_issues: int
    iterations: List[RewriteIteration]
    total_execution_time: float
    verification_timestamp: datetime


class VerificationConfig(BaseModel):
    max_iterations: int = 5
    stop_on_pass: bool = True
    stop_on_critical_only: bool = True
    allow_major_issues: bool = False
    allow_minor_issues: bool = True
    max_minor_issues: int = 10
    batch_size: int = 10
    generate_report: bool = True
    save_iteration_log: bool = True


class VerificationEngine:
    def __init__(self, project_dir: str, config: VerificationConfig):
        self.project_dir = Path(project_dir)
        self.config = config
        self.parser = ContinuityParser(str(self.project_dir))
        self.plan_generator = FixPlanGenerator()

    def verify_project(self) -> VerificationResult:
        start_time = datetime.now()

        rewrite_config = RewriteConfig(
            max_iterations=self.config.max_iterations,
            stop_on_pass=self.config.stop_on_pass,
            stop_on_critical_only=self.config.stop_on_critical_only,
            allow_major_issues=self.config.allow_major_issues,
            allow_minor_issues=self.config.allow_minor_issues,
            max_minor_issues=self.config.max_minor_issues,
            batch_size=self.config.batch_size,
        )

        executor = RewriteLoopExecutor(str(self.project_dir), rewrite_config)

        try:
            final_iteration = executor.execute_loop()

            execution_time = (datetime.now() - start_time).total_seconds()

            passed = final_iteration.status == IterationStatus.PASSED

            result = VerificationResult(
                project_name=self.project_dir.name,
                passed=passed,
                total_iterations=len(executor.iterations),
                final_status=self._map_iteration_status(final_iteration.status),
                issues_remaining=final_iteration.issues_after,
                critical_issues=final_iteration.critical_after,
                major_issues=final_iteration.major_after,
                minor_issues=final_iteration.minor_after,
                iterations=executor.iterations,
                total_execution_time=execution_time,
                verification_timestamp=datetime.now(),
            )

            if self.config.generate_report:
                self._save_verification_report(result)

            if self.config.save_iteration_log:
                log_path = self.project_dir / "verification_log.md"
                executor.save_iteration_log(str(log_path))

            return result

        except Exception as e:
            raise RuntimeError(f"Verification failed: {e}")

    def verify_chapter(self, chapter_number: int) -> VerificationResult:
        chapter_dir = self.project_dir / f"chapter_{chapter_number:03d}"

        if not chapter_dir.exists():
            raise FileNotFoundError(f"Chapter directory not found: {chapter_dir}")

        original_project_dir = self.project_dir
        self.project_dir = chapter_dir

        try:
            result = self.verify_project()
            result.project_name = f"{original_project_dir.name}_chapter_{chapter_number}"
            return result

        finally:
            self.project_dir = original_project_dir

    def quick_verify(self) -> ContinuityReport:
        try:
            report = self.parser.parse_report()
            return report

        except FileNotFoundError:
            raise RuntimeError("No continuity report found. Run continuity check first.")

    def _map_iteration_status(self, status: IterationStatus) -> ReportStatus:
        if status == IterationStatus.PASSED:
            return ReportStatus.PASS
        elif status == IterationStatus.MAX_LIMIT_REACHED:
            return ReportStatus.FAIL
        else:
            return ReportStatus.FAIL

    def _save_verification_report(self, result: VerificationResult) -> None:
        report_path = self.project_dir / "verification_report.md"

        lines = [
            "# Verification Report",
            f"**Project:** {result.project_name}",
            f"**Timestamp:** {result.verification_timestamp.strftime('%Y-%m-%d %H:%M:%S')}",
            f"**Status:** {'PASSED ✅' if result.passed else 'FAILED ❌'}",
            "",
            "## Summary",
            f"- **Total Iterations:** {result.total_iterations}",
            f"- **Execution Time:** {result.total_execution_time:.2f}s",
            f"- **Issues Remaining:** {result.issues_remaining}",
            "",
            "## Final Issue Breakdown",
            f"- **Critical:** {result.critical_issues}",
            f"- **Major:** {result.major_issues}",
            f"- **Minor:** {result.minor_issues}",
            "",
        ]

        if result.passed:
            lines.append("## Result: PASSED ✅")
            lines.append("")
            lines.append("Content quality standards met successfully.")
        else:
            lines.append("## Result: FAILED ❌")
            lines.append("")
            lines.append("Content does not meet quality standards.")

            if result.critical_issues > 0:
                lines.append(f"\n- {result.critical_issues} critical issues must be fixed")
            if result.major_issues > 0:
                lines.append(f"- {result.major_issues} major issues require attention")

        lines.append("")
        lines.append("## Iteration Details")
        lines.append("")

        for i, iteration in enumerate(result.iterations, 1):
            status_symbol = "✅" if iteration.status == IterationStatus.PASSED else "🔄"
            lines.append(f"### Iteration {i} {status_symbol}")
            lines.append(f"- **Status:** {iteration.status.value}")
            lines.append(f"- **Fixes Applied:** {iteration.fixes_applied}")
            lines.append(f"- **Issues:** {iteration.issues_before} → {iteration.issues_after}")
            lines.append(f"- **Time:** {iteration.execution_time:.2f}s")
            lines.append("")

        report_path.write_text("\n".join(lines))

    def get_fix_plan(self) -> Optional[FixPlan]:
        try:
            report = self.parser.parse_report()
            fix_plan = self.plan_generator.generate_fix_plan(report)
            return fix_plan

        except FileNotFoundError:
            return None

    def save_fix_plan(self, output_path: Optional[str] = None) -> str:
        fix_plan = self.get_fix_plan()

        if not fix_plan:
            raise RuntimeError("Cannot generate fix plan: no continuity report found")

        if output_path:
            plan_path = output_path
        else:
            plan_path = self.project_dir / "fix_plan.md"

        self.plan_generator.save_fix_plan(fix_plan, plan_path)
        return str(plan_path)

    def get_progress_estimate(self) -> str:
        try:
            report = self.parser.parse_report()

            lines = [
                "Verification Progress Estimate",
                "=" * 50,
                f"Current Issues: {report.total_issues}",
                f"  Critical: {report.critical_count}",
                f"  Major: {report.major_count}",
                f"  Minor: {report.minor_count}",
                "",
            ]

            if report.status == ReportStatus.PASS:
                lines.append("✅ Content already meets quality standards!")
            else:
                fix_plan = self.plan_generator.generate_fix_plan(report)
                lines.append(f"Estimated Iterations: {fix_plan.estimated_iterations}")
                lines.append(f"Total Fixes Required: {fix_plan.total_fixes}")
                lines.append("")
                lines.append("Fix Breakdown:")
                lines.append(f"  Critical: {fix_plan.critical_fixes}")
                lines.append(f"  Major: {fix_plan.major_fixes}")
                lines.append(f"  Minor: {fix_plan.minor_fixes}")

            return "\n".join(lines)

        except FileNotFoundError:
            return "No verification data available. Run verification first."
