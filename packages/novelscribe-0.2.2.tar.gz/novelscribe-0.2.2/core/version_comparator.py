"""Version comparison and diff utilities for draft management."""

import re
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Literal, Optional, Tuple

from pydantic import BaseModel, Field

from core.draft_manager import DraftManager


class SectionChange(BaseModel):
    section_type: Literal["added", "removed", "modified"]
    content: str
    location: str
    line_number: Optional[int] = None


class VersionDiff(BaseModel):
    from_version: int
    to_version: int
    chapter_number: int
    word_count_change: int
    similarity_score: float
    sections_added: List[SectionChange] = Field(default_factory=list)
    sections_removed: List[SectionChange] = Field(default_factory=list)
    sections_modified: List[SectionChange] = Field(default_factory=list)
    key_preservations: List[str] = Field(default_factory=list)
    timestamp: datetime = Field(default_factory=datetime.now)


class DiffReport(BaseModel):
    version_diff: VersionDiff
    summary: str
    recommendations: List[str] = Field(default_factory=list)
    quality_impact: Optional[str] = None


class VersionComparator:
    def __init__(self, project_dir: str):
        self.project_dir = Path(project_dir)
        self.draft_manager = DraftManager(str(self.project_dir))

    def compare_versions(
        self, chapter_number: int, from_version: int, to_version: int
    ) -> VersionDiff:
        from_content = self.draft_manager.get_version_content(chapter_number, from_version)
        to_content = self.draft_manager.get_version_content(chapter_number, to_version)

        if not from_content or not to_content:
            raise ValueError(
                f"Cannot find versions {from_version} and {to_version} for chapter {chapter_number}"
            )

        word_count_change = len(to_content.split()) - len(from_content.split())
        similarity_score = self._calculate_similarity(from_content, to_content)

        sections_added, sections_removed, sections_modified = self._identify_sections(
            from_content, to_content
        )

        key_preservations = self._find_key_preservations(from_content, to_content)

        return VersionDiff(
            from_version=from_version,
            to_version=to_version,
            chapter_number=chapter_number,
            word_count_change=word_count_change,
            similarity_score=similarity_score,
            sections_added=sections_added,
            sections_removed=sections_removed,
            sections_modified=sections_modified,
            key_preservations=key_preservations,
        )

    def _calculate_similarity(self, content1: str, content2: str) -> float:
        words1 = set(content1.lower().split())
        words2 = set(content2.lower().split())

        if not words1 or not words2:
            return 0.0

        intersection = words1.intersection(words2)
        union = words1.union(words2)

        return len(intersection) / len(union) if union else 0.0

    def _identify_sections(
        self, from_content: str, to_content: str
    ) -> Tuple[List[SectionChange], List[SectionChange], List[SectionChange]]:
        from_paragraphs = from_content.split("\n\n")
        to_paragraphs = to_content.split("\n\n")

        sections_added = []
        sections_removed = []
        sections_modified = []

        from_set = set(from_paragraphs)
        to_set = set(to_paragraphs)

        for paragraph in to_paragraphs:
            if paragraph not in from_set:
                similar_from = self._find_similar_paragraph(paragraph, from_paragraphs)

                if similar_from:
                    sections_modified.append(
                        SectionChange(
                            section_type="modified",
                            content=paragraph,
                            location=f"Paragraph in {to_content.index(paragraph)}",
                        )
                    )
                else:
                    sections_added.append(
                        SectionChange(
                            section_type="added",
                            content=paragraph[:100],
                            location="Position in content",
                        )
                    )

        for paragraph in from_paragraphs:
            if paragraph not in to_set:
                sections_removed.append(
                    SectionChange(
                        section_type="removed",
                        content=paragraph[:100],
                        location="Removed from content",
                    )
                )

        return sections_added, sections_removed, sections_modified

    def _find_similar_paragraph(self, paragraph: str, paragraph_list: List[str]) -> Optional[str]:
        paragraph_words = set(paragraph.lower().split())

        for existing in paragraph_list:
            existing_words = set(existing.lower().split())

            if not paragraph_words or not existing_words:
                continue

            intersection = paragraph_words.intersection(existing_words)
            union = paragraph_words.union(existing_words)

            similarity = len(intersection) / len(union) if union else 0.0

            if similarity > 0.5:
                return existing

        return None

    def _find_key_preservations(self, from_content: str, to_content: str) -> List[str]:
        preservations = []

        from_dialogue = self._extract_dialogue(from_content)
        to_dialogue = self._extract_dialogue(to_content)

        common_dialogue = from_dialogue.intersection(to_dialogue)
        if common_dialogue:
            preservations.append(f"Preserved {len(common_dialogue)} dialogue lines")

        from_character_names = self._extract_character_names(from_content)
        to_character_names = self._extract_character_names(to_content)

        if from_character_names == to_character_names:
            preservations.append(
                f"Maintained character consistency: {', '.join(from_character_names)}"
            )

        from_scenes = self._extract_scene_descriptions(from_content)
        to_scenes = self._extract_scene_descriptions(to_content)

        common_scenes = from_scenes.intersection(to_scenes)
        if common_scenes:
            preservations.append(f"Preserved {len(common_scenes)} scene descriptions")

        return preservations

    def _extract_dialogue(self, content: str) -> set:
        dialogue_pattern = r'"[^"]*"'
        dialogue_matches = re.findall(dialogue_pattern, content)
        return set(dialogue_matches)

    def _extract_character_names(self, content: str) -> List[str]:
        capitalized_words = re.findall(r"\b[A-Z][a-z]+\b", content)

        common_names = ["John", "Jane", "Michael", "Sarah", "David", "Emily"]
        found_names = [word for word in capitalized_words if word in common_names]

        return list(set(found_names))

    def _extract_scene_descriptions(self, content: str) -> set:
        scene_keywords = ["room", "forest", "city", "house", "building", "street", "road"]

        found_scenes = set()
        for keyword in scene_keywords:
            if keyword.lower() in content.lower():
                found_scenes.add(keyword)

        return found_scenes

    def generate_diff_report(
        self, chapter_number: int, from_version: int, to_version: int
    ) -> DiffReport:
        version_diff = self.compare_versions(chapter_number, from_version, to_version)

        summary = self._generate_summary(version_diff)
        recommendations = self._generate_recommendations(version_diff)
        quality_impact = self._assess_quality_impact(version_diff)

        return DiffReport(
            version_diff=version_diff,
            summary=summary,
            recommendations=recommendations,
            quality_impact=quality_impact,
        )

    def _generate_summary(self, diff: VersionDiff) -> str:
        lines = [
            f"Version comparison for Chapter {diff.chapter_number}",
            f"From version {diff.from_version} to {diff.to_version}",
            "",
            f"Word count change: {diff.word_count_change:+d}",
            f"Similarity score: {diff.similarity_score:.2%}",
            "",
            f"Sections added: {len(diff.sections_added)}",
            f"Sections removed: {len(diff.sections_removed)}",
            f"Sections modified: {len(diff.sections_modified)}",
            "",
        ]

        if diff.key_preservations:
            lines.append("Key preservations:")
            for preservation in diff.key_preservations:
                lines.append(f"  - {preservation}")

        return "\n".join(lines)

    def _generate_recommendations(self, diff: VersionDiff) -> List[str]:
        recommendations = []

        if diff.similarity_score < 0.3:
            recommendations.append(
                "Low similarity: This is a major rewrite. Consider keeping previous version."
            )

        if diff.word_count_change > 500:
            recommendations.append(
                f"Significant content added ({diff.word_count_change:+d} words). "
                "Review for consistency."
            )
        elif diff.word_count_change < -500:
            recommendations.append(
                f"Significant content removed ({diff.word_count_change:+d} words). "
                "Ensure nothing important was lost."
            )

        if len(diff.sections_removed) > 5:
            recommendations.append(
                f"Many sections removed ({len(diff.sections_removed)}). Verify story continuity."
            )

        if len(diff.sections_added) > 10:
            recommendations.append(
                f"Many sections added ({len(diff.sections_added)}). Check for redundancy."
            )

        if diff.similarity_score > 0.8 and diff.word_count_change < 100:
            recommendations.append(
                "Minimal changes detected. Consider if regeneration was necessary."
            )

        return recommendations

    def _assess_quality_impact(self, diff: VersionDiff) -> str:
        if diff.similarity_score > 0.8:
            return "Minor impact - Small refinements and adjustments"
        elif diff.similarity_score > 0.5:
            return "Moderate impact - Some sections rewritten or modified"
        elif diff.similarity_score > 0.3:
            return "Significant impact - Large portions reworked"
        else:
            return "Major impact - Substantially different content"

    def compare_all_versions(self, chapter_number: int) -> List[VersionDiff]:
        versions = self.draft_manager.list_versions(chapter_number)

        if len(versions) < 2:
            return []

        diffs = []
        for i in range(len(versions) - 1):
            from_version = versions[i].version
            to_version = versions[i + 1].version

            diff = self.compare_versions(chapter_number, from_version, to_version)
            diffs.append(diff)

        return diffs

    def get_version_progression(self, chapter_number: int) -> Dict[str, Any]:
        versions = self.draft_manager.list_versions(chapter_number)

        if not versions:
            return {
                "chapter_number": chapter_number,
                "versions": [],
                "total_changes": 0,
                "avg_similarity": 0.0,
            }

        diffs = self.compare_all_versions(chapter_number)

        total_word_change = sum(diff.word_count_change for diff in diffs)
        avg_similarity = sum(diff.similarity_score for diff in diffs) / len(diffs) if diffs else 0.0

        return {
            "chapter_number": chapter_number,
            "versions": [v.version for v in versions],
            "total_changes": len(diffs),
            "total_word_change": total_word_change,
            "avg_similarity": avg_similarity,
            "progression": [
                {
                    "from": diff.from_version,
                    "to": diff.to_version,
                    "word_change": diff.word_count_change,
                    "similarity": diff.similarity_score,
                }
                for diff in diffs
            ],
        }
