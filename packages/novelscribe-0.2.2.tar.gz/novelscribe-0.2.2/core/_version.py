"""Version information for NovelScribe.

This file is the single source of truth for version information.
The version is defined here and used throughout the package.
"""

__version__ = "0.2.2"


def get_version() -> str:
    """Get the current version string."""
    return __version__
