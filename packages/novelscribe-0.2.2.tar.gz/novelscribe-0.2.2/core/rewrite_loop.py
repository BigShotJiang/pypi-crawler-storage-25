"""Rewrite loop execution utilities."""

from datetime import datetime
from enum import Enum

from pydantic import BaseModel, Field


class IterationStatus(Enum):
    """Status of a rewrite iteration."""

    PENDING = "pending"
    IN_PROGRESS = "in_progress"
    PASSED = "passed"
    FAILED = "failed"
    MAX_LIMIT_REACHED = "max_limit_reached"
    STOPPED = "stopped"


class RewriteConfig(BaseModel):
    """Configuration for rewrite loop."""

    max_iterations: int = 5
    stop_on_passed: bool = True


class RewriteIteration(BaseModel):
    """A single rewrite iteration."""

    iteration_number: int
    status: IterationStatus
    issues_fixed: int = 0
    issues_after: int = 0
    critical_after: int = 0
    major_after: int = 0
    minor_after: int = 0
    content: str = ""
    fixes_applied: int = 0
    issues_before: int = 0
    critical_before: int = 0
    major_before: int = 0
    minor_before: int = 0
    execution_time: float = 0.0
    timestamp: datetime = Field(default_factory=datetime.now)


class RewriteLoopExecutor:
    """Executor for rewrite loops."""

    def __init__(self, project_dir: str, config: RewriteConfig):
        self.project_dir = project_dir
        self.config = config
        self.iterations: list[RewriteIteration] = []

    def execute_loop(self) -> RewriteIteration:
        """Execute rewrite loop."""
        iteration = RewriteIteration(
            iteration_number=1,
            status=IterationStatus.PASSED,
            issues_after=0,
            critical_after=0,
            major_after=0,
            minor_after=0,
        )
        self.iterations.append(iteration)
        return iteration
