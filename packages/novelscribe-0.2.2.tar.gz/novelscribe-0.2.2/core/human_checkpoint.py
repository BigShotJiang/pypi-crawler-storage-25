"""Human-in-the-loop checkpoint handler for autonomous execution."""

import logging
from enum import Enum
from typing import Any, Optional

from pydantic import BaseModel


class CheckpointType(str, Enum):
    """Checkpoint type enum."""

    APPROVAL = "approval"
    INPUT = "input"
    REVIEW = "review"


class HumanCheckpoint(BaseModel):
    """Human checkpoint configuration.

    Attributes:
        phase: Phase name where checkpoint occurs
        type: Checkpoint type (approval, input, review)
        message: Message to display to user
        required: Whether user input is required
        default_value: Optional default value for input checkpoints
    """

    phase: str
    type: CheckpointType
    message: str
    required: bool = True
    default_value: Optional[str] = None


class CheckpointDecision(BaseModel):
    """User decision at checkpoint.

    Attributes:
        approved: Whether user approved continuation
        input: Optional user input
        modifications: Optional modifications requested
    """

    approved: bool
    input: Optional[str] = None
    modifications: Optional[dict[str, Any]] = None


class HumanCheckpointHandler:
    """Human-in-the-loop checkpoint handler.

    Manages checkpoints that require human interaction during
    autonomous execution.
    """

    def __init__(self, enabled: bool = False):
        """Initialize human checkpoint handler.

        Args:
            enabled: Whether human checkpoints are enabled
        """
        self.enabled = enabled
        self.logger = logging.getLogger("scribe")

    def should_pause_at_phase(self, phase: str, checkpoints: list[HumanCheckpoint]) -> bool:
        """Check if execution should pause at a phase.

        Args:
            phase: Current phase name
            checkpoints: List of configured checkpoints

        Returns:
            True if should pause, False otherwise
        """
        if not self.enabled:
            return False

        return any(cp.phase == phase for cp in checkpoints)

    def get_checkpoint_for_phase(
        self, phase: str, checkpoints: list[HumanCheckpoint]
    ) -> Optional[HumanCheckpoint]:
        """Get checkpoint configuration for a phase.

        Args:
            phase: Phase name
            checkpoints: List of configured checkpoints

        Returns:
            Checkpoint configuration or None if not found
        """
        for cp in checkpoints:
            if cp.phase == phase:
                return cp

        return None

    def handle_checkpoint(self, checkpoint: HumanCheckpoint) -> CheckpointDecision:
        """Handle a human checkpoint.

        Args:
            checkpoint: Checkpoint to handle

        Returns:
            User decision

        Raises:
            RuntimeError: If checkpoint handler is not enabled
        """
        if not self.enabled:
            raise RuntimeError("Human checkpoints are not enabled")

        self.logger.info("")
        self.logger.info("=" * 60)
        self.logger.info(f"🛑 Human Checkpoint: {checkpoint.phase}")
        self.logger.info("=" * 60)
        self.logger.info("")
        self.logger.info(checkpoint.message)
        self.logger.info("")

        if checkpoint.type == CheckpointType.APPROVAL:
            return self._handle_approval_checkpoint(checkpoint)

        elif checkpoint.type == CheckpointType.INPUT:
            return self._handle_input_checkpoint(checkpoint)

        elif checkpoint.type == CheckpointType.REVIEW:
            return self._handle_review_checkpoint(checkpoint)

        else:
            raise ValueError(f"Unknown checkpoint type: {checkpoint.type}")

    def _handle_approval_checkpoint(self, checkpoint: HumanCheckpoint) -> CheckpointDecision:
        """Handle approval checkpoint.

        Args:
            checkpoint: Checkpoint configuration

        Returns:
            User decision
        """
        self.logger.info("Options:")
        self.logger.info("  1. Continue - Approve and continue execution")
        self.logger.info("  2. Stop - Stop execution")
        self.logger.info("")

        while True:
            try:
                choice = input("Continue? (y/n): ").strip().lower()

                if choice in ("y", "yes"):
                    self.logger.info("✓ Approved. Continuing execution...")
                    return CheckpointDecision(approved=True)

                elif choice in ("n", "no"):
                    self.logger.info("✗ Stopping execution...")
                    return CheckpointDecision(approved=False)

                else:
                    self.logger.warning("Invalid choice. Please enter 'y' or 'n'.")

            except (EOFError, KeyboardInterrupt):
                self.logger.info("")
                self.logger.info("✗ Stopping execution (interrupted)...")
                return CheckpointDecision(approved=False)

    def _handle_input_checkpoint(self, checkpoint: HumanCheckpoint) -> CheckpointDecision:
        """Handle input checkpoint.

        Args:
            checkpoint: Checkpoint configuration

        Returns:
            User decision with input
        """
        if checkpoint.default_value:
            self.logger.info(f"Default: {checkpoint.default_value}")

        if not checkpoint.required:
            self.logger.info("Press Enter to skip")

        self.logger.info("")

        try:
            user_input = input(f"{checkpoint.message}: ").strip()

            if not user_input and checkpoint.default_value:
                user_input = checkpoint.default_value

            self.logger.info(f"✓ Input received: {user_input}")
            return CheckpointDecision(approved=True, input=user_input)

        except (EOFError, KeyboardInterrupt):
            self.logger.info("")
            if checkpoint.required:
                self.logger.info("✗ Input required. Stopping execution...")
                return CheckpointDecision(approved=False)
            else:
                self.logger.info("✓ Skipping optional input...")
                return CheckpointDecision(approved=True)

    def _handle_review_checkpoint(self, checkpoint: HumanCheckpoint) -> CheckpointDecision:
        """Handle review checkpoint.

        Args:
            checkpoint: Checkpoint configuration

        Returns:
            User decision
        """
        self.logger.info("Options:")
        self.logger.info("  1. Continue - Approve and continue execution")
        self.logger.info("  2. Modify - Request modifications")
        self.logger.info("  3. Stop - Stop execution")
        self.logger.info("")

        try:
            choice = input("Action? (continue/modify/stop): ").strip().lower()

            if choice in ("continue", "c"):
                self.logger.info("✓ Approved. Continuing execution...")
                return CheckpointDecision(approved=True)

            elif choice in ("modify", "m"):
                self.logger.info("Enter modifications (JSON format):")
                mod_input = input("> ").strip()

                try:
                    import json

                    modifications = json.loads(mod_input)
                    self.logger.info("✓ Modifications recorded")
                    return CheckpointDecision(approved=True, modifications=modifications)

                except json.JSONDecodeError:
                    self.logger.warning("Invalid JSON format. Continuing without modifications...")
                    return CheckpointDecision(approved=True)

            elif choice in ("stop", "s"):
                self.logger.info("✗ Stopping execution...")
                return CheckpointDecision(approved=False)

            else:
                self.logger.warning("Invalid choice. Continuing execution...")
                return CheckpointDecision(approved=True)

        except (EOFError, KeyboardInterrupt):
            self.logger.info("")
            self.logger.info("✗ Stopping execution (interrupted)...")
            return CheckpointDecision(approved=False)
