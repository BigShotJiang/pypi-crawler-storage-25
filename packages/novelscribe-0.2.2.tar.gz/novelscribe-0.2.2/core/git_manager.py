"""Git integration for novel harness.

Implements atomic commits, milestone tagging, and project repository management.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any


class GitError(Exception):
    """Base exception for Git operations."""


class RepositoryNotFoundError(GitError):
    """Raised when Git repository is not found."""


class CommitError(GitError):
    """Raised when commit operation fails."""


class GitManager:
    """Manage Git operations for novel projects."""

    def __init__(
        self,
        project_path: str | Path,
        auto_commit: bool = True,
        commit_message_format: str = "{agent}: {description}",
        milestone_tag_prefix: str = "v",
        logger: logging.Logger | None = None,
    ):
        self.project_path = Path(project_path)
        self.auto_commit = auto_commit
        self.commit_message_format = commit_message_format
        self.milestone_tag_prefix = milestone_tag_prefix
        self.logger = logger or logging.getLogger(f"git_manager.{self.project_path.name}")

        try:
            import git

            self.git = git
        except ImportError:
            raise ImportError("GitPython not installed. Install with: pip install gitpython")

        self._repo: Any | None = None

    @property
    def repo(self) -> Any:
        """Get Git repository, initializing if needed."""
        if self._repo is None:
            try:
                self._repo = self.git.Repo(self.project_path)
            except Exception:
                raise RepositoryNotFoundError(
                    f"Git repository not initialized at {self.project_path}"
                )
        return self._repo

    def initialize_repository(self) -> None:
        """Initialize Git repository in project directory."""
        try:
            self._repo = self.git.Repo.init(self.project_path)
            self.logger.info(f"Initialized Git repository at {self.project_path}")
        except Exception as e:
            raise GitError(f"Failed to initialize Git repository: {e}") from e

    def is_repository(self) -> bool:
        """Check if directory is a Git repository."""
        try:
            git_dir = self.project_path / ".git"
            return git_dir.exists() and git_dir.is_dir()
        except Exception:
            return False

    def add_changed_files(self, files: list[str] | None = None) -> None:
        """Stage changed files for commit."""
        if not self.is_repository():
            raise RepositoryNotFoundError(f"Not a Git repository: {self.project_path}")

        try:
            if files:
                for file_path in files:
                    self.repo.index.add([file_path])
                    self.logger.debug(f"Staged file: {file_path}")
            else:
                self.repo.index.add(["."])
                self.logger.debug("Staged all changed files")
        except Exception as e:
            raise CommitError(f"Failed to stage files: {e}") from e

    def commit(
        self,
        message: str,
        agent: str = "",
        description: str = "",
        **kwargs: Any,
    ) -> str:
        """Create atomic commit with formatted message."""
        if not self.is_repository():
            raise RepositoryNotFoundError(f"Not a Git repository: {self.project_path}")

        commit_message = self._format_commit_message(
            message,
            agent=agent,
            description=description,
            **kwargs,
        )

        try:
            commit = self.repo.index.commit(commit_message)
            commit_hash: str = commit.hexsha
            self.logger.info(f"Created commit: {commit_hash[:8]} - {commit_message}")
            return commit_hash
        except Exception as e:
            raise CommitError(f"Failed to create commit: {e}") from e

    def auto_commit_step(
        self,
        agent: str,
        description: str,
        files: list[str] | None = None,
        **kwargs: Any,
    ) -> str | None:
        """Automatically stage and commit a workflow step."""
        if not self.auto_commit:
            self.logger.info("Auto-commit disabled, skipping commit")
            return None

        try:
            self.add_changed_files(files)
            commit_hash = self.commit(
                message=f"{agent}: {description}",
                agent=agent,
                description=description,
                **kwargs,
            )
            return commit_hash
        except Exception as e:
            self.logger.error(f"Auto-commit failed: {e}")
            return None

    def create_milestone_tag(
        self,
        milestone: str,
        message: str = "",
    ) -> str:
        """Create Git tag for milestone."""
        if not self.is_repository():
            raise RepositoryNotFoundError(f"Not a Git repository: {self.project_path}")

        tag_name = f"{self.milestone_tag_prefix}{milestone}"

        try:
            tag = self.repo.create_tag(
                tag_name,
                message=message or f"Milestone: {milestone}",
            )
            self.logger.info(f"Created tag: {tag_name}")
            tag_name_str: str = tag.name
            return tag_name_str
        except Exception as e:
            raise GitError(f"Failed to create tag {tag_name}: {e}") from e

    def get_current_commit(self) -> str:
        """Get current commit hash."""
        if not self.is_repository():
            raise RepositoryNotFoundError(f"Not a Git repository: {self.project_path}")

        commit_hexsha: str = self.repo.head.commit.hexsha
        return commit_hexsha

    def get_commit_history(self, limit: int = 10) -> list[dict[str, Any]]:
        """Get recent commit history."""
        if not self.is_repository():
            raise RepositoryNotFoundError(f"Not a Git repository: {self.project_path}")

        history = []
        for commit in list(self.repo.iter_commits())[:limit]:
            history.append(
                {
                    "hash": commit.hexsha,
                    "short_hash": commit.hexsha[:8],
                    "message": commit.message,
                    "author": str(commit.author),
                    "timestamp": commit.committed_datetime.isoformat(),
                }
            )

        return history

    def get_tags(self) -> list[dict[str, Any]]:
        """Get all Git tags."""
        if not self.is_repository():
            raise RepositoryNotFoundError(f"Not a Git repository: {self.project_path}")

        tags = []
        for tag in self.repo.tags:
            tags.append(
                {
                    "name": tag.name,
                    "commit": tag.commit.hexsha,
                    "message": tag.tag.message if tag.tag else "",
                }
            )

        return sorted(tags, key=lambda x: x["name"])

    def has_uncommitted_changes(self) -> bool:
        """Check if there are uncommitted changes."""
        if not self.is_repository():
            return False

        is_dirty: bool = self.repo.is_dirty()
        has_untracked: bool = len(self.repo.untracked_files) > 0
        return is_dirty or has_untracked

    def get_changed_files(self) -> list[str]:
        """Get list of changed files."""
        if not self.is_repository():
            return []

        changed = []
        for item in self.repo.index.diff(None):
            changed.append(item.a_path if item.a_path else item.b_path)

        for item in self.repo.untracked_files:
            changed.append(item)

        return changed

    def _format_commit_message(
        self,
        message: str,
        **kwargs: Any,
    ) -> str:
        """Format commit message with template variables."""
        if "{agent}" in self.commit_message_format or "{description}" in self.commit_message_format:
            template_vars = {
                "agent": kwargs.get("agent", ""),
                "description": kwargs.get("description", ""),
                **kwargs,
            }
            return self.commit_message_format.format(**template_vars)

        return message

    def status(self) -> dict[str, Any]:
        """Get repository status information."""
        if not self.is_repository():
            return {
                "is_repository": False,
                "path": str(self.project_path),
            }

        return {
            "is_repository": True,
            "path": str(self.project_path),
            "current_branch": self.repo.active_branch.name,
            "current_commit": self.get_current_commit()[:8],
            "has_changes": self.has_uncommitted_changes(),
            "changed_files": self.get_changed_files(),
            "auto_commit_enabled": self.auto_commit,
        }


def create_git_manager(
    project_path: str | Path,
    auto_commit: bool = True,
    **kwargs: Any,
) -> GitManager:
    """Create Git manager with default configuration."""
    manager = GitManager(
        project_path=project_path,
        auto_commit=auto_commit,
        **kwargs,
    )

    if not manager.is_repository():
        manager.initialize_repository()

    return manager


__all__ = [
    "GitError",
    "RepositoryNotFoundError",
    "CommitError",
    "GitManager",
    "create_git_manager",
]
