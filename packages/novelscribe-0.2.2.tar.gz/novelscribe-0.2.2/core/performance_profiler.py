"""
Performance Profiler for Novel Generation System

This module provides comprehensive profiling capabilities for tracking execution time
across agents, workflows, LLM calls, and file I/O operations.

Features:
- Agent-level timing with metadata
- Workflow-level timing with step breakdown
- LLM call timing (request/response)
- File I/O operation timing
- Bottleneck identification
- Performance report generation
- Export to JSON/CSV
"""

import csv
import json
import time
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional
from uuid import uuid4


class ProfileType(Enum):
    """Types of profiles that can be tracked"""

    AGENT = "agent"
    WORKFLOW = "workflow"
    LLM_CALL = "llm_call"
    FILE_IO = "file_io"
    CUSTOM = "custom"


class ExecutionStatus(Enum):
    """Execution status for profiles"""

    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"


@dataclass
class ExecutionProfile:
    """Represents a single execution profile with timing data"""

    profile_id: str
    name: str
    profile_type: ProfileType
    start_time: float
    end_time: Optional[float] = None
    duration: Optional[float] = None
    status: ExecutionStatus = ExecutionStatus.PENDING
    metadata: Dict[str, Any] = field(default_factory=dict)
    sub_profiles: List[str] = field(default_factory=list)  # IDs of sub-profiles
    parent_id: Optional[str] = None  # ID of parent profile
    error: Optional[str] = None

    def complete(self, end_time: Optional[float] = None) -> None:
        """Mark profile as completed and calculate duration"""
        self.end_time = end_time if end_time is not None else time.time()
        self.duration = self.end_time - self.start_time
        self.status = ExecutionStatus.COMPLETED

    def fail(self, error: str, end_time: Optional[float] = None) -> None:
        """Mark profile as failed"""
        self.end_time = end_time if end_time is not None else time.time()
        self.duration = self.end_time - self.start_time
        self.status = ExecutionStatus.FAILED
        self.error = error

    def to_dict(self) -> Dict[str, Any]:
        """Convert profile to dictionary for export"""
        return {
            "profile_id": self.profile_id,
            "name": self.name,
            "type": self.profile_type.value,
            "start_time": self.start_time,
            "end_time": self.end_time,
            "duration": self.duration,
            "status": self.status.value,
            "metadata": self.metadata,
            "sub_profiles": self.sub_profiles,
            "parent_id": self.parent_id,
            "error": self.error,
        }


@dataclass
class PerformanceReport:
    """Comprehensive performance report"""

    total_duration: float
    agent_profiles: List[ExecutionProfile]
    workflow_profiles: List[ExecutionProfile]
    llm_profiles: List[ExecutionProfile]
    file_io_profiles: List[ExecutionProfile]
    bottlenecks: List[str]
    summary: Dict[str, Any]

    def to_dict(self) -> Dict[str, Any]:
        """Convert report to dictionary"""
        return {
            "total_duration": self.total_duration,
            "agent_count": len(self.agent_profiles),
            "workflow_count": len(self.workflow_profiles),
            "llm_call_count": len(self.llm_profiles),
            "file_io_count": len(self.file_io_profiles),
            "bottlenecks": self.bottlenecks,
            "summary": self.summary,
            "agents": [p.to_dict() for p in self.agent_profiles],
            "workflows": [p.to_dict() for p in self.workflow_profiles],
            "llm_calls": [p.to_dict() for p in self.llm_profiles],
            "file_io": [p.to_dict() for p in self.file_io_profiles],
        }


class PerformanceProfiler:
    """
    Comprehensive performance profiler for tracking execution times

    Usage:
        profiler = PerformanceProfiler()

        # Profile an agent call
        profile_id = profiler.start_profile("writer_agent", ProfileType.AGENT)
        # ... execute agent ...
        profiler.end_profile(profile_id)

        # Get performance report
        report = profiler.get_report()
        print(report.summary)

        # Identify bottlenecks
        bottlenecks = profiler.identify_bottlenecks(threshold=5.0)

        # Export data
        profiler.export_data("performance.json", format="json")
    """

    def __init__(self):
        self.profiles: Dict[str, ExecutionProfile] = {}
        self.active_profiles: Dict[str, str] = {}  # name -> profile_id
        self.profile_stack: List[str] = []  # For tracking parent-child relationships
        self.start_time: float = time.time()

    def start_profile(
        self, name: str, profile_type: ProfileType, metadata: Optional[Dict[str, Any]] = None
    ) -> str:
        """
        Start a new profile

        Args:
            name: Descriptive name for the profile
            profile_type: Type of profile (AGENT, WORKFLOW, etc.)
            metadata: Optional metadata to attach

        Returns:
            Profile ID for use with end_profile()
        """
        profile_id = str(uuid4())
        profile = ExecutionProfile(
            profile_id=profile_id,
            name=name,
            profile_type=profile_type,
            start_time=time.time(),
            metadata=metadata or {},
            status=ExecutionStatus.RUNNING,
        )

        # Set parent relationship
        if self.profile_stack:
            parent_id = self.profile_stack[-1]
            profile.parent_id = parent_id
            parent_profile = self.profiles.get(parent_id)
            if parent_profile:
                parent_profile.sub_profiles.append(profile_id)

        self.profiles[profile_id] = profile
        self.active_profiles[name] = profile_id
        self.profile_stack.append(profile_id)

        return profile_id

    def end_profile(
        self,
        profile_id: str,
        error: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> ExecutionProfile:
        """
        End a profile and calculate duration

        Args:
            profile_id: ID from start_profile()
            error: Optional error message if execution failed
            metadata: Optional additional metadata

        Returns:
            Completed ExecutionProfile
        """
        profile = self.profiles.get(profile_id)
        if not profile:
            raise ValueError(f"Profile {profile_id} not found")

        # Update metadata if provided
        if metadata:
            profile.metadata.update(metadata)

        # Complete or fail the profile
        if error:
            profile.fail(error)
        else:
            profile.complete()

        # Remove from active profiles and stack
        if profile.name in self.active_profiles:
            del self.active_profiles[profile.name]

        if self.profile_stack and self.profile_stack[-1] == profile_id:
            self.profile_stack.pop()

        return profile

    def get_profile(self, profile_id: str) -> Optional[ExecutionProfile]:
        """Get a profile by ID"""
        return self.profiles.get(profile_id)

    def get_profiles_by_type(self, profile_type: ProfileType) -> List[ExecutionProfile]:
        """Get all profiles of a specific type"""
        return [p for p in self.profiles.values() if p.profile_type == profile_type]

    def get_profiles_by_name(self, name: str) -> List[ExecutionProfile]:
        """Get all profiles with a specific name"""
        return [p for p in self.profiles.values() if p.name == name]

    def identify_bottlenecks(
        self, threshold: float = 5.0, profile_type: Optional[ProfileType] = None
    ) -> List[str]:
        """
        Identify performance bottlenecks

        Args:
            threshold: Minimum duration in seconds to be considered a bottleneck
            profile_type: Optional filter by profile type

        Returns:
            List of bottleneck descriptions
        """
        bottlenecks = []

        profiles = self.profiles.values()
        if profile_type:
            profiles = [p for p in profiles if p.profile_type == profile_type]

        for profile in profiles:
            if profile.duration and profile.duration >= threshold:
                bottleneck = f"{profile.name}: {profile.duration:.2f}s"
                if profile.parent_id:
                    parent = self.profiles.get(profile.parent_id)
                    if parent:
                        percentage = (
                            (profile.duration / parent.duration * 100) if parent.duration else 0
                        )
                        bottleneck += f" ({percentage:.1f}% of {parent.name})"
                bottlenecks.append(bottleneck)

        # Sort by duration (descending)
        bottlenecks.sort(key=lambda x: float(x.split(": ")[1].split("s")[0]), reverse=True)

        return bottlenecks

    def get_report(self) -> PerformanceReport:
        """
        Generate comprehensive performance report

        Returns:
            PerformanceReport with all profiles and analysis
        """
        total_duration = time.time() - self.start_time

        agent_profiles = self.get_profiles_by_type(ProfileType.AGENT)
        workflow_profiles = self.get_profiles_by_type(ProfileType.WORKFLOW)
        llm_profiles = self.get_profiles_by_type(ProfileType.LLM_CALL)
        file_io_profiles = self.get_profiles_by_type(ProfileType.FILE_IO)

        bottlenecks = self.identify_bottlenecks()

        # Calculate summary statistics
        summary = self._calculate_summary()

        return PerformanceReport(
            total_duration=total_duration,
            agent_profiles=agent_profiles,
            workflow_profiles=workflow_profiles,
            llm_profiles=llm_profiles,
            file_io_profiles=file_io_profiles,
            bottlenecks=bottlenecks,
            summary=summary,
        )

    def _calculate_summary(self) -> Dict[str, Any]:
        """Calculate summary statistics"""

        def stats_for_profiles(profiles: List[ExecutionProfile]) -> Dict[str, Any]:
            completed = [p for p in profiles if p.duration is not None]
            if not completed:
                return {"count": len(profiles), "avg_duration": 0, "max_duration": 0}

            durations = [p.duration for p in completed]
            return {
                "count": len(completed),
                "avg_duration": sum(durations) / len(durations),
                "max_duration": max(durations),
                "min_duration": min(durations),
                "total_duration": sum(durations),
                "failed": len([p for p in profiles if p.status == ExecutionStatus.FAILED]),
            }

        return {
            "agents": stats_for_profiles(self.get_profiles_by_type(ProfileType.AGENT)),
            "workflows": stats_for_profiles(self.get_profiles_by_type(ProfileType.WORKFLOW)),
            "llm_calls": stats_for_profiles(self.get_profiles_by_type(ProfileType.LLM_CALL)),
            "file_io": stats_for_profiles(self.get_profiles_by_type(ProfileType.FILE_IO)),
            "total_profiles": len(self.profiles),
            "active_profiles": len(self.active_profiles),
        }

    def export_data(
        self, output_path: str, format: str = "json", profile_type: Optional[ProfileType] = None
    ) -> str:
        """
        Export profiling data to file

        Args:
            output_path: Path to output file
            format: Export format ('json' or 'csv')
            profile_type: Optional filter by profile type

        Returns:
            Absolute path to exported file
        """
        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)

        if format == "json":
            return self._export_json(output_path, profile_type)
        elif format == "csv":
            return self._export_csv(output_path, profile_type)
        else:
            raise ValueError(f"Unsupported export format: {format}")

    def _export_json(self, output_path: Path, profile_type: Optional[ProfileType]) -> str:
        """Export data as JSON"""
        report = self.get_report()
        data = report.to_dict()

        if profile_type:
            data["profiles"] = [p.to_dict() for p in self.get_profiles_by_type(profile_type)]

        with open(output_path, "w") as f:
            json.dump(data, f, indent=2)

        return str(output_path.absolute())

    def _export_csv(self, output_path: Path, profile_type: Optional[ProfileType]) -> str:
        """Export data as CSV"""
        profiles = list(self.profiles.values())
        if profile_type:
            profiles = self.get_profiles_by_type(profile_type)

        with open(output_path, "w", newline="") as f:
            writer = csv.writer(f)
            writer.writerow(
                [
                    "Profile ID",
                    "Name",
                    "Type",
                    "Start Time",
                    "End Time",
                    "Duration",
                    "Status",
                    "Parent ID",
                    "Error",
                ]
            )

            for profile in profiles:
                writer.writerow(
                    [
                        profile.profile_id,
                        profile.name,
                        profile.profile_type.value,
                        profile.start_time,
                        profile.end_time,
                        profile.duration or "",
                        profile.status.value,
                        profile.parent_id or "",
                        profile.error or "",
                    ]
                )

        return str(output_path.absolute())

    def clear(self) -> None:
        """Clear all profiling data"""
        self.profiles.clear()
        self.active_profiles.clear()
        self.profile_stack.clear()
        self.start_time = time.time()

    def get_active_profiles(self) -> List[ExecutionProfile]:
        """Get all currently active (running) profiles"""
        return [self.profiles[profile_id] for profile_id in self.profile_stack]


class ProfilingContext:
    """
    Context manager for automatic profiling

    Usage:
        profiler = PerformanceProfiler()

        with ProfilingContext(profiler, "writer_agent", ProfileType.AGENT):
            # ... code to profile ...
            pass
    """

    def __init__(
        self,
        profiler: PerformanceProfiler,
        name: str,
        profile_type: ProfileType,
        metadata: Optional[Dict[str, Any]] = None,
    ):
        self.profiler = profiler
        self.name = name
        self.profile_type = profile_type
        self.metadata = metadata
        self.profile_id: Optional[str] = None

    def __enter__(self) -> "ProfilingContext":
        self.profile_id = self.profiler.start_profile(self.name, self.profile_type, self.metadata)
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        if self.profile_id:
            error = str(exc_val) if exc_val else None
            self.profiler.end_profile(self.profile_id, error=error)


# Global profiler instance
_global_profiler: Optional[PerformanceProfiler] = None


def get_profiler() -> PerformanceProfiler:
    """Get the global profiler instance"""
    global _global_profiler
    if _global_profiler is None:
        _global_profiler = PerformanceProfiler()
    return _global_profiler


def profile_function(
    profiler: Optional[PerformanceProfiler] = None,
    name: Optional[str] = None,
    profile_type: ProfileType = ProfileType.CUSTOM,
):
    """
    Decorator for profiling functions

    Usage:
        @profile_function(name="my_function", profile_type=ProfileType.AGENT)
        def my_function():
            # ... function code ...
            pass
    """

    def decorator(func):
        def wrapper(*args, **kwargs):
            nonlocal profiler
            if profiler is None:
                profiler = get_profiler()

            profile_name = name or func.__name__
            profile_id = profiler.start_profile(profile_name, profile_type)

            try:
                result = func(*args, **kwargs)
                profiler.end_profile(profile_id)
                return result
            except Exception as e:
                profiler.end_profile(profile_id, error=str(e))
                raise

        return wrapper

    return decorator
