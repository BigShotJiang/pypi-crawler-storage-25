"""
Chapter Paginator for Long-Form Novel Generation

This module provides chapter pagination capabilities to handle chapters up to 5000 words
by splitting them into semantic pages while maintaining narrative coherence.
"""

import re
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Dict, List, Optional

from pydantic import BaseModel, ConfigDict

from .context_manager import TokenEstimator


class PageSplitStrategy(str, Enum):
    """Strategies for splitting chapters into pages."""

    TOKEN_BASED = "token_based"
    SCENE_BASED = "scene_based"
    PARAGRAPH_BASED = "paragraph_based"
    SEMANTIC = "semantic"


@dataclass
class PageMetadata:
    """Metadata for a page within a chapter."""

    page_number: int
    start_position: int
    end_position: int
    word_count: int
    token_count: int
    scene_identifier: Optional[str] = None
    characters_present: List[str] = field(default_factory=list)
    locations_present: List[str] = field(default_factory=list)
    key_events: List[str] = field(default_factory=list)
    created_at: datetime = field(default_factory=datetime.now)

    def to_dict(self) -> Dict:
        """Convert to dictionary."""
        return {
            "page_number": self.page_number,
            "start_position": self.start_position,
            "end_position": self.end_position,
            "word_count": self.word_count,
            "token_count": self.token_count,
            "scene_identifier": self.scene_identifier,
            "characters_present": self.characters_present,
            "locations_present": self.locations_present,
            "key_events": self.key_events,
            "created_at": self.created_at.isoformat(),
        }


@dataclass
class ChapterPage:
    """A single page within a chapter."""

    page_number: int
    content: str
    metadata: PageMetadata
    overlap_content: str = ""

    @property
    def word_count(self) -> int:
        """Get word count of page."""
        return len(re.findall(r"\b\w+\b", self.content))

    @property
    def full_content(self) -> str:
        """Get full content including overlap."""
        if self.overlap_content:
            return f"{self.overlap_content}\n\n{self.content}"
        return self.content

    def get_context_hint(self) -> str:
        """Get context hint for this page."""
        hint_parts = []

        if self.metadata.scene_identifier:
            hint_parts.append(f"Scene: {self.metadata.scene_identifier}")

        if self.metadata.characters_present:
            hint_parts.append(f"Characters: {', '.join(self.metadata.characters_present)}")

        if self.metadata.locations_present:
            hint_parts.append(f"Location: {', '.join(self.metadata.locations_present)}")

        return " | ".join(hint_parts) if hint_parts else "Continuing story..."


class PaginationConfig(BaseModel):
    """Configuration for chapter pagination."""

    strategy: PageSplitStrategy = PageSplitStrategy.SEMANTIC
    max_tokens_per_page: int = 2500
    target_tokens_per_page: int = 2000
    overlap_tokens: int = 200
    min_page_tokens: int = 500
    preserve_scene_boundaries: bool = True
    preserve_dialogue_groups: bool = True

    model_config = ConfigDict(use_enum_values=True)


class ChapterPaginator:
    """
    Split chapters into semantic pages for efficient processing.

    Handles chapters up to 5000 words by splitting them into manageable
    pages while maintaining narrative coherence and context.
    """

    SCENE_BREAK_PATTERNS = [
        re.compile(r"\n\s*\n\s*[*#-]{3,}\n"),
        re.compile(r"\n\s*\n\s*~{3,}\n"),
        re.compile(r"\n\s*#{3,}\s*.*?\n"),
        re.compile(r"\n\s*\n\s*(Chapter|Scene|Part)\s+\d+.*?\n", re.IGNORECASE),
    ]

    PARAGRAPH_PATTERN = re.compile(r"\n\s*\n")
    SENTENCE_PATTERN = re.compile(r"[.!?]+[\s\n]+")
    DIALOGUE_PATTERN = re.compile(r'"[^"]*"')

    def __init__(self, config: Optional[PaginationConfig] = None):
        """
        Initialize chapter paginator.

        Args:
            config: Optional pagination configuration
        """
        self.config = config or PaginationConfig()
        self.token_estimator = TokenEstimator()

    def paginate_chapter(
        self, content: str, chapter_number: int, metadata: Optional[Dict[str, any]] = None
    ) -> List[ChapterPage]:
        """
        Split chapter content into pages.

        Args:
            content: Chapter content to paginate
            chapter_number: Chapter number
            metadata: Optional chapter metadata

        Returns:
            List of ChapterPage objects
        """
        if not content or not content.strip():
            return []

        # Check if pagination is needed
        total_tokens = self.token_estimator.estimate_tokens(content)
        if total_tokens <= self.config.max_tokens_per_page:
            # No pagination needed
            page = self._create_single_page(content, chapter_number, metadata)
            return [page]

        # Paginate based on strategy
        if self.config.strategy == PageSplitStrategy.SCENE_BASED:
            return self._paginate_by_scenes(content, chapter_number, metadata)
        elif self.config.strategy == PageSplitStrategy.PARAGRAPH_BASED:
            return self._paginate_by_paragraphs(content, chapter_number, metadata)
        elif self.config.strategy == PageSplitStrategy.SEMANTIC:
            return self._paginate_semantically(content, chapter_number, metadata)
        else:  # TOKEN_BASED
            return self._paginate_by_tokens(content, chapter_number, metadata)

    def _create_single_page(
        self, content: str, chapter_number: int, metadata: Optional[Dict[str, any]]
    ) -> ChapterPage:
        """Create a single page for content that doesn't need pagination."""
        tokens = self.token_estimator.estimate_tokens(content)
        words = len(re.findall(r"\b\w+\b", content))

        page_metadata = PageMetadata(
            page_number=1,
            start_position=0,
            end_position=len(content),
            word_count=words,
            token_count=tokens,
        )

        # Extract metadata if provided
        if metadata:
            self._enrich_page_metadata(page_metadata, metadata, content)

        return ChapterPage(page_number=1, content=content, metadata=page_metadata)

    def _paginate_by_tokens(
        self, content: str, chapter_number: int, metadata: Optional[Dict[str, any]]
    ) -> List[ChapterPage]:
        """Paginate based purely on token count."""
        pages = []
        position = 0
        page_number = 1
        previous_content = ""

        while position < len(content):
            # Calculate target end position
            remaining_content = content[position:]
            remaining_tokens = self.token_estimator.estimate_tokens(remaining_content)

            if remaining_tokens <= self.config.target_tokens_per_page:
                # Last page
                page_content = remaining_content
                end_position = len(content)
            else:
                # Find split point
                target_position = position + int(
                    (self.config.target_tokens_per_page / remaining_tokens) * len(remaining_content)
                )
                split_position = self._find_safe_split_point(content, target_position)
                page_content = content[position:split_position]
                end_position = split_position

            # Create page
            page_metadata = PageMetadata(
                page_number=page_number,
                start_position=position,
                end_position=end_position,
                word_count=len(re.findall(r"\b\w+\b", page_content)),
                token_count=self.token_estimator.estimate_tokens(page_content),
            )

            if metadata:
                self._enrich_page_metadata(page_metadata, metadata, page_content)

            page = ChapterPage(
                page_number=page_number,
                content=page_content,
                metadata=page_metadata,
                overlap_content=(
                    previous_content[-self.config.overlap_tokens * 3 :] if previous_content else ""
                ),
            )

            pages.append(page)

            # Prepare for next page
            previous_content = page_content
            position = end_position
            page_number += 1

        return pages

    def _paginate_by_scenes(
        self, content: str, chapter_number: int, metadata: Optional[Dict[str, any]]
    ) -> List[ChapterPage]:
        """Paginate based on scene boundaries."""
        # Find all scene breaks
        scene_breaks = []
        for pattern in self.SCENE_BREAK_PATTERNS:
            for match in pattern.finditer(content):
                scene_breaks.append(match.start())

        # Remove duplicates and sort
        scene_breaks = sorted(set(scene_breaks))

        if not scene_breaks:
            # No scene breaks, fall back to semantic pagination
            return self._paginate_semantically(content, chapter_number, metadata)

        # Create pages based on scenes
        pages = []
        page_number = 1
        start_position = 0

        for break_position in scene_breaks + [len(content)]:
            scene_content = content[start_position:break_position].strip()
            if not scene_content:
                continue

            scene_tokens = self.token_estimator.estimate_tokens(scene_content)

            if scene_tokens > self.config.max_tokens_per_page:
                # Scene too large, need to split further
                sub_pages = self._paginate_by_tokens(scene_content, chapter_number, metadata)
                for sub_page in sub_pages:
                    sub_page.metadata.page_number = page_number
                    sub_page.metadata.start_position += start_position
                    sub_page.metadata.end_position += start_position
                    pages.append(sub_page)
                    page_number += 1
            else:
                page_metadata = PageMetadata(
                    page_number=page_number,
                    start_position=start_position,
                    end_position=break_position,
                    word_count=len(re.findall(r"\b\w+\b", scene_content)),
                    token_count=scene_tokens,
                    scene_identifier=f"scene_{page_number}",
                )

                if metadata:
                    self._enrich_page_metadata(page_metadata, metadata, scene_content)

                page = ChapterPage(
                    page_number=page_number, content=scene_content, metadata=page_metadata
                )

                pages.append(page)
                page_number += 1

            start_position = break_position

        return pages

    def _paginate_by_paragraphs(
        self, content: str, chapter_number: int, metadata: Optional[Dict[str, any]]
    ) -> List[ChapterPage]:
        """Paginate based on paragraph boundaries."""
        paragraphs = self.PARAGRAPH_PATTERN.split(content)
        paragraphs = [p.strip() for p in paragraphs if p.strip()]

        pages = []
        current_page_content = ""
        page_number = 1
        position = 0

        for paragraph in paragraphs:
            test_content = (
                current_page_content + "\n\n" + paragraph if current_page_content else paragraph
            )
            test_tokens = self.token_estimator.estimate_tokens(test_content)

            if test_tokens <= self.config.target_tokens_per_page:
                # Add paragraph to current page
                current_page_content = test_content
            else:
                # Current page is full
                if current_page_content:
                    # Create page
                    page = self._create_page_from_content(
                        current_page_content, page_number, position, chapter_number, metadata
                    )
                    pages.append(page)
                    position += len(current_page_content)
                    page_number += 1

                # Start new page
                if (
                    self.token_estimator.estimate_tokens(paragraph)
                    > self.config.max_tokens_per_page
                ):
                    # Single paragraph too large, need to split
                    sub_pages = self._paginate_by_tokens(paragraph, chapter_number, metadata)
                    for sub_page in sub_pages:
                        sub_page.metadata.page_number = page_number
                        pages.append(sub_page)
                        page_number += 1
                    current_page_content = ""
                else:
                    current_page_content = paragraph

        # Add last page
        if current_page_content:
            page = self._create_page_from_content(
                current_page_content, page_number, position, chapter_number, metadata
            )
            pages.append(page)

        return pages

    def _paginate_semantically(
        self, content: str, chapter_number: int, metadata: Optional[Dict[str, any]]
    ) -> List[ChapterPage]:
        """Paginate using semantic analysis for best coherence."""
        # Try scene-based first
        scene_pages = self._paginate_by_scenes(content, chapter_number, metadata)

        # Check if scene pagination worked well
        if len(scene_pages) > 1:
            avg_tokens = sum(p.metadata.token_count for p in scene_pages) / len(scene_pages)
            if self.config.min_page_tokens <= avg_tokens <= self.config.max_tokens_per_page:
                return scene_pages

        # Fall back to paragraph-based
        return self._paginate_by_paragraphs(content, chapter_number, metadata)

    def _find_safe_split_point(self, content: str, target_position: int) -> int:
        """Find a safe position to split content (near sentence boundaries)."""
        # Look for sentence boundaries near target position
        search_range = min(500, len(content) - target_position)
        search_start = max(0, target_position - search_range)
        search_end = min(len(content), target_position + search_range)

        search_area = content[search_start:search_end]

        # Find sentence endings
        for match in self.SENTENCE_PATTERN.finditer(search_area):
            split_pos = search_start + match.end()
            if search_start <= split_pos <= search_end:
                return split_pos

        # No sentence boundary found, use target position
        return target_position

    def _create_page_from_content(
        self,
        content: str,
        page_number: int,
        start_position: int,
        chapter_number: int,
        metadata: Optional[Dict[str, any]],
    ) -> ChapterPage:
        """Create a ChapterPage from content."""
        tokens = self.token_estimator.estimate_tokens(content)
        words = len(re.findall(r"\b\w+\b", content))

        page_metadata = PageMetadata(
            page_number=page_number,
            start_position=start_position,
            end_position=start_position + len(content),
            word_count=words,
            token_count=tokens,
        )

        if metadata:
            self._enrich_page_metadata(page_metadata, metadata, content)

        return ChapterPage(page_number=page_number, content=content, metadata=page_metadata)

    def _enrich_page_metadata(
        self, page_metadata: PageMetadata, chapter_metadata: Dict[str, any], content: str
    ):
        """Enrich page metadata with extracted information."""
        # Extract characters
        if "characters" in chapter_metadata:
            mentioned_chars = []
            for char in chapter_metadata["characters"]:
                if char.lower() in content.lower():
                    mentioned_chars.append(char)
            page_metadata.characters_present = mentioned_chars

        # Extract locations
        if "locations" in chapter_metadata:
            mentioned_locs = []
            for loc in chapter_metadata["locations"]:
                if loc.lower() in content.lower():
                    mentioned_locs.append(loc)
            page_metadata.locations_present = mentioned_locs

        # Extract dialogue for key events
        dialogues = self.DIALOGUE_PATTERN.findall(content)
        if dialogues:
            page_metadata.key_events = [f"Dialogue: {d[:50]}..." for d in dialogues[:3]]

    def regenerate_page(self, original_page: ChapterPage, new_content: str) -> ChapterPage:
        """
        Regenerate a page with new content while preserving metadata.

        Args:
            original_page: Original page to regenerate
            new_content: New content for the page

        Returns:
            New ChapterPage with updated content
        """
        tokens = self.token_estimator.estimate_tokens(new_content)
        words = len(re.findall(r"\b\w+\b", new_content))

        new_metadata = PageMetadata(
            page_number=original_page.metadata.page_number,
            start_position=original_page.metadata.start_position,
            end_position=original_page.metadata.start_position + len(new_content),
            word_count=words,
            token_count=tokens,
            scene_identifier=original_page.metadata.scene_identifier,
            characters_present=original_page.metadata.characters_present,
            locations_present=original_page.metadata.locations_present,
            key_events=original_page.metadata.key_events,
        )

        return ChapterPage(
            page_number=original_page.page_number,
            content=new_content,
            metadata=new_metadata,
            overlap_content=original_page.overlap_content,
        )

    def get_pagination_summary(self, pages: List[ChapterPage]) -> Dict[str, any]:
        """
        Get summary statistics for pagination.

        Args:
            pages: List of pages

        Returns:
            Dictionary with summary statistics
        """
        if not pages:
            return {
                "total_pages": 0,
                "total_words": 0,
                "total_tokens": 0,
                "avg_words_per_page": 0,
                "avg_tokens_per_page": 0,
            }

        total_words = sum(p.word_count for p in pages)
        total_tokens = sum(p.metadata.token_count for p in pages)

        return {
            "total_pages": len(pages),
            "total_words": total_words,
            "total_tokens": total_tokens,
            "avg_words_per_page": total_words // len(pages),
            "avg_tokens_per_page": total_tokens // len(pages),
            "pages_with_scenes": sum(1 for p in pages if p.metadata.scene_identifier),
            "total_characters": len(
                set(char for p in pages for char in p.metadata.characters_present)
            ),
            "total_locations": len(set(loc for p in pages for loc in p.metadata.locations_present)),
        }
