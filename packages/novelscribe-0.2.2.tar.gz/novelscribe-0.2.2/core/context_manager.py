"""
Context Window Manager for LLM-Based Novel Generation

This module provides context window management for efficient LLM utilization,
including token tracking, context chunking, and optimization strategies.
"""

import re
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional, Tuple

from pydantic import BaseModel, ConfigDict

from .llm_client import LLMProvider


class ContextStrategy(str, Enum):
    """Strategies for context window management."""

    FULL_CONTEXT = "full_context"
    SLIDING_WINDOW = "sliding_window"
    SUMMARIZATION = "summarization"
    HYBRID = "hybrid"


@dataclass
class ContextChunk:
    """A chunk of content with metadata."""

    content: str
    token_count: int
    chapter_number: int
    page_number: Optional[int] = None
    metadata: Dict[str, Any] = field(default_factory=dict)

    @property
    def size_kb(self) -> float:
        """Get size in kilobytes."""
        return len(self.content.encode("utf-8")) / 1024


@dataclass
class ContextWindow:
    """Track context window usage and capacity."""

    provider: LLMProvider
    max_tokens: int
    used_tokens: int = 0
    reserved_tokens: int = 500

    @property
    def available_tokens(self) -> int:
        """Get available tokens for content."""
        return self.max_tokens - self.used_tokens - self.reserved_tokens

    @property
    def utilization_rate(self) -> float:
        """Get context window utilization rate."""
        return self.used_tokens / self.max_tokens if self.max_tokens > 0 else 0.0

    def can_fit(self, token_count: int) -> bool:
        """Check if content can fit in context window."""
        return (self.used_tokens + token_count) <= (self.max_tokens - self.reserved_tokens)

    def allocate(self, token_count: int) -> bool:
        """Allocate tokens in context window."""
        if self.can_fit(token_count):
            self.used_tokens += token_count
            return True
        return False

    def deallocate(self, token_count: int):
        """Deallocate tokens from context window."""
        self.used_tokens = max(0, self.used_tokens - token_count)

    def reset(self):
        """Reset context window usage."""
        self.used_tokens = 0


class TokenEstimator:
    """
    Estimate token counts for text content.

    Uses approximate token counting based on word length and character patterns.
    For production, consider using tiktoken or provider-specific tokenizers.
    """

    @staticmethod
    def estimate_tokens(text: str) -> int:
        """
        Estimate token count for text.

        Approximation: ~1 token per 4 characters for English text.
        Adjusted for common patterns in prose.
        """
        if not text:
            return 0

        # Count words (approximate)
        words = re.findall(r"\b\w+\b", text)
        word_count = len(words)

        # Count punctuation
        punctuation = len(re.findall(r"[.,!?;:]", text))

        # Count special tokens (dialogue, etc.)
        dialogue_quotes = len(re.findall(r'"[^"]*"', text))

        # Estimate tokens
        # Average: 1.3 tokens per word for English prose
        estimated_tokens = int(word_count * 1.3) + punctuation + dialogue_quotes

        return max(estimated_tokens, 1)

    @staticmethod
    def estimate_tokens_for_chunks(chunks: List[ContextChunk]) -> int:
        """Estimate total tokens for multiple chunks."""
        return sum(chunk.token_count for chunk in chunks)


class ContextManagerConfig(BaseModel):
    """Configuration for context management."""

    strategy: ContextStrategy = ContextStrategy.HYBRID
    max_context_chunks: int = 10
    chunk_overlap_tokens: int = 200
    recent_chapters_full: int = 5
    summary_chapters_limit: int = 20
    optimize_for_provider: Optional[LLMProvider] = None

    model_config = ConfigDict(use_enum_values=True)


class ContextManager:
    """
    Manage context window allocation and optimization.

    Tracks token usage, implements context chunking strategies,
    and optimizes context allocation for LLM efficiency.
    """

    PROVIDER_CONTEXT_LIMITS = {
        LLMProvider.OPENAI: 128000,
        LLMProvider.CLAUDE: 200000,
        LLMProvider.GEMINI: 1000000,
        LLMProvider.OLLAMA: 8192,
        LLMProvider.LM_STUDIO: 8192,
    }

    def __init__(self, provider: LLMProvider, config: Optional[ContextManagerConfig] = None):
        """
        Initialize context manager.

        Args:
            provider: LLM provider for context limits
            config: Optional configuration
        """
        self.provider = provider
        self.config = config or ContextManagerConfig()

        max_tokens = self.PROVIDER_CONTEXT_LIMITS.get(provider, 8192)
        self.window = ContextWindow(provider=provider, max_tokens=max_tokens)

        self.chunks: List[ContextChunk] = []
        self.chapter_summaries: Dict[int, str] = {}
        self.metadata: Dict[str, Any] = {}

        self.token_estimator = TokenEstimator()

    def allocate_context(
        self, content: str, chapter_number: int, page_number: Optional[int] = None
    ) -> bool:
        """
        Allocate context for content.

        Args:
            content: Content to allocate
            chapter_number: Chapter number
            page_number: Optional page number

        Returns:
            True if allocation successful
        """
        token_count = self.token_estimator.estimate_tokens(content)

        if not self.window.can_fit(token_count):
            self._optimize_context(token_count)

        if self.window.allocate(token_count):
            chunk = ContextChunk(
                content=content,
                token_count=token_count,
                chapter_number=chapter_number,
                page_number=page_number,
                metadata={},
            )
            self.chunks.append(chunk)
            return True

        return False

    def _optimize_context(self, required_tokens: int):
        """
        Optimize context to make room for new content.

        Args:
            required_tokens: Tokens required for new content
        """
        target_tokens = self.window.available_tokens - required_tokens

        if target_tokens < 0:
            # Need to free up space
            if self.config.strategy in [ContextStrategy.SUMMARIZATION, ContextStrategy.HYBRID]:
                self._summarize_old_context(target_tokens)
            elif self.config.strategy == ContextStrategy.SLIDING_WINDOW:
                self._slide_window(target_tokens)
            else:
                self._truncate_oldest(target_tokens)

    def _summarize_old_context(self, target_tokens: int):
        """
        Summarize old context to free space.

        Args:
            target_tokens: Target tokens to free
        """
        freed_tokens = 0

        # Start from oldest chunks
        for chunk in self.chunks[:]:
            if chunk.chapter_number >= (self.config.recent_chapters_full + 1):
                # Summarize this chunk
                summary = self._create_summary(chunk.content)
                summary_tokens = self.token_estimator.estimate_tokens(summary)

                # Replace chunk with summary
                self.chunks.remove(chunk)
                self.window.deallocate(chunk.token_count)

                # Store summary
                self.chapter_summaries[chunk.chapter_number] = summary
                freed_tokens += chunk.token_count - summary_tokens

                if freed_tokens >= target_tokens:
                    break

    def _slide_window(self, target_tokens: int):
        """
        Slide context window to free space.

        Args:
            target_tokens: Target tokens to free
        """
        freed_tokens = 0

        # Remove oldest chunks
        for chunk in self.chunks[:]:
            self.chunks.remove(chunk)
            self.window.deallocate(chunk.token_count)
            freed_tokens += chunk.token_count

            if freed_tokens >= target_tokens:
                break

    def _truncate_oldest(self, target_tokens: int):
        """
        Truncate oldest chunks to free space.

        Args:
            target_tokens: Target tokens to free
        """
        freed_tokens = 0

        for chunk in self.chunks[:]:
            if freed_tokens >= target_tokens:
                break

            # Truncate chunk
            truncate_amount = min(chunk.token_count, target_tokens - freed_tokens)
            chunk.content = chunk.content[-int(truncate_amount * 3) :]
            chunk.token_count -= truncate_amount

            self.window.deallocate(truncate_amount)
            freed_tokens += truncate_amount

    def _create_summary(self, content: str) -> str:
        """
        Create summary of content.

        Args:
            content: Content to summarize

        Returns:
            Summary string
        """
        # Simple summarization: first and last sentences
        sentences = re.split(r"[.!?]+", content)
        sentences = [s.strip() for s in sentences if s.strip()]

        if len(sentences) <= 2:
            return content

        first_sentence = sentences[0]
        last_sentence = sentences[-1]

        summary = f"{first_sentence}. ... {last_sentence}."

        return summary

    def get_context_chunks(self, chapter_number: Optional[int] = None) -> List[ContextChunk]:
        """
        Get context chunks, optionally filtered by chapter.

        Args:
            chapter_number: Optional chapter number to filter

        Returns:
            List of context chunks
        """
        if chapter_number is None:
            return self.chunks.copy()

        return [c for c in self.chunks if c.chapter_number == chapter_number]

    def get_context_for_generation(self, target_chapter: int) -> List[ContextChunk]:
        """
        Get optimized context for generating target chapter.

        Args:
            target_chapter: Chapter number being generated

        Returns:
            List of relevant context chunks
        """
        if self.config.strategy == ContextStrategy.FULL_CONTEXT:
            return self.chunks.copy()

        elif self.config.strategy == ContextStrategy.SLIDING_WINDOW:
            # Recent chapters in full
            recent = [
                c
                for c in self.chunks
                if c.chapter_number >= (target_chapter - self.config.recent_chapters_full)
            ]
            return recent

        elif self.config.strategy == ContextStrategy.SUMMARIZATION:
            # Recent chapters full, older summarized
            recent = [
                c
                for c in self.chunks
                if c.chapter_number >= (target_chapter - self.config.recent_chapters_full)
            ]
            return recent

        else:  # HYBRID
            chunks = []

            # Recent chapters in full
            recent = [
                c
                for c in self.chunks
                if c.chapter_number >= (target_chapter - self.config.recent_chapters_full)
            ]
            chunks.extend(recent)

            # Add summaries of older chapters
            for chapter_num in range(1, target_chapter - self.config.recent_chapters_full):
                if chapter_num in self.chapter_summaries:
                    summary = self.chapter_summaries[chapter_num]
                    summary_tokens = self.token_estimator.estimate_tokens(summary)

                    chunk = ContextChunk(
                        content=summary,
                        token_count=summary_tokens,
                        chapter_number=chapter_num,
                        metadata={"is_summary": True},
                    )
                    chunks.append(chunk)

            return chunks

    def add_metadata(self, key: str, value: Any):
        """Add metadata to context manager."""
        self.metadata[key] = value

    def get_metadata(self, key: str) -> Optional[Any]:
        """Get metadata from context manager."""
        return self.metadata.get(key)

    def clear_context(self):
        """Clear all context chunks and reset window."""
        self.chunks.clear()
        self.window.reset()
        self.chapter_summaries.clear()

    def get_statistics(self) -> Dict[str, Any]:
        """
        Get context manager statistics.

        Returns:
            Dictionary with statistics
        """
        total_content_tokens = sum(c.token_count for c in self.chunks)
        total_summary_tokens = sum(
            self.token_estimator.estimate_tokens(s) for s in self.chapter_summaries.values()
        )

        stats = {
            "provider": self.provider.value
            if hasattr(self.provider, "value")
            else str(self.provider),
            "strategy": self.config.strategy.value
            if hasattr(self.config.strategy, "value")
            else str(self.config.strategy),
            "max_tokens": self.window.max_tokens,
            "used_tokens": self.window.used_tokens,
            "available_tokens": self.window.available_tokens,
            "utilization_rate": self.window.utilization_rate,
            "total_chunks": len(self.chunks),
            "content_tokens": total_content_tokens,
            "summary_tokens": total_summary_tokens,
            "summarized_chapters": len(self.chapter_summaries),
        }

        return stats

    def estimate_capacity(self, word_count: int) -> Tuple[bool, int]:
        """
        Estimate if content can fit in context window.

        Args:
            word_count: Word count of content

        Returns:
            Tuple of (can_fit, required_tokens)
        """
        # Estimate tokens: ~1.3 tokens per word
        estimated_tokens = int(word_count * 1.3)

        can_fit = self.window.can_fit(estimated_tokens)

        return can_fit, estimated_tokens

    def optimize_for_provider(self, provider: LLMProvider):
        """
        Optimize context settings for specific provider.

        Args:
            provider: LLM provider
        """
        self.config.optimize_for_provider = provider

        # Adjust chunk size based on provider
        if provider in [LLMProvider.OLLAMA, LLMProvider.LM_STUDIO]:
            self.config.max_context_chunks = 5
            self.config.chunk_overlap_tokens = 100
        elif provider == LLMProvider.CLAUDE:
            self.config.max_context_chunks = 20
            self.config.chunk_overlap_tokens = 300
        elif provider == LLMProvider.OPENAI:
            self.config.max_context_chunks = 15
            self.config.chunk_overlap_tokens = 250
